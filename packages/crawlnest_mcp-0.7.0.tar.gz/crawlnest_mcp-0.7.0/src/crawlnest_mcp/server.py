"""CrawlNest MCP Server

A Model Context Protocol server that exposes CrawlNest's web scraping capabilities
to AI assistants like Claude Desktop using FastMCP for proper Context support.
"""

import json
import logging

from mcp.server.fastmcp import Context, FastMCP

from .tools.appstore import (
    handle_appstore_app,
    handle_appstore_bulk,
    handle_appstore_charts,
    handle_appstore_developer,
    handle_appstore_in_app_purchases,
    handle_appstore_privacy,
    handle_appstore_ratings,
    handle_appstore_reviews,
    handle_appstore_search,
)
from .tools.crawl_website import handle_crawl_website
from .tools.extract_structured import handle_extract_structured
from .tools.github import (
    handle_github_contributors,
    handle_github_forks,
    handle_github_releases,
    handle_github_repo,
    handle_github_search_issues,
    handle_github_search_repos,
    handle_github_search_topics,
    handle_github_search_users,
    handle_github_stargazers,
    handle_github_topic_repos,
    handle_github_trending,
    handle_github_user,
    handle_github_user_repos,
    handle_github_user_starred,
)
from .tools.image import handle_download_image
from .tools.playstore import (
    handle_playstore_app,
    handle_playstore_category,
    handle_playstore_charts,
    handle_playstore_developer,
    handle_playstore_device,
    handle_playstore_games,
    handle_playstore_reviews,
    handle_playstore_search,
    handle_playstore_similar,
)
from .tools.reddit import (
    handle_reddit_about,
    handle_reddit_community,
    handle_reddit_explore,
    handle_reddit_feed,
    handle_reddit_popular,
    handle_reddit_post,
    handle_reddit_search,
)
from .tools.hackernews import (
    handle_hn_best_stories,
    handle_hn_comment_feed,
    handle_hn_comments,
    handle_hn_companies_search,
    handle_hn_company,
    handle_hn_domain_stories,
    handle_hn_founders_search,
    handle_hn_latest_stories,
    handle_hn_launch_detail,
    handle_hn_launches_search,
    handle_hn_leaders,
    handle_hn_ranked_stories,
    handle_hn_search,
    handle_hn_startup_job_detail,
    handle_hn_startup_jobs,
    handle_hn_story,
    handle_hn_user,
    handle_hn_user_activity,
    handle_hn_user_favorites,
    handle_hn_user_submissions,
    handle_hn_user_threads,
    handle_hn_who_is_hiring,
)
from .tools.scrape_url import handle_scrape_url
from .tools.twitter import (
    handle_fetch_tweet,
    handle_twitter_for_you,
    handle_twitter_home_timeline,
    handle_twitter_news,
    handle_twitter_search,
    handle_twitter_trending,
    handle_twitter_user_info,
)
from .tools.video import handle_download_video, handle_transcribe_video

# Set up file logging - debug output goes here, NOT to stdout/stderr
# Remove any existing handlers first
root_logger = logging.getLogger()
for handler in root_logger.handlers[:]:
    root_logger.removeHandler(handler)

# Create file handler
file_handler = logging.FileHandler("/tmp/mcp_server.log")
file_handler.setLevel(logging.DEBUG)
formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
file_handler.setFormatter(formatter)

# Configure root logger
root_logger.setLevel(logging.DEBUG)
root_logger.addHandler(file_handler)

logger = logging.getLogger(__name__)

# Suppress verbose httpx/httpcore logging
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)

# Create FastMCP server instance with longer timeout for long-running crawls
server = FastMCP("crawlnest")


# --- JSON response helper ---

def _parse_result(result) -> dict:
    """Parse handler result (list[TextContent]) into a dict."""
    if result and len(result) > 0:
        try:
            response_data: dict = json.loads(result[0].text)
            return response_data
        except json.JSONDecodeError:
            return {"success": False, "error": "Invalid JSON response from handler"}
    return {"success": False, "error": "No content returned"}


# =============================================================================
# Web Scraping Tools
# =============================================================================


@server.tool()
async def scrape_url(
    url: str,
    proxy: str | None = None,
    useragent: str | None = None,
    ctx: Context | None = None,
) -> dict:
    """
    GENERAL PURPOSE: Scrape a URL to get raw page content, images, links, and metadata.

    Use this for exploratory browsing or getting general page information.
    For structured data extraction (e.g., extract products with name, price, image),
    use extract_structured tool instead.

    Uses CrawlNest's multi-layer scraping with automatic anti-bot bypass.
    """
    logger.info(f"[scrape_url] Called with URL: {url}")
    result = await handle_scrape_url({"url": url, "proxy": proxy, "useragent": useragent})
    return _parse_result(result)


@server.tool()
async def crawl_website(
    url: str,
    max_pages: int = 10,
    same_domain: bool = True,
    include_pattern: str | None = None,
    exclude_pattern: str | None = None,
    ctx: Context | None = None,
) -> dict:
    """
    Crawl an entire website and extract content from multiple pages.

    Uses sitemap.xml for efficient URL discovery when available, otherwise
    follows HTML links. Supports up to 50 pages with real-time progress tracking.
    Useful for scraping blogs, documentation sites, or entire website sections.
    Returns an array of page objects with content, url, title, and metadata.
    """
    logger.info(
        f"[crawl_website] Called with URL: {url}, max_pages: {max_pages}, ctx: {ctx is not None}"
    )

    arguments = {
        "url": url,
        "max_pages": max_pages,
        "same_domain": same_domain,
        "include_pattern": include_pattern,
        "exclude_pattern": exclude_pattern,
    }

    result = await handle_crawl_website(arguments, ctx=ctx)
    return _parse_result(result)


@server.tool()
async def extract_structured(
    url: str,
    schema: dict[str, str],
    multiple: bool = True,
    output_format: str = "json",
    ctx: Context | None = None,
) -> dict:
    """
    STRUCTURED DATA EXTRACTION: Extract specific fields from a webpage using a schema.

    Use this whenever you need to extract multiple items with specific fields.
    Examples: extract products, job listings, articles, listings, etc.

    Returns raw page content (text, html, images, links) for the LLM to intelligently
    extract and format as the desired output format (JSON, CSV, Markdown, HTML, YAML, XML, or text).

    Args:
        url: URL to extract from
        schema: Field definitions to extract (e.g., {"name": "product name", "price": "price in USD", "image": "product image"})
        multiple: Extract multiple items as array (default: true)
        output_format: Desired output format - json, csv, markdown, html, yaml, xml, text (default: json)
    """
    logger.info(
        f"[extract_structured] Called with URL: {url}, format: {output_format}, ctx: {ctx is not None}"
    )
    result = await handle_extract_structured(
        {"url": url, "schema": schema, "multiple": multiple, "output_format": output_format},
        ctx=ctx,
    )
    return _parse_result(result)


# =============================================================================
# Twitter Tools
# =============================================================================


@server.tool()
async def fetch_tweet(
    url: str,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch a single tweet's text content, engagement stats, and author info from a Twitter/X URL.

    Use this when the user wants to read a tweet, see its likes/retweets/replies, or get
    the author's info. Returns tweet text, media URLs, engagement metrics, and author data.

    This tool returns tweet DATA (text, stats, media references). For downloading the actual
    video file from a tweet, use download_video. For transcribing speech from a tweet video,
    use transcribe_video. For getting images, use download_image.

    No Twitter credentials required — credentials only improve reliability.
    """
    logger.info(f"[fetch_tweet] URL: {url}")
    result = await handle_fetch_tweet({"url": url})
    return _parse_result(result)


@server.tool()
async def twitter_user_info(
    screen_name: str,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch a Twitter/X user's profile information.

    Returns profile data including display name, bio, follower/following counts,
    verification status, and profile images. Uses FxTwitter API — no credentials needed.
    """
    logger.info(f"[twitter_user_info] screen_name: {screen_name}")
    result = await handle_twitter_user_info({"screen_name": screen_name})
    return _parse_result(result)


@server.tool()
async def twitter_search(
    query: str,
    filter: str = "top",
    next_page_token: str | None = None,
    ctx: Context | None = None,
) -> dict:
    """
    Search Twitter/X for tweets matching a query.

    Requires Twitter credentials (auth_token + ct0) saved via API or dashboard.
    Supports pagination with next_page_token from previous responses.

    Args:
        query: Search query string
        filter: Result filter — top (default), live, user, media, or list
        next_page_token: Pagination cursor from previous search response
    """
    logger.info(f"[twitter_search] query: {query}, filter: {filter}")
    args: dict = {"query": query, "filter": filter}
    if next_page_token:
        args["next_page_token"] = next_page_token
    result = await handle_twitter_search(args)
    return _parse_result(result)


@server.tool()
async def twitter_trending(
    global_trending: bool = False,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch trending topics on Twitter/X.

    Requires Twitter credentials (auth_token + ct0) saved via API or dashboard.

    Args:
        global_trending: If false (default), returns local/regional trend names only.
                        If true, returns global trending tweets with full content.
    """
    logger.info(f"[twitter_trending] global: {global_trending}")
    result = await handle_twitter_trending({"global_trending": global_trending})
    return _parse_result(result)


@server.tool()
async def twitter_news(
    ctx: Context | None = None,
) -> dict:
    """
    Fetch the Twitter/X news timeline.

    Returns current news stories as shown in Twitter's news section.
    Requires Twitter credentials (auth_token + ct0) saved via API or dashboard.
    """
    logger.info("[twitter_news] Fetching news timeline")
    result = await handle_twitter_news({})
    return _parse_result(result)


@server.tool()
async def twitter_for_you(
    ctx: Context | None = None,
) -> dict:
    """
    Fetch the Twitter/X "For You" explore timeline.

    Returns algorithmically curated content from the Explore page.
    Requires Twitter credentials (auth_token + ct0) saved via API or dashboard.
    """
    logger.info("[twitter_for_you] Fetching explore timeline")
    result = await handle_twitter_for_you({})
    return _parse_result(result)


@server.tool()
async def twitter_home_timeline(
    tab: str = "for_you",
    ctx: Context | None = None,
) -> dict:
    """
    Fetch the Twitter/X home timeline.

    Returns the authenticated user's home feed. Requires Twitter credentials
    (auth_token + ct0) saved via API or dashboard.

    Args:
        tab: Timeline tab — "for_you" (default) or "following"
    """
    logger.info(f"[twitter_home_timeline] tab: {tab}")
    result = await handle_twitter_home_timeline({"tab": tab})
    return _parse_result(result)


# =============================================================================
# Hacker News Tools
# =============================================================================


@server.tool()
async def hn_story(
    story_id: int,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch a single Hacker News story by its ID.

    Returns the story's title, URL, text (for Ask/Show HN), points, author,
    comment count, and timestamps. Use this when you have a specific story ID
    and want its full details.

    NOTE: Many HN stories are discussion-only posts (Ask HN, Show HN, polls)
    with no external URL — the value is in the comments. If a story has a high
    comment count or no URL, follow up with hn_comments to get the discussion.

    No credentials required.
    """
    logger.info(f"[hn_story] story_id: {story_id}")
    result = await handle_hn_story({"story_id": story_id})
    return _parse_result(result)


@server.tool()
async def hn_ranked_stories(
    feed: str = "top",
    date: str | None = None,
    points_min: int | None = None,
    limit: int = 30,
    next_cursor: str | None = None,
    ctx: Context | None = None,
) -> dict:
    """
    The default tool for "top HN stories", "Show HN", "Ask HN", "trending",
    and "front page" queries. Many stories returned are discussion posts
    (just a title, no external URL) where the real content lives in the
    comments — use hn_comments with the story_id to read those discussions.
    Shows stories ranked by position as they appear on the actual HN site.
    Also the only tool that supports historical dates via the date param
    (e.g., "trending last Monday", "front page on 2026-01-15").

    Args:
        feed:
              - top: Front page ranked stories (default)
              - newest: All stories by submission time, most recent first
              - show: Show HN — ranked interactive projects
              - ask: Ask HN — ranked community questions and discussions
                where users ask for advice, opinions, or recommendations
                (e.g., "best resources for X?", "what are you working on?")
              - active: Stories with the most recent comment activity
              - classic: Stories upvoted by long-time HN users
              - launches: Launch HN — YC startup announcements
              - invited: Editor-invited submissions
              - pool: Community pool stories
              - noobstories: Submissions from new HN accounts
              - over: Stories above a points threshold — must be used with
                points_min (e.g., feed="over", points_min=200 returns stories
                with 200+ points)
        date: Fetch ranked stories from a past date (YYYY-MM-DD). Works with
              any feed. Defaults to today.
        points_min: Minimum points filter. Required when feed="over", optional
                    for other feeds.
        limit: Number of stories (default 30)
        next_cursor: Pagination cursor from previous response
    """
    logger.info(f"[hn_ranked_stories] feed: {feed}, limit: {limit}")
    args: dict = {"feed": feed, "limit": limit}
    if date:
        args["date"] = date
    if points_min is not None:
        args["points_min"] = points_min
    if next_cursor:
        args["next_cursor"] = next_cursor
    result = await handle_hn_ranked_stories(args)
    return _parse_result(result)


@server.tool()
async def hn_domain_stories(
    site: str,
    limit: int = 30,
    next_cursor: str | None = None,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch all HN stories submitted from a specific domain.
    Shows every story linking to that domain, sorted by recency.
    Examples: "HN stories from github.com", "posts from arxiv.org",
    "what has been posted from nytimes.com".

    Args:
        site: Domain name (e.g., "github.com", "arxiv.org")
        limit: Number of stories (default 30)
        next_cursor: Pagination cursor from previous response
    """
    logger.info(f"[hn_domain_stories] site: {site}, limit: {limit}")
    args: dict = {"site": site, "limit": limit}
    if next_cursor:
        args["next_cursor"] = next_cursor
    result = await handle_hn_domain_stories(args)
    return _parse_result(result)


@server.tool()
async def hn_latest_stories(
    feed: str = "top",
    limit: int = 30,
    offset: int = 0,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch HN stories sorted by creation time (newest first).
    Only use when the user explicitly asks for "latest", "newest", or
    "recent" stories. Also the only tool for job posts and polls.

    Args:
        feed:
              - top: Stories sorted by submission time, newest first (default)
              - new: Brand new stories, just submitted
              - show: Show HN — newest project demos first
              - ask: Ask HN — newest community questions first
              - job: Job posts from YC companies
              - polls: Community polls
        limit: Number of stories (default 30)
        offset: Pagination offset (default 0)
    """
    logger.info(f"[hn_latest_stories] feed: {feed}, limit: {limit}")
    result = await handle_hn_latest_stories({"feed": feed, "limit": limit, "offset": offset})
    return _parse_result(result)


@server.tool()
async def hn_best_stories(
    hours: int = 24,
    limit: int = 30,
    next_cursor: str | None = None,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch the most upvoted HN stories within a time window.
    Use for any query containing "best", "most upvoted", or "highest voted"
    — including combined queries like "best Ask HN", "best Show HN this week",
    "most upvoted stories today". Covers all story types via the hours param.

    Args:
        hours: How far back to look, in hours (default 24). Use 168 for
               a week, 720 for a month.
        limit: Number of stories (default 30)
        next_cursor: Pagination cursor from previous response
    """
    logger.info(f"[hn_best_stories] hours: {hours}, limit: {limit}")
    args: dict = {"hours": hours, "limit": limit}
    if next_cursor:
        args["next_cursor"] = next_cursor
    result = await handle_hn_best_stories(args)
    return _parse_result(result)


@server.tool()
async def hn_search(
    query: str,
    tags: str | None = None,
    sort: str = "relevance",
    points_min: int | None = None,
    comments_min: int | None = None,
    date_from: str | None = None,
    date_to: str | None = None,
    author: str | None = None,
    limit: int = 30,
    page: int = 0,
    ctx: Context | None = None,
) -> dict:
    """
    Search Hacker News for stories or comments by keyword.
    This is a LAST RESORT — always check if a more specific tool fits first:
    - "top", "front page", "trending" → hn_ranked_stories
    - "latest", "newest", "recent" → hn_latest_stories
    - "best", "most upvoted" → hn_best_stories
    - a domain name (github.com, etc.) → hn_domain_stories
    - "hiring", "jobs", "who is hiring" → hn_who_is_hiring
    - a specific user's posts → hn_user_submissions or hn_user_activity
    Only use hn_search when none of the above apply and the user wants
    a free-text keyword search.

    Args:
        query: Search query string
        tags: Narrow results to a specific type:
              - story: Only stories (links and text posts)
              - comment: Only comments
              - ask_hn: Only Ask HN posts (text-only community questions)
              - show_hn: Only Show HN posts
              - front_page: Only stories that reached the front page
        sort: Sort order — relevance (default) or date
        points_min: Minimum points threshold (optional)
        comments_min: Minimum comment count (optional)
        date_from: Start date in YYYY-MM-DD format (optional)
        date_to: End date in YYYY-MM-DD format (optional)
        author: Filter by HN username (optional)
        limit: Number of results (default 30)
        page: Pagination page number (default 0)
    """
    logger.info(f"[hn_search] query: {query}, sort: {sort}")
    args: dict = {"query": query, "sort": sort, "limit": limit, "page": page}
    if tags:
        args["tags"] = tags
    if points_min is not None:
        args["points_min"] = points_min
    if comments_min is not None:
        args["comments_min"] = comments_min
    if date_from:
        args["date_from"] = date_from
    if date_to:
        args["date_to"] = date_to
    if author:
        args["author"] = author
    result = await handle_hn_search(args)
    return _parse_result(result)


@server.tool()
async def hn_comments(
    story_id: int,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch the full comment tree for any HN story by its ID from the responses.
    Returns all comments with nested replies, author, and timestamps.
    Works with any story type — regular stories, Ask HN, Show HN,
    and Who Is Hiring threads (where each comment is a job posting).

    IMPORTANT: Many HN stories are discussion-only (no external URL) — the
    comments ARE the content. Always use this tool when a story has a high
    comment count or is a text post (Ask HN, Show HN, Who Is Hiring).
    For Who Is Hiring threads, each top-level comment is an individual job
    posting with company, role, and details.

    Store in JSON if the result is too large.

    Args:
        story_id: HN story ID to fetch comments for
    """
    logger.info(f"[hn_comments] story_id: {story_id}")
    result = await handle_hn_comments({"story_id": story_id})
    return _parse_result(result)


@server.tool()
async def hn_comment_feed(
    feed: str = "bestcomments",
    hours: int | None = None,
    limit: int = 30,
    next_cursor: str | None = None,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch HN comment feeds — browse comments across all stories.
    Use this when the user wants to see interesting comments site-wide,
    not comments on a specific story (use hn_comments for that).

    Args:
        feed:
              - bestcomments: Highest-quality comments (default)
              - newcomments: Most recent comments
              - noobcomments: Comments from new HN accounts
              - highlights: Editorially highlighted comments
        hours: Time window in hours (bestcomments only, optional)
        limit: Number of comments (default 30)
        next_cursor: Pagination cursor from previous response
    """
    logger.info(f"[hn_comment_feed] feed: {feed}")
    args: dict = {"feed": feed, "limit": limit}
    if hours is not None:
        args["hours"] = hours
    if next_cursor:
        args["next_cursor"] = next_cursor
    result = await handle_hn_comment_feed(args)
    return _parse_result(result)


@server.tool()
async def hn_who_is_hiring(
    thread_type: str | None = None,
    month_from: str | None = None,
    month_to: str | None = None,
    limit: int = 30,
    next_cursor: str | None = None,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch HN "Who Is Hiring" monthly threads.
    Use for any query about hiring, jobs, or freelancing on HN — e.g.,
    "who is hiring", "HN jobs this month", "freelancer threads".

    IMPORTANT: This returns thread metadata (title, story_id, date) — NOT the
    actual job postings. Each thread's job postings are individual comments.
    You MUST follow up with hn_comments using the thread's story_id to get
    the actual job listings, candidate posts, or freelancer ads.

    Args:
        thread_type:
              - all: All thread types (default)
              - hiring: "Who is hiring?" — companies posting jobs
              - hired: "Who wants to be hired?" — candidates seeking work
              - freelancer: Freelancer/contractor threads
        month_from: Start month (YYYY-MM), e.g. "2026-03"
        month_to: End month (YYYY-MM) for a range. If omitted, only
                  month_from is used.
        limit: Number of threads (default 30)
        next_cursor: Pagination cursor from previous response
    """
    logger.info(f"[hn_who_is_hiring] type: {thread_type}")
    args: dict = {"limit": limit}
    if thread_type:
        args["thread_type"] = thread_type
    if month_from:
        args["month_from"] = month_from
    if month_to:
        args["month_to"] = month_to
    if next_cursor:
        args["next_cursor"] = next_cursor
    result = await handle_hn_who_is_hiring(args)
    return _parse_result(result)


@server.tool()
async def hn_leaders(
    ctx: Context | None = None,
) -> dict:
    """
    Fetch the top 100 HN users by karma.
    Returns username, rank, and profile URL for each leader.
    """
    logger.info("[hn_leaders] Fetching karma leaders")
    result = await handle_hn_leaders({})
    return _parse_result(result)


# =============================================================================
# Hacker News User Tools
# =============================================================================


@server.tool()
async def hn_user(
    username: str,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch a Hacker News user's profile only — karma, about text, and
    account creation date. Does NOT include stories, comments, threads,
    or favorites — use hn_user_submissions, hn_user_threads,
    hn_user_favorites, or hn_user_activity for those. Call multiple
    tools if the user asks for more than just the profile.

    Args:
        username: HN username (e.g., "pg", "dang")
    """
    logger.info(f"[hn_user] username: {username}")
    result = await handle_hn_user({"username": username})
    return _parse_result(result)


@server.tool()
async def hn_user_submissions(
    username: str,
    limit: int = 30,
    next_cursor: str | None = None,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch stories submitted by a specific HN user.

    Args:
        username: HN username
        limit: Number of stories (default 30)
        next_cursor: Pagination cursor from previous response
    """
    logger.info(f"[hn_user_submissions] username: {username}")
    args: dict = {"username": username, "limit": limit}
    if next_cursor:
        args["next_cursor"] = next_cursor
    result = await handle_hn_user_submissions(args)
    return _parse_result(result)


@server.tool()
async def hn_user_threads(
    username: str,
    limit: int = 30,
    next_cursor: str | None = None,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch a user's comment threads on HN.
    Returns comments the user has made, with story context.

    Args:
        username: HN username
        limit: Number of comments (default 30)
        next_cursor: Pagination cursor from previous response
    """
    logger.info(f"[hn_user_threads] username: {username}")
    args: dict = {"username": username, "limit": limit}
    if next_cursor:
        args["next_cursor"] = next_cursor
    result = await handle_hn_user_threads(args)
    return _parse_result(result)


@server.tool()
async def hn_user_favorites(
    username: str,
    type: str = "stories",
    limit: int = 30,
    next_cursor: str | None = None,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch a user's favorited stories or comments on HN.

    Args:
        username: HN username
        type: What to fetch — "stories" (default) or "comments"
        limit: Number of items (default 30)
        next_cursor: Pagination cursor from previous response
    """
    logger.info(f"[hn_user_favorites] username: {username}, type: {type}")
    args: dict = {"username": username, "type": type, "limit": limit}
    if next_cursor:
        args["next_cursor"] = next_cursor
    result = await handle_hn_user_favorites(args)
    return _parse_result(result)


@server.tool()
async def hn_user_activity(
    username: str,
    type: str = "all",
    sort: str = "date",
    limit: int = 25,
    page: int = 0,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch a user's full activity — submissions, comments, or both.
    Use this for a combined view of everything a user has done on HN.

    Args:
        username: HN username
        type: Activity type — "all" (default), "stories", or "comments"
        sort: Sort order — "date" (default) or "relevance"
        limit: Number of items (default 25)
        page: Pagination page number (default 0)
    """
    logger.info(f"[hn_user_activity] username: {username}, type: {type}")
    result = await handle_hn_user_activity({
        "username": username, "type": type, "sort": sort, "limit": limit, "page": page,
    })
    return _parse_result(result)


# =============================================================================
# YC Company Tools
# =============================================================================


@server.tool()
async def hn_companies_search(
    query: str = "",
    batch: str | None = None,
    industry: str | None = None,
    tag: str | None = None,
    region: str | None = None,
    status: str | None = None,
    is_hiring: bool | None = None,
    top_company: bool | None = None,
    nonprofit: bool | None = None,
    limit: int = 20,
    page: int = 0,
    ctx: Context | None = None,
) -> dict:
    """
    Search YC companies (startups, not people).
    Use when the user asks about companies, startups, or products.
    For people/founders, use hn_founders_search instead.

    Args:
        query: Search query (optional, empty returns all)
        batch: Filter by YC batch (e.g., "Winter 2026")
        industry: Filter by industry (e.g., "B2B", "Fintech")
        tag: Filter by tag (e.g., "SaaS", "AI")
        region: Filter by region (e.g., "Remote", "Europe")
        status: Filter by status — Active, Inactive, Acquired, Public
        is_hiring: Filter companies currently hiring (true/false)
        top_company: Filter top YC companies only (true/false)
        nonprofit: Filter nonprofit companies (true/false)
        limit: Results per page (default 20)
        page: Page number (default 0)
    """
    logger.info(f"[hn_companies_search] query: {query}")
    args: dict = {"query": query, "limit": limit, "page": page}
    if batch:
        args["batch"] = batch
    if industry:
        args["industry"] = industry
    if tag:
        args["tag"] = tag
    if region:
        args["region"] = region
    if status:
        args["status"] = status
    if is_hiring is not None:
        args["is_hiring"] = is_hiring
    if top_company is not None:
        args["top_company"] = top_company
    if nonprofit is not None:
        args["nonprofit"] = nonprofit
    result = await handle_hn_companies_search(args)
    return _parse_result(result)


@server.tool()
async def hn_company(
    url: str,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch a YC startup company page with full details.
    Returns company info, founders, jobs, news, and launches.

    Args:
        url: YC company URL (e.g., "https://www.ycombinator.com/companies/airbnb")
    """
    logger.info(f"[hn_company] url: {url}")
    result = await handle_hn_company({"url": url})
    return _parse_result(result)


@server.tool()
async def hn_startup_jobs(
    role: str | None = None,
    location: str | None = None,
    limit: int = 50,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch YC startup job listings with optional filters.

    Args:
        role: Filter by role — engineering, design, product, science,
              sales, marketing, support, operations, recruiting, finance, legal
        location: Filter by location — san-francisco, new-york, los-angeles,
                  seattle, austin, boston, chicago, india, remote
        limit: Max results (default 50)
    """
    logger.info(f"[hn_startup_jobs] role: {role}, location: {location}")
    args: dict = {"limit": limit}
    if role:
        args["role"] = role
    if location:
        args["location"] = location
    result = await handle_hn_startup_jobs(args)
    return _parse_result(result)


@server.tool()
async def hn_startup_job_detail(
    url: str,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch full details for a single YC startup job.
    Returns job description, requirements, salary, equity, and company info.

    Args:
        url: YC job URL (e.g., "https://www.ycombinator.com/companies/company/jobs/id-title")
    """
    logger.info(f"[hn_startup_job_detail] url: {url}")
    result = await handle_hn_startup_job_detail({"url": url})
    return _parse_result(result)


# =============================================================================
# YC Founder Tools
# =============================================================================


@server.tool()
async def hn_founders_search(
    query: str = "",
    batch: str | None = None,
    industry: str | None = None,
    region: str | None = None,
    title: str | None = None,
    top_company: bool | None = None,
    limit: int = 20,
    page: int = 0,
    ctx: Context | None = None,
) -> dict:
    """
    Search YC founders (people, not companies).
    Use when the user asks about founders, people, CEOs, CTOs behind startups.
    For companies/startups, use hn_companies_search instead.

    Args:
        query: Search by name (optional, empty returns all)
        batch: Filter by batch code (e.g., "W26", "S25")
        industry: Filter by industry (e.g., "B2B", "Fintech")
        region: Filter by region (e.g., "United States of America", "India")
        title: Filter by title (e.g., "CEO", "CTO")
        top_company: Filter founders from top YC companies (true/false)
        limit: Results per page (default 20)
        page: Page number (default 0)
    """
    logger.info(f"[hn_founders_search] query: {query}")
    args: dict = {"query": query, "limit": limit, "page": page}
    if batch:
        args["batch"] = batch
    if industry:
        args["industry"] = industry
    if region:
        args["region"] = region
    if title:
        args["title"] = title
    if top_company is not None:
        args["top_company"] = top_company
    result = await handle_hn_founders_search(args)
    return _parse_result(result)


# =============================================================================
# YC Launch Tools
# =============================================================================


@server.tool()
async def hn_launches_search(
    query: str = "",
    sort: str = "relevance",
    batch: str | None = None,
    industry: str | None = None,
    tag: str | None = None,
    limit: int = 20,
    page: int = 0,
    ctx: Context | None = None,
) -> dict:
    """
    Search YC Launch HN posts.
    Browse startup launch announcements with filters.

    Args:
        query: Search query (optional, empty returns all)
        sort: Sort by — "relevance" (votes, default) or "date"
        batch: Filter by batch (e.g., "Fall 2025", "Winter 2026")
        industry: Filter by industry (e.g., "B2B", "Healthcare")
        tag: Filter by tag (e.g., "AI", "SaaS")
        limit: Results per page (default 20)
        page: Page number (default 0)
    """
    logger.info(f"[hn_launches_search] query: {query}")
    args: dict = {"query": query, "sort": sort, "limit": limit, "page": page}
    if batch:
        args["batch"] = batch
    if industry:
        args["industry"] = industry
    if tag:
        args["tag"] = tag
    result = await handle_hn_launches_search(args)
    return _parse_result(result)


@server.tool()
async def hn_launch_detail(
    url: str,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch full details for a single YC Launch HN post.
    Returns launch content, company info, and tags.

    Args:
        url: YC launch URL (e.g., "https://www.ycombinator.com/launches/xxx-company-name")
    """
    logger.info(f"[hn_launch_detail] url: {url}")
    result = await handle_hn_launch_detail({"url": url})
    return _parse_result(result)


# =============================================================================
# Google Play Store Tools
# =============================================================================
# Use playstore_* tools for Android/Google Play. Use appstore_* for iOS/Apple.
# When the user doesn't specify a platform, use BOTH to cover Android and iOS.
# =============================================================================


@server.tool()
async def playstore_app(
    package_id: str,
    hl: str = "en",
    gl: str = "us",
    ctx: Context | None = None,
) -> dict:
    """
    Fetch full details for an Android app from Google Play Store.

    Returns name, description, developer info, rating, downloads, screenshots,
    price, content rating, and similar apps. No credentials needed.

    Workflow: Use playstore_search or playstore_charts to discover package IDs,
    then pass them here. Chain with playstore_reviews to get user reviews.

    Args:
        package_id: Android package ID (e.g. 'com.instagram.android')
        hl: Language code (e.g. 'en', 'de')
        gl: Country code (e.g. 'us', 'de')

    Returns key fields: package_id, title, developer, developer_id, rating,
    ratings_count, downloads, price, description, screenshots, genre.
    """
    logger.info(f"[playstore_app] package_id: {package_id}")
    result = await handle_playstore_app({"package_id": package_id, "hl": hl, "gl": gl})
    return _parse_result(result)


@server.tool()
async def playstore_search(
    query: str,
    limit: int | None = None,
    hl: str = "en",
    gl: str = "us",
    ctx: Context | None = None,
) -> dict:
    """
    Search Google Play Store apps by keyword.

    Returns matching apps with name, rating, developer, and package ID.
    No credentials needed.

    Workflow: Use the returned package_id to call playstore_app for full details,
    playstore_reviews for user reviews, or playstore_similar for competitors.

    Args:
        query: Search keywords (e.g. 'finance tracker', 'photo editor')
        limit: Max results (1-100, default: all)
        hl: Language code
        gl: Country code

    Returns key fields per app: package_id, title, developer, rating, icon.
    """
    logger.info(f"[playstore_search] query: {query}")
    args: dict = {"query": query, "hl": hl, "gl": gl}
    if limit is not None:
        args["limit"] = limit
    result = await handle_playstore_search(args)
    return _parse_result(result)


@server.tool()
async def playstore_reviews(
    package_id: str,
    sort: str = "newest",
    count: int = 40,
    filter_score: int | None = None,
    pagination_token: str | None = None,
    hl: str = "en",
    gl: str = "us",
    ctx: Context | None = None,
) -> dict:
    """
    Fetch user reviews for an Android app.

    Returns reviews with author, score, text, date, and developer replies.
    Supports pagination via next_page_token in response. No credentials needed.

    Workflow: First get package_id from playstore_search, playstore_charts,
    or playstore_category, then pass it here to fetch reviews.

    Args:
        package_id: Android package ID (e.g. 'com.instagram.android')
        sort: Sort order — newest (default), most_relevant, rating
        count: Number of reviews (1-500, default 40)
        filter_score: Filter by star rating (1-5, optional)
        pagination_token: Token from previous response for next page
        hl: Language code
        gl: Country code

    Returns key fields per review: author, score (1-5), text, date, reply_text,
    thumbs_up_count. Response includes next_page_token for pagination.
    """
    logger.info(f"[playstore_reviews] package_id: {package_id}")
    args: dict = {"package_id": package_id, "sort": sort, "count": count, "hl": hl, "gl": gl}
    if filter_score is not None:
        args["filter_score"] = filter_score
    if pagination_token:
        args["pagination_token"] = pagination_token
    result = await handle_playstore_reviews(args)
    return _parse_result(result)


@server.tool()
async def playstore_category(
    category: str,
    chart_type: str | None = None,
    limit: int | None = None,
    hl: str = "en",
    gl: str = "us",
    ctx: Context | None = None,
) -> dict:
    """
    Browse Google Play Store apps by category or fetch category-specific charts.

    Without chart_type: returns category page sections with recommended apps.
    With chart_type: returns ranked chart apps for that category.
    No credentials needed.

    Workflow: Use this to discover top apps in a category, then pass the returned
    package_id values to playstore_reviews for reviews or playstore_app for details.

    Args:
        category: Category slug in UPPERCASE. Valid values:
            Apps: ART_AND_DESIGN, AUTO_AND_VEHICLES, BEAUTY, BOOKS_AND_REFERENCE,
            BUSINESS, COMICS, COMMUNICATION, EDUCATION, ENTERTAINMENT, EVENTS,
            FINANCE, FOOD_AND_DRINK, HEALTH_AND_FITNESS, HOUSE_AND_HOME, LIFESTYLE,
            MAPS_AND_NAVIGATION, MUSIC_AND_AUDIO, NEWS_AND_MAGAZINES, PARENTING,
            PERSONALIZATION, PHOTOGRAPHY, PRODUCTIVITY, SHOPPING, SOCIAL, SPORTS,
            TOOLS, TRAVEL_AND_LOCAL, VIDEO_PLAYERS, WEATHER, FAMILY.
            Games: GAME, GAME_ACTION, GAME_ADVENTURE, GAME_ARCADE, GAME_BOARD,
            GAME_CARD, GAME_CASUAL, GAME_EDUCATIONAL, GAME_MUSIC, GAME_PUZZLE,
            GAME_RACING, GAME_ROLE_PLAYING, GAME_SIMULATION, GAME_SPORTS,
            GAME_STRATEGY, GAME_TRIVIA, GAME_WORD.
        chart_type: Optional chart — top_free, top_grossing, or top_paid
        limit: Max chart results (1-200, only used with chart_type)
        hl: Language code
        gl: Country code

    Returns key fields per app: package_id, title, developer, rating, icon.
    """
    logger.info(f"[playstore_category] category: {category}")
    args: dict = {"category": category, "hl": hl, "gl": gl}
    if chart_type:
        args["chart_type"] = chart_type
    if limit is not None:
        args["limit"] = limit
    result = await handle_playstore_category(args)
    return _parse_result(result)


@server.tool()
async def playstore_charts(
    chart_type: str = "top_free",
    limit: int | None = None,
    hl: str = "en",
    gl: str = "us",
    ctx: Context | None = None,
) -> dict:
    """
    Fetch global Google Play Store top charts (all categories combined).

    Returns ranked apps across all categories. For category-specific charts,
    use playstore_category with chart_type instead. No credentials needed.

    Workflow: Use the returned package_id values to call playstore_reviews for
    reviews or playstore_app for full app details.

    Args:
        chart_type: Chart to fetch — top_free (default), top_grossing, or top_paid
        limit: Max results (1-200, default 50)
        hl: Language code
        gl: Country code

    Returns key fields per app: package_id, title, developer, rating, icon.
    """
    logger.info(f"[playstore_charts] chart_type: {chart_type}")
    args: dict = {"chart_type": chart_type, "hl": hl, "gl": gl}
    if limit is not None:
        args["limit"] = limit
    result = await handle_playstore_charts(args)
    return _parse_result(result)


@server.tool()
async def playstore_developer(
    developer_id: str,
    limit: int | None = None,
    hl: str = "en",
    gl: str = "us",
    ctx: Context | None = None,
) -> dict:
    """
    Fetch all published apps by a Google Play Store developer.

    Accepts numeric ID ('5700313618786177705') or named ID ('WhatsApp LLC').
    Get the developer_id from a playstore_app response. No credentials needed.

    Workflow: Call playstore_app first to get developer_id, then use this tool
    to see all apps by that developer.

    Args:
        developer_id: Numeric or named developer ID
        limit: Max results (1-200, default: all)
        hl: Language code
        gl: Country code

    Returns key fields per app: package_id, title, rating, icon.
    """
    logger.info(f"[playstore_developer] developer_id: {developer_id}")
    args: dict = {"developer_id": developer_id, "hl": hl, "gl": gl}
    if limit is not None:
        args["limit"] = limit
    result = await handle_playstore_developer(args)
    return _parse_result(result)


@server.tool()
async def playstore_similar(
    package_id: str,
    limit: int | None = None,
    hl: str = "en",
    gl: str = "us",
    ctx: Context | None = None,
) -> dict:
    """
    Fetch similar apps and more-by-developer for a Google Play Store app.

    Returns structured app data (name, rating, developer) for competitor apps.
    Great for competitive analysis and lead generation. No credentials needed.

    Workflow: Get a package_id from playstore_search or playstore_charts, then
    pass it here. Chain with playstore_reviews on the results for competitor reviews.

    Args:
        package_id: Android package ID (e.g. 'com.instagram.android')
        limit: Max similar apps to return (1-50)
        hl: Language code
        gl: Country code

    Returns key fields per app: package_id, title, developer, rating, icon.
    """
    logger.info(f"[playstore_similar] package_id: {package_id}")
    args: dict = {"package_id": package_id, "hl": hl, "gl": gl}
    if limit is not None:
        args["limit"] = limit
    result = await handle_playstore_similar(args)
    return _parse_result(result)


@server.tool()
async def playstore_games(
    limit: int | None = None,
    hl: str = "en",
    gl: str = "us",
    ctx: Context | None = None,
) -> dict:
    """
    Fetch the Google Play Games explore page.

    Returns featured game sections with curated apps (Featured, Premium, etc.).
    No credentials needed. For specific game categories, use playstore_category
    with a GAME_* category slug instead.

    Workflow: Use the returned package_id values to call playstore_reviews
    for reviews or playstore_app for full details.

    Args:
        limit: Max apps per section (1-100, applies to all sections)
        hl: Language code
        gl: Country code

    Returns sections, each with a list of apps containing: package_id, title,
    developer, rating, icon.
    """
    logger.info("[playstore_games] Fetching games explore")
    args: dict = {"hl": hl, "gl": gl}
    if limit is not None:
        args["limit"] = limit
    result = await handle_playstore_games(args)
    return _parse_result(result)


@server.tool()
async def playstore_device(
    device: str,
    limit: int | None = None,
    hl: str = "en",
    gl: str = "us",
    ctx: Context | None = None,
) -> dict:
    """
    Fetch Google Play Store apps filtered by device type.

    Returns app sections specific to a device form factor.
    No credentials needed.

    Workflow: Use the returned package_id values to call playstore_reviews
    for reviews or playstore_app for full details.

    Args:
        device: Device type — phone, tablet, tv, watch, car, chromebook, or xr
        limit: Max apps per section (1-100, applies to all sections)
        hl: Language code
        gl: Country code

    Returns sections, each with a list of apps containing: package_id, title,
    developer, rating, icon.
    """
    logger.info(f"[playstore_device] device: {device}")
    args: dict = {"device": device, "hl": hl, "gl": gl}
    if limit is not None:
        args["limit"] = limit
    result = await handle_playstore_device(args)
    return _parse_result(result)


# =============================================================================
# Apple App Store Tools
# =============================================================================
# Use appstore_* tools for iOS/Apple App Store. Use playstore_* for Android.
# When the user doesn't specify a platform, use BOTH to cover iOS and Android.
# =============================================================================


@server.tool()
async def appstore_app(
    app_id: str,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch full details for an iOS app from the Apple App Store.

    Returns name, description, developer, rating, price, screenshots, version,
    release notes, and content rating. Accepts a numeric track ID (e.g. '389801252')
    or bundle ID (e.g. 'com.burbn.instagram'). No credentials needed.

    Workflow: Use appstore_search or appstore_charts to discover app IDs,
    then pass them here. Chain with appstore_reviews to get user reviews.

    Args:
        app_id: Track ID (numeric) or bundle ID

    Returns key fields: track_id, bundle_id, title, developer, developer_id,
    rating, ratings_count, price, description, screenshots, genres.
    """
    logger.info(f"[appstore_app] app_id: {app_id}")
    result = await handle_appstore_app({"app_id": app_id})
    return _parse_result(result)


@server.tool()
async def appstore_search(
    query: str,
    limit: int = 20,
    country: str = "us",
    ctx: Context | None = None,
) -> dict:
    """
    Search Apple App Store apps by keyword.

    Returns matching apps with name, rating, developer, and app ID.
    No credentials needed.

    Workflow: Use the returned track_id to call appstore_app for full details,
    appstore_reviews for user reviews, or appstore_ratings for rating breakdown.

    Args:
        query: Search keywords (e.g. 'finance tracker', 'photo editor')
        limit: Max results (1-200, default 20)
        country: Country code (e.g. 'us', 'gb', 'de')

    Returns key fields per app: track_id, bundle_id, title, developer,
    developer_id, rating, price, icon.
    """
    logger.info(f"[appstore_search] query: {query}")
    result = await handle_appstore_search({"query": query, "limit": limit, "country": country})
    return _parse_result(result)


@server.tool()
async def appstore_charts(
    chart_type: str = "top_free",
    genre: str | None = None,
    limit: int = 20,
    country: str = "us",
    ctx: Context | None = None,
) -> dict:
    """
    Fetch Apple App Store top charts by genre and country.

    Returns ranked apps for the specified chart. No credentials needed.

    Workflow: Use the returned track_id values to call appstore_reviews for
    reviews, appstore_app for full details, or appstore_bulk for batch lookup.

    Args:
        chart_type: Chart type. Valid values: top_free (default), top_paid,
            top_grossing, new_free, new_paid, top_free_ipad, top_paid_ipad,
            top_grossing_ipad, new_apps, top_overall.
        genre: Genre filter. Valid values: BOOKS, BUSINESS, DEVELOPER_TOOLS,
            EDUCATION, ENTERTAINMENT, FINANCE, FOOD_DRINK, GAMES,
            GRAPHICS_DESIGN, HEALTH_FITNESS, LIFESTYLE, MAGAZINES_NEWSPAPERS,
            MEDICAL, MUSIC, NAVIGATION, NEWS, PHOTO_VIDEO, PRODUCTIVITY,
            REFERENCE, SHOPPING, SOCIAL_NETWORKING, SPORTS, TRAVEL,
            UTILITIES, WEATHER. Omit for all genres.
        limit: Max results (1-100, default 20)
        country: Country code (e.g. 'us', 'gb', 'de')

    Returns key fields per app: track_id, title, developer, rating, icon.
    """
    logger.info(f"[appstore_charts] chart_type: {chart_type}")
    args: dict = {"chart_type": chart_type, "limit": limit, "country": country}
    if genre:
        args["genre"] = genre
    result = await handle_appstore_charts(args)
    return _parse_result(result)


@server.tool()
async def appstore_reviews(
    app_id: str,
    sort: str = "most_recent",
    count: int = 20,
    offset: int = 0,
    country: str = "us",
    ctx: Context | None = None,
) -> dict:
    """
    Fetch user reviews for an iOS app.

    Returns reviews with author, title, text, score, and date.
    Supports pagination via offset. No credentials needed.

    Workflow: First get track_id from appstore_search, appstore_charts,
    or appstore_app, then pass it here to fetch reviews.

    Args:
        app_id: Track ID (numeric)
        sort: Sort order — most_recent (default), most_helpful, most_favorable, most_critical
        count: Number of reviews (1-500, default 20)
        offset: Pagination offset (default 0)
        country: Country code (e.g. 'us', 'gb', 'de')

    Returns key fields per review: author, title, text, score (1-5), date.
    Use offset + count for pagination.
    """
    logger.info(f"[appstore_reviews] app_id: {app_id}")
    result = await handle_appstore_reviews({
        "app_id": app_id, "sort": sort, "count": count, "offset": offset, "country": country,
    })
    return _parse_result(result)


@server.tool()
async def appstore_developer(
    developer_id: str,
    country: str = "us",
    ctx: Context | None = None,
) -> dict:
    """
    Fetch all published apps by an Apple App Store developer.

    Get the developer_id (artist ID) from an appstore_app response. No credentials needed.

    Workflow: Call appstore_app first to get developer_id, then use this tool
    to see all apps by that developer.

    Args:
        developer_id: Artist ID (numeric, e.g. '389801255')
        country: Country code (e.g. 'us', 'gb', 'de')

    Returns key fields per app: track_id, title, developer, rating, icon.
    """
    logger.info(f"[appstore_developer] developer_id: {developer_id}")
    result = await handle_appstore_developer({"developer_id": developer_id, "country": country})
    return _parse_result(result)


@server.tool()
async def appstore_privacy(
    app_id: str,
    country: str = "us",
    ctx: Context | None = None,
) -> dict:
    """
    Fetch privacy labels for an iOS app.

    Returns data categories collected, their purposes, and whether the app tracks users.
    Useful for compliance audits and competitor privacy analysis. No credentials needed.

    Workflow: Get track_id from appstore_search or appstore_charts, then pass it here.

    Args:
        app_id: Track ID (numeric)
        country: Country code (e.g. 'us', 'gb', 'de')

    Returns: privacy_details with data categories, purposes, and tracking status.
    """
    logger.info(f"[appstore_privacy] app_id: {app_id}")
    result = await handle_appstore_privacy({"app_id": app_id, "country": country})
    return _parse_result(result)


@server.tool()
async def appstore_ratings(
    app_id: str,
    country: str = "us",
    ctx: Context | None = None,
) -> dict:
    """
    Fetch rating breakdown with 5-star histogram for an iOS app.

    Returns overall rating, total count, and per-star counts (1-5).
    No credentials needed. For full text reviews, use appstore_reviews instead.

    Workflow: Get track_id from appstore_search or appstore_charts, then pass it here.

    Args:
        app_id: Track ID (numeric)
        country: Country code (e.g. 'us', 'gb', 'de')

    Returns: overall_rating, total_count, star_1 through star_5 counts.
    """
    logger.info(f"[appstore_ratings] app_id: {app_id}")
    result = await handle_appstore_ratings({"app_id": app_id, "country": country})
    return _parse_result(result)


@server.tool()
async def appstore_in_app_purchases(
    app_id: str,
    limit: int = 10,
    country: str = "us",
    ctx: Context | None = None,
) -> dict:
    """
    Fetch top in-app purchases for an iOS app.

    Returns IAP names, prices, and subscription details. Apple max: 10 per request.
    No credentials needed.

    Workflow: Get track_id from appstore_search or appstore_app, then pass it here
    to analyze monetization strategy.

    Args:
        app_id: Track ID (numeric)
        limit: Max IAPs (1-10, default 10)
        country: Country code (e.g. 'us', 'gb', 'de')

    Returns key fields per IAP: name, price, rank.
    """
    logger.info(f"[appstore_in_app_purchases] app_id: {app_id}")
    result = await handle_appstore_in_app_purchases({
        "app_id": app_id, "limit": limit, "country": country,
    })
    return _parse_result(result)


@server.tool()
async def appstore_bulk(
    app_ids: list[str],
    country: str = "us",
    ctx: Context | None = None,
) -> dict:
    """
    Bulk lookup multiple iOS apps by track IDs.

    Returns full details for up to 50 apps in a single request.
    More efficient than calling appstore_app repeatedly. No credentials needed.

    Workflow: Collect track_id values from appstore_charts or appstore_search,
    then pass them all here for efficient batch lookup.

    Args:
        app_ids: List of track IDs (max 50)
        country: Country code (e.g. 'us', 'gb', 'de')

    Returns: full app details for each ID (same fields as appstore_app).
    """
    logger.info(f"[appstore_bulk] {len(app_ids)} apps")
    result = await handle_appstore_bulk({"app_ids": app_ids, "country": country})
    return _parse_result(result)


# =============================================================================
# Reddit Tools
# =============================================================================


@server.tool()
async def reddit_post(
    url: str,
    include_comments: bool = True,
    comment_depth: int | None = None,
    comment_sort: str | None = None,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch a Reddit post with its comment tree.

    Returns post content, metadata, and optionally the full comment tree.
    No Reddit credentials needed for public posts.

    Args:
        url: Full Reddit post URL
        include_comments: Include comment tree (default: true)
        comment_depth: Max comment nesting depth (optional)
        comment_sort: Comment sort order — confidence, top, new, controversial, old, qa
    """
    logger.info(f"[reddit_post] URL: {url}")
    args: dict = {"url": url, "include_comments": include_comments}
    if comment_depth is not None:
        args["comment_depth"] = comment_depth
    if comment_sort:
        args["comment_sort"] = comment_sort
    result = await handle_reddit_post(args)
    return _parse_result(result)


@server.tool()
async def reddit_community(
    subreddit: str,
    sort: str = "hot",
    time_filter: str | None = None,
    limit: int = 25,
    after: str | None = None,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch posts from a subreddit.

    Returns a listing of posts with titles, scores, comment counts, and content.
    Supports sorting and pagination. No Reddit credentials needed.

    Args:
        subreddit: Subreddit name without r/ prefix (e.g., "technology")
        sort: Sort order — best, hot (default), new, top, rising
        time_filter: Time range for "top" sort — hour, day, week, month, year, all
        limit: Number of posts to return (max 100, default 25)
        after: Pagination cursor from previous response
    """
    logger.info(f"[reddit_community] r/{subreddit}, sort: {sort}")
    args: dict = {"subreddit": subreddit, "sort": sort, "limit": limit}
    if time_filter:
        args["time_filter"] = time_filter
    if after:
        args["after"] = after
    result = await handle_reddit_community(args)
    return _parse_result(result)


@server.tool()
async def reddit_about(
    subreddit: str,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch subreddit metadata and information.

    Returns subscriber count, description, rules, creation date, and other metadata.
    No Reddit credentials needed.

    Args:
        subreddit: Subreddit name without r/ prefix (e.g., "technology")
    """
    logger.info(f"[reddit_about] r/{subreddit}")
    result = await handle_reddit_about({"subreddit": subreddit})
    return _parse_result(result)


@server.tool()
async def reddit_search(
    query: str,
    category: str = "posts",
    subreddit: str | None = None,
    sort: str = "relevance",
    time_filter: str | None = None,
    limit: int = 25,
    after: str | None = None,
    ctx: Context | None = None,
) -> dict:
    """
    Search across Reddit for posts, communities, comments, people, or media.

    Supports global search or scoped to a specific subreddit.
    No Reddit credentials needed.

    Args:
        query: Search query string
        category: Search category — posts (default), communities, comments, people, media
        subreddit: Limit search to this subreddit (optional)
        sort: Sort order — relevance (default), hot, top, new, comments
        time_filter: Time range for "top" sort — hour, day, week, month, year, all
        limit: Number of results (max 100, default 25)
        after: Pagination cursor from previous response
    """
    logger.info(f"[reddit_search] query: {query}, category: {category}")
    args: dict = {"query": query, "category": category, "sort": sort, "limit": limit}
    if subreddit:
        args["subreddit"] = subreddit
    if time_filter:
        args["time_filter"] = time_filter
    if after:
        args["after"] = after
    result = await handle_reddit_search(args)
    return _parse_result(result)


@server.tool()
async def reddit_explore(
    category: str = "popular",
    limit: int = 25,
    after: str | None = None,
    ctx: Context | None = None,
) -> dict:
    """
    Discover subreddits by category.

    Browse popular, new, or default subreddits. No Reddit credentials needed.

    Args:
        category: Discovery category — popular (default), new, default
        limit: Number of subreddits to return (max 100, default 25)
        after: Pagination cursor from previous response
    """
    logger.info(f"[reddit_explore] category: {category}")
    args: dict = {"category": category, "limit": limit}
    if after:
        args["after"] = after
    result = await handle_reddit_explore(args)
    return _parse_result(result)


@server.tool()
async def reddit_popular(
    sort: str = "hot",
    time_filter: str | None = None,
    geo_filter: str | None = None,
    limit: int = 25,
    after: str | None = None,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch trending posts across all of Reddit.

    Returns popular posts site-wide with optional geographic filtering.
    No Reddit credentials needed.

    Args:
        sort: Sort order — best, hot (default), new, top, rising
        time_filter: Time range for "top" sort — hour, day, week, month, year, all
        geo_filter: Country code for regional trending (e.g., "US", "GB", "DE")
        limit: Number of posts (max 100, default 25)
        after: Pagination cursor from previous response
    """
    logger.info(f"[reddit_popular] sort: {sort}, geo: {geo_filter}")
    args: dict = {"sort": sort, "limit": limit}
    if time_filter:
        args["time_filter"] = time_filter
    if geo_filter:
        args["geo_filter"] = geo_filter
    if after:
        args["after"] = after
    result = await handle_reddit_popular(args)
    return _parse_result(result)


@server.tool()
async def reddit_feed(
    feed: str = "home",
    sort: str | None = None,
    time_filter: str | None = None,
    use_cookies: bool = False,
    limit: int = 25,
    after: str | None = None,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch a Reddit feed (home or news).

    Without credentials, returns generic public content. With credentials
    (use_cookies=true), returns personalized content from subscribed subreddits.
    News feed is only available with credentials.

    Save Reddit credentials first via API: POST /api/subreddit/credentials

    Args:
        feed: Feed type — "home" (default) or "news"
        sort: Sort order — best, hot, new, top, rising (optional)
        time_filter: Time range for "top" sort — hour, day, week, month, year, all
        use_cookies: Use saved Reddit credentials for personalized feed (default: false)
        limit: Number of posts (max 100, default 25)
        after: Pagination cursor from previous response
    """
    logger.info(f"[reddit_feed] feed: {feed}, cookies: {use_cookies}")
    args: dict = {"feed": feed, "use_cookies": use_cookies, "limit": limit}
    if sort:
        args["sort"] = sort
    if time_filter:
        args["time_filter"] = time_filter
    if after:
        args["after"] = after
    result = await handle_reddit_feed(args)
    return _parse_result(result)


# =============================================================================
# GitHub Tools
# =============================================================================


@server.tool()
async def github_repo(
    owner: str,
    repo: str,
    include: list[str] | None = None,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch full repository data — metadata, README, and/or language breakdown.

    This is the detail tool for any repo found via discovery tools (github_search_repos,
    github_trending, github_topic_repos). Those return summaries only — use this to get
    the full README, language breakdown, or detailed stats for a specific repo.

    Use `include` to pass ONLY what the user asks for:
    - "detail": repo stats (stars, forks, topics, license, etc.)
    - "readme": decoded README markdown
    - "languages": language breakdown (bytes + percentages)

    Only add "detail" when the user asks for general repo info/stats.
    If they only ask for README → ["readme"]. README + languages → ["readme", "languages"].

    Follow-up tools: github_releases (changelogs), github_contributors (who builds it),
    github_stargazers (who starred), github_forks (active forks),
    github_search_issues (bugs/PRs in this repo with repo="owner/name").

    Args:
        owner: Repository owner (user or org)
        repo: Repository name
        include: Requested data fields only (default: ["detail"])
    """
    logger.info(f"[github_repo] {owner}/{repo}")
    args: dict = {"owner": owner, "repo": repo}
    if include:
        args["include"] = include
    result = await handle_github_repo(args)
    return _parse_result(result)


@server.tool()
async def github_releases(
    owner: str,
    repo: str,
    per_page: int = 10,
    page: int = 1,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch repository release history with changelogs, tags, and downloadable assets.

    Use this after identifying a repo via github_repo, github_search_repos, github_trending,
    or github_topic_repos. Returns release tags, descriptions (changelogs), download assets
    with sizes, and author info. Sorted newest first.

    Typical chains: github_search_repos → github_repo → github_releases (version history),
    or github_trending → pick a repo → github_releases (what changed recently).

    Args:
        owner: Repository owner (user or org)
        repo: Repository name
        per_page: Results per page (1-100, default 10)
        page: Page number (default 1)
    """
    logger.info(f"[github_releases] {owner}/{repo}")
    args: dict = {"owner": owner, "repo": repo, "per_page": per_page, "page": page}
    result = await handle_github_releases(args)
    return _parse_result(result)


@server.tool()
async def github_forks(
    owner: str,
    repo: str,
    sort: str = "newest",
    per_page: int = 30,
    page: int = 1,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch repository forks with full repo data per fork.

    Use this after identifying a repo via github_repo, github_search_repos, github_trending,
    or github_topic_repos. Shows who forked a repo, active forks, or forks with the most stars.
    Each fork is a complete repository object with its own stats.

    Follow-up: use github_user on a fork owner to see their full profile, or github_repo on
    a fork to compare its README/languages against the original.

    Args:
        owner: Repository owner (user or org)
        repo: Repository name
        sort: Sort by — newest (default), oldest, stargazers, watchers
        per_page: Results per page (1-100, default 30)
        page: Page number (default 1)
    """
    logger.info(f"[github_forks] {owner}/{repo}")
    args: dict = {"owner": owner, "repo": repo, "sort": sort, "per_page": per_page, "page": page}
    result = await handle_github_forks(args)
    return _parse_result(result)


@server.tool()
async def github_stargazers(
    owner: str,
    repo: str,
    sort: str = "newest",
    per_page: int = 30,
    page: int = 1,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch repository stargazers with starred_at timestamps.

    Use this after identifying a repo via github_repo, github_search_repos, github_trending,
    or github_topic_repos. Shows who starred a repo and when — useful for tracking star growth
    or finding notable users interested in a project.

    Follow-up: use github_user on any stargazer username to see their full profile (bio,
    company, location), then github_user_repos or github_user_starred to explore their work.

    Args:
        owner: Repository owner (user or org)
        repo: Repository name
        sort: Sort order — newest (default) or oldest
        per_page: Results per page (1-100, default 30)
        page: Page number (default 1)
    """
    logger.info(f"[github_stargazers] {owner}/{repo}")
    args: dict = {"owner": owner, "repo": repo, "sort": sort, "per_page": per_page, "page": page}
    result = await handle_github_stargazers(args)
    return _parse_result(result)


@server.tool()
async def github_contributors(
    owner: str,
    repo: str,
    per_page: int = 30,
    page: int = 1,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch repository contributors ranked by commit count.

    Use this after identifying a repo via github_repo, github_search_repos, github_trending,
    or github_topic_repos. Returns usernames, avatars, and commit counts — useful for finding
    who maintains a project or identifying key developers.

    Follow-up: use github_user on any contributor username to see their full profile (bio,
    company, location, email), then github_user_repos to see their other projects.

    Args:
        owner: Repository owner (user or org)
        repo: Repository name
        per_page: Results per page (1-100, default 30)
        page: Page number (default 1)
    """
    logger.info(f"[github_contributors] {owner}/{repo}")
    args: dict = {"owner": owner, "repo": repo, "per_page": per_page, "page": page}
    result = await handle_github_contributors(args)
    return _parse_result(result)


@server.tool()
async def github_user(
    username: str,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch a GitHub user or organization profile — bio, company, location, email, blog,
    Twitter handle, follower/repo counts. Works for both users and organizations.

    Use this to get full profile details for any username found via github_search_users,
    github_contributors, github_stargazers, github_trending (developers), or github_forks.
    Those tools return usernames but not full profile data.

    Follow-up: github_user_repos (their projects), github_user_starred (what they follow),
    github_search_repos with user="username" (search within their repos).

    Args:
        username: GitHub username or organization name
    """
    logger.info(f"[github_user] {username}")
    result = await handle_github_user({"username": username})
    return _parse_result(result)


@server.tool()
async def github_user_repos(
    username: str,
    sort: str = "updated",
    per_page: int = 30,
    page: int = 1,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch a user's public repositories.

    Use this after github_user, github_search_users, github_contributors, or
    github_stargazers to see what projects a user maintains. Returns repo summaries
    with stats (stars, forks, language).

    Follow-up: use github_repo on any result to get full README, language breakdown,
    or detailed metadata. Use github_releases to check version history.

    Args:
        username: GitHub username
        sort: Sort by — created, updated (default), pushed, full_name
        per_page: Results per page (1-100, default 30)
        page: Page number (default 1)
    """
    logger.info(f"[github_user_repos] {username}")
    args: dict = {"username": username, "sort": sort, "per_page": per_page, "page": page}
    result = await handle_github_user_repos(args)
    return _parse_result(result)


@server.tool()
async def github_user_starred(
    username: str,
    sort: str = "created",
    direction: str = "desc",
    per_page: int = 30,
    page: int = 1,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch repositories a user has starred, with starred_at timestamps.

    Use this after github_user, github_search_users, or github_contributors to discover
    what tools and projects a developer follows or evaluates. Each result includes the repo
    and when they starred it.

    Follow-up: use github_repo on any starred repo to get its full README or languages,
    or github_contributors to see who builds it.

    Args:
        username: GitHub username
        sort: Sort by — created (when starred, default) or updated (last repo push)
        direction: Sort direction — desc (default) or asc
        per_page: Results per page (1-100, default 30)
        page: Page number (default 1)
    """
    logger.info(f"[github_user_starred] {username}")
    args: dict = {
        "username": username, "sort": sort, "direction": direction,
        "per_page": per_page, "page": page,
    }
    result = await handle_github_user_starred(args)
    return _parse_result(result)


@server.tool()
async def github_trending(
    type: str = "repositories",
    language: str | None = None,
    since: str = "daily",
    spoken_language_code: str | None = None,
    sponsorable: bool = False,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch trending repositories or developers from github.com/trending.

    Discovery tool — returns what's hot on GitHub right now. Scraped from HTML.

    - type="repositories" (default): trending repos with stars, forks, description.
      Follow-up: github_repo for full README/languages, github_contributors for who builds it,
      github_releases for recent versions.
    - type="developers": trending developers with popular repo.
      Follow-up: github_user for full profile, github_user_repos for all their projects.

    Args:
        type: Type — "repositories" (default) or "developers"
        language: Programming language filter (e.g. "python", "rust")
        since: Time range — "daily" (default), "weekly", "monthly"
        spoken_language_code: Spoken language ISO code (e.g. "en", "zh") — repos only
        sponsorable: Filter to sponsorable developers only — developers only
    """
    logger.info(f"[github_trending] type={type}, lang={language}")
    args: dict = {"type": type, "since": since}
    if language:
        args["language"] = language
    if spoken_language_code:
        args["spoken_language_code"] = spoken_language_code
    if sponsorable:
        args["sponsorable"] = sponsorable
    result = await handle_github_trending(args)
    return _parse_result(result)


@server.tool()
async def github_search_repos(
    query: str,
    language: str | None = None,
    stars_min: int | None = None,
    stars_max: int | None = None,
    forks_min: int | None = None,
    forks_max: int | None = None,
    pushed_after: str | None = None,
    pushed_before: str | None = None,
    created_after: str | None = None,
    created_before: str | None = None,
    topic: str | None = None,
    license: str | None = None,
    user: str | None = None,
    org: str | None = None,
    archived: bool | None = None,
    include_forks: str | None = None,
    sort: str = "best-match",
    order: str = "desc",
    per_page: int = 30,
    page: int = 1,
    ctx: Context | None = None,
) -> dict:
    """
    Search GitHub repositories by keyword query with structured filters.

    Discovery tool — use for keyword/phrase searches like "llm agent", "web scraping framework".
    NOT for browsing a known topic tag — use github_topic_repos for that instead.
    Returns repo summaries (name, description, stars, language) but NOT full README or languages.

    Follow-up: github_repo with include=["readme","languages"] for full details on any result,
    github_contributors for who builds it, github_releases for version history,
    github_search_issues with repo="owner/name" for bugs/PRs in a specific result.

    Filters are auto-composed into GitHub qualifier syntax. Max 1,000 results per query.

    Args:
        query: Search keywords (max 256 chars)
        language: Primary language (e.g. "python", "rust")
        stars_min: Minimum star count
        stars_max: Maximum star count
        forks_min: Minimum fork count
        forks_max: Maximum fork count
        pushed_after: Pushed after date (YYYY-MM-DD)
        pushed_before: Pushed before date (YYYY-MM-DD)
        created_after: Created after date (YYYY-MM-DD)
        created_before: Created before date (YYYY-MM-DD)
        topic: Topic tag (e.g. "machine-learning")
        license: License key (e.g. "mit", "apache-2.0")
        user: Owner username
        org: Organization name
        archived: Filter by archived status
        include_forks: Include forks ("true") or show only forks ("only")
        sort: Sort by — stars, forks, updated, help-wanted-issues, best-match (default)
        order: Sort order — desc (default) or asc
        per_page: Results per page (1-100, default 30)
        page: Page number (default 1)
    """
    logger.info(f"[github_search_repos] query={query}")
    args: dict = {"query": query, "sort": sort, "order": order, "per_page": per_page, "page": page}
    for key, val in {
        "language": language, "stars_min": stars_min, "stars_max": stars_max,
        "forks_min": forks_min, "forks_max": forks_max,
        "pushed_after": pushed_after, "pushed_before": pushed_before,
        "created_after": created_after, "created_before": created_before,
        "topic": topic, "license": license, "user": user, "org": org,
        "archived": archived, "include_forks": include_forks,
    }.items():
        if val is not None:
            args[key] = val
    result = await handle_github_search_repos(args)
    return _parse_result(result)


@server.tool()
async def github_search_users(
    query: str,
    location: str | None = None,
    language: str | None = None,
    followers_min: int | None = None,
    followers_max: int | None = None,
    repos_min: int | None = None,
    repos_max: int | None = None,
    created_after: str | None = None,
    created_before: str | None = None,
    fullname: str | None = None,
    account_type: str | None = None,
    sort: str = "best-match",
    order: str = "desc",
    per_page: int = 30,
    page: int = 1,
    ctx: Context | None = None,
) -> dict:
    """
    Search GitHub users and organizations by location, language, followers, and more.

    Discovery tool — find developers in a city, prolific open-source contributors, or
    organizations by language expertise. Uses GraphQL for richer profile data (bio, company,
    location, website) in a single request. Max 1,000 results per query.

    Follow-up: github_user for full profile if needed, github_user_repos to see their projects,
    github_user_starred to see what tools/libraries they follow.

    Args:
        query: Search keywords (max 256 chars)
        location: User location (e.g. "San Francisco", "Berlin")
        language: Primary language (e.g. "python", "rust")
        followers_min: Minimum follower count
        followers_max: Maximum follower count
        repos_min: Minimum public repo count
        repos_max: Maximum public repo count
        created_after: Account created after date (YYYY-MM-DD)
        created_before: Account created before date (YYYY-MM-DD)
        fullname: Display name (e.g. "Linus Torvalds")
        account_type: Account type — "user" or "org"
        sort: Sort by — followers, repositories, joined, best-match (default)
        order: Sort order — desc (default) or asc
        per_page: Results per page (1-100, default 30)
        page: Page number (default 1)
    """
    logger.info(f"[github_search_users] query={query}")
    args: dict = {"query": query, "sort": sort, "order": order, "per_page": per_page, "page": page}
    for key, val in {
        "location": location, "language": language,
        "followers_min": followers_min, "followers_max": followers_max,
        "repos_min": repos_min, "repos_max": repos_max,
        "created_after": created_after, "created_before": created_before,
        "fullname": fullname, "account_type": account_type,
    }.items():
        if val is not None:
            args[key] = val
    result = await handle_github_search_users(args)
    return _parse_result(result)


@server.tool()
async def github_search_topics(
    query: str,
    curation: str | None = None,
    repositories_min: int | None = None,
    repositories_max: int | None = None,
    per_page: int = 30,
    page: int = 1,
    ctx: Context | None = None,
) -> dict:
    """
    Search GitHub topics by keyword with optional curation and popularity filters.

    Discovery tool — find topic tags that exist for a subject area (e.g. "machine learning"
    returns topics like "machine-learning", "deep-learning", "neural-network"). Returns topic
    names, descriptions, and repo counts.

    Follow-up: use github_topic_repos with the topic name to browse top repos under that topic.
    This is the standard two-step flow: search_topics → topic_repos → github_repo for details.

    Args:
        query: Search keywords (max 256 chars)
        curation: Filter by curation status — "featured", "curated", "not-curated"
        repositories_min: Minimum repository count using this topic
        repositories_max: Maximum repository count using this topic
        per_page: Results per page (1-100, default 30)
        page: Page number (default 1)
    """
    logger.info(f"[github_search_topics] query={query}")
    args: dict = {"query": query, "per_page": per_page, "page": page}
    if curation:
        args["curation"] = curation
    if repositories_min is not None:
        args["repositories_min"] = repositories_min
    if repositories_max is not None:
        args["repositories_max"] = repositories_max
    result = await handle_github_search_topics(args)
    return _parse_result(result)


@server.tool()
async def github_search_issues(
    query: str,
    issue_type: str | None = None,
    state: str | None = None,
    label: str | None = None,
    language: str | None = None,
    repo: str | None = None,
    author: str | None = None,
    assignee: str | None = None,
    comments_min: int | None = None,
    comments_max: int | None = None,
    reactions_min: int | None = None,
    reactions_max: int | None = None,
    created_after: str | None = None,
    created_before: str | None = None,
    is_merged: bool | None = None,
    is_draft: bool | None = None,
    sort: str = "best-match",
    order: str = "desc",
    per_page: int = 30,
    page: int = 1,
    ctx: Context | None = None,
) -> dict:
    """
    Search GitHub issues and pull requests across all repositories.

    Use this to find bugs, feature requests, or PRs — either globally or scoped to a specific
    repo (repo="owner/name"). Commonly chained after discovering a repo via github_search_repos,
    github_trending, or github_topic_repos to explore its issue tracker.

    Also useful standalone: find all open "help wanted" issues in a language, track recently
    merged PRs by an author, or discover popular feature requests by reaction count.

    Follow-up: use github_repo to understand the repo context for any issue result,
    github_user on the issue author to see their profile.

    Max 1,000 results per query.

    Args:
        query: Search keywords (max 256 chars)
        issue_type: Filter by type — "issue" or "pr"
        state: Filter by state — "open" or "closed"
        label: Filter by label name (e.g. "bug", "help wanted")
        language: Filter by repository language
        repo: Filter to specific repo (owner/name format, e.g. "vercel/next.js")
        author: Filter by author username
        assignee: Filter by assignee username
        comments_min: Minimum comment count
        comments_max: Maximum comment count
        reactions_min: Minimum reaction count
        reactions_max: Maximum reaction count
        created_after: Created after date (YYYY-MM-DD)
        created_before: Created before date (YYYY-MM-DD)
        is_merged: Filter PRs by merged status
        is_draft: Filter PRs by draft status
        sort: Sort by — comments, reactions, created, updated, best-match (default)
        order: Sort order — desc (default) or asc
        per_page: Results per page (1-100, default 30)
        page: Page number (default 1)
    """
    logger.info(f"[github_search_issues] query={query}")
    args: dict = {"query": query, "sort": sort, "order": order, "per_page": per_page, "page": page}
    for key, val in {
        "issue_type": issue_type, "state": state, "label": label,
        "language": language, "repo": repo, "author": author, "assignee": assignee,
        "comments_min": comments_min, "comments_max": comments_max,
        "reactions_min": reactions_min, "reactions_max": reactions_max,
        "created_after": created_after, "created_before": created_before,
        "is_merged": is_merged, "is_draft": is_draft,
    }.items():
        if val is not None:
            args[key] = val
    result = await handle_github_search_issues(args)
    return _parse_result(result)


@server.tool()
async def github_topic_repos(
    topic: str,
    sort: str = "stars",
    order: str = "desc",
    per_page: int = 30,
    page: int = 1,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch repositories tagged with a specific GitHub topic.

    PREFER this over github_search_repos when the query maps directly to a GitHub topic tag
    (e.g. "web-scraping", "machine-learning", "python"). Equivalent of browsing
    github.com/topics/{name} — better results than keyword search for category browsing.

    Commonly reached via github_search_topics (discover topic names first) → github_topic_repos.
    Returns repo summaries with stats but NOT full README or languages.

    Follow-up: github_repo with include=["readme","languages"] for full details on any result,
    github_contributors for who builds it, github_search_issues with repo="owner/name" for bugs.

    Args:
        topic: Topic name (e.g. "python", "web-scraping", "machine-learning")
        sort: Sort by — stars (default), forks, updated, help-wanted-issues, best-match
        order: Sort order — desc (default) or asc
        per_page: Results per page (1-100, default 30)
        page: Page number (default 1)
    """
    logger.info(f"[github_topic_repos] topic={topic}")
    args: dict = {"topic": topic, "sort": sort, "order": order, "per_page": per_page, "page": page}
    result = await handle_github_topic_repos(args)
    return _parse_result(result)


# =============================================================================
# Video Tools
# =============================================================================


@server.tool()
async def download_video(
    url: str,
    platform: str,
    quality: str = "best",
    ctx: Context | None = None,
) -> dict:
    """
    Get video download URLs and metadata from a Twitter/X tweet or Reddit post.

    Use this when the user wants to download a video, get video URLs, check available
    quality options, or see video metadata (resolution, bitrate, duration, thumbnail).
    Returns all available quality variants — the user can open or download the URLs directly.

    This tool does NOT transcribe or extract text from videos. For speech-to-text
    transcription, use the transcribe_video tool instead.

    Since MCP is text-based, this returns metadata and CDN URLs — not the binary stream.

    Args:
        url: Tweet or Reddit post URL containing a video
        platform: Source platform — "twitter" or "reddit"
        quality: Preferred quality — "best" (default) or a pixel height (e.g. "720")
    """
    logger.info(f"[download_video] URL: {url}, platform: {platform}, quality: {quality}")
    args: dict = {"url": url, "platform": platform}
    if quality != "best":
        args["quality"] = quality
    result = await handle_download_video(args)
    return _parse_result(result)


@server.tool()
async def transcribe_video(
    url: str,
    platform: str,
    language: str | None = None,
    ctx: Context | None = None,
) -> dict:
    """
    Transcribe speech from a Twitter/X or Reddit video into text.

    Use this when the user wants to know what is being said in a video, get a transcript,
    generate subtitles/captions, or convert video speech to text. Works with videos of any
    length — uses a generous timeout to handle long transcriptions.

    Extracts audio in-memory, sends to Whisper speech-to-text. Returns the full transcript
    with optional timestamps. No video is downloaded or saved to disk.

    This tool does NOT return video URLs or metadata. For downloading videos, use the
    download_video tool instead.

    Args:
        url: Tweet or Reddit post URL containing a video with speech/audio
        platform: Source platform — "twitter" or "reddit"
        language: Language hint (ISO 639-1, e.g. 'en', 'es'). Auto-detected if omitted.
    """
    logger.info(f"[transcribe_video] URL: {url}, platform: {platform}")
    args: dict = {"url": url, "platform": platform}
    if language:
        args["language"] = language
    result = await handle_transcribe_video(args)
    return _parse_result(result)


# =============================================================================
# Image Tools
# =============================================================================


@server.tool()
async def download_image(
    url: str,
    platform: str,
    ctx: Context | None = None,
) -> dict:
    """
    Get image URLs and metadata from a Twitter/X tweet or Reddit post.

    Use this when the user wants to download images, get image URLs, or see image
    metadata from a tweet or Reddit post. Supports single images, multi-image tweets
    (up to 4), and Reddit gallery posts (unlimited images).

    Returns all image URLs with dimensions. The response includes `image_count` and
    `is_gallery`. When multiple images are found, present each image separately with
    its index (0-based) so the user knows exactly how many images are available.

    This tool is for IMAGES only. For videos, use download_video or transcribe_video.

    Since MCP is text-based, this returns metadata (URLs, dimensions), not binary data.
    The returned URLs are direct CDN links the user can open or download.

    Args:
        url: Tweet or Reddit post URL containing image(s)
        platform: Source platform — "twitter" or "reddit"
    """
    logger.info(f"[download_image] URL: {url}, platform: {platform}")
    result = await handle_download_image({"url": url, "platform": platform})
    return _parse_result(result)


def main():
    """Entry point for the MCP server."""
    logger.info("=" * 70)
    logger.info("CrawlNest MCP Server Started (FastMCP)")
    logger.info("Transport: stdio (Claude Desktop compatible)")
    logger.info("Tools: scraping (3) + twitter (7) + hackernews (22)  + github (14) + reddit (7) + video (2) + image (1) + playstore (9) + appstore (9) = 74 total")
    logger.info("Waiting for connections...")
    logger.info("=" * 70)
    server.run()


if __name__ == "__main__":
    main()
