from modict import modict

from codex_agent import Agent
from codex_agent.tui.chat import Chat
from codex_agent.message import CompactionMessage, DeveloperMessage, UserMessage


def test_agent_context_status_is_lightweight_and_does_not_call_providers():
    agent = Agent(session="new", voice_enabled=False, input_token_limit=10_000)
    agent.session.messages.append(DeveloperMessage(content="hello context"))
    called = []

    @agent.add_provider
    def expensive_provider():
        called.append(True)
        return "expensive"

    status = agent.status_manager.context_status()

    assert called == []
    assert status.used_tokens > 0
    assert status.input_token_limit == 10_000
    assert 0 <= status.percent <= 100
    assert status.total_session_messages == len(agent.session.messages)
    assert status.visible_history_messages <= status.total_history_messages
    assert status.sent_session_messages <= status.total_session_messages


def test_agent_context_status_counts_only_effective_context_messages():
    agent = Agent(session="new", voice_enabled=False, input_token_limit=10_000)
    old = DeveloperMessage(content="old hidden context")
    compaction = CompactionMessage(output_items=[{"type": "compaction_summary", "id": "cs_123"}])
    expired = DeveloperMessage(content="expired hidden context", turns_left=0)
    visible = DeveloperMessage(content="visible context")
    agent.session.messages = [old, compaction, expired, visible]

    status = agent.status_manager.context_status()

    assert status.context_session_messages == 2
    assert status.total_history_messages == 2
    assert status.sent_session_messages == 2
    assert status.persistent_session_messages == 2
    assert status.temporary_session_messages == 0


def test_agent_context_status_counts_persistent_and_temporary_messages():
    agent = Agent(session="new", voice_enabled=False, input_token_limit=10_000)
    compaction = CompactionMessage(output_items=[{"type": "compaction_summary", "id": "cs_123"}])
    persistent = DeveloperMessage(content="persistent")
    temporary = DeveloperMessage(content="temporary", turns_left=2)
    expired = DeveloperMessage(content="expired", turns_left=0)
    agent.session.messages = [compaction, persistent, temporary, expired]

    status = agent.status_manager.context_status()

    assert status.context_session_messages == 3
    assert status.persistent_session_messages == 2
    assert status.temporary_session_messages == 1


def test_agent_status_preserves_persistent_and_temporary_message_counts():
    agent = Agent(session="new", voice_enabled=False, input_token_limit=10_000)
    agent.session.messages.append(DeveloperMessage(content="persistent"))
    agent.session.messages.append(DeveloperMessage(content="temporary", turns_left=2))

    status = agent.get_status()

    assert status.persistent_session_messages == 2
    assert status.temporary_session_messages == 1


def test_agent_api_status_uses_precached_persistent_and_temporary_counts(monkeypatch):
    agent = Agent(session="new", voice_enabled=False, input_token_limit=10_000)
    agent.session.messages.append(DeveloperMessage(content="persistent"))
    agent.session.messages.append(DeveloperMessage(content="temporary", turns_left=2))

    agent.context_manager.get_context()
    monkeypatch.setattr(agent.status_manager, "context_status", lambda: (_ for _ in ()).throw(AssertionError("should use cache")))
    agent.status_manager.cache_api_status(usage=modict(input_tokens=1000), model="gpt-test")

    status = agent.get_status()
    assert status.persistent_session_messages == 2
    assert status.temporary_session_messages == 1


def test_agent_context_status_counts_response_tool_specs():
    agent = Agent(session="new", voice_enabled=False, input_token_limit=10_000)

    @agent.add_tool
    def verbose_tool(query: str):
        """
        description: Search a deliberately verbose external index with a long schema description.
        parameters:
          query:
            type: string
            description: A rich query string that can include names, dates, references, and constraints.
        """
        return query

    status = agent.status_manager.context_status()

    assert status.tool_spec_tokens == agent.context_manager.response_tools_token_count()
    assert status.tool_spec_tokens > 0
    assert status.fixed_tokens >= status.tool_spec_tokens
    assert status.token_count_source == "local_estimate"


def test_agent_get_status_uses_cached_last_api_call_status():
    agent = Agent(session="new", voice_enabled=False, input_token_limit=10_000)
    agent.session.messages.append(DeveloperMessage(content="hello context"))
    agent.status_manager.cache_api_status(
        usage=modict(input_tokens=2500),
        model="gpt-test",
        quota={
            "rate_limit": {
                "primary_window": {"used_percent": 12},
                "secondary_window": {"used_percent": 34},
            },
        },
    )

    status = agent.get_status()

    assert status.context_current_tokens == 2500
    assert status.context_limit_tokens == 10_000
    assert status.context_percent == 25
    assert status.sent_session_messages == len(agent.session.messages)
    assert status.total_session_messages == len(agent.session.messages)
    assert status.sent_session_message_percent == 100
    assert status.quota_5h_percent == 12
    assert status.quota_7d_percent == 34
    assert status.model == "gpt-test"


def test_agent_api_status_uses_precached_context_message_ratio(monkeypatch):
    agent = Agent(session="new", voice_enabled=False, input_token_limit=10_000)
    agent.session.messages.append(DeveloperMessage(content="first"))
    agent.session.messages.append(DeveloperMessage(content="second"))

    agent.context_manager.get_context()
    monkeypatch.setattr(agent.status_manager, "context_status", lambda: (_ for _ in ()).throw(AssertionError("should use cache")))
    agent.status_manager.cache_api_status(usage=modict(input_tokens=1000), model="gpt-test")

    status = agent.get_status()
    assert status.sent_session_messages == len(agent.session.messages)
    assert status.total_session_messages == len(agent.session.messages)
    assert status.sent_session_message_percent == 100


def test_agent_get_status_preloads_wham_once_before_first_api_call():
    agent = Agent(session="new", voice_enabled=False, input_token_limit=10_000)
    calls = []

    class Client:
        def usage(self):
            calls.append("usage")
            return {
                "rate_limit": {
                    "primary_window": {"used_percent": 12},
                    "secondary_window": {"used_percent": 34},
                },
            }

    agent.ai._codex_client = Client()

    first = agent.get_status()
    second = agent.get_status()

    assert calls == ["usage"]
    assert first.quota_5h_percent == 12
    assert first.quota_7d_percent == 34
    assert second.quota_5h_percent == 12
    assert second.quota_7d_percent == 34


def test_agent_wham_status_normalizes_quota_windows():
    agent = Agent(session="new", voice_enabled=False)

    status = agent.status_manager.wham_status({
        "plan_type": "plus",
        "rate_limit": {
            "allowed": True,
            "limit_reached": False,
            "primary_window": {"used_percent": 12, "limit_window_seconds": 18_000},
            "secondary_window": {"used_percent": 34, "limit_window_seconds": 604_800},
        },
        "credits": {"used": 1},
        "additional_rate_limits": [{"name": "extra"}],
        "rate_limit_reached_type": None,
    })

    assert status.plan_type == "plus"
    assert status.allowed is True
    assert status.limit_reached is False
    assert status.primary_window.used_percent == 12
    assert status.secondary_window.used_percent == 34
    assert status.credits == {"used": 1}
    assert status.additional_rate_limits == [{"name": "extra"}]
    assert status.rate_limit_reached_type is None
    assert status.quota_5h_percent == 12
    assert status.quota_7d_percent == 34


def test_chat_status_bar_formats_compact_status():
    status = modict(
        context_current_tokens=12_300,
        context_limit_tokens=128_000,
        context_percent=9.609,
        sent_session_messages=8,
        total_session_messages=25,
        quota_5h_percent=42,
        quota_7d_percent=13,
        model="gpt-5.4",
    )

    rendered = Chat.format_status(status)
    output = rendered.plain

    assert "ctx" in output
    assert "12.3/128.0 ktok" in output
    assert "9.6%" in output
    assert "msg 8/25" in output
    assert "5h 42%" in output
    assert "7d 13%" in output
    assert "gpt-5.4" in output
    assert any("#161b22" in str(span.style) for span in rendered.spans)


def test_chat_status_bar_formats_persistent_plus_temporary_messages():
    status = modict(
        context_current_tokens=12_300,
        context_limit_tokens=128_000,
        context_percent=9.609,
        sent_session_messages=43,
        persistent_session_messages=33,
        temporary_session_messages=10,
        total_session_messages=93,
        quota_5h_percent=42,
        quota_7d_percent=13,
        model="gpt-5.4",
    )

    rendered = Chat.format_status(status)
    output = rendered.plain

    assert "msg 33+10/93" in output
    assert any(
        "#f0883e" in str(span.style) and output[span.start:span.end] == "+10"
        for span in rendered.spans
    )


def test_chat_refresh_status_keeps_rich_text_styles():
    chat = Chat(client=modict(
        get_status=lambda: modict(
            context_current_tokens=10_000,
            context_limit_tokens=100_000,
            context_percent=80,
            sent_session_messages=8,
            total_session_messages=25,
            quota_5h_percent=55,
            quota_7d_percent=91,
            model="gpt-5.4",
        )
    ))
    chat._server_connected = True
    rendered = chat.status_renderable()

    assert hasattr(rendered, "spans")
    assert any("#f0883e" in str(span.style) for span in rendered.spans)


def test_chat_status_percent_styles_use_green_yellow_orange_red_scale():
    assert Chat._percent_style(10) == "#3fb950"
    assert Chat._percent_style(50) == "#d29922"
    assert Chat._percent_style(75) == "#f0883e"
    assert Chat._percent_style(90) == "bold #ff7b72"
    assert Chat._percent_style(None) == "#6e7681"


def test_chat_composer_height_expands_between_one_and_ten_useful_lines():
    assert Chat.composer_height("") == 3
    assert Chat.composer_height("one\ntwo") == 4
    assert Chat.composer_height("\n".join(str(i) for i in range(10))) == 12
    assert Chat.composer_height("\n".join(str(i) for i in range(20))) == 12


def test_chat_replays_startup_events_after_subscription(monkeypatch):
    chat = Chat()
    calls = []

    class App:
        def call_from_thread(self, callback, *args):
            callback(*args)

        def write_user(self, prompt):
            calls.append(("user", prompt))

        def write_agent_start(self, name):
            calls.append(("agent_start", name))

        def write_agent_delta(self, delta):
            calls.append(("delta", delta))

        def refresh_status(self):
            calls.append(("status",))

    chat.app = App()
    chat.attach()
    monkeypatch.setattr("codex_agent.tui.chat.register_tui", lambda base_url: None)
    monkeypatch.setattr(
        chat.client,
        "replay_events",
        lambda before_sequence=None, session_id=None: calls.append(("replay", before_sequence, session_id)) or modict(events=[
            modict(id="evt_1", type="assistant_turn_start_event", prompt="hello", sequence=5),
            modict(id="evt_2", type="message_added_event", message=UserMessage(content="hello"), sequence=6),
            modict(id="evt_3", type="assistant_turn_start_event", sequence=7),
            modict(id="evt_4", type="response_content_delta_event", delta="he", sequence=8),
            modict(id="evt_5", type="response_content_delta_event", delta="llo", sequence=9),
        ]),
    )

    chat._on_server_subscribed(modict(replay_before_sequence=9, session_id="session_1"))

    assert chat._server_connected is True
    assert chat.client._last_event_sequence == 9
    assert ("replay", 9, "session_1") in calls
    assert ("user", "hello") in calls
    assert ("agent_start", chat.agent_name()) in calls
    assert [call for call in calls if call[0] == "delta"] == [("delta", "hello")]


def test_chat_displays_user_message_added_events(monkeypatch):
    chat = Chat()
    calls = []
    monkeypatch.setattr(chat, "_call_app", lambda method, *args: calls.append((method, args)))
    message = UserMessage(content="hello from session")

    chat._on_message_added(modict(type="message_added_event", message=message))

    assert calls == [
        ("write_user", ("hello from session",)),
        ("refresh_status", ()),
    ]


def test_chat_uses_message_added_event_as_user_message_display_source(monkeypatch):
    chat = Chat()
    calls = []
    monkeypatch.setattr(chat, "_call_app", lambda method, *args: calls.append((method, args)))
    message = UserMessage(content="hello submitted")

    chat.attach()
    chat.client.emit_local(modict(type="message_submitted_event", message=message, turn_id="turn_1"))
    assert calls == []

    chat.client.emit_local(modict(type="message_added_event", message=message))

    assert calls == [
        ("write_user", ("hello submitted",)),
        ("refresh_status", ()),
    ]


def test_chat_attach_dispatches_assistant_turn_and_step_events(monkeypatch):
    chat = Chat()
    calls = []
    monkeypatch.setattr(chat, "_call_app", lambda method, *args: calls.append((method, args)))

    chat.attach()
    chat.client.emit_local(modict(type="assistant_turn_start_event"))
    chat.client.emit_local(modict(type="assistant_step_start_event"))
    chat.client.emit_local(modict(type="response_content_delta_event", delta="hi"))
    chat.client.emit_local(modict(type="assistant_step_end_event"))
    chat.client.emit_local(modict(type="assistant_turn_end_event", reason="completed"))
    chat.client.emit_local(modict(type="assistant_turn_error_event", error="boom"))

    assert ("write_agent_start", (chat.agent_name(),)) in calls
    assert ("start_agent_step", ()) in calls
    assert ("write_agent_delta", ("hi",)) in calls
    assert ("end_agent_step", ()) in calls
    assert ("write_error", ("boom",)) in calls
    assert not any("agent_turn" in str(call) for call in calls)


def test_chat_displays_tool_start_and_done_as_distinct_lines(monkeypatch):
    chat = Chat()
    calls = []
    monkeypatch.setattr(chat, "_call_app", lambda method, *args: calls.append((method, args)))

    chat.attach()
    tool_call = modict(name="read", call_id="call_read")
    chat.client.emit_local(modict(type="assistant_turn_start_event"))
    chat.client.emit_local(modict(type="tool_call_start_event", tool_call=tool_call))
    chat.client.emit_local(modict(type="tool_call_done_event", tool_call=tool_call, content="ok"))

    assert calls.count(("write_tool", ("read", "call_read", "running"))) == 1
    assert calls.count(("write_tool", ("read", "call_read", "done"))) == 1
    assert calls.index(("write_tool", ("read", "call_read", "running"))) < calls.index(("write_tool", ("read", "call_read", "done")))


def test_chat_displays_slash_command_start_and_done_as_distinct_lines(monkeypatch):
    chat = Chat()
    calls = []
    monkeypatch.setattr(chat, "_call_app", lambda method, *args: calls.append((method, args)))

    chat.attach()
    chat.client.emit_local(modict(type="assistant_turn_start_event"))
    chat.client.emit_local(modict(type="slash_command_start_event", name="compact", args="--force"))
    chat.client.emit_local(modict(type="slash_command_done_event", name="compact", args="--force", status="done"))

    assert calls.count(("write_slash_command", ("compact", "--force", "running"))) == 1
    assert calls.count(("write_slash_command", ("compact", "--force", "done"))) == 1
    assert calls.index(("write_slash_command", ("compact", "--force", "running"))) < calls.index(("write_slash_command", ("compact", "--force", "done")))


def test_chat_slash_command_done_displays_result(monkeypatch):
    chat = Chat()
    calls = []
    monkeypatch.setattr(chat, "_call_app", lambda method, *args: calls.append((method, args)))

    chat.attach()
    chat.client.emit_local(modict(type="slash_command_done_event", name="help", status="done", result="Available commands: /help"))

    assert ("write_slash_command", ("help", "", "done")) in calls
    assert ("write_agent_delta", ("Available commands: /help",)) in calls
    assert calls[-1] == ("refresh_status", ())


def test_chat_slash_command_done_displays_errors(monkeypatch):
    chat = Chat()
    calls = []
    monkeypatch.setattr(chat, "_call_app", lambda method, *args: calls.append((method, args)))

    chat.attach()
    chat.client.emit_local(modict(type="slash_command_done_event", name="missing", status="failed", error="Unknown command: /missing"))

    assert ("write_slash_command", ("missing", "", "failed")) in calls
    assert ("write_error", ("Unknown command: /missing",)) in calls
    assert calls[-1] == ("refresh_status", ())


def test_chat_tool_status_helpers_are_compact_and_consistent():
    assert Chat.normalized_tool_status("success") == "done"
    assert Chat.normalized_tool_status("error") == "failed"
    assert Chat.normalized_tool_status(None) == "running"

    assert Chat.tool_status_badge("running") == ("→", "bold #58a6ff")
    assert Chat.tool_status_badge("done") == ("✓", "bold #3fb950")
    assert Chat.tool_status_badge("failed") == ("✕", "bold #ff7b72")
    assert Chat.tool_status_label("running") == " · running"
    assert Chat.tool_status_label("done") == " · done"


def test_chat_shortens_long_tool_call_ids():
    assert Chat.short_tool_call_id("call_123") == "call_123"
    shortened = Chat.short_tool_call_id("call_abcdefghijklmnopqrstuvwxyz", max_length=14)
    assert shortened.startswith("call_")
    assert shortened.endswith("wxyz")
    assert "…" in shortened
    assert len(shortened) <= 14


def test_chat_tool_call_renderable_is_discreet_and_readable():
    rendered = Chat.tool_call_renderable("bash", call_id="call_abcdefghijklmnopqrstuvwxyz", status="done")
    plain = rendered.plain

    assert plain.startswith("  ✓ bash")
    assert "#call_" in plain
    assert "tool ›" not in plain
    assert "done" not in plain
    assert "running" not in plain
    assert "failed" not in plain
    assert "abcdefghijklmnopqrstuvwxyz" not in plain


def test_chat_appends_tool_lines_immediately_without_waiting_for_step_end():
    chat = Chat()

    chat.append_tool_transcript("bash", call_id="call_sleep", status="running")

    assert chat._transcript[-1] == ("tool", "bash", "call_sleep", "running")
    assert chat._step_had_content is True


def test_chat_transcript_tracks_user_and_assistant_role_boundaries(monkeypatch):
    chat = Chat()
    monkeypatch.setattr(chat, "username", lambda: "You")

    assert chat.ensure_agent_transcript("Pandora") is True
    assert chat.ensure_agent_transcript("Pandora") is False

    chat._agent_buffer = "already streamed"
    chat.append_user_transcript("new direction")
    assert chat._agent_buffer == ""
    assert chat.ensure_agent_transcript("Pandora") is True

    assert chat._transcript == [
        ("speaker", "Pandora", "#789fbe"),
        ("speaker", "You", "#88b38a"),
        ("user", "new direction"),
        ("user_end",),
        ("speaker", "Pandora", "#789fbe"),
    ]


def test_chat_tracks_server_connection_state(monkeypatch):
    chat = Chat()
    calls = []
    monkeypatch.setattr(chat, "_call_app", lambda method, *args: calls.append((method, args)))

    chat._server_connected = True
    chat._on_server_offline({"type": "server_offline", "error": "server down"})
    assert chat._server_connected is False
    assert chat._server_error == "server down"
    assert ("write_info", ("server offline",)) in calls
    assert calls[-1] == ("refresh_status", ())

    chat._on_server_connected({"type": "server_connected"})
    assert chat._server_connected is True
    assert chat._server_error == ""
    assert ("write_info", ("server connected",)) in calls
    assert calls[-1] == ("refresh_status", ())


def test_chat_event_stream_error_marks_server_offline_once(monkeypatch):
    chat = Chat()
    calls = []
    monkeypatch.setattr(chat, "_call_app", lambda method, *args: calls.append((method, args)))

    chat._server_connected = True
    chat._on_client_event_error({"type": "client_event_error", "source": "event_stream", "error": "connection lost"})
    chat._on_client_event_error({"type": "client_event_error", "source": "event_stream", "error": "still down"})

    assert chat._server_connected is False
    assert chat._server_error == "still down"
    assert calls == [
        ("write_info", ("server offline",)),
        ("refresh_status", ()),
        ("refresh_status", ()),
    ]


def test_chat_local_client_error_does_not_mark_server_offline(monkeypatch):
    chat = Chat()
    calls = []
    monkeypatch.setattr(chat, "_call_app", lambda method, *args: calls.append((method, args)))

    chat._server_connected = True
    chat._on_client_event_error({"type": "client_event_error", "error": "handler failed"})

    assert chat._server_connected is True
    assert chat._server_error == ""
    assert calls == [("write_error", ("handler failed",))]


def test_chat_status_error_does_not_mark_connected_stream_offline():
    chat = Chat(client=modict(get_status=lambda: (_ for _ in ()).throw(RuntimeError("status timeout"))))
    chat._server_connected = True

    rendered = chat.status_renderable()

    assert chat._server_connected is True
    assert "status unavailable" in rendered


def test_chat_stream_event_restores_connected_state(monkeypatch):
    chat = Chat()
    calls = []
    monkeypatch.setattr(chat, "_call_app", lambda method, *args: calls.append((method, args)))

    chat._server_connected = False
    chat._server_error = "stale status error"
    chat._on_content_delta(modict(type="response_content_delta_event", delta="hi"))

    assert chat._server_connected is True
    assert chat._server_error == ""
    assert ("write_agent_delta", ("hi",)) in calls


def test_chat_batches_stream_deltas_before_rendering():
    chat = Chat()
    calls = []
    timers = []

    class App:
        def call_from_thread(self, callback, *args):
            callback(*args)

        def set_timer(self, delay, callback):
            timers.append((delay, callback))

        def write_agent_delta(self, delta):
            calls.append(("delta", delta))

    chat.app = App()

    chat._on_content_delta(modict(type="response_content_delta_event", delta="he"))
    chat._on_content_delta(modict(type="response_content_delta_event", delta="llo"))

    assert calls == []
    assert len(timers) == 1

    timers[0][1]()

    assert calls == [("delta", "hello")]


def test_chat_response_done_flushes_batched_deltas_before_tool_start(monkeypatch):
    chat = Chat()
    calls = []
    timers = []

    def call_app(method, *args):
        calls.append((method, args))

    class App:
        def call_from_thread(self, callback, *args):
            callback(*args)

        def set_timer(self, delay, callback):
            timers.append((delay, callback))

        def write_agent_delta(self, delta):
            calls.append(("write_agent_delta", (delta,)))

    chat.app = App()
    monkeypatch.setattr(chat, "_call_app", call_app)

    chat._on_content_delta(modict(type="response_content_delta_event", delta="I will "))
    chat._on_content_delta(modict(type="response_content_delta_event", delta="inspect."))
    chat._on_response_done(modict(type="response_done_event"))
    chat._on_tool_call_start(modict(type="tool_call_start_event", tool_call=modict(name="bash", call_id="call_1")))

    assert ("write_agent_delta", ("I will inspect.",)) in calls
    assert ("write_tool", ("bash", "call_1", "running")) in calls
    assert calls.index(("write_agent_delta", ("I will inspect.",))) < calls.index(("write_tool", ("bash", "call_1", "running")))


def test_chat_flushes_replay_deltas_synchronously_before_live_deltas(monkeypatch):
    chat = Chat()
    calls = []
    timers = []

    class App:
        def call_from_thread(self, callback, *args):
            callback(*args)

        def set_timer(self, delay, callback):
            timers.append(callback)

        def write_agent_delta(self, delta):
            calls.append(("delta", delta))

        def write_agent_start(self, name):
            calls.append(("start", name))

        def refresh_status(self):
            calls.append(("status",))

    chat.app = App()
    chat.attach()
    monkeypatch.setattr("codex_agent.tui.chat.register_tui", lambda base_url: None)
    monkeypatch.setattr(
        chat.client,
        "replay_events",
        lambda before_sequence=None, session_id=None: modict(events=[
            modict(id="evt_1", type="assistant_turn_start_event", sequence=1),
            modict(id="evt_2", type="response_content_delta_event", delta="old", sequence=2),
        ]),
    )

    chat._on_server_subscribed(modict(replay_before_sequence=2, session_id="session_1"))
    chat._on_content_delta(modict(type="response_content_delta_event", delta="new"))

    assert ("delta", "old") in calls
    assert ("delta", "new") not in calls
    assert len(timers) == 1
    timers[0]()
    assert [call for call in calls if call[0] == "delta"] == [("delta", "old"), ("delta", "new")]
