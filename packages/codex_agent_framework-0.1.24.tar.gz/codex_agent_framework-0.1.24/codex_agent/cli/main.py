from pathlib import Path
import subprocess

from codex_agent import Agent
from codex_agent.tui import Chat
from codex_agent.server import create_app
from codex_agent.service import install_user_service, uninstall_user_service
from codex_agent.tray import run_tray
from codex_agent.utils import load_runtime_env


PACKAGE_DIR = Path(__file__).resolve().parents[1]


def default_agent_kwargs(host=None, port=None):
    kwargs = dict(
        system=str(PACKAGE_DIR / 'prompts' / 'system_prompt.txt'),
        voice_instructions="You're a lively and friendly female in her mid twenties. You speak french with a easy-going and cheerful tone.",
        username="Baptiste",
        userage="40",
    )
    if host is not None and port is not None:
        kwargs["server_url"] = f"http://{host}:{port}"
    return kwargs


def default_agent():
    return Agent(**default_agent_kwargs())


def configure_server_url(agent, host, port):
    agent.config_manager.update(server_url=f"http://{host}:{port}", save=False)
    return agent


def run_server(host="127.0.0.1", port=8765):
    import uvicorn

    app = create_app(process_agent=True, **default_agent_kwargs(host, port))
    if hasattr(app, "state") and hasattr(app.state, "agent_service"):
        app.state.agent_service.start()
    uvicorn.run(app, host=host, port=port, timeout_graceful_shutdown=2)


def run_chat(base_url="http://127.0.0.1:8765"):
    Chat(base_url=base_url).run()


def server_is_available(base_url, timeout=0.5):
    try:
        from codex_agent.client import AgentClient
        AgentClient(base_url, timeout=timeout).health()
        return True
    except Exception:
        return False


def run_tray_mode(base_url="http://127.0.0.1:8765"):
    run_tray(base_url=base_url)


def run_system_deps_installer(extra_args=None):
    script = PACKAGE_DIR / "scripts" / "install-system-dependencies.sh"
    if not script.is_file():
        raise RuntimeError(f"System dependency installer not found: {script}")
    return subprocess.call([str(script), *(extra_args or [])])


def run_bootstrap(
    host="127.0.0.1",
    port=8765,
    *,
    system_deps_args=None,
    install_system_deps=True,
    install_service=True,
    start_service=True,
):
    if install_system_deps:
        code = run_system_deps_installer(system_deps_args or [])
        if code:
            return code
    if install_service:
        path = install_user_service(host=host, port=port, enable=True, start=start_service)
        action = "Installed and started" if start_service else "Installed"
        print(f"{action} user services: {path}")
    return 0


def run_local(host="127.0.0.1", port=8765):
    import threading
    import time

    import uvicorn

    base_url = f"http://{host}:{port}"
    if server_is_available(base_url):
        run_chat(base_url)
        return

    app = create_app(process_agent=True, **default_agent_kwargs(host, port))
    if hasattr(app, "state") and hasattr(app.state, "agent_service"):
        app.state.agent_service.start()
    config = uvicorn.Config(app, host=host, port=port, log_level="warning", timeout_graceful_shutdown=2)
    server = uvicorn.Server(config)
    thread = threading.Thread(target=server.run, name="codex-agent-server", daemon=True)
    thread.start()
    time.sleep(0.4)
    try:
        run_chat(f"http://{host}:{port}")
    finally:
        server.should_exit = True
        thread.join(timeout=1.0)


def build_parser():
    import argparse

    parser = argparse.ArgumentParser(prog="codex-agent")
    parser.add_argument(
        "mode",
        nargs="?",
        choices=["local", "chat", "install-service", "uninstall-service", "install-system-deps", "bootstrap", "run", "prompt", "status", "tools", "sessions", "config", "interrupt"],
        default="local",
        help="local opens the TUI on an existing server when available, otherwise starts a temporary server for the TUI; chat connects to an existing API; run/prompt submit a headless prompt to an existing API; status/tools/sessions/config/interrupt are non-TUI API commands. Use start/stop/restart for services and open/close for interfaces.",
    )
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--url", default=None, help="Base URL for client modes, e.g. http://127.0.0.1:8765")
    parser.add_argument("--json", action="store_true", help="Emit JSON for headless commands.")
    parser.add_argument("--format", choices=["text", "json", "ndjson"], default=None, help="Output format for headless commands.")
    parser.add_argument("--stdin", action="store_true", help="Read prompt from stdin for run/prompt.")
    parser.add_argument("--wait-timeout", type=float, default=None, help="Seconds to wait for run/prompt completion; 0 submits and returns immediately.")
    parser.add_argument("--runtime", choices=["server", "process", "in-process"], default="server", help="Runtime backend for headless commands. server uses the running API service; process starts an isolated worker; in-process runs in the CLI process.")
    parser.add_argument("--no-save", action="store_true", help="With config set, update runtime config without persisting it.")
    parser.add_argument("--no-system-deps", action="store_true", help="With bootstrap, skip OS dependency installation.")
    parser.add_argument("--no-service", action="store_true", help="With bootstrap, skip user service installation.")
    parser.add_argument("--no-start-service", action="store_true", help="With bootstrap, install services but do not start them.")
    return parser


def run_agent_cli(argv=None):
    parser = build_parser()
    args, extra_args = parser.parse_known_args(argv)
    headless_modes = {"run", "prompt", "status", "tools", "sessions", "config", "interrupt"}
    if args.mode not in {"install-system-deps", "bootstrap", *headless_modes} and extra_args:
        parser.error(f"unrecognized arguments: {' '.join(extra_args)}")

    if args.mode in headless_modes:
        from . import headless
        handlers = {
            "run": headless.run_prompt,
            "prompt": headless.run_prompt,
            "status": headless.run_status,
            "tools": headless.run_tools,
            "sessions": headless.run_sessions,
            "config": headless.run_config,
            "interrupt": headless.run_interrupt,
        }
        handlers[args.mode](args, extra_args)
    elif args.mode == "chat":
        run_chat(args.url or f"http://{args.host}:{args.port}")
    elif args.mode == "install-service":
        path = install_user_service(host=args.host, port=args.port, enable=True, start=True)
        print(f"Installed and started user service: {path}")
    elif args.mode == "uninstall-service":
        path = uninstall_user_service(disable=True, stop=True)
        print(f"Uninstalled user service: {path}")
    elif args.mode == "install-system-deps":
        installer_args = extra_args
        if installer_args and installer_args[0] == "--":
            installer_args = installer_args[1:]
        raise SystemExit(run_system_deps_installer(installer_args))
    elif args.mode == "bootstrap":
        installer_args = extra_args
        if installer_args and installer_args[0] == "--":
            installer_args = installer_args[1:]
        raise SystemExit(run_bootstrap(
            host=args.host,
            port=args.port,
            system_deps_args=installer_args,
            install_system_deps=not args.no_system_deps,
            install_service=not args.no_service,
            start_service=not args.no_start_service,
        ))
    else:
        run_local(args.host, args.port)


def main(argv=None):
    load_runtime_env()
    from .root import dispatch
    dispatch(argv, fallback=run_agent_cli)


if __name__ == '__main__':
    main()
