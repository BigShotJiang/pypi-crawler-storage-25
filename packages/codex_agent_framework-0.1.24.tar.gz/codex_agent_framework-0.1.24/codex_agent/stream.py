import queue
import threading

from .message import UserMessage


class AgentStream:
    def __init__(self, agent, prompt=None):
        self.agent = agent
        self.prompt = prompt
        self.future = None
        self.mainloop_was_running = False
        self.events = queue.Queue()
        self._sentinel = object()
        self._closed = False
        self._error = None
        self._handler = None
        self._monitor_thread = None

    def start(self):
        self.mainloop_was_running = self.agent.mainloop_manager.thread is not None and self.agent.mainloop_manager.thread.is_alive()
        self._handler = self.agent.on("*", self._on_event)
        try:
            self.future = self._submit()
        except Exception:
            self.close()
            raise
        if self.future is None:
            self.close()
            raise RuntimeError("agent is already busy")
        self._monitor_thread = threading.Thread(target=self._monitor, name="agent-stream-monitor", daemon=True)
        self._monitor_thread.start()
        return self

    def _submit(self):
        if self.prompt is None:
            return self.agent.start_turn()
        if self.agent.command_manager.is_prompt(self.prompt):
            return self.agent.submit_command(self.prompt)
        result = self.agent.submit_message(UserMessage(content=self.prompt))
        return self.agent.mainloop_manager.futures[result.turn_id]

    def _on_event(self, event):
        self.events.put(event)
        return event

    def _monitor(self):
        try:
            self.future.wait()
        except Exception as exc:
            self._error = exc
        finally:
            self.close()
            if not self.mainloop_was_running:
                self.agent.stop(timeout=1.0)
            self.events.put(self._sentinel)

    def close(self):
        if self._closed:
            return
        self._closed = True
        if self._handler is not None:
            self.agent.events.off("*", self._handler)
            self._handler = None

    @property
    def turn(self):
        return self.future.wait()

    def __iter__(self):
        return self

    def __next__(self):
        item = self.events.get()
        if item is self._sentinel:
            if self._error is not None:
                raise self._error
            raise StopIteration
        return item
