# Changelog

All notable changes to this project will be documented in this file.

This project loosely follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and uses semantic versioning where practical.

## [0.1.24] - 2026-05-10
### Added
- Add dedicated slash-command lifecycle events, `SlashCommandStartEvent` and `SlashCommandDoneEvent`, with command name, arguments, status, result, and error metadata.

### Changed
- Show slash-command progress directly in the Textual TUI with running/done/failed status lines so commands such as `/compact` and `/help` no longer appear silent while executing.
- Render slash-command results and errors immediately in the TUI after completion.

### Tests
- Add regression coverage for slash-command lifecycle events, failed command reporting, and TUI rendering of command progress, results, and errors.

## [0.1.23] - 2026-05-10
### Added
- Add the SDK `Agent.stream(prompt=None)` API for iterating turn events while still exposing the final `AgentTurn` through `.turn`.
- Add root-level `Agent.add_plugin(plugin)` as a convenience API for registering plugin tools, providers, commands, hooks, and events.

### Changed
- Rework the README around a faster reader path: compact quick start, clearer Python API examples, grouped extension guidance, and updated runtime/CLI documentation.
- Change the default runtime directory from `~/.agent_runtime` to `~/.codex-agent` and align tests, services, examples, and ignore rules with the new location.
- Disable voice by default so SDK agents with OpenAI keys remain text-first unless voice is explicitly enabled.
- Make bare `codex-agent` attach to an already-running local server when available, otherwise start a temporary TUI-bound server.
- Improve TUI tool-call display with immediate start/done lines, ordered text flushing before tools, compact status icons, shortened call IDs, and cleaner terminal launch environment handling.

### Fixed
- Restrict prompt templating to `SystemMessage` content so developer messages, user messages, assistant messages, and tool outputs remain literal.
- Prevent TUI tool-call start events from being buffered until step completion, allowing long-running tool calls to show immediately.

### Tests
- Add regression coverage for SDK streaming, root plugin registration, runtime directory defaults, CLI local-server attachment, message templating scope, TUI tool-call ordering/rendering, and terminal environment sanitization.

## [0.1.22] - 2026-05-10
### Changed
- Harden the FastAPI/SSE bridge and Textual TUI streaming path after a stabilization audit: finite SSE read timeouts, batched live deltas, synchronous replay delta flushes, and explicit stale-subscriber replacement shutdowns.
- Improve process-backed runtime robustness with guarded startup, isolated event handlers, and clearer cached status/turn-state updates.
- Consolidate shared helpers for type hierarchy, turn outcomes, atomic session writes, tool exclusion matching, context truncation, and subagent child creation while removing smaller duplicated or dead helper paths.
- Publish the package version from a single `codex_agent.version` module and use it for FastAPI metadata.

### Fixed
- Prevent stale SSE subscribers from lingering silently when a replacement TUI stream connects.
- Avoid concurrent subscriber-table mutation during event publication and serialize persisted turn-event rewrite/append operations.
- Preserve replay ordering in the TUI so caught-up deltas render before newly batched live stream deltas.
- Keep one failing process-runtime event handler from stopping delivery to later handlers.

### Tests
- Validate post-restart API/import/runtime smoke tests after a real server restart.
- Validate `pyflakes codex_agent tests`, targeted server/client/chat smoke tests, and the full suite at 489 passing tests.

## [0.1.21] - 2026-05-10
### Added
- Add the structured `AgentTurn` API: `agent(...)` and `AgentFuture.wait()` now return a turn object with `result`, `completed`, `reason`, `messages`, and `events`.
- Add resumable non-terminal turns for `auto_proceed=False`; turns that need another model step pause with `reason="requires_next_step"` and continue through `agent.resume_turn(turn)`.
- Add `agent.set_turn_result(data)` for tools/plugins that need to explicitly finish the current turn with a structured result.
- Add the built-in `subagents` plugin with profile-based child agents, compact parent results, child-local `set_result`, `SubagentEvent` relay, and a packaged read-only `explorer` profile.
- Add hierarchical `types` to messages and events while keeping `type` as the concrete computed type.
- Add configurable `exclude_tools` matching by public or canonical plugin tool names.

### Changed
- Treat scheduled and post-restart wakeups as internal `DeveloperMessage` entries instead of user-authored messages.
- Make `AssistantTurnEndEvent` expose a terminal `reason` rather than carrying a raw result payload.
- Capture turn-local events and messages on `AgentTurn` so embedded callers can inspect what happened without replaying the whole session.
- Include packaged subagent profile JSON files in distributions.
- Refresh the packaged default system prompt around agent identity, clarification, durable fixes, and concise final reporting.

### Fixed
- Preserve coherent turn state across suspended/resumed turns, including stable turn IDs, non-terminal suspension without a turn-end event, and terminal completion on resume.

### Tests
- Validate the full suite at 483 passing tests.
- Validate post-restart wakeups after a real server restart and smoke-test `auto_proceed=False` `AgentTurn` suspension/resume behavior.

## [0.1.20] - 2026-05-09
### Added
- Make runtime plugins the single user-facing extension unit for tools, providers, commands, prompt sections, hooks, and events.
- Add explicit `ToolsManager` and `ProvidersManager` ownership in `tool.py` and `provider.py`.

### Changed
- Move built-in tools and providers into built-in plugins so the core no longer special-cases `builtin_tools` or `builtin_providers` packages.
- Keep SDK-style `agent.add_tool()` and `agent.add_provider()` while routing persistent runtime extensions through plugins.
- Keep system-prompt templating on a small explicit namespace: `agent`, `os`, `runtime_join`, `root_join`, and `text_content`.
- Refresh README extension, plugin, runtime, and project-layout documentation around the plugin-centric architecture.

### Removed
- Remove the old `RegistryManager` and `codex_agent/registry.py`.
- Remove legacy direct runtime loading from `tools/` and `providers/` folders.
- Remove the compatibility `codex_agent.builtin_tools` package, `codex_agent.builtin_providers` module, and related compatibility aliases.

### Tests
- Validate the full suite at 456 passing tests.

## [0.1.19] - 2026-05-08
### Changed
- Compacting a session now purges compacted raw history from the active session file, keeping only the previous compaction anchor, the new compaction summary, and any unfinished remainder turn.
- Drop compaction summaries older than the latest anchor from active session files because each new compaction already incorporates the previous anchor.

### Tests
- Add regression coverage for compaction prefix pruning, latest-anchor replay, older compaction removal, persisted session shape, and status/event message counts.
- Validate the full suite at 450 passing tests.

## [0.1.18] - 2026-05-08
### Added
- Add generic plugin event and hook handler discovery so plugins can react to agent lifecycle events without hard-coded core coupling.
- Add core browser and desktop controller modules used by extraction and vision helpers, while keeping browser and desktop plugins as agent-facing tool/provider facades.
- Add memory retrieval XML timestamps and sources so retrieved RAG memories expose freshness metadata to the model.

### Changed
- Make `codex-agent start server` and `codex-agent start tray` detach by default, with `--foreground` retained for supervised service managers.
- Move durable RAG memory fully into the built-in memory plugin, including configuration, commands, tools, retrieval provider, and auto-archive event handling.
- Keep scheduled wakeups as a core runtime/server primitive while simplifying the scheduler plugin into an agent-facing facade.
- Refresh the README around startup modes, runtime files, plugin responsibilities, memory configuration, server endpoints, and the current project layout.

### Removed
- Remove core memory surfaces such as `agent.memory`, the `/memory` server endpoint, `status.memory_entries`, and the `codex_agent.memory` module.
- Remove plugin-owned browser/desktop backend controller modules now that those controllers live in core modules.

### Tests
- Validate the full suite at 449 passing tests.

## [0.1.17] - 2026-05-08
### Changed
- Reorganize the Textual TUI into the `codex_agent.tui` package, splitting chat UI code from TUI lifecycle helpers.
- Reorganize the FastAPI bridge into the `codex_agent.server` package, separating server core/service logic from app and route creation.
- Remove the obsolete `Message.lasting` field now that message visibility is controlled by `turns_left`, reducing serialized payload noise.

### Removed
- Remove the old flat `codex_agent.chat` and `codex_agent.tui` modules in favor of the new package layout.

### Tests
- Validate the full suite at 442 passing tests.

## [0.1.16] - 2026-05-08
### Fixed
- Allow agent startup without an OpenAI API key by disabling OpenAI-dependent capabilities such as voice defaults and the built-in memory plugin instead of failing during initialization.
- Skip automatic memory archiving when the memory plugin is unavailable.

### Tests
- Add regression coverage for agent initialization with and without an OpenAI API key.

## [0.1.15] - 2026-05-08
### Added
- Add `AgentRuntime` as the canonical external runtime contract for HTTP server, headless CLI, in-process, and process-backed integrations.
- Add structured runtime configuration updates through `PATCH /config`, `AgentClient.update_config()`, and `codex-agent config set`.
- Add direct built-in selection config for tools, providers, and plugins with `None` meaning all built-ins, an empty list meaning none, and explicit lists selecting named built-ins.

### Changed
- Split the command line implementation into the `codex_agent.cli` package with root orchestration commands and headless runtime commands.
- Route server operations through `AgentRuntime` instead of depending on `Agent` internals directly.
- Update CLI service/interface commands to the explicit `start/stop/restart server|tray` and `open/close tui` forms.

### Tests
- Add regression coverage for the runtime abstraction, headless CLI, root CLI dispatch, config updates, and built-in selection.
- Validate the targeted release-regression suite at 82 passing tests.

## [0.1.14] - 2026-05-07
### Added
- Add a general `HookManager` with compatibility helpers and hook sites around message submission, commands, context/provider calls, runtime module loading, tool calls, shell execution, and file write/edit operations.
- Add planner and scheduler built-in plugins with atomic JSON persistence safeguards.
- Add `dependencies.txt` documenting non-Python system dependencies for browser, desktop, tray, service, TUI terminal, and audio features.
- Add packaged system dependency installation via `codex-agent install-system-deps` and a higher-level `codex-agent bootstrap` command that can install system dependencies then install/start the user services.

### Changed
- Improve TUI SSE replay/reconnect handling so replayed deltas are rendered as a compact catch-up while live deltas continue streaming normally.
- Keep the TUI reconnection status concise by reporting one offline message per outage and a connected message on recovery.

### Fixed
- Fix SSE cursor tracking so client replay state advances only from real sequenced events, avoiding missed events after reconnects.
- Surface asynchronous memory archive failures through `MemoryArchiveErrorEvent` instead of swallowing them silently.
- Clarify scheduler wakeup trigger event data around `turn_id` while preserving backward compatibility.

### Tests
- Expand regression coverage for hooks, planner schema/loading, scheduler persistence, TUI reconnect/replay behavior, CLI bootstrap/system dependency commands, and memory archive errors.
- Validate the full suite at 412 passing tests.

## [0.1.13] - 2026-05-07
### Changed
- Reorganize built-in tools into a `codex_agent.builtin_tools` package with separate modules for file, shell, vision, system, and server-tool responsibilities.
- Keep the public `codex_agent.builtin_tools` import surface compatible by re-exporting the existing built-in tools and helpers from the package initializer.

### Tests
- Update built-in tool regression coverage for the package layout and validate the full suite at 376 passing tests.

## [0.1.12] - 2026-05-05
### Added
- Add a persistent Playwright/Chromium browser controller with tools to open/close the browser, select tabs, navigate, click, fill, select options, press keys, inspect action snapshots, and capture screenshots.
- Add `browser_goto(url)` to navigate the active tab without opening or switching tabs.
- Add screenshot-backed visual fallback for pages where DOM snapshots are insufficient, including PDF viewers and image-heavy pages.

### Changed
- Replace the Selenium/Gecko rendered extraction path with Playwright-managed Chromium.
- Update web extraction dependencies and documentation to install Chromium with Playwright.

### Tests
- Add browser controller and rendered extraction regression coverage.

## [0.1.11] - 2026-05-05
### Added
- Add a separate `view` tool for folders, URLs, rich document extraction, and Python object inspection.
- Add context status counts for persistent and temporary session messages, surfaced in the TUI status bar.

### Changed
- Make `read` a strict local UTF-8 file reader with reliable forced line numbers and regex pattern search by default.
- Keep extracted `view` output unnumbered, including search snippets, because transformed document line structure is not source-of-truth reliable.
- Update the system prompt to direct agents to use `read` before targeted edits and `view` for broad extraction.

### Fixed
- Preserve blank lines and real source line numbers in `read` pattern snippets.
- Apply line-based pagination before token truncation.

### Tests
- Add regression coverage for strict `read`, unnumbered `view`, blank-line preservation, regex/literal search, and persistent/temporary message status counts.

## [0.1.10] - 2026-05-05
### Fixed
- Persist only backend `compaction_summary` items in compaction messages, avoiding bulky compacted conversation payloads while preserving summary replay.
- Sanitize encrypted compaction summaries in local token estimates and refresh cached context status after compaction/message updates.

### Tests
- Add regression coverage for compaction payload filtering, legacy `output_items` migration, context status cache invalidation, and runtime status updates after compaction.

## [0.1.9] - 2026-05-05
### Changed
- Maintenance release for the packaged distribution after validating the updated local execution environment and deploy workflow.

## [0.1.8] - 2026-05-05
### Changed
- Scope TUI startup replay and SSE catch-up events to the current session so reopening the UI after session navigation cannot replay turns from another session.
- Make the agent process normalize its execution environment from `sys.executable`, putting the project interpreter first on `PATH` and exposing `PYTHON` / `PYTHON_EXECUTABLE`.
- Generate systemd and launchd service definitions with the project Python environment propagated explicitly to server and tray processes.

### Fixed
- Ensure the agent `bash` tool resolves `python` and `pytest` from the environment where `codex-agent-framework` is installed, even when launched by a minimal service manager environment.
- Preserve direct `agent.tools.<name>(...)` calls by binding registered tools back to their owning agent for runtime context lookup.

### Tests
- Add regression coverage for session-scoped replay, same-session SSE catch-up filtering, service environment generation, and bash tool Python resolution.

## [0.1.7] - 2026-05-05
### Added
- Add durable RAG memory backed by `memory.json`, with memory entries modeled as developer messages and retrieved by semantic similarity plus optional recency scoring.
- Add memory tools for creating, editing, deleting, and searching entries, with XML-formatted search output.
- Add automatic fire-and-forget turn summarization into memory after completed agent turns.
- Add scheduled wakeups backed by `wakeups.json`, including one-shot and periodic wakeups plus server restart wakeup recovery.
- Add a desktop tray controller, user service install/uninstall helpers, and agent tools/endpoints to open or close the TUI.
- Add `/status`, `/wakeups`, `/tui`, `/events/replay`, and related server endpoints for a purely client-driven TUI.
- Add compact UI status data for context usage, message ratio, WHAM quota percentages, and current model.

### Changed
- Run the long-lived agent in a separate worker process behind the FastAPI bridge so the server remains responsive while the agent is busy.
- Make the Textual TUI robust to server restarts and reconnects by replaying the latest turn, tracking SSE event sequence cursors, and allowing same-client SSE replacement.
- Remove SSE read timeouts for the event stream while keeping immediate reconnect attempts after connection loss.
- Improve token counting by making messages responsible for cached API token estimates and including tool specs in context estimates.
- Treat leading system messages as Responses API instructions rather than ordinary history messages.
- Remove the legacy Streamlit dependency and replace `PyPDF2` with `pypdf`.

### Fixed
- Prevent stale SSE subscribers from blocking a reconnecting TUI with a false second-client error.
- Prevent local TUI handler errors from being displayed as server disconnects.
- Truncate long embedding inputs to avoid backend embedding context length errors.
- Add `audioop-lts` for Python 3.13+ compatibility with `pydub`.

### Tests
- Expand coverage for memory, token estimates, server replay, SSE reconnects, process runtime shutdown, tray/service helpers, scheduler wakeups, and TUI status behavior.

## [0.1.6] - 2026-05-04
### Added
- Add an async-style agent mainloop with command futures so turns and state mutations can be coordinated through one runtime.
- Add a FastAPI REST/SSE bridge and an `AgentClient` HTTP/SSE client for decoupled interfaces.
- Add CLI modes for local embedded server + TUI client, server-only, and client-only chat operation.

### Changed
- Decouple the Textual chat UI from direct `Agent` access; the TUI now communicates with the server through HTTP and SSE.
- Stream lightweight response deltas instead of cumulative content, reducing SSE traffic and client backpressure.
- Use unbounded subscriber queues with ping events for more reliable SSE client delivery.

### Tests
- Add coverage for the server bridge, HTTP/SSE client, async runtime behavior, CLI modes, and event lifecycle.

## [0.1.5] - 2026-05-03
### Changed
- Refine the default Textual chat UI with a pure black background, black multiline input area, subtler scrollbars, a smaller step-end marker, and English UI labels.


## [0.1.4] - 2026-05-03
### Added
- Make the Textual REPL UI the default chat interface, with multiline input, subdued colors, visual speaker separators, step-end markers, and cleaner tool-call rendering.
- Add assistant turn and assistant step lifecycle events for UI and runtime integrations.
- Add a `/voice` command to show, toggle, or select the configured voice mode.

### Changed
- Remove the legacy prompt-toolkit chat UI and the temporary `--textual` CLI flag.

### Tests
- Add CLI coverage for starting the default chat UI and update chat status formatting tests.


## [0.1.3] - 2026-05-03
### Added
- Send the current session id as `prompt_cache_key` to the Codex backend, enabling server-side prompt cache reuse across calls from the same session.

### Tests
- Add regression coverage for prompt cache key propagation through agent response calls and Codex stream parameters.


## [0.1.2] - 2026-05-03
### Added
- Add a `/clear` terminal chat command that clears the screen without touching session history.

### Tests
- Add regression coverage ensuring terminal screen clearing does not append session messages.


## [0.1.1] - 2026-05-03
### Fixed
- Validate `ImageMessage` content before adding it to session state.
- Prevent invalid or inaccessible observed images from polluting a session and breaking later SDK calls.

### Tests
- Add regression coverage for valid and invalid `ImageMessage` validation.
- Verify `Agent.add_image()` rejects invalid images without appending a broken session message.


## [0.1.0] - 2026-05-03

### Added

- Initial package metadata and console entry point.
- Event-driven agent runtime, session persistence, tools, providers, commands, voice, image, and document extraction modules.
- Test suite for core agent behavior, events, messages, image messages, utilities, and workers.
