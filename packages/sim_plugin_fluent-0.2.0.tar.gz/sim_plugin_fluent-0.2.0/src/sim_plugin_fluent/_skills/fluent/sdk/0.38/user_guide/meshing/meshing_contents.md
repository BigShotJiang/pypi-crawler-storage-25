# Meshing workflow #

The guided workflows in Fluent meshing are designed to make it easier to generate a volume mesh starting from CAD geometries. You can use PyFluent to access the guided workflows.

Workflows are divided into the new Meshing workflows and Classic meshing workflow, which align with the journal syntax.
