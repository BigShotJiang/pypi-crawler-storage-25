# Changelog

## 0.2.0 - 2026-05-07

- Added live Fluent health, version, model, boundary, case, mesh, field, and file inspect targets.
- Improved launch option normalization and PyFluent SDK keyword compatibility.
- Expanded Fluent artifact classification for case, data, mesh, journal, transcript, table, image, CSV, and JSON outputs.
- Reworked the bundled Fluent skill around live sim sessions, direct PyFluent scripts, and file-side artifact review.
- Updated package metadata and release automation for PyPI publication.
