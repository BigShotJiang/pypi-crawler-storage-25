# ylclab-single-cell-metabolomics/tests/test_batch_correction.py
import json
import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import pytest
from pathlib import Path
from single_cell_metabolomics.batch_correction import BatchCorrectionExecutor


# ---------------------------------------------------------------------------
# Fixture — 20 samples x 10 features, 2 batches (10 each), COO parquet
# with string row/col + metadata CSV with batch column
# ---------------------------------------------------------------------------
@pytest.fixture
def bc_data(tmp_path):
    """20 samples x 10 features with 2 batches of 10 samples each."""
    rng = np.random.default_rng(42)
    n_samples, n_features = 60, 10
    samples = [f'sample_{i}' for i in range(n_samples)]
    features = [f'negative_{100.0 + i * 10}' for i in range(n_features)]

    # Generate data with a batch effect: batch_B shifted up by 50
    values = rng.uniform(50, 500, (n_samples, n_features))
    half = n_samples // 2
    values[half:, :] += 50  # batch effect

    # Build COO parquet with VARCHAR row/col (production format)
    rows = []
    for si, sample in enumerate(samples):
        for fi, feat in enumerate(features):
            rows.append({'row': feat, 'col': sample, 'value': float(values[si, fi])})
    df = pd.DataFrame(rows)
    parquet_path = str(tmp_path / 'matrix.parquet')
    pq.write_table(pa.Table.from_pandas(df, preserve_index=False), parquet_path)

    # Name TSV files (single-column headerless format)
    row_tsv = tmp_path / 'row.tsv'
    row_tsv.write_text('\n'.join(features))
    col_tsv = tmp_path / 'col.tsv'
    col_tsv.write_text('\n'.join(samples))

    # Metadata CSV with batch column
    meta_df = pd.DataFrame({
        'batch': ['batch_A'] * half + ['batch_B'] * half,
    }, index=samples)
    meta_path = str(tmp_path / 'metadata.csv')
    meta_df.to_csv(meta_path)

    return parquet_path, str(row_tsv), str(col_tsv), meta_path, n_samples, n_features


def make_executor(bc_data):
    parquet_path, row_path, col_path, meta_path, _, _ = bc_data
    return BatchCorrectionExecutor(parquet_path, row_path, col_path, meta_path)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_combat_preserves_dimensions(bc_data):
    """ComBat output shape matches input."""
    ex = make_executor(bc_data)
    n_samples, n_features = bc_data[4], bc_data[5]
    ex.correct_combat(batch_column='batch')
    assert ex.adata.X.shape == (n_samples, n_features)


def test_combat_output_is_coo_parquet(bc_data, tmp_path):
    """Corrected parquet has row, col, value columns."""
    ex = make_executor(bc_data)
    ex.correct_combat(batch_column='batch')
    out_path = str(tmp_path / 'corrected.parquet')
    ex.write_corrected_parquet(out_path)
    out_df = pq.read_table(out_path).to_pandas()
    assert set(out_df.columns) == {'row', 'col', 'value'}
    # All finite values should be present
    n_finite = np.isfinite(ex.adata.X).sum()
    assert len(out_df) == n_finite


def test_harmony_preserves_dimensions(bc_data):
    """Harmony output shape matches input."""
    ex = make_executor(bc_data)
    n_samples, n_features = bc_data[4], bc_data[5]
    ex.correct_harmony(batch_column='batch')
    assert ex.adata.X.shape == (n_samples, n_features)


def test_harmony_z_corr_not_transposed(bc_data):
    """Verify Harmony Z_corr produces correct shape (bug #734 regression test).

    After Harmony correction, the matrix should remain (n_samples, n_features),
    NOT (n_features, n_samples). If Z_corr were transposed, the reconstructed
    matrix would have swapped dimensions.
    """
    ex = make_executor(bc_data)
    n_samples, n_features = bc_data[4], bc_data[5]
    ex.correct_harmony(batch_column='batch')
    assert ex.adata.X.shape[0] == n_samples, (
        f"Expected {n_samples} rows (samples), got {ex.adata.X.shape[0]} — Z_corr may be transposed"
    )
    assert ex.adata.X.shape[1] == n_features, (
        f"Expected {n_features} cols (features), got {ex.adata.X.shape[1]} — Z_corr may be transposed"
    )


def test_limma_preserves_dimensions(bc_data):
    """limma output shape matches input."""
    ex = make_executor(bc_data)
    n_samples, n_features = bc_data[4], bc_data[5]
    ex.correct_limma(batch_column='batch')
    assert ex.adata.X.shape == (n_samples, n_features)


def test_emit_sentinel_writes_json(bc_data, tmp_path, monkeypatch):
    """Sentinel file created with correct fields."""
    monkeypatch.chdir(tmp_path)
    ex = make_executor(bc_data)
    ex.compute_pca_before()
    ex.correct_combat(batch_column='batch')
    ex.compute_pca_after()

    out_parquet = str(tmp_path / 'corrected.parquet')
    ex.write_corrected_parquet(out_parquet)

    row_out = str(tmp_path / 'row_out.tsv')
    col_out = str(tmp_path / 'col_out.tsv')
    ex.write_tsv_files(row_out, col_out)

    ex.emit_sentinel(
        serial_number='TEST001',
        dataset_uid=1,
        analysis_id=103,
        storage_path=out_parquet,
        row_path=row_out,
        column_path=col_out,
        batch_column='batch',
        bio_color_label='',
    )
    sentinel_file = tmp_path / 'batch_correction_metadata.json'
    assert sentinel_file.exists()
    sentinel = json.loads(sentinel_file.read_text())
    for field in ['serial_number', 'dataset_uid', 'pipeline_stage', 'analysis_id',
                  'storage_path', 'row_path', 'column_path',
                  'pca_before', 'pca_after',
                  'pca_variance_ratio_before', 'pca_variance_ratio_after',
                  'batch_labels', 'bio_labels', 'status']:
        assert field in sentinel, f"Missing field: {field}"
    assert sentinel['status'] == 'completed'
    assert sentinel['storage_path'].startswith('/')
