# ylclab-single-cell-metabolomics/tests/test_clustering.py
import json
import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import pytest
from single_cell_metabolomics.clustering import ClusteringExecutor


N_SAMPLES = 30
N_FEATURES = 10


@pytest.fixture
def clustering_data(tmp_path):
    """30 samples x 10 features COO parquet (VARCHAR row/col) + embedding + metadata."""
    rng = np.random.default_rng(42)

    sample_names = [f'sample_{i}' for i in range(N_SAMPLES)]
    feature_names = [f'feature_{i}' for i in range(N_FEATURES)]

    # Build COO parquet with string row/col
    rows = []
    for s_name in sample_names:
        for f_name in feature_names:
            rows.append({'row': f_name, 'col': s_name, 'value': float(rng.uniform(1, 100))})
    coo_df = pd.DataFrame(rows)
    parquet_path = str(tmp_path / 'matrix.parquet')
    pq.write_table(pa.Table.from_pandas(coo_df, preserve_index=False), parquet_path)

    # Row TSV (single-column headerless — feature names)
    row_tsv = tmp_path / 'row.tsv'
    row_tsv.write_text('\n'.join(feature_names))

    # Col TSV (single-column headerless — sample names)
    col_tsv = tmp_path / 'col.tsv'
    col_tsv.write_text('\n'.join(sample_names))

    # Embedding parquet (cell_name, component_1, component_2)
    emb_df = pd.DataFrame({
        'cell_name': sample_names,
        'component_1': rng.standard_normal(N_SAMPLES).tolist(),
        'component_2': rng.standard_normal(N_SAMPLES).tolist(),
    })
    emb_path = str(tmp_path / 'embedding.parquet')
    pq.write_table(pa.Table.from_pandas(emb_df, preserve_index=False), emb_path)

    # Metadata CSV (index = sample name, one grouping column)
    meta_df = pd.DataFrame({
        'group': ['A'] * 10 + ['B'] * 10 + ['C'] * 10,
    }, index=sample_names)
    meta_path = str(tmp_path / 'metadata.csv')
    meta_df.to_csv(meta_path)

    return {
        'parquet_path': parquet_path,
        'row_path': str(row_tsv),
        'col_path': str(col_tsv),
        'embedding_path': emb_path,
        'metadata_path': meta_path,
        'sample_names': sample_names,
        'feature_names': feature_names,
    }


def make_executor(data):
    return ClusteringExecutor(
        matrix_data_path=data['parquet_path'],
        matrix_row_path=data['row_path'],
        matrix_column_path=data['col_path'],
        embedding_path=data['embedding_path'],
        metadata_path=data['metadata_path'],
    )


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_leiden_produces_labels(clustering_data):
    """Leiden assigns a cluster label to each sample."""
    ex = make_executor(clustering_data)
    ex.cluster_leiden(n_pcs=5, n_neighbors=5, resolution=1.0)
    assert len(ex.cluster_labels_all) == N_SAMPLES
    assert all(isinstance(lbl, str) for lbl in ex.cluster_labels_all)


def test_leiden_label_count(clustering_data):
    """Number of labels equals n_samples."""
    ex = make_executor(clustering_data)
    ex.cluster_leiden(n_pcs=5, n_neighbors=5, resolution=1.0)
    assert len(ex.cluster_labels_all) == len(clustering_data['sample_names'])


def test_louvain_produces_labels(clustering_data):
    """Louvain works and produces labels for all samples."""
    ex = make_executor(clustering_data)
    ex.cluster_louvain(n_pcs=5, n_neighbors=5, resolution=1.0)
    assert len(ex.cluster_labels_all) == N_SAMPLES
    assert all(isinstance(lbl, str) for lbl in ex.cluster_labels_all)


def test_kmeans_produces_labels(clustering_data):
    """k-means with n_clusters=3 produces exactly 3 clusters."""
    ex = make_executor(clustering_data)
    ex.cluster_kmeans(n_clusters=3)
    assert len(ex.cluster_labels_all) == N_SAMPLES
    unique_labels = set(ex.cluster_labels_all)
    assert len(unique_labels) == 3, f"Expected 3 clusters, got {len(unique_labels)}: {unique_labels}"


def test_emit_sentinel_writes_json(clustering_data, tmp_path, monkeypatch):
    """Sentinel file contains cluster_labels and cluster_sizes."""
    monkeypatch.chdir(tmp_path)
    ex = make_executor(clustering_data)
    ex.cluster_kmeans(n_clusters=3)

    ex.emit_sentinel(
        serial_number='TEST001',
        dataset_uid=1,
        analysis_id=106,
        storage_path='cluster_labels.parquet',
        row_path=clustering_data['row_path'],
        column_path=clustering_data['col_path'],
        color_label='group',
        dr_method='UMAP',
        clustering_method='k-means',
    )

    sentinel_file = tmp_path / 'clustering_metadata.json'
    assert sentinel_file.exists(), "Sentinel file was not written"
    sentinel = json.loads(sentinel_file.read_text())

    # Required fields
    for field in ['serial_number', 'dataset_uid', 'pipeline_stage', 'analysis_id',
                  'storage_path', 'cluster_labels', 'cluster_sizes', 'status']:
        assert field in sentinel, f"Missing field: {field}"

    assert sentinel['status'] == 'completed'
    assert sentinel['storage_path'].startswith('/')
    assert isinstance(sentinel['cluster_labels'], list)
    assert isinstance(sentinel['cluster_sizes'], dict)
    assert len(sentinel['cluster_sizes']) == 3
