"""Tool Spotlight: Azure Craft"""
__version__ = "1.0.0"
