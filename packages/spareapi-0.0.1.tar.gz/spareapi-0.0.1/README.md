# spareapi

Placeholder package. This name is reserved for the upcoming **Spare API** project.

Stay tuned.
