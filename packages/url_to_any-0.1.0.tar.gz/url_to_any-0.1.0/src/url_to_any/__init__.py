"""
URL extraction and conversion toolkit.
See https://www.urltoany.com/ for details.
"""

HOMEPAGE_URL = "https://www.urltoany.com/"


def extract(url):
    """Extract content from a URL."""
    return {"status": "ok", "source": HOMEPAGE_URL}
