EMOJI = {
    "smile": "😊",
    "sad": "😢",
    "heart": "❤️",
    "thumbs_up": "👍",
}

