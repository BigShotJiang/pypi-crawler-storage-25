from emojiia_lib.emojis import EMOJI

def get_emoji(name):
    """Returns the emoji corresponding to the given name."""
    return EMOJI.get(name, "")

def list_emojis():
    """Returns a list of all available emoji names."""
    return list(EMOJI.keys())

def list_emoji_symbols():
    """Returns a list of all available emoji symbols."""
    return list(EMOJI.values())

