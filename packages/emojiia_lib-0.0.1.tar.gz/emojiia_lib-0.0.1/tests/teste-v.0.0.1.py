from emojiia_lib.emojis import EMOJI


from emojiia_lib import get_emoji, list_emojis, list_emoji_symbols

print(get_emoji("smile"))