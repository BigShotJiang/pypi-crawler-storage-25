"""Tests for pixie.instrumentation.context — ObservationContext."""

from __future__ import annotations

import pytest

import pixie.instrumentation as px
from pixie.instrumentation.spans import ObserveSpan

from .conftest import RecordingHandler


class TestSpanContextSetters:
    """Tests for set_output() and set_metadata()."""

    def test_set_output(self, recording_handler: RecordingHandler) -> None:
        px.init()
        px.add_handler(recording_handler)
        with px.start_observation(input="q") as observation:
            observation.set_output("answer")
        px.flush()
        assert len(recording_handler.observe_spans) == 1
        assert recording_handler.observe_spans[0].output == "answer"

    def test_set_metadata(self, recording_handler: RecordingHandler) -> None:
        px.init()
        px.add_handler(recording_handler)
        with px.start_observation(input=None) as observation:
            observation.set_metadata("k1", "v1")
            observation.set_metadata("k2", 42)
        px.flush()
        obs = recording_handler.observe_spans[0]
        assert obs.metadata == {"k1": "v1", "k2": 42}


class TestSpanContextSnapshot:
    """Tests for _snapshot() producing correct frozen ObserveSpan."""

    def test_snapshot_produces_observe_span(
        self, recording_handler: RecordingHandler
    ) -> None:
        px.init()
        px.add_handler(recording_handler)
        with px.start_observation(input="hello", name="test_block") as observation:
            observation.set_output("world")
        px.flush()

        obs = recording_handler.observe_spans[0]
        assert isinstance(obs, ObserveSpan)
        assert obs.input == "hello"
        assert obs.output == "world"
        assert obs.name == "test_block"
        assert obs.error is None
        assert len(obs.span_id) == 16
        assert len(obs.trace_id) == 32

    def test_snapshot_with_default_name(
        self, recording_handler: RecordingHandler
    ) -> None:
        px.init()
        px.add_handler(recording_handler)
        with px.start_observation(input=None):
            pass
        px.flush()
        obs = recording_handler.observe_spans[0]
        assert obs.name == "observe"

    def test_snapshot_timing(self, recording_handler: RecordingHandler) -> None:
        px.init()
        px.add_handler(recording_handler)
        with px.start_observation(input=None):
            pass
        px.flush()
        obs = recording_handler.observe_spans[0]
        assert obs.started_at is not None
        assert obs.ended_at is not None
        assert obs.duration_ms >= 0


class TestSpanContextError:
    """Tests for exception handling inside start_observation() blocks."""

    def test_exception_sets_error_field(
        self, recording_handler: RecordingHandler
    ) -> None:
        px.init()
        px.add_handler(recording_handler)
        with (
            pytest.raises(ValueError, match="test error"),
            px.start_observation(input="q"),
        ):
            raise ValueError("test error")
        px.flush()
        obs = recording_handler.observe_spans[0]
        assert obs.error == "ValueError"

    def test_exception_is_reraised(self, recording_handler: RecordingHandler) -> None:
        px.init()
        px.add_handler(recording_handler)
        with pytest.raises(RuntimeError), px.start_observation(input=None):
            raise RuntimeError("boom")


class TestSpanContextNesting:
    """Tests for nesting start_observation() blocks."""

    def test_nested_parent_span_id(self, recording_handler: RecordingHandler) -> None:
        px.init()
        px.add_handler(recording_handler)
        with px.start_observation(input=None, name="outer"):  # noqa: SIM117
            with px.start_observation(input=None, name="inner"):
                pass
        px.flush()

        assert len(recording_handler.observe_spans) == 2
        # Inner is submitted first (innermost finally runs first)
        inner_obs = recording_handler.observe_spans[0]
        outer_obs = recording_handler.observe_spans[1]
        assert inner_obs.name == "inner"
        assert outer_obs.name == "outer"
        # Inner's parent should be outer's span_id
        assert inner_obs.parent_span_id == outer_obs.span_id
        # They share the same trace_id
        assert inner_obs.trace_id == outer_obs.trace_id


class TestNoOpContext:
    """Tests for no-op behavior when init() has not been called."""

    def test_start_observation_without_init_yields_noop(self) -> None:
        """start_observation() should not raise when init() not called."""
        # Do NOT call px.init()
        with px.start_observation(input="hello") as observation:
            observation.set_output("world")
            observation.set_metadata("key", "value")
        # No error, no span captured — just a no-op

    def test_noop_context_set_output_is_silent(self) -> None:
        with px.start_observation(input="q") as observation:
            observation.set_output("a")
        # No crash, no side effects

    def test_noop_context_set_metadata_is_silent(self) -> None:
        with px.start_observation(input="q") as observation:
            observation.set_metadata("k", "v")
        # No crash, no side effects

    def test_noop_context_exception_still_propagates(self) -> None:
        """Exceptions inside the block should still propagate normally."""
        with pytest.raises(ValueError, match="boom"), px.start_observation(input="q"):
            raise ValueError("boom")

    def test_noop_does_not_submit_to_queue(self) -> None:
        """No span should be submitted when tracing is not initialized."""
        with px.start_observation(input="q") as observation:
            observation.set_output("a")
        # State has no delivery queue — nothing to check, just no crash
