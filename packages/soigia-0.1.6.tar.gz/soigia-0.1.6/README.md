# soigia

`soigia` is a Python SDK centered on `soigia.datatable.DataTable`.

## Getting Started

```bash
pip install soigia
```

```python
import soigia

df = soigia.DataTable({"name": ["alice"], "age": [19]})
print(df)
```

For local development:

```bash
pip install -e .
```

It gives you a pandas-like dataframe wrapper with extra helpers for:

- creating and transforming tabular data
- filtering, sorting, grouping, joining, and schema validation
- version snapshots and change tracking
- SQL-backed data loading
- Google Sheets import/export
- fake data generation for tests and demos

## Install

Install the package from PyPI:

```bash
pip install soigia
```

Install from source while developing:

```bash
pip install -e .
```

## Optional Features

Some helpers need extra packages that are not part of the base install.

- Google Sheets helpers usually need `gspread` and Google service-account support.
- Shared account config screens need `pyyaml`.
- Jinja template examples need `jinja2`.
- Excel helpers need an Excel engine such as `openpyxl`.
- Parquet and Feather helpers need a parquet/arrow backend such as `pyarrow`.
- Fake data helpers work best with `faker`, but `soigia` also includes a small fallback generator.

## Quick Start

```python
from soigia.datatable import DataTable

df = DataTable({"name": ["alice", "bob"], "age": [19, 24]})

print(df)
print(df.shape)
print(df.columns.tolist())
```

`DataTable` is a subclass of `pandas.DataFrame`, so normal pandas-style operations still work.

You can also import it from the package root:

```python
import soigia

df = soigia.DataTable({"name": ["alice"], "age": [19]})
```

## UI Apps

`soigia.ui` is a one-file declarative UI layer built on top of Streamlit for quick internal web apps and management screens.

Use it when you want to declare inputs, tables, text, and actions in a single file and let the framework render the interface for you.

```python
from soigia.ui import ui

orders = [
    {"id": 1, "customer": "Alice", "amount": 120.0, "status": "paid"},
    {"id": 2, "customer": "Bob", "amount": 88.5, "status": "pending"},
]

@ui.page("Orders")
def orders_page(ctx):
    ui.text("Order Dashboard")
    keyword = ui.text_input("Search")
    ui.metric("Total orders", len(orders))
    ui.table(lambda: [row for row in orders if keyword.value.lower() in row["customer"].lower()])
    with ui.form("Update order", submit_label="Save"):
        ui.text_input("Order ID")
        ui.select("Status", ["paid", "pending", "cancelled"])

ui.run()
```

This is designed for:

- one-file apps
- fast CRUD screens
- internal admin tools
- quick data review workflows

You can run the bundled demos with:

```bash
make ui-config
make ui
make ui-users
make ui-csv
make ui-markdown
make ui-jinja
```

The UI layer also includes practical layout and display helpers for large screens:

- `sidebar()`
- `columns()`
- `tabs()`
- paginated `table()`
- expandable long `text()` / `markdown()` blocks

For shared API credentials, use `soigia.config` to load and save a single `config.yaml` file for the whole project.

## Pipeline

`soigia.pipeline.BasePipeline` is the simple workflow base for business code.

The intended usage is:

```python
from soigia.pipeline import BasePipeline


class SalesPipeline(BasePipeline):
    stages = ["normalize", "enrich", "summarize"]

    def load_data(self):
        return build_orders()

    def normalize(self):
        self.data_df = self.data_df.copy()

    def summarize(self):
        self.model.total_rows = len(self.data_df)


pipeline = SalesPipeline(name="sales")
result = pipeline.run()
```

Pipeline conventions:

- `load_data()` returns the initial payload and base assigns it to `self.data_df`
- `stages = [...]` defines the step order
- each stage mutates `self.data_df` and can use `self.model` for shared state
- `config.yaml` next to the pipeline module is loaded automatically
- `self.config` is a namespace, so you can read `self.config.min_amount`
- `self.on_rollback(...)` registers cleanup for external side effects
- final artifacts are written under `data/<ClassName>/`
- logger output goes to `logs/<ClassName>.log`

Typical config usage:

```python
class SalesPipeline(BasePipeline):
    stages = ["normalize", "enrich", "summarize"]

    def load_data(self):
        return build_orders()

    def normalize(self):
        if self.config.min_amount:
            self.data_df = self.data_df[self.data_df["amount"] >= self.config.min_amount]

    def enrich(self):
        self.on_rollback(lambda: cancel_side_effect())
        self.data_df["net_amount"] = self.data_df["amount"] * 0.98

    def summarize(self):
        self.model.total_rows = len(self.data_df)


pipeline = SalesPipeline(name="sales")
result = pipeline.run()
print(result.summary_path)
print(result.csv_path)
print(result.db_path)
print(result.parquet_path)
```

If a `config.yaml` file lives next to the pipeline module, it is loaded automatically and exposed as `self.config` with dot access:

```python
if self.config.min_amount:
    ...
```

Example commands:

```bash
python -m examples.pipeline_final_template
python -m examples.pipeline_yaml_config_demo
```

Generated files:

- `data/<ClassName>/<step>.csv`
- `data/<ClassName>/<ClassName>.csv`
- `data/<ClassName>/<ClassName>.sqlite3`
- `data/<ClassName>/<ClassName>.parquet`
- `data/<ClassName>/pipeline_summary.md`
- `logs/<ClassName>.log`

## Release

Build distribution artifacts:

```bash
python -m pip install --upgrade build
python -m build
```

Upload to PyPI:

```bash
python -m pip install --upgrade twine
python -m twine upload dist/*
```

Run the test suite before release:

```bash
python -m pytest tests -q
```

## Publish Checklist

1. Bump the version in `pyproject.toml`.
2. Update `CHANGELOG.md`.
3. Run `python -m pytest tests -q`.
4. Run `python -m build --no-isolation`.
5. Upload with `python -m twine upload dist/*`.
6. Tag the release in git.

## Core Ideas

`DataTable` keeps the pandas mental model, but adds a few opinionated helpers:

- `objects` for queryset-style chaining
- `values()` for record-style output
- `filter()` and `exclude()` for row filtering
- `order_by()` and `distinct()` for common table operations
- `join()` for relational merges
- `validate_schema()` for lightweight schema checks
- `init_versions()`, `snapshot()`, and `auto_version()` for version tracking

## Creating DataTables

### From dictionaries

```python
from soigia.datatable import DataTable

people = DataTable({
    "name": ["alice", "bob"],
    "age": [19, 24],
    "city": ["hanoi", "saigon"],
})
```

### From records

```python
records = [
    {"name": "alice", "age": 19},
    {"name": "bob", "age": 24},
]

people = DataTable.from_records(records)
```

### From files

Supported file helpers include:

- `from_csv()`
- `from_json()`
- `from_excel()`
- `from_parquet()`
- `from_feather()`
- `from_pickle()`

Example:

```python
table = DataTable.from_csv("people.csv")
```

Security note: `from_pickle()` should only be used with trusted input. Pickle files can execute code during loading.

## Everyday Data Work

### Select rows

```python
adults = df.objects.filter(age__gte=20)
print(adults.values("name", "age"))
```

### Exclude rows

```python
non_bob = df.objects.exclude(name="bob")
```

### Sort rows

```python
sorted_df = df.objects.order_by("age")
```

### Remove duplicates

```python
unique_names = df.objects.values("name").distinct("name")
```

### Group and aggregate

```python
summary = df.objects.group_by("city").aggregate(total_age="age")
print(summary)
```

### Work with record output

```python
rows = df.objects.filter(age__gte=20).values("name", "age")
print(rows)
```

## Joining Data

`DataTable` supports join-style workflows for combining tables.

```python
left = DataTable({"id": [1, 2, 3], "name": ["alice", "bob", "carol"]})
right = DataTable({"id": [1, 2, 4], "city": ["hanoi", "saigon", "danang"]})

joined = left.objects.inner_join(right, on="id").to_df()
print(joined)
```

Other common joins include:

- `left_join()`
- `inner_join()`
- `anti_join()`

## Comparing Data

If your main workflow is comparing two tables, `DataTable` gives you a few practical helpers for change detection and review.

Use `compare_frames()` when you want a structured report of what is the same, what only exists on one side, and what changed.

```python
from soigia.datatable import DataTable

left = DataTable(
    {
        "id": [1, 2, 3],
        "name": ["alice", "bob", "carol"],
        "age": [19, 24, 31],
    }
)
right = DataTable(
    {
        "id": [1, 2, 4],
        "name": ["alice", "bob", "david"],
        "age": [19, 25, 28],
    }
)

comparison = left.compare_frames(right, key_columns=["id"])

print(comparison["same_rows"])
print(comparison["left_only_rows"])
print(comparison["right_only_rows"])
print(comparison["changed_rows"])
print(comparison["changed_count"])
```

What the result means:

- `same_rows`: rows matched on both sides with identical values
- `left_only_rows`: rows only found in the left table
- `right_only_rows`: rows only found in the right table
- `changed_rows`: rows that matched by key, but have different values

If you want the 3-way output you remembered, use `compare_with_status()`. It returns one combined table with a status column and rows tagged as:

- `same`
- `left_only`
- `right_only`

```python
status_table = left.compare_with_status(right)
print(status_table)
```

That helper is useful when you want to inspect the three groups in a single table instead of handling three separate outputs.

You can also get a compact overview with `compare_status_summary()`:

```python
summary = left.compare_status_summary(right)

print(summary)
```

This is useful when you want to:

- review row-level differences quickly
- count how many rows are `same`, `left_only`, or `right_only`
- extract a compact sample for logs, reports, or debugging

For a small representative sample from each group, use `compare_status_rows()`:

```python
sample_rows = left.compare_status_rows(right)
print(sample_rows)
```

`compare_sample_rows()` is an alias of `compare_status_rows()`.

Common use case: compare data before and after an import or sync.

```python
before = DataTable(
    {
        "id": [1, 2, 3],
        "name": ["alice", "bob", "carol"],
        "status": ["active", "active", "inactive"],
    }
)

after = DataTable(
    {
        "id": [1, 2, 4],
        "name": ["alice", "bob", "david"],
        "status": ["active", "blocked", "active"],
    }
)

report = before.compare_with_status(after)
summary = before.compare_status_summary(after)
sample = before.compare_status_rows(after)

print(report)
print(summary)
print(sample)
```

This pattern is useful when you want to:

- verify that a sync did not drop rows unexpectedly
- see which records were added, removed, or stayed the same
- share a compact diff summary with non-technical reviewers

Detailed use case: you run a daily customer sync from an upstream system into your local table, and you want to validate the result before moving on to reporting or downstream exports.

In this case, you usually care about three questions:

1. Which rows are unchanged?
2. Which rows changed in one or more fields?
3. Which rows exist only on one side of the comparison?

For that kind of reconciliation, compare by a stable key such as `id` or `customer_id`, not by the full row.

```python
before = DataTable(
    {
        "customer_id": [101, 102, 103, 104],
        "name": ["alice", "bob", "carol", "dan"],
        "tier": ["gold", "silver", "bronze", "gold"],
        "city": ["hanoi", "saigon", "danang", "hanoi"],
        "active": [True, True, True, False],
    }
)

after = DataTable(
    {
        "customer_id": [101, 102, 103, 105],
        "name": ["alice", "bob", "carol", "erin"],
        "tier": ["gold", "gold", "bronze", "silver"],
        "city": ["hanoi", "saigon", "danang", "hanoi"],
        "active": [True, True, False, True],
    }
)

comparison = before.compare_frames(after, key_columns=["customer_id"])
status_table = before.compare_with_status(after)
summary = before.compare_status_summary(after)
sample_rows = before.compare_status_rows(after)

print("Same rows:")
print(comparison["same_rows"])

print("Rows only in before:")
print(comparison["left_only_rows"])

print("Rows only in after:")
print(comparison["right_only_rows"])

print("Changed rows:")
print(comparison["changed_rows"])

print("Status table:")
print(status_table)

print("Summary:")
print(summary)

print("Representative rows:")
print(sample_rows)
```

How to read this example:

- `customer_id=101` is `same` because every field matches.
- `customer_id=102` is a changed row because `tier` moved from `silver` to `gold`.
- `customer_id=103` is a changed row because `active` changed from `True` to `False`.
- `customer_id=104` exists only in `before`, so it is `left_only`.
- `customer_id=105` exists only in `after`, so it is `right_only`.

What each helper gives you:

- `compare_frames(..., key_columns=["customer_id"])` returns the raw structured result with `same_rows`, `left_only_rows`, `right_only_rows`, and `changed_rows`.
- `compare_with_status(...)` returns a single combined table with a `status` column, which is easier to inspect by eye.
- `compare_status_summary(...)` returns one row per status with counts and embedded rows, which is useful for audit logs and review notes.
- `compare_status_rows(...)` returns one representative row for each status, which is useful for a quick sanity check.
- `compare_sample_rows(...)` is an alias of `compare_status_rows()`.

Practical cautions:

- Pick a key that stays stable across both tables. A business identifier is usually better than a mutable field like `name`.
- If your source can contain duplicate keys, `compare_frames()` keeps the latest row it sees for each key.
- If you do not pass `key_columns`, `compare_frames()` falls back to full-row matching, which is stricter and often less useful for sync reconciliation.

Multi-column keys are also supported when a single field is not enough to identify a row:

```python
left = DataTable(
    {
        "region": ["vn", "vn", "sg"],
        "customer_id": [1, 2, 1],
        "status": ["active", "active", "inactive"],
    }
)

right = DataTable(
    {
        "region": ["vn", "vn", "sg"],
        "customer_id": [1, 2, 1],
        "status": ["active", "blocked", "inactive"],
    }
)

comparison = left.compare_frames(right, key_columns=["region", "customer_id"])
print(comparison["changed_rows"])
```

Use this when the natural key is a composite key, for example `region + customer_id`, `warehouse_id + sku`, or `date + account_id`.

### Use Case 1: Compare Data Before And After ETL

Use this when you load raw data, transform it, and want to check that the transformation only changed what you expected.

Typical questions:

- Did the ETL preserve every source record?
- Did any row get dropped during filtering, joins, or deduplication?
- Did a field like `tier`, `normalized_name`, or `status` change as intended?

```python
raw = DataTable(
    {
        "customer_id": [1, 2, 3, 4],
        "name": [" Alice ", "bob", "carol", "dan"],
        "city": ["Hanoi", "saigon", "Da Nang", "HANOI"],
        "status": ["active", "active", "inactive", "active"],
    }
)

transformed = DataTable(
    {
        "customer_id": [1, 2, 3, 4],
        "name": ["alice", "bob", "carol", "dan"],
        "city": ["hanoi", "saigon", "danang", "hanoi"],
        "status": ["active", "active", "inactive", "active"],
    }
)

comparison = raw.compare_frames(transformed, key_columns=["customer_id"])
status_table = raw.compare_with_status(transformed)
summary = raw.compare_status_summary(transformed)

print(comparison["changed_rows"])
print(status_table)
print(summary)
```

How to interpret it:

- If all records are still present and only format-normalized fields changed, `same_count` should stay high.
- If `left_only_count` is greater than zero, the ETL likely dropped rows.
- If `right_only_count` is greater than zero, the ETL likely created rows that were not in the source.
- If `changed_rows` contains keys you did not expect, inspect the transformation rules for that step.

### Use Case 2: Compare Database Data Against CSV

Use this when you export a database table to CSV and need to verify that the export is complete and accurate.

Typical questions:

- Did the CSV contain every row from the database?
- Did the export preserve numeric values, dates, and statuses?
- Did any row shift because of filtering, pagination, or encoding issues?

```python
db_table = DataTable(
    {
        "order_id": [5001, 5002, 5003],
        "customer_id": [101, 102, 103],
        "amount": [120.5, 88.0, 42.75],
        "currency": ["USD", "USD", "USD"],
    }
)

csv_table = DataTable(
    {
        "order_id": [5001, 5002, 5004],
        "customer_id": [101, 102, 104],
        "amount": [120.5, 88.0, 99.0],
        "currency": ["USD", "USD", "USD"],
    }
)

comparison = db_table.compare_frames(csv_table, key_columns=["order_id"])
report = db_table.compare_with_status(csv_table)
summary = db_table.compare_status_summary(csv_table)

print("Missing from CSV:")
print(comparison["left_only_rows"])

print("Extra in CSV:")
print(comparison["right_only_rows"])

print("Changed rows:")
print(comparison["changed_rows"])

print(report)
print(summary)
```

How to interpret it:

- `left_only_rows` shows records present in the database but missing from the CSV export.
- `right_only_rows` shows records present in the CSV but not in the database snapshot you expected.
- `changed_rows` shows keys that exist on both sides but have different values, which can happen if the export or source changed mid-run.

This is especially useful when the CSV is used for audit, payment, reporting, or data transfer to another team.

### Use Case 3: Compare Transaction Lists To Find Missing Or Mismatched Records

Use this when you reconcile transaction feeds, payment logs, trading fills, or ledger rows.

Typical questions:

- Which transactions were recorded in one system but not the other?
- Which transaction amounts, statuses, or timestamps differ?
- Which side has the authoritative version of the row?

```python
ledger = DataTable(
    {
        "tx_id": ["tx-1", "tx-2", "tx-3", "tx-4"],
        "amount": [1000, 2500, 1750, 900],
        "status": ["settled", "pending", "settled", "failed"],
        "updated_at": ["2026-03-28", "2026-03-28", "2026-03-28", "2026-03-28"],
    }
)

gateway = DataTable(
    {
        "tx_id": ["tx-1", "tx-2", "tx-3", "tx-5"],
        "amount": [1000, 2600, 1750, 500],
        "status": ["settled", "settled", "settled", "pending"],
        "updated_at": ["2026-03-28", "2026-03-28", "2026-03-28", "2026-03-28"],
    }
)

comparison = ledger.compare_frames(gateway, key_columns=["tx_id"])
status_table = ledger.compare_with_status(gateway)
sample_rows = ledger.compare_status_rows(gateway)

print("Matched transactions:")
print(comparison["same_rows"])

print("Ledger-only transactions:")
print(comparison["left_only_rows"])

print("Gateway-only transactions:")
print(comparison["right_only_rows"])

print("Changed transactions:")
print(comparison["changed_rows"])

print(status_table)
print(sample_rows)
```

How to interpret it:

- `tx-1` matches exactly.
- `tx-2` is a changed record because both `amount` and `status` differ.
- `tx-4` appears only in the ledger, so it may not have reached the gateway.
- `tx-5` appears only in the gateway, so it may be a late-arriving or duplicate record.

For transaction work, this is the most useful pattern when you need to reconcile across systems and then decide whether to replay, investigate, or alert.

### Use Case 4: Reconcile Orders After Sync

Use this when you sync orders from one system to another and need to confirm that no order was lost, duplicated, or altered unexpectedly.

Typical questions:

- Did every order from the source system land in the destination?
- Did any order status change during sync?
- Did amounts, customer references, or fulfillment flags get modified?

```python
source_orders = DataTable(
    {
        "order_id": [9001, 9002, 9003, 9004],
        "customer_id": [101, 102, 103, 104],
        "amount": [250.0, 125.5, 80.0, 300.0],
        "status": ["paid", "pending", "paid", "cancelled"],
        "fulfilled": [True, False, True, False],
    }
)

synced_orders = DataTable(
    {
        "order_id": [9001, 9002, 9003, 9005],
        "customer_id": [101, 102, 103, 105],
        "amount": [250.0, 125.5, 82.0, 300.0],
        "status": ["paid", "paid", "paid", "paid"],
        "fulfilled": [True, True, True, True],
    }
)

comparison = source_orders.compare_frames(synced_orders, key_columns=["order_id"])
status_table = source_orders.compare_with_status(synced_orders)
summary = source_orders.compare_status_summary(synced_orders)

print(comparison["same_rows"])
print(comparison["changed_rows"])
print(comparison["left_only_rows"])
print(comparison["right_only_rows"])
print(status_table)
print(summary)
```

How to interpret it:

- `order_id=9001` is unchanged.
- `order_id=9002` is changed because `status` and `fulfilled` differ.
- `order_id=9003` is changed because `amount` differs.
- `order_id=9004` is missing from the synced table.
- `order_id=9005` is extra in the synced table and should be investigated.

This is useful when your sync is supposed to be lossless and you want to catch issues before the next processing step.

### Use Case 5: Compare Price Lists Across Versions

Use this when you maintain product pricing in two places and need to ensure the updated price list matches what you expect before publishing it.

Typical questions:

- Which products got a price change?
- Which products were added or removed?
- Did any currency or discount field get changed incorrectly?

```python
old_prices = DataTable(
    {
        "sku": ["A-100", "B-200", "C-300", "D-400"],
        "name": ["basic plan", "pro plan", "team plan", "enterprise"],
        "price": [10, 25, 50, 120],
        "currency": ["USD", "USD", "USD", "USD"],
    }
)

new_prices = DataTable(
    {
        "sku": ["A-100", "B-200", "C-300", "E-500"],
        "name": ["basic plan", "pro plan", "team plan", "growth"],
        "price": [10, 30, 50, 80],
        "currency": ["USD", "USD", "USD", "USD"],
    }
)

comparison = old_prices.compare_frames(new_prices, key_columns=["sku"])
status_table = old_prices.compare_with_status(new_prices)
sample_rows = old_prices.compare_status_rows(new_prices)

print("Price changes:")
print(comparison["changed_rows"])

print("Removed SKUs:")
print(comparison["left_only_rows"])

print("Added SKUs:")
print(comparison["right_only_rows"])

print(status_table)
print(sample_rows)
```

How to interpret it:

- `B-200` changed because the price increased from `25` to `30`.
- `D-400` was removed from the new list.
- `E-500` was added in the new list.

This pattern is especially useful before publishing a price sheet, feeding a storefront, or sending pricing data to finance or sales teams.

### Use Case 6: Compare Users Synced From API Into Database

Use this when you pull users from an API, store them in your database, and want to make sure the sync did not miss updates or create bad records.

Typical questions:

- Which users already existed and stayed unchanged?
- Which users were updated by the API?
- Which users disappeared from the source or were newly created?

```python
api_users = DataTable(
    {
        "user_id": [1, 2, 3, 4],
        "email": ["alice@example.com", "bob@example.com", "carol@example.com", "dan@example.com"],
        "role": ["admin", "member", "member", "member"],
        "active": [True, True, True, True],
    }
)

db_users = DataTable(
    {
        "user_id": [1, 2, 3, 5],
        "email": ["alice@example.com", "bob@example.com", "carol_new@example.com", "eve@example.com"],
        "role": ["admin", "member", "member", "member"],
        "active": [True, False, True, True],
    }
)

comparison = api_users.compare_frames(db_users, key_columns=["user_id"])
status_table = api_users.compare_with_status(db_users)
summary = api_users.compare_status_summary(db_users)

print("Users that match:")
print(comparison["same_rows"])

print("Users with changes:")
print(comparison["changed_rows"])

print("Users only in API:")
print(comparison["left_only_rows"])

print("Users only in DB:")
print(comparison["right_only_rows"])

print(status_table)
print(summary)
```

How to interpret it:

- `user_id=1` matches exactly.
- `user_id=2` is changed because `active` differs.
- `user_id=3` is changed because `email` differs.
- `user_id=4` exists only in the API response, so the database is missing it.
- `user_id=5` exists only in the database, so it may be stale or created by another process.

This is the pattern to use when you want to validate a data sync job, a nightly import, or a reconciliation step between an external service and your local store.

If you only want specific subsets:

- `same(other, key_columns=...)`
- `left_only(other, key_columns=...)`
- `right_only(other, key_columns=...)`
- `different_rows(other, key_columns=...)`
- `diff_rows(other, key_columns=...)`

Without `key_columns`, `compare_frames()` compares rows by their full content. With `key_columns`, it compares rows by key and reports field-level changes.

## Schema Validation

`validate_schema()` helps you check data before you export, persist, or send it downstream.

```python
table = DataTable({
    "name": ["alice"],
    "age": [19],
    "email": ["alice@example.com"],
})

validated = table.validate_schema({
    "name": {"nullable": False},
    "age": {"type": int, "min": 18},
    "email": {"regex": r"@"},
})
```

Useful related helpers:

- `ensure_columns()`
- `coerce_types()`
- `fill_missing()`

Example:

```python
prepared = table.ensure_columns("city", fill_value="unknown")
prepared = prepared.coerce_types({"age": "int64"})
prepared = prepared.fill_missing(0)
```

## Version Snapshots

If you want to keep track of transformations, `DataTable` can store version history.

```python
table = DataTable({"name": ["alice"], "age": [19]})

table.init_versions("initial")
updated = table.fill_missing(0)
updated.mark_version("after_fill")
```

Useful version helpers:

- `version_history()`
- `version_count()`
- `current_version()`
- `get_version()`
- `restore_version()`
- `snapshot()`
- `auto_version()`
- `disable_auto_version()`
- `diff_versions()`

## SQL Helpers

`soigia` includes a small database connector layer for SQL-backed workflows.

```python
from soigia.datatable import DataTable

table = DataTable.from_sql(
    "select 1 as id",
    backend="sqlite",
    connection_string="sqlite:///example.db",
)
```

Module-level helpers are also available:

- `from_sql()`
- `from_mysql_db()`
- `from_maria_db()`
- `from_oracle_db()`
- `from_postgres_db()`
- `from_sqlite_db()`
- `db_connector()`

If you reuse the same connection settings often, `db_connector()` lets you create a configured connector once and call helpers on it repeatedly.

## Google Sheets

`soigia` can read from and write to Google Sheets when the optional dependencies are installed.

```python
from soigia.datatable import DataTable

sheet_table = DataTable.from_google_sheet("spreadsheet-id")
```

```python
sheet_table.to_google_sheet(worksheet)
```

Common uses:

- quick reporting
- spreadsheet-driven workflows
- manual QA on table-shaped data

## Fake Data

Generate synthetic rows for tests and demos.

```python
from soigia.datatable import DataTable

fake_people = DataTable.from_faker(
    {
        "name": "name",
        "email": "email",
        "city": "city",
    },
    count=5,
    seed=7,
)
```

If you already use a factory-style test-data class:

```python
fake_people = DataTable.from_factory(MyFactory, count=10)
```

## Helpful Aliases

The package keeps a few convenience aliases for the main table class:

- `soigia.datatable.DataTable`
- `soigia.datatable.datatable`
- `soigia.datatable.df`

They all point to the same class.

## Development

Run tests:

```bash
pytest tests -v
```

Build release artifacts:

```bash
python -m build
```

Publish:

```bash
make publish
```

Test publish:

```bash
make publish-test
```

## License

BSD-3-Clause
