"""Public pipeline entrypoint.

This module exists so users can import the base pipeline with:

    from soigia.pipeline import BasePipeline

It re-exports the pipeline primitives from `soigia.base_pipeline`.
"""

from __future__ import annotations

from .base_pipeline import BasePipeline as LegacyBasePipeline
from .base_pipeline import BaseStep, FunctionStep, Pipeline as BasePipeline, PipelineContext, PipelineStatus, StepOutcome

__all__ = [
    "BasePipeline",
    "PipelineStatus",
    "StepOutcome",
    "PipelineContext",
    "BaseStep",
    "FunctionStep",
    "LegacyBasePipeline",
]
