"""Import smoke tests for the public datatable entrypoint."""

import soigia
import soigia.datatable as dtpkg

from soigia.datatable import DataTable, datatable


def test_datatable_module_exports_data_table():
    assert hasattr(dtpkg, "DataTable")
    assert dtpkg.DataTable is DataTable
    assert datatable is DataTable
    assert callable(dtpkg.from_faker)
    assert callable(dtpkg.from_factory)


def test_soigia_package_can_expose_datatable_entrypoint():
    assert soigia.datatable.DataTable is DataTable
