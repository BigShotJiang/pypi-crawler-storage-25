"""Tests for the release automation helpers."""

import importlib.util
from pathlib import Path


def _load_release_module():
    spec = importlib.util.spec_from_file_location("release_script", Path("scripts/release.py"))
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def test_prompt_credentials_accepts_token_as_username(monkeypatch):
    release = _load_release_module()
    monkeypatch.delenv("TWINE_USERNAME", raising=False)
    monkeypatch.delenv("TWINE_PASSWORD", raising=False)
    monkeypatch.delenv("soigia-pip-user", raising=False)
    monkeypatch.delenv("soigia-pip-password", raising=False)
    monkeypatch.setattr("builtins.input", lambda prompt: "pypi-abc123")
    called = {}

    def fail_getpass(prompt):
        called["getpass"] = True
        return "should-not-run"

    monkeypatch.setattr(release.getpass, "getpass", fail_getpass)

    user, password = release._prompt_credentials("PyPI")

    assert user == "__token__"
    assert password == "pypi-abc123"
    assert "getpass" not in called


def test_prompt_credentials_accepts_token_in_environment(monkeypatch):
    release = _load_release_module()
    monkeypatch.setattr("builtins.input", lambda prompt: "someone")
    monkeypatch.setattr(release.getpass, "getpass", lambda prompt: "pypi-envtoken")
    user, password = release._prompt_credentials("PyPI")

    assert user == "__token__"
    assert password == "pypi-envtoken"
