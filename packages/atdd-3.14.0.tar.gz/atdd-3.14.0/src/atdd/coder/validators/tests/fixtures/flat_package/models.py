class Spec:
    pass
