# How-To Guides

Task-oriented guides for common workflows.

## Add a Command to `axm`

To expose a CLI command from your AXM package, add an entry point in your `pyproject.toml`:

```toml
[project.entry-points."axm.commands"]
mypackage_mycommand = "my_package.cli:my_function"
```

Command names must follow the `{domain}_{action}` convention:

```toml
# Example from axm-init
[project.entry-points."axm.commands"]
init_scaffold = "axm_init.cli:scaffold"
init_check    = "axm_init.cli:check"
```

The function must be a valid `cyclopts` command:

```python
# my_package/cli.py
from pathlib import Path

def my_function(path: Path = Path(".")) -> None:
    """My custom AXM command."""
    print(f"Running on {path}")
```

After installing your package, `axm mycommand` will be available automatically.

## Install Specific Plugins

```bash
# Install only what you need
uv pip install axm[init]        # scaffolding
uv pip install axm[init,audit]  # scaffolding + quality
uv pip install axm[mcp]         # MCP server for AI agents
uv pip install axm[all]         # everything
```
