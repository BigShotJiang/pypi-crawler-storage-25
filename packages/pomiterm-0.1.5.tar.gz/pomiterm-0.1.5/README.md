# PomiTerm 🍅

A minimal, beautiful Pomodoro timer that lives in your terminal.

Built with [Rich](https://github.com/Textualize/rich) for a clean UI — live countdown, a live clock, and a random quote to keep you going.

## Install

```sh
pipx install pomiterm
```

## Usage

```sh
pomiterm
```

## Features

- Live countdown for work sessions, short breaks, and long breaks
- Ticking clock on the main screen
- Random motivational, wisdom, and silly quotes
- Sound notifications at the end of each session (macOS)
- Configurable durations and cycles from the menu

## Default Settings

| Setting     | Value  |
|-------------|--------|
| Work        | 25 min |
| Short break | 5 min  |
| Long break  | 15 min |
| Cycles      | 4      |

## Requirements

- Python 3.10+
- macOS (sound notifications via `afplay`); timer works on Linux without sound
