from rich.panel import Panel
from rich.console import Console
from rich.live import Live
from datetime import datetime
from importlib.metadata import version
import sys
import questionary
import random

from pomiterm import setting, timer


def main():
    while True:
        console = Console()
        now = datetime.now()

        settings = setting.settings

        quotes = [
            # Success
            "The secret of getting ahead is getting started.",
            "It always seems impossible until it's done.",
            "Don't watch the clock; do what it does. Keep going.",
            "Success is the sum of small efforts, repeated day in and day out.",
            "The only way to do great work is to love what you do.",
            "Focus on being productive instead of busy.",
            "Action is the foundational key to all success.",
            # Wisdom
            "The unexamined life is not worth living.",
            "In the middle of difficulty lies opportunity.",
            "He who has a why can endure any how.",
            "The quieter you become, the more you can hear.",
            "Do not dwell in the past, do not dream of the future, concentrate the mind on the present moment.",
            "Knowing yourself is the beginning of all wisdom.",
            "The more I learn, the more I realize how much I don't know.",
            # Silly
            "I told my computer I needed a break. Now it won't stop sending me Kit-Kat ads.",
            "Why do programmers prefer dark mode? Because light attracts bugs.",
            "A tomato timer walks into a bar. The bartender says: 'You look ripe for a break.'",
            "My code doesn't have bugs. It has unexpected features.",
            "I'm on a seafood diet. I see food, I eat it — then I get back to work.",
            "The brain is a wonderful organ. It starts working the moment you get up and doesn't stop until you open a meeting invite.",
            "Work hard in silence. Let your commits speak.",
        ]

        console.clear()
        console.print("[bold red]🍅 PomiTerm[/bold red]")
        console.print(f"[bold yellow]V {version('pomiterm')}[/bold yellow]")
        console.print("[bold dim]Small minimal Pomidoro timer running in your terminal.[/bold dim]")

        console.print(Panel(f'[bold white] {now.strftime("%H:%M - %A %m %Y")} [/bold white]\n[italic dim]"{random.choice(quotes)}"[/italic dim]'))

        choice = questionary.select(
            "Choose an option:",
            choices=["Start", "Stats", "Settings", "Quit"]
        ).ask()

        console.clear()

        if choice == "Start":
            sessions = [
                ("Focus Time", "work_minutes", "Glass"),
                ("Short Break", "short_break", "Ping"),
                ("Long Break", "long_break", "Hero"),
            ]
            cycle = 0
            while cycle < settings["cycles"]:
                for name, key, sound in sessions:
                    with Live(refresh_per_second=2, transient=False) as live:
                        timer.countdown(settings[key] * 60, live, timerName=name, sound=sound)
                cycle += 1
        elif choice == "Quit":
            console.print("[dim]Goodbye![/dim]")
            sys.exit()
        elif choice == "Settings":
            setting.edit_settings()
