import questionary
from rich.console import Console
from rich.table import Table

console = Console()

settings = {
    "work_minutes": 25,
    "short_break": 5,
    "long_break": 15,
    "cycles": 4,
    "sound": True,
}

def show_settings():
    table = Table(title="Current Settings")
    table.add_column("Setting", style="cyan")
    table.add_column("Value", style="yellow")
    for key, value in settings.items():
        table.add_row(key, str(value))
    console.print(table)

def edit_settings():
    show_settings()

    key = questionary.select(
        "Which setting to change?",
        choices=[*settings.keys(), "Back"]
    ).ask()

    if key == "Back":
        return

    if isinstance(settings[key], bool):
        settings[key] = questionary.confirm(f"{key}?").ask()
    else:
        new_val = questionary.text(
            f"New value for {key} (current: {settings[key]}):"
        ).ask()
        settings[key] = int(new_val)

    console.print(f"[green]✓ {key} updated to {settings[key]}[/green]")
