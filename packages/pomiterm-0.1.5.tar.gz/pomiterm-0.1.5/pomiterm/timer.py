import time
import subprocess
from rich.panel import Panel

def countdown(seconds, live, timerName, sound="Glass"):
    while seconds > 0:
        mins, secs = divmod(seconds, 60)
        live.update(Panel(f"[bold white]{timerName}[/bold white]\n[bold red]{mins:02d}:{secs:02d}[/bold red]"))
        time.sleep(1)
        seconds -= 1
    live.update(Panel("[bold green]Done![/bold green]"))
    subprocess.run(["afplay", f"/System/Library/Sounds/{sound}.aiff"], check=False)
