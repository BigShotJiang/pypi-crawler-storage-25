#!/bin/bash
set -e

echo "Cleaning old builds..."
rm -rf dist/ build/

echo "Building..."
.venv/bin/python -m build

echo "Uploading to PyPI..."
.venv/bin/twine upload dist/*

echo "Done!"
