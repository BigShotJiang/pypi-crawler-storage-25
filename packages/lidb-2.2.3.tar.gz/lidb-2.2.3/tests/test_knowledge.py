# Copyright (c) ZhangYundi
# Licensed under the MIT License
# Test for knowledge base search functionality

import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import lidb


def test_get_docs_path():
    docs_path = lidb.get_docs_path()
    print(f"Docs path: {docs_path}")
    assert docs_path.exists()
    print("✓ Test passed: get_docs_path returns existing path")


def test_get_knowledge_path():
    knowledge_path = lidb.get_knowledge_path()
    print(f"Knowledge path: {knowledge_path}")
    assert knowledge_path.exists()
    print("✓ Test passed: get_knowledge_path returns existing path")


def test_search_knowledge():
    results = lidb.search_knowledge("dataset", k=5)
    print(f"Search results: {len(results)} results found")
    assert isinstance(results, list)
    assert len(results) > 0
    for result in results:
        assert "source" in result
        assert "content" in result
        assert "score" in result
    print("✓ Test passed: search_knowledge returns valid results")


def test_search_knowledge_multiple():
    results = lidb.search_knowledge("database", k=10)
    print(f"Multiple results: {len(results)} results found")
    assert isinstance(results, list)
    print("✓ Test passed: search_knowledge returns multiple results")


def test_search_knowledge_case():
    results = lidb.search_knowledge("database", k=5)
    results_upper = lidb.search_knowledge("DATABASE", k=5)
    print(f"Lower: {len(results)} results, Upper: {len(results_upper)} results")
    print("✓ Test passed: search_knowledge is case insensitive")


if __name__ == "__main__":
    print("Running knowledge base tests...")
    test_get_docs_path()
    test_get_knowledge_path()
    test_search_knowledge()
    test_search_knowledge_multiple()
    test_search_knowledge_case()
    print("\n✓ All tests passed!")
