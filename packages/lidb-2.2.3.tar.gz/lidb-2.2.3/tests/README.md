# lidb知识库测试说明

## 测试文件
- 文件位置: `tests/test_knowledge.py`

## 使用方法

### 安装依赖
```bash
pip install lidb
```

### 运行测试
```bash
cd /Users/zhangyundi/ypkg/lidb
python tests/test_knowledge.py
```

### 测试内容

1. test_get_docs_path - 测试docs目录路径获取
2. test_get_knowledge_path - 测试knowledge目录路径获取  
3. test_search_knowledge - 测试知识库搜索功能
4. test_search_knowledge_multiple - 测试返回多个结果
5. test_search_knowledge_case - 测试大小写不敏感搜索

### 输出示例
Running knowledge base tests...
Docs path: /Users/zhangyundi/ypkg/lidb/docs
✓ Test passed: get_docs_path returns existing path
Knowledge path: /Users/zhangyundi/ypkg/lidb/knowledge
✓ Test passed: get_knowledge_path returns existing path
Search results: 5 results found
Multiple results: 2 results found
Lower: 2 results, Upper: 2 results
✓ Test passed: search_knowledge returns multiple results
✓ Test passed: search_knowledge is case insensitive

✓ All tests passed!
