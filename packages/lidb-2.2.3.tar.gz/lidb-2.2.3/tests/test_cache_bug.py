# -*- coding: utf-8 -*-
"""测试缓存场景"""
import polars as pl
from lidb.qdf.qdf import QDF


def test_cache_false_never_pollutes_data():
    """cache=False 的设计意图：self.data 始终只包含原始列+有持久缓存的列，中间列不留"""
    df = pl.DataFrame({
        "date": ["2024-01-01"],
        "time": ["09:00"],
        "asset": ["BTC"],
        "close": [100.0],
    })

    qdf = QDF(df, index=("date", "time", "asset"), align=False)
    print(f"初始 data columns: {qdf.data.columns}")
    print(qdf.sql("close_2x * 2 as close_4x", "close * 2 as close_2x"))

    # Step 1: cache=False，close_2x 加到 self.data，计算后 revert，self.data 恢复原状
    r1 = qdf.sql("close * 2 as close_2x", cache=False)
    print(f"\nStep 1 cache=False: data.columns={qdf.data.columns}")
    print(f"  result has close_2x: {'close_2x' in r1.columns}")
    print(f"  close_2x in self.data: {'close_2x' in qdf.data.columns}")

    # Step 2: cache=True，依赖 close_2x -> 从缓存读取 pl.col("close_2x")
    r2 = qdf.sql("close_2x * 2 as close_4x", cache=True)
    print(f"\nStep 2 cache=True: data.columns={qdf.data.columns}")
    print(f"  result close_4x: {r2['close_4x'][0]}")

    print(f"\n{'[PASS]' if r2['close_4x'][0] == 400.0 else '[FAIL]'}")


def test_stale_cache_with_alias_collision():
    """两个不同表达式产生相同 alias 的场景，_expr_cache 被覆盖"""
    df = pl.DataFrame({
        "date": ["2024-01-01"],
        "time": ["09:00"],
        "asset": ["BTC"],
        "close": [100.0],
    })

    qdf = QDF(df, index=("date", "time", "asset"), align=False)

    # batch1: close * 2 as mid，mid 在 data 中
    r1 = qdf.sql("close * 2 as mid", cache=True)
    print(f"\n--- Alias collision test ---")
    print(f"batch1: mid={r1['mid'][0]}, data.columns={qdf.data.columns}")
    print(f"  _expr_cache: {[(str(k), v) for k, v in qdf._expr_cache.items()]}")

    # batch2: close * 3 as mid（不同表达式，相同 alias），mid 已在 data 和 cache 中
    r2 = qdf.sql("close * 3 as mid", cache=True)
    print(f"\nbatch2: mid={r2['mid'][0]}, data.columns={qdf.data.columns}")
    print(f"  _expr_cache: {[(str(k), v) for k, v in qdf._expr_cache.items()]}")

    # mid 的缓存 key 已被覆盖，但 data.columns 显示 mid 可能来自不同批次
    # 最终 select 返回的是 alias=mid 的列，即最后计算的 close * 3
    is_correct = r2['mid'][0] == 300.0
    print(f"\n{'[PASS] mid=300.0' if is_correct else '[FAIL] mid != 300.0'}")


if __name__ == "__main__":
    test_cache_false_never_pollutes_data()
    print("\n" + "="*60 + "\n")
    test_stale_cache_with_alias_collision()
