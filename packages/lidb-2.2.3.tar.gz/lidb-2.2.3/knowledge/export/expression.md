# 表达式计算知识库

## 核心功能
高级表达式计算，支持多种分析函数和自定义函数注册。

## 主要组件

### QDF类
表达式数据库的核心类。

#### 初始化
- `data`: 输入数据（DataFrame或LazyFrame）
- `index`: 索引列，默认为["date", "time", "asset"]
- `align`: 是否对齐数据

**执行流程**:
1. 将换输入数据为LazyFrame
2. 铸除空值和异常值
3. 构建数据索引
4. 计算数据维度
5. 对齐数据（如果需要）
6. 初始化内部状态

#### sql方法
执行表达式查询。

**执行流程**:
1. 解析所有输入表达式
2. 构建表达式依赖图
3. 拓扑排序确定执行顺序
4. 分批执行表达式
5. 更新数据和缓存
6. 返回结果DataFrame

#### register_udf方法
注册自定义用户函数。

**执行流程**:
1. 将函数添加到动态模块
2. 返回成功状态

### Expr类
表达式构建和解析的核心类。

#### 表达式解析
使用Lark解析器解析表达式字符串。

**执行流程**:
1. �用预定义的语法规则
2. 解析表达式字符串
3. 构建表达式树
4. 确定别名

#### 依赖图构建
`build_dependency_graph`函数。

**执行流程**:
1. 遍历所有表达式
2. 收集依赖关系
3. 构建图结构
4. 确定入度
5. 返回图、入度和表达式映射

#### 拓扑排序
`topological_sort`函数。

**执行流程**:
1. 使用队列存储入度为0的节点
2. 逐层处理节点
3. 更新邻接节点的入度
4. 生成分层的执行顺序

## 表达式函数分类

### 基础算子（base_udf）
- 一元算子：not_, neg, abs, log, sqrt, sin, cos, tan, sign, sigmoid等
- 二元算子：add, sub, mul, div, floordiv, mod, lt, le, gt, ge, eq, neq, and_, or_等
- 三元算子：if_, fib

### 时间序列函数（ts_udf）
- 统计函数：ts_mean, ts_std, ts_sum, ts_var, ts_skew, ts_mid, ts_mad, ts_max, ts_min等
- 相关函数：ts_corr, ts_cov, ts_slope, ts_resid等
- 差分函数：ts_diff, ts_pct
- 指数加权函数：ts_ewmmean, ts_ewmstd, ts_ewmvar
- 其他：ts_rank, ts_quantile, ts_zscore, ts_fill_forward等

### 横截面函数（cs_udf）
- 排名和标准化：cs_rank, cs_demean, cs_zscore, cs_norm等
- 统计函数：cs_mean, cs_std, cs_var, cs_skew, cs_mid, cs_mad等
- 相关函数：cs_corr, cs_ic, cs_slope, cs_resid等
- 分组函数：cs_meanby, cs_stdby, cs_sumby等

### 日期维度函数（d_udf）
- 统计函数：d_mean, d_std, d_sum, d_var, d_skew, d_max, d_min等
- 相关函数：d_corr, d_cov, d_slope, d_resid等
- 差分函数：d_diff, d_pct
- 指数加权函数：d_ewmmean, d_ewmstd, d_ewmvar
- 其他：d_rank, d_quantile, d_zscore, d_fill_forward等

### 日内函数（itd_udf）
- 统计函数：itd_mean, itd_std, itd_sum, itd_var, itd_skew, itd_max, itd_min等
- 相关函数：itd_corr, itd_cov, itd_slope, itd_resid等
- 差分函数：itd_diff, itd_pct
- 指数加权函数：itd_ewmmean, itd_ewmstd, itd_ewmvar
- 其他：itd_rank, itd_quantile, itd_zscore, itd_norm, itd_fill_forward等

## 知识库
1. 构建表达式依赖图
2. 拓扑排序确定执行顺序
3. 分批执行表达式
4. 更新数据和缓存
5. 返回最终结果