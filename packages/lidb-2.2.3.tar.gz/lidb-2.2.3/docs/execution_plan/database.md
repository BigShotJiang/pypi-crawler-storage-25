# 数据库操作执行计划

## 核心功能
本地和远程数据库操作，支持SQL查询、数据存储和读取。

## 主要API

### `sql(query: str) -> pl.DataFrame`
执行SQL查询，从本地parquet文件中获取数据。

**执行流程**:
1. 解析SQL语句，提取表名
2. 将换表名为本地文件路径
3. 执行Polars SQL查询
4. 返回结果DataFrame

### `put(df, tb_name: str, partitions: list[str])`
将DataFrame存储到指定表名的目录中。

**执行流程**:
1. 检查输入数据是否为空
2. 创建目标目录（如果不存在）
3. 根据分区列表进行分区存储
4. 返回存储结果

### `has(tb_name: str) -> bool`
检查指定表名是否存在。

**执行流程**:
1. 将换表名为完整路径
2. 检查路径是否存在
3. 返回布尔值结果

### `scan(tb: str) -> pl.LazyFrame`
惰性扫描指定表的数据。

**执行流程**:
1. 将换表名为完整路径
2. 使用polars.scan_parquet惰性加载数据
3. 返回LazyFrame对象

### MySQL和ClickHouse操作
- `read_mysql`：从MySQL读取数据
- `write_mysql`：写入MySQL表
- `execute_mysql`：执行MySQL语句
- `read_ck`：从ClickHouse读取数据

**共执行流程**:
1. 从配置文件获取数据库连接信息
2. 建立数据库连接
3. 执行相应操作
4. 处理结果和异常

## 数据路径
- 基础路径：DB_PATH（默认为用户家目录下的lidb）
- 完整路径：DB_PATH + tb_name

## 分区存储
支持按列分区存储，存储时会自动创建相应的目录结构。