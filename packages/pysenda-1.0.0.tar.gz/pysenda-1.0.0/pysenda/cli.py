def converter_para_decimal(graus, minutos, segundos, direcao):
    decimal = float(graus) + (float(minutos) / 60) + (float(segundos) / 3600)

    if direcao.upper() in ['S', 'O', 'W']:
        decimal = -decimal

    return decimal


def app_trilha():
    print("=" * 50)
    print("🛰️  PYSENDA - GERADOR DE LINK GPS")
    print("🧭 Desenvolvido por Tiago Rabelo")
    print("=" * 50)

    nome = input("\n📍 Nome do local: ")

    print("\n[LATITUDE]")
    lg = input("Graus: ")
    lm = input("Minutos: ")
    ls = input("Segundos: ")
    ld = input("Norte ou Sul? (N/S): ")

    print("\n[LONGITUDE]")
    og = input("Graus: ")
    om = input("Minutos: ")
    os = input("Segundos: ")
    od = input("Leste ou Oeste? (L/O): ")

    lat = converter_para_decimal(lg, lm, ls, ld)
    lon = converter_para_decimal(og, om, os, od)

    link_google = f"https://www.google.com/maps?q={lat},{lon}"

    print("\n" + "=" * 50)
    print(f"📍 Local: {nome}")
    print(f"🌎 Latitude: {lat}")
    print(f"🌍 Longitude: {lon}")
    print(f"\n🔗 Google Maps:")
    print(link_google)
    print("=" * 50)


if __name__ == "__main__":
    app_trilha()
