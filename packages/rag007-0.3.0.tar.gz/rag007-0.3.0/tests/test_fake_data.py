"""Retrieval tests against faker-generated customer & product data.

Tests cover:
  - Semantic search (vector similarity)
  - Exact / BM25 keyword search
  - Filter by category, supplier, tier, price, date, in_stock
  - Cross-field confusion: query mixes attributes from different records

Backends tested:
  - DuckDB (in-memory, no docker)
  - ChromaDB (in-memory, no docker)
  - Qdrant (docker: localhost:6333)
  - pgvector (docker: localhost:5433)
  - Meilisearch (docker: localhost:7700)

Run locally:
  podman compose -f docker-compose.test.yml up -d
  uv run pytest tests/test_fake_data.py -v

Run in CI: services started via GitHub Actions service containers.
"""

from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path

import pytest

from rag007.backend import SearchRequest

# ── Load test data ──────────────────────────────────────────────────────────

TESTS_DIR = Path(__file__).parent

_customers: list[dict] | None = None
_products: list[dict] | None = None
_confusion: list[dict] | None = None


def _load_json(name: str) -> list[dict]:
    return json.loads((TESTS_DIR / name).read_text())


def customers() -> list[dict]:
    global _customers
    if _customers is None:
        _customers = _load_json("fake_customers.json")
    return _customers


def products() -> list[dict]:
    global _products
    if _products is None:
        _products = _load_json("fake_products.json")
    return _products


def confusion_products() -> list[dict]:
    global _confusion
    if _confusion is None:
        _confusion = _load_json("fake_confusion_products.json")
    return _confusion


# ── Fake embeddings ─────────────────────────────────────────────────────────

DIMENSION = 64


def _fake_embed(text: str) -> list[float]:
    """Deterministic fake embeddings from text hash."""
    h = hashlib.sha256(text.encode()).digest()
    raw = []
    for i in range(0, DIMENSION * 2, 2):
        raw.append(float(h[i % len(h)] * 256 + h[(i + 1) % len(h)]) / 65535.0)
    norm = sum(v * v for v in raw) ** 0.5
    return [v / norm for v in raw]


# ── Helpers ─────────────────────────────────────────────────────────────────


def _all_products() -> list[dict]:
    """Products + confusion products merged."""
    return products() + confusion_products()


def _assert_hits_match(hits: list[dict], field: str, expected: set[str]) -> None:
    """At least one hit has field value in expected set."""
    values = {str(h.get(field, "")).lower() for h in hits}
    assert values & {e.lower() for e in expected}, (
        f"No hit with {field} in {expected}. Got: {values}"
    )


def _assert_all_hits_match(hits: list[dict], field: str, expected: set) -> None:
    """Every hit has field value in expected set."""
    for h in hits:
        val = h.get(field)
        assert val in expected, f"Hit {h.get('id')}: {field}={val} not in {expected}"


# ═══════════════════════════════════════════════════════════════════════════
#  DuckDB (in-memory — no docker needed)
# ═══════════════════════════════════════════════════════════════════════════


class TestDuckDBFakeData:
    @pytest.fixture(autouse=True)
    def backend(self):
        duckdb = pytest.importorskip("duckdb")
        from rag007.backend import DuckDBBackend

        conn = duckdb.connect(":memory:")

        # ── Products table
        conn.execute(f"""
            CREATE TABLE products (
                id VARCHAR PRIMARY KEY,
                name VARCHAR,
                sku VARCHAR,
                category VARCHAR,
                supplier VARCHAR,
                price DOUBLE,
                in_stock BOOLEAN,
                released_at VARCHAR,
                description VARCHAR,
                content VARCHAR,
                language VARCHAR,
                embedding FLOAT[{DIMENSION}]
            )
        """)
        for p in _all_products():
            vec = _fake_embed(p["content"])
            conn.execute(
                f"INSERT INTO products VALUES (?,?,?,?,?,?,?,?,?,?,?,?::FLOAT[{DIMENSION}])",
                [
                    p["id"], p["name"], p["sku"], p["category"], p["supplier"],
                    p["price"], p["in_stock"], p["released_at"], p["description"],
                    p["content"], p["language"], vec,
                ],
            )

        # ── Customers table
        conn.execute(f"""
            CREATE TABLE customers (
                id VARCHAR PRIMARY KEY,
                name VARCHAR,
                email VARCHAR,
                company VARCHAR,
                country VARCHAR,
                tier VARCHAR,
                created_at VARCHAR,
                content VARCHAR,
                language VARCHAR,
                embedding FLOAT[{DIMENSION}]
            )
        """)
        for c in customers():
            vec = _fake_embed(c["content"])
            conn.execute(
                f"INSERT INTO customers VALUES (?,?,?,?,?,?,?,?,?,?::FLOAT[{DIMENSION}])",
                [
                    c["id"], c["name"], c["email"], c["company"], c["country"],
                    c["tier"], c["created_at"], c["content"], c["language"], vec,
                ],
            )

        self.prod_backend = DuckDBBackend(
            table="products",
            db_path=":memory:",
            embed_fn=_fake_embed,
            vector_column="embedding",
            content_column="content",
        )
        self.prod_backend._conn = conn

        self.cust_backend = DuckDBBackend(
            table="customers",
            db_path=":memory:",
            embed_fn=_fake_embed,
            vector_column="embedding",
            content_column="content",
        )
        self.cust_backend._conn = conn

    # ── Semantic search ──────────────────────────────────────────────────

    def test_semantic_product_search(self):
        req = SearchRequest(query="portable storage device", limit=10)
        hits = self.prod_backend.search(req)
        assert len(hits) > 0
        assert "_rankingScore" in hits[0]

    def test_semantic_customer_search(self):
        req = SearchRequest(query="enterprise company", limit=10)
        hits = self.cust_backend.search(req)
        assert len(hits) > 0

    # ── Exact / keyword search ───────────────────────────────────────────

    def test_filter_by_supplier(self):
        req = SearchRequest(
            query="widget", limit=50, filter_expr="supplier = 'Apple'"
        )
        hits = self.prod_backend.search(req)
        _assert_all_hits_match(hits, "supplier", {"Apple"})

    def test_filter_by_category(self):
        req = SearchRequest(
            query="device", limit=50, filter_expr="category = 'Electronics'"
        )
        hits = self.prod_backend.search(req)
        _assert_all_hits_match(hits, "category", {"Electronics"})

    def test_filter_by_tier(self):
        req = SearchRequest(
            query="customer", limit=50, filter_expr="tier = 'enterprise'"
        )
        hits = self.cust_backend.search(req)
        _assert_all_hits_match(hits, "tier", {"enterprise"})

    def test_filter_by_price_range(self):
        req = SearchRequest(
            query="product", limit=50, filter_expr="price > 500 AND price < 1000"
        )
        hits = self.prod_backend.search(req)
        assert len(hits) > 0
        for h in hits:
            assert 500 < h["price"] < 1000, f"Price {h['price']} out of range"

    def test_filter_by_in_stock(self):
        req = SearchRequest(
            query="product", limit=50, filter_expr="in_stock = true"
        )
        hits = self.prod_backend.search(req)
        assert len(hits) > 0
        _assert_all_hits_match(hits, "in_stock", {True})

    def test_filter_by_date(self):
        req = SearchRequest(
            query="product", limit=50,
            filter_expr="released_at >= '2025-01-01' AND released_at <= '2025-06-30'",
        )
        hits = self.prod_backend.search(req)
        assert len(hits) > 0
        for h in hits:
            assert "2025-01-01" <= h["released_at"] <= "2025-06-30"

    def test_filter_combined_supplier_and_category(self):
        req = SearchRequest(
            query="device", limit=50,
            filter_expr="supplier = 'Samsung' AND category = 'Storage'",
        )
        hits = self.prod_backend.search(req)
        for h in hits:
            assert h["supplier"] == "Samsung"
            assert h["category"] == "Storage"

    def test_filter_language(self):
        req = SearchRequest(
            query="product", limit=50, filter_expr="language = 'de'"
        )
        hits = self.prod_backend.search(req)
        assert len(hits) > 0
        _assert_all_hits_match(hits, "language", {"de"})

    def test_filter_in_operator(self):
        req = SearchRequest(
            query="product", limit=50,
            filter_expr="supplier IN ('Apple', 'Samsung')",
        )
        hits = self.prod_backend.search(req)
        assert len(hits) > 0
        _assert_all_hits_match(hits, "supplier", {"Apple", "Samsung"})

    # ── Cross-field confusion ────────────────────────────────────────────

    def test_confusion_ultrawidget_pro_is_apple_not_samsung(self):
        """UltraWidget Pro is from Apple. Filtering supplier='Samsung'
        should NOT return it."""
        req = SearchRequest(
            query="UltraWidget Pro", limit=10, filter_expr="supplier = 'Samsung'"
        )
        hits = self.prod_backend.search(req)
        ids = {h["id"] for h in hits}
        assert "conf-1001" not in ids, "UltraWidget Pro (Apple) returned for Samsung filter"

    def test_confusion_samsung_electronics_returns_correct_product(self):
        """Querying Samsung electronics should return UltraWidget Lite (conf-1002),
        not UltraWidget Pro (conf-1001 = Apple).
        Use SQL substring to ensure we find the confusion products in 5k+ rows."""
        hits = self.prod_backend._conn.execute(
            "SELECT * FROM products WHERE content LIKE '%UltraWidget%' AND supplier = 'Samsung' AND category = 'Electronics'"
        ).fetchall()
        cols = [d[0] for d in self.prod_backend._conn.description]
        result = [dict(zip(cols, row)) for row in hits]
        ids = {r["id"] for r in result}
        assert "conf-1002" in ids, "UltraWidget Lite (Samsung) not found"
        assert "conf-1001" not in ids, "UltraWidget Pro (Apple) leaked through"

    def test_confusion_dell_networking_not_logitech(self):
        """PowerHub Max is Dell. PowerHub Mini is Logitech.
        Filtering Dell+Networking should return only Max."""
        hits = self.prod_backend._conn.execute(
            "SELECT * FROM products WHERE content LIKE '%PowerHub%' AND supplier = 'Dell' AND category = 'Networking'"
        ).fetchall()
        cols = [d[0] for d in self.prod_backend._conn.description]
        result = [dict(zip(cols, row)) for row in hits]
        ids = {r["id"] for r in result}
        assert "conf-1003" in ids, "PowerHub Max (Dell) not found"
        assert "conf-1004" not in ids, "PowerHub Mini (Logitech) leaked through"

    def test_confusion_out_of_stock_filter(self):
        """DataVault 2000 is out of stock (Apple). DataVault 500 is in stock (Samsung).
        Filter in_stock=false + Storage should return only 2000."""
        hits = self.prod_backend._conn.execute(
            "SELECT * FROM products WHERE content LIKE '%DataVault%' AND in_stock = false AND category = 'Storage'"
        ).fetchall()
        cols = [d[0] for d in self.prod_backend._conn.description]
        result = [dict(zip(cols, row)) for row in hits]
        ids = {r["id"] for r in result}
        assert "conf-1006" in ids, "DataVault 2000 (out of stock) not found"
        assert "conf-1005" not in ids, "DataVault 500 (in stock) leaked through"

    def test_confusion_price_range_discrimination(self):
        """UltraWidget Pro=$999, Lite=$499. Price>500 should exclude Lite."""
        req = SearchRequest(
            query="UltraWidget", limit=10, filter_expr="price > 500"
        )
        hits = self.prod_backend.search(req)
        ids = {h["id"] for h in hits}
        if "conf-1001" in ids:
            assert True  # Pro correctly included
        if "conf-1002" in ids:
            pytest.fail("UltraWidget Lite ($499) returned for price>500")

    # ── Volume / scale ───────────────────────────────────────────────────

    def test_large_result_set(self):
        req = SearchRequest(query="product", limit=100)
        hits = self.prod_backend.search(req)
        assert len(hits) == 100

    def test_customer_count(self):
        """Verify all 5000 customers loaded."""
        result = self.cust_backend._conn.execute(
            "SELECT COUNT(*) FROM customers"
        ).fetchone()
        assert result[0] == 5000

    def test_product_count(self):
        """Verify all products + confusion products loaded."""
        result = self.prod_backend._conn.execute(
            "SELECT COUNT(*) FROM products"
        ).fetchone()
        assert result[0] == 5000 + 6  # products + confusion


# ═══════════════════════════════════════════════════════════════════════════
#  ChromaDB (in-memory — no docker needed)
# ═══════════════════════════════════════════════════════════════════════════


class TestChromaDBFakeData:
    @pytest.fixture(autouse=True)
    def backend(self):
        chromadb = pytest.importorskip("chromadb")
        from rag007.backend import ChromaDBBackend

        b = ChromaDBBackend(
            collection="test_products_fake",
            embed_fn=_fake_embed,
        )
        # Load confusion products (small set for focused tests)
        docs = confusion_products()
        b._collection.add(
            ids=[d["id"] for d in docs],
            documents=[d["content"] for d in docs],
            metadatas=[
                {k: v for k, v in d.items() if k not in ("content", "description") and isinstance(v, (str, int, float, bool))}
                for d in docs
            ],
        )
        self.backend = b
        yield
        try:
            b._client.delete_collection("test_products_fake")
        except Exception:
            pass

    def test_semantic_search(self):
        req = SearchRequest(query="portable SSD storage", limit=5)
        hits = self.backend.search(req)
        assert len(hits) > 0

    def test_confusion_apple_widget_not_samsung(self):
        """ChromaDB: UltraWidget Pro is Apple, not Samsung."""
        req = SearchRequest(query="UltraWidget Pro", limit=5)
        hits = self.backend.search(req)
        # Find the UltraWidget Pro hit and verify supplier
        for h in hits:
            if h.get("id") == "conf-1001":
                assert h.get("supplier") == "Apple"
                break

    def test_search_returns_results(self):
        req = SearchRequest(query="networking hub enterprise", limit=3)
        hits = self.backend.search(req)
        assert len(hits) > 0
        assert "_rankingScore" in hits[0]


# ═══════════════════════════════════════════════════════════════════════════
#  Qdrant (docker: localhost:6333)
# ═══════════════════════════════════════════════════════════════════════════


def _qdrant_available() -> bool:
    try:
        from qdrant_client import QdrantClient
        client = QdrantClient(host="localhost", port=6333, timeout=2)
        client.get_collections()
        client.close()
        return True
    except Exception:
        return False


@pytest.mark.skipif(not _qdrant_available(), reason="Qdrant not running on localhost:6333")
class TestQdrantFakeData:
    COLLECTION = "test_fake_products"

    @pytest.fixture(autouse=True)
    def backend(self):
        from qdrant_client import QdrantClient, models
        from rag007.backend import QdrantBackend

        client = QdrantClient(host="localhost", port=6333)

        # Recreate collection
        try:
            client.delete_collection(self.COLLECTION)
        except Exception:
            pass

        client.create_collection(
            collection_name=self.COLLECTION,
            vectors_config=models.VectorParams(
                size=DIMENSION, distance=models.Distance.COSINE
            ),
        )

        docs = _all_products()
        batch_size = 500
        for i in range(0, len(docs), batch_size):
            batch = docs[i:i + batch_size]
            client.upsert(
                collection_name=self.COLLECTION,
                points=[
                    models.PointStruct(
                        id=idx + i,
                        vector=_fake_embed(d["content"]),
                        payload={k: v for k, v in d.items() if k != "content" or True},
                    )
                    for idx, d in enumerate(batch)
                ],
            )

        b = QdrantBackend(collection=self.COLLECTION, embed_fn=_fake_embed)
        b._client = client
        self.backend = b
        yield
        try:
            client.delete_collection(self.COLLECTION)
        except Exception:
            pass

    def test_semantic_search(self):
        req = SearchRequest(query="portable storage device", limit=10)
        hits = self.backend.search(req)
        assert len(hits) > 0
        assert "_rankingScore" in hits[0]

    def test_filter_supplier(self):
        from qdrant_client.models import FieldCondition, Filter, MatchValue

        filt = Filter(must=[FieldCondition(key="supplier", match=MatchValue(value="Samsung"))])
        req = SearchRequest(query="electronics", limit=20, filter_expr=filt)
        hits = self.backend.search(req)
        assert len(hits) > 0
        _assert_all_hits_match(hits, "supplier", {"Samsung"})

    def test_filter_category(self):
        from qdrant_client.models import FieldCondition, Filter, MatchValue

        filt = Filter(must=[FieldCondition(key="category", match=MatchValue(value="Storage"))])
        req = SearchRequest(query="data", limit=20, filter_expr=filt)
        hits = self.backend.search(req)
        assert len(hits) > 0
        _assert_all_hits_match(hits, "category", {"Storage"})

    def test_confusion_samsung_not_apple(self):
        """Qdrant: filtering Samsung should NOT return Apple products."""
        from qdrant_client.models import FieldCondition, Filter, MatchValue

        filt = Filter(must=[FieldCondition(key="supplier", match=MatchValue(value="Samsung"))])
        req = SearchRequest(query="UltraWidget", limit=10, filter_expr=filt)
        hits = self.backend.search(req)
        ids = {h.get("id") for h in hits}
        assert "conf-1001" not in ids, "UltraWidget Pro (Apple) returned for Samsung filter"

    def test_confusion_combined_filter(self):
        """Dell+Networking filter: should include PowerHub Max, exclude PowerHub Mini (Logitech)."""
        from qdrant_client.models import FieldCondition, Filter, MatchValue

        filt = Filter(must=[
            FieldCondition(key="supplier", match=MatchValue(value="Dell")),
            FieldCondition(key="category", match=MatchValue(value="Networking")),
        ])
        req = SearchRequest(query="PowerHub", limit=100, filter_expr=filt)
        hits = self.backend.search(req)
        ids = {h.get("id") for h in hits}
        # With filter, no Logitech products should appear
        for h in hits:
            assert h.get("supplier") == "Dell"
            assert h.get("category") == "Networking"
        # conf-1004 (Logitech) must never appear
        assert "conf-1004" not in ids

    def test_large_result_set(self):
        req = SearchRequest(query="product", limit=100)
        hits = self.backend.search(req)
        assert len(hits) == 100


# ═══════════════════════════════════════════════════════════════════════════
#  pgvector (docker: localhost:5433)
# ═══════════════════════════════════════════════════════════════════════════

PGVECTOR_DSN = "postgresql://test:test@localhost:5433/testdb"


def _pgvector_available() -> bool:
    try:
        import psycopg
        conn = psycopg.connect(PGVECTOR_DSN, connect_timeout=2)
        conn.close()
        return True
    except Exception:
        return False


@pytest.mark.skipif(not _pgvector_available(), reason="pgvector not running on localhost:5433")
class TestPgvectorFakeData:
    @pytest.fixture(autouse=True)
    def backend(self):
        import psycopg
        from rag007.backend import PgvectorBackend

        conn = psycopg.connect(PGVECTOR_DSN, autocommit=True)
        conn.execute("CREATE EXTENSION IF NOT EXISTS vector")
        conn.execute("DROP TABLE IF EXISTS fake_products")
        conn.execute(f"""
            CREATE TABLE fake_products (
                id VARCHAR PRIMARY KEY,
                name VARCHAR,
                sku VARCHAR,
                category VARCHAR,
                supplier VARCHAR,
                price DOUBLE PRECISION,
                in_stock BOOLEAN,
                released_at VARCHAR,
                content TEXT,
                language VARCHAR,
                embedding vector({DIMENSION})
            )
        """)

        docs = _all_products()
        for d in docs:
            vec = _fake_embed(d["content"])
            conn.execute(
                "INSERT INTO fake_products (id,name,sku,category,supplier,price,in_stock,released_at,content,language,embedding) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
                (d["id"], d["name"], d["sku"], d["category"], d["supplier"],
                 d["price"], d["in_stock"], d["released_at"], d["content"],
                 d["language"], vec),
            )
        conn.close()

        self.backend = PgvectorBackend(
            table="fake_products",
            dsn=PGVECTOR_DSN,
            embed_fn=_fake_embed,
            vector_column="embedding",
            content_column="content",
        )
        yield
        try:
            import psycopg
            conn = psycopg.connect(PGVECTOR_DSN, autocommit=True)
            conn.execute("DROP TABLE IF EXISTS fake_products")
            conn.close()
        except Exception:
            pass

    def test_semantic_search(self):
        req = SearchRequest(query="portable SSD storage", limit=10)
        hits = self.backend.search(req)
        assert len(hits) > 0
        assert "_rankingScore" in hits[0]

    def test_filter_supplier(self):
        req = SearchRequest(query="widget", limit=50, filter_expr="supplier = 'Apple'")
        hits = self.backend.search(req)
        _assert_all_hits_match(hits, "supplier", {"Apple"})

    def test_filter_price_range(self):
        req = SearchRequest(
            query="product", limit=50, filter_expr="price > 100 AND price < 500"
        )
        hits = self.backend.search(req)
        assert len(hits) > 0
        for h in hits:
            assert 100 < h["price"] < 500

    def test_filter_date_range(self):
        req = SearchRequest(
            query="product", limit=50,
            filter_expr="released_at >= '2025-01-01' AND released_at <= '2025-06-30'",
        )
        hits = self.backend.search(req)
        assert len(hits) > 0

    def test_confusion_samsung_filter_excludes_apple(self):
        req = SearchRequest(
            query="UltraWidget", limit=10, filter_expr="supplier = 'Samsung'"
        )
        hits = self.backend.search(req)
        ids = {h["id"] for h in hits}
        assert "conf-1001" not in ids

    def test_confusion_combined_filter(self):
        """Samsung+Storage filter must exclude Apple products."""
        req = SearchRequest(
            query="storage", limit=100,
            filter_expr="supplier = 'Samsung' AND category = 'Storage'"
        )
        hits = self.backend.search(req)
        for h in hits:
            assert h["supplier"] == "Samsung"
            assert h["category"] == "Storage"
        ids = {h["id"] for h in hits}
        assert "conf-1006" not in ids  # Apple, not Samsung

    def test_confusion_in_stock_false(self):
        """in_stock=false filter must exclude in-stock products."""
        req = SearchRequest(
            query="storage", limit=100, filter_expr="in_stock = false"
        )
        hits = self.backend.search(req)
        for h in hits:
            assert h["in_stock"] is False
        ids = {h["id"] for h in hits}
        assert "conf-1005" not in ids  # in_stock=true


# ═══════════════════════════════════════════════════════════════════════════
#  Meilisearch (docker: localhost:7700)
# ═══════════════════════════════════════════════════════════════════════════


def _meilisearch_available() -> bool:
    try:
        import meilisearch
        client = meilisearch.Client("http://localhost:7700", "masterKey")
        client.health()
        return True
    except Exception:
        return False


@pytest.mark.skipif(
    not _meilisearch_available(), reason="Meilisearch not running on localhost:7700"
)
class TestMeilisearchFakeData:
    INDEX = "test_fake_products"

    @pytest.fixture(autouse=True)
    def backend(self):
        import meilisearch
        from rag007.backend import MeilisearchBackend

        client = meilisearch.Client("http://localhost:7700", "masterKey")

        # Delete existing index
        try:
            client.index(self.INDEX).delete()
            time.sleep(1)
        except Exception:
            pass

        # Create index and configure
        task = client.create_index(self.INDEX, {"primaryKey": "id"})
        client.wait_for_task(task.task_uid)

        idx = client.index(self.INDEX)
        task = idx.update_filterable_attributes([
            "category", "supplier", "language", "in_stock", "price", "released_at", "tier",
        ])
        client.wait_for_task(task.task_uid)
        task = idx.update_searchable_attributes(["content", "name", "description", "sku"])
        client.wait_for_task(task.task_uid)
        task = idx.update_sortable_attributes(["price", "released_at"])
        client.wait_for_task(task.task_uid)

        # Add documents in batches
        docs = _all_products()
        batch_size = 1000
        for i in range(0, len(docs), batch_size):
            batch = docs[i:i + batch_size]
            # Strip embedding-heavy fields, keep searchable
            clean = [
                {k: v for k, v in d.items() if k != "embedding"}
                for d in batch
            ]
            task = idx.add_documents(clean)
            client.wait_for_task(task.task_uid)

        self.backend = MeilisearchBackend(index=self.INDEX)
        yield
        try:
            client.index(self.INDEX).delete()
        except Exception:
            pass

    def test_keyword_search(self):
        req = SearchRequest(query="UltraWidget", limit=10)
        hits = self.backend.search(req)
        assert len(hits) > 0
        _assert_hits_match(hits, "name", {"UltraWidget Pro", "UltraWidget Lite"})

    def test_filter_supplier(self):
        req = SearchRequest(
            query="product", limit=50, filter_expr="supplier = 'Apple'"
        )
        hits = self.backend.search(req)
        assert len(hits) > 0
        _assert_all_hits_match(hits, "supplier", {"Apple"})

    def test_filter_category(self):
        req = SearchRequest(
            query="product", limit=50, filter_expr="category = 'Electronics'"
        )
        hits = self.backend.search(req)
        assert len(hits) > 0
        _assert_all_hits_match(hits, "category", {"Electronics"})

    def test_filter_in_stock(self):
        req = SearchRequest(
            query="product", limit=50, filter_expr="in_stock = true"
        )
        hits = self.backend.search(req)
        assert len(hits) > 0
        _assert_all_hits_match(hits, "in_stock", {True})

    def test_filter_price_range(self):
        req = SearchRequest(
            query="product", limit=50, filter_expr="price > 100 AND price < 500"
        )
        hits = self.backend.search(req)
        assert len(hits) > 0
        for h in hits:
            assert 100 < h["price"] < 500

    def test_filter_combined(self):
        req = SearchRequest(
            query="product", limit=50,
            filter_expr="supplier = 'Samsung' AND category = 'Storage'",
        )
        hits = self.backend.search(req)
        for h in hits:
            assert h["supplier"] == "Samsung"
            assert h["category"] == "Storage"

    def test_confusion_ultrawidget_samsung_excludes_apple(self):
        req = SearchRequest(
            query="UltraWidget", limit=10, filter_expr="supplier = 'Samsung'"
        )
        hits = self.backend.search(req)
        ids = {h["id"] for h in hits}
        assert "conf-1001" not in ids, "UltraWidget Pro (Apple) leaked through Samsung filter"
        if hits:
            _assert_all_hits_match(hits, "supplier", {"Samsung"})

    def test_confusion_dell_networking(self):
        req = SearchRequest(
            query="PowerHub", limit=10,
            filter_expr="supplier = 'Dell' AND category = 'Networking'",
        )
        hits = self.backend.search(req)
        ids = {h["id"] for h in hits}
        assert "conf-1003" in ids
        assert "conf-1004" not in ids

    def test_sort_by_price(self):
        """Meilisearch sort: wildcard query + sort_fields gives pure sort order."""
        req = SearchRequest(
            query="",
            limit=10,
            filter_expr="category = 'Electronics'",
            sort_fields=["price:desc"],
        )
        hits = self.backend.search(req)
        assert len(hits) > 1
        prices = [h["price"] for h in hits]
        assert prices == sorted(prices, reverse=True), f"Not sorted desc: {prices}"

    def test_large_result_set(self):
        req = SearchRequest(query="product", limit=100)
        hits = self.backend.search(req)
        assert len(hits) == 100
