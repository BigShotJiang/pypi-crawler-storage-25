"""Backend integration tests.

pgvector: needs `podman compose -f docker-compose.test.yml up -d`
Azure AI Search: needs AZURE_SEARCH_ENDPOINT + AZURE_SEARCH_API_KEY env vars
Others: in-memory, no external deps required.

Run: uv run pytest tests/test_backends.py -v
"""

from __future__ import annotations

import os

import pytest
from dotenv import load_dotenv

load_dotenv()

from rag007.backend import SearchRequest

# ── Helpers ──────────────────────────────────────────────────────────────────

SAMPLE_DOCS = [
    {"id": "1", "content": "Python is a programming language", "category": "tech"},
    {"id": "2", "content": "The cat sat on the mat", "category": "animals"},
    {"id": "3", "content": "Machine learning uses neural networks", "category": "tech"},
    {"id": "4", "content": "Dogs are loyal companions", "category": "animals"},
    {"id": "5", "content": "PostgreSQL is a relational database", "category": "tech"},
]

DIMENSION = 8  # small dim for testing


def _fake_embed(text: str) -> list[float]:
    """Deterministic fake embeddings from text hash."""
    import hashlib

    h = hashlib.sha256(text.encode()).digest()
    vec = [float(b) / 255.0 for b in h[:DIMENSION]]
    norm = sum(v * v for v in vec) ** 0.5
    return [v / norm for v in vec]


def _docs_with_vectors() -> list[dict]:
    return [{**doc, "vector": _fake_embed(doc["content"])} for doc in SAMPLE_DOCS]


# ── ChromaDB ─────────────────────────────────────────────────────────────────


class TestChromaDBBackend:
    @pytest.fixture
    def backend(self):
        pytest.importorskip("chromadb")
        from rag007.backend import ChromaDBBackend

        b = ChromaDBBackend(collection="test_chroma")
        # Add docs
        b._collection.add(
            ids=[d["id"] for d in SAMPLE_DOCS],
            documents=[d["content"] for d in SAMPLE_DOCS],
            metadatas=[{"category": d["category"]} for d in SAMPLE_DOCS],
        )
        yield b
        # Cleanup
        try:
            b._client.delete_collection("test_chroma")
        except Exception:
            pass

    def test_search(self, backend):
        req = SearchRequest(query="programming language", limit=3)
        hits = backend.search(req)
        assert len(hits) > 0
        assert "content" in hits[0] or "id" in hits[0]

    def test_batch_search(self, backend):
        reqs = [
            SearchRequest(query="python", limit=2),
            SearchRequest(query="cat", limit=2),
        ]
        results = backend.batch_search(reqs)
        assert len(results) == 2

    def test_get_index_config(self, backend):
        cfg = backend.get_index_config()
        assert cfg is not None

    def test_sample_documents(self, backend):
        docs = backend.sample_documents(limit=3)
        assert len(docs) <= 3

    def test_custom_embed_fn(self):
        """Verify wrapped embed_fn is used by ChromaDB automatically."""
        pytest.importorskip("chromadb")
        from rag007.backend import ChromaDBBackend

        b = ChromaDBBackend(collection="test_chroma_ef", embed_fn=_fake_embed)
        b._collection.add(
            ids=[d["id"] for d in SAMPLE_DOCS],
            documents=[d["content"] for d in SAMPLE_DOCS],
            metadatas=[{"category": d["category"]} for d in SAMPLE_DOCS],
        )
        req = SearchRequest(query="programming language", limit=3)
        hits = b.search(req)
        assert len(hits) > 0
        assert "_rankingScore" in hits[0]
        b._client.delete_collection("test_chroma_ef")


# ── LanceDB ──────────────────────────────────────────────────────────────────


class TestLanceDBBackend:
    @pytest.fixture
    def backend(self, tmp_path):
        lancedb = pytest.importorskip("lancedb")
        from rag007.backend import LanceDBBackend

        db = lancedb.connect(str(tmp_path / "test.lance"))
        docs = _docs_with_vectors()
        db.create_table(
            "test_lance",
            data=[
                {
                    "id": d["id"],
                    "content": d["content"],
                    "category": d["category"],
                    "vector": d["vector"],
                }
                for d in docs
            ],
        )
        return LanceDBBackend(
            table="test_lance",
            db_uri=str(tmp_path / "test.lance"),
            embed_fn=_fake_embed,
            vector_column="vector",
            text_column="content",
        )

    def test_search(self, backend):
        req = SearchRequest(query="programming", limit=3)
        hits = backend.search(req)
        assert len(hits) > 0

    def test_sample_documents(self, backend):
        docs = backend.sample_documents(limit=3)
        assert len(docs) <= 5  # may get all


# ── DuckDB ───────────────────────────────────────────────────────────────────


class TestDuckDBBackend:
    @pytest.fixture
    def backend(self):
        pytest.importorskip("duckdb")
        from rag007.backend import DuckDBBackend

        b = DuckDBBackend(
            table="test_docs",
            db_path=":memory:",
            embed_fn=_fake_embed,
            vector_column="embedding",
            content_column="content",
        )
        # Create table + insert docs
        docs = _docs_with_vectors()
        b._conn.execute(f"""
            CREATE TABLE test_docs (
                id VARCHAR,
                content VARCHAR,
                category VARCHAR,
                embedding FLOAT[{DIMENSION}]
            )
        """)
        for d in docs:
            b._conn.execute(
                "INSERT INTO test_docs VALUES (?, ?, ?, ?::FLOAT[8])",
                [d["id"], d["content"], d["category"], d["vector"]],
            )
        return b

    def test_vector_search(self, backend):
        req = SearchRequest(query="programming", limit=3)
        hits = backend.search(req)
        assert len(hits) > 0
        assert "_rankingScore" in hits[0]

    def test_search_with_filter(self, backend):
        req = SearchRequest(
            query="programming", limit=5, filter_expr="category = 'tech'"
        )
        hits = backend.search(req)
        assert all(h.get("category") == "tech" for h in hits)

    def test_get_index_config(self, backend):
        cfg = backend.get_index_config()
        assert "content" in cfg.searchable_attributes

    def test_sample_documents(self, backend):
        docs = backend.sample_documents(limit=3)
        assert len(docs) == 3

    def test_sample_with_filter(self, backend):
        docs = backend.sample_documents(limit=10, filter_expr="category = 'animals'")
        assert all(d["category"] == "animals" for d in docs)


# ── pgvector ─────────────────────────────────────────────────────────────────

PGVECTOR_DSN = "postgresql://test:test@localhost:5433/testdb"


def _pgvector_available() -> bool:
    try:
        import psycopg

        conn = psycopg.connect(PGVECTOR_DSN, connect_timeout=2)
        conn.close()
        return True
    except Exception:
        return False


@pytest.mark.skipif(
    not _pgvector_available(),
    reason="pgvector container not running (podman compose -f docker-compose.test.yml up -d)",
)
class TestPgvectorBackend:
    @pytest.fixture(autouse=True)
    def backend(self):
        import psycopg
        from rag007.backend import PgvectorBackend

        # Setup: create extension + table
        conn = psycopg.connect(PGVECTOR_DSN, autocommit=True)
        conn.execute("CREATE EXTENSION IF NOT EXISTS vector")
        conn.execute("DROP TABLE IF EXISTS test_pgvec")
        conn.execute(f"""
            CREATE TABLE test_pgvec (
                id VARCHAR PRIMARY KEY,
                content TEXT,
                category VARCHAR,
                embedding vector({DIMENSION})
            )
        """)
        docs = _docs_with_vectors()
        for d in docs:
            conn.execute(
                "INSERT INTO test_pgvec (id, content, category, embedding) VALUES (%s, %s, %s, %s)",
                (d["id"], d["content"], d["category"], d["vector"]),
            )
        conn.close()

        self.backend = PgvectorBackend(
            table="test_pgvec",
            dsn=PGVECTOR_DSN,
            embed_fn=_fake_embed,
            vector_column="embedding",
            content_column="content",
        )
        yield
        # Cleanup
        try:
            self.backend._conn.execute("DROP TABLE IF EXISTS test_pgvec")
        except Exception:
            pass

    def test_vector_search(self):
        req = SearchRequest(query="programming", limit=3)
        hits = self.backend.search(req)
        assert len(hits) > 0
        assert "_rankingScore" in hits[0]

    def test_search_with_filter(self):
        req = SearchRequest(query="python", limit=5, filter_expr="category = 'tech'")
        hits = self.backend.search(req)
        assert len(hits) > 0
        assert all(h.get("category") == "tech" for h in hits)

    def test_text_search_fallback(self):
        req = SearchRequest(query="", limit=5)
        hits = self.backend.search(req)
        assert isinstance(hits, list)

    def test_get_index_config(self):
        cfg = self.backend.get_index_config()
        assert "content" in cfg.searchable_attributes

    def test_sample_documents(self):
        docs = self.backend.sample_documents(limit=3)
        assert len(docs) == 3


# ── Qdrant (in-memory) ──────────────────────────────────────────────────────


class TestQdrantBackend:
    @pytest.fixture
    def backend(self):
        pytest.importorskip("qdrant_client")
        from qdrant_client import QdrantClient, models
        from rag007.backend import QdrantBackend

        # Use in-memory Qdrant
        client = QdrantClient(":memory:")
        client.create_collection(
            collection_name="test_qdrant",
            vectors_config=models.VectorParams(
                size=DIMENSION, distance=models.Distance.COSINE
            ),
        )
        docs = _docs_with_vectors()
        client.upsert(
            collection_name="test_qdrant",
            points=[
                models.PointStruct(
                    id=int(d["id"]),
                    vector=d["vector"],
                    payload={"content": d["content"], "category": d["category"]},
                )
                for d in docs
            ],
        )

        b = QdrantBackend(collection="test_qdrant", embed_fn=_fake_embed)
        b._client = client  # inject in-memory client
        return b

    def test_search(self, backend):
        req = SearchRequest(query="programming", limit=3)
        hits = backend.search(req)
        assert len(hits) > 0
        assert "_rankingScore" in hits[0]

    def test_batch_search(self, backend):
        reqs = [
            SearchRequest(query="python", limit=2),
            SearchRequest(query="cat", limit=2),
        ]
        results = backend.batch_search(reqs)
        assert len(results) == 2

    def test_scroll_without_vector(self, backend):
        from rag007.backend import QdrantBackend

        b = QdrantBackend.__new__(QdrantBackend)
        b._collection = "test_qdrant"
        b._embed_fn = None
        b._client = backend._client
        req = SearchRequest(query="anything", limit=3)
        hits = b.search(req)  # no embed_fn → falls back to scroll
        assert isinstance(hits, list)

    def test_get_index_config(self, backend):
        cfg = backend.get_index_config()
        assert cfg is not None

    def test_sample_documents(self, backend):
        docs = backend.sample_documents(limit=3)
        assert len(docs) <= 5


# ── Azure AI Search ──────────────────────────────────────────────────────────


@pytest.mark.skipif(
    not os.getenv("AZURE_SEARCH_API_KEY"),
    reason="AZURE_SEARCH_API_KEY not set",
)
class TestAzureAISearchBackend:
    @pytest.fixture
    def backend(self):
        pytest.importorskip("azure.search.documents")
        from rag007.backend import AzureAISearchBackend

        return AzureAISearchBackend(
            index=os.getenv("AZURE_SEARCH_INDEX", "test-index"),
            endpoint=os.getenv(
                "AZURE_SEARCH_ENDPOINT", "https://aisearchtestbms.search.windows.net"
            ),
        )

    def test_search(self, backend):
        req = SearchRequest(query="test", limit=3)
        hits = backend.search(req)
        assert isinstance(hits, list)

    def test_sample_documents(self, backend):
        docs = backend.sample_documents(limit=3)
        assert isinstance(docs, list)

    def test_get_index_config(self, backend):
        cfg = backend.get_index_config()
        assert cfg is not None
