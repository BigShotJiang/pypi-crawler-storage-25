from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, runtime_checkable

from langchain_core.documents import Document
from pydantic import BaseModel, ConfigDict, Field


@dataclass
class RerankResult:
    """Single reranking result."""

    index: int
    relevance_score: float


@runtime_checkable
class Reranker(Protocol):
    """Protocol for reranking backends.

    Any object exposing this signature can be used as a reranker —
    no inheritance required.
    """

    def rerank(
        self,
        query: str,
        documents: list[str],
        top_n: int,
    ) -> list[RerankResult]: ...


class ConversationTurn(BaseModel):
    question: str
    answer: str


class RAGState(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    question: str = ""
    query: str = ""
    query_variants: list[str] = Field(default_factory=list)
    adaptive_semantic_ratio: float | None = None
    adaptive_fusion: str | None = None
    documents: list[Document] = Field(default_factory=list)
    answer: str | None = None
    iterations: int = 0
    history: list[ConversationTurn] = Field(default_factory=list)
    quality_ok: bool | None = None
    filter_intent: "FilterIntent | None" = None
    selected_collections: list[str] = Field(default_factory=list)
    expert_fired: bool = False


class SearchQuery(BaseModel):
    query: str
    variants: list[str] = []
    semantic_ratio: float = 0.5
    fusion: str = "rrf"


class QualityAssessment(BaseModel):
    sufficient: bool
    reason: str


class MultiQuery(BaseModel):
    queries: list[str]


class FilterIntent(BaseModel):
    field: str | None
    value: str
    operator: str


class CollectionIntent(BaseModel):
    """LLM-selected subset of collection names to query."""

    collections: list[str] = Field(default_factory=list)


RAGState.model_rebuild()
