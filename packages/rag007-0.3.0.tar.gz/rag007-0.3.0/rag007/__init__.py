"""Agentic RAG — LangGraph + multi-backend retrieval-augmented generation."""

from .factory import init_agent
from .backend import (
    AzureAISearchBackend,
    ChromaDBBackend,
    DuckDBBackend,
    InMemoryBackend,
    IndexConfig,
    LanceDBBackend,
    MeilisearchBackend,
    PgvectorBackend,
    QdrantBackend,
    SearchBackend,
    SearchRequest,
)
from .core import AgenticRAG
from .models import ConversationTurn, RAGState, Reranker, RerankResult
from .rerankers import (
    CohereReranker,
    HuggingFaceReranker,
    JinaReranker,
    LLMReranker,
    RerankersReranker,
)
from .utils import _dbsf_fuse, _make_azure_embed_fn, _rrf_fuse

Agent = AgenticRAG

__all__ = [
    "Agent",
    "AgenticRAG",
    "init_agent",
    "AzureAISearchBackend",
    "ChromaDBBackend",
    "CohereReranker",
    "HuggingFaceReranker",
    "JinaReranker",
    "RerankersReranker",
    "ConversationTurn",
    "DuckDBBackend",
    "InMemoryBackend",
    "IndexConfig",
    "LLMReranker",
    "LanceDBBackend",
    "MeilisearchBackend",
    "PgvectorBackend",
    "QdrantBackend",
    "RAGState",
    "Reranker",
    "RerankResult",
    "SearchBackend",
    "SearchRequest",
    "_dbsf_fuse",
    "_make_azure_embed_fn",
    "_rrf_fuse",
]
