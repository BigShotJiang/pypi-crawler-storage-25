"""
rag007 — Interactive RAG CLI

Usage:
    rag007                    # guided setup wizard
    rag007 --chat             # chat mode (default after setup)
    rag007 --retriever        # retriever-only mode (no LLM answer)
    rag007 -c my_index        # specify collection/index name
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import warnings
from typing import Any, Callable

warnings.filterwarnings(
    "ignore",
    message="Core Pydantic V1 functionality",
    category=UserWarning,
    module="langchain_core",
)

# Optional: python-dotenv for .env loading
try:
    from dotenv import load_dotenv

    load_dotenv()
except ModuleNotFoundError:
    pass

# Optional: rich for pretty output — falls back to plain print
try:
    from rich.console import Console
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.prompt import Prompt
    from rich.rule import Rule
    from rich.table import Table

    _console = Console()
    _HAS_RICH = True
except ModuleNotFoundError:
    _HAS_RICH = False
    _console = None  # type: ignore[assignment]

from langchain_core.documents import Document  # noqa: E402

from . import AgenticRAG, ConversationTurn  # noqa: E402


# ── Output helpers (rich or plain) ────────────────────────────────────────────


def _print(msg: str = "", **kwargs: Any) -> None:
    if _HAS_RICH:
        _console.print(msg, **kwargs)
    else:
        # Strip basic rich markup for plain output
        import re

        plain = re.sub(r"\[/?[^\]]*\]", "", msg)
        print(plain)


def _prompt(label: str, default: str = "", choices: list[str] | None = None) -> str:
    if _HAS_RICH:
        return Prompt.ask(label, default=default, console=_console)
    display = f"{label}"
    if default:
        display += f" [{default}]"
    display += ": "
    ans = input(display).strip()
    if not ans:
        return default
    if choices and ans not in choices:
        print(f"  Invalid choice: {ans}. Options: {', '.join(choices)}")
        return _prompt(label, default, choices)
    return ans


def _banner(text: str) -> None:
    if _HAS_RICH:
        _console.print(Panel.fit(text, border_style="bold blue"))
    else:
        width = len(text) + 4
        print("=" * width)
        print(f"  {text}")
        print("=" * width)


def _section(title: str) -> None:
    if _HAS_RICH:
        _console.print(f"\n[bold cyan]{title}[/bold cyan]")
        _console.print(Rule(style="dim"))
    else:
        print(f"\n--- {title} ---")


def _option_table(options: list[tuple[str, str, str]]) -> None:
    """Show options as table: (key, description, extras_needed)."""
    if _HAS_RICH:
        table = Table(show_header=True, header_style="bold", box=None)
        table.add_column("Choice", style="bold green", no_wrap=True)
        table.add_column("Description")
        table.add_column("Extra", style="dim")
        for key, desc, extra in options:
            table.add_row(key, desc, extra or "base")
        _console.print(table)
    else:
        for key, desc, extra in options:
            tag = f" (requires: pip install rag007[{extra}])" if extra else ""
            print(f"  {key:<14} {desc}{tag}")


# ── Dependency checker ────────────────────────────────────────────────────────


def _check_import(module: str, pip_extra: str) -> bool:
    try:
        __import__(module)
        return True
    except ModuleNotFoundError:
        _print(
            f"[bold red]Missing:[/bold red] {module}. "
            f"Install with: [bold]pip install rag007[{pip_extra}][/bold]"
        )
        return False


# ── Embedder builders ─────────────────────────────────────────────────────────


def _build_openai_embed() -> Callable[[str], list[float]] | None:
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        _print("[yellow]OPENAI_API_KEY not set. Set it or choose another embedder.[/yellow]")
        return None
    model = _prompt("  Embedding model", default="text-embedding-3-small")
    import requests

    session = requests.Session()
    session.headers.update(
        {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    )

    def _embed(text: str) -> list[float]:
        resp = session.post(
            "https://api.openai.com/v1/embeddings",
            json={"input": [text], "model": model},
            timeout=15,
        )
        resp.raise_for_status()
        return resp.json()["data"][0]["embedding"]

    return _embed


def _build_azure_embed() -> Callable[[str], list[float]] | None:
    from .utils import _make_azure_embed_fn

    fn = _make_azure_embed_fn()
    if fn is None:
        _print(
            "[yellow]Azure OpenAI env vars not set "
            "(AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_API_KEY).[/yellow]"
        )
    return fn


def _build_ollama_embed() -> Callable[[str], list[float]] | None:
    url = _prompt("  Ollama URL", default="http://localhost:11434")
    model = _prompt("  Embedding model", default="nomic-embed-text")
    import requests

    def _embed(text: str) -> list[float]:
        resp = requests.post(
            f"{url}/api/embed",
            json={"model": model, "input": text},
            timeout=30,
        )
        resp.raise_for_status()
        return resp.json()["embeddings"][0]

    # Test connection
    try:
        _embed("test")
        return _embed
    except Exception as exc:
        _print(f"[yellow]Ollama connection failed: {exc}[/yellow]")
        return None


_EMBEDDER_OPTIONS: list[tuple[str, str, str]] = [
    ("openai", "OpenAI API (text-embedding-3-small)", ""),
    ("azure", "Azure OpenAI (from env vars)", ""),
    ("ollama", "Ollama local (nomic-embed-text, etc.)", ""),
    ("none", "No embeddings (BM25/keyword only)", ""),
]

_EMBEDDER_BUILDERS: dict[str, Callable[[], Callable[[str], list[float]] | None]] = {
    "openai": _build_openai_embed,
    "azure": _build_azure_embed,
    "ollama": _build_ollama_embed,
}

# ── Backend options ───────────────────────────────────────────────────────────

_BACKEND_OPTIONS: list[tuple[str, str, str]] = [
    ("memory", "In-memory (no setup, great for testing)", ""),
    ("duckdb", "DuckDB (local file, fast)", "duckdb"),
    ("chromadb", "ChromaDB (local or server)", "chromadb"),
    ("meilisearch", "Meilisearch (full-text + vector)", "meilisearch"),
    ("qdrant", "Qdrant (vector DB, local or cloud)", "qdrant"),
    ("pgvector", "PostgreSQL + pgvector", "pgvector"),
    ("lancedb", "LanceDB (columnar vector DB)", "lancedb"),
    ("azure", "Azure AI Search", "azure"),
]

_BACKEND_MODULES: dict[str, str] = {
    "duckdb": "duckdb",
    "chromadb": "chromadb",
    "meilisearch": "meilisearch",
    "qdrant": "qdrant_client",
    "pgvector": "psycopg",
    "lancedb": "lancedb",
    "azure": "azure.search.documents",
}

# ── Reranker options ──────────────────────────────────────────────────────────

_RERANKER_OPTIONS: list[tuple[str, str, str]] = [
    ("none", "No reranker (skip reranking step)", ""),
    ("cohere", "Cohere Rerank (API, best quality)", "cohere"),
    ("jina", "Jina Reranker (API)", "jina"),
    ("huggingface", "HuggingFace cross-encoder (local)", "huggingface"),
    ("llm", "LLM-based reranker (uses your chat model)", ""),
]

# ── LLM options ───────────────────────────────────────────────────────────────

_LLM_OPTIONS: list[tuple[str, str, str]] = [
    ("openai", "OpenAI (gpt-4o, gpt-4o-mini, ...)", ""),
    ("anthropic", "Anthropic (claude-sonnet-4-6, ...)", ""),
    ("ollama", "Ollama local (llama3, mistral, ...)", ""),
    ("env", "Use default from env vars", ""),
]


# ── Wizard ────────────────────────────────────────────────────────────────────


def _wizard() -> dict[str, Any]:
    """Interactive setup wizard. Returns kwargs for init_agent."""
    _banner("rag007 — Setup Wizard")

    # ── 1. LLM ────────────────────────────────────────────────────────────────
    _section("1. Chat / Generation LLM")
    _option_table(_LLM_OPTIONS)
    llm_choice = _prompt("  Choose LLM provider", default="openai")

    model: str | None = None
    if llm_choice == "openai":
        model_name = _prompt("  Model name", default="gpt-4o-mini")
        model = f"openai:{model_name}"
    elif llm_choice == "anthropic":
        model_name = _prompt("  Model name", default="claude-sonnet-4-6")
        model = f"anthropic:{model_name}"
    elif llm_choice == "ollama":
        model_name = _prompt("  Model name", default="llama3")
        model = f"ollama:{model_name}"
    # else: env → model=None, uses env default

    # ── 2. Embedder ───────────────────────────────────────────────────────────
    _section("2. Embedding Model")
    _option_table(_EMBEDDER_OPTIONS)
    embed_choice = _prompt("  Choose embedder", default="openai")

    embed_fn: Callable[[str], list[float]] | None = None
    if embed_choice in _EMBEDDER_BUILDERS:
        embed_fn = _EMBEDDER_BUILDERS[embed_choice]()
        if embed_fn is None and embed_choice != "none":
            _print("[dim]Falling back to no embeddings (BM25 only).[/dim]")

    # ── 3. Backend ────────────────────────────────────────────────────────────
    _section("3. Vector Store / Backend")
    _option_table(_BACKEND_OPTIONS)
    backend_choice = _prompt("  Choose backend", default="memory")

    backend_url: str | None = None
    backend_kwargs: dict[str, Any] = {}
    index = "default"

    # Check dependency
    if backend_choice in _BACKEND_MODULES:
        mod = _BACKEND_MODULES[backend_choice]
        if not _check_import(mod, backend_choice):
            _print("[dim]Falling back to in-memory backend.[/dim]")
            backend_choice = "memory"

    if backend_choice == "memory":
        index = "in_memory"
        _print("  [dim]In-memory backend selected. Load data after setup.[/dim]")
    elif backend_choice == "meilisearch":
        backend_url = _prompt("  Meilisearch URL", default="http://localhost:7700")
        api_key = _prompt("  API key", default="masterKey")
        backend_kwargs["api_key"] = api_key
        index = _prompt("  Index name", default="documents")
    elif backend_choice == "qdrant":
        backend_url = _prompt("  Qdrant URL", default="http://localhost:6333")
        index = _prompt("  Collection name", default="documents")
    elif backend_choice == "pgvector":
        dsn = _prompt("  PostgreSQL DSN", default="postgresql://localhost:5432/ragdb")
        backend_kwargs["dsn"] = dsn
        index = _prompt("  Table name", default="documents")
    elif backend_choice == "chromadb":
        index = _prompt("  Collection name", default="documents")
    elif backend_choice == "duckdb":
        db_path = _prompt("  DB path", default=":memory:")
        if db_path != ":memory:":
            backend_kwargs["db_path"] = db_path
        index = _prompt("  Table name", default="documents")
    elif backend_choice == "lancedb":
        db_path = _prompt("  DB path", default="./lancedb")
        backend_kwargs["db_path"] = db_path
        index = _prompt("  Table name", default="documents")
    elif backend_choice == "azure":
        backend_url = _prompt(
            "  Azure Search endpoint",
            default=os.getenv("AZURE_SEARCH_ENDPOINT", ""),
        )
        index = _prompt("  Index name", default="documents")

    # ── 4. Reranker ───────────────────────────────────────────────────────────
    _section("4. Reranker")
    _option_table(_RERANKER_OPTIONS)
    reranker_choice = _prompt("  Choose reranker", default="none")

    reranker: str | None = None
    reranker_model: str | None = None
    if reranker_choice != "none":
        reranker = reranker_choice
        if reranker_choice == "huggingface":
            reranker_model = _prompt(
                "  Model", default="cross-encoder/ms-marco-MiniLM-L-6-v2"
            )
        elif reranker_choice == "cohere":
            if not os.getenv("COHERE_API_KEY"):
                _print("[yellow]COHERE_API_KEY not set.[/yellow]")

    return {
        "index": index,
        "model": model,
        "backend": backend_choice,
        "backend_url": backend_url,
        "backend_kwargs": backend_kwargs or None,
        "embed_fn": embed_fn,
        "reranker": reranker,
        "reranker_model": reranker_model,
    }


# ── Data loading ──────────────────────────────────────────────────────────────


def _load_documents(rag: AgenticRAG) -> None:
    """Optionally load documents from a JSON file into the backend."""
    _section("Load Documents")
    _print("  Load documents from a JSON file?")
    _print("  Format: list of objects, each with text fields.")
    path = _prompt("  File path (or skip)", default="skip")
    if path == "skip":
        return

    path = os.path.expanduser(path)
    if not os.path.isfile(path):
        _print(f"[red]File not found: {path}[/red]")
        return

    try:
        with open(path) as f:
            data = json.load(f)
        if not isinstance(data, list):
            _print("[red]Expected a JSON array of objects.[/red]")
            return
        _print(f"  Loading {len(data)} documents...")
        rag.backend.add_documents(data)
        _print(f"  [bold green]Loaded {len(data)} documents.[/bold green]")
    except Exception as exc:
        _print(f"[red]Error loading: {exc}[/red]")


# ── Citation formatting ───────────────────────────────────────────────────────


def format_citation_line(i: int, doc: Document) -> str:
    title = doc.metadata.get("title") or doc.metadata.get("name") or ""
    url = doc.metadata.get("url") or doc.metadata.get("link") or ""
    source = doc.metadata.get("source") or ""
    label = title or source or doc.page_content[:60].replace("\n", " ") + "..."
    suffix = f" -- {url}" if url else ""
    return f"[{i}] {label}{suffix}"


# ── Rendering -----------------------------------------------------------------


def render_sources(docs: list[Document]) -> None:
    if not docs:
        return
    if _HAS_RICH:
        _console.print(Rule("[dim]Sources[/dim]"))
        for i, doc in enumerate(docs, 1):
            line = format_citation_line(i, doc)
            _console.print(f"  [dim cyan]{line}[/dim cyan]")
    else:
        print("--- Sources ---")
        for i, doc in enumerate(docs, 1):
            line = format_citation_line(i, doc)
            print(f"  {line}")


def render_answer(answer: str, docs: list[Document]) -> None:
    if _HAS_RICH:
        _console.print()
        _console.print(
            Panel(
                Markdown(answer),
                title="[bold green]Answer[/bold green]",
                border_style="green",
                expand=True,
            )
        )
    else:
        print(f"\n=== Answer ===\n{answer}\n")
    render_sources(docs)


# ── Retriever mode ────────────────────────────────────────────────────────────


def run_retriever(rag: AgenticRAG, question: str, top_k: int | None = None) -> None:
    if _HAS_RICH:
        with _console.status("[bold yellow]Retrieving...[/bold yellow]", spinner="dots"):
            query, docs = rag.retrieve_documents(question, top_k=top_k)
    else:
        print("Retrieving...")
        query, docs = rag.retrieve_documents(question, top_k=top_k)

    _print(f"\n  Search query: {query}\n")

    if not docs:
        _print("  No documents found.")
        return

    for i, doc in enumerate(docs, 1):
        title = (
            doc.metadata.get("name")
            or doc.metadata.get("title")
            or doc.page_content[:60]
        )
        _print(f"  [bold]#{i}[/bold] {title}")
        # Show a few metadata fields
        for k, v in list(doc.metadata.items())[:5]:
            if isinstance(v, (str, int, float)) and v and k not in ("id", "_id", "score"):
                _print(f"    {k}: {v}")


# ── Chat runner ───────────────────────────────────────────────────────────────


def run_chat(
    rag: AgenticRAG,
    question: str,
    history: list[ConversationTurn],
) -> ConversationTurn | None:
    if _HAS_RICH:
        with _console.status("[bold green]Thinking...[/bold green]", spinner="dots"):
            state = rag.chat(question, history)
    else:
        print("Thinking...")
        state = rag.chat(question, history)

    answer = state.answer or ""
    docs = state.documents

    _print(f"\n  Search query: {state.query or question}")

    if not answer:
        _print("  No answer generated.")
        return None

    render_answer(answer, docs)
    return ConversationTurn(question=question, answer=answer)


# ── Main ──────────────────────────────────────────────────────────────────────


def main() -> None:
    parser = argparse.ArgumentParser(description="rag007 — Agentic RAG CLI")
    parser.add_argument("--collection", "-c", default=None, help="Index/collection name")
    parser.add_argument("--top-k", "-k", type=int, default=None, help="Max documents")

    mode_group = parser.add_mutually_exclusive_group()
    mode_group.add_argument(
        "--chat", dest="mode", action="store_const", const="chat", help="Chat mode"
    )
    mode_group.add_argument(
        "--retriever",
        dest="mode",
        action="store_const",
        const="retriever",
        help="Retriever mode",
    )
    mode_group.add_argument("--mode", "-m", choices=["chat", "retriever"], default=None)

    parser.add_argument(
        "--skip-wizard", action="store_true", help="Skip setup wizard (use env defaults)"
    )

    args = parser.parse_args()

    # ── Wizard or env defaults ────────────────────────────────────────────────
    if args.skip_wizard:
        from .utils import _make_azure_embed_fn

        config: dict[str, Any] = {
            "index": args.collection or os.getenv("MS_INDEX", "documents"),
            "embed_fn": _make_azure_embed_fn(),
        }
    else:
        config = _wizard()

    if args.collection:
        config["index"] = args.collection

    # ── Build agent ───────────────────────────────────────────────────────────
    _section("Initialising")
    _print("  Building RAG agent...")

    from .factory import init_agent

    try:
        rag = init_agent(**{k: v for k, v in config.items() if v is not None})
    except Exception as exc:
        _print(f"[bold red]Failed to initialise: {exc}[/bold red]")
        sys.exit(1)

    # ── Load data for in-memory backend ───────────────────────────────────────
    if config.get("backend") == "memory":
        _load_documents(rag)

    # ── Mode selection ────────────────────────────────────────────────────────
    mode: str = args.mode or "chat"
    if args.mode is None and not args.skip_wizard:
        _section("5. Mode")
        _print("  [bold]chat[/bold]       — Ask questions, get answers with citations")
        _print("  [bold]retriever[/bold]  — Search only, no LLM generation")
        mode = _prompt("  Choose mode", default="chat")

    _print(f"\n  [bold green]Ready![/bold green] Mode: {mode}")
    _print("  Type your question. [bold]q[/bold] to quit, [bold]clear[/bold] to reset history.\n")

    # ── REPL ──────────────────────────────────────────────────────────────────
    history: list[ConversationTurn] = []

    while True:
        if mode == "chat" and history:
            _print(f"  [dim]({len(history)} turn{'s' if len(history) != 1 else ''} in context)[/dim]")

        try:
            question = _prompt("[bold blue]>[/bold blue]")
        except (KeyboardInterrupt, EOFError):
            _print("\nBye.")
            sys.exit(0)

        q = question.strip()
        if not q:
            continue
        if q.lower() in {"q", "quit", "exit"}:
            _print("Bye.")
            break
        if mode == "chat" and q.lower() == "clear":
            history.clear()
            _print("  History cleared.\n")
            continue

        try:
            if mode == "retriever":
                run_retriever(rag, q, top_k=args.top_k)
            else:
                turn = run_chat(rag, q, history)
                if turn:
                    history.append(turn)
        except Exception as exc:
            _print(f"[bold red]Error:[/bold red] {exc}")
        _print()


if __name__ == "__main__":
    main()
