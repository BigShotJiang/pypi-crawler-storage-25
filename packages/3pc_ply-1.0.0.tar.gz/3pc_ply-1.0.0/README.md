# 3pc-ply

`3pc-ply` is a Python library used to define and compute the properties of a composite ply based on classical lamination theory. It provides a `Ply` class to define ply properties like angle and thickness, built upon an `Orthotropic` material (provided by the `3pc-material` package).

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install `3pc-ply`. Since both `3pc-ply` and `3pc-material` are publicly available on PyPI, you can install them directly:

```bash
pip install 3pc-ply 3pc-material
```

## API Reference

### `Ply` Class

The primary component of this package is the `Ply` class, which holds geometric properties of the ply and dynamically calculates transformed stiffness matrices and expansion vectors.

```python
from ply.ply import Ply
```

#### Required Parameters

When initializing `Ply` directly, the following parameters are required:

*   **`plyID`** *(str)*: Ply identifier.
*   **`angle`** *(float)*: Ply angle in degrees.
*   **`material`** *(Orthotropic)*: An instance of `material.Orthotropic` representing the material properties of the ply (Note: `Orthotropic` is defined in the `3pc-material` package).
*   **`thickness`** *(float)*: Ply thickness.

#### Calculated Properties

The class automatically calculates the following properties lazily:

*   **`Q`**: Reduced stiffness matrix of the ply in material orthotropy (1-2 axes).
*   **`T`**: Transformation matrix to convert tensorial stress/strain between reference axes (x-y) and material orthotropy (1-2).
*   **`R`**: Conversion matrix to convert tensorial strain matrix into engineering strain matrix.
*   **`Qbar`**: Transformed reduced stiffness matrix in reference coordinate axes (x-y).
*   **`Q44`**, **`Q55`**: Transverse stiffness in material direction.
*   **`Q44bar`**, **`Q45bar`**, **`Q55bar`**: Transformed transverse stiffness in reference coordinate axes (x-y).
*   **`alpha`**: Thermal expansion vector in material coordinate axes (1-2).
*   **`beta`**: Hygral (moisture) expansion vector in material coordinate axes (1-2).
*   **`alphabar`**: Transformed thermal expansion vector in reference coordinate axes (x-y).
*   **`betabar`**: Transformed hygral expansion vector in reference coordinate axes (x-y).

### Methods

#### `Ply.fromDict(**kwargs)`

Initializes a `Ply` instance using a dictionary of keyword arguments. This is ideal for loading configurations from JSON files or dictionaries.

---

## Usage Examples

### Basic Initialization

Below is an example of defining an orthotropic material and creating plies at different angles. 

```python
from material.orthotropic import Orthotropic
from ply.ply import Ply

# Define the material first
zg_material = Orthotropic(
    matID="zg",
    E1=181.0, 
    E2=10.3,
    G12=7.17, 
    G13=7.17, 
    G23=7.17, 
    v12=0.28
)

# 0-degree ply
ply_0_deg = Ply(
    plyID="1", 
    angle=0.0, 
    material=zg_material, 
    thickness=0.125
)

# 90-degree ply
ply_90_deg = Ply(
    plyID="2", 
    angle=90.0, 
    material=zg_material, 
    thickness=0.125
)

# Access Computed Properties
print("Q Matrix (0-deg ply):\\n", ply_0_deg.Q)
print("Qbar Matrix (90-deg ply):\\n", ply_90_deg.Qbar)
print("Transformation Matrix T (90-deg ply):\\n", ply_90_deg.T)
```

### Initializing from a Dictionary

You can load your plies directly from a JSON source.

```python
ply_dict = {
    "plyID": "3",
    "angle": 45.0,
    "material": zg_material,
    "thickness": 0.125
}

ply_45_deg = Ply.fromDict(**ply_dict)
print("Qbar Matrix (45-deg ply):\\n", ply_45_deg.Qbar)
```

## Commands

The package provides a command-line interface entry point. After installing, you can run the main application using:

```bash
ply
```
*(Currently, this serves as an entry point defined in `ply.main:main`)*
