import numpy as np
import json
from material.orthotropic import Orthotropic
from ply.ply import Ply

materialFile = 'material.json'
plyFile = 'ply.json'
Q = np.array([[181.81, 2.9, 0.], [2.9, 10.35, 0.], [0., 0., 7.17]])
Q1 = np.array([[10.35, 2.9, 0.], [2.9, 181.81, 0.], [0., 0., 7.17]])

class TestPly:
    """Unitest of Ply Object"""

    materials = {}
    plies = {}

    @classmethod
    def setup_class(cls):
        """Set up the class using material file and ply file."""
        
        with open(materialFile, 'r') as fh:
            jsonData = json.load(fh)
        for materialDict in jsonData["materials"]:
            matID = materialDict["matID"]
            E1 = materialDict["E1"]
            E2 = materialDict["E2"]
            G12 = materialDict["G12"]
            G13 = materialDict["G13"]
            G23 = materialDict["G23"]
            v12 = materialDict["v12"]
            cls.materials[matID] = Orthotropic(matID=matID, E1=E1, E2=E2, G12=G12, G13=G13, G23=G23, v12=v12)

        with open(plyFile, 'r') as fh:
            jsonData = json.load(fh)
        for plyDict in jsonData["plies"]:
            plyID = plyDict["plyID"]
            angle = plyDict["angle"]
            material = cls.materials[plyDict["material"]]
            thickness = plyDict["thickness"]
            cls.plies[plyID] = Ply(plyID=plyID, angle=angle, material=material, thickness=thickness)

    def test_can_read_ply(self):
        """Unittest to check if Ply is initialized properly."""

        assert "1" in self.plies

    def test_ply1_Q(self):
        """Unittest to check 0-deg ply Q matrix."""

        #print("\n", self.plies["1"].Q)
        np.testing.assert_array_almost_equal(self.plies["1"].Q, Q, decimal=1)

    def test_ply2_Q(self):
        """Unittest to check 90-deg ply Q matrix."""

        np.testing.assert_array_almost_equal(self.plies["2"].Q, Q, decimal=1)

    def test_ply1_Qbar(self):
        """Unitetst to check 0-deg ply Qbar matrix."""

        #print("\n", self.plies["1"].Qbar)
        np.testing.assert_array_almost_equal(self.plies["1"].Qbar, Q, decimal=1)

    def test_ply2_Qbar(self):
        """Unittest to check 90-deg ply Qbar matrix."""
        
        #print("\n", self.plies["2"].Qbar)
        np.testing.assert_array_almost_equal(self.plies["2"].Qbar, Q1, decimal=1)


