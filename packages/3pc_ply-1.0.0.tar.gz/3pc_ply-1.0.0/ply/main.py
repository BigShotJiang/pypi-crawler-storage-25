def main():
    """Main function of ply command line application."""
    
    pass

if __name__ == '__main__':
    """Main entry point of ply command line application."""

    main()
