#!/usr/bin/python
# type: ignore
"""Popoto Python API.

This module provides a Python interface to the Popoto acoustic modem.
It can run on the modem hardware or remotely from a host machine.
"""

from socket import socket, AF_INET, SOCK_STREAM, IPPROTO_TCP, TCP_NODELAY
import sys
import time
import threading
import json
import queue
import struct
import random
import logging
import os
import os.path
import string
import select
import traceback
import io
import shlex

FRAMESIZE = 640
VERSION_SERVER_PORT = 39484
VERSION_SERVER_TIMEOUT_SECONDS = 5

PCMLOG_OFFSET = 2
CAPTURES_PARTITION = '/dev/mmcblk0p3'
CAPTURES_PARTITION_DEVICE = '/dev/mmcblk0'
CAPTURES_PARTITION_NUMBER = 3
FULLSD_FILE = '/etc/sd_full'

SUPERFRAME_SIZE = 2048
'''The size of the superframe for streaming'''

class popoto:
    """High-level client for controlling a Popoto Modem over TCP.

    Public methods issue commands to the Popoto application, which the modem
    responds to with JSON strings. These strings are collected and parsed by a
    background worker thread that enqueues the resulting Python dictionaries in
    the `popoto` instance's reply queue (`popoto.replyQ`).

    Initialize the class with the modem's host address and base application
    port. The base port corresponds to the control port exposed by the modem
    firmware -- by default, this is TCP port 17000.
    
    **Constructor Args:**
    
    - ip (str):
        Hostname or IP address of the target Popoto modem.
    
    - basePort (int):
        Base TCP port exposed by the modem application; other service ports are derived from this value.
    
    - logname (str | None):
        Optional logger name to configure the instance-specific logger.
    
    Attributes:
        logger (logging.Logger): Instance-specific logger.
        pcmplayport (int): PCM playback port derived from `basePort`.
        pcmioport (int): PCM I/O port derived from `basePort`.
        pcmlogport (int): PCM log port derived from `basePort`.
        dataport (int): Data port derived from `basePort`.
        cmdport (int): Control port derived from `basePort`.
        rawTerminal (bool): Toggle for ANSI styling in displayed replies.
        quiet (int): Reply display verbosity flag used by helper methods.
        cmdsocket (socket.socket): Command socket to the modem.
        SampFreq (int): Sample frequency for audio streaming.
        pcmplaysocket (socket.socket | int): PCM playback socket (0 until opened).
        recByteCount (int): Byte counter for PCM receive.
        ip (str): Hostname or IP address of the target modem.
        is_running (bool): Indicates whether the client is running.
        fp (io.IOBase | None): Open file handle for PCM I/O operations.
        fileLock (threading.Lock): Lock guarding file I/O.
        rxThread (threading.Thread): Background command receive thread.
        replyQ (queue.Queue): Queue of parsed JSON replies.
        datasocket (socket.socket | None): Data socket for payloads.
        intParams (dict[str, int]): Cached integer parameter values.
        floatParams (dict[str, float]): Cached float parameter values.
        paramsList (list[dict]): Parameter metadata list.
        varcache (dict[str, object]): General-purpose cached values.
        cachingEnabled (bool): Toggle for parameter caching.
        isRemoteCmd (bool): True when running a remote command.
        remoteCommandAck (int | bool): Tracks remote command acknowledgements.
        remotePshellEnabled (bool): True when remote pshell is enabled.
        remotePshellCommandQueue (queue.Queue): Queue for remote pshell commands.
        remoteCommandHandler (object | None): Handler for remote command payloads.
        CurrentCommandRemote (bool): True if current command is remote.
        pcmiosocket (socket.socket | None): PCM I/O socket.
        MapPayloadModesToRates (list[int]): Payload mode to bitrate map (bps).
        first_recording (bool): True if first PCM recording session.
        running_on_modem (bool): True when running on modem hardware.
    
    .. NOTE::
        Examples:
        
        *Initialize and connect to the popoto_app on localhost:17000*
        
        ``p = popoto.popoto('localhost')``
        
        *Initialize and connect to the popoto_app on 10.0.1.193:18000*
        
        ``p = popoto.popoto('10.0.1.193', 18000)``
    
    """

    ROBOT_LIBRARY_SCOPE='GLOBAL'

    def __init__(self, ip='localhost', basePort=17000, logname=None, skip_params_load=False):
        """Initialize a Popoto modem client connection.

        Args:
            ip (str): Hostname or IP address of the target Popoto modem.
            basePort (int): Base TCP port exposed by the modem application;
                other service ports are derived from this value.
            logname (str | None): Optional logger name to configure the
                instance-specific logger.
        """
        self.logger = logging.getLogger(logname)
        self.logger.debug("Popoto Init Called")
        self.pcmplayport = basePort + 5
        self.pcmioport   = basePort + 3
        self.pcmlogport  = basePort + 2
        self.dataport    = basePort + 1
        self.cmdport     = basePort
        self.rawTerminal = False
        self.quiet = 0
        self.logger.debug("Opening Command Socket")
        self.cmdsocket=socket(AF_INET, SOCK_STREAM)
        self.cmdsocket.connect((ip, basePort))
        self.cmdsocket.settimeout(20)
        self.verbose = 2
        self.SampFreq = 102400
        self.pcmplaysocket = 0
        self.recByteCount = 0
        self.ip = ip
        self.is_running = True
        self.fp = None
        self.fileLock = threading.Lock()
        self.logger.debug("Starting Command Thread")

        # Dictionary to hold JSON message intercept handlers.
        # Each key maps to a tuple: (callback, user_arg)
        self._intercept_handlers = {}
        self._reconnect_callbacks = []

        self.rxThread = threading.Thread(target=self.RxCmdLoop, name="CmdRxLoop", daemon=True)
        self.rxThread.start()
        self.replyQ = queue.Queue()
        self.datasocket = None
        self.logger.debug("Starting pcmThread")
        self.intParams = {}
        self.floatParams = {}
        self.paramsList = []
        self.varcache = {}
        self.cachingEnabled = True
        self.isRemoteCmd = False
        self._fetchingParams = False
        self.remoteCommandAck = -1
        self.remotePshellEnabled = False
        self.remotePshellCommandQueue = queue.Queue()
        if not skip_params_load:
            self.getAllParameters()
        self.remoteCommandHandler = None
        self.CurrentCommandRemote = False
        self.pcmiosocket = None
        self.MapPayloadModesToRates = [80, 5120, 2560, 1920, 1280, 10240, 2560, 1280, 960, 640]
        self.first_recording = True
        self.running_on_modem = self.check_running_on_modem()

    @property
    def verbose(self):
        """
        Verbosity of output, from 0-5:
            
            - 0: CRITICAL
            
            - 1: ERROR
            
            - 2: WARNING
            
            - 3: INFO
            
            - 4: DEBUG
            
            - 5: UNSET (all)
        
        Logging level is 0 - 50, 0 being most verbose and 50 being least
        verbose.
        The `verbose` property is 0 - 5, with 0 being least verbose and 5 being
        most verbose.
        Thus popoto.verbose is treated as
        `(logging.CRITICAL // 10) - (self.logger.level // 10)`.
        """
        return (logging.CRITICAL // 10) - (self.logger.level // 10)
    
    @verbose.setter
    def verbose(self, value):
        self.logger.setLevel(int((5 - value) * 10))

    def prepareFilesystem(self):
        """Ensure capture storage is expanded and mounted on modem hardware."""
        if self.running_on_modem:
            self.expandCapturesPartition()
            self.mountCapturesPartition()

    def setRawTerminal(self):
        """Disable ANSI styling for displayed modem replies."""
        self.rawTerminal = True

    def setANSITerminal(self):
        """Enable ANSI styling for displayed modem replies."""
        self.rawTerminal = False

    def setRemoteCommandHandler(self, obj):
        """Register a handler for remote command payloads from other modems.

        Args:
            obj: Handler instance that implements ``handleCommand(command)``.
        """
        self.remoteCommandHandler = obj
        return

    def register_message_handler(self, message_type, callback, user_args=()):
        """
        Register a callback for JSON replies that contain a given key or key-value pair.
        The callback will be called with two arguments: the intercepted message (as a dict)
        and the user_arg provided at registration time.

        Args:
            message_type (str): JSON key that triggers the callback.
             For example, if you want to intercept messages that include the key
             "MyCustomType", pass that string here; or, if you want to intercept
             {"Alert": "TxComplete"}, pass the string '{"Alert": "TxComplete"}' here.
            callback (Callable[[dict, Any], None]): Function invoked with the
                intercepted message and user argument.
            user_arg (Any | None): Optional data passed through to `callback`.
        """
        if self._intercept_handlers.get(message_type, None) == None:
            self._intercept_handlers[message_type] = []
        self._intercept_handlers[message_type].append((callback, user_args))
        self.logger.info("Registered handler for message type '%s' with user_arg=%s",
                         message_type, user_args)

    def unregister_message_handler(self, message_type):
        """Remove the registered callback for a JSON message type.

        Args:
            message_type (str): JSON key whose callback should be removed.
        """
        if message_type in self._intercept_handlers:
            del self._intercept_handlers[message_type]
            self.logger.info("Unregistered all handlers for message type '%s'", message_type)
        else:
            self.logger.warning("No handler registered for message type '%s'", message_type)

    def register_reconnect_callback(self, callback, user_args):
        """
        Registers a callback function to
        The callback will be called with two arguments: the intercepted message (as a dict)
        and the user_arg provided at registration time.

        :param callback: A function that will be called with user_arg as arguments.
        :param user_arg: Additional arguments that will be passed to the callback.
        """
        self._reconnect_callbacks.append((callback, user_args))
        self.logger.info("Registered reconnect callback '%s' with user_args=%s",
                         callback.__name__, str(user_args))

    def unregister_reconnect_callback(self, callback, user_args=()):
        """
        Unregisters the callback function for a given JSON message type.

        :param message_type: The JSON key for which the callback should be removed.
        """
        i = 0
        for (list_callback, list_user_args) in self._reconnect_callbacks:
            if id(callback) == id(list_callback) and user_args == list_user_args:
                if i == len(self._reconnect_callbacks):
                    self._reconnect_callbacks = self._reconnect_callbacks[:-1]
                    return
                self._reconnect_callbacks = self._reconnect_callbacks[:i] + self._reconnect_callbacks[i+1:]
                return
            i += 1
        self.logger.warning(f"No callback registered for function {callback} ({id(callback)})")

    def check_running_on_modem(self):
        """
        Determine whether the client is executing on Popoto modem hardware by
        checking CPU characteristics and the serial number marker file.
        """
        if os.path.exists('proc/cpuinfo'):
            with open('/proc/cpuinfo') as file:
                cpuinfo = file.read()
        else:
            cpuinfo="no_cpuinfo_file"
        on_modem = os.path.exists("/etc/PopotoSerialNumber.txt") and (
            "ARM926EJ-S rev 5 (v5l)" in cpuinfo or "fp asimd evtstrm aes pmull sha1 sha2 crc32 cpuid" in cpuinfo)
        self.logger.debug(f'Running on PMM hardware: {on_modem}')
        return on_modem

    def send(self, message):
        """Send a Popoto JSON API command with optional arguments over the
        command socket.

        Args:
            message (str): Command string optionally followed by arguments.
        """
        args = message.split(' ', 1)

        # Break up the command and optional arguments around the space
        if len(args) > 1:
            command = args[0]
            arguments = ' '.join(args[1:])
        else:
            command = message
            arguments = "Unused Arguments"

        if(self.isRemoteCmd):

            if(self.remoteCommandAck):
                command = "RemoteCommandWithAck"
            else:
                command = "RemoteCommand"

            arguments = message + ' ' + arguments


        message = "{ \"Command\": \"" + command + \
            "\", \"Arguments\": \"" + arguments + "\"}"
        
        self.logger.info(message)
        
        # Send the message to the command socket
        try:
            self.logger.debug(
                "Port:" + str(self.cmdport) + " >>>> " + message)
            message = message +'\n'
            self.cmdsocket.sendall(message.encode())
        except Exception as e:
            self.logger.error(e)
            self.logger.error("Port:" + str(self.cmdport) +
                              " >>>> " + "SEND ERROR")

    def sendRemoteStatus(self, message):
        """Transmit a remote status message and await transmit completion.

        Args:
            message (str): Status payload to forward to the remote modem.
        """
        status = "RemoteStatus " + message
        self.drainReplyQ()

        self.send(status)

        self.waitForSpecificReply("Alert", "TxComplete", 20)

    def setRemoteCommand(self, AckFlag):
        """Configure the JSON API to send commands to a remote modem
        acoustically.
        
        .. NOTE::
            These commands will subsequently be executed on the remote modem.
            Not all commands can be executed remotely. This function will send JSON
            API calls, *NOT* pshell commands. To send a pshell command to a remote
            modem, use sendRemotePshell.
            The RemoteNode variable controls which modem to send the command to.

        Args:
            AckFlag (bool): If True, request an acknowledgement from the remote
            modem.
        """
        self.isRemoteCmd = True
        if(AckFlag):
            self.remoteCommandAck = True
        else:
            self.remoteCommandAck = False

    def setLocalCommand(self):
        """Route subsequent commands directly to the API's modem TCP connection.
        (Disables RemoteCmd)"""
        self.isRemoteCmd = False
        self.remoteCommandAck = False

    def drainReplyQ(self):
        """Empty the reply queue while logging every dequeued message."""
        while self.replyQ.empty() == False:
            self.logger.info(self.replyQ.get())

    def drainReplyQquiet(self):
        """Empty the reply queue without logging the removed messages."""
        while self.replyQ.empty() == False:
            self.replyQ.get()

    def sendRemotePshell(self, command):
        """Issue a remote pshell command without requesting an acknowledgement.
        
        .. NOTE::
            This function will send pshell commands, *NOT* JSON API calls. To send a
            JSON API command to a remote modem, use sendRemoteCommand.

        Args:
            command (str): Command string to execute on the remote shell.
        """
        message = "{ \"Command\": \"remotePshellCommand\", \"Arguments\": \"" + command +"\" }"
        try:
            json.loads(message)
            self.logger.info("Sending " + message)
            message = message + '\n'
            self.cmdsocket.sendall(message.encode())
        except json.JSONDecodeError:
            self.logger.error("Invalid JSON message: ", message)
        except OSError:
            self.logger.error("Could not send message. Please reconnect.")


    def sendRemotePshellAck(self, command):
        """Issue a remote pshell command and request an acknowledgement.
        
        .. NOTE::
            This function will send pshell commands, *NOT* JSON API calls. To send a
            JSON API command to a remote modem, use sendRemoteCommand.
        
        Args:
            command (str): Command string to execute on the remote shell.
        """
        message = "{ \"Command\": \"remotePshellCommandAck\", \"Arguments\": \"" + command +"\" }"
        try:
            json.loads(message)
            self.logger.info("Sending " + message)
            message = message + '\n'
            self.cmdsocket.sendall(message.encode())
        except json.JSONDecodeError:
            self.logger.error("Invalid JSON message: ", message)
        except OSError:
            self.logger.error("Could not send message. Please reconnect.")


    def waitForReply(self, Timeout=10):
        """Block until a reply arrives or the timeout elapses.

        Args:
            Timeout (float): Maximum number of seconds to wait.

        Returns:
            dict: Reply dictionary or ``{\"Timeout\": 0}`` on timeout.
        """
        try:
            reply = self.replyQ.get(True, Timeout)
        except:
            reply = {"Timeout":0}
        return reply

    def waitForSpecificReply(self, Msgtype, value=None, Timeout=10):
        """Block until a reply with the requested key/value pair arrives.

        Args:
            Msgtype (str): Reply dictionary key to match.
            value (Any or None): Optional value (or substring for str replies)
                to match.
            Timeout (float): Maximum number of seconds to wait.

        Returns:
            dict: Matching reply dictionary or ``{\"Timeout\": 0}`` on timeout.
        """
        done = 0
        start = time.time()
        try:
            while (done == 0 ):
                reply = self.replyQ.get(True, Timeout)
                if(Msgtype in reply):
                    if(value != None):
                        if(reply[Msgtype] == value):
                            done = 1
                        elif type(reply[Msgtype]) == str:
                            if(value in reply[Msgtype]):
                                done = 1
                    else:
                        done = 1
                elapsedTime = time.time() - start
                if(elapsedTime > Timeout):
                    reply = {"Timeout": 0}
                    return reply
        except:
            reply = {"Timeout": 0}
        return reply

    def startRx(self):
        """Put the Popoto modem into receive mode."""
        self.send('Event_StartRx')

    def calibrateTransmit(self):
        """(Deprecated)
        """
        self.setValueF('TxPowerWatts', 1)
        self.send('Event_startTxCal')

    def transmitJSON(self, JSmessage):
        """Send an arbitrary payload of bytes through the acoustic modem.

        Args:
            JSmessage (dict | str): JSON-encoded string or list of bytes to
                transmit. Large payloads are automatically streamed in chunks.
        
        .. NOTE::
            Does not transmit arbitrary JSON; rather, the user specifies
            the data to be transmitted using a JSON string or JSON-decodable
            python dictionary object, with the following format:
            
            ``{"Payload": {"Data": [<list of up to 255 bytes>]} }``
            
            For example:
            
            ``{"Payload": {"Data": [72, 101, 108, 108, 111] } }``
            
            If you would like to send JSON, encode it as bytes first, then send
            the array of bytes (integer encoded ASCII) using this command.
        """

        if type(JSmessage) != dict:
            try:
                JSmessage = json.loads(JSmessage)
            except json.JSONDecodeError:
                self.logger.error("Failed to parse JSON:\n\r" + traceback.format_exc())
                return
        # Format the user JSON message into a TransmitJSON message for Popoto
        if "Payload" in JSmessage.keys() and "Data" in JSmessage["Payload"].keys():
            data = JSmessage["Payload"]["Data"]
        elif "ClassUserID" in JSmessage.keys():
            data = []
        else:
            self.logger.error('Transmitted JSON must be in the format: {"Payload": {"Data": []}}')
            return

        # For data with a length of > 255, enable streaming mode and split the data into packets for sending quickly
        if len(data) > 255:
            self.streamBytes(data)
            return

        # Format the user JSON message into a TransmitJSON message for Popoto
        message = "{ \"Command\": \"TransmitJSON\", \"Arguments\": " + json.dumps(JSmessage) + " }"

        # Verify the JSON message integrity and send along to Popoto
        try:
            json.loads(message)
            self.logger.info("Sending " + message)
            message = message + '\n'
            self.cmdsocket.sendall(message.encode())
        except json.JSONDecodeError:
            self.logger.error("Invalid JSON message: ", JSmessage)
        except OSError:
            self.logger.error("Could not send message. Please reconnect.")

    def mariaCommand(self, JSmessage):
        """
        MARIA command builder with automatic type parsing.
        If there is exactly one argument, "Arguments" will be that item directly.
        If more than one, "Arguments" will be a list.
        """

        # Split "dest:rest"
        try:
            _dest, _func_and_args = JSmessage.split(':', 1)
        except ValueError:
            self.logger.error("Invalid MARIA command format (missing ':'): " + JSmessage)
            return

        parts = _func_and_args.strip().split(' ', 1)
        _func = parts[0]
        _args_str = parts[1].strip() if len(parts) > 1 else ''

        msg_dict = {
            "Command": "MARIACommand",
            "Destination": _dest,
            "Function": _func
        }

        # Handle arguments
        if _args_str != '':
            stripped = _args_str.lstrip()

            # --- Case 1: user is clearly trying to send raw JSON ({...} or [...]) ---
            if stripped.startswith('{'):
                try:
                    parsed = json.loads(stripped)
                    msg_dict["Arguments"] = parsed
                except json.JSONDecodeError as e:
                    self.logger.error(
                        f"Invalid JSON for Arguments: {_args_str} ({e})"
                    )
                    return

            else:
                # --- Case 2: normal "func arg1 arg2 ..." style → type-interpret tokens ---
                tokens = shlex.split(_args_str)
                parsed_args = []

                for tok in tokens:
                    low = tok.lower()

                    # bool
                    if low == "true":
                        parsed_args.append(True)
                        continue
                    if low == "false":
                        parsed_args.append(False)
                        continue

                    # null
                    if low == "null":
                        parsed_args.append(None)
                        continue

                    # int
                    try:
                        parsed_args.append(int(tok))
                        continue
                    except ValueError:
                        pass

                    # float
                    try:
                        parsed_args.append(float(tok))
                        continue
                    except ValueError:
                        pass

                    # fallback string
                    parsed_args.append(tok)

                # Single vs multiple argument behavior
                if len(parsed_args) == 1:
                    msg_dict["Arguments"] = parsed_args[0]
                else:
                    msg_dict["Arguments"] = parsed_args


        # Serialize and send
        try:
            message = json.dumps(msg_dict)
            self.logger.info("Sending " + message)
            self.cmdsocket.sendall((message + "\n").encode())
        except Exception as e:
            self.logger.error("Invalid JSON message: " + JSmessage + " (" + str(e) + ")")

    def setActiveChannels(self, line):
        """Enable JACK PCM streaming channels for recording.
        
        .. NOTE::
            PMM6081 has 10 receiving channels, though this command can only set
            the mask to receive up to 8 of them at any given time.
            Two channels will always be ignored by this method; which channels
            these are depends on how you launch the popoto app.

        Args:
            line (str): Space-separated channel numbers or the string ``"all"``.
        """
        try:
            if line.strip().lower() == 'all':
                bitmask = 255
            else:
                channels = line.strip().split()
                bitmask = 0
                for c in channels:
                    ch = int(c)
                    bitmask |= (1 << (ch - 1))

            cmd = { "Command": "SetValue", "Arguments": f"MARIA_Popoto_InputChannelMask {bitmask} 0"}
            message = json.dumps(cmd)
            json.loads(message)
            self.logger.info("Sending " + message)
            message = message + '\n'
            self.cmdsocket.sendall(message.encode())

        except:
            self.logger.error("Unable to parse channels!")

    def getVersion(self):
        """
        Retrieve Popoto application and component versions from the connected
        modem.
        """
        try:
            versions = self._fetch_versions_from_modem()
            if versions:
                return versions
        except Exception as exc:
            pass

        # Legacy behavior: request version via popoto_app command socket.
        self.send('getVersion')
        return []
    def getPopotoModulations(self):
        """
        request a json message from the modem that contains the supported modulations
        """
        self.send('getPopotoModulations')
        return []



    def _fetch_versions_from_modem(self):
        """
        Connect to the modem-hosted data server to fetch version data.
        """
        try:
            with socket(AF_INET, SOCK_STREAM) as version_socket:
                version_socket.settimeout(VERSION_SERVER_TIMEOUT_SECONDS)
                version_socket.connect((self.ip, VERSION_SERVER_PORT))
                # Payload content is irrelevant; presence of a connection triggers a response.
                version_socket.sendall(b"getVersion\n")
                reply_chunks = []
                while True:
                    data = version_socket.recv(4096)
                    if not data:
                        break
                    reply_chunks.append(data)
        except OSError as exc:
            self.logger.log(
                logging.DEBUG + 1,
                "Failed to reach modem data server at %s:%s: %s",
                self.ip,
                VERSION_SERVER_PORT,
                exc,
            )
            return []

        payload = b"".join(reply_chunks).decode("utf-8").strip()
        if not payload:
            self.logger.error(
                "Data server at %s:%s returned no data", self.ip, VERSION_SERVER_PORT
            )
            return []

        try:
            return json.loads(payload)
        except json.JSONDecodeError as exc:
            self.logger.error(
                "Invalid JSON from data server at %s:%s: %s",
                self.ip,
                VERSION_SERVER_PORT,
                exc,
            )
            return []

    def sendPrecisionRange(self, power=.1):
        """Initiate a precision ranging cycle to another modem.
        
        .. NOTE::
            This is for precision ranging, which is mutually exclusive with
            range-with-data. To send a range request with data, use
            setRangeData() and sendRange().

        Args:
            power (float): Transmit power in watts.
        """
        self.setValueF('TxPowerWatts', power)
        self.setValueI('CarrierTxMode', 0)
        self.send('Event_sendPrecisionRanging')

    def reboot(self):
        self.tearDownPopoto()
        if self.ip in ['localhost', '127.0.0.1'] and not (os.environ.get('IS_SIM') != 0):
            os.system('/sbin/reboot')
        else:
            os.system('sshpass -p root ssh root@' + self.ip + ' "/sbin/reboot"')

    def sendRange(self, power=.1):
        """Initiate a standard ranging cycle to another modem.

        Args:
            power (float): Transmit power in watts.
        """
        self.setValueF('TxPowerWatts', power)
        self.setValueI('CarrierTxMode', 0)
        self.send('Event_sendRanging')

    def recordStartTarget(self, filename, duration, capturesdir='/captures'):
        """Begin recording acoustic data to the modem's internal storage or SD
        card.

        - Recording is passband if  Popoto 'RecordMode' is 0
        
        - Recording is baseband if  Popoto 'RecordMode' is 1
        
        Args:
            filename (str): Destination file path; auto-prefixed with
                ``capturesdir`` when that directory exists.
            duration (float): Duration in seconds for each capture file.
            capturesdir (str): Directory used for capture storage when present.
        """

        if (filename[:10] != capturesdir + '/') and os.path.exists(capturesdir):
            filename = capturesdir + '/' + filename
            self.logger.info("File recording in" + capturesdir + "/ directory: " + filename)

        self.send('StartRecording {} {}'.format(filename, duration))

    def getRecordingStatus(self):
        '''
        Request the status and key information of the current recording session,
        in JSON Format.
        '''
        self.send('GetRecordingStatus')

    def expandCapturesPartition(self):
        """(Deprecated) Expand the captures partition to occupy remaining device
        space."""
        trailing_space_available = os.system(f"parted {CAPTURES_PARTITION_DEVICE} print free | tail -n 2 | grep -q 'Free Space'")
        if trailing_space_available == 0:
            self.logger.info(f"Filesystem for {CAPTURES_PARTITION_DEVICE} has trailing unpartitioned space. Resizing {CAPTURES_PARTITION} to fill remaining space (this may take some time)...")
            os.system('umount /captures &> /dev/null')
            if os.system(f'parted -s -a opt {CAPTURES_PARTITION_DEVICE} "resizepart {CAPTURES_PARTITION_NUMBER} 100%"') == 0 and os.system(f'resize2fs {CAPTURES_PARTITION}') == 0:
                self.logger.info("Filesystem resize complete.")
            else:
                self.logger.info("Error resizing filesystem! /captures partition may be very small.")
        else:
            self.logger.info(f"Filesystem for {CAPTURES_PARTITION_DEVICE} has no trailing unpartitioned space. Not resizing {CAPTURES_PARTITION}.")

    def mountCapturesPartition(self):
        """(Deprecated) Mount ``/dev/mmcblk0p3`` at ``/captures`` if available."""
        if os.path.isfile('/captures'):
            if os.path.getsize('/captures') == 0:
                os.remove('/captures')
            else:
                self.logger.error("ERROR: /captures is a file, not a directory! Moving to '/captures.file'...")
                os.rename('/captures', '/captures.file')

        if not os.path.isdir('/captures'):
            os.mkdir('/captures')

        os.system(f'umount /captures &> /dev/null')
        if os.system(f'fsck -y {CAPTURES_PARTITION}') & 4 != 0:
            self.logger.warning(f"WARNING: repairing {CAPTURES_PARTITION} failed!")

        rc = os.system(f'/bin/mount {CAPTURES_PARTITION} /captures > /dev/null')
        if rc != 0:
            self.logger.warning("WARNING: /captures directory partition failed to mount. You may not have much storage space to record to.")

    def recordStopTarget(self):
        """Stop recording modem audio."""
        self.send('StopRecording')

    def playStartTarget(self,filename, scale):
        """Play a stored WAV file through the Popoto transmitter.

        Playback occurs in passband when ``PlayMode`` is ``0`` and baseband when
        it is ``1``.

        Args:
            filename (str): WAV file path (32-bit IEEE float samples).
            scale (float): Transmitter scale factor (0-10) controlling output power.
        """
        if filename[:10] != '/captures/' and os.path.exists("/captures"):
            filename = '/captures/' + filename
            self.logger.info("File playing from /captures/ directory: " + filename)
        self.logger.info ("Playing {} at Scale {}".format(filename, scale))
        self.send('StartPlaying {} {}'.format(filename, scale))

    def playStopTarget(self):
        """Stop playback of the current WAV file."""
        self.send('StopPlaying')

    def set(self, Element, value, override_cache=False):
        """
        Sets a value of a Popoto variable

        Args:
            Element (str): Name of the internal variable to update.
            value (Any): Value to apply to the variable.
        """
        if self.cachingEnabled and not override_cache:
            if self.varcache.get(Element) != value:
                self.send('SetValue {} {} 0'.format(Element, value))
            self.varcache[Element] = value
        else:
            self.send('SetValue {} {} 0'.format(Element, value))

    def get(self, Element):
        """Request the value of a Popoto internal variable.

        Args:
            Element (str): Name of the internal variable to read.
        """
        self.send('GetValue {} 0'.format(Element))
    
    # Aliases for deprecated getters/setters
    setValueI = set
    setValueF = set
    getValueI = get
    getValueF = get
    
    def tearDownPopoto(self):
        """Gracefully shut down an interactive Popoto session.
        
        It is advised to call this when you no longer need a connection to the
        popoto application, or at the end of your python script.
        """
        self.getVersion()
        self.is_running = False
        time.sleep(1)

    def setRtc(self, clockstr):
        """Set the modem real-time clock.

        Args:
            clockstr (str): Timestamp string in ``YYYY.MM.DD-HH:MM;SS`` format.
        """
        self.send('SetRTC {}'.format(clockstr))

    def getRtc(self):
        """Request the current real-time clock string from the modem."""
        self.send('GetRTC')

    def __del__(self):
        """
        Best-effort destructor that stops background loops when the instance is
        garbage collected.
        """
        self.is_running = False

    def playPcmLoop(self, inFile, scale, bb):
        """Loop a REC/RAW file through the transmitter for playback testing.

        Args:
            inFile (str): Path to the input REC/RAW file.
            scale (float): Transmit scaling factor applied during playback.
            bb (int): ``0`` for passband playback, ``1`` for baseband playback.
        """
        self.pcmplaysocket=socket(AF_INET, SOCK_STREAM)
        self.pcmplaysocket.connect((self.ip, self.pcmplayport))
        self.pcmplaysocket.settimeout(1)
        if(self.pcmplaysocket == None):
            self.logger.error("Unable to open PCM Log Socket")
            return
        # Set mode to either passband-0 or baseband-1
        self.setValueI('PlayMode', bb)

        # Start the play
        self.send('StartNetPlay 0 0')

        # Open the file for playing
        fpin  = open(inFile, 'r')
        if(fpin == None):
            self.logger.error("Unable to Open {} for Reading")
            return
        s_time = time.time()
        sampleCounter = 0
        if(bb):
            SampPerSec = 10240 *2
        else:
            SampPerSec = 102400
        gain = struct.pack('f', scale)
        if('rec' in inFile[-4:] ):
            self.logger.info('Playing a rec file')
            readLen = 642*4
            startOffset = 8
        else:
            self.logger.info('Playing a raw file')
            readLen = 640*4
            startOffset = 0

        Done = 0
        while Done == 0:
            # Read socket of pcm data
            fdata = fpin.read(readLen)
            if(len(fdata) < readLen):
                self.logger.info('Done Reading File')
                Done = 1
            fdata = gain + gain + fdata[startOffset:]
            StartSample = sampleCounter
            while(sampleCounter == StartSample and len(fdata) > 8):
                try:
                    self.pcmplaysocket.send(fdata) # Send data over socket
                    sampleCounter += (len(fdata)-8)

                except:
                    self.logger.error('Waiting For Network SampleCount {}'.format(sampleCounter))
                    self.logger.error(sys.exc_info()[0])
                    Done = 1

        duration = sampleCounter / (4*SampPerSec)  #  Bytes to Floats->seconds
        self.logger.info('Duration {}'.format(duration))

        while(time.time() < s_time+duration):
            time.sleep(1)

        # Terminate play
        self.send('Event_playPcmQueueEmpty')

        self.logger.debug("Exiting PCM Loop")
        self.pcmplaysocket.close()
        fpin.close()


    def recPcmLoop(self, outFile, duration, bb):
        """Record passband or baseband PCM data for a fixed duration.

        .. NOTE::
            This function sets passband/baseband mode as specified, but changes
            back to passband mode on exit. Baseband recording and normal modem
            function are mutually exclusive, as they both require the use of
            modem's digital upconverter.

        Args:
            outFile (str): Output REC/RAW file path.
            duration (float): Recording duration in seconds.
            bb (int): ``0`` for passband capture, ``1`` for baseband capture.

        """
    
        self.logger.info("Opening %s", outFile)

        # Convert duration (seconds) -> sample count (historical behavior preserved)
        if bb == 1:
            target_samples = int(duration * 10240 * 2)   # baseband: 10240 complex samples/sec
        else:
            target_samples = int(duration * 102400)      # passband: 102400 samples/sec

        # Always restore mode on exit, even on errors.
        self.setValueI("RecordMode", bb)
        sock = None
        try:
            # Connect socket
            sock = socket(AF_INET, SOCK_STREAM)
            sock.settimeout(1)
            sock.connect((self.ip, self.pcmlogport))
            self.pcmplaysocket = sock

            bytes_per_read = 642 * 4
            target_bytes = target_samples * 4  # historical code compared recByteCount to duration*4

            self.recByteCount = 0
            frame_counter = 0
            record_deadline = time.time() + max(float(duration), 0.0) + 5.0

            with open(outFile, "wb") as fpout:
                while self.recByteCount < target_bytes and time.time() < record_deadline:
                    try:
                        chunk = sock.recv(bytes_per_read)
                        if not chunk:
                            self.logger.debug("PCM socket closed by peer.")
                            break

                        fpout.write(chunk)

                        # Preserve original accounting: +len(chunk)-2
                        self.recByteCount += max(0, len(chunk) - 2)

                        frame_counter += 1
                        if frame_counter > 80:
                            self.logger.debug(".")
                            frame_counter = 0

                    except (OSError, IOError) as e:
                        self.logger.debug("Error while recording/writing: %s", e)
                        continue

            if self.recByteCount < target_bytes:
                self.logger.debug(
                    "Stopping recPcmLoop at deadline with %d/%d bytes.",
                    self.recByteCount,
                    target_bytes,
                )

            self.logger.info("Exiting PCM Loop")

        except Exception:
            self.logger.exception("Unable to record PCM.")
            return
        finally:
            try:
                if sock is not None:
                    sock.close()
                elif getattr(self, "pcmplaysocket", None):
                    self.pcmplaysocket.close()
            except OSError:
                pass
            self.setValueI("RecordMode", 0)


    def statReport(self, line):
        """
        (Deprecated) Log a status message locally and forward it over the remote command
        channel when operating in remote-command mode.

        Args:
            line (str): Human-readable status message.
        """
        if(self.CurrentCommandRemote):
            self.sendRemoteStatus(line)
            self.logger.info(line)
        else:
            self.logger.info(line)

    def streamBytes(self, data):
        """
        Chunk and transmit large payloads over the data socket, falling back to
        command-socket JSON transmission for small payloads.

        Args:
            data (bytes | bytearray | io.BufferedReader | str): Payload to stream.
        """
        METHOD = "TransmitJSON"
        # Set up the data socket
        if (self.datasocket == None):
            self.datasocket = socket(AF_INET, SOCK_STREAM)

            self.datasocket.connect((self.ip, self.dataport))
            self.datasocket.settimeout(10)
            self.datasocket.setsockopt(IPPROTO_TCP, TCP_NODELAY, 1)

            if (self.datasocket == None):
                self.statReport("Unable to open data Socket")
                return

        # Make sure the data is bytes, not str
        if type(data) == str:
            data = data.encode()

        # Get the length of the file or stream
        if type(data) == io.BufferedReader:
            data.seek(0, io.SEEK_END)
            total_byte_count = data.tell()
            data.seek(0)

            def get_next_packet(start, length):
                data.seek(start)
                return bytes(data.read(length))
        else:
            total_byte_count = len(data)
            def get_next_packet(start, length):
                return bytes(data[start:start + length])

        superframe_size = min(SUPERFRAME_SIZE, total_byte_count)  # Maximum super frame size
        # self.setValueI('StreamingTxLen', superframe_size)

        total_bytes_sent = 0
        PacketsTransmitted = 0
        Msg = {}
        Msg['Payload'] = {}

        while(total_bytes_sent < total_byte_count):
            superframe_bytes_sent = 0
            while(superframe_bytes_sent < superframe_size):
                readLen = superframe_size - superframe_bytes_sent

                if METHOD == 'TransmitJSON' and (readLen > 255):
                    readLen = 255

                packet = get_next_packet(total_bytes_sent, readLen)

                Msg['Payload']["Data"] = list(packet)

                try:
                    if METHOD == 'TransmitJSON':
                        sendbytes = b"{ \"Command\": \"TransmitJSON\", \"Arguments\": " + json.dumps(Msg).encode() + b" }\n"
                        self.cmdsocket.sendall(sendbytes)
                    elif METHOD ==  'Streaming':
                        self.datasocket.send(packet)
                except:
                    self.logger.error("ERROR SENDING ON DATA SOCKET")

                total_bytes_sent += len(packet)
                superframe_bytes_sent += len(packet)
                self.logger.info('Bytes Uploaded ' + str(total_bytes_sent))
                # WAIT FOR COMPLETE
            PacketsTransmitted += 1

            if((total_byte_count - total_bytes_sent) < superframe_size):
                superframe_size = total_byte_count-total_bytes_sent

        # Compute the number of seconds to wait for a Complete message
        # Based on the payload mode.  Up it by factor of 10 to account
        # for headers etc, and the "timeout" nature of a timeout.
        # in the normal case we won't wait this long, as the complete message
        # will arrive.
        self.get("PayloadMode")
        PayloadMode = self.waitForSpecificReply("PayloadMode", None)
        if PayloadMode != {"Timeout": 0}:
            PayloadMode = int(PayloadMode["PayloadMode"])
        else:
            # Assume 80bps to be safe
            PayloadMode = 0

        timeout = 10*(total_byte_count * 8) / self.payLoadModeToBitRate(PayloadMode)

        self.waitForSpecificReply("Alert", 'TxComplete', timeout)

    def streamUpload(self, filename, power, PayloadMode = 1):
        """(Deprecated) Upload a file for acoustic transmission.
        
        .. NOTE::
            This transmits the internal data of a file, it does not play back an
            audio file. For that functionality, use ``playStartTarget()``.

        Args:
            filename (str): Path to the file that should be transmitted.
            power (float): Desired transmit power in watts.
            PayloadMode (int): Payload mode index used for streaming (default
            ``1``).
        """
        if(self.isRemoteCmd):
            self.send('upload ' + filename + ' ' + str(power))
            return

        if os.path.isfile(filename) and os.access(filename, os.R_OK):
            self.logger.debug("File exists and is readable")
            nbytes = os.path.getsize(filename)
            if(nbytes == 0):
                self.statReport("ZERO LENGTH FILE: NOT UPLOADING")
                return
            self.logger.debug("File is %d bytes" % nbytes )
        else:
            self.statReport ("Either the file is missing or not readable")
            return
        self.logger.debug("OK")
        self.statReport ("OK")
        # All good with the file lets upload
        done = 0
        while(done == 0):
            try:
                self.replyQ.get(False)
            except queue.Empty:
                done = 1

        self.setValueI('TCPecho',0)
        self.setValueI('ConsolePacketBytes', 256)
        self.setValueI('ConsoleTimeoutMS', 100)
        self.setValueI('PayloadMode', PayloadMode)
        self.setValueF('TxPowerWatts', power)

        done = 0
        while(done == 0):
            time.sleep(.1)
            resp = self.replyQ.get()
            self.logger.debug("Got a response")
            self.logger.debug(resp)
            if('PayloadMode' in resp['Info']):
                done = 1

# Read each character and send it to the socket
        self.drainReplyQquiet()

        with open(filename,'rb') as f:
            self.streamBytes(f)

        self.logger.info("Upload Complete")
        self.setValueI('PayloadMode', 0)
        self.setValueI('StreamingTxLen', 0)

    def streamDownload(self, filename, remotePowerLevel):
        """(Deprecated) Download a file over the acoustic streaming channel.
        Issues a request for upload to the remote modem, then listens for a
        stream of data to download.

        Args:
            filename (str): Destination filename; ``.download`` is appended to
                the provided base name.
            remotePowerLevel (float | None): Optional power level to request
                from the remote modem before downloading.
        """
        #clear reception queue
        TimeoutSec = 60
        self.drainReplyQquiet()
        if(remotePowerLevel):
            self.setValueF('TxPowerWatts', remotePowerLevel)

            # Set Remote Mode
            self.setRemoteCommand(0)
            # Issue Remote Command

            self.setValueF('TxPowerWatts', remotePowerLevel)
            repl = self.waitForSpecificReply("Alert","TxComplete", TimeoutSec)

            self.streamUpload(filename, remotePowerLevel)
            # wait for response ?

            repl = self.waitForSpecificReply("RemoteStatus",None, TimeoutSec)
            self.setLocalCommand()

            if(repl['RemoteStatus'] != "OK"):
                self.logger.error('Remote ERROR:')
                self.logger.error(repl)
                return
            # Set Local

        #check for proper response
        f = open(filename+'.download', 'wb')
        filedone =0
        TimeoutSec = 30
        while(filedone == 0):
            repl = self.waitForSpecificReply("Header",None, TimeoutSec)
            if('Timeout' in repl):
                self.logger.info ("Download Complete")
                filedone = 1
                SuperFrameDone = 1
            else:
                SuperFrameDone = 0
                TimeoutSec = 10

            while(SuperFrameDone == 0):
                reply = self.replyQ.get()
                if "Data" in reply:
                    byte_arr = reply['Data']
                    #file data in to buffer byte array
                    f.write(bytearray(byte_arr))
                elif "Alert" in reply:
                # check for CRC Error  Increment count
                    if reply['Alert'] == "CRCError":

                        byte_arr = [176] * 256
                        f.write(bytearray(byte_arr))
                elif "Info" in reply:
                    if "MODEM_Enable" in reply['Info']  :
                        SuperFrameDone = 1

            # check for Modem Enable ? is that a Info ?
            # done = 1
            # Timeout Done = 1
        f.close()


        #write byte array to disk

    def setRangeData(self, JSmessage):
        """Configure the range data.
        This data serves as the payload to be sent along with a range request,
        as well as the response payload returned during ranging exchanges.

        Args:
            JSmessage (str): JSON-encoded payload configuration message. May
            include a maximum of 255 integer-encoded bytes of data.
        
        .. NOTE::
            The format of JSMessage is as follows:
            
            ``{"Payload": {"Data": [<list of up to 255 bytes>]} }``
            
            For example:
            
            ``{"Payload": {"Data": [72, 101, 108, 108, 111] } }``
        """

        message = \
           "{ \"Command\": \"setRangeData\", \"Arguments\": " + JSmessage + " }"

        # Verify the JSON message integrity and send along to Popoto
        try:
            json.loads(message)
            self.logger.info("Sending " + message)
            message = message + '\n'
            self.cmdsocket.sendall(message.encode())
        except json.JSONDecodeError:
            self.logger.error("Invalid JSON message: ", message)
        except BrokenPipeError as e:
            self.tearDownPopoto()
            raise e

    def payLoadModeToBitRate(self, payloadMode):
        """Return the bitrate associated with a payload mode.

        Args:
            payloadMode (int): Payload mode index.

        Returns:
            int: Bitrate in bits per second.
            
        .. NOTE::
            As of writing, the map of payload mode to bitrate is:
            
            .. list-table::
               :widths: 45 20
               :header-rows: 1

               * - Rate
                 - PayloadMode value
               * - 80 bps Frequency-Hopped (Default)
                 - 0
               * - 5120 bps QPSK
                 - 1
               * - 2560 bps QPSK
                 - 2
               * - 1920 bps QPSK
                 - 3
               * - 1280 bps QPSK
                 - 4
               * - 10240 bps Uncoded QPSK
                 - 5
               * - 2560 bps BPSK
                 - 6
               * - 1280 bps BPSK
                 - 7
               * - 960 bps BPSK
                 - 8
               * - 640 bps BPSK
                 - 9

            This is subject to change and new payload modes may be added.
        """
        try:
            rate = self.MapPayloadModesToRates[payloadMode]
        except:
            self.logger.error("Invalid payloadMode")
            rate = self.MapPayloadModesToRates[0]

        return rate

    def BitRateToPayloadMode(self, rate):
        """Return the payload mode index that matches a bitrate.

        Args:
            rate (int): Bitrate in bits per second.

        Returns:
            int: Payload mode index.
            
        .. NOTE::
            As of writing, the map of payload mode to bitrate is shared in
            :meth:`payLoadModeToBitRate`.
            This is subject to change and new payload modes may be added.
        """
        try:
            # prefer the end of the list if duplicates of the modulation speed exists to prefer
            # the latest and the greatest modulation schemes 
            # (bpsk has a higher snr than qpsk for equivalent data rates)
            PayloadMode = max(i for i, v in enumerate(self.MapPayloadModesToRates) if v == rate)
        except:
            self.logger.error("Invalid Rate")
            PayloadMode = 0

        return PayloadMode

    def _update_payload_modes_from_modulations(self, reply):
        modulations = reply.get("PopotoModulations")
        if not isinstance(modulations, dict):
            return False
        params = modulations.get("params")
        if not isinstance(params, list) or not params:
            self.logger.warning("PopotoModulations missing params list")
            return False

        id_to_bps = {}
        max_id = -1
        for entry in params:
            if not isinstance(entry, dict):
                continue
            if "id" not in entry or "bps" not in entry:
                continue
            try:
                mode_id = int(entry["id"])
                bps = int(entry["bps"])
            except (TypeError, ValueError):
                self.logger.warning("Skipping modulation with invalid id/bps: %s", entry)
                continue
            if mode_id < 0:
                self.logger.warning("Skipping modulation with negative id: %s", entry)
                continue
            id_to_bps[mode_id] = bps
            max_id = max(max_id, mode_id)

        if max_id < 0:
            self.logger.warning("PopotoModulations params had no usable entries")
            return False

        new_map = [None] * (max_id + 1)
        for mode_id, bps in id_to_bps.items():
            new_map[mode_id] = bps

        if any(value is None for value in new_map):
            self.logger.warning(
                "PopotoModulations did not include every id from 0 to %d; leaving MapPayloadModesToRates unchanged",
                max_id,
            )
            return False

        self.MapPayloadModesToRates = new_map
        self.logger.info("Updated MapPayloadModesToRates: %s", self.MapPayloadModesToRates)
        return True

    def getParametersList(self):
        """Return the cached parameter list from the system controller."""
        return self.paramsList

    def getParameter(self, idx):
        """Request metadata for an internal variable by index.

        Args:
            idx (int): Element index to query.
        """
        self.send('GetParameters {}'.format(idx))


    def getExclusiveAccess(self):
        """Acquire exclusive access to the modem command socket.

        Sets a mutex token; if another client holds the token, this method waits
        and retries until ownership is granted.
        """
        self.drainReplyQquiet()
        letters = string.ascii_lowercase
        token = ''.join(random.choice(letters) for i in range(10))
        waitingCounter = 0
        accessGranted = False
        while accessGranted == False:
            self.send('SetMutexToken {}'.format(token) )
            tokenReplyReceived = False
            while(tokenReplyReceived == False):
                if waitingCounter == 5:
                    self.logger.info ("Forcing Access to Popoto")
                    self.releaseExclusiveAccess()
                    self.send('SetMutexToken {}'.format(token) )
                    waitingCounter = 0
                try:
                    reply = self.replyQ.get(True, 3)
                    if reply:
                        if "ExclusivityToken" in reply:
                            if token in reply["ExclusivityToken"]:
                                accessGranted = True
                                tokenReplyReceived = True
                            else:
                                self.logger.info("Waiting for ExclusivityToken; Process {} has it".format(reply["ExclusivityToken"]))
                                time.sleep(2)
                                tokenReplyReceived = True
                                waitingCounter += 1
                except:
                    self.logger.info ("Waiting for Exclusivity Token")
                    time.sleep(2)
                    waitingCounter += 1
                    self.send('SetMutexToken {}'.format(token))

    def releaseExclusiveAccess(self):
        """Release the exclusivity token so other clients can issue commands."""
        self.send('SetMutexToken {}'.format('Available'))

    def getAllParameters(self):
        """Query the modem for metadata describing every internal variable."""
        idx = 0

        # if we already have a parameter list file,  load and parse it.
        if (os.path.exists('ParamsList.txt')):
            with open("ParamsList.txt", 'r') as f:
                self.paramsList = json.load(f)
                self.paramsList.sort(key=lambda x: x.get('Name'))
                for El in self.paramsList:
                    if (El['Format'] == 'int'):
                        self.intParams[El['Name']] = El
                    else:
                        self.floatParams[El['Name']] = El
                return
        verboseCache = self.verbose
        self.verbose = 0
        self._fetchingParams = True
        self.getExclusiveAccess()
        try:
            # Use chunked method
            nextIdx = 0
            all_params = []

            while nextIdx >= 0:
                self.send(f'GetAllParameters {nextIdx}')
                reply = self.replyQ.get(True, 5)

                if reply and "AllParameters" in reply:
                    chunk = reply["AllParameters"]
                    if "params" in chunk:
                        all_params.extend(chunk["params"])
                        nextIdx = chunk.get("nextIdx", -1)
                    else:
                        # Old format - single array
                        all_params = chunk
                        nextIdx = -1
                else:
                    # Fall back to legacy
                    self.logger.warning("GetAllParameters not supported, using legacy method")
                    self._getAllParametersLegacy()
                    break

            if all_params:
                self.paramsList = all_params
                self.paramsList.sort(key=lambda x: x.get('Name'))
                for El in self.paramsList:
                    if El.get('Format') == 'int':
                        self.intParams[El['Name']] = El
                    else:
                        self.floatParams[El['Name']] = El
                self.logger.info(f"Loaded {len(self.paramsList)} parameters via GetAllParameters")

        except Exception as e:
            self.logger.error(f"GetAllParameters failed: {e}, trying legacy method")
            self._getAllParametersLegacy()

        self._fetchingParams = False
        self.releaseExclusiveAccess()
        self.waitForReply()
        self.verbose = verboseCache
        return

    def _getAllParametersLegacy(self):
        """
        Legacy method: iteratively fetch parameters one at a time.
        Used for backward compatibility with older firmware.
        """
        idx = 0
        seen_indices = set()

        while idx >= 0:
            # Prevent infinite loop by tracking seen indices
            if idx in seen_indices:
                self.logger.warning(f"Already visited parameter index {idx}, stopping")
                break
            seen_indices.add(idx)

            self.getParameter(idx)
            reply = self.replyQ.get(True, 3)
            if reply:
                if "Element" in reply:
                    El = reply['Element']
                    if 'nextidx' in El:
                        next_idx = int(El['nextidx'])
                        # Add to params regardless of nextidx value
                        if El.get('Format') == 'int':
                            self.intParams[El['Name']] = El
                        else:
                            self.floatParams[El['Name']] = El
                        if El.get('Channel') == 0:
                            self.paramsList.append(El)
                        # Move to next, break if done
                        if next_idx <= 0:
                            break
                        idx = next_idx
                    else:
                        self.logger.error("Element missing nextidx")
                        break
                else:
                    self.logger.info(reply)
            else:
                self.logger.error("GetParameter Timeout")
                break

    def RxCmdLoop(self):
        """
        Continuously read and decode newline-delimited JSON messages from the
        command socket, enqueueing replies and handling reconnects as needed.
        """
        errorcount = 0
        rxString = ''
        data = b''
        self.cmdsocket.settimeout(1)
        while(self.is_running == True):
            try:
                data = self.cmdsocket.recv(1)
                if len(data) <= 0:
                    self.logger.error("Popoto appears to have been forcibly disconnected.")
                    self.cmdsocket.close()
                    disconnected = True
                    reconnect_count = 0
                    while disconnected:
                        try:
                            reconnect_count += 1
                            if not self.is_running: break
                            self.logger.error("({}) Attempting reconnect on {}:{}...".format(reconnect_count, self.ip, self.cmdport))
                            del(self.cmdsocket)
                            self.cmdsocket=socket(AF_INET, SOCK_STREAM)
                            self.cmdsocket.connect((self.ip, self.cmdport))
                            self.cmdsocket.settimeout(1)
                            self.logger.info("Reconnected to {}:{}.".format(self.ip, self.cmdport))
                            for callback, user_args in self._reconnect_callbacks:
                                callback(*user_args)
                            disconnected = False
                        except OSError as e:
                            if reconnect_count > 99:
                                self.logger.critical("COULD NOT CONNECT TO POPOTO_APP. PLEASE RESTART.")
                                exit(2)
                                raise e
                            time.sleep(2)
                else:
                    errorcount = 0
                    if ord(data)  != 13:
                        try:
                            rxString = rxString+str(data,'utf-8')
                        except:
                            pass

                    else:

                        idx = rxString.find("{")
                        msgType = rxString[0:idx]
                        msgType = msgType.strip()


                        jsonData = str(rxString[idx:len(rxString)])
                        try:
                            reply = json.loads(jsonData)

                            self.logger.info("Port:" + str(self.cmdport)+ " <<<< " + str(jsonData))

                            # Intercept any registered JSON message types.
                            for key, cb_list in self._intercept_handlers.items():
                                matches = False
                                if isinstance(key, str):
                                    if key.lstrip().startswith("{"):
                                        try:
                                            matches = reply == json.loads(key)
                                        except json.JSONDecodeError:
                                            matches = False
                                    else:
                                        matches = key in reply

                                if matches:
                                    try:
                                        for callback, user_args in cb_list:
                                            callback(reply, user_args)
                                    except Exception as e:
                                        self.logger.error("Error in registered handler for '%s': %s", key, e)
                                        traceback.print_exc()

                            if "PopotoModulations" in reply:
                                self._update_payload_modes_from_modulations(reply)



                            if("RemoteCommand" in reply and self.remoteCommandHandler != None):
                                self.remoteCommandHandler.handleCommand(reply['RemoteCommand'])

                            if("RemotePshellCommand" in reply):
                                if (self.remotePshellEnabled):
                                    self.logger.info("Remote pshell command detected, executing...")
                                    self.logger.info(reply['RemotePshellCommand'])
                                    self.remotePshellCommandQueue.put(reply['RemotePshellCommand']) # To be read in default_shell
                                else:
                                    self.logger.info("Remote Command received, but remote pshell command execution is disabled.")
                                    self.logger.info("To enable this functionality, use the enableRemotePshell command.")


                            if jsonData == '{"BatteryVoltage":-0.001080}':
                                self.logger.warning("BatteryVoltage not currently measurable.")
                                self.logger.warning("(This may be due to a missing hardware component or firmware update.")
                                self.logger.warning("Contact info@popotomodem.com for more information.)")

                            # Drop unsolicited parameter dumps from other clients
                            if not self._fetchingParams and ("AllParameters" in reply or "Element" in reply):
                                self.logger.debug("Dropping unsolicited parameter message")
                                rxString = ''
                                continue

                            self.replyQ.put(reply)
                        except Exception as e:
                            self.logger.error(e)
                            self.logger.error("Unparsable JSON message " + jsonData)

                        if(self.rawTerminal == False):
                            self.logger.log(logging.WARNING, "\033[1m"+str(jsonData)+"\033[0m")
                        else:
                            self.logger.log(logging.WARNING, str(jsonData))

                        rxString = ''

            except OSError:
                errorcount += 1
                time.sleep(0.01)
                continue
        self.logger.debug("Command parsing loop stopped")

    def exit(self):
        """Hook for compatibility with legacy client code."""
        self.tearDownPopoto()

    def receive(self):
        """Read a raw chunk of 256 bytes from the command socket."""
        self.cmdsocket.recv(256)

    def close(self):
        """Close the command socket connection."""
        self.cmdsocket.close()

    def setTimeout(self, timeout):
        """
        Set the socket timeout used while waiting for command-channel traffic.

        Args:
            timeout (float): Timeout value in seconds.
        """
        self.cmdsocket.settimeout(timeout)

    def getCycleCount(self):
        """
        Request and display application cycle-count statistics from the modem.
        """
        while self.replyQ.empty() == False:
            self.replyQ.get()

        self.getValueI('APP_CycleCount')
        reply = self.replyQ.get(True, 3)
        if reply:
            if "Application.0" in reply:
                self.dispmips(reply)

        else:
            self.logger.error("Get CycleCount Timeout")


    def dispMips(self, mips):
        """
        Pretty-print cycle statistics returned by ``getCycleCount``.

        Args:
            mips (Mapping[str, Mapping[str, float]]): Raw statistics keyed by module name.
        """
        v = {}
        self.logger.critical('Name                            |       min  |        max |     total  |      count |    average |  peak mips | avg mips')
        for module in mips:
            v = mips[module]
            name = module
            self.logger.critical('{:<32}|{:12}|{:12}|{:12.1e}|{:12}|{:12.1f}|{:12.1f}|{:12.1f}'.format(name,v['min'],v['max'],v['total'], v['count'], v['total']/v['count'], v['max']*160/1e6, (160/1e6)*v['total']/v['count'] ))

    def pumpAudio(self, inFilename, outFilename):
        """
        Play audio through the modem DSP path and capture the processed output.

        Args:
            inFilename (str): Input PCM/REC file path to send to the modem.
            outFilename (str): Destination PCM file path for the returned audio.
        """
        global FRAMESIZE
        try:
            import scipy.io.wavfile as scipy_io_wavfile
            from progressbar import Bar,  ETA, FileTransferSpeed, Percentage, ProgressBar
            import numpy as np
        except ImportError as e:
            print(f"Not all needed modules are installed: {e}")
        
        sock = socket(AF_INET, SOCK_STREAM)
        sock.connect((self.ip, int(self.pcmioport)) )
        sock.setblocking(True)

        fs, read_data = scipy_io_wavfile.read(inFilename)

        if fs == 1024000: #DELSYS 1MHz mode
            FRAMESIZE = 6400

        write_data = []
        self.logger.info("Processing input wave file {} Output wave file  {}".format(inFilename, outFilename))

        rmndr = len(read_data) % FRAMESIZE

        if rmndr != 0:
            read_data = np.concatenate((read_data, np.zeros(FRAMESIZE - rmndr)))

        L = int(len(read_data)/FRAMESIZE)

        widgets = ['Test: ', Percentage(), ' ', Bar(marker='#',left='[',right=']'),' ', ETA(), ' ', FileTransferSpeed()]

        pbar = ProgressBar(widgets=widgets, maxval = L)
        pbar.start()

        for i in range(L):
            buf = read_data[i*FRAMESIZE: i*FRAMESIZE + FRAMESIZE]
            self.write_pcm(sock, buf)
            buf = self.read_pcm(sock)
            write_data.extend(buf)
            pbar.update(i)

        formatted = np.asarray(write_data).astype(np.float32)

        scipy_io_wavfile.write(outFilename, fs, formatted)
        self.logger.info("\nProcessing Complete... Collecting status")
        sock.close()
        FRAMESIZE = 640 #reset

    def read_pcm(self, sock):
        """
        Read a single frame of floating-point PCM samples from the given socket.

        Args:
            sock (socket.socket): Connected PCM stream socket.

        Returns:
            numpy.ndarray: Array of ``FRAMESIZE`` float32 samples.
        """
        NBYTES = FRAMESIZE * 4

        data = b''
        while len(data) < NBYTES:
            d = sock.recv(NBYTES - len(data))
            if len(d) > 0:
                data += d
            else:
                # If we receive 0 bytes, the connection may have closed
                break

        sig = struct.unpack_from(f'{FRAMESIZE}f', data)
        try:
            pcmdata = np.fromiter(sig, dtype=np.float32)
        except ModuleNotFoundError:
            import numpy as np
            pcmdata = np.fromiter(sig, dtype=np.float32)
        except ImportError:
            self.logger.warning("Could not import numpy. Make sure it is installed.")
            pcmdata = []
        return pcmdata

    def write_pcm(self, sock, buf):
        """
        Send a frame of floating-point PCM samples to the modem PCM socket.

        Args:
            sock (socket.socket): Connected PCM stream socket.
            buf (Sequence[float]): ``FRAMESIZE`` samples to transmit.
        """
        msg = struct.pack('f' * FRAMESIZE, *buf)
        totalsent = 0
        msglen = len(msg)
        while totalsent < msglen:
            sent = sock.send(msg[totalsent:])
            totalsent += sent

    def pumpAudioDeprecated(self, inFilename, outFilename):
        """
        Legacy audio loopback helper retained for backwards compatibility.

        Args:
            inFilename (str): Input PCM/REC file path to stream to the modem.
            outFilename (str): Destination PCM file path for captured audio.
        """
        try:
            import scipy.io.wavfile as scipy_io_wavfile
            from progressbar import Bar,  ETA, FileTransferSpeed, Percentage, ProgressBar
            import numpy as np
        except ImportError as e:
            print(f"Not all needed modules are installed: {e}")
        
        self.pcmiosocket = socket(AF_INET, SOCK_STREAM)
        self.pcmiosocket.connect((self.ip, int(self.pcmioport)) )
        self.pcmiosocket.setblocking(True)
        FrameSize = 640
        nbytes = FrameSize * 4   #sizeof(uint32_t )
        done = False
        zeroFrame = bytearray(nbytes)
        fs, read_data = scipy_io_wavfile.read(inFilename)
        self.logger.info("Processing input wave file {} Output wave file  {}".format(inFilename, outFilename))
        nFramesOut=0
        write_data = []
        nframes = 0
        paddingSilenceFrames = fs  # Pad end of file with 1 second of data
        paddingSilence = 0

        if self.pcmiosocket != None:
            targetNFrames = len(read_data) + paddingSilenceFrames

            inSock = []
            outSock = []
            exceptSock = []
            inSock.append(self.pcmiosocket)
            outSock.append(self.pcmiosocket)
            exceptSock.append(self.pcmiosocket)
            widgets = ['Test: ', Percentage(), ' ', Bar(marker='#',left='[',right=']'),' ', ETA(), ' ', FileTransferSpeed()]

            pbar = ProgressBar(widgets=widgets, maxval=targetNFrames)
            pbar.start()

            while done == False:

                pbar.update(nframes)
                readable, writeable, exceptions = select.select(inSock, outSock , exceptSock)
                for sock in writeable:
                    if (nFramesOut + FrameSize) < len(read_data):

                        txout = read_data[nFramesOut:nFramesOut+FrameSize]
                        nFramesOut += FrameSize
                        sig=txout.tolist()
                        msg = struct.pack('f' * 640, *sig)
                        sock.sendall(msg)
                    else:
                        sock.sendall(zeroFrame)
                        paddingSilence += len(zeroFrame)/4

                for sock in readable:
                    data = b''
                    while len(data) < FrameSize:
                        d = sock.recv(nbytes - len(data))
                        if(len(d)>0):
                            data+=d
                    num_floats = len(data) // 4
                    sig=struct.unpack_from(f"{num_floats}f",data)
                    write_data+=sig
                    nframes= nframes + FrameSize
                    if (nframes >= targetNFrames):
                            done = True


            scipy_io_wavfile.write(outFilename, fs, np.asarray(write_data))
            self.logger.info("\nProcessing Complete... Collecting status")
