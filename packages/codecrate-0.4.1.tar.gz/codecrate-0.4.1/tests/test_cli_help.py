from __future__ import annotations

import pytest

from codecrate.cli import main


def test_main_without_command_prints_friendly_help(capsys) -> None:
    main([])

    captured = capsys.readouterr()
    assert "usage: codecrate" in captured.out
    assert "Quick start examples:" in captured.out
    assert "codecrate pack . -o context.md" in captured.out
    assert "codecrate unpack context.md -o out/ --strict" in captured.out
    assert "codecrate validate-pack context.md --strict" in captured.out


def test_main_help_flag_still_works(capsys) -> None:
    try:
        main(["-h"])
    except SystemExit as exc:
        assert exc.code == 0

    captured = capsys.readouterr()
    assert "pack" in captured.out
    assert "unpack" in captured.out
    assert "validate-pack" in captured.out


def test_main_version_flag_prints_version(capsys) -> None:
    with pytest.raises(SystemExit) as exc:
        main(["--version"])
    assert exc.value.code == 0

    captured = capsys.readouterr()
    assert captured.out.startswith("codecrate ")


def test_pack_help_clarifies_explicit_file_behavior(capsys) -> None:
    with pytest.raises(SystemExit) as exc:
        main(["pack", "-h"])
    assert exc.value.code == 0

    captured = capsys.readouterr()
    assert "Include globs are not applied" in captured.out
    assert "exclude" in captured.out
    assert "ignore files still apply" in captured.out
    assert "agent implies compact nav + normalized v3 index-json" in captured.out
    assert "lean-agent implies compact nav + lean normalized v3" in captured.out
    assert "index-json" in captured.out
    assert "portable" in captured.out
    assert "preserves" in captured.out
    assert "overrides them" in captured.out
    assert "--index-json-mode" in captured.out
    assert "--index-json-pretty" in captured.out
    assert "--index-json-lookup" in captured.out
    assert "--index-json-symbol-index-lines" in captured.out
    assert "--index-json-semantic" in captured.out
    assert "--markdown-repository-guide" in captured.out
    assert "--emit-standalone-unpacker" in captured.out
    assert "--locator-space" in captured.out
    assert "reconstructed when --emit-standalone-unpacker" in captured.out
    assert "enabled, otherwise markdown" in captured.out
