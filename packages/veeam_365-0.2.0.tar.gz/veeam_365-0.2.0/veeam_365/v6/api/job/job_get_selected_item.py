from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.rest_exception_info import RESTExceptionInfo
from ...models.rest_job_item_composed import RESTJobItemComposed
from ...types import Response


def _get_kwargs(
    job_id: UUID,
    item_id: str,
) -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v6/Jobs/{job_id}/SelectedItems/{item_id}".format(
            job_id=quote(str(job_id), safe=""),
            item_id=quote(str(item_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> RESTExceptionInfo | RESTJobItemComposed:
    if response.status_code == 200:
        response_200 = RESTJobItemComposed.from_dict(response.json())

        return response_200

    response_default = RESTExceptionInfo.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[RESTExceptionInfo | RESTJobItemComposed]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    job_id: UUID,
    item_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[RESTExceptionInfo | RESTJobItemComposed]:
    """
    Args:
        job_id (UUID):
        item_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[RESTExceptionInfo | RESTJobItemComposed]
    """

    kwargs = _get_kwargs(
        job_id=job_id,
        item_id=item_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    job_id: UUID,
    item_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> RESTExceptionInfo | RESTJobItemComposed | None:
    """
    Args:
        job_id (UUID):
        item_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        RESTExceptionInfo | RESTJobItemComposed
    """

    return sync_detailed(
        job_id=job_id,
        item_id=item_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    job_id: UUID,
    item_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[RESTExceptionInfo | RESTJobItemComposed]:
    """
    Args:
        job_id (UUID):
        item_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[RESTExceptionInfo | RESTJobItemComposed]
    """

    kwargs = _get_kwargs(
        job_id=job_id,
        item_id=item_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    job_id: UUID,
    item_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> RESTExceptionInfo | RESTJobItemComposed | None:
    """
    Args:
        job_id (UUID):
        item_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        RESTExceptionInfo | RESTJobItemComposed
    """

    return (
        await asyncio_detailed(
            job_id=job_id,
            item_id=item_id,
            client=client,
        )
    ).parsed
