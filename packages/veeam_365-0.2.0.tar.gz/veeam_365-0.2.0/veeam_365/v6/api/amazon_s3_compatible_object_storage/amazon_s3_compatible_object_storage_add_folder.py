from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.rest_amazon_folder_to_receive_s3_compatible import RESTAmazonFolderToReceiveS3Compatible
from ...models.rest_amazon_folder_to_send import RESTAmazonFolderToSend
from ...models.rest_exception_info import RESTExceptionInfo
from ...types import UNSET, Response


def _get_kwargs(
    bucket_name: str,
    *,
    body: RESTAmazonFolderToSend,
    account_id: UUID,
    service_point: str,
    custom_region_id: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    json_account_id = str(account_id)
    params["accountId"] = json_account_id

    params["ServicePoint"] = service_point

    params["CustomRegionId"] = custom_region_id

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v6/S3CompatibleResources/buckets/{bucket_name}/folders".format(
            bucket_name=quote(str(bucket_name), safe=""),
        ),
        "params": params,
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> RESTAmazonFolderToReceiveS3Compatible | RESTExceptionInfo:
    if response.status_code == 200:
        response_200 = RESTAmazonFolderToReceiveS3Compatible.from_dict(response.json())

        return response_200

    response_default = RESTExceptionInfo.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[RESTAmazonFolderToReceiveS3Compatible | RESTExceptionInfo]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    bucket_name: str,
    *,
    client: AuthenticatedClient | Client,
    body: RESTAmazonFolderToSend,
    account_id: UUID,
    service_point: str,
    custom_region_id: str,
) -> Response[RESTAmazonFolderToReceiveS3Compatible | RESTExceptionInfo]:
    """
    Args:
        bucket_name (str):
        account_id (UUID):
        service_point (str):
        custom_region_id (str):
        body (RESTAmazonFolderToSend):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[RESTAmazonFolderToReceiveS3Compatible | RESTExceptionInfo]
    """

    kwargs = _get_kwargs(
        bucket_name=bucket_name,
        body=body,
        account_id=account_id,
        service_point=service_point,
        custom_region_id=custom_region_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    bucket_name: str,
    *,
    client: AuthenticatedClient | Client,
    body: RESTAmazonFolderToSend,
    account_id: UUID,
    service_point: str,
    custom_region_id: str,
) -> RESTAmazonFolderToReceiveS3Compatible | RESTExceptionInfo | None:
    """
    Args:
        bucket_name (str):
        account_id (UUID):
        service_point (str):
        custom_region_id (str):
        body (RESTAmazonFolderToSend):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        RESTAmazonFolderToReceiveS3Compatible | RESTExceptionInfo
    """

    return sync_detailed(
        bucket_name=bucket_name,
        client=client,
        body=body,
        account_id=account_id,
        service_point=service_point,
        custom_region_id=custom_region_id,
    ).parsed


async def asyncio_detailed(
    bucket_name: str,
    *,
    client: AuthenticatedClient | Client,
    body: RESTAmazonFolderToSend,
    account_id: UUID,
    service_point: str,
    custom_region_id: str,
) -> Response[RESTAmazonFolderToReceiveS3Compatible | RESTExceptionInfo]:
    """
    Args:
        bucket_name (str):
        account_id (UUID):
        service_point (str):
        custom_region_id (str):
        body (RESTAmazonFolderToSend):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[RESTAmazonFolderToReceiveS3Compatible | RESTExceptionInfo]
    """

    kwargs = _get_kwargs(
        bucket_name=bucket_name,
        body=body,
        account_id=account_id,
        service_point=service_point,
        custom_region_id=custom_region_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    bucket_name: str,
    *,
    client: AuthenticatedClient | Client,
    body: RESTAmazonFolderToSend,
    account_id: UUID,
    service_point: str,
    custom_region_id: str,
) -> RESTAmazonFolderToReceiveS3Compatible | RESTExceptionInfo | None:
    """
    Args:
        bucket_name (str):
        account_id (UUID):
        service_point (str):
        custom_region_id (str):
        body (RESTAmazonFolderToSend):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        RESTAmazonFolderToReceiveS3Compatible | RESTExceptionInfo
    """

    return (
        await asyncio_detailed(
            bucket_name=bucket_name,
            client=client,
            body=body,
            account_id=account_id,
            service_point=service_point,
            custom_region_id=custom_region_id,
        )
    ).parsed
