"""
AI Operations Assistant — rule-based intelligence engine.
Analyzes cluster signals and produces natural language
explanations, summaries, and recommendations.

No external API required — uses pattern matching and
heuristics. Can be extended with LLM integration later.
"""

from core.collectors.pods import collect_pods
from core.collectors.events import collect_events
from core.collectors.nodes import collect_nodes
from core.collectors.deployments import (
    collect_deployments
)
from core.collectors.inspect import (
    inspect_pod, pod_events, pod_logs,
    extract_pod_details
)
from core.collectors.metrics import top_pods
from core.resolver import resolve_pod_name
from core.selector import choose_pod
from core.diagnostics.engine import diagnose
from core.collectors.diagnosis import collect_diagnosis


def handle_ai_query(query):
    """
    Route natural language queries to appropriate
    analysis functions. Returns a structured response.
    """
    from core.nlp.matcher import parse_query
    parsed = parse_query(query)

    intent = parsed["intent"] if parsed else None
    entities = parsed["entities"] if parsed else {}
    target = entities.get("target")

    if intent == "count_pods":
        return _count_pods(query, target)

    if intent == "why_failing":
        return _why_query(query, target)

    if intent == "diagnose" and not target:
        return _high_restart_pods()

    if intent == "summarize":
        return _summarize_cluster()

    if intent == "what_changed":
        return _what_changed()

    if intent == "unhealthy":
        return _unhealthy_pods()

    if intent == "top_pods":
        return _top_consumers()

    if intent == "events":
        return _warning_events()

    if intent == "anomalies":
        return _anomaly_check()

    if intent == "health_check":
        return _health_check(query, target)

    if intent == "is_safe":
        # Fallback to general explanation if not handled by safety logic
        return _why_query(query, target)

    # Fallback
    return {
        "title": "🤖 AI Assistant",
        "content": (
            "I can help with:\n\n"
            "  [bold]DIAGNOSE[/bold]\n"
            "  • [cyan]why is <pod> failing[/cyan]\n"
            "  • [cyan]diagnose high restart pods[/cyan]\n"
            "  • [cyan]which pods are unhealthy[/cyan]\n\n"
            "  [bold]ANALYZE[/bold]\n"
            "  • [cyan]summarize cluster health[/cyan]\n"
            "  • [cyan]top resource consumers[/cyan]\n"
            "  • [cyan]is <deployment> healthy[/cyan]\n\n"
            "  [bold]INVESTIGATE[/bold]\n"
            "  • [cyan]what changed recently[/cyan]\n"
            "  • [cyan]show warning events[/cyan]\n"
            "  • [cyan]any anomalies detected[/cyan]\n"
        ),
        "severity": "info",
    }


def _count_pods(query, target=None):
    """Count pods matching a name pattern."""
    if not target or target in {
        "pods", "total", "all", "the", "running",
    }:
        # General count
        pods = collect_pods()
        running = sum(
            1 for p in pods if p["status"] == "Running"
        )
        return {
            "title": "🤖 Pod Count",
            "content": (
                f"[bold]Total pods:[/bold] {len(pods)}\n"
                f"  [green]● Running:[/green] {running}\n"
                f"  [yellow]● Other:[/yellow] "
                f"{len(pods) - running}"
            ),
            "severity": "info",
        }

    pods = collect_pods()
    matching = [
        p for p in pods
        if target in p["name"].lower()
    ]

    if not matching:
        return {
            "title": f"🤖 {target} pods",
            "content": (
                f"No pods matching '{target}' found."
            ),
            "severity": "info",
        }

    running = [
        p for p in matching
        if p["status"] == "Running"
    ]
    not_running = [
        p for p in matching
        if p["status"] != "Running"
    ]

    lines = [
        f"[bold]{len(matching)} pods matching "
        f"'{target}':[/bold]\n",
        f"  [green]● Running:[/green] {len(running)}",
    ]

    if not_running:
        lines.append(
            f"  [red]● Not running:[/red] "
            f"{len(not_running)}"
        )

    lines.append("\n[bold]Pods:[/bold]")
    for p in matching:
        status_color = (
            "green" if p["status"] == "Running"
            else "red"
        )
        restart_info = (
            f" (R:{p['restarts']})"
            if p["restarts"] > 0 else ""
        )
        lines.append(
            f"  [{status_color}]●[/{status_color}] "
            f"{p['name']} "
            f"[dim]{p['status']}{restart_info}[/dim]"
        )

    return {
        "title": f"🤖 {target} pods",
        "content": "\n".join(lines),
        "severity": "info",
    }


def _why_query(query, target=None):
    """Analyze why a specific resource is failing."""
    if not target:
        return {
            "title": "🤖 Analysis",
            "content": "Please specify a pod or deployment name.",
            "severity": "info",
        }

    # Resolve pod
    matches = resolve_pod_name(target)
    if not matches:
        return {
            "title": "🤖 Analysis",
            "content": (
                f"No pods matching '{target}' found."
            ),
            "severity": "warning",
        }

    pod_name = matches[0]
    data = collect_diagnosis(pod_name)
    if not data:
        return {
            "title": "🤖 Analysis",
            "content": f"Could not inspect '{pod_name}'.",
            "severity": "warning",
        }

    # Fetch logs for error detection
    logs = pod_logs(pod_name, tail=50)
    log_errors = [l for l in logs if any(x in l.lower() for x in ["error", "fail", "exception", "fatal", "panic"])]

    # Fetch events
    events = pod_events(pod_name)
    warning_events = [e for e in events if e["type"] == "Warning"]

    findings = diagnose(data)

    # Build explanation
    critical = [
        f for f in findings if f["severity"] == "critical"
    ]
    warnings = [
        f for f in findings if f["severity"] == "warning"
    ]

    if not critical and not warnings:
        return {
            "title": f"🤖 {pod_name}",
            "content": (
                f"[green]Pod appears healthy.[/green]\n"
                f"No critical issues detected."
            ),
            "severity": "healthy",
        }

    lines = [f"[bold]Analysis for {pod_name}:[/bold]\n"]

    if critical:
        lines.append("[bold red]Root Causes:[/bold red]")
        for f in critical:
            lines.append(
                f"  ❌ {f['title']}\n"
                f"     {f['detail']}\n"
                f"     [dim]→ {f['action']}[/dim]"
            )

    if warnings:
        lines.append("\n[bold yellow]Warnings:[/bold yellow]")
        for f in warnings:
            lines.append(
                f"  ⚠️  {f['title']}\n"
                f"     [dim]→ {f['action']}[/dim]"
            )

    # Add evidence from logs/events
    if log_errors:
        lines.append("\n[bold red]Evidence from Logs:[/bold red]")
        for l in log_errors[:3]:
            lines.append(f"  [dim]{l.strip()}[/dim]")

    if warning_events:
        lines.append("\n[bold yellow]Recent Warning Events:[/bold yellow]")
        for e in warning_events[:3]:
            lines.append(f"  ⚠️  {e['reason']}: {e['message']}")

    return {
        "title": f"🤖 Why is {target} failing?",
        "content": "\n".join(lines),
        "severity": "critical" if critical else "warning",
    }


def _summarize_cluster():
    """Produce a cluster health summary."""
    pods = collect_pods()
    nodes = collect_nodes()
    deployments = collect_deployments()
    events = collect_events(limit=50)

    total_pods = len(pods)
    running = sum(
        1 for p in pods if p["status"] == "Running"
    )
    crashing = sum(
        1 for p in pods if p["restarts"] >= 5
    )
    pending = sum(
        1 for p in pods if p["status"] == "Pending"
    )

    total_nodes = len(nodes)
    ready_nodes = sum(
        1 for n in nodes if n["ready"]
    )

    total_deps = len(deployments)
    healthy_deps = sum(
        1 for d in deployments
        if d["available"] >= d["desired"]
    )

    warning_events = sum(
        1 for e in events if e["type"] == "Warning"
    )

    # Determine overall health
    if crashing > 0 or pending > 0 or ready_nodes < total_nodes:
        overall = "[bold yellow]DEGRADED[/bold yellow]"
    elif warning_events > 10:
        overall = "[bold yellow]NOISY[/bold yellow]"
    else:
        overall = "[bold green]HEALTHY[/bold green]"

    lines = [
        f"[bold]Cluster Status:[/bold] {overall}\n",
        f"[cyan]Pods:[/cyan]        "
        f"{running}/{total_pods} running",
    ]

    if crashing:
        lines.append(
            f"             [red]{crashing} crash-looping[/red]"
        )
    if pending:
        lines.append(
            f"             [yellow]{pending} pending[/yellow]"
        )

    lines.extend([
        f"[cyan]Nodes:[/cyan]       "
        f"{ready_nodes}/{total_nodes} ready",
        f"[cyan]Deployments:[/cyan] "
        f"{healthy_deps}/{total_deps} healthy",
        f"[cyan]Events:[/cyan]      "
        f"{warning_events} warnings in recent events",
    ])

    # Actionable insights
    if crashing or pending or warning_events > 5:
        lines.append("\n[bold]Suggested Actions:[/bold]")
        if crashing:
            lines.append(
                "  → Run [cyan]diagnose <pod>[/cyan] "
                "on crash-looping pods"
            )
        if pending:
            lines.append(
                "  → Check node resources: "
                "[cyan]top nodes[/cyan]"
            )
        if warning_events > 5:
            lines.append(
                "  → Review events: "
                "[cyan]events[/cyan]"
            )

    return {
        "title": "🤖 Cluster Summary",
        "content": "\n".join(lines),
        "severity": "info",
    }


def _what_changed():
    """Analyze recent events for changes."""
    events = collect_events(limit=50)

    if not events:
        return {
            "title": "🤖 Recent Changes",
            "content": "No recent events found.",
            "severity": "info",
        }

    # Group by reason
    reasons = {}
    for ev in events:
        reason = ev["reason"]
        if reason not in reasons:
            reasons[reason] = []
        reasons[reason].append(ev)

    lines = ["[bold]Recent Activity:[/bold]\n"]

    # Highlight important changes
    important = [
        "Killing", "Pulled", "Created",
        "Started", "ScalingReplicaSet",
        "SuccessfulDelete", "FailedScheduling",
        "BackOff"
    ]

    for reason in important:
        if reason in reasons:
            evs = reasons[reason]
            objects = set(e["object"] for e in evs)
            lines.append(
                f"  • [cyan]{reason}[/cyan] "
                f"({len(evs)}×) — "
                f"{', '.join(list(objects)[:3])}"
            )

    # Warnings summary
    warnings = [
        e for e in events if e["type"] == "Warning"
    ]
    if warnings:
        lines.append(
            f"\n[yellow]⚠ {len(warnings)} warning "
            f"events[/yellow]"
        )
        unique_warnings = set(
            e["reason"] for e in warnings
        )
        for w in unique_warnings:
            count = sum(
                1 for e in warnings
                if e["reason"] == w
            )
            lines.append(f"    {w}: {count}×")

    return {
        "title": "🤖 What Changed",
        "content": "\n".join(lines),
        "severity": "info",
    }


def _unhealthy_pods():
    """List all unhealthy pods with reasons."""
    pods = collect_pods()

    unhealthy = [
        p for p in pods
        if p["status"] != "Running" or p["restarts"] >= 3
    ]

    if not unhealthy:
        return {
            "title": "🤖 Pod Health",
            "content": (
                "[green]All pods are healthy![/green]"
            ),
            "severity": "healthy",
        }

    lines = [
        f"[bold]{len(unhealthy)} unhealthy pods:[/bold]\n"
    ]

    for pod in sorted(
        unhealthy, key=lambda x: -x["restarts"]
    ):
        if pod["status"] != "Running":
            lines.append(
                f"  ❌ {pod['name']}\n"
                f"     Status: [red]{pod['status']}[/red]"
            )
        else:
            lines.append(
                f"  ⚠️  {pod['name']}\n"
                f"     Restarts: "
                f"[yellow]{pod['restarts']}[/yellow]"
            )

    lines.append(
        "\n[dim]Run: diagnose <pod> for details[/dim]"
    )

    return {
        "title": "🤖 Unhealthy Pods",
        "content": "\n".join(lines),
        "severity": "warning",
    }


def _top_consumers():
    """Show top resource consumers."""
    pods = top_pods()

    if not pods:
        return {
            "title": "🤖 Resource Usage",
            "content": (
                "No metrics available. "
                "Is metrics-server running?"
            ),
            "severity": "warning",
        }

    lines = ["[bold]Top Resource Consumers:[/bold]\n"]
    lines.append("[cyan]By CPU:[/cyan]")
    for pod in pods[:5]:
        lines.append(
            f"  {pod['cpu']:>8}  {pod['name']}"
        )

    # Sort by memory
    by_mem = sorted(
        pods, key=lambda x: x["memory_mb"],
        reverse=True
    )
    lines.append("\n[cyan]By Memory:[/cyan]")
    for pod in by_mem[:5]:
        lines.append(
            f"  {pod['memory']:>8}  {pod['name']}"
        )

    return {
        "title": "🤖 Top Consumers",
        "content": "\n".join(lines),
        "severity": "info",
    }


def _high_restart_pods():
    """Find pods with high restart counts."""
    pods = collect_pods()

    high_restart = sorted(
        [p for p in pods if p["restarts"] >= 3],
        key=lambda x: -x["restarts"]
    )

    if not high_restart:
        return {
            "title": "🤖 Restart Analysis",
            "content": "[green]No pods with high restarts.[/green]",
            "severity": "healthy",
        }

    lines = [
        f"[bold]{len(high_restart)} pods with high restarts:[/bold]\n"
    ]

    for pod in high_restart[:10]:
        severity = "red" if pod["restarts"] >= 10 else "yellow"
        lines.append(
            f"  [{severity}]● {pod['restarts']:>3} restarts[/{severity}]  "
            f"{pod['name']}"
        )

    lines.append(
        "\n[bold]Possible causes:[/bold]"
        "\n  • Application crash on startup"
        "\n  • OOM kills (check memory limits)"
        "\n  • Failed health probes"
        "\n  • Missing config/secrets"
        "\n\n[dim]Run: diagnose <pod> for root cause[/dim]"
    )

    return {
        "title": "🤖 High Restart Pods",
        "content": "\n".join(lines),
        "severity": "warning",
    }


def _warning_events():
    """Show recent warning events."""
    events = collect_events(limit=50)

    warnings = [
        e for e in events if e["type"] == "Warning"
    ]

    if not warnings:
        return {
            "title": "🤖 Events",
            "content": "[green]No warning events.[/green]",
            "severity": "healthy",
        }

    # Group by reason
    reasons = {}
    for e in warnings:
        r = e["reason"]
        if r not in reasons:
            reasons[r] = []
        reasons[r].append(e)

    lines = [
        f"[bold]{len(warnings)} warning events:[/bold]\n"
    ]

    for reason, evs in sorted(
        reasons.items(), key=lambda x: -len(x[1])
    ):
        objects = set(e["object"] for e in evs)
        lines.append(
            f"  [yellow]● {reason}[/yellow] ({len(evs)}×)"
        )
        for obj in list(objects)[:3]:
            lines.append(f"    [dim]{obj}[/dim]")

    lines.append(
        "\n[dim]Run: events watch for live stream[/dim]"
    )

    return {
        "title": "🤖 Warning Events",
        "content": "\n".join(lines),
        "severity": "warning",
    }


def _anomaly_check():
    """Quick anomaly detection."""
    from core.ai.anomaly import detect_anomalies

    alerts = detect_anomalies()

    if not alerts:
        return {
            "title": "🤖 Anomaly Check",
            "content": "[green]✓ No anomalies detected.[/green]",
            "severity": "healthy",
        }

    critical = [a for a in alerts if a["severity"] == "critical"]
    warnings = [a for a in alerts if a["severity"] == "warning"]

    lines = [
        f"[bold]{len(alerts)} anomalies detected:[/bold]\n"
    ]

    for a in critical:
        lines.append(
            f"  [red]● {a['title']}[/red]\n"
            f"    {a['detail']}\n"
            f"    [dim]→ {a['action']}[/dim]"
        )

    for a in warnings:
        lines.append(
            f"  [yellow]● {a['title']}[/yellow]\n"
            f"    {a['detail']}"
        )

    return {
        "title": "🤖 Anomalies",
        "content": "\n".join(lines),
        "severity": "critical" if critical else "warning",
    }


def _health_check(query, target=None):
    """Check health of a specific resource."""
    if not target:
        return _summarize_cluster()

    matches = resolve_pod_name(target)
    if not matches:
        return {
            "title": "🤖 Health Check",
            "content": f"No pods matching '{target}'.",
            "severity": "info",
        }

    pod_name = matches[0]
    data = collect_diagnosis(pod_name)
    if not data:
        return {
            "title": "🤖 Health Check",
            "content": f"Could not inspect '{pod_name}'.",
            "severity": "warning",
        }

    findings = diagnose(data)
    critical = sum(
        1 for f in findings if f["severity"] == "critical"
    )
    warnings = sum(
        1 for f in findings if f["severity"] == "warning"
    )

    if critical:
        status = "[bold red]CRITICAL[/bold red]"
    elif warnings:
        status = "[bold yellow]DEGRADED[/bold yellow]"
    else:
        status = "[bold green]HEALTHY[/bold green]"

    details = data["details"]
    content = (
        f"[bold]{pod_name}[/bold]: {status}\n\n"
        f"  Phase:    {details['phase']}\n"
        f"  Node:     {details['node']}\n"
        f"  Restarts: "
        f"{details['containers'][0]['restarts'] if details['containers'] else 0}\n"
        f"  Age:      {details['age']}\n"
    )

    if critical or warnings:
        content += "\n[dim]Run: diagnose " + target + "[/dim]"

    return {
        "title": f"🤖 {pod_name}",
        "content": content,
        "severity": (
            "critical" if critical
            else "warning" if warnings
            else "healthy"
        ),
    }
