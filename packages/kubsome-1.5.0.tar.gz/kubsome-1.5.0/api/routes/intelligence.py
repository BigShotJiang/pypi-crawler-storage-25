from fastapi import APIRouter, Query
from pydantic import BaseModel

from core.collectors.search import search_resources
from core.collectors.security import security_scan
from core.collectors.cost import resource_recommendations, find_unused_resources
from core.healthcheck import run_health_check
from core.ai.engine import handle_ai_query
from core.ai.anomaly import detect_anomalies

router = APIRouter(tags=["intelligence"])


class AiRequest(BaseModel):
    query: str
    last_target: str = None


@router.get("/search")
def get_search(q: str = Query(..., min_length=1)):
    results = search_resources(q)
    return {"query": q, "results": results}


@router.get("/security")
def get_security():
    findings = security_scan()
    return {"findings": findings}


@router.get("/health-check")
def get_health_check():
    return run_health_check()


@router.get("/anomalies")
def get_anomalies():
    alerts = detect_anomalies()
    return {"alerts": alerts}


@router.get("/optimize")
def get_optimize():
    recs = resource_recommendations()
    return {"recommendations": recs}


@router.get("/unused")
def get_unused():
    return {"resources": find_unused_resources()}


@router.post("/ai")
def post_ai(req: AiRequest):
    import re
    from core.nlp.matcher import parse_query
    from core.context import context

    # Temporarily set context memory for this request if provided
    if req.last_target:
        context.last_target = req.last_target

    parsed = parse_query(req.query)

    # Check if query references an ambiguous resource
    clarification = _check_ambiguity(req.query, parsed)
    if clarification:
        return clarification

    response = handle_ai_query(req.query)
    # Strip Rich markup tags for API consumers
    content = response.get("content", "")
    content = re.sub(r'\[/?[^\]]+\]', '', content)
    return {
        "title": response.get("title", "").replace("🤖 ", ""),
        "answer": content,
        "severity": response.get("severity", "info"),
        "last_target": context.last_target
    }


def _check_ambiguity(query: str, parsed=None):
    """If query mentions a resource with multiple matches, return options."""
    from core.collectors.pods import collect_pods
    import re

    # Use target from unified NLP engine if available
    target = parsed["entities"].get("target") if parsed else None

    if not target:
        # Fallback to old patterns if needed
        lower = query.lower()
        patterns = [
            r"why is (\S+)",
            r"diagnose (\S+)",
            r"inspect (\S+)",
            r"logs for (\S+)",
        ]

        for pattern in patterns:
            match = re.search(pattern, lower)
            if match:
                target = match.group(1).rstrip("?")
                break

    if not target:
        return None

    # Use substring matching to find ALL pods containing target
    pods = collect_pods()
    matching = [
        p["name"] for p in pods
        if target in p["name"].lower()
    ]

    if not matching or len(matching) <= 1:
        return None

    # Multiple matches — ask user to pick
    return {
        "title": f"Which '{target}'?",
        "answer": (
            f"Multiple pods match '{target}'. "
            f"Select one to continue:"
        ),
        "severity": "clarify",
        "options": matching[:8],
        "original_query": query,
    }
