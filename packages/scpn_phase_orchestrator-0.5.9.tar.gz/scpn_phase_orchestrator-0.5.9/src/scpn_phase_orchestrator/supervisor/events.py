# SPDX-License-Identifier: AGPL-3.0-or-later
# Commercial license available
# © Concepts 1996–2026 Miroslav Šotek. All rights reserved.
# © Code 2020–2026 Miroslav Šotek. All rights reserved.
# ORCID: 0009-0009-3560-0851
# Contact: www.anulum.li | protoscience@anulum.li
# SCPN Phase Orchestrator — Supervisor event types

from __future__ import annotations

from collections import deque
from dataclasses import dataclass

__all__ = ["RegimeEvent", "EventBus"]

VALID_EVENT_KINDS = frozenset(
    {
        "boundary_breach",
        "r_threshold",
        "regime_transition",
        "manual",
        "petri_transition",
    }
)


@dataclass(frozen=True)
class RegimeEvent:
    """Immutable event emitted on regime transitions or boundary breaches."""

    kind: str
    step: int
    detail: str = ""

    def __post_init__(self) -> None:
        if self.kind not in VALID_EVENT_KINDS:
            raise ValueError(
                f"invalid event kind {self.kind!r}, "
                f"expected one of {sorted(VALID_EVENT_KINDS)}"
            )


class EventBus:
    """Pub/sub bus for regime events with bounded history."""

    def __init__(self, maxlen: int = 200) -> None:
        if maxlen < 1:
            raise ValueError(f"maxlen must be >= 1, got {maxlen}")
        self._subscribers: list = []
        self._history: deque[RegimeEvent] = deque(maxlen=maxlen)

    def subscribe(self, callback: object) -> None:
        """Register a callback to receive future events."""
        self._subscribers.append(callback)

    def unsubscribe(self, callback: object) -> None:
        """Remove a previously registered callback."""
        self._subscribers = [s for s in self._subscribers if s != callback]

    def post(self, event: RegimeEvent) -> None:
        """Record *event* in history and notify all subscribers."""
        self._history.append(event)
        for cb in self._subscribers:
            cb(event)

    @property
    def history(self) -> list[RegimeEvent]:
        """Chronological list of all posted events."""
        return list(self._history)

    @property
    def count(self) -> int:
        """Number of events in history."""
        return len(self._history)

    def clear(self) -> None:
        """Discard all recorded events."""
        self._history.clear()
