# SPDX-License-Identifier: AGPL-3.0-or-later
# Commercial license available
# © Concepts 1996–2026 Miroslav Šotek. All rights reserved.
# © Code 2020–2026 Miroslav Šotek. All rights reserved.
# ORCID: 0009-0009-3560-0851
# Contact: www.anulum.li | protoscience@anulum.li
# SCPN Phase Orchestrator — Modbus adapter with TLS authentication

"""Secure Modbus TCP adapter with mutual TLS.

Wraps pymodbus with an ``ssl.SSLContext`` for certificate-authenticated
connections to SCADA endpoints per IEC 62443 zone/conduit requirements.
"""

from __future__ import annotations

import ssl
from pathlib import Path

from scpn_phase_orchestrator.adapters._schema import (
    require_non_empty_str,
    require_tcp_port,
)

__all__ = ["SecureModbusAdapter", "HAS_PYMODBUS"]

try:
    # type ignore: pymodbus is optional and has incomplete typing on supported releases.
    from pymodbus.client import ModbusTlsClient  # type: ignore[import-not-found]

    HAS_PYMODBUS = True
except ImportError:
    # type ignore: None sentinel mirrors the optional pymodbus import boundary.
    ModbusTlsClient = None  # type: ignore[assignment,misc]
    HAS_PYMODBUS = False


class SecureModbusAdapter:
    """Modbus TCP client with TLS mutual authentication.

    Parameters
    ----------
    host : str
        Target Modbus device hostname or IP.
    port : int
        TCP port (default Modbus/TLS: 802).
    tls_cert_path : str | Path
        Path to client certificate (PEM).
    tls_key_path : str | Path
        Path to client private key (PEM).
    ca_cert_path : str | Path | None
        Path to CA bundle (PEM) for server verification. When provided,
        server certificate is verified against this CA. When ``None``,
        verification is disabled (NOT recommended for production).
    """

    def __init__(
        self,
        host: str,
        port: int,
        tls_cert_path: str | Path,
        tls_key_path: str | Path,
        ca_cert_path: str | Path | None = None,
    ) -> None:
        self._host = require_non_empty_str(host, field="Modbus host")
        self._port = require_tcp_port(port, field="Modbus port")
        self._cert = Path(tls_cert_path)
        self._key = Path(tls_key_path)
        self._ca = Path(ca_cert_path) if ca_cert_path is not None else None
        self._ctx = self._build_tls_context()
        self._client = self._connect()

    def _build_tls_context(self) -> ssl.SSLContext:
        # Filename only in the raised message — full paths to key material
        # must never surface in error strings that may reach logs or clients.
        if not self._cert.exists():
            raise ConnectionError(f"TLS certificate not found: {self._cert.name}")
        if not self._key.exists():
            raise ConnectionError(f"TLS key not found: {self._key.name}")
        try:
            ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
            ctx.load_cert_chain(certfile=str(self._cert), keyfile=str(self._key))
            if self._ca is not None:
                ctx.load_verify_locations(cafile=str(self._ca))
                ctx.check_hostname = True
                ctx.verify_mode = ssl.CERT_REQUIRED
            else:
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
            return ctx
        except ssl.SSLError:
            raise ConnectionError("TLS context creation failed") from None

    def _connect(self) -> object:
        if ModbusTlsClient is None:
            raise ConnectionError(
                "pymodbus is required for Modbus TLS. Install: pip install pymodbus"
            )
        client = ModbusTlsClient(
            host=self._host,
            port=self._port,
            sslctx=self._ctx,
        )
        if not client.connect():
            raise ConnectionError("Modbus TLS connection failed")
        return client

    def read_register(self, address: int) -> int:
        """Read a single holding register.

        Raises ConnectionError if the read fails or returns an error frame.
        """
        # type ignore: optional pymodbus client is stored as object after runtime guard.
        result = self._client.read_holding_registers(  # type: ignore[attr-defined]
            address, count=1
        )
        if result.isError():
            raise ConnectionError(f"Modbus read error at address {address}: {result}")
        return int(result.registers[0])

    def write_register(self, address: int, value: int) -> None:
        """Write a single holding register.

        Raises ConnectionError if the write fails.
        """
        # type ignore: optional pymodbus client is stored as object after runtime guard.
        result = self._client.write_register(address, value)  # type: ignore[attr-defined]
        if result.isError():
            raise ConnectionError(f"Modbus write error at address {address}: {result}")

    def validate_connection(self) -> bool:
        """Return True if the TLS-wrapped Modbus connection is active."""
        try:
            # type ignore: optional pymodbus client is stored as object.
            return bool(self._client.connected)  # type: ignore[attr-defined]
        except (AttributeError, OSError, RuntimeError):
            return False
