# SPDX-License-Identifier: AGPL-3.0-or-later
# Commercial license available
# © Concepts 1996–2026 Miroslav Šotek. All rights reserved.
# © Code 2020–2026 Miroslav Šotek. All rights reserved.
# ORCID: 0009-0009-3560-0851
# Contact: www.anulum.li | protoscience@anulum.li
# SCPN Phase Orchestrator — Imprint update rules

from __future__ import annotations

from typing import TypeAlias

import numpy as np
from numpy.typing import NDArray

from scpn_phase_orchestrator.imprint.state import ImprintState

__all__ = ["ImprintModel"]

FloatArray: TypeAlias = NDArray[np.float64]


class ImprintModel:
    """Exponential exposure accumulation with decay and saturation.

    m_k(t+dt) = m_k(t) * exp(-decay_rate * dt) + exposure * dt,
    clipped to [0, saturation].

    Modulates: K (phase coupling), alpha (lag), mu (bifurcation).
    Does NOT modulate knm_r (amplitude coupling strength) — amplitude
    coupling topology is fixed by the binding spec, not learned.
    """

    def __init__(self, decay_rate: float, saturation: float):
        if decay_rate < 0.0:
            raise ValueError(f"decay_rate must be non-negative, got {decay_rate}")
        if saturation <= 0.0:
            raise ValueError(f"saturation must be positive, got {saturation}")
        self._decay_rate = decay_rate
        self._saturation = saturation

    def update(
        self, state: ImprintState, exposure: FloatArray, dt: float
    ) -> ImprintState:
        """Decay existing imprint, add new exposure, clip to saturation."""
        decayed = state.m_k * np.exp(-self._decay_rate * dt)
        m_new = np.clip(decayed + exposure * dt, 0.0, self._saturation)
        return ImprintState(
            m_k=m_new,
            last_update=state.last_update + dt,
            attribution=state.attribution.copy(),
        )

    def modulate_coupling(self, knm: FloatArray, imprint: ImprintState) -> FloatArray:
        """Scale Knm rows by (1 + m_k)."""
        result: FloatArray = knm * (1.0 + imprint.m_k)[:, np.newaxis]
        return result

    def modulate_lag(self, alpha: FloatArray, imprint: ImprintState) -> FloatArray:
        """Shift phase lags by antisymmetric imprint offset."""
        offset = imprint.m_k[:, np.newaxis] - imprint.m_k[np.newaxis, :]
        result: FloatArray = alpha + offset
        return result

    def modulate_mu(self, mu: FloatArray, imprint: ImprintState) -> FloatArray:
        """Scale bifurcation parameter: μ_k * (1 + m_k)."""
        result: FloatArray = mu * (1.0 + imprint.m_k)
        return result
