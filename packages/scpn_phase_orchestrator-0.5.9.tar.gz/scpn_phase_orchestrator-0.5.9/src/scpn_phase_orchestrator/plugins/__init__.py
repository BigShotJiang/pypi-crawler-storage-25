# SPDX-License-Identifier: AGPL-3.0-or-later
# Commercial license available
# © Concepts 1996–2026 Miroslav Šotek. All rights reserved.
# © Code 2020–2026 Miroslav Šotek. All rights reserved.
# ORCID: 0009-0009-3560-0851
# Contact: www.anulum.li | protoscience@anulum.li
# SCPN Phase Orchestrator — Plugin interface exports

from __future__ import annotations

from scpn_phase_orchestrator.plugins.registry import (
    PluginCapability,
    PluginCompatibilityReport,
    PluginManifest,
    build_plugin_marketplace_catalog,
    compatibility_report,
    discover_plugin_manifests,
    validate_plugin_manifest,
)

__all__ = [
    "PluginCapability",
    "PluginCompatibilityReport",
    "PluginManifest",
    "build_plugin_marketplace_catalog",
    "compatibility_report",
    "discover_plugin_manifests",
    "validate_plugin_manifest",
]
