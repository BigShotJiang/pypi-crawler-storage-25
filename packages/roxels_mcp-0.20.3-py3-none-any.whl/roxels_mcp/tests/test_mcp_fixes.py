"""Unit tests for the 8-fix MCP DX overhaul.

Covers:
  Fix 2 — set_goal_commit_rules warns when require_all_required + no required_before_commit
  Fix 3 — _collect_template_gaps HIGH gap for require_all_required + empty schema
  Fix 8 — set_goal_schema deprecated alias returns deprecation_warning
"""

import json
import pytest
import unittest.mock as mock
from unittest.mock import AsyncMock, MagicMock, patch

from roxels_mcp.server import create_server
from roxels_mcp.client import RoxelsClient


# ── Helpers ────────────────────────────────────────────────────────────────────

def _make_client(template: dict) -> RoxelsClient:
    client = MagicMock(spec=RoxelsClient)
    client.get_template = AsyncMock(return_value=template)
    client.update_template = AsyncMock(return_value=template)
    return client


def _make_template(
    goal_id: str = "goal1",
    commit_policy: str | None = None,
    schema: dict | None = None,
) -> dict:
    cfg: dict = {"trigger_goal": goal_id, "url": "https://example.com/webhook"}
    if commit_policy:
        cfg["commit_policy"] = commit_policy
    if schema:
        cfg["schema"] = schema
    return {
        "id": "tmpl1",
        "goals": [{"id": goal_id, "label": "Test goal"}],
        "settings": {
            "outputs": [{"type": "webhook", "config": cfg}]
        },
    }


# ── Fix 2: set_goal_commit_rules warns on require_all_required + empty schema ──

@pytest.mark.asyncio
async def test_set_goal_commit_rules_warns_no_required_fields():
    """require_all_required + empty schema → response includes 'warning' key."""
    template = _make_template(
        goal_id="goal1",
        commit_policy=None,
        schema={"name": {"type": "string"}},  # no required_before_commit
    )
    client = _make_client(template)
    mcp = create_server(client)

    # Call set_goal_commit_rules via the registered tool function
    tool_fn = _get_tool(mcp, "set_goal_commit_rules")
    result_str = await tool_fn(
        template_id="tmpl1",
        goal_id="goal1",
        commit_policy="require_all_required",
    )
    result = json.loads(result_str)
    assert "warning" in result
    assert "require_all_required" in result["warning"]
    assert "required_before_commit" in result["warning"]


@pytest.mark.asyncio
async def test_set_goal_commit_rules_no_warn_when_required_field_present():
    """require_all_required + schema with required_before_commit → no warning."""
    template = _make_template(
        goal_id="goal1",
        schema={"name": {"type": "string", "required_before_commit": True}},
    )
    client = _make_client(template)
    mcp = create_server(client)
    tool_fn = _get_tool(mcp, "set_goal_commit_rules")
    result_str = await tool_fn(
        template_id="tmpl1",
        goal_id="goal1",
        commit_policy="require_all_required",
    )
    result = json.loads(result_str)
    assert "warning" not in result


@pytest.mark.asyncio
async def test_set_goal_commit_rules_no_warn_for_auto_policy():
    """'auto' commit_policy → no warning regardless of schema."""
    template = _make_template(goal_id="goal1", schema={"name": "string"})
    client = _make_client(template)
    mcp = create_server(client)
    tool_fn = _get_tool(mcp, "set_goal_commit_rules")
    result_str = await tool_fn(
        template_id="tmpl1",
        goal_id="goal1",
        commit_policy="auto",
    )
    result = json.loads(result_str)
    assert "warning" not in result


# ── Fix 3: _collect_template_gaps HIGH gap for require_all_required + no rbc ──

@pytest.mark.asyncio
async def test_guided_setup_questions_high_gap_for_inert_require_all_required():
    """guided_setup_questions returns a HIGH gap when commit_policy=require_all_required
    but no required_before_commit fields exist in the schema."""
    template = _make_template(
        goal_id="goal1",
        commit_policy="require_all_required",
        schema={"name": {"type": "string"}},  # no required_before_commit
    )
    client = _make_client(template)
    # list_skills is called internally; stub it
    client._request = AsyncMock(return_value=[])
    mcp = create_server(client)
    tool_fn = _get_tool(mcp, "guided_setup_questions")
    result_str = await tool_fn(template_id="tmpl1")
    result = json.loads(result_str)

    gaps = result.get("gaps") or result.get("work_queue") or []
    high_gaps = [g for g in gaps if g.get("severity") == "HIGH"]
    assert any("require_all_required" in (g.get("problem") or "") for g in high_gaps), (
        f"Expected HIGH gap for inert require_all_required, got: {high_gaps}"
    )


@pytest.mark.asyncio
async def test_guided_setup_questions_no_high_gap_when_rbc_present():
    """No HIGH gap for require_all_required when required_before_commit field exists."""
    template = _make_template(
        goal_id="goal1",
        commit_policy="require_all_required",
        schema={"name": {"type": "string", "required_before_commit": True}},
    )
    client = _make_client(template)
    client._request = AsyncMock(return_value=[])
    mcp = create_server(client)
    tool_fn = _get_tool(mcp, "guided_setup_questions")
    result_str = await tool_fn(template_id="tmpl1")
    result = json.loads(result_str)

    gaps = result.get("gaps") or result.get("work_queue") or []
    high_rbc_gaps = [
        g for g in gaps
        if g.get("severity") == "HIGH" and "require_all_required" in (g.get("problem") or "")
    ]
    assert high_rbc_gaps == [], f"Unexpected HIGH gap: {high_rbc_gaps}"


# ── Fix 8: set_goal_schema deprecated alias ────────────────────────────────────

@pytest.mark.asyncio
async def test_set_goal_schema_alias_returns_deprecation_warning():
    """set_goal_schema (deprecated alias) returns a deprecation_warning and still works."""
    template = _make_template(goal_id="goal1")
    client = _make_client(template)
    # update_template returns the template; simulate schema being saved
    client.update_template = AsyncMock(return_value=template)
    client._request = AsyncMock(return_value=[])
    mcp = create_server(client)

    alias_fn = _get_tool(mcp, "set_goal_schema")
    result_str = await alias_fn(
        template_id="tmpl1",
        goal_id="goal1",
        schema={"name": {"type": "string"}},
    )
    result = json.loads(result_str)
    assert "deprecation_warning" in result
    assert "set_webhook_schema" in result["deprecation_warning"]


@pytest.mark.asyncio
async def test_set_webhook_schema_no_deprecation_warning():
    """set_webhook_schema (primary tool) does NOT include a deprecation_warning."""
    template = _make_template(goal_id="goal1")
    client = _make_client(template)
    client.update_template = AsyncMock(return_value=template)
    client._request = AsyncMock(return_value=[])
    mcp = create_server(client)

    primary_fn = _get_tool(mcp, "set_webhook_schema")
    result_str = await primary_fn(
        template_id="tmpl1",
        goal_id="goal1",
        schema={"name": {"type": "string"}},
    )
    result = json.loads(result_str)
    assert "deprecation_warning" not in result


# ── Fix 4: update_template warns on goal-level schema ─────────────────────────

@pytest.mark.asyncio
async def test_update_template_warns_on_goal_level_schema():
    """update_template emits a deprecation warning when a goal has 'schema' set directly."""
    template = {"id": "tmpl1", "goals": [], "settings": {}}
    client = _make_client(template)
    client.update_template = AsyncMock(return_value={"id": "tmpl1", "goals": [], "settings": {}, "warnings": []})
    mcp = create_server(client)

    tool_fn = _get_tool(mcp, "update_template")
    result_str = await tool_fn(
        template_id="tmpl1",
        goals=[{"id": "goal1", "label": "Test", "schema": {"name": "string"}}],
    )
    # _format_template_result_with_warnings returns text with warnings at the top
    # when warnings are present, followed by "Full response:" then the JSON
    assert "DEPRECATED" in result_str
    assert "set_webhook_schema" in result_str


# ── Utility ────────────────────────────────────────────────────────────────────

def _get_tool(mcp, name: str):
    """Extract a registered tool function from the FastMCP instance by name."""
    # FastMCP stores tools in _tool_manager or similar internal dict
    tools = {}
    if hasattr(mcp, "_tool_manager") and hasattr(mcp._tool_manager, "_tools"):
        tools = mcp._tool_manager._tools
    elif hasattr(mcp, "_tools"):
        tools = mcp._tools

    if name in tools:
        tool = tools[name]
        return tool.fn if hasattr(tool, "fn") else tool

    raise KeyError(f"Tool '{name}' not found. Available: {list(tools.keys())[:20]}")
