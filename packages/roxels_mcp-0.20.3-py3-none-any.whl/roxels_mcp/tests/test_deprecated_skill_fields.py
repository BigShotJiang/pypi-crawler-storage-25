"""Unit tests for _translate_deprecated_skill_fields in roxels_mcp/server.py.

Pure function — no network, no DB. Tests the deprecation shim that translates
the old skills/skill_execution_mode shape to speaker_skills/advisors.
"""
from roxels_mcp.server import _translate_deprecated_skill_fields


class TestTranslateDeprecatedSkillFields:
    def test_no_deprecated_fields_passthrough(self):
        s = {"speaker_skills": ["s1"], "language": "en"}
        result, warnings = _translate_deprecated_skill_fields(s)
        assert result == s
        assert warnings == []

    def test_inline_mode_moves_to_speaker_skills(self):
        s = {"skills": ["s1", "s2"], "skill_execution_mode": "inline"}
        result, warnings = _translate_deprecated_skill_fields(s)
        assert result["speaker_skills"] == ["s1", "s2"]
        assert "skills" not in result
        assert "skill_execution_mode" not in result
        assert len(warnings) >= 1

    def test_observer_mode_surfaces_warning_not_speaker_skills(self):
        s = {"skills": ["s1"], "skill_execution_mode": "observer"}
        result, warnings = _translate_deprecated_skill_fields(s)
        # observer → cannot auto-translate, must warn
        assert "speaker_skills" not in result or result.get("speaker_skills") == []
        assert "skills" not in result
        assert any("observer" in w.lower() or "advisor" in w.lower() for w in warnings)

    def test_inline_no_mode_field_treated_as_inline(self):
        s = {"skills": ["s1"]}
        result, warnings = _translate_deprecated_skill_fields(s)
        assert result.get("speaker_skills") == ["s1"]
        assert len(warnings) >= 1

    def test_merges_with_existing_speaker_skills_no_duplicates(self):
        s = {"skills": ["s2", "s3"], "skill_execution_mode": "inline", "speaker_skills": ["s1", "s2"]}
        result, warnings = _translate_deprecated_skill_fields(s)
        # s2 already in speaker_skills; s3 is new
        assert "s1" in result["speaker_skills"]
        assert "s2" in result["speaker_skills"]
        assert "s3" in result["speaker_skills"]
        assert result["speaker_skills"].count("s2") == 1  # no duplicate

    def test_empty_skills_list_no_warn(self):
        # skills:[] and skill_execution_mode:"inline" are the empty defaults the platform
        # writes back after every save — they should NOT trigger a deprecation warning or
        # be treated as actual deprecated usage.
        s = {"skills": [], "skill_execution_mode": "inline"}
        result, warnings = _translate_deprecated_skill_fields(s)
        assert warnings == []
        assert "speaker_skills" not in result

    def test_non_dict_passthrough(self):
        result, warnings = _translate_deprecated_skill_fields("not-a-dict")
        assert result == "not-a-dict"
        assert warnings == []

    def test_other_fields_preserved(self):
        s = {"skills": ["s1"], "language": "en", "tone": "friendly"}
        result, warnings = _translate_deprecated_skill_fields(s)
        assert result["language"] == "en"
        assert result["tone"] == "friendly"

    def test_observer_skills_not_added_to_speaker_skills(self):
        """Observer skills must NOT silently become speaker_skills."""
        s = {"skills": ["s1", "s2"], "skill_execution_mode": "observer"}
        result, _ = _translate_deprecated_skill_fields(s)
        assert result.get("speaker_skills", []) == []
