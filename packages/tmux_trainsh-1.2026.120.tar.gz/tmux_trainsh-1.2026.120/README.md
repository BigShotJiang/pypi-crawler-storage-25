# tmux-trainsh

<!-- AUTO-GENERATED FROM trainsh.commands.help_catalog; DO NOT EDIT DIRECTLY. -->

`tmux-trainsh` is a terminal-first workflow runner for GPU and remote automation work.

README is the quick overview and landing page. The canonical command reference stays in the CLI:

```bash
train help
train --help
```

Those two commands are the canonical help entry points.

## Install

Install from PyPI with uv:

```bash
uv tool install -U tmux-trainsh
train help
```

Or use the install script:

```bash
curl -LsSf https://raw.githubusercontent.com/binbinsh/tmux-trainsh/main/install.sh | bash
```

## Main Command Groups

- `train recipe` for recipe files, execution, status, logs, jobs, and schedules
- `train host` for named SSH or Colab hosts
- `train vllm` for managed remote vLLM servers and local batch clients
- `train storage` for named storage backends
- `train transfer` for local, host, and storage copies
- `train secrets` for credentials
- `train config` for config and tmux settings
- `train vast` for Vast.ai instances
- `train runpod` for RunPod Pods
- `train colab` for one-off Colab tunnels
- `train pricing` for exchange rates and cost estimates

## Quick Start

```bash
train secrets set GITHUB_TOKEN
train secrets set VAST_API_KEY
train secrets set RUNPOD_API_KEY
train secrets set POE_API_KEY
train host add
train vllm serve gpu-box Qwen/Qwen2.5-32B-Instruct --gpus 0
train storage add

train recipe show nanochat
train recipe new demo --template remote-train
train exec nanochat
train host clone gpu-box https://github.com/org/private-repo.git /srv/private-repo
train recipe status --last
```

## Bundled Examples

Current bundled examples: `aptup, brewup, hello, nanochat`

## Recipe Authoring

Public imports:

```python
from trainsh import Recipe, Host, RunpodHost, VastHost, HostPath, Storage, StoragePath, load_python_recipe, local
from trainsh import flash_attn_install_script
```

Main authoring model:

- `Recipe`
- `Host` / `VastHost` / `RunpodHost` / `HostPath`
- `Storage` / `StoragePath`
- `host.tmux(...)`
- `local.tmux(...)`
- `tmux.install_flash_attn(...)`
- `tmux.script(...)`
- `recipe.storage_wait_count(...)`

## Runtime Guarantees

- `.pyrecipe` recipes run as: load -> dependency graph from `depends_on` -> executor run
- Airflow-like retry / timeout / callback / trigger-rule semantics remain supported
- Supported executor aliases include `sequential`, `thread_pool`, `process_pool`, `local`, `airflow`, `celery`, `dask`, and `debug`
- Kubernetes executor remains unsupported

## Maintenance

To refresh this file after editing the canonical help catalog:

```bash
python3 scripts/sync_cli_docs.py
```

Regression commands:

```bash
python3 tests/test_commands.py
python3 -m unittest tests.test_runtime_persist tests.test_pyrecipe_runtime tests.test_runtime_semantics tests.test_provider_dispatch tests.test_ti_dependencies
uv run --with coverage python scripts/check_runtime_coverage.py
```
