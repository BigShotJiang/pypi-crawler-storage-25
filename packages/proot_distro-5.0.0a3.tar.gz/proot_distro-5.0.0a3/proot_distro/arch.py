import ctypes
import os
import struct
import sys

from proot_distro.constants import PREFIX, PROOT_DISTRO_X64_EMULATOR, INSTALLED_ROOTFS_DIR
from proot_distro.colors import C, msg


def get_device_cpu_arch() -> str:
    machine = os.uname().machine
    if machine in ("armv7l", "armv8l"):
        return "arm"
    return machine


def get_distro_arch_override() -> str:
    return os.environ.get("DISTRO_ARCH", "")


def supports_32bit() -> bool:
    """Return True if the host CPU supports 32-bit userspace execution."""
    machine = os.uname().machine

    if machine in ("x86_64", "amd64"):
        # All x86-64 CPUs support 32-bit x86.
        return True

    if machine in ("aarch64", "arm64"):
        # Mirror lscpu's technique: call personality(PER_LINUX32) and check
        # whether the kernel accepts it, which it only does when the CPU
        # implements AArch32 EL0.  The previous personality is restored
        # immediately so the probe has no lasting effect on the process.
        PER_LINUX32 = 0x0008
        try:
            libc = ctypes.CDLL(None)  # resolves to the in-process C library
            prev = libc.personality(PER_LINUX32)
            if prev == -1:
                return False
            libc.personality(prev)  # restore
            return True
        except Exception:
            pass

    return True


_ELF_MACHINE_MAP = {
    3:   "i686",     # EM_386
    40:  "arm",      # EM_ARM
    62:  "x86_64",   # EM_X86_64
    183: "aarch64",  # EM_AARCH64
    243: "riscv64",  # EM_RISCV
}


def _elf_arch(path: str) -> str:
    """Return the proot-distro arch name for an ELF binary, or '' on failure."""
    try:
        with open(path, "rb") as fh:
            ident = fh.read(20)
        if len(ident) < 20 or ident[:4] != b"\x7fELF":
            return ""
        fmt = "<H" if ident[5] == 1 else ">H"  # EI_DATA: 1=LE, 2=BE
        e_machine = struct.unpack_from(fmt, ident, 18)[0]
        return _ELF_MACHINE_MAP.get(e_machine, "")
    except OSError:
        return ""


def detect_installed_arch(distro_name: str) -> str:
    """Detect CPU architecture of an installed distro by reading ELF headers."""
    root = os.path.join(INSTALLED_ROOTFS_DIR, distro_name)
    candidates = [
        "/usr/bin/bash", "/usr/bin/sh", "/usr/bin/su", "/usr/bin/busybox",
        "/data/data/com.termux/files/usr/bin/bash",
        "/bin/bash", "/bin/sh", "/bin/su", "/bin/busybox",
    ]
    for rel in candidates:
        arch = _elf_arch(root + rel)
        if arch:
            return arch
    return "unknown"


# ---------------------------------------------------------------------------
# QEMU / CPU emulator helpers
# ---------------------------------------------------------------------------

_QEMU_BINS = {
    "aarch64": f"{PREFIX}/bin/qemu-aarch64",
    "arm":     f"{PREFIX}/bin/qemu-arm",
    "i686":    f"{PREFIX}/bin/qemu-i386",
    "riscv64": f"{PREFIX}/bin/qemu-riscv64",
    "x86_64":  f"{PREFIX}/bin/qemu-x86_64",
}
_BLINK_BIN = f"{PREFIX}/bin/blink"

_QEMU_PKGS = {
    "aarch64": "qemu-user-aarch64",
    "arm":     "qemu-user-arm",
    "i686":    "qemu-user-i386",
    "riscv64": "qemu-user-riscv64",
    "x86_64":  "qemu-user-x86-64",
}


def get_emulator_args(distro_arch: str, device_arch: str) -> list:
    """Return proot -q <emulator> args, or [] if no emulation needed."""
    if distro_arch == device_arch:
        return []

    need_emu = True
    # 64-bit host can run 32-bit guest natively.
    if distro_arch == "arm" and device_arch == "aarch64" and supports_32bit():
        need_emu = False
    if distro_arch == "i686" and device_arch == "x86_64":
        need_emu = False

    if not need_emu:
        return []

    if distro_arch == "x86_64":
        if PROOT_DISTRO_X64_EMULATOR == "BLINK":
            emu_path = _BLINK_BIN
        else:
            emu_path = _QEMU_BINS.get("x86_64", "")
    else:
        emu_path = _QEMU_BINS.get(distro_arch, "")

    if not emu_path:
        msg()
        msg(f"{C['BRED']}Error: DISTRO_ARCH has unknown value '{C['YELLOW']}{distro_arch}{C['BRED']}'. "
            f"Valid values are: aarch64, arm, i686, riscv64, x86_64.{C['RST']}")
        msg()
        sys.exit(1)

    if not os.path.isfile(emu_path) or not os.access(emu_path, os.X_OK):
        if distro_arch == "x86_64" and PROOT_DISTRO_X64_EMULATOR == "BLINK":
            pkg = "blink"
        else:
            pkg = _QEMU_PKGS.get(distro_arch, f"qemu-user-{distro_arch}")
        msg()
        msg(f"{C['BRED']}Error: package '{C['YELLOW']}{pkg}{C['BRED']}' is not installed.{C['RST']}")
        msg()
        sys.exit(1)

    args = ["-q", emu_path]
    # Extra bindings needed for QEMU to locate Android system libraries.
    for path in ("/apex", "/linkerconfig/ld.config.txt",
                 f"{PREFIX}", "/system", "/vendor",
                 "/plat_property_contexts", "/property_contexts"):
        if os.path.exists(path):
            args += [f"--bind={path}"]
    return args
