import os
import shutil
import sys

from proot_distro.constants import INSTALLED_ROOTFS_DIR
from proot_distro.colors import C, msg


def _resolve_copy_path(spec: str) -> str:
    """Resolve a 'dist:path' or plain path to a real host path."""
    if ":" in spec:
        dist, _, rel_path = spec.partition(":")
        rootfs = os.path.join(INSTALLED_ROOTFS_DIR, dist)
        if not os.path.isdir(rootfs):
            msg()
            msg(f"{C['BRED']}Error: distribution '{C['YELLOW']}{dist}{C['BRED']}' is not installed.{C['RST']}")
            msg()
            sys.exit(1)
        return os.path.normpath(os.path.join(rootfs, rel_path.lstrip("/")))
    return os.path.normpath(os.path.abspath(spec))


def command_copy(args, configs: dict) -> None:
    src  = args.source
    dest = args.destination
    verbose = getattr(args, "verbose", False)
    move_mode = getattr(args, "move", False)

    src_path  = _resolve_copy_path(src)
    dest_path = _resolve_copy_path(dest)

    if not os.path.exists(src_path):
        msg()
        msg(f"{C['BRED']}Error: can't copy '{C['YELLOW']}{src}{C['BRED']}' because file does not exist.{C['RST']}")
        msg()
        sys.exit(1)

    msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Source: '{src_path}'{C['RST']}")
    msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Destination: '{dest_path}'{C['RST']}")

    dest_dir = os.path.dirname(dest_path)
    if not os.path.isdir(dest_dir):
        msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Creating directory '{dest_dir}'...{C['RST']}")
        try:
            os.makedirs(dest_dir, exist_ok=True)
        except OSError as exc:
            msg(f"{C['BLUE']}[{C['RED']}!{C['BLUE']}] {C['CYAN']}Failure.{C['RST']}")
            msg()
            msg(f"{C['BRED']}Error: unable to create directory at '{C['YELLOW']}{dest_dir}{C['BRED']}'.{C['RST']}")
            msg()
            sys.exit(1)

    try:
        if move_mode:
            msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Moving files...{C['RST']}")
            shutil.move(src_path, dest_path)
        else:
            msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Copying files, this may take a while...{C['RST']}")
            if verbose:
                msg()
            if os.path.isdir(src_path):
                shutil.copytree(src_path, dest_path, symlinks=True,
                                copy_function=shutil.copy2)
            else:
                shutil.copy2(src_path, dest_path)
            if verbose:
                msg()
    except OSError as exc:
        msg(f"{C['BLUE']}[{C['RED']}!{C['BLUE']}] {C['CYAN']}Failure.{C['RST']}")
        msg()
        if move_mode:
            msg(f"{C['BRED']}Error: unable to move file into '{C['YELLOW']}{dest_path}{C['BRED']}'.{C['RST']}")
        else:
            msg(f"{C['BRED']}Error: unable to copy file into '{C['YELLOW']}{dest_path}{C['BRED']}'.{C['RST']}")
        msg()
        sys.exit(1)

    msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Finished.{C['RST']}")
