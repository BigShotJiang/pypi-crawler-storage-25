import os
import re
import shutil
import stat
import subprocess
import sys
import zipfile

import yaml

from proot_distro.constants import (
    DISTRO_CONFIGS_DIR,
    DOWNLOAD_CACHE_DIR,
    INSTALLED_ROOTFS_DIR,
    PROGRAM_NAME,
    _SAVED_LD_PRELOAD,
)
from proot_distro.colors import C, msg
from proot_distro.config import load_config, _write_yaml, expand_url
from proot_distro.arch import get_device_cpu_arch, get_distro_arch_override
from proot_distro.sysdata import setup_fake_sysdata
from proot_distro.download import sha256_file, download_file
from proot_distro.rootfs import (
    _write_environment,
    _fix_path_in_configs,
    _write_resolv_conf,
    _write_hosts,
    _register_android_ids,
    _run_post_install,
)

_ALIAS_RE = re.compile(r'^[a-z0-9][a-z0-9_.+\-]*$')


def _detect_archive_type(path: str) -> str:
    """Return 'zip' or 'tar' based on file magic bytes."""
    try:
        with open(path, "rb") as fh:
            magic = fh.read(4)
        if magic == b'PK\x03\x04':
            return "zip"
    except OSError:
        pass
    return "tar"


def _extract_zip(archive_path: str, rootfs_dir: str, strip: int, l2s_dir: str) -> None:  # noqa: ARG001
    """Extract a ZIP archive into rootfs_dir, handling symlinks and permissions."""
    with zipfile.ZipFile(archive_path, "r") as zf:
        for info in zf.infolist():
            parts = [p for p in info.filename.split("/") if p]
            if strip:
                if len(parts) <= strip:
                    continue
                parts = parts[strip:]
            if not parts:
                continue
            if parts[0] == "dev":
                continue

            name = "/".join(parts)
            dest = os.path.join(rootfs_dir, name)
            attr = info.external_attr >> 16

            if stat.S_ISLNK(attr):
                target = zf.read(info.filename).decode("utf-8", errors="replace")
                parent = os.path.dirname(dest)
                if parent:
                    os.makedirs(parent, exist_ok=True)
                if os.path.lexists(dest):
                    os.remove(dest)
                os.symlink(target, dest)
                continue

            if info.filename.endswith("/") or stat.S_ISDIR(attr):
                os.makedirs(dest, exist_ok=True)
                continue

            parent = os.path.dirname(dest)
            if parent:
                os.makedirs(parent, exist_ok=True)
            with zf.open(info) as src, open(dest, "wb") as fh:
                shutil.copyfileobj(src, fh)
            if attr:
                mode = stat.S_IMODE(attr)
                if mode:
                    os.chmod(dest, mode)


def _validate_alias(alias: str) -> bool:
    return bool(_ALIAS_RE.match(alias)) and not alias.endswith(".yaml")


def _install_termux_rootfs(archive_path: str, rootfs_dir: str, strip: int) -> None:
    """Handle extraction and setup for type=termux distributions."""
    termux_usr = os.path.join(rootfs_dir, "data", "data", "com.termux", "files", "usr")
    termux_home = os.path.join(rootfs_dir, "data", "data", "com.termux", "files", "home")
    os.makedirs(termux_home, exist_ok=True)
    os.makedirs(termux_usr, exist_ok=True)

    if _detect_archive_type(archive_path) == "zip":
        _extract_zip(archive_path, termux_usr, strip, termux_usr)
    else:
        tar_cmd = [
            "tar", "-C", termux_usr,
            "--warning=no-unknown-keyword",
            "--delay-directory-restore",
            "--preserve-permissions",
        ]
        if strip:
            tar_cmd.append(f"--strip={strip}")
        tar_cmd += ["-xf", archive_path]
        env = os.environ.copy()
        env.pop("LD_PRELOAD", None)
        proc = subprocess.run(tar_cmd, env=env, capture_output=True, text=True)
        for line in proc.stderr.splitlines():
            msg(line)
        if _SAVED_LD_PRELOAD:
            os.environ["LD_PRELOAD"] = _SAVED_LD_PRELOAD

    symlinks_file = os.path.join(termux_usr, "SYMLINKS.txt")
    if os.path.isfile(symlinks_file):
        msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Creating symlinks, please wait...{C['RST']}")
        with open(symlinks_file, encoding="utf-8") as fh:
            for line in fh:
                line = line.rstrip("\n")
                if "\u2190" not in line:
                    continue
                src, dst = line.split("\u2190", 1)
                full_dst = os.path.join(termux_usr, dst.lstrip("/"))
                dst_parent = os.path.dirname(full_dst)
                if dst_parent:
                    os.makedirs(dst_parent, exist_ok=True)
                if os.path.lexists(full_dst):
                    os.remove(full_dst)
                os.symlink(src, full_dst)
        os.remove(symlinks_file)

    bashrc = os.path.join(termux_usr, "etc", "bash.bashrc")
    if os.path.isfile(bashrc):
        msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Updating PS1 in bash.bashrc...{C['RST']}")
        with open(bashrc, "a") as fh:
            fh.write("\n# Added by proot-distro:\n")
            fh.write(r'PS1="\\[\\e[0;35m\\]\\\PD\\\\\[\\e[0m\\] ${PS1}"' + "\n")


def command_install(args, configs: dict) -> None:
    distro_name = args.alias
    override_alias = getattr(args, "override_alias", None)

    if distro_name not in configs:
        msg()
        msg(f"{C['BRED']}Error: unknown distribution '{C['YELLOW']}{distro_name}{C['BRED']}' was requested to be installed.{C['RST']}")
        msg()
        msg(f"{C['CYAN']}View supported distributions by: {C['GREEN']}{PROGRAM_NAME} list{C['RST']}")
        msg()
        sys.exit(1)

    cfg = configs[distro_name]
    install_name = distro_name

    if override_alias:
        if not _validate_alias(override_alias):
            msg()
            msg(f"{C['BRED']}Error: invalid alias '{C['YELLOW']}{override_alias}{C['BRED']}'. "
                f"Must start with alphanumeric and contain only [a-z0-9_.+-].{C['RST']}")
            msg()
            sys.exit(1)
        if os.path.exists(os.path.join(DISTRO_CONFIGS_DIR, override_alias + ".yaml")) \
                or os.path.exists(os.path.join(DISTRO_CONFIGS_DIR, override_alias + ".override.yaml")):
            msg()
            msg(f"{C['BRED']}Error: distribution with alias '{C['YELLOW']}{override_alias}{C['BRED']}' already exists.{C['RST']}")
            msg()
            sys.exit(1)
        # Create override config with the new alias appended to name.
        override_path = os.path.join(DISTRO_CONFIGS_DIR, override_alias + ".override.yaml")
        msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Creating override config '{override_path}'...{C['RST']}")
        with open(cfg.config_path) as fh:
            orig_data = yaml.safe_load(fh)
        orig_data["name"] = f"{cfg.name} - {override_alias}"
        _write_yaml(override_path, orig_data)
        install_name = override_alias
        cfg = load_config(override_path, override_alias)

    rootfs_dir = os.path.join(INSTALLED_ROOTFS_DIR, install_name)
    if os.path.isdir(rootfs_dir):
        msg()
        msg(f"{C['BRED']}Error: distribution '{C['YELLOW']}{install_name}{C['BRED']}' is already installed.{C['RST']}")
        msg()
        msg(f"{C['CYAN']}Log in:     {C['GREEN']}{PROGRAM_NAME} login {install_name}{C['RST']}")
        msg(f"{C['CYAN']}Reinstall:  {C['GREEN']}{PROGRAM_NAME} reset {install_name}{C['RST']}")
        msg(f"{C['CYAN']}Uninstall:  {C['GREEN']}{PROGRAM_NAME} remove {install_name}{C['RST']}")
        msg()
        sys.exit(1)

    # Determine architecture.
    device_arch = get_device_cpu_arch()
    distro_arch = get_distro_arch_override() or device_arch
    arch_entry = next((e for e in cfg.architectures if e.arch == distro_arch), None)
    if arch_entry is None:
        msg(f"{C['BLUE']}[{C['RED']}!{C['BLUE']}] {C['CYAN']}The distribution is not available for CPU architecture '{distro_arch}'.{C['RST']}")
        sys.exit(1)

    # Allow env override of URL/checksum.
    url = os.environ.get("PD_OVERRIDE_TARBALL_URL", "") or expand_url(
        arch_entry.url, cfg.version, distro_arch
    )
    checksum = os.environ.get("PD_OVERRIDE_TARBALL_SHA256", "") or arch_entry.checksum
    if os.environ.get("PD_OVERRIDE_TARBALL_URL"):
        checksum = os.environ.get("PD_OVERRIDE_TARBALL_SHA256", "")

    msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Installing {C['YELLOW']}{cfg.name}{C['CYAN']}...{C['RST']}")

    os.makedirs(rootfs_dir, exist_ok=True)
    l2s_dir = os.path.join(rootfs_dir, ".l2s")
    os.makedirs(l2s_dir, exist_ok=True)

    def _cleanup():
        try:
            shutil.rmtree(rootfs_dir)
        except OSError:
            pass
        if override_alias:
            override_path = os.path.join(DISTRO_CONFIGS_DIR, override_alias + ".override.yaml")
            try:
                os.remove(override_path)
            except OSError:
                pass

    try:
        os.makedirs(DOWNLOAD_CACHE_DIR, exist_ok=True)
        archive_name = os.path.basename(url.split("?")[0])
        archive_path = os.path.join(DOWNLOAD_CACHE_DIR, archive_name)

        if os.path.isfile(archive_path):
            msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Using cached rootfs archive...{C['RST']}")
        else:
            msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Downloading rootfs archive...{C['RST']}")
            msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}URL: {url}{C['RST']}")
            download_file(url, archive_path)

        if checksum:
            msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Verifying rootfs checksum...{C['RST']}")
            actual = sha256_file(archive_path)
            if actual != checksum:
                msg(f"{C['BLUE']}[{C['RED']}!{C['BLUE']}] {C['CYAN']}Verification failure: downloaded file is corrupted.{C['RST']}")
                os.remove(archive_path)
                _cleanup()
                sys.exit(1)
            msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Integrity check passed.{C['RST']}")
        else:
            msg(f"{C['BLUE']}[{C['RED']}!{C['BLUE']}] {C['CYAN']}Integrity checking of downloaded rootfs has been disabled.{C['RST']}")

        msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Extracting rootfs, please wait...{C['RST']}")

        if cfg.distro_type == "termux":
            _install_termux_rootfs(archive_path, rootfs_dir, cfg.tarball_strip)
        else:
            if _detect_archive_type(archive_path) == "zip":
                _extract_zip(archive_path, rootfs_dir, cfg.tarball_strip, l2s_dir)
            else:
                tar_cmd = [
                    "proot", "--link2symlink",
                    "tar", "-C", rootfs_dir,
                    "--warning=no-unknown-keyword",
                    "--delay-directory-restore",
                    "--preserve-permissions",
                ]
                if cfg.tarball_strip:
                    tar_cmd.append(f"--strip={cfg.tarball_strip}")
                tar_cmd += ["-xf", archive_path, "--exclude=dev"]

                env = os.environ.copy()
                env.pop("LD_PRELOAD", None)
                env["PROOT_L2S_DIR"] = l2s_dir

                proc = subprocess.run(tar_cmd, env=env, capture_output=True, text=True)
                # Suppress noisy linkerconfig warnings.
                for line in proc.stderr.splitlines():
                    if "/linkerconfig/" not in line:
                        msg(line)
                if _SAVED_LD_PRELOAD:
                    os.environ["LD_PRELOAD"] = _SAVED_LD_PRELOAD

            if not os.path.isdir(os.path.join(rootfs_dir, "etc")):
                msg()
                msg(f"{C['BRED']}Error: the rootfs of distribution '{C['YELLOW']}{install_name}{C['BRED']}' has unexpected structure "
                    f"(no /etc directory). Make sure that variable TARBALL_STRIP_OPT specified in distribution plug-in is correct.{C['RST']}")
                msg()
                _cleanup()
                sys.exit(1)

            msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Writing file '{rootfs_dir}/etc/environment'...{C['RST']}")
            _write_environment(rootfs_dir)
            _fix_path_in_configs(rootfs_dir)

            msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Creating file '{rootfs_dir}/etc/resolv.conf'...{C['RST']}")
            _write_resolv_conf(rootfs_dir)

            msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Creating file '{rootfs_dir}/etc/hosts'...{C['RST']}")
            _write_hosts(rootfs_dir)

            msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Registering Android-specific UIDs and GIDs...{C['RST']}")
            _register_android_ids(rootfs_dir)

            setup_fake_sysdata(install_name)

        if cfg.post_install_automation.strip():
            msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Running distribution-specific configuration steps...{C['RST']}")
            _run_post_install(install_name, cfg.post_install_automation, distro_arch)

    except Exception:
        _cleanup()
        raise

    msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Finished.{C['RST']}")
    msg()
    msg(f"{C['CYAN']}Log in with: {C['GREEN']}{PROGRAM_NAME} login {install_name}{C['CYAN']}{C['RST']}")
    msg()
