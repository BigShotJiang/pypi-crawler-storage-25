import os
import subprocess
import sys

from proot_distro.constants import DISTRO_CONFIGS_DIR, INSTALLED_ROOTFS_DIR
from proot_distro.colors import C, msg


def command_restore(args, configs: dict) -> None:
    tarball = getattr(args, "tarball", None)

    if tarball:
        if not os.path.exists(tarball):
            msg()
            msg(f"{C['BRED']}Error: file '{C['YELLOW']}{tarball}{C['BRED']}' does not exist.{C['RST']}")
            msg()
            sys.exit(1)
        if os.path.isdir(tarball):
            msg()
            msg(f"{C['BRED']}Error: path '{C['YELLOW']}{tarball}{C['BRED']}' is a directory.{C['RST']}")
            msg()
            sys.exit(1)
    else:
        if sys.stdin.isatty():
            from proot_distro.commands.help import _HELP_COMMANDS
            msg()
            msg(f"{C['BRED']}Error: tarball file path is not specified and it looks like nothing is being piped via stdin either.{C['RST']}")
            _HELP_COMMANDS["restore"]()
            sys.exit(1)

    configs_parent = os.path.dirname(DISTRO_CONFIGS_DIR)
    configs_base   = os.path.basename(DISTRO_CONFIGS_DIR)
    rootfs_parent  = os.path.dirname(INSTALLED_ROOTFS_DIR)
    rootfs_base    = os.path.basename(INSTALLED_ROOTFS_DIR)

    os.makedirs(INSTALLED_ROOTFS_DIR, exist_ok=True)

    msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Extracting distribution plug-in and rootfs from the tarball...{C['RST']}")

    if tarball:
        tar_cmd = ["tar", "-x", "--auto-compress", "--recursive-unlink",
                   "--preserve-permissions",
                   "-f", tarball,
                   "-C", configs_parent, f"{configs_base}/",
                   "-C", rootfs_parent, f"{rootfs_base}/"]
    else:
        tar_cmd = ["tar", "-x", "--recursive-unlink", "--preserve-permissions",
                   "-C", configs_parent, f"{configs_base}/",
                   "-C", rootfs_parent, f"{rootfs_base}/"]

    result = subprocess.run(tar_cmd)
    if result.returncode == 0:
        msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Finished.{C['RST']}")
    else:
        msg(f"{C['BLUE']}[{C['RED']}!{C['BLUE']}] {C['CYAN']}Failure.{C['RST']}")
        msg()
        msg(f"{C['BRED']}Failed to restore distribution from the given tarball.{C['RST']}")
        msg()
        msg(f"{C['BRED']}Possibly that tarball was corrupted or not made by PRoot-Distro. "
            f"Note that tarball piped to stdin must be decompressed.{C['RST']}")
        msg()
        sys.exit(1)
