import os
import re
import shutil
import sys

import yaml

from proot_distro.constants import DISTRO_CONFIGS_DIR, INSTALLED_ROOTFS_DIR
from proot_distro.colors import C, msg
from proot_distro.config import _write_yaml
from proot_distro.commands.install import _validate_alias


def command_rename(args, configs: dict) -> None:
    orig = args.orig_alias
    new  = args.new_alias

    if orig == new:
        msg()
        msg(f"{C['BRED']}Error: original and new aliases must differ.{C['RST']}")
        msg()
        sys.exit(1)

    if not _validate_alias(new):
        msg()
        msg(f"{C['BRED']}Error: invalid new alias '{C['YELLOW']}{new}{C['BRED']}'. "
            f"Must start with alphanumeric and contain only [a-z0-9_.+-].{C['RST']}")
        msg()
        sys.exit(1)

    if orig not in configs:
        msg()
        msg(f"{C['BRED']}Error: unknown distribution '{C['YELLOW']}{orig}{C['BRED']}' was requested to be renamed.{C['RST']}")
        msg()
        sys.exit(1)

    orig_rootfs = os.path.join(INSTALLED_ROOTFS_DIR, orig)
    new_rootfs  = os.path.join(INSTALLED_ROOTFS_DIR, new)

    if not os.path.isdir(orig_rootfs):
        msg()
        msg(f"{C['BRED']}Error: distribution '{C['YELLOW']}{orig}{C['BRED']}' is not installed.{C['RST']}")
        msg()
        sys.exit(1)

    if os.path.isdir(new_rootfs):
        msg()
        msg(f"{C['BRED']}Error: rootfs directory for '{C['YELLOW']}{new}{C['BRED']}' already exists.{C['RST']}")
        msg()
        sys.exit(1)

    if new in configs:
        msg()
        msg(f"{C['BRED']}Error: distribution with alias '{C['YELLOW']}{new}{C['BRED']}' already exists.{C['RST']}")
        msg()
        sys.exit(1)

    orig_cfg = configs[orig]
    new_override = os.path.join(DISTRO_CONFIGS_DIR, new + ".override.yaml")

    if orig_cfg.config_path.endswith(".override.yaml"):
        # Rename the override file directly.
        msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Renaming '{orig_cfg.config_path}' to '{new_override}'...{C['RST']}")
        shutil.copy2(orig_cfg.config_path, new_override)
        # Update name field in the new file.
        with open(new_override) as fh:
            data = yaml.safe_load(fh)
        old_name = data.get("name", orig)
        data["name"] = re.sub(rf" - {re.escape(orig)}$", f" - {new}", old_name)
        _write_yaml(new_override, data)
        os.remove(orig_cfg.config_path)
    else:
        # Package-managed .yaml — create a new override copy.
        msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Creating override config '{new_override}'...{C['RST']}")
        with open(orig_cfg.config_path) as fh:
            data = yaml.safe_load(fh)
        data["name"] = f"{orig_cfg.name} - {new}"
        _write_yaml(new_override, data)

    msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Renaming '{orig_rootfs}' to '{new_rootfs}'...{C['RST']}")
    os.rename(orig_rootfs, new_rootfs)

    # Update proot link2symlink (l2s) symlinks that point into the old rootfs path.
    msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Updating PRoot link2symlink extension files (may take long time)...{C['RST']}")
    for dirpath, _dirs, filenames in os.walk(new_rootfs):
        for fname in filenames:
            fpath = os.path.join(dirpath, fname)
            try:
                if os.path.islink(fpath):
                    target = os.readlink(fpath)
                    if target.startswith(orig_rootfs):
                        new_target = new_rootfs + target[len(orig_rootfs):]
                        os.unlink(fpath)
                        os.symlink(new_target, fpath)
            except OSError:
                pass

    msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Finished.{C['RST']}")
