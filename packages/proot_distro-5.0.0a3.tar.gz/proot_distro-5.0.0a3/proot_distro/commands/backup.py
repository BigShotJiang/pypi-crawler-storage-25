import io
import os
import stat
import sys
import tarfile
from concurrent.futures import ThreadPoolExecutor, as_completed

from proot_distro.constants import INSTALLED_ROOTFS_DIR, DISTRO_CONFIGS_DIR, PROGRAM_NAME
from proot_distro.colors import C, msg
from proot_distro.commands.help import _HELP_COMMANDS


# Maps file-extension suffixes to tarfile compression identifiers.
_COMPRESS_EXTS = (
    ('.tar.gz',   'gz'),
    ('.tgz',      'gz'),
    ('.tar.bz2',  'bz2'),
    ('.tbz2',     'bz2'),
    ('.tar.xz',   'xz'),
    ('.txz',      'xz'),
    ('.tar',      ''),
)

# Extensions that look like compression requests but are not supported.
_UNSUPPORTED_EXTS = ('.tar.zst', '.tzst', '.tar.lz4', '.tar.lz', '.tar.lzma', '.tlzma')

# Regular files up to this size are pre-read into memory by worker threads.
# Larger files are streamed from disk in the main writer thread.
_BUFFER_THRESHOLD = 4 << 20  # 4 MiB


def _compression_mode(filename: str) -> str:
    """Return the tarfile compression suffix for *filename*'s extension.

    Raises ValueError for recognised-but-unsupported formats.
    Falls back to uncompressed ('') for unknown extensions.
    """
    low = filename.lower()
    for ext, comp in _COMPRESS_EXTS:
        if low.endswith(ext):
            return comp
    for ext in _UNSUPPORTED_EXTS:
        if low.endswith(ext):
            raise ValueError(f"Compression format '{ext}' is not supported.")
    return ''


def _iter_entries(root: str, arcroot: str):
    """Yield *(src_path, arcname)* for every entry under *root*.

    Symlinks to subdirectories are yielded as single entries; os.walk is
    prevented from descending into them.  All sibling entries are sorted.
    """
    for dirpath, dirnames, filenames in os.walk(root, followlinks=False, topdown=True):
        rel = os.path.relpath(dirpath, root)
        arc_dir = arcroot if rel == '.' else os.path.join(arcroot, rel)

        yield (dirpath, arc_dir)

        i = 0
        while i < len(dirnames):
            d = dirnames[i]
            if os.path.islink(os.path.join(dirpath, d)):
                yield (os.path.join(dirpath, d), os.path.join(arc_dir, d))
                dirnames.pop(i)
            else:
                i += 1

        dirnames.sort()

        for fname in sorted(filenames):
            yield (os.path.join(dirpath, fname), os.path.join(arc_dir, fname))


def _prepare_entry(src: str, arcname: str):
    """Read a filesystem entry for archiving.  Thread-safe.

    Returns *(TarInfo, data, stream_src)* where:

    * *data* is ``bytes`` for small regular files (read into memory),
    * *stream_src* is the source path for large regular files (written
      sequentially in the main thread to avoid buffering),
    * both are ``None`` for directories and symlinks.

    Returns ``None`` if the entry should be skipped (special files, errors).
    """
    try:
        st = os.lstat(src)
    except OSError:
        return None
    m = st.st_mode
    if stat.S_ISBLK(m) or stat.S_ISCHR(m) or stat.S_ISFIFO(m) or stat.S_ISSOCK(m):
        return None

    info = tarfile.TarInfo(name=arcname)
    info.mode = stat.S_IMODE(m)
    info.mtime = st.st_mtime
    info.uid = 0
    info.gid = 0
    info.uname = ''
    info.gname = ''

    if stat.S_ISREG(m):
        info.type = tarfile.REGTYPE
        if st.st_size <= _BUFFER_THRESHOLD:
            try:
                with open(src, 'rb') as fh:
                    data = fh.read()
            except OSError:
                return None
            info.size = len(data)
            return (info, data, None)
        else:
            info.size = st.st_size
            return (info, None, src)   # stream in main thread
    elif stat.S_ISLNK(m):
        info.type = tarfile.SYMTYPE
        try:
            info.linkname = os.readlink(src)
        except OSError:
            return None
        info.size = 0
        return (info, None, None)
    elif stat.S_ISDIR(m):
        info.type = tarfile.DIRTYPE
        if not info.name.endswith('/'):
            info.name += '/'
        info.size = 0
        return (info, None, None)
    return None


def _write_entry(tf: tarfile.TarFile, prepared) -> None:
    """Write a prepared entry returned by *_prepare_entry* into *tf*."""
    if prepared is None:
        return
    info, data, stream_src = prepared
    if data is not None:
        tf.addfile(info, io.BytesIO(data))
    elif stream_src is not None:
        try:
            with open(stream_src, 'rb') as fh:
                tf.addfile(info, fh)
        except OSError:
            pass
    else:
        tf.addfile(info)   # directory or symlink


def command_backup(args, configs: dict) -> None:
    distro_name = args.alias
    output_path = getattr(args, "output", None)

    if distro_name not in configs:
        msg()
        msg(f"{C['BRED']}Error: unknown distribution '{C['YELLOW']}{distro_name}{C['BRED']}' was requested for backup.{C['RST']}")
        msg()
        msg(f"{C['CYAN']}View supported distributions by: {C['GREEN']}{PROGRAM_NAME} list{C['RST']}")
        msg()
        sys.exit(1)

    rootfs_dir = os.path.join(INSTALLED_ROOTFS_DIR, distro_name)
    if not os.path.isdir(rootfs_dir):
        msg()
        msg(f"{C['BRED']}Error: distribution '{C['YELLOW']}{distro_name}{C['BRED']}' is not installed.{C['RST']}")
        msg()
        msg(f"{C['CYAN']}You can install it by: {C['GREEN']}{PROGRAM_NAME} install {distro_name}{C['RST']}")
        msg()
        sys.exit(1)

    cfg = configs[distro_name]
    config_file = cfg.config_path

    if output_path:
        if os.path.isdir(output_path):
            msg()
            msg(f"{C['BRED']}Error: cannot write to '{C['YELLOW']}{output_path}{C['BRED']}' because this path is a directory.{C['RST']}")
            _HELP_COMMANDS["backup"]()
            sys.exit(1)
        if os.path.isfile(output_path):
            msg()
            msg(f"{C['BRED']}Error: file '{C['YELLOW']}{output_path}{C['BRED']}' already exists. Please specify a different name.{C['RST']}")
            _HELP_COMMANDS["backup"]()
            sys.exit(1)
        try:
            compression = _compression_mode(output_path)
        except ValueError as exc:
            msg()
            msg(f"{C['BRED']}Error: {exc}{C['RST']}")
            msg()
            sys.exit(1)
        msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Tarball will be written to '{output_path}'.{C['RST']}")
    else:
        if sys.stdout.isatty():
            msg()
            msg(f"{C['BRED']}Error: tarball cannot be printed to console. Please use option '{C['YELLOW']}--output{C['BRED']}' to specify a file or pipe the output to another command.{C['RST']}")
            msg()
            sys.exit(1)
        compression = ''
        msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Tarball will be written to stdout.{C['RST']}")

    msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Backing up {C['YELLOW']}{cfg.name}{C['CYAN']}...{C['RST']}")

    msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Fixing file permissions in rootfs...{C['RST']}")

    def _fix_dir(dirpath: str, files: list) -> None:
        try:
            os.chmod(dirpath, os.stat(dirpath).st_mode | stat.S_IRUSR | stat.S_IXUSR)
        except OSError:
            pass
        for fname in files:
            fpath = os.path.join(dirpath, fname)
            try:
                fstat = os.lstat(fpath)
                if stat.S_ISREG(fstat.st_mode):
                    mode = fstat.st_mode
                    if mode & (stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH):
                        os.chmod(fpath, mode | stat.S_IRUSR | stat.S_IXUSR)
                    else:
                        os.chmod(fpath, mode | stat.S_IRUSR)
            except OSError:
                pass

    with ThreadPoolExecutor() as pool:
        futures = [
            pool.submit(_fix_dir, dirpath, files)
            for dirpath, _dirs, files in os.walk(rootfs_dir)
        ]
        for fut in as_completed(futures):
            fut.result()

    if not os.path.isfile(config_file):
        msg()
        msg(f"{C['BRED']}Error: config file '{C['YELLOW']}{config_file}{C['BRED']}' does not exist.{C['RST']}")
        msg()
        sys.exit(1)

    configs_base = os.path.basename(DISTRO_CONFIGS_DIR)    # proot-distro
    rootfs_base  = os.path.basename(INSTALLED_ROOTFS_DIR)  # installed-rootfs

    config_rel = os.path.join(configs_base, os.path.basename(config_file))
    rootfs_rel = os.path.join(rootfs_base, distro_name)

    msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Archiving the rootfs and plug-in...{C['RST']}")

    # Collect all rootfs entries up front: gives us the total for the progress
    # bar and lets us submit parallel reads before writing begins.
    rootfs_entries = list(_iter_entries(rootfs_dir, rootfs_rel))
    total_entries  = 1 + len(rootfs_entries)   # +1 for the config file
    done = 0
    use_tty = sys.stderr.isatty()

    def _on_entry() -> None:
        nonlocal done
        done += 1
        if not use_tty:
            return
        pfx = f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}"
        pct = done * 100 // total_entries if total_entries else 100
        bar = "#" * (pct // 5) + "-" * (20 - pct // 5)
        sys.stderr.write(
            f"\r{pfx}[{bar}] {pct:3d}%  {done} / {total_entries} files{C['RST']}")
        sys.stderr.flush()

    try:
        tar_mode = (f'w:{compression}' if compression else 'w:') if output_path else 'w|'
        tar_target = output_path if output_path else sys.stdout.buffer

        with tarfile.open(tar_target if output_path else None,
                          fileobj=None if output_path else tar_target,
                          mode=tar_mode) as tf:
            # Config file — prepared and written in the main thread (single file).
            _write_entry(tf, _prepare_entry(config_file, config_rel))
            _on_entry()

            # Rootfs — reads are parallelised; writes happen in submission order.
            with ThreadPoolExecutor() as executor:
                futures = [
                    executor.submit(_prepare_entry, src, arc)
                    for src, arc in rootfs_entries
                ]
                for fut in futures:          # iterate in submission order
                    _write_entry(tf, fut.result())
                    _on_entry()

        if use_tty:
            sys.stderr.write("\r\033[K")
            sys.stderr.flush()
        msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Finished backing up.{C['RST']}")

    except (OSError, tarfile.TarError) as exc:
        if use_tty:
            sys.stderr.write("\r\033[K")
            sys.stderr.flush()
        msg(f"{C['BLUE']}[{C['RED']}!{C['BLUE']}] {C['CYAN']}Failed to create archive: {exc}{C['RST']}")
        if output_path:
            try:
                os.remove(output_path)
            except OSError:
                pass
        sys.exit(1)
