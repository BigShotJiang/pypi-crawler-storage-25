import os
import shutil
import stat
import sys

from proot_distro.constants import DISTRO_CONFIGS_DIR, INSTALLED_ROOTFS_DIR, PROGRAM_NAME
from proot_distro.colors import C, msg


def command_remove(args, configs: dict) -> None:
    distro_name = args.alias
    reset_mode = getattr(args, "_reset_mode", False)

    if distro_name not in configs:
        msg()
        msg(f"{C['BRED']}Error: unknown distribution '{C['YELLOW']}{distro_name}{C['BRED']}' was requested to be removed.{C['RST']}")
        msg()
        msg(f"{C['CYAN']}View supported distributions by: {C['GREEN']}{PROGRAM_NAME} list{C['RST']}")
        msg()
        sys.exit(1)

    rootfs_dir = os.path.join(INSTALLED_ROOTFS_DIR, distro_name)
    if not os.path.isdir(rootfs_dir):
        msg()
        msg(f"{C['BRED']}Error: distribution '{C['YELLOW']}{distro_name}{C['BRED']}' is not installed.{C['RST']}")
        msg()
        sys.exit(1)

    if not reset_mode:
        override_cfg = os.path.join(DISTRO_CONFIGS_DIR, distro_name + ".override.yaml")
        if os.path.isfile(override_cfg):
            msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Deleting file '{override_cfg}'...{C['RST']}")
            os.remove(override_cfg)

    msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Wiping the rootfs of {C['YELLOW']}{configs[distro_name].name}{C['CYAN']}...{C['RST']}")
    # Restore permissions to ensure removal succeeds.
    try:
        for dirpath, dirnames, filenames in os.walk(rootfs_dir):
            os.chmod(dirpath, stat.S_IRWXU | stat.S_IRGRP | stat.S_IXGRP | stat.S_IROTH | stat.S_IXOTH)
    except OSError:
        pass

    try:
        shutil.rmtree(rootfs_dir)
        msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Finished.{C['RST']}")
    except OSError as exc:
        msg(f"{C['BLUE']}[{C['RED']}!{C['BLUE']}] {C['CYAN']}Finished with errors. Some files probably were not deleted.{C['RST']}")
        sys.exit(1)
