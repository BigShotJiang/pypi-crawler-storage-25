import os
import sys

from proot_distro.constants import DOWNLOAD_CACHE_DIR
from proot_distro.colors import C, msg


def command_clear_cache(args, configs: dict) -> None:
    if not os.path.isdir(DOWNLOAD_CACHE_DIR):
        msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Download cache is empty.{C['RST']}")
        msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Finished.{C['RST']}")
        return

    cached_files = [
        os.path.join(DOWNLOAD_CACHE_DIR, f)
        for f in os.listdir(DOWNLOAD_CACHE_DIR)
        if os.path.isfile(os.path.join(DOWNLOAD_CACHE_DIR, f))
    ]

    if not cached_files:
        msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Download cache is empty.{C['RST']}")
        msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Finished.{C['RST']}")
        return

    total = sum(os.path.getsize(f) for f in cached_files)
    total_str = f"{total // (1024*1024)} MiB" if total >= 1024*1024 else f"{total // 1024} KiB"

    msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Clearing cache files...{C['RST']}")
    for fpath in cached_files:
        msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Deleting '{fpath}'{C['RST']}")
        os.remove(fpath)

    msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Reclaimed {total_str} of disk space.{C['RST']}")
    msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Finished.{C['RST']}")
