import os
import sys

from proot_distro.constants import PROGRAM_VERSION


_RST    = "\033[0m"
_BOLD   = "\033[1m"
_ITALIC = "\033[3m"
_RED    = "\033[31m"
_GREEN  = "\033[32m"
_YELLOW = "\033[33m"
_BLUE   = "\033[34m"
_CYAN   = "\033[36m"

_COLORS = {
    "RST":     _RST,
    "RED":     _RST + _RED,
    "BRED":    _RST + _BOLD + _RED,
    "GREEN":   _RST + _GREEN,
    "YELLOW":  _RST + _YELLOW,
    "BYELLOW": _RST + _BOLD + _YELLOW,
    "BLUE":    _RST + _BLUE,
    "CYAN":    _RST + _CYAN,
    "BCYAN":   _RST + _BOLD + _CYAN,
    "ICYAN":   _RST + _ITALIC + _CYAN,
}
_EMPTY = {k: "" for k in _COLORS}


def _init_colors() -> dict:
    if sys.stderr.isatty() and not os.environ.get("PROOT_DISTRO_FORCE_NO_COLORS"):
        return _COLORS
    return _EMPTY


C = _init_colors()


def msg(*args):
    print(*args, file=sys.stderr)


def show_version():
    msg(f"{C['ICYAN']}Proot-Distro v{PROGRAM_VERSION} by Termux (@sylirre).{C['RST']}")
