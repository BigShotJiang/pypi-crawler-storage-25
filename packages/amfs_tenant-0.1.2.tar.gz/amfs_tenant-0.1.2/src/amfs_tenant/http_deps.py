"""Pro scope enforcement for the AMFS HTTP API.

When mounted via ``mount_scope_enforcement(app)``, this module:

1. Adds middleware that resolves ``TenantContext`` from API-key headers
   and enforces entity-path scope permissions on all API routes.
2. Overrides the OSS ``verify_api_key`` dependency so that
   Pro-authenticated requests pass through without hitting the
   simple OSS auth layer.

OSS behaviour is unchanged when this package is not installed.
"""

from __future__ import annotations

import json
import logging
import os
import re

import psycopg
from psycopg.rows import dict_row
from fastapi import FastAPI, Request, Security
from fastapi.security import APIKeyHeader
from starlette.responses import JSONResponse

from amfs_tenant.models import KeyType, Permission, TenantContext
from amfs_tenant.rate_limit import RateLimitExceeded, RateLimiter
from amfs_tenant.repository import authenticate_api_key, set_tenant_context
from amfs_tenant.scopes import check_permission

logger = logging.getLogger(__name__)

_API_KEY_HEADER_NAME = "X-AMFS-API-Key"

# ---------------------------------------------------------------------------
# Route → (permission, entity-path-source) mapping
#
# entity-path-source tells the middleware where to find the entity_path:
#   "path"  — captured from the URL via a named regex group
#   "query" — from the ``entity_path`` query parameter
#   "body"  — from the JSON request body's ``entity_path`` field
# ---------------------------------------------------------------------------

_SCOPE_RULES: list[tuple[str, str, Permission, str]] = [
    ("GET",  r"^/api/v1/entries/(?P<entity_path>.+)/[^/]+$", Permission.READ,  "path"),
    ("GET",  r"^/api/v1/entries/?$",                         Permission.READ,  "query"),
    ("POST", r"^/api/v1/entries/?$",                         Permission.WRITE, "body"),
    ("POST", r"^/api/v1/search/?$",                          Permission.READ,  "body"),
    ("POST", r"^/api/v1/outcomes/?$",                        Permission.WRITE, "body"),
    ("GET",  r"^/api/v1/history/(?P<entity_path>.+)/[^/]+$", Permission.READ,  "path"),
]


def mount_scope_enforcement(app: FastAPI) -> None:
    """Wire Pro scope enforcement into the AMFS HTTP API.

    1. Adds HTTP middleware that authenticates via the ``amfs_tenant``
       IAM system and checks entity-path scopes per route.
    2. Overrides the OSS ``verify_api_key`` FastAPI dependency so that
       requests already authenticated by the middleware are not
       rejected by the simpler OSS auth check.
    """

    dsn = os.environ.get("AMFS_POSTGRES_DSN")
    if not dsn:
        logger.warning(
            "AMFS_POSTGRES_DSN not set — Pro scope enforcement skipped"
        )
        return

    _rate_limiter = RateLimiter()

    # ------------------------------------------------------------------
    # Key-type route restrictions
    # ------------------------------------------------------------------

    _ADMIN_ROUTE_PREFIX = "/api/v1/admin"
    _INGESTION_WRITE_PREFIXES = (
        "/api/v1/entries",
        "/api/v1/events",
        "/api/v1/record-context",
    )

    def _check_key_type(ctx: TenantContext, method: str, path: str) -> str | None:
        """Return an error message if the key type forbids this route, else None."""
        kt = ctx.key_type
        if kt is None or kt == KeyType.ADMIN:
            return None

        if kt == KeyType.READONLY and method in ("POST", "PUT", "PATCH", "DELETE"):
            return "Read-only API keys cannot perform write operations"

        if kt == KeyType.INGESTION:
            if path.startswith(_ADMIN_ROUTE_PREFIX):
                return "Ingestion API keys cannot access admin routes"
            if method in ("POST", "PUT", "PATCH", "DELETE"):
                if not any(path.startswith(p) for p in _INGESTION_WRITE_PREFIXES):
                    return (
                        "Ingestion API keys can only write to "
                        "entries, events, and record-context"
                    )

        if kt == KeyType.AGENT and path.startswith(_ADMIN_ROUTE_PREFIX):
            return "Agent API keys cannot access admin routes"

        return None

    # ------------------------------------------------------------------
    # 0. OSS key fallback — keys created via the OSS admin endpoint live
    #    in amfs_api_keys (SHA-256 hash). We build a TenantContext from
    #    them so whoami / rate-limiting / scopes still work.
    # ------------------------------------------------------------------

    def _try_oss_key(
        conn: psycopg.Connection, raw_key: str
    ) -> TenantContext | None:
        import hashlib

        key_hash = hashlib.sha256(raw_key.encode()).hexdigest()

        # Use SECURITY DEFINER function to bypass FORCE RLS.
        auth_row = conn.cursor(row_factory=dict_row).execute(
            "SELECT * FROM amfs_authenticate_api_key(%s)",
            (key_hash,),
        ).fetchone()
        if auth_row is None:
            return None

        key_id = auth_row["key_id"]
        account_id = auth_row["key_account_id"]

        # Touch last_used via SECURITY DEFINER function.
        conn.cursor().execute(
            "SELECT amfs_touch_api_key_usage(%s)", (key_id,)
        )

        # Set tenant context so RLS allows reading key metadata.
        conn.cursor().execute(
            "SELECT set_config('amfs.current_account_id', %s, true)",
            (str(account_id),),
        )
        row = conn.cursor(row_factory=dict_row).execute(
            """SELECT key_type, scopes, rate_limit_rpm
               FROM amfs_api_keys WHERE id = %s""",
            (key_id,),
        ).fetchone()

        scopes_raw = (row.get("scopes") if row else None) or []
        if isinstance(scopes_raw, str):
            scopes_raw = json.loads(scopes_raw)
        from amfs_tenant.models import APIKeyScope, Permission as ScopePerm

        scopes = []
        for s in scopes_raw:
            if isinstance(s, dict):
                pattern = s.get("entity_path_pattern") or s.get("pattern")
                if pattern:
                    scopes.append(APIKeyScope(
                        api_key_id=key_id,
                        entity_path_pattern=pattern,
                        permission=ScopePerm(s.get("permission", "read")),
                    ))
        kt = KeyType.AGENT
        try:
            kt = KeyType((row.get("key_type") if row else None) or "agent")
        except ValueError:
            pass
        from amfs_tenant.models import ActorType

        return TenantContext(
            account_id=account_id,
            actor_id=key_id,
            actor_type=ActorType.API_KEY,
            key_type=kt,
            scopes=scopes,
            rate_limit_rpm=(row.get("rate_limit_rpm") if row else None) or 60,
        )

    # ------------------------------------------------------------------
    # 1. Middleware: authenticate + enforce scopes + rate limit
    # ------------------------------------------------------------------

    @app.middleware("http")
    async def _pro_scope_middleware(request: Request, call_next):  # noqa: C901
        if not request.url.path.startswith("/api/"):
            return await call_next(request)

        api_key = request.headers.get(_API_KEY_HEADER_NAME)
        if not api_key:
            return await call_next(request)

        # --- resolve tenant ---
        # Resolve inside a tight `with` block so the DB connection is
        # released BEFORE call_next runs the handler.  Holding the conn
        # open across the full request lifetime causes lock contention
        # when DDL (e.g. ALTER TABLE) runs on the same tables.
        ctx: TenantContext | None = None
        key_team_id = None
        try:
            with psycopg.connect(dsn, row_factory=dict_row) as conn:
                ctx = authenticate_api_key(conn, api_key)
                if ctx is None:
                    ctx = _try_oss_key(conn, api_key)
                if ctx is not None:
                    set_tenant_context(conn, ctx.account_id, is_admin=False)
        except Exception:
            logger.exception("Pro tenant resolution failed — rejecting request to prevent unscoped data access")
            return JSONResponse(
                {"detail": "Service temporarily unavailable — tenant resolution failed"},
                status_code=503,
            )

        if ctx is None:
            return await call_next(request)

        request.state.tenant_ctx = ctx
        request.state.account_id = ctx.account_id

        # Resolve owner_user_id and team_id from the API key.
        # Check the Pro table first, then fall back to the OSS table
        # (keys created via the dashboard admin endpoint).
        try:
            with psycopg.connect(dsn, row_factory=dict_row) as conn:
                conn.execute(
                    "SELECT set_config('amfs.current_account_id', %s, true)",
                    (str(ctx.account_id),),
                )
                user_row = conn.execute(
                    "SELECT created_by, team_id FROM api_keys WHERE id = %s",
                    (str(ctx.actor_id),),
                ).fetchone()
                if user_row:
                    request.state.user_id = user_row["created_by"]
                    key_team_id = user_row.get("team_id")
                else:
                    oss_row = conn.execute(
                        "SELECT created_by FROM amfs_api_keys WHERE id = %s",
                        (str(ctx.actor_id),),
                    ).fetchone()
                    if oss_row and oss_row.get("created_by"):
                        from uuid import UUID as _UUID
                        _cb = oss_row["created_by"]
                        request.state.user_id = (
                            _UUID(_cb) if isinstance(_cb, str) else _cb
                        )
        except Exception:
            logger.debug("Could not resolve user_id from API key", exc_info=True)

        # Dashboard proxy: override user_id with the actual dashboard user
        # when the proxy secret is valid. This ensures per-user context for
        # rooms, negotiations, and other user-scoped features.
        _dashboard_secret = request.headers.get("x-amfs-dashboard-secret")
        _dashboard_user_id = request.headers.get("x-amfs-dashboard-user-id")
        if _dashboard_secret and _dashboard_user_id:
            _expected_secret = os.environ.get("AMFS_DASHBOARD_PROXY_SECRET", "")
            if _expected_secret and _dashboard_secret == _expected_secret:
                try:
                    from uuid import UUID as _UUID
                    request.state.user_id = _UUID(_dashboard_user_id)
                except (ValueError, AttributeError):
                    logger.debug("Invalid X-AMFS-Dashboard-User-Id: %s", _dashboard_user_id)

        # --- visibility filter ---
        # Uses the rooms package pool (set by mount_rooms before this middleware).
        user_id = getattr(request.state, "user_id", None)
        if user_id is not None:
            try:
                from amfs_rooms.visibility import UserVisibilityFilter
                from amfs_rooms import get_db_pool as _rooms_pool
                _pool = _rooms_pool()
                if _pool is not None:
                    request.state.visibility_filter = UserVisibilityFilter(
                        user_id=user_id,
                        pool=_pool,
                        is_admin=ctx.is_admin,
                    )
            except ImportError:
                pass
            except Exception:
                logger.debug("Could not create visibility filter", exc_info=True)

        # --- rate limiting ---
        try:
            _rate_limiter.check(ctx)
        except RateLimitExceeded as exc:
            headers = _rate_limiter.response_headers(ctx)
            headers["Retry-After"] = str(int(exc.retry_after) + 1)
            return JSONResponse(
                {"detail": str(exc)},
                status_code=429,
                headers=headers,
            )

        # --- key-type enforcement ---
        method = request.method
        path = request.url.path

        type_err = _check_key_type(ctx, method, path)
        if type_err:
            return JSONResponse({"detail": type_err}, status_code=403)

        # --- check entity-path scopes ---
        for rule_method, pattern, permission, source in _SCOPE_RULES:
            if method != rule_method:
                continue
            match = re.match(pattern, path)
            if not match:
                continue

            entity_path: str | None = None

            if source == "path":
                entity_path = match.group("entity_path")
            elif source == "query":
                entity_path = request.query_params.get("entity_path")
            elif source == "body":
                try:
                    body = await request.body()
                    data = json.loads(body)
                    entity_path = data.get("entity_path")
                except Exception:
                    pass

            if entity_path and not check_permission(ctx, entity_path, permission):
                return JSONResponse(
                    {
                        "detail": (
                            f"Scope denied: API key cannot "
                            f"{permission.value} '{entity_path}'"
                        ),
                    },
                    status_code=403,
                )
            break

        # --- propagate tenant to the handler's DB pool ---
        # The OSS PostgresAdapter pool wrapper reads thread-locals to
        # set GUCs on each connection checkout.
        _clear_tls_fns: list = []
        try:
            from amfs_postgres.tenant_context import (
                set_tls_tenant_account_id,
                set_tls_tenant_team_id,
                set_tls_is_account_admin,
                clear_tls_tenant_account_id,
                clear_tls_tenant_team_id,
                clear_tls_is_account_admin,
            )
            set_tls_tenant_account_id(str(ctx.account_id))
            set_tls_tenant_team_id(str(key_team_id) if key_team_id else None)
            set_tls_is_account_admin(False)
            _clear_tls_fns = [clear_tls_tenant_account_id, clear_tls_tenant_team_id, clear_tls_is_account_admin]
        except ImportError:
            pass

        try:
            response = await call_next(request)
        finally:
            for fn in _clear_tls_fns:
                fn()

        rl_headers = _rate_limiter.response_headers(ctx)
        for hdr, val in rl_headers.items():
            response.headers[hdr] = val

        return response

    # ------------------------------------------------------------------
    # 2. Override OSS verify_api_key
    # ------------------------------------------------------------------

    from amfs_http.auth import verify_api_key as _oss_verify

    _header_dep = APIKeyHeader(name=_API_KEY_HEADER_NAME, auto_error=False)

    async def _pro_verify_api_key(
        request: Request,
        api_key: str | None = Security(_header_dep),
    ) -> str | None:
        if getattr(request.state, "tenant_ctx", None) is not None:
            return api_key
        return await _oss_verify(api_key)

    app.dependency_overrides[_oss_verify] = _pro_verify_api_key

    logger.info("Pro scope enforcement enabled (middleware + dependency override)")
