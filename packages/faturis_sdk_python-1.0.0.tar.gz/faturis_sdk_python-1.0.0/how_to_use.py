import os
from dotenv import load_dotenv
from faturis.client import FaturisClient

load_dotenv()

client_id = os.getenv("CLIENT_ID")
client_secret = os.getenv("CLIENT_SECRET")
base_url = os.getenv("BASE_URL")
token_url = os.getenv("TOKEN_URL")
keycloak_url = os.getenv("KEYCLOAK_URL")
keycloak_realm = os.getenv("KEYCLOAK_REALM")

if not client_id or not client_secret or not base_url:
    raise SystemExit(
        "Missing CLIENT_ID, CLIENT_SECRET, or BASE_URL in environment (.env)."
    )

client = FaturisClient(
    client_id,
    client_secret,
    base_url,
    token_url=token_url if token_url else None,
    keycloak_url=keycloak_url if keycloak_url else None,
    realm=keycloak_realm if keycloak_realm else None,
)


if __name__ == "__main__":
    # Series — GET /v1/series/ (optional: document_type, status, year, skip, limit)
    #print(client.series.list(limit=50))

    # Invoices — GET /v1/invoices/ (optional: document_type, document_status, …)
    print(client.invoices.list(page_size=10, page=1))

    # POST /v1/invoices/ — criar lote (corpo em camelCase, como na API / AGT)

    create_invoice_payload = {
        "numberOfEntries": 1,
        "submissionTimeStamp": "2025-11-04T14:30:00Z",
        "documents": [
            {
                "companyName": "Consumidor Final",
                "documentDate": "2025-11-04",
                "documentNo": "FT 2025/0001",
                "documentStatus": "N",
                "documentTotals": {
                    "grossTotal": 570,
                    "netTotal": 500,
                    "taxPayable": 70,
                },
                "documentType": "FT",
                "lines": [
                    {
                        "lineNumber": 1,
                        "productCode": "ARROZ01",
                        "productDescription": "Arroz 1Kg",
                        "quantity": 2,
                        "unitPrice": 250,
                        "creditAmount": 500,
                        "settlementAmount": 0,
                        "taxes": [
                            {
                                "taxType": "IVA",
                                "taxCode": "NOR",
                                "taxPercentage": 14,
                                "taxContribution": 70,
                            }
                        ],
                    }
                ],
                "systemEntryDate": "2025-11-04T14:30:00Z",
            }
        ],
    }
    # Descomenta para submeter o lote (ajusta TENANT_ID, datas e número do documento).
    #print(client.invoices.create(create_invoice_payload))

    # Same query filters apply to list_persisted / list_agt (backend may return stubs).
    # print(client.invoices.list_persisted(page_size=5))
    # print(client.invoices.list_agt(page_size=5))

    # GET /v1/invoices/status/{request_id}
    # print(client.invoices.get_status("YOUR_REQUEST_ID"))
    # print(
    #     client.invoices.get_status(
    #         "YOUR_REQUEST_ID",
    #         submission_uuid="...",
    #         tax_registration_number="5001636863",
    #     )
    # )

    # print(client.invoices.consult({...}))
    # print(client.invoices.validate_document({...}))
    # print(client.series.create({...}))
