# Publicar o `faturis-sdk-python` no PyPI

Este guia descreve como publicar este pacote no [PyPI](https://pypi.org) para que qualquer pessoa possa instalar com `pip install faturis-sdk-python`.

## Pré-requisitos

- Conta no [PyPI](https://pypi.org/account/register/) (e, opcionalmente, no [Test PyPI](https://test.pypi.org) para testes sem afetar o índice oficial).
- [uv](https://docs.astral.sh/uv/) instalado (ou Python 3.10+ com `pip` e o pacote `build`).
- O código commitado e o ficheiro `pyproject.toml` com a versão que queres publicar.

## 1. Ajustar a versão e os metadados

Antes de cada publicação **nova**, incrementa o campo `version` em `pyproject.toml` (por exemplo `0.1.0` → `0.1.1`). O PyPI **não** permite substituir o mesmo ficheiro de uma versão já publicada; só podes publicar versões novas.

Recomenda-se também preencher, quando fizer sentido:

- `description` e `readme` (já usados na página do pacote).
- `license`, `authors`, `[project.urls]` (repositório, documentação), para a página no PyPI ficar completa.

## 2. Validar localmente

Na raiz do projeto (`faturis-sdk-python/`):

```bash
uv sync
uv run ruff check faturis
uv build
```

Isto gera `dist/` com o ficheiro fonte (`.tar.gz`) e a roda (`.whl`). Se algo falhar, corrige antes de enviar para o PyPI.

Opcional — instalar o wheel gerado num ambiente limpo e testar imports:

```bash
uv pip install dist/faturis_sdk_python-*.whl
uv run python -c "from faturis.client import FaturisClient; print('OK')"
```

## 3. Criar um token de API no PyPI

1. Entra em [pypi.org](https://pypi.org) → **Account settings** → **API tokens**.
2. Cria um token com permissão para o projeto `faturis-sdk-python` (na primeira vez podes usar um token para “toda a conta” e depois restringir).
3. Guarda o token num gestor de segredos; **não** commits no repositório.

Para upload via linha de comando, o PyPI recomenda:

- **Username:** `__token__`
- **Password:** o valor do token (começa por `pypi-...`)

## 4. Publicar no PyPI

### Opção A — `uv publish` (recomendado se já usas uv)

Na raiz do projeto, com `dist/` já gerado:

```bash
uv publish
```

Segue as instruções para credenciais (ou configura variáveis de ambiente / ficheiro de configuração conforme a [documentação do uv](https://docs.astral.sh/uv/guides/package/#publishing-your-package)).

### Opção B — Twine

```bash
uv tool run twine upload dist/*
```

Ou, com pip:

```bash
pip install twine
twine upload dist/*
```

Quando pedir utilizador e palavra-passe, usa `__token__` e o token de API.

### Limpar `dist/` entre builds

Antes de um novo `uv build`, podes apagar artefactos antigos para não enviar versões erradas por engano:

```bash
rm -rf dist/
uv build
```

## 5. Testar primeiro no Test PyPI (opcional)

Útil para validar o fluxo sem publicar no índice oficial.

1. Conta em [test.pypi.org](https://test.pypi.org) e token de API semelhante ao do PyPI.
2. Build: `uv build`
3. Upload, por exemplo com twine:

```bash
uv tool run twine upload --repository testpypi dist/*
```

4. Instalação de teste (o nome do pacote continua a ser o mesmo, mas o índice é outro):

```bash
pip install --index-url https://test.pypi.org/simple/ faturis-sdk-python
```

Nota: dependências como `requests` podem ser resolvidas a partir do PyPI principal; em cenários mais complexos podes precisar de `--extra-index-url https://pypi.org/simple/`.

## 6. Confirmar no PyPI e instalar

- Abre `https://pypi.org/project/faturis-sdk-python/` (após a primeira publicação com esse nome).
- Num ambiente novo:

```bash
pip install faturis-sdk-python
```

Uso no código:

```python
from faturis.client import FaturisClient
# ou: from faturis import FaturisClient
```

## 7. Próximas versões

1. Atualiza `version` em `pyproject.toml`.
2. `rm -rf dist/` → `uv build` → `uv publish` (ou `twine upload dist/*`).
3. Regista as alterações no controlo de versões (git tag, changelog, etc.) conforme o teu fluxo de equipa.

## 8. Automação (CI)

Muitas equipas publicam a partir do GitHub/GitLab com **Trusted Publishers** (OIDC), para não guardar tokens de API no CI. Configura-se no PyPI a ligação ao repositório e o workflow faz o upload automaticamente em tags ou releases. Consulta a documentação oficial do PyPI sobre [Trusted Publishing](https://docs.pypi.org/trusted-publishers/).

---

**Resumo:** incrementar versão → `uv build` → autenticar com token PyPI → `uv publish` ou `twine upload dist/*` → verificar com `pip install faturis-sdk-python`.
