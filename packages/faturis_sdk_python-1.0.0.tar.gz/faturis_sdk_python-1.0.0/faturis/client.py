from faturis.auth import TokenManager, build_keycloak_token_url
from faturis.http import HttpClient
from faturis.services.invoices import InvoiceService
from faturis.services.serie import SerieService


class FaturisClient:
    def __init__(
        self,
        client_id: str,
        client_secret: str,
        base_url: str,
        *,
        token_url: str | None = None,
        keycloak_url: str | None = None,
        realm: str | None = None,
    ) -> None:
        resolved: str | None = (token_url or "").strip() or None
        if not resolved and keycloak_url and realm:
            resolved = build_keycloak_token_url(keycloak_url, realm)
        if not resolved:
            raise ValueError(
                "Provide token_url or both keycloak_url and realm "
                "(Keycloak OpenID token URL)."
            )

        self.token_manager = TokenManager(client_id, client_secret, resolved)
        base = base_url.rstrip("/")
        self.http_client = HttpClient(base, self.token_manager)

        self.invoices = InvoiceService(self.http_client)
        self.series = SerieService(self.http_client)
