from faturis.http import HttpClient


def _invoice_list_filter_params(
    *,
    document_type: str | None = None,
    document_status: str | None = None,
    tax_registration_number: str | None = None,
    document_no: str | None = None,
    document_date_from: str | None = None,
    document_date_to: str | None = None,
    page: int | None = None,
    page_size: int | None = None,
) -> dict:
    raw = {
        "document_type": document_type,
        "document_status": document_status,
        "tax_registration_number": tax_registration_number,
        "document_no": document_no,
        "document_date_from": document_date_from,
        "document_date_to": document_date_to,
        "page": page,
        "page_size": page_size,
    }
    return {k: v for k, v in raw.items() if v is not None}


class InvoiceService:
    def __init__(self, http_client: HttpClient):
        self.http = http_client

    def create(self, payload: dict):
        return self.http.request("POST", "/v1/invoices/", json=payload)

    def list(
        self,
        *,
        document_type: str | None = None,
        document_status: str | None = None,
        tax_registration_number: str | None = None,
        document_no: str | None = None,
        document_date_from: str | None = None,
        document_date_to: str | None = None,
        page: int | None = None,
        page_size: int | None = None,
    ):
        params = _invoice_list_filter_params(
            document_type=document_type,
            document_status=document_status,
            tax_registration_number=tax_registration_number,
            document_no=document_no,
            document_date_from=document_date_from,
            document_date_to=document_date_to,
            page=page,
            page_size=page_size,
        )
        return self.http.request("GET", "/v1/invoices/", params=params)

    def consult(self, payload: dict):
        return self.http.request("POST", "/v1/invoices/consult", json=payload)

    def validate_document(self, payload: dict):
        return self.http.request(
            "POST", "/v1/invoices/validate-document", json=payload
        )

    def list_persisted(
        self,
        *,
        document_type: str | None = None,
        document_status: str | None = None,
        tax_registration_number: str | None = None,
        document_no: str | None = None,
        document_date_from: str | None = None,
        document_date_to: str | None = None,
        page: int | None = None,
        page_size: int | None = None,
    ):
        params = _invoice_list_filter_params(
            document_type=document_type,
            document_status=document_status,
            tax_registration_number=tax_registration_number,
            document_no=document_no,
            document_date_from=document_date_from,
            document_date_to=document_date_to,
            page=page,
            page_size=page_size,
        )
        return self.http.request("GET", "/v1/invoices/persisted", params=params)

    def list_agt(
        self,
        *,
        document_type: str | None = None,
        document_status: str | None = None,
        tax_registration_number: str | None = None,
        document_no: str | None = None,
        document_date_from: str | None = None,
        document_date_to: str | None = None,
        page: int | None = None,
        page_size: int | None = None,
    ):
        params = _invoice_list_filter_params(
            document_type=document_type,
            document_status=document_status,
            tax_registration_number=tax_registration_number,
            document_no=document_no,
            document_date_from=document_date_from,
            document_date_to=document_date_to,
            page=page,
            page_size=page_size,
        )
        return self.http.request("GET", "/v1/invoices/agt", params=params)

    def get_status(
        self,
        request_id: str,
        *,
        submission_uuid: str | None = None,
        tax_registration_number: str | None = None,
    ):
        params = {
            k: v
            for k, v in {
                "submission_uuid": submission_uuid,
                "tax_registration_number": tax_registration_number,
            }.items()
            if v is not None
        }
        return self.http.request(
            "GET",
            f"/v1/invoices/status/{request_id}",
            params=params,
        )
