from faturis.http import HttpClient


class SerieService:
    def __init__(self, http_client: HttpClient):
        self.http = http_client

    def list(
        self,
        *,
        document_type: str | None = None,
        status: str | None = None,
        year: int | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ):
        params = {
            k: v
            for k, v in {
                "document_type": document_type,
                "status": status,
                "year": year,
                "skip": skip,
                "limit": limit,
            }.items()
            if v is not None
        }
        return self.http.request(
            "GET",
            "/v1/series/",
            params=params,
        )

    def create(self, payload: dict):
        return self.http.request("POST", "/v1/series/", json=payload)
