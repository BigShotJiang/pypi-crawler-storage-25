import requests

from faturis.auth import TokenManager


class HttpClient:
    def __init__(self, base_url: str, token_manager: TokenManager):
        self.base_url = base_url
        self.token_manager = token_manager

    def request(self, method: str, url: str, **kwargs):
        token = self.token_manager.get_token()

        headers = kwargs.pop("headers", {})
        headers["Authorization"] = f"Bearer {token}"

        response = requests.request(
            method, f"{self.base_url}{url}", headers=headers, **kwargs
        )

        if response.status_code == 401:
            token = self.token_manager.refresh_token()
            headers["Authorization"] = f"Bearer {token}"
            response = requests.request(
                method, f"{self.base_url}{url}", headers=headers, **kwargs
            )

        return response.json()
