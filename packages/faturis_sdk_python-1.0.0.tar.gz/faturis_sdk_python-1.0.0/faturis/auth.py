import time
from typing import Any

import requests


class TokenAcquisitionError(Exception):
    """The token endpoint did not return a usable access_token."""


def build_keycloak_token_url(keycloak_url: str, realm: str) -> str:
    base = keycloak_url.rstrip("/")
    name = realm.strip().strip("/")
    return f"{base}/realms/{name}/protocol/openid-connect/token"


class TokenManager:
    def __init__(self, client_id: str, client_secret: str, token_url: str):
        self.client_id = client_id
        self.client_secret = client_secret
        self.token_url = token_url
        self._token: str | None = None
        self._expires_at: float | None = None

    def refresh_token(self) -> str:
        self._token = None
        self._expires_at = None
        return self.get_token()

    def get_token(self) -> str:
        now = time.time()
        if self._token and self._expires_at is not None and now < self._expires_at:
            return self._token

        response = requests.post(
            self.token_url,
            data={
                "grant_type": "client_credentials",
                "client_id": self.client_id,
                "client_secret": self.client_secret,
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            timeout=30,
        )

        try:
            data: dict[str, Any] = response.json()
        except ValueError as exc:
            raise TokenAcquisitionError(
                f"Token endpoint returned non-JSON (HTTP {response.status_code}): "
                f"{response.text[:500]!r}"
            ) from exc

        if response.status_code != 200:
            err = data.get("error", "")
            desc = data.get("error_description", "")
            detail = f"{err}: {desc}".strip(": ") or response.text[:500]
            raise TokenAcquisitionError(
                f"Token request failed (HTTP {response.status_code}): {detail}"
            )

        token = data.get("access_token")
        if not token or not isinstance(token, str):
            raise TokenAcquisitionError(
                "Token response missing access_token; "
                f"keys={list(data.keys())!r}"
            )

        expires_in_raw = data.get("expires_in", 60)
        try:
            expires_in = int(expires_in_raw)
        except (TypeError, ValueError):
            expires_in = 60

        skew = 30
        self._token = token
        self._expires_at = now + max(expires_in - skew, 5)

        return self._token
