# faturis-sdk-python

Cliente Python para a API Faturis (faturação eletrónica).

## Instalação

```bash
pip install faturis-sdk-python
```

## Uso

```python
from faturis.client import FaturisClient

# ou: from faturis import FaturisClient

client = FaturisClient(
    client_id="...",
    client_secret="...",
    base_url="https://...",
    token_url="https://.../token",  # ou keycloak_url + realm
)
```

Exemplo com variáveis de ambiente: `how_to_use.py` na raiz deste repositório (não faz parte do pacote instalado; serve para desenvolvimento).

## Requisitos

Python 3.10 ou superior.
