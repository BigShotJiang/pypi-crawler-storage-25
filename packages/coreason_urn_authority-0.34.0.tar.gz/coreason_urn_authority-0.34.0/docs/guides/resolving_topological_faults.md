# Resolving Topological Faults

When injecting a new URN Action Space into the `coreason-urn-authority`, your bundle is actively governed by the `scripts/compile_registry.py` AST array. If your integration hits an explicit `ValueError: Topological Fault`, it implies your architectural structure has violated the absolute physical constraints.

## Encountering "Unrecognized Asset Category"
**The Error:**
```bash
ValueError: Topological Fault: Unrecognized asset category 'my_custom_domain' in assets/my_custom_domain/tool_v1/...
```
**The Fix:**
You are mathematically forbidden from operating loosely coupled categories. Repackage your environment completely targeting strictly `"oracle", "solver", "effector", "substrate", "sensory", "node"` bounds explicitly defined within `AGENTS.md`.

## Encountering "Violates Directory Map Formula"
**The Error:**
```bash
ValueError: Topological Fault: URN 'urn:coreason:actionspace:oracle:clinical_fetch:v2' violates Directory Map Formula. ...
```
**The Fix:**
Your dynamic folder path MUST symmetrically equate backward into your explicit target declaration array matching natively across `${category}/${bundle_name}_${version}`. If the URN reads `oracle:clinical_fetch:v2`, the exact folder resolution must strictly map to `assets/oracle/clinical_fetch_v2/`. Rename your repository sub-bundle immediately!
