# CoReason URN Authority: The Epistemic Ledger

Welcome to the **Epistemic Ledger** (`coreason-urn-authority`). This repository operates as the strictly bound **Autonomic Capability Registry** and **Quality Guillotine** within the CoReason Tripartite Cybernetic Manifold.

*If `coreason-manifest` is the DNA and `coreason-runtime` is the cell, `coreason-urn-authority` is the immune system and library of record—ensuring that only verified, topologically sound capabilities are permitted to execute.*

## Documentation Architecture

This documentation is structured according to the [Diátaxis](https://diataxis.fr/) framework to serve both Human Oracles (Maintainers) and Enterprise Clients (Deployers).

### 🎓 [Tutorials](tutorials/scaffolding_first_urn.md)
*Learning-oriented paths for new Reasoning Engineers.*
- Scaffolding your first Sovereign URN.
- Executing the Human Oracle PR review process.

### 🛠️ [How-To Guides](guides/deploying_custom_client_urns.md)
*Action-oriented guides for daily operations.*
- **Enterprise Ops:** Deploying custom, air-gapped URNs to Client VPCs.
- Resolving AST Topological Faults in CI/CD.
- Updating Economic Ledgers and Billing Tiers.

### 🧠 [Explanation](architecture/the_epistemic_ledger.md)
*Understanding the Information Science behind the system.*
- The Tripartite Architecture (Why we decouple Identity from Execution).
- The 6 Universal Archetypes (Oracles, Solvers, Effectors, Substrates, Sensory, Nodes).
- Understanding the Quality Guillotines (OpenShell bounds & Canonical Sorting).

### 📖 [Reference](reference/manifest_specification.md)
*Information-oriented technical specs.*
- Exhaustive `manifest.yaml` Schema definition.
- Auto-generated API documentation for the active Registry matrix.

---
**Agentic Note:** Autonomous agents (`coreason-meta-engineering`) MUST consult `llms.txt` and `AGENTS.md` located in the root of the repository to internalize the mathematical constraints of the ledger before contributing.
