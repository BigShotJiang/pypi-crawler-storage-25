# URN Authority API

This reference documents the internal modules of the URN Authority.

::: coreason_urn_authority.ledger.loader

::: coreason_urn_authority.crypto.cosign_verifier

::: coreason_urn_authority.routing.semantic_router
