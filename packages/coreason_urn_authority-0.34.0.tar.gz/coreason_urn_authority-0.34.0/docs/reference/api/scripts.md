# Scripts Documentation

::: scripts.hydrate_docs

::: scripts.migrate_manifests
