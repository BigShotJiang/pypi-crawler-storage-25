# Manifest Specification (`manifest.yaml`)

The `manifest.yaml` is the cryptographic identity card for every Sovereign capability. All manifests MUST validate against `schemas/manifest.schema.json`.

## 1. Identity & Clearance
* **`urn`**: The globally unique Uniform Resource Name. Must match the directory path.
* **`tenant_cid`**: The Decentralized Identifier (CID) denoting the hard multi-tenancy bounds for this component (e.g. `889955217295c2bfef2d6812071b633b0819477e67f57853febf116f69f30531`).
* **`default_clearance_tiers`**: An array of integers (0-255) dictating the baseline authorized compartments.
* **`default_minimum_rigidity_tier`**: Integer (0-255) defining required thermodynamic execution limits.
* **`epistemic_status`**: `DRAFT` (AI scaffolded) or `PUBLISHED` (Oracle approved).

## 2. Composition & Economics
* **`topology`**: `ATOMIC` (Standalone) or `COMPOSITE` (Invokes other URNs).
* **`license_class`**: e.g., `PROSPERITY_3.0_COMMERCIAL` or `ENTERPRISE_CUSTOM`.
* **`billing_tier`**: Abstract cost category for thermodynamic pricing.
