# The Archetype Model

The `coreason-urn-authority` strictly forbids unstructured capability namespaces. To enforce rigorous, deterministic logic mapping across the overarching Tripartite Architecture, all assets must perfectly follow **The Archetype Model**.

## The 6 Universal Categories

Every single action space deployed within this ledger requires placement strictly inside one of the following exact geometric folder structures:

1. **Epistemic Oracles (`oracle/*`)**: Read-only APIs fetching semantic or probabilistic contexts strictly free of kinetic state accumulation.
2. **Cognitive Solvers (`solver/*`)**: Compute-intense boundaries routing pure calculation schemas or explicit NLP validation layers.
3. **Kinetic Effectors (`effector/*`)**: Pure mathematical Write/Update protocols operating exclusively over finite state parameters.
4. **Sovereign Substrates (`substrate/*`)**: Dynamic systems holding Mutable State and establishing persistent digital-twins mirroring underlying external contexts.
5. **Sensory Projections (`sensory/*`)**: Strict HCI/UI bindings routing context backwards across interfaces.
6. **Autonomic Nodes (`node/*`)**: Fully-functional encapsulated micro-agents bridging swarms across distributed systems.

## Topographical AST Enforcement

The system natively leverages Python AST validation logic dynamically across the Ouroboros CI Loop via `scripts/compile_registry.py`.

> [!WARNING]
> If an Action Space MCP module is floating arbitrarily in the root level, or attempts injection via a rogue categorization folder (e.g., `assets/toolchain/custom...`), the AST natively traps the matrix violation and triggers an immediate structural `ValueError: Topological Fault`. This guarantees mathematical precision mapping back up into `coreason-ecosystem`!
