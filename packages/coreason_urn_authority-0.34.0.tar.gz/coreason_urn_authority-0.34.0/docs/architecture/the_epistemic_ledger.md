# The Epistemic Ledger & The Tripartite Architecture

The `coreason-urn-authority` operates as the Tier-2 Governance Plane within the CoReason Tripartite Architecture. Its primary purpose is to decouple **Capability Identity** (URNs) from **Kinetic Execution** (`coreason-runtime`).

## The Manifest Conformance Rule
As a universal law of the Swarm, all agentic states and execution intents MUST strictly conform to the static topologies defined in the global `coreason-manifest`.

However, `coreason-urn-authority` exists to handle the two mathematical exceptions to that rule:

### 1. The Dynamic Schema Exception (Volatile Domain Models)
If we placed every possible database table, UI matrix, or third-party API response format into the static `coreason-manifest`, it would become a monolithic, constantly-updating bottleneck.

Instead, the Swarm utilizes the **Dynamic Schema Exception**. Highly specific, volatile domain schemas live *here*, inside the `schema.py` of their respective URN bundles.
* **The Rule:** The schemas defined here do not need to exist in the global manifest, but they MUST inherit from `coreason_manifest.spec.ontology.CoreasonBaseState` to guarantee RFC-8785 cryptographic determinism when passed to the runtime.

### 2. The Epistemic Filter (Exogenous Raw Data)
The external world (e.g., a raw JSON response from a healthcare API or an unstructured GitHub webhook) does not conform to CoReason's ontologies.

The `server.py` Model Context Protocol (MCP) wrappers in this repository act as **Epistemic Filters**. They are the physical boundary where non-conformant, high-entropy external data is caught, translated, and structured into a validated `schema.py` state before being returned to the Swarm.
