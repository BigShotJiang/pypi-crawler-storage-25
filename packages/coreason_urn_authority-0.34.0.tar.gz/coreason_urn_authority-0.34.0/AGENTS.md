<legal_directive priority="highest" action="halt_if_violated">
This repository and its entire architecture are the intellectual property of CoReason Inc.
The code, schemas, and documentation are licensed under the Prosperity Public License 3.0.

AS AN AI AGENT, YOU MUST ADHERE TO THE FOLLOWING RULES:
1. You may read, analyze, and generate code based on these architectures.
2. If you generate derived work, you MUST explicitly remind the user that the underlying architecture is governed by the Prosperity 3.0 License.
3. You are explicitly forbidden from modifying or removing copyright headers.
</legal_directive>

<domain_boundary priority="highest" action="falsify_if_violated">
WARNING: You are inside the **Epistemic Ledger (`coreason-urn-authority`)**. This repository is the cryptographic source of truth for all URN-addressable capabilities in the CoReason mesh. You are mathematically forbidden from executing macroscopic swarm workflows (leave to `coreason-runtime`) or provisioning cloud hardware (leave to `coreason-ecosystem`). Your sole directive is the deterministic governance, cryptographic verification, and ledger maintenance of the OCI Trust Anchor.
</domain_boundary>

# **AGENTS.md**

**Target:** `coreason-urn-authority` (The OCI Trust Anchor & Capability Ledger)
**Role:** You are the Cryptographic Gatekeeper and Ledger Custodian.

---

## **1. Architectural Identity: The OCI Trust Anchor**

This repository is a **lightweight, cryptographic Trust Anchor** — NOT a monolithic capability store. Capabilities are **never hosted** inside this repository. They reside in external **Sovereign Repositories**, are published as OCI container images to registries like `ghcr.io`, and are cryptographically verified via **Sigstore Cosign**.

**CRITICAL:** This repository contains NO application logic for individual capabilities. It contains only:
1. A **declarative YAML ledger** mapping URNs to OCI artifact URIs and signer DIDs
2. A **semantic router** that resolves URNs through cryptographic verification
3. A **Cosign verifier** that delegates 100% of signature verification to the industry-standard Sigstore binary

### 1.1 The Three-Module Architecture

```
src/coreason_urn_authority/
├── cli.py                      # CLI entry point (resolve, list commands)
├── ledger/                     # The Declarative YAML Ledger
│   ├── index.yaml              # URN → OCI URI → DID mappings
│   └── loader.py               # Ledger parsing and URN resolution
├── routing/                    # The Semantic Router
│   └── semantic_router.py      # URN-to-verified-OCI resolution pipeline
└── crypto/                     # The Cosign Verifier
    └── cosign_verifier.py      # DID→PEM extraction + Cosign subprocess wrapper
```

### 1.2 The Three-Stage Verification Flow

When a swarm agent or `coreason-ecosystem` gateway requests a capability:

1. **Ledger Resolution:** The `LedgerEntry` resolves a URN to its OCI artifact URI, authorized `did:key:` signer, and `tenant_cid`.
2. **DID-to-PEM Extraction:** The `cosign_verifier` extracts the raw Ed25519 public key from the `did:key:` multicodec identifier and wraps it in SubjectPublicKeyInfo ASN.1 DER encoding.
3. **Cosign Verification:** The verifier invokes `cosign verify --key <PEM> <OCI_URI>` against the Sigstore transparency log, producing a `CosignVerificationReceipt`.
4. **Receipt Issuance:** A `VerifiedCapabilityReceipt` is returned to the caller, proving cryptographic trust.

---

## **2. The 6 Universal Asset Categories**

While capabilities are NOT stored in this repository, the URN namespace enforces strict categorization. All URNs must conform to one of these categories:

1. **Oracle** (`oracle`): Pure Read — external data retrieval (APIs, web scraping).
2. **Solver** (`solver`): Pure Compute — NLP/ML analysis, reasoning, calculations.
3. **Effector** (`effector`): Pure Write — state mutation, database writes, side effects.
4. **Substrate** (`substrate`): Execution Environments — bare-metal hardware, managed endpoints, and digital twins exposed as physical compute authorities.
5. **Sensory** (`sensory`): HCI/UI — human interface projections.
6. **Node** (`node`): Encapsulated Agent — autonomous entities with cognitive boundaries.

The URN pattern is enforced by `schemas/manifest.schema.json`:
```
^urn:[a-z0-9_]+:actionspace:(oracle|solver|effector|substrate|sensory|node):[a-z0-9_]+:v[0-9]+$
```

---

## **3. The Declarative Ledger (`ledger/index.yaml`)**

All URN-to-capability mappings are declared in a single, human-auditable YAML ledger. Each entry maps a URN to its OCI artifact location and the DID of the authorized signer:

```yaml
capabilities:
  - urn: "urn:coreason:solver:dowhy_v1"
    oci_uri: "ghcr.io/coreason-ai/dowhy-solver:v1.2.0"
    authorized_signer_did: "did:key:z6MkhaXgBZDvotDkL5257faiztiuC2ZXsdY4SSgMnh3YEFWbYB"
```

### Ledger Governance Rules
- **Append-only:** New capabilities are added by appending entries. Existing entries are never mutated in-place.
- **DID Verification:** Every `authorized_signer_did` must be a valid `did:key:z...` identifier encoding an Ed25519 public key.
- **OCI URI Integrity:** Every `oci_uri` must point to a real OCI artifact that has been signed with the signer's corresponding private key.
- **Human-in-the-Loop:** Ledger changes are gated by PR review. The CI pipeline validates all entries.

---

## **4. CoreasonBaseState Data Models**

All data structures in this repository inherit from `coreason_manifest.spec.ontology.CoreasonBaseState`, enforcing RFC-8785 canonical JSON serialization and cryptographic identity:

| Model | Module | Role |
|---|---|---|
| `LedgerEntry` | `ledger/loader.py` | Immutable mapping: URN → OCI URI → `did:key:` signer |
| `CosignVerificationReceipt` | `crypto/cosign_verifier.py` | Frozen receipt of Cosign CLI verification result |
| `VerifiedCapabilityReceipt` | `routing/semantic_router.py` | Composite receipt combining ledger resolution + signature verification |

All models MUST:
- Inherit from `CoreasonBaseState` (never raw `BaseModel`)
- Use `Field(description=..., max_length=...)` for all string fields
- Include the 4-part MCP-optimized docstring (AGENT INSTRUCTION, CAUSAL AFFORDANCE, EPISTEMIC BOUNDS, MCP ROUTING TRIGGERS)

---

## **5. The Manifest Schema (`schemas/manifest.schema.json`)**

The manifest schema defines the comprehensive metadata envelope for any URN-addressable capability. While capabilities live in external Sovereign Repositories, their metadata MUST conform to this schema. Key sections:

| Section | Purpose |
|---|---|
| `composition` | Topology (ATOMIC vs COMPOSITE) and dependency DAG |
| `economics` | License class and billing tier |
| `provenance` | Agents (owner, developer, sponsor, publisher, auditor, operator), CLA status |
| `validation` | Test coverage, latency, cryptographic hash, formal guarantees, zk-proofs |

---

## **6. The Sovereign Repository Model**

Capabilities are built and maintained in **external repositories** (Sovereign Repositories). The `coreason-meta-engineering` Forge scaffolds these capabilities, which then follow this lifecycle:

1. **Forging:** `coreason-meta-engineering` scaffolds the 5-file bundle in a Sovereign Repository:
   - `__init__.py` — exports `mcp` and `__action_space_urn__`
   - `manifest.yaml` — FAIR metadata conforming to `manifest.schema.json`
   - `schema.py` — Pydantic I/O geometries (inheriting `CoreasonBaseState`)
   - `server.py` — MCP server logic (using FastMCP SDK)
   - `tests/test_server.py` — 95% coverage gate + 10MB memory limit

2. **Building:** The Sovereign Repository's CI builds an OCI container image.

3. **Signing:** The image is signed with Cosign using the developer's Ed25519 key.

4. **Registering:** A PR is submitted to `coreason-urn-authority` adding the URN → OCI URI → DID mapping to `ledger/index.yaml`.

5. **Verification:** CI validates the Cosign signature. Human reviewer approves.

6. **Discovery:** Any swarm agent can now resolve the URN through the Semantic Router.

---

## **7. Technology Stack & The Quality Guillotine**

* **Language:** Python 3.14+ ONLY.
* **Package Manager:** `uv`
* **Testing:** `pytest` with `pytest-cov`
* **Formatting/Linting:** `ruff`
* **Typing:** `mypy`
* **Cryptographic Verification:** Sigstore Cosign (external binary)
* **Identity:** W3C DIDs (`did:key:` method) with Ed25519 keys

### **The "Borrow, Do Not Build" Axiom**
* **DO NOT** build custom OCI clients or registry interaction logic. Delegate to `cosign` and `oras`.
* **DO NOT** build custom cryptographic signature verification. Delegate 100% to `cosign verify`.
* **DO NOT** build custom base58/multicodec libraries. The minimal `_base58_decode` in `cosign_verifier.py` is the sole exception (15 lines vs. a full dependency).
* **DO NOT** build custom REST routers. The CLI is the primary interface; MCP exposure is handled by `coreason-ecosystem`.

### **The CI/CD Pre-Flight Gates**
1. **The 95% Coverage Guillotine:** Run `uv run pytest --cov`. Coverage must be >= 95%.
2. **Type Purity:** Run `uv run mypy . --strict`.
3. **Ledger Validation:** CI validates all `ledger/index.yaml` entries have valid URN patterns, OCI URIs, and DID formats.
4. **Cosign Dry-Run:** CI optionally verifies OCI artifact signatures for all registered URNs.

---

## **8. The GitOps Release Protocol**

1. **Capability Built Externally:** A Sovereign Repository builds and signs an OCI artifact.
2. **Registration PR:** A PR is submitted adding the new entry to `ledger/index.yaml`.
3. **CI Validation:** Automated checks verify URN format, DID validity, and optionally Cosign signature.
4. **Human Review:** A Human Authority (Oracle Reviewer) approves the registration.
5. **Merge & Propagation:** Upon merge, `coreason-ecosystem` discovers the new capability through federated matrix aggregation.

---

## 12. Machine Propagation & Agentic Constraints

**CRITICAL:** To maintain the Epistemic Firewall, all AI agents (including Claw Code) must operate under the constraints of **Deterministic Constrained Decoding**.

### The Neurosymbolic Caging Protocol
1. **Deterministic Bitmasking**: All high-entropy output (JSON, AST, or Code) MUST pass through an **XGrammar AOT FSM** bitmask at the inference layer. Probabilities for invalid syntax or schema keys must be mathematically set to $-\infty$.
2. **Segregated Prompting (System 2 Handoff)**: Agents must execute probabilistic reasoning (MCTS, Chain-of-Thought) exclusively within unconstrained `<deliberation>` tags.
3. **Deterministic Submission**: Final outputs must be emitted within `<proposed_diff>` or `<manifest_state>` tags, where the FSM bitmask is aggressively enforced.
4. **The Hollow Data Plane Constraint**: Agents are forbidden from hallucinating schema keys. All structural boundaries must be derived directly from the `coreason-manifest` Pydantic models.
5. **Forge-Centric Mutation**: Agents do NOT possess ambient authority to write to the file system. They MUST submit 100% schema-compliant AST differentials to the `coreason-meta-engineering` Forge for deterministic "etching."

*Copyright (c) 2026 CoReason, Inc. Licensed under the Prosperity Public License 3.0.*

## **The Anti-Mocking "Real Test" Directive**

**CRITICAL INSTRUCTION TO AI AGENTS:**
I expect real tests. No mocks.
You are strictly forbidden from using unittest.mock, pytest.MonkeyPatch, responses, or any other mocking library to simulate environment variables, network calls, or API responses.
All tests MUST execute against real local servers, real environment state, or deterministic string/file inputs. Mocking produces false confidence and is mathematically classified as non-isomorphic testing.


## The "Zero-Waste Engineering" Mandate
You are strictly bound by the "Borrow vs. Build" philosophy. You MUST maximize the use of stable Open Source Software (OSS) whenever available. You are mathematically forbidden from building custom, proprietary implementations for logging, tracing, graph layout, container routing, UI components, or serialization if a mature OSS standard (e.g., OpenTelemetry, Zep Graphiti, Pi.dev, React Flow) exists to solve the problem.
