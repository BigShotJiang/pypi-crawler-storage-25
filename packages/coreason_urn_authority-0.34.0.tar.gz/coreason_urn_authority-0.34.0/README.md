# coreason-urn-authority (The Epistemic Ledger)

[![PyPI - Version](https://img.shields.io/pypi/v/coreason-urn-authority.svg)](https://pypi.org/project/coreason-urn-authority/)
[![CI](https://github.com/CoReason-AI/coreason-urn-authority/actions/workflows/ci.yml/badge.svg?branch=main)](https://github.com/CoReason-AI/coreason-urn-authority/actions/workflows/ci.yml)
[![Documentation](https://img.shields.io/badge/docs-GitHub_Pages-blue.svg)](https://coreason-ai.github.io/coreason-urn-authority/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/coreason-urn-authority.svg)](https://pypi.org/project/coreason-urn-authority/)
[![Downloads](https://static.pepy.tech/badge/coreason-urn-authority)](https://pepy.tech/project/coreason-urn-authority)
[![License: Prosperity 3.0](https://img.shields.io/badge/License-Prosperity_3.0-blue.svg)](https://prosperitylicense.com/versions/3.0.0)
[![Codecov](https://codecov.io/gh/CoReason-AI/coreason-urn-authority/branch/main/graph/badge.svg)](https://codecov.io/gh/CoReason-AI/coreason-urn-authority)
<br>
[![OpenSSF Scorecard](https://img.shields.io/ossf-scorecard/github.com/CoReason-AI/=OpenSSF)](https://scorecard.dev/viewer/?uri=github.com/CoReason-AI/coreason-urn-authority)
[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)
[![Pre-commit](https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit)](https://github.com/pre-commit/pre-commit)
[![uv](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/uv/main/assets/badge/v0.json)](https://github.com/astral-sh/uv)
[![Powered By: AI](https://img.shields.io/badge/Powered%20By-CoReason%20AI-FF4500.svg)](https://coreason.ai)
[![OSV-Scanner](https://img.shields.io/github/actions/workflow/status/CoReason-AI/coreason-urn-authority/osv-scanner.yml?branch=main&label=OSV-Scanner)](https://github.com/CoReason-AI/coreason-urn-authority/actions/workflows/osv-scanner.yml)
[![Trivy](https://img.shields.io/github/actions/workflow/status/CoReason-AI/coreason-urn-authority/trivy.yml?branch=main&label=Trivy)](https://github.com/CoReason-AI/coreason-urn-authority/actions/workflows/trivy.yml)
[![TruffleHog](https://img.shields.io/github/actions/workflow/status/CoReason-AI/coreason-urn-authority/trufflehog.yml?branch=main&label=TruffleHog)](https://github.com/CoReason-AI/coreason-urn-authority/actions/workflows/trufflehog.yml)
[![OWASP ZAP](https://img.shields.io/github/actions/workflow/status/CoReason-AI/coreason-urn-authority/dast.yml?branch=main&label=OWASP%20ZAP)](https://github.com/CoReason-AI/coreason-urn-authority/actions/workflows/dast.yml)

**The Epistemic Ledger & Capability Registry of the CoReason ecosystem.**

`coreason-urn-authority` acts as the central, cryptographic authority for all URN-addressable capabilities (Model Context Protocol servers). It enforces strict topographical bounds, quality guillotines, and memory limits before capabilities can be dynamically projected into client VPCs.

## Getting Started

### Prerequisites

- Python 3.14+
- uv

### Installation

1.  Clone the repository:
    ```sh
    git clone https://github.com/CoReason-AI/coreason-urn-authority.git
    cd coreason-urn-authority
    ```
2.  Install dependencies:
    ```sh
    uv sync --all-extras --dev
    ```

### Usage

-   Run the linter:
    ```sh
    uv run pre-commit run --all-files
    ```
-   Run the tests:
    ```sh
    uv run pytest
    ```

