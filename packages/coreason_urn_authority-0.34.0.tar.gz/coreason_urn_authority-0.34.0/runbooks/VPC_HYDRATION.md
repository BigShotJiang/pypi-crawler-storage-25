# Runbook: VPC Hydration & Matrix Sync

**Target Audience:** CoReason Deployment Engineers
**Objective:** Synchronize the global Epistemic Ledger (`compiled_matrix.json`) into an air-gapped Enterprise VPC and hydrate the Master MCP.

## Execution Steps
1. **Artifact Retrieval:** Download `compiled_matrix.json` and OCI containers from CoReason Global.
2. **Matrix Injection:** `cp compiled_matrix.json /mnt/coreason-state/registry/compiled_matrix.json`
3. **Image Sideloading:** `docker load -i coreason_assets_v2.1.tar`
4. **Hydrate Master MCP:** `systemctl restart coreason-master-mcp`
