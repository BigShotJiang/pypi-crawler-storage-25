# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-urn-authority>

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))

from hydrate_docs import hydrate  # type: ignore[import-not-found]


def test_hydrate_docs(tmp_path: Path) -> None:
    # Run the function
    hydrate(root_dir=tmp_path)

    # Assert directories are created
    assert (tmp_path / "schemas").exists()
    assert (tmp_path / "runbooks").exists()
    assert (tmp_path / "docs/tutorials").exists()
    assert (tmp_path / "docs/guides").exists()
    assert (tmp_path / "docs/architecture").exists()
    assert (tmp_path / "docs/reference").exists()

    # Assert files are created
    assert (tmp_path / "schemas/manifest.schema.json").exists()
    assert (tmp_path / "runbooks/VPC_HYDRATION.md").exists()
    assert (tmp_path / "docs/reference/manifest_specification.md").exists()
    assert (tmp_path / "docs/tutorials/scaffolding_first_urn.md").exists()
