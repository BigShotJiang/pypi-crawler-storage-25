# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-urn-authority>

"""Tests for the Cosign OCI Artifact Signature Verifier.

Uses dependency inversion (injectable subprocess runner) instead of
mocking libraries, per the Anti-Mock directive. Each test injects a
deterministic function that returns pre-defined CompletedProcess
results to simulate cosign CLI behavior.
"""

from __future__ import annotations

import base64
import json
import subprocess

import pytest
from pydantic import ValidationError

from coreason_urn_authority.crypto.cosign_verifier import (
    CosignVerificationReceipt,
    SubprocessRunner,
    TopologicalSeveranceEvent,
    _base58_decode,
    extract_public_key_pem_from_did,
    verify_oci_signature,
)

# ────────────────────────────────────────────────────────────────────
# Deterministic subprocess runners (Dependency Inversion, NOT mocking)
# ────────────────────────────────────────────────────────────────────


def _make_success_runner(
    payload: object = None,
) -> SubprocessRunner:
    """Create a runner that simulates a successful cosign verification."""
    output = json.dumps(payload or [{"critical": {"identity": {"docker-reference": "ghcr.io/test"}}}])

    def runner(*args: object, **kwargs: object) -> subprocess.CompletedProcess[str]:
        return subprocess.CompletedProcess(
            args=["cosign", "verify"],
            returncode=0,
            stdout=output,
            stderr="",
        )

    return runner


def _make_failure_runner(error_msg: str = "signature verification failed") -> SubprocessRunner:
    """Create a runner that simulates a failed cosign verification."""

    def runner(*args: object, **kwargs: object) -> subprocess.CompletedProcess[str]:
        return subprocess.CompletedProcess(
            args=["cosign", "verify"],
            returncode=1,
            stdout="",
            stderr=error_msg,
        )

    return runner


def _make_not_found_runner() -> SubprocessRunner:
    """Create a runner that simulates cosign binary not being installed."""

    def runner(*args: object, **kwargs: object) -> subprocess.CompletedProcess[str]:
        raise FileNotFoundError("cosign not found")

    return runner


def _make_non_json_runner() -> SubprocessRunner:
    """Create a runner that returns non-JSON output (some cosign versions)."""

    def runner(*args: object, **kwargs: object) -> subprocess.CompletedProcess[str]:
        return subprocess.CompletedProcess(
            args=["cosign", "verify"],
            returncode=0,
            stdout="Verification succeeded.\n",
            stderr="",
        )

    return runner


# ────────────────────────────────────────────────────────────────────
# Test: verify_oci_signature
# ────────────────────────────────────────────────────────────────────

_DUMMY_PEM = "-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEA...\n-----END PUBLIC KEY-----\n"


class TestVerifyOCISignature:
    """Tests for the OCI signature verification wrapper."""

    def test_successful_verification(self) -> None:
        expected_payload = [{"critical": {"identity": {"docker-reference": "ghcr.io/test"}}}]
        runner = _make_success_runner(expected_payload)
        receipt = verify_oci_signature(
            "ghcr.io/coreason-ai/dowhy-solver:v1.2.0",
            _DUMMY_PEM,
            runner=runner,
        )
        assert isinstance(receipt, CosignVerificationReceipt)
        assert receipt.oci_uri == "ghcr.io/coreason-ai/dowhy-solver:v1.2.0"
        assert receipt.cosign_payload == expected_payload

    def test_failed_verification_raises_severance(self) -> None:
        runner = _make_failure_runner("Error: no matching signatures")
        with pytest.raises(TopologicalSeveranceEvent, match="OCI signature verification failed"):
            verify_oci_signature(
                "ghcr.io/coreason-ai/tampered-image:v1",
                _DUMMY_PEM,
                runner=runner,
            )

    def test_tampered_artifact_raises_severance(self) -> None:
        runner = _make_failure_runner("Error: cosign verification failed: signature mismatch")
        with pytest.raises(TopologicalSeveranceEvent, match="signature mismatch"):
            verify_oci_signature(
                "ghcr.io/coreason-ai/tampered:latest",
                _DUMMY_PEM,
                runner=runner,
            )

    def test_cosign_not_installed_raises_severance(self) -> None:
        runner = _make_not_found_runner()
        with pytest.raises(TopologicalSeveranceEvent, match="Cosign binary not found"):
            verify_oci_signature(
                "ghcr.io/coreason-ai/any-image:v1",
                _DUMMY_PEM,
                runner=runner,
            )

    def test_non_json_output_handled_gracefully(self) -> None:
        runner = _make_non_json_runner()
        receipt = verify_oci_signature(
            "ghcr.io/coreason-ai/solver:v1",
            _DUMMY_PEM,
            runner=runner,
        )
        assert receipt.oci_uri == "ghcr.io/coreason-ai/solver:v1"
        assert "raw_output" in receipt.cosign_payload

    def test_receipt_is_immutable(self) -> None:
        runner = _make_success_runner()
        receipt = verify_oci_signature(
            "ghcr.io/test:v1",
            _DUMMY_PEM,
            runner=runner,
        )
        with pytest.raises(ValidationError):
            receipt.oci_uri = "tampered"


# ────────────────────────────────────────────────────────────────────
# Test: extract_public_key_pem_from_did
# ────────────────────────────────────────────────────────────────────


def _make_test_did() -> tuple[str, bytes]:
    """Create a valid test DID with a known Ed25519 public key.

    Returns a (did_key, raw_pubkey) tuple.
    """
    # Generate a deterministic 32-byte "public key"
    raw_pubkey = bytes(range(32))

    # Encode as did:key: (multicodec Ed25519 prefix + key, base58btc, 'z' prefix)
    multicodec_bytes = b"\xed\x01" + raw_pubkey

    # Encode to base58btc
    n = int.from_bytes(multicodec_bytes, "big")
    alphabet = b"123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
    chars: list[int] = []
    while n > 0:
        n, remainder = divmod(n, 58)
        chars.append(alphabet[remainder])
    # Handle leading zeros
    for byte in multicodec_bytes:
        if byte == 0:
            chars.append(alphabet[0])
        else:
            break
    encoded = bytes(reversed(chars)).decode("ascii")

    did_key = f"did:key:z{encoded}"
    return did_key, raw_pubkey


class TestExtractPublicKeyFromDID:
    """Tests for DID → PEM key extraction."""

    def test_valid_ed25519_did(self) -> None:
        did_key, raw_pubkey = _make_test_did()
        pem = extract_public_key_pem_from_did(did_key)

        # Verify PEM structure
        assert pem.startswith("-----BEGIN PUBLIC KEY-----\n")
        assert pem.strip().endswith("-----END PUBLIC KEY-----")

        # Decode the PEM body and verify it contains the raw public key
        pem_lines = pem.strip().split("\n")
        pem_body = pem_lines[1]
        der_bytes = base64.b64decode(pem_body)

        # The raw public key should be the last 32 bytes of the DER encoding
        assert der_bytes[-32:] == raw_pubkey

    def test_invalid_did_prefix(self) -> None:
        with pytest.raises(TopologicalSeveranceEvent, match="Invalid DID format"):
            extract_public_key_pem_from_did("did:web:example.com")

    def test_missing_z_prefix(self) -> None:
        with pytest.raises(TopologicalSeveranceEvent, match="Invalid DID format"):
            extract_public_key_pem_from_did("did:key:abc123")

    def test_invalid_base58_chars(self) -> None:
        with pytest.raises(TopologicalSeveranceEvent, match="Failed to base58-decode"):
            extract_public_key_pem_from_did("did:key:z0OIl")  # 0, O, I, l not in base58

    def test_wrong_multicodec_prefix(self) -> None:
        """A DID with a non-Ed25519 multicodec should be rejected."""
        # P-256 multicodec prefix is 0x8024
        raw_key = bytes(range(33))
        fake_bytes = b"\x80\x24" + raw_key

        n = int.from_bytes(fake_bytes, "big")
        alphabet = b"123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
        chars: list[int] = []
        while n > 0:
            n, remainder = divmod(n, 58)
            chars.append(alphabet[remainder])
        encoded = bytes(reversed(chars)).decode("ascii")
        did_key = f"did:key:z{encoded}"

        with pytest.raises(TopologicalSeveranceEvent, match="Unsupported key type"):
            extract_public_key_pem_from_did(did_key)


# ────────────────────────────────────────────────────────────────────
# Test: base58 decoder
# ────────────────────────────────────────────────────────────────────


class TestBase58Decode:
    """Tests for the internal base58 decoder."""

    def test_known_value(self) -> None:
        # "1" in base58 = 0x00
        result = _base58_decode("1")
        assert result == b"\x00"

    def test_round_trip(self) -> None:
        test_bytes = b"\xed\x01" + bytes(range(32))
        n = int.from_bytes(test_bytes, "big")
        alphabet = b"123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
        chars: list[int] = []
        while n > 0:
            n, remainder = divmod(n, 58)
            chars.append(alphabet[remainder])
        encoded = bytes(reversed(chars)).decode("ascii")

        decoded = _base58_decode(encoded)
        assert decoded == test_bytes


class TestRustFallback:
    """Verifies that the system falls back to pure-Python when Rust is unavailable."""

    def test_fallback_extract_public_key(self, monkeypatch: pytest.MonkeyPatch) -> None:
        import coreason_urn_authority.crypto.cosign_verifier as cv

        # Simulate Rust extension being unavailable
        monkeypatch.setattr(cv, "_RUST_VERIFIER", None)

        did_key, raw_pubkey = _make_test_did()
        pem = cv.extract_public_key_pem_from_did(did_key)
        assert pem.startswith("-----BEGIN PUBLIC KEY-----\n")
        assert pem.strip().endswith("-----END PUBLIC KEY-----")

    def test_fallback_compute_canonical_hash(self, monkeypatch: pytest.MonkeyPatch) -> None:
        import hashlib

        import coreason_urn_authority.crypto.cosign_verifier as cv

        # Simulate Rust extension being unavailable
        monkeypatch.setattr(cv, "_RUST_VERIFIER", None)

        payload = "test\r\npayload"
        hash_val = cv.compute_canonical_hash(payload)
        expected = hashlib.sha256(b"test\npayload").hexdigest()
        assert hash_val == expected


class TestSignatureCaching:
    """Verifies that duplicate signature verification requests use LRU cache."""

    def test_caching_behavior(self, monkeypatch: pytest.MonkeyPatch) -> None:
        import subprocess

        import coreason_urn_authority.crypto.cosign_verifier as cv

        call_count = 0

        def fake_run(*args: Any, **kwargs: Any) -> subprocess.CompletedProcess[str]:
            nonlocal call_count
            call_count += 1
            return subprocess.CompletedProcess(
                args=["cosign", "verify"],
                returncode=0,
                stdout='[{"critical": {"identity": {"docker-reference": "ghcr.io/test"}}}]',
                stderr="",
            )

        monkeypatch.setattr(subprocess, "run", fake_run)

        # Clear the cache before running the test to ensure isolation
        cv._verify_oci_signature_cached.cache_clear()

        # Call 1
        receipt1 = cv.verify_oci_signature("ghcr.io/test-cached:v1", _DUMMY_PEM)
        # Call 2
        receipt2 = cv.verify_oci_signature("ghcr.io/test-cached:v1", _DUMMY_PEM)

        # Confirm the underlying subprocess was run exactly once
        assert call_count == 1
        assert receipt1.oci_uri == receipt2.oci_uri
        assert receipt1.cosign_payload == receipt2.cosign_payload
