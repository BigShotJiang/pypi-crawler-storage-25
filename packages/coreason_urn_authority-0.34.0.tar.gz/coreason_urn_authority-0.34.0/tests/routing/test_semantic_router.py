# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-urn-authority>

"""Tests for the Semantic Router — URN-to-Verified-OCI Resolution.

Uses dependency inversion for the cosign subprocess runner and real
YAML ledger files. No mocking.
"""

from __future__ import annotations

import json
import subprocess
from pathlib import Path

import pytest
import yaml
from pydantic import ValidationError

from coreason_urn_authority.crypto.cosign_verifier import TopologicalSeveranceEvent
from coreason_urn_authority.routing.semantic_router import (
    VerifiedCapabilityReceipt,
    list_capabilities,
    resolve_capability,
)


def _write_test_ledger(tmp_path: Path) -> Path:
    """Write a test ledger with a valid Ed25519 DID."""
    # Generate a valid did:key for an Ed25519 key (32 zero bytes)
    raw_pubkey = bytes(32)
    multicodec_bytes = b"\xed\x01" + raw_pubkey
    n = int.from_bytes(multicodec_bytes, "big")
    alphabet = b"123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
    chars: list[int] = []
    while n > 0:
        n, remainder = divmod(n, 58)
        chars.append(alphabet[remainder])
    for byte in multicodec_bytes:
        if byte == 0:
            chars.append(alphabet[0])
        else:
            break
    encoded = bytes(reversed(chars)).decode("ascii")
    did_key = f"did:key:z{encoded}"

    ledger_path = tmp_path / "index.yaml"
    ledger_path.write_text(
        yaml.dump(
            {
                "capabilities": [
                    {
                        "urn": "urn:coreason:solver:test_v1",
                        "oci_uri": "ghcr.io/coreason-ai/test-solver:v1.0.0",
                        "authorized_signer_did": did_key,
                    },
                ]
            },
            default_flow_style=False,
        ),
        encoding="utf-8",
    )
    return ledger_path


def _success_runner(*args: object, **kwargs: object) -> subprocess.CompletedProcess[str]:
    """Deterministic runner that simulates successful cosign verification."""
    return subprocess.CompletedProcess(
        args=["cosign", "verify"],
        returncode=0,
        stdout=json.dumps([{"critical": {"identity": {}}}]),
        stderr="",
    )


def _failure_runner(*args: object, **kwargs: object) -> subprocess.CompletedProcess[str]:
    """Deterministic runner that simulates cosign verification failure."""
    return subprocess.CompletedProcess(
        args=["cosign", "verify"],
        returncode=1,
        stdout="",
        stderr="Error: no matching signatures: signature mismatch",
    )


class TestResolveCapability:
    """Tests for the resolve_capability function."""

    def test_successful_resolution(self, tmp_path: Path) -> None:
        ledger_path = _write_test_ledger(tmp_path)
        receipt = resolve_capability(
            "urn:coreason:solver:test_v1",
            ledger_path=ledger_path,
            runner=_success_runner,
        )
        assert isinstance(receipt, VerifiedCapabilityReceipt)
        assert receipt.urn == "urn:coreason:solver:test_v1"
        assert receipt.oci_uri == "ghcr.io/coreason-ai/test-solver:v1.0.0"

    def test_unknown_urn_raises_severance(self, tmp_path: Path) -> None:
        ledger_path = _write_test_ledger(tmp_path)
        with pytest.raises(TopologicalSeveranceEvent, match="not found in OCI Ledger"):
            resolve_capability(
                "urn:coreason:solver:nonexistent_v1",
                ledger_path=ledger_path,
                runner=_success_runner,
            )

    def test_tampered_signature_raises_severance(self, tmp_path: Path) -> None:
        ledger_path = _write_test_ledger(tmp_path)
        with pytest.raises(TopologicalSeveranceEvent, match="OCI signature verification failed"):
            resolve_capability(
                "urn:coreason:solver:test_v1",
                ledger_path=ledger_path,
                runner=_failure_runner,
            )

    def test_receipt_is_immutable(self, tmp_path: Path) -> None:
        ledger_path = _write_test_ledger(tmp_path)
        receipt = resolve_capability(
            "urn:coreason:solver:test_v1",
            ledger_path=ledger_path,
            runner=_success_runner,
        )
        with pytest.raises(ValidationError):
            receipt.urn = "tampered"

    def test_missing_ledger_raises_severance(self, tmp_path: Path) -> None:
        with pytest.raises(TopologicalSeveranceEvent, match="OCI Ledger not found"):
            resolve_capability(
                "urn:coreason:solver:test_v1",
                ledger_path=tmp_path / "nonexistent.yaml",
                runner=_success_runner,
            )


class TestListCapabilities:
    """Tests for the list_capabilities function."""

    def test_list_returns_entries(self, tmp_path: Path) -> None:
        ledger_path = _write_test_ledger(tmp_path)
        entries = list_capabilities(ledger_path=ledger_path)
        assert len(entries) == 1
        assert entries[0].urn == "urn:coreason:solver:test_v1"

    def test_list_empty_ledger(self, tmp_path: Path) -> None:
        ledger_path = tmp_path / "index.yaml"
        ledger_path.write_text(yaml.dump({"capabilities": []}), encoding="utf-8")
        entries = list_capabilities(ledger_path=ledger_path)
        assert entries == []


class TestAuthorizedTenantDID:
    """Tests for authorized tenant DID validation."""

    def test_authorized_did_success(self, tmp_path: Path) -> None:
        ledger_path = _write_test_ledger(tmp_path)

        # Determine the DID from the test ledger
        from coreason_urn_authority.ledger.loader import load_ledger

        entries = load_ledger(ledger_path)
        did = entries[0].authorized_signer_did

        import os

        old_val = os.environ.get("COREASON_AUTHORIZED_DIDS")
        try:
            os.environ["COREASON_AUTHORIZED_DIDS"] = did
            receipt = resolve_capability(
                "urn:coreason:solver:test_v1",
                ledger_path=ledger_path,
                runner=_success_runner,
            )
            assert receipt.authorized_signer_did == did
        finally:
            if old_val is not None:
                os.environ["COREASON_AUTHORIZED_DIDS"] = old_val
            else:
                del os.environ["COREASON_AUTHORIZED_DIDS"]

    def test_unauthorized_did_failure(self, tmp_path: Path) -> None:
        ledger_path = _write_test_ledger(tmp_path)

        import os

        old_val = os.environ.get("COREASON_AUTHORIZED_DIDS")
        try:
            os.environ["COREASON_AUTHORIZED_DIDS"] = "did:key:z6MkhaXgBZDvotDkL5257faiztiuC2ZXsdY4SSgMnh3YEFWbYB"
            with pytest.raises(TopologicalSeveranceEvent, match="Unauthorized Signer"):
                resolve_capability(
                    "urn:coreason:solver:test_v1",
                    ledger_path=ledger_path,
                    runner=_success_runner,
                )
        finally:
            if old_val is not None:
                os.environ["COREASON_AUTHORIZED_DIDS"] = old_val
            else:
                del os.environ["COREASON_AUTHORIZED_DIDS"]
