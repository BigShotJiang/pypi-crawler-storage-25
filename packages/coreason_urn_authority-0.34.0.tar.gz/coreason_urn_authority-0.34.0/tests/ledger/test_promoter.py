# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Tests for the OCI Artifact Ledger Promoter."""

from __future__ import annotations

from pathlib import Path

from coreason_urn_authority.ledger.loader import load_ledger
from coreason_urn_authority.ledger.promoter import append_to_ledger


def test_append_to_ledger_success(tmp_path: Path) -> None:
    ledger_path = tmp_path / "index.yaml"
    # Create initial file with comments
    ledger_path.write_text(
        "# CoReason OCI Artifact Ledger\n"
        "# Comments should be preserved!\n"
        "capabilities:\n"
        '  - urn: "urn:coreason:solver:existing_v1"\n'
        '    oci_uri: "ghcr.io/existing:v1"\n'
        '    authorized_signer_did: "did:key:z6MkExisting"\n',
        encoding="utf-8",
    )

    # Append new capability
    append_to_ledger(
        ledger_path=ledger_path,
        urn="urn:coreason:solver:new_v1",
        oci_uri="ghcr.io/new:v1",
        did="did:key:z6MkNew",
        tenant_cid="urn:tenant:coreason:custom",
        mcp_namespace="io.github.new/server",
    )

    # Verify content loaded successfully
    entries = load_ledger(ledger_path)
    assert len(entries) == 2
    assert entries[0].urn == "urn:coreason:solver:existing_v1"
    assert entries[1].urn == "urn:coreason:solver:new_v1"
    assert entries[1].mcp_registry is not None
    assert entries[1].mcp_registry.namespace == "io.github.new/server"

    # Verify comments are preserved in raw file
    raw_content = ledger_path.read_text(encoding="utf-8")
    assert "# CoReason OCI Artifact Ledger" in raw_content
    assert "# Comments should be preserved!" in raw_content
