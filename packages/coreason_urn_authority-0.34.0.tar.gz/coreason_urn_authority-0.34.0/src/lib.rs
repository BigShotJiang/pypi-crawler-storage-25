// Copyright (c) 2026 CoReason, Inc.
//
// This software is proprietary and dual-licensed.
// Licensed under the Prosperity Public License 3.0 (the "License").
// A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
// For details, see the LICENSE file.
// Commercial use beyond a 30-day trial requires a separate license.
//
// Source Code: <https://github.com/CoReason-AI/coreason-urn-authority>

#[cfg(feature = "pyo3")]
use pyo3::prelude::*;

#[cfg(feature = "pyo3")]
#[pyfunction]
pub fn extract_public_key_pem_from_did(did_key: &str) -> PyResult<String> {
    use base64::Engine;

    if !did_key.starts_with("did:key:z") {
        let got = if did_key.len() > 20 { &did_key[..20] } else { did_key };
        return Err(pyo3::exceptions::PyValueError::new_err(format!(
            "Invalid DID format: expected 'did:key:z...' prefix, got '{}...'",
            got
        )));
    }
    let suffix = &did_key["did:key:z".len()..];
    let decoded = bs58::decode(suffix)
        .into_vec()
        .map_err(|e| {
            pyo3::exceptions::PyValueError::new_err(format!(
                "Failed to base58-decode DID key material: {}",
                e
            ))
        })?;

    if !decoded.starts_with(b"\xed\x01") {
        let got_hex = if decoded.len() >= 2 {
            format!("{:02x}{:02x}", decoded[0], decoded[1])
        } else {
            hex::encode(&decoded)
        };
        return Err(pyo3::exceptions::PyValueError::new_err(format!(
            "Unsupported key type: expected Ed25519 multicodec prefix (0xed01), got {}",
            got_hex
        )));
    }

    let raw_pubkey = &decoded[2..];
    if raw_pubkey.len() != 32 {
        return Err(pyo3::exceptions::PyValueError::new_err(format!(
            "Invalid Ed25519 key length: expected 32 bytes, got {}",
            raw_pubkey.len()
        )));
    }

    // SPKI OID and BIT STRING prefix for Ed25519 (OID 1.3.101.112)
    let asn1_oid = b"\x30\x05\x06\x03\x2b\x65\x70";
    let bit_string_prefix = b"\x03\x21\x00";
    let spki_len = asn1_oid.len() + bit_string_prefix.len() + raw_pubkey.len();

    let mut spki = Vec::with_capacity(2 + spki_len);
    spki.push(0x30); // SEQUENCE
    spki.push(spki_len as u8);
    spki.extend_from_slice(asn1_oid);
    spki.extend_from_slice(bit_string_prefix);
    spki.extend_from_slice(raw_pubkey);

    let b64_pubkey = base64::engine::general_purpose::STANDARD.encode(&spki);

    // Split base64 into 64-char lines to construct canonical PEM format
    let mut pem_body = String::new();
    let mut chars = b64_pubkey.chars();
    while let Some(chunk) = {
        let mut c = String::new();
        for _ in 0..64 {
            if let Some(ch) = chars.next() {
                c.push(ch);
            } else {
                break;
            }
        }
        if c.is_empty() { None } else { Some(c) }
    } {
        pem_body.push_str(&chunk);
        pem_body.push('\n');
    }

    if pem_body.ends_with('\n') {
        pem_body.pop();
    }

    let pem = format!("-----BEGIN PUBLIC KEY-----\n{}\n-----END PUBLIC KEY-----\n", pem_body);
    Ok(pem)
}

#[cfg(feature = "pyo3")]
#[pyfunction]
pub fn compute_canonical_hash(payload: &str) -> String {
    use sha2::{Digest, Sha256};

    let normalized = payload.replace("\r\n", "\n");
    let mut hasher = Sha256::new();
    hasher.update(normalized.as_bytes());
    hex::encode(hasher.finalize())
}

#[cfg(feature = "pyo3")]
#[pymodule]
fn coreason_urn_authority_rust(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(extract_public_key_pem_from_did, m)?)?;
    m.add_function(wrap_pyfunction!(compute_canonical_hash, m)?)?;
    Ok(())
}
