# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-urn-authority>

"""Cosign OCI Artifact Signature Verifier.

Delegates 100% of cryptographic verification to the industry-standard
Sigstore Cosign binary.  This module is a thin, typed Python wrapper
that shells out to ``cosign verify`` and parses the result.

Borrow, Don't Build: We borrow Cosign rather than building a custom
OCI registry client or reimplementing signature verification.
"""

from __future__ import annotations

import base64
import functools
import json
import subprocess
import tempfile
from collections.abc import Callable
from pathlib import Path
from typing import Any

from coreason_manifest.spec.ontology import CoreasonBaseState
from pydantic import Field

_RUST_VERIFIER: Any = None
try:
    from coreason_urn_authority import coreason_urn_authority_rust

    _RUST_VERIFIER = coreason_urn_authority_rust
except ImportError:
    pass

# ────────────────────────────────────────────────────────────────────
# Exceptions
# ────────────────────────────────────────────────────────────────────


class TopologicalSeveranceEvent(Exception):
    """Raised when signature verification fails or a URN cannot be resolved.

    This is the cryptographic equivalent of a circuit breaker — the
    request is dropped and the caller is notified of the failure.
    """


# ────────────────────────────────────────────────────────────────────
# Data Structures
# ────────────────────────────────────────────────────────────────────


class CosignVerificationReceipt(CoreasonBaseState):
    """AGENT INSTRUCTION: A cryptographically frozen receipt produced after successful
    Cosign OCI artifact signature verification. Immutable post-creation.

    CAUSAL AFFORDANCE: Provides the verified OCI URI and raw cosign JSON payload
    to downstream routing and orchestration systems.

    EPISTEMIC BOUNDS: Frozen via CoreasonBaseState. The oci_uri is bounded to
    256 characters. The cosign_payload preserves the raw Cosign CLI output.

    MCP ROUTING TRIGGERS: OCI Verification, Cosign Receipt, Supply Chain Security,
    Sigstore Attestation, Artifact Provenance
    """

    oci_uri: str = Field(
        description="The verified OCI artifact URI that passed Cosign signature verification.",
        max_length=256,
    )
    cosign_payload: dict[str, Any] | list[Any] = Field(
        description="The raw JSON payload returned by the cosign verify command.",
    )


# ────────────────────────────────────────────────────────────────────
# DID Key Extraction
# ────────────────────────────────────────────────────────────────────

# Multicodec prefix for Ed25519 public keys (0xed01)
_ED25519_MULTICODEC_PREFIX = b"\xed\x01"

# Base58 Bitcoin alphabet
_BASE58_ALPHABET = b"123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"


def _base58_decode(encoded: str) -> bytes:
    """Decode a Base58-encoded string (Bitcoin alphabet).

    Borrow vs. Build: We implement a minimal base58 decoder here rather
    than pulling in a full dependency for a single 15-line function.
    The alternative (``base58`` PyPI package) would add a dependency for
    a trivial operation.
    """
    n = 0
    try:
        for char in encoded.encode("ascii"):
            if char not in _BASE58_ALPHABET:
                raise ValueError(f"Non-base58 character discovered: {chr(char)}")
            n = n * 58 + _BASE58_ALPHABET.index(char)
    except ValueError as e:
        raise ValueError(f"Malformed DID representation: {e}") from e

    # Convert integer to bytes
    result = n.to_bytes((n.bit_length() + 7) // 8, byteorder="big") if n > 0 else b""

    # Preserve leading zeros
    pad_count = 0
    for char in encoded.encode("ascii"):
        if char == _BASE58_ALPHABET[0]:
            pad_count += 1
        else:
            break

    return b"\x00" * pad_count + result


def extract_public_key_pem_from_did(did_key: str) -> str:
    """Extract an Ed25519 public key in PEM format from a ``did:key:`` identifier.

    The ``did:key:`` method encodes the public key as a multibase-encoded
    multicodec value.  For Ed25519 keys, the format is:

        did:key:z<base58btc(0xed01 + 32-byte-pubkey)>

    This function decodes the key material and wraps it in SubjectPublicKeyInfo
    ASN.1 DER encoding, then base64-encodes it into PEM format for Cosign.

    Args:
        did_key: A W3C DID in ``did:key:z6Mk...`` format.

    Returns:
        PEM-encoded Ed25519 public key string.

    Raises:
        TopologicalSeveranceEvent: If the DID format is invalid.
    """
    if _RUST_VERIFIER is not None:
        try:
            return str(_RUST_VERIFIER.extract_public_key_pem_from_did(did_key))
        except ValueError as e:
            raise TopologicalSeveranceEvent(str(e)) from e
        except Exception:  # nosec B110 # noqa: S110
            pass

    if not did_key.startswith("did:key:z"):
        raise TopologicalSeveranceEvent(f"Invalid DID format: expected 'did:key:z...' prefix, got '{did_key[:20]}...'")

    # Strip "did:key:z" prefix — 'z' indicates base58btc encoding
    encoded = did_key[len("did:key:z") :]

    try:
        decoded = _base58_decode(encoded)
    except (ValueError, IndexError) as e:
        raise TopologicalSeveranceEvent(f"Failed to base58-decode DID key material: {e}") from e

    # Verify Ed25519 multicodec prefix
    if not decoded.startswith(_ED25519_MULTICODEC_PREFIX):
        raise TopologicalSeveranceEvent(
            f"Unsupported key type: expected Ed25519 multicodec prefix (0xed01), got {decoded[:2].hex()}"
        )

    raw_pubkey = decoded[len(_ED25519_MULTICODEC_PREFIX) :]
    if len(raw_pubkey) != 32:
        raise TopologicalSeveranceEvent(f"Invalid Ed25519 key length: expected 32 bytes, got {len(raw_pubkey)}")

    # Wrap in SubjectPublicKeyInfo ASN.1 DER for Ed25519 (OID 1.3.101.112)
    # This is the standard encoding that Cosign expects for --key verification.
    #   SEQUENCE {
    #     SEQUENCE { OID 1.3.101.112 }
    #     BIT STRING (0x00 + raw_pubkey)
    #   }
    asn1_oid = b"\x30\x05\x06\x03\x2b\x65\x70"  # SEQUENCE { OID 1.3.101.112 }
    bit_string = b"\x03\x21\x00" + raw_pubkey  # BIT STRING (33 bytes: 0x00 + 32)
    spki = b"\x30" + bytes([len(asn1_oid) + len(bit_string)]) + asn1_oid + bit_string

    pem_body = base64.b64encode(spki).decode("ascii")
    return f"-----BEGIN PUBLIC KEY-----\n{pem_body}\n-----END PUBLIC KEY-----\n"


# ────────────────────────────────────────────────────────────────────
# Type alias for the subprocess runner (dependency inversion for testing)
# ────────────────────────────────────────────────────────────────────

SubprocessRunner = Callable[..., subprocess.CompletedProcess[str]]


# ────────────────────────────────────────────────────────────────────
# Public API
# ────────────────────────────────────────────────────────────────────


@functools.lru_cache(maxsize=1024)
def _verify_oci_signature_cached(oci_uri: str, public_key_pem: str) -> CosignVerificationReceipt:
    return _verify_oci_signature_impl(oci_uri, public_key_pem, subprocess.run)


def _verify_oci_signature_impl(
    oci_uri: str,
    public_key_pem: str,
    run: SubprocessRunner,
) -> CosignVerificationReceipt:
    # 1. Block basic argument injection upfront
    if oci_uri.strip().startswith("-"):
        raise TopologicalSeveranceEvent(f"Security Exception: Malformed or hostile OCI URI format detected: {oci_uri}")

    with tempfile.NamedTemporaryFile(
        mode="w",
        suffix=".pem",
        delete=False,
    ) as key_file:
        key_file.write(public_key_pem)
        key_path = Path(key_file.name)

    try:
        result = run(
            [
                "cosign",
                "verify",
                "--key",
                str(key_path),
                "--output",
                "json",
                "--",
                oci_uri,
            ],
            capture_output=True,
            text=True,
            check=False,
        )
    except FileNotFoundError as e:
        raise TopologicalSeveranceEvent(
            "Cosign binary not found. Install cosign: https://docs.sigstore.dev/cosign/system_config/installation/"
        ) from e
    finally:
        key_path.unlink(missing_ok=True)

    if result.returncode != 0:
        raise TopologicalSeveranceEvent(f"OCI signature verification failed for '{oci_uri}': {result.stderr.strip()}")

    try:
        payload = json.loads(result.stdout)
    except json.JSONDecodeError:
        # Cosign succeeded but output wasn't valid JSON — treat as success
        # with empty payload (some cosign versions output text on success).
        payload = {"raw_output": result.stdout.strip()}

    return CosignVerificationReceipt(oci_uri=oci_uri, cosign_payload=payload)


def verify_oci_signature(
    oci_uri: str,
    public_key_pem: str,
    *,
    runner: SubprocessRunner | None = None,
) -> CosignVerificationReceipt:
    """Verify an OCI artifact signature using the Cosign binary.

    Writes the PEM-encoded public key to a temporary file, then shells
    out to ``cosign verify --key <tmpfile> <oci_uri>``.

    Args:
        oci_uri: The OCI artifact URI (e.g. ``ghcr.io/coreason-ai/dowhy-solver:v1.2.0``).
        public_key_pem: PEM-encoded Ed25519 public key.
        runner: Optional subprocess runner for dependency inversion.
            Defaults to ``subprocess.run``.

    Returns:
        A ``CosignVerificationReceipt`` on success.

    Raises:
        TopologicalSeveranceEvent: If signature verification fails or
            the cosign binary is not available.
    """
    if runner is None:
        return _verify_oci_signature_cached(oci_uri, public_key_pem)
    return _verify_oci_signature_impl(oci_uri, public_key_pem, runner)


def compute_canonical_hash(payload: str) -> str:
    """Normalize line endings to LF and compute SHA-256 hash."""
    if _RUST_VERIFIER is not None:
        try:
            return str(_RUST_VERIFIER.compute_canonical_hash(payload))
        except Exception:  # nosec B110 # noqa: S110
            pass

    import hashlib

    normalized = payload.replace("\r\n", "\n")
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()


def verify_code_attestation(code_path: Path, expected_hash_or_path: str | Path | None = None) -> None:
    """Verifies that the code fingerprint matches the registry signature or sidecar hash.

    If expected_hash_or_path is a string matching SHA-256 format, we verify against it.
    If it is a path, we verify against the content of that path.
    If it is None, we look for a sidecar '<code_path>.hash' or '<code_path>.<suffix>.hash' file.
    Raises TopologicalSeveranceEvent on mismatch or missing verification resource.
    """
    if not code_path.exists():
        raise TopologicalSeveranceEvent(f"Attestation target code file does not exist: {code_path}")

    # Compute actual canonical hash
    try:
        content = code_path.read_text(encoding="utf-8")
        actual_hash = compute_canonical_hash(content)
    except Exception as e:
        raise TopologicalSeveranceEvent(f"Failed to read and hash target file {code_path}: {e}") from e

    expected_hash = ""

    if expected_hash_or_path is None:
        # Check standard sidecar patterns
        sidecar_1 = code_path.with_suffix(code_path.suffix + ".hash")
        sidecar_2 = code_path.parent / (code_path.name + ".hash")
        if sidecar_1.exists():
            expected_hash = sidecar_1.read_text(encoding="utf-8").strip()
        elif sidecar_2.exists():
            expected_hash = sidecar_2.read_text(encoding="utf-8").strip()
        else:
            raise TopologicalSeveranceEvent(f"No sidecar hash file found for code path: {code_path}")
    elif isinstance(expected_hash_or_path, Path):
        if not expected_hash_or_path.exists():
            raise TopologicalSeveranceEvent(f"Expected hash file path does not exist: {expected_hash_or_path}")
        expected_hash = expected_hash_or_path.read_text(encoding="utf-8").strip()
    else:
        # It's a hash string
        expected_hash = str(expected_hash_or_path).strip()

    if not expected_hash:
        raise TopologicalSeveranceEvent(f"Empty expected hash for code verification of {code_path}")

    import secrets

    if not secrets.compare_digest(actual_hash, expected_hash):
        raise TopologicalSeveranceEvent(
            f"Zero-Trust Attestation Handshake Failed: Code signature mismatch for '{code_path.name}'. "
            f"Expected: {expected_hash[:16]}..., Actual: {actual_hash[:16]}..."
        )
