# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-urn-authority>

"""Semantic Router — URN-to-Verified-OCI Resolution.

Resolves CoReason URNs to cryptographically verified OCI artifact URIs.
The routing flow is:

1. Look up the URN in the OCI Artifact Ledger (``ledger/index.yaml``).
2. Extract the authorized signer's public key from their DID.
3. Verify the OCI artifact signature via Cosign.
4. Return the verified OCI URI to the caller.

If any step fails, a ``TopologicalSeveranceEvent`` is raised and the
request is dropped.
"""

from __future__ import annotations

import json
import os
import time
import urllib.request
from pathlib import Path
from typing import Literal

from coreason_manifest.spec.ontology import CoreasonBaseState
from pydantic import Field

from coreason_urn_authority.crypto.cosign_verifier import (
    SubprocessRunner,
    TopologicalSeveranceEvent,
    extract_public_key_pem_from_did,
    verify_oci_signature,
)
from coreason_urn_authority.ledger.loader import (
    LedgerEntry,
    load_ledger,
    resolve_urn,
)

# ────────────────────────────────────────────────────────────────────
# Data Structures
# ────────────────────────────────────────────────────────────────────


class VerifiedCapabilityReceipt(CoreasonBaseState):
    """AGENT INSTRUCTION: A cryptographically frozen receipt proving that a CoReason URN
    was successfully resolved to an OCI artifact whose Cosign signature was verified
    against the authorized signer's DID. Immutable post-creation.

    CAUSAL AFFORDANCE: Provides the verified OCI URI to the coreason-ecosystem gateway
    and coreason-runtime orchestrator for secure artifact pull and WASM instantiation.

    EPISTEMIC BOUNDS: Frozen via CoreasonBaseState. All string fields are bounded.
    The receipt is only produced after successful Cosign verification — it cannot
    be constructed speculatively.

    MCP ROUTING TRIGGERS: Verified Capability, OCI Trust Receipt, URN Resolution,
    Supply Chain Attestation, Cosign Verification
    """

    urn: str = Field(
        description="The resolved CoReason URN.",
        max_length=256,
    )
    oci_uri: str = Field(
        description="The cryptographically verified OCI artifact URI.",
        max_length=512,
    )
    authorized_signer_did: str = Field(
        description="The DID of the signer whose Cosign signature was verified.",
        max_length=256,
    )
    license_tier: Literal["prosperity-3.0", "commercial"] = Field(
        description="The licensing class of this capability. "
        "'prosperity-3.0' = copyright owned by CoReason, Inc. (CLA-assigned). "
        "'commercial' = tenant retains IP sovereignty under commercial agreement.",
        default="prosperity-3.0",
    )


# ────────────────────────────────────────────────────────────────────
# Public API
# ────────────────────────────────────────────────────────────────────


def is_authorized_tenant_did(did: str) -> bool:
    """Checks whether the signer DID is authorized under the active trust anchors."""
    auth_dids_env = os.environ.get("COREASON_AUTHORIZED_DIDS")
    if not auth_dids_env:
        return True

    authorized_dids = [d.strip() for d in auth_dids_env.split(",") if d.strip()]
    if not authorized_dids:
        return True

    return did in authorized_dids


def resolve_capability(
    urn: str,
    *,
    ledger_path: Path | None = None,
    runner: SubprocessRunner | None = None,
) -> VerifiedCapabilityReceipt:
    """Resolve a URN to a cryptographically verified OCI artifact URI.

    This is the primary entry-point for the Sovereign LLM Proxy and
    the ``coreason-ecosystem`` gateway.

    Args:
        urn: The CoReason URN to resolve (e.g. ``urn:coreason:solver:dowhy_v1``).
        ledger_path: Optional override for the ledger YAML path.
        runner: Optional subprocess runner for Cosign (dependency inversion).

    Returns:
        A ``VerifiedCapabilityReceipt`` containing the secure OCI URI.

    Raises:
        TopologicalSeveranceEvent: If the URN is not found, the DID is
            invalid, or the OCI signature verification fails.
    """
    # Step 1: Load ledger and resolve URN
    ledger = load_ledger(ledger_path)
    entry: LedgerEntry = resolve_urn(urn, ledger)

    # Per-request validation: query Vault to check if AST Guillotine is active and if the tenant has a valid license
    vault_addr = os.environ.get("VAULT_ADDR", "http://127.0.0.1:8200")
    vault_token = os.environ.get("VAULT_TOKEN", "dev-only-token")

    ast_guillotine_active = False
    gov_url = f"{vault_addr.rstrip('/')}/v1/secret/data/coreason/governance"
    gov_req = urllib.request.Request(gov_url)  # nosec B310 # noqa: S310
    gov_req.add_header("X-Vault-Token", vault_token)
    try:
        with urllib.request.urlopen(gov_req, timeout=2.0) as gov_resp:  # nosec B310 # noqa: S310
            if gov_resp.status == 200:
                gov_data = json.loads(gov_resp.read().decode())
                inner_gov = gov_data.get("data", {}).get("data", {})
                ast_guillotine_active = inner_gov.get("ast_guillotine_active") == "True"
    except Exception:  # nosec B110 # noqa: S110
        # Defaults to False on network or Vault missing errors to keep dev/test environments frictionless
        pass

    if ast_guillotine_active:
        license_valid = False
        lic_url = f"{vault_addr.rstrip('/')}/v1/secret/data/coreason/license/{entry.tenant_cid}"
        lic_req = urllib.request.Request(lic_url)  # nosec B310 # noqa: S310
        lic_req.add_header("X-Vault-Token", vault_token)
        try:
            with urllib.request.urlopen(lic_req, timeout=2.0) as lic_resp:  # nosec B310 # noqa: S310
                if lic_resp.status == 200:
                    lic_data = json.loads(lic_resp.read().decode())
                    envelope = lic_data.get("data", {}).get("data", {})
                    claims = envelope.get("claims", envelope)
                    if claims:
                        exp = claims.get("exp")
                        current_epoch = int(time.time())
                        if exp is None or int(exp) > current_epoch:
                            license_valid = True
        except Exception:  # nosec B110 # noqa: S110
            pass

        if not license_valid:
            raise TopologicalSeveranceEvent(
                f"License verification failed: AST Guillotine is active and no valid license found for tenant '{entry.tenant_cid}'."
            )

    # Verify if the signer's DID is authorized
    if not is_authorized_tenant_did(entry.authorized_signer_did):
        raise TopologicalSeveranceEvent(
            f"Unauthorized Signer: The DID '{entry.authorized_signer_did}' is not authorized."
        )

    # Step 2: Extract public key from the authorized signer's DID
    public_key_pem = extract_public_key_pem_from_did(entry.authorized_signer_did)

    # Step 3: Verify OCI artifact signature via Cosign
    verify_oci_signature(entry.oci_uri, public_key_pem, runner=runner)

    # Step 4: Return verified receipt
    return VerifiedCapabilityReceipt(
        urn=entry.urn,
        oci_uri=entry.oci_uri,
        authorized_signer_did=entry.authorized_signer_did,
        license_tier=entry.license_tier,
    )


def list_capabilities(
    *,
    ledger_path: Path | None = None,
) -> list[LedgerEntry]:
    """List all capabilities registered in the OCI Artifact Ledger.

    Args:
        ledger_path: Optional override for the ledger YAML path.

    Returns:
        A list of ``LedgerEntry`` objects.
    """
    return load_ledger(ledger_path)
