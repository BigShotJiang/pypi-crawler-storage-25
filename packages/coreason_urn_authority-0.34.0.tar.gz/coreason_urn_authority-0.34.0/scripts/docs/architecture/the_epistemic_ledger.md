# The Epistemic Ledger

*Documentation pending.*