# Quality Guillotines

*Documentation pending.*