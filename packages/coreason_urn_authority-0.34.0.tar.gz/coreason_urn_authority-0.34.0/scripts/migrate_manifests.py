# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-documentation>

import os

import yaml


def migrate_manifest(path: str) -> None:
    with open(path) as f:
        data = yaml.safe_load(f)

    if not data:
        return

    dirty = False

    if "tenant_cid" in data:
        owner = data.pop("tenant_cid")
        if "provenance" not in data:
            data["provenance"] = {}
        if "agents" not in data["provenance"]:
            data["provenance"]["agents"] = {}
        data["provenance"]["agents"]["owner"] = owner
        dirty = True

    prov = data.get("provenance", {})
    if "author_id" in prov:
        if "agents" not in prov:
            prov["agents"] = {}
        prov["agents"]["developer"] = prov.pop("author_id")
        dirty = True

    if "oracle_validator" in prov:
        if "agents" not in prov:
            prov["agents"] = {}
        prov["agents"]["auditor"] = prov.pop("oracle_validator")
        dirty = True

    if "cla_assignee" in prov:
        prov.pop("cla_assignee")
        dirty = True

    if "developer_tenant_cid" in prov:
        if "agents" not in prov:
            prov["agents"] = {}
        prov["agents"]["developer"] = prov.pop("developer_tenant_cid")
        dirty = True

    if dirty:
        with open(path, "w") as f:
            yaml.dump(data, f, sort_keys=False)
        print(f"Migrated {path}")


for root, _, files in os.walk("assets"):
    for f in files:
        if f == "manifest.yaml":
            migrate_manifest(os.path.join(root, f))
