from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import sys
from pathlib import Path

from .api import bbc_config_path, load_bbc_config, save_bbc_config
from .classify import classify
from .config import load_config
from .htb import challenge_info, download_challenge, submit_flag
from .models import ChallengeState
from .scanner import scan_files
from .skills import load_skill
from .state import load_state, new_state, save_state, validate_challenge_name
from .writeup import write_writeup


FLAG_RE = re.compile(r"^HTB\{.+\}$")


def _challenge_dirs(challenges_dir: Path) -> list[Path]:
    if not challenges_dir.exists():
        return []
    return sorted(
        (
            path
            for path in challenges_dir.iterdir()
            if path.is_dir() and (path / ".bbc.json").exists()
        ),
        key=lambda path: path.name.lower(),
    )


def _format_table(rows: list[tuple[str, str, str, str]]) -> str:
    headers = ("Challenge", "State", "Category", "IP")
    widths = [
        max(len(headers[0]), *(len(row[0]) for row in rows)) if rows else len(headers[0]),
        max(len(headers[1]), *(len(row[1]) for row in rows)) if rows else len(headers[1]),
        max(len(headers[2]), *(len(row[2]) for row in rows)) if rows else len(headers[2]),
        max(len(headers[3]), *(len(row[3]) for row in rows)) if rows else len(headers[3]),
    ]

    def border(left: str, fill: str, join: str, right: str) -> str:
        return left + join.join(fill * (width + 2) for width in widths) + right

    def render_row(columns: tuple[str, str, str, str]) -> str:
        return "│ " + " │ ".join(value.ljust(width) for value, width in zip(columns, widths, strict=True)) + " │"

    lines = [
        border("┌", "─", "┬", "┐"),
        render_row(headers),
        border("├", "─", "┼", "┤"),
    ]
    lines.extend(render_row(row) for row in rows)
    lines.append(border("└", "─", "┴", "┘"))
    return "\n".join(lines)


def cmd_init(args: argparse.Namespace) -> int:
    config = load_config()
    validate_challenge_name(args.name)
    state = new_state(config.challenges_dir, args.name)
    try:
        description, htb_id, category = challenge_info(Path(state.root), args.name)
        state.description = description
        state.htb_id = htb_id
        state.category = classify(description, Path(state.root), category)
        state.status = "initialized"
    except RuntimeError as exc:
        state.status = "initialized"
        save_state(config.challenges_dir, state)
        print(f"Initialized locally, but HTB metadata failed: {exc}", file=sys.stderr)
        return 2
    save_state(config.challenges_dir, state)
    print(f"Initialized {state.name} ({state.category}, id={state.htb_id or 'unknown'})")
    return 0


def cmd_download(args: argparse.Namespace) -> int:
    config = load_config()
    validate_challenge_name(args.name)
    state = load_state(config.challenges_dir, args.name)
    started = download_challenge(
        Path(state.root),
        name=state.name,
        htb_id=state.htb_id,
        destination=Path(state.artifacts),
        start=args.start,
    )
    state.instance.started = args.start
    if started:
        host = started.get("docker_ip")
        ports = started.get("docker_ports") or []
        state.instance.host = str(host) if host else None
        state.instance.target = f"{host}:{ports[0]}" if host and ports else str(host) if host else None
    state.status = "downloaded"
    state = scan_files(state)
    state.category = classify(state.description, Path(state.root), state.category)
    save_state(config.challenges_dir, state)
    print(f"Downloaded {state.name} into {state.artifacts}")
    return 0


def cmd_info(args: argparse.Namespace) -> int:
    config = load_config()
    if args.name:
        validate_challenge_name(args.name)
        state = load_state(config.challenges_dir, args.name)
        print(f"name: {state.name}")
        print(f"status: {state.status}")
        print(f"category: {state.category or 'unknown'}")
        print(f"htb_id: {state.htb_id or 'unknown'}")
        print(f"host: {state.instance.host or 'unknown'}")
        print(f"target: {state.instance.target or 'unknown'}")
        print(f"root: {state.root}")
        print(f"files: {len(state.findings.get('files', []))}")
        print(f"candidate_flags: {len(state.findings.get('candidate_flags', []))}")
        print(f"submitted: {state.submission.valid}")
        return 0

    paths = _challenge_dirs(config.challenges_dir)
    if not paths:
        print(f"No challenges found in {config.challenges_dir}")
        return 0

    rows: list[tuple[str, str, str, str]] = []
    for path in paths:
        try:
            state = ChallengeState.from_json(
                json.loads((path / ".bbc.json").read_text(encoding="utf-8"))
            )
        except (OSError, json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
            rows.append((path.name, "invalid", "-", f"error: {type(exc).__name__}"))
            continue
        rows.append((state.name, state.status, state.category or "unknown", state.instance.target or state.instance.host or "-"))
    print(_format_table(rows))
    return 0


def cmd_status(args: argparse.Namespace) -> int:
    config = load_config()
    validate_challenge_name(args.name)
    state = load_state(config.challenges_dir, args.name)
    print(f"name: {state.name}")
    print(f"status: {state.status}")
    print(f"category: {state.category or 'unknown'}")
    print(f"htb_id: {state.htb_id or 'unknown'}")
    print(f"host: {state.instance.host or 'unknown'}")
    print(f"target: {state.instance.target or 'unknown'}")
    print(f"root: {state.root}")
    print(f"candidate_flags: {len(state.findings.get('candidate_flags', []))}")
    print(f"submitted: {state.submission.valid}")
    return 0


def cmd_skill(args: argparse.Namespace) -> int:
    config = load_config()
    validate_challenge_name(args.name)
    state = load_state(config.challenges_dir, args.name)
    category = state.category or "misc"
    print(load_skill(config.skills_dir, category))
    return 0


def cmd_rm(args: argparse.Namespace) -> int:
    config = load_config()
    validate_challenge_name(args.name)
    root = config.challenges_dir / args.name
    if not root.exists():
        raise FileNotFoundError(f"No challenge workspace found for {args.name!r}.")
    if not (root / ".bbc.json").exists():
        raise RuntimeError(f"Refusing to remove {root}: missing .bbc.json sentinel.")
    confirmation = input(f"Remove challenge workspace {args.name!r} at {root}? [y/N]: ").strip().lower()
    if confirmation not in {"y", "yes"}:
        print("Aborted.")
        return 1
    shutil.rmtree(root)
    print(f"Removed {root}")
    return 0


def cmd_submit(args: argparse.Namespace) -> int:
    config = load_config()
    validate_challenge_name(args.name)
    state = load_state(config.challenges_dir, args.name)
    if not FLAG_RE.match(args.flag):
        print("Flag must match HTB{...}", file=sys.stderr)
        return 2
    if state.htb_id is None:
        print("Challenge ID is unknown. Re-run init or edit .bbc.json.", file=sys.stderr)
        return 2
    state.submission.attempts.append(args.flag)
    valid = submit_flag(Path(state.root), htb_id=state.htb_id, flag=args.flag)
    state.submission.valid = valid
    if valid:
        state.submission.flag = args.flag
        state.status = "done"
        skill_text = load_skill(config.skills_dir, state.category or "misc")
        writeup_path = write_writeup(state, skill_text)
        save_state(config.challenges_dir, state)
        print(f"Flag accepted. Writeup created: {writeup_path}")
        return 0
    save_state(config.challenges_dir, state)
    print("Flag rejected.")
    return 1


def cmd_writeup(args: argparse.Namespace) -> int:
    config = load_config()
    validate_challenge_name(args.name)
    state = load_state(config.challenges_dir, args.name)
    skill_text = load_skill(config.skills_dir, state.category or "misc")
    path = write_writeup(state, skill_text)
    print(f"Writeup written: {path}")
    return 0


def cmd_config_set_token(args: argparse.Namespace) -> int:
    path = save_bbc_config(
        api_key=args.token,
        api_base_url=args.api_base,
        verify_ssl=not args.no_verify_ssl,
    )
    print(f"Config written: {path}")
    return 0


def cmd_config_show(args: argparse.Namespace) -> int:
    path = bbc_config_path()
    try:
        config = load_bbc_config()
    except Exception as exc:
        print(f"path: {path}")
        print(f"configured: false")
        print(f"error: {exc}")
        return 1
    print(f"path: {path}")
    print("configured: true")
    print(f"api_base_url: {config.api_base_url}")
    print(f"user_agent: {config.user_agent}")
    print(f"verify_ssl: {config.verify_ssl}")
    print("api_key: <redacted>")
    return 0


def prepare_solve_context(name: str, mode: str) -> tuple[ChallengeState, Path, str]:
    config = load_config()
    validate_challenge_name(name)
    state = load_state(config.challenges_dir, name)
    state.mode = mode
    state.status = "working"
    state = scan_files(state)
    state.category = classify(state.description, Path(state.root), state.category)
    save_state(config.challenges_dir, state)
    skill = load_skill(config.skills_dir, state.category or "misc")
    prompt_dir = Path(state.root) / "prompts"
    prompt_dir.mkdir(parents=True, exist_ok=True)
    prompt_path = prompt_dir / "solve_context.md"
    prompt_path.write_text(
        "\n".join(
            (
                f"# {state.name}",
                "",
                f"Mode: `{mode}`",
                f"Category: `{state.category}`",
                "",
                "## Description",
                "",
                state.description.strip() or "No description captured.",
                "",
                "## Skill",
                "",
                skill,
            )
        ),
        encoding="utf-8",
    )
    return state, prompt_path, skill


def build_codex_prompt(state: ChallengeState, prompt_path: Path) -> str:
    return f"""We are solving a Hack The Box challenge named {state.name}.

Use the working directory as the challenge root:
{state.root}

Read this solve context first:
{prompt_path}

Goal:
Find the HTB flag, keep notes in notes.md, preserve important commands/findings, and when a candidate flag is found submit it with:
bbc submit "{state.name}" --flag 'HTB{{...}}'

If the flag is accepted, generate or refine the writeup through the bbc workflow. Write the final writeup like a CTF player explaining their solve path, without mentioning AI.
"""


def launch_codex(state: ChallengeState, prompt_path: Path, mode: str, codex_bin: str = "codex") -> int:
    codex = shutil.which(codex_bin)
    if codex is None:
        print(f"codex executable not found: {codex_bin}", file=sys.stderr)
        print(f"Manual command: codex --cd {state.root!r} {build_codex_prompt(state, prompt_path)!r}", file=sys.stderr)
        return 1

    command = [codex, "--cd", state.root]
    if mode == "auto":
        command.append("--full-auto")
    else:
        command.extend(["--ask-for-approval", "on-request"])
    command.append(build_codex_prompt(state, prompt_path))
    os.execv(codex, command)
    return 1


def cmd_solve(args: argparse.Namespace) -> int:
    state, prompt_path, skill = prepare_solve_context(args.name, args.mode)
    print(f"Prepared {state.name} for {args.mode} mode.")
    print(f"Category: {state.category}")
    print(f"Prompt context: {prompt_path}")
    print("\nSkill guidance:\n")
    print(skill)
    print(f"\nWork directory: {state.root}")
    return 0


def cmd_assist(args: argparse.Namespace) -> int:
    args.mode = "assist"
    return cmd_solve(args)


def cmd_run(args: argparse.Namespace) -> int:
    state, prompt_path, skill = prepare_solve_context(args.name, "semi-auto")
    print(f"Prepared {state.name} for semi-auto mode.")
    print(f"Category: {state.category}")
    print(f"Prompt context: {prompt_path}")
    print(f"Work directory: {state.root}")
    if args.no_launch:
        print("\nSkill guidance:\n")
        print(skill)
        return 0
    return launch_codex(state, prompt_path, "semi-auto", args.codex_bin)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="bbc",
        description="Hack The Box challenge operator: create local workspaces, fetch challenge data, prepare Codex solve context, and submit flags.",
        epilog="Examples:\n  bbc init \"Execute\"\n  bbc download \"Execute\" --start\n  bbc info\n  bbc run \"Execute\" --no-launch",
        formatter_class=argparse.RawTextHelpFormatter,
    )
    sub = parser.add_subparsers(dest="command", required=True)

    init = sub.add_parser(
        "init",
        help="Create a local challenge workspace and fetch HTB metadata",
        description="Create a local workspace for a challenge and fetch its HTB description, ID, and initial category when available.",
    )
    init.add_argument("name")
    init.set_defaults(func=cmd_init)

    download = sub.add_parser(
        "download",
        help="Download challenge files and optionally start the HTB instance",
        description="Download challenge artifacts into the local workspace. Use --start to boot a remote HTB instance when the challenge supports it.",
    )
    download.add_argument("name")
    download.add_argument("-s", "--start", action="store_true", help="Start HTB instance after download")
    download.set_defaults(func=cmd_download)

    info = sub.add_parser(
        "info",
        help="List local challenge workspaces or show one workspace in detail",
        description="With no name, list all local challenge workspaces in a table. With a name, show detailed state for that challenge.",
    )
    info.add_argument("name", nargs="?")
    info.set_defaults(func=cmd_info)

    status = sub.add_parser(
        "status",
        help="Show detailed state for one challenge workspace",
        description="Show the saved local state for one challenge workspace, including HTB ID, category, instance target, and candidate-flag count.",
    )
    status.add_argument("name")
    status.set_defaults(func=cmd_status)

    skill = sub.add_parser(
        "skill",
        help="Print the category playbook for one challenge",
        description="Print the skill/playbook text currently selected for the challenge category.",
    )
    skill.add_argument("name")
    skill.set_defaults(func=cmd_skill)

    solve = sub.add_parser(
        "solve",
        help="Prepare solve context and print the category guidance",
        description="Refresh challenge findings, generate solve context files, and print the skill guidance without launching Codex.",
    )
    solve.add_argument("name")
    solve.add_argument("--mode", choices=("assist", "semi-auto", "auto"), default="assist")
    solve.set_defaults(func=cmd_solve)

    assist = sub.add_parser(
        "assist",
        help="Prepare assist-mode solve context",
        description="Alias for solve in assist mode. Refresh findings, generate prompt context, and print the selected skill guidance.",
    )
    assist.add_argument("name")
    assist.set_defaults(func=cmd_assist)

    run = sub.add_parser(
        "run",
        help="Prepare context and launch Codex in semi-auto mode",
        description="Refresh findings, generate solve context, and launch Codex in semi-auto mode unless --no-launch is used.",
    )
    run.add_argument("name")
    run.add_argument("--no-launch", action="store_true", help="Prepare context without starting Codex")
    run.add_argument("--codex-bin", default="codex", help="Codex executable to launch")
    run.set_defaults(func=cmd_run)

    submit = sub.add_parser(
        "submit",
        help="Submit a candidate HTB flag and generate the writeup on success",
        description="Submit a candidate HTB flag for the challenge. If HTB accepts it, mark the workspace done and generate the final writeup.",
    )
    submit.add_argument("name")
    submit.add_argument("--flag", required=True)
    submit.set_defaults(func=cmd_submit)

    writeup = sub.add_parser(
        "writeup",
        help="Generate or refresh the local writeup from notes and logs",
        description="Build the challenge writeup file from the saved challenge metadata, notes, and command log.",
    )
    writeup.add_argument("name")
    writeup.set_defaults(func=cmd_writeup)

    rm = sub.add_parser(
        "rm",
        help="Remove a local challenge workspace after confirmation",
        description="Delete a local challenge workspace directory after an interactive confirmation prompt.",
    )
    rm.add_argument("name")
    rm.set_defaults(func=cmd_rm)

    config = sub.add_parser(
        "config",
        help="Manage bbc configuration and the HTB API token",
        description="Inspect or update the local bbc configuration file used for HTB API access.",
    )
    config_sub = config.add_subparsers(dest="config_command", required=True)

    set_token = config_sub.add_parser(
        "set-token",
        help="Store the HTB personal access token in the local bbc config",
        description="Write the HTB personal access token and related API settings into the local bbc config file.",
    )
    set_token.add_argument("token")
    set_token.add_argument("--api-base", default="https://labs.hackthebox.com/api/")
    set_token.add_argument("--no-verify-ssl", action="store_true")
    set_token.set_defaults(func=cmd_config_set_token)

    show_config = config_sub.add_parser(
        "show",
        help="Show the current bbc config without exposing the token",
        description="Print the current bbc configuration values while redacting the HTB API token.",
    )
    show_config.set_defaults(func=cmd_config_show)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    if argv is None and len(sys.argv) == 1:
        parser.print_help()
        return 0
    args = parser.parse_args(argv)
    try:
        return args.func(args)
    except FileNotFoundError as exc:
        print(str(exc), file=sys.stderr)
        return 2
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        return 2
    except RuntimeError as exc:
        print(str(exc), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
