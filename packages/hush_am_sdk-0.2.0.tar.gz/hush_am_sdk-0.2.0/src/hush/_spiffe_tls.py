from __future__ import annotations
import datetime
import logging
from cryptography import x509
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.serialization import (
    Encoding,
    NoEncryption,
    PrivateFormat,
)
from OpenSSL import SSL, crypto
from spiffe import SpiffeId
from spiffe.workloadapi.x509_source import X509Source
from spiffetls import SpiffeSSLContext

LOG = logging.getLogger(__name__)


class _AuthorizingSpiffeSSLContext(SpiffeSSLContext):
    """Stdlib-shaped SSL context that mirrors go-spiffe's MTLSClientConfig.

    Subclasses ``SpiffeSSLContext`` purely to reuse its urllib3-port
    ``wrap_socket`` adapter (so httpx can talk to the underlying pyOpenSSL
    context). Bypasses ``SpiffeSSLContext.__init__`` because it would invoke
    ``spiffetls.context.create_ssl_context``, which loads the SPIRE bundle
    into an ``X509Store`` and lets OpenSSL run full ``X509_verify_cert``,
    including SSL-purpose checks (EKU/keyUsage/basicConstraints) that
    go-spiffe explicitly skips via ``ExtKeyUsageAny``.

    Instead we build the pyOpenSSL ``SSL.Context`` ourselves, load the SVID
    leaf+key+chain, subscribe to SPIRE rotations, and install a verify
    callback that defers to our own ``_verify_spiffe_chain`` at the leaf —
    matching go-spiffe's ``InsecureSkipVerify=true`` + ``VerifyPeerCertificate``
    (config.go:73-74 in v2.6.0).
    """

    def __init__(
        self,
        x509_source: X509Source,
        server_spiffe_id: SpiffeId,
    ) -> None:
        self.protocol = SSL.TLS_CLIENT_METHOD
        self._x509_source = x509_source
        self._server_spiffe_id = server_spiffe_id
        self._ctx = self._build_ctx()
        x509_source.subscribe_for_updates(self._rebuild_ctx)
        self.check_hostname = False

    def _build_ctx(self) -> SSL.Context:
        ctx = SSL.Context(self.protocol)
        _load_svid_into_context(ctx, self._x509_source)
        ctx.set_verify(
            SSL.VERIFY_PEER | SSL.VERIFY_FAIL_IF_NO_PEER_CERT,
            _spiffe_verify_callback(self._x509_source, self._server_spiffe_id),
        )
        return ctx

    def _rebuild_ctx(self) -> None:
        # On rotation, build a fresh SSL.Context and atomically swap instead
        # of mutating the live one. Attribute assignment is atomic under the
        # GIL, so concurrent handshake-initiations see either the old context
        # or the new one — never a half-loaded mix. In-flight SSL.Connection
        # objects keep their own ref to the old context and finish safely.
        # Also sidesteps add_extra_chain_cert accumulation across rotations,
        # since pyOpenSSL has no API to clear previously-added chain certs.
        self._ctx = self._build_ctx()


def _load_svid_into_context(ctx: SSL.Context, x509_source: X509Source) -> None:
    """Load the current SVID leaf+key+chain into a fresh pyOpenSSL context."""
    svid = x509_source.svid
    leaf_pem = svid.leaf.public_bytes(Encoding.PEM)
    leaf = crypto.load_certificate(crypto.FILETYPE_PEM, leaf_pem)
    ctx.use_certificate(leaf)

    key_pem = svid.private_key.private_bytes(
        encoding=Encoding.PEM,
        format=PrivateFormat.PKCS8,
        encryption_algorithm=NoEncryption(),
    )
    pkey = crypto.load_privatekey(crypto.FILETYPE_PEM, key_pem)
    ctx.use_privatekey(pkey)
    ctx.check_privatekey()

    for cert in svid.cert_chain[1:]:
        cert_pem = cert.public_bytes(Encoding.PEM)
        ctx.add_extra_chain_cert(crypto.load_certificate(crypto.FILETYPE_PEM, cert_pem))


def _spiffe_verify_callback(x509_source: X509Source, expected_spiffe_id: SpiffeId):
    """Verify callback that bypasses OpenSSL chain validation.

    Returns True at non-leaf depths (mirrors Go's ``InsecureSkipVerify=true``);
    at the leaf, runs our own chain verification against the live SPIRE
    bundle plus a SPIFFE-ID check.
    """

    def _verify(connection, _cert, _errno: int, depth: int, _preverify_ok: int) -> bool:
        if depth > 0:
            return True
        peer_chain = connection.get_peer_cert_chain() or []
        return _verify_spiffe_chain(peer_chain, x509_source, expected_spiffe_id)

    return _verify


def _verify_spiffe_chain(
    peer_chain: list,
    x509_source: X509Source,
    expected_spiffe_id: SpiffeId,
) -> bool:
    """Verify ``peer_chain`` against the SPIRE bundle, like x509svid.Verify.

    Mirrors the Go SDK's chain check: validity windows, signature on every
    edge, anchor in the trust-domain bundle, and matching leaf SPIFFE ID.
    No SSL-purpose / EKU enforcement — that's exactly what we're avoiding.
    """
    if not peer_chain:
        LOG.warning("server presented no certificates")
        return False
    chain = [c.to_cryptography() for c in peer_chain]
    leaf_id = _check_leaf_spiffe_id(chain[0], expected_spiffe_id)
    if leaf_id is None:
        return False
    if not _check_validity_windows(chain):
        return False
    if not _check_chain_signatures(chain):
        return False
    return _check_anchor(chain[-1], x509_source, leaf_id.trust_domain)


def _check_leaf_spiffe_id(leaf_cert, expected: SpiffeId) -> SpiffeId | None:
    leaf_uri = _cert_spiffe_uri(leaf_cert)
    if not leaf_uri:
        LOG.warning("leaf cert has no SPIFFE ID in SAN URIs")
        return None
    try:
        leaf_id = SpiffeId(leaf_uri)
    except Exception as exc:  # noqa: BLE001
        LOG.warning("invalid SPIFFE ID on leaf %r: %s", leaf_uri, exc)
        return None
    if leaf_id != expected:
        LOG.warning("server SPIFFE ID rejected: expected %s, got %s", expected, leaf_id)
        return None
    return leaf_id


def _check_validity_windows(chain: list) -> bool:
    now = datetime.datetime.now(datetime.timezone.utc)
    for i, cert in enumerate(chain):
        nb, na = cert.not_valid_before_utc, cert.not_valid_after_utc
        if now < nb or now > na:
            LOG.warning(
                "cert at depth %d outside validity window: not_before=%s"
                " not_after=%s now=%s",
                i,
                nb,
                na,
                now,
            )
            return False
    return True


def _check_chain_signatures(chain: list) -> bool:
    for i in range(len(chain) - 1):
        try:
            chain[i].verify_directly_issued_by(chain[i + 1])
        except (InvalidSignature, ValueError, TypeError) as exc:
            LOG.warning("chain signature failure at depth %d: %s", i, exc)
            return False
    return True


def _check_anchor(top, x509_source: X509Source, trust_domain) -> bool:
    try:
        bundle = (
            x509_source.get_x509_context().x509_bundle_set.get_bundle_for_trust_domain(
                trust_domain
            )
        )
    except Exception as exc:  # noqa: BLE001
        LOG.warning("failed to read SPIRE bundle for %s: %s", trust_domain, exc)
        return False
    if bundle is None:
        LOG.warning("no SPIRE bundle for trust domain %s", trust_domain)
        return False
    authorities = list(bundle.x509_authorities)
    top_der = top.public_bytes(Encoding.DER)
    if any(top_der == a.public_bytes(Encoding.DER) for a in authorities):
        return True
    for auth in authorities:
        try:
            top.verify_directly_issued_by(auth)
            return True
        except (InvalidSignature, ValueError, TypeError):
            continue
    LOG.warning(
        "no SPIRE authority for trust domain %s anchors the presented chain"
        " (top subject=%s)",
        trust_domain,
        top.subject.rfc4514_string(),
    )
    return False


def _cert_spiffe_uri(cert) -> str | None:
    """Return the SPIFFE URI from the cert's subjectAltName, or None if missing."""
    try:
        san = cert.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
    except x509.ExtensionNotFound:
        return None
    return next(
        (
            uri
            for uri in san.get_values_for_type(x509.UniformResourceIdentifier)
            if uri.startswith("spiffe://")
        ),
        None,
    )
