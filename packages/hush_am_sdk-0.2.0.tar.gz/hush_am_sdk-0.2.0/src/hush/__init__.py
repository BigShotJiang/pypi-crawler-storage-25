import threading
from hush.client import HEADER_POLICY_SNAPSHOT, HushClient
from hush.exceptions import (
    HushAuthError,
    HushBadRequestError,
    HushConfigError,
    HushError,
    HushFieldNotFoundError,
    HushNetworkError,
    HushSecretNotFoundError,
    HushServerError,
    HushSpiffeError,
)

__all__ = [
    "HushClient",
    "HEADER_POLICY_SNAPSHOT",
    "HushError",
    "HushConfigError",
    "HushSpiffeError",
    "HushAuthError",
    "HushNetworkError",
    "HushBadRequestError",
    "HushSecretNotFoundError",
    "HushFieldNotFoundError",
    "HushServerError",
    "get_client",
    "get_secret",
    "get_secret_field",
]

_client: HushClient | None = None
_client_lock = threading.Lock()


def get_client() -> HushClient:
    global _client
    if _client is None:
        with _client_lock:
            if _client is None:
                _client = HushClient()
    return _client


def get_secret(secret_name: str, token: str = "") -> dict:
    return get_client().get_secret(secret_name, token=token)


def get_secret_field(secret_name: str, field: str, token: str = "") -> str:
    return get_client().get_secret_field(secret_name, field, token=token)
