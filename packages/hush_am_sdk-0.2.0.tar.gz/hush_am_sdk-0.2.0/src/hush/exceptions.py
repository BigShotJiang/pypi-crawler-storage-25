from __future__ import annotations


class HushError(Exception):
    """Base class for all hush SDK errors."""


class HushConfigError(HushError, ValueError):
    """Required configuration (env var) is missing or invalid."""


class HushSpiffeError(HushError):
    """Failed to obtain an SVID from the SPIRE Workload API.

    Typical causes: SPIRE agent socket missing (no volume mounted), the
    workload is not registered, or the agent is unreachable.
    """


class HushAuthError(HushError):
    """mTLS handshake failed or the peer SPIFFE ID did not match the expected server ID."""


class HushNetworkError(HushError):
    """Connection or timeout error reaching the simba server."""


class HushBadRequestError(HushError):
    """Server returned 400. Indicates a deployment/environment misconfiguration
    (malformed policy snapshot, missing snapshot header, or non-mufasa-injected
    workload) — not recoverable by the caller.
    """


class HushSecretNotFoundError(HushError):
    """Server returned 404 for the requested secret.

    Note: simba also returns this when the caller's SPIFFE ID has no policy
    granting access to the secret — there is no separate 403 path.
    """

    def __init__(self, secret_name: str) -> None:
        super().__init__(f"secret not found: {secret_name!r}")
        self.secret_name = secret_name


class HushFieldNotFoundError(HushError):
    """Server returned 404 for the requested field on a secret."""

    def __init__(self, secret_name: str, field: str) -> None:
        super().__init__(f"field {field!r} not found on secret {secret_name!r}")
        self.secret_name = secret_name
        self.field = field


class HushServerError(HushError):
    """Server returned an unexpected 5xx response."""

    def __init__(self, status_code: int, message: str = "") -> None:
        text = f"simba server error {status_code}"
        if message:
            text = f"{text}: {message}"
        super().__init__(text)
        self.status_code = status_code
        self.message = message
