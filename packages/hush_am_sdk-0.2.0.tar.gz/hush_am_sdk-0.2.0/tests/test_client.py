from unittest.mock import MagicMock, patch
import httpx
import pytest
from hush.client import HEADER_POLICY_SNAPSHOT, HushClient
from hush.exceptions import (
    HushAuthError,
    HushBadRequestError,
    HushFieldNotFoundError,
    HushNetworkError,
    HushSecretNotFoundError,
    HushServerError,
    HushSpiffeError,
)

TRUST_DOMAIN = "example.org"


@pytest.fixture
def mock_env(monkeypatch):
    # Override the production server-address default so URL assertions are
    # deterministic regardless of the env the tests run in.
    monkeypatch.setenv("_HUSH_INJECTOR_POLICY_SNAPSHOT", "eyJmb28iOiAiYmFyIn0=")
    monkeypatch.setenv("_HUSH_INJECTOR_TRUST_DOMAIN", TRUST_DOMAIN)
    monkeypatch.setenv("_HUSH_INJECTOR_SERVER_ADDRESS", "hush.example:8743")
    monkeypatch.setenv(
        "_HUSH_INJECTOR_SPIRE_AGENT_SOCKET_PATH",
        "unix:///tmp/spire-agent/public/api.sock",
    )
    # Construction is now eager: stub out the SPIRE/SSL/HTTP wiring so
    # HushClient() doesn't try to reach a real workload API socket.
    with (
        patch("hush.client.X509Source"),
        patch("hush.client._AuthorizingSpiffeSSLContext"),
        patch("hush.client.httpx.Client"),
    ):
        yield


@pytest.fixture
def client(mock_env):
    c = HushClient()
    c._http_client = MagicMock()
    return c


def _stub_get(client, response):
    client._http_client.get.return_value = response


def _err_response(status_code: int, message: str) -> MagicMock:
    resp = MagicMock(spec=httpx.Response)
    resp.is_success = False
    resp.status_code = status_code
    resp.json.return_value = {"Status": status_code, "Message": message}
    resp.text = message
    return resp


class TestGetSecret:
    def test_returns_json(self, client):
        resp = MagicMock(spec=httpx.Response)
        resp.is_success = True
        resp.json.return_value = {"username": "u", "password": "p"}
        _stub_get(client, resp)
        assert client.get_secret("my-secret") == {"username": "u", "password": "p"}

    def test_url_encodes_name(self, client):
        resp = MagicMock(spec=httpx.Response)
        resp.json.return_value = {}
        _stub_get(client, resp)
        client.get_secret("a/b c")
        url = client._http_client.get.call_args.args[0]
        assert url == "https://hush.example:8743/getsecret/a%2Fb%20c"

    def test_headers_include_token_and_snapshot(self, client):
        resp = MagicMock(spec=httpx.Response)
        resp.json.return_value = {}
        _stub_get(client, resp)
        client.get_secret("k", token="jwt-abc")
        headers = client._http_client.get.call_args.kwargs["headers"]
        assert headers["Authorization"] == "Bearer jwt-abc"
        assert headers[HEADER_POLICY_SNAPSHOT] == "eyJmb28iOiAiYmFyIn0="

    def test_no_auth_header_without_token(self, client):
        resp = MagicMock(spec=httpx.Response)
        resp.json.return_value = {}
        _stub_get(client, resp)
        client.get_secret("k")
        assert (
            "Authorization" not in client._http_client.get.call_args.kwargs["headers"]
        )

    def test_empty_name_raises(self, client):
        with pytest.raises(ValueError, match="secret_name"):
            client.get_secret("")

    def test_missing_snapshot_raises(self, mock_env, monkeypatch):
        monkeypatch.delenv("_HUSH_INJECTOR_POLICY_SNAPSHOT", raising=False)
        with pytest.raises(ValueError, match="POLICY_SNAPSHOT"):
            HushClient()


class TestGetSecretField:
    def test_returns_text(self, client):
        resp = MagicMock(spec=httpx.Response)
        resp.text = "s3cret"
        _stub_get(client, resp)
        assert client.get_secret_field("db", "password") == "s3cret"

    def test_url_encodes_both_segments(self, client):
        resp = MagicMock(spec=httpx.Response)
        resp.text = ""
        _stub_get(client, resp)
        client.get_secret_field("a/b", "c d")
        url = client._http_client.get.call_args.args[0]
        assert url == "https://hush.example:8743/getsecret/a%2Fb/c%20d"

    def test_empty_field_raises(self, client):
        with pytest.raises(ValueError, match="field"):
            client.get_secret_field("k", "")


class TestErrorMapping:
    def test_404_secret_raises_secret_not_found(self, client):
        _stub_get(client, _err_response(404, "secret not found: db"))
        with pytest.raises(HushSecretNotFoundError) as exc:
            client.get_secret("db")
        assert exc.value.secret_name == "db"

    def test_404_field_raises_field_not_found(self, client):
        _stub_get(client, _err_response(404, "secret key not found: password"))
        with pytest.raises(HushFieldNotFoundError) as exc:
            client.get_secret_field("db", "password")
        assert exc.value.secret_name == "db"
        assert exc.value.field == "password"

    def test_404_field_endpoint_falls_back_to_secret_not_found(self, client):
        # /getsecret/:name/:field can also return "secret not found: <name>"
        # when the policy doesn't grant the secret at all.
        _stub_get(client, _err_response(404, "secret not found: db"))
        with pytest.raises(HushSecretNotFoundError):
            client.get_secret_field("db", "password")

    def test_400_raises_bad_request(self, client):
        _stub_get(client, _err_response(400, "invalid policy snapshot header"))
        with pytest.raises(HushBadRequestError, match="snapshot"):
            client.get_secret("db")

    def test_500_raises_server_error(self, client):
        _stub_get(
            client, _err_response(500, "secret incomplete: item missing from ACR")
        )
        with pytest.raises(HushServerError) as exc:
            client.get_secret("db")
        assert exc.value.status_code == 500
        assert "incomplete" in exc.value.message

    def test_network_error_wrapped(self, client):
        client._http_client.get.side_effect = httpx.ConnectError("refused")
        with pytest.raises(HushNetworkError, match="refused"):
            client.get_secret("db")

    def test_tls_error_wrapped_as_auth_error(self, client):
        import ssl as _ssl

        cause = _ssl.SSLError("bad cert")
        exc = httpx.ConnectError("tls handshake failed")
        exc.__cause__ = cause
        client._http_client.get.side_effect = exc
        with pytest.raises(HushAuthError, match="handshake"):
            client.get_secret("db")


class TestSpiffeErrorWrapping:
    def test_x509_source_failure_wraps_as_spiffe_error(self, monkeypatch):
        monkeypatch.setenv("_HUSH_INJECTOR_POLICY_SNAPSHOT", "x")
        monkeypatch.setenv("_HUSH_INJECTOR_TRUST_DOMAIN", TRUST_DOMAIN)
        monkeypatch.setenv("_HUSH_INJECTOR_SERVER_ADDRESS", "hush.example:8743")
        monkeypatch.setenv(
            "_HUSH_INJECTOR_SPIRE_AGENT_SOCKET_PATH", "unix:///nonexistent.sock"
        )
        with patch("hush.client.X509Source", side_effect=RuntimeError("no socket")):
            with pytest.raises(HushSpiffeError, match="no socket"):
                HushClient()


class TestTrustDomain:
    def test_builds_server_spiffe_id(self, mock_env):
        c = HushClient()
        assert str(c.server_spiffe_id) == f"spiffe://{TRUST_DOMAIN}/hush/simba/server"
        assert c.trust_domain == TRUST_DOMAIN

    def test_missing_raises(self, mock_env, monkeypatch):
        monkeypatch.delenv("_HUSH_INJECTOR_TRUST_DOMAIN", raising=False)
        with pytest.raises(ValueError, match="TRUST_DOMAIN"):
            HushClient()


class TestServerAddress:
    def test_adds_https_scheme(self, mock_env, monkeypatch):
        monkeypatch.setenv("_HUSH_INJECTOR_SERVER_ADDRESS", "host:1234")
        assert HushClient().server == "https://host:1234"

    def test_keeps_existing_scheme(self, mock_env, monkeypatch):
        monkeypatch.setenv("_HUSH_INJECTOR_SERVER_ADDRESS", "https://host:1234")
        assert HushClient().server == "https://host:1234"

    def test_missing_raises(self, mock_env, monkeypatch):
        monkeypatch.delenv("_HUSH_INJECTOR_SERVER_ADDRESS", raising=False)
        with pytest.raises(ValueError, match="SERVER_ADDRESS"):
            HushClient()


class TestCleanup:
    def test_context_manager_closes_resources(self, mock_env):
        http_instance = MagicMock()
        src_instance = MagicMock()
        with (
            patch("hush.client.X509Source", return_value=src_instance),
            patch("hush.client._AuthorizingSpiffeSSLContext"),
            patch("hush.client.httpx.Client", return_value=http_instance),
        ):
            with HushClient() as c:
                assert c is not None
            http_instance.close.assert_called_once()
            src_instance.close.assert_called_once()

    def test_cleanup_closes_resources(self, mock_env):
        http_instance = MagicMock()
        src_instance = MagicMock()
        with (
            patch("hush.client.X509Source", return_value=src_instance),
            patch("hush.client._AuthorizingSpiffeSSLContext"),
            patch("hush.client.httpx.Client", return_value=http_instance),
        ):
            c = HushClient()
            c.cleanup()
        http_instance.close.assert_called_once()
        src_instance.close.assert_called_once()

    def test_cleanup_is_idempotent(self, mock_env):
        http_instance = MagicMock()
        src_instance = MagicMock()
        with (
            patch("hush.client.X509Source", return_value=src_instance),
            patch("hush.client._AuthorizingSpiffeSSLContext"),
            patch("hush.client.httpx.Client", return_value=http_instance),
        ):
            c = HushClient()
            c.cleanup()
            c.cleanup()
        http_instance.close.assert_called_once()
        src_instance.close.assert_called_once()


class TestEagerConstruction:
    def test_x509_source_created_at_init(self, mock_env):
        with patch("hush.client.X509Source") as src_cls:
            HushClient()
        src_cls.assert_called_once()

    def test_x509_source_closed_if_ssl_ctx_fails(self, mock_env):
        src_instance = MagicMock()
        with (
            patch("hush.client.X509Source", return_value=src_instance),
            patch(
                "hush.client._AuthorizingSpiffeSSLContext",
                side_effect=RuntimeError("boom"),
            ),
        ):
            with pytest.raises(HushSpiffeError, match="boom"):
                HushClient()
        src_instance.close.assert_called_once()
