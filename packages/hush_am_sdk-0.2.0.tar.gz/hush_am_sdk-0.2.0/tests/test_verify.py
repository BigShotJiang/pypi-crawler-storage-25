"""Tests for the SPIFFE chain-verification path in hush.client.

Builds certificates in-process with `cryptography`, converts to pyOpenSSL
where the code under test expects pyOpenSSL X509 objects, and mocks the
X509Source's bundle lookup. No SPIRE agent needed.
"""

import datetime
from unittest.mock import MagicMock
from cryptography import x509
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.x509.oid import NameOID
from OpenSSL import crypto
from spiffe import SpiffeId
from hush._spiffe_tls import (
    _check_anchor,
    _check_chain_signatures,
    _check_leaf_spiffe_id,
    _check_validity_windows,
    _verify_spiffe_chain,
)

TRUST_DOMAIN = "example.org"
SERVER_SPIFFE_ID = SpiffeId(f"spiffe://{TRUST_DOMAIN}/hush/simba/server")


def _now():
    return datetime.datetime.now(datetime.timezone.utc)


def _make_ca(name="ca"):
    key = ec.generate_private_key(ec.SECP256R1())
    subject = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, name)])
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(subject)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(_now() - datetime.timedelta(hours=1))
        .not_valid_after(_now() + datetime.timedelta(hours=1))
        .add_extension(x509.BasicConstraints(ca=True, path_length=None), critical=True)
        .sign(key, hashes.SHA256())
    )
    return cert, key


def _make_leaf(
    ca_cert,
    ca_key,
    spiffe_uri=str(SERVER_SPIFFE_ID),
    not_before=None,
    not_after=None,
):
    leaf_key = ec.generate_private_key(ec.SECP256R1())
    return (
        x509.CertificateBuilder()
        .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "leaf")]))
        .issuer_name(ca_cert.subject)
        .public_key(leaf_key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(not_before or (_now() - datetime.timedelta(minutes=5)))
        .not_valid_after(not_after or (_now() + datetime.timedelta(hours=1)))
        .add_extension(
            x509.SubjectAlternativeName([x509.UniformResourceIdentifier(spiffe_uri)]),
            critical=True,
        )
        .sign(ca_key, hashes.SHA256())
    )


def _to_pyopenssl(cryptography_cert):
    return crypto.X509.from_cryptography(cryptography_cert)


def _mock_source(authorities):
    src = MagicMock()
    bundle = MagicMock()
    bundle.x509_authorities = authorities
    src.get_x509_context.return_value.x509_bundle_set.get_bundle_for_trust_domain.return_value = bundle
    return src


def _mock_source_no_bundle():
    src = MagicMock()
    src.get_x509_context.return_value.x509_bundle_set.get_bundle_for_trust_domain.return_value = None
    return src


class TestVerifySpiffeChain:
    def test_happy_path_self_signed_leaf_anchored(self):
        # SPIRE-style: leaf is signed by an authority in the bundle.
        ca, ca_key = _make_ca()
        leaf = _make_leaf(ca, ca_key)
        peer_chain = [_to_pyopenssl(leaf)]
        src = _mock_source([ca])
        assert _verify_spiffe_chain(peer_chain, src, SERVER_SPIFFE_ID) is True

    def test_empty_chain_rejected(self):
        src = _mock_source([])
        assert _verify_spiffe_chain([], src, SERVER_SPIFFE_ID) is False

    def test_wrong_spiffe_id_rejected(self):
        ca, ca_key = _make_ca()
        leaf = _make_leaf(ca, ca_key, spiffe_uri=f"spiffe://{TRUST_DOMAIN}/hush/wrong")
        src = _mock_source([ca])
        assert (
            _verify_spiffe_chain([_to_pyopenssl(leaf)], src, SERVER_SPIFFE_ID) is False
        )

    def test_expired_leaf_rejected(self):
        ca, ca_key = _make_ca()
        leaf = _make_leaf(
            ca,
            ca_key,
            not_before=_now() - datetime.timedelta(hours=2),
            not_after=_now() - datetime.timedelta(minutes=1),
        )
        src = _mock_source([ca])
        assert (
            _verify_spiffe_chain([_to_pyopenssl(leaf)], src, SERVER_SPIFFE_ID) is False
        )

    def test_not_yet_valid_leaf_rejected(self):
        ca, ca_key = _make_ca()
        leaf = _make_leaf(
            ca,
            ca_key,
            not_before=_now() + datetime.timedelta(minutes=5),
            not_after=_now() + datetime.timedelta(hours=1),
        )
        src = _mock_source([ca])
        assert (
            _verify_spiffe_chain([_to_pyopenssl(leaf)], src, SERVER_SPIFFE_ID) is False
        )

    def test_unknown_trust_domain_rejected(self):
        ca, ca_key = _make_ca()
        leaf = _make_leaf(ca, ca_key)
        src = _mock_source_no_bundle()
        assert (
            _verify_spiffe_chain([_to_pyopenssl(leaf)], src, SERVER_SPIFFE_ID) is False
        )

    def test_leaf_signed_by_unknown_ca_rejected(self):
        # Leaf claims the right SPIFFE ID but is signed by a CA not in the bundle.
        attacker_ca, attacker_key = _make_ca("attacker")
        leaf = _make_leaf(attacker_ca, attacker_key)
        legit_ca, _ = _make_ca("legit")
        src = _mock_source([legit_ca])
        assert (
            _verify_spiffe_chain([_to_pyopenssl(leaf)], src, SERVER_SPIFFE_ID) is False
        )

    def test_leaf_with_no_san_rejected(self):
        ca, ca_key = _make_ca()
        leaf_key = ec.generate_private_key(ec.SECP256R1())
        leaf = (
            x509.CertificateBuilder()
            .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "leaf")]))
            .issuer_name(ca.subject)
            .public_key(leaf_key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(_now() - datetime.timedelta(minutes=5))
            .not_valid_after(_now() + datetime.timedelta(hours=1))
            .sign(ca_key, hashes.SHA256())
        )
        src = _mock_source([ca])
        assert (
            _verify_spiffe_chain([_to_pyopenssl(leaf)], src, SERVER_SPIFFE_ID) is False
        )


class TestCheckLeafSpiffeId:
    def test_matching_id_returns_id(self):
        ca, ca_key = _make_ca()
        leaf = _make_leaf(ca, ca_key)
        assert _check_leaf_spiffe_id(leaf, SERVER_SPIFFE_ID) == SERVER_SPIFFE_ID

    def test_mismatched_id_returns_none(self):
        ca, ca_key = _make_ca()
        leaf = _make_leaf(ca, ca_key, spiffe_uri="spiffe://other.example/svc")
        assert _check_leaf_spiffe_id(leaf, SERVER_SPIFFE_ID) is None

    def test_san_with_multiple_uris_picks_spiffe(self):
        # Regression: old str-split parser broke when SAN had non-SPIFFE URIs
        # alongside the SPIFFE one (any value containing a comma was at risk).
        ca, ca_key = _make_ca()
        leaf_key = ec.generate_private_key(ec.SECP256R1())
        leaf = (
            x509.CertificateBuilder()
            .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "leaf")]))
            .issuer_name(ca.subject)
            .public_key(leaf_key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(_now() - datetime.timedelta(minutes=5))
            .not_valid_after(_now() + datetime.timedelta(hours=1))
            .add_extension(
                x509.SubjectAlternativeName(
                    [
                        x509.UniformResourceIdentifier("https://example.com/a,b"),
                        x509.UniformResourceIdentifier(str(SERVER_SPIFFE_ID)),
                    ]
                ),
                critical=True,
            )
            .sign(ca_key, hashes.SHA256())
        )
        assert _check_leaf_spiffe_id(leaf, SERVER_SPIFFE_ID) == SERVER_SPIFFE_ID


class TestCheckValidityWindows:
    def test_valid_chain(self):
        ca, ca_key = _make_ca()
        leaf = _make_leaf(ca, ca_key)
        assert _check_validity_windows([leaf, ca]) is True

    def test_expired_anywhere_in_chain(self):
        ca, ca_key = _make_ca()
        expired = _make_leaf(
            ca,
            ca_key,
            not_after=_now() - datetime.timedelta(seconds=1),
        )
        assert _check_validity_windows([expired, ca]) is False


class TestCheckChainSignatures:
    def test_valid_signatures(self):
        ca, ca_key = _make_ca()
        leaf = _make_leaf(ca, ca_key)
        assert _check_chain_signatures([leaf, ca]) is True

    def test_invalid_signature_rejected(self):
        ca_a, key_a = _make_ca("a")
        ca_b, _ = _make_ca("b")
        # Build a leaf signed by key_a but claim ca_b is the next link.
        leaf = _make_leaf(ca_a, key_a)
        assert _check_chain_signatures([leaf, ca_b]) is False

    def test_single_cert_chain_passes(self):
        ca, _ = _make_ca()
        assert _check_chain_signatures([ca]) is True


class TestCheckAnchor:
    def test_top_is_authority_by_der(self):
        ca, _ = _make_ca()
        src = _mock_source([ca])
        # trust_domain only used as a lookup key — the mock ignores it.
        assert _check_anchor(ca, src, TRUST_DOMAIN) is True

    def test_top_signed_by_authority(self):
        # Intermediate cert: top of presented chain is signed by an authority
        # in the bundle but isn't byte-equal to it.
        root, root_key = _make_ca("root")
        intermediate_key = ec.generate_private_key(ec.SECP256R1())
        intermediate = (
            x509.CertificateBuilder()
            .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "int")]))
            .issuer_name(root.subject)
            .public_key(intermediate_key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(_now() - datetime.timedelta(hours=1))
            .not_valid_after(_now() + datetime.timedelta(hours=1))
            .add_extension(
                x509.BasicConstraints(ca=True, path_length=None), critical=True
            )
            .sign(root_key, hashes.SHA256())
        )
        src = _mock_source([root])
        assert _check_anchor(intermediate, src, TRUST_DOMAIN) is True

    def test_no_bundle_for_trust_domain(self):
        ca, _ = _make_ca()
        src = _mock_source_no_bundle()
        assert _check_anchor(ca, src, TRUST_DOMAIN) is False

    def test_bundle_lookup_raises(self):
        ca, _ = _make_ca()
        src = MagicMock()
        src.get_x509_context.side_effect = RuntimeError("boom")
        assert _check_anchor(ca, src, TRUST_DOMAIN) is False

    def test_no_authority_anchors_top(self):
        ca, _ = _make_ca("presented")
        unrelated_ca, _ = _make_ca("unrelated")
        src = _mock_source([unrelated_ca])
        assert _check_anchor(ca, src, TRUST_DOMAIN) is False
