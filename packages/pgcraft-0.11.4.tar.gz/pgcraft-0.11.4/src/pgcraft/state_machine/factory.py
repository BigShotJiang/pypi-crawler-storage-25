"""Ledger-backed state machine factory.

:class:`PGCraftStateMachine` creates a validated transition log for
any entity that moves through a set of named states.  The valid
transitions are compiled directly into a ``BEFORE INSERT`` trigger
function, making them schema-level constraints that Alembic tracks
like any other database object.

Structure
---------
For a state machine named ``order_status`` in schema ``app``:

- ``app.order_status_raw`` -- append-only transition log.
  Columns: ``id`` (PK), ``subject_id`` (FK to subject table),
  ``from_state`` TEXT nullable (NULL for the initial transition),
  ``to_state`` TEXT not null, ``created_at``, plus any
  *extra_columns*.
- ``app.order_status`` -- view showing the full transition log.
- ``app.order_status_current`` -- view showing the current state per
  subject via ``DISTINCT ON (subject_id) ORDER BY created_at DESC``.

Usage::

    order_status = PGCraftStateMachine(
        name="order_status",
        schemaname="app",
        metadata=metadata,
        subject_column=Column(
            "order_id", Integer,
            PGCraftForeignKey("orders.id"), nullable=False
        ),
        states=["pending", "confirmed", "shipped", "delivered", "cancelled"],
        valid_transitions=[
            (None, "pending"),        # initial state
            ("pending", "confirmed"),
            ("pending", "cancelled"),
            ("confirmed", "shipped"),
            ("shipped", "delivered"),
            ("shipped", "cancelled"),
        ],
        extra_columns=[
            Column("changed_by", String, nullable=False),
            Column("notes", Text, nullable=True),
        ],
    )

    # Readable proxies
    order_status.table           # the raw transitions table
    order_status.current_view    # current state per subject

    # Query builders
    current_q = state_machine_current_query(order_status)
    history_q = state_machine_history_query(order_status)
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from sqlalchemy import (
    CheckConstraint,
    Column,
    DateTime,
    MetaData,
    Table,
    Text,
    select,
)
from sqlalchemy_declarative_extensions import (
    View,
    register_function,
    register_trigger,
    register_view,
)
from sqlalchemy_declarative_extensions.dialects.postgresql import (
    Function,
    FunctionSecurity,
    Trigger,
)

from pgcraft.errors import PGCraftValidationError
from pgcraft.fk import DimensionRef, register_dimension
from pgcraft.plugins.column_name import construct_column_name_plugin
from pgcraft.plugins.fk import TableFKPlugin
from pgcraft.plugins.pk import SerialPKPlugin
from pgcraft.utils.naming import resolve_name
from pgcraft.utils.query import compile_query
from pgcraft.utils.template import load_template

if TYPE_CHECKING:
    from sqlalchemy import Select

_TEMPLATES = Path(__file__).resolve().parent / "templates"

_NAMING_DEFAULTS = {
    "sm_raw_table": "%(name)s_raw",
    "sm_validate_function": "%(schema)s_%(name)s_validate_transition",
    "sm_validate_trigger": "%(schema)s_%(name)s_validate_transition",
    "sm_current_view": "%(name)s_current",
}


class PGCraftStateMachine:
    r"""Ledger-backed state machine with transition validation.

    Creates an append-only transitions table, a full history view, and
    a current-state view.  A ``BEFORE INSERT`` trigger validates that
    each new transition is:

    1. Declared in *valid_transitions*.
    2. Consistent with the subject's actual current state.

    The valid transitions are compiled into the trigger function body
    at migration time, so changing them requires a migration.

    Args:
        name: Base name for all generated objects.
        schemaname: PostgreSQL schema for all objects.
        metadata: SQLAlchemy ``MetaData`` to register on.
        subject_column: ``Column`` that identifies the entity being
            tracked.  Use ``PGCraftForeignKey`` to reference the
            subject's table.  Must be ``nullable=False``.
        states: List of valid state strings.
        valid_transitions: List of ``(from_state, to_state)`` pairs.
            Use ``None`` as *from_state* for the initial transition.
        extra_columns: Additional columns on the raw table (e.g.
            ``changed_by``, ``notes``).
        allow_initial: If ``True`` (default), a row with
            ``from_state = NULL`` is allowed as the first transition
            for a subject.  Set to ``False`` to require an explicit
            initial state defined in *valid_transitions*.

    Raises:
        PGCraftValidationError: If *states* or *valid_transitions* is
            empty, or if a transition references an undeclared state.

    """

    def __init__(  # noqa: PLR0913
        self,
        name: str,
        schemaname: str,
        metadata: MetaData,
        subject_column: Column,
        states: list[str],
        valid_transitions: list[tuple[str | None, str]],
        extra_columns: list[Column] | None = None,
        *,
        allow_initial: bool = True,
    ) -> None:
        """Build the state machine and register all objects."""
        self._validate(states, valid_transitions)
        self.name = name
        self.schemaname = schemaname
        self.metadata = metadata

        raw_name = resolve_name(
            metadata,
            "sm_raw_table",
            {"name": name, "schema": schemaname},
            _NAMING_DEFAULTS,
        )

        # PK plugin
        pk_plugin = SerialPKPlugin()
        from pgcraft.factory.context import FactoryContext  # noqa: PLC0415

        ctx = FactoryContext(
            tablename=name,
            schemaname=schemaname,
            metadata=metadata,
            schema_items=[subject_column, *(extra_columns or [])],
            plugins=[],
        )
        pk_plugin.run(ctx)
        construct_column_name_plugin("created_at_column", "created_at").run(ctx)
        pk_columns = ctx["pk_columns"]

        valid_state_set = set(states)
        # State check expression.
        state_values = ", ".join(f"'{s}'" for s in states)
        state_check = CheckConstraint(
            f"to_state IN ({state_values})",
            name=f"{raw_name}_to_state_ck",
        )
        from_state_check = CheckConstraint(
            f"from_state IS NULL OR from_state IN ({state_values})",
            name=f"{raw_name}_from_state_ck",
        )

        raw_table = Table(
            raw_name,
            metadata,
            *pk_columns,
            Column("from_state", Text, nullable=True),
            Column("to_state", Text, nullable=False),
            Column(
                "created_at",
                DateTime(timezone=True),
                server_default="now()",
                nullable=False,
            ),
            subject_column,
            *(extra_columns or []),
            state_check,
            from_state_check,
            schema=schemaname,
        )
        fk_ctx = FactoryContext(
            tablename=name,
            schemaname=schemaname,
            metadata=metadata,
            schema_items=[subject_column, *(extra_columns or [])],
            plugins=[],
        )
        fk_ctx["raw_table"] = raw_table
        TableFKPlugin("raw_table").run(fk_ctx)

        self.table = raw_table

        raw_fullname = f"{schemaname}.{raw_name}"
        subject_col_name = subject_column.name

        # Validate trigger.
        validate_fn_name = resolve_name(
            metadata,
            "sm_validate_function",
            {"name": name, "schema": schemaname},
            _NAMING_DEFAULTS,
        )
        validate_trig_name = resolve_name(
            metadata,
            "sm_validate_trigger",
            {"name": name, "schema": schemaname},
            _NAMING_DEFAULTS,
        )
        template = load_template(
            _TEMPLATES / "validate_transition.plpgsql.mako"
        )
        body = template.render(
            name=name,
            transitions_table=raw_fullname,
            subject_col=subject_col_name,
            valid_transitions=valid_transitions,
            allow_initial=allow_initial,
            valid_state_set=valid_state_set,
        )

        register_function(
            metadata,
            Function(
                validate_fn_name,
                body,
                returns="trigger",
                language="plpgsql",
                schema=schemaname,
                security=FunctionSecurity.definer,
            ),
        )
        register_trigger(
            metadata,
            Trigger.before(
                "insert",
                on=raw_fullname,
                execute=f"{schemaname}.{validate_fn_name}",
                name=validate_trig_name,
            ).for_each_row(),
        )

        # History view (full log ordered by subject, then time).
        history_sql = compile_query(
            select(raw_table).order_by(
                raw_table.c[subject_col_name],
                raw_table.c["created_at"],
            )
        )
        register_view(
            metadata,
            View(name, history_sql, schema=schemaname),
        )
        self._history_proxy = Table(
            name,
            MetaData(),
            *[
                Column(c.name, c.type, primary_key=c.primary_key)
                for c in raw_table.columns
            ],
            schema=schemaname,
        )

        # Current-state view (latest transition per subject).
        current_view_name = resolve_name(
            metadata,
            "sm_current_view",
            {"name": name, "schema": schemaname},
            _NAMING_DEFAULTS,
        )
        subject_col_obj = raw_table.c[subject_col_name]
        pk_col_name = pk_columns.first_key
        current_sql = compile_query(
            select(raw_table)
            .distinct(subject_col_obj)
            .order_by(
                subject_col_obj,
                raw_table.c["created_at"].desc(),
                raw_table.c[pk_col_name].desc(),
            )
        )
        register_view(
            metadata,
            View(current_view_name, current_sql, schema=schemaname),
        )
        self.current_view = Table(
            current_view_name,
            MetaData(),
            *[
                Column(c.name, c.type, primary_key=c.primary_key)
                for c in raw_table.columns
            ],
            schema=schemaname,
        )

        # Register for FK resolution.
        register_dimension(
            metadata,
            name,
            DimensionRef(schema=schemaname, table=raw_name),
        )

    @staticmethod
    def _validate(
        states: list[str],
        valid_transitions: list[tuple[str | None, str]],
    ) -> None:
        """Raise PGCraftValidationError if configuration is invalid."""
        if not states:
            msg = "PGCraftStateMachine: states must be a non-empty list"
            raise PGCraftValidationError(msg)
        if not valid_transitions:
            msg = "PGCraftStateMachine: valid_transitions must be non-empty"
            raise PGCraftValidationError(msg)
        state_set = set(states)
        for from_s, to_s in valid_transitions:
            if from_s is not None and from_s not in state_set:
                msg = (
                    f"PGCraftStateMachine: transition from_state "
                    f"{from_s!r} is not in states."
                )
                raise PGCraftValidationError(msg)
            if to_s not in state_set:
                msg = (
                    f"PGCraftStateMachine: transition to_state "
                    f"{to_s!r} is not in states."
                )
                raise PGCraftValidationError(msg)


def state_machine_current_query(
    sm: PGCraftStateMachine,
) -> Select:
    """Return a select against the current-state view.

    Args:
        sm: A :class:`PGCraftStateMachine` instance.

    Returns:
        A SQLAlchemy :class:`~sqlalchemy.Select` over
        ``{name}_current``.

    """
    return select(sm.current_view)


def state_machine_history_query(
    sm: PGCraftStateMachine,
    subject_id: object = None,
) -> Select:
    """Return all transitions, optionally filtered to one subject.

    Args:
        sm: A :class:`PGCraftStateMachine` instance.
        subject_id: When provided, adds a ``WHERE subject_col =
            subject_id`` filter.

    Returns:
        A SQLAlchemy :class:`~sqlalchemy.Select`.

    """
    q = select(sm.table).order_by(
        sm.table.c["created_at"],
    )
    if subject_id is not None:
        # Use the first non-PK, non-state, non-timestamp column as
        # the subject column for filtering.
        subject_col = next(
            c
            for c in sm.table.columns
            if c.name not in {"id", "from_state", "to_state", "created_at"}
        )
        q = q.where(subject_col == subject_id)
    return q
