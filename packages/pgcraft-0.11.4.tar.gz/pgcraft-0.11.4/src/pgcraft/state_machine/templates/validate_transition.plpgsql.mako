DECLARE
    _current_state TEXT;
    _valid_transitions TEXT[][] := ARRAY[
% for from_s, to_s in valid_transitions:
        ARRAY[${("NULL" if from_s is None else "'" + from_s + "'")}, '${to_s}']${"," if not loop.last else ""}
% endfor
    ];
    _pair TEXT[];
    _allowed BOOLEAN := FALSE;
    _initial_allowed BOOLEAN := ${str(allow_initial).upper()};
BEGIN
    -- Determine the current state for this subject.
    SELECT to_state
    INTO _current_state
    FROM ${transitions_table}
    WHERE ${subject_col} = NEW.${subject_col}
    ORDER BY created_at DESC, id DESC
    LIMIT 1;

    -- If no prior transition exists, this is the initial transition.
    IF _current_state IS NULL THEN
        IF NOT _initial_allowed THEN
            RAISE EXCEPTION
                'State machine ${name}: no initial transition allowed. '
                'Use transition(from_state=NULL) to set the initial state.';
        END IF;
        IF NEW.from_state IS NOT NULL THEN
            RAISE EXCEPTION
                'State machine ${name}: first transition for subject % '
                'must have from_state = NULL, got %.',
                NEW.${subject_col}, NEW.from_state;
        END IF;
    ELSE
        -- Validate from_state matches actual current state.
        IF NEW.from_state IS DISTINCT FROM _current_state THEN
            RAISE EXCEPTION
                'State machine ${name}: declared from_state % does not '
                'match actual current state % for subject %.',
                NEW.from_state, _current_state, NEW.${subject_col};
        END IF;
    END IF;

    -- Check that (from_state, to_state) is a valid transition.
    FOREACH _pair SLICE 1 IN ARRAY _valid_transitions LOOP
        IF (_pair[1] IS NOT DISTINCT FROM NEW.from_state)
           AND _pair[2] = NEW.to_state THEN
            _allowed := TRUE;
            EXIT;
        END IF;
    END LOOP;

    IF NOT _allowed THEN
        RAISE EXCEPTION
            'State machine ${name}: transition from % to % is not allowed.',
            COALESCE(NEW.from_state, 'NULL'), NEW.to_state;
    END IF;

    RETURN NEW;
END;
