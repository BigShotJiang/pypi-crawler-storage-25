"""Column name registry plugin."""

from __future__ import annotations

from typing import TYPE_CHECKING, ClassVar

if TYPE_CHECKING:
    from pgcraft.factory.context import FactoryContext

from pgcraft.plugin import Plugin


class _ColumnNamePlugin(Plugin):
    """Publish a column name string to ctx under a fixed key.

    Not used directly — create instances via
    :func:`construct_column_name_plugin`.

    Args:
        column_name: Name of the column to publish.

    """

    _ctx_key: ClassVar[str]

    def __init__(self, column_name: str) -> None:
        """Store the column name."""
        self._column_name = column_name

    def resolved_produces(self) -> list[str]:
        """Return the single ctx key this plugin writes."""
        return [self._ctx_key]

    def run(self, ctx: FactoryContext) -> None:
        """Store the column name in ctx."""
        ctx[self._ctx_key] = self._column_name


def construct_column_name_plugin(
    ctx_key: str,
    column_name: str,
) -> _ColumnNamePlugin:
    """Create a column-name-registry plugin for *ctx_key*.

    Args:
        ctx_key: The ctx key under which *column_name* is stored.
        column_name: Name of the column.

    Returns:
        A :class:`_ColumnNamePlugin` instance that publishes
        *column_name* under *ctx_key*.

    """
    cls = type(
        "_ColumnNamePlugin",
        (_ColumnNamePlugin,),
        {"_ctx_key": ctx_key},
    )
    return cls(column_name)
