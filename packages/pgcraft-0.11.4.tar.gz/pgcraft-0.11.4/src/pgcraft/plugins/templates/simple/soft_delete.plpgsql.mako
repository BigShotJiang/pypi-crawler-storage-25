BEGIN
UPDATE ${base_table}
SET ${deleted_at_col} = now()
WHERE ${pk_col} = OLD.${pk_col};
RETURN OLD;
END;
