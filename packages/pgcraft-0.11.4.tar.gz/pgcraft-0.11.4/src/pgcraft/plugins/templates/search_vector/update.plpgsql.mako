BEGIN
    NEW.${vector_column} := to_tsvector(
        '${ts_config}',
        ${source_expr}
    );
    RETURN NEW;
END;
