    INSERT INTO ${snapshot_table} (${dim_cols}, balance, updated_at)
    SELECT ${raw_dim_cols}, SUM(value), now()
    FROM ${raw_table}
    WHERE created_at >= _since
    GROUP BY ${raw_dim_cols}
    ON CONFLICT (${dim_cols})
    DO UPDATE SET
        balance = ${snapshot_table}.balance + EXCLUDED.balance,
        updated_at = now();
