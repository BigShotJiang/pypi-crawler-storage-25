DECLARE
    _since TIMESTAMPTZ;
BEGIN
    -- Use the caller-supplied cutoff or fall back to the snapshot's
    -- own last-updated timestamp, with a 1-second overlap to guard
    -- against any clock skew at the boundary.
    IF p_since IS NOT NULL THEN
        _since := p_since;
    ELSE
        SELECT MIN(updated_at) - INTERVAL '1 second'
        INTO _since
        FROM ${snapshot_table};

        IF _since IS NULL THEN
            _since := '-infinity'::TIMESTAMPTZ;
        END IF;
    END IF;

    INSERT INTO ${snapshot_table} (${dim_cols}, balance, updated_at)
    SELECT ${raw_dim_cols}, SUM(value), now()
    FROM ${raw_table}
    WHERE created_at >= _since
    GROUP BY ${raw_dim_cols}
    ON CONFLICT (${dim_cols})
    DO UPDATE SET
        balance = ${snapshot_table}.balance + EXCLUDED.balance,
        updated_at = now();

    RETURN;
END;
