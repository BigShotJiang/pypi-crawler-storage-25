DECLARE
    _row RECORD;
BEGIN
    FOR _row IN SELECT * FROM new_entries LOOP
        INSERT INTO ${snapshot_table} (${dim_cols}, balance, updated_at)
        VALUES (${new_dim_exprs}, _row.value, now())
        ON CONFLICT (${dim_cols})
        DO UPDATE SET
            balance = ${snapshot_table}.balance + EXCLUDED.balance,
            updated_at = now();
    END LOOP;
    RETURN NULL;
END;
