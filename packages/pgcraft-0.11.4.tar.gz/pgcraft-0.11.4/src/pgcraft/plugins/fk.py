"""Foreign key plugin for pgcraft dimensions.

:class:`TableFKPlugin` converts inline
:class:`~pgcraft.fk.PGCraftForeignKey` column markers into real
SQLAlchemy ``ForeignKeyConstraint`` objects on a table.  Two-part
references (``"dimension.column"``) are resolved via the dimension
registry in ``metadata.info``.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy import ForeignKeyConstraint

from pgcraft.errors import PGCraftValidationError
from pgcraft.fk import (
    _INLINE_FK_INFO_KEY,
    PGCraftForeignKey,
    resolve_fk_reference,
)
from pgcraft.plugin import Dynamic, Plugin, requires

if TYPE_CHECKING:
    from pgcraft.factory.context import FactoryContext


def _validate_fk_target(resolved_ref: str, metadata: object) -> None:
    """Validate a fully-qualified FK target against the metadata.

    Only validates when the target table is present in *metadata*
    (i.e. it is a pgcraft-managed table).  External tables are
    silently skipped.

    Args:
        resolved_ref: ``"schema.table.column"`` string.
        metadata: SQLAlchemy MetaData instance.

    Raises:
        PGCraftValidationError: If the target column does not exist
            on a known table.

    """
    schema, tname, col_name = resolved_ref.rsplit(".", 2)
    table_key = f"{schema}.{tname}"
    target = metadata.tables.get(table_key)  # type: ignore[union-attr]
    if target is None:
        return
    if col_name not in target.c:
        known = sorted(c.name for c in target.columns)
        msg = (
            f"FK target {resolved_ref!r}: column {col_name!r} "
            f"does not exist on {table_key!r}. "
            f"Known columns: {known}."
        )
        raise PGCraftValidationError(msg)


@requires(Dynamic("table_key"))
class TableFKPlugin(Plugin):
    """Materialize FK declarations as ``ForeignKeyConstraint`` objects.

    Handles inline :class:`~pgcraft.fk.PGCraftForeignKey` markers
    attached to ``Column`` constructors (single-column).

    Two-part ``"dimension.column"`` references are resolved via the
    dimension registry.  Three-part ``"schema.table.column"``
    references are passed through directly.

    Args:
        table_key: Key in ``ctx`` for the target table
            (default ``"primary"``).

    """

    def __init__(self, table_key: str = "primary") -> None:
        """Store the context key."""
        self.table_key = table_key

    def run(self, ctx: FactoryContext) -> None:
        """Collect and create foreign key constraints from inline markers."""
        table = ctx[self.table_key]

        for col in table.columns:
            inline_fks: list[PGCraftForeignKey] = col.info.get(
                _INLINE_FK_INFO_KEY, []
            )
            for inline_fk in inline_fks:
                ref = inline_fk.reference
                parts = ref.split(".")
                resolved_ref = (
                    ref
                    if len(parts) == 3  # noqa: PLR2004
                    else resolve_fk_reference(ctx.metadata, ref)
                )
                _validate_fk_target(resolved_ref, ctx.metadata)
                table.append_constraint(
                    ForeignKeyConstraint(
                        [col.name],
                        [resolved_ref],
                        ondelete=inline_fk.ondelete,
                        onupdate=inline_fk.onupdate,
                    )
                )
