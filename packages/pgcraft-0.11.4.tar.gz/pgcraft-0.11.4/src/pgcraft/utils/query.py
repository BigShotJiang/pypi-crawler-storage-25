from sqlalchemy.dialects import postgresql
from sqlalchemy.sql.selectable import SelectBase


def compile_query(query: SelectBase) -> str:
    """Compile a SQLAlchemy query to a PostgreSQL SQL string."""
    return str(
        query.compile(
            dialect=postgresql.dialect(),
            compile_kwargs={"literal_binds": True},
        )
    )
