"""Shared trigger registration for dimension factories."""

from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy_declarative_extensions import (
    register_function,
    register_trigger,
)
from sqlalchemy_declarative_extensions.dialects.postgresql import (
    Function,
    FunctionSecurity,
    Trigger,
)

from pgcraft.utils.naming import resolve_name

if TYPE_CHECKING:
    from sqlalchemy import MetaData


def register_view_triggers(  # noqa: PLR0913
    metadata: MetaData,
    *,
    view_schema: str,
    view_fullname: str,
    tablename: str,
    ops: list[tuple[str, str]],
    naming_defaults: dict[str, str],
    function_key: str,
    trigger_key: str,
) -> None:
    """Register INSTEAD OF triggers for a single view.

    Args:
        metadata: SQLAlchemy ``MetaData`` to register on.
        view_schema: Schema the view lives in.
        view_fullname: Fully qualified view name.
        tablename: Base dimension table name.
        ops: List of ``(operation, plpgsql_body)`` tuples.
        naming_defaults: Default naming templates.
        function_key: Key for function name resolution.
        trigger_key: Key for trigger name resolution.

    """
    subs = {"table_name": tablename, "schema": view_schema}

    for op, body in ops:
        fn_name = resolve_name(
            metadata,
            function_key,
            {**subs, "op": op},
            naming_defaults,
        )
        trigger_name = resolve_name(
            metadata,
            trigger_key,
            {**subs, "op": op},
            naming_defaults,
        )

        register_function(
            metadata,
            Function(
                fn_name,
                body,
                returns="trigger",
                language="plpgsql",
                schema=view_schema,
                security=FunctionSecurity.definer,
            ),
        )

        register_trigger(
            metadata,
            Trigger.instead_of(
                op,
                on=view_fullname,
                execute=f"{view_schema}.{fn_name}",
                name=trigger_name,
            ).for_each_row(),
        )
