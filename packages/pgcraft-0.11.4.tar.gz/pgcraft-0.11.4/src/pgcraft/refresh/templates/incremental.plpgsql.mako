DECLARE
    _since TIMESTAMPTZ;
BEGIN
    -- Use the caller-supplied cutoff, or fall back to the checkpoint
    -- expression (e.g. the aggregate table's MIN(updated_at) - overlap).
    -- A 1-second overlap guards against clock skew at the boundary.
    IF p_since IS NOT NULL THEN
        _since := p_since;
    ELSE
        _since := (${fallback_sql});
        IF _since IS NULL THEN
            _since := '-infinity'::TIMESTAMPTZ;
        END IF;
    END IF;

${body}
    RETURN;
END;
