"""RLS policy dataclasses and metadata registration.

:class:`RLSPolicy` describes a single PostgreSQL row-level security
policy.  :func:`register_rls_policy` stores it in ``metadata.info``
so the Alembic comparator can discover it during autogenerate.

A policy controls which rows a given role can see or modify.  The
minimal form::

    RLSPolicy(
        table="users_raw",
        schema="dim",
        name="owner_policy",
        using="current_setting('app.user_id', true)::text = user_id::text",
    )

Roles can be restricted via *roles* (empty = all roles, including
``PUBLIC``).  A *with_check* expression is used for INSERT/UPDATE when
the write predicate differs from the read predicate.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from sqlalchemy import MetaData


@dataclass(frozen=True)
class RLSPolicy:
    """Describe a single PostgreSQL row-level security policy.

    Args:
        table: Unqualified table name the policy applies to.
        schema: Schema that owns the table.
        name: Policy name (unique per table).
        using: ``USING`` expression controlling row visibility for
            SELECT, UPDATE, and DELETE.
        with_check: ``WITH CHECK`` expression controlling INSERT and
            UPDATE.  When ``None``, *using* is reused for writes.
        roles: PostgreSQL roles the policy applies to.  Empty list
            means ``PUBLIC`` (all roles).
        permissive: When ``True`` (default) the policy is
            ``PERMISSIVE`` -- rows passing ANY permissive policy are
            visible.  When ``False`` the policy is ``RESTRICTIVE`` --
            the row must pass ALL restrictive policies.
        cmd: DML command the policy applies to: ``"ALL"``,
            ``"SELECT"``, ``"INSERT"``, ``"UPDATE"``, or
            ``"DELETE"``.

    """

    table: str
    schema: str
    name: str
    using: str
    with_check: str | None = None
    roles: list[str] = field(default_factory=list)
    permissive: bool = True
    cmd: str = "ALL"

    @property
    def table_fullname(self) -> str:
        """Return ``schema.table``."""
        return f"{self.schema}.{self.table}"

    def to_sql_create(self) -> str:
        """Render the ``CREATE POLICY`` DDL statement.

        Returns:
            A complete ``CREATE POLICY ... ON ...`` SQL string.

        """
        parts = [
            f"CREATE POLICY {self.name}",
            f"ON {self.table_fullname}",
            "AS PERMISSIVE" if self.permissive else "AS RESTRICTIVE",
            f"FOR {self.cmd}",
        ]
        if self.roles:
            roles_str = ", ".join(self.roles)
            parts.append(f"TO {roles_str}")
        parts.append(f"USING ({self.using})")
        if self.with_check is not None:
            parts.append(f"WITH CHECK ({self.with_check})")
        return "\n".join(parts)

    def to_sql_drop(self) -> str:
        """Render the ``DROP POLICY`` DDL statement.

        Returns:
            A complete ``DROP POLICY ... ON ...`` SQL string.

        """
        return f"DROP POLICY IF EXISTS {self.name} ON {self.table_fullname}"

    def to_sql_enable_rls(self) -> str:
        """Render ``ALTER TABLE ... ENABLE ROW LEVEL SECURITY``.

        Returns:
            The DDL string to enable RLS on the table.

        """
        return f"ALTER TABLE {self.table_fullname} ENABLE ROW LEVEL SECURITY"


@dataclass
class RLSPolicies:
    """Container for all RLS policies registered on a MetaData.

    Stored under ``metadata.info["rls_policies"]`` by
    :func:`register_rls_policy`.
    """

    policies: list[RLSPolicy] = field(default_factory=list)

    @classmethod
    def extract(
        cls,
        metadata: object,
    ) -> RLSPolicies | None:
        """Return the registered policies or ``None`` if none exist.

        Args:
            metadata: SQLAlchemy :class:`~sqlalchemy.MetaData`, or
                ``None``.

        Returns:
            The :class:`RLSPolicies` holder or ``None``.

        """
        if metadata is None or not isinstance(metadata, MetaData):
            return None
        return metadata.info.get("rls_policies")


def register_rls_policy(
    metadata: MetaData,
    policy: RLSPolicy,
) -> None:
    """Store *policy* in *metadata* for Alembic autogenerate.

    Args:
        metadata: SQLAlchemy :class:`~sqlalchemy.MetaData` to
            register on.
        policy: The policy to register.

    """
    holder: RLSPolicies | None = metadata.info.get("rls_policies")
    if holder is None:
        holder = RLSPolicies()
        metadata.info["rls_policies"] = holder
    holder.policies.append(policy)
