"""Alembic comparator for row-level security policies.

Queries ``pg_policies`` to find the current set of policies in the
database and diffs them against the set registered in metadata via
:func:`~pgcraft.rls.base.register_rls_policy`.  Emits
:class:`CreateRLSPolicyOp`, :class:`DropRLSPolicyOp`, and
:class:`EnableRLSOp` as ``op.execute(...)`` statements.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from sqlalchemy import Connection

    from pgcraft.rls.base import RLSPolicies, RLSPolicy

_FETCH_POLICIES_SQL = """\
SELECT
    schemaname,
    tablename,
    policyname,
    permissive,
    COALESCE(roles::text, '{}') AS roles,
    cmd,
    COALESCE(qual, '') AS qual
FROM pg_policies
WHERE schemaname = ANY(:schemas)
"""

_FETCH_RLS_ENABLED_SQL = """\
SELECT
    n.nspname AS schemaname,
    c.relname AS tablename
FROM pg_class c
JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE c.relrowsecurity = true
  AND n.nspname = ANY(:schemas)
"""


@dataclass
class CreateRLSPolicyOp:
    """Alembic operation: create an RLS policy."""

    policy: RLSPolicy

    def to_sql(self) -> list[str]:
        """Return DDL statements for this operation."""
        return [self.policy.to_sql_enable_rls(), self.policy.to_sql_create()]


@dataclass
class DropRLSPolicyOp:
    """Alembic operation: drop an RLS policy."""

    policy: RLSPolicy

    def to_sql(self) -> list[str]:
        """Return DDL statements for this operation."""
        return [self.policy.to_sql_drop()]


@dataclass
class EnableRLSOp:
    """Alembic operation: enable RLS on a table (no policy yet)."""

    schema: str
    table: str

    def to_sql(self) -> list[str]:
        """Return DDL statement for this operation."""
        return [
            f"ALTER TABLE {self.schema}.{self.table} ENABLE ROW LEVEL SECURITY"
        ]


def _fetch_current_policies(
    connection: Connection,
    schemas: list[str],
) -> dict[tuple[str, str, str], dict]:
    """Return the current policies keyed by (schema, table, name).

    Args:
        connection: Active database connection.
        schemas: Schema names to inspect.

    Returns:
        Mapping from ``(schema, table, policyname)`` to a dict of
        policy attributes.

    """
    from sqlalchemy import text  # noqa: PLC0415

    rows = connection.execute(
        text(_FETCH_POLICIES_SQL),
        {"schemas": schemas},
    ).fetchall()

    return {
        (row.schemaname, row.tablename, row.policyname): {
            "permissive": row.permissive == "PERMISSIVE",
            "cmd": row.cmd,
            "using": row.qual,
        }
        for row in rows
    }


def _fetch_rls_enabled_tables(
    connection: Connection,
    schemas: list[str],
) -> set[tuple[str, str]]:
    """Return set of (schema, table) pairs with RLS enabled.

    Args:
        connection: Active database connection.
        schemas: Schema names to inspect.

    Returns:
        Set of ``(schemaname, tablename)`` tuples.

    """
    from sqlalchemy import text  # noqa: PLC0415

    rows = connection.execute(
        text(_FETCH_RLS_ENABLED_SQL),
        {"schemas": schemas},
    ).fetchall()
    return {(row.schemaname, row.tablename) for row in rows}


def compare_rls_policies(
    connection: Connection,
    desired: RLSPolicies,
) -> list[CreateRLSPolicyOp | DropRLSPolicyOp]:
    """Diff desired RLS policies against the current database state.

    Args:
        connection: Active database connection.
        desired: The :class:`~pgcraft.rls.base.RLSPolicies` holder
            read from metadata.

    Returns:
        List of :class:`CreateRLSPolicyOp` and
        :class:`DropRLSPolicyOp` operations to bring the database in
        sync with the declared policies.

    """
    schemas = list({p.schema for p in desired.policies})
    current = _fetch_current_policies(connection, schemas)

    desired_keys = {(p.schema, p.table, p.name): p for p in desired.policies}

    ops: list[CreateRLSPolicyOp | DropRLSPolicyOp] = []

    # Policies to create: in desired but not in current.
    for key, policy in desired_keys.items():
        if key not in current:
            ops.append(CreateRLSPolicyOp(policy=policy))

    # Policies to drop: in current but not in desired (for tracked
    # schemas only).
    for key in current:
        if key not in desired_keys:
            schema, table, name = key
            # Only drop policies on tables that have at least one
            # desired policy, to avoid touching unmanaged tables.
            managed_tables = {(p.schema, p.table) for p in desired.policies}
            if (schema, table) in managed_tables:
                from pgcraft.rls.base import RLSPolicy  # noqa: PLC0415

                ops.append(
                    DropRLSPolicyOp(
                        policy=RLSPolicy(
                            table=table,
                            schema=schema,
                            name=name,
                            using="",
                        )
                    )
                )

    return ops
