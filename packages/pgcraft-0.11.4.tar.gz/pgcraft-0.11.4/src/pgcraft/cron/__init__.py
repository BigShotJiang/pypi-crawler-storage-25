"""pg_cron job declarations for pgcraft."""

from pgcraft.cron.base import CronJob, CronJobs, register_cron_job

__all__ = [
    "CronJob",
    "CronJobs",
    "register_cron_job",
]
