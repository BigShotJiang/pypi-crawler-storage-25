"""Alembic event registration for pg_cron job autogenerate.

Call :func:`register_cron_alembic_events` once in ``env.py`` to
enable cron job diffing during ``alembic revision --autogenerate``::

    from pgcraft.cron.alembic import register_cron_alembic_events
    register_cron_alembic_events()

Alembic will then emit ``op.execute("SELECT cron.schedule(...)")``
for any :class:`~pgcraft.cron.base.CronJob` in metadata that is not
yet present in ``cron.job``.  Jobs are never dropped automatically;
use :class:`~pgcraft.cron.compare.UnscheduleCronJobOp` in a
hand-written migration to remove a job.
"""

# No `from __future__ import annotations` — AutogenContext is a runtime import.
_alembic_registered = False

from alembic.autogenerate.api import AutogenContext  # noqa: E402
from alembic.autogenerate.compare import comparators  # noqa: E402
from alembic.autogenerate.render import renderers  # noqa: E402

from pgcraft.cron.base import CronJobs  # noqa: E402
from pgcraft.cron.compare import (  # noqa: E402
    ScheduleCronJobOp,
    UnscheduleCronJobOp,
    compare_cron_jobs,
)


def _compare_cron(
    autogen_context: AutogenContext,
    upgrade_ops: object,
    _schemas: object,
) -> None:
    jobs = CronJobs.extract(autogen_context.metadata)
    if not jobs:
        return
    assert autogen_context.connection is not None  # noqa: S101
    result = compare_cron_jobs(autogen_context.connection, jobs)
    upgrade_ops.ops.extend(result)  # type: ignore[union-attr]


def _render_cron_op(
    _autogen_context: AutogenContext,
    op: ScheduleCronJobOp | UnscheduleCronJobOp,
) -> list[str]:
    return [f'op.execute("{cmd}")' for cmd in op.to_sql()]


def register_cron_alembic_events() -> None:
    """Register pg_cron comparator and renderer with Alembic.

    Call once in ``env.py``::

        from pgcraft.cron.alembic import register_cron_alembic_events
        register_cron_alembic_events()

    Safe to call multiple times; subsequent calls are no-ops.
    """
    global _alembic_registered  # noqa: PLW0603
    if _alembic_registered:
        return
    _alembic_registered = True

    comparators.dispatch_for("schema")(_compare_cron)
    renderers.dispatch_for(ScheduleCronJobOp)(_render_cron_op)
    renderers.dispatch_for(UnscheduleCronJobOp)(_render_cron_op)
