"""View factories for pgcraft."""

from pgcraft.functions import PGCraftFunction
from pgcraft.views.view import PGCraftMaterializedView, PGCraftPlainView

__all__ = [
    "PGCraftFunction",
    "PGCraftMaterializedView",
    "PGCraftPlainView",
]
