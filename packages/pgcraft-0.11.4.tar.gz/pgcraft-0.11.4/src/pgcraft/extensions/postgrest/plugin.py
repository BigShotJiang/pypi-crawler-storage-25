"""PostgREST view plugin: creates the PostgREST-facing view and resource."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from sqlalchemy import literal_column, select
from sqlalchemy_declarative_extensions import View, register_view

if TYPE_CHECKING:
    from collections.abc import Callable

    from sqlalchemy import Table
    from sqlalchemy.sql.expression import Select

    from pgcraft.factory.context import FactoryContext

from pgcraft.plugin import Dynamic, Plugin, produces, requires
from pgcraft.resource import (
    APIResource,
    Grant,
    register_api_resource,
)
from pgcraft.utils.query import compile_query
from pgcraft.utils.trigger import register_view_triggers

_NAMING_DEFAULTS = {
    "postgrest_function": "%(schema)s_%(table_name)s_%(op)s",
    "postgrest_trigger": "%(schema)s_%(table_name)s_%(op)s",
}


def _resolve_columns(
    primary: Table,
    columns: list[str],
    alias: str = "p",
) -> list[Any]:
    """Build a select list from column names.

    Resolves each name against the table's columns.
    Raises ``ValueError`` for unknown names.

    Args:
        primary: The source table.
        columns: Column names to include.
        alias: Table alias prefix for column references.

    Returns:
        List of labeled column expressions.

    Raises:
        ValueError: If a column name is not found on the table.

    """
    table_cols = {col.key for col in primary.columns}
    result: list[Any] = []

    for name in columns:
        if name in table_cols:
            result.append(literal_column(f"{alias}.{name}").label(name))
        else:
            msg = (
                f"Column {name!r} not found in table "
                f"columns ({sorted(table_cols)})"
            )
            raise ValueError(msg)

    return result


def _resolve_included_columns(
    primary: Table,
    columns: list[str] | None,
    exclude_columns: list[str] | None,
) -> list[str] | None:
    """Resolve the effective column list.

    Args:
        primary: The source table.
        columns: Explicit include list (or ``None``).
        exclude_columns: Explicit exclude list (or ``None``).

    Returns:
        Resolved column name list, or ``None`` for all columns.

    Raises:
        ValueError: If both are set, or an excluded column is
            not found on the table.

    """
    if columns is not None and exclude_columns is not None:
        msg = (
            "Cannot specify both 'columns' and"
            " 'exclude_columns' on PostgRESTPlugin"
        )
        raise ValueError(msg)

    if exclude_columns is not None:
        table_cols = {col.key for col in primary.columns}
        for name in exclude_columns:
            if name not in table_cols:
                msg = (
                    f"Column {name!r} in exclude_columns "
                    f"not found on table "
                    f"({sorted(table_cols)})"
                )
                raise ValueError(msg)
        return [
            col.key for col in primary.columns if col.key not in exclude_columns
        ]

    return columns


@produces(Dynamic("view_key"))
@requires(Dynamic("table_key"))
class PostgRESTPlugin(Plugin):
    """Create a PostgREST-facing view, register its grants and triggers.

    Reads ``ctx[table_key]`` to build a view query, registers
    the resulting view, stores it as ``ctx[view_key]``, registers
    the API resource for role/grant generation, and registers
    INSTEAD OF triggers on the api view that write through to the
    factory's dimension view (``{schemaname}.{tablename}``).

    Args:
        schema: Schema for the API view (default ``"api"``).
        grants: PostgREST privileges (default ``["select"]``).
        table_key: Key in ``ctx`` to read the source table or
            view proxy from (default ``"primary"``).
        view_key: Key in ``ctx`` to store the created view
            under (default ``"api"``).
        columns: Column names to include in the view. Mutually
            exclusive with ``exclude_columns``.
        exclude_columns: Column names to exclude from the view.
            Mutually exclusive with ``columns``.
        query: Optional ``Select`` for full SQLAlchemy control
            over the view definition.  When provided, overrides
            ``columns`` and ``exclude_columns``.

    """

    def __init__(  # noqa: PLR0913
        self,
        schema: str = "api",
        grants: list[Grant] | None = None,
        table_key: str = "primary",
        view_key: str = "api",
        columns: list[str] | None = None,
        exclude_columns: list[str] | None = None,
        query: Callable[[Select, Table], Select] | Select | None = None,
    ) -> None:
        """Store the API configuration and context keys."""
        self.schema = schema
        self.grants: list[Grant] = grants if grants is not None else ["select"]
        self.table_key = table_key
        self.view_key = view_key
        self.columns = columns
        self.exclude_columns = exclude_columns
        self.query = query

    def run(self, ctx: FactoryContext) -> None:
        """Create the API view, register the resource, and register triggers."""
        primary = ctx[self.table_key]
        effective_columns = _resolve_included_columns(
            primary, self.columns, self.exclude_columns
        )
        definition = self._build_definition(primary, effective_columns)

        view = View(
            ctx.tablename,
            definition,
            schema=self.schema,
        )
        register_view(ctx.metadata, view)
        ctx[self.view_key] = view

        register_api_resource(
            ctx.metadata,
            APIResource(
                name=ctx.tablename,
                schema=self.schema,
                grants=self.grants,
            ),
        )

        self._register_triggers(ctx, primary, effective_columns)

    def _register_triggers(
        self,
        ctx: FactoryContext,
        primary: Table,
        effective_columns: list[str] | None,
    ) -> None:
        """Register INSTEAD OF triggers on the api view.

        Triggers write through to the factory's dimension view at
        ``{schemaname}.{tablename}``.

        Args:
            ctx: The active factory context.
            primary: The factory view proxy (source table).
            effective_columns: Resolved api view column list, or
                ``None`` for all columns.

        """
        pk_name = ctx.pk_column_name
        factory_view = f"{ctx.schemaname}.{ctx.tablename}"

        if effective_columns is not None:
            non_pk_cols = [c for c in effective_columns if c != pk_name]
        else:
            non_pk_cols = [
                c.key
                for c in primary.columns
                if not c.primary_key and not c.computed
            ]

        col_list = ", ".join(non_pk_cols)
        new_vals = ", ".join(f"NEW.{c}" for c in non_pk_cols)
        set_clause = ", ".join(f"{c} = NEW.{c}" for c in non_pk_cols)

        insert_body = (
            f"BEGIN\n"
            f"INSERT INTO {factory_view} ({col_list})\n"
            f"VALUES ({new_vals})\n"
            f"RETURNING * INTO NEW;\n"
            f"RETURN NEW;\n"
            f"END;"
        )
        update_body = (
            f"BEGIN\n"
            f"UPDATE {factory_view}\n"
            f"SET {set_clause}\n"
            f"WHERE {pk_name} = OLD.{pk_name}\n"
            f"RETURNING * INTO NEW;\n"
            f"RETURN NEW;\n"
            f"END;"
        )
        delete_body = (
            f"BEGIN\n"
            f"DELETE FROM {factory_view} WHERE {pk_name} = OLD.{pk_name};\n"
            f"RETURN OLD;\n"
            f"END;"
        )

        register_view_triggers(
            ctx.metadata,
            view_schema=self.schema,
            view_fullname=f"{self.schema}.{ctx.tablename}",
            tablename=ctx.tablename,
            ops=[
                ("insert", insert_body),
                ("update", update_body),
                ("delete", delete_body),
            ],
            naming_defaults=_NAMING_DEFAULTS,
            function_key="postgrest_function",
            trigger_key="postgrest_trigger",
        )

    def _build_definition(
        self,
        primary: Table,
        effective_columns: list[str] | None,
    ) -> str:
        """Build the SQL definition for the API view."""
        if self.query is not None:
            if callable(self.query):
                query_fn = cast("Callable[[Select, Table], Select]", self.query)
                base_query = select(
                    *[col.label(col.key) for col in primary.columns]
                ).select_from(primary)
                return compile_query(query_fn(base_query, primary))
            return compile_query(self.query)

        if effective_columns is not None:
            alias = "p"
            select_cols = _resolve_columns(primary, effective_columns, alias)
            source = primary.alias(alias)
            view_query = select(*select_cols).select_from(source)
            return compile_query(view_query)

        select_cols = [col.label(col.key) for col in primary.columns]
        view_query = select(*select_cols).select_from(primary)
        return compile_query(view_query)
