"""Rolling and period aggregation query builders for ledger factories.

Provides pure-Python helpers that return SQLAlchemy selects without
registering anything on metadata.  Pass results to
:class:`~pgcraft.views.view.PGCraftPlainView` or
:class:`~pgcraft.views.view.PGCraftMaterializedView`.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

from sqlalchemy import func, select, text

if TYPE_CHECKING:
    from sqlalchemy import Select

    from pgcraft.factory.context import ContextSource

from pgcraft.errors import PGCraftValidationError

_VALID_PERIODS = frozenset(
    [
        "microsecond",
        "millisecond",
        "second",
        "minute",
        "hour",
        "day",
        "week",
        "month",
        "quarter",
        "year",
        "decade",
        "century",
        "millennium",
    ]
)

Period = Literal[
    "microsecond",
    "millisecond",
    "second",
    "minute",
    "hour",
    "day",
    "week",
    "month",
    "quarter",
    "year",
    "decade",
    "century",
    "millennium",
]


def ledger_running_balance_query(
    source: ContextSource,
    dimensions: list[str],
) -> Select:
    """Build a running balance query using a window function.

    Generates::

        SELECT dim_col1, ..., created_at, value,
               SUM(value) OVER (
                   PARTITION BY dim_col1, ...
                   ORDER BY created_at
                   ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
               ) AS running_balance
        FROM <primary_table>
        ORDER BY dim_col1, ..., created_at

    Args:
        source: A :class:`~pgcraft.factory.ledger.PGCraftLedger`
            instance or a :class:`~pgcraft.declarative.PGCraftBase`
            subclass using ``PGCraftLedger`` as its factory.
        dimensions: Column names to partition by.  Must be a
            non-empty list.

    Returns:
        A SQLAlchemy :class:`~sqlalchemy.Select`.

    Raises:
        PGCraftValidationError: If *dimensions* is empty.

    """
    if not dimensions:
        msg = "dimensions must be a non-empty list"
        raise PGCraftValidationError(msg)

    table = source.ctx["primary"]
    created_at_col = source.ctx["created_at_column"]
    dim_cols = [table.c[d] for d in dimensions]
    order_col = table.c[created_at_col]

    running_balance = (
        func.sum(table.c["value"])
        .over(
            partition_by=dim_cols,
            order_by=order_col,
            rows=(None, 0),
        )
        .label("running_balance")
    )

    return (
        select(
            *[c.label(c.key) for c in dim_cols],
            order_col.label(created_at_col),
            table.c["value"].label("value"),
            running_balance,
        )
        .select_from(table)
        .order_by(*dim_cols, order_col)
    )


def ledger_period_rollup_query(
    source: ContextSource,
    dimensions: list[str],
    period: Period = "day",
) -> Select:
    """Build a period rollup query using ``date_trunc``.

    Generates::

        SELECT date_trunc('day', created_at) AS period,
               dim_col1, ...,
               SUM(value) AS balance
        FROM <primary_table>
        GROUP BY 1, dim_col1, ...
        ORDER BY 1, dim_col1, ...

    Args:
        source: A :class:`~pgcraft.factory.ledger.PGCraftLedger`
            instance or a :class:`~pgcraft.declarative.PGCraftBase`
            subclass using ``PGCraftLedger`` as its factory.
        dimensions: Column names to group by.  Must be a
            non-empty list.
        period: ``date_trunc`` precision string, e.g. ``"day"``,
            ``"week"``, ``"month"``, ``"year"``.
            Defaults to ``"day"``.

    Returns:
        A SQLAlchemy :class:`~sqlalchemy.Select`.

    Raises:
        PGCraftValidationError: If *dimensions* is empty or *period*
            is not a valid ``date_trunc`` precision.

    """
    if not dimensions:
        msg = "dimensions must be a non-empty list"
        raise PGCraftValidationError(msg)
    if period not in _VALID_PERIODS:
        msg = (
            f"Unknown period {period!r}. "
            f"Must be one of: {sorted(_VALID_PERIODS)}"
        )
        raise PGCraftValidationError(msg)

    table = source.ctx["primary"]
    created_at_col = source.ctx["created_at_column"]
    dim_cols = [table.c[d] for d in dimensions]

    period_expr = func.date_trunc(
        text(f"'{period}'"),
        table.c[created_at_col],
    ).label("period")

    return (
        select(
            period_expr,
            *[c.label(c.key) for c in dim_cols],
            func.sum(table.c["value"]).label("balance"),
        )
        .select_from(table)
        .group_by(text("1"), *dim_cols)
        .order_by(text("1"), *dim_cols)
    )
