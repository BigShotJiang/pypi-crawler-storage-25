/**
 * API client for the forge-dashboard backend.
 */

const API_BASE = "/v1";

function getApiKey(): string {
  return localStorage.getItem("forge_api_key") || "";
}

async function apiFetch<T>(
  path: string,
  options: RequestInit = {},
): Promise<T> {
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    "X-API-Key": getApiKey(),
    ...(options.headers as Record<string, string>),
  };
  const res = await fetch(`${API_BASE}${path}`, { ...options, headers });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`API error ${res.status}: ${text}`);
  }
  return res.json();
}

export interface Session {
  trace_id: string;
  first_span: string;
  last_span: string;
  span_count: number;
}

export interface Span {
  span_id: string;
  parent_span_id: string | null;
  name: string;
  kind: string;
  start_time: string;
  end_time: string;
  attributes: Record<string, unknown>;
  status_code: string;
  status_message: string;
}

export interface BudgetPoint {
  name: string;
  value: number;
  timestamp: string;
  attributes: Record<string, unknown>;
}

export interface TokenSplit {
  thinking_tokens: number;
  response_tokens: number;
  total: number;
}

export interface ModeSwitch {
  span_id: string;
  trace_id: string;
  start_time: string;
  attributes: Record<string, unknown>;
}

export interface AlertRule {
  id: number;
  name: string;
  metric_name: string;
  condition: string;
  threshold: number;
  channel: string;
  enabled: number;
  created_at: string;
}

export function getSessions(limit = 50, offset = 0): Promise<Session[]> {
  return apiFetch(`/sessions?limit=${limit}&offset=${offset}`);
}

export function getSessionSpans(traceId: string): Promise<Span[]> {
  return apiFetch(`/sessions/${encodeURIComponent(traceId)}`);
}

export function getBudget(traceId?: string): Promise<BudgetPoint[]> {
  const q = traceId ? `?trace_id=${encodeURIComponent(traceId)}` : "";
  return apiFetch(`/budget${q}`);
}

export function getTokenSplit(traceId?: string): Promise<TokenSplit> {
  const q = traceId ? `?trace_id=${encodeURIComponent(traceId)}` : "";
  return apiFetch(`/token-split${q}`);
}

export function getModeSwitches(
  traceId?: string,
  limit = 100,
): Promise<ModeSwitch[]> {
  const params = new URLSearchParams();
  if (traceId) params.set("trace_id", traceId);
  params.set("limit", String(limit));
  return apiFetch(`/mode-switches?${params}`);
}

export function getAlerts(): Promise<AlertRule[]> {
  return apiFetch("/alerts");
}

export function createAlert(rule: {
  name: string;
  metric_name: string;
  condition: string;
  threshold: number;
  channel?: string;
}): Promise<AlertRule> {
  return apiFetch("/alerts", {
    method: "POST",
    body: JSON.stringify(rule),
  });
}

export function deleteAlert(ruleId: number): Promise<{ status: string }> {
  return apiFetch(`/alerts/${ruleId}`, { method: "DELETE" });
}

