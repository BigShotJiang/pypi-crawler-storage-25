"""Background scheduler for periodic alert evaluation and data retention."""

from __future__ import annotations

import asyncio
import logging
import os
from datetime import datetime, timezone

from backend.alerts import evaluate_alerts
from backend.db import get_connection

logger = logging.getLogger(__name__)

ALERT_INTERVAL = int(os.getenv("FORGE_ALERT_INTERVAL_SECONDS", "60"))
RETENTION_INTERVAL = 3600


def _get_all_project_ids() -> list[int]:
    with get_connection() as conn:
        rows = conn.execute("SELECT id FROM projects").fetchall()
        return [r["id"] for r in rows]


def _run_retention_cleanup() -> int:
    retention_days = int(os.getenv("FORGE_RETENTION_DAYS", "7"))
    cutoff = datetime.now(timezone.utc).timestamp() - (retention_days * 86400)
    # Spans store start_time as nanosecond strings (from OTLP startTimeUnixNano).
    # Metrics store timestamp as either nanosecond strings (OTLP) or ISO-8601
    # strings (fallback in store_metrics). The metrics query uses ORDER BY
    # timestamp DESC which works for both formats, but this numeric comparison
    # only matches nanosecond-format rows. ISO-format rows will not be cleaned
    # up by this query -- acceptable since direct OTLP ingest always uses nanos.
    cutoff_str = str(int(cutoff * 1e9))
    total = 0
    with get_connection() as conn:
        cur = conn.execute(
            "DELETE FROM spans WHERE start_time < ?", (cutoff_str,)
        )
        total += cur.rowcount
        cur = conn.execute(
            "DELETE FROM metrics WHERE timestamp < ?", (cutoff_str,)
        )
        total += cur.rowcount
        conn.commit()
    return total


def _evaluate_all_alerts() -> None:
    project_ids = _get_all_project_ids()
    for pid in project_ids:
        evaluate_alerts(pid)


async def alert_loop() -> None:
    while True:
        try:
            await asyncio.to_thread(_evaluate_all_alerts)
        except Exception:
            logger.exception("Alert evaluation failed")
        await asyncio.sleep(ALERT_INTERVAL)


async def retention_loop() -> None:
    while True:
        try:
            deleted = await asyncio.to_thread(_run_retention_cleanup)
            if deleted > 0:
                logger.info("Retention cleanup: removed %d rows", deleted)
        except Exception:
            logger.exception("Retention cleanup failed")
        await asyncio.sleep(RETENTION_INTERVAL)
