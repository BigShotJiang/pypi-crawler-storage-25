# AI Docs Toolkit

AI Docs Toolkit is a documentation toolkit for AI-assisted software development.

It treats documentation as an engineering interface between humans, AI agents, code, tests and change management. The project is post-MVP and is hardening planning, validation, distribution and integration workflows.

## Purpose

The toolkit is intended for projects where:
- AI agents participate in implementation;
- system knowledge must stay readable for humans and usable by automation;
- documentation should define constraints, expected behavior and validation rules;
- changes should be traceable across business rules, architecture, contracts, modules, acceptance criteria and code.

The core idea is that documentation should not be a secondary artifact created after implementation. It should guide implementation, validation and review.

## Current Status

The published beta package includes:
- schema and structure validation for Markdown documents with YAML front matter;
- document graph output;
- impact analysis;
- context bundle output;
- an executable `ai-docs` CLI;
- optional local MCP runtime entrypoint.

## Installation

Install the published beta package:

```bash
python -m pip install ai-docs-toolkit==0.1.0b8
ai-docs --version
```

For ephemeral execution with `uvx`:

```bash
uvx --from ai-docs-toolkit==0.1.0b8 ai-docs --version
```

For the optional local MCP runtime:

```bash
python -m pip install "ai-docs-toolkit[mcp]==0.1.0b8"
ai-docs-mcp --project-root .
```

After a stable release exists, package install commands can omit the beta version pin.

## Quick Start

Bootstrap a repository for AI Docs Toolkit:

```bash
ai-docs init
ai-docs validate
```

For a documentation-only bootstrap without `AGENTS.md`:

```bash
ai-docs init --profile minimal
```

The command creates missing toolkit files and skips existing files by default.
Use `--force` only when you explicitly want to overwrite toolkit-owned target files.

Validate a configured project:

```bash
ai-docs validate
```

Generate machine-readable validation output:

```bash
ai-docs validate --json
```

Build a document graph:

```bash
ai-docs graph --format json
```

Analyze impact for changed files:

```bash
ai-docs impact --changed
```

Prepare an agent context bundle for changed files:

```bash
ai-docs context --changed
```

## Repository Bootstrap

Repository bootstrap is an explicit command.
Package installation does not modify project files.

Default agent-oriented bootstrap:

```bash
ai-docs init
```

Minimal bootstrap:

```bash
ai-docs init --profile minimal
```

The source repository may be private or unavailable to agents in consuming projects.
Package usage does not require access to repository-local documentation files.

## AI Agent Instructions

The package includes an agent-readable instruction document for install, update, bootstrap, validation and context commands.

Give this short instruction to an agent that can inspect installed package resources:

```text
Install `ai-docs-toolkit`, then configure this repository by following the packaged instructions in `ai_docs_toolkit/docs/agent-installation.md`.
```

After installation, an agent can locate it with:

```bash
python -c "from importlib import resources; print(resources.files('ai_docs_toolkit').joinpath('docs/agent-installation.md'))"
```

Operators can give the prompt from that document to an AI agent when asking it to install or update the toolkit in a consuming repository.

## Development

Source checkout development install:

```bash
python -m pip install -e ".[dev]"
ai-docs --version
ai-docs validate
```

Current CI/source checkout install contract:

```bash
python -m pip install -e .
ai-docs validate --json
```

## License

License is not selected yet.
