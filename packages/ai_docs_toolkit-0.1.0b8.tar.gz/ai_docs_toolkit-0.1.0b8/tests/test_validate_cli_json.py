import json
from pathlib import Path

from ai_docs_toolkit.cli import main
from ai_docs_toolkit.validation import format_json_validation_result, validate_project_human


FIXTURES_ROOT = Path(__file__).parent / "fixtures" / "validate"


def test_validate_json_output_passes_for_success_fixture(monkeypatch, capsys):
    monkeypatch.chdir(FIXTURES_ROOT / "success")

    assert main(["validate", "--json"]) == 0

    output = capsys.readouterr()
    payload = json.loads(output.out)
    assert payload == {
        "issues": [],
        "ok": True,
        "summary": {
            "issue_count": 0,
            "schema_skipped_documents": 0,
            "schema_skipped_types": {},
            "schema_validated_documents": 2,
            "scanned_files": 2,
            "validated_documents": 2,
        },
    }
    assert output.err == ""


def test_validate_json_output_reports_failure_fixture(monkeypatch, capsys):
    monkeypatch.chdir(FIXTURES_ROOT / "failure")

    assert main(["validate", "--json"]) == 1

    output = capsys.readouterr()
    payload = json.loads(output.out)
    assert payload["ok"] is False
    assert payload["summary"] == {
        "issue_count": 1,
        "schema_skipped_documents": 0,
        "schema_skipped_types": {},
        "schema_validated_documents": 1,
        "scanned_files": 1,
        "validated_documents": 1,
    }
    assert payload["issues"] == [
        {
            "document_id": "BR-FIXTURE-001",
            "message": (
                "Relationship `related.modules` references unknown document "
                "id `MOD-MISSING-001`."
            ),
            "path": str((FIXTURES_ROOT / "failure" / "ai-docs" / "rule.md").resolve()),
            "rule_id": "document.relationship.unresolved",
            "severity": "error",
        }
    ]
    assert output.err == ""


def test_validate_json_output_is_deterministic(monkeypatch, capsys):
    monkeypatch.chdir(FIXTURES_ROOT / "failure")

    assert main(["validate", "--json"]) == 1
    first = capsys.readouterr().out

    assert main(["validate", "--json"]) == 1
    second = capsys.readouterr().out

    assert first == second


def test_repository_and_minimal_example_validate_with_json_contract():
    repository_result = validate_project_human(Path.cwd())
    minimal_result = validate_project_human(Path.cwd() / "examples" / "minimal-project")

    repository_payload = json.loads(format_json_validation_result(repository_result))
    minimal_payload = json.loads(format_json_validation_result(minimal_result))

    assert repository_result.exit_code == 0
    assert repository_payload["ok"] is True
    assert repository_payload["summary"]["issue_count"] == 0
    assert repository_payload["summary"]["validated_documents"] > 0

    assert minimal_result.exit_code == 0
    assert minimal_payload["ok"] is True
    assert minimal_payload["summary"] == {
        "issue_count": 0,
        "schema_skipped_documents": 0,
        "schema_skipped_types": {},
        "schema_validated_documents": 8,
        "scanned_files": 8,
        "validated_documents": 8,
    }


def test_validate_json_reports_unknown_type_but_skips_known_non_schema_types(
    tmp_path,
    monkeypatch,
    capsys,
):
    docs = tmp_path / "ai-docs"
    docs.mkdir()
    (tmp_path / "ai-docs.config.yaml").write_text(
        f"""version: 1
project:
  name: unknown-type-example
  documentation_roots:
    - ai-docs
schemas:
  roots:
    - {Path.cwd() / ".ai-docs" / "schemas"}
""",
        encoding="utf-8",
    )
    (docs / "plan.md").write_text(
        """---
id: PLAN-EXAMPLE-001
type: plan
status: planned
scope:
  plan: example
owners:
  - maintainers
related: {}
ai:
  priority: medium
  load_when: []
---

# Example Plan
""",
        encoding="utf-8",
    )
    (docs / "request.md").write_text(
        """---
id: REQ-000001
type: request
status: new
scope:
  modules:
    - requests
source:
  channel: local
  reported_at: 2026-05-19
classification:
  kind: docs_gap
triage:
  status: new
related: {}
ai:
  priority: medium
  load_when: []
---

# Example Request
""",
        encoding="utf-8",
    )
    (docs / "unknown.md").write_text(
        """---
id: UNKNOWN-EXAMPLE-001
type: future_document
status: draft
title: Unknown
summary: Unknown type.
scope:
  domains: []
  modules: []
  features: []
owners:
  - maintainers
related:
  business_rules: []
  architecture_decisions: []
  contracts: []
  modules: []
  scenarios: []
  acceptance: []
  operations: []
ai:
  priority: medium
  load_when: []
  avoid_when: []
  context_role: validation
validation:
  required_checks: []
  last_validated: null
---

# Unknown
""",
        encoding="utf-8",
    )
    monkeypatch.chdir(tmp_path)

    assert main(["validate", "--json"]) == 1

    payload = json.loads(capsys.readouterr().out)
    assert payload["summary"] == {
        "issue_count": 1,
        "schema_skipped_documents": 1,
        "schema_skipped_types": {"request": 1},
        "schema_validated_documents": 1,
        "scanned_files": 3,
        "validated_documents": 3,
    }
    assert payload["issues"] == [
        {
            "document_id": "UNKNOWN-EXAMPLE-001",
            "message": "Unknown document type: 'future_document'.",
            "path": str(docs / "unknown.md"),
            "rule_id": "document.schema.unknown_type",
            "severity": "error",
        }
    ]
