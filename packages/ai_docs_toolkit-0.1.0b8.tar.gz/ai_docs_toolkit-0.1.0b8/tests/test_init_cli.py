from pathlib import Path

from ai_docs_toolkit.cli import main
from ai_docs_toolkit.core import init_project
from ai_docs_toolkit.validation import validate_project_human


def test_init_default_agent_profile_creates_bootstrap_files(
    tmp_path: Path,
    monkeypatch,
    capsys,
):
    monkeypatch.chdir(tmp_path)

    assert main(["init"]) == 0

    output = capsys.readouterr()
    assert output.err == ""
    assert "profile: agent" in output.out
    assert "- ai-docs.config.yaml" in output.out
    assert "- ai-docs/index.md" in output.out
    assert "- .ai-docs/schemas/frontmatter.schema.yaml" in output.out
    assert "- AGENTS.md" in output.out
    assert "- .ai-docs/skills/index.md" in output.out
    assert "- .ai-docs/skills/planning-task-execution/SKILL.md" in output.out
    assert "- .ai-docs/skills/planning-record-generation/SKILL.md" in output.out
    assert "- .ai-docs/skills/toolkit-consumer-policy/SKILL.md" in output.out
    assert "- .ai-docs/skills/release-publication/SKILL.md" in output.out
    assert "- .ai-docs/templates/release/release-task.md" in output.out
    assert "- .ai-docs/templates/release/migration-note.md" in output.out
    assert "- .ai-docs/examples/skills/pypi-package-release/SKILL.md" in output.out
    assert "- .ai-docs/workflows/plan-stage-workflow.md" in output.out
    assert "- .ai-docs/workflows/toolkit-migration-workflow.md" in output.out
    assert "- .ai-docs/reference/planning-document-model.md" in output.out
    assert (tmp_path / "ai-docs.config.yaml").is_file()
    assert (tmp_path / "ai-docs" / "index.md").is_file()
    assert (tmp_path / ".ai-docs" / "schemas" / "frontmatter.schema.yaml").is_file()
    assert (
        tmp_path
        / ".ai-docs"
        / "schemas"
        / "document-types"
        / "business-rule.schema.yaml"
    ).is_file()
    assert (tmp_path / "AGENTS.md").is_file()
    assert (tmp_path / ".ai-docs" / "skills" / "index.md").is_file()
    assert (
        tmp_path / ".ai-docs" / "skills" / "planning-task-execution" / "SKILL.md"
    ).is_file()
    assert (
        tmp_path / ".ai-docs" / "skills" / "planning-record-generation" / "SKILL.md"
    ).is_file()
    assert (
        tmp_path / ".ai-docs" / "skills" / "toolkit-consumer-policy" / "SKILL.md"
    ).is_file()
    assert (
        tmp_path / ".ai-docs" / "skills" / "release-publication" / "SKILL.md"
    ).is_file()
    assert (
        tmp_path / ".ai-docs" / "templates" / "release" / "release-task.md"
    ).is_file()
    assert (
        tmp_path / ".ai-docs" / "templates" / "release" / "migration-note.md"
    ).is_file()
    assert (
        tmp_path / ".ai-docs" / "examples" / "skills" / "pypi-package-release" / "SKILL.md"
    ).is_file()
    assert not (
        tmp_path / ".ai-docs" / "skills" / "pypi-package-release" / "SKILL.md"
    ).exists()
    assert (tmp_path / ".ai-docs" / "workflows" / "plan-stage-workflow.md").is_file()
    assert (
        tmp_path / ".ai-docs" / "workflows" / "toolkit-migration-workflow.md"
    ).is_file()
    assert (
        tmp_path / ".ai-docs" / "reference" / "planning-document-model.md"
    ).is_file()


def test_init_minimal_profile_does_not_create_agents_file(
    tmp_path: Path,
    monkeypatch,
    capsys,
):
    monkeypatch.chdir(tmp_path)

    assert main(["init", "--profile", "minimal"]) == 0

    output = capsys.readouterr()
    assert output.err == ""
    assert "profile: minimal" in output.out
    assert (tmp_path / "ai-docs.config.yaml").is_file()
    assert (tmp_path / "ai-docs" / "index.md").is_file()
    assert (tmp_path / ".ai-docs" / "schemas" / "frontmatter.schema.yaml").is_file()
    assert not (tmp_path / "AGENTS.md").exists()
    assert not (tmp_path / ".ai-docs" / "skills" / "index.md").exists()
    assert not (tmp_path / ".ai-docs" / "skills").exists()
    assert not (tmp_path / ".ai-docs" / "workflows").exists()


def test_init_minimal_profile_outputs_valid_project(tmp_path: Path, monkeypatch):
    monkeypatch.chdir(tmp_path)

    assert main(["init", "--profile", "minimal"]) == 0

    result = validate_project_human(tmp_path)
    assert result.exit_code == 0
    assert result.messages == ()


def test_init_skips_existing_files_by_default(tmp_path: Path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)

    assert main(["init"]) == 0
    capsys.readouterr()
    assert main(["init"]) == 0

    output = capsys.readouterr()
    assert output.err == ""
    assert "created:\n- none" in output.out
    assert "skipped:" in output.out
    assert "- ai-docs.config.yaml" in output.out
    assert "- ai-docs/index.md" in output.out
    assert "- .ai-docs/schemas/frontmatter.schema.yaml" in output.out
    assert "- AGENTS.md" in output.out
    assert "overwritten:" in output.out
    assert "- .ai-docs/skills/index.md" in output.out
    assert "- .ai-docs/skills/planning-task-execution/SKILL.md" in output.out
    assert "- .ai-docs/skills/release-publication/SKILL.md" in output.out
    assert "- .ai-docs/templates/release/release-task.md" in output.out
    assert "- .ai-docs/examples/skills/pypi-package-release/SKILL.md" in output.out
    assert "- .ai-docs/workflows/plan-stage-workflow.md" in output.out


def test_init_force_overwrites_toolkit_owned_files(tmp_path: Path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    (tmp_path / "ai-docs").mkdir()
    (tmp_path / "ai-docs.config.yaml").write_text("custom", encoding="utf-8")
    (tmp_path / "ai-docs" / "index.md").write_text("custom", encoding="utf-8")
    schema = tmp_path / ".ai-docs" / "schemas" / "frontmatter.schema.yaml"
    schema.parent.mkdir(parents=True)
    schema.write_text("custom", encoding="utf-8")
    (tmp_path / "AGENTS.md").write_text("custom", encoding="utf-8")
    routing_index = tmp_path / ".ai-docs" / "skills" / "index.md"
    routing_index.parent.mkdir(parents=True, exist_ok=True)
    routing_index.write_text("custom", encoding="utf-8")
    skill = tmp_path / ".ai-docs" / "skills" / "planning-task-execution" / "SKILL.md"
    skill.parent.mkdir(parents=True)
    skill.write_text("custom", encoding="utf-8")
    workflow = tmp_path / ".ai-docs" / "workflows" / "plan-stage-workflow.md"
    workflow.parent.mkdir(parents=True)
    workflow.write_text("custom", encoding="utf-8")

    assert main(["init", "--force"]) == 0

    output = capsys.readouterr()
    assert output.err == ""
    assert "overwritten:" in output.out
    assert "- ai-docs.config.yaml" in output.out
    assert "- ai-docs/index.md" in output.out
    assert "- .ai-docs/schemas/frontmatter.schema.yaml" in output.out
    assert "- AGENTS.md" in output.out
    assert "- .ai-docs/skills/index.md" in output.out
    assert "- .ai-docs/skills/planning-task-execution/SKILL.md" in output.out
    assert "- .ai-docs/workflows/plan-stage-workflow.md" in output.out
    assert (tmp_path / "ai-docs.config.yaml").read_text(encoding="utf-8") != "custom"
    assert (tmp_path / "ai-docs" / "index.md").read_text(encoding="utf-8") != "custom"
    assert schema.read_text(encoding="utf-8") != "custom"
    assert (tmp_path / "AGENTS.md").read_text(encoding="utf-8") != "custom"
    assert routing_index.read_text(encoding="utf-8") != "custom"
    assert skill.read_text(encoding="utf-8") != "custom"
    assert workflow.read_text(encoding="utf-8") != "custom"


def test_init_overwrites_toolkit_managed_planning_files_by_default(
    tmp_path: Path,
    monkeypatch,
    capsys,
):
    monkeypatch.chdir(tmp_path)
    routing_index = tmp_path / ".ai-docs" / "skills" / "index.md"
    routing_index.parent.mkdir(parents=True)
    routing_index.write_text("custom", encoding="utf-8")
    skill = tmp_path / ".ai-docs" / "skills" / "planning-task-execution" / "SKILL.md"
    skill.parent.mkdir(parents=True)
    skill.write_text("custom", encoding="utf-8")
    workflow = tmp_path / ".ai-docs" / "workflows" / "plan-stage-workflow.md"
    workflow.parent.mkdir(parents=True)
    workflow.write_text("custom", encoding="utf-8")

    assert main(["init"]) == 0

    output = capsys.readouterr()
    assert output.err == ""
    assert "overwritten:" in output.out
    assert "- .ai-docs/skills/index.md" in output.out
    assert "- .ai-docs/skills/planning-task-execution/SKILL.md" in output.out
    assert "- .ai-docs/workflows/plan-stage-workflow.md" in output.out
    assert routing_index.read_text(encoding="utf-8") != "custom"
    assert skill.read_text(encoding="utf-8") != "custom"
    assert workflow.read_text(encoding="utf-8") != "custom"


def test_init_profile_agent_force_supports_documented_argument_order(
    tmp_path: Path,
    monkeypatch,
    capsys,
):
    monkeypatch.chdir(tmp_path)
    (tmp_path / "ai-docs.config.yaml").write_text("custom", encoding="utf-8")

    assert main(["init", "--profile", "agent", "--force"]) == 0

    output = capsys.readouterr()
    assert output.err == ""
    assert "profile: agent" in output.out
    assert "overwritten:" in output.out
    assert "- ai-docs.config.yaml" in output.out
    assert (tmp_path / "AGENTS.md").is_file()


def test_init_force_does_not_delete_unrelated_files(
    tmp_path: Path,
    monkeypatch,
):
    monkeypatch.chdir(tmp_path)
    unrelated = tmp_path / "docs" / "notes.md"
    unrelated.parent.mkdir()
    unrelated.write_text("keep me", encoding="utf-8")

    assert main(["init", "--force"]) == 0

    assert unrelated.read_text(encoding="utf-8") == "keep me"


def test_init_project_core_service_uses_explicit_project_root(tmp_path: Path):
    result = init_project(tmp_path, profile="minimal")

    assert result.exit_code == 0
    assert result.profile == "minimal"
    assert result.created == (
        "ai-docs.config.yaml",
        "ai-docs/index.md",
        ".ai-docs/schemas/frontmatter.schema.yaml",
        ".ai-docs/schemas/document-types/acceptance.schema.yaml",
        ".ai-docs/schemas/document-types/architecture-decision.schema.yaml",
        ".ai-docs/schemas/document-types/business-rule.schema.yaml",
        ".ai-docs/schemas/document-types/contract.schema.yaml",
        ".ai-docs/schemas/document-types/index.schema.yaml",
        ".ai-docs/schemas/document-types/module.schema.yaml",
        ".ai-docs/schemas/document-types/plan.schema.yaml",
        ".ai-docs/schemas/document-types/plan-stage.schema.yaml",
        ".ai-docs/schemas/document-types/implementation-task.schema.yaml",
        ".ai-docs/schemas/document-types/standalone-task.schema.yaml",
        ".ai-docs/schemas/document-types/operation.schema.yaml",
        ".ai-docs/schemas/document-types/scenario.schema.yaml",
        ".ai-docs/schemas/document-types/test-case.schema.yaml",
    )
    assert result.skipped == ()
    assert result.overwritten == ()
    assert result.errors == ()
    assert (tmp_path / "ai-docs.config.yaml").is_file()
    assert (tmp_path / "ai-docs" / "index.md").is_file()
    assert (tmp_path / ".ai-docs" / "schemas" / "frontmatter.schema.yaml").is_file()


def test_init_usage_error_for_unknown_profile(capsys):
    assert main(["init", "--profile", "unknown"]) == 3

    output = capsys.readouterr()
    assert output.out == ""
    assert (
        "Usage: ai-docs init [--profile minimal|agent] [--force] [--dry-run|--check]"
        in output.err
    )


def test_init_dry_run_reports_changes_without_writing(
    tmp_path: Path,
    monkeypatch,
    capsys,
):
    monkeypatch.chdir(tmp_path)

    assert main(["init", "--dry-run"]) == 0

    output = capsys.readouterr()
    assert "ai-docs init (dry-run)" in output.out
    assert "- ai-docs.config.yaml" in output.out
    assert not (tmp_path / "ai-docs.config.yaml").exists()


def test_init_check_reports_missing_files_without_writing(
    tmp_path: Path,
    monkeypatch,
    capsys,
):
    monkeypatch.chdir(tmp_path)

    assert main(["init", "--check"]) == 1

    output = capsys.readouterr()
    assert "ai-docs init (check)" in output.out
    assert "- ai-docs.config.yaml" in output.out
    assert not (tmp_path / "ai-docs.config.yaml").exists()
