from pathlib import Path

from ai_docs_toolkit.core import (
    ContextDocument,
    ContextReason,
    ContextSelectionIssue,
    DocumentGraphEdge,
    RegistryDocument,
    RULE_DOCUMENT_CONTEXT_NO_SOURCES,
    RULE_DOCUMENT_CONTEXT_UNKNOWN_ID,
    build_document_graph,
    build_document_registry,
    select_context_by_feature,
    select_context_by_ids,
    select_context_by_module,
)


def test_context_selector_includes_source_and_direct_neighbors(tmp_path: Path):
    registry = build_document_registry(
        (
            document(
                tmp_path / "ai-docs" / "rule.md",
                document_id="BR-TEST-001",
                document_type="business_rule",
                related={"architecture_decisions": ["ADR-TEST-001"]},
                priority="high",
                context_role="constraint",
            ),
            document(
                tmp_path / "ai-docs" / "decision.md",
                document_id="ADR-TEST-001",
                document_type="architecture_decision",
                related={"modules": ["MOD-TEST-001"]},
                priority="medium",
                context_role="decision",
            ),
            document(
                tmp_path / "ai-docs" / "module.md",
                document_id="MOD-TEST-001",
                document_type="module",
                priority="medium",
                context_role="behavior",
            ),
        )
    )
    graph = build_document_graph(registry, project_root=tmp_path)

    result = select_context_by_ids(graph, registry, ["BR-TEST-001"])

    assert result.ok
    assert [(source.document_id, source.source) for source in result.sources] == [
        ("BR-TEST-001", "id")
    ]
    assert [document.document_id for document in result.documents] == [
        "BR-TEST-001",
        "ADR-TEST-001",
    ]
    assert result.documents[0] == ContextDocument(
        document_id="BR-TEST-001",
        type="business_rule",
        path="ai-docs/rule.md",
        title="BR-TEST-001 title",
        summary="BR-TEST-001 summary",
        context_role="constraint",
        priority="high",
        group="source",
        distance=0,
        reasons=(
            ContextReason(
                source="BR-TEST-001",
                via=None,
                relationship="source",
                direction="self",
                message="BR-TEST-001 is a context source.",
            ),
        ),
    )
    assert result.documents[1].distance == 1
    assert result.documents[1].group == "decision"
    assert result.documents[1].reasons == (
        ContextReason(
            source="BR-TEST-001",
            via=None,
            relationship="architecture_decisions",
            direction="outgoing",
            message=(
                "BR-TEST-001 references ADR-TEST-001 "
                "through related.architecture_decisions."
            ),
        ),
    )


def test_context_selector_uses_incoming_edges(tmp_path: Path):
    registry = build_document_registry(
        (
            document(
                tmp_path / "ai-docs" / "contract.md",
                document_id="CON-TEST-001",
                document_type="contract",
                related={"modules": ["MOD-TEST-001"]},
            ),
            document(
                tmp_path / "ai-docs" / "module.md",
                document_id="MOD-TEST-001",
                document_type="module",
            ),
        )
    )
    graph = build_document_graph(registry, project_root=tmp_path)

    result = select_context_by_ids(graph, registry, ["MOD-TEST-001"])

    assert [document.document_id for document in result.documents] == [
        "MOD-TEST-001",
        "CON-TEST-001",
    ]
    assert result.documents[1].reasons[0].direction == "incoming"


def test_context_selector_selects_sources_by_module_and_feature(tmp_path: Path):
    registry = build_document_registry(
        (
            document(
                tmp_path / "ai-docs" / "checkout.md",
                document_id="MOD-CHECKOUT-001",
                document_type="module",
                scope={
                    "domains": [],
                    "modules": ["checkout"],
                    "features": ["submit-order"],
                },
            ),
            document(
                tmp_path / "ai-docs" / "billing.md",
                document_id="MOD-BILLING-001",
                document_type="module",
                scope={
                    "domains": [],
                    "modules": ["billing"],
                    "features": ["invoice"],
                },
            ),
        )
    )
    graph = build_document_graph(registry, project_root=tmp_path)

    by_module = select_context_by_module(graph, registry, "checkout")
    by_feature = select_context_by_feature(graph, registry, "submit-order")

    assert [source.document_id for source in by_module.sources] == ["MOD-CHECKOUT-001"]
    assert by_module.sources[0].source == "module"
    assert [source.document_id for source in by_feature.sources] == ["MOD-CHECKOUT-001"]
    assert by_feature.sources[0].source == "feature"


def test_context_selector_excludes_deprecated_archived_and_exported_documents(
    tmp_path: Path,
):
    registry = build_document_registry(
        (
            document(
                tmp_path / "ai-docs" / "rule.md",
                document_id="BR-TEST-001",
                document_type="business_rule",
                related={
                    "architecture_decisions": [
                        "ADR-ACTIVE-001",
                        "ADR-DEPRECATED-001",
                        "ADR-ARCHIVED-001",
                        "ADR-EXPORTED-001",
                    ]
                },
            ),
            document(
                tmp_path / "ai-docs" / "active.md",
                document_id="ADR-ACTIVE-001",
                document_type="architecture_decision",
            ),
            document(
                tmp_path / "ai-docs" / "deprecated.md",
                document_id="ADR-DEPRECATED-001",
                document_type="architecture_decision",
                status="deprecated",
            ),
            document(
                tmp_path / "ai-docs" / "archived.md",
                document_id="ADR-ARCHIVED-001",
                document_type="architecture_decision",
                status="archived",
            ),
            document(
                tmp_path / "ai-docs" / "exported.md",
                document_id="ADR-EXPORTED-001",
                document_type="architecture_decision",
                status="exported",
            ),
        )
    )
    graph = build_document_graph(registry, project_root=tmp_path)

    result = select_context_by_ids(graph, registry, ["BR-TEST-001"])

    assert [document.document_id for document in result.documents] == [
        "BR-TEST-001",
        "ADR-ACTIVE-001",
    ]


def test_context_selector_reports_unknown_id_and_missing_sources(tmp_path: Path):
    registry = build_document_registry(())
    graph = build_document_graph(registry, project_root=tmp_path)

    result = select_context_by_ids(graph, registry, ["UNKNOWN-001"])

    assert not result.ok
    assert result.sources == ()
    assert result.documents == ()
    assert result.issues == (
        ContextSelectionIssue(
            rule_id=RULE_DOCUMENT_CONTEXT_UNKNOWN_ID,
            message="Context source references unknown document id `UNKNOWN-001`.",
            document_id="UNKNOWN-001",
        ),
        ContextSelectionIssue(
            rule_id=RULE_DOCUMENT_CONTEXT_NO_SOURCES,
            message="Context selection did not find source documents.",
        ),
    )


def test_context_selector_output_is_deterministic(tmp_path: Path):
    registry = build_document_registry(
        (
            document(
                tmp_path / "ai-docs" / "rule.md",
                document_id="BR-TEST-001",
                document_type="business_rule",
                related={
                    "acceptance": ["ACC-TEST-002", "ACC-TEST-001"],
                    "architecture_decisions": ["ADR-TEST-001"],
                },
            ),
            document(
                tmp_path / "ai-docs" / "acceptance-b.md",
                document_id="ACC-TEST-002",
                document_type="acceptance",
                priority="low",
            ),
            document(
                tmp_path / "ai-docs" / "acceptance-a.md",
                document_id="ACC-TEST-001",
                document_type="acceptance",
                priority="high",
            ),
            document(
                tmp_path / "ai-docs" / "decision.md",
                document_id="ADR-TEST-001",
                document_type="architecture_decision",
                priority="medium",
            ),
        )
    )
    graph = build_document_graph(registry, project_root=tmp_path)

    first = select_context_by_ids(graph, registry, ["BR-TEST-001"])
    second = select_context_by_ids(graph, registry, ["BR-TEST-001"])

    assert first == second
    assert [document.document_id for document in first.documents] == [
        "BR-TEST-001",
        "ADR-TEST-001",
        "ACC-TEST-001",
        "ACC-TEST-002",
    ]


def document(
    path: Path,
    *,
    document_id: str,
    document_type: str,
    related: dict[str, list[str]] | None = None,
    scope: dict[str, list[str]] | None = None,
    status: str = "draft",
    priority: str = "medium",
    context_role: str = "reference",
) -> RegistryDocument:
    return RegistryDocument(
        path=path.resolve(),
        frontmatter={
            "id": document_id,
            "type": document_type,
            "status": status,
            "title": f"{document_id} title",
            "summary": f"{document_id} summary",
            "scope": scope
            or {
                "domains": [],
                "modules": [],
                "features": [],
            },
            "related": related or {},
            "ai": {
                "priority": priority,
                "context_role": context_role,
            },
        },
    )
