import json
import subprocess
from pathlib import Path

from ai_docs_toolkit.cli import main


def test_context_json_manifest_for_explicit_id(monkeypatch, capsys, tmp_path):
    _write_context_project(tmp_path)
    _write_document(
        tmp_path / "ai-docs" / "business-rule.md",
        document_id="BR-TEST-001",
        document_type="business_rule",
        related={"acceptance": ["ACC-TEST-001"]},
        context_role="constraint",
    )
    _write_document(
        tmp_path / "ai-docs" / "acceptance.md",
        document_id="ACC-TEST-001",
        document_type="acceptance",
        context_role="validation",
    )
    monkeypatch.chdir(tmp_path)

    assert main(["context", "--id", "BR-TEST-001", "--format", "json"]) == 0

    output = capsys.readouterr()
    assert json.loads(output.out) == {
        "documents": [
            {
                "context_role": "constraint",
                "distance": 0,
                "document_id": "BR-TEST-001",
                "group": "source",
                "path": "ai-docs/business-rule.md",
                "priority": "medium",
                "reasons": [
                    {
                        "direction": "self",
                        "message": "BR-TEST-001 is a context source.",
                        "relationship": "source",
                        "source": "BR-TEST-001",
                        "via": None,
                    }
                ],
                "summary": "BR-TEST-001 summary",
                "title": "BR-TEST-001 title",
                "type": "business_rule",
            },
            {
                "context_role": "validation",
                "distance": 1,
                "document_id": "ACC-TEST-001",
                "group": "validation",
                "path": "ai-docs/acceptance.md",
                "priority": "medium",
                "reasons": [
                    {
                        "direction": "outgoing",
                        "message": (
                            "BR-TEST-001 references ACC-TEST-001 "
                            "through related.acceptance."
                        ),
                        "relationship": "acceptance",
                        "source": "BR-TEST-001",
                        "via": None,
                    }
                ],
                "summary": "ACC-TEST-001 summary",
                "title": "ACC-TEST-001 title",
                "type": "acceptance",
            },
        ],
        "sources": [
            {
                "changed_file": None,
                "document_id": "BR-TEST-001",
                "path": "ai-docs/business-rule.md",
                "source": "id",
                "type": "business_rule",
            }
        ],
        "warnings": [],
    }
    assert output.err == ""


def test_context_json_manifest_is_deterministic(monkeypatch, capsys, tmp_path):
    _write_context_project(tmp_path)
    _write_document(
        tmp_path / "ai-docs" / "module.md",
        document_id="MOD-TEST-001",
        document_type="module",
        scope={
            "domains": [],
            "modules": ["checkout"],
            "features": ["submit-order"],
        },
        context_role="behavior",
    )
    monkeypatch.chdir(tmp_path)

    assert main(["context", "--module", "checkout", "--format", "json"]) == 0
    first = capsys.readouterr().out

    assert main(["context", "--format", "json", "--feature", "submit-order"]) == 0
    second = capsys.readouterr().out

    first_payload = json.loads(first)
    second_payload = json.loads(second)
    assert first_payload["documents"] == second_payload["documents"]
    assert first_payload["sources"][0]["source"] == "module"
    assert second_payload["sources"][0]["source"] == "feature"


def test_context_json_manifest_includes_validation_errors(monkeypatch, capsys, tmp_path):
    _write_context_project(tmp_path)
    monkeypatch.chdir(tmp_path)

    assert main(["context", "--id", "UNKNOWN-001", "--format", "json"]) == 1

    output = capsys.readouterr()
    assert json.loads(output.out) == {
        "documents": [],
        "errors": [
            {
                "document_id": "UNKNOWN-001",
                "message": "Context source references unknown document id `UNKNOWN-001`.",
                "path": None,
                "rule_id": "document.context.unknown_id",
                "severity": "error",
            },
            {
                "document_id": None,
                "message": "Context selection did not find source documents.",
                "path": None,
                "rule_id": "document.context.no_sources",
                "severity": "error",
            },
        ],
        "sources": [],
        "warnings": [],
    }
    assert output.err == ""


def test_context_json_manifest_for_changed_source(monkeypatch, capsys, tmp_path):
    _write_context_project(tmp_path)
    _write_document(
        tmp_path / "ai-docs" / "business-rule.md",
        document_id="BR-TEST-001",
        document_type="business_rule",
        related={"acceptance": ["ACC-TEST-001"]},
        context_role="constraint",
    )
    _write_document(
        tmp_path / "ai-docs" / "acceptance.md",
        document_id="ACC-TEST-001",
        document_type="acceptance",
        context_role="validation",
    )
    _commit_all(tmp_path)
    (tmp_path / "ai-docs" / "business-rule.md").write_text(
        (tmp_path / "ai-docs" / "business-rule.md").read_text(encoding="utf-8")
        + "\nChanged.\n",
        encoding="utf-8",
    )
    monkeypatch.chdir(tmp_path)

    assert main(["context", "--format", "json", "--changed"]) == 0

    output = capsys.readouterr()
    payload = json.loads(output.out)
    assert payload["sources"] == [
        {
            "changed_file": "ai-docs/business-rule.md",
            "document_id": "BR-TEST-001",
            "path": "ai-docs/business-rule.md",
            "source": "changed",
            "type": "business_rule",
        }
    ]
    assert [document["document_id"] for document in payload["documents"]] == [
        "BR-TEST-001",
        "ACC-TEST-001",
    ]
    assert payload["warnings"] == []
    assert output.err == ""


def test_context_json_changed_warns_for_non_document_files(monkeypatch, capsys, tmp_path):
    _write_context_project(tmp_path)
    _commit_all(tmp_path)
    (tmp_path / "README.md").write_text("# Readme\n", encoding="utf-8")
    (tmp_path / "ai-docs" / "note.txt").write_text("note\n", encoding="utf-8")
    monkeypatch.chdir(tmp_path)

    assert main(["context", "--changed", "--format", "json"]) == 1

    output = capsys.readouterr()
    payload = json.loads(output.out)
    assert payload["sources"] == []
    assert payload["documents"] == []
    assert payload["warnings"] == [
        {
            "document_id": None,
            "message": (
                "Changed file `README.md` is outside configured documentation roots."
            ),
            "path": "README.md",
            "rule_id": "document.context.changed_file_outside_docs",
            "severity": "warning",
        },
        {
            "document_id": None,
            "message": "Changed file `ai-docs/note.txt` is not a parsed document.",
            "path": "ai-docs/note.txt",
            "rule_id": "document.context.changed_file_not_document",
            "severity": "warning",
        },
    ]
    assert payload["errors"] == [
        {
            "document_id": None,
            "message": "Context selection did not find source documents.",
            "path": None,
            "rule_id": "document.context.no_sources",
            "severity": "error",
        }
    ]
    assert output.err == ""


def _write_context_project(project_root: Path) -> None:
    (project_root / "ai-docs").mkdir()
    (project_root / "ai-docs.config.yaml").write_text(
        """version: 1

project:
  name: context-test
  documentation_roots:
    - ai-docs
""",
        encoding="utf-8",
    )
    _run_git(project_root, "init")


def _write_document(
    path: Path,
    *,
    document_id: str,
    document_type: str,
    related: dict[str, list[str]] | None = None,
    scope: dict[str, list[str]] | None = None,
    priority: str = "medium",
    context_role: str = "reference",
) -> None:
    relationships = {
        "business_rules": [],
        "architecture_decisions": [],
        "contracts": [],
        "modules": [],
        "scenarios": [],
        "acceptance": [],
        "operations": [],
    }
    relationships.update(related or {})
    related_yaml = "\n".join(
        f"  {key}: [{', '.join(values)}]" if values else f"  {key}: []"
        for key, values in relationships.items()
    )
    scope_value = scope or {"domains": [], "modules": [], "features": []}
    scope_yaml = "\n".join(
        f"  {key}: [{', '.join(values)}]" if values else f"  {key}: []"
        for key, values in scope_value.items()
    )
    path.write_text(
        f"""---
id: {document_id}
type: {document_type}
status: draft
title: {document_id} title
summary: {document_id} summary
scope:
{scope_yaml}
owners:
  - maintainers
related:
{related_yaml}
ai:
  priority: {priority}
  load_when: []
  avoid_when: []
  context_role: {context_role}
validation:
  required_checks: []
  last_validated: null
---

# {document_id}
""",
        encoding="utf-8",
    )


def _commit_all(project_root: Path) -> None:
    _run_git(project_root, "add", ".")
    _run_git(
        project_root,
        "-c",
        "user.name=Test User",
        "-c",
        "user.email=test@example.com",
        "commit",
        "-m",
        "Initial commit",
    )


def _run_git(project_root: Path, *args: str) -> None:
    subprocess.run(
        ["git", *args],
        cwd=project_root,
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
