from importlib import resources
from pathlib import Path


BOOTSTRAP_TEMPLATE_NAMES = (
    "AGENTS.md",
    "ai-docs.config.yaml",
    "ai-docs-index.md",
    ".ai-docs/skills/index.md",
    ".ai-docs/schemas/frontmatter.schema.yaml",
    ".ai-docs/schemas/document-types/acceptance.schema.yaml",
    ".ai-docs/schemas/document-types/architecture-decision.schema.yaml",
    ".ai-docs/schemas/document-types/business-rule.schema.yaml",
    ".ai-docs/schemas/document-types/contract.schema.yaml",
    ".ai-docs/schemas/document-types/index.schema.yaml",
    ".ai-docs/schemas/document-types/module.schema.yaml",
    ".ai-docs/schemas/document-types/plan.schema.yaml",
    ".ai-docs/schemas/document-types/plan-stage.schema.yaml",
    ".ai-docs/schemas/document-types/implementation-task.schema.yaml",
    ".ai-docs/schemas/document-types/standalone-task.schema.yaml",
    ".ai-docs/schemas/document-types/operation.schema.yaml",
    ".ai-docs/schemas/document-types/scenario.schema.yaml",
    ".ai-docs/schemas/document-types/test-case.schema.yaml",
    ".ai-docs/skills/planning-task-execution/SKILL.md",
    ".ai-docs/skills/planning-record-generation/SKILL.md",
    ".ai-docs/skills/toolkit-consumer-policy/SKILL.md",
    ".ai-docs/skills/release-publication/SKILL.md",
    ".ai-docs/templates/release/release-task.md",
    ".ai-docs/templates/release/validation-evidence.md",
    ".ai-docs/templates/release/version-change-checklist.md",
    ".ai-docs/templates/release/post-publication-checks.md",
    ".ai-docs/templates/release/migration-note.md",
    ".ai-docs/examples/skills/release-publication/SKILL.md",
    ".ai-docs/examples/skills/pypi-package-release/SKILL.md",
    ".ai-docs/examples/templates/pypi-package-release/release-task.md",
    ".ai-docs/examples/templates/pypi-package-release/tag-version-guard.py",
    ".ai-docs/workflows/plan-stage-workflow.md",
    ".ai-docs/workflows/toolkit-migration-workflow.md",
    ".ai-docs/reference/planning-document-model.md",
)

PACKAGE_DOC_NAMES = (
    "agent-installation.md",
)


def test_packaged_bootstrap_templates_are_available():
    template_root = resources.files("ai_docs_toolkit").joinpath("templates/project")

    available_names = {
        path.relative_to(template_root).as_posix()
        for path in template_root.rglob("*")
        if path.is_file()
    }

    assert available_names.issuperset(BOOTSTRAP_TEMPLATE_NAMES)


def test_packaged_agent_instructions_are_available():
    docs_root = resources.files("ai_docs_toolkit").joinpath("docs")

    available_names = {path.name for path in docs_root.iterdir() if path.is_file()}

    assert available_names.issuperset(PACKAGE_DOC_NAMES)


def test_packaged_bootstrap_templates_match_root_templates():
    repository_root = Path.cwd()
    source_template_root = repository_root / ".ai-docs" / "templates" / "project"
    package_template_root = (
        repository_root / "src" / "ai_docs_toolkit" / "templates" / "project"
    )

    for template_name in BOOTSTRAP_TEMPLATE_NAMES:
        source_template = source_template_root / template_name
        package_template = package_template_root / template_name

        assert package_template.read_bytes() == source_template.read_bytes()
