import json

from ai_docs_toolkit.cli import main
from ai_docs_toolkit.core import scaffold_planning_record


def test_cli_help(capsys):
    assert main(["--help"]) == 0

    output = capsys.readouterr()
    assert "ai-docs 0.1.0b8" in output.out
    assert "ai-docs doctor" in output.out
    assert "ai-docs validate" in output.out
    assert "ai-docs validate --json" in output.out
    assert "ai-docs file" in output.out
    assert "ai-docs mcp status" in output.out
    assert "ai-docs plan start-task" in output.out
    assert output.err == ""


def test_cli_version(capsys):
    assert main(["--version"]) == 0

    output = capsys.readouterr()
    assert output.out.strip() == "0.1.0b8"
    assert output.err == ""


def test_cli_usage_error(capsys):
    assert main(["unknown"]) == 3

    output = capsys.readouterr()
    assert "Unknown command or option: unknown" in output.err


def test_doctor_passes_for_fresh_agent_project(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    assert main(["init"]) == 0
    capsys.readouterr()

    assert main(["doctor"]) == 0

    output = capsys.readouterr()
    assert "ai-docs doctor" in output.out
    assert "Status: ok" in output.out
    assert output.err == ""


def test_doctor_reports_legacy_planning_root(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    assert main(["init"]) == 0
    capsys.readouterr()
    (tmp_path / "docs" / "planning").mkdir(parents=True)

    assert main(["doctor"]) == 1

    output = capsys.readouterr()
    assert "doctor.legacy_planning_root" in output.out
    assert "docs/planning" in output.out
    assert "ai-docs planning migrate-layout --dry-run" in output.out
    assert output.err == ""


def test_doctor_recommends_init_check_for_stale_managed_files(
    tmp_path,
    monkeypatch,
    capsys,
):
    monkeypatch.chdir(tmp_path)
    assert main(["init"]) == 0
    capsys.readouterr()
    (
        tmp_path / ".ai-docs" / "workflows" / "plan-stage-workflow.md"
    ).write_text("custom", encoding="utf-8")

    assert main(["doctor"]) == 1

    output = capsys.readouterr()
    assert "doctor.managed_file.stale" in output.out
    assert "ai-docs init --check" in output.out
    assert output.err == ""


def test_file_task_lookup_accepts_short_task_number(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    _write_task_lookup_project(tmp_path)

    assert main(["file", "--task", "133"]) == 0

    output = capsys.readouterr()
    assert (
        output.out.strip()
        == "ai-docs/planning/tasks/2026-05/task-011-use-task-id-reference-index-for-migrations.md"
    )
    assert output.err == ""


def test_file_task_lookup_accepts_padded_and_full_task_id(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    _write_task_lookup_project(tmp_path)

    assert main(["file", "--task", "000133"]) == 0
    padded_output = capsys.readouterr()
    assert main(["file", "--task", "TASK-000133"]) == 0
    full_output = capsys.readouterr()

    assert padded_output.out == full_output.out
    assert output_path(full_output) == (
        "ai-docs/planning/tasks/2026-05/task-011-use-task-id-reference-index-for-migrations.md"
    )


def test_file_task_lookup_json_includes_canonical_task_id(
    tmp_path,
    monkeypatch,
    capsys,
):
    monkeypatch.chdir(tmp_path)
    _write_task_lookup_project(tmp_path)

    assert main(["file", "--task", "133", "--format", "json"]) == 0

    payload = json.loads(capsys.readouterr().out)
    assert payload["ok"] is True
    assert payload["document_id"] == "TASK-000133"
    assert payload["source"] == "task_index"
    assert payload["path"] == (
        "ai-docs/planning/tasks/2026-05/task-011-use-task-id-reference-index-for-migrations.md"
    )


def test_file_task_lookup_falls_back_to_frontmatter_scan(
    tmp_path,
    monkeypatch,
    capsys,
):
    monkeypatch.chdir(tmp_path)
    _write_task_lookup_project(tmp_path, include_index=False)

    assert main(["file", "--task", "133", "--json"]) == 0

    payload = json.loads(capsys.readouterr().out)
    assert payload["document_id"] == "TASK-000133"
    assert payload["source"] == "frontmatter_scan"


def test_file_task_lookup_reports_index_mismatch(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    _write_task_lookup_project(
        tmp_path,
        indexed_path="ai-docs/planning/tasks/2026-05/task-001-wrong.md",
    )

    assert main(["file", "--task", "133"]) == 1

    output = capsys.readouterr()
    assert "file_lookup.task_index.path_mismatch" in output.out
    assert "task-001-wrong.md" in output.out
    assert output.err == ""


def test_file_id_lookup_resolves_any_document_id(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    _write_task_lookup_project(tmp_path)

    assert main(["file", "--id", "PLAN-000003"]) == 0

    output = capsys.readouterr()
    assert output_path(output) == "ai-docs/planning/2026-05-20-example-plan/plan.md"


def test_file_id_lookup_resolves_alias(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    _write_task_lookup_project(tmp_path)

    assert main(["file", "--id", "PLAN-LEGACY-001"]) == 0

    output = capsys.readouterr()
    assert output_path(output) == "ai-docs/planning/2026-05-20-example-plan/plan.md"


def test_file_request_lookup_accepts_short_request_number(
    tmp_path,
    monkeypatch,
    capsys,
):
    monkeypatch.chdir(tmp_path)
    _write_task_lookup_project(tmp_path)

    assert main(["file", "--request", "5"]) == 0

    output = capsys.readouterr()
    assert output_path(output) == "ai-docs/requests/req-000005-example.md"


def test_file_plan_lookup_accepts_short_plan_number(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    _write_task_lookup_project(tmp_path)

    assert main(["file", "--plan", "3"]) == 0

    output = capsys.readouterr()
    assert output_path(output) == "ai-docs/planning/2026-05-20-example-plan/plan.md"


def test_file_stage_lookup_uses_stage_order_inside_plan(
    tmp_path,
    monkeypatch,
    capsys,
):
    monkeypatch.chdir(tmp_path)
    _write_task_lookup_project(tmp_path)

    assert main(["file", "--plan", "3", "--stage", "2"]) == 0

    output = capsys.readouterr()
    assert output_path(output) == (
        "ai-docs/planning/2026-05-20-example-plan/stage-2-build/stage.md"
    )


def test_file_stage_lookup_requires_plan(capsys):
    assert main(["file", "--stage", "2"]) == 3

    output = capsys.readouterr()
    assert "Usage: ai-docs file" in output.err


def test_file_usage_error(capsys):
    assert main(["file", "--task"]) == 3

    output = capsys.readouterr()
    assert "Usage: ai-docs file" in output.err


def test_mcp_status_reports_missing_runtime_or_success(capsys, tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    (tmp_path / "ai-docs.config.yaml").write_text(
        """version: 1
project:
  name: example
  documentation_roots:
    - ai-docs
""",
        encoding="utf-8",
    )

    exit_code = main(["mcp", "status"])

    output = capsys.readouterr()
    assert exit_code in {0, 1}
    assert "ai-docs mcp status" in output.out
    assert f"project_root: {tmp_path}" in output.out
    assert "mcp_runtime_available:" in output.out
    assert output.err == ""


def test_mcp_configure_prints_jetbrains_json(capsys, tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)

    assert main(["mcp", "configure", "--client", "jetbrains", "--print-json"]) == 0

    output = capsys.readouterr()
    assert '"mcpServers"' in output.out
    assert '"ai-docs-toolkit"' in output.out
    assert '"--project-root"' in output.out
    assert str(tmp_path) in output.out
    assert output.err == ""


def test_mcp_usage_error(capsys):
    assert main(["mcp", "configure"]) == 3

    output = capsys.readouterr()
    assert "Usage: ai-docs mcp status" in output.err


def test_planning_scaffold_creates_accepted_layout(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)

    assert (
        main(
            [
                "planning",
                "scaffold",
                "--plan",
                "sample-plan",
                "--stage",
                "research",
                "--task",
                "first-task",
                "--task-id",
                "TASK-000120",
                "--date",
                "2026-05-19",
            ]
        )
        == 0
    )

    output = capsys.readouterr()
    assert "ai-docs/planning/2026-05-19-sample-plan/plan.md" in output.out
    assert "ai-docs/planning/2026-05-19-sample-plan/stage-1-research/stage.md" in output.out
    assert (
        "ai-docs/planning/2026-05-19-sample-plan/stage-1-research/task-1-first-task.md"
        in output.out
    )
    assert (tmp_path / "ai-docs/planning/2026-05-19-sample-plan/plan.md").is_file()
    assert (
        tmp_path / "ai-docs/planning/2026-05-19-sample-plan/stage-1-research/stage.md"
    ).is_file()
    assert (
        tmp_path / "ai-docs/planning/2026-05-19-sample-plan/stage-1-research/task-1-first-task.md"
    ).is_file()
    assert "phase-" not in output.out
    assert "PLAN.md" not in output.out
    assert "STAGE.md" not in output.out


def test_planning_scaffold_rejects_invalid_task_id(capsys):
    assert (
        main(
            [
                "planning",
                "scaffold",
                "--plan",
                "sample-plan",
                "--stage",
                "research",
                "--task",
                "first-task",
                "--task-id",
                "TASK-1",
            ]
        )
        == 3
    )

    output = capsys.readouterr()
    assert "`--task-id` must match `TASK-NNNNNN`." in output.out


def test_planning_scaffold_uses_relative_relationship_paths(tmp_path):
    result = scaffold_planning_record(
        tmp_path,
        plan_slug="sample-plan",
        stage_slug="research",
        task_slug="first-task",
        task_id="TASK-000120",
    )

    assert result.exit_code == 0
    plan_text = (tmp_path / result.created[0]).read_text(encoding="utf-8")
    task_text = (tmp_path / result.created[2]).read_text(encoding="utf-8")
    assert str(tmp_path) not in plan_text
    assert str(tmp_path) not in task_text
    assert "ai-docs/planning/" in plan_text
    assert "ai-docs/planning/" in task_text


def test_planning_migration_dry_run_reports_phase_moves(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    (tmp_path / "ai-docs/planning/2026-05-19-sample/phase-1-research").mkdir(
        parents=True
    )

    assert main(["planning", "migrate-layout", "--dry-run"]) == 0

    output = capsys.readouterr()
    assert (
        "ai-docs/planning/2026-05-19-sample/phase-1-research -> "
        "ai-docs/planning/2026-05-19-sample/stage-1-research"
    ) in output.out
    assert "reference_updates_required: true" in output.out


def test_plan_start_task_dry_run_does_not_write(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    task_path = _write_lifecycle_project(tmp_path)
    before = task_path.read_text(encoding="utf-8")

    assert main(["plan", "start-task", "--task", "TASK-000200", "--dry-run"]) == 0

    output = capsys.readouterr()
    assert "dry_run: true" in output.out
    assert "planned -> in_progress" in output.out
    assert task_path.read_text(encoding="utf-8") == before


def test_plan_start_task_prepares_first_task_stage(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    task_path = _write_lifecycle_project(tmp_path)
    stage_path = task_path.parent / "stage.md"

    assert main(["plan", "start-task", "--task", "TASK-000200"]) == 0

    capsys.readouterr()
    task_text = task_path.read_text(encoding="utf-8")
    stage_text = stage_path.read_text(encoding="utf-8")
    assert "status: in_progress" in task_text
    assert "## Intake Checklist" in task_text
    assert "status: ready" in stage_text
    assert "Status: ready" in stage_text


def test_plan_close_task_can_close_last_task_stage(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    task_path = _write_lifecycle_project(tmp_path, task_status="in_progress", stage_status="ready")
    stage_path = task_path.parent / "stage.md"

    assert main(["plan", "close-task", "--task", "TASK-000200"]) == 0

    output = capsys.readouterr()
    assert "close parent stage" in output.out
    assert "status: done" in task_path.read_text(encoding="utf-8")
    stage_text = stage_path.read_text(encoding="utf-8")
    assert "status: done" in stage_text
    assert "## Closure Review" in stage_text


def test_plan_close_task_rejects_planned_task(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    _write_lifecycle_project(tmp_path)

    assert main(["plan", "close-task", "--task", "TASK-000200", "--format", "json"]) == 1

    payload = json.loads(capsys.readouterr().out)
    assert payload["ok"] is False
    assert payload["current_status"] == "planned"
    assert payload["issues"][0]["rule_id"] == "planning.close-task.invalid"


def test_plan_review_stage_json_reports_expected_shape(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    _write_lifecycle_project(tmp_path)

    assert main(["plan", "review-stage", "--stage", "STAGE-000200", "--format", "json"]) == 0

    payload = json.loads(capsys.readouterr().out)
    assert payload["stage_id"] == "STAGE-000200"
    assert "blocking_questions" in payload
    assert "readiness_decision" in payload


def test_plan_review_stage_human_reports_recommended_option(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    _write_lifecycle_project(tmp_path)

    assert main(["plan", "review-stage", "--stage", "STAGE-000200"]) == 0

    output = capsys.readouterr()
    assert "proposals:" in output.out
    assert "recommended:" in output.out


def test_plan_add_task_allocates_task_id_and_updates_registry(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    _write_lifecycle_project(tmp_path, include_registry=True)

    assert main(["plan", "add-task", "--stage", "STAGE-000200", "--task", "second-task"]) == 0

    output = capsys.readouterr()
    task_path = (
        tmp_path
        / "ai-docs"
        / "planning"
        / "2026-05-23-example"
        / "stage-1-build"
        / "task-2-second-task.md"
    )
    registry_text = (tmp_path / "ai-docs" / "planning" / "task-registry.md").read_text(
        encoding="utf-8"
    )
    assert "TASK-000201" in output.out
    assert task_path.is_file()
    assert "task_order: 2" in task_path.read_text(encoding="utf-8")
    assert "last_number: 201" in registry_text
    assert "task-2-second-task.md" in registry_text


def test_plan_add_task_dry_run_does_not_allocate(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    _write_lifecycle_project(tmp_path, include_registry=True)
    registry_path = tmp_path / "ai-docs" / "planning" / "task-registry.md"
    before = registry_path.read_text(encoding="utf-8")

    assert (
        main(
            [
                "plan",
                "add-task",
                "--stage",
                "STAGE-000200",
                "--task",
                "second-task",
                "--dry-run",
            ]
        )
        == 0
    )

    assert "dry_run: true" in capsys.readouterr().out
    assert registry_path.read_text(encoding="utf-8") == before
    assert not (
        tmp_path
        / "ai-docs"
        / "planning"
        / "2026-05-23-example"
        / "stage-1-build"
        / "task-2-second-task.md"
    ).exists()


def test_plan_add_stage_creates_accepted_layout(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    _write_lifecycle_project(tmp_path)

    assert (
        main(
            [
                "plan",
                "add-stage",
                "--plan",
                "PLAN-000200",
                "--stage",
                "validation",
                "--dry-run",
            ]
        )
        == 0
    )

    output = capsys.readouterr()
    assert "stage-2-validation/stage.md" in output.out
    assert not (
        tmp_path
        / "ai-docs"
        / "planning"
        / "2026-05-23-example"
        / "stage-2-validation"
        / "stage.md"
    ).exists()


def test_validate_fix_planning_dry_run_reports_skeleton_fixes(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    task_path = _write_lifecycle_project(tmp_path, task_status="done")
    before = task_path.read_text(encoding="utf-8")

    assert main(["validate", "--fix-planning", "--dry-run", "--format", "json"]) == 0

    payload = json.loads(capsys.readouterr().out)
    assert payload["ok"] is True
    assert payload["dry_run"] is True
    assert payload["changes"]
    assert task_path.read_text(encoding="utf-8") == before


def _write_task_lookup_project(
    project_root,
    *,
    include_index: bool = True,
    indexed_path: str = "ai-docs/planning/tasks/2026-05/task-011-use-task-id-reference-index-for-migrations.md",
) -> None:
    (project_root / "ai-docs" / "planning" / "tasks" / "2026-05").mkdir(
        parents=True
    )
    (project_root / "ai-docs" / "requests").mkdir(parents=True)
    (
        project_root
        / "ai-docs"
        / "planning"
        / "2026-05-20-example-plan"
        / "stage-1-research"
    ).mkdir(parents=True)
    (
        project_root
        / "ai-docs"
        / "planning"
        / "2026-05-20-example-plan"
        / "stage-2-build"
    ).mkdir(parents=True)
    (project_root / "ai-docs.config.yaml").write_text(
        """version: 1
project:
  name: file-lookup-test
  documentation_roots:
    - ai-docs
""",
        encoding="utf-8",
    )
    index = (
        f"task_index:\n  - id: TASK-000133\n    path: {indexed_path}\n"
        if include_index
        else ""
    )
    (project_root / "ai-docs" / "planning" / "task-registry.md").write_text(
        f"""---
id: REF-TASK-REGISTRY-001
type: reference
status: draft
sequence:
  prefix: TASK
  width: 6
  last_number: 133
{index}---

# Task Registry
""",
        encoding="utf-8",
    )
    (
        project_root
        / "ai-docs"
        / "planning"
        / "tasks"
        / "2026-05"
        / "task-011-use-task-id-reference-index-for-migrations.md"
    ).write_text(
        """---
id: TASK-000133
type: standalone_task
status: planned
scope:
  placement: standalone
  task: use-task-id-reference-index-for-migrations
---

# Task
""",
        encoding="utf-8",
    )
    (project_root / "ai-docs" / "requests" / "req-000005-example.md").write_text(
        """---
id: REQ-000005
type: request
status: submitted
scope:
  modules:
    - example
---

# Request
""",
        encoding="utf-8",
    )
    (
        project_root
        / "ai-docs"
        / "planning"
        / "2026-05-20-example-plan"
        / "plan.md"
    ).write_text(
        """---
id: PLAN-000003
aliases:
  - PLAN-LEGACY-001
type: plan
status: planned
scope:
  plan: example-plan
---

# Plan
""",
        encoding="utf-8",
    )
    (
        project_root
        / "ai-docs"
        / "planning"
        / "2026-05-20-example-plan"
        / "stage-1-research"
        / "stage.md"
    ).write_text(
        """---
id: STAGE-000001
type: plan_stage
status: planned
scope:
  plan: example-plan
  stage: research
---

# Stage 1
""",
        encoding="utf-8",
    )
    (
        project_root
        / "ai-docs"
        / "planning"
        / "2026-05-20-example-plan"
        / "stage-2-build"
        / "stage.md"
    ).write_text(
        """---
id: STAGE-000002
type: plan_stage
status: planned
scope:
  plan: example-plan
  stage: build
---

# Stage 2
""",
        encoding="utf-8",
    )


def _write_lifecycle_project(
    project_root,
    *,
    task_status: str = "planned",
    stage_status: str = "planned",
    include_registry: bool = False,
):
    stage_dir = project_root / "ai-docs" / "planning" / "2026-05-23-example" / "stage-1-build"
    stage_dir.mkdir(parents=True)
    (stage_dir.parent / "plan.md").write_text(
        """---
id: PLAN-000200
type: plan
status: planned
scope:
  plan: example
related:
  stages:
    - STAGE-000200
  tasks:
    - TASK-000200
---

# Plan
""",
        encoding="utf-8",
    )
    (stage_dir / "stage.md").write_text(
        f"""---
id: STAGE-000200
type: plan_stage
status: {stage_status}
scope:
  plan: example
  stage: build
related:
  plans:
    - PLAN-000200
  tasks:
    - TASK-000200
---

# Stage

## Outcome

Pending.

## Scope

- Implementation work.

## Task Decomposition

Status: planned

## Tasks

## Task 1: Build

Status: {task_status}

Task document:
- ai-docs/planning/2026-05-23-example/stage-1-build/task-1-build.md

## Validation

Planned validation:
- `.venv/bin/ai-docs validate`

## Result

Planned.
""",
        encoding="utf-8",
    )
    task_path = stage_dir / "task-1-build.md"
    task_path.write_text(
        f"""---
id: TASK-000200
type: implementation_task
status: {task_status}
scope:
  placement: plan_stage
  plan: example
  stage: build
  task_order: 1
related:
  plans:
    - PLAN-000200
  stages:
    - STAGE-000200
---

# Task

## Purpose

Build behavior.

## Expected Changes

- Pending.

## Acceptance Criteria

- Pending.

## Test Plan

- Run tests.

## Validation

- Pending.

## Result

Planned.
""",
        encoding="utf-8",
    )
    if include_registry:
        (project_root / "ai-docs" / "planning" / "task-registry.md").write_text(
            """---
id: REF-TASK-REGISTRY-001
type: reference
status: draft
sequence:
  prefix: TASK
  width: 6
  last_number: 200
task_index:
  - id: TASK-000200
    path: ai-docs/planning/2026-05-23-example/stage-1-build/task-1-build.md
---

# Task Registry

| Task ID | Current path |
| --- | --- |
| TASK-000200 | ai-docs/planning/2026-05-23-example/stage-1-build/task-1-build.md |

## Lookup Contract
""",
            encoding="utf-8",
        )
    return task_path


def output_path(output) -> str:
    return output.out.strip()
