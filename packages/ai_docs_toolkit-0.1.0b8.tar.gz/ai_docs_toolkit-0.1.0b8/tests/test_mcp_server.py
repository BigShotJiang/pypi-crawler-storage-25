import asyncio
import importlib.util
import json
import shutil
import subprocess
from pathlib import Path

import pytest

from ai_docs_toolkit.mcp.server import (
    _load_fastmcp,
    build_server,
    context_project_tool,
    graph_project_tool,
    impact_project_tool,
    parse_args,
    planning_next_task_resource,
    planning_plans_resource,
    planning_record_resource,
    server_info,
    validate_project_tool,
)


class FakeFastMCP:
    def __init__(self, name: str):
        self.name = name
        self.tools = {}
        self.resources = {}
        self.ran = False

    def tool(self, *, name: str):
        def decorator(func):
            self.tools[name] = func
            return func

        return decorator

    def resource(self, uri: str):
        def decorator(func):
            self.resources[uri] = func
            return func

        return decorator

    def run(self):
        self.ran = True


def test_parse_args_uses_defaults():
    args = parse_args([])

    assert args.project_root == Path(".")
    assert args.config_file == "ai-docs.config.yaml"


def test_parse_args_accepts_project_root_and_config():
    args = parse_args(["--project-root", "examples/minimal-project", "--config", "custom.yaml"])

    assert args.project_root == Path("examples/minimal-project")
    assert args.config_file == "custom.yaml"


def test_server_info_returns_structured_config_for_project():
    result = server_info("examples/minimal-project")

    assert result["ok"] is True
    assert result["server"] == "AI Docs Toolkit"
    assert result["project_root"].endswith("examples/minimal-project")
    assert result["documentation_roots"]
    assert result["schema_roots"]


def test_server_info_returns_structured_config_errors(tmp_path: Path):
    (tmp_path / "ai-docs.config.yaml").write_text(
        """version: 1
project:
  documentation_roots:
    - missing
""",
        encoding="utf-8",
    )

    result = server_info(tmp_path)

    assert result["ok"] is False
    assert result["errors"][0]["code"] == "missing_documentation_root"


def test_build_server_registers_minimal_read_only_tool_and_resource():
    server = build_server(
        project_root="examples/minimal-project",
        fastmcp_factory=FakeFastMCP,
    )

    assert server.name == "AI Docs Toolkit"
    assert set(server.tools) == {
        "ai_docs_context",
        "ai_docs_graph",
        "ai_docs_impact",
        "ai_docs_server_info",
        "ai_docs_validate",
    }
    assert set(server.resources) == {
        "ai-docs://config",
        "ai-docs://graph",
        "ai-docs://next-task",
        "ai-docs://plan/{plan_id}",
        "ai-docs://plans",
        "ai-docs://stage/{stage_id}",
        "ai-docs://task/{task_id}",
        "ai-docs://validation/latest",
    }
    assert server.tools["ai_docs_server_info"]()["ok"] is True
    assert server.tools["ai_docs_validate"]()["ok"] is True
    assert server.tools["ai_docs_graph"]()["exit_code"] == 0
    assert server.tools["ai_docs_impact"](source_ids=["BR-ORDERING-001"])["exit_code"] == 0
    assert server.tools["ai_docs_context"](mode="id", value="BR-ORDERING-001")[
        "exit_code"
    ] == 0
    assert server.resources["ai-docs://config"]()["ok"] is True
    assert server.resources["ai-docs://graph"]()["exit_code"] == 0


def test_planning_resources_expose_plan_stage_task_and_next_task(tmp_path: Path):
    _write_mcp_planning_project(tmp_path)

    plans = planning_plans_resource(tmp_path)
    plan = planning_record_resource(tmp_path, "PLAN-000900")
    stage = planning_record_resource(tmp_path, "STAGE-000900")
    task = planning_record_resource(tmp_path, "TASK-000900")
    next_task = planning_next_task_resource(tmp_path)

    assert plans["plans"] == [
        {
            "id": "PLAN-000900",
            "type": "plan",
            "status": "in_progress",
            "path": "ai-docs/planning/2026-05-23-mcp/plan.md",
        }
    ]
    assert plan["ok"] is True
    assert stage["frontmatter"]["scope"]["stage"] == "build"
    assert task["path"].endswith("task-1-design.md")
    assert next_task["task"]["id"] == "TASK-000900"


def test_build_server_registers_planning_resource_templates(tmp_path: Path):
    _write_mcp_planning_project(tmp_path)
    server = build_server(project_root=tmp_path, fastmcp_factory=FakeFastMCP)

    assert server.resources["ai-docs://plans"]()["plans"][0]["id"] == "PLAN-000900"
    assert server.resources["ai-docs://plan/{plan_id}"]("PLAN-000900")["ok"] is True
    assert server.resources["ai-docs://stage/{stage_id}"]("STAGE-000900")["ok"] is True
    assert server.resources["ai-docs://task/{task_id}"]("TASK-000900")["ok"] is True
    assert server.resources["ai-docs://next-task"]()["task"]["id"] == "TASK-000900"


def test_validate_project_tool_returns_cli_json_contract_for_success_fixture():
    result = validate_project_tool("tests/fixtures/validate/success")

    assert result == {
        "exit_code": 0,
        "issues": [],
        "ok": True,
        "summary": {
            "issue_count": 0,
            "schema_skipped_documents": 0,
            "schema_skipped_types": {},
            "schema_validated_documents": 2,
            "scanned_files": 2,
            "validated_documents": 2,
        },
    }


def test_validate_project_tool_returns_structured_failure_without_transport_error():
    result = validate_project_tool("tests/fixtures/validate/failure")

    assert result["exit_code"] == 1
    assert result["ok"] is False
    assert result["summary"]["issue_count"] == 1
    assert result["issues"][0]["rule_id"] == "document.relationship.unresolved"


def test_validation_tool_accepts_project_root_argument():
    server = build_server(project_root=".", fastmcp_factory=FakeFastMCP)

    result = server.tools["ai_docs_validate"](
        project_root="tests/fixtures/validate/success"
    )

    assert result["exit_code"] == 0
    assert result["ok"] is True


def test_graph_project_tool_returns_cli_json_contract_for_minimal_project():
    result = graph_project_tool("examples/minimal-project")

    assert result["exit_code"] == 0
    assert sorted(result) == ["edges", "exit_code", "nodes", "warnings"]
    assert result["warnings"] == []
    assert len(result["nodes"]) == 8
    assert {
        "id": "BR-ORDERING-001",
        "path": "ai-docs/business-rule-order-submission.md",
        "scope": {
            "domains": ["ordering"],
            "features": ["order-submission"],
            "modules": ["checkout"],
        },
        "summary": "A submitted order must include a customer contact email.",
        "title": "Submitted Orders Require Contact Email",
        "type": "business_rule",
    } in result["nodes"]


def test_graph_tool_accepts_filters():
    server = build_server(project_root="examples/minimal-project", fastmcp_factory=FakeFastMCP)

    result = server.tools["ai_docs_graph"](document_type="business_rule")

    assert result["exit_code"] == 0
    assert [node["type"] for node in result["nodes"]] == ["business_rule"]
    assert result["edges"] == []


def test_graph_tool_returns_structured_filter_errors():
    result = graph_project_tool(
        "examples/minimal-project",
        document_id="UNKNOWN-001",
    )

    assert result["exit_code"] == 1
    assert result["nodes"] == []
    assert result["edges"] == []
    assert result["errors"][0]["rule_id"] == "document.graph.filter.unknown_id"


def test_impact_project_tool_returns_cli_json_contract_for_id_source():
    result = impact_project_tool(
        "examples/minimal-project",
        source_ids=["BR-ORDERING-001"],
    )

    assert result["exit_code"] == 0
    assert sorted(result) == ["exit_code", "impacted", "sources", "warnings"]
    assert result["warnings"] == []
    assert result["sources"] == [
        {
            "changed_file": None,
            "document_id": "BR-ORDERING-001",
            "path": "ai-docs/business-rule-order-submission.md",
            "source": "id",
            "type": "business_rule",
        }
    ]
    assert [item["document_id"] for item in result["impacted"]] == [
        "ACC-ORDER-SUBMISSION-001",
        "ADR-CHECKOUT-001",
        "CON-CHECKOUT-001",
        "MOD-CHECKOUT-001",
        "SCN-ORDER-SUBMISSION-001",
        "OPS-CHECKOUT-001",
    ]


def test_impact_project_tool_returns_structured_unknown_id_error():
    result = impact_project_tool(
        "examples/minimal-project",
        source_ids=["UNKNOWN-001"],
    )

    assert result["exit_code"] == 1
    assert result["sources"] == []
    assert result["impacted"] == []
    assert result["errors"][0]["rule_id"] == "document.impact.unknown_id"


def test_impact_tool_accepts_changed_mode(tmp_path: Path):
    project_root = _copy_minimal_project_with_git_changes(tmp_path)
    server = build_server(project_root=project_root, fastmcp_factory=FakeFastMCP)

    result = server.tools["ai_docs_impact"](changed=True)

    assert result["exit_code"] == 0
    assert result["sources"]
    assert result["sources"][0]["source"] == "changed"


def test_context_project_tool_returns_json_manifest_for_id_source():
    result = context_project_tool(
        "examples/minimal-project",
        mode="id",
        value="BR-ORDERING-001",
    )

    assert result["exit_code"] == 0
    assert sorted(result) == ["documents", "exit_code", "sources", "warnings"]
    assert result["warnings"] == []
    assert result["sources"] == [
        {
            "changed_file": None,
            "document_id": "BR-ORDERING-001",
            "path": "ai-docs/business-rule-order-submission.md",
            "source": "id",
            "type": "business_rule",
        }
    ]
    assert result["documents"][0]["document_id"] == "BR-ORDERING-001"


def test_context_project_tool_returns_structured_unknown_id_error():
    result = context_project_tool(
        "examples/minimal-project",
        mode="id",
        value="UNKNOWN-001",
    )

    assert result["exit_code"] == 1
    assert result["documents"] == []
    assert result["sources"] == []
    assert result["errors"][0]["rule_id"] == "document.context.unknown_id"


def _copy_minimal_project_with_git_changes(tmp_path: Path) -> Path:
    project_root = tmp_path / "minimal-project"
    shutil.copytree(Path.cwd() / "examples" / "minimal-project", project_root)
    subprocess.run(["git", "init"], cwd=project_root, check=True, capture_output=True)
    return project_root


def test_context_tool_accepts_module_feature_and_changed_modes(tmp_path: Path):
    project_root = _copy_minimal_project_with_git_changes(tmp_path)
    server = build_server(project_root=project_root, fastmcp_factory=FakeFastMCP)

    by_module = server.tools["ai_docs_context"](mode="module", value="checkout")
    by_feature = server.tools["ai_docs_context"](mode="feature", value="order-submission")
    by_changed = server.tools["ai_docs_context"](mode="changed")

    assert by_module["exit_code"] == 0
    assert by_feature["exit_code"] == 0
    assert by_changed["exit_code"] == 0
    assert by_changed["sources"]
    assert by_changed["sources"][0]["source"] == "changed"


def test_load_fastmcp_reports_missing_optional_dependency_when_needed(monkeypatch):
    import builtins

    real_import = builtins.__import__

    def fake_import(name, globals=None, locals=None, fromlist=(), level=0):
        if name == "mcp.server.fastmcp":
            raise ImportError("missing mcp")
        return real_import(name, globals, locals, fromlist, level)

    monkeypatch.setattr(builtins, "__import__", fake_import)

    with pytest.raises(SystemExit) as exc_info:
        _load_fastmcp()

    assert "MCP runtime extra is not installed" in str(exc_info.value)


def test_real_fastmcp_smoke_lists_current_surfaces_when_extra_is_installed():
    if importlib.util.find_spec("mcp") is None:
        pytest.skip("Optional mcp extra is not installed.")

    async def run_smoke():
        server = build_server(project_root="examples/minimal-project")
        tools = await server.list_tools()
        resources = await server.list_resources()
        return {tool.name for tool in tools}, {str(resource.uri) for resource in resources}

    tool_names, resource_uris = asyncio.run(run_smoke())

    assert {
        "ai_docs_context",
        "ai_docs_graph",
        "ai_docs_impact",
        "ai_docs_server_info",
        "ai_docs_validate",
    } <= tool_names
    assert {"ai-docs://config", "ai-docs://graph"} <= resource_uris


def test_real_fastmcp_smoke_calls_validate_and_graph_when_extra_is_installed():
    if importlib.util.find_spec("mcp") is None:
        pytest.skip("Optional mcp extra is not installed.")

    async def run_smoke():
        server = build_server(project_root="examples/minimal-project")
        validate_result = await server.call_tool("ai_docs_validate", {})
        graph_result = await server.call_tool(
            "ai_docs_graph",
            {"document_type": "business_rule"},
        )
        impact_result = await server.call_tool(
            "ai_docs_impact",
            {"source_ids": ["BR-ORDERING-001"]},
        )
        context_result = await server.call_tool(
            "ai_docs_context",
            {"mode": "id", "value": "BR-ORDERING-001"},
        )
        return validate_result, graph_result, impact_result, context_result

    validate_result, graph_result, impact_result, context_result = asyncio.run(run_smoke())

    validate_payload = validate_result[1]
    graph_payload = graph_result[1]

    assert validate_payload["ok"] is True
    assert validate_payload["exit_code"] == 0
    assert graph_payload["exit_code"] == 0
    assert [node["type"] for node in graph_payload["nodes"]] == ["business_rule"]
    assert impact_result[1]["exit_code"] == 0
    assert impact_result[1]["sources"][0]["document_id"] == "BR-ORDERING-001"
    assert context_result[1]["exit_code"] == 0
    assert context_result[1]["sources"][0]["document_id"] == "BR-ORDERING-001"


def test_real_fastmcp_smoke_reads_config_and_graph_resources_when_extra_is_installed():
    if importlib.util.find_spec("mcp") is None:
        pytest.skip("Optional mcp extra is not installed.")

    async def run_smoke():
        server = build_server(project_root="examples/minimal-project")
        config_contents = await server.read_resource("ai-docs://config")
        graph_contents = await server.read_resource("ai-docs://graph")
        return config_contents, graph_contents

    config_contents, graph_contents = asyncio.run(run_smoke())
    config_payload = json.loads(config_contents[0].content)
    graph_payload = json.loads(graph_contents[0].content)

    assert config_payload["ok"] is True
    assert graph_payload["exit_code"] == 0
    assert len(graph_payload["nodes"]) == 8


def _write_mcp_planning_project(project_root: Path) -> None:
    stage_dir = project_root / "ai-docs" / "planning" / "2026-05-23-mcp" / "stage-1-build"
    stage_dir.mkdir(parents=True)
    (stage_dir.parent / "plan.md").write_text(
        """---
id: PLAN-000900
type: plan
status: in_progress
scope:
  plan: mcp
related:
  stages:
    - STAGE-000900
  tasks:
    - TASK-000900
---

# Plan
""",
        encoding="utf-8",
    )
    (stage_dir / "stage.md").write_text(
        """---
id: STAGE-000900
type: plan_stage
status: ready
scope:
  plan: mcp
  stage: build
related:
  plans:
    - PLAN-000900
  tasks:
    - TASK-000900
---

# Stage
""",
        encoding="utf-8",
    )
    (stage_dir / "task-1-design.md").write_text(
        """---
id: TASK-000900
type: implementation_task
status: ready
scope:
  placement: plan_stage
  plan: mcp
  stage: build
  task_order: 1
related:
  plans:
    - PLAN-000900
  stages:
    - STAGE-000900
---

# Design Task
""",
        encoding="utf-8",
    )
