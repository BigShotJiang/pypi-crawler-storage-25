from pathlib import Path

from ai_docs_toolkit.cli import main


def write_config(project_root: Path):
    (project_root / "ai-docs.config.yaml").write_text(
        """version: 1
project:
  name: example
  documentation_roots:
    - ai-docs
""",
        encoding="utf-8",
    )


def write_business_rule(path: Path, *, related_id: str = "MOD-TEST-001"):
    path.write_text(
        f"""---
id: BR-TEST-001
type: business_rule
status: draft
title: Test Rule
summary: A test rule.
scope:
  domains: []
  modules: []
  features: []
owners:
  - maintainers
related:
  business_rules: []
  architecture_decisions: []
  contracts: []
  modules:
    - {related_id}
  scenarios: []
  acceptance: []
  operations: []
ai:
  priority: medium
  load_when: []
  avoid_when: []
  context_role: constraint
validation:
  required_checks: []
  last_validated: null
---

# Test Rule

## Rule

## Rationale

## Applies To

## Exceptions

## Related Scenarios

## Validation
""",
        encoding="utf-8",
    )


def write_module(path: Path):
    path.write_text(
        """---
id: MOD-TEST-001
type: module
status: draft
title: Test Module
summary: A test module.
scope:
  domains: []
  modules: []
  features: []
owners:
  - maintainers
related:
  business_rules: []
  architecture_decisions: []
  contracts: []
  modules: []
  scenarios: []
  acceptance: []
  operations: []
ai:
  priority: medium
  load_when: []
  avoid_when: []
  context_role: behavior
validation:
  required_checks: []
  last_validated: null
---

# Test Module

## Responsibility

## Non-Goals

## Public Interfaces

## Dependencies

## Invariants

## Related Documents

## Validation
""",
        encoding="utf-8",
    )


def test_validate_human_output_passes_for_valid_project(tmp_path: Path, monkeypatch, capsys):
    docs = tmp_path / "ai-docs"
    docs.mkdir()
    write_config(tmp_path)
    write_business_rule(docs / "rule.md")
    write_module(docs / "module.md")
    monkeypatch.chdir(tmp_path)

    assert main(["validate"]) == 0

    output = capsys.readouterr()
    assert "Validation passed." in output.out
    assert "Scanned files: 2" in output.out
    assert output.err == ""


def test_validate_human_output_reports_validation_failures(
    tmp_path: Path,
    monkeypatch,
    capsys,
):
    docs = tmp_path / "ai-docs"
    docs.mkdir()
    write_config(tmp_path)
    write_business_rule(docs / "rule.md", related_id="MOD-MISSING-001")
    monkeypatch.chdir(tmp_path)

    assert main(["validate"]) == 1

    output = capsys.readouterr()
    assert "Validation failed." in output.out
    assert str(docs / "rule.md") in output.out
    assert "document.relationship.unresolved" in output.out
    assert "MOD-MISSING-001" in output.out
    assert output.err == ""


def test_validate_human_output_reports_configuration_errors(
    tmp_path: Path,
    monkeypatch,
    capsys,
):
    write_config(tmp_path)
    monkeypatch.chdir(tmp_path)

    assert main(["validate"]) == 2

    output = capsys.readouterr()
    assert "Validation failed." in output.out
    assert "missing_documentation_root" in output.out
    assert "Configured documentation root does not exist" in output.out
    assert output.err == ""


def test_validate_json_short_form_is_supported(tmp_path: Path, monkeypatch, capsys):
    docs = tmp_path / "ai-docs"
    docs.mkdir()
    write_config(tmp_path)
    write_business_rule(docs / "rule.md")
    write_module(docs / "module.md")
    monkeypatch.chdir(tmp_path)

    assert main(["--json", "validate"]) == 0

    output = capsys.readouterr()
    assert '"ok": true' in output.out
    assert output.err == ""
