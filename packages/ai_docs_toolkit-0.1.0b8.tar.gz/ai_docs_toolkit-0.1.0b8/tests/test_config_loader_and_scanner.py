from pathlib import Path

from ai_docs_toolkit.core import load_project_config, scan_markdown_files


def test_load_config_from_project_documentation_roots(tmp_path: Path):
    ai_docs = tmp_path / "ai-docs"
    ai_docs.mkdir()
    (tmp_path / "ai-docs.config.yaml").write_text(
        """version: 1
project:
  name: example
  documentation_roots:
    - ai-docs
""",
        encoding="utf-8",
    )

    result = load_project_config(tmp_path)

    assert result.ok
    assert result.config is not None
    assert result.config.project_root == tmp_path.resolve()
    assert result.config.config_path == (tmp_path / "ai-docs.config.yaml").resolve()
    assert result.config.project_name == "example"
    assert result.config.documentation_roots == (ai_docs.resolve(),)
    assert result.config.schema_roots == ((tmp_path / ".ai-docs" / "schemas").resolve(),)


def test_load_config_uses_safe_defaults_without_config_file(tmp_path: Path):
    ai_docs = tmp_path / "ai-docs"
    ai_docs.mkdir()

    result = load_project_config(tmp_path)

    assert result.ok
    assert result.config is not None
    assert result.config.config_path is None
    assert result.config.documentation_roots == (ai_docs.resolve(),)
    assert result.config.schema_roots == ((tmp_path / ".ai-docs" / "schemas").resolve(),)


def test_load_config_from_schema_roots(tmp_path: Path):
    ai_docs = tmp_path / "ai-docs"
    schemas = tmp_path / "toolkit-schemas"
    ai_docs.mkdir()
    schemas.mkdir()
    (tmp_path / "ai-docs.config.yaml").write_text(
        """version: 1
project:
  documentation_roots:
    - ai-docs
schemas:
  roots:
    - toolkit-schemas
""",
        encoding="utf-8",
    )

    result = load_project_config(tmp_path)

    assert result.ok
    assert result.config is not None
    assert result.config.schema_roots == (schemas.resolve(),)


def test_missing_configured_root_returns_configuration_error(tmp_path: Path):
    (tmp_path / "ai-docs.config.yaml").write_text(
        """version: 1
project:
  documentation_roots:
    - missing-docs
""",
        encoding="utf-8",
    )

    result = load_project_config(tmp_path)

    assert not result.ok
    assert result.config is None
    assert len(result.errors) == 1
    assert result.errors[0].code == "missing_documentation_root"


def test_document_scanner_finds_markdown_files_and_ignores_unsupported_paths(
    tmp_path: Path,
):
    ai_docs = tmp_path / "ai-docs"
    nested = ai_docs / "nested"
    git_dir = ai_docs / ".git"
    node_modules = ai_docs / "node_modules"
    nested.mkdir(parents=True)
    git_dir.mkdir()
    node_modules.mkdir()

    first = ai_docs / "index.md"
    second = nested / "module.md"
    first.write_text("# Index\n", encoding="utf-8")
    second.write_text("# Module\n", encoding="utf-8")
    (ai_docs / "notes.txt").write_text("not markdown\n", encoding="utf-8")
    (git_dir / "ignored.md").write_text("# Ignored\n", encoding="utf-8")
    (node_modules / "ignored.md").write_text("# Ignored\n", encoding="utf-8")

    result = load_project_config(tmp_path)
    assert result.config is not None

    files = scan_markdown_files(result.config)

    assert files == tuple(sorted((first.resolve(), second.resolve())))


def test_scanner_can_find_docs_in_this_repository():
    result = load_project_config(Path.cwd())
    assert result.config is not None

    files = scan_markdown_files(result.config)

    relative_files = {path.relative_to(Path.cwd()).as_posix() for path in files}
    assert "ai-docs/concepts/yaml-frontmatter.md" in relative_files
    assert "ai-docs/planning/2026-05-13-mvp/phase-3-validation-cli-mvp/stage.md" in relative_files


def test_scanner_can_find_docs_in_minimal_example():
    project_root = Path.cwd() / "examples" / "minimal-project"
    result = load_project_config(project_root)
    assert result.config is not None

    files = scan_markdown_files(result.config)

    relative_files = {path.relative_to(project_root).as_posix() for path in files}
    assert "ai-docs/index.md" in relative_files
    assert "ai-docs/business-rule-order-submission.md" in relative_files
