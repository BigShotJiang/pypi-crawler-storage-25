import json
from pathlib import Path

from ai_docs_toolkit.cli import main


def test_graph_json_output_for_minimal_project(monkeypatch, capsys):
    project_root = Path.cwd() / "examples" / "minimal-project"
    monkeypatch.chdir(project_root)

    assert main(["graph", "--format", "json"]) == 0

    output = capsys.readouterr()
    payload = json.loads(output.out)
    assert sorted(payload) == ["edges", "nodes", "warnings"]
    assert payload["warnings"] == []
    assert len(payload["nodes"]) == 8
    assert {
        "id": "BR-ORDERING-001",
        "path": "ai-docs/business-rule-order-submission.md",
        "scope": {
            "domains": ["ordering"],
            "features": ["order-submission"],
            "modules": ["checkout"],
        },
        "summary": "A submitted order must include a customer contact email.",
        "title": "Submitted Orders Require Contact Email",
        "type": "business_rule",
    } in payload["nodes"]
    assert {
        "relationship": "modules",
        "source": "BR-ORDERING-001",
        "source_path": "ai-docs/business-rule-order-submission.md",
        "target": "MOD-CHECKOUT-001",
        "target_path": "ai-docs/module-checkout.md",
    } in payload["edges"]
    assert output.err == ""


def test_graph_json_output_is_deterministic(monkeypatch, capsys):
    project_root = Path.cwd() / "examples" / "minimal-project"
    monkeypatch.chdir(project_root)

    assert main(["graph", "--format", "json"]) == 0
    first = capsys.readouterr().out

    assert main(["graph", "--format", "json"]) == 0
    second = capsys.readouterr().out

    assert first == second


def test_graph_json_output_for_repository(monkeypatch, capsys):
    monkeypatch.chdir(Path.cwd())

    assert main(["graph", "--format", "json"]) == 0

    output = capsys.readouterr()
    payload = json.loads(output.out)
    assert payload["warnings"] == []
    assert len(payload["nodes"]) > 0
    assert isinstance(payload["edges"], list)


def test_graph_unsupported_format_returns_usage_error(capsys):
    assert main(["graph", "--format", "dot"]) == 3

    output = capsys.readouterr()
    assert output.out == ""
    assert "Usage: ai-docs graph --format json" in output.err


def test_graph_type_filter_returns_induced_subgraph(monkeypatch, capsys):
    project_root = Path.cwd() / "examples" / "minimal-project"
    monkeypatch.chdir(project_root)

    assert main(["graph", "--format", "json", "--type", "business_rule"]) == 0

    output = capsys.readouterr()
    payload = json.loads(output.out)
    assert [node["type"] for node in payload["nodes"]] == ["business_rule"]
    assert payload["edges"] == []


def test_graph_module_filter_returns_checkout_scope(monkeypatch, capsys):
    project_root = Path.cwd() / "examples" / "minimal-project"
    monkeypatch.chdir(project_root)

    assert main(["graph", "--format", "json", "--module", "checkout"]) == 0

    output = capsys.readouterr()
    payload = json.loads(output.out)
    assert len(payload["nodes"]) == 8
    assert len(payload["edges"]) > 0


def test_graph_id_filter_returns_one_hop_neighborhood(monkeypatch, capsys):
    project_root = Path.cwd() / "examples" / "minimal-project"
    monkeypatch.chdir(project_root)

    assert main(["graph", "--format", "json", "--id", "BR-ORDERING-001"]) == 0

    output = capsys.readouterr()
    payload = json.loads(output.out)
    node_ids = {node["id"] for node in payload["nodes"]}
    assert "BR-ORDERING-001" in node_ids
    assert "MOD-CHECKOUT-001" in node_ids
    assert "CON-CHECKOUT-001" in node_ids
    assert all(
        edge["source"] in node_ids and edge["target"] in node_ids
        for edge in payload["edges"]
    )


def test_graph_unknown_id_filter_returns_validation_error(monkeypatch, capsys):
    project_root = Path.cwd() / "examples" / "minimal-project"
    monkeypatch.chdir(project_root)

    assert main(["graph", "--format", "json", "--id", "UNKNOWN-001"]) == 1

    output = capsys.readouterr()
    payload = json.loads(output.out)
    assert payload["nodes"] == []
    assert payload["edges"] == []
    assert payload["errors"] == [
        {
            "document_id": "UNKNOWN-001",
            "message": "Graph filter references unknown document id `UNKNOWN-001`.",
            "path": None,
            "rule_id": "document.graph.filter.unknown_id",
            "severity": "error",
        }
    ]


def test_graph_filter_usage_errors(capsys):
    assert main(["graph", "--format", "json", "--type"]) == 3
    output = capsys.readouterr()
    assert output.out == ""
    assert "Usage: ai-docs graph --format json" in output.err


def test_graph_orphan_warning_is_reported(monkeypatch, capsys, tmp_path):
    _write_graph_project(tmp_path)
    _write_document(
        tmp_path / "ai-docs" / "business-rule.md",
        document_id="BR-ORPHAN-001",
        document_type="business_rule",
        title="Orphan Rule",
        summary="Rule without resolved relationships.",
    )
    monkeypatch.chdir(tmp_path)

    assert main(["graph", "--format", "json"]) == 0

    output = capsys.readouterr()
    payload = json.loads(output.out)
    assert payload["warnings"] == [
        {
            "document_id": "BR-ORPHAN-001",
            "message": "Document has no resolved graph relationships.",
            "path": "ai-docs/business-rule.md",
            "rule_id": "document.graph.orphan",
            "severity": "warning",
        }
    ]
    assert output.err == ""


def test_graph_orphan_warning_skips_index_documents(monkeypatch, capsys, tmp_path):
    _write_graph_project(tmp_path)
    _write_document(
        tmp_path / "ai-docs" / "index.md",
        document_id="IDX-DOCS-001",
        document_type="index",
        title="Docs Index",
        summary="Index without resolved relationships.",
    )
    monkeypatch.chdir(tmp_path)

    assert main(["graph", "--format", "json"]) == 0

    output = capsys.readouterr()
    payload = json.loads(output.out)
    assert payload["warnings"] == []


def test_graph_filter_does_not_create_orphan_warnings(monkeypatch, capsys):
    project_root = Path.cwd() / "examples" / "minimal-project"
    monkeypatch.chdir(project_root)

    assert main(["graph", "--format", "json", "--type", "business_rule"]) == 0

    output = capsys.readouterr()
    payload = json.loads(output.out)
    assert payload["warnings"] == []


def _write_graph_project(project_root: Path) -> None:
    (project_root / "ai-docs").mkdir()
    (project_root / "ai-docs.config.yaml").write_text(
        """version: 1

project:
  name: graph-test
  documentation_roots:
    - ai-docs
""",
        encoding="utf-8",
    )


def _write_document(
    path: Path,
    *,
    document_id: str,
    document_type: str,
    title: str,
    summary: str,
) -> None:
    path.write_text(
        f"""---
id: {document_id}
type: {document_type}
status: draft
title: {title}
summary: {summary}
scope:
  domains: []
  modules: []
  features: []
owners:
  - maintainers
related:
  business_rules: []
  architecture_decisions: []
  contracts: []
  modules: []
  scenarios: []
  acceptance: []
  operations: []
ai:
  priority: medium
  load_when: []
  avoid_when: []
  context_role: reference
validation:
  required_checks: []
  last_validated: null
---

# {title}
""",
        encoding="utf-8",
    )
