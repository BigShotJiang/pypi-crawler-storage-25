from copy import deepcopy
from datetime import date
from pathlib import Path

from ai_docs_toolkit.core import (
    RULE_SCHEMA_INVALID,
    RULE_SCHEMA_UNKNOWN_TYPE,
    SchemaValidator,
    parse_markdown_file,
)


def valid_business_rule_frontmatter():
    return {
        "id": "BR-BILLING-001",
        "type": "business_rule",
        "status": "accepted",
        "title": "Billing Rule",
        "summary": "A billing rule.",
        "scope": {
            "domains": ["billing"],
            "modules": [],
            "features": [],
        },
        "owners": ["maintainers"],
        "related": {
            "business_rules": [],
            "architecture_decisions": [],
            "contracts": [],
            "modules": [],
            "scenarios": [],
            "acceptance": [],
            "operations": [],
        },
        "ai": {
            "priority": "high",
            "load_when": [{"topic": "billing"}],
            "avoid_when": [],
            "context_role": "constraint",
        },
        "validation": {
            "required_checks": [],
            "last_validated": None,
        },
    }


def test_valid_frontmatter_passes_schema_validation():
    validator = SchemaValidator.load()

    result = validator.validate_frontmatter(
        valid_business_rule_frontmatter(),
        path="ai-docs/business-rule.md",
    )

    assert result.ok
    assert result.issues == ()


def test_aliases_pass_common_frontmatter_schema_validation():
    validator = SchemaValidator.load()
    frontmatter = valid_business_rule_frontmatter()
    frontmatter["aliases"] = ["BR-BILLING-LEGACY-001"]

    result = validator.validate_frontmatter(
        frontmatter,
        path="ai-docs/business-rule.md",
    )

    assert result.ok


def test_unknown_document_type_is_reported():
    validator = SchemaValidator.load()
    frontmatter = valid_business_rule_frontmatter()
    frontmatter["type"] = "unknown"

    result = validator.validate_frontmatter(frontmatter, path="ai-docs/unknown.md")

    assert not result.ok
    assert len(result.issues) == 1
    issue = result.issues[0]
    assert issue.rule_id == RULE_SCHEMA_UNKNOWN_TYPE
    assert issue.path == "ai-docs/unknown.md"
    assert issue.document_id == "BR-BILLING-001"
    assert issue.schema_path == "type"


def test_invalid_status_and_required_fields_produce_validation_errors():
    validator = SchemaValidator.load()
    frontmatter = valid_business_rule_frontmatter()
    frontmatter["status"] = "invalid"
    del frontmatter["owners"]

    result = validator.validate_frontmatter(frontmatter, path="ai-docs/invalid.md")

    assert not result.ok
    assert {issue.rule_id for issue in result.issues} == {RULE_SCHEMA_INVALID}
    assert {issue.document_id for issue in result.issues} == {"BR-BILLING-001"}
    assert any(issue.schema_path == "status" for issue in result.issues)
    assert any("'owners' is a required property" in issue.message for issue in result.issues)


def test_type_specific_context_role_is_validated():
    validator = SchemaValidator.load()
    frontmatter = valid_business_rule_frontmatter()
    frontmatter["ai"] = deepcopy(frontmatter["ai"])
    frontmatter["ai"]["context_role"] = "decision"

    result = validator.validate_frontmatter(frontmatter, path="ai-docs/wrong-role.md")

    assert not result.ok
    assert any(issue.schema_path == "ai.context_role" for issue in result.issues)


def test_yaml_date_values_are_normalized_for_schema_validation():
    validator = SchemaValidator.load()
    frontmatter = valid_business_rule_frontmatter()
    frontmatter["validation"] = deepcopy(frontmatter["validation"])
    frontmatter["validation"]["last_validated"] = date(2026, 5, 14)

    result = validator.validate_frontmatter(frontmatter, path="ai-docs/date.md")

    assert result.ok


def test_valid_templates_and_test_case_docs_pass_schema_validation():
    validator = SchemaValidator.load()
    paths = [
        *sorted(Path(".ai-docs/templates/documents").glob("*.md")),
        *sorted(Path("ai-docs/test-cases").glob("*.md")),
    ]

    failures = []
    for path in paths:
        parsed = parse_markdown_file(path)
        assert parsed.document is not None
        result = validator.validate_frontmatter(parsed.document.frontmatter, path=str(path))
        if not result.ok:
            failures.extend(result.issues)

    assert failures == []


def test_planning_docs_pass_type_specific_schema_validation():
    validator = SchemaValidator.load()
    parsed = parse_markdown_file(
        "ai-docs/planning/2026-05-13-mvp/phase-3-validation-cli-mvp/task-7-implement-schema-validation.md"
    )
    assert parsed.document is not None

    result = validator.validate_frontmatter(parsed.document.frontmatter, path=parsed.document.path)

    assert result.ok


def test_invalid_planning_task_scope_is_reported_by_schema_validation():
    validator = SchemaValidator.load()
    parsed = parse_markdown_file(
        "ai-docs/planning/2026-05-13-mvp/phase-3-validation-cli-mvp/task-7-implement-schema-validation.md"
    )
    assert parsed.document is not None
    frontmatter = deepcopy(parsed.document.frontmatter)
    del frontmatter["scope"]["task_order"]

    result = validator.validate_frontmatter(frontmatter, path=parsed.document.path)

    assert not result.ok
    assert any("'task_order' is a required property" in issue.message for issue in result.issues)
