from pathlib import Path

from ai_docs_toolkit.core import (
    RULE_PLANNING_ACCEPTED_NOT_ACTIVE_GATE,
    RULE_PLANNING_INCOMPLETE_INTAKE_CHECKLIST,
    RULE_PLANNING_INCOMPLETE_CLOSURE_CHECKLIST,
    RULE_PLANNING_INVALID_LAYOUT,
    RULE_PLANNING_INVALID_PLACEMENT,
    RULE_PLANNING_INVALID_READINESS_PROPOSAL,
    RULE_PLANNING_INVALID_STATUS,
    RULE_PLANNING_MISSING_DESIGN_FIRST_TASK,
    RULE_PLANNING_MISSING_PLACEMENT,
    RULE_PLANNING_MISSING_PLACEMENT_FIELD,
    RULE_PLANNING_MISSING_INTAKE_CHECKLIST,
    RULE_PLANNING_MISSING_TEST_PLAN,
    RULE_PLANNING_MISSING_VALIDATION_COMMAND,
    RULE_PLANNING_MISSING_CLOSURE_CHECKLIST,
    RULE_PLANNING_MISSING_CLOSURE_OBSERVATIONS,
    RULE_PLANNING_MISSING_READINESS_REVIEW,
    RULE_PLANNING_TASK_ID_DUPLICATE,
    RULE_PLANNING_TASK_INDEX_PATH_MISMATCH,
    RULE_PLANNING_TASK_INDEX_UNKNOWN_ID,
    RULE_PLANNING_UNRESOLVED_OBSERVATION,
    RULE_RELATIONSHIP_UNRESOLVED,
    RULE_SECTION_MISSING,
    RegistryDocument,
    build_document_registry,
    load_project_config,
    parse_markdown_file,
    registry_document_from_parsed,
    scan_markdown_files,
    validate_relationships_and_sections,
)


def registry_document(
    path: Path,
    *,
    document_id: str = "BR-TEST-001",
    document_type: str = "business_rule",
    related: dict[str, list[str]] | None = None,
    body: str | None = None,
) -> RegistryDocument:
    return RegistryDocument(
        path=path.resolve(),
        frontmatter={
            "id": document_id,
            "type": document_type,
            "related": related or {},
        },
        body=body
        if body is not None
        else """# Rule

## Rule

## Rationale

## Applies To

## Exceptions

## Related Scenarios

## Validation
""",
    )


def planning_document(
    path: Path,
    *,
    document_id: str = "TASK-TEST-001",
    document_type: str = "implementation_task",
    status: str = "planned",
    scope: dict[str, object] | None = None,
    body: str = "# Task\n",
) -> RegistryDocument:
    if scope is None:
        if document_type == "standalone_task":
            scope = {"placement": "standalone", "task": "example"}
        elif document_type == "implementation_task":
            scope = {
                "placement": "plan_stage",
                "plan": "test-plan",
                "stage": "phase-1",
                "task_order": 1,
            }
        else:
            scope = {}
    return RegistryDocument(
        path=path.resolve(),
        frontmatter={
            "id": document_id,
            "type": document_type,
            "status": status,
            "scope": scope,
            "related": {},
        },
        body=body,
    )


def test_missing_related_id_is_reported(tmp_path: Path):
    source = registry_document(
        tmp_path / "source.md",
        related={"modules": ["MOD-MISSING-001"]},
    )
    registry = build_document_registry((source,))

    result = validate_relationships_and_sections(registry)

    assert not result.ok
    assert len(result.issues) == 1
    issue = result.issues[0]
    assert issue.rule_id == RULE_RELATIONSHIP_UNRESOLVED
    assert issue.document_id == "BR-TEST-001"
    assert issue.relationship == "related.modules"
    assert issue.target_id == "MOD-MISSING-001"
    assert issue.path == source.path


def test_known_related_id_passes(tmp_path: Path):
    source = registry_document(
        tmp_path / "source.md",
        related={"modules": ["MOD-TEST-001"]},
    )
    target = registry_document(
        tmp_path / "module.md",
        document_id="MOD-TEST-001",
        document_type="module",
        body="""# Module

## Responsibility

## Non-Goals

## Public Interfaces

## Dependencies

## Invariants

## Related Documents

## Validation
""",
    )
    registry = build_document_registry((source, target))

    result = validate_relationships_and_sections(registry)

    assert result.ok


def test_known_related_alias_passes(tmp_path: Path):
    source = registry_document(
        tmp_path / "source.md",
        document_id="BR-TEST-001",
        related={"modules": ["MOD-LEGACY-001"]},
    )
    target = registry_document(
        tmp_path / "module.md",
        document_id="MOD-TEST-001",
        document_type="module",
        body="""# Module

## Responsibility

## Non-Goals

## Public Interfaces

## Dependencies

## Invariants

## Related Documents

## Validation
""",
    )
    target.frontmatter["aliases"] = ["MOD-LEGACY-001"]
    registry = build_document_registry((source, target))

    result = validate_relationships_and_sections(registry)

    assert result.ok


def test_missing_required_section_is_reported(tmp_path: Path):
    document = registry_document(
        tmp_path / "source.md",
        body="""# Rule

## Rule

## Rationale
""",
    )
    registry = build_document_registry((document,))

    result = validate_relationships_and_sections(registry)

    missing_sections = {
        issue.section
        for issue in result.issues
        if issue.rule_id == RULE_SECTION_MISSING
    }
    assert "## Applies To" in missing_sections
    assert "## Exceptions" in missing_sections
    assert "## Related Scenarios" in missing_sections
    assert "## Validation" in missing_sections


def test_planning_task_without_status_is_reported(tmp_path: Path):
    document = registry_document(
        tmp_path / "task.md",
        document_id="TASK-TEST-001",
        document_type="implementation_task",
        related={"modules": ["MOD-MISSING-001"]},
        body="# Task\n",
    )
    registry = build_document_registry((document,))

    result = validate_relationships_and_sections(registry)

    assert [issue.rule_id for issue in result.issues] == [
        RULE_PLANNING_INVALID_STATUS
    ]


def test_planning_invalid_status_is_reported(tmp_path: Path):
    document = planning_document(
        tmp_path / "task.md",
        status="accepted",
    )
    registry = build_document_registry((document,))

    result = validate_relationships_and_sections(registry)

    assert [issue.rule_id for issue in result.issues] == [
        RULE_PLANNING_INVALID_STATUS
    ]


def test_active_plan_accepted_status_is_reported(tmp_path: Path):
    document = planning_document(
        tmp_path / "plan.md",
        document_id="PLAN-TEST-001",
        document_type="plan",
        status="accepted",
    )
    registry = build_document_registry((document,))

    result = validate_relationships_and_sections(registry)

    assert [issue.rule_id for issue in result.issues] == [
        RULE_PLANNING_ACCEPTED_NOT_ACTIVE_GATE
    ]


def test_flat_generated_plan_layout_is_reported(tmp_path: Path):
    document = planning_document(
        tmp_path / "ai-docs" / "planning" / "PLAN-000001-example.md",
        document_id="PLAN-EXAMPLE-001",
        document_type="plan",
        status="planned",
        scope={"plan": "example"},
    )
    registry = build_document_registry((document,))

    result = validate_relationships_and_sections(registry)

    assert any(issue.rule_id == RULE_PLANNING_INVALID_LAYOUT for issue in result.issues)


def test_flat_plan_stage_layout_is_reported(tmp_path: Path):
    document = planning_document(
        tmp_path / "ai-docs" / "planning" / "STAGE-001-example.md",
        document_id="STAGE-EXAMPLE-001",
        document_type="plan_stage",
        status="planned",
        scope={"plan": "example", "stage": "example"},
    )
    registry = build_document_registry((document,))

    result = validate_relationships_and_sections(registry)

    assert any(issue.rule_id == RULE_PLANNING_INVALID_LAYOUT for issue in result.issues)


def test_flat_plan_stage_task_layout_is_reported(tmp_path: Path):
    document = planning_document(
        tmp_path / "ai-docs" / "planning" / "TASK-000120-example.md",
        document_id="TASK-000120",
        document_type="implementation_task",
        status="planned",
        scope={
            "placement": "plan_stage",
            "plan": "example",
            "stage": "example",
            "task_order": 1,
        },
    )
    registry = build_document_registry((document,))

    result = validate_relationships_and_sections(registry)

    assert any(issue.rule_id == RULE_PLANNING_INVALID_LAYOUT for issue in result.issues)


def test_flat_standalone_task_layout_is_allowed(tmp_path: Path):
    document = planning_document(
        tmp_path / "ai-docs" / "planning" / "tasks" / "2026-05" / "task-001-example.md",
        document_id="TASK-000120",
        document_type="standalone_task",
        status="planned",
        scope={"placement": "standalone", "task": "example"},
    )
    registry = build_document_registry((document,))

    result = validate_relationships_and_sections(registry)

    assert all(issue.rule_id != RULE_PLANNING_INVALID_LAYOUT for issue in result.issues)


def test_planning_readiness_section_is_required_for_active_records(tmp_path: Path):
    document = planning_document(
        tmp_path / "ai-docs" / "planning" / "stage.md",
        document_id="STAGE-TEST-001",
        document_type="plan_stage",
        status="in_progress",
    )
    registry = build_document_registry((document,))

    result = validate_relationships_and_sections(registry)

    assert [issue.rule_id for issue in result.issues] == [
        RULE_PLANNING_MISSING_READINESS_REVIEW
    ]


def test_standalone_task_uses_planning_lifecycle_validation(tmp_path: Path):
    document = planning_document(
        tmp_path / "task-001-example.md",
        document_id="TASK-STANDALONE-2026-001",
        document_type="standalone_task",
        status="in_progress",
    )
    registry = build_document_registry((document,))

    result = validate_relationships_and_sections(registry)

    assert [issue.rule_id for issue in result.issues] == [
        RULE_PLANNING_MISSING_READINESS_REVIEW,
        RULE_PLANNING_MISSING_INTAKE_CHECKLIST,
    ]


def test_active_implementation_task_requires_intake_checklist(tmp_path: Path):
    document = planning_document(
        tmp_path / "task.md",
        status="in_progress",
        body="""# Task

## Readiness
""",
    )
    registry = build_document_registry((document,))

    result = validate_relationships_and_sections(registry)

    assert [issue.rule_id for issue in result.issues] == [
        RULE_PLANNING_MISSING_INTAKE_CHECKLIST
    ]


def test_active_implementation_task_requires_checked_intake_items(tmp_path: Path):
    document = planning_document(
        tmp_path / "task.md",
        status="in_progress",
        body="""# Task

## Readiness

## Intake Checklist

- [x] Read `.ai-docs/workflows/plan-stage-workflow.md`
- [ ] Read active plan
- [x] Read active stage
- [x] Read this task
""",
    )
    registry = build_document_registry((document,))

    result = validate_relationships_and_sections(registry)

    assert [issue.rule_id for issue in result.issues] == [
        RULE_PLANNING_INCOMPLETE_INTAKE_CHECKLIST
    ]
    assert "Read active plan" in result.issues[0].message


def test_active_implementation_task_passes_with_complete_intake_checklist(
    tmp_path: Path,
):
    document = planning_document(
        tmp_path / "task.md",
        status="in_progress",
        body="""# Task

## Readiness

## Intake Checklist

- [x] Read `.ai-docs/workflows/plan-stage-workflow.md`
- [x] Read active plan
- [x] Read active stage
- [x] Read this task
""",
    )
    registry = build_document_registry((document,))

    result = validate_relationships_and_sections(registry)

    assert result.ok


def test_duplicate_global_task_id_is_reported(tmp_path: Path):
    first = planning_document(
        tmp_path / "first.md",
        document_id="TASK-000001",
    )
    second = planning_document(
        tmp_path / "second.md",
        document_id="TASK-000001",
    )
    registry = build_document_registry((first, second))

    result = validate_relationships_and_sections(registry)

    assert {issue.rule_id for issue in result.issues} >= {
        RULE_PLANNING_TASK_ID_DUPLICATE
    }


def test_task_registry_index_unknown_id_is_reported(tmp_path: Path):
    registry_document = RegistryDocument(
        path=(tmp_path / "ai-docs" / "planning" / "task-registry.md").resolve(),
        frontmatter={
            "id": "REF-TASK-REGISTRY-001",
            "type": "reference",
            "status": "draft",
            "task_index": [
                {
                    "id": "TASK-000120",
                    "path": "ai-docs/planning/tasks/2026-05/task-001-example.md",
                }
            ],
        },
    )
    registry = build_document_registry((registry_document,))

    result = validate_relationships_and_sections(registry)

    issue = result.issues[0]
    assert issue.rule_id == RULE_PLANNING_TASK_INDEX_UNKNOWN_ID
    assert issue.target_id == "TASK-000120"


def test_task_registry_index_path_mismatch_is_reported(tmp_path: Path):
    registry_document = RegistryDocument(
        path=(tmp_path / "ai-docs" / "planning" / "task-registry.md").resolve(),
        frontmatter={
            "id": "REF-TASK-REGISTRY-001",
            "type": "reference",
            "status": "draft",
            "task_index": [
                {
                    "id": "TASK-000120",
                    "path": "ai-docs/planning/tasks/2026-05/task-001-example.md",
                }
            ],
        },
    )
    task_document = planning_document(
        tmp_path / "ai-docs" / "planning" / "tasks" / "2026-05" / "task-002-example.md",
        document_id="TASK-000120",
        document_type="standalone_task",
        status="planned",
        scope={"placement": "standalone", "task": "example"},
    )
    registry = build_document_registry((registry_document, task_document))

    result = validate_relationships_and_sections(registry)

    issue = result.issues[0]
    assert issue.rule_id == RULE_PLANNING_TASK_INDEX_PATH_MISMATCH
    assert issue.target_id == "TASK-000120"


def test_task_registry_index_accepts_matching_path(tmp_path: Path):
    registry_document = RegistryDocument(
        path=(tmp_path / "ai-docs" / "planning" / "task-registry.md").resolve(),
        frontmatter={
            "id": "REF-TASK-REGISTRY-001",
            "type": "reference",
            "status": "draft",
            "task_index": [
                {
                    "id": "TASK-000120",
                    "path": "ai-docs/planning/tasks/2026-05/task-001-example.md",
                }
            ],
        },
    )
    task_document = planning_document(
        tmp_path / "ai-docs" / "planning" / "tasks" / "2026-05" / "task-001-example.md",
        document_id="TASK-000120",
        document_type="standalone_task",
        status="planned",
        scope={"placement": "standalone", "task": "example"},
    )
    registry = build_document_registry((registry_document, task_document))

    result = validate_relationships_and_sections(registry)

    assert all(
        issue.rule_id
        not in {
            RULE_PLANNING_TASK_INDEX_UNKNOWN_ID,
            RULE_PLANNING_TASK_INDEX_PATH_MISMATCH,
        }
        for issue in result.issues
    )


def test_contextual_legacy_task_ids_do_not_trigger_global_task_id_validation(
    tmp_path: Path,
):
    first = planning_document(
        tmp_path / "first.md",
        document_id="TASK-MVP-PHASE-1-001",
    )
    second = planning_document(
        tmp_path / "second.md",
        document_id="TASK-MVP-PHASE-1-002",
    )
    registry = build_document_registry((first, second))

    result = validate_relationships_and_sections(registry)

    assert result.ok


def test_invalid_task_placement_is_reported(tmp_path: Path):
    document = planning_document(
        tmp_path / "task.md",
        scope={"placement": "unknown"},
    )
    registry = build_document_registry((document,))

    result = validate_relationships_and_sections(registry)

    assert [issue.rule_id for issue in result.issues] == [
        RULE_PLANNING_INVALID_PLACEMENT
    ]


def test_active_task_requires_explicit_placement(tmp_path: Path):
    document = planning_document(
        tmp_path / "task.md",
        status="planned",
        scope={"plan": "test-plan", "stage": "phase-1", "task_order": 1},
    )
    registry = build_document_registry((document,))

    result = validate_relationships_and_sections(registry)

    assert [issue.rule_id for issue in result.issues] == [
        RULE_PLANNING_MISSING_PLACEMENT
    ]


def test_done_task_does_not_require_explicit_placement(tmp_path: Path):
    document = planning_document(
        tmp_path / "task.md",
        status="done",
        scope={"plan": "test-plan", "stage": "phase-1", "task_order": 1},
        body="""# Task

## Closing Observations

None.

## Closure Checklist

```yaml
closure:
  observations_reported_with_disposition: true
```
""",
    )
    registry = build_document_registry((document,))

    result = validate_relationships_and_sections(registry)

    assert result.ok


def test_missing_placement_required_field_is_reported(tmp_path: Path):
    document = planning_document(
        tmp_path / "task.md",
        scope={"placement": "plan_stage", "plan": "test-plan"},
    )
    registry = build_document_registry((document,))

    result = validate_relationships_and_sections(registry)

    assert [issue.rule_id for issue in result.issues] == [
        RULE_PLANNING_MISSING_PLACEMENT_FIELD,
        RULE_PLANNING_MISSING_PLACEMENT_FIELD,
    ]
    assert "`stage`" in result.issues[0].message
    assert "`task_order`" in result.issues[1].message


def test_active_task_readiness_proposal_requires_valid_disposition(tmp_path: Path):
    document = planning_document(
        tmp_path / "task.md",
        status="ready",
        body="""# Task

## Readiness

## Intake Checklist

- [x] Read `.ai-docs/workflows/plan-stage-workflow.md`
- [x] Read active plan
- [x] Read active stage
- [x] Read this task

## Readiness Proposals

- Proposal: Use a new validation rule.
  Blocking: no
  Disposition: maybe
  Rationale: Invalid disposition.
  Follow-up: None.
""",
    )
    registry = build_document_registry((document,))

    result = validate_relationships_and_sections(registry)

    assert [issue.rule_id for issue in result.issues] == [
        RULE_PLANNING_INVALID_READINESS_PROPOSAL
    ]


def test_active_task_readiness_proposal_accepts_valid_disposition(tmp_path: Path):
    document = planning_document(
        tmp_path / "task.md",
        status="ready",
        body="""# Task

## Readiness

## Intake Checklist

- [x] Read `.ai-docs/workflows/plan-stage-workflow.md`
- [x] Read active plan
- [x] Read active stage
- [x] Read this task

## Readiness Proposals

- Proposal: Use a new validation rule.
  Blocking: no
  Disposition: accepted
  Rationale: Valid disposition.
  Follow-up: None.
""",
    )
    registry = build_document_registry((document,))

    result = validate_relationships_and_sections(registry)

    assert result.ok


def test_active_standalone_task_requires_standalone_intake_items(tmp_path: Path):
    document = planning_document(
        tmp_path / "task-001-example.md",
        document_id="TASK-STANDALONE-2026-001",
        document_type="standalone_task",
        status="ready",
        body="""# Standalone Task

## Readiness

## Intake Checklist

- [x] Read `.ai-docs/workflows/plan-stage-workflow.md`
- [x] Read this task
""",
    )
    registry = build_document_registry((document,))

    result = validate_relationships_and_sections(registry)

    assert [issue.rule_id for issue in result.issues] == [
        RULE_PLANNING_INCOMPLETE_INTAKE_CHECKLIST
    ]
    assert "Review standalone scope rationale" in result.issues[0].message


def test_terminal_planning_record_requires_closure_sections(tmp_path: Path):
    document = planning_document(
        tmp_path / "task.md",
        status="done",
        body="""# Task

## Closing Observations

None.
""",
    )
    registry = build_document_registry((document,))

    result = validate_relationships_and_sections(registry)

    assert [issue.rule_id for issue in result.issues] == [
        RULE_PLANNING_MISSING_CLOSURE_CHECKLIST
    ]


def test_implementation_stage_requires_design_first_task(tmp_path: Path):
    stage = planning_document(
        tmp_path / "ai-docs" / "planning" / "stage.md",
        document_id="STAGE-000200",
        document_type="plan_stage",
        status="ready",
        body="""# Stage

## Readiness

Status: ready

## Scope

- Implementation stage.
""",
    )
    stage.frontmatter["related"] = {"tasks": ["TASK-000200"]}
    task = planning_document(
        tmp_path / "ai-docs" / "planning" / "task.md",
        document_id="TASK-000200",
        body="# Task\n\n## Test Plan\n\n- Run tests.\n",
    )
    registry = build_document_registry((stage, task))

    result = validate_relationships_and_sections(registry)

    assert RULE_PLANNING_MISSING_DESIGN_FIRST_TASK in {
        issue.rule_id for issue in result.issues
    }


def test_active_implementation_task_requires_test_plan(tmp_path: Path):
    document = planning_document(
        tmp_path / "ai-docs" / "planning" / "task.md",
        status="planned",
        body="# Task\n",
    )
    registry = build_document_registry((document,))

    result = validate_relationships_and_sections(registry)

    assert RULE_PLANNING_MISSING_TEST_PLAN in {issue.rule_id for issue in result.issues}


def test_closed_task_requires_validation_command_and_result(tmp_path: Path):
    document = planning_document(
        tmp_path / "ai-docs" / "planning" / "task.md",
        status="done",
        body="""# Task

## Test Plan

- Run tests.

## Validation

- Pending.

## Closing Observations

None.

## Closure Checklist

```yaml
observations_reported_with_disposition: true
```
""",
    )
    registry = build_document_registry((document,))

    result = validate_relationships_and_sections(registry)

    assert RULE_PLANNING_MISSING_VALIDATION_COMMAND in {
        issue.rule_id for issue in result.issues
    }


def test_terminal_planning_record_requires_closing_observations(tmp_path: Path):
    document = planning_document(
        tmp_path / "task.md",
        status="done",
        body="""# Task

## Closure Checklist

```yaml
closure:
  observations_recorded: true
  observations_reported_with_disposition: true
```
""",
    )
    registry = build_document_registry((document,))

    result = validate_relationships_and_sections(registry)

    assert [issue.rule_id for issue in result.issues] == [
        RULE_PLANNING_MISSING_CLOSURE_OBSERVATIONS
    ]


def test_terminal_planning_record_requires_observation_disposition(tmp_path: Path):
    document = planning_document(
        tmp_path / "task.md",
        status="done",
        body="""# Task

## Closing Observations

- Observation: without disposition.

## Closure Checklist

```yaml
closure:
  observations_recorded: true
  observations_reported_with_disposition: true
```
""",
    )
    registry = build_document_registry((document,))

    result = validate_relationships_and_sections(registry)

    assert {issue.rule_id for issue in result.issues} == {
        RULE_PLANNING_UNRESOLVED_OBSERVATION
    }
    assert any("`Disposition:`" in issue.message for issue in result.issues)


def test_terminal_planning_record_requires_expanded_observation_fields(tmp_path: Path):
    document = planning_document(
        tmp_path / "task.md",
        status="done",
        body="""# Task

## Closing Observations

- Observation: missing action and follow-up.

  Impact:
  The observation is not actionable.

  Disposition:
  documented

  Rationale:
  The current task documents the limitation.

## Closure Checklist

```yaml
closure:
  observations_recorded: true
  observations_reported_to_user: true
  observations_reported_with_disposition: true
  observations_resolved: true
```
""",
    )
    registry = build_document_registry((document,))

    result = validate_relationships_and_sections(registry)

    assert [issue.rule_id for issue in result.issues] == [
        RULE_PLANNING_UNRESOLVED_OBSERVATION,
        RULE_PLANNING_UNRESOLVED_OBSERVATION,
    ]
    assert [issue.message for issue in result.issues] == [
        "Closing observation 1 is missing required field `Action taken:`.",
        "Closing observation 1 is missing required field `Follow-up:`.",
    ]


def test_terminal_planning_record_requires_disposition_report_checklist_field(
    tmp_path: Path,
):
    document = planning_document(
        tmp_path / "task.md",
        status="done",
        body="""# Task

## Closing Observations

None.

## Closure Checklist

```yaml
closure:
  observations_recorded: true
  observations_reported_to_user: true
  observations_resolved: true
```
""",
    )
    registry = build_document_registry((document,))

    result = validate_relationships_and_sections(registry)

    assert [issue.rule_id for issue in result.issues] == [
        RULE_PLANNING_INCOMPLETE_CLOSURE_CHECKLIST
    ]


def test_completed_plan_work_history_skips_expanded_closure_validation(tmp_path: Path):
    plan = planning_document(
        tmp_path / "plan.md",
        document_id="PLAN-COMPLETED-001",
        document_type="plan",
        status="done",
        body="""# Plan

## Closing Observations

None.

## Closure Checklist

```yaml
closure:
  observations_recorded: true
```
""",
    )
    task = RegistryDocument(
        path=(tmp_path / "task.md").resolve(),
        frontmatter={
            "id": "TASK-COMPLETED-001",
            "type": "implementation_task",
            "status": "done",
            "scope": {"plan": "completed-plan"},
            "related": {},
        },
        body="""# Task

## Closing Observations

- Observation: legacy format.

  Disposition:
  documented

  Rationale:
  Historical record.

## Closure Checklist

```yaml
closure:
  observations_recorded: true
```
""",
    )
    plan = RegistryDocument(
        path=plan.path,
        frontmatter={**plan.frontmatter, "scope": {"plan": "completed-plan"}},
        body=plan.body,
    )
    registry = build_document_registry((plan, task))

    result = validate_relationships_and_sections(registry)

    assert result.ok


def test_archived_planning_record_uses_lighter_validation(tmp_path: Path):
    document = planning_document(
        tmp_path / "task.md",
        status="archived",
    )
    registry = build_document_registry((document,))

    result = validate_relationships_and_sections(registry)

    assert result.ok


def test_exported_planning_record_uses_lighter_validation(tmp_path: Path):
    document = planning_document(
        tmp_path / "task.md",
        status="exported",
    )
    registry = build_document_registry((document,))

    result = validate_relationships_and_sections(registry)

    assert result.ok


def test_minimal_project_relationships_and_required_sections_pass():
    project_root = Path.cwd() / "examples" / "minimal-project"
    config_result = load_project_config(project_root)
    assert config_result.config is not None

    documents = []
    for path in scan_markdown_files(config_result.config):
        parse_result = parse_markdown_file(path)
        assert parse_result.document is not None
        documents.append(registry_document_from_parsed(parse_result.document))

    registry = build_document_registry(tuple(documents))
    assert registry.ok

    result = validate_relationships_and_sections(registry)

    assert result.ok
