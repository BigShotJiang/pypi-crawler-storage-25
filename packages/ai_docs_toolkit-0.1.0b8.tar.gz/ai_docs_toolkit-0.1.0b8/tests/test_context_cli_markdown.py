import subprocess
from pathlib import Path

from ai_docs_toolkit.cli import main


def test_context_markdown_output_for_explicit_id(monkeypatch, capsys, tmp_path):
    _write_context_project(tmp_path)
    _write_document(
        tmp_path / "ai-docs" / "business-rule.md",
        document_id="BR-TEST-001",
        document_type="business_rule",
        related={"acceptance": ["ACC-TEST-001"]},
        context_role="constraint",
        body="Business rule body.",
    )
    _write_document(
        tmp_path / "ai-docs" / "acceptance.md",
        document_id="ACC-TEST-001",
        document_type="acceptance",
        context_role="validation",
        body="Acceptance body.",
    )
    monkeypatch.chdir(tmp_path)

    assert main(["context", "--id", "BR-TEST-001"]) == 0

    output = capsys.readouterr()
    assert output.out == (
        "# AI Docs Context Bundle\n"
        "\n"
        "Status: completed\n"
        "Sources: 1\n"
        "Documents: 2\n"
        "\n"
        "## Sources\n"
        "- BR-TEST-001 (business_rule) ai-docs/business-rule.md source=id\n"
        "\n"
        "## Documents\n"
        "\n"
        "### BR-TEST-001\n"
        "\n"
        "```yaml\n"
        "type: business_rule\n"
        "path: ai-docs/business-rule.md\n"
        "group: source\n"
        "distance: 0\n"
        "priority: medium\n"
        "context_role: constraint\n"
        "reasons:\n"
        "  - BR-TEST-001 is a context source.\n"
        "```\n"
        "\n"
        "# BR-TEST-001\n"
        "\n"
        "Business rule body.\n"
        "\n"
        "### ACC-TEST-001\n"
        "\n"
        "```yaml\n"
        "type: acceptance\n"
        "path: ai-docs/acceptance.md\n"
        "group: validation\n"
        "distance: 1\n"
        "priority: medium\n"
        "context_role: validation\n"
        "reasons:\n"
        "  - BR-TEST-001 references ACC-TEST-001 through related.acceptance.\n"
        "```\n"
        "\n"
        "# ACC-TEST-001\n"
        "\n"
        "Acceptance body.\n"
    )
    assert output.err == ""


def test_context_markdown_output_for_module_and_feature(monkeypatch, capsys, tmp_path):
    _write_context_project(tmp_path)
    _write_document(
        tmp_path / "ai-docs" / "module.md",
        document_id="MOD-TEST-001",
        document_type="module",
        scope={
            "domains": [],
            "modules": ["checkout"],
            "features": ["submit-order"],
        },
        context_role="behavior",
        body="Module body.",
    )
    monkeypatch.chdir(tmp_path)

    assert main(["context", "--module", "checkout"]) == 0
    module_output = capsys.readouterr()
    assert "- MOD-TEST-001 (module) ai-docs/module.md source=module" in module_output.out
    assert "Documents: 1" in module_output.out
    assert module_output.err == ""

    assert main(["context", "--feature", "submit-order"]) == 0
    feature_output = capsys.readouterr()
    assert "- MOD-TEST-001 (module) ai-docs/module.md source=feature" in feature_output.out
    assert "Documents: 1" in feature_output.out
    assert feature_output.err == ""


def test_context_markdown_output_for_changed_source(monkeypatch, capsys, tmp_path):
    _write_context_project(tmp_path)
    _write_document(
        tmp_path / "ai-docs" / "business-rule.md",
        document_id="BR-TEST-001",
        document_type="business_rule",
        related={"acceptance": ["ACC-TEST-001"]},
        context_role="constraint",
        body="Business rule body.",
    )
    _write_document(
        tmp_path / "ai-docs" / "acceptance.md",
        document_id="ACC-TEST-001",
        document_type="acceptance",
        context_role="validation",
        body="Acceptance body.",
    )
    _commit_all(tmp_path)
    (tmp_path / "ai-docs" / "business-rule.md").write_text(
        (tmp_path / "ai-docs" / "business-rule.md").read_text(encoding="utf-8")
        + "\nChanged.\n",
        encoding="utf-8",
    )
    monkeypatch.chdir(tmp_path)

    assert main(["context", "--changed"]) == 0

    output = capsys.readouterr()
    assert "Status: completed" in output.out
    assert "Documents: 2" in output.out
    assert (
        "- BR-TEST-001 (business_rule) ai-docs/business-rule.md "
        "source=changed changed_file=ai-docs/business-rule.md"
    ) in output.out
    assert output.err == ""


def test_context_markdown_changed_warns_for_non_document_files(
    monkeypatch,
    capsys,
    tmp_path,
):
    _write_context_project(tmp_path)
    _commit_all(tmp_path)
    (tmp_path / "README.md").write_text("# Readme\n", encoding="utf-8")
    (tmp_path / "ai-docs" / "note.txt").write_text("note\n", encoding="utf-8")
    monkeypatch.chdir(tmp_path)

    assert main(["context", "--changed"]) == 1

    output = capsys.readouterr()
    assert "Status: failed" in output.out
    assert "## Warnings" in output.out
    assert (
        "- README.md document.context.changed_file_outside_docs: "
        "Changed file `README.md` is outside configured documentation roots."
    ) in output.out
    assert (
        "- ai-docs/note.txt document.context.changed_file_not_document: "
        "Changed file `ai-docs/note.txt` is not a parsed document."
    ) in output.out
    assert (
        "- document.context.no_sources: Context selection did not find source documents."
    ) in output.out
    assert output.err == ""


def test_context_markdown_output_includes_validation_errors(monkeypatch, capsys, tmp_path):
    _write_context_project(tmp_path)
    monkeypatch.chdir(tmp_path)

    assert main(["context", "--id", "UNKNOWN-001"]) == 1

    output = capsys.readouterr()
    assert output.out == (
        "# AI Docs Context Bundle\n"
        "\n"
        "Status: failed\n"
        "Sources: 0\n"
        "Documents: 0\n"
        "\n"
        "## Errors\n"
        "- [UNKNOWN-001] document.context.unknown_id: "
        "Context source references unknown document id `UNKNOWN-001`.\n"
        "- document.context.no_sources: Context selection did not find source documents.\n"
    )
    assert output.err == ""


def test_context_usage_errors(capsys):
    assert main(["context", "--id"]) == 3
    output = capsys.readouterr()
    assert output.out == ""
    assert (
        "Usage: ai-docs context "
        "(--id ID | --module MODULE | --feature FEATURE | --changed) [--format json]"
    ) in output.err

    assert main(["context", "--changed", "extra"]) == 3
    output = capsys.readouterr()
    assert output.out == ""
    assert (
        "Usage: ai-docs context "
        "(--id ID | --module MODULE | --feature FEATURE | --changed) [--format json]"
    ) in output.err


def _write_context_project(project_root: Path) -> None:
    (project_root / "ai-docs").mkdir()
    (project_root / "ai-docs.config.yaml").write_text(
        """version: 1

project:
  name: context-test
  documentation_roots:
    - ai-docs
""",
        encoding="utf-8",
    )
    _run_git(project_root, "init")


def _write_document(
    path: Path,
    *,
    document_id: str,
    document_type: str,
    related: dict[str, list[str]] | None = None,
    scope: dict[str, list[str]] | None = None,
    priority: str = "medium",
    context_role: str = "reference",
    body: str = "Body.",
) -> None:
    relationships = {
        "business_rules": [],
        "architecture_decisions": [],
        "contracts": [],
        "modules": [],
        "scenarios": [],
        "acceptance": [],
        "operations": [],
    }
    relationships.update(related or {})
    related_yaml = "\n".join(
        f"  {key}: [{', '.join(values)}]" if values else f"  {key}: []"
        for key, values in relationships.items()
    )
    scope_value = scope or {"domains": [], "modules": [], "features": []}
    scope_yaml = "\n".join(
        f"  {key}: [{', '.join(values)}]" if values else f"  {key}: []"
        for key, values in scope_value.items()
    )
    path.write_text(
        f"""---
id: {document_id}
type: {document_type}
status: draft
title: {document_id} title
summary: {document_id} summary
scope:
{scope_yaml}
owners:
  - maintainers
related:
{related_yaml}
ai:
  priority: {priority}
  load_when: []
  avoid_when: []
  context_role: {context_role}
validation:
  required_checks: []
  last_validated: null
---

# {document_id}

{body}
""",
        encoding="utf-8",
    )


def _commit_all(project_root: Path) -> None:
    _run_git(project_root, "add", ".")
    _run_git(
        project_root,
        "-c",
        "user.name=Test User",
        "-c",
        "user.email=test@example.com",
        "commit",
        "-m",
        "Initial commit",
    )


def _run_git(project_root: Path, *args: str) -> None:
    subprocess.run(
        ["git", *args],
        cwd=project_root,
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
