from pathlib import Path

import pytest

from ai_docs_toolkit.core import (
    RULE_DOCUMENT_ALIAS_COLLIDES_WITH_ID,
    RULE_DOCUMENT_ALIAS_DUPLICATE,
    RULE_DOCUMENT_ID_DUPLICATE,
    RULE_DOCUMENT_ID_MISSING,
    RegistryDocument,
    build_document_registry,
    parse_markdown_text,
    registry_document_from_parsed,
)


def document(path: Path, document_id: str | None) -> RegistryDocument:
    frontmatter = {}
    if document_id is not None:
        frontmatter["id"] = document_id

    return RegistryDocument(path=path, frontmatter=frontmatter)


def document_with_aliases(
    path: Path,
    document_id: str,
    aliases: list[str],
) -> RegistryDocument:
    return RegistryDocument(
        path=path,
        frontmatter={
            "id": document_id,
            "aliases": aliases,
        },
    )


def test_unique_ids_pass_registry_checks(tmp_path: Path):
    first = document(tmp_path / "first.md", "DOC-001")
    second = document(tmp_path / "second.md", "DOC-002")

    registry = build_document_registry((first, second))

    assert registry.ok
    assert registry.issues == ()
    assert registry.get_by_id("DOC-001") == first
    assert registry.get_by_path(tmp_path / "second.md") == second


def test_duplicate_ids_produce_validation_error_with_all_affected_paths(
    tmp_path: Path,
):
    first = document(tmp_path / "first.md", "DOC-001")
    second = document(tmp_path / "nested" / "second.md", "DOC-001")
    third = document(tmp_path / "third.md", "DOC-002")

    registry = build_document_registry((first, second, third))

    assert not registry.ok
    assert registry.get_by_id("DOC-002") == third
    assert registry.get_by_id("DOC-001") is None
    assert len(registry.issues) == 1
    issue = registry.issues[0]
    assert issue.rule_id == RULE_DOCUMENT_ID_DUPLICATE
    assert issue.document_id == "DOC-001"
    assert issue.paths == tuple(sorted((first.path.resolve(), second.path.resolve())))


def test_aliases_resolve_to_primary_document(tmp_path: Path):
    source = document_with_aliases(
        tmp_path / "source.md",
        "PLAN-000003",
        ["PLAN-CONSUMER-MIGRATION-001"],
    )
    registry = build_document_registry((source,))

    assert registry.ok
    assert registry.get_by_id("PLAN-000003") == source
    assert registry.get_by_id("PLAN-CONSUMER-MIGRATION-001") == source


def test_duplicate_aliases_produce_validation_error(tmp_path: Path):
    first = document_with_aliases(
        tmp_path / "first.md",
        "PLAN-000003",
        ["PLAN-LEGACY-001"],
    )
    second = document_with_aliases(
        tmp_path / "second.md",
        "PLAN-000004",
        ["PLAN-LEGACY-001"],
    )

    registry = build_document_registry((first, second))

    assert not registry.ok
    assert registry.get_by_id("PLAN-LEGACY-001") is None
    issue = registry.issues[0]
    assert issue.rule_id == RULE_DOCUMENT_ALIAS_DUPLICATE
    assert issue.document_id == "PLAN-LEGACY-001"
    assert issue.paths == tuple(sorted((first.path.resolve(), second.path.resolve())))


def test_alias_colliding_with_primary_id_produces_validation_error(tmp_path: Path):
    first = document_with_aliases(
        tmp_path / "first.md",
        "PLAN-000003",
        ["PLAN-000004"],
    )
    second = document(tmp_path / "second.md", "PLAN-000004")

    registry = build_document_registry((first, second))

    assert not registry.ok
    assert registry.get_by_id("PLAN-000004") == second
    issue = registry.issues[0]
    assert issue.rule_id == RULE_DOCUMENT_ALIAS_COLLIDES_WITH_ID
    assert issue.document_id == "PLAN-000004"


def test_documents_without_ids_produce_useful_validation_errors(tmp_path: Path):
    without_id = document(tmp_path / "without-id.md", None)

    registry = build_document_registry((without_id,))

    assert not registry.ok
    assert registry.documents_by_path[without_id.path.resolve()] == without_id
    assert registry.documents_by_id == {}
    assert len(registry.issues) == 1
    issue = registry.issues[0]
    assert issue.rule_id == RULE_DOCUMENT_ID_MISSING
    assert issue.document_id is None
    assert issue.paths == (without_id.path.resolve(),)


def test_registry_document_can_be_created_from_parsed_document(tmp_path: Path):
    path = tmp_path / "document.md"
    result = parse_markdown_text("---\nid: DOC-001\n---\n# Title\n", path=str(path))
    assert result.document is not None

    registry_document = registry_document_from_parsed(result.document)

    assert registry_document.path == path.resolve()
    assert registry_document.document_id == "DOC-001"
    assert registry_document.body == "# Title\n"


def test_registry_document_from_parsed_requires_path():
    result = parse_markdown_text("---\nid: DOC-001\n---\n# Title\n")
    assert result.document is not None

    with pytest.raises(ValueError, match="path is required"):
        registry_document_from_parsed(result.document)
