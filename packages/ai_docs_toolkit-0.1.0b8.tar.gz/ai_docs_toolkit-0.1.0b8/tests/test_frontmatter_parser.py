from pathlib import Path

from ai_docs_toolkit.core import parse_markdown_file, parse_markdown_text


def test_parse_valid_markdown_with_frontmatter():
    result = parse_markdown_text(
        """---
id: DOC-001
type: business_rule
owners:
  - maintainers
---

# Title

Body text.
""",
        path="ai-docs/example.md",
    )

    assert result.ok
    assert result.document is not None
    assert result.document.path == "ai-docs/example.md"
    assert result.document.frontmatter == {
        "id": "DOC-001",
        "type": "business_rule",
        "owners": ["maintainers"],
    }
    assert result.document.body == "\n# Title\n\nBody text.\n"
    assert result.errors == ()


def test_missing_frontmatter_returns_validation_ready_error():
    result = parse_markdown_text("# Title\n\nBody text.\n", path="ai-docs/missing.md")

    assert not result.ok
    assert result.document is None
    assert len(result.errors) == 1
    error = result.errors[0]
    assert error.code == "missing_frontmatter"
    assert error.path == "ai-docs/missing.md"
    assert error.line == 1
    assert error.column == 1


def test_invalid_yaml_returns_validation_ready_error():
    result = parse_markdown_text(
        """---
id: DOC-001
owners:
  - maintainers
    broken: value
---

# Title
""",
        path="ai-docs/invalid.md",
    )

    assert not result.ok
    assert result.document is None
    assert len(result.errors) == 1
    error = result.errors[0]
    assert error.code == "invalid_yaml"
    assert error.path == "ai-docs/invalid.md"
    assert error.line is not None
    assert error.column is not None
    assert "Invalid YAML front matter" in error.message


def test_missing_closing_delimiter_returns_error():
    result = parse_markdown_text("---\nid: DOC-001\n# Title\n", path="ai-docs/open.md")

    assert not result.ok
    assert result.document is None
    assert result.errors[0].code == "missing_frontmatter_closing_delimiter"


def test_non_mapping_frontmatter_returns_error():
    result = parse_markdown_text("---\n- item\n---\n# Title\n", path="ai-docs/list.md")

    assert not result.ok
    assert result.document is None
    assert result.errors[0].code == "invalid_frontmatter_type"


def test_parse_markdown_file(tmp_path: Path):
    markdown_file = tmp_path / "document.md"
    markdown_file.write_text("---\nid: DOC-001\n---\n# Title\n", encoding="utf-8")

    result = parse_markdown_file(markdown_file)

    assert result.ok
    assert result.document is not None
    assert result.document.frontmatter["id"] == "DOC-001"
    assert result.document.path == str(markdown_file)
