from ai_docs_toolkit.core import (
    DocumentGraph,
    DocumentGraphEdge,
    DocumentGraphNode,
    ImpactAnalysisIssue,
    ImpactReason,
    ImpactedDocument,
    RULE_DOCUMENT_IMPACT_UNKNOWN_ID,
    analyze_document_impact,
)


def node(
    document_id: str,
    document_type: str,
    *,
    path: str | None = None,
) -> DocumentGraphNode:
    return DocumentGraphNode(
        id=document_id,
        type=document_type,
        path=path or f"ai-docs/{document_id.lower()}.md",
        title=f"{document_id} title",
        summary=f"{document_id} summary",
        scope={"domains": [], "modules": [], "features": []},
    )


def edge(
    source: str,
    target: str,
    relationship: str,
) -> DocumentGraphEdge:
    return DocumentGraphEdge(
        source=source,
        target=target,
        relationship=relationship,
        source_path=f"ai-docs/{source.lower()}.md",
        target_path=f"ai-docs/{target.lower()}.md",
    )


def graph(
    nodes: tuple[DocumentGraphNode, ...],
    edges: tuple[DocumentGraphEdge, ...],
) -> DocumentGraph:
    return DocumentGraph(nodes=nodes, edges=edges)


def test_impact_analyzer_reports_direct_impact():
    document_graph = graph(
        nodes=(
            node("BR-TEST-001", "business_rule"),
            node("ACC-TEST-001", "acceptance"),
        ),
        edges=(edge("BR-TEST-001", "ACC-TEST-001", "acceptance"),),
    )

    result = analyze_document_impact(document_graph, ["BR-TEST-001"])

    assert result.ok
    assert [source.document_id for source in result.sources] == ["BR-TEST-001"]
    assert result.impacted == (
        ImpactedDocument(
            document_id="ACC-TEST-001",
            type="acceptance",
            path="ai-docs/acc-test-001.md",
            title="ACC-TEST-001 title",
            summary="ACC-TEST-001 summary",
            impact="direct",
            distance=1,
            reasons=(
                ImpactReason(
                    source="BR-TEST-001",
                    via=None,
                    relationship="acceptance",
                    direction="outgoing",
                    message=(
                        "BR-TEST-001 references ACC-TEST-001 "
                        "through related.acceptance."
                    ),
                ),
            ),
        ),
    )


def test_impact_analyzer_reports_transitive_impact():
    document_graph = graph(
        nodes=(
            node("BR-TEST-001", "business_rule"),
            node("ADR-TEST-001", "architecture_decision"),
            node("MOD-TEST-001", "module"),
        ),
        edges=(
            edge("BR-TEST-001", "ADR-TEST-001", "architecture_decisions"),
            edge("ADR-TEST-001", "MOD-TEST-001", "modules"),
        ),
    )

    result = analyze_document_impact(document_graph, ["BR-TEST-001"])

    assert [(item.document_id, item.impact, item.distance) for item in result.impacted] == [
        ("ADR-TEST-001", "direct", 1),
        ("MOD-TEST-001", "transitive", 2),
    ]
    module = result.impacted[1]
    assert module.reasons == (
        ImpactReason(
            source="BR-TEST-001",
            via="ADR-TEST-001",
            relationship="modules",
            direction="outgoing",
            message="ADR-TEST-001 references MOD-TEST-001 through related.modules.",
        ),
    )


def test_impact_analyzer_uses_incoming_edges_when_transition_allows_it():
    document_graph = graph(
        nodes=(
            node("MOD-TEST-001", "module"),
            node("CON-TEST-001", "contract"),
            node("ACC-TEST-001", "acceptance"),
        ),
        edges=(
            edge("CON-TEST-001", "MOD-TEST-001", "modules"),
            edge("ACC-TEST-001", "MOD-TEST-001", "modules"),
        ),
    )

    result = analyze_document_impact(document_graph, ["MOD-TEST-001"])

    assert [(item.document_id, item.impact, item.distance) for item in result.impacted] == [
        ("ACC-TEST-001", "direct", 1),
        ("CON-TEST-001", "direct", 1),
    ]
    assert result.impacted[0].reasons[0].direction == "incoming"
    assert result.impacted[1].reasons[0].direction == "incoming"


def test_impact_analyzer_skips_disallowed_type_transitions():
    document_graph = graph(
        nodes=(
            node("ACC-TEST-001", "acceptance"),
            node("BR-TEST-001", "business_rule"),
        ),
        edges=(edge("ACC-TEST-001", "BR-TEST-001", "business_rules"),),
    )

    result = analyze_document_impact(document_graph, ["ACC-TEST-001"])

    assert result.impacted == ()


def test_impact_analyzer_reports_unknown_source_ids():
    document_graph = graph(nodes=(), edges=())

    result = analyze_document_impact(document_graph, ["UNKNOWN-001"])

    assert not result.ok
    assert result.sources == ()
    assert result.impacted == ()
    assert result.issues == (
        ImpactAnalysisIssue(
            rule_id=RULE_DOCUMENT_IMPACT_UNKNOWN_ID,
            message="Impact source references unknown document id `UNKNOWN-001`.",
            document_id="UNKNOWN-001",
        ),
    )


def test_impact_analyzer_output_is_deterministic():
    document_graph = graph(
        nodes=(
            node("BR-TEST-001", "business_rule"),
            node("ACC-TEST-002", "acceptance"),
            node("ACC-TEST-001", "acceptance"),
        ),
        edges=(
            edge("BR-TEST-001", "ACC-TEST-002", "acceptance"),
            edge("BR-TEST-001", "ACC-TEST-001", "acceptance"),
        ),
    )

    first = analyze_document_impact(document_graph, ["BR-TEST-001"])
    second = analyze_document_impact(document_graph, ["BR-TEST-001"])

    assert first == second
    assert [item.document_id for item in first.impacted] == [
        "ACC-TEST-001",
        "ACC-TEST-002",
    ]
