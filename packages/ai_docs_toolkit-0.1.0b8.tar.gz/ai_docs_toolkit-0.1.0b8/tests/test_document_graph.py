from pathlib import Path

from ai_docs_toolkit.core import (
    DocumentGraphEdge,
    DocumentGraphNode,
    RegistryDocument,
    build_document_graph,
    build_document_registry,
    load_project_config,
    parse_markdown_file,
    registry_document_from_parsed,
    scan_markdown_files,
)


def document(
    path: Path,
    *,
    document_id: str,
    document_type: str,
    related: dict[str, list[str]] | None = None,
    scope: dict[str, list[str]] | None = None,
    title: str = "Title",
    summary: str = "Summary",
) -> RegistryDocument:
    return RegistryDocument(
        path=path.resolve(),
        frontmatter={
            "id": document_id,
            "type": document_type,
            "title": title,
            "summary": summary,
            "scope": scope
            or {
                "domains": [],
                "modules": [],
                "features": [],
            },
            "related": related or {},
        },
    )


def test_graph_nodes_include_contract_fields(tmp_path: Path):
    registry = build_document_registry(
        (
            document(
                tmp_path / "ai-docs" / "rule.md",
                document_id="BR-TEST-001",
                document_type="business_rule",
                scope={"domains": ["ordering"], "modules": ["checkout"], "features": []},
                title="Rule",
                summary="Rule summary",
            ),
        )
    )

    graph = build_document_graph(registry, project_root=tmp_path)

    assert graph.nodes == (
        DocumentGraphNode(
            id="BR-TEST-001",
            type="business_rule",
            path="ai-docs/rule.md",
            title="Rule",
            summary="Rule summary",
            scope={"domains": ["ordering"], "modules": ["checkout"], "features": []},
        ),
    )
    assert graph.edges == ()


def test_graph_edges_are_created_from_resolved_related_ids(tmp_path: Path):
    source = document(
        tmp_path / "rule.md",
        document_id="BR-TEST-001",
        document_type="business_rule",
        related={"modules": ["MOD-TEST-001"]},
    )
    target = document(
        tmp_path / "module.md",
        document_id="MOD-TEST-001",
        document_type="module",
    )
    registry = build_document_registry((source, target))

    graph = build_document_graph(registry, project_root=tmp_path)

    assert graph.edges == (
        DocumentGraphEdge(
            source="BR-TEST-001",
            target="MOD-TEST-001",
            relationship="modules",
            source_path="rule.md",
            target_path="module.md",
        ),
    )


def test_graph_skips_unresolved_related_ids(tmp_path: Path):
    source = document(
        tmp_path / "rule.md",
        document_id="BR-TEST-001",
        document_type="business_rule",
        related={"modules": ["MOD-MISSING-001"]},
    )
    registry = build_document_registry((source,))

    graph = build_document_graph(registry, project_root=tmp_path)

    assert graph.edges == ()


def test_graph_collapses_duplicate_edges(tmp_path: Path):
    source = document(
        tmp_path / "rule.md",
        document_id="BR-TEST-001",
        document_type="business_rule",
        related={"modules": ["MOD-TEST-001", "MOD-TEST-001"]},
    )
    target = document(
        tmp_path / "module.md",
        document_id="MOD-TEST-001",
        document_type="module",
    )
    registry = build_document_registry((source, target))

    graph = build_document_graph(registry, project_root=tmp_path)

    assert len(graph.edges) == 1


def test_minimal_project_graph_can_be_built():
    project_root = Path.cwd() / "examples" / "minimal-project"
    config_result = load_project_config(project_root)
    assert config_result.config is not None

    documents = []
    for path in scan_markdown_files(config_result.config):
        parse_result = parse_markdown_file(path)
        assert parse_result.document is not None
        documents.append(registry_document_from_parsed(parse_result.document))

    registry = build_document_registry(tuple(documents))
    graph = build_document_graph(registry, project_root=project_root)

    assert len(graph.nodes) == 8
    assert graph.get_node("BR-ORDERING-001") is not None
    assert DocumentGraphEdge(
        source="BR-ORDERING-001",
        target="MOD-CHECKOUT-001",
        relationship="modules",
        source_path="ai-docs/business-rule-order-submission.md",
        target_path="ai-docs/module-checkout.md",
    ) in graph.edges
