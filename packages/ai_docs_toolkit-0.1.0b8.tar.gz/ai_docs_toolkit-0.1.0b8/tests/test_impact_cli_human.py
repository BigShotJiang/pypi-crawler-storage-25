import subprocess
from pathlib import Path

from ai_docs_toolkit.cli import main


def test_impact_human_output_for_explicit_id(monkeypatch, capsys, tmp_path):
    _write_impact_project(tmp_path)
    _write_document(
        tmp_path / "ai-docs" / "business-rule.md",
        document_id="BR-TEST-001",
        document_type="business_rule",
        related={"acceptance": ["ACC-TEST-001"]},
    )
    _write_document(
        tmp_path / "ai-docs" / "acceptance.md",
        document_id="ACC-TEST-001",
        document_type="acceptance",
    )
    monkeypatch.chdir(tmp_path)

    assert main(["impact", "--id", "BR-TEST-001"]) == 0

    output = capsys.readouterr()
    assert output.out == (
        "Impact analysis completed.\n"
        "Sources: 1\n"
        "Impacted documents: 1\n"
        "\n"
        "Sources:\n"
        "- BR-TEST-001 (business_rule) ai-docs/business-rule.md source=id\n"
        "\n"
        "Direct impact:\n"
        "- ACC-TEST-001 (acceptance) distance=1 ai-docs/acceptance.md\n"
        "  reason: BR-TEST-001 outgoing related.acceptance: "
        "BR-TEST-001 references ACC-TEST-001 through related.acceptance.\n"
    )
    assert output.err == ""


def test_impact_human_output_for_changed_source(monkeypatch, capsys, tmp_path):
    _write_impact_project(tmp_path)
    _write_document(
        tmp_path / "ai-docs" / "business-rule.md",
        document_id="BR-TEST-001",
        document_type="business_rule",
        related={"acceptance": ["ACC-TEST-001"]},
    )
    _write_document(
        tmp_path / "ai-docs" / "acceptance.md",
        document_id="ACC-TEST-001",
        document_type="acceptance",
    )
    _commit_all(tmp_path)
    (tmp_path / "ai-docs" / "business-rule.md").write_text(
        (tmp_path / "ai-docs" / "business-rule.md").read_text(encoding="utf-8")
        + "\nChanged.\n",
        encoding="utf-8",
    )
    monkeypatch.chdir(tmp_path)

    assert main(["impact", "--changed"]) == 0

    output = capsys.readouterr()
    assert output.out == (
        "Impact analysis completed.\n"
        "Sources: 1\n"
        "Impacted documents: 1\n"
        "\n"
        "Sources:\n"
        "- BR-TEST-001 (business_rule) ai-docs/business-rule.md "
        "source=changed changed_file=ai-docs/business-rule.md\n"
        "\n"
        "Direct impact:\n"
        "- ACC-TEST-001 (acceptance) distance=1 ai-docs/acceptance.md\n"
        "  reason: BR-TEST-001 outgoing related.acceptance: "
        "BR-TEST-001 references ACC-TEST-001 through related.acceptance.\n"
    )
    assert output.err == ""


def test_impact_human_output_includes_validation_errors(monkeypatch, capsys, tmp_path):
    _write_impact_project(tmp_path)
    monkeypatch.chdir(tmp_path)

    assert main(["impact", "--id", "UNKNOWN-001"]) == 1

    output = capsys.readouterr()
    assert output.out == (
        "Impact analysis failed.\n"
        "Sources: 0\n"
        "Impacted documents: 0\n"
        "\n"
        "Errors:\n"
        "- [UNKNOWN-001] document.impact.unknown_id: "
        "Impact source references unknown document id `UNKNOWN-001`.\n"
    )
    assert output.err == ""


def _write_impact_project(project_root: Path) -> None:
    (project_root / "ai-docs").mkdir()
    (project_root / "ai-docs.config.yaml").write_text(
        """version: 1

project:
  name: impact-test
  documentation_roots:
    - ai-docs
""",
        encoding="utf-8",
    )
    _run_git(project_root, "init")


def _write_document(
    path: Path,
    *,
    document_id: str,
    document_type: str,
    related: dict[str, list[str]] | None = None,
) -> None:
    relationships = {
        "business_rules": [],
        "architecture_decisions": [],
        "contracts": [],
        "modules": [],
        "scenarios": [],
        "acceptance": [],
        "operations": [],
    }
    relationships.update(related or {})
    related_yaml = "\n".join(
        f"  {key}: [{', '.join(values)}]" if values else f"  {key}: []"
        for key, values in relationships.items()
    )
    path.write_text(
        f"""---
id: {document_id}
type: {document_type}
status: draft
title: {document_id} title
summary: {document_id} summary
scope:
  domains: []
  modules: []
  features: []
owners:
  - maintainers
related:
{related_yaml}
ai:
  priority: medium
  load_when: []
  avoid_when: []
  context_role: validation
validation:
  required_checks: []
  last_validated: null
---

# {document_id}
""",
        encoding="utf-8",
    )


def _commit_all(project_root: Path) -> None:
    _run_git(project_root, "add", ".")
    _run_git(
        project_root,
        "-c",
        "user.name=Test User",
        "-c",
        "user.email=test@example.com",
        "commit",
        "-m",
        "Initial commit",
    )


def _run_git(project_root: Path, *args: str) -> None:
    subprocess.run(
        ["git", *args],
        cwd=project_root,
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
