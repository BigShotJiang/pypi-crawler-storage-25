import json
import subprocess
from pathlib import Path

from ai_docs_toolkit.cli import main


def test_impact_json_output_for_minimal_project(monkeypatch, capsys):
    project_root = Path.cwd() / "examples" / "minimal-project"
    monkeypatch.chdir(project_root)

    assert main(["impact", "--id", "BR-ORDERING-001", "--format", "json"]) == 0

    output = capsys.readouterr()
    payload = json.loads(output.out)
    assert sorted(payload) == ["impacted", "sources", "warnings"]
    assert payload["warnings"] == []
    assert payload["sources"] == [
        {
            "changed_file": None,
            "document_id": "BR-ORDERING-001",
            "path": "ai-docs/business-rule-order-submission.md",
            "source": "id",
            "type": "business_rule",
        }
    ]
    impacted_ids = [item["document_id"] for item in payload["impacted"]]
    assert impacted_ids == [
        "ACC-ORDER-SUBMISSION-001",
        "ADR-CHECKOUT-001",
        "CON-CHECKOUT-001",
        "MOD-CHECKOUT-001",
        "SCN-ORDER-SUBMISSION-001",
        "OPS-CHECKOUT-001",
    ]
    assert payload["impacted"][0]["impact"] == "direct"
    assert payload["impacted"][0]["distance"] == 1
    assert payload["impacted"][-1]["impact"] == "transitive"
    assert payload["impacted"][-1]["distance"] == 2
    assert payload["impacted"][0]["reasons"][0] == {
        "direction": "outgoing",
        "message": (
            "BR-ORDERING-001 references ACC-ORDER-SUBMISSION-001 "
            "through related.acceptance."
        ),
        "relationship": "acceptance",
        "source": "BR-ORDERING-001",
        "via": None,
    }
    assert output.err == ""


def test_impact_json_output_is_deterministic(monkeypatch, capsys):
    project_root = Path.cwd() / "examples" / "minimal-project"
    monkeypatch.chdir(project_root)

    assert main(["impact", "--id", "BR-ORDERING-001", "--format", "json"]) == 0
    first = capsys.readouterr().out

    assert main(["impact", "--format", "json", "--id", "BR-ORDERING-001"]) == 0
    second = capsys.readouterr().out

    assert first == second


def test_impact_unknown_id_returns_validation_error(monkeypatch, capsys):
    project_root = Path.cwd() / "examples" / "minimal-project"
    monkeypatch.chdir(project_root)

    assert main(["impact", "--id", "UNKNOWN-001", "--format", "json"]) == 1

    output = capsys.readouterr()
    payload = json.loads(output.out)
    assert payload == {
        "errors": [
            {
                "document_id": "UNKNOWN-001",
                "message": "Impact source references unknown document id `UNKNOWN-001`.",
                "path": None,
                "rule_id": "document.impact.unknown_id",
                "severity": "error",
            }
        ],
        "impacted": [],
        "sources": [],
        "warnings": [],
    }
    assert output.err == ""


def test_impact_usage_errors(capsys):
    assert main(["impact", "--id"]) == 3
    output = capsys.readouterr()
    assert output.out == ""
    assert "Usage: ai-docs impact (--id ID | --changed) [--format json]" in output.err

    assert main(["impact", "--changed", "--format", "yaml"]) == 3
    output = capsys.readouterr()
    assert output.out == ""
    assert "Usage: ai-docs impact (--id ID | --changed) [--format json]" in output.err


def test_impact_changed_uses_modified_document_source(monkeypatch, capsys, tmp_path):
    _write_impact_project(tmp_path)
    _write_document(
        tmp_path / "ai-docs" / "business-rule.md",
        document_id="BR-TEST-001",
        document_type="business_rule",
        related={"acceptance": ["ACC-TEST-001"]},
    )
    _write_document(
        tmp_path / "ai-docs" / "acceptance.md",
        document_id="ACC-TEST-001",
        document_type="acceptance",
    )
    _commit_all(tmp_path)
    (tmp_path / "ai-docs" / "business-rule.md").write_text(
        (tmp_path / "ai-docs" / "business-rule.md").read_text(encoding="utf-8")
        + "\nChanged.\n",
        encoding="utf-8",
    )
    monkeypatch.chdir(tmp_path)

    assert main(["impact", "--changed", "--format", "json"]) == 0

    output = capsys.readouterr()
    payload = json.loads(output.out)
    assert payload["sources"] == [
        {
            "changed_file": "ai-docs/business-rule.md",
            "document_id": "BR-TEST-001",
            "path": "ai-docs/business-rule.md",
            "source": "changed",
            "type": "business_rule",
        }
    ]
    assert [item["document_id"] for item in payload["impacted"]] == ["ACC-TEST-001"]
    assert payload["warnings"] == []


def test_impact_changed_includes_untracked_document(monkeypatch, capsys, tmp_path):
    _write_impact_project(tmp_path)
    _write_document(
        tmp_path / "ai-docs" / "acceptance.md",
        document_id="ACC-TEST-001",
        document_type="acceptance",
    )
    _commit_all(tmp_path)
    _write_document(
        tmp_path / "ai-docs" / "business-rule.md",
        document_id="BR-TEST-001",
        document_type="business_rule",
        related={"acceptance": ["ACC-TEST-001"]},
    )
    monkeypatch.chdir(tmp_path)

    assert main(["impact", "--format", "json", "--changed"]) == 0

    output = capsys.readouterr()
    payload = json.loads(output.out)
    assert payload["sources"][0]["document_id"] == "BR-TEST-001"
    assert payload["sources"][0]["changed_file"] == "ai-docs/business-rule.md"
    assert [item["document_id"] for item in payload["impacted"]] == ["ACC-TEST-001"]


def test_impact_changed_warns_for_non_document_files(monkeypatch, capsys, tmp_path):
    _write_impact_project(tmp_path)
    _commit_all(tmp_path)
    (tmp_path / "README.md").write_text("# Readme\n", encoding="utf-8")
    (tmp_path / "ai-docs" / "note.txt").write_text("note\n", encoding="utf-8")
    monkeypatch.chdir(tmp_path)

    assert main(["impact", "--changed", "--format", "json"]) == 1

    output = capsys.readouterr()
    payload = json.loads(output.out)
    assert payload["sources"] == []
    assert payload["impacted"] == []
    assert payload["warnings"] == [
        {
            "document_id": None,
            "message": (
                "Changed file `README.md` is outside configured documentation roots."
            ),
            "path": "README.md",
            "rule_id": "document.impact.changed_file_outside_docs",
            "severity": "warning",
        },
        {
            "document_id": None,
            "message": "Changed file `ai-docs/note.txt` is not a parsed document.",
            "path": "ai-docs/note.txt",
            "rule_id": "document.impact.changed_file_not_document",
            "severity": "warning",
        },
    ]
    assert payload["errors"] == [
        {
            "document_id": None,
            "message": "Impact analysis did not find changed documentation sources.",
            "path": None,
            "rule_id": "document.impact.no_sources",
            "severity": "error",
        }
    ]


def _write_impact_project(project_root: Path) -> None:
    (project_root / "ai-docs").mkdir()
    (project_root / "ai-docs.config.yaml").write_text(
        """version: 1

project:
  name: impact-test
  documentation_roots:
    - ai-docs
""",
        encoding="utf-8",
    )
    _run_git(project_root, "init")


def _write_document(
    path: Path,
    *,
    document_id: str,
    document_type: str,
    related: dict[str, list[str]] | None = None,
) -> None:
    relationships = {
        "business_rules": [],
        "architecture_decisions": [],
        "contracts": [],
        "modules": [],
        "scenarios": [],
        "acceptance": [],
        "operations": [],
    }
    relationships.update(related or {})
    related_yaml = "\n".join(
        f"  {key}: [{', '.join(values)}]" if values else f"  {key}: []"
        for key, values in relationships.items()
    )
    path.write_text(
        f"""---
id: {document_id}
type: {document_type}
status: draft
title: {document_id} title
summary: {document_id} summary
scope:
  domains: []
  modules: []
  features: []
owners:
  - maintainers
related:
{related_yaml}
ai:
  priority: medium
  load_when: []
  avoid_when: []
  context_role: validation
validation:
  required_checks: []
  last_validated: null
---

# {document_id}
""",
        encoding="utf-8",
    )


def _commit_all(project_root: Path) -> None:
    _run_git(project_root, "add", ".")
    _run_git(
        project_root,
        "-c",
        "user.name=Test User",
        "-c",
        "user.email=test@example.com",
        "commit",
        "-m",
        "Initial commit",
    )


def _run_git(project_root: Path, *args: str) -> None:
    subprocess.run(
        ["git", *args],
        cwd=project_root,
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
