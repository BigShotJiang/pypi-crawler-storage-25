from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path

from ai_docs_toolkit.core.changed_files import (
    ChangedFileIssue,
    read_git_changed_files,
    resolve_changed_document_sources,
)
from ai_docs_toolkit.core import (
    ImpactAnalysisResult,
    ImpactSource,
    ImpactedDocument,
    DocumentRegistry,
    RegistryDocument,
    ToolkitConfig,
    analyze_document_impact,
    build_document_graph,
    build_document_registry,
    load_project_config,
    parse_markdown_file,
    registry_document_from_parsed,
    scan_markdown_files,
)
from ai_docs_toolkit.validation import ValidationMessage

RULE_CHANGED_FILE_NOT_DOCUMENT = "document.impact.changed_file_not_document"
RULE_CHANGED_FILE_OUTSIDE_DOCS = "document.impact.changed_file_outside_docs"
RULE_GIT_CHANGED_FILES_UNAVAILABLE = "document.impact.git_changed_files_unavailable"
RULE_NO_SOURCES = "document.impact.no_sources"


@dataclass(frozen=True)
class ImpactBuildResult:
    exit_code: int
    impact: ImpactAnalysisResult | None
    warnings: tuple[ValidationMessage, ...] = ()
    errors: tuple[ValidationMessage, ...] = ()

    @property
    def ok(self) -> bool:
        return self.exit_code == 0


@dataclass(frozen=True)
class _ProjectImpactContext:
    root: Path
    config: ToolkitConfig
    documents: tuple[RegistryDocument, ...]
    errors: tuple[ValidationMessage, ...]


def impact_project(
    source_ids: tuple[str, ...] | list[str],
    project_root: str | Path = ".",
) -> ImpactBuildResult:
    context_result = _load_project_context(project_root)
    if isinstance(context_result, ImpactBuildResult):
        return context_result

    registry = build_document_registry(context_result.documents)
    errors = [*context_result.errors, *_registry_errors(registry)]
    graph = build_document_graph(registry, project_root=context_result.root)
    impact = analyze_document_impact(graph, source_ids)
    errors.extend(_impact_errors(impact))
    warnings = _impact_warnings(impact)

    return ImpactBuildResult(
        exit_code=0 if not errors else 1,
        impact=impact,
        warnings=warnings,
        errors=tuple(errors),
    )


def impact_changed_project(project_root: str | Path = ".") -> ImpactBuildResult:
    context_result = _load_project_context(project_root)
    if isinstance(context_result, ImpactBuildResult):
        return context_result

    registry = build_document_registry(context_result.documents)
    errors = [*context_result.errors, *_registry_errors(registry)]
    changed_result = _git_changed_files(context_result.root)
    errors.extend(_changed_file_errors(changed_result.issues))

    source_result = resolve_changed_document_sources(
        changed_result.changed_files,
        config=context_result.config,
        registry=registry,
        root=context_result.root,
        outside_docs_rule_id=RULE_CHANGED_FILE_OUTSIDE_DOCS,
        not_document_rule_id=RULE_CHANGED_FILE_NOT_DOCUMENT,
    )
    source_ids = source_result.source_ids
    changed_files_by_id = source_result.changed_files_by_id
    warnings = [*_changed_file_warnings((*changed_result.issues, *source_result.issues))]

    if not source_ids:
        errors.append(
            ValidationMessage(
                rule_id=RULE_NO_SOURCES,
                message="Impact analysis did not find changed documentation sources.",
            )
        )

    graph = build_document_graph(registry, project_root=context_result.root)
    impact = analyze_document_impact(graph, source_ids)
    impact = ImpactAnalysisResult(
        sources=tuple(
            ImpactSource(
                document_id=source.document_id,
                type=source.type,
                path=source.path,
                source="changed",
                changed_file=changed_files_by_id.get(source.document_id),
            )
            for source in impact.sources
        ),
        impacted=impact.impacted,
        issues=impact.issues,
    )
    errors.extend(_impact_errors(impact))
    warnings.extend(_impact_warnings(impact))

    return ImpactBuildResult(
        exit_code=0 if not errors else 1,
        impact=impact,
        warnings=tuple(warnings),
        errors=tuple(errors),
    )


def _load_project_context(project_root: str | Path) -> _ProjectImpactContext | ImpactBuildResult:
    root = Path(project_root).resolve()
    config_result = load_project_config(root)
    if not config_result.ok or config_result.config is None:
        return ImpactBuildResult(
            exit_code=2,
            impact=None,
            errors=tuple(
                ValidationMessage(
                    rule_id=error.code,
                    message=error.message,
                    path=error.path,
                )
                for error in config_result.errors
            ),
        )

    documents: list[RegistryDocument] = []
    errors: list[ValidationMessage] = []
    for path in scan_markdown_files(config_result.config):
        parse_result = parse_markdown_file(path)
        if parse_result.document is None:
            errors.extend(
                ValidationMessage(
                    rule_id=f"frontmatter.{error.code}",
                    message=error.message,
                    path=error.path,
                )
                for error in parse_result.errors
            )
            continue

        documents.append(registry_document_from_parsed(parse_result.document))

    return _ProjectImpactContext(
        root=root,
        config=config_result.config,
        documents=tuple(documents),
        errors=tuple(errors),
    )


def _registry_errors(registry: DocumentRegistry) -> tuple[ValidationMessage, ...]:
    return tuple(
        ValidationMessage(
            rule_id=issue.rule_id,
            message=issue.message,
            path=", ".join(str(path) for path in issue.paths),
            document_id=issue.document_id,
            severity=issue.severity,
        )
        for issue in registry.issues
    )


def _impact_errors(impact: ImpactAnalysisResult) -> tuple[ValidationMessage, ...]:
    return tuple(
        ValidationMessage(
            rule_id=issue.rule_id,
            message=issue.message,
            document_id=issue.document_id,
            severity=issue.severity,
        )
        for issue in impact.issues
        if issue.severity == "error"
    )


def _impact_warnings(impact: ImpactAnalysisResult) -> tuple[ValidationMessage, ...]:
    return tuple(
        ValidationMessage(
            rule_id=issue.rule_id,
            message=issue.message,
            document_id=issue.document_id,
            severity=issue.severity,
        )
        for issue in impact.issues
        if issue.severity != "error"
    )


def _changed_file_errors(issues: tuple[ChangedFileIssue, ...]) -> tuple[ValidationMessage, ...]:
    return tuple(_changed_file_message(issue) for issue in issues if issue.severity == "error")


def _changed_file_warnings(issues: tuple[ChangedFileIssue, ...]) -> tuple[ValidationMessage, ...]:
    return tuple(_changed_file_message(issue) for issue in issues if issue.severity != "error")


def _changed_file_message(issue: ChangedFileIssue) -> ValidationMessage:
    return ValidationMessage(
        rule_id=issue.rule_id,
        message=issue.message,
        path=issue.path,
        document_id=issue.document_id,
        severity=issue.severity,
    )


def _git_changed_files(root: Path):
    return read_git_changed_files(
        root,
        unavailable_rule_id=RULE_GIT_CHANGED_FILES_UNAVAILABLE,
    )


def format_impact_json(result: ImpactBuildResult) -> str:
    impact = result.impact
    payload = {
        "sources": [asdict(source) for source in impact.sources] if impact else [],
        "impacted": [_impacted_payload(document) for document in impact.impacted]
        if impact
        else [],
        "warnings": [_message_payload(message) for message in result.warnings],
    }
    if result.errors:
        payload["errors"] = [_message_payload(message) for message in result.errors]
    return json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True)


def format_impact_human(result: ImpactBuildResult) -> str:
    lines: list[str] = []
    if result.exit_code == 0:
        lines.append("Impact analysis completed.")
    else:
        lines.append("Impact analysis failed.")

    impact = result.impact
    sources = impact.sources if impact is not None else ()
    impacted = impact.impacted if impact is not None else ()
    lines.append(f"Sources: {len(sources)}")
    lines.append(f"Impacted documents: {len(impacted)}")

    if sources:
        lines.append("")
        lines.append("Sources:")
        for source in sources:
            changed = f" changed_file={source.changed_file}" if source.changed_file else ""
            lines.append(
                f"- {source.document_id} ({source.type}) {source.path}"
                f" source={source.source}{changed}"
            )

    if impacted:
        direct = tuple(document for document in impacted if document.impact == "direct")
        transitive = tuple(document for document in impacted if document.impact == "transitive")
        _append_impacted_group(lines, "Direct impact", direct)
        _append_impacted_group(lines, "Transitive impact", transitive)

    if result.warnings:
        lines.append("")
        lines.append("Warnings:")
        for warning in result.warnings:
            lines.append(f"- {_message_line(warning)}")

    if result.errors:
        lines.append("")
        lines.append("Errors:")
        for error in result.errors:
            lines.append(f"- {_message_line(error)}")

    return "\n".join(lines)


def _append_impacted_group(
    lines: list[str],
    title: str,
    documents: tuple[ImpactedDocument, ...],
) -> None:
    if not documents:
        return

    lines.append("")
    lines.append(f"{title}:")
    for document in documents:
        lines.append(
            f"- {document.document_id} ({document.type}) distance={document.distance} "
            f"{document.path}"
        )
        for reason in document.reasons:
            via = f" via {reason.via}" if reason.via else ""
            lines.append(
                f"  reason: {reason.source}{via} {reason.direction} "
                f"related.{reason.relationship}: {reason.message}"
            )


def _impacted_payload(document: ImpactedDocument) -> dict[str, object]:
    payload = asdict(document)
    payload["reasons"] = [asdict(reason) for reason in document.reasons]
    return payload


def _message_payload(message: ValidationMessage) -> dict[str, str | None]:
    return {
        "path": message.path,
        "document_id": message.document_id,
        "rule_id": message.rule_id,
        "severity": message.severity,
        "message": message.message,
    }


def _message_line(message: ValidationMessage) -> str:
    path = f"{message.path} " if message.path else ""
    document = f"[{message.document_id}] " if message.document_id else ""
    return f"{path}{document}{message.rule_id}: {message.message}"
