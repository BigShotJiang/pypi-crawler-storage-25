from ai_docs_toolkit.cli import main


raise SystemExit(main())
