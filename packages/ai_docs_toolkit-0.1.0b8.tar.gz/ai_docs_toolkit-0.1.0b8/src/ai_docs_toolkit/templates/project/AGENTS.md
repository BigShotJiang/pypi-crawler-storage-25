# AGENTS.md

## Purpose

This project uses AI-oriented documentation as implementation context.

Agents must treat documentation as part of the engineering process, not as a secondary artifact.

## Source Of Truth

Before changing behavior, read the relevant documentation in the configured documentation roots.

If implementation and documentation conflict:
- stop and record the conflict;
- update the source-of-truth document or the implementation in the same change unit;
- do not let code silently become the only source of meaning.

## Change Workflow

Before selecting project-local skills, read `.ai-docs/skills/index.md` when it exists.
Use the selected skill documents from that index before loading full planning references.

Full documents such as `.ai-docs/workflows/plan-stage-workflow.md` and `.ai-docs/reference/planning-document-model.md` are source-of-truth references. Load them when compact skills are insufficient or the selected task requires them; do not inject them into every request by default.

For every non-trivial change:
- identify source documents;
- run `ai-docs context` by task, module, feature or changed documents before implementation;
- perform readiness review and ask blocking clarification questions before editing implementation artifacts;
- update affected documentation together with or before implementation;
- keep front matter relationships current;
- update test case documents and executable tests when stable behavior changes;
- run available validation checks;
- record validation evidence, closing observations and follow-ups before closing the task.

## Validation

Before closure, run:

```bash
ai-docs validate
```

For machine-readable CI or automation output:

```bash
ai-docs validate --json
```

If automated validation is unavailable, perform manual checks:
- Markdown files have YAML front matter;
- `id`, `type`, `status`, `scope`, `owners`, `related`, `ai` and `validation` are present where required;
- links and relationships point to existing documents when possible;
- acceptance criteria match the changed behavior.

## Toolkit Runtime

If the `ai-docs` CLI is unavailable, install or update the package in an available Python environment:

```bash
python -m pip install --upgrade ai-docs-toolkit
ai-docs --version
```

If the project pins a toolkit version, use the pinned version instead of an unpinned upgrade.
Package-local install/update guidance lives in `ai_docs_toolkit/docs/agent-installation.md` inside the installed package.

## Task Closure

Before moving a task to `done`:
- confirm there are no blocking issues;
- record executed commands and results in the task record;
- check language policy for changed documentation;
- record closing observations or explicitly state that there are none;
- assign a disposition to every observation;
- for each observation, include impact, action taken, rationale and follow-up decision;
- report each observation to the user with disposition, rationale and follow-up decision, or explicitly state `Closing observations: None.`;
- record follow-ups when work is intentionally deferred.

Do not proceed to implementation when a task, stage or plan contains unresolved blocking clarification questions requiring user confirmation.
