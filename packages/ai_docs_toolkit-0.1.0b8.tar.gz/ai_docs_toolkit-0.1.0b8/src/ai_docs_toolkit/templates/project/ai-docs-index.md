---
id: IDX-PROJECT-001
type: index
status: draft
title: Project Documentation Index
summary: Entry points and loading guidance for project documentation.
scope:
  domains: []
  modules: []
  features: []
owners:
  - owner
related:
  business_rules: []
  architecture_decisions: []
  contracts: []
  modules: []
  scenarios: []
  acceptance: []
  operations: []
ai:
  priority: high
  load_when: []
  avoid_when: []
  context_role: navigation
validation:
  required_checks: []
  last_validated: null
---

# Project Documentation Index

## Scope

## Entry Points

## Documents

## Loading Guidance
