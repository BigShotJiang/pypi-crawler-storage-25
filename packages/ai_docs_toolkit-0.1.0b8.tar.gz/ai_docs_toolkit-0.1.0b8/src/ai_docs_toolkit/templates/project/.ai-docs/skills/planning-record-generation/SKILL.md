---
name: planning-record-generation
description: Use when creating or updating incoming requests, plans, stages, implementation tasks, standalone tasks, task ids, planning layout, or planning front matter in an AI Docs Toolkit project.
---

# Planning Record Generation

Use this skill when creating or modifying planning records.

## Incoming Requests

- Store raw incoming requests in `docs/requests/`.
- Incoming request examples are intake evidence, not accepted design decisions.
- Prefer existing toolkit rules when a request conflicts with accepted workflow, architecture, schema, template or validation rules.
- Record explicit decision points for proposed rule changes.

## Accepted Layout

Use the accepted planning layout by default:

```text
ai-docs/planning/<sortable-plan-slug>/
  plan.md
  stage-NNN-<stage-slug>/
    stage.md
    task-N-<task-slug>.md
ai-docs/planning/tasks/YYYY-MM/
  task-NNN-<task-slug>.md
```

Rules:
- use lowercase `plan.md` and `stage.md`;
- use `stage-NNN-<stage-slug>/`, not `phase-NNN-<stage-slug>/`;
- keep task filenames ordered by stage-local execution order;
- do not put global `TASK-NNNNNN` ids into task filenames as the sort key;
- keep standalone tasks in the monthly `ai-docs/planning/tasks/YYYY-MM/` directory;
- use `task-NNN-<task-slug>.md` for standalone task filenames, where `NNN` is unique within the month.

## Front Matter

- Plans use `type: plan`.
- Stages use `type: plan_stage`.
- Executable stage tasks use `type: implementation_task`.
- Keep the same `scope.plan` across plan, stage and tasks.
- Stage tasks include `scope.stage` and `scope.task_order`.
- Allocate global task ids through `ai-docs/planning/task-registry.md`.
- Preserve request provenance with `source_request_id` or `source_request_ids`.

## References

Load full references only when needed:
- `.ai-docs/reference/planning-document-model.md`
- `.ai-docs/workflows/plan-stage-workflow.md`
