---
id: WF-TOOLKIT-MIGRATION-001
type: workflow
status: draft
scope:
  modules:
    - migration
    - init
    - doctor
    - planning
owners:
  - maintainers
related:
  reference:
    - REF-TOOLKIT-MIGRATION-MECHANISM-001
    - REF-INIT-COMMAND-CONTRACT-001
    - REF-PLANNING-DOCUMENT-MODEL-001
  architecture:
    - ARCH-CLI-001
ai:
  priority: high
  load_when:
    - topic: migration
    - topic: toolkit-upgrade
    - topic: consumer-migration
---

# Toolkit Migration Workflow

## Purpose

This workflow tells agents how to migrate a consumer project after an `ai-docs-toolkit` upgrade.

It is operational guidance, not an apply-mode migration command. Agents may edit project-owned files only when the user requested migration work and the affected files are named by the migration note, dry-run output or planning task.

## Lifecycle

Migration work follows:

```text
detect -> plan -> review -> apply manually -> validate -> record
```

## Detect

Run read-only checks first:

```bash
ai-docs doctor
ai-docs init --check
ai-docs planning migrate-layout --dry-run
```

Rules:
- `doctor` reports drift and recommended checks;
- `init --check` reports toolkit-managed files that differ from the installed package;
- `planning migrate-layout --dry-run` previews planning layout moves only;
- none of these commands may rewrite project-owned documentation.

## Plan

Before editing files, identify:
- source and target toolkit versions;
- release migration note, if one exists;
- files that are toolkit-managed versus project-owned;
- planning records that will receive validation evidence;
- commands that must be run before and after manual edits.

If a release migration note is missing for a release that changed installed templates, validation rules, workflows, schemas, CLI behavior, document layout or front matter contracts, stop and ask for release guidance.

## Review

Stop for human review when:
- a project-owned file must be rewritten without a deterministic instruction;
- a target path already exists;
- `AGENTS.md` or another locally customized policy file conflicts with packaged guidance;
- a planning lifecycle state would need to be changed without a task record;
- validation reports errors outside the migration scope.

## Apply Manually

Apply only the reviewed manual steps.

Rules:
- preserve document ids, task ids and aliases;
- update `task_index.path` only when the task record path changed;
- keep durable task references as `TASK-NNNNNN` ids;
- do not rewrite completed historical records only to modernize old paths;
- do not run broad apply-mode migrations unless the release note names a specific apply command.

## Validate

After manual edits, run:

```bash
ai-docs validate
ai-docs doctor
```

Run targeted tests when the migration changed executable toolkit code, templates, schemas or validation behavior.

## Record

Record migration evidence in the relevant planning task, release note or project migration record.

Evidence must include:
- commands run;
- result for each command;
- files changed;
- skipped steps and rationale;
- follow-up tasks for deferred conflicts or manual decisions.
