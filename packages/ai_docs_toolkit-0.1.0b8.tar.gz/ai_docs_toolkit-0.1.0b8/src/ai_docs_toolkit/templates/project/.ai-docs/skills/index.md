---
id: REF-SKILL-ROUTING-INDEX-001
type: reference
status: draft
scope:
  modules:
    - skills
    - onboarding
    - toolkit
owners:
  - maintainers
related:
  workflows:
    - WF-PLAN-STAGE-001
  reference:
    - REF-PLANNING-DOCUMENT-MODEL-001
ai:
  priority: high
  load_when:
    - topic: skills
    - topic: routing
    - topic: agent-intake
---

# Skill Routing Index

Use this index before task execution to select project-local skills.

- Planning execution from `ai-docs/planning/**`, readiness review, lifecycle changes or closure:
  `.ai-docs/skills/planning-task-execution/SKILL.md`
- Planning record creation or updates, task ids, layout or front matter:
  `.ai-docs/skills/planning-record-generation/SKILL.md`
- Toolkit-provided workflow, schema, template, validation rule or skill files:
  `.ai-docs/skills/toolkit-consumer-policy/SKILL.md`
- Release, publish, tag, version or post-publication verification work; this is the primary release skill:
  `.ai-docs/skills/release-publication/SKILL.md`
- Python package release to PyPI with tag-driven CI, when repository policy confirms this stack:
  `.ai-docs/examples/skills/pypi-package-release/SKILL.md`

The PyPI package release skill is an example specialization. Do not treat it as the default active release policy for every consumer project.
