---
name: pypi-package-release
description: Example stack-specific release skill for Python packages published to PyPI with Git tag driven CI. Use as a model for toolkit's own release process, not as the default release skill for all toolkit consumers.
---

# PyPI Package Release Example

This is an example specialization of the generic `release-publication` skill for Python packages.

Use it only when the repository policy confirms:

- Python package metadata lives in `pyproject.toml`;
- release artifacts are source distributions and wheels;
- publication target is Public PyPI or TestPyPI;
- CI publication is driven by Git release tags.

## Procedure

1. Read the repository release policy and previous release task.
2. Check Public PyPI for existing versions.
3. Check remote release tags.
4. Choose the next version and tag from policy.
5. Update `pyproject.toml` and any separate runtime `__version__`.
6. Run the tag/version guard.
7. Run repository validation and tests.
8. Build with `python -m build --sdist --wheel`.
9. Install the built wheel into an isolated target and verify the package version.
10. Commit release preparation changes.
11. Push the main branch.
12. Push the release tag.
13. Wait for CI publication.
14. Verify exact install from PyPI with `pip`, and with `pipx` or `uvx` when those tools are available.
15. Report agent-ready migration instructions for consumers upgrading from the previous published version, or explicitly state that no migration is required.
16. Use `.ai-docs/templates/release/migration-note.md` when the release needs a durable consumer migration artifact.

## Migration Instructions

This stack-specific release flow inherits the generic `release-publication` migration instruction rule.

For each PyPI release, include a consumer-facing agent instruction with:

- previous and target package versions;
- package upgrade commands for `pip`, `pipx` and `uvx` when relevant;
- required toolkit commands after upgrade;
- manual migration steps when the package has no apply-mode migration command;
- files, ids, links or indexes that must be preserved or updated;
- validation commands and expected results;
- known limitations such as unavailable `uvx`, PyPI propagation lag or manual-only migrations.

If the package release does not require migration, state that explicitly and provide only post-upgrade verification commands.

## Toolkit Example Defaults

- Package name: `ai-docs-toolkit`
- Runtime module: `ai_docs_toolkit`
- Beta tag format: `vX.Y.Z-beta-NN`
- Beta package version mapping: `vX.Y.Z-beta-NN` -> `X.Y.ZbN`
- Release pipeline: GitLab tag pipeline
- Publication mechanism: PyPI Trusted Publishing

See `.ai-docs/examples/templates/pypi-package-release/` for example snippets.
