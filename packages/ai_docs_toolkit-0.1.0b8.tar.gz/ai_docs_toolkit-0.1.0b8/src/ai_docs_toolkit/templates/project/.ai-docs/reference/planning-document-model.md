---
id: REF-PLANNING-DOCUMENT-MODEL-001
type: reference
status: draft
scope:
  modules:
    - planning
    - documentation
    - toolkit
owners:
  - maintainers
related:
  concepts:
    - docs/concepts/documentation-as-interface.md
    - docs/concepts/document-taxonomy.md
    - docs/concepts/change-cascade.md
    - docs/concepts/planning-as-execution-interface.md
  planning:
    - PLAN-MVP-001
    - PLAN-BACKLOG-001
    - REF-TASK-REGISTRY-001
  workflows:
    - WF-PLAN-STAGE-001
  reference:
    - docs/reference/source-of-truth-model.md
    - docs/reference/incoming-request-model.md
ai:
  priority: high
  load_when:
    - topic: planning
    - topic: document-model
    - topic: implementation-task
---

# Planning Document Model

## Purpose

Этот документ формализует модель planning-документов в AI Docs Toolkit.

Active planning-документы не должны быть единым backlog-файлом без структуры. Они являются частью документационной системы и должны участвовать в:
- context loading;
- change cascade;
- document graph;
- impact analysis;
- validation;
- review.

Модель вводится поэтапно. Целевое состояние - отдельная папка на каждый plan, внутри которой stages and implementation tasks имеют собственный YAML front matter, плюс отдельное место для standalone tasks when a full plan is unnecessary.

Completed plans and tasks are work history. They should not remain in the active documentation graph forever unless they still define current constraints.

---

# Document Types

## `plan`

Plan описывает направление развития, порядок этапов и границы roadmap.

Plan отвечает на вопросы:
- какую цель преследует набор этапов;
- какие stages входят в roadmap;
- в каком порядке stages обычно выполняются;
- какие non-goals действуют для roadmap;
- какие документы являются entry points для планирования.

Plan не должен хранить детальные task records, если для них уже есть отдельные documents.

Примеры:
- `ai-docs/planning/2026-05-13-mvp/plan.md`
- `ai-docs/planning/2026-05-15-post-mvp-hardening/plan.md`

## `plan_stage`

Plan stage описывает крупный этап реализации.

Plan stage отвечает на вопросы:
- какой outcome должен быть достигнут;
- какой scope входит в stage;
- какие acceptance criteria закрывают stage;
- какие implementation tasks относятся к stage;
- какие tasks обязательны, deferred, blocked or archived.

Plan stage может быть отдельным документом, когда stage становится достаточно большим.
Future stages may be intentionally high-level until they become the next active stage.
Detailed implementation tasks should be created during stage preparation, not necessarily when the roadmap is first written.
When a stage is decomposed into ordered implementation tasks, every ordered task must have its own task record file.
A stage must not keep planned task work only as a text-only task list once that work is part of the stage task order.
This keeps every planned task addressable by global task id and available for follow-ups, readiness review and lookup.

Пример размещения:
- `ai-docs/planning/2026-05-13-mvp/stage-1-methodology-baseline/stage.md`
- `ai-docs/planning/2026-05-13-mvp/stage-2-schema-template-mvp/stage.md`

## `implementation_task`

Implementation task описывает минимальную executable task внутри plan stage.
В целевой модели это task with `placement: plan_stage`.

Implementation task отвечает на вопросы:
- что именно должно измениться;
- какие source documents задают требования;
- какие документы и артефакты затрагиваются;
- какие acceptance checks должны пройти;
- какой cascade impact ожидается;
- какие commits относятся к выполнению задачи;
- какой результат получен;
- какие follow-ups остались.

Implementation task должна иметь собственный front matter, если она:
- меняет несколько документов;
- имеет самостоятельный lifecycle;
- может быть выполнена отдельным коммитом;
- должна быть доступна agent retrieval;
- участвует в impact analysis.

Пример размещения:
- `ai-docs/planning/2026-05-13-mvp/stage-1-methodology-baseline/task-2-replace-readme-with-product-readme.md`
- `ai-docs/planning/2026-05-13-mvp/stage-1-methodology-baseline/task-8-create-source-of-truth-model.md`

## `standalone_task`

Standalone task описывает executable change unit, который не требует отдельного plan/stage context.
В целевой модели это task with `placement: standalone`.

Standalone task отвечает на те же task-level вопросы, что и `implementation_task`:
- что именно должно измениться;
- какие source documents задают требования;
- какие readiness questions нужно решить;
- какие проверки и validation evidence нужны;
- какие closing observations and follow-ups остались.

Standalone task достаточно, когда:
- задача мала и не зависит от stage ordering;
- результат можно проверить одной change unit;
- task не создаёт roadmap direction or multiple related tasks;
- нет plan-level or stage-level decisions, которые нужно согласовать заранее;
- work history нужен, но полноценный plan/stage был бы лишним overhead.

Standalone task нужно promote into plan/stage or mini-plan, когда:
- задача распадается на несколько связанных tasks;
- появляется ordering, dependencies or staged delivery;
- решение влияет на roadmap, architecture direction or source-of-truth policy;
- требуется stage-level acceptance criteria;
- task начинает блокировать or coordinate broader work.

Пример размещения:
- `ai-docs/planning/tasks/2026-05/task-001-update-session-compaction-guide.md`

## `execution_record`

Execution record describes completed work after it no longer needs to participate in active planning.

Execution records may live:
- in an external task tracker;
- in an external file archive;
- in `ai-docs/planning/archive/` when no external tracker or archive is configured.

Execution record is not a source of truth for current system behavior by default.
Long-lived knowledge discovered during execution must be extracted into current documentation before the plan is closed.

## `request`

Request records describe incoming feedback before it becomes planning work.

Request отвечает на вопросы:
- откуда пришёл запрос;
- какой тип входящего сигнала получен: bug, feature, docs gap, support question or contribution proposal;
- какую triage-классификацию получил запрос;
- был ли запрос accepted, rejected, answered, duplicated or converted;
- в какой task, stage or plan он был converted, если работа принята.

Request не является executable task.
Request ids use a dedicated `REQ-NNNNNN` namespace and do not consume global task ids.

Подробная модель описана в `docs/reference/incoming-request-model.md`.

---

# Unified Task Model

`task` is the conceptual work item across backlog, plan-stage execution and standalone work.
Backlog records, implementation tasks and standalone tasks are placements of one task concept, not separate work identities.

Task identity answers "what work is this?"
Task placement answers "where is this work currently managed?"
Task status answers "what is its lifecycle state?"

Rules:
- one task should have one stable task identity even when it moves between backlog, plan, plan stage, standalone execution or archive;
- changing placement must preserve problem, expected result, decisions, validation evidence and follow-up handoff context;
- incoming requests are intake artifacts and must be triaged before they become tasks;
- backlog is a placement for deferred or unscheduled tasks, not a different kind of work;
- plan-stage tasks are executable tasks selected into a stage and ordered by that stage;
- standalone tasks are executable tasks without a parent stage;
- when a backlog task expands into a plan or plan stage, the backlog task is not the resulting plan/stage identity; the target plan or stage records the source task in `origin_task_id`;
- completed, cancelled, exported or archived tasks remain work history unless durable knowledge is extracted into current source-of-truth documentation.

Non-document references in planning records:
- use stable document ids for source documents that have front matter ids;
- use repository-relative paths for schemas, templates, generated assets, directories and other files that are not documentation records;
- do not create artificial document ids for non-document files only to place them in `related`;
- use `related.result_documents` or body links for changed non-document paths when a task needs execution traceability;
- if a non-document file becomes a source of truth, add a Markdown reference or architecture document that describes the contract and link to that document id.

## Task Placements

Target placements:
- `backlog` - unscheduled or deferred work kept for later selection;
- `plan` - work associated with a plan but not yet decomposed into a stage task;
- `plan_stage` - executable work inside an active or planned stage;
- `standalone` - executable work outside a plan/stage when a full plan would be unnecessary overhead;
- `archive` - completed, cancelled, exported or otherwise historical work no longer managed as active planning state.

Placement mapping:
- `backlog_item` documents map to `placement: backlog`;
- `implementation_task` documents map to `placement: plan_stage`;
- `standalone_task` documents map to `placement: standalone`;
- `execution_record` documents map to `placement: archive`.

Task records use global `TASK-NNNNNN` ids as primary ids.

## Task Status Groups

Task status is shared across placements, but not every status is meaningful in every placement.

Primary execution lifecycle:

```text
planned
  -> readiness_review
    -> ready
      -> in_progress
        -> closure_review
          -> done
```

Backlog-oriented statuses:
- `open` - task is known but not scheduled for execution;
- `deferred` - task is intentionally postponed;
- `rejected` - task will not be done in the current product direction.

Execution lifecycle statuses:
- `planned` - task is selected into an executable context, but readiness has not been reviewed yet;
- `readiness_review` - task is being checked for missing decisions, assumptions and clarification questions;
- `ready` - task has no unresolved blocking clarification questions and can move to active work;
- `in_progress` - task is being executed;
- `closure_review` - work and validation are complete enough to review residual issues, observations and follow-ups before closing;
- `done` - acceptance checks are complete.

Terminal or side statuses:
- `cancelled` - task was intentionally stopped after being created or selected, with rationale;
- `blocked` - task cannot advance because of an external blocker or missing upstream artifact;
- `expanded` - task was intentionally expanded into a plan, stage or multiple tasks and should no longer be executed one-to-one;
- `exported` - task record was moved or represented in an external tracker or archive;
- `archived` - task record is preserved as local history and excluded from default active retrieval;
- `deprecated` - task record should no longer be used as current planning input.

Rules:
- `open` belongs to backlog placement and is not an execution-ready state;
- `planned` means the task has been selected into an executable context or plan/stage decomposition;
- `deferred` can apply to backlog or execution contexts when rationale is recorded;
- `cancelled` requires rationale and should not be used for normal backlog postponement;
- `expanded` requires a target plan, stage or task handoff so the original work is traceable;
- when a backlog task expands into a plan or plan stage, the target `plan` or `plan_stage` document must record `origin_task_id: TASK-NNNNNN` and the original backlog task record is removed after its context is copied;
- `done`, `cancelled`, `exported` and `archived` are not active execution states.

## Repository-Wide Task Identity

Current task records use global `TASK-NNNNNN` primary ids.
Previous repository-local `BLG-*` and contextual `TASK-*` ids are historical only and are not part of current lookup metadata.
Git history remains the traceability source for those old ids.

Rules:
- `type: implementation_task` remains valid for plan-stage executable tasks;
- `type: standalone_task` remains valid for standalone executable tasks;
- `type: backlog_item` remains valid for backlog placement records;
- existing `task_order` remains stage-local ordering and is not a global task identifier;
- validation must not reject completed historical records solely because they omit newer optional placement fields unless a strict migration task brings them into scope.

## Numeric Document ID And Alias Model

Numeric document ids are the target canonical id model for durable repository documents.
Descriptive ids remain supported through aliases during migration.

Target id examples:
- `REQ-000005` for incoming requests;
- `TASK-000135` for tasks;
- `PLAN-000003` for plans;
- `STAGE-000014` for globally identified stages;
- `REF-000021` for reference documents;
- `ARCH-000004` for architecture documents;
- `WF-000002` for workflows;
- `TC-000031` for test cases.

Alias migration shape:

```yaml
id: PLAN-000003
aliases:
  - PLAN-CONSUMER-PLANNING-WORKFLOW-DISTRIBUTION-001
```

Rules:
- primary `id` is the canonical identity;
- `aliases` preserve older descriptive ids and compatibility ids;
- `aliases` must not collide with any primary `id`;
- one alias must resolve to at most one document;
- relationship validation and `ai-docs file --id` resolve both primary ids and aliases;
- migrations that change a primary id must add the previous id to `aliases` unless an explicit breaking migration says otherwise;
- path, slug and title are navigation metadata, not durable identity.

Stage numeric shorthand:
- global stage ids may use `STAGE-NNNNNN`;
- `ai-docs file --plan 3 --stage 2` treats `2` as stage order inside `PLAN-000003`, not as a global stage id;
- stage records should move toward explicit parent references such as `scope.plan_id: PLAN-000003` and order fields such as `scope.stage_order: 2` when a numeric id migration is applied.

## Global Task ID And Lookup Contract

Global task id is the stable identifier for a task across backlog, plan, plan stage, standalone and archive placements.
It is separate from stage-local order.

Target global task id format:
- `TASK-NNNNNN`

Rules:
- `TASK` is the stable global task prefix;
- `NNNNNN` is a zero-padded decimal number;
- the numeric part is repository-global, not plan-local or stage-local;
- ids are allocated monotonically and never reused;
- ids remain stable when a task changes placement;
- ids remain stable when a task is cancelled, deferred, done, exported or archived;
- when a task is expanded into multiple tasks, the original task handoff remains traceable and each new target task receives its own id;
- when a backlog task is expanded into a plan or plan stage, the source task id is recorded as target `origin_task_id`, the source task record is removed after context copy, and child executable tasks created inside the target receive new global task ids.

Allocation ownership:
- `ai-docs/planning/task-registry.md` owns the global task id sequence;
- `sequence.last_number` records the last allocated global task number;
- allocating a new global task id requires incrementing `sequence.last_number`;
- allocation should happen before creating a new task record in any placement;
- if allocation tooling is unavailable, humans and agents update the registry manually in the same change unit that creates the task.

Stage-local fields:
- `scope.task_order` remains stage-local ordering and is not a global id;
- filenames like `task-3-define-global-task-id-and-lookup-contract.md` remain human navigation and ordering aids;
- task relationships should use global task ids when the target is a task record;
- path references remain valid for human navigation and historical traceability, but they are not the stable task identity.

Task location index:
- `ai-docs/planning/task-registry.md` may contain `task_index` entries mapping stable task ids to current repository paths;
- each `task_index` entry uses `id` and `path`;
- `id` is the stable task identity and must match a real task record front matter `id`;
- `path` is the current file location and may change during layout migrations;
- `ai-docs file --task 133` resolves a task number or task id to the current file path;
- `ai-docs file --request 5` resolves request shorthand to `REQ-000005`;
- `ai-docs file --plan 3` resolves plan shorthand to `PLAN-000003`;
- `ai-docs file --plan 3 --stage 2` resolves stage order `2` inside `PLAN-000003`;
- `ai-docs file --id ID` resolves any exact front matter id;
- migration commands should update `path` mappings when moving task files instead of rewriting every durable task relationship;
- `ai-docs validate` reports unknown indexed task ids and indexed path mismatches.

Lookup by task id:
- resolves a task id to the current task record regardless of placement;
- must support active backlog, plan-stage, standalone and archive placements;
- should return at most one active record for a given id;
- must report ambiguity when duplicate active ids exist;
- if no active primary task record exists, may resolve the id through a plan or plan stage with matching `origin_task_id`;
- `origin_task_id` is a traceability pointer, not a primary id of the target plan or stage.

Lookup result should include:
- task id;
- current path when the task is stored in repository documentation;
- placement;
- status;
- title;
- expansion, export or archive target when available.

Origin task lookup should include:
- the source task id;
- target plan or stage path;
- target document id;
- target document status;
- note that the source task was expanded and removed from active backlog by default.

Validation expectations:
- duplicate active global task ids matching `TASK-NNNNNN` should produce a stable validation issue;
- active executable task records should define `scope.placement`;
- `scope.placement`, when present on executable task records, must be one of the target placements;
- placement-specific required scope fields should be validated when `scope.placement` is present;
- `## Readiness Proposals` should use documented dispositions when present on active executable task records.

## Migration And Compatibility Path

The repository has migrated task identity to global task ids.
Current task records should use `TASK-NNNNNN` as primary ids.
Old repository-local ids are retained only in Git history, not in current front matter.

Migration rules for future work:
- new backlog, plan-stage and standalone task records receive a global task id from `ai-docs/planning/task-registry.md`;
- when a task moves between placements, preserve its global task id;
- when a task is expanded into multiple executable tasks, keep the source handoff traceable and allocate new global ids for new target tasks;
- when a backlog task is expanded into a plan or plan stage, copy the source context to the target, add `origin_task_id: TASK-NNNNNN`, remove the backlog task from the active backlog index and delete the source backlog task file;
- completed records should not be renumbered again unless a dedicated migration task updates references and records the rationale.

`scope.placement` requirement timing:
- new task records should include `scope.placement`;
- validation requires `scope.placement` for active executable tasks;
- completed, archived, exported and deprecated work history may remain exempt from placement backfill unless a project explicitly chooses full historical normalization.

---

# Recommended Directory Layout

```text
ai-docs/planning/
  backlog.md
  task-registry.md
  backlog/
    blg-NNN-<backlog-item-slug>.md

  tasks/
    2026-05/
      task-001-update-session-compaction-guide.md

  <sortable-plan-slug>/
    plan.md

    stage-1-methodology-baseline/
      stage.md
      task-1-define-plan-stage-workflow.md
      task-2-replace-readme-with-product-readme.md
      task-3-formalize-planning-document-model.md
      task-4-implement-plan-directory-structure.md
      task-5-introduce-work-history-policy.md
      task-6-add-planning-as-execution-interface-concept.md
      task-7-define-task-readiness-review.md
      task-8-create-source-of-truth-model.md
      task-9-renumber-mvp-stages-from-one.md

    stage-2-schema-template-mvp/
      stage.md
      task-1-define-document-type-reference.md
      task-2-create-common-frontmatter-schema.md
      task-3-create-type-specific-schemas.md
      task-4-create-markdown-document-templates.md
      task-5-create-project-template.md
      task-6-add-minimal-project-example.md

        stage-3-validation-cli-mvp/
          stage.md
          task-1-define-cli-implementation-baseline.md
          task-2-implement-markdown-frontmatter-parser.md
          task-3-implement-config-loader-and-document-scanner.md
          task-4-implement-document-registry.md
          task-5-define-task-test-planning-and-validation.md
          task-6-define-test-case-documentation-model.md
          task-7-implement-schema-validation.md
          task-8-add-task-closure-review-gate.md
          task-9-resolve-closing-observation-disposition.md
          task-10-implement-relationship-and-section-validation.md
          task-11-implement-validate-cli-human-output.md
          task-12-implement-validate-json-output-and-fixtures.md
```

`ai-docs/planning/<sortable-plan-slug>/plan.md` is the plan entry point.
`ai-docs/planning/<sortable-plan-slug>/<stage-slug>/stage.md` contains stage-level scope and acceptance.
`ai-docs/planning/<sortable-plan-slug>/<stage-slug>/task-N-<task-slug>.md` contains executable change units.
`ai-docs/planning/tasks/YYYY-MM/task-NNN-<task-slug>.md` contains standalone executable change units.

Generated stage directory names use:
- `stage-NNN-<stage-slug>` for new planning records.

Rules:
- `NNN` is the stage-local order inside the plan directory;
- existing `phase-NNN-...` directories are legacy placement and should be migrated by a dedicated migration task when practical;
- do not introduce shared `stages/` or `tasks/` directories inside a plan directory;
- keep plan and stage document filenames lowercase: `plan.md` and `stage.md`;
- keep stage task filenames ordered by stage-local execution order: `task-N-<task-slug>.md`.

Plan directory names should include a sortable prefix when a new plan is created.
Recommended formats:
- date prefix: `YYYY-MM-DD-<plan-slug>`;
- numeric sequence prefix: `NNN-<plan-slug>`.

Rules:
- use a date prefix when plan start date is the most useful ordering signal;
- use a numeric sequence prefix when plans are maintained as a controlled roadmap sequence;
- keep the suffix human-readable and stable after the plan starts;
- do not rename completed plan directories only to change sorting unless a dedicated migration task handles all references.

---

# Relationship Model

Planning documents should form an explicit chain:

```text
plan
  -> stage directory
    -> plan_stage
      -> numbered implementation_task
      -> affected source documents
      -> changed artifacts
```

Recommended relations:
- plan lists related plan stages;
- plan stage lists related implementation tasks;
- implementation task lists source documents;
- standalone task lists source documents and may link to related plans or backlog tasks when useful;
- task registry owns global task id allocation and may be linked by tasks that define or consume task id rules;
- implementation task lists affected documents in cascade impact;
- implementation task lists execution commits when they are known;
- completed task references result documents where useful.
- task filename order uses `task-N-<slug>.md`, where `N` is unique within the stage directory.
- standalone task filename order uses `task-NNN-<slug>.md`, where `NNN` is unique in the monthly standalone task directory.

Task filename rules:
- stage task filenames must be sorted by stage-local execution order, not by global task id;
- global `TASK-NNNNNN` ids belong in front matter and references, not as the leading filename order key for stage tasks;
- when planned tasks are inserted before other incomplete tasks, later incomplete `task-N-*` filenames and `scope.task_order` values may be renumbered in the same planning change unit;
- completed task filenames should not be renumbered unless a dedicated migration task updates references and records rationale.

Relationship groups have separate meanings:
- `plans` links the parent or related plan record;
- `stages` links the parent or related stage record;
- `tasks` links child or related executable task records;
- `requests` links incoming request records that motivated or duplicate the current record;
- `backlog` links motivating backlog tasks or follow-up backlog targets;
- `source_documents` links normative inputs used for readiness, implementation and validation;
- `result_documents` links durable documents produced or materially changed by completed work;
- `concepts`, `architecture`, `workflows`, `reference`, `test_cases` and similar layer groups link documentation layers, not execution order.

Rules:
- do not put source documents in `tasks`, `plans` or `stages`;
- do not put execution hierarchy links in `source_documents`;
- use `backlog` only for backlog tasks, not for active implementation tasks;
- use `requests` only for request records, not for backlog tasks or executable tasks;
- use `source_documents` for documents that define constraints or expected behavior for the work;
- use `result_documents` for outputs only after they exist or when the task intentionally creates them;
- use task ids for durable task-to-task references;
- use document ids when the relationship must become a graph edge;
- use paths when the relationship is primarily human navigation or historical traceability.

Until relationship schemas exist, these links can be represented with existing `related` groups and explicit Markdown sections.
Path-based planning links remain valid for active work, but they are not stable identities or resolved graph edges unless they match document ids.

---

# Progressive Planning Rules

Plan documents may describe future stages without detailed tasks.

Rules:
- `plan.md` defines roadmap-level direction, stage order and non-goals;
- `stage.md` may initially contain only outcome, scope and acceptance criteria;
- `stage.md` should contain stage readiness and task decomposition sections before the stage starts;
- detailed `implementation_task` documents are created when the stage is being prepared for execution;
- before a stage moves to `in_progress`, it must have an explicit ordered task list or an explicit decision to defer task creation;
- stage-level blocking questions are handled in the stage readiness section;
- task decomposition usually happens in `stage.md`;
- create a separate decomposition task only when decomposition itself is a standalone work unit;
- do not create detailed tasks for distant future stages unless there is enough context to make them useful;
- inserting a new stage before incomplete stages triggers downstream readiness invalidation review.

Downstream readiness invalidation rules:
- completed stages are not reopened unless a dedicated correction or migration task explicitly changes their history;
- downstream `planned` stages remain `planned` and should record the new dependency when relevant;
- downstream stages in `readiness_review` or `ready` return to `planned` unless the plan records an explicit decision that the inserted stage cannot affect their scope, source documents, readiness questions, dependencies or task decomposition;
- downstream `in_progress` stages require an explicit replan decision and must not be silently reset;
- the plan and affected stage documents should be updated in the same change unit as the inserted stage.

This keeps planning useful for AI agents without forcing premature detail.

## Stage Readiness Sections

Stage documents may include:

```md
## Readiness

Status: not_reviewed | needs_clarification | ready
Reviewed at: null

Blocking questions: unknown

## Clarification Questions

## Assumptions

## Task Decomposition

Status: not_started | in_progress | done

Required before stage `in_progress`:
- ordered executable tasks;
- source documents for each task;
- dependencies between tasks;
- likely readiness risks;
- explicit non-goals.
```

Stage readiness answers whether a stage is ready to be decomposed into tasks.
Task readiness answers whether a specific task is ready for implementation.

## Review Level Routing

Readiness and closure questions should be recorded at the level where the decision belongs.

Rules:
- plan-level questions affect roadmap goal, stage sequence, global scope, non-goals or source-of-truth policy;
- stage-level questions affect stage outcome, stage acceptance criteria, task decomposition, dependencies or readiness risks;
- task-level questions affect one executable change unit and its implementation choices;
- a task should not silently decide a stage-level or plan-level question;
- if a task readiness review discovers a stage-level question, record it in `stage.md` and pause the affected task until the stage question is resolved;
- if a stage readiness review discovers a plan-level question, record it in `plan.md` and pause affected stage work until the plan question is resolved;
- closing observations follow the same routing: task observations can be escalated to stage closure, and stage observations can be escalated to plan closure or backlog.

## Plan Readiness Sections

Plan documents may include:

```md
## Readiness

Status: not_reviewed | needs_clarification | ready
Reviewed at: null

Blocking questions: unknown

## Clarification Questions

## Assumptions

## Stage Readiness Summary
```

Plan readiness answers whether the plan is ready to guide active work.

Plan readiness should check:
- plan goal and expected outcome are clear;
- roadmap stages are ordered or intentionally unordered;
- global non-goals and boundaries are recorded;
- active source documents and source-of-truth assumptions are clear;
- stage-level details can be deferred without blocking the current stage;
- no unresolved blocking questions affect stage sequence or plan scope.

## Stage Closure Sections

Stage documents may include:

```md
## Closure Review

Status: not_started | in_progress | ready_to_close | blocked
Reviewed at: null

Blocking issues: unknown

## Closing Observations

## Closure Checklist
```

Stage closure review runs before a stage is marked `done`.

Stage closure should check:
- required tasks are `done`, `deferred` with rationale or explicitly removed from scope;
- stage acceptance criteria are satisfied or intentionally revised;
- validation evidence across the stage is sufficient;
- stage-level observations are recorded and dispositioned;
- follow-ups are promoted to backlog, later stages or new tasks;
- durable knowledge discovered during the stage is extracted to current reference, workflow, architecture or test case documentation;
- plan status and next stage readiness are updated when needed.

## Plan Closure Sections

Plan documents may include:

```md
## Closure Review

Status: not_started | in_progress | ready_to_close | blocked
Reviewed at: null

Blocking issues: unknown

## Closing Observations

## Closure Checklist
```

Plan closure review runs before a plan is marked `done`, exported or archived.

Plan closure should check:
- all stages are `done`, `deferred`, `rejected`, `exported` or `archived` with rationale;
- plan goal is achieved or the reason for partial closure is recorded;
- active source-of-truth documentation no longer depends on completed execution records;
- backlog and follow-up items are current;
- completed work history is exported or archived according to repository policy;
- remaining active plans or standalone tasks are linked from current planning entry points.

## Commit Traceability

Implementation task records should include commit traceability in two forms:
- `execution.commits` in YAML front matter for agents, tooling and tracker export;
- `## Commits` in Markdown body for human-readable history.

Rules:
- planned tasks use `execution.commits: []` and `None yet` in the Markdown section;
- completed tasks list commits that implemented or closed the task;
- if several commits are required for one task, list all of them in chronological order;
- if one commit intentionally closes several tasks, list that commit in each affected task;
- do not list unrelated later maintenance commits just because they touched the task file;
- exported task records should preserve commit references for task tracker migration.

Commit hashes cannot be written into the same commit before it exists.
Traceability may therefore be recorded by:
- using a short commit message that describes the substance of the change;
- adding commit hashes in a later bookkeeping update to both `execution.commits` and `## Commits`;
- filling commit hashes before exporting or archiving completed records.

Commit messages should not include planning task ids by default.
Task ids live in task records and may later be represented through task tracker connectors after task files are migrated.

---

# Front Matter Requirements

## Common Fields

All planning model documents should include:
- `id`;
- `type`;
- `status`;
- `scope`;
- `owners`;
- `related`;
- `ai.priority`;
- `ai.load_when`.

## `plan`

Recommended fields:

```yaml
id: PLAN-MVP-001
type: plan
status: draft
scope:
  plan: mvp
  modules:
    - toolkit
related:
  stages:
    - ai-docs/planning/2026-05-13-mvp/stage-1-methodology-baseline/stage.md
origin_task_id: TASK-000010
```

Bootstrap compatibility: existing documents with `type: planning` may remain valid until schemas and migrations are introduced.

`origin_task_id` is optional for normal plans.
It is required when a backlog task is expanded into a plan.
The field points to the removed source task id and lets task lookup resolve old task references to the target plan.

## `plan_stage`

Recommended fields:

```yaml
id: STAGE-MVP-STAGE-1-001
type: plan_stage
status: in_progress
scope:
  plan: mvp
  stage: stage-1-methodology-baseline
  modules:
    - documentation
related:
  plans:
    - ai-docs/planning/2026-05-13-mvp/plan.md
  tasks:
    - ai-docs/planning/2026-05-13-mvp/stage-1-methodology-baseline/task-8-create-source-of-truth-model.md
origin_task_id: TASK-000010
```

`origin_task_id` is optional for normal stages.
It is required when a backlog task is expanded directly into a plan stage.
The field points to the removed source task id; child implementation tasks inside the stage receive their own global task ids.

## `implementation_task`

Recommended fields:

```yaml
id: TASK-PHASE-1-SOURCE-OF-TRUTH-001
type: implementation_task
status: planned
scope:
  plan: mvp
  stage: stage-1-methodology-baseline
  task_order: 8
  modules:
    - documentation
related:
  plans:
    - ai-docs/planning/2026-05-13-mvp/plan.md
  stages:
    - ai-docs/planning/2026-05-13-mvp/stage-1-methodology-baseline/stage.md
  workflows:
    - .ai-docs/workflows/plan-stage-workflow.md
  source_documents:
    - docs/concepts/documentation-as-interface.md
execution:
  commits: []
```

## `standalone_task`

Recommended fields:

```yaml
id: TASK-STANDALONE-2026-001
type: standalone_task
status: planned
scope:
  task: update-session-compaction-guide
  modules:
    - documentation
related:
  source_documents:
    - .ai-docs/workflows/plan-stage-workflow.md
  backlog: []
execution:
  commits: []
```

Rules:
- `scope.plan` and `scope.stage` are not required for standalone tasks;
- use `related.backlog` when the standalone task resolves or advances a backlog task;
- use `related.plans` only when the task intentionally supports an active plan without belonging to its stage task list;
- standalone tasks should still include source documents, cascade impact, test plan, validation evidence, closing observations and follow-ups.

---

# Status Semantics

Planning model statuses should be shared across active plans, plan stages, implementation tasks and standalone tasks.
For task records, these statuses are interpreted through the unified task model: placement describes where the task is managed, while status describes lifecycle state.

Primary execution lifecycle:

```text
planned
  -> readiness_review
    -> ready
      -> in_progress
        -> closure_review
          -> done
```

Primary statuses:
- `planned` - record exists, but readiness has not been reviewed yet;
- `readiness_review` - record is being checked for missing decisions, assumptions and clarification questions;
- `ready` - record has no unresolved blocking clarification questions and can move to active work;
- `in_progress` - record is being executed;
- `closure_review` - work and validation are complete enough to review residual issues, observations and follow-ups before closing;
- `done` - acceptance checks are complete.

Side statuses:
- `draft` - document is still being authored and is not yet an executable planning record;
- `blocked` - record cannot advance because of an external blocker or missing upstream artifact;
- `deferred` - работа осознанно перенесена;
- `cancelled` - task was intentionally stopped or removed from active execution with rationale;
- `expanded` - task was expanded into a plan, stage or multiple tasks and has a recorded handoff target;
- `exported` - record перенесён во внешний tracker or archive;
- `archived` - record сохранён в локальном archive and excluded from default retrieval;
- `deprecated` - документ больше не должен использоваться как актуальный источник.

Для active plan допустимы `planned`, `readiness_review`, `ready`, `in_progress`, `closure_review`, `blocked`, `done`, `exported`, `archived`, `deferred`.
Для active stage допустимы `planned`, `readiness_review`, `ready`, `in_progress`, `closure_review`, `blocked`, `done`, `exported`, `archived`, `deferred`.
Для implementation task and standalone task допустимы `planned`, `readiness_review`, `ready`, `in_progress`, `closure_review`, `blocked`, `done`, `exported`, `archived`, `deferred`, `cancelled`, `expanded`.
Для early draft plan допустим `draft`, но перед началом active work его нужно перевести в primary execution lifecycle.
`accepted` is not a lifecycle gate for active plans; use `ready` when plan readiness review has passed.

Plan status rules:
- plan cannot move from `planned` directly to `in_progress`;
- plan cannot move to `ready` or `in_progress` while unresolved blocking plan-level questions remain;
- plan cannot move from `in_progress` directly to `done`, `exported` or `archived`;
- plan must enter `closure_review` before `done`, `exported` or `archived`;
- `exported` and `archived` are post-closure history states, not substitutes for plan closure review;
- if a plan remains `draft`, agents must treat it as not ready for execution unless the user explicitly asks to prepare it.

Stage status rules mirror plan status rules.
Stage cannot move from `planned` directly to `in_progress`, and stage cannot move from `in_progress` directly to `done` without `closure_review`.

`blocked` is not a replacement for normal readiness review.
Unanswered clarification questions are handled inside `readiness_review`.
A task becomes `blocked` only when it cannot advance because of an external dependency, missing upstream document, unavailable access or another blocker that cannot be resolved by answering readiness questions.

`split` is not a normal lifecycle status.
Splitting before execution is a planning edit: replace the original not-yet-completed task with smaller tasks and renumber planned tasks if needed.
Splitting after implementation has started is a replan event: preserve useful execution history and create new active tasks.
Completed tasks are not split; create follow-up tasks instead.

---

# Task Document Structure

Implementation task and standalone task documents should contain these sections:

```md
# Task Title

## Purpose

## Source Documents

## Readiness

## Intake Checklist

## Clarification Questions

## Readiness Proposals

## Assumptions

## Intake Context

## Decision Authority

## Expected Result

## Test Plan

## Acceptance Checks

## Cascade Impact

## Validation

## Closing Observations

## Closure Checklist

## Result

## Follow-ups
```

`Result` can stay empty while the task is not done.
`Follow-ups` should be explicit even when there are none.

## Readiness Section

The `Readiness` section records whether the task can move from `readiness_review` to `ready`.
Readiness review must include explicit question preparation before implementation starts.

Recommended format:

```md
## Readiness

Status: not_reviewed | needs_clarification | ready
Reviewed at: null

Blocking questions: 0

Documentation language: ru
Technical identifiers: keep original
Language exception: none
```

`Status: ready` means all blocking clarification questions are resolved.
It does not mean the task is already in progress.

`Documentation language` records the primary language to use for changed documentation.
For this repository, use `ru` by default.
Keep identifiers, statuses, paths, commands, code symbols and stable technical terms in their original form.
If the task needs a different primary language, record the exception and rationale before editing documentation.

## Intake Checklist Section

The `Intake Checklist` section records that the agent read the mandatory execution context before editing implementation artifacts.

For `implementation_task`, use these exact checklist labels:

```md
## Intake Checklist

- [x] Read `.ai-docs/workflows/plan-stage-workflow.md`
- [x] Read active plan
- [x] Read active stage
- [x] Read this task
```

For `standalone_task`, use these exact checklist labels:

```md
## Intake Checklist

- [x] Read `.ai-docs/workflows/plan-stage-workflow.md`
- [x] Review standalone scope rationale
- [x] Read this task
```

Rules:
- executable task records in `readiness_review`, `ready`, `in_progress` or `closure_review` must include a complete checked intake checklist;
- `.ai-docs/workflows/plan-stage-workflow.md` must be read before work begins;
- implementation tasks must also read the active plan and active stage;
- standalone tasks must review the standalone scope rationale instead of active plan/stage context;
- checklist labels are intentionally exact so static validation can verify them.

## Clarification Questions

Clarification questions are used during `readiness_review`.
Every task entering `readiness_review` must have this section reviewed and updated.

Recommended format:

```md
## Clarification Questions

- [ ] Question text
  Blocking: yes
  Requires user confirmation: yes
  Recommended option: A
  Options:
  - A: Recommended decision and tradeoff.
  - B: Alternative decision and tradeoff.

Non-blocking clarifications:
- Clarification: Question or uncertainty that can proceed with a documented default.
  Blocking: no
  Requires user confirmation: no
  Default: Safe default selected for this task.
  Rationale: Why the default is acceptable without blocking execution.
```

Rules:
- before implementation, the agent must inspect task purpose, source documents, acceptance checks, cascade impact and likely implementation choices;
- questions must be prepared and recorded before the agent edits implementation artifacts;
- decisions that affect architecture, public interface, data model, tooling, workflow, validation behavior, task boundaries or destructive actions require explicit review;
- each prepared question must be marked as blocking or non-blocking;
- each prepared question must say whether user confirmation is required;
- `None blocking` is allowed only after the review finds no blocking questions requiring user confirmation;
- non-blocking clarifications may proceed with a documented default when the default is safe, reversible inside the task scope and does not affect task boundaries;
- non-blocking clarifications must be reclassified as blocking if new information shows that they affect architecture, public interface, data model, tooling, workflow, validation behavior, task boundaries or destructive actions;
- questions are asked one at a time;
- each question should include 2-3 options;
- one option should be marked as recommended when a safe default exists;
- the user may accept the recommended option with a simple confirmation;
- accepted answers must be written back as assumptions or decisions;
- after each accepted answer, the agent must decide whether the answer can create new questions;
- if an answer changes task boundaries, architecture, tooling, validation behavior or implementation approach, the agent must immediately re-review clarification questions;
- if answers are independent and do not change task shape, the agent may re-review after the current question set is resolved;
- task can move to `ready` only after the final re-review confirms that no new blocking clarification questions requiring user confirmation remain;
- task cannot move to `ready` or `in_progress` while blocking questions requiring user confirmation remain unresolved.

## Readiness Proposals

Readiness proposals record agent recommendations that improve task execution but are not questions requiring a user answer.
They are used when the agent wants to propose an implementation direction, a tradeoff, a scope boundary, a validation approach or a follow-up.

Recommended format:

```md
## Readiness Proposals

- Proposal: Use the existing structure validation module for this rule.
  Blocking: no
  Disposition: accepted
  Rationale: The proposal follows the local validation architecture and does not expand task scope.
  Follow-up: None.

- Proposal: Add stricter validation for historical records.
  Blocking: no
  Disposition: deferred
  Rationale: Historical migration needs a separate compatibility decision.
  Follow-up: ai-docs/planning/backlog.md#...
```

Rules:
- proposals must include rationale and disposition;
- valid dispositions are `accepted`, `deferred`, `rejected`, `documented`, `not_applicable`, `backlog` or `task`;
- `backlog` and `task` dispositions must name the target backlog task or executable task when the target exists;
- proposals do not block `ready` when their disposition is recorded;
- proposals that reveal a missing decision affecting architecture, workflow, validation behavior or task boundaries must be converted into clarification questions;
- proposals must not silently expand the current task scope.

## Assumptions

Assumptions record non-blocking defaults accepted for the task.

## Intake Context

`Intake Context` records the original "why" when a task is moved from backlog placement into an executable placement or expanded into a plan/stage.

Recommended format:

```md
## Intake Context

Origin: TASK-000007
Moved from: backlog
Moved to: plan_stage
Moved at: 2026-05-16

Problem:
...

Expected:
...

Notes:
...
```

Rules:
- copy the original backlog problem, expected result and relevant notes into the target task before deleting the backlog task record;
- preserve the same global task id when the backlog task already has one;
- after movement, the target implementation task becomes the source of truth for the active work context;
- do not keep a tombstone backlog task by default;
- historical or external references to removed backlog task records are outside the active documentation consistency guarantee;
- if a project needs redirects or notifications for removed backlog task records, define that as a separate archive/integration mechanism.

Expansion rules:
- when a backlog task becomes a plan or plan stage, copy the full source context into the target plan/stage before deleting the backlog task record;
- the target plan/stage front matter must include `origin_task_id: TASK-NNNNNN`;
- remove the source backlog task from `ai-docs/planning/backlog.md` and delete its backlog task file after successful context copy;
- do not keep a tombstone source task record by default;
- executable tasks created inside the target plan/stage receive new global task ids and must not reuse the source `origin_task_id` id.

## Decision Authority

Decision authority explains what the agent may decide without confirmation and what requires user confirmation.

Example:

```md
## Decision Authority

Agent may decide:
- formatting details;
- names following existing conventions.

User confirmation required:
- source-of-truth precedence;
- lifecycle changes;
- destructive archive/export behavior.
```

## Test Plan Section

The `Test Plan` section records how the task will be verified before implementation starts.

Recommended format:

```md
## Test Plan

Task-specific tests:
- tests/test_target_behavior.py

Related module tests:
- tests/test_related_contract.py

Project regression:
- .venv/bin/python -m pytest

Notes:
- Selected checks cover the changed behavior and affected module boundary.
```

Rules:
- task-specific tests should cover the behavior changed by the task;
- before behavior changes, identify related test case documents and executable tests;
- update expected behavior in test case documents and executable tests before changing implementation when documented stable behavior changes;
- if existing test case documents and executable tests already cover the change, record that decision in the task;
- related module tests should cover shared contracts, adapters or dependencies touched by the task;
- project regression should run before closing the task when a project-level test suite exists;
- documentation-only tasks may use manual documentation consistency review instead of automated tests;
- test scope should match task risk and blast radius;
- exhaustive tests are not required, but omitted relevant checks should be explained.

For bugfix or behavior-change tasks, add or update a failing test that reproduces the required behavior before implementation when practical.
If the behavior is already covered by an existing failing test, reference that test instead.
If existing passing tests already cover the new expected behavior, record why no test update is needed.
If the behavior cannot be tested at the current layer, record why in the task.

## Validation Section

The `Validation` section records checks actually executed before closing the task.

Recommended format:

```md
## Validation

Executed:
- .venv/bin/python -m pytest tests/test_target_behavior.py
- .venv/bin/python -m pytest

Result:
- Passed.
```

Rules:
- include exact commands when automated checks are run;
- include manual checks when no automated check applies;
- record failed or skipped checks with reason and residual risk;
- completed implementation tasks should not have empty validation evidence.

## Closing Observations Section

The `Closing Observations` section records risks, tradeoffs and improvement proposals found before closing the task.
It must also make the disposition actionable by explaining what was done in the current task and what remains to do.

Recommended format:

```md
## Closing Observations

- Observation: Consider adding bidirectional traceability if needed later.

  Impact:
  Future navigation may require reverse lookup that is not covered by the current task.

  Action taken:
  The current task records one-way relationships and keeps the follow-up visible.

  Disposition:
  backlog

  Rationale:
  Bidirectional traceability is useful but not required for the current acceptance checks.

  Follow-up:
  - Target: ai-docs/planning/backlog.md#blg-001-example
    Requirement: Define whether reverse lookup is required for navigation.
    Handoff status: recorded
    Handoff evidence: Backlog task contains the requirement.

- Observation: Current validation is manual until CLI validation is implemented.

  Impact:
  Manual validation can miss consistency errors that automated checks would catch.

  Action taken:
  Manual checks were executed and recorded in `Validation`.

  Disposition:
  accepted_risk

  Rationale:
  CLI validation is scheduled for a later task.

  Follow-up:
  None.
```

Rules:
- review observations before marking a task `done`;
- include risks, tradeoffs, follow-ups, missing documentation, test gaps, validation limitations and improvement proposals when found;
- every observation must include `Impact`, `Action taken`, `Disposition`, `Rationale` and `Follow-up`;
- every observation must have a `Disposition`;
- dispositions are `backlog`, `task`, `accepted_risk`, `documented`, `not_applicable` or `deferred`;
- `backlog` and `task` dispositions must include a target backlog task or executable task;
- `accepted_risk`, `documented`, `not_applicable` and `deferred` dispositions must include a short rationale;
- `Follow-up` must name the follow-up target or explicitly state `None`;
- every follow-up must be actionable and include `Target`, `Requirement`, `Handoff status` and `Handoff evidence` unless it is `None`;
- `Handoff status` values are `recorded`, `deferred`, `blocked` or `not_applicable`;
- `recorded` means the target planning record, backlog task, executable task or documentation artifact was updated to account for the requirement;
- `deferred`, `blocked` and `not_applicable` must include rationale in `Handoff evidence`;
- when disposition is `task` or `backlog`, `recorded` requires the target task or backlog task to explicitly include the transferred requirement in source documents, intake context, expected result, acceptance checks, follow-ups or another appropriate section;
- report closing observations to the user before or while closing the task;
- report each observation to the user with `Observation`, `Impact`, `Action taken`, `Disposition`, `Rationale` and `Follow-up`;
- explicitly state `Closing observations: None.` when no additional observations are found;
- do not use observations to hide blocking issues; blocking issues should keep the task out of `done`;
- observations without action, rationale or follow-up decision remain unresolved.

## Closure Checklist Section

The `Closure Checklist` section records that the mandatory closeout gate was performed.

Recommended format:

```yaml
closure:
  observations_recorded: true
  observations_reported_to_user: true
  observations_reported_with_disposition: true
  observations_resolved: true
  language_policy_checked: true
  blocking_issues: 0
  followups_recorded: true
```

Rules:
- task must move from `in_progress` to `closure_review` before it can move to `done`;
- task cannot move from `in_progress` directly to `done`;
- `observations_recorded` means the `Closing Observations` section was reviewed and filled with either findings or `None`;
- `observations_reported_to_user` means observations were shown to the user before the task was marked `done`;
- `observations_reported_with_disposition` means the user-facing closure report included disposition, rationale and follow-up decision for each observation, or explicitly reported `Closing observations: None.`;
- `observations_resolved` means every observation has impact, action taken, disposition, rationale and follow-up decision;
- `language_policy_checked` means changed documentation was checked against `docs/reference/document-language-policy.md`;
- `blocking_issues` must be `0` before the task can move to `done`;
- `followups_recorded` means follow-ups are either `None` or have actionable handoff records; for `recorded` handoffs, the target was actually updated;
- the checklist complements the `closure_review` status but does not replace it.

---

# Work History Policy

Planning files are an active execution interface, not the permanent source of truth for all completed work.

Active planning documents should stay in the repository while they are needed for current implementation, validation and review.

After a plan, stage or task is completed, its record should be handled as work history:
- if an external task tracker is configured, export or link the completed record there;
- if an external file archive is configured, move completed records there;
- if no external tracker or archive is configured, move completed records to `ai-docs/planning/archive/`;
- exclude exported and archived records from default context retrieval and graph validation;
- keep only current source-of-truth documentation in active docs.

## Knowledge Extraction Before Close

Before a completed planning record is exported or archived, durable knowledge must be extracted into the appropriate documentation layer.

Examples:
- new methodology rule -> `docs/reference`, `docs/workflows` or `rules`;
- architecture decision -> `docs/architecture`;
- user-facing process -> `docs/guides`;
- validation behavior -> `schemas`, `rules` or acceptance docs;
- unresolved work -> new active plan, stage or task.

If a completed task contains knowledge needed to understand current behavior, that knowledge must not remain only in the execution record.

## Tracker Configuration

The project may define a tracker or archive backend later in configuration.

Conceptual fields:

```yaml
planning:
  history:
    backend: external-tracker
    exported_records_are_source_of_truth: false
```

Supported backend concepts:
- `external-tracker` - GitLab Issues, Jira, Linear or similar;
- `external-files` - a file storage outside the repository;
- `repository-archive` - `ai-docs/planning/archive/` inside the repository.

Default behavior:
- if no backend is configured, use `repository-archive`;
- if a backend is configured, completed records may be exported and removed from active planning directories;
- exported records should leave only minimal references in active docs when useful.

## Link Maintenance

Active planning documents must keep links valid.

Exported or archived execution records are historical artifacts and are not required to track every future documentation path change.
If a historical record references an old path, it should be interpreted as a record of the repository state at the time of execution.

Current source-of-truth documents must not depend on archived or exported execution records for understanding current behavior.

---

# Standalone Task Rules

Standalone tasks use the same readiness and closure gates as implementation tasks.

Rules:
- a standalone task must not skip clarification question preparation;
- if blocking questions require user confirmation, the task stays in `readiness_review`;
- before closing, the task records validation evidence, closing observations and closure checklist;
- if a standalone task discovers plan-level or stage-level decisions, create or update the appropriate plan/stage before implementation continues;
- if a standalone task grows beyond one change unit, promote it into a plan/stage or create a small plan.

Standalone task without a file:
- allowed only for trivial user requests where no durable work history is needed;
- still requires the agent to perform readiness thinking, ask blocking questions and report validation/observations in the chat;
- if the task changes source-of-truth documentation, workflow, validation behavior, architecture or code, create a standalone task file or attach the work to an active plan task.

Promotion rules:
- keep the original standalone task as context if work already started;
- create a plan/stage when multiple tasks or ordering are needed;
- move durable decisions into reference/workflow/architecture docs before closing;
- record the movement or promotion target in `Follow-ups` or `Closing Observations`.

---

# File Naming Rules

Plan directory:

```text
ai-docs/planning/<sortable-plan-slug>/
```

Stage directory:

```text
ai-docs/planning/<sortable-plan-slug>/<stage-slug>/
```

Task filename:

```text
task-N-<task-slug>.md
```

Standalone task filename:

```text
ai-docs/planning/tasks/YYYY-MM/task-NNN-<task-slug>.md
```

Rules:
- `N` defines task order inside the stage.
- `N` is unique only within one stage directory.
- `scope.plan`, `scope.stage` and `scope.task_order` must match the file path.
- A newly discovered task should be inserted after the last completed task and before the first not-yet-completed task when it is needed to continue the current stage.
- Planned tasks after the insertion point should be renumbered while they are still not completed.
- Completed tasks should not be renumbered except to fix an obvious ordering mistake in the current uncommitted change unit.
- When a planning edit divides a not-yet-completed task into smaller tasks, prefer suffixes such as `task-5a-...` and `task-5b-...` instead of renumbering completed or unrelated tasks.
- Deferred or removed tasks should not force renumbering of completed task files.
- `YYYY-MM` groups standalone tasks by creation or planning month.
- standalone task `NNN` defines order inside the monthly standalone task directory.
- standalone task `NNN` is unique only within one `YYYY-MM` directory.
- standalone tasks do not use `scope.plan`, `scope.stage` or `scope.task_order` unless they intentionally reference an active plan context.

---

# Bootstrap Migration Rule

Current MVP plan is migrated to `ai-docs/planning/2026-05-13-mvp/plan.md`.

New substantial tasks should prefer separate `implementation_task` documents.

Next migration targets:
- add schemas for `plan`, `plan_stage` and `implementation_task`;
- add templates for `plan.md`, `stage.md` and `task-N-<slug>.md`;
- add validation rules for path and metadata consistency;
- add configuration and validation for work history backends.
