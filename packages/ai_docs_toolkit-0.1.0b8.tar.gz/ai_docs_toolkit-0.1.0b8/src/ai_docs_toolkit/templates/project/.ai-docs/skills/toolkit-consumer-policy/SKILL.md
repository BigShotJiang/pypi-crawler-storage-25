---
name: toolkit-consumer-policy
description: Use in projects that consume AI Docs Toolkit when deciding whether a workflow, schema, template, validation rule, planning skill, or toolkit-provided file is imported policy or a local project override.
---

# Toolkit Consumer Policy

Use this skill when a consumer project changes files delivered by AI Docs Toolkit.

## Imported Toolkit Policy

Treat toolkit-provided workflow, schema, template, validation and planning skill files as imported toolkit policy unless the project records an explicit local override.

Toolkit policy changes should normally be made upstream in the toolkit repository, then redistributed through the package.

## Local Overrides

A local override must record:
- why the project needs different behavior;
- which files and rules are overridden;
- how long the override is expected to live;
- what replaces or reconciles it later.

Do not silently fork toolkit planning rules during ordinary product work.

## Migration Rule

During the current migration stage, toolkit-managed planning skill, workflow and reference files may be overwritten from the toolkit distribution when `ai-docs init` runs.

Project-specific files outside the toolkit-managed paths must not be deleted or rewritten as part of that migration.

## References

Load full references only when needed:
- `docs/reference/toolkit-maintenance-context-routing.md`
- `.ai-docs/workflows/plan-stage-workflow.md`
