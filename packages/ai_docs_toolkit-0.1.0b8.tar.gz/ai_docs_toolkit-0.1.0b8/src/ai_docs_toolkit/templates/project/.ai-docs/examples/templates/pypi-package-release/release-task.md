---
id: TASK-NNNNNN
type: standalone_task
status: planned
scope:
  placement: standalone
  task: release-beta-NN
  modules:
    - packaging
    - release
owners:
  - maintainers
related:
  reference:
    - REF-DISTRIBUTION-STRATEGY-001
    - REF-CI-AGENT-INTEGRATION-001
  workflows:
    - WF-PLAN-STAGE-001
ai:
  priority: high
  load_when:
    - topic: package-publishing
    - topic: release
    - topic: beta
---

# Release Beta NN

## Intake Checklist

- [ ] Read `.ai-docs/workflows/plan-stage-workflow.md`
- [ ] Read `.ai-docs/reference/distribution-strategy.md`
- [ ] Read previous release evidence
- [ ] Confirm target version and tag
- [ ] Read this task

## Purpose

Publish Python package `PACKAGE==VERSION` to PyPI for tag `TAG`.

## Expected Changes

- Bump `pyproject.toml` to `VERSION`.
- Bump runtime `__version__` to `VERSION` when present.
- Update versioned package-facing examples.
- Build source distribution and wheel artifacts.
- Verify wheel install.
- Commit release changes.
- Push tag `TAG` to trigger publication.
- Record post-publish verification.

## Acceptance Criteria

- Package metadata and runtime version report `VERSION`.
- Tag/version guard accepts `TAG`.
- Project validation and tests pass.
- Built wheel can be installed into an isolated target.
- Matching tag `TAG` is pushed.
- PyPI exact install works after publication.

## Validation

- Pending.

## Publication Evidence

- commit: pending
- tag: `TAG`
- pipeline: pending
- package: `PACKAGE==VERSION`
