import os
import re
import tomllib
from pathlib import Path


tag = os.environ["CI_COMMIT_TAG"]
match = re.fullmatch(r"v(\d+\.\d+\.\d+)(?:-(beta|rc)-(\d{2}))?", tag)
if not match:
    raise SystemExit(f"Unsupported release tag: {tag}")

base, kind, sequence = match.groups()
expected = base
if kind == "beta":
    expected = f"{base}b{int(sequence)}"
elif kind == "rc":
    expected = f"{base}rc{int(sequence)}"

with Path("pyproject.toml").open("rb") as file:
    actual = tomllib.load(file)["project"]["version"]

if actual != expected:
    raise SystemExit(
        f"pyproject.toml version {actual!r} does not match {tag!r}; expected {expected!r}"
    )
if actual == "0.0.0":
    raise SystemExit("Bootstrap version 0.0.0 must not be published")
print(f"Release tag {tag} matches package version {actual}")
