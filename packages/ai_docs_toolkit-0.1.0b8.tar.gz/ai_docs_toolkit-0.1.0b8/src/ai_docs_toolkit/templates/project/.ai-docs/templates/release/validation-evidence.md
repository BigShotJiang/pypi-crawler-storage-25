## Validation

- `COMMAND` - passed, output `SUMMARY`.
- `COMMAND` - failed, reason `SUMMARY`.
- `COMMAND` - skipped, reason `SUMMARY`.

## Publication Evidence

- commit: `COMMIT`
- tag: `TAG`
- pipeline/workflow: `URL_OR_ID`
- package/artifact: `NAME_VERSION_OR_URL`

## Post-Publication Verification

- `COMMAND` - passed, output `SUMMARY`.
- `COMMAND` - failed, reason `SUMMARY`.
- `COMMAND` - skipped, reason `SUMMARY`.
