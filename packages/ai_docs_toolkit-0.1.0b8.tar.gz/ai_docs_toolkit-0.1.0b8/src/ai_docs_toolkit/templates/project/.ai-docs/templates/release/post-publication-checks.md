# Post-Publication Checks

- [ ] Published artifact is visible in the target registry or distribution channel
- [ ] Exact version install or consumption works
- [ ] Default/latest install behavior is understood for the release channel
- [ ] Runtime version reports the released version
- [ ] Required packaged resources are present
- [ ] Project-specific CLI, library, service, or deployment smoke test passes
- [ ] Skipped checks are recorded with rationale
