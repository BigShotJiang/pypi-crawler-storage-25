---
id: REL-MIGRATION-NOTE-TEMPLATE
type: reference
status: draft
scope:
  modules:
    - release
    - migration
owners:
  - maintainers
related:
  workflows:
    - WF-TOOLKIT-MIGRATION-001
ai:
  priority: medium
  load_when:
    - topic: release
    - topic: migration-note
---

# Release Migration Note Template

## Version Range

From: `<previous-version>`

To: `<target-version>`

## Consumer Impact

- Changed files, templates, schemas, workflows, validation rules or CLI behavior:
- No migration required: yes/no

## Agent Instructions

Run before edits:

```bash
ai-docs doctor
ai-docs init --check
ai-docs planning migrate-layout --dry-run
```

Manual steps:
- Step 1:
- Step 2:

Stop for human review when:
- a project-owned file needs a rewrite not described here;
- a target path conflict exists;
- validation reports errors outside this migration.

## Preservation Rules

- Preserve document ids and task ids.
- Preserve aliases and compatibility fields.
- Update `task_index.path` only when a task record path changes.
- Do not rewrite completed historical records only to modernize paths.

## Validation

Run after migration:

```bash
ai-docs validate
ai-docs doctor
```

Expected result:
- `ai-docs validate` passes, or remaining failures are listed with defer rationale.
- `ai-docs doctor` has no unexpected upgrade findings, or findings are recorded as follow-ups.

## Evidence

Commands and results:
- Command:
  Result:

Changed files:
- 

Skipped checks or deferred work:
- Reason:
  Follow-up:

## Rollback

Rollback expectation:
- use Git revert for manual file edits;
- do not promise automatic rollback for semantic conflicts.
