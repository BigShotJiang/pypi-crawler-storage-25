---
id: TASK-NNNNNN
type: standalone_task
status: planned
scope:
  placement: standalone
  task: release-short-slug
  modules:
    - release
owners:
  - maintainers
related:
  reference: []
  workflows: []
ai:
  priority: high
  load_when:
    - topic: release
    - topic: publication
---

# Release Short Title

## Intake Checklist

- [ ] Read repository release policy
- [ ] Review previous release evidence
- [ ] Confirm target version, release channel and tag
- [ ] Read this task

## Standalone Scope Rationale

This task is limited to release preparation, validation, publication evidence and post-publication verification.

## Purpose

Publish or verify release `VERSION` for `PROJECT`.

## Source Documents

- `path/to/release-policy.md`
- `path/to/ci-or-distribution-policy.md`
- `path/to/package-or-version-metadata`

## Expected Changes

- Update version metadata to `VERSION`.
- Update release-facing examples or documentation that must match `VERSION`.
- Build and verify release artifacts.
- Commit release preparation changes.
- Create and push tag `TAG`.
- Record publication and post-publication verification.

## Readiness

Status: ready
Reviewed at: YYYY-MM-DD

Blocking questions: 0

## Clarification Questions

Blocking:
- None.

Resolved:
- What is the target version?
  - Decision: `VERSION`.
  - Evidence: repository release policy and previous release evidence.
  - Status: resolved.

## Acceptance Criteria

- Version metadata reports `VERSION`.
- Tag `TAG` matches repository release policy.
- Repository validation and tests pass.
- Release artifacts are built and locally verified.
- Release commit exists.
- Tag `TAG` is pushed.
- Publication and post-publication verification are recorded, or an external limitation is recorded.

## Test Plan

- Run repository validation.
- Run automated tests.
- Build release artifacts.
- Verify built artifacts in an isolated environment.
- Run repository-specific tag/version checks when available.
- Run post-publication install or consumption checks.

## Validation

- Pending.

## Publication Evidence

- commit: pending
- tag: pending
- pipeline/workflow: pending
- package/artifact: pending

## Result

Pending.

## Follow-ups

- None.

## Closing Observations

- None.

## Closure Checklist

```yaml
closure:
  observations_recorded: false
  observations_reported_to_user: false
  observations_resolved: false
  blocking_issues: 0
  followups_recorded: false
```
