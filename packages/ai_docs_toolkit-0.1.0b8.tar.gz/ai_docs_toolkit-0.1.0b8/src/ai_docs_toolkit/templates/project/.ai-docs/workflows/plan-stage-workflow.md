---
id: WF-PLAN-STAGE-001
type: workflow
status: draft
scope:
  modules:
    - planning
    - documentation
    - toolkit
owners:
  - maintainers
related:
  concepts:
    - docs/concepts/documentation-as-interface.md
    - docs/concepts/change-cascade.md
    - docs/concepts/planning-as-execution-interface.md
  planning:
    - PLAN-MVP-001
    - PLAN-BACKLOG-001
  architecture:
    - docs/architecture/repository-structure.md
  reference:
    - REF-PLANNING-DOCUMENT-MODEL-001
    - docs/reference/source-of-truth-model.md
ai:
  priority: high
  load_when:
    - topic: planning
    - topic: implementation-stage
    - topic: change-cascade
---

# Plan Stage Workflow

## Purpose

Этот workflow описывает, как реализуется этап плана в AI Docs Toolkit.

Этап плана не является внешней задачей поверх документации. Он является документированным изменением состояния toolkit и должен обновлять все затронутые слои:
- planning;
- methodology;
- architecture;
- reference documents;
- schemas, templates and rules;
- implementation;
- examples and validation.

Цель workflow - сделать реализацию этапов воспроизводимой для человека, AI-агента и будущего CLI.

Planning document types and target file layout are defined in `.ai-docs/reference/planning-document-model.md`.
New planning records should use the accepted repository layout by default:
- plan directory: `ai-docs/planning/<sortable-plan-slug>/`;
- plan document: `plan.md`;
- stage directory: `stage-NNN-<stage-slug>/`;
- stage document: `stage.md`;
- stage task file: `task-N-<task-slug>.md`.

Global `TASK-NNNNNN` ids identify tasks in front matter and references.
They do not replace stage-local task filename ordering.

## Agent-Facing Planning Skills

Planning workflow is distributed skill-first.
Compact skills contain the executable subset of this workflow and the planning model, while this document and `.ai-docs/reference/planning-document-model.md` remain full source-of-truth references.

Toolkit-maintained planning skills:
- `.ai-docs/skills/planning-task-execution/SKILL.md` - execution from `ai-docs/planning/**`, readiness review, lifecycle transitions, validation and closure;
- `.ai-docs/skills/planning-record-generation/SKILL.md` - incoming request conversion, plan/stage/task creation, task ids, layout and front matter relationships;
- `.ai-docs/skills/toolkit-consumer-policy/SKILL.md` - imported toolkit policy versus local overrides in consumer projects.

Rules:
- agents should load compact planning skills before loading full workflow/model references;
- this repository and toolkit consumers should use the same planning skill/rule set;
- full workflow/model documents should be loaded selectively by task, topic, id or unresolved decision;
- `.ai-docs/` is the toolkit-owned namespace for project-local toolkit artifacts such as skills and generated templates;
- toolkit-managed planning skill, workflow and reference files may be overwritten from toolkit distribution during the current migration stage;
- project-specific files outside toolkit-managed paths must not be rewritten by this migration.

---

# Core Model

## Plan Stage

Plan stage - это крупная запланированная часть развития toolkit.

Пример:
- Phase 1: Methodology Baseline;
- Phase 2: Schema and Template MVP;
- Phase 3: Validation CLI MVP.

Plan stage определяет expected outcome, scope и acceptance criteria, но обычно слишком крупен для одного изменения.

## Implementation Task

Implementation task - это минимальная change unit внутри plan stage.

Одна implementation task должна:
- иметь ясный результат;
- иметь ограниченный набор затронутых документов и файлов;
- проходить change cascade;
- обновлять план, если фактическое состояние изменилось;
- оставлять репозиторий в согласованном состоянии.

Пример:
- заменить GitLab boilerplate README на product README;
- создать reference document для front matter fields;
- добавить базовую frontmatter schema;
- реализовать parser для Markdown + YAML front matter.

## Standalone Task

Standalone task - это минимальная executable change unit без обязательного parent plan/stage.

Standalone task используется для небольших задач, где полноценный plan/stage создаёт лишний overhead, но readiness review, validation and closure review всё равно нужны.

Пример:
- небольшое уточнение workflow rule;
- локальная документационная правка с durable effect;
- isolated validation hardening task;
- user-requested change that needs audit trail but not roadmap sequencing.

Standalone task не является способом обойти planning lifecycle.
Если task меняет source-of-truth documentation, workflow, validation behavior, architecture or code, agent should create or use a task record unless the work is truly trivial and reported completely in chat.

## Incoming Request

Incoming request - это входящий сигнал до planning decision.

Request может быть:
- bug report;
- feature request;
- documentation gap;
- support or usage question;
- contribution proposal;
- external feedback.

Request не является task и не должен выполняться напрямую.
Перед попаданием в backlog, active task, stage or plan request проходит triage по `docs/reference/incoming-request-model.md`.

Rules:
- raw incoming requests are stored under `docs/requests/` during the local pilot;
- request ids use `REQ-NNNNNN`, not global `TASK-NNNNNN` ids;
- converting a request into planning work allocates or updates normal task/stage/plan records;
- target planning records should preserve request provenance through `source_request_id` or `source_request_ids`.
- request details are not accepted design decisions until triage/readiness review compares them with existing toolkit rules;
- when a request conflicts with accepted workflow, architecture, schema, template or validation rules, agents should recommend the current accepted rule by default and record any proposed rule change as an explicit decision point;
- when a request is compatible with current toolkit behavior, agents may plan it as an additive improvement.

Toolkit-related requests require an additional routing check:
- in this repository, toolkit workflow, schema, template and validation documents are product source documents;
- in consuming projects, toolkit workflow, schema, template and validation documents are imported toolkit policy unless explicitly forked as local overrides;
- requests that change toolkit behavior should route to toolkit maintenance context, not ordinary product work;
- local toolkit overrides require rationale, scope and replacement or expiry criteria;
- detailed routing rules live in `docs/reference/toolkit-maintenance-context-routing.md`.

---

# Stage Execution Lifecycle

## 1. Review Plan Readiness

Перед активной работой по roadmap or major plan нужно проверить plan-level readiness.

Plan readiness отвечает на вопросы:
- понятна ли цель plan;
- понятны ли global scope and non-goals;
- понятен ли порядок stages or rationale for unordered stages;
- нет ли blocking questions по source-of-truth, приоритетам, границам roadmap or sequencing;
- достаточно ли детализирован ближайший stage.

Future stages may remain high-level.
Это допустимо, если ближайший active stage можно подготовить без unresolved plan-level questions.

Если вопрос влияет на цель plan, sequence stages, global non-goals or source-of-truth policy, его нужно записать в `plan.md`, а не в отдельную task.

Active plan uses the same gate lifecycle as stages and tasks:

```text
planned
  -> readiness_review
    -> ready
      -> in_progress
        -> closure_review
          -> done
```

Rules:
- plan cannot move from `planned` directly to `in_progress`;
- plan cannot move to `ready` or `in_progress` while unresolved blocking plan-level questions remain;
- plan cannot move from `in_progress` directly to `done`, `exported` or `archived`;
- plan must enter `closure_review` before `done`, `exported` or `archived`;
- `draft` plan is not executable active work until it enters the primary lifecycle;
- `accepted` is not used as an active lifecycle gate; use `ready`.

## 2. Select Stage

Перед началом работы выбирается active plan stage.

Нужно прочитать:
- сам planning-документ;
- связанные architecture documents;
- связанные concept documents;
- уже существующие reference/workflow documents, если они есть.

Если документов недостаточно для реализации, сначала создаётся или уточняется нормативная документация.

When a new stage is inserted before incomplete stages in an active plan, the plan must run downstream readiness invalidation review:
- completed stages are not reopened unless a dedicated correction or migration task explicitly changes their history;
- downstream `planned` stages remain `planned` and should record the new dependency when relevant;
- downstream stages in `readiness_review` or `ready` return to `planned` unless the plan records an explicit decision that the inserted stage cannot affect their scope, source documents, readiness questions, dependencies or task decomposition;
- downstream `in_progress` stages must not be silently reset; they require an explicit replan decision that preserves completed work and records affected tasks;
- the plan and affected stage documents must be updated in the same change unit as the stage insertion.

## 3. Review Stage Readiness

Перед переводом stage в `in_progress` нужно выполнить stage readiness review.

Stage readiness отвечает на вопросы:
- понятен ли stage outcome;
- достаточно ли acceptance criteria для закрытия stage;
- есть ли ordered task decomposition or explicit decision to defer task creation;
- понятны ли dependencies, readiness risks and non-goals;
- можно ли передать первую task агенту без выдумывания stage-level decisions.

Stage-level readiness фиксируется в `stage.md`.
Если stage-level blocking questions остаются unresolved, tasks этого stage не должны переходить в `in_progress`, если эти questions влияют на их boundaries or implementation approach.

Stage uses the same gate lifecycle as active plan.
Stage cannot move from `planned` directly to `in_progress` and cannot move from `in_progress` directly to `done`.
Stage must pass through `readiness_review` before active work and `closure_review` before `done`.

## 4. Split Into Implementation Tasks

Этап разбивается на implementation tasks.

Future stages may remain high-level while they are not active.
Before a stage becomes active, it must be decomposed into executable tasks.

Stage-level readiness is reviewed in `stage.md`.
If the stage has no tasks yet, fill the stage readiness and task decomposition sections before moving the stage to `in_progress`.
Create a separate decomposition task only when decomposition itself is a standalone work unit.
When a stage is decomposed into ordered tasks, each ordered task must have a task record file in the same change unit.
Do not list a planned or ordered stage task only as text in `stage.md`.
The stage may remain high-level before decomposition, but once a task is named as part of the stage task order it must receive a global task id, `scope.task_order`, placement metadata and a task document path.

Каждая task должна быть достаточно маленькой, чтобы по ней можно было проверить:
- какие документы были источником требований;
- какие документы изменились;
- какая реализация добавлена или изменена;
- какие проверки выполнены;
- что осталось follow-up.

## 5. Define Task Context

Для каждой implementation task or standalone task фиксируется минимальный контекст:
- active plan stage;
- source documents;
- affected documentation layers;
- expected artifact;
- acceptance checks;
- known non-goals.

For standalone tasks, `active plan stage` can be omitted, but the task must record why standalone scope is sufficient.

На раннем этапе это может быть отдельный раздел в planning-документе.
Позже это может стать отдельным document type или CLI-managed artifact.

## 6. Review Task Readiness

Перед implementation task or standalone task должна пройти readiness review.
Readiness review starts with mandatory question preparation.
Agent must inspect the task, source documents, affected layers and likely implementation choices before editing implementation artifacts.
Before executing any implementation task from `ai-docs/planning/**`, the agent must read this workflow document.
This is not optional agent discipline: task records in `readiness_review`, `ready`, `in_progress` or `closure_review` must include a checked `## Intake Checklist` proving the required intake was performed.

Primary task lifecycle:

```text
planned
  -> readiness_review
    -> ready
      -> in_progress
        -> closure_review
          -> done
```

Агент может самостоятельно перевести task из `planned` в `readiness_review`, если пользователь просит выполнить эту task.
Для небольшой user-requested work без task file агент всё равно должен выполнить readiness thinking and ask blocking questions before implementation.

При переходе task в `readiness_review`, а также при попытке выполнить task уже находящуюся в `readiness_review`, агент обязан подготовить и записать clarification questions в task record.

Intake checklist rules for `implementation_task`:
- `## Intake Checklist` must exist before implementation artifacts are edited;
- `Read .ai-docs/workflows/plan-stage-workflow.md` must be checked;
- `Read active plan` must be checked;
- `Read active stage` must be checked;
- `Read this task` must be checked.

Intake checklist rules for `standalone_task`:
- `## Intake Checklist` must exist before implementation artifacts are edited;
- `Read .ai-docs/workflows/plan-stage-workflow.md` must be checked;
- `Review standalone scope rationale` must be checked;
- `Read this task` must be checked.

Machine-readable checklist text must use these exact Markdown labels:

```md
## Intake Checklist

- [x] Read `.ai-docs/workflows/plan-stage-workflow.md`
- [x] Read active plan
- [x] Read active stage
- [x] Read this task
```

For standalone tasks:

```md
## Intake Checklist

- [x] Read `.ai-docs/workflows/plan-stage-workflow.md`
- [x] Review standalone scope rationale
- [x] Read this task
```

Question preparation rules:
- review task purpose, source documents, acceptance checks, cascade impact and expected implementation surface;
- record documentation language when the task changes documentation;
- identify decisions that affect architecture, public interface, data model, tooling, workflow, validation behavior, task boundaries or destructive actions;
- classify each question as blocking or non-blocking;
- mark whether user confirmation is required;
- record non-blocking clarifying questions when they can improve execution quality without changing task boundaries;
- record agent proposals separately from questions when the agent recommends an implementation direction, tradeoff or follow-up;
- give every non-blocking clarification or proposal a default, disposition or follow-up target before moving the task to `ready`;
- provide 2-3 options and a recommended option when a safe default exists;
- record `None blocking` only after the review finds no blocking questions requiring user confirmation;
- do not edit implementation artifacts while blocking clarification questions requiring user confirmation remain unresolved.

Readiness review may contain three kinds of items:
- blocking clarification questions - unresolved decisions requiring user confirmation before `ready`;
- non-blocking clarifications - useful questions or assumptions that can proceed with a documented default because they do not change task boundaries, architecture, validation behavior or destructive actions;
- readiness proposals - agent recommendations with rationale and disposition.

Rules:
- unresolved blocking questions keep the task in `readiness_review`;
- unresolved non-blocking clarifications do not block `ready` when a documented default is safe and reversible inside the task scope;
- proposals do not block `ready` when they have a disposition such as `accepted`, `deferred`, `rejected`, `documented`, `not_applicable`, `backlog` or `task`;
- if a non-blocking clarification later changes task boundaries, architecture, tooling, validation behavior or implementation approach, reclassify it as blocking and pause execution;
- if a proposal creates work outside the current task, record the target as a follow-up, backlog task or later task instead of silently expanding scope.

После подготовки вопросов агент обязан инициировать clarification dialog, если есть unresolved blocking questions requiring user confirmation.

Clarification dialog rules:
- задавать один вопрос за раз;
- давать 2-3 варианта ответа;
- помечать recommended option, если есть безопасный default;
- кратко объяснять tradeoff каждого варианта;
- позволять пользователю принять recommended option простым подтверждением;
- записывать принятый ответ в task как assumption or decision.

После ответа пользователя агент должен пересмотреть readiness questions.
Если ответ может изменить task boundaries, architecture, tooling, validation behavior or implementation approach, re-review выполняется сразу после этого ответа.
Если ответы независимы и не меняют форму задачи, re-review может выполняться после закрытия текущего набора вопросов.
Task can move to `ready` only after the final re-review confirms that no new blocking clarification questions requiring user confirmation remain.

Task cannot move to `ready` or `in_progress` while blocking clarification questions requiring user confirmation remain unresolved.
Task cannot move from `planned` directly to `in_progress`.
Task cannot move from `in_progress` directly to `done`.

Standalone task follows the same lifecycle and closure gates as implementation task.
If a standalone task discovers stage-level or plan-level decisions, it should be promoted into plan/stage work or paused until the appropriate planning record is updated.

`blocked` is used only for external blockers or missing upstream artifacts.
Ordinary unresolved readiness questions keep the task in `readiness_review`.

Splitting a not-yet-completed task is a planning edit, not a normal lifecycle status.

## 7. Route Questions To The Right Level

Readiness questions must be recorded at the level where the decision belongs.

Routing rules:
- task-level question: affects one executable task and its implementation choices;
- stage-level question: affects stage outcome, acceptance, decomposition, dependencies or readiness risks;
- plan-level question: affects roadmap goal, stage sequence, global scope, non-goals or source-of-truth policy.

If a task readiness review discovers a stage-level question, the agent must record it in `stage.md` and pause affected task execution until the stage question is resolved.
If a stage readiness review discovers a plan-level question, the agent must record it in `plan.md` and pause affected stage work until the plan question is resolved.
The agent should not hide plan-level or stage-level decisions inside a task assumption.

## 8. Apply Change Cascade

Перед реализацией нужно определить, какие слои затрагиваются.

Типовой порядок:

```text
planning
  -> concepts or methodology
    -> architecture
      -> reference/workflows
        -> schemas/templates/rules
          -> implementation
            -> examples/tests
```

Не каждый task проходит все уровни.
Но каждый task должен явно показать, какие уровни не затронуты.

## 9. Implement

Реализация выполняется только после того, как достаточный документированный контекст существует.

Если во время реализации обнаружено, что план или архитектура неверны, нужно сначала обновить соответствующий документ или выполнить это в том же change unit.

Перед изменением implementation artifacts task должна иметь `## Test Plan`.
Test plan фиксирует:
- task-specific tests for the changed behavior;
- related module tests for nearby contracts and dependencies;
- project regression checks before closing the task.

Перед изменением behavior нужно сначала найти связанные test case documents and executable tests.
Затем нужно обновить ожидаемое поведение в test case docs and executable tests before changing implementation, если изменение затрагивает documented stable behavior.

Это может означать:
- добавить новый test case document;
- обновить существующий test case document;
- добавить новый executable test;
- обновить существующий executable test;
- зафиксировать, что существующие test cases and executable tests already cover the change.

Если toolkit применяется в проекте с уже существующими executable tests but without test case docs, агент не должен создавать полный backfill test case documentation upfront.
Test case docs создаются инкрементально, когда task меняет stable behavior, covered by existing or new executable tests.
Если существующий executable test становится source of expected behavior для task, агент должен либо оформить его как test case doc, либо записать, почему он остаётся implementation-level test only.

Для bugfix or behavior-change tasks нужно сначала добавить или обновить тест, который воспроизводит требуемое поведение и падает на текущей реализации, если это применимо.
Исключения:
- task is documentation-only;
- existing failing test already covers the behavior;
- existing passing tests already cover the new expected behavior;
- behavior cannot be tested at the current layer, and the limitation is recorded in the task.

Test scope should match task risk and blast radius.
Task не обязана покрывать все возможные cases, но должна объяснять, почему выбранных проверок достаточно для текущего изменения.

## 10. Validate

Минимальная проверка task:
- acceptance criteria выполнены или явно перенесены;
- связанные документы обновлены;
- новые документы имеют YAML front matter;
- ссылки в `related` указывают на существующие документы, когда это возможно;
- implementation не вводит правила, отсутствующие в документации.
- task-specific tests запущены или явно объяснено, почему они неприменимы;
- related module tests запущены, если изменение затрагивает shared behavior or contracts;
- project regression checks запущены перед закрытием task, если test suite доступен.

Task record must include `## Validation` with executed commands and results.
If a validation command cannot be run, the reason and residual risk must be recorded.

До появления CLI часть проверок выполняется вручную.
После появления CLI workflow должен требовать `ai-docs validate`.

## 11. Task Closure Review

Before marking a task `done`, move it to `closure_review`.

Closure review is mandatory even when implementation, documentation updates and validation have passed.
Its purpose is to make non-blocking observations visible instead of silently losing them during task closure.

Closure review rules:
- inspect the implemented changes, validation evidence, documentation updates, test gaps and residual risks;
- separate blocking issues from non-blocking observations;
- keep the task out of `done` while blocking issues remain;
- record non-blocking observations, tradeoffs and follow-ups in `Closing Observations`;
- for each closing observation, explain its impact, what was done in the current task and why the selected disposition is sufficient;
- assign a disposition to every closing observation;
- check changed documentation against the project language policy;
- fill the task closure checklist;
- report closing observations to the user before marking the task `done`;
- include `Observation`, `Impact`, `Action taken`, `Disposition`, `Rationale` and `Follow-up` for each observation in the final response when observations exist;
- explicitly report `Closing observations: None.` in the final response when no observations are found.

Recommended closing observation format:

```md
- Observation: ...

  Impact:
  ...

  Action taken:
  ...

  Disposition:
  backlog | task | accepted_risk | documented | not_applicable | deferred

  Rationale:
  ...

  Follow-up:
  - Target: ...
    Requirement: ...
    Handoff status: recorded | deferred | blocked | not_applicable
    Handoff evidence: ...
```

Rules:
- `Impact` explains why the observation matters or what could happen if it is ignored;
- `Action taken` explains what was already done in the current change unit;
- `Disposition` records the current decision;
- `Rationale` explains why the disposition is acceptable;
- `Follow-up` names the next action or explicitly states `None`;
- every follow-up must be actionable: it must state the target, requirement, handoff status and handoff evidence or rationale;
- `Handoff status: recorded` means the target planning record, backlog task or documentation artifact was actually updated to account for the requirement;
- `Handoff status: deferred`, `blocked` or `not_applicable` must include the reason in handoff evidence;
- when `Disposition` is `task` or `backlog`, the target task or backlog task must explicitly include the transferred requirement before the observation is counted as resolved;
- observations without action, rationale or follow-up decision are unresolved and should not be counted as resolved in the closure checklist.
- final response should use the same expanded fields so the user can see what will happen with every observation.

Recommended closure checklist:

```yaml
closure:
  observations_recorded: true
  observations_reported_to_user: true
  observations_reported_with_disposition: true
  observations_resolved: true
  language_policy_checked: true
  blocking_issues: 0
  followups_recorded: true
```

The checklist does not replace the `closure_review` status.
The status controls the workflow; the checklist records that required closeout checks were performed.
`observations_reported_with_disposition` can be `true` only when the user-facing closure report included disposition, rationale and follow-up decision for every observation, or explicitly reported that there were no observations.

## 12. Close Or Replan Task

Task, including standalone task, считается закрытой, только если:
- результат отражён в документации;
- план обновлён при необходимости;
- follow-up явно зафиксирован and handed off when it has a target;
- validation evidence recorded;
- closing observations reviewed and reported to the user;
- every closing observation has impact, action taken, disposition, rationale and follow-up decision;
- repository state не противоречит acceptance criteria текущего stage.

Before closing a task, the agent must review the completed change for observations and report them to the user.
Observations may include:
- risks;
- tradeoffs;
- follow-ups;
- missing documentation;
- test gaps;
- validation limitations;
- improvement proposals;
- non-blocking questions relevant to later tasks.

If there are no observations, the agent should explicitly state that no additional observations were found.

Task record should include commit traceability in `execution.commits` front matter and in the human-readable `## Commits` section.
Commit messages should briefly describe the substance of the change and should not include planning task ids by default.
Task ids belong in task records and, after tracker migration, in task tracker connectors.
Because commit hashes are known only after commit creation, commit traceability may be updated by a later bookkeeping change or before export/archive.

Если scope оказался слишком большим, это оформляется как planning edit: not-yet-completed task заменяется меньшими tasks, а completed task получает follow-ups вместо split.
Если standalone task оказался больше одной change unit, он должен быть promoted into plan/stage or mini-plan before continuing broad implementation.

Если во время выполнения stage появляется новая task, которая нужна для продолжения текущего stage, она вставляется после последней completed task and before the first not-yet-completed task.
Planned tasks after the insertion point should be renumbered while they are still not completed.
Completed tasks should not be renumbered except to fix an obvious ordering mistake in the current uncommitted change unit.
Если новая task не блокирует текущий stage, она добавляется в конец как planned task.

## 13. Move Or Expand Task Placement

Backlog movement into execution is a placement move, not a new work identity and not a long-lived duplicate link.

When a backlog task is accepted into an active plan/stage:
- create or update the target implementation task;
- preserve the same task identity when a global task id already exists;
- copy the backlog task problem, expected result, relevant options and notes into the target task `Intake Context`;
- remove the backlog task from `ai-docs/planning/backlog.md`;
- delete the backlog task file when one exists;
- do not leave a tombstone by default;
- keep `backlog.md` `sequence.last_id` unchanged except when allocating a new compatibility backlog id;
- do not reuse removed backlog ids.

After movement, the target implementation task is the source of truth for the active work context.
Historical or external references to removed backlog tasks are outside the active documentation consistency guarantee.
Maintaining redirects, tombstones or external notifications is out of scope unless a project explicitly configures an archive or integration mechanism.

When a backlog task expands into a plan or plan stage:
- create or update the target plan or stage document;
- copy the full source task context into the target plan or stage before removing the source task;
- add `origin_task_id: TASK-NNNNNN` to the target plan or stage front matter;
- allocate new global task ids for child executable tasks created inside the target plan or stage;
- do not reuse the source task id for target child tasks;
- remove the source task from `ai-docs/planning/backlog.md`;
- delete the source backlog task file when one exists;
- do not leave a tombstone source task record by default.

After expansion, the target plan or stage is the active documentation entry point for the expanded work.
Task lookup for the removed source id may resolve through target `origin_task_id`.

When a task moves between placements:
- preserve the global task id when one exists;
- preserve problem, expected result, accepted decisions, validation evidence and follow-up handoff context;
- update the source and target planning indexes in the same change unit;
- keep placement-specific ordering fields local to the target placement.

When a task is expanded into a plan, stage or multiple tasks:
- record the expansion target as a plan, stage or task path/id before removing or archiving the source task;
- allocate new global task ids for newly created target tasks;
- copy the source task problem, expected result, decisions and relevant notes into the target plan/stage/task context;
- if the target is a plan or stage, record the source id in target `origin_task_id`;
- if the source was an active backlog task expanded into a plan or stage, remove it from the active backlog index and delete its file after successful context copy;
- do not execute the expanded source task one-to-one after expansion unless it is explicitly re-scoped.

Cancelled and deferred handling:
- use `deferred` when a task remains valid but intentionally postponed;
- use `cancelled` when the task should no longer be pursued in its current form;
- both states require rationale;
- if cancelled or deferred work leaves follow-up requirements, record actionable follow-up handoff with target and evidence.

## 14. Stage Closure Review

Перед переводом stage в `done` нужно выполнить stage closure review.

Stage closure review checks:
- required tasks are closed or explicitly deferred with rationale;
- stage acceptance criteria are satisfied or updated;
- validation evidence across the stage is sufficient;
- stage-level closing observations are recorded;
- every stage-level observation has a disposition and target or rationale;
- follow-ups are promoted to backlog, a later stage or new tasks;
- durable knowledge discovered during the stage is extracted into active source-of-truth documentation;
- plan status and next stage readiness are updated when needed.

If a task closing observation affects the whole stage, it should be escalated to stage `Closing Observations`.
If a stage observation affects roadmap direction or future plans, it should be escalated to plan closure or backlog.

Stage should not move from `in_progress` directly to `done` while blocking stage-level observations remain.

## 15. Plan Closure Review

Перед переводом plan в `done`, `exported` or `archived` нужно выполнить plan closure review.

Plan closure review checks:
- all stages have final status with rationale;
- plan goal is achieved or partial closure is explained;
- active source-of-truth documentation contains durable knowledge from the plan;
- completed execution records are exported or archived according to work history policy;
- backlog and follow-ups are current;
- links from current planning entry points are updated;
- remaining active work is represented by another plan, stage or task.

Plan-level closing observations must be recorded and dispositioned before plan closure.

Перед закрытием stage or plan нужно выполнить knowledge extraction:
- durable methodology changes move to reference, workflow or rules documents;
- architecture decisions move to architecture documents;
- user-facing process knowledge moves to guides;
- validation behavior moves to schemas, rules or acceptance docs;
- unresolved work becomes a new active task.

После закрытия completed records become work history.
Если configured tracker or archive существует, completed records may be exported there.
Если tracker/archive не настроен, completed records remain in repository archive.

Archived or exported execution records are not source of truth for current behavior by default.

---

# Required Task Record

На bootstrap-этапе implementation task можно фиксировать прямо в planning-документе.
Целевая модель - отдельные `implementation_task` documents, описанные в `.ai-docs/reference/planning-document-model.md`.

Минимальный формат:

```md
## Task: Replace README with product README

Status: planned
Stage: Phase 1

Source documents:
- docs/concepts/vision.md
- docs/architecture/repository-structure.md
- ai-docs/planning/backlog.md

Expected result:
- README explains toolkit purpose, status and navigation.

Test plan:
- manual README content review;
- link/path consistency review.

Acceptance checks:
- README is no longer GitLab boilerplate.
- README links to concepts, architecture and planning docs.
- No production code is added.

Cascade impact:
- planning: update task status
- product docs: update README
- architecture: no change expected
- implementation: no change expected

Validation:
- manual README content review passed;
- link/path consistency review passed.

Commits:
- None yet
```

Позже этот формат должен быть вынесен в отдельный template и проверяться CLI.

---

# Status Semantics

Implementation task statuses:
- `planned` - задача определена, работа не началась;
- `readiness_review` - task проверяется на готовность к выполнению;
- `ready` - blocking clarification questions закрыты, task можно выполнять;
- `in_progress` - задача выполняется;
- `closure_review` - implementation and validation завершены, closing observations and follow-ups проверяются перед закрытием;
- `blocked` - есть внешний блокер или отсутствующий upstream artifact;
- `done` - acceptance checks выполнены;
- `exported` - record перенесён во внешний tracker or archive;
- `archived` - record сохранён в локальном archive and excluded from default retrieval;
- `deferred` - задача осознанно перенесена.

Статус plan stage не должен переводиться в completed, пока не закрыты или явно перенесены все tasks, необходимые для его acceptance criteria.

---

# Bootstrap Rule

До появления schemas, templates и CLI этот workflow применяется вручную.

Репозиторий всё равно должен использовать собственную методологию:
- новые документы создаются с front matter;
- связи фиксируются в `related`;
- план обновляется вместе с результатом;
- отсутствие автоматической проверки не отменяет обязательность ручной проверки.
