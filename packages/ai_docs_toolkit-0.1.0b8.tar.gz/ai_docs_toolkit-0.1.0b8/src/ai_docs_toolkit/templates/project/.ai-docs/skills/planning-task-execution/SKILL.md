---
name: planning-task-execution
description: Use when executing work from ai-docs/planning records, changing planning lifecycle status, performing readiness review, or closing plan/stage/task records in an AI Docs Toolkit project.
---

# Planning Task Execution

Use this skill before editing implementation artifacts for any task selected from `ai-docs/planning/**`.

## Required Intake

Read, in order:
- `.ai-docs/workflows/plan-stage-workflow.md` for full workflow reference when needed;
- the active `plan.md`;
- the active `stage.md`, unless the record is standalone;
- the selected task record.

For normal execution, prefer this compact skill over loading full reference documents into every prompt.

Executable tasks in `readiness_review`, `ready`, `in_progress` or `closure_review` must include a checked `## Intake Checklist` proving intake was completed.

## Lifecycle Gates

Do not move planning records directly from `planned` to `in_progress`.

Required lifecycle:

```text
planned -> readiness_review -> ready -> in_progress -> closure_review -> done
```

Rules:
- plans, stages and executable tasks must pass through `readiness_review` before active work;
- records with unresolved blocking questions stay in `readiness_review`;
- records cannot move from `in_progress` directly to `done`;
- terminal records need closing observations, closure review and closure checklist;
- `accepted` is not an active execution gate; use `ready` after readiness review.

## Execution Rules

- Resolve blocking readiness questions before changing implementation artifacts.
- Keep documentation and implementation changes in the same change unit when behavior changes.
- Preserve `scope.plan`, `scope.stage`, `scope.task_order` and `related` links.
- Record validation commands and results before closure.
- Final user response must report closing observations, or explicitly say there are none.

## References

Load full references only when the compact rules are insufficient:
- `.ai-docs/workflows/plan-stage-workflow.md`
- `.ai-docs/reference/planning-document-model.md`
