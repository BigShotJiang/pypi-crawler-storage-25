# Version Change Checklist

- [ ] Target version selected from repository release policy
- [ ] Release channel selected
- [ ] Git tag format confirmed
- [ ] Version/tag mapping confirmed
- [ ] Package or application version metadata updated
- [ ] Runtime version output updated when separate from package metadata
- [ ] Versioned install or usage examples reviewed
- [ ] Tests that assert version output updated
- [ ] Previous published versions checked to avoid reuse
