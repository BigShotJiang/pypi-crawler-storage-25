---
name: release-publication
description: Use when preparing, publishing, or verifying a software release for any project stack. Guides agents through release task intake, version/tag decisions, validation evidence, publication evidence, and post-publication checks without assuming a package registry, CI provider, or programming language.
---

# Release Publication

Use this skill when the user asks to release, publish, tag, or verify a project version.

## Operating Rules

- Treat repository release policy as authoritative. Read local release/distribution reference files before changing versions, tags, CI, or artifacts.
- Do not assume a stack. Detect the package manager, registry, CI provider, tag format, and artifact type from the repository.
- Do not publish from ordinary validation work. Publication requires an explicit user request or a repository policy that already authorizes it.
- Keep release evidence in a planning task, release notes, or another repository-approved record.
- Never record credentials, tokens, or secret values.

## Intake

Before edits or publication:

1. Check git status and current branch.
2. Locate release policy and previous release evidence. Common paths:
   - `.ai-docs/reference/*release*`
   - `.ai-docs/reference/*distribution*`
   - `.ai-docs/reference/*ci*`
   - `ai-docs/planning/tasks/**`
   - `CHANGELOG.md`, `RELEASE.md`, `.github/**`, `.gitlab-ci.yml`
3. Determine the target version, release channel, tag, package index or distribution target.
4. Confirm the version/tag mapping from repository policy.
5. Create or update a release task using `.ai-docs/templates/release/release-task.md` when the repository uses ai-docs planning records.
6. When consumers may need upgrade work, prepare the migration note from `.ai-docs/templates/release/migration-note.md`.

## Generic Procedure

1. Prepare the release record.
2. Update version metadata and package-facing examples that must match the release.
3. Run repository validation and tests.
4. Build release artifacts.
5. Verify built artifacts locally in an isolated environment when possible.
6. Record validation evidence using `.ai-docs/templates/release/validation-evidence.md`.
7. Commit release preparation changes.
8. Create and push the release tag only after validation passes.
9. Wait for the release pipeline or publication workflow when one exists.
10. Verify installation or consumption from the published distribution target.
11. Prepare and report migration instructions for agents when users may upgrade from a previous version.
12. Record post-publication evidence and any skipped checks with rationale.

## Agent Migration Instructions

Every package release must explicitly report whether consumers need migration work after upgrading.
Do not rely on agents reconstructing migration steps from the repository diff.

When the release changes installed templates, validation rules, workflows, schemas, CLI behavior, document layout, front matter contracts or package-facing instructions, include an agent-ready migration note with:

- source and target versions;
- what changed for consumers;
- exact commands to run before and after migration;
- manual migration steps when no apply-mode command exists;
- files or namespaces that may be changed;
- ids, links or compatibility fields that must be preserved;
- validation commands and expected success criteria;
- known limitations, skipped checks and when to stop for human review.

If no migration is required, state that explicitly and still list the post-upgrade verification commands.

## Template Use

Use these generic templates when they fit the repository:

- `.ai-docs/templates/release/release-task.md` for release task records.
- `.ai-docs/templates/release/version-change-checklist.md` for version metadata review.
- `.ai-docs/templates/release/validation-evidence.md` for command evidence.
- `.ai-docs/templates/release/post-publication-checks.md` for install/consumption verification.
- `.ai-docs/templates/release/migration-note.md` for agent-ready upgrade and migration instructions.

Adapt template wording to the project. Keep project-specific registry commands out of the generic skill unless the repository policy already defines them.

## Completion Criteria

A release is complete only when:

- the selected version and tag match repository policy;
- validation and artifact checks are recorded;
- publication either succeeded and was verified, or the blocking external limitation is recorded;
- migration instructions for agents are reported, or the release explicitly states that no migration is required;
- local git state and pushed refs are reported to the user.
