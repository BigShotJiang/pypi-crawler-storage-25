"""AI Docs Toolkit package baseline."""

__version__ = "0.1.0b8"
