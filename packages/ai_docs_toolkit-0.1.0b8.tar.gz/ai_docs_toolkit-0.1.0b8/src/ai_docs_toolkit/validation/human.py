from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ai_docs_toolkit.core import (
    DocumentRegistry,
    RegistryDocument,
    SchemaValidator,
    build_document_registry,
    load_project_config,
    parse_markdown_file,
    registry_document_from_parsed,
    scan_markdown_files,
    validate_relationships_and_sections,
)

SCHEMA_UNSUPPORTED_DOCUMENT_TYPES = {
    "architecture",
    "backlog",
    "backlog_item",
    "concept",
    "planning",
    "reference",
    "request",
    "request_index",
    "workflow",
}


@dataclass(frozen=True)
class ValidationMessage:
    rule_id: str
    message: str
    path: str | None = None
    document_id: str | None = None
    severity: str = "error"


@dataclass(frozen=True)
class HumanValidationResult:
    exit_code: int
    messages: tuple[ValidationMessage, ...]
    scanned_files: int = 0
    validated_documents: int = 0
    schema_validated_documents: int = 0
    schema_skipped_documents: int = 0
    schema_skipped_types: tuple[tuple[str, int], ...] = ()

    @property
    def ok(self) -> bool:
        return self.exit_code == 0


@dataclass(frozen=True)
class SchemaValidationSummary:
    messages: tuple[ValidationMessage, ...]
    validated_documents: int = 0
    skipped_documents: int = 0
    skipped_types: tuple[tuple[str, int], ...] = ()


def validate_project_human(project_root: str | Path = ".") -> HumanValidationResult:
    root = Path(project_root).resolve()
    config_result = load_project_config(root)
    if not config_result.ok or config_result.config is None:
        return HumanValidationResult(
            exit_code=2,
            messages=tuple(
                ValidationMessage(
                    rule_id=error.code,
                    message=error.message,
                    path=error.path,
                )
                for error in config_result.errors
            ),
        )

    parse_messages: list[ValidationMessage] = []
    documents: list[RegistryDocument] = []
    markdown_files = scan_markdown_files(config_result.config)

    for path in markdown_files:
        parse_result = parse_markdown_file(path)
        if parse_result.document is None:
            parse_messages.extend(
                ValidationMessage(
                    rule_id=f"frontmatter.{error.code}",
                    message=error.message,
                    path=error.path,
                )
                for error in parse_result.errors
            )
            continue

        documents.append(registry_document_from_parsed(parse_result.document))

    registry = build_document_registry(tuple(documents))
    schema_result = _schema_validation(registry, config_result.config.schema_roots)
    messages = [
        *parse_messages,
        *_registry_messages(registry),
        *schema_result.messages,
        *_structure_messages(registry),
    ]
    has_errors = any(message.severity == "error" for message in messages)

    return HumanValidationResult(
        exit_code=1 if has_errors else 0,
        messages=tuple(messages),
        scanned_files=len(markdown_files),
        validated_documents=len(documents),
        schema_validated_documents=schema_result.validated_documents,
        schema_skipped_documents=schema_result.skipped_documents,
        schema_skipped_types=schema_result.skipped_types,
    )


def format_human_validation_result(result: HumanValidationResult) -> str:
    if result.exit_code == 0:
        return (
            "Validation passed.\n"
            f"Scanned files: {result.scanned_files}\n"
            f"Validated documents: {result.validated_documents}\n"
            f"Schema validated documents: {result.schema_validated_documents}\n"
            f"Schema skipped documents: {result.schema_skipped_documents}\n"
            f"Schema skipped types: {_format_skipped_types(result.schema_skipped_types)}"
        )

    lines = ["Validation failed.", "Issues:"]
    for message in result.messages:
        path = message.path or "<unknown>"
        document = f" [{message.document_id}]" if message.document_id else ""
        lines.append(f"- {path}{document} {message.rule_id}: {message.message}")
    return "\n".join(lines)


def format_json_validation_result(result: HumanValidationResult) -> str:
    payload = {
        "ok": result.ok,
        "summary": {
            "scanned_files": result.scanned_files,
            "validated_documents": result.validated_documents,
            "schema_validated_documents": result.schema_validated_documents,
            "schema_skipped_documents": result.schema_skipped_documents,
            "schema_skipped_types": {
                document_type: count
                for document_type, count in result.schema_skipped_types
            },
            "issue_count": len(result.messages),
        },
        "issues": [
            {
                "path": message.path,
                "document_id": message.document_id,
                "rule_id": message.rule_id,
                "severity": message.severity,
                "message": message.message,
            }
            for message in sorted(result.messages, key=_message_sort_key)
        ],
    }
    return json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True)


def _registry_messages(registry: DocumentRegistry) -> tuple[ValidationMessage, ...]:
    return tuple(
        ValidationMessage(
            rule_id=issue.rule_id,
            message=issue.message,
            path=", ".join(str(path) for path in issue.paths),
            document_id=issue.document_id,
            severity=issue.severity,
        )
        for issue in registry.issues
    )


def _schema_validation(
    registry: DocumentRegistry,
    schema_roots: tuple[Path, ...],
) -> SchemaValidationSummary:
    schemas_root = next((root for root in schema_roots if root.exists()), None)
    if schemas_root is None:
        return SchemaValidationSummary(messages=())
    validator = SchemaValidator.load(schemas_root)
    messages: list[ValidationMessage] = []
    validated_documents = 0
    skipped_documents = 0
    skipped_type_counts: dict[str, int] = {}

    for document in _schema_candidate_documents(registry):
        document_type = document.frontmatter.get("type")
        if isinstance(document_type, str) and document_type in SCHEMA_UNSUPPORTED_DOCUMENT_TYPES:
            skipped_documents += 1
            skipped_type_counts[document_type] = skipped_type_counts.get(document_type, 0) + 1
            continue

        result = validator.validate_frontmatter(
            document.frontmatter,
            path=str(document.path),
        )
        if isinstance(document_type, str) and document_type in validator.schemas_by_type:
            validated_documents += 1
        messages.extend(
            ValidationMessage(
                rule_id=issue.rule_id,
                message=issue.message,
                path=issue.path,
                document_id=issue.document_id,
                severity=issue.severity,
            )
            for issue in result.issues
        )
    return SchemaValidationSummary(
        messages=tuple(messages),
        validated_documents=validated_documents,
        skipped_documents=skipped_documents,
        skipped_types=tuple(sorted(skipped_type_counts.items())),
    )


def _format_skipped_types(skipped_types: tuple[tuple[str, int], ...]) -> str:
    if not skipped_types:
        return "none"
    return ", ".join(
        f"{document_type}={count}" for document_type, count in skipped_types
    )


def _structure_messages(registry: DocumentRegistry) -> tuple[ValidationMessage, ...]:
    result = validate_relationships_and_sections(registry)
    return tuple(
        ValidationMessage(
            rule_id=issue.rule_id,
            message=issue.message,
            path=str(issue.path),
            document_id=issue.document_id,
            severity=issue.severity,
        )
        for issue in result.issues
    )


def _schema_candidate_documents(
    registry: DocumentRegistry,
) -> tuple[RegistryDocument, ...]:
    documents: list[RegistryDocument] = []
    for path in sorted(registry.documents_by_path):
        documents.append(registry.documents_by_path[path])
    return tuple(documents)


def _message_sort_key(message: ValidationMessage) -> tuple[Any, ...]:
    return (
        message.path or "",
        message.document_id or "",
        message.rule_id,
        message.severity,
        message.message,
    )
