from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import date
from pathlib import Path

import yaml

from ai_docs_toolkit.core.frontmatter import parse_markdown_file


TASK_ID_PATTERN = re.compile(r"^TASK-\d{6}$")
STAGE_ID_PATTERN = re.compile(r"^STAGE-[A-Z0-9-]+-\d{3}$|^STAGE-\d{6}$")
PLAN_ID_PATTERN = re.compile(r"^PLAN-[A-Z0-9-]+-\d{3}$|^PLAN-\d{6}$")
SLUG_PATTERN = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
HEADING_PATTERN = re.compile(r"^(?P<hashes>#{1,6})\s+(?P<title>.+?)\s*$", re.MULTILINE)

TERMINAL_STATUSES = {"done", "cancelled", "exported", "archived", "deprecated"}


@dataclass(frozen=True)
class PlanningIssue:
    rule_id: str
    message: str
    path: str | None = None


@dataclass(frozen=True)
class PlanningChange:
    path: str
    description: str


@dataclass(frozen=True)
class PlanningOperationResult:
    ok: bool
    command: str
    dry_run: bool = False
    target_id: str | None = None
    current_status: str | None = None
    next_status: str | None = None
    changes: tuple[PlanningChange, ...] = ()
    issues: tuple[PlanningIssue, ...] = ()
    warnings: tuple[str, ...] = ()
    no_op: bool = False

    @property
    def exit_code(self) -> int:
        return 0 if self.ok else 1


@dataclass(frozen=True)
class PlanningReviewResult:
    ok: bool
    stage_id: str
    blocking_questions: tuple[str, ...]
    non_blocking_questions: tuple[str, ...]
    proposals: tuple[dict[str, object], ...]
    missing_docs_tests: tuple[str, ...]
    readiness_decision: str
    suggested_task_split: tuple[str, ...]

    @property
    def exit_code(self) -> int:
        return 0 if self.ok else 1


def start_task(
    project_root: str | Path,
    *,
    task_id: str,
    dry_run: bool = False,
) -> PlanningOperationResult:
    root = Path(project_root).resolve()
    task = _load_document_by_id(root, task_id)
    if task is None:
        return _error("start-task", task_id, f"Task `{task_id}` was not found.")

    status = _status(task)
    if status == "in_progress":
        return PlanningOperationResult(
            ok=True,
            command="start-task",
            dry_run=dry_run,
            target_id=task_id,
            current_status=status,
            next_status=status,
            no_op=True,
        )
    if status not in {"planned", "readiness_review", "ready"}:
        return _error(
            "start-task",
            task_id,
            f"Task `{task_id}` cannot be started from status `{status}`.",
            path=_rel(task.path, root),
            current_status=status,
        )

    task_text = task.path.read_text(encoding="utf-8")
    new_task_text = _set_frontmatter_status(task_text, "in_progress")
    new_task_text = _ensure_intake_checklist(new_task_text)
    new_task_text = _ensure_readiness_section(new_task_text)

    changes = [
        PlanningChange(_rel(task.path, root), f"set task `{task_id}` to `in_progress`"),
    ]
    writes: list[tuple[Path, str]] = [(task.path, new_task_text)]

    stage = _parent_stage(root, task)
    if stage is not None and _is_first_stage_task(root, stage, task_id):
        stage_text = stage.path.read_text(encoding="utf-8")
        stage_status = _status(stage)
        if stage_status in {"planned", "readiness_review"}:
            stage_text = _set_frontmatter_status(stage_text, "ready")
            stage_text = _replace_section_status(stage_text, "Readiness", "ready")
            writes.append((stage.path, stage_text))
            changes.append(
                PlanningChange(
                    _rel(stage.path, root),
                    "prepare parent stage for first task by setting status to `ready`",
                )
            )

    if not dry_run:
        _write_all(writes)

    return PlanningOperationResult(
        ok=True,
        command="start-task",
        dry_run=dry_run,
        target_id=task_id,
        current_status=status,
        next_status="in_progress",
        changes=tuple(changes),
    )


def close_task(
    project_root: str | Path,
    *,
    task_id: str,
    dry_run: bool = False,
) -> PlanningOperationResult:
    root = Path(project_root).resolve()
    task = _load_document_by_id(root, task_id)
    if task is None:
        return _error("close-task", task_id, f"Task `{task_id}` was not found.")

    status = _status(task)
    if status == "done":
        return PlanningOperationResult(
            ok=True,
            command="close-task",
            dry_run=dry_run,
            target_id=task_id,
            current_status=status,
            next_status=status,
            no_op=True,
        )
    if status not in {"in_progress", "closure_review", "ready"}:
        return _error(
            "close-task",
            task_id,
            f"Task `{task_id}` cannot be closed from status `{status}`.",
            path=_rel(task.path, root),
            current_status=status,
        )

    task_text = task.path.read_text(encoding="utf-8")
    task_text = _set_frontmatter_status(task_text, "done")
    task_text = _ensure_closure_sections(task_text)
    changes = [PlanningChange(_rel(task.path, root), f"set task `{task_id}` to `done`")]
    writes: list[tuple[Path, str]] = [(task.path, task_text)]

    stage = _parent_stage(root, task)
    if stage is not None:
        stage_text = stage.path.read_text(encoding="utf-8")
        stage_text = _update_child_summary_status(stage_text, task_id, "done")
        changes.append(
            PlanningChange(
                _rel(stage.path, root),
                f"update parent stage summary for `{task_id}` to `done`",
            )
        )
        if _is_last_stage_task(root, stage, task_id):
            stage_text = _set_frontmatter_status(stage_text, "done")
            stage_text = _ensure_closure_sections(stage_text)
            changes.append(
                PlanningChange(
                    _rel(stage.path, root),
                    "close parent stage because the last stage task is closed",
                )
            )
        writes.append((stage.path, stage_text))

    if not dry_run:
        _write_all(writes)

    return PlanningOperationResult(
        ok=True,
        command="close-task",
        dry_run=dry_run,
        target_id=task_id,
        current_status=status,
        next_status="done",
        changes=tuple(changes),
    )


def start_stage(
    project_root: str | Path,
    *,
    stage_id: str,
    dry_run: bool = False,
) -> PlanningOperationResult:
    root = Path(project_root).resolve()
    stage = _load_document_by_id(root, stage_id)
    if stage is None:
        return _error("start-stage", stage_id, f"Stage `{stage_id}` was not found.")
    status = _status(stage)
    if status == "in_progress":
        return PlanningOperationResult(True, "start-stage", dry_run, stage_id, status, status, no_op=True)
    if status not in {"planned", "readiness_review", "ready"}:
        return _error("start-stage", stage_id, f"Stage `{stage_id}` cannot be started from status `{status}`.", path=_rel(stage.path, root), current_status=status)
    text = _set_frontmatter_status(stage.path.read_text(encoding="utf-8"), "in_progress")
    text = _ensure_readiness_section(text)
    if not dry_run:
        stage.path.write_text(text, encoding="utf-8")
    return PlanningOperationResult(True, "start-stage", dry_run, stage_id, status, "in_progress", (PlanningChange(_rel(stage.path, root), f"set stage `{stage_id}` to `in_progress`"),))


def close_stage(
    project_root: str | Path,
    *,
    stage_id: str,
    dry_run: bool = False,
) -> PlanningOperationResult:
    root = Path(project_root).resolve()
    stage = _load_document_by_id(root, stage_id)
    if stage is None:
        return _error("close-stage", stage_id, f"Stage `{stage_id}` was not found.")
    status = _status(stage)
    if status == "done":
        return PlanningOperationResult(True, "close-stage", dry_run, stage_id, status, status, no_op=True)
    if status not in {"in_progress", "closure_review", "ready"}:
        return _error("close-stage", stage_id, f"Stage `{stage_id}` cannot be closed from status `{status}`.", path=_rel(stage.path, root), current_status=status)
    text = _set_frontmatter_status(stage.path.read_text(encoding="utf-8"), "done")
    text = _ensure_closure_sections(text)
    if not dry_run:
        stage.path.write_text(text, encoding="utf-8")
    return PlanningOperationResult(True, "close-stage", dry_run, stage_id, status, "done", (PlanningChange(_rel(stage.path, root), f"set stage `{stage_id}` to `done`"),))


def add_stage(
    project_root: str | Path,
    *,
    plan_id: str,
    stage_slug: str,
    dry_run: bool = False,
) -> PlanningOperationResult:
    root = Path(project_root).resolve()
    plan = _load_document_by_id(root, plan_id)
    if plan is None:
        return _error("add-stage", plan_id, f"Plan `{plan_id}` was not found.")
    if not SLUG_PATTERN.fullmatch(stage_slug):
        return _error("add-stage", plan_id, "`--stage` must be lowercase kebab-case.")

    plan_dir = plan.path.parent
    stage_number = _next_stage_number(plan_dir)
    stage_path = plan_dir / f"stage-{stage_number}-{stage_slug}" / "stage.md"
    stage_id = _stage_id_from_plan(plan_id, stage_number)
    if stage_path.exists():
        return _error("add-stage", plan_id, f"Stage path `{_rel(stage_path, root)}` already exists.")
    content = _stage_template(plan, stage_id, stage_slug)
    if not dry_run:
        stage_path.parent.mkdir(parents=True, exist_ok=True)
        stage_path.write_text(content, encoding="utf-8")
    return PlanningOperationResult(True, "add-stage", dry_run, stage_id, None, "planned", (PlanningChange(_rel(stage_path, root), "create stage record"),))


def add_task(
    project_root: str | Path,
    *,
    stage_id: str,
    task_slug: str,
    dry_run: bool = False,
) -> PlanningOperationResult:
    root = Path(project_root).resolve()
    stage = _load_document_by_id(root, stage_id)
    if stage is None:
        return _error("add-task", stage_id, f"Stage `{stage_id}` was not found.")
    if not SLUG_PATTERN.fullmatch(task_slug):
        return _error("add-task", stage_id, "`--task` must be lowercase kebab-case.")
    task_id = _next_task_id(root)
    order = _next_task_order(stage.path.parent)
    task_path = stage.path.parent / f"task-{order}-{task_slug}.md"
    if task_path.exists():
        return _error("add-task", stage_id, f"Task path `{_rel(task_path, root)}` already exists.")
    content = _task_template(stage, task_id, task_slug, order)
    changes = [PlanningChange(_rel(task_path, root), f"create task `{task_id}`")]
    writes: list[tuple[Path, str]] = [(task_path, content)]
    registry = root / "ai-docs" / "planning" / "task-registry.md"
    if registry.exists():
        registry_text = _append_task_registry_entry(
            registry.read_text(encoding="utf-8"),
            task_id,
            _rel(task_path, root),
        )
        writes.append((registry, registry_text))
        changes.append(PlanningChange(_rel(registry, root), f"allocate `{task_id}`"))
    if not dry_run:
        task_path.parent.mkdir(parents=True, exist_ok=True)
        _write_all(writes)
    return PlanningOperationResult(True, "add-task", dry_run, task_id, None, "planned", tuple(changes))


def review_stage(project_root: str | Path, *, stage_id: str) -> PlanningReviewResult:
    root = Path(project_root).resolve()
    stage = _load_document_by_id(root, stage_id)
    if stage is None:
        return PlanningReviewResult(False, stage_id, (f"Stage `{stage_id}` was not found.",), (), (), (), "blocked", ())
    text = stage.path.read_text(encoding="utf-8")
    headings = set(_headings(text))
    missing: list[str] = []
    for section in ("Outcome", "Scope", "Task Decomposition", "Validation"):
        if section not in headings:
            missing.append(f"Missing `## {section}` section.")
    tasks = _stage_task_ids(stage)
    if not tasks:
        missing.append("Stage has no related task ids.")
    decision = "ready" if not missing else "not_ready"
    proposals = (
        {
            "proposal": "Keep stage review read-only.",
            "options": ["record findings manually", "generate patch automatically"],
            "recommended": "record findings manually",
        },
    )
    return PlanningReviewResult(
        ok=True,
        stage_id=stage_id,
        blocking_questions=tuple(missing),
        non_blocking_questions=(),
        proposals=proposals,
        missing_docs_tests=tuple(missing),
        readiness_decision=decision,
        suggested_task_split=tuple(tasks),
    )


def autofix_planning(project_root: str | Path, *, dry_run: bool = False) -> PlanningOperationResult:
    root = Path(project_root).resolve()
    changes: list[PlanningChange] = []
    writes: list[tuple[Path, str]] = []
    for path in sorted((root / "ai-docs" / "planning").rglob("*.md")):
        parsed = parse_markdown_file(path)
        if parsed.document is None:
            continue
        doc_type = parsed.document.frontmatter.get("type")
        if doc_type not in {"plan", "plan_stage", "implementation_task", "standalone_task"}:
            continue
        text = path.read_text(encoding="utf-8")
        fixed = text
        if parsed.document.frontmatter.get("status") in {"ready", "in_progress", "closure_review", "done"}:
            fixed = _ensure_readiness_section(fixed)
        if parsed.document.frontmatter.get("status") in {"closure_review", "done"}:
            fixed = _ensure_closure_sections(fixed)
        if fixed != text:
            changes.append(PlanningChange(_rel(path, root), "apply safe planning skeleton fixes"))
            writes.append((path, fixed))
    if not dry_run:
        _write_all(writes)
    return PlanningOperationResult(True, "validate --fix-planning", dry_run, changes=tuple(changes), no_op=not changes)


def format_planning_operation_human(result: PlanningOperationResult) -> str:
    lines = [f"ai-docs plan {result.command}", f"status: {'ok' if result.ok else 'error'}", f"dry_run: {str(result.dry_run).lower()}"]
    if result.target_id:
        lines.append(f"target: {result.target_id}")
    if result.current_status or result.next_status:
        lines.append(f"transition: {result.current_status or 'none'} -> {result.next_status or 'none'}")
    if result.no_op:
        lines.append("no_op: true")
    lines.append("changes:")
    if result.changes:
        for change in result.changes:
            lines.append(f"- {change.path}: {change.description}")
    else:
        lines.append("- none")
    if result.issues:
        lines.append("issues:")
        for issue in result.issues:
            suffix = f" ({issue.path})" if issue.path else ""
            lines.append(f"- {issue.rule_id}{suffix}: {issue.message}")
    return "\n".join(lines)


def format_planning_operation_json(result: PlanningOperationResult) -> str:
    return json.dumps(
        {
            "ok": result.ok,
            "command": result.command,
            "dry_run": result.dry_run,
            "target_id": result.target_id,
            "current_status": result.current_status,
            "next_status": result.next_status,
            "no_op": result.no_op,
            "changes": [change.__dict__ for change in result.changes],
            "issues": [issue.__dict__ for issue in result.issues],
            "warnings": list(result.warnings),
            "exit_code": result.exit_code,
        },
        indent=2,
        sort_keys=True,
    )


def format_stage_review_human(result: PlanningReviewResult) -> str:
    lines = ["ai-docs plan review-stage", f"stage: {result.stage_id}", f"readiness_decision: {result.readiness_decision}"]
    for label, values in (
        ("blocking_questions", result.blocking_questions),
        ("non_blocking_questions", result.non_blocking_questions),
        ("missing_docs_tests", result.missing_docs_tests),
        ("suggested_task_split", result.suggested_task_split),
    ):
        lines.append(f"{label}:")
        lines.extend([f"- {value}" for value in values] or ["- none"])
    lines.append("proposals:")
    if result.proposals:
        for proposal in result.proposals:
            lines.append(f"- {proposal['proposal']}")
            options = proposal.get("options")
            if isinstance(options, list):
                lines.append(f"  options: {', '.join(str(option) for option in options)}")
            lines.append(f"  recommended: {proposal.get('recommended', 'none')}")
    else:
        lines.append("- none")
    return "\n".join(lines)


def format_stage_review_json(result: PlanningReviewResult) -> str:
    return json.dumps(
        {
            "ok": result.ok,
            "stage_id": result.stage_id,
            "blocking_questions": list(result.blocking_questions),
            "non_blocking_questions": list(result.non_blocking_questions),
            "proposals": list(result.proposals),
            "missing_docs_tests": list(result.missing_docs_tests),
            "readiness_decision": result.readiness_decision,
            "suggested_task_split": list(result.suggested_task_split),
            "exit_code": result.exit_code,
        },
        indent=2,
        sort_keys=True,
    )


@dataclass(frozen=True)
class _LoadedDocument:
    path: Path
    frontmatter: dict[str, object]


def _load_document_by_id(root: Path, document_id: str) -> _LoadedDocument | None:
    planning_root = root / "ai-docs" / "planning"
    if not planning_root.exists():
        return None
    for path in sorted(planning_root.rglob("*.md")):
        parsed = parse_markdown_file(path)
        if parsed.document is None:
            continue
        if parsed.document.frontmatter.get("id") == document_id:
            return _LoadedDocument(path=path.resolve(), frontmatter=dict(parsed.document.frontmatter))
    return None


def _status(document: _LoadedDocument) -> str:
    value = document.frontmatter.get("status")
    return value if isinstance(value, str) else ""


def _rel(path: Path, root: Path) -> str:
    try:
        return path.resolve().relative_to(root).as_posix()
    except ValueError:
        return str(path)


def _error(
    command: str,
    target_id: str,
    message: str,
    *,
    path: str | None = None,
    current_status: str | None = None,
) -> PlanningOperationResult:
    return PlanningOperationResult(
        ok=False,
        command=command,
        target_id=target_id,
        current_status=current_status,
        issues=(PlanningIssue(f"planning.{command}.invalid", message, path),),
    )


def _frontmatter_bounds(text: str) -> tuple[int, int] | None:
    if not text.startswith("---\n"):
        return None
    end = text.find("\n---\n", 4)
    if end < 0:
        return None
    return 4, end


def _set_frontmatter_status(text: str, status: str) -> str:
    bounds = _frontmatter_bounds(text)
    if bounds is None:
        return text
    start, end = bounds
    frontmatter = yaml.safe_load(text[start:end]) or {}
    frontmatter["status"] = status
    rendered = yaml.safe_dump(frontmatter, sort_keys=False, allow_unicode=False).strip()
    return f"---\n{rendered}\n---\n{text[end + 5:]}"


def _headings(text: str) -> tuple[str, ...]:
    return tuple(match.group("title").strip() for match in HEADING_PATTERN.finditer(text) if match.group("hashes") == "##")


def _ensure_section(text: str, title: str, body: str) -> str:
    if title in _headings(text):
        return text
    suffix = "" if text.endswith("\n") else "\n"
    return f"{text}{suffix}\n## {title}\n\n{body.rstrip()}\n"


def _ensure_intake_checklist(text: str) -> str:
    return _ensure_section(
        text,
        "Intake Checklist",
        "- [x] Read `.ai-docs/workflows/plan-stage-workflow.md`\n- [x] Read active plan\n- [x] Read active stage\n- [x] Read this task",
    )


def _ensure_readiness_section(text: str) -> str:
    return _ensure_section(text, "Readiness", "Status: ready\n\nBlocking questions:\n- None.")


def _ensure_closure_sections(text: str) -> str:
    text = _ensure_section(text, "Closure Review", "Blocking issues: None.\n\nNon-blocking observations: None.")
    text = _ensure_section(text, "Closing Observations", "None.")
    text = _ensure_section(
        text,
        "Closure Checklist",
        "```yaml\ndocumentation_updated: true\nvalidation_recorded: true\ntests_recorded: true\nblocking_issues: false\nclosing_observations_recorded: true\nobservations_reported_with_disposition: true\n```",
    )
    return text


def _replace_section_status(text: str, title: str, status: str) -> str:
    pattern = re.compile(rf"(## {re.escape(title)}\n\nStatus: )\w+")
    if pattern.search(text):
        return pattern.sub(rf"\g<1>{status}", text, count=1)
    return _ensure_section(text, title, f"Status: {status}\n\nBlocking questions:\n- None.")


def _write_all(writes: list[tuple[Path, str]]) -> None:
    for path, text in writes:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")


def _stage_task_ids(stage: _LoadedDocument) -> tuple[str, ...]:
    related = stage.frontmatter.get("related")
    if not isinstance(related, dict):
        return ()
    tasks = related.get("tasks")
    if not isinstance(tasks, list):
        return ()
    return tuple(task for task in tasks if isinstance(task, str) and TASK_ID_PATTERN.fullmatch(task))


def _parent_stage(root: Path, task: _LoadedDocument) -> _LoadedDocument | None:
    stage_id = None
    related = task.frontmatter.get("related")
    if isinstance(related, dict):
        stages = related.get("stages")
        if isinstance(stages, list):
            stage_id = next((item for item in stages if isinstance(item, str)), None)
    return _load_document_by_id(root, stage_id) if stage_id else None


def _is_first_stage_task(root: Path, stage: _LoadedDocument, task_id: str) -> bool:
    tasks = _stage_task_ids(stage)
    return bool(tasks) and tasks[0] == task_id


def _is_last_stage_task(root: Path, stage: _LoadedDocument, task_id: str) -> bool:
    tasks = _stage_task_ids(stage)
    return bool(tasks) and tasks[-1] == task_id


def _update_child_summary_status(text: str, task_id: str, status: str) -> str:
    # Prefer exact task id mentions when present; otherwise leave the body unchanged.
    pattern = re.compile(rf"(- Task \d+: {re.escape(task_id)} .*\n(?:.*\n)*?Status: )\w+", re.MULTILINE)
    if pattern.search(text):
        return pattern.sub(rf"\g<1>{status}", text, count=1)
    return text


def _next_stage_number(plan_dir: Path) -> int:
    numbers = []
    for path in plan_dir.glob("stage-*"):
        match = re.match(r"stage-(\d+)-", path.name)
        if match:
            numbers.append(int(match.group(1)))
    return (max(numbers) + 1) if numbers else 1


def _next_task_order(stage_dir: Path) -> int:
    numbers = []
    for path in stage_dir.glob("task-*.md"):
        match = re.match(r"task-(\d+)-", path.name)
        if match:
            numbers.append(int(match.group(1)))
    return (max(numbers) + 1) if numbers else 1


def _stage_id_from_plan(plan_id: str, stage_number: int) -> str:
    stem = plan_id.removeprefix("PLAN-").removesuffix("-001")
    return f"STAGE-{stem}-STAGE-{stage_number}-001"


def _stage_template(plan: _LoadedDocument, stage_id: str, stage_slug: str) -> str:
    plan_slug = _scope_value(plan, "plan")
    return f"""---
id: {stage_id}
type: plan_stage
status: planned
scope:
  plan: {plan_slug}
  stage: {stage_slug}
  modules: []
owners:
  - maintainers
related:
  plans:
    - {plan.frontmatter.get("id")}
  tasks: []
ai:
  priority: medium
  load_when:
    - topic: planning
---

# {_title(stage_slug)}

## Outcome

Pending.

## Scope

- Pending.

## Task Decomposition

Status: planned

## Validation

Planned validation:
- `.venv/bin/ai-docs validate`

## Result

Planned.
"""


def _task_template(stage: _LoadedDocument, task_id: str, task_slug: str, order: int) -> str:
    plan_slug = _scope_value(stage, "plan")
    stage_slug = _scope_value(stage, "stage")
    return f"""---
id: {task_id}
type: implementation_task
status: planned
scope:
  placement: plan_stage
  plan: {plan_slug}
  stage: {stage_slug}
  task_order: {order}
  modules: []
owners:
  - maintainers
related:
  stages:
    - {stage.frontmatter.get("id")}
ai:
  priority: medium
  load_when:
    - topic: planning
---

# Task {order}: {_title(task_slug)}

## Purpose

Pending.

## Expected Changes

- Pending.

## Acceptance Criteria

- Pending.

## Test Plan

- Run `.venv/bin/ai-docs validate`.

## Validation

- Pending.

## Result

Planned.
"""


def _scope_value(document: _LoadedDocument, key: str) -> str:
    scope = document.frontmatter.get("scope")
    if isinstance(scope, dict) and isinstance(scope.get(key), str):
        return scope[key]
    return ""


def _title(slug: str) -> str:
    return " ".join(part.capitalize() for part in slug.split("-"))


def _next_task_id(root: Path) -> str:
    registry = root / "ai-docs" / "planning" / "task-registry.md"
    if not registry.exists():
        return f"TASK-{date.today().day:06d}"
    parsed = parse_markdown_file(registry)
    if parsed.document is None:
        return "TASK-000001"
    sequence = parsed.document.frontmatter.get("sequence")
    last = sequence.get("last_number", 0) if isinstance(sequence, dict) else 0
    if not isinstance(last, int):
        last = 0
    return f"TASK-{last + 1:06d}"


def _append_task_registry_entry(text: str, task_id: str, task_path: str) -> str:
    bounds = _frontmatter_bounds(text)
    if bounds is None:
        return text
    start, end = bounds
    frontmatter = yaml.safe_load(text[start:end]) or {}
    sequence = frontmatter.setdefault("sequence", {})
    if isinstance(sequence, dict):
        sequence["last_number"] = int(task_id.removeprefix("TASK-"))
    task_index = frontmatter.setdefault("task_index", [])
    if isinstance(task_index, list):
        task_index.append({"id": task_id, "path": task_path})
    rendered = yaml.safe_dump(frontmatter, sort_keys=False, allow_unicode=False).strip()
    body = text[end + 5:]
    table_line = f"| {task_id} | {task_path} |"
    if "| Task ID | Current path |" in body and table_line not in body:
        body = body.replace("\n## Lookup Contract", f"\n{table_line}\n\n## Lookup Contract")
    return f"---\n{rendered}\n---\n{body}"
