from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ai_docs_toolkit.core.frontmatter import ParsedMarkdownDocument


RULE_DOCUMENT_ID_MISSING = "document.id.missing"
RULE_DOCUMENT_ID_DUPLICATE = "document.id.duplicate"
RULE_DOCUMENT_ALIAS_DUPLICATE = "document.alias.duplicate"
RULE_DOCUMENT_ALIAS_COLLIDES_WITH_ID = "document.alias.collides_with_id"


@dataclass(frozen=True)
class RegistryDocument:
    path: Path
    frontmatter: dict[str, Any]
    body: str = ""
    raw_frontmatter: str = ""

    @property
    def document_id(self) -> str | None:
        value = self.frontmatter.get("id")
        return value if isinstance(value, str) and value else None

    @property
    def aliases(self) -> tuple[str, ...]:
        value = self.frontmatter.get("aliases")
        if not isinstance(value, list):
            return ()
        aliases: list[str] = []
        for alias in value:
            if isinstance(alias, str) and alias:
                aliases.append(alias)
        return tuple(dict.fromkeys(aliases))


@dataclass(frozen=True)
class RegistryIssue:
    rule_id: str
    message: str
    paths: tuple[Path, ...]
    document_id: str | None = None
    severity: str = "error"


@dataclass(frozen=True)
class DocumentRegistry:
    documents_by_path: dict[Path, RegistryDocument]
    documents_by_id: dict[str, RegistryDocument]
    issues: tuple[RegistryIssue, ...] = ()

    @property
    def ok(self) -> bool:
        return not self.issues

    def get_by_path(self, path: str | Path) -> RegistryDocument | None:
        return self.documents_by_path.get(Path(path).resolve())

    def get_by_id(self, document_id: str) -> RegistryDocument | None:
        return self.documents_by_id.get(document_id)


def build_document_registry(
    documents: list[RegistryDocument] | tuple[RegistryDocument, ...],
) -> DocumentRegistry:
    documents_by_path = {document.path.resolve(): document for document in documents}
    id_groups: dict[str, list[RegistryDocument]] = {}
    alias_groups: dict[str, list[RegistryDocument]] = {}
    issues: list[RegistryIssue] = []

    for document in documents:
        document_id = document.document_id
        if document_id is None:
            issues.append(
                RegistryIssue(
                    rule_id=RULE_DOCUMENT_ID_MISSING,
                    message="Document front matter must define a non-empty string `id`.",
                    paths=(document.path.resolve(),),
                )
            )
            continue

        id_groups.setdefault(document_id, []).append(document)
        for alias in document.aliases:
            alias_groups.setdefault(alias, []).append(document)

    documents_by_id: dict[str, RegistryDocument] = {}
    for document_id, group in id_groups.items():
        if len(group) == 1:
            documents_by_id[document_id] = group[0]
            continue

        paths = tuple(sorted(document.path.resolve() for document in group))
        issues.append(
            RegistryIssue(
                rule_id=RULE_DOCUMENT_ID_DUPLICATE,
                message=f"Document id `{document_id}` is used by multiple documents.",
                paths=paths,
                document_id=document_id,
            )
        )

    for alias, group in alias_groups.items():
        primary_group = id_groups.get(alias, [])
        if primary_group:
            paths = tuple(
                sorted(
                    document.path.resolve()
                    for document in [*primary_group, *group]
                )
            )
            issues.append(
                RegistryIssue(
                    rule_id=RULE_DOCUMENT_ALIAS_COLLIDES_WITH_ID,
                    message=(
                        f"Document alias `{alias}` collides with a primary "
                        "document id."
                    ),
                    paths=paths,
                    document_id=alias,
                )
            )
            continue

        unique_paths = {document.path.resolve() for document in group}
        if len(unique_paths) == 1:
            documents_by_id[alias] = group[0]
            continue

        paths = tuple(sorted(unique_paths))
        issues.append(
            RegistryIssue(
                rule_id=RULE_DOCUMENT_ALIAS_DUPLICATE,
                message=f"Document alias `{alias}` is used by multiple documents.",
                paths=paths,
                document_id=alias,
            )
        )

    return DocumentRegistry(
        documents_by_path=documents_by_path,
        documents_by_id=documents_by_id,
        issues=tuple(issues),
    )


def registry_document_from_parsed(
    parsed_document: ParsedMarkdownDocument,
) -> RegistryDocument:
    if parsed_document.path is None:
        raise ValueError("Parsed document path is required for registry indexing.")

    return RegistryDocument(
        path=Path(parsed_document.path).resolve(),
        frontmatter=parsed_document.frontmatter,
        body=parsed_document.body,
        raw_frontmatter=parsed_document.raw_frontmatter,
    )
