from __future__ import annotations

import subprocess
from dataclasses import dataclass
from pathlib import Path

from ai_docs_toolkit.core.config import ToolkitConfig
from ai_docs_toolkit.core.registry import DocumentRegistry


@dataclass(frozen=True)
class ChangedFileIssue:
    rule_id: str
    message: str
    path: str | None = None
    document_id: str | None = None
    severity: str = "warning"


@dataclass(frozen=True)
class GitChangedFilesResult:
    changed_files: tuple[str, ...]
    issues: tuple[ChangedFileIssue, ...] = ()


@dataclass(frozen=True)
class ChangedDocumentSourcesResult:
    source_ids: tuple[str, ...]
    changed_files_by_id: dict[str, str]
    issues: tuple[ChangedFileIssue, ...] = ()


def read_git_changed_files(
    root: Path,
    *,
    unavailable_rule_id: str,
) -> GitChangedFilesResult:
    process = subprocess.run(
        ["git", "status", "--porcelain", "--untracked-files=all"],
        cwd=root,
        capture_output=True,
        text=True,
        check=False,
    )
    if process.returncode != 0:
        return GitChangedFilesResult(
            changed_files=(),
            issues=(
                ChangedFileIssue(
                    rule_id=unavailable_rule_id,
                    message=process.stderr.strip()
                    or "Unable to read changed files from Git status.",
                    severity="error",
                ),
            ),
        )

    return GitChangedFilesResult(
        changed_files=tuple(sorted(set(parse_git_status_porcelain(process.stdout))))
    )


def parse_git_status_porcelain(output: str) -> tuple[str, ...]:
    changed_files: list[str] = []
    for line in output.splitlines():
        if len(line) < 4:
            continue

        path = line[3:]
        if " -> " in path:
            path = path.split(" -> ", maxsplit=1)[1]

        if path:
            changed_files.append(path)

    return tuple(changed_files)


def resolve_changed_document_sources(
    changed_files: tuple[str, ...],
    *,
    config: ToolkitConfig,
    registry: DocumentRegistry,
    root: Path,
    outside_docs_rule_id: str,
    not_document_rule_id: str,
) -> ChangedDocumentSourcesResult:
    source_ids: list[str] = []
    changed_files_by_id: dict[str, str] = {}
    issues: list[ChangedFileIssue] = []

    for changed_file in changed_files:
        changed_path = (root / changed_file).resolve()
        if not is_inside_documentation_roots(changed_path, config):
            issues.append(
                ChangedFileIssue(
                    rule_id=outside_docs_rule_id,
                    message=(
                        f"Changed file `{changed_file}` is outside configured "
                        "documentation roots."
                    ),
                    path=changed_file,
                    severity="warning",
                )
            )
            continue

        document = registry.get_by_path(changed_path)
        if document is None or document.document_id is None:
            issues.append(
                ChangedFileIssue(
                    rule_id=not_document_rule_id,
                    message=f"Changed file `{changed_file}` is not a parsed document.",
                    path=changed_file,
                    severity="warning",
                )
            )
            continue

        if document.document_id not in changed_files_by_id:
            source_ids.append(document.document_id)
            changed_files_by_id[document.document_id] = changed_file

    return ChangedDocumentSourcesResult(
        source_ids=tuple(source_ids),
        changed_files_by_id=changed_files_by_id,
        issues=tuple(issues),
    )


def is_inside_documentation_roots(path: Path, config: ToolkitConfig) -> bool:
    for documentation_root in config.documentation_roots:
        try:
            path.relative_to(documentation_root)
        except ValueError:
            continue
        return True
    return False
