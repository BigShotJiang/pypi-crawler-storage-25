from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from ai_docs_toolkit.core.config import ToolkitConfig


@dataclass(frozen=True)
class DocumentScanner:
    config: ToolkitConfig

    def scan_markdown_files(self) -> tuple[Path, ...]:
        files: list[Path] = []
        for root in self.config.documentation_roots:
            files.extend(_scan_root(root, self.config.excluded_directories))

        return tuple(sorted(files))


def scan_markdown_files(config: ToolkitConfig) -> tuple[Path, ...]:
    return DocumentScanner(config).scan_markdown_files()


def _scan_root(root: Path, excluded_directories: tuple[str, ...]) -> list[Path]:
    files: list[Path] = []

    for child in root.iterdir():
        if child.is_dir():
            if child.name in excluded_directories:
                continue
            files.extend(_scan_root(child, excluded_directories))
            continue

        if child.is_file() and child.suffix.lower() == ".md":
            files.append(child.resolve())

    return files
