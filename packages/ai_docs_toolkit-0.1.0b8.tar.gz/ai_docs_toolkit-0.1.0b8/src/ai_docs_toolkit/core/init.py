from dataclasses import dataclass
from importlib import resources
from pathlib import Path


VALID_INIT_PROFILES = {"agent", "minimal"}


@dataclass(frozen=True)
class InitFileResult:
    path: str
    status: str


@dataclass(frozen=True)
class InitResult:
    profile: str
    created: tuple[str, ...]
    skipped: tuple[str, ...]
    overwritten: tuple[str, ...]
    errors: tuple[str, ...]
    mode: str = "apply"
    changed: bool = False

    @property
    def exit_code(self) -> int:
        if self.errors:
            return 2
        if self.mode == "check" and self.changed:
            return 1
        return 0


@dataclass(frozen=True)
class BootstrapTemplate:
    source_name: str
    target_path: str
    profiles: frozenset[str]
    overwrite_existing: bool = False


BOOTSTRAP_TEMPLATES = (
    BootstrapTemplate(
        source_name="ai-docs.config.yaml",
        target_path="ai-docs.config.yaml",
        profiles=frozenset({"minimal", "agent"}),
    ),
    BootstrapTemplate(
        source_name="ai-docs-index.md",
        target_path="ai-docs/index.md",
        profiles=frozenset({"minimal", "agent"}),
    ),
    BootstrapTemplate(
        source_name=".ai-docs/schemas/frontmatter.schema.yaml",
        target_path=".ai-docs/schemas/frontmatter.schema.yaml",
        profiles=frozenset({"minimal", "agent"}),
        overwrite_existing=True,
    ),
    BootstrapTemplate(
        source_name=".ai-docs/schemas/document-types/acceptance.schema.yaml",
        target_path=".ai-docs/schemas/document-types/acceptance.schema.yaml",
        profiles=frozenset({"minimal", "agent"}),
        overwrite_existing=True,
    ),
    BootstrapTemplate(
        source_name=".ai-docs/schemas/document-types/architecture-decision.schema.yaml",
        target_path=".ai-docs/schemas/document-types/architecture-decision.schema.yaml",
        profiles=frozenset({"minimal", "agent"}),
        overwrite_existing=True,
    ),
    BootstrapTemplate(
        source_name=".ai-docs/schemas/document-types/business-rule.schema.yaml",
        target_path=".ai-docs/schemas/document-types/business-rule.schema.yaml",
        profiles=frozenset({"minimal", "agent"}),
        overwrite_existing=True,
    ),
    BootstrapTemplate(
        source_name=".ai-docs/schemas/document-types/contract.schema.yaml",
        target_path=".ai-docs/schemas/document-types/contract.schema.yaml",
        profiles=frozenset({"minimal", "agent"}),
        overwrite_existing=True,
    ),
    BootstrapTemplate(
        source_name=".ai-docs/schemas/document-types/index.schema.yaml",
        target_path=".ai-docs/schemas/document-types/index.schema.yaml",
        profiles=frozenset({"minimal", "agent"}),
        overwrite_existing=True,
    ),
    BootstrapTemplate(
        source_name=".ai-docs/schemas/document-types/module.schema.yaml",
        target_path=".ai-docs/schemas/document-types/module.schema.yaml",
        profiles=frozenset({"minimal", "agent"}),
        overwrite_existing=True,
    ),
    BootstrapTemplate(
        source_name=".ai-docs/schemas/document-types/plan.schema.yaml",
        target_path=".ai-docs/schemas/document-types/plan.schema.yaml",
        profiles=frozenset({"minimal", "agent"}),
        overwrite_existing=True,
    ),
    BootstrapTemplate(
        source_name=".ai-docs/schemas/document-types/plan-stage.schema.yaml",
        target_path=".ai-docs/schemas/document-types/plan-stage.schema.yaml",
        profiles=frozenset({"minimal", "agent"}),
        overwrite_existing=True,
    ),
    BootstrapTemplate(
        source_name=".ai-docs/schemas/document-types/implementation-task.schema.yaml",
        target_path=".ai-docs/schemas/document-types/implementation-task.schema.yaml",
        profiles=frozenset({"minimal", "agent"}),
        overwrite_existing=True,
    ),
    BootstrapTemplate(
        source_name=".ai-docs/schemas/document-types/standalone-task.schema.yaml",
        target_path=".ai-docs/schemas/document-types/standalone-task.schema.yaml",
        profiles=frozenset({"minimal", "agent"}),
        overwrite_existing=True,
    ),
    BootstrapTemplate(
        source_name=".ai-docs/schemas/document-types/operation.schema.yaml",
        target_path=".ai-docs/schemas/document-types/operation.schema.yaml",
        profiles=frozenset({"minimal", "agent"}),
        overwrite_existing=True,
    ),
    BootstrapTemplate(
        source_name=".ai-docs/schemas/document-types/scenario.schema.yaml",
        target_path=".ai-docs/schemas/document-types/scenario.schema.yaml",
        profiles=frozenset({"minimal", "agent"}),
        overwrite_existing=True,
    ),
    BootstrapTemplate(
        source_name=".ai-docs/schemas/document-types/test-case.schema.yaml",
        target_path=".ai-docs/schemas/document-types/test-case.schema.yaml",
        profiles=frozenset({"minimal", "agent"}),
        overwrite_existing=True,
    ),
    BootstrapTemplate(
        source_name="AGENTS.md",
        target_path="AGENTS.md",
        profiles=frozenset({"agent"}),
    ),
    BootstrapTemplate(
        source_name=".ai-docs/skills/index.md",
        target_path=".ai-docs/skills/index.md",
        profiles=frozenset({"agent"}),
        overwrite_existing=True,
    ),
    BootstrapTemplate(
        source_name=".ai-docs/skills/planning-task-execution/SKILL.md",
        target_path=".ai-docs/skills/planning-task-execution/SKILL.md",
        profiles=frozenset({"agent"}),
        overwrite_existing=True,
    ),
    BootstrapTemplate(
        source_name=".ai-docs/skills/planning-record-generation/SKILL.md",
        target_path=".ai-docs/skills/planning-record-generation/SKILL.md",
        profiles=frozenset({"agent"}),
        overwrite_existing=True,
    ),
    BootstrapTemplate(
        source_name=".ai-docs/skills/toolkit-consumer-policy/SKILL.md",
        target_path=".ai-docs/skills/toolkit-consumer-policy/SKILL.md",
        profiles=frozenset({"agent"}),
        overwrite_existing=True,
    ),
    BootstrapTemplate(
        source_name=".ai-docs/skills/release-publication/SKILL.md",
        target_path=".ai-docs/skills/release-publication/SKILL.md",
        profiles=frozenset({"agent"}),
        overwrite_existing=True,
    ),
    BootstrapTemplate(
        source_name=".ai-docs/templates/release/release-task.md",
        target_path=".ai-docs/templates/release/release-task.md",
        profiles=frozenset({"agent"}),
        overwrite_existing=True,
    ),
    BootstrapTemplate(
        source_name=".ai-docs/templates/release/validation-evidence.md",
        target_path=".ai-docs/templates/release/validation-evidence.md",
        profiles=frozenset({"agent"}),
        overwrite_existing=True,
    ),
    BootstrapTemplate(
        source_name=".ai-docs/templates/release/version-change-checklist.md",
        target_path=".ai-docs/templates/release/version-change-checklist.md",
        profiles=frozenset({"agent"}),
        overwrite_existing=True,
    ),
    BootstrapTemplate(
        source_name=".ai-docs/templates/release/post-publication-checks.md",
        target_path=".ai-docs/templates/release/post-publication-checks.md",
        profiles=frozenset({"agent"}),
        overwrite_existing=True,
    ),
    BootstrapTemplate(
        source_name=".ai-docs/templates/release/migration-note.md",
        target_path=".ai-docs/templates/release/migration-note.md",
        profiles=frozenset({"agent"}),
        overwrite_existing=True,
    ),
    BootstrapTemplate(
        source_name=".ai-docs/examples/skills/pypi-package-release/SKILL.md",
        target_path=".ai-docs/examples/skills/pypi-package-release/SKILL.md",
        profiles=frozenset({"agent"}),
        overwrite_existing=True,
    ),
    BootstrapTemplate(
        source_name=".ai-docs/examples/templates/pypi-package-release/release-task.md",
        target_path=".ai-docs/examples/templates/pypi-package-release/release-task.md",
        profiles=frozenset({"agent"}),
        overwrite_existing=True,
    ),
    BootstrapTemplate(
        source_name=".ai-docs/examples/templates/pypi-package-release/tag-version-guard.py",
        target_path=".ai-docs/examples/templates/pypi-package-release/tag-version-guard.py",
        profiles=frozenset({"agent"}),
        overwrite_existing=True,
    ),
    BootstrapTemplate(
        source_name=".ai-docs/workflows/plan-stage-workflow.md",
        target_path=".ai-docs/workflows/plan-stage-workflow.md",
        profiles=frozenset({"agent"}),
        overwrite_existing=True,
    ),
    BootstrapTemplate(
        source_name=".ai-docs/workflows/toolkit-migration-workflow.md",
        target_path=".ai-docs/workflows/toolkit-migration-workflow.md",
        profiles=frozenset({"agent"}),
        overwrite_existing=True,
    ),
    BootstrapTemplate(
        source_name=".ai-docs/reference/planning-document-model.md",
        target_path=".ai-docs/reference/planning-document-model.md",
        profiles=frozenset({"agent"}),
        overwrite_existing=True,
    ),
)


def init_project(
    project_root: str | Path = ".",
    *,
    profile: str = "agent",
    force: bool = False,
    dry_run: bool = False,
    check: bool = False,
) -> InitResult:
    mode = "check" if check else "dry-run" if dry_run else "apply"
    if profile not in VALID_INIT_PROFILES:
        return InitResult(
            profile=profile,
            created=(),
            skipped=(),
            overwritten=(),
            errors=(f"Unsupported init profile: {profile}",),
            mode=mode,
        )

    root = Path(project_root)
    created: list[str] = []
    skipped: list[str] = []
    overwritten: list[str] = []
    errors: list[str] = []

    for template in BOOTSTRAP_TEMPLATES:
        if profile not in template.profiles:
            continue

        target = root / template.target_path
        existed_before = target.exists()
        try:
            content = _read_bootstrap_template(template.source_name)
            if existed_before and not force and not template.overwrite_existing:
                skipped.append(template.target_path)
                continue

            if existed_before and (dry_run or check) and target.read_bytes() == content:
                skipped.append(template.target_path)
                continue

            if dry_run or check:
                if existed_before:
                    overwritten.append(template.target_path)
                else:
                    created.append(template.target_path)
                continue

            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(content)
        except OSError as exc:
            errors.append(f"{template.target_path}: {exc}")
            continue

        if existed_before and (force or template.overwrite_existing):
            overwritten.append(template.target_path)
        else:
            created.append(template.target_path)

    return InitResult(
        profile=profile,
        created=tuple(created),
        skipped=tuple(skipped),
        overwritten=tuple(overwritten),
        errors=tuple(errors),
        mode=mode,
        changed=bool(created or overwritten),
    )


def _read_bootstrap_template(source_name: str) -> bytes:
    template_root = resources.files("ai_docs_toolkit").joinpath("templates/project")
    return template_root.joinpath(*source_name.split("/")).read_bytes()
