from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path

from ai_docs_toolkit.core.config import load_project_config
from ai_docs_toolkit.core.frontmatter import parse_markdown_file
from ai_docs_toolkit.core.registry import (
    RegistryDocument,
    build_document_registry,
    registry_document_from_parsed,
)
from ai_docs_toolkit.core.scanner import scan_markdown_files

RULE_FILE_LOOKUP_CONFIG_ERROR = "file_lookup.config_error"
RULE_FILE_LOOKUP_INVALID_ID = "file_lookup.id.invalid"
RULE_FILE_LOOKUP_UNKNOWN_ID = "file_lookup.id.unknown"
RULE_FILE_LOOKUP_DUPLICATE_ID = "file_lookup.id.duplicate"
RULE_FILE_LOOKUP_INVALID_TASK = "file_lookup.task.invalid"
RULE_FILE_LOOKUP_UNKNOWN_TASK = "file_lookup.task.unknown"
RULE_FILE_LOOKUP_DUPLICATE_TASK = "file_lookup.task.duplicate"
RULE_FILE_LOOKUP_INDEX_PATH_MISMATCH = "file_lookup.task_index.path_mismatch"
RULE_FILE_LOOKUP_INVALID_REQUEST = "file_lookup.request.invalid"
RULE_FILE_LOOKUP_UNKNOWN_REQUEST = "file_lookup.request.unknown"
RULE_FILE_LOOKUP_INVALID_PLAN = "file_lookup.plan.invalid"
RULE_FILE_LOOKUP_UNKNOWN_PLAN = "file_lookup.plan.unknown"
RULE_FILE_LOOKUP_INVALID_STAGE = "file_lookup.stage.invalid"
RULE_FILE_LOOKUP_UNKNOWN_STAGE = "file_lookup.stage.unknown"


@dataclass(frozen=True)
class FileLookupIssue:
    rule_id: str
    message: str
    path: str | None = None
    document_id: str | None = None


@dataclass(frozen=True)
class FileLookupResult:
    exit_code: int
    query: str
    document_id: str | None = None
    path: str | None = None
    absolute_path: str | None = None
    source: str | None = None
    issues: tuple[FileLookupIssue, ...] = ()

    @property
    def ok(self) -> bool:
        return self.exit_code == 0


def lookup_task_file(
    task: str,
    project_root: str | Path = ".",
) -> FileLookupResult:
    root = Path(project_root).resolve()
    config_result = load_project_config(root)
    if not config_result.ok or config_result.config is None:
        return FileLookupResult(
            exit_code=2,
            query=task,
            issues=tuple(
                FileLookupIssue(
                    rule_id=RULE_FILE_LOOKUP_CONFIG_ERROR,
                    message=error.message,
                    path=error.path,
                )
                for error in config_result.errors
            ),
        )

    documents: list[RegistryDocument] = []
    for path in scan_markdown_files(config_result.config):
        parse_result = parse_markdown_file(path)
        if parse_result.document is None:
            continue
        documents.append(registry_document_from_parsed(parse_result.document))

    registry = build_document_registry(tuple(documents))
    registry_document = _find_task_registry_document(tuple(documents))
    document_id = _normalize_task_id(task, registry_document)
    if document_id is None:
        return FileLookupResult(
            exit_code=1,
            query=task,
            issues=(
                FileLookupIssue(
                    rule_id=RULE_FILE_LOOKUP_INVALID_TASK,
                    message=(
                        "Task lookup value must be a number, zero-padded number, "
                        "or `TASK-NNNNNN` id."
                    ),
                ),
            ),
        )

    indexed_path = _indexed_task_path(registry_document, document_id)
    task_documents = tuple(
        document for document in documents if document.document_id == document_id
    )
    if len(task_documents) > 1:
        paths = ", ".join(
            _relative_path(document.path, root) for document in sorted(task_documents, key=lambda item: item.path)
        )
        return FileLookupResult(
            exit_code=1,
            query=task,
            document_id=document_id,
            issues=(
                FileLookupIssue(
                    rule_id=RULE_FILE_LOOKUP_DUPLICATE_TASK,
                    message=f"Task id `{document_id}` is used by multiple records: {paths}.",
                    document_id=document_id,
                ),
            ),
        )

    if indexed_path is not None:
        expected_path = Path(indexed_path)
        if not expected_path.is_absolute():
            expected_path = root / expected_path
        expected_path = expected_path.resolve()
        task_document = registry.get_by_id(document_id)
        if task_document is None:
            return FileLookupResult(
                exit_code=1,
                query=task,
                document_id=document_id,
                issues=(
                    FileLookupIssue(
                        rule_id=RULE_FILE_LOOKUP_UNKNOWN_TASK,
                        message=f"Task registry index references unknown task id `{document_id}`.",
                        document_id=document_id,
                    ),
                ),
            )

        actual_path = task_document.path.resolve()
        if expected_path != actual_path:
            return FileLookupResult(
                exit_code=1,
                query=task,
                document_id=document_id,
                path=_relative_path(expected_path, root),
                absolute_path=str(expected_path),
                source="task_index",
                issues=(
                    FileLookupIssue(
                        rule_id=RULE_FILE_LOOKUP_INDEX_PATH_MISMATCH,
                        message=(
                            f"Task registry index maps `{document_id}` to "
                            f"`{_relative_path(expected_path, root)}`, but the task "
                            f"record is at `{_relative_path(actual_path, root)}`."
                        ),
                        path=_relative_path(registry_document.path, root)
                        if registry_document
                        else None,
                        document_id=document_id,
                    ),
                ),
            )

        return FileLookupResult(
            exit_code=0,
            query=task,
            document_id=document_id,
            path=_relative_path(actual_path, root),
            absolute_path=str(actual_path),
            source="task_index",
        )

    task_document = registry.get_by_id(document_id)
    if task_document is None:
        return FileLookupResult(
            exit_code=1,
            query=task,
            document_id=document_id,
            issues=(
                FileLookupIssue(
                    rule_id=RULE_FILE_LOOKUP_UNKNOWN_TASK,
                    message=f"Task id `{document_id}` was not found.",
                    document_id=document_id,
                ),
            ),
        )

    actual_path = task_document.path.resolve()
    return FileLookupResult(
        exit_code=0,
        query=task,
        document_id=document_id,
        path=_relative_path(actual_path, root),
        absolute_path=str(actual_path),
        source="frontmatter_scan",
    )


def lookup_document_file(
    document_id: str,
    project_root: str | Path = ".",
) -> FileLookupResult:
    root = Path(project_root).resolve()
    loaded = _load_documents(root, query=document_id)
    if isinstance(loaded, FileLookupResult):
        return loaded

    document = _unique_document_by_id(loaded, document_id)
    if isinstance(document, FileLookupResult):
        return document

    return _document_result(document_id, document, root, source="frontmatter_scan")


def lookup_request_file(
    request: str,
    project_root: str | Path = ".",
) -> FileLookupResult:
    document_id = _normalize_prefixed_id(request, prefix="REQ", width=6)
    if document_id is None:
        return FileLookupResult(
            exit_code=1,
            query=request,
            issues=(
                FileLookupIssue(
                    rule_id=RULE_FILE_LOOKUP_INVALID_REQUEST,
                    message=(
                        "Request lookup value must be a number, zero-padded number, "
                        "or `REQ-NNNNNN` id."
                    ),
                ),
            ),
        )

    result = lookup_document_file(document_id, project_root)
    if result.ok:
        return FileLookupResult(
            exit_code=0,
            query=request,
            document_id=result.document_id,
            path=result.path,
            absolute_path=result.absolute_path,
            source=result.source,
        )

    return _retag_lookup_error(
        result,
        query=request,
        invalid_rule=RULE_FILE_LOOKUP_INVALID_REQUEST,
        unknown_rule=RULE_FILE_LOOKUP_UNKNOWN_REQUEST,
    )


def lookup_plan_file(
    plan: str,
    project_root: str | Path = ".",
) -> FileLookupResult:
    document_id = _normalize_prefixed_id(plan, prefix="PLAN", width=6)
    if document_id is None:
        return FileLookupResult(
            exit_code=1,
            query=plan,
            issues=(
                FileLookupIssue(
                    rule_id=RULE_FILE_LOOKUP_INVALID_PLAN,
                    message=(
                        "Plan lookup value must be a number, zero-padded number, "
                        "or `PLAN-NNNNNN` id."
                    ),
                ),
            ),
        )

    result = lookup_document_file(document_id, project_root)
    if result.ok:
        return FileLookupResult(
            exit_code=0,
            query=plan,
            document_id=result.document_id,
            path=result.path,
            absolute_path=result.absolute_path,
            source=result.source,
        )

    return _retag_lookup_error(
        result,
        query=plan,
        invalid_rule=RULE_FILE_LOOKUP_INVALID_PLAN,
        unknown_rule=RULE_FILE_LOOKUP_UNKNOWN_PLAN,
    )


def lookup_stage_file(
    plan: str,
    stage: str,
    project_root: str | Path = ".",
) -> FileLookupResult:
    root = Path(project_root).resolve()
    loaded = _load_documents(root, query=f"{plan}:{stage}")
    if isinstance(loaded, FileLookupResult):
        return loaded

    plan_id = _normalize_prefixed_id(plan, prefix="PLAN", width=6)
    if plan_id is None:
        return FileLookupResult(
            exit_code=1,
            query=plan,
            issues=(
                FileLookupIssue(
                    rule_id=RULE_FILE_LOOKUP_INVALID_PLAN,
                    message=(
                        "Plan lookup value must be a number, zero-padded number, "
                        "or `PLAN-NNNNNN` id."
                    ),
                ),
            ),
        )

    plan_document = _unique_document_by_id(loaded, plan_id)
    if isinstance(plan_document, FileLookupResult):
        return _retag_lookup_error(
            plan_document,
            query=plan,
            invalid_rule=RULE_FILE_LOOKUP_INVALID_PLAN,
            unknown_rule=RULE_FILE_LOOKUP_UNKNOWN_PLAN,
        )

    if re.fullmatch(r"\d+", stage):
        stage_document = _stage_by_order(loaded, plan_document, int(stage))
        if stage_document is None:
            return FileLookupResult(
                exit_code=1,
                query=stage,
                document_id=plan_id,
                issues=(
                    FileLookupIssue(
                        rule_id=RULE_FILE_LOOKUP_UNKNOWN_STAGE,
                        message=f"Stage `{stage}` was not found in plan `{plan_id}`.",
                        document_id=plan_id,
                    ),
                ),
            )
        return _document_result(stage, stage_document, root, source="stage_order")

    stage_id = _normalize_prefixed_id(stage, prefix="STAGE", width=6)
    if stage_id is None:
        return FileLookupResult(
            exit_code=1,
            query=stage,
            document_id=plan_id,
            issues=(
                FileLookupIssue(
                    rule_id=RULE_FILE_LOOKUP_INVALID_STAGE,
                    message=(
                        "Stage lookup value must be a stage order number or "
                        "`STAGE-NNNNNN` id."
                    ),
                    document_id=plan_id,
                ),
            ),
        )

    stage_document = _unique_document_by_id(loaded, stage_id)
    if isinstance(stage_document, FileLookupResult):
        return _retag_lookup_error(
            stage_document,
            query=stage,
            invalid_rule=RULE_FILE_LOOKUP_INVALID_STAGE,
            unknown_rule=RULE_FILE_LOOKUP_UNKNOWN_STAGE,
        )
    if not _is_inside_plan(stage_document.path, plan_document.path.parent):
        return FileLookupResult(
            exit_code=1,
            query=stage,
            document_id=stage_id,
            issues=(
                FileLookupIssue(
                    rule_id=RULE_FILE_LOOKUP_UNKNOWN_STAGE,
                    message=f"Stage `{stage_id}` was not found in plan `{plan_id}`.",
                    document_id=stage_id,
                ),
            ),
        )
    return _document_result(stage, stage_document, root, source="frontmatter_scan")


def format_file_lookup_human(
    result: FileLookupResult,
    *,
    absolute: bool = False,
) -> str:
    if result.ok:
        return result.absolute_path if absolute and result.absolute_path else result.path or ""

    return "\n".join(
        f"{issue.rule_id}: {issue.message}" for issue in result.issues
    )


def format_file_lookup_json(result: FileLookupResult) -> str:
    payload = {
        "ok": result.ok,
        "query": result.query,
        "document_id": result.document_id,
        "path": result.path,
        "absolute_path": result.absolute_path,
        "source": result.source,
        "issues": [
            {
                "rule_id": issue.rule_id,
                "message": issue.message,
                "path": issue.path,
                "document_id": issue.document_id,
            }
            for issue in result.issues
        ],
    }
    return json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True)


def _find_task_registry_document(
    documents: tuple[RegistryDocument, ...],
) -> RegistryDocument | None:
    for document in documents:
        parts = document.path.resolve().parts
        if len(parts) >= 3 and parts[-3:] == ("ai-docs", "planning", "task-registry.md"):
            return document
    return None


def _load_documents(
    root: Path,
    *,
    query: str,
) -> tuple[RegistryDocument, ...] | FileLookupResult:
    config_result = load_project_config(root)
    if not config_result.ok or config_result.config is None:
        return FileLookupResult(
            exit_code=2,
            query=query,
            issues=tuple(
                FileLookupIssue(
                    rule_id=RULE_FILE_LOOKUP_CONFIG_ERROR,
                    message=error.message,
                    path=error.path,
                )
                for error in config_result.errors
            ),
        )

    documents: list[RegistryDocument] = []
    for path in scan_markdown_files(config_result.config):
        parse_result = parse_markdown_file(path)
        if parse_result.document is None:
            continue
        documents.append(registry_document_from_parsed(parse_result.document))
    return tuple(documents)


def _unique_document_by_id(
    documents: tuple[RegistryDocument, ...],
    document_id: str,
) -> RegistryDocument | FileLookupResult:
    matches = tuple(
        document
        for document in documents
        if document.document_id == document_id or document_id in document.aliases
    )
    if not matches:
        return FileLookupResult(
            exit_code=1,
            query=document_id,
            document_id=document_id,
            issues=(
                FileLookupIssue(
                    rule_id=RULE_FILE_LOOKUP_UNKNOWN_ID,
                    message=f"Document id `{document_id}` was not found.",
                    document_id=document_id,
                ),
            ),
        )
    if len(matches) > 1:
        paths = ", ".join(str(document.path) for document in sorted(matches, key=lambda item: item.path))
        return FileLookupResult(
            exit_code=1,
            query=document_id,
            document_id=document_id,
            issues=(
                FileLookupIssue(
                    rule_id=RULE_FILE_LOOKUP_DUPLICATE_ID,
                    message=f"Document id `{document_id}` is used by multiple records: {paths}.",
                    document_id=document_id,
                ),
            ),
        )
    return matches[0]


def _document_result(
    query: str,
    document: RegistryDocument,
    root: Path,
    *,
    source: str,
) -> FileLookupResult:
    actual_path = document.path.resolve()
    return FileLookupResult(
        exit_code=0,
        query=query,
        document_id=document.document_id,
        path=_relative_path(actual_path, root),
        absolute_path=str(actual_path),
        source=source,
    )


def _normalize_task_id(
    value: str,
    registry_document: RegistryDocument | None,
) -> str | None:
    prefix, width = _task_sequence(registry_document)
    if re.fullmatch(r"\d+", value):
        return f"{prefix}-{int(value):0{width}d}"

    match = re.fullmatch(r"([A-Z]+)-(\d+)", value)
    if match is None:
        return None

    candidate_prefix, number = match.groups()
    if candidate_prefix != prefix:
        return None
    return f"{prefix}-{int(number):0{width}d}"


def _normalize_prefixed_id(value: str, *, prefix: str, width: int) -> str | None:
    if re.fullmatch(r"\d+", value):
        return f"{prefix}-{int(value):0{width}d}"

    match = re.fullmatch(r"([A-Z]+)-(\d+)", value)
    if match is None:
        return value if value.startswith(f"{prefix}-") else None

    candidate_prefix, number = match.groups()
    if candidate_prefix != prefix:
        return None
    return f"{prefix}-{int(number):0{width}d}"


def _stage_by_order(
    documents: tuple[RegistryDocument, ...],
    plan_document: RegistryDocument,
    stage_order: int,
) -> RegistryDocument | None:
    if stage_order <= 0:
        return None

    plan_dir = plan_document.path.parent.resolve()
    expected_prefixes = (f"stage-{stage_order}-", f"phase-{stage_order}-")
    for document in sorted(documents, key=lambda item: item.path):
        if document.frontmatter.get("type") != "plan_stage":
            continue
        if not _is_inside_plan(document.path, plan_dir):
            continue
        if document.path.name != "stage.md":
            continue
        if document.path.parent.name.startswith(expected_prefixes):
            return document

    return None


def _is_inside_plan(path: Path, plan_dir: Path) -> bool:
    try:
        path.resolve().relative_to(plan_dir.resolve())
        return True
    except ValueError:
        return False


def _retag_lookup_error(
    result: FileLookupResult,
    *,
    query: str,
    invalid_rule: str,
    unknown_rule: str,
) -> FileLookupResult:
    rule_map = {
        RULE_FILE_LOOKUP_INVALID_ID: invalid_rule,
        RULE_FILE_LOOKUP_UNKNOWN_ID: unknown_rule,
    }
    return FileLookupResult(
        exit_code=result.exit_code,
        query=query,
        document_id=result.document_id,
        path=result.path,
        absolute_path=result.absolute_path,
        source=result.source,
        issues=tuple(
            FileLookupIssue(
                rule_id=rule_map.get(issue.rule_id, issue.rule_id),
                message=issue.message,
                path=issue.path,
                document_id=issue.document_id,
            )
            for issue in result.issues
        ),
    )


def _task_sequence(registry_document: RegistryDocument | None) -> tuple[str, int]:
    if registry_document is None:
        return "TASK", 6

    sequence = registry_document.frontmatter.get("sequence")
    if not isinstance(sequence, dict):
        return "TASK", 6

    prefix = sequence.get("prefix")
    width = sequence.get("width")
    if not isinstance(prefix, str) or not prefix:
        prefix = "TASK"
    if not isinstance(width, int) or width <= 0:
        width = 6
    return prefix, width


def _indexed_task_path(
    registry_document: RegistryDocument | None,
    document_id: str,
) -> str | None:
    if registry_document is None:
        return None

    task_index = registry_document.frontmatter.get("task_index")
    if not isinstance(task_index, list):
        return None

    for entry in task_index:
        if not isinstance(entry, dict):
            continue
        if entry.get("id") != document_id:
            continue
        path = entry.get("path")
        return path if isinstance(path, str) and path else None
    return None


def _relative_path(path: str | Path, root: Path) -> str:
    resolved = Path(path).resolve()
    try:
        return resolved.relative_to(root).as_posix()
    except ValueError:
        return str(resolved)
