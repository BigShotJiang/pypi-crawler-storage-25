from __future__ import annotations

from dataclasses import dataclass
from importlib import resources
from pathlib import Path

from ai_docs_toolkit.core.config import load_project_config
from ai_docs_toolkit.core.init import BOOTSTRAP_TEMPLATES


@dataclass(frozen=True)
class DoctorFinding:
    rule_id: str
    message: str
    path: str | None = None
    severity: str = "warning"


@dataclass(frozen=True)
class DoctorResult:
    findings: tuple[DoctorFinding, ...]

    @property
    def ok(self) -> bool:
        return not self.findings

    @property
    def exit_code(self) -> int:
        return 0 if self.ok else 1


def doctor_project(project_root: str | Path = ".") -> DoctorResult:
    root = Path(project_root).resolve()
    findings: list[DoctorFinding] = []

    config_result = load_project_config(root)
    if not config_result.ok:
        findings.extend(
            DoctorFinding(
                rule_id=f"doctor.config.{error.code}",
                message=error.message,
                path=error.path,
                severity="error",
            )
            for error in config_result.errors
        )
    elif config_result.config is not None:
        if (root / "docs" / "planning").exists():
            findings.append(
                DoctorFinding(
                    rule_id="doctor.legacy_planning_root",
                    message=(
                        "Legacy planning root `docs/planning` exists; current toolkit policy uses "
                        "`ai-docs/planning`. Run `ai-docs planning migrate-layout --dry-run` "
                        "to preview layout migration checks."
                    ),
                    path=str(root / "docs" / "planning"),
                )
            )

        configured_roots = {
            path.relative_to(root).as_posix()
            for path in config_result.config.documentation_roots
            if path.is_relative_to(root)
        }
        if "docs/planning" in configured_roots:
            findings.append(
                DoctorFinding(
                    rule_id="doctor.config.legacy_documentation_root",
                    message=(
                        "Config includes legacy documentation root `docs/planning`. Run "
                        "`ai-docs planning migrate-layout --dry-run` before manual migration."
                    ),
                    path=str(root / "ai-docs.config.yaml"),
                )
            )

    if not _is_toolkit_source_checkout(root):
        findings.extend(_managed_file_findings(root))
    findings.extend(_obsolete_link_findings(root))
    return DoctorResult(findings=tuple(sorted(findings, key=_finding_sort_key)))


def format_doctor_human(result: DoctorResult) -> str:
    if result.ok:
        return "ai-docs doctor\nStatus: ok\nFindings: none"

    lines = ["ai-docs doctor", "Status: issues found", "Findings:"]
    for finding in result.findings:
        path = f" {finding.path}" if finding.path else ""
        lines.append(f"- {finding.severity} {finding.rule_id}{path}: {finding.message}")
    return "\n".join(lines)


def _managed_file_findings(root: Path) -> list[DoctorFinding]:
    findings: list[DoctorFinding] = []
    template_root = resources.files("ai_docs_toolkit").joinpath("templates/project")
    for template in BOOTSTRAP_TEMPLATES:
        if "agent" not in template.profiles and "minimal" not in template.profiles:
            continue
        target = root / template.target_path
        if not target.exists():
            findings.append(
                DoctorFinding(
                    rule_id="doctor.managed_file.missing",
                    message=(
                        "Toolkit-managed file is missing. Run `ai-docs init --check` to "
                        "preview managed files before refreshing them."
                    ),
                    path=str(target),
                )
            )
            continue

        if not template.overwrite_existing:
            continue

        expected = template_root.joinpath(*template.source_name.split("/")).read_bytes()
        if target.read_bytes() != expected:
            findings.append(
                DoctorFinding(
                    rule_id="doctor.managed_file.stale",
                    message=(
                        "Toolkit-managed file differs from the packaged template. Run "
                        "`ai-docs init --check` to review the package update before refresh."
                    ),
                    path=str(target),
                )
            )
    return findings


def _obsolete_link_findings(root: Path) -> list[DoctorFinding]:
    findings: list[DoctorFinding] = []
    for path in sorted(root.rglob("*.md")):
        if any(part in {".git", ".venv", "build", "dist"} for part in path.parts):
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        if ".ai-docs/reference/plan-stage-workflow.md" in text:
            findings.append(
                DoctorFinding(
                    rule_id="doctor.obsolete_workflow_link",
                    message="File links to obsolete workflow path `.ai-docs/reference/plan-stage-workflow.md`.",
                    path=str(path),
                )
            )
    return findings


def _finding_sort_key(finding: DoctorFinding) -> tuple[str, str, str]:
    return (finding.rule_id, finding.path or "", finding.message)


def _is_toolkit_source_checkout(root: Path) -> bool:
    return (root / "src" / "ai_docs_toolkit" / "templates" / "project").is_dir()
