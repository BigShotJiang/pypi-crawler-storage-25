from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ai_docs_toolkit.core.registry import DocumentRegistry, RegistryDocument

RULE_RELATIONSHIP_UNRESOLVED = "document.relationship.unresolved"
RULE_SECTION_MISSING = "document.section.missing"
RULE_PLANNING_INVALID_STATUS = "planning.lifecycle.invalid_status"
RULE_PLANNING_ACCEPTED_NOT_ACTIVE_GATE = "planning.lifecycle.accepted_not_active_gate"
RULE_PLANNING_MISSING_READINESS_REVIEW = "planning.lifecycle.missing_readiness_review"
RULE_PLANNING_MISSING_INTAKE_CHECKLIST = "planning.intake.missing_checklist"
RULE_PLANNING_INCOMPLETE_INTAKE_CHECKLIST = "planning.intake.incomplete_checklist"
RULE_PLANNING_MISSING_CLOSURE_REVIEW = "planning.lifecycle.missing_closure_review"
RULE_PLANNING_MISSING_CLOSURE_OBSERVATIONS = "planning.closure.missing_observations"
RULE_PLANNING_MISSING_CLOSURE_CHECKLIST = "planning.closure.missing_checklist"
RULE_PLANNING_INCOMPLETE_CLOSURE_CHECKLIST = "planning.closure.incomplete_checklist"
RULE_PLANNING_UNRESOLVED_OBSERVATION = "planning.closure.unresolved_observation"
RULE_PLANNING_TASK_ID_DUPLICATE = "planning.task_id.duplicate"
RULE_PLANNING_TASK_INDEX_UNKNOWN_ID = "planning.task_index.unknown_id"
RULE_PLANNING_TASK_INDEX_PATH_MISMATCH = "planning.task_index.path_mismatch"
RULE_PLANNING_INVALID_PLACEMENT = "planning.placement.invalid"
RULE_PLANNING_MISSING_PLACEMENT = "planning.placement.missing"
RULE_PLANNING_MISSING_PLACEMENT_FIELD = "planning.placement.missing_field"
RULE_PLANNING_INVALID_READINESS_PROPOSAL = "planning.readiness_proposal.invalid"
RULE_PLANNING_INVALID_LAYOUT = "planning.layout.invalid"
RULE_PLANNING_MISSING_DESIGN_FIRST_TASK = "planning.design_first.missing_task"
RULE_PLANNING_MISSING_TEST_PLAN = "planning.test_discipline.missing_test_plan"
RULE_PLANNING_MISSING_VALIDATION_COMMAND = "planning.test_discipline.missing_validation_command"

PLANNING_DOCUMENT_TYPES = {
    "plan",
    "plan_stage",
    "implementation_task",
    "standalone_task",
}
ACTIVE_PLAN_STATUSES = {
    "accepted",
    "draft",
    "planned",
    "readiness_review",
    "ready",
    "in_progress",
    "closure_review",
    "blocked",
    "done",
    "exported",
    "archived",
    "deferred",
    "deprecated",
}
PLANNING_EXECUTION_STATUSES = {
    "planned",
    "readiness_review",
    "ready",
    "in_progress",
    "closure_review",
    "blocked",
    "done",
    "exported",
    "archived",
    "deferred",
    "cancelled",
    "expanded",
}
READINESS_REQUIRED_STATUSES = {
    "readiness_review",
    "ready",
    "in_progress",
    "closure_review",
}
CLOSURE_REQUIRED_STATUSES = {
    "closure_review",
    "done",
}
ACTIVE_EXECUTABLE_PLACEMENT_REQUIRED_STATUSES = {
    "planned",
    "readiness_review",
    "ready",
    "in_progress",
    "closure_review",
    "blocked",
    "deferred",
}

DEFAULT_REQUIRED_SECTIONS_BY_TYPE: dict[str, tuple[str, ...]] = {
    "business_rule": (
        "Rule",
        "Rationale",
        "Applies To",
        "Exceptions",
        "Related Scenarios",
        "Validation",
    ),
    "architecture_decision": (
        "Context",
        "Decision",
        "Consequences",
        "Alternatives Considered",
        "Impacted Documents",
        "Validation",
    ),
    "contract": (
        "Producer",
        "Consumer",
        "Contract",
        "Compatibility",
        "Breaking Changes",
        "Validation",
    ),
    "module": (
        "Responsibility",
        "Non-Goals",
        "Public Interfaces",
        "Dependencies",
        "Invariants",
        "Related Documents",
        "Validation",
    ),
    "scenario": (
        "Actor",
        "Preconditions",
        "Flow",
        "Edge Cases",
        "Related Rules",
        "Validation",
    ),
    "acceptance": (
        "Source Documents",
        "Acceptance Criteria",
        "Required Tests",
        "Manual Checks",
        "Done Definition",
    ),
    "test_case": (
        "Purpose",
        "Coverage Type",
        "Source Documents",
        "Preconditions",
        "Steps",
        "Expected Result",
        "Executable Tests",
        "Notes",
    ),
    "operation": (
        "Purpose",
        "Preconditions",
        "Procedure",
        "Validation",
        "Rollback",
        "Risks",
    ),
    "index": (
        "Scope",
        "Entry Points",
        "Documents",
        "Loading Guidance",
    ),
}

_HEADING_PATTERN = re.compile(r"^##\s+(?P<title>.+?)\s*#*\s*$")
_GLOBAL_TASK_ID_PATTERN = re.compile(r"^TASK-\d{6}$")

TASK_PLACEMENTS = {
    "backlog",
    "plan",
    "plan_stage",
    "standalone",
    "archive",
}
REQUIRED_SCOPE_FIELDS_BY_PLACEMENT: dict[str, tuple[str, ...]] = {
    "backlog": (),
    "plan": ("plan",),
    "plan_stage": ("plan", "stage", "task_order"),
    "standalone": ("task",),
    "archive": (),
}
READINESS_PROPOSAL_DISPOSITIONS = {
    "accepted",
    "deferred",
    "rejected",
    "documented",
    "not_applicable",
    "backlog",
    "task",
}


@dataclass(frozen=True)
class StructureValidationIssue:
    rule_id: str
    message: str
    path: Path
    document_id: str | None = None
    severity: str = "error"
    relationship: str | None = None
    target_id: str | None = None
    section: str | None = None


@dataclass(frozen=True)
class StructureValidationResult:
    issues: tuple[StructureValidationIssue, ...] = ()

    @property
    def ok(self) -> bool:
        return not self.issues


def validate_relationships_and_sections(
    registry: DocumentRegistry,
    *,
    required_sections_by_type: dict[str, tuple[str, ...]] | None = None,
) -> StructureValidationResult:
    required_sections = required_sections_by_type or DEFAULT_REQUIRED_SECTIONS_BY_TYPE
    issues: list[StructureValidationIssue] = []
    issues.extend(_validate_global_task_ids(registry))
    issues.extend(_validate_task_registry_index(registry))

    for document in _sorted_documents(registry):
        document_type = _string_value(document.frontmatter.get("type"))
        issues.extend(_validate_planning_layout(document))
        issues.extend(_validate_planning_lifecycle(document, registry))
        issues.extend(_validate_design_first_stage(document, registry))
        issues.extend(_validate_task_test_discipline(document, registry))
        if document_type not in required_sections:
            continue

        issues.extend(_validate_relationships(document, registry))
        issues.extend(_validate_required_sections(document, required_sections[document_type]))

    return StructureValidationResult(issues=tuple(issues))


def _validate_planning_layout(document: RegistryDocument) -> list[StructureValidationIssue]:
    document_type = _string_value(document.frontmatter.get("type"))
    if document_type not in {"plan", "plan_stage", "implementation_task"}:
        return []

    relative_parts = _planning_relative_parts(document.path)
    if relative_parts is None:
        return []

    filename = relative_parts[-1]
    if document_type == "plan" and len(relative_parts) == 1 and filename.startswith("PLAN-"):
        return [
            StructureValidationIssue(
                rule_id=RULE_PLANNING_INVALID_LAYOUT,
                message=(
                    "Generated plan documents must live under a plan directory "
                    "as `plan.md`, not as a flat `ai-docs/planning/PLAN-*.md` file."
                ),
                path=document.path.resolve(),
                document_id=document.document_id,
            )
        ]

    if document_type == "plan_stage" and len(relative_parts) == 1 and filename.startswith("STAGE-"):
        return [
            StructureValidationIssue(
                rule_id=RULE_PLANNING_INVALID_LAYOUT,
                message=(
                    "Generated stage documents must live under "
                    "`ai-docs/planning/<plan>/stage-NNN-<slug>/stage.md`, "
                    "not as a flat `ai-docs/planning/STAGE-*.md` file."
                ),
                path=document.path.resolve(),
                document_id=document.document_id,
            )
        ]

    if (
        document_type == "implementation_task"
        and len(relative_parts) == 1
        and filename.startswith("TASK-")
    ):
        scope = document.frontmatter.get("scope")
        placement = scope.get("placement") if isinstance(scope, dict) else None
        if placement == "plan_stage":
            return [
                StructureValidationIssue(
                    rule_id=RULE_PLANNING_INVALID_LAYOUT,
                    message=(
                        "Plan-stage task documents must live inside their owning "
                        "stage directory with a `task-N-<slug>.md` filename."
                    ),
                    path=document.path.resolve(),
                    document_id=document.document_id,
                )
            ]

    return []


def _planning_relative_parts(path: Path) -> tuple[str, ...] | None:
    parts = path.resolve().parts
    for index in range(len(parts) - 1):
        if parts[index] == "ai-docs" and parts[index + 1] == "planning":
            return tuple(parts[index + 2 :])
    return None


def _validate_relationships(
    document: RegistryDocument,
    registry: DocumentRegistry,
) -> list[StructureValidationIssue]:
    related = document.frontmatter.get("related")
    if not isinstance(related, dict):
        return []

    issues: list[StructureValidationIssue] = []
    for group, target_ids in sorted(related.items()):
        if not isinstance(group, str) or not isinstance(target_ids, list):
            continue

        for target_id in target_ids:
            if not isinstance(target_id, str) or not target_id:
                continue

            if registry.get_by_id(target_id) is not None:
                continue

            relationship = f"related.{group}"
            issues.append(
                StructureValidationIssue(
                    rule_id=RULE_RELATIONSHIP_UNRESOLVED,
                    message=(
                        f"Relationship `{relationship}` references unknown document "
                        f"id `{target_id}`."
                    ),
                    path=document.path.resolve(),
                    document_id=document.document_id,
                    relationship=relationship,
                    target_id=target_id,
                )
            )

    return issues


def _validate_required_sections(
    document: RegistryDocument,
    required_sections: tuple[str, ...],
) -> list[StructureValidationIssue]:
    headings = _second_level_headings(document.body)
    issues: list[StructureValidationIssue] = []

    for section in required_sections:
        if section in headings:
            continue

        issues.append(
            StructureValidationIssue(
                rule_id=RULE_SECTION_MISSING,
                message=f"Document is missing required section `## {section}`.",
                path=document.path.resolve(),
                document_id=document.document_id,
                section=f"## {section}",
            )
        )

    return issues


def _validate_planning_lifecycle(
    document: RegistryDocument,
    registry: DocumentRegistry,
) -> list[StructureValidationIssue]:
    document_type = _string_value(document.frontmatter.get("type"))
    if document_type not in PLANNING_DOCUMENT_TYPES:
        return []

    status = _string_value(document.frontmatter.get("status"))
    issues: list[StructureValidationIssue] = []

    if status is None or status not in _allowed_planning_statuses(document_type):
        issues.append(
            StructureValidationIssue(
                rule_id=RULE_PLANNING_INVALID_STATUS,
                message=(
                    f"Planning document type `{document_type}` has invalid lifecycle "
                    f"status `{status}`."
                ),
                path=document.path.resolve(),
                document_id=document.document_id,
            )
        )
        return issues

    headings = _second_level_headings(document.body)
    if document_type == "plan" and status == "accepted":
        issues.append(
            StructureValidationIssue(
                rule_id=RULE_PLANNING_ACCEPTED_NOT_ACTIVE_GATE,
                message=(
                    "`accepted` is not an active plan lifecycle gate; use `ready` "
                    "after plan readiness review."
                ),
                path=document.path.resolve(),
                document_id=document.document_id,
            )
        )

    if status in READINESS_REQUIRED_STATUSES and "Readiness" not in headings:
        issues.append(
            StructureValidationIssue(
                rule_id=RULE_PLANNING_MISSING_READINESS_REVIEW,
                message="Planning record is missing required section `## Readiness`.",
                path=document.path.resolve(),
                document_id=document.document_id,
                section="## Readiness",
            )
        )
    if (
        document_type in {"implementation_task", "standalone_task"}
        and status in READINESS_REQUIRED_STATUSES
    ):
        issues.extend(_validate_intake_checklist(document))
        issues.extend(_validate_readiness_proposals(document))
    if document_type in {"implementation_task", "standalone_task"}:
        issues.extend(_validate_task_placement(document))

    if status in CLOSURE_REQUIRED_STATUSES:
        if "Closure Review" not in headings and status == "closure_review":
            issues.append(
                StructureValidationIssue(
                    rule_id=RULE_PLANNING_MISSING_CLOSURE_REVIEW,
                    message=(
                        "Planning record in `closure_review` is missing required "
                        "section `## Closure Review`."
                    ),
                    path=document.path.resolve(),
                    document_id=document.document_id,
                    section="## Closure Review",
                )
            )
        if "Closing Observations" not in headings:
            issues.append(
                StructureValidationIssue(
                    rule_id=RULE_PLANNING_MISSING_CLOSURE_OBSERVATIONS,
                    message=(
                        "Terminal planning record is missing required section "
                        "`## Closing Observations`."
                    ),
                    path=document.path.resolve(),
                    document_id=document.document_id,
                    section="## Closing Observations",
                )
            )
        if "Closure Checklist" not in headings:
            issues.append(
                StructureValidationIssue(
                    rule_id=RULE_PLANNING_MISSING_CLOSURE_CHECKLIST,
                    message=(
                        "Terminal planning record is missing required section "
                        "`## Closure Checklist`."
                    ),
                    path=document.path.resolve(),
                    document_id=document.document_id,
                    section="## Closure Checklist",
                )
            )
        if _is_in_active_planning_tree(document, registry):
            issues.extend(_validate_closing_observations(document))
            issues.extend(_validate_closure_checklist(document))

    return issues


def _validate_design_first_stage(
    document: RegistryDocument,
    registry: DocumentRegistry,
) -> list[StructureValidationIssue]:
    document_type = _string_value(document.frontmatter.get("type"))
    if document_type != "plan_stage":
        return []
    if not _is_ai_docs_planning_path(document):
        return []
    status = _string_value(document.frontmatter.get("status"))
    if status in {"done", "exported", "archived", "deferred", "deprecated", "cancelled"}:
        return []
    if not _is_implementation_stage(document):
        return []

    related = document.frontmatter.get("related")
    tasks = related.get("tasks") if isinstance(related, dict) else None
    if not isinstance(tasks, list) or not tasks:
        return []
    first_task_id = next((task for task in tasks if isinstance(task, str)), None)
    if first_task_id is None:
        return []
    first_task = registry.get_by_id(first_task_id)
    if first_task is not None and re.search(r"\bdesign\b", first_task.body, re.IGNORECASE):
        return []

    return [
        StructureValidationIssue(
            rule_id=RULE_PLANNING_MISSING_DESIGN_FIRST_TASK,
            message="Implementation stage must start with a design task.",
            path=document.path.resolve(),
            document_id=document.document_id,
        )
    ]


def _validate_task_test_discipline(
    document: RegistryDocument,
    registry: DocumentRegistry,
) -> list[StructureValidationIssue]:
    document_type = _string_value(document.frontmatter.get("type"))
    if document_type not in {"implementation_task", "standalone_task"}:
        return []
    if not _is_ai_docs_planning_path(document):
        return []
    if not _is_in_active_planning_tree(document, registry):
        return []

    status = _string_value(document.frontmatter.get("status"))
    issues: list[StructureValidationIssue] = []
    if status in ACTIVE_EXECUTABLE_PLACEMENT_REQUIRED_STATUSES and _section_text(document.body, "Test Plan") is None:
        issues.append(
            StructureValidationIssue(
                rule_id=RULE_PLANNING_MISSING_TEST_PLAN,
                message="Executable implementation task must include `## Test Plan`.",
                path=document.path.resolve(),
                document_id=document.document_id,
                section="## Test Plan",
            )
        )

    if status in CLOSURE_REQUIRED_STATUSES:
        validation = _section_text(document.body, "Validation") or ""
        has_command = re.search(r"(`[^`]*(pytest|ai-docs validate|git diff --check|python)[^`]*`|^\s*-\s+[\w./-]+)", validation, re.MULTILINE)
        has_result = re.search(r"\b(passed|failed|skipped|deferred)\b", validation, re.IGNORECASE)
        if not has_command or not has_result:
            issues.append(
                StructureValidationIssue(
                    rule_id=RULE_PLANNING_MISSING_VALIDATION_COMMAND,
                    message="Closed executable task must record validation command and result.",
                    path=document.path.resolve(),
                    document_id=document.document_id,
                    section="## Validation",
                )
            )

    return issues


def _is_implementation_stage(document: RegistryDocument) -> bool:
    scope_text = _section_text(document.body, "Scope") or ""
    modules = ""
    scope = document.frontmatter.get("scope")
    if isinstance(scope, dict) and isinstance(scope.get("modules"), list):
        modules = " ".join(item for item in scope["modules"] if isinstance(item, str))
    text = f"{modules}\n{scope_text}"
    return re.search(r"\bimplementation\b", text, re.IGNORECASE) is not None


def _is_ai_docs_planning_path(document: RegistryDocument) -> bool:
    parts = document.path.parts
    return any(
        parts[index : index + 2] == ("ai-docs", "planning")
        for index in range(0, max(len(parts) - 1, 0))
    )


def _validate_global_task_ids(
    registry: DocumentRegistry,
) -> list[StructureValidationIssue]:
    global_id_groups: dict[str, list[RegistryDocument]] = {}
    for document in registry.documents_by_path.values():
        document_id = document.document_id
        if document_id is None or _GLOBAL_TASK_ID_PATTERN.fullmatch(document_id) is None:
            continue
        global_id_groups.setdefault(document_id, []).append(document)

    issues: list[StructureValidationIssue] = []
    for task_id, documents in sorted(global_id_groups.items()):
        if len(documents) < 2:
            continue
        paths = ", ".join(str(document.path.resolve()) for document in documents)
        for document in sorted(documents, key=lambda item: item.path):
            issues.append(
                StructureValidationIssue(
                    rule_id=RULE_PLANNING_TASK_ID_DUPLICATE,
                    message=(
                        f"Global task id `{task_id}` is used by multiple task "
                        f"records: {paths}."
                    ),
                    path=document.path.resolve(),
                    document_id=document.document_id,
                )
            )
    return issues


def _validate_task_registry_index(
    registry: DocumentRegistry,
) -> list[StructureValidationIssue]:
    registry_document = _find_task_registry_document(registry)
    if registry_document is None:
        return []

    task_index = registry_document.frontmatter.get("task_index")
    if not isinstance(task_index, list):
        return []

    project_root = _project_root_from_task_registry(registry_document.path)
    issues: list[StructureValidationIssue] = []
    for entry in task_index:
        if not isinstance(entry, dict):
            continue

        task_id = entry.get("id")
        path_value = entry.get("path")
        if not isinstance(task_id, str) or not task_id:
            continue
        if not isinstance(path_value, str) or not path_value:
            continue

        task_document = registry.get_by_id(task_id)
        if task_document is None:
            issues.append(
                StructureValidationIssue(
                    rule_id=RULE_PLANNING_TASK_INDEX_UNKNOWN_ID,
                    message=f"Task registry index references unknown task id `{task_id}`.",
                    path=registry_document.path.resolve(),
                    document_id=registry_document.document_id,
                    target_id=task_id,
                )
            )
            continue

        expected_path = Path(path_value)
        if not expected_path.is_absolute():
            expected_path = project_root / expected_path
        expected_path = expected_path.resolve()
        actual_path = task_document.path.resolve()
        if expected_path != actual_path:
            issues.append(
                StructureValidationIssue(
                    rule_id=RULE_PLANNING_TASK_INDEX_PATH_MISMATCH,
                    message=(
                        f"Task registry index maps `{task_id}` to `{path_value}`, "
                        f"but the task record is at `{actual_path}`."
                    ),
                    path=registry_document.path.resolve(),
                    document_id=registry_document.document_id,
                    target_id=task_id,
                )
            )

    return issues


def _find_task_registry_document(registry: DocumentRegistry) -> RegistryDocument | None:
    for document in registry.documents_by_path.values():
        relative_parts = _planning_relative_parts(document.path)
        if relative_parts == ("task-registry.md",):
            return document
    return None


def _project_root_from_task_registry(path: Path) -> Path:
    parts = path.resolve().parts
    for index in range(len(parts) - 1):
        if parts[index] == "ai-docs" and parts[index + 1] == "planning":
            return Path(*parts[:index])
    return path.resolve().parent


def _validate_task_placement(
    document: RegistryDocument,
) -> list[StructureValidationIssue]:
    scope = document.frontmatter.get("scope")
    status = _string_value(document.frontmatter.get("status"))
    if not isinstance(scope, dict):
        if status in ACTIVE_EXECUTABLE_PLACEMENT_REQUIRED_STATUSES:
            return [
                StructureValidationIssue(
                    rule_id=RULE_PLANNING_MISSING_PLACEMENT,
                    message=(
                        "Active executable task must define "
                        "`scope.placement`."
                    ),
                    path=document.path.resolve(),
                    document_id=document.document_id,
                )
            ]
        return []

    placement = scope.get("placement")
    if placement is None:
        if status in ACTIVE_EXECUTABLE_PLACEMENT_REQUIRED_STATUSES:
            return [
                StructureValidationIssue(
                    rule_id=RULE_PLANNING_MISSING_PLACEMENT,
                    message=(
                        "Active executable task must define "
                        "`scope.placement`."
                    ),
                    path=document.path.resolve(),
                    document_id=document.document_id,
                )
            ]
        return []
    if not isinstance(placement, str) or placement not in TASK_PLACEMENTS:
        return [
            StructureValidationIssue(
                rule_id=RULE_PLANNING_INVALID_PLACEMENT,
                message=f"Task has invalid placement `{placement}`.",
                path=document.path.resolve(),
                document_id=document.document_id,
            )
        ]

    issues: list[StructureValidationIssue] = []
    for field in REQUIRED_SCOPE_FIELDS_BY_PLACEMENT[placement]:
        if field in scope and scope[field] not in {None, ""}:
            continue
        issues.append(
            StructureValidationIssue(
                rule_id=RULE_PLANNING_MISSING_PLACEMENT_FIELD,
                message=(
                    f"Task placement `{placement}` requires scope field "
                    f"`{field}`."
                ),
                path=document.path.resolve(),
                document_id=document.document_id,
            )
        )
    return issues


def _validate_readiness_proposals(
    document: RegistryDocument,
) -> list[StructureValidationIssue]:
    section = _section_text(document.body, "Readiness Proposals")
    if section is None:
        return []

    proposal_blocks = _readiness_proposal_blocks(section)
    if not proposal_blocks:
        return []

    issues: list[StructureValidationIssue] = []
    for index, block in enumerate(proposal_blocks, start=1):
        disposition = _field_value(block, "Disposition")
        if disposition in READINESS_PROPOSAL_DISPOSITIONS:
            continue
        issues.append(
            StructureValidationIssue(
                rule_id=RULE_PLANNING_INVALID_READINESS_PROPOSAL,
                message=(
                    f"Readiness proposal {index} must include a valid "
                    "`Disposition:`."
                ),
                path=document.path.resolve(),
                document_id=document.document_id,
                section="## Readiness Proposals",
            )
        )
    return issues


def _allowed_planning_statuses(document_type: str) -> set[str]:
    if document_type == "plan":
        return ACTIVE_PLAN_STATUSES
    return PLANNING_EXECUTION_STATUSES


def _is_in_active_planning_tree(
    document: RegistryDocument,
    registry: DocumentRegistry,
) -> bool:
    status = _string_value(document.frontmatter.get("status"))
    if status in {"exported", "archived", "deprecated"}:
        return False

    document_type = _string_value(document.frontmatter.get("type"))
    if document_type == "plan":
        return status not in {"done", "deferred"}

    scope = document.frontmatter.get("scope")
    plan_slug = scope.get("plan") if isinstance(scope, dict) else None
    if not isinstance(plan_slug, str) or not plan_slug:
        return True

    for candidate in registry.documents_by_path.values():
        candidate_type = _string_value(candidate.frontmatter.get("type"))
        if candidate_type != "plan":
            continue
        candidate_scope = candidate.frontmatter.get("scope")
        candidate_plan_slug = (
            candidate_scope.get("plan") if isinstance(candidate_scope, dict) else None
        )
        if candidate_plan_slug != plan_slug:
            continue
        candidate_status = _string_value(candidate.frontmatter.get("status"))
        return candidate_status not in {
            "done",
            "exported",
            "archived",
            "deferred",
            "deprecated",
        }

    return True


def _validate_closing_observations(
    document: RegistryDocument,
) -> list[StructureValidationIssue]:
    section = _section_text(document.body, "Closing Observations")
    if section is None:
        return []
    stripped = section.strip()
    if not stripped or stripped in {"None.", "Closing observations: None."}:
        return []
    observation_blocks = _closing_observation_blocks(stripped)
    if not observation_blocks:
        return []

    issues: list[StructureValidationIssue] = []
    required_fields = (
        "Impact",
        "Action taken",
        "Disposition",
        "Rationale",
        "Follow-up",
    )
    for index, block in enumerate(observation_blocks, start=1):
        for field in required_fields:
            if re.search(rf"^\s*{re.escape(field)}\s*:", block, re.MULTILINE):
                continue
            issues.append(
                StructureValidationIssue(
                    rule_id=RULE_PLANNING_UNRESOLVED_OBSERVATION,
                    message=(
                        f"Closing observation {index} is missing required field "
                        f"`{field}:`."
                    ),
                    path=document.path.resolve(),
                    document_id=document.document_id,
                    section="## Closing Observations",
                )
            )

    return issues


def _validate_intake_checklist(
    document: RegistryDocument,
) -> list[StructureValidationIssue]:
    section = _section_text(document.body, "Intake Checklist")
    if section is None:
        return [
            StructureValidationIssue(
                rule_id=RULE_PLANNING_MISSING_INTAKE_CHECKLIST,
                message=(
                    "Executable task is missing required section "
                    "`## Intake Checklist`."
                ),
                path=document.path.resolve(),
                document_id=document.document_id,
                section="## Intake Checklist",
            )
        ]

    document_type = _string_value(document.frontmatter.get("type"))
    required_items = (
        (
            "Read `.ai-docs/workflows/plan-stage-workflow.md`",
            "Read active plan",
            "Read active stage",
            "Read this task",
        )
        if document_type == "implementation_task"
        else (
            "Read `.ai-docs/workflows/plan-stage-workflow.md`",
            "Review standalone scope rationale",
            "Read this task",
        )
    )

    issues: list[StructureValidationIssue] = []
    for item in required_items:
        if _checked_checklist_item(section, item):
            continue
        issues.append(
            StructureValidationIssue(
                rule_id=RULE_PLANNING_INCOMPLETE_INTAKE_CHECKLIST,
                message=f"Intake checklist must include checked item `{item}`.",
                path=document.path.resolve(),
                document_id=document.document_id,
                section="## Intake Checklist",
            )
        )

    return issues


def _validate_closure_checklist(
    document: RegistryDocument,
) -> list[StructureValidationIssue]:
    section = _section_text(document.body, "Closure Checklist")
    if section is None:
        return []
    if re.search(
        r"^\s*observations_reported_with_disposition\s*:\s*true\s*$",
        section,
        re.MULTILINE,
    ):
        return []
    return [
        StructureValidationIssue(
            rule_id=RULE_PLANNING_INCOMPLETE_CLOSURE_CHECKLIST,
            message=(
                "Closure checklist must include "
                "`observations_reported_with_disposition: true`."
            ),
            path=document.path.resolve(),
            document_id=document.document_id,
            section="## Closure Checklist",
        )
    ]


def _checked_checklist_item(section: str, item: str) -> bool:
    return re.search(
        rf"^\s*-\s+\[[xX]\]\s+{re.escape(item)}\s*$",
        section,
        re.MULTILINE,
    ) is not None


def _closing_observation_blocks(section: str) -> list[str]:
    matches = list(re.finditer(r"(?m)^-\s+Observation\s*:", section))
    blocks: list[str] = []
    for index, match in enumerate(matches):
        end = matches[index + 1].start() if index + 1 < len(matches) else len(section)
        blocks.append(section[match.start():end])
    return blocks


def _readiness_proposal_blocks(section: str) -> list[str]:
    matches = list(re.finditer(r"(?m)^-\s+Proposal\s*:", section))
    blocks: list[str] = []
    for index, match in enumerate(matches):
        end = matches[index + 1].start() if index + 1 < len(matches) else len(section)
        blocks.append(section[match.start():end])
    return blocks


def _field_value(block: str, field: str) -> str | None:
    match = re.search(
        rf"^\s*{re.escape(field)}\s*:\s*(?P<value>\S.*?)\s*$",
        block,
        re.MULTILINE,
    )
    if match is None:
        return None
    return match.group("value").strip()


def _section_text(body: str, section: str) -> str | None:
    lines = body.splitlines()
    start: int | None = None
    for index, line in enumerate(lines):
        match = _HEADING_PATTERN.match(line.strip())
        if match and match.group("title").strip() == section:
            start = index + 1
            continue
        if start is not None and match:
            return "\n".join(lines[start:index])
    if start is None:
        return None
    return "\n".join(lines[start:])


def _second_level_headings(body: str) -> set[str]:
    headings: set[str] = set()
    for line in body.splitlines():
        match = _HEADING_PATTERN.match(line.strip())
        if match:
            headings.add(match.group("title").strip())
    return headings


def _sorted_documents(registry: DocumentRegistry) -> tuple[RegistryDocument, ...]:
    return tuple(
        registry.documents_by_path[path]
        for path in sorted(registry.documents_by_path)
    )


def _string_value(value: Any) -> str | None:
    return value if isinstance(value, str) and value else None
