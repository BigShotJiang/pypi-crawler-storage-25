from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml


DEFAULT_CONFIG_FILE = "ai-docs.config.yaml"
DEFAULT_DOCUMENTATION_ROOTS = ("ai-docs",)
DEFAULT_EXCLUDED_DIRECTORIES = (
    ".git",
    ".hg",
    ".svn",
    ".venv",
    "venv",
    "node_modules",
    "__pycache__",
    ".pytest_cache",
)


@dataclass(frozen=True)
class ConfigError:
    code: str
    message: str
    path: str | None = None


@dataclass(frozen=True)
class ToolkitConfig:
    project_root: Path
    config_path: Path | None
    project_name: str | None
    documentation_roots: tuple[Path, ...]
    schema_roots: tuple[Path, ...]
    excluded_directories: tuple[str, ...] = DEFAULT_EXCLUDED_DIRECTORIES


@dataclass(frozen=True)
class ConfigLoadResult:
    config: ToolkitConfig | None
    errors: tuple[ConfigError, ...] = ()

    @property
    def ok(self) -> bool:
        return self.config is not None and not self.errors


def load_project_config(
    project_root: str | Path,
    *,
    config_file: str = DEFAULT_CONFIG_FILE,
) -> ConfigLoadResult:
    root = Path(project_root).resolve()
    config_path = root / config_file

    if not config_path.exists():
        return _build_config(root, config_path=None, raw_config={})

    try:
        raw_loaded = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    except yaml.YAMLError as exc:
        return ConfigLoadResult(
            config=None,
            errors=(
                ConfigError(
                    "invalid_config_yaml",
                    f"Invalid YAML config: {getattr(exc, 'problem', None) or str(exc)}",
                    path=str(config_path),
                ),
            ),
        )

    if raw_loaded is None:
        raw_config: dict[str, Any] = {}
    elif isinstance(raw_loaded, dict):
        raw_config = raw_loaded
    else:
        return ConfigLoadResult(
            config=None,
            errors=(
                ConfigError(
                    "invalid_config_type",
                    "Project config must parse to a mapping object.",
                    path=str(config_path),
                ),
            ),
        )

    return _build_config(root, config_path=config_path, raw_config=raw_config)


def _build_config(
    project_root: Path,
    *,
    config_path: Path | None,
    raw_config: dict[str, Any],
) -> ConfigLoadResult:
    project = raw_config.get("project", {})
    if project is None:
        project = {}

    if not isinstance(project, dict):
        return ConfigLoadResult(
            config=None,
            errors=(
                ConfigError(
                    "invalid_project_config",
                    "`project` config section must be a mapping object.",
                    path=str(config_path) if config_path else None,
                ),
            ),
        )

    roots_value = project.get("documentation_roots", list(DEFAULT_DOCUMENTATION_ROOTS))
    if not isinstance(roots_value, list) or not all(
        isinstance(item, str) and item for item in roots_value
    ):
        return ConfigLoadResult(
            config=None,
            errors=(
                ConfigError(
                    "invalid_documentation_roots",
                    "`project.documentation_roots` must be a non-empty list of paths.",
                    path=str(config_path) if config_path else None,
                ),
            ),
        )

    roots = tuple((project_root / item).resolve() for item in roots_value)
    missing_roots = tuple(path for path in roots if not path.exists())
    if missing_roots:
        missing = ", ".join(str(path) for path in missing_roots)
        return ConfigLoadResult(
            config=None,
            errors=(
                ConfigError(
                    "missing_documentation_root",
                    f"Configured documentation root does not exist: {missing}",
                    path=str(config_path) if config_path else None,
                ),
            ),
        )

    project_name = project.get("name")
    if project_name is not None and not isinstance(project_name, str):
        return ConfigLoadResult(
            config=None,
            errors=(
                ConfigError(
                    "invalid_project_name",
                    "`project.name` must be a string when provided.",
                    path=str(config_path) if config_path else None,
                ),
            ),
        )

    schemas = raw_config.get("schemas", {})
    if schemas is None:
        schemas = {}

    if not isinstance(schemas, dict):
        return ConfigLoadResult(
            config=None,
            errors=(
                ConfigError(
                    "invalid_schemas_config",
                    "`schemas` config section must be a mapping object.",
                    path=str(config_path) if config_path else None,
                ),
            ),
        )

    schema_roots_value = schemas.get("roots", [".ai-docs/schemas"])
    if not isinstance(schema_roots_value, list) or not all(
        isinstance(item, str) and item for item in schema_roots_value
    ):
        return ConfigLoadResult(
            config=None,
            errors=(
                ConfigError(
                    "invalid_schema_roots",
                    "`schemas.roots` must be a non-empty list of paths.",
                    path=str(config_path) if config_path else None,
                ),
            ),
        )

    schema_roots = tuple((project_root / item).resolve() for item in schema_roots_value)

    return ConfigLoadResult(
        config=ToolkitConfig(
            project_root=project_root,
            config_path=config_path,
            project_name=project_name,
            documentation_roots=roots,
            schema_roots=schema_roots,
        )
    )
