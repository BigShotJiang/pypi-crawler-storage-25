from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date
from pathlib import Path


_SLUG_PATTERN = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
_TASK_ID_PATTERN = re.compile(r"^TASK-\d{6}$")


@dataclass(frozen=True)
class PlanningScaffoldResult:
    exit_code: int
    created: tuple[str, ...]
    skipped: tuple[str, ...]
    errors: tuple[str, ...]


@dataclass(frozen=True)
class PlanningLayoutMigrationResult:
    moves: tuple[tuple[str, str], ...]


def scaffold_planning_record(
    project_root: str | Path,
    *,
    plan_slug: str,
    stage_slug: str,
    task_slug: str,
    task_id: str,
    plan_date: date | None = None,
) -> PlanningScaffoldResult:
    errors = _validate_inputs(plan_slug, stage_slug, task_slug, task_id)
    if errors:
        return PlanningScaffoldResult(3, (), (), tuple(errors))

    root = Path(project_root)
    effective_date = plan_date or date.today()
    plan_path = (
        root
        / "ai-docs"
        / "planning"
        / f"{effective_date.isoformat()}-{plan_slug}"
        / "plan.md"
    )
    stage_path = plan_path.parent / f"stage-1-{stage_slug}" / "stage.md"
    task_path = stage_path.parent / f"task-1-{task_slug}.md"
    plan_ref = plan_path.relative_to(root).as_posix()
    stage_ref = stage_path.relative_to(root).as_posix()
    task_ref = task_path.relative_to(root).as_posix()

    files = {
        plan_path: _plan_content(plan_slug, stage_slug, stage_ref, task_ref),
        stage_path: _stage_content(plan_slug, stage_slug, plan_ref, task_ref),
        task_path: _task_content(
            plan_slug,
            stage_slug,
            task_slug,
            task_id,
            plan_ref,
            stage_ref,
        ),
    }

    created: list[str] = []
    skipped: list[str] = []
    write_errors: list[str] = []
    for path, content in files.items():
        relative_path = path.relative_to(root).as_posix()
        if path.exists():
            skipped.append(relative_path)
            continue
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding="utf-8")
        except OSError as exc:
            write_errors.append(f"{relative_path}: {exc}")
            continue
        created.append(relative_path)

    return PlanningScaffoldResult(
        exit_code=1 if write_errors else 0,
        created=tuple(created),
        skipped=tuple(skipped),
        errors=tuple(write_errors),
    )


def format_planning_scaffold_result(result: PlanningScaffoldResult) -> str:
    lines = [
        "ai-docs planning scaffold",
        "created:",
        *_format_list(result.created),
        "skipped:",
        *_format_list(result.skipped),
    ]
    if result.errors:
        lines.extend(["errors:", *_format_list(result.errors)])
    return "\n".join(lines)


def planning_layout_migration_dry_run(
    project_root: str | Path,
) -> PlanningLayoutMigrationResult:
    root = Path(project_root)
    planning_root = root / "ai-docs" / "planning"
    if not planning_root.exists():
        return PlanningLayoutMigrationResult(moves=())

    moves: list[tuple[str, str]] = []
    for path in sorted(planning_root.rglob("phase-*")):
        if not path.is_dir():
            continue
        target = path.with_name("stage-" + path.name.removeprefix("phase-"))
        moves.append(
            (
                path.relative_to(root).as_posix(),
                target.relative_to(root).as_posix(),
            )
        )
    return PlanningLayoutMigrationResult(moves=tuple(moves))


def format_planning_layout_migration_dry_run(
    result: PlanningLayoutMigrationResult,
) -> str:
    lines = ["ai-docs planning migrate-layout --dry-run"]
    if not result.moves:
        lines.append("moves: none")
        return "\n".join(lines)

    lines.append("moves:")
    for source, target in result.moves:
        lines.append(f"- {source} -> {target}")
    lines.append("reference_updates_required: true")
    return "\n".join(lines)


def _validate_inputs(
    plan_slug: str,
    stage_slug: str,
    task_slug: str,
    task_id: str,
) -> list[str]:
    errors: list[str] = []
    for label, value in (
        ("plan", plan_slug),
        ("stage", stage_slug),
        ("task", task_slug),
    ):
        if _SLUG_PATTERN.fullmatch(value) is None:
            errors.append(f"`--{label}` must be a lowercase kebab-case slug.")
    if _TASK_ID_PATTERN.fullmatch(task_id) is None:
        errors.append("`--task-id` must match `TASK-NNNNNN`.")
    return errors


def _format_list(values: tuple[str, ...]) -> list[str]:
    if not values:
        return ["- none"]
    return [f"- {value}" for value in values]


def _title(slug: str) -> str:
    return " ".join(part.capitalize() for part in slug.split("-"))


def _document_id(prefix: str, *slugs: str) -> str:
    suffix = "-".join(slugs).upper()
    return f"{prefix}-{suffix}-001"


def _plan_content(
    plan_slug: str,
    stage_slug: str,
    stage_ref: str,
    task_ref: str,
) -> str:
    title = _title(plan_slug)
    return f"""---
id: {_document_id("PLAN", plan_slug)}
type: plan
status: planned
scope:
  plan: {plan_slug}
  modules: []
owners:
  - maintainers
related:
  stages:
    - {stage_ref}
  tasks:
    - {task_ref}
ai:
  priority: medium
  load_when:
    - topic: planning
---

# {title}

## Goal

TBD.

## Readiness

Status: planned

Blocking questions:
- TBD.

## Stages

## Stage 1: {_title(stage_slug)}

Status: planned

Stage document:
- {stage_ref}
"""


def _stage_content(
    plan_slug: str,
    stage_slug: str,
    plan_ref: str,
    task_ref: str,
) -> str:
    title = _title(stage_slug)
    return f"""---
id: {_document_id("STAGE", plan_slug, stage_slug)}
type: plan_stage
status: planned
scope:
  plan: {plan_slug}
  stage: {stage_slug}
  modules: []
owners:
  - maintainers
related:
  plans:
    - {plan_ref}
  tasks:
    - {task_ref}
ai:
  priority: medium
  load_when:
    - topic: planning
---

# Stage 1: {title}

## Outcome

TBD.

## Scope

- TBD.

## Readiness

Status: planned

Blocking questions:
- TBD.

## Task Decomposition

Status: planned

Ordered tasks:
- Task 1: TBD.
"""


def _task_content(
    plan_slug: str,
    stage_slug: str,
    task_slug: str,
    task_id: str,
    plan_ref: str,
    stage_ref: str,
) -> str:
    title = _title(task_slug)
    return f"""---
id: {task_id}
type: implementation_task
status: planned
scope:
  placement: plan_stage
  plan: {plan_slug}
  stage: {stage_slug}
  task_order: 1
  modules: []
owners:
  - maintainers
related:
  plans:
    - {plan_ref}
  stages:
    - {stage_ref}
ai:
  priority: medium
  load_when:
    - topic: planning
---

# Task 1: {title}

## Purpose

TBD.

## Source Documents

- {plan_ref}
- {stage_ref}

## Expected Changes

- TBD.

## Acceptance Criteria

- TBD.

## Test Plan

- Run `ai-docs validate`.
"""
