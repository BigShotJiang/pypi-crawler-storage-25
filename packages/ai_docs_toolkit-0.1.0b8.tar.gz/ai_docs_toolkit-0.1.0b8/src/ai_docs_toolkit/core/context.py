from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ai_docs_toolkit.core.graph import DocumentGraph, DocumentGraphEdge, DocumentGraphNode
from ai_docs_toolkit.core.registry import DocumentRegistry, RegistryDocument

RULE_DOCUMENT_CONTEXT_NO_SOURCES = "document.context.no_sources"
RULE_DOCUMENT_CONTEXT_UNKNOWN_ID = "document.context.unknown_id"

EXCLUDED_STATUSES = frozenset({"deprecated", "archived", "exported"})
PRIORITY_ORDER = {
    "critical": 0,
    "high": 1,
    "medium": 2,
    "low": 3,
}
GROUP_ORDER = {
    "source": 0,
    "constraint": 1,
    "decision": 2,
    "contract": 3,
    "behavior": 4,
    "validation": 5,
    "operation": 6,
    "support": 7,
}
TYPE_GROUPS = {
    "business_rule": "constraint",
    "architecture_decision": "decision",
    "contract": "contract",
    "module": "behavior",
    "scenario": "behavior",
    "acceptance": "validation",
    "test_case": "validation",
    "operation": "operation",
}


@dataclass(frozen=True)
class ContextSource:
    document_id: str
    type: str | None
    path: str
    source: str
    changed_file: str | None = None


@dataclass(frozen=True)
class ContextReason:
    source: str
    via: str | None
    relationship: str
    direction: str
    message: str


@dataclass(frozen=True)
class ContextDocument:
    document_id: str
    type: str | None
    path: str
    title: str | None
    summary: str | None
    context_role: str | None
    priority: str | None
    group: str
    distance: int
    reasons: tuple[ContextReason, ...]


@dataclass(frozen=True)
class ContextSelectionIssue:
    rule_id: str
    message: str
    document_id: str | None = None
    severity: str = "error"


@dataclass(frozen=True)
class ContextSelectionResult:
    sources: tuple[ContextSource, ...]
    documents: tuple[ContextDocument, ...]
    issues: tuple[ContextSelectionIssue, ...] = ()

    @property
    def ok(self) -> bool:
        return not any(issue.severity == "error" for issue in self.issues)


def select_context_by_ids(
    graph: DocumentGraph,
    registry: DocumentRegistry,
    source_ids: tuple[str, ...] | list[str],
) -> ContextSelectionResult:
    unique_source_ids = tuple(dict.fromkeys(source_ids))
    issues = tuple(
        ContextSelectionIssue(
            rule_id=RULE_DOCUMENT_CONTEXT_UNKNOWN_ID,
            message=f"Context source references unknown document id `{document_id}`.",
            document_id=document_id,
        )
        for document_id in sorted(
            document_id
            for document_id in unique_source_ids
            if graph.get_node(document_id) is None
        )
    )
    sources = _sources_from_ids(graph, registry, unique_source_ids, source="id")
    return _select_context(graph, registry, sources, issues=issues)


def select_context_by_module(
    graph: DocumentGraph,
    registry: DocumentRegistry,
    module: str,
) -> ContextSelectionResult:
    sources = _sources_from_ids(
        graph,
        registry,
        tuple(
            node.id
            for node in graph.nodes
            if module in ((node.scope or {}).get("modules") or ())
        ),
        source="module",
    )
    return _select_context(graph, registry, sources)


def select_context_by_feature(
    graph: DocumentGraph,
    registry: DocumentRegistry,
    feature: str,
) -> ContextSelectionResult:
    sources = _sources_from_ids(
        graph,
        registry,
        tuple(
            node.id
            for node in graph.nodes
            if feature in ((node.scope or {}).get("features") or ())
        ),
        source="feature",
    )
    return _select_context(graph, registry, sources)


def select_context_by_changed_ids(
    graph: DocumentGraph,
    registry: DocumentRegistry,
    changed_files_by_id: dict[str, str],
) -> ContextSelectionResult:
    sources = _sources_from_ids(
        graph,
        registry,
        tuple(changed_files_by_id),
        source="changed",
        changed_files_by_id=changed_files_by_id,
    )
    return _select_context(graph, registry, sources)


def _sources_from_ids(
    graph: DocumentGraph,
    registry: DocumentRegistry,
    source_ids: tuple[str, ...],
    *,
    source: str,
    changed_files_by_id: dict[str, str] | None = None,
) -> tuple[ContextSource, ...]:
    sources: list[ContextSource] = []
    for document_id in source_ids:
        node = graph.get_node(document_id)
        if node is None or _is_excluded(registry.get_by_id(document_id)):
            continue
        sources.append(
            ContextSource(
                document_id=node.id,
                type=node.type,
                path=node.path,
                source=source,
                changed_file=(changed_files_by_id or {}).get(node.id),
            )
        )
    return tuple(sorted(sources, key=lambda item: (item.source, item.document_id, item.path)))


def _select_context(
    graph: DocumentGraph,
    registry: DocumentRegistry,
    sources: tuple[ContextSource, ...],
    *,
    issues: tuple[ContextSelectionIssue, ...] = (),
) -> ContextSelectionResult:
    if not sources:
        issues = (
            *issues,
            ContextSelectionIssue(
                rule_id=RULE_DOCUMENT_CONTEXT_NO_SOURCES,
                message="Context selection did not find source documents.",
            ),
        )
        return ContextSelectionResult(sources=(), documents=(), issues=issues)

    reasons_by_document: dict[str, list[ContextReason]] = {}
    distances: dict[str, int] = {}
    for source in sources:
        reasons_by_document.setdefault(source.document_id, []).append(
            ContextReason(
                source=source.document_id,
                via=None,
                relationship="source",
                direction="self",
                message=f"{source.document_id} is a context source.",
            )
        )
        distances[source.document_id] = 0

        source_node = graph.get_node(source.document_id)
        if source_node is None:
            continue

        for neighbor, edge, direction in _direct_neighbors(graph, registry, source_node):
            previous_distance = distances.get(neighbor.id)
            if previous_distance is None or previous_distance > 1:
                distances[neighbor.id] = 1
            reasons_by_document.setdefault(neighbor.id, []).append(
                _relationship_reason(
                    source=source.document_id,
                    edge=edge,
                    direction=direction,
                )
            )

    documents = tuple(
        sorted(
            (
                _context_document(
                    node,
                    registry=registry,
                    distance=distances[node.id],
                    reasons=tuple(sorted(reasons_by_document[node.id], key=_reason_sort_key)),
                )
                for node in graph.nodes
                if node.id in distances
            ),
            key=_document_sort_key,
        )
    )
    return ContextSelectionResult(sources=sources, documents=documents, issues=issues)


def _direct_neighbors(
    graph: DocumentGraph,
    registry: DocumentRegistry,
    node: DocumentGraphNode,
) -> tuple[tuple[DocumentGraphNode, DocumentGraphEdge, str], ...]:
    neighbors: list[tuple[DocumentGraphNode, DocumentGraphEdge, str]] = []
    for edge in graph.edges:
        if edge.source == node.id:
            target = graph.get_node(edge.target)
            if target is not None and not _is_excluded(registry.get_by_id(target.id)):
                neighbors.append((target, edge, "outgoing"))

        if edge.target == node.id:
            source = graph.get_node(edge.source)
            if source is not None and not _is_excluded(registry.get_by_id(source.id)):
                neighbors.append((source, edge, "incoming"))

    return tuple(sorted(neighbors, key=lambda item: (item[0].id, item[1].relationship, item[2])))


def _relationship_reason(
    *,
    source: str,
    edge: DocumentGraphEdge,
    direction: str,
) -> ContextReason:
    return ContextReason(
        source=source,
        via=None,
        relationship=edge.relationship,
        direction=direction,
        message=f"{edge.source} references {edge.target} through related.{edge.relationship}.",
    )


def _context_document(
    node: DocumentGraphNode,
    *,
    registry: DocumentRegistry,
    distance: int,
    reasons: tuple[ContextReason, ...],
) -> ContextDocument:
    document = registry.get_by_id(node.id)
    frontmatter = document.frontmatter if document is not None else {}
    priority = _ai_string(frontmatter, "priority")
    context_role = _ai_string(frontmatter, "context_role")
    return ContextDocument(
        document_id=node.id,
        type=node.type,
        path=node.path,
        title=node.title,
        summary=node.summary,
        context_role=context_role,
        priority=priority,
        group="source" if distance == 0 else TYPE_GROUPS.get(node.type or "", "support"),
        distance=distance,
        reasons=reasons,
    )


def _is_excluded(document: RegistryDocument | None) -> bool:
    if document is None:
        return True
    status = document.frontmatter.get("status")
    return isinstance(status, str) and status in EXCLUDED_STATUSES


def _ai_string(frontmatter: dict[str, Any], key: str) -> str | None:
    ai = frontmatter.get("ai")
    if not isinstance(ai, dict):
        return None
    value = ai.get(key)
    return value if isinstance(value, str) and value else None


def _reason_sort_key(reason: ContextReason) -> tuple[str, str, str, str]:
    return (
        reason.source,
        reason.via or "",
        reason.relationship,
        reason.direction,
    )


def _document_sort_key(document: ContextDocument) -> tuple[int, int, int, str, str, str]:
    return (
        GROUP_ORDER.get(document.group, GROUP_ORDER["support"]),
        PRIORITY_ORDER.get(document.priority or "", PRIORITY_ORDER["medium"]),
        document.distance,
        document.type or "",
        document.document_id,
        document.path,
    )
