from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ai_docs_toolkit.core.registry import DocumentRegistry, RegistryDocument


@dataclass(frozen=True)
class DocumentGraphNode:
    id: str
    type: str | None
    path: str
    title: str | None = None
    summary: str | None = None
    scope: dict[str, list[str]] | None = None


@dataclass(frozen=True)
class DocumentGraphEdge:
    source: str
    target: str
    relationship: str
    source_path: str
    target_path: str


@dataclass(frozen=True)
class DocumentGraph:
    nodes: tuple[DocumentGraphNode, ...]
    edges: tuple[DocumentGraphEdge, ...]

    def get_node(self, document_id: str) -> DocumentGraphNode | None:
        for node in self.nodes:
            if node.id == document_id:
                return node
        return None


def build_document_graph(
    registry: DocumentRegistry,
    *,
    project_root: str | Path | None = None,
) -> DocumentGraph:
    root = Path(project_root).resolve() if project_root is not None else None
    nodes = tuple(
        sorted(
            (
                _node_from_document(document, project_root=root)
                for document in registry.documents_by_id.values()
            ),
            key=lambda node: (node.id, node.path),
        )
    )
    edges = tuple(sorted(_graph_edges(registry, project_root=root), key=_edge_sort_key))
    return DocumentGraph(nodes=nodes, edges=edges)


def _node_from_document(
    document: RegistryDocument,
    *,
    project_root: Path | None,
) -> DocumentGraphNode:
    document_id = document.document_id
    if document_id is None:
        raise ValueError("Graph nodes require documents with ids.")

    return DocumentGraphNode(
        id=document_id,
        type=_string_value(document.frontmatter.get("type")),
        path=_display_path(document.path, project_root),
        title=_string_value(document.frontmatter.get("title")),
        summary=_string_value(document.frontmatter.get("summary")),
        scope=_scope_value(document.frontmatter.get("scope")),
    )


def _graph_edges(
    registry: DocumentRegistry,
    *,
    project_root: Path | None,
) -> set[DocumentGraphEdge]:
    edges: set[DocumentGraphEdge] = set()

    for source in registry.documents_by_id.values():
        source_id = source.document_id
        if source_id is None:
            continue

        related = source.frontmatter.get("related")
        if not isinstance(related, dict):
            continue

        for relationship, targets in related.items():
            if not isinstance(relationship, str) or not isinstance(targets, list):
                continue

            for target_id in targets:
                if not isinstance(target_id, str) or not target_id:
                    continue

                target = registry.get_by_id(target_id)
                if target is None:
                    continue

                edges.add(
                    DocumentGraphEdge(
                        source=source_id,
                        target=target_id,
                        relationship=relationship,
                        source_path=_display_path(source.path, project_root),
                        target_path=_display_path(target.path, project_root),
                    )
                )

    return edges


def _display_path(path: Path, project_root: Path | None) -> str:
    resolved = path.resolve()
    if project_root is None:
        return str(resolved)

    try:
        return resolved.relative_to(project_root).as_posix()
    except ValueError:
        return str(resolved)


def _scope_value(value: Any) -> dict[str, list[str]] | None:
    if not isinstance(value, dict):
        return None

    scope: dict[str, list[str]] = {}
    for key in ("domains", "modules", "features"):
        items = value.get(key)
        if isinstance(items, list):
            scope[key] = [item for item in items if isinstance(item, str)]
        else:
            scope[key] = []
    return scope


def _string_value(value: Any) -> str | None:
    return value if isinstance(value, str) and value else None


def _edge_sort_key(edge: DocumentGraphEdge) -> tuple[str, str, str]:
    return (edge.source, edge.relationship, edge.target)
