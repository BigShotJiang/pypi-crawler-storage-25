from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path
from typing import Any
from urllib.parse import urljoin

import yaml
from jsonschema import Draft202012Validator
from referencing import Registry, Resource
from referencing.jsonschema import DRAFT202012

RULE_SCHEMA_INVALID = "document.schema.invalid"
RULE_SCHEMA_UNKNOWN_TYPE = "document.schema.unknown_type"


@dataclass(frozen=True)
class SchemaValidationIssue:
    rule_id: str
    message: str
    path: str | None = None
    document_id: str | None = None
    schema_path: str | None = None
    severity: str = "error"


@dataclass(frozen=True)
class SchemaValidationResult:
    issues: tuple[SchemaValidationIssue, ...] = ()

    @property
    def ok(self) -> bool:
        return not self.issues


@dataclass(frozen=True)
class SchemaValidator:
    schemas_root: Path
    common_schema_path: Path
    document_type_schemas_path: Path
    registry: Registry
    schemas_by_type: dict[str, tuple[dict[str, Any], str]]

    @classmethod
    def load(
        cls,
        schemas_root: str | Path = ".ai-docs/schemas",
        *,
        common_schema: str | Path = "frontmatter.schema.yaml",
        document_type_schemas: str | Path = "document-types",
    ) -> SchemaValidator:
        root = Path(schemas_root).resolve()
        common_path = _resolve_child(root, common_schema)
        type_schemas_path = _resolve_child(root, document_type_schemas)

        schema_documents = _load_schema_documents(root)
        resources = [
            (uri, Resource.from_contents(schema, default_specification=DRAFT202012))
            for uri, schema in schema_documents
        ]
        registry = Registry().with_resources(resources)

        schemas_by_type: dict[str, tuple[dict[str, Any], str]] = {}
        for schema_path in sorted(type_schemas_path.glob("*.schema.yaml")):
            schema = _load_yaml_mapping(schema_path)
            document_type = _extract_const_type(schema)
            schema_id = schema.get("$id")
            if isinstance(document_type, str) and isinstance(schema_id, str):
                schemas_by_type[document_type] = (schema, schema_id)

        return cls(
            schemas_root=root,
            common_schema_path=common_path,
            document_type_schemas_path=type_schemas_path,
            registry=registry,
            schemas_by_type=schemas_by_type,
        )

    def validate_frontmatter(
        self,
        frontmatter: dict[str, Any],
        *,
        path: str | None = None,
    ) -> SchemaValidationResult:
        document_id = _string_value(frontmatter.get("id"))
        document_type = _string_value(frontmatter.get("type"))

        if document_type is None or document_type not in self.schemas_by_type:
            return SchemaValidationResult(
                issues=(
                    SchemaValidationIssue(
                        rule_id=RULE_SCHEMA_UNKNOWN_TYPE,
                        message=f"Unknown document type: {document_type!r}.",
                        path=path,
                        document_id=document_id,
                        schema_path="type",
                    ),
                )
            )

        schema, schema_id = self.schemas_by_type[document_type]
        validator = Draft202012Validator(schema, registry=self.registry)
        normalized_frontmatter = _normalize_for_json_schema(frontmatter)
        issues = tuple(
            SchemaValidationIssue(
                rule_id=RULE_SCHEMA_INVALID,
                message=error.message,
                path=path,
                document_id=document_id,
                schema_path=_format_schema_path(error.absolute_path),
            )
            for error in sorted(validator.iter_errors(normalized_frontmatter), key=str)
        )

        return SchemaValidationResult(issues=issues)


def validate_frontmatter_schema(
    frontmatter: dict[str, Any],
    *,
    path: str | None = None,
    schemas_root: str | Path = ".ai-docs/schemas",
) -> SchemaValidationResult:
    return SchemaValidator.load(schemas_root).validate_frontmatter(
        frontmatter,
        path=path,
    )


def _load_schema_documents(root: Path) -> list[tuple[str, dict[str, Any]]]:
    schema_documents: list[tuple[str, dict[str, Any]]] = []
    for schema_path in sorted(root.rglob("*.schema.yaml")):
        schema = _load_yaml_mapping(schema_path)
        schema_id = schema.get("$id")
        if not isinstance(schema_id, str):
            continue

        schema_documents.append((schema_id, schema))
        schema_documents.extend(_relative_schema_uris(schema_path, schema_id, root, schema))

    return schema_documents


def _relative_schema_uris(
    schema_path: Path,
    schema_id: str,
    root: Path,
    schema: dict[str, Any],
) -> list[tuple[str, dict[str, Any]]]:
    relative_path = schema_path.relative_to(root).as_posix()
    uris = {
        relative_path,
        f"/{relative_path}",
        urljoin(schema_id, relative_path),
    }

    if relative_path.startswith("document-types/"):
        common_relative = "../frontmatter.schema.yaml"
        uris.add(urljoin(schema_id, common_relative))

    return [(uri, schema) for uri in sorted(uris)]


def _load_yaml_mapping(path: Path) -> dict[str, Any]:
    loaded = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(loaded, dict):
        raise ValueError(f"Schema must parse to a mapping object: {path}")
    return loaded


def _extract_const_type(schema: dict[str, Any]) -> str | None:
    properties = schema.get("properties", {})
    if isinstance(properties, dict):
        type_property = properties.get("type", {})
        if isinstance(type_property, dict):
            const_value = type_property.get("const")
            if isinstance(const_value, str):
                return const_value

    for item in schema.get("allOf", []):
        if not isinstance(item, dict):
            continue
        properties = item.get("properties", {})
        if not isinstance(properties, dict):
            continue
        type_property = properties.get("type", {})
        if isinstance(type_property, dict):
            const_value = type_property.get("const")
            if isinstance(const_value, str):
                return const_value
    return None


def _resolve_child(root: Path, child: str | Path) -> Path:
    child_path = Path(child)
    return child_path.resolve() if child_path.is_absolute() else (root / child_path).resolve()


def _string_value(value: Any) -> str | None:
    return value if isinstance(value, str) and value else None


def _format_schema_path(path: Any) -> str:
    parts = [str(part) for part in path]
    return ".".join(parts) if parts else "<root>"


def _normalize_for_json_schema(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: _normalize_for_json_schema(item) for key, item in value.items()}

    if isinstance(value, list):
        return [_normalize_for_json_schema(item) for item in value]

    if isinstance(value, datetime):
        return value.isoformat()

    if isinstance(value, date):
        return value.isoformat()

    return value
