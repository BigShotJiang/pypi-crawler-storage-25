from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml


@dataclass(frozen=True)
class FrontMatterError:
    code: str
    message: str
    path: str | None = None
    line: int | None = None
    column: int | None = None


@dataclass(frozen=True)
class ParsedMarkdownDocument:
    frontmatter: dict[str, Any]
    body: str
    raw_frontmatter: str
    path: str | None = None


@dataclass(frozen=True)
class FrontMatterParseResult:
    document: ParsedMarkdownDocument | None
    errors: tuple[FrontMatterError, ...] = ()

    @property
    def ok(self) -> bool:
        return self.document is not None and not self.errors


def parse_markdown_file(path: str | Path) -> FrontMatterParseResult:
    file_path = Path(path)
    return parse_markdown_text(
        file_path.read_text(encoding="utf-8"),
        path=str(file_path),
    )


def parse_markdown_text(text: str, *, path: str | None = None) -> FrontMatterParseResult:
    lines = text.splitlines(keepends=True)

    if not lines or not _is_frontmatter_delimiter(lines[0]):
        return _error(
            "missing_frontmatter",
            "Markdown document must start with YAML front matter delimiter `---`.",
            path=path,
            line=1,
            column=1,
        )

    closing_index = _find_closing_delimiter(lines)
    if closing_index is None:
        return _error(
            "missing_frontmatter_closing_delimiter",
            "YAML front matter must end with delimiter `---`.",
            path=path,
            line=len(lines),
            column=1,
        )

    raw_frontmatter = "".join(lines[1:closing_index])
    body = "".join(lines[closing_index + 1 :])

    try:
        loaded = yaml.safe_load(raw_frontmatter) if raw_frontmatter.strip() else {}
    except yaml.YAMLError as exc:
        return _yaml_error(exc, path=path)

    if loaded is None:
        frontmatter: dict[str, Any] = {}
    elif isinstance(loaded, dict):
        frontmatter = loaded
    else:
        return _error(
            "invalid_frontmatter_type",
            "YAML front matter must parse to a mapping object.",
            path=path,
            line=2,
            column=1,
        )

    return FrontMatterParseResult(
        document=ParsedMarkdownDocument(
            frontmatter=frontmatter,
            body=body,
            raw_frontmatter=raw_frontmatter,
            path=path,
        )
    )


def _find_closing_delimiter(lines: list[str]) -> int | None:
    for index, line in enumerate(lines[1:], start=1):
        if _is_frontmatter_delimiter(line):
            return index
    return None


def _is_frontmatter_delimiter(line: str) -> bool:
    return line.strip() == "---"


def _error(
    code: str,
    message: str,
    *,
    path: str | None,
    line: int | None = None,
    column: int | None = None,
) -> FrontMatterParseResult:
    return FrontMatterParseResult(
        document=None,
        errors=(FrontMatterError(code, message, path=path, line=line, column=column),),
    )


def _yaml_error(exc: yaml.YAMLError, *, path: str | None) -> FrontMatterParseResult:
    line: int | None = None
    column: int | None = None

    mark = getattr(exc, "problem_mark", None)
    if mark is not None:
        line = mark.line + 2
        column = mark.column + 1

    message = getattr(exc, "problem", None) or str(exc)
    return _error(
        "invalid_yaml",
        f"Invalid YAML front matter: {message}",
        path=path,
        line=line,
        column=column,
    )
