from __future__ import annotations

from collections import deque
from dataclasses import dataclass

from ai_docs_toolkit.core.graph import DocumentGraph, DocumentGraphEdge, DocumentGraphNode

RULE_DOCUMENT_IMPACT_UNKNOWN_ID = "document.impact.unknown_id"

IMPACT_TRANSITIONS: dict[str, frozenset[str]] = {
    "business_rule": frozenset(
        {
            "architecture_decision",
            "contract",
            "module",
            "scenario",
            "acceptance",
            "operation",
        }
    ),
    "architecture_decision": frozenset(
        {"contract", "module", "scenario", "acceptance", "operation"}
    ),
    "contract": frozenset({"module", "scenario", "acceptance", "operation"}),
    "module": frozenset({"contract", "scenario", "acceptance", "operation"}),
    "scenario": frozenset({"acceptance", "operation"}),
    "acceptance": frozenset({"operation"}),
    "operation": frozenset(),
    "index": frozenset(),
    "test_case": frozenset(),
}


@dataclass(frozen=True)
class ImpactSource:
    document_id: str
    type: str | None
    path: str
    source: str = "id"
    changed_file: str | None = None


@dataclass(frozen=True)
class ImpactReason:
    source: str
    via: str | None
    relationship: str
    direction: str
    message: str


@dataclass(frozen=True)
class ImpactedDocument:
    document_id: str
    type: str | None
    path: str
    title: str | None
    summary: str | None
    impact: str
    distance: int
    reasons: tuple[ImpactReason, ...]


@dataclass(frozen=True)
class ImpactAnalysisIssue:
    rule_id: str
    message: str
    document_id: str | None = None
    severity: str = "error"


@dataclass(frozen=True)
class ImpactAnalysisResult:
    sources: tuple[ImpactSource, ...]
    impacted: tuple[ImpactedDocument, ...]
    issues: tuple[ImpactAnalysisIssue, ...] = ()

    @property
    def ok(self) -> bool:
        return not any(issue.severity == "error" for issue in self.issues)


@dataclass(frozen=True)
class _TraversalStep:
    origin: str
    current: str
    distance: int


@dataclass(frozen=True)
class _Neighbor:
    node: DocumentGraphNode
    edge: DocumentGraphEdge
    direction: str


def analyze_document_impact(
    graph: DocumentGraph,
    source_ids: tuple[str, ...] | list[str],
) -> ImpactAnalysisResult:
    unique_source_ids = tuple(dict.fromkeys(source_ids))
    known_sources = tuple(
        sorted(
            (
                ImpactSource(
                    document_id=document_id,
                    type=node.type,
                    path=node.path,
                )
                for document_id in unique_source_ids
                if (node := graph.get_node(document_id)) is not None
            ),
            key=lambda source: (source.document_id, source.path),
        )
    )
    issues = tuple(
        ImpactAnalysisIssue(
            rule_id=RULE_DOCUMENT_IMPACT_UNKNOWN_ID,
            message=f"Impact source references unknown document id `{document_id}`.",
            document_id=document_id,
        )
        for document_id in sorted(
            document_id
            for document_id in unique_source_ids
            if graph.get_node(document_id) is None
        )
    )

    impacted = _find_impacted_documents(
        graph,
        tuple(source.document_id for source in known_sources),
    )
    return ImpactAnalysisResult(
        sources=known_sources,
        impacted=impacted,
        issues=issues,
    )


def _find_impacted_documents(
    graph: DocumentGraph,
    source_ids: tuple[str, ...],
) -> tuple[ImpactedDocument, ...]:
    source_id_set = set(source_ids)
    best_distances: dict[str, int] = {}
    reasons_by_document: dict[str, list[ImpactReason]] = {}
    visited_by_origin: dict[tuple[str, str], int] = {}
    queue: deque[_TraversalStep] = deque(
        _TraversalStep(origin=document_id, current=document_id, distance=0)
        for document_id in source_ids
    )

    while queue:
        step = queue.popleft()
        current_node = graph.get_node(step.current)
        if current_node is None:
            continue

        for neighbor in _accepted_neighbors(graph, current_node):
            next_distance = step.distance + 1
            candidate_id = neighbor.node.id
            if candidate_id == step.origin:
                continue

            visit_key = (step.origin, candidate_id)
            previous_visit_distance = visited_by_origin.get(visit_key)
            if previous_visit_distance is not None and previous_visit_distance <= next_distance:
                continue
            visited_by_origin[visit_key] = next_distance

            reason = _impact_reason(
                origin=step.origin,
                via=None if step.current == step.origin else step.current,
                neighbor=neighbor,
            )
            previous_best_distance = best_distances.get(candidate_id)
            if previous_best_distance is None or next_distance < previous_best_distance:
                best_distances[candidate_id] = next_distance
                reasons_by_document[candidate_id] = [reason]
                queue.append(
                    _TraversalStep(
                        origin=step.origin,
                        current=candidate_id,
                        distance=next_distance,
                    )
                )
                continue

            if next_distance == previous_best_distance:
                reasons_by_document[candidate_id].append(reason)

            if candidate_id in source_id_set:
                continue

    impacted_documents = []
    for document_id, distance in best_distances.items():
        node = graph.get_node(document_id)
        if node is None:
            continue

        impacted_documents.append(
            ImpactedDocument(
                document_id=node.id,
                type=node.type,
                path=node.path,
                title=node.title,
                summary=node.summary,
                impact="direct" if distance == 1 else "transitive",
                distance=distance,
                reasons=tuple(sorted(reasons_by_document[document_id], key=_reason_sort_key)),
            )
        )

    return tuple(sorted(impacted_documents, key=_impacted_sort_key))


def _accepted_neighbors(
    graph: DocumentGraph,
    node: DocumentGraphNode,
) -> tuple[_Neighbor, ...]:
    allowed_types = IMPACT_TRANSITIONS.get(node.type or "", frozenset())
    if not allowed_types:
        return ()

    neighbors: list[_Neighbor] = []
    for edge in graph.edges:
        if edge.source == node.id:
            target = graph.get_node(edge.target)
            if target is not None and target.type in allowed_types:
                neighbors.append(_Neighbor(node=target, edge=edge, direction="outgoing"))

        if edge.target == node.id:
            source = graph.get_node(edge.source)
            if source is not None and source.type in allowed_types:
                neighbors.append(_Neighbor(node=source, edge=edge, direction="incoming"))

    return tuple(sorted(neighbors, key=_neighbor_sort_key))


def _impact_reason(
    *,
    origin: str,
    via: str | None,
    neighbor: _Neighbor,
) -> ImpactReason:
    edge = neighbor.edge
    return ImpactReason(
        source=origin,
        via=via,
        relationship=edge.relationship,
        direction=neighbor.direction,
        message=(
            f"{edge.source} references {edge.target} "
            f"through related.{edge.relationship}."
        ),
    )


def _neighbor_sort_key(neighbor: _Neighbor) -> tuple[str, str, str]:
    return (neighbor.node.id, neighbor.edge.relationship, neighbor.direction)


def _reason_sort_key(reason: ImpactReason) -> tuple[str, str, str, str]:
    return (
        reason.source,
        reason.via or "",
        reason.relationship,
        reason.direction,
    )


def _impacted_sort_key(document: ImpactedDocument) -> tuple[int, str, str]:
    return (document.distance, document.document_id, document.path)
