# AI Docs Toolkit Agent Instructions

## Purpose

This document is packaged with `ai-docs-toolkit` so an AI agent can install, update and use the toolkit without access to the source repository.

Use it when an operator asks an agent to bootstrap or validate a repository with AI Docs Toolkit.

## Agent Prompt

Give this prompt to an AI agent that can run shell commands in a repository:

```text
Install or update AI Docs Toolkit for this repository, then use it as the documentation validation and context tool.

Required behavior:
- Prefer an isolated or project-local Python environment.
- Install the package with `python -m pip install --upgrade ai-docs-toolkit`.
- If the project requires a pinned version, use the pinned `ai-docs-toolkit==...` version instead of the unpinned upgrade command.
- Verify the CLI with `ai-docs --version`.
- If the repository is not configured for AI Docs Toolkit yet, run `ai-docs init` before validation.
- Read `AGENTS.md` after bootstrap when it exists.
- Before changing non-trivial behavior, load relevant context with `ai-docs context` by id, module, feature or changed files.
- Validate before closure with `ai-docs validate`; use `ai-docs validate --json` for automation.
- Preserve existing user changes. `ai-docs init` may refresh toolkit-managed planning skill/workflow/reference files; use `--force` only when explicitly asked to overwrite the remaining toolkit-owned bootstrap files.
- If the CLI cannot be installed or run, report the exact limitation and perform applicable manual documentation checks.
```

## Install

Use Python 3.11 or newer.

Recommended project-local install:

```bash
python -m pip install --upgrade ai-docs-toolkit
ai-docs --version
```

Pinned install:

```bash
python -m pip install "ai-docs-toolkit==0.1.0b8"
ai-docs --version
```

Optional MCP runtime:

```bash
python -m pip install --upgrade "ai-docs-toolkit[mcp]"
ai-docs-mcp --project-root .
```

## JetBrains MCP Setup

Use this section when JetBrains AI Assistant should launch AI Docs Toolkit as a local MCP server for the current repository.
This configures JetBrains as the MCP client and `ai-docs-mcp` as an external local MCP server.
It is different from the JetBrains built-in IDE MCP server used by external clients.

Package installation does not modify JetBrains settings.
Run the helper commands below, then add the generated JSON in JetBrains under `Settings | Tools | AI Assistant | Model Context Protocol (MCP)`.

Install or update the MCP runtime extra in the same environment that contains the project tooling:

```bash
python -m pip install --upgrade "ai-docs-toolkit[mcp]"
```

Check setup readiness:

```bash
ai-docs mcp status --project-root .
```

Generate JetBrains MCP JSON:

```bash
ai-docs mcp configure --client jetbrains --print-json --project-root .
```

The generated JSON has this shape:

```json
{
  "mcpServers": {
    "ai-docs-toolkit": {
      "command": "/absolute/path/to/ai-docs-mcp",
      "args": [
        "--project-root",
        "/absolute/path/to/project",
        "--config",
        "ai-docs.config.yaml"
      ]
    }
  }
}
```

On Windows, use the generated JSON from the helper.
If writing the config manually, the command usually points to the virtualenv script:

```json
{
  "mcpServers": {
    "ai-docs-toolkit": {
      "command": "C:\\path\\to\\project\\.venv\\Scripts\\ai-docs-mcp.exe",
      "args": [
        "--project-root",
        "C:\\path\\to\\project",
        "--config",
        "ai-docs.config.yaml"
      ]
    }
  }
}
```

Use absolute paths because an IDE-launched server process may not inherit the shell `PATH` or an activated virtualenv.

### Agent-Assisted JetBrains Setup

If an operator asks an AI agent to configure JetBrains MCP for a repository, the agent should:

1. Identify the project root and active Python environment.
2. Run `ai-docs mcp status --project-root <project-root>`.
3. If the MCP runtime is missing, ask for permission to install or run:

   ```bash
   python -m pip install --upgrade "ai-docs-toolkit[mcp]"
   ```

4. Run:

   ```bash
   ai-docs mcp configure --client jetbrains --print-json --project-root <project-root>
   ```

5. Give the generated JSON to the operator for JetBrains MCP settings.
6. Do not silently edit JetBrains IDE configuration files unless the operator explicitly asks for that and the exact config target is known.

Troubleshooting:
- If `ai-docs-mcp --help` works but server startup fails with `No module named 'mcp'`, install `ai-docs-toolkit[mcp]` in the same environment.
- If JetBrains cannot launch the server, regenerate JSON with absolute paths from the same environment the project uses.
- If `ai-docs.config.yaml` is missing, run `ai-docs init` before configuring MCP.

Ephemeral execution with `uvx`:

```bash
uvx --from ai-docs-toolkit ai-docs --version
uvx --from ai-docs-toolkit ai-docs validate
```

## Update

Update the package in the active Python environment:

```bash
python -m pip install --upgrade ai-docs-toolkit
ai-docs --version
```

If the repository pins a toolkit version, do not change the pin silently. Report that an update requires a version policy decision.

## Bootstrap A Repository

Package installation does not modify the repository.

Default agent-oriented bootstrap:

```bash
ai-docs init
```

Minimal bootstrap without `AGENTS.md`:

```bash
ai-docs init --profile minimal
```

The init command skips most existing files by default.
During the planning workflow migration, it may refresh toolkit-managed planning files under `.ai-docs/skills/`, `.ai-docs/workflows/plan-stage-workflow.md` and `.ai-docs/reference/planning-document-model.md`.
Use `--force` only when the operator explicitly wants to overwrite the remaining toolkit-owned target files.

## Use

Validate:

```bash
ai-docs validate
ai-docs validate --json
```

Build a document graph:

```bash
ai-docs graph --format json
```

Analyze changed files:

```bash
ai-docs impact --changed
```

Prepare context for an agent:

```bash
ai-docs context --changed
ai-docs context --id <document-id>
ai-docs context --module <module>
ai-docs context --feature <feature>
```

## Manual Fallback

If installation is unavailable, the agent should still read project documentation directly:

- `AGENTS.md`
- `ai-docs.config.yaml`
- documentation roots configured in `ai-docs.config.yaml`
- planning records under `ai-docs/planning/**`
- source documents linked from the task or request

Manual checks should verify that Markdown documents have YAML front matter, required ids and types are present, relationships point to existing documents where possible and acceptance criteria match the changed behavior.

The agent must report that automated `ai-docs` validation was not run.
