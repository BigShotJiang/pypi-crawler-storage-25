from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from ai_docs_toolkit import __version__
from ai_docs_toolkit.context import context_project, format_context_json
from ai_docs_toolkit.core.config import DEFAULT_CONFIG_FILE, load_project_config
from ai_docs_toolkit.core.frontmatter import parse_markdown_file
from ai_docs_toolkit.graph import GraphFilters, format_graph_json, graph_project
from ai_docs_toolkit.impact import (
    format_impact_json,
    impact_changed_project,
    impact_project,
)
from ai_docs_toolkit.validation import format_json_validation_result, validate_project_human


SERVER_NAME = "AI Docs Toolkit"


@dataclass(frozen=True)
class McpRuntimeArgs:
    project_root: Path
    config_file: str


def parse_args(argv: list[str] | None = None) -> McpRuntimeArgs:
    parser = argparse.ArgumentParser(
        prog="ai-docs-mcp",
        description="Run the AI Docs Toolkit MCP server.",
    )
    parser.add_argument(
        "--project-root",
        default=".",
        help="Project root to serve. Defaults to the current working directory.",
    )
    parser.add_argument(
        "--config",
        default=DEFAULT_CONFIG_FILE,
        help=f"Project config file relative to the project root. Defaults to {DEFAULT_CONFIG_FILE}.",
    )
    parsed = parser.parse_args(argv)
    return McpRuntimeArgs(
        project_root=Path(parsed.project_root),
        config_file=parsed.config,
    )


def server_info(project_root: str | Path = ".", config_file: str = DEFAULT_CONFIG_FILE) -> dict[str, Any]:
    config_result = load_project_config(project_root, config_file=config_file)
    resolved_root = Path(project_root).resolve()
    if not config_result.ok or config_result.config is None:
        return {
            "ok": False,
            "server": SERVER_NAME,
            "version": __version__,
            "project_root": str(resolved_root),
            "config_file": config_file,
            "errors": [
                {
                    "code": error.code,
                    "message": error.message,
                    "path": error.path,
                }
                for error in config_result.errors
            ],
        }

    config = config_result.config
    return {
        "ok": True,
        "server": SERVER_NAME,
        "version": __version__,
        "project_root": str(config.project_root),
        "config_path": str(config.config_path) if config.config_path else None,
        "project_name": config.project_name,
        "documentation_roots": [str(path) for path in config.documentation_roots],
        "schema_roots": [str(path) for path in config.schema_roots],
    }


def validate_project_tool(project_root: str | Path = ".") -> dict[str, Any]:
    result = validate_project_human(project_root)
    payload = json.loads(format_json_validation_result(result))
    payload["exit_code"] = result.exit_code
    return payload


def graph_project_tool(
    project_root: str | Path = ".",
    *,
    document_type: str | None = None,
    module: str | None = None,
    document_id: str | None = None,
) -> dict[str, Any]:
    result = graph_project(
        project_root,
        filters=GraphFilters(
            document_type=document_type,
            module=module,
            document_id=document_id,
        ),
    )
    payload = json.loads(format_graph_json(result))
    payload["exit_code"] = result.exit_code
    return payload


def impact_project_tool(
    project_root: str | Path = ".",
    *,
    source_ids: list[str] | tuple[str, ...] | None = None,
    changed: bool = False,
) -> dict[str, Any]:
    result = (
        impact_changed_project(project_root)
        if changed
        else impact_project(tuple(source_ids or ()), project_root)
    )
    payload = json.loads(format_impact_json(result))
    payload["exit_code"] = result.exit_code
    return payload


def context_project_tool(
    project_root: str | Path = ".",
    *,
    mode: str,
    value: str = "",
) -> dict[str, Any]:
    result = context_project(mode=mode, value=value, project_root=project_root)
    payload = json.loads(format_context_json(result))
    payload["exit_code"] = result.exit_code
    return payload


def planning_record_resource(project_root: str | Path, document_id: str) -> dict[str, Any]:
    record = _find_planning_record(project_root, document_id)
    if record is None:
        return {"ok": False, "document_id": document_id, "error": "not_found"}
    return {"ok": True, **record}


def planning_plans_resource(project_root: str | Path = ".") -> dict[str, Any]:
    records = [
        _record_summary(record)
        for record in _iter_planning_records(project_root)
        if record["type"] == "plan"
    ]
    return {"ok": True, "plans": records}


def planning_next_task_resource(project_root: str | Path = ".") -> dict[str, Any]:
    active_statuses = {"in_progress", "ready", "readiness_review", "planned"}
    tasks = [
        record
        for record in _iter_planning_records(project_root)
        if record["type"] in {"implementation_task", "standalone_task"}
        and record["status"] in active_statuses
    ]
    if not tasks:
        return {"ok": True, "task": None}
    tasks.sort(key=lambda record: (record["status"] != "in_progress", record["path"]))
    return {"ok": True, "task": _record_summary(tasks[0])}


def build_server(
    *,
    project_root: str | Path = ".",
    config_file: str = DEFAULT_CONFIG_FILE,
    fastmcp_factory: Callable[[str], Any] | None = None,
) -> Any:
    fastmcp = fastmcp_factory or _load_fastmcp()
    server = fastmcp(SERVER_NAME)
    default_project_root = project_root

    @server.tool(name="ai_docs_server_info")
    def ai_docs_server_info() -> dict[str, Any]:
        return server_info(project_root=project_root, config_file=config_file)

    @server.tool(name="ai_docs_validate")
    def ai_docs_validate(project_root: str | None = None) -> dict[str, Any]:
        validation_root = project_root if project_root is not None else default_project_root
        return validate_project_tool(project_root=validation_root)

    @server.tool(name="ai_docs_graph")
    def ai_docs_graph(
        project_root: str | None = None,
        document_type: str | None = None,
        module: str | None = None,
        document_id: str | None = None,
    ) -> dict[str, Any]:
        graph_root = project_root if project_root is not None else default_project_root
        return graph_project_tool(
            project_root=graph_root,
            document_type=document_type,
            module=module,
            document_id=document_id,
        )

    @server.tool(name="ai_docs_impact")
    def ai_docs_impact(
        project_root: str | None = None,
        source_ids: list[str] | None = None,
        changed: bool = False,
    ) -> dict[str, Any]:
        impact_root = project_root if project_root is not None else default_project_root
        return impact_project_tool(
            project_root=impact_root,
            source_ids=source_ids,
            changed=changed,
        )

    @server.tool(name="ai_docs_context")
    def ai_docs_context(
        mode: str,
        value: str = "",
        project_root: str | None = None,
    ) -> dict[str, Any]:
        context_root = project_root if project_root is not None else default_project_root
        return context_project_tool(project_root=context_root, mode=mode, value=value)

    @server.resource("ai-docs://config")
    def ai_docs_config() -> dict[str, Any]:
        return server_info(project_root=project_root, config_file=config_file)

    @server.resource("ai-docs://graph")
    def ai_docs_graph_resource() -> dict[str, Any]:
        return graph_project_tool(project_root=project_root)

    @server.resource("ai-docs://plans")
    def ai_docs_plans_resource() -> dict[str, Any]:
        return planning_plans_resource(project_root=project_root)

    @server.resource("ai-docs://plan/{plan_id}")
    def ai_docs_plan_resource(plan_id: str) -> dict[str, Any]:
        return planning_record_resource(project_root, plan_id)

    @server.resource("ai-docs://stage/{stage_id}")
    def ai_docs_stage_resource(stage_id: str) -> dict[str, Any]:
        return planning_record_resource(project_root, stage_id)

    @server.resource("ai-docs://task/{task_id}")
    def ai_docs_task_resource(task_id: str) -> dict[str, Any]:
        return planning_record_resource(project_root, task_id)

    @server.resource("ai-docs://next-task")
    def ai_docs_next_task_resource() -> dict[str, Any]:
        return planning_next_task_resource(project_root=project_root)

    @server.resource("ai-docs://validation/latest")
    def ai_docs_validation_latest_resource() -> dict[str, Any]:
        return validate_project_tool(project_root=project_root)

    return server


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    server = build_server(project_root=args.project_root, config_file=args.config_file)
    server.run()
    return 0


def _load_fastmcp() -> Callable[[str], Any]:
    try:
        from mcp.server.fastmcp import FastMCP
    except ImportError as exc:
        raise SystemExit(
            "The MCP runtime extra is not installed. "
            'Install it with `python -m pip install "ai-docs-toolkit[mcp]"` '
            'or `python -m pip install -e ".[mcp]"` from a source checkout.'
        ) from exc

    return FastMCP


def _iter_planning_records(project_root: str | Path) -> list[dict[str, Any]]:
    root = Path(project_root).resolve()
    planning_root = root / "ai-docs" / "planning"
    if not planning_root.exists():
        return []
    records: list[dict[str, Any]] = []
    for path in sorted(planning_root.rglob("*.md")):
        parsed = parse_markdown_file(path)
        if parsed.document is None:
            continue
        frontmatter = parsed.document.frontmatter
        document_type = frontmatter.get("type")
        if document_type not in {"plan", "plan_stage", "implementation_task", "standalone_task"}:
            continue
        records.append(
            {
                "id": frontmatter.get("id"),
                "type": document_type,
                "status": frontmatter.get("status"),
                "path": path.resolve().relative_to(root).as_posix(),
                "frontmatter": frontmatter,
                "body": parsed.document.body,
            }
        )
    return records


def _find_planning_record(project_root: str | Path, document_id: str) -> dict[str, Any] | None:
    for record in _iter_planning_records(project_root):
        if record["id"] == document_id:
            return record
    return None


def _record_summary(record: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": record["id"],
        "type": record["type"],
        "status": record["status"],
        "path": record["path"],
    }
