from __future__ import annotations

import importlib.util
import json
import shutil
import sys
from pathlib import Path
from typing import Any

from ai_docs_toolkit.core.config import DEFAULT_CONFIG_FILE


def mcp_setup_status(
    project_root: str | Path = ".",
    config_file: str = DEFAULT_CONFIG_FILE,
    command: str | None = None,
) -> dict[str, Any]:
    resolved_root = Path(project_root).resolve()
    resolved_command = _resolve_mcp_command(command)
    config_path = resolved_root / config_file
    runtime_available = importlib.util.find_spec("mcp") is not None

    issues: list[dict[str, str]] = []
    if not runtime_available:
        issues.append(
            {
                "code": "missing_mcp_runtime",
                "message": 'Install the MCP runtime with `python -m pip install --upgrade "ai-docs-toolkit[mcp]"`.',
            }
        )
    if not config_path.exists():
        issues.append(
            {
                "code": "missing_config",
                "message": f"Project config was not found at {config_path}.",
            }
        )

    return {
        "ok": not issues,
        "project_root": str(resolved_root),
        "config_file": config_file,
        "config_path": str(config_path),
        "mcp_runtime_available": runtime_available,
        "command": resolved_command["command"],
        "command_args_prefix": resolved_command["args_prefix"],
        "issues": issues,
    }


def jetbrains_mcp_config(
    project_root: str | Path = ".",
    config_file: str = DEFAULT_CONFIG_FILE,
    command: str | None = None,
) -> dict[str, Any]:
    resolved_root = Path(project_root).resolve()
    resolved_command = _resolve_mcp_command(command)
    args = [
        *resolved_command["args_prefix"],
        "--project-root",
        str(resolved_root),
        "--config",
        config_file,
    ]
    return {
        "mcpServers": {
            "ai-docs-toolkit": {
                "command": resolved_command["command"],
                "args": args,
            }
        }
    }


def format_mcp_status_human(status: dict[str, Any]) -> str:
    lines = [
        "ai-docs mcp status",
        f"ok: {str(status['ok']).lower()}",
        f"project_root: {status['project_root']}",
        f"config_file: {status['config_file']}",
        f"mcp_runtime_available: {str(status['mcp_runtime_available']).lower()}",
        f"command: {status['command']}",
    ]
    if status["command_args_prefix"]:
        lines.append("command_args_prefix:")
        lines.extend(f"- {arg}" for arg in status["command_args_prefix"])
    if status["issues"]:
        lines.append("issues:")
        lines.extend(f"- {issue['code']}: {issue['message']}" for issue in status["issues"])
    else:
        lines.append("issues: none")
    return "\n".join(lines)


def format_jetbrains_mcp_config_json(config: dict[str, Any]) -> str:
    return json.dumps(config, indent=2)


def _resolve_mcp_command(command: str | None) -> dict[str, Any]:
    if command:
        return {"command": str(Path(command).expanduser()), "args_prefix": []}

    discovered = shutil.which("ai-docs-mcp")
    if discovered:
        return {"command": str(Path(discovered).resolve()), "args_prefix": []}

    return {"command": sys.executable, "args_prefix": ["-m", "ai_docs_toolkit.mcp"]}
