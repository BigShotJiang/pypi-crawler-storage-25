from ai_docs_toolkit.mcp.server import main


if __name__ == "__main__":
    raise SystemExit(main())
