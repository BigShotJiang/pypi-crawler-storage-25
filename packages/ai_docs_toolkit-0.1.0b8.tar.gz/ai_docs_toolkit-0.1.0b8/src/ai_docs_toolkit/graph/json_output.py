from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path

from ai_docs_toolkit.core import (
    DocumentGraph,
    DocumentGraphEdge,
    DocumentGraphNode,
    RegistryDocument,
    build_document_graph,
    build_document_registry,
    load_project_config,
    parse_markdown_file,
    registry_document_from_parsed,
    scan_markdown_files,
)
from ai_docs_toolkit.validation import ValidationMessage

RULE_DOCUMENT_GRAPH_ORPHAN = "document.graph.orphan"

_ORPHAN_WARNING_TYPES = {
    "acceptance",
    "architecture_decision",
    "business_rule",
    "contract",
    "module",
    "operation",
    "scenario",
}


@dataclass(frozen=True)
class GraphBuildResult:
    exit_code: int
    graph: DocumentGraph | None
    warnings: tuple[ValidationMessage, ...] = ()
    errors: tuple[ValidationMessage, ...] = ()

    @property
    def ok(self) -> bool:
        return self.exit_code == 0


@dataclass(frozen=True)
class GraphFilters:
    document_type: str | None = None
    module: str | None = None
    document_id: str | None = None


def graph_project(
    project_root: str | Path = ".",
    *,
    filters: GraphFilters | None = None,
) -> GraphBuildResult:
    root = Path(project_root).resolve()
    config_result = load_project_config(root)
    if not config_result.ok or config_result.config is None:
        return GraphBuildResult(
            exit_code=2,
            graph=None,
            errors=tuple(
                ValidationMessage(
                    rule_id=error.code,
                    message=error.message,
                    path=error.path,
                )
                for error in config_result.errors
            ),
        )

    documents: list[RegistryDocument] = []
    errors: list[ValidationMessage] = []
    for path in scan_markdown_files(config_result.config):
        parse_result = parse_markdown_file(path)
        if parse_result.document is None:
            errors.extend(
                ValidationMessage(
                    rule_id=f"frontmatter.{error.code}",
                    message=error.message,
                    path=error.path,
                )
                for error in parse_result.errors
            )
            continue

        documents.append(registry_document_from_parsed(parse_result.document))

    registry = build_document_registry(tuple(documents))
    errors.extend(
        ValidationMessage(
            rule_id=issue.rule_id,
            message=issue.message,
            path=", ".join(str(path) for path in issue.paths),
            document_id=issue.document_id,
            severity=issue.severity,
        )
        for issue in registry.issues
    )

    active_filters = filters or GraphFilters()
    full_graph = build_document_graph(registry, project_root=root)
    graph = _filter_graph(full_graph, active_filters)
    id_errors = _id_filter_errors(graph, active_filters)
    return GraphBuildResult(
        exit_code=0 if not errors and not id_errors else 1,
        graph=graph,
        warnings=_filter_warnings(_orphan_warnings(full_graph), graph),
        errors=tuple([*errors, *id_errors]),
    )


def format_graph_json(result: GraphBuildResult) -> str:
    graph = result.graph
    payload = {
        "nodes": [asdict(node) for node in graph.nodes] if graph is not None else [],
        "edges": [asdict(edge) for edge in graph.edges] if graph is not None else [],
        "warnings": [_message_payload(message) for message in result.warnings],
    }
    if result.errors:
        payload["errors"] = [_message_payload(message) for message in result.errors]
    return json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True)


def _message_payload(message: ValidationMessage) -> dict[str, str | None]:
    return {
        "path": message.path,
        "document_id": message.document_id,
        "rule_id": message.rule_id,
        "severity": message.severity,
        "message": message.message,
    }


def _filter_graph(graph: DocumentGraph, filters: GraphFilters) -> DocumentGraph:
    nodes = graph.nodes
    if filters.document_type is not None:
        nodes = tuple(node for node in nodes if node.type == filters.document_type)

    if filters.module is not None:
        nodes = tuple(
            node for node in nodes if filters.module in ((node.scope or {}).get("modules") or [])
        )

    if filters.document_id is not None:
        scoped_ids = {node.id for node in nodes}
        if filters.document_id not in scoped_ids:
            return DocumentGraph(nodes=(), edges=())

        neighbor_ids = {filters.document_id}
        for edge in graph.edges:
            if edge.source == filters.document_id and edge.target in scoped_ids:
                neighbor_ids.add(edge.target)
            if edge.target == filters.document_id and edge.source in scoped_ids:
                neighbor_ids.add(edge.source)

        nodes = tuple(node for node in nodes if node.id in neighbor_ids)

    node_ids = {node.id for node in nodes}
    edges = tuple(
        edge for edge in graph.edges if edge.source in node_ids and edge.target in node_ids
    )
    return DocumentGraph(
        nodes=tuple(sorted(nodes, key=_node_sort_key)),
        edges=tuple(sorted(edges, key=_edge_sort_key)),
    )


def _id_filter_errors(
    graph: DocumentGraph,
    filters: GraphFilters,
) -> tuple[ValidationMessage, ...]:
    if filters.document_id is None or graph.get_node(filters.document_id) is not None:
        return ()

    return (
        ValidationMessage(
            rule_id="document.graph.filter.unknown_id",
            message=f"Graph filter references unknown document id `{filters.document_id}`.",
            document_id=filters.document_id,
        ),
    )


def _orphan_warnings(graph: DocumentGraph) -> tuple[ValidationMessage, ...]:
    connected_document_ids = {
        document_id
        for edge in graph.edges
        for document_id in (edge.source, edge.target)
    }
    warnings: list[ValidationMessage] = []
    for node in graph.nodes:
        if node.id in connected_document_ids:
            continue
        if node.type not in _ORPHAN_WARNING_TYPES:
            continue

        warnings.append(
            ValidationMessage(
                rule_id=RULE_DOCUMENT_GRAPH_ORPHAN,
                message="Document has no resolved graph relationships.",
                path=node.path,
                document_id=node.id,
                severity="warning",
            )
        )

    return tuple(sorted(warnings, key=_message_sort_key))


def _filter_warnings(
    warnings: tuple[ValidationMessage, ...],
    graph: DocumentGraph,
) -> tuple[ValidationMessage, ...]:
    document_ids = {node.id for node in graph.nodes}
    return tuple(
        warning
        for warning in warnings
        if warning.document_id is None or warning.document_id in document_ids
    )


def _node_sort_key(node: DocumentGraphNode) -> tuple[str, str]:
    return (node.id, node.path)


def _edge_sort_key(edge: DocumentGraphEdge) -> tuple[str, str, str]:
    return (edge.source, edge.relationship, edge.target)


def _message_sort_key(message: ValidationMessage) -> tuple[str, str, str]:
    return (message.path or "", message.document_id or "", message.rule_id)
