"""Knowledge base DTOs for collections, documents, and search."""

from datetime import datetime, timezone
from typing import Any, Literal, Self, cast
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from alloy_runtime_types.dtos.structured_filter import ConditionSpec, LogicalSpec
from alloy_runtime_types.dtos.templates import TagResponse


def _empty_tag_responses() -> list[TagResponse]:
    return []


def _empty_uuid_list() -> list[UUID]:
    return []


# Processing status type aliases
# DB statuses (persisted to database)
ProcessingStatus = Literal[
    "queued",
    "processing",
    "completed",
    "failed",
    "duplicate",
    "filtered",
]

FilteredReason = Literal["micro_chunk_policy_zero", "deduplicated_to_zero"]

# Terminal statuses - indicates polling should stop
TERMINAL_PROCESSING_STATUSES: frozenset[ProcessingStatus] = frozenset(
    {"completed", "failed", "duplicate", "filtered"}
)


def is_terminal_status(status: ProcessingStatus) -> bool:
    """Check if a processing status is terminal (processing complete, stop polling)."""
    return status in TERMINAL_PROCESSING_STATUSES


ClusteringStatus = Literal["pending", "processing", "completed", "failed"]

TERMINAL_CLUSTERING_STATUSES: frozenset[ClusteringStatus] = frozenset(
    {"completed", "failed"}
)


def is_terminal_clustering_status(status: ClusteringStatus) -> bool:
    return status in TERMINAL_CLUSTERING_STATUSES


# API response statuses (includes transient statuses not persisted)
IngestResponseStatus = Literal[
    "queued",
    "processing",
    "completed",
    "failed",
    "filtered",
    "duplicate",
    "dry_run_complete",
    "rejected",
]
ReingestResponseStatus = Literal["queued", "dry_run_complete"]

# Source type type alias
SourceType = Literal["upload", "paste", "api_import", "url_scrape"]

# Section extraction strategy type alias
SectionStrategyType = Literal["heading_based", "paragraph_based", "fixed_size", "none"]

SemanticSplitterModelType = Literal[
    "voyage-4-nano", "voyage-4-lite", "voyage-3", "voyage-3-lite", "voyage-3.5-lite"
]

CollectionQuestionGenerationMode = Literal[
    "enabled", "skipped_by_design", "mixed", "empty"
]


# === Collections ===


class CollectionMicroChunkConfig(BaseModel):
    """Configuration for detecting and handling micro-chunks during ingestion.

    Micro-chunks are ultra-small chunks (e.g., standalone headers) that may not
    provide meaningful search context. This config controls detection thresholds
    and merge/suppress strategies.
    """

    model_config = ConfigDict(extra="forbid")

    enabled: bool = Field(
        default=True,
        description="Whether to apply micro-chunk detection during ingestion.",
    )
    min_tokens: int = Field(
        default=5,
        ge=1,
        description="Chunks at or below this token count are candidates for merge-or-suppress handling.",
    )
    min_characters: int = Field(
        default=40,
        ge=1,
        description="Chunks at or below this character count are candidates for micro-chunk handling.",
    )
    max_header_characters: int = Field(
        default=80,
        ge=1,
        description="Maximum character length for a header-like chunk before it stops being treated as a header candidate.",
    )
    merge_strategy: Literal["forward_then_backward", "metadata_only"] = Field(
        default="forward_then_backward",
        description="How to handle detected micro-chunks: merge into a neighbor when possible, or always preserve as metadata only.",
    )


class CollectionPreprocessingConfig(BaseModel):
    """Collection-level preprocessing settings applied during document ingestion.

    Controls content filtering and micro-chunk handling before chunking.
    """

    model_config = ConfigDict(extra="forbid")

    min_length: int = Field(
        default=50,
        ge=0,
        description="Minimum characters required after preprocessing. Set to 0 to disable length filtering.",
    )
    micro_chunk: CollectionMicroChunkConfig = Field(
        default_factory=CollectionMicroChunkConfig,
        description="Settings for detecting and suppressing ultra-small header-like chunks during ingestion.",
    )


class CollectionSemanticRoutingProfile(BaseModel):
    model_config = ConfigDict(extra="forbid")

    enable_content_vector_search: bool = Field(
        default=True,
        description="Whether semantic search should use the content-vector retrieval path.",
    )
    enable_question_embedding_search: bool = Field(
        default=True,
        description="Whether semantic search should use the question-embedding retrieval path.",
    )
    enable_bm25_search: bool = Field(
        default=True,
        description="Whether semantic search should use BM25 content matching.",
    )
    enable_phrase_fusion: bool = Field(
        default=True,
        description="Whether semantic search should run phrase-fusion probes when globally enabled.",
    )
    enable_metadata_field_retrieval: bool = Field(
        default=True,
        description="Whether semantic search should use the metadata-field retrieval path.",
    )

    @model_validator(mode="after")
    def validate_at_least_one_core_path_enabled(self) -> Self:
        if not (
            self.enable_content_vector_search
            or self.enable_question_embedding_search
            or self.enable_bm25_search
            or self.enable_metadata_field_retrieval
        ):
            raise ValueError(
                "semantic_routing_profile must enable at least one core semantic retrieval path"
            )
        return self


class CollectionSemanticRoutingProfilePatch(BaseModel):
    model_config = ConfigDict(extra="forbid")

    enable_content_vector_search: bool | None = Field(default=None)
    enable_question_embedding_search: bool | None = Field(default=None)
    enable_bm25_search: bool | None = Field(default=None)
    enable_phrase_fusion: bool | None = Field(default=None)
    enable_metadata_field_retrieval: bool | None = Field(default=None)


class CreateCollectionRequest(BaseModel):
    """Request to create a document collection.

    chunk_size_tokens, chunk_overlap_tokens, section_strategy, and dedup_similarity_threshold
    are immutable after creation (changing them would require re-processing all documents).
    """

    name: str = Field(..., min_length=1, max_length=255, description="Collection name")
    description: str | None = Field(None, description="Optional description")
    chunk_size_tokens: int = Field(
        default=512, ge=64, le=8192, description="Target tokens per chunk"
    )
    chunk_overlap_tokens: int = Field(
        default=50, ge=0, description="Token overlap between chunks"
    )
    section_strategy: SectionStrategyType = Field(
        default="paragraph_based",
        description="Section extraction strategy: heading_based (markdown headings), paragraph_based (double newlines), fixed_size (fixed tokens), none (no sections)",
    )
    dedup_similarity_threshold: float | None = Field(
        default=0.95,
        ge=0.50,
        le=1.00,
        description="Cosine similarity threshold for chunk deduplication. Chunks with similarity >= threshold are skipped. NULL disables deduplication.",
    )
    rerank_instruction: str | None = Field(
        None,
        max_length=500,
        description="Default instruction for Voyage AI reranking (e.g., 'Prioritize implementation details over introductions')",
    )
    preprocessing_config: CollectionPreprocessingConfig = Field(
        default_factory=CollectionPreprocessingConfig,
        description="Collection-level preprocessing settings applied during ingestion.",
    )
    semantic_routing_profile: CollectionSemanticRoutingProfile = Field(
        default_factory=CollectionSemanticRoutingProfile,
        description="Collection-level semantic retrieval routing profile.",
    )
    question_processing_concurrency: int | None = Field(
        default=None,
        ge=1,
        le=100,
        description="Default per-document question-generation concurrency for this collection. NULL uses the global RAG default.",
    )


class CreateCollectionResponse(BaseModel):
    """Response from creating a collection."""

    id: UUID
    name: str
    description: str | None
    embedding_model: str = Field(
        description="Embedding model used (e.g., voyage-context-3)"
    )
    chunk_size_tokens: int = Field(description="Target tokens per chunk")
    chunk_overlap_tokens: int = Field(
        description="Token overlap between adjacent chunks"
    )
    section_strategy: str = Field(
        description="Section extraction strategy: heading_based, paragraph_based, fixed_size, or none"
    )
    dedup_similarity_threshold: float | None = Field(
        description="Cosine similarity threshold for dedup. NULL = dedup disabled."
    )
    rerank_instruction: str | None = Field(
        description="Default Voyage AI rerank instruction for this collection"
    )
    preprocessing_config: CollectionPreprocessingConfig
    semantic_routing_profile: CollectionSemanticRoutingProfile
    question_generation_mode: CollectionQuestionGenerationMode = Field(
        description="Server-managed question-generation capability for this collection. Derived from completed document state."
    )
    question_processing_concurrency: int | None = Field(
        description="Default per-document question-generation concurrency for this collection. NULL means global fallback."
    )


class CollectionSummary(BaseModel):
    """Summary of a document collection for list responses."""

    id: UUID
    name: str
    description: str | None
    embedding_model: str = Field(description="Embedding model (e.g., voyage-context-3)")
    chunk_size_tokens: int = Field(description="Target tokens per chunk")
    chunk_overlap_tokens: int = Field(
        description="Token overlap between adjacent chunks"
    )
    section_strategy: str = Field(
        description="Section extraction strategy: heading_based, paragraph_based, fixed_size, or none"
    )
    dedup_similarity_threshold: float | None = Field(
        description="Cosine similarity threshold for dedup. NULL = dedup disabled."
    )
    rerank_instruction: str | None = Field(
        description="Default Voyage AI rerank instruction for this collection"
    )
    preprocessing_config: CollectionPreprocessingConfig
    semantic_routing_profile: CollectionSemanticRoutingProfile
    question_generation_mode: CollectionQuestionGenerationMode = Field(
        description="Server-managed question-generation capability for this collection. Derived from completed document state."
    )
    question_processing_concurrency: int | None = Field(
        description="Default per-document question-generation concurrency for this collection. NULL means global fallback."
    )
    created_at: datetime
    updated_at: datetime


class ListCollectionsResponse(BaseModel):
    """Response containing list of collections."""

    collections: list[CollectionSummary]
    total: int


class CollectionDocumentStatusSummary(BaseModel):
    collection_id: UUID
    collection_name: str
    total_documents: int
    queued_documents: int
    processing_documents: int
    completed_documents: int
    failed_documents: int
    duplicate_documents: int
    filtered_documents: int
    estimated_remaining_processing_ms: int | None = None


class ListCollectionDocumentStatusesResponse(BaseModel):
    collections: list[CollectionDocumentStatusSummary]
    total: int


class GetCollectionResponse(BaseModel):
    """Response containing collection details with document count."""

    id: UUID
    name: str
    description: str | None
    embedding_model: str = Field(description="Embedding model (e.g., voyage-context-3)")
    embedding_dimensions: int = Field(
        description="Embedding vector dimensions (e.g., 1024)"
    )
    chunk_size_tokens: int = Field(description="Target tokens per chunk")
    chunk_overlap_tokens: int = Field(
        description="Token overlap between adjacent chunks"
    )
    section_strategy: str = Field(
        description="Section extraction strategy: heading_based, paragraph_based, fixed_size, or none"
    )
    dedup_similarity_threshold: float | None = Field(
        description="Cosine similarity threshold for dedup. NULL = dedup disabled."
    )
    rerank_instruction: str | None = Field(
        description="Default Voyage AI rerank instruction for this collection"
    )
    preprocessing_config: CollectionPreprocessingConfig
    semantic_routing_profile: CollectionSemanticRoutingProfile
    question_generation_mode: CollectionQuestionGenerationMode = Field(
        description="Server-managed question-generation capability for this collection. Derived from completed document state."
    )
    question_processing_concurrency: int | None = Field(
        description="Default per-document question-generation concurrency for this collection. NULL means global fallback."
    )
    document_count: int = Field(description="Number of documents in this collection")
    created_at: datetime
    updated_at: datetime


class UpdateCollectionRequest(BaseModel):
    """Request to update a document collection."""

    name: str | None = Field(
        None, min_length=1, max_length=255, description="Collection name"
    )
    description: str | None = Field(None, description="Optional description")
    rerank_instruction: str | None = Field(
        None,
        max_length=500,
        description="Default instruction for Voyage AI reranking",
    )
    preprocessing_config: CollectionPreprocessingConfig | None = Field(
        default=None,
        description="Collection-level preprocessing settings. Set min_length to 0 to disable length filtering.",
    )
    semantic_routing_profile: CollectionSemanticRoutingProfilePatch | None = Field(
        default=None,
        description="Collection-level semantic retrieval routing profile. Omit to leave unchanged.",
    )
    question_processing_concurrency: int | None = Field(
        default=None,
        ge=1,
        le=100,
        description="Default per-document question-generation concurrency for this collection. Set null to clear and use the global fallback.",
    )

    @field_validator("preprocessing_config", mode="before")
    @classmethod
    def validate_preprocessing_config_patch(cls, value: Any) -> Any:
        if value is None:
            raise ValueError(
                "preprocessing_config cannot be null; omit it to leave it unchanged"
            )
        if value == {}:
            raise ValueError(
                "preprocessing_config must include at least one setting; omit it to leave it unchanged"
            )
        return value

    @field_validator("semantic_routing_profile", mode="before")
    @classmethod
    def validate_semantic_routing_profile_patch(cls, value: Any) -> Any:
        if value is None:
            raise ValueError(
                "semantic_routing_profile cannot be null; omit it to leave it unchanged"
            )
        if value == {}:
            raise ValueError(
                "semantic_routing_profile must include at least one setting; omit it to leave it unchanged"
            )
        return value


class UpdateCollectionResponse(BaseModel):
    """Response from updating a collection."""

    id: UUID
    name: str
    description: str | None
    embedding_model: str = Field(description="Embedding model (e.g., voyage-context-3)")
    embedding_dimensions: int = Field(
        description="Embedding vector dimensions (e.g., 1024)"
    )
    chunk_size_tokens: int = Field(
        description="Target tokens per chunk (immutable after creation)"
    )
    chunk_overlap_tokens: int = Field(
        description="Token overlap between chunks (immutable after creation)"
    )
    section_strategy: str = Field(
        description="Section extraction strategy (immutable after creation)"
    )
    rerank_instruction: str | None = Field(
        description="Default Voyage AI rerank instruction for this collection"
    )
    preprocessing_config: CollectionPreprocessingConfig
    semantic_routing_profile: CollectionSemanticRoutingProfile
    question_generation_mode: CollectionQuestionGenerationMode = Field(
        description="Server-managed question-generation capability for this collection. Derived from completed document state."
    )
    question_processing_concurrency: int | None = Field(
        description="Default per-document question-generation concurrency for this collection. NULL means global fallback."
    )
    created_at: datetime
    updated_at: datetime


class DeleteCollectionResponse(BaseModel):
    """Response containing deleted collection info.

    Cascade: deleting a collection removes all documents, chunks, sections, and embeddings.
    """

    id: UUID
    name: str
    documents_deleted: int = Field(
        description="Number of documents deleted via cascade"
    )


# === Documents ===


class SpeakerConfig(BaseModel):
    """Speaker handling configuration for transcript preprocessing.

    Controls how speaker labels are processed:
    - "keep": Preserve speaker labels as-is (e.g., "John:", "Speaker 1:")
    - "remove": Strip all speaker labels from content (default)
    - "remap": Replace speaker labels with custom values

    Examples:
        # Keep speakers unchanged
        SpeakerConfig(mode="keep")

        # Remove all speaker labels (default)
        SpeakerConfig(mode="remove")

        # Remap anonymous speakers to names
        SpeakerConfig(
            mode="remap",
            mappings={
                "Phone Caller #1": "Dan Nicolas",
                "Phone Caller #2": "Robert Paolitto"
            }
        )
    """

    mode: Literal["keep", "remove", "remap"] = Field(
        default="remove",
        description="Speaker handling mode: 'keep' preserves labels, 'remove' strips them, 'remap' replaces them",
    )
    mappings: dict[str, str] | None = Field(
        default=None,
        description="Speaker name mappings when mode='remap'. Keys are original names, values are replacements.",
    )

    @model_validator(mode="after")
    def validate_mappings_for_remap(self) -> Self:
        """Require non-empty mappings when mode is 'remap'."""
        if self.mode == "remap":
            if not self.mappings:
                raise ValueError("mappings required when mode is 'remap'")
        return self


class IngestDocumentRequest(BaseModel):
    """Request to ingest a document.

    Preprocessing pipeline: Raw content → NormalizationStage → ContentTypeProcessor
    (transcript/markdown/document) → StructuralNormalizationStage → QualityFilterStage
    (may reject) → processed content.

    Transcript processor removes timestamps, filler words, and handles speaker labels
    via speaker_config. Markdown processor preserves structure. Document processor
    removes page numbers, headers/footers, and fixes hyphenation.
    """

    collection_id: str | UUID = Field(
        ..., description="Target collection identifier - can be UUID or collection name"
    )
    title: str = Field(..., min_length=1, max_length=500, description="Document title")
    content: str = Field(..., min_length=1, description="Document text content")
    question_gen_agent_id: str | UUID | None = Field(
        default=None,
        description="Question-generation agent identifier - can be UUID or agent name. "
        "Required unless skip_question_generation=True.",
    )
    question_gen_template_id: str | UUID | None = Field(
        default=None,
        description="Question-generation template identifier - can be UUID or template name. "
        "Required unless skip_question_generation=True.",
    )
    skip_question_generation: bool = Field(
        default=False,
        description="If True, skip question generation and retrieval keyword extraction during ingestion. "
        "Reduces ingestion time and cost. Chunks are still searchable via content embeddings and BM25.",
    )
    source_type: SourceType = Field(default="upload", description="Source type")
    document_type: Literal["transcript", "markdown", "document", "form"] = Field(
        default="document",
        description="Document type for preprocessing: "
        "'transcript' for podcasts/videos/meetings/calls with timestamps and speaker labels, "
        "'markdown' for markdown-formatted content, "
        "'document' for general text documents, "
        "'form' for semi-structured form or intake content",
    )
    chunk_size_tokens: int | None = Field(
        default=None,
        ge=64,
        le=8192,
        description="Optional per-document chunk size override. NULL uses collection default.",
    )
    chunk_overlap_tokens: int | None = Field(
        default=None,
        ge=0,
        description="Optional per-document chunk overlap override. NULL uses collection default.",
    )
    section_strategy: SectionStrategyType | None = Field(
        default=None,
        description="Optional per-document section extraction strategy override. NULL uses collection default.",
    )
    semantic_splitter_model: SemanticSplitterModelType | None = Field(
        default=None,
        description="Optional per-document Voyage model for semantic chunking. "
        "NULL uses system default. Allowed: voyage-4-nano, voyage-4-lite, voyage-3, voyage-3-lite, voyage-3.5-lite.",
    )
    question_processing_concurrency: int | None = Field(
        default=None,
        ge=1,
        le=100,
        description="Optional per-document override for question-generation concurrency. NULL uses collection default, then global fallback.",
    )
    speaker_config: SpeakerConfig | None = Field(
        None,
        description="Speaker handling for transcript documents. "
        "Use mode='keep' to preserve speakers, mode='remove' to strip them, "
        "or mode='remap' with mappings to replace speaker names.",
    )
    metadata: dict[str, Any] | None = Field(
        None, description="Optional document metadata"
    )
    document_author: str | None = Field(
        default=None,
        max_length=500,
        description="Optional document author name. Displayed alongside document title in RAG search results.",
    )
    external_id: str | None = Field(
        default=None,
        description="Optional caller-provided identifier for idempotency and correlation. "
        "Unique per organization across all collections.",
    )
    tags: list[str] | None = Field(
        None,
        description="Optional hierarchical tag paths (e.g., ['engineering.backend', 'docs.api']). "
        "Tags will be auto-created if they don't exist.",
    )
    source_date: datetime | None = Field(
        default=None,
        description="When the source content was originally produced (e.g., Slack message timestamp, "
        "meeting date, publication date). If omitted, falls back to metadata['source_date'] if present "
        "and parseable. Stored as UTC timestamptz.",
    )
    dry_run: bool = Field(
        default=False,
        description="If True, only preprocess the document and return the result without persisting. "
        "Useful for testing preprocessing pipeline output.",
    )

    @model_validator(mode="after")
    def validate_speaker_config_for_transcript(self) -> Self:
        """Ensure speaker_config is only used with document_type='transcript'."""
        if self.speaker_config and self.document_type != "transcript":
            raise ValueError(
                "speaker_config is only valid when document_type is 'transcript'"
            )
        return self

    @model_validator(mode="after")
    def validate_chunk_overlap_less_than_chunk_size(self) -> Self:
        if (
            self.chunk_size_tokens is not None
            and self.chunk_overlap_tokens is not None
            and self.chunk_overlap_tokens >= self.chunk_size_tokens
        ):
            raise ValueError("chunk_overlap_tokens must be less than chunk_size_tokens")
        return self

    @model_validator(mode="after")
    def validate_question_gen_fields_required_unless_skipping(self) -> Self:
        """Require question_gen_agent_id and question_gen_template_id unless skip_question_generation=True."""
        if not self.skip_question_generation:
            if self.question_gen_agent_id is None:
                raise ValueError(
                    "question_gen_agent_id is required when skip_question_generation is False"
                )
            if self.question_gen_template_id is None:
                raise ValueError(
                    "question_gen_template_id is required when skip_question_generation is False"
                )
        return self


class IngestDocumentResponse(BaseModel):
    """Response from ingesting a document.

    New documents are usually queued for background processing.
    Exact duplicate replays may instead return the existing document directly.

    When dry_run=True, includes processed_content and diff fields.
    """

    document_id: UUID | None = None  # None when dry_run=True
    title: str
    status: IngestResponseStatus
    message: str
    external_id: str | None = None
    # Dry run fields
    dry_run: bool = False
    processed_content: str | None = None
    preprocessing_metadata: dict[str, Any] | None = None
    rejected: bool = False
    rejection_reason: str | None = None
    # Diff fields (only populated when dry_run=True)
    diff_raw: list[dict[str, Any]] | None = None
    diff_unified: str | None = None
    diff_html: str | None = None
    diff_markers: str | None = None
    diff_stats: dict[str, Any] | None = None


class DocumentSummary(BaseModel):
    """Summary of a document for list responses."""

    id: UUID
    collection_id: UUID
    title: str
    source_type: str = Field(
        description="Document origin: upload, paste, api_import, or url_scrape"
    )
    character_count: int = Field(description="Character count of original content")
    estimated_tokens: int | None = Field(
        description="Estimated token count (populated after embedding)"
    )
    processing_status: ProcessingStatus
    is_processing_terminal: bool = Field(
        default=False,
        description="True when processing is complete (success or failure). "
        "Clients should stop polling when this is True.",
    )
    processing_error: str | None = Field(
        default=None,
        description="Error message if processing failed (e.g., preprocessing rejection)",
    )
    filtered_reason: FilteredReason | None = Field(
        default=None,
        description="Structured reason when a document is terminally filtered rather than failed.",
    )
    chunks_count: int = Field(description="Number of chunks after deduplication")
    chunks_failed: int = Field(description="Chunks where question generation failed")
    chunks_deduplicated: int = Field(
        description="Chunks removed as duplicates (hash + semantic)"
    )
    questions_generated: int = Field(
        description="Successfully generated hypothetical questions"
    )
    metadata: dict[str, Any] | None = Field(
        description="User-provided + system-generated metadata (JSONB)"
    )
    external_id: str | None = None
    source_date: datetime | None = Field(
        default=None,
        description="When the source content was originally produced. NULL when unknown.",
    )
    created_at: datetime
    updated_at: datetime
    tags: list[TagResponse] = Field(default_factory=_empty_tag_responses)

    @model_validator(mode="after")
    def validate_filtered_reason_invariant(self) -> Self:
        if self.processing_status == "filtered" and self.filtered_reason is None:
            raise ValueError("filtered documents must include filtered_reason")
        if self.processing_status != "filtered" and self.filtered_reason is not None:
            raise ValueError("filtered_reason is only valid for filtered documents")
        return self


class ListDocumentsResponse(BaseModel):
    """Response containing list of documents."""

    documents: list[DocumentSummary]
    total: int


class ChunkQuestionResponse(BaseModel):
    """A hypothetical question generated for a document chunk during ingestion."""

    id: UUID
    chunk_id: UUID = Field(
        description="ID of the chunk this question was generated for"
    )
    question_text: str = Field(description="The generated hypothetical question")
    created_at: datetime


def _empty_chunk_questions() -> list[ChunkQuestionResponse]:
    return []


class GetDocumentResponse(BaseModel):
    """Response containing document details."""

    id: UUID
    collection_id: UUID
    title: str
    document_author: str | None = Field(
        default=None,
        description="Author name displayed alongside title in search results",
    )
    source_type: str = Field(
        description="Document origin: upload, paste, api_import, or url_scrape"
    )
    character_count: int = Field(description="Character count of original content")
    estimated_tokens: int | None = Field(
        description="Estimated token count (populated after embedding)"
    )
    processing_status: ProcessingStatus
    is_processing_terminal: bool = Field(
        default=False,
        description="True when processing is complete (success or failure). "
        "Clients should stop polling when this is True.",
    )
    processing_error: str | None = Field(
        default=None, description="Error details if processing failed"
    )
    processing_warnings: list[str] | None = Field(
        default=None,
        description="Non-fatal warnings from preprocessing (e.g., borderline quality scores)",
    )
    filtered_reason: FilteredReason | None = Field(
        default=None,
        description="Structured reason when a document is terminally filtered rather than failed.",
    )
    chunks_count: int = Field(description="Number of chunks after deduplication")
    chunks_failed: int = Field(description="Chunks where question generation failed")
    chunks_deduplicated: int = Field(
        description="Chunks removed as duplicates (hash + semantic)"
    )
    questions_generated: int = Field(
        description="Successfully generated hypothetical questions"
    )
    metadata: dict[str, Any] | None = Field(
        description="User-provided + system-generated metadata (JSONB)"
    )
    external_id: str | None = None
    source_date: datetime | None = Field(
        default=None,
        description="When the source content was originally produced. NULL when unknown.",
    )
    original_content: str | None = Field(
        default=None,
        description="Raw document text. Only included if include_content=true.",
    )
    created_at: datetime
    updated_at: datetime
    tags: list[TagResponse] = Field(default_factory=_empty_tag_responses)
    chunk_questions: list[ChunkQuestionResponse] = Field(
        default_factory=_empty_chunk_questions,
        description="Generated hypothetical questions per chunk. Only included if include_questions=true.",
    )

    @model_validator(mode="after")
    def validate_filtered_reason_invariant(self) -> Self:
        if self.processing_status == "filtered" and self.filtered_reason is None:
            raise ValueError("filtered documents must include filtered_reason")
        if self.processing_status != "filtered" and self.filtered_reason is not None:
            raise ValueError("filtered_reason is only valid for filtered documents")
        return self


class DeleteDocumentResponse(BaseModel):
    """Response containing deleted document info."""

    id: UUID
    title: str
    chunks_deleted: int = Field(description="Number of chunks deleted via cascade")


# Keys written by the ingestion pipeline — user updates must not overwrite these.
SYSTEM_MANAGED_METADATA_KEYS: frozenset[str] = frozenset(
    {
        "preprocessing_metadata",
        "question_generation_quality",
        "chunk_quality_summary",
    }
)


def _reject_system_metadata_keys(metadata: dict[str, Any]) -> dict[str, Any]:
    """Validate that user-supplied metadata does not contain system-managed keys."""
    forbidden = SYSTEM_MANAGED_METADATA_KEYS & metadata.keys()
    if forbidden:
        raise ValueError(
            f"Cannot modify system-managed metadata keys: {sorted(forbidden)}. "
            f"These keys are written by the ingestion pipeline and must not be overwritten."
        )
    return metadata


class UpdateDocumentMetadataRequest(BaseModel):
    """Request to update a document's metadata."""

    metadata: dict[str, Any] = Field(..., description="Metadata to apply")
    metadata_mode: Literal["merge", "replace"] = Field(
        default="merge",
        description="'merge' (default): adds/overwrites keys, preserves others. 'replace': full replacement",
    )

    @field_validator("metadata")
    @classmethod
    def metadata_must_not_contain_system_keys(cls, v: dict[str, Any]) -> dict[str, Any]:
        return _reject_system_metadata_keys(v)


class UpdateDocumentMetadataResponse(BaseModel):
    """Response from updating a document's metadata."""

    id: UUID
    collection_id: UUID
    title: str
    metadata: dict[str, Any] | None = Field(description="Updated document metadata")
    updated_at: datetime


class BulkUpdateDocumentMetadataRequest(BaseModel):
    """Request to bulk-update metadata across documents matching a filter."""

    filter: dict[str, Any] = Field(
        ..., description="JSONB containment filter to match documents"
    )
    patch: dict[str, Any] = Field(..., description="Metadata fields to apply")
    metadata_mode: Literal["merge", "replace"] = Field(
        default="merge",
        description="'merge' (default): adds/overwrites keys, preserves others. 'replace': full replacement",
    )
    collection_id: str | UUID | None = Field(
        default=None, description="Optional collection scope"
    )
    dry_run: bool = Field(
        default=False, description="If True, return matched count without updating"
    )

    @field_validator("filter")
    @classmethod
    def filter_must_not_be_empty(cls, v: dict[str, Any]) -> dict[str, Any]:
        if not v:
            raise ValueError(
                "filter must not be empty — would match all documents in org"
            )
        return v

    @field_validator("patch")
    @classmethod
    def patch_must_not_contain_system_keys(cls, v: dict[str, Any]) -> dict[str, Any]:
        return _reject_system_metadata_keys(v)


class BulkUpdateDocumentMetadataResponse(BaseModel):
    """Response from bulk-updating document metadata."""

    updated_count: int = Field(description="Number of documents updated (0 if dry_run)")
    matched_count: int = Field(description="Number of documents matching the filter")
    dry_run: bool = Field(default=False, description="Whether this was a dry run")


class ReingestDocumentRequest(BaseModel):
    """Request to reingest a document with new processing parameters.

    Use this to re-process a document when you want to:
    - Change the question generation agent or template
    - Change the preprocessing pipeline (document_type)
    - Add or update speaker configuration for transcripts
    - Preview changes with dry_run before committing

    The document's original content is preserved; only derived data
    (sections, chunks, questions, embeddings) is regenerated.
    """

    question_gen_agent_id: str | UUID | None = Field(
        default=None,
        description="New question-generation agent identifier - can be UUID or agent name. None = keep current.",
    )
    question_gen_template_id: str | UUID | None = Field(
        default=None,
        description="New question-generation template identifier - can be UUID or template name. None = keep current.",
    )
    document_type: Literal["transcript", "markdown", "document", "form"] | None = Field(
        default=None,
        description="New document type for preprocessing. None = keep current. "
        "'transcript' for podcasts/videos/meetings/calls with timestamps, "
        "'markdown' for markdown-formatted content, "
        "'document' for general text documents, "
        "'form' for semi-structured form or intake content.",
    )
    chunk_size_tokens: int | None = Field(
        default=None,
        ge=64,
        le=8192,
        description="New per-document chunk size override. None = keep current.",
    )
    chunk_overlap_tokens: int | None = Field(
        default=None,
        ge=0,
        description="New per-document chunk overlap override. None = keep current.",
    )
    section_strategy: SectionStrategyType | None = Field(
        default=None,
        description="New per-document section strategy override. None = keep current.",
    )
    semantic_splitter_model: SemanticSplitterModelType | None = Field(
        default=None,
        description="New per-document Voyage model for semantic chunking. None = keep current. "
        "Allowed: voyage-4-nano, voyage-4-lite, voyage-3, voyage-3-lite, voyage-3.5-lite.",
    )
    question_processing_concurrency: int | None = Field(
        default=None,
        ge=1,
        le=100,
        description="New per-document question-generation concurrency override. None = keep current resolved value.",
    )
    speaker_config: SpeakerConfig | None = Field(
        default=None,
        description="Speaker handling for transcript documents. "
        "Only valid when document_type is 'transcript' (or will become 'transcript').",
    )
    skip_question_generation: bool | None = Field(
        default=None,
        description="If True, skip question generation on reingest. None = keep current setting.",
    )
    dry_run: bool = Field(
        default=False,
        description="If True, only preview preprocessing changes without committing. "
        "Returns diff showing what would change in processed content.",
    )

    @model_validator(mode="after")
    def at_least_one_change_or_dry_run(self) -> Self:
        has_change = (
            self.question_gen_agent_id is not None
            or self.question_gen_template_id is not None
            or self.document_type is not None
            or self.chunk_size_tokens is not None
            or self.chunk_overlap_tokens is not None
            or self.section_strategy is not None
            or self.semantic_splitter_model is not None
            or self.question_processing_concurrency is not None
            or self.speaker_config is not None
            or self.skip_question_generation is not None
        )
        if not has_change and not self.dry_run:
            raise ValueError(
                "At least one of question_gen_agent_id, question_gen_template_id, "
                "document_type, chunk_size_tokens, chunk_overlap_tokens, "
                "section_strategy, semantic_splitter_model, question_processing_concurrency, or speaker_config must be provided "
                "(or set dry_run=True to preview current state)"
            )
        return self

    @model_validator(mode="after")
    def validate_speaker_config_requires_transcript(self) -> Self:
        """Ensure speaker_config is only used with transcript document type."""
        if (
            self.speaker_config
            and self.document_type
            and self.document_type != "transcript"
        ):
            raise ValueError(
                "speaker_config is only valid when document_type is 'transcript'"
            )
        return self

    @model_validator(mode="after")
    def validate_chunk_overlap_less_than_chunk_size(self) -> Self:
        if (
            self.chunk_size_tokens is not None
            and self.chunk_overlap_tokens is not None
            and self.chunk_overlap_tokens >= self.chunk_size_tokens
        ):
            raise ValueError("chunk_overlap_tokens must be less than chunk_size_tokens")
        return self


class ReingestDocumentResponse(BaseModel):
    """Response from reingesting a document.

    When dry_run=False:
        - document_id is set
        - status is "queued"
        - Processing happens asynchronously via Celery workers

    When dry_run=True:
        - status is "dry_run_complete"
        - Diff fields show preprocessing changes
        - No data is modified
    """

    document_id: UUID
    status: ReingestResponseStatus
    message: str
    # Parameters that will be used (after merging with existing)
    question_gen_agent_id: UUID | None
    question_gen_template_id: UUID | None
    document_type: str
    chunk_size_tokens: int | None = None
    chunk_overlap_tokens: int | None = None
    section_strategy: str | None = None
    semantic_splitter_model: str | None = None
    question_processing_concurrency: int | None = None
    speaker_config: SpeakerConfig | None = None
    # Dry run fields (only populated when dry_run=True)
    dry_run: bool = False
    processed_content: str | None = None
    preprocessing_metadata: dict[str, Any] | None = None
    rejected: bool = False
    rejection_reason: str | None = None
    # Diff fields (only populated when dry_run=True)
    diff_raw: list[dict[str, Any]] | None = None
    diff_unified: str | None = None
    diff_html: str | None = None
    diff_markers: str | None = None
    diff_stats: dict[str, Any] | None = None


class BulkReingestFailedDocumentsRequest(BaseModel):
    dry_run: bool = Field(
        default=False,
        description="If True, preview which failed documents would be queued without enqueuing them.",
    )
    collection_id: UUID | None = Field(
        default=None,
        description="Optional collection UUID to scope the failed-document reingest.",
    )
    document_ids: list[UUID] | None = Field(
        default=None,
        description="Optional document UUIDs to limit reingest to specific failed documents.",
    )


class BulkReingestFailedDocumentsResponse(BaseModel):
    matched_count: int = Field(
        description="Number of failed documents matching the provided scope."
    )
    queued_count: int = Field(
        description="Number of matched documents queued for reingest."
    )
    skipped_count: int = Field(
        description="Number of matched documents skipped instead of queued."
    )
    matched_document_ids: list[UUID] = Field(
        description="Document IDs matching the failed-document reingest scope."
    )
    queued_document_ids: list[UUID] = Field(
        description="Document IDs queued for reingest."
    )
    skipped_document_ids: list[UUID] = Field(
        description="Document IDs skipped during bulk failed-document reingest."
    )
    message: str = Field(
        description="Human-readable summary of the bulk reingest result."
    )
    dry_run: bool = Field(
        default=False,
        description="Whether the bulk failed-document reingest was a dry run.",
    )


# === Search ===


# Search mode type alias
SearchMode = Literal["semantic", "keyword", "exact_phrase"]


class SearchRequest(BaseModel):
    """Request to search the knowledge base.

    Canonical defaults: retrieval_k=75, rerank_k=5, min_confidence=0.20.
    HyDE and decomposition are opt-in via explicit agent/template IDs.
    """

    model_config = ConfigDict(extra="forbid")

    query: str = Field(..., min_length=1, description="Search query")
    collection_ids: list[UUID] | None = Field(
        None, description="Collection IDs to search (None = all collections)"
    )
    collection_filter: str | None = Field(
        None, description="Filter by collection name (alternative to collection_ids)"
    )
    top_k: int = Field(
        default=5, ge=1, le=20, description="Number of results to return"
    )
    metadata_filter: ConditionSpec | LogicalSpec | None = Field(
        None,
        description="Filter by structured document metadata expressions",
    )
    tag_filter: str | None = Field(
        None,
        description="Filter by document tag pattern (e.g., 'engineering.*', 'docs'). "
        "Supports ltree pattern matching with wildcards.",
    )
    source_date_from: datetime | None = Field(
        None,
        description="Filter documents with source_date >= this value (inclusive). "
        "Half-open interval: [from, to). ISO 8601 format with timezone.",
    )
    source_date_to: datetime | None = Field(
        None,
        description="Filter documents with source_date < this value (exclusive). "
        "Half-open interval: [from, to). ISO 8601 format with timezone.",
    )

    # Advanced retrieval configuration
    rerank_instruction: str | None = Field(
        None,
        max_length=500,
        description="Custom instruction for reranking (e.g., 'Prioritize recent documents')",
    )
    retrieval_k: int | None = Field(
        None,
        ge=1,
        le=1000,
        description="Override initial candidate retrieval count.",
    )
    min_retrieval_confidence: float | None = Field(
        None,
        ge=0.0,
        le=1.0,
        description="Override minimum confidence threshold for results (0.0-1.0)",
    )

    # Search mode configuration
    search_mode: SearchMode = Field(
        default="semantic",
        description="Search mode: 'semantic' for AI-powered search with embeddings and ranking, "
        "'keyword' for BM25 text search (finds terms in any order), "
        "'exact_phrase' for verbatim matching (error codes, identifiers, quotes)",
    )

    # HyDE (Hypothetical Document Embeddings) configuration
    hyde_agent_id: UUID | None = Field(
        None, description="Agent for HyDE hypothetical document generation"
    )
    hyde_template_id: UUID | None = Field(
        None,
        description="Template ID for HyDE hypothetical document generation (receives {{ query }} variable). Latest version is used automatically.",
    )

    # Query decomposition configuration
    decomposition_agent_id: UUID | None = Field(
        None, description="Agent for query decomposition"
    )
    decomposition_template_id: UUID | None = Field(
        None,
        description="Template ID for query decomposition (receives {{ query }} variable). Latest version is used automatically.",
    )

    @model_validator(mode="after")
    def validate_source_date_range(self) -> Self:
        from_dt = self.source_date_from
        to_dt = self.source_date_to
        for field_name, dt in (
            ("source_date_from", from_dt),
            ("source_date_to", to_dt),
        ):
            if dt is not None and dt.tzinfo is None:
                raise ValueError(
                    f"{field_name} must include timezone information (e.g. '2026-01-01T00:00:00Z')"
                )
        if from_dt and to_dt:
            # Both are tz-aware at this point; normalize to UTC for comparison
            from_utc = from_dt.astimezone(timezone.utc)
            to_utc = to_dt.astimezone(timezone.utc)
            if from_utc >= to_utc:
                raise ValueError("source_date_from must be before source_date_to")
        return self


class SearchResultItem(BaseModel):
    """A single search result from the RAG pipeline."""

    chunk_id: UUID = Field(description="Source chunk ID for attribution")
    document_id: UUID = Field(description="Parent document ID")
    document_title: str = Field(description="Document title for display")
    document_metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Parent document metadata for display and attribution",
    )
    content: str = Field(description="Chunk text, possibly expanded to parent section")
    relevance_score: float = Field(description="Voyage rerank score (0.0-1.0)")
    metadata: dict[str, Any] = Field(
        description="Chunk metadata + section expansion info"
    )
    low_confidence: bool = Field(
        default=False,
        description="True if no results met confidence threshold; this is the best-effort fallback",
    )
    document_tags: list[TagResponse] = Field(
        default_factory=_empty_tag_responses,
        description="Tags associated with the source document",
    )


class SearchResponse(BaseModel):
    """Response from knowledge base search."""

    results: list[SearchResultItem]
    query: str = Field(
        description="Executed query (may differ from original if transformed)"
    )
    total_candidates: int = Field(description="Candidates found before reranking")
    avg_relevance_score: float = Field(
        description="Average relevance score across results"
    )
    timing_ms: dict[str, int] = Field(
        description="Performance breakdown. Keys: decomposition_ms, embedding_ms, "
        "original_embedding_ms (if HyDE), search_ms, synthesis_search_ms, rerank_ms, total_ms"
    )

    # Query transformation metadata
    transformations_applied: list[str] = Field(
        default_factory=list,
        description="Transformations applied: 'hyde', 'decomposition'",
    )
    original_query: str | None = Field(
        None, description="Original query if transformations applied"
    )
    sub_queries_used: list[str] | None = Field(
        None, description="Decomposed sub-queries if decomposition applied"
    )
    search_mode: str | None = Field(
        None, description="Search mode used: 'semantic', 'keyword', or 'exact_phrase'"
    )


# === Recovery ===


class RecoverDocumentsRequest(BaseModel):
    """Request for document recovery operation.

    Detects stuck claimed documents: status='processing' with stale heartbeat (>10min).
    Queued backlog with no processing_started_at (>60min) is observed by default and
    can be restarted from scratch when restart_queued is true.
    Documents under max_retries are reset to queued and re-queued; others are marked permanently failed.
    """

    max_retries: int | None = Field(
        None,
        ge=1,
        le=10,
        description="Override max retry attempts (default: 3)",
    )
    restart_queued: bool = Field(
        False,
        description="Restart old queued backlog documents from scratch using reingest semantics",
    )


class RecoverDocumentsResponse(BaseModel):
    """Response from document recovery operation."""

    recovered_count: int = Field(description="Number of documents reset for retry")
    failed_count: int = Field(
        description="Number of documents marked as permanently failed"
    )
    requeued_count: int = Field(
        default=0, description="Number of documents re-queued for processing"
    )
    queued_restart_count: int = Field(
        default=0,
        description="Number of queued backlog documents restarted from scratch",
    )
    queued_restart_skipped_count: int = Field(
        default=0,
        description="Number of queued backlog documents skipped during restart",
    )
    recovered_document_ids: list[UUID] = Field(description="IDs of recovered documents")
    failed_document_ids: list[UUID] = Field(
        description="IDs of permanently failed documents"
    )
    requeued_document_ids: list[UUID] = Field(
        default_factory=_empty_uuid_list,
        description="IDs of documents re-queued for processing",
    )
    queued_restart_document_ids: list[UUID] = Field(
        default_factory=_empty_uuid_list,
        description="IDs of queued backlog documents restarted from scratch",
    )
    queued_restart_skipped_document_ids: list[UUID] = Field(
        default_factory=_empty_uuid_list,
        description="IDs of queued backlog documents skipped during restart",
    )


class TriggerCollectionClusteringResponse(BaseModel):
    collection_id: UUID
    status: str = Field(description="pending")
    task_id: str = Field(
        description="Celery task ID for run-scoped clustering status polling"
    )
    message: str


class GetCollectionClusteringStatusResponse(BaseModel):
    collection_id: UUID
    status: ClusteringStatus
    is_terminal: bool = Field(
        description="True when clustering reached terminal status and polling can stop"
    )
    message: str | None = Field(default=None)
    error_message: str | None = Field(default=None)
    cluster_count: int
    total_chunks: int
    clustered_chunks: int
    noise_chunks: int
    unclustered_chunks: int
    last_cluster_run_at: datetime | None = Field(default=None)


# === Synthesis ===

SynthesisStatus = Literal[
    "accepted",
    "queued",
    "worker_assigned",
    "processing",
    "completed",
    "failed",
]


class SynthesisQueueMetadata(BaseModel):
    request_fingerprint: str
    request_fingerprint_version: int
    attempt_id: UUID | None = None
    attempt_number: int | None = None
    total_attempt_count: int | None = None
    failure_classification: str | None = None
    accepted_at: datetime
    queued_at: datetime | None = None
    worker_assigned_at: datetime | None = None
    processing_started_at: datetime | None = None
    last_heartbeat_at: datetime | None = None
    completed_at: datetime | None = None


class CreateSynthesisRequest(BaseModel):
    """Request to create a corpus-level synthesis.

    IMPORTANT: The collection_ids field is for metadata and staleness tracking only.
    It does NOT control which collections the agent searches during synthesis.

    The agent's rag_search tool behavior is controlled by its pre-configured
    tool settings in ai.agent_tools.config. To restrict which collections the
    agent searches, configure collection_ids in the agent's rag_search tool config.

    The collection_ids in this request are validated to ensure the agent has
    access to all specified collections. If the agent's rag_search tool is
    configured with collection_ids that don't include all request collection_ids,
    the request will be rejected.
    """

    topic: str = Field(
        ...,
        min_length=1,
        description="Topic to research and synthesize",
    )
    collection_ids: list[UUID] = Field(
        ...,
        min_length=1,
        description="Collection IDs to associate with the synthesis. Used for staleness "
        "tracking and metadata - the agent must have these collections configured in its "
        "rag_search tool config to actually search them. Request fails if the agent's "
        "rag_search tool cannot access all specified collections.",
    )
    synthesizer_agent_id: UUID = Field(
        ..., description="Agent with RAG tools to perform the synthesis"
    )
    synthesis_template_id: UUID = Field(
        ...,
        description="Template ID for the synthesis prompt (receives {{ topic }} variable). Latest version is used automatically.",
    )
    title: str | None = Field(
        None,
        min_length=1,
        max_length=500,
        description="Optional title for the synthesis (defaults to topic)",
    )
    metadata: dict[str, Any] | None = Field(
        None, description="Optional metadata for the synthesis"
    )


class CreateSynthesisResponse(BaseModel):
    synthesis_id: UUID
    status: SynthesisStatus
    message: str
    queue_metadata: SynthesisQueueMetadata


class SynthesisSummary(BaseModel):
    id: UUID
    topic: str = Field(description="Research topic that was synthesized")
    title: str = Field(description="Display title (defaults to topic)")
    status: SynthesisStatus = Field(
        description="accepted, queued, worker_assigned, processing, completed, or failed"
    )
    is_stale: bool = Field(
        description="True if source data changed since synthesis was generated"
    )
    source_chunk_count: int = Field(description="Number of source chunks used")
    collection_ids: list[UUID] = Field(
        description="Collections scoped for staleness tracking"
    )
    created_at: datetime
    updated_at: datetime
    queue_metadata: SynthesisQueueMetadata | None = None


class ListSynthesesResponse(BaseModel):
    """Response containing list of syntheses."""

    syntheses: list[SynthesisSummary]
    total: int


class GetSynthesisResponse(BaseModel):
    id: UUID
    topic: str = Field(description="Research topic that was synthesized")
    title: str = Field(description="Display title (defaults to topic)")
    synthesis_content: str | None = Field(
        description="Generated synthesis text. None if still processing."
    )
    status: SynthesisStatus = Field(
        description="accepted, queued, worker_assigned, processing, completed, or failed"
    )
    error_message: str | None = Field(description="Error details if status is 'failed'")
    is_stale: bool = Field(
        description="True if source chunks were deleted/updated or collection grew 20%+ since synthesis"
    )
    staleness_reason: str | None = Field(
        description="Staleness cause: deleted sources, updated sources, or collection growth percentage"
    )
    source_chunk_count: int = Field(description="Number of source chunks used")
    collection_ids: list[UUID] = Field(
        description="Collections scoped for staleness tracking"
    )
    synthesizer_agent_id: UUID | None = Field(
        description="Agent that performed the synthesis"
    )
    execution_id: UUID | None = Field(
        description="Agent execution trace ID (after completion)"
    )
    metadata: dict[str, Any] | None
    citations: list["SynthesisCitationResponse"] = Field(
        default_factory=lambda: cast(list["SynthesisCitationResponse"], []),
        description="Source chunks cited in the synthesis via [S###] handles",
    )
    created_at: datetime
    updated_at: datetime
    queue_metadata: SynthesisQueueMetadata | None = None


class DeleteSynthesisResponse(BaseModel):
    """Response from deleting a synthesis."""

    id: UUID
    topic: str
    title: str


class RefreshSynthesisResponse(BaseModel):
    synthesis_id: UUID
    status: SynthesisStatus
    message: str
    queue_metadata: SynthesisQueueMetadata


class UpdateSynthesisRequest(BaseModel):
    """Request to update a synthesis document manually."""

    synthesis_content: str | None = Field(default=None, min_length=1)
    title: str | None = Field(default=None, min_length=1, max_length=500)


class UpdateSynthesisResponse(BaseModel):
    """Response from updating a synthesis."""

    id: UUID
    topic: str
    title: str
    synthesis_content: str = Field(description="Updated synthesis content")
    status: str = Field(description="Current synthesis status")
    is_stale: bool = Field(
        description="True if source data changed since synthesis was generated"
    )
    staleness_reason: str | None
    source_chunk_count: int = Field(description="Number of source chunks used")
    collection_ids: list[UUID]
    metadata: dict[str, Any] | None
    updated_at: datetime


class SynthesisSourceInfo(BaseModel):
    """Information about a source chunk used in a synthesis."""

    chunk_id: UUID = Field(description="Source chunk ID")
    document_id: UUID = Field(description="Source document ID")
    relevance_score: float | None = Field(description="RAG search relevance score")
    search_query: str | None = Field(description="Query that found this chunk")


class SynthesisCitationResponse(BaseModel):
    """Source chunk cited in the synthesis output via [S###] handle."""

    id: UUID
    source_handle: str = Field(
        description="The [S###] reference used in synthesis content"
    )
    chunk_id: UUID = Field(description="Source chunk ID")
    document_id: UUID = Field(description="Source document ID")
    relevance_score: float | None = Field(description="RAG search relevance score")
    search_query: str | None = Field(description="Query that found this chunk")


class GetSynthesisSourcesResponse(BaseModel):
    """Response containing synthesis source chunks."""

    synthesis_id: UUID
    sources: list[SynthesisSourceInfo]
    total: int
