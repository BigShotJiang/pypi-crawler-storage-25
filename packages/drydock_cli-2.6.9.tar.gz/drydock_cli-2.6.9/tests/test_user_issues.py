"""Tests for user-reported issues (2026-04-07).

Each test should FAIL before the fix and PASS after.
"""
import hashlib
import pytest
from unittest.mock import patch, MagicMock


class TestMD5Crash:
    """#61: Crash after install — md5 error in manager.py."""

    def test_md5_usedforsecurity(self):
        """md5 should work with usedforsecurity=False."""
        h = hashlib.md5(b"test", usedforsecurity=False)
        assert h.hexdigest() == "098f6bcd4621d373cade4e832627b4f6"

    def test_tool_manager_import(self):
        """Tool manager should not crash on import."""
        from drydock.core.tools.manager import ToolManager
        assert ToolManager is not None


class TestSearchReplaceGarbled:
    """#55: search_replace garbled characters."""

    def test_garbled_detection(self):
        from drydock.core.tools.builtins.search_replace import SearchReplaceArgs
        args = SearchReplaceArgs.model_validate({
            "file_path": "test.py",
            "content": "<<<<<<< SEARCH\nold text\n=======\nnew text\n>>>>>>> REPLACE",
        })
        assert args.file_path == "test.py"


class TestTodoEnumQuotes:
    """#60: Todo enum quoting issues."""

    def test_double_quoted(self):
        from drydock.core.tools.builtins.todo import TodoItem
        item = TodoItem.model_validate({
            "id": "1", "content": "test",
            "status": '"completed"', "priority": '"high"',
        })
        assert item.status.value == "completed"

    def test_single_quoted(self):
        from drydock.core.tools.builtins.todo import TodoItem
        item = TodoItem.model_validate({
            "id": "1", "content": "test",
            "status": "'completed'", "priority": "'high'",
        })
        assert item.status.value == "completed"


class TestEmptyState:
    """#58: IndexError on empty lists."""

    def test_empty_tool_calls(self):
        from drydock.core.types import LLMMessage, Role
        msg = LLMMessage(role=Role.assistant, content="hello", tool_calls=None)
        calls = msg.tool_calls or []
        assert calls == []


if __name__ == "__main__":
    pytest.main([__file__, "-v"])


class TestSearchReplaceGarbledAdvanced:
    """#55: Garbled detection should only catch real corruption."""

    def test_legitimate_repeats_not_flagged(self):
        """Normal repeated chars like ===== should NOT be flagged."""
        from drydock.core.tools.builtins.search_replace import SearchReplace
        blocks = SearchReplace._parse_search_replace_blocks(
            "<<<<<<< SEARCH\ndef foo():\n    x = 5\n=======\ndef foo():\n    x = 10\n>>>>>>> REPLACE"
        )
        assert len(blocks) == 1
        assert "x = 5" in blocks[0].search

    def test_real_garble_detected(self):
        """Token corruption like <<t<ttt<t should be caught."""
        import re
        garbled = "(?P<<t<ttt<t<tststssts>\\d+)"
        assert re.search(r'<[a-z]<[a-z]{2,}<[a-z]', garbled)

    def test_normal_regex_not_garbled(self):
        """Normal regex should not trigger garble detection."""
        import re
        normal = r"(?P<timestamp>\d{4}-\d{2}-\d{2})"
        assert not re.search(r'<[a-z]<[a-z]{2,}<[a-z]', normal)


class TestIndexErrorGuards:
    """#58: Guard all [-1] accesses on potentially empty lists."""

    def test_empty_messages_safe(self):
        """Accessing last message on empty list should not crash."""
        messages = []
        last = messages[-1] if messages else None
        assert last is None

    def test_agent_loop_no_md5(self):
        """Agent loop should use sha256, not md5."""
        import inspect
        from drydock.core.agent_loop import AgentLoop
        source = inspect.getsource(AgentLoop)
        assert "hashlib.md5" not in source, "Still using md5 in agent_loop"
        assert "hashlib.sha256" in source or "sha256" not in source  # either uses sha256 or doesn't hash at all


class TestAPIRecovery:
    """#57: API error recovery should auto-compact."""

    def test_message_list_reset_keeps_structure(self):
        """Reset should produce valid message ordering."""
        from drydock.core.types import MessageList, LLMMessage, Role
        ml = MessageList()
        for i in range(25):
            ml.append(LLMMessage(role=Role.user, content=f"msg {i}"))
            ml.append(LLMMessage(role=Role.assistant, content=f"reply {i}"))
        
        # Simulate emergency reset: keep first user + last 5
        first_user = ml[0]
        kept = [first_user] + list(ml[-5:])
        ml.reset(kept)
        assert len(ml) == 6
        assert ml[0].role == Role.user
