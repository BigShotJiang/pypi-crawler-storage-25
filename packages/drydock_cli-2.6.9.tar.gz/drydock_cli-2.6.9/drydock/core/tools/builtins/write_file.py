from __future__ import annotations

from collections.abc import AsyncGenerator
from pathlib import Path
from typing import ClassVar, final

import anyio
from pydantic import BaseModel, Field

from drydock.core.tools.base import (
    BaseTool,
    BaseToolConfig,
    BaseToolState,
    InvokeContext,
    ToolError,
    ToolPermission,
)
from drydock.core.tools.ui import ToolCallDisplay, ToolResultDisplay, ToolUIData
from drydock.core.tools.utils import resolve_file_tool_permission
from drydock.core.types import ToolResultEvent, ToolStreamEvent


class WriteFileArgs(BaseModel):
    path: str
    content: str
    overwrite: bool = Field(
        default=True, description="Whether to overwrite an existing file."
    )


class WriteFileResult(BaseModel):
    path: str
    bytes_written: int
    file_existed: bool
    content: str


class WriteFileConfig(BaseToolConfig):
    permission: ToolPermission = ToolPermission.ASK
    max_write_bytes: int = 64_000
    create_parent_dirs: bool = True


class WriteFile(
    BaseTool[WriteFileArgs, WriteFileResult, WriteFileConfig, BaseToolState],
    ToolUIData[WriteFileArgs, WriteFileResult],
):
    description: ClassVar[str] = (
        "Create or overwrite a UTF-8 file. Fails if file exists unless 'overwrite=True'."
    )

    @classmethod
    def format_call_display(cls, args: WriteFileArgs) -> ToolCallDisplay:
        return ToolCallDisplay(
            summary=f"Writing {args.path}{' (overwrite)' if args.overwrite else ''}",
            content=args.content,
        )

    @classmethod
    def get_result_display(cls, event: ToolResultEvent) -> ToolResultDisplay:
        if isinstance(event.result, WriteFileResult):
            action = "Overwritten" if event.result.file_existed else "Created"
            return ToolResultDisplay(
                success=True, message=f"{action} {Path(event.result.path).name}"
            )

        return ToolResultDisplay(success=True, message="File written")

    @classmethod
    def get_status_text(cls) -> str:
        return "Writing file"

    def resolve_permission(self, args: WriteFileArgs) -> ToolPermission | None:
        return resolve_file_tool_permission(
            args.path,
            allowlist=self.config.allowlist,
            denylist=self.config.denylist,
            config_permission=self.config.permission,
        )

    @final
    async def run(
        self, args: WriteFileArgs, ctx: InvokeContext | None = None
    ) -> AsyncGenerator[ToolStreamEvent | WriteFileResult, None]:
        file_path, file_existed, content_bytes = self._prepare_and_validate_path(args)

        # Injection guard: scan content for suspicious patterns
        from drydock.core.tools.injection_guard import check_content_for_injection
        if warning := check_content_for_injection(args.content, args.path):
            import logging
            logging.getLogger(__name__).warning("write_file: %s", warning)

        await self._write_file(args, file_path)

        # Auto-verify syntax for Python files
        syntax_warning = ""
        if file_path.suffix == ".py":
            try:
                import ast
                ast.parse(args.content)
            except SyntaxError as e:
                syntax_warning = (
                    f"\n\n⚠ SYNTAX ERROR in {file_path.name} line {e.lineno}: {e.msg}"
                    f"\n  {e.text.rstrip() if e.text else ''}"
                    f"\n  Fix this before moving to the next file."
                )

        result = WriteFileResult(
            path=str(file_path),
            bytes_written=content_bytes,
            file_existed=file_existed,
            content=args.content,
        )
        if syntax_warning:
            result.content = syntax_warning  # Override content with the warning
        yield result

    _BINARY_EXTENSIONS = frozenset({
        ".pptx", ".xlsx", ".docx", ".pdf", ".zip", ".tar", ".gz", ".bz2",
        ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".ico", ".svg",
        ".mp3", ".mp4", ".wav", ".avi", ".mov",
        ".exe", ".dll", ".so", ".dylib", ".whl", ".egg",
        ".sqlite", ".db", ".pkl", ".pickle", ".npy", ".npz",
    })

    def _prepare_and_validate_path(self, args: WriteFileArgs) -> tuple[Path, bool, int]:
        if not args.path.strip():
            raise ToolError("Path cannot be empty")

        # Warn about binary file extensions
        ext = Path(args.path).suffix.lower()
        if ext in self._BINARY_EXTENSIONS:
            raise ToolError(
                f"write_file creates UTF-8 text files only. "
                f"'{ext}' is a binary format — use bash to run a Python script instead. "
                f"Example: write a .py script that uses the appropriate library "
                f"(python-pptx, openpyxl, Pillow, etc.), then run it with bash."
            )

        content_bytes = len(args.content.encode("utf-8"))
        if content_bytes > self.config.max_write_bytes:
            raise ToolError(
                f"Content exceeds {self.config.max_write_bytes} bytes limit"
            )

        file_path = Path(args.path).expanduser()
        if not file_path.is_absolute():
            file_path = Path.cwd() / file_path
        file_path = file_path.resolve()

        file_existed = file_path.exists()

        if file_existed and not args.overwrite:
            raise ToolError(
                f"File '{file_path}' exists. Set overwrite=True to replace."
            )

        if self.config.create_parent_dirs:
            file_path.parent.mkdir(parents=True, exist_ok=True)
        elif not file_path.parent.exists():
            raise ToolError(f"Parent directory does not exist: {file_path.parent}")

        return file_path, file_existed, content_bytes

    async def _write_file(self, args: WriteFileArgs, file_path: Path) -> None:
        import asyncio
        import concurrent.futures

        def _sync_write():
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(args.content)

        try:
            # Use a thread with a real timeout — anyio.fail_after doesn't
            # cancel thread-pool I/O, which is why writes hung for 45+ minutes
            loop = asyncio.get_running_loop()
            await asyncio.wait_for(
                loop.run_in_executor(None, _sync_write),
                timeout=10,  # 10 seconds is generous for a text file write
            )
        except asyncio.TimeoutError:
            raise ToolError(
                f"Timed out writing {file_path} after 10s. "
                f"The file may be locked by another process."
            )
        except Exception as e:
            raise ToolError(f"Error writing {file_path}: {e}") from e
