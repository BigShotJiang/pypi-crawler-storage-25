from __future__ import annotations

from typing import List
import torch
import numpy as np

from wisent.core.control.steering_methods.core.atoms import PerLayerBaseSteeringMethod
from wisent.core.control.steering_methods.configs.optimal import get_optimal
from wisent.core.utils.infra_tools.errors import InsufficientDataError
from wisent.core.utils import preferred_dtype
from wisent.core.utils.config_tools.constants import LOG_EPS

__all__ = [
    "OstrzeMethod",
]


def _require(name: str, kwargs: dict):
    """Raise ValueError if a required hyperparameter is missing."""
    if name not in kwargs:
        raise ValueError(
            f"Parameter '{name}' is required. "
            f"Run 'wisent optimize-steering auto' first, or pass it explicitly."
        )
    return kwargs[name]


class OstrzeMethod(PerLayerBaseSteeringMethod):
    """
    Ostrze-based steering using classifier decision boundary.
    
    Instead of computing mean(pos) - mean(neg) like CAA, this method trains
    a logistic regression classifier to separate positive from negative activations,
    then uses the classifier's weight vector (ostrze normal) as the steering vector.
    
    This works better when the geometry is orthogonal (each contrastive pair has
    a unique direction) rather than linear (all pairs share a common direction).
    In orthogonal geometry, CAA's mean difference cancels out to near-zero,
    while the classifier can still find a separating ostrze.
    """
    name = "ostrze"
    description = "Classifier-based steering using logistic regression decision boundary as steering vector."

    def train_for_layer(self, pos_list: List[torch.Tensor], neg_list: List[torch.Tensor]) -> torch.Tensor:
        """
        Train ostrze steering vector for a single layer using logistic regression.

        arguments:
            pos_list: List of positive activations (torch.Tensor) for this layer.
            neg_list: List of negative activations (torch.Tensor) for this layer.
            
        returns:
            torch.Tensor steering vector for the layer (classifier weights / ostrze normal).
        """
        if not pos_list or not neg_list:
            raise InsufficientDataError(reason="Both positive and negative lists must be non-empty.")
        
        pos = torch.stack([t.detach().to("cpu").float().reshape(-1) for t in pos_list], dim=0)
        neg = torch.stack([t.detach().to("cpu").float().reshape(-1) for t in neg_list], dim=0)
        
        pos_np = pos.numpy()
        neg_np = neg.numpy()
        
        X = np.vstack([pos_np, neg_np])
        y = np.array([1] * len(pos_np) + [0] * len(neg_np))
        
        # Train logistic regression classifier
        from sklearn.linear_model import LogisticRegression

        C = float(_require("C", self.kwargs))

        clf = LogisticRegression(C=C, solver="lbfgs")
        clf.fit(X, y)
        
        # Use classifier weights as steering vector
        v = torch.tensor(clf.coef_[0], dtype=preferred_dtype())
        
        if bool(self.kwargs.get("normalize", get_optimal("normalize"))):
            v = self._safe_l2_normalize(v)
        
        return v

    def _safe_l2_normalize(self, v: torch.Tensor, eps: float = LOG_EPS) -> torch.Tensor:
        if v.ndim != 1:
            v = v.reshape(-1)
        return v / (torch.linalg.norm(v) + eps)
