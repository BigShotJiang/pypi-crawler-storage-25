# signalfuse

Python client for the [SignalFuse](https://signalfuse.co) trading intelligence API.

Fused signals combining sentiment, macro regime, and market structure for crypto markets.

## Install

```bash
pip install signalfuse
```

## Quick start

```python
from signalfuse import SignalFuseClient

client = SignalFuseClient(credit_token="your-token")
signal = client.get_signal("BTC")
print(signal)
```

### Get a free trial token

```bash
curl -X POST https://api.signalfuse.co/v1/credits/trial \
  -H "Content-Type: application/json" \
  -d '{"wallet": "0xYourWalletAddress"}'
```

## Usage

### Sync client

```python
from signalfuse import SignalFuseClient

with SignalFuseClient(credit_token="your-token") as client:
    # Directional signal for a single asset
    signal = client.get_signal("ETH")

    # Batch signals for all supported assets
    signals = client.get_signals()

    # Sentiment breakdown
    sentiment = client.get_sentiment("BTC")

    # Macro risk regime
    regime = client.get_regime()

    # Strategy Arena
    leaderboard = client.get_arena_leaderboard()
    arena_signal = client.get_arena_signal("momentum_v1", "BTC")

    # Pricing info
    pricing = client.get_pricing()
```

### Async client

```python
import asyncio
from signalfuse import AsyncSignalFuseClient

async def main():
    async with AsyncSignalFuseClient(credit_token="your-token") as client:
        signal = await client.get_signal("BTC")
        regime = await client.get_regime()
        print(signal, regime)

asyncio.run(main())
```

## Authentication

SignalFuse supports two payment modes:

1. **Credit tokens** (simplest) -- get 25 free trial calls, then buy packs (500 calls / $4, 5000 calls / $30).
2. **x402 micropayments** -- automatic per-call USDC payments on Base. See [x402.org](https://x402.org) for details.

This SDK uses credit tokens. Pass your token when creating the client:

```python
client = SignalFuseClient(credit_token="sf_abc123...")
```

## API reference

| Method | Endpoint | Description |
|--------|----------|-------------|
| `get_signal(symbol)` | `GET /v1/signal/{symbol}` | Fused directional signal |
| `get_signals()` | `GET /v1/signal/batch` | Batch signals for all assets |
| `get_sentiment(symbol)` | `GET /v1/sentiment/{symbol}` | Sentiment breakdown |
| `get_regime()` | `GET /v1/regime` | Macro risk regime |
| `get_arena_leaderboard()` | `GET /v1/arena/leaderboard` | Strategy Arena leaderboard |
| `get_arena_signal(id, symbol)` | `GET /v1/arena/{id}/{symbol}` | Arena strategy signal |
| `get_pricing()` | `GET /v1/pricing` | Current API pricing |

## License

MIT
