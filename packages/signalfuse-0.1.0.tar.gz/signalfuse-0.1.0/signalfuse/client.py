"""Synchronous SignalFuse API client."""

from __future__ import annotations

import httpx


class SignalFuseError(Exception):
    """Base exception for SignalFuse API errors."""

    def __init__(self, status_code: int, detail: str):
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"HTTP {status_code}: {detail}")


class PaymentRequired(SignalFuseError):
    """Raised when credits are exhausted (HTTP 402)."""

    def __init__(self, detail: str = ""):
        msg = (
            "Payment required — your credit balance is empty. "
            "Buy more at POST /v1/credits/buy or use x402 pay-per-call. "
            "Details: https://signalfuse.co"
        )
        if detail:
            msg = f"{msg}\nServer response: {detail}"
        super().__init__(402, msg)


class SignalFuseClient:
    """Synchronous client for the SignalFuse trading intelligence API.

    Usage::

        from signalfuse import SignalFuseClient

        client = SignalFuseClient(credit_token="your-token")
        signal = client.get_signal("BTC")
        print(signal)
    """

    def __init__(
        self,
        credit_token: str | None = None,
        base_url: str = "https://api.signalfuse.co",
        timeout: float = 15.0,
    ):
        headers = {}
        if credit_token:
            headers["X-Credit-Token"] = credit_token
        self._client = httpx.Client(
            base_url=base_url, headers=headers, timeout=timeout
        )

    # -- core endpoints -------------------------------------------------------

    def get_signal(self, symbol: str) -> dict:
        """Fetch fused directional signal for a symbol."""
        return self._get(f"/v1/signal/{symbol.upper()}")

    def get_signals(self) -> dict:
        """Fetch batch signals for all supported symbols."""
        return self._get("/v1/signal/batch")

    def get_sentiment(self, symbol: str) -> dict:
        """Fetch sentiment breakdown for a symbol."""
        return self._get(f"/v1/sentiment/{symbol.upper()}")

    def get_regime(self) -> dict:
        """Fetch current macro risk regime."""
        return self._get("/v1/regime")

    # -- arena endpoints ------------------------------------------------------

    def get_arena_leaderboard(self) -> dict:
        """Fetch the Strategy Arena leaderboard."""
        return self._get("/v1/arena/leaderboard")

    def get_arena_signal(self, strategy_id: str, symbol: str) -> dict:
        """Fetch a signal from a specific arena strategy."""
        return self._get(f"/v1/arena/{strategy_id}/{symbol.upper()}")

    # -- meta endpoints -------------------------------------------------------

    def get_pricing(self) -> dict:
        """Fetch current API pricing info."""
        return self._get("/v1/pricing")

    # -- internals ------------------------------------------------------------

    def _get(self, path: str) -> dict:
        resp = self._client.get(path)
        if resp.status_code == 402:
            detail = ""
            try:
                detail = resp.text
            except Exception:
                pass
            raise PaymentRequired(detail)
        resp.raise_for_status()
        return resp.json()

    def close(self) -> None:
        """Close the underlying HTTP connection."""
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
