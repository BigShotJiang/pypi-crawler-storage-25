"""Asynchronous SignalFuse API client."""

from __future__ import annotations

import httpx

from signalfuse.client import PaymentRequired


class AsyncSignalFuseClient:
    """Async client for the SignalFuse trading intelligence API.

    Usage::

        import asyncio
        from signalfuse import AsyncSignalFuseClient

        async def main():
            async with AsyncSignalFuseClient(credit_token="your-token") as client:
                signal = await client.get_signal("BTC")
                print(signal)

        asyncio.run(main())
    """

    def __init__(
        self,
        credit_token: str | None = None,
        base_url: str = "https://api.signalfuse.co",
        timeout: float = 15.0,
    ):
        headers = {}
        if credit_token:
            headers["X-Credit-Token"] = credit_token
        self._client = httpx.AsyncClient(
            base_url=base_url, headers=headers, timeout=timeout
        )

    # -- core endpoints -------------------------------------------------------

    async def get_signal(self, symbol: str) -> dict:
        """Fetch fused directional signal for a symbol."""
        return await self._get(f"/v1/signal/{symbol.upper()}")

    async def get_signals(self) -> dict:
        """Fetch batch signals for all supported symbols."""
        return await self._get("/v1/signal/batch")

    async def get_sentiment(self, symbol: str) -> dict:
        """Fetch sentiment breakdown for a symbol."""
        return await self._get(f"/v1/sentiment/{symbol.upper()}")

    async def get_regime(self) -> dict:
        """Fetch current macro risk regime."""
        return await self._get("/v1/regime")

    # -- arena endpoints ------------------------------------------------------

    async def get_arena_leaderboard(self) -> dict:
        """Fetch the Strategy Arena leaderboard."""
        return await self._get("/v1/arena/leaderboard")

    async def get_arena_signal(self, strategy_id: str, symbol: str) -> dict:
        """Fetch a signal from a specific arena strategy."""
        return await self._get(f"/v1/arena/{strategy_id}/{symbol.upper()}")

    # -- meta endpoints -------------------------------------------------------

    async def get_pricing(self) -> dict:
        """Fetch current API pricing info."""
        return await self._get("/v1/pricing")

    # -- internals ------------------------------------------------------------

    async def _get(self, path: str) -> dict:
        resp = await self._client.get(path)
        if resp.status_code == 402:
            detail = ""
            try:
                detail = resp.text
            except Exception:
                pass
            raise PaymentRequired(detail)
        resp.raise_for_status()
        return resp.json()

    async def close(self) -> None:
        """Close the underlying HTTP connection."""
        await self._client.aclose()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()
