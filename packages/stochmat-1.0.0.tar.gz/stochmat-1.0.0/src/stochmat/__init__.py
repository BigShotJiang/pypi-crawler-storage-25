"""Stochmat - sparse stochastic matrix utilities.

This package provides efficient data structures and routines for working with
sparse stochastic (row-normalized) matrices, including:

- :class:`SparseStochMat`: a memory-efficient sparse stochastic matrix
  representation that avoids materializing identity rows.
- :class:`SparseAutocovMat`: a sparse representation of autocovariance-style
  matrices used in flow-stability community detection.
- In-place helpers (:func:`inplace_csr_matmul_diag`,
  :func:`inplace_diag_matmul_csr`, :func:`inplace_csr_row_normalize`) and
  matrix products (:func:`sparse_matmul`, :func:`sparse_gram_matrix`) that
  optionally dispatch to compiled (Cython / MKL) backends.

The package transparently falls back to pure-Python implementations when the
compiled extensions (``stochmat.fast``, ``stochmat._cython_sparse_stoch``) are
unavailable. The optional MKL acceleration (``sparse_dot_mkl``), in contrast,
is treated as a **hard runtime dependency once opted into**: if
``sparse_dot_mkl`` is installed but the underlying Intel MKL shared libraries
cannot be loaded, ``import stochmat`` will raise ``ImportError`` with an
actionable message rather than silently falling back. See the README section
"Optional: Intel MKL for better performance" for installation guidance.

Use :mod:`stochmat.backends` to inspect which backends are active in the
current process::

    >>> import stochmat
    >>> stochmat.backends.summary()
    {'cython_sparse_stoch': True, 'fast': True, 'mkl': False}
"""
try:
    # try to import version (provided by hatch (see pyproject.toml)
    from ._version import __version__
except ImportError:
    # Fallback if the package wasn't installed properly
    __version__ = "unknown"

from . import backends  # noqa: F401
from .sparse_stoch_mat import (  # noqa: F401
    inplace_csr_matmul_diag,
    inplace_csr_row_normalize,
    inplace_diag_matmul_csr,
    sparse_matmul,
    sparse_gram_matrix,
    SparseAutocovMat,
    SparseStochMat,
    fast,
)

# ---------------------------------------------------------------------------
# Backward-compatibility alias.
#
# Older releases exposed a module-level boolean ``USE_SPARSE_DOT_MKL`` that
# mirrored what is now :data:`stochmat.backends.mkl`. The public API was
# consolidated in :mod:`stochmat.backends` (single source of truth), but
# downstream packages -- notably ``flow_stability`` -- still import the
# legacy name. Re-export it here so existing consumers keep working.
#
# New code should use :data:`stochmat.backends.mkl` (or
# :func:`stochmat.backends.summary`) directly. This alias is frozen at
# import time, matching the behaviour of the underlying flag.
USE_SPARSE_DOT_MKL: bool = backends.mkl

__all__ = [
    "__version__",
    "backends",
    "inplace_csr_matmul_diag",
    "inplace_csr_row_normalize",
    "inplace_diag_matmul_csr",
    "sparse_matmul",
    "sparse_gram_matrix",
    "SparseAutocovMat",
    "SparseStochMat",
    "fast",
    "USE_SPARSE_DOT_MKL",
]
