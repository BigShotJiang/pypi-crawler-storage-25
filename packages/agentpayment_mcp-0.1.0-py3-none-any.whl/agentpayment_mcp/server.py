import os
import httpx
import asyncio
import json
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

API_BASE = os.getenv("APN_API_BASE", "https://agentpayment.network/api/v1")
API_KEY  = os.getenv("APN_API_KEY", "")

app = Server("agentpayment")


def _headers():
    return {"X-API-Key": API_KEY, "Content-Type": "application/json"}


async def _call(method: str, path: str, body: dict = None) -> dict:
    async with httpx.AsyncClient(timeout=30) as client:
        if method == "GET":
            r = await client.get(f"{API_BASE}{path}", headers=_headers())
        else:
            r = await client.post(f"{API_BASE}{path}", headers=_headers(), json=body or {})
        try:
            return r.json()
        except Exception:
            return {"error": "invalid_response", "status_code": r.status_code}


@app.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="check_balance",
            description="Check your current agent balance and plan details.",
            inputSchema={"type": "object", "properties": {}, "required": []}
        ),
        Tool(
            name="pay_agent",
            description="Make a direct payment to another agent.",
            inputSchema={
                "type": "object",
                "properties": {
                    "to_agent_id": {"type": "string", "description": "Agent ID to pay"},
                    "amount":      {"type": "number",  "description": "Amount in USD"},
                    "description": {"type": "string",  "description": "What this payment is for"},
                    "rail":        {"type": "string",  "description": "crypto, card, or bank", "default": "crypto"}
                },
                "required": ["to_agent_id", "amount"]
            }
        ),
        Tool(
            name="create_invoice",
            description="Invoice another agent for services. Auto-pays if they have a billing rule set.",
            inputSchema={
                "type": "object",
                "properties": {
                    "to_agent_id":   {"type": "string",  "description": "Agent ID to bill"},
                    "amount":        {"type": "number",   "description": "Invoice amount in USD"},
                    "description":   {"type": "string",   "description": "Service description"},
                    "payment_rail":  {"type": "string",   "description": "CRYPTO, CARD, or BANK", "default": "CRYPTO"},
                    "allow_partial": {"type": "boolean",  "description": "Allow partial payment if consumer limit is lower", "default": False},
                    "splits":        {"type": "array",    "description": "Optional split payouts to sub-agents", "items": {"type": "object"}}
                },
                "required": ["to_agent_id", "amount"]
            }
        ),
        Tool(
            name="set_billing_rule",
            description="Set an auto-pay rule for a trusted provider. Invoices up to max_invoice_amount will auto-pay.",
            inputSchema={
                "type": "object",
                "properties": {
                    "approved_provider_id": {"type": "string",  "description": "Provider agent ID to auto-pay"},
                    "max_invoice_amount":   {"type": "number",   "description": "Max invoice amount to auto-pay"},
                    "preferred_rail":       {"type": "string",   "description": "CRYPTO, CARD, or BANK", "default": "CRYPTO"},
                    "allow_partial":        {"type": "boolean",  "description": "Allow partial auto-payment", "default": False}
                },
                "required": ["approved_provider_id", "max_invoice_amount"]
            }
        ),
        Tool(
            name="get_invoice_status",
            description="Check the status of an invoice by ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "invoice_id": {"type": "string", "description": "Invoice ID to check"}
                },
                "required": ["invoice_id"]
            }
        ),
        Tool(
            name="pay_remaining",
            description="Pay the remaining balance on a PARTIAL_PAID invoice.",
            inputSchema={
                "type": "object",
                "properties": {
                    "invoice_id": {"type": "string", "description": "Invoice ID"}
                },
                "required": ["invoice_id"]
            }
        ),
        Tool(
            name="get_payment_history",
            description="Get recent invoices and payment history.",
            inputSchema={
                "type": "object",
                "properties": {
                    "limit": {"type": "integer", "description": "Number of records to return", "default": 10}
                },
                "required": []
            }
        ),
        Tool(
            name="list_billing_rules",
            description="List all active auto-pay billing rules for your agent.",
            inputSchema={"type": "object", "properties": {}, "required": []}
        )
    ]


@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    if name == "check_balance":
        result = await _call("GET", "/agents/me")

    elif name == "pay_agent":
        result = await _call("POST", "/payments/create", {
            "to_agent_id":  arguments["to_agent_id"],
            "amount":       arguments["amount"],
            "currency":     "USD",
            "description":  arguments.get("description", ""),
            "payment_rail": arguments.get("rail", "crypto").upper()
        })

    elif name == "create_invoice":
        body = {
            "to_agent_id":   arguments["to_agent_id"],
            "amount":        arguments["amount"],
            "currency":      "USD",
            "description":   arguments.get("description", ""),
            "payment_rail":  arguments.get("payment_rail", "CRYPTO"),
            "allow_partial": arguments.get("allow_partial", False),
        }
        if arguments.get("splits"):
            body["splits"] = arguments["splits"]
        result = await _call("POST", "/invoices", body)

    elif name == "set_billing_rule":
        result = await _call("POST", "/billing-rules", {
            "approved_provider_id": arguments["approved_provider_id"],
            "max_invoice_amount":   arguments["max_invoice_amount"],
            "preferred_rail":       arguments.get("preferred_rail", "CRYPTO"),
            "allow_partial":        arguments.get("allow_partial", False)
        })

    elif name == "get_invoice_status":
        result = await _call("GET", f"/invoices/{arguments['invoice_id']}")

    elif name == "pay_remaining":
        result = await _call("POST", f"/invoices/{arguments['invoice_id']}/pay-remaining", {})

    elif name == "get_payment_history":
        result = await _call("GET", f"/invoices?limit={arguments.get('limit', 10)}")

    elif name == "list_billing_rules":
        result = await _call("GET", "/billing-rules")

    else:
        result = {"error": "unknown_tool", "message": f"Tool {name} not found"}

    return [TextContent(type="text", text=json.dumps(result, indent=2))]


async def main():
    async with stdio_server() as (read_stream, write_stream):
        await app.run(read_stream, write_stream, app.create_initialization_options())


def run():
    asyncio.run(main())


if __name__ == "__main__":
    run()
