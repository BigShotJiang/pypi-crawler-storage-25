"""
Encryption utilities for context optimization files.

Uses a stdlib-only XOR stream cipher with SHA-256 derived key.
No external dependencies required — works everywhere.

Key derivation: sha256("{org_id}_{agent_id}_{task_id}")
Encryption: XOR with SHA-256 counter-mode key stream, base64-encoded output.
Symmetric: same function encrypts and decrypts the raw bytes.
"""

import base64
import hashlib


def derive_key(org_id: str, agent_id: str, task_id: str) -> bytes:
    """Derive a 256-bit encryption key from context identifiers."""
    material = f"{org_id}_{agent_id}_{task_id}"
    return hashlib.sha256(material.encode()).digest()


def _xor_stream(data: bytes, key: bytes) -> bytes:
    """XOR data with a SHA-256 counter-mode key stream."""
    key_stream = b""
    counter = 0
    while len(key_stream) < len(data):
        key_stream += hashlib.sha256(key + counter.to_bytes(4, "big")).digest()
        counter += 1
    return bytes(a ^ b for a, b in zip(data, key_stream[: len(data)]))


def encrypt(data: str, key: bytes) -> str:
    """Encrypt a string and return base64-encoded ciphertext.

    Base64 encoding ensures the output survives text-based file I/O
    (workspace file_read/file_write operate on UTF-8 strings).
    """
    encrypted = _xor_stream(data.encode("utf-8"), key)
    return base64.b64encode(encrypted).decode("ascii")


def decrypt(data: str, key: bytes) -> str:
    """Decrypt a base64-encoded ciphertext back to plaintext string."""
    encrypted = base64.b64decode(data.encode("ascii"))
    return _xor_stream(encrypted, key).decode("utf-8")


def is_context_optimization_file(path: str) -> bool:
    """Check if a path refers to a context optimization file.

    Matches both root-relative (/CONTEXT_OPTIMIZATION/uuid.xp) and
    absolute (/agent/data/CONTEXT_OPTIMIZATION/uuid.xp) paths.
    """
    return "CONTEXT_OPTIMIZATION/" in path and path.endswith(".xp")
