"""
Agno Context Optimizer for xpander.ai SDK.

4-layer context management pipeline:
  Layer 0 — Toon encoding: strip JSON verbosity from tool results (in tool hook, zero cost).
  Layer 1 — Microcompaction: offload large tool outputs to workspace, keep preview (zero LLM cost).
  Layer 2 — Auto-compaction: LLM summarisation when approaching token ceiling.
  Layer 3 — Manual compaction: agent-triggered on-demand compression with focus hint.
  Emergency — Near-ceiling safety net at 95% capacity, bypasses circuit breaker.

Thresholds based on industry best practices for agentic context management.
"""

import ast
import asyncio
import json
import re
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from types import SimpleNamespace
from typing import TYPE_CHECKING, Any, Dict, List, Literal, Optional, Type, Union

from pydantic import BaseModel

from loguru import logger

from agno.compression import CompressionManager
from agno.models.base import Model
from agno.models.message import Message
from agno.models.utils import get_model

from xpander_sdk.consts.api_routes import APIRoute
from xpander_sdk.core.context_optimizer.encryption import derive_key, encrypt
from xpander_sdk.core.xpander_api_client import APIClient
from xpander_sdk.utils.event_loop import run_sync

if TYPE_CHECKING:
    from agno.metrics import RunMetrics
    from xpander_sdk.modules.agents.sub_modules.agent import Agent
    from xpander_sdk.modules.tasks.sub_modules.task import Task


# ------------------------------------------------------------------ #
#  Constants
# ------------------------------------------------------------------ #

MAX_CONSECUTIVE_COMPACT_FAILURES = 3
# Emergency fires at 88% of context window — lower than the 95% used previously
# because by then the prompt + reserved-output overhead has often pushed the
# real request past the provider's hard limit, causing fatal overflows that
# only the external retry path could recover from. 88% leaves enough headroom
# for the compaction LLM call itself plus output reservation.
EMERGENCY_COMPACT_FRACTION = 0.88
SESSION_COMPACT_TIMEOUT = 120  # seconds — timeout for pre-retry compaction LLM call

AUTO_COMPACT_SYSTEM_PROMPT = (
    "You are a helpful AI assistant tasked with summarizing conversations."
)

AUTO_COMPACT_USER_PROMPT_TEMPLATE = """\
You are compacting an in-progress agent session into a binding state artifact that the
resuming agent will treat as AUTHORITATIVE. The resuming agent will be told NOT to
re-do anything you list under <work_completed>, NOT to relitigate decisions in
<decisions_made>, and NOT to re-fetch values listed in <data_gathered>. Be precise.

Here is the conversation history to summarize:
<conversation>
{conversation}
</conversation>

Output a single XML-tagged artifact with EXACTLY these sections in this order. No
markdown headings, no preamble, no closing remarks, no commentary outside tags.

<work_completed>
One bullet per concrete action that produced an output. Format each line as:
  - <verb> <target> — <observed result>
The <target> MUST be an exact identifier (file path, URL, ID, function name, command).
The <observed result> MUST be a verifiable outcome the agent can trust later.
Examples:
  - Edited /src/auth/middleware.py:42-58 — replaced expiry check `<` with `<=`, pytest tests/auth passed (47/0)
  - Created KB document doc_id=4f1e2... with 4 chunks from spec.pdf
  - Ran command `pytest tests/integration` — exit=0, 23 passed
Use one bullet per action. Be exhaustive — anything missing here is something the
resuming agent will redo.
</work_completed>

<decisions_made>
One line per choice or fact the agent has committed to. The resuming agent will NOT
relitigate these. Examples:
  - chose JWT over session cookies (user confirmed in turn 3)
  - target Python version is 3.9, not 3.11 (per setup.py)
Only include decisions that affect future actions.
</decisions_made>

<data_gathered>
Verbatim opaque values, IDs, schemas, snippets the agent retrieved that may be needed
again. The resuming agent will look here BEFORE re-fetching. Format:
  - <kind> <identifier>: <value or summary> (source: <where it came from>)
Examples:
  - org id: 7f1c... (source: GET /orgs/me)
  - file /src/config.py lines 1-20: <verbatim snippet> (source: file-read)
Preserve identifiers EXACTLY as written. Do not shorten, normalize, or reconstruct.
</data_gathered>

<user_requests_verbatim>
Every user message verbatim, oldest first, one per line prefixed with the turn marker.
Critical — non-negotiable preservation. Do NOT paraphrase. Do NOT attribute assistant
suggestions as user preferences.
</user_requests_verbatim>

<open_questions>
Anything the agent asked the user that is unanswered, OR ambiguities the agent flagged
but did not resolve. One per line.
</open_questions>

<current_focus>
One short paragraph: what the agent was doing in the LAST 1-2 turns of <conversation>,
with a direct quote from the most recent assistant message. Do NOT speculate forward.
</current_focus>

<next_action>
Single concrete next step: tool to call OR file to edit OR question to ask. MUST be
verbatim from the most recent plan/user direction in <conversation>. Do NOT invent
steps the user did not request and the plan does not require.
</next_action>
{plan_section}
HARD RULES (violations make the artifact useless to the resuming agent):
- MUST preserve all opaque identifiers verbatim (UUIDs, hashes, IDs, tokens, hostnames,
  IPs, ports, URLs, file paths, line numbers, version numbers).
- MUST NOT attribute assistant suggestions as user preferences — only what the user
  actually said or confirmed.
- MUST NOT include speculative next steps beyond what user asked or plan requires.
- MUST output XML-tagged sections IN ORDER. No markdown headings. No prose outside tags.
- MUST treat work in <work_completed> as DONE; the resuming agent will NOT redo it.
- MUST NOT use any tools. Respond with ONLY the XML artifact.
{custom_instructions_section}"""

CONTINUATION_MESSAGE_TEMPLATE = """\
<session_resume>
This session resumed after context compaction. The state below is AUTHORITATIVE
and contains ALL data, findings, and work products from the earlier session.

<state>
{summary}
</state>

<binding_rules>
1. Treat <work_completed> as DONE. Do NOT re-run, re-verify, re-fetch, or re-edit
   anything listed there unless the user explicitly asks you to. Trust the observed
   results recorded inline.
2. Treat <data_gathered> as available. Do NOT re-fetch identifiers, IDs, schemas, or
   snippets listed there. If you need a value, look in <state> first.
3. Treat <decisions_made> as final. Do NOT relitigate or propose alternatives.
4. The plan section below shows completed tasks. Continue from <next_action>.
5. Do NOT ask the user any questions about prior context — it is in <state>.
6. Continue execution. Do NOT stop until the plan is complete.
</binding_rules>
{backup_pointer}
</session_resume>
"""


def build_pre_retry_focus_instructions(
    uncompleted_tasks: List[Any],
    retry_count: int,
) -> str:
    """Build the ``custom_instructions`` payload for pre-retry L2 compaction.

    Shared by the SDK retry path (``events_module.handle_task_execution_request``)
    and the cloud retry path (xpander-mono ``agent_executor.execute``) so both
    sites bias the compaction LLM identically toward remaining plan tasks /
    next-action without re-implementing the prompt.

    Tag names (``<next_action>`` / ``<work_completed>``) intentionally mirror
    ``AUTO_COMPACT_USER_PROMPT_TEMPLATE`` — keep them in sync.

    Args:
        uncompleted_tasks: Items from ``PlanFollowingStatus.uncompleted_tasks``
            (each must expose ``.title`` and ``.id``). Empty list → returns
            "" so the template's ``Additional focus:`` section is suppressed.
        retry_count: Current zero-based retry count from the retry loop.
            Rendered as ``retry attempt {retry_count + 2}`` to match the
            user-facing 1-based retry numbering used elsewhere.

    Returns:
        The guidance string, or "" when there are no uncompleted tasks.
    """
    if not uncompleted_tasks:
        return ""
    first = uncompleted_tasks[0]
    remaining = "; ".join(
        f"{t.title} (ID: {t.id})" for t in uncompleted_tasks
    )
    return (
        f"This is a PRE-RETRY compaction (retry attempt {retry_count + 2}). "
        f"Populate <next_action> with the exact next step for the first "
        f'uncompleted plan task: "{first.title}" (ID: {first.id}). '
        f"Remaining uncompleted plan tasks: {remaining}. "
        f"Under <work_completed> include ONLY tasks the agent ACTUALLY "
        f"finished — never mark unfinished plan items as completed. "
        f"Preserve verbatim user request(s) and any exact data, IDs, paths, "
        f"or tool outputs the remaining tasks will need."
    )


# Map-reduce compaction prompts. Used when the conversation is too large for a
# single LLM call and we need to summarise it in chunks first, then combine.
PARTIAL_COMPACT_SYSTEM_PROMPT = (
    "You are a helpful AI assistant producing a dense partial digest of a long "
    "conversation. Your digest will later be combined with other partial digests "
    "to build a full working-state summary."
)

PARTIAL_COMPACT_USER_PROMPT_TEMPLATE = """\
You are producing a PARTIAL digest of CHUNK {chunk_index} of {total_chunks} of a longer
conversation. This digest will be combined with other partial digests into a final
state-capture artifact (the same XML-tagged contract the resuming agent will rely on).

To make the reduce step trivial, structure your output using the SAME XML tags the final
artifact uses, but only fill in the parts represented in this chunk. Leave a tag empty
when this chunk has no content for it.

<work_completed>
One bullet per concrete action that produced an output. Format: "<verb> <target> — <observed result>".
Target MUST be an exact identifier (file path, URL, ID, function name, command).
</work_completed>

<decisions_made>
One line per choice or fact the agent committed to in this chunk.
</decisions_made>

<data_gathered>
Verbatim opaque values, IDs, schemas, snippets the agent retrieved in this chunk.
Format: "<kind> <identifier>: <value or summary> (source: <where>)".
</data_gathered>

<user_requests_verbatim>
Every user message in this chunk verbatim. Do NOT paraphrase.
</user_requests_verbatim>

<open_questions>
Anything the agent asked the user that is unanswered, or unresolved ambiguities.
</open_questions>

<chunk_local_focus>
One short paragraph: what the agent was doing at the END of this chunk.
(The final reduce step will only use the LAST chunk's focus to populate <current_focus>.)
</chunk_local_focus>

PRESERVE all opaque identifiers exactly: UUIDs, hashes, IDs, paths, URLs, version numbers.
Do NOT attribute assistant suggestions as user preferences.
Do NOT use any tools. Respond with ONLY the XML tags.

Here is the chunk to digest:
<conversation_chunk index="{chunk_index}" total="{total_chunks}">
{conversation}
</conversation_chunk>
"""


# ------------------------------------------------------------------ #
#  Context-overflow error detection + provider max parsing
# ------------------------------------------------------------------ #

# Regex patterns that signal the LLM rejected the prompt because it exceeded
# the model context window. Covers Anthropic, OpenAI, vLLM / OpenAI-compat,
# Bedrock Claude, and Gemini. Matched against ``str(exc).lower()``.
_CONTEXT_OVERFLOW_PATTERNS = [
    re.compile(r"prompt is too long", re.IGNORECASE),
    re.compile(r"context_length_exceeded", re.IGNORECASE),
    re.compile(r"maximum context length", re.IGNORECASE),
    re.compile(r"input length exceeds the context length", re.IGNORECASE),
    re.compile(r"input is too long for requested model", re.IGNORECASE),
    re.compile(r"input_length and max_tokens exceed context limit", re.IGNORECASE),
    re.compile(r"model's context length is only", re.IGNORECASE),
    re.compile(r"request_too_large", re.IGNORECASE),
]

# Patterns that extract the provider-reported maximum input tokens from the
# error message. Order matters: first match wins.
_MAX_TOKEN_PATTERNS = [
    # Anthropic: "prompt is too long: 6432565 tokens > 1000000 maximum"
    re.compile(r">\s*(\d{3,})\s*maximum", re.IGNORECASE),
    # Anthropic Bedrock: "input_length and max_tokens exceed context limit: A+B > 2000000"
    re.compile(r"context\s+limit[:\s]+[^>]*>\s*(\d{3,})", re.IGNORECASE),
    # OpenAI: "This model's maximum context length is 16385 tokens"
    re.compile(r"maximum context length is\s*(\d{3,})\s*tokens?", re.IGNORECASE),
    # vLLM-style: "model's context length is only 131072 tokens"
    re.compile(r"context length is only\s*(\d{3,})\s*tokens?", re.IGNORECASE),
]


def _is_context_overflow_error(exc: BaseException) -> bool:
    """Return True when *exc* looks like a provider context-window overflow."""
    try:
        text = str(exc)
    except Exception:
        return False
    if not text:
        return False
    for pat in _CONTEXT_OVERFLOW_PATTERNS:
        if pat.search(text):
            return True
    return False


def _parse_provider_max_tokens(exc: BaseException) -> Optional[int]:
    """Extract the provider-reported max input tokens from *exc*, if present."""
    try:
        text = str(exc)
    except Exception:
        return None
    if not text:
        return None
    for pat in _MAX_TOKEN_PATTERNS:
        m = pat.search(text)
        if m:
            try:
                return int(m.group(1))
            except Exception:
                continue
    return None


# ------------------------------------------------------------------ #
#  Message chunking utility (map phase input)
# ------------------------------------------------------------------ #


def _message_char_size(message: Any) -> int:
    """Return the approximate size of a single message in characters.

    Uses ``message.to_dict()`` when available so role, tool-call metadata and
    other structured fields are accounted for; falls back to ``str(message)``.
    """
    try:
        if hasattr(message, "to_dict"):
            return len(json.dumps(message.to_dict(), default=str, ensure_ascii=False))
    except Exception:
        pass
    try:
        return len(str(message))
    except Exception:
        return 0


def _split_oversized_message_text(text: str, char_budget: int) -> List[str]:
    """Split a single message's text into chunks that fit in *char_budget*.

    Attempts paragraph-level splits first, then line-level, then hard
    character slicing. Preserves ordering.
    """
    if char_budget <= 0:
        return [text]
    if len(text) <= char_budget:
        return [text]

    # Try paragraph split first.
    pieces: List[str] = []
    buf: List[str] = []
    buf_len = 0
    for para in text.split("\n\n"):
        piece_len = len(para) + 2
        if buf and buf_len + piece_len > char_budget:
            pieces.append("\n\n".join(buf))
            buf = [para]
            buf_len = piece_len
        elif piece_len > char_budget:
            # Paragraph itself too large — hard-slice.
            if buf:
                pieces.append("\n\n".join(buf))
                buf = []
                buf_len = 0
            for i in range(0, len(para), char_budget):
                pieces.append(para[i : i + char_budget])
        else:
            buf.append(para)
            buf_len += piece_len
    if buf:
        pieces.append("\n\n".join(buf))
    return pieces


def _split_messages_into_chunks(
    messages: List[Any],
    char_budget: int,
) -> List[List[Any]]:
    """Pack *messages* into ordered chunks whose total char size stays below
    *char_budget*. Never splits across multiple messages in the same slot.

    When a single message is itself larger than *char_budget*, the message is
    split into multiple synthetic messages (``SimpleNamespace``) at paragraph
    boundaries so ordering is preserved.
    """
    if char_budget <= 0 or not messages:
        return [list(messages)] if messages else []

    chunks: List[List[Any]] = []
    current: List[Any] = []
    current_size = 0

    def _flush():
        nonlocal current, current_size
        if current:
            chunks.append(current)
            current = []
            current_size = 0

    for msg in messages:
        size = _message_char_size(msg)

        if size > char_budget:
            # Flush what we have, then split the oversized message.
            _flush()
            text = str(getattr(msg, "content", "") or "")
            for piece_idx, piece in enumerate(
                _split_oversized_message_text(text, char_budget)
            ):
                synthetic = SimpleNamespace(
                    role=getattr(msg, "role", "user"),
                    content=piece,
                    tool_name=getattr(msg, "tool_name", None),
                    tool_call_id=getattr(msg, "tool_call_id", None),
                    _is_split_fragment=True,
                    _fragment_index=piece_idx,
                    to_dict=(
                        lambda p=piece, r=getattr(msg, "role", "user"): {
                            "role": r,
                            "content": p,
                        }
                    ),
                )
                chunks.append([synthetic])
            continue

        if current and current_size + size > char_budget:
            _flush()
        current.append(msg)
        current_size += size

    _flush()
    return chunks


# ------------------------------------------------------------------ #
#  ToolInvocationResult repr unwrapping helpers
# ------------------------------------------------------------------ #

_TOOL_INVOCATION_REPR_PREFIX = "tool_id="


def _extract_balanced_value(content: str, start: int) -> Optional[str]:
    """Extract a Python-literal value starting at ``content[start]``,
    balancing braces/brackets and tracking quoted strings.

    Supports dicts (``{...}``), lists (``[...]``), and quoted strings.
    Returns the substring for the value, or ``None`` if it cannot be parsed.
    """
    if start >= len(content):
        return None
    ch = content[start]
    if ch in ("'", '"'):
        end = start + 1
        escape = False
        while end < len(content):
            c = content[end]
            if escape:
                escape = False
            elif c == "\\":
                escape = True
            elif c == ch:
                return content[start : end + 1]
            end += 1
        return None
    if ch in ("{", "["):
        open_char = ch
        close_char = "}" if ch == "{" else "]"
        depth = 0
        in_string = False
        string_char = None
        escape = False
        end = start
        while end < len(content):
            c = content[end]
            if escape:
                escape = False
                end += 1
                continue
            if c == "\\":
                escape = True
                end += 1
                continue
            if in_string:
                if c == string_char:
                    in_string = False
            elif c in ("'", '"'):
                in_string = True
                string_char = c
            elif c == open_char:
                depth += 1
            elif c == close_char:
                depth -= 1
                if depth == 0:
                    return content[start : end + 1]
            end += 1
        return None
    # Bare value: read until next `  <field>=` marker or end of string.
    tail = content[start:]
    m = re.search(r"\s\w+=", tail)
    return (tail[: m.start()] if m else tail).strip()


def _extract_repr_field(content: str, field_name: str) -> Any:
    """Pull a single field value out of a pydantic ``repr()`` string.

    Tries JSON first, then ``ast.literal_eval``. Returns the raw value
    string on parse failure, or ``None`` when the field isn't present.
    """
    if not isinstance(content, str):
        return None
    marker = f" {field_name}="
    if content.startswith(f"{field_name}="):
        start = len(field_name) + 1
    else:
        idx = content.find(marker)
        if idx == -1:
            return None
        start = idx + len(marker)
    raw = _extract_balanced_value(content, start)
    if raw is None:
        return None
    try:
        return json.loads(raw)
    except Exception:
        pass
    try:
        return ast.literal_eval(raw)
    except Exception:
        return raw


def unwrap_tool_result_content(content: Any) -> str:
    """Return a clean serialized form of a tool message content.

    If *content* looks like the ``repr()`` of a ``ToolInvocationResult``
    (starts with ``tool_id=``), extract just the ``result`` field and
    JSON-serialize it. This strips the pydantic wrapper (tool_id, task_id,
    payload, status_code, is_success, ...) so the workspace and preview carry
    only the actual tool output.

    For any other content type the value is returned as its string form.
    """
    if content is None:
        return ""
    if not isinstance(content, str):
        # Pydantic models, dicts, etc. — prefer a JSON serialization when
        # possible; fall back to ``str()``.
        try:
            return json.dumps(content, default=str, ensure_ascii=False)
        except Exception:
            return str(content)
    stripped = content.lstrip()
    if not stripped.startswith(_TOOL_INVOCATION_REPR_PREFIX):
        return content
    result = _extract_repr_field(content, "result")
    if result is None:
        return content
    if isinstance(result, str):
        return result
    try:
        return json.dumps(result, default=str, ensure_ascii=False)
    except Exception:
        return str(result)


@dataclass
class CompactRetryResult:
    """Result of a pre-retry session compaction."""

    compacted: bool = False
    input_tokens: int = 0
    output_tokens: int = 0
    total_tokens: int = 0
    backup_path: Optional[str] = None


@dataclass
class XPanderContextOptimizer(CompressionManager):
    """4-layer context optimizer for xpander.ai agents (+ emergency).

    Plugs into agno's ``compression_manager`` slot but implements its own
    optimisation logic instead of relying on agno's built-in patterns.

    Layers:
        0 — Toon encoding (in tool hook, zero cost)
        1 — Microcompaction (workspace offload + preview)
        2 — Auto-compaction (LLM summarisation, replaces context window)
        3 — Manual compaction (agent-triggered via xpcompact_context)
        Emergency — 95% capacity safety net

    Attributes:
        agent: The xpander Agent instance (provides config + IDs for workspace calls).
        task: The xpander Task instance (provides task ID for storage paths;
              will be used in Layers 2/3 for plan following).
        min_content_length: Skip processing for tool results shorter than this.
        max_content_length: Offload threshold — results larger than this are
            saved to workspace and replaced with a preview.
        preview_length: Characters kept inline as preview for offloaded results.
        context_window: Model context window size in tokens.
        reserved_for_output: Tokens reserved for LLM output.
        buffer_tokens: Safety buffer before auto-compact threshold.
    """

    # xpander context (use Any to avoid dataclass/pydantic conflict)
    agent: Any = None
    task: Any = None

    # Layer 1 settings
    min_content_length: int = 100
    max_content_length: int = 8_000
    preview_length: int = 2_000

    # Layer 2 settings
    context_window: int = 200_000
    reserved_for_output: int = 20_000
    buffer_tokens: int = 13_000

    # Map-reduce chunked-compaction settings.
    # When None, defaults to ``int(context_window * 0.9)`` in ``__post_init__``.
    chunked_compact_threshold: Optional[int] = None
    max_chunked_recursion_depth: int = 3

    # Internal state (not dataclass init fields)
    _auto_compact_consecutive_failures: int = field(default=0, init=False, repr=False)
    _compaction_attempt: int = field(default=0, init=False, repr=False)

    # Cached provider-reported max input tokens (populated on first overflow
    # error). Used to size chunk budgets elastically for the current model.
    _provider_max_tokens: Optional[int] = field(default=None, init=False, repr=False)

    # Layer 3 flags (set by tool hook, consumed by acompress)
    compact_requested: bool = field(default=False, init=False, repr=False)
    compact_focus: str = field(default="", init=False, repr=False)

    # Tool-call IDs that were already offloaded inline by the tool hook.
    # Used by the fallback layer_1_microcompact loop to avoid re-offloading
    # a message the hook already processed.
    _inline_offloaded_tool_call_ids: set = field(
        default_factory=set, init=False, repr=False
    )

    def __post_init__(self):
        self.compress_tool_results = True
        super().__post_init__()
        if self.chunked_compact_threshold is None:
            self.chunked_compact_threshold = int(self.context_window * 0.9)
        logger.info(
            f"[context-optimizer] initialized "
            f"(max_content={self.max_content_length}, preview={self.preview_length}, "
            f"context_window={self.context_window}, threshold={self._auto_compact_threshold}, "
            f"chunked_threshold={self.chunked_compact_threshold})"
        )

    # ------------------------------------------------------------------ #
    #  Token estimation
    # ------------------------------------------------------------------ #

    @staticmethod
    def _estimate_tokens(messages: List[Message]) -> int:
        """Rough token count: ~4 chars per token, with 1.2x safety margin.

        The chars/4 heuristic underestimates real token counts because it
        misses multi-byte characters, special tokens, and structured message
        overhead.  The 20% padding aligns the trigger with ~80% of the
        context window — the threshold used by production agentic systems.
        """
        raw = len(json.dumps([m.to_dict() for m in messages], default=str)) // 4
        return int(raw * 1.2)

    @property
    def _auto_compact_threshold(self) -> int:
        return self.context_window - self.reserved_for_output - self.buffer_tokens

    # ------------------------------------------------------------------ #
    #  Workspace storage
    # ------------------------------------------------------------------ #

    async def _save_to_workspace(self, content: str) -> Optional[str]:
        """Persist full tool output to the agent’s workspace filesystem.

        Returns the workspace path on success, or None on failure.
        """
        if not self.agent or not self.task:
            logger.warning(
                "[context-optimizer] workspace save skipped: agent or task not set"
            )
            return None

        file_id = str(uuid.uuid4())
        path = f"CONTEXT_OPTIMIZATION/{file_id}.xp"

        try:
            # Encrypt content before writing to workspace
            key = derive_key(
                org_id=self.agent.configuration.organization_id,
                agent_id=self.agent.id,
                task_id=self.task.id,
            )
            encrypted_content = encrypt(content, key)

            client = APIClient(configuration=self.agent.configuration)
            await client.make_request(
                path=str(APIRoute.WorkspaceToolInvoke).format(
                    agent_id=self.agent.id,
                    tool_name="file_write",
                ),
                method="POST",
                payload={"path": path, "content": encrypted_content},
            )
            logger.info(
                f"[context-optimizer] saved encrypted tool result to workspace: {path} ({len(content):,} chars)"
            )
            return path
        except Exception as e:
            logger.warning(f"[context-optimizer] workspace save failed: {e}")
            return None

    # ------------------------------------------------------------------ #
    #  Agno interface — should_compress
    # ------------------------------------------------------------------ #

    async def ashould_compress(
        self,
        messages: List[Message],
        tools: Optional[List] = None,
        model: Optional[Model] = None,
        response_format: Optional[Union[Dict, Type[BaseModel]]] = None,
    ) -> bool:
        """Always returns True — Layer 1 runs every turn."""
        return True

    def should_compress(
        self,
        messages: List[Message],
        tools: Optional[List] = None,
        model: Optional[Model] = None,
        response_format: Optional[Union[Dict, Type[BaseModel]]] = None,
    ) -> bool:
        return True

    # ------------------------------------------------------------------ #
    #  Agno interface — compress  (orchestrates all layers)
    # ------------------------------------------------------------------ #

    @property
    def _emergency_compact_threshold(self) -> int:
        return int(self.context_window * EMERGENCY_COMPACT_FRACTION)

    def _should_emergency_compact(self, messages: List[Message]) -> bool:
        """Return True when context is near the absolute ceiling (95%).

        Bypasses the circuit breaker — this is a last-resort safety net.
        """
        return self._estimate_tokens(messages) >= self._emergency_compact_threshold

    async def acompress(
        self,
        messages: List[Message],
        run_metrics: Optional["RunMetrics"] = None,
    ) -> None:
        """Run the optimisation pipeline (called by agno every turn)."""
        # Layer 1: always runs — offload large tool results to workspace
        await self.layer_1_microcompact(messages)

        # Layer 3: agent-requested manual compaction (takes priority)
        if self.compact_requested:
            focus = self.compact_focus
            self.compact_requested = False
            self.compact_focus = ""
            estimated = self._estimate_tokens(messages)
            logger.info(
                f"[context-optimizer] layer 3 triggered: "
                f"manual compact requested (est_tokens={estimated:,}, focus={focus!r})"
            )
            await self.layer_2_auto_compact(
                messages,
                run_metrics,
                custom_instructions=focus,
                trigger="manual",
            )
            return

        # Layer 2: auto-compact at normal threshold (167K)
        if self._should_auto_compact(messages):
            estimated = self._estimate_tokens(messages)
            logger.info(
                f"[context-optimizer] layer 2 triggered: "
                f"{estimated:,} tokens >= {self._auto_compact_threshold:,} threshold"
            )
            await self.layer_2_auto_compact(messages, run_metrics, trigger="auto")
            return

        # Emergency: near-ceiling safety net at 95% — bypasses circuit breaker
        if self._should_emergency_compact(messages):
            estimated = self._estimate_tokens(messages)
            pct = estimated / self.context_window * 100
            logger.warning(
                f"[context-optimizer] emergency compact: context at {pct:.0f}% capacity "
                f"({estimated:,} tokens >= {self._emergency_compact_threshold:,}), "
                f"compacting to prevent overflow"
            )
            await self.layer_2_auto_compact(
                messages,
                run_metrics,
                custom_instructions="EMERGENCY: context is near overflow. Focus on preserving the most recent work state, pending tasks, and key decisions.",
                trigger="emergency",
            )

    def compress(
        self,
        messages: List[Message],
        run_metrics: Optional["RunMetrics"] = None,
    ) -> None:
        run_sync(self.acompress(messages, run_metrics=run_metrics))

    # ------------------------------------------------------------------ #
    #  Agno interface — _compress_tool_result  (unused, kept for compat)
    # ------------------------------------------------------------------ #

    async def _acompress_tool_result(
        self,
        tool_result: Message,
        run_metrics: Optional["RunMetrics"] = None,
    ) -> Optional[str]:
        """Not used directly — Layer 1 handles compression in bulk."""
        return None

    def _compress_tool_result(
        self,
        tool_result: Message,
        run_metrics: Optional["RunMetrics"] = None,
    ) -> Optional[str]:
        return None

    # ================================================================== #
    #  Layer 1 — Microcompaction (workspace offload + preview)
    # ================================================================== #

    # Tool names for which L1 must NOT offload (reasoning + xp-prefixed
    # internal tools, except xpworkspace-bash whose output can be huge).
    @staticmethod
    def _l1_skip_tool(tool_name: Optional[str]) -> bool:
        if not tool_name:
            return False
        if tool_name in ("think", "analyze"):
            return True
        if tool_name.startswith("xp") and tool_name != "xpworkspace-bash":
            return True
        return False

    def _build_offload_preview(
        self, content: str, workspace_path: str, original_len: int
    ) -> str:
        # Derive the context_id from the workspace path: CONTEXT_OPTIMIZATION/{context_id}.xp
        context_id = workspace_path.rsplit("/", 1)[-1]
        if context_id.endswith(".xp"):
            context_id = context_id[:-3]
        return (
            f"{content[: self.preview_length]}\n\n"
            f"[TRUNCATED OUTPUT - {original_len:,} chars total, showing first {self.preview_length:,}]\n"
            f"Full result saved (encrypted) to: {workspace_path}\n"
            f'To retrieve the full output, call xpworkspace-context-retrieve with context_id="{context_id}". '
            f"The file is encrypted and scoped to the current task — do not use xpworkspace-bash or xpworkspace-file-read. "
            f"Do this if the preview above is insufficient for your current task."
        )

    async def maybe_offload_content(
        self,
        content: Any,
        tool_name: Optional[str],
    ) -> tuple:
        """Offload *content* to the workspace when it exceeds ``max_content_length``.

        Returns ``(replacement, workspace_path)`` when an offload happens,
        where ``replacement`` is the preview + retrieval-pointer string
        that should be used as the visible tool output. Returns
        ``(None, None)`` when the content is skipped, too small, or
        between min/max (passthrough). Also updates ``self.stats`` so
        both the inline (tool-hook) and fallback paths share counters.
        """
        if self._l1_skip_tool(tool_name):
            return None, None
        # Normalize to clean JSON string (strips ToolInvocationResult repr).
        clean = unwrap_tool_result_content(content)
        if not isinstance(clean, str) or len(clean) <= self.min_content_length:
            return None, None
        original_len = len(clean)
        if original_len <= self.max_content_length:
            # Between min and max — passthrough (caller decides whether to
            # mark the message as processed). Count as a passthrough.
            self.stats["tool_results_compressed"] = (
                self.stats.get("tool_results_compressed", 0) + 1
            )
            self.stats["original_size"] = (
                self.stats.get("original_size", 0) + original_len
            )
            self.stats["compressed_size"] = (
                self.stats.get("compressed_size", 0) + original_len
            )
            return None, None

        workspace_path = await self._save_to_workspace(clean)
        if not workspace_path:
            # Workspace unavailable — leave the content unchanged.
            return None, None

        replacement = self._build_offload_preview(
            content=clean,
            workspace_path=workspace_path,
            original_len=original_len,
        )
        compressed_len = len(replacement)
        self.stats["tool_results_compressed"] = (
            self.stats.get("tool_results_compressed", 0) + 1
        )
        self.stats["original_size"] = self.stats.get("original_size", 0) + original_len
        self.stats["compressed_size"] = (
            self.stats.get("compressed_size", 0) + compressed_len
        )
        logger.info(
            f"[context-optimizer] layer 1: offloaded '{tool_name or 'unknown'}' to workspace "
            f"({original_len:,} -> {compressed_len:,} chars, path={workspace_path})"
        )
        return replacement, workspace_path

    async def layer_1_microcompact(self, messages: List[Message]) -> None:
        """Fallback offload loop for messages the tool hook didn't process.

        With the inline offload from the agno tool hook, fresh tool results
        are already truncated by the time they reach this loop. This loop
        still runs every turn so messages arriving from session history /
        resumed runs (where the hook never fired) are offloaded too.
        """
        offloaded_count = 0
        passthrough_count = 0
        skipped_count = 0
        turn_saved_chars = 0

        for msg in messages:
            if msg.role != "tool":
                continue
            if msg.compressed_content is not None:
                skipped_count += 1
                continue
            # Hook already offloaded this message — do not re-process.
            tool_call_id = getattr(msg, "tool_call_id", None)
            if tool_call_id and tool_call_id in self._inline_offloaded_tool_call_ids:
                skipped_count += 1
                continue
            if self._l1_skip_tool(msg.tool_name):
                skipped_count += 1
                continue

            # Strip the pydantic ``ToolInvocationResult`` wrapper so only the
            # actual tool result (JSON) is saved to the workspace and previewed
            # to the LLM. Non-xpander tool results pass through unchanged.
            content = unwrap_tool_result_content(msg.content)
            if len(content) <= self.min_content_length:
                skipped_count += 1
                continue

            original_len = len(content)
            tool_name = msg.tool_name or "unknown"

            replacement, workspace_path = await self.maybe_offload_content(
                content=content,
                tool_name=tool_name,
            )
            if replacement is not None:
                msg.compressed_content = replacement
                compressed_len = len(replacement)
                saved = original_len - compressed_len
                turn_saved_chars += saved
                offloaded_count += 1
                logger.info(
                    f"[context-optimizer] layer 1 (fallback): offloaded '{tool_name}' "
                    f"({original_len:,} -> {compressed_len:,} chars, saved {saved:,} chars, "
                    f"path={workspace_path})"
                )
                continue

            if original_len > self.max_content_length:
                # Workspace save failed — leave the content alone.
                logger.warning(
                    f"[context-optimizer] layer 1 (fallback): keeping full result for "
                    f"'{tool_name}' ({original_len:,} chars) — workspace unavailable"
                )
                continue

            # Between min and max — mark as processed so we don't revisit.
            msg.compressed_content = content
            passthrough_count += 1
            logger.debug(
                f"[context-optimizer] layer 1 (fallback): passthrough '{tool_name}' "
                f"({original_len:,} chars, below {self.max_content_length:,} threshold)"
            )

        total_processed = offloaded_count + passthrough_count
        if total_processed > 0 or skipped_count > 0:
            total_original = self.stats.get("original_size", 0)
            total_compressed = self.stats.get("compressed_size", 0)
            total_saved = total_original - total_compressed
            savings_pct = (
                (total_saved / total_original * 100) if total_original > 0 else 0
            )
            logger.info(
                f"[context-optimizer] layer 1 summary: "
                f"offloaded={offloaded_count}, passthrough={passthrough_count}, "
                f"already_processed={skipped_count} | "
                f"this turn saved {turn_saved_chars:,} chars | "
                f"cumulative: {total_original:,} -> {total_compressed:,} chars "
                f"({savings_pct:.1f}% savings)"
            )

    # ================================================================== #
    #  Layer 2 — Auto-compaction (LLM summarisation)
    # ================================================================== #

    def _should_auto_compact(self, messages: List[Message]) -> bool:
        """Check whether token usage has crossed the auto-compact threshold.

        Returns ``False`` immediately if the circuit breaker is open
        (too many consecutive failures).
        """
        if self._auto_compact_consecutive_failures >= MAX_CONSECUTIVE_COMPACT_FAILURES:
            return False
        return self._estimate_tokens(messages) >= self._auto_compact_threshold

    # -- helpers -------------------------------------------------------- #

    def _has_active_plan(self) -> bool:
        """Return True if a deep-planning plan with tasks is active."""
        return bool(
            self.task
            and self.task.deep_planning
            and self.task.deep_planning.enabled
            and self.task.deep_planning.tasks
        )

    def _build_plan_section(self) -> str:
        """Build the plan-status block for the compaction prompt.

        Returns an empty string when there is no active plan.
        """
        if not self._has_active_plan():
            return ""

        lines = []
        completed = 0
        first_uncompleted = None
        for t in self.task.deep_planning.tasks:
            mark = "✓" if t.completed else " "
            lines.append(f"   [{mark}] {t.title} (ID: {t.id})")
            if t.completed:
                completed += 1
            elif first_uncompleted is None:
                first_uncompleted = t

        total = len(self.task.deep_planning.tasks)
        plan_block = "\n".join(lines)
        next_task_line = (
            f"   Next task: {first_uncompleted.title} (ID: {first_uncompleted.id})"
            if first_uncompleted
            else ""
        )
        return (
            f"\n   Current execution plan:\n{plan_block}\n"
            f"   Completed: {completed}/{total} tasks\n"
            f"{next_task_line}"
        )

    def _build_compaction_prompt(
        self,
        messages: List[Message],
        custom_instructions: str = "",
    ) -> str:
        """Render the user-side compaction prompt with conversation + template."""
        conversation = json.dumps(
            [m.to_dict() for m in messages],
            default=str,
            ensure_ascii=False,
        )
        plan_section = self._build_plan_section()
        custom_section = (
            f"\nAdditional focus: {custom_instructions}" if custom_instructions else ""
        )
        return AUTO_COMPACT_USER_PROMPT_TEMPLATE.format(
            conversation=conversation,
            plan_section=plan_section,
            custom_instructions_section=custom_section,
        )

    async def _push_activity_event(
        self,
        event_type: Any,
        data: Any,
    ) -> None:
        """Push an event to the task activity log.

        Fire-and-forget — failures are logged but never block compaction.
        """
        if not self.agent or not self.task:
            return
        try:
            from xpander_sdk.modules.tasks.sub_modules.task import TaskUpdateEvent

            evt = TaskUpdateEvent(
                task_id=self.task.id,
                organization_id=self.task.organization_id,
                time=datetime.now(timezone.utc).isoformat(),
                type=event_type,
                data=data,
            )
            client = APIClient(configuration=self.agent.configuration)
            await client.make_request(
                path=APIRoute.PushExecutionEventToQueue.format(task_id=self.task.id),
                method="POST",
                payload=[evt.model_dump_safe()],
            )
        except Exception as exc:
            logger.warning(
                f"[context-optimizer] layer 2: failed to push activity event: {exc}"
            )

    async def _publish_compaction_start(
        self,
        trigger: Literal["auto", "manual", "emergency", "pre_retry"],
        pre_tokens: int,
        pre_message_count: int,
        focus: str = "",
    ) -> None:
        """Emit a compaction_started event."""
        from xpander_sdk.models.compactization import (
            TaskCompactizationEvent,
            TaskCompactizationStarted,
        )
        from xpander_sdk.models.events import TaskUpdateEventType

        await self._push_activity_event(
            event_type=TaskUpdateEventType.TaskCompactization,
            data=TaskCompactizationEvent(
                type="compaction_started",
                data=TaskCompactizationStarted(
                    trigger=trigger,
                    estimated_tokens=pre_tokens,
                    message_count=pre_message_count,
                    threshold=self._auto_compact_threshold,
                    attempt=self._compaction_attempt,
                    focus=focus or None,
                ),
            ),
        )

    async def _publish_compaction_end(
        self,
        trigger: Literal["auto", "manual", "emergency", "pre_retry"],
        summary: str,
        continuation_message: str,
        pre_tokens: int,
        post_tokens: int,
        llm_tokens_used: int,
    ) -> None:
        """Emit a success event (summarization / manual_compaction / emergency_compaction / pre_retry_compaction)."""
        from xpander_sdk.models.compactization import (
            TaskCompactizationEvent,
            TaskCompactizationOutput,
        )
        from xpander_sdk.models.events import TaskUpdateEventType

        type_map = {
            "auto": "summarization",
            "manual": "manual_compaction",
            "emergency": "emergency_compaction",
            "pre_retry": "pre_retry_compaction",
        }
        await self._push_activity_event(
            event_type=TaskUpdateEventType.TaskCompactization,
            data=TaskCompactizationEvent(
                type=type_map[trigger],
                data=TaskCompactizationOutput(
                    new_task_prompt=continuation_message,
                    task_context=summary,
                ),
            ),
        )
        logger.info(
            f"[context-optimizer] published compaction events for task {self.task.id} "
            f"(trigger={trigger}, attempt={self._compaction_attempt})"
        )

    async def _publish_compaction_error(
        self,
        trigger: Literal["auto", "manual", "emergency", "pre_retry"],
        error: str,
    ) -> None:
        """Emit a compaction_error event."""
        from xpander_sdk.models.compactization import (
            TaskCompactizationError as CompactionErrorModel,
            TaskCompactizationEvent,
        )
        from xpander_sdk.models.events import TaskUpdateEventType

        await self._push_activity_event(
            event_type=TaskUpdateEventType.TaskCompactization,
            data=TaskCompactizationEvent(
                type="compaction_error",
                data=CompactionErrorModel(
                    trigger=trigger,
                    error=error,
                    attempt=self._compaction_attempt,
                ),
            ),
        )

    async def _publish_compaction_progress(
        self,
        trigger: Literal["auto", "manual", "emergency", "pre_retry"],
        percent: float,
        label: str = "Compacting context",
        detail: Optional[str] = None,
    ) -> None:
        """Emit a customer-facing ``compaction_progress`` activity event.

        Only ``percent`` + ``label`` + ``detail`` are sent over the wire.
        Callers should NOT invoke this directly for rate-limited updates;
        go through ``_emit_progress`` which applies the monotonic /
        cadence guards.
        """
        from xpander_sdk.models.compactization import (
            TaskCompactizationEvent,
            TaskCompactizationProgress,
        )
        from xpander_sdk.models.events import TaskUpdateEventType

        await self._push_activity_event(
            event_type=TaskUpdateEventType.TaskCompactization,
            data=TaskCompactizationEvent(
                type="compaction_progress",
                data=TaskCompactizationProgress(
                    trigger=trigger,
                    attempt=self._compaction_attempt,
                    percent=round(max(0.0, min(100.0, percent)), 1),
                    label=label,
                    detail=detail,
                ),
            ),
        )

    # Progress-emission rate-limiter state. Reset at the start of every
    # ``layer_2_auto_compact`` call by ``_reset_progress_state``.
    _progress_last_percent: float = field(default=-1.0, init=False, repr=False)
    _progress_last_label: str = field(default="", init=False, repr=False)
    _progress_last_detail: Optional[str] = field(default=None, init=False, repr=False)
    _progress_last_ts: float = field(default=0.0, init=False, repr=False)

    def _reset_progress_state(self) -> None:
        """Reset the progress rate-limiter for a fresh compaction attempt."""
        self._progress_last_percent = -1.0
        self._progress_last_label = ""
        self._progress_last_detail = None
        self._progress_last_ts = 0.0

    async def _emit_progress(
        self,
        trigger: Literal["auto", "manual", "emergency", "pre_retry"],
        percent: float,
        label: str = "Compacting context",
        detail: Optional[str] = None,
        force: bool = False,
    ) -> None:
        """Rate-limited + monotonic wrapper around ``_publish_compaction_progress``.

        Emits only when at least one of the following is true:
            * ``force`` is True
            * it's the first emit for this attempt (no prior value)
            * ``percent`` advanced by >= 5 since the last emit
            * 2 seconds have passed since the last emit
            * ``label`` or ``detail`` changed

        ``percent`` is clamped to the last-seen value so the user never sees
        it go backwards even if an out-of-order phase call tries to lower it.
        """
        import time as _time

        clamped = max(0.0, min(100.0, float(percent)))
        if self._progress_last_percent >= 0 and clamped < self._progress_last_percent:
            clamped = self._progress_last_percent

        now = _time.monotonic()
        label_changed = label != self._progress_last_label
        detail_changed = detail != self._progress_last_detail
        first = self._progress_last_percent < 0
        percent_changed = clamped - max(self._progress_last_percent, 0.0) >= 5.0
        stale = (now - self._progress_last_ts) >= 2.0 and self._progress_last_ts > 0

        if not (
            force
            or first
            or label_changed
            or detail_changed
            or percent_changed
            or stale
        ):
            return

        self._progress_last_percent = clamped
        self._progress_last_label = label
        self._progress_last_detail = detail
        self._progress_last_ts = now

        try:
            await self._publish_compaction_progress(
                trigger=trigger,
                percent=clamped,
                label=label,
                detail=detail,
            )
        except Exception as exc:
            logger.warning(f"[context-optimizer] failed to emit progress event: {exc}")

    # ------------------------------------------------------------------ #
    #  LLM call helpers (single call + chunked map-reduce)
    # ------------------------------------------------------------------ #

    async def _run_llm_compaction_call(
        self,
        system_prompt: str,
        user_prompt: str,
        run_metrics: Optional["RunMetrics"] = None,
        progress_label: str = "layer 2",
        trigger: Optional[Literal["auto", "manual", "emergency", "pre_retry"]] = None,
        percent_start: Optional[float] = None,
        percent_end: Optional[float] = None,
        progress_detail: Optional[str] = None,
    ) -> tuple:
        """Run a single streaming LLM call and return ``(text, in_tok, out_tok)``.

        Used by both the regular L2 single-shot path and each map/reduce step
        of the chunked compaction path. Raises on provider errors so callers
        can decide whether to fall back to chunked compaction.

        When ``trigger``, ``percent_start`` and ``percent_end`` are provided,
        emits sparse customer-facing ``compaction_progress`` events mapped
        linearly from a rough output-char estimate into the
        ``[percent_start, percent_end)`` range. Cadence + monotonic guards
        are enforced by ``_emit_progress``.
        """
        import time
        from agno.models.response import ModelResponse, ModelResponseEvent

        self.model = get_model(self.model)
        if not self.model:
            raise RuntimeError("No model available for compaction")

        content_parts: List[str] = []
        input_tokens = 0
        output_tokens = 0
        streamed_chars = 0
        _PROGRESS_LOG_INTERVAL = 2_000
        _next_progress_log = _PROGRESS_LOG_INTERVAL

        messages = [
            Message(role="system", content=system_prompt),
            Message(role="user", content=user_prompt),
        ]

        prompt_chars = len(system_prompt) + len(user_prompt)
        start_ts = time.monotonic()
        first_token_ts: Optional[float] = None
        logger.info(
            f"[context-optimizer] {progress_label}: → LLM call starting "
            f"(model={getattr(self.model, 'id', '?')}, prompt_chars={prompt_chars:,})"
        )

        # Coarse target used purely to interpolate the percent inside the
        # caller-requested [percent_start, percent_end) window. We intentionally
        # do NOT emit streaming rates or char counts to the wire.
        emit_progress = (
            trigger is not None
            and percent_start is not None
            and percent_end is not None
            and percent_end > percent_start
        )
        est_output_chars = max(500, int(prompt_chars * 0.2)) if emit_progress else 0

        async for chunk in self.model.aresponse_stream(messages=messages):
            if not isinstance(chunk, ModelResponse):
                continue
            if (
                chunk.event == ModelResponseEvent.assistant_response.value
                and chunk.content
            ):
                text = str(chunk.content)
                if first_token_ts is None:
                    first_token_ts = time.monotonic()
                    logger.info(
                        f"[context-optimizer] {progress_label}: first token "
                        f"(ttft={first_token_ts - start_ts:.2f}s)"
                    )
                content_parts.append(text)
                streamed_chars += len(text)
                if streamed_chars >= _next_progress_log:
                    elapsed = time.monotonic() - start_ts
                    rate = streamed_chars / elapsed if elapsed > 0 else 0
                    logger.info(
                        f"[context-optimizer] {progress_label}: streaming "
                        f"{streamed_chars:,} chars ({rate:,.0f} ch/s, elapsed={elapsed:.1f}s)"
                    )
                    _next_progress_log = streamed_chars + _PROGRESS_LOG_INTERVAL
                # Sparse, rate-limited customer-facing progress event.
                if emit_progress:
                    span = percent_end - percent_start  # type: ignore[operator]
                    frac = (
                        min(1.0, streamed_chars / est_output_chars)
                        if est_output_chars
                        else 0.0
                    )
                    pct = percent_start + span * frac  # type: ignore[operator]
                    await self._emit_progress(
                        trigger=trigger,  # type: ignore[arg-type]
                        percent=pct,
                        detail=progress_detail,
                    )
            if chunk.event == ModelResponseEvent.model_request_completed.value:
                input_tokens = chunk.input_tokens or 0
                output_tokens = chunk.output_tokens or 0

        summary = "".join(content_parts)
        elapsed = time.monotonic() - start_ts

        if run_metrics is not None and (input_tokens or output_tokens):
            self._accumulate_run_metrics(run_metrics, input_tokens, output_tokens)

        logger.info(
            f"[context-optimizer] {progress_label}: ← LLM call done "
            f"(in={input_tokens:,} tok, out={output_tokens:,} tok, "
            f"summary={len(summary):,} chars, elapsed={elapsed:.1f}s)"
        )
        return summary, input_tokens, output_tokens

    def _accumulate_run_metrics(
        self,
        run_metrics: "RunMetrics",
        input_tokens: int,
        output_tokens: int,
    ) -> None:
        """Add compaction-call token usage to the run's compression metrics."""
        from agno.metrics import ModelType, ModelMetrics

        if run_metrics.details is None:
            run_metrics.details = {}

        model_id = self.model.id
        model_provider = self.model.get_provider()
        model_metrics = ModelMetrics(
            id=model_id,
            provider=model_provider,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            total_tokens=input_tokens + output_tokens,
        )
        _type_key = ModelType.COMPRESSION_MODEL.value
        entries = run_metrics.details.get(_type_key)
        if entries is None:
            run_metrics.details[_type_key] = [model_metrics]
        else:
            for entry in entries:
                if entry.id == model_id and entry.provider == model_provider:
                    entry.accumulate(model_metrics)
                    break
            else:
                entries.append(model_metrics)

        run_metrics.input_tokens += input_tokens
        run_metrics.output_tokens += output_tokens
        run_metrics.total_tokens += input_tokens + output_tokens

    # ------------------------------------------------------------------ #
    #  Chunked map-reduce compaction
    # ------------------------------------------------------------------ #

    def _compute_chunk_char_budget(
        self, provider_max_tokens: Optional[int] = None
    ) -> int:
        """Derive a safe per-chunk input char budget.

        Starts from the smaller of the agent-declared ``context_window`` and
        any provider-reported max (set via ``_provider_max_tokens`` or the
        *provider_max_tokens* override), subtracts ``reserved_for_output`` and
        ``buffer_tokens``, and converts to chars using the same chars/token
        heuristic the rest of the optimizer uses (chars ≈ tokens * 4 / 1.2).
        """
        caps = [self.context_window]
        if self._provider_max_tokens:
            caps.append(self._provider_max_tokens)
        if provider_max_tokens:
            caps.append(provider_max_tokens)
        effective_cap = min(c for c in caps if c and c > 0)
        budget_tokens = max(
            1, effective_cap - self.reserved_for_output - self.buffer_tokens
        )
        # chars ≈ tokens * 4 / 1.2 (matches ``_estimate_tokens`` heuristic).
        return max(1_000, int(budget_tokens * 4 / 1.2))

    async def _run_chunked_map(
        self,
        messages: List[Any],
        char_budget: int,
        trigger: Literal["auto", "manual", "emergency", "pre_retry"],
        run_metrics: Optional["RunMetrics"],
        recursion_depth: int,
    ) -> tuple:
        """Summarize *messages* chunk-by-chunk. Returns ``(partials, total_tokens)``."""
        chunks = _split_messages_into_chunks(messages, char_budget)
        total_chunks = len(chunks)
        partials: List[str] = []
        total_tokens = 0
        logger.info(
            f"[context-optimizer] layer 2 (chunked): map phase "
            f"depth={recursion_depth} chunks={total_chunks} budget={char_budget:,} chars"
        )
        for idx, chunk in enumerate(chunks, start=1):
            conversation = json.dumps(
                [
                    (
                        m.to_dict()
                        if hasattr(m, "to_dict")
                        else {
                            "role": getattr(m, "role", "user"),
                            "content": str(getattr(m, "content", "")),
                        }
                    )
                    for m in chunk
                ],
                default=str,
                ensure_ascii=False,
            )
            user_prompt = PARTIAL_COMPACT_USER_PROMPT_TEMPLATE.format(
                chunk_index=idx,
                total_chunks=total_chunks,
                conversation=conversation,
            )
            # Map phase takes the 5..70 range; each chunk advances the percent
            # by its fair share. Inside a chunk we stream from the "start" to
            # the "end" of that chunk's slice.
            chunk_span = 65.0 / max(1, total_chunks)
            chunk_pct_start = 5.0 + (idx - 1) * chunk_span
            chunk_pct_end = 5.0 + idx * chunk_span
            await self._emit_progress(
                trigger=trigger,
                percent=chunk_pct_start,
                detail=f"Analyzing conversation ({idx} of {total_chunks})",
            )
            partial, in_tok, out_tok = await self._run_llm_compaction_call(
                system_prompt=PARTIAL_COMPACT_SYSTEM_PROMPT,
                user_prompt=user_prompt,
                run_metrics=run_metrics,
                progress_label=f"layer 2 (map {idx}/{total_chunks})",
                trigger=trigger,
                percent_start=chunk_pct_start,
                percent_end=chunk_pct_end,
                progress_detail=f"Analyzing conversation ({idx} of {total_chunks})",
            )
            if not partial:
                partial = "(empty partial digest)"
            partials.append(
                f'<partial index="{idx}" total="{total_chunks}">\n{partial}\n</partial>'
            )
            total_tokens += in_tok + out_tok
        return partials, total_tokens

    async def _layer_2_chunked_compact(
        self,
        messages: List[Message],
        run_metrics: Optional["RunMetrics"],
        custom_instructions: str,
        trigger: Literal["auto", "manual", "emergency", "pre_retry"],
        provider_max_tokens: Optional[int] = None,
    ) -> tuple:
        """Run map-reduce compaction: summarise chunks, then combine.

        Returns ``(summary, total_llm_tokens_used)``. Raises on unrecoverable
        failure; the caller handles failure-path activity / circuit breaker.
        """
        char_budget = self._compute_chunk_char_budget(provider_max_tokens)
        current_inputs: List[Any] = list(messages)
        total_tokens = 0

        for depth in range(self.max_chunked_recursion_depth):
            partials, tokens_used = await self._run_chunked_map(
                messages=current_inputs,
                char_budget=char_budget,
                trigger=trigger,
                run_metrics=run_metrics,
                recursion_depth=depth,
            )
            total_tokens += tokens_used

            if not partials:
                raise RuntimeError("Chunked compaction produced no partial digests")

            combined_text = "\n\n".join(partials)
            combined_chars = len(combined_text)
            logger.info(
                f"[context-optimizer] layer 2 (chunked): depth={depth} "
                f"produced {len(partials)} partials ({combined_chars:,} chars, budget={char_budget:,})"
            )

            if (
                combined_chars <= char_budget
                or depth + 1 >= self.max_chunked_recursion_depth
            ):
                # Final reduce step: use the normal state-capture template.
                plan_section = self._build_plan_section()
                custom_section = (
                    f"\nAdditional focus: {custom_instructions}"
                    if custom_instructions
                    else ""
                )
                reduce_prompt = AUTO_COMPACT_USER_PROMPT_TEMPLATE.format(
                    conversation=(
                        "The original conversation was too large for a single "
                        "summarization call, so it was split into partial digests "
                        f"(R1..R{len(partials)}). Treat these digests as the "
                        "conversation and synthesize the final working-state "
                        "summary below.\n\n" + combined_text
                    ),
                    plan_section=plan_section,
                    custom_instructions_section=custom_section,
                )
                await self._emit_progress(
                    trigger=trigger,
                    percent=70.0,
                    detail="Summarizing analysis",
                )
                summary, in_tok, out_tok = await self._run_llm_compaction_call(
                    system_prompt=AUTO_COMPACT_SYSTEM_PROMPT,
                    user_prompt=reduce_prompt,
                    run_metrics=run_metrics,
                    progress_label="layer 2 (reduce)",
                    trigger=trigger,
                    percent_start=70.0,
                    percent_end=95.0,
                    progress_detail="Summarizing analysis",
                )
                total_tokens += in_tok + out_tok
                if not summary:
                    raise RuntimeError(
                        "Chunked compaction reduce step returned empty summary"
                    )
                return summary, total_tokens

            # Partials still too big for a single reduce call; recurse by
            # summarising the partials themselves.
            current_inputs = [
                SimpleNamespace(
                    role="user",
                    content=p,
                    to_dict=(lambda _p=p: {"role": "user", "content": _p}),
                )
                for p in partials
            ]

        raise RuntimeError(
            f"Chunked compaction exceeded max recursion depth ({self.max_chunked_recursion_depth})"
        )

    # -- main entry point ----------------------------------------------- #

    async def layer_2_auto_compact(
        self,
        messages: List[Message],
        run_metrics: Optional["RunMetrics"] = None,
        custom_instructions: str = "",
        trigger: Literal["auto", "manual", "emergency", "pre_retry"] = "auto",
    ) -> None:
        """Summarise the full conversation into a structured working state.

        Replaces the context window contents: clears all conversation messages
        but preserves system messages (agent instructions, tool descriptions),
        then appends the compacted summary as a continuation message.

        On failure the list is left untouched so the agent can continue with
        full context.

        If the conversation is too large for a single compaction call — either
        detected proactively (``pre_tokens > chunked_compact_threshold``) or
        reactively (the provider returns a context-overflow 400) — this method
        falls back to ``_layer_2_chunked_compact`` which does map-reduce
        summarisation over message chunks.
        """
        # Circuit breaker guard (emergency and pre_retry bypass this)
        if (
            trigger not in ("emergency", "pre_retry")
            and self._auto_compact_consecutive_failures
            >= MAX_CONSECUTIVE_COMPACT_FAILURES
        ):
            logger.warning(
                f"[context-optimizer] circuit breaker open "
                f"({self._auto_compact_consecutive_failures} consecutive failures) — skipping"
            )
            return

        self._compaction_attempt += 1
        pre_tokens = self._estimate_tokens(messages)
        pre_message_count = len(messages)

        # Snapshot deep-planning state (may be None)
        deep_planning_snapshot = None
        if self._has_active_plan():
            deep_planning_snapshot = self.task.deep_planning.model_copy(deep=True)

        logger.info(
            f"[context-optimizer] starting compaction #{self._compaction_attempt} "
            f"(trigger={trigger}, messages={pre_message_count}, est_tokens={pre_tokens:,}, "
            f"threshold={self._auto_compact_threshold:,})"
        )

        # Publish start event (fire-and-forget)
        await self._publish_compaction_start(
            trigger=trigger,
            pre_tokens=pre_tokens,
            pre_message_count=pre_message_count,
            focus=custom_instructions if trigger == "manual" else "",
        )

        # Reset and emit an initial 0% progress tick so the UI gets a
        # customer-facing "Compacting context" the moment compaction starts,
        # independent of how fast the LLM eventually produces content.
        self._reset_progress_state()
        await self._emit_progress(trigger=trigger, percent=0.0, force=True)

        try:
            self.model = get_model(self.model)
            if not self.model:
                raise RuntimeError("No model available for auto-compaction")

            logger.info(
                f"[context-optimizer] layer 2: calling LLM ({self.model.id}) "
                f"to summarise {pre_message_count} messages"
            )

            summary: str = ""
            tokens_used = 0
            compact_mode = "single"

            # Proactive chunked path when we already know the conversation is
            # too large for a single call. Saves a wasted round trip.
            should_chunk = (
                self.chunked_compact_threshold is not None
                and pre_tokens >= self.chunked_compact_threshold
            ) or (self._provider_max_tokens and pre_tokens >= self._provider_max_tokens)
            if should_chunk:
                logger.info(
                    f"[context-optimizer] layer 2: proactively chunking "
                    f"(pre_tokens={pre_tokens:,} ≥ threshold={self.chunked_compact_threshold:,})"
                )
                summary, tokens_used = await self._layer_2_chunked_compact(
                    messages=list(messages),
                    run_metrics=run_metrics,
                    custom_instructions=custom_instructions,
                    trigger=trigger,
                )
                compact_mode = "chunked-proactive"
            else:
                # Reactive path: attempt the single compaction call and fall
                # back to chunked on context-overflow errors.
                compaction_prompt = self._build_compaction_prompt(
                    messages,
                    custom_instructions=custom_instructions,
                )
                try:
                    await self._emit_progress(
                        trigger=trigger,
                        percent=5.0,
                        detail="Summarizing conversation",
                    )
                    summary, in_tok, out_tok = await self._run_llm_compaction_call(
                        system_prompt=AUTO_COMPACT_SYSTEM_PROMPT,
                        user_prompt=compaction_prompt,
                        run_metrics=run_metrics,
                        progress_label="layer 2",
                        trigger=trigger,
                        percent_start=5.0,
                        percent_end=90.0,
                        progress_detail="Summarizing conversation",
                    )
                    tokens_used = in_tok + out_tok
                except Exception as exc:
                    if not _is_context_overflow_error(exc):
                        raise
                    provider_max = _parse_provider_max_tokens(exc)
                    if provider_max:
                        self._provider_max_tokens = provider_max
                    logger.warning(
                        f"[context-optimizer] layer 2: single call hit context "
                        f"overflow (provider_max={provider_max or 'unknown'}) — "
                        f"retrying with chunked map-reduce compaction"
                    )
                    summary, tokens_used = await self._layer_2_chunked_compact(
                        messages=list(messages),
                        run_metrics=run_metrics,
                        custom_instructions=custom_instructions,
                        trigger=trigger,
                        provider_max_tokens=provider_max,
                    )
                    compact_mode = "chunked-reactive"

            if not summary:
                raise RuntimeError("LLM returned empty summary")

            # ---- Replace context window in-place ---------------------- #
            backup_pointer = getattr(self, "_pending_backup_pointer", "")
            self._pending_backup_pointer = ""  # reset after use
            continuation_message = CONTINUATION_MESSAGE_TEMPLATE.format(
                summary=summary,
                backup_pointer=backup_pointer,
            )
            system_messages = [m for m in messages if m.role == "system"]
            messages.clear()
            messages.extend(system_messages)
            messages.append(Message(role="user", content=continuation_message))

            # ---- Rehydrate deep-planning state ------------------------ #
            if deep_planning_snapshot is not None and self.task:
                self.task.deep_planning = deep_planning_snapshot
                plan_context = self._build_plan_section()
                if plan_context:
                    messages.append(
                        Message(
                            role="user",
                            content=f"Execution plan state after context compaction:\n{plan_context}",
                        )
                    )

            # Final progress tick before the end event so the UI shows
            # 95% → 100% naturally (the end event marks completion).
            await self._emit_progress(
                trigger=trigger,
                percent=95.0,
                detail="Finalizing",
                force=True,
            )

            # ---- Publish activity event (end) ------------------------- #
            post_tokens = self._estimate_tokens(messages)
            await self._publish_compaction_end(
                trigger=trigger,
                summary=summary,
                continuation_message=continuation_message,
                pre_tokens=pre_tokens,
                post_tokens=post_tokens,
                llm_tokens_used=tokens_used,
            )

            ratio = (
                f"{(1 - post_tokens / pre_tokens) * 100:.1f}%"
                if pre_tokens > 0
                else "N/A"
            )
            logger.info(
                f"[context-optimizer] compaction #{self._compaction_attempt} succeeded "
                f"(trigger={trigger}, mode={compact_mode}, {pre_tokens:,} -> {post_tokens:,} "
                f"tokens, {ratio} reduction, LLM cost: {tokens_used:,} tokens)"
            )

            self._auto_compact_consecutive_failures = 0
            self.stats["compactions"] = self.stats.get("compactions", 0) + 1
            self.stats["compact_tokens_used"] = (
                self.stats.get("compact_tokens_used", 0) + tokens_used
            )

        except Exception as exc:
            self._auto_compact_consecutive_failures += 1
            logger.error(
                f"[context-optimizer] compaction #{self._compaction_attempt} failed "
                f"(trigger={trigger}, consecutive_failures={self._auto_compact_consecutive_failures}/"
                f"{MAX_CONSECUTIVE_COMPACT_FAILURES}): {exc}"
            )
            # Publish error event (fire-and-forget)
            await self._publish_compaction_error(trigger=trigger, error=str(exc))
            # Messages are NOT modified on failure — agent continues with full context

    # ================================================================== #
    #  Pre-retry session compaction
    # ================================================================== #

    async def acompact_session_for_retry(
        self,
        agno_agent_or_xpander_agent: Any,
        task: "Task",
        custom_instructions: str = "",
    ) -> "CompactRetryResult":
        """Force L2 compaction on the session before a plan retry.

        Consolidates the pre-retry compaction logic used by both the agent-worker
        (mono) and the events_module (SDK).  Does four things:
        1. Backs up the full session to workspace (encrypted) for grep/search.
        2. Forces L2 compaction (replaces context window in-place).
        3. Persists the compacted summary to task.additional_context so the
           fresh retry agent picks it up.
        4. Deletes the old session from DB so the retry starts clean.

        Args:
            custom_instructions: Optional retry-focus guidance forwarded to
                the L2 compaction LLM (rendered after ``Additional focus:`` in
                the user prompt). Lets callers bias the summary toward
                remaining plan tasks / next action without changing the
                shared template used by ``auto`` / ``manual`` / ``emergency``.

        Returns a CompactRetryResult with token usage for billing.
        """
        result = CompactRetryResult()

        # ---- Circuit breaker: skip if already compacted --------------- #
        if task.additional_context and "<compacted_context>" in task.additional_context:
            logger.info(
                "[context-optimizer] pre-retry: skipping — <compacted_context> already present"
            )
            return result

        try:
            # ---- 0. Snapshot deep-planning state (must survive) -------- #
            deep_planning_snapshot = None
            if task.deep_planning:
                deep_planning_snapshot = task.deep_planning.model_copy(deep=True)

            # ---- 1. Load session from DB ------------------------------ #
            agent_obj = agno_agent_or_xpander_agent
            session = None

            # Agno Agent path (mono) — has session_id attr from agno
            if hasattr(agent_obj, "session_id") and hasattr(agent_obj, "db"):
                from agno.agent._session import aget_session as agno_aget_session

                session = await agno_aget_session(agent_obj, session_id=task.id)
            # xpander Agent path (SDK) — use the xpander agent's method
            elif hasattr(agent_obj, "aget_session"):
                session = await agent_obj.aget_session(session_id=task.id)

            if not session:
                logger.warning(
                    "[context-optimizer] pre-retry: no session found in DB — skipping"
                )
                return result

            messages = session.get_messages()
            if not messages or len(messages) < 3:
                logger.info(
                    "[context-optimizer] pre-retry: too few messages to compact — skipping"
                )
                return result

            logger.info(
                f"[context-optimizer] pre-retry: compacting session for task {task.id} "
                f"({len(messages)} messages)"
            )

            # ---- 2. Backup full session to workspace (non-blocking) ----- #
            backup_path = None
            try:
                session_json = json.dumps(
                    [m.to_dict() for m in messages],
                    default=str,
                    ensure_ascii=False,
                )
                stable_path = f"CONTEXT_OPTIMIZATION/session_backup_{task.id}.xp"
                key = derive_key(
                    org_id=self.agent.configuration.organization_id,
                    agent_id=self.agent.id,
                    task_id=task.id,
                )
                encrypted = encrypt(session_json, key)
                client = APIClient(configuration=self.agent.configuration)
                await client.make_request(
                    path=str(APIRoute.WorkspaceToolInvoke).format(
                        agent_id=self.agent.id,
                        tool_name="file_write",
                    ),
                    method="POST",
                    payload={"path": stable_path, "content": encrypted},
                )
                backup_path = stable_path
                result.backup_path = backup_path
                logger.info(
                    f"[context-optimizer] pre-retry: session backup saved to {backup_path}"
                )
            except Exception as exc:
                logger.warning(
                    f"[context-optimizer] pre-retry: backup failed (non-blocking): {exc}"
                )

            # ---- 3. Set backup pointer for continuation message ------- #
            if backup_path:
                self._pending_backup_pointer = (
                    f"\n<session_backup>\n"
                    f"Full session transcript backed up to: {backup_path}\n"
                    f"This file is ENCRYPTED at rest. To read it, call "
                    f"`xpworkspace-file-read` with `path={backup_path}` — the "
                    f"file-read tool decrypts it transparently. Do NOT use "
                    f"bash `cat` or `xpworkspace-bash` (those return ciphertext).\n"
                    f"Use this only when the summary above lacks a specific "
                    f"detail you need (exact code, error message verbatim, "
                    f"complete tool output).\n"
                    f"</session_backup>"
                )
            else:
                self._pending_backup_pointer = ""

            # ---- 4. Force L2 compaction with timeout ------------------ #
            from agno.models.metrics import RunMetrics

            compact_metrics = RunMetrics()
            try:
                await asyncio.wait_for(
                    self.layer_2_auto_compact(
                        messages,
                        run_metrics=compact_metrics,
                        custom_instructions=custom_instructions,
                        trigger="pre_retry",
                    ),
                    timeout=SESSION_COMPACT_TIMEOUT,
                )
            except asyncio.TimeoutError:
                logger.error(
                    f"[context-optimizer] pre-retry: compaction timed out after {SESSION_COMPACT_TIMEOUT}s"
                )
                return result

            # ---- 5. Capture token usage ------------------------------- #
            result.input_tokens = compact_metrics.input_tokens
            result.output_tokens = compact_metrics.output_tokens
            result.total_tokens = compact_metrics.total_tokens

            # ---- 5b. Persist summary to task.additional_context ------- #
            # L2 replaces the context window in-place but does NOT write to
            # additional_context.  For pre-retry we need the summary there
            # because the session gets deleted and the fresh agent rebuilds
            # its context from additional_context.
            try:
                # Extract summary from the continuation message L2 appended
                continuation_msg = next(
                    (
                        m
                        for m in messages
                        if m.role == "user"
                        and m.content
                        and "<session_resume>" in str(m.content)
                    ),
                    None,
                )
                if continuation_msg:
                    task.additional_context = (
                        (task.additional_context or "")
                        + "\n\n<compacted_context>\n"
                        + str(continuation_msg.content)
                        + "\n</compacted_context>"
                    )
                    logger.info(
                        "[context-optimizer] pre-retry: persisted compaction summary to task.additional_context"
                    )
            except Exception as exc:
                logger.warning(
                    f"[context-optimizer] pre-retry: failed to persist summary to task: {exc}"
                )

            # ---- 6. Delete old session so retry starts clean ---------- #
            # The fresh agent will rebuild its system prompt + pick up the
            # summary from additional_context.
            try:
                if hasattr(agent_obj, "session_id") and hasattr(agent_obj, "db"):
                    # Agno Agent path
                    from agno.agent._session import adelete_session

                    await adelete_session(agent_obj, session_id=task.id)
                elif hasattr(agent_obj, "adelete_session"):
                    # xpander Agent path
                    await agent_obj.adelete_session(session_id=task.id)
                logger.info(
                    f"[context-optimizer] pre-retry: deleted old session {task.id}"
                )
            except Exception as exc:
                logger.warning(
                    f"[context-optimizer] pre-retry: session delete failed (non-critical): {exc}"
                )

            # ---- 7. Restore deep-planning state ----------------------- #
            # Deep planning must survive the retry — it tracks plan tasks,
            # completion status, and question state.
            if deep_planning_snapshot is not None:
                task.deep_planning = deep_planning_snapshot
                logger.info(
                    "[context-optimizer] pre-retry: deep planning state preserved"
                )

            result.compacted = True
            logger.info(
                f"[context-optimizer] pre-retry: compaction complete "
                f"(input={result.input_tokens:,}, output={result.output_tokens:,}, "
                f"total={result.total_tokens:,} tokens)"
            )
            return result

        except Exception as exc:
            logger.error(f"[context-optimizer] pre-retry: compaction failed: {exc}")
            # Restore deep planning even on failure
            if deep_planning_snapshot is not None:
                task.deep_planning = deep_planning_snapshot
            return result
