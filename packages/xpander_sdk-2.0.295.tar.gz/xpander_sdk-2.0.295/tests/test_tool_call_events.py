"""Unit tests for the shared tool-call activity reporting utility and its
integration with ``Tool.ainvoke`` and the agno hook.

These tests avoid live HTTP by patching ``APIClient.make_request``; they do
not require real credentials or a running backend.
"""

from __future__ import annotations

import asyncio
from types import SimpleNamespace
from typing import Any, Dict, List

import pytest
from unittest.mock import AsyncMock, patch

from xpander_sdk.models.events import (
    TaskUpdateEventType,
    ToolCallRequestReasoning,
)
from xpander_sdk.modules.backend.utils.tool_call_events import (
    DEFAULT_MAX_CONTENT_LENGTH,
    DEFAULT_PREVIEW_LENGTH,
    PLANNING_TOOLS,
    REASONING_TOOLS,
    coerce_json_like,
    extract_reasoning,
    is_reasoning_tool,
    report_reasoning_event,
    report_tool_call_request,
    report_tool_call_result,
    shape_result_for_activity,
    should_skip_tool_report,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class _FakeTask(SimpleNamespace):
    """Minimal Task stand-in. The helper only reads id/org/configuration."""


def _make_fake_task(task_id: str = "task-1", org_id: str = "org-1") -> _FakeTask:
    # Configuration only needs to be a simple object that APIClient can accept.
    from xpander_sdk.models.configuration import Configuration

    return _FakeTask(
        id=task_id,
        organization_id=org_id,
        configuration=Configuration(api_key="test", organization_id=org_id),
    )


async def _wait_for_background_tasks() -> None:
    """Yield enough times to let asyncio.create_task-scheduled coroutines run."""
    for _ in range(6):
        await asyncio.sleep(0)


# ---------------------------------------------------------------------------
# shape_result_for_activity
# ---------------------------------------------------------------------------


def test_shape_result_returns_small_values_unchanged():
    assert shape_result_for_activity("hello") == "hello"
    assert shape_result_for_activity({"a": 1}) == {"a": 1}
    assert shape_result_for_activity(None) is None


def test_shape_result_truncates_large_strings():
    big = "x" * (DEFAULT_MAX_CONTENT_LENGTH + 500)
    shaped = shape_result_for_activity(big)
    assert isinstance(shaped, str)
    assert "[TRUNCATED OUTPUT" in shaped
    # The preview portion is exactly preview_length characters of the input.
    assert shaped.startswith("x" * DEFAULT_PREVIEW_LENGTH)
    assert len(shaped) < len(big)


def test_shape_result_truncates_large_dicts_via_json():
    big_dict = {"items": ["y" * 20] * 1000}
    shaped = shape_result_for_activity(big_dict)
    assert isinstance(shaped, str)
    assert "[TRUNCATED OUTPUT" in shaped


def test_shape_result_with_skip_truncation_keeps_full_content():
    big = "z" * (DEFAULT_MAX_CONTENT_LENGTH + 5_000)
    shaped = shape_result_for_activity(big, skip_truncation=True)
    # Full content preserved, no truncation marker.
    assert shaped == big
    assert "[TRUNCATED OUTPUT" not in shaped


# ---------------------------------------------------------------------------
# coerce_json_like
# ---------------------------------------------------------------------------


def test_coerce_json_like_parses_json_string_dict():
    assert coerce_json_like('{"a": 1, "b": [2, 3]}') == {"a": 1, "b": [2, 3]}


def test_coerce_json_like_parses_json_string_list():
    assert coerce_json_like('[1, 2, {"x": "y"}]') == [1, 2, {"x": "y"}]


def test_coerce_json_like_parses_python_literal_dict():
    # Single-quoted Python literal; json.loads would fail, ast.literal_eval should handle it.
    assert coerce_json_like("{'a': 1, 'b': 'two'}") == {"a": 1, "b": "two"}


def test_coerce_json_like_leaves_plain_strings_alone():
    assert coerce_json_like("hello world") == "hello world"
    # Looks like an identifier, not a dict/list.
    assert coerce_json_like("42") == "42"


def test_coerce_json_like_recurses_into_dicts_and_lists():
    value = {
        "outer": '{"inner": 5}',
        "list": ["[1, 2]", {"nested_str": '{"k": "v"}'}],
    }
    assert coerce_json_like(value) == {
        "outer": {"inner": 5},
        "list": [[1, 2], {"nested_str": {"k": "v"}}],
    }


def test_coerce_json_like_pass_through_primitives():
    assert coerce_json_like(None) is None
    assert coerce_json_like(123) == 123
    assert coerce_json_like(1.5) == 1.5
    assert coerce_json_like(True) is True


def test_coerce_json_like_returns_original_on_parse_failure():
    # Starts with { but is not a valid JSON/literal dict.
    assert coerce_json_like("{not valid") == "{not valid"


# ---------------------------------------------------------------------------
# extract_reasoning
# ---------------------------------------------------------------------------


def test_extract_reasoning_from_top_level_headers():
    reasoning = extract_reasoning(
        {
            "headers": {
                "toolcallreasoningtitle": "Do X",
                "toolcallreasoningdescription": "because Y",
            }
        }
    )
    assert isinstance(reasoning, ToolCallRequestReasoning)
    assert reasoning.title == "Do X"
    assert reasoning.description == "because Y"


def test_extract_reasoning_from_nested_body_params_headers():
    reasoning = extract_reasoning(
        {
            "payload": {
                "body_params": {
                    "headers": {
                        "toolcallreasoningtitle": "Compact",
                        "toolcallreasoningdescription": "free space",
                    }
                }
            }
        }
    )
    assert reasoning is not None
    assert reasoning.title == "Compact"
    assert reasoning.description == "free space"


def test_extract_reasoning_missing_returns_none():
    assert extract_reasoning(None) is None
    assert extract_reasoning({}) is None
    assert extract_reasoning({"unrelated": "value"}) is None


# ---------------------------------------------------------------------------
# should_skip_tool_report (deep-planning tools)
# ---------------------------------------------------------------------------


def test_planning_tools_skip_set_matches_mono():
    # Must cover every deep-planning tool the backend currently skips.
    expected = {
        "xpcreate_agent_plan",
        "xpget_agent_plan",
        "xpadd_new_agent_plan_item",
        "xpupdate_agent_plan_item",
        "xpdelete_agent_plan_item",
        "xpcomplete_agent_plan_items",
        "xpask_for_information",
        "xpstart_execution_plan",
    }
    assert set(PLANNING_TOOLS) == expected


def test_should_skip_tool_report_flags_planning_and_reasoning_tools():
    for tool in PLANNING_TOOLS:
        assert should_skip_tool_report(tool) is True
    # Reasoning tools are also skipped for regular tool-call reporting; they
    # are emitted via the dedicated reasoning event instead.
    for tool in REASONING_TOOLS:
        assert should_skip_tool_report(tool) is True
    # Non-planning / non-reasoning tools should not be skipped.
    assert should_skip_tool_report("my_tool") is False
    assert should_skip_tool_report("xpworkspace-bash") is False
    assert should_skip_tool_report("xpcompact_context") is False
    assert should_skip_tool_report(None) is False
    assert should_skip_tool_report("") is False


# ---------------------------------------------------------------------------
# Reasoning tools (think / analyze)
# ---------------------------------------------------------------------------


def test_reasoning_tools_set_is_think_and_analyze():
    assert set(REASONING_TOOLS) == {"think", "analyze"}


def test_is_reasoning_tool_flag():
    assert is_reasoning_tool("think") is True
    assert is_reasoning_tool("analyze") is True
    assert is_reasoning_tool("my_tool") is False
    assert is_reasoning_tool(None) is False


@pytest.mark.asyncio
async def test_report_reasoning_event_emits_think_with_input_payload():
    task = _make_fake_task()
    with patch(
        "xpander_sdk.modules.backend.utils.tool_call_events.APIClient"
    ) as mock_api_cls:
        mock_client = mock_api_cls.return_value
        mock_client.make_request = AsyncMock(return_value=None)

        await report_reasoning_event(
            task=task,
            tool_name="think",
            arguments={
                "title": "Consider options",
                "confidence": 0.85,
                "thought": "let's evaluate",
                "action": "compare",
            },
        )

        events = _captured_payloads(mock_client.make_request)
        assert len(events) == 1
        event = events[0]
        # Consumer expects the dedicated Think event type.
        assert event["type"] == TaskUpdateEventType.Think.value
        # And the reasoning fields wrapped under payload["input"].
        payload_input = event["data"]["payload"]["input"]
        assert payload_input["title"] == "Consider options"
        assert payload_input["confidence"] == 0.85
        assert payload_input["thought"] == "let's evaluate"
        assert payload_input["action"] == "compare"


@pytest.mark.asyncio
async def test_report_reasoning_event_emits_analyze():
    task = _make_fake_task()
    with patch(
        "xpander_sdk.modules.backend.utils.tool_call_events.APIClient"
    ) as mock_api_cls:
        mock_client = mock_api_cls.return_value
        mock_client.make_request = AsyncMock(return_value=None)

        await report_reasoning_event(
            task=task,
            tool_name="analyze",
            arguments={"title": "Review", "confidence": 0.5, "analysis": "looks fine"},
        )

        events = _captured_payloads(mock_client.make_request)
        assert len(events) == 1
        assert events[0]["type"] == TaskUpdateEventType.Analyze.value
        assert events[0]["data"]["payload"]["input"]["analysis"] == "looks fine"


@pytest.mark.asyncio
async def test_report_reasoning_event_accepts_already_wrapped_input():
    task = _make_fake_task()
    with patch(
        "xpander_sdk.modules.backend.utils.tool_call_events.APIClient"
    ) as mock_api_cls:
        mock_client = mock_api_cls.return_value
        mock_client.make_request = AsyncMock(return_value=None)

        await report_reasoning_event(
            task=task,
            tool_name="think",
            arguments={"input": {"title": "T", "confidence": 1.0, "thought": "x"}},
        )

        events = _captured_payloads(mock_client.make_request)
        assert len(events) == 1
        assert events[0]["data"]["payload"]["input"]["title"] == "T"


@pytest.mark.asyncio
async def test_report_reasoning_event_ignores_unknown_tool():
    task = _make_fake_task()
    with patch(
        "xpander_sdk.modules.backend.utils.tool_call_events.APIClient"
    ) as mock_api_cls:
        mock_client = mock_api_cls.return_value
        mock_client.make_request = AsyncMock(return_value=None)

        await report_reasoning_event(
            task=task, tool_name="not_a_reasoning_tool", arguments={"x": 1}
        )

        assert mock_client.make_request.await_count == 0


# ---------------------------------------------------------------------------
# report_tool_call_request / report_tool_call_result
# ---------------------------------------------------------------------------


def _captured_payloads(mock_make_request) -> List[Dict[str, Any]]:
    """Collect the single event dict passed to each make_request call."""
    out = []
    for call in mock_make_request.await_args_list:
        kwargs = call.kwargs or {}
        payload = kwargs.get("payload")
        if isinstance(payload, list) and payload:
            out.append(payload[0])
    return out


@pytest.mark.asyncio
async def test_report_tool_call_coerces_string_json_payload_and_result():
    """Stringified JSON payloads / results should be reported as structured
    dicts in the activity event."""
    task = _make_fake_task()
    with patch(
        "xpander_sdk.modules.backend.utils.tool_call_events.APIClient"
    ) as mock_api_cls:
        mock_client = mock_api_cls.return_value
        mock_client.make_request = AsyncMock(return_value=None)

        await report_tool_call_request(
            task=task,
            request_id="req-json",
            operation_id="my_tool",
            payload='{"a": 1, "nested": {"b": [2, 3]}}',
        )
        await report_tool_call_result(
            task=task,
            request_id="req-json",
            operation_id="my_tool",
            # Python-literal style result, should still parse via ast.literal_eval.
            result="{'ok': True, 'items': [1, 2]}",
        )

        events = _captured_payloads(mock_client.make_request)
        assert len(events) == 2
        assert events[0]["data"]["payload"] == {"a": 1, "nested": {"b": [2, 3]}}
        assert events[1]["data"]["result"] == {"ok": True, "items": [1, 2]}


@pytest.mark.asyncio
async def test_report_request_and_result_push_correct_event_shapes():
    task = _make_fake_task()
    with patch(
        "xpander_sdk.modules.backend.utils.tool_call_events.APIClient"
    ) as mock_api_cls:
        mock_client = mock_api_cls.return_value
        mock_client.make_request = AsyncMock(return_value=None)

        await report_tool_call_request(
            task=task,
            request_id="req-1",
            operation_id="my_tool",
            tool_name="my_tool",
            payload={"x": 1},
        )
        await report_tool_call_result(
            task=task,
            request_id="req-1",
            operation_id="my_tool",
            tool_name="my_tool",
            payload={"x": 1},
            result={"ok": True},
            is_error=False,
        )

        events = _captured_payloads(mock_client.make_request)
        assert len(events) == 2
        assert events[0]["type"] == TaskUpdateEventType.ToolCallRequest.value
        assert events[1]["type"] == TaskUpdateEventType.ToolCallResult.value
        assert events[0]["data"]["request_id"] == "req-1"
        assert events[1]["data"]["request_id"] == "req-1"
        assert events[1]["data"]["is_error"] is False
        assert events[1]["data"]["result"] == {"ok": True}


@pytest.mark.asyncio
async def test_report_result_truncates_large_payload():
    task = _make_fake_task()
    big = "a" * (DEFAULT_MAX_CONTENT_LENGTH + 1000)
    with patch(
        "xpander_sdk.modules.backend.utils.tool_call_events.APIClient"
    ) as mock_api_cls:
        mock_client = mock_api_cls.return_value
        mock_client.make_request = AsyncMock(return_value=None)

        await report_tool_call_result(
            task=task,
            request_id="req-big",
            operation_id="my_tool",
            result=big,
        )

        events = _captured_payloads(mock_client.make_request)
        assert len(events) == 1
        result_field = events[0]["data"]["result"]
        assert "[TRUNCATED OUTPUT" in result_field
        assert len(result_field) < len(big)


@pytest.mark.asyncio
async def test_report_result_with_skip_truncation_keeps_full():
    """Reading a previously-offloaded CONTEXT_OPTIMIZATION file must not be
    re-truncated in the activity log; the agent explicitly asked for the
    full content.
    """
    task = _make_fake_task()
    big = "a" * (DEFAULT_MAX_CONTENT_LENGTH + 5_000)
    with patch(
        "xpander_sdk.modules.backend.utils.tool_call_events.APIClient"
    ) as mock_api_cls:
        mock_client = mock_api_cls.return_value
        mock_client.make_request = AsyncMock(return_value=None)

        await report_tool_call_result(
            task=task,
            request_id="req-full",
            operation_id="xpworkspace-file-read",
            result=big,
            skip_truncation=True,
        )

        events = _captured_payloads(mock_client.make_request)
        assert len(events) == 1
        result_field = events[0]["data"]["result"]
        assert result_field == big
        assert "[TRUNCATED OUTPUT" not in result_field


@pytest.mark.asyncio
async def test_report_push_failure_is_swallowed():
    task = _make_fake_task()
    with patch(
        "xpander_sdk.modules.backend.utils.tool_call_events.APIClient"
    ) as mock_api_cls:
        mock_client = mock_api_cls.return_value
        mock_client.make_request = AsyncMock(side_effect=RuntimeError("boom"))

        # Must not raise despite the backend failure.
        await report_tool_call_request(
            task=task,
            request_id="req-x",
            operation_id="my_tool",
        )
        await report_tool_call_result(
            task=task,
            request_id="req-x",
            operation_id="my_tool",
            result="done",
        )


# ---------------------------------------------------------------------------
# Tool.ainvoke with report_activity flag
# ---------------------------------------------------------------------------


def _make_local_tool(name: str = "greet") -> Any:
    from xpander_sdk.models.configuration import Configuration
    from xpander_sdk.modules.tools_repository.sub_modules.tool import Tool

    async def _fn(name: str):
        return f"hello {name}"

    return Tool(
        id=name,
        name=name,
        method="GET",
        path=f"/tools/{name}",
        is_local=True,
        is_synced=True,
        description=name,
        parameters={
            "type": "object",
            "properties": {"name": {"type": "string"}},
            "required": ["name"],
        },
        fn=_fn,
        configuration=Configuration(api_key="test", organization_id="org-1"),
    )


@pytest.mark.asyncio
async def test_tool_ainvoke_without_flag_does_not_emit():
    tool = _make_local_tool()
    task = _make_fake_task()
    tool.configuration.state.task = task

    with (
        patch(
            "xpander_sdk.modules.backend.utils.tool_call_events.APIClient"
        ) as mock_api_cls,
        patch.object(
            type(tool), "agraph_preflight_check", new=AsyncMock(return_value=None)
        ),
    ):
        mock_client = mock_api_cls.return_value
        mock_client.make_request = AsyncMock(return_value=None)

        result = await tool.ainvoke(
            agent_id="agent-1",
            payload={"name": "Moriel"},
            task_id=task.id,
            report_activity=False,
        )
        await _wait_for_background_tasks()

        assert result.is_success is True
        assert mock_client.make_request.await_count == 0


@pytest.mark.asyncio
async def test_tool_ainvoke_with_flag_emits_request_and_result_with_same_uuid():
    tool = _make_local_tool()
    task = _make_fake_task()
    tool.configuration.state.task = task

    with (
        patch(
            "xpander_sdk.modules.backend.utils.tool_call_events.APIClient"
        ) as mock_api_cls,
        patch.object(
            type(tool), "agraph_preflight_check", new=AsyncMock(return_value=None)
        ),
    ):
        mock_client = mock_api_cls.return_value
        mock_client.make_request = AsyncMock(return_value=None)

        await tool.ainvoke(
            agent_id="agent-1",
            payload={"name": "Moriel"},
            task_id=task.id,
            report_activity=True,
        )
        await _wait_for_background_tasks()

        events = _captured_payloads(mock_client.make_request)
        assert len(events) == 2
        assert events[0]["type"] == TaskUpdateEventType.ToolCallRequest.value
        assert events[1]["type"] == TaskUpdateEventType.ToolCallResult.value
        assert events[0]["data"]["request_id"] == events[1]["data"]["request_id"]
        assert events[1]["data"]["is_error"] is False


@pytest.mark.asyncio
async def test_tool_ainvoke_two_calls_produce_distinct_uuids():
    tool = _make_local_tool()
    task = _make_fake_task()
    tool.configuration.state.task = task

    with (
        patch(
            "xpander_sdk.modules.backend.utils.tool_call_events.APIClient"
        ) as mock_api_cls,
        patch.object(
            type(tool), "agraph_preflight_check", new=AsyncMock(return_value=None)
        ),
    ):
        mock_client = mock_api_cls.return_value
        mock_client.make_request = AsyncMock(return_value=None)

        await tool.ainvoke(
            agent_id="agent-1",
            payload={"name": "A"},
            task_id=task.id,
            report_activity=True,
        )
        await tool.ainvoke(
            agent_id="agent-1",
            payload={"name": "B"},
            task_id=task.id,
            report_activity=True,
        )
        await _wait_for_background_tasks()

        events = _captured_payloads(mock_client.make_request)
        # Two invocations => 4 events (request+result each).
        assert len(events) == 4
        request_events = [
            e for e in events if e["type"] == TaskUpdateEventType.ToolCallRequest.value
        ]
        uuids = {e["data"]["request_id"] for e in request_events}
        assert len(uuids) == 2


@pytest.mark.asyncio
async def test_tool_ainvoke_skips_planning_tools():
    """Deep-planning tools must never produce activity events, even with the flag on."""
    from xpander_sdk.models.configuration import Configuration
    from xpander_sdk.modules.tools_repository.sub_modules.tool import Tool

    async def _fn(**kwargs):
        return "ok"

    tool = Tool(
        id="xpcreate_agent_plan",
        name="xpcreate_agent_plan",
        method="GET",
        path="/tools/xpcreate_agent_plan",
        is_local=True,
        is_synced=True,
        description="create plan",
        parameters={
            "type": "object",
            "properties": {"x": {"type": "string"}},
        },
        fn=_fn,
        configuration=Configuration(api_key="test", organization_id="org-1"),
    )
    task = _make_fake_task()
    tool.configuration.state.task = task

    with (
        patch(
            "xpander_sdk.modules.backend.utils.tool_call_events.APIClient"
        ) as mock_api_cls,
        patch.object(
            type(tool), "agraph_preflight_check", new=AsyncMock(return_value=None)
        ),
    ):
        mock_client = mock_api_cls.return_value
        mock_client.make_request = AsyncMock(return_value=None)

        await tool.ainvoke(
            agent_id="agent-1",
            payload={"x": "y"},
            task_id=task.id,
            report_activity=True,
        )
        await _wait_for_background_tasks()

        assert mock_client.make_request.await_count == 0


@pytest.mark.asyncio
async def test_tool_ainvoke_reasoning_tool_emits_reasoning_event():
    """think/analyze called through Tool.ainvoke should produce a Think/Analyze
    activity event and no ToolCallRequest/ToolCallResult events.
    """
    from xpander_sdk.models.configuration import Configuration
    from xpander_sdk.modules.tools_repository.sub_modules.tool import Tool

    async def _fn(**kwargs):
        return "ok"

    tool = Tool(
        id="think",
        name="think",
        method="GET",
        path="/tools/think",
        is_local=True,
        is_synced=True,
        description="think",
        parameters={
            "type": "object",
            "properties": {
                "title": {"type": "string"},
                "confidence": {"type": "number"},
                "thought": {"type": "string"},
            },
        },
        fn=_fn,
        configuration=Configuration(api_key="test", organization_id="org-1"),
    )
    task = _make_fake_task()
    tool.configuration.state.task = task

    with (
        patch(
            "xpander_sdk.modules.backend.utils.tool_call_events.APIClient"
        ) as mock_api_cls,
        patch.object(
            type(tool), "agraph_preflight_check", new=AsyncMock(return_value=None)
        ),
    ):
        mock_client = mock_api_cls.return_value
        mock_client.make_request = AsyncMock(return_value=None)

        await tool.ainvoke(
            agent_id="agent-1",
            payload={"title": "X", "confidence": 1.0, "thought": "hmm"},
            task_id=task.id,
            report_activity=True,
        )
        await _wait_for_background_tasks()

        events = _captured_payloads(mock_client.make_request)
        # Exactly one Think event, no ToolCallRequest/ToolCallResult.
        assert len(events) == 1
        assert events[0]["type"] == TaskUpdateEventType.Think.value
        assert events[0]["data"]["payload"]["input"]["title"] == "X"


@pytest.mark.asyncio
async def test_tool_ainvoke_error_still_reports_is_error_true():
    from xpander_sdk.models.configuration import Configuration
    from xpander_sdk.modules.tools_repository.sub_modules.tool import Tool

    async def _failing(name: str):
        raise RuntimeError("boom")

    tool = Tool(
        id="boom",
        name="boom",
        method="GET",
        path="/tools/boom",
        is_local=True,
        is_synced=True,
        description="boom",
        parameters={
            "type": "object",
            "properties": {"name": {"type": "string"}},
            "required": ["name"],
        },
        fn=_failing,
        configuration=Configuration(api_key="test", organization_id="org-1"),
    )
    task = _make_fake_task()
    tool.configuration.state.task = task

    with (
        patch(
            "xpander_sdk.modules.backend.utils.tool_call_events.APIClient"
        ) as mock_api_cls,
        patch.object(
            type(tool), "agraph_preflight_check", new=AsyncMock(return_value=None)
        ),
    ):
        mock_client = mock_api_cls.return_value
        mock_client.make_request = AsyncMock(return_value=None)

        result = await tool.ainvoke(
            agent_id="agent-1",
            payload={"name": "Moriel"},
            task_id=task.id,
            report_activity=True,
        )
        await _wait_for_background_tasks()

        # The tool implementation catches exceptions into the result object,
        # so ainvoke returns rather than raising. The event must still be
        # emitted with is_error=True.
        assert result.is_error is True

        events = _captured_payloads(mock_client.make_request)
        result_events = [
            e for e in events if e["type"] == TaskUpdateEventType.ToolCallResult.value
        ]
        assert len(result_events) == 1
        assert result_events[0]["data"]["is_error"] is True
        assert "boom" in str(result_events[0]["data"]["result"])
