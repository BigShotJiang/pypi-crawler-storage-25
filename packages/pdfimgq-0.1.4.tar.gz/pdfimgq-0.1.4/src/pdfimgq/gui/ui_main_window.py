# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'main_windowVtLGTh.ui'
##
## Created by: Qt User Interface Compiler version 6.10.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QComboBox, QFrame,
    QGroupBox, QHBoxLayout, QHeaderView, QLabel,
    QLayout, QMainWindow, QMenuBar, QPlainTextEdit,
    QPushButton, QSizePolicy, QSpacerItem, QStatusBar,
    QTableWidget, QTableWidgetItem, QToolButton, QVBoxLayout,
    QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1280, 720)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(MainWindow.sizePolicy().hasHeightForWidth())
        MainWindow.setSizePolicy(sizePolicy)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.centralwidget.sizePolicy().hasHeightForWidth())
        self.centralwidget.setSizePolicy(sizePolicy1)
        self.verticalLayout_3 = QVBoxLayout(self.centralwidget)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.topPanelWidget = QWidget(self.centralwidget)
        self.topPanelWidget.setObjectName(u"topPanelWidget")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.topPanelWidget.sizePolicy().hasHeightForWidth())
        self.topPanelWidget.setSizePolicy(sizePolicy2)
        self.topPanelWidget.setMinimumSize(QSize(0, 40))
        self.topPanelWidget.setBaseSize(QSize(0, 0))
        self.horizontalLayout_2 = QHBoxLayout(self.topPanelWidget)
        self.horizontalLayout_2.setSpacing(0)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.selectInputButton = QPushButton(self.topPanelWidget)
        self.selectInputButton.setObjectName(u"selectInputButton")

        self.horizontalLayout.addWidget(self.selectInputButton)

        self.horizontalSpacer = QSpacerItem(6, 20, QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Minimum)

        self.horizontalLayout.addItem(self.horizontalSpacer)

        self.fileLabel = QLabel(self.topPanelWidget)
        self.fileLabel.setObjectName(u"fileLabel")

        self.horizontalLayout.addWidget(self.fileLabel)

        self.horizontalSpacer_3 = QSpacerItem(4, 20, QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Minimum)

        self.horizontalLayout.addItem(self.horizontalSpacer_3)

        self.fileComboBox = QComboBox(self.topPanelWidget)
        self.fileComboBox.setObjectName(u"fileComboBox")
        self.fileComboBox.setMinimumSize(QSize(250, 0))

        self.horizontalLayout.addWidget(self.fileComboBox)

        self.horizontalSpacer_5 = QSpacerItem(5, 20, QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Minimum)

        self.horizontalLayout.addItem(self.horizontalSpacer_5)

        self.selectOutputButton = QPushButton(self.topPanelWidget)
        self.selectOutputButton.setObjectName(u"selectOutputButton")

        self.horizontalLayout.addWidget(self.selectOutputButton)

        self.horizontalSpacer_4 = QSpacerItem(5, 20, QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Minimum)

        self.horizontalLayout.addItem(self.horizontalSpacer_4)

        self.runButton = QPushButton(self.topPanelWidget)
        self.runButton.setObjectName(u"runButton")
        self.runButton.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

        self.horizontalLayout.addWidget(self.runButton)

        self.horizontalSpacer_7 = QSpacerItem(5, 20, QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Minimum)

        self.horizontalLayout.addItem(self.horizontalSpacer_7)

        self.horizontalSpacer_2 = QSpacerItem(10, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout.addItem(self.horizontalSpacer_2)

        self.tagFilterButton = QPushButton(self.topPanelWidget)
        self.tagFilterButton.setObjectName(u"tagFilterButton")
        self.tagFilterButton.setEnabled(False)
        self.tagFilterButton.setStyleSheet(u"QPushButton::menu-indicator { image: none; width: 0px; }\n"
"")

        self.horizontalLayout.addWidget(self.tagFilterButton)

        self.horizontalSpacer_6 = QSpacerItem(5, 20, QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Minimum)

        self.horizontalLayout.addItem(self.horizontalSpacer_6)

        self.helpButton = QToolButton(self.topPanelWidget)
        self.helpButton.setObjectName(u"helpButton")
        self.helpButton.setAutoRaise(True)

        self.horizontalLayout.addWidget(self.helpButton)


        self.horizontalLayout_2.addLayout(self.horizontalLayout)


        self.verticalLayout.addWidget(self.topPanelWidget)

        self.resultsTableView = QTableWidget(self.centralwidget)
        self.resultsTableView.setObjectName(u"resultsTableView")
        sizePolicy1.setHeightForWidth(self.resultsTableView.sizePolicy().hasHeightForWidth())
        self.resultsTableView.setSizePolicy(sizePolicy1)
        self.resultsTableView.setMinimumSize(QSize(0, 100))

        self.verticalLayout.addWidget(self.resultsTableView)

        self.detailWidget = QWidget(self.centralwidget)
        self.detailWidget.setObjectName(u"detailWidget")
        sizePolicy2.setHeightForWidth(self.detailWidget.sizePolicy().hasHeightForWidth())
        self.detailWidget.setSizePolicy(sizePolicy2)
        self.detailWidget.setMinimumSize(QSize(0, 0))
        self.horizontalLayout_3 = QHBoxLayout(self.detailWidget)
        self.horizontalLayout_3.setSpacing(0)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_4 = QHBoxLayout()
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalLayout_4.setSizeConstraint(QLayout.SizeConstraint.SetDefaultConstraint)
        self.horizontalLayout_4.setContentsMargins(-1, -1, -1, 0)
        self.selectedImageGroupBox = QGroupBox(self.detailWidget)
        self.selectedImageGroupBox.setObjectName(u"selectedImageGroupBox")
        sizePolicy2.setHeightForWidth(self.selectedImageGroupBox.sizePolicy().hasHeightForWidth())
        self.selectedImageGroupBox.setSizePolicy(sizePolicy2)
        self.selectedImageGroupBox.setMinimumSize(QSize(0, 0))
        self.verticalLayout_2 = QVBoxLayout(self.selectedImageGroupBox)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.horizontalLayout_5 = QHBoxLayout()
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.imagePreviewLabel = QLabel(self.selectedImageGroupBox)
        self.imagePreviewLabel.setObjectName(u"imagePreviewLabel")
        sizePolicy1.setHeightForWidth(self.imagePreviewLabel.sizePolicy().hasHeightForWidth())
        self.imagePreviewLabel.setSizePolicy(sizePolicy1)
        self.imagePreviewLabel.setMinimumSize(QSize(0, 0))
        self.imagePreviewLabel.setFrameShape(QFrame.Shape.Box)
        self.imagePreviewLabel.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_5.addWidget(self.imagePreviewLabel)

        self.imageInfoTable = QTableWidget(self.selectedImageGroupBox)
        if (self.imageInfoTable.columnCount() < 2):
            self.imageInfoTable.setColumnCount(2)
        self.imageInfoTable.setObjectName(u"imageInfoTable")
        self.imageInfoTable.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.imageInfoTable.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self.imageInfoTable.setColumnCount(2)
        self.imageInfoTable.horizontalHeader().setVisible(False)
        self.imageInfoTable.verticalHeader().setVisible(False)

        self.horizontalLayout_5.addWidget(self.imageInfoTable)


        self.verticalLayout_2.addLayout(self.horizontalLayout_5)


        self.horizontalLayout_4.addWidget(self.selectedImageGroupBox)

        self.recommendationsGroupBox = QGroupBox(self.detailWidget)
        self.recommendationsGroupBox.setObjectName(u"recommendationsGroupBox")
        sizePolicy2.setHeightForWidth(self.recommendationsGroupBox.sizePolicy().hasHeightForWidth())
        self.recommendationsGroupBox.setSizePolicy(sizePolicy2)
        self.recommendationsGroupBox.setMinimumSize(QSize(0, 0))
        self.verticalLayout_5 = QVBoxLayout(self.recommendationsGroupBox)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.recommendationTextEdit = QPlainTextEdit(self.recommendationsGroupBox)
        self.recommendationTextEdit.setObjectName(u"recommendationTextEdit")
        sizePolicy2.setHeightForWidth(self.recommendationTextEdit.sizePolicy().hasHeightForWidth())
        self.recommendationTextEdit.setSizePolicy(sizePolicy2)
        self.recommendationTextEdit.setMinimumSize(QSize(0, 0))
        self.recommendationTextEdit.setReadOnly(True)

        self.verticalLayout_5.addWidget(self.recommendationTextEdit)


        self.horizontalLayout_4.addWidget(self.recommendationsGroupBox)

        self.horizontalLayout_4.setStretch(0, 2)
        self.horizontalLayout_4.setStretch(1, 1)

        self.horizontalLayout_3.addLayout(self.horizontalLayout_4)


        self.verticalLayout.addWidget(self.detailWidget)

        self.verticalLayout.setStretch(1, 1)

        self.verticalLayout_3.addLayout(self.verticalLayout)

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 1280, 33))
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.selectInputButton.setText(QCoreApplication.translate("MainWindow", u"Select PDFs", None))
        self.fileLabel.setText(QCoreApplication.translate("MainWindow", u"PDF:", None))
        self.selectOutputButton.setText(QCoreApplication.translate("MainWindow", u"Output folder", None))
        self.runButton.setText(QCoreApplication.translate("MainWindow", u"Analyze", None))
        self.tagFilterButton.setText(QCoreApplication.translate("MainWindow", u"Filter tags", None))
        self.helpButton.setText(QCoreApplication.translate("MainWindow", u"?", None))
        self.selectedImageGroupBox.setTitle(QCoreApplication.translate("MainWindow", u"Selected image", None))
        self.imagePreviewLabel.setText("")
        self.recommendationsGroupBox.setTitle(QCoreApplication.translate("MainWindow", u"Recommendations", None))
    # retranslateUi

