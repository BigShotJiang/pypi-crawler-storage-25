from __future__ import annotations
from PIL import Image
from PIL.Image import Resampling
import numpy as np


MAX_METRIC_PIXELS = 1_000_000


def to_rgb(im: Image.Image) -> Image.Image:
    if im.mode != "RGB":
        rgb = im.convert("RGB")
    else:
        rgb = im
    return rgb


def downscale_for_metrics(im: Image.Image, max_pixels: int = MAX_METRIC_PIXELS) -> Image.Image:
    w, h = im.size
    if w * h <= max_pixels:
        return im
    scale = (max_pixels / (w * h)) ** 0.5
    new_w = max(1, int(w * scale))
    new_h = max(1, int(h * scale))
    return im.resize((new_w, new_h), Resampling.BOX)


def is_effectively_grayscale_from_pil(
    im: Image.Image,
    *,
    tolerance: int = 3,
    max_colored_ratio: float = 0.01,
) -> bool:
    sample = downscale_for_metrics(im)
    arr = np.asarray(to_rgb(sample), dtype=np.int16)

    if arr.size == 0:
        return True

    channel_range = arr.max(axis=2) - arr.min(axis=2)
    colored_pixels = int(np.count_nonzero(channel_range > tolerance))
    total_pixels = int(channel_range.size) or 1
    colored_ratio = colored_pixels / total_pixels

    return colored_ratio <= max_colored_ratio