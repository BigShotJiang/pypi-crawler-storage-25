from __future__ import annotations
from PIL import Image
from .tones import compute_tone_metrics_from_pil   # (shadow, highlight, contrast)
from .color import compute_color_metrics_from_pil  # (colorfulness_hs, color_richness_pct)
from .common import downscale_for_metrics

def compute_all_metrics_from_pil(pil: Image.Image) -> tuple[float, float, float, float, float]:
    pil_small = downscale_for_metrics(pil)
    sh, hi, co = compute_tone_metrics_from_pil(pil_small)
    cf, cr = compute_color_metrics_from_pil(pil_small)
    return sh, hi, co, cf, cr
