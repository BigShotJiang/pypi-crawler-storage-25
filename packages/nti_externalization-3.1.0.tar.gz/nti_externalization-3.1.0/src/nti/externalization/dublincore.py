#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Externalization support for things that implement the interfaces
of :mod:`zope.dublincore.interfaces`.

.. note::
   We are "namespacing" the dublincore properties, since they have
   defined meanings we don't control. We are currently doing this by simply prefixing
   them with 'DC' for ease of access in JavaScript.

These objects are typically used as decorators, registered
from ZCML.

"""

from zope import component
from zope import interface
try:
    from zope.dublincore.interfaces import IDCDescriptiveProperties
    from zope.dublincore.interfaces import IDCExtended
except ModuleNotFoundError:
    # pylint:disable=inherit-non-class
    class IDCDescriptiveProperties(interface.Interface): # type:ignore[no-redef]
        """Mock"""
    class IDCExtended(interface.Interface): # type:ignore[no-redef]
        """Mock"""

from nti.externalization.interfaces import IExternalStandardDictionaryDecorator
from nti.externalization.interfaces import StandardExternalFields
from nti.externalization.singleton import Singleton

__all__ = [
    'DCExtendedExternalMappingDecorator',
    'DCDescriptivePropertiesExternalMappingDecorator',
]

# Note that its fairly common for things to claim to implement these interfaces,
# but only provide a subset of the properties. (mostly due to programming errors).
# Hence the use of getattr below, to protect against this.
@component.adapter(IDCExtended)
@interface.implementer(IExternalStandardDictionaryDecorator)
class DCExtendedExternalMappingDecorator(Singleton):
    """
    Adds the extended properties of dublincore to external objects as
    defined by :class:`zope.dublincore.interfaces.IDCExtended`.

    .. note::

        We are currently only mapping 'Creator' since that's the
        only field that ever gets populated.

    Implements
    `~nti.externalization.interfaces.IExternalStandardDictionaryDecorator` for
    :class:`zope.dublincore.interfaces.IDCExtended` objects.
    """

    def decorateExternalMapping(self, original, external):
        creators = getattr(original, 'creators', None)
        if 'DCCreator' not in external:
            external['DCCreator'] = creators
        if StandardExternalFields.CREATOR not in external and creators:
            external[StandardExternalFields.CREATOR] = creators[0]


@component.adapter(IDCDescriptiveProperties)
@interface.implementer(IExternalStandardDictionaryDecorator)
class DCDescriptivePropertiesExternalMappingDecorator(Singleton):
    """
    Supports the 'DCTitle' and 'DCDescription' fields, as defined in
    :class:`zope.dublincore.interfaces.IDCDescriptiveProperties`.

    Implements
    `~nti.externalization.interfaces.IExternalStandardDictionaryDecorator`.
    """

    def decorateExternalMapping(self, original, external):
        if 'DCTitle' not in external:
            external['DCTitle'] = getattr(original, 'title', None)
        if 'DCDescription' not in external:
            external['DCDescription'] = getattr(original, 'description', None)
