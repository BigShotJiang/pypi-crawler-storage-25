#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Tests for oids.py.
"""


import unittest

from zope.testing.cleanup import CleanUp

from hamcrest import assert_that
from hamcrest import is_

from ..oids import fromExternalOID
from ..oids import toExternalOID


class TestToExternalOID(CleanUp,
                        unittest.TestCase):

    def test_add_to_connection(self):
        from zope.interface import implementer
        try:
            from ZODB.interfaces import IConnection
        except ModuleNotFoundError:
            self.skipTest('ZODB not installed')

        @implementer(IConnection)
        class Persistent(object):
            _p_oid = None

            database_name = 'main'
            def add(self, obj):
                obj._p_oid = b'abc' # pylint:disable=protected-access

            def db(self):
                return self


        result = toExternalOID(Persistent(), add_to_connection=True)
        assert_that(result, is_(b'0x616263:6d61696e'))

    def test_add_to_connection_no_connection(self):
        class Persistent(object):
            _p_oid = None

        result = toExternalOID(Persistent(), add_to_connection=True, default='default')
        assert_that(result, is_('default'))

    def test_intid(self):
        from zope import component
        from zope.interface import implementer
        try:
            from zope.intid.interfaces import IIntIds
        except ModuleNotFoundError:
            self.skipTest('Intids not installed')

        @implementer(IIntIds)
        class IntIds(object):

            def queryId(self, _obj):
                return None

            def register(self, _obj):
                return 1

        class Persistent(object):
            _p_oid = b'abc'

        component.provideUtility(IntIds())
        result = toExternalOID(Persistent(), add_to_intids=True)
        assert_that(result, is_(b'0x616263::y'))

class TestFromExternalOID(unittest.TestCase):

    def test_with_intid(self):

        oid, db_name, intid = fromExternalOID(b'0x616263::y')
        assert_that(oid, is_(b'\x00\x00\x00\x00\x00abc'))
        assert_that(db_name, is_(b''))
        assert_that(intid, is_(1))
