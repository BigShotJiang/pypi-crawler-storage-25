"""Default configuration templates."""

DEFAULT_CONFIG_TEMPLATE = """base: ./base.yaml
output: ./config.yaml
preserve-base-proxies: false

sources:
  - name: provider-a
    path: ./profiles/provider-a.yaml
  - name: provider-b
    path: ./profiles/provider-b.yaml

regions:
  日本: [日本, JP, Japan, Tokyo, 东京]
  新加坡: [新加坡, SG, Singapore, 狮城]
  香港: [香港, 港, HK, Hong Kong]
  台湾: [台湾, 台, TW, Taiwan]
  美国: [美国, US, USA, United States, 洛杉矶, LA]
  加拿大: [加拿大, CA, Canada]
  英国: [英国, UK, GB, United Kingdom, London, 伦敦]
  德国: [德国, DE, Germany]

exclude:
  contains: [流量, 到期, 过期, 官网, 套餐, 剩余, 网址, 群组]

naming: "{source}-{region}-{number}"

proxy-groups:
  - name: 节点选择
    type: select
    proxies:
      - 区域-日本
      - 区域-新加坡
      - 区域-香港
      - 区域-台湾
      - 区域-美国
      - 区域-加拿大
      - 区域-英国
      - 区域-德国
      - DIRECT

  - name: 区域-日本
    type: fallback
    url: https://www.gstatic.com/generate_204
    interval: 300
    proxies:
      - "@region:日本"

  - name: 区域-新加坡
    type: fallback
    url: https://www.gstatic.com/generate_204
    interval: 300
    proxies:
      - "@region:新加坡"

  - name: 区域-香港
    type: fallback
    url: https://www.gstatic.com/generate_204
    interval: 300
    proxies:
      - "@region:香港"

  - name: 区域-台湾
    type: fallback
    url: https://www.gstatic.com/generate_204
    interval: 300
    proxies:
      - "@region:台湾"

  - name: 区域-美国
    type: fallback
    url: https://www.gstatic.com/generate_204
    interval: 300
    proxies:
      - "@region:美国"

  - name: 区域-加拿大
    type: fallback
    url: https://www.gstatic.com/generate_204
    interval: 300
    proxies:
      - "@region:加拿大"

  - name: 区域-英国
    type: fallback
    url: https://www.gstatic.com/generate_204
    interval: 300
    proxies:
      - "@region:英国"

  - name: 区域-德国
    type: fallback
    url: https://www.gstatic.com/generate_204
    interval: 300
    proxies:
      - "@region:德国"
"""
