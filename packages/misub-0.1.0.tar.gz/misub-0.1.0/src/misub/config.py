"""Configuration loading helpers."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml
from ruamel.yaml import YAML
from ruamel.yaml.comments import CommentedMap


class ConfigError(Exception):
    """Raised when a configuration or YAML file cannot be loaded."""


def load_yaml(path: Path, *, label: str) -> dict[str, Any]:
    """Load a YAML mapping from disk."""
    if not path.exists():
        raise ConfigError(f"{label} 不存在: {path}")
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
    except yaml.YAMLError as exc:
        raise ConfigError(f"{label} YAML 无法解析: {path}: {exc}") from exc
    except OSError as exc:
        raise ConfigError(f"{label} 无法读取: {path}: {exc}") from exc

    if data is None:
        return {}
    if not isinstance(data, dict):
        raise ConfigError(f"{label} 必须是 YAML 映射: {path}")
    return data


def create_round_trip_yaml() -> YAML:
    """Create a ruamel.yaml instance that preserves loaded YAML presentation."""
    round_trip_yaml = YAML()
    round_trip_yaml.preserve_quotes = True
    round_trip_yaml.default_flow_style = False
    round_trip_yaml.width = 4096
    return round_trip_yaml


def load_yaml_round_trip(path: Path, *, label: str) -> CommentedMap:
    """Load a YAML mapping while preserving comments and scalar styles."""
    if not path.exists():
        raise ConfigError(f"{label} 不存在: {path}")
    round_trip_yaml = create_round_trip_yaml()
    try:
        data = round_trip_yaml.load(path)
    except Exception as exc:
        raise ConfigError(f"{label} YAML 无法解析: {path}: {exc}") from exc

    if data is None:
        return CommentedMap()
    if not isinstance(data, dict):
        raise ConfigError(f"{label} 必须是 YAML 映射: {path}")
    return data


def dump_yaml_round_trip(data: Any, path: Path) -> None:
    """Dump YAML while keeping presentation styles loaded by ruamel.yaml."""
    round_trip_yaml = create_round_trip_yaml()
    round_trip_yaml.dump(data, path)


def resolve_path(config_dir: Path, value: str | Path, *, field: str) -> Path:
    """Resolve relative paths against the directory containing misub.yaml."""
    if not value:
        raise ConfigError(f"配置缺少 {field}")
    path = Path(value).expanduser()
    if path.is_absolute():
        return path
    return config_dir / path
