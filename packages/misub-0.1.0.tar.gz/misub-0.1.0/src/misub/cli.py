"""Command line interface for misub."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Sequence

from .build import BuildError, build
from .templates import DEFAULT_CONFIG_TEMPLATE


def main(argv: Sequence[str] | None = None) -> int:
    parser = _create_parser()
    args = parser.parse_args(argv)

    if args.command == "init":
        return _init_config(Path(args.output), force=args.force)
    if args.command == "build":
        return _build_config(Path(args.config))

    parser.print_help()
    return 0


def _create_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="misub", description="Build local Mihomo subscriptions into one config.yaml")
    subparsers = parser.add_subparsers(dest="command")

    init_parser = subparsers.add_parser("init", help="在当前目录生成默认 misub.yaml")
    init_parser.add_argument("-o", "--output", default="misub.yaml", help="输出配置模板路径，默认 misub.yaml")
    init_parser.add_argument("-f", "--force", action="store_true", help="允许覆盖已存在的配置文件")

    build_parser = subparsers.add_parser("build", help="根据 misub.yaml 构建最终配置")
    build_parser.add_argument("-c", "--config", default="misub.yaml", help="构建配置文件路径，默认 misub.yaml")

    return parser


def _init_config(output: Path, *, force: bool = False) -> int:
    if output.exists() and not force:
        print(f"错误: {output} 已存在，使用 --force 覆盖", file=sys.stderr)
        return 1
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(DEFAULT_CONFIG_TEMPLATE, encoding="utf-8")
    print(f"已生成: {output}")
    return 0


def _build_config(config: Path) -> int:
    try:
        build(config)
    except BuildError as exc:
        print(f"错误: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
