"""Build final Mihomo configuration files from local subscriptions."""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ruamel.yaml.comments import CommentedMap, CommentedSeq

from .classify import UNRECOGNIZED_REGION, classify_region, extract_number, should_exclude
from .config import ConfigError, dump_yaml_round_trip, load_yaml, load_yaml_round_trip, resolve_path


class BuildError(Exception):
    """Raised when the build cannot safely produce a config."""


@dataclass(frozen=True)
class BuildSummary:
    sources_read: int
    kept: int
    filtered: int
    unrecognized: int
    output: Path


@dataclass(frozen=True)
class NodeRecord:
    name: str
    source: str
    region: str
    proxy: dict[str, Any]


def build(config_path: str | Path = "misub.yaml") -> BuildSummary:
    """Build a Mihomo config from a misub YAML config file."""
    config_path = Path(config_path).expanduser()
    config_dir = config_path.parent if config_path.parent != Path("") else Path.cwd()

    try:
        config = load_yaml(config_path, label="配置文件")
        base_path = resolve_path(config_dir, config.get("base"), field="base")
        output_path = resolve_path(config_dir, config.get("output"), field="output")
        base_config = load_yaml_round_trip(base_path, label="base")
    except ConfigError as exc:
        raise BuildError(str(exc)) from exc

    proxy_groups = config.get("proxy-groups", [])
    if not isinstance(proxy_groups, list):
        raise BuildError("proxy-groups 必须是列表")

    sources = config.get("sources", [])
    if not isinstance(sources, list):
        raise BuildError("sources 必须是列表")

    regions = config.get("regions", {}) or {}
    if not isinstance(regions, dict):
        raise BuildError("regions 必须是映射")

    exclude = config.get("exclude", {}) or {}
    if not isinstance(exclude, dict):
        raise BuildError("exclude 必须是映射")
    exclude_contains = exclude.get("contains", []) or []

    naming = config.get("naming", "{source}-{region}-{number}")
    preserve_base_proxies = bool(config.get("preserve-base-proxies", False))

    records: list[NodeRecord] = []
    filtered = 0
    generated_counters: dict[tuple[str, str], int] = defaultdict(int)
    used_names: dict[str, int] = {}
    base_proxies = _get_base_proxies(base_config) if preserve_base_proxies else []
    for proxy in base_proxies:
        used_names[str(proxy["name"])] = 1

    for source in sources:
        if not isinstance(source, dict):
            raise BuildError("sources 中的每一项必须是映射")
        source_name = source.get("name")
        if not source_name:
            raise BuildError("sources[].name 不能为空")
        source_path = resolve_path(config_dir, source.get("path"), field=f"sources[{source_name}].path")
        try:
            source_data = load_yaml(source_path, label=f"订阅 {source_name}")
        except ConfigError as exc:
            raise BuildError(str(exc)) from exc

        proxies = source_data.get("proxies", [])
        if proxies is None:
            proxies = []
        if not isinstance(proxies, list):
            raise BuildError(f"订阅 {source_name} 的 proxies 必须是列表")
        if "proxies" not in source_data:
            print(f"警告: 订阅 {source_name} 缺少 proxies，视为空节点来源")

        for proxy in proxies:
            if not isinstance(proxy, dict):
                raise BuildError(f"订阅 {source_name} 中存在非映射节点")
            original_name = proxy.get("name")
            if not original_name:
                raise BuildError(f"订阅 {source_name} 中存在缺少 name 的节点")
            original_name = str(original_name)
            if should_exclude(original_name, exclude_contains):
                filtered += 1
                continue

            region = classify_region(original_name, regions)
            number = extract_number(original_name)
            if number is None:
                generated_counters[(str(source_name), region)] += 1
                number = f"{generated_counters[(str(source_name), region)]:03d}"
            new_name = _format_name(naming, source=str(source_name), region=region, number=number)
            new_name = _deduplicate_name(new_name, used_names)
            renamed_proxy = dict(proxy)
            renamed_proxy["name"] = new_name
            records.append(NodeRecord(name=new_name, source=str(source_name), region=region, proxy=renamed_proxy))

    rendered_groups = _expand_proxy_groups(proxy_groups, records)

    for key in ("proxies", "proxy-groups"):
        if key in base_config:
            del base_config[key]
    base_config["proxies"] = _to_block_sequence_of_flow_items(base_proxies + [record.proxy for record in records])
    base_config["proxy-groups"] = _to_block_sequence_of_flow_items(rendered_groups)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    dump_yaml_round_trip(base_config, output_path)

    unrecognized = sum(1 for record in records if record.region == UNRECOGNIZED_REGION)
    if unrecognized:
        print(f"警告: {unrecognized} 个节点未识别地区，已归入 未识别")

    summary = BuildSummary(
        sources_read=len(sources),
        kept=len(records),
        filtered=filtered,
        unrecognized=unrecognized,
        output=output_path,
    )
    print(
        f"读取 {summary.sources_read} 个订阅，保留 {summary.kept} 个节点，"
        f"过滤 {summary.filtered} 个节点，未识别地区 {summary.unrecognized} 个"
    )
    print(f"输出: {output_path}")
    return summary


def _get_base_proxies(base_config: dict[str, Any]) -> list[dict[str, Any]]:
    proxies = base_config.get("proxies", []) or []
    if not isinstance(proxies, list):
        raise BuildError("base 中的 proxies 必须是列表")

    base_proxies: list[dict[str, Any]] = []
    for proxy in proxies:
        if not isinstance(proxy, dict):
            raise BuildError("base 中存在非映射节点")
        if not proxy.get("name"):
            raise BuildError("base 中存在缺少 name 的节点")
        base_proxies.append(proxy)
    return base_proxies


def _to_block_sequence_of_flow_items(items: list[Any]) -> CommentedSeq:
    sequence = CommentedSeq()
    for item in items:
        sequence.append(_to_flow_style(item))
    return sequence


def _to_flow_style(value: Any) -> Any:
    if isinstance(value, dict):
        mapping = CommentedMap()
        for key, item in value.items():
            mapping[key] = _to_flow_style(item)
        mapping.fa.set_flow_style()
        return mapping
    if isinstance(value, list):
        sequence = CommentedSeq(_to_flow_style(item) for item in value)
        sequence.fa.set_flow_style()
        return sequence
    return value


def _format_name(template: str, *, source: str, region: str, number: str) -> str:
    try:
        return template.format(source=source, region=region, number=number)
    except KeyError as exc:
        raise BuildError(f"naming 包含未知字段: {exc.args[0]}") from exc


def _deduplicate_name(name: str, used_names: dict[str, int]) -> str:
    if name not in used_names:
        used_names[name] = 1
        return name
    used_names[name] += 1
    deduplicated = f"{name}-{used_names[name]}"
    while deduplicated in used_names:
        used_names[name] += 1
        deduplicated = f"{name}-{used_names[name]}"
    used_names[deduplicated] = 1
    return deduplicated


def _expand_proxy_groups(groups: list[dict[str, Any]], records: list[NodeRecord]) -> list[dict[str, Any]]:
    all_names = [record.name for record in records]
    by_region: dict[str, list[str]] = defaultdict(list)
    by_source: dict[str, list[str]] = defaultdict(list)
    for record in records:
        by_region[record.region].append(record.name)
        by_source[record.source].append(record.name)

    rendered_groups: list[dict[str, Any]] = []
    for group in groups:
        if not isinstance(group, dict):
            raise BuildError("proxy-groups 中的每一项必须是映射")
        rendered = dict(group)
        proxies = rendered.get("proxies", [])
        if not isinstance(proxies, list):
            raise BuildError(f"代理组 {rendered.get('name', '<unnamed>')} 的 proxies 必须是列表")
        rendered["proxies"] = _expand_proxy_list(proxies, all_names, by_region, by_source)
        rendered_groups.append(rendered)
    return rendered_groups


def _expand_proxy_list(
    proxies: list[Any],
    all_names: list[str],
    by_region: dict[str, list[str]],
    by_source: dict[str, list[str]],
) -> list[str]:
    expanded: list[str] = []
    for item in proxies:
        if not isinstance(item, str):
            raise BuildError("proxy-groups[].proxies 只能包含字符串")
        if item == "@all":
            _append_placeholder(expanded, all_names, item)
        elif item.startswith("@region:"):
            _append_placeholder(expanded, by_region[item.removeprefix("@region:")], item)
        elif item.startswith("@source:"):
            _append_placeholder(expanded, by_source[item.removeprefix("@source:")], item)
        elif item.startswith("@"):
            raise BuildError(f"未知占位符: {item}")
        else:
            expanded.append(item)
    return expanded


def _append_placeholder(target: list[str], names: list[str], placeholder: str) -> None:
    if names:
        target.extend(names)
    else:
        print(f"警告: {placeholder} 没有匹配到节点")
