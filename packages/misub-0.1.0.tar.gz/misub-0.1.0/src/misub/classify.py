"""Node filtering and classification helpers."""

from __future__ import annotations

import re
from collections.abc import Mapping, Sequence

UNRECOGNIZED_REGION = "未识别"


def should_exclude(name: str, contains: Sequence[str] | None) -> bool:
    """Return whether a node name contains any configured exclusion word."""
    if not contains:
        return False
    return any(word and word in name for word in contains)


def classify_region(name: str, regions: Mapping[str, Sequence[str]] | None) -> str:
    """Classify a node by configured region aliases.

    Matching is case-insensitive. If multiple regions match, mapping order wins.
    """
    if not regions:
        return UNRECOGNIZED_REGION

    lowered_name = name.casefold()
    for region, aliases in regions.items():
        for alias in aliases or []:
            if str(alias).casefold() in lowered_name:
                return region
    return UNRECOGNIZED_REGION


def extract_number(name: str) -> str | None:
    """Extract the last numeric token from a node name, preserving padding."""
    numbers = re.findall(r"\d+", name)
    return numbers[-1] if numbers else None
