from pathlib import Path

import pytest
import yaml

from misub.build import BuildError, build


def write_yaml(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(data, allow_unicode=True, sort_keys=False), encoding="utf-8")


def test_build_merges_sources_filters_renames_and_expands_groups(tmp_path, capsys):
    write_yaml(
        tmp_path / "base.yaml",
        {
            "mixed-port": 7890,
            "mode": "rule",
            "proxies": [{"name": "old", "type": "ss", "server": "old.example"}],
            "proxy-groups": [{"name": "old-group", "type": "select", "proxies": ["old"]}],
            "rules": ["MATCH,节点选择"],
        },
    )
    write_yaml(
        tmp_path / "profiles" / "a.yaml",
        {
            "proxies": [
                {"name": "日本 03", "type": "ss", "server": "node-jp-a.example", "port": 443},
                {"name": "套餐剩余流量", "type": "ss", "server": "info-node.example", "port": 443},
                {"name": "Moon Base", "type": "ss", "server": "node-unmatched.example", "port": 443},
            ]
        },
    )
    write_yaml(
        tmp_path / "profiles" / "b.yaml",
        {
            "proxies": [
                {"name": "香港 03", "type": "ss", "server": "node-hk-b.example", "port": 443},
                {"name": "JP 03", "type": "ss", "server": "node-jp-b.example", "port": 443},
            ]
        },
    )
    write_yaml(
        tmp_path / "misub.yaml",
        {
            "base": "./base.yaml",
            "output": "./config.yaml",
            "sources": [
                {"name": "provider-a", "path": "./profiles/a.yaml"},
                {"name": "provider-b", "path": "./profiles/b.yaml"},
            ],
            "regions": {"日本": ["日本", "JP"], "香港": ["香港", "HK"]},
            "exclude": {"contains": ["流量"]},
            "naming": "{source}-{region}-{number}",
            "proxy-groups": [
                {"name": "节点选择", "type": "select", "proxies": ["@all", "DIRECT"]},
                {"name": "区域-日本", "type": "fallback", "proxies": ["@region:日本"]},
                {"name": "机场-provider-a", "type": "select", "proxies": ["@source:provider-a"]},
                {"name": "区域-德国", "type": "select", "proxies": ["@region:德国", "DIRECT"]},
            ],
        },
    )

    summary = build(tmp_path / "misub.yaml")

    output = yaml.safe_load((tmp_path / "config.yaml").read_text(encoding="utf-8"))
    names = [proxy["name"] for proxy in output["proxies"]]
    assert output["mixed-port"] == 7890
    assert output["mode"] == "rule"
    assert output["rules"] == ["MATCH,节点选择"]
    assert names == ["provider-a-日本-03", "provider-a-未识别-001", "provider-b-香港-03", "provider-b-日本-03"]
    assert output["proxy-groups"][0]["proxies"] == names + ["DIRECT"]
    assert output["proxy-groups"][1]["proxies"] == ["provider-a-日本-03", "provider-b-日本-03"]
    assert output["proxy-groups"][2]["proxies"] == ["provider-a-日本-03", "provider-a-未识别-001"]
    assert output["proxy-groups"][3]["proxies"] == ["DIRECT"]
    assert summary.sources_read == 2
    assert summary.kept == 4
    assert summary.filtered == 1
    assert summary.unrecognized == 1
    captured = capsys.readouterr()
    assert "警告: @region:德国 没有匹配到节点" in captured.out
    assert "警告: 1 个节点未识别地区，已归入 未识别" in captured.out
    assert "读取 2 个订阅，保留 4 个节点，过滤 1 个节点，未识别地区 1 个" in captured.out


def test_build_preserves_base_proxies_when_configured(tmp_path):
    write_yaml(
        tmp_path / "base.yaml",
        {
            "proxies": [{"name": "manual-home", "type": "socks5", "server": "home.example", "port": 1080}],
            "rules": ["IN-USER,home,manual-home", "MATCH,节点选择"],
        },
    )
    write_yaml(
        tmp_path / "profile.yaml",
        {"proxies": [{"name": "日本 01", "type": "ss", "server": "node-a.example", "port": 443}]},
    )
    write_yaml(
        tmp_path / "misub.yaml",
        {
            "base": "./base.yaml",
            "output": "./config.yaml",
            "preserve-base-proxies": True,
            "sources": [{"name": "provider-a", "path": "./profile.yaml"}],
            "regions": {"日本": ["日本"]},
            "proxy-groups": [{"name": "节点选择", "type": "select", "proxies": ["@all", "DIRECT"]}],
        },
    )

    build(tmp_path / "misub.yaml")

    output = yaml.safe_load((tmp_path / "config.yaml").read_text(encoding="utf-8"))
    assert [proxy["name"] for proxy in output["proxies"]] == ["manual-home", "provider-a-日本-01"]
    assert output["rules"] == ["IN-USER,home,manual-home", "MATCH,节点选择"]


def test_build_writes_generated_nodes_and_groups_as_single_line_items(tmp_path):
    write_yaml(tmp_path / "base.yaml", {"mixed-port": 7890})
    write_yaml(
        tmp_path / "profile.yaml",
        {"proxies": [{"name": "日本 01", "type": "ss", "server": "node-a.example", "port": 443}]},
    )
    write_yaml(
        tmp_path / "misub.yaml",
        {
            "base": "./base.yaml",
            "output": "./config.yaml",
            "sources": [{"name": "provider-a", "path": "./profile.yaml"}],
            "regions": {"日本": ["日本"]},
            "proxy-groups": [{"name": "节点选择", "type": "select", "proxies": ["@all", "DIRECT"]}],
        },
    )

    build(tmp_path / "misub.yaml")

    output_text = (tmp_path / "config.yaml").read_text(encoding="utf-8")
    assert "- {name: provider-a-日本-01, type: ss, server: node-a.example, port: 443}" in output_text
    assert "- {name: 节点选择, type: select, proxies: [provider-a-日本-01, DIRECT]}" in output_text


def test_build_preserves_block_scalar_style_from_base_yaml(tmp_path):
    (tmp_path / "base.yaml").write_text(
        """mixed-port: 7890
description: >
  line one
  line two
script:
  code: |
    def main():
      return "DIRECT"
""",
        encoding="utf-8",
    )
    write_yaml(tmp_path / "profile.yaml", {"proxies": []})
    write_yaml(
        tmp_path / "misub.yaml",
        {
            "base": "./base.yaml",
            "output": "./config.yaml",
            "sources": [{"name": "provider-a", "path": "./profile.yaml"}],
            "regions": {},
            "proxy-groups": [],
        },
    )

    build(tmp_path / "misub.yaml")

    output_text = (tmp_path / "config.yaml").read_text(encoding="utf-8")
    assert "description: >" in output_text
    assert "code: |" in output_text


def test_build_raises_for_unknown_placeholder(tmp_path):
    write_yaml(tmp_path / "base.yaml", {"mixed-port": 7890})
    write_yaml(tmp_path / "profile.yaml", {"proxies": []})
    write_yaml(
        tmp_path / "misub.yaml",
        {
            "base": "./base.yaml",
            "output": "./config.yaml",
            "sources": [{"name": "provider-a", "path": "./profile.yaml"}],
            "regions": {},
            "proxy-groups": [{"name": "bad", "type": "select", "proxies": ["@bad:value"]}],
        },
    )

    with pytest.raises(BuildError, match="未知占位符"):
        build(tmp_path / "misub.yaml")
