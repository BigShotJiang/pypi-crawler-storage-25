from misub.classify import classify_region, extract_number, should_exclude


def test_should_exclude_when_name_contains_configured_word():
    assert should_exclude("套餐剩余流量 100G", ["流量", "到期"])
    assert not should_exclude("日本 03", ["流量", "到期"])


def test_classify_region_matches_alias_case_insensitively_and_keeps_unrecognized():
    regions = {"日本": ["日本", "JP", "Tokyo"], "香港": ["香港", "HK"]}

    assert classify_region("premium tokyo 03", regions) == "日本"
    assert classify_region("HK 01", regions) == "香港"
    assert classify_region("Moon Base 01", regions) == "未识别"


def test_classify_region_uses_first_matching_region_order():
    regions = {"日本": ["东京", "01"], "香港": ["香港", "01"]}

    assert classify_region("香港 01", regions) == "日本"


def test_extract_number_returns_last_number_with_original_padding():
    assert extract_number("日本 03") == "03"
    assert extract_number("US-LA-12 x2") == "2"
    assert extract_number("无编号") is None
