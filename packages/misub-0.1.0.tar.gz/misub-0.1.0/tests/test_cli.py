from pathlib import Path

import yaml

from misub.cli import main
from misub.templates import DEFAULT_CONFIG_TEMPLATE


def test_no_args_prints_help_successfully(capsys):
    assert main([]) == 0
    assert "{init,build}" in capsys.readouterr().out


def test_init_writes_default_config_and_refuses_overwrite(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)

    assert main(["init"]) == 0
    config_path = tmp_path / "misub.yaml"
    assert config_path.exists()
    config_text = config_path.read_text(encoding="utf-8")
    assert "sources:" in config_text
    assert "provider-a" in config_text
    assert "provider-b" in config_text

    assert main(["init"]) == 1
    assert "已存在" in capsys.readouterr().err


def test_default_config_template_does_not_reference_undefined_proxy_groups():
    config = yaml.safe_load(DEFAULT_CONFIG_TEMPLATE)
    group_names = {group["name"] for group in config["proxy-groups"]}
    builtins = {"DIRECT", "REJECT", "REJECT-DROP", "PASS"}

    unresolved = []
    for group in config["proxy-groups"]:
        for proxy_name in group.get("proxies", []):
            if proxy_name.startswith("@") or proxy_name in builtins:
                continue
            if proxy_name not in group_names:
                unresolved.append((group["name"], proxy_name))

    assert unresolved == []


def test_build_command_with_config_path_writes_output(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    Path("base.yaml").write_text(yaml.safe_dump({"mixed-port": 7890}, allow_unicode=True), encoding="utf-8")
    Path("provider-a.yaml").write_text(
        yaml.safe_dump(
            {"proxies": [{"name": "日本 01", "type": "ss", "server": "node-a.example", "port": 443}]},
            allow_unicode=True,
        ),
        encoding="utf-8",
    )
    Path("misub.yaml").write_text(
        yaml.safe_dump(
            {
                "base": "./base.yaml",
                "output": "./config.yaml",
                "sources": [{"name": "provider-a", "path": "./provider-a.yaml"}],
                "regions": {"日本": ["日本"]},
                "exclude": {"contains": []},
                "naming": "{source}-{region}-{number}",
                "proxy-groups": [{"name": "节点选择", "type": "select", "proxies": ["@all", "DIRECT"]}],
            },
            allow_unicode=True,
            sort_keys=False,
        ),
        encoding="utf-8",
    )

    assert main(["build", "-c", "misub.yaml"]) == 0
    output = yaml.safe_load(Path("config.yaml").read_text(encoding="utf-8"))
    assert output["proxies"][0]["name"] == "provider-a-日本-01"
    assert output["proxy-groups"][0]["proxies"] == ["provider-a-日本-01", "DIRECT"]
