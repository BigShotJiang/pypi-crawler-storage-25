import httpx
import structlog
import typer
from rich.console import Console

from ailtir_cli.commands.kbs import kbs_app
from ailtir_cli.config import settings

_log = structlog.get_logger(__name__)
_console = Console()


@kbs_app.command()
def analyse(kb_id: str = typer.Argument(..., help="The knowledge base ID to analyse.")) -> None:
    """Trigger analysis and Knowledge Base creation for an uploaded ZIP."""
    _console.print(f"Starting analysis for kb_id: [bold]{kb_id}[/bold]...")

    token = settings.ailtir_cli_secret

    with httpx.Client(base_url=settings.cli_api_url, timeout=30.0) as http:
        try:
            resp = http.post(
                f"/kbs/{kb_id}/analyse",
                headers={"Authorization": f"Bearer {token}"},
            )
            resp.raise_for_status()
        except httpx.HTTPStatusError as exc:
            _console.print(f"[red]Error: {exc.response.status_code}[/red]")
            raise typer.Exit(1) from exc

    _log.info("analyse.started", kb_id=kb_id)
    _console.print(
        f"[green]Analysis started[/green] for kb_id: [bold]{kb_id}[/bold]. "
        "This typically takes a few minutes. Use [bold]ailtir kbs list[/bold] to check status."
    )
