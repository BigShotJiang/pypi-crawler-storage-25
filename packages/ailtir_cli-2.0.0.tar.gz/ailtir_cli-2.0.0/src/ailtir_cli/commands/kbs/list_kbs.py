import json
from enum import StrEnum

import httpx
import structlog
import typer
from rich.console import Console
from rich.table import Table

from ailtir_cli.commands.kbs import kbs_app
from ailtir_cli.config import settings

_log = structlog.get_logger(__name__)
_console = Console()

_OUTPUT_OPTION = typer.Option(default="text", help="Output format: text or json.")


class OutputFormat(StrEnum):
    text = "text"
    json = "json"


@kbs_app.command(name="list")
def list_kbs(
    output: OutputFormat = _OUTPUT_OPTION,
) -> None:
    """List all knowledge bases in your Ailtir account."""
    token = settings.ailtir_cli_secret

    with httpx.Client(base_url=settings.cli_api_url, timeout=30.0) as http:
        try:
            resp = http.get("/kbs", headers={"Authorization": f"Bearer {token}"})
            resp.raise_for_status()
        except httpx.HTTPStatusError as exc:
            _console.print(f"[red]Error: {exc.response.status_code}[/red]")
            raise typer.Exit(1) from exc

    kbs = resp.json()

    if output == OutputFormat.json:
        _console.print(json.dumps(kbs, indent=2, default=str))
        return

    if not kbs:
        _console.print("No knowledge bases found.")
        return

    table = Table(title="Knowledge Bases")
    table.add_column("ID", style="dim")
    table.add_column("Name")
    table.add_column("Status")

    for kb in kbs:
        table.add_row(str(kb.get("id", "")), str(kb.get("name", "")), str(kb.get("status", "")))

    _log.info("list_kbs.returned", count=len(kbs))
    _console.print(table)
