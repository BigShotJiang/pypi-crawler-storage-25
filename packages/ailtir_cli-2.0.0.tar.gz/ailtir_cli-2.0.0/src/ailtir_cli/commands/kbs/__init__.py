import typer

kbs_app = typer.Typer(name="kbs", help="Manage knowledge bases.", no_args_is_help=True)

import ailtir_cli.commands.kbs.analyse  # noqa: F401, E402
import ailtir_cli.commands.kbs.chat  # noqa: F401, E402
import ailtir_cli.commands.kbs.list_kbs  # noqa: F401, E402
import ailtir_cli.commands.kbs.upload  # noqa: F401, E402
