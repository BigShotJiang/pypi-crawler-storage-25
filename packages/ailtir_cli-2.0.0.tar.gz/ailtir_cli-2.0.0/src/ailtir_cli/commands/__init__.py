import ailtir_cli.commands.agents  # noqa: F401
import ailtir_cli.commands.kbs  # noqa: F401
import ailtir_cli.commands.version  # noqa: F401
