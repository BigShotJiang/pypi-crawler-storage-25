import typer

agents_app = typer.Typer(name="agents", help="Run AI agent workflows.", no_args_is_help=True)

import ailtir_cli.commands.agents.research  # noqa: F401, E402
