import httpx
import structlog
import typer
from rich.console import Console

from ailtir_cli.commands.agents import agents_app
from ailtir_cli.config import settings

_log = structlog.get_logger(__name__)
_console = Console()


@agents_app.command()
def research(
    topic: str = typer.Argument(..., help="The topic to research."),
) -> None:
    """Run the research agent on a given topic."""
    _console.print(f"Researching: [bold]{topic}[/bold]...")

    token = settings.ailtir_cli_secret

    with httpx.Client(base_url=settings.cli_api_url, timeout=120.0) as http:
        try:
            resp = http.post(
                "/agents/research",
                json={"topic": topic},
                headers={"Authorization": f"Bearer {token}"},
            )
            resp.raise_for_status()
        except httpx.HTTPStatusError as exc:
            _console.print(f"[red]Error: {exc.response.status_code}[/red]")
            raise typer.Exit(1) from exc

    data = resp.json()
    _log.info("agents.research.complete", topic=topic)
    _console.print(data.get("result", "No result returned."))
