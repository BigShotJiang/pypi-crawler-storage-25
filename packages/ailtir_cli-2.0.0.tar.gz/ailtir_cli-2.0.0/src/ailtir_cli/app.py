import sys

import typer
from rich.console import Console

from ailtir_cli.commands.agents import agents_app
from ailtir_cli.commands.kbs import kbs_app

_console = Console(stderr=True)
_DOCS_URL = "https://team-ailtir.github.io/ailtir-cli/"

app = typer.Typer(name="ailtir", help="The Ailtir CLI", no_args_is_help=True)
app.add_typer(kbs_app, name="kbs")
app.add_typer(agents_app, name="agents")


@app.callback()
def _check_config(ctx: typer.Context) -> None:
    if (
        ctx.resilient_parsing
        or "--help" in sys.argv
        or "-h" in sys.argv
        or ctx.invoked_subcommand == "version"
    ):
        return

    from ailtir_cli.config import settings

    if not settings.ailtir_cli_secret:
        _console.print("[red]Error:[/red] AILTIR_CLI_SECRET is not set.")
        _console.print(f"Get your CLI key and set it up: [link]{_DOCS_URL}[/link]")
        raise typer.Exit(1)
