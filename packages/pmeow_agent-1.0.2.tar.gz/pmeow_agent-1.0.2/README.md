# pmeow-agent

`pmeow-agent` 是 PMEOW 的独立 Python Agent。它运行在计算节点本地，负责本地指标采集、GPU 归属识别、本地任务队列，以及通过 Socket.IO 回连 PMEOW Web 服务。

如果你是在仓库内开发或部署节点，也建议同时阅读 [../docs/user/agent-nodes.md](../docs/user/agent-nodes.md)。

## 运行要求

- Python 3.10+
- Linux（依赖 `/proc` 采集系统指标）
- 可选：NVIDIA GPU 与 `nvidia-smi`，用于 GPU 指标和 GPU 归属视图

## 安装

### 从 PyPI 安装

```bash
pip install pmeow-agent
```

### 推荐的系统级安装（独立虚拟环境）

生产环境更推荐给 Agent 单独建一个系统级虚拟环境，而不是把它装进某个项目自己的 venv：

```bash
sudo mkdir -p /opt/pmeow-agent
sudo python3 -m venv /opt/pmeow-agent/.venv
sudo /opt/pmeow-agent/.venv/bin/pip install --upgrade pip
sudo /opt/pmeow-agent/.venv/bin/pip install pmeow-agent
sudo ln -sf /opt/pmeow-agent/.venv/bin/pmeow-agent /usr/local/bin/pmeow-agent
sudo ln -sf /opt/pmeow-agent/.venv/bin/pmeow /usr/local/bin/pmeow
```

这样 `pmeow-agent` 和 `pmeow` 在节点上只有一份固定安装，systemd 也可以稳定指向这套解释器；与此同时，用户在别的虚拟环境里调用 `pmeow` 时，CLI 仍会优先解析调用侧当前激活环境的 Python，而不是 Agent 自己的安装解释器。

如果某个项目虚拟环境里也安装了另一份 `pmeow-agent`，shell 会优先命中那一份；想强制走系统级命令时，请显式调用 `/usr/local/bin/pmeow` 或 `/usr/local/bin/pmeow-agent`。

### 从源码安装（开发模式）

```bash
cd agent
python3 -m venv .venv
. .venv/bin/activate
pip install -e ".[dev]"
```

## 使用方式

### 前台运行

```bash
export PMEOW_SERVER_URL=http://your-server:17200
pmeow-agent run

# 兼容别名
pmeow-agent daemon
```

当前更推荐写成 `pmeow-agent run`。前台模式会把 Agent 运行日志直接打印到当前终端，适合首次接入和现场排障。

### 后台运行

```bash
export PMEOW_SERVER_URL=http://your-server:17200
export PMEOW_AGENT_LOG_FILE=~/.pmeow/agent.log
pmeow-agent start
pmeow-agent is-running
pmeow-agent stop
```

后台模式会把 Agent 运行日志写入 `PMEOW_AGENT_LOG_FILE`，任务的 stdout 和 stderr 仍然写入 `PMEOW_LOG_DIR`。

### 安装为 systemd service

```bash
sudo pmeow-agent install-service --enable --start
sudo pmeow-agent uninstall-service
```

systemd 会以前台模式托管进程，运行日志进入 journal。

如果你按上面的独立虚拟环境方式安装，`install-service` 会把 `ExecStart` 固定到系统级 `pmeow-agent` 可执行文件，并把 `WorkingDirectory` 设为 `PMEOW_STATE_DIR`，不再依赖你执行安装命令时所在的目录。

### 提交任务

```bash
pmeow-agent submit --pvram 4000 --gpu 1 -- python train.py

# 如果不需要 GPU
pmeow-agent submit --pvram 0 --gpu 0 -- bash run_preprocessing.sh
```

常用参数：

- `--pvram`：每张 GPU 需要的显存，单位 MB，默认 `0`
- `--gpu`：需要的 GPU 数量，默认 `1`
- `--priority`：优先级，数字越小越先调度，默认 `10`

`submit` 模式的执行语义有两点需要注意：

- 提交时会冻结当前工作目录和当前进程环境；任务真正开始时，daemon 会用这份 cwd 和整份环境快照启动命令。
- 如果命令看起来是 `python ...`、`py ...` 或 `python3 ...`，并且后面跟的是脚本、`-m` 或 `-c`，CLI 会优先解析调用侧当前激活环境的 Python；解析顺序是 `PMEOW_PYTHON_EXECUTABLE`、`VIRTUAL_ENV` / `CONDA_PREFIX`、当前 `PATH` 里的 `python`，最后才回退到 CLI 自己的解释器。

### 查看队列状态

```bash
pmeow-agent status
```

该命令会输出 queued、running、completed、failed 和 cancelled 等任务数量。

### 查看任务日志

```bash
pmeow-agent logs <task_id>
pmeow-agent logs <task_id> --tail 50
```

### 取消任务

```bash
pmeow-agent cancel <task_id>
```

### 直接运行 Python 任务

```bash
pmeow -vram=10g -gpus=2 --report train.py --epochs 50
```

规则如下：

- 第一个 `.py` 路径之前的 token 会被解析为 PMEOW flags，例如 `-vram`、`-gpus`、`--priority`、`--report`
- 脚本路径之后的参数会原样传给 Python
- `--report` 会在排队期间打印调度尝试和当前 GPU 占用概览
- GPU 资源就绪后，同一个终端会直接切换成 Python 进程的 stdin、stdout 和 stderr

这个 Python 直达模式和 `submit` 的区别是：

- daemon 只负责排队、资源保留和状态同步；真正的 Python 进程是在当前等待中的终端里以前台 attached 方式启动。
- 启动时仍然使用提交时记录的工作目录与解释器参数，但 stdin、stdout 和 stderr 行为更接近你直接在这个终端里运行 `python script.py`。
- 调度器仍然会额外注入 `CUDA_VISIBLE_DEVICES`，所以它不是完全裸的本地执行，而是“带资源绑定的前台 Python”。

### 可选的 PyTorch 样例任务

PyTorch 样例任务是可选能力。使用前请自行安装与当前 CUDA 运行时匹配的 `torch`；`pmeow-agent` 不会把 `torch` 作为默认依赖。

```bash
pmeow -vram=8g -gpus=1 examples/tasks/pytorch_hold.py --gpus 1 --mem-per-gpu 7g --seconds 60
pmeow -vram=12g -gpus=2 --report examples/tasks/pytorch_stagger.py --memories 5g,11g --seconds 90
pmeow -vram=6g -gpus=1 examples/tasks/pytorch_chatty.py --gpus 1 --mem-per-gpu 4g --seconds 45 --interval 5
```

### 暂停 / 恢复队列

```bash
pmeow-agent pause
pmeow-agent resume
```

队列暂停后不会再启动新任务，但已经 running 的任务会继续执行到结束。

## 环境变量

Agent 通过环境变量配置；未设置时会使用默认值。

| 变量 | 默认值 | 说明 |
|---|---|---|
| `PMEOW_SERVER_URL` | 空 | PMEOW Web 服务基础 URL，例如 `http://server:17200` |
| `PMEOW_WS_RECONNECT_DELAY` | `0.5` | Socket.IO 断线后首次重连等待时间，单位秒 |
| `PMEOW_WS_RECONNECT_DELAY_MAX` | `5.0` | Socket.IO 重连退避上限，单位秒 |
| `PMEOW_WS_REQUEST_TIMEOUT` | `3.0` | Socket.IO 建连 / 请求超时，单位秒 |
| `PMEOW_AGENT_ID` | hostname | 当前 Agent 的唯一标识 |
| `PMEOW_COLLECTION_INTERVAL` | `5` | 指标采集间隔，单位秒 |
| `PMEOW_HEARTBEAT_INTERVAL` | `30` | 心跳上报间隔，单位秒 |
| `PMEOW_HISTORY_WINDOW` | `5` | 调度时参考的历史窗口，单位秒 |
| `PMEOW_VRAM_REDUNDANCY` | `0.1` | 显存冗余系数，用于给非 PMEOW 进程预留安全余量 |
| `PMEOW_STATE_DIR` | `~/.pmeow/` | 本地状态目录 |
| `PMEOW_SOCKET_PATH` | `~/.pmeow/pmeow.sock` | CLI 与 daemon 通信的 Unix socket |
| `PMEOW_LOG_DIR` | `~/.pmeow/logs/` | 任务 stdout 和 stderr 日志目录 |
| `PMEOW_PID_FILE` | `~/.pmeow/pmeow-agent.pid` | 后台模式使用的 pid 文件 |
| `PMEOW_AGENT_LOG_FILE` | 空 | 后台模式使用的专用运行日志文件 |

`PMEOW_SERVER_URL` 需要指向 PMEOW Web 服务的基础 URL。Agent transport 会自动连接 Socket.IO `/agent` namespace；不要自己拼 `/agent`，也不要改成原始 WebSocket URL。

如果节点网络抖动较多，优先调 `PMEOW_WS_RECONNECT_DELAY_MAX` 和 `PMEOW_WS_REQUEST_TIMEOUT`；默认值已经比旧配置更激进，断线后会更快重新尝试连接。

## 状态目录

默认情况下，所有 Agent 状态都保存在 `~/.pmeow/` 下：

```text
~/.pmeow/
├── pmeow.db        # 本地 SQLite（任务和运行状态）
├── pmeow.sock      # Unix domain socket（daemon 控制通道）
├── pmeow-agent.pid # pid 文件，仅后台模式使用
└── logs/
    ├── <task_id>.log
    └── ...
```

## 开发与测试

```bash
pip install -e ".[dev]"
pytest -v
```

## 与服务端集成说明

- Agent 会通过 Socket.IO 向服务端发送 `agent:register`、`agent:metrics`、`agent:taskUpdate` 和 `agent:heartbeat`
- 节点在线时，服务端可能会回发 `server:cancelTask`、`server:pauseQueue`、`server:resumeQueue` 和 `server:setPriority`
- 服务端侧的自动绑定基于 hostname 精确匹配；如果你希望自动绑定成功，应让 Web 侧 `servers.host` 与节点 hostname 保持一致
