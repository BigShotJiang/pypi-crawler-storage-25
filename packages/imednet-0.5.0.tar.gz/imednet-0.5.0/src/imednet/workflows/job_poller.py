"""Utility for polling job status."""

from __future__ import annotations

import asyncio
import time
from typing import Any, Callable, cast

from ..constants import TERMINAL_JOB_STATES
from ..models import JobStatus


class JobTimeoutError(TimeoutError):
    """Raised when a job does not finish before the timeout."""


class JobPoller:
    """Poll a job until it reaches a terminal state."""

    def __init__(
        self,
        get_job: Callable[[str, str], Any],
        is_async: bool,
    ) -> None:
        self._get_job = get_job
        self._async = is_async

    def _check_complete(self, status: JobStatus, batch_id: str) -> JobStatus:
        if status.state.upper() in TERMINAL_JOB_STATES:
            if status.state.upper() == "FAILED":
                raise RuntimeError(f"Job {batch_id} failed")
            return status
        return status

    def _check_timeout(self, start_time: float, timeout: int, batch_id: str) -> None:
        if time.monotonic() - start_time >= timeout:
            raise JobTimeoutError(f"Timeout ({timeout}s) waiting for job {batch_id}")

    def _poll_sync(
        self,
        study_key: str,
        batch_id: str,
        interval: int,
        timeout: int,
    ) -> JobStatus:
        start = time.monotonic()

        while True:
            result = self._get_job(study_key, batch_id)
            status = self._check_complete(cast(JobStatus, result), batch_id)

            if status.state.upper() in TERMINAL_JOB_STATES:
                return status

            self._check_timeout(start, timeout, batch_id)
            time.sleep(interval)

    async def _poll_async(
        self,
        study_key: str,
        batch_id: str,
        interval: int,
        timeout: int,
    ) -> JobStatus:
        start = time.monotonic()

        while True:
            result = await self._get_job(study_key, batch_id)
            status = self._check_complete(cast(JobStatus, result), batch_id)

            if status.state.upper() in TERMINAL_JOB_STATES:
                return status

            self._check_timeout(start, timeout, batch_id)
            await asyncio.sleep(interval)

    def run(
        self, study_key: str, batch_id: str, interval: int = 5, timeout: int = 300
    ) -> JobStatus:
        """Synchronously poll a job until completion."""

        if self._async:
            raise RuntimeError("Use run_async for asynchronous polling")

        return self._poll_sync(study_key, batch_id, interval, timeout)

    async def run_async(
        self, study_key: str, batch_id: str, interval: int = 5, timeout: int = 300
    ) -> JobStatus:
        """Asynchronously poll a job until completion."""

        if not self._async:
            raise RuntimeError("Use run for synchronous polling")

        return await self._poll_async(study_key, batch_id, interval, timeout)
