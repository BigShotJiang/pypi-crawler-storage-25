import{n as e,t}from"./rolldown-runtime-DF2fYuay.js";import{a as n,c as r,i,l as a,n as o,o as s,r as c,s as l,t as u,u as d}from"./lit-CNFZiXEs.js";import{a as f,i as p,n as m,r as h,t as g}from"./markdown-CV8Hi911.js";import{a as _,c as v,d as y,f as b,i as x,l as S,n as C,o as w,p as T,r as E,s as D,t as ee,u as te}from"./hljs-v0CKncSw.js";(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var ne={"--radius-xs":`var(--rh-border-radius-default, 3px)`,"--radius-sm":`8px`,"--radius-md":`12px`,"--radius-lg":`16px`,"--radius-xl":`24px`,"--radius-full":`var(--rh-border-radius-pill, 64px)`,"--sidebar-width":`280px`,"--topbar-height":`48px`,"--chat-max-width":`768px`,"--detail-pane-width":`340px`,"--detail-pane-min-width":`200px`,"--chat-area-min-width":`320px`,"--transition-fast":`150ms ease`,"--transition-normal":`250ms ease`,"--font-size-xs":`var(--rh-font-size-body-text-xs, 0.75rem)`,"--font-size-sm":`var(--rh-font-size-body-text-sm, 0.875rem)`,"--font-size-base":`var(--rh-font-size-body-text-md, 1rem)`,"--font-size-lg":`var(--rh-font-size-body-text-lg, 1.125rem)`,"--font-size-xl":`var(--rh-font-size-body-text-2xl, 1.5rem)`,"--font-weight-normal":`var(--rh-font-weight-body-text-regular, 400)`,"--font-weight-medium":`var(--rh-font-weight-body-text-medium, 500)`,"--font-weight-bold":`var(--rh-font-weight-heading-bold, 700)`,"--line-height":`var(--rh-line-height-body-text, 1.5)`},re={...ne,"--bg-primary":`#F8F6FB`,"--bg-secondary":`#F0ECF5`,"--bg-tertiary":`#E4DEF0`,"--bg-user-bubble":`#DCE8DC`,"--bg-assistant":`transparent`,"--bg-sidebar":`#F2F5F2`,"--bg-input":`#FFFFFF`,"--bg-code":`#F3EEF8`,"--bg-hover":`rgba(90, 70, 140, 0.06)`,"--bg-tool":`#F0ECF5`,"--bg-tool-header":`#E4DEF0`,"--text-primary":`#2D2B3D`,"--text-secondary":`#6B6880`,"--text-tertiary":`#9895AA`,"--text-inverse":`#FFFFFF`,"--text-code":`#7C5CBF`,"--border-primary":`rgba(80, 60, 120, 0.15)`,"--border-secondary":`rgba(80, 60, 120, 0.08)`,"--accent-primary":`#5B9EA6`,"--accent-hover":`#4A8A93`,"--accent-success":`#6B9F6B`,"--accent-danger":`#C27070`,"--accent-warning":`#C4966E`,"--accent-info":`#7B9EC9`,"--hat-color":`#E06060`,"--font-sans":`'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif`,"--font-mono":`'SF Mono', 'Fira Code', 'Fira Mono', 'Roboto Mono', monospace`,"--shadow-sm":`0 1px 2px rgba(60, 40, 100, 0.06)`,"--shadow-md":`0 2px 8px rgba(60, 40, 100, 0.10)`,"--shadow-lg":`0 4px 16px rgba(60, 40, 100, 0.14)`},ie={...ne,"--bg-primary":`#1E1B2E`,"--bg-secondary":`#262340`,"--bg-tertiary":`#352F54`,"--bg-user-bubble":`#3A3458`,"--bg-assistant":`transparent`,"--bg-sidebar":`#151324`,"--bg-input":`#262340`,"--bg-code":`#262340`,"--bg-hover":`rgba(180, 160, 255, 0.08)`,"--bg-tool":`#1C1930`,"--bg-tool-header":`#2E2A48`,"--text-primary":`#E8E4F0`,"--text-secondary":`#ACA8C0`,"--text-tertiary":`#7E7A96`,"--text-inverse":`#1E1B2E`,"--text-code":`#E8A8C0`,"--border-primary":`rgba(200, 180, 255, 0.15)`,"--border-secondary":`rgba(200, 180, 255, 0.08)`,"--accent-primary":`#A78BFA`,"--accent-hover":`#B89FF8`,"--accent-success":`#86D9A8`,"--accent-danger":`#F08080`,"--accent-warning":`#E8C06A`,"--accent-info":`#88B8E8`,"--hat-color":`#F07888`,"--font-sans":`'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif`,"--font-mono":`'SF Mono', 'Fira Code', 'Fira Mono', 'Roboto Mono', monospace`,"--shadow-sm":`0 1px 2px rgba(10, 8, 30, 0.3)`,"--shadow-md":`0 2px 8px rgba(10, 8, 30, 0.4)`,"--shadow-lg":`0 4px 16px rgba(10, 8, 30, 0.5)`},ae={...ne,"--bg-primary":`#e6e6e6`,"--bg-secondary":`#f5f5f5`,"--bg-tertiary":`var(--rh-color-surface-light, #e0e0e0)`,"--bg-user-bubble":`var(--rh-color-gray-20, #e0e0e0)`,"--bg-assistant":`transparent`,"--bg-sidebar":`var(--rh-color-gray-10, #f5f5f5)`,"--bg-input":`var(--rh-color-surface-lightest, #ffffff)`,"--bg-code":`var(--rh-color-surface-lighter, #f2f2f2)`,"--bg-hover":`var(--rh-color-surface-lighter, rgba(21, 21, 21, 0.04))`,"--bg-tool":`var(--rh-color-gray-10, #f2f2f2)`,"--bg-tool-header":`var(--rh-color-gray-20, #e0e0e0)`,"--text-primary":`var(--rh-color-text-primary-on-light, #151515)`,"--text-secondary":`var(--rh-color-text-secondary-on-light, #4d4d4d)`,"--text-tertiary":`var(--rh-color-gray-50, #707070)`,"--text-inverse":`var(--rh-color-text-primary-on-dark, #ffffff)`,"--text-code":`var(--rh-color-blue-70, #003366)`,"--border-primary":`var(--rh-color-border-subtle-on-light, #c7c7c7)`,"--border-secondary":`var(--rh-color-border-subtle-on-light, rgba(21, 21, 21, 0.10))`,"--accent-primary":`var(--rh-color-interactive-blue-darker, #0066cc)`,"--accent-hover":`var(--rh-color-interactive-blue-darkest, #003366)`,"--accent-success":`var(--rh-color-status-success-on-light, #3d7317)`,"--accent-danger":`var(--rh-color-status-danger-on-light, #b1380b)`,"--accent-warning":`var(--rh-color-status-warning-on-light, #dca614)`,"--accent-info":`var(--rh-color-interactive-blue-darker, #0066cc)`,"--hat-color":`var(--rh-color-brand-red-on-light, #ee0000)`,"--font-sans":`var(--rh-font-family-body-text, 'Red Hat Text', 'Red Hat Display', sans-serif)`,"--font-mono":`var(--rh-font-family-code, 'Red Hat Mono', 'Courier New', monospace)`,"--shadow-sm":`var(--rh-box-shadow-sm, 0 1px 2px rgba(21, 21, 21, 0.1))`,"--shadow-md":`var(--rh-box-shadow-md, 0 2px 4px rgba(21, 21, 21, 0.12))`,"--shadow-lg":`var(--rh-box-shadow-lg, 0 4px 8px rgba(21, 21, 21, 0.15))`},oe={...ne,"--bg-primary":`#252525`,"--bg-secondary":`#2a2a2a`,"--bg-tertiary":`var(--rh-color-gray-60, #4d4d4d)`,"--bg-user-bubble":`var(--rh-color-gray-70, #3d3d3d)`,"--bg-assistant":`transparent`,"--bg-sidebar":`var(--rh-color-surface-darkest, #151515)`,"--bg-input":`#2a2a2a`,"--bg-code":`var(--rh-color-gray-70, #333333)`,"--bg-hover":`var(--rh-color-surface-darker, rgba(255, 255, 255, 0.06))`,"--bg-tool":`var(--rh-color-surface-darker, #1f1f1f)`,"--bg-tool-header":`var(--rh-color-surface-dark, #383838)`,"--text-primary":`var(--rh-color-text-primary-on-dark, #ffffff)`,"--text-secondary":`var(--rh-color-text-secondary-on-dark, #c7c7c7)`,"--text-tertiary":`#a0a0a0`,"--text-inverse":`var(--rh-color-text-primary-on-light, #151515)`,"--text-code":`var(--rh-color-red-orange-30, #f89b78)`,"--border-primary":`var(--rh-color-border-subtle-on-dark, #707070)`,"--border-secondary":`var(--rh-color-border-subtle-on-dark, rgba(242, 242, 242, 0.08))`,"--accent-primary":`var(--rh-color-interactive-blue-lighter, #92c5f9)`,"--accent-hover":`var(--rh-color-interactive-blue-lightest, #b9dafc)`,"--accent-success":`var(--rh-color-status-success-on-dark, #87bb62)`,"--accent-danger":`var(--rh-color-status-danger-on-dark, #f0561d)`,"--accent-warning":`var(--rh-color-status-warning-on-dark, #ffcc17)`,"--accent-info":`var(--rh-color-interactive-blue-lighter, #92c5f9)`,"--hat-color":`var(--rh-color-brand-red-on-dark, #ee0000)`,"--font-sans":`var(--rh-font-family-body-text, 'Red Hat Text', 'Red Hat Display', sans-serif)`,"--font-mono":`var(--rh-font-family-code, 'Red Hat Mono', 'Courier New', monospace)`,"--shadow-sm":`var(--rh-box-shadow-sm, 0 1px 2px rgba(21, 21, 21, 0.15))`,"--shadow-md":`var(--rh-box-shadow-md, 0 2px 4px rgba(21, 21, 21, 0.18))`,"--shadow-lg":`var(--rh-box-shadow-lg, 0 4px 8px rgba(21, 21, 21, 0.22))`},se=[{id:`light`,label:`Light`,theme:re,dark:!1},{id:`dark`,label:`Dark`,theme:ie,dark:!0},{id:`rh-light`,label:`Red Hat Light`,theme:ae,dark:!1},{id:`rh-dark`,label:`Red Hat Dark`,theme:oe,dark:!0}],ce=new Map(se.map(e=>[e.id,e])),le=`agent-theme`,ue=new class{constructor(){this.themeName=this.loadPreference();let e=ce.get(this.themeName);this.current=e?e.theme:re,this.apply()}get name(){return this.themeName}get isDark(){let e=ce.get(this.themeName);return e?e.dark:!1}get themes(){return se}toggle(){let e=se.map(e=>e.id),t=e[(e.indexOf(this.themeName)+1)%e.length];this.setTheme(t)}setTheme(e,t){this.themeName=e;let n=ce.get(e),r=n?n.theme:re;this.current=t?Object.assign({},r,t):r,this.apply(),this.savePreference()}apply(){let e=document.documentElement;for(let[t,n]of Object.entries(this.current))e.style.setProperty(t,n)}loadPreference(){try{let e=localStorage.getItem(le);if(e&&ce.has(e))return e}catch{}return window.matchMedia?.(`(prefers-color-scheme: dark)`).matches?`dark`:`light`}savePreference(){try{localStorage.setItem(le,this.themeName)}catch{}}},de=[{name:`set_context`,description:`Set or update a context key-value pair for the conversation`},{name:`select_skill`,description:`Load a reference guide (skill) for the current conversation`}],O=new class{constructor(){this.data={sessionId:null,activeChatId:null,chatList:[],messages:[],isStreaming:!1,usage:null,model:``,mcpServers:[],toolCount:0,contextWindow:0,maxActiveSkills:3,availableSkills:[],activeSkills:[],context:{},availableModels:[],availablePlaybooks:[],availableTools:[],toolPolicies:{},pinCards:[],sidebarOpen:!0,detailPaneOpen:!0,detailPaneWidth:340,error:null,warning:null,streamStartTime:null,streamElapsed:null},this.listeners=new Set}get state(){return this.data}subscribe(e){return this.listeners.add(e),()=>this.listeners.delete(e)}notify(){for(let e of this.listeners)e()}update(e){Object.assign(this.data,e),this.notify()}addMessage(e){this.data.messages=[...this.data.messages,e],this.notify()}updateLastAssistant(e){let t=[...this.data.messages];for(let n=t.length-1;n>=0;n--)if(t[n].role===`assistant`){t[n]=e(t[n]);break}this.data.messages=t,this.notify()}addToolCallToLast(e){this.updateLastAssistant(t=>({...t,toolCalls:[...t.toolCalls??[],e]}))}updateLastToolCall(e){this.updateLastAssistant(t=>{let n=[...t.toolCalls??[]];return n.length>0&&(n[n.length-1]=e(n[n.length-1])),{...t,toolCalls:n}})}clearMessages(){this.data.messages=[],this.data.sessionId=null,this.data.activeChatId=null,this.data.isStreaming=!1,this.data.usage=null,this.data.error=null,this.data.streamStartTime=null,this.data.streamElapsed=null,this.notify()}setChatList(e){this.data.chatList=e,this.notify()}setActiveChat(e,t,n){this.data.activeChatId=e,this.data.sessionId=t,this.data.messages=n,this.data.isStreaming=!1,this.data.usage=null,this.data.error=null,this.data.streamStartTime=null,this.data.streamElapsed=null,this.notify()}removeChat(e){this.data.chatList=this.data.chatList.filter(t=>t.id!==e),this.data.activeChatId===e&&this.clearMessages(),this.notify()}setContext(e,t){this.data.context={...this.data.context,[e]:t},this.notify()}removeContext(e){let t={...this.data.context};delete t[e],this.data.context=t,this.notify()}clearContext(){this.data.context={},this.notify()}toggleSkill(e){let t=[...this.data.activeSkills],n=t.indexOf(e);n>=0?t.splice(n,1):(t.push(e),t.length>this.data.maxActiveSkills&&t.shift()),this.data.activeSkills=t,this.notify()}setActiveSkills(e){this.data.activeSkills=e,this.notify()}needsApproval(){let e=Object.values(this.data.toolPolicies);return e.length===0?!0:e.some(e=>e!==`auto-accept`)}setToolPolicy(e,t){this.data.toolPolicies={...this.data.toolPolicies,[e]:t},this.notify()}setAllToolPolicies(e){let t={};for(let n of this.data.availableTools)t[n.name]=e;this.data.toolPolicies=t,this.notify()}hasCard(e){return this.data.pinCards.some(t=>t.id===e)}addCard(e){this.hasCard(e.id)||(this.data.pinCards=[...this.data.pinCards,e],this.notify())}removeCard(e){this.data.pinCards=this.data.pinCards.filter(t=>t.id!==e),this.notify()}moveCard(e,t){let n=[...this.data.pinCards],r=n.findIndex(t=>t.id===e);if(r<0||r===t)return;let[i]=n.splice(r,1);n.splice(t,0,i),this.data.pinCards=n,this.notify()}updateCardContent(e,t){this.data.pinCards=this.data.pinCards.map(n=>n.id===e?{...n,content:t,timestamp:Date.now()}:n),this.notify()}updateCard(e,t){this.data.pinCards=this.data.pinCards.map(n=>n.id===e?{...n,...t}:n),this.notify()}updateCardHeight(e,t){this.data.pinCards=this.data.pinCards.map(n=>n.id===e?{...n,height:t}:n),this.notify()}genId(){return`${Date.now()}-${Math.random().toString(36).slice(2,8)}`}};function fe(e){return e===`set_context`||e===`select_skill`||e.endsWith(`_read`)||e.endsWith(`_help`)?`auto-accept`:`ask`}var pe=`/api`;async function k(e,t){let n=await fetch(`${pe}${e}`,{headers:{"Content-Type":`application/json`},...t});if(!n.ok)throw Error(`API ${n.status}: ${n.statusText}`);return n.json()}async function me(){return k(`/status`)}async function A(){return(await k(`/models`)).models}async function j(e){return k(`/model`,{method:`PUT`,body:JSON.stringify({model:e})})}async function he(){return(await k(`/tools`)).tools}async function ge(){return(await k(`/skills`)).skills}async function _e(){return(await k(`/playbooks`)).playbooks}async function ve(){return(await k(`/mcp`)).servers}async function ye(e){return k(`/mcp/${encodeURIComponent(e)}`,{method:`POST`})}async function be(e){return k(`/mcp/${encodeURIComponent(e)}`,{method:`DELETE`})}async function xe(){return(await k(`/chats`)).chats}async function Se(e){return k(`/chats/${encodeURIComponent(e)}`)}async function Ce(e){await k(`/chats/${encodeURIComponent(e)}`,{method:`DELETE`})}async function we(e,t={}){return k(`/tools/${encodeURIComponent(e)}`,{method:`POST`,body:JSON.stringify({arguments:t})})}async function M(e,t,n){let r={approved:t};n&&(r.reason=n),await k(`/chat/${e}/approve`,{method:`POST`,body:JSON.stringify(r)})}async function Te(e){await k(`/chat/${e}/cancel`,{method:`POST`})}function Ee(e){let t=`${pe}/chat/${e}/cancel`;navigator.sendBeacon(t)}var De=`/api`;async function Oe(e,t,n){let r=`${De}/chat/stream${n?.approve?`?approve=true`:``}`,i;try{i=await fetch(r,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify(e),signal:n?.signal})}catch(e){t.onError?.(e instanceof Error?e:Error(String(e)));return}if(!i.ok){t.onError?.(Error(`Stream ${i.status}: ${i.statusText}`));return}let a=i.body?.getReader();if(!a){t.onError?.(Error(`No response body`));return}let o=new TextDecoder,s=``,c=``;try{for(;;){let{done:e,value:n}=await a.read();if(e)break;s+=o.decode(n,{stream:!0});let r=s.split(`
`);s=r.pop()??``;for(let e of r)if(e.startsWith(`event:`))c=e.slice(6).trim();else if(e.startsWith(`data:`)){let n=e.slice(5).trim();if(!n)continue;let r;try{r=JSON.parse(n)}catch{continue}ke(c,r,t),c=``}}}catch(e){e.name!==`AbortError`&&t.onError?.(e instanceof Error?e:Error(String(e)))}}function ke(e,t,n){switch(e){case`session`:n.onSession?.(t.session_id);break;case`thinking`:n.onThinking?.();break;case`usage`:n.onUsage?.(t);break;case`tool_call`:n.onToolCall?.(t.name,t.arguments);break;case`tool_result`:n.onToolResult?.(t.name,t.result);break;case`tool_denied`:n.onToolDenied?.(t.name,t.reason);break;case`skill_selected`:n.onSkillSelected?.(t.name);break;case`skill_cleared`:n.onSkillCleared?.();break;case`context_set`:n.onContextSet?.(t.key,t.value);break;case`context_unset`:n.onContextUnset?.(t.key);break;case`content`:n.onContent?.(t.content);break;case`cancelled`:n.onCancelled?.(t.content);break;case`done`:n.onDone?.(t.content);break}}async function Ae(){try{let e=(await xe()).map(e=>({id:e.id,title:e.title,updatedAt:e.updated_at}));O.setChatList(e)}catch{}}function je(e,t,n,r){let i=O.state;return Oe({message:e,session_id:i.sessionId??void 0,skills:i.activeSkills.length?i.activeSkills:void 0,context:Object.keys(i.context).length?i.context:void 0},{onSession:t=>{if(O.update({sessionId:t,activeChatId:t}),!O.state.chatList.some(e=>e.id===t)){let n=e.replace(/^#{1,6}\s+/gm,``).replace(/\*{1,3}(.+?)\*{1,3}/g,`$1`).replace(/`(.+?)`/g,`$1`).replace(/\[([^\]]+)\]\([^)]+\)/g,`$1`).replace(/^[-*>]+\s+/gm,``).replace(/\n/g,` `).trim(),r=n.length>80?n.slice(0,80).trimEnd()+`...`:n;O.setChatList([{id:t,title:r||`New Chat`,updatedAt:Date.now()/1e3},...O.state.chatList])}},onThinking:()=>{O.updateLastAssistant(e=>({...e,thinking:!0}))},onUsage:e=>{O.update({usage:{totalTokens:e.total_tokens,promptTokens:e.prompt_tokens,completionTokens:e.completion_tokens,contextWindow:e.context_window}})},onToolCall:(e,n)=>{O.updateLastAssistant(e=>({...e,thinking:!1}));let r=O.state.toolPolicies[e]??fe(e);if(e===`select_skill`){let e=n.name??``;O.state.activeSkills.some(t=>t.toLowerCase()===e.toLowerCase())&&(r=`auto-accept`)}let i=t&&r===`ask`;if(O.addToolCallToLast({name:e,arguments:n,pending:i}),t&&r!==`ask`){let e=O.state.sessionId;if(e){let t=r===`auto-accept`;M(e,t,t?void 0:`auto-rejected by policy`).catch(()=>{}),t||O.updateLastToolCall(e=>({...e,pending:!1,denied:!0,denyReason:`auto-rejected by policy`}))}}},onToolResult:(e,t)=>{O.updateLastToolCall(e=>({...e,result:t,pending:!1}))},onToolDenied:(e,t)=>{O.updateLastToolCall(e=>({...e,denied:!0,denyReason:t,pending:!1}))},onSkillSelected:e=>{O.state.activeSkills.includes(e)||O.setActiveSkills([...O.state.activeSkills,e])},onSkillCleared:()=>{O.setActiveSkills([])},onContextSet:(e,t)=>{(O.state.toolPolicies.set_context??fe(`set_context`))!==`auto-reject`&&O.setContext(e,t)},onContextUnset:e=>{(O.state.toolPolicies.set_context??fe(`set_context`))!==`auto-reject`&&O.removeContext(e)},onContent:e=>{O.updateLastAssistant(t=>({...t,content:e,thinking:!1}))},onCancelled:e=>{let t=(performance.now()-n)/1e3;O.updateLastAssistant(t=>({...t,content:e||t.content||``,thinking:!1,cancelled:!0})),O.update({isStreaming:!1,streamElapsed:t,activeChatId:O.state.sessionId}),Ae()},onDone:e=>{let t=(performance.now()-n)/1e3;O.updateLastAssistant(t=>({...t,content:e,thinking:!1})),O.update({isStreaming:!1,streamElapsed:t,activeChatId:O.state.sessionId}),Ae()},onError:e=>{O.updateLastAssistant(t=>({...t,content:`Error: ${e.message}`,thinking:!1})),O.update({isStreaming:!1})}},{approve:t,signal:r})}function Me(e,t,n){let r=[],i=0,a=()=>`${t}-${i++}`;for(let t=0;t<e.length;t++){let i=e[t];if(i.role===`user`){r.push({id:a(),role:`user`,content:i.content??``,timestamp:n});continue}if(i.role===`assistant`&&i.tool_calls?.length){let o=[];for(let n of i.tool_calls){let r={};try{r=JSON.parse(n.function.arguments)}catch{}let i={name:n.function.name,arguments:r};for(let r=t+1;r<e.length;r++)if(e[r].role===`tool`&&e[r].tool_call_id===n.id){i.result=e[r].content??``;break}o.push(i)}let s=i.content??``,c,l=t+1;for(;l<e.length&&e[l].role===`tool`;)l++;l<e.length&&e[l].role===`assistant`&&!e[l].tool_calls?.length&&(c=e[l],s=c.content??``),r.push({id:a(),role:`assistant`,content:s,toolCalls:o,cancelled:c?.cancelled||void 0,timestamp:n});continue}if(i.role===`assistant`){if(r.length>0){let e=r[r.length-1];if(e.role===`assistant`&&e.toolCalls?.length&&e.content===i.content)continue}r.push({id:a(),role:`assistant`,content:i.content??``,cancelled:i.cancelled||void 0,timestamp:n});continue}}return r}function N(e,t,n,r){var i=arguments.length,a=i<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,o;if(typeof Reflect==`object`&&typeof Reflect.decorate==`function`)a=Reflect.decorate(e,t,n,r);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(i<3?o(a):i>3?o(t,n,a):o(t,n))||a);return i>3&&a&&Object.defineProperty(t,n,a),a}var Ne,Pe=(Ne=class extends l{constructor(...e){super(...e),this.sidebarOpen=O.state.sidebarOpen,this.detailPaneOpen=O.state.detailPaneOpen,this.detailPaneWidth=O.state.detailPaneWidth,this.dragStartWidth=0,this.onBeforeUnload=()=>{if(O.state.isStreaming){let e=O.state.sessionId;e&&Ee(e)}},this.onSendMessage=e=>{this.handleSend(e.detail.message)},this.onCancelStream=()=>{this.handleCancel()},this.onLoadChat=async e=>{O.state.isStreaming&&this.handleCancel();let{chatId:t}=e.detail;try{let e=await Se(t),n=Me(e.messages??[],e.id,e.updated_at*1e3);O.setActiveChat(t,t,n)}catch(e){O.update({error:`Failed to load chat: ${e.message}`})}},this.onDeleteChat=async e=>{let{chatId:t}=e.detail;try{await Ce(t),O.removeChat(t)}catch(e){O.update({error:`Failed to delete chat: ${e.message}`})}},this.onPinCard=e=>{O.addCard(e.detail.card),O.state.detailPaneOpen||O.update({detailPaneOpen:!0})},this.onPaneResize=e=>{let t=getComputedStyle(this),n=parseInt(t.getPropertyValue(`--detail-pane-min-width`))||200,r=parseInt(t.getPropertyValue(`--chat-area-min-width`))||320,i=this.shadowRoot?.querySelector(`.main`),a=(i?i.clientWidth:1/0)-r-4;this.dragStartWidth||=this.detailPaneWidth,this.detailPaneWidth=Math.max(n,Math.min(a,this.dragStartWidth-e.detail.delta))},this.onPaneResizeEnd=()=>{O.update({detailPaneWidth:this.detailPaneWidth}),this.dragStartWidth=0}}connectedCallback(){super.connectedCallback(),this.unsubscribe=O.subscribe(()=>{this.sidebarOpen=O.state.sidebarOpen,this.detailPaneOpen=O.state.detailPaneOpen,!O.state.isStreaming&&this.abortController&&(this.abortController.abort(),this.abortController=void 0)}),this.addEventListener(`send-message`,this.onSendMessage),this.addEventListener(`cancel-stream`,this.onCancelStream),this.addEventListener(`load-chat`,this.onLoadChat),this.addEventListener(`delete-chat`,this.onDeleteChat),this.addEventListener(`pin-card`,this.onPinCard),window.addEventListener(`beforeunload`,this.onBeforeUnload),this.loadInitialData()}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.(),this.removeEventListener(`send-message`,this.onSendMessage),this.removeEventListener(`cancel-stream`,this.onCancelStream),this.removeEventListener(`load-chat`,this.onLoadChat),this.removeEventListener(`delete-chat`,this.onDeleteChat),this.removeEventListener(`pin-card`,this.onPinCard),window.removeEventListener(`beforeunload`,this.onBeforeUnload)}async loadInitialData(){try{let[e,t,n,r,i,a]=await Promise.all([me(),ge(),_e(),ve(),he(),xe()]),o=r,s=i,c=a.map(e=>({id:e.id,title:e.title,updatedAt:e.updated_at})),l=[],u=null;if(e.llm_status!==`ok`)u=`LLM server is unreachable. Start your LLM server and reload the page.`;else try{l=await A()}catch{u=`Could not fetch model list from LLM server.`}let d=o.filter(e=>!e.connected),f=[],p=e.tools;for(let e of d)try{let t=await ye(e.name);o=t.servers,p=t.tools}catch{f.push(e.name)}if(f.length>0){let e=f.join(`, `);u=[u,`MCP server${f.length>1?`s`:``} unreachable: ${e}.`].filter(Boolean).join(` `)}d.length>0&&(s=await he());let m=[...s,...de],h={};for(let e of m)h[e.name]=O.state.toolPolicies[e.name]??fe(e.name);O.update({model:e.model,mcpServers:o,toolCount:p,contextWindow:e.context_window,maxActiveSkills:e.max_active_skills,availableModels:l,availableSkills:t,availablePlaybooks:n,availableTools:m,toolPolicies:h,chatList:c,warning:u})}catch(e){O.update({error:`Cannot connect to agent server: ${e.message}`})}}handleCancel(){if(!this.abortController)return;let e=O.state.sessionId;e&&Te(e).catch(()=>{}),this.abortController.abort(),this.abortController=void 0,O.updateLastAssistant(e=>({...e,thinking:!1,content:e.content||``,cancelled:!0})),O.update({isStreaming:!1})}async handleSend(e){if(O.state.isStreaming)return;O.addMessage({id:O.genId(),role:`user`,content:e,timestamp:Date.now()}),O.addMessage({id:O.genId(),role:`assistant`,content:``,thinking:!0,timestamp:Date.now()});let t=O.needsApproval(),n=performance.now();O.update({isStreaming:!0,error:null,streamStartTime:Date.now()}),this.abortController=new AbortController,await je(e,t,n,this.abortController.signal)}render(){return a`
      <top-bar></top-bar>
      <div class="content">
        <div class="sidebar-container ${this.sidebarOpen?``:`collapsed`}">
          <agent-sidebar></agent-sidebar>
        </div>
        <div class="main">
          <div class="chat-area">
            <agent-chat></agent-chat>
          </div>
          ${this.detailPaneOpen?a`
                <resize-handle
                  @handle-resize=${this.onPaneResize}
                  @resize-end=${this.onPaneResizeEnd}
                ></resize-handle>
                <detail-pane style="width:${this.detailPaneWidth}px"></detail-pane>
              `:``}
        </div>
      </div>
    `}},Ne.styles=d`
    :host {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      overflow: hidden;
      background: var(--bg-primary);
      color: var(--text-primary);
      font-family: var(--font-sans);
    }

    .content {
      display: flex;
      flex: 1;
      min-height: 0;
      overflow: hidden;
    }

    .sidebar-container {
      width: var(--sidebar-width);
      min-width: var(--sidebar-width);
      height: 100%;
      transition: margin-left var(--transition-normal);
      overflow: hidden;
    }

    .sidebar-container.collapsed {
      margin-left: calc(-1 * var(--sidebar-width));
    }

    .main {
      flex: 1;
      display: flex;
      flex-direction: row;
      height: 100%;
      min-width: 0;
      position: relative;
    }

    .chat-area {
      flex: 1;
      display: flex;
      flex-direction: column;
      height: 100%;
      min-width: var(--chat-area-min-width);
      position: relative;
    }

    detail-pane {
      height: 100%;
      flex-shrink: 0;
    }

    @media (max-width: 768px) {
      .sidebar-container {
        position: absolute;
        z-index: 100;
        top: 0;
        left: 0;
        height: 100%;
        box-shadow: var(--shadow-lg);
      }

      .sidebar-container.collapsed {
        margin-left: calc(-1 * var(--sidebar-width));
      }

      resize-handle,
      detail-pane {
        display: none;
      }
    }
  `,Ne);N([i()],Pe.prototype,`sidebarOpen`,void 0),N([i()],Pe.prototype,`detailPaneOpen`,void 0),N([i()],Pe.prototype,`detailPaneWidth`,void 0),Pe=N([s(`agent-app`)],Pe);function Fe(e){let t=Math.floor((Date.now()-e)/1e3);if(t<5)return`just now`;if(t<60)return`${t}s ago`;let n=Math.floor(t/60);if(n<60)return`${n}m ago`;let r=Math.floor(n/60);return r<24?`${r}h ago`:`${Math.floor(r/24)}d ago`}var Ie=5e3,Le=new Set,Re=null;function ze(){Re||=setInterval(()=>{for(let e of Le)e.requestUpdate()},Ie)}function Be(){Re&&=(clearInterval(Re),null)}var Ve=class{constructor(e){this.host=e,e.addController(this)}hostConnected(){Le.add(this.host),ze()}hostDisconnected(){Le.delete(this.host),Le.size||Be()}},He=`auto-refresh-interval`,Ue=30,We=5,Ge=3600,Ke=new class{constructor(){this.listeners=new Set,this._intervalSec=this.loadInterval()}get intervalSec(){return this._intervalSec}setInterval(e){let t=Math.max(We,Math.min(Ge,Math.round(e)));t!==this._intervalSec&&(this._intervalSec=t,this.saveInterval(),this.notify())}subscribe(e){return this.listeners.add(e),()=>this.listeners.delete(e)}notify(){for(let e of this.listeners)e()}loadInterval(){try{let e=localStorage.getItem(He);if(e!==null){let t=Number(e);if(!Number.isNaN(t)&&t>=We&&t<=Ge)return t}}catch{}return Ue}saveInterval(){try{localStorage.setItem(He,String(this._intervalSec))}catch{}}},qe,Je=(qe=class extends l{constructor(...e){super(...e),this.intervalSec=Ke.intervalSec}connectedCallback(){super.connectedCallback(),this.unsubscribe=Ke.subscribe(()=>{this.intervalSec=Ke.intervalSec})}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.()}onIntervalChange(e){let t=Number(e.target.value);!Number.isNaN(t)&&t>0&&Ke.setInterval(t)}render(){return a`
      <div class="row">
        <label for="interval-input">Refresh every</label>
        <input
          id="interval-input"
          class="interval-input"
          type="number"
          min="5"
          max="3600"
          aria-describedby="interval-hint"
          .value=${String(this.intervalSec)}
          @change=${this.onIntervalChange}
        />
        <span class="unit">sec</span>
      </div>
      <div class="hint" id="interval-hint">
        Use the timer button on each card to enable auto-refresh.
      </div>
    `}},qe.styles=d`
    :host {
      display: block;
    }

    .row {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: var(--font-size-sm);
    }

    label {
      color: var(--text-secondary);
      white-space: nowrap;
    }

    .interval-input {
      width: 64px;
      padding: 4px 8px;
      border: 1px solid var(--border-primary);
      border-radius: var(--radius-xs);
      background: var(--bg-input);
      color: var(--text-primary);
      font-size: var(--font-size-sm);
      text-align: center;
    }

    .unit {
      color: var(--text-tertiary);
      font-size: var(--font-size-xs);
    }

    .hint {
      margin-top: 6px;
      font-size: var(--font-size-xs);
      color: var(--text-tertiary);
      line-height: 1.4;
    }
  `,qe);N([i()],Je.prototype,`intervalSec`,void 0),Je=N([s(`auto-refresh-settings`)],Je);var Ye,Xe=(Ye=class extends l{constructor(...e){super(...e),this.ticker=new Ve(this),this.model=``,this.toolCount=0,this.contextWindow=0,this.sessionId=null,this.activeChatId=null,this.chatList=[],this.error=null,this.warning=null,this.openSections={status:!1,session:!1,model:!1,mcp:!1,skills:!1,context:!1,policies:!1,settings:!1}}connectedCallback(){super.connectedCallback(),this.unsubscribe=O.subscribe(()=>{let e=O.state;this.model=e.model,this.toolCount=e.toolCount,this.contextWindow=e.contextWindow,this.sessionId=e.sessionId,this.activeChatId=e.activeChatId,this.chatList=e.chatList,this.error=e.error,this.warning=e.warning})}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.()}newChat(){O.clearMessages()}selectChat(e){e!==this.activeChatId&&this.dispatchEvent(new CustomEvent(`load-chat`,{detail:{chatId:e},bubbles:!0,composed:!0}))}deleteChat(e,t){e.stopPropagation(),this.dispatchEvent(new CustomEvent(`delete-chat`,{detail:{chatId:t},bubbles:!0,composed:!0}))}toggleSection(e){this.openSections={...this.openSections,[e]:!this.openSections[e]}}renderAccordion(e,t,n){let r=this.openSections[e]??!1;return a`
      <div class="accordion">
        <div class="accordion-header" @click=${()=>this.toggleSection(e)}>
          <span class="section-title">${t}</span>
          <svg
            class="accordion-chevron ${r?`open`:``}"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <polyline points="9 18 15 12 9 6"></polyline>
          </svg>
        </div>
        <div class="accordion-body ${r?`open`:``}">
          <div>${n}</div>
        </div>
      </div>
    `}render(){return a`
      <div class="body">
        ${this.error?a`<div class="error-banner">${this.error}</div>`:``}
        ${this.warning?a`<div class="warning-banner">${this.warning}</div>`:``}

        <div class="section">
          <span class="section-title">Chats</span>
          <button class="new-chat-btn" ?disabled=${!this.activeChatId} @click=${this.newChat}>
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
            >
              <line x1="12" y1="5" x2="12" y2="19" />
              <line x1="5" y1="12" x2="19" y2="12" />
            </svg>
            New Chat
          </button>
          ${this.chatList.length?a`
                <div class="chat-list">
                  ${this.chatList.map(e=>a`
                      <div
                        class="chat-item ${e.id===this.activeChatId?`active`:``}"
                        @click=${()=>this.selectChat(e.id)}
                      >
                        <span class="chat-item-indicator">
                          ${e.id===this.activeChatId?a`<svg
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="2"
                                stroke-linecap="round"
                                stroke-linejoin="round"
                              >
                                <path
                                  d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"
                                ></path>
                              </svg>`:``}
                        </span>
                        <span class="chat-item-title">${e.title}</span>
                        <span class="chat-item-trailing">
                          <span class="chat-item-time">${Fe(e.updatedAt*1e3)}</span>
                          <button
                            class="chat-item-delete"
                            title="Delete chat"
                            @click=${t=>this.deleteChat(t,e.id)}
                          >
                            <svg
                              width="14"
                              height="14"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              stroke-width="2"
                              stroke-linecap="round"
                              stroke-linejoin="round"
                            >
                              <polyline points="3 6 5 6 21 6"></polyline>
                              <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"></path>
                              <path d="M10 11v6"></path>
                              <path d="M14 11v6"></path>
                            </svg>
                          </button>
                        </span>
                      </div>
                    `)}
                </div>
              `:``}
        </div>

        ${this.renderAccordion(`status`,`Status`,a`
            <div class="status-grid">
              <span class="status-label">Model</span>
              <span class="status-value">${this.model||`—`}</span>
              <span class="status-label">Tools</span>
              <span class="status-value">${this.toolCount}</span>
              <span class="status-label">Context</span>
              <span class="status-value">
                ${this.contextWindow?`${(this.contextWindow/1e3).toFixed(1)}k tokens`:`—`}
              </span>
            </div>
          `)}
        ${this.sessionId?this.renderAccordion(`session`,`Session`,a`<div class="session-id">${this.sessionId}</div>`):``}
        ${this.renderAccordion(`model`,`Model`,a`<model-selector></model-selector>`)}
        ${this.renderAccordion(`mcp`,`MCP Servers`,a`<mcp-manager></mcp-manager>`)}
        ${this.renderAccordion(`skills`,`Skills`,a`<skill-selector></skill-selector>`)}
        ${this.renderAccordion(`context`,`Context`,a`<context-editor></context-editor>`)}
        ${this.renderAccordion(`policies`,`Tool Policies`,a`<tool-policy-editor></tool-policy-editor>`)}
        ${this.renderAccordion(`settings`,`Settings`,a`<auto-refresh-settings></auto-refresh-settings>`)}
      </div>
    `}},Ye.styles=d`
    :host {
      display: flex;
      flex-direction: column;
      height: 100%;
      background: var(--bg-sidebar);
      border-right: none;
      overflow: hidden;
    }

    .new-chat-btn {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 8px 14px;
      border-radius: var(--radius-sm);
      background: var(--accent-primary);
      color: var(--text-inverse);
      font-size: var(--font-size-sm);
      font-weight: var(--font-weight-medium);
      border: none;
      cursor: pointer;
      transition: background var(--transition-fast);
    }

    .new-chat-btn:hover:not(:disabled) {
      background: var(--accent-hover);
    }

    .new-chat-btn:disabled {
      background: var(--bg-tertiary);
      color: var(--text-secondary);
      cursor: default;
    }

    .new-chat-btn svg {
      width: 14px;
      height: 14px;
    }

    .body {
      flex: 1;
      overflow-y: auto;
      padding: 12px;
      display: flex;
      flex-direction: column;
      gap: 16px;
      scrollbar-width: thin;
      scrollbar-color: var(--border-primary) transparent;
    }

    .body::-webkit-scrollbar {
      width: 4px;
    }

    .body::-webkit-scrollbar-track {
      background: transparent;
    }

    .body::-webkit-scrollbar-thumb {
      background: var(--border-primary);
      border-radius: 2px;
    }

    .section {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    .section-title {
      font-size: var(--font-size-xs);
      font-weight: var(--font-weight-bold);
      color: var(--text-tertiary);
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }

    .status-grid {
      display: grid;
      grid-template-columns: auto 1fr;
      gap: 4px 12px;
      font-size: var(--font-size-sm);
    }

    .status-label {
      color: var(--text-tertiary);
    }

    .status-value {
      color: var(--text-primary);
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .session-id {
      font-family: var(--font-mono);
      font-size: var(--font-size-xs);
      color: var(--text-tertiary);
      padding: 4px 0;
      word-break: break-all;
    }

    .footer {
      padding: 12px 16px;
      border-top: 1px solid var(--border-secondary);
      display: flex;
      align-items: center;
      justify-content: space-between;
    }

    .error-banner {
      padding: 8px 12px;
      background: var(--accent-danger);
      color: var(--text-inverse);
      font-size: var(--font-size-sm);
      border-radius: var(--radius-xs);
    }

    .warning-banner {
      padding: 8px 12px;
      background: var(--accent-warning, #b45309);
      color: var(--text-inverse, #fff);
      font-size: var(--font-size-sm);
      border-radius: var(--radius-xs);
    }

    .chat-list {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }

    .chat-item {
      display: flex;
      align-items: center;
      gap: 4px;
      padding: 6px 10px;
      border-radius: var(--radius-xs);
      cursor: pointer;
      transition: background var(--transition-fast);
    }

    .chat-item:hover {
      background: var(--bg-hover);
    }

    .chat-item.active {
      background: var(--bg-active, var(--bg-hover));
    }

    .chat-item-indicator {
      flex-shrink: 0;
      width: 14px;
      height: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: var(--accent-primary);
    }

    .chat-item-indicator svg {
      width: 14px;
      height: 14px;
    }

    .chat-item-title {
      flex: 1;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      font-size: var(--font-size-sm);
      color: var(--text-primary);
    }

    .chat-item-trailing {
      flex-shrink: 0;
      display: grid;
      place-items: center;
    }

    .chat-item-trailing > * {
      grid-area: 1 / 1;
    }

    .chat-item-time {
      font-size: var(--font-size-xs);
      color: var(--text-tertiary);
      pointer-events: none;
      transition: opacity var(--transition-fast);
    }

    .chat-item-delete {
      z-index: 1;
      background: none;
      border: none;
      cursor: pointer;
      color: var(--text-tertiary);
      padding: 2px;
      border-radius: var(--radius-xs);
      line-height: 1;
      opacity: 0;
      transition:
        opacity var(--transition-fast),
        color var(--transition-fast);
    }

    .chat-item-delete:hover {
      color: var(--accent-danger);
    }

    .chat-item:hover .chat-item-delete {
      opacity: 1;
    }

    .chat-item:hover .chat-item-time {
      opacity: 0;
    }

    .accordion {
      display: flex;
      flex-direction: column;
    }

    .accordion-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      cursor: pointer;
      user-select: none;
      padding: 2px 0;
    }

    .accordion-header:hover .accordion-chevron {
      color: var(--text-primary);
    }

    .accordion-chevron {
      width: 14px;
      height: 14px;
      color: var(--text-tertiary);
      transition:
        transform var(--transition-fast),
        color var(--transition-fast);
      flex-shrink: 0;
    }

    .accordion-chevron.open {
      transform: rotate(90deg);
    }

    .accordion-body {
      display: grid;
      grid-template-rows: 0fr;
      transition: grid-template-rows 0.2s ease;
    }

    .accordion-body.open {
      grid-template-rows: 1fr;
    }

    .accordion-body > div {
      overflow: hidden;
      padding-top: 0;
      transition: padding-top 0.2s ease;
    }

    .accordion-body.open > div {
      padding-top: 8px;
    }
  `,Ye);N([i()],Xe.prototype,`model`,void 0),N([i()],Xe.prototype,`toolCount`,void 0),N([i()],Xe.prototype,`contextWindow`,void 0),N([i()],Xe.prototype,`sessionId`,void 0),N([i()],Xe.prototype,`activeChatId`,void 0),N([i()],Xe.prototype,`chatList`,void 0),N([i()],Xe.prototype,`error`,void 0),N([i()],Xe.prototype,`warning`,void 0),N([i()],Xe.prototype,`openSections`,void 0),Xe=N([s(`agent-sidebar`)],Xe);var Ze,Qe={Health:`monitor_heart`,Migration:`swap_horiz`,Setup:`build`};function $e(e){return e.split(`-`).map(e=>e.charAt(0).toUpperCase()+e.slice(1)).join(` `)}var et=(Ze=class extends l{constructor(...e){super(...e),this.messages=[],this.playbooks=[],this.showPlaybooks=!1,this.hasUserToggledPlaybooks=!1}connectedCallback(){super.connectedCallback(),this.unsubscribe=O.subscribe(()=>{let e=this.messages;this.messages=O.state.messages,this.playbooks=O.state.availablePlaybooks,e.length>0&&this.messages.length===0&&(this.hasUserToggledPlaybooks=!1),this.hasUserToggledPlaybooks||(this.showPlaybooks=this.messages.length===0),this.messages!==e&&this.scrollToBottom()})}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.()}scrollToBottom(){requestAnimationFrame(()=>{this.scrollContainer&&(this.scrollContainer.scrollTop=this.scrollContainer.scrollHeight)})}onTogglePlaybooks(){this.hasUserToggledPlaybooks=!0,this.showPlaybooks=!this.showPlaybooks}onPlaybookClick(e){this.showPlaybooks=!1,this.dispatchEvent(new CustomEvent(`send-message`,{detail:{message:e.body},bubbles:!0,composed:!0}))}renderPlaybooks(){if(!this.playbooks.length)return r;let e=new Map;for(let t of this.playbooks){let n=e.get(t.category)??[];n.push(t),e.set(t.category,n)}return a`${Array.from(e.entries()).map(([e,t])=>a`
        <div class="playbook-section">
          <div class="playbook-category">${e}</div>
          <div class="playbook-grid">
            ${t.map(t=>a`
                <div class="playbook-card" @click=${()=>this.onPlaybookClick(t)}>
                  <span class="card-icon">${Qe[e]??`article`}</span>
                  <div class="card-text">
                    <div class="card-name">${$e(t.name)}</div>
                    <div class="card-desc">${t.description}</div>
                  </div>
                </div>
              `)}
          </div>
        </div>
      `)}`}render(){return a`
      ${this.messages.length>0?a`
            <div class="messages-scroll">
              <div class="messages">
                ${o(this.messages,e=>e.id,e=>a`<chat-message .msg=${e}></chat-message>`)}
              </div>
            </div>
          `:a`
            <div class="empty-state ${this.showPlaybooks?`compact`:``}">
              <div class="empty-header">
                <span class="empty-icon">forklift</span>
                <div class="empty-title">Moving your virtual machines?</div>
                <div class="empty-hint">Pick a playbook to get started, or ask me anything.</div>
              </div>
            </div>
          `}

      <div class="composer-area">
        <div class="composer-inner">
          <chat-composer
            .playbooksOpen=${this.showPlaybooks}
            @toggle-playbooks=${this.onTogglePlaybooks}
          ></chat-composer>
          <div class="playbook-panel ${this.showPlaybooks?`open`:``}">
            ${this.renderPlaybooks()}
          </div>
        </div>
      </div>
    `}},Ze.styles=d`
    :host {
      display: flex;
      flex-direction: column;
      height: 100%;
      overflow: hidden;
    }

    .messages-scroll {
      flex: 1;
      overflow-y: auto;
      overflow-x: hidden;
      padding: 60px 24px 12px;
      scroll-behavior: smooth;
      scrollbar-width: thin;
      scrollbar-color: var(--border-primary) transparent;
    }

    .messages-scroll::-webkit-scrollbar {
      width: 6px;
    }

    .messages-scroll::-webkit-scrollbar-track {
      background: transparent;
    }

    .messages-scroll::-webkit-scrollbar-thumb {
      background: var(--border-primary);
      border-radius: 3px;
    }

    .messages {
      max-width: var(--chat-max-width);
      margin: 0 auto;
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    .empty-state {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      overflow-y: auto;
      padding: 24px;
      scrollbar-width: thin;
      scrollbar-color: var(--border-primary) transparent;
    }

    .empty-state.compact {
      flex: none;
      justify-content: flex-end;
      min-height: 180px;
    }

    .empty-header {
      text-align: center;
      margin-bottom: 32px;
    }

    .empty-icon {
      font-family: "Material Symbols Outlined";
      font-weight: normal;
      font-style: normal;
      font-size: 48px;
      line-height: 1;
      letter-spacing: normal;
      text-transform: none;
      white-space: nowrap;
      direction: ltr;
      font-feature-settings: "liga";
      -webkit-font-smoothing: antialiased;
      opacity: 0.4;
      color: var(--text-tertiary);
    }

    .empty-title {
      font-size: var(--font-size-lg);
      font-weight: var(--font-weight-medium);
      color: var(--text-secondary);
      margin-top: 12px;
    }

    .empty-hint {
      font-size: var(--font-size-sm);
      color: var(--text-tertiary);
      margin-top: 4px;
    }

    .playbook-section {
      width: 100%;
      max-width: var(--chat-max-width);
      margin-bottom: 24px;
    }

    .playbook-category {
      font-size: var(--font-size-xs, 11px);
      font-weight: var(--font-weight-semibold, 600);
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: var(--text-tertiary);
      margin-bottom: 8px;
      padding-left: 4px;
    }

    .playbook-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
      gap: 10px;
    }

    .playbook-card {
      display: flex;
      align-items: flex-start;
      gap: 12px;
      padding: 14px 16px;
      border-radius: var(--radius-lg, 12px);
      border: 1px solid var(--border-primary);
      background: var(--bg-secondary);
      cursor: pointer;
      transition:
        border-color var(--transition-fast),
        box-shadow var(--transition-fast);
    }

    .playbook-card:hover {
      border-color: var(--accent-primary);
      box-shadow: 0 0 0 1px var(--accent-primary);
    }

    .card-icon {
      font-family: "Material Symbols Outlined";
      font-weight: normal;
      font-style: normal;
      font-size: 22px;
      line-height: 1;
      letter-spacing: normal;
      text-transform: none;
      white-space: nowrap;
      direction: ltr;
      font-feature-settings: "liga";
      -webkit-font-smoothing: antialiased;
      color: var(--accent-primary);
      flex-shrink: 0;
      margin-top: 1px;
    }

    .card-text {
      display: flex;
      flex-direction: column;
      gap: 2px;
      min-width: 0;
    }

    .card-name {
      font-size: var(--font-size-sm);
      font-weight: var(--font-weight-medium);
      color: var(--text-primary);
    }

    .card-desc {
      font-size: var(--font-size-xs, 11px);
      color: var(--text-tertiary);
      line-height: 1.4;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }

    .composer-area {
      padding: 8px 24px 24px;
    }

    .composer-inner {
      max-width: var(--chat-max-width);
      margin: 0 auto;
    }

    .playbook-panel {
      max-width: var(--chat-max-width);
      margin: 0 auto;
      overflow: hidden;
      max-height: 0;
      opacity: 0;
      transition:
        max-height 0.3s ease,
        opacity 0.25s ease,
        padding 0.3s ease;
      padding: 0;
    }

    .playbook-panel.open {
      max-height: min(2000px, 60vh);
      opacity: 1;
      padding: 12px 0 0;
      overflow-y: auto;
      scrollbar-width: thin;
      scrollbar-color: var(--border-primary) transparent;
    }
  `,Ze);N([i()],et.prototype,`messages`,void 0),N([i()],et.prototype,`playbooks`,void 0),N([i()],et.prototype,`showPlaybooks`,void 0),N([c(`.messages-scroll`)],et.prototype,`scrollContainer`,void 0),et=N([s(`agent-chat`)],et);var tt,nt=(tt=class extends l{constructor(...e){super(...e),this.userExpanded=!1,this.userOverflows=!1}updated(){this.msg.role!==`user`||!this.msg.content||(this.renderRoot.querySelector(`markdown-renderer`)?.updateComplete??Promise.resolve()).then(()=>{requestAnimationFrame(()=>this._measureOverflow())})}_measureOverflow(){let e=this.renderRoot.querySelector(`.bubble`);if(!e)return;let t=this.userExpanded?!0:e.scrollHeight>e.clientHeight+1;t!==this.userOverflows&&(this.userOverflows=t)}toggleExpand(){this.userExpanded=!this.userExpanded}formatTime(e){return new Date(e).toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`})}render(){let e=this.msg,t=e.role===`user`,n=e.role===`assistant`&&e.cancelled===!0;return a`
      <div class="message ${e.role}${n?` cancelled`:``}">
        ${t?r:a`<span class="role-label">Assistant</span>`}
        ${e.thinking?a`<thinking-indicator></thinking-indicator>`:r}
        ${e.toolCalls?.length?a`
              <div class="tool-calls">
                ${e.toolCalls.map(e=>a`<tool-call-card .entry=${e} .sessionId=${this.msg.id}></tool-call-card>`)}
              </div>
            `:r}
        ${e.content?t?a`
                <div class="bubble-wrapper">
                  <div class="bubble ${this.userExpanded?``:`truncated`}">
                    <markdown-renderer .content=${e.content}></markdown-renderer>
                  </div>
                  ${this.userOverflows?a`<button
                        class="expand-toggle"
                        @click=${this.toggleExpand}
                        title=${this.userExpanded?`Collapse`:`Expand`}
                      >
                        ${this.userExpanded?`▽`:`◁`}
                      </button>`:r}
                </div>
              `:a`
                <div class="bubble">
                  <markdown-renderer .content=${e.content}></markdown-renderer>
                </div>
              `:r}
        ${n?a`<span class="cancelled-label" aria-label="This response was cancelled"
              >cancelled<span class="sr-only"> — response was interrupted</span></span
            >`:r}
        <span class="timestamp">${this.formatTime(e.timestamp)}</span>
      </div>
    `}},tt.styles=d`
    :host {
      display: block;
      padding: 4px 0;
      animation: fadeIn 0.25s ease;
    }

    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(8px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .message {
      display: flex;
      flex-direction: column;
      max-width: 100%;
    }

    .message.user {
      align-items: flex-end;
    }

    .message.assistant {
      align-items: flex-start;
    }

    .bubble {
      max-width: 85%;
      border-radius: var(--radius-lg);
      line-height: var(--line-height);
    }

    .user .bubble-wrapper .bubble {
      max-width: 100%;
    }

    .user .bubble-wrapper {
      position: relative;
      max-width: 85%;
    }

    .user .bubble {
      background: var(--bg-user-bubble);
      color: var(--text-primary);
      padding: 10px 16px;
      border-bottom-right-radius: var(--radius-xs);
      --md-h1-size: 1em;
      --md-h2-size: 1em;
      --md-h3-size: 1em;
      --md-h4-size: 1em;
    }

    .user .bubble.truncated {
      max-height: 6.4em;
      overflow: hidden;
    }

    .expand-toggle {
      position: absolute;
      top: 4px;
      right: 4px;
      display: flex;
      align-items: center;
      justify-content: center;
      width: 22px;
      height: 22px;
      font-size: 14px;
      line-height: 1;
      color: var(--text-tertiary);
      background: var(--bg-user-bubble);
      border: none;
      border-radius: var(--radius-xs);
      cursor: pointer;
      padding: 0;
      z-index: 1;
    }

    .expand-toggle:hover {
      color: var(--text-secondary);
    }

    .assistant .bubble {
      background: var(--bg-assistant);
      color: var(--text-primary);
      max-width: 100%;
      padding: 4px 0;
    }

    .tool-calls {
      display: flex;
      flex-direction: column;
      gap: 6px;
      margin: 8px 0;
      max-width: 100%;
    }

    .timestamp {
      font-size: var(--font-size-xs);
      color: var(--text-tertiary);
      margin-top: 4px;
      padding: 0 4px;
    }

    .role-label {
      font-size: var(--font-size-xs);
      font-weight: var(--font-weight-medium);
      color: var(--text-tertiary);
      margin-bottom: 4px;
      padding: 0 4px;
      text-transform: uppercase;
      letter-spacing: 0.04em;
    }

    .message.assistant.cancelled .bubble {
      opacity: 0.7;
      border-left: 3px solid #d32f2f;
      padding-left: 8px;
    }

    .cancelled-label {
      font-size: var(--font-size-xs);
      color: #d32f2f;
      font-style: italic;
      margin-top: 2px;
      padding: 0 4px;
    }

    .sr-only {
      position: absolute;
      width: 1px;
      height: 1px;
      padding: 0;
      margin: -1px;
      overflow: hidden;
      clip: rect(0, 0, 0, 0);
      white-space: nowrap;
      border: 0;
    }
  `,tt);N([n({type:Object})],nt.prototype,`msg`,void 0),N([i()],nt.prototype,`userExpanded`,void 0),N([i()],nt.prototype,`userOverflows`,void 0),nt=N([s(`chat-message`)],nt);var rt,it=(rt=class extends l{constructor(...e){super(...e),this.playbooksOpen=!1,this.text=``,this.isStreaming=!1,this.usage=null,this.elapsed=null}connectedCallback(){super.connectedCallback(),this.unsubscribe=O.subscribe(()=>{this.isStreaming=O.state.isStreaming,this.usage=O.state.usage,this.elapsed=O.state.streamElapsed})}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.()}autoResize(){let e=this.textarea;e&&(e.style.height=`auto`,e.scrollHeight>e.clientHeight?e.style.height=Math.min(e.scrollHeight,200)+`px`:e.style.removeProperty(`height`))}handleInput(e){this.text=e.target.value,this.autoResize()}handleKeyDown(e){e.key===`Enter`&&!e.shiftKey&&(e.preventDefault(),this.send())}togglePlaybooks(){this.dispatchEvent(new CustomEvent(`toggle-playbooks`,{bubbles:!0,composed:!0}))}send(){let e=this.text.trim();!e||this.isStreaming||(this.text=``,this.textarea&&(this.textarea.style.height=`auto`),this.dispatchEvent(new CustomEvent(`send-message`,{detail:{message:e},bubbles:!0,composed:!0})))}cancel(){this.dispatchEvent(new CustomEvent(`cancel-stream`,{bubbles:!0,composed:!0}))}formatTokens(e){return e>=1e3?`${(e/1e3).toFixed(1)}k`:String(e)}render(){return a`
      ${this.usage||this.elapsed!==null?a`
            <div class="usage-bar">
              ${this.usage?a`<span>
                    ${this.formatTokens(this.usage.totalTokens)} /
                    ${this.formatTokens(this.usage.contextWindow)} tokens
                  </span>`:``}
              ${this.elapsed===null?``:a`<span>${this.elapsed.toFixed(1)}s</span>`}
            </div>
          `:``}

      <div class="composer">
        <button
          class="toggle-btn ${this.playbooksOpen?`open`:``}"
          @click=${this.togglePlaybooks}
          title="${this.playbooksOpen?`Hide playbooks`:`Show playbooks`}"
          aria-label="${this.playbooksOpen?`Hide playbooks`:`Show playbooks`}"
        >
          <span class="material-symbols-outlined">add</span>
        </button>
        <textarea
          rows="1"
          placeholder="Send a message..."
          .value=${this.text}
          @input=${this.handleInput}
          @keydown=${this.handleKeyDown}
        ></textarea>
        ${this.isStreaming?a`<button class="send-btn stop" @click=${this.cancel} title="Stop" aria-label="Stop">
              <span class="material-symbols-outlined">forklift</span>
            </button>`:a`<button
              class="send-btn"
              @click=${this.send}
              ?disabled=${!this.text.trim()}
              title="Send message"
              aria-label="Send message"
            >
              <span class="material-symbols-outlined">forklift</span>
            </button>`}
      </div>
    `}},rt.styles=d`
    :host {
      display: block;
    }

    .usage-bar {
      display: flex;
      align-items: center;
      justify-content: flex-end;
      gap: 12px;
      padding: 4px 8px;
      font-size: var(--font-size-xs);
      color: var(--text-tertiary);
    }

    .composer {
      display: flex;
      align-items: flex-end;
      gap: 8px;
      padding: 12px 16px;
      background: var(--bg-input);
      border: 1px solid var(--border-primary);
      border-radius: var(--radius-xl);
      box-shadow: var(--shadow-md);
      transition:
        border-color var(--transition-fast),
        box-shadow var(--transition-fast);
    }

    .composer:focus-within {
      border-color: var(--accent-primary);
      box-shadow:
        var(--shadow-md),
        0 0 0 2px rgba(174, 86, 48, 0.15);
    }

    textarea {
      flex: 1;
      border: none;
      background: none;
      resize: none;
      outline: none;
      font-family: var(--font-sans);
      font-size: var(--font-size-base);
      line-height: var(--line-height);
      color: var(--text-primary);
      max-height: 200px;
      min-height: 24px;
      padding: 7px 0;
    }

    textarea::placeholder {
      color: var(--text-tertiary);
    }

    .send-btn {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 36px;
      height: 36px;
      border: none;
      border-radius: var(--radius-full);
      background: var(--accent-primary);
      color: var(--text-inverse);
      cursor: pointer;
      flex-shrink: 0;
      transition:
        background var(--transition-fast),
        transform var(--transition-fast);
    }

    .send-btn:hover {
      background: var(--accent-hover);
    }

    .send-btn:active {
      transform: scale(0.95);
    }

    .send-btn:disabled {
      background: var(--bg-tertiary);
      color: var(--text-secondary);
      cursor: not-allowed;
    }

    .send-btn.stop {
      background: var(--status-error, #d32f2f);
    }

    .send-btn.stop:hover {
      background: color-mix(in srgb, var(--status-error, #d32f2f) 85%, black);
    }

    .send-btn .material-symbols-outlined {
      font-family: "Material Symbols Outlined";
      font-weight: normal;
      font-style: normal;
      font-size: 20px;
      line-height: 1;
      letter-spacing: normal;
      text-transform: none;
      white-space: nowrap;
      direction: ltr;
      font-feature-settings: "liga";
      -webkit-font-smoothing: antialiased;
    }

    .toggle-btn {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 36px;
      height: 36px;
      border: none;
      border-radius: var(--radius-full);
      background: transparent;
      color: var(--text-tertiary);
      cursor: pointer;
      flex-shrink: 0;
      transition:
        color var(--transition-fast),
        background var(--transition-fast),
        transform var(--transition-fast);
    }

    .toggle-btn:hover {
      color: var(--accent-primary);
      background: var(--bg-secondary);
    }

    .toggle-btn.open {
      color: var(--accent-primary);
      transform: rotate(45deg);
    }

    .toggle-btn .material-symbols-outlined {
      font-family: "Material Symbols Outlined";
      font-weight: normal;
      font-style: normal;
      font-size: 22px;
      line-height: 1;
      letter-spacing: normal;
      text-transform: none;
      white-space: nowrap;
      direction: ltr;
      font-feature-settings: "liga";
      -webkit-font-smoothing: antialiased;
    }
  `,rt);N([n({type:Boolean})],it.prototype,`playbooksOpen`,void 0),N([i()],it.prototype,`text`,void 0),N([i()],it.prototype,`isStreaming`,void 0),N([i()],it.prototype,`usage`,void 0),N([i()],it.prototype,`elapsed`,void 0),N([c(`textarea`)],it.prototype,`textarea`,void 0),it=N([s(`chat-composer`)],it);var at={table:`markdown`,graph:`graph`,markdown:`markdown`,text:`text`,log:`text`,raw:`text`};function ot(e){return at[e]}function st(e){let t=p.lexer(e);for(let e of t)if(e.type===`table`){let t=e;return{headers:t.header.map(e=>e.text),rows:t.rows.map(e=>e.map(e=>e.text))}}return null}function ct(e){return e.replace(/^-+\s*/,``).replace(/\s*-+$/,``).trim()}function lt(e){let t=p.lexer(e),n=[],r;for(let e of t)if(e.type===`heading`)r=ct(e.text);else if(e.type===`table`){let t=e;n.push({heading:r,table:{headers:t.header.map(e=>e.text),rows:t.rows.map(e=>e.map(e=>e.text))}}),r=void 0}else e.type!==`space`&&(r=void 0);return n}function ut(e){let t=[0],n=0;for(let r=0;r<e.length;r++)e[r]===` `?n++:(n>=2&&t.push(r),n=0);return t}function dt(e){let t=e.split(`
`).filter(e=>e.trim());if(t.length<2)return null;let n=ut(t[0]);if(n.length<2)return null;let r=e=>n.map((t,r)=>{let i=r<n.length-1?n[r+1]:e.length;return e.substring(t,i).trim()});return{headers:r(t[0]),rows:t.slice(1).map(e=>r(e))}}function ft(e){let t=e.search(/[[{]/);if(t<0)return null;let n=e.slice(t);try{return JSON.parse(n)}catch{return null}}function pt(e){return e==null?``:typeof e==`object`?JSON.stringify(e):String(e)}function mt(e){let t=ft(e);if(typeof t!=`object`||!t)return null;let n=[];if(Array.isArray(t))for(let e of t)typeof e==`object`&&e&&!Array.isArray(e)&&n.push(e);else n.push(t);if(n.length===0)return null;let r=new Set;for(let e of n)for(let t of Object.keys(e))r.add(t);let i=[...r];return i.length===0?null:{headers:i,rows:n.map(e=>i.map(t=>pt(e[t])))}}function ht(e){return st(e)??dt(e)??mt(e)}var gt=new Set([`true`,`yes`]),_t=new Set([`false`,`no`]);function vt(e){let t=e.trim();if(!t)return t;let n=t.toLowerCase();if(gt.has(n))return`true`;if(_t.has(n))return`false`;if(/^[+-]?\d+(\.\d+)?$/.test(t)){let e=parseFloat(t);if(!isNaN(e))return String(e)}return t}function yt(e){return{headers:e.headers,rows:e.rows.map(e=>e.map(vt))}}function bt(e){let t=e=>`| `+e.join(` | `)+` |`,n=e.headers.map(()=>`---`);return[t(e.headers),t(n),...e.rows.map(t)].join(`
`)}function xt(e){if(!e?.trim())return e;let t=ht(e);return t?bt(yt(t)):e}function P(e){return e?.trim()?xt(e):e}function F(e){return e}var St=`mtv_read`,I=`user-kubectl-mtv`,Ct=[`get plan`,`get provider`,`get hook`,`get host`,`get mapping`];function wt(e){return typeof e.command==`string`?e.command.trim():``}var Tt=[{server:I,tool:St,category:`inventory-list`,renderer:`table`,canPin:!0,canPinGraph:!1,match(e){return wt(e).startsWith(`get inventory`)},parse:P},{server:I,tool:St,category:`resource-describe`,renderer:`markdown`,canPin:!0,canPinGraph:!1,match(e){return wt(e).startsWith(`describe`)},parse:F},{server:I,tool:St,category:`health`,renderer:`markdown`,canPin:!0,canPinGraph:!1,match(e){return wt(e)===`health`},parse:F},{server:I,tool:St,category:`settings`,renderer:`table`,canPin:!0,canPinGraph:!1,match(e){let t=wt(e);return t===`settings`||t===`settings get`},parse:P},{server:I,tool:St,category:`resource-list`,renderer:`table`,canPin:!0,canPinGraph:!1,match(e){let t=wt(e);return Ct.some(e=>t===e||t.startsWith(e+` `))},parse:P}],Et=[{server:`user-kubectl-mtv`,tool:`mtv_write`,category:`write`,renderer:`markdown`,canPin:!1,canPinGraph:!1,match(){return!0},parse:F}],Dt=[{server:`user-kubectl-mtv`,tool:`mtv_help`,category:`help`,renderer:`markdown`,canPin:!1,canPinGraph:!1,match(){return!0},parse:F}];function Ot(e){return e}var kt=`metrics_read`,At=`user-kubectl-metrics`;function jt(e){return typeof e.command==`string`?e.command.trim():``}var Mt=[{server:At,tool:kt,category:`query-range`,renderer:`graph`,canPin:!0,canPinGraph:!0,match(e){let t=jt(e);return t===`query_range`||t===`preset`},parse:Ot},{server:At,tool:kt,category:`query`,renderer:`table`,canPin:!0,canPinGraph:!1,match(e){return jt(e)===`query`},parse:P},{server:At,tool:kt,category:`discover`,renderer:`table`,canPin:!0,canPinGraph:!1,match(e){let t=jt(e);return t===`discover`||t===`labels`},parse:P}],Nt=[{server:`user-kubectl-metrics`,tool:`metrics_help`,category:`help`,renderer:`markdown`,canPin:!1,canPinGraph:!1,match(){return!0},parse:F}];function Pt(e){return e?.trim()?"```\n"+e.trimEnd()+"\n```":e}var Ft=`debug_read`,It=`user-kubectl-debug-queries`;function Lt(e){return typeof e.command==`string`?e.command.trim():``}var Rt=[{server:It,tool:Ft,category:`resource-list`,renderer:`table`,canPin:!0,canPinGraph:!1,match(e){return Lt(e)===`list`},parse:P},{server:It,tool:Ft,category:`resource-get`,renderer:`markdown`,canPin:!0,canPinGraph:!1,match(e){return Lt(e)===`get`},parse:F},{server:It,tool:Ft,category:`logs`,renderer:`log`,canPin:!0,canPinGraph:!1,match(e){return Lt(e)===`logs`},parse:Pt},{server:It,tool:Ft,category:`events`,renderer:`table`,canPin:!0,canPinGraph:!1,match(e){return Lt(e)===`events`},parse:P}],zt=[{server:`user-kubectl-debug-queries`,tool:`debug_help`,category:`help`,renderer:`markdown`,canPin:!1,canPinGraph:!1,match(){return!0},parse:F}],Bt=[{server:`builtin`,tool:`web_fetch`,category:`web-fetch`,renderer:`markdown`,canPin:!0,canPinGraph:!1,match(){return!0},parse:F}],Vt=[...Tt,...Et,...Dt,...Mt,...Nt,...Rt,...zt,...Bt];function Ht(e){if(!e?.trim())return{text:``,hasError:!0,errorMessage:`Empty tool result`};try{let t=JSON.parse(e);if(!t||typeof t!=`object`)return{text:e,hasError:!1};let n=t.return_value,r=typeof t.output==`string`?t.output:``,i=typeof t.stderr==`string`?t.stderr.trim():``;if(typeof n==`number`&&n!==0){let e=i||r||`Tool exited with code ${n}`;return{text:r||i,hasError:!0,errorMessage:e}}return i&&typeof n!=`number`?{text:r,hasError:!0,errorMessage:i}:typeof t.output==`string`?{text:r,hasError:!1}:{text:e,hasError:!1}}catch{return{text:e,hasError:!1}}}function Ut(e){return e?.trim()?"```\n"+e.trimEnd()+"\n```":e}var Wt=new Set([`json`,`yaml`]);function Gt(e,t){return"```"+t+`
`+e.trimEnd()+"\n```"}var Kt=new Map;for(let e of Vt){let t=Kt.get(e.tool)??[];t.push(e),Kt.set(e.tool,t)}function qt(e){let t=e.flags;if(t&&typeof t==`object`&&!Array.isArray(t)){let e=t.output;if(typeof e==`string`)return e}if(typeof e.output==`string`)return e.output}function Jt(e){return typeof e.command==`string`?e.command.trim():``}function Yt(e,t){let n=Kt.get(e);if(n){for(let e of n)if(e.match(t))return{identified:!0,server:e.server,tool:e.tool,command:Jt(t),category:e.category,renderer:e.renderer,outputFlag:qt(t),canPin:e.canPin,canPinGraph:e.canPinGraph}}return{identified:!1,server:`unknown`,tool:e,command:Jt(t),category:`unknown`,renderer:`raw`,outputFlag:qt(t),canPin:!1,canPinGraph:!1}}function Xt(e){if(e.identified)return Kt.get(e.tool)?.find(t=>t.category===e.category)}function Zt(e,t){let n=Ht(t),r=`text`;if(n.hasError)return{hasError:!0,errorMessage:n.errorMessage,content:n.text||n.errorMessage||t,displayType:r,raw:t};let i=Xt(e),a=n.text,o=e.outputFlag?.toLowerCase();return o&&Wt.has(o)?{hasError:!1,content:Gt(a,o),displayType:`markdown`,raw:t}:o===`markdown`?{hasError:!1,content:i?i.parse(a):a,displayType:`markdown`,raw:t}:{hasError:!1,content:i?i.parse(a):Ut(a),displayType:i?ot(i.renderer):r,raw:t}}var Qt={k:1e3,K:1e3,M:1e6,G:1e9,T:0xe8d4a51000};function $t(e){let t=e.trim();if(!t)return NaN;let n=t.match(/^([+-]?\d+(?:\.\d+)?)\s*([kKMGT])?$/);return n?parseFloat(n[1])*(n[2]?Qt[n[2]]??1:1):NaN}function en(e,t){let{headers:n,rows:r}=e,i=n.findIndex(e=>/^timestamp$/i.test(e));if(i<0)return[];let a=n.map((e,t)=>({name:e,idx:t})).filter(({idx:e})=>e!==i);if(a.length===0)return[];let o=[];for(let e of a){let n=t??e.name,a=[];for(let t of r){let n=t[i]?.trim(),r=t[e.idx]?.trim();if(!n||!r)continue;let o=Date.parse(n);if(isNaN(o)){let e=Number(n);isNaN(e)||(o=e<0xe8d4a51000?e*1e3:e)}let s=$t(r);isNaN(o)||isNaN(s)||a.push({x:o,y:s})}a.length>0&&(a.sort((e,t)=>e.x-t.x),o.push({name:n,data:a}))}return o}function tn(e){let t=e.trim().split(`
`);return t.length<2?null:{headers:t[0].split(`	`),rows:t.slice(1).map(e=>e.split(`	`))}}function nn(e){if(!e?.trim())return null;let t=e.slice(0,e.indexOf(`
`)).trim();if(t.includes(`	`)&&/\bTIMESTAMP\b/i.test(t)){let t=tn(e);if(t){let e=en(t);if(e.length>0)return{series:e}}}let n=lt(e);if(n.length>0){let e=n.flatMap(e=>en(e.table,e.heading));if(e.length>0)return{series:e}}let r=ht(e);if(!r)return null;let i=en(r);return i.length>0?{series:i}:null}function rn(e,t){let n=e+JSON.stringify(t),r=5381;for(let e=0;e<n.length;e++)r=(r<<5)+r+n.charCodeAt(e)>>>0;return`card-${r.toString(36)}`}function an(e){let t=Ht(e).text;return t?.trim()?nn(t):null}var on,sn=(on=class extends l{constructor(...e){super(...e),this.sessionId=``,this.expanded=!1,this.pinned=!1,this.graphPinned=!1,this.denyReasonInput=``,this._graphCacheValue=!1}get identification(){let e=this.entry,t=e.name+JSON.stringify(e.arguments);return this._idCacheKey===t&&this._idCacheValue?this._idCacheValue:(this._idCacheKey=t,this._idCacheValue=Yt(e.name,e.arguments),this._idCacheValue)}connectedCallback(){super.connectedCallback(),this.unsubscribe=O.subscribe(()=>this.syncPinned())}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.()}syncPinned(){let e=this.entry;e.result&&!e.denied&&(this.pinned=O.hasCard(rn(e.name,e.arguments)),this.graphPinned=O.hasCard(`graph-${rn(e.name,e.arguments)}`))}toggle(){this.expanded=!this.expanded}pinCard(e){e.stopPropagation();let t=this.entry,n=rn(t.name,t.arguments);if(O.hasCard(n)){O.removeCard(n);return}let r=t.arguments.command,i=r?`${t.name}: ${r}`:t.name,a=t.result,o={id:n,title:i,content:``,timestamp:Date.now(),toolName:t.name,toolArgs:t.arguments,loading:!0};this.dispatchEvent(new CustomEvent(`pin-card`,{detail:{card:o},bubbles:!0,composed:!0})),setTimeout(()=>{let e=Zt(this.identification,a),t=this.identification.canPinGraph?`text`:e.displayType;O.updateCard(n,{content:e.content,type:t,loading:!1})},0)}async approve(){let e=O.state.sessionId;if(e){O.updateLastToolCall(e=>({...e,pending:!1}));try{await M(e,!0)}catch{}}}async deny(){let e=O.state.sessionId;if(!e)return;let t=this.denyReasonInput.trim()||`denied by user`;this.denyReasonInput=``,O.updateLastToolCall(e=>({...e,pending:!1,denied:!0,denyReason:t}));try{await M(e,!1,t)}catch{}}get hasResultError(){return this.entry.result?Zt(this.identification,this.entry.result).hasError:!1}get statusBadge(){let e=this.entry;return e.denied?a`<span class="badge denied">denied</span>`:e.pending?a`<span class="badge waiting">waiting</span>`:e.result===void 0?a`<span class="badge running">running</span>`:this.hasResultError?a`<span class="badge error">error</span>`:a`<span class="badge done">done</span>`}get iconClass(){let e=this.entry;return e.denied?`denied`:e.pending?`pending`:e.result===void 0?`call`:`result`}get canPin(){let e=this.entry;return!e.result||e.denied?!1:this.identification.canPin}get canPinGraph(){let e=this.entry;if(!e.result||e.denied||!this.identification.canPinGraph)return!1;if(this._graphCacheKey===e.result)return this._graphCacheValue;this._graphCacheKey=e.result;let t=an(e.result);return this._graphCacheValue=t!==null&&t.series.length>0,this._graphCacheValue}get pinButton(){return this.canPin?a`
      <button
        class="pin-btn ${this.pinned?`pinned`:``}"
        @click=${this.pinCard}
        title=${this.pinned?`Pinned`:`Pin to detail pane`}
      >
        <svg
          viewBox="0 0 24 24"
          fill="${this.pinned?`currentColor`:`none`}"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        >
          <path d="M12 2 L12 12" />
          <path d="M18.5 8.5 C18.5 12 16 14 12 14 C8 14 5.5 12 5.5 8.5" />
          <path d="M12 14 L12 22" />
        </svg>
      </button>
    `:r}pinGraphCard(e){e.stopPropagation();let t=this.entry,n=`graph-${rn(t.name,t.arguments)}`;if(O.hasCard(n)){O.removeCard(n);return}let r=t.arguments.command,i={id:n,title:r?`${t.name}: ${r}`:t.name,content:t.result,timestamp:Date.now(),toolName:t.name,toolArgs:t.arguments,type:`graph`};this.dispatchEvent(new CustomEvent(`pin-card`,{detail:{card:i},bubbles:!0,composed:!0}))}get graphPinButton(){return this.canPinGraph?a`
      <button
        class="pin-btn ${this.graphPinned?`pinned`:``}"
        @click=${this.pinGraphCard}
        title=${this.graphPinned?`Graph pinned`:`Pin as graph`}
      >
        <svg
          viewBox="0 0 24 24"
          fill="${this.graphPinned?`currentColor`:`none`}"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        >
          <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
        </svg>
      </button>
    `:r}render(){let e=this.entry,t=JSON.stringify(e.arguments,null,2);return a`
      <div class="card">
        <div class="header" @click=${this.toggle}>
          <svg
            class="chevron ${this.expanded?`open`:``}"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <polyline points="9 18 15 12 9 6" />
          </svg>
          <svg
            class="icon ${this.iconClass}"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <path
              d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"
            />
          </svg>
          <span class="name">${e.name}</span>
          ${this.identification.identified?a`<span class="badge category">${this.identification.category}</span>`:r}
          ${this.statusBadge} ${this.graphPinButton} ${this.pinButton}
        </div>

        ${this.expanded?a`
              <div class="body">
                <div class="section-label">Arguments</div>
                <div class="code-block">${t}</div>

                ${e.result===void 0?r:a`
                      <div class="result-section">
                        <div class="section-label">Result</div>
                        <div class="code-block">${e.result}</div>
                      </div>
                    `}
                ${e.denied&&e.denyReason?a`
                      <div class="result-section">
                        <div class="section-label">Denial reason</div>
                        <div class="code-block">${e.denyReason}</div>
                      </div>
                    `:r}
              </div>
            `:r}
        ${e.pending?a`
              <div class="approval-bar">
                <input
                  class="deny-reason-input"
                  type="text"
                  placeholder="Reason for denial (optional)"
                  .value=${this.denyReasonInput}
                  @input=${e=>{this.denyReasonInput=e.target.value}}
                />
                <div class="approval-actions">
                  <span>Approve this tool call?</span>
                  <button class="deny-btn" @click=${this.deny}>Deny</button>
                  <button class="approve-btn" @click=${this.approve}>Approve</button>
                </div>
              </div>
            `:r}
      </div>
    `}},on.styles=d`
    :host {
      display: block;
    }

    .card {
      border: 1px solid var(--border-secondary);
      border-radius: var(--radius-sm);
      background: var(--bg-tool);
      overflow: hidden;
      font-size: var(--font-size-sm);
    }

    .header {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 8px 12px;
      background: var(--bg-tool-header);
      cursor: pointer;
      user-select: none;
      transition: background var(--transition-fast);
    }

    .header:hover {
      background: var(--bg-hover);
    }

    .chevron {
      width: 14px;
      height: 14px;
      color: var(--text-tertiary);
      transition: transform var(--transition-fast);
      flex-shrink: 0;
    }

    .chevron.open {
      transform: rotate(90deg);
    }

    .icon {
      width: 16px;
      height: 16px;
      flex-shrink: 0;
    }

    .icon.call {
      color: var(--accent-warning);
    }

    .icon.result {
      color: var(--accent-success);
    }

    .icon.denied {
      color: var(--accent-danger);
    }

    .icon.pending {
      color: var(--accent-info);
    }

    .name {
      font-weight: var(--font-weight-medium);
      color: var(--text-primary);
      flex: 1;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .badge {
      font-size: var(--font-size-xs);
      padding: 2px 6px;
      border-radius: var(--radius-full);
      font-weight: var(--font-weight-medium);
      white-space: nowrap;
    }

    .badge.category {
      background: rgba(50, 102, 173, 0.1);
      color: var(--text-tertiary);
      font-family: var(--font-mono);
    }

    .badge.running {
      background: rgba(59, 130, 246, 0.1);
      color: var(--accent-info);
    }

    .badge.done {
      background: rgba(34, 197, 94, 0.1);
      color: var(--accent-success);
    }

    .badge.error,
    .badge.denied {
      background: rgba(239, 68, 68, 0.1);
      color: var(--accent-danger);
    }

    .badge.waiting {
      background: rgba(59, 130, 246, 0.1);
      color: var(--accent-info);
    }

    .body {
      padding: 10px 12px;
      border-top: 1px solid var(--border-secondary);
    }

    .section-label {
      font-size: var(--font-size-xs);
      font-weight: var(--font-weight-bold);
      color: var(--text-tertiary);
      text-transform: uppercase;
      letter-spacing: 0.04em;
      margin-bottom: 4px;
    }

    .code-block {
      font-family: var(--font-mono);
      font-size: var(--font-size-xs);
      padding: 8px 10px;
      background: var(--bg-code);
      border-radius: var(--radius-xs);
      white-space: pre-wrap;
      word-break: break-all;
      overflow-x: auto;
      max-height: 300px;
      overflow-y: auto;
      color: var(--text-primary);
      line-height: 1.5;
    }

    .result-section {
      margin-top: 10px;
    }

    .approval-bar {
      display: flex;
      flex-direction: column;
      gap: 8px;
      padding: 10px 12px;
      border-top: 1px solid var(--border-secondary);
    }

    .deny-reason-input {
      width: 100%;
      box-sizing: border-box;
      padding: 6px 10px;
      font-size: var(--font-size-sm);
      font-family: inherit;
      color: var(--text-primary);
      background: var(--bg-code);
      border: 1px solid var(--border-primary);
      border-radius: var(--radius-xs);
      outline: none;
      transition: border-color var(--transition-fast);
    }

    .deny-reason-input::placeholder {
      color: var(--text-tertiary);
    }

    .deny-reason-input:focus {
      border-color: var(--accent-info);
    }

    .approval-actions {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .approval-actions span {
      flex: 1;
      font-size: var(--font-size-sm);
      color: var(--text-secondary);
    }

    .approve-btn,
    .deny-btn {
      padding: 6px 14px;
      border-radius: var(--radius-sm);
      font-size: var(--font-size-sm);
      font-weight: var(--font-weight-medium);
      cursor: pointer;
      transition: background var(--transition-fast);
    }

    .approve-btn {
      background: var(--accent-success);
      color: white;
    }

    .approve-btn:hover {
      filter: brightness(1.1);
    }

    .deny-btn {
      background: var(--bg-tertiary);
      color: var(--text-secondary);
      border: 1px solid var(--border-primary);
    }

    .deny-btn:hover {
      background: var(--bg-hover);
      color: var(--accent-danger);
    }

    .pin-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 24px;
      height: 24px;
      padding: 0;
      border: none;
      border-radius: var(--radius-xs);
      background: transparent;
      color: var(--text-tertiary);
      cursor: pointer;
      flex-shrink: 0;
      transition: all var(--transition-fast);
    }

    .pin-btn:hover {
      background: var(--bg-hover);
      color: var(--accent-primary);
    }

    .pin-btn.pinned {
      color: var(--accent-primary);
    }

    .pin-btn svg {
      width: 14px;
      height: 14px;
    }
  `,on);N([n({type:Object})],sn.prototype,`entry`,void 0),N([n({type:String})],sn.prototype,`sessionId`,void 0),N([i()],sn.prototype,`expanded`,void 0),N([i()],sn.prototype,`pinned`,void 0),N([i()],sn.prototype,`graphPinned`,void 0),N([i()],sn.prototype,`denyReasonInput`,void 0),sn=N([s(`tool-call-card`)],sn);var cn,ln=[{value:`auto-accept`,label:`Accept`},{value:`ask`,label:`Ask`},{value:`auto-reject`,label:`Reject`}],un=(cn=class extends l{constructor(...e){super(...e),this.tools=[],this.policies={}}connectedCallback(){super.connectedCallback(),this.unsubscribe=O.subscribe(()=>{this.tools=O.state.availableTools,this.policies=O.state.toolPolicies}),this.tools=O.state.availableTools,this.policies=O.state.toolPolicies}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.()}setPolicy(e,t){O.setToolPolicy(e,t)}setAll(e){O.setAllToolPolicies(e)}get allPolicy(){let e=Object.values(this.policies);if(e.length===0)return null;let t=e[0];return e.every(e=>e===t)?t:null}render(){if(!this.tools.length)return a`<div class="empty">No tools available</div>`;let e=this.allPolicy;return a`
      <div class="bulk-actions">
        ${ln.map(t=>a`
            <button
              class="bulk-btn ${e===t.value?`active`:``}"
              @click=${()=>this.setAll(t.value)}
            >
              All ${t.label}
            </button>
          `)}
      </div>
      <div class="tool-list">
        ${this.tools.map(e=>{let t=this.policies[e.name]??fe(e.name);return a`
            <div class="tool-row">
              <div class="tool-name-wrap">
                <div class="tool-name">${e.name}</div>
                ${e.description?a`<div class="tool-tip">${e.description}</div>`:r}
              </div>
              <div class="policy-toggle">
                ${ln.map(n=>a`
                    <button
                      class="policy-btn ${t===n.value?`selected-${n.value}`:``}"
                      @click=${()=>this.setPolicy(e.name,n.value)}
                      title=${n.label}
                    >
                      ${n.label}
                    </button>
                  `)}
              </div>
            </div>
          `})}
      </div>
    `}},cn.styles=d`
    :host {
      display: block;
    }

    .bulk-actions {
      display: flex;
      gap: 6px;
      margin-bottom: 8px;
    }

    .bulk-btn {
      padding: 3px 10px;
      border-radius: var(--radius-full);
      font-size: var(--font-size-xs);
      font-weight: var(--font-weight-medium);
      border: 1px solid var(--border-primary);
      background: var(--bg-primary);
      color: var(--text-secondary);
      cursor: pointer;
      transition: all var(--transition-fast);
    }

    .bulk-btn:hover {
      background: var(--bg-hover);
      color: var(--text-primary);
    }

    .bulk-btn.active {
      background: var(--accent-primary);
      color: var(--text-inverse);
      border-color: var(--accent-primary);
    }

    .tool-list {
      display: flex;
      flex-direction: column;
      gap: 4px;
    }

    .tool-row {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 4px 0;
    }

    .tool-name-wrap {
      flex: 1;
      min-width: 0;
      position: relative;
    }

    .tool-name {
      font-size: var(--font-size-xs);
      color: var(--text-primary);
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      cursor: default;
    }

    .tool-tip {
      display: none;
      position: absolute;
      bottom: calc(100% + 6px);
      left: 0;
      z-index: 100;
      max-width: 280px;
      padding: 6px 10px;
      border-radius: var(--radius-sm);
      background: var(--bg-tertiary);
      border: 1px solid var(--border-primary);
      color: var(--text-secondary);
      font-size: var(--font-size-xs);
      line-height: 1.4;
      white-space: normal;
      word-wrap: break-word;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      pointer-events: none;
    }

    .tool-name-wrap:hover .tool-tip {
      display: block;
    }

    .policy-toggle {
      display: flex;
      border-radius: var(--radius-full);
      border: 1px solid var(--border-primary);
      overflow: hidden;
      flex-shrink: 0;
    }

    .policy-btn {
      padding: 2px 8px;
      font-size: 10px;
      font-weight: var(--font-weight-medium);
      border: none;
      background: var(--bg-primary);
      color: var(--text-tertiary);
      cursor: pointer;
      transition: all var(--transition-fast);
      line-height: 1.4;
    }

    .policy-btn:not(:last-child) {
      border-right: 1px solid var(--border-primary);
    }

    .policy-btn:hover {
      background: var(--bg-hover);
      color: var(--text-primary);
    }

    .policy-btn.selected-auto-accept {
      background: var(--accent-success);
      color: white;
    }

    .policy-btn.selected-ask {
      background: var(--accent-info);
      color: white;
    }

    .policy-btn.selected-auto-reject {
      background: var(--accent-danger);
      color: white;
    }

    .empty {
      font-size: var(--font-size-sm);
      color: var(--text-tertiary);
      padding: 4px 0;
    }
  `,cn);N([i()],un.prototype,`tools`,void 0),N([i()],un.prototype,`policies`,void 0),un=N([s(`tool-policy-editor`)],un);var dn,fn=(dn=class extends l{render(){return a`
      <div class="dots">
        <div class="dot"></div>
        <div class="dot"></div>
        <div class="dot"></div>
      </div>
      <span class="label">Thinking...</span>
    `}},dn.styles=d`
    :host {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      padding: 12px 0;
    }

    .dots {
      display: flex;
      gap: 4px;
    }

    .dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: var(--accent-primary);
      opacity: 0.3;
      animation: pulse 1.4s ease-in-out infinite;
    }

    .dot:nth-child(2) {
      animation-delay: 0.2s;
    }

    .dot:nth-child(3) {
      animation-delay: 0.4s;
    }

    @keyframes pulse {
      0%,
      80%,
      100% {
        opacity: 0.3;
        transform: scale(0.8);
      }
      40% {
        opacity: 1;
        transform: scale(1);
      }
    }

    .label {
      font-size: var(--font-size-sm);
      color: var(--text-tertiary);
    }
  `,dn);fn=N([s(`thinking-indicator`)],fn);var pn;T.registerLanguage(`bash`,b),T.registerLanguage(`sh`,b),T.registerLanguage(`shell`,b),T.registerLanguage(`javascript`,y),T.registerLanguage(`js`,y),T.registerLanguage(`typescript`,te),T.registerLanguage(`ts`,te),T.registerLanguage(`python`,S),T.registerLanguage(`py`,S),T.registerLanguage(`json`,v),T.registerLanguage(`yaml`,D),T.registerLanguage(`yml`,D),T.registerLanguage(`xml`,w),T.registerLanguage(`html`,w),T.registerLanguage(`css`,_),T.registerLanguage(`sql`,x),T.registerLanguage(`markdown`,E),T.registerLanguage(`md`,E),T.registerLanguage(`go`,C),T.registerLanguage(`rust`,ee);var mn=new h(m({langPrefix:`hljs language-`,highlight(e,t){if(t&&T.getLanguage(t))try{return T.highlight(e,{language:t}).value}catch{}return T.highlightAuto(e).value}}));mn.setOptions({breaks:!0,gfm:!0});var hn=(pn=class extends l{constructor(...e){super(...e),this.content=``,this._cacheKey=``,this._cacheHtml=``}renderMarkdown(){if(!this.content)return``;if(this._cacheKey===this.content)return this._cacheHtml;this._cacheKey=this.content;let e=mn.parse(this.content);return this._cacheHtml=g.sanitize(e),this._cacheHtml}render(){return a`<div class="md">${u(this.renderMarkdown())}</div>`}},pn.styles=d`
    :host {
      display: block;
      line-height: var(--line-height);
      color: var(--text-primary);
      word-wrap: break-word;
      overflow-wrap: break-word;
    }

    .md h1,
    .md h2,
    .md h3,
    .md h4 {
      margin-top: 1.2em;
      margin-bottom: 0.4em;
      font-weight: var(--font-weight-bold);
      line-height: 1.3;
    }

    .md h1 {
      font-size: var(--md-h1-size, 1.5em);
    }
    .md h2 {
      font-size: var(--md-h2-size, 1.3em);
    }
    .md h3 {
      font-size: var(--md-h3-size, 1.15em);
    }
    .md h4 {
      font-size: var(--md-h4-size, 1em);
    }

    .md h1:first-child,
    .md h2:first-child,
    .md h3:first-child {
      margin-top: 0;
    }

    .md p {
      margin: 0.6em 0;
    }

    .md p:first-child {
      margin-top: 0;
    }

    .md p:last-child {
      margin-bottom: 0;
    }

    .md ul,
    .md ol {
      margin: 0.6em 0;
      padding-left: 1.5em;
    }

    .md li {
      margin: 0.2em 0;
    }

    .md code {
      font-family: var(--font-mono);
      font-size: 0.9em;
      padding: 0.15em 0.4em;
      border-radius: var(--radius-xs);
      background: var(--bg-code);
      color: var(--text-code);
    }

    .md pre {
      margin: 0.8em 0;
      padding: 14px 16px;
      border-radius: var(--radius-sm);
      background: var(--bg-code);
      overflow-x: auto;
      font-size: 0.88em;
      line-height: 1.5;
    }

    .md pre code {
      padding: 0;
      background: none;
      color: var(--text-primary);
      font-size: inherit;
    }

    .md blockquote {
      margin: 0.8em 0;
      padding: 0.4em 1em;
      border-left: 3px solid var(--accent-primary);
      color: var(--text-secondary);
      background: var(--bg-tertiary);
      border-radius: 0 var(--radius-xs) var(--radius-xs) 0;
    }

    .md table {
      width: 100%;
      border-collapse: collapse;
      margin: 0.8em 0;
      font-size: var(--font-size-sm);
    }

    .md th,
    .md td {
      padding: 8px 12px;
      text-align: left;
      border-bottom: 1px solid var(--border-secondary);
    }

    .md th {
      font-weight: var(--font-weight-bold);
      color: var(--text-secondary);
      border-bottom-color: var(--border-primary);
    }

    .md a {
      color: var(--accent-info);
      text-decoration: none;
    }

    .md a:hover {
      text-decoration: underline;
    }

    .md hr {
      margin: 1.2em 0;
      border: none;
      border-top: 1px solid var(--border-secondary);
    }

    .md img {
      max-width: 100%;
      border-radius: var(--radius-sm);
    }

    /* highlight.js theme integration */
    .md .hljs-keyword,
    .md .hljs-selector-tag,
    .md .hljs-built_in,
    .md .hljs-name,
    .md .hljs-tag {
      color: var(--accent-primary);
    }
    .md .hljs-string,
    .md .hljs-title,
    .md .hljs-section,
    .md .hljs-attribute,
    .md .hljs-literal,
    .md .hljs-template-tag,
    .md .hljs-template-variable,
    .md .hljs-type,
    .md .hljs-addition {
      color: var(--accent-success);
    }
    .md .hljs-comment,
    .md .hljs-quote,
    .md .hljs-deletion,
    .md .hljs-meta {
      color: var(--text-tertiary);
    }
    .md .hljs-number,
    .md .hljs-regexp,
    .md .hljs-literal,
    .md .hljs-bullet,
    .md .hljs-link {
      color: var(--accent-info);
    }
    .md .hljs-emphasis {
      font-style: italic;
    }
    .md .hljs-strong {
      font-weight: var(--font-weight-bold);
    }
  `,pn);N([n({type:String})],hn.prototype,`content`,void 0),hn=N([s(`markdown-renderer`)],hn);var gn=d`
  :host {
    display: block;
  }

  .chips {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
  }

  .chip {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 4px 10px;
    border-radius: var(--radius-full);
    font-size: var(--font-size-xs);
    border: 1px solid var(--border-primary);
    background: var(--bg-primary);
    color: var(--text-secondary);
    cursor: pointer;
    transition: all var(--transition-fast);
    white-space: nowrap;
  }

  .chip:hover {
    background: var(--bg-hover);
    color: var(--text-primary);
  }

  .chip.active {
    background: var(--accent-primary);
    color: var(--text-inverse);
    border-color: var(--accent-primary);
  }

  .chip.active:hover {
    background: var(--accent-hover);
  }

  .chip:disabled {
    opacity: 0.5;
    cursor: wait;
  }

  .chip .dot {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: currentColor;
    opacity: 0.6;
  }

  .empty {
    font-size: var(--font-size-sm);
    color: var(--text-tertiary);
    padding: 4px 0;
  }
`,_n,vn=(_n=class extends l{constructor(...e){super(...e),this.available=[],this.active=[]}connectedCallback(){super.connectedCallback(),this.unsubscribe=O.subscribe(()=>{this.available=O.state.availableSkills,this.active=O.state.activeSkills}),this.available=O.state.availableSkills,this.active=O.state.activeSkills}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.()}toggle(e){O.toggleSkill(e)}render(){return this.available.length?a`
      <div class="chips">
        ${this.available.map(e=>{let t=this.active.includes(e.name);return a`
            <button
              class="chip ${t?`active`:``}"
              @click=${()=>this.toggle(e.name)}
              title=${e.description}
            >
              ${t?a`<span class="dot"></span>`:``} ${e.name}
            </button>
          `})}
      </div>
    `:a`<div class="empty">No skills loaded</div>`}},_n.styles=gn,_n);N([i()],vn.prototype,`available`,void 0),N([i()],vn.prototype,`active`,void 0),vn=N([s(`skill-selector`)],vn);var yn,bn=(yn=class extends l{constructor(...e){super(...e),this.context={},this.newKey=``,this.newValue=``}connectedCallback(){super.connectedCallback(),this.unsubscribe=O.subscribe(()=>{this.context=O.state.context}),this.context=O.state.context}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.()}removeKey(e){O.removeContext(e)}add(){let e=this.newKey.trim(),t=this.newValue.trim();!e||!t||(O.setContext(e,t),this.newKey=``,this.newValue=``)}onKeyDown(e){e.key===`Enter`&&this.add()}render(){let e=Object.entries(this.context);return a`
      ${e.length?a`
            <div class="entries">
              ${e.map(([e,t])=>a`
                  <div class="entry">
                    <span class="entry-key">${e}</span>
                    <span class="entry-value">${t}</span>
                    <button
                      class="remove-btn"
                      @click=${()=>this.removeKey(e)}
                      title="Remove ${e}"
                    >
                      <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                      >
                        <line x1="18" y1="6" x2="6" y2="18" />
                        <line x1="6" y1="6" x2="18" y2="18" />
                      </svg>
                    </button>
                  </div>
                `)}
            </div>
          `:a`<div class="empty">No context set</div>`}

      <div class="add-row">
        <input
          type="text"
          placeholder="key"
          .value=${this.newKey}
          @input=${e=>this.newKey=e.target.value}
          @keydown=${this.onKeyDown}
        />
        <input
          type="text"
          placeholder="value"
          .value=${this.newValue}
          @input=${e=>this.newValue=e.target.value}
          @keydown=${this.onKeyDown}
        />
        <button class="add-btn" @click=${this.add}>Add</button>
      </div>
    `}},yn.styles=d`
    :host {
      display: block;
    }

    .entries {
      display: flex;
      flex-direction: column;
      gap: 4px;
      margin-bottom: 8px;
    }

    .entry {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: var(--font-size-sm);
      padding: 4px 8px;
      border-radius: var(--radius-xs);
      background: var(--bg-tertiary);
    }

    .entry-key {
      font-weight: var(--font-weight-medium);
      color: var(--text-primary);
    }

    .entry-value {
      color: var(--text-secondary);
      flex: 1;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .remove-btn {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 20px;
      height: 20px;
      border: none;
      background: none;
      border-radius: var(--radius-xs);
      color: var(--text-tertiary);
      cursor: pointer;
      flex-shrink: 0;
      transition:
        color var(--transition-fast),
        background var(--transition-fast);
    }

    .remove-btn:hover {
      color: var(--accent-danger);
      background: var(--bg-hover);
    }

    .remove-btn svg {
      width: 12px;
      height: 12px;
    }

    .add-row {
      display: flex;
      gap: 6px;
    }

    .add-row input {
      flex: 1;
      padding: 6px 8px;
      border: 1px solid var(--border-primary);
      border-radius: var(--radius-xs);
      background: var(--bg-input);
      font-size: var(--font-size-sm);
      min-width: 0;
    }

    .add-row input::placeholder {
      color: var(--text-tertiary);
    }

    .add-btn {
      padding: 6px 10px;
      border: none;
      border-radius: var(--radius-xs);
      background: var(--bg-tertiary);
      color: var(--text-secondary);
      font-size: var(--font-size-sm);
      cursor: pointer;
      white-space: nowrap;
      transition:
        background var(--transition-fast),
        color var(--transition-fast);
    }

    .add-btn:hover {
      background: var(--bg-hover);
      color: var(--text-primary);
    }

    .empty {
      font-size: var(--font-size-sm);
      color: var(--text-tertiary);
      padding: 4px 0;
    }
  `,yn);N([i()],bn.prototype,`context`,void 0),N([i()],bn.prototype,`newKey`,void 0),N([i()],bn.prototype,`newValue`,void 0),bn=N([s(`context-editor`)],bn);var xn,Sn=(xn=class extends l{constructor(...e){super(...e),this.models=[],this.current=``}connectedCallback(){super.connectedCallback(),this.unsubscribe=O.subscribe(()=>{this.models=O.state.availableModels,this.current=O.state.model}),this.models=O.state.availableModels,this.current=O.state.model}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.()}async onChange(e){let t=e.target.value;if(!(!t||t===this.current))try{let e=await j(t);O.update({model:e.model,contextWindow:e.context_window})}catch(e){O.update({error:e.message})}}render(){return this.models.length?a`
      <select .value=${this.current} @change=${this.onChange}>
        ${this.models.map(e=>a`<option value=${e} ?selected=${e===this.current}>${e}</option>`)}
      </select>
    `:a`<div class="empty">No models available</div>`}},xn.styles=d`
    :host {
      display: block;
    }

    select {
      width: 100%;
      padding: 8px 10px;
      border: 1px solid var(--border-primary);
      border-radius: var(--radius-sm);
      background: var(--bg-input);
      color: var(--text-primary);
      font-size: var(--font-size-sm);
      cursor: pointer;
      appearance: auto;
    }

    select:focus {
      outline: 2px solid var(--accent-primary);
      outline-offset: -1px;
    }

    .empty {
      font-size: var(--font-size-sm);
      color: var(--text-tertiary);
      padding: 4px 0;
    }
  `,xn);N([i()],Sn.prototype,`models`,void 0),N([i()],Sn.prototype,`current`,void 0),Sn=N([s(`model-selector`)],Sn);var Cn,wn=(Cn=class extends l{constructor(...e){super(...e),this.servers=[],this.busy=!1}connectedCallback(){super.connectedCallback(),this.unsubscribe=O.subscribe(()=>{this.servers=O.state.mcpServers}),this.servers=O.state.mcpServers}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.()}async toggle(e){if(!this.busy){this.busy=!0;try{let t=e.connected?await be(e.name):await ye(e.name);O.update({mcpServers:t.servers,toolCount:t.tools});let n=[...await he(),...de],r=O.state.toolPolicies,i={};for(let e of n)i[e.name]=r[e.name]??fe(e.name);O.update({availableTools:n,toolPolicies:i})}catch(e){O.update({error:e.message})}finally{this.busy=!1}}}render(){return this.servers.length?a`
      <div class="chips">
        ${this.servers.map(e=>a`
            <button
              class="chip ${e.connected?`active`:``}"
              ?disabled=${this.busy}
              @click=${()=>this.toggle(e)}
              title=${e.url}
            >
              ${e.connected?a`<span class="dot"></span>`:``} ${e.name}
            </button>
          `)}
      </div>
    `:a`<div class="empty">No MCP servers configured</div>`}},Cn.styles=gn,Cn);N([i()],wn.prototype,`servers`,void 0),N([i()],wn.prototype,`busy`,void 0),wn=N([s(`mcp-manager`)],wn);var Tn,En=(Tn=class extends l{constructor(...e){super(...e),this.open=!1,this.currentTheme=ue.name,this.outsideClickHandler=e=>{this.open&&(e.composedPath().includes(this)||(this.open=!1))},this.swatchColors={light:[`#FAF9F5`,`#AE5630`],dark:[`#1A1918`,`#D4703C`],"rh-light":[`#ffffff`,`#a60000`],"rh-dark":[`#151515`,`#f56e6e`]}}connectedCallback(){super.connectedCallback(),document.addEventListener(`click`,this.outsideClickHandler,!0)}disconnectedCallback(){super.disconnectedCallback(),document.removeEventListener(`click`,this.outsideClickHandler,!0)}toggleDropdown(){this.open=!this.open}selectTheme(e){ue.setTheme(e),this.currentTheme=ue.name,this.open=!1,this.dispatchEvent(new CustomEvent(`theme-changed`,{detail:{theme:ue.name},bubbles:!0,composed:!0}))}render(){let e=ue.isDark,t=ue.themes;return a`
      <button
        class="trigger"
        @click=${this.toggleDropdown}
        title="Change theme"
        aria-label="Change theme"
        aria-expanded=${this.open}
      >
        ${e?a`<svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
            >
              <circle cx="12" cy="12" r="5" />
              <line x1="12" y1="1" x2="12" y2="3" />
              <line x1="12" y1="21" x2="12" y2="23" />
              <line x1="4.22" y1="4.22" x2="5.64" y2="5.64" />
              <line x1="18.36" y1="18.36" x2="19.78" y2="19.78" />
              <line x1="1" y1="12" x2="3" y2="12" />
              <line x1="21" y1="12" x2="23" y2="12" />
              <line x1="4.22" y1="19.78" x2="5.64" y2="18.36" />
              <line x1="18.36" y1="5.64" x2="19.78" y2="4.22" />
            </svg>`:a`<svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
            >
              <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
            </svg>`}
      </button>

      <div class="dropdown ${this.open?`open`:``}">
        ${t.map(e=>a`
            <button
              class=${e.id===this.currentTheme?`active`:``}
              @click=${()=>this.selectTheme(e.id)}
            >
              <span
                class="swatch"
                style="background: linear-gradient(135deg, ${this.swatchColors[e.id]?.[0]??`#888`} 50%, ${this.swatchColors[e.id]?.[1]??`#444`} 50%)"
              ></span>
              ${e.label}
              <span class="check">&#10003;</span>
            </button>
          `)}
      </div>
    `}},Tn.styles=d`
    :host {
      display: inline-flex;
      position: relative;
    }

    button.trigger {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 36px;
      height: 36px;
      border-radius: var(--radius-sm);
      background: transparent;
      color: var(--text-secondary);
      border: none;
      cursor: pointer;
      transition:
        background var(--transition-fast),
        color var(--transition-fast);
    }

    button.trigger:hover {
      background: var(--bg-hover);
      color: var(--text-primary);
    }

    svg {
      width: 18px;
      height: 18px;
    }

    .dropdown {
      position: absolute;
      top: 100%;
      right: 0;
      margin-top: 4px;
      min-width: 160px;
      background: var(--bg-input);
      border: 1px solid var(--border-primary);
      border-radius: var(--radius-sm);
      box-shadow: var(--shadow-md);
      z-index: 200;
      padding: 4px;
      opacity: 0;
      transform: translateY(-4px);
      pointer-events: none;
      transition:
        opacity var(--transition-fast),
        transform var(--transition-fast);
    }

    .dropdown.open {
      opacity: 1;
      transform: translateY(0);
      pointer-events: auto;
    }

    .dropdown button {
      display: flex;
      align-items: center;
      gap: 8px;
      width: 100%;
      padding: 8px 10px;
      border: none;
      border-radius: var(--radius-xs);
      background: transparent;
      color: var(--text-primary);
      font-size: var(--font-size-sm);
      font-family: var(--font-sans);
      cursor: pointer;
      transition: background var(--transition-fast);
    }

    .dropdown button:hover {
      background: var(--bg-hover);
    }

    .dropdown button.active {
      background: var(--bg-tertiary);
      font-weight: var(--font-weight-medium);
    }

    .swatch {
      width: 14px;
      height: 14px;
      border-radius: var(--radius-xs);
      border: 1px solid var(--border-primary);
      flex-shrink: 0;
    }

    .check {
      margin-left: auto;
      font-size: 13px;
      opacity: 0;
    }

    .active .check {
      opacity: 1;
    }
  `,Tn);N([i()],En.prototype,`open`,void 0),N([i()],En.prototype,`currentTheme`,void 0),En=N([s(`theme-picker`)],En);var Dn;function On(){let e=O.state.context;return e.namespace?{namespace:e.namespace}:{all_namespaces:!0}}function kn(){return O.state.context.namespace||void 0}function An(e,t){return[{label:`Network RX/TX`,kind:`query-graph`,buildQueries:()=>{let e=kn(),t=e?`pod`:`namespace`,n=e?`{namespace="${e}"}`:``;return{queries:[`topk(10, sum by (${t})(rate(container_network_receive_bytes_total${n}[5m])))`,`topk(10, sum by (${t})(rate(container_network_transmit_bytes_total${n}[5m])))`],names:[`rx`,`tx`]}},start:e,step:t},{label:`CPU / Memory`,kind:`query-graph`,buildQueries:()=>{let e=kn(),t=e?`pod`:`namespace`,n=e?`{namespace="${e}"}`:``;return{queries:[`topk(10, sum by (${t})(rate(container_cpu_usage_seconds_total${n}[5m])))`,`topk(10, sum by (${t})(container_memory_working_set_bytes${n}))`],names:[`cpu`,`memory`]}},start:e,step:t},{label:`Network Total`,kind:`query-graph`,buildQueries:()=>{let e=kn(),t=e??`all`,n=e?`{namespace="${e}"}`:``;return{queries:[`sum(rate(container_network_receive_bytes_total${n}[5m]))`,`sum(rate(container_network_transmit_bytes_total${n}[5m]))`],names:[`total rx (${t})`,`total tx (${t})`]}},start:e,step:t},{label:`CPU / Mem Total`,kind:`query-graph`,buildQueries:()=>{let e=kn(),t=e??`all`,n=e?`{namespace="${e}"}`:``;return{queries:[`sum(rate(container_cpu_usage_seconds_total${n}[5m]))`,`sum(container_memory_working_set_bytes${n})`],names:[`total cpu (${t})`,`total mem (${t})`]}},start:e,step:t}]}var jn=[{heading:`Resources`,items:[{label:`Health`,kind:`table`,toolName:`mtv_read`,buildArgs:()=>({command:`health`})},{label:`Providers`,kind:`table`,toolName:`mtv_read`,buildArgs:()=>({command:`get provider`,flags:{...On(),output:`markdown`}})},{label:`Plans`,kind:`table`,toolName:`mtv_read`,buildArgs:()=>({command:`get plan`,flags:{...On(),output:`markdown`}})},{label:`Plans (VMs)`,kind:`table`,toolName:`mtv_read`,buildArgs:()=>({command:`get plan`,flags:{...On(),"vms-table":!0,output:`markdown`}})}]},{heading:`Metrics (2 h)`,items:[...An(`-2h`,`60s`)]},{heading:`Metrics (24 h)`,items:[...An(`-24h`,`300s`)]}],Mn=(Dn=class extends l{constructor(...e){super(...e),this.open=!1,this.outsideClickHandler=e=>{this.open&&(e.composedPath().includes(this)||(this.open=!1))},this.tableIcon=a`<svg
    class="icon"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    stroke-width="2"
    stroke-linecap="round"
    stroke-linejoin="round"
  >
    <rect x="3" y="3" width="18" height="18" rx="2" />
    <line x1="3" y1="9" x2="21" y2="9" />
    <line x1="3" y1="15" x2="21" y2="15" />
    <line x1="9" y1="3" x2="9" y2="21" />
  </svg>`,this.chartIcon=a`<svg
    class="icon"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    stroke-width="2"
    stroke-linecap="round"
    stroke-linejoin="round"
  >
    <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
  </svg>`}connectedCallback(){super.connectedCallback(),document.addEventListener(`click`,this.outsideClickHandler,!0)}disconnectedCallback(){super.disconnectedCallback(),document.removeEventListener(`click`,this.outsideClickHandler,!0)}toggleDropdown(){this.open=!this.open}async openPanel(e){this.open=!1,e.kind===`table`?await this.openTablePanel(e):await this.openQueryGraphPanel(e)}async openTablePanel(e){let t=e.buildArgs(),n=rn(e.toolName,t);if(O.hasCard(n))return;let r={id:n,title:`${e.toolName}: ${e.label}`,content:``,timestamp:Date.now(),toolName:e.toolName,toolArgs:t,loading:!0};O.addCard(r),O.state.detailPaneOpen||O.update({detailPaneOpen:!0});try{let r=await we(e.toolName,t),i=Zt(Yt(e.toolName,t),r.result);O.updateCard(n,{content:i.content,type:i.displayType,loading:!1})}catch(e){O.updateCard(n,{content:`**Error:** ${e.message}`,loading:!1})}}async openQueryGraphPanel(e){let{queries:t,names:n}=e.buildQueries(),r=kn(),i={command:`query_range`,flags:{query:t,name:n,start:e.start,step:e.step,output:`tsv`}},a=`graph-${rn(`metrics_read`,i)}`;if(O.hasCard(a))return;let o=e.start.replace(`-`,``),s={id:a,title:r?`${e.label} [${r}] (${o})`:`${e.label} (${o})`,content:``,timestamp:Date.now(),toolName:`metrics_read`,toolArgs:i,type:`graph`,loading:!0};O.addCard(s),O.state.detailPaneOpen||O.update({detailPaneOpen:!0});try{let e=await we(`metrics_read`,i);O.updateCard(a,{content:e.result,loading:!1})}catch(e){O.updateCard(a,{content:`**Error:** ${e.message}`,loading:!1})}}render(){return a`
      <button
        class="trigger"
        @click=${this.toggleDropdown}
        title="Quick panels"
        aria-label="Quick panels"
        aria-expanded=${this.open}
      >
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        >
          <rect x="3" y="3" width="7" height="7" rx="1" />
          <rect x="14" y="3" width="7" height="7" rx="1" />
          <rect x="3" y="14" width="7" height="7" rx="1" />
          <rect x="14" y="14" width="7" height="7" rx="1" />
        </svg>
      </button>

      <div class="dropdown ${this.open?`open`:``}">
        ${jn.map((e,t)=>a`
            ${t>0?a`<div class="separator"></div>`:``}
            <div class="section-label">${e.heading}</div>
            ${e.items.map(e=>a`
                <button @click=${()=>this.openPanel(e)}>
                  ${e.kind===`table`?this.tableIcon:this.chartIcon} ${e.label}
                </button>
              `)}
          `)}
      </div>
    `}},Dn.styles=d`
    :host {
      display: inline-flex;
      position: relative;
    }

    button.trigger {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 36px;
      height: 36px;
      border-radius: var(--radius-sm);
      background: transparent;
      color: var(--text-secondary);
      border: none;
      cursor: pointer;
      transition:
        background var(--transition-fast),
        color var(--transition-fast);
    }

    button.trigger:hover {
      background: var(--bg-hover);
      color: var(--text-primary);
    }

    svg {
      width: 18px;
      height: 18px;
    }

    .dropdown {
      position: absolute;
      top: 100%;
      right: 0;
      margin-top: 4px;
      min-width: 200px;
      background: var(--bg-input);
      border: 1px solid var(--border-primary);
      border-radius: var(--radius-sm);
      box-shadow: var(--shadow-md);
      z-index: 200;
      padding: 4px;
      opacity: 0;
      transform: translateY(-4px);
      pointer-events: none;
      transition:
        opacity var(--transition-fast),
        transform var(--transition-fast);
    }

    .dropdown.open {
      opacity: 1;
      transform: translateY(0);
      pointer-events: auto;
    }

    .section-label {
      padding: 6px 10px 2px;
      font-size: var(--font-size-xs);
      font-weight: var(--font-weight-bold);
      color: var(--text-tertiary);
      text-transform: uppercase;
      letter-spacing: 0.04em;
      user-select: none;
    }

    .dropdown button {
      display: flex;
      align-items: center;
      gap: 8px;
      width: 100%;
      padding: 8px 10px;
      border: none;
      border-radius: var(--radius-xs);
      background: transparent;
      color: var(--text-primary);
      font-size: var(--font-size-sm);
      font-family: var(--font-sans);
      cursor: pointer;
      transition: background var(--transition-fast);
    }

    .dropdown button:hover {
      background: var(--bg-hover);
    }

    .dropdown button .icon {
      width: 14px;
      height: 14px;
      flex-shrink: 0;
      color: var(--text-tertiary);
    }

    .separator {
      height: 1px;
      margin: 4px 0;
      background: var(--border-secondary);
    }
  `,Dn);N([i()],Mn.prototype,`open`,void 0),Mn=N([s(`quick-panels`)],Mn);async function Nn(){let e=await we(`debug_read`,{command:`list`,flags:{resource:`namespaces`,all_namespaces:!0,output:`json`,query:`select name`}}),t;try{t=JSON.parse(e.result)}catch(t){throw Error(`Failed to parse namespace list: ${t instanceof Error?t.message:e.result}`,{cause:t})}if(!Array.isArray(t))throw Error(`Expected array of namespaces, got: ${typeof t}`);return t.map(e=>{if(typeof e==`string`)return e.trim()||``;if(e&&typeof e==`object`&&`name`in e){let t=e.name;return typeof t==`string`&&t.trim()!==``?t.trim():``}return``}).filter(Boolean).sort((e,t)=>e.localeCompare(t))}var Pn=d`
  :host {
    display: inline-flex;
    position: relative;
  }

  /* ── trigger button ── */

  button.trigger {
    display: flex;
    align-items: center;
    gap: 6px;
    height: 36px;
    padding: 0 10px;
    border-radius: var(--radius-sm);
    background: transparent;
    color: var(--text-secondary);
    border: none;
    cursor: pointer;
    font-size: var(--font-size-sm);
    font-family: var(--font-sans);
    white-space: nowrap;
    transition:
      background var(--transition-fast),
      color var(--transition-fast);
  }

  button.trigger:hover {
    background: var(--bg-hover);
    color: var(--text-primary);
  }

  button.trigger svg {
    width: 16px;
    height: 16px;
    flex-shrink: 0;
  }

  .trigger-label {
    max-width: 140px;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .caret {
    width: 10px;
    height: 10px;
    flex-shrink: 0;
    transition: transform var(--transition-fast);
  }

  .caret.open {
    transform: rotate(180deg);
  }

  /* ── dropdown panel ── */

  .dropdown {
    position: absolute;
    top: 100%;
    left: 0;
    margin-top: 4px;
    width: 240px;
    background: var(--bg-input);
    border: 1px solid var(--border-primary);
    border-radius: var(--radius-sm);
    box-shadow: var(--shadow-md);
    z-index: 200;
    padding: 6px;
    opacity: 0;
    transform: translateY(-4px);
    pointer-events: none;
    transition:
      opacity var(--transition-fast),
      transform var(--transition-fast);
  }

  .dropdown.open {
    opacity: 1;
    transform: translateY(0);
    pointer-events: auto;
  }

  /* ── search input ── */

  .search-input {
    width: 100%;
    box-sizing: border-box;
    padding: 6px 8px;
    margin-bottom: 4px;
    border: 1px solid var(--border-primary);
    border-radius: var(--radius-xs);
    background: var(--bg-primary);
    color: var(--text-primary);
    font-size: var(--font-size-sm);
    font-family: var(--font-sans);
    outline: none;
  }

  .search-input::placeholder {
    color: var(--text-tertiary);
  }

  .search-input:focus {
    border-color: var(--accent-primary);
  }

  /* ── namespace list ── */

  .ns-list {
    max-height: 260px;
    overflow-y: auto;
    display: flex;
    flex-direction: column;
    gap: 1px;
  }

  .ns-item {
    display: flex;
    align-items: center;
    gap: 8px;
    width: 100%;
    padding: 6px 8px;
    border: none;
    border-radius: var(--radius-xs);
    background: transparent;
    color: var(--text-primary);
    font-size: var(--font-size-sm);
    font-family: var(--font-sans);
    cursor: pointer;
    text-align: left;
    transition: background var(--transition-fast);
  }

  .ns-item:hover {
    background: var(--bg-hover);
  }

  .ns-item.active {
    background: var(--bg-tertiary);
    font-weight: var(--font-weight-medium);
  }

  .ns-item .check {
    margin-left: auto;
    font-size: 13px;
    opacity: 0;
  }

  .ns-item.active .check {
    opacity: 1;
  }

  /* ── status messages ── */

  .status {
    padding: 8px;
    font-size: var(--font-size-sm);
    color: var(--text-tertiary);
    text-align: center;
  }
`,Fn,In=`All Namespaces`,Ln=(Fn=class extends l{constructor(...e){super(...e),this.open=!1,this.namespaces=[],this.loading=!1,this.search=``,this.selected=``,this.fetchError=!1,this.errorMessage=``,this.fetched=!1,this.onOutsideClick=e=>{this.open&&!e.composedPath().includes(this)&&(this.open=!1,this.search=``)}}connectedCallback(){super.connectedCallback(),this.syncFromContext(),this.unsubscribe=O.subscribe(()=>this.syncFromContext()),document.addEventListener(`click`,this.onOutsideClick,!0)}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.(),document.removeEventListener(`click`,this.onOutsideClick,!0)}syncFromContext(){let e=O.state.context;e[`all-namespaces`]?this.selected=``:e.namespace?this.selected=e.namespace:this.selected=``}async toggleDropdown(){this.open=!this.open,this.open&&(this.search=``,this.fetched||await this.loadNamespaces())}async loadNamespaces(){this.loading=!0,this.fetchError=!1,this.errorMessage=``;try{this.namespaces=await Nn(),this.fetched=!0}catch(e){console.error(`Failed to load namespaces:`,e),this.fetchError=!0,this.errorMessage=e instanceof Error?e.message:String(e)}finally{this.loading=!1}}selectNamespace(e){this.selected=e,this.open=!1,this.search=``,e===``?(O.setContext(`all-namespaces`,`true`),O.removeContext(`namespace`)):(O.setContext(`namespace`,e),O.removeContext(`all-namespaces`))}onSearchInput(e){this.search=e.target.value}get filtered(){let e=this.search.toLowerCase();return e?this.namespaces.filter(t=>t.toLowerCase().includes(e)):this.namespaces}render(){let e=this.selected||In;return a`
      <button
        class="trigger"
        @click=${this.toggleDropdown}
        title="Select namespace"
        aria-label="Select namespace"
        aria-expanded=${this.open}
      >
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        >
          <rect x="2" y="2" width="20" height="20" rx="2" />
          <line x1="2" y1="12" x2="22" y2="12" />
          <line x1="12" y1="2" x2="12" y2="22" />
        </svg>
        <span class="trigger-label">${e}</span>
        <svg
          class="caret ${this.open?`open`:``}"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        >
          <polyline points="6 9 12 15 18 9" />
        </svg>
      </button>

      <div class="dropdown ${this.open?`open`:``}">
        ${this.open?a`
              <input
                class="search-input"
                type="text"
                placeholder="Search namespaces…"
                .value=${this.search}
                @input=${this.onSearchInput}
              />
              ${this.renderList()}
            `:``}
      </div>
    `}renderList(){if(this.loading)return a`<div class="status">Loading…</div>`;if(this.fetchError)return a`<div class="status">
        Failed to load namespaces${this.errorMessage?`: ${this.errorMessage}`:``}
      </div>`;let e=this.filtered;return a`
      <div class="ns-list">
        ${this.search?``:a`
              <button
                class="ns-item ${this.selected===``?`active`:``}"
                @click=${()=>this.selectNamespace(``)}
              >
                ${In}
                <span class="check">&#10003;</span>
              </button>
            `}
        ${e.length?e.map(e=>a`
                <button
                  class="ns-item ${e===this.selected?`active`:``}"
                  @click=${()=>this.selectNamespace(e)}
                >
                  ${e}
                  <span class="check">&#10003;</span>
                </button>
              `):a`<div class="status">No matches</div>`}
      </div>
    `}},Fn.styles=Pn,Fn);N([i()],Ln.prototype,`open`,void 0),N([i()],Ln.prototype,`namespaces`,void 0),N([i()],Ln.prototype,`loading`,void 0),N([i()],Ln.prototype,`search`,void 0),N([i()],Ln.prototype,`selected`,void 0),N([i()],Ln.prototype,`fetchError`,void 0),N([i()],Ln.prototype,`errorMessage`,void 0),Ln=N([s(`namespace-picker`)],Ln);var Rn,zn=(Rn=class extends l{constructor(...e){super(...e),this.sidebarOpen=O.state.sidebarOpen}connectedCallback(){super.connectedCallback(),this.unsubscribe=O.subscribe(()=>{this.sidebarOpen=O.state.sidebarOpen})}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.()}toggleSidebar(){O.update({sidebarOpen:!this.sidebarOpen})}render(){return a`
      <button
        class="toggle-btn"
        @click=${this.toggleSidebar}
        title=${this.sidebarOpen?`Close sidebar`:`Open sidebar`}
        aria-label=${this.sidebarOpen?`Close sidebar`:`Open sidebar`}
      >
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        >
          <line x1="3" y1="6" x2="21" y2="6" />
          <line x1="3" y1="12" x2="21" y2="12" />
          <line x1="3" y1="18" x2="21" y2="18" />
        </svg>
      </button>

      <div class="brand">
        <svg class="hat-icon" viewBox="0 0 136 103" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path
            d="m 90.6538,59.2537 c 8.9312,0 21.8512,-1.8412 21.8512,-12.4662 0.029,-0.82 -0.045,-1.64 -0.22,-2.4413 l -5.3175,-23.1 C 105.7363,16.1575 104.6575,13.8525 95.7363,9.39 88.8075,5.85 73.725,0 69.2625,0 65.1075,0 63.9013,5.3575 58.945,5.3575 c -4.7712,0 -8.3112,-4 -12.7737,-4 -4.2825,0 -7.075,2.92 -9.2338,8.9262 0,0 -6,16.9338 -6.7725,19.39 -0.1262,0.4538 -0.18,0.9175 -0.16,1.3863 0,6.5825 25.9175,28.1687 60.6488,28.1687 m 23.2225,-8.125 c 1.235,5.845 1.235,6.46 1.235,7.2313 0,9.995 -11.235,15.5425 -26.01,15.5425 -33.3838,0.02 -62.6275,-19.5413 -62.6275,-32.4713 0,-1.8012 0.3612,-3.5837 1.075,-5.2337 C 15.5413,36.7725 0,38.9162 0,52.6375 c 0,22.475 53.2513,50.175 95.42,50.175 32.3288,0 40.4825,-14.6188 40.4825,-26.1663 0,-9.0825 -7.8512,-19.39 -22.0112,-25.5425"
            fill="var(--hat-color)"
          />
          <path
            d="m 113.8763,51.1037 c 1.235,5.845 1.235,6.46 1.235,7.2313 0,9.995 -11.235,15.5425 -26.01,15.5425 -33.3838,0.02 -62.6275,-19.5413 -62.6275,-32.4713 0,-1.8012 0.3612,-3.5837 1.075,-5.2337 l 2.6162,-6.47 c -0.1212,0.445 -0.175,0.8987 -0.16,1.3575 0,6.5825 25.9175,28.1687 60.6488,28.1687 8.9312,0 21.8512,-1.845 21.8512,-12.47 0.029,-0.8162 -0.045,-1.6362 -0.22,-2.4412 l 1.5913,6.7862 z"
            fill="rgba(0,0,0,0.2)"
          />
        </svg>
        <span class="title">Forklift</span>
      </div>

      <namespace-picker></namespace-picker>

      <div class="spacer"></div>

      <quick-panels></quick-panels>
      <theme-picker></theme-picker>
    `}},Rn.styles=d`
    :host {
      display: flex;
      align-items: center;
      height: var(--topbar-height);
      min-height: var(--topbar-height);
      padding: 0 12px;
      background: var(--bg-sidebar);
      border-bottom: none;
      gap: 8px;
    }

    .toggle-btn {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 36px;
      height: 36px;
      border-radius: var(--radius-sm);
      background: transparent;
      color: var(--text-secondary);
      border: none;
      cursor: pointer;
      transition:
        background var(--transition-fast),
        color var(--transition-fast);
      flex-shrink: 0;
    }

    .toggle-btn:hover {
      background: var(--bg-hover);
      color: var(--text-primary);
    }

    .toggle-btn svg {
      width: 18px;
      height: 18px;
    }

    .brand {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .hat-icon {
      width: 28px;
      height: 22px;
      flex-shrink: 0;
    }

    .title {
      font-size: var(--font-size-lg);
      font-weight: var(--font-weight-bold);
      color: var(--text-primary);
      white-space: nowrap;
    }

    .spacer {
      flex: 1;
    }
  `,Rn);N([i()],zn.prototype,`sidebarOpen`,void 0),zn=N([s(`top-bar`)],zn);var Bn,Vn=(Bn=class extends l{constructor(...e){super(...e),this.startX=0,this.onMouseDown=e=>{e.preventDefault(),this.startX=e.clientX,this.setAttribute(`active`,``),document.addEventListener(`mousemove`,this.onMouseMove),document.addEventListener(`mouseup`,this.onMouseUp)},this.onMouseMove=e=>{this.emitResize(e.clientX-this.startX)},this.onMouseUp=()=>{this.removeAttribute(`active`),document.removeEventListener(`mousemove`,this.onMouseMove),document.removeEventListener(`mouseup`,this.onMouseUp),this.emitResizeEnd()}}emitResize(e){this.dispatchEvent(new CustomEvent(`handle-resize`,{detail:{delta:e},bubbles:!0,composed:!0}))}emitResizeEnd(){this.dispatchEvent(new CustomEvent(`resize-end`,{bubbles:!0,composed:!0}))}render(){return a`<div class="overlay"></div>`}connectedCallback(){super.connectedCallback(),this.addEventListener(`mousedown`,this.onMouseDown)}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener(`mousedown`,this.onMouseDown),document.removeEventListener(`mousemove`,this.onMouseMove),document.removeEventListener(`mouseup`,this.onMouseUp)}},Bn.styles=d`
    :host {
      display: block;
      width: 4px;
      min-width: 4px;
      cursor: col-resize;
      background: var(--border-secondary);
      transition: background var(--transition-fast);
      position: relative;
      z-index: 2;
    }

    :host(:hover),
    :host([active]) {
      background: var(--accent-primary);
    }

    .overlay {
      display: none;
      position: fixed;
      inset: 0;
      z-index: 9999;
      cursor: col-resize;
    }

    :host([active]) .overlay {
      display: block;
    }
  `,Bn);Vn=N([s(`resize-handle`)],Vn);var Hn,Un=(Hn=class extends l{constructor(...e){super(...e),this.matchCount=0,this.activeIndex=-1}firstUpdated(){this.input?.focus()}onInput(e){let t=e.target.value;this.emit(`search-input`,t)}onKeyDown(e){e.key===`Escape`?this.emit(`search-close`):e.key===`Enter`&&(e.shiftKey?this.emit(`search-prev`):this.emit(`search-next`))}emit(e,t){this.dispatchEvent(new CustomEvent(e,{detail:t,bubbles:!0,composed:!0}))}get countLabel(){return this.matchCount===0?r:a`<span class="count">${this.activeIndex+1} / ${this.matchCount}</span>`}render(){let e=this.matchCount===0;return a`
      <input
        type="text"
        placeholder="Search…"
        spellcheck="false"
        @input=${this.onInput}
        @keydown=${this.onKeyDown}
      />
      ${this.countLabel}
      <button
        class="nav-btn"
        title="Previous (Shift+Enter)"
        ?disabled=${e}
        @click=${()=>this.emit(`search-prev`)}
      >
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        >
          <polyline points="18 15 12 9 6 15" />
        </svg>
      </button>
      <button
        class="nav-btn"
        title="Next (Enter)"
        ?disabled=${e}
        @click=${()=>this.emit(`search-next`)}
      >
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        >
          <polyline points="6 9 12 15 18 9" />
        </svg>
      </button>
    `}},Hn.styles=d`
    :host {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 4px 12px;
      background: var(--bg-tertiary);
      border-top: 1px solid var(--border-secondary);
    }

    input {
      flex: 1;
      min-width: 0;
      padding: 3px 8px;
      border: 1px solid var(--border-secondary);
      border-radius: var(--radius-xs);
      background: var(--bg-input, var(--bg-primary));
      color: var(--text-primary);
      font-family: inherit;
      font-size: var(--font-size-xs);
      outline: none;
      transition: border-color var(--transition-fast);
    }

    input:focus {
      border-color: var(--accent-primary);
    }

    .count {
      font-size: var(--font-size-xs);
      color: var(--text-tertiary);
      white-space: nowrap;
      min-width: 40px;
      text-align: center;
      font-variant-numeric: tabular-nums;
    }

    .nav-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 20px;
      height: 20px;
      padding: 0;
      border: none;
      border-radius: var(--radius-xs);
      background: transparent;
      color: var(--text-tertiary);
      cursor: pointer;
      flex-shrink: 0;
      transition: all var(--transition-fast);
    }

    .nav-btn:hover {
      background: var(--bg-hover);
      color: var(--accent-primary);
    }

    .nav-btn:disabled {
      opacity: 0.3;
      cursor: default;
    }

    .nav-btn svg {
      width: 12px;
      height: 12px;
    }
  `,Hn);N([n({type:Number})],Un.prototype,`matchCount`,void 0),N([n({type:Number})],Un.prototype,`activeIndex`,void 0),N([c(`input`)],Un.prototype,`input`,void 0),Un=N([s(`card-search-bar`)],Un);function Wn(e){return e+.5|0}var Gn=(e,t,n)=>Math.max(Math.min(e,n),t);function Kn(e){return Gn(Wn(e*2.55),0,255)}function qn(e){return Gn(Wn(e*255),0,255)}function Jn(e){return Gn(Wn(e/2.55)/100,0,1)}function Yn(e){return Gn(Wn(e*100),0,100)}var Xn={0:0,1:1,2:2,3:3,4:4,5:5,6:6,7:7,8:8,9:9,A:10,B:11,C:12,D:13,E:14,F:15,a:10,b:11,c:12,d:13,e:14,f:15},Zn=[...`0123456789ABCDEF`],Qn=e=>Zn[e&15],$n=e=>Zn[(e&240)>>4]+Zn[e&15],er=e=>(e&240)>>4==(e&15),tr=e=>er(e.r)&&er(e.g)&&er(e.b)&&er(e.a);function nr(e){var t=e.length,n;return e[0]===`#`&&(t===4||t===5?n={r:255&Xn[e[1]]*17,g:255&Xn[e[2]]*17,b:255&Xn[e[3]]*17,a:t===5?Xn[e[4]]*17:255}:(t===7||t===9)&&(n={r:Xn[e[1]]<<4|Xn[e[2]],g:Xn[e[3]]<<4|Xn[e[4]],b:Xn[e[5]]<<4|Xn[e[6]],a:t===9?Xn[e[7]]<<4|Xn[e[8]]:255})),n}var rr=(e,t)=>e<255?t(e):``;function ir(e){var t=tr(e)?Qn:$n;return e?`#`+t(e.r)+t(e.g)+t(e.b)+rr(e.a,t):void 0}var ar=/^(hsla?|hwb|hsv)\(\s*([-+.e\d]+)(?:deg)?[\s,]+([-+.e\d]+)%[\s,]+([-+.e\d]+)%(?:[\s,]+([-+.e\d]+)(%)?)?\s*\)$/;function or(e,t,n){let r=t*Math.min(n,1-n),i=(t,i=(t+e/30)%12)=>n-r*Math.max(Math.min(i-3,9-i,1),-1);return[i(0),i(8),i(4)]}function sr(e,t,n){let r=(r,i=(r+e/60)%6)=>n-n*t*Math.max(Math.min(i,4-i,1),0);return[r(5),r(3),r(1)]}function cr(e,t,n){let r=or(e,1,.5),i;for(t+n>1&&(i=1/(t+n),t*=i,n*=i),i=0;i<3;i++)r[i]*=1-t-n,r[i]+=t;return r}function lr(e,t,n,r,i){return e===i?(t-n)/r+(t<n?6:0):t===i?(n-e)/r+2:(e-t)/r+4}function ur(e){let t=e.r/255,n=e.g/255,r=e.b/255,i=Math.max(t,n,r),a=Math.min(t,n,r),o=(i+a)/2,s,c,l;return i!==a&&(l=i-a,c=o>.5?l/(2-i-a):l/(i+a),s=lr(t,n,r,l,i),s=s*60+.5),[s|0,c||0,o]}function dr(e,t,n,r){return(Array.isArray(t)?e(t[0],t[1],t[2]):e(t,n,r)).map(qn)}function fr(e,t,n){return dr(or,e,t,n)}function pr(e,t,n){return dr(cr,e,t,n)}function mr(e,t,n){return dr(sr,e,t,n)}function hr(e){return(e%360+360)%360}function gr(e){let t=ar.exec(e),n=255,r;if(!t)return;t[5]!==r&&(n=t[6]?Kn(+t[5]):qn(+t[5]));let i=hr(+t[2]),a=t[3]/100,o=t[4]/100;return r=t[1]===`hwb`?pr(i,a,o):t[1]===`hsv`?mr(i,a,o):fr(i,a,o),{r:r[0],g:r[1],b:r[2],a:n}}function _r(e,t){var n=ur(e);n[0]=hr(n[0]+t),n=fr(n),e.r=n[0],e.g=n[1],e.b=n[2]}function vr(e){if(!e)return;let t=ur(e),n=t[0],r=Yn(t[1]),i=Yn(t[2]);return e.a<255?`hsla(${n}, ${r}%, ${i}%, ${Jn(e.a)})`:`hsl(${n}, ${r}%, ${i}%)`}var yr={x:`dark`,Z:`light`,Y:`re`,X:`blu`,W:`gr`,V:`medium`,U:`slate`,A:`ee`,T:`ol`,S:`or`,B:`ra`,C:`lateg`,D:`ights`,R:`in`,Q:`turquois`,E:`hi`,P:`ro`,O:`al`,N:`le`,M:`de`,L:`yello`,F:`en`,K:`ch`,G:`arks`,H:`ea`,I:`ightg`,J:`wh`},br={OiceXe:`f0f8ff`,antiquewEte:`faebd7`,aqua:`ffff`,aquamarRe:`7fffd4`,azuY:`f0ffff`,beige:`f5f5dc`,bisque:`ffe4c4`,black:`0`,blanKedOmond:`ffebcd`,Xe:`ff`,XeviTet:`8a2be2`,bPwn:`a52a2a`,burlywood:`deb887`,caMtXe:`5f9ea0`,KartYuse:`7fff00`,KocTate:`d2691e`,cSO:`ff7f50`,cSnflowerXe:`6495ed`,cSnsilk:`fff8dc`,crimson:`dc143c`,cyan:`ffff`,xXe:`8b`,xcyan:`8b8b`,xgTMnPd:`b8860b`,xWay:`a9a9a9`,xgYF:`6400`,xgYy:`a9a9a9`,xkhaki:`bdb76b`,xmagFta:`8b008b`,xTivegYF:`556b2f`,xSange:`ff8c00`,xScEd:`9932cc`,xYd:`8b0000`,xsOmon:`e9967a`,xsHgYF:`8fbc8f`,xUXe:`483d8b`,xUWay:`2f4f4f`,xUgYy:`2f4f4f`,xQe:`ced1`,xviTet:`9400d3`,dAppRk:`ff1493`,dApskyXe:`bfff`,dimWay:`696969`,dimgYy:`696969`,dodgerXe:`1e90ff`,fiYbrick:`b22222`,flSOwEte:`fffaf0`,foYstWAn:`228b22`,fuKsia:`ff00ff`,gaRsbSo:`dcdcdc`,ghostwEte:`f8f8ff`,gTd:`ffd700`,gTMnPd:`daa520`,Way:`808080`,gYF:`8000`,gYFLw:`adff2f`,gYy:`808080`,honeyMw:`f0fff0`,hotpRk:`ff69b4`,RdianYd:`cd5c5c`,Rdigo:`4b0082`,ivSy:`fffff0`,khaki:`f0e68c`,lavFMr:`e6e6fa`,lavFMrXsh:`fff0f5`,lawngYF:`7cfc00`,NmoncEffon:`fffacd`,ZXe:`add8e6`,ZcSO:`f08080`,Zcyan:`e0ffff`,ZgTMnPdLw:`fafad2`,ZWay:`d3d3d3`,ZgYF:`90ee90`,ZgYy:`d3d3d3`,ZpRk:`ffb6c1`,ZsOmon:`ffa07a`,ZsHgYF:`20b2aa`,ZskyXe:`87cefa`,ZUWay:`778899`,ZUgYy:`778899`,ZstAlXe:`b0c4de`,ZLw:`ffffe0`,lime:`ff00`,limegYF:`32cd32`,lRF:`faf0e6`,magFta:`ff00ff`,maPon:`800000`,VaquamarRe:`66cdaa`,VXe:`cd`,VScEd:`ba55d3`,VpurpN:`9370db`,VsHgYF:`3cb371`,VUXe:`7b68ee`,VsprRggYF:`fa9a`,VQe:`48d1cc`,VviTetYd:`c71585`,midnightXe:`191970`,mRtcYam:`f5fffa`,mistyPse:`ffe4e1`,moccasR:`ffe4b5`,navajowEte:`ffdead`,navy:`80`,Tdlace:`fdf5e6`,Tive:`808000`,TivedBb:`6b8e23`,Sange:`ffa500`,SangeYd:`ff4500`,ScEd:`da70d6`,pOegTMnPd:`eee8aa`,pOegYF:`98fb98`,pOeQe:`afeeee`,pOeviTetYd:`db7093`,papayawEp:`ffefd5`,pHKpuff:`ffdab9`,peru:`cd853f`,pRk:`ffc0cb`,plum:`dda0dd`,powMrXe:`b0e0e6`,purpN:`800080`,YbeccapurpN:`663399`,Yd:`ff0000`,Psybrown:`bc8f8f`,PyOXe:`4169e1`,saddNbPwn:`8b4513`,sOmon:`fa8072`,sandybPwn:`f4a460`,sHgYF:`2e8b57`,sHshell:`fff5ee`,siFna:`a0522d`,silver:`c0c0c0`,skyXe:`87ceeb`,UXe:`6a5acd`,UWay:`708090`,UgYy:`708090`,snow:`fffafa`,sprRggYF:`ff7f`,stAlXe:`4682b4`,tan:`d2b48c`,teO:`8080`,tEstN:`d8bfd8`,tomato:`ff6347`,Qe:`40e0d0`,viTet:`ee82ee`,JHt:`f5deb3`,wEte:`ffffff`,wEtesmoke:`f5f5f5`,Lw:`ffff00`,LwgYF:`9acd32`};function xr(){let e={},t=Object.keys(br),n=Object.keys(yr),r,i,a,o,s;for(r=0;r<t.length;r++){for(o=s=t[r],i=0;i<n.length;i++)a=n[i],s=s.replace(a,yr[a]);a=parseInt(br[o],16),e[s]=[a>>16&255,a>>8&255,a&255]}return e}var Sr;function Cr(e){Sr||(Sr=xr(),Sr.transparent=[0,0,0,0]);let t=Sr[e.toLowerCase()];return t&&{r:t[0],g:t[1],b:t[2],a:t.length===4?t[3]:255}}var wr=/^rgba?\(\s*([-+.\d]+)(%)?[\s,]+([-+.e\d]+)(%)?[\s,]+([-+.e\d]+)(%)?(?:[\s,/]+([-+.e\d]+)(%)?)?\s*\)$/;function Tr(e){let t=wr.exec(e),n=255,r,i,a;if(t){if(t[7]!==r){let e=+t[7];n=t[8]?Kn(e):Gn(e*255,0,255)}return r=+t[1],i=+t[3],a=+t[5],r=255&(t[2]?Kn(r):Gn(r,0,255)),i=255&(t[4]?Kn(i):Gn(i,0,255)),a=255&(t[6]?Kn(a):Gn(a,0,255)),{r,g:i,b:a,a:n}}}function Er(e){return e&&(e.a<255?`rgba(${e.r}, ${e.g}, ${e.b}, ${Jn(e.a)})`:`rgb(${e.r}, ${e.g}, ${e.b})`)}var Dr=e=>e<=.0031308?e*12.92:e**(1/2.4)*1.055-.055,Or=e=>e<=.04045?e/12.92:((e+.055)/1.055)**2.4;function kr(e,t,n){let r=Or(Jn(e.r)),i=Or(Jn(e.g)),a=Or(Jn(e.b));return{r:qn(Dr(r+n*(Or(Jn(t.r))-r))),g:qn(Dr(i+n*(Or(Jn(t.g))-i))),b:qn(Dr(a+n*(Or(Jn(t.b))-a))),a:e.a+n*(t.a-e.a)}}function Ar(e,t,n){if(e){let r=ur(e);r[t]=Math.max(0,Math.min(r[t]+r[t]*n,t===0?360:1)),r=fr(r),e.r=r[0],e.g=r[1],e.b=r[2]}}function jr(e,t){return e&&Object.assign(t||{},e)}function Mr(e){var t={r:0,g:0,b:0,a:255};return Array.isArray(e)?e.length>=3&&(t={r:e[0],g:e[1],b:e[2],a:255},e.length>3&&(t.a=qn(e[3]))):(t=jr(e,{r:0,g:0,b:0,a:1}),t.a=qn(t.a)),t}function Nr(e){return e.charAt(0)===`r`?Tr(e):gr(e)}var Pr=class e{constructor(t){if(t instanceof e)return t;let n=typeof t,r;n===`object`?r=Mr(t):n===`string`&&(r=nr(t)||Cr(t)||Nr(t)),this._rgb=r,this._valid=!!r}get valid(){return this._valid}get rgb(){var e=jr(this._rgb);return e&&(e.a=Jn(e.a)),e}set rgb(e){this._rgb=Mr(e)}rgbString(){return this._valid?Er(this._rgb):void 0}hexString(){return this._valid?ir(this._rgb):void 0}hslString(){return this._valid?vr(this._rgb):void 0}mix(e,t){if(e){let n=this.rgb,r=e.rgb,i,a=t===i?.5:t,o=2*a-1,s=n.a-r.a,c=((o*s===-1?o:(o+s)/(1+o*s))+1)/2;i=1-c,n.r=255&c*n.r+i*r.r+.5,n.g=255&c*n.g+i*r.g+.5,n.b=255&c*n.b+i*r.b+.5,n.a=a*n.a+(1-a)*r.a,this.rgb=n}return this}interpolate(e,t){return e&&(this._rgb=kr(this._rgb,e._rgb,t)),this}clone(){return new e(this.rgb)}alpha(e){return this._rgb.a=qn(e),this}clearer(e){let t=this._rgb;return t.a*=1-e,this}greyscale(){let e=this._rgb;return e.r=e.g=e.b=Wn(e.r*.3+e.g*.59+e.b*.11),this}opaquer(e){let t=this._rgb;return t.a*=1+e,this}negate(){let e=this._rgb;return e.r=255-e.r,e.g=255-e.g,e.b=255-e.b,this}lighten(e){return Ar(this._rgb,2,e),this}darken(e){return Ar(this._rgb,2,-e),this}saturate(e){return Ar(this._rgb,1,e),this}desaturate(e){return Ar(this._rgb,1,-e),this}rotate(e){return _r(this._rgb,e),this}};function Fr(){}var Ir=(()=>{let e=0;return()=>e++})();function L(e){return e==null}function R(e){if(Array.isArray&&Array.isArray(e))return!0;let t=Object.prototype.toString.call(e);return t.slice(0,7)===`[object`&&t.slice(-6)===`Array]`}function z(e){return e!==null&&Object.prototype.toString.call(e)===`[object Object]`}function B(e){return(typeof e==`number`||e instanceof Number)&&isFinite(+e)}function Lr(e,t){return B(e)?e:t}function V(e,t){return e===void 0?t:e}var Rr=(e,t)=>typeof e==`string`&&e.endsWith(`%`)?parseFloat(e)/100:+e/t,zr=(e,t)=>typeof e==`string`&&e.endsWith(`%`)?parseFloat(e)/100*t:+e;function H(e,t,n){if(e&&typeof e.call==`function`)return e.apply(n,t)}function U(e,t,n,r){let i,a,o;if(R(e))if(a=e.length,r)for(i=a-1;i>=0;i--)t.call(n,e[i],i);else for(i=0;i<a;i++)t.call(n,e[i],i);else if(z(e))for(o=Object.keys(e),a=o.length,i=0;i<a;i++)t.call(n,e[o[i]],o[i])}function Br(e,t){let n,r,i,a;if(!e||!t||e.length!==t.length)return!1;for(n=0,r=e.length;n<r;++n)if(i=e[n],a=t[n],i.datasetIndex!==a.datasetIndex||i.index!==a.index)return!1;return!0}function Vr(e){if(R(e))return e.map(Vr);if(z(e)){let t=Object.create(null),n=Object.keys(e),r=n.length,i=0;for(;i<r;++i)t[n[i]]=Vr(e[n[i]]);return t}return e}function Hr(e){return[`__proto__`,`prototype`,`constructor`].indexOf(e)===-1}function Ur(e,t,n,r){if(!Hr(e))return;let i=t[e],a=n[e];z(i)&&z(a)?Wr(i,a,r):t[e]=Vr(a)}function Wr(e,t,n){let r=R(t)?t:[t],i=r.length;if(!z(e))return e;n||={};let a=n.merger||Ur,o;for(let t=0;t<i;++t){if(o=r[t],!z(o))continue;let i=Object.keys(o);for(let t=0,r=i.length;t<r;++t)a(i[t],e,o,n)}return e}function Gr(e,t){return Wr(e,t,{merger:Kr})}function Kr(e,t,n){if(!Hr(e))return;let r=t[e],i=n[e];z(r)&&z(i)?Gr(r,i):Object.prototype.hasOwnProperty.call(t,e)||(t[e]=Vr(i))}var qr={"":e=>e,x:e=>e.x,y:e=>e.y};function Jr(e){let t=e.split(`.`),n=[],r=``;for(let e of t)r+=e,r.endsWith(`\\`)?r=r.slice(0,-1)+`.`:(n.push(r),r=``);return n}function Yr(e){let t=Jr(e);return e=>{for(let n of t){if(n===``)break;e&&=e[n]}return e}}function Xr(e,t){return(qr[t]||(qr[t]=Yr(t)))(e)}function Zr(e){return e.charAt(0).toUpperCase()+e.slice(1)}var Qr=e=>e!==void 0,$r=e=>typeof e==`function`,ei=(e,t)=>{if(e.size!==t.size)return!1;for(let n of e)if(!t.has(n))return!1;return!0};function ti(e){return e.type===`mouseup`||e.type===`click`||e.type===`contextmenu`}var W=Math.PI,G=2*W,ni=G+W,ri=1/0,ii=W/180,K=W/2,ai=W/4,oi=W*2/3,si=Math.log10,ci=Math.sign;function li(e,t,n){return Math.abs(e-t)<n}function ui(e){let t=Math.round(e);e=li(e,t,e/1e3)?t:e;let n=10**Math.floor(si(e)),r=e/n;return(r<=1?1:r<=2?2:r<=5?5:10)*n}function di(e){let t=[],n=Math.sqrt(e),r;for(r=1;r<n;r++)e%r===0&&(t.push(r),t.push(e/r));return n===(n|0)&&t.push(n),t.sort((e,t)=>e-t).pop(),t}function fi(e){return typeof e==`symbol`||typeof e==`object`&&!!e&&!(Symbol.toPrimitive in e||`toString`in e||`valueOf`in e)}function pi(e){return!fi(e)&&!isNaN(parseFloat(e))&&isFinite(e)}function mi(e,t){let n=Math.round(e);return n-t<=e&&n+t>=e}function hi(e,t,n){let r,i,a;for(r=0,i=e.length;r<i;r++)a=e[r][n],isNaN(a)||(t.min=Math.min(t.min,a),t.max=Math.max(t.max,a))}function gi(e){return W/180*e}function _i(e){return 180/W*e}function vi(e){if(!B(e))return;let t=1,n=0;for(;Math.round(e*t)/t!==e;)t*=10,n++;return n}function yi(e,t){let n=t.x-e.x,r=t.y-e.y,i=Math.sqrt(n*n+r*r),a=Math.atan2(r,n);return a<-.5*W&&(a+=G),{angle:a,distance:i}}function bi(e,t){return Math.sqrt((t.x-e.x)**2+(t.y-e.y)**2)}function xi(e,t){return(e-t+ni)%G-W}function q(e){return(e%G+G)%G}function Si(e,t,n,r){let i=q(e),a=q(t),o=q(n),s=q(a-i),c=q(o-i),l=q(i-a),u=q(i-o);return i===a||i===o||r&&a===o||s>c&&l<u}function J(e,t,n){return Math.max(t,Math.min(n,e))}function Ci(e){return J(e,-32768,32767)}function wi(e,t,n,r=1e-6){return e>=Math.min(t,n)-r&&e<=Math.max(t,n)+r}function Ti(e,t,n){n||=(n=>e[n]<t);let r=e.length-1,i=0,a;for(;r-i>1;)a=i+r>>1,n(a)?i=a:r=a;return{lo:i,hi:r}}var Ei=(e,t,n,r)=>Ti(e,n,r?r=>{let i=e[r][t];return i<n||i===n&&e[r+1][t]===n}:r=>e[r][t]<n),Di=(e,t,n)=>Ti(e,n,r=>e[r][t]>=n);function Oi(e,t,n){let r=0,i=e.length;for(;r<i&&e[r]<t;)r++;for(;i>r&&e[i-1]>n;)i--;return r>0||i<e.length?e.slice(r,i):e}var ki=[`push`,`pop`,`shift`,`splice`,`unshift`];function Ai(e,t){if(e._chartjs){e._chartjs.listeners.push(t);return}Object.defineProperty(e,`_chartjs`,{configurable:!0,enumerable:!1,value:{listeners:[t]}}),ki.forEach(t=>{let n=`_onData`+Zr(t),r=e[t];Object.defineProperty(e,t,{configurable:!0,enumerable:!1,value(...t){let i=r.apply(this,t);return e._chartjs.listeners.forEach(e=>{typeof e[n]==`function`&&e[n](...t)}),i}})})}function ji(e,t){let n=e._chartjs;if(!n)return;let r=n.listeners,i=r.indexOf(t);i!==-1&&r.splice(i,1),!(r.length>0)&&(ki.forEach(t=>{delete e[t]}),delete e._chartjs)}function Mi(e){let t=new Set(e);return t.size===e.length?e:Array.from(t)}var Ni=function(){return typeof window>`u`?function(e){return e()}:window.requestAnimationFrame}();function Pi(e,t){let n=[],r=!1;return function(...i){n=i,r||(r=!0,Ni.call(window,()=>{r=!1,e.apply(t,n)}))}}function Fi(e,t){let n;return function(...r){return t?(clearTimeout(n),n=setTimeout(e,t,r)):e.apply(this,r),t}}var Ii=e=>e===`start`?`left`:e===`end`?`right`:`center`,Li=(e,t,n)=>e===`start`?t:e===`end`?n:(t+n)/2,Ri=(e,t,n,r)=>e===(r?`left`:`right`)?n:e===`center`?(t+n)/2:t;function zi(e,t,n){let r=t.length,i=0,a=r;if(e._sorted){let{iScale:o,vScale:s,_parsed:c}=e,l=e.dataset&&e.dataset.options?e.dataset.options.spanGaps:null,u=o.axis,{min:d,max:f,minDefined:p,maxDefined:m}=o.getUserBounds();if(p){if(i=Math.min(Ei(c,u,d).lo,n?r:Ei(t,u,o.getPixelForValue(d)).lo),l){let e=c.slice(0,i+1).reverse().findIndex(e=>!L(e[s.axis]));i-=Math.max(0,e)}i=J(i,0,r-1)}if(m){let e=Math.max(Ei(c,o.axis,f,!0).hi+1,n?0:Ei(t,u,o.getPixelForValue(f),!0).hi+1);if(l){let t=c.slice(e-1).findIndex(e=>!L(e[s.axis]));e+=Math.max(0,t)}a=J(e,i,r)-i}else a=r-i}return{start:i,count:a}}function Bi(e){let{xScale:t,yScale:n,_scaleRanges:r}=e,i={xmin:t.min,xmax:t.max,ymin:n.min,ymax:n.max};if(!r)return e._scaleRanges=i,!0;let a=r.xmin!==t.min||r.xmax!==t.max||r.ymin!==n.min||r.ymax!==n.max;return Object.assign(r,i),a}var Vi=e=>e===0||e===1,Hi=(e,t,n)=>-(2**(10*--e)*Math.sin((e-t)*G/n)),Ui=(e,t,n)=>2**(-10*e)*Math.sin((e-t)*G/n)+1,Wi={linear:e=>e,easeInQuad:e=>e*e,easeOutQuad:e=>-e*(e-2),easeInOutQuad:e=>(e/=.5)<1?.5*e*e:-.5*(--e*(e-2)-1),easeInCubic:e=>e*e*e,easeOutCubic:e=>--e*e*e+1,easeInOutCubic:e=>(e/=.5)<1?.5*e*e*e:.5*((e-=2)*e*e+2),easeInQuart:e=>e*e*e*e,easeOutQuart:e=>-(--e*e*e*e-1),easeInOutQuart:e=>(e/=.5)<1?.5*e*e*e*e:-.5*((e-=2)*e*e*e-2),easeInQuint:e=>e*e*e*e*e,easeOutQuint:e=>--e*e*e*e*e+1,easeInOutQuint:e=>(e/=.5)<1?.5*e*e*e*e*e:.5*((e-=2)*e*e*e*e+2),easeInSine:e=>-Math.cos(e*K)+1,easeOutSine:e=>Math.sin(e*K),easeInOutSine:e=>-.5*(Math.cos(W*e)-1),easeInExpo:e=>e===0?0:2**(10*(e-1)),easeOutExpo:e=>e===1?1:-(2**(-10*e))+1,easeInOutExpo:e=>Vi(e)?e:e<.5?.5*2**(10*(e*2-1)):.5*(-(2**(-10*(e*2-1)))+2),easeInCirc:e=>e>=1?e:-(Math.sqrt(1-e*e)-1),easeOutCirc:e=>Math.sqrt(1- --e*e),easeInOutCirc:e=>(e/=.5)<1?-.5*(Math.sqrt(1-e*e)-1):.5*(Math.sqrt(1-(e-=2)*e)+1),easeInElastic:e=>Vi(e)?e:Hi(e,.075,.3),easeOutElastic:e=>Vi(e)?e:Ui(e,.075,.3),easeInOutElastic(e){let t=.1125,n=.45;return Vi(e)?e:e<.5?.5*Hi(e*2,t,n):.5+.5*Ui(e*2-1,t,n)},easeInBack(e){let t=1.70158;return e*e*((t+1)*e-t)},easeOutBack(e){let t=1.70158;return--e*e*((t+1)*e+t)+1},easeInOutBack(e){let t=1.70158;return(e/=.5)<1?.5*(e*e*(((t*=1.525)+1)*e-t)):.5*((e-=2)*e*(((t*=1.525)+1)*e+t)+2)},easeInBounce:e=>1-Wi.easeOutBounce(1-e),easeOutBounce(e){let t=7.5625,n=2.75;return e<1/n?t*e*e:e<2/n?t*(e-=1.5/n)*e+.75:e<2.5/n?t*(e-=2.25/n)*e+.9375:t*(e-=2.625/n)*e+.984375},easeInOutBounce:e=>e<.5?Wi.easeInBounce(e*2)*.5:Wi.easeOutBounce(e*2-1)*.5+.5};function Gi(e){if(e&&typeof e==`object`){let t=e.toString();return t===`[object CanvasPattern]`||t===`[object CanvasGradient]`}return!1}function Ki(e){return Gi(e)?e:new Pr(e)}function qi(e){return Gi(e)?e:new Pr(e).saturate(.5).darken(.1).hexString()}var Ji=[`x`,`y`,`borderWidth`,`radius`,`tension`],Yi=[`color`,`borderColor`,`backgroundColor`];function Xi(e){e.set(`animation`,{delay:void 0,duration:1e3,easing:`easeOutQuart`,fn:void 0,from:void 0,loop:void 0,to:void 0,type:void 0}),e.describe(`animation`,{_fallback:!1,_indexable:!1,_scriptable:e=>e!==`onProgress`&&e!==`onComplete`&&e!==`fn`}),e.set(`animations`,{colors:{type:`color`,properties:Yi},numbers:{type:`number`,properties:Ji}}),e.describe(`animations`,{_fallback:`animation`}),e.set(`transitions`,{active:{animation:{duration:400}},resize:{animation:{duration:0}},show:{animations:{colors:{from:`transparent`},visible:{type:`boolean`,duration:0}}},hide:{animations:{colors:{to:`transparent`},visible:{type:`boolean`,easing:`linear`,fn:e=>e|0}}}})}function Zi(e){e.set(`layout`,{autoPadding:!0,padding:{top:0,right:0,bottom:0,left:0}})}var Qi=new Map;function $i(e,t){t||={};let n=e+JSON.stringify(t),r=Qi.get(n);return r||(r=new Intl.NumberFormat(e,t),Qi.set(n,r)),r}function ea(e,t,n){return $i(t,n).format(e)}var ta={values(e){return R(e)?e:``+e},numeric(e,t,n){if(e===0)return`0`;let r=this.chart.options.locale,i,a=e;if(n.length>1){let t=Math.max(Math.abs(n[0].value),Math.abs(n[n.length-1].value));(t<1e-4||t>0x38d7ea4c68000)&&(i=`scientific`),a=na(e,n)}let o=si(Math.abs(a)),s=isNaN(o)?1:Math.max(Math.min(-1*Math.floor(o),20),0),c={notation:i,minimumFractionDigits:s,maximumFractionDigits:s};return Object.assign(c,this.options.ticks.format),ea(e,r,c)},logarithmic(e,t,n){if(e===0)return`0`;let r=n[t].significand||e/10**Math.floor(si(e));return[1,2,3,5,10,15].includes(r)||t>.8*n.length?ta.numeric.call(this,e,t,n):``}};function na(e,t){let n=t.length>3?t[2].value-t[1].value:t[1].value-t[0].value;return Math.abs(n)>=1&&e!==Math.floor(e)&&(n=e-Math.floor(e)),n}var ra={formatters:ta};function ia(e){e.set(`scale`,{display:!0,offset:!1,reverse:!1,beginAtZero:!1,bounds:`ticks`,clip:!0,grace:0,grid:{display:!0,lineWidth:1,drawOnChartArea:!0,drawTicks:!0,tickLength:8,tickWidth:(e,t)=>t.lineWidth,tickColor:(e,t)=>t.color,offset:!1},border:{display:!0,dash:[],dashOffset:0,width:1},title:{display:!1,text:``,padding:{top:4,bottom:4}},ticks:{minRotation:0,maxRotation:50,mirror:!1,textStrokeWidth:0,textStrokeColor:``,padding:3,display:!0,autoSkip:!0,autoSkipPadding:3,labelOffset:0,callback:ra.formatters.values,minor:{},major:{},align:`center`,crossAlign:`near`,showLabelBackdrop:!1,backdropColor:`rgba(255, 255, 255, 0.75)`,backdropPadding:2}}),e.route(`scale.ticks`,`color`,``,`color`),e.route(`scale.grid`,`color`,``,`borderColor`),e.route(`scale.border`,`color`,``,`borderColor`),e.route(`scale.title`,`color`,``,`color`),e.describe(`scale`,{_fallback:!1,_scriptable:e=>!e.startsWith(`before`)&&!e.startsWith(`after`)&&e!==`callback`&&e!==`parser`,_indexable:e=>e!==`borderDash`&&e!==`tickBorderDash`&&e!==`dash`}),e.describe(`scales`,{_fallback:`scale`}),e.describe(`scale.ticks`,{_scriptable:e=>e!==`backdropPadding`&&e!==`callback`,_indexable:e=>e!==`backdropPadding`})}var aa=Object.create(null),oa=Object.create(null);function sa(e,t){if(!t)return e;let n=t.split(`.`);for(let t=0,r=n.length;t<r;++t){let r=n[t];e=e[r]||(e[r]=Object.create(null))}return e}function ca(e,t,n){return typeof t==`string`?Wr(sa(e,t),n):Wr(sa(e,``),t)}var Y=new class{constructor(e,t){this.animation=void 0,this.backgroundColor=`rgba(0,0,0,0.1)`,this.borderColor=`rgba(0,0,0,0.1)`,this.color=`#666`,this.datasets={},this.devicePixelRatio=e=>e.chart.platform.getDevicePixelRatio(),this.elements={},this.events=[`mousemove`,`mouseout`,`click`,`touchstart`,`touchmove`],this.font={family:`'Helvetica Neue', 'Helvetica', 'Arial', sans-serif`,size:12,style:`normal`,lineHeight:1.2,weight:null},this.hover={},this.hoverBackgroundColor=(e,t)=>qi(t.backgroundColor),this.hoverBorderColor=(e,t)=>qi(t.borderColor),this.hoverColor=(e,t)=>qi(t.color),this.indexAxis=`x`,this.interaction={mode:`nearest`,intersect:!0,includeInvisible:!1},this.maintainAspectRatio=!0,this.onHover=null,this.onClick=null,this.parsing=!0,this.plugins={},this.responsive=!0,this.scale=void 0,this.scales={},this.showLine=!0,this.drawActiveElementsOnTop=!0,this.describe(e),this.apply(t)}set(e,t){return ca(this,e,t)}get(e){return sa(this,e)}describe(e,t){return ca(oa,e,t)}override(e,t){return ca(aa,e,t)}route(e,t,n,r){let i=sa(this,e),a=sa(this,n),o=`_`+t;Object.defineProperties(i,{[o]:{value:i[t],writable:!0},[t]:{enumerable:!0,get(){let e=this[o],t=a[r];return z(e)?Object.assign({},t,e):V(e,t)},set(e){this[o]=e}}})}apply(e){e.forEach(e=>e(this))}}({_scriptable:e=>!e.startsWith(`on`),_indexable:e=>e!==`events`,hover:{_fallback:`interaction`},interaction:{_scriptable:!1,_indexable:!1}},[Xi,Zi,ia]);function la(e){return!e||L(e.size)||L(e.family)?null:(e.style?e.style+` `:``)+(e.weight?e.weight+` `:``)+e.size+`px `+e.family}function ua(e,t,n,r,i){let a=t[i];return a||(a=t[i]=e.measureText(i).width,n.push(i)),a>r&&(r=a),r}function da(e,t,n,r){r||={};let i=r.data=r.data||{},a=r.garbageCollect=r.garbageCollect||[];r.font!==t&&(i=r.data={},a=r.garbageCollect=[],r.font=t),e.save(),e.font=t;let o=0,s=n.length,c,l,u,d,f;for(c=0;c<s;c++)if(d=n[c],d!=null&&!R(d))o=ua(e,i,a,o,d);else if(R(d))for(l=0,u=d.length;l<u;l++)f=d[l],f!=null&&!R(f)&&(o=ua(e,i,a,o,f));e.restore();let p=a.length/2;if(p>n.length){for(c=0;c<p;c++)delete i[a[c]];a.splice(0,p)}return o}function fa(e,t,n){let r=e.currentDevicePixelRatio,i=n===0?0:Math.max(n/2,.5);return Math.round((t-i)*r)/r+i}function pa(e,t){!t&&!e||(t||=e.getContext(`2d`),t.save(),t.resetTransform(),t.clearRect(0,0,e.width,e.height),t.restore())}function ma(e,t,n,r){ha(e,t,n,r,null)}function ha(e,t,n,r,i){let a,o,s,c,l,u,d,f,p=t.pointStyle,m=t.rotation,h=t.radius,g=(m||0)*ii;if(p&&typeof p==`object`&&(a=p.toString(),a===`[object HTMLImageElement]`||a===`[object HTMLCanvasElement]`)){e.save(),e.translate(n,r),e.rotate(g),e.drawImage(p,-p.width/2,-p.height/2,p.width,p.height),e.restore();return}if(!(isNaN(h)||h<=0)){switch(e.beginPath(),p){default:i?e.ellipse(n,r,i/2,h,0,0,G):e.arc(n,r,h,0,G),e.closePath();break;case`triangle`:u=i?i/2:h,e.moveTo(n+Math.sin(g)*u,r-Math.cos(g)*h),g+=oi,e.lineTo(n+Math.sin(g)*u,r-Math.cos(g)*h),g+=oi,e.lineTo(n+Math.sin(g)*u,r-Math.cos(g)*h),e.closePath();break;case`rectRounded`:l=h*.516,c=h-l,o=Math.cos(g+ai)*c,d=Math.cos(g+ai)*(i?i/2-l:c),s=Math.sin(g+ai)*c,f=Math.sin(g+ai)*(i?i/2-l:c),e.arc(n-d,r-s,l,g-W,g-K),e.arc(n+f,r-o,l,g-K,g),e.arc(n+d,r+s,l,g,g+K),e.arc(n-f,r+o,l,g+K,g+W),e.closePath();break;case`rect`:if(!m){c=Math.SQRT1_2*h,u=i?i/2:c,e.rect(n-u,r-c,2*u,2*c);break}g+=ai;case`rectRot`:d=Math.cos(g)*(i?i/2:h),o=Math.cos(g)*h,s=Math.sin(g)*h,f=Math.sin(g)*(i?i/2:h),e.moveTo(n-d,r-s),e.lineTo(n+f,r-o),e.lineTo(n+d,r+s),e.lineTo(n-f,r+o),e.closePath();break;case`crossRot`:g+=ai;case`cross`:d=Math.cos(g)*(i?i/2:h),o=Math.cos(g)*h,s=Math.sin(g)*h,f=Math.sin(g)*(i?i/2:h),e.moveTo(n-d,r-s),e.lineTo(n+d,r+s),e.moveTo(n+f,r-o),e.lineTo(n-f,r+o);break;case`star`:d=Math.cos(g)*(i?i/2:h),o=Math.cos(g)*h,s=Math.sin(g)*h,f=Math.sin(g)*(i?i/2:h),e.moveTo(n-d,r-s),e.lineTo(n+d,r+s),e.moveTo(n+f,r-o),e.lineTo(n-f,r+o),g+=ai,d=Math.cos(g)*(i?i/2:h),o=Math.cos(g)*h,s=Math.sin(g)*h,f=Math.sin(g)*(i?i/2:h),e.moveTo(n-d,r-s),e.lineTo(n+d,r+s),e.moveTo(n+f,r-o),e.lineTo(n-f,r+o);break;case`line`:o=i?i/2:Math.cos(g)*h,s=Math.sin(g)*h,e.moveTo(n-o,r-s),e.lineTo(n+o,r+s);break;case`dash`:e.moveTo(n,r),e.lineTo(n+Math.cos(g)*(i?i/2:h),r+Math.sin(g)*h);break;case!1:e.closePath();break}e.fill(),t.borderWidth>0&&e.stroke()}}function ga(e,t,n){return n||=.5,!t||e&&e.x>t.left-n&&e.x<t.right+n&&e.y>t.top-n&&e.y<t.bottom+n}function _a(e,t){e.save(),e.beginPath(),e.rect(t.left,t.top,t.right-t.left,t.bottom-t.top),e.clip()}function va(e){e.restore()}function ya(e,t,n,r,i){if(!t)return e.lineTo(n.x,n.y);if(i===`middle`){let r=(t.x+n.x)/2;e.lineTo(r,t.y),e.lineTo(r,n.y)}else i===`after`==!!r?e.lineTo(n.x,t.y):e.lineTo(t.x,n.y);e.lineTo(n.x,n.y)}function ba(e,t,n,r){if(!t)return e.lineTo(n.x,n.y);e.bezierCurveTo(r?t.cp1x:t.cp2x,r?t.cp1y:t.cp2y,r?n.cp2x:n.cp1x,r?n.cp2y:n.cp1y,n.x,n.y)}function xa(e,t){t.translation&&e.translate(t.translation[0],t.translation[1]),L(t.rotation)||e.rotate(t.rotation),t.color&&(e.fillStyle=t.color),t.textAlign&&(e.textAlign=t.textAlign),t.textBaseline&&(e.textBaseline=t.textBaseline)}function Sa(e,t,n,r,i){if(i.strikethrough||i.underline){let a=e.measureText(r),o=t-a.actualBoundingBoxLeft,s=t+a.actualBoundingBoxRight,c=n-a.actualBoundingBoxAscent,l=n+a.actualBoundingBoxDescent,u=i.strikethrough?(c+l)/2:l;e.strokeStyle=e.fillStyle,e.beginPath(),e.lineWidth=i.decorationWidth||2,e.moveTo(o,u),e.lineTo(s,u),e.stroke()}}function Ca(e,t){let n=e.fillStyle;e.fillStyle=t.color,e.fillRect(t.left,t.top,t.width,t.height),e.fillStyle=n}function wa(e,t,n,r,i,a={}){let o=R(t)?t:[t],s=a.strokeWidth>0&&a.strokeColor!==``,c,l;for(e.save(),e.font=i.string,xa(e,a),c=0;c<o.length;++c)l=o[c],a.backdrop&&Ca(e,a.backdrop),s&&(a.strokeColor&&(e.strokeStyle=a.strokeColor),L(a.strokeWidth)||(e.lineWidth=a.strokeWidth),e.strokeText(l,n,r,a.maxWidth)),e.fillText(l,n,r,a.maxWidth),Sa(e,n,r,l,a),r+=Number(i.lineHeight);e.restore()}function Ta(e,t){let{x:n,y:r,w:i,h:a,radius:o}=t;e.arc(n+o.topLeft,r+o.topLeft,o.topLeft,1.5*W,W,!0),e.lineTo(n,r+a-o.bottomLeft),e.arc(n+o.bottomLeft,r+a-o.bottomLeft,o.bottomLeft,W,K,!0),e.lineTo(n+i-o.bottomRight,r+a),e.arc(n+i-o.bottomRight,r+a-o.bottomRight,o.bottomRight,K,0,!0),e.lineTo(n+i,r+o.topRight),e.arc(n+i-o.topRight,r+o.topRight,o.topRight,0,-K,!0),e.lineTo(n+o.topLeft,r)}var Ea=/^(normal|(\d+(?:\.\d+)?)(px|em|%)?)$/,Da=/^(normal|italic|initial|inherit|unset|(oblique( -?[0-9]?[0-9]deg)?))$/;function Oa(e,t){let n=(``+e).match(Ea);if(!n||n[1]===`normal`)return t*1.2;switch(e=+n[2],n[3]){case`px`:return e;case`%`:e/=100;break}return t*e}var ka=e=>+e||0;function Aa(e,t){let n={},r=z(t),i=r?Object.keys(t):t,a=z(e)?r?n=>V(e[n],e[t[n]]):t=>e[t]:()=>e;for(let e of i)n[e]=ka(a(e));return n}function ja(e){return Aa(e,{top:`y`,right:`x`,bottom:`y`,left:`x`})}function Ma(e){return Aa(e,[`topLeft`,`topRight`,`bottomLeft`,`bottomRight`])}function X(e){let t=ja(e);return t.width=t.left+t.right,t.height=t.top+t.bottom,t}function Z(e,t){e||={},t||=Y.font;let n=V(e.size,t.size);typeof n==`string`&&(n=parseInt(n,10));let r=V(e.style,t.style);r&&!(``+r).match(Da)&&(console.warn(`Invalid font style specified: "`+r+`"`),r=void 0);let i={family:V(e.family,t.family),lineHeight:Oa(V(e.lineHeight,t.lineHeight),n),size:n,style:r,weight:V(e.weight,t.weight),string:``};return i.string=la(i),i}function Na(e,t,n,r){let i=!0,a,o,s;for(a=0,o=e.length;a<o;++a)if(s=e[a],s!==void 0&&(t!==void 0&&typeof s==`function`&&(s=s(t),i=!1),n!==void 0&&R(s)&&(s=s[n%s.length],i=!1),s!==void 0))return r&&!i&&(r.cacheable=!1),s}function Pa(e,t,n){let{min:r,max:i}=e,a=zr(t,(i-r)/2),o=(e,t)=>n&&e===0?0:e+t;return{min:o(r,-Math.abs(a)),max:o(i,a)}}function Fa(e,t){return Object.assign(Object.create(e),t)}function Ia(e,t=[``],n,r,i=()=>e[0]){let a=n||e;r===void 0&&(r=Qa(`_fallback`,e));let o={[Symbol.toStringTag]:`Object`,_cacheable:!0,_scopes:e,_rootScopes:a,_fallback:r,_getTarget:i,override:n=>Ia([n,...e],t,a,r)};return new Proxy(o,{deleteProperty(t,n){return delete t[n],delete t._keys,delete e[0][n],!0},get(n,r){return Va(n,r,()=>Za(r,t,e,n))},getOwnPropertyDescriptor(e,t){return Reflect.getOwnPropertyDescriptor(e._scopes[0],t)},getPrototypeOf(){return Reflect.getPrototypeOf(e[0])},has(e,t){return $a(e).includes(t)},ownKeys(e){return $a(e)},set(e,t,n){let r=e._storage||=i();return e[t]=r[t]=n,delete e._keys,!0}})}function La(e,t,n,r){let i={_cacheable:!1,_proxy:e,_context:t,_subProxy:n,_stack:new Set,_descriptors:Ra(e,r),setContext:t=>La(e,t,n,r),override:i=>La(e.override(i),t,n,r)};return new Proxy(i,{deleteProperty(t,n){return delete t[n],delete e[n],!0},get(e,t,n){return Va(e,t,()=>Ha(e,t,n))},getOwnPropertyDescriptor(t,n){return t._descriptors.allKeys?Reflect.has(e,n)?{enumerable:!0,configurable:!0}:void 0:Reflect.getOwnPropertyDescriptor(e,n)},getPrototypeOf(){return Reflect.getPrototypeOf(e)},has(t,n){return Reflect.has(e,n)},ownKeys(){return Reflect.ownKeys(e)},set(t,n,r){return e[n]=r,delete t[n],!0}})}function Ra(e,t={scriptable:!0,indexable:!0}){let{_scriptable:n=t.scriptable,_indexable:r=t.indexable,_allKeys:i=t.allKeys}=e;return{allKeys:i,scriptable:n,indexable:r,isScriptable:$r(n)?n:()=>n,isIndexable:$r(r)?r:()=>r}}var za=(e,t)=>e?e+Zr(t):t,Ba=(e,t)=>z(t)&&e!==`adapters`&&(Object.getPrototypeOf(t)===null||t.constructor===Object);function Va(e,t,n){if(Object.prototype.hasOwnProperty.call(e,t)||t===`constructor`)return e[t];let r=n();return e[t]=r,r}function Ha(e,t,n){let{_proxy:r,_context:i,_subProxy:a,_descriptors:o}=e,s=r[t];return $r(s)&&o.isScriptable(t)&&(s=Ua(t,s,e,n)),R(s)&&s.length&&(s=Wa(t,s,e,o.isIndexable)),Ba(t,s)&&(s=La(s,i,a&&a[t],o)),s}function Ua(e,t,n,r){let{_proxy:i,_context:a,_subProxy:o,_stack:s}=n;if(s.has(e))throw Error(`Recursion detected: `+Array.from(s).join(`->`)+`->`+e);s.add(e);let c=t(a,o||r);return s.delete(e),Ba(e,c)&&(c=Ja(i._scopes,i,e,c)),c}function Wa(e,t,n,r){let{_proxy:i,_context:a,_subProxy:o,_descriptors:s}=n;if(a.index!==void 0&&r(e))return t[a.index%t.length];if(z(t[0])){let n=t,r=i._scopes.filter(e=>e!==n);t=[];for(let c of n){let n=Ja(r,i,e,c);t.push(La(n,a,o&&o[e],s))}}return t}function Ga(e,t,n){return $r(e)?e(t,n):e}var Ka=(e,t)=>e===!0?t:typeof e==`string`?Xr(t,e):void 0;function qa(e,t,n,r,i){for(let a of t){let t=Ka(n,a);if(t){e.add(t);let a=Ga(t._fallback,n,i);if(a!==void 0&&a!==n&&a!==r)return a}else if(t===!1&&r!==void 0&&n!==r)return null}return!1}function Ja(e,t,n,r){let i=t._rootScopes,a=Ga(t._fallback,n,r),o=[...e,...i],s=new Set;s.add(r);let c=Ya(s,o,n,a||n,r);return c===null||a!==void 0&&a!==n&&(c=Ya(s,o,a,c,r),c===null)?!1:Ia(Array.from(s),[``],i,a,()=>Xa(t,n,r))}function Ya(e,t,n,r,i){for(;n;)n=qa(e,t,n,r,i);return n}function Xa(e,t,n){let r=e._getTarget();t in r||(r[t]={});let i=r[t];return R(i)&&z(n)?n:i||{}}function Za(e,t,n,r){let i;for(let a of t)if(i=Qa(za(a,e),n),i!==void 0)return Ba(e,i)?Ja(n,r,e,i):i}function Qa(e,t){for(let n of t){if(!n)continue;let t=n[e];if(t!==void 0)return t}}function $a(e){let t=e._keys;return t||=e._keys=eo(e._scopes),t}function eo(e){let t=new Set;for(let n of e)for(let e of Object.keys(n).filter(e=>!e.startsWith(`_`)))t.add(e);return Array.from(t)}function to(e,t,n,r){let{iScale:i}=e,{key:a=`r`}=this._parsing,o=Array(r),s,c,l,u;for(s=0,c=r;s<c;++s)l=s+n,u=t[l],o[s]={r:i.parse(Xr(u,a),l)};return o}var no=2**-52||1e-14,ro=(e,t)=>t<e.length&&!e[t].skip&&e[t],io=e=>e===`x`?`y`:`x`;function ao(e,t,n,r){let i=e.skip?t:e,a=t,o=n.skip?t:n,s=bi(a,i),c=bi(o,a),l=s/(s+c),u=c/(s+c);l=isNaN(l)?0:l,u=isNaN(u)?0:u;let d=r*l,f=r*u;return{previous:{x:a.x-d*(o.x-i.x),y:a.y-d*(o.y-i.y)},next:{x:a.x+f*(o.x-i.x),y:a.y+f*(o.y-i.y)}}}function oo(e,t,n){let r=e.length,i,a,o,s,c,l=ro(e,0);for(let u=0;u<r-1;++u)if(c=l,l=ro(e,u+1),!(!c||!l)){if(li(t[u],0,no)){n[u]=n[u+1]=0;continue}i=n[u]/t[u],a=n[u+1]/t[u],s=i**2+a**2,!(s<=9)&&(o=3/Math.sqrt(s),n[u]=i*o*t[u],n[u+1]=a*o*t[u])}}function so(e,t,n=`x`){let r=io(n),i=e.length,a,o,s,c=ro(e,0);for(let l=0;l<i;++l){if(o=s,s=c,c=ro(e,l+1),!s)continue;let i=s[n],u=s[r];o&&(a=(i-o[n])/3,s[`cp1${n}`]=i-a,s[`cp1${r}`]=u-a*t[l]),c&&(a=(c[n]-i)/3,s[`cp2${n}`]=i+a,s[`cp2${r}`]=u+a*t[l])}}function co(e,t=`x`){let n=io(t),r=e.length,i=Array(r).fill(0),a=Array(r),o,s,c,l=ro(e,0);for(o=0;o<r;++o)if(s=c,c=l,l=ro(e,o+1),c){if(l){let e=l[t]-c[t];i[o]=e===0?0:(l[n]-c[n])/e}a[o]=s?l?ci(i[o-1])===ci(i[o])?(i[o-1]+i[o])/2:0:i[o-1]:i[o]}oo(e,i,a),so(e,a,t)}function lo(e,t,n){return Math.max(Math.min(e,n),t)}function uo(e,t){let n,r,i,a,o,s=ga(e[0],t);for(n=0,r=e.length;n<r;++n)o=a,a=s,s=n<r-1&&ga(e[n+1],t),a&&(i=e[n],o&&(i.cp1x=lo(i.cp1x,t.left,t.right),i.cp1y=lo(i.cp1y,t.top,t.bottom)),s&&(i.cp2x=lo(i.cp2x,t.left,t.right),i.cp2y=lo(i.cp2y,t.top,t.bottom)))}function fo(e,t,n,r,i){let a,o,s,c;if(t.spanGaps&&(e=e.filter(e=>!e.skip)),t.cubicInterpolationMode===`monotone`)co(e,i);else{let n=r?e[e.length-1]:e[0];for(a=0,o=e.length;a<o;++a)s=e[a],c=ao(n,s,e[Math.min(a+1,o-(r?0:1))%o],t.tension),s.cp1x=c.previous.x,s.cp1y=c.previous.y,s.cp2x=c.next.x,s.cp2y=c.next.y,n=s}t.capBezierPoints&&uo(e,n)}function po(){return typeof window<`u`&&typeof document<`u`}function mo(e){let t=e.parentNode;return t&&t.toString()===`[object ShadowRoot]`&&(t=t.host),t}function ho(e,t,n){let r;return typeof e==`string`?(r=parseInt(e,10),e.indexOf(`%`)!==-1&&(r=r/100*t.parentNode[n])):r=e,r}var go=e=>e.ownerDocument.defaultView.getComputedStyle(e,null);function _o(e,t){return go(e).getPropertyValue(t)}var vo=[`top`,`right`,`bottom`,`left`];function yo(e,t,n){let r={};n=n?`-`+n:``;for(let i=0;i<4;i++){let a=vo[i];r[a]=parseFloat(e[t+`-`+a+n])||0}return r.width=r.left+r.right,r.height=r.top+r.bottom,r}var bo=(e,t,n)=>(e>0||t>0)&&(!n||!n.shadowRoot);function xo(e,t){let n=e.touches,r=n&&n.length?n[0]:e,{offsetX:i,offsetY:a}=r,o=!1,s,c;if(bo(i,a,e.target))s=i,c=a;else{let e=t.getBoundingClientRect();s=r.clientX-e.left,c=r.clientY-e.top,o=!0}return{x:s,y:c,box:o}}function So(e,t){if(`native`in e)return e;let{canvas:n,currentDevicePixelRatio:r}=t,i=go(n),a=i.boxSizing===`border-box`,o=yo(i,`padding`),s=yo(i,`border`,`width`),{x:c,y:l,box:u}=xo(e,n),d=o.left+(u&&s.left),f=o.top+(u&&s.top),{width:p,height:m}=t;return a&&(p-=o.width+s.width,m-=o.height+s.height),{x:Math.round((c-d)/p*n.width/r),y:Math.round((l-f)/m*n.height/r)}}function Co(e,t,n){let r,i;if(t===void 0||n===void 0){let a=e&&mo(e);if(!a)t=e.clientWidth,n=e.clientHeight;else{let e=a.getBoundingClientRect(),o=go(a),s=yo(o,`border`,`width`),c=yo(o,`padding`);t=e.width-c.width-s.width,n=e.height-c.height-s.height,r=ho(o.maxWidth,a,`clientWidth`),i=ho(o.maxHeight,a,`clientHeight`)}}return{width:t,height:n,maxWidth:r||ri,maxHeight:i||ri}}var wo=e=>Math.round(e*10)/10;function To(e,t,n,r){let i=go(e),a=yo(i,`margin`),o=ho(i.maxWidth,e,`clientWidth`)||ri,s=ho(i.maxHeight,e,`clientHeight`)||ri,c=Co(e,t,n),{width:l,height:u}=c;if(i.boxSizing===`content-box`){let e=yo(i,`border`,`width`),t=yo(i,`padding`);l-=t.width+e.width,u-=t.height+e.height}return l=Math.max(0,l-a.width),u=Math.max(0,r?l/r:u-a.height),l=wo(Math.min(l,o,c.maxWidth)),u=wo(Math.min(u,s,c.maxHeight)),l&&!u&&(u=wo(l/2)),(t!==void 0||n!==void 0)&&r&&c.height&&u>c.height&&(u=c.height,l=wo(Math.floor(u*r))),{width:l,height:u}}function Eo(e,t,n){let r=t||1,i=wo(e.height*r),a=wo(e.width*r);e.height=wo(e.height),e.width=wo(e.width);let o=e.canvas;return o.style&&(n||!o.style.height&&!o.style.width)&&(o.style.height=`${e.height}px`,o.style.width=`${e.width}px`),e.currentDevicePixelRatio!==r||o.height!==i||o.width!==a?(e.currentDevicePixelRatio=r,o.height=i,o.width=a,e.ctx.setTransform(r,0,0,r,0,0),!0):!1}var Do=function(){let e=!1;try{let t={get passive(){return e=!0,!1}};po()&&(window.addEventListener(`test`,null,t),window.removeEventListener(`test`,null,t))}catch{}return e}();function Oo(e,t){let n=_o(e,t),r=n&&n.match(/^(\d+)(\.\d+)?px$/);return r?+r[1]:void 0}function ko(e,t,n,r){return{x:e.x+n*(t.x-e.x),y:e.y+n*(t.y-e.y)}}function Ao(e,t,n,r){return{x:e.x+n*(t.x-e.x),y:r===`middle`?n<.5?e.y:t.y:r===`after`?n<1?e.y:t.y:n>0?t.y:e.y}}function jo(e,t,n,r){let i={x:e.cp2x,y:e.cp2y},a={x:t.cp1x,y:t.cp1y},o=ko(e,i,n),s=ko(i,a,n),c=ko(a,t,n);return ko(ko(o,s,n),ko(s,c,n),n)}var Mo=function(e,t){return{x(n){return e+e+t-n},setWidth(e){t=e},textAlign(e){return e===`center`?e:e===`right`?`left`:`right`},xPlus(e,t){return e-t},leftForLtr(e,t){return e-t}}},No=function(){return{x(e){return e},setWidth(e){},textAlign(e){return e},xPlus(e,t){return e+t},leftForLtr(e,t){return e}}};function Po(e,t,n){return e?Mo(t,n):No()}function Fo(e,t){let n,r;(t===`ltr`||t===`rtl`)&&(n=e.canvas.style,r=[n.getPropertyValue(`direction`),n.getPropertyPriority(`direction`)],n.setProperty(`direction`,t,`important`),e.prevTextDirection=r)}function Io(e,t){t!==void 0&&(delete e.prevTextDirection,e.canvas.style.setProperty(`direction`,t[0],t[1]))}function Lo(e){return e===`angle`?{between:Si,compare:xi,normalize:q}:{between:wi,compare:(e,t)=>e-t,normalize:e=>e}}function Ro({start:e,end:t,count:n,loop:r,style:i}){return{start:e%n,end:t%n,loop:r&&(t-e+1)%n===0,style:i}}function zo(e,t,n){let{property:r,start:i,end:a}=n,{between:o,normalize:s}=Lo(r),c=t.length,{start:l,end:u,loop:d}=e,f,p;if(d){for(l+=c,u+=c,f=0,p=c;f<p&&o(s(t[l%c][r]),i,a);++f)l--,u--;l%=c,u%=c}return u<l&&(u+=c),{start:l,end:u,loop:d,style:e.style}}function Bo(e,t,n){if(!n)return[e];let{property:r,start:i,end:a}=n,o=t.length,{compare:s,between:c,normalize:l}=Lo(r),{start:u,end:d,loop:f,style:p}=zo(e,t,n),m=[],h=!1,g=null,_,v,y,b=()=>c(i,y,_)&&s(i,y)!==0,x=()=>s(a,_)===0||c(a,y,_),S=()=>h||b(),C=()=>!h||x();for(let e=u,n=u;e<=d;++e)v=t[e%o],!v.skip&&(_=l(v[r]),_!==y&&(h=c(_,i,a),g===null&&S()&&(g=s(_,i)===0?e:n),g!==null&&C()&&(m.push(Ro({start:g,end:e,loop:f,count:o,style:p})),g=null),n=e,y=_));return g!==null&&m.push(Ro({start:g,end:d,loop:f,count:o,style:p})),m}function Vo(e,t){let n=[],r=e.segments;for(let i=0;i<r.length;i++){let a=Bo(r[i],e.points,t);a.length&&n.push(...a)}return n}function Ho(e,t,n,r){let i=0,a=t-1;if(n&&!r)for(;i<t&&!e[i].skip;)i++;for(;i<t&&e[i].skip;)i++;for(i%=t,n&&(a+=i);a>i&&e[a%t].skip;)a--;return a%=t,{start:i,end:a}}function Uo(e,t,n,r){let i=e.length,a=[],o=t,s=e[t],c;for(c=t+1;c<=n;++c){let n=e[c%i];n.skip||n.stop?s.skip||(r=!1,a.push({start:t%i,end:(c-1)%i,loop:r}),t=o=n.stop?c:null):(o=c,s.skip&&(t=c)),s=n}return o!==null&&a.push({start:t%i,end:o%i,loop:r}),a}function Wo(e,t){let n=e.points,r=e.options.spanGaps,i=n.length;if(!i)return[];let a=!!e._loop,{start:o,end:s}=Ho(n,i,a,r);return r===!0?Go(e,[{start:o,end:s,loop:a}],n,t):Go(e,Uo(n,o,s<o?s+i:s,!!e._fullLoop&&o===0&&s===i-1),n,t)}function Go(e,t,n,r){return!r||!r.setContext||!n?t:Ko(e,t,n,r)}function Ko(e,t,n,r){let i=e._chart.getContext(),a=qo(e.options),{_datasetIndex:o,options:{spanGaps:s}}=e,c=n.length,l=[],u=a,d=t[0].start,f=d;function p(e,t,r,i){let a=s?-1:1;if(e!==t){for(e+=c;n[e%c].skip;)e-=a;for(;n[t%c].skip;)t+=a;e%c!==t%c&&(l.push({start:e%c,end:t%c,loop:r,style:i}),u=i,d=t%c)}}for(let e of t){d=s?d:e.start;let t=n[d%c],a;for(f=d+1;f<=e.end;f++){let s=n[f%c];a=qo(r.setContext(Fa(i,{type:`segment`,p0:t,p1:s,p0DataIndex:(f-1)%c,p1DataIndex:f%c,datasetIndex:o}))),Jo(a,u)&&p(d,f-1,e.loop,u),t=s,u=a}d<f-1&&p(d,f-1,e.loop,u)}return l}function qo(e){return{backgroundColor:e.backgroundColor,borderCapStyle:e.borderCapStyle,borderDash:e.borderDash,borderDashOffset:e.borderDashOffset,borderJoinStyle:e.borderJoinStyle,borderWidth:e.borderWidth,borderColor:e.borderColor}}function Jo(e,t){if(!t)return!1;let n=[],r=function(e,t){return Gi(t)?(n.includes(t)||n.push(t),n.indexOf(t)):t};return JSON.stringify(e,r)!==JSON.stringify(t,r)}function Yo(e,t,n){return e.options.clip?e[n]:t[n]}function Xo(e,t){let{xScale:n,yScale:r}=e;return n&&r?{left:Yo(n,t,`left`),right:Yo(n,t,`right`),top:Yo(r,t,`top`),bottom:Yo(r,t,`bottom`)}:t}function Zo(e,t){let n=t._clip;if(n.disabled)return!1;let r=Xo(t,e.chartArea);return{left:n.left===!1?0:r.left-(n.left===!0?0:n.left),right:n.right===!1?e.width:r.right+(n.right===!0?0:n.right),top:n.top===!1?0:r.top-(n.top===!0?0:n.top),bottom:n.bottom===!1?e.height:r.bottom+(n.bottom===!0?0:n.bottom)}}var Qo=new class{constructor(){this._request=null,this._charts=new Map,this._running=!1,this._lastDate=void 0}_notify(e,t,n,r){let i=t.listeners[r],a=t.duration;i.forEach(r=>r({chart:e,initial:t.initial,numSteps:a,currentStep:Math.min(n-t.start,a)}))}_refresh(){this._request||=(this._running=!0,Ni.call(window,()=>{this._update(),this._request=null,this._running&&this._refresh()}))}_update(e=Date.now()){let t=0;this._charts.forEach((n,r)=>{if(!n.running||!n.items.length)return;let i=n.items,a=i.length-1,o=!1,s;for(;a>=0;--a)s=i[a],s._active?(s._total>n.duration&&(n.duration=s._total),s.tick(e),o=!0):(i[a]=i[i.length-1],i.pop());o&&(r.draw(),this._notify(r,n,e,`progress`)),i.length||(n.running=!1,this._notify(r,n,e,`complete`),n.initial=!1),t+=i.length}),this._lastDate=e,t===0&&(this._running=!1)}_getAnims(e){let t=this._charts,n=t.get(e);return n||(n={running:!1,initial:!0,items:[],listeners:{complete:[],progress:[]}},t.set(e,n)),n}listen(e,t,n){this._getAnims(e).listeners[t].push(n)}add(e,t){!t||!t.length||this._getAnims(e).items.push(...t)}has(e){return this._getAnims(e).items.length>0}start(e){let t=this._charts.get(e);t&&(t.running=!0,t.start=Date.now(),t.duration=t.items.reduce((e,t)=>Math.max(e,t._duration),0),this._refresh())}running(e){if(!this._running)return!1;let t=this._charts.get(e);return!(!t||!t.running||!t.items.length)}stop(e){let t=this._charts.get(e);if(!t||!t.items.length)return;let n=t.items,r=n.length-1;for(;r>=0;--r)n[r].cancel();t.items=[],this._notify(e,t,Date.now(),`complete`)}remove(e){return this._charts.delete(e)}},$o=`transparent`,es={boolean(e,t,n){return n>.5?t:e},color(e,t,n){let r=Ki(e||$o),i=r.valid&&Ki(t||$o);return i&&i.valid?i.mix(r,n).hexString():t},number(e,t,n){return e+(t-e)*n}},ts=class{constructor(e,t,n,r){let i=t[n];r=Na([e.to,r,i,e.from]);let a=Na([e.from,i,r]);this._active=!0,this._fn=e.fn||es[e.type||typeof a],this._easing=Wi[e.easing]||Wi.linear,this._start=Math.floor(Date.now()+(e.delay||0)),this._duration=this._total=Math.floor(e.duration),this._loop=!!e.loop,this._target=t,this._prop=n,this._from=a,this._to=r,this._promises=void 0}active(){return this._active}update(e,t,n){if(this._active){this._notify(!1);let r=this._target[this._prop],i=n-this._start,a=this._duration-i;this._start=n,this._duration=Math.floor(Math.max(a,e.duration)),this._total+=i,this._loop=!!e.loop,this._to=Na([e.to,t,r,e.from]),this._from=Na([e.from,r,t])}}cancel(){this._active&&(this.tick(Date.now()),this._active=!1,this._notify(!1))}tick(e){let t=e-this._start,n=this._duration,r=this._prop,i=this._from,a=this._loop,o=this._to,s;if(this._active=i!==o&&(a||t<n),!this._active){this._target[r]=o,this._notify(!0);return}if(t<0){this._target[r]=i;return}s=t/n%2,s=a&&s>1?2-s:s,s=this._easing(Math.min(1,Math.max(0,s))),this._target[r]=this._fn(i,o,s)}wait(){let e=this._promises||=[];return new Promise((t,n)=>{e.push({res:t,rej:n})})}_notify(e){let t=e?`res`:`rej`,n=this._promises||[];for(let e=0;e<n.length;e++)n[e][t]()}},ns=class{constructor(e,t){this._chart=e,this._properties=new Map,this.configure(t)}configure(e){if(!z(e))return;let t=Object.keys(Y.animation),n=this._properties;Object.getOwnPropertyNames(e).forEach(r=>{let i=e[r];if(!z(i))return;let a={};for(let e of t)a[e]=i[e];(R(i.properties)&&i.properties||[r]).forEach(e=>{(e===r||!n.has(e))&&n.set(e,a)})})}_animateOptions(e,t){let n=t.options,r=is(e,n);if(!r)return[];let i=this._createAnimations(r,n);return n.$shared&&rs(e.options.$animations,n).then(()=>{e.options=n},()=>{}),i}_createAnimations(e,t){let n=this._properties,r=[],i=e.$animations||={},a=Object.keys(t),o=Date.now(),s;for(s=a.length-1;s>=0;--s){let c=a[s];if(c.charAt(0)===`$`)continue;if(c===`options`){r.push(...this._animateOptions(e,t));continue}let l=t[c],u=i[c],d=n.get(c);if(u)if(d&&u.active()){u.update(d,l,o);continue}else u.cancel();if(!d||!d.duration){e[c]=l;continue}i[c]=u=new ts(d,e,c,l),r.push(u)}return r}update(e,t){if(this._properties.size===0){Object.assign(e,t);return}let n=this._createAnimations(e,t);if(n.length)return Qo.add(this._chart,n),!0}};function rs(e,t){let n=[],r=Object.keys(t);for(let t=0;t<r.length;t++){let i=e[r[t]];i&&i.active()&&n.push(i.wait())}return Promise.all(n)}function is(e,t){if(!t)return;let n=e.options;if(!n){e.options=t;return}return n.$shared&&(e.options=n=Object.assign({},n,{$shared:!1,$animations:{}})),n}function as(e,t){let n=e&&e.options||{},r=n.reverse,i=n.min===void 0?t:0,a=n.max===void 0?t:0;return{start:r?a:i,end:r?i:a}}function os(e,t,n){if(n===!1)return!1;let r=as(e,n),i=as(t,n);return{top:i.end,right:r.end,bottom:i.start,left:r.start}}function ss(e){let t,n,r,i;return z(e)?(t=e.top,n=e.right,r=e.bottom,i=e.left):t=n=r=i=e,{top:t,right:n,bottom:r,left:i,disabled:e===!1}}function cs(e,t){let n=[],r=e._getSortedDatasetMetas(t),i,a;for(i=0,a=r.length;i<a;++i)n.push(r[i].index);return n}function ls(e,t,n,r={}){let i=e.keys,a=r.mode===`single`,o,s,c,l;if(t===null)return;let u=!1;for(o=0,s=i.length;o<s;++o){if(c=+i[o],c===n){if(u=!0,r.all)continue;break}l=e.values[c],B(l)&&(a||t===0||ci(t)===ci(l))&&(t+=l)}return!u&&!r.all?0:t}function us(e,t){let{iScale:n,vScale:r}=t,i=n.axis===`x`?`x`:`y`,a=r.axis===`x`?`x`:`y`,o=Object.keys(e),s=Array(o.length),c,l,u;for(c=0,l=o.length;c<l;++c)u=o[c],s[c]={[i]:u,[a]:e[u]};return s}function ds(e,t){let n=e&&e.options.stacked;return n||n===void 0&&t.stack!==void 0}function fs(e,t,n){return`${e.id}.${t.id}.${n.stack||n.type}`}function ps(e){let{min:t,max:n,minDefined:r,maxDefined:i}=e.getUserBounds();return{min:r?t:-1/0,max:i?n:1/0}}function ms(e,t,n){let r=e[t]||(e[t]={});return r[n]||(r[n]={})}function hs(e,t,n,r){for(let i of t.getMatchingVisibleMetas(r).reverse()){let t=e[i.index];if(n&&t>0||!n&&t<0)return i.index}return null}function gs(e,t){let{chart:n,_cachedMeta:r}=e,i=n._stacks||={},{iScale:a,vScale:o,index:s}=r,c=a.axis,l=o.axis,u=fs(a,o,r),d=t.length,f;for(let e=0;e<d;++e){let n=t[e],{[c]:a,[l]:d}=n,p=n._stacks||={};f=p[l]=ms(i,u,a),f[s]=d,f._top=hs(f,o,!0,r.type),f._bottom=hs(f,o,!1,r.type);let m=f._visualValues||={};m[s]=d}}function _s(e,t){let n=e.scales;return Object.keys(n).filter(e=>n[e].axis===t).shift()}function vs(e,t){return Fa(e,{active:!1,dataset:void 0,datasetIndex:t,index:t,mode:`default`,type:`dataset`})}function ys(e,t,n){return Fa(e,{active:!1,dataIndex:t,parsed:void 0,raw:void 0,element:n,index:t,mode:`default`,type:`data`})}function bs(e,t){let n=e.controller.index,r=e.vScale&&e.vScale.axis;if(r){t||=e._parsed;for(let e of t){let t=e._stacks;if(!t||t[r]===void 0||t[r][n]===void 0)return;delete t[r][n],t[r]._visualValues!==void 0&&t[r]._visualValues[n]!==void 0&&delete t[r]._visualValues[n]}}}var xs=e=>e===`reset`||e===`none`,Ss=(e,t)=>t?e:Object.assign({},e),Cs=(e,t,n)=>e&&!t.hidden&&t._stacked&&{keys:cs(n,!0),values:null},ws=class{constructor(e,t){this.chart=e,this._ctx=e.ctx,this.index=t,this._cachedDataOpts={},this._cachedMeta=this.getMeta(),this._type=this._cachedMeta.type,this.options=void 0,this._parsing=!1,this._data=void 0,this._objectData=void 0,this._sharedOptions=void 0,this._drawStart=void 0,this._drawCount=void 0,this.enableOptionSharing=!1,this.supportsDecimation=!1,this.$context=void 0,this._syncList=[],this.datasetElementType=new.target.datasetElementType,this.dataElementType=new.target.dataElementType,this.initialize()}initialize(){let e=this._cachedMeta;this.configure(),this.linkScales(),e._stacked=ds(e.vScale,e),this.addElements(),this.options.fill&&!this.chart.isPluginEnabled(`filler`)&&console.warn(`Tried to use the 'fill' option without the 'Filler' plugin enabled. Please import and register the 'Filler' plugin and make sure it is not disabled in the options`)}updateIndex(e){this.index!==e&&bs(this._cachedMeta),this.index=e}linkScales(){let e=this.chart,t=this._cachedMeta,n=this.getDataset(),r=(e,t,n,r)=>e===`x`?t:e===`r`?r:n,i=t.xAxisID=V(n.xAxisID,_s(e,`x`)),a=t.yAxisID=V(n.yAxisID,_s(e,`y`)),o=t.rAxisID=V(n.rAxisID,_s(e,`r`)),s=t.indexAxis,c=t.iAxisID=r(s,i,a,o),l=t.vAxisID=r(s,a,i,o);t.xScale=this.getScaleForId(i),t.yScale=this.getScaleForId(a),t.rScale=this.getScaleForId(o),t.iScale=this.getScaleForId(c),t.vScale=this.getScaleForId(l)}getDataset(){return this.chart.data.datasets[this.index]}getMeta(){return this.chart.getDatasetMeta(this.index)}getScaleForId(e){return this.chart.scales[e]}_getOtherScale(e){let t=this._cachedMeta;return e===t.iScale?t.vScale:t.iScale}reset(){this._update(`reset`)}_destroy(){let e=this._cachedMeta;this._data&&ji(this._data,this),e._stacked&&bs(e)}_dataCheck(){let e=this.getDataset(),t=e.data||=[],n=this._data;if(z(t)){let e=this._cachedMeta;this._data=us(t,e)}else if(n!==t){if(n){ji(n,this);let e=this._cachedMeta;bs(e),e._parsed=[]}t&&Object.isExtensible(t)&&Ai(t,this),this._syncList=[],this._data=t}}addElements(){let e=this._cachedMeta;this._dataCheck(),this.datasetElementType&&(e.dataset=new this.datasetElementType)}buildOrUpdateElements(e){let t=this._cachedMeta,n=this.getDataset(),r=!1;this._dataCheck();let i=t._stacked;t._stacked=ds(t.vScale,t),t.stack!==n.stack&&(r=!0,bs(t),t.stack=n.stack),this._resyncElements(e),(r||i!==t._stacked)&&(gs(this,t._parsed),t._stacked=ds(t.vScale,t))}configure(){let e=this.chart.config,t=e.datasetScopeKeys(this._type),n=e.getOptionScopes(this.getDataset(),t,!0);this.options=e.createResolver(n,this.getContext()),this._parsing=this.options.parsing,this._cachedDataOpts={}}parse(e,t){let{_cachedMeta:n,_data:r}=this,{iScale:i,_stacked:a}=n,o=i.axis,s=e===0&&t===r.length?!0:n._sorted,c=e>0&&n._parsed[e-1],l,u,d;if(this._parsing===!1)n._parsed=r,n._sorted=!0,d=r;else{d=R(r[e])?this.parseArrayData(n,r,e,t):z(r[e])?this.parseObjectData(n,r,e,t):this.parsePrimitiveData(n,r,e,t);let i=()=>u[o]===null||c&&u[o]<c[o];for(l=0;l<t;++l)n._parsed[l+e]=u=d[l],s&&(i()&&(s=!1),c=u);n._sorted=s}a&&gs(this,d)}parsePrimitiveData(e,t,n,r){let{iScale:i,vScale:a}=e,o=i.axis,s=a.axis,c=i.getLabels(),l=i===a,u=Array(r),d,f,p;for(d=0,f=r;d<f;++d)p=d+n,u[d]={[o]:l||i.parse(c[p],p),[s]:a.parse(t[p],p)};return u}parseArrayData(e,t,n,r){let{xScale:i,yScale:a}=e,o=Array(r),s,c,l,u;for(s=0,c=r;s<c;++s)l=s+n,u=t[l],o[s]={x:i.parse(u[0],l),y:a.parse(u[1],l)};return o}parseObjectData(e,t,n,r){let{xScale:i,yScale:a}=e,{xAxisKey:o=`x`,yAxisKey:s=`y`}=this._parsing,c=Array(r),l,u,d,f;for(l=0,u=r;l<u;++l)d=l+n,f=t[d],c[l]={x:i.parse(Xr(f,o),d),y:a.parse(Xr(f,s),d)};return c}getParsed(e){return this._cachedMeta._parsed[e]}getDataElement(e){return this._cachedMeta.data[e]}applyStack(e,t,n){let r=this.chart,i=this._cachedMeta,a=t[e.axis];return ls({keys:cs(r,!0),values:t._stacks[e.axis]._visualValues},a,i.index,{mode:n})}updateRangeFromParsed(e,t,n,r){let i=n[t.axis],a=i===null?NaN:i,o=r&&n._stacks[t.axis];r&&o&&(r.values=o,a=ls(r,i,this._cachedMeta.index)),e.min=Math.min(e.min,a),e.max=Math.max(e.max,a)}getMinMax(e,t){let n=this._cachedMeta,r=n._parsed,i=n._sorted&&e===n.iScale,a=r.length,o=this._getOtherScale(e),s=Cs(t,n,this.chart),c={min:1/0,max:-1/0},{min:l,max:u}=ps(o),d,f;function p(){f=r[d];let t=f[o.axis];return!B(f[e.axis])||l>t||u<t}for(d=0;d<a&&!(!p()&&(this.updateRangeFromParsed(c,e,f,s),i));++d);if(i){for(d=a-1;d>=0;--d)if(!p()){this.updateRangeFromParsed(c,e,f,s);break}}return c}getAllParsedValues(e){let t=this._cachedMeta._parsed,n=[],r,i,a;for(r=0,i=t.length;r<i;++r)a=t[r][e.axis],B(a)&&n.push(a);return n}getMaxOverflow(){return!1}getLabelAndValue(e){let t=this._cachedMeta,n=t.iScale,r=t.vScale,i=this.getParsed(e);return{label:n?``+n.getLabelForValue(i[n.axis]):``,value:r?``+r.getLabelForValue(i[r.axis]):``}}_update(e){let t=this._cachedMeta;this.update(e||`default`),t._clip=ss(V(this.options.clip,os(t.xScale,t.yScale,this.getMaxOverflow())))}update(e){}draw(){let e=this._ctx,t=this.chart,n=this._cachedMeta,r=n.data||[],i=t.chartArea,a=[],o=this._drawStart||0,s=this._drawCount||r.length-o,c=this.options.drawActiveElementsOnTop,l;for(n.dataset&&n.dataset.draw(e,i,o,s),l=o;l<o+s;++l){let t=r[l];t.hidden||(t.active&&c?a.push(t):t.draw(e,i))}for(l=0;l<a.length;++l)a[l].draw(e,i)}getStyle(e,t){let n=t?`active`:`default`;return e===void 0&&this._cachedMeta.dataset?this.resolveDatasetElementOptions(n):this.resolveDataElementOptions(e||0,n)}getContext(e,t,n){let r=this.getDataset(),i;if(e>=0&&e<this._cachedMeta.data.length){let t=this._cachedMeta.data[e];i=t.$context||=ys(this.getContext(),e,t),i.parsed=this.getParsed(e),i.raw=r.data[e],i.index=i.dataIndex=e}else i=this.$context||=vs(this.chart.getContext(),this.index),i.dataset=r,i.index=i.datasetIndex=this.index;return i.active=!!t,i.mode=n,i}resolveDatasetElementOptions(e){return this._resolveElementOptions(this.datasetElementType.id,e)}resolveDataElementOptions(e,t){return this._resolveElementOptions(this.dataElementType.id,t,e)}_resolveElementOptions(e,t=`default`,n){let r=t===`active`,i=this._cachedDataOpts,a=e+`-`+t,o=i[a],s=this.enableOptionSharing&&Qr(n);if(o)return Ss(o,s);let c=this.chart.config,l=c.datasetElementScopeKeys(this._type,e),u=r?[`${e}Hover`,`hover`,e,``]:[e,``],d=c.getOptionScopes(this.getDataset(),l),f=Object.keys(Y.elements[e]),p=c.resolveNamedOptions(d,f,()=>this.getContext(n,r,t),u);return p.$shared&&(p.$shared=s,i[a]=Object.freeze(Ss(p,s))),p}_resolveAnimations(e,t,n){let r=this.chart,i=this._cachedDataOpts,a=`animation-${t}`,o=i[a];if(o)return o;let s;if(r.options.animation!==!1){let r=this.chart.config,i=r.datasetAnimationScopeKeys(this._type,t),a=r.getOptionScopes(this.getDataset(),i);s=r.createResolver(a,this.getContext(e,n,t))}let c=new ns(r,s&&s.animations);return s&&s._cacheable&&(i[a]=Object.freeze(c)),c}getSharedOptions(e){if(e.$shared)return this._sharedOptions||=Object.assign({},e)}includeOptions(e,t){return!t||xs(e)||this.chart._animationsDisabled}_getSharedOptions(e,t){let n=this.resolveDataElementOptions(e,t),r=this._sharedOptions,i=this.getSharedOptions(n),a=this.includeOptions(t,i)||i!==r;return this.updateSharedOptions(i,t,n),{sharedOptions:i,includeOptions:a}}updateElement(e,t,n,r){xs(r)?Object.assign(e,n):this._resolveAnimations(t,r).update(e,n)}updateSharedOptions(e,t,n){e&&!xs(t)&&this._resolveAnimations(void 0,t).update(e,n)}_setStyle(e,t,n,r){e.active=r;let i=this.getStyle(t,r);this._resolveAnimations(t,n,r).update(e,{options:!r&&this.getSharedOptions(i)||i})}removeHoverStyle(e,t,n){this._setStyle(e,n,`active`,!1)}setHoverStyle(e,t,n){this._setStyle(e,n,`active`,!0)}_removeDatasetHoverStyle(){let e=this._cachedMeta.dataset;e&&this._setStyle(e,void 0,`active`,!1)}_setDatasetHoverStyle(){let e=this._cachedMeta.dataset;e&&this._setStyle(e,void 0,`active`,!0)}_resyncElements(e){let t=this._data,n=this._cachedMeta.data;for(let[e,t,n]of this._syncList)this[e](t,n);this._syncList=[];let r=n.length,i=t.length,a=Math.min(i,r);a&&this.parse(0,a),i>r?this._insertElements(r,i-r,e):i<r&&this._removeElements(i,r-i)}_insertElements(e,t,n=!0){let r=this._cachedMeta,i=r.data,a=e+t,o,s=e=>{for(e.length+=t,o=e.length-1;o>=a;o--)e[o]=e[o-t]};for(s(i),o=e;o<a;++o)i[o]=new this.dataElementType;this._parsing&&s(r._parsed),this.parse(e,t),n&&this.updateElements(i,e,t,`reset`)}updateElements(e,t,n,r){}_removeElements(e,t){let n=this._cachedMeta;if(this._parsing){let r=n._parsed.splice(e,t);n._stacked&&bs(n,r)}n.data.splice(e,t)}_sync(e){if(this._parsing)this._syncList.push(e);else{let[t,n,r]=e;this[t](n,r)}this.chart._dataChanges.push([this.index,...e])}_onDataPush(){let e=arguments.length;this._sync([`_insertElements`,this.getDataset().data.length-e,e])}_onDataPop(){this._sync([`_removeElements`,this._cachedMeta.data.length-1,1])}_onDataShift(){this._sync([`_removeElements`,0,1])}_onDataSplice(e,t){t&&this._sync([`_removeElements`,e,t]);let n=arguments.length-2;n&&this._sync([`_insertElements`,e,n])}_onDataUnshift(){this._sync([`_insertElements`,0,arguments.length])}};f(ws,`defaults`,{}),f(ws,`datasetElementType`,null),f(ws,`dataElementType`,null);function Ts(e,t){if(!e._cache.$bar){let n=e.getMatchingVisibleMetas(t),r=[];for(let t=0,i=n.length;t<i;t++)r=r.concat(n[t].controller.getAllParsedValues(e));e._cache.$bar=Mi(r.sort((e,t)=>e-t))}return e._cache.$bar}function Es(e){let t=e.iScale,n=Ts(t,e.type),r=t._length,i,a,o,s,c=()=>{o===32767||o===-32768||(Qr(s)&&(r=Math.min(r,Math.abs(o-s)||r)),s=o)};for(i=0,a=n.length;i<a;++i)o=t.getPixelForValue(n[i]),c();for(s=void 0,i=0,a=t.ticks.length;i<a;++i)o=t.getPixelForTick(i),c();return r}function Ds(e,t,n,r){let i=n.barThickness,a,o;return L(i)?(a=t.min*n.categoryPercentage,o=n.barPercentage):(a=i*r,o=1),{chunk:a/r,ratio:o,start:t.pixels[e]-a/2}}function Os(e,t,n,r){let i=t.pixels,a=i[e],o=e>0?i[e-1]:null,s=e<i.length-1?i[e+1]:null,c=n.categoryPercentage;o===null&&(o=a-(s===null?t.end-t.start:s-a)),s===null&&(s=a+a-o);let l=a-(a-Math.min(o,s))/2*c;return{chunk:Math.abs(s-o)/2*c/r,ratio:n.barPercentage,start:l}}function ks(e,t,n,r){let i=n.parse(e[0],r),a=n.parse(e[1],r),o=Math.min(i,a),s=Math.max(i,a),c=o,l=s;Math.abs(o)>Math.abs(s)&&(c=s,l=o),t[n.axis]=l,t._custom={barStart:c,barEnd:l,start:i,end:a,min:o,max:s}}function As(e,t,n,r){return R(e)?ks(e,t,n,r):t[n.axis]=n.parse(e,r),t}function js(e,t,n,r){let i=e.iScale,a=e.vScale,o=i.getLabels(),s=i===a,c=[],l,u,d,f;for(l=n,u=n+r;l<u;++l)f=t[l],d={},d[i.axis]=s||i.parse(o[l],l),c.push(As(f,d,a,l));return c}function Ms(e){return e&&e.barStart!==void 0&&e.barEnd!==void 0}function Ns(e,t,n){return e===0?(t.isHorizontal()?1:-1)*(t.min>=n?1:-1):ci(e)}function Ps(e){let t,n,r,i,a;return e.horizontal?(t=e.base>e.x,n=`left`,r=`right`):(t=e.base<e.y,n=`bottom`,r=`top`),t?(i=`end`,a=`start`):(i=`start`,a=`end`),{start:n,end:r,reverse:t,top:i,bottom:a}}function Fs(e,t,n,r){let i=t.borderSkipped,a={};if(!i){e.borderSkipped=a;return}if(i===!0){e.borderSkipped={top:!0,right:!0,bottom:!0,left:!0};return}let{start:o,end:s,reverse:c,top:l,bottom:u}=Ps(e);i===`middle`&&n&&(e.enableBorderRadius=!0,(n._top||0)===r?i=l:(n._bottom||0)===r?i=u:(a[Is(u,o,s,c)]=!0,i=l)),a[Is(i,o,s,c)]=!0,e.borderSkipped=a}function Is(e,t,n,r){return r?(e=Ls(e,t,n),e=Rs(e,n,t)):e=Rs(e,t,n),e}function Ls(e,t,n){return e===t?n:e===n?t:e}function Rs(e,t,n){return e===`start`?t:e===`end`?n:e}function zs(e,{inflateAmount:t},n){e.inflateAmount=t===`auto`?n===1?.33:0:t}var Bs=class extends ws{parsePrimitiveData(e,t,n,r){return js(e,t,n,r)}parseArrayData(e,t,n,r){return js(e,t,n,r)}parseObjectData(e,t,n,r){let{iScale:i,vScale:a}=e,{xAxisKey:o=`x`,yAxisKey:s=`y`}=this._parsing,c=i.axis===`x`?o:s,l=a.axis===`x`?o:s,u=[],d,f,p,m;for(d=n,f=n+r;d<f;++d)m=t[d],p={},p[i.axis]=i.parse(Xr(m,c),d),u.push(As(Xr(m,l),p,a,d));return u}updateRangeFromParsed(e,t,n,r){super.updateRangeFromParsed(e,t,n,r);let i=n._custom;i&&t===this._cachedMeta.vScale&&(e.min=Math.min(e.min,i.min),e.max=Math.max(e.max,i.max))}getMaxOverflow(){return 0}getLabelAndValue(e){let{iScale:t,vScale:n}=this._cachedMeta,r=this.getParsed(e),i=r._custom,a=Ms(i)?`[`+i.start+`, `+i.end+`]`:``+n.getLabelForValue(r[n.axis]);return{label:``+t.getLabelForValue(r[t.axis]),value:a}}initialize(){this.enableOptionSharing=!0,super.initialize();let e=this._cachedMeta;e.stack=this.getDataset().stack}update(e){let t=this._cachedMeta;this.updateElements(t.data,0,t.data.length,e)}updateElements(e,t,n,r){let i=r===`reset`,{index:a,_cachedMeta:{vScale:o}}=this,s=o.getBasePixel(),c=o.isHorizontal(),l=this._getRuler(),{sharedOptions:u,includeOptions:d}=this._getSharedOptions(t,r);for(let f=t;f<t+n;f++){let t=this.getParsed(f),n=i||L(t[o.axis])?{base:s,head:s}:this._calculateBarValuePixels(f),p=this._calculateBarIndexPixels(f,l),m=(t._stacks||{})[o.axis],h={horizontal:c,base:n.base,enableBorderRadius:!m||Ms(t._custom)||a===m._top||a===m._bottom,x:c?n.head:p.center,y:c?p.center:n.head,height:c?p.size:Math.abs(n.size),width:c?Math.abs(n.size):p.size};d&&(h.options=u||this.resolveDataElementOptions(f,e[f].active?`active`:r));let g=h.options||e[f].options;Fs(h,g,m,a),zs(h,g,l.ratio),this.updateElement(e[f],f,h,r)}}_getStacks(e,t){let{iScale:n}=this._cachedMeta,r=n.getMatchingVisibleMetas(this._type).filter(e=>e.controller.options.grouped),i=n.options.stacked,a=[],o=this._cachedMeta.controller.getParsed(t),s=o&&o[n.axis],c=e=>{let t=e._parsed.find(e=>e[n.axis]===s),r=t&&t[e.vScale.axis];if(L(r)||isNaN(r))return!0};for(let n of r)if(!(t!==void 0&&c(n))&&((i===!1||a.indexOf(n.stack)===-1||i===void 0&&n.stack===void 0)&&a.push(n.stack),n.index===e))break;return a.length||a.push(void 0),a}_getStackCount(e){return this._getStacks(void 0,e).length}_getAxisCount(){return this._getAxis().length}getFirstScaleIdForIndexAxis(){let e=this.chart.scales,t=this.chart.options.indexAxis;return Object.keys(e).filter(n=>e[n].axis===t).shift()}_getAxis(){let e={},t=this.getFirstScaleIdForIndexAxis();for(let n of this.chart.data.datasets)e[V(this.chart.options.indexAxis===`x`?n.xAxisID:n.yAxisID,t)]=!0;return Object.keys(e)}_getStackIndex(e,t,n){let r=this._getStacks(e,n),i=t===void 0?-1:r.indexOf(t);return i===-1?r.length-1:i}_getRuler(){let e=this.options,t=this._cachedMeta,n=t.iScale,r=[],i,a;for(i=0,a=t.data.length;i<a;++i)r.push(n.getPixelForValue(this.getParsed(i)[n.axis],i));let o=e.barThickness;return{min:o||Es(t),pixels:r,start:n._startPixel,end:n._endPixel,stackCount:this._getStackCount(),scale:n,grouped:e.grouped,ratio:o?1:e.categoryPercentage*e.barPercentage}}_calculateBarValuePixels(e){let{_cachedMeta:{vScale:t,_stacked:n,index:r},options:{base:i,minBarLength:a}}=this,o=i||0,s=this.getParsed(e),c=s._custom,l=Ms(c),u=s[t.axis],d=0,f=n?this.applyStack(t,s,n):u,p,m;f!==u&&(d=f-u,f=u),l&&(u=c.barStart,f=c.barEnd-c.barStart,u!==0&&ci(u)!==ci(c.barEnd)&&(d=0),d+=u);let h=!L(i)&&!l?i:d,g=t.getPixelForValue(h);if(p=this.chart.getDataVisibility(e)?t.getPixelForValue(d+f):g,m=p-g,Math.abs(m)<a){m=Ns(m,t,o)*a,u===o&&(g-=m/2);let e=t.getPixelForDecimal(0),i=t.getPixelForDecimal(1),c=Math.min(e,i),d=Math.max(e,i);g=Math.max(Math.min(g,d),c),p=g+m,n&&!l&&(s._stacks[t.axis]._visualValues[r]=t.getValueForPixel(p)-t.getValueForPixel(g))}if(g===t.getPixelForValue(o)){let e=ci(m)*t.getLineWidthForValue(o)/2;g+=e,m-=e}return{size:m,base:g,head:p,center:p+m/2}}_calculateBarIndexPixels(e,t){let n=t.scale,r=this.options,i=r.skipNull,a=V(r.maxBarThickness,1/0),o,s,c=this._getAxisCount();if(t.grouped){let n=i?this._getStackCount(e):t.stackCount,l=r.barThickness===`flex`?Os(e,t,r,n*c):Ds(e,t,r,n*c),u=this.chart.options.indexAxis===`x`?this.getDataset().xAxisID:this.getDataset().yAxisID,d=this._getAxis().indexOf(V(u,this.getFirstScaleIdForIndexAxis())),f=this._getStackIndex(this.index,this._cachedMeta.stack,i?e:void 0)+d;o=l.start+l.chunk*f+l.chunk/2,s=Math.min(a,l.chunk*l.ratio)}else o=n.getPixelForValue(this.getParsed(e)[n.axis],e),s=Math.min(a,t.min*t.ratio);return{base:o-s/2,head:o+s/2,center:o,size:s}}draw(){let e=this._cachedMeta,t=e.vScale,n=e.data,r=n.length,i=0;for(;i<r;++i)this.getParsed(i)[t.axis]!==null&&!n[i].hidden&&n[i].draw(this._ctx)}};f(Bs,`id`,`bar`),f(Bs,`defaults`,{datasetElementType:!1,dataElementType:`bar`,categoryPercentage:.8,barPercentage:.9,grouped:!0,animations:{numbers:{type:`number`,properties:[`x`,`y`,`base`,`width`,`height`]}}}),f(Bs,`overrides`,{scales:{_index_:{type:`category`,offset:!0,grid:{offset:!0}},_value_:{type:`linear`,beginAtZero:!0}}});var Vs=class extends ws{initialize(){this.enableOptionSharing=!0,super.initialize()}parsePrimitiveData(e,t,n,r){let i=super.parsePrimitiveData(e,t,n,r);for(let e=0;e<i.length;e++)i[e]._custom=this.resolveDataElementOptions(e+n).radius;return i}parseArrayData(e,t,n,r){let i=super.parseArrayData(e,t,n,r);for(let e=0;e<i.length;e++){let r=t[n+e];i[e]._custom=V(r[2],this.resolveDataElementOptions(e+n).radius)}return i}parseObjectData(e,t,n,r){let i=super.parseObjectData(e,t,n,r);for(let e=0;e<i.length;e++){let r=t[n+e];i[e]._custom=V(r&&r.r&&+r.r,this.resolveDataElementOptions(e+n).radius)}return i}getMaxOverflow(){let e=this._cachedMeta.data,t=0;for(let n=e.length-1;n>=0;--n)t=Math.max(t,e[n].size(this.resolveDataElementOptions(n))/2);return t>0&&t}getLabelAndValue(e){let t=this._cachedMeta,n=this.chart.data.labels||[],{xScale:r,yScale:i}=t,a=this.getParsed(e),o=r.getLabelForValue(a.x),s=i.getLabelForValue(a.y),c=a._custom;return{label:n[e]||``,value:`(`+o+`, `+s+(c?`, `+c:``)+`)`}}update(e){let t=this._cachedMeta.data;this.updateElements(t,0,t.length,e)}updateElements(e,t,n,r){let i=r===`reset`,{iScale:a,vScale:o}=this._cachedMeta,{sharedOptions:s,includeOptions:c}=this._getSharedOptions(t,r),l=a.axis,u=o.axis;for(let d=t;d<t+n;d++){let t=e[d],n=!i&&this.getParsed(d),f={},p=f[l]=i?a.getPixelForDecimal(.5):a.getPixelForValue(n[l]),m=f[u]=i?o.getBasePixel():o.getPixelForValue(n[u]);f.skip=isNaN(p)||isNaN(m),c&&(f.options=s||this.resolveDataElementOptions(d,t.active?`active`:r),i&&(f.options.radius=0)),this.updateElement(t,d,f,r)}}resolveDataElementOptions(e,t){let n=this.getParsed(e),r=super.resolveDataElementOptions(e,t);r.$shared&&(r=Object.assign({},r,{$shared:!1}));let i=r.radius;return t!==`active`&&(r.radius=0),r.radius+=V(n&&n._custom,i),r}};f(Vs,`id`,`bubble`),f(Vs,`defaults`,{datasetElementType:!1,dataElementType:`point`,animations:{numbers:{type:`number`,properties:[`x`,`y`,`borderWidth`,`radius`]}}}),f(Vs,`overrides`,{scales:{x:{type:`linear`},y:{type:`linear`}}});function Hs(e,t,n){let r=1,i=1,a=0,o=0;if(t<G){let s=e,c=s+t,l=Math.cos(s),u=Math.sin(s),d=Math.cos(c),f=Math.sin(c),p=(e,t,r)=>Si(e,s,c,!0)?1:Math.max(t,t*n,r,r*n),m=(e,t,r)=>Si(e,s,c,!0)?-1:Math.min(t,t*n,r,r*n),h=p(0,l,d),g=p(K,u,f),_=m(W,l,d),v=m(W+K,u,f);r=(h-_)/2,i=(g-v)/2,a=-(h+_)/2,o=-(g+v)/2}return{ratioX:r,ratioY:i,offsetX:a,offsetY:o}}var Us=class extends ws{constructor(e,t){super(e,t),this.enableOptionSharing=!0,this.innerRadius=void 0,this.outerRadius=void 0,this.offsetX=void 0,this.offsetY=void 0}linkScales(){}parse(e,t){let n=this.getDataset().data,r=this._cachedMeta;if(this._parsing===!1)r._parsed=n;else{let i=e=>+n[e];if(z(n[e])){let{key:e=`value`}=this._parsing;i=t=>+Xr(n[t],e)}let a,o;for(a=e,o=e+t;a<o;++a)r._parsed[a]=i(a)}}_getRotation(){return gi(this.options.rotation-90)}_getCircumference(){return gi(this.options.circumference)}_getRotationExtents(){let e=G,t=-G;for(let n=0;n<this.chart.data.datasets.length;++n)if(this.chart.isDatasetVisible(n)&&this.chart.getDatasetMeta(n).type===this._type){let r=this.chart.getDatasetMeta(n).controller,i=r._getRotation(),a=r._getCircumference();e=Math.min(e,i),t=Math.max(t,i+a)}return{rotation:e,circumference:t-e}}update(e){let{chartArea:t}=this.chart,n=this._cachedMeta,r=n.data,i=this.getMaxBorderWidth()+this.getMaxOffset(r)+this.options.spacing,a=Math.max((Math.min(t.width,t.height)-i)/2,0),o=Math.min(Rr(this.options.cutout,a),1),s=this._getRingWeight(this.index),{circumference:c,rotation:l}=this._getRotationExtents(),{ratioX:u,ratioY:d,offsetX:f,offsetY:p}=Hs(l,c,o),m=(t.width-i)/u,h=(t.height-i)/d,g=Math.max(Math.min(m,h)/2,0),_=zr(this.options.radius,g),v=(_-Math.max(_*o,0))/this._getVisibleDatasetWeightTotal();this.offsetX=f*_,this.offsetY=p*_,n.total=this.calculateTotal(),this.outerRadius=_-v*this._getRingWeightOffset(this.index),this.innerRadius=Math.max(this.outerRadius-v*s,0),this.updateElements(r,0,r.length,e)}_circumference(e,t){let n=this.options,r=this._cachedMeta,i=this._getCircumference();return t&&n.animation.animateRotate||!this.chart.getDataVisibility(e)||r._parsed[e]===null||r.data[e].hidden?0:this.calculateCircumference(r._parsed[e]*i/G)}updateElements(e,t,n,r){let i=r===`reset`,a=this.chart,o=a.chartArea,s=a.options.animation,c=(o.left+o.right)/2,l=(o.top+o.bottom)/2,u=i&&s.animateScale,d=u?0:this.innerRadius,f=u?0:this.outerRadius,{sharedOptions:p,includeOptions:m}=this._getSharedOptions(t,r),h=this._getRotation(),g;for(g=0;g<t;++g)h+=this._circumference(g,i);for(g=t;g<t+n;++g){let t=this._circumference(g,i),n=e[g],a={x:c+this.offsetX,y:l+this.offsetY,startAngle:h,endAngle:h+t,circumference:t,outerRadius:f,innerRadius:d};m&&(a.options=p||this.resolveDataElementOptions(g,n.active?`active`:r)),h+=t,this.updateElement(n,g,a,r)}}calculateTotal(){let e=this._cachedMeta,t=e.data,n=0,r;for(r=0;r<t.length;r++){let i=e._parsed[r];i!==null&&!isNaN(i)&&this.chart.getDataVisibility(r)&&!t[r].hidden&&(n+=Math.abs(i))}return n}calculateCircumference(e){let t=this._cachedMeta.total;return t>0&&!isNaN(e)?Math.abs(e)/t*G:0}getLabelAndValue(e){let t=this._cachedMeta,n=this.chart,r=n.data.labels||[],i=ea(t._parsed[e],n.options.locale);return{label:r[e]||``,value:i}}getMaxBorderWidth(e){let t=0,n=this.chart,r,i,a,o,s;if(!e){for(r=0,i=n.data.datasets.length;r<i;++r)if(n.isDatasetVisible(r)){a=n.getDatasetMeta(r),e=a.data,o=a.controller;break}}if(!e)return 0;for(r=0,i=e.length;r<i;++r)s=o.resolveDataElementOptions(r),s.borderAlign!==`inner`&&(t=Math.max(t,s.borderWidth||0,s.hoverBorderWidth||0));return t}getMaxOffset(e){let t=0;for(let n=0,r=e.length;n<r;++n){let e=this.resolveDataElementOptions(n);t=Math.max(t,e.offset||0,e.hoverOffset||0)}return t}_getRingWeightOffset(e){let t=0;for(let n=0;n<e;++n)this.chart.isDatasetVisible(n)&&(t+=this._getRingWeight(n));return t}_getRingWeight(e){return Math.max(V(this.chart.data.datasets[e].weight,1),0)}_getVisibleDatasetWeightTotal(){return this._getRingWeightOffset(this.chart.data.datasets.length)||1}};f(Us,`id`,`doughnut`),f(Us,`defaults`,{datasetElementType:!1,dataElementType:`arc`,animation:{animateRotate:!0,animateScale:!1},animations:{numbers:{type:`number`,properties:[`circumference`,`endAngle`,`innerRadius`,`outerRadius`,`startAngle`,`x`,`y`,`offset`,`borderWidth`,`spacing`]}},cutout:`50%`,rotation:0,circumference:360,radius:`100%`,spacing:0,indexAxis:`r`}),f(Us,`descriptors`,{_scriptable:e=>e!==`spacing`,_indexable:e=>e!==`spacing`&&!e.startsWith(`borderDash`)&&!e.startsWith(`hoverBorderDash`)}),f(Us,`overrides`,{aspectRatio:1,plugins:{legend:{labels:{generateLabels(e){let t=e.data,{labels:{pointStyle:n,textAlign:r,color:i,useBorderRadius:a,borderRadius:o}}=e.legend.options;return t.labels.length&&t.datasets.length?t.labels.map((t,s)=>{let c=e.getDatasetMeta(0).controller.getStyle(s);return{text:t,fillStyle:c.backgroundColor,fontColor:i,hidden:!e.getDataVisibility(s),lineDash:c.borderDash,lineDashOffset:c.borderDashOffset,lineJoin:c.borderJoinStyle,lineWidth:c.borderWidth,strokeStyle:c.borderColor,textAlign:r,pointStyle:n,borderRadius:a&&(o||c.borderRadius),index:s}}):[]}},onClick(e,t,n){n.chart.toggleDataVisibility(t.index),n.chart.update()}}}});var Ws=class extends ws{initialize(){this.enableOptionSharing=!0,this.supportsDecimation=!0,super.initialize()}update(e){let t=this._cachedMeta,{dataset:n,data:r=[],_dataset:i}=t,a=this.chart._animationsDisabled,{start:o,count:s}=zi(t,r,a);this._drawStart=o,this._drawCount=s,Bi(t)&&(o=0,s=r.length),n._chart=this.chart,n._datasetIndex=this.index,n._decimated=!!i._decimated,n.points=r;let c=this.resolveDatasetElementOptions(e);this.options.showLine||(c.borderWidth=0),c.segment=this.options.segment,this.updateElement(n,void 0,{animated:!a,options:c},e),this.updateElements(r,o,s,e)}updateElements(e,t,n,r){let i=r===`reset`,{iScale:a,vScale:o,_stacked:s,_dataset:c}=this._cachedMeta,{sharedOptions:l,includeOptions:u}=this._getSharedOptions(t,r),d=a.axis,f=o.axis,{spanGaps:p,segment:m}=this.options,h=pi(p)?p:1/0,g=this.chart._animationsDisabled||i||r===`none`,_=t+n,v=e.length,y=t>0&&this.getParsed(t-1);for(let n=0;n<v;++n){let p=e[n],v=g?p:{};if(n<t||n>=_){v.skip=!0;continue}let b=this.getParsed(n),x=L(b[f]),S=v[d]=a.getPixelForValue(b[d],n),C=v[f]=i||x?o.getBasePixel():o.getPixelForValue(s?this.applyStack(o,b,s):b[f],n);v.skip=isNaN(S)||isNaN(C)||x,v.stop=n>0&&Math.abs(b[d]-y[d])>h,m&&(v.parsed=b,v.raw=c.data[n]),u&&(v.options=l||this.resolveDataElementOptions(n,p.active?`active`:r)),g||this.updateElement(p,n,v,r),y=b}}getMaxOverflow(){let e=this._cachedMeta,t=e.dataset,n=t.options&&t.options.borderWidth||0,r=e.data||[];if(!r.length)return n;let i=r[0].size(this.resolveDataElementOptions(0)),a=r[r.length-1].size(this.resolveDataElementOptions(r.length-1));return Math.max(n,i,a)/2}draw(){let e=this._cachedMeta;e.dataset.updateControlPoints(this.chart.chartArea,e.iScale.axis),super.draw()}};f(Ws,`id`,`line`),f(Ws,`defaults`,{datasetElementType:`line`,dataElementType:`point`,showLine:!0,spanGaps:!1}),f(Ws,`overrides`,{scales:{_index_:{type:`category`},_value_:{type:`linear`}}});var Gs=class extends ws{constructor(e,t){super(e,t),this.innerRadius=void 0,this.outerRadius=void 0}getLabelAndValue(e){let t=this._cachedMeta,n=this.chart,r=n.data.labels||[],i=ea(t._parsed[e].r,n.options.locale);return{label:r[e]||``,value:i}}parseObjectData(e,t,n,r){return to.bind(this)(e,t,n,r)}update(e){let t=this._cachedMeta.data;this._updateRadius(),this.updateElements(t,0,t.length,e)}getMinMax(){let e=this._cachedMeta,t={min:1/0,max:-1/0};return e.data.forEach((e,n)=>{let r=this.getParsed(n).r;!isNaN(r)&&this.chart.getDataVisibility(n)&&(r<t.min&&(t.min=r),r>t.max&&(t.max=r))}),t}_updateRadius(){let e=this.chart,t=e.chartArea,n=e.options,r=Math.min(t.right-t.left,t.bottom-t.top),i=Math.max(r/2,0),a=(i-Math.max(n.cutoutPercentage?i/100*n.cutoutPercentage:1,0))/e.getVisibleDatasetCount();this.outerRadius=i-a*this.index,this.innerRadius=this.outerRadius-a}updateElements(e,t,n,r){let i=r===`reset`,a=this.chart,o=a.options.animation,s=this._cachedMeta.rScale,c=s.xCenter,l=s.yCenter,u=s.getIndexAngle(0)-.5*W,d=u,f,p=360/this.countVisibleElements();for(f=0;f<t;++f)d+=this._computeAngle(f,r,p);for(f=t;f<t+n;f++){let t=e[f],n=d,m=d+this._computeAngle(f,r,p),h=a.getDataVisibility(f)?s.getDistanceFromCenterForValue(this.getParsed(f).r):0;d=m,i&&(o.animateScale&&(h=0),o.animateRotate&&(n=m=u));let g={x:c,y:l,innerRadius:0,outerRadius:h,startAngle:n,endAngle:m,options:this.resolveDataElementOptions(f,t.active?`active`:r)};this.updateElement(t,f,g,r)}}countVisibleElements(){let e=this._cachedMeta,t=0;return e.data.forEach((e,n)=>{!isNaN(this.getParsed(n).r)&&this.chart.getDataVisibility(n)&&t++}),t}_computeAngle(e,t,n){return this.chart.getDataVisibility(e)?gi(this.resolveDataElementOptions(e,t).angle||n):0}};f(Gs,`id`,`polarArea`),f(Gs,`defaults`,{dataElementType:`arc`,animation:{animateRotate:!0,animateScale:!0},animations:{numbers:{type:`number`,properties:[`x`,`y`,`startAngle`,`endAngle`,`innerRadius`,`outerRadius`]}},indexAxis:`r`,startAngle:0}),f(Gs,`overrides`,{aspectRatio:1,plugins:{legend:{labels:{generateLabels(e){let t=e.data;if(t.labels.length&&t.datasets.length){let{labels:{pointStyle:n,color:r}}=e.legend.options;return t.labels.map((t,i)=>{let a=e.getDatasetMeta(0).controller.getStyle(i);return{text:t,fillStyle:a.backgroundColor,strokeStyle:a.borderColor,fontColor:r,lineWidth:a.borderWidth,pointStyle:n,hidden:!e.getDataVisibility(i),index:i}})}return[]}},onClick(e,t,n){n.chart.toggleDataVisibility(t.index),n.chart.update()}}},scales:{r:{type:`radialLinear`,angleLines:{display:!1},beginAtZero:!0,grid:{circular:!0},pointLabels:{display:!1},startAngle:0}}});var Ks=class extends Us{};f(Ks,`id`,`pie`),f(Ks,`defaults`,{cutout:0,rotation:0,circumference:360,radius:`100%`});var qs=class extends ws{getLabelAndValue(e){let t=this._cachedMeta.vScale,n=this.getParsed(e);return{label:t.getLabels()[e],value:``+t.getLabelForValue(n[t.axis])}}parseObjectData(e,t,n,r){return to.bind(this)(e,t,n,r)}update(e){let t=this._cachedMeta,n=t.dataset,r=t.data||[],i=t.iScale.getLabels();if(n.points=r,e!==`resize`){let t=this.resolveDatasetElementOptions(e);this.options.showLine||(t.borderWidth=0);let a={_loop:!0,_fullLoop:i.length===r.length,options:t};this.updateElement(n,void 0,a,e)}this.updateElements(r,0,r.length,e)}updateElements(e,t,n,r){let i=this._cachedMeta.rScale,a=r===`reset`;for(let o=t;o<t+n;o++){let t=e[o],n=this.resolveDataElementOptions(o,t.active?`active`:r),s=i.getPointPositionForValue(o,this.getParsed(o).r),c=a?i.xCenter:s.x,l=a?i.yCenter:s.y,u={x:c,y:l,angle:s.angle,skip:isNaN(c)||isNaN(l),options:n};this.updateElement(t,o,u,r)}}};f(qs,`id`,`radar`),f(qs,`defaults`,{datasetElementType:`line`,dataElementType:`point`,indexAxis:`r`,showLine:!0,elements:{line:{fill:`start`}}}),f(qs,`overrides`,{aspectRatio:1,scales:{r:{type:`radialLinear`}}});var Js=class extends ws{getLabelAndValue(e){let t=this._cachedMeta,n=this.chart.data.labels||[],{xScale:r,yScale:i}=t,a=this.getParsed(e),o=r.getLabelForValue(a.x),s=i.getLabelForValue(a.y);return{label:n[e]||``,value:`(`+o+`, `+s+`)`}}update(e){let t=this._cachedMeta,{data:n=[]}=t,r=this.chart._animationsDisabled,{start:i,count:a}=zi(t,n,r);if(this._drawStart=i,this._drawCount=a,Bi(t)&&(i=0,a=n.length),this.options.showLine){this.datasetElementType||this.addElements();let{dataset:i,_dataset:a}=t;i._chart=this.chart,i._datasetIndex=this.index,i._decimated=!!a._decimated,i.points=n;let o=this.resolveDatasetElementOptions(e);o.segment=this.options.segment,this.updateElement(i,void 0,{animated:!r,options:o},e)}else this.datasetElementType&&=(delete t.dataset,!1);this.updateElements(n,i,a,e)}addElements(){let{showLine:e}=this.options;!this.datasetElementType&&e&&(this.datasetElementType=this.chart.registry.getElement(`line`)),super.addElements()}updateElements(e,t,n,r){let i=r===`reset`,{iScale:a,vScale:o,_stacked:s,_dataset:c}=this._cachedMeta,l=this.resolveDataElementOptions(t,r),u=this.getSharedOptions(l),d=this.includeOptions(r,u),f=a.axis,p=o.axis,{spanGaps:m,segment:h}=this.options,g=pi(m)?m:1/0,_=this.chart._animationsDisabled||i||r===`none`,v=t>0&&this.getParsed(t-1);for(let l=t;l<t+n;++l){let t=e[l],n=this.getParsed(l),m=_?t:{},y=L(n[p]),b=m[f]=a.getPixelForValue(n[f],l),x=m[p]=i||y?o.getBasePixel():o.getPixelForValue(s?this.applyStack(o,n,s):n[p],l);m.skip=isNaN(b)||isNaN(x)||y,m.stop=l>0&&Math.abs(n[f]-v[f])>g,h&&(m.parsed=n,m.raw=c.data[l]),d&&(m.options=u||this.resolveDataElementOptions(l,t.active?`active`:r)),_||this.updateElement(t,l,m,r),v=n}this.updateSharedOptions(u,r,l)}getMaxOverflow(){let e=this._cachedMeta,t=e.data||[];if(!this.options.showLine){let e=0;for(let n=t.length-1;n>=0;--n)e=Math.max(e,t[n].size(this.resolveDataElementOptions(n))/2);return e>0&&e}let n=e.dataset,r=n.options&&n.options.borderWidth||0;if(!t.length)return r;let i=t[0].size(this.resolveDataElementOptions(0)),a=t[t.length-1].size(this.resolveDataElementOptions(t.length-1));return Math.max(r,i,a)/2}};f(Js,`id`,`scatter`),f(Js,`defaults`,{datasetElementType:!1,dataElementType:`point`,showLine:!1,fill:!1}),f(Js,`overrides`,{interaction:{mode:`point`},scales:{x:{type:`linear`},y:{type:`linear`}}});function Ys(){throw Error(`This method is not implemented: Check that a complete date adapter is provided.`)}var Xs={_date:class e{static override(t){Object.assign(e.prototype,t)}constructor(e){f(this,`options`,void 0),this.options=e||{}}init(){}formats(){return Ys()}parse(){return Ys()}format(){return Ys()}add(){return Ys()}diff(){return Ys()}startOf(){return Ys()}endOf(){return Ys()}}};function Zs(e,t,n,r){let{controller:i,data:a,_sorted:o}=e,s=i._cachedMeta.iScale,c=e.dataset&&e.dataset.options?e.dataset.options.spanGaps:null;if(s&&t===s.axis&&t!==`r`&&o&&a.length){let o=s._reversePixels?Di:Ei;if(!r){let r=o(a,t,n);if(c){let{vScale:t}=i._cachedMeta,{_parsed:n}=e,a=n.slice(0,r.lo+1).reverse().findIndex(e=>!L(e[t.axis]));r.lo-=Math.max(0,a);let o=n.slice(r.hi).findIndex(e=>!L(e[t.axis]));r.hi+=Math.max(0,o)}return r}else if(i._sharedOptions){let e=a[0],r=typeof e.getRange==`function`&&e.getRange(t);if(r){let e=o(a,t,n-r),i=o(a,t,n+r);return{lo:e.lo,hi:i.hi}}}}return{lo:0,hi:a.length-1}}function Qs(e,t,n,r,i){let a=e.getSortedVisibleDatasetMetas(),o=n[t];for(let e=0,n=a.length;e<n;++e){let{index:n,data:s}=a[e],{lo:c,hi:l}=Zs(a[e],t,o,i);for(let e=c;e<=l;++e){let t=s[e];t.skip||r(t,n,e)}}}function $s(e){let t=e.indexOf(`x`)!==-1,n=e.indexOf(`y`)!==-1;return function(e,r){let i=t?Math.abs(e.x-r.x):0,a=n?Math.abs(e.y-r.y):0;return Math.sqrt(i**2+a**2)}}function ec(e,t,n,r,i){let a=[];return!i&&!e.isPointInArea(t)||Qs(e,n,t,function(n,o,s){!i&&!ga(n,e.chartArea,0)||n.inRange(t.x,t.y,r)&&a.push({element:n,datasetIndex:o,index:s})},!0),a}function tc(e,t,n,r){let i=[];function a(e,n,a){let{startAngle:o,endAngle:s}=e.getProps([`startAngle`,`endAngle`],r),{angle:c}=yi(e,{x:t.x,y:t.y});Si(c,o,s)&&i.push({element:e,datasetIndex:n,index:a})}return Qs(e,n,t,a),i}function nc(e,t,n,r,i,a){let o=[],s=$s(n),c=1/0;function l(n,l,u){let d=n.inRange(t.x,t.y,i);if(r&&!d)return;let f=n.getCenterPoint(i);if(!(a||e.isPointInArea(f))&&!d)return;let p=s(t,f);p<c?(o=[{element:n,datasetIndex:l,index:u}],c=p):p===c&&o.push({element:n,datasetIndex:l,index:u})}return Qs(e,n,t,l),o}function rc(e,t,n,r,i,a){return!a&&!e.isPointInArea(t)?[]:n===`r`&&!r?tc(e,t,n,i):nc(e,t,n,r,i,a)}function ic(e,t,n,r,i){let a=[],o=n===`x`?`inXRange`:`inYRange`,s=!1;return Qs(e,n,t,(e,r,c)=>{e[o]&&e[o](t[n],i)&&(a.push({element:e,datasetIndex:r,index:c}),s||=e.inRange(t.x,t.y,i))}),r&&!s?[]:a}var ac={evaluateInteractionItems:Qs,modes:{index(e,t,n,r){let i=So(t,e),a=n.axis||`x`,o=n.includeInvisible||!1,s=n.intersect?ec(e,i,a,r,o):rc(e,i,a,!1,r,o),c=[];return s.length?(e.getSortedVisibleDatasetMetas().forEach(e=>{let t=s[0].index,n=e.data[t];n&&!n.skip&&c.push({element:n,datasetIndex:e.index,index:t})}),c):[]},dataset(e,t,n,r){let i=So(t,e),a=n.axis||`xy`,o=n.includeInvisible||!1,s=n.intersect?ec(e,i,a,r,o):rc(e,i,a,!1,r,o);if(s.length>0){let t=s[0].datasetIndex,n=e.getDatasetMeta(t).data;s=[];for(let e=0;e<n.length;++e)s.push({element:n[e],datasetIndex:t,index:e})}return s},point(e,t,n,r){return ec(e,So(t,e),n.axis||`xy`,r,n.includeInvisible||!1)},nearest(e,t,n,r){let i=So(t,e),a=n.axis||`xy`,o=n.includeInvisible||!1;return rc(e,i,a,n.intersect,r,o)},x(e,t,n,r){return ic(e,So(t,e),`x`,n.intersect,r)},y(e,t,n,r){return ic(e,So(t,e),`y`,n.intersect,r)}}},oc=[`left`,`top`,`right`,`bottom`];function sc(e,t){return e.filter(e=>e.pos===t)}function cc(e,t){return e.filter(e=>oc.indexOf(e.pos)===-1&&e.box.axis===t)}function lc(e,t){return e.sort((e,n)=>{let r=t?n:e,i=t?e:n;return r.weight===i.weight?r.index-i.index:r.weight-i.weight})}function uc(e){let t=[],n,r,i,a,o,s;for(n=0,r=(e||[]).length;n<r;++n)i=e[n],{position:a,options:{stack:o,stackWeight:s=1}}=i,t.push({index:n,box:i,pos:a,horizontal:i.isHorizontal(),weight:i.weight,stack:o&&a+o,stackWeight:s});return t}function dc(e){let t={};for(let n of e){let{stack:e,pos:r,stackWeight:i}=n;if(!e||!oc.includes(r))continue;let a=t[e]||(t[e]={count:0,placed:0,weight:0,size:0});a.count++,a.weight+=i}return t}function fc(e,t){let n=dc(e),{vBoxMaxWidth:r,hBoxMaxHeight:i}=t,a,o,s;for(a=0,o=e.length;a<o;++a){s=e[a];let{fullSize:o}=s.box,c=n[s.stack],l=c&&s.stackWeight/c.weight;s.horizontal?(s.width=l?l*r:o&&t.availableWidth,s.height=i):(s.width=r,s.height=l?l*i:o&&t.availableHeight)}return n}function pc(e){let t=uc(e),n=lc(t.filter(e=>e.box.fullSize),!0),r=lc(sc(t,`left`),!0),i=lc(sc(t,`right`)),a=lc(sc(t,`top`),!0),o=lc(sc(t,`bottom`)),s=cc(t,`x`),c=cc(t,`y`);return{fullSize:n,leftAndTop:r.concat(a),rightAndBottom:i.concat(c).concat(o).concat(s),chartArea:sc(t,`chartArea`),vertical:r.concat(i).concat(c),horizontal:a.concat(o).concat(s)}}function mc(e,t,n,r){return Math.max(e[n],t[n])+Math.max(e[r],t[r])}function hc(e,t){e.top=Math.max(e.top,t.top),e.left=Math.max(e.left,t.left),e.bottom=Math.max(e.bottom,t.bottom),e.right=Math.max(e.right,t.right)}function gc(e,t,n,r){let{pos:i,box:a}=n,o=e.maxPadding;if(!z(i)){n.size&&(e[i]-=n.size);let t=r[n.stack]||{size:0,count:1};t.size=Math.max(t.size,n.horizontal?a.height:a.width),n.size=t.size/t.count,e[i]+=n.size}a.getPadding&&hc(o,a.getPadding());let s=Math.max(0,t.outerWidth-mc(o,e,`left`,`right`)),c=Math.max(0,t.outerHeight-mc(o,e,`top`,`bottom`)),l=s!==e.w,u=c!==e.h;return e.w=s,e.h=c,n.horizontal?{same:l,other:u}:{same:u,other:l}}function _c(e){let t=e.maxPadding;function n(n){let r=Math.max(t[n]-e[n],0);return e[n]+=r,r}e.y+=n(`top`),e.x+=n(`left`),n(`right`),n(`bottom`)}function vc(e,t){let n=t.maxPadding;function r(e){let r={left:0,top:0,right:0,bottom:0};return e.forEach(e=>{r[e]=Math.max(t[e],n[e])}),r}return r(e?[`left`,`right`]:[`top`,`bottom`])}function yc(e,t,n,r){let i=[],a,o,s,c,l,u;for(a=0,o=e.length,l=0;a<o;++a){s=e[a],c=s.box,c.update(s.width||t.w,s.height||t.h,vc(s.horizontal,t));let{same:o,other:d}=gc(t,n,s,r);l|=o&&i.length,u||=d,c.fullSize||i.push(s)}return l&&yc(i,t,n,r)||u}function bc(e,t,n,r,i){e.top=n,e.left=t,e.right=t+r,e.bottom=n+i,e.width=r,e.height=i}function xc(e,t,n,r){let i=n.padding,{x:a,y:o}=t;for(let s of e){let e=s.box,c=r[s.stack]||{count:1,placed:0,weight:1},l=s.stackWeight/c.weight||1;if(s.horizontal){let r=t.w*l,a=c.size||e.height;Qr(c.start)&&(o=c.start),e.fullSize?bc(e,i.left,o,n.outerWidth-i.right-i.left,a):bc(e,t.left+c.placed,o,r,a),c.start=o,c.placed+=r,o=e.bottom}else{let r=t.h*l,o=c.size||e.width;Qr(c.start)&&(a=c.start),e.fullSize?bc(e,a,i.top,o,n.outerHeight-i.bottom-i.top):bc(e,a,t.top+c.placed,o,r),c.start=a,c.placed+=r,a=e.right}}t.x=a,t.y=o}var Sc={addBox(e,t){e.boxes||=[],t.fullSize=t.fullSize||!1,t.position=t.position||`top`,t.weight=t.weight||0,t._layers=t._layers||function(){return[{z:0,draw(e){t.draw(e)}}]},e.boxes.push(t)},removeBox(e,t){let n=e.boxes?e.boxes.indexOf(t):-1;n!==-1&&e.boxes.splice(n,1)},configure(e,t,n){t.fullSize=n.fullSize,t.position=n.position,t.weight=n.weight},update(e,t,n,r){if(!e)return;let i=X(e.options.layout.padding),a=Math.max(t-i.width,0),o=Math.max(n-i.height,0),s=pc(e.boxes),c=s.vertical,l=s.horizontal;U(e.boxes,e=>{typeof e.beforeLayout==`function`&&e.beforeLayout()});let u=c.reduce((e,t)=>t.box.options&&t.box.options.display===!1?e:e+1,0)||1,d=Object.freeze({outerWidth:t,outerHeight:n,padding:i,availableWidth:a,availableHeight:o,vBoxMaxWidth:a/2/u,hBoxMaxHeight:o/2}),f=Object.assign({},i);hc(f,X(r));let p=Object.assign({maxPadding:f,w:a,h:o,x:i.left,y:i.top},i),m=fc(c.concat(l),d);yc(s.fullSize,p,d,m),yc(c,p,d,m),yc(l,p,d,m)&&yc(c,p,d,m),_c(p),xc(s.leftAndTop,p,d,m),p.x+=p.w,p.y+=p.h,xc(s.rightAndBottom,p,d,m),e.chartArea={left:p.left,top:p.top,right:p.left+p.w,bottom:p.top+p.h,height:p.h,width:p.w},U(s.chartArea,t=>{let n=t.box;Object.assign(n,e.chartArea),n.update(p.w,p.h,{left:0,top:0,right:0,bottom:0})})}},Cc=class{acquireContext(e,t){}releaseContext(e){return!1}addEventListener(e,t,n){}removeEventListener(e,t,n){}getDevicePixelRatio(){return 1}getMaximumSize(e,t,n,r){return t=Math.max(0,t||e.width),n||=e.height,{width:t,height:Math.max(0,r?Math.floor(t/r):n)}}isAttached(e){return!0}updateConfig(e){}},wc=class extends Cc{acquireContext(e){return e&&e.getContext&&e.getContext(`2d`)||null}updateConfig(e){e.options.animation=!1}},Tc=`$chartjs`,Ec={touchstart:`mousedown`,touchmove:`mousemove`,touchend:`mouseup`,pointerenter:`mouseenter`,pointerdown:`mousedown`,pointermove:`mousemove`,pointerup:`mouseup`,pointerleave:`mouseout`,pointerout:`mouseout`},Dc=e=>e===null||e===``;function Oc(e,t){let n=e.style,r=e.getAttribute(`height`),i=e.getAttribute(`width`);if(e[Tc]={initial:{height:r,width:i,style:{display:n.display,height:n.height,width:n.width}}},n.display=n.display||`block`,n.boxSizing=n.boxSizing||`border-box`,Dc(i)){let t=Oo(e,`width`);t!==void 0&&(e.width=t)}if(Dc(r))if(e.style.height===``)e.height=e.width/(t||2);else{let t=Oo(e,`height`);t!==void 0&&(e.height=t)}return e}var kc=Do?{passive:!0}:!1;function Ac(e,t,n){e&&e.addEventListener(t,n,kc)}function jc(e,t,n){e&&e.canvas&&e.canvas.removeEventListener(t,n,kc)}function Mc(e,t){let n=Ec[e.type]||e.type,{x:r,y:i}=So(e,t);return{type:n,chart:t,native:e,x:r===void 0?null:r,y:i===void 0?null:i}}function Nc(e,t){for(let n of e)if(n===t||n.contains(t))return!0}function Pc(e,t,n){let r=e.canvas,i=new MutationObserver(e=>{let t=!1;for(let n of e)t||=Nc(n.addedNodes,r),t&&=!Nc(n.removedNodes,r);t&&n()});return i.observe(document,{childList:!0,subtree:!0}),i}function Fc(e,t,n){let r=e.canvas,i=new MutationObserver(e=>{let t=!1;for(let n of e)t||=Nc(n.removedNodes,r),t&&=!Nc(n.addedNodes,r);t&&n()});return i.observe(document,{childList:!0,subtree:!0}),i}var Ic=new Map,Lc=0;function Rc(){let e=window.devicePixelRatio;e!==Lc&&(Lc=e,Ic.forEach((t,n)=>{n.currentDevicePixelRatio!==e&&t()}))}function zc(e,t){Ic.size||window.addEventListener(`resize`,Rc),Ic.set(e,t)}function Bc(e){Ic.delete(e),Ic.size||window.removeEventListener(`resize`,Rc)}function Vc(e,t,n){let r=e.canvas,i=r&&mo(r);if(!i)return;let a=Pi((e,t)=>{let r=i.clientWidth;n(e,t),r<i.clientWidth&&n()},window),o=new ResizeObserver(e=>{let t=e[0],n=t.contentRect.width,r=t.contentRect.height;n===0&&r===0||a(n,r)});return o.observe(i),zc(e,a),o}function Hc(e,t,n){n&&n.disconnect(),t===`resize`&&Bc(e)}function Uc(e,t,n){let r=e.canvas,i=Pi(t=>{e.ctx!==null&&n(Mc(t,e))},e);return Ac(r,t,i),i}var Wc=class extends Cc{acquireContext(e,t){let n=e&&e.getContext&&e.getContext(`2d`);return n&&n.canvas===e?(Oc(e,t),n):null}releaseContext(e){let t=e.canvas;if(!t[Tc])return!1;let n=t[Tc].initial;[`height`,`width`].forEach(e=>{let r=n[e];L(r)?t.removeAttribute(e):t.setAttribute(e,r)});let r=n.style||{};return Object.keys(r).forEach(e=>{t.style[e]=r[e]}),t.width=t.width,delete t[Tc],!0}addEventListener(e,t,n){this.removeEventListener(e,t);let r=e.$proxies||={};r[t]=({attach:Pc,detach:Fc,resize:Vc}[t]||Uc)(e,t,n)}removeEventListener(e,t){let n=e.$proxies||={},r=n[t];r&&(({attach:Hc,detach:Hc,resize:Hc}[t]||jc)(e,t,r),n[t]=void 0)}getDevicePixelRatio(){return window.devicePixelRatio}getMaximumSize(e,t,n,r){return To(e,t,n,r)}isAttached(e){let t=e&&mo(e);return!!(t&&t.isConnected)}};function Gc(e){return!po()||typeof OffscreenCanvas<`u`&&e instanceof OffscreenCanvas?wc:Wc}var Kc=class{constructor(){f(this,`x`,void 0),f(this,`y`,void 0),f(this,`active`,!1),f(this,`options`,void 0),f(this,`$animations`,void 0)}tooltipPosition(e){let{x:t,y:n}=this.getProps([`x`,`y`],e);return{x:t,y:n}}hasValue(){return pi(this.x)&&pi(this.y)}getProps(e,t){let n=this.$animations;if(!t||!n)return this;let r={};return e.forEach(e=>{r[e]=n[e]&&n[e].active()?n[e]._to:this[e]}),r}};f(Kc,`defaults`,{}),f(Kc,`defaultRoutes`,void 0);function qc(e,t){let n=e.options.ticks,r=Jc(e),i=Math.min(n.maxTicksLimit||r,r),a=n.major.enabled?Xc(t):[],o=a.length,s=a[0],c=a[o-1],l=[];if(o>i)return Zc(t,l,a,o/i),l;let u=Yc(a,t,i);if(o>0){let e,n,r=o>1?Math.round((c-s)/(o-1)):null;for(Qc(t,l,u,L(r)?0:s-r,s),e=0,n=o-1;e<n;e++)Qc(t,l,u,a[e],a[e+1]);return Qc(t,l,u,c,L(r)?t.length:c+r),l}return Qc(t,l,u),l}function Jc(e){let t=e.options.offset,n=e._tickSize(),r=e._length/n+(t?0:1),i=e._maxLength/n;return Math.floor(Math.min(r,i))}function Yc(e,t,n){let r=$c(e),i=t.length/n;if(!r)return Math.max(i,1);let a=di(r);for(let e=0,t=a.length-1;e<t;e++){let t=a[e];if(t>i)return t}return Math.max(i,1)}function Xc(e){let t=[],n,r;for(n=0,r=e.length;n<r;n++)e[n].major&&t.push(n);return t}function Zc(e,t,n,r){let i=0,a=n[0],o;for(r=Math.ceil(r),o=0;o<e.length;o++)o===a&&(t.push(e[o]),i++,a=n[i*r])}function Qc(e,t,n,r,i){let a=V(r,0),o=Math.min(V(i,e.length),e.length),s=0,c,l,u;for(n=Math.ceil(n),i&&(c=i-r,n=c/Math.floor(c/n)),u=a;u<0;)s++,u=Math.round(a+s*n);for(l=Math.max(a,0);l<o;l++)l===u&&(t.push(e[l]),s++,u=Math.round(a+s*n))}function $c(e){let t=e.length,n,r;if(t<2)return!1;for(r=e[0],n=1;n<t;++n)if(e[n]-e[n-1]!==r)return!1;return r}var el=e=>e===`left`?`right`:e===`right`?`left`:e,tl=(e,t,n)=>t===`top`||t===`left`?e[t]+n:e[t]-n,nl=(e,t)=>Math.min(t||e,e);function rl(e,t){let n=[],r=e.length/t,i=e.length,a=0;for(;a<i;a+=r)n.push(e[Math.floor(a)]);return n}function il(e,t,n){let r=e.ticks.length,i=Math.min(t,r-1),a=e._startPixel,o=e._endPixel,s=1e-6,c=e.getPixelForTick(i),l;if(!(n&&(l=r===1?Math.max(c-a,o-c):t===0?(e.getPixelForTick(1)-c)/2:(c-e.getPixelForTick(i-1))/2,c+=i<t?l:-l,c<a-s||c>o+s)))return c}function al(e,t){U(e,e=>{let n=e.gc,r=n.length/2,i;if(r>t){for(i=0;i<r;++i)delete e.data[n[i]];n.splice(0,r)}})}function ol(e){return e.drawTicks?e.tickLength:0}function sl(e,t){if(!e.display)return 0;let n=Z(e.font,t),r=X(e.padding);return(R(e.text)?e.text.length:1)*n.lineHeight+r.height}function cl(e,t){return Fa(e,{scale:t,type:`scale`})}function ll(e,t,n){return Fa(e,{tick:n,index:t,type:`tick`})}function ul(e,t,n){let r=Ii(e);return(n&&t!==`right`||!n&&t===`right`)&&(r=el(r)),r}function dl(e,t,n,r){let{top:i,left:a,bottom:o,right:s,chart:c}=e,{chartArea:l,scales:u}=c,d=0,f,p,m,h=o-i,g=s-a;if(e.isHorizontal()){if(p=Li(r,a,s),z(n)){let e=Object.keys(n)[0],r=n[e];m=u[e].getPixelForValue(r)+h-t}else m=n===`center`?(l.bottom+l.top)/2+h-t:tl(e,n,t);f=s-a}else{if(z(n)){let e=Object.keys(n)[0],r=n[e];p=u[e].getPixelForValue(r)-g+t}else p=n===`center`?(l.left+l.right)/2-g+t:tl(e,n,t);m=Li(r,o,i),d=n===`left`?-K:K}return{titleX:p,titleY:m,maxWidth:f,rotation:d}}var fl=class e extends Kc{constructor(e){super(),this.id=e.id,this.type=e.type,this.options=void 0,this.ctx=e.ctx,this.chart=e.chart,this.top=void 0,this.bottom=void 0,this.left=void 0,this.right=void 0,this.width=void 0,this.height=void 0,this._margins={left:0,right:0,top:0,bottom:0},this.maxWidth=void 0,this.maxHeight=void 0,this.paddingTop=void 0,this.paddingBottom=void 0,this.paddingLeft=void 0,this.paddingRight=void 0,this.axis=void 0,this.labelRotation=void 0,this.min=void 0,this.max=void 0,this._range=void 0,this.ticks=[],this._gridLineItems=null,this._labelItems=null,this._labelSizes=null,this._length=0,this._maxLength=0,this._longestTextCache={},this._startPixel=void 0,this._endPixel=void 0,this._reversePixels=!1,this._userMax=void 0,this._userMin=void 0,this._suggestedMax=void 0,this._suggestedMin=void 0,this._ticksLength=0,this._borderValue=0,this._cache={},this._dataLimitsCached=!1,this.$context=void 0}init(e){this.options=e.setContext(this.getContext()),this.axis=e.axis,this._userMin=this.parse(e.min),this._userMax=this.parse(e.max),this._suggestedMin=this.parse(e.suggestedMin),this._suggestedMax=this.parse(e.suggestedMax)}parse(e,t){return e}getUserBounds(){let{_userMin:e,_userMax:t,_suggestedMin:n,_suggestedMax:r}=this;return e=Lr(e,1/0),t=Lr(t,-1/0),n=Lr(n,1/0),r=Lr(r,-1/0),{min:Lr(e,n),max:Lr(t,r),minDefined:B(e),maxDefined:B(t)}}getMinMax(e){let{min:t,max:n,minDefined:r,maxDefined:i}=this.getUserBounds(),a;if(r&&i)return{min:t,max:n};let o=this.getMatchingVisibleMetas();for(let s=0,c=o.length;s<c;++s)a=o[s].controller.getMinMax(this,e),r||(t=Math.min(t,a.min)),i||(n=Math.max(n,a.max));return t=i&&t>n?n:t,n=r&&t>n?t:n,{min:Lr(t,Lr(n,t)),max:Lr(n,Lr(t,n))}}getPadding(){return{left:this.paddingLeft||0,top:this.paddingTop||0,right:this.paddingRight||0,bottom:this.paddingBottom||0}}getTicks(){return this.ticks}getLabels(){let e=this.chart.data;return this.options.labels||(this.isHorizontal()?e.xLabels:e.yLabels)||e.labels||[]}getLabelItems(e=this.chart.chartArea){return this._labelItems||=this._computeLabelItems(e)}beforeLayout(){this._cache={},this._dataLimitsCached=!1}beforeUpdate(){H(this.options.beforeUpdate,[this])}update(e,t,n){let{beginAtZero:r,grace:i,ticks:a}=this.options,o=a.sampleSize;this.beforeUpdate(),this.maxWidth=e,this.maxHeight=t,this._margins=n=Object.assign({left:0,right:0,top:0,bottom:0},n),this.ticks=null,this._labelSizes=null,this._gridLineItems=null,this._labelItems=null,this.beforeSetDimensions(),this.setDimensions(),this.afterSetDimensions(),this._maxLength=this.isHorizontal()?this.width+n.left+n.right:this.height+n.top+n.bottom,this._dataLimitsCached||=(this.beforeDataLimits(),this.determineDataLimits(),this.afterDataLimits(),this._range=Pa(this,i,r),!0),this.beforeBuildTicks(),this.ticks=this.buildTicks()||[],this.afterBuildTicks();let s=o<this.ticks.length;this._convertTicksToLabels(s?rl(this.ticks,o):this.ticks),this.configure(),this.beforeCalculateLabelRotation(),this.calculateLabelRotation(),this.afterCalculateLabelRotation(),a.display&&(a.autoSkip||a.source===`auto`)&&(this.ticks=qc(this,this.ticks),this._labelSizes=null,this.afterAutoSkip()),s&&this._convertTicksToLabels(this.ticks),this.beforeFit(),this.fit(),this.afterFit(),this.afterUpdate()}configure(){let e=this.options.reverse,t,n;this.isHorizontal()?(t=this.left,n=this.right):(t=this.top,n=this.bottom,e=!e),this._startPixel=t,this._endPixel=n,this._reversePixels=e,this._length=n-t,this._alignToPixels=this.options.alignToPixels}afterUpdate(){H(this.options.afterUpdate,[this])}beforeSetDimensions(){H(this.options.beforeSetDimensions,[this])}setDimensions(){this.isHorizontal()?(this.width=this.maxWidth,this.left=0,this.right=this.width):(this.height=this.maxHeight,this.top=0,this.bottom=this.height),this.paddingLeft=0,this.paddingTop=0,this.paddingRight=0,this.paddingBottom=0}afterSetDimensions(){H(this.options.afterSetDimensions,[this])}_callHooks(e){this.chart.notifyPlugins(e,this.getContext()),H(this.options[e],[this])}beforeDataLimits(){this._callHooks(`beforeDataLimits`)}determineDataLimits(){}afterDataLimits(){this._callHooks(`afterDataLimits`)}beforeBuildTicks(){this._callHooks(`beforeBuildTicks`)}buildTicks(){return[]}afterBuildTicks(){this._callHooks(`afterBuildTicks`)}beforeTickToLabelConversion(){H(this.options.beforeTickToLabelConversion,[this])}generateTickLabels(e){let t=this.options.ticks,n,r,i;for(n=0,r=e.length;n<r;n++)i=e[n],i.label=H(t.callback,[i.value,n,e],this)}afterTickToLabelConversion(){H(this.options.afterTickToLabelConversion,[this])}beforeCalculateLabelRotation(){H(this.options.beforeCalculateLabelRotation,[this])}calculateLabelRotation(){let e=this.options,t=e.ticks,n=nl(this.ticks.length,e.ticks.maxTicksLimit),r=t.minRotation||0,i=t.maxRotation,a=r,o,s,c;if(!this._isVisible()||!t.display||r>=i||n<=1||!this.isHorizontal()){this.labelRotation=r;return}let l=this._getLabelSizes(),u=l.widest.width,d=l.highest.height,f=J(this.chart.width-u,0,this.maxWidth);o=e.offset?this.maxWidth/n:f/(n-1),u+6>o&&(o=f/(n-(e.offset?.5:1)),s=this.maxHeight-ol(e.grid)-t.padding-sl(e.title,this.chart.options.font),c=Math.sqrt(u*u+d*d),a=_i(Math.min(Math.asin(J((l.highest.height+6)/o,-1,1)),Math.asin(J(s/c,-1,1))-Math.asin(J(d/c,-1,1)))),a=Math.max(r,Math.min(i,a))),this.labelRotation=a}afterCalculateLabelRotation(){H(this.options.afterCalculateLabelRotation,[this])}afterAutoSkip(){}beforeFit(){H(this.options.beforeFit,[this])}fit(){let e={width:0,height:0},{chart:t,options:{ticks:n,title:r,grid:i}}=this,a=this._isVisible(),o=this.isHorizontal();if(a){let a=sl(r,t.options.font);if(o?(e.width=this.maxWidth,e.height=ol(i)+a):(e.height=this.maxHeight,e.width=ol(i)+a),n.display&&this.ticks.length){let{first:t,last:r,widest:i,highest:a}=this._getLabelSizes(),s=n.padding*2,c=gi(this.labelRotation),l=Math.cos(c),u=Math.sin(c);if(o){let t=n.mirror?0:u*i.width+l*a.height;e.height=Math.min(this.maxHeight,e.height+t+s)}else{let t=n.mirror?0:l*i.width+u*a.height;e.width=Math.min(this.maxWidth,e.width+t+s)}this._calculatePadding(t,r,u,l)}}this._handleMargins(),o?(this.width=this._length=t.width-this._margins.left-this._margins.right,this.height=e.height):(this.width=e.width,this.height=this._length=t.height-this._margins.top-this._margins.bottom)}_calculatePadding(e,t,n,r){let{ticks:{align:i,padding:a},position:o}=this.options,s=this.labelRotation!==0,c=o!==`top`&&this.axis===`x`;if(this.isHorizontal()){let o=this.getPixelForTick(0)-this.left,l=this.right-this.getPixelForTick(this.ticks.length-1),u=0,d=0;s?c?(u=r*e.width,d=n*t.height):(u=n*e.height,d=r*t.width):i===`start`?d=t.width:i===`end`?u=e.width:i!==`inner`&&(u=e.width/2,d=t.width/2),this.paddingLeft=Math.max((u-o+a)*this.width/(this.width-o),0),this.paddingRight=Math.max((d-l+a)*this.width/(this.width-l),0)}else{let n=t.height/2,r=e.height/2;i===`start`?(n=0,r=e.height):i===`end`&&(n=t.height,r=0),this.paddingTop=n+a,this.paddingBottom=r+a}}_handleMargins(){this._margins&&(this._margins.left=Math.max(this.paddingLeft,this._margins.left),this._margins.top=Math.max(this.paddingTop,this._margins.top),this._margins.right=Math.max(this.paddingRight,this._margins.right),this._margins.bottom=Math.max(this.paddingBottom,this._margins.bottom))}afterFit(){H(this.options.afterFit,[this])}isHorizontal(){let{axis:e,position:t}=this.options;return t===`top`||t===`bottom`||e===`x`}isFullSize(){return this.options.fullSize}_convertTicksToLabels(e){this.beforeTickToLabelConversion(),this.generateTickLabels(e);let t,n;for(t=0,n=e.length;t<n;t++)L(e[t].label)&&(e.splice(t,1),n--,t--);this.afterTickToLabelConversion()}_getLabelSizes(){let e=this._labelSizes;if(!e){let t=this.options.ticks.sampleSize,n=this.ticks;t<n.length&&(n=rl(n,t)),this._labelSizes=e=this._computeLabelSizes(n,n.length,this.options.ticks.maxTicksLimit)}return e}_computeLabelSizes(e,t,n){let{ctx:r,_longestTextCache:i}=this,a=[],o=[],s=Math.floor(t/nl(t,n)),c=0,l=0,u,d,f,p,m,h,g,_,v,y,b;for(u=0;u<t;u+=s){if(p=e[u].label,m=this._resolveTickFontOptions(u),r.font=h=m.string,g=i[h]=i[h]||{data:{},gc:[]},_=m.lineHeight,v=y=0,!L(p)&&!R(p))v=ua(r,g.data,g.gc,v,p),y=_;else if(R(p))for(d=0,f=p.length;d<f;++d)b=p[d],!L(b)&&!R(b)&&(v=ua(r,g.data,g.gc,v,b),y+=_);a.push(v),o.push(y),c=Math.max(v,c),l=Math.max(y,l)}al(i,t);let x=a.indexOf(c),S=o.indexOf(l),C=e=>({width:a[e]||0,height:o[e]||0});return{first:C(0),last:C(t-1),widest:C(x),highest:C(S),widths:a,heights:o}}getLabelForValue(e){return e}getPixelForValue(e,t){return NaN}getValueForPixel(e){}getPixelForTick(e){let t=this.ticks;return e<0||e>t.length-1?null:this.getPixelForValue(t[e].value)}getPixelForDecimal(e){this._reversePixels&&(e=1-e);let t=this._startPixel+e*this._length;return Ci(this._alignToPixels?fa(this.chart,t,0):t)}getDecimalForPixel(e){let t=(e-this._startPixel)/this._length;return this._reversePixels?1-t:t}getBasePixel(){return this.getPixelForValue(this.getBaseValue())}getBaseValue(){let{min:e,max:t}=this;return e<0&&t<0?t:e>0&&t>0?e:0}getContext(e){let t=this.ticks||[];if(e>=0&&e<t.length){let n=t[e];return n.$context||=ll(this.getContext(),e,n)}return this.$context||=cl(this.chart.getContext(),this)}_tickSize(){let e=this.options.ticks,t=gi(this.labelRotation),n=Math.abs(Math.cos(t)),r=Math.abs(Math.sin(t)),i=this._getLabelSizes(),a=e.autoSkipPadding||0,o=i?i.widest.width+a:0,s=i?i.highest.height+a:0;return this.isHorizontal()?s*n>o*r?o/n:s/r:s*r<o*n?s/n:o/r}_isVisible(){let e=this.options.display;return e===`auto`?this.getMatchingVisibleMetas().length>0:!!e}_computeGridLineItems(e){let t=this.axis,n=this.chart,r=this.options,{grid:i,position:a,border:o}=r,s=i.offset,c=this.isHorizontal(),l=this.ticks.length+(s?1:0),u=ol(i),d=[],f=o.setContext(this.getContext()),p=f.display?f.width:0,m=p/2,h=function(e){return fa(n,e,p)},g,_,v,y,b,x,S,C,w,T,E,D;if(a===`top`)g=h(this.bottom),x=this.bottom-u,C=g-m,T=h(e.top)+m,D=e.bottom;else if(a===`bottom`)g=h(this.top),T=e.top,D=h(e.bottom)-m,x=g+m,C=this.top+u;else if(a===`left`)g=h(this.right),b=this.right-u,S=g-m,w=h(e.left)+m,E=e.right;else if(a===`right`)g=h(this.left),w=e.left,E=h(e.right)-m,b=g+m,S=this.left+u;else if(t===`x`){if(a===`center`)g=h((e.top+e.bottom)/2+.5);else if(z(a)){let e=Object.keys(a)[0],t=a[e];g=h(this.chart.scales[e].getPixelForValue(t))}T=e.top,D=e.bottom,x=g+m,C=x+u}else if(t===`y`){if(a===`center`)g=h((e.left+e.right)/2);else if(z(a)){let e=Object.keys(a)[0],t=a[e];g=h(this.chart.scales[e].getPixelForValue(t))}b=g-m,S=b-u,w=e.left,E=e.right}let ee=V(r.ticks.maxTicksLimit,l),te=Math.max(1,Math.ceil(l/ee));for(_=0;_<l;_+=te){let e=this.getContext(_),t=i.setContext(e),r=o.setContext(e),a=t.lineWidth,l=t.color,u=r.dash||[],f=r.dashOffset,p=t.tickWidth,m=t.tickColor,h=t.tickBorderDash||[],g=t.tickBorderDashOffset;v=il(this,_,s),v!==void 0&&(y=fa(n,v,a),c?b=S=w=E=y:x=C=T=D=y,d.push({tx1:b,ty1:x,tx2:S,ty2:C,x1:w,y1:T,x2:E,y2:D,width:a,color:l,borderDash:u,borderDashOffset:f,tickWidth:p,tickColor:m,tickBorderDash:h,tickBorderDashOffset:g}))}return this._ticksLength=l,this._borderValue=g,d}_computeLabelItems(e){let t=this.axis,n=this.options,{position:r,ticks:i}=n,a=this.isHorizontal(),o=this.ticks,{align:s,crossAlign:c,padding:l,mirror:u}=i,d=ol(n.grid),f=d+l,p=u?-l:f,m=-gi(this.labelRotation),h=[],g,_,v,y,b,x,S,C,w,T,E,D,ee=`middle`;if(r===`top`)x=this.bottom-p,S=this._getXAxisLabelAlignment();else if(r===`bottom`)x=this.top+p,S=this._getXAxisLabelAlignment();else if(r===`left`){let e=this._getYAxisLabelAlignment(d);S=e.textAlign,b=e.x}else if(r===`right`){let e=this._getYAxisLabelAlignment(d);S=e.textAlign,b=e.x}else if(t===`x`){if(r===`center`)x=(e.top+e.bottom)/2+f;else if(z(r)){let e=Object.keys(r)[0],t=r[e];x=this.chart.scales[e].getPixelForValue(t)+f}S=this._getXAxisLabelAlignment()}else if(t===`y`){if(r===`center`)b=(e.left+e.right)/2-f;else if(z(r)){let e=Object.keys(r)[0],t=r[e];b=this.chart.scales[e].getPixelForValue(t)}S=this._getYAxisLabelAlignment(d).textAlign}t===`y`&&(s===`start`?ee=`top`:s===`end`&&(ee=`bottom`));let te=this._getLabelSizes();for(g=0,_=o.length;g<_;++g){v=o[g],y=v.label;let e=i.setContext(this.getContext(g));C=this.getPixelForTick(g)+i.labelOffset,w=this._resolveTickFontOptions(g),T=w.lineHeight,E=R(y)?y.length:1;let t=E/2,n=e.color,s=e.textStrokeColor,l=e.textStrokeWidth,d=S;a?(b=C,S===`inner`&&(d=g===_-1?this.options.reverse?`left`:`right`:g===0?this.options.reverse?`right`:`left`:`center`),D=r===`top`?c===`near`||m!==0?-E*T+T/2:c===`center`?-te.highest.height/2-t*T+T:-te.highest.height+T/2:c===`near`||m!==0?T/2:c===`center`?te.highest.height/2-t*T:te.highest.height-E*T,u&&(D*=-1),m!==0&&!e.showLabelBackdrop&&(b+=T/2*Math.sin(m))):(x=C,D=(1-E)*T/2);let f;if(e.showLabelBackdrop){let t=X(e.backdropPadding),n=te.heights[g],r=te.widths[g],i=D-t.top,a=0-t.left;switch(ee){case`middle`:i-=n/2;break;case`bottom`:i-=n;break}switch(S){case`center`:a-=r/2;break;case`right`:a-=r;break;case`inner`:g===_-1?a-=r:g>0&&(a-=r/2);break}f={left:a,top:i,width:r+t.width,height:n+t.height,color:e.backdropColor}}h.push({label:y,font:w,textOffset:D,options:{rotation:m,color:n,strokeColor:s,strokeWidth:l,textAlign:d,textBaseline:ee,translation:[b,x],backdrop:f}})}return h}_getXAxisLabelAlignment(){let{position:e,ticks:t}=this.options;if(-gi(this.labelRotation))return e===`top`?`left`:`right`;let n=`center`;return t.align===`start`?n=`left`:t.align===`end`?n=`right`:t.align===`inner`&&(n=`inner`),n}_getYAxisLabelAlignment(e){let{position:t,ticks:{crossAlign:n,mirror:r,padding:i}}=this.options,a=this._getLabelSizes(),o=e+i,s=a.widest.width,c,l;return t===`left`?r?(l=this.right+i,n===`near`?c=`left`:n===`center`?(c=`center`,l+=s/2):(c=`right`,l+=s)):(l=this.right-o,n===`near`?c=`right`:n===`center`?(c=`center`,l-=s/2):(c=`left`,l=this.left)):t===`right`?r?(l=this.left+i,n===`near`?c=`right`:n===`center`?(c=`center`,l-=s/2):(c=`left`,l-=s)):(l=this.left+o,n===`near`?c=`left`:n===`center`?(c=`center`,l+=s/2):(c=`right`,l=this.right)):c=`right`,{textAlign:c,x:l}}_computeLabelArea(){if(this.options.ticks.mirror)return;let e=this.chart,t=this.options.position;if(t===`left`||t===`right`)return{top:0,left:this.left,bottom:e.height,right:this.right};if(t===`top`||t===`bottom`)return{top:this.top,left:0,bottom:this.bottom,right:e.width}}drawBackground(){let{ctx:e,options:{backgroundColor:t},left:n,top:r,width:i,height:a}=this;t&&(e.save(),e.fillStyle=t,e.fillRect(n,r,i,a),e.restore())}getLineWidthForValue(e){let t=this.options.grid;if(!this._isVisible()||!t.display)return 0;let n=this.ticks.findIndex(t=>t.value===e);return n>=0?t.setContext(this.getContext(n)).lineWidth:0}drawGrid(e){let t=this.options.grid,n=this.ctx,r=this._gridLineItems||=this._computeGridLineItems(e),i,a,o=(e,t,r)=>{!r.width||!r.color||(n.save(),n.lineWidth=r.width,n.strokeStyle=r.color,n.setLineDash(r.borderDash||[]),n.lineDashOffset=r.borderDashOffset,n.beginPath(),n.moveTo(e.x,e.y),n.lineTo(t.x,t.y),n.stroke(),n.restore())};if(t.display)for(i=0,a=r.length;i<a;++i){let e=r[i];t.drawOnChartArea&&o({x:e.x1,y:e.y1},{x:e.x2,y:e.y2},e),t.drawTicks&&o({x:e.tx1,y:e.ty1},{x:e.tx2,y:e.ty2},{color:e.tickColor,width:e.tickWidth,borderDash:e.tickBorderDash,borderDashOffset:e.tickBorderDashOffset})}}drawBorder(){let{chart:e,ctx:t,options:{border:n,grid:r}}=this,i=n.setContext(this.getContext()),a=n.display?i.width:0;if(!a)return;let o=r.setContext(this.getContext(0)).lineWidth,s=this._borderValue,c,l,u,d;this.isHorizontal()?(c=fa(e,this.left,a)-a/2,l=fa(e,this.right,o)+o/2,u=d=s):(u=fa(e,this.top,a)-a/2,d=fa(e,this.bottom,o)+o/2,c=l=s),t.save(),t.lineWidth=i.width,t.strokeStyle=i.color,t.beginPath(),t.moveTo(c,u),t.lineTo(l,d),t.stroke(),t.restore()}drawLabels(e){if(!this.options.ticks.display)return;let t=this.ctx,n=this._computeLabelArea();n&&_a(t,n);let r=this.getLabelItems(e);for(let e of r){let n=e.options,r=e.font,i=e.label,a=e.textOffset;wa(t,i,0,a,r,n)}n&&va(t)}drawTitle(){let{ctx:e,options:{position:t,title:n,reverse:r}}=this;if(!n.display)return;let i=Z(n.font),a=X(n.padding),o=n.align,s=i.lineHeight/2;t===`bottom`||t===`center`||z(t)?(s+=a.bottom,R(n.text)&&(s+=i.lineHeight*(n.text.length-1))):s+=a.top;let{titleX:c,titleY:l,maxWidth:u,rotation:d}=dl(this,s,t,o);wa(e,n.text,0,0,i,{color:n.color,maxWidth:u,rotation:d,textAlign:ul(o,t,r),textBaseline:`middle`,translation:[c,l]})}draw(e){this._isVisible()&&(this.drawBackground(),this.drawGrid(e),this.drawBorder(),this.drawTitle(),this.drawLabels(e))}_layers(){let t=this.options,n=t.ticks&&t.ticks.z||0,r=V(t.grid&&t.grid.z,-1),i=V(t.border&&t.border.z,0);return!this._isVisible()||this.draw!==e.prototype.draw?[{z:n,draw:e=>{this.draw(e)}}]:[{z:r,draw:e=>{this.drawBackground(),this.drawGrid(e),this.drawTitle()}},{z:i,draw:()=>{this.drawBorder()}},{z:n,draw:e=>{this.drawLabels(e)}}]}getMatchingVisibleMetas(e){let t=this.chart.getSortedVisibleDatasetMetas(),n=this.axis+`AxisID`,r=[],i,a;for(i=0,a=t.length;i<a;++i){let a=t[i];a[n]===this.id&&(!e||a.type===e)&&r.push(a)}return r}_resolveTickFontOptions(e){return Z(this.options.ticks.setContext(this.getContext(e)).font)}_maxDigits(){let e=this._resolveTickFontOptions(0).lineHeight;return(this.isHorizontal()?this.width:this.height)/e}},pl=class{constructor(e,t,n){this.type=e,this.scope=t,this.override=n,this.items=Object.create(null)}isForType(e){return Object.prototype.isPrototypeOf.call(this.type.prototype,e.prototype)}register(e){let t=Object.getPrototypeOf(e),n;gl(t)&&(n=this.register(t));let r=this.items,i=e.id,a=this.scope+`.`+i;if(!i)throw Error(`class does not have id: `+e);return i in r?a:(r[i]=e,ml(e,a,n),this.override&&Y.override(e.id,e.overrides),a)}get(e){return this.items[e]}unregister(e){let t=this.items,n=e.id,r=this.scope;n in t&&delete t[n],r&&n in Y[r]&&(delete Y[r][n],this.override&&delete aa[n])}};function ml(e,t,n){let r=Wr(Object.create(null),[n?Y.get(n):{},Y.get(t),e.defaults]);Y.set(t,r),e.defaultRoutes&&hl(t,e.defaultRoutes),e.descriptors&&Y.describe(t,e.descriptors)}function hl(e,t){Object.keys(t).forEach(n=>{let r=n.split(`.`),i=r.pop(),a=[e].concat(r).join(`.`),o=t[n].split(`.`),s=o.pop(),c=o.join(`.`);Y.route(a,i,c,s)})}function gl(e){return`id`in e&&`defaults`in e}var _l=new class{constructor(){this.controllers=new pl(ws,`datasets`,!0),this.elements=new pl(Kc,`elements`),this.plugins=new pl(Object,`plugins`),this.scales=new pl(fl,`scales`),this._typedRegistries=[this.controllers,this.scales,this.elements]}add(...e){this._each(`register`,e)}remove(...e){this._each(`unregister`,e)}addControllers(...e){this._each(`register`,e,this.controllers)}addElements(...e){this._each(`register`,e,this.elements)}addPlugins(...e){this._each(`register`,e,this.plugins)}addScales(...e){this._each(`register`,e,this.scales)}getController(e){return this._get(e,this.controllers,`controller`)}getElement(e){return this._get(e,this.elements,`element`)}getPlugin(e){return this._get(e,this.plugins,`plugin`)}getScale(e){return this._get(e,this.scales,`scale`)}removeControllers(...e){this._each(`unregister`,e,this.controllers)}removeElements(...e){this._each(`unregister`,e,this.elements)}removePlugins(...e){this._each(`unregister`,e,this.plugins)}removeScales(...e){this._each(`unregister`,e,this.scales)}_each(e,t,n){[...t].forEach(t=>{let r=n||this._getRegistryForType(t);n||r.isForType(t)||r===this.plugins&&t.id?this._exec(e,r,t):U(t,t=>{let r=n||this._getRegistryForType(t);this._exec(e,r,t)})})}_exec(e,t,n){let r=Zr(e);H(n[`before`+r],[],n),t[e](n),H(n[`after`+r],[],n)}_getRegistryForType(e){for(let t=0;t<this._typedRegistries.length;t++){let n=this._typedRegistries[t];if(n.isForType(e))return n}return this.plugins}_get(e,t,n){let r=t.get(e);if(r===void 0)throw Error(`"`+e+`" is not a registered `+n+`.`);return r}},vl=class{constructor(){this._init=void 0}notify(e,t,n,r){if(t===`beforeInit`&&(this._init=this._createDescriptors(e,!0),this._notify(this._init,e,`install`)),this._init===void 0)return;let i=r?this._descriptors(e).filter(r):this._descriptors(e),a=this._notify(i,e,t,n);return t===`afterDestroy`&&(this._notify(i,e,`stop`),this._notify(this._init,e,`uninstall`),this._init=void 0),a}_notify(e,t,n,r){r||={};for(let i of e){let e=i.plugin,a=e[n];if(H(a,[t,r,i.options],e)===!1&&r.cancelable)return!1}return!0}invalidate(){L(this._cache)||(this._oldCache=this._cache,this._cache=void 0)}_descriptors(e){if(this._cache)return this._cache;let t=this._cache=this._createDescriptors(e);return this._notifyStateChanges(e),t}_createDescriptors(e,t){let n=e&&e.config,r=V(n.options&&n.options.plugins,{}),i=yl(n);return r===!1&&!t?[]:xl(e,i,r,t)}_notifyStateChanges(e){let t=this._oldCache||[],n=this._cache,r=(e,t)=>e.filter(e=>!t.some(t=>e.plugin.id===t.plugin.id));this._notify(r(t,n),e,`stop`),this._notify(r(n,t),e,`start`)}};function yl(e){let t={},n=[],r=Object.keys(_l.plugins.items);for(let e=0;e<r.length;e++)n.push(_l.getPlugin(r[e]));let i=e.plugins||[];for(let e=0;e<i.length;e++){let r=i[e];n.indexOf(r)===-1&&(n.push(r),t[r.id]=!0)}return{plugins:n,localIds:t}}function bl(e,t){return!t&&e===!1?null:e===!0?{}:e}function xl(e,{plugins:t,localIds:n},r,i){let a=[],o=e.getContext();for(let s of t){let t=s.id,c=bl(r[t],i);c!==null&&a.push({plugin:s,options:Sl(e.config,{plugin:s,local:n[t]},c,o)})}return a}function Sl(e,{plugin:t,local:n},r,i){let a=e.pluginScopeKeys(t),o=e.getOptionScopes(r,a);return n&&t.defaults&&o.push(t.defaults),e.createResolver(o,i,[``],{scriptable:!1,indexable:!1,allKeys:!0})}function Cl(e,t){let n=Y.datasets[e]||{};return((t.datasets||{})[e]||{}).indexAxis||t.indexAxis||n.indexAxis||`x`}function wl(e,t){let n=e;return e===`_index_`?n=t:e===`_value_`&&(n=t===`x`?`y`:`x`),n}function Tl(e,t){return e===t?`_index_`:`_value_`}function El(e){if(e===`x`||e===`y`||e===`r`)return e}function Dl(e){if(e===`top`||e===`bottom`)return`x`;if(e===`left`||e===`right`)return`y`}function Ol(e,...t){if(El(e))return e;for(let n of t){let t=n.axis||Dl(n.position)||e.length>1&&El(e[0].toLowerCase());if(t)return t}throw Error(`Cannot determine type of '${e}' axis. Please provide 'axis' or 'position' option.`)}function kl(e,t,n){if(n[t+`AxisID`]===e)return{axis:t}}function Al(e,t){if(t.data&&t.data.datasets){let n=t.data.datasets.filter(t=>t.xAxisID===e||t.yAxisID===e);if(n.length)return kl(e,`x`,n[0])||kl(e,`y`,n[0])}return{}}function jl(e,t){let n=aa[e.type]||{scales:{}},r=t.scales||{},i=Cl(e.type,t),a=Object.create(null);return Object.keys(r).forEach(t=>{let o=r[t];if(!z(o))return console.error(`Invalid scale configuration for scale: ${t}`);if(o._proxy)return console.warn(`Ignoring resolver passed as options for scale: ${t}`);let s=Ol(t,o,Al(t,e),Y.scales[o.type]),c=Tl(s,i),l=n.scales||{};a[t]=Gr(Object.create(null),[{axis:s},o,l[s],l[c]])}),e.data.datasets.forEach(n=>{let i=n.type||e.type,o=n.indexAxis||Cl(i,t),s=(aa[i]||{}).scales||{};Object.keys(s).forEach(e=>{let t=wl(e,o),i=n[t+`AxisID`]||t;a[i]=a[i]||Object.create(null),Gr(a[i],[{axis:t},r[i],s[e]])})}),Object.keys(a).forEach(e=>{let t=a[e];Gr(t,[Y.scales[t.type],Y.scale])}),a}function Ml(e){let t=e.options||={};t.plugins=V(t.plugins,{}),t.scales=jl(e,t)}function Nl(e){return e||={},e.datasets=e.datasets||[],e.labels=e.labels||[],e}function Pl(e){return e||={},e.data=Nl(e.data),Ml(e),e}var Fl=new Map,Il=new Set;function Ll(e,t){let n=Fl.get(e);return n||(n=t(),Fl.set(e,n),Il.add(n)),n}var Rl=(e,t,n)=>{let r=Xr(t,n);r!==void 0&&e.add(r)},zl=class{constructor(e){this._config=Pl(e),this._scopeCache=new Map,this._resolverCache=new Map}get platform(){return this._config.platform}get type(){return this._config.type}set type(e){this._config.type=e}get data(){return this._config.data}set data(e){this._config.data=Nl(e)}get options(){return this._config.options}set options(e){this._config.options=e}get plugins(){return this._config.plugins}update(){let e=this._config;this.clearCache(),Ml(e)}clearCache(){this._scopeCache.clear(),this._resolverCache.clear()}datasetScopeKeys(e){return Ll(e,()=>[[`datasets.${e}`,``]])}datasetAnimationScopeKeys(e,t){return Ll(`${e}.transition.${t}`,()=>[[`datasets.${e}.transitions.${t}`,`transitions.${t}`],[`datasets.${e}`,``]])}datasetElementScopeKeys(e,t){return Ll(`${e}-${t}`,()=>[[`datasets.${e}.elements.${t}`,`datasets.${e}`,`elements.${t}`,``]])}pluginScopeKeys(e){let t=e.id,n=this.type;return Ll(`${n}-plugin-${t}`,()=>[[`plugins.${t}`,...e.additionalOptionScopes||[]]])}_cachedScopes(e,t){let n=this._scopeCache,r=n.get(e);return(!r||t)&&(r=new Map,n.set(e,r)),r}getOptionScopes(e,t,n){let{options:r,type:i}=this,a=this._cachedScopes(e,n),o=a.get(t);if(o)return o;let s=new Set;t.forEach(t=>{e&&(s.add(e),t.forEach(t=>Rl(s,e,t))),t.forEach(e=>Rl(s,r,e)),t.forEach(e=>Rl(s,aa[i]||{},e)),t.forEach(e=>Rl(s,Y,e)),t.forEach(e=>Rl(s,oa,e))});let c=Array.from(s);return c.length===0&&c.push(Object.create(null)),Il.has(t)&&a.set(t,c),c}chartOptionScopes(){let{options:e,type:t}=this;return[e,aa[t]||{},Y.datasets[t]||{},{type:t},Y,oa]}resolveNamedOptions(e,t,n,r=[``]){let i={$shared:!0},{resolver:a,subPrefixes:o}=Bl(this._resolverCache,e,r),s=a;if(Hl(a,t)){i.$shared=!1,n=$r(n)?n():n;let t=this.createResolver(e,n,o);s=La(a,n,t)}for(let e of t)i[e]=s[e];return i}createResolver(e,t,n=[``],r){let{resolver:i}=Bl(this._resolverCache,e,n);return z(t)?La(i,t,void 0,r):i}};function Bl(e,t,n){let r=e.get(t);r||(r=new Map,e.set(t,r));let i=n.join(),a=r.get(i);return a||(a={resolver:Ia(t,n),subPrefixes:n.filter(e=>!e.toLowerCase().includes(`hover`))},r.set(i,a)),a}var Vl=e=>z(e)&&Object.getOwnPropertyNames(e).some(t=>$r(e[t]));function Hl(e,t){let{isScriptable:n,isIndexable:r}=Ra(e);for(let i of t){let t=n(i),a=r(i),o=(a||t)&&e[i];if(t&&($r(o)||Vl(o))||a&&R(o))return!0}return!1}var Ul=`4.5.1`,Wl=[`top`,`bottom`,`left`,`right`,`chartArea`];function Gl(e,t){return e===`top`||e===`bottom`||Wl.indexOf(e)===-1&&t===`x`}function Kl(e,t){return function(n,r){return n[e]===r[e]?n[t]-r[t]:n[e]-r[e]}}function ql(e){let t=e.chart,n=t.options.animation;t.notifyPlugins(`afterRender`),H(n&&n.onComplete,[e],t)}function Jl(e){let t=e.chart,n=t.options.animation;H(n&&n.onProgress,[e],t)}function Yl(e){return po()&&typeof e==`string`?e=document.getElementById(e):e&&e.length&&(e=e[0]),e&&e.canvas&&(e=e.canvas),e}var Xl={},Zl=e=>{let t=Yl(e);return Object.values(Xl).filter(e=>e.canvas===t).pop()};function Ql(e,t,n){let r=Object.keys(e);for(let i of r){let r=+i;if(r>=t){let a=e[i];delete e[i],(n>0||r>t)&&(e[r+n]=a)}}}function $l(e,t,n,r){return!n||e.type===`mouseout`?null:r?t:e}var eu=class{static register(...e){_l.add(...e),tu()}static unregister(...e){_l.remove(...e),tu()}constructor(e,t){let n=this.config=new zl(t),r=Yl(e),i=Zl(r);if(i)throw Error(`Canvas is already in use. Chart with ID '`+i.id+`' must be destroyed before the canvas with ID '`+i.canvas.id+`' can be reused.`);let a=n.createResolver(n.chartOptionScopes(),this.getContext());this.platform=new(n.platform||(Gc(r))),this.platform.updateConfig(n);let o=this.platform.acquireContext(r,a.aspectRatio),s=o&&o.canvas,c=s&&s.height,l=s&&s.width;if(this.id=Ir(),this.ctx=o,this.canvas=s,this.width=l,this.height=c,this._options=a,this._aspectRatio=this.aspectRatio,this._layers=[],this._metasets=[],this._stacks=void 0,this.boxes=[],this.currentDevicePixelRatio=void 0,this.chartArea=void 0,this._active=[],this._lastEvent=void 0,this._listeners={},this._responsiveListeners=void 0,this._sortedMetasets=[],this.scales={},this._plugins=new vl,this.$proxies={},this._hiddenIndices={},this.attached=!1,this._animationsDisabled=void 0,this.$context=void 0,this._doResize=Fi(e=>this.update(e),a.resizeDelay||0),this._dataChanges=[],Xl[this.id]=this,!o||!s){console.error(`Failed to create chart: can't acquire context from the given item`);return}Qo.listen(this,`complete`,ql),Qo.listen(this,`progress`,Jl),this._initialize(),this.attached&&this.update()}get aspectRatio(){let{options:{aspectRatio:e,maintainAspectRatio:t},width:n,height:r,_aspectRatio:i}=this;return L(e)?t&&i?i:r?n/r:null:e}get data(){return this.config.data}set data(e){this.config.data=e}get options(){return this._options}set options(e){this.config.options=e}get registry(){return _l}_initialize(){return this.notifyPlugins(`beforeInit`),this.options.responsive?this.resize():Eo(this,this.options.devicePixelRatio),this.bindEvents(),this.notifyPlugins(`afterInit`),this}clear(){return pa(this.canvas,this.ctx),this}stop(){return Qo.stop(this),this}resize(e,t){Qo.running(this)?this._resizeBeforeDraw={width:e,height:t}:this._resize(e,t)}_resize(e,t){let n=this.options,r=this.canvas,i=n.maintainAspectRatio&&this.aspectRatio,a=this.platform.getMaximumSize(r,e,t,i),o=n.devicePixelRatio||this.platform.getDevicePixelRatio(),s=this.width?`resize`:`attach`;this.width=a.width,this.height=a.height,this._aspectRatio=this.aspectRatio,Eo(this,o,!0)&&(this.notifyPlugins(`resize`,{size:a}),H(n.onResize,[this,a],this),this.attached&&this._doResize(s)&&this.render())}ensureScalesHaveIDs(){U(this.options.scales||{},(e,t)=>{e.id=t})}buildOrUpdateScales(){let e=this.options,t=e.scales,n=this.scales,r=Object.keys(n).reduce((e,t)=>(e[t]=!1,e),{}),i=[];t&&(i=i.concat(Object.keys(t).map(e=>{let n=t[e],r=Ol(e,n),i=r===`r`,a=r===`x`;return{options:n,dposition:i?`chartArea`:a?`bottom`:`left`,dtype:i?`radialLinear`:a?`category`:`linear`}}))),U(i,t=>{let i=t.options,a=i.id,o=Ol(a,i),s=V(i.type,t.dtype);(i.position===void 0||Gl(i.position,o)!==Gl(t.dposition))&&(i.position=t.dposition),r[a]=!0;let c=null;a in n&&n[a].type===s?c=n[a]:(c=new(_l.getScale(s))({id:a,type:s,ctx:this.ctx,chart:this}),n[c.id]=c),c.init(i,e)}),U(r,(e,t)=>{e||delete n[t]}),U(n,e=>{Sc.configure(this,e,e.options),Sc.addBox(this,e)})}_updateMetasets(){let e=this._metasets,t=this.data.datasets.length,n=e.length;if(e.sort((e,t)=>e.index-t.index),n>t){for(let e=t;e<n;++e)this._destroyDatasetMeta(e);e.splice(t,n-t)}this._sortedMetasets=e.slice(0).sort(Kl(`order`,`index`))}_removeUnreferencedMetasets(){let{_metasets:e,data:{datasets:t}}=this;e.length>t.length&&delete this._stacks,e.forEach((e,n)=>{t.filter(t=>t===e._dataset).length===0&&this._destroyDatasetMeta(n)})}buildOrUpdateControllers(){let e=[],t=this.data.datasets,n,r;for(this._removeUnreferencedMetasets(),n=0,r=t.length;n<r;n++){let r=t[n],i=this.getDatasetMeta(n),a=r.type||this.config.type;if(i.type&&i.type!==a&&(this._destroyDatasetMeta(n),i=this.getDatasetMeta(n)),i.type=a,i.indexAxis=r.indexAxis||Cl(a,this.options),i.order=r.order||0,i.index=n,i.label=``+r.label,i.visible=this.isDatasetVisible(n),i.controller)i.controller.updateIndex(n),i.controller.linkScales();else{let t=_l.getController(a),{datasetElementType:r,dataElementType:o}=Y.datasets[a];Object.assign(t,{dataElementType:_l.getElement(o),datasetElementType:r&&_l.getElement(r)}),i.controller=new t(this,n),e.push(i.controller)}}return this._updateMetasets(),e}_resetElements(){U(this.data.datasets,(e,t)=>{this.getDatasetMeta(t).controller.reset()},this)}reset(){this._resetElements(),this.notifyPlugins(`reset`)}update(e){let t=this.config;t.update();let n=this._options=t.createResolver(t.chartOptionScopes(),this.getContext()),r=this._animationsDisabled=!n.animation;if(this._updateScales(),this._checkEventBindings(),this._updateHiddenIndices(),this._plugins.invalidate(),this.notifyPlugins(`beforeUpdate`,{mode:e,cancelable:!0})===!1)return;let i=this.buildOrUpdateControllers();this.notifyPlugins(`beforeElementsUpdate`);let a=0;for(let e=0,t=this.data.datasets.length;e<t;e++){let{controller:t}=this.getDatasetMeta(e),n=!r&&i.indexOf(t)===-1;t.buildOrUpdateElements(n),a=Math.max(+t.getMaxOverflow(),a)}a=this._minPadding=n.layout.autoPadding?a:0,this._updateLayout(a),r||U(i,e=>{e.reset()}),this._updateDatasets(e),this.notifyPlugins(`afterUpdate`,{mode:e}),this._layers.sort(Kl(`z`,`_idx`));let{_active:o,_lastEvent:s}=this;s?this._eventHandler(s,!0):o.length&&this._updateHoverStyles(o,o,!0),this.render()}_updateScales(){U(this.scales,e=>{Sc.removeBox(this,e)}),this.ensureScalesHaveIDs(),this.buildOrUpdateScales()}_checkEventBindings(){let e=this.options;(!ei(new Set(Object.keys(this._listeners)),new Set(e.events))||!!this._responsiveListeners!==e.responsive)&&(this.unbindEvents(),this.bindEvents())}_updateHiddenIndices(){let{_hiddenIndices:e}=this,t=this._getUniformDataChanges()||[];for(let{method:n,start:r,count:i}of t)Ql(e,r,n===`_removeElements`?-i:i)}_getUniformDataChanges(){let e=this._dataChanges;if(!e||!e.length)return;this._dataChanges=[];let t=this.data.datasets.length,n=t=>new Set(e.filter(e=>e[0]===t).map((e,t)=>t+`,`+e.splice(1).join(`,`))),r=n(0);for(let e=1;e<t;e++)if(!ei(r,n(e)))return;return Array.from(r).map(e=>e.split(`,`)).map(e=>({method:e[1],start:+e[2],count:+e[3]}))}_updateLayout(e){if(this.notifyPlugins(`beforeLayout`,{cancelable:!0})===!1)return;Sc.update(this,this.width,this.height,e);let t=this.chartArea,n=t.width<=0||t.height<=0;this._layers=[],U(this.boxes,e=>{n&&e.position===`chartArea`||(e.configure&&e.configure(),this._layers.push(...e._layers()))},this),this._layers.forEach((e,t)=>{e._idx=t}),this.notifyPlugins(`afterLayout`)}_updateDatasets(e){if(this.notifyPlugins(`beforeDatasetsUpdate`,{mode:e,cancelable:!0})!==!1){for(let e=0,t=this.data.datasets.length;e<t;++e)this.getDatasetMeta(e).controller.configure();for(let t=0,n=this.data.datasets.length;t<n;++t)this._updateDataset(t,$r(e)?e({datasetIndex:t}):e);this.notifyPlugins(`afterDatasetsUpdate`,{mode:e})}}_updateDataset(e,t){let n=this.getDatasetMeta(e),r={meta:n,index:e,mode:t,cancelable:!0};this.notifyPlugins(`beforeDatasetUpdate`,r)!==!1&&(n.controller._update(t),r.cancelable=!1,this.notifyPlugins(`afterDatasetUpdate`,r))}render(){this.notifyPlugins(`beforeRender`,{cancelable:!0})!==!1&&(Qo.has(this)?this.attached&&!Qo.running(this)&&Qo.start(this):(this.draw(),ql({chart:this})))}draw(){let e;if(this._resizeBeforeDraw){let{width:e,height:t}=this._resizeBeforeDraw;this._resizeBeforeDraw=null,this._resize(e,t)}if(this.clear(),this.width<=0||this.height<=0||this.notifyPlugins(`beforeDraw`,{cancelable:!0})===!1)return;let t=this._layers;for(e=0;e<t.length&&t[e].z<=0;++e)t[e].draw(this.chartArea);for(this._drawDatasets();e<t.length;++e)t[e].draw(this.chartArea);this.notifyPlugins(`afterDraw`)}_getSortedDatasetMetas(e){let t=this._sortedMetasets,n=[],r,i;for(r=0,i=t.length;r<i;++r){let i=t[r];(!e||i.visible)&&n.push(i)}return n}getSortedVisibleDatasetMetas(){return this._getSortedDatasetMetas(!0)}_drawDatasets(){if(this.notifyPlugins(`beforeDatasetsDraw`,{cancelable:!0})===!1)return;let e=this.getSortedVisibleDatasetMetas();for(let t=e.length-1;t>=0;--t)this._drawDataset(e[t]);this.notifyPlugins(`afterDatasetsDraw`)}_drawDataset(e){let t=this.ctx,n={meta:e,index:e.index,cancelable:!0},r=Zo(this,e);this.notifyPlugins(`beforeDatasetDraw`,n)!==!1&&(r&&_a(t,r),e.controller.draw(),r&&va(t),n.cancelable=!1,this.notifyPlugins(`afterDatasetDraw`,n))}isPointInArea(e){return ga(e,this.chartArea,this._minPadding)}getElementsAtEventForMode(e,t,n,r){let i=ac.modes[t];return typeof i==`function`?i(this,e,n,r):[]}getDatasetMeta(e){let t=this.data.datasets[e],n=this._metasets,r=n.filter(e=>e&&e._dataset===t).pop();return r||(r={type:null,data:[],dataset:null,controller:null,hidden:null,xAxisID:null,yAxisID:null,order:t&&t.order||0,index:e,_dataset:t,_parsed:[],_sorted:!1},n.push(r)),r}getContext(){return this.$context||=Fa(null,{chart:this,type:`chart`})}getVisibleDatasetCount(){return this.getSortedVisibleDatasetMetas().length}isDatasetVisible(e){let t=this.data.datasets[e];if(!t)return!1;let n=this.getDatasetMeta(e);return typeof n.hidden==`boolean`?!n.hidden:!t.hidden}setDatasetVisibility(e,t){let n=this.getDatasetMeta(e);n.hidden=!t}toggleDataVisibility(e){this._hiddenIndices[e]=!this._hiddenIndices[e]}getDataVisibility(e){return!this._hiddenIndices[e]}_updateVisibility(e,t,n){let r=n?`show`:`hide`,i=this.getDatasetMeta(e),a=i.controller._resolveAnimations(void 0,r);Qr(t)?(i.data[t].hidden=!n,this.update()):(this.setDatasetVisibility(e,n),a.update(i,{visible:n}),this.update(t=>t.datasetIndex===e?r:void 0))}hide(e,t){this._updateVisibility(e,t,!1)}show(e,t){this._updateVisibility(e,t,!0)}_destroyDatasetMeta(e){let t=this._metasets[e];t&&t.controller&&t.controller._destroy(),delete this._metasets[e]}_stop(){let e,t;for(this.stop(),Qo.remove(this),e=0,t=this.data.datasets.length;e<t;++e)this._destroyDatasetMeta(e)}destroy(){this.notifyPlugins(`beforeDestroy`);let{canvas:e,ctx:t}=this;this._stop(),this.config.clearCache(),e&&(this.unbindEvents(),pa(e,t),this.platform.releaseContext(t),this.canvas=null,this.ctx=null),delete Xl[this.id],this.notifyPlugins(`afterDestroy`)}toBase64Image(...e){return this.canvas.toDataURL(...e)}bindEvents(){this.bindUserEvents(),this.options.responsive?this.bindResponsiveEvents():this.attached=!0}bindUserEvents(){let e=this._listeners,t=this.platform,n=(n,r)=>{t.addEventListener(this,n,r),e[n]=r},r=(e,t,n)=>{e.offsetX=t,e.offsetY=n,this._eventHandler(e)};U(this.options.events,e=>n(e,r))}bindResponsiveEvents(){this._responsiveListeners||={};let e=this._responsiveListeners,t=this.platform,n=(n,r)=>{t.addEventListener(this,n,r),e[n]=r},r=(n,r)=>{e[n]&&(t.removeEventListener(this,n,r),delete e[n])},i=(e,t)=>{this.canvas&&this.resize(e,t)},a,o=()=>{r(`attach`,o),this.attached=!0,this.resize(),n(`resize`,i),n(`detach`,a)};a=()=>{this.attached=!1,r(`resize`,i),this._stop(),this._resize(0,0),n(`attach`,o)},t.isAttached(this.canvas)?o():a()}unbindEvents(){U(this._listeners,(e,t)=>{this.platform.removeEventListener(this,t,e)}),this._listeners={},U(this._responsiveListeners,(e,t)=>{this.platform.removeEventListener(this,t,e)}),this._responsiveListeners=void 0}updateHoverStyle(e,t,n){let r=n?`set`:`remove`,i,a,o,s;for(t===`dataset`&&(i=this.getDatasetMeta(e[0].datasetIndex),i.controller[`_`+r+`DatasetHoverStyle`]()),o=0,s=e.length;o<s;++o){a=e[o];let t=a&&this.getDatasetMeta(a.datasetIndex).controller;t&&t[r+`HoverStyle`](a.element,a.datasetIndex,a.index)}}getActiveElements(){return this._active||[]}setActiveElements(e){let t=this._active||[],n=e.map(({datasetIndex:e,index:t})=>{let n=this.getDatasetMeta(e);if(!n)throw Error(`No dataset found at index `+e);return{datasetIndex:e,element:n.data[t],index:t}});Br(n,t)||(this._active=n,this._lastEvent=null,this._updateHoverStyles(n,t))}notifyPlugins(e,t,n){return this._plugins.notify(this,e,t,n)}isPluginEnabled(e){return this._plugins._cache.filter(t=>t.plugin.id===e).length===1}_updateHoverStyles(e,t,n){let r=this.options.hover,i=(e,t)=>e.filter(e=>!t.some(t=>e.datasetIndex===t.datasetIndex&&e.index===t.index)),a=i(t,e),o=n?e:i(e,t);a.length&&this.updateHoverStyle(a,r.mode,!1),o.length&&r.mode&&this.updateHoverStyle(o,r.mode,!0)}_eventHandler(e,t){let n={event:e,replay:t,cancelable:!0,inChartArea:this.isPointInArea(e)},r=t=>(t.options.events||this.options.events).includes(e.native.type);if(this.notifyPlugins(`beforeEvent`,n,r)===!1)return;let i=this._handleEvent(e,t,n.inChartArea);return n.cancelable=!1,this.notifyPlugins(`afterEvent`,n,r),(i||n.changed)&&this.render(),this}_handleEvent(e,t,n){let{_active:r=[],options:i}=this,a=t,o=this._getActiveElements(e,r,n,a),s=ti(e),c=$l(e,this._lastEvent,n,s);n&&(this._lastEvent=null,H(i.onHover,[e,o,this],this),s&&H(i.onClick,[e,o,this],this));let l=!Br(o,r);return(l||t)&&(this._active=o,this._updateHoverStyles(o,r,t)),this._lastEvent=c,l}_getActiveElements(e,t,n,r){if(e.type===`mouseout`)return[];if(!n)return t;let i=this.options.hover;return this.getElementsAtEventForMode(e,i.mode,i,r)}};f(eu,`defaults`,Y),f(eu,`instances`,Xl),f(eu,`overrides`,aa),f(eu,`registry`,_l),f(eu,`version`,Ul),f(eu,`getChart`,Zl);function tu(){return U(eu.instances,e=>e._plugins.invalidate())}function nu(e,t,n){let{startAngle:r,x:i,y:a,outerRadius:o,innerRadius:s,options:c}=t,{borderWidth:l,borderJoinStyle:u}=c,d=Math.min(l/o,q(r-n));if(e.beginPath(),e.arc(i,a,o-l/2,r+d/2,n-d/2),s>0){let t=Math.min(l/s,q(r-n));e.arc(i,a,s+l/2,n-t/2,r+t/2,!0)}else{let t=Math.min(l/2,o*q(r-n));if(u===`round`)e.arc(i,a,t,n-W/2,r+W/2,!0);else if(u===`bevel`){let o=2*t*t,s=-o*Math.cos(n+W/2)+i,c=-o*Math.sin(n+W/2)+a,l=o*Math.cos(r+W/2)+i,u=o*Math.sin(r+W/2)+a;e.lineTo(s,c),e.lineTo(l,u)}}e.closePath(),e.moveTo(0,0),e.rect(0,0,e.canvas.width,e.canvas.height),e.clip(`evenodd`)}function ru(e,t,n){let{startAngle:r,pixelMargin:i,x:a,y:o,outerRadius:s,innerRadius:c}=t,l=i/s;e.beginPath(),e.arc(a,o,s,r-l,n+l),c>i?(l=i/c,e.arc(a,o,c,n+l,r-l,!0)):e.arc(a,o,i,n+K,r-K),e.closePath(),e.clip()}function iu(e){return Aa(e,[`outerStart`,`outerEnd`,`innerStart`,`innerEnd`])}function au(e,t,n,r){let i=iu(e.options.borderRadius),a=(n-t)/2,o=Math.min(a,r*t/2),s=e=>{let t=(n-Math.min(a,e))*r/2;return J(e,0,Math.min(a,t))};return{outerStart:s(i.outerStart),outerEnd:s(i.outerEnd),innerStart:J(i.innerStart,0,o),innerEnd:J(i.innerEnd,0,o)}}function ou(e,t,n,r){return{x:n+e*Math.cos(t),y:r+e*Math.sin(t)}}function su(e,t,n,r,i,a){let{x:o,y:s,startAngle:c,pixelMargin:l,innerRadius:u}=t,d=Math.max(t.outerRadius+r+n-l,0),f=u>0?u+r+n+l:0,p=0,m=i-c;if(r){let e=((u>0?u-r:0)+(d>0?d-r:0))/2;p=(m-(e===0?m:m*e/(e+r)))/2}let h=(m-Math.max(.001,m*d-n/W)/d)/2,g=c+h+p,_=i-h-p,{outerStart:v,outerEnd:y,innerStart:b,innerEnd:x}=au(t,f,d,_-g),S=d-v,C=d-y,w=g+v/S,T=_-y/C,E=f+b,D=f+x,ee=g+b/E,te=_-x/D;if(e.beginPath(),a){let t=(w+T)/2;if(e.arc(o,s,d,w,t),e.arc(o,s,d,t,T),y>0){let t=ou(C,T,o,s);e.arc(t.x,t.y,y,T,_+K)}let n=ou(D,_,o,s);if(e.lineTo(n.x,n.y),x>0){let t=ou(D,te,o,s);e.arc(t.x,t.y,x,_+K,te+Math.PI)}let r=(_-x/f+(g+b/f))/2;if(e.arc(o,s,f,_-x/f,r,!0),e.arc(o,s,f,r,g+b/f,!0),b>0){let t=ou(E,ee,o,s);e.arc(t.x,t.y,b,ee+Math.PI,g-K)}let i=ou(S,g,o,s);if(e.lineTo(i.x,i.y),v>0){let t=ou(S,w,o,s);e.arc(t.x,t.y,v,g-K,w)}}else{e.moveTo(o,s);let t=Math.cos(w)*d+o,n=Math.sin(w)*d+s;e.lineTo(t,n);let r=Math.cos(T)*d+o,i=Math.sin(T)*d+s;e.lineTo(r,i)}e.closePath()}function cu(e,t,n,r,i){let{fullCircles:a,startAngle:o,circumference:s}=t,c=t.endAngle;if(a){su(e,t,n,r,c,i);for(let t=0;t<a;++t)e.fill();isNaN(s)||(c=o+(s%G||G))}return su(e,t,n,r,c,i),e.fill(),c}function lu(e,t,n,r,i){let{fullCircles:a,startAngle:o,circumference:s,options:c}=t,{borderWidth:l,borderJoinStyle:u,borderDash:d,borderDashOffset:f,borderRadius:p}=c,m=c.borderAlign===`inner`;if(!l)return;e.setLineDash(d||[]),e.lineDashOffset=f,m?(e.lineWidth=l*2,e.lineJoin=u||`round`):(e.lineWidth=l,e.lineJoin=u||`bevel`);let h=t.endAngle;if(a){su(e,t,n,r,h,i);for(let t=0;t<a;++t)e.stroke();isNaN(s)||(h=o+(s%G||G))}m&&ru(e,t,h),c.selfJoin&&h-o>=W&&p===0&&u!==`miter`&&nu(e,t,h),a||(su(e,t,n,r,h,i),e.stroke())}var uu=class extends Kc{constructor(e){super(),f(this,`circumference`,void 0),f(this,`endAngle`,void 0),f(this,`fullCircles`,void 0),f(this,`innerRadius`,void 0),f(this,`outerRadius`,void 0),f(this,`pixelMargin`,void 0),f(this,`startAngle`,void 0),this.options=void 0,this.circumference=void 0,this.startAngle=void 0,this.endAngle=void 0,this.innerRadius=void 0,this.outerRadius=void 0,this.pixelMargin=0,this.fullCircles=0,e&&Object.assign(this,e)}inRange(e,t,n){let{angle:r,distance:i}=yi(this.getProps([`x`,`y`],n),{x:e,y:t}),{startAngle:a,endAngle:o,innerRadius:s,outerRadius:c,circumference:l}=this.getProps([`startAngle`,`endAngle`,`innerRadius`,`outerRadius`,`circumference`],n),u=(this.options.spacing+this.options.borderWidth)/2,d=V(l,o-a),f=Si(r,a,o)&&a!==o,p=d>=G||f,m=wi(i,s+u,c+u);return p&&m}getCenterPoint(e){let{x:t,y:n,startAngle:r,endAngle:i,innerRadius:a,outerRadius:o}=this.getProps([`x`,`y`,`startAngle`,`endAngle`,`innerRadius`,`outerRadius`],e),{offset:s,spacing:c}=this.options,l=(r+i)/2,u=(a+o+c+s)/2;return{x:t+Math.cos(l)*u,y:n+Math.sin(l)*u}}tooltipPosition(e){return this.getCenterPoint(e)}draw(e){let{options:t,circumference:n}=this,r=(t.offset||0)/4,i=(t.spacing||0)/2,a=t.circular;if(this.pixelMargin=t.borderAlign===`inner`?.33:0,this.fullCircles=n>G?Math.floor(n/G):0,n===0||this.innerRadius<0||this.outerRadius<0)return;e.save();let o=(this.startAngle+this.endAngle)/2;e.translate(Math.cos(o)*r,Math.sin(o)*r);let s=r*(1-Math.sin(Math.min(W,n||0)));e.fillStyle=t.backgroundColor,e.strokeStyle=t.borderColor,cu(e,this,s,i,a),lu(e,this,s,i,a),e.restore()}};f(uu,`id`,`arc`),f(uu,`defaults`,{borderAlign:`center`,borderColor:`#fff`,borderDash:[],borderDashOffset:0,borderJoinStyle:void 0,borderRadius:0,borderWidth:2,offset:0,spacing:0,angle:void 0,circular:!0,selfJoin:!1}),f(uu,`defaultRoutes`,{backgroundColor:`backgroundColor`}),f(uu,`descriptors`,{_scriptable:!0,_indexable:e=>e!==`borderDash`});function du(e,t,n=t){e.lineCap=V(n.borderCapStyle,t.borderCapStyle),e.setLineDash(V(n.borderDash,t.borderDash)),e.lineDashOffset=V(n.borderDashOffset,t.borderDashOffset),e.lineJoin=V(n.borderJoinStyle,t.borderJoinStyle),e.lineWidth=V(n.borderWidth,t.borderWidth),e.strokeStyle=V(n.borderColor,t.borderColor)}function fu(e,t,n){e.lineTo(n.x,n.y)}function pu(e){return e.stepped?ya:e.tension||e.cubicInterpolationMode===`monotone`?ba:fu}function mu(e,t,n={}){let r=e.length,{start:i=0,end:a=r-1}=n,{start:o,end:s}=t,c=Math.max(i,o),l=Math.min(a,s),u=i<o&&a<o||i>s&&a>s;return{count:r,start:c,loop:t.loop,ilen:l<c&&!u?r+l-c:l-c}}function hu(e,t,n,r){let{points:i,options:a}=t,{count:o,start:s,loop:c,ilen:l}=mu(i,n,r),u=pu(a),{move:d=!0,reverse:f}=r||{},p,m,h;for(p=0;p<=l;++p)m=i[(s+(f?l-p:p))%o],!m.skip&&(d?(e.moveTo(m.x,m.y),d=!1):u(e,h,m,f,a.stepped),h=m);return c&&(m=i[(s+(f?l:0))%o],u(e,h,m,f,a.stepped)),!!c}function gu(e,t,n,r){let i=t.points,{count:a,start:o,ilen:s}=mu(i,n,r),{move:c=!0,reverse:l}=r||{},u=0,d=0,f,p,m,h,g,_,v=e=>(o+(l?s-e:e))%a,y=()=>{h!==g&&(e.lineTo(u,g),e.lineTo(u,h),e.lineTo(u,_))};for(c&&(p=i[v(0)],e.moveTo(p.x,p.y)),f=0;f<=s;++f){if(p=i[v(f)],p.skip)continue;let t=p.x,n=p.y,r=t|0;r===m?(n<h?h=n:n>g&&(g=n),u=(d*u+t)/++d):(y(),e.lineTo(t,n),m=r,d=0,h=g=n),_=n}y()}function _u(e){let t=e.options,n=t.borderDash&&t.borderDash.length;return!e._decimated&&!e._loop&&!t.tension&&t.cubicInterpolationMode!==`monotone`&&!t.stepped&&!n?gu:hu}function vu(e){return e.stepped?Ao:e.tension||e.cubicInterpolationMode===`monotone`?jo:ko}function yu(e,t,n,r){let i=t._path;i||(i=t._path=new Path2D,t.path(i,n,r)&&i.closePath()),du(e,t.options),e.stroke(i)}function bu(e,t,n,r){let{segments:i,options:a}=t,o=_u(t);for(let s of i)du(e,a,s.style),e.beginPath(),o(e,t,s,{start:n,end:n+r-1})&&e.closePath(),e.stroke()}var xu=typeof Path2D==`function`;function Su(e,t,n,r){xu&&!t.options.segment?yu(e,t,n,r):bu(e,t,n,r)}var Cu=class extends Kc{constructor(e){super(),this.animated=!0,this.options=void 0,this._chart=void 0,this._loop=void 0,this._fullLoop=void 0,this._path=void 0,this._points=void 0,this._segments=void 0,this._decimated=!1,this._pointsUpdated=!1,this._datasetIndex=void 0,e&&Object.assign(this,e)}updateControlPoints(e,t){let n=this.options;if((n.tension||n.cubicInterpolationMode===`monotone`)&&!n.stepped&&!this._pointsUpdated){let r=n.spanGaps?this._loop:this._fullLoop;fo(this._points,n,e,r,t),this._pointsUpdated=!0}}set points(e){this._points=e,delete this._segments,delete this._path,this._pointsUpdated=!1}get points(){return this._points}get segments(){return this._segments||=Wo(this,this.options.segment)}first(){let e=this.segments,t=this.points;return e.length&&t[e[0].start]}last(){let e=this.segments,t=this.points,n=e.length;return n&&t[e[n-1].end]}interpolate(e,t){let n=this.options,r=e[t],i=this.points,a=Vo(this,{property:t,start:r,end:r});if(!a.length)return;let o=[],s=vu(n),c,l;for(c=0,l=a.length;c<l;++c){let{start:l,end:u}=a[c],d=i[l],f=i[u];if(d===f){o.push(d);continue}let p=s(d,f,Math.abs((r-d[t])/(f[t]-d[t])),n.stepped);p[t]=e[t],o.push(p)}return o.length===1?o[0]:o}pathSegment(e,t,n){return _u(this)(e,this,t,n)}path(e,t,n){let r=this.segments,i=_u(this),a=this._loop;t||=0,n||=this.points.length-t;for(let o of r)a&=i(e,this,o,{start:t,end:t+n-1});return!!a}draw(e,t,n,r){let i=this.options||{};(this.points||[]).length&&i.borderWidth&&(e.save(),Su(e,this,n,r),e.restore()),this.animated&&(this._pointsUpdated=!1,this._path=void 0)}};f(Cu,`id`,`line`),f(Cu,`defaults`,{borderCapStyle:`butt`,borderDash:[],borderDashOffset:0,borderJoinStyle:`miter`,borderWidth:3,capBezierPoints:!0,cubicInterpolationMode:`default`,fill:!1,spanGaps:!1,stepped:!1,tension:0}),f(Cu,`defaultRoutes`,{backgroundColor:`backgroundColor`,borderColor:`borderColor`}),f(Cu,`descriptors`,{_scriptable:!0,_indexable:e=>e!==`borderDash`&&e!==`fill`});function wu(e,t,n,r){let i=e.options,{[n]:a}=e.getProps([n],r);return Math.abs(t-a)<i.radius+i.hitRadius}var Tu=class extends Kc{constructor(e){super(),f(this,`parsed`,void 0),f(this,`skip`,void 0),f(this,`stop`,void 0),this.options=void 0,this.parsed=void 0,this.skip=void 0,this.stop=void 0,e&&Object.assign(this,e)}inRange(e,t,n){let r=this.options,{x:i,y:a}=this.getProps([`x`,`y`],n);return(e-i)**2+(t-a)**2<(r.hitRadius+r.radius)**2}inXRange(e,t){return wu(this,e,`x`,t)}inYRange(e,t){return wu(this,e,`y`,t)}getCenterPoint(e){let{x:t,y:n}=this.getProps([`x`,`y`],e);return{x:t,y:n}}size(e){e=e||this.options||{};let t=e.radius||0;t=Math.max(t,t&&e.hoverRadius||0);let n=t&&e.borderWidth||0;return(t+n)*2}draw(e,t){let n=this.options;this.skip||n.radius<.1||!ga(this,t,this.size(n)/2)||(e.strokeStyle=n.borderColor,e.lineWidth=n.borderWidth,e.fillStyle=n.backgroundColor,ma(e,n,this.x,this.y))}getRange(){let e=this.options||{};return e.radius+e.hitRadius}};f(Tu,`id`,`point`),f(Tu,`defaults`,{borderWidth:1,hitRadius:1,hoverBorderWidth:1,hoverRadius:4,pointStyle:`circle`,radius:3,rotation:0}),f(Tu,`defaultRoutes`,{backgroundColor:`backgroundColor`,borderColor:`borderColor`});function Eu(e,t){let{x:n,y:r,base:i,width:a,height:o}=e.getProps([`x`,`y`,`base`,`width`,`height`],t),s,c,l,u,d;return e.horizontal?(d=o/2,s=Math.min(n,i),c=Math.max(n,i),l=r-d,u=r+d):(d=a/2,s=n-d,c=n+d,l=Math.min(r,i),u=Math.max(r,i)),{left:s,top:l,right:c,bottom:u}}function Du(e,t,n,r){return e?0:J(t,n,r)}function Ou(e,t,n){let r=e.options.borderWidth,i=e.borderSkipped,a=ja(r);return{t:Du(i.top,a.top,0,n),r:Du(i.right,a.right,0,t),b:Du(i.bottom,a.bottom,0,n),l:Du(i.left,a.left,0,t)}}function ku(e,t,n){let{enableBorderRadius:r}=e.getProps([`enableBorderRadius`]),i=e.options.borderRadius,a=Ma(i),o=Math.min(t,n),s=e.borderSkipped,c=r||z(i);return{topLeft:Du(!c||s.top||s.left,a.topLeft,0,o),topRight:Du(!c||s.top||s.right,a.topRight,0,o),bottomLeft:Du(!c||s.bottom||s.left,a.bottomLeft,0,o),bottomRight:Du(!c||s.bottom||s.right,a.bottomRight,0,o)}}function Au(e){let t=Eu(e),n=t.right-t.left,r=t.bottom-t.top,i=Ou(e,n/2,r/2),a=ku(e,n/2,r/2);return{outer:{x:t.left,y:t.top,w:n,h:r,radius:a},inner:{x:t.left+i.l,y:t.top+i.t,w:n-i.l-i.r,h:r-i.t-i.b,radius:{topLeft:Math.max(0,a.topLeft-Math.max(i.t,i.l)),topRight:Math.max(0,a.topRight-Math.max(i.t,i.r)),bottomLeft:Math.max(0,a.bottomLeft-Math.max(i.b,i.l)),bottomRight:Math.max(0,a.bottomRight-Math.max(i.b,i.r))}}}}function ju(e,t,n,r){let i=t===null,a=n===null,o=e&&!(i&&a)&&Eu(e,r);return o&&(i||wi(t,o.left,o.right))&&(a||wi(n,o.top,o.bottom))}function Mu(e){return e.topLeft||e.topRight||e.bottomLeft||e.bottomRight}function Nu(e,t){e.rect(t.x,t.y,t.w,t.h)}function Pu(e,t,n={}){let r=e.x===n.x?0:-t,i=e.y===n.y?0:-t,a=(e.x+e.w===n.x+n.w?0:t)-r,o=(e.y+e.h===n.y+n.h?0:t)-i;return{x:e.x+r,y:e.y+i,w:e.w+a,h:e.h+o,radius:e.radius}}var Fu=class extends Kc{constructor(e){super(),this.options=void 0,this.horizontal=void 0,this.base=void 0,this.width=void 0,this.height=void 0,this.inflateAmount=void 0,e&&Object.assign(this,e)}draw(e){let{inflateAmount:t,options:{borderColor:n,backgroundColor:r}}=this,{inner:i,outer:a}=Au(this),o=Mu(a.radius)?Ta:Nu;e.save(),(a.w!==i.w||a.h!==i.h)&&(e.beginPath(),o(e,Pu(a,t,i)),e.clip(),o(e,Pu(i,-t,a)),e.fillStyle=n,e.fill(`evenodd`)),e.beginPath(),o(e,Pu(i,t)),e.fillStyle=r,e.fill(),e.restore()}inRange(e,t,n){return ju(this,e,t,n)}inXRange(e,t){return ju(this,e,null,t)}inYRange(e,t){return ju(this,null,e,t)}getCenterPoint(e){let{x:t,y:n,base:r,horizontal:i}=this.getProps([`x`,`y`,`base`,`horizontal`],e);return{x:i?(t+r)/2:t,y:i?n:(n+r)/2}}getRange(e){return e===`x`?this.width/2:this.height/2}};f(Fu,`id`,`bar`),f(Fu,`defaults`,{borderSkipped:`start`,borderWidth:0,borderRadius:0,inflateAmount:`auto`,pointStyle:void 0}),f(Fu,`defaultRoutes`,{backgroundColor:`backgroundColor`,borderColor:`borderColor`});function Iu(e,t,n){let r=e.segments,i=e.points,a=t.points,o=[];for(let e of r){let{start:r,end:s}=e;s=zu(r,s,i);let c=Lu(n,i[r],i[s],e.loop);if(!t.segments){o.push({source:e,target:c,start:i[r],end:i[s]});continue}let l=Vo(t,c);for(let t of l){let r=Lu(n,a[t.start],a[t.end],t.loop),s=Bo(e,i,r);for(let e of s)o.push({source:e,target:t,start:{[n]:Bu(c,r,`start`,Math.max)},end:{[n]:Bu(c,r,`end`,Math.min)}})}}return o}function Lu(e,t,n,r){if(r)return;let i=t[e],a=n[e];return e===`angle`&&(i=q(i),a=q(a)),{property:e,start:i,end:a}}function Ru(e,t){let{x:n=null,y:r=null}=e||{},i=t.points,a=[];return t.segments.forEach(({start:e,end:t})=>{t=zu(e,t,i);let o=i[e],s=i[t];r===null?n!==null&&(a.push({x:n,y:o.y}),a.push({x:n,y:s.y})):(a.push({x:o.x,y:r}),a.push({x:s.x,y:r}))}),a}function zu(e,t,n){for(;t>e;t--){let e=n[t];if(!isNaN(e.x)&&!isNaN(e.y))break}return t}function Bu(e,t,n,r){return e&&t?r(e[n],t[n]):e?e[n]:t?t[n]:0}function Vu(e,t){let n=[],r=!1;return R(e)?(r=!0,n=e):n=Ru(e,t),n.length?new Cu({points:n,options:{tension:0},_loop:r,_fullLoop:r}):null}function Hu(e){return e&&e.fill!==!1}function Uu(e,t,n){let r=e[t].fill,i=[t],a;if(!n)return r;for(;r!==!1&&i.indexOf(r)===-1;){if(!B(r))return r;if(a=e[r],!a)return!1;if(a.visible)return r;i.push(r),r=a.fill}return!1}function Wu(e,t,n){let r=Ju(e);if(z(r))return isNaN(r.value)?!1:r;let i=parseFloat(r);return B(i)&&Math.floor(i)===i?Gu(r[0],t,i,n):[`origin`,`start`,`end`,`stack`,`shape`].indexOf(r)>=0&&r}function Gu(e,t,n,r){return(e===`-`||e===`+`)&&(n=t+n),n===t||n<0||n>=r?!1:n}function Ku(e,t){let n=null;return e===`start`?n=t.bottom:e===`end`?n=t.top:z(e)?n=t.getPixelForValue(e.value):t.getBasePixel&&(n=t.getBasePixel()),n}function qu(e,t,n){let r;return r=e===`start`?n:e===`end`?t.options.reverse?t.min:t.max:z(e)?e.value:t.getBaseValue(),r}function Ju(e){let t=e.options,n=t.fill,r=V(n&&n.target,n);return r===void 0&&(r=!!t.backgroundColor),r===!1||r===null?!1:r===!0?`origin`:r}function Yu(e){let{scale:t,index:n,line:r}=e,i=[],a=r.segments,o=r.points,s=Xu(t,n);s.push(Vu({x:null,y:t.bottom},r));for(let e=0;e<a.length;e++){let t=a[e];for(let e=t.start;e<=t.end;e++)Zu(i,o[e],s)}return new Cu({points:i,options:{}})}function Xu(e,t){let n=[],r=e.getMatchingVisibleMetas(`line`);for(let e=0;e<r.length;e++){let i=r[e];if(i.index===t)break;i.hidden||n.unshift(i.dataset)}return n}function Zu(e,t,n){let r=[];for(let i=0;i<n.length;i++){let a=n[i],{first:o,last:s,point:c}=Qu(a,t,`x`);if(!(!c||o&&s)){if(o)r.unshift(c);else if(e.push(c),!s)break}}e.push(...r)}function Qu(e,t,n){let r=e.interpolate(t,n);if(!r)return{};let i=r[n],a=e.segments,o=e.points,s=!1,c=!1;for(let e=0;e<a.length;e++){let t=a[e],r=o[t.start][n],l=o[t.end][n];if(wi(i,r,l)){s=i===r,c=i===l;break}}return{first:s,last:c,point:r}}var $u=class{constructor(e){this.x=e.x,this.y=e.y,this.radius=e.radius}pathSegment(e,t,n){let{x:r,y:i,radius:a}=this;return t||={start:0,end:G},e.arc(r,i,a,t.end,t.start,!0),!n.bounds}interpolate(e){let{x:t,y:n,radius:r}=this,i=e.angle;return{x:t+Math.cos(i)*r,y:n+Math.sin(i)*r,angle:i}}};function ed(e){let{chart:t,fill:n,line:r}=e;if(B(n))return td(t,n);if(n===`stack`)return Yu(e);if(n===`shape`)return!0;let i=nd(e);return i instanceof $u?i:Vu(i,r)}function td(e,t){let n=e.getDatasetMeta(t);return n&&e.isDatasetVisible(t)?n.dataset:null}function nd(e){return(e.scale||{}).getPointPositionForValue?id(e):rd(e)}function rd(e){let{scale:t={},fill:n}=e,r=Ku(n,t);if(B(r)){let e=t.isHorizontal();return{x:e?r:null,y:e?null:r}}return null}function id(e){let{scale:t,fill:n}=e,r=t.options,i=t.getLabels().length,a=r.reverse?t.max:t.min,o=qu(n,t,a),s=[];if(r.grid.circular){let e=t.getPointPositionForValue(0,a);return new $u({x:e.x,y:e.y,radius:t.getDistanceFromCenterForValue(o)})}for(let e=0;e<i;++e)s.push(t.getPointPositionForValue(e,o));return s}function ad(e,t,n){let r=ed(t),{chart:i,index:a,line:o,scale:s,axis:c}=t,l=o.options,u=l.fill,d=l.backgroundColor,{above:f=d,below:p=d}=u||{},m=Zo(i,i.getDatasetMeta(a));r&&o.points.length&&(_a(e,n),od(e,{line:o,target:r,above:f,below:p,area:n,scale:s,axis:c,clip:m}),va(e))}function od(e,t){let{line:n,target:r,above:i,below:a,area:o,scale:s,clip:c}=t,l=n._loop?`angle`:t.axis;e.save();let u=a;a!==i&&(l===`x`?(sd(e,r,o.top),ld(e,{line:n,target:r,color:i,scale:s,property:l,clip:c}),e.restore(),e.save(),sd(e,r,o.bottom)):l===`y`&&(cd(e,r,o.left),ld(e,{line:n,target:r,color:a,scale:s,property:l,clip:c}),e.restore(),e.save(),cd(e,r,o.right),u=i)),ld(e,{line:n,target:r,color:u,scale:s,property:l,clip:c}),e.restore()}function sd(e,t,n){let{segments:r,points:i}=t,a=!0,o=!1;e.beginPath();for(let s of r){let{start:r,end:c}=s,l=i[r],u=i[zu(r,c,i)];a?(e.moveTo(l.x,l.y),a=!1):(e.lineTo(l.x,n),e.lineTo(l.x,l.y)),o=!!t.pathSegment(e,s,{move:o}),o?e.closePath():e.lineTo(u.x,n)}e.lineTo(t.first().x,n),e.closePath(),e.clip()}function cd(e,t,n){let{segments:r,points:i}=t,a=!0,o=!1;e.beginPath();for(let s of r){let{start:r,end:c}=s,l=i[r],u=i[zu(r,c,i)];a?(e.moveTo(l.x,l.y),a=!1):(e.lineTo(n,l.y),e.lineTo(l.x,l.y)),o=!!t.pathSegment(e,s,{move:o}),o?e.closePath():e.lineTo(n,u.y)}e.lineTo(n,t.first().y),e.closePath(),e.clip()}function ld(e,t){let{line:n,target:r,property:i,color:a,scale:o,clip:s}=t,c=Iu(n,r,i);for(let{source:t,target:l,start:u,end:d}of c){let{style:{backgroundColor:c=a}={}}=t,f=r!==!0;e.save(),e.fillStyle=c,ud(e,o,s,f&&Lu(i,u,d)),e.beginPath();let p=!!n.pathSegment(e,t),m;if(f){p?e.closePath():dd(e,r,d,i);let t=!!r.pathSegment(e,l,{move:p,reverse:!0});m=p&&t,m||dd(e,r,u,i)}e.closePath(),e.fill(m?`evenodd`:`nonzero`),e.restore()}}function ud(e,t,n,r){let i=t.chart.chartArea,{property:a,start:o,end:s}=r||{};if(a===`x`||a===`y`){let t,r,c,l;a===`x`?(t=o,r=i.top,c=s,l=i.bottom):(t=i.left,r=o,c=i.right,l=s),e.beginPath(),n&&(t=Math.max(t,n.left),c=Math.min(c,n.right),r=Math.max(r,n.top),l=Math.min(l,n.bottom)),e.rect(t,r,c-t,l-r),e.clip()}}function dd(e,t,n,r){let i=t.interpolate(n,r);i&&e.lineTo(i.x,i.y)}var fd={id:`filler`,afterDatasetsUpdate(e,t,n){let r=(e.data.datasets||[]).length,i=[],a,o,s,c;for(o=0;o<r;++o)a=e.getDatasetMeta(o),s=a.dataset,c=null,s&&s.options&&s instanceof Cu&&(c={visible:e.isDatasetVisible(o),index:o,fill:Wu(s,o,r),chart:e,axis:a.controller.options.indexAxis,scale:a.vScale,line:s}),a.$filler=c,i.push(c);for(o=0;o<r;++o)c=i[o],!(!c||c.fill===!1)&&(c.fill=Uu(i,o,n.propagate))},beforeDraw(e,t,n){let r=n.drawTime===`beforeDraw`,i=e.getSortedVisibleDatasetMetas(),a=e.chartArea;for(let t=i.length-1;t>=0;--t){let n=i[t].$filler;n&&(n.line.updateControlPoints(a,n.axis),r&&n.fill&&ad(e.ctx,n,a))}},beforeDatasetsDraw(e,t,n){if(n.drawTime!==`beforeDatasetsDraw`)return;let r=e.getSortedVisibleDatasetMetas();for(let t=r.length-1;t>=0;--t){let n=r[t].$filler;Hu(n)&&ad(e.ctx,n,e.chartArea)}},beforeDatasetDraw(e,t,n){let r=t.meta.$filler;!Hu(r)||n.drawTime!==`beforeDatasetDraw`||ad(e.ctx,r,e.chartArea)},defaults:{propagate:!0,drawTime:`beforeDatasetDraw`}},pd=(e,t)=>{let{boxHeight:n=t,boxWidth:r=t}=e;return e.usePointStyle&&(n=Math.min(n,t),r=e.pointStyleWidth||Math.min(r,t)),{boxWidth:r,boxHeight:n,itemHeight:Math.max(t,n)}},md=(e,t)=>e!==null&&t!==null&&e.datasetIndex===t.datasetIndex&&e.index===t.index,hd=class extends Kc{constructor(e){super(),this._added=!1,this.legendHitBoxes=[],this._hoveredItem=null,this.doughnutMode=!1,this.chart=e.chart,this.options=e.options,this.ctx=e.ctx,this.legendItems=void 0,this.columnSizes=void 0,this.lineWidths=void 0,this.maxHeight=void 0,this.maxWidth=void 0,this.top=void 0,this.bottom=void 0,this.left=void 0,this.right=void 0,this.height=void 0,this.width=void 0,this._margins=void 0,this.position=void 0,this.weight=void 0,this.fullSize=void 0}update(e,t,n){this.maxWidth=e,this.maxHeight=t,this._margins=n,this.setDimensions(),this.buildLabels(),this.fit()}setDimensions(){this.isHorizontal()?(this.width=this.maxWidth,this.left=this._margins.left,this.right=this.width):(this.height=this.maxHeight,this.top=this._margins.top,this.bottom=this.height)}buildLabels(){let e=this.options.labels||{},t=H(e.generateLabels,[this.chart],this)||[];e.filter&&(t=t.filter(t=>e.filter(t,this.chart.data))),e.sort&&(t=t.sort((t,n)=>e.sort(t,n,this.chart.data))),this.options.reverse&&t.reverse(),this.legendItems=t}fit(){let{options:e,ctx:t}=this;if(!e.display){this.width=this.height=0;return}let n=e.labels,r=Z(n.font),i=r.size,a=this._computeTitleHeight(),{boxWidth:o,itemHeight:s}=pd(n,i),c,l;t.font=r.string,this.isHorizontal()?(c=this.maxWidth,l=this._fitRows(a,i,o,s)+10):(l=this.maxHeight,c=this._fitCols(a,r,o,s)+10),this.width=Math.min(c,e.maxWidth||this.maxWidth),this.height=Math.min(l,e.maxHeight||this.maxHeight)}_fitRows(e,t,n,r){let{ctx:i,maxWidth:a,options:{labels:{padding:o}}}=this,s=this.legendHitBoxes=[],c=this.lineWidths=[0],l=r+o,u=e;i.textAlign=`left`,i.textBaseline=`middle`;let d=-1,f=-l;return this.legendItems.forEach((e,p)=>{let m=n+t/2+i.measureText(e.text).width;(p===0||c[c.length-1]+m+2*o>a)&&(u+=l,c[c.length-(p>0?0:1)]=0,f+=l,d++),s[p]={left:0,top:f,row:d,width:m,height:r},c[c.length-1]+=m+o}),u}_fitCols(e,t,n,r){let{ctx:i,maxHeight:a,options:{labels:{padding:o}}}=this,s=this.legendHitBoxes=[],c=this.columnSizes=[],l=a-e,u=o,d=0,f=0,p=0,m=0;return this.legendItems.forEach((e,a)=>{let{itemWidth:h,itemHeight:g}=gd(n,t,i,e,r);a>0&&f+g+2*o>l&&(u+=d+o,c.push({width:d,height:f}),p+=d+o,m++,d=f=0),s[a]={left:p,top:f,col:m,width:h,height:g},d=Math.max(d,h),f+=g+o}),u+=d,c.push({width:d,height:f}),u}adjustHitBoxes(){if(!this.options.display)return;let e=this._computeTitleHeight(),{legendHitBoxes:t,options:{align:n,labels:{padding:r},rtl:i}}=this,a=Po(i,this.left,this.width);if(this.isHorizontal()){let i=0,o=Li(n,this.left+r,this.right-this.lineWidths[i]);for(let s of t)i!==s.row&&(i=s.row,o=Li(n,this.left+r,this.right-this.lineWidths[i])),s.top+=this.top+e+r,s.left=a.leftForLtr(a.x(o),s.width),o+=s.width+r}else{let i=0,o=Li(n,this.top+e+r,this.bottom-this.columnSizes[i].height);for(let s of t)s.col!==i&&(i=s.col,o=Li(n,this.top+e+r,this.bottom-this.columnSizes[i].height)),s.top=o,s.left+=this.left+r,s.left=a.leftForLtr(a.x(s.left),s.width),o+=s.height+r}}isHorizontal(){return this.options.position===`top`||this.options.position===`bottom`}draw(){if(this.options.display){let e=this.ctx;_a(e,this),this._draw(),va(e)}}_draw(){let{options:e,columnSizes:t,lineWidths:n,ctx:r}=this,{align:i,labels:a}=e,o=Y.color,s=Po(e.rtl,this.left,this.width),c=Z(a.font),{padding:l}=a,u=c.size,d=u/2,f;this.drawTitle(),r.textAlign=s.textAlign(`left`),r.textBaseline=`middle`,r.lineWidth=.5,r.font=c.string;let{boxWidth:p,boxHeight:m,itemHeight:h}=pd(a,u),g=function(e,t,n){if(isNaN(p)||p<=0||isNaN(m)||m<0)return;r.save();let i=V(n.lineWidth,1);if(r.fillStyle=V(n.fillStyle,o),r.lineCap=V(n.lineCap,`butt`),r.lineDashOffset=V(n.lineDashOffset,0),r.lineJoin=V(n.lineJoin,`miter`),r.lineWidth=i,r.strokeStyle=V(n.strokeStyle,o),r.setLineDash(V(n.lineDash,[])),a.usePointStyle)ha(r,{radius:m*Math.SQRT2/2,pointStyle:n.pointStyle,rotation:n.rotation,borderWidth:i},s.xPlus(e,p/2),t+d,a.pointStyleWidth&&p);else{let a=t+Math.max((u-m)/2,0),o=s.leftForLtr(e,p),c=Ma(n.borderRadius);r.beginPath(),Object.values(c).some(e=>e!==0)?Ta(r,{x:o,y:a,w:p,h:m,radius:c}):r.rect(o,a,p,m),r.fill(),i!==0&&r.stroke()}r.restore()},_=function(e,t,n){wa(r,n.text,e,t+h/2,c,{strikethrough:n.hidden,textAlign:s.textAlign(n.textAlign)})},v=this.isHorizontal(),y=this._computeTitleHeight();f=v?{x:Li(i,this.left+l,this.right-n[0]),y:this.top+l+y,line:0}:{x:this.left+l,y:Li(i,this.top+y+l,this.bottom-t[0].height),line:0},Fo(this.ctx,e.textDirection);let b=h+l;this.legendItems.forEach((o,u)=>{r.strokeStyle=o.fontColor,r.fillStyle=o.fontColor;let m=r.measureText(o.text).width,h=s.textAlign(o.textAlign||=a.textAlign),x=p+d+m,S=f.x,C=f.y;if(s.setWidth(this.width),v?u>0&&S+x+l>this.right&&(C=f.y+=b,f.line++,S=f.x=Li(i,this.left+l,this.right-n[f.line])):u>0&&C+b>this.bottom&&(S=f.x=S+t[f.line].width+l,f.line++,C=f.y=Li(i,this.top+y+l,this.bottom-t[f.line].height)),g(s.x(S),C,o),S=Ri(h,S+p+d,v?S+x:this.right,e.rtl),_(s.x(S),C,o),v)f.x+=x+l;else if(typeof o.text!=`string`){let e=c.lineHeight;f.y+=yd(o,e)+l}else f.y+=b}),Io(this.ctx,e.textDirection)}drawTitle(){let e=this.options,t=e.title,n=Z(t.font),r=X(t.padding);if(!t.display)return;let i=Po(e.rtl,this.left,this.width),a=this.ctx,o=t.position,s=n.size/2,c=r.top+s,l,u=this.left,d=this.width;if(this.isHorizontal())d=Math.max(...this.lineWidths),l=this.top+c,u=Li(e.align,u,this.right-d);else{let t=this.columnSizes.reduce((e,t)=>Math.max(e,t.height),0);l=c+Li(e.align,this.top,this.bottom-t-e.labels.padding-this._computeTitleHeight())}let f=Li(o,u,u+d);a.textAlign=i.textAlign(Ii(o)),a.textBaseline=`middle`,a.strokeStyle=t.color,a.fillStyle=t.color,a.font=n.string,wa(a,t.text,f,l,n)}_computeTitleHeight(){let e=this.options.title,t=Z(e.font),n=X(e.padding);return e.display?t.lineHeight+n.height:0}_getLegendItemAt(e,t){let n,r,i;if(wi(e,this.left,this.right)&&wi(t,this.top,this.bottom)){for(i=this.legendHitBoxes,n=0;n<i.length;++n)if(r=i[n],wi(e,r.left,r.left+r.width)&&wi(t,r.top,r.top+r.height))return this.legendItems[n]}return null}handleEvent(e){let t=this.options;if(!bd(e.type,t))return;let n=this._getLegendItemAt(e.x,e.y);if(e.type===`mousemove`||e.type===`mouseout`){let r=this._hoveredItem,i=md(r,n);r&&!i&&H(t.onLeave,[e,r,this],this),this._hoveredItem=n,n&&!i&&H(t.onHover,[e,n,this],this)}else n&&H(t.onClick,[e,n,this],this)}};function gd(e,t,n,r,i){return{itemWidth:_d(r,e,t,n),itemHeight:vd(i,r,t.lineHeight)}}function _d(e,t,n,r){let i=e.text;return i&&typeof i!=`string`&&(i=i.reduce((e,t)=>e.length>t.length?e:t)),t+n.size/2+r.measureText(i).width}function vd(e,t,n){let r=e;return typeof t.text!=`string`&&(r=yd(t,n)),r}function yd(e,t){return t*(e.text?e.text.length:0)}function bd(e,t){return!!((e===`mousemove`||e===`mouseout`)&&(t.onHover||t.onLeave)||t.onClick&&(e===`click`||e===`mouseup`))}var xd={id:`legend`,_element:hd,start(e,t,n){let r=e.legend=new hd({ctx:e.ctx,options:n,chart:e});Sc.configure(e,r,n),Sc.addBox(e,r)},stop(e){Sc.removeBox(e,e.legend),delete e.legend},beforeUpdate(e,t,n){let r=e.legend;Sc.configure(e,r,n),r.options=n},afterUpdate(e){let t=e.legend;t.buildLabels(),t.adjustHitBoxes()},afterEvent(e,t){t.replay||e.legend.handleEvent(t.event)},defaults:{display:!0,position:`top`,align:`center`,fullSize:!0,reverse:!1,weight:1e3,onClick(e,t,n){let r=t.datasetIndex,i=n.chart;i.isDatasetVisible(r)?(i.hide(r),t.hidden=!0):(i.show(r),t.hidden=!1)},onHover:null,onLeave:null,labels:{color:e=>e.chart.options.color,boxWidth:40,padding:10,generateLabels(e){let t=e.data.datasets,{labels:{usePointStyle:n,pointStyle:r,textAlign:i,color:a,useBorderRadius:o,borderRadius:s}}=e.legend.options;return e._getSortedDatasetMetas().map(e=>{let c=e.controller.getStyle(n?0:void 0),l=X(c.borderWidth);return{text:t[e.index].label,fillStyle:c.backgroundColor,fontColor:a,hidden:!e.visible,lineCap:c.borderCapStyle,lineDash:c.borderDash,lineDashOffset:c.borderDashOffset,lineJoin:c.borderJoinStyle,lineWidth:(l.width+l.height)/4,strokeStyle:c.borderColor,pointStyle:r||c.pointStyle,rotation:c.rotation,textAlign:i||c.textAlign,borderRadius:o&&(s||c.borderRadius),datasetIndex:e.index}},this)}},title:{color:e=>e.chart.options.color,display:!1,position:`center`,text:``}},descriptors:{_scriptable:e=>!e.startsWith(`on`),labels:{_scriptable:e=>![`generateLabels`,`filter`,`sort`].includes(e)}}},Sd={average(e){if(!e.length)return!1;let t,n,r=new Set,i=0,a=0;for(t=0,n=e.length;t<n;++t){let n=e[t].element;if(n&&n.hasValue()){let e=n.tooltipPosition();r.add(e.x),i+=e.y,++a}}return a===0||r.size===0?!1:{x:[...r].reduce((e,t)=>e+t)/r.size,y:i/a}},nearest(e,t){if(!e.length)return!1;let n=t.x,r=t.y,i=1/0,a,o,s;for(a=0,o=e.length;a<o;++a){let n=e[a].element;if(n&&n.hasValue()){let e=bi(t,n.getCenterPoint());e<i&&(i=e,s=n)}}if(s){let e=s.tooltipPosition();n=e.x,r=e.y}return{x:n,y:r}}};function Cd(e,t){return t&&(R(t)?Array.prototype.push.apply(e,t):e.push(t)),e}function wd(e){return(typeof e==`string`||e instanceof String)&&e.indexOf(`
`)>-1?e.split(`
`):e}function Td(e,t){let{element:n,datasetIndex:r,index:i}=t,a=e.getDatasetMeta(r).controller,{label:o,value:s}=a.getLabelAndValue(i);return{chart:e,label:o,parsed:a.getParsed(i),raw:e.data.datasets[r].data[i],formattedValue:s,dataset:a.getDataset(),dataIndex:i,datasetIndex:r,element:n}}function Ed(e,t){let n=e.chart.ctx,{body:r,footer:i,title:a}=e,{boxWidth:o,boxHeight:s}=t,c=Z(t.bodyFont),l=Z(t.titleFont),u=Z(t.footerFont),d=a.length,f=i.length,p=r.length,m=X(t.padding),h=m.height,g=0,_=r.reduce((e,t)=>e+t.before.length+t.lines.length+t.after.length,0);if(_+=e.beforeBody.length+e.afterBody.length,d&&(h+=d*l.lineHeight+(d-1)*t.titleSpacing+t.titleMarginBottom),_){let e=t.displayColors?Math.max(s,c.lineHeight):c.lineHeight;h+=p*e+(_-p)*c.lineHeight+(_-1)*t.bodySpacing}f&&(h+=t.footerMarginTop+f*u.lineHeight+(f-1)*t.footerSpacing);let v=0,y=function(e){g=Math.max(g,n.measureText(e).width+v)};return n.save(),n.font=l.string,U(e.title,y),n.font=c.string,U(e.beforeBody.concat(e.afterBody),y),v=t.displayColors?o+2+t.boxPadding:0,U(r,e=>{U(e.before,y),U(e.lines,y),U(e.after,y)}),v=0,n.font=u.string,U(e.footer,y),n.restore(),g+=m.width,{width:g,height:h}}function Dd(e,t){let{y:n,height:r}=t;return n<r/2?`top`:n>e.height-r/2?`bottom`:`center`}function Od(e,t,n,r){let{x:i,width:a}=r,o=n.caretSize+n.caretPadding;if(e===`left`&&i+a+o>t.width||e===`right`&&i-a-o<0)return!0}function kd(e,t,n,r){let{x:i,width:a}=n,{width:o,chartArea:{left:s,right:c}}=e,l=`center`;return r===`center`?l=i<=(s+c)/2?`left`:`right`:i<=a/2?l=`left`:i>=o-a/2&&(l=`right`),Od(l,e,t,n)&&(l=`center`),l}function Ad(e,t,n){let r=n.yAlign||t.yAlign||Dd(e,n);return{xAlign:n.xAlign||t.xAlign||kd(e,t,n,r),yAlign:r}}function jd(e,t){let{x:n,width:r}=e;return t===`right`?n-=r:t===`center`&&(n-=r/2),n}function Md(e,t,n){let{y:r,height:i}=e;return t===`top`?r+=n:t===`bottom`?r-=i+n:r-=i/2,r}function Nd(e,t,n,r){let{caretSize:i,caretPadding:a,cornerRadius:o}=e,{xAlign:s,yAlign:c}=n,l=i+a,{topLeft:u,topRight:d,bottomLeft:f,bottomRight:p}=Ma(o),m=jd(t,s),h=Md(t,c,l);return c===`center`?s===`left`?m+=l:s===`right`&&(m-=l):s===`left`?m-=Math.max(u,f)+i:s===`right`&&(m+=Math.max(d,p)+i),{x:J(m,0,r.width-t.width),y:J(h,0,r.height-t.height)}}function Pd(e,t,n){let r=X(n.padding);return t===`center`?e.x+e.width/2:t===`right`?e.x+e.width-r.right:e.x+r.left}function Fd(e){return Cd([],wd(e))}function Id(e,t,n){return Fa(e,{tooltip:t,tooltipItems:n,type:`tooltip`})}function Ld(e,t){let n=t&&t.dataset&&t.dataset.tooltip&&t.dataset.tooltip.callbacks;return n?e.override(n):e}var Rd={beforeTitle:Fr,title(e){if(e.length>0){let t=e[0],n=t.chart.data.labels,r=n?n.length:0;if(this&&this.options&&this.options.mode===`dataset`)return t.dataset.label||``;if(t.label)return t.label;if(r>0&&t.dataIndex<r)return n[t.dataIndex]}return``},afterTitle:Fr,beforeBody:Fr,beforeLabel:Fr,label(e){if(this&&this.options&&this.options.mode===`dataset`)return e.label+`: `+e.formattedValue||e.formattedValue;let t=e.dataset.label||``;t&&(t+=`: `);let n=e.formattedValue;return L(n)||(t+=n),t},labelColor(e){let t=e.chart.getDatasetMeta(e.datasetIndex).controller.getStyle(e.dataIndex);return{borderColor:t.borderColor,backgroundColor:t.backgroundColor,borderWidth:t.borderWidth,borderDash:t.borderDash,borderDashOffset:t.borderDashOffset,borderRadius:0}},labelTextColor(){return this.options.bodyColor},labelPointStyle(e){let t=e.chart.getDatasetMeta(e.datasetIndex).controller.getStyle(e.dataIndex);return{pointStyle:t.pointStyle,rotation:t.rotation}},afterLabel:Fr,afterBody:Fr,beforeFooter:Fr,footer:Fr,afterFooter:Fr};function Q(e,t,n,r){let i=e[t].call(n,r);return i===void 0?Rd[t].call(n,r):i}var zd=class extends Kc{constructor(e){super(),this.opacity=0,this._active=[],this._eventPosition=void 0,this._size=void 0,this._cachedAnimations=void 0,this._tooltipItems=[],this.$animations=void 0,this.$context=void 0,this.chart=e.chart,this.options=e.options,this.dataPoints=void 0,this.title=void 0,this.beforeBody=void 0,this.body=void 0,this.afterBody=void 0,this.footer=void 0,this.xAlign=void 0,this.yAlign=void 0,this.x=void 0,this.y=void 0,this.height=void 0,this.width=void 0,this.caretX=void 0,this.caretY=void 0,this.labelColors=void 0,this.labelPointStyles=void 0,this.labelTextColors=void 0}initialize(e){this.options=e,this._cachedAnimations=void 0,this.$context=void 0}_resolveAnimations(){let e=this._cachedAnimations;if(e)return e;let t=this.chart,n=this.options.setContext(this.getContext()),r=n.enabled&&t.options.animation&&n.animations,i=new ns(this.chart,r);return r._cacheable&&(this._cachedAnimations=Object.freeze(i)),i}getContext(){return this.$context||=Id(this.chart.getContext(),this,this._tooltipItems)}getTitle(e,t){let{callbacks:n}=t,r=Q(n,`beforeTitle`,this,e),i=Q(n,`title`,this,e),a=Q(n,`afterTitle`,this,e),o=[];return o=Cd(o,wd(r)),o=Cd(o,wd(i)),o=Cd(o,wd(a)),o}getBeforeBody(e,t){return Fd(Q(t.callbacks,`beforeBody`,this,e))}getBody(e,t){let{callbacks:n}=t,r=[];return U(e,e=>{let t={before:[],lines:[],after:[]},i=Ld(n,e);Cd(t.before,wd(Q(i,`beforeLabel`,this,e))),Cd(t.lines,Q(i,`label`,this,e)),Cd(t.after,wd(Q(i,`afterLabel`,this,e))),r.push(t)}),r}getAfterBody(e,t){return Fd(Q(t.callbacks,`afterBody`,this,e))}getFooter(e,t){let{callbacks:n}=t,r=Q(n,`beforeFooter`,this,e),i=Q(n,`footer`,this,e),a=Q(n,`afterFooter`,this,e),o=[];return o=Cd(o,wd(r)),o=Cd(o,wd(i)),o=Cd(o,wd(a)),o}_createItems(e){let t=this._active,n=this.chart.data,r=[],i=[],a=[],o=[],s,c;for(s=0,c=t.length;s<c;++s)o.push(Td(this.chart,t[s]));return e.filter&&(o=o.filter((t,r,i)=>e.filter(t,r,i,n))),e.itemSort&&(o=o.sort((t,r)=>e.itemSort(t,r,n))),U(o,t=>{let n=Ld(e.callbacks,t);r.push(Q(n,`labelColor`,this,t)),i.push(Q(n,`labelPointStyle`,this,t)),a.push(Q(n,`labelTextColor`,this,t))}),this.labelColors=r,this.labelPointStyles=i,this.labelTextColors=a,this.dataPoints=o,o}update(e,t){let n=this.options.setContext(this.getContext()),r=this._active,i,a=[];if(!r.length)this.opacity!==0&&(i={opacity:0});else{let e=Sd[n.position].call(this,r,this._eventPosition);a=this._createItems(n),this.title=this.getTitle(a,n),this.beforeBody=this.getBeforeBody(a,n),this.body=this.getBody(a,n),this.afterBody=this.getAfterBody(a,n),this.footer=this.getFooter(a,n);let t=this._size=Ed(this,n),o=Object.assign({},e,t),s=Ad(this.chart,n,o),c=Nd(n,o,s,this.chart);this.xAlign=s.xAlign,this.yAlign=s.yAlign,i={opacity:1,x:c.x,y:c.y,width:t.width,height:t.height,caretX:e.x,caretY:e.y}}this._tooltipItems=a,this.$context=void 0,i&&this._resolveAnimations().update(this,i),e&&n.external&&n.external.call(this,{chart:this.chart,tooltip:this,replay:t})}drawCaret(e,t,n,r){let i=this.getCaretPosition(e,n,r);t.lineTo(i.x1,i.y1),t.lineTo(i.x2,i.y2),t.lineTo(i.x3,i.y3)}getCaretPosition(e,t,n){let{xAlign:r,yAlign:i}=this,{caretSize:a,cornerRadius:o}=n,{topLeft:s,topRight:c,bottomLeft:l,bottomRight:u}=Ma(o),{x:d,y:f}=e,{width:p,height:m}=t,h,g,_,v,y,b;return i===`center`?(y=f+m/2,r===`left`?(h=d,g=h-a,v=y+a,b=y-a):(h=d+p,g=h+a,v=y-a,b=y+a),_=h):(g=r===`left`?d+Math.max(s,l)+a:r===`right`?d+p-Math.max(c,u)-a:this.caretX,i===`top`?(v=f,y=v-a,h=g-a,_=g+a):(v=f+m,y=v+a,h=g+a,_=g-a),b=v),{x1:h,x2:g,x3:_,y1:v,y2:y,y3:b}}drawTitle(e,t,n){let r=this.title,i=r.length,a,o,s;if(i){let c=Po(n.rtl,this.x,this.width);for(e.x=Pd(this,n.titleAlign,n),t.textAlign=c.textAlign(n.titleAlign),t.textBaseline=`middle`,a=Z(n.titleFont),o=n.titleSpacing,t.fillStyle=n.titleColor,t.font=a.string,s=0;s<i;++s)t.fillText(r[s],c.x(e.x),e.y+a.lineHeight/2),e.y+=a.lineHeight+o,s+1===i&&(e.y+=n.titleMarginBottom-o)}}_drawColorBox(e,t,n,r,i){let a=this.labelColors[n],o=this.labelPointStyles[n],{boxHeight:s,boxWidth:c}=i,l=Z(i.bodyFont),u=Pd(this,`left`,i),d=r.x(u),f=s<l.lineHeight?(l.lineHeight-s)/2:0,p=t.y+f;if(i.usePointStyle){let t={radius:Math.min(c,s)/2,pointStyle:o.pointStyle,rotation:o.rotation,borderWidth:1},n=r.leftForLtr(d,c)+c/2,l=p+s/2;e.strokeStyle=i.multiKeyBackground,e.fillStyle=i.multiKeyBackground,ma(e,t,n,l),e.strokeStyle=a.borderColor,e.fillStyle=a.backgroundColor,ma(e,t,n,l)}else{e.lineWidth=z(a.borderWidth)?Math.max(...Object.values(a.borderWidth)):a.borderWidth||1,e.strokeStyle=a.borderColor,e.setLineDash(a.borderDash||[]),e.lineDashOffset=a.borderDashOffset||0;let t=r.leftForLtr(d,c),n=r.leftForLtr(r.xPlus(d,1),c-2),o=Ma(a.borderRadius);Object.values(o).some(e=>e!==0)?(e.beginPath(),e.fillStyle=i.multiKeyBackground,Ta(e,{x:t,y:p,w:c,h:s,radius:o}),e.fill(),e.stroke(),e.fillStyle=a.backgroundColor,e.beginPath(),Ta(e,{x:n,y:p+1,w:c-2,h:s-2,radius:o}),e.fill()):(e.fillStyle=i.multiKeyBackground,e.fillRect(t,p,c,s),e.strokeRect(t,p,c,s),e.fillStyle=a.backgroundColor,e.fillRect(n,p+1,c-2,s-2))}e.fillStyle=this.labelTextColors[n]}drawBody(e,t,n){let{body:r}=this,{bodySpacing:i,bodyAlign:a,displayColors:o,boxHeight:s,boxWidth:c,boxPadding:l}=n,u=Z(n.bodyFont),d=u.lineHeight,f=0,p=Po(n.rtl,this.x,this.width),m=function(n){t.fillText(n,p.x(e.x+f),e.y+d/2),e.y+=d+i},h=p.textAlign(a),g,_,v,y,b,x,S;for(t.textAlign=a,t.textBaseline=`middle`,t.font=u.string,e.x=Pd(this,h,n),t.fillStyle=n.bodyColor,U(this.beforeBody,m),f=o&&h!==`right`?a===`center`?c/2+l:c+2+l:0,y=0,x=r.length;y<x;++y){for(g=r[y],_=this.labelTextColors[y],t.fillStyle=_,U(g.before,m),v=g.lines,o&&v.length&&(this._drawColorBox(t,e,y,p,n),d=Math.max(u.lineHeight,s)),b=0,S=v.length;b<S;++b)m(v[b]),d=u.lineHeight;U(g.after,m)}f=0,d=u.lineHeight,U(this.afterBody,m),e.y-=i}drawFooter(e,t,n){let r=this.footer,i=r.length,a,o;if(i){let s=Po(n.rtl,this.x,this.width);for(e.x=Pd(this,n.footerAlign,n),e.y+=n.footerMarginTop,t.textAlign=s.textAlign(n.footerAlign),t.textBaseline=`middle`,a=Z(n.footerFont),t.fillStyle=n.footerColor,t.font=a.string,o=0;o<i;++o)t.fillText(r[o],s.x(e.x),e.y+a.lineHeight/2),e.y+=a.lineHeight+n.footerSpacing}}drawBackground(e,t,n,r){let{xAlign:i,yAlign:a}=this,{x:o,y:s}=e,{width:c,height:l}=n,{topLeft:u,topRight:d,bottomLeft:f,bottomRight:p}=Ma(r.cornerRadius);t.fillStyle=r.backgroundColor,t.strokeStyle=r.borderColor,t.lineWidth=r.borderWidth,t.beginPath(),t.moveTo(o+u,s),a===`top`&&this.drawCaret(e,t,n,r),t.lineTo(o+c-d,s),t.quadraticCurveTo(o+c,s,o+c,s+d),a===`center`&&i===`right`&&this.drawCaret(e,t,n,r),t.lineTo(o+c,s+l-p),t.quadraticCurveTo(o+c,s+l,o+c-p,s+l),a===`bottom`&&this.drawCaret(e,t,n,r),t.lineTo(o+f,s+l),t.quadraticCurveTo(o,s+l,o,s+l-f),a===`center`&&i===`left`&&this.drawCaret(e,t,n,r),t.lineTo(o,s+u),t.quadraticCurveTo(o,s,o+u,s),t.closePath(),t.fill(),r.borderWidth>0&&t.stroke()}_updateAnimationTarget(e){let t=this.chart,n=this.$animations,r=n&&n.x,i=n&&n.y;if(r||i){let n=Sd[e.position].call(this,this._active,this._eventPosition);if(!n)return;let a=this._size=Ed(this,e),o=Object.assign({},n,this._size),s=Ad(t,e,o),c=Nd(e,o,s,t);(r._to!==c.x||i._to!==c.y)&&(this.xAlign=s.xAlign,this.yAlign=s.yAlign,this.width=a.width,this.height=a.height,this.caretX=n.x,this.caretY=n.y,this._resolveAnimations().update(this,c))}}_willRender(){return!!this.opacity}draw(e){let t=this.options.setContext(this.getContext()),n=this.opacity;if(!n)return;this._updateAnimationTarget(t);let r={width:this.width,height:this.height},i={x:this.x,y:this.y};n=Math.abs(n)<.001?0:n;let a=X(t.padding),o=this.title.length||this.beforeBody.length||this.body.length||this.afterBody.length||this.footer.length;t.enabled&&o&&(e.save(),e.globalAlpha=n,this.drawBackground(i,e,r,t),Fo(e,t.textDirection),i.y+=a.top,this.drawTitle(i,e,t),this.drawBody(i,e,t),this.drawFooter(i,e,t),Io(e,t.textDirection),e.restore())}getActiveElements(){return this._active||[]}setActiveElements(e,t){let n=this._active,r=e.map(({datasetIndex:e,index:t})=>{let n=this.chart.getDatasetMeta(e);if(!n)throw Error(`Cannot find a dataset at index `+e);return{datasetIndex:e,element:n.data[t],index:t}}),i=!Br(n,r),a=this._positionChanged(r,t);(i||a)&&(this._active=r,this._eventPosition=t,this._ignoreReplayEvents=!0,this.update(!0))}handleEvent(e,t,n=!0){if(t&&this._ignoreReplayEvents)return!1;this._ignoreReplayEvents=!1;let r=this.options,i=this._active||[],a=this._getActiveElements(e,i,t,n),o=this._positionChanged(a,e),s=t||!Br(a,i)||o;return s&&(this._active=a,(r.enabled||r.external)&&(this._eventPosition={x:e.x,y:e.y},this.update(!0,t))),s}_getActiveElements(e,t,n,r){let i=this.options;if(e.type===`mouseout`)return[];if(!r)return t.filter(e=>this.chart.data.datasets[e.datasetIndex]&&this.chart.getDatasetMeta(e.datasetIndex).controller.getParsed(e.index)!==void 0);let a=this.chart.getElementsAtEventForMode(e,i.mode,i,n);return i.reverse&&a.reverse(),a}_positionChanged(e,t){let{caretX:n,caretY:r,options:i}=this,a=Sd[i.position].call(this,e,t);return a!==!1&&(n!==a.x||r!==a.y)}};f(zd,`positioners`,Sd);var Bd={id:`tooltip`,_element:zd,positioners:Sd,afterInit(e,t,n){n&&(e.tooltip=new zd({chart:e,options:n}))},beforeUpdate(e,t,n){e.tooltip&&e.tooltip.initialize(n)},reset(e,t,n){e.tooltip&&e.tooltip.initialize(n)},afterDraw(e){let t=e.tooltip;if(t&&t._willRender()){let n={tooltip:t};if(e.notifyPlugins(`beforeTooltipDraw`,{...n,cancelable:!0})===!1)return;t.draw(e.ctx),e.notifyPlugins(`afterTooltipDraw`,n)}},afterEvent(e,t){if(e.tooltip){let n=t.replay;e.tooltip.handleEvent(t.event,n,t.inChartArea)&&(t.changed=!0)}},defaults:{enabled:!0,external:null,position:`average`,backgroundColor:`rgba(0,0,0,0.8)`,titleColor:`#fff`,titleFont:{weight:`bold`},titleSpacing:2,titleMarginBottom:6,titleAlign:`left`,bodyColor:`#fff`,bodySpacing:2,bodyFont:{},bodyAlign:`left`,footerColor:`#fff`,footerSpacing:2,footerMarginTop:6,footerFont:{weight:`bold`},footerAlign:`left`,padding:6,caretPadding:2,caretSize:5,cornerRadius:6,boxHeight:(e,t)=>t.bodyFont.size,boxWidth:(e,t)=>t.bodyFont.size,multiKeyBackground:`#fff`,displayColors:!0,boxPadding:0,borderColor:`rgba(0,0,0,0)`,borderWidth:0,animation:{duration:400,easing:`easeOutQuart`},animations:{numbers:{type:`number`,properties:[`x`,`y`,`width`,`height`,`caretX`,`caretY`]},opacity:{easing:`linear`,duration:200}},callbacks:Rd},defaultRoutes:{bodyFont:`font`,footerFont:`font`,titleFont:`font`},descriptors:{_scriptable:e=>e!==`filter`&&e!==`itemSort`&&e!==`external`,_indexable:!1,callbacks:{_scriptable:!1,_indexable:!1},animation:{_fallback:!1},animations:{_fallback:`animation`}},additionalOptionScopes:[`interaction`]},Vd=(e,t,n,r)=>(typeof t==`string`?(n=e.push(t)-1,r.unshift({index:n,label:t})):isNaN(t)&&(n=null),n);function Hd(e,t,n,r){let i=e.indexOf(t);return i===-1?Vd(e,t,n,r):i===e.lastIndexOf(t)?i:n}var Ud=(e,t)=>e===null?null:J(Math.round(e),0,t);function Wd(e){let t=this.getLabels();return e>=0&&e<t.length?t[e]:e}var Gd=class extends fl{constructor(e){super(e),this._startValue=void 0,this._valueRange=0,this._addedLabels=[]}init(e){let t=this._addedLabels;if(t.length){let e=this.getLabels();for(let{index:n,label:r}of t)e[n]===r&&e.splice(n,1);this._addedLabels=[]}super.init(e)}parse(e,t){if(L(e))return null;let n=this.getLabels();return t=isFinite(t)&&n[t]===e?t:Hd(n,e,V(t,e),this._addedLabels),Ud(t,n.length-1)}determineDataLimits(){let{minDefined:e,maxDefined:t}=this.getUserBounds(),{min:n,max:r}=this.getMinMax(!0);this.options.bounds===`ticks`&&(e||(n=0),t||(r=this.getLabels().length-1)),this.min=n,this.max=r}buildTicks(){let e=this.min,t=this.max,n=this.options.offset,r=[],i=this.getLabels();i=e===0&&t===i.length-1?i:i.slice(e,t+1),this._valueRange=Math.max(i.length-(n?0:1),1),this._startValue=this.min-(n?.5:0);for(let n=e;n<=t;n++)r.push({value:n});return r}getLabelForValue(e){return Wd.call(this,e)}configure(){super.configure(),this.isHorizontal()||(this._reversePixels=!this._reversePixels)}getPixelForValue(e){return typeof e!=`number`&&(e=this.parse(e)),e===null?NaN:this.getPixelForDecimal((e-this._startValue)/this._valueRange)}getPixelForTick(e){let t=this.ticks;return e<0||e>t.length-1?null:this.getPixelForValue(t[e].value)}getValueForPixel(e){return Math.round(this._startValue+this.getDecimalForPixel(e)*this._valueRange)}getBasePixel(){return this.bottom}};f(Gd,`id`,`category`),f(Gd,`defaults`,{ticks:{callback:Wd}});function Kd(e,t){let n=[],{bounds:r,step:i,min:a,max:o,precision:s,count:c,maxTicks:l,maxDigits:u,includeBounds:d}=e,f=i||1,p=l-1,{min:m,max:h}=t,g=!L(a),_=!L(o),v=!L(c),y=(h-m)/(u+1),b=ui((h-m)/p/f)*f,x,S,C,w;if(b<1e-14&&!g&&!_)return[{value:m},{value:h}];w=Math.ceil(h/b)-Math.floor(m/b),w>p&&(b=ui(w*b/p/f)*f),L(s)||(x=10**s,b=Math.ceil(b*x)/x),r===`ticks`?(S=Math.floor(m/b)*b,C=Math.ceil(h/b)*b):(S=m,C=h),g&&_&&i&&mi((o-a)/i,b/1e3)?(w=Math.round(Math.min((o-a)/b,l)),b=(o-a)/w,S=a,C=o):v?(S=g?a:S,C=_?o:C,w=c-1,b=(C-S)/w):(w=(C-S)/b,w=li(w,Math.round(w),b/1e3)?Math.round(w):Math.ceil(w));let T=Math.max(vi(b),vi(S));x=10**(L(s)?T:s),S=Math.round(S*x)/x,C=Math.round(C*x)/x;let E=0;for(g&&(d&&S!==a?(n.push({value:a}),S<a&&E++,li(Math.round((S+E*b)*x)/x,a,qd(a,y,e))&&E++):S<a&&E++);E<w;++E){let e=Math.round((S+E*b)*x)/x;if(_&&e>o)break;n.push({value:e})}return _&&d&&C!==o?n.length&&li(n[n.length-1].value,o,qd(o,y,e))?n[n.length-1].value=o:n.push({value:o}):(!_||C===o)&&n.push({value:C}),n}function qd(e,t,{horizontal:n,minRotation:r}){let i=gi(r),a=(n?Math.sin(i):Math.cos(i))||.001,o=.75*t*(``+e).length;return Math.min(t/a,o)}var Jd=class extends fl{constructor(e){super(e),this.start=void 0,this.end=void 0,this._startValue=void 0,this._endValue=void 0,this._valueRange=0}parse(e,t){return L(e)||(typeof e==`number`||e instanceof Number)&&!isFinite(+e)?null:+e}handleTickRangeOptions(){let{beginAtZero:e}=this.options,{minDefined:t,maxDefined:n}=this.getUserBounds(),{min:r,max:i}=this,a=e=>r=t?r:e,o=e=>i=n?i:e;if(e){let e=ci(r),t=ci(i);e<0&&t<0?o(0):e>0&&t>0&&a(0)}if(r===i){let t=i===0?1:Math.abs(i*.05);o(i+t),e||a(r-t)}this.min=r,this.max=i}getTickLimit(){let{maxTicksLimit:e,stepSize:t}=this.options.ticks,n;return t?(n=Math.ceil(this.max/t)-Math.floor(this.min/t)+1,n>1e3&&(console.warn(`scales.${this.id}.ticks.stepSize: ${t} would result generating up to ${n} ticks. Limiting to 1000.`),n=1e3)):(n=this.computeTickLimit(),e||=11),e&&(n=Math.min(e,n)),n}computeTickLimit(){return 1/0}buildTicks(){let e=this.options,t=e.ticks,n=this.getTickLimit();n=Math.max(2,n);let r=Kd({maxTicks:n,bounds:e.bounds,min:e.min,max:e.max,precision:t.precision,step:t.stepSize,count:t.count,maxDigits:this._maxDigits(),horizontal:this.isHorizontal(),minRotation:t.minRotation||0,includeBounds:t.includeBounds!==!1},this._range||this);return e.bounds===`ticks`&&hi(r,this,`value`),e.reverse?(r.reverse(),this.start=this.max,this.end=this.min):(this.start=this.min,this.end=this.max),r}configure(){let e=this.ticks,t=this.min,n=this.max;if(super.configure(),this.options.offset&&e.length){let r=(n-t)/Math.max(e.length-1,1)/2;t-=r,n+=r}this._startValue=t,this._endValue=n,this._valueRange=n-t}getLabelForValue(e){return ea(e,this.chart.options.locale,this.options.ticks.format)}},Yd=class extends Jd{determineDataLimits(){let{min:e,max:t}=this.getMinMax(!0);this.min=B(e)?e:0,this.max=B(t)?t:1,this.handleTickRangeOptions()}computeTickLimit(){let e=this.isHorizontal(),t=e?this.width:this.height,n=gi(this.options.ticks.minRotation),r=(e?Math.sin(n):Math.cos(n))||.001,i=this._resolveTickFontOptions(0);return Math.ceil(t/Math.min(40,i.lineHeight/r))}getPixelForValue(e){return e===null?NaN:this.getPixelForDecimal((e-this._startValue)/this._valueRange)}getValueForPixel(e){return this._startValue+this.getDecimalForPixel(e)*this._valueRange}};f(Yd,`id`,`linear`),f(Yd,`defaults`,{ticks:{callback:ra.formatters.numeric}});var Xd=e=>Math.floor(si(e)),Zd=(e,t)=>10**(Xd(e)+t);function Qd(e){return e/10**Xd(e)==1}function $d(e,t,n){let r=10**n,i=Math.floor(e/r);return Math.ceil(t/r)-i}function ef(e,t){let n=Xd(t-e);for(;$d(e,t,n)>10;)n++;for(;$d(e,t,n)<10;)n--;return Math.min(n,Xd(e))}function tf(e,{min:t,max:n}){t=Lr(e.min,t);let r=[],i=Xd(t),a=ef(t,n),o=a<0?10**Math.abs(a):1,s=10**a,c=i>a?10**i:0,l=Math.round((t-c)*o)/o,u=Math.floor((t-c)/s/10)*s*10,d=Math.floor((l-u)/10**a),f=Lr(e.min,Math.round((c+u+d*10**a)*o)/o);for(;f<n;)r.push({value:f,major:Qd(f),significand:d}),d>=10?d=d<15?15:20:d++,d>=20&&(a++,d=2,o=a>=0?1:o),f=Math.round((c+u+d*10**a)*o)/o;let p=Lr(e.max,f);return r.push({value:p,major:Qd(p),significand:d}),r}var nf=class extends fl{constructor(e){super(e),this.start=void 0,this.end=void 0,this._startValue=void 0,this._valueRange=0}parse(e,t){let n=Jd.prototype.parse.apply(this,[e,t]);if(n===0){this._zero=!0;return}return B(n)&&n>0?n:null}determineDataLimits(){let{min:e,max:t}=this.getMinMax(!0);this.min=B(e)?Math.max(0,e):null,this.max=B(t)?Math.max(0,t):null,this.options.beginAtZero&&(this._zero=!0),this._zero&&this.min!==this._suggestedMin&&!B(this._userMin)&&(this.min=e===Zd(this.min,0)?Zd(this.min,-1):Zd(this.min,0)),this.handleTickRangeOptions()}handleTickRangeOptions(){let{minDefined:e,maxDefined:t}=this.getUserBounds(),n=this.min,r=this.max,i=t=>n=e?n:t,a=e=>r=t?r:e;n===r&&(n<=0?(i(1),a(10)):(i(Zd(n,-1)),a(Zd(r,1)))),n<=0&&i(Zd(r,-1)),r<=0&&a(Zd(n,1)),this.min=n,this.max=r}buildTicks(){let e=this.options,t=tf({min:this._userMin,max:this._userMax},this);return e.bounds===`ticks`&&hi(t,this,`value`),e.reverse?(t.reverse(),this.start=this.max,this.end=this.min):(this.start=this.min,this.end=this.max),t}getLabelForValue(e){return e===void 0?`0`:ea(e,this.chart.options.locale,this.options.ticks.format)}configure(){let e=this.min;super.configure(),this._startValue=si(e),this._valueRange=si(this.max)-si(e)}getPixelForValue(e){return(e===void 0||e===0)&&(e=this.min),e===null||isNaN(e)?NaN:this.getPixelForDecimal(e===this.min?0:(si(e)-this._startValue)/this._valueRange)}getValueForPixel(e){let t=this.getDecimalForPixel(e);return 10**(this._startValue+t*this._valueRange)}};f(nf,`id`,`logarithmic`),f(nf,`defaults`,{ticks:{callback:ra.formatters.logarithmic,major:{enabled:!0}}});function rf(e){let t=e.ticks;if(t.display&&e.display){let e=X(t.backdropPadding);return V(t.font&&t.font.size,Y.font.size)+e.height}return 0}function af(e,t,n){return n=R(n)?n:[n],{w:da(e,t.string,n),h:n.length*t.lineHeight}}function of(e,t,n,r,i){return e===r||e===i?{start:t-n/2,end:t+n/2}:e<r||e>i?{start:t-n,end:t}:{start:t,end:t+n}}function sf(e){let t={l:e.left+e._padding.left,r:e.right-e._padding.right,t:e.top+e._padding.top,b:e.bottom-e._padding.bottom},n=Object.assign({},t),r=[],i=[],a=e._pointLabels.length,o=e.options.pointLabels,s=o.centerPointLabels?W/a:0;for(let c=0;c<a;c++){let a=o.setContext(e.getPointLabelContext(c));i[c]=a.padding;let l=e.getPointPosition(c,e.drawingArea+i[c],s),u=Z(a.font),d=af(e.ctx,u,e._pointLabels[c]);r[c]=d;let f=q(e.getIndexAngle(c)+s),p=Math.round(_i(f));cf(n,t,f,of(p,l.x,d.w,0,180),of(p,l.y,d.h,90,270))}e.setCenterPoint(t.l-n.l,n.r-t.r,t.t-n.t,n.b-t.b),e._pointLabelItems=df(e,r,i)}function cf(e,t,n,r,i){let a=Math.abs(Math.sin(n)),o=Math.abs(Math.cos(n)),s=0,c=0;r.start<t.l?(s=(t.l-r.start)/a,e.l=Math.min(e.l,t.l-s)):r.end>t.r&&(s=(r.end-t.r)/a,e.r=Math.max(e.r,t.r+s)),i.start<t.t?(c=(t.t-i.start)/o,e.t=Math.min(e.t,t.t-c)):i.end>t.b&&(c=(i.end-t.b)/o,e.b=Math.max(e.b,t.b+c))}function lf(e,t,n){let r=e.drawingArea,{extra:i,additionalAngle:a,padding:o,size:s}=n,c=e.getPointPosition(t,r+i+o,a),l=Math.round(_i(q(c.angle+K))),u=mf(c.y,s.h,l),d=ff(l),f=pf(c.x,s.w,d);return{visible:!0,x:c.x,y:u,textAlign:d,left:f,top:u,right:f+s.w,bottom:u+s.h}}function uf(e,t){if(!t)return!0;let{left:n,top:r,right:i,bottom:a}=e;return!(ga({x:n,y:r},t)||ga({x:n,y:a},t)||ga({x:i,y:r},t)||ga({x:i,y:a},t))}function df(e,t,n){let r=[],i=e._pointLabels.length,a=e.options,{centerPointLabels:o,display:s}=a.pointLabels,c={extra:rf(a)/2,additionalAngle:o?W/i:0},l;for(let a=0;a<i;a++){c.padding=n[a],c.size=t[a];let i=lf(e,a,c);r.push(i),s===`auto`&&(i.visible=uf(i,l),i.visible&&(l=i))}return r}function ff(e){return e===0||e===180?`center`:e<180?`left`:`right`}function pf(e,t,n){return n===`right`?e-=t:n===`center`&&(e-=t/2),e}function mf(e,t,n){return n===90||n===270?e-=t/2:(n>270||n<90)&&(e-=t),e}function hf(e,t,n){let{left:r,top:i,right:a,bottom:o}=n,{backdropColor:s}=t;if(!L(s)){let n=Ma(t.borderRadius),c=X(t.backdropPadding);e.fillStyle=s;let l=r-c.left,u=i-c.top,d=a-r+c.width,f=o-i+c.height;Object.values(n).some(e=>e!==0)?(e.beginPath(),Ta(e,{x:l,y:u,w:d,h:f,radius:n}),e.fill()):e.fillRect(l,u,d,f)}}function gf(e,t){let{ctx:n,options:{pointLabels:r}}=e;for(let i=t-1;i>=0;i--){let t=e._pointLabelItems[i];if(!t.visible)continue;let a=r.setContext(e.getPointLabelContext(i));hf(n,a,t);let o=Z(a.font),{x:s,y:c,textAlign:l}=t;wa(n,e._pointLabels[i],s,c+o.lineHeight/2,o,{color:a.color,textAlign:l,textBaseline:`middle`})}}function _f(e,t,n,r){let{ctx:i}=e;if(n)i.arc(e.xCenter,e.yCenter,t,0,G);else{let n=e.getPointPosition(0,t);i.moveTo(n.x,n.y);for(let a=1;a<r;a++)n=e.getPointPosition(a,t),i.lineTo(n.x,n.y)}}function vf(e,t,n,r,i){let a=e.ctx,o=t.circular,{color:s,lineWidth:c}=t;!o&&!r||!s||!c||n<0||(a.save(),a.strokeStyle=s,a.lineWidth=c,a.setLineDash(i.dash||[]),a.lineDashOffset=i.dashOffset,a.beginPath(),_f(e,n,o,r),a.closePath(),a.stroke(),a.restore())}function yf(e,t,n){return Fa(e,{label:n,index:t,type:`pointLabel`})}var bf=class extends Jd{constructor(e){super(e),this.xCenter=void 0,this.yCenter=void 0,this.drawingArea=void 0,this._pointLabels=[],this._pointLabelItems=[]}setDimensions(){let e=this._padding=X(rf(this.options)/2),t=this.width=this.maxWidth-e.width,n=this.height=this.maxHeight-e.height;this.xCenter=Math.floor(this.left+t/2+e.left),this.yCenter=Math.floor(this.top+n/2+e.top),this.drawingArea=Math.floor(Math.min(t,n)/2)}determineDataLimits(){let{min:e,max:t}=this.getMinMax(!1);this.min=B(e)&&!isNaN(e)?e:0,this.max=B(t)&&!isNaN(t)?t:0,this.handleTickRangeOptions()}computeTickLimit(){return Math.ceil(this.drawingArea/rf(this.options))}generateTickLabels(e){Jd.prototype.generateTickLabels.call(this,e),this._pointLabels=this.getLabels().map((e,t)=>{let n=H(this.options.pointLabels.callback,[e,t],this);return n||n===0?n:``}).filter((e,t)=>this.chart.getDataVisibility(t))}fit(){let e=this.options;e.display&&e.pointLabels.display?sf(this):this.setCenterPoint(0,0,0,0)}setCenterPoint(e,t,n,r){this.xCenter+=Math.floor((e-t)/2),this.yCenter+=Math.floor((n-r)/2),this.drawingArea-=Math.min(this.drawingArea/2,Math.max(e,t,n,r))}getIndexAngle(e){let t=G/(this._pointLabels.length||1),n=this.options.startAngle||0;return q(e*t+gi(n))}getDistanceFromCenterForValue(e){if(L(e))return NaN;let t=this.drawingArea/(this.max-this.min);return this.options.reverse?(this.max-e)*t:(e-this.min)*t}getValueForDistanceFromCenter(e){if(L(e))return NaN;let t=e/(this.drawingArea/(this.max-this.min));return this.options.reverse?this.max-t:this.min+t}getPointLabelContext(e){let t=this._pointLabels||[];if(e>=0&&e<t.length){let n=t[e];return yf(this.getContext(),e,n)}}getPointPosition(e,t,n=0){let r=this.getIndexAngle(e)-K+n;return{x:Math.cos(r)*t+this.xCenter,y:Math.sin(r)*t+this.yCenter,angle:r}}getPointPositionForValue(e,t){return this.getPointPosition(e,this.getDistanceFromCenterForValue(t))}getBasePosition(e){return this.getPointPositionForValue(e||0,this.getBaseValue())}getPointLabelPosition(e){let{left:t,top:n,right:r,bottom:i}=this._pointLabelItems[e];return{left:t,top:n,right:r,bottom:i}}drawBackground(){let{backgroundColor:e,grid:{circular:t}}=this.options;if(e){let n=this.ctx;n.save(),n.beginPath(),_f(this,this.getDistanceFromCenterForValue(this._endValue),t,this._pointLabels.length),n.closePath(),n.fillStyle=e,n.fill(),n.restore()}}drawGrid(){let e=this.ctx,t=this.options,{angleLines:n,grid:r,border:i}=t,a=this._pointLabels.length,o,s,c;if(t.pointLabels.display&&gf(this,a),r.display&&this.ticks.forEach((e,t)=>{if(t!==0||t===0&&this.min<0){s=this.getDistanceFromCenterForValue(e.value);let n=this.getContext(t),o=r.setContext(n),c=i.setContext(n);vf(this,o,s,a,c)}}),n.display){for(e.save(),o=a-1;o>=0;o--){let r=n.setContext(this.getPointLabelContext(o)),{color:i,lineWidth:a}=r;!a||!i||(e.lineWidth=a,e.strokeStyle=i,e.setLineDash(r.borderDash),e.lineDashOffset=r.borderDashOffset,s=this.getDistanceFromCenterForValue(t.reverse?this.min:this.max),c=this.getPointPosition(o,s),e.beginPath(),e.moveTo(this.xCenter,this.yCenter),e.lineTo(c.x,c.y),e.stroke())}e.restore()}}drawBorder(){}drawLabels(){let e=this.ctx,t=this.options,n=t.ticks;if(!n.display)return;let r=this.getIndexAngle(0),i,a;e.save(),e.translate(this.xCenter,this.yCenter),e.rotate(r),e.textAlign=`center`,e.textBaseline=`middle`,this.ticks.forEach((r,o)=>{if(o===0&&this.min>=0&&!t.reverse)return;let s=n.setContext(this.getContext(o)),c=Z(s.font);if(i=this.getDistanceFromCenterForValue(this.ticks[o].value),s.showLabelBackdrop){e.font=c.string,a=e.measureText(r.label).width,e.fillStyle=s.backdropColor;let t=X(s.backdropPadding);e.fillRect(-a/2-t.left,-i-c.size/2-t.top,a+t.width,c.size+t.height)}wa(e,r.label,0,-i,c,{color:s.color,strokeColor:s.textStrokeColor,strokeWidth:s.textStrokeWidth})}),e.restore()}drawTitle(){}};f(bf,`id`,`radialLinear`),f(bf,`defaults`,{display:!0,animate:!0,position:`chartArea`,angleLines:{display:!0,lineWidth:1,borderDash:[],borderDashOffset:0},grid:{circular:!1},startAngle:0,ticks:{showLabelBackdrop:!0,callback:ra.formatters.numeric},pointLabels:{backdropColor:void 0,backdropPadding:2,display:!0,font:{size:10},callback(e){return e},padding:5,centerPointLabels:!1}}),f(bf,`defaultRoutes`,{"angleLines.color":`borderColor`,"pointLabels.color":`color`,"ticks.color":`color`}),f(bf,`descriptors`,{angleLines:{_fallback:`grid`}});var xf={millisecond:{common:!0,size:1,steps:1e3},second:{common:!0,size:1e3,steps:60},minute:{common:!0,size:6e4,steps:60},hour:{common:!0,size:36e5,steps:24},day:{common:!0,size:864e5,steps:30},week:{common:!1,size:6048e5,steps:4},month:{common:!0,size:2628e6,steps:12},quarter:{common:!1,size:7884e6,steps:4},year:{common:!0,size:3154e7}},Sf=Object.keys(xf);function Cf(e,t){return e-t}function wf(e,t){if(L(t))return null;let n=e._adapter,{parser:r,round:i,isoWeekday:a}=e._parseOpts,o=t;return typeof r==`function`&&(o=r(o)),B(o)||(o=typeof r==`string`?n.parse(o,r):n.parse(o)),o===null?null:(i&&(o=i===`week`&&(pi(a)||a===!0)?n.startOf(o,`isoWeek`,a):n.startOf(o,i)),+o)}function Tf(e,t,n,r){let i=Sf.length;for(let a=Sf.indexOf(e);a<i-1;++a){let e=xf[Sf[a]],i=e.steps?e.steps:2**53-1;if(e.common&&Math.ceil((n-t)/(i*e.size))<=r)return Sf[a]}return Sf[i-1]}function Ef(e,t,n,r,i){for(let a=Sf.length-1;a>=Sf.indexOf(n);a--){let n=Sf[a];if(xf[n].common&&e._adapter.diff(i,r,n)>=t-1)return n}return Sf[n?Sf.indexOf(n):0]}function Df(e){for(let t=Sf.indexOf(e)+1,n=Sf.length;t<n;++t)if(xf[Sf[t]].common)return Sf[t]}function Of(e,t,n){if(!n)e[t]=!0;else if(n.length){let{lo:r,hi:i}=Ti(n,t),a=n[r]>=t?n[r]:n[i];e[a]=!0}}function kf(e,t,n,r){let i=e._adapter,a=+i.startOf(t[0].value,r),o=t[t.length-1].value,s,c;for(s=a;s<=o;s=+i.add(s,1,r))c=n[s],c>=0&&(t[c].major=!0);return t}function Af(e,t,n){let r=[],i={},a=t.length,o,s;for(o=0;o<a;++o)s=t[o],i[s]=o,r.push({value:s,major:!1});return a===0||!n?r:kf(e,r,i,n)}var jf=class extends fl{constructor(e){super(e),this._cache={data:[],labels:[],all:[]},this._unit=`day`,this._majorUnit=void 0,this._offsets={},this._normalized=!1,this._parseOpts=void 0}init(e,t={}){let n=e.time||={},r=this._adapter=new Xs._date(e.adapters.date);r.init(t),Gr(n.displayFormats,r.formats()),this._parseOpts={parser:n.parser,round:n.round,isoWeekday:n.isoWeekday},super.init(e),this._normalized=t.normalized}parse(e,t){return e===void 0?null:wf(this,e)}beforeLayout(){super.beforeLayout(),this._cache={data:[],labels:[],all:[]}}determineDataLimits(){let e=this.options,t=this._adapter,n=e.time.unit||`day`,{min:r,max:i,minDefined:a,maxDefined:o}=this.getUserBounds();function s(e){!a&&!isNaN(e.min)&&(r=Math.min(r,e.min)),!o&&!isNaN(e.max)&&(i=Math.max(i,e.max))}(!a||!o)&&(s(this._getLabelBounds()),(e.bounds!==`ticks`||e.ticks.source!==`labels`)&&s(this.getMinMax(!1))),r=B(r)&&!isNaN(r)?r:+t.startOf(Date.now(),n),i=B(i)&&!isNaN(i)?i:+t.endOf(Date.now(),n)+1,this.min=Math.min(r,i-1),this.max=Math.max(r+1,i)}_getLabelBounds(){let e=this.getLabelTimestamps(),t=1/0,n=-1/0;return e.length&&(t=e[0],n=e[e.length-1]),{min:t,max:n}}buildTicks(){let e=this.options,t=e.time,n=e.ticks,r=n.source===`labels`?this.getLabelTimestamps():this._generate();e.bounds===`ticks`&&r.length&&(this.min=this._userMin||r[0],this.max=this._userMax||r[r.length-1]);let i=this.min,a=this.max,o=Oi(r,i,a);return this._unit=t.unit||(n.autoSkip?Tf(t.minUnit,this.min,this.max,this._getLabelCapacity(i)):Ef(this,o.length,t.minUnit,this.min,this.max)),this._majorUnit=!n.major.enabled||this._unit===`year`?void 0:Df(this._unit),this.initOffsets(r),e.reverse&&o.reverse(),Af(this,o,this._majorUnit)}afterAutoSkip(){this.options.offsetAfterAutoskip&&this.initOffsets(this.ticks.map(e=>+e.value))}initOffsets(e=[]){let t=0,n=0,r,i;this.options.offset&&e.length&&(r=this.getDecimalForValue(e[0]),t=e.length===1?1-r:(this.getDecimalForValue(e[1])-r)/2,i=this.getDecimalForValue(e[e.length-1]),n=e.length===1?i:(i-this.getDecimalForValue(e[e.length-2]))/2);let a=e.length<3?.5:.25;t=J(t,0,a),n=J(n,0,a),this._offsets={start:t,end:n,factor:1/(t+1+n)}}_generate(){let e=this._adapter,t=this.min,n=this.max,r=this.options,i=r.time,a=i.unit||Tf(i.minUnit,t,n,this._getLabelCapacity(t)),o=V(r.ticks.stepSize,1),s=a===`week`?i.isoWeekday:!1,c=pi(s)||s===!0,l={},u=t,d,f;if(c&&(u=+e.startOf(u,`isoWeek`,s)),u=+e.startOf(u,c?`day`:a),e.diff(n,t,a)>1e5*o)throw Error(t+` and `+n+` are too far apart with stepSize of `+o+` `+a);let p=r.ticks.source===`data`&&this.getDataTimestamps();for(d=u,f=0;d<n;d=+e.add(d,o,a),f++)Of(l,d,p);return(d===n||r.bounds===`ticks`||f===1)&&Of(l,d,p),Object.keys(l).sort(Cf).map(e=>+e)}getLabelForValue(e){let t=this._adapter,n=this.options.time;return n.tooltipFormat?t.format(e,n.tooltipFormat):t.format(e,n.displayFormats.datetime)}format(e,t){let n=this.options.time.displayFormats,r=this._unit,i=t||n[r];return this._adapter.format(e,i)}_tickFormatFunction(e,t,n,r){let i=this.options,a=i.ticks.callback;if(a)return H(a,[e,t,n],this);let o=i.time.displayFormats,s=this._unit,c=this._majorUnit,l=s&&o[s],u=c&&o[c],d=n[t],f=c&&u&&d&&d.major;return this._adapter.format(e,r||(f?u:l))}generateTickLabels(e){let t,n,r;for(t=0,n=e.length;t<n;++t)r=e[t],r.label=this._tickFormatFunction(r.value,t,e)}getDecimalForValue(e){return e===null?NaN:(e-this.min)/(this.max-this.min)}getPixelForValue(e){let t=this._offsets,n=this.getDecimalForValue(e);return this.getPixelForDecimal((t.start+n)*t.factor)}getValueForPixel(e){let t=this._offsets,n=this.getDecimalForPixel(e)/t.factor-t.end;return this.min+n*(this.max-this.min)}_getLabelSize(e){let t=this.options.ticks,n=this.ctx.measureText(e).width,r=gi(this.isHorizontal()?t.maxRotation:t.minRotation),i=Math.cos(r),a=Math.sin(r),o=this._resolveTickFontOptions(0).size;return{w:n*i+o*a,h:n*a+o*i}}_getLabelCapacity(e){let t=this.options.time,n=t.displayFormats,r=n[t.unit]||n.millisecond,i=this._tickFormatFunction(e,0,Af(this,[e],this._majorUnit),r),a=this._getLabelSize(i),o=Math.floor(this.isHorizontal()?this.width/a.w:this.height/a.h)-1;return o>0?o:1}getDataTimestamps(){let e=this._cache.data||[],t,n;if(e.length)return e;let r=this.getMatchingVisibleMetas();if(this._normalized&&r.length)return this._cache.data=r[0].controller.getAllParsedValues(this);for(t=0,n=r.length;t<n;++t)e=e.concat(r[t].controller.getAllParsedValues(this));return this._cache.data=this.normalize(e)}getLabelTimestamps(){let e=this._cache.labels||[],t,n;if(e.length)return e;let r=this.getLabels();for(t=0,n=r.length;t<n;++t)e.push(wf(this,r[t]));return this._cache.labels=this._normalized?e:this.normalize(e)}normalize(e){return Mi(e.sort(Cf))}};f(jf,`id`,`time`),f(jf,`defaults`,{bounds:`data`,adapters:{},time:{parser:!1,unit:!1,round:!1,isoWeekday:!1,minUnit:`millisecond`,displayFormats:{}},ticks:{source:`auto`,callback:!1,major:{enabled:!1}}});function Mf(e,t,n){let r=0,i=e.length-1,a,o,s,c;n?(t>=e[r].pos&&t<=e[i].pos&&({lo:r,hi:i}=Ei(e,`pos`,t)),{pos:a,time:s}=e[r],{pos:o,time:c}=e[i]):(t>=e[r].time&&t<=e[i].time&&({lo:r,hi:i}=Ei(e,`time`,t)),{time:a,pos:s}=e[r],{time:o,pos:c}=e[i]);let l=o-a;return l?s+(c-s)*(t-a)/l:s}var Nf=class extends jf{constructor(e){super(e),this._table=[],this._minPos=void 0,this._tableRange=void 0}initOffsets(){let e=this._getTimestampsForTable(),t=this._table=this.buildLookupTable(e);this._minPos=Mf(t,this.min),this._tableRange=Mf(t,this.max)-this._minPos,super.initOffsets(e)}buildLookupTable(e){let{min:t,max:n}=this,r=[],i=[],a,o,s,c,l;for(a=0,o=e.length;a<o;++a)c=e[a],c>=t&&c<=n&&r.push(c);if(r.length<2)return[{time:t,pos:0},{time:n,pos:1}];for(a=0,o=r.length;a<o;++a)l=r[a+1],s=r[a-1],c=r[a],Math.round((l+s)/2)!==c&&i.push({time:c,pos:a/(o-1)});return i}_generate(){let e=this.min,t=this.max,n=super.getDataTimestamps();return(!n.includes(e)||!n.length)&&n.splice(0,0,e),(!n.includes(t)||n.length===1)&&n.push(t),n.sort((e,t)=>e-t)}_getTimestampsForTable(){let e=this._cache.all||[];if(e.length)return e;let t=this.getDataTimestamps(),n=this.getLabelTimestamps();return e=t.length&&n.length?this.normalize(t.concat(n)):t.length?t:n,e=this._cache.all=e,e}getDecimalForValue(e){return(Mf(this._table,e)-this._minPos)/this._tableRange}getValueForPixel(e){let t=this._offsets,n=this.getDecimalForPixel(e)/t.factor-t.end;return Mf(this._table,n*this._tableRange+this._minPos,!0)}};f(Nf,`id`,`timeseries`),f(Nf,`defaults`,jf.defaults);var Pf=e(t(((e,t)=>{(function(e,n,r,i){var a=[``,`webkit`,`Moz`,`MS`,`ms`,`o`],o=n.createElement(`div`),s=`function`,c=Math.round,l=Math.abs,u=Date.now;function d(e,t,n){return setTimeout(y(e,n),t)}function f(e,t,n){return Array.isArray(e)?(p(e,n[t],n),!0):!1}function p(e,t,n){var r;if(e)if(e.forEach)e.forEach(t,n);else if(e.length!==i)for(r=0;r<e.length;)t.call(n,e[r],r,e),r++;else for(r in e)e.hasOwnProperty(r)&&t.call(n,e[r],r,e)}function m(t,n,r){var i=`DEPRECATED METHOD: `+n+`
`+r+` AT 
`;return function(){var n=Error(`get-stack-trace`),r=n&&n.stack?n.stack.replace(/^[^\(]+?[\n$]/gm,``).replace(/^\s+at\s+/gm,``).replace(/^Object.<anonymous>\s*\(/gm,`{anonymous}()@`):`Unknown Stack Trace`,a=e.console&&(e.console.warn||e.console.log);return a&&a.call(e.console,i,r),t.apply(this,arguments)}}var h=typeof Object.assign==`function`?Object.assign:function(e){if(e===i||e===null)throw TypeError(`Cannot convert undefined or null to object`);for(var t=Object(e),n=1;n<arguments.length;n++){var r=arguments[n];if(r!==i&&r!==null)for(var a in r)r.hasOwnProperty(a)&&(t[a]=r[a])}return t},g=m(function(e,t,n){for(var r=Object.keys(t),a=0;a<r.length;)(!n||n&&e[r[a]]===i)&&(e[r[a]]=t[r[a]]),a++;return e},`extend`,"Use `assign`."),_=m(function(e,t){return g(e,t,!0)},`merge`,"Use `assign`.");function v(e,t,n){var r=t.prototype,i=e.prototype=Object.create(r);i.constructor=e,i._super=r,n&&h(i,n)}function y(e,t){return function(){return e.apply(t,arguments)}}function b(e,t){return typeof e==s?e.apply(t&&t[0]||i,t):e}function x(e,t){return e===i?t:e}function S(e,t,n){p(E(t),function(t){e.addEventListener(t,n,!1)})}function C(e,t,n){p(E(t),function(t){e.removeEventListener(t,n,!1)})}function w(e,t){for(;e;){if(e==t)return!0;e=e.parentNode}return!1}function T(e,t){return e.indexOf(t)>-1}function E(e){return e.trim().split(/\s+/g)}function D(e,t,n){if(e.indexOf&&!n)return e.indexOf(t);for(var r=0;r<e.length;){if(n&&e[r][n]==t||!n&&e[r]===t)return r;r++}return-1}function ee(e){return Array.prototype.slice.call(e,0)}function te(e,t,n){for(var r=[],i=[],a=0;a<e.length;){var o=t?e[a][t]:e[a];D(i,o)<0&&r.push(e[a]),i[a]=o,a++}return n&&(r=t?r.sort(function(e,n){return e[t]>n[t]}):r.sort()),r}function ne(e,t){for(var n,r,o=t[0].toUpperCase()+t.slice(1),s=0;s<a.length;){if(n=a[s],r=n?n+o:t,r in e)return r;s++}return i}var re=1;function ie(){return re++}function ae(t){var n=t.ownerDocument||t;return n.defaultView||n.parentWindow||e}var oe=/mobile|tablet|ip(ad|hone|od)|android/i,se=`ontouchstart`in e,ce=ne(e,`PointerEvent`)!==i,le=se&&oe.test(navigator.userAgent),ue=`touch`,de=`pen`,O=`mouse`,fe=`kinect`,pe=25,k=1,me=2,A=4,j=8,he=1,ge=2,_e=4,ve=8,ye=16,be=ge|_e,xe=ve|ye,Se=be|xe,Ce=[`x`,`y`],we=[`clientX`,`clientY`];function M(e,t){var n=this;this.manager=e,this.callback=t,this.element=e.element,this.target=e.options.inputTarget,this.domHandler=function(t){b(e.options.enable,[e])&&n.handler(t)},this.init()}M.prototype={handler:function(){},init:function(){this.evEl&&S(this.element,this.evEl,this.domHandler),this.evTarget&&S(this.target,this.evTarget,this.domHandler),this.evWin&&S(ae(this.element),this.evWin,this.domHandler)},destroy:function(){this.evEl&&C(this.element,this.evEl,this.domHandler),this.evTarget&&C(this.target,this.evTarget,this.domHandler),this.evWin&&C(ae(this.element),this.evWin,this.domHandler)}};function Te(e){var t;return t=e.options.inputClass||(ce?Ge:le?$e:se?rt:Be),new t(e,Ee)}function Ee(e,t,n){var r=n.pointers.length,i=n.changedPointers.length,a=t&k&&r-i===0,o=t&(A|j)&&r-i===0;n.isFirst=!!a,n.isFinal=!!o,a&&(e.session={}),n.eventType=t,De(e,n),e.emit(`hammer.input`,n),e.recognize(n),e.session.prevInput=n}function De(e,t){var n=e.session,r=t.pointers,i=r.length;n.firstInput||=Ae(t),i>1&&!n.firstMultiple?n.firstMultiple=Ae(t):i===1&&(n.firstMultiple=!1);var a=n.firstInput,o=n.firstMultiple,s=o?o.center:a.center,c=t.center=je(r);t.timeStamp=u(),t.deltaTime=t.timeStamp-a.timeStamp,t.angle=Pe(s,c),t.distance=Ne(s,c),Oe(n,t),t.offsetDirection=N(t.deltaX,t.deltaY);var d=Me(t.deltaTime,t.deltaX,t.deltaY);t.overallVelocityX=d.x,t.overallVelocityY=d.y,t.overallVelocity=l(d.x)>l(d.y)?d.x:d.y,t.scale=o?Ie(o.pointers,r):1,t.rotation=o?Fe(o.pointers,r):0,t.maxPointers=n.prevInput?t.pointers.length>n.prevInput.maxPointers?t.pointers.length:n.prevInput.maxPointers:t.pointers.length,ke(n,t);var f=e.element;w(t.srcEvent.target,f)&&(f=t.srcEvent.target),t.target=f}function Oe(e,t){var n=t.center,r=e.offsetDelta||{},i=e.prevDelta||{},a=e.prevInput||{};(t.eventType===k||a.eventType===A)&&(i=e.prevDelta={x:a.deltaX||0,y:a.deltaY||0},r=e.offsetDelta={x:n.x,y:n.y}),t.deltaX=i.x+(n.x-r.x),t.deltaY=i.y+(n.y-r.y)}function ke(e,t){var n=e.lastInterval||t,r=t.timeStamp-n.timeStamp,a,o,s,c;if(t.eventType!=j&&(r>pe||n.velocity===i)){var u=t.deltaX-n.deltaX,d=t.deltaY-n.deltaY,f=Me(r,u,d);o=f.x,s=f.y,a=l(f.x)>l(f.y)?f.x:f.y,c=N(u,d),e.lastInterval=t}else a=n.velocity,o=n.velocityX,s=n.velocityY,c=n.direction;t.velocity=a,t.velocityX=o,t.velocityY=s,t.direction=c}function Ae(e){for(var t=[],n=0;n<e.pointers.length;)t[n]={clientX:c(e.pointers[n].clientX),clientY:c(e.pointers[n].clientY)},n++;return{timeStamp:u(),pointers:t,center:je(t),deltaX:e.deltaX,deltaY:e.deltaY}}function je(e){var t=e.length;if(t===1)return{x:c(e[0].clientX),y:c(e[0].clientY)};for(var n=0,r=0,i=0;i<t;)n+=e[i].clientX,r+=e[i].clientY,i++;return{x:c(n/t),y:c(r/t)}}function Me(e,t,n){return{x:t/e||0,y:n/e||0}}function N(e,t){return e===t?he:l(e)>=l(t)?e<0?ge:_e:t<0?ve:ye}function Ne(e,t,n){n||=Ce;var r=t[n[0]]-e[n[0]],i=t[n[1]]-e[n[1]];return Math.sqrt(r*r+i*i)}function Pe(e,t,n){n||=Ce;var r=t[n[0]]-e[n[0]],i=t[n[1]]-e[n[1]];return Math.atan2(i,r)*180/Math.PI}function Fe(e,t){return Pe(t[1],t[0],we)+Pe(e[1],e[0],we)}function Ie(e,t){return Ne(t[0],t[1],we)/Ne(e[0],e[1],we)}var Le={mousedown:k,mousemove:me,mouseup:A},Re=`mousedown`,ze=`mousemove mouseup`;function Be(){this.evEl=Re,this.evWin=ze,this.pressed=!1,M.apply(this,arguments)}v(Be,M,{handler:function(e){var t=Le[e.type];t&k&&e.button===0&&(this.pressed=!0),t&me&&e.which!==1&&(t=A),this.pressed&&(t&A&&(this.pressed=!1),this.callback(this.manager,t,{pointers:[e],changedPointers:[e],pointerType:O,srcEvent:e}))}});var Ve={pointerdown:k,pointermove:me,pointerup:A,pointercancel:j,pointerout:j},He={2:ue,3:de,4:O,5:fe},Ue=`pointerdown`,We=`pointermove pointerup pointercancel`;e.MSPointerEvent&&!e.PointerEvent&&(Ue=`MSPointerDown`,We=`MSPointerMove MSPointerUp MSPointerCancel`);function Ge(){this.evEl=Ue,this.evWin=We,M.apply(this,arguments),this.store=this.manager.session.pointerEvents=[]}v(Ge,M,{handler:function(e){var t=this.store,n=!1,r=Ve[e.type.toLowerCase().replace(`ms`,``)],i=He[e.pointerType]||e.pointerType,a=i==ue,o=D(t,e.pointerId,`pointerId`);r&k&&(e.button===0||a)?o<0&&(t.push(e),o=t.length-1):r&(A|j)&&(n=!0),!(o<0)&&(t[o]=e,this.callback(this.manager,r,{pointers:t,changedPointers:[e],pointerType:i,srcEvent:e}),n&&t.splice(o,1))}});var Ke={touchstart:k,touchmove:me,touchend:A,touchcancel:j},qe=`touchstart`,Je=`touchstart touchmove touchend touchcancel`;function Ye(){this.evTarget=qe,this.evWin=Je,this.started=!1,M.apply(this,arguments)}v(Ye,M,{handler:function(e){var t=Ke[e.type];if(t===k&&(this.started=!0),this.started){var n=Xe.call(this,e,t);t&(A|j)&&n[0].length-n[1].length===0&&(this.started=!1),this.callback(this.manager,t,{pointers:n[0],changedPointers:n[1],pointerType:ue,srcEvent:e})}}});function Xe(e,t){var n=ee(e.touches),r=ee(e.changedTouches);return t&(A|j)&&(n=te(n.concat(r),`identifier`,!0)),[n,r]}var Ze={touchstart:k,touchmove:me,touchend:A,touchcancel:j},Qe=`touchstart touchmove touchend touchcancel`;function $e(){this.evTarget=Qe,this.targetIds={},M.apply(this,arguments)}v($e,M,{handler:function(e){var t=Ze[e.type],n=et.call(this,e,t);n&&this.callback(this.manager,t,{pointers:n[0],changedPointers:n[1],pointerType:ue,srcEvent:e})}});function et(e,t){var n=ee(e.touches),r=this.targetIds;if(t&(k|me)&&n.length===1)return r[n[0].identifier]=!0,[n,n];var i,a,o=ee(e.changedTouches),s=[],c=this.target;if(a=n.filter(function(e){return w(e.target,c)}),t===k)for(i=0;i<a.length;)r[a[i].identifier]=!0,i++;for(i=0;i<o.length;)r[o[i].identifier]&&s.push(o[i]),t&(A|j)&&delete r[o[i].identifier],i++;if(s.length)return[te(a.concat(s),`identifier`,!0),s]}var tt=2500,nt=25;function rt(){M.apply(this,arguments);var e=y(this.handler,this);this.touch=new $e(this.manager,e),this.mouse=new Be(this.manager,e),this.primaryTouch=null,this.lastTouches=[]}v(rt,M,{handler:function(e,t,n){var r=n.pointerType==ue,i=n.pointerType==O;if(!(i&&n.sourceCapabilities&&n.sourceCapabilities.firesTouchEvents)){if(r)it.call(this,t,n);else if(i&&ot.call(this,n))return;this.callback(e,t,n)}},destroy:function(){this.touch.destroy(),this.mouse.destroy()}});function it(e,t){e&k?(this.primaryTouch=t.changedPointers[0].identifier,at.call(this,t)):e&(A|j)&&at.call(this,t)}function at(e){var t=e.changedPointers[0];if(t.identifier===this.primaryTouch){var n={x:t.clientX,y:t.clientY};this.lastTouches.push(n);var r=this.lastTouches;setTimeout(function(){var e=r.indexOf(n);e>-1&&r.splice(e,1)},tt)}}function ot(e){for(var t=e.srcEvent.clientX,n=e.srcEvent.clientY,r=0;r<this.lastTouches.length;r++){var i=this.lastTouches[r],a=Math.abs(t-i.x),o=Math.abs(n-i.y);if(a<=nt&&o<=nt)return!0}return!1}var st=ne(o.style,`touchAction`),ct=st!==i,lt=`compute`,ut=`auto`,dt=`manipulation`,ft=`none`,pt=`pan-x`,mt=`pan-y`,ht=vt();function gt(e,t){this.manager=e,this.set(t)}gt.prototype={set:function(e){e==lt&&(e=this.compute()),ct&&this.manager.element.style&&ht[e]&&(this.manager.element.style[st]=e),this.actions=e.toLowerCase().trim()},update:function(){this.set(this.manager.options.touchAction)},compute:function(){var e=[];return p(this.manager.recognizers,function(t){b(t.options.enable,[t])&&(e=e.concat(t.getTouchAction()))}),_t(e.join(` `))},preventDefaults:function(e){var t=e.srcEvent,n=e.offsetDirection;if(this.manager.session.prevented){t.preventDefault();return}var r=this.actions,i=T(r,ft)&&!ht[ft],a=T(r,mt)&&!ht[mt],o=T(r,pt)&&!ht[pt];if(i){var s=e.pointers.length===1,c=e.distance<2,l=e.deltaTime<250;if(s&&c&&l)return}if(!(o&&a)&&(i||a&&n&be||o&&n&xe))return this.preventSrc(t)},preventSrc:function(e){this.manager.session.prevented=!0,e.preventDefault()}};function _t(e){if(T(e,ft))return ft;var t=T(e,pt),n=T(e,mt);return t&&n?ft:t||n?t?pt:mt:T(e,dt)?dt:ut}function vt(){if(!ct)return!1;var t={},n=e.CSS&&e.CSS.supports;return[`auto`,`manipulation`,`pan-y`,`pan-x`,`pan-x pan-y`,`none`].forEach(function(r){t[r]=n?e.CSS.supports(`touch-action`,r):!0}),t}var yt=1,bt=2,xt=4,P=8,F=P,St=16,I=32;function Ct(e){this.options=h({},this.defaults,e||{}),this.id=ie(),this.manager=null,this.options.enable=x(this.options.enable,!0),this.state=yt,this.simultaneous={},this.requireFail=[]}Ct.prototype={defaults:{},set:function(e){return h(this.options,e),this.manager&&this.manager.touchAction.update(),this},recognizeWith:function(e){if(f(e,`recognizeWith`,this))return this;var t=this.simultaneous;return e=Et(e,this),t[e.id]||(t[e.id]=e,e.recognizeWith(this)),this},dropRecognizeWith:function(e){return f(e,`dropRecognizeWith`,this)?this:(e=Et(e,this),delete this.simultaneous[e.id],this)},requireFailure:function(e){if(f(e,`requireFailure`,this))return this;var t=this.requireFail;return e=Et(e,this),D(t,e)===-1&&(t.push(e),e.requireFailure(this)),this},dropRequireFailure:function(e){if(f(e,`dropRequireFailure`,this))return this;e=Et(e,this);var t=D(this.requireFail,e);return t>-1&&this.requireFail.splice(t,1),this},hasRequireFailures:function(){return this.requireFail.length>0},canRecognizeWith:function(e){return!!this.simultaneous[e.id]},emit:function(e){var t=this,n=this.state;function r(n){t.manager.emit(n,e)}n<P&&r(t.options.event+wt(n)),r(t.options.event),e.additionalEvent&&r(e.additionalEvent),n>=P&&r(t.options.event+wt(n))},tryEmit:function(e){if(this.canEmit())return this.emit(e);this.state=I},canEmit:function(){for(var e=0;e<this.requireFail.length;){if(!(this.requireFail[e].state&(I|yt)))return!1;e++}return!0},recognize:function(e){var t=h({},e);if(!b(this.options.enable,[this,t])){this.reset(),this.state=I;return}this.state&(F|St|I)&&(this.state=yt),this.state=this.process(t),this.state&(bt|xt|P|St)&&this.tryEmit(t)},process:function(e){},getTouchAction:function(){},reset:function(){}};function wt(e){return e&St?`cancel`:e&P?`end`:e&xt?`move`:e&bt?`start`:``}function Tt(e){return e==ye?`down`:e==ve?`up`:e==ge?`left`:e==_e?`right`:``}function Et(e,t){var n=t.manager;return n?n.get(e):e}function Dt(){Ct.apply(this,arguments)}v(Dt,Ct,{defaults:{pointers:1},attrTest:function(e){var t=this.options.pointers;return t===0||e.pointers.length===t},process:function(e){var t=this.state,n=e.eventType,r=t&(bt|xt),i=this.attrTest(e);return r&&(n&j||!i)?t|St:r||i?n&A?t|P:t&bt?t|xt:bt:I}});function Ot(){Dt.apply(this,arguments),this.pX=null,this.pY=null}v(Ot,Dt,{defaults:{event:`pan`,threshold:10,pointers:1,direction:Se},getTouchAction:function(){var e=this.options.direction,t=[];return e&be&&t.push(mt),e&xe&&t.push(pt),t},directionTest:function(e){var t=this.options,n=!0,r=e.distance,i=e.direction,a=e.deltaX,o=e.deltaY;return i&t.direction||(t.direction&be?(i=a===0?he:a<0?ge:_e,n=a!=this.pX,r=Math.abs(e.deltaX)):(i=o===0?he:o<0?ve:ye,n=o!=this.pY,r=Math.abs(e.deltaY))),e.direction=i,n&&r>t.threshold&&i&t.direction},attrTest:function(e){return Dt.prototype.attrTest.call(this,e)&&(this.state&bt||!(this.state&bt)&&this.directionTest(e))},emit:function(e){this.pX=e.deltaX,this.pY=e.deltaY;var t=Tt(e.direction);t&&(e.additionalEvent=this.options.event+t),this._super.emit.call(this,e)}});function kt(){Dt.apply(this,arguments)}v(kt,Dt,{defaults:{event:`pinch`,threshold:0,pointers:2},getTouchAction:function(){return[ft]},attrTest:function(e){return this._super.attrTest.call(this,e)&&(Math.abs(e.scale-1)>this.options.threshold||this.state&bt)},emit:function(e){if(e.scale!==1){var t=e.scale<1?`in`:`out`;e.additionalEvent=this.options.event+t}this._super.emit.call(this,e)}});function At(){Ct.apply(this,arguments),this._timer=null,this._input=null}v(At,Ct,{defaults:{event:`press`,pointers:1,time:251,threshold:9},getTouchAction:function(){return[ut]},process:function(e){var t=this.options,n=e.pointers.length===t.pointers,r=e.distance<t.threshold,i=e.deltaTime>t.time;if(this._input=e,!r||!n||e.eventType&(A|j)&&!i)this.reset();else if(e.eventType&k)this.reset(),this._timer=d(function(){this.state=F,this.tryEmit()},t.time,this);else if(e.eventType&A)return F;return I},reset:function(){clearTimeout(this._timer)},emit:function(e){this.state===F&&(e&&e.eventType&A?this.manager.emit(this.options.event+`up`,e):(this._input.timeStamp=u(),this.manager.emit(this.options.event,this._input)))}});function jt(){Dt.apply(this,arguments)}v(jt,Dt,{defaults:{event:`rotate`,threshold:0,pointers:2},getTouchAction:function(){return[ft]},attrTest:function(e){return this._super.attrTest.call(this,e)&&(Math.abs(e.rotation)>this.options.threshold||this.state&bt)}});function Mt(){Dt.apply(this,arguments)}v(Mt,Dt,{defaults:{event:`swipe`,threshold:10,velocity:.3,direction:be|xe,pointers:1},getTouchAction:function(){return Ot.prototype.getTouchAction.call(this)},attrTest:function(e){var t=this.options.direction,n;return t&(be|xe)?n=e.overallVelocity:t&be?n=e.overallVelocityX:t&xe&&(n=e.overallVelocityY),this._super.attrTest.call(this,e)&&t&e.offsetDirection&&e.distance>this.options.threshold&&e.maxPointers==this.options.pointers&&l(n)>this.options.velocity&&e.eventType&A},emit:function(e){var t=Tt(e.offsetDirection);t&&this.manager.emit(this.options.event+t,e),this.manager.emit(this.options.event,e)}});function Nt(){Ct.apply(this,arguments),this.pTime=!1,this.pCenter=!1,this._timer=null,this._input=null,this.count=0}v(Nt,Ct,{defaults:{event:`tap`,pointers:1,taps:1,interval:300,time:250,threshold:9,posThreshold:10},getTouchAction:function(){return[dt]},process:function(e){var t=this.options,n=e.pointers.length===t.pointers,r=e.distance<t.threshold,i=e.deltaTime<t.time;if(this.reset(),e.eventType&k&&this.count===0)return this.failTimeout();if(r&&i&&n){if(e.eventType!=A)return this.failTimeout();var a=this.pTime?e.timeStamp-this.pTime<t.interval:!0,o=!this.pCenter||Ne(this.pCenter,e.center)<t.posThreshold;if(this.pTime=e.timeStamp,this.pCenter=e.center,!o||!a?this.count=1:this.count+=1,this._input=e,this.count%t.taps===0)return this.hasRequireFailures()?(this._timer=d(function(){this.state=F,this.tryEmit()},t.interval,this),bt):F}return I},failTimeout:function(){return this._timer=d(function(){this.state=I},this.options.interval,this),I},reset:function(){clearTimeout(this._timer)},emit:function(){this.state==F&&(this._input.tapCount=this.count,this.manager.emit(this.options.event,this._input))}});function Pt(e,t){return t||={},t.recognizers=x(t.recognizers,Pt.defaults.preset),new Lt(e,t)}Pt.VERSION=`2.0.7`,Pt.defaults={domEvents:!1,touchAction:lt,enable:!0,inputTarget:null,inputClass:null,preset:[[jt,{enable:!1}],[kt,{enable:!1},[`rotate`]],[Mt,{direction:be}],[Ot,{direction:be},[`swipe`]],[Nt],[Nt,{event:`doubletap`,taps:2},[`tap`]],[At]],cssProps:{userSelect:`none`,touchSelect:`none`,touchCallout:`none`,contentZooming:`none`,userDrag:`none`,tapHighlightColor:`rgba(0,0,0,0)`}};var Ft=1,It=2;function Lt(e,t){this.options=h({},Pt.defaults,t||{}),this.options.inputTarget=this.options.inputTarget||e,this.handlers={},this.session={},this.recognizers=[],this.oldCssProps={},this.element=e,this.input=Te(this),this.touchAction=new gt(this,this.options.touchAction),Rt(this,!0),p(this.options.recognizers,function(e){var t=this.add(new e[0](e[1]));e[2]&&t.recognizeWith(e[2]),e[3]&&t.requireFailure(e[3])},this)}Lt.prototype={set:function(e){return h(this.options,e),e.touchAction&&this.touchAction.update(),e.inputTarget&&(this.input.destroy(),this.input.target=e.inputTarget,this.input.init()),this},stop:function(e){this.session.stopped=e?It:Ft},recognize:function(e){var t=this.session;if(!t.stopped){this.touchAction.preventDefaults(e);var n,r=this.recognizers,i=t.curRecognizer;(!i||i&&i.state&F)&&(i=t.curRecognizer=null);for(var a=0;a<r.length;)n=r[a],t.stopped!==It&&(!i||n==i||n.canRecognizeWith(i))?n.recognize(e):n.reset(),!i&&n.state&(bt|xt|P)&&(i=t.curRecognizer=n),a++}},get:function(e){if(e instanceof Ct)return e;for(var t=this.recognizers,n=0;n<t.length;n++)if(t[n].options.event==e)return t[n];return null},add:function(e){if(f(e,`add`,this))return this;var t=this.get(e.options.event);return t&&this.remove(t),this.recognizers.push(e),e.manager=this,this.touchAction.update(),e},remove:function(e){if(f(e,`remove`,this))return this;if(e=this.get(e),e){var t=this.recognizers,n=D(t,e);n!==-1&&(t.splice(n,1),this.touchAction.update())}return this},on:function(e,t){if(e!==i&&t!==i){var n=this.handlers;return p(E(e),function(e){n[e]=n[e]||[],n[e].push(t)}),this}},off:function(e,t){if(e!==i){var n=this.handlers;return p(E(e),function(e){t?n[e]&&n[e].splice(D(n[e],t),1):delete n[e]}),this}},emit:function(e,t){this.options.domEvents&&zt(e,t);var n=this.handlers[e]&&this.handlers[e].slice();if(!(!n||!n.length)){t.type=e,t.preventDefault=function(){t.srcEvent.preventDefault()};for(var r=0;r<n.length;)n[r](t),r++}},destroy:function(){this.element&&Rt(this,!1),this.handlers={},this.session={},this.input.destroy(),this.element=null}};function Rt(e,t){var n=e.element;if(n.style){var r;p(e.options.cssProps,function(i,a){r=ne(n.style,a),t?(e.oldCssProps[r]=n.style[r],n.style[r]=i):n.style[r]=e.oldCssProps[r]||``}),t||(e.oldCssProps={})}}function zt(e,t){var r=n.createEvent(`Event`);r.initEvent(e,!0,!0),r.gesture=t,t.target.dispatchEvent(r)}h(Pt,{INPUT_START:k,INPUT_MOVE:me,INPUT_END:A,INPUT_CANCEL:j,STATE_POSSIBLE:yt,STATE_BEGAN:bt,STATE_CHANGED:xt,STATE_ENDED:P,STATE_RECOGNIZED:F,STATE_CANCELLED:St,STATE_FAILED:I,DIRECTION_NONE:he,DIRECTION_LEFT:ge,DIRECTION_RIGHT:_e,DIRECTION_UP:ve,DIRECTION_DOWN:ye,DIRECTION_HORIZONTAL:be,DIRECTION_VERTICAL:xe,DIRECTION_ALL:Se,Manager:Lt,Input:M,TouchAction:gt,TouchInput:$e,MouseInput:Be,PointerEventInput:Ge,TouchMouseInput:rt,SingleTouchInput:Ye,Recognizer:Ct,AttrRecognizer:Dt,Tap:Nt,Pan:Ot,Swipe:Mt,Pinch:kt,Rotate:jt,Press:At,on:S,off:C,each:p,merge:_,extend:g,assign:h,inherit:v,bindFn:y,prefixed:ne});var Bt=e===void 0?typeof self<`u`?self:{}:e;Bt.Hammer=Pt,typeof define==`function`&&define.amd?define(function(){return Pt}):t!==void 0&&t.exports?t.exports=Pt:e[r]=Pt})(window,document,`Hammer`)}))()),Ff=e=>e&&e.enabled&&e.modifierKey,If=(e,t)=>e&&t[e+`Key`],Lf=(e,t)=>e&&!t[e+`Key`];function Rf(e,t,n){return e===void 0?!0:typeof e==`string`?e.indexOf(t)!==-1:typeof e==`function`?e({chart:n}).indexOf(t)!==-1:!1}function zf(e,t){return typeof e==`function`&&(e=e({chart:t})),typeof e==`string`?{x:e.indexOf(`x`)!==-1,y:e.indexOf(`y`)!==-1}:{x:!1,y:!1}}function Bf(e,t){let n;return function(){return clearTimeout(n),n=setTimeout(e,t),t}}function Vf({x:e,y:t},n){let r=n.scales,i=Object.keys(r);for(let n=0;n<i.length;n++){let a=r[i[n]];if(t>=a.top&&t<=a.bottom&&e>=a.left&&e<=a.right)return a}return null}function Hf(e,t,n){let{mode:r=`xy`,scaleMode:i,overScaleMode:a}=e||{},o=Vf(t,n),s=zf(r,n),c=zf(i,n);if(a){let e=zf(a,n);for(let t of[`x`,`y`])e[t]&&(c[t]=s[t],s[t]=!1)}if(o&&c[o.axis])return[o];let l=[];return U(n.scales,function(e){s[e.axis]&&l.push(e)}),l}var Uf=new WeakMap;function $(e){let t=Uf.get(e);return t||(t={originalScaleLimits:{},updatedScaleLimits:{},handlers:{},panDelta:{},dragging:!1,panning:!1},Uf.set(e,t)),t}function Wf(e){Uf.delete(e)}function Gf(e,t,n,r){let i=Math.max(0,Math.min(1,(e-t)/n||0)),a=1-i;return{min:r*i,max:r*a}}function Kf(e,t){let n=e.isHorizontal()?t.x:t.y;return e.getValueForPixel(n)}function qf(e,t,n){let r=e.max-e.min,i=r*(t-1);return Gf(Kf(e,n),e.min,r,i)}function Jf(e,t,n){let r=Kf(e,n);if(r===void 0)return{min:e.min,max:e.max};let i=Math.log10(e.min),a=Math.log10(e.max),o=Math.log10(r),s=a-i,c=Gf(o,i,s,s*(t-1));return{min:10**(i+c.min),max:10**(a-c.max)}}function Yf(e,t){return t&&(t[e.id]||t[e.axis])||{}}function Xf(e,t,n,r,i){let a=n[r];if(a===`original`){let n=e.originalScaleLimits[t.id][r];a=V(n.options,n.scale)}return V(a,i)}function Zf(e,t,n){let r=e.getValueForPixel(t),i=e.getValueForPixel(n);return{min:Math.min(r,i),max:Math.max(r,i)}}function Qf(e,{min:t,max:n,minLimit:r,maxLimit:i},a){let o=(e-n+t)/2;t-=o,n+=o;let s=a.min.options??a.min.scale,c=a.max.options??a.max.scale,l=e/1e6;return li(t,s,l)&&(t=s),li(n,c,l)&&(n=c),t<r?(t=r,n=Math.min(r+e,i)):n>i&&(n=i,t=Math.max(i-e,r)),{min:t,max:n}}function $f(e,{min:t,max:n},r,i=!1){let a=$(e.chart),{options:o}=e,s=Yf(e,r),{minRange:c=0}=s,l=Xf(a,e,s,`min`,-1/0),u=Xf(a,e,s,`max`,1/0);if(i===`pan`&&(t<l||n>u))return!0;let d=e.max-e.min,f=i?Math.max(n-t,c):d;if(i&&f===c&&d<=c)return!0;let p=Qf(f,{min:t,max:n,minLimit:l,maxLimit:u},a.originalScaleLimits[e.id]);return o.min=p.min,o.max=p.max,a.updatedScaleLimits[e.id]=p,e.parse(p.min)!==e.min||e.parse(p.max)!==e.max}function ep(e,t,n,r){let i=qf(e,t,n);return $f(e,{min:e.min+i.min,max:e.max-i.max},r,!0)}function tp(e,t,n,r){return $f(e,Jf(e,t,n),r,!0)}function np(e,t,n,r){$f(e,Zf(e,t,n),r,!0)}var rp=e=>e===0||isNaN(e)?0:e<0?Math.min(Math.round(e),-1):Math.max(Math.round(e),1);function ip(e){let t=e.getLabels().length-1;e.min>0&&--e.min,e.max<t&&(e.max+=1)}function ap(e,t,n,r){let i=qf(e,t,n);return e.min===e.max&&t<1&&ip(e),$f(e,{min:e.min+rp(i.min),max:e.max-rp(i.max)},r,!0)}function op(e){return e.isHorizontal()?e.width:e.height}function sp(e,t,n){let r=e.getLabels().length-1,{min:i,max:a}=e,o=Math.max(a-i,1),s=Math.round(op(e)/Math.max(o,10)),c=Math.round(Math.abs(t/s)),l;return t<-s?(a=Math.min(a+c,r),i=o===1?a:a-o,l=a===r):t>s&&(i=Math.max(0,i-c),a=o===1?i:i+o,l=i===0),$f(e,{min:i,max:a},n)||l}var cp={second:500,minute:30*1e3,hour:1800*1e3,day:720*60*1e3,week:3.5*24*60*60*1e3,month:360*60*60*1e3,quarter:1440*60*60*1e3,year:4368*60*60*1e3};function lp(e,t,n,r=!1){let{min:i,max:a,options:o}=e,s=cp[o.time&&o.time.round]||0,c=e.getValueForPixel(e.getPixelForValue(i+s)-t),l=e.getValueForPixel(e.getPixelForValue(a+s)-t);return isNaN(c)||isNaN(l)?!0:$f(e,{min:c,max:l},n,r?`pan`:!1)}function up(e,t,n){return lp(e,t,n,!0)}var dp={category:ap,default:ep,logarithmic:tp},fp={default:np},pp={category:sp,default:lp,logarithmic:up,timeseries:up};function mp(e,t,n){let{id:r,options:{min:i,max:a}}=e;if(!t[r]||!n[r])return!0;let o=n[r];return o.min!==i||o.max!==a}function hp(e,t){U(e,(n,r)=>{t[r]||delete e[r]})}function gp(e,t){let{scales:n}=e,{originalScaleLimits:r,updatedScaleLimits:i}=t;return U(n,function(e){mp(e,r,i)&&(r[e.id]={min:{scale:e.min,options:e.options.min},max:{scale:e.max,options:e.options.max}})}),hp(r,n),hp(i,n),r}function _p(e,t,n,r){H(dp[e.type]||dp.default,[e,t,n,r])}function vp(e,t,n,r){H(fp[e.type]||fp.default,[e,t,n,r])}function yp(e){let t=e.chartArea;return{x:(t.left+t.right)/2,y:(t.top+t.bottom)/2}}function bp(e,t,n=`none`,r=`api`){let{x:i=1,y:a=1,focalPoint:o=yp(e)}=typeof t==`number`?{x:t,y:t}:t,s=$(e),{options:{limits:c,zoom:l}}=s;gp(e,s);let u=i!==1,d=a!==1;U(Hf(l,o,e)||e.scales,function(e){e.isHorizontal()&&u?_p(e,i,o,c):!e.isHorizontal()&&d&&_p(e,a,o,c)}),e.update(n),H(l.onZoom,[{chart:e,trigger:r}])}function xp(e,t,n,r=`none`,i=`api`){let a=$(e),{options:{limits:o,zoom:s}}=a,{mode:c=`xy`}=s;gp(e,a);let l=Rf(c,`x`,e),u=Rf(c,`y`,e);U(e.scales,function(e){e.isHorizontal()&&l?vp(e,t.x,n.x,o):!e.isHorizontal()&&u&&vp(e,t.y,n.y,o)}),e.update(r),H(s.onZoom,[{chart:e,trigger:i}])}function Sp(e,t,n,r=`none`,i=`api`){let a=$(e);gp(e,a);let o=e.scales[t];$f(o,n,void 0,!0),e.update(r),H(a.options.zoom?.onZoom,[{chart:e,trigger:i}])}function Cp(e,t=`default`){let n=$(e),r=gp(e,n);U(e.scales,function(e){let t=e.options;r[e.id]?(t.min=r[e.id].min.options,t.max=r[e.id].max.options):(delete t.min,delete t.max),delete n.updatedScaleLimits[e.id]}),e.update(t),H(n.options.zoom.onZoomComplete,[{chart:e}])}function wp(e,t){let n=e.originalScaleLimits[t];if(!n)return;let{min:r,max:i}=n;return V(i.options,i.scale)-V(r.options,r.scale)}function Tp(e){let t=$(e),n=1,r=1;return U(e.scales,function(e){let i=wp(t,e.id);if(i){let t=Math.round(i/(e.max-e.min)*100)/100;n=Math.min(n,t),r=Math.max(r,t)}}),n<1?n:r}function Ep(e,t,n,r){let{panDelta:i}=r,a=i[e.id]||0;ci(a)===ci(t)&&(t+=a),H(pp[e.type]||pp.default,[e,t,n])?i[e.id]=0:i[e.id]=t}function Dp(e,t,n,r=`none`){let{x:i=0,y:a=0}=typeof t==`number`?{x:t,y:t}:t,o=$(e),{options:{pan:s,limits:c}}=o,{onPan:l}=s||{};gp(e,o);let u=i!==0,d=a!==0;U(n||e.scales,function(e){e.isHorizontal()&&u?Ep(e,i,c,o):!e.isHorizontal()&&d&&Ep(e,a,c,o)}),e.update(r),H(l,[{chart:e}])}function Op(e){let t=$(e);gp(e,t);let n={};for(let r of Object.keys(e.scales)){let{min:e,max:i}=t.originalScaleLimits[r]||{min:{},max:{}};n[r]={min:e.scale,max:i.scale}}return n}function kp(e){let t=$(e),n={};for(let r of Object.keys(e.scales))n[r]=t.updatedScaleLimits[r];return n}function Ap(e){let t=Op(e);for(let n of Object.keys(e.scales)){let{min:r,max:i}=t[n];if(r!==void 0&&e.scales[n].min!==r||i!==void 0&&e.scales[n].max!==i)return!0}return!1}function jp(e){let t=$(e);return t.panning||t.dragging}var Mp=(e,t,n)=>Math.min(n,Math.max(t,e));function Np(e,t){let{handlers:n}=$(e),r=n[t];r&&r.target&&(r.target.removeEventListener(t,r),delete n[t])}function Pp(e,t,n,r){let{handlers:i,options:a}=$(e),o=i[n];if(o&&o.target===t)return;Np(e,n),i[n]=t=>r(e,t,a),i[n].target=t;let s=n===`wheel`?!1:void 0;t.addEventListener(n,i[n],{passive:s})}function Fp(e,t){let n=$(e);n.dragStart&&(n.dragging=!0,n.dragEnd=t,e.update(`none`))}function Ip(e,t){let n=$(e);!n.dragStart||t.key!==`Escape`||(Np(e,`keydown`),n.dragging=!1,n.dragStart=n.dragEnd=null,e.update(`none`))}function Lp(e,t){if(e.target!==t.canvas){let n=t.canvas.getBoundingClientRect();return{x:e.clientX-n.left,y:e.clientY-n.top}}return So(e,t)}function Rp(e,t,n){let{onZoomStart:r,onZoomRejected:i}=n;if(r&&H(r,[{chart:e,event:t,point:Lp(t,e)}])===!1)return H(i,[{chart:e,event:t}]),!1}function zp(e,t){if(e.legend&&ga(So(t,e),e.legend))return;let n=$(e),{pan:r,zoom:i={}}=n.options;if(t.button!==0||If(Ff(r),t)||Lf(Ff(i.drag),t))return H(i.onZoomRejected,[{chart:e,event:t}]);Rp(e,t,i)!==!1&&(n.dragStart=t,Pp(e,e.canvas.ownerDocument,`mousemove`,Fp),Pp(e,window.document,`keydown`,Ip))}function Bp({begin:e,end:t},n){let r=t.x-e.x,i=t.y-e.y,a=Math.abs(r/i);a>n?r=Math.sign(r)*Math.abs(i*n):a<n&&(i=Math.sign(i)*Math.abs(r/n)),t.x=e.x+r,t.y=e.y+i}function Vp(e,t,n,{min:r,max:i,prop:a}){e[r]=Mp(Math.min(n.begin[a],n.end[a]),t[r],t[i]),e[i]=Mp(Math.max(n.begin[a],n.end[a]),t[r],t[i])}function Hp(e,t,n){let r={begin:Lp(t.dragStart,e),end:Lp(t.dragEnd,e)};return n&&Bp(r,e.chartArea.width/e.chartArea.height),r}function Up(e,t,n,r){let i=Rf(t,`x`,e),a=Rf(t,`y`,e),{top:o,left:s,right:c,bottom:l,width:u,height:d}=e.chartArea,f={top:o,left:s,right:c,bottom:l},p=Hp(e,n,r&&i&&a);i&&Vp(f,e.chartArea,p,{min:`left`,max:`right`,prop:`x`}),a&&Vp(f,e.chartArea,p,{min:`top`,max:`bottom`,prop:`y`});let m=f.right-f.left,h=f.bottom-f.top;return{...f,width:m,height:h,zoomX:i&&m?1+(u-m)/u:1,zoomY:a&&h?1+(d-h)/d:1}}function Wp(e,t){let n=$(e);if(!n.dragStart)return;Np(e,`mousemove`);let{mode:r,onZoomComplete:i,drag:{threshold:a=0,maintainAspectRatio:o}}=n.options.zoom,s=Up(e,r,{dragStart:n.dragStart,dragEnd:t},o),c=Rf(r,`x`,e)?s.width:0,l=Rf(r,`y`,e)?s.height:0,u=Math.sqrt(c*c+l*l);if(n.dragStart=n.dragEnd=null,u<=a){n.dragging=!1,e.update(`none`);return}xp(e,{x:s.left,y:s.top},{x:s.right,y:s.bottom},`zoom`,`drag`),n.dragging=!1,n.filterNextClick=!0,H(i,[{chart:e}])}function Gp(e,t,n){if(Lf(Ff(n.wheel),t)){H(n.onZoomRejected,[{chart:e,event:t}]);return}if(Rp(e,t,n)!==!1&&(t.cancelable&&t.preventDefault(),t.deltaY!==void 0))return!0}function Kp(e,t){let{handlers:{onZoomComplete:n},options:{zoom:r}}=$(e);if(!Gp(e,t,r))return;let i=t.target.getBoundingClientRect(),a=r.wheel.speed,o=t.deltaY>=0?2-1/(1-a):1+a;bp(e,{x:o,y:o,focalPoint:{x:t.clientX-i.left,y:t.clientY-i.top}},`zoom`,`wheel`),H(n,[{chart:e}])}function qp(e,t,n,r){n&&($(e).handlers[t]=Bf(()=>H(n,[{chart:e}]),r))}function Jp(e,t){let n=e.canvas,{wheel:r,drag:i,onZoomComplete:a}=t.zoom;r.enabled?(Pp(e,n,`wheel`,Kp),qp(e,`onZoomComplete`,a,250)):Np(e,`wheel`),i.enabled?(Pp(e,n,`mousedown`,zp),Pp(e,n.ownerDocument,`mouseup`,Wp)):(Np(e,`mousedown`),Np(e,`mousemove`),Np(e,`mouseup`),Np(e,`keydown`))}function Yp(e){Np(e,`mousedown`),Np(e,`mousemove`),Np(e,`mouseup`),Np(e,`wheel`),Np(e,`click`),Np(e,`keydown`)}function Xp(e,t){return function(n,r){let{pan:i,zoom:a={}}=t.options;if(!i||!i.enabled)return!1;let o=r&&r.srcEvent;return o&&!t.panning&&r.pointerType===`mouse`&&(Lf(Ff(i),o)||If(Ff(a.drag),o))?(H(i.onPanRejected,[{chart:e,event:r}]),!1):!0}}function Zp(e,t){let n=Math.abs(e.clientX-t.clientX),r=Math.abs(e.clientY-t.clientY),i=n/r,a,o;return i>.3&&i<1.7?a=o=!0:n>r?a=!0:o=!0,{x:a,y:o}}function Qp(e,t,n){if(t.scale){let{center:r,pointers:i}=n,a=1/t.scale*n.scale,o=n.target.getBoundingClientRect(),s=Zp(i[0],i[1]),c=t.options.zoom.mode;bp(e,{x:s.x&&Rf(c,`x`,e)?a:1,y:s.y&&Rf(c,`y`,e)?a:1,focalPoint:{x:r.x-o.left,y:r.y-o.top}},`zoom`,`pinch`),t.scale=n.scale}}function $p(e,t,n){if(t.options.zoom.pinch.enabled){let r=So(n,e);H(t.options.zoom.onZoomStart,[{chart:e,event:n,point:r}])===!1?(t.scale=null,H(t.options.zoom.onZoomRejected,[{chart:e,event:n}])):t.scale=1}}function em(e,t,n){t.scale&&(Qp(e,t,n),t.scale=null,H(t.options.zoom.onZoomComplete,[{chart:e}]))}function tm(e,t,n){let r=t.delta;r&&(t.panning=!0,Dp(e,{x:n.deltaX-r.x,y:n.deltaY-r.y},t.panScales),t.delta={x:n.deltaX,y:n.deltaY})}function nm(e,t,n){let{enabled:r,onPanStart:i,onPanRejected:a}=t.options.pan;if(!r)return;let o=n.target.getBoundingClientRect(),s={x:n.center.x-o.left,y:n.center.y-o.top};if(H(i,[{chart:e,event:n,point:s}])===!1)return H(a,[{chart:e,event:n}]);t.panScales=Hf(t.options.pan,s,e),t.delta={x:0,y:0},tm(e,t,n)}function rm(e,t){t.delta=null,t.panning&&(t.panning=!1,t.filterNextClick=!0,H(t.options.pan.onPanComplete,[{chart:e}]))}var im=new WeakMap;function am(e,t){let n=$(e),r=e.canvas,{pan:i,zoom:a}=t,o=new Pf.default.Manager(r);a&&a.pinch.enabled&&(o.add(new Pf.default.Pinch),o.on(`pinchstart`,t=>$p(e,n,t)),o.on(`pinch`,t=>Qp(e,n,t)),o.on(`pinchend`,t=>em(e,n,t))),i&&i.enabled&&(o.add(new Pf.default.Pan({threshold:i.threshold,enable:Xp(e,n)})),o.on(`panstart`,t=>nm(e,n,t)),o.on(`panmove`,t=>tm(e,n,t)),o.on(`panend`,()=>rm(e,n))),im.set(e,o)}function om(e){let t=im.get(e);t&&(t.remove(`pinchstart`),t.remove(`pinch`),t.remove(`pinchend`),t.remove(`panstart`),t.remove(`pan`),t.remove(`panend`),t.destroy(),im.delete(e))}function sm(e,t){let{pan:n,zoom:r}=e,{pan:i,zoom:a}=t;return r?.zoom?.pinch?.enabled!==a?.zoom?.pinch?.enabled||n?.enabled!==i?.enabled||n?.threshold!==i?.threshold}var cm=`2.2.0`;function lm(e,t,n){let r=n.zoom.drag,{dragStart:i,dragEnd:a}=$(e);if(r.drawTime!==t||!a)return;let{left:o,top:s,width:c,height:l}=Up(e,n.zoom.mode,{dragStart:i,dragEnd:a},r.maintainAspectRatio),u=e.ctx;u.save(),u.beginPath(),u.fillStyle=r.backgroundColor||`rgba(225,225,225,0.3)`,u.fillRect(o,s,c,l),r.borderWidth>0&&(u.lineWidth=r.borderWidth,u.strokeStyle=r.borderColor||`rgba(225,225,225)`,u.strokeRect(o,s,c,l)),u.restore()}var um={id:`zoom`,version:cm,defaults:{pan:{enabled:!1,mode:`xy`,threshold:10,modifierKey:null},zoom:{wheel:{enabled:!1,speed:.1,modifierKey:null},drag:{enabled:!1,drawTime:`beforeDatasetsDraw`,modifierKey:null},pinch:{enabled:!1},mode:`xy`}},start:function(e,t,n){let r=$(e);r.options=n,Object.prototype.hasOwnProperty.call(n.zoom,`enabled`)&&console.warn("The option `zoom.enabled` is no longer supported. Please use `zoom.wheel.enabled`, `zoom.drag.enabled`, or `zoom.pinch.enabled`."),(Object.prototype.hasOwnProperty.call(n.zoom,`overScaleMode`)||Object.prototype.hasOwnProperty.call(n.pan,`overScaleMode`))&&console.warn("The option `overScaleMode` is deprecated. Please use `scaleMode` instead (and update `mode` as desired)."),Pf.default&&am(e,n),e.pan=(t,n,r)=>Dp(e,t,n,r),e.zoom=(t,n)=>bp(e,t,n),e.zoomRect=(t,n,r)=>xp(e,t,n,r),e.zoomScale=(t,n,r)=>Sp(e,t,n,r),e.resetZoom=t=>Cp(e,t),e.getZoomLevel=()=>Tp(e),e.getInitialScaleBounds=()=>Op(e),e.getZoomedScaleBounds=()=>kp(e),e.isZoomedOrPanned=()=>Ap(e),e.isZoomingOrPanning=()=>jp(e)},beforeEvent(e,{event:t}){if(jp(e))return!1;if(t.type===`click`||t.type===`mouseup`){let t=$(e);if(t.filterNextClick)return t.filterNextClick=!1,!1}},beforeUpdate:function(e,t,n){let r=$(e),i=r.options;r.options=n,sm(i,n)&&(om(e),am(e,n)),Jp(e,n)},beforeDatasetsDraw(e,t,n){lm(e,`beforeDatasetsDraw`,n)},afterDatasetsDraw(e,t,n){lm(e,`afterDatasetsDraw`,n)},beforeDraw(e,t,n){lm(e,`beforeDraw`,n)},afterDraw(e,t,n){lm(e,`afterDraw`,n)},stop:function(e){Yp(e),Pf.default&&om(e),Wf(e)},panFunctions:pp,zoomFunctions:dp,zoomRectFunctions:fp},dm;eu.register(Ws,Cu,Tu,Yd,jf,Bd,xd,fd,um);var fm=[`#3b82f6`,`#ef4444`,`#10b981`,`#f59e0b`,`#8b5cf6`,`#ec4899`,`#06b6d4`,`#84cc16`,`#f97316`,`#6366f1`],pm=[{label:`5m`,ms:5*6e4},{label:`15m`,ms:15*6e4},{label:`1h`,ms:60*6e4},{label:`6h`,ms:360*6e4},{label:`All`,ms:null}],mm=(dm=class extends l{constructor(...e){super(...e),this.content=``,this.hiddenSeries=new Set,this.activeZoom=`All`,this.error=!1,this.chart=null,this.buildPending=!1,this._cachedContent=``,this._cachedParsed=null,this._boundWrap=null,this.onWrapWheel=e=>{this.chart&&(e.preventDefault(),e.stopPropagation())}}disconnectedCallback(){super.disconnectedCallback(),this.destroyChart(),this.detachWrapListeners()}destroyChart(){this.chart&&=(this.chart.destroy(),null)}attachWrapListeners(){this.detachWrapListeners();let e=this.shadowRoot?.querySelector(`.chart-wrap`);e&&(this._boundWrap=e,e.addEventListener(`wheel`,this.onWrapWheel,{passive:!1}))}detachWrapListeners(){this._boundWrap&&=(this._boundWrap.removeEventListener(`wheel`,this.onWrapWheel),null)}updated(e){e.has(`content`)&&(this.hiddenSeries=new Set,this.activeZoom=`All`,this.error=!1,this._cachedContent=this.content,this._cachedParsed=an(this.content),this.scheduleBuild())}get parsed(){return this._cachedContent!==this.content&&(this._cachedContent=this.content,this._cachedParsed=an(this.content)),this._cachedParsed}scheduleBuild(){this.buildPending||(this.buildPending=!0,setTimeout(()=>{this.buildPending=!1,this.buildChart()},0))}getTimeRange(){let e=this.parsed;if(!e)return null;let t=1/0,n=-1/0;for(let r of e.series)for(let e of r.data)e.x<t&&(t=e.x),e.x>n&&(n=e.x);return isFinite(t)&&isFinite(n)?{min:t,max:n}:null}buildChart(){this.destroyChart();let e=this.parsed;if(!e||e.series.length===0){this.error=!0;return}let t=this.shadowRoot?.querySelector(`canvas`);if(!t)return;let n=t.getContext(`2d`);if(!n)return;let r=getComputedStyle(this).getPropertyValue(`--text-secondary`).trim()||`#999`,i=getComputedStyle(this).getPropertyValue(`--border-secondary`).trim()||`rgba(128,128,128,0.2)`;this.chart=new eu(n,{type:`line`,data:{datasets:e.series.map((e,t)=>({label:e.name,data:e.data,borderColor:fm[t%fm.length],backgroundColor:fm[t%fm.length]+`22`,borderWidth:1.5,pointRadius:0,pointHitRadius:6,tension:.25,fill:!1,hidden:this.hiddenSeries.has(t)}))},options:{responsive:!0,maintainAspectRatio:!1,animation:{duration:300},interaction:{mode:`index`,intersect:!1},plugins:{legend:{display:!1},tooltip:{callbacks:{title:e=>{if(!e.length)return``;let t=e[0].parsed.x;return t==null?``:new Date(t).toLocaleString()}}},zoom:{pan:{enabled:!1},zoom:{wheel:{enabled:!0},drag:{enabled:!0,backgroundColor:`rgba(59,130,246,0.12)`,borderColor:`rgba(59,130,246,0.4)`,borderWidth:1},mode:`x`,onZoomComplete:()=>{this.activeZoom=``,this.requestUpdate()}}}},scales:{x:{type:`linear`,ticks:{color:r,font:{size:10},maxTicksLimit:8,callback:e=>new Date(e).toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`})},grid:{color:i}},y:{ticks:{color:r,font:{size:10},maxTicksLimit:6},grid:{color:i}}}}}),this.attachWrapListeners()}toggleSeries(e){let t=new Set(this.hiddenSeries);if(t.has(e)?t.delete(e):t.add(e),this.hiddenSeries=t,this.chart){let n=this.chart.getDatasetMeta(e);n.hidden=t.has(e),this.chart.update(`none`)}}toggleAllSeries(){let e=this.parsed;if(!e)return;let t=e.series.length,n=this.hiddenSeries.size===t;if(this.hiddenSeries=n?new Set:new Set(Array.from({length:t},(e,t)=>t)),this.chart){for(let e=0;e<t;e++)this.chart.getDatasetMeta(e).hidden=!n;this.chart.update(`none`)}}applyZoom(e){if(this.activeZoom=e.label,!this.chart)return;if(e.ms===null){this.chart.resetZoom(`default`);return}let t=this.getTimeRange();if(!t)return;let n=t.max,r=Math.max(t.min,n-e.ms);this.chart.zoomScale(`x`,{min:r,max:n},`default`)}renderLegend(e){let t=this.hiddenSeries.size===e.series.length;return a`
      <button
        class="legend-item toggle-all"
        @click=${()=>this.toggleAllSeries()}
        title="${t?`Show all series`:`Hide all series`}"
      >
        ${t?`Show all`:`Hide all`}
      </button>
      ${e.series.map((e,t)=>a`
          <button
            class="legend-item ${this.hiddenSeries.has(t)?`hidden`:``}"
            @click=${()=>this.toggleSeries(t)}
            title="${this.hiddenSeries.has(t)?`Show`:`Hide`} ${e.name}"
          >
            <span class="legend-swatch" style="background:${fm[t%fm.length]}"></span>
            ${e.name}
          </button>
        `)}
    `}renderZoomControls(){return a`
      <span class="zoom-hint">Zoom:</span>
      ${pm.map(e=>a`
          <button
            class="zoom-btn ${this.activeZoom===e.label?`active`:``}"
            @click=${()=>this.applyZoom(e)}
          >
            ${e.label}
          </button>
        `)}
    `}render(){let e=this.parsed;return this.error||!e?a`<div class="fallback">Unable to parse time-series data</div>`:a`
      <div class="toolbar">
        <div class="legend-area">${this.renderLegend(e)}</div>
        <div class="zoom-controls">${this.renderZoomControls()}</div>
      </div>
      <div class="chart-wrap">
        <canvas></canvas>
      </div>
    `}},dm.styles=d`
    :host {
      display: flex;
      flex-direction: column;
      flex: 1;
      min-height: 0;
      user-select: none;
    }

    .toolbar {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 4px 2px 2px;
      flex-wrap: wrap;
    }

    .legend-area {
      display: flex;
      align-items: center;
      gap: 4px;
      flex-wrap: wrap;
      flex: 1;
      min-width: 0;
    }

    .legend-item {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      padding: 2px 6px;
      border-radius: var(--radius-xs, 4px);
      cursor: pointer;
      font-size: 11px;
      font-family: var(--font-sans, sans-serif);
      color: var(--text-secondary, #999);
      background: transparent;
      border: 1px solid transparent;
      transition:
        opacity 0.15s,
        background 0.15s;
      user-select: none;
    }

    .legend-item:hover {
      background: var(--bg-hover, rgba(128, 128, 128, 0.1));
    }

    .legend-item.hidden {
      opacity: 0.4;
    }

    .legend-item.hidden .legend-swatch {
      background: var(--text-tertiary, #666) !important;
    }

    .legend-item.toggle-all {
      border-color: var(--border-secondary, rgba(128, 128, 128, 0.15));
      font-size: 10px;
      font-family: var(--font-mono, monospace);
    }

    .legend-swatch {
      width: 10px;
      height: 3px;
      border-radius: 1px;
      flex-shrink: 0;
    }

    .zoom-controls {
      display: flex;
      align-items: center;
      gap: 2px;
      flex-shrink: 0;
    }

    .zoom-btn {
      padding: 2px 7px;
      border-radius: var(--radius-xs, 4px);
      cursor: pointer;
      font-size: 10px;
      font-family: var(--font-mono, monospace);
      color: var(--text-secondary, #999);
      background: transparent;
      border: 1px solid var(--border-secondary, rgba(128, 128, 128, 0.15));
      transition:
        background 0.15s,
        color 0.15s,
        border-color 0.15s;
      user-select: none;
      line-height: 1.5;
    }

    .zoom-btn:hover {
      background: var(--bg-hover, rgba(128, 128, 128, 0.1));
      color: var(--text-primary, #ccc);
    }

    .zoom-btn.active {
      background: var(--accent-primary, #3b82f6);
      color: var(--text-inverse, #fff);
      border-color: var(--accent-primary, #3b82f6);
    }

    .zoom-hint {
      font-size: 10px;
      color: var(--text-tertiary, #666);
      font-family: var(--font-sans, sans-serif);
      padding: 0 4px;
    }

    .chart-wrap {
      position: relative;
      width: 100%;
      flex: 1;
      min-height: 0;
      touch-action: none;
    }

    .fallback {
      padding: 16px;
      color: var(--text-tertiary);
      font-size: var(--font-size-sm);
      font-family: var(--font-mono);
      text-align: center;
    }
  `,dm);N([n({type:String})],mm.prototype,`content`,void 0),N([i()],mm.prototype,`hiddenSeries`,void 0),N([i()],mm.prototype,`activeZoom`,void 0),N([i()],mm.prototype,`error`,void 0),mm=N([s(`chart-card`)],mm);var hm=`highlight-utils-style`;function gm(e){if(e.getElementById(hm))return;let t=document.createElement(`style`);t.id=hm,t.textContent=`
    mark[data-hl] {
      background: var(--accent-warning, #e8a817);
      color: inherit;
      border-radius: 2px;
      padding: 0;
    }
    mark[data-hl].active {
      background: var(--accent-primary, #2563eb);
      color: #fff;
    }
  `,e.appendChild(t)}function _m(e,t){if(vm(e),!t)return 0;let n=t.toLowerCase(),r=document.createTreeWalker(e,NodeFilter.SHOW_TEXT),i=[];for(;r.nextNode();)i.push(r.currentNode);let a=0;for(let e of i){let t=bm(e.nodeValue??``,n);if(t.length<=1)continue;let r=document.createDocumentFragment();for(let e of t)if(e.match){let t=document.createElement(`mark`);t.setAttribute(`data-hl`,``),t.textContent=e.text,r.appendChild(t),a++}else r.appendChild(document.createTextNode(e.text));e.parentNode.replaceChild(r,e)}return a}function vm(e){let t=e.querySelectorAll(`mark[data-hl]`);for(let e of t){let t=e.parentNode,n=document.createTextNode(e.textContent??``);t.replaceChild(n,e),t.normalize()}}function ym(e,t){let n=e.querySelectorAll(`mark[data-hl]`);for(let e=0;e<n.length;e++){let r=n[e];e===t?(r.classList.add(`active`),r.scrollIntoView({block:`nearest`,behavior:`smooth`})):r.classList.remove(`active`)}}function bm(e,t){let n=[],r=e.toLowerCase(),i=0;for(;i<e.length;){let a=r.indexOf(t,i);if(a===-1){n.push({text:e.slice(i),match:!1});break}a>i&&n.push({text:e.slice(i,a),match:!1}),n.push({text:e.slice(a,a+t.length),match:!0}),i=a+t.length}return n}var xm,Sm=(xm=class extends l{constructor(...e){super(...e),this.content=``}render(){return a`<pre class="text">${this.content}</pre>`}},xm.styles=d`
    :host {
      display: block;
      color: var(--text-primary);
    }

    .text {
      font-family: var(--font-mono);
      font-size: var(--font-size-xs);
      line-height: 1.5;
      white-space: pre;
      overflow-x: auto;
      padding: 4px 0;
      margin: 0;
    }
  `,xm);N([n({type:String})],Sm.prototype,`content`,void 0),Sm=N([s(`text-renderer`)],Sm);var Cm,wm,Tm=(Cm=class extends l{constructor(...e){super(...e),this.ticker=new Ve(this),this.cards=[],this.expandedToolStrips=new Set,this.rerunningCards=new Set,this.copiedCards=new Set,this.searchOpen=new Set,this.searchState=new Map,this.minimizedCards=new Set,this.dragId=null,this.resizeCardId=null,this.resizeStartY=0,this.resizeStartHeight=0,this.refreshTimers=new Map,this.onResizeMove=e=>{if(!this.resizeCardId)return;let t=e.clientY-this.resizeStartY,n=Math.max(wm.MIN_CARD_HEIGHT,this.resizeStartHeight+t),r=this.shadowRoot?.querySelector(`.card-body[data-card-id="${this.resizeCardId}"]`);r&&(r.style.height=`${n}px`)},this.onResizeEnd=()=>{if(!this.resizeCardId)return;let e=this.shadowRoot?.querySelector(`.card-body[data-card-id="${this.resizeCardId}"]`),t=e?parseInt(e.style.height,10):this.resizeStartHeight;O.updateCardHeight(this.resizeCardId,t),this.shadowRoot?.querySelectorAll(`.resize-grip.active`).forEach(e=>{e.classList.remove(`active`)}),this.resizeCardId=null,document.removeEventListener(`mousemove`,this.onResizeMove),document.removeEventListener(`mouseup`,this.onResizeEnd)}}connectedCallback(){super.connectedCallback(),this.unsubscribe=O.subscribe(()=>{this.cards=O.state.pinCards,this.reconcileRefreshTimers()}),this.unsubscribeRefresh=Ke.subscribe(()=>{this.restartAllRefreshTimers()}),this.cards=O.state.pinCards,this.reconcileRefreshTimers()}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.(),this.unsubscribeRefresh?.(),this.clearAllRefreshTimers(),document.removeEventListener(`mousemove`,this.onResizeMove),document.removeEventListener(`mouseup`,this.onResizeEnd)}reconcileRefreshTimers(){let e=Ke.intervalSec*1e3,t=new Map(this.cards.filter(e=>e.autoRefresh&&e.toolName).map(t=>[t.id,e]));for(let[e,n]of this.refreshTimers)t.has(e)||(clearInterval(n),this.refreshTimers.delete(e));for(let[n]of t){if(this.refreshTimers.has(n))continue;let t=setInterval(()=>{let e=O.state.pinCards.find(e=>e.id===n);e?.autoRefresh&&e.toolName&&this.rerunTool(e)},e);this.refreshTimers.set(n,t)}}restartAllRefreshTimers(){this.clearAllRefreshTimers(),this.reconcileRefreshTimers()}clearAllRefreshTimers(){for(let e of this.refreshTimers.values())clearInterval(e);this.refreshTimers.clear()}toggleAutoRefresh(e){O.updateCard(e.id,{autoRefresh:!e.autoRefresh})}close(e){O.removeCard(e)}toggleMinimize(e){let t=new Set(this.minimizedCards);t.has(e)?t.delete(e):t.add(e),this.minimizedCards=t}async copyCard(e){try{await navigator.clipboard.writeText(e.content);let t=new Set(this.copiedCards);t.add(e.id),this.copiedCards=t,setTimeout(()=>{let t=new Set(this.copiedCards);t.delete(e.id),this.copiedCards=t},1500)}catch{}}toggleToolStrip(e){let t=new Set(this.expandedToolStrips);t.has(e)?t.delete(e):t.add(e),this.expandedToolStrips=t}async rerunTool(e){if(!e.toolName||this.rerunningCards.has(e.id))return;let t=new Set(this.rerunningCards);t.add(e.id),this.rerunningCards=t;try{O.updateCard(e.id,{loading:!0});let t=await we(e.toolName,e.toolArgs??{});await new Promise(n=>setTimeout(()=>{if(e.type===`graph`)O.updateCard(e.id,{content:t.result,loading:!1,timestamp:Date.now()});else{let n=Yt(e.toolName,e.toolArgs??{}),r=Zt(n,t.result),i=n.canPinGraph?`text`:r.displayType;O.updateCard(e.id,{content:r.content,type:i,loading:!1,timestamp:Date.now()})}n()},0))}catch(t){O.updateCard(e.id,{content:`**Error re-running tool:** ${t.message}`,loading:!1})}finally{let t=new Set(this.rerunningCards);t.delete(e.id),this.rerunningCards=t}}onDragStart(e,t){this.dragId=e,t.dataTransfer.effectAllowed=`move`}onDragOver(e){e.preventDefault(),e.dataTransfer.dropEffect=`move`}onDragEnter(e){e.currentTarget.closest(`.card`)?.classList.add(`drag-over`)}onDragLeave(e){let t=e.currentTarget.closest(`.card`),n=e.relatedTarget;t&&!t.contains(n)&&t.classList.remove(`drag-over`)}onDrop(e,t){if(t.preventDefault(),t.currentTarget.closest(`.card`)?.classList.remove(`drag-over`),!this.dragId||this.dragId===e)return;let n=this.cards.findIndex(t=>t.id===e);n>=0&&O.moveCard(this.dragId,n),this.dragId=null}onDragEnd(){this.dragId=null,this.shadowRoot?.querySelectorAll(`.drag-over`).forEach(e=>{e.classList.remove(`drag-over`)})}onResizeStart(e,t){t.preventDefault(),this.resizeCardId=e,this.resizeStartY=t.clientY,this.resizeStartHeight=this.cards.find(t=>t.id===e)?.height??wm.DEFAULT_CARD_HEIGHT,t.currentTarget.classList.add(`active`),document.addEventListener(`mousemove`,this.onResizeMove),document.addEventListener(`mouseup`,this.onResizeEnd)}getRendererRoot(e){let t=this.shadowRoot?.querySelector(`.card-body[data-card-id="${e}"]`),n=t?.querySelector(`markdown-renderer`);if(n){let e=n.shadowRoot?.querySelector(`.md`);return e&&n.shadowRoot&&gm(n.shadowRoot),e}let r=t?.querySelector(`text-renderer`);if(r){let e=r.shadowRoot?.querySelector(`.text`);return e&&r.shadowRoot&&gm(r.shadowRoot),e}return null}toggleSearch(e){let t=new Set(this.searchOpen);if(t.has(e)){t.delete(e);let n=this.getRendererRoot(e);n&&vm(n);let r=new Map(this.searchState);r.delete(e),this.searchState=r}else t.add(e);this.searchOpen=t}onSearchInput(e,t){let n=t.detail??``,r=this.getRendererRoot(e);if(!r)return;let i=_m(r,n),a=i>0?0:-1;i>0&&ym(r,0);let o=new Map(this.searchState);o.set(e,{query:n,count:i,index:a}),this.searchState=o}onSearchNav(e,t){let n=this.searchState.get(e);if(!n||n.count===0)return;let r=(n.index+t+n.count)%n.count,i=this.getRendererRoot(e);i&&ym(i,r);let a=new Map(this.searchState);a.set(e,{...n,index:r}),this.searchState=a}toolSummary(e){if(!e.toolArgs||Object.keys(e.toolArgs).length===0)return``;let t=e.toolArgs.command;if(typeof t==`string`)return t;let n=Object.values(e.toolArgs).map(e=>typeof e==`string`?e:JSON.stringify(e)).join(`, `);return n.length>60?n.slice(0,57)+`...`:n}renderToolStrip(e){if(!e.toolName)return r;let t=this.expandedToolStrips.has(e.id),n=this.toolSummary(e),i=JSON.stringify(e.toolArgs??{},null,2);return a`
      <div class="tool-strip">
        <div class="tool-strip-header" @click=${()=>this.toggleToolStrip(e.id)}>
          <svg
            class="tool-chevron ${t?`open`:``}"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <polyline points="9 18 15 12 9 6" />
          </svg>
          <svg
            class="tool-icon"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <path
              d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"
            />
          </svg>
          <span class="tool-name">${e.toolName}</span>
          ${n?a`<span class="tool-summary">${n}</span>`:r}
        </div>
        ${t?a`
              <div class="tool-detail">
                <div class="tool-detail-label">Arguments</div>
                <div class="tool-code">${i}</div>
              </div>
            `:r}
      </div>
    `}renderRerunButton(e){return e.toolName?a`
      <button
        class="header-btn rerun ${this.rerunningCards.has(e.id)?`rerunning`:``}"
        title="Re-run tool call"
        @click=${t=>{t.stopPropagation(),this.rerunTool(e)}}
      >
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        >
          <polyline points="23 4 23 10 17 10" />
          <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10" />
        </svg>
      </button>
    `:r}renderAutoRefreshButton(e){if(!e.toolName)return r;let t=e.autoRefresh===!0;return a`
      <button
        class="header-btn auto-refresh ${t?`active`:``}"
        title=${t?`Stop auto-refresh`:`Start auto-refresh`}
        aria-label=${t?`Stop auto-refresh`:`Start auto-refresh`}
        aria-pressed=${t?`true`:`false`}
        @click=${t=>{t.stopPropagation(),this.toggleAutoRefresh(e)}}
      >
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        >
          <circle cx="12" cy="12" r="10" />
          <polyline points="12 6 12 12 16 14" />
        </svg>
      </button>
    `}renderSearchBar(e){if(!this.searchOpen.has(e.id))return r;let t=this.searchState.get(e.id);return a`
      <card-search-bar
        .matchCount=${t?.count??0}
        .activeIndex=${t?.index??-1}
        @search-input=${t=>this.onSearchInput(e.id,t)}
        @search-prev=${()=>this.onSearchNav(e.id,-1)}
        @search-next=${()=>this.onSearchNav(e.id,1)}
        @search-close=${()=>this.toggleSearch(e.id)}
      ></card-search-bar>
    `}renderMinimizeButton(e){let t=this.minimizedCards.has(e.id);return a`
      <button
        class="header-btn minimize"
        title=${t?`Expand card`:`Minimize card`}
        aria-label=${t?`Expand card`:`Minimize card`}
        aria-expanded=${t?`false`:`true`}
        @click=${()=>this.toggleMinimize(e.id)}
      >
        ${t?a`<svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
            >
              <polyline points="18 15 12 9 6 15" />
            </svg>`:a`<svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
            >
              <line x1="5" y1="12" x2="19" y2="12" />
            </svg>`}
      </button>
    `}renderCard(e){let t=this.minimizedCards.has(e.id);return a`
      <div
        class="card"
        @dragover=${this.onDragOver}
        @dragenter=${this.onDragEnter}
        @dragleave=${this.onDragLeave}
        @drop=${t=>this.onDrop(e.id,t)}
      >
        <div
          class="card-header"
          draggable="true"
          @dragstart=${t=>this.onDragStart(e.id,t)}
          @dragend=${this.onDragEnd}
        >
          <button
            class="header-btn copy ${this.copiedCards.has(e.id)?`copied`:``}"
            title=${this.copiedCards.has(e.id)?`Copied!`:`Copy content`}
            @click=${t=>{t.stopPropagation(),this.copyCard(e)}}
          >
            ${this.copiedCards.has(e.id)?a`<svg
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  stroke-width="2"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                >
                  <polyline points="20 6 9 17 4 12" />
                </svg>`:a`<svg
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  stroke-width="2"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                >
                  <rect x="9" y="9" width="13" height="13" rx="2" ry="2" />
                  <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
                </svg>`}
          </button>
          <span class="card-title" title=${e.title}>${e.title}</span>
          <span class="timestamp" title=${new Date(e.timestamp).toLocaleString()}
            >${Fe(e.timestamp)}</span
          >
          ${t?r:a`<button
                class="header-btn search"
                title="Search"
                @click=${()=>this.toggleSearch(e.id)}
              >
                <svg
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  stroke-width="2"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                >
                  <circle cx="11" cy="11" r="8" />
                  <line x1="21" y1="21" x2="16.65" y2="16.65" />
                </svg>
              </button>`}
          ${t?r:this.renderRerunButton(e)}
          ${t?r:this.renderAutoRefreshButton(e)}
          ${this.renderMinimizeButton(e)}
          <button class="header-btn close" title="Close" @click=${()=>this.close(e.id)}>
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
            >
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>
        ${t?r:a`
              ${this.renderSearchBar(e)} ${this.renderToolStrip(e)}
              <div
                class="card-body ${e.type===`graph`?`no-scroll`:``}"
                data-card-id=${e.id}
                style="height: ${e.height??wm.DEFAULT_CARD_HEIGHT}px"
              >
                ${e.loading?a`<div class="card-loading">
                      <span class="card-loading-dot"></span>
                      <span class="card-loading-dot"></span>
                      <span class="card-loading-dot"></span>
                      <span>Preparing&hellip;</span>
                    </div>`:e.type===`graph`?a`<chart-card .content=${e.content}></chart-card>`:e.type===`text`?a`<text-renderer .content=${e.content}></text-renderer>`:a`<markdown-renderer .content=${e.content}></markdown-renderer>`}
              </div>
              <div
                class="resize-grip"
                @mousedown=${t=>this.onResizeStart(e.id,t)}
              ></div>
            `}
      </div>
    `}render(){return this.cards.length===0?a`<div class="placeholder">Pinned results will appear here</div>`:a` <div class="cards">${this.cards.map(e=>this.renderCard(e))}</div> `}},wm=Cm,Cm.styles=d`
    :host {
      display: flex;
      flex-direction: column;
      height: 100%;
      overflow: hidden;
      background: var(--bg-secondary);
      box-sizing: border-box;
    }

    .cards {
      flex: 1;
      overflow-y: auto;
      padding: 12px;
      display: flex;
      flex-direction: column;
      gap: 12px;
    }

    .card {
      border: 1px solid var(--border-secondary);
      border-radius: var(--radius-sm);
      background: var(--bg-primary);
      overflow: hidden;
    }

    .card.drag-over {
      border-color: var(--accent-primary);
      box-shadow: 0 0 0 1px var(--accent-primary);
    }

    .card-header {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 8px 12px;
      background: var(--bg-tertiary);
      cursor: grab;
      user-select: none;
    }

    .card-header:active {
      cursor: grabbing;
    }

    .card-title {
      flex: 1;
      font-size: var(--font-size-sm);
      font-weight: var(--font-weight-medium);
      color: var(--text-primary);
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .timestamp {
      font-size: var(--font-size-xs);
      color: var(--text-tertiary);
      white-space: nowrap;
      flex-shrink: 0;
      font-variant-numeric: tabular-nums;
    }

    .header-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 22px;
      height: 22px;
      padding: 0;
      border: none;
      border-radius: var(--radius-xs);
      background: transparent;
      color: var(--text-tertiary);
      cursor: pointer;
      flex-shrink: 0;
      transition: all var(--transition-fast);
    }

    .header-btn:hover {
      background: var(--bg-hover);
      color: var(--accent-primary);
    }

    .header-btn.search {
      color: var(--text-tertiary);
    }

    .header-btn.minimize:hover {
      color: var(--accent-warning);
    }

    .header-btn.close:hover {
      color: var(--accent-danger);
    }

    .header-btn.rerun:hover {
      color: var(--accent-success);
    }

    .header-btn.rerunning {
      color: var(--accent-info);
      animation: spin 1s linear infinite;
    }

    .header-btn.auto-refresh {
      color: var(--text-tertiary);
    }

    .header-btn.auto-refresh:hover {
      color: var(--accent-info);
    }

    .header-btn.auto-refresh.active {
      color: var(--accent-info);
      animation: pulse 2s ease-in-out infinite;
    }

    @keyframes pulse {
      0%,
      100% {
        opacity: 1;
      }
      50% {
        opacity: 0.5;
      }
    }

    .header-btn.copy.copied {
      color: var(--accent-success);
    }

    @keyframes spin {
      from {
        transform: rotate(0deg);
      }
      to {
        transform: rotate(360deg);
      }
    }

    .header-btn svg {
      width: 14px;
      height: 14px;
    }

    /* --- tool-call info strip ------------------------------------------- */

    .tool-strip {
      border-top: 1px solid var(--border-secondary);
      background: var(--bg-tool-header, var(--bg-tertiary));
      font-size: var(--font-size-xs);
      overflow: hidden;
    }

    .tool-strip-header {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 4px 12px;
      cursor: pointer;
      user-select: none;
      transition: background var(--transition-fast);
    }

    .tool-strip-header:hover {
      background: var(--bg-hover);
    }

    .tool-chevron {
      width: 12px;
      height: 12px;
      color: var(--text-tertiary);
      transition: transform var(--transition-fast);
      flex-shrink: 0;
    }

    .tool-chevron.open {
      transform: rotate(90deg);
    }

    .tool-icon {
      width: 12px;
      height: 12px;
      color: var(--accent-warning);
      flex-shrink: 0;
    }

    .tool-name {
      font-family: var(--font-mono);
      color: var(--text-secondary);
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .tool-summary {
      color: var(--text-tertiary);
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      flex: 1;
    }

    .tool-detail {
      padding: 6px 12px;
      border-top: 1px solid var(--border-secondary);
    }

    .tool-detail-label {
      font-size: var(--font-size-xs);
      font-weight: var(--font-weight-bold);
      color: var(--text-tertiary);
      text-transform: uppercase;
      letter-spacing: 0.04em;
      margin-bottom: 2px;
    }

    .tool-code {
      font-family: var(--font-mono);
      font-size: var(--font-size-xs);
      padding: 6px 8px;
      background: var(--bg-code);
      border-radius: var(--radius-xs);
      white-space: pre-wrap;
      word-break: break-all;
      overflow-x: auto;
      max-height: 200px;
      overflow-y: auto;
      color: var(--text-primary);
      line-height: 1.4;
    }

    /* --- card body ------------------------------------------------------- */

    .card-body {
      padding: 10px 12px;
      overflow: auto;
      user-select: text;
      cursor: auto;
    }

    .card-body.no-scroll {
      overflow: hidden;
      display: flex;
      flex-direction: column;
      box-sizing: border-box;
    }

    .resize-grip {
      height: 6px;
      cursor: ns-resize;
      background: var(--bg-tertiary);
      display: flex;
      align-items: center;
      justify-content: center;
      user-select: none;
      flex-shrink: 0;
      transition: background var(--transition-fast);
    }

    .resize-grip:hover,
    .resize-grip.active {
      background: var(--accent-primary);
    }

    .resize-grip::after {
      content: "";
      display: block;
      width: 32px;
      height: 2px;
      border-radius: 1px;
      background: var(--text-tertiary);
      opacity: 0.5;
    }

    .resize-grip:hover::after,
    .resize-grip.active::after {
      background: var(--bg-primary);
      opacity: 0.8;
    }

    .placeholder {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
      color: var(--text-tertiary);
      font-size: var(--font-size-sm);
      font-family: var(--font-sans);
      padding: 16px;
      text-align: center;
      user-select: none;
    }

    .card-loading {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      padding: 24px 12px;
      color: var(--text-tertiary);
      font-size: var(--font-size-sm);
      font-family: var(--font-sans);
    }

    .card-loading-dot {
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: var(--text-tertiary);
      animation: loadPulse 1.2s ease-in-out infinite;
    }

    .card-loading-dot:nth-child(2) {
      animation-delay: 0.15s;
    }

    .card-loading-dot:nth-child(3) {
      animation-delay: 0.3s;
    }

    @keyframes loadPulse {
      0%,
      80%,
      100% {
        opacity: 0.25;
        transform: scale(0.8);
      }
      40% {
        opacity: 1;
        transform: scale(1);
      }
    }
  `,Cm.DEFAULT_CARD_HEIGHT=400,Cm.MIN_CARD_HEIGHT=80,Cm);N([i()],Tm.prototype,`cards`,void 0),N([i()],Tm.prototype,`expandedToolStrips`,void 0),N([i()],Tm.prototype,`rerunningCards`,void 0),N([i()],Tm.prototype,`copiedCards`,void 0),N([i()],Tm.prototype,`searchOpen`,void 0),N([i()],Tm.prototype,`searchState`,void 0),N([i()],Tm.prototype,`minimizedCards`,void 0),Tm=wm=N([s(`detail-pane`)],Tm);