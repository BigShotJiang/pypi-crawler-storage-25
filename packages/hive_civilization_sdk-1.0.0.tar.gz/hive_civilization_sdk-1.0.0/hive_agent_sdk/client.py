"""
Hive Civilization SDK — Python client
Wraps the Hive Civilization public REST APIs.
"""
from __future__ import annotations

import httpx

ENDPOINTS = {
    "gate": "https://hivegate.onrender.com",
    "trust": "https://hivetrust.onrender.com",
    "law": "https://hivelaw.onrender.com",
    "bank": "https://hivebank.onrender.com",
}

_timeout = httpx.Timeout(30.0)


def _post(url: str, body: dict) -> dict:
    with httpx.Client(timeout=_timeout) as client:
        r = client.post(url, json=body)
        r.raise_for_status()
        return r.json()


def _get(url: str) -> dict:
    with httpx.Client(timeout=_timeout) as client:
        r = client.get(url)
        r.raise_for_status()
        return r.json()


class HiveTrustClient:
    """W3C DID Core + VCDM 2.0 identity layer."""

    def generate(self, *, agent_name: str, agent_type: str = "custom") -> dict:
        """Generate a sovereign DID (did:key, Ed25519)."""
        return _post(f"{ENDPOINTS['trust']}/v1/trust/did/generate",
                     {"agentName": agent_name, "agentType": agent_type})

    def issue_vc(self, *, subject_did: str, credential_type: str = "AgentIdentityCredential") -> dict:
        """Issue a VCDM 2.0 verifiable credential, Cheqd-anchored."""
        return _post(f"{ENDPOINTS['trust']}/v1/trust/vc/issue",
                     {"subjectDid": subject_did, "credentialType": credential_type})

    def score(self, did: str) -> dict:
        """Get 5-pillar KYA trust score (0–1000)."""
        return _get(f"{ENDPOINTS['trust']}/v1/trust/score/{did}")

    def stake(self, *, did: str, amount_usdc: float) -> dict:
        """Stake USDC to back agent reputation (HiveBond)."""
        return _post(f"{ENDPOINTS['trust']}/v1/trust/bond/stake",
                     {"did": did, "amountUsdc": amount_usdc})

    def reputation_proof(self, did: str) -> dict:
        """Generate cryptographic reputation proof (ZK-ready)."""
        return _post(f"{ENDPOINTS['trust']}/v1/trust/reputation/proof", {"did": did})


class HiveLawClient:
    """HAHS 1.0.0 legal contracts + HAGF governance."""

    def schema(self) -> dict:
        """Get the HAHS 1.0.0 JSON schema."""
        return _get(f"{ENDPOINTS['law']}/v1/law/hahs/schema")

    def create_hahs(self, *, hirer_did: str, agent_did: str, scope_of_work: str,
                    max_spend_usdc: float = 50.0, jurisdiction: str = "US-DE") -> dict:
        """Create an HAHS 1.0.0 agent employment contract."""
        return _post(f"{ENDPOINTS['law']}/v1/law/hahs/create", {
            "hirerDid": hirer_did,
            "agentDid": agent_did,
            "scopeOfWork": scope_of_work,
            "maxSpendUsdc": max_spend_usdc,
            "jurisdiction": jurisdiction,
        })

    def file_dispute(self, *, claimant_did: str, respondent_did: str,
                     claim_type: str, amount_usdc: float) -> dict:
        """File a dispute (autonomous arbitration, p95 < 5s)."""
        return _post(f"{ENDPOINTS['law']}/v1/law/dispute/file", {
            "claimantDid": claimant_did,
            "respondentDid": respondent_did,
            "claimType": claim_type,
            "amountUsdc": amount_usdc,
        })

    def apply_for_seal(self, *, did: str) -> dict:
        """Apply for the Hive compliance seal."""
        return _post(f"{ENDPOINTS['law']}/v1/law/seal/apply", {"did": did})

    def governance(self) -> dict:
        """Get the full HAGF governance framework."""
        return _get(f"{ENDPOINTS['law']}/v1/law/governance")


class HiveBankClient:
    """USDC vaults, streaming payments, credit, and Agent Transaction Graph."""

    def create_vault(self, *, did: str) -> dict:
        return _post(f"{ENDPOINTS['bank']}/v1/bank/vault/create", {"did": did})

    def deposit(self, *, did: str, amount_usdc: float) -> dict:
        return _post(f"{ENDPOINTS['bank']}/v1/bank/vault/deposit",
                     {"did": did, "amountUsdc": amount_usdc})

    def create_stream(self, *, from_did: str, to_did: str,
                      rate_usdc: float, duration_seconds: int) -> dict:
        """Start a per-second USDC streaming payment."""
        return _post(f"{ENDPOINTS['bank']}/v1/bank/stream/create", {
            "fromDid": from_did,
            "toDid": to_did,
            "rateUsdc": rate_usdc,
            "durationSeconds": duration_seconds,
        })

    def apply_credit_line(self, *, did: str) -> dict:
        """Apply for trust-score-gated credit underwriting."""
        return _post(f"{ENDPOINTS['bank']}/v1/bank/credit/apply", {"did": did})

    def graph_record(self, event: dict) -> dict:
        """Record a commerce event to the Agent Transaction Graph."""
        return _post(f"{ENDPOINTS['bank']}/v1/bank/graph/record", event)

    def agent_history(self, did: str) -> dict:
        """Get agent commerce history from the transaction graph."""
        return _get(f"{ENDPOINTS['bank']}/v1/bank/graph/agent/{did}")

    def network_stats(self) -> dict:
        """Get network-wide transaction graph statistics."""
        return _get(f"{ENDPOINTS['bank']}/v1/bank/graph/network")

    def insights(self, did: str) -> dict:
        """Get AI-generated insights for an agent."""
        return _get(f"{ENDPOINTS['bank']}/v1/bank/graph/insights/{did}")


class HiveGateClient:
    """Onboarding, routing, trust bridging, and framework translation."""

    def onboard(self, *, agent_name: str, framework: str = "custom",
                operator_email: str = "") -> dict:
        """Full onboarding: DID + API key + vault in one call."""
        return _post(f"{ENDPOINTS['gate']}/v1/gate/onboard", {
            "agentName": agent_name,
            "framework": framework,
            "operatorEmail": operator_email,
        })

    def bridge_trust(self, *, source_did: str, target_ecosystem: str) -> dict:
        return _post(f"{ENDPOINTS['gate']}/v1/gate/bridge",
                     {"sourceDid": source_did, "targetEcosystem": target_ecosystem})

    def translate_intent(self, *, intent: str, target_framework: str) -> dict:
        return _post(f"{ENDPOINTS['gate']}/v1/gate/translate",
                     {"intent": intent, "targetFramework": target_framework})

    def health(self) -> dict:
        return _get(f"{ENDPOINTS['gate']}/health")


class HiveAgent:
    """
    Main entry point for the Hive Civilization SDK.

    Quick start:
        agent = HiveAgent(name="my-agent", agent_type="research")
        result = agent.register()
        print(result["did"])
    """

    def __init__(self, *, name: str, agent_type: str = "custom",
                 api_key: str = "", network: str = "base", tier: str = "citizen"):
        self.name = name
        self.agent_type = agent_type
        self.api_key = api_key
        self.network = network
        self.tier = tier
        self._did: str | None = None
        self._vc: dict | None = None

        # Service clients
        self.trust = HiveTrustClient()
        self.law = HiveLawClient()
        self.bank = HiveBankClient()
        self.gate = HiveGateClient()

    def register(self) -> dict:
        """One-call: generate DID + issue VC."""
        result = self.trust.generate(agent_name=self.name, agent_type=self.agent_type)
        if "did" in result:
            self._did = result["did"]
            try:
                self._vc = self.trust.issue_vc(subject_did=self._did)
            except Exception:
                pass
        return result

    def issue_credential(self) -> dict:
        """Issue a VCDM 2.0 verifiable credential for this agent."""
        if not self._did:
            raise RuntimeError("Call register() first to generate a DID.")
        return self.trust.issue_vc(subject_did=self._did)

    def open_vault(self) -> dict:
        """Open a USDC vault on Base L2."""
        if not self._did:
            raise RuntimeError("Call register() first to generate a DID.")
        return self.bank.create_vault(did=self._did)

    @classmethod
    def onboard(cls, *, agent_name: str, framework: str = "custom",
                operator_email: str = "") -> dict:
        """Static convenience: full onboarding in one call."""
        return _post(f"{ENDPOINTS['gate']}/v1/gate/onboard", {
            "agentName": agent_name,
            "framework": framework,
            "operatorEmail": operator_email,
        })

    def __repr__(self) -> str:
        did_str = self._did or "not registered"
        return f"HiveAgent(name={self.name!r}, did={did_str!r})"
