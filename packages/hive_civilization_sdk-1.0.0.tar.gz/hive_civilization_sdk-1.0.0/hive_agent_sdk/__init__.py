"""
hive-agent-sdk — Hive Civilization AI Agent Infrastructure
https://thehiveryiq.com

Give your AI agent a sovereign W3C DID, VCDM 2.0 verifiable credentials,
HAHS 1.0.0 legal contracts, and USDC settlement rails on Base L2.

Quick start:
    from hive_agent_sdk import HiveAgent

    agent = HiveAgent(name="my-agent", agent_type="research")
    result = agent.register()
    print(result["did"])  # did:key:z6Mk...
"""

from .client import HiveAgent, HiveTrustClient, HiveLawClient, HiveBankClient, HiveGateClient

__version__ = "1.0.0"
__all__ = [
    "HiveAgent",
    "HiveTrustClient",
    "HiveLawClient",
    "HiveBankClient",
    "HiveGateClient",
]
