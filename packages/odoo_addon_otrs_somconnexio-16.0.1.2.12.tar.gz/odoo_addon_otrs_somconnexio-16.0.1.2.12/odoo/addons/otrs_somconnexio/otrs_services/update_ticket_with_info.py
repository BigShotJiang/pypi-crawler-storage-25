from otrs_somconnexio.services.update_ticket_with_provider_info import (
    UpdateTicketWithProviderInfo,
)
from otrs_somconnexio.otrs_models.abstract_article import AbstractArticle


class UpdateTicketWithInfo(UpdateTicketWithProviderInfo):
    """
    Update the ticket process with an article to inform about the result.

    Params:
    ticket_id (str) -> id from the involved OTRS ticket to which an article will be send
    info (dict) -> dictionary with the information description
    df_dct (dict) -> dictionary with the Dynamic Fields to be updated and their values
    """

    def __init__(self, ticket_id, info, df_dct=None):
        self.ticket_id = ticket_id
        self.article = AbstractArticle()
        self.article.subject = info.get("title", "Odoo Info")
        self.article.body = info.get("body", "Odoo Info")
        self.df_dct = df_dct or {}
