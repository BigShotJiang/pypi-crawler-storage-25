from otrs_somconnexio.otrs_models.switchboard_header_data import SwitchboardHeaderData
from .base_data import BaseDataFromOdoo
from odoo.tools import html2plaintext


class SBHeaderDataFromCRMLead(BaseDataFromOdoo):
    DataModel = SwitchboardHeaderData

    def __init__(self, crm_lead):
        self.crm_lead = crm_lead

    def _get_data(self):
        return {
            "contact_phone": self.crm_lead.phone,
            "notes": html2plaintext(self.crm_lead.description),
            "email": self.crm_lead.email_from,
            "sales_team": self.crm_lead.team_id.code,
            "order_id": self.crm_lead.id,
            "lead_line_data": self._get_lead_line_data(self.crm_lead.lead_line_ids),
            "agent_data": self._get_agent_data(self.crm_lead.lead_line_ids),
            "technology": "Switchboard",
        }

    def _get_lead_line_data(self, lead_lines):
        """Generate a dictionary representation of the lead lines."""

        # order sb_lines according to their product
        sb_lines = lead_lines.filtered(lambda line: line.is_switchboard).sorted(
            key=lambda line: line.product_id.id
        )
        switchboard_infos = sb_lines.mapped("switchboard_isp_info")

        product_name_mapping = {
            "SE_SC_REC_CV_APP_0": "BASIC",
            "SE_SC_REC_CV_APP_500": "AVANÇ",
            "SE_SC_REC_CV_APP_UNL": "EXPER",
            "SE_SC_REC_CV_FIX": "TFIXE",
        }

        return {
            "Núm.": [i for i in range(1, len(sb_lines) + 1)],
            "Ext": switchboard_infos.mapped("extension"),
            "Prod": [
                product_name_mapping.get(p.default_code, p.showed_name)
                for sb_line in sb_lines
                for p in sb_line.product_id
            ],
            "Nom": switchboard_infos.mapped("agent_name"),
            "Telf": [
                info.phone_number or info.mobile_phone_number
                for info in switchboard_infos
            ],
            "Tipus": [s.switchboard_isp_info_type for s in sb_lines],
        }

    def _get_agent_data(self, lead_lines):
        """Generate a string representation of the agent data."""
        sb_lines = lead_lines.filtered(
            lambda line: line.is_switchboard and line.has_agent
        )
        return [
            {
                "product": line.product_id.showed_name,
                "extension": line.switchboard_isp_info.extension,
                "agent_name": line.switchboard_isp_info.agent_name,
                "agent_email": line.switchboard_isp_info.agent_email,
            }
            for line in sb_lines
        ]
