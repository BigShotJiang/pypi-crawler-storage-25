from mock import patch

from otrs_somconnexio.otrs_models.abstract_article import AbstractArticle
from odoo.addons.somconnexio.tests.sc_test_case import SCTestCase
from ...otrs_services.update_ticket_with_info import UpdateTicketWithInfo


@patch(
    "otrs_somconnexio.services.update_ticket_with_provider_info.UpdateTicketWithProviderInfo.run"  # noqa
)
class UpdateTicketWithInfoTest(SCTestCase):
    def setUp(self, *args, **kwargs):
        super().setUp(*args, **kwargs)
        self.error = {
            "title": "Unexpected error ocurred with this ticket",
            "body": "test body",
        }
        self.ticket_id = "123424"

    def test_custom_error_wth_df(self, mock_run):
        df_dct = {"df_key": "df_value", "df_second_key": "df_second_value"}

        update_ticket_with_info = UpdateTicketWithInfo(
            self.ticket_id, self.error, df_dct
        )

        self.assertEqual(update_ticket_with_info.ticket_id, self.ticket_id)
        self.assertEqual(update_ticket_with_info.df_dct, df_dct)
        self.assertIsInstance(update_ticket_with_info.article, AbstractArticle)
        self.assertEqual(update_ticket_with_info.article.subject, self.error["title"])
        self.assertEqual(update_ticket_with_info.article.body, self.error["body"])

        update_ticket_with_info.run()

        mock_run.assert_called_once_with()

    def test_custom_error_wo_df(self, mock_run):
        update_ticket_with_info = UpdateTicketWithInfo(self.ticket_id, self.error)

        self.assertFalse(update_ticket_with_info.df_dct)

        update_ticket_with_info.run()

        mock_run.assert_called_once_with()
