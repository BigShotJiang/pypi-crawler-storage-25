from odoo.addons.somconnexio.tests.sc_test_case import SCTestCase
from odoo.addons.switchboard_somconnexio.tests.helper_service import crm_lead_create
from ...otrs_factories.sb_header_data_from_crm_lead import SBHeaderDataFromCRMLead
from odoo.tools import html2plaintext


class SBHeaderDataFromCRMLeadTest(SCTestCase):
    def setUp(self, *args, **kwargs):
        super().setUp(*args, **kwargs)
        self.partner_id = self.browse_ref("somconnexio.res_partner_2_demo")
        self.sb_crm_lead = crm_lead_create(self.env, self.partner_id, "switchboard")

    def test_build(self):
        description = "<p>Header activation notes to consider</p>"
        self.sb_crm_lead.description = description
        lead_data = SBHeaderDataFromCRMLead(self.sb_crm_lead).build()

        self.assertEqual(lead_data.order_id, self.sb_crm_lead.id)
        self.assertEqual(lead_data.sales_team, self.sb_crm_lead.team_id.name)
        self.assertEqual(lead_data.service_type, "header_switchboard")
        self.assertEqual(lead_data.contact_phone, self.sb_crm_lead.phone)
        self.assertEqual(lead_data.email, self.sb_crm_lead.email_from)
        self.assertEqual(lead_data.notes, html2plaintext(description))

    def test_lead_line_data(self):
        """Test that the lead line data is correctly extracted as a dictionary."""

        lead_data = SBHeaderDataFromCRMLead(self.sb_crm_lead).build()
        sb_line = self.sb_crm_lead.lead_line_ids[0]
        lead_line_data = lead_data.lead_line_data
        self.assertEqual(len(self.sb_crm_lead.lead_line_ids), 1)
        self.assertTrue(all(len(v) == 1 for v in lead_line_data.values()))
        self.assertEqual(lead_line_data["Núm."][0], len(self.sb_crm_lead.lead_line_ids))
        self.assertEqual(
            lead_line_data["Ext"][0], sb_line.switchboard_isp_info.extension
        )
        self.assertEqual(
            lead_line_data["Nom"][0], sb_line.switchboard_isp_info.agent_name
        )
        self.assertEqual(
            lead_line_data["Telf"][0],
            sb_line.switchboard_isp_info.phone_number,
        )
        self.assertEqual(
            lead_line_data["Tipus"][0],
            sb_line.switchboard_isp_info.type,
        )

        another_lead = crm_lead_create(self.env, self.partner_id, "switchboard")
        another_sb_line = another_lead.lead_line_ids[0]
        self.sb_crm_lead.write(
            {"lead_line_ids": [(4, another_lead.lead_line_ids[0].id, None)]}
        )

        # Add second line with different data
        lead_data = SBHeaderDataFromCRMLead(self.sb_crm_lead).build()
        lead_line_data = lead_data.lead_line_data
        self.assertEqual(len(self.sb_crm_lead.lead_line_ids), 2)
        self.assertTrue(all(len(v) == 2 for v in lead_line_data.values()))
        self.assertEqual(lead_line_data["Núm."][1], len(self.sb_crm_lead.lead_line_ids))
        self.assertEqual(
            lead_line_data["Ext"][1],
            another_sb_line.switchboard_isp_info.extension,
        )
        self.assertEqual(
            lead_line_data["Nom"][1],
            another_sb_line.switchboard_isp_info.agent_name,
        )
        self.assertEqual(
            lead_line_data["Telf"][1],
            another_sb_line.switchboard_isp_info.mobile_phone_number,
        )
        self.assertEqual(
            lead_line_data["Tipus"][1],
            another_sb_line.switchboard_isp_info.type,
        )

    def test_product_name_mapping_in_lead_line_data(self):
        """Test that the product names are correctly mapped in the lead line data."""
        sb_expert = self.env.ref("switchboard_somconnexio.AgentCentraletaVirtualAppUNL")
        sb_advanced = self.env.ref(
            "switchboard_somconnexio.AgentCentraletaVirtualApp500"
        )
        sb_basic = self.env.ref("switchboard_somconnexio.AgentCentraletaVirtualBasic")
        sb_landline = self.env.ref("switchboard_somconnexio.FixCentraletaVirtual")

        self.sb_crm_lead.lead_line_ids.product_id = sb_expert

        lead_data = SBHeaderDataFromCRMLead(self.sb_crm_lead).build()
        self.assertEqual(
            lead_data.lead_line_data["Prod"][0],
            "EXPER",
        )

        self.sb_crm_lead.lead_line_ids.product_id = sb_advanced
        lead_data = SBHeaderDataFromCRMLead(self.sb_crm_lead).build()
        self.assertEqual(
            lead_data.lead_line_data["Prod"][0],
            "AVANÇ",
        )

        self.sb_crm_lead.lead_line_ids.product_id = sb_basic
        lead_data = SBHeaderDataFromCRMLead(self.sb_crm_lead).build()
        self.assertEqual(
            lead_data.lead_line_data["Prod"][0],
            "BASIC",
        )

        self.sb_crm_lead.lead_line_ids.product_id = sb_landline
        lead_data = SBHeaderDataFromCRMLead(self.sb_crm_lead).build()
        self.assertEqual(
            lead_data.lead_line_data["Prod"][0],
            "TFIXE",
        )

    def test_get_agent_data(self):
        """Test that the agent data is correctly extracted as a string."""
        sb_product_1 = self.env.ref(
            "switchboard_somconnexio.AgentCentraletaVirtualBasic"
        )
        sb_product_2 = self.env.ref(
            "switchboard_somconnexio.AgentCentraletaVirtualAppUNL"
        )
        self.sb_crm_lead.lead_line_ids = False
        agent_data_list = [
            {
                "agent_name": "Josep Lopes",
                "agent_email": "josep.lopes@ccma.cat",
                "extension": "1001",
            },
            {
                "agent_name": "David Güell",
                "agent_email": "david.guell@ccma.cat",
                "extension": "1002",
            },
            {
                "agent_name": "Emma Cruscat",
                "agent_email": "emma.cruscat@ccma.cat",
                "extension": "1003",
            },
            {
                "agent_name": "Conxita Carbonell",
                "agent_email": "conxita.carbonell@ccma.cat",
                "extension": "1004",
            },
        ]
        sb_infos = self.env["switchboard.isp.info"].create(agent_data_list)

        self.env["crm.lead.line"].create(
            [
                {
                    "name": sb_product_1.showed_name,
                    "lead_id": self.sb_crm_lead.id,
                    "product_id": sb_product_1.id,
                    "switchboard_isp_info": sb_infos[0].id,
                },
                {
                    "name": sb_product_2.showed_name,
                    "lead_id": self.sb_crm_lead.id,
                    "product_id": sb_product_2.id,
                    "switchboard_isp_info": sb_infos[1].id,
                },
                {
                    "name": sb_product_1.showed_name,
                    "lead_id": self.sb_crm_lead.id,
                    "product_id": sb_product_1.id,
                    "switchboard_isp_info": sb_infos[2].id,
                },
                {
                    "name": sb_product_2.showed_name,
                    "lead_id": self.sb_crm_lead.id,
                    "product_id": sb_product_2.id,
                    "switchboard_isp_info": sb_infos[3].id,
                },
            ]
        )
        lead_data = SBHeaderDataFromCRMLead(self.sb_crm_lead).build()
        expected_agent_data = agent_data_list
        expected_agent_data[0]["product"] = sb_product_1.showed_name
        expected_agent_data[1]["product"] = sb_product_2.showed_name
        expected_agent_data[2]["product"] = sb_product_1.showed_name
        expected_agent_data[3]["product"] = sb_product_2.showed_name
        self.assertEqual(lead_data.agent_data, expected_agent_data)
