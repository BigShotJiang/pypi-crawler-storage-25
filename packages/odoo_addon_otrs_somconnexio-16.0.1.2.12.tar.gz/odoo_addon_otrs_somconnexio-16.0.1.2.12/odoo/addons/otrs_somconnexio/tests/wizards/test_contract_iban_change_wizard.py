from mock import patch

from odoo.exceptions import UserError, ValidationError
from odoo.addons.somconnexio.tests.sc_test_case import SCTestCase


class TestContractIBANChangeWizard(SCTestCase):
    def setUp(self, *args, **kwargs):
        super().setUp(*args, **kwargs)
        self.partner = self.browse_ref("somconnexio.res_partner_1_demo")
        self.partner_mandate = self.browse_ref(
            "somconnexio.demo_mandate_partner_1_demo"
        )
        self.ticket_id = "1234"
        self.user_admin = self.browse_ref("base.user_admin")
        self.contract = self.browse_ref("somconnexio.contract_mobile_il_20")
        self.wizard = (
            self.env["contract.iban.change.wizard"]
            .with_context(active_id=self.partner.id)
            .sudo()
            .create(
                {
                    "contract_ids": [(6, 0, [self.contract.id])],
                    "account_banking_mandate_id": self.partner_mandate.id,
                }
            )
        )
        self.params = {
            "ticket_id": self.ticket_id,
            "iban": "ESXXXXX",
            "contracts": self.contract.code,
            "partner_id": self.partner.ref,
        }

    @patch(
        "odoo.addons.otrs_somconnexio.wizards.contract_iban_change.contract_iban_change.UpdateTicketWithInfo"  # noqa
    )
    @patch(
        "odoo.addons.contract_api_somconnexio.wizards.contract_iban_change.contract_iban_change.ContractIbanChangeProcess"  # noqa
    )
    def test_wizard_from_api_ok(
        self, MockContractIbanChangeProcess, MockUpdateTicketWithInfo
    ):
        MockContractIbanChangeProcess.return_value.run_from_api.return_value = True

        info = {
            "title": "Canvi d'IBAN realitzat",
            "body": "El canvi d'IBAN s'ha realitzat correctament.",
        }
        dynamic_fields_dct = {"ibanOK": 1}

        self.wizard.run_from_api(**self.params)

        MockContractIbanChangeProcess.assert_called_once()
        MockContractIbanChangeProcess.return_value.run_from_api.assert_called_once()
        MockUpdateTicketWithInfo.assert_called_once_with(
            self.ticket_id,
            info,
            dynamic_fields_dct,
        )
        MockUpdateTicketWithInfo.return_value.run.assert_called_once()

    @patch(
        "odoo.addons.otrs_somconnexio.wizards.contract_iban_change.contract_iban_change.UpdateTicketWithInfo"  # noqa
    )
    @patch(
        "odoo.addons.contract_api_somconnexio.wizards.contract_iban_change.contract_iban_change.ContractIbanChangeProcess"  # noqa
    )
    def test_wizard_run_from_api_validation_error_update_ticket(
        self, MockContractIbanChangeProcess, MockUpdateTicketWithInfo
    ):
        error_msg = "Invalid bank for IBAN: ESXXXXX."
        MockContractIbanChangeProcess.return_value.run_from_api.side_effect = (
            ValidationError(error_msg)
        )
        error = {"title": "Error en el canvi d'IBAN", "body": error_msg}
        dynamic_fields_dct = {"ibanKO": 1}

        self.wizard.run_from_api(**self.params)

        MockUpdateTicketWithInfo.assert_called_once_with(
            self.ticket_id,
            error,
            dynamic_fields_dct,
        )
        MockUpdateTicketWithInfo.return_value.run.assert_called_once()

    @patch(
        "odoo.addons.otrs_somconnexio.wizards.contract_iban_change.contract_iban_change.UpdateTicketWithInfo"  # noqa
    )
    @patch(
        "odoo.addons.contract_api_somconnexio.wizards.contract_iban_change.contract_iban_change.ContractIbanChangeProcess"  # noqa
    )
    def test_wizard_run_from_api_user_error_update_ticket(
        self, MockContractIbanChangeProcess, MockUpdateTicketWithInfo
    ):
        error_msg = "Partner id %s not found" % (self.partner.ref,)
        MockContractIbanChangeProcess.return_value.run_from_api.side_effect = UserError(
            error_msg
        )
        error = {"title": "Error en el canvi d'IBAN", "body": error_msg}
        dynamic_fields_dct = {"ibanKO": 1}

        self.wizard.run_from_api(**self.params)

        MockUpdateTicketWithInfo.assert_called_once_with(
            self.ticket_id,
            error,
            dynamic_fields_dct,
        )
        MockUpdateTicketWithInfo.return_value.run.assert_called_once()
