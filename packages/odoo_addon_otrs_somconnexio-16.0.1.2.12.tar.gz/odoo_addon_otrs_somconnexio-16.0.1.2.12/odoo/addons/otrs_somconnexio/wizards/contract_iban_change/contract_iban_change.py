from odoo import models
from odoo.exceptions import UserError

from ...otrs_services.update_ticket_with_info import UpdateTicketWithInfo


class ContractIbanChangeWizard(models.TransientModel):
    _inherit = "contract.iban.change.wizard"

    def run_from_api(self, **params):
        info = {}
        dynamic_fields_dct = {}
        try:
            super().run_from_api(**params)
        except UserError as error:  # Catching both ValidationError and UserError
            info = {
                "title": "Error en el canvi d'IBAN",
                "body": str(error),
            }
            dynamic_fields_dct = {"ibanKO": 1}
        else:
            info = {
                "title": "Canvi d'IBAN realitzat",
                "body": "El canvi d'IBAN s'ha realitzat correctament.",
            }
            dynamic_fields_dct = {"ibanOK": 1}
        finally:
            update_ticket = UpdateTicketWithInfo(
                params["ticket_id"], info, dynamic_fields_dct
            )
            update_ticket.run()
