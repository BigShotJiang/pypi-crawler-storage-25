"""Core MCP tools for initializing hardware clients."""

from __future__ import annotations

from typing import Optional

from ..state import set_afm_instance, set_vi_instance


def set_afm_instances() -> str:
    set_afm_instance()
    return "DONE--set_afm_instances()"


def set_vi_instances(app_path: Optional[str] = None) -> str:
    set_vi_instance(app_path=app_path)
    return "DONE--set_vi_instances()"


TOOLS = (
    set_afm_instances,
    set_vi_instances,
)
