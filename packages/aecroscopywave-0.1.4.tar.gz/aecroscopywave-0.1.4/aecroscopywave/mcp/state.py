"""Shared instrument state for MCP tools."""

from __future__ import annotations

from typing import Optional

pyvi = None
pycy = None

DEFAULT_VI_APP_PATH = (
    r"C:\Users\Asylum Research\Desktop\PyScanner_FPGA_6124_01"
    r"\PyScanner_FPGA_6124_01.exe"
)


def set_afm_instance():
    """Create and cache the Cypher controller."""
    global pycy
    from aecroscopywave.interfaces import Cypher

    pycy = Cypher.PyCypher()
    return pycy


def set_vi_instance(app_path: Optional[str] = None):
    """Create and cache the LabVIEW controller."""
    global pyvi
    from aecroscopywave.interfaces import WaveVI

    if app_path is None:
        app_path = DEFAULT_VI_APP_PATH
    pyvi = WaveVI.PyWaveVI(app_path=app_path)
    return pyvi


def require_afm_instance():
    if pycy is None:
        raise RuntimeError("No Cypher instance available, call set_afm_instances() first.")
    return pycy


def require_vi_instance():
    if pyvi is None:
        raise RuntimeError("No VI instance available, call set_vi_instances() first.")
    return pyvi
