
# PyCypher
# Yongtao Liu

import win32com.client
import time
import numpy as np
from typing import Optional, Dict, Tuple, Any, List
from ..logger import log_function

class PyCypher:
    """
    Thin wrapper to connect to Igor Pro via COM for AFM control.

    Parameters
    ----------
    app_path : str, optional
        Path to Igor.exe (kept for reference or future use; not required for COM attach).
        Default: r\"C:\\AsylumResearch\\v18\\Igor Pro Folder\\Igor.exe\"
    client : str, optional
        COM ProgID for Igor Pro. Default: \"IgorPro.Application\".

    Attributes
    ----------
    igor :
        The COM object returned by win32com.client.Dispatch(client).

    Notes
    -----
    - This class **does not** launch Igor; it just attaches to a running COM server.
      Make sure Igor Pro is installed with COM automation enabled.
    - If you need auto-launch/retry logic later, you can extend this class without
      changing the public interface.
    
    Method Organization
    -------------------
    
    **Low-Level Communication:**
    - Execute() : Send arbitrary Igor commands
    - ARExecuteControl() : Execute UI control commands
    
    **Parameter Management:**
    - PV() : Set Master Variables (low-level)
    - get_MasterVariables() : Retrieve all Master Variables
    
    **High-Level Configuration:**
    - set_Master_Panel() : Configure imaging mode, scan mode, and parameters
    - set_CrosspointPanel() : Configure signal routing
    
    **Coordinate Transformations:**
    - pixel_to_xy() : Pixel → Normalized coordinates [-1, 1]
    - xy_to_voltage() : Normalized coordinates → Piezo voltages
    - pixel_to_voltage() : Pixel → Piezo voltages (combines above two)
    
    **Tip Control:**
    - show_tip() : Display tip location indicator
    - move_tip() : Move tip to specific pixel location
    
    Common Workflows
    ----------------
    
    **Workflow 1: Configure and start a scan**
```python
    pc = PyCypher()
    params = {"ScanSize": 10e-6, "PointsLines": 128, "ScanRate": 1.0}
    pc.set_Master_Panel(
        imaging_mode="PFM Mode",
        scan_mode="One Frame Mode",
        parameters=params,
        do_scan="Frame Up"
    )
    # Internally calls: ARExecuteControl (2x) → PV → ARExecuteControl
```
    """

    def __init__(self, app_path: str = r"C:\AsylumResearch\v18\Igor Pro Folder\Igor.exe", client: str = "IgorPro.Application") -> None:
        """
        Initialize PyCypher and attach to a running Igor Pro COM server.

        Parameters
        ----------
        app_path : str, optional
            Path to Igor.exe. Kept for reference; not used for COM connection.
            Default: r"C:\\AsylumResearch\\v18\\Igor Pro Folder\\Igor.exe"
        client : str, optional
            COM ProgID for Igor Pro. Default: "IgorPro.Application"

        Raises
        ------
        com_error
            If Igor Pro COM server is not running or cannot be accessed.

        Notes
        -----
        This method attaches to an already running Igor Pro instance via COM.
        Make sure Igor Pro is running before creating a PyCypher instance.

        Examples
        --------
        >>> pc = PyCypher()
        >>> pc.igor.Execute("Print \\"Hello from Igor Pro!\\"")
        """
        # Keep a reference.
        self.app_path: str = app_path

        # Attach to Igor Pro via COM. 
        self.igor = win32com.client.Dispatch(client)

    @log_function
    def Execute(self, command: str) -> str:
        """
        Execute an arbitrary Igor Pro command via COM automation.
        
        This is a low-level method that sends commands directly to the Igor Pro
        command line. It provides direct access to all Igor Pro functionality but
        requires knowledge of Igor Pro command syntax.
        
        Parameters
        ----------
        command : str
            The Igor Pro command string to execute. Must use valid Igor Pro syntax.
            Can include Igor functions, variable assignments, control flow, etc.
        
        Returns
        -------
        str
            Confirmation message containing the executed command:
            "DONE--Execute: {command}"

        **Called By:**
        - PV() : Sends PV("name", value) commands to set Master Variables
        - ARExecuteControl() : Sends ARExecuteControl(...) commands to trigger UI controls
        - move_tip() : Sends td_SetRamp(...) commands for piezo motion

        Warnings
        --------
        Direct command execution bypasses safety checks. Incorrect commands may:
        - Crash Igor Pro
        - Corrupt data
        - Leave the AFM in an unsafe state
        - Cause unintended hardware actions

        Examples
        --------
        >>> pc = PyCypher()
        >>> # Print a message to Igor Pro history
        >>> pc.Execute('Print "Hello from Igor Pro!"')
        'DONE--Execute: Print "Hello from Igor Pro!"'
        """
        self.igor.Execute(command)
        return f"DONE--Execute{command}"

    @log_function
    def PV(self, parameters: Optional[Dict[str, Any]] = None) -> str:
        """
        Set Master Variables in Igor Pro using the PV() (Parameter-Value) command.
        
        This method sends parameter-value pairs to Igor Pro, updating AFM system
        configuration and operating parameters. The PV() command in Igor Pro is the
        standard way to programmatically modify Master Variables.
        
        Parameters
        ----------
        parameters : dict, optional
            Dictionary mapping parameter names to their values. Default is None.
            Keys must be valid Master Variable names (case-sensitive).
            Values can be numeric (int, float) or strings.
            
            If None or empty dict, the method returns without executing any commands.
        
        Returns
        -------
        str
            Confirmation message for the last parameter set, or notification if
            no parameters were provided.
        
        Raises
        ------
        KeyError
            If parameter name is not a valid Master Variable (error occurs in Igor Pro).
        TypeError
            If parameter value type is incompatible with the target variable.
        
        Notes
        -----
        **Execution Sequence:**
        
        For each parameter in the dictionary:
        1. Constructs PV() command string: 'print PV("name", value)'
        2. Calls Execute() to send command to Igor Pro
        3. Igor Pro updates the Master Variable
        4. Returns confirmation for the last parameter set
        
        **Method Call Hierarchy:**
    ```
        PV()
        └── Execute()  # Called once per parameter
            └── self.igor.Execute()  # COM call to Igor Pro
    ```
        
        **Called By:**
        - set_Master_Panel() : Uses this method to set scan configuration parameters
        
        **Related Methods:**
        - get_MasterVariables() : Retrieves current Master Variable values
        - set_Master_Panel() : High-level interface that calls this method
        
        This is a low-level method. For common parameter sets, consider using
        set_Master_Panel() which provides a higher-level interface.
        
        Warnings
        --------
        Incorrect parameter values may cause AFM instability or damage. Always verify
        parameter ranges before setting. Critical parameters include:
        - Setpoint: Too low may crash tip; too high may lose feedback
        - DriveAmplitude: Excessive values may damage cantilever
        - Gains: Unstable feedback if set incorrectly
        
        Examples
        --------
        >>> pc = PyCypher()
        >>> # Set multiple scan parameters
        >>> params = {
        ...     "ScanSize": 10e-6,
        ...     "PointsLines": 128,
        ...     "ScanRate": 0.5
        ... }
        >>> pc.PV(parameters=params)
        "DONE--PV('ScanRate', 0.5)"
        
        >>> # Verify parameter was set
        >>> mvs = pc.get_MasterVariables()
        >>> print(mvs['ScanSize'])
        1e-05
        """
        if parameters is None:
            print("No parameters provided. Nothing executed.")
            return "No parameters provided, nothing executed"

        for name, value in parameters.items():
            self.Execute(f'print PV("{name}", {value})')
        return f"DONE--PV()"

    @log_function
    def ARExecuteControl(self, control_name: str, graph_name: str, var_num: float = 0, var_str: str = "") -> str:
        """
        Execute a control command in Asylum Research Igor Pro interface via COM automation.
        
        This method programmatically triggers user-interface controls (buttons, checkboxes,
        popups, etc.) in Asylum Research control panels, enabling automated AFM operation
        without manual interaction.
        
        Parameters
        ----------
        control_name : str
            Name of the Igor control to execute.
            Examples: "UpScan_0", "ImagingModePopup_0", "ShowXYSpotCheck_1"
            Control names can be found by examining the panel in Igor Pro or
            consulting Asylum Research documentation.
        graph_name : str
            Name of the window or panel hosting the control.
            Common panels: "MasterPanel", "CrosspointPanel", "FMapPanel"
        var_num : int or float, optional
            Numeric value for control state. Default is 0.
            - For checkboxes: 0 (unchecked) or 1 (checked)
            - For buttons: typically 0
            - For SetVariable: numeric value to set
            - For popups: ignored (use var_str instead)
        var_str : str, optional
            String value for textual or popup controls. Default is "".
            - For popups: the exact text of the menu item to select
            - For text inputs: the string to enter
            - For other controls: typically empty
        
        Returns
        -------
        str
            Confirmation message containing the executed command.
        
        Notes
        -----
        **Execution Sequence:**
        
        1. Constructs ARExecuteControl command string
        2. Calls Execute() to send command to Igor Pro
        3. Igor Pro executes the control's associated function
        4. Returns confirmation message
        
        **Method Call Hierarchy:**
    ```
        ARExecuteControl()
        └── Execute()
            └── self.igor.Execute()  # COM call
    ```
        
        **Called By:**
        - set_Master_Panel() : Executes imaging mode, scan mode, and scan controls
        - set_CrosspointPanel() : Executes channel routing controls
        - show_tip() : Executes tip display controls
        
        This is a low-level method providing direct access to UI controls.
        For common operations, use high-level methods like set_Master_Panel()
        or set_CrosspointPanel().
        
        Error codes returned by ARExecuteControl in Igor Pro:
        - 0: Success, command executed properly
        - 1: Control does not exist in the specified panel
        - 2: Control type is not supported
        - 3: Control has no associated function to call
        - 4: Number of arguments does not match control type
        - 7: Function does not exist as a user function
        - 9: Internal error (should be impossible)
        
        These errors are printed in Igor Pro but not directly returned by this method.
        
        Examples
        --------
        >>> pc = PyCypher()
        >>> # Click the "Up Scan" button
        >>> pc.ARExecuteControl("UpScan_0", "MasterPanel", 0, "")
        
        >>> # Select from a popup menu
        >>> pc.ARExecuteControl("ImagingModePopup_0", "MasterPanel", 0, "PFM Mode")
        
        >>> # Set a numeric variable
        >>> pc.ARExecuteControl("ScanSizeSetVar", "MasterPanel", 10e-6, "")
        """
        # Build the Igor command
        command = f'print ARExecuteControl("{control_name}", "{graph_name}", {var_num}, "{var_str}")'
        self.Execute(command)
        return f"DONE--ARExecuteControl{command}"

    @log_function
    def set_folder(self, file_loc: str) -> str:
        """
        Set the data save location for AFM measurements in Igor Pro.
        
        This method configures the file system paths where AFM data (images and force curves)
        will be saved. It updates multiple global strings in the Asylum Research software,
        creates symbolic paths, and initializes the file numbering system.
        
        Parameters
        ----------
        file_loc : str
            Windows-style path to the target directory where data will be saved.
            Can be absolute or relative path.
            Examples: 
            - r"C:\\Data\\AFM\\Experiment1"
            
        Returns
        -------
        str
            Confirmation message "DONE--set_folder: {file_loc}"
            
        Notes
        -----
        **Execution Sequence:**
        This method performs multiple operations to fully configure the save location:
        
        1. Converts Windows path to Igor-compatible format (via windows2igor utility)        
        2. Update Global String Variables
        - GlobalStrings[18]: Current save path
        - GlobalStrings[19]: Force curve save path
        - GlobalStrings[20]: Image save path
        - GlobalStrings[21]: Base save path
        - These are internal Asylum Research path storage locations
        
        3. Insert into Path History
        - Adds path to recently used locations
        - InsertNewPathInHistory() makes it accessible in UI dropdowns
        
        4. Build File Folder Structure
        - BuildFileFolder("SaveForce", path) initializes force curve directories
        
        5. Create Symbolic Paths
        - NewPath/O SaveImage: Path alias for image data
        - NewPath/O SaveForce: Path alias for force curve data
        
        6. Initialize File Numbering
        - PV("BaseSuffix", 0): Resets file counter to 0000
        - ARCheckSuffix(): Validates and updates suffix counter
        
        7. Update UI Elements
        - UpdateStatusText(): Refreshes status bar with new path
        - UpdateHDDStrength(): Updates disk space indicator
       
        Examples
        --------
        >>> pc = PyCypher()
        >>> # Set save location to a specific directory
        >>> pc.set_folder(r"C:\\Data\\AFM\\Sample1")
        'DONE--set_folder: C:\\Data\\AFM\\Sample1'
        """
        # Convert Windows path to Igor-compatible format
        file_loc_igor = windows2igor(file_loc)
        
        # Update global string variables for save paths
        self.Execute(f'root:Packages:MFP3D:Main:Strings:GlobalStrings[20] = "{file_loc_igor}"')
        self.Execute(f'InsertNewPathInHistory("{file_loc_igor}")')
        self.Execute(f'root:Packages:MFP3D:Main:Strings:GlobalStrings[18] = "{file_loc_igor}"')
        self.Execute(f'root:Packages:MFP3D:Main:Strings:GlobalStrings[19] = "{file_loc_igor}"')
        self.Execute(f'root:Packages:MFP3D:Main:Strings:GlobalStrings[21] = "{file_loc_igor}"')
        
        # Build file folder structure
        self.Execute(f'BuildFileFolder("SaveForce","{file_loc_igor}")')
        
        # Create symbolic paths for image and force curve data
        self.Execute(f'NewPath/O SaveImage "{file_loc_igor}"')
        self.Execute(f'NewPath/O SaveForce "{file_loc_igor}"')
        
        # Reset file numbering and update UI
        self.Execute('PV("BaseSuffix", 0000)')
        self.Execute('ARCheckSuffix()')
        self.Execute('UpdateStatusText()')
        self.Execute('UpdateHDDStrength()')
        
        return f"DONE--set_folder: {file_loc}"    

    @log_function
    def check_folder(self) -> str:
        """
        Retrieve the current data save location from Igor Pro.
        
        This method reads the current file save path configured in the Asylum Research
        software and returns it in Windows path format. This is useful for verifying
        where data will be saved or for programmatically tracking save locations.
        
        Returns
        -------
        str
            Current save location in Windows path format.
            Example: r"C:\\Data\\AFM\\Experiment1"
        
        **Related Methods:**
        - set_folder() : Sets the save location
        
        Examples
        --------
        >>> pc = PyCypher()
        >>> # Check current save location
        >>> current_path = pc.check_folder()
        >>> print(f"Data will save to: {current_path}")
        Data will save to: C:\\Data\\AFM\\Experiment1
        """
        # Access GlobalStrings wave and read the current save path (index 18)
        file_loc_igor = self.igor.DataFolder(r"root:Packages:MFP3D:Main:Strings").Wave("GlobalStrings").GetTextWavePointValue(18, 0)
        
        # Convert from Igor format to Windows format
        windows_format = igor2windows(file_loc_igor)
        return windows_format

    @log_function
    def get_base_filename(self) -> str:
        """
        Get the current base filename from Igor AFM system.
        
        Retrieves the base name used for file naming in the Asylum AFM system.
        This is the prefix that will be used when capturing images or saving data,
        before any suffix numbers are appended.
        
        Returns
        -------
        str
            Current base filename string 
        
        Examples
        --------
        >>> # Get current base filename
        >>> base_name = get_base_filename(igor)
        >>> print(f"Files will be saved as: {base_name}####.ibw")
        """
        base_name_variable = self.DataFolder(r"root:packages:MFP3D:Main:Variables").Variable("BaseName")
        base_name_str = base_name_variable.GetStringValue(0)
        return base_name_str

    @log_function
    def set_base_filename(self, base_filename: str) -> str:
        """
        Set the base filename for AFM data files and reset the file counter.
        This method configures the prefix used for all saved data files (images and
        force curves) and resets the numeric suffix counter to 0000. Files will be
        saved with the format: {base_filename}{suffix}.ibw
        
        Parameters
        ----------
        base_filename : str
            Base name prefix for data files. Should not include file extension.
            Examples: "Sample1_", "PFM_Image", "ForceMap", "Test_"
            The underscore at the end is optional but recommended for readability
            of generated filenames (e.g., "Sample1_0000" vs "Sample10000").
        
        Returns
        -------
        str
            Confirmation message: "DONE--set_base_filename: {base_filename}"
        
        
        Examples
        --------
        >>> pc = PyCypher()
        >>> # Set base filename for a sample
        >>> pc.set_base_filename("Sample1_")
        'DONE--set_base_filename: Sample1_'
        >>> # Next saved file will be: Sample1_0000.ibw

        >>> # Automated batch processing
        >>> samples = ["Control", "Treatment1", "Treatment2"]
        >>> for sample in samples:
        ...     pc.set_base_filename(f"{sample}_")
        ...     for scan_num in range(5):
        ...         pc.set_Master_Panel(do_scan="Frame Up")
        ...         time.sleep(30)  # Wait for scan completion
        ...     # Results: Control_0000-0004, Treatment1_0000-0004, Treatment2_0000-0004
        """
        self.Execute(f'root:Packages:MFP3D:Main:Variables:BaseName = "{base_filename}"') # Set the base filename
        self.Execute('PV("BaseSuffix", 0000)') # Reset file counter to 0000
        self.Execute('ARCheckSuffix()') # Validate and update suffix (may increment if files exist)
        return f"DONE--set_base_filename: {base_filename}"
    
    @log_function
    def engage (self,):
        """Engage the AFM tip"""
        self.Execute('SimpleEngageMe("SimpleEngageButton")')
        return "Executed Engage"

    @log_function
    def withdraw (self,):
        """Withdraw the AFM tip"""
        self.Execute('DoScanFunc("StopEngageButton")')
        return "Executed Withdraw"

    @log_function
    def doIV(self,):
        """Perform a single-point I-V spectroscopy 
        measurement at the current tip location"""
        self.ARExecuteControl("ArDoIVDoItButton_1", "ARDoIVPanel")
        return "Executed DoIV"
    
    @log_function
    def control_laser(self, state):
        """
        Turn laser on or off.
        
        Parameters
        ----------
        state : bool or int
            True/1 for on, False/0 for off
        """
        state_value = 1 if state else 0
        self.Execute(f'td_wv("Red Laser", {state_value})')
        return f"DONE-- Laser is {state_value}"

    @log_function
    def set_Master_Panel(self, imaging_mode: str = "PFM Mode", scan_mode: str = "One Frame Mode", 
                         parameters: Optional[Dict[str, float]] = None, do_scan: Optional[str] = None) -> str:
        """
        Configure the Master Panel settings and optionally initiate scanning.
        
        The Master Panel is the primary control interface in Asylum Research AFM software.
        This method allows programmatic configuration of imaging mode, scan mode, operating
        parameters, and scan execution.
        
        Parameters
        ----------
        imaging_mode : str, optional
            AFM imaging mode. Default is "PFM Mode".
            Common modes include:
            - "Contact": Contact mode imaging
            - "AC Mode": Tapping/AC mode imaging
            - "PFM Mode": Piezoresponse Force Microscopy
            - "DART": Dual AC Resonance Tracking
            Check your AFM software for available modes.
        scan_mode : str, optional
            Scan acquisition mode. Default is "One Frame Mode".
            Common modes include:
            - "One Frame Mode": Single scan frame
            - "Continuous Mode": Continuous scanning
            - "Point and Shoot": Single point measurements
        parameters : dict, optional
            Dictionary of operating parameters to set. Default is None.
            Keys must match Master Variable names. See PV() for supported parameters.
        do_scan : {"Frame Up", "Frame Down", "Stop"}, optional
            Scan command to execute after configuring parameters. Default is None (no action).
            - "Frame Up": Start upward scan
            - "Frame Down": Start downward scan
            - "Stop": Stop current scan
        
        Returns
        -------
        str
            Confirmation message "DONE--set Master Panel"
        
        Raises
        ------
        ValueError
            If do_scan is not one of {'Frame Up', 'Frame Down', 'Stop', None}.
        
        Notes
        -----
        **Execution Sequence:**
        
        This method orchestrates multiple lower-level operations in the following order:
        
        1. **Set Imaging Mode** (via ARExecuteControl)
        - Control: "ImagingModePopup_0" on "MasterPanel"
        - Sets the AFM imaging mode (e.g., "PFM Mode", "Contact")
        
        2. **Set Scan Mode** (via ARExecuteControl)
        - Control: "LastScanPopup_0" on "MasterPanel"
        - Sets the scan acquisition mode (e.g., "One Frame Mode")
        
        3. **Set Parameters** (via PV)
        - Iterates through all key-value pairs in parameters dict
        - Calls PV() to set each Master Variable
        - If parameters=None, this step is skipped
        
        4. **Wait for Stabilization**
        - 1-second delay using time.sleep(1)
        - Ensures AFM software processes all parameter changes
        
        5. **Execute Scan Command** (via ARExecuteControl, optional)
        - Only if do_scan is not None
        - Maps do_scan string to control name:
            * "Frame Up" → "UpScan_0"
            * "Frame Down" → "DownScan_0"
            * "Stop" → "StopScan_0"
        - Executes the corresponding control on "MasterPanel"
        
        **Method Calls from PyCypher:**
        - ARExecuteControl() : Called 2-3 times (imaging mode, scan mode, optional scan command)
        - PV() : Called once (sets all parameters in dict)
        - Execute() : Called indirectly through ARExecuteControl and PV
        
        The 1-second delay is critical - removing it may cause scan parameters to be
        overridden or ignored if a scan starts too quickly.
        
        Examples
        --------
        >>> pc = PyCypher()
        >>> # Full workflow: configure and scan
        >>> params = {
        ...     "ScanSize": 10e-6,
        ...     "PointsLines": 128,
        ...     "ScanRate": 0.5,
        ...     "DriveAmplitude": 1.0
        ... }
        >>> pc.set_Master_Panel(
        ...     imaging_mode="PFM Mode",
        ...     scan_mode="One Frame Mode",
        ...     parameters=params,
        ...     do_scan="Frame Up"
        ... )
        'DONE--set Master Panel'
        
        >>> # Change parameters without scanning
        >>> pc.set_Master_Panel(parameters={"ScanAngle": 45.0})
        'DONE--set Master Panel'
        
        >>> # Emergency stop
        >>> pc.set_Master_Panel(do_scan="Stop")
        'DONE--set Master Panel'
        
        See Also
        --------
        ARExecuteControl : Low-level control execution used by this method
        PV : Parameter setting method called for each parameter
        Execute : Base method for sending Igor commands
        set_CrosspointPanel : Configure signal routing channels
        get_MasterVariables : Retrieve current parameter values
        """
        # Set Imaging Mode and Scan Mode
        self.ARExecuteControl("ImagingModePopup_0", "MasterPanel", 0, imaging_mode)
        self.ARExecuteControl("LastScanPopup_0", "MasterPanel", 0, scan_mode)

        # Set parameters
        self.PV(parameters)

        time.sleep(1)
        # start/stop scan
        if do_scan is not None:
            cmd_map = {
                "Frame Up":   "UpScan_0",
                "Frame Down": "DownScan_0",
                "Stop":       "StopScan_0",
            }
            if do_scan not in cmd_map:
                raise ValueError("do_scan must be one of {'Frame Up', 'Frame Down', 'Stop'} or None.")
            _cmd = cmd_map[do_scan]
            self.ARExecuteControl(_cmd, "MasterPanel", 0, "")
            # Wait until scan to finish
            time.sleep(20)
            while self.is_scanning():
                time.sleep(1)
        return "DONE--set Master Panel"

    @log_function
    def is_scanning(self) -> bool:
        """
        Check if AFM is currently performing a scan operation.
        
        This method queries Igor Pro to determine whether the AFM is actively scanning
        (acquiring image data). It reads the OutWaves text wave which contains status
        information about the current scanning state. This is useful for monitoring
        scan progress or implementing wait loops in automated workflows.
        
        Returns
        -------
        bool
            True if AFM is currently scanning (outputting data).
            False if AFM is idle or scan has completed.
    
        Examples
        --------
        >>> pc = PyCypher()
        >>> # Check if currently scanning
        >>> is_scanning = pc.scanning()
        >>> print(f"Currently scanning: {is_scanning}")
        Currently scanning: False 
        >>> # Wait for scan to complete
        >>> while pc.scanning():
        ...     print("Scanning in progress...")
        ...     time.sleep(5)
        >>> print("Scan complete!")

        """
        # Access OutWaves text wave containing scan status
        data = self.igor.DataFolder(r"root:packages:MFP3D").Wave("OutWaves")
        # Read scanning status from first element [0, 0]
        outputting = bool(data.GetTextWavePointValue(0, 0))
        
        return outputting

    @log_function
    def set_CrosspointPanel(self, channel_settings: Optional[Dict[str, str]] = None, lock: bool = True) -> str:
        """
        Configure the Crosspoint Panel channels in Igor Pro AFM software.
        
        The Crosspoint Panel manages signal routing between various input/output channels
        in the AFM system. This method allows programmatic configuration of channel
        assignments and optionally locks the settings to prevent accidental changes.
        
        Parameters
        ----------
        channel_settings : dict, optional
            Dictionary mapping Crosspoint channel names to their output assignments.
            Default is None (or empty dict).
            
            - Keys: Channel control names as they appear in the Crosspoint Panel
            Examples: "BNCOut0", "BNCOut1", "Chip", "Shake", "PhotoDetect"
            - Values: Output signal assignments
            Examples: "OutA", "OutB", "Defl", "ZLVDT", "InA", "InB"
            
            Common channel configurations:
            - BNC outputs: "BNCOut0", "BNCOut1", "BNCOut2", "BNCOut3"
            - Drive signals: "Chip", "Shake"
            - Detection: "PhotoDetect", "AuxDetect"
            
            If None or empty dict, only WriteXPT is executed (useful when lock=False
            to just update without changing assignments).
            
        lock : bool, optional
            Whether to lock all channels after assignment to prevent manual changes.
            Default is True.
            - True: Enables "Don't Change XPT" checkbox, preventing UI modifications
            - False: Leaves channels unlocked, allowing manual adjustments
        
        Returns
        -------
        str
            Confirmation message "DONE--set CrosspointPanel"
        
        Raises
        ------
        KeyError
            If channel name does not exist in Crosspoint Panel.
        ValueError
            If output assignment is not valid for the specified channel.
        
        Notes
        -----
        **Execution Sequence:**
        
        1. **Configure Channels** (via ARExecuteControl, for each channel)
        - Iterates through channel_settings dictionary
        - For each key-value pair:
            * Control name: key (e.g., "BNCOut0")
            * Panel: "CrosspointPanel"
            * var_num: 0 (not used for popups)
            * var_str: value (e.g., "OutA")
        - Calls ARExecuteControl() once per channel
        
        2. **Lock Channels** (via ARExecuteControl, conditional)
        - If lock=True:
            * Control name: "DontChangeXPTCheck"
            * Panel: "CrosspointPanel"
            * var_num: True (check the checkbox)
            * var_str: "" (not used)
        - Prevents accidental manual changes to crosspoint settings
        
        3. **Write Configuration** (via ARExecuteControl)
        - Control name: "WriteXPT"
        - Panel: "CrosspointPanel"
        - var_num: True (execute the write)
        - var_str: "" (not used)
        - Sends configuration to Crosspoint hardware
        - This step is ALWAYS executed, even if channel_settings is empty
        
        **Method Call Hierarchy:**
    ```
        set_CrosspointPanel()
        ├── ARExecuteControl()  # Called len(channel_settings) times for channels
        ├── ARExecuteControl()  # Called once if lock=True (DontChangeXPTCheck)
        └── ARExecuteControl()  # Called once for WriteXPT
            └── Execute()  # Each ARExecuteControl calls this
                └── self.igor.Execute()  # COM call
    ```
      
        **Related Methods:**
        - set_Master_Panel() : Often called in sequence with this method for full setup
        - ARExecuteControl() : Low-level method used internally
        
        **Typical Use Cases:**
        1. Band excitation experiments: Route drive signals to specific outputs
        2. Custom detection schemes: Route detector signals appropriately
        3. Lock configurations for automated experiments
        
        Warnings
        --------
        Incorrect channel assignments may disrupt AFM operation or feedback control.
        
        Examples
        --------
        >>> pc = PyCypher()
        >>> # Configure BNC outputs for band excitation
        >>> settings = {
        ...     "BNCOut0": "OutA",      # Drive signal to BNC0
        ...     "BNCOut1": "OutB",      # Response to BNC1
        ...     "Chip": "Defl"          # Standard deflection
        ... }
        >>> pc.set_CrosspointPanel(channel_settings=settings, lock=True)
        'DONE--set CrosspointPanel'
        
        >>> # Configure without locking (allow manual adjustments)
        >>> settings = {"BNCOut0": "OutA"}
        >>> pc.set_CrosspointPanel(channel_settings=settings, lock=False)
        'DONE--set CrosspointPanel'
        
        >>> # Just write XPT without changing channels (refresh configuration)
        >>> pc.set_CrosspointPanel(channel_settings=None, lock=False)
        'DONE--set CrosspointPanel'
        
        >>> # Complete setup workflow
        >>> # Step 1: Configure crosspoint
        >>> xpt_settings = {
        ...     "BNCOut0": "OutA",
        ...     "BNCOut1": "OutB",
        ...     "Chip": "OutC"
        ... }
        >>> pc.set_CrosspointPanel(channel_settings=xpt_settings, lock=True)
        >>> 
        >>> # Step 2: Configure scan parameters
        >>> scan_params = {"ScanSize": 10e-6, "PointsLines": 128}
        >>> pc.set_Master_Panel(imaging_mode="AC Mode", parameters=scan_params)
        
        See Also
        --------
        ARExecuteControl : Low-level control execution used by this method
        set_Master_Panel : Configure Master Panel (often used together)
        Execute : Base method for Igor Pro commands
        """
        if channel_settings is None:
            return "None channel setting conditions provided"

        # Iterate through provided mappings
        for _name, _setting in channel_settings.items():
            self.ARExecuteControl(_name, "CrosspointPanel", 0, _setting)
        if lock:  # Optionally lock the channel
            self.ARExecuteControl("DontChangeXPTCheck", "CrosspointPanel", True, "")

        # Finalize Crosspoint settings
        self.ARExecuteControl("WriteXPT", "CrosspointPanel", True, "")
        return "DONE--set CrosspointPanel"

    @log_function
    def get_MasterVariables(self,) -> dict:
        """
        Retrieve all Master Variables from Igor Pro as a dictionary.
        
        Master Variables contain comprehensive AFM system parameters including scan
        settings, piezo calibrations, feedback parameters, and system configurations.
        This method provides read access to the current state of all AFM parameters.
        
        Returns
        -------
        dict
            Dictionary mapping variable names (str) to their current values (float).
            
            Common Master Variables include:
            - 'ScanSize': Scan area size (meters)
            - 'ScanPoints': Number of points per scan line
            - 'ScanLines': Number of scan lines
            - 'ScanRate': Scan rate
            - 'ScanSpeed': Scan speed (meters/second)
            - 'ScanAngle': Scan rotation angle (degrees)
            - 'XOffset', 'YOffset': Position offsets
            - 'FastRatio', 'SlowRatio': Scan aspect ratios
            - 'XLVDTSens': X-axis LVDT sensitivity (meters/volt)
            - 'YLVDTSens': Y-axis LVDT sensitivity (meters/volt)
            - 'ZLVDTSens': Z-axis LVDT sensitivity (meters/volt)
            - 'XLVDTOffset', 'YLVDTOffset', 'ZLVDTOffset': LVDT offsets (volts)
            - 'Setpoint': Force/amplitude setpoint
            - 'ProportionalGain': P gain for feedback
            - 'IntegralGain': I gain for feedback
            - 'FBFilterBW': Feedback filter bandwidth
            - 'DriveAmplitude': AC drive amplitude (volts)
            - 'DriveFrequency': AC drive frequency
            - 'AmplitudeSetpoint': Target amplitude     
        
        **Called By:**
        - pixel_to_xy() : Reads ScanPoints, ScanLines for normalization
        - xy_to_voltage() : Reads calibrations, offsets, scan parameters
        - pixel_to_voltage() : Indirectly via pixel_to_xy and xy_to_voltage
        - move_tip() : Indirectly via pixel_to_voltage
        
        **Notes:**
        - This method reads ALL Master Variables (100+), which may take 0.1-0.5 seconds
        - For repeated access to specific variables, consider caching the result
        - The dictionary contains complete system state snapshot at call time
       
        Examples
        --------
        >>> pc = PyCypher()
        >>> # Get all Master Variables
        >>> mvs = pc.get_MasterVariables()
        >>> print(f"Total variables: {len(mvs)}")
        
        >>> # Check current scan configuration
        >>> print(f"Scan Size: {mvs['ScanSize']*1e6:.2f} µm")
        >>> print(f"Resolution: {int(mvs['ScanPoints'])} x {int(mvs['ScanLines'])}")
        >>> print(f"Scan Rate: {mvs['ScanRate']:.2f} Hz")
        Scan Size: 10.00 µm
        Resolution: 256 x 256
        Scan Rate: 1.00 Hz
        
        >>> # List all available variables
        >>> for name in sorted(mvs.keys()):
        ...     print(name)
        AmplitudeSetpoint
        DriveAmplitude
        DriveFrequency
        ...
        
        >>> # Save configuration to file
        >>> import json
        >>> with open('afm_config.json', 'w') as f:
        ...     json.dump(mvs, f, indent=2)
        """
        # Read data from MasterVariablesTable
        # Find the folder: Programming > Global Variables > Master > Right Click a Variable > Browser MasterVariablesWave > Data Folder
        mvs = self.igor.DataFolder(r'root:packages:MFP3D:main:variables')
        mvw = mvs.Wave('MasterVariablesWave')
    
        # Get the total number of variables
        dims = mvw.GetDimensions()
        variable_list_length = dims[1]
    
    
        # Set a dictionary to add variables and description
        mvs_dict = {}
        for i in range (variable_list_length):
            # MVs_dict[mvw.DimensionLabel(0,i,0)] = mvw.MDGetNumericWavePointValue(i, 0, 0, 0)[0]
            mvs_dict[mvw.DimensionLabel(0,i,0)] = mvw.GetNumericWavePointValue(i)
    
        return mvs_dict
    
    @log_function
    def pixel_to_xy(self, pixel_coordinates: Tuple[int, int]) -> Tuple[float, float]:
        """
        Convert pixel coordinates to normalized XY coordinates in range [-1, 1].
        
        This method maps pixel indices from the scan grid to normalized coordinates
        where (-1, -1) represents the bottom-left corner and (1, 1) represents the 
        top-right corner of the scan area. This normalization is the first step in
        converting pixel positions to physical positions or piezo voltages.
        
        Parameters
        ----------
        pixel_coordinates : Tuple[int, int]
            Pixel coordinates (x, y) where:
            - x: Column index (horizontal position, 0 to ScanPoints-1)
            - y: Row index (vertical position, 0 to ScanLines-1)
            
            Both indices should be zero-based (starting from 0).
            Origin (0, 0) is at bottom-left corner of scan area.
        
        Returns
        -------
        Tuple[float, float]
            Normalized XY coordinates (_x, _y) in range [-1, 1].
            - _x: Normalized x-coordinate (left: -1, center: 0, right: 1)
            - _y: Normalized y-coordinate (bottom: -1, center: 0, top: 1)
            
            These normalized coordinates are independent of scan size, making them
            useful for position calculations that need to work across different
            scan configurations.
        
        Raises
        ------
        IndexError
            If pixel_coordinates are outside valid range:
            - x must be in [0, ScanPoints-1]
            - y must be in [0, ScanLines-1]
        
        Notes
        -----
        **Execution Sequence:**
        
        1. **Retrieve Scan Dimensions** (via get_MasterVariables)
        - Calls get_MasterVariables() to get current AFM parameters
        - Extracts ScanPoints (number of pixels in X direction)
        - Extracts ScanLines (number of pixels in Y direction)
        
        2. **Calculate Normalized Coordinates**
        - X normalization: _x = 2 * (pixel_x / (ScanPoints - 1)) - 1
        - Y normalization: _y = 2 * (pixel_y / (ScanLines - 1)) - 1
        - Formula maps [0, max_pixels] to [-1, 1] linearly
        
        3. **Return Normalized Coordinates**
        - Returns tuple (_x, _y) for further processing
        
        **Method Call Hierarchy:**
    ```
        pixel_to_xy()
        └── get_MasterVariables()
            └── self.igor.DataFolder().Wave()  # COM calls to read parameters
    ```
        
        **Called By:**
        - pixel_to_voltage() : First step in pixel → voltage conversion
        - move_tip() : Indirectly via pixel_to_voltage()
        - User scripts : For coordinate system conversions
        
        **Mathematical Details:**
        
        The normalization formula ensures:
        - Corner mapping:
        * (0, 0) → (-1, -1) [bottom-left]
        * (ScanPoints-1, 0) → (1, -1) [bottom-right]
        * (0, ScanLines-1) → (-1, 1) [top-left]
        * (ScanPoints-1, ScanLines-1) → (1, 1) [top-right]
        
        - Center mapping (for N×N scan):
        * ((N-1)/2, (N-1)/2) → (0, 0) [center]
        
        - Linear interpolation between corners
    
        **Coordinate System Convention:**
        - Pixel space: Discrete grid [0, N-1] × [0, M-1]
        - Normalized space: Continuous [-1, 1] × [-1, 1]
        - Origin: Bottom-left in both systems
        - X-axis: Left to right (increasing pixel index)
        - Y-axis: Bottom to top (increasing pixel index)
        
        Examples
        --------
        >>> pc = PyCypher() # Assume 128×128 scan configured
        >>> pc.pixel_to_xy((0, 0)) # Corner pixels
        (-1.0, -1.0)  # Bottom-left corner
        >>> pc.pixel_to_xy((127, 127))
        (1.0, 1.0)  # Top-right corner
        >>> pc.pixel_to_xy((127, 0))
        (1.0, -1.0)  # Bottom-right corner
        >>> pc.pixel_to_xy((0, 127))
        (-1.0, 1.0)  # Top-left corner
        >>> # Center pixel (approximately)
        >>> pc.pixel_to_xy((64, 64))
        (0.007874015748031496, 0.007874015748031496)  # Very close to (0, 0)
        
        >>> # Edge midpoints
        >>> pc.pixel_to_xy((64, 0))
        (0.007874015748031496, -1.0)  # Bottom edge center
        >>> pc.pixel_to_xy((0, 64))
        (-1.0, 0.007874015748031496)  # Left edge center
        
        >>> # Quarter positions
        >>> pc.pixel_to_xy((32, 32))
        (-0.4960629921259843, -0.4960629921259843)
        
        >>> # Non-square scan (256×128)
        >>> # After configuring different ScanPoints and ScanLines
        >>> pc.pixel_to_xy((128, 64))  # Center of 256×128
        (0.003921568627450980, 0.007874015748031496)
        
        >>> # Use in a loop to process all pixels
        >>> for y in range(128):
        ...     for x in range(128):
        ...         norm_x, norm_y = pc.pixel_to_xy((x, y))
        ...         # Process normalized coordinates
        
        See Also
        --------
        xy_to_voltage : Convert normalized coordinates to piezo voltages (next step)
        pixel_to_voltage : Direct conversion from pixels to voltages (combines both steps)
        get_MasterVariables : Retrieves scan dimensions used by this method
        move_tip : Uses this method indirectly for tip positioning
        """
        Scan_Points = self.get_MasterVariables()["ScanPoints"]
        Scan_Lines = self.get_MasterVariables()["ScanLines"]

        # Normalize pixel position: [0, pixel_idx_max] → [-1, 1]
        _x = 2*(pixel_coordinates[0]/(Scan_Points - 1)) - 1
        _y = 2*(pixel_coordinates[1]/(Scan_Lines - 1)) - 1
        return _x, _y
   
    @log_function
    def xy_to_voltage(self, xy_coordinates: Tuple[float, float]) -> Tuple[float, float]:
        """
        Convert normalized XY coordinates to piezo voltage values.
        
        This method transforms normalized coordinates (range [-1, 1]) into the actual
        voltage values needed to position the AFM piezo scanner. The conversion accounts
        for scan size, aspect ratios, rotation angle, offsets, and sensor calibrations,
        providing accurate piezo positioning.
        
        Parameters
        ----------
        xy_coordinates : Tuple[float, float]
            Normalized XY coordinates (_x, _y) in range [-1, 1].
            - (-1, -1) corresponds to bottom-left corner of scan area
            - (1, 1) corresponds to top-right corner of scan area
            - (0, 0) corresponds to center of scan area
            
            These coordinates are typically obtained from pixel_to_xy() but can
            also be specified directly for arbitrary positions.
        
        Returns
        -------
        Tuple[float, float]
            Piezo voltage values (XLocV, YLocV) in volts.
            - XLocV: X-axis piezo voltage (horizontal positioning)
            - YLocV: Y-axis piezo voltage (vertical positioning)
            
            These voltages can be sent directly to the piezo controller to
            position the AFM tip at the desired location.
        
        Raises
        ------
        ValueError
            If xy_coordinates are outside reasonable range (typically [-1, 1]).
        
        Notes
        -----
        **Execution Sequence:**
        
        1. **Retrieve Master Variables** (via get_MasterVariables)
        - Gets all AFM system parameters
        - Key parameters used:
            * ScanSize: Overall scan area dimension
            * FastRatio, SlowRatio: Aspect ratio scaling
            * ScanAngle: Rotation angle for scan
            * XOffset, YOffset: Position offsets
            * XLVDTSens, YLVDTSens: Piezo calibrations (meters/volt)
            * XLVDTOffset, YLVDTOffset: Voltage offsets
        
        2. **Scale to Physical Coordinates**
        - Convert normalized [-1, 1] to meters
        - XLoc = (ScanSize × _x) / (2 × FastRatio)
        - YLoc = (ScanSize × _y) / (2 × SlowRatio)
        - Accounts for aspect ratios (non-square scans)
        
        3. **Apply Scan Rotation**
        - Convert ScanAngle from degrees to radians: θ = -ScanAngle × π/180
        - Create rotation matrix:
            [[cos(θ),  sin(θ)]
            [-sin(θ), cos(θ)]]
        - Apply rotation: [XLocR, YLocR] = [XLoc, YLoc] × RotationMatrix
        - Negative angle for clockwise rotation
        
        4. **Apply Position Offsets**
        - Add user-defined offsets: XLocR + XOffset, YLocR + YOffset
        - Allows centering scan on specific feature
        
        5. **Convert to Voltage**
        - XLocV = ((XLocR + XOffset) / XLVDTSens) + XLVDTOffset
        - YLocV = ((YLocR + YOffset) / YLVDTSens) + YLVDTOffset
        - LVDT sensitivity converts meters to volts
        - LVDT offset accounts for voltage bias
        
        **Method Call Hierarchy:**
    ```
        xy_to_voltage()
        └── get_MasterVariables()
            └── self.igor.DataFolder().Wave()  # COM calls to read parameters
    ```
        
        **Called By:**
        - pixel_to_voltage() : Second step in pixel → voltage conversion
        - move_tip() : Indirectly via pixel_to_voltage()
        
        **Calls To:**
        - get_MasterVariables() : Retrieves calibrations and scan parameters
        
        **Mathematical Transformation Chain:**
    ```
        Normalized XY [-1, 1]
            ↓ (scale by ScanSize and aspect ratios)
        Physical XY [meters]
            ↓ (rotate by ScanAngle)
        Rotated Physical XY [meters]
            ↓ (add XOffset, YOffset)
        Offset Physical XY [meters]
            ↓ (divide by LVDT sensitivity, add voltage offset)
        Piezo Voltage [volts]
    ```
        
        Examples
        --------
        >>> pc = PyCypher()
        >>> x_volt, y_volt = pc.xy_to_voltage((0.0, 0.0)) # Convert center position to voltage     
        >>> x_volt, y_volt = pc.xy_to_voltage((-1.0, -1.0)) # Convert corners  
    
        >>> # Two-step conversion from pixel
        >>> xy = pc.pixel_to_xy((64, 64))
        >>> x_volt, y_volt = pc.xy_to_voltage(xy)
        
        >>> # Calculate voltage range for current scan
        >>> mvs = pc.get_MasterVariables()
        >>> max_voltage = (mvs['ScanSize'] / 2) / mvs['XLVDTSens']
        >>> print(f"Voltage range: ±{max_voltage:.2f}V")
        
        See Also
        --------
        pixel_to_xy : Convert pixel coordinates to normalized XY (previous step)
        pixel_to_voltage : Direct pixel → voltage conversion (combines both steps)
        get_MasterVariables : Retrieves parameters used in conversion
        move_tip : Uses this method indirectly for tip positioning
        """
        # Retrieve MasterVariables (contains all scaling and offset parameters)
        mvs = self.get_MasterVariables()

        # Convert xy_coordinates to internal scan locations
        XLoc = (mvs["ScanSize"] * xy_coordinates[0]) / (2 * mvs["FastRatio"])
        YLoc = (mvs["ScanSize"] * xy_coordinates[1]) / (2 * mvs["SlowRatio"])
        # Apply scan angle rotation
        scan_theta = -mvs["ScanAngle"] * np.pi / 180
        RLoc1 = np.array([XLoc, YLoc])
        RLoc2 = np.array([[np.cos(scan_theta), np.sin(scan_theta)], [-np.sin(scan_theta), np.cos(scan_theta)]])
        XLocR, YLocR = np.dot(RLoc1, RLoc2)
        # Convert to internal voltage units
        XLocV = ((XLocR + mvs["XOffset"]) / mvs["XLVDTSens"]) + mvs["XLVDTOffset"]
        YLocV = ((YLocR + mvs["YOffset"]) / mvs["YLVDTSens"]) + mvs["YLVDTOffset"]

        return XLocV, YLocV

    @log_function
    def pixel_to_voltage(self, pixel_coordinates: Tuple[int, int]) -> Tuple[float, float]:
        """
        Convert pixel coordinates directly to piezo voltage values.
        
        This is a convenience method that combines pixel_to_xy() and xy_to_voltage()
        into a single call, providing a direct conversion from scan grid indices to
        the actual voltages needed to position the AFM piezo scanner.
        
        Parameters
        ----------
        pixel_coordinates : Tuple[int, int]
            Pixel coordinates (x, y) where x is the column index and y is the row index.
            Both indices should be zero-based (starting from 0).
            - Pixel (0, 0) corresponds to the bottom-left corner
            - Pixel (ScanPoints-1, ScanLines-1) corresponds to the top-right corner
        
        Returns
        -------
        Tuple[float, float]
            Piezo voltage values (XLocV, YLocV) in volts.
            - XLocV: X-axis piezo voltage
            - YLocV: Y-axis piezo voltage
        
        Notes
        -----
        **Execution Sequence:**
        
        This method performs a two-step coordinate transformation:
        
        1. **Pixel to Normalized Coordinates** (via pixel_to_xy)
        - Calls pixel_to_xy(pixel_coordinates)
        - Converts pixel indices to normalized coordinates in range [-1, 1]
        - Retrieves ScanPoints and ScanLines from get_MasterVariables()
        
        2. **Normalized Coordinates to Voltage** (via xy_to_voltage)
        - Calls xy_to_voltage(xy_coordinates)
        - Applies scan size, aspect ratios, rotation, offsets
        - Retrieves calibration constants from get_MasterVariables()
        - Returns final piezo voltages
        
        **Method Call Hierarchy:**
    ```
        pixel_to_voltage()
        ├── pixel_to_xy()
        │   └── get_MasterVariables()  # Reads: ScanPoints, ScanLines
        └── xy_to_voltage()
            └── get_MasterVariables()  # Reads: ScanSize, FastRatio, SlowRatio,
                                        #        ScanAngle, XOffset, YOffset,
                                        #        XLVDTSens, YLVDTSens, XLVDTOffset, YLVDTOffset
    ```
        
        **Called By:**
        - move_tip() : Uses this method to convert target pixel to voltage before motion
        
        This method is particularly useful when you need voltage values without
        executing a tip movement, such as for planning trajectories or calculating
        expected positions.
        
        Examples
        --------
        >>> pc = PyCypher()
        >>> # Convert pixel to voltage directly
        >>> x_volt, y_volt = pc.pixel_to_voltage((64, 64))
        >>> print(f"Center pixel voltage: X={x_volt:.4f}V, Y={y_volt:.4f}V")
        
        >>> # For a 128x128 scan, get corner voltages
        >>> x_volt, y_volt = pc.pixel_to_voltage((0, 0))  # Bottom-left
        >>> print(f"Bottom-left: ({x_volt:.4f}V, {y_volt:.4f}V)")
        
        >>> x_volt, y_volt = pc.pixel_to_voltage((127, 127))  # Top-right
        >>> print(f"Top-right: ({x_volt:.4f}V, {y_volt:.4f}V)")
        
        See Also
        --------
        pixel_to_xy : First step - convert pixel to normalized XY coordinates
        xy_to_voltage : Second step - convert XY coordinates to voltage values
        move_tip : High-level method that uses this for tip positioning
        get_MasterVariables : Retrieves calibration data needed for conversion
        """
        # Step 1: Convert pixel → normalized xy
        xy_coordinates = self.pixel_to_xy(pixel_coordinates)
        # Step 2: Convert xy → voltage
        XLocV, YLocV = self.xy_to_voltage(xy_coordinates)

        return XLocV, YLocV

    @log_function
    def initialize_move_tip(self,) -> str:
        """
        Display the current tip location in the AFM software interface.
        
        This method enables the visual indicator showing where the AFM tip is
        currently positioned on the scan image. The indicator appears as a crosshair
        or marker on the displayed scan image, useful for verifying tip position
        before performing measurements or navigating to specific locations.
        
        Returns
        -------
        str
            Confirmation message "DONE--initialize move tip"
        
        Notes
        -----
        **Execution Sequence:**
        
        1. **Enable Force Mode Display** (via ARExecuteControl)
        - Control: "GoForce_1" on "MasterPanel"
        - var_num: 1 (enable)
        - Activates force curve mode display context
        
        2. **Enable XY Spot Indicator** (via ARExecuteControl)
        - Control: "ShowXYSpotCheck_1" on "MasterPanel"
        - var_num: 1 (check the checkbox)
        - Displays visual marker at current tip position
        
        The tip location indicator will remain visible in the AFM software until:
        - Manually disabled via the interface
        - Another operation hides it
        - A new scan is started
        - Igor Pro is restarted

    ```
        **Related Methods:**
        - move_tip() : Often called after initialize_move_tip() to position tip
        
        **Visual Behavior:**
        - Indicator appears as a spot on scan image
        - Updates in real-time as tip moves
        
        Examples
        --------
        >>> pc = PyCypher()
        >>> # initilize tip before moving
        >>> pc.initialize_move_tip()
        'DONE--initialize move tip'
        
        >>> # Common workflow: show, then move
        >>> pc.initialize_move_tip()
        >>> time.sleep(1)  # Give user time to see current position
        >>> pc.move_tip(pixel_coordinates=(64, 64))
        """
        # Enable show tip location
        self.ARExecuteControl("GoForce_1", "MasterPanel", 1, "")
        self.ARExecuteControl("ShowXYSpotCheck_1", "MasterPanel", 1, "")
        return "DONE--initialize move tip"

    @log_function    
    def move_tip(self, coordinates: Tuple[float, float], coordinates_type: str = "pixel", transit_time: float = 0.3) -> str:
        """
        Move the AFM tip to a specific location given in pixel coordinates or direct piezo voltages.
        
        This method moves the tip to the target location either by converting pixel coordinates 
        to piezo voltages, or by directly accepting piezo voltages. The tip movement is performed
        using the td_SetRamp command in Igor Pro.
        
        Parameters
        ----------
        coordinates : Tuple[float, float]
            Target coordinates (x, y), interpreted according to `coordinates_type`:
            
            - If coordinates_type="pixel" (default):
                Integer pixel indices (x, y) where x is the column and y is the row.
                Both indices should be zero-based (starting from 0).
                - Pixel (0, 0) corresponds to the bottom-left corner of scan area
                - Pixel (ScanPoints-1, ScanLines-1) corresponds to the top-right corner
            
            - If input_type="voltage":
                Direct piezo voltages (XLocV, YLocV) in volts.
                Bypasses all coordinate transformations and sends voltages directly
                to the piezo actuators.
        
        transit_time : float, optional
            Duration of the tip movement in seconds. Default is 0.3 s.
            Longer times result in slower, smoother motion; shorter times are faster but
            may cause piezo ringing or overshoot.
        
        input_type : str, optional
            Specifies the coordinate system of `coordinates`. Default is "pixel".
            - "pixel"   : coordinates are (col, row) pixel indices; full conversion pipeline runs.
            - "voltage" : coordinates are (XLocV, YLocV) piezo voltages; conversion is skipped.
        
        Returns
        -------
        str
            Confirmation message "DONE--move tip"
        
        Notes
        -----
        **Execution Sequence (coordinates_type="pixel"):**
        
        1. **Pixel to Voltage Conversion** (via pixel_to_voltage)
        - Calls pixel_to_voltage() which internally performs:
            a. pixel_to_xy() : Pixel indices → Normalized coordinates [-1, 1]
            b. xy_to_voltage() : Normalized coordinates → Piezo voltages
        - Retrieves scan parameters from get_MasterVariables()
        - Accounts for scan size, aspect ratios, rotation, offsets, and calibrations
        
        2. **Execute Ramp Command** (via Execute)
        - Constructs td_SetRamp command string with:
            * X piezo: ramp to XLocV over transit_time
            * Y piezo: ramp to YLocV over transit_time
        - Sends command to Igor Pro via Execute()
        
        3. **Wait for Motion Completion**
        - Blocks execution for transit_time seconds using time.sleep()
        - Ensures tip reaches target before returning
        
        **Execution Sequence (coordinates_type="voltage"):**
        
        1. **Direct Voltage Assignment**
        - Unpacks coordinates directly as (XLocV, YLocV)
        - Skips pixel_to_voltage() and all intermediate transformations
        
        2. **Execute Ramp Command** (same as pixel path)
        
        3. **Wait for Motion Completion** (same as pixel path)
        
        It is better to call show_tip() before move_tip() to visualize tip position.
        
        **Dependencies:**
        - If coordinates_type="pixel": requires valid scan config (ScanPoints, ScanLines, piezo calibrations)
        - If coordinates_type="voltage": only requires an active Igor Pro connection
        
        Warnings
        --------
        - Ensure pixel coordinates are within the valid scan range when using coordinates_type="pixel"
        - Very short transit_times (<0.1 s) may cause piezo instability
        - When using coordinates_type="voltage", the caller is responsible for ensuring voltages are
        within safe operating ranges for the piezo hardware
        
        Examples
        --------
        >>> pc = PyCypher()

        >>> # Move using pixel coordinates (default)
        >>> pc.move_tip(coordinates=(64, 64))
        'DONE--move tip'

        >>> # Move using direct piezo voltages
        >>> pc.move_tip(coordinates=(1.25, -0.80), coordinates_type="voltage")
        'DONE--move tip'

        >>> # Common workflow: show tip, then move
        >>> pc.show_tip()
        >>> pc.move_tip(coordinates=(50, 75), transit_time=0.5)
        >>> # Perform measurement at new location
        """
        if coordinates_type == "pixel":
            XLocV, YLocV = self.pixel_to_voltage(coordinates)
        elif coordinates_type == "voltage":
            XLocV, YLocV = coordinates
        else:
            raise ValueError(f"Invalid coordinates_type '{coordinates_type}'. Must be 'pixel' or 'voltage'.")

        self.Execute(f'td_SetRamp({transit_time:.6f},"$outputXloop.Setpoint",0,{XLocV:.6f},"$outputYloop.Setpoint",0,{YLocV:.6f},"",0,0,"")')

        time.sleep(transit_time)
        return "DONE--move tip"
