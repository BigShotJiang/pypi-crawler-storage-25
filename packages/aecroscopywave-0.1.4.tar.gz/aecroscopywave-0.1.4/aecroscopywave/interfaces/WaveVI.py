# PyVI for Labview interface
# Yongtao Liu

import os
import win32com.client
import time
import numpy as np
from ..logger import log_function
from typing import Optional, List

class PyWaveVI():
    """
    Python interface for LabVIEW-based NI 6124 DAQ control via COM automation.
    
    This class provides programmatic control of a LabVIEW VI that manages
    National Instruments 6124 data acquisition hardware. It enables configuration,
    waveform generation, data acquisition, and result retrieval through a
    COM interface to LabVIEW.
    
    The class handles both analog output (AO) waveform generation and analog
    input (AI) data acquisition, with configurable sampling rates, voltage ranges,
    triggering modes, and channel assignments.
    
    **CRITICAL: Settings vs Parameters**
    -------------------------------------
    
    This class distinguishes between two types of values:
    
    1. **Settings** (Selector Indices): What you configure via set_IO_settings()
       - Most are integer indices that select from predefined options
       - Example: IO_rate = 2 (index) → selects "1 MS/s" option
       - Retrieved via get_IO_settings()
    
    2. **Parameters** (Actual Values): What the hardware actually uses
       - Computed by DAQmx driver from setting indices
       - Example: AO Actual Rate = 1000000.0 (actual samples/second)
       - Retrieved via get_IO_parameters()
    
    **Settings Index Reference:**

    Setting Name      Index  →  Actual Hardware Value
    ─────────────────────────────────────────────────────
    IO_rate           0      →  4,000,000 S/s (4 MS/s)
                      1      →  2,000,000 S/s (2 MS/s)
                      2      →  1,000,000 S/s (1 MS/s)
    
    AI_range          0      →  ±10 V input range
    AO_range          1      →  ±2 V input/output range
                      2      →  ±0.2 V input/output range
    
    AO_amplifier      0      →  1× gain (no amplification)
                      1      →  10× gain
                      2      →  22× gain
    
    trigger_type      0      →  Internal trigger (software)
                      1      →  External trigger (hardware)
    
    AO_num_channels   0      →  1 output channel
    
    IO_trigger_ring   0      →  External trigger
                      1      →  Internal clock-1
    
    AI_ch01/02/03     True   →  Channel enabled
                      False  →  Channel disabled
    
    IO_timeout        value  →  value (seconds) ← ACTUAL VALUE, NOT INDEX!

    Parameters
    ----------
    app_path : str, optional
        Full path to the LabVIEW executable file (.exe).
        Default: r"C:\\Users\\PyScanner_FPGA_6124_01\\PyScanner_FPGA_6124_01.exe"
    client : str, optional
        COM ProgID for the LabVIEW application.
        Default: "PyScanner01.Application"
    pywave_vi : str, optional
        Relative path to the main DAQ VI file.
        Default: r"/6124 DAQ/DAQ_6124_01.vi"
    pyscanner_vi : str or None, optional
        Relative path to the PyScanner VI file or None to skip.
        Default: r"\\FPGA PyScanner\\FPGA_PyScanner_01.vi"

    Attributes
    ----------
    labview : win32com.client.CDispatch
        COM object representing the LabVIEW application instance.
    VI : win32com.client.CDispatch
        Reference to the main DAQ VI (6124 DAQ control VI).
    sVI : win32com.client.CDispatch, optional
        Reference to the secondary PyScanner VI (if loaded).
    
    Method Organization
    -------------------
    
    **Initialization:**
    - __init__() : Launch LabVIEW, establish COM connection, load VIs
    
    **Configuration Management:**
    - get_IO_settings() : Retrieve current setting indices
    - set_IO_settings() : Update setting indices
    - get_IO_parameters() : Get actual hardware parameters (after upload)
    
    **Waveform Management:**
    - set_AO_waveforms() : Upload output waveform to DAQ
    - get_AO_waveforms() : Retrieve current output waveform
    - get_AO_waveforms_duration() : Calculate waveform duration
    - get_AI_waveforms() : Retrieve acquired input data
    
    **DAQ Control (Low-Level):**
    - clear_6124() : Reset DAQ hardware state
    - upload_to_6124() : Transfer configuration to hardware
    - run_6124_IO_10() : Execute I/O operation
    
    **High-Level Workflow:**
    - set_IO_control() : Complete acquisition sequence (recommended)
    
    **Synchronization:**
    - wait_for_vi_flag() : Block until LabVIEW operation completes
    
    Common Workflows
    ----------------
    
    **Workflow: Basic Single Acquisition (with index configuration)**
    python
    # Initialize
    pyvi = PyWaveVI()
    
    # Configure DAQ using INDICES (not actual values!)
    pyvi.set_IO_settings({
        'IO_rate': 2,           # Index 2 → 1 MS/s
        'AI_range': 0,          # Index 0 → ±10V
        'AO_range': 0,          # Index 0 → ±10V
        'AO_num_channels': 0,   # Index 0 → 1 channel
        'AO_amplifier': 0       # Index 0 → 1× gain
    })
    
    # Create and upload waveform
    t = np.linspace(0, 1, 1000)
    waveform = np.sin(2 * np.pi * 10 * t)
    pyvi.set_AO_waveforms(waveform)
    
    # Acquire data (translates indices to actual values during upload)
    data = pyvi.set_IO_control()
    
    # Verify actual parameters
    params = pyvi.get_IO_parameters()
    print(f"Actual rate: {params['AO Actual Rate']} S/s")  # 1000000.0
    print(f"Actual range: ±{params['IO_AI_range_b']} V")   # 10.0
    
    Notes
    -----
    - Only one PyWaveVI instance should exist at a time
    
    Examples
    --------
    >>> # Correct usage with indices
    >>> pyvi = PyWaveVI()
    >>> pyvi.set_IO_settings({'IO_rate': 2})  # Correct, Index 2 → 1 MS/s
    >>> pyvi.set_AO_waveforms(np.sin(np.linspace(0, 2*np.pi, 1000)))
    >>> data = pyvi.set_IO_control()
    
    >>> # Verify actual parameters
    >>> params = pyvi.get_IO_parameters()
    >>> assert params['AO Actual Rate'] == 1000000.0
    
    >>> # Common mistake: using actual values instead of indices
    >>> # pyvi.set_IO_settings({'IO_rate': 1000000})  # WRONG! Too large an index
    >>> # Use: pyvi.set_IO_settings({'IO_rate': 2})   # CORRECT!
    """
    def __init__(self, 
                 app_path: str = r"C:\Users\PyScanner_FPGA_6124_01\PyScanner_FPGA_6124_01.exe",
                 client: str = "PyScanner01.Application",
                 pywave_vi: str = r"\6124 DAQ\DAQ_6124_01.vi",
                 pyscanner_vi: Optional[str] = r"\FPGA PyScanner\FPGA_PyScanner_01.vi") -> None:
        r"""
        Initialize the PyWaveVI class and establish connection to LabVIEW via COM.
        
        This constructor launches the LabVIEW executable, waits for it to initialize,
        establishes a COM connection, and loads the specified VI (Virtual Instrument)
        files for DAQ control and optional PyScanner functionality.
        
        Parameters
        ----------
        app_path : str, optional
            Full path to the LabVIEW executable file (.exe).
            Default: r"C:\Users\PyScanner_FPGA_6124_01\PyScanner_FPGA_6124_01.exe"
            This executable must be a LabVIEW application built with COM automation enabled.
        client : str, optional
            COM ProgID for the LabVIEW application.
            Default: "PyScanner01.Application"
            Must match the server name configured in LabVIEW build specifications.
        pywave_vi : str, optional
            Relative path (from app_path) to the main DAQ VI file.
            Default: r"\6124 DAQ\DAQ_6124_01.vi"
            This VI handles the primary data acquisition operations.
        pyscanner_vi : str or None, optional
            Relative path (from app_path) to the PyScanner VI file.
            Default: r"\FPGA PyScanner\FPGA_PyScanner_01.vi"
            If None, the secondary VI is not loaded.
            This VI typically handles scanning control functionality.
        
        Attributes
        ----------
        labview : win32com.client.CDispatch
            COM object representing the LabVIEW application.
        VI : win32com.client.CDispatch
            Reference to the main DAQ VI (6124 DAQ).
        sVI : win32com.client.CDispatch, optional
            Reference to the secondary PyScanner VI (only if pyscanner_vi is not None).
        
        Examples
        --------
        >>> # Basic initialization with defaults
        >>> pyvi = PyWaveVI()
        # LabVIEW starts, waits for connection, loads both VIs
        
        >>> # Custom paths
        >>> pyvi = PyWaveVI(
        ...     app_path=r"C:\MyLabVIEW\MyApp.exe",
        ...     client="MyApp.Application",
        ...     pywave_vi=r"\VIs\DAQ.vi"
        ... )
        
        >>> # Load only primary VI (no scanner)
        >>> pyvi = PyWaveVI(pyscanner_vi=None)
        # Only self.VI is available, self.sVI does not exist
        
        """
        # Start Labview executable
        os.startfile(app_path)

        # Wait for Labview executable to start, then connect
        while True:
            try:
                self.labview = win32com.client.Dispatch(client)
                self.VI = self.labview.getvireference(app_path + pywave_vi)
                break
            except Exception:
                time.sleep(0.1)

        # Optionally load second VI
        if pyscanner_vi is not None:
            self.sVI = self.labview.getvireference(app_path + pyscanner_vi)

    @log_function    
    def wait_for_vi_flag(self, flag_name: str, poll_interval: float = 0.001, timeout: float = 10.0) -> str:
        """
        Wait until a VI control flag becomes False or until timeout.
        
        This method polls a LabVIEW control (typically a boolean flag) and blocks
        execution until the flag becomes False, indicating the operation has completed.
        This is essential for synchronizing Python execution with LabVIEW operations.
        
        Parameters
        ----------
        flag_name : str
            The name of the LabVIEW control to monitor.
            Must be a valid control name in the currently loaded VI.
            Common flags:
            - 'upload_to_6124': Monitors data upload completion
            - 'clear_6124': Monitors device clear operation
            - 'run_6124_IO_10': Monitors I/O execution
        poll_interval : float, optional
            How often to check the flag status (in seconds).
            Default: 0.001 (1 millisecond)
            Smaller values provide faster response but increase CPU usage.
        timeout : float, optional
            Maximum time to wait (in seconds).
            Default: 10.0
            If the flag doesn't clear within this time, TimeoutError is raised.
        
        Returns
        -------
        str
            Confirmation message: "{flag_name} completed, wait clear"
        
        **Called By:**
        - upload_to_6124() : Waits for upload completion
        - clear_6124() : Waits for clear completion
        - run_6124_IO_10() : Waits for I/O completion (optional)
        - set_IO_control() : Indirectly through above methods
        
        **Calls To:**
        - self.VI.getcontrolvalue() : Reads flag status from LabVIEW
        
        Examples
        --------
        >>> pyvi = PyWaveVI()
        >>> # Wait for upload with default settings
        >>> pyvi.VI.setcontrolvalue('upload_to_6124', True)
        >>> pyvi.wait_for_vi_flag('upload_to_6124')
        'upload_to_6124 completed, wait clear'
        """
        start_time = time.time()
        while self.VI.getcontrolvalue(flag_name):
            if time.time() - start_time > timeout:
                raise TimeoutError(f"Timeout while waiting for '{flag_name}' to complete.")
            time.sleep(poll_interval)
        return f"{flag_name} completed, wait clear"

    @log_function  
    def get_IO_settings(self) -> dict:
        """
        Retrieve the current DAQ I/O setting indices from the LabVIEW VI.
        
        This method reads all configuration setting indices that control the data 
        acquisition hardware behavior. These are selector values (integers/booleans)
        that map to actual hardware parameters. Use get_IO_parameters() to retrieve
        the actual computed hardware values after DAQ initialization.
        
        Returns
        -------
        dict
            Dictionary mapping parameter names (str) to their current setting values.
            
            **Important**: Except for IO_timeout, all other values are selector indices, NOT actual hardware parameters.
            **Complete Mapping Reference:**
        ```
            Setting Index → Actual Parameter
            ─────────────────────────────────
            - 'AO_num_channels': int
            * 0 → 1 AO channel
            
            - 'AI_ch01': bool
            * True → Channel enabled
            * False → Channel disabled
            
            - 'AI_ch02': bool
            * True → Channel enabled
            * False → Channel disabled
            
            - 'AI_ch03': bool
            * True → Channel enabled
            * False → Channel disabled
            
            - 'IO_rate': int (selector index)
            * 0 → 4 MS/s (4,000,000 samples/second)
            * 1 → 2 MS/s (2,000,000 samples/second)
            * 2 → 1 MS/s (1,000,000 samples/second)

            - 'AI_range': int (selector index)
            * 0 → ±10 V input range
            * 1 → ±2 V input range
            * 2 → ±0.2 V input range
            
            - 'AO_range': int (selector index)
            * 0 → ±10 V output range
            * 1 → ±2 V output range
            * 2 → ±0.2 V output range
            
            - 'AO_amplifier': int (selector index)
            * 0 → 1× amplification (unity gain)
            * 1 → 10× amplification
            * 2 → 22× amplification
            
            - 'IO_trigger_ring': int (selector index)
            * 0 → External trigger
            * 1 → Internal clock-1
            
            - 'IO_timeout': float (ACTUAL VALUE in seconds, not a selector)
            * Direct value: e.g., 10.0 means 10 seconds timeout
            * Maximum time to wait for I/O completion
        
        Raises
        ------
        KeyError
            If any expected parameter name does not exist in the VI.
        
        Notes
        -----
        **Setting vs Parameter Distinction:**
        
        - **Settings** (this method): Selector indices/flags for LabVIEW controls
        * Example: IO_rate = 0 (just an index)
        * These are what you SET in LabVIEW controls
        
        - **Parameters** (get_IO_parameters): Actual hardware values after configuration
        * Example: AO Actual Rate = 4000000.0 (actual samples/second)
        * These are what the hardware ACTUALLY uses
        
        **Why Use Indices?**
        LabVIEW uses enumerated controls (dropdowns/selectors) for user-friendly
        configuration. Each index corresponds to a specific hardware configuration.
        The DAQ driver translates these indices to actual hardware register values.
        
        **Method Call Hierarchy:**
    ```
        get_IO_settings()
        └── self.VI.getcontrolvalue()  # COM call to LabVIEW (11 calls total)
    ```
        
        **Called By:**
        - set_IO_settings() : Retrieves defaults before merging with updates
        
        **Calls To:**
        - self.VI.getcontrolvalue() : LabVIEW COM interface (called 11 times)
        
        **Related Methods:**
        - set_IO_settings() : Modifies these setting indices
        - get_IO_parameters() : Retrieves actual computed hardware parameters
        
    ```
        
        Examples
        --------
        >>> pyvi = PyWaveVI()
        >>> # Get all current settings (selector indices)
        >>> settings = pyvi.get_IO_settings()
        >>> print(settings)
        {
            'trigger_type': 0,        # Internal trigger
            'AO_num_channels': 0,     # 1 channel
            'IO_rate': 2,             # 1 MS/s
            'AI_range': 0,            # ±10V
            'AO_range': 0,            # ±10V
            'AO_amplifier': 0,        # 1× gain
            'IO_trigger_ring': 1,     # Internal clock-1
            'IO_timeout': 10.0,       # 10 seconds (actual value)
            'AI_ch01': True,          # Enabled
            'AI_ch02': False,         # Disabled
            'AI_ch03': False          # Disabled
        }
        
        >>> # Compare settings vs actual parameters
        >>> settings = pyvi.get_IO_settings()
        >>> params = pyvi.get_IO_parameters()
        >>> print(f"Setting: IO_rate = {settings['IO_rate']} (index)")
        >>> print(f"Actual:  AO Actual Rate = {params['AO Actual Rate']} S/s")
        Setting: IO_rate = 2 (index)
        Actual:  AO Actual Rate = 1000000.0 S/s
        
        See Also
        --------
        set_IO_settings : Modify these setting indices
        get_IO_parameters : Get actual hardware parameters (not indices)
        set_IO_control : High-level DAQ control workflow
        """
        # Define parameter names 
        parameter_name_list = ["trigger_type", "AO_num_channels", "IO_rate", "AI_range", "AO_range", "AO_amplifier", "IO_trigger_ring", "IO_timeout",
                            "AI_ch01", "AI_ch02", "AI_ch03"]

        # Create a dictionary mapping parameter names to their setting indices
        daq_settings_dict = {parameter_name_list[i]: self.VI.getcontrolvalue(parameter_name_list[i]) for i in range(len(parameter_name_list))}
        
        return daq_settings_dict

    @log_function      
    def get_IO_parameters (self) -> dict:
        """
        Retrieve the actual computed DAQ I/O parameters from the LabVIEW VI.
        
        This method reads the ACTUAL hardware parameters after DAQ initialization,
        not the selector indices. These values represent what the hardware is actually
        configured to use, as computed by the NI-DAQmx driver from the setting indices.
        
        Returns
        -------
        dict
            Dictionary mapping parameter names (str) to their actual hardware values.
            
            **Important**: Values are ACTUAL hardware parameters, not selector indices.

            - 'IO_rate_b': float
            * Actual I/O sample rate (samples/second)
            * Example: 1000000.0 for 1 MS/s
            
            - 'AI Actual Rate': float
            * Actual analog input sample rate (samples/second)
            * Confirmed rate after DAQ initialization
            
            - 'AO Actual Rate': float
            * Actual analog output sample rate (samples/second)
            * Confirmed rate after DAQ initialization
            * Should match AI rate for synchronized operation
            
            - 'IO_AO_range_b': float
            * Actual analog output voltage range (volts, peak value)
            * Corresponds to setting index: 0→10.0, 1→2.0, 2→0.2
            
            - 'IO_AI_range_b': float
            * Actual analog input voltage range (volts, peak value)
            * Corresponds to setting index: 0→10.0, 1→2.0, 2→0.2

            - 'IO_AO_routing_b': float
            * Actual analog output routing/terminal configuration
            
            - 'AO_amp_b': float
            * Actual amplifier gain value
            * Example: 1.0 for unity gain, 10.0 for 10×, 22.0 for 22×
            * Corresponds to setting index: 0→1.0, 1→10.0, 2→22.0
            
            - 'samples per channel': int
            * Number of samples per channel configured for acquisition
            * Equals length of waveform / number of channels
            * Determines acquisition duration: duration = samples / rate
        
        
        Notes
        -----
        **Parameters vs Settings:**
        
        - **Settings** (get_IO_settings): User-selected indices
        * Example: IO_rate = 2 (just an index meaning "1 MS/s")
        * What you configure in LabVIEW controls
        
        - **Parameters** (this method): Actual hardware values
        * Example: AO Actual Rate = 1000000.0 (actual S/s used by hardware)
        * What the DAQ hardware actually operates at
        * Computed by NI-DAQmx driver during initialization
        
        **Method Call Hierarchy:**
    ```
        get_IO_parameters()
        └── [For each parameter in list]
            └── self.VI.getcontrolvalue()  # COM call to LabVIEW (8 calls total)
    ```
        
        **Called By:**
        - get_AO_waveforms_duration() : Uses 'AO Actual Rate' for duration calculation
        
        **Calls To:**
        - self.VI.getcontrolvalue() : LabVIEW COM interface (called 8 times)
        
        **Related Methods:**
        - get_IO_settings() : Get selector indices (what user configures)
        - set_IO_settings() : Set selector indices
        - upload_to_6124() : Initializes DAQ and computes these parameters
        
        Examples
        --------
        >>> pyvi = PyWaveVI()
        >>> # Must initialize DAQ first
        >>> pyvi.set_IO_settings({'IO_rate': 2, 'AI_range': 0})
        >>> pyvi.set_AO_waveforms(np.zeros(1000))
        >>> pyvi.clear_6124()    
        >>> pyvi.upload_to_6124()

        >>> # Now get actual parameters
        >>> params = pyvi.get_IO_parameters()
        >>> print(params)
        {
            'IO_rate_b': 1000000.0,
            'IO_AO_range_b': 10.0,
            'IO_AO_routing_b': 'Dev1/ao0',
            'AO_amp_b': 1.0,
            'IO_AI_range_b': 10.0,
            'AI Actual Rate': 1000000.0,
            'AO Actual Rate': 1000000.0,
            'samples per channel': 1000
        }
        
        >>> # Compare setting vs actual
        >>> settings = pyvi.get_IO_settings()
        >>> params = pyvi.get_IO_parameters()
        >>> 
        >>> print("Sample Rate:")
        >>> print(f"  Setting index: {settings['IO_rate']}")
        >>> print(f"  Actual rate: {params['AO Actual Rate']} S/s")
        Sample Rate:
        Setting index: 2
        Actual rate: 1000000.0 S/s
        
        >>> # Calculate acquisition duration
        >>> samples = params['samples per channel']
        >>> rate = params['AI Actual Rate']
        >>> duration = samples / rate
        >>> print(f"\nAcquisition duration: {duration:.6f} seconds")
        Acquisition duration: 0.001000 seconds
        
        >>> # Verify synchronization
        >>> if params['AI Actual Rate'] == params['AO Actual Rate']:
        ...     print("AI and AO synchronized")
        ... else:
        ...     print("Warning: AI/AO rate mismatch!")
        AI and AO synchronized
        
        >>> # Full configuration verification workflow
        >>> pyvi.set_IO_settings({'IO_rate': 0, 'AO_amplifier': 1})
        >>> pyvi.set_AO_waveforms(np.sin(np.linspace(0, 2*np.pi, 10000)))
        >>> pyvi.clear_6124()       
        >>> pyvi.upload_to_6124()
        >>> 
        >>> params = pyvi.get_IO_parameters()
        >>> assert params['AO Actual Rate'] == 4000000.0, "Unexpected sample rate!"
        >>> assert params['AO_amp_b'] == 10.0, "Amplifier not set correctly!"
        >>> print("Configuration verified!")
        
        See Also
        --------
        get_IO_settings : Get setting indices (what user configures)
        set_IO_settings : Set setting indices
        upload_to_6124 : Initializes DAQ and computes these parameters
        get_AO_waveforms_duration : Uses 'AO Actual Rate' from this method
        """
        # Define parameter names corresponding to the values
        parameter_name_list = ["IO_rate_b", "IO_AO_range_b", "IO_AO_routing_b", "AO_amp_b", "IO_AI_range_b", "AI Actual Rate",
                            "AO Actual Rate", "samples per channel"]

        # Create a dictionary mapping parameter names to their values
        io_parameters_dict = {parameter_name_list[i]: self.VI.getcontrolvalue(parameter_name_list[i]) for i in range(len(parameter_name_list))}
        
        return io_parameters_dict

    @log_function  
    def set_IO_settings (self, IO_setting_dict: Optional[dict] = None) -> str:
        """
        Set DAQ I/O configuration using setting indices.
        
        This method updates DAQ configuration by providing selector indices that
        map to specific hardware parameters. The indices are used by LabVIEW and
        the NI-DAQ driver to configure the actual hardware values.
        
        Parameters
        ----------
        IO_setting_dict : dict, optional
            Dictionary containing setting indices/values to update.
            Default: None (equivalent to empty dict - no changes made)
            
            Keys must match parameter names from get_IO_settings().
            Values must be appropriate selector indices or values for each parameter.
            
            **IMPORTANT: Except for IO_timout, other values are INDICES, not actual parameters!**
            
            **Sample Rate Selection:**
            - 'IO_rate': int (selector index)
            * 0 → 4 MS/s (4,000,000 samples/second)
            * 1 → 2 MS/s (2,000,000 samples/second)
            * 2 → 1 MS/s (1,000,000 samples/second)
            
            **Voltage Range Selection:**
            - 'AI_range': int (selector index)
            * 0 → ±10 V input range
            * 1 → ±2 V input range
            * 2 → ±0.2 V input range (for small signals)
            
            - 'AO_range': int (selector index)
            * 0 → ±10 V output range
            * 1 → ±2 V output range
            * 2 → ±0.2 V output range
            
            **Amplifier Selection:**
            - 'AO_amplifier': int (selector index)
            * 0 → 1× amplification (unity gain, no amplification)
            * 1 → 10× amplification
            * 2 → 22× amplification (for small signals)
            
            **Channel Configuration:**
            - 'AO_num_channels': int (selector index)
            * 0 → 1 AO channel
            
            - 'AI_ch01': bool (enable/disable flag)
            * True → Enable analog input channel 1
            * False → Disable analog input channel 1
            
            - 'AI_ch02': bool (enable/disable flag)
            * True → Enable analog input channel 2
            * False → Disable analog input channel 2
            
            - 'AI_ch03': bool (enable/disable flag)
            * True → Enable analog input channel 3
            * False → Disable analog input channel 3
            
            **Trigger Configuration:**
            - 'trigger_type': int (selector index)
            * 0 → Internal trigger (software-triggered)
            * 1 → External trigger (hardware-triggered)
            
            - 'IO_trigger_ring': int (selector index)
            * 0 → External trigger
            * 1 → Internal clock-1
            
            **Timeout (ACTUAL VALUE):**
            - 'IO_timeout': float (ACTUAL value in seconds, NOT an index)
            * Direct value: e.g., 10.0 means 10 seconds timeout
            * Maximum time to wait for I/O completion
            * This is the ONLY setting that is not an index
            
            Unknown keys are silently ignored (no error raised).
        
        Returns
        -------
        str
            Confirmation message "DONE--set_IO_settings"
        
        **Execution Sequence:**
        1. **Handle None Input**
        - If IO_setting_dict is None, creates empty dict
        - No changes will be made (all current settings reapplied)
        
        2. **Get Current Settings** (via get_IO_settings)
        - Retrieves all current DAQ setting indices
        - Creates baseline configuration dictionary
        - Makes 11 COM calls to read current values
        
        3. **Merge with Updates**
        - Calls io_setting.update(IO_setting_dict)
        - Provided settings override defaults
        - Unspecified parameters keep current values
        
        4. **Apply All Settings**
        - Iterates through merged dictionary
        - For each key-value pair:
            * Calls self.VI.setcontrolvalue(key, value)
            * Updates LabVIEW VI control
            * LabVIEW validates index values
            * COM call may trigger validation errors
        
        5. **Return Confirmation**
        - All settings applied successfully
        - Returns confirmation string
        
        **Method Call Hierarchy:**
    ```
        set_IO_settings()
        ├── get_IO_settings()                    # Get current settings
        │   └── self.VI.getcontrolvalue()       # 11 calls
        ├── dict.update()                        # Merge settings
        └── [For each parameter]
            └── self.VI.setcontrolvalue()       # COM call to LabVIEW (11 calls total)
    ```
        
        **Called By:**
        - set_IO_control() : Often called before I/O operations
        
        **Calls To:**
        - get_IO_settings() : Retrieves current baseline setting indices
        
        **Index-to-Parameter Translation:**
        The translation from indices to actual values happens in two stages:
        1. LabVIEW: Index selects from enumerated list
        2. DAQmx: Configures hardware with corresponding value
        3. Result visible in get_IO_parameters() after upload
        
        **Complete Reference Table:**
    ```
        Parameter         Index  →  Actual Value
        ────────────────────────────────────────
        IO_rate:          0      →  4,000,000 S/s
                          1      →  2,000,000 S/s
                          2      →  1,000,000 S/s
        
        AI_range:         0      →  ±10 V
        AO_range:         1      →  ±2 V
                          2      →  ±0.2 V
        
        AO_amplifier:     0      →  1× gain
                          1      →  10× gain
                          2      →  22× gain
        
        trigger_type:     0      →  Internal
                          1      →  External
        
        AO_num_channels:  0      →  1 channel

        IO_trigger_ring:  0      →  External trigger
                          1      →  Internal clock-1
        
        AI_ch01/02/03:    True   →  Enabled
                          False  →  Disabled
        
        IO_timeout:       value  →  value (seconds)
                            ↑ ONLY ACTUAL VALUE, NOT INDEX
    ```
        
        Examples
        --------
        >>> pyvi = PyWaveVI()
        >>> # Set sample rate to 1 MS/s (index 2, NOT 1000000)
        >>> pyvi.set_IO_settings({'IO_rate': 2})  # Correct: index 2
        'DONE--set_IO_settings'
        >>> # NOT: pyvi.set_IO_settings({'IO_rate': 1000000})  # Wrong!
        
        >>> # Configure for high-speed, high-voltage acquisition
        >>> settings = {
        ...     'IO_rate': 0,           # 4 MS/s (fastest)
        ...     'AI_range': 0,          # ±10V (largest range)
        ...     'AO_range': 0,          # ±10V output
        ...     'AO_amplifier': 0,      # 1× (no amplification)
        ...     'AO_num_channels': 0,   # 1 channel
        ...     'AI_ch01': True,        # Enable input channel 1
        ...     'trigger_type': 0       # Internal trigger
        ... }
        >>> pyvi.set_IO_settings(settings)
        'DONE--set_IO_settings'
        
        >>> # Verify settings were applied
        >>> settings = pyvi.get_IO_settings()
        >>> print(f"Sample rate index: {settings['IO_rate']}")  # Should be 2
        >>> print(f"AI range index: {settings['AI_range']}")    # Should be 2
        Sample rate index: 2
        AI range index: 2
        
        >>> # Then verify actual parameters after upload
        >>> pyvi.set_AO_waveforms(np.zeros(1000))
        >>> pyvi.clear_6124()
        >>> pyvi.upload_to_6124()
        >>> params = pyvi.get_IO_parameters()
        >>> print(f"Actual sample rate: {params['AO Actual Rate']} S/s")
        >>> print(f"Actual AI range: ±{params['IO_AI_range_b']} V")
        >>> print(f"Actual amplifier: {params['AO_amp_b']}×")
        Actual sample rate: 1000000.0 S/s
        Actual AI range: ±0.2 V
        Actual amplifier: 22.0×
        
        See Also
        --------
        get_IO_settings : Retrieve current setting indices
        get_IO_parameters : Get actual hardware parameters (after upload)
        upload_to_6124 : Initializes DAQ and translates indices to actual values
        set_IO_control : High-level workflow that may call this method
        """
        # Handle None case explicitly
        if IO_setting_dict is None:
            IO_setting_dict = {}

        # get default settings
        io_setting = self.get_IO_settings()
        io_setting.update(IO_setting_dict)
        
        # set io parameters
        for key in io_setting.keys():
            self.VI.setcontrolvalue(key, io_setting[key])
        return "DONE--set_IO_settings"

    @log_function  
    def set_AO_waveforms(self, waveform: List[float], zero_tail: bool = False, timeout: float = 5.0) -> str :
        """
        Set the analog output waveform to be generated by the DAQ.
        
        This method uploads a waveform array to the LabVIEW VI, which will be output
        on the configured analog output channels during I/O operations. The method
        blocks until upload verification confirms the waveform was transferred correctly.
        
        Parameters
        ----------
        waveform : List[float]
            List or array containing the output waveform samples.
            
        zero_tail : bool, optional
            If True, appends a final zero sample to avoid residual output bias.
            Default: False
            
            **Use Cases:**
            - True: Ensures output returns to zero after waveform completes
            - False: Output maintains last waveform value after completion
            
            Setting to True adds one additional sample to the waveform.
        
        timeout : float, optional
            Maximum time (seconds) to wait for upload verification.
            Default: 5.0
            
            Increase for very large waveforms (>1M samples) or slow COM connections.
            Typical upload speeds: 10,000-100,000 samples/second.
        
        Returns
        -------
        str
            Confirmation message "DONE--set_AO_waveforms"
        
        Notes
        -----
        
        **Method Call Hierarchy:**
    ```
        set_AO_waveforms()
        ├── waveform.append(0)                   # If zero_tail=True
        ├── self.VI.setcontrolvalue()           # Upload waveform (COM call)
        └── [Verification Loop with timeout]
            ├── time.time()                     # Check elapsed time
            ├── get_AO_waveforms()              # Read back waveform
            │   └── self.VI.getcontrolvalue()  # COM call
            ├── np.array_equal()                # Compare arrays
            ├── time.sleep(0.1)                 # Wait between checks
            └── [Raise TimeoutError if exceeded]
    ```
        
        **Called By:**
        - set_IO_control() : Typically called before this method
        
        **Calls To:**
        - get_AO_waveforms() : For upload verification
        - self.VI.setcontrolvalue() : To upload waveform
        
        **Verification Logic:**
        The verification loop ensures data integrity by:
        1. Reading back the uploaded waveform
        2. Comparing element-by-element with original
        3. Retrying if mismatch (handles COM delays)
        4. Blocking until perfect match or timeout
        This guarantees the waveform in LabVIEW matches what you provided.
        
        Examples
        --------
        >>> pyvi = PyWaveVI()
        >>> # Simple sine wave as list
        >>> t = np.linspace(0, 1, 1000)
        >>> waveform = (np.sin(2 * np.pi * 10 * t)).tolist()
        >>> pyvi.set_AO_waveforms(waveform)
        'DONE--set_AO_waveforms'
        
        >>> # With zero tail (returns to zero after completion)
        >>> waveform = [0.5, 1.0, 1.5, 1.0, 0.5]
        >>> pyvi.set_AO_waveforms(waveform, zero_tail=True)
        'DONE--set_AO_waveforms'
        >>> # Final waveform: [0.5, 1.0, 1.5, 1.0, 0.5, 0.0]
        """

        if zero_tail:
            waveform.append(0.0)  # Append zero to list
        
        # Upload waveform to VI
        self.VI.setcontrolvalue('AO_waveforms', waveform)
        
        # Check if upload is completed with timeout
        start_time = time.time()
        while not np.array_equal(self.get_AO_waveforms(), np.asarray(waveform)):
            if time.time() - start_time > timeout:
                raise TimeoutError(f"Timeout waiting for waveform upload verification after {timeout} seconds.")
            time.sleep(0.1)
        
        return "DONE--set_AO_waveforms"

    @log_function  
    def get_AO_waveforms(self, ) -> List[float]:
        """
        Retrieve the current analog output waveform from the LabVIEW VI.
        
        This method reads back the waveform currently stored in the VI's memory,
        which may have been uploaded via set_AO_waveforms().
        
        Returns
        -------
        List[float]
            The analog output waveform as a Python list of floats.
        
        **Called By:**
        - set_AO_waveforms() : For upload verification (in verification loop)
        - get_AO_waveforms_duration() : To calculate waveform duration
        
        **Calls To:**
        - self.VI.getcontrolvalue() : LabVIEW COM interface
        
        **Use Cases:**
        1. Verify waveform upload after set_AO_waveforms()
        2. Inspect waveform before running acquisition
        3. Debug waveform issues
        4. Calculate waveform properties (duration, amplitude, etc.)
        
        Examples
        --------
        >>> pyvi = PyWaveVI()
        >>> # Set a waveform
        >>> original = [1.0, 2.0, 3.0, 2.0, 1.0]
        >>> pyvi.set_AO_waveforms(original)
        
        >>> # Retrieve it back
        >>> retrieved = pyvi.get_AO_waveforms()
        >>> print(retrieved)
        [1.0, 2.0, 3.0, 2.0, 1.0]
        """
        waveform = self.VI.getcontrolvalue('AO_waveforms')
        return waveform    

    @log_function  
    def get_AO_waveforms_duration(self,) -> float:
        """
        Calculate the duration of the current analog output waveform.
        
        This method computes the time required to output the complete waveform
        based on its length and the actual sample rate configured in the DAQ.
        
        Returns
        -------
        float
            Duration of the waveform in seconds.
            
            Formula: duration = len(waveform) / IO_rate
        
        Notes
        -----
        **Method Call Hierarchy:**
    ```
        get_AO_waveforms_duration()
        ├── get_AO_waveforms()              # Get waveform length
        │   └── self.VI.getcontrolvalue()  # COM call
        ├── get_IO_parameters()             # Get actual sample rate
        │   └── self.VI.getcontrolvalue()  # Multiple COM calls
        └── len() / rate calculation
    ```
        
        **Calls To:**
        - get_AO_waveforms() : Retrieves waveform for length calculation
        - get_IO_parameters() : Retrieves actual sample rate
 
        
        **Use Cases:**
        - Calculate timeout for run_6124_IO_10()
        - Estimate total acquisition time
        - Synchronize with external events
        - Verify waveform timing requirements
        
        Examples
        --------
        >>> pyvi = PyWaveVI()
        >>> # Configure DAQ
        >>> pyvi.set_IO_settings({'IO_rate': 2})  # Index 2 → 1 MS/s
        >>> 
        >>> # Upload waveform
        >>> waveform = [1.0] * 10000  # 10000 samples
        >>> pyvi.set_AO_waveforms(waveform)
        >>> pyvi.clear_6124() 
        >>> pyvi.upload_to_6124()  # Must upload for accurate duration!
        >>> 
        >>> # Calculate duration
        >>> duration = pyvi.get_AO_waveforms_duration()
        """
        duration = len(self.get_AO_waveforms())/self.get_IO_parameters( )['AO Actual Rate']
        return duration    

    @log_function  
    def get_AI_waveforms(self) -> List[float]:
        """
        Retrieve the acquired analog input waveforms from the LabVIEW VI.
        
        This method reads back the data acquired during the most recent I/O operation.
        Data is returned as a flat list, with samples from multiple channels interleaved
        if more than one AI channel is enabled.
        
        Returns
        -------
        List[float]
            The analog input waveform data as a Python list of floats.
            Returns [] (empty list) if no acquisition performed yet or stale data from previous acquisition
        
        Notes
        **Called By:**
        - set_IO_control() : Retrieves data after I/O execution (if fetch_result=True)
        
        **Calls To:**
        - self.VI.getcontrolvalue() : LabVIEW COM interface
        
        Examples
        --------
        >>> pyvi = PyWaveVI()
        >>> # Configure and acquire
        >>> pyvi.set_IO_settings({'IO_rate': 2, 'AI_ch01': True})
        >>> pyvi.set_AO_waveforms([1.0] * 1000)
        >>> data = pyvi.set_IO_control()  # Calls this method internally

        >>> # Manual retrieval
        >>> pyvi.run_6124_IO_10(timeout=10.0)
        >>> data = pyvi.get_AI_waveforms()
        """
        waveform = self.VI.getcontrolvalue('AI_waveforms')

        return waveform

    @log_function  
    def upload_to_6124(self, timeout: float = 10.0) -> str:
        """
        Upload waveform and configuration data to the 6124 DAQ device.
        
        This method transfers the configured waveform and all DAQ settings to the
        hardware, initializing the NI-DAQ tasks and preparing for acquisition.
        This is when setting indices are translated to actual hardware parameters.
        
        Parameters
        ----------
        timeout : float, optional
            Maximum time (seconds) to wait for upload completion.
            Default: 10.0
            Increase for very large waveforms.
        
        Returns
        -------
        str
            Confirmation message "DONE--upload_to_6124"
        
        Notes
        -----       
        **Called By:**
        - set_IO_control() : As part of full acquisition sequence (if upload=True)
        
        **Calls To:**
        - wait_for_vi_flag() : Waits for upload to complete
        - self.VI.setcontrolvalue() : Triggers upload operation
        
        Examples
        --------
        >>> pyvi = PyWaveVI()
        >>> # Complete configuration and upload workflow
        >>> pyvi.set_IO_settings({'IO_rate': 2, 'AI_range': 0})
        >>> pyvi.set_AO_waveforms([1.0] * 10000)
        >>> pyvi.clear_6124()
        >>> pyvi.upload_to_6124()
        'DONE--upload_to_6124'
        """
        self.VI.setcontrolvalue('upload_to_6124', True)
        self.wait_for_vi_flag('upload_to_6124', timeout=timeout)
        return "DONE--upload_to_6124"

    @log_function  
    def clear_6124(self, timeout: float = 10.0) -> str:
        """
        Clear the 6124 DAQ device state and reset hardware.
        
        This method clears hardware buffers and resets the DAQ device to a clean state. Recommended before each new
        acquisition or upload.
        
        Parameters
        ----------
        timeout : float, optional
            Maximum time (seconds) to wait for clear completion.
            Default: 10.0
            Usually completes in <0.5 seconds.
        
        Returns
        -------
        str
            Confirmation message "DONE--clear_6124"
        
        **Called By:**
        - set_IO_control() : First step in acquisition sequence (if clear=True)
        
        **Calls To:**
        - wait_for_vi_flag() : Waits for clear to complete
        - self.VI.setcontrolvalue() : Triggers clear operation
        
        **When to Use:**
        - **Before Upload:** Always clear before uploading a waveform
        - **After Errors:** Required to recover from failures
        - **Configuration Changes:** Ensures clean state for new settings
        - **Not Needed:** When doing rapid repeated acquisitions with same config
        
        Examples
        --------
        >>> pyvi = PyWaveVI()    
        >>> # Full workflow with clear
        >>> pyvi.set_IO_settings({'IO_rate': 2})
        >>> pyvi.set_AO_waveforms([1.0] * 1000)
        >>> pyvi.clear_6124()
        >>> pyvi.upload_to_6124()
        >>> pyvi.run_6124_IO_10()
        
        >>> # Clear after error
        >>> try:
        ...     data = pyvi.set_IO_control()
        ... except Exception as e:
        ...     print(f"Error: {e}")
        ...     pyvi.clear_6124()  # Reset hardware
        ...     # Retry with corrected settings
        """
        self.VI.setcontrolvalue('clear_6124', True)
        self.wait_for_vi_flag('clear_6124', timeout=timeout)
        return "DONE--clear_6124"

    @log_function  
    def run_6124_IO_10(self, timeout: Optional[float] = None) -> str:
        """
        Execute the DAQ I/O operation (generate outputs).
        
        This method starts the configured DAQ tasks, outputs the waveform on AO
        channels. This is the actual data acquisition step.
        
        Parameters
        ----------
        timeout : float
        Maximum time (seconds) to wait for I/O completion.
        Default: None
        Recommended Values: timeout = waveform_duration + margin (for internal trigger)
                            timeout = None for external trigger
        
        Returns
        -------
        str
            Confirmation message "DONE--run_6124_IO_10"
        
        Notes
        -----
        **Execution Sequence:**
        - Calls self.VI.setcontrolvalue('run_6124_IO_10', True) to set LabVIEW flag to start I/O operation
        - Starts AO task (begins outputting waveform), simultaneously starts AI task (begins acquiring samples)
        - Wait for completion via wait_for_vi_flag
        - Return Confirmation
        - Data available via get_AI_waveforms() after completion
        
        **Called By:**
        - set_IO_control() : As part of full acquisition sequence (if do_IO=True)
        
        **Calls To:**
        - wait_for_vi_flag() : Waits for I/O completion (if timeout not None)
        - self.VI.setcontrolvalue() : Triggers I/O operation
        
        Examples
        --------
        >>> pyvi = PyWaveVI()
        >>> # Complete workflow with blocking I/O
        >>> pyvi.set_IO_settings({'IO_rate': 2})
        >>> pyvi.set_AO_waveforms([1.0] * 10000)
        >>> pyvi.clear_6124()
        >>> pyvi.upload_to_6124()
        >>> pyvi.run_6124_IO_10(timeout=timeout)
        'DONE--run_6124_IO_10'
        >>> 
        >>> # Data is ready
        >>> data = pyvi.get_AI_waveforms()
        >>> print(f"Acquired {len(data)} samples")
        Acquired 10000 samples
 
        """
        self.VI.setcontrolvalue('run_6124_IO_10', True)
        if timeout is None:
            return "DONE--skip wait for completion"
        else:
            self.wait_for_vi_flag('run_6124_IO_10', timeout=timeout)
            return "DONE--run_6124_IO_10"

    @log_function  
    def set_IO_control(self, clear: bool = True, upload: bool = True, do_IO: bool = True,
                       fetch_result: bool = True, timeout: float = 10.0) -> List[float]:
        """
        Execute a complete DAQ I/O control sequence on the 6124 device.
        
        This is the primary high-level method for data acquisition operations. It
        orchestrates the full workflow: clearing state, uploading configuration,
        executing I/O, and retrieving results. This method provides flexible control
        over which steps to execute while maintaining proper sequencing.
        
        Parameters
        ----------
        clear : bool, optional
            If True, clear the 6124 device state before upload.
            Default: True
            Recommended to ensure clean state before uploading a new waveform.
        upload : bool, optional
            If True, upload waveform configuration to the 6124 DAQ hardware.
            Default: True
            Requires waveform to be set via set_AO_waveforms() first.
        do_IO : bool, optional
            If True, execute the I/O operation (generate outputs, acquire inputs).
            Default: True
            This is the actual data acquisition step.
        fetch_result : bool, optional
            If True, retrieve and return acquired AI waveforms after I/O.
            Default: True
            Returns waveform data; if False, returns confirmation string.
        timeout : float, optional
            Maximum time (seconds) to wait for each operation to complete.
            Default: 10.0
            Applied to clear, upload, and do_IO steps independently.
        
        Returns
        -------
        List[float] or str
            - If fetch_result=True: Returns AI waveform data as list of floats
            Format depends on number of AI channels configured
            - If fetch_result=False: Returns "DONE--set_IO_control"
        
        Notes
        -----
        **Execution Sequence:**
        
        1. **Clear DAQ State** (via clear_6124, conditional)
        - If clear=True:
            * Calls clear_6124(timeout)
            * Waits up to timeout seconds for completion
        
        2. **Upload Configuration** (via upload_to_6124, conditional)
        - If upload=True:
            * Calls upload_to_6124(timeout)
            * Transfers waveform and settings to DAQ hardware
            * Waits up to timeout seconds for completion
        
        3. **Execute I/O Operation** (via run_6124_IO_10, conditional)
        - If do_IO=True:
            * Calls run_6124_IO_10(timeout)
            * Starts DAQ acquisition
            * Outputs AO waveform
            * Acquires AI samples
            * Waits up to timeout seconds for completion
        
        4. **Fetch Results** (via get_AI_waveforms, conditional)
        - If fetch_result=True:
            * Calls get_AI_waveforms()
            * Retrieves acquired data from VI
            * Returns as list of floats
        - If fetch_result=False:
            * Returns confirmation string only
        
        **Method Call Hierarchy:**
    ```
        set_IO_control()
        ├── clear_6124()                         # If clear=True
        │   ├── self.VI.setcontrolvalue()       # Set flag
        │   └── wait_for_vi_flag()              # Wait for completion
        │       └── self.VI.getcontrolvalue()  # Poll flag
        ├── upload_to_6124()                     # If upload=True
        │   ├── self.VI.setcontrolvalue()       # Set flag
        │   └── wait_for_vi_flag()              # Wait for completion
        │       └── self.VI.getcontrolvalue()  # Poll flag
        ├── run_6124_IO_10()                     # If do_IO=True
        │   ├── self.VI.setcontrolvalue()       # Set flag
        │   └── wait_for_vi_flag()              # Wait for completion (conditional)
        │       └── self.VI.getcontrolvalue()  # Poll flag
        └── get_AI_waveforms()                   # If fetch_result=True
            └── self.VI.getcontrolvalue()       # Get AI data
    ```
        
        **Calls To:**
        - clear_6124() : Resets DAQ hardware
        - upload_to_6124() : Configures DAQ hardware
        - run_6124_IO_10() : Executes acquisition
        - get_AI_waveforms() : Retrieves data
        
        **Common Usage Patterns:**
        
        1. **Full Acquisition (default)**:
    ```
        data = pyvi.set_IO_control()  # All steps, return data
    ```
        
        2. **Setup Only (no acquisition)**:
    ```
        pyvi.set_IO_control(do_IO=False, fetch_result=False)  # Configure only
    ```
        
        3. **Acquisition Without Clear and Upload** (faster repeated acquisitions):
    ```
        for i in range(100):
            data = pyvi.set_IO_control(clear=False, upload=False)  # Reuse config
    ```
        
        **Performance Optimization:**
        - **First acquisition**: Use all flags (clear=True, upload=True)
        - **Repeated acquisitions**: Set clear=False, upload=False
        
        **Data Format:**
        Returned AI waveform format (if fetch_result=True):
        - List: [sample0, sample1, ..., sampleN]
        
        Examples
        --------
        >>> pyvi = PyWaveVI()
        >>> # Complete workflow: configure, acquire, return data
        >>> waveform = np.sin(2 * np.pi * 10 * np.linspace(0, 1, 1000))
        >>> pyvi.set_AO_waveforms(waveform)
        >>> data = pyvi.set_IO_control()
        >>> print(f"Acquired {len(data)} samples")
        Acquired 1000 samples

        """
        if clear:
            self.clear_6124(timeout=timeout)

        if upload:
            self.upload_to_6124(timeout=timeout)

        if do_IO:
            self.run_6124_IO_10(timeout=timeout)

        if fetch_result:
            return self.get_AI_waveforms()

        return "DONE--set_IO_control"

