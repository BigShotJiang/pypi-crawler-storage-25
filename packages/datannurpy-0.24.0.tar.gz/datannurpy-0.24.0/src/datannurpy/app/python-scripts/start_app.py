#!/usr/bin/env python3
"""
Start datannur app with optional local services
Launches the HTTP server for index.html and available local service scripts in parallel
No external dependencies required - uses only Python standard library
"""

import functools
import os
import subprocess
import sys
import webbrowser
from http.server import SimpleHTTPRequestHandler
from pathlib import Path

from _local_runtime import create_local_http_server, get_local_port

APP_DIR = Path(__file__).parent.parent
DEFAULT_APP_PORT = 61291
LOCAL_SERVICE_SCRIPTS = ("proxy_llm.py", "edit_server.py")


class SafeHTTPHandler(SimpleHTTPRequestHandler):
    """HTTP handler compatible with Windows network drives.

    Fixes os.fstat() OSError on SMB shares with Microsoft Store Python.
    Uses os.stat(path) instead of os.fstat(fd) for Content-Length header.
    """

    def send_head(self):
        path = self.translate_path(self.path)

        if os.path.isdir(path):
            if not self.path.endswith("/"):
                self.send_response(301)
                self.send_header("Location", self.path + "/")
                self.end_headers()
                return None
            for index in ("index.html", "index.htm"):
                index_path = os.path.join(path, index)
                if os.path.isfile(index_path):
                    path = index_path
                    break
            else:
                return self.list_directory(path)

        if not os.path.isfile(path):
            self.send_error(404, "File not found")
            return None

        try:
            f = open(path, "rb")
            fs = os.stat(path)
        except OSError:
            self.send_error(404, "File not found")
            return None

        self.send_response(200)
        self.send_header("Content-type", self.guess_type(path))
        self.send_header("Content-Length", str(fs.st_size))
        self.send_header("Last-Modified", self.date_time_string(fs.st_mtime))
        self.end_headers()
        return f


def main():
    processes = []
    app_port = get_local_port("appPort", DEFAULT_APP_PORT)
    handler = functools.partial(SafeHTTPHandler, directory=str(APP_DIR))

    server = create_local_http_server(app_port, handler, "app")

    for script_name in LOCAL_SERVICE_SCRIPTS:
        service_script = Path(__file__).parent / script_name
        if service_script.exists():
            processes.append(subprocess.Popen([sys.executable, str(service_script)]))

    print(f"\n  App: http://localhost:{app_port}")
    print("  Press Ctrl+C to stop\n")

    webbrowser.open(f"http://localhost:{app_port}")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.shutdown()
        for p in processes:
            p.terminate()


if __name__ == "__main__":
    main()
