"""Shim — on first run, fetches the matching CLI archive from the manifest,
caches it under ~/.maestro/bin/, then exec's it."""
from __future__ import annotations
import json, os, platform, shutil, ssl, stat, subprocess, sys, tarfile, tempfile, urllib.request, zipfile
from pathlib import Path

MANIFEST_URL = os.environ.get(
    "MAESTRO_MANIFEST_URL",
    "https://maestro.makerman.co/storage/downloads/cli/latest.json",
)

ASSET = {
    ("Darwin", "arm64"):  "darwin-aarch64",
    ("Darwin", "x86_64"): "darwin-x86_64",
    ("Linux",  "aarch64"):"linux-aarch64",
    ("Linux",  "x86_64"): "linux-x86_64",
    ("Windows","AMD64"):  "windows-x86_64",
}

def _asset() -> str:
    key = (platform.system(), platform.machine())
    if key not in ASSET:
        sys.exit(f"maestro: unsupported platform {key}")
    return ASSET[key]

def _cache_dir() -> Path:
    d = Path(os.environ.get("MAESTRO_HOME", Path.home() / ".maestro")) / "bin"
    d.mkdir(parents=True, exist_ok=True)
    return d

def _ensure_binary() -> Path:
    asset = _asset()
    cache = _cache_dir()
    target = cache / ("maestro.exe" if asset.startswith("windows") else "maestro")
    if target.exists():
        return target
    ctx = ssl.create_default_context()
    with urllib.request.urlopen(MANIFEST_URL, context=ctx) as r:
        m = json.load(r)
    entry = next((t for t in m["targets"] if t["asset"] == asset), None)
    if not entry:
        sys.exit(f"maestro: no archive for {asset} in manifest")
    archive_url = MANIFEST_URL.rsplit("/", 1)[0] + "/" + entry["archive"]
    with tempfile.NamedTemporaryFile(delete=False) as tmp:
        with urllib.request.urlopen(archive_url, context=ctx) as r:
            shutil.copyfileobj(r, tmp)
        tmp_path = tmp.name
    if entry["format"] == "zip":
        with zipfile.ZipFile(tmp_path) as z:
            z.extractall(cache)
    else:
        with tarfile.open(tmp_path, "r:gz") as t:
            t.extractall(cache)
    os.unlink(tmp_path)
    target.chmod(target.stat().st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)
    return target

def run() -> None:
    exe = _ensure_binary()
    sys.exit(subprocess.call([str(exe), *sys.argv[1:]]))
