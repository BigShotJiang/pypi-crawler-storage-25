"""Rule schema definition."""

from __future__ import annotations

from typing import Any, Optional

from pydantic import BaseModel, Field


class RuleDefinition(BaseModel):
    id: str
    name: str
    description: str = ""
    type: str  # "regex", "file_policy", "ast", "documentation_obligation"
    pattern: Optional[str] = None
    check: Optional[str] = None
    ast_check: Optional[str] = None  # AST check function name (e.g. "no_mutable_defaults")
    severity: str = "medium"
    file_glob: str = "**/*"
    autofix: Optional[str] = None  # "remove_line", "replace_match", "comment_out"
    autofix_replacement: Optional[str] = None  # replacement text for "replace_match"
    standard: Optional[str] = None  # e.g. "IEC 62304"
    clause: Optional[str] = None  # e.g. "5.1.1"
    compliance_category: Optional[str] = None  # "code" | "documentation" | "process"
    remediation_guidance: Optional[str] = None  # Detailed remediation text
    tags: list[str] = Field(default_factory=list)  # e.g. ["fda", "class-C"]
    pack_id: Optional[str] = None  # Originating pack ID
    params: dict[str, Any] = Field(default_factory=dict)  # Thresholds for file_policy/AST checks
    all_patterns: list[str] = Field(default_factory=list)  # Composite regex (all must match)
    applies_when: dict[str, Any] = Field(default_factory=dict)  # Conditional evaluation for obligations
    language: Optional[str] = None  # Tree-sitter language name (e.g. "python", "cpp", "go")
    query: Optional[str] = None     # Tree-sitter S-expression query string
