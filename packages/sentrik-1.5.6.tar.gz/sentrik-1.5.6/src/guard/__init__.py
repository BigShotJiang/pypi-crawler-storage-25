"""AI SDLC Guard — governance runtime for AI coding agents."""

__version__ = "1.1.0"
