"""LLM-powered confidence scoring for non-deterministic findings.

Re-scores findings where heuristic confidence < 1.0 by asking an LLM
whether each match is a true positive. Fully optional — Sentrik works
without any LLM.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from guard.core.models import Finding
    from guard.providers.llm_base import LLMProvider

logger = logging.getLogger(__name__)

_PROMPT_TEMPLATE = """\
You are a code security reviewer. For each code finding below, determine whether \
it is a TRUE POSITIVE (real issue in executable code) or a FALSE POSITIVE \
(in a comment, string literal, test fixture, dead code, or documentation).

Respond with ONLY a JSON object: {{"confidence": <float 0.0-1.0>}}

- 1.0 = definitely a real issue
- 0.7-0.9 = likely real
- 0.3-0.6 = uncertain
- 0.0-0.2 = likely false positive

Finding:
  Rule: {rule_id}
  Message: {message}
  File: {file}
  Line: {line}
  Snippet: {snippet}
"""


def score_findings(
    findings: list[Finding],
    llm: LLMProvider,
    max_findings: int = 50,
) -> list[Finding]:
    """Re-score non-deterministic findings using the given LLM provider.

    Only findings with ``deterministic=False`` (heuristic confidence < 1.0)
    are sent to the LLM. Deterministic findings are returned unchanged.

    Args:
        findings: All findings from the scan.
        llm: Any LLM provider implementing ``analyze(prompt, context)``.
        max_findings: Maximum number of findings to re-score (cost cap).

    Returns:
        The same list with updated confidence values on re-scored findings.
    """
    candidates = [f for f in findings if not f.deterministic]
    if not candidates:
        return findings

    # Cap to avoid excessive API costs
    to_score = candidates[:max_findings]
    skipped = len(candidates) - len(to_score)
    if skipped > 0:
        logger.info(
            "Confidence scoring: %d findings capped at %d (skipped %d)",
            len(candidates), max_findings, skipped,
        )

    scored = 0
    for finding in to_score:
        try:
            new_confidence = _score_single(finding, llm)
            if new_confidence is not None:
                finding.confidence = new_confidence
                # If LLM is highly confident, mark as deterministic
                if new_confidence >= 0.95:
                    finding.deterministic = True
                scored += 1
        except Exception:
            logger.debug("LLM confidence scoring failed for %s", finding.finding_id, exc_info=True)

    if scored > 0:
        logger.info("LLM confidence scoring: updated %d/%d findings", scored, len(to_score))

    return findings


def _score_single(finding: Finding, llm: LLMProvider) -> float | None:
    """Score a single finding via LLM. Returns confidence or None on failure."""
    file = finding.evidence.file if finding.evidence else "(unknown)"
    line = finding.evidence.lines[0] if finding.evidence and finding.evidence.lines else 0
    snippet = finding.evidence.snippet if finding.evidence else ""

    prompt = _PROMPT_TEMPLATE.format(
        rule_id=finding.rule_id,
        message=finding.message,
        file=file,
        line=line,
        snippet=snippet,
    )

    result = llm.analyze(prompt, {"file": file, "content": snippet})

    # Extract confidence from response
    confidence = result.get("confidence")
    if confidence is not None:
        return max(0.0, min(1.0, float(confidence)))

    # Some models wrap in findings list
    llm_findings = result.get("findings", [])
    if llm_findings and isinstance(llm_findings[0], dict):
        confidence = llm_findings[0].get("confidence")
        if confidence is not None:
            return max(0.0, min(1.0, float(confidence)))

    return None
