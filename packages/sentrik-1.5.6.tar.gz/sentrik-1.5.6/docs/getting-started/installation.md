# Installation

## Install

```bash
npm install -g sentrik
```

Downloads a platform-specific binary. No Python or runtime dependencies needed. Works on macOS (x64/arm64), Linux (x64), and Windows (x64).

## Verify installation

```bash
sentrik --help
```

## License

Check your current license status:

```bash
sentrik license
```

Visit [sentrik.dev](https://sentrik.dev) to upgrade to Team, Organization, or Enterprise tiers.
