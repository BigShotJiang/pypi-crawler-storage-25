# Standards Packs

Standards packs are pre-built collections of rules for specific compliance frameworks. Enable them to instantly enforce regulatory standards on your codebase.

## Available Packs

Sentrik ships with **22 standards packs** across three tiers:

### Free Tier (5 packs — 158 rules)

Available to all users, no license key required, forever.

| Pack ID | Name | Rules | Standard |
|---------|------|-------|----------|
| `owasp-top-10` | OWASP Top 10 | 69 | OWASP Top 10 2021 (8 languages) |
| `soc2` | SOC2 Trust Services | 30 | SOC2 Trust Services Criteria |
| `python-security` | Python Security | 18 | Python eval/exec, pickle, subprocess, Django/Flask, crypto |
| `go-security` | Go Security | 15 | Go injection, crypto, unsafe, concurrency, web |
| `supply-chain-security` | Supply Chain Security | 26 | SLSA, NIST SSDF, CISA — CI/CD, dependencies, provenance |

### Team Tier (11 packs — $29/month)

Requires a Team license key or higher.

| Pack ID | Name | Rules | Standard |
|---------|------|-------|----------|
| `fda-iec-62304` | FDA IEC 62304 | 31 | IEC 62304 — Medical device software lifecycle |
| `hipaa` | HIPAA Security Rule | 25 | 45 CFR Part 164 — Protecting ePHI |
| `pci-dss` | PCI DSS v4.0 | 33 | Payment Card Industry Data Security Standard |
| `iso-27001` | ISO 27001 | 32 | ISO/IEC 27001:2022 Annex A — Information security |
| `gdpr` | GDPR | 25 | EU General Data Protection Regulation — PII security, consent, erasure |
| `nist-800-53` | NIST 800-53 | 21 | NIST SP 800-53 Rev 5 — US federal security controls |
| `cmmc` | CMMC 2.0 | 19 | Cybersecurity Maturity Model Certification — defense contractor security |
| `nist-ai-rmf` | NIST AI RMF | 15 | NIST AI 600-1 — AI governance, bias, security, transparency |
| `eu-ai-act` | EU AI Act | 22 | EU Artificial Intelligence Act — risk management, transparency, human oversight |
| `php-security` | PHP Security | 15 | PHP/Laravel code injection, SQLi, XSS, CSRF |
| `kotlin-security` | Kotlin Security | 13 | Kotlin/Android/Spring Boot security |

### Organization Tier (6 packs — $99/month)

Requires an Organization or Enterprise license key.

| Pack ID | Name | Rules | Standard |
|---------|------|-------|----------|
| `iec-81001-5-1` | IEC 81001-5-1 | 20 | Health software cybersecurity |
| `fda-21cfr11` | 21 CFR Part 11 | 16 | Electronic records and signatures |
| `iso-14971` | ISO 14971 | 16 | Medical device risk management |
| `misra-c` | MISRA C/C++ | 21 | Motor Industry Software Reliability Association |
| `do-178c` | DO-178C | 22 | Airborne systems software |
| `iso-26262` | ISO 26262 | 23 | Automotive functional safety |

**Total: 526 rules across all 22 packs (5 free, 11 team, 6 organization).**

## Managing Packs

```bash
# List all packs and their status
sentrik list-packs

# Enable a pack
sentrik add-pack owasp-top-10

# Disable a pack
sentrik remove-pack owasp-top-10

# List all active rules (builtins + user + packs)
sentrik list-rules
```

Or configure in `.sentrik/config.yaml` (or `.guard.yaml`):

```yaml
standards_packs:
  - owasp-top-10
  - fda-iec-62304
  - hipaa
```

Or via environment variable:

```bash
GUARD_STANDARDS_PACKS="owasp-top-10,soc2,pci-dss" sentrik scan
```

## Rule Types in Packs

Packs include a mix of rule types:

| Type | Purpose | Fails gate? |
|------|---------|-------------|
| `regex` | Pattern matching against file contents | Yes |
| `required_pattern` | Flags files missing a required pattern | Yes |
| `file_policy` | Structural checks (docstrings, file length) | Yes |
| `ast` | Python AST semantic analysis | Yes |
| `documentation_obligation` | Non-code compliance items | No |

Documentation obligations appear in reports for audit purposes but never fail the gate.

## Pack Rule Overrides

You can customize individual rules within a pack without modifying the pack itself. Overrides are stored in config:

```yaml
pack_overrides:
  owasp-top-10:
    OWASP-A03-005:
      severity: medium  # Downgrade from critical
    OWASP-A02-001:
      enabled: false     # Disable a specific rule
```

Pack overrides require an Organization or Enterprise license.

## Multi-Language Coverage

The OWASP Top 10 pack covers **8 languages**:

- Python (`.py`)
- JavaScript (`.js`)
- TypeScript (`.ts`)
- Java (`.java`)
- C# (`.cs`)
- Go (`.go`)
- C/C++ (`.c`, `.cpp`, `.h`, `.hpp`)
- Ruby (`.rb`)

Language-specific packs provide deeper coverage:

- **PHP** (`.php`) — `php-security` pack (15 rules for PHP and Laravel)
- **Kotlin** (`.kt`, `.kts`) — `kotlin-security` pack (13 rules for Android and Spring Boot)

Other packs use language-agnostic patterns (regex, file policies) that work across all file types.

## Custom Packs

Create your own packs for organization-specific rules. See [Authoring Custom Packs](authoring-custom-packs.md) for a full guide.
