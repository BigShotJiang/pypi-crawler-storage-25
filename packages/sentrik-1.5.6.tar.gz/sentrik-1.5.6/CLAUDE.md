# SENTRIK — Agent Instructions

## Project Overview

SENTRIK (formerly AI SDLC Guard) is a governance runtime that enforces coding standards, traces work items, and gates PRs for teams using AI coding agents. The PyPI package is `sentrik`, the npm package is `sentrik`, the Python import package is `guard`. The CLI command is `sentrik`.

Configuration resolution order: `.sentrik/config.yaml` → `.guard.yaml` → auto-detect (in-memory defaults). New projects use `.sentrik/config.yaml`; legacy `.guard.yaml` still fully supported.

## Quick Reference

```bash
# Validate config before anything else
sentrik validate-config

# Run a full scan (writes findings + reports to out/)
sentrik scan

# Enforce the gate (exit 1 on failure)
sentrik gate

# Scope to staged files (pre-commit)
sentrik scan --staged

# Scope to PR diff
sentrik gate --git-range "origin/main...HEAD"

# PR decoration + status check in CI
sentrik gate --git-range "origin/main...HEAD" --decorate-pr --status-check

# Reconcile findings with work items (create/update/close)
sentrik reconcile                          # Full reconcile against Azure DevOps
sentrik reconcile --dry-run                # Preview actions without calling APIs
sentrik reconcile --staged                 # Scope to staged files only
sentrik reconcile --work-items wi.json     # Override work_items.json path

# Compliance reports
sentrik compliance-report --list           # List frameworks from last scan
sentrik compliance-report -f "IEC 62304"   # Per-framework compliance report
sentrik compliance-report                  # All frameworks combined
sentrik compliance-map                     # Evidence map — where code SATISFIES requirements
sentrik compliance-map -f "HIPAA"          # Filter by framework
sentrik compliance-map --json              # JSON output for automation
sentrik compliance-map -o evidence.html    # Custom output path

# Historical audit reports
sentrik history-report --list              # List available historical runs
sentrik history-report --run-id <ID>       # Generate report for a past run
sentrik history-report --run-id <ID> -f "IEC 62304"  # With framework filter

# Trust center (public compliance page)
sentrik trust-center                        # Generate public-safe HTML page
sentrik trust-center --org "Acme Corp"      # With organization name
sentrik trust-center --json                 # JSON output for embedding
sentrik trust-center -o public/compliance.html  # Custom output path
sentrik attest                              # Generate signed compliance attestation
sentrik attest --verify out/attestation.json  # Verify an existing attestation

# Continuous monitoring
sentrik watch                              # Watch for file changes, scan on save
sentrik watch --interval 300               # Periodic scan every 5 minutes
sentrik watch --interval 60 --quiet        # Cron mode, minimal output
sentrik watch --vulns                      # Also scan deps for new CVEs (hourly)
sentrik watch --vulns --fix --create-pr    # Auto-fix + auto-PR on new CVEs

# Standards packs
sentrik list-packs                         # Show available standards packs
sentrik add-pack fda-iec-62304             # Enable a standards pack
sentrik remove-pack fda-iec-62304          # Disable a standards pack
sentrik import-spec api.yaml               # Generate rules from OpenAPI/AsyncAPI/protobuf spec
sentrik import-spec api.yaml --enable      # Generate and enable in config
sentrik import-spec service.proto -f protobuf  # Explicit format override
sentrik diff-packs owasp-top-10 old-owasp.yaml  # Diff current vs old pack version
sentrik diff-packs owasp-top-10 old.yaml --json  # JSON output for automation
sentrik gap-analysis owasp-top-10 old-owasp.yaml  # Regulatory gap report
sentrik gap-analysis soc2 old-soc2.yaml --json    # JSON gap analysis for automation
sentrik drift-scan                         # Context-aware requirement drift analysis
sentrik drift-scan -r reqs.yaml --staged   # Scope to staged files with custom requirements
sentrik drift-scan --json -o drift.json    # JSON output for automation
sentrik next-action                        # Show top 3 fixable findings
sentrik next-action -n 5                   # Show top 5
sentrik compliance-trend                   # Compliance score trend over time
sentrik compliance-trend --last 20 --json  # JSON output, last 20 runs
sentrik risk-summary                       # One-page executive risk summary (HTML)
sentrik risk-summary --org "Acme Corp"     # With organization name
sentrik init --no-interactive --mode developer  # Developer preset (permissive, fast)
sentrik init --no-interactive --mode compliance  # Strict compliance preset
sentrik init --no-interactive --mode ci          # CI pipeline preset
sentrik quality-score                      # Code quality score (0-100) across 6 dimensions
sentrik quality-score --verbose --json     # Detailed breakdown as JSON
sentrik quality-score --min-quality 70     # Fail if below threshold
sentrik quality-trend                      # Quality score trend over time
sentrik profile                            # Build/refresh project profile (frameworks, patterns, ADRs)
sentrik profile --show                     # View current project profile
sentrik profile --for src/auth/            # View constraints for a specific area
sentrik review-design --git-range HEAD~1..HEAD  # Review design decisions in recent changes
sentrik review-design --file src/auth.py   # Review a specific file
sentrik review-design --pending            # Show unacknowledged decisions
sentrik review-design --ack DD-ABC123 --note "Intentional"  # Acknowledge a decision
sentrik check-expertise                    # Check if changes are outside your expertise
sentrik check-expertise --profile          # Show your developer profile
sentrik check-expertise --git-range HEAD~5..HEAD --threshold 0.2  # Custom range + threshold
sentrik threat-model --file src/auth.py          # STRIDE threat analysis of a file
sentrik threat-model --git-range HEAD~3..HEAD    # Analyze recent changes
sentrik threat-model --pending                   # Show unmitigated threats
sentrik threat-model --mitigate TM-ABC123 --note "Fixed"  # Mark as mitigated
sentrik threat-model --stride tampering --json   # Filter by category, JSON output

# Guided setup wizard
sentrik init                               # Interactive setup wizard
sentrik init --no-interactive              # Auto-detect project, create .sentrik/config.yaml

# Migration from .guard.yaml
sentrik migrate                            # Copy .guard.yaml → .sentrik/config.yaml

# Governance & licensing
sentrik license                            # Show license status and features

# Dashboard + REST API server
sentrik dashboard                          # Start dashboard on localhost:8000
sentrik dashboard --port 9000              # Custom port
sentrik dashboard --reload                 # Dev mode with auto-reload
sentrik dashboard --no-open                # Don't auto-open browser

# Supply chain
sentrik sbom                    # Generate SBOM
sentrik vulns                   # Scan for CVEs
sentrik vulns --fix             # Auto-fix vulnerable deps
sentrik licenses                # Check dependency licenses
sentrik secrets                 # Scan for hardcoded secrets (AWS, GitHub, Stripe, etc.)
sentrik secrets --staged        # Scan only staged files (pre-commit)

# Analysis
sentrik analyze-cpp             # C/C++ semantic analysis
sentrik check-arch              # Architecture rules check
sentrik check-policies          # Policy-as-Code evaluation
sentrik check-inline --context src/main.cpp  # AI agent compliance context
sentrik metrics                 # Per-file code metrics (lines, nesting, functions)
sentrik compare                 # Delta analysis (new/resolved findings vs previous run)
sentrik compare --run-id <ID>   # Compare against specific historical run

# Governance
sentrik pull-reqs               # Pull requirements from DevOps
sentrik evidence-export -f SOC2 # Export audit evidence
sentrik grc-push --event scan_complete  # Push to GRC platform
sentrik auditor create --name "Jane" --email "jane@audit.com"
sentrik org-dashboard           # Multi-repo compliance view
sentrik impact --staged         # Change impact analysis

# AI integration
sentrik mcp-server              # Start MCP server for Claude Code/Cursor/VS Code
sentrik lsp-server              # Start LSP server for real-time as-you-type scanning

# Dashboard frontend (Vue 3 + Vite)
cd frontend && npm install && npm run build:only  # Build dashboard → src/guard/dashboard.html
sentrik check-inline --context src/main.cpp  # Get compliance context for AI agents
sentrik audit-mcp               # Audit MCP server configs for security risks

# Docker
docker compose up -d                     # Run REST API in container
docker compose down                      # Stop container
```

## Workflow: Implement → Scan → Fix → Repeat

1. **Read context first**: Run `sentrik context` to generate `out/agent_context.json` — it contains active work items, standards, and rules.
2. **Implement** the requested change.
3. **Run the gate**: `sentrik gate` — if it fails, read `out/findings.json` for details.
4. **Fix findings** flagged as `critical` or `high` (these block the gate).
5. **Re-run** `sentrik gate` until it passes.

## Key Files

| File | Purpose |
|------|---------|
| `.sentrik/config.yaml` | Shared team config (new convention, checked into git) |
| `.sentrik/rules/` | Custom rules directory (checked into git) |
| `.sentrik/local/` | Machine-local state (gitignored) |
| `.guard.yaml` | Legacy config (still supported, lower priority than `.sentrik/`) |
| `standards.yaml` | Coding rules — regex patterns and file policies |
| `work_items.json` | Active work items for traceability |
| `azure-pipelines.yml` | PR gate pipeline for Azure DevOps |
| `.github/workflows/guard-gate.yml` | GitHub Actions CI/CD workflow |
| `.pre-commit-config.yaml` | Pre-commit hook running `sentrik scan --staged` |
| `Dockerfile` | Multi-stage build for REST API server container |
| `docker-compose.yml` | Docker Compose config with volume mounts |
| `docs/USER_GUIDE.md` | Internal user guide (installation, config, rules, packs, CLI) |
| `docs/API_REFERENCE.md` | REST API reference (endpoints, auth, examples) |
| `docs/EXTENSION_GUIDE.md` | Custom rules authoring guide with YAML examples |

## Configuration

Environment variables override `.guard.yaml` values (useful in CI):

- `GUARD_OUTPUT_DIR` — output directory (default: `out`)
- `GUARD_STANDARDS_FILE` — path to standards file
- `GUARD_WORK_ITEMS_FILE` — path to work items file
- `GUARD_PROVIDER` — scanner provider (`stub`, `sarif`, `composite`)
- `GUARD_GATE_FAIL_ON` — comma-separated severities that fail the gate (e.g. `"critical,high"`)
- `GUARD_DEVOPS_PROVIDER` — devops work item provider: `"stub"` (default), `"azure"`, `"github"`, or `"jira"`
- `AZURE_DEVOPS_PAT` — Personal Access Token for Azure DevOps (secret — set in env, not in config)
- `GUARD_AZURE_DEVOPS_ORG` — Azure DevOps organization name (e.g. `"mycompany"`)
- `GUARD_AZURE_DEVOPS_PROJECT` — Azure DevOps project name
- `GUARD_AZURE_DEVOPS_TEAM` — Azure DevOps team (optional, needed for `@CurrentIteration`)
- `GUARD_AZURE_DEVOPS_ITERATION` — iteration path (defaults to `@CurrentIteration` at runtime)
- `GUARD_AZURE_DEVOPS_REPO` — Azure DevOps repository name (used for PR decoration and commit statuses)
- `GITHUB_TOKEN` — GitHub Personal Access Token (secret — set in env, not in config)
- `GUARD_GITHUB_OWNER` — GitHub repository owner (user or org)
- `GUARD_GITHUB_REPO` — GitHub repository name
- `GUARD_GITHUB_LABEL` — Filter issues by label (optional)
- `GUARD_GITHUB_MILESTONE` — Filter issues by milestone (optional)
- `GUARD_GITHUB_STANDARDS_REPO` — GitHub repo containing standards YAML (defaults to `github_repo`)
- `GUARD_GITHUB_STANDARDS_FILE` — Path to standards file in GitHub repo (default: `standards.yaml`)
- `GUARD_GITHUB_STANDARDS_REF` — Git ref/branch for standards file (default: `main`)
- `GUARD_JIRA_BASE_URL` — Jira instance base URL (e.g. `"https://jira.example.com"`)
- `GUARD_JIRA_PROJECT_KEY` — Jira project key (e.g. `"PROJ"`)
- `GUARD_JIRA_JQL` — Custom JQL query for work item fetching (optional)
- `GUARD_JIRA_STANDARDS_ISSUE_KEY` — Jira issue key containing standards YAML
- `JIRA_USER` — Jira username/email for API token auth (secret — set in env, not in config)
- `JIRA_TOKEN` — Jira API token (secret — set in env, not in config)
- `JIRA_PAT` — Jira Personal Access Token for Data Center/Server (secret — set in env, not in config)
- `GUARD_STANDARDS_PACKS` — comma-separated list of standards packs to enable (e.g. `"fda-iec-62304"`)
- `GUARD_API_KEY` — API key for REST server authentication (optional — when set, all endpoints require `X-API-Key` header)
- `GUARD_SEVERITY_RESCORING_ENABLED` — enable heuristic severity rescoring for findings (`"true"` or `"1"`, runs locally, no AI)
- `GUARD_ML_SEVERITY_ENABLED` — legacy alias for `GUARD_SEVERITY_RESCORING_ENABLED` (still works)
- `GUARD_PARALLEL_SCAN` — enable parallel file scanning (`"true"` or `"1"`)
- `GUARD_MAX_WORKERS` — number of parallel worker threads (default: `4`)
- `GUARD_AGENT_SCAN` — enable multi-agent compliance scanning (`"true"` or `"1"`) — one agent per pack, evaluated in parallel
- `GUARD_AGENT_MAX_CONCURRENCY` — max concurrent compliance agents (default: `0` = one thread per pack)
- `GUARD_GOVERNANCE_PROFILE` — governance profile override (`"strict"`, `"standard"`, `"permissive"`)
- `GUARD_LLM_BASE_URL` — Custom LLM API endpoint (for OpenAI-compatible APIs or Ollama)
- `GUARD_LLM_MODEL` — LLM model override (e.g. `"gpt-4o-mini"`, `"claude-haiku-4-5"`, `"llama3"`)
- `GUARD_LLM_PROVIDER` — LLM provider for confidence scoring: `"stub"` (default), `"anthropic"`, `"openai"`, or `"ollama"`
- `GUARD_LICENSE_KEY` — license key for production use (format: `GUARD-TIER-YYYYMMDD-HMAC`)
- `GUARD_LICENSE_SECRET` — HMAC secret used for license key generation/validation (for production deployments)
- `GUARD_CONFIDENCE_SCORING_ENABLED` — enable LLM-powered confidence re-scoring (`"true"` or `"1"`)
- `GUARD_CONFIDENCE_SCORING_MAX_FINDINGS` — max findings to re-score per scan (default: `50`)
- `GUARD_AZURE_OAUTH_CLIENT_ID` — Microsoft Entra ID app client ID (for Azure DevOps)
- `GUARD_AZURE_OAUTH_CLIENT_SECRET` — Microsoft Entra ID app client secret
- `GUARD_AZURE_OAUTH_TENANT_ID` — Microsoft Entra tenant ID (default: `common` for multi-tenant)
- `GUARD_AZURE_OAUTH_REDIRECT_URI` — Azure DevOps OAuth redirect URI (auto-detected from server URL)
- `GUARD_GITHUB_OAUTH_CLIENT_ID` — GitHub OAuth app client ID
- `GUARD_GITHUB_OAUTH_CLIENT_SECRET` — GitHub OAuth app client secret
- `GUARD_GITHUB_OAUTH_REDIRECT_URI` — GitHub OAuth redirect URI (auto-detected from server URL)
- `GUARD_JIRA_OAUTH_CLIENT_ID` — Atlassian/Jira OAuth app client ID
- `GUARD_JIRA_OAUTH_CLIENT_SECRET` — Atlassian/Jira OAuth app client secret
- `GUARD_JIRA_OAUTH_REDIRECT_URI` — Atlassian/Jira OAuth redirect URI (auto-detected from server URL)
- `GUARD_CPP_ANALYSIS_ENABLED` — enable C/C++ semantic analysis (`"true"` or `"1"`)
- `GUARD_CPP_ANALYSIS_TOOL` — C/C++ analysis tool: `"clang-tidy"` (default), `"cppcheck"`, or `"both"`
- `GUARD_CPP_ANALYSIS_CHECKS` — clang-tidy check patterns (empty = use defaults)
- `GUARD_GRC_WEBHOOK_URL` — GRC platform webhook URL for compliance event pushes
- `GUARD_GRC_API_KEY` — API key for GRC platform authentication
- `GUARD_GRC_PLATFORM` — GRC platform type: `"generic"` (default), `"drata"`, `"vanta"`, `"secureframe"`
- `GUARD_GRC_EVENTS` — comma-separated GRC events to push (e.g. `"scan_complete,gate_failed"`)
- `GUARD_RATE_LIMIT_ENABLED` — enable per-IP rate limiting on API endpoints (`"true"` by default)
- `GUARD_RATE_LIMIT_RPM` — rate limit requests per minute per IP (default: `60`)
- `GUARD_AUDIT_HMAC_KEY` — HMAC key for audit log integrity signatures (default: built-in key; set a custom value for production)

## OAuth Integration

Connect to DevOps providers via OAuth instead of managing PATs manually:

1. Register an OAuth app with your provider:
   - **Azure DevOps**: Register in [Microsoft Entra ID](https://entra.microsoft.com/) → App registrations → New registration. Add API permission for `Azure DevOps` → `user_impersonation`. Set redirect URI to `http://localhost:8000/oauth/azure/callback` (Web platform).
   - **GitHub**: https://github.com/settings/applications/new
   - **Jira Cloud**: https://developer.atlassian.com/console/myapps/
2. Set the client ID, secret, and tenant as env vars (e.g. `GUARD_AZURE_OAUTH_CLIENT_ID`, `GUARD_AZURE_OAUTH_TENANT_ID`)
3. Set the redirect URI to `http://localhost:8000/oauth/<provider>/callback`
4. In the dashboard Integration tab, click "Connect to [Provider]"
5. Tokens are stored locally in `.sentrik/local/oauth_tokens.json` (gitignored) and auto-refresh

Token resolution order: OAuth token (auto-refreshed) → legacy PAT env var → DefaultAzureCredential.

## Governance Policies

Governance is configured via the `governance:` section in `.guard.yaml`:

```yaml
governance:
  profile: standard  # strict | standard | permissive
  human_review_required:
    on_requirement_change: true
    on_critical_finding: true
    on_auto_patch_above: medium
  auto_patch:
    enabled: true
    max_severity: low
  gate:
    fail_on: [critical, high]
    block_merge_on_obligations: false
  sync:
    auto_close_work_items: true
    require_sign_off: false
  audit:
    enabled: true
    log_file: out/agent_audit.jsonl
```

Profiles provide sensible defaults: **strict** (human review for everything, tight gates), **standard** (balanced), **permissive** (maximum agent autonomy).

## Project Structure

```
src/guard/          # Main package
  cli.py            # Typer CLI entry point
  server.py         # FastAPI REST API server
  config.py         # GuardConfig with YAML + env var loading
  core/             # Pipeline, diff parsing, traceability, governance, licensing, reconciler
    auto_detect.py  # Zero-config project detection (languages, CI, packs)
  ml/               # Heuristic severity rescoring (no actual ML)
  providers/        # Scanner backends (stub, SARIF, composite) + DevOps (stub, Azure, GitHub, Jira)
  reporters/        # Output formats (HTML, JUnit, SARIF)
  rules/            # Built-in rules + rule engine + AST checks
  packs/            # Standards packs (e.g. fda_iec_62304/)
tests/              # Pytest test suite
npm-package/        # npm distribution (downloads platform binary)
vscode-extension/   # VS Code/Cursor extension (zero-config, auto-scan)
```

## Development Setup

```bash
# One command setup (creates venv, installs deps, hooks, validates)
bash scripts/setup-dev.sh    # Linux/macOS
# or
.\scripts\setup-dev.ps1      # Windows PowerShell
```

## Testing

```bash
pytest                        # Run all tests with coverage (80% threshold)
pytest --no-cov               # Run tests without coverage (faster)
pytest tests/test_rules_engine.py  # Run specific test file
sentrik validate-config         # Check config validity
sentrik scan                    # Full scan with reports
```

Coverage report is generated at `out/htmlcov/index.html`.

## Standards Packs

Standards packs are pre-built sets of regulatory rules. Enable packs in `.guard.yaml`:

```yaml
standards_packs:
  - fda-iec-62304
```

Available packs (22 total — 5 free, 11 team, 6 Organization tier):
- **owasp-top-10** — OWASP Top 10 2021 web application security rules (69 rules)
- **soc2** — SOC2 Trust Services Criteria for security, availability, and confidentiality (30 rules)
- **python-security** — Python-specific security: eval/exec, pickle, subprocess, SQL injection, Django/Flask, crypto (18 rules)
- **go-security** — Go-specific security: injection, cryptography, unsafe operations, concurrency, web (15 rules)
- **supply-chain-security** — SLSA, NIST SSDF, and CISA guidance for CI/CD pipelines, dependency integrity, build provenance, and AI tool supply chain (26 rules)
- **fda-iec-62304** — IEC 62304 / 21 CFR Part 11 rules for medical device software (31 rules) [Team tier]
- **hipaa** — HIPAA Security Rule (45 CFR Part 164) for protecting ePHI (25 rules) [Team tier]
- **pci-dss** — PCI DSS v4.0 for protecting cardholder data (33 rules) [Team tier]
- **iso-27001** — ISO/IEC 27001:2022 Annex A for information security management (32 rules) [Team tier]
- **gdpr** — EU General Data Protection Regulation: PII security, consent, erasure, breach notification, cross-border transfers (25 rules) [Team tier]
- **nist-800-53** — NIST SP 800-53 Rev 5: US federal security controls — access control, audit, crypto, input validation (21 rules) [Team tier]
- **cmmc** — CMMC 2.0: Cybersecurity Maturity Model Certification for defense contractors — CUI protection, FIPS crypto, MFA (19 rules) [Team tier]
- **nist-ai-rmf** — NIST AI 600-1 Risk Management Framework for AI governance, bias, security, and transparency (15 rules) [Team tier]
- **eu-ai-act** — EU Artificial Intelligence Act compliance for high-risk AI systems: risk management, transparency, human oversight, data governance, prohibited practices (22 rules) [Team tier]
- **php-security** — PHP/Laravel security: code injection, SQLi, XSS, CSRF (15 rules) [Team tier]
- **kotlin-security** — Kotlin/Android/Spring Boot security (12 rules) [Team tier]
- **iec-81001-5-1** — Health software cybersecurity (20 rules) [Org tier]
- **fda-21cfr11** — 21 CFR Part 11 electronic records (16 rules) [Org tier]
- **iso-14971** — Medical device risk management (16 rules) [Org tier]
- **misra-c** — MISRA C/C++ coding standards (21 rules) [Org tier]
- **do-178c** — Airborne systems software (22 rules) [Org tier]
- **iso-26262** — Automotive functional safety (23 rules) [Org tier]

## Rule Types

- **regex** — Pattern matching against file contents (code-enforceable). Supports `all_patterns` for composite matching.
- **required_pattern** — Inverse of regex: flags files that LACK a required pattern
- **file_policy** — Structural checks with configurable `params` (docstring, max lines, imports, function count)
- **ast** — Structural AST analysis. Two dispatch modes:
  - `ast_check` (Python only) — built-in Python AST check functions with `params` thresholds
  - `language` + `query` (any language) — tree-sitter S-expression query; supports Python, C++, C, Go, Rust, JavaScript, TypeScript, Java, Kotlin, Ruby, C#
- **documentation_obligation** — Non-code compliance items that appear in reports but never fail the gate

## Built-in AST Checks (Python only)

- `no_mutable_defaults` — Flags mutable default arguments (list, dict, set)
- `no_star_imports` — Flags `from X import *` wildcard imports
- `high_complexity` — Flags functions exceeding complexity threshold (param: `max_complexity`, default 10)
- `no_nested_functions` — Flags deeply nested function definitions (param: `max_depth`, default 1)
- `no_global_variables` — Flags module-level mutable variable assignments
- `max_function_length` — Flags functions exceeding line count (param: `max_lines`, default 50)

## Tree-sitter AST Queries (multi-language)

Rules with `type: ast` can include `language` + `query` fields to run a tree-sitter S-expression query against the parsed AST of any supported language. Parsers are cached per process. Install grammars with `pip install "sentrik[treesitter]"`.

```yaml
- id: MYPACK-001
  type: ast
  language: cpp
  query: |
    (call_expression function: (template_function
      name: (identifier) @fn (#eq? @fn "reinterpret_cast")))
  severity: high
  file_glob: "**/*.{cpp,hpp,h}"
```

Supported language aliases: `python`, `cpp`/`c++`, `c`, `javascript`/`js`, `typescript`/`ts`, `go`/`golang`, `rust`, `java`, `kotlin`, `ruby`/`rb`, `c_sharp`/`csharp`/`cs`.
Use the [tree-sitter playground](https://tree-sitter.github.io/tree-sitter/playground) to explore AST node types for any language.

## File Policy Checks

- `starts_with_docstring` — Requires module docstring
- `max_lines` — Limits file length (param: `max_lines`, default 500)
- `must_contain_pattern` — Requires a regex pattern in file (param: `pattern`)
- `must_not_import` — Forbids specific module imports (param: `forbidden_modules`)
- `max_function_count` — Limits function definitions per file (param: `max_functions`, default 20)

## Severity Rescoring (Heuristic)

Enable with `severity_rescoring_enabled: true` in `.guard.yaml` or `GUARD_SEVERITY_RESCORING_ENABLED=true`.
The legacy names `ml_severity_enabled` and `GUARD_ML_SEVERITY_ENABLED` still work as aliases.

The severity rescorer adjusts finding severity based on code context using a weighted heuristic model (not ML — runs locally, no AI models, no external APIs):
- Six features: base severity, confidence, code context, pattern risk, file risk, finding density
- Deterministic findings are not re-scored by default
- Documentation obligations are never re-scored

## Confidence Scoring

Regex findings have variable confidence based on code context:

- **1.0** — Match in executable code (`deterministic=True`)
- **0.7** — Match in a test file (`test_` prefix, `_test.py` suffix, or `/tests/` directory)
- **0.5** — Match inside a comment (language-aware: `#` for Python/Ruby/YAML/Shell, `//` for JS/TS/C/C++/Go/Rust/Java/Swift/Kotlin/Scala/Dart)
- **0.4** — Match inside a string literal or docstring

When confidence < 1.0, the finding is marked `deterministic=False`.

### LLM-Powered Confidence Re-scoring

Opt-in, provider-agnostic LLM re-scoring adjusts confidence for non-deterministic findings (confidence < 1.0). Enable in config:

```yaml
llm_provider: openai       # anthropic, openai, ollama
llm_model: gpt-4o-mini
llm_base_url: ""           # custom endpoint
confidence_scoring_enabled: true
confidence_scoring_max_findings: 50
```

Supported providers:
- **Anthropic** — Claude models (requires `ANTHROPIC_API_KEY`)
- **OpenAI** — GPT models and compatible APIs via `llm_base_url` (requires `OPENAI_API_KEY`)
- **Ollama** — Local models (set `llm_base_url` to Ollama endpoint, e.g. `http://localhost:11434`)

Only findings with confidence < 1.0 are sent for re-scoring. Deterministic findings (AST, file_policy, required_pattern) are skipped.

Non-regex checks retain fixed confidence:
- **AST, file_policy, required_pattern** — always 1.0 (structurally verified)
- **SARIF imports** — default 0.9
- **LLM findings** — use the LLM-provided confidence value
- **Requirement drift** (`verify-reqs`) — 0.7

## Parallel Scanning

Enable parallel file evaluation with:
```yaml
parallel_scan: true
max_workers: 4     # Number of threads (default: 4)
```

Or via environment variables: `GUARD_PARALLEL_SCAN=true`, `GUARD_MAX_WORKERS=8`.

Files within each rule are evaluated concurrently using `ThreadPoolExecutor`. Cache access is thread-safe via locking.

## Scan Metrics

When scanning, metrics are automatically written to `out/scan_metrics.json`:
- Total duration, rules engine time, scanner time, rescorer time
- Files scanned, cache hits/misses, cache hit rate
- Findings by severity and by rule
- Parallel worker count

## Dashboard & Management Console

The REST API includes a management console at `/dashboard` with 21 sidebar pages organized into 6 sections:

**Monitoring:**
- **Overview** — scan metrics, severity charts, top files, governance status banner
- **Findings** — severity filter indicator showing active filters
- **Vulnerabilities** — CVE/dependency vulnerability viewer
- **History** — historical audit runs with "View Report" per entry

**Compliance:**
- **Rules** — searchable/filterable rule browser with filtering by severity, type, and standard, plus grouping options
- **Packs** — enable/disable standards packs
- **Reports** — compliance report generation per framework
- **Licenses** — dependency license compliance
- **Evidence Map** — compliance evidence mapping: where code satisfies requirements

**Integrations:**
- **Work Items** — DevOps work item tracking, reconcile findings
- **Integration** — DevOps provider connection (Azure DevOps, GitHub, Jira), OAuth connect/disconnect

**Governance:**
- **Policies** — governance profile selector, human review gates, auto-patch controls
- **Approvals** — async approval gates for gated actions
- **Audit Log** — agent action timeline with policy justification
- **Attestation** — signed compliance attestation viewer

**Intelligence:**
- **Quality Score** — 0-100 quality score across 6 dimensions with trend chart
- **Project Profile** — auto-detected languages, frameworks, patterns, module map
- **Design Decisions** — LLM-identified design decisions with acknowledgement workflow
- **Expertise** — developer expertise profiles from git history
- **Threat Model** — STRIDE threat analysis with severity/category filters, AI chat, mitigate workflow

**Settings** — full configuration viewer

API endpoints: `/api/metrics`, `/api/posture`, `/api/config`, `/api/governance`, `/api/audit`, `/api/packs`, `/api/license`, `/api/compliance-report`, `/api/compliance-map`, `/api/trust-center`, `/api/audit/runs`, `/api/oauth/status`, `/api/quality-score`, `/api/project-profile`, `/api/design-decisions`, `/api/developer-profiles`, `/api/attestation`, `/api/threat-model`

## Multi-Agent Scanning

Enable with `agent_scan: true` in config or `GUARD_AGENT_SCAN=true`. Each enabled standards pack runs as an independent compliance agent in parallel via `ThreadPoolExecutor`. Per-agent timing and finding counts are recorded in `scan_metrics.json` under `agent_metrics`. Use the MCP `get_agent_status` tool to query agent metrics from AI coding agents.

## VS Code / Cursor Extension

The `vscode-extension/` directory contains a VS Code extension for in-editor scanning:
- **Zero config** — auto-detects project, creates `.sentrik/` on first open, scans immediately
- **All languages** — scan-on-save for any file type (not just Python)
- **Status bar** — shows scan state and finding count inline
- Findings displayed as VS Code diagnostics (errors, warnings, hints)
- Commands: `SENTRIK: Run Scan`, `SENTRIK: Run Gate`, `SENTRIK: Clear Diagnostics`
- Settings: `sentrik.autoInit`, `sentrik.autoScan`, `sentrik.binaryPath`, `sentrik.severityFilter`
- Legacy `ai-sdlc-guard.*` settings still read as fallback
