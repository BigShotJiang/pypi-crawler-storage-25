
{
    "version": "2026.5.23",
    "target": "default",
    "variant": "cpu"
}
