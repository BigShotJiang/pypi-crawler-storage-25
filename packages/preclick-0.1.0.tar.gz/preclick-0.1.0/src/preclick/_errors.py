# Copyright 2026 CybrLab.ai
# SPDX-License-Identifier: Apache-2.0

"""
Error types raised by PreClickClient.

Consumers can use ``isinstance`` checks to distinguish transport problems
from remote-side errors and from generic client misuse.
"""

__all__ = ["PreClickError", "PreClickConnectionError", "PreClickRemoteError"]


class PreClickError(Exception):
    """Base error for all PreClick client failures.

    Raised for local misuse (invalid arguments, closed client) and as the
    base class for the two more specific error types below.
    """


class PreClickConnectionError(PreClickError):
    """Raised when the client cannot reach the PreClick endpoint or the
    underlying transport fails to (re)connect.

    Carries a :attr:`retryable` hint so callers can distinguish transient
    failures (DNS glitch, socket reset, mid-stream drop -- safe to retry)
    from permanent ones (malformed endpoint URL -- no amount of retrying
    will help).  Defaults to ``True``; pass ``retryable=False`` for
    configuration errors.
    """

    def __init__(self, message: str, *, retryable: bool = True) -> None:
        super().__init__(message)
        self.retryable = retryable


class PreClickRemoteError(PreClickError):
    """Raised when the remote PreClick service returns an error response
    (tool error, invalid request, rate limit, auth failure, etc.).
    """

    def __init__(
        self,
        message: str,
        *,
        code: int | str | None = None,
        data: object = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.data = data