# Copyright 2026 CybrLab.ai
# SPDX-License-Identifier: Apache-2.0

"""
PreClickClient -- async Python client for the PreClick URL security
scanning service.

Uses MCP under the hood, but consumers see a small scan-oriented API with
no protocol vocabulary:

    Primary scan API (convenience wrappers, recommended for most users):
        scan, scan_with_intent

    Job methods (explicit control over submission / polling / waiting):
        start_scan, start_scan_with_intent, get_scan_status,
        get_scan_result, wait_for_scan

Plus lifecycle: connect, disconnect, close (alias), is_connected.

Publisher: CybrLab.ai (https://cybrlab.ai)
Service:   PreClick (https://preclick.ai)
"""

from __future__ import annotations

import asyncio
import json
import logging
import math
import time
from importlib.metadata import version as _pkg_version
from typing import Any
from urllib.parse import urlparse

from mcp import ClientSession
from mcp.client.streamable_http import (
    create_mcp_http_client,
    streamable_http_client,
)
from mcp.shared.exceptions import McpError
from mcp.types import Implementation

from ._errors import (
    PreClickConnectionError,
    PreClickError,
    PreClickRemoteError,
)

__all__ = ["PreClickClient", "PRECLICK_ENDPOINT"]

PRECLICK_ENDPOINT = "https://preclick.ai/mcp"

_DEFAULT_CLIENT_NAME = "preclick-mcp-client-python"
_DEFAULT_REQUEST_TIMEOUT: float = 600.0  # seconds
_DEFAULT_MAX_WAIT: float = 600.0  # seconds
_DEFAULT_POLL_INTERVAL: float = 2.0  # seconds
_MIN_POLL_INTERVAL: float = 0.5  # seconds
_MAX_TRANSIENT_POLL_FAILURES = 3
_MAX_POLL_RETRY_DELAY: float = 10.0  # seconds

_REQUEST_TIMEOUT_CODE = -32001
_RETRYABLE_REMOTE_CODES: frozenset[int] = frozenset(
    [_REQUEST_TIMEOUT_CODE, 408, 429, 502, 503, 504]
)

# TLS/certificate error reason strings that indicate a permanent (not
# transient) failure.  Python's ssl module surfaces these as the ``reason``
# attribute of ``ssl.SSLCertVerificationError`` (an OSError subclass).
# When one of these appears, retrying is pointless — it's a config error.
_NON_RETRYABLE_TRANSPORT_ERROR_CODES: frozenset[str] = frozenset(
    [
        "CERT_HAS_EXPIRED",
        "CERTIFICATE_VERIFY_FAILED",
        "DEPTH_ZERO_SELF_SIGNED_CERT",
        "ERR_TLS_CERT_ALTNAME_INVALID",
        "SELF_SIGNED_CERT_IN_CHAIN",
        "UNABLE_TO_GET_ISSUER_CERT",
        "UNABLE_TO_GET_ISSUER_CERT_LOCALLY",
        "UNABLE_TO_VERIFY_LEAF_SIGNATURE",
    ]
)

# Module-private.  These are the four upstream compatibility tools this
# client wraps.  Consumers never see or import them -- the whole point of
# this client is to hide MCP details behind a scan-shaped API.
_PRECLICK_TOOLS: dict[str, str] = {
    "start_scan": "url_scanner_async_scan",
    "start_scan_with_intent": "url_scanner_async_scan_with_intent",
    "get_scan_status": "url_scanner_async_task_status",
    "get_scan_result": "url_scanner_async_task_result",
}

# Explicit whitelist of upstream envelope keys the normalizer understands.
# Anything outside this set is dropped (fail-closed) AND logged as a drift
# signal so upstream contract changes are caught immediately.
_KNOWN_ENVELOPE_KEYS: frozenset[str] = frozenset(
    [
        "task_id",
        "status",
        "status_message",
        "created_at",
        "updated_at",
        "ttl_ms",
        "poll_interval_ms",
        "result",
        "retry_after_ms",
        "message",
    ]
)

_logger = logging.getLogger("preclick")


def _read_package_version() -> str:
    """Read the installed package version, falling back gracefully."""
    try:
        return _pkg_version("preclick")
    except Exception:
        return "0.0.0-unknown"


_DEFAULT_CLIENT_VERSION = _read_package_version()


class PreClickClient:
    """Async Python client for the PreClick URL security scanning service.

    Parameters
    ----------
    api_key : str, optional
        PreClick API key.  When omitted, the trial tier is used (up to
        100 requests/day).  Must be a non-empty string when provided.
    endpoint : str
        Override the MCP endpoint URL.  Defaults to
        ``https://preclick.ai/mcp``.
    client_name : str
        Reported MCP client name.
    client_version : str
        Reported MCP client version.  Defaults to the installed package
        version.
    headers : dict[str, str], optional
        Extra HTTP headers sent with every request.
    request_timeout : float
        Per-request timeout in seconds.  Default: 600.

    Examples
    --------
    Context manager (recommended)::

        async with PreClickClient(api_key="sk-...") as client:
            result = await client.scan("https://example.com")
            print(result["agent_access_directive"])

    Manual lifecycle::

        client = PreClickClient()
        result = await client.scan("https://example.com")
        await client.close()
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        endpoint: str = PRECLICK_ENDPOINT,
        client_name: str = _DEFAULT_CLIENT_NAME,
        client_version: str | None = None,
        headers: dict[str, str] | None = None,
        request_timeout: float = _DEFAULT_REQUEST_TIMEOUT,
    ) -> None:
        # --- Validate api_key ---
        if api_key is not None:
            if not isinstance(api_key, str):
                raise PreClickError("Invalid api_key: expected a string.")
            if len(api_key) == 0:
                raise PreClickError(
                    "Invalid api_key: expected a non-empty string. "
                    "Omit api_key entirely for trial mode."
                )

        # --- Validate endpoint ---
        if not isinstance(endpoint, str):
            raise PreClickError("Invalid endpoint: expected a string.")

        # --- Validate client_name ---
        if not isinstance(client_name, str):
            raise PreClickError("Invalid client_name: expected a string.")

        # --- Validate client_version ---
        if client_version is not None and not isinstance(client_version, str):
            raise PreClickError("Invalid client_version: expected a string.")

        # --- Validate headers ---
        if headers is not None:
            if not isinstance(headers, dict):
                raise PreClickError("Invalid headers: expected a dict.")
            for name, value in headers.items():
                if not isinstance(name, str) or len(name) == 0:
                    raise PreClickError(
                        "Invalid header name: expected a non-empty string."
                    )
                if not isinstance(value, str):
                    raise PreClickError(
                        f"Invalid headers[{name!r}]: expected a string."
                    )

        # --- Validate request_timeout ---
        _require_positive_number(request_timeout, "request_timeout")

        self.endpoint = endpoint
        self.api_key = api_key
        self.client_name = client_name
        self.client_version = client_version or _DEFAULT_CLIENT_VERSION
        self.request_timeout = float(request_timeout)
        self._extra_headers: dict[str, str] = dict(headers or {})

        # Connection state
        self._session: ClientSession | None = None
        self._transport_ctx: Any = None
        self._session_ctx: Any = None
        self._connect_lock = asyncio.Lock()
        self._closing = False

        # Delay function -- overridable by tests to skip real sleeps.
        self._delay = _default_delay

    # ------------------------------------------------------------------
    # Lifecycle -- the first scan call auto-connects, so users rarely
    # need these.
    # ------------------------------------------------------------------

    async def connect(self) -> None:
        """Connect to the PreClick service.

        Safe to call multiple times -- only the first call performs the
        connection.  Calling explicitly lets you fail fast on
        misconfiguration; otherwise the first scan auto-connects.
        """
        if self._session is not None:
            return

        async with self._connect_lock:
            if self._session is not None:
                return
            await self._do_connect()

    async def disconnect(self) -> None:
        """Disconnect from the PreClick service.

        Safe to call when not connected.  If a ``connect()`` is still in
        flight, this waits for it to finish so the resulting connection is
        torn down cleanly -- no leaked sockets.
        """
        self._closing = True
        try:
            # Wait for any in-flight connect so we can tear it down after
            # it resolves (mirrors the JS client's disconnect behaviour).
            async with self._connect_lock:
                await self._cleanup_connection()
        finally:
            self._closing = False

    async def close(self) -> None:
        """Alias for :meth:`disconnect`.

        Prefer ``close()`` in consumer code -- it matches the convention
        used by most Python network clients.
        """
        await self.disconnect()

    @property
    def is_connected(self) -> bool:
        """Whether the client currently holds an active connection."""
        return self._session is not None

    async def __aenter__(self) -> PreClickClient:
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.close()

    # ------------------------------------------------------------------
    # Primary scan API -- one-call convenience wrappers
    # ------------------------------------------------------------------

    async def scan(
        self,
        url: str,
        *,
        max_wait: float = _DEFAULT_MAX_WAIT,
        signal: Any | None = None,
    ) -> dict[str, Any]:
        """Scan a URL and return the result.

        This is the recommended entry point for the common "is this URL
        safe?" question.  Internally it calls :meth:`start_scan` followed
        by the same polling logic as :meth:`wait_for_scan` and returns the
        inner scan result payload directly.  Scans typically take 70--80
        seconds; the default wait window is 10 minutes.

        If the wait raises (timeout, cancellation, transport failure), the
        error is decorated with ``err.scan_id`` so the caller can resume
        polling the same scan via ``wait_for_scan(scan_id)`` without
        re-submitting.

        Parameters
        ----------
        url : str
            URL or hostname.  Upstream requires HTTP or HTTPS; if no
            scheme is provided, ``https://`` is assumed.
        max_wait : float
            Maximum total time to wait in seconds.  Default: 600.
        signal : object, optional
            Cancellation signal.  Accepts an ``asyncio.Event``-like object
            (``is_set()`` / ``wait()``) or an AbortSignal-like object
            (boolean ``aborted``).  If already set before submission, no
            scan is submitted.

        Returns
        -------
        dict
            The inner scan result with keys ``risk_score``,
            ``confidence``, ``analysis_complete``,
            ``agent_access_directive``, ``agent_access_reason``,
            ``intent_alignment``.
        """
        _require_string(url, "url")
        _validate_max_wait(max_wait)
        _validate_signal(signal)
        _raise_if_aborted(signal)
        submission = await self._start_scan(url, signal=signal)
        return await self._wait_for_scan_internal(
            submission["scan_id"], max_wait, signal=signal
        )

    async def scan_with_intent(
        self,
        url: str,
        intent: str,
        *,
        max_wait: float = _DEFAULT_MAX_WAIT,
        signal: Any | None = None,
    ) -> dict[str, Any]:
        """Scan a URL with user intent and return the result.

        Use this when the user has stated their purpose (log in, purchase,
        download, booking, etc.).  The scanner evaluates destination/intent
        alignment in addition to threat signals.

        Parameters
        ----------
        url : str
            URL or hostname.
        intent : str
            User's stated purpose.  Max 248 characters (server-enforced).
        max_wait : float
            Maximum total time to wait in seconds.  Default: 600.
        signal : object, optional
            Cancellation signal.  Accepts an ``asyncio.Event``-like object
            (``is_set()`` / ``wait()``) or an AbortSignal-like object
            (boolean ``aborted``).

        Returns
        -------
        dict
            The inner scan result payload.
        """
        _require_string(url, "url")
        _require_string(intent, "intent")
        _validate_max_wait(max_wait)
        _validate_signal(signal)
        _raise_if_aborted(signal)
        submission = await self._start_scan_with_intent(
            url, intent, signal=signal
        )
        return await self._wait_for_scan_internal(
            submission["scan_id"], max_wait, signal=signal
        )

    # ------------------------------------------------------------------
    # Job methods -- for manual polling, progress reporting, or handing a
    # scan_id across async boundaries.
    # ------------------------------------------------------------------

    async def start_scan(
        self, url: str, *, signal: Any | None = None
    ) -> dict[str, Any]:
        """Submit a URL for security scanning.

        Returns immediately with a submission envelope containing
        ``scan_id``.  Use :meth:`wait_for_scan` to block until the scan
        finishes, or :meth:`get_scan_status` / :meth:`get_scan_result` to
        poll manually.

        Parameters
        ----------
        url : str
            URL or hostname.
        signal : object, optional
            Cancellation signal.  If already set, no scan is submitted.

        Returns
        -------
        dict
            Submission envelope with ``scan_id``, ``status``,
            ``status_message``, ``created_at``, ``updated_at``,
            ``ttl_ms``, ``poll_interval_ms``, ``message``.
        """
        _require_string(url, "url")
        _validate_signal(signal)
        _raise_if_aborted(signal)
        return await self._start_scan(url, signal=signal)

    async def start_scan_with_intent(
        self,
        url: str,
        intent: str,
        *,
        signal: Any | None = None,
    ) -> dict[str, Any]:
        """Submit a URL for intent-aware security scanning.

        Parameters
        ----------
        url : str
            URL or hostname.
        intent : str
            User's stated purpose.  Max 248 characters (server-enforced).
        signal : object, optional
            Cancellation signal.  If already set, no scan is submitted.

        Returns
        -------
        dict
            Submission envelope with ``scan_id``.
        """
        _require_string(url, "url")
        _require_string(intent, "intent")
        _validate_signal(signal)
        _raise_if_aborted(signal)
        return await self._start_scan_with_intent(
            url, intent, signal=signal
        )

    async def get_scan_status(
        self, scan_id: str, *, signal: Any | None = None
    ) -> dict[str, Any]:
        """Non-blocking status check for a scan.

        Parameters
        ----------
        scan_id : str
            ID returned by :meth:`start_scan` or
            :meth:`start_scan_with_intent`.
        signal : object, optional
            Cancellation signal.

        Returns
        -------
        dict
            Status envelope with ``scan_id``, ``status``,
            ``status_message``, ``created_at``, ``updated_at``,
            ``ttl_ms``, ``poll_interval_ms``.
        """
        _require_string(scan_id, "scan_id")
        _validate_signal(signal)
        _raise_if_aborted(signal)
        envelope = await self._call_tool(
            _PRECLICK_TOOLS["get_scan_status"],
            {"task_id": scan_id},
            signal=signal,
        )
        return _normalize_scan_envelope(envelope)

    async def get_scan_result(
        self, scan_id: str, *, signal: Any | None = None
    ) -> dict[str, Any]:
        """Non-blocking result fetch for a scan.

        Returns an envelope with ``status``.  When
        ``status == "completed"``, the scan result is under ``result``.
        When still running, ``result`` is ``None`` and ``retry_after_ms``
        hints how long to wait before the next call.

        Parameters
        ----------
        scan_id : str
            Scan ID.
        signal : object, optional
            Cancellation signal.

        Returns
        -------
        dict
            Result envelope.
        """
        _require_string(scan_id, "scan_id")
        _validate_signal(signal)
        _raise_if_aborted(signal)
        return await self._get_scan_result(scan_id, signal=signal)

    async def wait_for_scan(
        self,
        scan_id: str,
        *,
        max_wait: float = _DEFAULT_MAX_WAIT,
        signal: Any | None = None,
    ) -> dict[str, Any]:
        """Wait for a scan to complete and return the inner scan result.

        Polls :meth:`get_scan_result` at the cadence recommended by the
        server (``retry_after_ms``), up to *max_wait* total.  Returns the
        scan result directly -- not the envelope.

        Parameters
        ----------
        scan_id : str
            Scan ID.
        max_wait : float
            Maximum total wait time in seconds.  Default: 600.
        signal : object, optional
            Cancellation signal.  When cancellation happens after the scan
            ID is known, the raised ``CancelledError`` carries
            ``err.scan_id``.

        Returns
        -------
        dict
            The inner scan result payload.
        """
        _require_string(scan_id, "scan_id")
        _validate_max_wait(max_wait)
        _validate_signal(signal)
        return await self._wait_for_scan_internal(
            scan_id, max_wait, signal=signal
        )

    # ------------------------------------------------------------------
    # Internal scan helpers
    # ------------------------------------------------------------------

    async def _start_scan(
        self, url: str, *, signal: Any | None = None
    ) -> dict[str, Any]:
        envelope = await self._call_tool(
            _PRECLICK_TOOLS["start_scan"],
            {"url": url},
            signal=signal,
        )
        return _require_submission_envelope(
            _normalize_scan_envelope(envelope),
            _PRECLICK_TOOLS["start_scan"],
        )

    async def _start_scan_with_intent(
        self,
        url: str,
        intent: str,
        *,
        signal: Any | None = None,
    ) -> dict[str, Any]:
        envelope = await self._call_tool(
            _PRECLICK_TOOLS["start_scan_with_intent"],
            {"url": url, "intent": intent},
            signal=signal,
        )
        return _require_submission_envelope(
            _normalize_scan_envelope(envelope),
            _PRECLICK_TOOLS["start_scan_with_intent"],
        )

    async def _get_scan_result(
        self,
        scan_id: str,
        *,
        allow_internal_retry: bool = True,
        signal: Any | None = None,
    ) -> dict[str, Any]:
        envelope = await self._call_tool(
            _PRECLICK_TOOLS["get_scan_result"],
            {"task_id": scan_id},
            allow_internal_retry=allow_internal_retry,
            signal=signal,
        )
        return _normalize_scan_envelope(envelope)

    async def _wait_for_scan_internal(
        self,
        scan_id: str,
        max_wait: float,
        *,
        signal: Any | None = None,
    ) -> dict[str, Any]:
        """Internal polling loop shared by wait_for_scan / scan /
        scan_with_intent.

        Decorates every raised error with ``.scan_id`` so callers of the
        convenience wrappers can resume polling the same scan instead of
        losing the ID on timeout/cancel/transport failure.
        """
        transient_poll_failures = 0
        last_transient_err: BaseException | None = None

        try:
            _raise_if_aborted(signal)
            deadline = time.monotonic() + max_wait

            while time.monotonic() < deadline:
                _raise_if_aborted(signal)
                try:
                    # allow_internal_retry=False -- the polling loop owns
                    # retry budget.  The inner _call_tool must NOT also
                    # retry, or one "transient" poll iteration would cost
                    # two server calls.
                    envelope = await self._get_scan_result(
                        scan_id,
                        allow_internal_retry=False,
                        signal=signal,
                    )
                    transient_poll_failures = 0
                    last_transient_err = None
                except BaseException as err:
                    if (
                        _is_retryable_poll_error(err)
                        and transient_poll_failures
                        < _MAX_TRANSIENT_POLL_FAILURES
                    ):
                        transient_poll_failures += 1
                        last_transient_err = err
                        retry_delay = min(
                            _DEFAULT_POLL_INTERVAL * transient_poll_failures,
                            _MAX_POLL_RETRY_DELAY,
                        )
                        if time.monotonic() + retry_delay >= deadline:
                            raise
                        _logger.warning(
                            "Transient error while polling scan %s (%s), "
                            "retrying...",
                            scan_id,
                            err,
                        )
                        await self._delay(retry_delay, signal)
                        continue
                    raise

                if envelope["status"] == "completed":
                    result = envelope.get("result")
                    if not result or not isinstance(result, dict):
                        raise PreClickRemoteError(
                            f"Scan {scan_id} completed but result payload "
                            "is missing or malformed.",
                            data=envelope,
                        )
                    return result

                # Only "working" is a keep-polling status.  Anything else
                # -- "failed", "cancelled", "expired", or unknown -- is a
                # terminal remote-side failure.
                if envelope["status"] != "working":
                    raise PreClickRemoteError(
                        f"Scan {scan_id} ended with unexpected status: "
                        f"{envelope['status']}",
                        data=envelope,
                    )

                # Respect the server-recommended retry interval.
                # Validate strictly: must be a real finite positive
                # number (not bool, not NaN, not Infinity) -- matches
                # the JS client's Number.isFinite guard.
                retry_after = envelope.get("retry_after_ms")
                if _is_valid_poll_hint(retry_after):
                    retry_secs = max(
                        retry_after / 1000.0, _MIN_POLL_INTERVAL
                    )
                else:
                    if retry_after is not None:
                        _logger.warning(
                            "Invalid retry_after_ms in envelope (%r), "
                            "falling back to %.1fs",
                            retry_after,
                            _DEFAULT_POLL_INTERVAL,
                        )
                    retry_secs = _DEFAULT_POLL_INTERVAL

                if time.monotonic() + retry_secs >= deadline:
                    break
                await self._delay(retry_secs, signal)

            err = PreClickError(
                f"wait_for_scan exhausted: scan {scan_id} did not "
                f"complete within {max_wait}s."
            )
            if last_transient_err is not None:
                err.__cause__ = last_transient_err
            raise err

        except BaseException as err:
            # Attach scan_id to any error so callers can resume polling.
            if not hasattr(err, "scan_id"):
                try:
                    err.scan_id = scan_id  # type: ignore[attr-defined]
                except (AttributeError, TypeError):
                    pass  # frozen / sealed object -- best effort
            raise

    # ------------------------------------------------------------------
    # Internal RPC
    # ------------------------------------------------------------------

    async def _call_tool(
        self,
        tool_name: str,
        args: dict[str, Any],
        *,
        allow_internal_retry: bool = True,
        signal: Any | None = None,
    ) -> Any:
        max_attempts = 2 if allow_internal_retry else 1

        for attempt in range(max_attempts):
            try:
                _raise_if_aborted(signal)
                await self._ensure_connected()
                _raise_if_aborted(signal)

                assert self._session is not None
                result = await _await_with_signal(
                    self._session.call_tool(tool_name, args),
                    timeout=self.request_timeout,
                    signal=signal,
                )
                _raise_if_aborted(signal)

                if result.isError:
                    text = (
                        _extract_error_text(result.content)
                        or "Unknown remote error"
                    )
                    raise PreClickRemoteError(text, data=result)

                return _unwrap_tool_result(result)

            except asyncio.CancelledError:
                raise
            except PreClickRemoteError:
                raise
            except PreClickError as err:
                if not isinstance(err, PreClickConnectionError):
                    raise
                has_more = attempt + 1 < max_attempts
                if has_more and _should_retry_call_error(err, attempt):
                    _logger.warning(
                        "Call to %s failed (%s), retrying...",
                        tool_name,
                        err,
                    )
                    await self._reset_connection()
                    continue
                raise
            except BaseException as err:
                has_more = attempt + 1 < max_attempts
                if has_more and _should_retry_call_error(err, attempt):
                    _logger.warning(
                        "Call to %s failed (%s), retrying...",
                        tool_name,
                        err,
                    )
                    await self._reset_connection()
                    continue
                raise _wrap_as_remote_error(err, tool_name) from err

        raise PreClickError(  # pragma: no cover
            f"{tool_name}: unexpected retry loop exit"
        )

    # ------------------------------------------------------------------
    # Connection internals
    # ------------------------------------------------------------------

    async def _do_connect(self) -> None:
        headers = {
            "Accept": "application/json, text/event-stream",
            **self._extra_headers,
        }
        if self.api_key:
            headers["X-API-Key"] = self.api_key

        try:
            parsed = urlparse(self.endpoint)
            if not parsed.scheme or not parsed.netloc:
                raise ValueError(f"Invalid URL: {self.endpoint}")
        except Exception as exc:
            raise PreClickConnectionError(
                f"Invalid PreClick endpoint {self.endpoint!r}: {exc}",
                retryable=False,
            ) from exc

        try:
            http_client = create_mcp_http_client(headers=headers)
            self._transport_ctx = streamable_http_client(
                self.endpoint,
                http_client=http_client,
            )
            read_stream, write_stream, _ = (
                await self._transport_ctx.__aenter__()
            )

            self._session_ctx = ClientSession(
                read_stream,
                write_stream,
                client_info=Implementation(
                    name=self.client_name,
                    version=self.client_version,
                ),
            )
            session = await self._session_ctx.__aenter__()
            await session.initialize()

            if self._closing:
                await self._cleanup_connection()
                return

            self._session = session
            _logger.info("Connected to %s", self.endpoint)
        except PreClickConnectionError:
            raise
        except Exception as exc:
            await self._cleanup_connection()
            raise PreClickConnectionError(
                f"Failed to connect to PreClick at {self.endpoint}: {exc}",
                retryable=_is_retryable_connection_failure(exc),
            ) from exc

    async def _ensure_connected(self) -> None:
        if self._session is not None:
            return
        await self.connect()
        if self._session is None:
            raise PreClickError(
                "PreClick client was closed during an in-flight connection."
            )

    async def _reset_connection(self) -> None:
        await self._cleanup_connection()

    async def _cleanup_connection(self) -> None:
        self._session = None
        if self._session_ctx is not None:
            try:
                await self._session_ctx.__aexit__(None, None, None)
            except Exception as exc:
                _logger.warning(
                    "Error while closing session (ignored): %s", exc
                )
            self._session_ctx = None
        if self._transport_ctx is not None:
            try:
                await self._transport_ctx.__aexit__(None, None, None)
            except Exception as exc:
                _logger.warning(
                    "Error while closing transport (ignored): %s", exc
                )
            self._transport_ctx = None


# ------------------------------------------------------------------
# Pure helpers (module-private)
# ------------------------------------------------------------------


def _require_string(value: Any, name: str) -> None:
    if not isinstance(value, str) or len(value) == 0:
        raise PreClickError(f"Invalid {name}: expected a non-empty string.")


def _require_positive_number(value: Any, name: str) -> None:
    """Reject bools, NaN, Infinity, and non-positive values."""
    if (
        isinstance(value, bool)
        or not isinstance(value, (int, float))
        or not math.isfinite(value)
        or value <= 0
    ):
        raise PreClickError(
            f"Invalid {name}: expected a positive finite number."
        )


def _validate_max_wait(value: Any) -> None:
    _require_positive_number(value, "max_wait")


def _validate_signal(signal: Any) -> None:
    """Validate the optional public cancellation signal.

    Python has no built-in AbortSignal equivalent, so the client accepts
    two small duck-typed forms:

    * ``asyncio.Event``-like: callable ``is_set()`` and ``wait()``.
    * AbortSignal-like: boolean ``aborted``.
    """
    if signal is None:
        return

    aborted = getattr(signal, "aborted", None)
    if isinstance(aborted, bool):
        return

    is_set = getattr(signal, "is_set", None)
    wait = getattr(signal, "wait", None)
    if callable(is_set) and callable(wait):
        return

    raise PreClickError(
        "Invalid signal: expected an asyncio.Event-like object "
        "or an AbortSignal-like object."
    )


def _is_signal_aborted(signal: Any) -> bool:
    if signal is None:
        return False

    aborted = getattr(signal, "aborted", None)
    if isinstance(aborted, bool):
        return aborted

    is_set = getattr(signal, "is_set", None)
    if callable(is_set):
        return bool(is_set())

    return False


def _raise_if_aborted(signal: Any) -> None:
    if _is_signal_aborted(signal):
        raise asyncio.CancelledError("Operation cancelled by signal.")


def _signal_wait_coro(signal: Any) -> Any | None:
    wait = getattr(signal, "wait", None)
    if callable(wait):
        return wait()
    return None


def _is_valid_poll_hint(value: Any) -> bool:
    """Check whether a server-supplied retry_after_ms is usable.

    Must be a real finite positive number -- not bool, not NaN, not
    Infinity.  Matches the JS client's ``Number.isFinite`` guard.
    """
    if isinstance(value, bool):
        return False
    if not isinstance(value, (int, float)):
        return False
    return math.isfinite(value) and value > 0


async def _default_delay(
    seconds: float, signal: Any | None = None
) -> None:
    """Default delay backed by :func:`asyncio.sleep`."""
    _raise_if_aborted(signal)
    wait_coro = _signal_wait_coro(signal)
    if wait_coro is None:
        if signal is None:
            await asyncio.sleep(seconds)
            return
        deadline = time.monotonic() + seconds
        while True:
            _raise_if_aborted(signal)
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return
            await asyncio.sleep(min(remaining, 0.1))

    try:
        await asyncio.wait_for(wait_coro, timeout=seconds)
    except asyncio.TimeoutError:
        return

    _raise_if_aborted(signal)
    raise asyncio.CancelledError("Operation cancelled by signal.")


async def _await_with_signal(
    awaitable: Any,
    *,
    timeout: float,
    signal: Any | None,
) -> Any:
    """Await an operation with request timeout and optional cancellation."""
    _raise_if_aborted(signal)
    wait_coro = _signal_wait_coro(signal)
    if wait_coro is None:
        result = await asyncio.wait_for(awaitable, timeout=timeout)
        _raise_if_aborted(signal)
        return result

    op_task = asyncio.create_task(awaitable)
    signal_task = asyncio.create_task(wait_coro)
    try:
        done, pending = await asyncio.wait(
            {op_task, signal_task},
            timeout=timeout,
            return_when=asyncio.FIRST_COMPLETED,
        )
        if not done:
            op_task.cancel()
            signal_task.cancel()
            raise asyncio.TimeoutError()

        # Give the operation result precedence: if the call already
        # completed, use the result even if the signal fired at the
        # same instant (matches JS client behaviour).
        if op_task in done:
            signal_task.cancel()
            return await op_task

        if signal_task in done:
            op_task.cancel()
            _raise_if_aborted(signal)
            raise asyncio.CancelledError("Operation cancelled by signal.")
    finally:
        for task in (op_task, signal_task):
            if not task.done():
                task.cancel()
        await asyncio.gather(op_task, signal_task, return_exceptions=True)


def _get_mcp_error_code(err: McpError) -> int | None:
    """Extract the JSON-RPC error code from an MCP SDK error.

    The Python MCP SDK stores error details on ``err.error`` (an
    ``ErrorData`` pydantic model), not as top-level attributes.
    """
    error_data = getattr(err, "error", None)
    if error_data is not None:
        return getattr(error_data, "code", None)
    return None


def _get_mcp_error_data(err: McpError) -> Any:
    """Extract the error data payload from an MCP SDK error."""
    error_data = getattr(err, "error", None)
    if error_data is not None:
        return getattr(error_data, "data", None)
    return None


def _deep_get(obj: Any, key: str) -> Any:
    """Read *key* from *obj* whether it is a dict or an object with attrs."""
    if obj is None:
        return None
    if isinstance(obj, dict):
        return obj.get(key)
    return getattr(obj, key, None)


def _first_not_none(*values: Any) -> Any:
    """Return the first non-``None`` value, or ``None`` if all are."""
    for v in values:
        if v is not None:
            return v
    return None


def _unwrap_tool_result(result: Any) -> Any:
    """Unwrap an MCP tool-call result into the most useful shape.

    Prefers ``structuredContent`` (parsed dict), then JSON-parses the first
    text content item, then falls back to the raw text or the whole result.
    """
    if result is None or not hasattr(result, "structuredContent"):
        return result

    if result.structuredContent is not None:
        return result.structuredContent

    if hasattr(result, "content") and isinstance(
        result.content, (list, tuple)
    ):
        for item in result.content:
            text = getattr(item, "text", None)
            if isinstance(text, str):
                try:
                    return json.loads(text)
                except (json.JSONDecodeError, ValueError):
                    return text

    return result


def _normalize_scan_envelope(envelope: Any) -> dict[str, Any]:
    """Translate an upstream compat envelope to a clean Python dict.

    Renames ``task_id`` to ``scan_id``.  All other snake_case fields pass
    through unchanged (they are already Pythonic).  Unknown upstream fields
    are dropped (fail-closed) and logged.
    """
    if not isinstance(envelope, dict):
        raise PreClickRemoteError(
            "Malformed scan envelope: upstream response was not a "
            "JSON object.",
            data=envelope,
        )

    unknown = [k for k in envelope if k not in _KNOWN_ENVELOPE_KEYS]
    if unknown:
        _logger.warning(
            "Unknown envelope fields from upstream (dropped): %s",
            ", ".join(unknown),
        )

    out: dict[str, Any] = {}
    if "task_id" in envelope:
        out["scan_id"] = envelope["task_id"]
    if "status" in envelope:
        out["status"] = envelope["status"]
    if "status_message" in envelope:
        out["status_message"] = envelope["status_message"]
    if "created_at" in envelope:
        out["created_at"] = envelope["created_at"]
    if "updated_at" in envelope:
        out["updated_at"] = envelope["updated_at"]
    if "ttl_ms" in envelope:
        out["ttl_ms"] = envelope["ttl_ms"]
    if "poll_interval_ms" in envelope:
        out["poll_interval_ms"] = envelope["poll_interval_ms"]
    if "result" in envelope:
        out["result"] = envelope["result"]
    if "retry_after_ms" in envelope:
        out["retry_after_ms"] = envelope["retry_after_ms"]
    if "message" in envelope:
        out["message"] = envelope["message"]

    return out


def _require_submission_envelope(
    envelope: dict[str, Any], tool_name: str
) -> dict[str, Any]:
    scan_id = envelope.get("scan_id")
    if not isinstance(scan_id, str) or len(scan_id) == 0:
        raise PreClickRemoteError(
            f"{tool_name}: malformed submission envelope: "
            "missing task_id.",
            data=envelope,
        )
    return envelope


def _should_retry_call_error(err: BaseException, attempt: int) -> bool:
    if attempt != 0:
        return False
    if isinstance(err, asyncio.CancelledError):
        return False
    if isinstance(err, PreClickConnectionError):
        return err.retryable is not False
    if isinstance(err, McpError):
        return _get_mcp_error_code(err) == _REQUEST_TIMEOUT_CODE
    return _is_known_transport_error(err)


def _is_retryable_poll_error(err: BaseException) -> bool:
    if isinstance(err, asyncio.CancelledError):
        return False
    if isinstance(err, PreClickConnectionError):
        return err.retryable is not False
    if not isinstance(err, PreClickRemoteError):
        return False
    # Use nullish precedence (first non-None wins), not truthy
    # precedence, so an explicit code like 0 is not skipped.
    # Matches JS's `err.code ?? err.data?.code ?? err.data?.statusCode`.
    raw = _first_not_none(
        err.code,
        _deep_get(err.data, "code"),
        _deep_get(err.data, "statusCode"),
    )
    code = _normalize_error_code(raw)
    return code in _RETRYABLE_REMOTE_CODES


def _is_known_transport_error(err: BaseException) -> bool:
    """Recognise transport-level failures (socket, DNS, timeout).

    Deliberately narrower than ``isinstance(err, OSError)`` -- raw
    ``OSError`` is the parent of ``FileNotFoundError``,
    ``PermissionError``, and other non-network errors that should NOT be
    classified as transport failures.  Matches the JS client's explicit
    code-set approach adapted to Python's exception hierarchy.
    """
    if not isinstance(err, Exception):
        return False
    # ConnectionError covers ConnectionRefusedError, ConnectionResetError,
    # ConnectionAbortedError, BrokenPipeError -- all network-level.
    if isinstance(err, (ConnectionError, TimeoutError)):
        return True
    # The MCP SDK uses httpx under the hood. httpx raises its own
    # exception hierarchy (not stdlib subclasses) for transport failures.
    # Check ancestor names to avoid a hard import dependency on httpx.
    ancestor_names = {c.__name__ for c in type(err).__mro__}
    if ancestor_names & _HTTPX_TRANSPORT_ERROR_NAMES:
        return True
    # socket.gaierror (DNS resolution failure) is an OSError subclass
    # but not a ConnectionError.
    if type(err).__name__ in ("gaierror", "FetchError"):
        return True
    return False


# httpx exception class names that indicate transport-level failures.
# Checked via MRO name set so we don't need to import httpx directly.
# NetworkError covers ConnectError, ReadError, WriteError, CloseError.
# TimeoutException covers ConnectTimeout, ReadTimeout, WriteTimeout,
# PoolTimeout. RemoteProtocolError covers peer/stream protocol drops.
_HTTPX_TRANSPORT_ERROR_NAMES: frozenset[str] = frozenset(
    ["NetworkError", "TimeoutException", "RemoteProtocolError"]
)


def _is_retryable_connection_failure(err: BaseException) -> bool:
    if _is_known_non_retryable_transport_error(err):
        return False
    return _is_known_transport_error(err)


def _is_known_non_retryable_transport_error(err: BaseException) -> bool:
    if not isinstance(err, Exception):
        return False
    # Check for SSL/TLS certificate errors
    if isinstance(err, OSError) and hasattr(err, "reason"):
        reason = str(getattr(err, "reason", ""))
        for code in _NON_RETRYABLE_TRANSPORT_ERROR_CODES:
            if code in reason:
                return True
    # Check nested cause
    cause = getattr(err, "__cause__", None)
    if cause and isinstance(cause, OSError) and hasattr(cause, "reason"):
        reason = str(getattr(cause, "reason", ""))
        for code in _NON_RETRYABLE_TRANSPORT_ERROR_CODES:
            if code in reason:
                return True
    return False


def _normalize_error_code(code: Any) -> int | str | None:
    if isinstance(code, int):
        return code
    if not isinstance(code, str) or code == "":
        return code
    try:
        return int(code)
    except (ValueError, TypeError):
        return code


def _extract_error_text(content: Any) -> str:
    if not isinstance(content, (list, tuple)):
        return ""
    parts = []
    for item in content:
        text = getattr(item, "text", None)
        if isinstance(text, str) and text:
            parts.append(text)
    return "\n".join(parts)


def _wrap_as_remote_error(
    err: BaseException, tool_name: str
) -> PreClickError:
    """Convert any error into the right public error class."""
    if isinstance(err, PreClickError):
        return err
    if isinstance(err, asyncio.CancelledError):
        raise err  # re-raise, don't wrap
    if isinstance(err, McpError):
        return PreClickRemoteError(
            f"{tool_name}: {err}",
            code=_get_mcp_error_code(err),
            data=_get_mcp_error_data(err),
        )
    if _is_known_transport_error(err):
        return PreClickConnectionError(
            f"{tool_name}: {err}",
            retryable=True,
        )
    return PreClickError(f"{tool_name}: {err}")
