# Copyright 2026 CybrLab.ai
# SPDX-License-Identifier: Apache-2.0

"""
preclick -- async Python client for the PreClick URL security scanning
service.  Hosted endpoint, scan-oriented public API, no MCP protocol
vocabulary in the public surface.

Public surface: two primary methods (scan, scan_with_intent) plus five
job methods (start_scan, start_scan_with_intent, get_scan_status,
get_scan_result, wait_for_scan) for explicit control.  See README.md
for usage.

Publisher: CybrLab.ai (https://cybrlab.ai)
Service:   PreClick (https://preclick.ai)
"""

from ._client import PRECLICK_ENDPOINT, PreClickClient
from ._errors import (
    PreClickConnectionError,
    PreClickError,
    PreClickRemoteError,
)

__all__ = [
    "PreClickClient",
    "PreClickError",
    "PreClickConnectionError",
    "PreClickRemoteError",
    "PRECLICK_ENDPOINT",
]