# Changelog

## 0.1.0 (2026-04-12)

Initial release of `preclick` -- an async Python client for the PreClick URL
security scanning service. The client uses MCP under the hood but the public
API is scan-oriented, with no protocol vocabulary exposed to consumers.

### Primary scan API (convenience wrappers)

One-call methods that submit a scan and return the completed result directly. These are what most consumers should use:

- `scan(url, *, max_wait=600)` -- scan a URL and return the completed scan result.
- `scan_with_intent(url, intent, *, max_wait=600)` -- intent-aware variant; use when the user has stated their purpose (log in, purchase, download, booking, etc.).

Both block until the scan completes (typically 70--80 seconds; 10-minute default wait window) and return the inner scan result dict directly -- no envelopes, no intermediate scan IDs to thread through.

### Job methods (explicit control)

For long-running contexts where you need explicit control over submission and waiting:

- `start_scan(url)` -- submit a URL for scanning; returns a submission envelope with `scan_id`.
- `start_scan_with_intent(url, intent)` -- intent-aware submission.
- `get_scan_status(scan_id)` -- non-blocking status check.
- `get_scan_result(scan_id)` -- non-blocking result fetch; returns a working or completed envelope.
- `wait_for_scan(scan_id, *, max_wait=600)` -- polls `get_scan_result` at the server-recommended cadence until the scan completes, then returns the inner scan result payload.

### Cancellation

Standard asyncio cancellation works naturally. After a scan is submitted, any error carries `err.scan_id` so callers can resume polling without re-submitting.

### Retry policy

`wait_for_scan()` tolerates a small budget (3) of retryable transient poll failures -- recognised remote HTTP-like codes (408, 429, 502, 503, 504) and MCP request-timeout (-32001), plus any `PreClickConnectionError` that isn't flagged `retryable=False`. The polling loop owns retry exclusively.

### Lifecycle

- `close()` -- idiomatic alias for `disconnect()`. Preferred in consumer code.
- `connect()` / `disconnect()` / `is_connected` -- optional, the first scan method auto-connects.
- Context manager: `async with PreClickClient() as client:` -- recommended.

### Public exports

```python
from preclick import (
    PreClickClient,          # also the default import target
    PreClickError,
    PreClickConnectionError,
    PreClickRemoteError,
    PRECLICK_ENDPOINT,
)
```

### Envelope normalization

Upstream compat-tool envelopes are normalized to a clean Python dict:

- `task_id` -> `scan_id`
- All other snake_case fields pass through unchanged (already Pythonic)

The inner scan result payload (`risk_score`, `confidence`, `agent_access_directive`, etc.) is left in its documented PreClick form.

### Error contract

- `PreClickConnectionError` -- known transport-layer failures (network, DNS, TLS, socket). Invalid endpoint URLs are wrapped here.
- `PreClickRemoteError` -- JSON-RPC / remote-side failures from the PreClick service. Carries the original `code` and `data`.
- `PreClickError` -- local misuse (invalid arguments), unknown local exceptions, or `wait_for_scan` `max_wait` exhausted.

### Test suite

Comprehensive test coverage using pytest across six test files:

- `tests/test_public_api.py` -- public exports, class method surface.
- `tests/test_validation.py` -- constructor and input validation.
- `tests/test_normalization.py` -- envelope normalization and tool-result unwrapping.
- `tests/test_errors.py` -- error hierarchy, wrapping, and retry predicates.
- `tests/test_client.py` -- end-to-end behavior with a fake MCP session.
- `tests/test_integration.py` -- live-service integration tests gated behind `INTEGRATION=1`.

CI runs the test suite on Python 3.10, 3.11, 3.12, and 3.13.

### Requirements

- Python >= 3.10
- Depends on `mcp>=1.24.0` (transport only; users never see MCP types).

### Apache-2.0 licensed.