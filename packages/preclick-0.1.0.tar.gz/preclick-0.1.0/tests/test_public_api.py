# Copyright 2026 CybrLab.ai
# SPDX-License-Identifier: Apache-2.0

"""
Public API surface tests.

Guards against accidental drops, renames, or contract drift on both the
package-root exports and the PreClickClient public methods.  Also guards
against MCP-shaped symbols sneaking back into the public surface.
"""

import preclick


def test_package_exports_documented_public_symbols():
    expected = [
        "PreClickClient",
        "PreClickError",
        "PreClickConnectionError",
        "PreClickRemoteError",
        "PRECLICK_ENDPOINT",
    ]
    for name in expected:
        assert hasattr(preclick, name), f"missing public export: {name}"


def test_package_does_not_expose_mcp_symbols():
    forbidden = ["_PRECLICK_TOOLS", "PRECLICK_TOOLS", "PRECLICK_TASK_METHODS"]
    for name in forbidden:
        assert not hasattr(preclick, name), (
            f"public export should be hidden: {name}"
        )


def test_preclick_endpoint_is_hosted_url():
    assert preclick.PRECLICK_ENDPOINT == "https://preclick.ai/mcp"


def test_error_classes_form_documented_hierarchy():
    assert issubclass(
        preclick.PreClickConnectionError, preclick.PreClickError
    )
    assert issubclass(
        preclick.PreClickRemoteError, preclick.PreClickError
    )
    assert issubclass(preclick.PreClickError, Exception)


def test_client_has_primary_scan_methods():
    import inspect

    client_cls = preclick.PreClickClient
    for method in ["scan", "scan_with_intent"]:
        attr = getattr(client_cls, method, None)
        assert attr is not None, f"missing method: {method}"
        assert inspect.iscoroutinefunction(attr), (
            f"{method} should be async"
        )


def test_client_has_job_methods():
    import inspect

    client_cls = preclick.PreClickClient
    for method in [
        "start_scan",
        "start_scan_with_intent",
        "get_scan_status",
        "get_scan_result",
        "wait_for_scan",
    ]:
        attr = getattr(client_cls, method, None)
        assert attr is not None, f"missing method: {method}"
        assert inspect.iscoroutinefunction(attr), (
            f"{method} should be async"
        )


def test_client_has_lifecycle_methods():
    import inspect

    client_cls = preclick.PreClickClient
    for method in ["connect", "disconnect", "close"]:
        attr = getattr(client_cls, method, None)
        assert attr is not None, f"missing method: {method}"
        assert inspect.iscoroutinefunction(attr), (
            f"{method} should be async"
        )


def test_client_has_is_connected_property():
    client = preclick.PreClickClient()
    assert isinstance(client.is_connected, bool)
    assert client.is_connected is False


def test_client_supports_async_context_manager():
    assert hasattr(preclick.PreClickClient, "__aenter__")
    assert hasattr(preclick.PreClickClient, "__aexit__")


def test_all_list_matches_exports():
    for name in preclick.__all__:
        assert hasattr(preclick, name), (
            f"__all__ lists {name} but it is not exported"
        )