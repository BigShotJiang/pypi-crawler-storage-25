# Copyright 2026 CybrLab.ai
# SPDX-License-Identifier: Apache-2.0

"""
Integration tests -- exercise the public API against the live PreClick
service at https://preclick.ai/mcp.

Gated behind the INTEGRATION env var so they never run in CI or during
normal ``pytest``.

Two tiers:

    Smoke (no API key needed, ~2 scans):
        INTEGRATION=1 pytest tests/test_integration.py -v

    Full (requires PRECLICK_API_KEY, exercises every method):
        INTEGRATION=1 PRECLICK_API_KEY=sk-... pytest tests/test_integration.py -v

The trial tier allows 100 requests/day.  Smoke stays well under that
budget; the full suite submits many scans and should only be run with
an API key.

Scans typically take 70-80 seconds.  The full suite may take several
minutes.
"""

import asyncio
import os

import pytest
import pytest_asyncio

from preclick import (
    PreClickClient,
    PreClickConnectionError,
    PreClickError,
    PreClickRemoteError,
)

SKIP = not os.environ.get("INTEGRATION")
HAS_API_KEY = bool(os.environ.get("PRECLICK_API_KEY"))
SAFE_URL = "https://example.com"
SAFE_INTENT = "read documentation"

# Per-scan timeout: 3 minutes should be plenty for a ~80s scan
SCAN_TIMEOUT = 180.0  # seconds


pytestmark = pytest.mark.skipif(SKIP, reason="INTEGRATION env var not set")


@pytest_asyncio.fixture
async def client():
    api_key = os.environ.get("PRECLICK_API_KEY") or None
    async with PreClickClient(api_key=api_key) as c:
        yield c


# =====================================================================
# Smoke tier -- minimal live-service coverage, safe for trial quota
# =====================================================================


class TestSmoke:
    @pytest.mark.asyncio
    async def test_connect_establishes_connection(self, client):
        await client.connect()
        assert client.is_connected is True
        # Second call is a no-op
        await client.connect()
        assert client.is_connected is True

    @pytest.mark.asyncio
    async def test_scan_returns_complete_result(self, client):
        result = await client.scan(SAFE_URL, max_wait=SCAN_TIMEOUT)

        assert isinstance(result["risk_score"], (int, float))
        assert isinstance(result["confidence"], (int, float))
        assert isinstance(result["analysis_complete"], bool)
        assert isinstance(result["agent_access_directive"], str)
        assert isinstance(result["agent_access_reason"], str)
        assert isinstance(result["intent_alignment"], str)

        assert 0 <= result["risk_score"] <= 1
        assert 0 <= result["confidence"] <= 1

        valid_directives = [
            "ALLOW",
            "DENY",
            "RETRY_LATER",
            "REQUIRE_CREDENTIALS",
        ]
        assert result["agent_access_directive"] in valid_directives
        assert result["intent_alignment"] == "not_provided"

    @pytest.mark.asyncio
    async def test_start_scan_returns_envelope_with_scan_id(self, client):
        submission = await client.start_scan(SAFE_URL)
        assert isinstance(submission["scan_id"], str)
        assert len(submission["scan_id"]) > 0
        assert submission["status"] in ("working", "completed")

    @pytest.mark.asyncio
    async def test_start_scan_rejects_empty_url(self, client):
        with pytest.raises(PreClickError, match="url"):
            await client.start_scan("")

    @pytest.mark.asyncio
    async def test_get_scan_status_rejects_empty_scan_id(self, client):
        with pytest.raises(PreClickError, match="scan_id"):
            await client.get_scan_status("")

    @pytest.mark.asyncio
    async def test_bad_endpoint_raises_connection_error(self):
        bad_client = PreClickClient(endpoint="not-a-url")
        with pytest.raises(PreClickConnectionError) as exc_info:
            await bad_client.connect()
        assert exc_info.value.retryable is False
        await bad_client.close()


# =====================================================================
# Full tier -- requires PRECLICK_API_KEY
# =====================================================================


@pytest.mark.skipif(not HAS_API_KEY, reason="PRECLICK_API_KEY not set")
class TestFull:
    @pytest.mark.asyncio
    async def test_scan_with_intent_returns_alignment(self, client):
        result = await client.scan_with_intent(
            SAFE_URL, SAFE_INTENT, max_wait=SCAN_TIMEOUT
        )
        assert isinstance(result["risk_score"], (int, float))
        assert isinstance(result["intent_alignment"], str)

        valid_alignments = [
            "misaligned",
            "no_mismatch_detected",
            "inconclusive",
        ]
        assert result["intent_alignment"] in valid_alignments

    @pytest.mark.asyncio
    async def test_start_scan_with_intent_returns_envelope(self, client):
        submission = await client.start_scan_with_intent(
            SAFE_URL, SAFE_INTENT
        )
        assert isinstance(submission["scan_id"], str)
        assert len(submission["scan_id"]) > 0

    @pytest.mark.asyncio
    async def test_get_scan_status_returns_status(self, client):
        submission = await client.start_scan(SAFE_URL)
        status = await client.get_scan_status(submission["scan_id"])
        assert status["scan_id"] == submission["scan_id"]
        assert status["status"] in (
            "working",
            "completed",
            "failed",
            "cancelled",
        )

    @pytest.mark.asyncio
    async def test_get_scan_result_after_completion(self, client):
        submission = await client.start_scan(SAFE_URL)
        await client.wait_for_scan(
            submission["scan_id"], max_wait=SCAN_TIMEOUT
        )
        envelope = await client.get_scan_result(submission["scan_id"])
        assert envelope["scan_id"] == submission["scan_id"]
        assert envelope["status"] == "completed"
        assert isinstance(envelope["result"], dict)
        assert isinstance(envelope["result"]["risk_score"], (int, float))

    @pytest.mark.asyncio
    async def test_wait_for_scan_returns_result(self, client):
        submission = await client.start_scan(SAFE_URL)
        result = await client.wait_for_scan(
            submission["scan_id"], max_wait=SCAN_TIMEOUT
        )
        assert isinstance(result["risk_score"], (int, float))
        assert isinstance(result["agent_access_directive"], str)

    @pytest.mark.asyncio
    async def test_close_and_reconnect(self, client):
        await client.connect()
        assert client.is_connected is True

        await client.close()
        assert client.is_connected is False

        # New scan auto-reconnects
        submission = await client.start_scan(SAFE_URL)
        assert client.is_connected is True
        assert isinstance(submission["scan_id"], str)

    @pytest.mark.asyncio
    async def test_get_scan_result_with_bogus_id(self, client):
        with pytest.raises((PreClickRemoteError, PreClickError)):
            await client.get_scan_result("nonexistent-scan-id-12345")