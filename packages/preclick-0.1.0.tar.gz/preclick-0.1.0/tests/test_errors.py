# Copyright 2026 CybrLab.ai
# SPDX-License-Identifier: Apache-2.0

"""
Error class hierarchy and helper tests.
"""

import asyncio

import pytest

from preclick import (
    PreClickConnectionError,
    PreClickError,
    PreClickRemoteError,
)
from mcp.shared.exceptions import McpError
from mcp.types import ErrorData

from preclick._client import (
    _get_mcp_error_code,
    _get_mcp_error_data,
    _is_known_non_retryable_transport_error,
    _is_known_transport_error,
    _is_retryable_connection_failure,
    _is_retryable_poll_error,
    _is_valid_poll_hint,
    _should_retry_call_error,
    _wrap_as_remote_error,
)


# ------------------------------------------------------------------
# Error hierarchy
# ------------------------------------------------------------------


class TestErrorHierarchy:
    def test_connection_error_is_preclick_error(self):
        err = PreClickConnectionError("fail")
        assert isinstance(err, PreClickError)
        assert isinstance(err, Exception)

    def test_remote_error_is_preclick_error(self):
        err = PreClickRemoteError("fail")
        assert isinstance(err, PreClickError)
        assert isinstance(err, Exception)

    def test_connection_error_default_retryable(self):
        err = PreClickConnectionError("fail")
        assert err.retryable is True

    def test_connection_error_non_retryable(self):
        err = PreClickConnectionError("fail", retryable=False)
        assert err.retryable is False

    def test_remote_error_carries_code_and_data(self):
        err = PreClickRemoteError("fail", code=429, data={"limit": 100})
        assert err.code == 429
        assert err.data == {"limit": 100}

    def test_remote_error_defaults(self):
        err = PreClickRemoteError("fail")
        assert err.code is None
        assert err.data is None

    def test_error_message_accessible(self):
        err = PreClickError("test message")
        assert str(err) == "test message"

    def test_error_supports_cause_chain(self):
        cause = ValueError("root cause")
        try:
            raise PreClickError("wrapper") from cause
        except PreClickError as err:
            assert err.__cause__ is cause


# ------------------------------------------------------------------
# _wrap_as_remote_error
# ------------------------------------------------------------------


class TestWrapAsRemoteError:
    def test_passes_through_preclick_error(self):
        orig = PreClickError("already wrapped")
        assert _wrap_as_remote_error(orig, "test_tool") is orig

    def test_passes_through_connection_error(self):
        orig = PreClickConnectionError("conn fail")
        assert _wrap_as_remote_error(orig, "test_tool") is orig

    def test_passes_through_remote_error(self):
        orig = PreClickRemoteError("remote fail")
        assert _wrap_as_remote_error(orig, "test_tool") is orig

    def test_wraps_connection_error_for_transport_failures(self):
        orig = ConnectionRefusedError("refused")
        result = _wrap_as_remote_error(orig, "test_tool")
        assert isinstance(result, PreClickConnectionError)
        assert result.retryable is True

    def test_wraps_timeout_as_connection_error(self):
        orig = TimeoutError("timed out")
        result = _wrap_as_remote_error(orig, "test_tool")
        assert isinstance(result, PreClickConnectionError)

    def test_wraps_unknown_as_preclick_error(self):
        orig = RuntimeError("unknown")
        result = _wrap_as_remote_error(orig, "test_tool")
        assert isinstance(result, PreClickError)
        assert not isinstance(result, PreClickConnectionError)
        assert not isinstance(result, PreClickRemoteError)

    def test_wraps_mcp_error_preserving_code_and_data(self):
        orig = McpError(
            ErrorData(code=-32001, message="timeout", data={"k": "v"})
        )
        result = _wrap_as_remote_error(orig, "test_tool")
        assert isinstance(result, PreClickRemoteError)
        assert result.code == -32001
        assert result.data == {"k": "v"}


# ------------------------------------------------------------------
# _should_retry_call_error
# ------------------------------------------------------------------


class TestShouldRetryCallError:
    def test_retries_on_retryable_connection_error(self):
        err = PreClickConnectionError("fail", retryable=True)
        assert _should_retry_call_error(err, 0) is True

    def test_no_retry_on_non_retryable_connection_error(self):
        err = PreClickConnectionError("fail", retryable=False)
        assert _should_retry_call_error(err, 0) is False

    def test_no_retry_on_second_attempt(self):
        err = PreClickConnectionError("fail", retryable=True)
        assert _should_retry_call_error(err, 1) is False

    def test_no_retry_on_cancelled_error(self):
        err = asyncio.CancelledError()
        assert _should_retry_call_error(err, 0) is False

    def test_retries_on_connection_refused(self):
        err = ConnectionRefusedError("refused")
        assert _should_retry_call_error(err, 0) is True

    def test_retries_on_timeout(self):
        err = TimeoutError("timed out")
        assert _should_retry_call_error(err, 0) is True

    def test_retries_on_mcp_request_timeout(self):
        err = McpError(ErrorData(code=-32001, message="Request timed out"))
        assert _should_retry_call_error(err, 0) is True

    def test_no_retry_on_mcp_non_timeout_code(self):
        err = McpError(ErrorData(code=-32600, message="Invalid request"))
        assert _should_retry_call_error(err, 0) is False


# ------------------------------------------------------------------
# _is_retryable_poll_error
# ------------------------------------------------------------------


class TestIsRetryablePollError:
    def test_retryable_connection_error(self):
        err = PreClickConnectionError("fail", retryable=True)
        assert _is_retryable_poll_error(err) is True

    def test_non_retryable_connection_error(self):
        err = PreClickConnectionError("fail", retryable=False)
        assert _is_retryable_poll_error(err) is False

    def test_cancelled_error_not_retryable(self):
        err = asyncio.CancelledError()
        assert _is_retryable_poll_error(err) is False

    def test_remote_error_with_retryable_code(self):
        for code in [408, 429, 502, 503, 504, -32001]:
            err = PreClickRemoteError("fail", code=code)
            assert _is_retryable_poll_error(err) is True, (
                f"code {code} should be retryable"
            )

    def test_remote_error_with_non_retryable_code(self):
        err = PreClickRemoteError("fail", code=400)
        assert _is_retryable_poll_error(err) is False

    def test_plain_preclick_error_not_retryable(self):
        err = PreClickError("fail")
        assert _is_retryable_poll_error(err) is False

    def test_respects_explicit_zero_code(self):
        """code=0 is falsy but should be used, not skipped (nullish parity)."""
        err = PreClickRemoteError("fail", code=0)
        assert _is_retryable_poll_error(err) is False  # 0 is not retryable


# ------------------------------------------------------------------
# _is_known_transport_error
# ------------------------------------------------------------------


class TestIsKnownTransportError:
    def test_connection_error(self):
        assert _is_known_transport_error(ConnectionError("fail")) is True

    def test_connection_refused(self):
        assert _is_known_transport_error(ConnectionRefusedError("fail")) is True

    def test_connection_reset(self):
        assert _is_known_transport_error(ConnectionResetError("fail")) is True

    def test_broken_pipe(self):
        assert _is_known_transport_error(BrokenPipeError("fail")) is True

    def test_timeout_error(self):
        assert _is_known_transport_error(TimeoutError("fail")) is True

    def test_raw_os_error_not_transport(self):
        assert _is_known_transport_error(OSError("fail")) is False

    def test_file_not_found_not_transport(self):
        assert _is_known_transport_error(FileNotFoundError("fail")) is False

    def test_permission_error_not_transport(self):
        assert _is_known_transport_error(PermissionError("fail")) is False

    def test_runtime_error_not_transport(self):
        assert _is_known_transport_error(RuntimeError("fail")) is False

    def test_none_not_transport(self):
        assert _is_known_transport_error(None) is False  # type: ignore[arg-type]

    def test_httpx_connect_error(self):
        import httpx

        err = httpx.ConnectError("connection refused")
        assert _is_known_transport_error(err) is True

    def test_httpx_read_timeout(self):
        import httpx

        err = httpx.ReadTimeout("read timed out")
        assert _is_known_transport_error(err) is True

    def test_httpx_connect_timeout(self):
        import httpx

        err = httpx.ConnectTimeout("connect timed out")
        assert _is_known_transport_error(err) is True

    def test_httpx_network_error(self):
        import httpx

        err = httpx.NetworkError("network fail")
        assert _is_known_transport_error(err) is True

    def test_httpx_remote_protocol_error(self):
        import httpx

        err = httpx.RemoteProtocolError("peer closed connection")
        assert _is_known_transport_error(err) is True


# ------------------------------------------------------------------
# _is_known_non_retryable_transport_error
# ------------------------------------------------------------------


class TestIsKnownNonRetryableTransportError:
    def _make_ssl_error(self, reason: str) -> OSError:
        """Build a fake SSLCertVerificationError with a reason attribute."""
        err = OSError(reason)
        err.reason = reason  # type: ignore[attr-defined]
        return err

    def test_cert_has_expired(self):
        err = self._make_ssl_error("CERT_HAS_EXPIRED")
        assert _is_known_non_retryable_transport_error(err) is True

    def test_self_signed_cert(self):
        err = self._make_ssl_error("DEPTH_ZERO_SELF_SIGNED_CERT")
        assert _is_known_non_retryable_transport_error(err) is True

    def test_certificate_verify_failed(self):
        err = self._make_ssl_error("CERTIFICATE_VERIFY_FAILED")
        assert _is_known_non_retryable_transport_error(err) is True

    def test_regular_os_error_is_retryable(self):
        err = OSError("Connection refused")
        assert _is_known_non_retryable_transport_error(err) is False

    def test_nested_cause_ssl_error(self):
        inner = self._make_ssl_error("SELF_SIGNED_CERT_IN_CHAIN")
        outer = OSError("wrapper")
        outer.__cause__ = inner
        assert _is_known_non_retryable_transport_error(outer) is True

    def test_non_exception_returns_false(self):
        assert _is_known_non_retryable_transport_error(None) is False  # type: ignore[arg-type]

    def test_runtime_error_returns_false(self):
        assert _is_known_non_retryable_transport_error(RuntimeError("fail")) is False


# ------------------------------------------------------------------
# _is_retryable_connection_failure
# ------------------------------------------------------------------


class TestIsRetryableConnectionFailure:
    def test_ssl_error_not_retryable(self):
        err = OSError("CERT_HAS_EXPIRED")
        err.reason = "CERT_HAS_EXPIRED"  # type: ignore[attr-defined]
        assert _is_retryable_connection_failure(err) is False

    def test_connection_refused_is_retryable(self):
        assert _is_retryable_connection_failure(ConnectionRefusedError("refused")) is True

    def test_timeout_is_retryable(self):
        assert _is_retryable_connection_failure(TimeoutError("timed out")) is True

    def test_unknown_error_not_retryable(self):
        assert _is_retryable_connection_failure(RuntimeError("unknown")) is False

    def test_raw_os_error_not_retryable(self):
        assert _is_retryable_connection_failure(OSError("fail")) is False

    def test_httpx_connect_error_is_retryable(self):
        import httpx

        assert _is_retryable_connection_failure(httpx.ConnectError("refused")) is True

    def test_httpx_timeout_is_retryable(self):
        import httpx

        assert _is_retryable_connection_failure(httpx.ConnectTimeout("timed out")) is True

    def test_httpx_remote_protocol_error_is_retryable(self):
        import httpx

        err = httpx.RemoteProtocolError("peer closed connection")
        assert _is_retryable_connection_failure(err) is True


# ------------------------------------------------------------------
# _get_mcp_error_code / _get_mcp_error_data
# ------------------------------------------------------------------


class TestGetMcpErrorCode:
    def test_extracts_code_from_error_data(self):
        err = McpError(ErrorData(code=-32001, message="timeout"))
        assert _get_mcp_error_code(err) == -32001

    def test_extracts_data_from_error_data(self):
        err = McpError(
            ErrorData(code=-32600, message="bad", data={"detail": "x"})
        )
        assert _get_mcp_error_data(err) == {"detail": "x"}

    def test_returns_none_when_no_data_payload(self):
        err = McpError(ErrorData(code=-32600, message="bad"))
        assert _get_mcp_error_data(err) is None


# ------------------------------------------------------------------
# _is_valid_poll_hint
# ------------------------------------------------------------------


class TestIsValidPollHint:
    def test_positive_int(self):
        assert _is_valid_poll_hint(2000) is True

    def test_positive_float(self):
        assert _is_valid_poll_hint(1500.5) is True

    def test_zero_rejected(self):
        assert _is_valid_poll_hint(0) is False

    def test_negative_rejected(self):
        assert _is_valid_poll_hint(-1) is False

    def test_bool_rejected(self):
        assert _is_valid_poll_hint(True) is False

    def test_nan_rejected(self):
        assert _is_valid_poll_hint(float("nan")) is False

    def test_inf_rejected(self):
        assert _is_valid_poll_hint(float("inf")) is False

    def test_string_rejected(self):
        assert _is_valid_poll_hint("2000") is False

    def test_none_rejected(self):
        assert _is_valid_poll_hint(None) is False
