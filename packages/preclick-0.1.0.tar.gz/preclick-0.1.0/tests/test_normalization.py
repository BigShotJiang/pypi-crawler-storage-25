# Copyright 2026 CybrLab.ai
# SPDX-License-Identifier: Apache-2.0

"""
Envelope normalization and tool-result unwrapping tests.
"""

import json
from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest

from preclick import PreClickRemoteError
from preclick._client import _normalize_scan_envelope, _unwrap_tool_result


# ------------------------------------------------------------------
# _unwrap_tool_result
# ------------------------------------------------------------------


class TestUnwrapToolResult:
    def test_prefers_structured_content(self):
        result = SimpleNamespace(
            structuredContent={"task_id": "abc", "status": "working"},
            content=[],
        )
        assert _unwrap_tool_result(result) == {
            "task_id": "abc",
            "status": "working",
        }

    def test_json_parses_first_text_content(self):
        payload = {"task_id": "abc", "status": "completed"}
        result = SimpleNamespace(
            structuredContent=None,
            content=[SimpleNamespace(text=json.dumps(payload))],
        )
        assert _unwrap_tool_result(result) == payload

    def test_returns_raw_text_on_invalid_json(self):
        result = SimpleNamespace(
            structuredContent=None,
            content=[SimpleNamespace(text="not json")],
        )
        assert _unwrap_tool_result(result) == "not json"

    def test_returns_result_unchanged_on_no_content(self):
        result = SimpleNamespace(structuredContent=None, content=[])
        assert _unwrap_tool_result(result) is result

    def test_returns_none_unchanged(self):
        assert _unwrap_tool_result(None) is None


# ------------------------------------------------------------------
# _normalize_scan_envelope
# ------------------------------------------------------------------


class TestNormalizeScanEnvelope:
    def test_renames_task_id_to_scan_id(self):
        envelope = {"task_id": "abc-123", "status": "working"}
        out = _normalize_scan_envelope(envelope)
        assert out["scan_id"] == "abc-123"
        assert "task_id" not in out

    def test_passes_through_snake_case_fields(self):
        envelope = {
            "task_id": "id-1",
            "status": "working",
            "status_message": "Queued",
            "created_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:01Z",
            "ttl_ms": 720000,
            "poll_interval_ms": 2000,
            "retry_after_ms": 3000,
            "message": "Processing",
        }
        out = _normalize_scan_envelope(envelope)
        assert out["scan_id"] == "id-1"
        assert out["status"] == "working"
        assert out["status_message"] == "Queued"
        assert out["created_at"] == "2026-01-01T00:00:00Z"
        assert out["updated_at"] == "2026-01-01T00:00:01Z"
        assert out["ttl_ms"] == 720000
        assert out["poll_interval_ms"] == 2000
        assert out["retry_after_ms"] == 3000
        assert out["message"] == "Processing"

    def test_preserves_result_payload(self):
        result = {
            "risk_score": 0.1,
            "confidence": 0.95,
            "analysis_complete": True,
            "agent_access_directive": "ALLOW",
            "agent_access_reason": "safe",
            "intent_alignment": "not_provided",
        }
        envelope = {
            "task_id": "id-1",
            "status": "completed",
            "result": result,
        }
        out = _normalize_scan_envelope(envelope)
        assert out["result"] is result

    def test_drops_unknown_fields(self, caplog):
        envelope = {
            "task_id": "id-1",
            "status": "working",
            "unknown_field": "surprise",
        }
        with caplog.at_level("WARNING", logger="preclick"):
            out = _normalize_scan_envelope(envelope)
        assert "unknown_field" not in out
        assert "Unknown envelope fields" in caplog.text

    def test_rejects_non_dict_envelope(self):
        with pytest.raises(PreClickRemoteError, match="Malformed"):
            _normalize_scan_envelope("not a dict")

    def test_rejects_none_envelope(self):
        with pytest.raises(PreClickRemoteError, match="Malformed"):
            _normalize_scan_envelope(None)

    def test_rejects_list_envelope(self):
        with pytest.raises(PreClickRemoteError, match="Malformed"):
            _normalize_scan_envelope([1, 2, 3])

    def test_empty_envelope_returns_empty_dict(self):
        out = _normalize_scan_envelope({})
        assert out == {}

    def test_only_includes_present_keys(self):
        envelope = {"task_id": "id-1", "status": "working"}
        out = _normalize_scan_envelope(envelope)
        assert set(out.keys()) == {"scan_id", "status"}