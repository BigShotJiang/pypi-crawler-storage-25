# Copyright 2026 CybrLab.ai
# SPDX-License-Identifier: Apache-2.0

"""
End-to-end client behavior tests with a fake MCP session.
"""

import asyncio
import json
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

import pytest

from preclick import (
    PreClickClient,
    PreClickConnectionError,
    PreClickError,
    PreClickRemoteError,
)


def _make_tool_result(payload: dict, *, is_error: bool = False):
    """Build a fake MCP CallToolResult."""
    return SimpleNamespace(
        isError=is_error,
        structuredContent=payload,
        content=[],
    )


def _submission_envelope(
    scan_id: str = "test-scan-id",
    status: str = "working",
):
    return {
        "task_id": scan_id,
        "status": status,
        "status_message": "Queued",
        "created_at": "2026-01-01T00:00:00Z",
        "updated_at": "2026-01-01T00:00:00Z",
        "ttl_ms": 720000,
        "poll_interval_ms": 2000,
        "message": "Scan submitted.",
    }


def _completed_envelope(scan_id: str = "test-scan-id"):
    return {
        "task_id": scan_id,
        "status": "completed",
        "status_message": "Done",
        "result": {
            "risk_score": 0.1,
            "confidence": 0.95,
            "analysis_complete": True,
            "agent_access_directive": "ALLOW",
            "agent_access_reason": "safe",
            "intent_alignment": "not_provided",
        },
    }


def _working_envelope(
    scan_id: str = "test-scan-id",
    retry_after_ms: int = 100,
):
    return {
        "task_id": scan_id,
        "status": "working",
        "status_message": "Processing",
        "result": None,
        "retry_after_ms": retry_after_ms,
    }


def _make_client_with_fake_session(call_tool_side_effect):
    """Create a PreClickClient with a mocked MCP session."""
    client = PreClickClient()
    client._session = AsyncMock()
    client._session.call_tool = AsyncMock(side_effect=call_tool_side_effect)
    # No-op delay for fast tests
    client._delay = AsyncMock()
    return client


# ------------------------------------------------------------------
# scan() happy path
# ------------------------------------------------------------------


class TestScanHappyPath:
    @pytest.mark.asyncio
    async def test_scan_returns_result_on_immediate_completion(self):
        responses = [
            _make_tool_result(_submission_envelope()),
            _make_tool_result(_completed_envelope()),
        ]
        idx = 0

        async def fake_call_tool(name, args):
            nonlocal idx
            result = responses[idx]
            idx += 1
            return result

        client = _make_client_with_fake_session(None)
        client._session.call_tool = AsyncMock(side_effect=fake_call_tool)

        result = await client.scan("https://example.com")
        assert result["agent_access_directive"] == "ALLOW"
        assert result["risk_score"] == 0.1

    @pytest.mark.asyncio
    async def test_scan_polls_until_completed(self):
        responses = [
            _make_tool_result(_submission_envelope()),
            _make_tool_result(_working_envelope()),
            _make_tool_result(_working_envelope()),
            _make_tool_result(_completed_envelope()),
        ]
        call_count = 0

        async def fake_call_tool(name, args):
            nonlocal call_count
            result = responses[call_count]
            call_count += 1
            return result

        client = _make_client_with_fake_session(None)
        client._session.call_tool = AsyncMock(side_effect=fake_call_tool)

        result = await client.scan("https://example.com")
        assert result["agent_access_directive"] == "ALLOW"
        assert call_count == 4  # submit + 2 working + completed


# ------------------------------------------------------------------
# scan_with_intent()
# ------------------------------------------------------------------


class TestScanWithIntent:
    @pytest.mark.asyncio
    async def test_scan_with_intent_returns_result(self):
        completed = _completed_envelope()
        completed["result"]["intent_alignment"] = "no_mismatch_detected"
        responses = [
            _make_tool_result(_submission_envelope()),
            _make_tool_result(completed),
        ]
        idx = 0

        async def fake_call_tool(name, args):
            nonlocal idx
            result = responses[idx]
            idx += 1
            return result

        client = _make_client_with_fake_session(None)
        client._session.call_tool = AsyncMock(side_effect=fake_call_tool)

        result = await client.scan_with_intent(
            "https://example.com", "log in"
        )
        assert result["intent_alignment"] == "no_mismatch_detected"


# ------------------------------------------------------------------
# Job methods
# ------------------------------------------------------------------


class TestJobMethods:
    @pytest.mark.asyncio
    async def test_start_scan_returns_envelope_with_scan_id(self):
        client = _make_client_with_fake_session(None)
        client._session.call_tool = AsyncMock(
            return_value=_make_tool_result(_submission_envelope("my-id"))
        )
        envelope = await client.start_scan("https://example.com")
        assert envelope["scan_id"] == "my-id"
        assert envelope["status"] == "working"

    @pytest.mark.asyncio
    async def test_get_scan_status_returns_normalized_envelope(self):
        status_data = {
            "task_id": "my-id",
            "status": "working",
            "status_message": "Processing",
            "poll_interval_ms": 2000,
        }
        client = _make_client_with_fake_session(None)
        client._session.call_tool = AsyncMock(
            return_value=_make_tool_result(status_data)
        )
        envelope = await client.get_scan_status("my-id")
        assert envelope["scan_id"] == "my-id"
        assert "task_id" not in envelope

    @pytest.mark.asyncio
    async def test_get_scan_result_returns_envelope(self):
        client = _make_client_with_fake_session(None)
        client._session.call_tool = AsyncMock(
            return_value=_make_tool_result(_completed_envelope("my-id"))
        )
        envelope = await client.get_scan_result("my-id")
        assert envelope["status"] == "completed"
        assert envelope["result"]["risk_score"] == 0.1


# ------------------------------------------------------------------
# Error handling in wait loop
# ------------------------------------------------------------------


class TestWaitLoopErrors:
    @pytest.mark.asyncio
    async def test_failed_status_raises_remote_error(self):
        failed = {
            "task_id": "my-id",
            "status": "failed",
            "status_message": "scan failed",
        }
        responses = [
            _make_tool_result(_submission_envelope("my-id")),
            _make_tool_result(failed),
        ]
        idx = 0

        async def fake_call_tool(name, args):
            nonlocal idx
            result = responses[idx]
            idx += 1
            return result

        client = _make_client_with_fake_session(None)
        client._session.call_tool = AsyncMock(side_effect=fake_call_tool)

        with pytest.raises(PreClickRemoteError, match="unexpected status"):
            await client.scan("https://example.com")

    @pytest.mark.asyncio
    async def test_timeout_raises_preclick_error_with_scan_id(self):
        responses = [
            _make_tool_result(_submission_envelope("my-id")),
        ]
        call_count = 0

        async def fake_call_tool(name, args):
            nonlocal call_count
            if call_count == 0:
                call_count += 1
                return responses[0]
            return _make_tool_result(_working_envelope("my-id", 100))

        client = _make_client_with_fake_session(None)
        client._session.call_tool = AsyncMock(side_effect=fake_call_tool)

        with pytest.raises(PreClickError, match="exhausted") as exc_info:
            await client.scan("https://example.com", max_wait=0.01)

        assert getattr(exc_info.value, "scan_id", None) == "my-id"

    @pytest.mark.asyncio
    async def test_completed_with_missing_result_raises(self):
        bad_completed = {
            "task_id": "my-id",
            "status": "completed",
            "result": None,
        }
        responses = [
            _make_tool_result(_submission_envelope("my-id")),
            _make_tool_result(bad_completed),
        ]
        idx = 0

        async def fake_call_tool(name, args):
            nonlocal idx
            result = responses[idx]
            idx += 1
            return result

        client = _make_client_with_fake_session(None)
        client._session.call_tool = AsyncMock(side_effect=fake_call_tool)

        with pytest.raises(PreClickRemoteError, match="missing or malformed"):
            await client.scan("https://example.com")


# ------------------------------------------------------------------
# Cancellation signal support
# ------------------------------------------------------------------


class TestCancellationSignal:
    @pytest.mark.asyncio
    async def test_scan_rejects_pre_set_signal_without_submitting(self):
        signal = asyncio.Event()
        signal.set()
        client = _make_client_with_fake_session(None)

        with pytest.raises(asyncio.CancelledError):
            await client.scan("https://example.com", signal=signal)

        client._session.call_tool.assert_not_called()

    @pytest.mark.asyncio
    async def test_start_scan_rejects_pre_set_signal_without_submitting(self):
        signal = asyncio.Event()
        signal.set()
        client = _make_client_with_fake_session(None)

        with pytest.raises(asyncio.CancelledError):
            await client.start_scan("https://example.com", signal=signal)

        client._session.call_tool.assert_not_called()

    @pytest.mark.asyncio
    async def test_scan_signal_abort_during_poll_delay_attaches_scan_id(self):
        signal = asyncio.Event()
        responses = [
            _make_tool_result(_submission_envelope("my-id")),
            _make_tool_result(_working_envelope("my-id", 10_000)),
        ]
        idx = 0

        async def fake_call_tool(name, args):
            nonlocal idx
            result = responses[idx]
            idx += 1
            if idx == 2:
                signal.set()
            return result

        client = PreClickClient()
        client._session = AsyncMock()
        client._session.call_tool = AsyncMock(side_effect=fake_call_tool)

        with pytest.raises(asyncio.CancelledError) as exc_info:
            await client.scan("https://example.com", signal=signal)

        assert getattr(exc_info.value, "scan_id", None) == "my-id"

    @pytest.mark.asyncio
    async def test_signal_abort_cancels_in_flight_call(self):
        signal = asyncio.Event()
        started = asyncio.Event()

        async def fake_call_tool(name, args):
            started.set()
            await asyncio.sleep(10)

        client = _make_client_with_fake_session(None)
        client._session.call_tool = AsyncMock(side_effect=fake_call_tool)

        task = asyncio.create_task(
            client.start_scan("https://example.com", signal=signal)
        )
        await started.wait()
        signal.set()

        with pytest.raises(asyncio.CancelledError):
            await task


# ------------------------------------------------------------------
# Submission envelope validation
# ------------------------------------------------------------------


class TestSubmissionValidation:
    @pytest.mark.asyncio
    async def test_missing_task_id_raises(self):
        bad_envelope = {"status": "working"}  # no task_id
        client = _make_client_with_fake_session(None)
        client._session.call_tool = AsyncMock(
            return_value=_make_tool_result(bad_envelope)
        )
        with pytest.raises(PreClickRemoteError, match="missing task_id"):
            await client.start_scan("https://example.com")


# ------------------------------------------------------------------
# Lifecycle
# ------------------------------------------------------------------


class TestLifecycle:
    @pytest.mark.asyncio
    async def test_close_when_not_connected_is_safe(self):
        client = PreClickClient()
        await client.close()  # should not raise

    @pytest.mark.asyncio
    async def test_is_connected_false_after_close(self):
        client = _make_client_with_fake_session(None)
        assert client.is_connected is True
        # Mock cleanup to prevent real context manager calls
        client._session_ctx = None
        client._transport_ctx = None
        await client.close()
        assert client.is_connected is False

    @pytest.mark.asyncio
    async def test_context_manager_calls_close(self):
        client = PreClickClient()
        async with client:
            pass
        assert client.is_connected is False


# ------------------------------------------------------------------
# Invalid endpoint
# ------------------------------------------------------------------


class TestInvalidEndpoint:
    @pytest.mark.asyncio
    async def test_bad_endpoint_raises_non_retryable_connection_error(self):
        client = PreClickClient(endpoint="not-a-url")
        with pytest.raises(PreClickConnectionError) as exc_info:
            await client.connect()
        assert exc_info.value.retryable is False


# ------------------------------------------------------------------
# Client identity reported to MCP
# ------------------------------------------------------------------


class TestClientInfo:
    @pytest.mark.asyncio
    async def test_connect_passes_client_info_to_session(self):
        """ClientSession must receive client_name and client_version."""
        from unittest.mock import AsyncMock, MagicMock, patch

        client = PreClickClient(
            client_name="my-agent",
            client_version="1.2.3",
            endpoint="https://preclick.ai/mcp",
        )

        captured_kwargs: dict = {}
        original_init = None

        class FakeSession:
            def __init__(self, *args, **kwargs):
                captured_kwargs.update(kwargs)

            async def __aenter__(self):
                session = AsyncMock()
                session.initialize = AsyncMock()
                return session

            async def __aexit__(self, *exc):
                pass

        fake_transport = MagicMock()

        async def fake_transport_enter(*a, **kw):
            return (AsyncMock(), AsyncMock(), None)

        fake_transport.__aenter__ = fake_transport_enter
        fake_transport.__aexit__ = AsyncMock()

        with (
            patch(
                "preclick._client.streamable_http_client",
                return_value=fake_transport,
            ),
            patch(
                "preclick._client.ClientSession",
                FakeSession,
            ),
        ):
            await client.connect()

        info = captured_kwargs.get("client_info")
        assert info is not None
        assert info.name == "my-agent"
        assert info.version == "1.2.3"
