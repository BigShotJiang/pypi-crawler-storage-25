# Copyright 2026 CybrLab.ai
# SPDX-License-Identifier: Apache-2.0

"""
Constructor and method input validation tests.
"""

import pytest

from preclick import PreClickClient, PreClickError


# ------------------------------------------------------------------
# Constructor validation
# ------------------------------------------------------------------


class TestConstructorValidation:
    def test_default_options_accepted(self):
        client = PreClickClient()
        assert client.endpoint == "https://preclick.ai/mcp"
        assert client.api_key is None
        assert client.is_connected is False

    def test_api_key_must_be_string(self):
        with pytest.raises(PreClickError, match="api_key.*string"):
            PreClickClient(api_key=123)  # type: ignore[arg-type]

    def test_api_key_must_be_non_empty(self):
        with pytest.raises(PreClickError, match="non-empty"):
            PreClickClient(api_key="")

    def test_api_key_none_accepted(self):
        client = PreClickClient(api_key=None)
        assert client.api_key is None

    def test_endpoint_must_be_string(self):
        with pytest.raises(PreClickError, match="endpoint.*string"):
            PreClickClient(endpoint=123)  # type: ignore[arg-type]

    def test_client_name_must_be_string(self):
        with pytest.raises(PreClickError, match="client_name.*string"):
            PreClickClient(client_name=123)  # type: ignore[arg-type]

    def test_client_version_must_be_string(self):
        with pytest.raises(PreClickError, match="client_version.*string"):
            PreClickClient(client_version=123)  # type: ignore[arg-type]

    def test_headers_must_be_dict(self):
        with pytest.raises(PreClickError, match="headers.*dict"):
            PreClickClient(headers="bad")  # type: ignore[arg-type]

    def test_headers_must_be_dict_not_list(self):
        with pytest.raises(PreClickError, match="headers.*dict"):
            PreClickClient(headers=["bad"])  # type: ignore[arg-type]

    def test_header_name_must_be_non_empty(self):
        with pytest.raises(PreClickError, match="header name"):
            PreClickClient(headers={"": "value"})

    def test_header_value_must_be_string(self):
        with pytest.raises(PreClickError, match="headers.*string"):
            PreClickClient(headers={"X-Foo": 123})  # type: ignore[dict-item]

    def test_request_timeout_must_be_positive(self):
        with pytest.raises(PreClickError, match="request_timeout"):
            PreClickClient(request_timeout=0)

    def test_request_timeout_must_be_number(self):
        with pytest.raises(PreClickError, match="request_timeout"):
            PreClickClient(request_timeout="bad")  # type: ignore[arg-type]

    def test_negative_request_timeout_rejected(self):
        with pytest.raises(PreClickError, match="request_timeout"):
            PreClickClient(request_timeout=-1)

    def test_request_timeout_rejects_bool(self):
        with pytest.raises(PreClickError, match="request_timeout"):
            PreClickClient(request_timeout=True)  # type: ignore[arg-type]

    def test_request_timeout_rejects_nan(self):
        with pytest.raises(PreClickError, match="request_timeout"):
            PreClickClient(request_timeout=float("nan"))

    def test_request_timeout_rejects_inf(self):
        with pytest.raises(PreClickError, match="request_timeout"):
            PreClickClient(request_timeout=float("inf"))


# ------------------------------------------------------------------
# Method input validation
# ------------------------------------------------------------------


class TestMethodValidation:
    @pytest.fixture()
    def client(self):
        return PreClickClient()

    @pytest.mark.asyncio
    async def test_scan_rejects_empty_url(self, client):
        with pytest.raises(PreClickError, match="url"):
            await client.scan("")

    @pytest.mark.asyncio
    async def test_scan_rejects_non_string_url(self, client):
        with pytest.raises(PreClickError, match="url"):
            await client.scan(123)  # type: ignore[arg-type]

    @pytest.mark.asyncio
    async def test_scan_rejects_invalid_max_wait(self, client):
        with pytest.raises(PreClickError, match="max_wait"):
            await client.scan("https://example.com", max_wait=0)

    @pytest.mark.asyncio
    async def test_scan_rejects_negative_max_wait(self, client):
        with pytest.raises(PreClickError, match="max_wait"):
            await client.scan("https://example.com", max_wait=-1)

    @pytest.mark.asyncio
    async def test_scan_rejects_bool_max_wait(self, client):
        with pytest.raises(PreClickError, match="max_wait"):
            await client.scan("https://example.com", max_wait=True)  # type: ignore[arg-type]

    @pytest.mark.asyncio
    async def test_scan_rejects_nan_max_wait(self, client):
        with pytest.raises(PreClickError, match="max_wait"):
            await client.scan("https://example.com", max_wait=float("nan"))

    @pytest.mark.asyncio
    async def test_scan_rejects_inf_max_wait(self, client):
        with pytest.raises(PreClickError, match="max_wait"):
            await client.scan("https://example.com", max_wait=float("inf"))

    @pytest.mark.asyncio
    async def test_scan_rejects_invalid_signal(self, client):
        with pytest.raises(PreClickError, match="signal"):
            await client.scan("https://example.com", signal="bad")

    @pytest.mark.asyncio
    async def test_scan_with_intent_rejects_empty_url(self, client):
        with pytest.raises(PreClickError, match="url"):
            await client.scan_with_intent("", "some intent")

    @pytest.mark.asyncio
    async def test_scan_with_intent_rejects_empty_intent(self, client):
        with pytest.raises(PreClickError, match="intent"):
            await client.scan_with_intent("https://example.com", "")

    @pytest.mark.asyncio
    async def test_scan_with_intent_rejects_non_string_intent(self, client):
        with pytest.raises(PreClickError, match="intent"):
            await client.scan_with_intent("https://example.com", 123)  # type: ignore[arg-type]

    @pytest.mark.asyncio
    async def test_start_scan_rejects_empty_url(self, client):
        with pytest.raises(PreClickError, match="url"):
            await client.start_scan("")

    @pytest.mark.asyncio
    async def test_start_scan_with_intent_rejects_empty_url(self, client):
        with pytest.raises(PreClickError, match="url"):
            await client.start_scan_with_intent("", "intent")

    @pytest.mark.asyncio
    async def test_start_scan_with_intent_rejects_empty_intent(self, client):
        with pytest.raises(PreClickError, match="intent"):
            await client.start_scan_with_intent("https://example.com", "")

    @pytest.mark.asyncio
    async def test_get_scan_status_rejects_empty_scan_id(self, client):
        with pytest.raises(PreClickError, match="scan_id"):
            await client.get_scan_status("")

    @pytest.mark.asyncio
    async def test_get_scan_result_rejects_empty_scan_id(self, client):
        with pytest.raises(PreClickError, match="scan_id"):
            await client.get_scan_result("")

    @pytest.mark.asyncio
    async def test_wait_for_scan_rejects_empty_scan_id(self, client):
        with pytest.raises(PreClickError, match="scan_id"):
            await client.wait_for_scan("")

    @pytest.mark.asyncio
    async def test_wait_for_scan_rejects_invalid_max_wait(self, client):
        with pytest.raises(PreClickError, match="max_wait"):
            await client.wait_for_scan("some-id", max_wait=0)

    @pytest.mark.asyncio
    async def test_start_scan_rejects_invalid_signal(self, client):
        with pytest.raises(PreClickError, match="signal"):
            await client.start_scan("https://example.com", signal=object())
