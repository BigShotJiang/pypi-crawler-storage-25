#!/usr/bin/env python3
# Copyright 2026 CybrLab.ai
# SPDX-License-Identifier: Apache-2.0

"""
Long-running scan -- submit once, wait later.

Use this pattern when you need to hand the scan ID off between functions,
workers, or processes before blocking on the result.  ``client.scan(url)``
is literally ``start_scan(url)`` + ``wait_for_scan(scan_id)``; this
example splits the two steps so you can see (and control) the boundary.

For the simple one-call case, see basic_scan.py.
For manual polling (UI progress, custom retry logic), see manual_polling.py.

Run with:
    python examples/long_running_scan.py https://example.com
"""

import asyncio
import os
import sys

from preclick import PreClickClient


async def main() -> None:
    url = sys.argv[1] if len(sys.argv) > 1 else "https://example.com"

    async with PreClickClient(
        api_key=os.environ.get("PRECLICK_API_KEY"),
    ) as client:
        # Step 1: submit.  Returns immediately with a scan_id you can
        # persist, hand to a worker, log, etc.
        submission = await client.start_scan(url)
        print(f"Submitted scan {submission['scan_id']}")
        print(f"  status:          {submission['status']}")
        print(f"  ttl_ms:          {submission.get('ttl_ms')}")
        print(f"  poll_interval_ms: {submission.get('poll_interval_ms')}")

        # ... later, in the same process or a different one ...

        # Step 2: wait.  Blocks until the scan completes (typically
        # 70-80 seconds).
        result = await client.wait_for_scan(submission["scan_id"])

        print(f"\nDirective: {result['agent_access_directive']}")
        print(f"Reason:    {result['agent_access_reason']}")
        print(f"Risk:      {result['risk_score']:.2f}")


if __name__ == "__main__":
    asyncio.run(main())