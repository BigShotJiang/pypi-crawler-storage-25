#!/usr/bin/env python3
# Copyright 2026 CybrLab.ai
# SPDX-License-Identifier: Apache-2.0

"""
Intent-aware URL scan -- one call, print the decision and intent alignment.

Run with:
    python examples/intent_scan.py https://example.com "log in to my account"

Pass an explicit intent whenever the user has stated their purpose (login,
purchase, download, booking, etc).  The service evaluates whether the
destination appears aligned with that intent in addition to checking for
threats.
"""

import asyncio
import os
import sys

from preclick import PreClickClient


async def main() -> None:
    url = sys.argv[1] if len(sys.argv) > 1 else "https://example.com"
    intent = sys.argv[2] if len(sys.argv) > 2 else "log in to my account"

    async with PreClickClient(
        api_key=os.environ.get("PRECLICK_API_KEY"),
    ) as client:
        print(f'Scanning {url} with intent "{intent}" ...')
        result = await client.scan_with_intent(url, intent)

        print(f"risk_score:        {result['risk_score']}")
        print(f"confidence:        {result['confidence']}")
        print(f"directive:         {result['agent_access_directive']}")
        print(f"reason:            {result['agent_access_reason']}")
        print(f"intent_alignment:  {result['intent_alignment']}")

        if result["agent_access_directive"] == "ALLOW":
            print("\nProceeding with navigation.")
        else:
            print("\nDo not navigate without further confirmation.")


if __name__ == "__main__":
    asyncio.run(main())