#!/usr/bin/env python3
# Copyright 2026 CybrLab.ai
# SPDX-License-Identifier: Apache-2.0

"""
Basic URL scan -- one call, print the decision.

Run with:
    python examples/basic_scan.py https://example.com

Optionally set PRECLICK_API_KEY for higher rate limits.  The trial tier
allows up to 100 requests per day with no key.
"""

import asyncio
import os
import sys

from preclick import PreClickClient


async def main() -> None:
    url = sys.argv[1] if len(sys.argv) > 1 else "https://example.com"

    async with PreClickClient(
        api_key=os.environ.get("PRECLICK_API_KEY"),
    ) as client:
        print(f"Scanning {url} ...")
        result = await client.scan(url)

        print(f"\nDirective:  {result['agent_access_directive']}")
        print(f"Reason:     {result['agent_access_reason']}")
        print(f"Risk:       {result['risk_score']:.2f}")
        print(f"Confidence: {result['confidence']:.2f}")


if __name__ == "__main__":
    asyncio.run(main())