#!/usr/bin/env python3
# Copyright 2026 CybrLab.ai
# SPDX-License-Identifier: Apache-2.0

"""
Manual polling pattern -- use get_scan_result in your own loop instead of
wait_for_scan when you need explicit control (integrating with an existing
job queue, reporting progress to a UI, cooperative scheduling, etc.).

For the common case, prefer wait_for_scan -- see basic_scan.py.

Run with:
    python examples/manual_polling.py https://example.com
"""

import asyncio
import os
import sys

from preclick import PreClickClient


async def main() -> None:
    url = sys.argv[1] if len(sys.argv) > 1 else "https://example.com"

    async with PreClickClient(
        api_key=os.environ.get("PRECLICK_API_KEY"),
    ) as client:
        submission = await client.start_scan(url)
        print(f"Submitted scan {submission['scan_id']}")

        # Poll until the scan finishes.  The server's retry_after_ms is
        # a hint -- respect it to avoid hammering the service.
        while True:
            envelope = await client.get_scan_result(submission["scan_id"])

            if envelope["status"] == "completed":
                result = envelope.get("result")
                if not result or not isinstance(result, dict):
                    raise RuntimeError(
                        f"Scan {submission['scan_id']} completed but "
                        "result payload is missing or malformed."
                    )
                print(f"\nDirective: {result['agent_access_directive']}")
                print(f"Reason:    {result['agent_access_reason']}")
                print(f"Risk:      {result['risk_score']:.2f}")
                break

            # Anything other than "working" is a terminal failure.
            if envelope["status"] != "working":
                raise RuntimeError(
                    f"Scan {submission['scan_id']} ended with "
                    f"status: {envelope['status']}"
                )

            # Validate retry_after_ms before using it.
            hint = envelope.get("retry_after_ms")
            if (
                isinstance(hint, (int, float))
                and hint > 0
            ):
                wait_secs = hint / 1000.0
            else:
                wait_secs = 2.0

            print(
                f"Status: {envelope['status']} "
                f"-- polling again in {wait_secs:.1f}s"
            )
            await asyncio.sleep(wait_secs)


if __name__ == "__main__":
    asyncio.run(main())