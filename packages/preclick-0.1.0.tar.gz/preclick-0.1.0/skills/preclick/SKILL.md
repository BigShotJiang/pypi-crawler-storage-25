---
name: preclick
description: Companion skill for the preclick Python package. Use PreClickClient to assess URLs for threats and intent alignment before navigation.
---

# PreClick -- Intent-aware URL security verifier for agents

You have access to a URL verification system that checks target web resources
for security threats and evaluates whether they appear to correspond to the
user's browsing goals. Use it to verify any URL **before** taking the next
step -- navigating, clicking, opening, or redirecting.

The goal is not only to detect threats but to help assess whether the target
resource appears aligned with what the user actually intends to accomplish.

## Quick start (for developers)

```bash
pip install preclick
```

```python
import asyncio
from preclick import PreClickClient

async def main():
    async with PreClickClient(
        api_key="sk-...",  # optional
    ) as client:
        result = await client.scan_with_intent(
            "https://example.com",
            "log in to my account",
        )
        print(result["agent_access_directive"])

asyncio.run(main())
```

Trial mode currently allows up to 100 requests/day with no API key and no
sign-up required. Trial limits, availability, and higher-limit access are
subject to change and may be governed by separate hosted-service terms. For
higher limits, contact contact@cybrlab.ai.

## Hosted service and data sent

This package is open-source client software for the hosted PreClick service.
No scanner logic runs locally when using the default endpoint.

Calls to `scan()` / `start_scan()` send the target URL to
`https://preclick.ai/mcp`. Calls to `scan_with_intent()` /
`start_scan_with_intent()` send both the target URL and the user intent text.
If configured, the API key is sent as an `X-API-Key` header, along with any
custom headers passed to the client.

Do not submit secrets, credentials, highly sensitive personal data, regulated
data, private/internal URLs, or confidential business information unless the
user is authorized to do so and the applicable service, privacy, retention,
and acceptable-use terms permit that use. For hosted-service terms or privacy
questions, contact contact@cybrlab.ai.

## When to verify

Verify a URL before any of these actions:

- Opening a link the user provides or that you discover
- Navigating to a page on the user's behalf
- Following a redirect chain
- Downloading a file from a URL
- Submitting credentials to a login page
- Taking any action where the destination matters to the outcome

Do not verify URLs that are internal references (localhost, `file://`, or
intranet addresses the user is already working with).

## Which method to use

**`client.scan(url)`** -- Threat-focused verification.
- Required parameter: `url`.
- Returns the completed scan result in a single call. Use when the user
  has not stated a specific purpose.

**`client.scan_with_intent(url, intent)`** -- Threat verification plus
destination/intent alignment.
- Required parameters: `url` and `intent` (the user's stated purpose).
- Returns the completed scan result in a single call. Use when the user
  has mentioned a purpose such as "log in", "purchase", "download",
  "book", or "sign up".

**Prefer `scan_with_intent` whenever intent is available.** It catches
mismatches that threat-only analysis may miss.

Both methods block until the scan completes (typically 70--80 seconds) and
return the inner scan result directly.

### Advanced: explicit job control

For long-running contexts where you need explicit control:

#### Submit once, wait later

```python
submission = await client.start_scan("https://example.com")
# submission["scan_id"] is available immediately
result = await client.wait_for_scan(submission["scan_id"])
print(result["agent_access_directive"])
```

#### Check status without blocking

```python
status = await client.get_scan_status(submission["scan_id"])
# status["status"] is "working", "completed", "failed", or "cancelled"
```

#### Poll manually with progress reporting

```python
import asyncio

submission = await client.start_scan("https://example.com")

while True:
    envelope = await client.get_scan_result(submission["scan_id"])

    if envelope["status"] == "completed":
        print(envelope["result"]["agent_access_directive"])
        break

    if envelope["status"] != "working":
        raise RuntimeError(f"scan ended with status: {envelope['status']}")

    hint = envelope.get("retry_after_ms")
    wait_secs = hint / 1000.0 if isinstance(hint, (int, float)) and hint > 0 else 2.0
    await asyncio.sleep(wait_secs)
```

#### Job method reference

| Method | Returns | Use when |
|---|---|---|
| `start_scan(url)` | Submission envelope with `scan_id` | You need the scan ID before blocking |
| `start_scan_with_intent(url, intent)` | Same, intent-aware | User has stated a purpose |
| `get_scan_status(scan_id)` | Status envelope (no result payload) | Lightweight progress check |
| `get_scan_result(scan_id)` | Full envelope with `result` when completed | Manual polling loop |
| `wait_for_scan(scan_id, max_wait=600)` | Inner scan result directly | Block until done |

## How to act on results

Every completed scan returns an `agent_access_directive`. Follow it:

- **`ALLOW`** -- No blocking signal was detected. Continue only according to
  user confirmation, local policy, and normal security controls. Inform the
  user briefly that the URL was assessed. Do not guarantee safety.
- **`DENY`** -- Do not navigate. Tell the user the URL was flagged and
  include the `agent_access_reason`. Suggest they verify the URL or use
  an alternative.
- **`RETRY_LATER`** -- Verification could not complete (temporary issue).
  Wait a moment and retry once. If it fails again, inform the user.
- **`REQUIRE_CREDENTIALS`** -- The target requires authentication. Ask the
  user how they would like to proceed before continuing.

## Interpreting additional fields

- `risk_score` (0.0 to 1.0): threat probability. Lower is safer.
- `confidence` (0.0 to 1.0): how certain the analysis is.
- `analysis_complete` (true/false): whether the full analysis finished.
- `intent_alignment`: alignment signal between user purpose and observed
  destination behavior/content.
  - `misaligned`: evidence suggests mismatch with user intent.
  - `no_mismatch_detected`: no explicit mismatch signal detected.
  - `inconclusive`: insufficient evidence to verify alignment.
  - `not_provided`: no intent was provided.

## Timing

Verifications typically take around 70 to 80 seconds on current production
traffic. Do not set short timeouts or abandon verification prematurely.
`wait_for_scan` defaults to 10 minutes before raising; that is usually
enough for normal scans plus headroom.

## Error handling

The client raises three error types:

- **`PreClickConnectionError`** -- transport / connection failure. Retry
  once after a short delay; if it persists, surface the failure to the
  user and stop.
- **`PreClickRemoteError`** -- remote-side failure (rate limit, auth failure,
  scan failed / cancelled / expired). Inspect `err.code` and `err.data` for
  context. Do not silently ignore.
- **`PreClickError`** -- generic client misuse (invalid argument) or
  `wait_for_scan` max_wait exhausted.

If PreClick is unavailable, do not fall back to running scan logic on your
own. Tell the user verification is unavailable and let them decide how to
proceed.

## User-facing messaging

- Report the outcome clearly using `agent_access_directive` and
  `agent_access_reason`, and state whether the destination appears aligned
  with the user's goal when intent is provided.
- Use confidence-aware language based on scan evidence; avoid absolute
  guarantees.
