from collections import OrderedDict
from typing import Any

from celery.result import AsyncResult
from fastapi import APIRouter, Depends, HTTPException, status

from ezrules.backend.api_v2.auth.dependencies import (
    get_current_active_user,
    get_current_org_id,
    get_db,
    require_permission,
)
from ezrules.backend.api_v2.schemas.backtesting import (
    BacktestRequest,
    BacktestResultItem,
    BacktestResultsResponse,
    BacktestTaskResult,
    BacktestTriggerResponse,
)
from ezrules.backend.tasks import app as celery_app
from ezrules.backend.tasks import backtest_rule_change
from ezrules.core.permissions_constants import PermissionAction
from ezrules.core.rule import Rule
from ezrules.core.user_lists import PersistentUserListManager
from ezrules.models.backend_core import Rule as RuleModel
from ezrules.models.backend_core import RuleBackTestingResult, User

router = APIRouter(prefix="/api/v2/backtesting", tags=["Backtesting"])
_MAX_EAGER_BACKTEST_RESULTS = 128
_EAGER_BACKTEST_RESULTS: OrderedDict[str, dict[str, Any]] = OrderedDict()


def _build_task_result_response(data: dict[str, Any]) -> BacktestTaskResult:
    if "error" in data:
        return BacktestTaskResult(status="FAILURE", error=str(data["error"]))

    return BacktestTaskResult(
        status="SUCCESS",
        stored_result=data.get("stored_result"),
        proposed_result=data.get("proposed_result"),
        stored_result_rate=data.get("stored_result_rate"),
        proposed_result_rate=data.get("proposed_result_rate"),
        total_records=data.get("total_records"),
        eligible_records=data.get("eligible_records"),
        skipped_records=data.get("skipped_records"),
        labeled_records=data.get("labeled_records"),
        label_counts=data.get("label_counts"),
        stored_quality_summary=data.get("stored_quality_summary"),
        proposed_quality_summary=data.get("proposed_quality_summary"),
        stored_quality_metrics=data.get("stored_quality_metrics"),
        proposed_quality_metrics=data.get("proposed_quality_metrics"),
        warnings=data.get("warnings"),
    )


def _store_eager_backtest_result(task_id: str, result: dict[str, Any]) -> None:
    _EAGER_BACKTEST_RESULTS[task_id] = result
    _EAGER_BACKTEST_RESULTS.move_to_end(task_id)
    while len(_EAGER_BACKTEST_RESULTS) > _MAX_EAGER_BACKTEST_RESULTS:
        _EAGER_BACKTEST_RESULTS.popitem(last=False)


@router.post("", response_model=BacktestTriggerResponse)
def trigger_backtest(
    request: BacktestRequest,
    user: User = Depends(get_current_active_user),
    _: None = Depends(require_permission(PermissionAction.MODIFY_RULE)),
    current_org_id: int = Depends(get_current_org_id),
    db: Any = Depends(get_db),
) -> BacktestTriggerResponse:
    rule = db.query(RuleModel).filter(RuleModel.r_id == request.r_id, RuleModel.o_id == current_org_id).first()
    if rule is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Rule not found",
        )

    try:
        Rule(
            rid="",
            logic=request.new_rule_logic,
            list_values_provider=PersistentUserListManager(db, current_org_id),
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid proposed rule logic: {e!s}",
        ) from e

    task = backtest_rule_change.delay(request.r_id, request.new_rule_logic, current_org_id)
    if celery_app.conf.task_always_eager and task.id and isinstance(task.result, dict):
        _store_eager_backtest_result(str(task.id), task.result)

    bt_result = RuleBackTestingResult(
        r_id=request.r_id,
        task_id=task.id,
        stored_logic=rule.logic,
        proposed_logic=request.new_rule_logic,
    )
    db.add(bt_result)
    db.commit()

    return BacktestTriggerResponse(
        success=True,
        task_id=task.id,
        message="Backtest started",
    )


@router.get("/task/{task_id}", response_model=BacktestTaskResult)
def get_task_result(
    task_id: str,
    user: User = Depends(get_current_active_user),
    _: None = Depends(require_permission(PermissionAction.VIEW_RULES)),
    current_org_id: int = Depends(get_current_org_id),
    db: Any = Depends(get_db),
) -> BacktestTaskResult:
    task_record = (
        db.query(RuleBackTestingResult)
        .join(RuleModel, RuleModel.r_id == RuleBackTestingResult.r_id)
        .filter(
            RuleBackTestingResult.task_id == task_id,
            RuleModel.o_id == current_org_id,
        )
        .first()
    )
    if task_record is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Backtest task not found",
        )

    eager_result = _EAGER_BACKTEST_RESULTS.get(task_id)
    if eager_result is not None:
        return _build_task_result_response(eager_result)

    result = AsyncResult(task_id, app=celery_app)

    if result.state == "PENDING":
        return BacktestTaskResult(status="PENDING")

    if result.state == "FAILURE":
        return BacktestTaskResult(status="FAILURE", error=str(result.result))

    if result.state == "SUCCESS":
        data = result.result
        if isinstance(data, dict):
            return _build_task_result_response(data)
        return BacktestTaskResult(status="FAILURE", error="Backtest task returned an invalid result payload")

    return BacktestTaskResult(status=result.state)


@router.get("/{rule_id}", response_model=BacktestResultsResponse)
def get_backtest_results(
    rule_id: int,
    user: User = Depends(get_current_active_user),
    _: None = Depends(require_permission(PermissionAction.VIEW_RULES)),
    current_org_id: int = Depends(get_current_org_id),
    db: Any = Depends(get_db),
) -> BacktestResultsResponse:
    rule = db.query(RuleModel).filter(RuleModel.r_id == rule_id, RuleModel.o_id == current_org_id).first()
    if rule is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Rule not found",
        )

    results = (
        db.query(RuleBackTestingResult)
        .filter(RuleBackTestingResult.r_id == rule_id)
        .order_by(RuleBackTestingResult.created_at.desc())
        .limit(3)
        .all()
    )

    items = [
        BacktestResultItem(
            task_id=str(r.task_id),
            created_at=r.created_at,
            stored_logic=r.stored_logic,
            proposed_logic=r.proposed_logic,
        )
        for r in results
    ]

    return BacktestResultsResponse(results=items)
