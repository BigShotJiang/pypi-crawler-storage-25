import re
import requests

# nested loops
def process_data(items):
    results = []
    for i in items:
        for j in items:
            results.append(i + j)  # list append in nested loop
    return results

# string concat in loop
def build_string(words):
    result = ""
    for word in words:
        result += word  # string concat
    return result

# re.compile in loop
def match_emails(emails):
    for email in emails:
        pattern = re.compile(r'\w+@\w+\.\w+')  # re.compile in loop
        if pattern.match(email):
            print(f"Valid: {email}")  # print in loop

# expensive call in loop
def fetch_data(urls):
    for url in urls:
        response = requests.get(url)  # I/O in loop
        print(response.status_code)

# mutable default argument
def add_item(item, items=[]):
    items.append(item)
    return items

# bare except
def risky():
    try:
        x = 1 / 0
    except:
        pass

# global in loop
counter = 0
def increment(n):
    global counter
    for i in range(n):
        counter += 1  # global in loop

# unnecessary object creation in loop
def make_dicts(n):
    for i in range(n):
        d = dict()  # unnecessary object creation
        d['key'] = i

# import inside function
def parse_json(data):
    import json  # import inside function
    return json.loads(data)

# list concat with +
def combine(lists):
    result = []
    for l in lists:
        result = result + l  # list concat with +
    return result