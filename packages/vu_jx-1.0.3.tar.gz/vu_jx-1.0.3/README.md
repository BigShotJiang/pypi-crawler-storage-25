# VU_JX v1.0.0
**Telegram:** [@VU_JX](https://t.me/VU_JX)

---

## Kurulum

```bash
pip install VU_JX
```

---

## Modüller

| Modül | Açıklama |
|---|---|
| `VUSession` | Retry + timeout + UA rotasyonu ile HTTP session |
| `AntiDetectSession` | Bot algılanmasını zorlaştıran gelişmiş session |
| `ProxyManager` | Proxy listesi, rotasyon, sağlık kontrolü |
| `CacheDB` | TTL destekli in-memory + dosya cache |
| `encrypt_aes` / `decrypt_aes` | AES-256-GCM şifreleme |
| `generate_keypair` / `rsa_encrypt` / `rsa_decrypt` | RSA şifreleme |
| `create_token` / `decode_token` | JWT token üretimi ve doğrulama |
| `VUWebSocket` | WebSocket bağlantısı ve dinleme |
| `parallel_get` / `parallel_post` / `parallel_requests` | ThreadPool ile paralel istek |
| `Config` / `load_json` / `load_toml` | TOML/JSON config okuma |
| `async_get` / `async_post` / `async_batch` | Paralel async HTTP |
| `rate_limited_request` | Rate-limited istek (15/dk) |

---

## Kullanım

```python
import VU_JX as vx

vx.banner("VU_JX", color="cyan")

resp = vx.get("https://httpbin.org/get")
print(resp.json())

session = vx.VUSession()
data = session.get_json("https://httpbin.org/json")

anti = vx.AntiDetectSession(browser="chrome", request_delay=1.0)

pm = vx.ProxyManager()
pm.add("http://1.2.3.4:8080")

import asyncio
results = asyncio.run(vx.async_batch([
    {"method": "GET", "url": "https://httpbin.org/get"},
    {"method": "GET", "url": "https://httpbin.org/ip"},
]))

results = vx.parallel_get(["https://httpbin.org/get", "https://httpbin.org/ip"], max_workers=5)

token = vx.encrypt_aes("gizli veri", b"anahtarim")
plain = vx.decrypt_aes(token, b"anahtarim")

priv, pub = vx.generate_keypair()
token = vx.rsa_encrypt("mesaj", pub)
plain = vx.rsa_decrypt(token, priv)

jwt = vx.create_token({"user": "VU_JX"}, secret="gizli", expires_in=3600)
payload = vx.decode_token(jwt, secret="gizli")

cfg = vx.Config("config.json")
cfg.get("database.host")

db = vx.CacheDB(path="cache.json", default_ttl=600)
db.set("key", "value", ttl=60)
print(db.get("key"))

vx.setup_logging("DEBUG", log_file="vujx.log")
vx.log_info("Başladı")
```

---

*VU_JX Tool Library — @VU_JX*
