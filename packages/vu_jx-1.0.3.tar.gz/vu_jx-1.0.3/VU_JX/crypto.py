from __future__ import annotations
import base64
from Crypto.Cipher import AES, PKCS1_OAEP
from Crypto.PublicKey import RSA
from Crypto.Random import get_random_bytes


def _make_key(key: bytes) -> bytes:
    return (key + b"\x00" * 32)[:32]


def encrypt_aes(data: str, key: bytes) -> str:
    key = _make_key(key)
    nonce = get_random_bytes(12)
    cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
    ct, tag = cipher.encrypt_and_digest(data.encode())
    return base64.b64encode(nonce + tag + ct).decode()


def decrypt_aes(token: str, key: bytes) -> str:
    key = _make_key(key)
    raw = base64.b64decode(token)
    nonce, tag, ct = raw[:12], raw[12:28], raw[28:]
    cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
    return cipher.decrypt_and_verify(ct, tag).decode()


def generate_keypair(key_size: int = 2048) -> tuple[bytes, bytes]:
    key = RSA.generate(key_size)
    return key.export_key("PEM"), key.publickey().export_key("PEM")


def rsa_encrypt(data: str, public_pem: bytes) -> str:
    cipher = PKCS1_OAEP.new(RSA.import_key(public_pem))
    return base64.b64encode(cipher.encrypt(data.encode())).decode()


def rsa_decrypt(token: str, private_pem: bytes) -> str:
    cipher = PKCS1_OAEP.new(RSA.import_key(private_pem))
    return cipher.decrypt(base64.b64decode(token)).decode()
