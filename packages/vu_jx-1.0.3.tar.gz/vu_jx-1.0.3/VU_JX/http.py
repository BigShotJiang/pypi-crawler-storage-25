from __future__ import annotations
import requests
import asyncio
import aiohttp
import httpx
import urllib3
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from requests_cache import CachedSession
from ratelimit import limits, sleep_and_retry
from fake_useragent import UserAgent

from requests import (
    Request, Response, PreparedRequest,
    RequestException, HTTPError, ConnectionError, Timeout, TooManyRedirects,
    codes as status_codes,
    get, post, put, delete, head, patch, request,
)

ua = UserAgent()
_URLLIB3_MAJOR = int(urllib3.__version__.split(".")[0])


class VUSession(requests.Session):
    def __init__(self, retries=5, backoff_factor=0.5, timeout=15, rotate_ua=True, proxies=None):
        super().__init__()
        self.timeout = timeout
        self.rotate_ua = rotate_ua

        retry_kwargs = dict(
            total=retries,
            backoff_factor=backoff_factor,
            status_forcelist=[429, 500, 502, 503, 504],
        )
        if _URLLIB3_MAJOR >= 2:
            retry_kwargs["allowed_methods"] = ["GET", "POST", "PUT", "DELETE", "PATCH"]
        else:
            retry_kwargs["method_whitelist"] = ["GET", "POST", "PUT", "DELETE", "PATCH"]

        adapter = HTTPAdapter(max_retries=Retry(**retry_kwargs))
        self.mount("http://", adapter)
        self.mount("https://", adapter)
        self.headers.update({
            "User-Agent": ua.random,
            "Accept-Language": "en-US,en;q=0.9",
            "Accept-Encoding": "gzip, deflate, br",
        })
        if proxies:
            self.proxies.update(proxies)
        self.hooks["response"].append(self._on_response)

    def _on_response(self, response, *args, **kwargs):
        if self.rotate_ua:
            self.headers.update({"User-Agent": ua.random})

    def request(self, method, url, **kwargs):
        kwargs.setdefault("timeout", self.timeout)
        return super().request(method, url, **kwargs)

    def get_json(self, url, **kwargs):
        r = self.get(url, **kwargs)
        r.raise_for_status()
        return r.json()

    def post_json(self, url, data, **kwargs):
        r = self.post(url, json=data, **kwargs)
        r.raise_for_status()
        return r.json()

    def download(self, url, path, chunk_size=8192, **kwargs):
        with self.get(url, stream=True, **kwargs) as r:
            r.raise_for_status()
            with open(path, "wb") as f:
                for chunk in r.iter_content(chunk_size=chunk_size):
                    f.write(chunk)
        return path


def cache_session(expire_after=300, backend="memory"):
    s = CachedSession(backend=backend, expire_after=expire_after)
    s.headers.update({"User-Agent": ua.random})
    return s


@sleep_and_retry
@limits(calls=15, period=60)
def rate_limited_request(method, url, **kwargs):
    return requests.request(method, url, **kwargs)


async def async_get(url, **kwargs):
    async with aiohttp.ClientSession() as s:
        async with s.get(url, **kwargs) as r:
            return await r.text()


async def async_post(url, data=None, json=None, **kwargs):
    async with aiohttp.ClientSession() as s:
        async with s.post(url, data=data, json=json, **kwargs) as r:
            return await r.text()


async def async_request(method, url, **kwargs):
    async with aiohttp.ClientSession() as s:
        async with s.request(method, url, **kwargs) as r:
            return await r.text()


async def async_batch(requests_list):
    async def _fetch(session, req):
        method = req.pop("method", "GET")
        url = req.pop("url")
        async with session.request(method, url, **req) as resp:
            return {"status": resp.status, "text": await resp.text()}
    async with aiohttp.ClientSession() as s:
        return await asyncio.gather(*[_fetch(s, dict(r)) for r in requests_list])
