from __future__ import annotations
import json
import os
import tomllib
from typing import Any


class Config:
    def __init__(self, path: str):
        self._path = path
        self._data: dict = {}
        self.load()

    def load(self):
        if not os.path.exists(self._path):
            self._data = {}
            return
        ext = os.path.splitext(self._path)[1].lower()
        if ext == ".json":
            with open(self._path, "r", encoding="utf-8") as f:
                self._data = json.load(f)
        elif ext == ".toml":
            with open(self._path, "rb") as f:
                self._data = tomllib.load(f)
        else:
            raise ValueError(f"Desteklenmeyen format: {ext} (json veya toml olmalı)")

    def get(self, key: str, default: Any = None) -> Any:
        keys = key.split(".")
        val = self._data
        for k in keys:
            if not isinstance(val, dict):
                return default
            val = val.get(k, default)
        return val

    def set(self, key: str, value: Any):
        keys = key.split(".")
        d = self._data
        for k in keys[:-1]:
            d = d.setdefault(k, {})
        d[keys[-1]] = value

    def save(self):
        ext = os.path.splitext(self._path)[1].lower()
        if ext == ".json":
            with open(self._path, "w", encoding="utf-8") as f:
                json.dump(self._data, f, ensure_ascii=False, indent=2)
        else:
            raise ValueError("Sadece JSON dosyaları kaydedilebilir.")

    def all(self) -> dict:
        return self._data

    def __repr__(self):
        return f"<Config path={self._path} keys={list(self._data.keys())}>"


def load_json(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def load_toml(path: str) -> dict:
    with open(path, "rb") as f:
        return tomllib.load(f)


def save_json(path: str, data: dict, indent: int = 2):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=indent)
