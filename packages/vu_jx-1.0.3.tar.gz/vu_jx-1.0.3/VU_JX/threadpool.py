from __future__ import annotations
import requests
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from fake_useragent import UserAgent

ua = UserAgent()


def thread_request(method: str, url: str, **kwargs) -> dict:
    try:
        headers = kwargs.pop("headers", {})
        headers.setdefault("User-Agent", ua.random)
        r = requests.request(method, url, headers=headers, timeout=15, **kwargs)
        return {"url": url, "status": r.status_code, "text": r.text, "error": None}
    except Exception as e:
        return {"url": url, "status": None, "text": None, "error": str(e)}


def parallel_get(urls: list[str], max_workers: int = 10, **kwargs) -> list[dict]:
    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = {pool.submit(thread_request, "GET", url, **kwargs): url for url in urls}
        return [f.result() for f in as_completed(futures)]


def parallel_post(targets: list[dict], max_workers: int = 10) -> list[dict]:
    def _post(item):
        return thread_request("POST", item["url"], json=item.get("data"), **item.get("kwargs", {}))
    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = [pool.submit(_post, t) for t in targets]
        return [f.result() for f in as_completed(futures)]


def parallel_requests(tasks: list[dict], max_workers: int = 10) -> list[dict]:
    def _run(task):
        method = task.pop("method", "GET")
        url = task.pop("url")
        return thread_request(method, url, **task)
    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = [pool.submit(_run, dict(t)) for t in tasks]
        return [f.result() for f in as_completed(futures)]
