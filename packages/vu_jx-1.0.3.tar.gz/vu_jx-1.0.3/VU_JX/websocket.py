from __future__ import annotations
import asyncio
import websockets
from typing import Callable


class VUWebSocket:
    def __init__(self, url: str):
        self.url = url
        self._ws = None

    async def connect(self):
        self._ws = await websockets.connect(self.url)
        return self

    async def send(self, message: str):
        if self._ws:
            await self._ws.send(message)

    async def receive(self) -> str:
        if self._ws:
            return await self._ws.recv()
        return ""

    async def close(self):
        if self._ws:
            await self._ws.close()

    async def listen(self, on_message: Callable, on_error: Callable = None):
        async with websockets.connect(self.url) as ws:
            while True:
                try:
                    msg = await ws.recv()
                    await on_message(msg)
                except websockets.ConnectionClosed:
                    break
                except Exception as e:
                    if on_error:
                        await on_error(e)
                    break

    async def __aenter__(self):
        return await self.connect()

    async def __aexit__(self, *args):
        await self.close()


async def ws_send_receive(url: str, message: str) -> str:
    async with websockets.connect(url) as ws:
        await ws.send(message)
        return await ws.recv()
