from __future__ import annotations
import jwt
import datetime


def create_token(payload: dict, secret: str, expires_in: int = 3600, algorithm: str = "HS256") -> str:
    data = payload.copy()
    data["exp"] = datetime.datetime.utcnow() + datetime.timedelta(seconds=expires_in)
    data["iat"] = datetime.datetime.utcnow()
    return jwt.encode(data, secret, algorithm=algorithm)


def decode_token(token: str, secret: str, algorithm: str = "HS256") -> dict:
    return jwt.decode(token, secret, algorithms=[algorithm])


def is_token_valid(token: str, secret: str, algorithm: str = "HS256") -> bool:
    try:
        jwt.decode(token, secret, algorithms=[algorithm])
        return True
    except jwt.ExpiredSignatureError:
        return False
    except jwt.InvalidTokenError:
        return False


def token_payload(token: str, secret: str, algorithm: str = "HS256") -> dict | None:
    try:
        return jwt.decode(token, secret, algorithms=[algorithm])
    except Exception:
        return None
