from .http import (
    VUSession,
    get, post, put, delete, head, patch, request,
    async_get, async_post, async_request, async_batch,
    cache_session, rate_limited_request,
    Request, Response, PreparedRequest,
    RequestException, HTTPError, ConnectionError, Timeout, TooManyRedirects,
    status_codes,
)
from .utils import (
    colored_print, figlet_font, cfont_text, banner,
    random_user_agent, random_string,
    generate_uuid, md5_hash, sha256_hash, sha512_hash,
    b64_encode, b64_decode,
    os, uuid, hashlib, threading, queue, httpx,
)
from .proxy import ProxyManager
from .crypto import encrypt_aes, decrypt_aes, generate_keypair, rsa_encrypt, rsa_decrypt
from .fingerprint import AntiDetectSession
from .database import CacheDB
from .jwt_utils import create_token, decode_token, is_token_valid, token_payload
from .websocket import VUWebSocket, ws_send_receive
from .threadpool import parallel_get, parallel_post, parallel_requests, thread_request
from .config import Config, load_json, load_toml, save_json
from .logging import setup_logging, log_info, log_error, log_warn, log_debug
from .version import __version__, __author__, __telegram__

_session = VUSession()
get    = _session.get
post   = _session.post
put    = _session.put
delete = _session.delete

try:
    from cfonts import render as _cfont_render
    print(_cfont_render("VU_JX", font="block", colors=["white", "blue"], align="center"))
except Exception:
    from colorama import Fore, Style
    from pyfiglet import Figlet
    print(f"{Fore.CYAN}{Figlet(font='slant').renderText('VU_JX')}{Style.RESET_ALL}")

__all__ = [
    "VUSession", "AntiDetectSession",
    "get", "post", "put", "delete", "head", "patch", "request",
    "async_get", "async_post", "async_request", "async_batch",
    "cache_session", "rate_limited_request",
    "Request", "Response", "PreparedRequest",
    "RequestException", "HTTPError", "ConnectionError", "Timeout",
    "status_codes",
    "ProxyManager",
    "encrypt_aes", "decrypt_aes", "generate_keypair", "rsa_encrypt", "rsa_decrypt",
    "colored_print", "figlet_font", "cfont_text", "banner",
    "random_user_agent", "random_string",
    "generate_uuid", "md5_hash", "sha256_hash", "sha512_hash",
    "b64_encode", "b64_decode",
    "os", "uuid", "hashlib", "threading", "queue", "httpx",
    "CacheDB",
    "create_token", "decode_token", "is_token_valid", "token_payload",
    "VUWebSocket", "ws_send_receive",
    "parallel_get", "parallel_post", "parallel_requests", "thread_request",
    "Config", "load_json", "load_toml", "save_json",
    "setup_logging", "log_info", "log_error", "log_warn", "log_debug",
    "__version__", "__author__", "__telegram__",
]
