from __future__ import annotations
import requests
import random
import threading


class ProxyManager:
    def __init__(self, proxies=None, test_url="https://httpbin.org/ip"):
        self._proxies = proxies or []
        self._blacklist = set()
        self._lock = threading.Lock()
        self._index = 0
        self.test_url = test_url

    def add(self, proxy):
        with self._lock:
            if proxy not in self._proxies:
                self._proxies.append(proxy)

    def add_bulk(self, proxies):
        for p in proxies:
            self.add(p)

    def remove(self, proxy):
        with self._lock:
            self._proxies = [p for p in self._proxies if p != proxy]

    def blacklist(self, proxy):
        with self._lock:
            self._blacklist.add(proxy)
            self._proxies = [p for p in self._proxies if p != proxy]

    def rotate(self):
        with self._lock:
            active = [p for p in self._proxies if p not in self._blacklist]
            if not active:
                return None
            proxy = active[self._index % len(active)]
            self._index += 1
            return {"http": proxy, "https": proxy}

    def random_proxy(self):
        with self._lock:
            active = [p for p in self._proxies if p not in self._blacklist]
            if not active:
                return None
            p = random.choice(active)
            return {"http": p, "https": p}

    def check(self, proxy, timeout=5):
        try:
            r = requests.get(self.test_url, proxies={"http": proxy, "https": proxy}, timeout=timeout)
            return r.status_code == 200
        except Exception:
            return False

    def health_check_all(self, timeout=5):
        results = {}
        for proxy in list(self._proxies):
            ok = self.check(proxy, timeout)
            results[proxy] = ok
            if not ok:
                self.blacklist(proxy)
        return results

    @property
    def count(self):
        return len([p for p in self._proxies if p not in self._blacklist])

    def __repr__(self):
        return f"<ProxyManager proxies={self.count} blacklisted={len(self._blacklist)}>"
