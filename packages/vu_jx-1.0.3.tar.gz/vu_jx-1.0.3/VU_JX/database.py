from __future__ import annotations
import json
import os
import time
import threading


class CacheDB:
    def __init__(self, path=None, default_ttl=300):
        self._store: dict = {}
        self._lock = threading.Lock()
        self._path = path
        self.default_ttl = default_ttl
        if path and os.path.exists(path):
            self._load()

    def set(self, key, value, ttl=None, namespace="default"):
        expire_at = time.time() + (ttl if ttl is not None else self.default_ttl)
        with self._lock:
            self._store[f"{namespace}:{key}"] = {"value": value, "expire_at": expire_at}
        if self._path:
            self._save()

    def get(self, key, namespace="default"):
        ns_key = f"{namespace}:{key}"
        with self._lock:
            entry = self._store.get(ns_key)
            if not entry:
                return None
            if time.time() > entry["expire_at"]:
                del self._store[ns_key]
                return None
            return entry["value"]

    def delete(self, key, namespace="default"):
        with self._lock:
            self._store.pop(f"{namespace}:{key}", None)
        if self._path:
            self._save()

    def flush(self, namespace=None):
        with self._lock:
            if namespace:
                for k in [k for k in self._store if k.startswith(f"{namespace}:")]:
                    del self._store[k]
            else:
                self._store.clear()
        if self._path:
            self._save()

    def cleanup(self):
        now = time.time()
        with self._lock:
            for k in [k for k, v in self._store.items() if now > v["expire_at"]]:
                del self._store[k]

    def keys(self, namespace="default"):
        prefix = f"{namespace}:"
        with self._lock:
            return [k[len(prefix):] for k in self._store if k.startswith(prefix)]

    def _save(self):
        with open(self._path, "w", encoding="utf-8") as f:
            json.dump(self._store, f, ensure_ascii=False, indent=2)

    def _load(self):
        try:
            with open(self._path, "r", encoding="utf-8") as f:
                self._store = json.load(f)
        except Exception:
            self._store = {}

    def __repr__(self):
        return f"<CacheDB keys={len(self._store)} path={self._path}>"
