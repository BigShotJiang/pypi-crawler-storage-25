"""Penalty system for repeat offenders.

Progressively increases rate limit strictness for keys that repeatedly
hit their limits, implementing exponential backoff penalties.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field


@dataclass
class PenaltyState:
    """Tracks penalty state for a key."""
    violations: int = 0
    penalty_until: float = 0.0
    last_violation: float = 0.0

    @property
    def is_penalized(self) -> bool:
        return self.penalty_until > time.time()

    @property
    def penalty_remaining(self) -> float:
        return max(0.0, self.penalty_until - time.time())


class PenaltyTracker:
    """Tracks and applies progressive penalties for rate limit violations.

    After a configurable number of violations within a decay window,
    the key receives an exponentially increasing penalty duration.
    """

    def __init__(
        self,
        threshold: int = 5,
        base_penalty: float = 10.0,
        max_penalty: float = 3600.0,
        multiplier: float = 2.0,
        decay_seconds: float = 300.0,
    ):
        """Initialize penalty tracker.

        Args:
            threshold: Violations before penalty kicks in.
            base_penalty: Base penalty duration in seconds.
            max_penalty: Maximum penalty duration in seconds.
            multiplier: Penalty multiplier per threshold breach.
            decay_seconds: Time after which violations decay if no new ones.
        """
        if threshold <= 0:
            raise ValueError("threshold must be positive")
        if base_penalty <= 0:
            raise ValueError("base_penalty must be positive")
        if max_penalty < base_penalty:
            raise ValueError("max_penalty must be >= base_penalty")
        if multiplier < 1.0:
            raise ValueError("multiplier must be >= 1.0")

        self._threshold = threshold
        self._base_penalty = base_penalty
        self._max_penalty = max_penalty
        self._multiplier = multiplier
        self._decay_seconds = decay_seconds
        self._states: dict[str, PenaltyState] = {}

    def record_violation(self, key: str) -> PenaltyState:
        """Record a rate limit violation for a key."""
        now = time.time()
        state = self._states.get(key)

        if state is None:
            state = PenaltyState()
            self._states[key] = state

        # Decay old violations
        if state.last_violation > 0 and (now - state.last_violation) > self._decay_seconds:
            state.violations = 0

        state.violations += 1
        state.last_violation = now

        # Apply penalty if threshold exceeded
        if state.violations >= self._threshold:
            breach_count = (state.violations - self._threshold) // self._threshold + 1
            penalty_duration = min(
                self._base_penalty * (self._multiplier ** (breach_count - 1)),
                self._max_penalty,
            )
            state.penalty_until = now + penalty_duration

        return PenaltyState(
            violations=state.violations,
            penalty_until=state.penalty_until,
            last_violation=state.last_violation,
        )

    def check(self, key: str) -> PenaltyState:
        """Check penalty state without recording a violation."""
        state = self._states.get(key)
        if state is None:
            return PenaltyState()
        return PenaltyState(
            violations=state.violations,
            penalty_until=state.penalty_until,
            last_violation=state.last_violation,
        )

    def clear(self, key: str) -> None:
        """Clear penalty state for a key."""
        self._states.pop(key, None)

    def clear_all(self) -> None:
        """Clear all penalty states."""
        self._states.clear()

    def get_penalized_keys(self) -> list[str]:
        """Get list of currently penalized keys."""
        now = time.time()
        return [k for k, v in self._states.items() if v.penalty_until > now]
