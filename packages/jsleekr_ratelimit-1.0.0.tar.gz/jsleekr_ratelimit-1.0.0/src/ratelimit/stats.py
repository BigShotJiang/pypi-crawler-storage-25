"""Rate limiter statistics and metrics tracking."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from collections import defaultdict
from threading import Lock


@dataclass
class KeyStats:
    """Statistics for a single rate limit key."""
    total_requests: int = 0
    allowed_requests: int = 0
    denied_requests: int = 0
    total_retry_after: float = 0.0
    first_seen: float = 0.0
    last_seen: float = 0.0

    @property
    def denial_rate(self) -> float:
        """Percentage of denied requests (0.0 to 1.0)."""
        if self.total_requests == 0:
            return 0.0
        return self.denied_requests / self.total_requests

    @property
    def avg_retry_after(self) -> float:
        """Average retry_after for denied requests."""
        if self.denied_requests == 0:
            return 0.0
        return self.total_retry_after / self.denied_requests


class StatsCollector:
    """Collects rate limiting statistics.

    Thread-safe statistics collector that can be attached to a RateLimiter.
    """

    def __init__(self):
        self._stats: dict[str, KeyStats] = defaultdict(KeyStats)
        self._lock = Lock()
        self._global_allowed = 0
        self._global_denied = 0

    def record_allowed(self, key: str) -> None:
        """Record an allowed request."""
        now = time.time()
        with self._lock:
            s = self._stats[key]
            s.total_requests += 1
            s.allowed_requests += 1
            if s.first_seen == 0.0:
                s.first_seen = now
            s.last_seen = now
            self._global_allowed += 1

    def record_denied(self, key: str, retry_after: float = 0.0) -> None:
        """Record a denied request."""
        now = time.time()
        with self._lock:
            s = self._stats[key]
            s.total_requests += 1
            s.denied_requests += 1
            s.total_retry_after += retry_after
            if s.first_seen == 0.0:
                s.first_seen = now
            s.last_seen = now
            self._global_denied += 1

    def get_key_stats(self, key: str) -> KeyStats | None:
        """Get stats for a specific key."""
        with self._lock:
            if key in self._stats:
                s = self._stats[key]
                return KeyStats(
                    total_requests=s.total_requests,
                    allowed_requests=s.allowed_requests,
                    denied_requests=s.denied_requests,
                    total_retry_after=s.total_retry_after,
                    first_seen=s.first_seen,
                    last_seen=s.last_seen,
                )
            return None

    def get_all_keys(self) -> list[str]:
        """Get all tracked keys."""
        with self._lock:
            return list(self._stats.keys())

    @property
    def total_allowed(self) -> int:
        with self._lock:
            return self._global_allowed

    @property
    def total_denied(self) -> int:
        with self._lock:
            return self._global_denied

    @property
    def total_requests(self) -> int:
        with self._lock:
            return self._global_allowed + self._global_denied

    @property
    def global_denial_rate(self) -> float:
        with self._lock:
            total = self._global_allowed + self._global_denied
            if total == 0:
                return 0.0
            return self._global_denied / total

    def top_denied_keys(self, n: int = 10) -> list[tuple[str, KeyStats]]:
        """Get top N keys by denial count."""
        with self._lock:
            items = [(k, KeyStats(
                total_requests=v.total_requests,
                allowed_requests=v.allowed_requests,
                denied_requests=v.denied_requests,
                total_retry_after=v.total_retry_after,
                first_seen=v.first_seen,
                last_seen=v.last_seen,
            )) for k, v in self._stats.items()]
        items.sort(key=lambda x: x[1].denied_requests, reverse=True)
        return items[:n]

    def reset(self) -> None:
        """Clear all statistics."""
        with self._lock:
            self._stats.clear()
            self._global_allowed = 0
            self._global_denied = 0

    def attach(self, limiter) -> None:
        """Attach this collector to a RateLimiter via callbacks."""
        from ratelimit.core import RateLimiter

        @limiter.on_allowed
        def _on_allowed(key, result):
            self.record_allowed(key)

        @limiter.on_limited
        def _on_limited(key, result):
            self.record_denied(key, result.retry_after)
