"""Decorator for easy rate limiting of functions."""

from __future__ import annotations

import asyncio
import functools
import inspect
from typing import Any, Callable

from ratelimit.core import RateLimiter, RateLimitResult


class RateLimitExceeded(Exception):
    """Raised when rate limit is exceeded."""

    def __init__(self, result: RateLimitResult):
        self.result = result
        super().__init__(
            f"Rate limit exceeded. Retry after {result.retry_after:.1f}s"
        )


def rate_limit(
    limiter: RateLimiter,
    key: str | Callable[..., str] | None = None,
    cost: int = 1,
    wait: bool = False,
    timeout: float = 30.0,
):
    """Decorator to rate limit a function.

    Args:
        limiter: The RateLimiter instance to use.
        key: Static key string, or callable that extracts key from args.
             If None, uses the function name.
        cost: Cost per invocation.
        wait: If True, wait for rate limit instead of raising.
        timeout: Max wait time when wait=True.
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            k = _resolve_key(func, key, args, kwargs)
            if wait:
                await limiter.wait_and_acquire(k, cost=cost, timeout=timeout)
            else:
                result = await limiter.acquire(k, cost=cost)
                if not result.allowed:
                    raise RateLimitExceeded(result)
            return await func(*args, **kwargs)

        @functools.wraps(func)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            k = _resolve_key(func, key, args, kwargs)
            try:
                loop = asyncio.get_running_loop()
            except RuntimeError:
                loop = None
            if loop and loop.is_running():
                raise RuntimeError(
                    "Cannot use sync rate_limit decorator inside a running event loop. "
                    "Use the async version or call from a non-async context."
                )
            if wait:
                asyncio.run(
                    limiter.wait_and_acquire(k, cost=cost, timeout=timeout)
                )
            else:
                result = asyncio.run(limiter.acquire(k, cost=cost))
                if not result.allowed:
                    raise RateLimitExceeded(result)
            return func(*args, **kwargs)

        if inspect.iscoroutinefunction(func):
            return async_wrapper
        return sync_wrapper

    return decorator


def _resolve_key(
    func: Callable,
    key: str | Callable[..., str] | None,
    args: tuple,
    kwargs: dict,
) -> str:
    """Resolve the rate limit key."""
    if key is None:
        return func.__qualname__
    if callable(key):
        return key(*args, **kwargs)
    return key
