"""Circuit breaker for rate limiting.

Automatically stops sending requests when failure rate is high,
and gradually recovers.
"""

from __future__ import annotations

import time
from enum import Enum
from dataclasses import dataclass


class CircuitState(str, Enum):
    """Circuit breaker states."""
    CLOSED = "closed"       # Normal: requests pass through
    OPEN = "open"           # Tripped: all requests rejected
    HALF_OPEN = "half_open" # Testing: limited requests allowed


@dataclass
class CircuitStatus:
    """Current circuit breaker status."""
    state: CircuitState
    failure_count: int
    success_count: int
    last_failure: float
    last_state_change: float

    @property
    def time_in_state(self) -> float:
        return time.time() - self.last_state_change


class CircuitBreaker:
    """Rate limit-aware circuit breaker.

    Opens when too many requests are denied, preventing unnecessary
    attempts that will fail anyway.
    """

    def __init__(
        self,
        failure_threshold: int = 5,
        success_threshold: int = 3,
        timeout: float = 30.0,
    ):
        """Initialize circuit breaker.

        Args:
            failure_threshold: Consecutive failures to trip the circuit.
            success_threshold: Successes needed in half-open to close.
            timeout: Seconds to wait in open state before half-open.
        """
        if failure_threshold <= 0:
            raise ValueError("failure_threshold must be positive")
        if success_threshold <= 0:
            raise ValueError("success_threshold must be positive")
        if timeout <= 0:
            raise ValueError("timeout must be positive")

        self._failure_threshold = failure_threshold
        self._success_threshold = success_threshold
        self._timeout = timeout
        self._states: dict[str, _CircuitData] = {}

    def _get_data(self, key: str) -> _CircuitData:
        if key not in self._states:
            self._states[key] = _CircuitData()
        return self._states[key]

    def should_allow(self, key: str) -> bool:
        """Check if a request should be allowed through."""
        data = self._get_data(key)
        now = time.time()

        if data.state == CircuitState.CLOSED:
            return True
        elif data.state == CircuitState.OPEN:
            if now - data.last_state_change >= self._timeout:
                data.state = CircuitState.HALF_OPEN
                data.last_state_change = now
                data.half_open_successes = 0
                return True
            return False
        else:  # HALF_OPEN
            return True

    def record_success(self, key: str) -> CircuitState:
        """Record a successful request."""
        data = self._get_data(key)
        data.failure_count = 0
        data.success_count += 1

        if data.state == CircuitState.HALF_OPEN:
            data.half_open_successes += 1
            if data.half_open_successes >= self._success_threshold:
                data.state = CircuitState.CLOSED
                data.last_state_change = time.time()

        return data.state

    def record_failure(self, key: str) -> CircuitState:
        """Record a failed (rate limited) request."""
        data = self._get_data(key)
        now = time.time()
        data.failure_count += 1
        data.last_failure = now

        if data.state == CircuitState.HALF_OPEN:
            # Immediately re-open on failure in half-open
            data.state = CircuitState.OPEN
            data.last_state_change = now
        elif data.state == CircuitState.CLOSED:
            if data.failure_count >= self._failure_threshold:
                data.state = CircuitState.OPEN
                data.last_state_change = now

        return data.state

    def get_status(self, key: str) -> CircuitStatus:
        """Get the current circuit status for a key."""
        data = self._get_data(key)
        return CircuitStatus(
            state=data.state,
            failure_count=data.failure_count,
            success_count=data.success_count,
            last_failure=data.last_failure,
            last_state_change=data.last_state_change,
        )

    def reset(self, key: str) -> None:
        """Reset the circuit breaker for a key."""
        self._states.pop(key, None)

    def reset_all(self) -> None:
        """Reset all circuits."""
        self._states.clear()


class _CircuitData:
    __slots__ = (
        "state", "failure_count", "success_count",
        "last_failure", "last_state_change", "half_open_successes",
    )

    def __init__(self):
        self.state = CircuitState.CLOSED
        self.failure_count = 0
        self.success_count = 0
        self.last_failure = 0.0
        self.last_state_change = time.time()
        self.half_open_successes = 0
