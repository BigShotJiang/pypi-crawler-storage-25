"""Key extraction utilities for rate limiting.

Provides common patterns for extracting rate limit keys from
request context, IP addresses, API keys, etc.
"""

from __future__ import annotations

import hashlib
from typing import Any, Callable


class KeyBuilder:
    """Builds composite rate limit keys.

    Example:
        kb = KeyBuilder(prefix="api", separator=":")
        key = kb.build("user", "123", "endpoint", "GET /users")
        # => "api:user:123:endpoint:GET /users"
    """

    def __init__(self, prefix: str = "", separator: str = ":"):
        self._prefix = prefix
        self._separator = separator

    def build(self, *parts: str) -> str:
        """Build a key from parts."""
        all_parts = [self._prefix] + list(parts) if self._prefix else list(parts)
        return self._separator.join(all_parts)

    def with_prefix(self, prefix: str) -> KeyBuilder:
        """Create a new KeyBuilder with an additional prefix."""
        new_prefix = f"{self._prefix}{self._separator}{prefix}" if self._prefix else prefix
        return KeyBuilder(prefix=new_prefix, separator=self._separator)


def ip_key(ip: str, prefix: str = "ip") -> str:
    """Create a key based on IP address."""
    return f"{prefix}:{ip}"


def user_key(user_id: str | int, prefix: str = "user") -> str:
    """Create a key based on user ID."""
    return f"{prefix}:{user_id}"


def api_key_hash(api_key: str, prefix: str = "apikey") -> str:
    """Create a key based on hashed API key (for privacy)."""
    hashed = hashlib.sha256(api_key.encode()).hexdigest()[:16]
    return f"{prefix}:{hashed}"


def endpoint_key(method: str, path: str, prefix: str = "endpoint") -> str:
    """Create a key based on HTTP method and path."""
    return f"{prefix}:{method}:{path}"


def composite_key(*parts: str, separator: str = ":") -> str:
    """Create a composite key from multiple parts."""
    return separator.join(str(p) for p in parts)


class KeyExtractor:
    """Configurable key extractor for use with decorators.

    Example:
        extractor = KeyExtractor()
        extractor.add_part("user", lambda req: req.user_id)
        extractor.add_part("endpoint", lambda req: req.path)
        key = extractor.extract(request)
    """

    def __init__(self, separator: str = ":", prefix: str = ""):
        self._parts: list[tuple[str, Callable[..., str]]] = []
        self._separator = separator
        self._prefix = prefix

    def add_part(self, name: str, extractor: Callable[..., str]) -> KeyExtractor:
        """Add a key part with its extractor function. Returns self for chaining."""
        self._parts.append((name, extractor))
        return self

    def extract(self, *args: Any, **kwargs: Any) -> str:
        """Extract the key from the given arguments."""
        parts = []
        if self._prefix:
            parts.append(self._prefix)
        for name, extractor in self._parts:
            value = extractor(*args, **kwargs)
            parts.append(f"{name}={value}")
        return self._separator.join(parts)

    def __call__(self, *args: Any, **kwargs: Any) -> str:
        """Make the extractor callable for use with decorators."""
        return self.extract(*args, **kwargs)
