"""Pre-configured rate limiting policies for common use cases."""

from __future__ import annotations

from ratelimit.core import RateLimitConfig, Algorithm, RateLimiter
from ratelimit.factory import create_limiter
from ratelimit.groups import RateLimitGroup


def api_standard(key_prefix: str = "api") -> RateLimiter:
    """Standard API rate limit: 100 req/min with 20 burst."""
    return create_limiter(100, 60, burst_size=20, key_prefix=key_prefix)


def api_strict(key_prefix: str = "api_strict") -> RateLimiter:
    """Strict API rate limit: 30 req/min, no burst."""
    return create_limiter(30, 60, algorithm="fixed_window", key_prefix=key_prefix)


def api_generous(key_prefix: str = "api_generous") -> RateLimiter:
    """Generous API rate limit: 1000 req/min with 200 burst."""
    return create_limiter(1000, 60, burst_size=200, key_prefix=key_prefix)


def login_protection(key_prefix: str = "login") -> RateLimiter:
    """Login attempt limiting: 5 attempts per 15 minutes."""
    return create_limiter(5, 900, algorithm="sliding_window_log", key_prefix=key_prefix)


def webhook_delivery(key_prefix: str = "webhook") -> RateLimiter:
    """Webhook delivery: 10 req/sec with smooth output."""
    return create_limiter(10, 1, algorithm="leaky_bucket", key_prefix=key_prefix)


def search_api(key_prefix: str = "search") -> RateLimitGroup:
    """Search endpoint: 10 req/sec, 60 req/min (dual window)."""
    per_sec = create_limiter(10, 1, key_prefix=f"{key_prefix}_sec")
    per_min = create_limiter(60, 60, key_prefix=f"{key_prefix}_min")
    return RateLimitGroup(per_sec, per_min)


def upload_limit(key_prefix: str = "upload") -> RateLimiter:
    """File upload: 10 uploads per hour."""
    return create_limiter(10, 3600, algorithm="fixed_window", key_prefix=key_prefix)


def free_tier(key_prefix: str = "free") -> RateLimiter:
    """Free tier: 100 req/hour."""
    return create_limiter(100, 3600, key_prefix=key_prefix)


def pro_tier(key_prefix: str = "pro") -> RateLimiter:
    """Pro tier: 5000 req/hour with 100 burst."""
    return create_limiter(5000, 3600, burst_size=100, key_prefix=key_prefix)


def enterprise_tier(key_prefix: str = "enterprise") -> RateLimiter:
    """Enterprise tier: 50000 req/hour with 500 burst."""
    return create_limiter(50000, 3600, burst_size=500, key_prefix=key_prefix)


# Registry for dynamic lookup
PRESETS: dict[str, callable] = {
    "api_standard": api_standard,
    "api_strict": api_strict,
    "api_generous": api_generous,
    "login_protection": login_protection,
    "webhook_delivery": webhook_delivery,
    "search_api": search_api,
    "upload_limit": upload_limit,
    "free_tier": free_tier,
    "pro_tier": pro_tier,
    "enterprise_tier": enterprise_tier,
}


def get_preset(name: str, **kwargs) -> RateLimiter | RateLimitGroup:
    """Get a preset by name."""
    if name not in PRESETS:
        available = ", ".join(sorted(PRESETS.keys()))
        raise ValueError(f"Unknown preset: {name}. Available: {available}")
    return PRESETS[name](**kwargs)


def list_presets() -> list[str]:
    """List available preset names."""
    return sorted(PRESETS.keys())
