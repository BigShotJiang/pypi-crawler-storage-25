"""Context manager support for rate limiting."""

from __future__ import annotations

from ratelimit.core import RateLimiter, RateLimitResult
from ratelimit.algorithms.concurrency import ConcurrencyLimiter
from ratelimit.decorator import RateLimitExceeded


class RateLimitContext:
    """Async context manager for rate limiting.

    Usage:
        async with RateLimitContext(limiter, "user:123") as result:
            # result.allowed is guaranteed True here
            process_request()
    """

    def __init__(
        self,
        limiter: RateLimiter,
        key: str,
        cost: int = 1,
        wait: bool = False,
        timeout: float = 30.0,
    ):
        self._limiter = limiter
        self._key = key
        self._cost = cost
        self._wait = wait
        self._timeout = timeout
        self._result: RateLimitResult | None = None

    async def __aenter__(self) -> RateLimitResult:
        if self._wait:
            self._result = await self._limiter.wait_and_acquire(
                self._key, cost=self._cost, timeout=self._timeout
            )
        else:
            self._result = await self._limiter.acquire(self._key, cost=self._cost)
            if not self._result.allowed:
                raise RateLimitExceeded(self._result)
        return self._result

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        # If using concurrency limiter, release the lease
        if isinstance(self._limiter.algorithm, ConcurrencyLimiter) and self._result:
            lease_ids = self._result.metadata.get("lease_ids", [])
            for lid in lease_ids:
                await self._limiter.algorithm.release(self._key, lid)
        return False  # Don't suppress exceptions


class ConcurrencyContext:
    """Specialized context manager for concurrency limiting.

    Automatically acquires and releases concurrent slots.

    Usage:
        async with ConcurrencyContext(concurrency_limiter, "service:db") as result:
            # Slot is held
            await db.query(...)
        # Slot is automatically released
    """

    def __init__(self, limiter: ConcurrencyLimiter, key: str, cost: int = 1):
        self._limiter = limiter
        self._key = key
        self._cost = cost
        self._lease_ids: list[str] = []

    async def __aenter__(self) -> RateLimitResult:
        result = await self._limiter.acquire(self._key, cost=self._cost)
        if not result.allowed:
            raise RateLimitExceeded(result)
        self._lease_ids = result.metadata.get("lease_ids", [])
        return result

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        for lid in self._lease_ids:
            # ConcurrencyLimiter has release() directly, not via RateLimiter wrapper
            if isinstance(self._limiter, ConcurrencyLimiter):
                await self._limiter.release(self._key, lid)
        self._lease_ids = []
        return False
