"""Quota management for rate limiting.

Supports daily/monthly quotas and scheduled rate limit changes.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum


class QuotaPeriod(str, Enum):
    """Quota period types."""
    HOURLY = "hourly"
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"


@dataclass
class QuotaUsage:
    """Current quota usage."""
    used: int
    limit: int
    period: QuotaPeriod
    resets_at: float

    @property
    def remaining(self) -> int:
        return max(0, self.limit - self.used)

    @property
    def percentage_used(self) -> float:
        if self.limit == 0:
            return 100.0
        return (self.used / self.limit) * 100.0

    @property
    def is_exceeded(self) -> bool:
        return self.used >= self.limit


class QuotaManager:
    """Manages quotas over longer time periods.

    Unlike rate limiters which control request velocity,
    quotas control total volume over hours/days/months.
    """

    def __init__(self):
        self._quotas: dict[str, dict[QuotaPeriod, int]] = {}
        self._usage: dict[str, dict[QuotaPeriod, _UsageEntry]] = {}

    def set_quota(self, key: str, period: QuotaPeriod, limit: int) -> None:
        """Set a quota limit for a key."""
        if limit <= 0:
            raise ValueError("limit must be positive")
        if key not in self._quotas:
            self._quotas[key] = {}
        self._quotas[key][period] = limit

    def consume(self, key: str, amount: int = 1) -> list[QuotaUsage]:
        """Consume quota and return usage for all periods.

        Returns list of QuotaUsage for each configured period.
        Raises QuotaExceeded if any quota is exceeded.
        """
        quotas = self._quotas.get(key, {})
        if not quotas:
            return []

        results = []
        for period, limit in quotas.items():
            entry = self._get_or_create_entry(key, period)
            now = time.time()

            # Reset if period expired
            if now >= entry.resets_at:
                entry.used = 0
                entry.resets_at = _next_reset(period)

            entry.used += amount
            results.append(QuotaUsage(
                used=entry.used,
                limit=limit,
                period=period,
                resets_at=entry.resets_at,
            ))

        return results

    def check(self, key: str) -> list[QuotaUsage]:
        """Check quota usage without consuming."""
        quotas = self._quotas.get(key, {})
        if not quotas:
            return []

        results = []
        for period, limit in quotas.items():
            entry = self._get_or_create_entry(key, period)
            now = time.time()

            used = entry.used
            resets_at = entry.resets_at

            if now >= resets_at:
                used = 0
                resets_at = _next_reset(period)

            results.append(QuotaUsage(
                used=used,
                limit=limit,
                period=period,
                resets_at=resets_at,
            ))

        return results

    def reset(self, key: str, period: QuotaPeriod | None = None) -> None:
        """Reset quota usage for a key, optionally for a specific period."""
        if key in self._usage:
            if period is None:
                del self._usage[key]
            elif period in self._usage[key]:
                self._usage[key][period].used = 0

    def _get_or_create_entry(self, key: str, period: QuotaPeriod) -> _UsageEntry:
        if key not in self._usage:
            self._usage[key] = {}
        if period not in self._usage[key]:
            self._usage[key][period] = _UsageEntry(
                used=0,
                resets_at=_next_reset(period),
            )
        return self._usage[key][period]


@dataclass
class _UsageEntry:
    used: int
    resets_at: float


def _next_reset(period: QuotaPeriod) -> float:
    """Calculate next reset timestamp for the given period."""
    now = time.time()
    if period == QuotaPeriod.HOURLY:
        return now + 3600
    elif period == QuotaPeriod.DAILY:
        return now + 86400
    elif period == QuotaPeriod.WEEKLY:
        return now + 604800
    elif period == QuotaPeriod.MONTHLY:
        return now + 2592000  # 30 days
    return now + 86400
