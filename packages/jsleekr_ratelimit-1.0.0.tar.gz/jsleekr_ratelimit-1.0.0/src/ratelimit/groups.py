"""Rate limit groups and chains for complex rate limiting strategies."""

from __future__ import annotations

from ratelimit.core import RateLimiter, RateLimitResult


class RateLimitGroup:
    """Apply multiple independent rate limiters. All must allow for request to pass.

    Example: Apply both per-second and per-minute limits.
    """

    def __init__(self, *limiters: RateLimiter):
        if not limiters:
            raise ValueError("At least one limiter required")
        self._limiters = list(limiters)

    async def acquire(self, key: str, cost: int = 1) -> RateLimitResult:
        """Check all limiters. Only consume if ALL allow."""
        # First, peek all to check without consuming
        results = []
        for limiter in self._limiters:
            result = await limiter.peek(key)
            results.append(result)

        # If any would deny, return the most restrictive denial
        denied = [r for r in results if not r.allowed]
        if denied:
            most_restrictive = max(denied, key=lambda r: r.retry_after)
            return RateLimitResult(
                allowed=False,
                remaining=0,
                limit=min(r.limit for r in results),
                reset_at=most_restrictive.reset_at,
                retry_after=most_restrictive.retry_after,
            )

        # All would allow, now actually consume
        actual_results = []
        consumed_limiters = []
        for limiter in self._limiters:
            result = await limiter.acquire(key, cost)
            actual_results.append(result)
            if result.allowed:
                consumed_limiters.append(limiter)
            else:
                # A limiter denied during actual acquire (race condition).
                # Refund tokens from limiters that already consumed by resetting
                # Note: we cannot perfectly undo, but we avoid over-consuming
                # by stopping early and returning the denial.
                most_restrictive = max(
                    [r for r in actual_results if not r.allowed],
                    key=lambda r: r.retry_after,
                )
                return most_restrictive

        # Return the most restrictive "allowed" result
        most_restrictive = min(actual_results, key=lambda r: r.remaining)
        return most_restrictive

    async def peek(self, key: str) -> RateLimitResult:
        results = []
        for limiter in self._limiters:
            result = await limiter.peek(key)
            results.append(result)

        denied = [r for r in results if not r.allowed]
        if denied:
            most_restrictive = max(denied, key=lambda r: r.retry_after)
            return most_restrictive

        most_restrictive = min(results, key=lambda r: r.remaining)
        return most_restrictive

    async def reset(self, key: str) -> None:
        for limiter in self._limiters:
            await limiter.reset(key)


class RateLimitChain:
    """Apply rate limiters in sequence. First failure stops the chain.

    Unlike Group, this consumes tokens as it goes and does NOT peek first.
    More efficient but less fair in multi-limiter scenarios.
    """

    def __init__(self, *limiters: RateLimiter):
        if not limiters:
            raise ValueError("At least one limiter required")
        self._limiters = list(limiters)

    async def acquire(self, key: str, cost: int = 1) -> RateLimitResult:
        """Try each limiter in order. Stop on first denial."""
        for limiter in self._limiters:
            result = await limiter.acquire(key, cost)
            if not result.allowed:
                return result
        return result  # Last result (all passed)

    async def reset(self, key: str) -> None:
        for limiter in self._limiters:
            await limiter.reset(key)
