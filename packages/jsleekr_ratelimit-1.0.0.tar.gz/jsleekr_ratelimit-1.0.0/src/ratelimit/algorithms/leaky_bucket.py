"""Leaky Bucket rate limiting algorithm.

Requests queue up and are processed at a fixed rate.
Smooths out traffic bursts.
"""

from __future__ import annotations

import time
from dataclasses import dataclass

from ratelimit.core import (
    Algorithm,
    Backend,
    RateLimitConfig,
    RateLimitResult,
    RateLimiterAlgorithm,
)


@dataclass
class _LeakyState:
    water_level: float
    last_leak: float


class LeakyBucket(RateLimiterAlgorithm):
    """Leaky Bucket algorithm.

    Water (requests) enters the bucket and leaks out at a constant rate.
    If the bucket overflows, requests are rejected.
    """

    def __init__(self, backend: Backend, config: RateLimitConfig):
        self._backend = backend
        self._config = config
        self._capacity = config.burst_size or config.max_requests
        self._leak_rate = config.max_requests / config.window_seconds

    def _make_key(self, key: str) -> str:
        prefix = self._config.key_prefix or "lb"
        return f"{prefix}:{key}"

    async def _get_state(self, key: str) -> _LeakyState:
        full_key = self._make_key(key)
        data = await self._backend.get(full_key)
        if data is None:
            return _LeakyState(water_level=0.0, last_leak=time.time())
        return data

    async def _save_state(self, key: str, state: _LeakyState) -> None:
        full_key = self._make_key(key)
        await self._backend.set(full_key, state)

    def _leak(self, state: _LeakyState) -> _LeakyState:
        now = time.time()
        elapsed = now - state.last_leak
        leaked = elapsed * self._leak_rate
        new_level = max(0.0, state.water_level - leaked)
        return _LeakyState(water_level=new_level, last_leak=now)

    async def acquire(self, key: str, cost: int = 1) -> RateLimitResult:
        state = await self._get_state(key)
        state = self._leak(state)

        if state.water_level + cost <= self._capacity:
            state.water_level += cost
            await self._save_state(key, state)
            remaining = int(self._capacity - state.water_level)
            drain_time = state.water_level / self._leak_rate if self._leak_rate > 0 else 0
            return RateLimitResult(
                allowed=True,
                remaining=remaining,
                limit=self._capacity,
                reset_at=time.time() + drain_time,
            )
        else:
            await self._save_state(key, state)
            overflow = state.water_level + cost - self._capacity
            retry_after = overflow / self._leak_rate if self._leak_rate > 0 else 0
            return RateLimitResult(
                allowed=False,
                remaining=0,
                limit=self._capacity,
                reset_at=time.time() + retry_after,
                retry_after=retry_after,
            )

    async def peek(self, key: str) -> RateLimitResult:
        state = await self._get_state(key)
        state = self._leak(state)
        remaining = int(self._capacity - state.water_level)
        drain_time = state.water_level / self._leak_rate if self._leak_rate > 0 else 0
        return RateLimitResult(
            allowed=remaining >= 1,
            remaining=max(0, remaining),
            limit=self._capacity,
            reset_at=time.time() + drain_time,
        )

    async def reset(self, key: str) -> None:
        full_key = self._make_key(key)
        await self._backend.delete(full_key)

    def get_config(self) -> RateLimitConfig:
        return self._config
