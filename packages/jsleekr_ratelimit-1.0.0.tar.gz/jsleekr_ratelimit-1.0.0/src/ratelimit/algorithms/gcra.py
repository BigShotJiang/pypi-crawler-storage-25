"""Generic Cell Rate Algorithm (GCRA).

Also known as "Virtual Scheduling" algorithm.
Combines the best of token bucket and leaky bucket without
maintaining explicit counters. Used by Stripe, Shopify, etc.
"""

from __future__ import annotations

import time

from ratelimit.core import (
    Backend,
    RateLimitConfig,
    RateLimitResult,
    RateLimiterAlgorithm,
)


class GCRA(RateLimiterAlgorithm):
    """Generic Cell Rate Algorithm.

    Tracks a TAT (Theoretical Arrival Time) per key.
    Each request computes when the next request should arrive
    based on the emission interval (window / max_requests).
    """

    def __init__(self, backend: Backend, config: RateLimitConfig):
        self._backend = backend
        self._config = config
        self._emission_interval = config.window_seconds / config.max_requests
        self._burst = config.burst_size or config.max_requests
        self._delay_tolerance = self._emission_interval * self._burst

    def _make_key(self, key: str) -> str:
        prefix = self._config.key_prefix or "gcra"
        return f"{prefix}:{key}"

    async def acquire(self, key: str, cost: int = 1) -> RateLimitResult:
        full_key = self._make_key(key)
        now = time.time()
        increment = self._emission_interval * cost

        tat = await self._backend.get(full_key)
        if tat is None:
            tat = now

        new_tat = max(tat, now) + increment
        allow_at = new_tat - self._delay_tolerance

        if allow_at <= now:
            await self._backend.set(full_key, new_tat, ttl=self._delay_tolerance + self._emission_interval)
            remaining = max(0, int((self._delay_tolerance - (new_tat - now)) / self._emission_interval))
            return RateLimitResult(
                allowed=True,
                remaining=remaining,
                limit=self._burst,
                reset_at=new_tat,
            )
        else:
            retry_after = allow_at - now
            return RateLimitResult(
                allowed=False,
                remaining=0,
                limit=self._burst,
                reset_at=tat,
                retry_after=retry_after,
            )

    async def peek(self, key: str) -> RateLimitResult:
        full_key = self._make_key(key)
        now = time.time()

        tat = await self._backend.get(full_key)
        if tat is None:
            return RateLimitResult(
                allowed=True,
                remaining=self._burst,
                limit=self._burst,
                reset_at=now,
            )

        new_tat = max(tat, now) + self._emission_interval
        allow_at = new_tat - self._delay_tolerance

        if allow_at <= now:
            remaining = max(0, int((self._delay_tolerance - (new_tat - now)) / self._emission_interval))
            return RateLimitResult(
                allowed=True,
                remaining=remaining,
                limit=self._burst,
                reset_at=tat,
            )
        else:
            return RateLimitResult(
                allowed=False,
                remaining=0,
                limit=self._burst,
                reset_at=tat,
                retry_after=max(0, allow_at - now),
            )

    async def reset(self, key: str) -> None:
        full_key = self._make_key(key)
        await self._backend.delete(full_key)

    def get_config(self) -> RateLimitConfig:
        return self._config
