"""Concurrency Limiter algorithm.

Limits the number of concurrent in-flight requests.
Different from rate limiting - controls parallelism rather than throughput.
"""

from __future__ import annotations

import time
import uuid

from ratelimit.core import (
    Algorithm,
    Backend,
    RateLimitConfig,
    RateLimitResult,
    RateLimiterAlgorithm,
)


class ConcurrencyLimiter(RateLimiterAlgorithm):
    """Concurrency limiter.

    Limits the number of concurrent operations. Each acquire() must be
    paired with a release() call.
    """

    def __init__(self, backend: Backend, config: RateLimitConfig):
        self._backend = backend
        self._config = config
        self._max_concurrent = config.max_requests
        self._timeout = config.window_seconds  # re-use as lease timeout

    def _make_key(self, key: str) -> str:
        prefix = self._config.key_prefix or "cc"
        return f"{prefix}:{key}"

    async def _cleanup_expired(self, key: str) -> int:
        """Remove expired leases and return active count."""
        full_key = self._make_key(key)
        now = time.time()
        leases = await self._backend.get(full_key)
        if leases is None:
            return 0
        # Filter out expired leases
        active = {lid: exp for lid, exp in leases.items() if exp > now}
        await self._backend.set(full_key, active)
        return len(active)

    async def acquire(self, key: str, cost: int = 1) -> RateLimitResult:
        full_key = self._make_key(key)
        now = time.time()

        leases = await self._backend.get(full_key)
        if leases is None:
            leases = {}

        # Cleanup expired
        leases = {lid: exp for lid, exp in leases.items() if exp > now}
        active = len(leases)

        if active + cost <= self._max_concurrent:
            lease_ids = []
            for _ in range(cost):
                lease_id = str(uuid.uuid4())
                leases[lease_id] = now + self._timeout
                lease_ids.append(lease_id)
            await self._backend.set(full_key, leases)
            return RateLimitResult(
                allowed=True,
                remaining=self._max_concurrent - active - cost,
                limit=self._max_concurrent,
                reset_at=now + self._timeout,
                metadata={"lease_ids": lease_ids},
            )
        else:
            # Find earliest expiring lease
            if leases:
                earliest_exp = min(leases.values())
                retry_after = max(0, earliest_exp - now)
            else:
                retry_after = 0
            await self._backend.set(full_key, leases)
            return RateLimitResult(
                allowed=False,
                remaining=0,
                limit=self._max_concurrent,
                reset_at=now + retry_after,
                retry_after=retry_after,
            )

    async def release(self, key: str, lease_id: str) -> bool:
        """Release a lease. Returns True if lease was found and released."""
        full_key = self._make_key(key)
        leases = await self._backend.get(full_key)
        if leases is None:
            return False
        if lease_id in leases:
            del leases[lease_id]
            await self._backend.set(full_key, leases)
            return True
        return False

    async def peek(self, key: str) -> RateLimitResult:
        active = await self._cleanup_expired(key)
        remaining = max(0, self._max_concurrent - active)
        return RateLimitResult(
            allowed=remaining > 0,
            remaining=remaining,
            limit=self._max_concurrent,
            reset_at=time.time() + self._timeout,
        )

    async def reset(self, key: str) -> None:
        full_key = self._make_key(key)
        await self._backend.delete(full_key)

    def get_config(self) -> RateLimitConfig:
        return self._config
