"""Sliding Window rate limiting algorithms.

Two variants:
- SlidingWindowLog: Exact, stores each request timestamp. More memory.
- SlidingWindowCounter: Approximate, uses weighted counters. Less memory.
"""

from __future__ import annotations

import time

from ratelimit.core import (
    Algorithm,
    Backend,
    RateLimitConfig,
    RateLimitResult,
    RateLimiterAlgorithm,
)


class SlidingWindowLog(RateLimiterAlgorithm):
    """Sliding Window Log algorithm.

    Stores timestamps of all requests within the window.
    Exact counting but uses more memory.
    """

    def __init__(self, backend: Backend, config: RateLimitConfig):
        self._backend = backend
        self._config = config

    def _make_key(self, key: str) -> str:
        prefix = self._config.key_prefix or "swl"
        return f"{prefix}:{key}"

    async def acquire(self, key: str, cost: int = 1) -> RateLimitResult:
        full_key = self._make_key(key)
        now = time.time()
        window_start = now - self._config.window_seconds

        # Remove expired entries
        count = await self._backend.trim_list(full_key, window_start)

        if count + cost <= self._config.max_requests:
            # Add timestamps for each unit of cost
            for _ in range(cost):
                await self._backend.append_list(full_key, now, ttl=self._config.window_seconds * 2)
            remaining = self._config.max_requests - count - cost
            return RateLimitResult(
                allowed=True,
                remaining=remaining,
                limit=self._config.max_requests,
                reset_at=now + self._config.window_seconds,
            )
        else:
            # Get oldest timestamp to calculate retry_after
            timestamps = await self._backend.get_list(full_key)
            if timestamps:
                oldest = min(timestamps)
                retry_after = oldest + self._config.window_seconds - now
            else:
                retry_after = self._config.window_seconds
            return RateLimitResult(
                allowed=False,
                remaining=0,
                limit=self._config.max_requests,
                reset_at=now + max(0, retry_after),
                retry_after=max(0, retry_after),
            )

    async def peek(self, key: str) -> RateLimitResult:
        full_key = self._make_key(key)
        now = time.time()
        window_start = now - self._config.window_seconds
        count = await self._backend.trim_list(full_key, window_start)
        remaining = max(0, self._config.max_requests - count)
        return RateLimitResult(
            allowed=remaining > 0,
            remaining=remaining,
            limit=self._config.max_requests,
            reset_at=now + self._config.window_seconds,
        )

    async def reset(self, key: str) -> None:
        full_key = self._make_key(key)
        await self._backend.delete(full_key)

    def get_config(self) -> RateLimitConfig:
        return self._config


class SlidingWindowCounter(RateLimiterAlgorithm):
    """Sliding Window Counter algorithm.

    Approximation using weighted counts from current and previous windows.
    More memory-efficient than the log variant.
    """

    def __init__(self, backend: Backend, config: RateLimitConfig):
        self._backend = backend
        self._config = config

    def _make_key(self, key: str, window: int) -> str:
        prefix = self._config.key_prefix or "swc"
        return f"{prefix}:{key}:{window}"

    def _current_window(self) -> int:
        return int(time.time() // self._config.window_seconds)

    def _window_position(self) -> float:
        """Returns how far we are into the current window (0.0 to 1.0)."""
        return (time.time() % self._config.window_seconds) / self._config.window_seconds

    async def _get_weighted_count(self, key: str) -> float:
        window = self._current_window()
        prev_window = window - 1
        position = self._window_position()

        curr_key = self._make_key(key, window)
        prev_key = self._make_key(key, prev_window)

        curr_count = await self._backend.get(curr_key) or 0
        prev_count = await self._backend.get(prev_key) or 0

        # Weighted count: full current + proportional previous
        return curr_count + prev_count * (1 - position)

    async def acquire(self, key: str, cost: int = 1) -> RateLimitResult:
        weighted = await self._get_weighted_count(key)
        now = time.time()
        reset_at = (self._current_window() + 1) * self._config.window_seconds

        if weighted + cost <= self._config.max_requests:
            window = self._current_window()
            curr_key = self._make_key(key, window)
            ttl = self._config.window_seconds * 2
            await self._backend.increment(curr_key, cost, ttl=ttl)
            remaining = int(self._config.max_requests - weighted - cost)
            return RateLimitResult(
                allowed=True,
                remaining=max(0, remaining),
                limit=self._config.max_requests,
                reset_at=reset_at,
            )
        else:
            retry_after = reset_at - now
            return RateLimitResult(
                allowed=False,
                remaining=0,
                limit=self._config.max_requests,
                reset_at=reset_at,
                retry_after=max(0, retry_after),
            )

    async def peek(self, key: str) -> RateLimitResult:
        weighted = await self._get_weighted_count(key)
        remaining = max(0, int(self._config.max_requests - weighted))
        reset_at = (self._current_window() + 1) * self._config.window_seconds
        return RateLimitResult(
            allowed=remaining > 0,
            remaining=remaining,
            limit=self._config.max_requests,
            reset_at=reset_at,
        )

    async def reset(self, key: str) -> None:
        window = self._current_window()
        for w in (window, window - 1):
            full_key = self._make_key(key, w)
            await self._backend.delete(full_key)

    def get_config(self) -> RateLimitConfig:
        return self._config
