"""Fixed Window rate limiting algorithm.

Divides time into fixed windows and counts requests per window.
Simple and memory-efficient but can allow 2x burst at window boundaries.
"""

from __future__ import annotations

import math
import time

from ratelimit.core import (
    Algorithm,
    Backend,
    RateLimitConfig,
    RateLimitResult,
    RateLimiterAlgorithm,
)


class FixedWindow(RateLimiterAlgorithm):
    """Fixed Window Counter algorithm.

    Time is divided into fixed-size windows. Each window has its own counter.
    """

    def __init__(self, backend: Backend, config: RateLimitConfig):
        self._backend = backend
        self._config = config

    def _make_key(self, key: str) -> str:
        prefix = self._config.key_prefix or "fw"
        window = self._current_window()
        return f"{prefix}:{key}:{window}"

    def _current_window(self) -> int:
        return int(time.time() // self._config.window_seconds)

    def _window_reset_at(self) -> float:
        window = self._current_window()
        return (window + 1) * self._config.window_seconds

    async def acquire(self, key: str, cost: int = 1) -> RateLimitResult:
        full_key = self._make_key(key)
        reset_at = self._window_reset_at()
        ttl = reset_at - time.time()

        count = await self._backend.increment(full_key, cost, ttl=ttl)

        if count <= self._config.max_requests:
            return RateLimitResult(
                allowed=True,
                remaining=self._config.max_requests - count,
                limit=self._config.max_requests,
                reset_at=reset_at,
            )
        else:
            # Undo the increment since we're rejecting
            await self._backend.increment(full_key, -cost, ttl=ttl)
            retry_after = reset_at - time.time()
            return RateLimitResult(
                allowed=False,
                remaining=0,
                limit=self._config.max_requests,
                reset_at=reset_at,
                retry_after=max(0, retry_after),
            )

    async def peek(self, key: str) -> RateLimitResult:
        full_key = self._make_key(key)
        reset_at = self._window_reset_at()
        count = await self._backend.get(full_key)
        count = count or 0
        remaining = max(0, self._config.max_requests - count)
        return RateLimitResult(
            allowed=remaining > 0,
            remaining=remaining,
            limit=self._config.max_requests,
            reset_at=reset_at,
        )

    async def reset(self, key: str) -> None:
        full_key = self._make_key(key)
        await self._backend.delete(full_key)

    def get_config(self) -> RateLimitConfig:
        return self._config
