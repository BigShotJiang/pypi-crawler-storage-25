"""Token Bucket rate limiting algorithm.

Tokens are added at a fixed rate. Each request consumes tokens.
Allows bursting up to bucket capacity.
"""

from __future__ import annotations

import time
from dataclasses import dataclass

from ratelimit.core import (
    Algorithm,
    Backend,
    RateLimitConfig,
    RateLimitResult,
    RateLimiterAlgorithm,
)


@dataclass
class _BucketState:
    tokens: float
    last_refill: float
    capacity: int
    refill_rate: float


class TokenBucket(RateLimiterAlgorithm):
    """Token Bucket algorithm.

    Tokens refill at a constant rate (max_requests / window_seconds).
    Bucket capacity = burst_size (defaults to max_requests).
    """

    def __init__(self, backend: Backend, config: RateLimitConfig):
        self._backend = backend
        self._config = config
        self._capacity = config.burst_size or config.max_requests
        self._refill_rate = config.max_requests / config.window_seconds

    def _make_key(self, key: str) -> str:
        prefix = self._config.key_prefix or "tb"
        return f"{prefix}:{key}"

    async def _get_state(self, key: str) -> _BucketState:
        full_key = self._make_key(key)
        data = await self._backend.get(full_key)
        if data is None:
            return _BucketState(
                tokens=float(self._capacity),
                last_refill=time.time(),
                capacity=self._capacity,
                refill_rate=self._refill_rate,
            )
        return data

    async def _save_state(self, key: str, state: _BucketState) -> None:
        full_key = self._make_key(key)
        await self._backend.set(full_key, state)

    def _refill(self, state: _BucketState) -> _BucketState:
        now = time.time()
        elapsed = now - state.last_refill
        new_tokens = min(
            state.capacity,
            state.tokens + elapsed * state.refill_rate,
        )
        return _BucketState(
            tokens=new_tokens,
            last_refill=now,
            capacity=state.capacity,
            refill_rate=state.refill_rate,
        )

    async def acquire(self, key: str, cost: int = 1) -> RateLimitResult:
        state = await self._get_state(key)
        state = self._refill(state)

        if state.tokens >= cost:
            state.tokens -= cost
            await self._save_state(key, state)
            # Calculate reset: time until bucket is full again
            deficit = state.capacity - state.tokens
            reset_at = time.time() + (deficit / state.refill_rate if state.refill_rate > 0 else 0)
            return RateLimitResult(
                allowed=True,
                remaining=int(state.tokens),
                limit=state.capacity,
                reset_at=reset_at,
            )
        else:
            await self._save_state(key, state)
            tokens_needed = cost - state.tokens
            retry_after = tokens_needed / state.refill_rate if state.refill_rate > 0 else 0
            reset_at = time.time() + retry_after
            return RateLimitResult(
                allowed=False,
                remaining=0,
                limit=state.capacity,
                reset_at=reset_at,
                retry_after=retry_after,
            )

    async def peek(self, key: str) -> RateLimitResult:
        state = await self._get_state(key)
        state = self._refill(state)
        deficit = state.capacity - state.tokens
        reset_at = time.time() + (deficit / state.refill_rate if state.refill_rate > 0 else 0)
        return RateLimitResult(
            allowed=state.tokens >= 1,
            remaining=int(state.tokens),
            limit=state.capacity,
            reset_at=reset_at,
        )

    async def reset(self, key: str) -> None:
        full_key = self._make_key(key)
        await self._backend.delete(full_key)

    def get_config(self) -> RateLimitConfig:
        return self._config
