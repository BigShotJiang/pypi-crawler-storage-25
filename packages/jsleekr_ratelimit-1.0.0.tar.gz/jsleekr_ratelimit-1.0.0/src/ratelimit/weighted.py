"""Weighted rate limiter with priority support.

Different endpoints or operations can have different costs, and
priority keys can get preferential treatment.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum

from ratelimit.core import RateLimiter, RateLimitResult, RateLimitConfig


class Priority(IntEnum):
    """Request priority levels. Higher value = higher priority."""
    LOW = 0
    NORMAL = 1
    HIGH = 2
    CRITICAL = 3


@dataclass
class WeightedRoute:
    """A route with its cost weight."""
    pattern: str
    cost: int = 1

    def __post_init__(self):
        if self.cost <= 0:
            raise ValueError("cost must be positive")


class WeightedRateLimiter:
    """Rate limiter that supports different costs per operation.

    Can also reserve capacity for high-priority requests.
    """

    def __init__(
        self,
        limiter: RateLimiter,
        priority_reserves: dict[Priority, float] | None = None,
    ):
        """Initialize weighted rate limiter.

        Args:
            limiter: Underlying rate limiter.
            priority_reserves: Percentage of capacity to reserve per priority.
                Example: {Priority.CRITICAL: 0.1} reserves 10% for critical.
        """
        self._limiter = limiter
        self._reserves = priority_reserves or {}
        total = sum(self._reserves.values())
        if total > 1.0:
            raise ValueError("Total priority reserves cannot exceed 1.0 (100%)")

    async def acquire(
        self,
        key: str,
        cost: int = 1,
        priority: Priority = Priority.NORMAL,
    ) -> RateLimitResult:
        """Acquire with weighted cost and priority."""
        # Check if we need to enforce priority reserves
        if self._reserves and priority < Priority.CRITICAL:
            peek = await self._limiter.peek(key)
            config = self._limiter.get_config()
            capacity = config.burst_size or config.max_requests

            # Calculate reserved capacity for higher priorities
            reserved = 0.0
            for p, reserve_pct in self._reserves.items():
                if p > priority:
                    reserved += reserve_pct

            available = peek.remaining
            reserved_capacity = int(capacity * reserved)

            if available <= reserved_capacity:
                return RateLimitResult(
                    allowed=False,
                    remaining=0,
                    limit=peek.limit,
                    reset_at=peek.reset_at,
                    retry_after=peek.reset_in,
                    metadata={"reason": "capacity_reserved", "priority": priority.name},
                )

        return await self._limiter.acquire(key, cost=cost)

    async def peek(self, key: str) -> RateLimitResult:
        return await self._limiter.peek(key)

    async def reset(self, key: str) -> None:
        await self._limiter.reset(key)


class CostCalculator:
    """Calculates request cost based on route patterns."""

    def __init__(self):
        self._routes: list[WeightedRoute] = []
        self._default_cost = 1

    def add_route(self, pattern: str, cost: int) -> None:
        """Add a route with its cost."""
        self._routes.append(WeightedRoute(pattern=pattern, cost=cost))

    def set_default_cost(self, cost: int) -> None:
        """Set default cost for unmatched routes."""
        if cost <= 0:
            raise ValueError("cost must be positive")
        self._default_cost = cost

    def get_cost(self, path: str) -> int:
        """Get the cost for a given path."""
        for route in self._routes:
            if self._matches(route.pattern, path):
                return route.cost
        return self._default_cost

    def _matches(self, pattern: str, path: str) -> bool:
        """Simple prefix/suffix/exact matching."""
        if pattern.endswith("*"):
            return path.startswith(pattern[:-1])
        if pattern.startswith("*"):
            return path.endswith(pattern[1:])
        return pattern == path
