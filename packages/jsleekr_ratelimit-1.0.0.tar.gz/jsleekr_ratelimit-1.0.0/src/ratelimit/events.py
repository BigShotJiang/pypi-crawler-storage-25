"""Event system for rate limiter lifecycle hooks."""

from __future__ import annotations

import asyncio
import inspect
from enum import Enum
from typing import Any, Callable


class EventType(str, Enum):
    """Rate limiter event types."""
    ACQUIRED = "acquired"
    DENIED = "denied"
    RESET = "reset"
    QUOTA_WARNING = "quota_warning"
    QUOTA_EXCEEDED = "quota_exceeded"
    PENALTY_APPLIED = "penalty_applied"


class Event:
    """A rate limiter event."""

    __slots__ = ("type", "key", "data", "timestamp")

    def __init__(self, event_type: EventType, key: str, data: dict[str, Any] | None = None):
        import time
        self.type = event_type
        self.key = key
        self.data = data or {}
        self.timestamp = time.time()

    def __repr__(self) -> str:
        return f"Event({self.type.value}, key={self.key!r})"


class EventEmitter:
    """Async-compatible event emitter for rate limiter events.

    Supports both sync and async handlers.
    """

    def __init__(self):
        self._handlers: dict[EventType, list[Callable]] = {}
        self._global_handlers: list[Callable] = []

    def on(self, event_type: EventType, handler: Callable) -> Callable:
        """Register a handler for an event type. Returns handler for decorator use."""
        if event_type not in self._handlers:
            self._handlers[event_type] = []
        self._handlers[event_type].append(handler)
        return handler

    def on_any(self, handler: Callable) -> Callable:
        """Register a handler for all events."""
        self._global_handlers.append(handler)
        return handler

    def off(self, event_type: EventType, handler: Callable) -> bool:
        """Remove a handler. Returns True if handler was found."""
        if event_type in self._handlers:
            try:
                self._handlers[event_type].remove(handler)
                return True
            except ValueError:
                pass
        return False

    def off_any(self, handler: Callable) -> bool:
        """Remove a global handler. Returns True if found."""
        try:
            self._global_handlers.remove(handler)
            return True
        except ValueError:
            return False

    async def emit(self, event: Event) -> None:
        """Emit an event, calling all registered handlers."""
        handlers = list(self._global_handlers)
        if event.type in self._handlers:
            handlers.extend(self._handlers[event.type])

        for handler in handlers:
            if inspect.iscoroutinefunction(handler):
                await handler(event)
            else:
                handler(event)

    def handler_count(self, event_type: EventType | None = None) -> int:
        """Get number of handlers for a type, or total."""
        if event_type is None:
            total = len(self._global_handlers)
            for handlers in self._handlers.values():
                total += len(handlers)
            return total
        return len(self._handlers.get(event_type, []))

    def clear(self) -> None:
        """Remove all handlers."""
        self._handlers.clear()
        self._global_handlers.clear()
