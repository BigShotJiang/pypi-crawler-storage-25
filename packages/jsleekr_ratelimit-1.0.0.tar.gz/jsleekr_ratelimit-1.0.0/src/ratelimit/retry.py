"""Retry strategies for rate-limited operations."""

from __future__ import annotations

import asyncio
import random
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Callable, TypeVar

from ratelimit.core import RateLimiter, RateLimitResult

T = TypeVar("T")


class RetryStrategy(ABC):
    """Abstract retry strategy."""

    @abstractmethod
    def get_delay(self, attempt: int, result: RateLimitResult) -> float:
        """Calculate delay before next retry in seconds."""

    @abstractmethod
    def should_retry(self, attempt: int, result: RateLimitResult) -> bool:
        """Whether to retry after a failed attempt."""


class FixedRetry(RetryStrategy):
    """Fixed delay between retries."""

    def __init__(self, delay: float = 1.0, max_retries: int = 3):
        if delay <= 0:
            raise ValueError("delay must be positive")
        if max_retries < 0:
            raise ValueError("max_retries must be non-negative")
        self._delay = delay
        self._max_retries = max_retries

    def get_delay(self, attempt: int, result: RateLimitResult) -> float:
        return self._delay

    def should_retry(self, attempt: int, result: RateLimitResult) -> bool:
        return attempt < self._max_retries


class ExponentialBackoff(RetryStrategy):
    """Exponential backoff with optional jitter."""

    def __init__(
        self,
        base_delay: float = 0.5,
        max_delay: float = 60.0,
        max_retries: int = 5,
        jitter: bool = True,
    ):
        if base_delay <= 0:
            raise ValueError("base_delay must be positive")
        if max_delay < base_delay:
            raise ValueError("max_delay must be >= base_delay")
        if max_retries < 0:
            raise ValueError("max_retries must be non-negative")
        self._base_delay = base_delay
        self._max_delay = max_delay
        self._max_retries = max_retries
        self._jitter = jitter

    def get_delay(self, attempt: int, result: RateLimitResult) -> float:
        delay = min(self._base_delay * (2 ** attempt), self._max_delay)
        if self._jitter:
            delay = random.uniform(0, delay)
        return delay

    def should_retry(self, attempt: int, result: RateLimitResult) -> bool:
        return attempt < self._max_retries


class RetryAfterStrategy(RetryStrategy):
    """Use the server's Retry-After hint with optional multiplier."""

    def __init__(self, max_retries: int = 3, multiplier: float = 1.0):
        if max_retries < 0:
            raise ValueError("max_retries must be non-negative")
        if multiplier <= 0:
            raise ValueError("multiplier must be positive")
        self._max_retries = max_retries
        self._multiplier = multiplier

    def get_delay(self, attempt: int, result: RateLimitResult) -> float:
        return max(0.1, result.retry_after * self._multiplier)

    def should_retry(self, attempt: int, result: RateLimitResult) -> bool:
        return attempt < self._max_retries


@dataclass
class RetryResult:
    """Result of a retry operation."""
    success: bool
    attempts: int
    total_wait: float
    last_result: RateLimitResult


async def retry_acquire(
    limiter: RateLimiter,
    key: str,
    strategy: RetryStrategy,
    cost: int = 1,
) -> RetryResult:
    """Retry acquiring a rate limit with the given strategy.

    Args:
        limiter: The rate limiter to acquire from.
        key: The rate limit key.
        strategy: The retry strategy to use.
        cost: Cost per acquisition attempt.

    Returns:
        RetryResult with success status and attempt details.
    """
    total_wait = 0.0
    attempt = 0

    while True:
        result = await limiter.acquire(key, cost=cost)
        if result.allowed:
            return RetryResult(
                success=True,
                attempts=attempt + 1,
                total_wait=total_wait,
                last_result=result,
            )

        if not strategy.should_retry(attempt, result):
            return RetryResult(
                success=False,
                attempts=attempt + 1,
                total_wait=total_wait,
                last_result=result,
            )

        delay = strategy.get_delay(attempt, result)
        await asyncio.sleep(delay)
        total_wait += delay
        attempt += 1
