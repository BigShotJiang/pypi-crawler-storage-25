"""Rate limiter introspection and information utilities."""

from __future__ import annotations

from dataclasses import dataclass
from ratelimit.core import Algorithm


@dataclass(frozen=True)
class AlgorithmInfo:
    """Information about a rate limiting algorithm."""
    name: str
    algorithm: Algorithm
    description: str
    supports_burst: bool
    memory_complexity: str
    best_for: str
    boundary_issue: bool


_ALGORITHM_INFO: dict[Algorithm, AlgorithmInfo] = {
    Algorithm.TOKEN_BUCKET: AlgorithmInfo(
        name="Token Bucket",
        algorithm=Algorithm.TOKEN_BUCKET,
        description="Tokens are added at a fixed rate. Each request consumes tokens. Allows bursting up to capacity.",
        supports_burst=True,
        memory_complexity="O(1)",
        best_for="General API rate limiting with burst support",
        boundary_issue=False,
    ),
    Algorithm.FIXED_WINDOW: AlgorithmInfo(
        name="Fixed Window",
        algorithm=Algorithm.FIXED_WINDOW,
        description="Divides time into fixed windows and counts requests per window.",
        supports_burst=False,
        memory_complexity="O(1)",
        best_for="Simple counter-based rate limiting",
        boundary_issue=True,
    ),
    Algorithm.SLIDING_WINDOW_LOG: AlgorithmInfo(
        name="Sliding Window Log",
        algorithm=Algorithm.SLIDING_WINDOW_LOG,
        description="Stores timestamps of all requests. Exact counting but more memory.",
        supports_burst=False,
        memory_complexity="O(n)",
        best_for="Exact rate limiting where accuracy is critical",
        boundary_issue=False,
    ),
    Algorithm.SLIDING_WINDOW_COUNTER: AlgorithmInfo(
        name="Sliding Window Counter",
        algorithm=Algorithm.SLIDING_WINDOW_COUNTER,
        description="Weighted counters from current and previous windows. Balanced accuracy/memory.",
        supports_burst=False,
        memory_complexity="O(1)",
        best_for="Balanced accuracy and memory efficiency",
        boundary_issue=False,
    ),
    Algorithm.LEAKY_BUCKET: AlgorithmInfo(
        name="Leaky Bucket",
        algorithm=Algorithm.LEAKY_BUCKET,
        description="Requests queue up and drain at a constant rate. Smooths traffic.",
        supports_burst=True,
        memory_complexity="O(1)",
        best_for="Traffic smoothing and output shaping",
        boundary_issue=False,
    ),
    Algorithm.CONCURRENCY: AlgorithmInfo(
        name="Concurrency Limiter",
        algorithm=Algorithm.CONCURRENCY,
        description="Limits concurrent in-flight requests, not throughput.",
        supports_burst=False,
        memory_complexity="O(n)",
        best_for="Controlling parallelism for resource-bound operations",
        boundary_issue=False,
    ),
    Algorithm.GCRA: AlgorithmInfo(
        name="GCRA (Generic Cell Rate Algorithm)",
        algorithm=Algorithm.GCRA,
        description="Virtual scheduling algorithm. Tracks theoretical arrival time per key.",
        supports_burst=True,
        memory_complexity="O(1)",
        best_for="Production systems (used by Stripe, Shopify)",
        boundary_issue=False,
    ),
}


def get_algorithm_info(algorithm: Algorithm | str) -> AlgorithmInfo:
    """Get information about an algorithm."""
    if isinstance(algorithm, str):
        algorithm = Algorithm(algorithm)
    info = _ALGORITHM_INFO.get(algorithm)
    if info is None:
        raise ValueError(f"Unknown algorithm: {algorithm}")
    return info


def list_algorithms() -> list[AlgorithmInfo]:
    """List all available algorithms with their info."""
    return list(_ALGORITHM_INFO.values())


def recommend_algorithm(
    needs_burst: bool = False,
    needs_exactness: bool = False,
    needs_smoothing: bool = False,
    memory_constrained: bool = False,
    is_concurrency: bool = False,
) -> AlgorithmInfo:
    """Recommend the best algorithm for given requirements."""
    if is_concurrency:
        return _ALGORITHM_INFO[Algorithm.CONCURRENCY]
    if needs_smoothing:
        return _ALGORITHM_INFO[Algorithm.LEAKY_BUCKET]
    if needs_exactness:
        return _ALGORITHM_INFO[Algorithm.SLIDING_WINDOW_LOG]
    if needs_burst and memory_constrained:
        return _ALGORITHM_INFO[Algorithm.GCRA]
    if needs_burst:
        return _ALGORITHM_INFO[Algorithm.TOKEN_BUCKET]
    if memory_constrained:
        return _ALGORITHM_INFO[Algorithm.FIXED_WINDOW]
    return _ALGORITHM_INFO[Algorithm.GCRA]  # Default: best all-rounder
