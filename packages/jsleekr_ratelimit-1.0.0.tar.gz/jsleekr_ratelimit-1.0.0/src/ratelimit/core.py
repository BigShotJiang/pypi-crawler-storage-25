"""Core rate limiter interfaces and types."""

from __future__ import annotations

import asyncio
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Protocol


class Algorithm(str, Enum):
    """Available rate limiting algorithms."""
    TOKEN_BUCKET = "token_bucket"
    SLIDING_WINDOW_LOG = "sliding_window_log"
    SLIDING_WINDOW_COUNTER = "sliding_window_counter"
    FIXED_WINDOW = "fixed_window"
    LEAKY_BUCKET = "leaky_bucket"
    CONCURRENCY = "concurrency"
    GCRA = "gcra"


@dataclass(frozen=True)
class RateLimitResult:
    """Result of a rate limit check."""
    allowed: bool
    remaining: int
    limit: int
    reset_at: float
    retry_after: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def reset_in(self) -> float:
        """Seconds until the rate limit resets."""
        return max(0.0, self.reset_at - time.time())

    def to_headers(self) -> dict[str, str]:
        """Convert to standard rate limit HTTP headers."""
        headers = {
            "X-RateLimit-Limit": str(self.limit),
            "X-RateLimit-Remaining": str(max(0, self.remaining)),
            "X-RateLimit-Reset": str(int(self.reset_at)),
        }
        if not self.allowed and self.retry_after > 0:
            headers["Retry-After"] = str(int(self.retry_after) + 1)
        return headers


@dataclass
class RateLimitConfig:
    """Configuration for a rate limiter."""
    max_requests: int
    window_seconds: float
    algorithm: Algorithm = Algorithm.TOKEN_BUCKET
    burst_size: int | None = None
    key_prefix: str = ""

    def __post_init__(self):
        if self.max_requests <= 0:
            raise ValueError("max_requests must be positive")
        if self.window_seconds <= 0:
            raise ValueError("window_seconds must be positive")
        if self.burst_size is not None and self.burst_size <= 0:
            raise ValueError("burst_size must be positive")


class Backend(ABC):
    """Abstract storage backend for rate limiter state."""

    @abstractmethod
    async def get(self, key: str) -> Any | None:
        """Get value for key."""

    @abstractmethod
    async def set(self, key: str, value: Any, ttl: float | None = None) -> None:
        """Set value for key with optional TTL."""

    @abstractmethod
    async def delete(self, key: str) -> None:
        """Delete key."""

    @abstractmethod
    async def increment(self, key: str, amount: int = 1, ttl: float | None = None) -> int:
        """Atomically increment a counter, return new value."""

    @abstractmethod
    async def get_list(self, key: str) -> list[Any]:
        """Get a list stored at key."""

    @abstractmethod
    async def append_list(self, key: str, value: Any, ttl: float | None = None) -> None:
        """Append to a list at key."""

    @abstractmethod
    async def trim_list(self, key: str, min_value: Any) -> int:
        """Remove list elements less than min_value, return remaining count."""

    @abstractmethod
    async def clear(self) -> None:
        """Clear all data."""


class RateLimiterAlgorithm(ABC):
    """Abstract rate limiting algorithm."""

    @abstractmethod
    async def acquire(self, key: str, cost: int = 1) -> RateLimitResult:
        """Try to acquire permission. Returns result with allowed=True/False."""

    @abstractmethod
    async def peek(self, key: str) -> RateLimitResult:
        """Check current state without consuming tokens."""

    @abstractmethod
    async def reset(self, key: str) -> None:
        """Reset the rate limiter for a key."""

    @abstractmethod
    def get_config(self) -> RateLimitConfig:
        """Return the algorithm's configuration."""


class RateLimiter:
    """High-level rate limiter that wraps an algorithm."""

    def __init__(self, algorithm: RateLimiterAlgorithm):
        self._algorithm = algorithm
        self._on_limited: list = []
        self._on_allowed: list = []

    @property
    def algorithm(self) -> RateLimiterAlgorithm:
        return self._algorithm

    async def acquire(self, key: str, cost: int = 1) -> RateLimitResult:
        """Try to acquire permission for the given key."""
        result = await self._algorithm.acquire(key, cost)
        if result.allowed:
            for cb in self._on_allowed:
                cb(key, result)
        else:
            for cb in self._on_limited:
                cb(key, result)
        return result

    async def peek(self, key: str) -> RateLimitResult:
        """Check current state without consuming tokens."""
        return await self._algorithm.peek(key)

    async def reset(self, key: str) -> None:
        """Reset rate limiter for a key."""
        await self._algorithm.reset(key)

    async def wait_and_acquire(self, key: str, cost: int = 1, timeout: float = 30.0) -> RateLimitResult:
        """Wait until rate limit allows, then acquire. Raises TimeoutError if timeout exceeded."""
        deadline = time.time() + timeout
        while True:
            result = await self._algorithm.acquire(key, cost)
            if result.allowed:
                return result
            remaining = deadline - time.time()
            if remaining <= 0:
                raise TimeoutError(f"Rate limit wait exceeded timeout of {timeout}s")
            wait_time = min(max(result.retry_after, 0.01), remaining)
            await asyncio.sleep(wait_time)

    def on_limited(self, callback):
        """Register a callback for when a request is rate limited."""
        self._on_limited.append(callback)
        return callback

    def on_allowed(self, callback):
        """Register a callback for when a request is allowed."""
        self._on_allowed.append(callback)
        return callback

    def get_config(self) -> RateLimitConfig:
        return self._algorithm.get_config()
