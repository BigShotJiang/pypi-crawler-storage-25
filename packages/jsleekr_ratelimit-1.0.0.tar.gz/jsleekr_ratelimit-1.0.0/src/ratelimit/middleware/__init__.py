"""HTTP middleware for rate limiting."""
