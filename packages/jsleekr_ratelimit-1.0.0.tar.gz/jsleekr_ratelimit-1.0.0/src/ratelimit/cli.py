"""CLI tool for testing rate limits."""

from __future__ import annotations

import argparse
import asyncio
import time
import sys

from ratelimit.factory import create_limiter
from ratelimit.core import Algorithm
from ratelimit.info import list_algorithms


async def benchmark(
    algorithm: str,
    max_requests: int,
    window: float,
    num_requests: int,
    key: str = "benchmark",
) -> dict:
    """Run a rate limit benchmark."""
    limiter = create_limiter(max_requests, window, algorithm=algorithm)

    allowed = 0
    denied = 0
    total_retry = 0.0
    start = time.time()

    for _ in range(num_requests):
        result = await limiter.acquire(key)
        if result.allowed:
            allowed += 1
        else:
            denied += 1
            total_retry += result.retry_after

    elapsed = time.time() - start

    return {
        "algorithm": algorithm,
        "max_requests": max_requests,
        "window_seconds": window,
        "total_requests": num_requests,
        "allowed": allowed,
        "denied": denied,
        "elapsed_seconds": round(elapsed, 4),
        "requests_per_second": round(num_requests / elapsed, 2) if elapsed > 0 else 0,
        "avg_retry_after": round(total_retry / denied, 3) if denied > 0 else 0,
    }


def format_results(results: dict) -> str:
    """Format benchmark results for display."""
    lines = [
        f"Algorithm:         {results['algorithm']}",
        f"Limit:             {results['max_requests']} / {results['window_seconds']}s",
        f"Total requests:    {results['total_requests']}",
        f"Allowed:           {results['allowed']}",
        f"Denied:            {results['denied']}",
        f"Elapsed:           {results['elapsed_seconds']}s",
        f"Throughput:        {results['requests_per_second']} req/s",
    ]
    if results["denied"] > 0:
        lines.append(f"Avg retry after:   {results['avg_retry_after']}s")
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    """CLI entry point."""
    parser = argparse.ArgumentParser(
        description="ratelimit - benchmark and test rate limiting algorithms"
    )
    subparsers = parser.add_subparsers(dest="command")

    # Benchmark command
    bench = subparsers.add_parser("bench", help="Run rate limit benchmark")
    bench.add_argument("-a", "--algorithm", default="token_bucket",
                       help="Algorithm (token_bucket, fixed_window, etc.)")
    bench.add_argument("-r", "--rate", type=int, default=100,
                       help="Max requests per window")
    bench.add_argument("-w", "--window", type=float, default=1.0,
                       help="Window in seconds")
    bench.add_argument("-n", "--num", type=int, default=200,
                       help="Number of test requests")

    # List command
    subparsers.add_parser("list", help="List available algorithms")

    args = parser.parse_args(argv)

    if args.command == "bench":
        results = asyncio.run(benchmark(
            args.algorithm, args.rate, args.window, args.num
        ))
        print(format_results(results))
        return 0
    elif args.command == "list":
        for info in list_algorithms():
            print(f"  {info.algorithm.value:<25} {info.name} - {info.best_for}")
        return 0
    else:
        parser.print_help()
        return 1


if __name__ == "__main__":
    sys.exit(main())
