"""ratelimit - Multi-algorithm rate limiter with pluggable backends."""

from ratelimit.algorithms.token_bucket import TokenBucket
from ratelimit.algorithms.sliding_window import SlidingWindowLog, SlidingWindowCounter
from ratelimit.algorithms.fixed_window import FixedWindow
from ratelimit.algorithms.leaky_bucket import LeakyBucket
from ratelimit.algorithms.concurrency import ConcurrencyLimiter
from ratelimit.algorithms.gcra import GCRA
from ratelimit.backends.memory import MemoryBackend
from ratelimit.core import RateLimiter, RateLimitResult, RateLimitConfig, Algorithm
from ratelimit.decorator import rate_limit, RateLimitExceeded
from ratelimit.groups import RateLimitGroup, RateLimitChain
from ratelimit.stats import StatsCollector
from ratelimit.factory import create_limiter
from ratelimit.context import RateLimitContext, ConcurrencyContext
from ratelimit.circuit import CircuitBreaker
from ratelimit.penalty import PenaltyTracker
from ratelimit.estimator import RateEstimator
from ratelimit.quota import QuotaManager
from ratelimit.presets import get_preset, list_presets

__version__ = "1.0.0"

__all__ = [
    # Algorithms
    "TokenBucket",
    "SlidingWindowLog",
    "SlidingWindowCounter",
    "FixedWindow",
    "LeakyBucket",
    "ConcurrencyLimiter",
    "GCRA",
    # Backends
    "MemoryBackend",
    # Core
    "Algorithm",
    "RateLimiter",
    "RateLimitResult",
    "RateLimitConfig",
    "RateLimitExceeded",
    # Groups
    "RateLimitGroup",
    "RateLimitChain",
    # Context managers
    "RateLimitContext",
    "ConcurrencyContext",
    # Utilities
    "StatsCollector",
    "CircuitBreaker",
    "PenaltyTracker",
    "RateEstimator",
    "QuotaManager",
    # Factory & Presets
    "create_limiter",
    "get_preset",
    "list_presets",
    "rate_limit",
]
