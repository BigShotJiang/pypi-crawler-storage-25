"""Snapshot and serialization support for rate limiter state."""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, asdict
from typing import Any


@dataclass
class Snapshot:
    """A snapshot of rate limiter state."""
    algorithm: str
    key: str
    timestamp: float
    data: dict[str, Any]

    def to_json(self) -> str:
        """Serialize to JSON string."""
        return json.dumps(asdict(self), indent=2)

    @classmethod
    def from_json(cls, json_str: str) -> Snapshot:
        """Deserialize from JSON string."""
        d = json.loads(json_str)
        return cls(**d)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> Snapshot:
        """Create from dictionary."""
        return cls(**d)

    @property
    def age(self) -> float:
        """Seconds since snapshot was taken."""
        return time.time() - self.timestamp

    @property
    def is_stale(self) -> bool:
        """Whether the snapshot is likely stale (older than the data suggests)."""
        window = self.data.get("window_seconds", 60)
        return self.age > window


class SnapshotManager:
    """Manages snapshots of rate limiter state for debugging and monitoring."""

    def __init__(self, max_history: int = 100):
        if max_history <= 0:
            raise ValueError("max_history must be positive")
        self._max_history = max_history
        self._history: list[Snapshot] = []

    def capture(self, algorithm: str, key: str, data: dict[str, Any]) -> Snapshot:
        """Capture a new snapshot."""
        snapshot = Snapshot(
            algorithm=algorithm,
            key=key,
            timestamp=time.time(),
            data=dict(data),  # Copy to prevent mutation
        )
        self._history.append(snapshot)
        if len(self._history) > self._max_history:
            self._history = self._history[-self._max_history:]
        return snapshot

    def get_history(self, key: str | None = None, limit: int = 10) -> list[Snapshot]:
        """Get snapshot history, optionally filtered by key."""
        items = self._history
        if key is not None:
            items = [s for s in items if s.key == key]
        return items[-limit:]

    def get_latest(self, key: str) -> Snapshot | None:
        """Get the most recent snapshot for a key."""
        for s in reversed(self._history):
            if s.key == key:
                return s
        return None

    def clear(self) -> None:
        """Clear all snapshots."""
        self._history.clear()

    @property
    def count(self) -> int:
        return len(self._history)

    def export_all(self) -> str:
        """Export all snapshots as JSON."""
        return json.dumps([s.to_dict() for s in self._history], indent=2)

    def import_all(self, json_str: str) -> int:
        """Import snapshots from JSON. Returns count imported."""
        items = json.loads(json_str)
        count = 0
        for item in items:
            self._history.append(Snapshot.from_dict(item))
            count += 1
        # Trim if needed
        if len(self._history) > self._max_history:
            self._history = self._history[-self._max_history:]
        return count
