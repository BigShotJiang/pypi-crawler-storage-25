"""Rate estimation and forecasting.

Estimates current request rates and predicts when limits will be hit.
"""

from __future__ import annotations

import time
from collections import deque
from dataclasses import dataclass


@dataclass
class RateEstimate:
    """Estimated request rate."""
    requests_per_second: float
    requests_per_minute: float
    window_seconds: float
    sample_count: int

    @property
    def requests_per_hour(self) -> float:
        return self.requests_per_second * 3600


class RateEstimator:
    """Estimates request rate using a sliding time window.

    Maintains a fixed-size buffer of recent request timestamps
    to estimate the current request rate.
    """

    def __init__(self, window_seconds: float = 60.0, max_samples: int = 1000):
        if window_seconds <= 0:
            raise ValueError("window_seconds must be positive")
        if max_samples <= 0:
            raise ValueError("max_samples must be positive")
        self._window = window_seconds
        self._max_samples = max_samples
        self._timestamps: dict[str, deque[float]] = {}

    def record(self, key: str) -> None:
        """Record a request for the given key."""
        now = time.time()
        if key not in self._timestamps:
            self._timestamps[key] = deque(maxlen=self._max_samples)
        self._timestamps[key].append(now)

    def estimate(self, key: str) -> RateEstimate:
        """Estimate current request rate for a key."""
        now = time.time()
        cutoff = now - self._window

        if key not in self._timestamps:
            return RateEstimate(
                requests_per_second=0.0,
                requests_per_minute=0.0,
                window_seconds=self._window,
                sample_count=0,
            )

        timestamps = self._timestamps[key]
        # Count requests within window
        recent = [t for t in timestamps if t >= cutoff]
        count = len(recent)

        if count <= 1:
            rps = count / self._window
        else:
            span = now - min(recent)
            rps = count / span if span > 0 else 0.0

        return RateEstimate(
            requests_per_second=rps,
            requests_per_minute=rps * 60,
            window_seconds=self._window,
            sample_count=count,
        )

    def time_to_limit(self, key: str, max_requests: int, remaining: int) -> float | None:
        """Estimate seconds until the rate limit will be hit.

        Returns None if rate is too low to estimate.
        """
        est = self.estimate(key)
        if est.requests_per_second <= 0:
            return None
        return remaining / est.requests_per_second

    def cleanup(self, key: str | None = None) -> None:
        """Remove old timestamps outside the window."""
        now = time.time()
        cutoff = now - self._window

        if key is not None:
            if key in self._timestamps:
                self._timestamps[key] = deque(
                    (t for t in self._timestamps[key] if t >= cutoff),
                    maxlen=self._max_samples,
                )
        else:
            for k in list(self._timestamps.keys()):
                self._timestamps[k] = deque(
                    (t for t in self._timestamps[k] if t >= cutoff),
                    maxlen=self._max_samples,
                )
                if not self._timestamps[k]:
                    del self._timestamps[k]

    def get_keys(self) -> list[str]:
        """Get all tracked keys."""
        return list(self._timestamps.keys())

    def clear(self) -> None:
        """Clear all data."""
        self._timestamps.clear()
