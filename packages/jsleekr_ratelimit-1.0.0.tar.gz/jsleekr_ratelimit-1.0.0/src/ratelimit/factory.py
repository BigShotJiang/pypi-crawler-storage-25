"""Factory functions for creating rate limiters."""

from __future__ import annotations

from ratelimit.core import (
    Algorithm,
    Backend,
    RateLimitConfig,
    RateLimiter,
    RateLimiterAlgorithm,
)
from ratelimit.algorithms.token_bucket import TokenBucket
from ratelimit.algorithms.fixed_window import FixedWindow
from ratelimit.algorithms.sliding_window import SlidingWindowLog, SlidingWindowCounter
from ratelimit.algorithms.leaky_bucket import LeakyBucket
from ratelimit.algorithms.concurrency import ConcurrencyLimiter
from ratelimit.algorithms.gcra import GCRA
from ratelimit.backends.memory import MemoryBackend


_ALGORITHM_MAP: dict[Algorithm, type[RateLimiterAlgorithm]] = {
    Algorithm.TOKEN_BUCKET: TokenBucket,
    Algorithm.FIXED_WINDOW: FixedWindow,
    Algorithm.SLIDING_WINDOW_LOG: SlidingWindowLog,
    Algorithm.SLIDING_WINDOW_COUNTER: SlidingWindowCounter,
    Algorithm.LEAKY_BUCKET: LeakyBucket,
    Algorithm.CONCURRENCY: ConcurrencyLimiter,
    Algorithm.GCRA: GCRA,
}


def create_limiter(
    max_requests: int,
    window_seconds: float,
    algorithm: Algorithm | str = Algorithm.TOKEN_BUCKET,
    backend: Backend | None = None,
    burst_size: int | None = None,
    key_prefix: str = "",
) -> RateLimiter:
    """Create a RateLimiter with a single call.

    Args:
        max_requests: Maximum requests per window.
        window_seconds: Window duration in seconds.
        algorithm: Algorithm to use (enum or string like "token_bucket").
        backend: Storage backend. Defaults to MemoryBackend.
        burst_size: Optional burst capacity (token bucket, leaky bucket).
        key_prefix: Optional key prefix for namespacing.

    Returns:
        Configured RateLimiter instance.

    Example:
        limiter = create_limiter(100, 60)  # 100 req/min with token bucket
        limiter = create_limiter(10, 1, algorithm="fixed_window")
    """
    if isinstance(algorithm, str):
        algorithm = Algorithm(algorithm)

    if backend is None:
        backend = MemoryBackend()

    config = RateLimitConfig(
        max_requests=max_requests,
        window_seconds=window_seconds,
        algorithm=algorithm,
        burst_size=burst_size,
        key_prefix=key_prefix,
    )

    algo_class = _ALGORITHM_MAP.get(algorithm)
    if algo_class is None:
        raise ValueError(f"Unknown algorithm: {algorithm}")

    algo_instance = algo_class(backend, config)
    return RateLimiter(algo_instance)
