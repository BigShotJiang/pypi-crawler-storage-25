"""In-memory storage backend for rate limiter."""

from __future__ import annotations

import asyncio
import time
from typing import Any

from ratelimit.core import Backend


class _Entry:
    __slots__ = ("value", "expires_at")

    def __init__(self, value: Any, expires_at: float | None = None):
        self.value = value
        self.expires_at = expires_at

    def is_expired(self) -> bool:
        return self.expires_at is not None and time.time() >= self.expires_at


class MemoryBackend(Backend):
    """Thread-safe in-memory backend using asyncio locks."""

    def __init__(self):
        self._data: dict[str, _Entry] = {}
        self._lock = asyncio.Lock()

    def _cleanup_expired(self):
        """Remove expired entries."""
        now = time.time()
        expired = [k for k, v in self._data.items() if v.expires_at and now >= v.expires_at]
        for k in expired:
            del self._data[k]

    def _get_valid(self, key: str) -> _Entry | None:
        entry = self._data.get(key)
        if entry is None:
            return None
        if entry.is_expired():
            del self._data[key]
            return None
        return entry

    async def get(self, key: str) -> Any | None:
        async with self._lock:
            entry = self._get_valid(key)
            return entry.value if entry else None

    async def set(self, key: str, value: Any, ttl: float | None = None) -> None:
        async with self._lock:
            expires_at = (time.time() + ttl) if ttl else None
            self._data[key] = _Entry(value, expires_at)

    async def delete(self, key: str) -> None:
        async with self._lock:
            self._data.pop(key, None)

    async def increment(self, key: str, amount: int = 1, ttl: float | None = None) -> int:
        async with self._lock:
            entry = self._get_valid(key)
            if entry is None:
                expires_at = (time.time() + ttl) if ttl else None
                self._data[key] = _Entry(amount, expires_at)
                return amount
            entry.value += amount
            return entry.value

    async def get_list(self, key: str) -> list[Any]:
        async with self._lock:
            entry = self._get_valid(key)
            if entry is None:
                return []
            return list(entry.value)

    async def append_list(self, key: str, value: Any, ttl: float | None = None) -> None:
        async with self._lock:
            entry = self._get_valid(key)
            if entry is None:
                expires_at = (time.time() + ttl) if ttl else None
                self._data[key] = _Entry([value], expires_at)
            else:
                entry.value.append(value)

    async def trim_list(self, key: str, min_value: Any) -> int:
        async with self._lock:
            entry = self._get_valid(key)
            if entry is None:
                return 0
            entry.value = [v for v in entry.value if v >= min_value]
            return len(entry.value)

    async def clear(self) -> None:
        async with self._lock:
            self._data.clear()

    async def size(self) -> int:
        """Return number of non-expired entries."""
        async with self._lock:
            self._cleanup_expired()
            return len(self._data)
