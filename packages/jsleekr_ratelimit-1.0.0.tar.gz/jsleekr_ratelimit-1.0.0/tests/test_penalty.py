"""Tests for penalty tracker."""

import time
import pytest
from ratelimit.penalty import PenaltyTracker, PenaltyState


class TestPenaltyState:
    def test_not_penalized_by_default(self):
        ps = PenaltyState()
        assert not ps.is_penalized
        assert ps.penalty_remaining == 0.0

    def test_penalized_when_future(self):
        ps = PenaltyState(penalty_until=time.time() + 100)
        assert ps.is_penalized
        assert ps.penalty_remaining > 0

    def test_not_penalized_when_past(self):
        ps = PenaltyState(penalty_until=time.time() - 10)
        assert not ps.is_penalized


class TestPenaltyTracker:
    def test_no_penalty_below_threshold(self):
        pt = PenaltyTracker(threshold=5)
        for _ in range(4):
            state = pt.record_violation("user1")
        assert not state.is_penalized

    def test_penalty_at_threshold(self):
        pt = PenaltyTracker(threshold=5, base_penalty=10.0)
        for _ in range(5):
            state = pt.record_violation("user1")
        assert state.is_penalized

    def test_penalty_increases(self):
        pt = PenaltyTracker(threshold=2, base_penalty=10.0, multiplier=2.0)
        # First threshold: 10s
        for _ in range(2):
            pt.record_violation("user1")
        state1 = pt.check("user1")
        p1 = state1.penalty_remaining

        # Second threshold: 20s
        for _ in range(2):
            pt.record_violation("user1")
        state2 = pt.check("user1")
        p2 = state2.penalty_remaining

        assert p2 > p1

    def test_max_penalty_cap(self):
        pt = PenaltyTracker(threshold=1, base_penalty=100.0, max_penalty=200.0, multiplier=10.0)
        for _ in range(100):
            pt.record_violation("user1")
        state = pt.check("user1")
        assert state.penalty_remaining <= 200.0

    def test_check_nonexistent(self):
        pt = PenaltyTracker()
        state = pt.check("nonexistent")
        assert not state.is_penalized
        assert state.violations == 0

    def test_different_keys_independent(self):
        pt = PenaltyTracker(threshold=2)
        pt.record_violation("a")
        pt.record_violation("a")
        assert pt.check("a").is_penalized
        assert not pt.check("b").is_penalized

    def test_clear_key(self):
        pt = PenaltyTracker(threshold=2)
        pt.record_violation("user1")
        pt.record_violation("user1")
        pt.clear("user1")
        state = pt.check("user1")
        assert state.violations == 0

    def test_clear_all(self):
        pt = PenaltyTracker(threshold=1)
        pt.record_violation("a")
        pt.record_violation("b")
        pt.clear_all()
        assert pt.check("a").violations == 0
        assert pt.check("b").violations == 0

    def test_get_penalized_keys(self):
        pt = PenaltyTracker(threshold=1, base_penalty=60.0)
        pt.record_violation("bad1")
        pt.record_violation("bad2")
        penalized = pt.get_penalized_keys()
        assert "bad1" in penalized
        assert "bad2" in penalized

    def test_decay_resets_violations(self):
        pt = PenaltyTracker(threshold=5, decay_seconds=0.01)
        for _ in range(4):
            pt.record_violation("user1")
        import time as t
        t.sleep(0.02)
        # After decay, violations reset; this is violation #1 again
        state = pt.record_violation("user1")
        assert state.violations == 1
        assert not state.is_penalized

    def test_returns_copy(self):
        pt = PenaltyTracker(threshold=1)
        state = pt.record_violation("user1")
        state.violations = 999
        assert pt.check("user1").violations == 1


class TestPenaltyTrackerValidation:
    def test_invalid_threshold(self):
        with pytest.raises(ValueError, match="threshold must be positive"):
            PenaltyTracker(threshold=0)

    def test_invalid_base_penalty(self):
        with pytest.raises(ValueError, match="base_penalty must be positive"):
            PenaltyTracker(base_penalty=0)

    def test_invalid_max_penalty(self):
        with pytest.raises(ValueError, match="max_penalty must be >= base_penalty"):
            PenaltyTracker(base_penalty=100, max_penalty=10)

    def test_invalid_multiplier(self):
        with pytest.raises(ValueError, match="multiplier must be >= 1.0"):
            PenaltyTracker(multiplier=0.5)
