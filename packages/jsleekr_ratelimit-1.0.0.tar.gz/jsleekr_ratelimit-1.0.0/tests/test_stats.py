"""Tests for statistics collector."""

import pytest
from ratelimit.stats import StatsCollector, KeyStats
from ratelimit.core import RateLimiter, RateLimitConfig
from ratelimit.algorithms.token_bucket import TokenBucket
from ratelimit.backends.memory import MemoryBackend


class TestKeyStats:
    def test_denial_rate_zero(self):
        ks = KeyStats()
        assert ks.denial_rate == 0.0

    def test_denial_rate(self):
        ks = KeyStats(total_requests=10, allowed_requests=7, denied_requests=3)
        assert ks.denial_rate == pytest.approx(0.3)

    def test_avg_retry_after_zero(self):
        ks = KeyStats()
        assert ks.avg_retry_after == 0.0

    def test_avg_retry_after(self):
        ks = KeyStats(denied_requests=4, total_retry_after=8.0)
        assert ks.avg_retry_after == pytest.approx(2.0)


class TestStatsCollector:
    def test_record_allowed(self):
        stats = StatsCollector()
        stats.record_allowed("user1")
        ks = stats.get_key_stats("user1")
        assert ks is not None
        assert ks.total_requests == 1
        assert ks.allowed_requests == 1
        assert ks.denied_requests == 0

    def test_record_denied(self):
        stats = StatsCollector()
        stats.record_denied("user1", retry_after=5.0)
        ks = stats.get_key_stats("user1")
        assert ks is not None
        assert ks.denied_requests == 1
        assert ks.total_retry_after == 5.0

    def test_multiple_records(self):
        stats = StatsCollector()
        stats.record_allowed("user1")
        stats.record_allowed("user1")
        stats.record_denied("user1", 2.0)
        ks = stats.get_key_stats("user1")
        assert ks.total_requests == 3
        assert ks.allowed_requests == 2
        assert ks.denied_requests == 1

    def test_get_nonexistent_key(self):
        stats = StatsCollector()
        assert stats.get_key_stats("nope") is None

    def test_get_all_keys(self):
        stats = StatsCollector()
        stats.record_allowed("a")
        stats.record_allowed("b")
        stats.record_allowed("c")
        keys = stats.get_all_keys()
        assert set(keys) == {"a", "b", "c"}

    def test_total_allowed(self):
        stats = StatsCollector()
        stats.record_allowed("a")
        stats.record_allowed("b")
        assert stats.total_allowed == 2

    def test_total_denied(self):
        stats = StatsCollector()
        stats.record_denied("a")
        stats.record_denied("b")
        assert stats.total_denied == 2

    def test_total_requests(self):
        stats = StatsCollector()
        stats.record_allowed("a")
        stats.record_denied("b")
        assert stats.total_requests == 2

    def test_global_denial_rate_zero(self):
        stats = StatsCollector()
        assert stats.global_denial_rate == 0.0

    def test_global_denial_rate(self):
        stats = StatsCollector()
        for _ in range(7):
            stats.record_allowed("a")
        for _ in range(3):
            stats.record_denied("a")
        assert stats.global_denial_rate == pytest.approx(0.3)

    def test_top_denied_keys(self):
        stats = StatsCollector()
        for _ in range(5):
            stats.record_denied("heavy")
        for _ in range(2):
            stats.record_denied("light")
        top = stats.top_denied_keys(1)
        assert len(top) == 1
        assert top[0][0] == "heavy"
        assert top[0][1].denied_requests == 5

    def test_reset(self):
        stats = StatsCollector()
        stats.record_allowed("a")
        stats.record_denied("b")
        stats.reset()
        assert stats.total_requests == 0
        assert stats.get_key_stats("a") is None

    def test_first_last_seen(self):
        stats = StatsCollector()
        stats.record_allowed("user1")
        ks = stats.get_key_stats("user1")
        assert ks.first_seen > 0
        assert ks.last_seen >= ks.first_seen

    def test_returns_copy(self):
        stats = StatsCollector()
        stats.record_allowed("user1")
        ks1 = stats.get_key_stats("user1")
        ks1.total_requests = 999
        ks2 = stats.get_key_stats("user1")
        assert ks2.total_requests == 1


class TestStatsAttach:
    async def test_attach_to_limiter(self):
        backend = MemoryBackend()
        config = RateLimitConfig(max_requests=2, window_seconds=1.0)
        limiter = RateLimiter(TokenBucket(backend, config))
        stats = StatsCollector()
        stats.attach(limiter)

        await limiter.acquire("user1")
        await limiter.acquire("user1")
        await limiter.acquire("user1")  # denied

        assert stats.total_allowed == 2
        assert stats.total_denied == 1
        ks = stats.get_key_stats("user1")
        assert ks.total_requests == 3
