"""Tests for retry strategies."""

import pytest
import time
from ratelimit.retry import (
    FixedRetry,
    ExponentialBackoff,
    RetryAfterStrategy,
    RetryResult,
    retry_acquire,
)
from ratelimit.core import RateLimiter, RateLimitConfig, RateLimitResult
from ratelimit.algorithms.token_bucket import TokenBucket
from ratelimit.backends.memory import MemoryBackend


class TestFixedRetry:
    def test_constant_delay(self):
        strategy = FixedRetry(delay=2.0)
        result = RateLimitResult(allowed=False, remaining=0, limit=10, reset_at=0)
        assert strategy.get_delay(0, result) == 2.0
        assert strategy.get_delay(5, result) == 2.0

    def test_max_retries(self):
        strategy = FixedRetry(max_retries=3)
        result = RateLimitResult(allowed=False, remaining=0, limit=10, reset_at=0)
        assert strategy.should_retry(0, result) is True
        assert strategy.should_retry(2, result) is True
        assert strategy.should_retry(3, result) is False

    def test_invalid_delay(self):
        with pytest.raises(ValueError, match="delay must be positive"):
            FixedRetry(delay=0)

    def test_invalid_max_retries(self):
        with pytest.raises(ValueError, match="max_retries must be non-negative"):
            FixedRetry(max_retries=-1)


class TestExponentialBackoff:
    def test_increases(self):
        strategy = ExponentialBackoff(base_delay=1.0, jitter=False)
        result = RateLimitResult(allowed=False, remaining=0, limit=10, reset_at=0)
        d0 = strategy.get_delay(0, result)
        d1 = strategy.get_delay(1, result)
        d2 = strategy.get_delay(2, result)
        assert d0 == 1.0
        assert d1 == 2.0
        assert d2 == 4.0

    def test_max_delay(self):
        strategy = ExponentialBackoff(base_delay=1.0, max_delay=5.0, jitter=False)
        result = RateLimitResult(allowed=False, remaining=0, limit=10, reset_at=0)
        d10 = strategy.get_delay(10, result)
        assert d10 == 5.0

    def test_jitter_in_range(self):
        strategy = ExponentialBackoff(base_delay=1.0, jitter=True)
        result = RateLimitResult(allowed=False, remaining=0, limit=10, reset_at=0)
        for _ in range(20):
            d = strategy.get_delay(0, result)
            assert 0 <= d <= 1.0

    def test_max_retries(self):
        strategy = ExponentialBackoff(max_retries=5)
        result = RateLimitResult(allowed=False, remaining=0, limit=10, reset_at=0)
        assert strategy.should_retry(4, result) is True
        assert strategy.should_retry(5, result) is False

    def test_invalid_base_delay(self):
        with pytest.raises(ValueError):
            ExponentialBackoff(base_delay=0)

    def test_invalid_max_delay(self):
        with pytest.raises(ValueError):
            ExponentialBackoff(base_delay=10, max_delay=5)

    def test_invalid_max_retries(self):
        with pytest.raises(ValueError):
            ExponentialBackoff(max_retries=-1)


class TestRetryAfterStrategy:
    def test_uses_retry_after(self):
        strategy = RetryAfterStrategy()
        result = RateLimitResult(
            allowed=False, remaining=0, limit=10, reset_at=0, retry_after=5.0
        )
        assert strategy.get_delay(0, result) == 5.0

    def test_multiplier(self):
        strategy = RetryAfterStrategy(multiplier=1.5)
        result = RateLimitResult(
            allowed=False, remaining=0, limit=10, reset_at=0, retry_after=4.0
        )
        assert strategy.get_delay(0, result) == 6.0

    def test_minimum_delay(self):
        strategy = RetryAfterStrategy()
        result = RateLimitResult(
            allowed=False, remaining=0, limit=10, reset_at=0, retry_after=0.0
        )
        assert strategy.get_delay(0, result) >= 0.1

    def test_invalid_max_retries(self):
        with pytest.raises(ValueError):
            RetryAfterStrategy(max_retries=-1)

    def test_invalid_multiplier(self):
        with pytest.raises(ValueError):
            RetryAfterStrategy(multiplier=0)


class TestRetryAcquire:
    async def test_success_first_try(self):
        backend = MemoryBackend()
        config = RateLimitConfig(max_requests=10, window_seconds=1.0)
        limiter = RateLimiter(TokenBucket(backend, config))
        strategy = FixedRetry(delay=0.01, max_retries=3)

        result = await retry_acquire(limiter, "user1", strategy)
        assert result.success is True
        assert result.attempts == 1
        assert result.total_wait == 0.0

    async def test_success_after_retry(self):
        backend = MemoryBackend()
        config = RateLimitConfig(max_requests=1, window_seconds=0.05)
        limiter = RateLimiter(TokenBucket(backend, config))
        strategy = FixedRetry(delay=0.06, max_retries=3)

        # Exhaust the limit
        await limiter.acquire("user1")

        # Should retry and succeed after refill
        result = await retry_acquire(limiter, "user1", strategy)
        assert result.success is True
        assert result.attempts >= 2

    async def test_failure_exhausted_retries(self):
        backend = MemoryBackend()
        config = RateLimitConfig(max_requests=1, window_seconds=10.0)
        limiter = RateLimiter(TokenBucket(backend, config))
        strategy = FixedRetry(delay=0.01, max_retries=2)

        await limiter.acquire("user1")

        result = await retry_acquire(limiter, "user1", strategy)
        assert result.success is False
        assert result.attempts == 3  # 1 initial + 2 retries

    async def test_tracks_total_wait(self):
        backend = MemoryBackend()
        config = RateLimitConfig(max_requests=1, window_seconds=10.0)
        limiter = RateLimiter(TokenBucket(backend, config))
        strategy = FixedRetry(delay=0.01, max_retries=2)

        await limiter.acquire("user1")

        result = await retry_acquire(limiter, "user1", strategy)
        assert result.total_wait > 0
