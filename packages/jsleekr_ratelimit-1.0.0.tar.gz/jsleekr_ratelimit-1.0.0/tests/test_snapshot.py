"""Tests for snapshot and serialization."""

import json
import time
import pytest
from ratelimit.snapshot import Snapshot, SnapshotManager


class TestSnapshot:
    def test_create(self):
        snap = Snapshot(
            algorithm="token_bucket",
            key="user1",
            timestamp=time.time(),
            data={"tokens": 5, "capacity": 10},
        )
        assert snap.algorithm == "token_bucket"
        assert snap.key == "user1"

    def test_to_json(self):
        snap = Snapshot(
            algorithm="token_bucket",
            key="user1",
            timestamp=1000.0,
            data={"tokens": 5},
        )
        j = snap.to_json()
        parsed = json.loads(j)
        assert parsed["algorithm"] == "token_bucket"
        assert parsed["data"]["tokens"] == 5

    def test_from_json(self):
        original = Snapshot(
            algorithm="fixed_window",
            key="user2",
            timestamp=2000.0,
            data={"count": 3},
        )
        j = original.to_json()
        restored = Snapshot.from_json(j)
        assert restored.algorithm == original.algorithm
        assert restored.key == original.key
        assert restored.data == original.data

    def test_to_dict(self):
        snap = Snapshot("tb", "k", 1000.0, {"x": 1})
        d = snap.to_dict()
        assert d["algorithm"] == "tb"
        assert d["data"] == {"x": 1}

    def test_from_dict(self):
        d = {"algorithm": "tb", "key": "k", "timestamp": 1000.0, "data": {"x": 1}}
        snap = Snapshot.from_dict(d)
        assert snap.algorithm == "tb"

    def test_age(self):
        snap = Snapshot("tb", "k", time.time() - 10, {})
        assert snap.age >= 10

    def test_is_stale(self):
        snap = Snapshot("tb", "k", time.time() - 100, {"window_seconds": 60})
        assert snap.is_stale is True

    def test_not_stale(self):
        snap = Snapshot("tb", "k", time.time(), {"window_seconds": 60})
        assert snap.is_stale is False


class TestSnapshotManager:
    def test_capture(self):
        mgr = SnapshotManager()
        snap = mgr.capture("tb", "user1", {"tokens": 5})
        assert snap.algorithm == "tb"
        assert snap.key == "user1"
        assert mgr.count == 1

    def test_get_history(self):
        mgr = SnapshotManager()
        mgr.capture("tb", "user1", {"t": 1})
        mgr.capture("tb", "user1", {"t": 2})
        mgr.capture("tb", "user2", {"t": 3})
        history = mgr.get_history()
        assert len(history) == 3

    def test_get_history_filtered(self):
        mgr = SnapshotManager()
        mgr.capture("tb", "user1", {"t": 1})
        mgr.capture("tb", "user2", {"t": 2})
        mgr.capture("tb", "user1", {"t": 3})
        history = mgr.get_history(key="user1")
        assert len(history) == 2

    def test_get_history_limit(self):
        mgr = SnapshotManager()
        for i in range(10):
            mgr.capture("tb", "user1", {"t": i})
        history = mgr.get_history(limit=3)
        assert len(history) == 3

    def test_get_latest(self):
        mgr = SnapshotManager()
        mgr.capture("tb", "user1", {"t": 1})
        mgr.capture("tb", "user1", {"t": 2})
        latest = mgr.get_latest("user1")
        assert latest.data["t"] == 2

    def test_get_latest_none(self):
        mgr = SnapshotManager()
        assert mgr.get_latest("nonexistent") is None

    def test_max_history(self):
        mgr = SnapshotManager(max_history=5)
        for i in range(10):
            mgr.capture("tb", "user1", {"t": i})
        assert mgr.count == 5

    def test_clear(self):
        mgr = SnapshotManager()
        mgr.capture("tb", "user1", {"t": 1})
        mgr.clear()
        assert mgr.count == 0

    def test_export_import(self):
        mgr1 = SnapshotManager()
        mgr1.capture("tb", "user1", {"t": 1})
        mgr1.capture("fw", "user2", {"t": 2})
        exported = mgr1.export_all()

        mgr2 = SnapshotManager()
        imported = mgr2.import_all(exported)
        assert imported == 2
        assert mgr2.count == 2

    def test_invalid_max_history(self):
        with pytest.raises(ValueError, match="max_history must be positive"):
            SnapshotManager(max_history=0)

    def test_capture_copies_data(self):
        mgr = SnapshotManager()
        data = {"tokens": 5}
        snap = mgr.capture("tb", "user1", data)
        data["tokens"] = 999
        assert snap.data["tokens"] == 5
