"""Tests for RateLimitGroup and RateLimitChain."""

import pytest
from ratelimit.core import RateLimiter, RateLimitConfig
from ratelimit.algorithms.token_bucket import TokenBucket
from ratelimit.algorithms.fixed_window import FixedWindow
from ratelimit.backends.memory import MemoryBackend
from ratelimit.groups import RateLimitGroup, RateLimitChain


class TestRateLimitGroup:
    async def test_all_allow(self):
        backend = MemoryBackend()
        l1 = RateLimiter(TokenBucket(backend, RateLimitConfig(max_requests=10, window_seconds=1.0, key_prefix="g1")))
        l2 = RateLimiter(TokenBucket(backend, RateLimitConfig(max_requests=100, window_seconds=60.0, key_prefix="g2")))
        group = RateLimitGroup(l1, l2)
        result = await group.acquire("user1")
        assert result.allowed is True

    async def test_one_denies(self):
        backend = MemoryBackend()
        l1 = RateLimiter(TokenBucket(backend, RateLimitConfig(max_requests=1, window_seconds=1.0, key_prefix="g1")))
        l2 = RateLimiter(TokenBucket(backend, RateLimitConfig(max_requests=100, window_seconds=60.0, key_prefix="g2")))
        group = RateLimitGroup(l1, l2)
        await group.acquire("user1")  # Exhausts l1
        result = await group.acquire("user1")
        assert result.allowed is False

    async def test_peek(self):
        backend = MemoryBackend()
        l1 = RateLimiter(TokenBucket(backend, RateLimitConfig(max_requests=5, window_seconds=1.0, key_prefix="g1")))
        l2 = RateLimiter(TokenBucket(backend, RateLimitConfig(max_requests=3, window_seconds=1.0, key_prefix="g2")))
        group = RateLimitGroup(l1, l2)
        result = await group.peek("user1")
        assert result.remaining == 3  # Most restrictive

    async def test_reset(self):
        backend = MemoryBackend()
        l1 = RateLimiter(TokenBucket(backend, RateLimitConfig(max_requests=1, window_seconds=1.0, key_prefix="g1")))
        l2 = RateLimiter(TokenBucket(backend, RateLimitConfig(max_requests=1, window_seconds=1.0, key_prefix="g2")))
        group = RateLimitGroup(l1, l2)
        await group.acquire("user1")
        await group.reset("user1")
        result = await group.acquire("user1")
        assert result.allowed is True

    async def test_empty_group_raises(self):
        with pytest.raises(ValueError, match="At least one limiter"):
            RateLimitGroup()


class TestRateLimitChain:
    async def test_all_pass(self):
        backend = MemoryBackend()
        l1 = RateLimiter(TokenBucket(backend, RateLimitConfig(max_requests=10, window_seconds=1.0, key_prefix="c1")))
        l2 = RateLimiter(TokenBucket(backend, RateLimitConfig(max_requests=100, window_seconds=60.0, key_prefix="c2")))
        chain = RateLimitChain(l1, l2)
        result = await chain.acquire("user1")
        assert result.allowed is True

    async def test_first_denies(self):
        backend = MemoryBackend()
        l1 = RateLimiter(TokenBucket(backend, RateLimitConfig(max_requests=1, window_seconds=1.0, key_prefix="c1")))
        l2 = RateLimiter(TokenBucket(backend, RateLimitConfig(max_requests=100, window_seconds=60.0, key_prefix="c2")))
        chain = RateLimitChain(l1, l2)
        await chain.acquire("user1")
        result = await chain.acquire("user1")
        assert result.allowed is False

    async def test_reset(self):
        backend = MemoryBackend()
        l1 = RateLimiter(TokenBucket(backend, RateLimitConfig(max_requests=1, window_seconds=1.0, key_prefix="c1")))
        chain = RateLimitChain(l1)
        await chain.acquire("user1")
        await chain.reset("user1")
        result = await chain.acquire("user1")
        assert result.allowed is True

    async def test_empty_chain_raises(self):
        with pytest.raises(ValueError, match="At least one limiter"):
            RateLimitChain()
