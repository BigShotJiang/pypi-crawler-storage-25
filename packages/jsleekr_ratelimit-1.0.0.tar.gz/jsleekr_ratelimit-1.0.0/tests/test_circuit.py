"""Tests for circuit breaker."""

import time
import pytest
from ratelimit.circuit import CircuitBreaker, CircuitState, CircuitStatus


class TestCircuitBreaker:
    def test_initially_closed(self):
        cb = CircuitBreaker()
        assert cb.should_allow("key1") is True
        status = cb.get_status("key1")
        assert status.state == CircuitState.CLOSED

    def test_opens_after_failures(self):
        cb = CircuitBreaker(failure_threshold=3)
        for _ in range(3):
            cb.record_failure("key1")
        assert cb.should_allow("key1") is False
        assert cb.get_status("key1").state == CircuitState.OPEN

    def test_stays_closed_below_threshold(self):
        cb = CircuitBreaker(failure_threshold=5)
        for _ in range(4):
            cb.record_failure("key1")
        assert cb.should_allow("key1") is True

    def test_success_resets_failures(self):
        cb = CircuitBreaker(failure_threshold=3)
        cb.record_failure("key1")
        cb.record_failure("key1")
        cb.record_success("key1")
        cb.record_failure("key1")  # Only 1 consecutive now
        assert cb.should_allow("key1") is True

    def test_half_open_after_timeout(self):
        cb = CircuitBreaker(failure_threshold=2, timeout=0.01)
        cb.record_failure("key1")
        cb.record_failure("key1")
        assert cb.should_allow("key1") is False
        time.sleep(0.02)
        assert cb.should_allow("key1") is True
        assert cb.get_status("key1").state == CircuitState.HALF_OPEN

    def test_half_open_to_closed(self):
        cb = CircuitBreaker(failure_threshold=2, success_threshold=2, timeout=0.01)
        cb.record_failure("key1")
        cb.record_failure("key1")
        time.sleep(0.02)
        cb.should_allow("key1")  # Transitions to half-open
        cb.record_success("key1")
        cb.record_success("key1")
        assert cb.get_status("key1").state == CircuitState.CLOSED

    def test_half_open_failure_reopens(self):
        cb = CircuitBreaker(failure_threshold=2, timeout=0.01)
        cb.record_failure("key1")
        cb.record_failure("key1")
        time.sleep(0.02)
        cb.should_allow("key1")  # half-open
        cb.record_failure("key1")
        assert cb.get_status("key1").state == CircuitState.OPEN

    def test_different_keys_independent(self):
        cb = CircuitBreaker(failure_threshold=2)
        cb.record_failure("key1")
        cb.record_failure("key1")
        assert cb.should_allow("key1") is False
        assert cb.should_allow("key2") is True

    def test_reset(self):
        cb = CircuitBreaker(failure_threshold=2)
        cb.record_failure("key1")
        cb.record_failure("key1")
        cb.reset("key1")
        assert cb.should_allow("key1") is True

    def test_reset_all(self):
        cb = CircuitBreaker(failure_threshold=1)
        cb.record_failure("a")
        cb.record_failure("b")
        cb.reset_all()
        assert cb.should_allow("a") is True
        assert cb.should_allow("b") is True


class TestCircuitStatus:
    def test_time_in_state(self):
        cb = CircuitBreaker()
        cb.should_allow("key1")
        status = cb.get_status("key1")
        assert status.time_in_state >= 0

    def test_failure_count(self):
        cb = CircuitBreaker()
        cb.record_failure("key1")
        cb.record_failure("key1")
        status = cb.get_status("key1")
        assert status.failure_count == 2


class TestCircuitBreakerValidation:
    def test_invalid_failure_threshold(self):
        with pytest.raises(ValueError, match="failure_threshold must be positive"):
            CircuitBreaker(failure_threshold=0)

    def test_invalid_success_threshold(self):
        with pytest.raises(ValueError, match="success_threshold must be positive"):
            CircuitBreaker(success_threshold=0)

    def test_invalid_timeout(self):
        with pytest.raises(ValueError, match="timeout must be positive"):
            CircuitBreaker(timeout=0)
