"""Tests for weighted rate limiter and cost calculator."""

import pytest
from ratelimit.weighted import WeightedRateLimiter, CostCalculator, Priority, WeightedRoute
from ratelimit.core import RateLimiter, RateLimitConfig
from ratelimit.algorithms.token_bucket import TokenBucket
from ratelimit.backends.memory import MemoryBackend


class TestPriority:
    def test_ordering(self):
        assert Priority.LOW < Priority.NORMAL < Priority.HIGH < Priority.CRITICAL

    def test_values(self):
        assert Priority.LOW == 0
        assert Priority.CRITICAL == 3


class TestWeightedRoute:
    def test_valid(self):
        route = WeightedRoute(pattern="/api/*", cost=5)
        assert route.cost == 5

    def test_invalid_cost(self):
        with pytest.raises(ValueError, match="cost must be positive"):
            WeightedRoute(pattern="/api/*", cost=0)


class TestWeightedRateLimiter:
    async def test_basic_acquire(self):
        backend = MemoryBackend()
        config = RateLimitConfig(max_requests=10, window_seconds=1.0)
        limiter = RateLimiter(TokenBucket(backend, config))
        weighted = WeightedRateLimiter(limiter)
        result = await weighted.acquire("user1")
        assert result.allowed

    async def test_weighted_cost(self):
        backend = MemoryBackend()
        config = RateLimitConfig(max_requests=10, window_seconds=1.0)
        limiter = RateLimiter(TokenBucket(backend, config))
        weighted = WeightedRateLimiter(limiter)
        result = await weighted.acquire("user1", cost=5)
        assert result.allowed
        assert result.remaining == 5

    async def test_priority_reserve(self):
        backend = MemoryBackend()
        config = RateLimitConfig(max_requests=10, window_seconds=1.0)
        limiter = RateLimiter(TokenBucket(backend, config))
        weighted = WeightedRateLimiter(
            limiter,
            priority_reserves={Priority.CRITICAL: 0.3},
        )
        # Use up 7 tokens (leaving 3, which is 30% reserved)
        for _ in range(7):
            await weighted.acquire("user1", priority=Priority.CRITICAL)

        # Normal priority should be blocked (3 remaining = 30% reserved)
        result = await weighted.acquire("user1", priority=Priority.NORMAL)
        assert not result.allowed
        assert result.metadata.get("reason") == "capacity_reserved"

    async def test_critical_bypasses_reserve(self):
        backend = MemoryBackend()
        config = RateLimitConfig(max_requests=10, window_seconds=1.0)
        limiter = RateLimiter(TokenBucket(backend, config))
        weighted = WeightedRateLimiter(
            limiter,
            priority_reserves={Priority.CRITICAL: 0.3},
        )
        for _ in range(7):
            await weighted.acquire("user1", priority=Priority.CRITICAL)
        # Critical should still be allowed
        result = await weighted.acquire("user1", priority=Priority.CRITICAL)
        assert result.allowed

    async def test_peek(self):
        backend = MemoryBackend()
        config = RateLimitConfig(max_requests=10, window_seconds=1.0)
        limiter = RateLimiter(TokenBucket(backend, config))
        weighted = WeightedRateLimiter(limiter)
        result = await weighted.peek("user1")
        assert result.remaining == 10

    async def test_reset(self):
        backend = MemoryBackend()
        config = RateLimitConfig(max_requests=3, window_seconds=1.0)
        limiter = RateLimiter(TokenBucket(backend, config))
        weighted = WeightedRateLimiter(limiter)
        for _ in range(3):
            await weighted.acquire("user1")
        await weighted.reset("user1")
        result = await weighted.acquire("user1")
        assert result.allowed

    def test_reserves_exceed_100_pct(self):
        backend = MemoryBackend()
        config = RateLimitConfig(max_requests=10, window_seconds=1.0)
        limiter = RateLimiter(TokenBucket(backend, config))
        with pytest.raises(ValueError, match="Total priority reserves cannot exceed"):
            WeightedRateLimiter(limiter, {Priority.HIGH: 0.6, Priority.CRITICAL: 0.5})


class TestCostCalculator:
    def test_exact_match(self):
        calc = CostCalculator()
        calc.add_route("/api/upload", 5)
        assert calc.get_cost("/api/upload") == 5

    def test_prefix_match(self):
        calc = CostCalculator()
        calc.add_route("/api/*", 2)
        assert calc.get_cost("/api/users") == 2
        assert calc.get_cost("/api/data/export") == 2

    def test_suffix_match(self):
        calc = CostCalculator()
        calc.add_route("*.csv", 10)
        assert calc.get_cost("/export/data.csv") == 10

    def test_no_match_returns_default(self):
        calc = CostCalculator()
        calc.add_route("/api/*", 2)
        assert calc.get_cost("/other") == 1

    def test_custom_default(self):
        calc = CostCalculator()
        calc.set_default_cost(3)
        assert calc.get_cost("/anything") == 3

    def test_invalid_default_cost(self):
        calc = CostCalculator()
        with pytest.raises(ValueError, match="cost must be positive"):
            calc.set_default_cost(0)

    def test_first_match_wins(self):
        calc = CostCalculator()
        calc.add_route("/api/*", 2)
        calc.add_route("/api/upload", 5)
        assert calc.get_cost("/api/upload") == 2  # First match
