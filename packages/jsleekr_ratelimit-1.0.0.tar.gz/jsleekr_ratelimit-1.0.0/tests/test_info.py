"""Tests for algorithm information and recommendation."""

import pytest
from ratelimit.info import (
    get_algorithm_info,
    list_algorithms,
    recommend_algorithm,
    AlgorithmInfo,
)
from ratelimit.core import Algorithm


class TestGetAlgorithmInfo:
    def test_token_bucket(self):
        info = get_algorithm_info(Algorithm.TOKEN_BUCKET)
        assert info.name == "Token Bucket"
        assert info.supports_burst is True
        assert info.memory_complexity == "O(1)"

    def test_by_string(self):
        info = get_algorithm_info("fixed_window")
        assert info.name == "Fixed Window"
        assert info.boundary_issue is True

    def test_gcra(self):
        info = get_algorithm_info(Algorithm.GCRA)
        assert "GCRA" in info.name

    def test_all_algorithms_have_info(self):
        for algo in Algorithm:
            info = get_algorithm_info(algo)
            assert info is not None
            assert info.name
            assert info.description

    def test_unknown(self):
        with pytest.raises(ValueError):
            get_algorithm_info("nonexistent")


class TestListAlgorithms:
    def test_returns_all(self):
        algos = list_algorithms()
        assert len(algos) == len(Algorithm)

    def test_all_are_info_objects(self):
        for info in list_algorithms():
            assert isinstance(info, AlgorithmInfo)


class TestRecommendAlgorithm:
    def test_burst(self):
        info = recommend_algorithm(needs_burst=True)
        assert info.supports_burst is True

    def test_exactness(self):
        info = recommend_algorithm(needs_exactness=True)
        assert info.algorithm == Algorithm.SLIDING_WINDOW_LOG

    def test_smoothing(self):
        info = recommend_algorithm(needs_smoothing=True)
        assert info.algorithm == Algorithm.LEAKY_BUCKET

    def test_concurrency(self):
        info = recommend_algorithm(is_concurrency=True)
        assert info.algorithm == Algorithm.CONCURRENCY

    def test_memory_constrained_with_burst(self):
        info = recommend_algorithm(needs_burst=True, memory_constrained=True)
        assert info.algorithm == Algorithm.GCRA

    def test_memory_constrained(self):
        info = recommend_algorithm(memory_constrained=True)
        assert info.memory_complexity == "O(1)"

    def test_default(self):
        info = recommend_algorithm()
        assert info.algorithm == Algorithm.GCRA
