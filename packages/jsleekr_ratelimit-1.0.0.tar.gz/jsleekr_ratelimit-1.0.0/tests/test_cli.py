"""Tests for CLI tool."""

import pytest
from ratelimit.cli import benchmark, format_results, main


class TestBenchmark:
    async def test_token_bucket(self):
        results = await benchmark("token_bucket", 10, 1.0, 20)
        assert results["allowed"] == 10
        assert results["denied"] == 10
        assert results["total_requests"] == 20

    async def test_fixed_window(self):
        results = await benchmark("fixed_window", 5, 1.0, 10)
        assert results["allowed"] == 5
        assert results["denied"] == 5

    async def test_leaky_bucket(self):
        results = await benchmark("leaky_bucket", 5, 1.0, 10)
        assert results["allowed"] == 5
        assert results["denied"] == 5

    async def test_gcra(self):
        results = await benchmark("gcra", 5, 1.0, 10)
        assert results["allowed"] == 5
        assert results["denied"] == 5

    async def test_all_allowed(self):
        results = await benchmark("token_bucket", 100, 1.0, 50)
        assert results["allowed"] == 50
        assert results["denied"] == 0


class TestFormatResults:
    def test_format_basic(self):
        results = {
            "algorithm": "token_bucket",
            "max_requests": 10,
            "window_seconds": 1.0,
            "total_requests": 20,
            "allowed": 10,
            "denied": 10,
            "elapsed_seconds": 0.001,
            "requests_per_second": 20000,
            "avg_retry_after": 0.5,
        }
        output = format_results(results)
        assert "token_bucket" in output
        assert "10" in output

    def test_format_no_denied(self):
        results = {
            "algorithm": "token_bucket",
            "max_requests": 100,
            "window_seconds": 1.0,
            "total_requests": 50,
            "allowed": 50,
            "denied": 0,
            "elapsed_seconds": 0.001,
            "requests_per_second": 50000,
            "avg_retry_after": 0,
        }
        output = format_results(results)
        assert "retry" not in output.lower()


class TestMain:
    def test_list_command(self):
        result = main(["list"])
        assert result == 0

    def test_bench_command(self):
        result = main(["bench", "-r", "5", "-n", "10"])
        assert result == 0

    def test_no_command(self):
        result = main([])
        assert result == 1

    def test_bench_with_algorithm(self):
        result = main(["bench", "-a", "fixed_window", "-r", "5", "-n", "10"])
        assert result == 0
