"""Tests for factory function."""

import pytest
from ratelimit.factory import create_limiter
from ratelimit.core import Algorithm
from ratelimit.backends.memory import MemoryBackend
from ratelimit.algorithms.token_bucket import TokenBucket
from ratelimit.algorithms.fixed_window import FixedWindow
from ratelimit.algorithms.sliding_window import SlidingWindowLog, SlidingWindowCounter
from ratelimit.algorithms.leaky_bucket import LeakyBucket
from ratelimit.algorithms.concurrency import ConcurrencyLimiter


class TestCreateLimiter:
    def test_default_token_bucket(self):
        limiter = create_limiter(100, 60)
        assert isinstance(limiter.algorithm, TokenBucket)

    def test_fixed_window_enum(self):
        limiter = create_limiter(10, 1, algorithm=Algorithm.FIXED_WINDOW)
        assert isinstance(limiter.algorithm, FixedWindow)

    def test_fixed_window_string(self):
        limiter = create_limiter(10, 1, algorithm="fixed_window")
        assert isinstance(limiter.algorithm, FixedWindow)

    def test_sliding_window_log(self):
        limiter = create_limiter(10, 1, algorithm="sliding_window_log")
        assert isinstance(limiter.algorithm, SlidingWindowLog)

    def test_sliding_window_counter(self):
        limiter = create_limiter(10, 1, algorithm="sliding_window_counter")
        assert isinstance(limiter.algorithm, SlidingWindowCounter)

    def test_leaky_bucket(self):
        limiter = create_limiter(10, 1, algorithm="leaky_bucket")
        assert isinstance(limiter.algorithm, LeakyBucket)

    def test_concurrency(self):
        limiter = create_limiter(5, 30, algorithm="concurrency")
        assert isinstance(limiter.algorithm, ConcurrencyLimiter)

    def test_custom_backend(self):
        backend = MemoryBackend()
        limiter = create_limiter(10, 1, backend=backend)
        assert isinstance(limiter.algorithm, TokenBucket)

    def test_burst_size(self):
        limiter = create_limiter(10, 1, burst_size=20)
        config = limiter.get_config()
        assert config.burst_size == 20

    def test_key_prefix(self):
        limiter = create_limiter(10, 1, key_prefix="api")
        config = limiter.get_config()
        assert config.key_prefix == "api"

    def test_invalid_algorithm(self):
        with pytest.raises(ValueError):
            create_limiter(10, 1, algorithm="nonexistent")

    def test_invalid_max_requests(self):
        with pytest.raises(ValueError):
            create_limiter(0, 1)

    async def test_functional_acquire(self):
        limiter = create_limiter(3, 1)
        for _ in range(3):
            r = await limiter.acquire("test")
            assert r.allowed
        r = await limiter.acquire("test")
        assert not r.allowed
