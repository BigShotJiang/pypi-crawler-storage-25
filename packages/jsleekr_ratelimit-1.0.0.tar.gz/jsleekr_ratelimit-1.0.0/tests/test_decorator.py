"""Tests for the rate_limit decorator."""

import pytest
from ratelimit.core import RateLimiter, RateLimitConfig
from ratelimit.algorithms.token_bucket import TokenBucket
from ratelimit.backends.memory import MemoryBackend
from ratelimit.decorator import rate_limit, RateLimitExceeded


@pytest.fixture
def limiter():
    backend = MemoryBackend()
    config = RateLimitConfig(max_requests=3, window_seconds=1.0)
    tb = TokenBucket(backend, config)
    return RateLimiter(tb)


class TestRateLimitDecorator:
    async def test_async_function_allowed(self, limiter):
        @rate_limit(limiter, key="test")
        async def my_func():
            return "ok"

        result = await my_func()
        assert result == "ok"

    async def test_async_function_denied(self, limiter):
        @rate_limit(limiter, key="test")
        async def my_func():
            return "ok"

        for _ in range(3):
            await my_func()
        with pytest.raises(RateLimitExceeded):
            await my_func()

    async def test_default_key_uses_qualname(self, limiter):
        @rate_limit(limiter)
        async def my_func():
            return "ok"

        result = await my_func()
        assert result == "ok"

    async def test_callable_key(self, limiter):
        @rate_limit(limiter, key=lambda user_id: f"user:{user_id}")
        async def my_func(user_id):
            return f"hello {user_id}"

        result = await my_func("alice")
        assert result == "hello alice"

    async def test_custom_cost(self, limiter):
        @rate_limit(limiter, key="test", cost=2)
        async def my_func():
            return "ok"

        await my_func()  # cost 2, remaining 1
        with pytest.raises(RateLimitExceeded):
            await my_func()  # cost 2, but only 1 remaining

    async def test_rate_limit_exceeded_has_result(self, limiter):
        @rate_limit(limiter, key="test")
        async def my_func():
            return "ok"

        for _ in range(3):
            await my_func()
        with pytest.raises(RateLimitExceeded) as exc_info:
            await my_func()
        assert exc_info.value.result.allowed is False
        assert exc_info.value.result.retry_after > 0

    async def test_wait_mode(self):
        backend = MemoryBackend()
        config = RateLimitConfig(max_requests=1, window_seconds=0.05)
        tb = TokenBucket(backend, config)
        limiter = RateLimiter(tb)

        @rate_limit(limiter, key="test", wait=True, timeout=1.0)
        async def my_func():
            return "ok"

        r1 = await my_func()
        assert r1 == "ok"
        r2 = await my_func()  # Should wait and succeed
        assert r2 == "ok"
