"""Tests for key extraction utilities."""

import pytest
from ratelimit.keys import (
    KeyBuilder,
    KeyExtractor,
    ip_key,
    user_key,
    api_key_hash,
    endpoint_key,
    composite_key,
)


class TestKeyBuilder:
    def test_build_no_prefix(self):
        kb = KeyBuilder()
        assert kb.build("user", "123") == "user:123"

    def test_build_with_prefix(self):
        kb = KeyBuilder(prefix="api")
        assert kb.build("user", "123") == "api:user:123"

    def test_custom_separator(self):
        kb = KeyBuilder(separator="/")
        assert kb.build("a", "b", "c") == "a/b/c"

    def test_with_prefix(self):
        kb = KeyBuilder(prefix="api")
        kb2 = kb.with_prefix("v1")
        assert kb2.build("users") == "api:v1:users"

    def test_with_prefix_no_original(self):
        kb = KeyBuilder()
        kb2 = kb.with_prefix("api")
        assert kb2.build("users") == "api:users"

    def test_single_part(self):
        kb = KeyBuilder()
        assert kb.build("single") == "single"


class TestHelperFunctions:
    def test_ip_key(self):
        assert ip_key("192.168.1.1") == "ip:192.168.1.1"

    def test_ip_key_custom_prefix(self):
        assert ip_key("10.0.0.1", prefix="addr") == "addr:10.0.0.1"

    def test_user_key(self):
        assert user_key("alice") == "user:alice"

    def test_user_key_int(self):
        assert user_key(42) == "user:42"

    def test_api_key_hash(self):
        key1 = api_key_hash("my-secret-key")
        assert key1.startswith("apikey:")
        assert "my-secret-key" not in key1

    def test_api_key_hash_consistent(self):
        h1 = api_key_hash("same-key")
        h2 = api_key_hash("same-key")
        assert h1 == h2

    def test_api_key_hash_different(self):
        h1 = api_key_hash("key-1")
        h2 = api_key_hash("key-2")
        assert h1 != h2

    def test_endpoint_key(self):
        assert endpoint_key("GET", "/users") == "endpoint:GET:/users"

    def test_composite_key(self):
        assert composite_key("user", "123", "GET", "/api") == "user:123:GET:/api"

    def test_composite_key_custom_sep(self):
        assert composite_key("a", "b", separator="-") == "a-b"


class TestKeyExtractor:
    def test_basic_extract(self):
        ext = KeyExtractor()
        ext.add_part("user", lambda uid: uid)
        assert ext.extract("alice") == "user=alice"

    def test_multiple_parts(self):
        ext = KeyExtractor()
        ext.add_part("user", lambda uid, path: uid)
        ext.add_part("path", lambda uid, path: path)
        assert ext.extract("alice", "/api") == "user=alice:path=/api"

    def test_with_prefix(self):
        ext = KeyExtractor(prefix="rl")
        ext.add_part("user", lambda uid: uid)
        assert ext.extract("bob") == "rl:user=bob"

    def test_chaining(self):
        ext = (
            KeyExtractor()
            .add_part("a", lambda x: x)
            .add_part("b", lambda x: x.upper())
        )
        result = ext.extract("hello")
        assert result == "a=hello:b=HELLO"

    def test_callable(self):
        ext = KeyExtractor()
        ext.add_part("user", lambda uid: uid)
        # Should be callable directly
        assert ext("alice") == "user=alice"

    def test_kwargs(self):
        ext = KeyExtractor()
        ext.add_part("user", lambda **kw: kw.get("user_id", "anon"))
        assert ext(user_id="bob") == "user=bob"

    def test_custom_separator(self):
        ext = KeyExtractor(separator="/")
        ext.add_part("a", lambda: "1")
        ext.add_part("b", lambda: "2")
        assert ext() == "a=1/b=2"
