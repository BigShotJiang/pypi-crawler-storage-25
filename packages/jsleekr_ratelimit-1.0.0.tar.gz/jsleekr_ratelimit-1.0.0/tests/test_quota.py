"""Tests for quota management."""

import time
import pytest
from ratelimit.quota import QuotaManager, QuotaPeriod, QuotaUsage


class TestQuotaUsage:
    def test_remaining(self):
        qu = QuotaUsage(used=30, limit=100, period=QuotaPeriod.DAILY, resets_at=0)
        assert qu.remaining == 70

    def test_remaining_exceeded(self):
        qu = QuotaUsage(used=150, limit=100, period=QuotaPeriod.DAILY, resets_at=0)
        assert qu.remaining == 0

    def test_percentage_used(self):
        qu = QuotaUsage(used=25, limit=100, period=QuotaPeriod.DAILY, resets_at=0)
        assert qu.percentage_used == pytest.approx(25.0)

    def test_percentage_zero_limit(self):
        qu = QuotaUsage(used=0, limit=0, period=QuotaPeriod.DAILY, resets_at=0)
        assert qu.percentage_used == 100.0

    def test_is_exceeded(self):
        qu = QuotaUsage(used=100, limit=100, period=QuotaPeriod.DAILY, resets_at=0)
        assert qu.is_exceeded is True

    def test_not_exceeded(self):
        qu = QuotaUsage(used=50, limit=100, period=QuotaPeriod.DAILY, resets_at=0)
        assert qu.is_exceeded is False


class TestQuotaManager:
    def test_set_quota(self):
        qm = QuotaManager()
        qm.set_quota("user1", QuotaPeriod.DAILY, 1000)
        usage = qm.check("user1")
        assert len(usage) == 1
        assert usage[0].limit == 1000
        assert usage[0].used == 0

    def test_set_quota_invalid(self):
        qm = QuotaManager()
        with pytest.raises(ValueError, match="limit must be positive"):
            qm.set_quota("user1", QuotaPeriod.DAILY, 0)

    def test_consume(self):
        qm = QuotaManager()
        qm.set_quota("user1", QuotaPeriod.DAILY, 100)
        usage = qm.consume("user1", amount=10)
        assert len(usage) == 1
        assert usage[0].used == 10
        assert usage[0].remaining == 90

    def test_consume_multiple(self):
        qm = QuotaManager()
        qm.set_quota("user1", QuotaPeriod.DAILY, 100)
        qm.consume("user1", 30)
        usage = qm.consume("user1", 20)
        assert usage[0].used == 50

    def test_consume_exceeds(self):
        qm = QuotaManager()
        qm.set_quota("user1", QuotaPeriod.DAILY, 10)
        usage = qm.consume("user1", 15)
        assert usage[0].is_exceeded is True

    def test_multiple_periods(self):
        qm = QuotaManager()
        qm.set_quota("user1", QuotaPeriod.HOURLY, 100)
        qm.set_quota("user1", QuotaPeriod.DAILY, 1000)
        usage = qm.consume("user1", 10)
        assert len(usage) == 2
        hourly = [u for u in usage if u.period == QuotaPeriod.HOURLY][0]
        daily = [u for u in usage if u.period == QuotaPeriod.DAILY][0]
        assert hourly.used == 10
        assert daily.used == 10

    def test_check_without_consuming(self):
        qm = QuotaManager()
        qm.set_quota("user1", QuotaPeriod.DAILY, 100)
        qm.consume("user1", 30)
        usage1 = qm.check("user1")
        usage2 = qm.check("user1")
        assert usage1[0].used == usage2[0].used == 30

    def test_check_no_quota(self):
        qm = QuotaManager()
        usage = qm.check("nonexistent")
        assert usage == []

    def test_consume_no_quota(self):
        qm = QuotaManager()
        usage = qm.consume("nonexistent")
        assert usage == []

    def test_reset_all_periods(self):
        qm = QuotaManager()
        qm.set_quota("user1", QuotaPeriod.HOURLY, 100)
        qm.set_quota("user1", QuotaPeriod.DAILY, 1000)
        qm.consume("user1", 50)
        qm.reset("user1")
        usage = qm.check("user1")
        for u in usage:
            assert u.used == 0

    def test_reset_specific_period(self):
        qm = QuotaManager()
        qm.set_quota("user1", QuotaPeriod.HOURLY, 100)
        qm.set_quota("user1", QuotaPeriod.DAILY, 1000)
        qm.consume("user1", 50)
        qm.reset("user1", QuotaPeriod.HOURLY)
        usage = qm.check("user1")
        hourly = [u for u in usage if u.period == QuotaPeriod.HOURLY][0]
        daily = [u for u in usage if u.period == QuotaPeriod.DAILY][0]
        assert hourly.used == 0
        assert daily.used == 50

    def test_different_keys_independent(self):
        qm = QuotaManager()
        qm.set_quota("user1", QuotaPeriod.DAILY, 100)
        qm.set_quota("user2", QuotaPeriod.DAILY, 100)
        qm.consume("user1", 50)
        usage = qm.check("user2")
        assert usage[0].used == 0

    def test_resets_at_future(self):
        qm = QuotaManager()
        qm.set_quota("user1", QuotaPeriod.DAILY, 100)
        usage = qm.consume("user1")
        assert usage[0].resets_at > time.time()


class TestQuotaPeriod:
    def test_values(self):
        assert QuotaPeriod.HOURLY.value == "hourly"
        assert QuotaPeriod.DAILY.value == "daily"
        assert QuotaPeriod.WEEKLY.value == "weekly"
        assert QuotaPeriod.MONTHLY.value == "monthly"
