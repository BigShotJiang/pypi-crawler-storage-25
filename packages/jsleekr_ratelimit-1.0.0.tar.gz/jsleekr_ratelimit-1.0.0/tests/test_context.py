"""Tests for context managers."""

import pytest
from ratelimit.context import RateLimitContext, ConcurrencyContext
from ratelimit.core import RateLimiter, RateLimitConfig
from ratelimit.algorithms.token_bucket import TokenBucket
from ratelimit.algorithms.concurrency import ConcurrencyLimiter
from ratelimit.backends.memory import MemoryBackend
from ratelimit.decorator import RateLimitExceeded


class TestRateLimitContext:
    async def test_allowed(self):
        backend = MemoryBackend()
        config = RateLimitConfig(max_requests=10, window_seconds=1.0)
        limiter = RateLimiter(TokenBucket(backend, config))

        async with RateLimitContext(limiter, "user1") as result:
            assert result.allowed is True
            assert result.remaining == 9

    async def test_denied_raises(self):
        backend = MemoryBackend()
        config = RateLimitConfig(max_requests=1, window_seconds=1.0)
        limiter = RateLimiter(TokenBucket(backend, config))
        await limiter.acquire("user1")  # Exhaust

        with pytest.raises(RateLimitExceeded):
            async with RateLimitContext(limiter, "user1"):
                pass

    async def test_wait_mode(self):
        backend = MemoryBackend()
        config = RateLimitConfig(max_requests=1, window_seconds=0.05)
        limiter = RateLimiter(TokenBucket(backend, config))
        await limiter.acquire("user1")

        async with RateLimitContext(limiter, "user1", wait=True, timeout=1.0) as result:
            assert result.allowed is True

    async def test_cost(self):
        backend = MemoryBackend()
        config = RateLimitConfig(max_requests=10, window_seconds=1.0)
        limiter = RateLimiter(TokenBucket(backend, config))

        async with RateLimitContext(limiter, "user1", cost=5) as result:
            assert result.remaining == 5

    async def test_concurrency_auto_release(self):
        backend = MemoryBackend()
        config = RateLimitConfig(max_requests=1, window_seconds=60.0)
        cl = ConcurrencyLimiter(backend, config)
        limiter = RateLimiter(cl)

        async with RateLimitContext(limiter, "user1") as result:
            assert result.allowed
            # Slot is taken
            peek = await limiter.peek("user1")
            assert peek.remaining == 0

        # After context exit, slot should be released
        peek = await limiter.peek("user1")
        assert peek.remaining == 1


class TestConcurrencyContext:
    async def test_acquire_and_release(self):
        backend = MemoryBackend()
        config = RateLimitConfig(max_requests=2, window_seconds=60.0)
        cl = ConcurrencyLimiter(backend, config)

        async with ConcurrencyContext(cl, "svc1") as result:
            assert result.allowed
            peek = await cl.peek("svc1")
            assert peek.remaining == 1

        # Auto-released
        peek = await cl.peek("svc1")
        assert peek.remaining == 2

    async def test_denied_raises(self):
        backend = MemoryBackend()
        config = RateLimitConfig(max_requests=1, window_seconds=60.0)
        cl = ConcurrencyLimiter(backend, config)

        async with ConcurrencyContext(cl, "svc1"):
            with pytest.raises(RateLimitExceeded):
                async with ConcurrencyContext(cl, "svc1"):
                    pass

    async def test_release_on_exception(self):
        backend = MemoryBackend()
        config = RateLimitConfig(max_requests=1, window_seconds=60.0)
        cl = ConcurrencyLimiter(backend, config)

        try:
            async with ConcurrencyContext(cl, "svc1"):
                raise ValueError("test error")
        except ValueError:
            pass

        # Should be released despite exception
        peek = await cl.peek("svc1")
        assert peek.remaining == 1

    async def test_cost(self):
        backend = MemoryBackend()
        config = RateLimitConfig(max_requests=5, window_seconds=60.0)
        cl = ConcurrencyLimiter(backend, config)

        async with ConcurrencyContext(cl, "svc1", cost=3) as result:
            assert result.remaining == 2

        peek = await cl.peek("svc1")
        assert peek.remaining == 5
