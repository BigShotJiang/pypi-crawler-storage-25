"""Tests for preset rate limiting policies."""

import pytest
from ratelimit.presets import (
    api_standard,
    api_strict,
    api_generous,
    login_protection,
    webhook_delivery,
    search_api,
    upload_limit,
    free_tier,
    pro_tier,
    enterprise_tier,
    get_preset,
    list_presets,
    PRESETS,
)
from ratelimit.core import RateLimiter
from ratelimit.groups import RateLimitGroup


class TestPresets:
    def test_api_standard(self):
        limiter = api_standard()
        assert isinstance(limiter, RateLimiter)
        config = limiter.get_config()
        assert config.max_requests == 100

    def test_api_strict(self):
        limiter = api_strict()
        config = limiter.get_config()
        assert config.max_requests == 30

    def test_api_generous(self):
        limiter = api_generous()
        config = limiter.get_config()
        assert config.max_requests == 1000

    def test_login_protection(self):
        limiter = login_protection()
        config = limiter.get_config()
        assert config.max_requests == 5
        assert config.window_seconds == 900

    def test_webhook_delivery(self):
        limiter = webhook_delivery()
        config = limiter.get_config()
        assert config.max_requests == 10

    def test_search_api(self):
        group = search_api()
        assert isinstance(group, RateLimitGroup)

    def test_upload_limit(self):
        limiter = upload_limit()
        config = limiter.get_config()
        assert config.max_requests == 10

    def test_free_tier(self):
        limiter = free_tier()
        config = limiter.get_config()
        assert config.max_requests == 100

    def test_pro_tier(self):
        limiter = pro_tier()
        config = limiter.get_config()
        assert config.max_requests == 5000

    def test_enterprise_tier(self):
        limiter = enterprise_tier()
        config = limiter.get_config()
        assert config.max_requests == 50000

    def test_custom_prefix(self):
        limiter = api_standard(key_prefix="v2")
        config = limiter.get_config()
        assert config.key_prefix == "v2"


class TestPresetRegistry:
    def test_get_preset(self):
        limiter = get_preset("api_standard")
        assert isinstance(limiter, RateLimiter)

    def test_get_preset_unknown(self):
        with pytest.raises(ValueError, match="Unknown preset"):
            get_preset("nonexistent")

    def test_list_presets(self):
        presets = list_presets()
        assert "api_standard" in presets
        assert "login_protection" in presets
        assert len(presets) == len(PRESETS)

    def test_all_presets_callable(self):
        for name in list_presets():
            result = get_preset(name)
            assert result is not None


class TestPresetsFunctional:
    async def test_login_protection_blocks(self):
        limiter = login_protection()
        for _ in range(5):
            r = await limiter.acquire("attacker")
            assert r.allowed
        r = await limiter.acquire("attacker")
        assert not r.allowed

    async def test_api_standard_allows_burst(self):
        limiter = api_standard()
        for _ in range(20):
            r = await limiter.acquire("user1")
            assert r.allowed
