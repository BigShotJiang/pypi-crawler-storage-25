"""Tests for rate estimator."""

import time
import pytest
from ratelimit.estimator import RateEstimator, RateEstimate


class TestRateEstimate:
    def test_requests_per_hour(self):
        est = RateEstimate(
            requests_per_second=10.0,
            requests_per_minute=600.0,
            window_seconds=60.0,
            sample_count=100,
        )
        assert est.requests_per_hour == 36000.0


class TestRateEstimator:
    def test_no_records(self):
        estimator = RateEstimator()
        est = estimator.estimate("user1")
        assert est.requests_per_second == 0.0
        assert est.sample_count == 0

    def test_single_record(self):
        estimator = RateEstimator(window_seconds=10.0)
        estimator.record("user1")
        est = estimator.estimate("user1")
        assert est.sample_count == 1
        assert est.requests_per_second >= 0

    def test_multiple_records(self):
        estimator = RateEstimator(window_seconds=10.0)
        for _ in range(5):
            estimator.record("user1")
        est = estimator.estimate("user1")
        assert est.sample_count == 5
        assert est.requests_per_second > 0

    def test_different_keys(self):
        estimator = RateEstimator()
        estimator.record("user1")
        estimator.record("user1")
        estimator.record("user2")
        est1 = estimator.estimate("user1")
        est2 = estimator.estimate("user2")
        assert est1.sample_count == 2
        assert est2.sample_count == 1

    def test_time_to_limit(self):
        estimator = RateEstimator(window_seconds=10.0)
        for _ in range(10):
            estimator.record("user1")
        ttl = estimator.time_to_limit("user1", max_requests=100, remaining=50)
        assert ttl is not None
        assert ttl > 0

    def test_time_to_limit_no_data(self):
        estimator = RateEstimator()
        ttl = estimator.time_to_limit("user1", max_requests=100, remaining=50)
        assert ttl is None

    def test_cleanup(self):
        estimator = RateEstimator(window_seconds=0.01)
        estimator.record("user1")
        time.sleep(0.02)
        estimator.cleanup()
        assert "user1" not in estimator.get_keys()

    def test_cleanup_specific_key(self):
        estimator = RateEstimator(window_seconds=0.01)
        estimator.record("user1")
        estimator.record("user2")
        time.sleep(0.02)
        estimator.record("user2")  # Fresh record
        estimator.cleanup()  # Clean all
        assert "user1" not in estimator.get_keys()
        assert "user2" in estimator.get_keys()

    def test_get_keys(self):
        estimator = RateEstimator()
        estimator.record("a")
        estimator.record("b")
        estimator.record("c")
        keys = estimator.get_keys()
        assert set(keys) == {"a", "b", "c"}

    def test_clear(self):
        estimator = RateEstimator()
        estimator.record("user1")
        estimator.clear()
        assert estimator.get_keys() == []

    def test_max_samples(self):
        estimator = RateEstimator(max_samples=5)
        for _ in range(10):
            estimator.record("user1")
        est = estimator.estimate("user1")
        assert est.sample_count <= 5

    def test_invalid_window(self):
        with pytest.raises(ValueError, match="window_seconds must be positive"):
            RateEstimator(window_seconds=0)

    def test_invalid_max_samples(self):
        with pytest.raises(ValueError, match="max_samples must be positive"):
            RateEstimator(max_samples=0)
