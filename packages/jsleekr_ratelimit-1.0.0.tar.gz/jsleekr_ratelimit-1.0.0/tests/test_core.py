"""Tests for core module."""

import pytest
import time
from ratelimit.core import RateLimitResult, RateLimitConfig, RateLimiter, Algorithm
from ratelimit.algorithms.token_bucket import TokenBucket
from ratelimit.backends.memory import MemoryBackend


class TestRateLimitResult:
    def test_to_headers_allowed(self):
        result = RateLimitResult(
            allowed=True,
            remaining=5,
            limit=10,
            reset_at=time.time() + 60,
        )
        headers = result.to_headers()
        assert headers["X-RateLimit-Limit"] == "10"
        assert headers["X-RateLimit-Remaining"] == "5"
        assert "Retry-After" not in headers

    def test_to_headers_denied(self):
        result = RateLimitResult(
            allowed=False,
            remaining=0,
            limit=10,
            reset_at=time.time() + 60,
            retry_after=30.0,
        )
        headers = result.to_headers()
        assert headers["X-RateLimit-Remaining"] == "0"
        assert "Retry-After" in headers

    def test_reset_in(self):
        future = time.time() + 10
        result = RateLimitResult(
            allowed=True, remaining=5, limit=10, reset_at=future
        )
        assert result.reset_in > 0
        assert result.reset_in <= 10

    def test_reset_in_past(self):
        past = time.time() - 10
        result = RateLimitResult(
            allowed=True, remaining=5, limit=10, reset_at=past
        )
        assert result.reset_in == 0.0

    def test_remaining_never_negative_in_headers(self):
        result = RateLimitResult(
            allowed=False, remaining=-1, limit=10, reset_at=time.time()
        )
        headers = result.to_headers()
        assert headers["X-RateLimit-Remaining"] == "0"

    def test_metadata_default(self):
        result = RateLimitResult(
            allowed=True, remaining=5, limit=10, reset_at=time.time()
        )
        assert result.metadata == {}


class TestRateLimitConfig:
    def test_valid_config(self):
        config = RateLimitConfig(max_requests=10, window_seconds=1.0)
        assert config.max_requests == 10
        assert config.window_seconds == 1.0

    def test_invalid_max_requests(self):
        with pytest.raises(ValueError, match="max_requests must be positive"):
            RateLimitConfig(max_requests=0, window_seconds=1.0)

    def test_negative_max_requests(self):
        with pytest.raises(ValueError, match="max_requests must be positive"):
            RateLimitConfig(max_requests=-1, window_seconds=1.0)

    def test_invalid_window_seconds(self):
        with pytest.raises(ValueError, match="window_seconds must be positive"):
            RateLimitConfig(max_requests=10, window_seconds=0)

    def test_invalid_burst_size(self):
        with pytest.raises(ValueError, match="burst_size must be positive"):
            RateLimitConfig(max_requests=10, window_seconds=1.0, burst_size=0)

    def test_default_algorithm(self):
        config = RateLimitConfig(max_requests=10, window_seconds=1.0)
        assert config.algorithm == Algorithm.TOKEN_BUCKET

    def test_custom_prefix(self):
        config = RateLimitConfig(max_requests=10, window_seconds=1.0, key_prefix="api")
        assert config.key_prefix == "api"


class TestRateLimiter:
    async def test_acquire(self):
        backend = MemoryBackend()
        config = RateLimitConfig(max_requests=5, window_seconds=1.0)
        tb = TokenBucket(backend, config)
        limiter = RateLimiter(tb)
        result = await limiter.acquire("user1")
        assert result.allowed is True

    async def test_on_limited_callback(self):
        backend = MemoryBackend()
        config = RateLimitConfig(max_requests=1, window_seconds=1.0)
        tb = TokenBucket(backend, config)
        limiter = RateLimiter(tb)

        limited_calls = []
        limiter.on_limited(lambda k, r: limited_calls.append(k))

        await limiter.acquire("user1")
        await limiter.acquire("user1")  # Should trigger callback
        assert "user1" in limited_calls

    async def test_on_allowed_callback(self):
        backend = MemoryBackend()
        config = RateLimitConfig(max_requests=5, window_seconds=1.0)
        tb = TokenBucket(backend, config)
        limiter = RateLimiter(tb)

        allowed_calls = []
        limiter.on_allowed(lambda k, r: allowed_calls.append(k))

        await limiter.acquire("user1")
        assert "user1" in allowed_calls

    async def test_peek(self):
        backend = MemoryBackend()
        config = RateLimitConfig(max_requests=5, window_seconds=1.0)
        tb = TokenBucket(backend, config)
        limiter = RateLimiter(tb)
        result = await limiter.peek("user1")
        assert result.remaining == 5

    async def test_reset(self):
        backend = MemoryBackend()
        config = RateLimitConfig(max_requests=3, window_seconds=1.0)
        tb = TokenBucket(backend, config)
        limiter = RateLimiter(tb)
        for _ in range(3):
            await limiter.acquire("user1")
        await limiter.reset("user1")
        result = await limiter.acquire("user1")
        assert result.allowed is True

    async def test_get_config(self):
        backend = MemoryBackend()
        config = RateLimitConfig(max_requests=5, window_seconds=1.0)
        tb = TokenBucket(backend, config)
        limiter = RateLimiter(tb)
        assert limiter.get_config() == config

    async def test_algorithm_property(self):
        backend = MemoryBackend()
        config = RateLimitConfig(max_requests=5, window_seconds=1.0)
        tb = TokenBucket(backend, config)
        limiter = RateLimiter(tb)
        assert limiter.algorithm is tb


class TestAlgorithmEnum:
    def test_all_algorithms(self):
        assert Algorithm.TOKEN_BUCKET.value == "token_bucket"
        assert Algorithm.SLIDING_WINDOW_LOG.value == "sliding_window_log"
        assert Algorithm.FIXED_WINDOW.value == "fixed_window"
        assert Algorithm.LEAKY_BUCKET.value == "leaky_bucket"
        assert Algorithm.CONCURRENCY.value == "concurrency"
