"""Tests for event system."""

import pytest
from ratelimit.events import EventType, Event, EventEmitter


class TestEvent:
    def test_create(self):
        event = Event(EventType.ACQUIRED, "user1")
        assert event.type == EventType.ACQUIRED
        assert event.key == "user1"
        assert event.timestamp > 0

    def test_data(self):
        event = Event(EventType.DENIED, "user1", {"reason": "limit"})
        assert event.data["reason"] == "limit"

    def test_default_data(self):
        event = Event(EventType.ACQUIRED, "user1")
        assert event.data == {}

    def test_repr(self):
        event = Event(EventType.DENIED, "user1")
        r = repr(event)
        assert "denied" in r
        assert "user1" in r


class TestEventType:
    def test_values(self):
        assert EventType.ACQUIRED.value == "acquired"
        assert EventType.DENIED.value == "denied"
        assert EventType.RESET.value == "reset"
        assert EventType.QUOTA_WARNING.value == "quota_warning"
        assert EventType.QUOTA_EXCEEDED.value == "quota_exceeded"
        assert EventType.PENALTY_APPLIED.value == "penalty_applied"


class TestEventEmitter:
    async def test_on_sync_handler(self):
        emitter = EventEmitter()
        calls = []
        emitter.on(EventType.ACQUIRED, lambda e: calls.append(e))
        await emitter.emit(Event(EventType.ACQUIRED, "user1"))
        assert len(calls) == 1

    async def test_on_async_handler(self):
        emitter = EventEmitter()
        calls = []

        async def handler(e):
            calls.append(e)

        emitter.on(EventType.DENIED, handler)
        await emitter.emit(Event(EventType.DENIED, "user1"))
        assert len(calls) == 1

    async def test_on_any(self):
        emitter = EventEmitter()
        calls = []
        emitter.on_any(lambda e: calls.append(e.type))
        await emitter.emit(Event(EventType.ACQUIRED, "user1"))
        await emitter.emit(Event(EventType.DENIED, "user1"))
        assert len(calls) == 2

    async def test_off(self):
        emitter = EventEmitter()
        calls = []
        handler = lambda e: calls.append(e)
        emitter.on(EventType.ACQUIRED, handler)
        removed = emitter.off(EventType.ACQUIRED, handler)
        assert removed is True
        await emitter.emit(Event(EventType.ACQUIRED, "user1"))
        assert len(calls) == 0

    async def test_off_not_found(self):
        emitter = EventEmitter()
        removed = emitter.off(EventType.ACQUIRED, lambda e: None)
        assert removed is False

    async def test_off_any(self):
        emitter = EventEmitter()
        handler = lambda e: None
        emitter.on_any(handler)
        removed = emitter.off_any(handler)
        assert removed is True

    async def test_off_any_not_found(self):
        emitter = EventEmitter()
        removed = emitter.off_any(lambda e: None)
        assert removed is False

    async def test_multiple_handlers(self):
        emitter = EventEmitter()
        calls = []
        emitter.on(EventType.ACQUIRED, lambda e: calls.append("h1"))
        emitter.on(EventType.ACQUIRED, lambda e: calls.append("h2"))
        await emitter.emit(Event(EventType.ACQUIRED, "user1"))
        assert calls == ["h1", "h2"]

    async def test_different_events(self):
        emitter = EventEmitter()
        acquired = []
        denied = []
        emitter.on(EventType.ACQUIRED, lambda e: acquired.append(1))
        emitter.on(EventType.DENIED, lambda e: denied.append(1))
        await emitter.emit(Event(EventType.ACQUIRED, "user1"))
        assert len(acquired) == 1
        assert len(denied) == 0

    def test_handler_count(self):
        emitter = EventEmitter()
        emitter.on(EventType.ACQUIRED, lambda e: None)
        emitter.on(EventType.ACQUIRED, lambda e: None)
        emitter.on(EventType.DENIED, lambda e: None)
        assert emitter.handler_count(EventType.ACQUIRED) == 2
        assert emitter.handler_count(EventType.DENIED) == 1

    def test_handler_count_total(self):
        emitter = EventEmitter()
        emitter.on(EventType.ACQUIRED, lambda e: None)
        emitter.on_any(lambda e: None)
        assert emitter.handler_count() == 2

    def test_clear(self):
        emitter = EventEmitter()
        emitter.on(EventType.ACQUIRED, lambda e: None)
        emitter.on_any(lambda e: None)
        emitter.clear()
        assert emitter.handler_count() == 0

    async def test_decorator_pattern(self):
        emitter = EventEmitter()
        calls = []

        def on_denied(event):
            calls.append(event.key)

        emitter.on(EventType.DENIED, on_denied)
        await emitter.emit(Event(EventType.DENIED, "user1"))
        assert calls == ["user1"]
