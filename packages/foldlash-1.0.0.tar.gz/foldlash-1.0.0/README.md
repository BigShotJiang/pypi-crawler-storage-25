# ⚡ foldlash

> Blazing-fast TUI file finder — search your **entire system** in real time.

```
pip install foldlash
foldlash
```

---

## Features

- 🔍 **System-wide search** — all drives on Windows (`C:\`, `D:\`, …), full `/` on Unix
- ⚡ **Fast BFS indexer** — uses `os.scandir` (2-3× faster than `os.walk`), streams results live
- 🎯 **Relevance sorting** — exact → prefix → substring → path matches, in that order
- 📁 **OneDrive / reparse points** — correctly follows Windows junctions so Documents, Music, Pictures, Downloads are all indexed
- 👁️ **Live index counter** — stats bar shows how many files have been indexed so far
- ⌨️ **Keyboard-first** — type to search, `↑↓` to navigate, `Enter` to open, `q` to quit
- 🖥️ **Cross-platform open** — `os.startfile` on Windows, `open` on macOS, `xdg-open` on Linux
- 👁️ **Watchdog** — picks up newly created files in real time across all drives

## Install

```bash
pip install foldlash
```

Requires Python 3.9+.

## Usage

```bash
foldlash          # launch the TUI
```

Or run as a module:

```bash
python -m foldlash
```

### Key bindings

| Key       | Action                     |
|-----------|----------------------------|
| Type      | Search files & folders     |
| `↑` / `↓` | Navigate results           |
| `Enter`   | Open highlighted item      |
| `q`       | Quit                       |

## How it works

On launch, `foldlash` starts a background BFS scanner using `os.scandir` across every
available drive. Results stream into the cache immediately — you can start searching
before indexing is complete. The stats bar shows the live count.

Matches are ranked:

1. **Exact filename** match
2. Filename **starts with** query
3. Filename **contains** query
4. Full **path contains** query

## Development

```bash
git clone https://github.com/yourusername/foldlash
cd foldlash
pip install -e ".[dev]"
foldlash
```

## Publishing to PyPI

```bash
pip install build twine
python -m build
twine upload dist/*
```

## License

MIT
