"""
Fast, thread-safe file system indexer using BFS + os.scandir.

os.scandir is 2-3× faster than os.walk because DirEntry objects
cache stat data — no extra syscalls for is_dir() checks.
"""

from __future__ import annotations

import os
import platform
import threading
from collections import deque
from typing import Callable, List, Optional

from foldlash.platform_utils import get_scan_roots, should_skip

_HARD_CAP = 500_000   # max entries across all drives


class FileIndexer:
    """
    Background BFS scanner.  Results stream into an internal list so
    the UI can search even before indexing is complete.
    """

    def __init__(self) -> None:
        self._cache: List[str] = []
        self._lock = threading.Lock()
        self._done = threading.Event()
        self._on_update: Optional[Callable[[int], None]] = None

    # ── Public interface ─────────────────────────────────────────────────────

    def start(self, on_update: Optional[Callable[[int], None]] = None) -> None:
        """Start background indexing.  *on_update* is called with the current
        count each time a new batch of paths is added."""
        self._on_update = on_update
        t = threading.Thread(target=self._scan, daemon=True)
        t.start()

    @property
    def snapshot(self) -> List[str]:
        """Return a point-in-time copy of the cache (thread-safe)."""
        with self._lock:
            return list(self._cache)

    @property
    def count(self) -> int:
        return len(self._cache)          # int reads are GIL-atomic in CPython

    @property
    def done(self) -> bool:
        return self._done.is_set()

    def add(self, path: str) -> None:
        """Manually add a path (called by the watchdog)."""
        with self._lock:
            if path not in self._cache:
                self._cache.append(path)

    # ── Internal BFS scan ────────────────────────────────────────────────────

    def _scan(self) -> None:
        follow = platform.system() == "Windows"   # follow reparse points on Windows

        for root in get_scan_roots():
            queue: deque[str] = deque([root])

            while queue:
                current = queue.popleft()
                batch: List[str] = []

                try:
                    with os.scandir(current) as it:
                        for entry in it:
                            if should_skip(entry.name):
                                continue
                            batch.append(entry.path)
                            try:
                                if entry.is_dir(follow_symlinks=follow):
                                    queue.append(entry.path)
                            except OSError:
                                pass
                except (PermissionError, OSError):
                    continue

                if batch:
                    with self._lock:
                        self._cache.extend(batch)

                    if self._on_update:
                        self._on_update(len(self._cache))

                    if len(self._cache) >= _HARD_CAP:
                        self._done.set()
                        return

        self._done.set()


# ── Search helper ─────────────────────────────────────────────────────────────

def ranked_search(cache: List[str], query: str, limit: int = 100) -> List[str]:
    """
    Return up to *limit* paths that match *query*, sorted by relevance:

      0 — exact filename match
      1 — filename starts with query
      2 — filename contains query
      3 — full path contains query (not the filename)
    """
    q = query.lower()
    buckets: tuple[list, list, list, list] = ([], [], [], [])

    for path in cache:
        name = os.path.basename(path).lower()
        if name == q:
            buckets[0].append(path)
        elif name.startswith(q):
            buckets[1].append(path)
        elif q in name:
            buckets[2].append(path)
        elif q in path.lower():
            buckets[3].append(path)

        # Early exit once we have enough from high-priority buckets
        if len(buckets[0]) + len(buckets[1]) >= limit:
            break

    result: List[str] = []
    for bucket in buckets:
        result.extend(bucket)
        if len(result) >= limit:
            break

    return result[:limit]
