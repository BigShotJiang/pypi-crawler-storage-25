import typer
from foldlash import __version__

_app = typer.Typer(
    name="foldlash",
    help="Blazing-fast TUI file finder for your entire system.",
    add_completion=False,
)


@_app.command()
def _start(
    version: bool = typer.Option(
        False, "--version", "-v", help="Show version and exit.", is_eager=True
    ),
) -> None:
    """Launch the foldlash TUI."""
    if version:
        typer.echo(f"foldlash {__version__}")
        raise typer.Exit()

    from foldlash.tui import FoldlashUI
    FoldlashUI().run()


def main() -> None:
    _app()
