"""
Foldlash TUI — Textual-based UI.

Speed improvements over the original single-file version:
  • BFS indexer (os.scandir) runs in a daemon thread → UI never blocks
  • Debounced search (80 ms) → no lag while typing
  • ranked_search() sorts by relevance before rendering
  • Stats label shows live index count while scanning
  • Periodic ticker keeps the counter updating smoothly
"""

from __future__ import annotations

import os
import re
from typing import Optional

from rich.text import Text
from textual import work
from textual.app import App, ComposeResult
from textual.timer import Timer
from textual.widgets import Input, Label, ListItem, ListView, Static
from textual.containers import Container
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

from foldlash.indexer import FileIndexer, ranked_search
from foldlash.platform_utils import get_scan_roots, open_path


# ── Watchdog ──────────────────────────────────────────────────────────────────

class _FolderWatcher(FileSystemEventHandler):
    def __init__(self, indexer: FileIndexer) -> None:
        self._indexer = indexer

    def on_created(self, event) -> None:           # type: ignore[override]
        self._indexer.add(event.src_path)


# ── App ───────────────────────────────────────────────────────────────────────

class FoldlashUI(App):
    CSS = """
    Screen { layout: vertical; }
    #results_list {
        height: 1fr;
        border: round green;
        scrollbar-color: green;
    }
    #bottom_zone {
        height: auto;
        dock: bottom;
        layout: vertical;
    }
    #stats_label {
        width: 100%;
        text-align: right;
        color: orange;
        text-style: bold;
        padding-right: 2;
        margin-bottom: -1;
    }
    #search_bar {
        border: round blue;
        background: $boost;
    }
    """

    BINDINGS = [("q", "quit", "Quit"), ("enter", "open_item", "Open")]

    def __init__(self) -> None:
        super().__init__()
        self._indexer = FileIndexer()
        self._debounce_timer: Optional[Timer] = None
        self._ticker: Optional[Timer] = None

    # ── Layout ────────────────────────────────────────────────────────────────

    def compose(self) -> ComposeResult:
        yield ListView(id="results_list")
        with Container(id="bottom_zone"):
            yield Label("indexing… 0 files", id="stats_label")
            yield Input(placeholder="Search files and folders…", id="search_bar")

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def on_mount(self) -> None:
        self.query_one("#search_bar").focus()
        # Start the BFS indexer in a background thread
        self._indexer.start()
        # Start watchdog on every drive root
        self._observer = Observer()
        for root in get_scan_roots():
            self._observer.schedule(
                _FolderWatcher(self._indexer), root, recursive=True
            )
        self._observer.start()
        # Ticker: refresh the stats label while indexing
        self._ticker = self.set_interval(0.4, self._refresh_stats)

    def on_unmount(self) -> None:
        if self._ticker:
            self._ticker.stop()
        if hasattr(self, "_observer"):
            self._observer.stop()
            self._observer.join()

    # ── Stats ticker ──────────────────────────────────────────────────────────

    def _refresh_stats(self) -> None:
        count = self._indexer.count
        status = "indexed" if self._indexer.done else "indexing…"
        self.query_one("#stats_label", Label).update(
            f"{status}  {count:,} files"
        )
        if self._indexer.done and self._ticker:
            self._ticker.stop()
            self._ticker = None

    # ── Keyboard navigation ───────────────────────────────────────────────────

    def on_key(self, event) -> None:
        lv = self.query_one("#results_list", ListView)
        if event.key == "up":
            lv.action_cursor_up()
        elif event.key == "down":
            lv.action_cursor_down()

    # ── Search (debounced 80 ms) ───────────────────────────────────────────────

    def on_input_changed(self, event: Input.Changed) -> None:
        if self._debounce_timer:
            self._debounce_timer.stop()
        query = event.value.strip()
        if query:
            self._debounce_timer = self.set_timer(
                0.08, lambda q=query: self._run_search(q)
            )
        else:
            # Clear immediately on empty input — no debounce needed
            self._run_search("")

    @work(thread=False)
    async def _run_search(self, query: str) -> None:
        lv = self.query_one("#results_list", ListView)
        await lv.clear()
        if not query:
            return

        # Grab a snapshot (thread-safe copy) and rank it
        cache = self._indexer.snapshot
        matches = ranked_search(cache, query)

        q_lower = query.lower()
        for path in matches:
            name = os.path.basename(path)
            is_dir = os.path.isdir(path)
            icon = "📁" if is_dir else "📄"

            display_name = Text(
                f"{icon} {name}\n",
                style="bold green" if is_dir else "bold white",
            )
            display_name.highlight_regex(re.escape(q_lower), "bold yellow on blue")

            display_path = Text(f"   {path}", style="dim green")
            full_display = Text.assemble(display_name, display_path)

            item = ListItem(Static(full_display))
            item.path_data = path          # type: ignore[attr-defined]
            await lv.append(item)

    # ── Open ──────────────────────────────────────────────────────────────────

    def action_open_item(self) -> None:
        """Open highlighted item (bound to Enter)."""
        lv = self.query_one("#results_list", ListView)
        child = lv.highlighted_child
        if child and hasattr(child, "path_data"):
            open_path(child.path_data)

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        """Also opens on mouse double-click / Space."""
        if hasattr(event.item, "path_data"):
            open_path(event.item.path_data)

    # ── Stats on highlight ────────────────────────────────────────────────────

    def on_list_view_highlighted(self, event: ListView.Highlighted) -> None:
        if event.item and hasattr(event.item, "path_data"):
            self._show_item_stats(event.item.path_data)

    @work(thread=True)
    def _show_item_stats(self, path: str) -> None:
        try:
            if os.path.isdir(path):
                entries = list(os.scandir(path))
                f = sum(1 for e in entries if e.is_file())
                d = sum(1 for e in entries if e.is_dir())
                msg = f"( {f} files,  {d} folders )"
            else:
                size = os.path.getsize(path) / 1024
                msg = f"( {size:.1f} KB )"
            self.call_from_thread(
                self.query_one("#stats_label", Label).update, msg
            )
        except Exception:
            pass
