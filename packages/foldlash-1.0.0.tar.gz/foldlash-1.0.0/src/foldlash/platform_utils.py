"""Cross-platform helpers for foldlash."""

from __future__ import annotations

import os
import platform
import string
import subprocess
from typing import List

# ── Skip lists ───────────────────────────────────────────────────────────────
# Windows: skip pure-OS noise; keep user data (Documents, OneDrive, etc.)
_SKIP_WIN: frozenset[str] = frozenset({
    "Windows", "System32", "SysWOW64", "WinSxS",
    "$Recycle.Bin", "$WinREAgent",
    "System Volume Information",
    "ProgramData",           # mostly service data; remove if you want it
    "MSOCache",
})

# Unix: skip virtual/kernel filesystems
_SKIP_UNIX: frozenset[str] = frozenset({
    "proc", "sys", "dev", "run", "snap", "boot",
    "Volumes", "private", "cores", "tmp",
})


def get_scan_roots() -> List[str]:
    """
    Return every accessible drive root on Windows (C:\\, D:\\, …)
    or a single '/' on Unix/macOS.
    """
    if platform.system() == "Windows":
        roots = [
            f"{d}:\\"
            for d in string.ascii_uppercase
            if os.path.exists(f"{d}:\\")
        ]
        return roots or ["C:\\"]
    return ["/"]


def should_skip(name: str) -> bool:
    """Return True if this directory name should be skipped entirely."""
    if platform.system() == "Windows":
        return name in _SKIP_WIN
    # Unix: skip known virtual dirs and hidden dot-dirs
    return name in _SKIP_UNIX or name.startswith(".")


def open_path(path: str) -> None:
    """Open *path* with the system default application (cross-platform)."""
    try:
        sys_name = platform.system()
        if sys_name == "Windows":
            os.startfile(path)                          # type: ignore[attr-defined]
        elif sys_name == "Darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path])
    except Exception:
        pass
