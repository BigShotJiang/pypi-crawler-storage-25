import asyncio
import inspect
import json
import sys
import traceback
from typing import Any, AsyncGenerator, Callable, Dict, List, Literal, Optional, Union, TypeAlias
from fastapi.responses import StreamingResponse
from pie.card import Card
from pie.types import SocketIOEvent

try:
    from fastapi_socketio import SocketManager
    SocketManagerType: TypeAlias = SocketManager
except ImportError:
    print(
        "FastAPI socketio not installed. Emitting events is not available",
        file=sys.stderr,
    )
    SocketManagerType: TypeAlias = Any

try:
    from faststream.redis.fastapi import RedisBroker
    from redis.asyncio import StrictRedis

    RedisBrokerType: TypeAlias = RedisBroker
    StrictRedisType: TypeAlias = StrictRedis
except ImportError:
    print(
        "FastStream & redis not installed. Cache and Background processing are not available",
        file=sys.stderr,
    )
    RedisBrokerType: TypeAlias = Any
    StrictRedisType: TypeAlias = Any


class AsyncPage(object):
    """
    Base class for asynchronous pages.

    Provides methods for:
        - filling and parsing data
        - generating events
        - SocketIO or Centrifuge integration
        - caching via Redis
        - AJAX registration
    """

    def __init__(self, is_typed: bool = False) -> None:
        super(AsyncPage, self).__init__()
        """
        Initialize AsyncPage with default attributes.
        """
        self.is_typed: bool = is_typed
        self.global_data: Dict[str, Any] = {}
        self.ajax_post: Dict[str, Callable[..., Any]] = {}
        self.ajax_get: Dict[str, Callable[..., Any]] = {}
        self.io: Optional[SocketManagerType] = None
        self.broker: Optional[RedisBrokerType] = None
        self.cache: Optional[StrictRedisType] = None

    def get_possible_fields(self) -> Dict[str, Card]:
        return {
            name: value
            for name, value in inspect.getmembers(self)
            if not name.startswith("__") and isinstance(value, Card)
        }

    def get_io_cards(self) -> List[Card]:
        """
        Return all cards that support IO events (SocketIO or Centrifuge).

        Raises:
            NotImplementedError: If the page has no fields.

        Returns:
            List: IO-enabled cards.
        """
        if hasattr(self, "fields"):
            return self._get_io_cards(self.fields)
        raise NotImplementedError("In " + self.__class__.__name__)

    @staticmethod
    def _get_io_cards(fields: Card) -> List[Card]:
        """
        Helper to extract IO-enabled cards from a Card object.

        Args:
            fields: Card object.

        Returns:
            List: Cards supporting IO events.
        """
        return [
            card
            for card in fields.children()
            if hasattr(card, "name")
            and (
                (hasattr(card, "use_socketio_support") and card.use_socketio_support)
                or (
                    hasattr(card, "use_centrifuge_support")
                    and card.use_centrifuge_support
                )
            )
        ]

    async def get_content(self, **kwargs: Any):
        """
        Return filled content of the page.

        Raises:
            NotImplementedError: If the page has no fields.

        Returns:
            dict: Page content.
        """
        if hasattr(self, "fields"):
            return self.fill(self.fields, {})
        raise NotImplementedError()

    async def process(self, **data: Any):
        """
        Process form submission.

        Raises:
            NotImplementedError
        """
        raise NotImplementedError()

    @staticmethod
    def fill(
        fields: Card,
        data: Dict[str, Any],
        inplace: bool = False,
        generate: bool = True,
    ):
        """
        Fill a card or V1 fields with data.

        Args:
            fields: Card or legacy fields.
            data: Dictionary with input values.
            inplace: Modify fields in place.
            generate: Generate content after filling.
            hook: Optional function to run after filling fields.

        Returns:
            Generated content or modified fields.
        """
        return fields.fill(data, inplace=inplace, generate=generate)

    @staticmethod
    def parse(fields: Card,
              data: Dict[str, Any],
              strict: bool = True) -> Dict[str, Any]:
        """
        Parse input data into Card or legacy field structure.

        Args:
            fields: Card or legacy fields.
            data: Input dictionary.
            strict: Raise exceptions on invalid values.

        Returns:
            Parsed data dictionary.
        """
        return fields.parse_all(data)

    @staticmethod
    def redirect_url(to: Optional[str], **kwargs: Any) -> Optional[str]:
        """
        Build a redirect URL with optional query parameters.

        Args:
            to: Base URL.
            kwargs: Query parameters.

        Returns:
            str: Full redirect URL.
        """
        if to is None:
            return None
        if len(kwargs) == 0 or all([v is None for v in kwargs.values()]):
            return to
        params = "&".join([f"{k}={v}" for k, v in kwargs.items() if v is not None])

        if "?" in to:
            if to.endswith("&"):
                return f"{to}{params}"
            else:
                return f"{to}&{params}"
        else:
            return f"{to}?{params}"

    async def emit(
        self,
        event: Union[List[SocketIOEvent], SocketIOEvent],
        to: Optional[str] = None,
    ) -> None:
        """
        Emit SocketIO event(s) to connected clients.

        Args:
            event: Single or list of events.
            to: Target recipient or broadcast.
        """
        if self.io is None:
            raise RuntimeError("SocketIO and Centrifuge not supported!")

        if not isinstance(event, list):
            events = [event]
        else:
            events = event

        await asyncio.gather(*[self.io.emit(ev.name, ev.data, to=to)
                               for ev in events])

    async def reload(self, to: Optional[str] = None) -> None:
        """
        Trigger a page reload via SocketIO.

        Args:
            to: Target recipient or broadcast.
        """
        if self.io is None:
            raise RuntimeError("SocketIO not supported!")
        print("Reload: ")
        await self.io.emit("piereload", {}, to=to)

    def register_ajax(
        self,
        pathname: str,
        ajax_fn: Callable[..., Any],
        method: Literal["GET", "POST"] = "POST",
    ) -> str:
        """
        Register an AJAX endpoint.

        Args:
            pathname: URL path.
            ajax_fn: Handler function.
            method: HTTP method ("POST" or "GET").

        Returns:
            str: Pathname.
        """
        if method == "POST":
            self.ajax_post[pathname[1:]] = ajax_fn
        elif method == "GET":
            self.ajax_get[pathname[1:]] = ajax_fn
        return pathname

    @staticmethod
    def create_ajax_event_streaming(
        event_generator: AsyncGenerator[SocketIOEvent, None],
    ) -> StreamingResponse:
        """
        Wrap async generator as a streaming response.

        Args:
            event_generator: Async generator of SocketIO events.

        Returns:
            StreamingResponse: Streaming events to the client.
        """

        async def wrapped_generator() -> AsyncGenerator[str, None]:
            try:
                async for event in event_generator:
                    yield event.to_json() + "\n"
            except asyncio.CancelledError:
                print("Streaming cancelled by client", file=sys.stderr)
                raise
            except Exception:
                traceback.print_exc(file=sys.stderr)

        return StreamingResponse(wrapped_generator(), media_type="text/plain",
                                 headers={
                                     "Cache-Control": "no-cache",
                                     "X-Accel-Buffering": "no",
                                 })

    def lock(self, name: str, timeout: int = 120) -> Any:
        """
        Create a Redis lock.

        Args:
            name: Lock name.
            timeout: Lock timeout in seconds.

        Returns:
            Redis lock object.
        """
        if self.cache is None:
            raise RuntimeError("Lock not supported!")
        return self.cache.lock(f"lock:{name}", timeout=timeout)

    async def page_lock(self, name: str, timeout: int = 120) -> Any:
        """
        Create a page-scoped Redis lock.

        Args:
            name: Lock name.
            timeout: Lock timeout.

        Returns:
            Redis lock object.
        """
        return self.lock(f"{self.__class__.__name__}:{name}", timeout=timeout)

    async def save_value(
        self,
        scope: str,
        key: str,
        value: Any,
        encode: bool = False,
    ) -> Any:
        """
        Save a string value to Redis.

        Args:
            scope: Key prefix.
            key: Key name.
            value: Value to save (must be str).
            encode: JSON encode value.

        Returns:
            bool: Result of Redis set.
        """
        if not isinstance(value, str):
            raise TypeError("Value must be a string")
        if scope in ["lock"]:
            raise RuntimeError("scope must not be `lock`")
        if ":" in scope:
            raise RuntimeError("scope must not contain ':')")
        if encode:
            value = json.dumps(value)
        return await self.cache.set(f"{scope}:{key}", value)

    async def load_value(
        self,
        scope: str,
        key: str,
        decode: bool = False,
    ) -> Any:
        """
        Load a value from Redis.

        Args:
            scope: Key prefix.
            key: Key name.
            decode: JSON decode value.

        Returns:
            str or decoded object.
        """
        if scope in ["lock"]:
            raise RuntimeError("scope must not be `lock`")
        if ":" in scope:
            raise RuntimeError("scope must not contain ':')")
        value = await self.cache.get(f"{scope}:{key}")
        if decode:
            value = json.loads(value)
        return value

    def debug(self) -> None:
        """
        Run a development server for debugging the page.
        """
        from pie.fastweb import Web

        web = Web(
            {
                "": self,
            },
            use_socketio_support=True,
            enable_cors=True,
            disable_serving=True,
            serving_url="http://localhost:3000",
            cors_origins=["http://localhost:8008", "http://localhost:3000"],
        )
        web.run(host="localhost", port=8008, debug=False)
