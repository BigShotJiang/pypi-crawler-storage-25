from dataclasses import dataclass, field
from typing import Callable, List, Optional

from ..card import Card


@dataclass
class UnionCard(Card):
    """
    UnionCard provides a container for grouping multiple `Card` instances into a composite card,
    supplying a unifying structure identified by an optional `name` and style dictionary (`sx`).
    This class supports programmatic management of its child card collection and can be serialized
    for frontend rendering. The class is typically used to define composite UI elements where a set
    of cards are treated as a single logical entity.

    Dependencies:
        - `dataclasses`: For dataclass behavior, field defaults, and auto-generated methods.
        - `typing`: For type hints (`List`, `Optional`, `Callable`).
        - Base class `Card`: Inherits core card functionality, which must be defined elsewhere.

    Fields:
        fields (List[Card]):
            - Collection of child Card objects contained in this UnionCard.
            - Type: List of Card (required, never None).
            - Default: Empty list, via `default_factory`.
            - Can be dynamically modified using methods (insert, append, extend, filter, etc.).
            - Directly influences the content and children of the card as rendered in the frontend.

        name (Optional[str]):
            - Identifies this union card; can be used for referencing, titling, or mapping in frontend logic.
            - Type: Optional string.
            - Default: None (unnamed).
            - When set, included in the serialized data consumed by the frontend.

    Integration Notes:
        - The serialized output produced by `generate()` includes "card", "content" (children), and "data"
          (with `name`). These fields are consumed by frontend components to render the card.

    Example Usage:
        >>> from pie import UnionCard
        >>> from pie import HiddenCard
        >>> # Create simple child cards
        >>> card1 = HiddenCard(name="A")
        >>> card2 = HiddenCard(name="B")
        >>> # Instantiate a UnionCard with children, name, and custom style
        >>> union = UnionCard(fields=[card1, card2], name="MyUnion")
        >>> # Add another card dynamically
        >>> card3 = HiddenCard(name="C")
        >>> union.append(card3)
        >>> # Serialize for frontend
        >>> data = union.generate()

    """

    content: List[Card] = field(default_factory=lambda: [])

    name: Optional[str] = None

    def insert(self, i, f):
        self.content.insert(i, f)

    def append(self, f):
        self.content.append(f)

    def extend(self, fs):
        self.content.extend(fs)

    def filter(self, fn: Callable[[Card], bool]):
        self.content = list(filter(fn, self.content))

    def __getitem__(self, index):
        return self.content[index]

    def __setitem__(self, index, new_field):
        self.content[index] = new_field

    def children(self):
        return ([self] if self.name is not None else []) + sum(
            [f.children() for f in self.content], []
        )

    def clear(self):
        for f in self.content:
            f.clear()

    def __repr__(self):
        return "UnionCard([%s])" % ",\n".join([repr(f) for f in self.content])
