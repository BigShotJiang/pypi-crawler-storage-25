from dataclasses import dataclass
from typing import Optional

from dataclasses_json.core import Json

from ..card import Card


@dataclass
class IOLogCard(Card):
    name: str

    use_socketio_support: bool = False
    use_centrifuge_support: bool = False
    use_mitt_support: bool = False
    centrifuge_channel: Optional[str] = None

    def create_redirect_event(self, to=None):
        return self.create_event(
            "redirect",
            {
                "to": to,
            },
        )

    def create_log_event(self, data: Json):
        return self.create_event("log", data)

    def get_supported_events(self):
        return ["redirect", "log"]
