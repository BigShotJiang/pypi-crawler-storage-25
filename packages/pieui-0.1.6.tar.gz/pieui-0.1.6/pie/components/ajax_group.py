from dataclasses import dataclass, field
from typing import Literal, Optional
from ..card import Card


@dataclass
class AjaxGroupCard(Card):
    content: Card

    use_loader: bool = True
    no_return: bool = False
    return_type: Literal["content", "events"] = "content"
    name: str = ""

    use_socketio_support: bool = False
    use_centrifuge_support: bool = False
    use_mitt_support: bool = False
    centrifuge_channel: Optional[str] = None

    def children(self):
        return [self] + self.content.children()

    def create_change_content_event(self, new_content: Card):
        return self.create_event("changeContent", {
            "content": new_content.generate()
        })

    def get_supported_events(self):
        return ["changeContent"]
