from dataclasses import dataclass
from typing import Optional
from ..card import Card


@dataclass
class HTMLEmbedCard(Card):
    """
    Represents a UI card displaying arbitrary HTML content in the frontend.
    This card is consumed by frontend components to render embedded HTML within a styled card,
    and supports optional real-time updating via various event systems. All fields are utilized
    by the frontend to control the visual content and behavior of the card.
    ONLY SUPPORTS STATIC CONTENT.
    SUPPORTED TAGS: <p>,<div>,<span>,<h1>,<h2>,<h3>,<h4>,<h5>,<h6>,<ul>,<ol>,<li>,<a>,<b>,<i>,<strong>,<em>

    Attributes:
        name (str):
            A required identifier for the card instance. Generally used for tracking or referencing the card within the UI.
        html (str):
            Required HTML markup string to be rendered inside the card. This content will be parsed and embedded directly by the frontend.
        use_socketio_support (bool, default=False):
            Optional flag enabling support for receiving real-time updates via Socket.IO. If True,
            the frontend will connect to the appropriate Socket.IO channel to listen for "update" events that replace the displayed HTML.
        use_centrifuge_support (bool, default=False):
            Optional flag enabling Centrifuge-based real-time updates. When enabled, the frontend subscribes to a Centrifuge channel (as specified by `centrifuge_channel`) for event-driven content updates.
        use_mitt_support (bool, default=False):
            Optional flag enabling event bus updates over a Mitt-like event system. If set to True, the card listens for events via Mitt.
        centrifuge_channel (Optional[str], default=None):
            Optionally specifies the Centrifuge channel to subscribe to for updates. Required when `use_centrifuge_support` is True; ignored otherwise.

    Usage:
        The frontend consumes these fields to render the card, define its content, and configure
        real-time event update mechanisms. Real-time support flags (`use_socketio_support`, `use_centrifuge_support`, `use_mitt_support`)
        are mutually independent, enabling integration with multiple event sources as needed.

    Example:
        Instantiate an HTML embed card configured for Centrifuge real-time updates:

            card = HTMLEmbedCard(
                name="weather-widget",
                html="<div>Initial weather data</div>",
                use_centrifuge_support=True,
                centrifuge_channel="live.weather.updates"
            )

        For static embedded HTML content with no real-time updates:

            card = HTMLEmbedCard(
                name="help-section",
                html="<p>Welcome to the help page!</p>"
            )
    """

    name: str
    html: str

    use_socketio_support: bool = False
    use_centrifuge_support: bool = False
    use_mitt_support: bool = False
    centrifuge_channel: Optional[str] = None

    def create_update_event(self, value):
        return self.create_event("update", {"value": value})

    def get_supported_events(self):
        return ["update"]


def phtml(content, name=""):
    return HTMLEmbedCard(name, content)
