from dataclasses import dataclass
from typing import Dict
from ..card import Card


@dataclass
class OneOfCard(Card):
    fields: Dict[str, Card]
    variant: str

    def choose_variant(self, variant: str):
        self.variant = variant

    def __getitem__(self, variant: str) -> Card:
        return self.fields[variant]

    def __setitem__(self, variant, new_field):
        self.fields[variant] = new_field

    def generate(self):
        return self.fields[self.variant].generate()

    def children(self):
        return sum([f.children() for f in self.fields.values()], [])

    def clear(self):
        for f in self.fields.values():
            f.clear()
