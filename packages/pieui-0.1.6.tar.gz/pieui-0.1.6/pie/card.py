import asyncio
from copy import deepcopy
from dataclasses import is_dataclass, replace
import inspect
from typing import Any, ClassVar, Dict, List, Optional, Type, TypeVar
from adaptix import Retort
from dataclasses_json import DataClassJsonMixin, LetterCase, dataclass_json
from dataclasses_jsonschema import JsonSchemaMixin
from pie.types import SocketIOEvent


TCard = TypeVar("TCard", bound="Card")
TInputCard = TypeVar("TInputCard", bound="InputCard")


@dataclass_json(letter_case=LetterCase.CAMEL)
class Card(DataClassJsonMixin, JsonSchemaMixin):
    retort: ClassVar[Retort] = Retort()

    def generate(self) -> Dict[str, Any]:
        card_name = next((cls
                          for cls in self.__class__.__mro__
                          if "__dataclass_fields__" in cls.__dict__)).__name__
        data = self.to_dict()
        content = data.pop("content", None)
        generated = {"card": card_name, "data": data}
        if content is not None:
            generated["content"] = content
        return generated

    def diff(self, other: "Card") -> Any:
        import jsonpatch
        return jsonpatch.make_patch(self.generate(), other.generate())

    def apply_patch(self, patch: Any) -> Any:
        import jsonpatch
        return jsonpatch.apply_patch(self.generate(), patch)

    def children(self) -> List["Card"]:
        return [self]

    def clear(self) -> None:
        pass

    def fill(
        self,
        data: Dict[str, Any],
        inplace: bool = False,
        generate: bool = True,
    ) -> Any:
        if not inplace:
            fields = self.copy()
        else:
            fields = self

        child_mapping = fields.child_loc
        for key in data.keys():
            if key not in child_mapping:
                continue
            child_mapping[key].set_output(data[key])
        if generate:
            return fields.generate()
        return fields

    async def aparse_all(self, data: Dict[str, Any]) -> Dict[str, Any]:
        child_mapping = self.get_input_child_mapping()
        result = {}
        for k, v in data.items():
            if k not in child_mapping:
                continue
            result[k] = await child_mapping[k].aparse(data[k])
        return result

    def parse_all(self, data: Dict[str, Any]) -> Dict[str, Any]:
        child_mapping = self.input_child_loc
        result = {}
        for k, v in data.items():
            if k not in child_mapping:
                continue
            result[k] = child_mapping[k].parse(data[k])
        return result

    def set_output(self, data: Dict[str, Any]) -> None:
        for k, v in data.items():
            setattr(self, k, v)

    def get_child_mapping(self) -> Dict[str, TCard]:
        return {getattr(f, "name"): f for f in self.children() if hasattr(f, "name")}

    def get_child_type_mapping(self) -> Dict[Type["Card"], "Card"]:
        return {f.__class__: f for f in self.children()
                if self.is_custom_card_type(type(f))}

    def get_input_child_mapping(self) -> Dict[str, TInputCard]:
        return {
            getattr(f, "name"): f
            for f in self.children()
            if isinstance(f, InputCard) and hasattr(f, "name")
        }

    @property
    def child_loc(self) -> Dict[str | Type[TCard], TCard]:
        return self.get_child_mapping() | self.get_child_type_mapping()

    @property
    def input_child_loc(self) -> Dict[str, TInputCard]:
        return self.get_input_child_mapping()

    def get_child_by_name(self, name: str) -> Optional["Card"]:
        child_mapping = self.child_loc
        if name not in child_mapping:
            return None
        return child_mapping[name]

    def get_input_child_by_name(self, name: str) -> Optional[TCard]:
        child_mapping = self.input_child_loc
        if name not in child_mapping:
            return None
        return child_mapping[name]

    def copy(self) -> TCard:
        return deepcopy(self)

    def replaced(self, **kwargs: Any) -> TCard:
        if not is_dataclass(self):
            raise TypeError(
                f"{self.__class__.__name__} is not a dataclass, cannot call .replace()"
            )
        return replace(self, **kwargs)

    def get_supported_events(self) -> List[str]:
        return []

    def create_event(
        self,
        event_name: str,
        data: Optional[Dict[str, Any]] = None,
    ) -> SocketIOEvent:
        if data is None:
            data = {}

        if not hasattr(self, "name"):
            raise RuntimeError("Card don't have socketio support (missing name) !")

        has_socketio_support = (
            hasattr(self, "use_socketio_support") and self.use_socketio_support
        )
        has_centrifuge_support = (
            hasattr(self, "use_centrifuge_support") and self.use_centrifuge_support
        )
        has_mitt_support = hasattr(self, "use_mitt_support") and self.use_mitt_support

        if has_socketio_support or has_centrifuge_support or has_mitt_support:
            event = SocketIOEvent(f"pie{event_name}_{self.name}", data)
            return event

        raise RuntimeError(
            "Required socketio support (enable it by use_centrifuge_support, use_socketio_support, use_mitt_support) !"
        )

    @classmethod
    def is_custom_card_type(cls, card_type: Type["Card"]) -> bool:
        if not inspect.isclass(card_type):
            return False

        if not issubclass(card_type, Card):
            return False

        if is_dataclass(card_type.__mro__[1]):
            return True

        return False

    @staticmethod
    def redirect_url(to: Optional[str], **kwargs: Any) -> Optional[str]:
        if to is None:
            return None
        if len(kwargs) == 0 or all([v is None for v in kwargs.values()]):
            return to
        params = "&".join([f"{k}={v}" for k, v in kwargs.items() if v is not None])

        if "?" in to:
            if to.endswith("&"):
                return f"{to}{params}"
            else:
                return f"{to}&{params}"
        else:
            return f"{to}?{params}"

    def debug(self, use_socketio_support: bool = True) -> None:
        from pie.async_page import AsyncPage
        from pie.fastweb import Web

        class DebugPage(AsyncPage):
            def __init__(_self):
                super(DebugPage, _self).__init__()
                _self.fields = self

        web = Web(
            {
                "": DebugPage(),
            },
            use_socketio_support=use_socketio_support,
            enable_cors=True,
            disable_serving=True,
            serving_url="http://localhost:3000",
            cors_origins=["http://localhost:8008", "http://localhost:3000"],
        )
        web.run(host="localhost", port=8008, debug=False)


class InputCard(Card):
    def parse(self, data: Any) -> Any:
        return data

    async def aparse(self, data: Any) -> Any:
        return await asyncio.to_thread(self.parse,
                                       data)
