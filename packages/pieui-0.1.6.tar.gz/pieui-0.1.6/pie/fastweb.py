import hashlib
import inspect
import json
import logging
import os
import sys
from functools import wraps
import jwt
from .async_page import AsyncPage
from .types import get_rich_signature, FormParsingOptions, AggregationRuleType, _is_upload_file_type, form2dict

import time
import zipfile
from datetime import datetime
from typing import (
    Any,
    Awaitable,
    Dict,
    List,
    Optional,
    Callable
)

from fastapi import FastAPI, Request, Response, status, Depends, Form, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates


class Web(object):
    """
    Main class for a FastAPI-based web application integrating PieData AsyncPages.

    Handles:
        - Page registration and AJAX endpoints
        - SocketIO or Centrifuge real-time support
        - CORS and static file serving
        - Form submission and aggregation
        - Precompilation of page content
    """

    PIEBREAK = "__piedemo__"
    FORM_PARSING_OPTIONS: FormParsingOptions = {
        "max_files": 100000,
        "max_fields": 100000,
        "max_part_size": 1024 * 1024 * 100,  # 100 MB
    }

    def __init__(
        self,
        pages: Dict[str, Any],
        name: str = "PieDataWebDemo",
        aggregation_rule: AggregationRuleType = "by_underscore",
        assets_path: Optional[str] = None,
        enable_cors: bool = False,
        cookie_keys: Optional[List[str]] = None,
        cookie_options: Optional[Dict[str, Any]] = None,
        admin_subdomain: str = "/",
        cors_origins: Optional[List[str]] = None,
        use_socketio_support: bool = False,
        use_centrifuge_support: bool = False,
        centrifuge_url: Optional[str] = None,
        centrifuge_api_key: Optional[str] = None,
        centrifuge_hmac_secret: Optional[str] = None,
        centrifuge_sub_fn: Optional[Callable[[dict], str]] = None,
        disable_serving: bool = False,
        serving_url: Optional[str] = None,
        allow_ajax_duplicates: bool = False,
        error_logger: Optional[logging.Logger] = None,
        log_handler_errors: bool = True,
    ):
        """
        Initialize the Web application.

        Args:
            pages (Dict[str, Any]): Mapping of page paths to AsyncPage instances.
            name (str): Name of the web app.
            aggregation_rule (AggregationRuleType): Rule for aggregating form data.
            assets_path: Optional path for additional assets.
            enable_cors (bool): Enable CORS middleware.
            cookie_keys (List[str]): Keys to read from cookies.
            admin_subdomain (str): Prefix for admin routes.
            cors_origins (List[str]): Allowed CORS origins.
            use_socketio_support (bool): Enable SocketIO support.
            use_centrifuge_support (bool): Enable Centrifuge support.
            centrifuge_url (str): Centrifuge server URL.
            centrifuge_api_key (str): Centrifuge API key.
            centrifuge_hmac_secret (str): Secret for generating Centrifuge tokens.
            centrifuge_sub_fn (Callable): Function to generate subscriber ID.
            disable_serving (bool): Disable static file serving.
            serving_url (str): Base URL when serving is disabled.
            error_logger (logging.Logger): Logger to use for handler errors.
            log_handler_errors (bool): Enable logging of handler exceptions.
        """

        if not (admin_subdomain.endswith("/") and admin_subdomain.startswith("/")):
            raise RuntimeError("Admin subdomain must ends with /")
        self.admin_subdomain = admin_subdomain

        self.name: str = name
        self.pages: Dict[str, Any] = self._perform_redirects(pages)
        self.ajax_post: Dict[str, Any] = self._collect_ajax(
            pages,
            method="POST",
            allow_ajax_duplicates=allow_ajax_duplicates,
        )
        self.ajax_get: Dict[str, Any] = self._collect_ajax(
            pages,
            method="GET",
            allow_ajax_duplicates=allow_ajax_duplicates,
        )

        print("Registered Ajax:", file=sys.stderr)
        for ajax_key in self.ajax_post.keys():
            print(f"(POST) {ajax_key}", file=sys.stderr)

        for ajax_key in self.ajax_get.keys():
            print(f"(GET) {ajax_key}", file=sys.stderr)

        self.io_cards = self._collect_io_cards(pages)

        print("Registered IO events:", file=sys.stderr)
        names = set()
        for io_card in self.io_cards:
            if io_card.name in names:
                print(
                    f"WARNING: Duplicate IO card name: {io_card.name}; Page: {io_card.__page_name}",
                    file=sys.stderr,
                )
            names.add(io_card.name)
            for event_name in io_card.get_supported_events():
                print(f"(IO) pie{event_name}_{io_card.name}", file=sys.stderr)

        self.aggregation_rule: AggregationRuleType = aggregation_rule
        self.use_socketio_support: bool = use_socketio_support
        self.use_centrifuge_support: bool = use_centrifuge_support

        self.centrifuge_url: Optional[str] = centrifuge_url
        self.centrifuge_api_key: Optional[str] = centrifuge_api_key
        self.centrifuge_hmac_secret: Optional[str] = centrifuge_hmac_secret

        if self.use_centrifuge_support and self.use_socketio_support:
            raise RuntimeError("Use either Centrifuge or Socketio")

        # Validate per-card real-time flags: only one of socketio/centrifuge/mitt can be enabled
        # and centrifuge_channel must only be set when use_centrifuge_support is True.
        for page in self.pages.values():
            # Traverse declared cards if the page exposes a root `fields` card
            if hasattr(page, "fields") and hasattr(page.fields, "children"):
                for card in page.fields.children():
                    try:
                        name = getattr(card, "name", str(card))
                        use_sio = bool(getattr(card, "use_socketio_support", False))
                        use_centr = bool(getattr(card, "use_centrifuge_support", False))
                        use_mitt = bool(getattr(card, "use_mitt_support", False))
                        channel = getattr(card, "centrifuge_channel", None)

                        enabled_count = int(use_sio) + int(use_centr)
                        if enabled_count > 1:
                            raise RuntimeError(
                                f"Card '{name}' on page {page.__class__.__name__}: enable only ONE of "
                                f"use_socketio_support / use_centrifuge_support"
                            )

                        if channel is not None and not use_centr:
                            raise RuntimeError(
                                f"Card '{name}' on page {page.__class__.__name__}: centrifuge_channel "
                                f"can be set only when use_centrifuge_support=True"
                            )
                    except Exception as e:
                        # Re-raise to fail fast with clear message
                        raise

        if cookie_keys is None:
            cookie_keys = []
        self.cookie_keys: List[str] = cookie_keys

        if cookie_options is None:
            cookie_options = {"samesite": None}
        self.cookie_options: Dict[str, Any] = {"samesite": None} | cookie_options

        if centrifuge_sub_fn is None:

            def centrifuge_sub_fn_impl(cookies: dict) -> str:
                """Generates a unique user ID based on cookie values using a hash function."""
                cookie_string = json.dumps(cookies, sort_keys=True)
                return hashlib.sha256(cookie_string.encode()).hexdigest()

            centrifuge_sub_fn = centrifuge_sub_fn_impl
        self.centrifuge_sub_fn: Callable[[dict], str] = centrifuge_sub_fn

        if cors_origins is None:
            cors_origins = []
        self.cors_origins: List[str] = cors_origins

        self.enable_cors: bool = enable_cors
        self.assets_path: Optional[str] = assets_path
        if self.assets_path is not None:
            print(
                "Assets path: ",
                os.path.abspath(self.assets_path),
            )
        self.static_path = os.path.join(os.path.dirname(__file__), "build")
        if not disable_serving:
            self.download_static_files()

        self.storage: Dict[str, str] = {}
        self.disable_serving: bool = disable_serving
        self.serving_url: Optional[str] = serving_url
        if self.disable_serving and self.serving_url is None:
            print("ATTENTION, form submission will be disabled!")

        if error_logger is None:
            error_logger = logging.getLogger(__name__)
        self.error_logger: logging.Logger = error_logger
        self.log_handler_errors: bool = log_handler_errors

    def handle_cookies(self, **data: Any) -> Dict[str, Any]:
        return data

    def download_static_files(self) -> None:
        if not os.path.exists(self.static_path):
            from .hub.checkpoint import url_download_file

            cached_path = os.path.join(os.path.dirname(__file__))
            zip_path = os.path.join(cached_path, "static.zip")
            url_download_file(
                url="https://github.com/PieDataLabs/piedemo_frontend/releases/download/V2.0.6/static.zip",
                cached_path=zip_path,
            )
            with zipfile.ZipFile(zip_path) as zf:
                zf.extractall(cached_path)
            os.remove(zip_path)

    def add_assets_directory(self, storage_name: str, assets_path: str) -> None:
        self.storage[storage_name] = assets_path

    def run(
        self,
        host: str = "0.0.0.0",
        port: int = 8008,
        debug: bool = True,
        **options: Any,
    ) -> None:
        """
        Start the web server using Uvicorn.

        Args:
            host (str): Host to bind.
            port (int): Port to bind.
            debug (bool): Enable auto-reload.
            options: Additional uvicorn options.
        """
        import uvicorn

        app = self.get_app()

        if self.use_socketio_support:
            self.get_socketio(app)

        if self.use_centrifuge_support:
            self.get_centrifuge(app)

        uvicorn.run(app, host=host, port=port, reload=debug, **options)

    def add_endpoints(self, app: FastAPI) -> FastAPI:
        if self.use_centrifuge_support:

            @app.get("/api/centrifuge/gen_token")
            async def get_centrifuge_token(request: Request):
                sub = self.centrifuge_sub_fn(
                    {
                        cookie_key: cookie_value
                        for cookie_key, cookie_value in request.cookies.items()
                        if cookie_key in self.cookie_keys
                    }
                )
                token = jwt.encode(
                    {
                        "sub": sub,
                        "exp": int(time.time()) + 3600,  # Expiry time (1 hour from now)
                        "iat": int(time.time()),  # Issued at
                    },
                    self.centrifuge_hmac_secret,
                    algorithm="HS256",
                )
                return {"token": token}

        @app.get("/api/support/{name}", response_model=bool)
        async def check_support(name):
            if name.lower() == "socketio":
                return self.use_socketio_support
            if name.lower() == "centrifuge":
                return self.use_centrifuge_support
            return False

        for page_path, page in self.pages.items():
            route_path = (
                self.admin_subdomain
                + "api/content/"
                + self.admin_subdomain[1:]
                + page_path
            )
            app.get(route_path)(
                self.make_send_content(
                    page_path,
                    page,
                    self.cookie_keys,
                    aggregation_rule=self.aggregation_rule,
                    cookie_options=self.cookie_options,
                    error_logger=self.error_logger,
                    log_handler_errors=self.log_handler_errors,
                ) if not page.is_typed else self.make_send_content_typed(
                    page_path,
                    page,
                    self.cookie_keys,
                    aggregation_rule=self.aggregation_rule,
                    cookie_options=self.cookie_options,
                    error_logger=self.error_logger,
                    log_handler_errors=self.log_handler_errors,
                )
            )

        for ajax_post_path, post_handler in self.ajax_post.items():
            page = post_handler.__self__
            route_path = (
                self.admin_subdomain
                + "api/ajax_content/"
                + self.admin_subdomain[1:]
                + ajax_post_path
            )
            app.post(route_path)(
                self.make_send_ajax_post_content(
                    ajax_post_path,
                    page=page,
                    handler=post_handler,
                    aggregation_rule=self.aggregation_rule,
                    error_logger=self.error_logger,
                    log_handler_errors=self.log_handler_errors,
                ) if not page.is_typed else self.make_send_ajax_post_content_typed(
                    ajax_post_path,
                    page=page,
                    handler=post_handler,
                    aggregation_rule=self.aggregation_rule,
                    error_logger=self.error_logger,
                    log_handler_errors=self.log_handler_errors,
                )
            )

        for ajax_get_path, get_handler in self.ajax_get.items():
            page = get_handler.__self__
            route_path = (
                self.admin_subdomain
                + "api/ajax_content/"
                + self.admin_subdomain[1:]
                + ajax_get_path
            )
            app.get(route_path)(
                self.make_send_ajax_get_content(
                    ajax_get_path,
                    page=page,
                    handler=get_handler,
                    aggregation_rule=self.aggregation_rule,
                    error_logger=self.error_logger,
                    log_handler_errors=self.log_handler_errors,
                ) if not page.is_typed else self.make_send_ajax_get_content_typed(
                    ajax_get_path,
                    page=page,
                    handler=get_handler,
                    aggregation_rule=self.aggregation_rule,
                    error_logger=self.error_logger,
                    log_handler_errors=self.log_handler_errors,
                )
            )

        for page_path, page in self.pages.items():
            route_path = (
                self.admin_subdomain
                + "api/process/"
                + self.admin_subdomain[1:]
                + page_path
            )
            app.post(route_path)(
                self.make_process_page_form(
                    page_path,
                    page,
                    aggregation_rule=self.aggregation_rule,
                    admin_subdomain=self.admin_subdomain,
                    disable_serving=self.disable_serving,
                    serving_url=self.serving_url,
                    error_logger=self.error_logger,
                    log_handler_errors=self.log_handler_errors,
                ) if not page.is_typed else self.make_process_page_form_typed(
                    page_path,
                    page,
                    aggregation_rule=self.aggregation_rule,
                    admin_subdomain=self.admin_subdomain,
                    disable_serving=self.disable_serving,
                    serving_url=self.serving_url,
                    error_logger=self.error_logger,
                    log_handler_errors=self.log_handler_errors,
                )
            )

        return app

    def get_app(self, **app_kwgs: Any) -> FastAPI:
        """
        Build the FastAPI app with endpoints and optional static serving.

        Returns:
            FastAPI: Configured FastAPI app.
        """

        app = app_kwgs.pop("app", None)
        if app is None:
            app = FastAPI(**app_kwgs)

        if self.enable_cors:
            app.add_middleware(
                CORSMiddleware,
                allow_origins=self.cors_origins,
                allow_credentials=True,
                allow_methods=["*"],
                allow_headers=["*"],
                expose_headers=["Set-Cookie"],
            )

        self.add_endpoints(app)
        if not self.disable_serving:
            for folder in os.listdir(self.static_path):
                if os.path.isdir(os.path.join(self.static_path, folder)):
                    app.mount(
                        f"{self.admin_subdomain}{folder}/",
                        StaticFiles(directory=os.path.join(self.static_path, folder)),
                        name=f"Static for {folder}",
                    )

            templates = Jinja2Templates(directory=self.static_path)

            @app.get(self.admin_subdomain + "{full_path:path}")
            async def serve_react_app(request: Request, full_path: str):
                return templates.TemplateResponse("index.html", {"request": request})

        return app

    def get_centrifuge(self, app: FastAPI) -> Any:
        """
        Setup Centrifuge async client.

        Args:
            app (FastAPI): FastAPI app.

        Returns:
            AsyncClient: Wrapped Centrifuge async client.
        """
        from pie.hub.centrifuge_helpers.cent_client_wrapper import SIOLikeWrapper
        from pie.hub.centrifuge_helpers.session_wrapper import LazyClientSession
        from cent import AsyncClient

        if self.centrifuge_api_key is None or self.centrifuge_url is None:
            raise RuntimeError(
                "Centrifuge is not configured properly."
            )

        _cio = AsyncClient(
            self.centrifuge_url,
            api_key=self.centrifuge_api_key,
            timeout=None,
            session=LazyClientSession(),
        )
        _cio = SIOLikeWrapper(_cio)
        self.setup_cio(_cio)
        return _cio

    def get_socketio(
        self,
        app: FastAPI,
        async_mode: str = "asgi",
        engineio_logger: bool = True,
        **kwargs: Any,
    ):
        """
        Setup SocketIO server for real-time communication.

        Args:
            app (FastAPI): FastAPI instance.
            async_mode (str): SocketIO async mode.
            engineio_logger (bool): Enable engineio logging.
            kwargs: Additional SocketIO server options.

        Returns:
            socketio.AsyncServer: Configured SocketIO server.
        """

        import socketio

        kwargs.update(
            async_mode=async_mode,
            engineio_logger=engineio_logger,
            cors_allowed_origins=[],
        )

        _sio = socketio.AsyncServer(**kwargs)
        _app = socketio.ASGIApp(
            socketio_server=_sio,
            socketio_path="socket.io",
        )
        app.mount("/", _app)
        app.sio = _sio
        self.setup_sio(_sio)
        return _sio

    def setup_broker(self, broker: Any) -> None:
        for page in self.pages.values():
            page.broker = broker

    def setup_cache(self, cache: Any) -> None:
        for page in self.pages.values():
            page.cache = cache

    def setup_sio(self, io: Any) -> None:
        """
        Setup IO event handlers for SocketIO server.

        Args:
            io: SocketIO server instance.
        """

        for page in self.pages.values():
            page.io = io

        @io.on("connect")
        async def ws_connect(sid, *args, **kwargs):
            t = datetime.now().strftime("[%Y/%m/%D %H:%M:%S]")

            # print(f"{t} Connected {sid}", file=sys.stderr)
            await io.emit("pieinit", {"sid": sid})

        @io.on("disconnect")
        async def ws_disconnect(sid, *args, **kwargs):
            # t = datetime.now().strftime("[%Y/%m/%D %H:%M:%S]")
            # print(f"{t} Disconnected {sid}", file=sys.stderr)
            pass

    def setup_cio(self, io: Any) -> None:
        """
        Setup IO instance for Centrifuge.

        Args:
            io: Centrifuge client instance.
        """
        for page in self.pages.values():
            page.io = io

    @staticmethod
    def _perform_redirects(pages: Dict[str, Any]) -> Dict[str, Any]:
        for key in list(pages.keys()):
            if isinstance(pages[key], str):
                pages[key] = pages[pages[key]]
        return pages

    @staticmethod
    def _collect_ajax(
        pages: Dict[str, Any],
        method: str = "POST",
        allow_ajax_duplicates: bool = False,
    ) -> Dict[str, Any]:
        """
        Collect AJAX handlers from all pages.

        Args:
            pages (dict): Pages dictionary.
            method (str): HTTP method ("POST" or "GET").

        Returns:
            dict: Aggregated AJAX handlers.
        """
        ajax = {}
        for page in pages.values():
            page_ajax = page.ajax_post if method == "POST" else page.ajax_get
            if not allow_ajax_duplicates:
                if ajax.keys() & page_ajax.keys():
                    raise ValueError(
                        f"Duplicate AJAX members found: {ajax.keys() & page_ajax.keys()}"
                    )
            ajax.update(page_ajax)
        return ajax

    @staticmethod
    def _collect_io_cards(pages: Dict[str, Any]) -> List[Any]:
        cards = []
        for page in pages.values():
            for card in page.get_io_cards():
                card = card.copy()
                card.__page_name = page.__class__.__name__
                cards.append(card)
        return cards

    @classmethod
    def make_send_content(
        cls,
        page_path: str,
        page: AsyncPage,
        cookie_keys: List[str],
        aggregation_rule: AggregationRuleType = None,
        cookie_options: Optional[Dict[str, Any]] = None,
        error_logger: Optional[logging.Logger] = None,
        log_handler_errors: bool = True,
    ):
        """
        Create an async function to send page content.

        Args:
            page_path (str): Page path.
            page: AsyncPage instance.
            cookie_keys (List[str]): Keys to extract from cookies.
            aggregation_rule (AggregationRuleType): Aggregation rule.
            cookie_options (Dict): Cookie options.

        Returns:
            Callable: Async function to be used as endpoint.
        """
        if cookie_options is None:
            cookie_options = {}


        route_name = f"send_content__{page_path.replace('/', '_')}"

        async def send_content(request: Request, response: Response):
            data = {k: v for k, v in request.cookies.items() if k in cookie_keys}
            data.update(request.query_params)

            try:
                content = await page.get_content(**data)
            except Exception:
                if log_handler_errors and error_logger is not None:
                    error_logger.exception(
                        "GET content error: path=%s page=%s",
                        page_path,
                        page.__class__.__name__,
                    )
                raise

            for key in cookie_keys:
                if key in data:
                    response.set_cookie(key=key, value=data[key],
                                        **cookie_options)
            return content

        send_content.__name__ = route_name
        return send_content

    @classmethod
    def make_send_content_typed(
        cls,
        page_path: str,
        page: AsyncPage,  # instance
        cookie_keys: list[str],
        aggregation_rule: AggregationRuleType = None,
        cookie_options: Optional[Dict[str, Any]] = None,
        error_logger: Optional[logging.Logger] = None,
        log_handler_errors: bool = True,
    ):
        route_name = f"send_content_typed__{page_path.replace('/', '_')}"
        public_sig, has_request, has_response = get_rich_signature(page.get_content)
        if cookie_options is None:
            cookie_options = {}

        @wraps(page.get_content)
        async def send_content_typed(**kwargs):
            response: Response = kwargs["response"]

            if not has_request:
                kwargs.pop("request")
            if not has_response:
                kwargs.pop("response")

            try:
                result = await page.get_content(**kwargs)
            except Exception:
                if log_handler_errors and error_logger is not None:
                    error_logger.exception(
                        "GET content error: path=%s page=%s",
                        page_path,
                        page.__class__.__name__,
                    )
                raise

            for key in cookie_keys:
                value = kwargs.get(key)
                if value is not None:
                    response.set_cookie(
                        key=key,
                        value=value,
                        **cookie_options
                    )

            return result

        send_content_typed.__signature__ = public_sig
        send_content_typed.__name__ = route_name
        return send_content_typed

    @classmethod
    def make_send_compiled_events(
        cls,
        page_path: str,
        page: AsyncPage,
        cookie_keys: List[str],
        aggregation_rule: AggregationRuleType = None,
        cookie_options: Optional[Dict[str, Any]] = None,
        error_logger: Optional[logging.Logger] = None,
        log_handler_errors: bool = True,
    ):
        """
        Create an async function to send compiled page events.

        Args:
            page_path (str): Page path.
            page: AsyncPage instance.
            cookie_keys (List[str]): Cookie keys.
            aggregation_rule (AggregationRuleType): Aggregation rule.

        Returns:
            Callable: Async function for endpoint.
        """
        if cookie_options is None:
            cookie_options = {}

        route_name = f"send_compiled_events__{page_path.replace('/', '_')}"

        async def send_compiled_events(request: Request, response: Response):
            data = {k: v for k, v in request.cookies.items() if k in cookie_keys}
            data.update(request.query_params)

            try:
                content = await page.get_compiled_events(**data)
            except Exception:
                if log_handler_errors and error_logger is not None:
                    error_logger.exception(
                        "GET compiled events error: path=%s page=%s",
                        page_path,
                        page.__class__.__name__,
                    )
                raise

            for key in cookie_keys:
                if key in data:
                    response.set_cookie(key=key, value=data[key],
                                        **cookie_options)
            return content

        send_compiled_events.__name__ = route_name
        return send_compiled_events

    @classmethod
    def make_send_compiled_events_typed(
        cls,
        page_path: str,
        page: AsyncPage,
        cookie_keys: List[str],
        aggregation_rule: AggregationRuleType = None,
        cookie_options: Optional[Dict[str, Any]] = None,
        error_logger: Optional[logging.Logger] = None,
        log_handler_errors: bool = True,
    ):
        """
        Create an async function to send compiled page events.

        Args:
            page_path (str): Page path.
            page: AsyncPage instance.
            cookie_keys (List[str]): Cookie keys.
            aggregation_rule (AggregationRuleType): Aggregation rule.

        Returns:
            Callable: Async function for endpoint.
        """
        if cookie_options is None:
            cookie_options = {}

        route_name = f"send_compiled_events_typed__{page_path.replace('/', '_')}"

        public_sig, has_request, has_response = get_rich_signature(page.get_compiled_events)

        @wraps(page.get_compiled_events)
        async def send_compiled_events_typed(**kwargs):
            response: Response = kwargs["response"]

            if not has_request:
                kwargs.pop("request")
            if not has_response:
                kwargs.pop("response")

            try:
                content = await page.get_compiled_events(**kwargs)
            except Exception:
                if log_handler_errors and error_logger is not None:
                    error_logger.exception(
                        "GET compiled events error: path=%s page=%s",
                        page_path,
                        page.__class__.__name__,
                    )
                raise

            for key in cookie_keys:
                value = kwargs.get(key)
                if value is not None:
                    response.set_cookie(
                        key=key,
                        value=value,
                        **cookie_options,
                    )
            return content

        send_compiled_events_typed.__name__ = route_name
        send_compiled_events_typed.__signature__ = public_sig
        return send_compiled_events_typed

    @classmethod
    def make_send_ajax_post_content(
        cls,
        ajax_post_path: str,
        page: AsyncPage,
        handler: Callable[..., Awaitable[Any]],
        aggregation_rule: AggregationRuleType = None,
        error_logger: Optional[logging.Logger] = None,
        log_handler_errors: bool = True,
    ):
        route_name = f"send_ajax_post_content__{ajax_post_path.replace('/', '_')}"

        async def send_ajax_post_content(request: Request, response: Response):
            data: Dict[str, Any] = {}
            form_data = await request.form(**cls.FORM_PARSING_OPTIONS)
            data.update(form2dict(form_data))
            data = cls.aggregate(data, aggregation_rule=aggregation_rule)
            try:
                content = await handler(**data)
            except Exception:
                if log_handler_errors and error_logger is not None:
                    error_logger.exception(
                        "Ajax POST handler error: path=%s page=%s handler=%s",
                        ajax_post_path,
                        page.__class__.__name__,
                        getattr(handler, "__name__", repr(handler)),
                    )
                raise
            return content

        send_ajax_post_content.__name__ = route_name
        return send_ajax_post_content

    @classmethod
    def make_send_ajax_post_content_typed(
        cls,
        ajax_post_path: str,
        page: AsyncPage,
        handler: Callable[..., Awaitable[Any]],
        aggregation_rule: AggregationRuleType = None,
        error_logger: Optional[logging.Logger] = None,
        log_handler_errors: bool = True,
    ):
        route_name = f"send_ajax_post_content_typed__{ajax_post_path.replace('/', '_')}"

        process_sig = inspect.signature(handler)
        new_params = []

        # --- build parsers for every param ---
        for param in process_sig.parameters.values():
            if param.name == "self":
                continue

            if param.kind is inspect.Parameter.VAR_KEYWORD:
                continue

            if param.kind is inspect.Parameter.VAR_POSITIONAL:
                raise RuntimeError("Process function cannot have *args parameters.")

            if param.name not in page.fields.child_loc:
                new_params.append(inspect.Parameter(
                    name=param.name,
                    kind=inspect.Parameter.POSITIONAL_OR_KEYWORD,
                    default=Form(param.default),
                    annotation=param.annotation,
                ))
                continue

            param_card = page.fields.child_loc[param.name]

            def make_parser(card, field_name: str):
                sig = inspect.signature(card.parse)
                params = list(sig.parameters.values())
                data_param = params[0]

                data_type = (
                    data_param.annotation
                    if data_param.annotation is not inspect.Parameter.empty
                    else Any
                )

                return_type = (
                    sig.return_annotation
                    if sig.return_annotation is not inspect.Signature.empty
                    else Any
                )

                if _is_upload_file_type(data_type):
                    param = inspect.Parameter(
                        name=field_name,
                        kind=inspect.Parameter.KEYWORD_ONLY,
                        default=File(...),
                        annotation=data_type,
                    )
                else:
                    param = inspect.Parameter(
                        name=field_name,
                        kind=inspect.Parameter.POSITIONAL_OR_KEYWORD,
                        default=Form(...),
                        annotation=data_type,
                    )

                async def parse_param(**kwargs):
                    return card.parse(kwargs[field_name])

                parse_param.__signature__ = inspect.Signature(
                    parameters=[param],
                    return_annotation=return_type,
                )

                return parse_param

            parser = make_parser(param_card, field_name=param.name)
            parser.__name__ = f"parse_{param.name}"

            new_params.append(
                inspect.Parameter(
                    name=param.name,
                    kind=inspect.Parameter.POSITIONAL_OR_KEYWORD,
                    default=Depends(parser),
                    annotation=param.annotation,
                )
            )

        has_response = any(p.annotation is Response for p in new_params)
        if not has_response:
            new_params.insert(
                0,
                inspect.Parameter(
                    "response",
                    inspect.Parameter.POSITIONAL_OR_KEYWORD,
                    annotation=Response,
                ),
            )

        has_request = any(p.annotation is Request for p in new_params)
        if not has_request:
            new_params.insert(
                0,
                inspect.Parameter(
                    "request",
                    inspect.Parameter.POSITIONAL_OR_KEYWORD,
                    annotation=Request,
                ),
            )

        public_signature = inspect.Signature(
            parameters=new_params,
            return_annotation=process_sig.return_annotation,
        )

        async def send_ajax_post_content_typed(**data):
            if not has_request:
                data.pop("request")
            if not has_response:
                data.pop("response")

            try:
                content = await handler(**data)
            except Exception:
                if log_handler_errors and error_logger is not None:
                    error_logger.exception(
                        "Ajax POST handler error: path=%s page=%s handler=%s",
                        ajax_post_path,
                        page.__class__.__name__,
                        getattr(handler, "__name__", repr(handler)),
                    )
                raise
            return content

        send_ajax_post_content_typed.__name__ = route_name
        send_ajax_post_content_typed.__signature__ = public_signature
        return send_ajax_post_content_typed

    @classmethod
    def make_send_ajax_get_content(
        cls,
        ajax_get_path: str,
        page: AsyncPage,
        handler: Callable[..., Awaitable[Any]],
        aggregation_rule: AggregationRuleType = None,
        error_logger: Optional[logging.Logger] = None,
        log_handler_errors: bool = True,
    ):
        route_name = f"send_ajax_get_content__{ajax_get_path.replace('/', '_')}"

        async def send_ajax_get_content(request: Request, response: Response):
            data: Dict[str, Any] = {}
            data.update(dict(request.query_params))
            data = cls.aggregate(data, aggregation_rule=aggregation_rule)
            try:
                content = await handler(**data)
            except Exception:
                if log_handler_errors and error_logger is not None:
                    error_logger.exception(
                        "Ajax GET handler error: path=%s page=%s handler=%s",
                        ajax_get_path,
                        page.__class__.__name__,
                        getattr(handler, "__name__", repr(handler)),
                    )
                raise
            return content

        send_ajax_get_content.__name__ = route_name
        return send_ajax_get_content

    @classmethod
    def make_send_ajax_get_content_typed(
        cls,
        ajax_get_path: str,
        page: AsyncPage,
        handler: Callable[..., Awaitable[Any]],
        aggregation_rule: AggregationRuleType = None,
        error_logger: Optional[logging.Logger] = None,
        log_handler_errors: bool = True,
    ):
        route_name = f"send_ajax_get_content_typed__{ajax_get_path.replace('/', '_')}"
        public_sig, has_request, has_response = get_rich_signature(handler)

        @wraps(handler)
        async def send_ajax_get_content_typed(**kwargs):
            if not has_request:
                kwargs.pop("request")
            if not has_response:
                kwargs.pop("response")
            try:
                content = await handler(**kwargs)
            except Exception:
                if log_handler_errors and error_logger is not None:
                    error_logger.exception(
                        "Ajax GET handler error: path=%s page=%s handler=%s",
                        ajax_get_path,
                        page.__class__.__name__,
                        getattr(handler, "__name__", repr(handler)),
                    )
                raise
            return content

        send_ajax_get_content_typed.__name__ = route_name
        send_ajax_get_content_typed.__signature__ = public_sig
        return send_ajax_get_content_typed

    @classmethod
    def make_process_page_form(
        cls,
        page_path: str,
        page: AsyncPage,
        aggregation_rule: AggregationRuleType = None,
        admin_subdomain: str = "/",
        disable_serving: bool = True,
        serving_url: Optional[str] = None,
        error_logger: Optional[logging.Logger] = None,
        log_handler_errors: bool = True,
    ):
        async def process_page_form(request: Request):
            data: Dict[str, Any] = {}
            form_data = await request.form(**cls.FORM_PARSING_OPTIONS)
            data.update(form2dict(form_data))
            data = cls.aggregate(data, aggregation_rule=aggregation_rule)

            try:
                redirect_url = await page.process(**data)
            except Exception:
                if log_handler_errors and error_logger is not None:
                    error_logger.exception(
                        "Form process error: path=%s page=%s handler=%s",
                        page_path,
                        page.__class__.__name__,
                        getattr(page.process, "__name__", "process"),
                    )
                raise
            if isinstance(redirect_url, Response):
                return redirect_url

            if redirect_url.startswith("/"):
                redirect_url = admin_subdomain + redirect_url[1:]
                if disable_serving:

                    def try_get_referrer():
                        url = request.headers.get("Referer", "")
                        if url.endswith("/"):
                            url = url[:-1]
                        return url

                    redirect_url = (
                        serving_url if serving_url is not None else try_get_referrer()
                    ) + redirect_url

            # print("Redirected to:", redirect_url)
            return RedirectResponse(
                redirect_url,
                status_code=status.HTTP_303_SEE_OTHER,
            )

        process_page_form.__name__ = f"process_page_form__{page_path.replace('/', '_')}"
        return process_page_form

    @classmethod
    def make_process_page_form_typed(
        cls,
        page_path: str,
        page: AsyncPage,
        aggregation_rule: AggregationRuleType = None,
        admin_subdomain: str = "/",
        disable_serving: bool = True,
        serving_url: Optional[str] = None,
        error_logger: Optional[logging.Logger] = None,
        log_handler_errors: bool = True,
    ):
        process_sig = inspect.signature(page.process)
        new_params = []

        # --- build parsers for every param ---
        for param in process_sig.parameters.values():
            if param.name == "self":
                continue

            if param.kind is inspect.Parameter.VAR_KEYWORD:
                continue

            if param.kind is inspect.Parameter.VAR_POSITIONAL:
                raise RuntimeError("Ajax function cannot have *args parameters.")

            if param.name not in page.fields.child_loc:
                new_params.append(param)
                continue

            param_card = page.fields.child_loc[param.name]

            def make_parser(card, field_name: str):
                sig = inspect.signature(card.parse)
                params = list(sig.parameters.values())
                data_param = params[0]

                data_type = (
                    data_param.annotation
                    if data_param.annotation is not inspect.Parameter.empty
                    else Any
                )

                return_type = (
                    sig.return_annotation
                    if sig.return_annotation is not inspect.Signature.empty
                    else Any
                )

                if _is_upload_file_type(data_type):
                    param = inspect.Parameter(
                        name=field_name,
                        kind=inspect.Parameter.KEYWORD_ONLY,
                        default=File(...),
                        annotation=data_type,
                    )
                else:
                    param = inspect.Parameter(
                        name=field_name,
                        kind=inspect.Parameter.POSITIONAL_OR_KEYWORD,
                        default=Form(...),
                        annotation=data_type,
                    )



                async def parse_param(**kwargs):
                    return card.parse(kwargs[field_name])

                parse_param.__signature__ = inspect.Signature(
                    parameters=[param],
                    return_annotation=return_type,
                )

                return parse_param

            parser = make_parser(param_card, field_name=param.name)
            parser.__name__ = f"parse_{param.name}"

            new_params.append(
                inspect.Parameter(
                    name=param.name,
                    kind=inspect.Parameter.POSITIONAL_OR_KEYWORD,
                    default=Depends(parser),
                    annotation=param.annotation,
                )
            )

        has_response = any(p.annotation is Response for p in new_params)
        if not has_response:
            new_params.insert(
                0,
                inspect.Parameter(
                    "response",
                    inspect.Parameter.POSITIONAL_OR_KEYWORD,
                    annotation=Response,
                ),
            )

        has_request = any(p.annotation is Request for p in new_params)
        if not has_request:
            new_params.insert(
                0,
                inspect.Parameter(
                    "request",
                    inspect.Parameter.POSITIONAL_OR_KEYWORD,
                    annotation=Request,
                ),
            )

        public_signature = inspect.Signature(
            parameters=new_params,
            return_annotation=process_sig.return_annotation,
        )

        # --- endpoint ---
        async def process_page_form(**data):
            request: Request = data["request"]

            if not has_request:
                data.pop("request")
            if not has_response:
                data.pop("response")

            try:
                redirect_url = await page.process(**data)
            except Exception:
                if log_handler_errors and error_logger is not None:
                    error_logger.exception(
                        "Form process error: path=%s page=%s handler=%s",
                        page_path,
                        page.__class__.__name__,
                        getattr(page.process, "__name__", "process"),
                    )
                raise

            if isinstance(redirect_url, Response):
                return redirect_url

            if redirect_url.startswith("/"):
                redirect_url = admin_subdomain + redirect_url[1:]
                if disable_serving:

                    def try_get_referrer():
                        url = request.headers.get("Referer", "")
                        if url.endswith("/"):
                            url = url[:-1]
                        return url

                    redirect_url = (serving_url if serving_url is not None else try_get_referrer()) + redirect_url

            return RedirectResponse(
                redirect_url,
                status_code=status.HTTP_303_SEE_OTHER,
            )

        process_page_form.__name__ = (
            f"process_page_form__{page_path.replace('/', '_')}"
        )
        process_page_form.__signature__ = public_signature
        return process_page_form

    @classmethod
    def aggregate(
        cls,
        data: Dict[str, Any],
        aggregation_rule: AggregationRuleType = None,
    ) -> Dict[str, Any]:
        if aggregation_rule is None:
            return data

        if aggregation_rule == "by_underscore":
            new_data = {}
            for key, value in data.items():
                if cls.PIEBREAK not in key:
                    if key in new_data:
                        if isinstance(new_data[key], dict):
                            new_data[key]["__value"] = value
                    else:
                        new_data[key] = value

                else:
                    root, sub = key.split(cls.PIEBREAK, 1)
                    if root not in new_data or not isinstance(new_data[root], dict):
                        old_value = new_data.get(root)
                        new_data[root] = {"__value": old_value}
                    new_data[root][sub] = value

            return new_data

        raise NotImplementedError()
