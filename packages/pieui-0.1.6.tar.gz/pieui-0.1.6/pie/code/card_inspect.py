"""Inspect card source and declared IO events."""

from __future__ import annotations

import ast
import sys
from pathlib import Path

from pie.code.card_add import class_filename, normalize_class_name
from pie.config import get_settings

_AJAX_FIELD_NAMES = frozenset({"pathname", "deps_names", "kwargs"})
_IO_SUPPORT_SUFFIX = "_support"
_FUNC_DEF_TYPES = (ast.FunctionDef, ast.AsyncFunctionDef)


def _card_file_path(card_name: str) -> Path:
    class_name = normalize_class_name(card_name)
    settings = get_settings()
    return (settings.components_dir / class_filename(class_name)).resolve()


def _find_card_class(tree: ast.AST, class_name: str) -> ast.ClassDef | None:
    for node in tree.body:
        if isinstance(node, ast.ClassDef) and node.name == class_name:
            return node
    return None


def _parse_dataclass_props(class_node: ast.ClassDef) -> list[tuple[str, str, str | None]]:
    """Return (name, type source, default source or None if required)."""
    rows: list[tuple[str, str, str | None]] = []
    for item in class_node.body:
        if not isinstance(item, ast.AnnAssign):
            continue
        target = item.target
        if not isinstance(target, ast.Name):
            continue
        name = target.id
        type_src = ast.unparse(item.annotation) if item.annotation else ""
        if item.value is None:
            rows.append((name, type_src, None))
        else:
            rows.append((name, type_src, ast.unparse(item.value)))
    return rows


def _card_has_ajax(field_names: set[str]) -> bool:
    return _AJAX_FIELD_NAMES.issubset(field_names)


def _io_support_field_names(field_names: set[str]) -> list[str]:
    return sorted(
        n
        for n in field_names
        if n.startswith("use_") and n.endswith(_IO_SUPPORT_SUFFIX)
    )


def _find_create_event_method(
    class_node: ast.ClassDef, event: str
) -> ast.FunctionDef | ast.AsyncFunctionDef | None:
    name = f"create_{event}_event"
    for item in class_node.body:
        if isinstance(item, _FUNC_DEF_TYPES) and item.name == name:
            return item
    return None


def _parse_factory_params(func: ast.FunctionDef | ast.AsyncFunctionDef) -> list[tuple[str, str, str | None]]:
    """After self/cls: (param name, type source, default source or None if required)."""
    a = func.args
    rows: list[tuple[str, str, str | None]] = []

    def emit_arg(arg: ast.arg, default: ast.expr | None) -> None:
        typ = ast.unparse(arg.annotation) if arg.annotation else ""
        if default is None:
            rows.append((arg.arg, typ, None))
        else:
            rows.append((arg.arg, typ, ast.unparse(default)))

    pos_kw = list(a.posonlyargs) + list(a.args)
    n = len(pos_kw)
    n_defaults = len(a.defaults)
    first_default_i = n - n_defaults

    for i, arg in enumerate(pos_kw):
        if i == 0 and arg.arg in ("self", "cls"):
            continue
        di = i - first_default_i
        default_node = a.defaults[di] if di >= 0 else None
        emit_arg(arg, default_node)

    if a.vararg is not None:
        va = a.vararg
        typ = ast.unparse(va.annotation) if va.annotation else ""
        rows.append((f"*{va.arg}", typ, None))

    for j, arg in enumerate(a.kwonlyargs):
        emit_arg(arg, a.kw_defaults[j])

    if a.kwarg is not None:
        ka = a.kwarg
        typ = ast.unparse(ka.annotation) if ka.annotation else ""
        rows.append((f"**{ka.arg}", typ, None))

    return rows


def _event_table_rows(class_node: ast.ClassDef, events: list[str]) -> list[list[str]]:
    rows: list[list[str]] = []
    for ev in events:
        method = _find_create_event_method(class_node, ev)
        if method is None:
            rows.append([ev, "—", "—", f"(no create_{ev}_event)"])
            continue
        params = _parse_factory_params(method)
        if not params:
            rows.append([ev, "—", "—", "(no args)"])
            continue
        for name, typ, default in params:
            default_cell = "(required)" if default is None else default
            rows.append([ev, name, typ, default_cell])
    return rows


def _ascii_table(headers: list[str], rows: list[list[str]]) -> str:
    """Plain ASCII table (no Markdown)."""
    n = len(headers)
    for row in rows:
        if len(row) != n:
            raise ValueError("row width mismatch")
    data = [headers] + rows
    widths = [max(len(data[r][c]) for r in range(len(data))) for c in range(n)]

    def hline() -> str:
        return "+" + "+".join("-" * (w + 2) for w in widths) + "+"

    def fmt_row(cells: list[str]) -> str:
        return "|" + "|".join(" " + cells[i].ljust(widths[i]) + " " for i in range(n)) + "|"

    lines = [hline(), fmt_row(headers), hline()]
    for row in rows:
        lines.append(fmt_row(row))
    lines.append(hline())
    return "\n".join(lines)


def _format_card_view_plain(
    class_name: str,
    component_path: Path,
    props: list[tuple[str, str, str | None]],
    has_ajax: bool,
    io_fields: list[str],
    events: list[str],
    *,
    class_node: ast.ClassDef,
) -> str:
    """Structured plain text: Name, file, Props, Ajax, IO, Events (from create_*_event)."""
    sections: list[str] = []
    sections.append(f"Name:\n{class_name}")
    sections.append(f"File:\n{component_path.resolve()}")

    prop_rows: list[list[str]] = []
    for name, typ, default in props:
        default_cell = "(required)" if default is None else default
        prop_rows.append([name, typ, default_cell])
    sections.append("Props:\n" + _ascii_table(["Name", "Type", "Default"], prop_rows))

    sections.append(f"Ajax:\n{'yes' if has_ajax else 'no'}")

    if io_fields:
        io_rows = [[fn] for fn in io_fields]
        sections.append("IO:\n" + _ascii_table(["name"], io_rows))
    else:
        sections.append("IO:\nno")

    if events:
        event_rows = _event_table_rows(class_node, events)
        sections.append(
            "Events:\n"
            + _ascii_table(["event", "param", "type", "default"], event_rows)
        )
    else:
        sections.append("Events:\nno")

    return "\n\n".join(sections) + "\n"


def handle_card_view(card_name: str) -> None:
    path = _card_file_path(card_name)
    if not path.is_file():
        raise ValueError(f"Card file not found: {path}")
    class_name = normalize_class_name(card_name)
    text = path.read_text(encoding="utf-8")
    tree = ast.parse(text)
    class_node = _find_card_class(tree, class_name)
    if class_node is None:
        raise ValueError(f"Class {class_name!r} not found in {path}")

    props = _parse_dataclass_props(class_node)
    field_names = {p[0] for p in props}
    has_ajax = _card_has_ajax(field_names)
    io_fields = _io_support_field_names(field_names)
    events = _extract_supported_events(path, class_name)

    plain = _format_card_view_plain(
        class_name,
        path,
        props,
        has_ajax=has_ajax,
        io_fields=io_fields,
        events=events,
        class_node=class_node,
    )
    sys.stdout.write(plain)


def _extract_supported_events(path: Path, class_name: str) -> list[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in tree.body:
        if not isinstance(node, ast.ClassDef) or node.name != class_name:
            continue
        for item in node.body:
            if not isinstance(item, ast.FunctionDef) or item.name != "get_supported_events":
                continue
            for stmt in item.body:
                if not isinstance(stmt, ast.Return) or stmt.value is None:
                    continue
                if not isinstance(stmt.value, ast.List):
                    continue
                out: list[str] = []
                for elt in stmt.value.elts:
                    if isinstance(elt, ast.Constant) and isinstance(elt.value, str):
                        out.append(elt.value)
                return out
        break
    return []


def handle_card_list_events(card_name: str) -> None:
    settings = get_settings()
    components_dir = settings.components_dir.resolve()
    print(f"Scanning events in: {components_dir}")
    class_name = normalize_class_name(card_name)
    path = _card_file_path(card_name)
    if not path.is_file():
        print(f"No events found for {class_name}.")
        return
    events = _extract_supported_events(path, class_name)
    if not events:
        print(f"No events found for {class_name}.")
        return
    for ev in events:
        print(ev)


def handle_card_add_event(card_name: str, event_name: str) -> None:
    _ = card_name, event_name
    raise ValueError("add-event requires TypeScript AST editing and is not implemented")
