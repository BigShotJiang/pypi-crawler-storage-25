import ast
import importlib
import inspect
import json
import re
import sys
from pathlib import Path
from types import ModuleType

from jinja2 import Template

from pie.async_page import AsyncPage
from pie.config import get_settings


def handle_page_add(page_name: str) -> Path:
    target_path = _write_page_module(page_name)
    _register_page_in_web_py(page_name=page_name, page_path=target_path)
    return target_path


def _write_page_module(page_name: str) -> Path:
    page_root = pages_dir()
    page_root.mkdir(parents=True, exist_ok=True)

    target_path = page_root / page_filename(page_name)
    class_base = normalize_page_class_name(page_name)
    if target_path.exists():
        print(f"[pie] Page already exists: {class_base}Page")
        print(f"[pie] Path: {target_path}")
        return target_path

    template_text = template_path().read_text(encoding="utf-8")
    rendered = Template(template_text).render(name=class_base).strip() + "\n"
    target_path.write_text(rendered, encoding="utf-8")
    print(f"[pie] Created page: {class_base}Page")
    print(f"[pie] Path: {target_path}")
    return target_path


def _register_page_in_web_py(*, page_name: str, page_path: Path) -> None:
    web_path = web_py_path()
    if not web_path.is_file():
        raise ValueError(f"web.py not found (expected {web_path})")

    route = page_route_key(page_name, page_path)
    if not route:
        raise ValueError("Page route is empty after normalization")

    module_stem = page_path.stem
    class_base = normalize_page_class_name(page_name)
    full_class = f"{class_base}Page"

    text = web_path.read_text(encoding="utf-8")
    text2 = _apply_web_py_registration(text, module_stem, full_class, route)
    if text2 != text:
        web_path.write_text(text2, encoding="utf-8")
        print(f"[pie] Registered page in web.py: {route!r} -> {full_class}")


def web_py_path() -> Path:
    return pages_dir().parent / "web.py"


def page_route_key(page_name: str, page_path: Path) -> str:
    s = page_name.strip()
    if "/" in s:
        return normalize_slash_route(s)
    return page_path.stem


def normalize_slash_route(value: str) -> str:
    s = value.strip()
    s = re.sub(r"/+", "/", s)
    return s.strip("/")


def _apply_web_py_registration(
    content: str,
    module_stem: str,
    class_name: str,
    route: str,
) -> str:
    tree = ast.parse(content)
    pages_dict = _find_web_pages_dict(tree)
    need_entry = not _dict_has_str_key(pages_dict, route)
    need_import = not _imports_pages_class(tree, module_stem, class_name)
    if not need_entry and not need_import:
        return content

    lines = content.splitlines(keepends=True)

    if need_entry:
        indent = _dict_entry_indent(content, pages_dict)
        key_lit = json.dumps(route, ensure_ascii=False)
        entry = f"{indent}{key_lit}: {class_name}(),\n"
        dline = pages_dict.end_lineno - 1
        col = pages_dict.end_col_offset - 1
        row = lines[dline]
        lines[dline] = row[:col] + entry + row[col:]

    if need_import:
        new_line = f"from pages.{module_stem} import {class_name}\n"
        after = _last_pages_import_end_line(tree)
        if after is None:
            after = _first_fastapi_import_end_line(tree)
        if after is None:
            raise ValueError("web.py: cannot find a place to insert pages import")
        lines.insert(after, new_line)

    return "".join(lines)


def _find_web_pages_dict(tree: ast.Module) -> ast.Dict:
    for stmt in tree.body:
        if not isinstance(stmt, ast.Assign):
            continue
        for target in stmt.targets:
            if isinstance(target, ast.Name) and target.id == "web":
                val = stmt.value
                if isinstance(val, ast.Call) and _is_web_callee(val.func):
                    for arg in val.args:
                        if isinstance(arg, ast.Dict):
                            return arg
                raise ValueError("web.py: Web(...) has no pages dict literal")
    raise ValueError("web.py: cannot find web = Web({...})")


def _is_web_callee(func: ast.expr) -> bool:
    if isinstance(func, ast.Name):
        return func.id == "Web"
    if isinstance(func, ast.Attribute):
        return func.attr == "Web"
    return False


def _dict_has_str_key(d: ast.Dict, key: str) -> bool:
    for k in d.keys:
        if k is None:
            continue
        if isinstance(k, ast.Constant) and isinstance(k.value, str) and k.value == key:
            return True
    return False


def _imports_pages_class(tree: ast.Module, module_stem: str, class_name: str) -> bool:
    want = f"pages.{module_stem}"
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module == want:
            for alias in node.names:
                if alias.name == class_name:
                    return True
    return False


def _last_pages_import_end_line(tree: ast.Module) -> int | None:
    best: int | None = None
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module and node.module.startswith("pages."):
            end = node.end_lineno
            assert end is not None
            best = end if best is None else max(best, end)
    return best


def _first_fastapi_import_end_line(tree: ast.Module) -> int | None:
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module == "fastapi":
            return node.end_lineno
    return None


def _dict_entry_indent(content: str, d: ast.Dict) -> str:
    for k in d.keys:
        if k is None:
            continue
        line_no = k.lineno
        if line_no is None:
            break
        line = content.splitlines()[line_no - 1]
        m = re.match(r"(\s*)", line)
        if m:
            return m.group(1)
    return "        "


def pages_dir() -> Path:
    return get_settings().components_dir.parent


def template_path() -> Path:
    return Path(__file__).resolve().parent / "templates" / "pages" / "page.py.j2"


def normalize_page_class_name(value: str) -> str:
    cleaned = re.sub(r"[^0-9A-Za-z]+", " ", value).strip()
    if not cleaned:
        raise ValueError("page.py: invalid page class name")
    class_name = "".join(part[:1].upper() + part[1:] for part in cleaned.split())
    if class_name.endswith("Page") and class_name != "Page":
        return class_name[:-4]
    return class_name


def page_filename(value: str) -> str:
    cleaned = re.sub(r"[^0-9A-Za-z]+", "_", value).strip("_").lower()
    if not cleaned:
        raise ValueError("page.py: invalid page class name")
    return f"{cleaned}.py"


def _ascii_table(headers: list[str], rows: list[list[str]]) -> str:
    if not rows:
        return "(empty)"
    widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            widths[i] = max(widths[i], len(cell))

    def hline() -> str:
        return "+" + "+".join("-" * (w + 2) for w in widths) + "+"

    def fmt_row(cells: list[str]) -> str:
        parts = [f" {cells[i]:<{widths[i]}} " for i in range(len(cells))]
        return "|" + "|".join(parts) + "|"

    lines = [hline(), fmt_row(headers), hline()]
    lines.extend(fmt_row(row) for row in rows)
    lines.append(hline())
    return "\n".join(lines)


def _ajax_table(instance: AsyncPage) -> str:
    post = sorted(instance.ajax_post.keys())
    get = sorted(instance.ajax_get.keys())
    if not post and not get:
        return _ascii_table(["method", "path"], [["—", "—"]])
    rows: list[list[str]] = []
    for path in post:
        rows.append(["POST", path])
    for path in get:
        rows.append(["GET", path])
    return _ascii_table(["method", "path"], rows)


def _find_async_page_class(mod: ModuleType) -> type:
    candidates: list[type] = []
    for _, obj in inspect.getmembers(mod, inspect.isclass):
        if getattr(obj, "__module__", None) != mod.__name__:
            continue
        if not issubclass(obj, AsyncPage) or obj is AsyncPage:
            continue
        candidates.append(obj)
    if not candidates:
        raise ValueError(f"No AsyncPage subclass found in module {mod.__name__!r}")
    if len(candidates) == 1:
        return candidates[0]
    for cls in candidates:
        if cls.__name__.endswith("Page"):
            return cls
    return candidates[0]


def handle_page_view(page_name: str) -> None:
    page_root = pages_dir()
    target = (page_root / page_filename(page_name)).resolve()
    if not target.is_file():
        raise ValueError(f"Page file not found: {target}")

    project_root = page_root.parent.resolve()
    stem = target.stem
    root_str = str(project_root)
    inserted = False
    if root_str not in sys.path:
        sys.path.insert(0, root_str)
        inserted = True
    try:
        try:
            mod = importlib.import_module(f"pages.{stem}")
        except Exception as exc:
            raise ValueError(f"Failed to import pages.{stem}: {exc}") from exc
        page_cls = _find_async_page_class(mod)
        try:
            instance = page_cls()
        except Exception as exc:
            raise ValueError(f"Failed to instantiate {page_cls.__name__}: {exc}") from exc
    finally:
        if inserted:
            try:
                sys.path.remove(root_str)
            except ValueError:
                pass

    process_impl = page_cls.process is not AsyncPage.process
    header_lines = [
        f"Page: {page_cls.__name__}",
        f"Module: pages.{stem}",
        f"Path: {target}",
        f"is_typed: {'yes' if instance.is_typed else 'no'}",
        f"Form process: {'yes' if process_impl else 'no'}",
    ]

    print("\n".join(header_lines))
    print()
    print("Ajax:")
    print(_ajax_table(instance))
