import mimetypes
from collections.abc import Iterable
from pathlib import Path
from typing import List, Optional
from urllib.parse import quote

import httpx

from pie.config import Settings
from pie.code.services.models import ComponentObject


METADATA_CONTENT_TYPES = {
    "jsonSchema": "application/json",
    "eventSchema": "application/json",
    "llms.txt": "text/plain",
}
STORAGE_LANGUAGE = "python"
DEFAULT_TIMEOUT = 30


class PieStorageError(RuntimeError):
    pass


class PieStorageService:
    def __init__(self, settings: Settings):
        self._settings = settings
        self._base_url = str(settings.api_base_url).rstrip("/")

    def list_component(
        self,
        *,
        component_name: str,
        user_id: Optional[str] = None,
        project_slug: Optional[str] = None,
    ) -> ComponentTree:
        response = self._request(
            "GET",
            self._component_url(
                component_name=component_name,
                user_id=user_id,
                project_slug=project_slug,
            ),
            headers=self._headers(),
            timeout=DEFAULT_TIMEOUT,
        )
        self._raise_for_error(response)
        return ComponentTree.model_validate(response.json())

    def delete_component(
        self,
        *,
        component_name: str,
        user_id: Optional[str] = None,
        project_slug: Optional[str] = None,
    ) -> None:
        response = self._request(
            "DELETE",
            self._component_url(
                component_name=component_name,
                user_id=user_id,
                project_slug=project_slug,
            ),
            headers=self._headers(),
            timeout=DEFAULT_TIMEOUT,
        )
        self._raise_for_error(response)

    def upload_component_directory(
        self,
        *,
        component_name: str,
        source_dir: Path,
        user_id: Optional[str] = None,
        project_slug: Optional[str] = None,
    ) -> List[ComponentObject]:
        source_dir = source_dir.resolve()
        if not source_dir.is_dir():
            raise PieStorageError(f"component directory not found: {source_dir}")

        uploaded: List[ComponentObject] = []
        for file_path in self._iter_files(source_dir):
            object_path = file_path.relative_to(source_dir).as_posix()
            uploaded.append(
                self.upload_language_file(
                    component_name=component_name,
                    object_path=object_path,
                    file_path=file_path,
                    user_id=user_id,
                    project_slug=project_slug,
                )
            )
        return uploaded

    def upload_language_file(
        self,
        *,
        component_name: str,
        object_path: str,
        file_path: Path,
        user_id: Optional[str] = None,
        project_slug: Optional[str] = None,
    ) -> ComponentObject:
        file_path = file_path.resolve()
        if not file_path.is_file():
            raise PieStorageError(f"file not found: {file_path}")

        content_type = mimetypes.guess_type(file_path.name)[0] or "application/octet-stream"
        with file_path.open("rb") as file_obj:
            response = self._request(
                "PUT",
                self._language_file_url(
                    component_name=component_name,
                    object_path=object_path,
                    user_id=user_id,
                    project_slug=project_slug,
                ),
                files={"file": (file_path.name, file_obj, content_type)},
                headers=self._headers(),
                timeout=DEFAULT_TIMEOUT,
            )
        self._raise_for_error(response)
        return ComponentObject.from_dict(response.json())

    def download_component_directory(
        self,
        *,
        component_name: str,
        target_dir: Path,
        user_id: Optional[str] = None,
        project_slug: Optional[str] = None,
    ) -> list[Path]:
        tree = self.list_component(
            component_name=component_name,
            user_id=user_id,
            project_slug=project_slug,
        )
        tree_data = tree.model_dump()
        objects = (tree_data.get(STORAGE_LANGUAGE) or {}).get("objects") or []
        prefix = f"{tree.prefix}{STORAGE_LANGUAGE}/"

        downloaded: list[Path] = []
        for item in objects:
            key = item["key"]
            if not key.startswith(prefix):
                continue
            object_path = key.removeprefix(prefix)
            downloaded.append(
                self.download_language_file(
                    component_name=component_name,
                    object_path=object_path,
                    target_path=target_dir / object_path,
                    user_id=user_id,
                    project_slug=project_slug,
                )
            )
        return downloaded

    def download_language_file(
        self,
        *,
        component_name: str,
        object_path: str,
        target_path: Path,
        user_id: Optional[str] = None,
        project_slug: Optional[str] = None,
    ) -> Path:
        response = self._request(
            "GET",
            self._language_file_url(
                component_name=component_name,
                object_path=object_path,
                user_id=user_id,
                project_slug=project_slug,
            ),
            headers=self._headers(),
            timeout=DEFAULT_TIMEOUT,
        )
        self._raise_for_error(response)
        target_path.parent.mkdir(parents=True, exist_ok=True)
        target_path.write_bytes(response.content)
        return target_path

    def delete_language_file(
        self,
        *,
        component_name: str,
        object_path: str,
        user_id: Optional[str] = None,
        project_slug: Optional[str] = None,
    ) -> None:
        response = self._request(
            "DELETE",
            self._language_file_url(
                component_name=component_name,
                object_path=object_path,
                user_id=user_id,
                project_slug=project_slug,
            ),
            headers=self._headers(),
            timeout=DEFAULT_TIMEOUT,
        )
        self._raise_for_error(response)

    def upload_metadata(
        self,
        *,
        component_name: str,
        schema_kind: str,
        file_path: Path,
        user_id: Optional[str] = None,
        project_slug: Optional[str] = None,
    ) -> ComponentObject:
        content_type = self._metadata_content_type(schema_kind)
        if not file_path.is_file():
            raise PieStorageError(f"file not found: {file_path}")

        response = self._request(
            "PUT",
            self._metadata_url(
                component_name=component_name,
                schema_kind=schema_kind,
                user_id=user_id,
                project_slug=project_slug,
            ),
            content=file_path.read_bytes(),
            headers={**self._headers(), "content-type": content_type},
            timeout=DEFAULT_TIMEOUT,
        )
        self._raise_for_error(response)
        return ComponentObject.model_validate(response.json())

    def download_metadata(
        self,
        *,
        component_name: str,
        schema_kind: str,
        target_path: Path,
        user_id: Optional[str] = None,
        project_slug: Optional[str] = None,
    ) -> Path:
        self._metadata_content_type(schema_kind)
        response = self._request(
            "GET",
            self._metadata_url(
                component_name=component_name,
                schema_kind=schema_kind,
                user_id=user_id,
                project_slug=project_slug,
            ),
            headers=self._headers(),
            timeout=DEFAULT_TIMEOUT,
        )
        self._raise_for_error(response)
        target_path.parent.mkdir(parents=True, exist_ok=True)
        target_path.write_bytes(response.content)
        return target_path

    def delete_metadata(
        self,
        *,
        component_name: str,
        schema_kind: str,
        user_id: Optional[str] = None,
        project_slug: Optional[str] = None,
    ) -> None:
        self._metadata_content_type(schema_kind)
        response = self._request(
            "DELETE",
            self._metadata_url(
                component_name=component_name,
                schema_kind=schema_kind,
                user_id=user_id,
                project_slug=project_slug,
            ),
            headers=self._headers(),
            timeout=DEFAULT_TIMEOUT,
        )
        self._raise_for_error(response)

    def _component_url(
        self,
        *,
        component_name: str,
        user_id: Optional[str],
        project_slug: Optional[str],
    ) -> str:
        return (
            f"{self._base_url}/components/"
            f"{self._path_part(user_id or self._settings.user_id)}/"
            f"{self._path_part(project_slug or self._settings.project_slug)}/"
            f"{self._path_part(component_name)}"
        )

    def _language_file_url(
        self,
        *,
        component_name: str,
        object_path: str,
        user_id: Optional[str],
        project_slug: Optional[str],
    ) -> str:
        component_url = self._component_url(
            component_name=component_name,
            user_id=user_id,
            project_slug=project_slug,
        )
        return f"{component_url}/{STORAGE_LANGUAGE}/{self._object_path(object_path)}"

    def _metadata_url(
        self,
        *,
        component_name: str,
        schema_kind: str,
        user_id: Optional[str],
        project_slug: Optional[str],
    ) -> str:
        component_url = self._component_url(
            component_name=component_name,
            user_id=user_id,
            project_slug=project_slug,
        )
        return f"{component_url}/metadata/{quote(schema_kind, safe='')}"

    def _headers(self) -> dict[str, str]:
        if not self._settings.api_key:
            return {}
        return {"x-api-key": self._settings.api_key}

    def _request(self, method: str, url: str, **kwargs: object) -> httpx.Response:
        try:
            return httpx.request(method, url, **kwargs)
        except httpx.HTTPError as error:
            raise PieStorageError(f"{method} {url} failed: {error}") from error

    @staticmethod
    def _path_part(value: str) -> str:
        return quote(value, safe="")

    @staticmethod
    def _object_path(value: str) -> str:
        parts = value.replace("\\", "/").split("/")
        if (
            value.startswith("/")
            or "" in parts
            or any(part in {".", ".."} for part in parts)
        ):
            raise PieStorageError("object path must be relative and must not contain . or ..")
        return quote("/".join(parts), safe="/")

    @staticmethod
    def _iter_files(root: Path) -> Iterable[Path]:
        for path in sorted(root.rglob("*")):
            if path.is_file():
                yield path

    @staticmethod
    def _metadata_content_type(schema_kind: str) -> str:
        try:
            return METADATA_CONTENT_TYPES[schema_kind]
        except KeyError as error:
            allowed = ", ".join(sorted(METADATA_CONTENT_TYPES))
            raise PieStorageError(
                f"unknown metadata kind: {schema_kind}. Use one of: {allowed}"
            ) from error

    @staticmethod
    def _raise_for_error(response: httpx.Response) -> None:
        if not response.is_error:
            return
        detail = response.text.strip()
        message = (
            f"{response.request.method} {response.request.url} "
            f"failed: {response.status_code}"
        )
        if detail:
            message = f"{message}\n{detail}"
        raise PieStorageError(message)
