from dataclasses import dataclass, field
from typing import Optional

from dataclasses_json import DataClassJsonMixin, dataclass_json, LetterCase


@dataclass_json(letter_case=LetterCase.CAMEL)
@dataclass
class ComponentObject(DataClassJsonMixin):
    key: str
    size: int | None = None
    content_type: Optional[str] = None
    signed_url: Optional[str] = None
