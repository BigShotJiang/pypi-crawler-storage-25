"""`pie login` — browser OAuth-style flow against PieUI."""

from __future__ import annotations

import json
import secrets
import string
import time
import webbrowser
from pathlib import Path
from typing import Any, Callable
from urllib.parse import urlencode

import httpx

CONNECT_BASE = "https://pieui.swarm.ing/connect"
CREDENTIALS_API = "https://api-pieui.swarm.ing/api/external/credentials"


def _generate_code(length: int = 32) -> str:
    alphabet = string.ascii_letters + string.digits
    return "".join(secrets.choice(alphabet) for _ in range(length))


def handle_login(
    *,
    cwd: Path | None = None,
    poll_interval_s: float = 3.0,
    open_browser_fn: Callable[[str], bool] | None = None,
    httpx_client: httpx.Client | None = None,
) -> None:
    """Generate a one-time code, open the connect URL, poll until ok/error, then save config."""
    code = _generate_code(32)
    connect_url = f"{CONNECT_BASE}?{urlencode({'code': code})}"

    print("Open link in browser:\n")
    print(connect_url)

    opener = open_browser_fn if open_browser_fn is not None else webbrowser.open
    try:
        opener(connect_url)
    except Exception:
        pass

    base = cwd if cwd is not None else Path.cwd()
    pie_dir = base / ".pie"
    config_path = pie_dir / "config.json"

    if httpx_client is not None:
        _poll_and_save(httpx_client, code, config_path, poll_interval_s=poll_interval_s)
    else:
        with httpx.Client(timeout=30.0) as client:
            _poll_and_save(client, code, config_path, poll_interval_s=poll_interval_s)


def _poll_and_save(
    client: httpx.Client,
    code: str,
    config_path: Path,
    *,
    poll_interval_s: float,
) -> None:
    url = CREDENTIALS_API
    params = {"code": code}
    first = True
    while True:
        if not first:
            time.sleep(poll_interval_s)
        first = False

        response = client.get(url, params=params)
        response.raise_for_status()
        data: Any = response.json()
        if not isinstance(data, dict):
            continue

        status = data.get("status")
        if status == "error":
            detail = data.get("message", data.get("error", "unknown error"))
            raise ValueError(f"Login failed: {detail}")
        if status == "ok":
            if "config" not in data:
                raise ValueError("Login succeeded but response had no 'config' field")
            config_path.parent.mkdir(parents=True, exist_ok=True)
            config_path.write_text(
                json.dumps(data["config"], indent=2, ensure_ascii=False) + "\n",
                encoding="utf-8",
            )
            print(f"[pie] Saved credentials to {config_path}")
            return

