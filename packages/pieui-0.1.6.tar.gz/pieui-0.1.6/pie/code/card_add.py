import re
from pathlib import Path

from jinja2 import Template

from pie.config import get_settings


_TEMPLATE_SUFFIXES = {
    "simple": "component.py.j2",
    "complex": "complex_component.py.j2",
    "container": "container_component.py.j2",
    "complex-container": "complex_container_component.py.j2",
}


def handle_card_add(card_name: str, card_type: str, use_io: bool, use_ajax: bool) -> Path:
    class_name = normalize_class_name(card_name)
    template_path = resolve_template_path(card_type, use_io=use_io, use_ajax=use_ajax)
    components_dir = get_settings().components_dir
    components_dir.mkdir(parents=True, exist_ok=True)

    target_path = components_dir / class_filename(class_name)
    if target_path.exists():
        print(f"[pie] Card already exists: {class_name}")
        print(f"[pie] Path: {target_path}")
        return target_path

    template_text = template_path.read_text(encoding="utf-8")
    rendered_body = Template(template_text).render(name=class_name).strip() + "\n"
    target_path.write_text(module_source(rendered_body), encoding="utf-8")
    print(f"[pie] Created card: {class_name}")
    print(f"[pie] Path: {target_path}")
    return target_path


def resolve_template_path(card_type: str, *, use_io: bool, use_ajax: bool) -> Path:
    prefix = template_prefix(use_io=use_io, use_ajax=use_ajax)
    template_name = prefix + _TEMPLATE_SUFFIXES[card_type]
    template_path = templates_dir() / template_name
    if not template_path.exists():
        raise ValueError(f"Template not found: {template_name}")
    return template_path


def template_prefix(*, use_io: bool, use_ajax: bool) -> str:
    if use_ajax and use_io:
        return "ajax_io_"
    if use_ajax:
        return "ajax_"
    if use_io:
        return "io_"
    return ""


def templates_dir() -> Path:
    return Path(__file__).resolve().parent / "templates" / "pages" / "components"


def normalize_class_name(value: str) -> str:
    cleaned = re.sub(r"[^0-9A-Za-z]+", " ", value).strip()
    if not cleaned:
        return "Card"
    class_name = "".join(part[:1].upper() + part[1:] for part in cleaned.split())
    return class_name


def class_filename(class_name: str) -> str:
    snake_name = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1_\2", class_name)
    snake_name = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", snake_name).lower()
    snake_name = re.sub(r"_+", "_", snake_name).strip("_")
    if not snake_name.endswith("_card"):
        snake_name = f"{snake_name}_card"
    return f"{snake_name}.py"


def module_source(rendered_body: str) -> str:
    imports = []
    if "field(" in rendered_body:
        imports.append("from dataclasses import dataclass, field")
    else:
        imports.append("from dataclasses import dataclass")
    if "Any" in rendered_body:
        imports.append("from typing import Any")
    return "\n".join(imports + ["", rendered_body])
