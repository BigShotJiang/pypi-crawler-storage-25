"""Web application loading and linting."""

import importlib
import sys


def _load_web(web_path: str):
    module_name, app_name = web_path.split(":")
    module = importlib.import_module(module_name)
    return getattr(module, app_name)


def handle_web(web_path: str) -> None:
    web = _load_web(web_path)
    print(f"Web application loaded: {web}")


def handle_web_verify(web_path: str) -> None:
    web = _load_web(web_path)
    print("Linting web application...")

    for page in web.pages.values():
        if not hasattr(page, "fields"):
            print(f"Error: Page {page} has no fields attribute")
            sys.exit(1)

    print("All pages have fields attribute")
    print("Lint completed successfully")
