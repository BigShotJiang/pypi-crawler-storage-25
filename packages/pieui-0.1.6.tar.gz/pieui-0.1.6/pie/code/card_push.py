from pathlib import Path

from pie.code.card_add import class_filename, normalize_class_name
from pie.code.services.models import ComponentObject
from pie.code.services.storage import PieStorageService
from pie.config import get_settings


def handle_card_push(card_name: str) -> ComponentObject:
    class_name = normalize_class_name(card_name)
    settings = get_settings()
    file_path = (settings.components_dir / class_filename(class_name)).resolve()
    if not file_path.is_file():
        raise ValueError(f"Card file not found: {file_path}")

    uploaded = PieStorageService(settings).upload_language_file(
        component_name=class_name,
        object_path=file_path.name,
        file_path=file_path,
    )
    print(f"[pie] Uploaded card: {class_name}")
    print(f"[pie] Path: {file_path}")
    print(f"[pie] Remote key: {uploaded.key}")
    return uploaded
