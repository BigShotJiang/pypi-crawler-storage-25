import errno
import hashlib
import os.path
import shutil
import tempfile
import uuid
from typing import Optional

import requests
from tqdm import tqdm

from .pretrained_checkpoint import FileLocation, PretrainedCheckpoint


def download_url_to_file(url, dst, hash_prefix: Optional[str] = None, progress=True):
    file_size = None
    resp: requests.Response = requests.get(
        url, stream=True, headers={"User-Agent": "torch.hub"}
    )

    content_length = resp.headers["Content-Length"]
    if content_length is not None and len(content_length) > 0:
        file_size = int(content_length)

    dst = os.path.expanduser(dst)
    for seq in range(tempfile.TMP_MAX):
        tmp_dst = dst + "." + uuid.uuid4().hex + ".partial"
        try:
            f = open(tmp_dst, "w+b")
        except FileExistsError:
            continue
        break
    else:
        raise FileExistsError(errno.EEXIST, "No usable temporary file name found")

    try:
        if hash_prefix is not None:
            sha256 = hashlib.sha256()
        with tqdm(
            total=file_size,
            disable=not progress,
            unit="B",
            unit_scale=True,
            unit_divisor=1024,
        ) as pbar:
            for buffer in resp.iter_content(chunk_size=8192):
                if len(buffer) == 0:
                    break
                f.write(buffer)
                if hash_prefix is not None:
                    sha256.update(buffer)
                pbar.update(len(buffer))

        f.close()
        if hash_prefix is not None:
            digest = sha256.hexdigest()
            if digest[: len(hash_prefix)] != hash_prefix:
                raise RuntimeError(
                    f'invalid hash value (expected "{hash_prefix}", got "{digest}")'
                )
        shutil.move(f.name, dst)
    finally:
        f.close()
        if os.path.exists(f.name):
            os.remove(f.name)


def download_file(url, cached_path, progress=True):
    print(f"Downloading {url} -> {cached_path}")
    download_url_to_file(url, cached_path, progress=progress)


PretrainedCheckpoint.DOWNLOADERS[FileLocation.URL] = download_file
