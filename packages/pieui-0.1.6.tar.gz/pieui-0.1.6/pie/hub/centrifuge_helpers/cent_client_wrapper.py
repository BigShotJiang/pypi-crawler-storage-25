from typing import Any

from cent import AsyncClient, PublishRequest


class SIOLikeWrapper(object):
    def __init__(self, cio: AsyncClient):
        self.cio = cio

    async def emit(self, name: str, data: Any, to: str = None):
        request = PublishRequest(channel=f"{name}_{to}", data=data)
        result = await self.cio.publish(request)
        return result
