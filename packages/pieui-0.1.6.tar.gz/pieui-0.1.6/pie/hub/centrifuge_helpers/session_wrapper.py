import asyncio

import aiohttp
from aiohttp import ClientSession


class LazyPostWrapper(object):
    def __init__(self, session: "LazyClientSession", *args, **kwargs):
        self.session = session
        self.args = args
        self.kwargs = kwargs
        self.context = None

    async def __aenter__(self):
        real_session = await self.session.ensure_session()
        context = real_session.post(*self.args, **self.kwargs)
        self.context = context
        return await context.__aenter__()

    async def __aexit__(self, exc_type, exc, tb):
        await self.context.__aexit__(exc_type, exc, tb)


class LazyClientSession(ClientSession):
    """Wrapper for aiohttp.ClientSession with lazy initialization."""

    def __init__(self):
        self._session: aiohttp.ClientSession | None = None
        self._headers = {}

    async def __aenter__(self):
        """Support async with syntax."""
        await self._ensure_session()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Ensure session is closed on exit."""
        await self.close()

    def post(self, *args, **kwargs):
        return LazyPostWrapper(self, *args, **kwargs)

    async def ensure_session(self):
        """Ensure the session is initialized before use."""
        if self._session is None:
            loop = asyncio.get_running_loop()
            self._session = aiohttp.ClientSession(loop=loop)
            self._session.headers.update(self._headers)
        return self._session

    async def close(self):
        """Close the session if it exists."""
        if self._session:
            await self._session.close()
            self._session = None

    @property
    def headers(self):
        return self._headers

    def __getattr__(self, name):
        """Dynamically delegate methods to the wrapped session."""

        async def wrapper(*args, **kwargs):
            await self.ensure_session()
            method = getattr(self._session, name)
            return await method(*args, **kwargs)

        return wrapper
