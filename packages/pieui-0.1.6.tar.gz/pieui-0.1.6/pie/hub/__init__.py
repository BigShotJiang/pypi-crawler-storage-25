def adopt_repo(url, infer_file):
    pass
