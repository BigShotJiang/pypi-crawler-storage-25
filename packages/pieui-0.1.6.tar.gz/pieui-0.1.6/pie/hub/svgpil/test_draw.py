from . import SVGImage

im = SVGImage.new((100, 100))
draw = SVGImage.SVGImageDraw(im)
draw.rectangle([0, 0, 10, 10], fill="black")
draw.polygon([0, 0, 0, 100, 100, 0], fill="white")
print(im.svg_content)
