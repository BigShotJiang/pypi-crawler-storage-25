import base64
import io
import re

try:
    from typing import Any, Callable, Literal, Tuple
except ImportError:
    from typing import Callable, Tuple, Any
    from typing_extensions import Literal

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from imantics import Polygons

import math
from xml.etree import ElementTree as ET

import numpy as np
from PIL import Image

DirectionType = Literal["horizontal", "vertical"]


def iterate_xml_recursive(element, depth=0):
    """Recursively iterate through all child elements of an XML node."""
    yield element
    for child in element:
        yield from iterate_xml_recursive(child, depth + 1)


def apply_xml_recursive(
    element, fn: Callable[[ET.Element, int], Tuple[Any, bool]], depth=0
):
    ret, result = fn(element, depth)
    yield result
    if ret:
        for child in element:
            yield from apply_xml_recursive(child, fn, depth + 1)


def parse_transform(transform: str):
    """Parses an SVG transform string into a transformation matrix."""
    matrix = np.identity(3)  # 3x3 identity matrix for affine transformations

    transform_commands = re.findall(r"([a-zA-Z]+)\(([^)]+)\)", transform)

    for command, values in transform_commands:
        values = list(map(float, values.replace(",", " ").split()))

        if command == "translate":
            tx, ty = values[0], values[1] if len(values) > 1 else 0
            transform_matrix = np.array([[1, 0, tx], [0, 1, ty], [0, 0, 1]])
        elif command == "scale":
            sx, sy = values[0], values[1] if len(values) > 1 else values[0]
            transform_matrix = np.array([[sx, 0, 0], [0, sy, 0], [0, 0, 1]])
        elif command == "rotate":
            angle = np.radians(values[0])
            cos_a, sin_a = np.cos(angle), np.sin(angle)
            if len(values) == 3:
                cx, cy = values[1], values[2]
                transform_matrix = np.array(
                    [
                        [cos_a, -sin_a, cx - cx * cos_a + cy * sin_a],
                        [sin_a, cos_a, cy - cx * sin_a - cy * cos_a],
                        [0, 0, 1],
                    ]
                )
            else:
                transform_matrix = np.array(
                    [[cos_a, -sin_a, 0], [sin_a, cos_a, 0], [0, 0, 1]]
                )
        elif command == "matrix":
            a, b, c, d, e, f = values
            transform_matrix = np.array([[a, c, e], [b, d, f], [0, 0, 1]])
        else:
            raise ValueError(f"Unsupported transform command: {command}")

        matrix = np.dot(matrix, transform_matrix)  # Apply transformation
    # matrix = np.linalg.inv(matrix)
    return matrix


def get_extreme_points(element, parent_matrix):
    import svgpathtools

    transform = element.get("transform", "")
    matrix = (
        np.dot(parent_matrix, parse_transform(transform))
        if transform
        else parent_matrix
    )

    if element.tag.endswith("rect"):
        x, y, w, h = map(
            float,
            [
                element.get("x", 0),
                element.get("y", 0),
                element.get("width", 0),
                element.get("height", 0),
            ],
        )
        points = [(x, y), (x + w, y), (x, y + h), (x + w, y + h)]
        # vectors = [(0, 0), (0, 0), (0, 0), (0, 0)]
    elif element.tag.endswith("circle"):
        cx, cy, r = map(
            float, [element.get("cx", 0), element.get("cy", 0), element.get("r", 0)]
        )
        points = [(cx - r, cy), (cx + r, cy), (cx, cy - r), (cx, cy + r)]
        # vectors = [(0, -1), (1, 0), (0, 1), (-1, 0)]
    elif element.tag.endswith("path"):
        path_data = element.get("d", "")
        path = svgpathtools.parse_path(path_data)
        points = [segment.point(0) for segment in path] + [path[-1].point(1)]
        points = [(float(p.real), float(p.imag)) for p in points]
        # vectors = [segment.unit_tangent(0) for segment in path] + [path[-1].unit_tangent(1)]
        # vectors = [(float(v.real), float(v.imag))
        #           for v in vectors]
    else:
        points = []
        for child in element:
            points.extend(get_extreme_points(child, matrix))
        return points

    return [apply_transform(px, py, matrix) for px, py in points]


def apply_transform(x, y, matrix):
    point = np.array([x, y, 1])
    transformed = np.dot(matrix, point)
    return transformed[0], transformed[1]


class SVGImage(object):
    def __init__(self, svg_content):
        super(SVGImage, self).__init__()
        svg_content = re.sub(r"<\?xml[^>]+>\n?", "", svg_content, count=1)
        self.svg_content: str = re.sub(r'\sxmlns="[^"]+"', "", svg_content, count=1)

    def get_svg_body_content(self):
        svg_content = re.sub(r"<\?xml[^>]+\?>", "", self.svg_content).strip()
        svg_body_content = re.sub(r"^<svg[^>]*>", "", svg_content).rsplit("</svg>", 1)[
            0
        ]
        return svg_body_content

    def set_svg_body_content(self, svg_body_content):
        match = re.match(r"(<svg[^>]*>)", self.svg_content)
        if match:
            svg_opening_tag = match.group(1)
            self.svg_content = f"{svg_opening_tag}{svg_body_content}</svg>"
        else:
            raise ValueError("Invalid SVG content: Missing <svg> tag")

    def to_pil(self, scale=1):
        import cairosvg

        image_content = cairosvg.svg2png(self.svg_content, scale=scale)
        return Image.open(io.BytesIO(image_content))

    @property
    def viewbox(self):
        root = ET.fromstring(self.svg_content)
        viewBox = root.attrib.get("viewBox")
        if viewBox:
            if "," in viewBox:
                return list(map(float, viewBox.split(",")))
            else:
                return list(map(float, viewBox.split()))

        return [
            0,
            0,
            float(root.attrib.get("width", 100)),
            float(root.attrib.get("height", 100)),
        ]

    @property
    def size(self):
        return self.viewbox[2:]

    def to_base64(self):
        xml_declaration = '<?xml version="1.0" encoding="UTF-8"?>\n'
        svg_content = self.svg_content
        if not re.search(r"<svg[^>]+xmlns=", self.svg_content):
            svg_content = re.sub(
                r"<svg", '<svg xmlns="http://www.w3.org/2000/svg"', svg_content, count=1
            )
        b64 = base64.b64encode((xml_declaration + svg_content).encode("utf-8")).decode(
            "utf-8"
        )
        return f"data:image/svg+xml;base64,{b64}"

    def save(self, fp, format="SVG", **kwargs):
        if format != "SVG":
            self.to_pil().save(fp, format=format, **kwargs)
        if isinstance(fp, str):
            with io.open(fp, "w") as f:
                f.write(self.svg_content)
        if hasattr(fp, "write"):
            fp.write(self.svg_content)

    def __copy__(self):
        return self.copy()

    def __deepcopy__(self):
        return self.copy()

    def _repr_svg_(self):
        return self.svg_content

    def copy(self) -> "SVGImage":
        return SVGImage(str(self.svg_content))

    def to_etree(self):
        root = ET.fromstring(self.svg_content)
        return root

    def apply_fn_to_paths(self, fn):
        import svgpathtools

        root = ET.fromstring(self.svg_content)
        for child in iterate_xml_recursive(root):
            if child.tag == "path":
                child.attrib["d"] = fn(svgpathtools.parse_path(child.attrib["d"])).d()

        return SVGImage(ET.tostring(root, encoding="unicode"))

    def apply_transform(self, transform):
        """Apply a transformation matrix to the root SVG element."""
        root = ET.fromstring(self.svg_content)
        childs = list(root)
        if len(childs) != 1 or childs[0].tag != "g":
            g = ET.Element("g")
            g.attrib["transform"] = transform
            for child in list(root):
                g.append(child)
                root.remove(child)
            root.append(g)
        else:
            old_transform = childs[0].attrib.get("transform", "")
            childs[0].attrib["transform"] = f"{transform} {old_transform}".strip()

        return SVGImage(ET.tostring(root, encoding="unicode"))

    def imstyle(self, style):
        root = ET.fromstring(self.svg_content)
        root.attrib["style"] = style
        return SVGImage(ET.tostring(root, encoding="unicode"))

    def imresize(self, width, height):
        """Resize the SVG by setting width and height attributes."""
        root = ET.fromstring(self.svg_content)
        root.attrib["width"] = str(width)
        root.attrib["height"] = str(height)
        return SVGImage(ET.tostring(root, encoding="unicode"))

    def view(self, x, y, width, height):
        root = ET.fromstring(self.svg_content)
        root.set("viewBox", f"{x} {y} {width} {height}")
        return SVGImage(ET.tostring(root, encoding="unicode"))

    def scale(self, kw: float, kh: float = None, anchor=None) -> "SVGImage":
        if kh is None:
            kh = kw
        if anchor is None:
            anchor = self.viewbox[:2]
        return self.apply_transform(
            f"translate({anchor[0]},{anchor[1]}) scale({kw},{kh}) translate({-anchor[0]},{-anchor[1]})"
        )

    def rescale(self, k):
        return self.scale(k, anchor=self.viewbox[:2]).view(
            *self.viewbox[:2], k * self.viewbox[2], k * self.viewbox[3]
        )

    def set_size(self, width, height):
        return self.scale(width / self.viewbox[2], height / self.viewbox[3])

    def translate(self, x: float = 0, y: float = 0) -> "SVGImage":
        return self.apply_transform(f"translate({x},{y})")

    def retranslate(self):
        return self.translate(-self.viewbox[0], -self.viewbox[1]).view(
            0, 0, *self.viewbox[2:]
        )

    def crop(self, x, y, width, height) -> "SVGImage":
        """Crop an SVG by setting a viewBox."""
        return self.view(x, y, width, height)

    def crop_by_bounding_box(self) -> "SVGImage":
        return self.view(*self.get_bounding_box())

    def rotate(self, angle, anchor=None, expand=True) -> "SVGImage":
        """Rotate the SVG by applying a transform attribute with optional expansion."""
        svg = self
        cx, cy, w, h = self.get_svg_bounds()
        if anchor is None:
            anchor = (cx, cy)

        if expand:
            new_w = abs(w * math.cos(math.radians(angle))) + abs(
                h * math.sin(math.radians(angle))
            )
            pad_x = (new_w - w) / 2
            new_h = abs(w * math.sin(math.radians(angle))) + abs(
                h * math.cos(math.radians(angle))
            )
            pad_y = (new_h - h) / 2

            vx, vy, vw, wh = svg.viewbox
            svg = svg.view(vx - pad_x, vy - pad_y, vw + 2 * pad_x, wh + 2 * pad_y)

        transform = f"rotate({angle} {anchor[0]} {anchor[1]})"
        return svg.apply_transform(transform)

    def flip_horizontal(self, anchor=None) -> "SVGImage":
        """Flip the SVG horizontally."""
        if anchor is None:
            anchor = self.get_svg_center()[0]
        return self.apply_transform(
            f"translate({anchor},0) scale(-1,1) translate({-anchor},0)"
        )

    def flip_vertical(self, anchor=None) -> "SVGImage":
        """Flip the SVG vertically."""
        if anchor is None:
            anchor = self.get_svg_center()[1]
        return self.apply_transform(
            f"translate(0,{anchor}) scale(1,-1) translate(0,{-anchor})"
        )

    def get_svg_bounds(self):
        """Calculate the bounds of the SVG viewBox or width/height."""
        x, y, w, h = self.viewbox
        cx, cy = x + w / 2, y + h / 2
        return cx, cy, w, h

    def get_svg_center(self):
        return self.get_svg_bounds()[:2]

    def get_extreme_points(self):
        root = ET.fromstring(self.svg_content)
        return get_extreme_points(root, np.identity(3))

    def get_bounding_points(self):
        points = np.array(self.get_extreme_points())
        l_idx, t_idx = np.argmin(points, axis=0)
        r_idx, b_idx = np.argmax(points, axis=0)
        return points[l_idx], points[t_idx], points[r_idx], points[b_idx]

    def get_bounding_box(self):
        points = np.array(self.get_extreme_points())
        left, top = np.min(points, axis=0)
        right, bottom = np.max(points, axis=0)
        return [left, top, right - left, bottom - top]

    def with_opacity(self, opacity):
        root = ET.fromstring(self.svg_content)
        childs = list(root)
        if len(childs) != 1 or childs[0].tag != "g":
            g = ET.Element("g")
            g.attrib["opacity"] = str(opacity)
            for child in list(root):
                g.append(child)
                root.remove(child)
            root.append(g)
        else:
            childs[0].attrib["opacity"] = str(opacity)

        return SVGImage(ET.tostring(root, encoding="unicode"))

    def paste(self, other: "SVGImage", anchor=None) -> "SVGImage":
        if anchor is None:
            anchor = self.viewbox[:2]

        other = other.retranslate()
        other = other.translate(anchor[0], anchor[1])
        result = self.copy()
        result.set_svg_body_content(
            self.get_svg_body_content() + "\n" + other.get_svg_body_content()
        )
        return result

    def join_unsafe(self, *ims: "SVGImage"):
        result = self.copy()
        result.set_svg_body_content(
            self.get_svg_body_content()
            + "\n"
            + "\n".join([im.get_svg_body_content() for im in ims])
        )
        return result

    def pad(self, paddings):
        x, y, w, h = self.viewbox
        return self.view(
            x - paddings[0],
            y - paddings[1],
            w + paddings[0] + paddings[2],
            h + paddings[1] + paddings[3],
        )

    def split_unsafe(self):
        root = self.to_etree()
        childs = []
        for child in list(root):
            result = self.copy()
            result.set_svg_body_content(ET.tostring(child, encoding="unicode"))
            childs.append(result)
        return childs

    @staticmethod
    def concat(
        im1: "SVGImage",
        im2: "SVGImage",
        direction: DirectionType = "horizontal",
        rescale: bool = True,
    ) -> "SVGImage":
        im1 = im1.retranslate()
        im2 = im2.retranslate()
        if direction == "horizontal":
            if rescale:
                im2 = im2.rescale(im1.size[1] / im2.size[1])
            result = im1.view(0, 0, im1.size[0] + im2.size[0], im1.size[1])
            return result.paste(im2, (im1.size[0], 0))
        elif direction == "vertical":
            if rescale:
                im2 = im2.rescale(im1.size[0] / im2.size[0])
            result = im1.view(0, 0, im1.size[0], im1.size[1] + im2.size[1])
            return result.paste(im2, (0, im1.size[1]))
        else:
            raise NotImplementedError("No such direction")

    @staticmethod
    def blend(im1: "SVGImage", im2: "SVGImage", alpha: float = 0.5):
        im1 = im1.with_opacity(alpha)
        im2 = im2.with_opacity(1 - alpha)
        return im1.paste(im2)

    def iter_recursive(self):
        childs = self.split_unsafe()
        for child in childs:
            yield child
            yield from child.iter_recursive()

    def expand_stroke(self, k: float = 1.0):
        root = ET.fromstring(self.svg_content)

        def expand_stroke_recursive(child, depth):
            if "stroke-width" in child.attrib:
                child.attrib["stroke-width"] = str(
                    k * float(child.attrib["stroke-width"])
                )
                return child.attrib["stroke-width"], False
            else:
                return 1, True

        for stroke_width in apply_xml_recursive(root, expand_stroke_recursive):
            pass

        return SVGImage(ET.tostring(root, encoding="unicode"))


def open(path):
    with io.open(path, "r") as f:
        return SVGImage(f.read())


def new(size):
    return SVGImage(
        f"""
<svg width="{size[0]}" height="{size[1]}" viewBox="0 0 {size[0]} {size[1]}" fill="none" xmlns="http://www.w3.org/2000/svg">
</svg>
"""
    )


def from_polygons(
    poly: "Polygons",
    size: tuple,
    stroke=None,
    fill=None,
    **kwargs,
):
    from drawsvg import Drawing, Path

    result = Path(stroke=stroke, fill=fill, **kwargs)
    for polygon in poly.polygons:
        result = result.M(polygon[0], polygon[1])
        for p in zip(polygon[::2], polygon[1::2]):
            result = result.L(p[0], p[1])
        result = result.Z()
    d = Drawing(*size)
    d.append(result)
    return SVGImage(d.as_svg())


class SVGImageDraw(object):
    def __init__(self, im: SVGImage):
        from drawsvg import Drawing

        super().__init__()
        self.im = im
        self.draw = Drawing(*im.size)

    def line(self, xy, fill=None, stroke=None, width=0, closed: bool = False):
        from drawsvg import Lines

        xy = sum(xy, [])
        self.draw.append(
            Lines(*xy, closed=closed, fill=fill, stroke=stroke, stroke_width=width)
        )
        self.flush()

    def rectangle(self, xy, fill=None, stroke=None, outline=None, width=1):
        from drawsvg import Rectangle

        self.draw.append(
            Rectangle(
                xy[0],
                xy[1],
                xy[2] - xy[0],
                xy[3] - xy[1],
                stroke=stroke,
                fill=fill,
                outline=outline,
                stroke_width=width,
            )
        )
        self.flush()

    def ellipse(self, xy, fill=None, stroke=None, stroke_width=None):
        from drawsvg import Ellipse

        self.draw.append(
            Ellipse(*xy, fill=fill, stroke=stroke, stroke_width=stroke_width)
        )
        self.flush()

    def circle(self, xy, fill=None, stroke=None, stroke_width=None):
        from drawsvg import Circle

        self.draw.append(
            Circle(*xy, fill=fill, stroke=stroke, stroke_width=stroke_width)
        )
        self.flush()

    def polygon(self, xy, fill=None, stroke=None, outline=None):
        from drawsvg import Lines

        self.draw.append(
            Lines(
                *xy,
                close=True,
                stroke=stroke,
                fill=fill,
                outline=outline,
            )
        )
        self.flush()

    def flush(self):
        idx = self.im.svg_content.find("</svg>")
        svg_inner_content = self.draw.as_svg()
        svg_inner_content = re.sub("<.xml.*>", "", svg_inner_content)
        svg_inner_content = re.sub("<svg[^>]*>", "", svg_inner_content)
        svg_inner_content = re.sub("</svg.*>", "", svg_inner_content)
        self.im.svg_content = (
            self.im.svg_content[:idx] + svg_inner_content + self.im.svg_content[idx:]
        )
