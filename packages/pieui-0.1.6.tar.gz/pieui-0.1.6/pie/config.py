import os
from functools import lru_cache
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional
from dotenv import load_dotenv

load_dotenv()


@dataclass
class Settings:
    user_id: Optional[str] = field(default_factory=lambda: os.getenv("PIE_USER_ID"))
    api_key: Optional[str] = field(default_factory=lambda: os.getenv("PIE_API_KEY"))
    components_dir: Path = field(
        default_factory=lambda: Path(os.getenv("PIE_COMPONENTS_DIR", "pages/components"))
    )
    project_slug: str = field(default_factory=lambda: os.getenv("PIE_PROJECT_SLUG", Path.cwd().name))
    api_base_url: str = "https://cdn-pieui.swarm.ing/api"


@lru_cache
def get_settings() -> Settings:
    return Settings()
