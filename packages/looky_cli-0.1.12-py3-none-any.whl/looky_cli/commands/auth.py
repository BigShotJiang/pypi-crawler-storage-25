from __future__ import annotations

from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from looky_cli import config as cfg
from looky_cli.client import LookyClient, LookyClientError
from looky_cli.commands.billing import relogin_command, require_root_context

console = Console()
app = typer.Typer(help="Authenticate with a looky instance.")


@app.command("login")
def login(
    url: str = typer.Argument(..., help="Instance URL (e.g. https://looky.example.com)"),
    root_path: Path = typer.Argument(..., help="Local root path linked to this instance"),
    email: str = typer.Option(None, "--email", "-e", help="Email address registered in this looky instance"),
) -> None:
    """Log in to a looky instance via email OTP."""
    url = url.rstrip("/")
    linked_root = root_path.expanduser().resolve()
    if not linked_root.is_dir():
        console.print(f"[red]Root path not found: [bold]{linked_root}[/bold][/red]")
        raise typer.Exit(1)

    if not email:
        email = typer.prompt("Email")
    email = email.strip().lower()

    client = LookyClient(url=url)

    console.print(f"Sending verification code to [bold]{email}[/bold]…")
    try:
        start_result = client.otp_start(email)
    except LookyClientError as exc:
        console.print(f"[red]Error: {exc}[/red]")
        raise typer.Exit(1) from exc

    method_id: str = str(start_result.get("method_id") or "")
    project_type: str = str(start_result.get("project_type") or "consumer")

    console.print("Check your email for the verification code.")
    code = typer.prompt("Verification code")
    code = code.strip()

    try:
        auth_result = client.otp_authenticate(
            method_id=method_id,
            email=email if project_type == "b2b" else "",
            code=code,
        )
    except LookyClientError as exc:
        console.print(f"[red]Authentication failed: {exc}[/red]")
        raise typer.Exit(1) from exc

    cli_token = str(auth_result.get("cli_token") or "")
    cli_token_expires_at = str(auth_result.get("cli_token_expires_at") or "")
    app_user = auth_result.get("app_user") or {}

    if not cli_token:
        console.print("[red]Server did not return a CLI token. Make sure the server supports CLI auth.[/red]")
        raise typer.Exit(1)

    cfg.save_session(
        url,
        token=cli_token,
        expires_at=cli_token_expires_at,
        user=app_user,
    )
    try:
        cfg.bind_workspace_root(linked_root, url=url)
    except ValueError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(1) from exc

    console.print(f"[green]Logged in as [bold]{app_user.get('email', email)}[/bold][/green]")
    console.print(f"[dim]Linked root: [bold]{linked_root}[/bold] -> {url}[/dim]")
    _print_user_table(app_user)


@app.command("logout")
def logout() -> None:
    """Revoke the CLI token and clear local credentials."""
    root_context = require_root_context(Path.cwd(), exact_root=False)
    url = root_context.url
    token = root_context.token

    if token and url:
        client = LookyClient(url=url, token=token)
        try:
            client.revoke_token()
        except LookyClientError:
            pass

    cfg.clear_session(url)
    cfg.clear_root_billing_account_id(root_context.root_path)
    console.print(
        "[green]Logged out from "
        f"[bold]{url}[/bold] for linked root [bold]{root_context.root_path}[/bold].[/green]"
    )


@app.command("whoami")
def whoami() -> None:
    """Show the currently authenticated user."""
    root_context = require_root_context(Path.cwd(), exact_root=False)
    url = root_context.url
    token = root_context.token

    if not token:
        console.print(
            "[red]Not logged in for the linked root "
            f"[bold]{root_context.root_path}[/bold]. Run "
            f"[bold]looky login {url} {root_context.root_path}[/bold] first.[/red]"
        )
        raise typer.Exit(1)

    client = LookyClient(url=url, token=token)
    try:
        result = client.whoami()
    except LookyClientError as exc:
        if exc.status_code == 401:
            console.print(
                "[red]Token expired or revoked. Run "
                f"[bold]{relogin_command(root_context)}[/bold] again.[/red]"
            )
        else:
            console.print(f"[red]Error: {exc}[/red]")
        raise typer.Exit(1) from exc

    user = result.get("user") or {}
    console.print(
        f"[green]Authenticated on [bold]{url}[/bold] "
        f"for [bold]{root_context.root_path}[/bold][/green]"
    )
    _print_user_table(user)


def _print_user_table(user: dict) -> None:
    t = Table(show_header=False, box=None, padding=(0, 1))
    t.add_column(style="dim")
    t.add_column()
    if user.get("first_name") or user.get("last_name"):
        name = f"{user.get('first_name', '')} {user.get('last_name', '')}".strip()
        t.add_row("name", name)
    if user.get("email"):
        t.add_row("email", str(user["email"]))
    if user.get("role"):
        t.add_row("role", str(user["role"]))
    console.print(t)
