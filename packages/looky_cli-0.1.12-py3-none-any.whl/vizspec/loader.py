"""Load and expose all viz type schemas at import time.

Schemas live as JSON files in ``vizspec/schemas/viz.<type>.schema.json``.
The loader reads every file matching ``viz.*.schema.json``, extracts the
viz type from the filename, and exposes them as ``SCHEMAS_BY_TYPE``.

The shared envelope ``viz.base.schema.json`` is loaded separately and is
available as ``BASE_SCHEMA`` — it is not a viz type itself.
"""

from __future__ import annotations

import json
from pathlib import Path

_SCHEMAS_DIR = Path(__file__).parent / "schemas"

BASE_SCHEMA_FILENAME = "viz.base.schema.json"


def _load_json(path: Path) -> dict:
    with path.open(encoding="utf-8") as fh:
        return json.load(fh)


def _viz_type_from_filename(name: str) -> str:
    # ``viz.bar.schema.json`` → ``bar``; ``viz.report_matrix.schema.json`` → ``report_matrix``
    stem = name[len("viz."):-len(".schema.json")]
    return stem


def _load_all_schemas() -> tuple[dict, dict]:
    base: dict = {}
    by_type: dict[str, dict] = {}
    if not _SCHEMAS_DIR.is_dir():
        return base, by_type
    for path in sorted(_SCHEMAS_DIR.iterdir()):
        if not path.name.startswith("viz.") or not path.name.endswith(".schema.json"):
            continue
        if path.name == BASE_SCHEMA_FILENAME:
            base = _load_json(path)
            continue
        viz_type = _viz_type_from_filename(path.name)
        by_type[viz_type] = _load_json(path)
    return base, by_type


BASE_SCHEMA, SCHEMAS_BY_TYPE = _load_all_schemas()


def get_schema(viz_type: str) -> dict:
    """Return the JSON Schema for ``viz_type`` or raise ``KeyError``."""
    try:
        return SCHEMAS_BY_TYPE[viz_type]
    except KeyError as exc:
        known = ", ".join(sorted(SCHEMAS_BY_TYPE)) or "(none loaded)"
        raise KeyError(f"Unknown viz type: {viz_type!r}. Known types: {known}.") from exc
