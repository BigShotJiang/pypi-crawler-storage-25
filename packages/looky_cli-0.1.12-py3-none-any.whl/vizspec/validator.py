"""Validate a parsed ``vizSpec`` dict against its type's JSON Schema.

No "did you mean" hints, no deprecated-key suggestions, no backwards-compat
shims. The schema is the contract; errors are raw ``jsonschema`` messages
with the JSON path to the offending field.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from jsonschema import Draft202012Validator
from jsonschema.exceptions import ValidationError
from referencing import Registry, Resource
from referencing.jsonschema import DRAFT202012

from vizspec.loader import BASE_SCHEMA, SCHEMAS_BY_TYPE


@dataclass(frozen=True)
class ValidationIssue:
    """A single schema violation.

    ``path`` is a dotted path into the vizSpec (``"chart.legend.show"``) so
    downstream error renderers can point the user directly at the offending
    key. ``message`` is the raw ``jsonschema`` error text.
    """

    path: str
    message: str


def _format_path(error: ValidationError) -> str:
    parts: list[str] = []
    for token in error.absolute_path:
        if isinstance(token, int):
            parts.append(f"[{token}]")
        else:
            if parts:
                parts.append(f".{token}")
            else:
                parts.append(str(token))
    return "".join(parts) or "<root>"


def _known_types() -> list[str]:
    return sorted(SCHEMAS_BY_TYPE)


def _build_registry() -> Registry:
    """Registry of all loaded schemas, keyed by their relative filename.

    Per-type schemas use $ref: "viz.base.schema.json" to pull in the shared
    envelope + $defs. The registry maps that relative URI to the loaded
    resource.
    """
    resources = [
        ("viz.base.schema.json", Resource.from_contents(BASE_SCHEMA, default_specification=DRAFT202012)),
    ]
    for viz_type, schema in SCHEMAS_BY_TYPE.items():
        resources.append(
            (
                f"viz.{viz_type}.schema.json",
                Resource.from_contents(schema, default_specification=DRAFT202012),
            )
        )
    return Registry().with_resources(resources)


_REGISTRY = _build_registry() if SCHEMAS_BY_TYPE else Registry()


def validate_viz_spec(data: Any) -> list[ValidationIssue]:
    """Validate a parsed YAML dict and return all violations.

    Returns an empty list on success. Does not raise.

    The viz type is read from ``data["type"]``. If the type is absent or
    unknown, a single ``ValidationIssue`` describing that is returned and
    no schema validation is attempted.
    """
    if not isinstance(data, dict):
        return [ValidationIssue(path="<root>", message="vizSpec must be a mapping.")]

    viz_type = data.get("type")
    if not isinstance(viz_type, str) or not viz_type:
        return [ValidationIssue(path="type", message="Missing required 'type' string.")]

    schema = SCHEMAS_BY_TYPE.get(viz_type)
    if schema is None:
        return [
            ValidationIssue(
                path="type",
                message=f"Unknown viz type {viz_type!r}. Known types: {', '.join(_known_types())}.",
            )
        ]

    validator = Draft202012Validator(schema, registry=_REGISTRY)

    issues: list[ValidationIssue] = []
    for error in sorted(validator.iter_errors(data), key=lambda e: list(e.absolute_path)):
        issues.append(ValidationIssue(path=_format_path(error), message=error.message))
    return issues
