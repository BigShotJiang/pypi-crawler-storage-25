"""Canonical JSON Schema + validator for looky vizSpec YAMLs.

Single source of truth shared between the CLI (``looky validate`` / ``looky push``)
and the app backend (defensive validation on push receive).

Public surface:
- ``validate_viz_spec(data)`` — validate a parsed YAML dict; returns a list of
  ``ValidationIssue`` (empty list on success).
- ``SCHEMAS_BY_TYPE`` — mapping of viz type string (e.g. ``"bar"``) to its
  loaded JSON Schema dict.
- ``get_schema(viz_type)`` — look up one schema; raises ``KeyError`` on unknown
  type.
- ``ValidationIssue`` — dataclass describing a single schema violation.
"""

from vizspec.loader import SCHEMAS_BY_TYPE, get_schema
from vizspec.validator import ValidationIssue, validate_viz_spec

__all__ = [
    "SCHEMAS_BY_TYPE",
    "ValidationIssue",
    "get_schema",
    "validate_viz_spec",
]
