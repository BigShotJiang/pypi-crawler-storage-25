"""Well-test pressure-transient analysis.

Pressure buildup and drawdown interpretation tools for radial-flow
diagnostics: Bourdet log-time derivatives, Horner buildup plots, and
Miller-Dyes-Hutchinson semi-log analysis.

References:
    Bourdet, D., Whittle, T.M., Douglas, A.A., and Pirard, Y.M., "A New
        Set of Type Curves Simplifies Well Test Analysis," SPE 12777,
        1989.
    Horner, D.R., "Pressure Build-Up in Wells," Proceedings, Third World
        Petroleum Congress, 1951.
    Miller, C.C., Dyes, A.B., and Hutchinson, C.A., "The Estimation of
        Permeability and Reservoir Pressure from Bottom Hole Pressure
        Build-Up Characteristics," Trans. AIME 189, 1950.
    Lee, W.J. and Wattenbarger, R.A., Gas Reservoir Engineering, Ch. 7,
        1996.
"""

from __future__ import annotations

import numpy as np


def _as_matching_arrays(a: np.ndarray, b: np.ndarray, a_name: str, b_name: str) -> tuple[np.ndarray, np.ndarray]:
    """Convert two inputs to float arrays and verify matching shape."""
    a_arr = np.asarray(a, dtype=float)
    b_arr = np.asarray(b, dtype=float)
    if a_arr.shape != b_arr.shape:
        raise ValueError(f"{a_name} and {b_name} must have the same length")
    if a_arr.ndim != 1:
        raise ValueError(f"{a_name} and {b_name} must be 1-D arrays")
    return a_arr, b_arr


def _late_time_indices(size: int, fit_indices: np.ndarray | None) -> np.ndarray:
    """Return explicit fit indices, defaulting to the last half of a record."""
    if fit_indices is not None:
        idx = np.asarray(fit_indices, dtype=int)
        if idx.ndim != 1:
            raise ValueError("fit_indices must be a 1-D array")
        if idx.size < 2:
            raise ValueError("Need at least 2 fit points")
        if np.any((idx < 0) | (idx >= size)):
            raise ValueError("fit_indices contains out-of-range values")
        return idx

    start = size // 2
    idx = np.arange(start, size, dtype=int)
    if idx.size < 2:
        raise ValueError("Need at least 2 fit points")
    return idx


def _require_positive(name: str, value: float | None) -> float:
    """Return a positive scalar or raise ValueError."""
    if value is None:
        raise ValueError(f"{name} is required")
    value_float = float(value)
    if value_float <= 0:
        raise ValueError(f"{name} must be positive")
    return value_float


def bourdet_derivative(
    t: np.ndarray,
    dp: np.ndarray,
    L: float = 0.1,
) -> np.ndarray:
    """Bourdet (1989) pressure derivative on a logarithmic time scale.

    Returns ``t * dp/dt = dp/d(ln t)``, computed with the Bourdet weighted
    central-difference algorithm. For each interior point, left and right
    neighbors are chosen as the nearest samples that satisfy the log-time
    smoothing window ``L``. Boundary points and interior points where the
    requested ``L`` window cannot be satisfied return ``NaN``.

    Args:
        t: Time array, monotonically increasing and positive.
        dp: Pressure-change array, same length as ``t``.
        L: Log-time smoothing window. Typical values are 0.05 to 0.2.

    Returns:
        Numpy array with the same length as ``t`` containing ``dp/d(ln t)``.
        Boundary points where the ``L`` window cannot be satisfied are
        ``NaN``.

    Raises:
        ValueError: If ``t`` and ``dp`` have different lengths, if ``t`` is
            not strictly increasing and positive, or if ``L`` is negative.

    References: Bourdet et al. (1989) SPE 12777 Eq. 4.
    """
    t_arr, dp_arr = _as_matching_arrays(t, dp, "t", "dp")
    if t_arr.size == 0:
        raise ValueError("t must not be empty")
    if np.any(t_arr <= 0) or np.any(np.diff(t_arr) <= 0):
        raise ValueError("t must be strictly increasing and positive")
    if L < 0:
        raise ValueError("L must be non-negative")

    derivative = np.full(t_arr.shape, np.nan, dtype=float)
    if t_arr.size < 3:
        return derivative

    x = np.log(t_arr)
    for i in range(1, t_arr.size - 1):
        left_candidates = np.flatnonzero(x[i] - x[:i] >= L)
        right_candidates = np.flatnonzero(x[i + 1:] - x[i] >= L)
        if left_candidates.size == 0 or right_candidates.size == 0:
            continue

        j = int(left_candidates[-1])
        k = int(right_candidates[0] + i + 1)
        dx_left = x[i] - x[j]
        dx_right = x[k] - x[i]
        dpdt_left = (dp_arr[i] - dp_arr[j]) / dx_left
        dpdt_right = (dp_arr[k] - dp_arr[i]) / dx_right
        derivative[i] = (
            dpdt_left * dx_right + dpdt_right * dx_left
        ) / (dx_left + dx_right)

    return derivative


def horner_plot(
    dt: np.ndarray,
    pws: np.ndarray,
    tp: float,
    *,
    q: float | None = None,
    bo: float | None = None,
    mu: float | None = None,
    h: float | None = None,
    pwf_at_shutin: float | None = None,
    rw: float = 0.25,
    phi: float = 0.1,
    ct: float = 1e-5,
    fit_indices: np.ndarray | None = None,
) -> dict:
    """Horner (1951) semi-log buildup analysis.

    Regresses shut-in pressure against ``log10((tp + dt) / dt)`` over the
    late-time portion of the data. The line intercept at Horner time 1 is
    the extrapolated initial pressure. When ``q``, ``bo``, ``mu``, and ``h``
    are supplied, the result also includes ``kh``, ``k``, and ``p1hr``. Skin
    is only returned when ``pwf_at_shutin`` is provided.

    Args:
        dt: Shut-in time array (hours).
        pws: Shut-in pressure array (psi).
        tp: Producing time before shut-in (hours).
        q: Oil rate before shut-in (STB/day).
        bo: Oil formation volume factor (RB/STB).
        mu: Viscosity (cp).
        h: Net pay (ft).
        pwf_at_shutin: Flowing pressure immediately before shut-in (psi).
        rw: Wellbore radius (ft). Default 0.25.
        phi: Porosity fraction. Default 0.1.
        ct: Total compressibility (1/psi). Default 1e-5.
        fit_indices: Optional indices to use in the semi-log regression.

    Returns:
        Dict with ``horner_time``, ``slope``, ``intercept``, and
        ``fit_indices``. Optional reservoir-property fields are included
        when ``q``, ``bo``, ``mu``, and ``h`` are supplied.

    Raises:
        ValueError: If inputs are inconsistent or non-positive where
            positive values are required.

    References: Horner (1951); Lee-Wattenbarger Ch. 7.
    """
    dt_arr, pws_arr = _as_matching_arrays(dt, pws, "dt", "pws")
    if dt_arr.size < 2:
        raise ValueError("Need at least 2 data points")
    if np.any(dt_arr <= 0):
        raise ValueError("dt must be positive")
    if tp <= 0:
        raise ValueError("tp must be positive")

    horner_time = (float(tp) + dt_arr) / dt_arr
    x = np.log10(horner_time)
    idx = _late_time_indices(dt_arr.size, fit_indices)
    slope, intercept = np.polyfit(x[idx], pws_arr[idx], 1)
    slope = float(slope)
    intercept = float(intercept)

    result = {
        "horner_time": horner_time,
        "slope": slope,
        "intercept": intercept,
        "fit_indices": idx,
    }

    optional_supplied = any(value is not None for value in (q, bo, mu, h))
    if optional_supplied:
        q_val = _require_positive("q", q)
        bo_val = _require_positive("bo", bo)
        mu_val = _require_positive("mu", mu)
        h_val = _require_positive("h", h)
        if slope == 0:
            raise ValueError("slope must be non-zero to compute kh")
        if rw <= 0:
            raise ValueError("rw must be positive")
        if phi <= 0:
            raise ValueError("phi must be positive")
        if ct <= 0:
            raise ValueError("ct must be positive")

        kh = -162.6 * q_val * bo_val * mu_val / slope
        k = kh / h_val
        p1hr = slope * np.log10(float(tp) + 1.0) + intercept
        result.update({
            "kh": float(kh),
            "k": float(k),
            "p1hr": float(p1hr),
        })
        if pwf_at_shutin is not None:
            pwf = float(pwf_at_shutin)
            skin = 1.151 * (
                (p1hr - pwf) / abs(slope)
                - np.log10(k / (phi * mu_val * ct * rw**2))
                + 3.23
            )
            result["skin"] = float(skin)

    return result


def mdh_plot(
    dt: np.ndarray,
    pws: np.ndarray,
    q: float | None = None,
    bo: float | None = None,
    mu: float | None = None,
    h: float | None = None,
    *,
    fit_indices: np.ndarray | None = None,
) -> dict:
    """Miller-Dyes-Hutchinson semi-log analysis.

    Regresses shut-in pressure against ``log10(dt)`` over the late-time
    portion of the data. The slope gives the same radial-flow transmissibility
    as Horner analysis when producing time is long relative to shut-in time.

    Args:
        dt: Shut-in time array (hours).
        pws: Shut-in pressure array (psi).
        q: Oil rate before shut-in (STB/day).
        bo: Oil formation volume factor (RB/STB).
        mu: Viscosity (cp).
        h: Net pay (ft).
        fit_indices: Optional indices to use in the semi-log regression.

    Returns:
        Dict with ``log_dt``, ``slope``, ``intercept``, and ``fit_indices``.
        Optional ``kh`` and ``k`` fields are included when ``q``, ``bo``,
        ``mu``, and ``h`` are supplied.

    Raises:
        ValueError: If inputs are inconsistent or non-positive where
            positive values are required.

    References: Miller-Dyes-Hutchinson (1950) Trans. AIME 189.
    """
    dt_arr, pws_arr = _as_matching_arrays(dt, pws, "dt", "pws")
    if dt_arr.size < 2:
        raise ValueError("Need at least 2 data points")
    if np.any(dt_arr <= 0):
        raise ValueError("dt must be positive")

    log_dt = np.log10(dt_arr)
    idx = _late_time_indices(dt_arr.size, fit_indices)
    slope, intercept = np.polyfit(log_dt[idx], pws_arr[idx], 1)
    slope = float(slope)
    intercept = float(intercept)

    result = {
        "log_dt": log_dt,
        "slope": slope,
        "intercept": intercept,
        "fit_indices": idx,
    }

    optional_supplied = any(value is not None for value in (q, bo, mu, h))
    if optional_supplied:
        q_val = _require_positive("q", q)
        bo_val = _require_positive("bo", bo)
        mu_val = _require_positive("mu", mu)
        h_val = _require_positive("h", h)
        if slope == 0:
            raise ValueError("slope must be non-zero to compute kh")

        kh = 162.6 * q_val * bo_val * mu_val / slope
        result.update({
            "kh": float(kh),
            "k": float(kh / h_val),
        })

    return result
