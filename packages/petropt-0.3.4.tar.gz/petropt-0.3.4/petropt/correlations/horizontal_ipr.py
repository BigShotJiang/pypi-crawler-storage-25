"""Horizontal-well IPR and productivity correlations.

Implements:
    - Joshi (1988): Steady-state horizontal-well productivity
    - Babu-Odeh (1989): Box-shaped drainage-volume horizontal-well productivity

References:
    Joshi, S.D., "Augmentation of Well Productivity With Slant and
        Horizontal Wells," SPE 15375, 1988.
    Economides, M.J., Hill, A.D., Ehlig-Economides, C.A., and Zhu, D.,
        "Petroleum Production Systems," 2nd ed., 2013, Ch. 5.
    Babu, D.K. and Odeh, A.S., "Productivity of a Horizontal Well,"
        SPE Reservoir Engineering, Nov. 1989, pp. 417-421 (SPE 18334).
"""

from __future__ import annotations

import numpy as np


def _validate_positive(value: float | np.ndarray, name: str) -> None:
    if np.any(np.asarray(value, dtype=float) <= 0):
        raise ValueError(f"{name} must be positive, got {value}")


def _validate_non_negative(value: float | np.ndarray, name: str) -> None:
    if np.any(np.asarray(value, dtype=float) < 0):
        raise ValueError(f"{name} must be non-negative, got {value}")


def _to_output(value: float | np.ndarray) -> float | np.ndarray:
    arr = np.asarray(value)
    if arr.ndim == 0:
        return float(arr)
    return arr


def joshi_horizontal_pi(
    kh: float,
    h: float,
    mu: float,
    bo: float,
    L: float,
    reH: float,
    rw: float,
    skin: float = 0.0,
    kv_kh_ratio: float = 1.0,
    iani: float | None = None,
) -> dict:
    """Joshi (1988) horizontal-well productivity index.

    J_h = (0.007078 * kh * h) / (mu * Bo * denominator)

    Args:
        kh: Horizontal permeability in mD.
        h: Net pay thickness in ft.
        mu: Oil viscosity in cp.
        bo: Oil formation volume factor in RB/STB.
        L: Horizontal-well length in ft.
        reH: Horizontal-plane drainage radius in ft.
        rw: Wellbore radius in ft.
        skin: Total mechanical skin.
        kv_kh_ratio: Vertical-to-horizontal permeability ratio. Ignored when
            iani is provided.
        iani: Anisotropy ratio, sqrt(kh / kv). Overrides kv_kh_ratio.

    Returns:
        Dict with 'j_horizontal', 'j_vertical_equivalent', 'pi_ratio', and
        'a_half_axis'.

    Raises:
        ValueError: If inputs are outside the correlation's valid range.

    References: Joshi (1988) SPE 15375; Economides (2013) Eq. 5-8.
    """
    _validate_positive(kh, "horizontal permeability")
    _validate_positive(h, "net pay thickness")
    _validate_positive(mu, "oil viscosity")
    _validate_positive(bo, "oil FVF")
    _validate_positive(L, "horizontal-well length")
    _validate_positive(reH, "drainage radius")
    _validate_positive(rw, "wellbore radius")

    L_arr = np.asarray(L, dtype=float)
    reH_arr = np.asarray(reH, dtype=float)
    rw_arr = np.asarray(rw, dtype=float)
    if np.any(reH_arr <= L_arr / 2.0):
        raise ValueError("reH must be greater than L/2 for Joshi horizontal PI")
    if np.any(reH_arr <= rw_arr):
        raise ValueError("reH must be greater than rw for vertical-equivalent PI")

    if iani is None:
        _validate_positive(kv_kh_ratio, "kv_kh_ratio")
        iani_val = 1.0 / np.sqrt(np.asarray(kv_kh_ratio, dtype=float))
    else:
        _validate_positive(iani, "anisotropy ratio")
        iani_val = np.asarray(iani, dtype=float)

    a_half_axis = (L_arr / 2.0) * np.sqrt(
        0.5 + np.sqrt(0.25 + (2.0 * reH_arr / L_arr) ** 4)
    )
    half_length = L_arr / 2.0

    horizontal_shape = np.log(
        (a_half_axis + np.sqrt(a_half_axis**2 - half_length**2)) / half_length
    )
    vertical_shape = (iani_val * np.asarray(h, dtype=float) / L_arr) * np.log(
        iani_val * np.asarray(h, dtype=float) / (2.0 * rw_arr)
    )
    denominator = horizontal_shape + vertical_shape + skin
    if np.any(denominator <= 0):
        raise ValueError("Joshi productivity denominator must be positive")

    numerator = 0.007078 * np.asarray(kh, dtype=float) * np.asarray(h, dtype=float)
    J_horizontal = numerator / (
        np.asarray(mu, dtype=float) * np.asarray(bo, dtype=float) * denominator
    )
    J_vertical = numerator / (
        np.asarray(mu, dtype=float) * np.asarray(bo, dtype=float) * np.log(reH_arr / rw_arr)
    )

    return {
        "j_horizontal": _to_output(J_horizontal),
        "j_vertical_equivalent": _to_output(J_vertical),
        "pi_ratio": _to_output(J_horizontal / J_vertical),
        "a_half_axis": _to_output(a_half_axis),
    }


def joshi_horizontal_rate(
    kh: float,
    h: float,
    mu: float,
    bo: float,
    L: float,
    reH: float,
    rw: float,
    pr: float,
    pwf: float | np.ndarray,
    skin: float = 0.0,
    kv_kh_ratio: float = 1.0,
    iani: float | None = None,
) -> dict:
    """Steady-state oil rate from Joshi (1988).

    q = J_h * (Pr - Pwf)

    Args:
        kh: Horizontal permeability in mD.
        h: Net pay thickness in ft.
        mu: Oil viscosity in cp.
        bo: Oil formation volume factor in RB/STB.
        L: Horizontal-well length in ft.
        reH: Horizontal-plane drainage radius in ft.
        rw: Wellbore radius in ft.
        pr: Reservoir pressure in psi.
        pwf: Flowing bottomhole pressure in psi.
        skin: Total mechanical skin.
        kv_kh_ratio: Vertical-to-horizontal permeability ratio. Ignored when
            iani is provided.
        iani: Anisotropy ratio, sqrt(kh / kv). Overrides kv_kh_ratio.

    Returns:
        Dict with 'qo', 'j_horizontal', and 'pi_ratio'.

    Raises:
        ValueError: If inputs are outside the correlation's valid range.

    References: Joshi (1988); productivity x drawdown.
    """
    _validate_positive(pr, "reservoir pressure")
    _validate_non_negative(pwf, "flowing bottomhole pressure")

    pi_result = joshi_horizontal_pi(
        kh=kh,
        h=h,
        mu=mu,
        bo=bo,
        L=L,
        reH=reH,
        rw=rw,
        skin=skin,
        kv_kh_ratio=kv_kh_ratio,
        iani=iani,
    )
    drawdown = np.maximum(0.0, np.asarray(pr, dtype=float) - np.asarray(pwf, dtype=float))
    qo = np.asarray(pi_result["j_horizontal"]) * drawdown

    return {
        "qo": _to_output(qo),
        "j_horizontal": pi_result["j_horizontal"],
        "pi_ratio": pi_result["pi_ratio"],
    }


def babu_odeh_horizontal_pi(
    kx: float,
    ky: float,
    kz: float,
    a: float,
    b: float,
    h: float,
    L: float,
    x0: float | None = None,
    y0: float | None = None,
    z0: float | None = None,
    rw: float = 0.354,
    mu: float = 1.0,
    bo: float = 1.0,
    skin_partial: float = 0.0,
) -> dict:
    """Babu-Odeh (1989) productivity index for a horizontal well in a box.

    J = (0.007078 * sqrt(kx*kz) * b) /
        (mu * Bo * [ln(sqrt(A) / rw) + ln(C_H) - 0.75 + s_R])

    This implementation covers the fully penetrating case L = b. x0 and z0
    default to the centered location and may be supplied for off-center
    transverse placement. Partial penetration L < b requires Goode-Kuchuk
    pseudo-skin terms and is not implemented here.

    Args:
        kx: Permeability in the x-direction in mD.
        ky: Permeability in the y-direction in mD. Accepted for API symmetry;
            the fully penetrating Babu-Odeh form is independent of ky.
        kz: Permeability in the z-direction in mD.
        a: Drainage-box length in the x-direction in ft.
        b: Drainage-box length in the y-direction in ft.
        h: Drainage-box height in ft.
        L: Horizontal-well length in ft.
        x0: Well midpoint x-location in ft. Defaults to a/2.
        y0: Well midpoint y-location in ft. Defaults to b/2 and is accepted
            for API symmetry.
        z0: Well midpoint z-location in ft. Defaults to h/2.
        rw: Wellbore radius in ft.
        mu: Oil viscosity in cp.
        bo: Oil formation volume factor in RB/STB.
        skin_partial: Partial-penetration pseudo-skin. Must be zero for the
            implemented fully penetrating case.

    Returns:
        Dict with 'j_horizontal', 'ln_c_h', and 'geometric_skin'.

    Raises:
        ValueError: If inputs are nonphysical or the productivity denominator
            is not positive.
        NotImplementedError: If partial penetration is requested.

    References: Babu & Odeh (1989) SPE 18334 Eq. 3.
    """
    _validate_positive(kx, "x-direction permeability")
    _validate_positive(ky, "y-direction permeability")
    _validate_positive(kz, "z-direction permeability")
    _validate_positive(a, "x-direction drainage length")
    _validate_positive(b, "y-direction drainage length")
    _validate_positive(h, "drainage height")
    _validate_positive(L, "horizontal-well length")
    _validate_positive(rw, "wellbore radius")
    _validate_positive(mu, "oil viscosity")
    _validate_positive(bo, "oil FVF")

    if L < b and not np.isclose(L, b):
        raise NotImplementedError(
            "partial-penetration Babu-Odeh requires Goode-Kuchuk pseudo-skin "
            "terms s_R > 0; out of scope for v0.3.x — open an issue if you "
            "need this."
        )
    if L > b and not np.isclose(L, b):
        raise ValueError("horizontal-well length L must not exceed drainage length b")
    if skin_partial != 0.0:
        raise NotImplementedError(
            "partial-penetration Babu-Odeh requires Goode-Kuchuk pseudo-skin "
            "terms s_R > 0; out of scope for v0.3.x — open an issue if you "
            "need this."
        )

    x0_val = a / 2.0 if x0 is None else float(x0)
    y0_val = b / 2.0 if y0 is None else float(y0)
    z0_val = h / 2.0 if z0 is None else float(z0)
    if not (0.0 <= x0_val <= a):
        raise ValueError("x0 must be within the drainage length a")
    if not (0.0 <= y0_val <= b):
        raise ValueError("y0 must be within the drainage length b")
    if not (0.0 < z0_val < h):
        raise ValueError("z0 must be strictly inside the drainage height h")

    x_ratio = x0_val / a
    z_ratio = z0_val / h
    aspect_ratio = a / h
    ln_c_h = (
        6.28 * aspect_ratio * (1.0 / 3.0 - x_ratio + x_ratio**2)
        - np.log(np.sin(np.pi * z_ratio))
        - 0.5 * np.log(aspect_ratio * z_ratio * (1.0 - z_ratio))
        - 1.088
    )

    area = a * h
    s_R = 0.0
    geometric_skin = ln_c_h - 0.75 + s_R
    denominator = np.log(np.sqrt(area) / rw) + geometric_skin
    if denominator <= 0:
        raise ValueError("Babu-Odeh productivity denominator must be positive")

    J_horizontal = 0.007078 * np.sqrt(kx * kz) * b / (mu * bo * denominator)

    return {
        "j_horizontal": float(J_horizontal),
        "ln_c_h": float(ln_c_h),
        "geometric_skin": float(geometric_skin),
    }
