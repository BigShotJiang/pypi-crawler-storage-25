"""Buckley-Leverett waterflood correlations.

Implements:
    - Buckley and Leverett (1942): Water fractional flow
    - Welge (1952): Tangent construction for shock-front saturation
    - Displacement efficiency from average saturation behind the front

Reference:
    Dake, L.P., "Fundamentals of Reservoir Engineering," Elsevier, 1978,
    Ch. 10, Eq. 10.4.
    Welge, H.J., "A Simplified Method for Computing Oil Recovery by Gas or
    Water Drive," Trans. AIME, 195, 1952, pp. 91-98.
"""

from __future__ import annotations

from collections.abc import Callable

import numpy as np
from scipy.optimize import brentq


def _validate_saturation(sw: float | np.ndarray, name: str = "sw") -> np.ndarray:
    """Validate water saturation and return a float array."""
    sw_array = np.asarray(sw, dtype=float)
    if np.any(~np.isfinite(sw_array)):
        raise ValueError(f"{name} must be finite")
    if np.any((sw_array < 0.0) | (sw_array > 1.0)):
        raise ValueError(f"{name} must be in [0, 1]")
    return sw_array


def _validate_relperm(kr: float | np.ndarray, sw_shape: tuple[int, ...], name: str) -> np.ndarray:
    """Validate relative permeability values."""
    kr_array = np.asarray(kr, dtype=float)
    if kr_array.shape != sw_shape:
        try:
            kr_array = np.broadcast_to(kr_array, sw_shape)
        except ValueError as exc:
            raise ValueError(f"{name} must be scalar or match sw shape") from exc
    if np.any(~np.isfinite(kr_array)):
        raise ValueError(f"{name} must be finite")
    if np.any(kr_array < 0.0):
        raise ValueError(f"{name} must be non-negative")
    return kr_array


def _as_scalar_or_array(result: np.ndarray) -> float | np.ndarray:
    """Return scalar if input calculation was scalar."""
    return float(result) if result.ndim == 0 else result


def fractional_flow_water(
    sw: float | np.ndarray,
    kr_oil_func: Callable[[float | np.ndarray], float | np.ndarray],
    kr_water_func: Callable[[float | np.ndarray], float | np.ndarray],
    mu_oil: float,
    mu_water: float,
    gravity_term: float = 0.0,
) -> float | np.ndarray:
    """Buckley-Leverett fractional flow of water.

    fw(Sw) = 1 / (1 + (kro(Sw)/mu_o) / (krw(Sw)/mu_w))

    With optional gravity term G, the implemented correction is:
    fw = base_fw + G * (1 - base_fw)

    Args:
        sw: Water saturation, scalar or numpy array.
        kr_oil_func: Function returning oil relative permeability at sw.
        kr_water_func: Function returning water relative permeability at sw.
        mu_oil: Oil viscosity.
        mu_water: Water viscosity.
        gravity_term: Additive gravity correction term.

    Returns:
        Water fractional flow. Same shape as input sw.

    Raises:
        ValueError: If saturations, viscosities, gravity_term, or relative
            permeability values are invalid.

    References: Dake (1978) Eq. 10.4.
    """
    if not callable(kr_oil_func):
        raise ValueError("kr_oil_func must be callable")
    if not callable(kr_water_func):
        raise ValueError("kr_water_func must be callable")
    if mu_oil <= 0.0 or not np.isfinite(mu_oil):
        raise ValueError(f"mu_oil must be positive and finite, got {mu_oil}")
    if mu_water <= 0.0 or not np.isfinite(mu_water):
        raise ValueError(f"mu_water must be positive and finite, got {mu_water}")
    if not np.isfinite(gravity_term):
        raise ValueError(f"gravity_term must be finite, got {gravity_term}")

    sw_array = _validate_saturation(sw)
    kro = _validate_relperm(kr_oil_func(sw_array), sw_array.shape, "kr_oil")
    krw = _validate_relperm(kr_water_func(sw_array), sw_array.shape, "kr_water")

    with np.errstate(divide="ignore", invalid="ignore"):
        mobility_ratio_inverse = (kro * mu_water) / (krw * mu_oil)
        base_fw = 1.0 / (1.0 + mobility_ratio_inverse)

    base_fw = np.where(krw == 0.0, 0.0, base_fw)
    base_fw = np.where((kro == 0.0) & (krw > 0.0), 1.0, base_fw)
    if np.any(~np.isfinite(base_fw)):
        raise ValueError("fractional flow is undefined for the supplied relperms")

    fw = base_fw + gravity_term * (1.0 - base_fw)
    return _as_scalar_or_array(fw)


def fractional_flow_derivative(
    sw: float | np.ndarray,
    kr_oil_func: Callable[[float | np.ndarray], float | np.ndarray],
    kr_water_func: Callable[[float | np.ndarray], float | np.ndarray],
    mu_oil: float,
    mu_water: float,
    h: float = 1e-4,
    gravity_term: float = 0.0,
) -> float | np.ndarray:
    """Numerical derivative dfw/dSw via central difference.

    Args:
        sw: Water saturation, scalar or numpy array.
        kr_oil_func: Function returning oil relative permeability at sw.
        kr_water_func: Function returning water relative permeability at sw.
        mu_oil: Oil viscosity.
        mu_water: Water viscosity.
        h: Central-difference step in saturation units.
        gravity_term: Additive gravity correction term.

    Returns:
        Numerical derivative of water fractional flow. Same shape as input sw.

    Raises:
        ValueError: If h is invalid or central-difference points are outside
            the saturation interval [0, 1].

    References: numerical d/dSw of Dake Eq. 10.4.
    """
    if h <= 0.0 or not np.isfinite(h):
        raise ValueError(f"h must be positive and finite, got {h}")

    sw_array = _validate_saturation(sw)
    if np.any(sw_array - h < 0.0) or np.any(sw_array + h > 1.0):
        raise ValueError("central-difference points must remain in [0, 1]")

    fw_plus = fractional_flow_water(
        sw_array + h,
        kr_oil_func,
        kr_water_func,
        mu_oil,
        mu_water,
        gravity_term=gravity_term,
    )
    fw_minus = fractional_flow_water(
        sw_array - h,
        kr_oil_func,
        kr_water_func,
        mu_oil,
        mu_water,
        gravity_term=gravity_term,
    )
    derivative = (np.asarray(fw_plus) - np.asarray(fw_minus)) / (2.0 * h)
    return _as_scalar_or_array(derivative)


def welge_tangent(
    swc: float,
    sor: float,
    kr_oil_func: Callable[[float | np.ndarray], float | np.ndarray],
    kr_water_func: Callable[[float | np.ndarray], float | np.ndarray],
    mu_oil: float,
    mu_water: float,
    gravity_term: float = 0.0,
) -> dict:
    """Welge tangent construction to find shock-front saturation.

    Solves fw'(Swf) = (fw(Swf) - fw(Swc)) / (Swf - Swc), then calculates:
    Sw_avg = Swf + (1 - fw(Swf)) / fw'(Swf)

    Args:
        swc: Connate water saturation.
        sor: Residual oil saturation.
        kr_oil_func: Function returning oil relative permeability at sw.
        kr_water_func: Function returning water relative permeability at sw.
        mu_oil: Oil viscosity.
        mu_water: Water viscosity.
        gravity_term: Additive gravity correction term.

    Returns:
        Dict with keys:
            - "sw_front": water saturation at the shock front
            - "fw_front": water fractional flow at the shock front
            - "sw_avg": average water saturation behind the front
            - "breakthrough_pv": injected pore volumes at breakthrough

    Raises:
        ValueError: If endpoint saturations are invalid or no tangent root is
            found in the requested bracket.

    References: Welge (1952) Trans. AIME 195, pp. 91-98; Dake (1978) Ch. 10.
    """
    if swc < 0.0 or swc >= 1.0 or not np.isfinite(swc):
        raise ValueError(f"swc must be finite and in [0, 1), got {swc}")
    if sor < 0.0 or sor >= 1.0 or not np.isfinite(sor):
        raise ValueError(f"sor must be finite and in [0, 1), got {sor}")
    if swc + sor >= 1.0:
        raise ValueError(
            f"swc + sor must be < 1.0, got {swc} + {sor} = {swc + sor}"
        )

    lower = swc + 1e-3
    upper = 1.0 - sor - 1e-3
    if lower >= upper:
        raise ValueError("Welge tangent bracket is empty")

    fw_at_swc = float(
        fractional_flow_water(
            swc,
            kr_oil_func,
            kr_water_func,
            mu_oil,
            mu_water,
            gravity_term=gravity_term,
        )
    )

    def objective(sw_val: float) -> float:
        fw_val = fractional_flow_water(
            sw_val,
            kr_oil_func,
            kr_water_func,
            mu_oil,
            mu_water,
            gravity_term=gravity_term,
        )
        dfw_val = fractional_flow_derivative(
            sw_val,
            kr_oil_func,
            kr_water_func,
            mu_oil,
            mu_water,
            gravity_term=gravity_term,
        )
        return float(dfw_val) * (sw_val - swc) - (float(fw_val) - fw_at_swc)

    try:
        sw_front = brentq(objective, lower, upper)
    except ValueError as exc:
        raise ValueError("could not find Welge tangent root in saturation bracket") from exc

    fw_front = float(
        fractional_flow_water(
            sw_front,
            kr_oil_func,
            kr_water_func,
            mu_oil,
            mu_water,
            gravity_term=gravity_term,
        )
    )
    dfw_front = float(
        fractional_flow_derivative(
            sw_front,
            kr_oil_func,
            kr_water_func,
            mu_oil,
            mu_water,
            gravity_term=gravity_term,
        )
    )
    if dfw_front <= 0.0 or not np.isfinite(dfw_front):
        raise ValueError("Welge tangent derivative must be positive and finite")

    sw_avg = sw_front + (1.0 - fw_front) / dfw_front
    breakthrough_pv = 1.0 / dfw_front

    return {
        "sw_front": float(sw_front),
        "fw_front": fw_front,
        "sw_avg": float(sw_avg),
        "breakthrough_pv": float(breakthrough_pv),
    }


def waterflood_recovery(
    sw_avg: float,
    swc: float,
    sor: float,
) -> dict:
    """Recovery efficiency from average water saturation behind the front.

    Args:
        sw_avg: Average water saturation behind the front.
        swc: Connate water saturation.
        sor: Residual oil saturation.

    Returns:
        Dict with keys:
            - "displacement_efficiency": fraction of movable oil displaced
            - "movable_oil_fraction": initial movable oil fraction

    Raises:
        ValueError: If saturations are outside their physical ranges.

    References: Dake (1978) Eq. 10.5/10.6.
    """
    if swc < 0.0 or swc >= 1.0 or not np.isfinite(swc):
        raise ValueError(f"swc must be finite and in [0, 1), got {swc}")
    if sor < 0.0 or sor >= 1.0 or not np.isfinite(sor):
        raise ValueError(f"sor must be finite and in [0, 1), got {sor}")
    if swc + sor >= 1.0:
        raise ValueError(
            f"swc + sor must be < 1.0, got {swc} + {sor} = {swc + sor}"
        )
    if sw_avg < swc or sw_avg > 1.0 - sor or not np.isfinite(sw_avg):
        raise ValueError(f"sw_avg must be finite and in [{swc}, {1.0 - sor}]")

    movable_oil_fraction = 1.0 - swc - sor
    displacement_efficiency = (sw_avg - swc) / movable_oil_fraction

    return {
        "displacement_efficiency": float(displacement_efficiency),
        "movable_oil_fraction": float(movable_oil_fraction),
    }
