# Beyond petropt

petropt is MIT-licensed open source. Use it freely in commercial products,
research, classrooms, and AI applications. No copyleft restrictions, no
support contract required.

petropt is built and maintained by **Groundwork Analytics**, a product
company building AI tools, AI agents, and apps for the energy and oil &
gas industry. petropt is the open-source library at the base of that
stack.

## Products

- **[tools.petropt.com](https://tools.petropt.com)** — petroleum-engineering web calculators (decline curves, PVT, well economics, LAS viewer) powered by petropt.
- **[petro-mcp](https://pypi.org/project/petro-mcp/)** — MCP server that lets Claude / ChatGPT / other LLM clients call petropt directly. `pip install petro-mcp`.

## Get in touch

- Web: <https://petropt.com>
- Tools: <https://tools.petropt.com>
- Email: <info@petropt.com>
- GitHub issues (technical questions and bugs): <https://github.com/petropt/petropt/issues>
