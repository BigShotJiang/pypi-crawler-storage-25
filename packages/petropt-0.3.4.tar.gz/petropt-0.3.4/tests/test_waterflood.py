"""Tests for Buckley-Leverett waterflood correlations."""

import numpy as np
from petropt.correlations.relperm import brooks_corey_oil, brooks_corey_water
from petropt.correlations.waterflood import (
    fractional_flow_derivative,
    fractional_flow_water,
    waterflood_recovery,
    welge_tangent,
)


class TestFractionalFlow:
    def test_endpoints(self):
        """At Sw=Swc, fw=0; at Sw=1-Sor, fw=1."""
        swc = 0.2
        sor = 0.2
        kr_oil = lambda sw: brooks_corey_oil(sw, swc, sor, lam=2.0)
        kr_water = lambda sw: brooks_corey_water(sw, swc, sor, lam=2.0)

        fw_swc = fractional_flow_water(swc, kr_oil, kr_water, 2.0, 1.0)
        fw_sor = fractional_flow_water(1.0 - sor, kr_oil, kr_water, 2.0, 1.0)

        assert abs(fw_swc) < 0.01
        assert abs(fw_sor - 1.0) < 0.01

    def test_unfavorable_mobility(self):
        """Viscous oil increases fw at the same Sw for fixed relperms."""
        swc = 0.2
        sor = 0.2
        sw = 0.5
        kr_oil = lambda sw: brooks_corey_oil(sw, swc, sor, lam=2.0)
        kr_water = lambda sw: brooks_corey_water(sw, swc, sor, lam=2.0)

        fw_viscous_oil = fractional_flow_water(sw, kr_oil, kr_water, 10.0, 1.0)
        fw_favorable = fractional_flow_water(sw, kr_oil, kr_water, 1.0, 1.0)

        assert fw_viscous_oil > fw_favorable

    def test_array_input(self):
        swc = 0.2
        sor = 0.2
        sw = np.linspace(swc, 1.0 - sor, 20)
        kr_oil = lambda sw: brooks_corey_oil(sw, swc, sor, lam=2.0)
        kr_water = lambda sw: brooks_corey_water(sw, swc, sor, lam=2.0)

        fw = fractional_flow_water(sw, kr_oil, kr_water, 2.0, 1.0)

        assert isinstance(fw, np.ndarray)
        assert fw.shape == sw.shape
        assert all(fw[i] <= fw[i + 1] for i in range(len(fw) - 1))

    def test_derivative_against_analytical(self):
        """For quadratic relperms with Swc=Sor=0 and M=1, dfw/dSw=2 at Sw=0.5."""
        kr_oil = lambda sw: (1.0 - sw) ** 2
        kr_water = lambda sw: sw**2

        derivative = fractional_flow_derivative(0.5, kr_oil, kr_water, 1.0, 1.0)

        assert np.isclose(derivative, 2.0, rtol=1e-2)

    def test_derivative_threads_gravity_term(self):
        """Gravity correction should be included in central-difference calls."""
        kr_oil = lambda sw: (1.0 - sw) ** 2
        kr_water = lambda sw: sw**2

        derivative = fractional_flow_derivative(
            0.5,
            kr_oil,
            kr_water,
            1.0,
            1.0,
            gravity_term=0.2,
        )

        assert np.isclose(derivative, 1.6, rtol=1e-2)


class TestWelgeTangent:
    def test_basic_brooks_corey(self):
        swc = 0.2
        sor = 0.2
        kr_oil = lambda sw: brooks_corey_oil(sw, swc, sor, lam=2.0)
        kr_water = lambda sw: brooks_corey_water(sw, swc, sor, lam=2.0)

        result = welge_tangent(swc, sor, kr_oil, kr_water, 2.0, 1.0)

        assert swc < result["sw_front"] < 1.0 - sor
        assert 0.0 < result["fw_front"] < 1.0
        assert result["sw_avg"] > result["sw_front"]

    def test_dake_textbook_case(self):
        """Quadratic relperms, Swc=0.2, Sor=0.2, mu_o/mu_w=2, krw_end=0.4."""
        swc = 0.2
        sor = 0.2
        kr_oil = lambda sw: (1.0 - (sw - swc) / (1.0 - swc - sor)) ** 2
        kr_water = lambda sw: 0.4 * ((sw - swc) / (1.0 - swc - sor)) ** 2

        result = welge_tangent(swc, sor, kr_oil, kr_water, 2.0, 1.0)

        assert np.isclose(result["sw_front"], 0.65, atol=0.05)

    def test_invariant_sw_avg_greater(self):
        swc = 0.2
        sor = 0.2
        kr_oil = lambda sw: brooks_corey_oil(sw, swc, sor, lam=2.0)
        kr_water = lambda sw: brooks_corey_water(sw, swc, sor, lam=2.0)

        result = welge_tangent(swc, sor, kr_oil, kr_water, 2.0, 1.0)

        assert result["sw_avg"] > result["sw_front"]

    def test_breakthrough_pv_positive(self):
        swc = 0.2
        sor = 0.2
        kr_oil = lambda sw: brooks_corey_oil(sw, swc, sor, lam=2.0)
        kr_water = lambda sw: brooks_corey_water(sw, swc, sor, lam=2.0)

        result = welge_tangent(swc, sor, kr_oil, kr_water, 2.0, 1.0)

        assert result["breakthrough_pv"] > 0.0
        assert np.isfinite(result["breakthrough_pv"])

    def test_nonzero_fwc_objective(self):
        swc = 0.2
        sor = 0.2
        kr_oil = lambda sw: (1.0 - (sw - swc) / (1.0 - swc - sor)) ** 2
        kr_water = lambda sw: 0.02 + 0.4 * ((sw - swc) / (1.0 - swc - sor)) ** 2

        result = welge_tangent(swc, sor, kr_oil, kr_water, 2.0, 1.0)

        assert swc < result["sw_front"] < 1.0 - sor


class TestWaterfloodRecovery:
    def test_at_residual(self):
        result = waterflood_recovery(sw_avg=0.8, swc=0.2, sor=0.2)

        assert result["displacement_efficiency"] == 1.0

    def test_at_connate(self):
        result = waterflood_recovery(sw_avg=0.2, swc=0.2, sor=0.2)

        assert result["displacement_efficiency"] == 0.0

    def test_intermediate(self):
        swc = 0.2
        sor = 0.2
        sw_avg = (swc + (1.0 - sor)) / 2.0

        result = waterflood_recovery(sw_avg, swc, sor)

        assert np.isclose(result["displacement_efficiency"], 0.5)
