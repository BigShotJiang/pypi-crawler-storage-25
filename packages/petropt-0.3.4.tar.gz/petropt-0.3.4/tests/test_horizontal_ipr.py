"""Tests for horizontal-well IPR correlations."""

import numpy as np
import pytest

from petropt.correlations.horizontal_ipr import (
    babu_odeh_horizontal_pi,
    joshi_horizontal_pi,
    joshi_horizontal_rate,
)


class TestJoshi:
    def test_pi_ratio_long_well(self):
        """A long horizontal well should outperform a vertical well."""
        result = joshi_horizontal_pi(
            kh=10,
            h=50,
            mu=1,
            bo=1,
            L=2000,
            reH=2000,
            rw=0.354,
        )
        assert result["pi_ratio"] > 1

    def test_pi_decreases_with_anisotropy(self):
        """Lower vertical permeability should reduce horizontal-well PI."""
        isotropic = joshi_horizontal_pi(
            kh=10,
            h=50,
            mu=1,
            bo=1,
            L=2000,
            reH=2000,
            rw=0.354,
            iani=1,
        )
        anisotropic = joshi_horizontal_pi(
            kh=10,
            h=50,
            mu=1,
            bo=1,
            L=2000,
            reH=2000,
            rw=0.354,
            iani=3,
        )
        assert anisotropic["pi_ratio"] < isotropic["pi_ratio"]

    def test_skin_reduces_pi(self):
        """Positive mechanical skin should reduce horizontal-well PI."""
        base = joshi_horizontal_pi(
            kh=10,
            h=50,
            mu=1,
            bo=1,
            L=2000,
            reH=2000,
            rw=0.354,
        )
        damaged = joshi_horizontal_pi(
            kh=10,
            h=50,
            mu=1,
            bo=1,
            L=2000,
            reH=2000,
            rw=0.354,
            skin=5,
        )
        assert damaged["j_horizontal"] < base["j_horizontal"]

    def test_economides_textbook_value(self):
        """Joshi worked case gives J = 1.07 STB/day/psi for this form.

        This case uses the Economides Ch. 5 horizontal-well data with
        kh=8.2 mD, kv=0.9 mD, h=53 ft, L=2000 ft, reH=1490 ft,
        rw=0.328 ft, mu=1.7 cp, Bo=1.1, and skin=0. The expected value
        is computed from the implemented Joshi denominator using the
        field-unit constant 0.007078.
        """
        result = joshi_horizontal_pi(
            kh=8.2,
            h=53,
            mu=1.7,
            bo=1.1,
            L=2000,
            reH=1490,
            rw=0.328,
            iani=(8.2 / 0.9) ** 0.5,
        )
        assert result["j_horizontal"] == pytest.approx(1.07, rel=0.01)

    def test_l_greater_than_2reh_raises(self):
        """Drainage radius must exceed horizontal-well half-length."""
        with pytest.raises(ValueError, match="reH"):
            joshi_horizontal_pi(
                kh=10,
                h=50,
                mu=1,
                bo=1,
                L=2000,
                reH=500,
                rw=0.354,
            )

    def test_qo_proportional_to_drawdown(self):
        """Twice the drawdown should give twice the steady-state rate."""
        low_drawdown = joshi_horizontal_rate(
            kh=10,
            h=50,
            mu=1,
            bo=1,
            L=2000,
            reH=2000,
            rw=0.354,
            pr=3000,
            pwf=2500,
        )
        high_drawdown = joshi_horizontal_rate(
            kh=10,
            h=50,
            mu=1,
            bo=1,
            L=2000,
            reH=2000,
            rw=0.354,
            pr=3000,
            pwf=2000,
        )
        assert high_drawdown["qo"] == pytest.approx(2.0 * low_drawdown["qo"])

    def test_pwf_above_pr_clamps_to_zero(self):
        """Zero or negative drawdown should not produce a negative rate."""
        result = joshi_horizontal_rate(
            kh=10,
            h=50,
            mu=1,
            bo=1,
            L=2000,
            reH=2000,
            rw=0.354,
            pr=3000,
            pwf=3100,
        )
        assert result["qo"] == 0.0


class TestBabuOdeh:
    @staticmethod
    def _ln_c_h(a, h, x0, z0):
        x_ratio = x0 / a
        z_ratio = z0 / h
        return (
            6.28 * (a / h) * (1.0 / 3.0 - x_ratio + x_ratio**2)
            - np.log(np.sin(np.pi * z_ratio))
            - 0.5 * np.log((a / h) * z_ratio * (1.0 - z_ratio))
            - 1.088
        )

    def test_centered_isotropic(self):
        """Centered, fully penetrating Babu-Odeh case should match ln(C_H)."""
        a = 2000.0
        h = 50.0
        result = babu_odeh_horizontal_pi(
            kx=10,
            ky=10,
            kz=10,
            a=a,
            b=2000,
            h=h,
            L=2000,
            x0=a / 2.0,
            y0=1000,
            z0=h / 2.0,
            rw=0.354,
            mu=1,
            bo=1.1,
        )
        assert result["j_horizontal"] > 0
        assert result["ln_c_h"] == pytest.approx(
            self._ln_c_h(a, h, a / 2.0, h / 2.0),
            rel=1e-3,
        )

    def test_anisotropic_kx_vs_kz(self):
        """Doubling transverse kx should increase J by sqrt(2)."""
        base = babu_odeh_horizontal_pi(
            kx=10,
            ky=10,
            kz=10,
            a=2000,
            b=2000,
            h=50,
            L=2000,
            x0=1000,
            y0=1000,
            z0=25,
            rw=0.354,
            mu=1,
            bo=1.1,
        )
        doubled_kx = babu_odeh_horizontal_pi(
            kx=20,
            ky=10,
            kz=10,
            a=2000,
            b=2000,
            h=50,
            L=2000,
            x0=1000,
            y0=1000,
            z0=25,
            rw=0.354,
            mu=1,
            bo=1.1,
        )

        assert doubled_kx["j_horizontal"] / base["j_horizontal"] == pytest.approx(
            np.sqrt(2.0),
            rel=0.02,
        )

    def test_partial_penetration_raises(self):
        """Partial penetration requires Goode-Kuchuk pseudo-skin terms."""
        with pytest.raises(NotImplementedError, match="partial-penetration"):
            babu_odeh_horizontal_pi(
                kx=10,
                ky=10,
                kz=10,
                a=2000,
                b=2000,
                h=50,
                L=1500,
                x0=1000,
                y0=1000,
                z0=25,
                rw=0.354,
                mu=1,
                bo=1.1,
            )

    def test_off_center_z(self):
        """Off-center z placement should change ln(C_H)."""
        centered = babu_odeh_horizontal_pi(
            kx=10,
            ky=10,
            kz=10,
            a=2000,
            b=2000,
            h=50,
            L=2000,
            x0=1000,
            y0=1000,
            z0=25,
            rw=0.354,
            mu=1,
            bo=1.1,
        )
        off_center_z = babu_odeh_horizontal_pi(
            kx=10,
            ky=10,
            kz=10,
            a=2000,
            b=2000,
            h=50,
            L=2000,
            x0=1000,
            y0=1000,
            z0=12.5,
            rw=0.354,
            mu=1,
            bo=1.1,
        )
        assert off_center_z["ln_c_h"] != pytest.approx(centered["ln_c_h"])
