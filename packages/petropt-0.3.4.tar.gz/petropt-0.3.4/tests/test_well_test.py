"""Tests for well-test pressure-transient analysis tools."""

import numpy as np
import pytest

from petropt.rta.well_test import bourdet_derivative, horner_plot, mdh_plot


class TestBourdetDerivative:
    def test_radial_flow_synthetic(self):
        t = np.logspace(-2, 2, 50)
        m_target = 50.0
        dp = m_target * np.log(t)

        derivative = bourdet_derivative(t, dp)
        valid = np.isfinite(derivative)

        np.testing.assert_allclose(derivative[valid], m_target, rtol=0.1)

    def test_linear_flow_signature(self):
        t = np.logspace(-2, 2, 50)
        c = 20.0
        dp = c * np.sqrt(t)

        derivative = bourdet_derivative(t, dp)
        valid = np.isfinite(derivative)

        np.testing.assert_allclose(derivative[valid] / dp[valid], 0.5, rtol=0.1)

    def test_length_mismatch_raises(self):
        with pytest.raises(ValueError):
            bourdet_derivative(np.array([1.0, 2.0]), np.array([1.0]))

    def test_non_monotonic_raises(self):
        with pytest.raises(ValueError):
            bourdet_derivative(
                np.array([1.0, 3.0, 2.0]),
                np.array([10.0, 20.0, 30.0]),
            )

    def test_returns_correct_length(self):
        t = np.logspace(-2, 2, 50)
        dp = 10.0 * np.log(t)

        derivative = bourdet_derivative(t, dp)

        assert derivative.size == t.size

    def test_boundary_nan(self):
        t = np.array([1.0, 2.0])
        dp = np.array([10.0, 20.0])

        derivative = bourdet_derivative(t, dp)

        assert np.isnan(derivative[0])
        assert np.isnan(derivative[-1])


class TestHornerPlot:
    def test_radial_flow_recovers_kh(self):
        k = 50.0
        h = 30.0
        mu = 1.0
        q = 500.0
        bo = 1.2
        tp = 100.0
        pi = 3000.0
        dt = np.logspace(-1, 2, 30)
        pws = pi - 162.6 * q * bo * mu / (k * h) * np.log10((tp + dt) / dt)

        result = horner_plot(dt, pws, tp, q=q, bo=bo, mu=mu, h=h)

        assert result["kh"] == pytest.approx(k * h, rel=0.05)

    def test_returns_horner_time(self):
        dt = np.array([1.0, 2.0, 4.0])
        pws = np.array([2500.0, 2600.0, 2700.0])
        tp = 100.0

        result = horner_plot(dt, pws, tp)

        np.testing.assert_allclose(result["horner_time"], (tp + dt) / dt)

    def test_p1hr_finite(self):
        k = 50.0
        h = 30.0
        mu = 1.0
        q = 500.0
        bo = 1.2
        tp = 100.0
        pi = 3000.0
        dt = np.logspace(-1, 2, 30)
        pws = pi - 162.6 * q * bo * mu / (k * h) * np.log10((tp + dt) / dt)

        result = horner_plot(dt, pws, tp, q=q, bo=bo, mu=mu, h=h)

        assert np.isfinite(result["p1hr"])
        assert "skin" not in result

    def test_zero_skin_synthetic(self):
        pi = 5000.0
        k = 50.0
        h = 30.0
        mu = 1.0
        q = 500.0
        bo = 1.2
        phi = 0.15
        ct = 1e-5
        rw = 0.354
        tp = 100.0
        dt = np.logspace(-1, 2, 40)
        slope_magnitude = 162.6 * q * bo * mu / (k * h)
        pws = pi - slope_magnitude * np.log10((tp + dt) / dt)

        p1hr = pi - slope_magnitude * np.log10(tp + 1.0)
        log_term = np.log10(k / (phi * mu * ct * rw**2))
        pwf_at_shutin = p1hr - slope_magnitude * (log_term - 3.23)

        result = horner_plot(
            dt,
            pws,
            tp,
            q=q,
            bo=bo,
            mu=mu,
            h=h,
            pwf_at_shutin=pwf_at_shutin,
            rw=rw,
            phi=phi,
            ct=ct,
        )

        assert result["skin"] == pytest.approx(0.0, abs=0.05)

    def test_no_optional_inputs(self):
        dt = np.logspace(-1, 2, 30)
        tp = 100.0
        pws = 3000.0 - 10.0 * np.log10((tp + dt) / dt)

        result = horner_plot(dt, pws, tp)

        assert "kh" not in result
        assert "skin" not in result


class TestMDHPlot:
    def test_radial_recovery_kh(self):
        k = 50.0
        h = 30.0
        mu = 1.0
        q = 500.0
        bo = 1.2
        tp = 10000.0
        pi = 3000.0
        dt = np.logspace(-2, 1, 30)
        pws = pi - 162.6 * q * bo * mu / (k * h) * np.log10((tp + dt) / dt)

        result = mdh_plot(dt, pws, q=q, bo=bo, mu=mu, h=h)

        assert result["kh"] == pytest.approx(k * h, rel=0.05)

    def test_log_dt_returned(self):
        dt = np.array([1.0, 10.0, 100.0])
        pws = np.array([2500.0, 2600.0, 2700.0])

        result = mdh_plot(dt, pws)

        np.testing.assert_allclose(result["log_dt"], np.log10(dt))
