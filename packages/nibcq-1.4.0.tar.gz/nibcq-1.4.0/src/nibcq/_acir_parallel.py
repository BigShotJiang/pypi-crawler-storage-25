"""Defines the Parallel ACIR measurement for the nibcq package."""

import cmath
import contextlib
import math
import os
from collections.abc import Iterator, Sequence
from typing import override

import nidcpower

from nibcq._acir import (
    ACIR,
    ACIRTestParameters,
    DFTFeatures,
    SMUGenerationParameters,
    SMUInputParameters,
    SMUMeasurementParameters,
    SMUResult,
)
from nibcq._device import Device
from nibcq.compensation import Compensation, CompensationFile, CompensationMethod
from nibcq.constants import DEFAULT_COMPENSATION_DIR
from nibcq.enums import InterpolationMode, MultiDeviceMode
from nibcq.errors import (
    CompensationMethodError,
    FrequencyError,
    TestSessionMismatchError,
)
from nibcq.measurement import ParallelMeasurement, SMUMeasurement


class ParallelACIR(ParallelMeasurement, ACIR):
    """Defines an ACIR measurement with multiple SMUs working in parallel.

    This class enables AC impedance measurements using multiple SMU devices connected
    in parallel to achieve higher current amplitudes than a single SMU can provide.

    Unlike single-device ACIR measurements, parallel ACIR does NOT support switching
    configurations due to hardware current limitations of switch matrices (typically
    limited to ~2A). Parallel ACIR is designed for direct-connection, high-current
    testing scenarios.

    Key Features:
        - Multiple SMUs synchronized via hardware triggers (PXI backplane).
        - Current capacity scales linearly with number of devices (e.g., 3 SMUs = 3x current).
        - Voltage measured from leader device (4-wire sense for accuracy).
        - Current contributions summed across all devices.
        - Single frequency measurement per run (frequency sweep requires EIS).

    Hardware Requirements:
        - All devices must be NI PXIe-4139 or compatible SMUs.
        - Devices must be in the same PXI chassis for trigger routing.
        - One device designated as leader, others as followers.

    Example:
        >>> leader_device = Device.create(DeviceFamily.SMU, "PXI1Slot2")
        >>> follower1 = Device.create(DeviceFamily.SMU, "PXI1Slot3")
        >>>
        >>> params = ACIRTestParameters(
        ...     current_amplitude=4.0,
        ...     powerline_frequency=PowerlineFrequency.FREQ_50_HZ,
        ... )
        >>>
        >>> parallel_acir = ParallelACIR(
        ...     leader=leader_device,
        ...     followers=[follower1],
        ...     test_parameters=params,
        ...     test_frequency=1000.0,
        ... )
        >>>
        >>> compensation = parallel_acir.load_compensation_file()
        >>> result = parallel_acir.run(compensation)
        >>> print(f"Impedance: {result.impedance}")
    """

    def __init__(
        self,
        leader: Device,
        followers: Sequence[Device],
        test_parameters: ACIRTestParameters,
        test_frequency: float = 1000.0,
        multi_device_type: MultiDeviceMode = MultiDeviceMode.PARALLEL,
    ):
        """Initialize Parallel ACIR measurement with an explicit leader and follower devices.

        Args:
            leader (Device): The single SMU device that acts as the timing source
                and provides remote-sense voltage data.
            followers (Sequence[Device]): An ordered collection of SMU devices that
                synchronise to the leader via start-trigger signals.
            test_parameters (ACIRTestParameters): ACIR-specific test configuration including
                current amplitude, voltage limits, number of periods, and compensation method.
            test_frequency (float): Measurement frequency in Hz. Must be between
                0 (exclusive) and ACIR.FREQUENCY_LIMIT (inclusive). Defaults to 1000.0 Hz.
            multi_device_type (MultiDeviceMode): How the devices share the load current.
                Defaults to ``MultiDeviceMode.PARALLEL``.

        Raises:
            TypeError: If the leader or any follower is not a ``Device`` instance.
            TestSessionMismatchError: If any supplied device is not an SMU.
        """
        ParallelMeasurement.__init__(self, leader, followers, test_parameters)

        # Ensure every device belongs to the SMU family.
        for device in self.get_all_devices():
            if device.device_family is not ACIR.DEVICE_FAMILY:
                raise TestSessionMismatchError(
                    f"{device.product} (family={device.device_family.name}) "
                    f"is not supported by the Cell Quality Toolkit for an ACIR test; "
                    f"ACIR requires a {ACIR.DEVICE_FAMILY.name} device."
                )

        # --- Initialize ACIR-compatible internal state ---
        # These mirror the single-device ACIR __init__ exactly,
        # so _configure() and helper methods can reuse ACIR logic.
        self._generation_input_parameters = SMUInputParameters()
        self._generation_input_parameters.frequency_sweep_characteristics = {}

        self._calculated_generation_parameters = SMUGenerationParameters()
        self._calculated_generation_parameters.generated_sinusoidal_waveform = []

        self._calculated_measurement_parameters = SMUMeasurementParameters()
        self._calculated_measurement_parameters.dut_voltage = []
        self._calculated_measurement_parameters.dut_temperature = []

        # Initialize measurement storage aligned with device list by index
        self._raw_measurement_data: list[SMUMeasurement | None] = [None] * (
            len(self._followers) + 1
        )

        # Use ACIR property setters which perform validation and populate
        # frequency_sweep_characteristics dictionary.
        self.current_frequency = test_frequency
        self.test_parameters = test_parameters

        # Parallel-specific state
        self.multi_device_type = multi_device_type
        self._multidevice_measurement_data: SMUMeasurement | None = None
        self._result: SMUResult | None = None

    # ================================================================
    # Properties
    # ================================================================

    @property
    def all_measurement_data(self) -> Iterator[tuple[Device, SMUMeasurement | None]]:
        """Get raw measurement data from all individual devices.

        Returns per-device voltage and current measurements as captured during
        the measurement phase, before the parallel multidevice operation is applied.

        Returns:
            Iterator[tuple[Device, SMUMeasurement | None]]: Iterator of tuples pairing each
                Device with its corresponding SMUMeasurement. Yields tuples
                with None measurements if no measurement has been performed yet.

        Example:
            >>> for device, measurement in parallel_acir.all_measurement_data:
            ...     print(f"Device: {device.product}")
            ...     print(f"Voltage samples: {len(measurement.voltage_values)}")
        """
        return zip(self.get_all_devices(), self._raw_measurement_data)

    @property
    def calibration_file_paths(self) -> list[tuple[Device, str]]:
        """Get the default calibration file paths for all parallel devices.

        Returns a list of tuples pairing each Device with its default
        calibration diary file path. Calibration is managed per-device via the
        Calibrator class, so this property simply aggregates the paths.

        Returns:
            list[tuple[Device, str]]: List of (device, path) tuples.
        """
        return [(device, device.default_calibration_path) for device in self.get_all_devices()]

    @property
    @override
    def measurement_data(self) -> SMUMeasurement:
        """Get sanitized multidevice measurement data after parallel combination.

        Applies the same signal conditioning as single-device ACIR.
        First, edge effects are removed for frequencies above 60 Hz with more
        than 10 periods by trimming the first two periods from the signal.
        Then DC offset is removed by subtracting the mean from both voltage
        and current waveforms to center them around zero.

        In parallel mode, voltage values come from the leader device
        (4-wire remote sense) and current values are the sum of all
        devices' individual currents.

        Returns:
            SMUMeasurement: Sanitized combined measurement data, or None if
                no multidevice data is available yet.
        """
        if self._multidevice_measurement_data is None:
            return None

        voltage_measurements = list(self._multidevice_measurement_data.voltage_values)
        current_measurements = list(self._multidevice_measurement_data.current_values)

        # Remove edge effects for high-frequency measurements with many periods.
        # Same logic as ACIR.measurement_data property.
        number_of_periods = self._generation_input_parameters.frequency_sweep_characteristics[
            self.current_frequency
        ].number_of_periods
        if self.current_frequency > 60 and number_of_periods > 10:
            first_period = self._calculated_generation_parameters.first_period_number_of_samples - 1
            voltage_measurements = voltage_measurements[2 * first_period :]
            current_measurements = current_measurements[2 * first_period :]

        # DC offset removal — centers signals around zero for accurate DFT analysis.
        if voltage_measurements:
            voltage_mean = sum(voltage_measurements) / len(voltage_measurements)
            voltage_measurements = [v - voltage_mean for v in voltage_measurements]

        if current_measurements:
            current_mean = sum(current_measurements) / len(current_measurements)
            current_measurements = [i - current_mean for i in current_measurements]

        return SMUMeasurement(
            tone_frequency=self._multidevice_measurement_data.tone_frequency,
            voltage_values=voltage_measurements,
            current_values=current_measurements,
        )

    # ================================================================
    # Terminal name builder (parallel-specific override)
    # ================================================================

    def _build_terminal_name(
        self,
        target_device: Device,
        channel_name: int | str,
        local_terminal_name: str,
    ) -> str:
        """Build a fully qualified PXI trigger terminal name.

        Uses the target device's IO resource descriptor to construct terminal
        paths used for hardware trigger routing between parallel SMU devices.

        This follows the same pattern as ParallelDCIR._build_terminal_name,
        but accepts any device (not just the leader) because each device needs
        its own SourceCompleteEvent terminal for the measure trigger.

        Args:
            target_device: The device whose resource descriptor forms the
                base of the terminal path.
            channel_name: The channel/engine identifier (typically 0).
            local_terminal_name: The terminal event name
                (e.g., "SourceCompleteEvent", "StartTrigger").

        Returns:
            str: Formatted terminal name.
                Example: "/PXI1Slot2/Engine0/SourceCompleteEvent"

        Raises:
            RuntimeError: If target_device has no active session.
        """
        if not target_device or not target_device.session:
            raise RuntimeError("Target device is not initialized or has no active session.")
        return (
            "/"
            + target_device.session.io_resource_descriptor
            + "/Engine"
            + str(channel_name)
            + "/"
            + str(local_terminal_name)
        )

    # ================================================================
    # Compensation file path generation (parallel-specific override)
    # ================================================================

    @override
    def generate_compensation_file_path(self) -> str:
        """Generate compensation file path for parallel ACIR measurement.

        Uses the leader device's serial number with parallel-specific naming:
        ``z_{method}_Leader_SN{serial_number}.json``

        This differs from single-device ACIR which uses:
        ``z_{method}_{serial_number}.json``

        The parallel naming convention makes it clear which device was the leader
        during compensation data collection.

        Returns:
            str: The generated file path for compensation data, or None if no
                compensation is needed.

        Raises:
            CompensationMethodError: If compensation_method is not supported.
        """
        compensation_method = self._test_parameters.compensation_method

        if compensation_method == CompensationMethod.NO_COMPENSATION:
            return None

        if compensation_method not in (CompensationMethod.SHORT, CompensationMethod.GOLDEN_DUT):
            raise CompensationMethodError(
                f"Compensation method '{compensation_method.value}' is not supported by the "
                f"nibcq Python API. Supported methods are: {CompensationMethod.SHORT.value}, "
                f"{CompensationMethod.GOLDEN_DUT.value}, "
                f"{CompensationMethod.NO_COMPENSATION.value}"
            )

        # Use leader serial number (strip leading zeros for NI convention).
        leader_serial = self.device.serial_number.lstrip("0")
        filename = f"z_{compensation_method.value}_Leader_SN{leader_serial}.json"
        return os.path.join(DEFAULT_COMPENSATION_DIR, filename)

    # ================================================================
    # Multidevice data population
    # ================================================================

    def _populate_multidevice_measurement_data(self, data_point_count: int):
        """Combine per-device measurements into a single multidevice dataset.

        For PARALLEL multidevice configuration:
        - Voltage comes from the leader device only (remote sense accuracy).
        - Current is the sum of all devices' current measurements.

        Args:
            data_point_count: Expected number of data points per device.

        Raises:
            IndexError: If any device has a mismatched sample count.
            NotImplementedError: If multidevice configuration type is not PARALLEL.
        """
        # Validate sample counts across all devices.
        for idx, measurement in enumerate(self._raw_measurement_data):
            if measurement is not None:
                if len(measurement.voltage_values) != data_point_count:
                    raise IndexError(
                        f"Device at index {idx} has {len(measurement.voltage_values)} "
                        f"voltage samples, expected {data_point_count}."
                    )
                if len(measurement.current_values) != data_point_count:
                    raise IndexError(
                        f"Device at index {idx} has {len(measurement.current_values)} "
                        f"current samples, expected {data_point_count}."
                    )

        if self.multi_device_type is not MultiDeviceMode.PARALLEL:
            raise NotImplementedError(
                "Only MultiDeviceMode.PARALLEL is currently supported for ParallelACIR."
            )

        # Leader provides voltage (4-wire remote sense).
        leader_idx = len(self._followers)  # By convention, leader is last amongst the devices.
        multidevice_voltage = list(self._raw_measurement_data[leader_idx].voltage_values)

        # Sum currents from all devices.
        multidevice_current = [0.0] * data_point_count
        for measurement in self._raw_measurement_data:
            if measurement is not None:
                multidevice_current = [
                    total + device_current
                    for total, device_current in zip(
                        multidevice_current, measurement.current_values, strict=True
                    )
                ]

        self._multidevice_measurement_data = SMUMeasurement(
            tone_frequency=self.current_frequency,
            voltage_values=multidevice_voltage,
            current_values=multidevice_current,
        )

    # ================================================================
    # Configure
    # ================================================================

    @staticmethod
    def _determine_bandwidth(number_of_devices: int) -> int:
        """Determine the bandwidth for the current amplitude adjustment based on device count.

        The bandwidth value controls how aggressively the current amplitude is corrected
        at higher frequencies. Fewer devices allow a wider bandwidth (less correction),
        while more devices require a narrower bandwidth (more correction).

        Args:
            number_of_devices: Total number of parallel SMU devices (leader + followers).

        Returns:
            The bandwidth value in Hz used for the amplitude adjustment formula.

        Examples:
            >>> ParallelACIR._determine_bandwidth(1)
            30000
            >>> ParallelACIR._determine_bandwidth(2)
            20000
            >>> ParallelACIR._determine_bandwidth(4)
            16000
        """
        if number_of_devices == 1:
            return 30000
        elif number_of_devices <= 3:
            return 20000
        else:
            return 16000

    @staticmethod
    def _adjust_current_amplitude(
        current_amplitude: float,
        configured_frequency: float,
        bandwidth: int,
    ) -> float:
        """Adjust the current amplitude based on configured frequency and bandwidth.

        Applies a low-pass correction factor to the current amplitude to compensate for
        frequency-dependent signal attenuation in parallel SMU configurations.

        The formula is::

            adjusted = current_amplitude / sqrt((configured_frequency / bandwidth)^2 + 1)

        Args:
            current_amplitude: The original current amplitude in amperes.
            configured_frequency: The configured measurement frequency in Hz.
            bandwidth: The bandwidth value in Hz, determined by the number of devices.

        Returns:
            The adjusted current amplitude in amperes.

        Examples:
            >>> ParallelACIR._adjust_current_amplitude(3.0, 1000.0, 20000)
            2.9962...
        """
        return current_amplitude / math.sqrt((configured_frequency / bandwidth) ** 2 + 1)

    def _configure(self):
        """Configure all parallel SMU devices for synchronized ACIR measurement.

        This method replicates the single-device ACIR._configure() logic, but applies
        it across multiple parallel SMU devices with these key differences:

        1. Current amplitude is divided equally among all devices in the group.
        2. Each device gets its own SourceCompleteEvent-based measure trigger.
        3. Follower devices receive their start trigger from the leader's StartTrigger.
        4. The leader is always configured last (NI parallel convention).

        The calculation steps (sample rate, number of samples, aperture time, waveform
        generation) are performed once and shared across all devices, since all devices
        must use identical timing parameters for proper synchronization.

        Raises:
            FrequencyError: If frequency is not set or parameters produce too many samples.
            CurrentAmplitudeError: If per-device current amplitude is out of range.
            SMUParameterError: If hardware rejects any configured parameter.
        """
        # ---------------------------------------------------------------
        # Step 1: Calculate parameters (mirrors ACIR._configure() steps).
        # ---------------------------------------------------------------
        if self.current_frequency is None:
            raise FrequencyError("Measurement cannot run without a set current waveform frequency.")

        if self.multi_device_type is not MultiDeviceMode.PARALLEL:
            raise NotImplementedError(
                f"Only {MultiDeviceMode.PARALLEL.value} MultiDeviceMode is currently supported, "
                f"but '{self.multi_device_type.value}' was provided."
            )

        number_of_devices = len(self._followers) + 1

        # Adjust current amplitude for frequency-dependent attenuation in parallel configs.
        current_amplitude = self.test_parameters.current_amplitude
        configured_frequency = self.current_frequency
        bandwidth = self._determine_bandwidth(number_of_devices)
        adjusted_current_amplitude = self._adjust_current_amplitude(
            current_amplitude, configured_frequency, bandwidth
        )

        # Divide adjusted current amplitude equally among parallel devices.
        per_device_current_amplitude = adjusted_current_amplitude / number_of_devices

        # Validate per-device amplitude (each SMU must stay within its own limits).
        ACIR.validate_current_amplitude(configured_frequency, per_device_current_amplitude)

        gen_params = self._calculated_generation_parameters
        mes_params = self._calculated_measurement_parameters

        # Sample rate — same as single-device ACIR, frequency-dependent.
        mes_params.sample_rate = self._determine_sample_rate()

        # Number of samples — same formula as single-device ACIR.
        total_samples, first_period_samples = self._calculate_number_of_samples()
        mes_params.number_of_samples = total_samples
        gen_params.first_period_number_of_samples = first_period_samples

        # Timing parameters — derived from sample rate.
        mes_params.aperture_time = 1.0 / mes_params.sample_rate
        gen_params.sinusoidal_pattern_dt = 1.0 / mes_params.sample_rate
        gen_params.timeout_value = mes_params.number_of_samples / mes_params.sample_rate + 1

        # Temporarily set per-device amplitude in frequency_sweep_characteristics
        # so ACIR's _generate_waveform() and _determine_current_level_range() operate
        # on the divided value. This avoids duplicating waveform and range logic,
        # ensuring future changes in ACIR automatically propagate here.
        freq_set = self._generation_input_parameters.frequency_sweep_characteristics[
            self.current_frequency
        ]
        original_amplitude = freq_set.current_amplitude
        freq_set.current_amplitude = per_device_current_amplitude

        # Generate waveform — reuses ACIR._generate_waveform() with per-device amplitude.
        gen_params.generated_sinusoidal_waveform = self._generate_waveform()

        # Voltage range — same logic as single-device ACIR.
        gen_params.voltage_range = self._determine_voltage_limit_range()

        # Current level range — reuses ACIR._determine_current_level_range() with
        # the per-device amplitude already set in frequency_sweep_characteristics.
        per_device_current_level_range = self._determine_current_level_range()
        gen_params.current_range = per_device_current_level_range

        # Restore original (total) amplitude after helper methods have been called.
        freq_set.current_amplitude = original_amplitude

        # ---------------------------------------------------------------
        # Step 2: Configure each device (followers first, leader last).
        # ---------------------------------------------------------------
        leader_start_trigger_terminal = self._build_terminal_name(self._leader, 0, "StartTrigger")

        for device in self.get_all_devices():
            session: nidcpower.Session = device.session
            is_leader = device is self._leader

            # --- Measurement properties (identical for all devices) ---
            # Each device's measure trigger fires from its own SourceCompleteEvent.
            device_measure_trigger = self._build_terminal_name(device, 0, "SourceCompleteEvent")

            session.measure_when = nidcpower.MeasureWhen.ON_MEASURE_TRIGGER
            session.measure_trigger_type = nidcpower.TriggerType.DIGITAL_EDGE
            session.digital_edge_measure_trigger_input_terminal = device_measure_trigger
            session.aperture_time_units = nidcpower.ApertureTimeUnits.SECONDS
            session.aperture_time = mes_params.aperture_time
            session.measure_record_length = mes_params.number_of_samples
            session.power_line_frequency = self.test_parameters.powerline_frequency.value
            # In parallel ACIR, only the leader uses REMOTE sense (4-wire) for accurate
            # voltage measurement. Followers use LOCAL sense since their voltage readings
            # are not used — only their current contributions are summed.
            # This differs from single-device ACIR where the sole device always uses REMOTE.
            session.sense = nidcpower.Sense.REMOTE if is_leader else nidcpower.Sense.LOCAL
            session.dc_noise_rejection = nidcpower.DCNoiseRejection.NORMAL
            session.measure_complete_event_delay = 0
            # Disable autorange to ensure consistent measurement ranges across all
            # synchronized devices in the parallel gang. This prevents mid-measurement
            # range switching that would break trigger timing and make current summation
            # impossible due to different scaling factors per device.
            session.autorange = False

            # --- Generation properties (current-source mode, sinusoidal sequence) ---
            # set_sequence must come before generation properties that depend on
            # source_mode being SEQUENCE (mirrors single-device ACIR order).
            session.set_sequence(
                values=gen_params.generated_sinusoidal_waveform,
                source_delays=[0] * mes_params.number_of_samples,
            )

            session.output_function = self._generation_input_parameters.output_function.value
            session.source_mode = nidcpower.SourceMode.SEQUENCE
            session.current_limit_autorange = False
            session.transient_response = nidcpower.TransientResponse.NORMAL
            session.current_level_range = per_device_current_level_range
            session.voltage_limit = self._generation_input_parameters.voltage_limit_hi
            session.voltage_limit_range = gen_params.voltage_range
            session.source_delay = 0
            session.output_resistance = 1000
            session.sequence_step_delta_time_enabled = True
            session.sequence_step_delta_time = gen_params.sinusoidal_pattern_dt

            # --- Trigger synchronization ---
            # Followers sync their start to the leader's StartTrigger terminal.
            # The leader uses default trigger (software/immediate).
            if not is_leader:
                session.start_trigger_type = nidcpower.TriggerType.DIGITAL_EDGE
                session.digital_edge_start_trigger_input_terminal = leader_start_trigger_terminal

        # ---------------------------------------------------------------
        # Step 3: Commit and enable outputs (followers first, leader last).
        # ---------------------------------------------------------------
        for device in self.get_all_devices():
            session: nidcpower.Session = device.session
            session.commit()
            if not session.output_connected:
                session.output_connected = True

        # ---------------------------------------------------------------
        # Step 4: Retrieve actual hardware values from leader.
        # The hardware may quantize dt or sample count to valid discrete values.
        # ---------------------------------------------------------------
        leader_session: nidcpower.Session = self._leader.session
        raw_delta_time = self._delta_to_seconds(leader_session.measure_record_delta_time)
        mes_params.actual_measurement_record_dt = raw_delta_time
        mes_params.number_of_samples = leader_session.measure_record_length

    # ================================================================
    # Measure
    # ================================================================

    def _measure(self):
        """Execute synchronized measurement across all parallel devices.

        Workflow:
        1. Initiate all devices (followers first, leader last — leader's start
           trigger fires the followers).
        2. Wait for SEQUENCE_ENGINE_DONE on all devices (the sequence engine
           finishing means all waveform steps have been sourced and measured).
        3. Fetch raw voltage/current data from each device.
        4. Abort sourcing on all devices.
        5. Combine per-device data into a single multidevice measurement
           (leader voltage, summed currents).

        Raises:
            RuntimeError: If any device fails during initiation or data fetch.
            nidcpower.errors.DriverError: If hardware communication fails.
        """
        # Clear previous measurements to allow re-run.
        self._raw_measurement_data = [None] * (len(self._followers) + 1)

        timeout = self._calculated_generation_parameters.timeout_value

        # Initiate all devices: followers first, then leader (leader triggers all).
        for device in self.get_all_devices():
            device.session.initiate()

        # Wait for all devices to complete their sequence.
        for device in self.get_all_devices():
            device.session.wait_for_event(
                event_id=nidcpower.Event.SEQUENCE_ENGINE_DONE,
                timeout=timeout,
            )

        # Fetch data from all devices.
        number_of_samples = self._calculated_measurement_parameters.number_of_samples

        for idx, device in enumerate(self.get_all_devices()):
            session: nidcpower.Session = device.session

            # fetch_multiple returns list of Measurement namedtuples
            # with fields: voltage, current, in_compliance, channel
            measurements = session.fetch_multiple(count=number_of_samples)

            self._raw_measurement_data[idx] = SMUMeasurement(
                tone_frequency=self.current_frequency,
                voltage_values=[m.voltage for m in measurements],
                current_values=[m.current for m in measurements],
            )

        # Abort sourcing on all devices (followers first, leader last).
        for device in self.get_all_devices():
            device.session.abort()

        # Combine per-device measurements into multidevice result.
        self._populate_multidevice_measurement_data(number_of_samples)

    # ================================================================
    # Run
    # ================================================================

    def run(self, compensation: Compensation) -> SMUResult:
        """Execute the complete parallel ACIR measurement workflow.

        Full measurement cycle:
        1. Validate temperature if compensation requires it.
        2. Lock all device sessions via a shared ExitStack context manager.
        3. Configure all devices for synchronized ACIR measurement.
        4. Execute the measurement (initiate, fetch, gang).
        5. Perform DFT-based impedance calculation on the multidevice waveform.
        6. Apply compensation to the raw impedance result.
        7. Release all session locks (guaranteed even if an earlier step raised).

        Args:
            compensation (Compensation): Compensation data for error correction. Supports
                NO_COMPENSATION, SHORT, and GOLDEN_DUT methods, matching
                the single-device ACIR workflow.

        Returns:
            SMUResult: Measurement result containing the compensated complex impedance,
                magnitude, phase, real and imaginary components.

        Raises:
            FrequencyError: If frequency or test parameters are invalid.
            SMUParameterError: If device configuration fails.
            CompensationMethodError: If compensation data is incompatible.
            RuntimeError: If measurement or DFT analysis fails.

        Example:
            >>> compensation = parallel_acir.load_compensation_file()
            >>> result = parallel_acir.run(compensation)
            >>> print(f"Impedance magnitude: {result.z:.4f} Ohms")
        """
        # Validate temperature if compensation specifies a target temperature.
        if compensation.target_temperature is not None and (
            not math.isnan(compensation.target_temperature.center)
        ):
            self.validate_temperature(compensation.target_temperature)

        # Use ExitStack to enter each session's lock context manager. This guarantees that:
        # - If any lock() call raises an exception, all already-acquired locks are released.
        # - After the block exits (normally or via exception), every acquired lock is released
        #   even if one or more releases fail, because ExitStack calls __exit__ on all entered
        #   contexts before propagating any exception.
        with contextlib.ExitStack() as stack:
            for device in self.get_all_devices():
                stack.enter_context(device.session.lock())

            # Configure hardware.
            self._configure()

            # Execute measurement and populate multidevice data.
            self._measure()

            # DFT analysis on the multidevice (combined) waveform.
            # Uses the sanitized measurement_data property (inherited from ACIR)
            # which applies DC offset removal and edge-effect trimming.
            # Note: measurement_data now returns _multidevice_measurement_data via our override.
            dft_features: DFTFeatures = self._calculate_impedance(
                voltage_signal=self.measurement_data.voltage_values,
                current_signal=self.measurement_data.current_values,
            )

            # Update tone frequency with the detected value from DFT.
            self._multidevice_measurement_data.tone_frequency = dft_features.tone_frequency
            self._calculated_generation_parameters.measured_frequency = dft_features.tone_frequency

            # Calculate raw impedance phasor.
            impedance_phasor = dft_features.voltage_phasor / dft_features.current_phasor

            # Apply compensation (same method as single-device ACIR).
            compensated_impedance = compensation.get_compensated_impedance(
                frequency=dft_features.tone_frequency,
                measured_impedance=impedance_phasor,
            )

            # Package results.
            single_result = SMUResult(
                measured_frequency=dft_features.tone_frequency,
                impedance=compensated_impedance,
                r=compensated_impedance.real,
                x=compensated_impedance.imag,
                z=abs(compensated_impedance),
                theta=math.degrees(cmath.phase(compensated_impedance)),
            )

            self._result = single_result
            return single_result

    # ================================================================
    # Switching is NOT supported for parallel ACIR
    # ================================================================

    # ================================================================
    # Compensation file writing (parallel session locking override)
    # ================================================================

    @override
    def write_compensation_file(
        self,
        compensation_file_path: str | None = None,
        kit_file_path: str | None = None,
        comment: str | None = None,
    ) -> str:
        """Create a compensation file for the parallel ACIR measurement setup.

        Same workflow as single-device ACIR, but locks all device sessions via a
        shared ExitStack during the measurement to prevent concurrent access. The
        compensation file is saved based on the leader device's serial number.

        Args:
            compensation_file_path (str, optional): Optional file path for the compensation data.
                If None, auto-generates path using leader serial number.
            kit_file_path (str, optional): Optional path to known impedance table for KIT
                compensation subtraction.
            comment (str, optional): Optional comment to embed in the compensation file.

        Returns:
            str: Path to the created compensation file.

        Raises:
            CompensationMethodError: If NO_COMPENSATION is selected or method
                is unsupported.
            FrequencyError: If the test frequency is out of range.
            SMUParameterError: If device configuration or measurement fails.
        """
        base_conv_file_path = self.generate_compensation_file_path()
        if compensation_file_path is None:
            compensation_file_path = base_conv_file_path

        if self.test_parameters.compensation_method == CompensationMethod.NO_COMPENSATION:
            raise CompensationMethodError(
                f"You must select a compensation method other than "
                f"{CompensationMethod.NO_COMPENSATION.value} to create a compensation file."
            )
        # Measure temperature (optional capability, handled by TemperatureAware mixin).
        self.measure_temperature()

        # Use ExitStack to enter each session's lock context manager. This guarantees that:
        # - If any lock() call raises an exception, all already-acquired locks are released.
        # - After the block exits (normally or via exception), every acquired lock is released
        #   even if one or more releases fail, because ExitStack calls __exit__ on all entered
        #   contexts before propagating any exception.
        with contextlib.ExitStack() as stack:
            for device in self.get_all_devices():
                stack.enter_context(device.session.lock())

            self._configure()
            self._measure()

            # Calculate impedance from multidevice data (parallel _measure does not
            # return SMUResult directly like single-device ACIR).
            dft_features: DFTFeatures = self._calculate_impedance(
                voltage_signal=self.measurement_data.voltage_values,
                current_signal=self.measurement_data.current_values,
            )
            impedance_phasor = dft_features.voltage_phasor / dft_features.current_phasor

        # Build Compensation object.
        compensation = Compensation(
            compensation_method=self.test_parameters.compensation_method,
            compensation_file_path=compensation_file_path,
            target_temperature=self.temperature_range,
            compensation_parameters={self.current_frequency: impedance_phasor},
        )

        # Apply KIT correction if applicable.
        if self.test_parameters.compensation_method == CompensationMethod.SHORT and kit_file_path:
            self._apply_kit_compensation(compensation, kit_file_path, InterpolationMode.NEAREST)

        # Persist to file.
        new_file = CompensationFile.memory_to_file(compensation=compensation, comment=comment)
        new_file.save_to_file(compensation_file_path)

        return compensation_file_path

    # ================================================================
    # Switching is NOT supported for parallel ACIR
    # ================================================================

    @override
    def run_with_switching(self, compensation=None):
        """Parallel ACIR does not support switching.

        Switching support is limited to 3A, which a single SMU can already
        provide. For current targets up to 3A, use single-device ACIR with
        switching instead.

        Raises:
            NotImplementedError: Always raised.
        """
        raise NotImplementedError(
            "ParallelACIR does not support switching. "
            "Switching support is limited to 3A; for targets within that range, "
            "use single-device ACIR with switching instead."
        )
