"""LCR Meter compensation generation module for nibcq package.

This module provides the compensation generation functionality for the NI PXIe-4190
LCR Meter. The compensation data is stored on the device's onboard memory and can
be used by LCRACIR measurements.

The module contains:
- LCRCompensationParameters: Configuration dataclass for compensation generation
- perform_lcr_compensation(): Helper function implementing the 7-step compensation flow
"""

import json
from dataclasses import dataclass, field
from typing import Any, Dict, List

import nidcpower

from nibcq.errors import LCRParameterError
from nibcq.measurement import ConfigFileSupport

# Default timeout for LCR compensation verification measurement (same as LCRACIR)
DEFAULT_COMPENSATION_TIMEOUT: float = 21.0


def parse_cable_length(cable_length_str: str) -> nidcpower.CableLength:
    """Convert a cable length string into a nidcpower.CableLength enum value.

    Args:
        cable_length_str (str): Human-readable cable length string from configuration,
            for example "1m", "2m triaxial", or "custom onboard".

    Returns:
        nidcpower.CableLength: The corresponding :class:`nidcpower.CableLength` enum value.

    Raises:
        LCRParameterError: If the provided cable length string is not supported.

    Examples:
        >>> parse_cable_length("1m")
        <CableLength.NI_STANDARD_1M: ...>
    """
    cable_length_map = {
        "0m": nidcpower.CableLength.ZERO_M,
        "0.5m": nidcpower.CableLength.NI_STANDARD_0_5M,
        "1m": nidcpower.CableLength.NI_STANDARD_1M,
        "2m": nidcpower.CableLength.NI_STANDARD_2M,
        "4m": nidcpower.CableLength.NI_STANDARD_4M,
        "1m triaxial": nidcpower.CableLength.NI_STANDARD_TRIAXIAL_1M,
        "2m triaxial": nidcpower.CableLength.NI_STANDARD_TRIAXIAL_2M,
        "4m triaxial": nidcpower.CableLength.NI_STANDARD_TRIAXIAL_4M,
        "custom onboard": nidcpower.CableLength.CUSTOM_ONBOARD_STORAGE,
        "custom as configured": nidcpower.CableLength.CUSTOM_AS_CONFIGURED,
    }
    try:
        return cable_length_map[cable_length_str]
    except KeyError as exc:
        raise LCRParameterError(f"Unsupported cable length: {cable_length_str}") from exc


@dataclass
class LCRCompensationParameters(ConfigFileSupport):
    """Parameters for LCR compensation generation.

    This dataclass contains all configuration needed for the 7-step LCR
    compensation flow. The compensation data is stored on the device's
    onboard memory (not in external files).

    The parameters are divided into two groups:

    **Generate flags** - control which `perform_lcr_*()` methods run:
        - generate_custom_cable: Custom cable compensation (Step 2)
        - generate_open: Open compensation (Step 4)
        - generate_short: Short compensation (Step 4)
        - generate_load: Load compensation (Step 5)

    **Enable flags** - set on session for measurements after compensation:
        - enable_open: Use open compensation from onboard storage
        - enable_short: Use short compensation from onboard storage
        - enable_load: Use load compensation (requires open AND short!)

    Attributes:
        generate_custom_cable (bool): If True, performs custom cable compensation.
            Requires physical open and short connections during procedure.
        generate_open (bool): If True, performs open compensation.
            Requires physical open connection (no DUT).
        generate_short (bool): If True, performs short compensation.
            Requires physical short connection.
        generate_load (bool): If True, performs load compensation.
            Requires physical load connection with known reference.
        enable_open (bool): Enable open compensation for verification measurement.
        enable_short (bool): Enable short compensation for verification measurement.
        enable_load (bool): Enable load compensation for verification measurement.
            Note: Requires both enable_open AND enable_short to be True!
        short_custom_cable_enabled (bool): Also perform short custom cable comp (Step 2b).
        additional_frequencies (list[float]): Extra frequencies for open/short compensation.
            Default frequencies are always included by the hardware.
        load_compensation_spots (list[nidcpower.LCRLoadCompensationSpot]):
            Reference values for load compensation.
            Each spot specifies frequency and known impedance value.
        cable_length (nidcpower.CableLength): Cable length setting for all compensation steps.
        voltage_amplitude (float): LCR voltage amplitude in Volts RMS (for load comp).
        impedance_range (float): LCR impedance range in Ohms. 0 = auto-range.
        dc_bias_source (nidcpower.LCRDCBiasSource):
            DC bias source setting (OFF, VOLTAGE, or CURRENT).
        dc_bias_voltage_level (float): DC bias voltage if source=VOLTAGE.
        dc_bias_current_level (float): DC bias current if source=CURRENT.
        measurement_time (nidcpower.LCRMeasurementTime):
            Measurement time setting (SHORT, MEDIUM, LONG, CUSTOM).
        custom_measurement_time (float): Custom time in seconds if measurement_time=CUSTOM.
        lcr_frequency (float): Measurement frequency in Hz. 1000 Hz for ACIR, variable for EIS.

    Examples:
        >>> # Simple open+short compensation
        >>> params = LCRCompensationParameters(
        ...     generate_open=True,
        ...     generate_short=True,
        ...     enable_open=True,
        ...     enable_short=True,
        ... )
        >>>
        >>> # Full compensation with load
        >>> params = LCRCompensationParameters(
        ...     generate_open=True,
        ...     generate_short=True,
        ...     generate_load=True,
        ...     enable_open=True,
        ...     enable_short=True,
        ...     enable_load=True,
        ...     load_compensation_spots=[
        ...         nidcpower.LCRLoadCompensationSpot(
        ...             frequency=1000.0,
        ...             reference_value_type=nidcpower.LCRReferenceValueType.IMPEDANCE,
        ...             reference_value=complex(0.01, 0.0),  # 10 mOhm known load
        ...         ),
        ...     ],
        ... )
    """

    # Generate flags - control which perform_lcr_* methods run
    generate_custom_cable: bool = False
    generate_open: bool = True
    generate_short: bool = True
    generate_load: bool = False

    # Enable flags - applied during measurement configuration
    enable_open: bool = True
    enable_short: bool = True
    enable_load: bool = False

    # Custom cable options (Step 2)
    short_custom_cable_enabled: bool = False

    # Open/Short options (Step 4)
    additional_frequencies: List[float] = field(default_factory=list)

    # Load options (Step 5)
    load_compensation_spots: List[nidcpower.LCRLoadCompensationSpot] = field(default_factory=list)

    # Session configuration
    cable_length: nidcpower.CableLength = nidcpower.CableLength.NI_STANDARD_1M
    voltage_amplitude: float = 0.5  # Volts RMS
    impedance_range: float = 0  # 0 = auto-range
    dc_bias_source: nidcpower.LCRDCBiasSource = nidcpower.LCRDCBiasSource.OFF
    dc_bias_voltage_level: float = 0.0  # Volts (if bias_source=VOLTAGE)
    dc_bias_current_level: float = 0.0  # Amperes (if bias_source=CURRENT)
    measurement_time: nidcpower.LCRMeasurementTime = nidcpower.LCRMeasurementTime.MEDIUM
    custom_measurement_time: float = 0.0  # seconds (if measurement_time=CUSTOM)

    # Measurement frequency (1000 Hz for ACIR, variable for EIS)
    lcr_frequency: float = 1000.0

    @classmethod
    def from_json(cls, json_data: Dict[str, Any]) -> "LCRCompensationParameters":
        """Create LCRCompensationParameters instance from JSON dictionary.

        Args:
            json_data (Dict[str, Any]): Dictionary containing compensation configuration data.

        Returns:
            LCRCompensationParameters: Instance configured from JSON data.

        Raises:
            LCRParameterError: If parameters are invalid.
            KeyError: If expected keys are not found.
        """
        # Parse cable length
        cable_length_str = json_data.get("Cable Length", "1m")
        cable_length = parse_cable_length(cable_length_str)

        # Parse DC bias source
        dc_bias_source_str = json_data.get("DC Bias Source", "OFF").upper()
        dc_bias_source_map = {
            "OFF": nidcpower.LCRDCBiasSource.OFF,
            "VOLTAGE": nidcpower.LCRDCBiasSource.VOLTAGE,
            "CURRENT": nidcpower.LCRDCBiasSource.CURRENT,
        }
        dc_bias_source = dc_bias_source_map.get(dc_bias_source_str)
        if dc_bias_source is None:
            raise LCRParameterError(f"Unsupported DC bias source: {dc_bias_source_str}")

        # Parse measurement time
        measurement_time_str = json_data.get("Measurement Time", "MEDIUM").upper()
        measurement_time_map = {
            "SHORT": nidcpower.LCRMeasurementTime.SHORT,
            "MEDIUM": nidcpower.LCRMeasurementTime.MEDIUM,
            "LONG": nidcpower.LCRMeasurementTime.LONG,
            "CUSTOM": nidcpower.LCRMeasurementTime.CUSTOM,
        }
        measurement_time = measurement_time_map.get(measurement_time_str)
        if measurement_time is None:
            raise LCRParameterError(f"Unsupported measurement time: {measurement_time_str}")

        # Parse generate_load flag explicitly to enforce JSON limitations.
        generate_load_flag = bool(json_data.get("Generate Load", False))
        if generate_load_flag:
            raise LCRParameterError(
                "Load compensation configured via JSON is not supported because "
                "load_compensation_spots cannot be expressed in JSON. Configure "
                "load compensation spots programmatically instead."
            )

        return cls(
            generate_custom_cable=bool(json_data.get("Generate Custom Cable", False)),
            generate_open=bool(json_data.get("Generate Open", True)),
            generate_short=bool(json_data.get("Generate Short", True)),
            generate_load=generate_load_flag,
            enable_open=bool(json_data.get("Enable Open", True)),
            enable_short=bool(json_data.get("Enable Short", True)),
            enable_load=bool(json_data.get("Enable Load", False)),
            short_custom_cable_enabled=bool(json_data.get("Short Custom Cable Enabled", False)),
            additional_frequencies=list(json_data.get("Additional Frequencies", [])),
            load_compensation_spots=[],
            cable_length=cable_length,
            voltage_amplitude=float(json_data.get("Voltage Amplitude (V)", 0.5)),
            impedance_range=float(json_data.get("Impedance Range (Ohm)", 0)),
            dc_bias_source=dc_bias_source,
            dc_bias_voltage_level=float(json_data.get("DC Bias Voltage Level (V)", 0.0)),
            dc_bias_current_level=float(json_data.get("DC Bias Current Level (A)", 0.0)),
            measurement_time=measurement_time,
            custom_measurement_time=float(json_data.get("Custom Measurement Time (s)", 0.0)),
            lcr_frequency=float(json_data.get("LCR Frequency (Hz)", 1000.0)),
        )

    @classmethod
    def from_file(cls, file_path: str) -> "LCRCompensationParameters":
        """Create LCRCompensationParameters instance from JSON configuration file.

        Args:
            file_path (str): Path to JSON configuration file.

        Returns:
            LCRCompensationParameters: Instance configured from file.

        Raises:
            FileNotFoundError: If configuration file is not found.
            LCRParameterError: If file content is invalid.
            json.JSONDecodeError: If file contains invalid JSON.
        """
        with open(file_path, "r", encoding="utf-8") as f:
            json_data = json.load(f)
        return cls.from_json(json_data)


def validate_compensation_parameters(params: LCRCompensationParameters) -> None:
    """Validate LCR compensation parameters.

    Checks that the compensation parameters are valid before performing
    the compensation procedure.

    Args:
        params (LCRCompensationParameters): The LCRCompensationParameters to validate.

    Raises:
        LCRParameterError: If parameters are invalid. Specifically:
            - If generate_load=True but generate_open or generate_short is False
            - If enable_load=True but enable_open or enable_short is False
            - If measurement_time=CUSTOM but custom_measurement_time is not positive
    """
    # Validate: load compensation generation requires open and short
    if params.generate_load:
        if not (params.generate_open and params.generate_short):
            raise LCRParameterError(
                "Load compensation generation requires both open AND short "
                "compensation to be generated first."
            )

    # Validate: enabling load compensation requires open and short enabled
    if params.enable_load:
        if not (params.enable_open and params.enable_short):
            raise LCRParameterError(
                "Enable load compensation requires both enable_open AND enable_short to be True."
            )

    # Validate: custom measurement time must be positive when using CUSTOM mode
    if params.measurement_time == nidcpower.LCRMeasurementTime.CUSTOM:
        if params.custom_measurement_time <= 0:
            raise LCRParameterError(
                "custom_measurement_time must be a positive value when "
                "measurement_time is CUSTOM."
            )


def perform_lcr_compensation(
    session: nidcpower.Session,
    params: LCRCompensationParameters,
    skip_prompts: bool = False,
    timeout: float = DEFAULT_COMPENSATION_TIMEOUT,
) -> dict:
    """Perform the 7-step LCR compensation flow.

    This function implements the complete compensation generation flow as defined
    in the LabVIEW "Create Compensation" example. The compensation data is stored
    on the device's onboard memory.

    The 7 steps are:
    1. Session init (assumed already done via Device.create)
    2. Custom cable compensation (if enabled)
    3. Set cable length
    4. Open/Short compensation (if enabled)
    5. Load compensation (if enabled)
    6. Configure session for verification measurement
    7. Verification measurement (initiate, wait, measure, reset)

    User prompts are displayed before each step requiring physical connection
    changes (open, short, load). These prompts ensure the user has made
    the correct physical setup before compensation data is captured.

    Args:
        session (nidcpower.Session): The nidcpower.Session connected to the LCR Meter.
        params (LCRCompensationParameters): LCRCompensationParameters with all configuration
            options.
        skip_prompts (bool): If True, skips user prompts for physical connections.
            User must ensure correct connections are made before each step.
            Useful for automated testing or scripted calibration sequences.
        timeout (float): Timeout in seconds for the verification measurement.
            Default is 21.0 seconds.

    Returns:
        dict: Raw measurement data from verification measurement containing:
            - 'z': Complex impedance
            - 'z_magnitude': Impedance magnitude
            - 'z_phase': Phase angle in degrees
            - 'resistance': Series resistance Rs
            - 'stimulus_frequency': Actual measurement frequency

    Raises:
        LCRParameterError: If parameters are invalid (e.g., load comp
            without open AND short).
        nidcpower.Error: If hardware operation fails.

    Examples:
        >>> # Perform compensation with user prompts
        >>> result = perform_lcr_compensation(
        ...     session=device.session,
        ...     params=LCRCompensationParameters(
        ...         generate_open=True,
        ...         generate_short=True,
        ...     ),
        ... )
        >>>
        >>> # Automated compensation (for testing)
        >>> result = perform_lcr_compensation(session, params, skip_prompts=True)
    """
    # Validate parameters first
    validate_compensation_parameters(params)

    # ===== STEP 1: Session already initialized via Device.create() =====
    # (reset=True, independent_channels=True)

    # Ensure session is in LCR mode with a defined stimulus function before compensation
    # NOTE: Compensation uses VOLTAGE stimulus (different from CURRENT used in ACIR measurement)
    session.instrument_mode = nidcpower.InstrumentMode.LCR
    session.lcr_stimulus_function = nidcpower.LCRStimulusFunction.VOLTAGE

    # ===== STEP 2: Custom Cable Compensation =====
    if params.generate_custom_cable:
        # 2a: Open custom cable compensation
        if not skip_prompts:
            input(
                "[nibcq] Set up OPEN connection for custom cable compensation.\n"
                "        (Remove DUT, leave probes disconnected)\n"
                "Press Enter when ready..."
            )
        session.perform_lcr_open_custom_cable_compensation()

        # 2b: Short custom cable compensation (optional)
        if params.short_custom_cable_enabled:
            session.lcr_short_custom_cable_compensation_enabled = True
            if not skip_prompts:
                input(
                    "[nibcq] Set up SHORT connection for custom cable compensation.\n"
                    "        (Connect probes together, no DUT)\n"
                    "Press Enter when ready..."
                )
            session.perform_lcr_short_custom_cable_compensation()

    # ===== STEP 3: Set cable length =====
    session.cable_length = params.cable_length

    # ===== STEP 4: Standard Open/Short Compensation =====
    if params.generate_open:
        if not skip_prompts:
            input(
                "[nibcq] Set up OPEN connection for open compensation.\n"
                "        (Remove DUT, leave probes disconnected)\n"
                "Press Enter when ready..."
            )
        session.perform_lcr_open_compensation(additional_frequencies=params.additional_frequencies)

    if params.generate_short:
        if not skip_prompts:
            input(
                "[nibcq] Set up SHORT connection for short compensation.\n"
                "        (Connect probes together, no DUT)\n"
                "Press Enter when ready..."
            )
        session.perform_lcr_short_compensation(additional_frequencies=params.additional_frequencies)

    # ===== STEP 5: Load Compensation =====
    if params.generate_load:
        # Configure load properties first
        session.lcr_voltage_amplitude = params.voltage_amplitude
        session.lcr_impedance_range = params.impedance_range
        session.lcr_dc_bias_source = params.dc_bias_source
        session.lcr_dc_bias_voltage_level = params.dc_bias_voltage_level
        session.lcr_dc_bias_current_level = params.dc_bias_current_level
        session.lcr_measurement_time = params.measurement_time

        if params.measurement_time == nidcpower.LCRMeasurementTime.CUSTOM:
            session.lcr_custom_measurement_time = params.custom_measurement_time

        if not skip_prompts:
            input(
                "[nibcq] Set up LOAD connection for load compensation.\n"
                "        (Connect known reference load/resistor)\n"
                "Press Enter when ready..."
            )
        session.perform_lcr_load_compensation(compensation_spots=params.load_compensation_spots)

    # ===== STEP 6: Configure session for verification measurement =====
    # Data source: always ONBOARD_STORAGE (where perform_* methods saved data)
    session.lcr_open_short_load_compensation_data_source = (
        nidcpower.LCROpenShortLoadCompensationDataSource.ONBOARD_STORAGE
    )

    # Instrument mode and stimulus function
    session.instrument_mode = nidcpower.InstrumentMode.LCR
    # NOTE: Compensation uses VOLTAGE stimulus (different from measurement!)
    session.lcr_stimulus_function = nidcpower.LCRStimulusFunction.VOLTAGE

    # Enable compensation flags for verification measurement
    session.lcr_open_compensation_enabled = params.enable_open
    session.lcr_short_compensation_enabled = params.enable_short
    session.lcr_load_compensation_enabled = params.enable_load

    # Measurement properties
    session.lcr_frequency = params.lcr_frequency
    session.lcr_voltage_amplitude = params.voltage_amplitude
    session.lcr_impedance_range = params.impedance_range
    session.lcr_measurement_time = params.measurement_time

    if params.measurement_time == nidcpower.LCRMeasurementTime.CUSTOM:
        session.lcr_custom_measurement_time = params.custom_measurement_time

    # DC-bias configuration for verification measurement
    session.lcr_dc_bias_source = params.dc_bias_source
    session.lcr_dc_bias_voltage_level = params.dc_bias_voltage_level
    session.lcr_dc_bias_current_level = params.dc_bias_current_level

    # ===== STEP 7: Verification Measurement =====
    # Perform a verification measurement using the current connection/fixture.
    # If a SHORT is connected and properly compensated, the measured impedance should be near zero.
    session.initiate()
    session.wait_for_event(
        event_id=nidcpower.Event.SOURCE_COMPLETE,
        timeout=timeout,
    )
    measurements = session.measure_multiple_lcr()
    session.reset()

    # Return raw measurement data as dictionary
    # The caller (LCRACIR) will convert to appropriate result type
    measurement = measurements[0]
    return {
        "z": measurement.z,
        "z_magnitude": measurement.z_magnitude_and_phase[0],
        "z_phase": measurement.z_magnitude_and_phase[1],
        "resistance": measurement.series_lcr.resistance,
        "stimulus_frequency": measurement.stimulus_frequency,
    }
