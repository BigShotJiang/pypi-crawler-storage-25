"""Defines the Parallel EIS measurement for the nibcq package."""

import cmath
import contextlib
import math
from collections.abc import Sequence
from typing import Callable, override

import nidcpower

from nibcq._acir import ACIR, DFTFeatures, SMUResult
from nibcq._acir_parallel import ParallelACIR
from nibcq._device import Device
from nibcq._eis import EIS, EISTestParameters
from nibcq.compensation import (
    Compensation,
    CompensationFile,
    CompensationMethod,
    InterpolationMode,
)
from nibcq.enums import MultiDeviceMode
from nibcq.errors import CompensationMethodError, FrequencyError
from nibcq.measurement import SMUMeasurement


class ParallelEIS(ParallelACIR, EIS):
    """Defines an EIS measurement with multiple SMUs working in parallel.

    This class enables multi-frequency electrochemical impedance spectroscopy using
    multiple SMU devices connected in parallel. It combines the parallel hardware
    management from ParallelACIR (trigger synchronization, current division, multidevice
    data collection) with the frequency sweep workflow from EIS.

    Each frequency point in the sweep is essentially a parallel ACIR measurement:
    all devices are configured, synchronized, and measured together, then the per-device
    currents are summed and voltage is taken from the leader. This is repeated for every
    frequency in the sweep (highest to lowest).

    Unlike single-device EIS measurements, parallel EIS does NOT support switching
    configurations due to hardware current limitations of switch matrices (typically
    limited to ~2A). Parallel EIS is designed for direct-connection, high-current
    testing scenarios.

    Key Features:
        - Multiple SMUs synchronized via hardware triggers (PXI backplane).
        - Current capacity scales linearly with number of devices.
        - Full frequency sweep with per-frequency current amplitude support.
        - Voltage measured from leader device (4-wire remote sense).
        - Current contributions summed across all devices at each frequency.
        - Bode and Nyquist plot generation from sweep results.

    Hardware Requirements:
        - All devices must be NI PXIe-4139 or compatible SMUs.
        - Devices must be in the same PXI chassis for trigger routing.
        - One device designated as leader, others as followers.

    Inheritance:
        ParallelEIS inherits from both ParallelACIR and EIS.

        - ParallelACIR provides parallel hardware management, multidevice data,
          and compensation.
        - EIS provides the frequency sweep workflow, plotting, and list-based results.

    Example:
        >>> leader = Device.create(DeviceFamily.SMU, "PXI1Slot2")
        >>> follower1 = Device.create(DeviceFamily.SMU, "PXI1Slot3")
        >>>
        >>> sweep = {
        ...     1000.0: FrequencySet(current_amplitude=3.0, number_of_periods=20),
        ...     100.0: FrequencySet(current_amplitude=3.0, number_of_periods=50),
        ... }
        >>> params = EISTestParameters(frequency_sweep_characteristics=sweep)
        >>>
        >>> eis = ParallelEIS(leader=leader, followers=[follower1], test_parameters=params)
        >>> compensation = eis.load_compensation_file()
        >>> results = eis.run(compensation)
        >>> nyquist, bode_mag, bode_phase = eis.get_plots()
    """

    def __init__(
        self,
        leader: Device,
        followers: Sequence[Device],
        test_parameters: EISTestParameters,
        multi_device_type: MultiDeviceMode = MultiDeviceMode.PARALLEL,
    ):
        """Initialize Parallel EIS measurement with an explicit leader and follower devices.

        Combines ParallelACIR initialization (device validation, parallel state,
        ACIR-compatible dataclass initialization) with EIS-specific state
        (frequency sweep management, list-based result storage).

        Args:
            leader (Device): The single SMU device that acts as the timing source
                and provides remote-sense voltage data.
            followers (Sequence[Device]): An ordered collection of SMU devices that
                synchronise to the leader via start-trigger signals.
            test_parameters (EISTestParameters): EIS-specific test configuration including
                frequency sweep characteristics, voltage limits, and compensation method.
            multi_device_type (MultiDeviceMode): How the devices share the load current.
                Defaults to ``MultiDeviceMode.PARALLEL``.

        Raises:
            TypeError: If the leader or any follower is not a ``Device`` instance.
            TestSessionMismatchError: If any supplied device is not an SMU
                (``DeviceFamily.SMU``).
        """
        # ParallelACIR.__init__ handles:
        #   - Device validation and sorting (leader last)
        #   - ParallelMeasurement init (leader detection)
        #   - SMU family validation
        #   - ACIR dataclass initialization (SMUInputParameters, SMUGenerationParameters, etc.)
        #   - Parallel state (multi_device_type, _multidevice_measurement_data, _result)
        #
        # Note: test_frequency is not meaningful for EIS (which sweeps), so we pass a
        # dummy value. The ACIR.current_frequency setter will set it, but we override
        # it below with EIS-specific state.
        ParallelACIR.__init__(
            self,
            leader=leader,
            followers=followers,
            test_parameters=test_parameters,
            test_frequency=1000.0,  # Placeholder; EIS manages frequency via sweep dict.
            multi_device_type=multi_device_type,
        )

        # --- EIS-specific overrides ---
        # Reset current_frequency to None — EIS does not have a single fixed frequency.
        # The EIS.current_frequency property uses self._current_frequency, not
        # gen_params.configured_frequency (which the ACIR setter writes to).
        self._current_frequency = None

        # Re-apply test_parameters through the EIS setter (not ACIR setter).
        # The ACIR setter creates a single-frequency FrequencySet, while the EIS setter
        # copies the full frequency_sweep_characteristics dict as-is.
        self.test_parameters = test_parameters

        # EIS stores results as a list of SMUResult (one per frequency), not a single value.
        self._result: list[SMUResult] = []

    # ================================================================
    # Properties — MRO provides the right ones automatically:
    #
    #   From ParallelACIR:
    #     all_measurement_data     (per-device, including None entries)
    #     calibration_file_paths   (all devices)
    #     measurement_data         (multidevice + sanitized via _multidevice_measurement_data)
    #
    #   From EIS:
    #     test_parameters          (EIS setter with full sweep dict)
    #     current_frequency        (sweep-aware getter/setter)
    #     frequency_list           (sorted descending)
    #     result                   (list[SMUResult])
    #     get_plots()              (Nyquist + Bode from result list)
    #
    #   From ParallelACIR (via ACIR):
    #     generate_compensation_file_path()  (leader SN naming)
    #     load_compensation_file()           (ACIR standard)
    # ================================================================

    # ================================================================
    # Configure — override to read amplitude from frequency sweep dict
    # ================================================================

    @override
    def _configure(self):
        """Configure all parallel SMU devices for synchronized measurement at current frequency.

        This overrides ParallelACIR._configure() with one key difference: the total
        current amplitude is read from the per-frequency FrequencySet in
        frequency_sweep_characteristics (EIS pattern), instead of from a single
        test_parameters.current_amplitude value (ACIR pattern).

        After reading the correct per-frequency amplitude, the rest of the configuration
        is identical to ParallelACIR: parameter calculation, amplitude division across
        devices, temporary amplitude swap for ACIR helper methods, per-device hardware
        configuration, trigger synchronization, and output enabling.

        Raises:
            FrequencyError: If frequency is not set or parameters produce too many samples.
            CurrentAmplitudeError: If per-device current amplitude is out of range.
            SMUParameterError: If hardware rejects any configured parameter.
        """
        if self.current_frequency is None:
            raise FrequencyError("Measurement cannot run without a set current waveform frequency.")

        if self.multi_device_type is not MultiDeviceMode.PARALLEL:
            raise NotImplementedError(
                f"Only {MultiDeviceMode.PARALLEL.value} MultiDeviceMode is currently supported, "
                f"but '{self.multi_device_type.value}' was provided."
            )

        number_of_devices = len(self._followers) + 1

        # Read amplitude from the frequency sweep characteristics dict (EIS pattern).
        # ParallelACIR reads from test_parameters.current_amplitude, which doesn't exist
        # on EISTestParameters. Here we get it from the per-frequency FrequencySet.
        freq_set = self._generation_input_parameters.frequency_sweep_characteristics[
            self.current_frequency
        ]
        current_amplitude = freq_set.current_amplitude
        configured_frequency = self.current_frequency

        # Adjust current amplitude for frequency-dependent attenuation in parallel configs.
        bandwidth = self._determine_bandwidth(number_of_devices)
        adjusted_current_amplitude = self._adjust_current_amplitude(
            current_amplitude, configured_frequency, bandwidth
        )

        per_device_current_amplitude = adjusted_current_amplitude / number_of_devices

        # Validate per-device amplitude.
        ACIR.validate_current_amplitude(configured_frequency, per_device_current_amplitude)

        gen_params = self._calculated_generation_parameters
        mes_params = self._calculated_measurement_parameters

        # Sample rate — same as single-device, frequency-dependent.
        mes_params.sample_rate = self._determine_sample_rate()

        # Number of samples — same formula.
        total_samples, first_period_samples = self._calculate_number_of_samples()
        mes_params.number_of_samples = total_samples
        gen_params.first_period_number_of_samples = first_period_samples

        # Timing parameters.
        mes_params.aperture_time = 1.0 / mes_params.sample_rate
        gen_params.sinusoidal_pattern_dt = 1.0 / mes_params.sample_rate
        gen_params.timeout_value = mes_params.number_of_samples / mes_params.sample_rate + 1

        # Temporarily set per-device amplitude so ACIR helper methods (_generate_waveform,
        # _determine_current_level_range) operate on the divided value.
        freq_set.current_amplitude = per_device_current_amplitude

        gen_params.generated_sinusoidal_waveform = self._generate_waveform()
        gen_params.voltage_range = self._determine_voltage_limit_range()
        per_device_current_level_range = self._determine_current_level_range()
        gen_params.current_range = per_device_current_level_range

        # Restore original (total) amplitude.
        freq_set.current_amplitude = current_amplitude

        # --- Configure each device (reuses ParallelACIR pattern) ---
        self._configure_parallel_devices(per_device_current_level_range)

    def _configure_parallel_devices(self, per_device_current_level_range: float):
        """Configure hardware properties on all parallel devices.

        This method encapsulates the per-device configuration loop (mirrors the
        inline loop in ParallelACIR._configure()). It sets measurement properties,
        generation properties, trigger synchronization, commits configurations,
        and retrieves actual hardware values from the leader.

        Args:
            per_device_current_level_range: The current level range calculated for
                each individual SMU device after amplitude division.
        """
        gen_params = self._calculated_generation_parameters
        mes_params = self._calculated_measurement_parameters

        leader_start_trigger_terminal = self._build_terminal_name(self._leader, 0, "StartTrigger")

        for device in self.get_all_devices():
            session: nidcpower.Session = device.session
            is_leader = device is self._leader

            # --- Measurement properties ---
            device_measure_trigger = self._build_terminal_name(device, 0, "SourceCompleteEvent")

            session.measure_when = nidcpower.MeasureWhen.ON_MEASURE_TRIGGER
            session.measure_trigger_type = nidcpower.TriggerType.DIGITAL_EDGE
            session.digital_edge_measure_trigger_input_terminal = device_measure_trigger
            session.aperture_time_units = nidcpower.ApertureTimeUnits.SECONDS
            session.aperture_time = mes_params.aperture_time
            session.measure_record_length = mes_params.number_of_samples
            session.power_line_frequency = self.test_parameters.powerline_frequency.value
            session.sense = nidcpower.Sense.REMOTE if is_leader else nidcpower.Sense.LOCAL
            session.dc_noise_rejection = nidcpower.DCNoiseRejection.NORMAL
            session.measure_complete_event_delay = 0
            session.autorange = False

            # --- Generation properties ---
            session.set_sequence(
                values=gen_params.generated_sinusoidal_waveform,
                source_delays=[0] * mes_params.number_of_samples,
            )

            session.output_function = self._generation_input_parameters.output_function.value
            session.source_mode = nidcpower.SourceMode.SEQUENCE
            session.current_limit_autorange = False
            session.transient_response = nidcpower.TransientResponse.NORMAL
            session.current_level_range = per_device_current_level_range
            session.voltage_limit = self._generation_input_parameters.voltage_limit_hi
            session.voltage_limit_range = gen_params.voltage_range
            session.source_delay = 0
            session.output_resistance = 1000
            session.sequence_step_delta_time_enabled = True
            session.sequence_step_delta_time = gen_params.sinusoidal_pattern_dt

            # --- Trigger synchronization ---
            if not is_leader:
                session.start_trigger_type = nidcpower.TriggerType.DIGITAL_EDGE
                session.digital_edge_start_trigger_input_terminal = leader_start_trigger_terminal

        # Commit and enable outputs (followers first, leader last — order preserved by tuple).
        for device in self.get_all_devices():
            session: nidcpower.Session = device.session
            session.commit()
            if not session.output_connected:
                session.output_connected = True

        # Retrieve actual hardware values from leader.
        leader_session: nidcpower.Session = self._leader.session
        raw_delta_time = self._delta_to_seconds(leader_session.measure_record_delta_time)
        mes_params.actual_measurement_record_dt = raw_delta_time
        mes_params.number_of_samples = leader_session.measure_record_length

    # ================================================================
    # Run — frequency sweep with parallel hardware
    # ================================================================

    @override
    def run(
        self,
        compensation: Compensation,
        measurement_callback: Callable[[SMUMeasurement], None] | None = None,
    ) -> list[SMUResult]:
        """Execute a complete parallel EIS frequency sweep.

        Performs impedance spectroscopy across all frequencies defined in the test
        parameters, using multiple synchronized SMU devices. Each frequency point
        follows the ParallelACIR measurement pattern:
        1. Configure all devices for the current frequency.
        2. Initiate synchronized measurement (leader triggers followers).
        3. Fetch and aggregate multidevice data (leader voltage, summed currents).
        4. DFT-based impedance calculation on the multidevice waveform.
        5. Apply frequency-specific compensation.

        Frequencies are swept from highest to lowest (EIS convention).

        Args:
            compensation (Compensation): Compensation data for error correction across
                all frequencies.
            measurement_callback (Callable or None): Optional callback invoked after each
                frequency point with the raw multidevice SMUMeasurement data. Useful for
                progress tracking or raw data logging.

        Returns:
            list[SMUResult]: Impedance results for each frequency point, containing
                compensated impedance magnitude, phase, real and imaginary components.

        Raises:
            FrequencyError: If frequency sweep characteristics are not configured.
            SMUParameterError: If device configuration fails at any frequency.
            CompensationMethodError: If compensation data is incompatible.

        Example:
            >>> compensation = parallel_eis.load_compensation_file()
            >>> results = parallel_eis.run(compensation)
            >>> for r in results:
            ...     print(f"{r.measured_frequency:.1f} Hz: Z={r.z:.4f} Ohm")
        """
        # Validate temperature if compensation specifies a target.
        if compensation.target_temperature is not None and (
            not math.isnan(compensation.target_temperature.center)
        ):
            self.validate_temperature(compensation.target_temperature)

        # Use ExitStack to enter each session's lock context manager. This guarantees that:
        # - If any lock() call raises an exception, all already-acquired locks are released.
        # - After the block exits (normally or via exception), every acquired lock is released
        #   even if one or more releases fail, because ExitStack calls __exit__ on all entered
        #   contexts before propagating any exception.
        with contextlib.ExitStack() as stack:
            for device in self.get_all_devices():
                stack.enter_context(device.session.lock())

            eis_results: list[SMUResult] = []

            for frequency in self.frequency_list:
                self.current_frequency = frequency

                # Configure all devices for this frequency.
                self._configure()

                # Execute parallel measurement and populate multidevice data.
                self._measure()

                # DFT analysis on the multidevice (combined) waveform.
                dft_features: DFTFeatures = self._calculate_impedance(
                    voltage_signal=self.measurement_data.voltage_values,
                    current_signal=self.measurement_data.current_values,
                )

                # Update tone frequency with DFT-detected value.
                self._multidevice_measurement_data.tone_frequency = dft_features.tone_frequency
                self._calculated_generation_parameters.measured_frequency = (
                    dft_features.tone_frequency
                )

                # Calculate raw impedance phasor.
                impedance_phasor = dft_features.voltage_phasor / dft_features.current_phasor

                # Apply compensation.
                compensated_impedance = compensation.get_compensated_impedance(
                    frequency=dft_features.tone_frequency,
                    measured_impedance=impedance_phasor,
                )

                single_result = SMUResult(
                    measured_frequency=dft_features.tone_frequency,
                    impedance=compensated_impedance,
                    r=compensated_impedance.real,
                    x=compensated_impedance.imag,
                    z=abs(compensated_impedance),
                    theta=math.degrees(cmath.phase(compensated_impedance)),
                )

                eis_results.append(single_result)

                if measurement_callback:
                    measurement_callback(self.measurement_data)

                # Reset all devices between frequency points to clear sequence state.
                # Same pattern as single-device EIS — ensures clean configuration at
                # the next frequency. Uses leader session reset (as in EIS.run()).
                for device in self.get_all_devices():
                    device.session.reset()

            self._result = eis_results

        return self.result

    # ================================================================
    # Compensation file writing — frequency sweep with parallel locking
    # ================================================================

    @override
    def write_compensation_file(
        self,
        compensation_file_path: str | None = None,
        kit_file_path: str | None = None,
        comment: str | None = None,
        measurement_callback: Callable[[SMUMeasurement], None] | None = None,
    ) -> str:
        """Create a compensation file across all frequencies in the sweep.

        Performs the same per-frequency measurement loop as run(), but stores the
        raw impedance phasor at each frequency instead of compensating it. These
        raw impedance values form the compensation data that will be subtracted
        from future measurements.

        All parallel device sessions are locked for the entire sweep to prevent
        concurrent access.

        Args:
            compensation_file_path (str or None): Optional file path for the compensation
                data. If None, auto-generates path using leader serial number.
            kit_file_path (str or None): Optional path to known impedance table for KIT
                compensation subtraction (applied after all measurements).
            comment (str or None): Optional comment to embed in the compensation file.
            measurement_callback (Callable or None): Optional callback invoked after each
                frequency measurement with the raw multidevice SMUMeasurement data.

        Returns:
            str: Path to the created compensation file.

        Raises:
            CompensationMethodError: If NO_COMPENSATION is selected or method
                is unsupported.
            FrequencyError: If frequency sweep characteristics are not configured.
            SMUParameterError: If device configuration or measurement fails.
        """
        base_compensation_file_path = self.generate_compensation_file_path()
        if compensation_file_path is None:
            compensation_file_path = base_compensation_file_path

        if self.test_parameters.compensation_method == CompensationMethod.NO_COMPENSATION:
            raise CompensationMethodError(
                f"You must select a compensation method other than "
                f"{CompensationMethod.NO_COMPENSATION.value} to create a compensation file."
            )

        # Measure temperature (optional capability, handled by TemperatureAware mixin).
        self.measure_temperature()

        # Collect compensation data for all frequencies.
        compensation_parameters: dict[float, complex] = {}

        with contextlib.ExitStack() as stack:
            for device in self.get_all_devices():
                stack.enter_context(device.session.lock())

            for frequency in self.frequency_list:
                self.current_frequency = frequency

                self._configure()
                self._measure()

                # DFT analysis on the multidevice waveform.
                dft_features: DFTFeatures = self._calculate_impedance(
                    voltage_signal=self.measurement_data.voltage_values,
                    current_signal=self.measurement_data.current_values,
                )
                impedance_phasor = dft_features.voltage_phasor / dft_features.current_phasor
                compensation_parameters[frequency] = impedance_phasor

                if measurement_callback:
                    measurement_callback(self.measurement_data)

                # Reset all devices between frequency points.
                for device in self.get_all_devices():
                    device.session.reset()

        # Build Compensation object with all frequency data.
        compensation = Compensation(
            compensation_method=self.test_parameters.compensation_method,
            compensation_file_path=compensation_file_path,
            target_temperature=self.temperature_range,
            compensation_parameters=compensation_parameters,
        )

        # Apply KIT correction if applicable.
        if self.test_parameters.compensation_method == CompensationMethod.SHORT and kit_file_path:
            self._apply_kit_compensation(compensation, kit_file_path, InterpolationMode.NEAREST)

        # Persist to file.
        new_file = CompensationFile.memory_to_file(compensation=compensation, comment=comment)
        new_file.save_to_file(compensation_file_path)

        return compensation_file_path

    # ================================================================
    # Switching is NOT supported for parallel EIS
    # ================================================================

    @override
    def run_with_switching(self, compensation=None, measurement_callback=None):
        """Parallel EIS does not support switching.

        Switching support is limited to 3A, which a single SMU can already
        provide. For current targets up to 3A, use single-device EIS with
        switching instead.

        Raises:
            NotImplementedError: Always raised.
        """
        raise NotImplementedError(
            "ParallelEIS does not support switching. "
            "Switching support is limited to 3A; for targets within that range, "
            "use single-device EIS with switching instead."
        )
