"""Defines the LCR-based ACIR measurement for the nibcq package using PXIe-4190 LCR Meter.

This module provides ACIR (Alternating Current Internal Resistance) measurements
using the NI PXIe-4190 LCR Meter. Unlike the SMU-based ACIR which uses waveform
generation and FFT analysis, the LCR meter performs hardware-based impedance
measurements directly.
"""

import json
import math
from dataclasses import dataclass
from typing import Any, Dict, Final, Optional

import nidcpower

from nibcq._device import Device
from nibcq.enums import DeviceFamily, LCRVoltageRange
from nibcq.errors import LCRParameterError, TestSessionMismatchError
from nibcq.lcr_compensation import (
    LCRCompensationParameters,
    parse_cable_length,
    perform_lcr_compensation,
)
from nibcq.measurement import ConfigFileSupport, LCRMeasurementResult


@dataclass
class LCRTestParameters(ConfigFileSupport):
    """Test parameters specific to LCR Meter (PXIe-4190) ACIR measurements.

    Unlike SMU/DMM parameters, LCR does NOT use powerline_frequency.
    The LCR hardware handles noise rejection internally.

    Supports two ways to create instances:
    1. Direct instantiation with keyword arguments
    2. Loading from JSON file via from_file() classmethod

    Attributes:
        cable_length (nidcpower.CableLength): Cable length setting.
            Default is NI_STANDARD_1M (1 meter).
        voltage_range (LCRVoltageRange): Peak voltage range (10V or 40V),
            converted to RMS internally. Default is PEAK_10V (7V RMS).
        current_amplitude (float): AC current amplitude in Amperes RMS.
            Range: 7.08e-9 A to 0.707 A. Default is 0.07 A.
        open_compensation_enabled (bool): Enable open compensation from onboard storage.
        short_compensation_enabled (bool): Enable short compensation from onboard storage.
        load_compensation_enabled (bool): Enable load compensation from onboard storage.
            Note: Load compensation requires both open AND short to be enabled.

    Examples:
        >>> # Direct instantiation
        >>> params = LCRTestParameters(
        ...     voltage_range=LCRVoltageRange.PEAK_10V,
        ...     current_amplitude=0.07,
        ...     open_compensation_enabled=True,
        ... )
        >>> # From JSON file
        >>> params = LCRTestParameters.from_file("config/lcr_config.json")
    """

    cable_length: nidcpower.CableLength = nidcpower.CableLength.NI_STANDARD_1M
    voltage_range: LCRVoltageRange = LCRVoltageRange.PEAK_10V
    current_amplitude: float = 0.07  # Amperes RMS
    open_compensation_enabled: bool = False
    short_compensation_enabled: bool = False
    load_compensation_enabled: bool = False

    @classmethod
    def from_json(cls, json_data: Dict[str, Any]) -> "LCRTestParameters":
        """Create LCRTestParameters instance from JSON dictionary.

        Args:
            json_data (Dict[str, Any]): Dictionary containing LCR configuration data.

        Returns:
            LCRTestParameters: Instance configured from JSON data.

        Raises:
            LCRParameterError: If parameters are invalid.
            KeyError: If expected keys are not found.
        """
        # Parse cable length
        cable_length_str = json_data.get("Cable Length", "1m")
        cable_length = parse_cable_length(cable_length_str)

        # Parse voltage range (expects peak value: 10 or 40)
        voltage_range_value = json_data.get("Voltage Range (V Peak)", 10)
        if voltage_range_value == 10:
            voltage_range = LCRVoltageRange.PEAK_10V
        elif voltage_range_value == 40:
            voltage_range = LCRVoltageRange.PEAK_40V
        else:
            raise LCRParameterError(f"Unsupported voltage range: {voltage_range_value}")

        # Parse current amplitude with type validation
        try:
            current_amplitude = float(json_data.get("Current Amplitude (A)", 0.07))
        except (TypeError, ValueError) as exc:
            raise LCRParameterError(
                f"Invalid current amplitude value: {json_data.get('Current Amplitude (A)')}"
            ) from exc

        return cls(
            cable_length=cable_length,
            voltage_range=voltage_range,
            current_amplitude=current_amplitude,
            open_compensation_enabled=bool(json_data.get("Enable Open Compensation", False)),
            short_compensation_enabled=bool(json_data.get("Enable Short Compensation", False)),
            load_compensation_enabled=bool(json_data.get("Enable Load Compensation", False)),
        )

    @classmethod
    def from_file(cls, file_path: str) -> "LCRTestParameters":
        """Create LCRTestParameters instance from JSON configuration file.

        Args:
            file_path (str): Path to JSON configuration file.

        Returns:
            LCRTestParameters: Instance configured from file.

        Raises:
            FileNotFoundError: If configuration file is not found.
            LCRParameterError: If file content is invalid.
            json.JSONDecodeError: If file contains invalid JSON.
        """
        with open(file_path, "r", encoding="utf-8") as f:
            json_data = json.load(f)
        return cls.from_json(json_data)


class LCRACIR:
    """LCR-based ACIR (AC Internal Resistance) measurement handler class.

    This class implements single-frequency AC impedance measurements using
    the NI PXIe-4190 LCR Meter. Unlike SMU-based ACIR which uses waveform
    generation and FFT analysis, the LCR meter performs hardware-based
    impedance measurements directly at 1000 Hz.

    The LCR meter handles all signal generation and analysis internally,
    making measurements simpler and faster than SMU-based methods.

    Attributes:
        DEVICE_FAMILY (DeviceFamily): DeviceFamily.LCR_METER - required device type.
        measurement_frequency (float): Default frequency for ACIR (1000.0 Hz).
        MEASUREMENT_TIMEOUT (float): 21.0 seconds - timeout for measurement completion.

    Examples:
        >>> device = Device.create(DeviceFamily.LCR_METER, "PXI1Slot2")
        >>> params = LCRTestParameters(current_amplitude=0.07)
        >>> lcr_acir = LCRACIR(device, params)
        >>> result = lcr_acir.run()
        >>> print(f"Impedance: {result.z_magnitude:.4f} Ohm")
    """

    DEVICE_FAMILY: Final[DeviceFamily] = DeviceFamily.LCR_METER
    measurement_frequency: float = 1000.0
    MEASUREMENT_TIMEOUT: Final[float] = 21.0
    CURRENT_AMPLITUDE_MIN: Final[float] = 7.08e-9  # 7.08 nA
    CURRENT_AMPLITUDE_MAX: Final[float] = 0.707  # 707 mA

    def __init__(self, device: Device, test_parameters: LCRTestParameters):
        """Initialize the LCR ACIR measurement with the instrument device.

        Args:
            device (Device): The Device instance connected to an LCR Meter.
            test_parameters (LCRTestParameters): The LCRTestParameters for the measurement.

        Raises:
            ValueError: If device is None or invalid.
            TestSessionMismatchError: If the device is not a supported device
                or is otherwise incompatible with LCR ACIR measurement requirements.
        """
        if device is None:
            raise ValueError("Device cannot be None")

        if device.device_family is not LCRACIR.DEVICE_FAMILY:
            raise TestSessionMismatchError(
                f"{device.product} (family={device.device_family.name}) "
                f"is not supported by the Cell Quality Toolkit for a LCR ACIR test; "
                f"LCR ACIR requires a {LCRACIR.DEVICE_FAMILY.name} device."
            )

        self._device = device
        self._test_parameters = test_parameters
        self._result: Optional[LCRMeasurementResult] = None

    @property
    def device(self) -> Device:
        """Get the device instance.

        Returns:
            Device: The connected LCR Meter device instance.
        """
        return self._device

    @property
    def test_parameters(self) -> LCRTestParameters:
        """Get the test parameters.

        Returns:
            LCRTestParameters: The current LCR test parameters configuration.
        """
        return self._test_parameters

    @test_parameters.setter
    def test_parameters(self, value: LCRTestParameters):
        """Set the test parameters.

        Args:
            value (LCRTestParameters): The new LCR test parameters to apply.
        """
        self._test_parameters = value

    @property
    def result(self) -> Optional[LCRMeasurementResult]:
        """Get the last measurement result."""
        return self._result

    @staticmethod
    def validate_current_amplitude(current_amplitude: float) -> bool:
        """Validate that the current amplitude is within acceptable limits.

        Args:
            current_amplitude (float): The current amplitude to validate in Amperes RMS.

        Returns:
            bool: Always returns True when validation passes.

        Raises:
            LCRParameterError: If the current amplitude is outside the valid range
                (7.08 nA to 707 mA).
        """
        if not (
            LCRACIR.CURRENT_AMPLITUDE_MIN <= current_amplitude <= LCRACIR.CURRENT_AMPLITUDE_MAX
        ):
            raise LCRParameterError(
                f"current_amplitude {current_amplitude} A is out of valid range "
                f"({LCRACIR.CURRENT_AMPLITUDE_MIN} A to {LCRACIR.CURRENT_AMPLITUDE_MAX} A)."
            )
        return True

    def _configure(self) -> None:
        """Configure the LCR Meter session for ACIR measurement.

        Sets all required session properties for LCR-based impedance
        measurement at 1000 Hz with CURRENT stimulus.

        This method implements Steps 4-7 of the measurement flow:
        - Step 4: Compensation settings
        - Step 5: LCR configuration
        - Step 6: Commit
        - Step 7: Frequency and current amplitude
        """
        session = self._device.session
        params = self._test_parameters

        # STEP 4: Compensation settings
        session.lcr_open_short_load_compensation_data_source = (
            nidcpower.LCROpenShortLoadCompensationDataSource.ONBOARD_STORAGE
        )
        session.lcr_open_compensation_enabled = params.open_compensation_enabled
        session.lcr_short_compensation_enabled = params.short_compensation_enabled
        session.lcr_load_compensation_enabled = params.load_compensation_enabled

        # STEP 5: LCR configuration
        session.instrument_mode = nidcpower.InstrumentMode.LCR
        session.lcr_stimulus_function = nidcpower.LCRStimulusFunction.CURRENT
        session.cable_length = params.cable_length
        session.lcr_source_delay_mode = nidcpower.LCRSourceDelayMode.AUTOMATIC
        # Convert peak voltage range to RMS for nidcpower driver
        # PEAK_10V (10 V peak) → ~7.07 V RMS, PEAK_40V (40 V peak) → ~28.28 V RMS
        voltage_range_peak = 10.0 if params.voltage_range == LCRVoltageRange.PEAK_10V else 40.0
        voltage_range_rms = voltage_range_peak / math.sqrt(2.0)
        session.lcr_dc_bias_voltage_range = voltage_range_rms
        session.lcr_measurement_time = nidcpower.LCRMeasurementTime.MEDIUM
        session.lcr_impedance_auto_range = True
        session.lcr_impedance_range = 0
        session.lcr_dc_bias_source = nidcpower.LCRDCBiasSource.OFF

        # STEP 6: Commit
        session.commit()

        # STEP 7: Frequency and current amplitude
        session.lcr_frequency = LCRACIR.measurement_frequency
        session.lcr_current_amplitude = params.current_amplitude

    def _measure(self) -> LCRMeasurementResult:
        """Perform the LCR measurement and extract results.

        Implements Steps 8-11 of the measurement flow:
        - Step 8: Initiate
        - Step 9: Wait for Source Complete
        - Step 10: Measure
        - Step 11: Reset

        Returns:
            LCRMeasurementResult: The measurement results.
        """
        session = self._device.session

        # STEP 8: Initiate
        session.initiate()

        # STEP 9: Wait for Source Complete
        session.wait_for_event(
            event_id=nidcpower.Event.SOURCE_COMPLETE,
            timeout=LCRACIR.MEASUREMENT_TIMEOUT,
        )

        # STEP 10: Measure
        measurements = session.measure_multiple_lcr()
        measurement = measurements[0]  # Single channel

        # Extract results
        result = LCRMeasurementResult(
            impedance=measurement.z,
            z_magnitude=measurement.z_magnitude_and_phase[0],
            resistance=measurement.series_lcr.resistance,  # Rs, NOT Z.real!
            x_reactance=measurement.z.imag,
            theta=measurement.z_magnitude_and_phase[1],
            measured_frequency=measurement.stimulus_frequency,
        )

        # STEP 11: Reset
        session.reset()

        return result

    def run(self) -> LCRMeasurementResult:
        """Run the complete LCR ACIR measurement.

        Configures the device, performs the measurement, and returns the results.
        The measurement is performed at 1000 Hz (ACIR standard frequency).

        Returns:
            LCRMeasurementResult: The measurement results containing impedance,
                resistance, reactance, phase, and frequency data.

        Raises:
            LCRParameterError: If parameters are invalid.
            nidcpower.Error: If hardware operation fails.

        Examples:
            >>> device = Device.create(DeviceFamily.LCR_METER, "PXI1Slot2")
            >>> params = LCRTestParameters()
            >>> lcr_acir = LCRACIR(device, params)
            >>> result = lcr_acir.run()
            >>> print(f"Z = {result.z_magnitude:.4f} Ohm")
            >>> print(f"Rs = {result.resistance:.4f} Ohm")
            >>> print(f"Theta = {result.theta:.2f} degrees")
        """
        # Validate current amplitude before configuring driver
        LCRACIR.validate_current_amplitude(self._test_parameters.current_amplitude)

        # Validate load compensation requirement
        if self._test_parameters.load_compensation_enabled:
            if not (
                self._test_parameters.open_compensation_enabled
                and self._test_parameters.short_compensation_enabled
            ):
                raise LCRParameterError(
                    "Load compensation requires both open AND short compensation to be enabled"
                )

        # Configure and measure with session lock for thread safety
        with self._device.session.lock():
            self._configure()
            self._result = self._measure()

        return self._result

    def create_compensation(
        self,
        params: LCRCompensationParameters,
        skip_prompts: bool = False,
    ) -> LCRMeasurementResult:
        """Generate LCR compensation data and verify with a measurement.

        This method performs the complete 7-step compensation generation flow
        as defined in the LabVIEW "Create Compensation" example:

        1. Session init (already done via Device.create)
        2. Custom cable compensation (if enabled)
        3. Set cable length
        4. Open/Short compensation (if enabled)
        5. Load compensation (if enabled)
        6. Configure session for verification measurement
        7. Verification measurement (initiate, wait, measure, reset)

        The compensation data is stored on the device's onboard memory and
        remains available for subsequent measurements until the device is
        reset or powered off.

        User prompts are displayed before each step requiring physical connection
        changes (open, short, load). These prompts ensure the user has made
        the correct physical setup before compensation data is captured.

        Args:
            params (LCRCompensationParameters): LCRCompensationParameters with all
                configuration options.
            skip_prompts (bool): If True, skips user prompts for physical connections.
                User must ensure correct connections are made before each step.
                Useful for automated testing or scripted calibration sequences.
                Follows the Calibrator.self_calibrate(force=...) pattern.

        Returns:
            LCRMeasurementResult: Verification measurement result after
                compensation is applied. Can be used to verify compensation
                quality (should show near-zero impedance for a short).

        Raises:
            LCRParameterError: If parameters are invalid (e.g., load comp
                without open AND short).
            nidcpower.Error: If hardware operation fails.

        Examples:
            >>> # Interactive compensation with user prompts
            >>> lcr = LCRACIR(device, test_params)
            >>> result = lcr.create_compensation(
            ...     LCRCompensationParameters(
            ...         generate_open=True,
            ...         generate_short=True,
            ...         enable_open=True,
            ...         enable_short=True,
            ...     )
            ... )
            >>> print(f"Verification Z: {result.z_magnitude:.6f} Ohm")
            >>>
            >>> # Automated compensation (for testing)
            >>> result = lcr.create_compensation(params, skip_prompts=True)
        """
        # Call the shared compensation helper function with session lock for thread safety
        with self._device.session.lock():
            raw_result = perform_lcr_compensation(
                session=self._device.session,
                params=params,
                skip_prompts=skip_prompts,
                timeout=LCRACIR.MEASUREMENT_TIMEOUT,
            )

        # Convert raw dict result to LCRMeasurementResult
        return LCRMeasurementResult(
            impedance=raw_result["z"],
            z_magnitude=raw_result["z_magnitude"],
            resistance=raw_result["resistance"],
            x_reactance=raw_result["z"].imag,
            theta=raw_result["z_phase"],
            measured_frequency=raw_result["stimulus_frequency"],
        )
