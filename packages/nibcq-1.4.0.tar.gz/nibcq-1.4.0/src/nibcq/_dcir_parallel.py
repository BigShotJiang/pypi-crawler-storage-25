"""Defines the Parallel DCIR measurement for the nibcq package."""

import contextlib
import math
from collections.abc import Iterator, Sequence
from typing import Union, override

import nidcpower

from nibcq._dcir import DCIR, DCIRTestParameters
from nibcq._device import Device
from nibcq.enums import MultiDeviceMode
from nibcq.errors import TestSessionMismatchError
from nibcq.measurement import ParallelMeasurement, SMUMeasurement


class ParallelDCIR(ParallelMeasurement, DCIR):
    """Defines a DCIR measurement with multiple ELoads working in parallel.

    This class enables DC internal resistance measurements using multiple Electronic Load
    devices connected in parallel to achieve higher current draw than a single ELoad can
    provide.

    DCIR measurements in general does NOT have switching support, but implementing one to the
    parallel implementation is highly discouraged due to hardware current limitations of switch
    matrices (typically limited to ~2A). Parallel DCIR is designed for direct-connection,
    high-current testing scenarios.

    The measurement applies a two-phase discharge sequence (20% then 100% of the
    configured max load current) distributed evenly across all devices. Internal
    resistance is calculated from the voltage and current differences using Ohm's law:
    R = (V1 - V2) / (I1 - I2), where subscripts 1 and 2 refer to the light-load
    (20%) and heavy-load (100%) phases respectively.

    Key Features:
        - Multiple ELoads synchronized via hardware triggers (PXI backplane).
        - Current capacity scales linearly with number of devices (e.g., 3 ELoads = 3x current).
        - Voltage measured from leader device (remote sense for accuracy).
        - Current contributions summed across all devices.

    Hardware Requirements:
        - All devices must be NI PXIe-4051 or compatible Electronic Loads.
        - Devices must be in the same PXI chassis for trigger routing.
        - One device designated as leader, others as followers.

    Example:
        >>> leader_device = Device.create(DeviceFamily.ELOAD, "PXI1Slot2")
        >>> follower1 = Device.create(DeviceFamily.ELOAD, "PXI1Slot3")
        >>>
        >>> params = DCIRTestParameters(
        ...     max_load_current=2.0,
        ...     powerline_frequency=PowerlineFrequency.FREQ_50_HZ,
        ... )
        >>>
        >>> parallel_dcir = ParallelDCIR(
        ...     leader=leader_device,
        ...     followers=[follower1],
        ...     test_parameters=params,
        ... )
        >>>
        >>> result = parallel_dcir.run()
        >>> print(f"DC Resistance: {result} Ohms")
    """

    def __init__(
        self,
        leader: Device,
        followers: Sequence[Device],
        test_parameters: DCIRTestParameters,
        multi_device_type: MultiDeviceMode = MultiDeviceMode.PARALLEL,
    ):
        """Initializes a Parallel DCIR measurement with a leader and at least one follower.

        Args:
            leader (Device): The single ELoad device that acts as the timing source.
                It provides the start trigger and supplies remote-sense voltage data.
            followers (Sequence[Device]): An ordered collection of ELoad devices that arm
                themselves and then wait for the leader's start trigger.
            test_parameters (DCIRTestParameters): Measurement configuration parameters such
                as max load current and power-line frequency.
            multi_device_type (MultiDeviceMode): How the devices share the load current.
                Defaults to ``MultiDeviceMode.PARALLEL``.

        Raises:
            TypeError: If the leader or any follower is not a ``Device`` instance.
            TestSessionMismatchError: If any supplied device is not an Electronic Load
                (``DeviceFamily.ELOAD``).
        """
        ParallelMeasurement.__init__(self, leader, followers, test_parameters)
        # Ensure every device belongs to the Electronic Load family
        for device in self.get_all_devices():
            if device.device_family is not DCIR.DEVICE_FAMILY:
                raise TestSessionMismatchError(
                    f"{device.product} (family={device.device_family.name}) "
                    f"is not supported by the Cell Quality Toolkit for a DCIR test; "
                    f"DCIR requires a {DCIR.DEVICE_FAMILY.name} device."
                )

        # Initialize measurement storage aligned with device list by index
        self._raw_measurement_data = [None] * (len(self._followers) + 1)

        self._set_init_parameters()
        self.multi_device_type = multi_device_type
        self._multidevice_measurement_data = None
        self._result = None
        self._test_parameters = test_parameters

    @property
    def all_measurement_data(self) -> Iterator[tuple[Device, SMUMeasurement | None]]:
        """Get the processed measurement data from the last DCIR test.

        Returns voltage and current measurement data collected during the two-phase
        discharge sequence, over all devices. This data includes all samples from both
        discharge periods and later combined across devices for further calculations.

        Returns:
            Iterator[tuple[Device, SMUMeasurement | None]]: Iterator of tuples pairing each
                Device with its corresponding SMUMeasurement. The tone_frequency is set
                to 0 for DC measurements. Yields tuples with None measurements if no
                measurement has been performed yet.

        Example:
            >>> for device, measurement in parallel_dcir.all_measurement_data:
            ...     print(f"Device: {device.product}")
            ...     print(f"Voltage samples: {len(measurement.voltage_values)}")
        """
        return zip(self.get_all_devices(), self._raw_measurement_data)

    @property
    @override
    def measurement_data(self) -> Union[None, SMUMeasurement]:
        """Get the processed measurement data from the last DCIR test.

        Returns voltage and current measurement data collected during the two-phase
        discharge sequence, combined across all devices. This data includes all samples from both
        discharge periods and can be used for detailed analysis or custom calculations.

        Returns:
            SMUMeasurement: Processed and multidevice-combined measurement data containing
                            voltage_values and current_values lists, combined across
                            all devices. The tone_frequency is set to 0 for DC
                            measurements. Returns None if the multidevice aggregation of
                            measurements has not been performed yet.
        """
        return self._multidevice_measurement_data

    def _build_terminal_name(
        self,
        channel_name: int | str,
        local_terminal_name: str,
    ) -> str:
        """Build a terminal name string for device configuration.

        Args:
            channel_name (int | str): The channel identifier (typically an integer).
            local_terminal_name (str): The local terminal name string.

        Returns:
            str: A formatted terminal name string for device configuration.

        Raises:
            RuntimeError: If device is not initialized.
        """
        if not self._leader:
            raise RuntimeError("Device is not initialized.")
        return (
            "/"
            + self._leader.session.io_resource_descriptor
            + "/Engine"
            + str(channel_name)
            + "/"
            + str(local_terminal_name)
        )

    def _configure(self):
        """Configure the electronic loads for parallel DCIR measurement execution.

        Sets up multiple ELoad devices working in parallel with all necessary parameters
        for the two-phase DCIR measurement sequence. This includes discharge current
        calculations distributed across devices, timing parameters, measurement settings,
        trigger synchronization, and hardware configuration validation.

        The configuration process:
        1. Calculates discharge currents (20% and 100% of max_load_current)
        2. Distributes current load across parallel devices based on multidevice configuration
        3. Configures leader-follower trigger synchronization using start triggers
        4. Sets measurement parameters (aperture time, samples, noise rejection)
        5. Configures sensing mode (remote for leader, local for followers)
        6. Sets up the current sequence for two-phase discharge on all devices
        7. Configures current level ranges with appropriate division for parallel operation
        8. Commits configuration and enables outputs on all devices

        The method ensures all devices are properly synchronized and configured before
        measurement begins. Leader device provides start trigger signal that follower
        devices synchronize to for coordinated parallel operation.

        Raises:
            NotImplementedError: If the multi_device_type is not MultiDeviceMode.PARALLEL,
                        as only parallel operation is currently supported.
            ValueError: If the electronic load configuration parameters are not set
                        correctly during configuration. This can occur if the devices
                        do not accept the calculated current ranges or sample counts,
                        indicating hardware limitations or compatibility issues.
            RuntimeError: If any device session cannot be properly configured or
                        if communication with the hardware fails during setup.

        Example:
            >>> parallel_dcir._configure()  # Prepares all devices for measurement
        """
        if self.multi_device_type is not MultiDeviceMode.PARALLEL:
            raise NotImplementedError(
                f"Only {MultiDeviceMode.PARALLEL.value} MultiDeviceMode is currently supported, "
                f"but '{self.multi_device_type.value}' was provided."
            )

        # Configure eload
        self._calculate_discharge_current()
        # Build timing trigger terminal name
        start_trigger = self._build_terminal_name("0", "StartTrigger")

        # Configure the Eloads for the DCIR, eload measurement properties
        # Configure start trigger
        for device in self.get_all_devices():
            sess = device.session
            if device in self._followers:
                sess.start_trigger_type = nidcpower.TriggerType.DIGITAL_EDGE
                sess.digital_edge_start_trigger_input_terminal = start_trigger
            sess.measure_when = nidcpower.MeasureWhen.AUTOMATICALLY_AFTER_SOURCE_COMPLETE

            # Configure Sense
            sess = device.session
            if device in self._followers:
                sess.sense = nidcpower.Sense.LOCAL
            else:
                sess.sense = nidcpower.Sense.REMOTE

            # Set Aperture Time
            sess = device.session
            sess.aperture_time = self._obtained_measurement_parameters.aperture_time
            sess.aperture_time_units = self._obtained_measurement_parameters.aperture_time_units
            sess.power_line_frequency = self.test_parameters.powerline_frequency.value

            # Other values to set
            sess = device.session
            sess.auto_zero = nidcpower.AutoZero.OFF
            sess.dc_noise_rejection = nidcpower.DCNoiseRejection.NORMAL
            sess.measure_record_length = self._obtained_measurement_parameters.number_of_samples

        # Configure the ELoads Discharge Properties
        output_function_to_set = nidcpower.OutputFunction.DC_CURRENT
        divider_number = len(self._followers) + 1
        values_to_set = [
            self._obtained_discharge_parameters.discharge_current_1 / divider_number,
            self._obtained_discharge_parameters.discharge_current_2 / divider_number,
        ]
        delays_to_set = [
            self._input_discharge_parameters.discharge_period_1,
            self._input_discharge_parameters.discharge_period_2,
        ]

        # Set sequence
        for device in self.get_all_devices():
            sess = device.session
            sess.set_sequence(values=values_to_set, source_delays=delays_to_set)
            sess.output_function = output_function_to_set
            sess.source_mode = nidcpower.SourceMode.SEQUENCE

        # Set Current Level Range
        current_level_range_to_set = self.test_parameters.max_load_current
        if self.multi_device_type == MultiDeviceMode.PARALLEL:
            current_level_range_to_set /= len(self._followers) + 1
        for device in self.get_all_devices():
            sess = device.session
            sess.current_level_range = current_level_range_to_set
            sess.current_level_autorange = False
            # Commit and enable the output
            device.session.commit()
            device.session.output_enabled = True

        # Connect output
        for device in self.get_all_devices():
            if not device.session.output_connected:
                device.session.output_connected = True

    def _populate_multidevice_measurement_data(self, data_point_count: int):
        """Populate the multidevice measurement data from individual device measurements.

        Args:
            data_point_count: Number of data points in each measurement.

        Raises:
            IndexError: If any device has a different number of measurements than expected.
            NotImplementedError: If multidevice configuration type is not PARALLEL.
        """
        # Validate that all devices have the expected number of measurements
        for idx, measurement in enumerate(self._raw_measurement_data):
            if measurement is not None:
                if len(measurement.voltage_values) != data_point_count:
                    raise IndexError(
                        f"Device at index {idx} has {len(measurement.voltage_values)} voltage samples, "
                        f"expected {data_point_count}"
                    )
                if len(measurement.current_values) != data_point_count:
                    raise IndexError(
                        f"Device at index {idx} has {len(measurement.current_values)} current samples, "
                        f"expected {data_point_count}"
                    )

        all_voltage = [0.0] * data_point_count
        all_current = [0.0] * data_point_count

        if self.multi_device_type is MultiDeviceMode.PARALLEL:
            # Use leader's voltage measurements
            leader_idx = len(self._followers)  # By convention, leader is last amongst the devices.
            all_voltage = self._raw_measurement_data[leader_idx].voltage_values

            # Sum current measurements from all devices
            for measurement in self._raw_measurement_data:
                measurement_currents = measurement.current_values
                all_current = [a + b for a, b in zip(all_current, measurement_currents)]

            self._multidevice_measurement_data = SMUMeasurement(
                tone_frequency=0,
                voltage_values=all_voltage,
                current_values=all_current,
            )
        # Currently no other work flow is supported
        else:
            raise NotImplementedError("Non-Parallel configuration types are not supported yet.")

    def _measure(self):
        """Execute the DCIR measurement sequence and acquire data from all devices.

        Performs the complete two-phase discharge measurement by initiating the
        current sequence on all devices, waiting for completion sequentially, and
        fetching the resulting voltage and current data. The measurement follows
        this sequence:

        1. Initiate the pre-configured current sequence on all electronic loads
        2. Wait for sequence completion on all devices sequentially
        3. Fetch voltage and current measurements from all devices
        4. Store data in SMUMeasurement format for subsequent analysis
        5. Clean up hardware state and disable outputs on all devices

        Hardware synchronization via trigger signals ensures coordinated parallel
        operation of all devices, while the software waits for and fetches data
        sequentially.

        Raises:
            RuntimeError: If measurement data cannot be retrieved from any device, if the
                sequence engine fails to complete within the timeout period, or if
                hardware communication errors or timeouts occur during data acquisition.
                The error message identifies which specific device encountered the
                failure and whether the underlying cause was a timeout or another
                hardware or DUT issue.

        Example:
            >>> parallel_dcir._measure()  # Executes measurement and stores data internally
        """
        # Clear previous measurements to allow re-run
        self._raw_measurement_data = [None] * (len(self._followers) + 1)

        # Initiate the measurement devices one after another (leader comes last)
        for device in self.get_all_devices():
            device.session.initiate()

        # Wait for all devices to complete sequentially
        # Hardware synchronization ensures coordinated operation
        timeout = self._calculate_timeout()
        for device in self.get_all_devices():
            try:
                device.session.wait_for_event(
                    event_id=nidcpower.Event.SEQUENCE_ENGINE_DONE,
                    timeout=timeout,
                )
            except Exception as exc:
                raise RuntimeError(
                    f"Device {device.product} on channel " f"{0} failed during sequence wait: {exc}"
                ) from exc

        # Using a constant of 2 for the two setpoints used in DischargeCurrents
        number_of_setpoints = 2
        to_fetch = self._obtained_measurement_parameters.number_of_samples * number_of_setpoints
        for idx, device in enumerate(self.get_all_devices()):
            try:
                measurements = device.session.fetch_multiple(
                    count=to_fetch,
                    timeout=timeout,
                )
                # Using a SMUMeasurement dataclass with 0 frequency for DCIR measurements
                self._raw_measurement_data[idx] = SMUMeasurement(
                    tone_frequency=0,
                    voltage_values=[m.voltage for m in measurements],
                    current_values=[m.current for m in measurements],
                )
            except Exception as exc:
                raise RuntimeError(
                    f"Device {device.product} on channel " f"{0} failed during data fetch: {exc}"
                ) from exc
        # Transform raw measurement data into a multidevice format
        self._populate_multidevice_measurement_data(to_fetch)

        # Clean up all devices after measurement completion
        for device in self.get_all_devices():
            device.session.abort()
        for device in self.get_all_devices():
            device.session.reset()
            device.session.output_enabled = False
            device.session.output_connected = False

    def run(self) -> float:
        """Execute the complete DCIR measurement process and return the result.

        Performs the full DCIR measurement sequence including device configuration,
        two-phase discharge measurement, and internal resistance calculation. The
        method coordinates all measurement steps and ensures proper resource
        management through session locking.

        The measurement process follows these steps:
        1. Acquire exclusive session lock on every device via a shared ExitStack
        2. Configure the electronic loads with calculated parameters
        3. Execute the two-phase discharge measurement sequence
        4. Calculate internal resistance from voltage and current data
        5. Validate the result for mathematical and physical validity
        6. Release all session locks (guaranteed even if an earlier step raised)

        Returns:
            float: The measured internal resistance in Ohms. Valid results are finite,
                  positive values representing the DC resistance of the DUT under
                  the specified load conditions.

        Raises:
            NotImplementedError: If the multi_device_type is not MultiDeviceMode.PARALLEL,
                         as only parallel operation is currently supported.
            ValueError: If the calculated resistance is NaN (zero current difference)
                       or infinite (indicating measurement or calculation errors),
                       if device configuration fails due to invalid parameters,
                       or if measurement data validation fails.
            RuntimeError: If the measurement process fails at any step due to
                         hardware communication errors, device malfunctions, or
                         resource conflicts with other measurement sessions.
            TimeoutError: If the measurement sequence does not complete within
                         the calculated timeout period.

        Example:
            >>> # Configure and run DCIR measurement
            >>> params = DCIRTestParameters(max_load_current=2.0)
            >>> dcir = DCIR(device, params)
            >>> resistance = dcir.run()
            >>> print(f"DCIR: {resistance:.4f} Ohms")
        """
        # Use ExitStack to enter each session's lock context manager. This guarantees that:
        # - If any lock() call raises an exception, all already-acquired locks are released.
        # - After the block exits (normally or via exception), every acquired lock is released
        #   even if one or more releases fail, because ExitStack calls __exit__ on all entered
        #   contexts before propagating any exception.
        with contextlib.ExitStack() as stack:
            for device in self.get_all_devices():
                stack.enter_context(device.session.lock())
            self._configure()
            self._measure()
            result = self._impedance_calculation()
            if math.isnan(result) or math.isinf(result):
                raise ValueError(
                    "Invalid measurement result: NaN or Infinity encountered. "
                    "Measurement either failed or was not properly configured. "
                    "Check your Test Parameters and your device connections."
                )

        return self._result
