# Change Log

All important changes to the sing4me package will be documented here.

The changelog format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/) and the project uses [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [v2.0.0rc0]

### Added

- Added a modern PEP 621 `pyproject.toml` (Hatchling backend) so the package can be built and published to PyPI as `sing4me`.
- Added Python 3.9 / 3.10 / 3.11 / 3.12 / 3.13 classifiers and `requires-python = ">=3.9"`.
- Added `[project.urls]` for Homepage / Repository / Issues.
- Added `dev`, `notebook`, and `publish` optional-dependency extras (`pip install -e ".[dev]"`, `pip install -e ".[notebook]"`, `pip install -e ".[publish]"`).
- Added the `textgrid` runtime dependency (it is imported by `sing4me.singing_extract` but was missing from the legacy `requirements.txt`).
- Added a real GitLab CI `test` stage on `python:3.13-slim` that installs the package, smoke-imports it, runs `sing4me --version`, builds the wheel/sdist, and runs `twine check` on the artifacts.

### Changed

- Bumped version from 2.0.0 to 2.0.0rc0 to mark the first PyPI release candidate.
- Removed lower-bound version specifiers from runtime dependencies. The codebase doesn't rely on modern numpy/scipy/etc. APIs, so pip's resolver can pick compatible versions and `requires-python = ">=3.9"` is preserved as the floor.
- The `syllable_extract.praat` script and the `VERSION` file are now `force-include`d in the wheel so they are reliably available next to the package code regardless of the user's working directory.
- `sing4me/VERSION` is now the single source of truth for the package version: `pyproject.toml` reads it at build time via Hatchling's regex version source (`dynamic = ["version"]`), and `sing4me/__init__.py` reads the same file at import time. The wheel/sdist metadata, `sing4me --version`, and `sing4me.__version__` therefore can never drift.
- Use an absolute GitLab raw URL for the README logo so it renders correctly on PyPI.

### Removed

- Removed `setup.py` (replaced by `pyproject.toml`).
- Removed `MANIFEST.in` (not used by Hatchling; replaced by explicit wheel/sdist include/exclude rules in `pyproject.toml`).
- Removed `requirements.txt` (replaced by `dependencies = [...]` in `pyproject.toml`).
- Removed the unused `docopt` and `flask` dependencies (declared in the legacy `setup.py` / `requirements.txt` but not imported by any code remaining in this repository).
- Excluded the large `sing4me/tests/` sample-audio directory from the published wheel and sdist. Those samples are kept in the source repository for development but are not shipped with the PyPI distribution; the same applies to the top-level `input/`, `output/`, and `demos/` directories.

## [v2.0.0]

- Removed all psynet related dependencies
- Included only singing extract and demos
- Made it public

## [v1.3.0]

### Added

- Improved extraction by relaxing failing criteria and adding failing reason in plots

## [v1.2.0]

### Added

- Praat functionality to extract syllables/ rhythm

## [v1.1.3]

### Added

- Added params for rhythm experimetns with singing

## [v1.1.3]

### Change

- Changed package name to sing4me

## [v1.1.1]

### Added

- Added new package name: sing4me

## [v1.1.0]

### Added

- Created SING package
