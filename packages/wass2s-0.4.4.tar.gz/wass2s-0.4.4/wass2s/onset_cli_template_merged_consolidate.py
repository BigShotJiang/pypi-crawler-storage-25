#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
WASS2S Onset Forecast CLI — structured from the cumulative seasonal CLI,
but adapted to an onset predictand derived from daily rainfall.

Design goals
------------
1. Keep the cumulative CLI architecture:
   - argparse parser
   - modular stage functions
   - checkpoints
   - intermediate NetCDF outputs
   - score pickles
   - final consolidation
2. Add onset-specific preprocessing:
   - download daily observations
   - compute onset from daily rain
   - optional merge with CPT/station onset data
   - download daily model rain
   - preprocess / bias-correct daily model rain
   - convert corrected daily rain to onset dates
3. Preserve WASS2S API style and naming.

This file is intentionally exhaustive and designed as a production-ready
starting point. Some helper functions/classes are assumed to already exist
in your local wass2s package exactly as they appear in your notebook, e.g.:
    - WAS_compute_onset
    - WAS_Download_AgroIndicators_daily
    - WAS_Download_Models_Daily
    - pre_process_biophysical_model
    - proceed_seasonal_daily_bias_correction
    - process_model_for_other_params
    - compute_sst_indices

If one helper has a slightly different name in your installed package,
replace only that local call; the CLI architecture can stay unchanged.
"""

import os
import gc
import json
import time
import argparse
import calendar
import datetime as dt
import warnings
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import xarray as xr
import joblib

from scipy.stats import loguniform
from statsmodels.stats.outliers_influence import variance_inflation_factor as VIF

from wass2s import *


# =========================
# Defaults & Constants
# =========================
DEFAULT_DIR = "./ONSET_2026_ic_01/"
DEFAULT_LOGO = "./utilities/cilss.png"
DEFAULT_COUNTRY_ISO3 = "BEN"
ONSET_LABELS_EN = ["EARLY", "NORMAL", "LATE"]
ONSET_LABELS_FR = ["PRECOCE", "NORMALE", "TARDIVE"]

DEFAULT_CLIM_YEARS = (1994, 2016)
DEFAULT_HIND_YEARS = (1993, 2016)
DEFAULT_OBS_YEARS = (1991, dt.date.today().year - 1)
DEFAULT_ONSET_EXTENT = [8, -3.5, 4, 1.5]
DEFAULT_REAN_SST_EXTENT = [60, -180, -60, 180]
DEFAULT_REAN_FIELD_EXTENT = [30, -30, -20, 30]

CHECKPOINTS = {
    "obs": "chk_obs.json",
    "daily_models": "chk_daily_models.json",
    "sv_ml_cmme": "chk_sv_ml_cmme.json",
    "cca_gcm": "chk_cca_gcm.json",
    "obs_lag": "chk_obs_lag.json",
    "analog": "chk_analog.json",
    "consolidate": "chk_consolidate.json",
}

# Conservative default list copied from the onset notebook pattern.
DEFAULT_ONSET_CENTERS = [
    "BOM_2.PRCP",
    "ECMWF_51.PRCP",
    "UKMO_604.PRCP",
    "METEOFRANCE_9.PRCP",
    "DWD_22.PRCP",
    "NCEP_2.PRCP",
]

DEFAULT_SST_INDICES = ["NINO34", "TNA", "TSA", "DMI", "MB"]


def default_onset_criteria_payload():
    """
    Build criteria from the package default if available, otherwise use a local fallback.
    """
    try:
        crit = json.loads(json.dumps(onset_criteria))
    except Exception:
        crit = [
            {
                "start_search": "02-01",
                "end_search": "05-15",
            }
        ]
    return crit


# =========================
# Helpers
# =========================
def log_progress(step_name: str):
    now = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"\n[{now}] >>> {step_name}", flush=True)


def save_and_close_plot(filepath):
    filepath = Path(filepath)
    filepath.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(filepath, bbox_inches="tight", dpi=300)
    plt.close("all")


def save_json(path: Path, payload: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False))


def done(check_dir: Path, key: str) -> bool:
    return (check_dir / CHECKPOINTS[key]).exists()


def mark_done(check_dir: Path, key: str, meta: dict):
    save_json(check_dir / CHECKPOINTS[key], meta)


def load_scores(pkl_path: Path):
    import pickle
    if pkl_path.exists():
        with open(pkl_path, "rb") as f:
            return pickle.load(f)
    return {}


def save_scores(workdir: Path, scores: dict, scorefile: str):
    import pickle
    pkl_path = workdir / "intermediate" / scorefile
    pkl_path.parent.mkdir(parents=True, exist_ok=True)
    with open(pkl_path, "wb") as f:
        pickle.dump(scores, f)


def update_nested_dict(d1, d2):
    for k, v in d2.items():
        if k in d1 and isinstance(d1[k], dict) and isinstance(v, dict):
            update_nested_dict(d1[k], v)
        else:
            d1[k] = v
    return d1


def filter_center_variable(keys, contains):
    return [k for k in keys if isinstance(k, str) and "." in k and contains in k.split(".", 1)[1]]


def load_bestfit_params(workdir: Path):
    path = workdir / "best_distribution_params.nc"
    if path.exists():
        ds = xr.load_dataset(path)
        return ds.code, ds.shape, ds.loca, ds.scale
    return None, None, None, None


def season_to_str(months, lang="en", mode="abbr"):
    fr_data = {
        1: {"total": "Janvier", "abbr": "Jan", "initial": "J"},
        2: {"total": "Février", "abbr": "Fév", "initial": "F"},
        3: {"total": "Mars", "abbr": "Mar", "initial": "M"},
        4: {"total": "Avril", "abbr": "Avr", "initial": "A"},
        5: {"total": "Mai", "abbr": "Mai", "initial": "M"},
        6: {"total": "Juin", "abbr": "Jun", "initial": "J"},
        7: {"total": "Juillet", "abbr": "Jul", "initial": "J"},
        8: {"total": "Août", "abbr": "Aoû", "initial": "A"},
        9: {"total": "Septembre", "abbr": "Sep", "initial": "S"},
        10: {"total": "Octobre", "abbr": "Oct", "initial": "O"},
        11: {"total": "Novembre", "abbr": "Nov", "initial": "N"},
        12: {"total": "Décembre", "abbr": "Déc", "initial": "D"},
    }

    out = []
    for m in months:
        idx = int(m)
        if lang.lower() == "fr":
            out.append(fr_data[idx][mode])
        else:
            if mode == "total":
                out.append(calendar.month_name[idx])
            elif mode == "abbr":
                out.append(calendar.month_abbr[idx])
            else:
                out.append(calendar.month_name[idx][0])
    return "".join(out) if mode == "initial" else "-".join(out)


def _setup_parallel(ncores: int, threads_per_worker: int = 1, use_dask: bool = True):
    ncores = int(max(1, ncores))
    for k in [
        "OMP_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
        "MKL_NUM_THREADS",
        "VECLIB_MAXIMUM_THREADS",
        "NUMEXPR_NUM_THREADS",
    ]:
        os.environ.setdefault(k, "1")

    client = None
    if use_dask:
        try:
            from dask.distributed import Client, LocalCluster
            n_workers = min(ncores, max(1, ncores // max(1, threads_per_worker)))
            cluster = LocalCluster(
                n_workers=n_workers,
                threads_per_worker=threads_per_worker,
                processes=True,
                memory_limit=0,
                dashboard_address=None,
            )
            client = Client(cluster)
            print(f"[parallel] Dask Client started: workers={n_workers}, threads/worker={threads_per_worker}")
        except Exception as e:
            print(f"[parallel] Dask not started. Reason: {e}")
    os.environ.setdefault("WAS_NCORES", str(ncores))
    return client


def get_cv_kwargs(args, workdir: Path):
    best_code_da, best_shape_da, best_loc_da, best_scale_da = load_bestfit_params(workdir)
    if args.dist_method == "bestfit":
        return {
            "best_code_da": best_code_da,
            "best_shape_da": best_shape_da,
            "best_loc_da": best_loc_da,
            "best_scale_da": best_scale_da,
        }
    return {}


def write_intermediate_pair(workdir: Path, prefix: str, hind_det=None, hind_prob=None, fcst_det=None, fcst_prob=None):
    (workdir / "intermediate").mkdir(parents=True, exist_ok=True)

    ds_h = xr.Dataset()
    ds_f = xr.Dataset()
    if hind_det is not None:
        ds_h[f"hdcst_det_{prefix}"] = hind_det
    if hind_prob is not None:
        ds_h[f"hdcst_prob_{prefix}"] = hind_prob
    if fcst_det is not None:
        ds_f[f"fcst_det_{prefix}"] = fcst_det
    if fcst_prob is not None:
        ds_f[f"fcst_prob_{prefix}"] = fcst_prob

    if ds_h.data_vars:
        ds_h.to_netcdf(workdir / f"intermediate/{prefix.lower().replace(' ', '_')}_hindcasts.nc")
    if ds_f.data_vars:
        ds_f.to_netcdf(workdir / f"intermediate/{prefix.lower().replace(' ', '_')}_forecasts.nc")


def evaluate_and_plot_forecasts(
    was_verify,
    obs_da,
    hindcast_det,
    hindcast_prob,
    forecast_prob,
    model_name,
    dict_key,
    clim_start,
    clim_end,
    scores_consolidated,
    dir_save_score,
    dir_to_forecast,
    forecast_year,
    month_init,
    labels,
    reverse_cmap=True,
    country_iso3=None,
    logopath=None,
):
    if hindcast_det is not None:
        for metric in ["Pearson", "MAE"]:
            r = was_verify.compute_deterministic_score(
                was_verify.get_scores_metadata()[metric][5],
                obs_da,
                hindcast_det,
            )
            scores_consolidated.setdefault(metric, {})[dict_key] = r.compute()
            try:
                was_verify.plot_model_score(r, metric, dir_save_score, model_name)
                plt.close("all")
            except Exception:
                pass

    if hindcast_prob is not None:
        for metric in ["GROC", "RPSS"]:
            r = was_verify.compute_probabilistic_score(
                was_verify.get_scores_metadata()[metric][5],
                obs_da,
                hindcast_prob,
                clim_start,
                clim_end,
            )
            scores_consolidated.setdefault(metric, {})[dict_key] = r.compute()
            try:
                was_verify.plot_model_score(r, metric, dir_save_score, model_name)
                plt.close("all")
            except Exception:
                pass

    if forecast_prob is not None:
        try:
            plot_prob_forecasts_(
                str(dir_to_forecast),
                forecast_prob.drop_vars("T").squeeze(),
                f"{model_name} Onset-{forecast_year} IC: {calendar.month_name[int(month_init)]}",
                hspace=0.1,
                labels=labels,
                reverse_cmap=reverse_cmap,
            )
        except Exception as e:
            print(f"Basic plot failed for {model_name}: {e}")

        if country_iso3 is not None:
            try:
                plot_prob_forecasts(
                    str(dir_to_forecast),
                    forecast_prob.drop_vars("T").squeeze(),
                    f"{model_name} Onset-{forecast_year} IC: {calendar.month_name[int(month_init)]}",
                    country_code=country_iso3,
                    source="gadm",
                    admin_level=1,
                    stations_df=None,
                    reverse_cmap=reverse_cmap,
                    hspace=-0.5,
                    labels=labels,
                    logo=logopath,
                    logo_size=("21%", "14%"),
                    logo_position="lower left",
                    res=0.05,
                    out="png",
                )
                plt.close("all")
            except Exception as e:
                print(f"Advanced plot failed for {model_name}: {e}")


def _mme_factory(name: str, args):
    name = (name or "hpelm").lower()

    if name == "rf":
        return WAS_mme_RF(
            search_method="bayesian",
            n_iter_search=50,
            n_estimators_range=[100, 300, 500, 800, 1000],
            max_depth_range=[2, 3, 5, 7, 10, None],
            min_samples_split_range=[2, 5, 10, 15],
            min_samples_leaf_range=[1, 2, 3, 5],
            max_features_range=["sqrt", "log2", 0.3, 0.5],
            bootstrap_range=[True, False],
            cv_folds=5,
            n_clusters=2,
            random_state=42,
            dist_method=args.dist_method,
            optuna_n_jobs=getattr(args, "ncores", 1),
            optuna_timeout=3600,
        )

    if name == "xgb":
        return WAS_mme_XGBoosting(
            search_method="bayesian",
            n_estimators_range=[50, 100, 200, 300, 500],
            learning_rate_range=[0.001, 0.01, 0.05, 0.1],
            max_depth_range=[2, 3, 4, 5, 7],
            min_child_weight_range=[1, 2, 5, 10],
            subsample_range=[0.6, 0.8, 1.0],
            colsample_bytree_range=[0.5, 0.7, 0.9, 1.0],
            gamma_range=[0, 0.01, 0.1, 0.5],
            reg_alpha_range=[0, 0.1, 0.5, 1.0],
            reg_lambda_range=[1, 3, 5, 10],
            random_state=42,
            dist_method=args.dist_method,
            n_iter_search=40,
            cv_folds=5,
            n_clusters=2,
            optuna_n_jobs=getattr(args, "ncores", 1),
            optuna_timeout=3600,
        )

    if name == "mlp":
        return WAS_mme_MLP(
            hidden_layer_sizes_range=[(2, 2), (3, 2), (4, 2), (5, 2), (8, 4), (16, 8)],
            learning_rate_init_range=loguniform(1e-4, 1e-1),
            activation_options=["tanh", "identity"],
            solver_options=["adam", "sgd"],
            alpha_range=loguniform(1e-5, 1e-1),
            search_method="bayesian",
            random_state=42,
            n_iter_search=25,
            max_iter=2000,
            cv_folds=5,
            n_clusters=1,
            dist_method=args.dist_method,
            optuna_n_jobs=getattr(args, "ncores", 1),
            optuna_timeout=1800,
        )

    if name == "stack":
        return WAS_mme_Stacking(
            meta_learner_type=args.meta_learner,
            alpha_range=[0.1, 1.0, 10.0, 100.0],
            random_state=42,
            dist_method=args.dist_method,
            stacking_cv=3,
            meta_cv_folds=3,
            meta_n_iter_search=10,
            n_clusters=4,
        )

    return WAS_mme_hpELM(
        neurons_range=[5, 10, 25, 50, 100, 200],
        activation_options=["lin", "tanh"],
        norm_range=loguniform(1e-2, 1e2),
        random_state=42,
        n_iter_search=100,
        cv_folds=5,
        dist_method=args.dist_method,
        search_method="bayesian",
        n_clusters=1,
        n_trials_bayesian=60,
        bayesian_sampler="tpe",
    )


# =========================
# Stage 1 — Observation / Onset Predictand
# =========================
def stage_obs(args, workdir: Path, downloader):
    check_dir = workdir / "checkpoints"
    if done(check_dir, "obs") and not args.redo:
        print("[obs] checkpoint exists → skip")
        return

    scores_dir = workdir / "scores"
    scores_dir.mkdir(parents=True, exist_ok=True)
    obs_dir = workdir / "Observation"
    obs_dir.mkdir(parents=True, exist_ok=True)

    try:
        plot_map(
            [args.obs_extent[1], args.obs_extent[3], args.obs_extent[2], args.obs_extent[0]],
            title="Onset Observation Area",
            fig_size=(4, 3),
        )
        save_and_close_plot(scores_dir / "Map_Onset_Observation_Area.png")
    except Exception:
        pass

    variables_obs = [key for key in downloader.AgroObsName().keys() if "PRCP" in key]

    log_progress("Downloading daily observations")
    if not args.reuse_obs:
        downloader.WAS_Download_AgroIndicators_daily(
            str(obs_dir),
            variables_obs,
            args.obs_years[0],
            args.obs_years[1],
            args.obs_extent,
            force_download=args.force,
        )
        downloader.WAS_Download_AgroIndicators_daily(
            str(obs_dir),
            variables_obs,
            args.forecast_year,
            args.forecast_year,
            args.obs_extent,
            force_download=args.force,
        )

    rainfall = prepare_predictand(str(obs_dir), variables_obs, args.obs_years[0], args.obs_years[1], daily=True, ds=False)
    rainfall_for_forecast_year = prepare_predictand(str(obs_dir), variables_obs, args.forecast_year, args.forecast_year, daily=True, ds=False)

    log_progress("Computing onset from daily observations")
    criteria = default_onset_criteria_payload()
    criteria[0]["start_search"] = args.onset_start_search
    criteria[0]["end_search"] = args.onset_end_search

    was_onset = WAS_compute_onset(criteria)
    onset = was_onset.compute(daily_data=rainfall, nb_cores=args.ncores)

    try:
        plot_date(onset.mean(dim="T"))
        save_and_close_plot(scores_dir / "Obs_Onset_Mean_Date.png")
    except Exception:
        pass

    if args.cpt_csv and Path(args.cpt_csv).exists():
        log_progress("Merging gridded onset with CPT/station onset")
        df = pd.read_csv(args.cpt_csv, na_values=-999.0, encoding="latin1")
        onset_df = df[
            (df["STATION"] == "LAT")
            | (df["STATION"] == "LON")
            | (pd.to_numeric(df["STATION"], errors="coerce").between(args.obs_years[0], args.obs_years[1]))
        ]
        verify_station_network(onset_df, args.obs_extent)
        merger = WAS_Merging(onset_df, onset, date_month_day=args.merge_date)
        onset_path = workdir / "onset_predictand.nc"
        if onset_path.exists() and args.reuse_obs:
            onset = xr.load_dataarray(onset_path)
        else:
            onset, _ = merger.simple_bias_adjustment(do_cross_validation=False)
            onset.to_netcdf(onset_path)
        try:
            merger.plot_merging_comparaison(onset_df, onset, onset)
            save_and_close_plot(scores_dir / "Onset_Merging_Comparison.png")
        except Exception:
            pass
    else:
        onset.to_netcdf(workdir / "onset_predictand.nc")

    onset.name = args.predictand_name
    onset.to_netcdf(workdir / "onset_predictand.nc")
    rainfall_for_forecast_year.to_netcdf(workdir / "obs_daily_forecast_year.nc")

    if args.dist_method == "bestfit":
        log_progress("Fitting best distribution for onset predictand")
        transf = WAS_TransformData(
            onset.sel(T=slice(str(args.clim_years[0]), str(args.clim_years[1]))),
            distribution_map={"norm": 1, "lognorm": 2, "gamma": 4},
            n_clusters=args.n_clusters,
        )
        best_code_da, best_shape_da, best_loc_da, best_scale_da, _ = transf.fit_best_distribution(mode="grid")
        xr.Dataset(
            {
                "code": best_code_da,
                "shape": best_shape_da,
                "loca": best_loc_da,
                "scale": best_scale_da,
            }
        ).to_netcdf(workdir / "best_distribution_params.nc")
        try:
            transf.plot_best_fit_map(
                best_code_da,
                {
                    "norm": 1,
                    "lognorm": 2,
                    "expon": 3,
                    "gamma": 4,
                    "weibull_min": 5,
                    "t_dist": 6,
                    "poisson": 7,
                    "nbinom": 8,
                },
                show_plot=False,
            )
            save_and_close_plot(scores_dir / "Map_Best_Fit_Onset_Distribution.png")
        except Exception:
            pass

    mark_done(
        check_dir,
        "obs",
        {
            "predictand": args.predictand_name,
            "obs_years": args.obs_years,
            "extent": args.obs_extent,
            "onset_start_search": args.onset_start_search,
            "onset_end_search": args.onset_end_search,
        },
    )
    print("[obs] done")


# =========================
# Stage 2 — Daily Models → Onset Hindcasts / Forecasts
# =========================
def stage_daily_models(args, workdir: Path, downloader):
    check_dir = workdir / "checkpoints"
    if done(check_dir, "daily_models") and not args.redo:
        print("[daily-models] checkpoint exists → skip")
        return

    onset = xr.load_dataarray(workdir / "onset_predictand.nc")
    rainfall = prepare_predictand(str(workdir / "Observation"), [k for k in downloader.AgroObsName().keys() if "PRCP" in k], args.obs_years[0], args.obs_years[1], daily=True, ds=False)
    rainfall_for_forecast_year = xr.load_dataarray(workdir / "obs_daily_forecast_year.nc")

    dir_model = workdir / "daily_model_data"
    dir_model.mkdir(parents=True, exist_ok=True)

    center_variable = args.center_variable or DEFAULT_ONSET_CENTERS
    center_variable = list(center_variable)

    log_progress("Downloading daily hindcast model rainfall")
    hind_paths = downloader.WAS_Download_Models_Daily(
        str(dir_model),
        center_variable,
        args.init_month,
        args.init_day,
        args.leadtime_hour,
        args.hindcast_years[0],
        args.hindcast_years[1],
        args.obs_extent,
        None,
        args.ensemble_mean,
        args.force,
    )

    log_progress("Downloading daily forecast model rainfall")
    fcst_paths = downloader.WAS_Download_Models_Daily(
        str(dir_model),
        center_variable,
        args.init_month,
        args.init_day,
        args.leadtime_hour,
        args.hindcast_years[0],
        args.hindcast_years[1],
        args.obs_extent,
        args.forecast_year,
        args.ensemble_mean,
        args.force,
    )

    log_progress("Pre-processing biophysical daily model rainfall")
    hindcast_files, forecast_files = pre_process_biophysical_model(
        workdir,
        hind_paths,
        fcst_paths,
        rainfall,
        rainfall_for_forecast_year,
        args.init_month,
        args.hindcast_years[0],
        args.hindcast_years[1],
        args.forecast_year,
        param="PRCP",
    )

    if args.daily_bias_correction:
        log_progress("Bias-correcting daily model rainfall before onset conversion")
        hindcast_files, forecast_files = proceed_seasonal_daily_bias_correction(
            str(dir_model),
            rainfall.sel(T=slice(str(args.hindcast_years[0]), str(args.hindcast_years[1]))),
            hindcast_files,
            forecast_files,
            varname="PRCP",
            method=args.daily_bias_method,
            qstep=args.daily_bias_qstep,
            wet_day=args.daily_bias_wet_day,
        )

    log_progress("Transforming corrected daily rainfall into onset hindcasts/forecasts")
    hindcast_files, forecast_files = process_model_for_other_params(
        WAS_compute_onset(default_onset_criteria_payload()),
        workdir,
        hindcast_files,
        forecast_files,
        rainfall,
        rainfall_for_forecast_year,
        args.init_month,
        args.hindcast_years[0],
        args.hindcast_years[1],
        args.forecast_year,
        nb_cores=args.ncores,
        agrometparam="Onset",
    )

    save_json(
        workdir / "intermediate" / "daily_models_manifest.json",
        {
            "hindcast_keys": sorted(list(hindcast_files.keys())),
            "forecast_keys": sorted(list(forecast_files.keys())),
        },
    )
    joblib.dump(hindcast_files, workdir / "intermediate" / "daily_hindcast_files.joblib")
    joblib.dump(forecast_files, workdir / "intermediate" / "daily_forecast_files.joblib")
    mark_done(check_dir, "daily_models", {"n_models": len(hindcast_files)})
    print("[daily-models] done")


# =========================
# Stage 3 — SV-ML-CMME for Onset
# =========================
def stage_sv_ml_cmme(args, workdir: Path, downloader, client):
    check_dir = workdir / "checkpoints"
    if done(check_dir, "sv_ml_cmme") and not args.redo:
        print("[sv-ml-cmme] checkpoint exists → skip")
        return

    onset = xr.load_dataarray(workdir / "onset_predictand.nc")
    scores_dir = workdir / "scores"
    scores_dir.mkdir(parents=True, exist_ok=True)
    out_dir = workdir / "forecasts"
    out_dir.mkdir(parents=True, exist_ok=True)

    dir_model = workdir / "daily_model_data"
    manifest = json.loads((workdir / "intermediate" / "daily_models_manifest.json").read_text())
    # Reloading from disk is delegated to existing preprocessing outputs.
    # We assume process_model_for_other_params returned dict[path] objects and was
    # already serialized by your own package functions where needed.
    # If your local workflow instead stores them in memory only, serialize them
    # before this stage.

    # Best effort: reconstruct from preprocessed daily folder using helper if available.
    try:
        hindcast_files = joblib.load(workdir / "intermediate" / "daily_hindcast_files.joblib")
        forecast_files = joblib.load(workdir / "intermediate" / "daily_forecast_files.joblib")
    except Exception:
        raise RuntimeError(
            "This template expects the stage_daily_models outputs to be serialized. "
            "Add joblib.dump(hindcast_files, ...) and joblib.dump(forecast_files, ...) "
            "inside stage_daily_models if your helpers do not already persist them."
        )

    was_verify = WAS_Verification(dist_method=args.dist_method, mae_rmse_crps_thrsd=args.mae_rmse_crps_threshold)

    hindcast_files = {k: hindcast_files[k] for k in hindcast_files.keys() & forecast_files.keys()}
    forecast_files = {k: forecast_files[k] for k in hindcast_files.keys() & forecast_files.keys()}
    common_keys = {k.lower() for k in hindcast_files} & {k.lower() for k in forecast_files}
    center_variable = [item for item in (args.center_variable or DEFAULT_ONSET_CENTERS) if any(item.lower().startswith(k) for k in list(common_keys))]

    log_progress("Validating onset hindcasts from daily model rainfall")
    scores = {}
    for metric in ["Pearson", "MAE"]:
        s_dict = was_verify.gcm_validation_compute(
            hindcast_files,
            onset.sel(T=slice(str(args.hindcast_years[0]), str(args.hindcast_years[1]))),
            metric,
            args.init_month,
            args.clim_years[0],
            args.clim_years[1],
            str(scores_dir),
            lead_time=None,
            ensemble_mean=None,
            gridded=True,
        )
        scores[metric] = {k: v.compute() for k, v in s_dict.items()}
        try:
            was_verify.plot_models_score(scores[metric], metric, str(scores_dir))
            plt.close("all")
        except Exception:
            pass

    best_models = get_best_models(
        center_variable,
        scores,
        metric="MAE",
        threshold=args.onset_gcm_mae_threshold,
        top_n=args.top_n_gcm,
        agroparam=True,
        gcm=False,
    )
    save_json(workdir / "scores" / "onset_sv_ml_cmme_best_models.json", {"best_models": best_models})

    all_model_hdcst, all_model_fcst, obs, _ = process_datasets_for_mme(
        onset.sel(T=slice(str(args.hindcast_years[0]), str(args.hindcast_years[1]))),
        hdcsted=hindcast_files,
        fcsted=forecast_files,
        scores=scores,
        score_metric="MAE",
        gcm=False,
        agroparam=True,
        ELM_ELR=False,
        best_models=best_models,
        dir_to_save_model=str(dir_model),
        year_start=args.hindcast_years[0],
        year_end=args.hindcast_years[1],
        model=True,
        month_of_initialization=args.init_month,
        year_forecast=args.forecast_year,
    )

    cv = WAS_Cross_Validator(n_splits=len(obs.get_index("T")), nb_omit=2)
    base_cv_kwargs = get_cv_kwargs(args, workdir)

    for m_name in args.mme_models:
        scores_consolidated = {}
        log_progress(f"Training onset SV-ML-CMME: {m_name.upper()}")
        model = _mme_factory(m_name, args)

        if client is not None:
            with joblib.parallel_backend("dask"):
                best_params, cluster = model.compute_hyperparameters(all_model_hdcst, obs, args.clim_years[0], args.clim_years[1])
        else:
            with joblib.parallel_backend("threading", n_jobs=args.ncores):
                best_params, cluster = model.compute_hyperparameters(all_model_hdcst, obs, args.clim_years[0], args.clim_years[1])

        try:
            cluster.plot()
            save_and_close_plot(scores_dir / f"Onset_{m_name.upper()}_Clusters.png")
        except Exception:
            pass

        cv_kwargs = {"best_params": best_params, "cluster_da": cluster}
        cv_kwargs.update(base_cv_kwargs)

        hind_det, hind_prob = cv.cross_validate(model, obs, all_model_hdcst, args.clim_years[0], args.clim_years[1], **cv_kwargs)
        fcst_det, fcst_prob = model.forecast(obs, args.clim_years[0], args.clim_years[1], all_model_hdcst, hind_det, all_model_fcst, **cv_kwargs)

        model_id = f"SV-ML-CMME_{m_name.upper()}"
        evaluate_and_plot_forecasts(
            was_verify,
            obs,
            hind_det,
            hind_prob,
            fcst_prob,
            model_id,
            model_id,
            args.clim_years[0],
            args.clim_years[1],
            scores_consolidated,
            str(scores_dir),
            str(out_dir),
            args.forecast_year,
            args.init_month,
            ONSET_LABELS_EN,
            reverse_cmap=True,
            country_iso3=args.country_code,
            logopath=args.logo,
        )

        write_intermediate_pair(workdir, f"onset_sv_ml_cmme_{m_name}", hind_det, hind_prob, fcst_det, fcst_prob)
        save_scores(workdir, scores_consolidated, f"scores_consolidated_onset_sv_ml_cmme_{m_name}.pkl")

        gc.collect()
        if client:
            client.restart()

    mark_done(check_dir, "sv_ml_cmme", {"models_run": args.mme_models, "top_n": args.top_n_gcm})
    print("[sv-ml-cmme] done")


# =========================
# Stage 4 — Generic CCA on Monthly Model Predictors
# =========================
def _execute_cca_pipeline(args, workdir, downloader, predictor_var, extent, defined_zone, prefix, top_n=4):
    onset = xr.load_dataarray(workdir / "onset_predictand.nc")
    scores_dir = workdir / "scores"
    out_dir = workdir / "forecasts"
    dir_model = workdir / "monthly_model_data"
    dir_model.mkdir(parents=True, exist_ok=True)

    center_variable = filter_center_variable(downloader.ModelsName().keys(), predictor_var)
    for bad in args.drop_gcm:
        try:
            center_variable.remove(bad)
        except ValueError:
            pass

    hind = downloader.WAS_Download_Models(
        str(dir_model),
        center_variable,
        args.init_month,
        args.monthly_lead_time,
        args.hindcast_years[0],
        args.hindcast_years[1],
        extent,
        None,
        args.ensemble_mean,
        args.force,
    )
    fcst = downloader.WAS_Download_Models(
        str(dir_model),
        center_variable,
        args.init_month,
        args.monthly_lead_time,
        args.hindcast_years[0],
        args.hindcast_years[1],
        extent,
        args.forecast_year,
        args.ensemble_mean,
        args.force,
    )

    hind = {k: hind[k] for k in hind.keys() & fcst.keys()}
    fcst = {k: fcst[k] for k in hind.keys() & fcst.keys()}
    common_keys = {k.lower() for k in hind} & {k.lower() for k in fcst}
    center_variable = [it for it in center_variable if any(it.lower().startswith(k) for k in list(common_keys))]

    try:
        plot_map([extent[1], extent[3], extent[2], extent[0]], sst_indices=defined_zone, title=f"CCA predictor area: {predictor_var}", fig_size=(6, 4))
        save_and_close_plot(scores_dir / f"Map_CCA_{prefix}.png")
    except Exception:
        pass

    was_cca = WAS_CCA(n_modes=args.cca_modes, n_pca_modes=args.cca_pca_modes, dist_method=args.dist_method)
    was_cv = WAS_Cross_Validator(n_splits=len(onset.sel(T=slice(str(args.hindcast_years[0]), str(args.hindcast_years[1]))).get_index("T")), nb_omit=2)
    cv_k = get_cv_kwargs(args, workdir)
    was_verify = WAS_Verification(dist_method=args.dist_method, mae_rmse_crps_thrsd=args.mae_rmse_crps_threshold)

    predictors = {}
    for key in center_variable:
        predictors[key] = retrieve_single_zone_for_PCR(
            str(dir_model),
            defined_zone,
            key,
            args.hindcast_years[0],
            args.hindcast_years[1],
            clim_year_start=args.clim_years[0],
            clim_year_end=args.clim_years[1],
            model=True,
            month_of_initialization=args.init_month,
            lead_time=args.monthly_lead_time,
            standardize=True,
        )

    hind_det_all, hind_prob_all, fcst_det_all, fcst_prob_all = {}, {}, {}, {}
    for key, predictor in predictors.items():
        p_train = predictor.isel(T=slice(None, -1))
        p_train["T"] = onset.sel(T=slice(str(args.hindcast_years[0]), str(args.hindcast_years[1])))["T"]
        p_fcst = predictor.isel(T=[-1])

        try:
            was_cca.plot_cca_results(X=p_train, Y=onset.sel(T=slice(str(args.hindcast_years[0]), str(args.hindcast_years[1]))), clim_year_start=args.clim_years[0], clim_year_end=args.clim_years[1])
            save_and_close_plot(scores_dir / f"CCA_Modes_{prefix}_{key.replace('.', '_')}.png")
        except Exception:
            pass

        hind_det_all[key], hind_prob_all[key] = was_cv.cross_validate(
            was_cca,
            onset.sel(T=slice(str(args.hindcast_years[0]), str(args.hindcast_years[1]))),
            p_train,
            args.clim_years[0],
            args.clim_years[1],
            **cv_k,
        )
        fcst_det_all[key], fcst_prob_all[key] = was_cca.forecast(
            onset.sel(T=slice(str(args.hindcast_years[0]), str(args.hindcast_years[1]))),
            args.clim_years[0],
            args.clim_years[1],
            p_train,
            hind_det_all[key],
            p_fcst,
            **cv_k,
        )

    cca_scores = {}
    for metric in ["Pearson", "MAE"]:
        tmp = {}
        for k_id, hd in hind_det_all.items():
            tmp[k_id] = was_verify.compute_deterministic_score(was_verify.get_scores_metadata()[metric][5], onset.sel(T=slice(str(args.hindcast_years[0]), str(args.hindcast_years[1]))), hd).compute()
        cca_scores[metric] = tmp
    for metric in ["GROC", "RPSS"]:
        tmp = {}
        for k_id, hp in hind_prob_all.items():
            tmp[k_id] = was_verify.compute_probabilistic_score(was_verify.get_scores_metadata()[metric][5], onset.sel(T=slice(str(args.hindcast_years[0]), str(args.hindcast_years[1]))), hp, args.clim_years[0], args.clim_years[1]).compute()
        cca_scores[metric] = tmp

    best_models = get_best_models(list(hind_det_all.keys()), cca_scores, metric="GROC", threshold=args.cca_threshold, top_n=top_n, gcm=False)
    save_json(workdir / f"scores/{prefix}_best_models.json", {"best_models": best_models})

    best_hind = {f"hdcst_det_{k}": hind_det_all[k] for k in best_models}
    best_hind.update({f"hdcst_prob_{k}": hind_prob_all[k] for k in best_models})
    best_fcst = {f"fcst_det_{k}": fcst_det_all[k] for k in best_models}
    best_fcst.update({f"fcst_prob_{k}": fcst_prob_all[k] for k in best_models})
    xr.Dataset(best_hind).to_netcdf(workdir / f"intermediate/{prefix}_hindcasts.nc")
    xr.Dataset(best_fcst).to_netcdf(workdir / f"intermediate/{prefix}_forecasts.nc")

    scores_consolidated = {}
    for k in best_models:
        evaluate_and_plot_forecasts(
            was_verify,
            onset.sel(T=slice(str(args.hindcast_years[0]), str(args.hindcast_years[1]))),
            hind_det_all[k],
            hind_prob_all[k],
            fcst_prob_all[k],
            f"CCA_{k}",
            k,
            args.clim_years[0],
            args.clim_years[1],
            scores_consolidated,
            str(scores_dir),
            str(out_dir),
            args.forecast_year,
            args.init_month,
            ONSET_LABELS_EN,
            reverse_cmap=True,
            country_iso3=args.country_code,
            logopath=args.logo,
        )

    save_scores(workdir, scores_consolidated, f"scores_consolidated_{prefix}.pkl")
    return best_models


def stage_cca_gcm(args, workdir: Path, downloader):
    check_dir = workdir / "checkpoints"
    if done(check_dir, "cca_gcm") and not args.redo:
        print("[cca-gcm] checkpoint exists → skip")
        return

    _execute_cca_pipeline(
        args,
        workdir,
        downloader,
        predictor_var=args.cca_predictor_var,
        extent=args.cca_extent,
        defined_zone={"A": ("A", args.cca_extent[1], args.cca_extent[3], args.cca_extent[2], args.cca_extent[0])},
        prefix=f"onset_cca_{args.cca_predictor_var.lower()}",
        top_n=args.cca_top_n,
    )

    mark_done(check_dir, "cca_gcm", {"predictor_var": args.cca_predictor_var})
    print("[cca-gcm] done")


# =========================
# Stage 5 — Obs-Lag (MLR + Field CCA)
# =========================
def stage_obs_lag(args, workdir: Path, downloader):
    check_dir = workdir / "checkpoints"
    if done(check_dir, "obs_lag") and not args.redo:
        print("[obs-lag] checkpoint exists → skip")
        return

    onset = xr.load_dataarray(workdir / "onset_predictand.nc")
    scores_dir = workdir / "scores"
    out_dir = workdir / "forecasts"
    rean_dir = workdir / "reanalysis_data"
    inter_dir = workdir / "intermediate"
    rean_dir.mkdir(parents=True, exist_ok=True)
    inter_dir.mkdir(parents=True, exist_ok=True)

    cv_k = get_cv_kwargs(args, workdir)
    was_cv = WAS_Cross_Validator(n_splits=len(onset.get_index("T")), nb_omit=2)
    was_verify = WAS_Verification(dist_method=args.dist_method, mae_rmse_crps_thrsd=args.mae_rmse_crps_threshold)

    run_mlr = args.obs_lag_policy in ("both", "mlr")
    run_field_cca = args.obs_lag_policy in ("both", "field_cca")

    if run_mlr:
        log_progress("Obs-lag branch: MLR with SST indices")
        downloader.WAS_Download_Reanalysis(
            str(rean_dir),
            ["NOAA.SST"],
            args.obs_years[0],
            max(args.obs_years[1], args.forecast_year),
            args.reanalysis_sst_extent,
            args.obs_lag_season,
            args.force,
        )

        my_own_indices_zone = args.custom_sst_zones if args.custom_sst_zones else {}
        predictors = compute_sst_indices(
            str(rean_dir),
            args.sst_indices,
            "NOAA.SST",
            args.obs_years[0],
            max(args.obs_years[1], args.forecast_year),
            args.obs_lag_season,
            args.clim_years[0],
            args.clim_years[1],
            my_own_indices_zone,
        )

        pred_df = predictors.to_dataframe()
        vif_data = pd.DataFrame({
            "feature": pred_df.columns,
            "VIF": [VIF(pred_df, i) for i in range(pred_df.shape[1])],
        })
        vif_data.to_csv(scores_dir / "obs_lag_vif.csv", index=False)

        low_vif_predictors = vif_data[vif_data["VIF"] < args.vif_threshold]["feature"].tolist()
        if not low_vif_predictors:
            raise RuntimeError("No SST index predictor remained after VIF filtering in obs-lag stage.")

        filtered_predictors = predictors[low_vif_predictors].to_array().rename({"variable": "features"}).transpose("T", "features")
        filtered_predictors_train = filtered_predictors.isel(T=slice(None, -1))
        filtered_predictors_train["T"] = onset["T"]

        model = WAS_LinearRegression_Model(nb_cores=max(1, args.ncores // 2), dist_method=args.dist_method)
        hind_det, hind_prob = was_cv.cross_validate(
            model,
            onset,
            filtered_predictors_train,
            args.clim_years[0],
            args.clim_years[1],
            **cv_k,
        )
        f_predictors = filtered_predictors.isel(T=[-1])
        f_predictors["T"] = xr.DataArray([np.datetime64(f"{args.forecast_year}-{int(args.init_month):02d}-01")], dims=["T"])
        fcst_det, fcst_prob = model.forecast(
            onset,
            args.clim_years[0],
            args.clim_years[1],
            filtered_predictors_train,
            hind_det,
            f_predictors,
            **cv_k,
        )

        scores_consolidated = {}
        evaluate_and_plot_forecasts(
            was_verify,
            onset,
            hind_det,
            hind_prob,
            fcst_prob,
            "OBS-LAG_MLR_VIF",
            "OBS-LAG_MLR_VIF",
            args.clim_years[0],
            args.clim_years[1],
            scores_consolidated,
            str(scores_dir),
            str(out_dir),
            args.forecast_year,
            args.init_month,
            ONSET_LABELS_EN,
            reverse_cmap=False,
            country_iso3=args.country_code,
            logopath=args.logo,
        )

        write_intermediate_pair(workdir, "onset_obs_lag_mlr_vif", hind_det, hind_prob, fcst_det, fcst_prob)
        save_scores(workdir, scores_consolidated, "scores_consolidated_onset_obs_lag_mlr.pkl")

    if run_field_cca:
        log_progress(f"Obs-lag branch: field CCA using {args.field_cca_source.upper()}")

        if args.field_cca_source == "vws":
            path_u200 = downloader.WAS_Download_Reanalysis(
                str(rean_dir),
                ["ERA5.UGRD_200"],
                args.obs_years[0],
                max(args.obs_years[1], args.forecast_year),
                args.reanalysis_field_extent,
                args.obs_lag_season,
                args.force,
            )[0]
            path_u850 = downloader.WAS_Download_Reanalysis(
                str(rean_dir),
                ["ERA5.UGRD_850"],
                args.obs_years[0],
                max(args.obs_years[1], args.forecast_year),
                args.reanalysis_field_extent,
                args.obs_lag_season,
                args.force,
            )[0]
            predictor = standardize_timeseries(
                xr.open_dataarray(path_u200) - xr.open_dataarray(path_u850),
                clim_year_start=args.clim_years[0],
                clim_year_end=args.clim_years[1],
            )
            model_key = "CCA_VWS"
        elif args.field_cca_source == "smc":
            path_sm = downloader.WAS_Download_TAMSAT_Seasonal(
                str(rean_dir),
                product="soilmoisture",
                variables="smcl",
                year_start=args.obs_years[0],
                year_end=max(args.obs_years[1], args.forecast_year),
                area=args.reanalysis_field_extent,
                season_months=args.obs_lag_season,
                agg="mean",
            )
            predictor = standardize_timeseries(
                xr.open_dataarray(path_sm).sum(dim="soil"),
                clim_year_start=args.clim_years[0],
                clim_year_end=args.clim_years[1],
            )
            model_key = "CCA_SMC"
        else:
            raise ValueError(f"Unsupported field_cca_source: {args.field_cca_source}")

        predictor_train = predictor.isel(T=slice(None, -1))
        predictor_train["T"] = onset["T"]
        predictor_fcst = predictor.isel(T=[-1])
        predictor_fcst["T"] = xr.DataArray([np.datetime64(f"{args.forecast_year}-{int(args.init_month):02d}-01")], dims=["T"])

        was_cca = WAS_CCA(
            n_modes=args.obs_field_cca_modes,
            n_pca_modes=args.obs_field_cca_pca_modes,
            dist_method=args.dist_method,
        )
        hind_det, hind_prob = was_cv.cross_validate(
            was_cca,
            onset,
            predictor_train,
            args.clim_years[0],
            args.clim_years[1],
            **cv_k,
        )
        fcst_det, fcst_prob = was_cca.forecast(
            onset,
            args.clim_years[0],
            args.clim_years[1],
            predictor_train,
            hind_det,
            predictor_fcst,
            **cv_k,
        )

        scores_consolidated = {}
        evaluate_and_plot_forecasts(
            was_verify,
            onset,
            hind_det,
            hind_prob,
            fcst_prob,
            model_key,
            model_key,
            args.clim_years[0],
            args.clim_years[1],
            scores_consolidated,
            str(scores_dir),
            str(out_dir),
            args.forecast_year,
            args.init_month,
            ONSET_LABELS_EN,
            reverse_cmap=False,
            country_iso3=args.country_code,
            logopath=args.logo,
        )

        write_intermediate_pair(workdir, f"onset_{model_key.lower()}", hind_det, hind_prob, fcst_det, fcst_prob)
        save_scores(workdir, scores_consolidated, f"scores_consolidated_onset_{model_key.lower()}.pkl")

    mark_done(
        check_dir,
        "obs_lag",
        {
            "policy": args.obs_lag_policy,
            "sst_indices": args.sst_indices,
            "vif_threshold": args.vif_threshold,
            "field_cca_source": args.field_cca_source,
        },
    )
    print("[obs-lag] done")


# =========================
# Stage 7 — Analog
# =========================
def stage_analog(args, workdir: Path):
    check_dir = workdir / "checkpoints"
    if done(check_dir, "analog") and not args.redo:
        print("[analog] checkpoint exists → skip")
        return

    onset = xr.load_dataarray(workdir / "onset_predictand.nc")
    scores_dir = workdir / "scores"
    out_dir = workdir / "forecasts"
    cv_k = get_cv_kwargs(args, workdir)

    model = WAS_Analog(
        dir_to_save=str(workdir / "analog"),
        year_start=args.obs_years[0] - 1,
        year_forecast=args.forecast_year,
        month_of_initialization=int(args.init_month),
        predictor_vars=[
            {
                "reanalysis_name": "NOAA",
                "model_name": "ECMWF_51",
                "variable": "SST",
                "area": [40, -180, -35, 100],
            }
        ],
        method_analog=args.analog_method,
        standardize=True,
        rolling=3,
        lead_time=args.analog_lead_time,
        clim_year_start=args.clim_years[0],
        clim_year_end=args.clim_years[1],
        dist_method=args.dist_method,
    )

    was_cv = WAS_Cross_Validator(n_splits=len(onset.get_index("T")), nb_omit=2)
    hind_det, hind_prob = was_cv.cross_validate(model, onset, clim_year_start=args.clim_years[0], clim_year_end=args.clim_years[1], **cv_k)
    _, fcst_det, fcst_prob = model.forecast(onset, args.clim_years[0], args.clim_years[1], hind_det, **cv_k)

    scores_consolidated = {}
    was_verify = WAS_Verification(dist_method=args.dist_method, mae_rmse_crps_thrsd=args.mae_rmse_crps_threshold)
    evaluate_and_plot_forecasts(
        was_verify,
        onset,
        hind_det,
        hind_prob,
        fcst_prob,
        "ANALOG",
        "ANALOG",
        args.clim_years[0],
        args.clim_years[1],
        scores_consolidated,
        str(scores_dir),
        str(out_dir),
        args.forecast_year,
        args.init_month,
        ONSET_LABELS_EN,
        reverse_cmap=True,
        country_iso3=args.country_code,
        logopath=args.logo,
    )

    write_intermediate_pair(workdir, "onset_analog", hind_det, hind_prob, fcst_det, fcst_prob)
    save_scores(workdir, scores_consolidated, "scores_consolidated_onset_analog.pkl")

    mark_done(check_dir, "analog", {"method": args.analog_method})
    print("[analog] done")


# =========================
# Stage 8 — Consolidation
# =========================
def stage_consolidate(args, workdir: Path):
    check_dir = workdir / "checkpoints"
    if done(check_dir, "consolidate") and not args.redo:
        print("[consolidate] checkpoint exists → skip")
        return

    onset = xr.load_dataarray(workdir / "onset_predictand.nc")
    scores_dir = workdir / "scores"
    out_dir = workdir / "forecasts"
    inter_dir = workdir / "intermediate"
    cv_k = get_cv_kwargs(args, workdir)

    ds_list_h, ds_list_f = [], []
    for hind_path in inter_dir.glob("*_hindcasts.nc"):
        fcst_path = inter_dir / hind_path.name.replace("_hindcasts.nc", "_forecasts.nc")
        if fcst_path.exists():
            ds_list_h.append(xr.load_dataset(hind_path))
            ds_list_f.append(xr.load_dataset(fcst_path))

    if not ds_list_h:
        raise RuntimeError("Nothing to consolidate. No *_hindcasts.nc found in intermediate/.")

    all_model_hdcst_dict, all_model_fcst_dict = {}, {}
    obs = onset.sel(T=slice(str(args.hindcast_years[0]), str(args.hindcast_years[1])))

    for ds in ds_list_h:
        for k in ds.data_vars:
            if k.startswith("hdcst_det_"):
                all_model_hdcst_dict[k.replace("hdcst_det_", "")] = ds[k].sel(T=slice(str(args.hindcast_years[0]), str(args.hindcast_years[1])))
    for ds in ds_list_f:
        for k in ds.data_vars:
            if k.startswith("fcst_det_"):
                all_model_fcst_dict[k.replace("fcst_det_", "")] = ds[k]

    if not all_model_hdcst_dict:
        raise RuntimeError("No deterministic hindcast members were found for consolidation.")

    all_scores = {}
    for pkl_path in inter_dir.glob("scores_consolidated_*.pkl"):
        all_scores = update_nested_dict(all_scores, load_scores(pkl_path))

    best_models = list(all_model_hdcst_dict.keys())
    log_progress(f"Consolidating onset models: {best_models}")

    all_model_hdcst, all_model_fcst, obs, best_score = process_datasets_for_mme(
        obs,
        hdcsted=all_model_hdcst_dict,
        fcsted=all_model_fcst_dict,
        gcm=False,
        ELM_ELR=False,
        Prob=False,
        best_models=best_models,
        scores=all_scores,
        model=False,
        score_metric="GROC",
    )

    all_model_hdcst = all_model_hdcst.transpose("T", "M", "Y", "X")
    all_model_fcst = all_model_fcst.transpose("T", "M", "Y", "X")

    was_verify = WAS_Verification(dist_method=args.dist_method, mae_rmse_crps_thrsd=args.mae_rmse_crps_threshold)
    cv_log = WAS_Cross_Validator(n_splits=len(obs.get_index("T")), nb_omit=2)
    failures = {}

    def write_and_plot(name, hind_det, hind_prob, fcst_det, fcst_prob, reverse_cmap=True):
        scores_consolidated = {}
        evaluate_and_plot_forecasts(
            was_verify,
            obs,
            hind_det,
            hind_prob,
            fcst_prob,
            f"CONS_{name}",
            f"CONS_{name}",
            args.clim_years[0],
            args.clim_years[1],
            scores_consolidated,
            str(scores_dir),
            str(out_dir),
            args.forecast_year,
            args.init_month,
            ONSET_LABELS_EN,
            reverse_cmap=reverse_cmap,
            country_iso3=args.country_code,
            logopath=args.logo,
        )
        write_intermediate_pair(workdir, f"consolidated_{name.lower().replace(' ', '_')}", hind_det, hind_prob, fcst_det, fcst_prob)
        save_scores(workdir, scores_consolidated, f"scores_consolidated_cons_{name.lower().replace(' ', '_')}.pkl")

    # 1. Equal-weighted
    try:
        log_progress("Consensus: EqualWeighted")
        was_mme_eq = WAS_mme_Weighted(equal_weighted=True, dist_method=args.dist_method, metric="GROC", threshold=args.cons_threshold)
        hind_det_eq, fcst_det_eq = was_mme_eq.compute(obs, all_model_hdcst, all_model_fcst.isel(T=[-1]), best_score, complete=True)
        hind_prob_eq = was_mme_eq.compute_prob(obs, args.clim_years[0], args.clim_years[1], hind_det_eq, **cv_k)
        _, fcst_prob_eq = was_mme_eq.forecast(obs, args.clim_years[0], args.clim_years[1], hind_det_eq, fcst_det_eq, **cv_k)
        write_and_plot("EqualWeighted", hind_det_eq, hind_prob_eq, fcst_det_eq, fcst_prob_eq)
    except Exception as e:
        failures["EqualWeighted"] = str(e)

    # 2. Skill-weighted
    try:
        log_progress("Consensus: SkillWeighted")
        was_mme_sk = WAS_mme_Weighted(equal_weighted=False, dist_method=args.dist_method, metric="GROC", threshold=args.cons_threshold)
        hind_det_sk, fcst_det_sk = was_mme_sk.compute(obs, all_model_hdcst, all_model_fcst.isel(T=[-1]), best_score, complete=True)
        hind_prob_sk = was_mme_sk.compute_prob(obs, args.clim_years[0], args.clim_years[1], hind_det_sk, **cv_k)
        _, fcst_prob_sk = was_mme_sk.forecast(obs, args.clim_years[0], args.clim_years[1], hind_det_sk, fcst_det_sk, **cv_k)
        write_and_plot("Weighted", hind_det_sk, hind_prob_sk, fcst_det_sk, fcst_prob_sk)
    except Exception as e:
        failures["Weighted"] = str(e)

    # 3. Probability-weighted
    try:
        log_progress("Consensus: ProbWeighted")
        was_mme_prob = WAS_ProbWeighted()
        hind_prob_pw, fcst_prob_pw = was_mme_prob.compute(obs, all_model_hdcst, all_model_fcst.isel(T=[-1]), best_score, threshold=args.cons_threshold, complete=True)
        write_and_plot("ProbWeighted", None, hind_prob_pw, None, fcst_prob_pw)
    except Exception as e:
        failures["ProbWeighted"] = str(e)

    # 4. Min2009 PMME
    try:
        log_progress("Consensus: Min2009 ProbWeighted")
        pmme = WAS_Min2009_ProbWeighted(distribution="gaussian", cv_method="leave_one_out", n_samples_for_chisq="total_ensemble")

        model_names = [str(m) for m in all_model_fcst.M.values]
        masks = {
            name: xr.DataArray(
                np.array([str(m) == name for m in all_model_fcst.M.values]),
                dims=["M"],
                coords={"M": all_model_fcst.M.values},
            )
            for name in model_names
        }
        forecasts = {k: all_model_fcst.sel(M=v) for k, v in masks.items() if int(v.sum()) > 0}
        hindcasts = {k: all_model_hdcst.sel(M=v) for k, v in masks.items() if int(v.sum()) > 0}
        ensemble_sizes = {k: int(v.sum()) for k, v in masks.items() if int(v.sum()) > 0}
        climatology = obs.sel(T=slice(str(args.clim_years[0]), str(args.clim_years[1]))).mean(dim="T", skipna=True)

        cv_probweight = WAS_Cross_Validator(n_splits=len(obs.get_index("T")), nb_omit=2)
        hind_prob_pmme, _ = cv_probweight.cross_validate(
            pmme,
            obs,
            all_model_hdcst,
            args.clim_years[0],
            args.clim_years[1],
            ensemble_sizes=ensemble_sizes,
            masks=masks,
            climatology=climatology,
        )

        pmme_probs = pmme.compute_pmme_probabilities(forecasts, hindcasts, climatology, ensemble_sizes)
        pmme_da = xr.concat(
            [pmme_probs["PB"], pmme_probs["PN"], pmme_probs["PA"]],
            dim=xr.DataArray(["EARLY", "NORMAL", "LATE"], dims="probability", name="probability"),
        )
        pmme_da.attrs.update({
            "description": "PMME tercile probabilities for onset categories",
            "probability_labels": "EARLY / NORMAL / LATE",
        })

        try:
            sig_map, _ = pmme.compute_combined_map(
                pmme_probs,
                ensemble_sizes,
                list(ensemble_sizes.keys()),
                significance_level=0.5,
            )
            signif = xr.where(sig_map.drop_vars("T").squeeze() <= 0, np.nan, 1)
            fig, ax = plt.subplots(figsize=(12, 8))
            signif.plot(ax=ax, cmap="Greys", add_colorbar=False, vmin=0, vmax=1)
            ax.set_title("Statistical Significance for Min2009 PMME")
            ax.set_xlabel("")
            ax.set_ylabel("")
            plt.tight_layout()
            fig.savefig(out_dir / "onset_min2009_significance_map.png", dpi=300, bbox_inches="tight")
            fig.savefig(out_dir / "onset_min2009_significance_map.pdf", bbox_inches="tight")
            plt.close(fig)
        except Exception:
            pass

        write_and_plot("Min2009_ProbWeighted", None, hind_prob_pmme, None, pmme_da)
    except Exception as e:
        failures["Min2009_ProbWeighted"] = str(e)

    # 5. MVA
    try:
        log_progress("Consensus: MVA")
        mva = WAS_mme_MVA(dist_method=args.dist_method)
        obs_ = obs
        mva.fit(all_model_hdcst, obs_)
        hindcast_calib_loocv = mva.fit_transform_loocv(all_model_hdcst, obs_)
        hind_prob_mva = mva.compute_prob(obs_, args.clim_years[0], args.clim_years[1], hindcast_calib_loocv, **cv_k)
        fcst_det_mva, fcst_prob_mva = mva.forecast(obs_, args.clim_years[0], args.clim_years[1], all_model_hdcst, hindcast_calib_loocv, all_model_fcst.isel(T=[-1]), **cv_k)
        write_and_plot("MVA", hindcast_calib_loocv.mean(dim="M", skipna=True), hind_prob_mva, fcst_det_mva, fcst_prob_mva)
    except Exception as e:
        failures["MVA"] = str(e)

    # 6. Logistic
    try:
        log_progress("Consensus: Logistic")
        model_log = WAS_mme_logistic(
            optimization_method="bayesian",
            C_range=(0.1, 100.0),
            solver_options=["lbfgs", "saga"],
            random_state=42,
            cv_folds=5,
            n_clusters=4,
            n_iter_search=20,
            n_trials=50,
            timeout=None,
        )
        best_params, cluster = model_log.compute_hyperparameters(all_model_hdcst, obs, args.clim_years[0], args.clim_years[1])
        hind_det_log, hind_prob_log = cv_log.cross_validate(
            model_log,
            obs,
            all_model_hdcst,
            args.clim_years[0],
            args.clim_years[1],
            best_params=best_params,
            cluster_da=cluster,
        )
        fcst_det_log, fcst_prob_log = model_log.forecast(
            obs,
            args.clim_years[0],
            args.clim_years[1],
            all_model_hdcst,
            all_model_fcst.isel(T=[-1]),
            best_params=best_params,
            cluster_da=cluster,
        )
        write_and_plot("Logistic", hind_det_log, hind_prob_log, fcst_det_log, fcst_prob_log)
    except Exception as e:
        failures["Logistic"] = str(e)

    # 7. NGR
    try:
        log_progress("Consensus: NGR")
        model_ngr = WAS_mme_NGR_Gaussian(apply_to="pos", alpha=0.10)
        _, hind_prob_ngr = cv_log.cross_validate(
            model_ngr,
            obs,
            all_model_hdcst,
            args.clim_years[0],
            args.clim_years[1],
            obs_for_terciles=obs,
            quantiles=[0.1, 0.5, 0.9],
            clim_terciles=True,
            return_synthetic_ensemble=False,
            member_dim="M",
            time_dim="T",
            lat_dim="Y",
            lon_dim="X",
        )
        fcst_prob_ngr = model_ngr.compute_model(
            all_model_hdcst,
            obs,
            all_model_fcst,
            obs_for_terciles=obs,
            quantiles=[0.1, 0.5, 0.9],
            clim_terciles=True,
            return_synthetic_ensemble=False,
            member_dim="M",
            time_dim="T",
            lat_dim="Y",
            lon_dim="X",
        )["tercile_probability"]
        write_and_plot("NGR", None, hind_prob_ngr, None, fcst_prob_ngr)
    except Exception as e:
        failures["NGR"] = str(e)

    # 8. BMA
    try:
        log_progress("Consensus: BMA")
        model_bma = WAS_mme_FullBMA(mode="fast", draws=800, tune=800, chains=2, target_accept=0.92, maxiter=300, verbose=False)
        _, hind_prob_bma = cv_log.cross_validate(
            model_bma,
            obs,
            all_model_hdcst,
            args.clim_years[0],
            args.clim_years[1],
            dist_map=getattr(load_bestfit_params(workdir)[0], "copy", lambda: load_bestfit_params(workdir)[0])(),
            obs_for_terciles=obs,
            quantiles=[0.1, 0.5, 0.9],
            clim_terciles=True,
            return_synthetic_ensemble=False,
            member_dim="M",
            time_dim="T",
            lat_dim="Y",
            lon_dim="X",
        )
        fcst_prob_bma = model_bma.compute_model(
            all_model_hdcst,
            obs,
            all_model_fcst,
            obs_for_terciles=obs,
            quantiles=[0.1, 0.5, 0.9],
            clim_terciles=True,
            return_synthetic_ensemble=False,
            member_dim="M",
            time_dim="T",
            lat_dim="Y",
            lon_dim="X",
        )["tercile_probability"]
        write_and_plot("BMA", None, hind_prob_bma, None, fcst_prob_bma)
    except Exception as e:
        failures["BMA"] = str(e)

    # 9. xcELM
    try:
        log_progress("Consensus: xcELM")
        all_model_hdcst_elm, all_model_fcst_elm, obs_elm, _ = process_datasets_for_mme(
            obs,
            hdcsted=all_model_hdcst_dict,
            fcsted=all_model_fcst_dict,
            gcm=False,
            ELM_ELR=True,
            Prob=False,
            best_models=best_models,
            scores=all_scores,
            model=False,
            score_metric="GROC",
        )
        model_elm = WAS_mme_xcELM(
            elm_kwargs={
                "regularization": 30,
                "hidden_layer_size": 10,
                "activation": "lin",
                "preprocessing": "none",
                "n_estimators": 40,
            },
            dist_method=args.dist_method,
        )
        cv_elm = WAS_Cross_Validator(n_splits=len(obs_elm.get_index("T")), nb_omit=2)
        hind_det_elm, hind_prob_elm = cv_elm.cross_validate(model_elm, obs_elm, all_model_hdcst_elm, args.clim_years[0], args.clim_years[1], **cv_k)
        fcst_det_elm, fcst_prob_elm = model_elm.forecast(obs_elm, args.clim_years[0], args.clim_years[1], all_model_hdcst_elm, hind_det_elm, all_model_fcst_elm.isel(T=[-1]), **cv_k)
        write_and_plot("xcELM", hind_det_elm, hind_prob_elm, fcst_det_elm, fcst_prob_elm)
    except Exception as e:
        failures["xcELM"] = str(e)

    # 10. xcELR
    try:
        log_progress("Consensus: xcELR")
        try:
            all_model_hdcst_elr, all_model_fcst_elr, obs_elr, _ = process_datasets_for_mme(
                obs,
                hdcsted=all_model_hdcst_dict,
                fcsted=all_model_fcst_dict,
                gcm=False,
                ELM_ELR=True,
                Prob=False,
                best_models=best_models,
                scores=all_scores,
                model=False,
                score_metric="GROC",
            )
        except Exception:
            all_model_hdcst_elr, all_model_fcst_elr, obs_elr = all_model_hdcst, all_model_fcst, obs
        model_elr = WAS_mme_xcELR(elm_kwargs=None)
        cv_elr = WAS_Cross_Validator(n_splits=len(obs_elr.get_index("T")), nb_omit=2)
        hind_det_elr, hind_prob_elr = cv_elr.cross_validate(model_elr, obs_elr, all_model_hdcst_elr, args.clim_years[0], args.clim_years[1], **cv_k)
        fcst_prob_elr = model_elr.forecast(obs_elr, args.clim_years[0], args.clim_years[1], all_model_hdcst_elr, all_model_fcst_elr.isel(T=[-1]), **cv_k)
        write_and_plot("xcELR", hind_det_elr if 'hind_det_elr' in locals() else None, hind_prob_elr, None, fcst_prob_elr)
    except Exception as e:
        failures["xcELR"] = str(e)

    save_json(workdir / "scores" / "consolidation_failures.json", failures)
    mark_done(check_dir, "consolidate", {"n_models": len(best_models), "failures": failures})
    print("[consolidate] done")


# =========================
# CLI Parser
# =========================
def parse_args():
    p = argparse.ArgumentParser(description="WASS2S Onset Forecast CLI")

    # Core workflow
    p.add_argument("--workdir", default=DEFAULT_DIR)
    p.add_argument("--forecast-year", type=int, default=dt.date.today().year)
    p.add_argument("--clim-years", nargs=2, type=int, default=list(DEFAULT_CLIM_YEARS))
    p.add_argument("--hindcast-years", nargs=2, type=int, default=list(DEFAULT_HIND_YEARS))
    p.add_argument("--obs-years", nargs=2, type=int, default=list(DEFAULT_OBS_YEARS))
    p.add_argument("--only", nargs="+", default=["all"], choices=["all", "obs", "daily-models", "sv-ml-cmme", "cca-gcm", "obs-lag", "analog", "consolidate"])
    p.add_argument("--redo", action="store_true")
    p.add_argument("--force", action="store_true")
    p.add_argument("--reuse-obs", action="store_true")

    # Predictand / onset settings
    p.add_argument("--predictand-name", default="Onset")
    p.add_argument("--obs-extent", nargs=4, type=float, default=DEFAULT_ONSET_EXTENT, metavar=("N", "W", "S", "E"))
    p.add_argument("--onset-start-search", default="02-01")
    p.add_argument("--onset-end-search", default="05-15")
    p.add_argument("--cpt-csv", default=None)
    p.add_argument("--merge-date", default="02-01")
    p.add_argument("--dist-method", default="bestfit", choices=["bestfit", "nonparam"])
    p.add_argument("--n-clusters", type=int, default=1000)

    # Daily dynamical model settings
    p.add_argument("--center-variable", nargs="+", default=DEFAULT_ONSET_CENTERS)
    p.add_argument("--init-month", default="01")
    p.add_argument("--init-day", default="01")
    p.add_argument("--ensemble-mean", default="mean")
    p.add_argument("--leadtime-hour-start", type=int, default=24)
    p.add_argument("--leadtime-hour-stop", type=int, default=5160)
    p.add_argument("--leadtime-hour-step", type=int, default=24)
    p.add_argument("--daily-bias-correction", action="store_true")
    p.add_argument("--daily-bias-method", default="QUANT")
    p.add_argument("--daily-bias-qstep", type=float, default=0.01)
    p.add_argument("--daily-bias-wet-day", action="store_true")

    # MME settings
    p.add_argument("--mme-models", nargs="+", default=["mlp", "hpelm"], choices=["hpelm", "rf", "xgb", "mlp", "stack"])
    p.add_argument("--meta-learner", default="ridge", choices=["ridge", "lasso", "elasticnet", "linear"])
    p.add_argument("--top-n-gcm", type=int, default=3)
    p.add_argument("--onset-gcm-mae-threshold", type=float, default=7.0)
    p.add_argument("--mae-rmse-crps-threshold", type=float, default=50.0)

    # Monthly CCA settings
    p.add_argument("--monthly-lead-time", nargs="+", default=["1", "2", "3"])
    p.add_argument("--cca-predictor-var", default="VGRD_850")
    p.add_argument("--cca-extent", nargs=4, type=float, default=DEFAULT_REAN_FIELD_EXTENT, metavar=("N", "W", "S", "E"))
    p.add_argument("--cca-modes", type=int, default=3)
    p.add_argument("--cca-pca-modes", type=int, default=8)
    p.add_argument("--cca-threshold", type=float, default=0.6)
    p.add_argument("--cca-top-n", type=int, default=4)
    p.add_argument("--drop-gcm", nargs="+", default=[])

    # Obs-lag (MLR + field CCA)
    p.add_argument("--obs-lag-season", nargs="+", default=["02", "03"])
    p.add_argument("--sst-indices", nargs="+", default=DEFAULT_SST_INDICES)
    p.add_argument("--vif-threshold", type=float, default=5.0)
    p.add_argument("--custom-sst-zones", type=json.loads, default=None, help="JSON dict for custom SST zones")

    p.add_argument("--obs-lag-policy", default="both", choices=["both", "mlr", "field_cca"])

    # Observation-field CCA
    p.add_argument("--field-cca-source", default="vws", choices=["vws", "smc"])
    p.add_argument("--reanalysis-sst-extent", nargs=4, type=float, default=DEFAULT_REAN_SST_EXTENT, metavar=("N", "W", "S", "E"))
    p.add_argument("--reanalysis-field-extent", nargs=4, type=float, default=DEFAULT_REAN_FIELD_EXTENT, metavar=("N", "W", "S", "E"))
    p.add_argument("--obs-field-cca-modes", type=int, default=2)
    p.add_argument("--obs-field-cca-pca-modes", type=int, default=6)

    # Analog
    p.add_argument("--analog-method", default="bias_based", choices=["bias_based", "som", "pca_based"])
    p.add_argument("--analog-lead-time", nargs="+", type=int, default=[1, 2, 3])

    # Consolidation
    p.add_argument("--cons-threshold", type=float, default=0.6)

    # Parallel / plotting
    p.add_argument("--ncores", type=int, default=int(os.environ.get("SLURM_CPUS_PER_TASK", os.cpu_count() or 1)))
    p.add_argument("--threads-per-worker", type=int, default=4)
    p.add_argument("--no-dask", action="store_true")
    p.add_argument("--country-code", default=DEFAULT_COUNTRY_ISO3)
    p.add_argument("--logo", default=DEFAULT_LOGO)

    return p.parse_args()


# =========================
# Main
# =========================
def main():
    args = parse_args()
    args.leadtime_hour = [str(i) for i in range(args.leadtime_hour_start, args.leadtime_hour_stop + 1, args.leadtime_hour_step)]

    workdir = Path(args.workdir)
    workdir.mkdir(parents=True, exist_ok=True)
    (workdir / "checkpoints").mkdir(parents=True, exist_ok=True)
    (workdir / "scores").mkdir(parents=True, exist_ok=True)
    (workdir / "forecasts").mkdir(parents=True, exist_ok=True)
    (workdir / "intermediate").mkdir(parents=True, exist_ok=True)

    downloader = WAS_Download()
    client = _setup_parallel(args.ncores, args.threads_per_worker, use_dask=not args.no_dask)

    stages = {
        "obs": lambda: stage_obs(args, workdir, downloader),
        "daily-models": lambda: stage_daily_models(args, workdir, downloader),
        "sv-ml-cmme": lambda: stage_sv_ml_cmme(args, workdir, downloader, client),
        "cca-gcm": lambda: stage_cca_gcm(args, workdir, downloader),
        "obs-lag": lambda: stage_obs_lag(args, workdir, downloader),
        "analog": lambda: stage_analog(args, workdir),
        "consolidate": lambda: stage_consolidate(args, workdir),
    }

    run_list = list(stages.keys()) if "all" in args.only else args.only

    t0 = time.time()
    for key in run_list:
        print(f"\n=== Running stage: {key} ===")
        stages[key]()
        gc.collect()
        if client:
            try:
                client.restart()
            except Exception:
                pass
        print(f"=== Done: {key} ===\n")

    save_json(
        workdir / "run_manifest.json",
        {
            "workdir": str(workdir),
            "forecast_year": args.forecast_year,
            "init_month": args.init_month,
            "init_day": args.init_day,
            "mme_models_run": args.mme_models,
            "timestamp": dt.datetime.utcnow().isoformat() + "Z",
        },
    )
    print(f"✅ Onset pipeline completed in {(time.time() - t0) / 60:.1f} min. Workdir: {workdir}")


if __name__ == "__main__":
    main()
