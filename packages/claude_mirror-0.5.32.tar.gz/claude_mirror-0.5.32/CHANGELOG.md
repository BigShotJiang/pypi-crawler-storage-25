# Changelog

All notable changes to claude-mirror.

---

## [0.5.32] — 2026-05-07

Two additive features bundled into one release: a colorized diff command and configurable snapshot retention. Plus the held documentation tweaks from the v0.5.31 cycle.

### Added — `claude-mirror diff <path>`
- **Colorized line-diff of local vs remote** for a single tracked file. Diff direction is remote → local, so green `+` lines are what would be pushed and red `-` lines are what would be pulled, making "should I push, pull, or merge?" answerable at a glance before doing any of those.
- Handles every state combination cleanly:
  - both sides differ — full unified diff with `@@` hunk headers and configurable context (`--context N`, default 3)
  - only-on-local — every line shown as added (would be pushed)
  - only-on-remote — every line shown as deleted (would be pulled)
  - identical — single "in sync" message, exit 0
  - binary file (NUL-byte sniff or non-utf8 decode) — refused with a one-line note rather than rendering garbage
  - missing on both sides — clear error, exit 1
- Path argument accepts both project-relative (`memory/CLAUDE.md`) and absolute paths inside the project root; absolute paths outside the project root are rejected up-front with the project root surfaced in the error.
- 20 new tests in `tests/test_diff.py` cover the binary heuristic, every render state, and the CLI command across all path-resolution cases.
- Implementation in a new `claude_mirror/_diff.py` module so the rendering logic is decoupled from the CLI wiring and reusable from future surfaces (VS Code extension, web dashboard if either ever ships).

### Added — Snapshot retention policies (`keep_last`, `keep_daily`, `keep_monthly`, `keep_yearly`)
- **Four new YAML config fields** that compose into a multi-bucket retention policy:
  - `keep_last` — keep the N newest snapshots regardless of age
  - `keep_daily` — for the last N days, keep the newest snapshot in each day-bucket (UTC)
  - `keep_monthly` — for the last N months, keep the newest snapshot in each month-bucket
  - `keep_yearly` — for the last N years, keep the newest snapshot in each year-bucket
- Each is independent — the **union** of every selector's keep-set is retained — so a user can compose "newest 7 + last 30 days + last 12 months + last 5 years" cleanly without overlap concerns. Every field defaults to `0` (= disabled), so existing projects see zero behaviour change.
- **Auto-prune after `claude-mirror push`**: when any retention field is non-zero in the config, push runs `prune_per_retention(...)` after the upload finishes and logs the deletion summary. Setting the YAML field IS the consent — no extra confirmation prompt fires for the auto-prune path.
- **New `claude-mirror prune` CLI command** for ad-hoc / manual invocation. Reads the four `keep_*` fields from the project YAML by default; any `--keep-last`, `--keep-daily`, `--keep-monthly`, `--keep-yearly` flag overrides the corresponding config field for that one run only (the YAML is not modified). Dry-run by default per the project's destructive-ops convention; require `--delete` plus a typed `YES` (or `--yes` for non-interactive use) to actually remove anything.
- 17 new tests in `tests/test_retention.py` cover: config field defaults + YAML round-trip; the algorithm across all four buckets independently; the union behaviour when all four compose; dry-run = no writes; the CLI's dry-run-by-default + typed-YES + flag-overrides-config invariants.

### Fixed — `claude-mirror status` lost its live phase progress in v0.5.30
- **Regression** introduced when `status --watch` was added in v0.5.30: the refactor extracted `_build_status_renderable` from the original `engine.show_status()` but dropped the `on_local` / `on_remote` phase-progress callback wiring. As a result, the snapshot-mode `claude-mirror status` ran silently during local hashing + remote listing, then dumped the full table all at once at the end — instead of the dual-row "Local: hashing 42/120 files" / "Remote: explored 7 folder(s), 312 file(s)" updates.
- Fix: `_build_status_renderable` gained a `with_progress` parameter. `status` (snapshot path) calls it with `with_progress=True`, which opens a transient dual-row Progress and forwards `on_local` + `on_remote` callbacks into `engine.get_status(...)` — restoring the pre-v0.5.30 live updates. `status --watch` keeps `with_progress=False` because the outer `rich.live.Live` already owns the live region (running both at once would interleave/flicker).
- Pinned with a regression test in `tests/test_status_watch.py` that asserts the snapshot path forwards both callbacks into `get_status` so this behaviour can't silently regress again.

### Updated — README and command summary
- README "How it works" / quality-gates line updated to reflect the now-303 tests and Python 3.11 / 3.12 / 3.13 / 3.14 matrix (the doc tweaks from the v0.5.31 cycle, held back for this feature bump).
- Command-summary block now includes `claude-mirror diff` and `claude-mirror prune` with their flags.
- CONTRIBUTING.md updated to mention Python 3.14 in the CI matrix.

---

## [0.5.31] — 2026-05-07

CI fix for the v0.5.30 watch-mode tests, plus Python 3.14 added to the supported matrix.

### Fixed — `status --watch` test suite green on Linux Python 3.11/3.12/3.13
- The three watch-mode tests in `tests/test_status_watch.py` failed in CI on Ubuntu / Python 3.11, 3.12, and 3.13 with `Aborted!` exit_code 1, while passing locally on Python 3.14 / macOS. Root cause: the tests monkey-patched `time.sleep` globally to raise `KeyboardInterrupt`, but the global patch could fire from unrelated stdlib code paths between `CliRunner.invoke` and the watch loop's `try/except`, surfacing as Click's `Abort()` instead of being caught by the loop's interrupt handler.
- Fix: introduced a thin `_status_watch_sleep(interval)` indirection in `claude_mirror/cli.py` that the watch loop calls instead of `time.sleep` directly. Tests now patch `cli_module._status_watch_sleep` (one specific call site) rather than the global `time.sleep`, eliminating the interference. No production behaviour change — the helper is a one-line wrapper.

### Added — Python 3.14 to test matrix and PyPI classifiers
- `.github/workflows/test.yml` now runs the test suite on Python 3.11, 3.12, 3.13, and 3.14 (matching the maintainer's local dev version, so future regressions surface uniformly across all supported versions before they reach a release tag).
- Added `Programming Language :: Python :: 3.14` to `pyproject.toml` classifiers so the PyPI page and resolver correctly advertise 3.14 support.

---

## [0.5.30] — 2026-05-07

Three additive features bundled into one release.

### Added — `claude-mirror doctor [--config PATH] [--backend NAME]`
- **One-shot configuration diagnostic** that replaces the "why isn't my sync working" support thread. Runs through six check categories per backend (primary plus every Tier 2 mirror in `mirror_config_paths`):
  1. Config file parses
  2. Credentials file present (skipped for WebDAV which uses username + password)
  3. Token file has `refresh_token`, or for WebDAV has `username` + `password`
  4. Backend connectivity via `get_credentials()` plus a `list_folders(root, name=None)` smoke call, with class-specific fix hints based on the exception type (auth / permission / 404 / network / unknown)
  5. `project_path` exists and is a directory
  6. Manifest JSON integrity (read directly rather than via `Manifest.load()`, which auto-quarantines corrupt files and would mask the failure)
- All checks always run (no early exit) so the user sees every issue in one pass. Exit code 0 on all-pass, 1 on any failure — composes cleanly with shell scripts and CI.
- `--backend NAME` limits checks to one backend (relevant for users with Tier 2 multi-mirror setups who want to debug just one).
- 10 new tests in `tests/test_doctor.py` cover happy-path, each failure category, the per-backend filter, and the exit-code contract.

### Added — `claude-mirror status --watch SECONDS`
- Live-updating sync state via `rich.live.Live`. `claude-mirror status --watch 10` refreshes the status display in place every 10 seconds until the user presses Ctrl+C; on interrupt, prints "watch stopped" and exits cleanly without a stack trace.
- Refresh interval is validated as `IntRange(min=1, max=3600)` at the Click layer; values outside that range error before the loop starts.
- Snapshot mode (without `--watch`) is byte-for-byte unchanged — the same rendering helper `_build_status_renderable` produces a Rich `Group`/`Table`/`Text` consumed by both `console.print` (snapshot) and `Live.update` (watch).
- `--watch` is also wired into the Tier 2 pending-state view (`status --pending --watch 10`), refactored into a parallel `_build_pending_renderable` helper.
- 7 new tests in `tests/test_status_watch.py` cover the snapshot regression, Live entry, multi-iteration loop with Ctrl+C exit, the click-level interval validation, the "watch stopped" stop message, and the renderable-helper return type.

### Added — `parallel_workers` config field (project-scoped)
- New YAML field `parallel_workers: int = 5` (default 5, matching the previous hardcoded constant). Override per project to tune `ThreadPoolExecutor` concurrency for blob uploads, snapshot copies, recursive listings, and other parallel operations. Useful for slow CPUs (lower), fat home connections (higher), and rate-limited APIs (lower).
- Every existing call site of `PARALLEL_WORKERS` (4 in `sync.py`, 13 in `snapshots.py`) now reads `self.config.parallel_workers` instead of the module-level constant. The constant in `claude_mirror/_constants.py` is preserved as the documented default value of the new field; the `tests/test_constants.py` `is`-identity invariant continues to pass.
- 5 new tests in `tests/test_parallel_workers_config.py` cover the default value, YAML override, the boundary at zero, the constant fallback invariant, and an end-to-end test that wraps `concurrent.futures.ThreadPoolExecutor` and asserts `max_workers=3` propagates when the config sets `parallel_workers=3`.

### Notes
- Total suite: 265 tests, runtime under one second.
- All three features ship as additive changes — no observable behaviour change for existing configs (defaults match the prior hardcoded values; `--watch` is opt-in; `doctor` is a new command).

---

## [0.5.29] — 2026-05-07

### Added
- **`SECURITY.md`** at the repo root. Documents the security-advisory reporting flow (GitHub's private security-advisory form at `https://github.com/alessiobravi/claude-mirror/security/advisories/new` rather than public issues), what the maintainer commits to (acknowledgement within seven days, fix in a private branch shipped as a patch release, credit in the CHANGELOG unless the reporter asks otherwise, no bug bounty), what is in scope (the `claude_mirror/` package, the helper scripts in `skills/`, the CLI commands, the CI workflows, and anything that ships in the wheel or sdist) and out of scope (third-party SDKs, the user's own environment, the cloud backends themselves, the Claude Code agent platform). Also enumerates what claude-mirror's design protects against (no maintainer-operated infrastructure on the data path, chmod 0600 token files, path-traversal guards via `_safe_join`, error-message redaction via `redact_error`, TLS with default certificate verification on every network call, and a fixed allowlist of network destinations) so reporters know which boundaries to test.
- **`.github/ISSUE_TEMPLATE/bug_report.md`** standard bug-report template. Pre-fills the fields that diagnosis usually needs (`claude-mirror --version`, OS and version, Python version, backend in use, install method, the exact command, the steps to reproduce, the full error output, what the reporter has already tried) so incoming reports come in a useful shape rather than a free-form sentence. Includes a top-of-template note redirecting security issues to the private security-advisory form.
- **`.github/ISSUE_TEMPLATE/config.yml`** wires a "Security vulnerability (private)" option into GitHub's issue-creation chooser, pointing at the same security-advisory URL. Blank issues remain enabled for cases the bug-report template does not fit.

### Notes
- Pure repository-metadata patch; no runtime behaviour change. Tests stay at 243.
- The GitHub repo's "About" sidebar (description and topic tags) is set via the GitHub web UI, not the repo contents, so it ships as a manual operation alongside this commit rather than as code.

---

## [0.5.28] — 2026-05-07

### Docs
- **Skill (`skills/claude-mirror.md`) gains a "Shell tab-completion" section.** Pre-v0.5.28, the v0.5.27 tab-completion feature was documented in `README.md` and `CHANGELOG.md` but not in the skill that ships at `~/.claude/skills/claude-mirror/SKILL.md`. The Claude Code agent reading the skill now knows that `claude-mirror-install` auto-installs tab-completion, that the `completion` command can emit the script directly for any of the three supported shells, and that the most common reason tab-completion fails to work after install is that the user's current shell session was started before the rc-file edit (fix: re-source the rc file or open a new terminal).
- **`CONTRIBUTING.md` documents the two tab-completion code surfaces** for future contributors: the `completion` Click command in `claude_mirror/cli.py` (tests at `tests/test_completion.py`) and the `install_completion` / `uninstall_completion` functions in `claude_mirror/install.py` (tests at `tests/test_install_completion.py`). The new paragraph describes which file to touch for which kind of change and explicitly calls out the `_completion_activation_pending` module-level flag that drives the end-of-install activation banner.

### Notes
- Pure documentation patch; no runtime behaviour change. Suite stays at 243 tests.

---

## [0.5.27] — 2026-05-07

### Added
- **`claude-mirror completion {bash|zsh|fish}`** emits shell tab-completion source for the user to eval into their shell rc. Click 8's native completion already works via `_CLAUDE_MIRROR_COMPLETE=<shell>_source claude-mirror`, but that bootstrap is opaque enough that nobody discovers it. The new command exposes the same script under a discoverable name:
  ```bash
  # zsh
  eval "$(claude-mirror completion zsh)"

  # bash
  eval "$(claude-mirror completion bash)"

  # fish
  claude-mirror completion fish > ~/.config/fish/completions/claude-mirror.fish
  ```
- After installation, tab-completion handles:
  - **Command names:** `claude-mirror <TAB>` → `auth / completion / delete / find-config / forget / gc / history / inbox / init / inspect / log / migrate-snapshots / migrate-state / pull / push / reload / restore / retry / snapshots / status / sync / test-notify / update / watch / watch-all` plus `check-update`
  - **Flag names:** `claude-mirror push <TAB>` → `--config / --files / --force-local`
  - **`click.Choice` values automatically** — e.g. `claude-mirror init --backend <TAB>` → `googledrive / dropbox / onedrive / webdav`
  - **File paths for `--config <TAB>`** — handled by the shell itself (no extra completer needed)

- **`claude-mirror-install` now auto-installs shell tab-completion** as one of its components. Pre-v0.5.27, users had to manually run `eval "$(claude-mirror completion zsh)"` to get tab-completion — most users never discovered it. The installer now:
  - **Detects your shell** from `$SHELL` (zsh / bash / fish; falls back to platform default if unset).
  - **Picks the right target file** — `~/.zshrc` for zsh; `~/.bash_profile` on macOS or `~/.bashrc` on Linux for bash; `~/.config/fish/completions/claude-mirror.fish` for fish.
  - **Wraps the addition in marker comments** so the whole block can be found and removed cleanly by a future `claude-mirror-install --uninstall`. The begin marker is `# >>> claude-mirror tab-completion (added by claude-mirror-install) >>>`, the end marker is `# <<< claude-mirror tab-completion <<<`, and the `eval` line sits in between.
  - **Prompts before any change** (consistent with the rest of the installer; declining skips this component without affecting the others).
  - **Idempotent** — re-running install with no changes is a true no-op (no rewrite of the rc file). If the binary path changed (e.g. `pipx install -e` → PyPI install), the prompt offers to refresh the stored eval line.
  - **Skips cleanly on unsupported shells** (sh, dash, csh, tcsh, ksh) with a warning rather than writing a broken file.
- **Prominent activation banner at the end of `claude-mirror-install`.** When tab-completion is newly added to the rc file (or refreshed because the binary path changed), the install command finishes with a high-contrast yellow banner explaining that tab-completion is installed but is not yet active in the current shell, and pointing at the exact `source` command needed to activate it (or instructing the user to open a new terminal). The banner exists because the per-step `✓ Tab-completion installed in <path>` line during install was easy to skim past, leading users to think completion was working when it was not yet sourced into their current shell.
- **Optional one-shot shell replacement during install.** After the activation banner the installer asks "Replace the current shell with a fresh one now to activate tab-completion immediately? (Default: No — open a new terminal manually instead.)". A `Y` answer calls `os.execvp(shell, [shell])`, replacing the install process with a fresh interactive shell that sources the user's rc file and picks up the new completion immediately. The default of `No` is intentional, because `os.execvp` discards any environment variables the user set during the install session and returns them to a fresh login-equivalent shell. For users who would rather avoid that side effect, opening a new terminal or running `source <rc-file>` manually has the same effect with no process replacement.

### Tests
- New `tests/test_completion.py` (7 tests) covers each shell's emitted script + invalid-shell rejection + case-insensitive shell argument + completion-command discoverability via top-level `--help`.
- New `tests/test_install_completion.py` (22 tests) covers shell detection, target-file resolution, install (zsh, bash, fish + idempotency + update path), uninstall (preserves user content above and below the marker block), the unsupported-shell skip path, and the `_completion_activation_pending` module flag that drives the end-of-run banner (set on first install, set on refresh, NOT set on no-op idempotent skip, NOT set on unsupported-shell skip).

### Removed
- Removed legacy `claude-sync` migration support. Specifically:
  - `claude-mirror migrate-state` command and its helpers (`_LEGACY_CONFIG_DIR`, `_NEW_CONFIG_DIR`, `_FILE_RENAMES`, `_detect_legacy_state`).
  - `_legacy_state_banner` startup warning that detected `~/.config/claude_sync` and prompted users to migrate.
  - `CLAUDE_MIRROR_SUPPRESS_MIGRATION_BANNER` env var.
  - `LEGACY_SKILL_DIR` cleanup in `install.py:install_skill` that detected `~/.claude/skills/claude-sync` and prompted to remove it.
  - `LEGACY_HOOK_COMMAND_PREFIXES` strip-and-prune logic in `install.py:install_hook` that scanned `~/.claude/settings.json` for `claude-sync inbox` entries and removed them.
  - Dual-prefix folder-exclusion predicates `startswith(("_claude_sync", "_claude_mirror"))` narrowed back to single prefix `startswith("_claude_mirror")` in `claude_mirror/backends/onedrive.py`, `claude_mirror/backends/webdav.py`, and `claude_mirror/snapshots.py`.
  - Legacy `.claude_sync_manifest.json`, `.claude_sync_inbox.jsonl`, and `.claude_sync_hash_cache.json` patterns from `.gitignore`.
  - `migrate-state` row from `README.md`'s command reference table.

### Notes
- Pure CLI and installer feature pair; no behaviour change to sync, push, pull, snapshots, or any other working-tree command.
- Total suite: 243 tests, runtime under one second.

---

## [0.5.26] — 2026-05-07

### Added
- **`PRIVACY.md`** — full privacy policy at the repo root. Plain-language description of what data claude-mirror handles, where it goes, and what the maintainer has access to. Sections cover: what data flows where (3 explicit categories: stays local / user↔cloud / user↔GitHub-version-check), what the maintainer CAN see (aggregate count + PyPI download stats; no identities, no files, no metadata), token security (chmod 0600, double-write guard, where to revoke per backend), the bring-your-own-app advanced option, and source-code transparency (the `grep -rn 'https://' claude_mirror/` audit trail anyone can run).
- **`PRIVACY.md` is shipped now (pre-v0.6.0) so it has a stable GitHub URL** before the upcoming v0.6.0 Dropbox + Azure AD app registrations need to point at it (both providers require a privacy-policy URL during app registration).

### Infrastructure
- **`.gitignore`** adds `ROADMAP_*.md` glob so future internal planning docs (e.g. `ROADMAP_v060.md`) follow the same local-only convention as `ROADMAP.md` without needing per-file additions.

### Notes
- No code change; no behaviour change. Wheel rebuilt because `PRIVACY.md` is part of the sdist (Hatchling's default sdist policy includes tracked files), and so PyPI's project page has the latest list of bundled files.

---

## [0.5.25] — 2026-05-07

### Infrastructure
- **PyPI Trusted Publishing** is now wired up for the release flow. New `.github/workflows/publish.yml` triggers on tag pushes matching `v*`, runs the full 214-test suite on a clean Ubuntu VM as a final pre-flight, builds the wheel + sdist, generates a **SLSA-3 build provenance attestation** via `actions/attest-build-provenance@v3`, then uploads to PyPI using OIDC — no API token is read from anywhere.
- **Anyone can now verify a published release was built by this repo's CI:**
  ```bash
  gh attestation verify <wheel-path> --owner alessiobravi --repo claude-mirror
  ```
  Returns the workflow filename, commit SHA, and runner identity, chained back to GitHub's OIDC issuer via Sigstore's Fulcio CA.
- **PyPI URL verification.** Now that uploads come from a trusted publisher whose OIDC claim points at `alessiobravi/claude-mirror`, PyPI auto-verifies all `[project.urls]` entries that point at the same repo. The "Unverified details" disclaimer on the project page is replaced with green checkmarks next to Homepage / Repository / Changelog / Documentation / Issues.

### Release flow change
Pre-v0.5.25: bump version → `pyproject-build` → `twine upload dist/*` from laptop with project-scoped token in `~/.pypirc`.

v0.5.25 onward: bump version → `git push origin main` (CI tests run) → after green, `git tag vX.Y.Z && git push origin vX.Y.Z` (publish workflow fires, builds + attests + uploads). Laptop is no longer in the supply-chain critical path; the PyPI token in `~/.pypirc` can be revoked once the first trusted-publishing release lands cleanly.

### Docs
- `CONTRIBUTING.md` documents the new release flow + how downstream users / auditors verify provenance with `gh attestation verify`.

---

## [0.5.24] — 2026-05-07

### Docs
- **README opening rewritten to describe what claude-mirror actually does, not just its original use case.** Pre-v0.5.24, the headline read "Sync Claude project MD files across machines…" — accurate to the project's origin but misleading about its current scope. The file-pattern glob has always been configurable, but the marketing copy implied markdown-only. New headline: "Mirror your project files across machines and cloud backends — with multi-cloud redundancy, time-travel disaster recovery, and real-time collaboration signals." Followed by an explicit note that `file_patterns` is a glob (default `["**/*.md"]`, but `["**/*"]` mirrors everything, and any glob like `["**/*.py", "**/*.md"]` scopes what gets synced).
- **Added a "Why use it" bullet section right at the top** with four value props that previously were buried in the "How it works" technical section: multi-cloud redundancy (Tier 2 mirroring as outage / suspension / quota survival), time-travel DR (`history` + `restore` to any past timestamp, with both blob and full snapshot formats explained), near-real-time collaboration (per-backend notification mechanics in one line each), and no-loss conflict resolution (the four interactive choices). Drive-by visitors now see why this exists before they see how it works.
- **Backend support reordered.** Now appears after the value props instead of mixed in with the headline pitch. Same content, better information hierarchy.

### Notes
- No code change. Wheel + sdist rebuilt only because the README change is the long-description on PyPI's project page; uploading v0.5.24 refreshes that page.

---

## [0.5.23] — 2026-05-07

### Docs
- **README now leads with status badges** for CI test runs, PyPI version, supported Python versions, and license — gives drive-by visitors immediate signal that the project is maintained, tested, and on a known cadence.
- **README explicitly advertises the test suite** in a new "Quality gates" paragraph at the top: 214 tests on Python 3.11/3.12/3.13 in parallel, what surfaces are covered, the merge-blocking guarantee, and a pointer to `CONTRIBUTING.md` for run-it-yourself instructions. Closes the gap where readers had no way to gauge code-quality posture without scrolling to the changelog.

### Tests
- **`test_redact_error_strips_bearer_token` now uses an unambiguously-fake token fixture.** The previous fixture (`Bearer ya29.a0AfH6SMB...`) used the real-world Google access-token prefix `ya29.`, which would trip automated secret scanners (PyPI / GitHub Advanced Security / TruffleHog) into flagging the test file as a leaked credential — even though the suffix was nonsense. New fixture is `Bearer FAKE_TOKEN_NOT_A_REAL_CREDENTIAL_xxx...` which exercises the same redactor regex code path without resembling a real token shape. Test logic is unchanged.

### Privacy audit (no findings)
- Full repo grep ran across all tracked files for: real Mac/Linux paths (`/Users/<name>`, `/home/<name>`), personal aliases (`claude-aa`), other-project codenames (`Cortex/`, `cortex.yaml`), real `user@machine` slack-style examples, personal email addresses, real-format Drive folder IDs (excluding the well-known Google sample), real internal hostnames, and token-shaped strings. Zero hits remained after the bearer-token fixture rewrite.

### Infrastructure
- **CI workflow bumped to action versions that support Node.js 24.** GitHub deprecates Node.js 20 from runners on 2026-09-16; from 2026-06-02 actions running on Node 20 emit warnings until forced onto Node 24. Bumped `actions/checkout@v4 → v5` and `actions/setup-python@v5 → v6`. Both new majors are drop-in compatible (same `with:` keys); the only behavioural change is the runtime Node version, which we never depend on directly. Eliminates the warning banner on every CI run.

---

## [0.5.22] — 2026-05-07

### Fixed
- **`claude-mirror-install` now installs the Claude Code skill for PyPI users.** Pre-v0.5.22, `_find_skill_source()` only checked the editable-install layout (`<install.py>/../skills/claude-mirror.md`). For users who installed via `pipx install claude-mirror` from PyPI, that resolved to `<venv>/lib/python3.X/site-packages/skills/`, which doesn't exist — the installer printed `Skill source file not found — skipping` and the user got the binary without the skill.
  - **Fix in two parts:**
    1. **Wheel now bundles the skill.** `pyproject.toml` adds a `[tool.hatch.build.targets.wheel.force-include]` directive mapping `skills/claude-mirror.md` → `claude_mirror/_skill/claude-mirror.md` inside the wheel. The 14,711-byte file is now present in every PyPI install at `<site-packages>/claude_mirror/_skill/claude-mirror.md`.
    2. **`_find_skill_source()` checks the bundled location first**, falling back to the repo `skills/` directory for editable installs from a clone. Both paths return the same content; the resolution order means PyPI users never miss it.
- **No code change for editable-install users.** The repo `skills/claude-mirror.md` is still authoritative; the bundled copy is generated at wheel-build time.

### Tests
- New `tests/test_skill_bundling.py` (4 tests) pins both resolution paths:
  - `test_find_skill_source_returns_existing_path_in_dev_layout` — editable install (the test environment) resolves to the repo file successfully.
  - `test_find_skill_source_prefers_bundled_over_repo` — when both layouts exist, the bundled wheel copy wins.
  - `test_find_skill_source_falls_back_to_repo_when_bundled_missing` — editable installs without `_skill/` still find the source.
  - `test_find_skill_source_returns_none_when_neither_exists` — graceful no-op so `install_skill()` can show its own friendly skip message.
- Suite now totals **214 tests**, still <1 s.

### Verified
- Built v0.5.22 wheel, installed into a fresh venv (`python3 -m venv /tmp/...`), verified `_find_skill_source()` returns the bundled `claude_mirror/_skill/claude-mirror.md` (14,711 bytes) — the first version where PyPI users get a complete `claude-mirror-install`.

---

## [0.5.21] — 2026-05-07

This release is a coordinated multi-agent test-coverage push. **210 tests** now pass in <1 s; coverage of every major feature surface jumped from ~10% to ~70%. No runtime behaviour change beyond a single import fix in `snapshots.py`.

### Tests added
- **SyncEngine 3-way diff** (`tests/test_sync_engine.py`, **29 tests**) — full state matrix: no-manifest cells, in-sync, one-side-changed, both-changed/conflict, deletes. push / pull / sync / `_delete_drive_file` end-to-end against an in-memory backend. `force_local=True` skip-resolver pinned with hard-failing monkeypatch.
- **SnapshotManager** (`tests/test_snapshots.py`, **25 tests**) — both formats (`full` + `blobs`): create / list / restore (incl. `output_path` and per-backend fallback) / forget (specific timestamps, `--keep-last`, `--keep-days`, `--before`) / gc (orphan list + dry-run + apply) / migrate (full↔blobs, idempotent) / history (path-grouped-by-SHA) / inspect (`--paths` filter).
- **Path-traversal guard** (`tests/test_safe_join.py`, **23 tests**) — security-critical, parametrized over safe paths and traversal attacks (`..` segments at every depth, absolute paths, NUL bytes).
- **Conflict resolver** (`tests/test_merge_resolver.py`, **13 tests**) — `[L]ocal / [D]rive / [E]ditor / [S]kip` choices, conflict-marker file with `claude_mirror_merge_` prefix, editor invocation via subprocess.
- **Auth backup-and-restore** (`tests/test_auth_backup_restore.py`, **6 tests**) — regression test for the v0.5.11 fix: token moved to `<token>.pre-reauth.bak`, deleted on success, restored on failure, `--keep-existing` opt-out.
- **Per-backend round-trip** (`tests/test_googledrive_backend.py` + `test_dropbox_backend.py` + `test_onedrive_backend.py` + `test_webdav_backend.py`, **27 tests**). Drive (12) — `googleapiclient.discovery.build` mocked, covers auth/folders/path-resolve/upload/download/hash/error-classification incl. `RefreshError("invalid_grant")` → AUTH and `HttpError(503)` → TRANSIENT. Dropbox / OneDrive / WebDAV (5 each) — smoke coverage via `mock_oauth_*` fixtures + `responses` HTTP mocking. WebDAV explicitly tests the v0.5.6 https-required guard.
- **Notifier inbox** (`tests/test_notifier_inbox.py`, **7 tests**) — concurrency-critical. Includes the **TOCTOU regression test** (writer thread + drain loops asserting strict equality, would fail immediately if `read_and_clear_inbox` regressed away from `LOCK_EX`), plus round-trip / multi-write / corrupt-line / unicode / filename invariant.
- **Watcher daemon** (`tests/test_watcher.py`, **6 tests**) — smoke: one-thread-per-config, dedup, SIGHUP handler registration, `claude-mirror reload` sends SIGHUP via subprocess.

### Fixed
- **`snapshots.py` was missing a `timedelta` import** (uncovered by `test_forget_keep_days_n`). Any `forget --keep-days=N` or relative `--before=30d` invocation would have raised `NameError`. One-line fix; new test pins it.

### Infrastructure
- **`.github/workflows/test.yml`** runs the full suite on push and pull request, against Python 3.11 / 3.12 / 3.13 in parallel. CI now blocks merging a PR that fails tests.
- **`CONTRIBUTING.md`** — layout, fixture conventions, local-run commands, what's expected of PRs.
- **`pyproject.toml`** dev extras now include `responses>=0.25` for HTTP-level backend mocking.
- **`tests/conftest.py`** — full `StorageBackend` ABC fake (`FakeStorageBackend`), `NotificationBackend` fake (`FakeNotificationBackend`), and OAuth-flow mock fixtures for all four backends.

### Notes
- Test files are intentionally NOT shipped to PyPI. The Hatchling wheel build only includes `packages = ["claude_mirror"]`.
- Two test files (`test_sync_engine.py`, `test_snapshots.py`) build their own `InMemoryBackend` rather than reusing `conftest.FakeStorageBackend` because each needs slightly different semantics. Both work, both pass.
- Click 8.3 emits a `DeprecationWarning` for `Context.protected_args`; auth + watcher tests use module-level `filterwarnings("ignore::DeprecationWarning")` to coexist with the project-wide `filterwarnings = "error"` setting.

---

## [0.5.16] — 2026-05-07

### Fixed
- **Narrowed broad `except Exception` clauses on six load/best-effort paths.** Catching the bare `Exception` base class hides real coding bugs (`AttributeError`, `TypeError`, `NameError`) as "feature silently does nothing" — by far the hardest class of bug to track down because there's no traceback, no log line, just a behaviour that quietly stops working. Each site now narrows to exactly the exception types its legitimate failure modes can raise; programming bugs propagate normally so they're caught in development instead of in production.
  - `claude_mirror/hash_cache.py:_load` — narrowed to `(json.JSONDecodeError, OSError)`. Corrupt or unreadable hash cache → start with empty dict (the cache is purely a performance optimisation).
  - `claude_mirror/manifest.py:_is_safe_relpath` — narrowed to `(ValueError,)`. `Path()` raises `ValueError` on embedded NUL on some platforms; nothing else is expected here.
  - `claude_mirror/_update_check.py:_resolve_repo_root` — narrowed to `(ImportError, OSError)`. `ImportError` if the package isn't installed; `OSError` if `Path.resolve()` fails (broken symlink, missing dir).
  - `claude_mirror/_update_check.py:suggested_update_command` — narrowed to `(ImportError, OSError)`. Same shape as `_resolve_repo_root`.
  - `claude_mirror/_update_check.py:_get_current_version` — narrowed to `(ImportError, LookupError)`. `LookupError` is the parent of `importlib.metadata.PackageNotFoundError`.
  - `claude_mirror/_update_check.py:_load_cache` — narrowed to `(json.JSONDecodeError, OSError, ValueError)`. JSON parse / file-read / generic decode failure modes only.
  - `claude_mirror/_update_check.py:_save_cache` — narrowed to `OSError`. mkdir/write_text/os.replace all surface filesystem errors as `OSError`; non-serialisable cache data is a coding bug, not a runtime failure.

### Tests
- Added `tests/test_load_paths_narrow.py` (6 regression tests pinning the new behaviour):
  - `test_hash_cache_returns_empty_on_corrupt_json` — malformed cache file is treated as 'no cache yet' (legitimate failure mode still no-ops).
  - `test_hash_cache_propagates_attribute_error` — a coding bug in `json.loads` is NOT swallowed (the original regression test).
  - `test_manifest_load_propagates_programming_bugs` — `TypeError` raised inside `_is_safe_relpath` propagates rather than being misread as 'unsafe path'.
  - `test_update_check_silent_on_network_error` — `URLError` from urllib results in a clean no-op (the foreground command still works offline).
  - `test_update_check_load_cache_propagates_attribute_error` — coding bug in cache parse propagates out of `_load_cache`.
  - `test_update_check_load_cache_silent_on_corrupt_json` — `JSONDecodeError` on a corrupt cache file yields `{}` silently.

---

## [0.5.15] — 2026-05-07

### Refactored
- **Removed dead-equivalent branch in `Manifest._is_safe_relpath`** (`manifest.py:165`). The condition `part.startswith("..") and (part == ".." or part in ("..", ))` was a confusingly over-defensive way to write `part == ".."` — and the literal-`".."` case is already caught by the preceding `part in ("..", "\\..", "/..")` check on the line above. Removing the redundant branch simplifies the path-traversal guard without changing rejection semantics: `..` segments still rejected, names that merely START with `..` (e.g. `..foo`, `...trailing`, `.hidden`) still accepted as legal POSIX filenames. Covered by `tests/test_path_safety.py`.
- **Deduplicated `PARALLEL_WORKERS = 5` constant.** Previously declared twice — once in `sync.py:24` and once in `snapshots.py:68` — meaning a tuning bump required remembering to bump both. The constant now lives in a new `claude_mirror/_constants.py` module, imported by reference into both call sites. The `is`-identity invariant is asserted in `tests/test_constants.py` so any regression that re-declares it in either module fails CI.

---

## [0.5.14] — 2026-05-07

### Fixed
- **OneDrive `classify_error` no longer misclassifies "Token"-named transient errors as `AUTH`.** The previous heuristic ran a substring check on `type(exc).__name__` for `"Auth"` or `"Token"` and routed any match to `ErrorClass.AUTH`. That correctly caught `MsalUiRequiredError` but also caught any unrelated exception that happened to have one of those words in its class name — for example, a transient `TokenRateLimitError` would surface as a scary "re-authenticate" prompt and force the user through a pointless interactive OAuth flow for what should auto-retry.
  - **Class-name allowlist.** Only `MsalUiRequiredError` and `InteractionRequiredAuthError` (the two MSAL exception names that unambiguously mean "silent token failed; user must re-auth") trigger the AUTH classification by class name. `MsalServiceError` is intentionally excluded from the allowlist because it covers a wide range of service-side conditions, only some of which require re-auth.
  - **OAuth error-code branch.** For the broader exceptions, the classifier now inspects `exc.args` and matches against a narrow set of OAuth/AAD codes that genuinely mean "refresh token is dead": `invalid_grant`, `AADSTS50058` (silent sign-in with no signed-in user), `AADSTS70008` (refresh token expired), and `AADSTS700082` (refresh token expired due to inactivity). Every other server-side error falls through to the existing HTTP-status / network branches, which classify them as `TRANSIENT` or `UNKNOWN` as appropriate.
  - **Net effect.** Recoverable rate-limit / service blips no longer interrupt the user; only genuine credential failures prompt for re-auth.

### Tests
- New `tests/test_onedrive_classify_error.py` (10 tests) locks in the fix: synthesised `MsalUiRequiredError` and `InteractionRequiredAuthError` are AUTH; synthesised `TokenRateLimitError` is NOT AUTH (UNKNOWN); `invalid_grant`, `AADSTS50058`, and `AADSTS70008` in `exc.args` are AUTH; bare `RuntimeError("backend exploded")` is UNKNOWN; HTTP 401 → AUTH, 429 → QUOTA, 503 → TRANSIENT regression guards.

---

## [0.5.13] — 2026-05-07

### Performance
- **`SyncEngine._is_excluded` now uses a pre-compiled regex instead of a per-call `fnmatch.fnmatch` loop.** The previous implementation invoked `fnmatch.fnmatch` up to 3 times per pattern per file, and each call internally compiled (and LRU-cached) a regex. On a 5,000-file project with 10 exclude patterns, status/push/pull each made up to 150,000 `fnmatch.fnmatch` calls per command. The new code builds a single union regex of every `pattern` + `pattern/*` form once at `SyncEngine.__init__`, plus a `tuple(f"{p}/" for p in patterns)` for the legacy `startswith` branch. `_is_excluded` is now one `re.match` + one `str.startswith` per file.
  - **Measured impact** on the reference benchmark (10,000 path checks × 10 patterns, Python 3.14, Apple Silicon, median of 5 runs):
    - Old fnmatch loop: **38.00 ms**
    - New precompiled regex: **5.19 ms**
    - **Speedup: 7.3x** (-86% wall time)
  - Behaviour is byte-for-byte identical to the legacy implementation — verified by a 39-case parametrize sweep in `tests/test_exclude_patterns.py` comparing every input shape against the old fnmatch-loop reference.

### Documentation
- **`SyncEngine._local_files` now documents its symlink behaviour explicitly.** `Path.glob()` follows symlinks transparently — both for symlinked files (included under their symlink path) and symlinked directories (traversed like any other directory). Cycles are not detected. This is unchanged behaviour; the docstring just makes the policy discoverable. Switching to non-following semantics in the future is a behaviour change deserving its own version bump and migration note.

### Tests
- New `tests/test_exclude_patterns.py` (45 cases): simple-glob match, directory-form prefix match, `**/*` double-star match, empty-config short-circuit, compile-once invariant, perf smoke (<100ms / 10K calls), and a 39-case parity sweep against the verbatim legacy fnmatch-loop oracle.

---

## [0.5.11] — 2026-05-07

### Fixed
- **`claude-mirror auth` no longer falls into a "run claude-mirror auth" loop.** Previously, if Google's OAuth refresh path returned a `RefreshError` whose error string didn't match the three substrings in `_is_invalid_grant()` (`invalid_grant`, `token has been expired or revoked`, `account has been deleted`), the global `_CLIGroup` error handler caught it and instructed the user to run `claude-mirror auth` — the very command they had just run. The user had no path forward.
  - **Primary fix — `auth` command pre-emptively replaces the token file.** The existing token is moved to `<token>.pre-reauth.bak` before `storage.authenticate()` is called. The backend therefore sees no cached credential and goes straight to the interactive OAuth flow (browser for Google, code-paste for Dropbox, device-code for OneDrive, password prompt for WebDAV). On OAuth success, the backup is deleted; on OAuth failure (Ctrl-C, network, browser error), the backup is restored — running `auth` is therefore always safe and never leaves the user with a worse state than they started with.
  - **Secondary fix — `_CLIGroup.invoke()` knows when the running command is `auth`.** When `sub_cmd == "auth"`, the error handlers no longer print "run claude-mirror auth" (the loop trap). Instead they show "OAuth flow itself failed" with diagnostic hints: network reachability of accounts.google.com, validity of `credentials_file`, ability to bind a local OAuth callback port, and the `CLAUDE_MIRROR_AUTH_VERBOSE=1` env var for refresh-attempt logs.
  - **New `--keep-existing` flag** preserves the older behaviour for explicit refresh diagnostics: with it, `auth` does NOT move the token aside, so the backend's `authenticate()` will try to refresh first before falling through. Use this only when you want to test whether an existing token still works.

### Audit
- Confirmed that **only the Google Drive backend was affected** by the loop. Dropbox / OneDrive / WebDAV `authenticate()` already runs a fresh interactive flow on every call without consulting the existing token file, so those paths were never susceptible.

---

## [0.5.10] — 2026-05-05

Initial public release.

### Features

**Backends (storage)**
- Google Drive (Pub/Sub-driven real-time notifications)
- Dropbox (long-poll notifications)
- OneDrive (Graph API + polling)
- WebDAV (PROPFIND polling; OwnCloud / Nextcloud / Apache mod_dav / NAS / Box.com)
- Multi-backend mirroring (Tier 2): one primary backend + N secondary mirrors per project, with per-mirror manifest state and pending-retry queue.
- All backends ship in the base install — `pipx install claude-mirror` is the only command needed regardless of which backend you choose.

**Sync engine**
- 3-way diff manifest (`local hash` × `synced hash` × `remote hash`) with content-addressed change detection.
- Conflict resolver with `[L]ocal / [D]rive / [E]ditor / [S]kip` interactive choices.
- `push --force-local` for skill-side merges that should treat local as authoritative.
- File-pattern allowlist + glob exclude patterns, applied uniformly to status/push/pull/sync/delete.
- Per-machine Pub/Sub subscriptions with `SIGHUP` hot-reload of config tree (`claude-mirror reload`).
- Pending-retry queue with classified error types (TRANSIENT / AUTH / QUOTA / PERMISSION / FILE_REJECTED) for graceful degradation under transient failures.

**Snapshots & disaster recovery**
- Auto-snapshot after every push/sync, stored on the remote storage (`_claude_mirror_snapshots/`).
- Two on-disk formats: `full` (one folder per snapshot, server-side `files.copy`) and `blobs` (content-addressed dedup with `_claude_mirror_blobs/`).
- `claude-mirror history PATH` — shows every snapshot containing a file, version-grouped by SHA-256.
- `claude-mirror inspect TIMESTAMP` — list snapshot contents with `--paths` filtering.
- `claude-mirror restore TIMESTAMP [PATH...]` — restore a snapshot (non-destructive `--output`, in-place when omitted, per-backend `--backend NAME` override).
- `claude-mirror forget` and `claude-mirror gc` for safe pruning (dry-run by default; require `--delete` flag and typed `YES` confirmation; `--yes` only for non-interactive use).
- `claude-mirror migrate-snapshots --to {blobs|full}` for in-place format conversion.

**Notifications**
- Cross-platform desktop notifications (macOS `osascript`, Linux `libnotify` via `plyer`).
- Per-project notification inbox (`.claude_mirror_inbox.jsonl`) atomic against concurrent writers.
- Optional Slack webhooks (`slack_enabled` / `slack_webhook_url` / `slack_channel`) with best-effort delivery.

**CLI**
- 25 commands covering init/auth/status/sync/push/pull/delete/watch/snapshots/restore/log/inbox/find-config/migrate-state/migrate-snapshots/check-update/update.
- `claude-mirror init --wizard` for interactive setup; non-wizard path supports the same fields via flags.
- `claude-mirror find-config` walks up the directory tree like `git`'s `.git/` discovery; lists every available config on a total miss.
- `claude-mirror update --apply` one-shot self-upgrade (executes `git pull` + `pipx install -e . --force` as separate list-form `subprocess` calls — never `shell=True`).
- `claude-mirror check-update` queries the GitHub API for the latest version (CDN-bypass for instant visibility after a push); cache-busting headers fall back to raw GitHub when the API is rate-limited.
- Live-progress UI on every long-running command; silence is opt-in via a future `--quiet` flag, never default.

**Installer**
- `claude-mirror-install` — interactive installer for the Claude Code skill, the PreToolUse hook, and the background watcher daemon (launchd on macOS, systemd on Linux).
- Honours `CLAUDE_CONFIG_DIR` so a parallel Claude install is targeted correctly.

**Security & robustness**
- Path-traversal guards on all remote-driven local writes.
- Token files written with `0600` mode + post-`chmod` belt-and-braces.
- Error-message redaction (`redact_error()`) strips Bearer tokens, basic-auth credentials in URLs, query-string secrets, and home-directory paths before any error reaches a manifest, log, Slack message, or `status --pending` output.
- WebDAV backend refuses `http://` URLs by default (transmits credentials in cleartext); `--webdav-insecure-http` flag + `webdav_insecure_http: true` config field opt in.
- `BackendError` drops the live `cause` traceback to avoid pinning credential tuples / response bodies in long-running watcher processes.
- AppleScript notification text escaped against injection.
- All HTTP traffic to first-party endpoints (`api.github.com`, `raw.githubusercontent.com`) over TLS with default cert verification.

**Performance**
- O(1) state lookup on pending-retry queue expansion (was O(N×P)).
- `claude-mirror history` walks path components instead of full BFS per snapshot — ~30× fewer Drive API calls on a 30-snapshot project.
- Blob deduplication with `threading.Lock`-guarded existence check; uploads remain parallel via `ThreadPoolExecutor`.

### Notes
- Python 3.11+, Linux + macOS (Windows untested).
- Config directory: `~/.config/claude_mirror/`. Per-project state: `.claude_mirror_manifest.json`, `.claude_mirror_inbox.jsonl`, `.claude_mirror_hash_cache.json` inside each project.
- Single install command for all backends: `pipx install claude-mirror`.
- License: GPL-3.0-or-later.
