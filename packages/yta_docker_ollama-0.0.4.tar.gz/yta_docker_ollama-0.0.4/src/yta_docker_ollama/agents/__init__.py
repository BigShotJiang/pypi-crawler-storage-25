"""
Module to handle the AI agents.
"""
