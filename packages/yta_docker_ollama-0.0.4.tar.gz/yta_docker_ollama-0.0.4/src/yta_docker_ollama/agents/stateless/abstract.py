from abc import abstractmethod, ABC

import requests


class StatelessAgent(ABC):
    """
    Class to handle an agent that is stateless and
    doesn't have any memory of conversations we had
    in the past.

    This agent is perfect when we need a simple task
    done, such as fixing or rewriting a text, 
    analyze a transcription, etc.

    This agent works, basically, creating a ephemeral
    chat session, giving the instructions to the
    system, receiving a prompt from the user and
    returning the response.
    """

    @property
    @abstractmethod
    def endpoint_url(
        self
    ) -> str:
        """
        The url we have to send the request to.
        """
        pass

    @property
    @abstractmethod
    def model_name(
        self
    ) -> str:
        """
        The name of the model we are using for this agent.
        """
        pass

    def __init__(
        self,
        prompt_system: str
    ):
        self._prompt_system: str = prompt_system
        """
        *For internal use only*

        The prompt that will be given to the chat assistant
        to be able to receive a nice response.
        """

    def ask(
        self,
        prompt: str
    ) -> str:
        """
        Ask the `prompt` provided to the agent and receive
        the response as a single `str`.
        """
        return self._ask_model(
            prompt = prompt,
            temperature = 0.7
        )

    def _ask_model(
        self,
        prompt: str,
        # TODO: What is temperature for (?)
        temperature: float = 0.7
    ) -> str:
        """
        *For internal use only*

        Build the request that the specific model needs to be
        received and answered properly.

        This method will return the response as plain text 
        (string).
        """
        messages = [
            {
                'role': 'system',
                # 'content': 'Eres un experto en edición de texto y eres muy conciso con tus respuestas y muy profesional. A cualquier input que recibas, la única respuesta que das es el texto ya corregido. Se te va a dar un input y tienes que corregirlo. Es una transcripción de un audio, por lo que alguna palabra podría estar mal transcrita o no tener sentido, pero como eres un profesional, serás capaz de solucionarlo. Recuerda, solo da como respuesta el texto corregido directamente y nada más. Si el texto estuviese bien, lo devuelves como está. Solo el texto.'
                'content': self._prompt_system
            },
            {
                'role': 'user',
                # 'content': 'La vida es un poco más normale cuando vivese feliz.'
                'content': prompt
            }
        ]

        request = requests.post(
            f'{self.endpoint_url}/api/chat',
            json = {
                # TODO: Change the model according to this class
                # 'model': 'gemma3',
                'model': self.model_name,
                'messages': messages,
                'stream': False,
                'options': {
                    'temperature': temperature
                }
            }
        )

        data = request.json()

        return data['message']['content']