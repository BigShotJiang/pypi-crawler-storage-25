from yta_docker_ollama.agents.stateless.abstract import StatelessAgent


class OllamaStatelessAgent(StatelessAgent):
    """
    An stateless agent based on the Ollama docker.
    """

    @property
    def endpoint_url(
        self
    ) -> str:
        return 'http://localhost:11434'