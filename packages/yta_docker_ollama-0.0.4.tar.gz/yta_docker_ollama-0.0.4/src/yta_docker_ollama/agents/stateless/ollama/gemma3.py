from yta_docker_ollama.agents.stateless.ollama import OllamaStatelessAgent


class Gemma3OllamaStatelessAgent(OllamaStatelessAgent):
    """
    An stateless agent based on `Ollama` (through local
    Docker)  and on this model:
    - `gemma3`
    """

    @property
    def model_name(
        self
    ) -> str:
        # TODO: Create enum (?)
        return 'gemma3'
    

"""
Real and useful agents below

TODO: Maybe we could create a custom class that uses
the normal methods below but actually implements new
methods (or just wraps the agent) to make it easy to
work by naming the methods '.review_text()' or
similar, instead of the '.ask()' we have for all the
agents.
"""
transcription_cleaner_agent = Gemma3OllamaStatelessAgent(
    prompt_system = 'Eres un experto en edición de texto y eres muy conciso con tus respuestas y muy profesional. A cualquier input que recibas, la única respuesta que das es el texto ya corregido. Se te va a dar un input y tienes que corregirlo. Es una transcripción de un audio, por lo que alguna palabra podría estar mal transcrita o no tener sentido, pero como eres un profesional, serás capaz de solucionarlo. Recuerda, solo da como respuesta el texto corregido directamente y nada más. Si el texto estuviese bien, lo devuelves como está. Solo el texto.'
)