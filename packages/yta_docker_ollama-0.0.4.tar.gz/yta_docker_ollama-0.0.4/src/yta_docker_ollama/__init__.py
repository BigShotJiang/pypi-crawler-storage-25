"""
This code is to be able to handle containers
and to work with the modes we make available.

We've started this project based on this:
- https://dev.to/savvasstephnds/run-deepseek-locally-using-docker-2pdm
"""