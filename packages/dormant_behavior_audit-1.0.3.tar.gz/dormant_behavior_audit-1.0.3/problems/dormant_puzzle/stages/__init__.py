"""Dormant puzzle pipeline stages."""
