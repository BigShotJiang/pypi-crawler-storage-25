# toolkitkey

Quick access to shared API keys from the command line.

## Installation

```bash
pip install toolkitkey
```

## Usage

**Show all keys:**
```bash
toolkitkey
```

**Show keys for a specific person:**
```bash
toolkitkey --key adi
toolkitkey --key AJ
```

**Check version:**
```bash
toolkitkey --version
```
