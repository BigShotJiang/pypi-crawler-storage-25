"""CLI entry point for toolkitkey."""

import argparse
import os
import sys

from . import __version__


def get_keys_content():
    """Read and return the contents of keys.txt bundled with the package."""
    keys_path = os.path.join(os.path.dirname(__file__), "keys.txt")
    with open(keys_path, "r", encoding="utf-8") as f:
        return f.read()


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="toolkitkey",
        description="Display shared API keys",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"toolkitkey {__version__}",
    )
    parser.add_argument(
        "--key",
        type=str,
        metavar="NAME",
        help="Show keys for a specific person (e.g. AJ, Anantha, adi)",
    )

    args = parser.parse_args()
    content = get_keys_content()

    if args.key:
        # Search for a specific person's keys
        found = False
        for line in content.splitlines():
            line_stripped = line.strip()
            if line_stripped.lower().startswith(args.key.lower() + "="):
                name, value = line_stripped.split("=", 1)
                print(f"{name}: {value.strip('\"')}")
                found = True
                break
        if not found:
            print(f"No keys found for '{args.key}'")
            sys.exit(1)
    else:
        # Show all keys
        print(content)


if __name__ == "__main__":
    main()
