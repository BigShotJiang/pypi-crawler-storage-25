"""Test the careerrag package."""
