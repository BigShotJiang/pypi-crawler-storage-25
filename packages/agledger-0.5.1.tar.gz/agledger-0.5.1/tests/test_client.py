"""Tests for AgledgerClient — resources, auth, context manager, typed kwargs."""

import httpx
import pytest
import respx

from agledger import AgledgerClient, AsyncAgledgerClient, Mandate, AuthenticationError


MANDATE_JSON = {
    "id": "mnd-123",
    "enterpriseId": "ent-1",
    "agentId": None,
    "contractType": "ACH-PROC-v1",
    "contractVersion": "1",
    "platform": "test",
    "status": "CREATED",
    "criteria": {"item": "widgets"},
    "submissionCount": 0,
    "maxSubmissions": None,
    "version": 1,
    "createdAt": "2026-03-16T00:00:00Z",
    "updatedAt": "2026-03-16T00:00:00Z",
}


@respx.mock
def test_mandates_create_typed_kwargs():
    respx.post("https://agledger.example.com/v1/mandates").mock(
        return_value=httpx.Response(200, json=MANDATE_JSON)
    )
    client = AgledgerClient(api_key="test-key")
    mandate = client.mandates.create(
        enterprise_id="ent-1",
        contract_type="ACH-PROC-v1",
        contract_version="1",
        platform="test",
        criteria={"item": "widgets"},
        max_submissions=3,
    )
    assert isinstance(mandate, Mandate)
    assert mandate.id == "mnd-123"
    assert mandate.status == "CREATED"
    # Verify camelCase was sent to API
    body = respx.calls[0].request.content
    import json
    sent = json.loads(body)
    assert sent["enterpriseId"] == "ent-1"
    assert sent["contractType"] == "ACH-PROC-v1"
    assert sent["maxSubmissions"] == 3


@respx.mock
def test_mandates_get():
    respx.get("https://agledger.example.com/v1/mandates/mnd-123").mock(
        return_value=httpx.Response(200, json=MANDATE_JSON)
    )
    client = AgledgerClient(api_key="test-key")
    mandate = client.mandates.get("mnd-123")
    assert mandate.id == "mnd-123"
    assert mandate.contract_type == "ACH-PROC-v1"


@respx.mock
def test_mandates_list_with_status_filter():
    respx.get("https://agledger.example.com/v1/mandates").mock(
        return_value=httpx.Response(200, json={"data": [MANDATE_JSON], "hasMore": False})
    )
    client = AgledgerClient(api_key="test-key")
    page = client.mandates.list(enterprise_id="ent-1", status="CREATED")
    assert len(page.data) == 1
    assert page.has_more is False
    assert isinstance(page.data[0], Mandate)


@respx.mock
def test_mandates_transition():
    activated = {**MANDATE_JSON, "status": "ACTIVE"}
    respx.post("https://agledger.example.com/v1/mandates/mnd-123/transition").mock(
        return_value=httpx.Response(200, json=activated)
    )
    client = AgledgerClient(api_key="test-key")
    mandate = client.mandates.transition("mnd-123", "activate")
    assert mandate.status == "ACTIVE"


@respx.mock
def test_mandates_request_revision():
    revised = {**MANDATE_JSON, "status": "REVISION_REQUESTED"}
    respx.post("https://agledger.example.com/v1/mandates/mnd-123/revision").mock(
        return_value=httpx.Response(200, json=revised)
    )
    client = AgledgerClient(api_key="test-key")
    mandate = client.mandates.request_revision("mnd-123", "please fix X")
    assert mandate.status == "REVISION_REQUESTED"


@respx.mock
def test_receipt_submit_typed_kwargs():
    receipt_json = {
        "id": "rct-1", "mandateId": "mnd-123", "agentId": "agent-1",
        "status": "SUBMITTED", "evidence": {"delivered": True},
        "createdAt": "2026-03-16T00:00:00Z",
    }
    respx.post("https://agledger.example.com/v1/mandates/mnd-123/receipts").mock(
        return_value=httpx.Response(200, json=receipt_json)
    )
    client = AgledgerClient(api_key="test-key")
    receipt = client.receipts.submit("mnd-123", evidence={"delivered": True})
    assert receipt.id == "rct-1"


@respx.mock
def test_auth_header():
    route = respx.get("https://agledger.example.com/v1/mandates/mnd-123").mock(
        return_value=httpx.Response(200, json=MANDATE_JSON)
    )
    client = AgledgerClient(api_key="ach_ent_test123")
    client.mandates.get("mnd-123")
    assert route.calls[0].request.headers["authorization"] == "Bearer ach_ent_test123"


@respx.mock
def test_user_agent_header():
    route = respx.get("https://agledger.example.com/v1/mandates/mnd-123").mock(
        return_value=httpx.Response(200, json=MANDATE_JSON)
    )
    client = AgledgerClient(api_key="test-key")
    client.mandates.get("mnd-123")
    assert "agledger-python/" in route.calls[0].request.headers["user-agent"]


@respx.mock
def test_idempotency_key_on_post():
    route = respx.post("https://agledger.example.com/v1/mandates").mock(
        return_value=httpx.Response(200, json=MANDATE_JSON)
    )
    client = AgledgerClient(api_key="test-key")
    client.mandates.create(enterprise_id="e", contract_type="ACH-PROC-v1", contract_version="1", platform="t", criteria={})
    assert "idempotency-key" in route.calls[0].request.headers


@respx.mock
def test_no_idempotency_key_on_get():
    route = respx.get("https://agledger.example.com/v1/mandates/mnd-123").mock(
        return_value=httpx.Response(200, json=MANDATE_JSON)
    )
    client = AgledgerClient(api_key="test-key")
    client.mandates.get("mnd-123")
    assert "idempotency-key" not in route.calls[0].request.headers


@respx.mock
def test_no_content_type_on_get():
    route = respx.get("https://agledger.example.com/v1/mandates/mnd-123").mock(
        return_value=httpx.Response(200, json=MANDATE_JSON)
    )
    client = AgledgerClient(api_key="test-key")
    client.mandates.get("mnd-123")
    assert "content-type" not in route.calls[0].request.headers


@respx.mock
def test_context_manager():
    respx.get("https://agledger.example.com/v1/mandates/mnd-123").mock(
        return_value=httpx.Response(200, json=MANDATE_JSON)
    )
    with AgledgerClient(api_key="test-key") as client:
        mandate = client.mandates.get("mnd-123")
        assert mandate.id == "mnd-123"


def test_env_var_fallback(monkeypatch):
    monkeypatch.setenv("AGLEDGER_API_KEY", "ach_ent_from_env")
    client = AgledgerClient()
    # Client should have been created successfully with env var
    assert client._http._api_key == "ach_ent_from_env"


def test_no_api_key_raises(monkeypatch):
    monkeypatch.delenv("AGLEDGER_API_KEY", raising=False)
    with pytest.raises(AuthenticationError, match="No API key"):
        AgledgerClient()


@respx.mock
def test_populate_by_name():
    """Verify Pydantic models can be constructed with snake_case names."""
    m = Mandate(
        id="mnd-1",
        enterprise_id="ent-1",
        contract_type="ACH-PROC-v1",
        contract_version="1",
        platform="test",
        status="CREATED",
        criteria={},
        submission_count=0,
        max_submissions=None,
        version=1,
        created_at="2026-01-01T00:00:00Z",
        updated_at="2026-01-01T00:00:00Z",
    )
    assert m.enterprise_id == "ent-1"
    assert m.contract_type == "ACH-PROC-v1"
    assert m.submission_count == 0


@respx.mock
def test_has_18_resources():
    """Verify client has all 18 resource sub-clients."""
    client = AgledgerClient(api_key="test-key")
    resources = [
        "mandates", "receipts", "verification", "disputes", "webhooks",
        "reputation", "events", "schemas", "dashboard", "compliance",
        "registration", "health", "admin", "a2a", "capabilities",
        "notarize", "enterprises",
    ]
    for r in resources:
        assert hasattr(client, r), f"Missing resource: {r}"


# --- Admin provisioning tests ---

@respx.mock
def test_admin_create_enterprise():
    response_json = {"id": "ent-1", "name": "Acme Corp", "slug": "acme-corp"}
    respx.post("https://agledger.example.com/v1/admin/enterprises").mock(
        return_value=httpx.Response(200, json=response_json)
    )
    client = AgledgerClient(api_key="test-key")
    result = client.admin.create_enterprise(name="Acme Corp", slug="acme-corp")
    assert result["id"] == "ent-1"
    assert result["slug"] == "acme-corp"
    import json
    sent = json.loads(respx.calls[0].request.content)
    assert sent["name"] == "Acme Corp"
    assert sent["slug"] == "acme-corp"


@respx.mock
def test_admin_create_agent():
    response_json = {"id": "agt-1", "name": "My Agent", "slug": "my-agent", "enterpriseId": "ent-1"}
    respx.post("https://agledger.example.com/v1/admin/agents").mock(
        return_value=httpx.Response(200, json=response_json)
    )
    client = AgledgerClient(api_key="test-key")
    result = client.admin.create_agent(name="My Agent", slug="my-agent", enterprise_id="ent-1")
    assert result["id"] == "agt-1"
    assert result["slug"] == "my-agent"
    import json
    sent = json.loads(respx.calls[0].request.content)
    assert sent["enterpriseId"] == "ent-1"


@respx.mock
def test_admin_set_enterprise_config():
    config = {"agentApprovalRequired": True, "allowSelfApproval": False}
    respx.put("https://agledger.example.com/v1/admin/enterprises/ent-1/config").mock(
        return_value=httpx.Response(200, json=config)
    )
    client = AgledgerClient(api_key="test-key")
    result = client.admin.set_enterprise_config("ent-1", config)
    assert result["agentApprovalRequired"] is True


@respx.mock
def test_webhooks_list_url_filter():
    respx.get("https://agledger.example.com/v1/webhooks").mock(
        return_value=httpx.Response(200, json={"data": [], "hasMore": False})
    )
    client = AgledgerClient(api_key="test-key")
    page = client.webhooks.list(url="https://example.com/hook")
    assert page.data == []
    # Verify URL param was sent
    request_url = str(respx.calls[0].request.url)
    assert "url=https" in request_url


# --- Async tests ---

@respx.mock
@pytest.mark.asyncio
async def test_async_mandates_get():
    respx.get("https://agledger.example.com/v1/mandates/mnd-123").mock(
        return_value=httpx.Response(200, json=MANDATE_JSON)
    )
    async with AsyncAgledgerClient(api_key="test-key") as client:
        mandate = await client.mandates.get("mnd-123")
        assert mandate.id == "mnd-123"
        assert isinstance(mandate, Mandate)


@respx.mock
@pytest.mark.asyncio
async def test_async_context_manager():
    respx.get("https://agledger.example.com/v1/mandates/mnd-123").mock(
        return_value=httpx.Response(200, json=MANDATE_JSON)
    )
    async with AsyncAgledgerClient(api_key="test-key") as client:
        mandate = await client.mandates.get("mnd-123")
        assert mandate.id == "mnd-123"


# --- Admin API key tests ---

@respx.mock
def test_admin_toggle_api_key():
    response_json = {"id": "key-1", "isActive": True}
    respx.patch("https://agledger.example.com/v1/admin/api-keys/key-1").mock(
        return_value=httpx.Response(200, json=response_json)
    )
    client = AgledgerClient(api_key="test-key")
    result = client.admin.toggle_api_key("key-1", is_active=True)
    assert result["isActive"] is True
    import json
    sent = json.loads(respx.calls[0].request.content)
    assert sent["isActive"] is True


# --- Admin: rate limit exemptions, webhook health, circuit breaker ---


@respx.mock
def test_admin_list_rate_limit_exemptions():
    respx.get("https://agledger.example.com/v1/admin/rate-limit-exemptions/ips").mock(
        return_value=httpx.Response(200, json={"data": ["10.0.0.1"], "total": 1, "hasMore": False})
    )
    client = AgledgerClient(api_key="test-key")
    result = client.admin.list_rate_limit_exemptions()
    assert result["data"] == ["10.0.0.1"]


@respx.mock
def test_admin_set_rate_limit_exemption():
    respx.put("https://agledger.example.com/v1/admin/rate-limit-exemptions/ip/10.0.0.1").mock(
        return_value=httpx.Response(200, json={"ip": "10.0.0.1", "exempt": True})
    )
    client = AgledgerClient(api_key="test-key")
    result = client.admin.set_rate_limit_exemption("10.0.0.1")
    assert result["exempt"] is True


@respx.mock
def test_admin_delete_rate_limit_exemption():
    respx.delete("https://agledger.example.com/v1/admin/rate-limit-exemptions/ip/10.0.0.1").mock(
        return_value=httpx.Response(200, json={"ip": "10.0.0.1", "exempt": False})
    )
    client = AgledgerClient(api_key="test-key")
    result = client.admin.delete_rate_limit_exemption("10.0.0.1")
    assert result["exempt"] is False


@respx.mock
def test_admin_get_webhook_health():
    respx.get("https://agledger.example.com/v1/admin/webhooks/health").mock(
        return_value=httpx.Response(200, json={"data": [{"id": "wh-1", "circuitState": "closed"}], "total": 1})
    )
    client = AgledgerClient(api_key="test-key")
    result = client.admin.get_webhook_health()
    assert result["data"][0]["circuitState"] == "closed"


@respx.mock
def test_admin_update_circuit_breaker():
    respx.patch("https://agledger.example.com/v1/admin/webhooks/wh-1/circuit-breaker").mock(
        return_value=httpx.Response(200, json={"id": "wh-1", "circuitState": "open", "consecutiveFailures": 5})
    )
    client = AgledgerClient(api_key="test-key")
    result = client.admin.update_circuit_breaker("wh-1", state="open")
    assert result["circuitState"] == "open"
    import json
    sent = json.loads(respx.calls[0].request.content)
    assert sent["state"] == "open"


# --- Webhook get / pause tests ---

@respx.mock
def test_webhooks_get():
    webhook_json = {
        "id": "wh-1", "url": "https://example.com/hook",
        "eventTypes": ["mandate.created"], "status": "active",
        "isActive": True, "createdAt": "2026-01-01T00:00:00Z",
    }
    respx.get("https://agledger.example.com/v1/webhooks/wh-1").mock(
        return_value=httpx.Response(200, json=webhook_json)
    )
    client = AgledgerClient(api_key="test-key")
    webhook = client.webhooks.get("wh-1")
    assert webhook.id == "wh-1"
    assert webhook.url == "https://example.com/hook"


@respx.mock
def test_webhooks_pause():
    webhook_json = {
        "id": "wh-1", "url": "https://example.com/hook",
        "eventTypes": ["mandate.created"], "status": "paused",
        "isActive": False, "createdAt": "2026-01-01T00:00:00Z",
    }
    respx.post("https://agledger.example.com/v1/webhooks/wh-1/pause").mock(
        return_value=httpx.Response(200, json=webhook_json)
    )
    client = AgledgerClient(api_key="test-key")
    webhook = client.webhooks.pause("wh-1")
    assert webhook.id == "wh-1"
    assert webhook.status == "paused"


# --- Mandate counter_propose and batch_get tests ---


@respx.mock
def test_mandates_counter_propose():
    counter_json = {**MANDATE_JSON, "status": "PROPOSED", "acceptanceStatus": "COUNTER_PROPOSED"}
    respx.post("https://agledger.example.com/v1/mandates/mnd-123/counter-propose").mock(
        return_value=httpx.Response(200, json=counter_json)
    )
    client = AgledgerClient(api_key="test-key")
    mandate = client.mandates.counter_propose("mnd-123", counter_deadline="2026-06-01T00:00:00Z")
    assert isinstance(mandate, Mandate)
    assert mandate.acceptance_status == "COUNTER_PROPOSED"
    import json
    sent = json.loads(respx.calls[0].request.content)
    assert sent["counterDeadline"] == "2026-06-01T00:00:00Z"


@respx.mock
def test_mandates_batch_get():
    batch_response = {"data": [MANDATE_JSON, {**MANDATE_JSON, "id": "mnd-456"}]}
    respx.post("https://agledger.example.com/v1/mandates/batch").mock(
        return_value=httpx.Response(200, json=batch_response)
    )
    client = AgledgerClient(api_key="test-key")
    result = client.mandates.batch_get(["mnd-123", "mnd-456"])
    assert len(result["data"]) == 2
    import json
    sent = json.loads(respx.calls[0].request.content)
    assert sent["ids"] == ["mnd-123", "mnd-456"]
