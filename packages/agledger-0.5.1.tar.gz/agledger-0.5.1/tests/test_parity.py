"""
SDK ↔ API Parity Test (Python)

Validates that every Python SDK resource method maps to a real API route.
Uses the same route manifest (routes.json) as the TypeScript SDK parity test,
shared via the TS SDK's __tests__ directory.

To update the manifest (shared across both SDKs):
    cd ~/projects/agledger-api && npx tsx scripts/generate-route-manifest.ts
    cp dist/routes.json ~/projects/agledger-agents/agledger-sdk/src/__tests__/routes.json

This test is the Python mirror of
`agledger-sdk/src/__tests__/parity.test.ts`.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest

# Shared manifest location — one file, both SDKs.
_MANIFEST_PATH = (
    Path(__file__).resolve().parent.parent.parent
    / "agledger-sdk"
    / "src"
    / "__tests__"
    / "routes.json"
)


@pytest.fixture(scope="module")
def route_map() -> dict[str, dict[str, Any]]:
    """Return a METHOD + path → route entry dict.

    The manifest lives in the sibling agledger-sdk monorepo package; when this
    SDK is consumed standalone (via PyPI or the public sdk-python repo), skip
    the parity suite so it only runs inside the monorepo.
    """
    if not _MANIFEST_PATH.exists():
        pytest.skip(f"Route manifest not available at {_MANIFEST_PATH} (skip in standalone checkout)")
    manifest = json.loads(_MANIFEST_PATH.read_text())
    return {f"{r['method']} {r['path']}": r for r in manifest["routes"]}


# ---------------------------------------------------------------------------
# SDK method → API route map
#
# Entries: (resource, python_method, http_method, api_path).
# Paths use the OpenAPI spec convention (no /v1/ prefix — the API's OpenAPI
# server base is /v1, so paths are relative). Health endpoints sit at root,
# so they keep their literal /health, /status paths.
#
# We only enumerate methods that wrap a single HTTP call — multi-call
# convenience helpers (create_and_activate, formalize_sidecar_mandate, etc.)
# are excluded because they reuse other methods that are already covered.
# ---------------------------------------------------------------------------

SDK_METHODS: list[tuple[str, str, str, str]] = [
    # Mandates
    ("mandates", "create", "POST", "/mandates"),
    ("mandates", "create_agent", "POST", "/mandates/agent"),
    ("mandates", "get", "GET", "/mandates/{id}"),
    ("mandates", "list", "GET", "/mandates"),
    ("mandates", "search", "GET", "/mandates/search"),
    ("mandates", "update", "PATCH", "/mandates/{id}"),
    ("mandates", "transition", "POST", "/mandates/{id}/transition"),
    ("mandates", "accept", "POST", "/mandates/{id}/accept"),
    ("mandates", "reject", "POST", "/mandates/{id}/reject"),
    ("mandates", "counter_propose", "POST", "/mandates/{id}/counter-propose"),
    ("mandates", "accept_counter", "POST", "/mandates/{id}/accept-counter"),
    ("mandates", "batch_get", "POST", "/mandates/batch"),
    ("mandates", "get_chain", "GET", "/mandates/{id}/chain"),
    ("mandates", "get_sub_mandates", "GET", "/mandates/{id}/sub-mandates"),
    ("mandates", "get_audit", "GET", "/mandates/{mandateId}/audit"),
    ("mandates", "get_graph", "GET", "/mandates/{id}/graph"),
    ("mandates", "bulk_create", "POST", "/mandates/bulk"),
    ("mandates", "list_as_principal", "GET", "/mandates/agent/principal"),
    ("mandates", "list_proposals", "GET", "/mandates/agent/proposals"),
    ("mandates", "request_revision", "POST", "/mandates/{id}/revision"),
    ("mandates", "report_outcome", "POST", "/mandates/{id}/outcome"),
    ("mandates", "get_summary", "GET", "/mandates/summary"),
    # Receipts
    ("receipts", "submit", "POST", "/mandates/{mandateId}/receipts"),
    ("receipts", "get", "GET", "/mandates/{mandateId}/receipts/{receiptId}"),
    ("receipts", "list", "GET", "/mandates/{mandateId}/receipts"),
    # Webhooks
    ("webhooks", "create", "POST", "/webhooks"),
    ("webhooks", "get", "GET", "/webhooks/{webhookId}"),
    ("webhooks", "list", "GET", "/webhooks"),
    ("webhooks", "update", "PATCH", "/webhooks/{webhookId}"),
    ("webhooks", "delete", "DELETE", "/webhooks/{webhookId}"),
    ("webhooks", "rotate", "POST", "/webhooks/{webhookId}/rotate"),
    ("webhooks", "ping", "POST", "/webhooks/{webhookId}/ping"),
    ("webhooks", "pause", "POST", "/webhooks/{webhookId}/pause"),
    ("webhooks", "resume", "POST", "/webhooks/{webhookId}/resume"),
    # Disputes
    ("disputes", "create", "POST", "/mandates/{mandateId}/dispute"),
    ("disputes", "get", "GET", "/mandates/{mandateId}/dispute"),
    # Health (root paths, not under /v1)
    ("health", "check", "GET", "/health"),
    ("health", "status", "GET", "/status"),
    # Reputation
    ("reputation", "get", "GET", "/agents/{agentId}/reputation"),
    # Events
    ("events", "list", "GET", "/events"),
    # Schemas
    ("schemas", "list", "GET", "/schemas"),
    ("schemas", "get", "GET", "/schemas/{contractType}"),
    ("schemas", "get_version", "GET", "/schemas/{contractType}/versions/{version}"),
    # Capabilities
    ("capabilities", "set", "PUT", "/agents/{agentId}/capabilities"),
    ("capabilities", "get", "GET", "/agents/{agentId}/capabilities"),
    # Proxy
    ("proxy", "create_session", "POST", "/proxy/sessions"),
    ("proxy", "get_session", "GET", "/proxy/sessions/{sessionId}"),
    ("proxy", "list_sessions", "GET", "/proxy/sessions"),
    ("proxy", "sync_session", "POST", "/proxy/sync"),
    ("proxy", "ingest_tool_calls", "POST", "/proxy/sessions/{sessionId}/tool-calls"),
    ("proxy", "ingest_sidecar_mandates", "POST", "/proxy/sessions/{sessionId}/sidecar-mandates"),
    ("proxy", "ingest_sidecar_receipts", "POST", "/proxy/sessions/{sessionId}/sidecar-receipts"),
    # Compliance (per-mandate records + compliance export flow)
    ("compliance", "create_record", "POST", "/mandates/{mandateId}/compliance-records"),
    ("compliance", "list_records", "GET", "/mandates/{mandateId}/compliance-records"),
    ("compliance", "export_mandate", "POST", "/compliance/export"),
]


# ---------------------------------------------------------------------------
# Parity assertions
# ---------------------------------------------------------------------------


def _route_variants(path: str) -> list[str]:
    """Return plausible path variants. Health/root endpoints stay literal;
    versioned endpoints may appear with or without a /v1 prefix depending on
    how the OpenAPI manifest was generated."""
    return [path, f"/v1{path}"] if not path.startswith(("/health", "/status")) else [path]


@pytest.mark.parametrize("resource,method,http,path", SDK_METHODS)
def test_sdk_method_maps_to_api_route(
    route_map: dict[str, dict[str, Any]],
    resource: str,
    method: str,
    http: str,
    path: str,
) -> None:
    """Every SDK method must target a real API route in the manifest."""
    keys = [f"{http} {p}" for p in _route_variants(path)]
    matched = [k for k in keys if k in route_map]
    assert matched, (
        f"SDK method {resource}.{method} targets {http} {path}, but no matching "
        f"route exists in the manifest. Tried: {keys}"
    )


def test_webhook_create_requires_event_types(
    route_map: dict[str, dict[str, Any]],
) -> None:
    """Regression guard for F-379: webhook create must require eventTypes, not events."""
    entry = route_map.get("POST /webhooks") or route_map.get("POST /v1/webhooks")
    assert entry is not None, "POST /webhooks route missing from manifest"
    required = entry["requiredFields"]
    assert "eventTypes" in required, f"Expected eventTypes required; got {required}"
    assert "events" not in required, f"Unexpected legacy 'events' field in required: {required}"


def test_capabilities_uses_put(route_map: dict[str, dict[str, Any]]) -> None:
    """Regression guard: capabilities.set() must use PUT (replace), not PATCH."""
    assert ("PUT /agents/{agentId}/capabilities" in route_map) or (
        "PUT /v1/agents/{agentId}/capabilities" in route_map
    ), "Expected PUT /agents/{agentId}/capabilities in manifest"
