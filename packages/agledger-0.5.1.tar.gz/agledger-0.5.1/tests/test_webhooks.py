"""Tests for webhook signature verification."""

import json
import time
import pytest

from agledger import SignatureVerificationError
from agledger.webhooks import sign_payload, verify_signature, construct_event


SECRET = "whsec_test_secret_key"
BODY = json.dumps({"type": "mandate.created", "data": {"id": "mnd-123"}, "timestamp": "2026-03-16T00:00:00Z", "id": "evt-1"})


def test_sign_and_verify():
    result = sign_payload(BODY, SECRET)
    assert verify_signature(BODY, result["header"], SECRET)


def test_wrong_body():
    result = sign_payload(BODY, SECRET)
    assert not verify_signature("wrong body", result["header"], SECRET)


def test_wrong_secret():
    result = sign_payload(BODY, SECRET)
    assert not verify_signature(BODY, result["header"], "wrong_secret")


def test_expired_signature():
    old_ts = int(time.time()) - 600
    result = sign_payload(BODY, SECRET, old_ts)
    assert not verify_signature(BODY, result["header"], SECRET)


def test_key_rotation():
    result = sign_payload(BODY, SECRET)
    assert verify_signature(BODY, result["header"], ["old_secret", SECRET, "new_secret"])


def test_tolerance_cap():
    old_ts = int(time.time()) - 400
    result = sign_payload(BODY, SECRET, old_ts)
    # Even with 600s tolerance, should be capped at 300
    assert not verify_signature(BODY, result["header"], SECRET, tolerance_seconds=600)


def test_construct_event():
    result = sign_payload(BODY, SECRET)
    event = construct_event(BODY, result["header"], SECRET)
    assert event["type"] == "mandate.created"
    assert event["data"]["id"] == "mnd-123"
    assert event["id"] == "evt-1"


def test_construct_event_bad_signature():
    result = sign_payload(BODY, "wrong_secret")
    with pytest.raises(SignatureVerificationError, match="verification failed") as exc_info:
        construct_event(BODY, result["header"], SECRET)
    assert exc_info.value.payload == BODY.encode()
