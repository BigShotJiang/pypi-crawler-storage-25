# AGLedger Python SDK

Accountability and audit infrastructure for agentic systems. Self-hosted.

## Install

```bash
pip install agledger
```

## Quick Start

```python
import os
from agledger import AgledgerClient

client = AgledgerClient(
    api_key=os.environ["AGLEDGER_API_KEY"],
    base_url=os.environ["AGLEDGER_EXTERNAL_URL"],  # your AGLedger instance URL
)

# Create a mandate
mandate = client.mandates.create(
    enterprise_id="ent_123",
    contract_type="ACH-PROC-v1",
    contract_version="1",
    platform="internal",
    criteria={"item": "widgets", "max_quantity": 100},
)

# Activate it
client.mandates.transition(mandate.id, "activate")

# Submit a receipt
receipt = client.receipts.submit(mandate.id, evidence={"quantity": 95, "vendor": "acme"})

# Verify
result = client.verification.verify(mandate.id)
```

## Configuration

```python
client = AgledgerClient(
    api_key="ach_ent_...",                              # or set AGLEDGER_API_KEY env var
    base_url="https://agledger.internal.example.com",   # your instance URL
    max_retries=2,                                      # default: 2
    timeout=30.0,                                       # default: 30s
)
```

## Async Support

```python
from agledger import AsyncAgledgerClient

async with AsyncAgledgerClient() as client:
    mandate = await client.mandates.get("mnd-123")
```

## Resources

23 resource sub-clients: `mandates`, `receipts`, `verification`, `disputes`, `webhooks`, `reputation`, `events`, `schemas`, `dashboard`, `compliance`, `registration`, `health`, `admin`, `a2a`, `capabilities`, `notarize`, `enterprises`, `projects`, `proxy`, `federation`, `federation_admin`, `agents`, `references`.

## Offline Audit Export Verification

Verify a mandate's hash-chained, Ed25519-signed audit export without calling the API:

```python
from agledger.verify import verify_export

export_data = client.compliance.export_mandate("MND_123")
result = verify_export(export_data)

if not result.valid:
    print(f"Broken at position {result.broken_at.position}: {result.broken_at.reason}")
# VerifyExportResult(valid=True, verified_entries=12, total_entries=12, ...)
```

Requires the `cryptography` package for Ed25519 verification:

```bash
pip install 'agledger[verify]'
```

Re-implements the vault's integrity check (RFC 8785 JCS → SHA-256 → Ed25519 over
`{position}:{payloadHash}:{previousHash}`). Pass `public_keys={...}` to override
the export's embedded keys, or `require_key_id="key-id"` to reject exports signed
by an unexpected key.

## Licensing

AGLedger is **free for single-node deployments** (Docker Compose with bundled database). An Enterprise License is required for external database connections, federation, and multi-node deployments.

Full details: [agledger.ai/pricing](https://agledger.ai/pricing) | [License Agreement](https://agledger.ai/license)

## SDK License

Proprietary. Copyright (c) 2026 AGLedger LLC. All rights reserved.
