# Changelog

All notable changes to the AGLedger Python SDK will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/), and this project adheres to [Semantic Versioning](https://semver.org/).

## [0.1.0] - 2026-04-02

### Added
- `AgledgerClient` (sync) and `AsyncAgledgerClient` (async) with 23 resource sub-clients each
- Full error hierarchy: `APIError`, `AuthenticationError`, `PermissionDeniedError` (with `missing_scopes`), `NotFoundError`, `BadRequestError`, `ConflictError`, `UnprocessableError`, `RateLimitError`, `APIConnectionError`, `APITimeoutError`, `SignatureVerificationError`
- `doc_url` and `suggestion` on all API errors
- Auto-pagination via generators (`list_all()` methods)
- Retry with exponential backoff + jitter, respects `Retry-After`
- Auto-generated idempotency keys on mutations
- Webhook signature verification via `agledger.webhooks`
- Context manager support (`with AgledgerClient() as client:`)
- Environment variable fallback (`AGLEDGER_API_KEY`)
- Typed kwargs on core resources (mandates, receipts) with full IDE autocomplete
- 11 Pydantic v2 models: AgentProfile, VerificationStatus, WebhookTestResult, DashboardStats, DashboardAlert, DashboardAgent, Project, AgentCapabilities, ComplianceExport, AiImpactAssessment, EuAiActReport
- `py.typed` marker for PEP 561 compliance
- 101 tests (pytest + respx) with async coverage
- SECURITY.md with CVE disclosure policy

### Technical
- Python >=3.10
- Dependencies: httpx >=0.27.0, pydantic >=2.0.0
- Pydantic v2 models with `populate_by_name=True` and `extra="allow"` for forward compatibility
- Modern union syntax (`X | None`) throughout
