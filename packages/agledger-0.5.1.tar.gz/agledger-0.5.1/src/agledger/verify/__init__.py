"""
AGLedger SDK — Offline audit export verification.

Usage::

    from agledger.verify import verify_export

    with open("audit-export.json") as f:
        data = json.load(f)
    result = verify_export(data)
    if not result.valid:
        print(f"Broken at position {result.broken_at.position}: {result.broken_at.reason}")

Requires the ``cryptography`` package for Ed25519 verification. Install via
``pip install 'agledger[verify]'``.
"""

from agledger.verify.verify_export import (
    canonicalize,
    verify_export,
    EntryVerificationResult,
    VerifyExportResult,
    BrokenAt,
)

__all__ = [
    "verify_export",
    "canonicalize",
    "EntryVerificationResult",
    "VerifyExportResult",
    "BrokenAt",
]
