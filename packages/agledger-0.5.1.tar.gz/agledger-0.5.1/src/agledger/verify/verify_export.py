"""
Offline verification of AGLedger audit exports.

Independently re-implements the vault's per-entry integrity check
(RFC 8785 JCS → SHA-256 → Ed25519 over ``{position}:{payloadHash}:{previousHash}``)
and walks the hash chain. Makes no network calls.

This module mirrors the TypeScript SDK's ``@agledger/sdk/verify`` and is validated
against the same shared test vectors under ``testdata/verifier/``.
"""

from __future__ import annotations

import base64
import hashlib
import json
from dataclasses import dataclass, field
from typing import Any, Literal, Mapping

try:
    from cryptography.exceptions import InvalidSignature as _InvalidSignature
    from cryptography.hazmat.primitives.serialization import (
        load_der_public_key as _load_der_public_key,
    )
    _CRYPTO_IMPORT_ERROR: Exception | None = None
except ImportError as _err:
    _InvalidSignature = None  # type: ignore[assignment,misc]
    _load_der_public_key = None  # type: ignore[assignment]
    _CRYPTO_IMPORT_ERROR = _err

EntryFailureReason = Literal[
    "payload_hash_mismatch",
    "chain_break",
    "position_gap",
    "signature_invalid",
    "unknown_key",
    "malformed_entry",
    "unsupported_algorithm",
]

_RFC8785 = "RFC8785"
_SUPPORTED_HASH = {"SHA-256", "sha-256", "sha256"}
_SUPPORTED_SIG = {"Ed25519", "ed25519"}


@dataclass
class EntryVerificationResult:
    position: int
    valid: bool
    reason: EntryFailureReason | None = None
    detail: str | None = None


@dataclass
class BrokenAt:
    position: int
    reason: EntryFailureReason
    detail: str | None = None


@dataclass
class VerifyExportResult:
    valid: bool
    total_entries: int
    verified_entries: int
    mandate_id: str
    entries: list[EntryVerificationResult] = field(default_factory=list)
    broken_at: BrokenAt | None = None


def verify_export(
    export_data: Mapping[str, Any],
    *,
    public_keys: Mapping[str, str] | None = None,
    require_key_id: str | None = None,
) -> VerifyExportResult:
    """Verify a mandate audit export offline.

    :param export_data: The parsed export JSON (from ``client.compliance.export_mandate()``).
    :param public_keys: Optional map of keyId → SPKI DER base64 public key, merged
        over any keys embedded in the export.
    :param require_key_id: If set, every entry must reference this keyId.
    :returns: A :class:`VerifyExportResult` with per-entry outcomes.
    """
    meta = export_data.get("exportMetadata", {})
    entries = export_data.get("entries", []) or []
    mandate_id = str(meta.get("mandateId", ""))
    keys = _KeyCache(_resolve_keys(meta, public_keys))

    canonicalization = meta.get("canonicalization")
    if canonicalization and canonicalization != _RFC8785:
        detail = f"Unsupported canonicalization: {canonicalization} (only RFC8785 supported)"
        return VerifyExportResult(
            valid=False,
            total_entries=len(entries),
            verified_entries=0,
            mandate_id=mandate_id,
            entries=[
                EntryVerificationResult(
                    position=0,
                    valid=False,
                    reason="unsupported_algorithm",
                    detail=detail,
                )
            ],
            broken_at=BrokenAt(position=0, reason="unsupported_algorithm", detail=detail),
        )

    entry_results: list[EntryVerificationResult] = []
    verified = 0
    broken_at: BrokenAt | None = None
    prev_payload_hash: str | None = None

    for i, entry in enumerate(entries):
        result = _verify_entry(entry, i + 1, prev_payload_hash, keys, require_key_id)
        entry_results.append(result)
        if result.valid:
            verified += 1
        elif broken_at is None and result.reason is not None:
            broken_at = BrokenAt(position=result.position, reason=result.reason, detail=result.detail)
        prev_payload_hash = entry.get("integrity", {}).get("payloadHash")

    return VerifyExportResult(
        valid=(verified == len(entries) and len(entries) > 0),
        total_entries=len(entries),
        verified_entries=verified,
        mandate_id=mandate_id,
        entries=entry_results,
        broken_at=broken_at,
    )


def _resolve_keys(
    meta: Mapping[str, Any],
    overrides: Mapping[str, str] | None,
) -> dict[str, str]:
    keys: dict[str, str] = {}
    embedded = meta.get("signingPublicKeys")
    if isinstance(embedded, Mapping):
        for k, v in embedded.items():
            keys[str(k)] = str(v)
    if overrides:
        for k, v in overrides.items():
            keys[str(k)] = str(v)
    return keys


class _KeyCache:
    """Lazily decodes SPKI DER base64 public keys and caches them.

    Large exports (10k+ entries) would otherwise re-decode the same key on
    every signature check.
    """

    def __init__(self, spki: Mapping[str, str]) -> None:
        self._spki = dict(spki)
        self._cache: dict[str, Any] = {}

    def get(self, key_id: str) -> Any | None:
        if key_id in self._cache:
            return self._cache[key_id]
        raw = self._spki.get(key_id)
        if raw is None:
            return None
        if _load_der_public_key is None:
            raise RuntimeError(
                "The 'cryptography' package is required for audit verification. "
                "Install via: pip install 'agledger[verify]'"
            ) from _CRYPTO_IMPORT_ERROR
        public_key = _load_der_public_key(base64.b64decode(raw))
        self._cache[key_id] = public_key
        return public_key


def _verify_entry(
    entry: Mapping[str, Any],
    expected_position: int,
    expected_prev_hash: str | None,
    keys: _KeyCache,
    require_key_id: str | None,
) -> EntryVerificationResult:
    position = int(entry.get("position", -1))
    integrity = entry.get("integrity") or {}

    if position != expected_position:
        return EntryVerificationResult(
            position=position,
            valid=False,
            reason="position_gap",
            detail=f"Expected position {expected_position}, got {position}",
        )

    hash_alg = integrity.get("hashAlg")
    if hash_alg and hash_alg not in _SUPPORTED_HASH:
        return EntryVerificationResult(
            position=position,
            valid=False,
            reason="unsupported_algorithm",
            detail=f"hashAlg={hash_alg}",
        )

    signature_alg = integrity.get("signatureAlg")
    if signature_alg and signature_alg not in _SUPPORTED_SIG:
        return EntryVerificationResult(
            position=position,
            valid=False,
            reason="unsupported_algorithm",
            detail=f"signatureAlg={signature_alg}",
        )

    payload_hash: str | None = integrity.get("payloadHash")
    previous_hash: str | None = integrity.get("previousHash")
    signature: str | None = integrity.get("signature")
    signing_key_id: str | None = integrity.get("signingKeyId")

    if previous_hash != expected_prev_hash:
        return EntryVerificationResult(
            position=position,
            valid=False,
            reason="chain_break",
            detail=(
                f"Expected previousHash={expected_prev_hash or 'null'}, "
                f"got {previous_hash or 'null'}"
            ),
        )

    recomputed = hashlib.sha256(canonicalize(entry.get("payload")).encode()).hexdigest()
    if recomputed != payload_hash:
        return EntryVerificationResult(
            position=position,
            valid=False,
            reason="payload_hash_mismatch",
            detail=f"Recomputed {recomputed[:16]}…, stored {(payload_hash or '')[:16]}…",
        )

    if not signature or not signing_key_id:
        return EntryVerificationResult(
            position=position,
            valid=False,
            reason="malformed_entry",
            detail="Missing signature or signingKeyId",
        )

    if require_key_id and signing_key_id != require_key_id:
        return EntryVerificationResult(
            position=position,
            valid=False,
            reason="unknown_key",
            detail=f"Entry keyId={signing_key_id} does not match requireKeyId={require_key_id}",
        )

    public_key = keys.get(signing_key_id)
    if public_key is None:
        return EntryVerificationResult(
            position=position,
            valid=False,
            reason="unknown_key",
            detail=f"No public key for keyId={signing_key_id}",
        )

    sign_input = f"{position}:{payload_hash}:{previous_hash or 'null'}"
    try:
        if not _verify_ed25519(public_key, sign_input, signature):
            return EntryVerificationResult(position=position, valid=False, reason="signature_invalid")
    except Exception as err:
        return EntryVerificationResult(
            position=position,
            valid=False,
            reason="signature_invalid",
            detail=f"Signature verification raised: {err}",
        )

    return EntryVerificationResult(position=position, valid=True)


def canonicalize(value: Any) -> str:
    """RFC 8785 JSON Canonicalization Scheme.

    Sorts object keys lexicographically, preserves array order, uses compact
    separators, and delegates primitive formatting to :func:`json.dumps`.
    """
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return json.dumps(value)
    if isinstance(value, str):
        return json.dumps(value, ensure_ascii=False)
    if isinstance(value, (list, tuple)):
        return "[" + ",".join(canonicalize(v) for v in value) + "]"
    if isinstance(value, Mapping):
        items = sorted(((str(k), v) for k, v in value.items()), key=lambda kv: kv[0])
        return "{" + ",".join(json.dumps(k, ensure_ascii=False) + ":" + canonicalize(v) for k, v in items) + "}"
    return "null"


def _verify_ed25519(public_key: Any, message: str, signature_hex: str) -> bool:
    if _InvalidSignature is None:
        raise RuntimeError(
            "The 'cryptography' package is required for audit verification. "
            "Install via: pip install 'agledger[verify]'"
        ) from _CRYPTO_IMPORT_ERROR
    try:
        public_key.verify(bytes.fromhex(signature_hex), message.encode())
        return True
    except _InvalidSignature:
        return False
