"""Disputes resource."""

from __future__ import annotations

from typing import Any

from agledger._http import AsyncHttpClient, HttpClient
from agledger.types import Dispute


class DisputesResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def create(self, mandate_id: str, *, grounds: str, context: str | None = None) -> Dispute:
        body: dict[str, Any] = {"grounds": grounds}
        if context is not None:
            body["context"] = context
        return Dispute.model_validate(self._http.post(f"/v1/mandates/{mandate_id}/dispute", json=body))

    def get(self, mandate_id: str) -> Dispute:
        return Dispute.model_validate(self._http.get(f"/v1/mandates/{mandate_id}/dispute"))

    def escalate(self, mandate_id: str, reason: str) -> Dispute:
        return Dispute.model_validate(self._http.post(f"/v1/mandates/{mandate_id}/dispute/escalate", json={"reason": reason}))

    def submit_evidence(self, mandate_id: str, evidence: dict[str, Any]) -> Dispute:
        return Dispute.model_validate(self._http.post(f"/v1/mandates/{mandate_id}/dispute/evidence", json=evidence))


class AsyncDisputesResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def create(self, mandate_id: str, *, grounds: str, context: str | None = None) -> Dispute:
        body: dict[str, Any] = {"grounds": grounds}
        if context is not None:
            body["context"] = context
        return Dispute.model_validate(await self._http.post(f"/v1/mandates/{mandate_id}/dispute", json=body))

    async def get(self, mandate_id: str) -> Dispute:
        return Dispute.model_validate(await self._http.get(f"/v1/mandates/{mandate_id}/dispute"))

    async def escalate(self, mandate_id: str, reason: str) -> Dispute:
        return Dispute.model_validate(await self._http.post(f"/v1/mandates/{mandate_id}/dispute/escalate", json={"reason": reason}))

    async def submit_evidence(self, mandate_id: str, evidence: dict[str, Any]) -> Dispute:
        return Dispute.model_validate(await self._http.post(f"/v1/mandates/{mandate_id}/dispute/evidence", json=evidence))
