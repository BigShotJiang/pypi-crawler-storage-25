"""References resource — reverse lookup by external ID."""

from __future__ import annotations

from typing import Any

from agledger._http import AsyncHttpClient, HttpClient


class ReferencesResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def lookup(self, *, system: str, ref_type: str, ref_id: str) -> dict[str, Any]:
        """Reverse lookup mandates/agents by external reference."""
        return self._http.get("/v1/references", params={"system": system, "refType": ref_type, "refId": ref_id})

    def add_mandate_references(self, mandate_id: str, references: list[dict[str, Any]]) -> dict[str, Any]:
        """Add references to a mandate."""
        return self._http.post(f"/v1/mandates/{mandate_id}/references", json={"references": references})

    def get_mandate_references(self, mandate_id: str) -> dict[str, Any]:
        """Get mandate references."""
        return self._http.get(f"/v1/mandates/{mandate_id}/references")


class AsyncReferencesResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def lookup(self, *, system: str, ref_type: str, ref_id: str) -> dict[str, Any]:
        """Reverse lookup mandates/agents by external reference."""
        return await self._http.get("/v1/references", params={"system": system, "refType": ref_type, "refId": ref_id})

    async def add_mandate_references(self, mandate_id: str, references: list[dict[str, Any]]) -> dict[str, Any]:
        """Add references to a mandate."""
        return await self._http.post(f"/v1/mandates/{mandate_id}/references", json={"references": references})

    async def get_mandate_references(self, mandate_id: str) -> dict[str, Any]:
        """Get mandate references."""
        return await self._http.get(f"/v1/mandates/{mandate_id}/references")
