"""Schemas resource."""

from __future__ import annotations

from typing import Any


from agledger._http import AsyncHttpClient, HttpClient
from agledger.types import Page


class SchemasResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def get(self, contract_type: str) -> dict[str, Any]:
        """Get the full JSON Schema for a contract type."""
        return self._http.get(f"/v1/schemas/{contract_type}")

    def list(self) -> list[dict[str, Any]]:
        """List available contract type schemas."""
        return self._http.get("/v1/schemas")

    def get_rules(self, contract_type: str) -> dict[str, Any]:
        """Get the verification rules for a contract type."""
        return self._http.get(f"/v1/schemas/{contract_type}/rules")

    def validate_receipt(
        self, contract_type: str, evidence: dict[str, Any]
    ) -> dict[str, Any]:
        """Dry-run receipt validation against a contract type's schema."""
        return self._http.post(
            f"/v1/schemas/{contract_type}/validate", json={"evidence": evidence}
        )

    def get_meta_schema(self) -> dict[str, Any]:
        """Get the meta-schema describing constraints for custom schema authoring."""
        return self._http.get("/v1/schemas/meta-schema")

    def get_template(self, contract_type: str) -> dict[str, Any]:
        """Get a template based on an existing contract type."""
        return self._http.get(
            f"/v1/schemas/{contract_type}", params={"format": "template"}
        )

    def get_blank_template(self) -> dict[str, Any]:
        """Get a blank template for creating a custom contract type from scratch."""
        return self._http.get("/v1/schemas/_blank")

    def preview(self, schema_input: dict[str, Any]) -> dict[str, Any]:
        """Preview a schema before registration."""
        return self._http.post("/v1/schemas/preview", json=schema_input)

    def diff(
        self, contract_type: str, *, from_version: int, to_version: int
    ) -> dict[str, Any]:
        """Diff two versions of a contract type schema."""
        return self._http.get(
            f"/v1/schemas/{contract_type}/diff",
            params={"from": from_version, "to": to_version},
        )

    def export_schema(
        self,
        contract_type: str,
        *,
        versions: str | None = None,
        enterprise_id: str | None = None,
    ) -> dict[str, Any]:
        """Export a contract type schema bundle."""
        params: dict[str, Any] = {}
        if versions is not None:
            params["versions"] = versions
        if enterprise_id is not None:
            params["enterpriseId"] = enterprise_id
        return self._http.post(
            f"/v1/schemas/{contract_type}/export", params=params
        )

    def import_schema(
        self,
        payload: dict[str, Any],
        *,
        dry_run: bool = False,
        enterprise_id: str | None = None,
    ) -> dict[str, Any]:
        """Import a schema bundle. Set dry_run=True to preview without persisting."""
        params: dict[str, Any] = {}
        if dry_run:
            params["dryRun"] = "true"
        if enterprise_id is not None:
            params["enterpriseId"] = enterprise_id
        return self._http.post("/v1/schemas/import", json=payload, params=params)

    def preview_import(
        self,
        payload: dict[str, Any],
        *,
        enterprise_id: str | None = None,
    ) -> dict[str, Any]:
        """Preview a schema import without persisting (dry_run=True)."""
        return self.import_schema(payload, dry_run=True, enterprise_id=enterprise_id)

    def register(self, schema_input: dict[str, Any]) -> dict[str, Any]:
        """Register a new custom contract type schema."""
        return self._http.post("/v1/schemas", json=schema_input)

    def get_versions(self, contract_type: str) -> Page[dict[str, Any]]:
        """List all versions of a contract type schema."""
        raw = self._http.get_page(f"/v1/schemas/{contract_type}/versions")
        return Page[dict[str, Any]].model_validate(raw)

    def get_version(self, contract_type: str, version: int) -> dict[str, Any]:
        """Get a specific version of a contract type schema."""
        return self._http.get(f"/v1/schemas/{contract_type}/versions/{version}")

    def check_compatibility(
        self, contract_type: str, schemas: dict[str, Any]
    ) -> dict[str, Any]:
        """Check compatibility of new schemas against an existing contract type."""
        return self._http.post(
            f"/v1/schemas/{contract_type}/check-compatibility", json=schemas
        )

    def update_version(
        self, contract_type: str, version: int, params: dict[str, Any]
    ) -> dict[str, Any]:
        """Update a schema version (e.g., deprecate or change compatibility mode)."""
        return self._http.patch(
            f"/v1/schemas/{contract_type}/versions/{version}", json=params
        )

    def delete(self, contract_type: str) -> dict[str, Any]:
        """Delete a custom contract type schema."""
        return self._http.delete(f"/v1/schemas/{contract_type}")


class AsyncSchemasResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def get(self, contract_type: str) -> dict[str, Any]:
        """Get the full JSON Schema for a contract type."""
        return await self._http.get(f"/v1/schemas/{contract_type}")

    async def list(self) -> list[dict[str, Any]]:
        """List available contract type schemas."""
        return await self._http.get("/v1/schemas")

    async def get_rules(self, contract_type: str) -> dict[str, Any]:
        """Get the verification rules for a contract type."""
        return await self._http.get(f"/v1/schemas/{contract_type}/rules")

    async def validate_receipt(
        self, contract_type: str, evidence: dict[str, Any]
    ) -> dict[str, Any]:
        """Dry-run receipt validation against a contract type's schema."""
        return await self._http.post(
            f"/v1/schemas/{contract_type}/validate", json={"evidence": evidence}
        )

    async def get_meta_schema(self) -> dict[str, Any]:
        """Get the meta-schema describing constraints for custom schema authoring."""
        return await self._http.get("/v1/schemas/meta-schema")

    async def get_template(self, contract_type: str) -> dict[str, Any]:
        """Get a template based on an existing contract type."""
        return await self._http.get(
            f"/v1/schemas/{contract_type}", params={"format": "template"}
        )

    async def get_blank_template(self) -> dict[str, Any]:
        """Get a blank template for creating a custom contract type from scratch."""
        return await self._http.get("/v1/schemas/_blank")

    async def preview(self, schema_input: dict[str, Any]) -> dict[str, Any]:
        """Preview a schema before registration."""
        return await self._http.post("/v1/schemas/preview", json=schema_input)

    async def diff(
        self, contract_type: str, *, from_version: int, to_version: int
    ) -> dict[str, Any]:
        """Diff two versions of a contract type schema."""
        return await self._http.get(
            f"/v1/schemas/{contract_type}/diff",
            params={"from": from_version, "to": to_version},
        )

    async def export_schema(
        self,
        contract_type: str,
        *,
        versions: str | None = None,
        enterprise_id: str | None = None,
    ) -> dict[str, Any]:
        """Export a contract type schema bundle."""
        params: dict[str, Any] = {}
        if versions is not None:
            params["versions"] = versions
        if enterprise_id is not None:
            params["enterpriseId"] = enterprise_id
        return await self._http.post(
            f"/v1/schemas/{contract_type}/export", params=params
        )

    async def import_schema(
        self,
        payload: dict[str, Any],
        *,
        dry_run: bool = False,
        enterprise_id: str | None = None,
    ) -> dict[str, Any]:
        """Import a schema bundle. Set dry_run=True to preview without persisting."""
        params: dict[str, Any] = {}
        if dry_run:
            params["dryRun"] = "true"
        if enterprise_id is not None:
            params["enterpriseId"] = enterprise_id
        return await self._http.post(
            "/v1/schemas/import", json=payload, params=params
        )

    async def preview_import(
        self,
        payload: dict[str, Any],
        *,
        enterprise_id: str | None = None,
    ) -> dict[str, Any]:
        """Preview a schema import without persisting (dry_run=True)."""
        return await self.import_schema(payload, dry_run=True, enterprise_id=enterprise_id)

    async def register(self, schema_input: dict[str, Any]) -> dict[str, Any]:
        """Register a new custom contract type schema."""
        return await self._http.post("/v1/schemas", json=schema_input)

    async def get_versions(self, contract_type: str) -> Page[dict[str, Any]]:
        """List all versions of a contract type schema."""
        raw = await self._http.get_page(f"/v1/schemas/{contract_type}/versions")
        return Page[dict[str, Any]].model_validate(raw)

    async def get_version(self, contract_type: str, version: int) -> dict[str, Any]:
        """Get a specific version of a contract type schema."""
        return await self._http.get(
            f"/v1/schemas/{contract_type}/versions/{version}"
        )

    async def check_compatibility(
        self, contract_type: str, schemas: dict[str, Any]
    ) -> dict[str, Any]:
        """Check compatibility of new schemas against an existing contract type."""
        return await self._http.post(
            f"/v1/schemas/{contract_type}/check-compatibility", json=schemas
        )

    async def update_version(
        self, contract_type: str, version: int, params: dict[str, Any]
    ) -> dict[str, Any]:
        """Update a schema version (e.g., deprecate or change compatibility mode)."""
        return await self._http.patch(
            f"/v1/schemas/{contract_type}/versions/{version}", json=params
        )

    async def delete(self, contract_type: str) -> dict[str, Any]:
        """Delete a custom contract type schema."""
        return await self._http.delete(f"/v1/schemas/{contract_type}")
