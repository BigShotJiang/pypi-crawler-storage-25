"""Compliance resource."""

from __future__ import annotations

from typing import Any, AsyncIterator, Iterator

from agledger._http import AsyncHttpClient, HttpClient
from agledger.types import AiImpactAssessment, AuditStreamResult, ComplianceExport, ComplianceRecord, EuAiActReport, Page


class ComplianceResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def export(self, **params: Any) -> ComplianceExport:
        """Create a compliance export."""
        return ComplianceExport.model_validate(self._http.post("/v1/compliance/export", json=params))

    def get_export(self, export_id: str) -> ComplianceExport:
        """Get a compliance export by ID."""
        return ComplianceExport.model_validate(self._http.get(f"/v1/compliance/export/{export_id}"))

    def download_export(self, export_id: str) -> dict[str, Any]:
        """Download a compliance export."""
        return self._http.get(f"/v1/compliance/export/{export_id}/download")

    def get_ai_act_report(self, **params: Any) -> EuAiActReport:
        """Get the EU AI Act compliance report."""
        return EuAiActReport.model_validate(self._http.get("/v1/compliance/eu-ai-act/report", params=params))

    def create_record(
        self,
        mandate_id: str,
        *,
        record_type: str,
        attestation: dict[str, Any],
        attested_by: str,
        attested_at: str | None = None,
    ) -> ComplianceRecord:
        """Create a compliance record (attestation) for a mandate."""
        body: dict[str, Any] = {
            "recordType": record_type,
            "attestation": attestation,
            "attestedBy": attested_by,
        }
        if attested_at is not None:
            body["attestedAt"] = attested_at
        return ComplianceRecord.model_validate(self._http.post(f"/v1/mandates/{mandate_id}/compliance-records", json=body))

    def list_records(self, mandate_id: str, **params: Any) -> Page:
        """List compliance records for a mandate."""
        return Page.model_validate(self._http.get_page(f"/v1/mandates/{mandate_id}/compliance-records", params=params))

    def get_record(self, mandate_id: str, record_id: str) -> ComplianceRecord:
        """Get a specific compliance record."""
        return ComplianceRecord.model_validate(self._http.get(f"/v1/mandates/{mandate_id}/compliance-records/{record_id}"))

    def export_mandate(self, mandate_id: str, *, format: str = "json") -> dict[str, Any]:
        """Export per-mandate audit trail."""
        return self._http.get(f"/v1/mandates/{mandate_id}/audit-export", params={"format": format})

    def create_assessment(self, mandate_id: str, **params: Any) -> AiImpactAssessment:
        """Create an AI impact assessment for a mandate."""
        return AiImpactAssessment.model_validate(self._http.post(f"/v1/mandates/{mandate_id}/ai-impact-assessment", json=params))

    def get_assessment(self, mandate_id: str) -> AiImpactAssessment:
        """Get the AI impact assessment for a mandate."""
        return AiImpactAssessment.model_validate(self._http.get(f"/v1/mandates/{mandate_id}/ai-impact-assessment"))

    def get_enterprise_report(self, **params: Any) -> dict[str, Any]:
        """Get an enterprise audit report."""
        return self._http.get("/v1/audit/enterprise-report", params=params)

    def analyze_audit(self, mandate_id: str) -> dict[str, Any]:
        """Analyze audit data for a mandate."""
        return self._http.post("/v1/audit/enterprise-report/analyze", json={"mandateId": mandate_id})

    def stream(
        self,
        *,
        since: str,
        limit: int | None = None,
        format: str = "ocsf",
    ) -> AuditStreamResult:
        """Pull audit events as NDJSON for SIEM ingestion. Requires audit:read scope."""
        params: dict[str, Any] = {"since": since, "format": format}
        if limit is not None:
            params["limit"] = limit
        result = self._http.get_ndjson("/v1/audit/stream", params=params)
        effective_limit = limit if limit is not None else 100
        return AuditStreamResult.model_validate({
            "events": result["data"],
            "cursor": result.get("cursor"),
            "hasMore": len(result["data"]) >= effective_limit,
        })

    def stream_all(
        self,
        *,
        since: str,
        limit: int | None = None,
        format: str = "ocsf",
        max_pages: int = 100,
    ) -> Iterator[dict[str, Any]]:
        """Auto-paginating iterator for SIEM streaming."""
        current_since = since
        for _ in range(max_pages):
            result = self.stream(since=current_since, limit=limit, format=format)
            yield from result.events
            if not result.has_more or not result.cursor:
                return
            # Extract timestamp from composite cursor (timestamp_id format)
            idx = result.cursor.rfind("_")
            current_since = result.cursor[:idx] if idx > 0 else result.cursor


class AsyncComplianceResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def export(self, **params: Any) -> ComplianceExport:
        """Create a compliance export."""
        return ComplianceExport.model_validate(await self._http.post("/v1/compliance/export", json=params))

    async def get_export(self, export_id: str) -> ComplianceExport:
        """Get a compliance export by ID."""
        return ComplianceExport.model_validate(await self._http.get(f"/v1/compliance/export/{export_id}"))

    async def download_export(self, export_id: str) -> dict[str, Any]:
        """Download a compliance export."""
        return await self._http.get(f"/v1/compliance/export/{export_id}/download")

    async def get_ai_act_report(self, **params: Any) -> EuAiActReport:
        """Get the EU AI Act compliance report."""
        return EuAiActReport.model_validate(await self._http.get("/v1/compliance/eu-ai-act/report", params=params))

    async def create_record(
        self,
        mandate_id: str,
        *,
        record_type: str,
        attestation: dict[str, Any],
        attested_by: str,
        attested_at: str | None = None,
    ) -> ComplianceRecord:
        """Create a compliance record (attestation) for a mandate."""
        body: dict[str, Any] = {
            "recordType": record_type,
            "attestation": attestation,
            "attestedBy": attested_by,
        }
        if attested_at is not None:
            body["attestedAt"] = attested_at
        return ComplianceRecord.model_validate(await self._http.post(f"/v1/mandates/{mandate_id}/compliance-records", json=body))

    async def list_records(self, mandate_id: str, **params: Any) -> Page:
        """List compliance records for a mandate."""
        return Page.model_validate(await self._http.get_page(f"/v1/mandates/{mandate_id}/compliance-records", params=params))

    async def get_record(self, mandate_id: str, record_id: str) -> ComplianceRecord:
        """Get a specific compliance record."""
        return ComplianceRecord.model_validate(await self._http.get(f"/v1/mandates/{mandate_id}/compliance-records/{record_id}"))

    async def export_mandate(self, mandate_id: str, *, format: str = "json") -> dict[str, Any]:
        """Export per-mandate audit trail."""
        return await self._http.get(f"/v1/mandates/{mandate_id}/audit-export", params={"format": format})

    async def create_assessment(self, mandate_id: str, **params: Any) -> AiImpactAssessment:
        """Create an AI impact assessment for a mandate."""
        return AiImpactAssessment.model_validate(await self._http.post(f"/v1/mandates/{mandate_id}/ai-impact-assessment", json=params))

    async def get_assessment(self, mandate_id: str) -> AiImpactAssessment:
        """Get the AI impact assessment for a mandate."""
        return AiImpactAssessment.model_validate(await self._http.get(f"/v1/mandates/{mandate_id}/ai-impact-assessment"))

    async def get_enterprise_report(self, **params: Any) -> dict[str, Any]:
        """Get an enterprise audit report."""
        return await self._http.get("/v1/audit/enterprise-report", params=params)

    async def analyze_audit(self, mandate_id: str) -> dict[str, Any]:
        """Analyze audit data for a mandate."""
        return await self._http.post("/v1/audit/enterprise-report/analyze", json={"mandateId": mandate_id})

    async def stream(
        self,
        *,
        since: str,
        limit: int | None = None,
        format: str = "ocsf",
    ) -> AuditStreamResult:
        """Pull audit events as NDJSON for SIEM ingestion. Requires audit:read scope."""
        params: dict[str, Any] = {"since": since, "format": format}
        if limit is not None:
            params["limit"] = limit
        result = await self._http.get_ndjson("/v1/audit/stream", params=params)
        effective_limit = limit if limit is not None else 100
        return AuditStreamResult.model_validate({
            "events": result["data"],
            "cursor": result.get("cursor"),
            "hasMore": len(result["data"]) >= effective_limit,
        })

    async def stream_all(
        self,
        *,
        since: str,
        limit: int | None = None,
        format: str = "ocsf",
        max_pages: int = 100,
    ) -> AsyncIterator[dict[str, Any]]:
        """Auto-paginating async iterator for SIEM streaming."""
        current_since = since
        for _ in range(max_pages):
            result = await self.stream(since=current_since, limit=limit, format=format)
            for event in result.events:
                yield event
            if not result.has_more or not result.cursor:
                return
            idx = result.cursor.rfind("_")
            current_since = result.cursor[:idx] if idx > 0 else result.cursor
