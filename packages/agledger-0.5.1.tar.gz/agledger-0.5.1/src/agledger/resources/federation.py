"""Federation resource — gateway-facing operations."""

from __future__ import annotations

from typing import Any

from agledger._http import AsyncHttpClient, HttpClient


class FederationResource:
    """Gateway-facing federation operations (bearer token auth)."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def register(
        self,
        *,
        registration_token: str,
        organization_id: str,
        signing_public_key: str,
        encryption_public_key: str,
        endpoint_url: str,
        revocation_secret: str,
        timestamp: str,
        nonce: str,
        signature: str,
        display_name: str | None = None,
        capabilities: list[str] | None = None,
    ) -> dict[str, Any]:
        """Register a new gateway. No auth required (proof-of-possession)."""
        body: dict[str, Any] = {
            "registrationToken": registration_token,
            "organizationId": organization_id,
            "signingPublicKey": signing_public_key,
            "encryptionPublicKey": encryption_public_key,
            "endpointUrl": endpoint_url,
            "revocationSecret": revocation_secret,
            "timestamp": timestamp,
            "nonce": nonce,
            "signature": signature,
        }
        if display_name is not None:
            body["displayName"] = display_name
        if capabilities is not None:
            body["capabilities"] = capabilities
        return self._http.post("/federation/v1/register", json=body, auth_override="none")

    def heartbeat(
        self,
        *,
        gateway_id: str,
        agent_count: int,
        mandate_count: int,
        timestamp: str,
    ) -> dict[str, Any]:
        """Send heartbeat to refresh bearer token."""
        return self._http.post("/federation/v1/heartbeat", json={
            "gatewayId": gateway_id,
            "agentCount": agent_count,
            "mandateCount": mandate_count,
            "timestamp": timestamp,
        })

    def register_agent(
        self,
        *,
        agent_id: str,
        contract_types: list[str],
        display_name: str | None = None,
    ) -> dict[str, Any]:
        """Register an agent in the federation directory."""
        body: dict[str, Any] = {"agentId": agent_id, "contractTypes": contract_types}
        if display_name is not None:
            body["displayName"] = display_name
        return self._http.post("/federation/v1/agents", json=body)

    def list_agents(self, **params: Any) -> dict[str, Any]:
        """List federated agents. Supports contractType, limit, cursor."""
        mapped = {}
        if "contract_type" in params:
            mapped["contractType"] = params.pop("contract_type")
        mapped.update(params)
        return self._http.get("/federation/v1/agents", params=mapped)

    def submit_state_transition(
        self,
        *,
        mandate_id: str,
        gateway_id: str,
        state: str,
        contract_type: str,
        criteria_hash: str,
        role: str,
        seq: int,
        idempotency_key: str,
        timestamp: str,
        nonce: str,
        signature: str,
        performer_gateway_id: str | None = None,
    ) -> dict[str, Any]:
        """Submit a cross-boundary state transition."""
        body: dict[str, Any] = {
            "mandateId": mandate_id,
            "gatewayId": gateway_id,
            "state": state,
            "contractType": contract_type,
            "criteriaHash": criteria_hash,
            "role": role,
            "seq": seq,
            "idempotencyKey": idempotency_key,
            "timestamp": timestamp,
            "nonce": nonce,
            "signature": signature,
        }
        if performer_gateway_id is not None:
            body["performerGatewayId"] = performer_gateway_id
        return self._http.post("/federation/v1/state-transitions", json=body)

    def relay_signal(
        self,
        *,
        mandate_id: str,
        signal: str,
        outcome_hash: str,
        signal_seq: int,
        valid_until: str,
        performer_gateway_id: str,
        timestamp: str,
        nonce: str,
        performer_signature: str,
        outcome: str | None = None,
    ) -> dict[str, Any]:
        """Relay a settlement signal to the counterparty gateway."""
        body: dict[str, Any] = {
            "mandateId": mandate_id,
            "signal": signal,
            "outcomeHash": outcome_hash,
            "signalSeq": signal_seq,
            "validUntil": valid_until,
            "performerGatewayId": performer_gateway_id,
            "timestamp": timestamp,
            "nonce": nonce,
            "performerSignature": performer_signature,
        }
        if outcome is not None:
            body["outcome"] = outcome
        return self._http.post("/federation/v1/signals", json=body)

    def rotate_key(
        self,
        gateway_id: str,
        *,
        new_signing_public_key: str,
        new_encryption_public_key: str,
        signature_old_key: str,
        signature_new_key: str,
        timestamp: str,
        nonce: str,
    ) -> dict[str, Any]:
        """Rotate gateway signing and encryption keys (dual-signature)."""
        return self._http.post(f"/federation/v1/gateways/{gateway_id}/rotate-key", json={
            "newSigningPublicKey": new_signing_public_key,
            "newEncryptionPublicKey": new_encryption_public_key,
            "signatureOldKey": signature_old_key,
            "signatureNewKey": signature_new_key,
            "timestamp": timestamp,
            "nonce": nonce,
        })

    def revoke(self, gateway_id: str, *, revocation_secret: str, reason: str) -> dict[str, Any]:
        """Self-service gateway revocation. No auth required."""
        return self._http.post(
            f"/federation/v1/gateways/{gateway_id}/revoke",
            json={"revocationSecret": revocation_secret, "reason": reason},
            auth_override="none",
        )

    def catch_up(self, *, since_position: int, limit: int | None = None) -> dict[str, Any]:
        """Fetch missed audit entries for partition recovery."""
        params: dict[str, Any] = {"sincePosition": since_position}
        if limit is not None:
            params["limit"] = limit
        return self._http.get("/federation/v1/catch-up", params=params)

    def stream(self, **params: Any) -> dict[str, Any]:
        """Stream federation events."""
        return self._http.get("/federation/v1/stream", params=params)

    def publish_schema(self, contract_type: str, **params: Any) -> dict[str, Any]:
        """Publish a contract type schema to the federation."""
        return self._http.post(f"/federation/v1/schemas/{contract_type}/publish", json=params)

    def confirm_schema_publish(self, contract_type: str, **params: Any) -> dict[str, Any]:
        """Confirm a pending schema publish."""
        return self._http.post(f"/federation/v1/schemas/{contract_type}/publish/confirm", json=params)

    def list_contract_types(self) -> dict[str, Any]:
        """List available federation contract types."""
        return self._http.get("/federation/v1/contract-types")

    def get_contract_type(self, contract_type: str) -> dict[str, Any]:
        """Get a specific federation contract type."""
        return self._http.get(f"/federation/v1/contract-types/{contract_type}")

    def get_mandate_criteria(self, mandate_id: str) -> dict[str, Any]:
        """Get criteria for a federated mandate."""
        return self._http.get(f"/federation/v1/mandates/{mandate_id}/criteria")

    def submit_mandate_criteria(self, mandate_id: str, **params: Any) -> dict[str, Any]:
        """Submit criteria for a federated mandate."""
        return self._http.post(f"/federation/v1/mandates/{mandate_id}/criteria", json=params)

    def contribute_reputation(self, **params: Any) -> dict[str, Any]:
        """Contribute reputation data for a federated agent."""
        return self._http.post("/federation/v1/reputation/contribute", json=params)

    def get_agent_reputation(self, agent_id: str) -> dict[str, Any]:
        """Get reputation for a federated agent."""
        return self._http.get(f"/federation/v1/agents/{agent_id}/reputation")

    def broadcast_revocations(self, **params: Any) -> dict[str, Any]:
        """Broadcast revocations to peer gateways."""
        return self._http.post("/federation/v1/peer/revocations", json=params)

    def sync_agent_directory(self, **params: Any) -> dict[str, Any]:
        """Sync agent directory with a peer gateway."""
        return self._http.post("/federation/v1/peer/agent-sync", json=params)


class AsyncFederationResource:
    """Async gateway-facing federation operations."""

    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def register(
        self,
        *,
        registration_token: str,
        organization_id: str,
        signing_public_key: str,
        encryption_public_key: str,
        endpoint_url: str,
        revocation_secret: str,
        timestamp: str,
        nonce: str,
        signature: str,
        display_name: str | None = None,
        capabilities: list[str] | None = None,
    ) -> dict[str, Any]:
        """Register a new gateway. No auth required (proof-of-possession)."""
        body: dict[str, Any] = {
            "registrationToken": registration_token,
            "organizationId": organization_id,
            "signingPublicKey": signing_public_key,
            "encryptionPublicKey": encryption_public_key,
            "endpointUrl": endpoint_url,
            "revocationSecret": revocation_secret,
            "timestamp": timestamp,
            "nonce": nonce,
            "signature": signature,
        }
        if display_name is not None:
            body["displayName"] = display_name
        if capabilities is not None:
            body["capabilities"] = capabilities
        return await self._http.post("/federation/v1/register", json=body, auth_override="none")

    async def heartbeat(self, *, gateway_id: str, agent_count: int, mandate_count: int, timestamp: str) -> dict[str, Any]:
        """Send heartbeat to refresh bearer token."""
        return await self._http.post("/federation/v1/heartbeat", json={
            "gatewayId": gateway_id, "agentCount": agent_count, "mandateCount": mandate_count, "timestamp": timestamp,
        })

    async def register_agent(self, *, agent_id: str, contract_types: list[str], display_name: str | None = None) -> dict[str, Any]:
        """Register an agent in the federation directory."""
        body: dict[str, Any] = {"agentId": agent_id, "contractTypes": contract_types}
        if display_name is not None:
            body["displayName"] = display_name
        return await self._http.post("/federation/v1/agents", json=body)

    async def list_agents(self, **params: Any) -> dict[str, Any]:
        """List federated agents. Supports contractType, limit, cursor."""
        mapped = {}
        if "contract_type" in params:
            mapped["contractType"] = params.pop("contract_type")
        mapped.update(params)
        return await self._http.get("/federation/v1/agents", params=mapped)

    async def submit_state_transition(
        self, *, mandate_id: str, gateway_id: str, state: str, contract_type: str, criteria_hash: str,
        role: str, seq: int, idempotency_key: str, timestamp: str, nonce: str, signature: str,
        performer_gateway_id: str | None = None,
    ) -> dict[str, Any]:
        """Submit a cross-boundary state transition."""
        body: dict[str, Any] = {
            "mandateId": mandate_id, "gatewayId": gateway_id, "state": state, "contractType": contract_type,
            "criteriaHash": criteria_hash, "role": role, "seq": seq, "idempotencyKey": idempotency_key,
            "timestamp": timestamp, "nonce": nonce, "signature": signature,
        }
        if performer_gateway_id is not None:
            body["performerGatewayId"] = performer_gateway_id
        return await self._http.post("/federation/v1/state-transitions", json=body)

    async def relay_signal(
        self, *, mandate_id: str, signal: str, outcome_hash: str, signal_seq: int, valid_until: str,
        performer_gateway_id: str, timestamp: str, nonce: str, performer_signature: str, outcome: str | None = None,
    ) -> dict[str, Any]:
        """Relay a settlement signal to the counterparty gateway."""
        body: dict[str, Any] = {
            "mandateId": mandate_id, "signal": signal, "outcomeHash": outcome_hash, "signalSeq": signal_seq,
            "validUntil": valid_until, "performerGatewayId": performer_gateway_id, "timestamp": timestamp,
            "nonce": nonce, "performerSignature": performer_signature,
        }
        if outcome is not None:
            body["outcome"] = outcome
        return await self._http.post("/federation/v1/signals", json=body)

    async def rotate_key(
        self, gateway_id: str, *, new_signing_public_key: str, new_encryption_public_key: str,
        signature_old_key: str, signature_new_key: str, timestamp: str, nonce: str,
    ) -> dict[str, Any]:
        """Rotate gateway signing and encryption keys (dual-signature)."""
        return await self._http.post(f"/federation/v1/gateways/{gateway_id}/rotate-key", json={
            "newSigningPublicKey": new_signing_public_key, "newEncryptionPublicKey": new_encryption_public_key,
            "signatureOldKey": signature_old_key, "signatureNewKey": signature_new_key,
            "timestamp": timestamp, "nonce": nonce,
        })

    async def revoke(self, gateway_id: str, *, revocation_secret: str, reason: str) -> dict[str, Any]:
        """Self-service gateway revocation. No auth required."""
        return await self._http.post(
            f"/federation/v1/gateways/{gateway_id}/revoke",
            json={"revocationSecret": revocation_secret, "reason": reason},
            auth_override="none",
        )

    async def catch_up(self, *, since_position: int, limit: int | None = None) -> dict[str, Any]:
        """Fetch missed audit entries for partition recovery."""
        params: dict[str, Any] = {"sincePosition": since_position}
        if limit is not None:
            params["limit"] = limit
        return await self._http.get("/federation/v1/catch-up", params=params)

    async def stream(self, **params: Any) -> dict[str, Any]:
        """Stream federation events."""
        return await self._http.get("/federation/v1/stream", params=params)

    async def publish_schema(self, contract_type: str, **params: Any) -> dict[str, Any]:
        """Publish a contract type schema to the federation."""
        return await self._http.post(f"/federation/v1/schemas/{contract_type}/publish", json=params)

    async def confirm_schema_publish(self, contract_type: str, **params: Any) -> dict[str, Any]:
        """Confirm a pending schema publish."""
        return await self._http.post(f"/federation/v1/schemas/{contract_type}/publish/confirm", json=params)

    async def list_contract_types(self) -> dict[str, Any]:
        """List available federation contract types."""
        return await self._http.get("/federation/v1/contract-types")

    async def get_contract_type(self, contract_type: str) -> dict[str, Any]:
        """Get a specific federation contract type."""
        return await self._http.get(f"/federation/v1/contract-types/{contract_type}")

    async def get_mandate_criteria(self, mandate_id: str) -> dict[str, Any]:
        """Get criteria for a federated mandate."""
        return await self._http.get(f"/federation/v1/mandates/{mandate_id}/criteria")

    async def submit_mandate_criteria(self, mandate_id: str, **params: Any) -> dict[str, Any]:
        """Submit criteria for a federated mandate."""
        return await self._http.post(f"/federation/v1/mandates/{mandate_id}/criteria", json=params)

    async def contribute_reputation(self, **params: Any) -> dict[str, Any]:
        """Contribute reputation data for a federated agent."""
        return await self._http.post("/federation/v1/reputation/contribute", json=params)

    async def get_agent_reputation(self, agent_id: str) -> dict[str, Any]:
        """Get reputation for a federated agent."""
        return await self._http.get(f"/federation/v1/agents/{agent_id}/reputation")

    async def broadcast_revocations(self, **params: Any) -> dict[str, Any]:
        """Broadcast revocations to peer gateways."""
        return await self._http.post("/federation/v1/peer/revocations", json=params)

    async def sync_agent_directory(self, **params: Any) -> dict[str, Any]:
        """Sync agent directory with a peer gateway."""
        return await self._http.post("/federation/v1/peer/agent-sync", json=params)
