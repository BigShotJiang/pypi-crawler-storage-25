"""Reputation resource."""

from __future__ import annotations
from typing import Any
from agledger._http import AsyncHttpClient, HttpClient
from agledger.types import Page, ReputationScore


class ReputationResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def get_agent(self, agent_id: str, **params: Any) -> Page:
        """Get paginated per-contract-type reputation scores for an agent."""
        return Page.model_validate(self._http.get_page(f"/v1/agents/{agent_id}/reputation", params=params))

    def get_by_contract_type(self, agent_id: str, contract_type: str) -> ReputationScore:
        """Get reputation score for an agent on a specific contract type."""
        return ReputationScore.model_validate(self._http.get(f"/v1/agents/{agent_id}/reputation/{contract_type}"))

    def get_history(self, agent_id: str, **params: Any) -> Page:
        """Get transaction history for an agent."""
        return Page.model_validate(self._http.get_page(f"/v1/agents/{agent_id}/history", params=params))


class AsyncReputationResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def get_agent(self, agent_id: str, **params: Any) -> Page:
        """Get paginated per-contract-type reputation scores for an agent."""
        return Page.model_validate(await self._http.get_page(f"/v1/agents/{agent_id}/reputation", params=params))

    async def get_by_contract_type(self, agent_id: str, contract_type: str) -> ReputationScore:
        """Get reputation score for an agent on a specific contract type."""
        return ReputationScore.model_validate(await self._http.get(f"/v1/agents/{agent_id}/reputation/{contract_type}"))

    async def get_history(self, agent_id: str, **params: Any) -> Page:
        """Get transaction history for an agent."""
        return Page.model_validate(await self._http.get_page(f"/v1/agents/{agent_id}/history", params=params))
