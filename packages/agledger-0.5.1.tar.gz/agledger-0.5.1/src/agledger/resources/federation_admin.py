"""Federation admin resource — platform admin operations."""

from __future__ import annotations

from typing import Any

from agledger._http import AsyncHttpClient, HttpClient


class FederationAdminResource:
    """Platform admin federation operations (API key auth, admin:system scope)."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def create_registration_token(
        self,
        *,
        label: str | None = None,
        expires_in_hours: int | None = None,
        metadata: dict[str, Any] | None = None,
        allowed_contract_types: list[str] | None = None,
    ) -> dict[str, Any]:
        """Create a single-use registration token for a new gateway."""
        body: dict[str, Any] = {}
        if label is not None:
            body["label"] = label
        if expires_in_hours is not None:
            body["expiresInHours"] = expires_in_hours
        if metadata is not None:
            body["metadata"] = metadata
        if allowed_contract_types is not None:
            body["allowedContractTypes"] = allowed_contract_types
        return self._http.post("/federation/v1/admin/registration-tokens", json=body)

    def list_gateways(self, **params: Any) -> dict[str, Any]:
        """List registered federation gateways. Supports status, limit, offset."""
        return self._http.get_page("/federation/v1/admin/gateways", params=params)

    def revoke_gateway(self, gateway_id: str, *, reason: str) -> dict[str, Any]:
        """Admin-initiated gateway revocation (irreversible)."""
        return self._http.post(f"/federation/v1/admin/gateways/{gateway_id}/revoke", json={"reason": reason})

    def query_mandates(self, **params: Any) -> dict[str, Any]:
        """Query federation mandates. Supports gatewayId, hubState, contractType, limit, offset."""
        mapped = {}
        if "gateway_id" in params:
            mapped["gatewayId"] = params.pop("gateway_id")
        if "hub_state" in params:
            mapped["hubState"] = params.pop("hub_state")
        if "contract_type" in params:
            mapped["contractType"] = params.pop("contract_type")
        mapped.update(params)
        return self._http.get("/federation/v1/admin/mandates", params=mapped)

    def get_audit_log(self, **params: Any) -> dict[str, Any]:
        """Query the federation audit log. Supports gatewayId, entryType, mandateId, limit, offset."""
        mapped = {}
        if "gateway_id" in params:
            mapped["gatewayId"] = params.pop("gateway_id")
        if "entry_type" in params:
            mapped["entryType"] = params.pop("entry_type")
        if "mandate_id" in params:
            mapped["mandateId"] = params.pop("mandate_id")
        mapped.update(params)
        return self._http.get("/federation/v1/admin/audit-log", params=mapped)

    def get_health(self) -> dict[str, Any]:
        """Get federation health summary."""
        return self._http.get("/federation/v1/admin/health")

    def reset_sequence(self, gateway_id: str, *, new_seq: int | None = None) -> dict[str, Any]:
        """Reset a gateway's sequence counter."""
        body: dict[str, Any] = {}
        if new_seq is not None:
            body["newSeq"] = new_seq
        return self._http.post(f"/federation/v1/admin/gateways/{gateway_id}/reset-seq", json=body)

    def list_dlq(self, **params: Any) -> dict[str, Any]:
        """List outbound DLQ entries."""
        return self._http.get_page("/federation/v1/admin/outbound-dlq", params=params)

    def retry_dlq(self, dlq_id: str) -> dict[str, Any]:
        """Retry a failed outbound federation message."""
        return self._http.post(f"/federation/v1/admin/outbound-dlq/{dlq_id}/retry", json={})

    def delete_dlq(self, dlq_id: str) -> dict[str, Any]:
        """Permanently discard a failed outbound message from the DLQ."""
        return self._http.delete(f"/federation/v1/admin/outbound-dlq/{dlq_id}")

    def rotate_hub_key(self) -> dict[str, Any]:
        """Rotate the federation hub signing key."""
        return self._http.post("/federation/v1/admin/rotate-hub-key", json={})

    def register_peer(self, **params: Any) -> dict[str, Any]:
        """Register a peer federation hub."""
        return self._http.post("/federation/v1/peer", json=params)

    def list_peers(self) -> dict[str, Any]:
        """List all peer federation hubs."""
        return self._http.get("/federation/v1/admin/peers")

    def get_peer(self, hub_id: str) -> dict[str, Any]:
        """Get a specific peer federation hub."""
        return self._http.get(f"/federation/v1/admin/peers/{hub_id}")

    def revoke_peer(self, hub_id: str) -> dict[str, Any]:
        """Revoke a peer federation hub."""
        return self._http.post(f"/federation/v1/admin/peers/{hub_id}/revoke", json={})

    def resync_peer(self, hub_id: str) -> dict[str, Any]:
        """Resync with a peer federation hub."""
        return self._http.post(f"/federation/v1/admin/peers/{hub_id}/resync", json={})

    def create_peering_token(self) -> dict[str, Any]:
        """Create a peering token for hub-to-hub federation."""
        return self._http.post("/federation/v1/admin/peering-tokens", json={})

    def list_hub_keys(self) -> dict[str, Any]:
        """List all hub signing keys."""
        return self._http.get("/federation/v1/admin/hub-keys")

    def activate_hub_key(self, key_id: str) -> dict[str, Any]:
        """Activate a hub signing key."""
        return self._http.post(f"/federation/v1/admin/hub-keys/{key_id}/activate", json={})

    def expire_hub_key(self, key_id: str) -> dict[str, Any]:
        """Expire a hub signing key."""
        return self._http.post(f"/federation/v1/admin/hub-keys/{key_id}/expire", json={})

    def delete_schema_version(self, contract_type: str, version: str) -> dict[str, Any]:
        """Delete a specific schema version from the federation."""
        return self._http.delete(f"/federation/v1/admin/schemas/{contract_type}/{version}")

    def list_reputation_contributions(self, agent_id: str) -> dict[str, Any]:
        """List reputation contributions for an agent."""
        return self._http.get(f"/federation/v1/admin/reputation/{agent_id}")

    def reset_reputation(self, agent_id: str) -> dict[str, Any]:
        """Reset reputation for an agent."""
        return self._http.delete(f"/federation/v1/admin/reputation/{agent_id}")

    def get_mandate_criteria_status(self, mandate_id: str) -> dict[str, Any]:
        """Get criteria status for a federated mandate."""
        return self._http.get(f"/federation/v1/admin/mandates/{mandate_id}/criteria-status")


class AsyncFederationAdminResource:
    """Async platform admin federation operations."""

    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def create_registration_token(
        self, *, label: str | None = None, expires_in_hours: int | None = None,
        metadata: dict[str, Any] | None = None, allowed_contract_types: list[str] | None = None,
    ) -> dict[str, Any]:
        """Create a single-use registration token for a new gateway."""
        body: dict[str, Any] = {}
        if label is not None:
            body["label"] = label
        if expires_in_hours is not None:
            body["expiresInHours"] = expires_in_hours
        if metadata is not None:
            body["metadata"] = metadata
        if allowed_contract_types is not None:
            body["allowedContractTypes"] = allowed_contract_types
        return await self._http.post("/federation/v1/admin/registration-tokens", json=body)

    async def list_gateways(self, **params: Any) -> dict[str, Any]:
        """List registered federation gateways."""
        return await self._http.get_page("/federation/v1/admin/gateways", params=params)

    async def revoke_gateway(self, gateway_id: str, *, reason: str) -> dict[str, Any]:
        """Admin-initiated gateway revocation (irreversible)."""
        return await self._http.post(f"/federation/v1/admin/gateways/{gateway_id}/revoke", json={"reason": reason})

    async def query_mandates(self, **params: Any) -> dict[str, Any]:
        """Query federation mandates."""
        mapped = {}
        if "gateway_id" in params:
            mapped["gatewayId"] = params.pop("gateway_id")
        if "hub_state" in params:
            mapped["hubState"] = params.pop("hub_state")
        if "contract_type" in params:
            mapped["contractType"] = params.pop("contract_type")
        mapped.update(params)
        return await self._http.get("/federation/v1/admin/mandates", params=mapped)

    async def get_audit_log(self, **params: Any) -> dict[str, Any]:
        """Query the federation audit log."""
        mapped = {}
        if "gateway_id" in params:
            mapped["gatewayId"] = params.pop("gateway_id")
        if "entry_type" in params:
            mapped["entryType"] = params.pop("entry_type")
        if "mandate_id" in params:
            mapped["mandateId"] = params.pop("mandate_id")
        mapped.update(params)
        return await self._http.get("/federation/v1/admin/audit-log", params=mapped)

    async def get_health(self) -> dict[str, Any]:
        """Get federation health summary."""
        return await self._http.get("/federation/v1/admin/health")

    async def reset_sequence(self, gateway_id: str, *, new_seq: int | None = None) -> dict[str, Any]:
        """Reset a gateway's sequence counter."""
        body: dict[str, Any] = {}
        if new_seq is not None:
            body["newSeq"] = new_seq
        return await self._http.post(f"/federation/v1/admin/gateways/{gateway_id}/reset-seq", json=body)

    async def list_dlq(self, **params: Any) -> dict[str, Any]:
        """List outbound DLQ entries."""
        return await self._http.get_page("/federation/v1/admin/outbound-dlq", params=params)

    async def retry_dlq(self, dlq_id: str) -> dict[str, Any]:
        """Retry a failed outbound federation message."""
        return await self._http.post(f"/federation/v1/admin/outbound-dlq/{dlq_id}/retry", json={})

    async def delete_dlq(self, dlq_id: str) -> dict[str, Any]:
        """Permanently discard a failed outbound message from the DLQ."""
        return await self._http.delete(f"/federation/v1/admin/outbound-dlq/{dlq_id}")

    async def rotate_hub_key(self) -> dict[str, Any]:
        """Rotate the federation hub signing key."""
        return await self._http.post("/federation/v1/admin/rotate-hub-key", json={})

    async def register_peer(self, **params: Any) -> dict[str, Any]:
        """Register a peer federation hub."""
        return await self._http.post("/federation/v1/peer", json=params)

    async def list_peers(self) -> dict[str, Any]:
        """List all peer federation hubs."""
        return await self._http.get("/federation/v1/admin/peers")

    async def get_peer(self, hub_id: str) -> dict[str, Any]:
        """Get a specific peer federation hub."""
        return await self._http.get(f"/federation/v1/admin/peers/{hub_id}")

    async def revoke_peer(self, hub_id: str) -> dict[str, Any]:
        """Revoke a peer federation hub."""
        return await self._http.post(f"/federation/v1/admin/peers/{hub_id}/revoke", json={})

    async def resync_peer(self, hub_id: str) -> dict[str, Any]:
        """Resync with a peer federation hub."""
        return await self._http.post(f"/federation/v1/admin/peers/{hub_id}/resync", json={})

    async def create_peering_token(self) -> dict[str, Any]:
        """Create a peering token for hub-to-hub federation."""
        return await self._http.post("/federation/v1/admin/peering-tokens", json={})

    async def list_hub_keys(self) -> dict[str, Any]:
        """List all hub signing keys."""
        return await self._http.get("/federation/v1/admin/hub-keys")

    async def activate_hub_key(self, key_id: str) -> dict[str, Any]:
        """Activate a hub signing key."""
        return await self._http.post(f"/federation/v1/admin/hub-keys/{key_id}/activate", json={})

    async def expire_hub_key(self, key_id: str) -> dict[str, Any]:
        """Expire a hub signing key."""
        return await self._http.post(f"/federation/v1/admin/hub-keys/{key_id}/expire", json={})

    async def delete_schema_version(self, contract_type: str, version: str) -> dict[str, Any]:
        """Delete a specific schema version from the federation."""
        return await self._http.delete(f"/federation/v1/admin/schemas/{contract_type}/{version}")

    async def list_reputation_contributions(self, agent_id: str) -> dict[str, Any]:
        """List reputation contributions for an agent."""
        return await self._http.get(f"/federation/v1/admin/reputation/{agent_id}")

    async def reset_reputation(self, agent_id: str) -> dict[str, Any]:
        """Reset reputation for an agent."""
        return await self._http.delete(f"/federation/v1/admin/reputation/{agent_id}")

    async def get_mandate_criteria_status(self, mandate_id: str) -> dict[str, Any]:
        """Get criteria status for a federated mandate."""
        return await self._http.get(f"/federation/v1/admin/mandates/{mandate_id}/criteria-status")
