"""Projects resource."""

from __future__ import annotations

from typing import Any

from agledger._http import AsyncHttpClient, HttpClient
from agledger.types import Project


class ProjectsResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def create(self, *, name: str, description: str | None = None) -> Project:
        """Create a new project."""
        body: dict[str, Any] = {"name": name}
        if description is not None:
            body["description"] = description
        return Project.model_validate(self._http.post("/v1/projects", json=body))

    def list(self, **params: Any) -> dict[str, Any]:
        """List projects."""
        return self._http.get_page("/v1/projects", params=params)

    def get(self, project_id: str) -> Project:
        """Get a project by ID."""
        return Project.model_validate(self._http.get(f"/v1/projects/{project_id}"))

    def update(
        self,
        project_id: str,
        *,
        name: str | None = None,
        description: str | None = None,
        status: str | None = None,
    ) -> Project:
        """Update a project."""
        body: dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if description is not None:
            body["description"] = description
        if status is not None:
            body["status"] = status
        return Project.model_validate(self._http.patch(f"/v1/projects/{project_id}", json=body))

    def delete(self, project_id: str) -> dict[str, Any]:
        """Delete a project."""
        return self._http.delete(f"/v1/projects/{project_id}")


class AsyncProjectsResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def create(self, *, name: str, description: str | None = None) -> Project:
        """Create a new project."""
        body: dict[str, Any] = {"name": name}
        if description is not None:
            body["description"] = description
        return Project.model_validate(await self._http.post("/v1/projects", json=body))

    async def list(self, **params: Any) -> dict[str, Any]:
        """List projects."""
        return await self._http.get_page("/v1/projects", params=params)

    async def get(self, project_id: str) -> Project:
        """Get a project by ID."""
        return Project.model_validate(await self._http.get(f"/v1/projects/{project_id}"))

    async def update(
        self,
        project_id: str,
        *,
        name: str | None = None,
        description: str | None = None,
        status: str | None = None,
    ) -> Project:
        """Update a project."""
        body: dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if description is not None:
            body["description"] = description
        if status is not None:
            body["status"] = status
        return Project.model_validate(await self._http.patch(f"/v1/projects/{project_id}", json=body))

    async def delete(self, project_id: str) -> dict[str, Any]:
        """Delete a project."""
        return await self._http.delete(f"/v1/projects/{project_id}")
