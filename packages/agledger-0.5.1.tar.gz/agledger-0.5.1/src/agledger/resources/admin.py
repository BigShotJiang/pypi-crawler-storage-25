"""Admin resource — platform-level operations.

Requires a platform-level API key.
"""

from __future__ import annotations

import warnings
from typing import Any

from agledger._http import AsyncHttpClient, HttpClient


class AdminResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def list_enterprises(self, **params: Any) -> dict[str, Any]:
        """List all enterprises on the platform."""
        return self._http.get_page("/v1/admin/enterprises", params=params)

    def create_enterprise(
        self,
        *,
        name: str,
        slug: str | None = None,
    ) -> dict[str, Any]:
        """Create a new enterprise.

        Example::

            result = client.admin.create_enterprise(name="Acme Corp", slug="acme-corp")
            print(result["id"])
        """
        body: dict[str, Any] = {"name": name}
        if slug is not None:
            body["slug"] = slug
        return self._http.post("/v1/admin/enterprises", json=body)

    def list_agents(self, **params: Any) -> dict[str, Any]:
        """List all registered agents on the platform."""
        return self._http.get_page("/v1/admin/agents", params=params)

    def create_agent(
        self,
        *,
        name: str,
        slug: str | None = None,
        enterprise_id: str | None = None,
        email: str | None = None,
        trust_level: str | None = None,
        agent_card_url: str | None = None,
    ) -> dict[str, Any]:
        """Create a new agent.

        Example::

            result = client.admin.create_agent(
                name="My Agent", slug="my-agent", enterprise_id="ent_abc123",
            )
            print(result["id"])
        """
        body: dict[str, Any] = {"name": name}
        if slug is not None:
            body["slug"] = slug
        if enterprise_id is not None:
            body["enterpriseId"] = enterprise_id
        if email is not None:
            body["email"] = email
        if trust_level is not None:
            body["trustLevel"] = trust_level
        if agent_card_url is not None:
            body["agentCardUrl"] = agent_card_url
        return self._http.post("/v1/admin/agents", json=body)

    def get_enterprise_config(self, enterprise_id: str) -> dict[str, Any]:
        """Get an enterprise's configuration."""
        return self._http.get(f"/v1/admin/enterprises/{enterprise_id}/config")

    def replace_enterprise_config(
        self,
        enterprise_id: str,
        config: dict[str, Any],
    ) -> dict[str, Any]:
        """Replace an enterprise's configuration (desired-state semantics).

        Uses PUT — the entire config object is replaced; omitted fields
        are removed.

        Example::

            client.admin.replace_enterprise_config("ent_abc123", {
                "agentApprovalRequired": True,
                "allowSelfApproval": False,
            })
        """
        return self._http.put(f"/v1/admin/enterprises/{enterprise_id}/config", json=config)

    def set_enterprise_config(
        self,
        enterprise_id: str,
        config: dict[str, Any],
    ) -> dict[str, Any]:
        """Deprecated: use :meth:`replace_enterprise_config` instead."""
        warnings.warn(
            "set_enterprise_config is deprecated, use replace_enterprise_config",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.replace_enterprise_config(enterprise_id, config)

    def update_enterprise_config(
        self,
        enterprise_id: str,
        config: dict[str, Any],
    ) -> dict[str, Any]:
        """Partially update an enterprise's configuration (PATCH semantics).

        Only the provided fields are updated; omitted fields are unchanged.
        """
        return self._http.patch(f"/v1/admin/enterprises/{enterprise_id}/config", json=config)

    def update_trust_level(
        self,
        entity_id: str,
        *,
        trust_level: str,
        account_type: str,
    ) -> dict[str, Any]:
        """Update an account's trust level (sandbox, active, verified).

        Args:
            entity_id: The account ID.
            trust_level: Target trust level.
            account_type: 'enterprise' or 'agent'.
        """
        return self._http.patch(
            f"/v1/admin/accounts/{entity_id}/trust-level",
            json={"trustLevel": trust_level, "accountType": account_type},
        )

    def get_system_health(self) -> dict[str, Any]:
        """Get system health metrics."""
        return self._http.get("/v1/admin/system-health")

    def deactivate_account(
        self,
        account_id: str,
        *,
        account_type: str,
        reason: str | None = None,
    ) -> dict[str, Any]:
        """Deactivate an account."""
        body: dict[str, Any] = {"accountType": account_type}
        if reason is not None:
            body["reason"] = reason
        return self._http.post(f"/v1/admin/accounts/{account_id}/deactivate", json=body)

    def list_api_keys(self, **params: Any) -> dict[str, Any]:
        """List API keys."""
        return self._http.get_page("/v1/admin/api-keys", params=params)

    def create_api_key(
        self,
        *,
        role: str,
        owner_id: str,
        owner_type: str,
        label: str | None = None,
        scopes: list[str] | None = None,
        scope_profile: str | None = None,
        expires_at: str | None = None,
        environment: str | None = None,
    ) -> dict[str, Any]:
        """Create an API key."""
        body: dict[str, Any] = {
            "role": role,
            "ownerId": owner_id,
            "ownerType": owner_type,
        }
        if label is not None:
            body["label"] = label
        if scopes is not None:
            body["scopes"] = scopes
        if scope_profile is not None:
            body["scopeProfile"] = scope_profile
        if expires_at is not None:
            body["expiresAt"] = expires_at
        if environment is not None:
            body["environment"] = environment
        return self._http.post("/v1/admin/api-keys", json=body)

    def toggle_api_key(self, key_id: str, *, is_active: bool) -> dict[str, Any]:
        """Enable or disable an API key."""
        return self._http.patch(f"/v1/admin/api-keys/{key_id}", json={"isActive": is_active})

    def bulk_revoke_api_keys(self, key_ids: list[str]) -> dict[str, Any]:
        """Revoke multiple API keys at once."""
        return self._http.post("/v1/admin/api-keys/bulk-revoke", json={"keyIds": key_ids})

    def set_capabilities(
        self,
        agent_id: str,
        *,
        contract_types: list[str],
    ) -> dict[str, Any]:
        """Set an agent's capabilities (PUT — replaces all)."""
        return self._http.put(
            f"/v1/admin/agents/{agent_id}/capabilities",
            json={"contractTypes": contract_types},
        )

    def get_fleet_capabilities(self, **params: Any) -> dict[str, Any]:
        """List capabilities across all agents."""
        return self._http.get_page("/v1/admin/agents/capabilities", params=params)

    def list_dlq(self, **params: Any) -> dict[str, Any]:
        """List webhook dead-letter queue entries."""
        return self._http.get_page("/v1/admin/webhook-dlq", params=params)

    def retry_dlq(self, dlq_id: str) -> dict[str, Any]:
        """Retry a single DLQ entry."""
        return self._http.post(f"/v1/admin/webhook-dlq/{dlq_id}/retry")

    def retry_all_dlq(self) -> dict[str, Any]:
        """Retry all DLQ entries."""
        return self._http.post("/v1/admin/webhook-dlq/retry-all")

    def get_license(self) -> dict[str, Any]:
        """Get license information."""
        return self._http.get("/v1/admin/license")

    def get_license_instance_id(self) -> dict[str, Any]:
        """Get the unique instance ID for this AGLedger installation."""
        return self._http.get("/v1/admin/license/instance-id")

    def reload_license(self) -> dict[str, Any]:
        """Re-read the license from environment/file and re-validate."""
        return self._http.post("/v1/admin/license/reload", json={})

    def get_scope_profiles(self) -> dict[str, Any]:
        """List all available scope profiles."""
        return self._http.get("/v1/admin/scope-profiles")

    def get_support_bundle(self) -> dict[str, Any]:
        """Download a diagnostic support bundle."""
        return self._http.get("/v1/admin/support-bundle")

    def upload_support_bundle(self) -> dict[str, Any]:
        """Upload a support bundle to AGLedger support."""
        return self._http.post("/v1/admin/support-bundle/upload", json={})

    def list_mandates(self, **params: Any) -> dict[str, Any]:
        """List mandates (admin view). Supports enterpriseId, status, contractType, agentId, sort, order, from, to."""
        return self._http.get_page("/v1/admin/mandates", params=params)

    def list_rate_limit_exemptions(self) -> dict[str, Any]:
        """List all IP addresses exempt from rate limiting."""
        return self._http.get_page("/v1/admin/rate-limit-exemptions/ips")

    def set_rate_limit_exemption(self, ip: str) -> dict[str, Any]:
        """Grant rate limit exemption to an IP address."""
        return self._http.put(f"/v1/admin/rate-limit-exemptions/ip/{ip}", json={})

    def delete_rate_limit_exemption(self, ip: str) -> dict[str, Any]:
        """Remove rate limit exemption from an IP address."""
        return self._http.delete(f"/v1/admin/rate-limit-exemptions/ip/{ip}")

    def get_webhook_health(self, **params: Any) -> dict[str, Any]:
        """Get health status of all webhooks."""
        return self._http.get_page("/v1/admin/webhooks/health", params=params)

    def update_circuit_breaker(self, webhook_id: str, *, state: str) -> dict[str, Any]:
        """Update a webhook's circuit breaker state (closed / open / half_open)."""
        return self._http.patch(f"/v1/admin/webhooks/{webhook_id}/circuit-breaker", json={"state": state})

    def list_vault_signing_keys(self) -> dict[str, Any]:
        """List vault signing keys."""
        return self._http.get("/v1/admin/vault/signing-keys")

    def rotate_vault_signing_key(self) -> dict[str, Any]:
        """Rotate the vault signing key."""
        return self._http.post("/v1/admin/vault/signing-keys/rotate", json={})

    def list_vault_anchors(self) -> dict[str, Any]:
        """List vault anchors."""
        return self._http.get("/v1/admin/vault/anchors")

    def verify_vault_anchors(self) -> dict[str, Any]:
        """Verify vault anchor integrity."""
        return self._http.post("/v1/admin/vault/anchors/verify", json={})

    def start_vault_scan(self) -> dict[str, Any]:
        """Start a vault integrity scan."""
        return self._http.post("/v1/admin/vault/scan", json={})

    def get_vault_scan_status(self, job_id: str) -> dict[str, Any]:
        """Get the status of a vault scan job."""
        return self._http.get(f"/v1/admin/vault/scan/{job_id}")

    def flush_auth_cache(self) -> dict[str, Any]:
        """Flush the authentication cache."""
        return self._http.post("/v1/admin/auth-cache/flush", json={})

    def get_auth_cache_stats(self) -> dict[str, Any]:
        """Get authentication cache statistics."""
        return self._http.get("/v1/admin/auth-cache/stats")

    def flush_schema_cache(self) -> dict[str, Any]:
        """Flush the schema cache."""
        return self._http.post("/v1/admin/schemas/cache/flush", json={})

    def list_owner_rate_limit_exemptions(self) -> dict[str, Any]:
        """List all owner-level rate limit exemptions."""
        return self._http.get("/v1/admin/rate-limit-exemptions")

    def set_owner_rate_limit_exemption(self, owner_id: str) -> dict[str, Any]:
        """Grant rate limit exemption to an owner."""
        return self._http.put(f"/v1/admin/rate-limit-exemptions/{owner_id}", json={})

    def delete_owner_rate_limit_exemption(self, owner_id: str) -> dict[str, Any]:
        """Remove rate limit exemption from an owner."""
        return self._http.delete(f"/v1/admin/rate-limit-exemptions/{owner_id}")


class AsyncAdminResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def list_enterprises(self, **params: Any) -> dict[str, Any]:
        """List all enterprises on the platform."""
        return await self._http.get_page("/v1/admin/enterprises", params=params)

    async def create_enterprise(
        self,
        *,
        name: str,
        slug: str | None = None,
    ) -> dict[str, Any]:
        """Create a new enterprise."""
        body: dict[str, Any] = {"name": name}
        if slug is not None:
            body["slug"] = slug
        return await self._http.post("/v1/admin/enterprises", json=body)

    async def list_agents(self, **params: Any) -> dict[str, Any]:
        """List all registered agents on the platform."""
        return await self._http.get_page("/v1/admin/agents", params=params)

    async def create_agent(
        self,
        *,
        name: str,
        slug: str | None = None,
        enterprise_id: str | None = None,
        email: str | None = None,
        trust_level: str | None = None,
        agent_card_url: str | None = None,
    ) -> dict[str, Any]:
        """Create a new agent."""
        body: dict[str, Any] = {"name": name}
        if slug is not None:
            body["slug"] = slug
        if enterprise_id is not None:
            body["enterpriseId"] = enterprise_id
        if email is not None:
            body["email"] = email
        if trust_level is not None:
            body["trustLevel"] = trust_level
        if agent_card_url is not None:
            body["agentCardUrl"] = agent_card_url
        return await self._http.post("/v1/admin/agents", json=body)

    async def get_enterprise_config(self, enterprise_id: str) -> dict[str, Any]:
        """Get an enterprise's configuration."""
        return await self._http.get(f"/v1/admin/enterprises/{enterprise_id}/config")

    async def replace_enterprise_config(
        self,
        enterprise_id: str,
        config: dict[str, Any],
    ) -> dict[str, Any]:
        """Replace an enterprise's configuration (desired-state, PUT semantics)."""
        return await self._http.put(f"/v1/admin/enterprises/{enterprise_id}/config", json=config)

    async def set_enterprise_config(
        self,
        enterprise_id: str,
        config: dict[str, Any],
    ) -> dict[str, Any]:
        """Deprecated: use :meth:`replace_enterprise_config` instead."""
        warnings.warn(
            "set_enterprise_config is deprecated, use replace_enterprise_config",
            DeprecationWarning,
            stacklevel=2,
        )
        return await self.replace_enterprise_config(enterprise_id, config)

    async def update_enterprise_config(
        self,
        enterprise_id: str,
        config: dict[str, Any],
    ) -> dict[str, Any]:
        """Partially update an enterprise's configuration (PATCH semantics)."""
        return await self._http.patch(f"/v1/admin/enterprises/{enterprise_id}/config", json=config)

    async def update_trust_level(
        self,
        entity_id: str,
        *,
        trust_level: str,
        account_type: str,
    ) -> dict[str, Any]:
        """Update an account's trust level (sandbox, active, verified)."""
        return await self._http.patch(
            f"/v1/admin/accounts/{entity_id}/trust-level",
            json={"trustLevel": trust_level, "accountType": account_type},
        )

    async def get_system_health(self) -> dict[str, Any]:
        """Get system health metrics."""
        return await self._http.get("/v1/admin/system-health")

    async def deactivate_account(
        self,
        account_id: str,
        *,
        account_type: str,
        reason: str | None = None,
    ) -> dict[str, Any]:
        """Deactivate an account."""
        body: dict[str, Any] = {"accountType": account_type}
        if reason is not None:
            body["reason"] = reason
        return await self._http.post(f"/v1/admin/accounts/{account_id}/deactivate", json=body)

    async def list_api_keys(self, **params: Any) -> dict[str, Any]:
        """List API keys."""
        return await self._http.get_page("/v1/admin/api-keys", params=params)

    async def create_api_key(
        self,
        *,
        role: str,
        owner_id: str,
        owner_type: str,
        label: str | None = None,
        scopes: list[str] | None = None,
        scope_profile: str | None = None,
        expires_at: str | None = None,
        environment: str | None = None,
    ) -> dict[str, Any]:
        """Create an API key."""
        body: dict[str, Any] = {
            "role": role,
            "ownerId": owner_id,
            "ownerType": owner_type,
        }
        if label is not None:
            body["label"] = label
        if scopes is not None:
            body["scopes"] = scopes
        if scope_profile is not None:
            body["scopeProfile"] = scope_profile
        if expires_at is not None:
            body["expiresAt"] = expires_at
        if environment is not None:
            body["environment"] = environment
        return await self._http.post("/v1/admin/api-keys", json=body)

    async def toggle_api_key(self, key_id: str, *, is_active: bool) -> dict[str, Any]:
        """Enable or disable an API key."""
        return await self._http.patch(f"/v1/admin/api-keys/{key_id}", json={"isActive": is_active})

    async def bulk_revoke_api_keys(self, key_ids: list[str]) -> dict[str, Any]:
        """Revoke multiple API keys at once."""
        return await self._http.post("/v1/admin/api-keys/bulk-revoke", json={"keyIds": key_ids})

    async def set_capabilities(
        self,
        agent_id: str,
        *,
        contract_types: list[str],
    ) -> dict[str, Any]:
        """Set an agent's capabilities (PUT — replaces all)."""
        return await self._http.put(
            f"/v1/admin/agents/{agent_id}/capabilities",
            json={"contractTypes": contract_types},
        )

    async def get_fleet_capabilities(self, **params: Any) -> dict[str, Any]:
        """List capabilities across all agents."""
        return await self._http.get_page("/v1/admin/agents/capabilities", params=params)

    async def list_dlq(self, **params: Any) -> dict[str, Any]:
        """List webhook dead-letter queue entries."""
        return await self._http.get_page("/v1/admin/webhook-dlq", params=params)

    async def retry_dlq(self, dlq_id: str) -> dict[str, Any]:
        """Retry a single DLQ entry."""
        return await self._http.post(f"/v1/admin/webhook-dlq/{dlq_id}/retry")

    async def retry_all_dlq(self) -> dict[str, Any]:
        """Retry all DLQ entries."""
        return await self._http.post("/v1/admin/webhook-dlq/retry-all")

    async def get_license(self) -> dict[str, Any]:
        """Get license information."""
        return await self._http.get("/v1/admin/license")

    async def get_license_instance_id(self) -> dict[str, Any]:
        """Get the unique instance ID for this AGLedger installation."""
        return await self._http.get("/v1/admin/license/instance-id")

    async def reload_license(self) -> dict[str, Any]:
        """Re-read the license from environment/file and re-validate."""
        return await self._http.post("/v1/admin/license/reload", json={})

    async def get_scope_profiles(self) -> dict[str, Any]:
        """List all available scope profiles."""
        return await self._http.get("/v1/admin/scope-profiles")

    async def get_support_bundle(self) -> dict[str, Any]:
        """Download a diagnostic support bundle."""
        return await self._http.get("/v1/admin/support-bundle")

    async def upload_support_bundle(self) -> dict[str, Any]:
        """Upload a support bundle to AGLedger support."""
        return await self._http.post("/v1/admin/support-bundle/upload", json={})

    async def list_mandates(self, **params: Any) -> dict[str, Any]:
        """List mandates (admin view)."""
        return await self._http.get_page("/v1/admin/mandates", params=params)

    async def list_rate_limit_exemptions(self) -> dict[str, Any]:
        """List all IP addresses exempt from rate limiting."""
        return await self._http.get_page("/v1/admin/rate-limit-exemptions/ips")

    async def set_rate_limit_exemption(self, ip: str) -> dict[str, Any]:
        """Grant rate limit exemption to an IP address."""
        return await self._http.put(f"/v1/admin/rate-limit-exemptions/ip/{ip}", json={})

    async def delete_rate_limit_exemption(self, ip: str) -> dict[str, Any]:
        """Remove rate limit exemption from an IP address."""
        return await self._http.delete(f"/v1/admin/rate-limit-exemptions/ip/{ip}")

    async def get_webhook_health(self, **params: Any) -> dict[str, Any]:
        """Get health status of all webhooks."""
        return await self._http.get_page("/v1/admin/webhooks/health", params=params)

    async def update_circuit_breaker(self, webhook_id: str, *, state: str) -> dict[str, Any]:
        """Update a webhook's circuit breaker state (closed / open / half_open)."""
        return await self._http.patch(f"/v1/admin/webhooks/{webhook_id}/circuit-breaker", json={"state": state})

    async def list_vault_signing_keys(self) -> dict[str, Any]:
        """List vault signing keys."""
        return await self._http.get("/v1/admin/vault/signing-keys")

    async def rotate_vault_signing_key(self) -> dict[str, Any]:
        """Rotate the vault signing key."""
        return await self._http.post("/v1/admin/vault/signing-keys/rotate", json={})

    async def list_vault_anchors(self) -> dict[str, Any]:
        """List vault anchors."""
        return await self._http.get("/v1/admin/vault/anchors")

    async def verify_vault_anchors(self) -> dict[str, Any]:
        """Verify vault anchor integrity."""
        return await self._http.post("/v1/admin/vault/anchors/verify", json={})

    async def start_vault_scan(self) -> dict[str, Any]:
        """Start a vault integrity scan."""
        return await self._http.post("/v1/admin/vault/scan", json={})

    async def get_vault_scan_status(self, job_id: str) -> dict[str, Any]:
        """Get the status of a vault scan job."""
        return await self._http.get(f"/v1/admin/vault/scan/{job_id}")

    async def flush_auth_cache(self) -> dict[str, Any]:
        """Flush the authentication cache."""
        return await self._http.post("/v1/admin/auth-cache/flush", json={})

    async def get_auth_cache_stats(self) -> dict[str, Any]:
        """Get authentication cache statistics."""
        return await self._http.get("/v1/admin/auth-cache/stats")

    async def flush_schema_cache(self) -> dict[str, Any]:
        """Flush the schema cache."""
        return await self._http.post("/v1/admin/schemas/cache/flush", json={})

    async def list_owner_rate_limit_exemptions(self) -> dict[str, Any]:
        """List all owner-level rate limit exemptions."""
        return await self._http.get("/v1/admin/rate-limit-exemptions")

    async def set_owner_rate_limit_exemption(self, owner_id: str) -> dict[str, Any]:
        """Grant rate limit exemption to an owner."""
        return await self._http.put(f"/v1/admin/rate-limit-exemptions/{owner_id}", json={})

    async def delete_owner_rate_limit_exemption(self, owner_id: str) -> dict[str, Any]:
        """Remove rate limit exemption from an owner."""
        return await self._http.delete(f"/v1/admin/rate-limit-exemptions/{owner_id}")
