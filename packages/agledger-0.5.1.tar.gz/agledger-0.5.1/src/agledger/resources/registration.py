"""Registration resource."""

from __future__ import annotations

from typing import Any

from agledger._http import AsyncHttpClient, HttpClient
from agledger.types import AccountProfile, RegisterResult


class RegistrationResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def register(self, *, role: str, name: str, email: str, contact_email: str | None = None) -> RegisterResult:
        """Register a new account. Sends {role, name, email} to the API."""
        body: dict[str, Any] = {"role": role, "name": name, "email": email}
        if contact_email is not None:
            body["contactEmail"] = contact_email
        return RegisterResult.model_validate(self._http.post("/v1/auth/register", json=body))

    def get_me(self) -> AccountProfile:
        return AccountProfile.model_validate(self._http.get("/v1/auth/me"))

    def verify_email(self, token: str) -> dict[str, Any]:
        """Verify an email address using a verification token."""
        return self._http.get("/v1/auth/verify", params={"token": token})

    def send_verification_email(self, email: str) -> dict[str, Any]:
        """Send (or re-send) a verification email."""
        return self._http.post("/v1/auth/verify-email", json={"email": email})

    def register_enterprise(self, *, name: str, email: str | None = None) -> RegisterResult:
        """Register a new enterprise account."""
        body: dict[str, Any] = {"name": name}
        if email is not None:
            body["email"] = email
        return RegisterResult.model_validate(self._http.post("/v1/auth/enterprise", json=body))

    def register_agent(
        self,
        *,
        name: str,
        email: str | None = None,
        agent_card_url: str | None = None,
        enterprise_id: str | None = None,
    ) -> RegisterResult:
        """Register a new agent account."""
        body: dict[str, Any] = {"name": name}
        if email is not None:
            body["email"] = email
        if agent_card_url is not None:
            body["agentCardUrl"] = agent_card_url
        if enterprise_id is not None:
            body["enterpriseId"] = enterprise_id
        return RegisterResult.model_validate(self._http.post("/v1/auth/agent", json=body))

    def rotate_api_key(self) -> dict[str, Any]:
        """Rotate the current API key."""
        return self._http.post("/v1/auth/keys/rotate")

    def verify_agent_card(self, agent_card_url: str) -> dict[str, Any]:
        """Verify an agent card URL."""
        return self._http.post("/v1/auth/verify-agent-card", json={"agentCardUrl": agent_card_url})


class AsyncRegistrationResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def register(self, *, role: str, name: str, email: str, contact_email: str | None = None) -> RegisterResult:
        """Register a new account. Sends {role, name, email} to the API."""
        body: dict[str, Any] = {"role": role, "name": name, "email": email}
        if contact_email is not None:
            body["contactEmail"] = contact_email
        return RegisterResult.model_validate(await self._http.post("/v1/auth/register", json=body))

    async def get_me(self) -> AccountProfile:
        return AccountProfile.model_validate(await self._http.get("/v1/auth/me"))

    async def verify_email(self, token: str) -> dict[str, Any]:
        """Verify an email address using a verification token."""
        return await self._http.get("/v1/auth/verify", params={"token": token})

    async def send_verification_email(self, email: str) -> dict[str, Any]:
        """Send (or re-send) a verification email."""
        return await self._http.post("/v1/auth/verify-email", json={"email": email})

    async def register_enterprise(self, *, name: str, email: str | None = None) -> RegisterResult:
        """Register a new enterprise account."""
        body: dict[str, Any] = {"name": name}
        if email is not None:
            body["email"] = email
        return RegisterResult.model_validate(await self._http.post("/v1/auth/enterprise", json=body))

    async def register_agent(
        self,
        *,
        name: str,
        email: str | None = None,
        agent_card_url: str | None = None,
        enterprise_id: str | None = None,
    ) -> RegisterResult:
        """Register a new agent account."""
        body: dict[str, Any] = {"name": name}
        if email is not None:
            body["email"] = email
        if agent_card_url is not None:
            body["agentCardUrl"] = agent_card_url
        if enterprise_id is not None:
            body["enterpriseId"] = enterprise_id
        return RegisterResult.model_validate(await self._http.post("/v1/auth/agent", json=body))

    async def rotate_api_key(self) -> dict[str, Any]:
        """Rotate the current API key."""
        return await self._http.post("/v1/auth/keys/rotate")

    async def verify_agent_card(self, agent_card_url: str) -> dict[str, Any]:
        """Verify an agent card URL."""
        return await self._http.post("/v1/auth/verify-agent-card", json={"agentCardUrl": agent_card_url})
