"""Unit tests for trackline_mcp.client."""

import json
import time
from unittest.mock import MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# CLI arg parsing
# ---------------------------------------------------------------------------


class TestCLIArgParsing:
    """Tests for argument parser configuration."""

    def test_auth_flag_exists(self):
        """--auth flag triggers interactive device flow."""
        from trackline_mcp.client import build_parser

        parser = build_parser()
        args = parser.parse_args(["--auth"])
        assert args.auth is True

    def test_auth_flag_default_false(self):
        """--auth defaults to False."""
        from trackline_mcp.client import build_parser

        parser = build_parser()
        args = parser.parse_args([])
        assert args.auth is False

    def test_auth_url_arg(self):
        """--auth-url CLI arg is accepted."""
        from trackline_mcp.client import build_parser

        parser = build_parser()
        args = parser.parse_args(["--auth-url", "https://custom.auth"])
        assert args.auth_url == "https://custom.auth"

    def test_mcp_url_arg(self):
        """--mcp-url CLI arg is accepted."""
        from trackline_mcp.client import build_parser

        parser = build_parser()
        args = parser.parse_args(["--mcp-url", "https://custom.mcp/sse"])
        assert args.mcp_url == "https://custom.mcp/sse"

    def test_auth_url_default_none(self):
        """--auth-url defaults to None (falls back to env/hardcoded)."""
        from trackline_mcp.client import build_parser

        parser = build_parser()
        args = parser.parse_args([])
        assert args.auth_url is None

    def test_mcp_url_default_none(self):
        """--mcp-url defaults to None (falls back to env/hardcoded)."""
        from trackline_mcp.client import build_parser

        parser = build_parser()
        args = parser.parse_args([])
        assert args.mcp_url is None


# ---------------------------------------------------------------------------
# URL resolution (CLI arg > env var > hardcoded default)
# ---------------------------------------------------------------------------


class TestURLResolution:
    """Tests for resolve_auth_url and resolve_mcp_url config priority."""

    def test_resolve_auth_url_cli_overrides_env(self, monkeypatch):
        """CLI arg takes priority over environment variable."""
        from trackline_mcp.client import resolve_auth_url

        monkeypatch.setenv("TRACKLINE_AUTH_URL", "https://env.auth")
        result = resolve_auth_url(cli_arg="https://cli.auth")
        assert result == "https://cli.auth"

    def test_resolve_auth_url_env_overrides_default(self, monkeypatch):
        """Env var takes priority over hardcoded default."""
        from trackline_mcp.client import resolve_auth_url

        monkeypatch.setenv("TRACKLINE_AUTH_URL", "https://env.auth")
        result = resolve_auth_url(cli_arg=None)
        assert result == "https://env.auth"

    def test_resolve_auth_url_hardcoded_default(self, monkeypatch):
        """Falls back to hardcoded default when no CLI or env."""
        from trackline_mcp.client import DEFAULT_AUTH_URL, resolve_auth_url

        monkeypatch.delenv("TRACKLINE_AUTH_URL", raising=False)
        result = resolve_auth_url(cli_arg=None)
        assert result == DEFAULT_AUTH_URL

    def test_resolve_mcp_url_cli_overrides_env(self, monkeypatch):
        """CLI arg takes priority over environment variable."""
        from trackline_mcp.client import resolve_mcp_url

        monkeypatch.setenv("TRACKLINE_MCP_URL", "https://env.mcp/sse")
        result = resolve_mcp_url(cli_arg="https://cli.mcp/sse")
        assert result == "https://cli.mcp/sse"

    def test_resolve_mcp_url_env_overrides_default(self, monkeypatch):
        """Env var takes priority over hardcoded default."""
        from trackline_mcp.client import resolve_mcp_url

        monkeypatch.setenv("TRACKLINE_MCP_URL", "https://env.mcp/sse")
        result = resolve_mcp_url(cli_arg=None)
        assert result == "https://env.mcp/sse"

    def test_resolve_mcp_url_hardcoded_default(self, monkeypatch):
        """Falls back to hardcoded default when no CLI or env."""
        from trackline_mcp.client import DEFAULT_MCP_URL, resolve_mcp_url

        monkeypatch.delenv("TRACKLINE_MCP_URL", raising=False)
        result = resolve_mcp_url(cli_arg=None)
        assert result == DEFAULT_MCP_URL

    def test_old_env_var_not_used(self, monkeypatch):
        """PYRAIL_AUTH_URL is NOT picked up (renamed to TRACKLINE_AUTH_URL)."""
        from trackline_mcp.client import DEFAULT_AUTH_URL, resolve_auth_url

        monkeypatch.setenv("PYRAIL_AUTH_URL", "https://old.env")
        monkeypatch.delenv("TRACKLINE_AUTH_URL", raising=False)
        result = resolve_auth_url(cli_arg=None)
        assert result == DEFAULT_AUTH_URL


# ---------------------------------------------------------------------------
# Token cache — read/write/expiry
# ---------------------------------------------------------------------------


class TestTokenCache:
    """Tests for token file read, write, and expiry logic."""

    def test_save_token_writes_access_token(self, tmp_path):
        """_save_token writes access_token and expires_at to TOKEN_FILE."""
        from trackline_mcp import client

        orig_token_file = client.TOKEN_FILE
        client.TOKEN_FILE = tmp_path / "token.json"
        try:
            client._save_token({"access_token": "acc123", "expires_in": 300})
            data = json.loads(client.TOKEN_FILE.read_text())
            assert data["access_token"] == "acc123"
            assert data["expires_at"] > time.time()
        finally:
            client.TOKEN_FILE = orig_token_file

    def test_save_token_writes_refresh_token(self, tmp_path):
        """_save_token writes refresh_token when present."""
        from trackline_mcp import client

        orig_token_file = client.TOKEN_FILE
        client.TOKEN_FILE = tmp_path / "token.json"
        try:
            client._save_token(
                {
                    "access_token": "acc123",
                    "expires_in": 300,
                    "refresh_token": "ref456",
                    "refresh_expires_in": 1800,
                }
            )
            data = json.loads(client.TOKEN_FILE.read_text())
            assert data["refresh_token"] == "ref456"
            assert data["refresh_token_expires"] > time.time()
        finally:
            client.TOKEN_FILE = orig_token_file

    def test_save_token_sets_permissions(self, tmp_path):
        """_save_token sets file permissions to 0o600 (owner read/write only)."""
        from trackline_mcp import client

        orig_token_file = client.TOKEN_FILE
        client.TOKEN_FILE = tmp_path / "token.json"
        try:
            client._save_token({"access_token": "acc", "expires_in": 300})
            # On Windows chmod is largely a no-op, so just check file exists
            assert client.TOKEN_FILE.exists()
        finally:
            client.TOKEN_FILE = orig_token_file

    def test_get_token_returns_cached_valid(self, tmp_path):
        """get_token returns cached access_token if not expired."""
        from trackline_mcp import client

        orig_token_file = client.TOKEN_FILE
        client.TOKEN_FILE = tmp_path / "token.json"
        try:
            cache = {"access_token": "valid_tok", "expires_at": time.time() + 600}
            client.TOKEN_FILE.write_text(json.dumps(cache))
            tok = client.get_token()
            assert tok == "valid_tok"
        finally:
            client.TOKEN_FILE = orig_token_file

    def test_get_token_refreshes_when_expired(self, tmp_path):
        """get_token calls refresh when access token is expired but refresh token exists."""
        from trackline_mcp import client

        orig_token_file = client.TOKEN_FILE
        client.TOKEN_FILE = tmp_path / "token.json"
        try:
            cache = {
                "access_token": "expired_tok",
                "expires_at": time.time() - 10,
                "refresh_token": "ref_tok",
                "refresh_token_expires": time.time() + 3600,
            }
            client.TOKEN_FILE.write_text(json.dumps(cache))
            with patch.object(client, "_try_refresh", return_value="new_tok"):
                tok = client.get_token()
            assert tok == "new_tok"
        finally:
            client.TOKEN_FILE = orig_token_file

    def test_get_token_device_flow_when_no_cache(self, tmp_path):
        """get_token falls back to device flow when no cache file exists."""
        from trackline_mcp import client

        orig_token_file = client.TOKEN_FILE
        client.TOKEN_FILE = tmp_path / "no_token.json"
        try:
            with patch.object(client, "_device_flow", return_value="device_tok"):
                tok = client.get_token()
            assert tok == "device_tok"
        finally:
            client.TOKEN_FILE = orig_token_file


# ---------------------------------------------------------------------------
# URL parsing helper
# ---------------------------------------------------------------------------


class TestParseURL:
    """Tests for _parse_url."""

    def test_https_default_port(self):
        from trackline_mcp.client import _parse_url

        scheme, host, port, path = _parse_url("https://example.com/sse")
        assert scheme == "https"
        assert host == "example.com"
        assert port == 443
        assert path == "/sse"

    def test_http_default_port(self):
        from trackline_mcp.client import _parse_url

        scheme, host, port, path = _parse_url("http://example.com/sse")
        assert scheme == "http"
        assert port == 80

    def test_custom_port(self):
        from trackline_mcp.client import _parse_url

        _, _, port, _ = _parse_url("https://example.com:8443/path")
        assert port == 8443

    def test_query_string_preserved(self):
        from trackline_mcp.client import _parse_url

        _, _, _, path = _parse_url("https://example.com/sse?token=abc")
        assert "token=abc" in path

    def test_path_defaults_to_slash(self):
        from trackline_mcp.client import _parse_url

        _, _, _, path = _parse_url("https://example.com")
        assert path == "/"


# ---------------------------------------------------------------------------
# SSE event parsing
# ---------------------------------------------------------------------------


class TestSSEParsing:
    """Tests for the SSE event parsing logic in run_bridge."""

    def test_parse_sse_lines_endpoint_event(self):
        """endpoint event stores the messages path."""
        from trackline_mcp.client import _process_sse_event

        holder: list = []
        _process_sse_event(
            event_type="endpoint",
            data="/messages?session=123",
            mcp_url="https://example.com/sse",
            messages_path_holder=holder,
            stdout_buffer=None,
        )
        assert holder == ["/messages?session=123"]

    def test_parse_sse_lines_message_event(self):
        """message event writes JSON to stdout buffer."""
        from trackline_mcp.client import _process_sse_event

        buf = MagicMock()
        _process_sse_event(
            event_type="message",
            data='{"jsonrpc":"2.0","id":1,"result":{}}',
            mcp_url="https://example.com/sse",
            messages_path_holder=["/msgs"],
            stdout_buffer=buf,
        )
        buf.write.assert_called_once()
        written = buf.write.call_args[0][0]
        assert b"jsonrpc" in written

    def test_parse_sse_empty_data_ignored(self):
        """Empty data on message event does not write to stdout."""
        from trackline_mcp.client import _process_sse_event

        buf = MagicMock()
        _process_sse_event(
            event_type="message",
            data="",
            mcp_url="https://example.com/sse",
            messages_path_holder=["/msgs"],
            stdout_buffer=buf,
        )
        buf.write.assert_not_called()


# ---------------------------------------------------------------------------
# Device flow scope includes offline_access
# ---------------------------------------------------------------------------


class TestDeviceFlowScope:
    """Ensure offline_access is in the device flow scope."""

    def test_device_flow_scope_includes_offline_access(self):
        """The device auth scope must include offline_access."""
        from trackline_mcp.client import DEVICE_FLOW_SCOPE

        assert "offline_access" in DEVICE_FLOW_SCOPE


# ---------------------------------------------------------------------------
# Error messages reference uvx trackline-mcp
# ---------------------------------------------------------------------------


class TestErrorMessages:
    """Ensure error messages reference the correct CLI command."""

    def test_expired_token_message_references_uvx(self, tmp_path):
        """When token is expired and refresh fails, message references uvx trackline-mcp --auth."""
        from trackline_mcp import client

        orig_token_file = client.TOKEN_FILE
        client.TOKEN_FILE = tmp_path / "token.json"
        try:
            cache = {
                "access_token": "old",
                "expires_at": time.time() - 10,
            }
            client.TOKEN_FILE.write_text(json.dumps(cache))

            stderr_output = []
            with (
                patch.object(client, "_device_flow", side_effect=SystemExit(1)),
                patch("sys.stderr", MagicMock(write=lambda s: stderr_output.append(s))),
            ):
                try:
                    client._get_token_non_interactive()
                except SystemExit:
                    pass

            full_stderr = "".join(stderr_output)
            assert "uvx trackline-mcp" in full_stderr
        finally:
            client.TOKEN_FILE = orig_token_file

    def test_no_cache_message_references_uvx(self, tmp_path):
        """When no token file, message references uvx trackline-mcp --auth."""
        from trackline_mcp import client

        orig_token_file = client.TOKEN_FILE
        client.TOKEN_FILE = tmp_path / "no_token.json"
        try:
            stderr_output = []
            with (
                patch("sys.stderr", MagicMock(write=lambda s: stderr_output.append(s))),
            ):
                try:
                    client._get_token_non_interactive()
                except SystemExit:
                    pass

            full_stderr = "".join(stderr_output)
            assert "uvx trackline-mcp" in full_stderr
        finally:
            client.TOKEN_FILE = orig_token_file


# ---------------------------------------------------------------------------
# main() entry point
# ---------------------------------------------------------------------------


class TestMainEntryPoint:
    """Tests for main() function."""

    def test_main_auth_mode_calls_device_flow(self):
        """main() with --auth calls _device_flow and exits."""
        from trackline_mcp.client import main

        with (
            patch("sys.argv", ["trackline-mcp", "--auth"]),
            patch("trackline_mcp.client._device_flow", return_value="tok") as mock_flow,
            patch("sys.exit", side_effect=SystemExit(0)),
        ):
            with pytest.raises(SystemExit):
                main()
        mock_flow.assert_called_once()

    def test_main_runs_bridge_in_non_auth_mode(self):
        """main() without --auth calls _get_token_non_interactive and run_bridge."""
        from trackline_mcp.client import main

        with (
            patch("sys.argv", ["trackline-mcp"]),
            patch("trackline_mcp.client._get_token_non_interactive", return_value="tok"),
            patch("trackline_mcp.client.run_bridge") as mock_bridge,
        ):
            main()

        assert mock_bridge.call_count == 1
        assert mock_bridge.call_args[0][0] == "tok"


# ---------------------------------------------------------------------------
# _post helper
# ---------------------------------------------------------------------------


class TestPostHelper:
    """Tests for the _post HTTP utility."""

    def test_post_returns_parsed_json(self):
        """_post returns parsed JSON from the response."""
        from trackline_mcp.client import _post

        mock_response = MagicMock()
        mock_response.read.return_value = b'{"access_token": "abc"}'
        mock_response.__enter__ = lambda s: s
        mock_response.__exit__ = MagicMock(return_value=False)

        with patch("urllib.request.urlopen", return_value=mock_response):
            result = _post("https://example.com/token", {"grant_type": "device_code"})

        assert result == {"access_token": "abc"}

    def test_post_sends_url_encoded_body(self):
        """_post encodes data as application/x-www-form-urlencoded."""
        from trackline_mcp.client import _post

        mock_response = MagicMock()
        mock_response.read.return_value = b"{}"
        mock_response.__enter__ = lambda s: s
        mock_response.__exit__ = MagicMock(return_value=False)

        captured_request = []

        def capture_urlopen(req, timeout):
            captured_request.append(req)
            return mock_response

        with patch("urllib.request.urlopen", side_effect=capture_urlopen):
            _post("https://example.com/token", {"key": "val"})

        assert captured_request[0].get_header("Content-type") == "application/x-www-form-urlencoded"


# ---------------------------------------------------------------------------
# _try_refresh
# ---------------------------------------------------------------------------


class TestTryRefresh:
    """Tests for _try_refresh."""

    def test_try_refresh_returns_access_token_on_success(self, tmp_path):
        """_try_refresh returns new access token on successful refresh."""
        from trackline_mcp import client

        orig = client.TOKEN_FILE
        client.TOKEN_FILE = tmp_path / "token.json"
        try:
            with patch.object(
                client,
                "_post",
                return_value={"access_token": "new_tok", "expires_in": 300},
            ):
                result = client._try_refresh("old_refresh_tok")
            assert result == "new_tok"
        finally:
            client.TOKEN_FILE = orig

    def test_try_refresh_returns_none_on_failure(self):
        """_try_refresh returns None when network call raises."""
        from trackline_mcp import client

        with patch.object(client, "_post", side_effect=Exception("Network error")):
            result = client._try_refresh("bad_tok")
        assert result is None


# ---------------------------------------------------------------------------
# get_token — additional paths
# ---------------------------------------------------------------------------


class TestGetTokenAdditional:
    """Additional get_token path coverage."""

    def test_get_token_falls_back_to_device_flow_when_refresh_fails(self, tmp_path):
        """get_token falls back to device flow when refresh returns None."""
        from trackline_mcp import client

        orig = client.TOKEN_FILE
        client.TOKEN_FILE = tmp_path / "token.json"
        try:
            cache = {
                "access_token": "expired",
                "expires_at": time.time() - 10,
                "refresh_token": "bad_refresh",
            }
            client.TOKEN_FILE.write_text(json.dumps(cache))
            with (
                patch.object(client, "_try_refresh", return_value=None),
                patch.object(client, "_device_flow", return_value="device_tok"),
            ):
                tok = client.get_token()
            assert tok == "device_tok"
        finally:
            client.TOKEN_FILE = orig

    def test_get_token_handles_corrupt_cache(self, tmp_path):
        """get_token falls back to device flow when cache file is corrupt JSON."""
        from trackline_mcp import client

        orig = client.TOKEN_FILE
        client.TOKEN_FILE = tmp_path / "token.json"
        try:
            client.TOKEN_FILE.write_text("not valid json{{{")
            with patch.object(client, "_device_flow", return_value="device_tok"):
                tok = client.get_token()
            assert tok == "device_tok"
        finally:
            client.TOKEN_FILE = orig


# ---------------------------------------------------------------------------
# _get_token_non_interactive — additional paths
# ---------------------------------------------------------------------------


class TestGetTokenNonInteractiveAdditional:
    """Additional coverage for _get_token_non_interactive."""

    def test_valid_cached_token_returned(self, tmp_path):
        """Returns valid cached token directly."""
        from trackline_mcp import client

        orig = client.TOKEN_FILE
        client.TOKEN_FILE = tmp_path / "token.json"
        try:
            cache = {"access_token": "valid", "expires_at": time.time() + 600}
            client.TOKEN_FILE.write_text(json.dumps(cache))
            tok = client._get_token_non_interactive()
            assert tok == "valid"
        finally:
            client.TOKEN_FILE = orig

    def test_refresh_token_used_when_access_expired(self, tmp_path):
        """Uses refresh token when access token is expired."""
        from trackline_mcp import client

        orig = client.TOKEN_FILE
        client.TOKEN_FILE = tmp_path / "token.json"
        try:
            cache = {
                "access_token": "expired",
                "expires_at": time.time() - 10,
                "refresh_token": "valid_refresh",
            }
            client.TOKEN_FILE.write_text(json.dumps(cache))
            with patch.object(client, "_try_refresh", return_value="refreshed_tok"):
                tok = client._get_token_non_interactive()
            assert tok == "refreshed_tok"
        finally:
            client.TOKEN_FILE = orig

    def test_exits_when_refresh_also_fails(self, tmp_path):
        """sys.exit(1) called when both access and refresh tokens fail."""
        from trackline_mcp import client

        orig = client.TOKEN_FILE
        client.TOKEN_FILE = tmp_path / "token.json"
        try:
            cache = {
                "access_token": "expired",
                "expires_at": time.time() - 10,
                "refresh_token": "bad_refresh",
            }
            client.TOKEN_FILE.write_text(json.dumps(cache))
            with (
                patch.object(client, "_try_refresh", return_value=None),
                pytest.raises(SystemExit),
            ):
                client._get_token_non_interactive()
        finally:
            client.TOKEN_FILE = orig


# ---------------------------------------------------------------------------
# _device_flow — mocked paths
# ---------------------------------------------------------------------------


class TestDeviceFlow:
    """Tests for _device_flow with mocked network calls."""

    def _make_device_resp(self, include_complete_uri=True):
        resp = {
            "device_code": "dev_code_123",
            "user_code": "ABCD-1234",
            "verification_uri": "https://auth.trackline.live/activate",
            "expires_in": 300,
            "interval": 0,
        }
        if include_complete_uri:
            resp["verification_uri_complete"] = (
                "https://auth.trackline.live/activate?code=ABCD-1234"
            )
        return resp

    def test_device_flow_success_on_first_poll(self, tmp_path):
        """_device_flow returns access token when poll succeeds immediately."""
        from trackline_mcp import client

        orig = client.TOKEN_FILE
        client.TOKEN_FILE = tmp_path / "token.json"
        try:
            device_resp = self._make_device_resp()
            token_resp = {"access_token": "access123", "expires_in": 300}

            post_calls = [device_resp, token_resp]
            with patch.object(client, "_post", side_effect=post_calls):
                result = client._device_flow()
            assert result == "access123"
        finally:
            client.TOKEN_FILE = orig

    def test_device_flow_shows_user_code_without_complete_uri(self, tmp_path, capsys):
        """_device_flow prints user code when verification_uri_complete not provided."""
        from trackline_mcp import client

        orig = client.TOKEN_FILE
        client.TOKEN_FILE = tmp_path / "token.json"
        try:
            device_resp = self._make_device_resp(include_complete_uri=False)
            token_resp = {"access_token": "tok", "expires_in": 300}

            with patch.object(client, "_post", side_effect=[device_resp, token_resp]):
                client._device_flow()

            captured = capsys.readouterr()
            assert "ABCD-1234" in captured.err
        finally:
            client.TOKEN_FILE = orig

    def test_device_flow_retries_on_authorization_pending(self, tmp_path):
        """_device_flow retries when authorization_pending is returned."""
        import urllib.error

        from trackline_mcp import client

        orig = client.TOKEN_FILE
        client.TOKEN_FILE = tmp_path / "token.json"
        try:
            device_resp = self._make_device_resp()
            token_resp = {"access_token": "final_tok", "expires_in": 300}

            # Build a fake HTTPError for authorization_pending
            pending_body = json.dumps({"error": "authorization_pending"}).encode()
            pending_err = urllib.error.HTTPError(
                url="",
                code=400,
                msg="Bad Request",
                hdrs=None,
                fp=MagicMock(read=lambda: pending_body),  # type: ignore
            )
            pending_err.read = lambda: pending_body

            post_calls = iter([device_resp, pending_err, token_resp])

            def mock_post(url, data):
                val = next(post_calls)
                if isinstance(val, Exception):
                    raise val
                return val

            with patch.object(client, "_post", side_effect=mock_post):
                result = client._device_flow()
            assert result == "final_tok"
        finally:
            client.TOKEN_FILE = orig

    def test_device_flow_exits_on_unknown_error(self, tmp_path):
        """_device_flow sys.exit(1) on unexpected auth error."""
        import urllib.error

        from trackline_mcp import client

        orig = client.TOKEN_FILE
        client.TOKEN_FILE = tmp_path / "token.json"
        try:
            device_resp = self._make_device_resp()

            err_body = json.dumps(
                {"error": "access_denied", "error_description": "User denied"}
            ).encode()
            http_err = urllib.error.HTTPError(
                url="",
                code=400,
                msg="Bad Request",
                hdrs=None,
                fp=None,  # type: ignore
            )
            http_err.read = lambda: err_body

            with (
                patch.object(client, "_post", side_effect=[device_resp, http_err]),
                pytest.raises(SystemExit),
            ):
                client._device_flow()
        finally:
            client.TOKEN_FILE = orig

    def test_device_flow_exits_on_timeout(self, tmp_path):
        """_device_flow sys.exit(1) when deadline expires without auth."""
        from trackline_mcp import client

        orig = client.TOKEN_FILE
        client.TOKEN_FILE = tmp_path / "token.json"
        try:
            device_resp = {
                "device_code": "dev_code",
                "user_code": "CODE",
                "verification_uri": "https://example.com",
                "verification_uri_complete": "https://example.com?code=CODE",
                "expires_in": 0,
                "interval": 0,
            }
            with (
                patch.object(client, "_post", return_value=device_resp),
                pytest.raises(SystemExit),
            ):
                client._device_flow()
        finally:
            client.TOKEN_FILE = orig

    def test_device_flow_slow_down_increases_interval(self, tmp_path):
        """_device_flow increases polling interval on slow_down and then succeeds."""
        import urllib.error

        from trackline_mcp import client

        orig = client.TOKEN_FILE
        client.TOKEN_FILE = tmp_path / "token.json"
        try:
            device_resp = self._make_device_resp()
            token_resp = {"access_token": "slow_tok", "expires_in": 300}

            slow_body = json.dumps({"error": "slow_down"}).encode()
            slow_err = urllib.error.HTTPError(
                url="",
                code=400,
                msg="Slow Down",
                hdrs=None,
                fp=None,  # type: ignore
            )
            slow_err.read = lambda: slow_body

            intervals_seen = []

            post_calls = iter([device_resp, slow_err, token_resp])

            def mock_post(url, data):
                val = next(post_calls)
                if isinstance(val, Exception):
                    raise val
                return val

            # Capture the interval at each sleep call
            def mock_sleep(n):
                intervals_seen.append(n)

            with (
                patch.object(client, "_post", side_effect=mock_post),
                patch("time.sleep", side_effect=mock_sleep),
            ):
                result = client._device_flow()

            assert result == "slow_tok"
            # After slow_down, interval should increase by 5
            assert len(intervals_seen) >= 2
            assert intervals_seen[1] > intervals_seen[0]
        finally:
            client.TOKEN_FILE = orig


# ---------------------------------------------------------------------------
# _make_conn
# ---------------------------------------------------------------------------


class TestMakeConn:
    """Tests for _make_conn."""

    def test_make_conn_https_returns_https_connection(self):
        from trackline_mcp.client import _make_conn

        conn = _make_conn("https", "example.com", 443)
        assert isinstance(
            conn, __import__("http.client", fromlist=["HTTPSConnection"]).HTTPSConnection
        )

    def test_make_conn_http_returns_http_connection(self):
        from trackline_mcp.client import _make_conn

        conn = _make_conn("http", "example.com", 80)
        assert isinstance(
            conn, __import__("http.client", fromlist=["HTTPConnection"]).HTTPConnection
        )


# ---------------------------------------------------------------------------
# _post_message
# ---------------------------------------------------------------------------


class TestPostMessage:
    """Tests for _post_message."""

    def test_post_message_sends_body(self):
        """_post_message POSTs the body to the given path."""
        from trackline_mcp.client import _post_message

        mock_conn = MagicMock()
        mock_conn.getresponse.return_value = MagicMock(read=MagicMock(return_value=b""))

        with patch("trackline_mcp.client._make_conn", return_value=mock_conn):
            _post_message("https://example.com/sse", "/messages", "tok", b'{"id":1}')

        mock_conn.request.assert_called_once()
        call_kwargs = mock_conn.request.call_args
        assert call_kwargs[0][0] == "POST"
        assert call_kwargs[0][1] == "/messages"

    def test_post_message_handles_exception(self, capsys):
        """_post_message prints error and does not raise on exception."""
        from trackline_mcp.client import _post_message

        mock_conn = MagicMock()
        mock_conn.request.side_effect = Exception("connection refused")

        with patch("trackline_mcp.client._make_conn", return_value=mock_conn):
            _post_message("https://example.com/sse", "/messages", "tok", b"{}")

        captured = capsys.readouterr()
        assert "POST error" in captured.err


# ---------------------------------------------------------------------------
# run_bridge — basic paths
# ---------------------------------------------------------------------------


class TestRunBridge:
    """Tests for run_bridge with mocked HTTP connections."""

    def _make_mock_conn(self, sse_lines, status=200):
        """Build a mock HTTPConnection whose SSE stream returns given lines then EOF."""
        mock_resp = MagicMock()
        mock_resp.status = status
        mock_resp.read.return_value = b"error body"

        # fp.readline() returns lines one at a time then b""
        line_iter = iter(sse_lines + [b""])
        mock_resp.fp = MagicMock()
        mock_resp.fp.readline.side_effect = lambda: next(line_iter, b"")

        mock_conn = MagicMock()
        mock_conn.getresponse.return_value = mock_resp
        return mock_conn, mock_resp

    def test_run_bridge_exits_on_non_200(self):
        """run_bridge calls sys.exit when SSE server returns non-200."""
        from trackline_mcp.client import run_bridge

        mock_conn, _ = self._make_mock_conn([], status=401)

        with (
            patch("trackline_mcp.client._make_conn", return_value=mock_conn),
            pytest.raises(SystemExit),
        ):
            run_bridge("tok", "http://localhost/sse")

    def test_run_bridge_processes_sse_stream(self):
        """run_bridge parses SSE lines and dispatches events."""
        import io

        from trackline_mcp.client import run_bridge

        sse_lines = [
            b"event: endpoint\n",
            b"data: /messages?session=1\n",
            b"\n",
            b"event: message\n",
            b'data: {"jsonrpc":"2.0","id":1,"result":{}}\n',
            b"\n",
        ]
        mock_conn, _ = self._make_mock_conn(sse_lines, status=200)
        stdout_capture = io.BytesIO()
        stdin_mock = io.BytesIO(b"")  # empty stdin so _stdin_pump exits cleanly

        with (
            patch("trackline_mcp.client._make_conn", return_value=mock_conn),
            patch("sys.stdout") as mock_stdout,
            patch("sys.stdin") as mock_stdin,
        ):
            mock_stdout.buffer = stdout_capture
            mock_stdin.buffer = stdin_mock
            run_bridge("tok", "http://localhost/sse")

        assert b"jsonrpc" in stdout_capture.getvalue()


# ---------------------------------------------------------------------------
# _process_sse_event — full URL endpoint
# ---------------------------------------------------------------------------


class TestSSEEventFullURL:
    """Test _process_sse_event with absolute URL endpoint."""

    def test_endpoint_full_url_extracts_path(self):
        """endpoint event with full URL extracts just the path."""
        from trackline_mcp.client import _process_sse_event

        holder: list = []
        _process_sse_event(
            event_type="endpoint",
            data="https://example.com/messages?session=42",
            mcp_url="https://example.com/sse",
            messages_path_holder=holder,
            stdout_buffer=None,
        )
        assert holder[0] == "/messages?session=42"
