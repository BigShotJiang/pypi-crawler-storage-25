# CHANGELOG


## v0.2.1 (2026-04-10)

### Bug Fixes

- **auth**: Update DEVICE_FLOW_SCOPE to use consolidated trackline scope (#7)
  ([#8](https://github.com/Trackline-Live/trackline-mcp/pull/8),
  [`ea6010f`](https://github.com/Trackline-Live/trackline-mcp/commit/ea6010f33984c9ebca08b22dfe9335ba5fa24f7f))

Change DEVICE_FLOW_SCOPE from "openid pyrail-read mcp-tools offline_access" to "openid trackline
  offline_access" to align with the scope consolidation from TRAA-155. The trackline scope replaces
  the separate pyrail-read and mcp-tools scopes.

Implements TRAA-162.

Co-authored-by: trackline-lead-engineer[bot]
  <273459789+trackline-lead-engineer[bot]@users.noreply.github.com>

Co-authored-by: Trackline Lead Engineer <lead-eng@trackline.live>

Co-authored-by: Paperclip <noreply@paperclip.ing>


## v0.2.0 (2026-04-08)

### Features

- Use ~/.trackline/ for token caching and clean PyPI README
  ([`7810058`](https://github.com/Trackline-Live/trackline-mcp/commit/78100588f6fa39317ba773beebabc2d65efd1544))

Squash-merged feat/scaffold-package into main after all checks passed.

- 54 tests passing - Zero .pyrail references remain - PR formally approved (TRAA-113)

Closes TRAA-112


## v0.1.0 (2026-04-08)

### Features

- Scaffold trackline-mcp Python package for uvx distribution
  ([`1c45349`](https://github.com/Trackline-Live/trackline-mcp/commit/1c45349e58c37602bb7995f831cc64976d80a3a0))

Squash-merged feat/scaffold-package into main after all CI checks passed.

- 54 tests passing, 95% coverage - Code review approved (TRAA-102) - Ruff format fix applied before
  merge

Closes TRAA-96
