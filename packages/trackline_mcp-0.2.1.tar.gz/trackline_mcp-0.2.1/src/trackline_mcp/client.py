#!/usr/bin/env python3
"""
Trackline MCP Client — Device Flow Auth + stdio<->SSE Bridge

Authenticates with Keycloak using OAuth 2.0 Device Authorization Grant,
then bridges Claude Code's stdio transport to the remote SSE MCP server.

No external dependencies — pure Python 3.9+ stdlib only.
Token is cached in ~/.trackline/token.json and refreshed automatically.

Usage:
  uvx trackline-mcp --auth       # Authenticate once in a terminal
  uvx trackline-mcp              # Run MCP bridge (used by Claude Code)
  uvx trackline-mcp --auth-url https://custom.auth --mcp-url https://custom/sse
"""

import argparse
import http.client
import json
import os
import ssl
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

# ── Defaults ─────────────────────────────────────────────────────────────────
DEFAULT_AUTH_URL = "https://auth.trackline.live"
DEFAULT_MCP_URL = "https://mcp.trackline.live/sse"
REALM = "pyrail"
CLIENT_ID = "pyrail-mcp"
TOKEN_FILE = Path.home() / ".trackline" / "token.json"

# Scope for device flow — includes offline_access for long-lived refresh tokens
DEVICE_FLOW_SCOPE = "openid trackline offline_access"

# ── Config resolution: CLI arg > env var > hardcoded default ─────────────────


def resolve_auth_url(cli_arg: "str | None") -> str:
    """Return auth URL: CLI arg takes priority, then TRACKLINE_AUTH_URL env, then default."""
    if cli_arg is not None:
        return cli_arg
    return os.environ.get("TRACKLINE_AUTH_URL", DEFAULT_AUTH_URL)


def resolve_mcp_url(cli_arg: "str | None") -> str:
    """Return MCP URL: CLI arg takes priority, then TRACKLINE_MCP_URL env, then default."""
    if cli_arg is not None:
        return cli_arg
    return os.environ.get("TRACKLINE_MCP_URL", DEFAULT_MCP_URL)


# ── Token cache ───────────────────────────────────────────────────────────────


def _post(url: str, data: dict) -> dict:
    body = urllib.parse.urlencode(data).encode()
    req = urllib.request.Request(
        url,
        data=body,
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read())


def _save_token(resp: dict) -> None:
    TOKEN_FILE.parent.mkdir(parents=True, exist_ok=True)
    cache: dict = {
        "access_token": resp["access_token"],
        "expires_at": time.time() + resp.get("expires_in", 300),
    }
    if "refresh_token" in resp:
        cache["refresh_token"] = resp["refresh_token"]
        cache["refresh_token_expires"] = time.time() + resp.get("refresh_expires_in", 1800)
    # Write atomically: temp file → chmod → rename to avoid brief world-readable window
    tmp = TOKEN_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(cache))
    tmp.chmod(0o600)
    tmp.replace(TOKEN_FILE)


def _try_refresh(refresh_tok: str, auth_url: "str | None" = None) -> "str | None":
    url = resolve_auth_url(auth_url)
    token_endpoint = f"{url}/realms/{REALM}/protocol/openid-connect/token"
    try:
        resp = _post(
            token_endpoint,
            {
                "grant_type": "refresh_token",
                "client_id": CLIENT_ID,
                "refresh_token": refresh_tok,
            },
        )
        _save_token(resp)
        return resp["access_token"]
    except Exception:
        return None


def get_token(auth_url: "str | None" = None) -> str:
    """Return a valid access token, refreshing or re-authenticating as needed."""
    if TOKEN_FILE.exists():
        try:
            cache = json.loads(TOKEN_FILE.read_text())
            if time.time() < cache.get("expires_at", 0) - 60:
                return cache["access_token"]
            if "refresh_token" in cache:
                tok = _try_refresh(cache["refresh_token"], auth_url)
                if tok:
                    return tok
        except Exception:
            pass
    return _device_flow(auth_url)


def _get_token_non_interactive(auth_url: "str | None" = None) -> str:
    """Return a valid token from cache only. Print an error and sys.exit(1) if unavailable."""
    if TOKEN_FILE.exists():
        try:
            cache = json.loads(TOKEN_FILE.read_text())
            if time.time() < cache.get("expires_at", 0) - 60:
                return cache["access_token"]
            if "refresh_token" in cache:
                tok = _try_refresh(cache["refresh_token"], auth_url)
                if tok:
                    return tok
        except Exception:
            pass
        print(
            "Trackline token expired. Run this to re-authenticate:\n\n  uvx trackline-mcp --auth\n",
            file=sys.stderr,
        )
        sys.exit(1)
    print(
        "Trackline: not authenticated. Run this in a terminal first:\n\n"
        "  uvx trackline-mcp --auth\n",
        file=sys.stderr,
    )
    sys.exit(1)


def _device_flow(auth_url: "str | None" = None) -> str:
    """Run OAuth 2.0 Device Authorization Grant and return access token."""
    url = resolve_auth_url(auth_url)
    token_endpoint = f"{url}/realms/{REALM}/protocol/openid-connect/token"
    device_endpoint = f"{url}/realms/{REALM}/protocol/openid-connect/auth/device"

    device = _post(
        device_endpoint,
        {
            "client_id": CLIENT_ID,
            "scope": DEVICE_FLOW_SCOPE,
        },
    )

    uri = device.get("verification_uri_complete") or device["verification_uri"]
    dev_code = device["device_code"]
    interval = device.get("interval", 5)
    expires = device.get("expires_in", 300)

    print(f"\nOpen this URL to log in to Trackline:\n\n  {uri}\n", file=sys.stderr)
    if "verification_uri_complete" not in device:
        print(f"  Enter code: {device['user_code']}\n", file=sys.stderr)
    print(f"Waiting for authorisation (expires in {expires}s)…", file=sys.stderr)

    deadline = time.time() + expires
    while time.time() < deadline:
        time.sleep(interval)
        try:
            resp = _post(
                token_endpoint,
                {
                    "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                    "client_id": CLIENT_ID,
                    "device_code": dev_code,
                },
            )
            _save_token(resp)
            return resp["access_token"]
        except urllib.error.HTTPError as e:
            err = json.loads(e.read())
            error = err.get("error", "")
            if error == "authorization_pending":
                continue
            elif error == "slow_down":
                interval += 5
            else:
                print(f"Auth error: {err.get('error_description', error)}", file=sys.stderr)
                sys.exit(1)

    print("Authentication timed out.", file=sys.stderr)
    sys.exit(1)


# ── URL parsing ───────────────────────────────────────────────────────────────


def _parse_url(url: str) -> "tuple[str, str, int, str]":
    """Return (scheme, host, port, path)."""
    p = urllib.parse.urlparse(url)
    scheme = p.scheme
    host = p.hostname or ""
    port = p.port or (443 if scheme == "https" else 80)
    path = p.path or "/"
    if p.query:
        path += "?" + p.query
    return scheme, host, port, path


def _make_conn(scheme: str, host: str, port: int) -> http.client.HTTPConnection:
    if scheme == "https":
        ctx = ssl.create_default_context()
        return http.client.HTTPSConnection(host, port, context=ctx, timeout=30)
    return http.client.HTTPConnection(host, port, timeout=30)


# ── SSE event processor (extracted for testability) ───────────────────────────


def _process_sse_event(
    event_type: str,
    data: str,
    mcp_url: str,
    messages_path_holder: list,
    stdout_buffer: "object | None",
) -> None:
    """Process a single SSE event dispatched from the stream."""
    if event_type == "endpoint":
        if data.startswith("/"):
            messages_path_holder.append(data)
        else:
            parsed = urllib.parse.urlparse(data)
            path = parsed.path
            if parsed.query:
                path += "?" + parsed.query
            messages_path_holder.append(path)
    elif event_type == "message" and data:
        if stdout_buffer is not None:
            stdout_buffer.write((data + "\n").encode())
            stdout_buffer.flush()


# ── SSE <-> stdio bridge ──────────────────────────────────────────────────────


def _post_message(base_url: str, messages_path: str, token: str, body: bytes) -> None:
    """POST a JSON-RPC message to the server's message endpoint."""
    scheme, host, port, _ = _parse_url(base_url)
    conn = _make_conn(scheme, host, port)
    try:
        conn.request(
            "POST",
            messages_path,
            body=body,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {token}",
                "Content-Length": str(len(body)),
            },
        )
        conn.getresponse().read()  # drain
    except Exception as e:
        print(f"[trackline-mcp] POST error: {e}", file=sys.stderr)
    finally:
        conn.close()


def _stdin_pump(base_url: str, messages_path_holder: list, token: str) -> None:
    """Read JSON-RPC lines from stdin and POST to server."""
    for line in sys.stdin.buffer:
        line = line.strip()
        if not line:
            continue
        while not messages_path_holder:
            time.sleep(0.05)
        _post_message(base_url, messages_path_holder[0], token, line)


def run_bridge(token: str, mcp_url: "str | None" = None) -> None:
    """Connect to SSE endpoint and bridge to stdio."""
    url = resolve_mcp_url(mcp_url)
    scheme, host, port, path = _parse_url(url)
    conn = _make_conn(scheme, host, port)
    conn.request(
        "GET",
        path,
        headers={
            "Accept": "text/event-stream",
            "Authorization": f"Bearer {token}",
            "Cache-Control": "no-cache",
        },
    )
    resp = conn.getresponse()
    if resp.status != 200:
        body = resp.read().decode(errors="replace")
        print(f"[trackline-mcp] SSE connect failed: {resp.status} {body}", file=sys.stderr)
        sys.exit(1)

    messages_path_holder: list = []
    stdin_thread = threading.Thread(
        target=_stdin_pump,
        args=(url, messages_path_holder, token),
        daemon=True,
    )
    stdin_thread.start()

    # Parse SSE stream
    event_type = "message"
    data_lines: list = []

    while True:
        raw = resp.fp.readline()
        if not raw:
            break
        line = raw.decode("utf-8", errors="replace").rstrip("\n").rstrip("\r")

        if line.startswith("event:"):
            event_type = line[6:].strip()
        elif line.startswith("data:"):
            data_lines.append(line[5:].strip())
        elif line == "":
            data = "\n".join(data_lines)
            data_lines = []
            _process_sse_event(
                event_type=event_type,
                data=data,
                mcp_url=url,
                messages_path_holder=messages_path_holder,
                stdout_buffer=sys.stdout.buffer,
            )
            event_type = "message"


# ── CLI ───────────────────────────────────────────────────────────────────────


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Trackline MCP Client — bridges Claude Code to the Trackline MCP server"
    )
    parser.add_argument(
        "--auth",
        action="store_true",
        help="Authenticate via device flow and cache token, then exit",
    )
    parser.add_argument(
        "--auth-url",
        default=None,
        dest="auth_url",
        help="Override Keycloak base URL (default: TRACKLINE_AUTH_URL env or https://auth.trackline.live)",
    )
    parser.add_argument(
        "--mcp-url",
        default=None,
        dest="mcp_url",
        help="Override MCP SSE URL (default: TRACKLINE_MCP_URL env or https://mcp.trackline.live/sse)",
    )
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    auth_url = resolve_auth_url(args.auth_url)
    mcp_url = resolve_mcp_url(args.mcp_url)

    if args.auth:
        _device_flow(auth_url)
        print("Token cached. You can now connect from Claude Code.", file=sys.stderr)
        sys.exit(0)

    token = _get_token_non_interactive(auth_url)
    try:
        run_bridge(token, mcp_url)
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
