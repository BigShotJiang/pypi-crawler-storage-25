from pixelarraythirdparty.client import AsyncClient
from typing import Any, Dict, List, Optional, Tuple


class CustomEventsManagerAsync(AsyncClient):
    """自定义事件上报（需先在 Portal 配置事件定义与字段 schema）。"""

    async def report_custom_event(
        self,
        project_id: int,
        event_key: str,
        payload: Dict[str, Any],
        client_occurred_at: Optional[str] = None,
    ) -> Tuple[Dict[str, Any], bool]:
        """
        description:
            上报单条自定义事件日志（JSON 载荷须符合 Portal 中配置的 field_schema）
        parameters:
            project_id(int): 项目 ID
            event_key(str): 事件键
            payload(dict): JSON 对象，键与类型须与定义一致
            client_occurred_at(str, optional): 客户端事件发生时间，ISO8601 字符串
        return:
            data(dict): 成功时为日志记录；失败时含 message 等
            success(bool): 是否成功
        """
        data: Dict[str, Any] = {
            "project_id": project_id,
            "event_key": event_key,
            "payload": payload,
        }
        if client_occurred_at is not None:
            data["client_occurred_at"] = client_occurred_at
        return await self._request("POST", "/api/custom-events/report", json=data)

    async def report_custom_events_batch(
        self,
        project_id: int,
        items: List[Dict[str, Any]],
    ) -> Tuple[Dict[str, Any], bool]:
        """
        description:
            批量上报自定义事件（同一 project_id；任一条校验失败则整批失败）
        parameters:
            project_id(int): 项目 ID
            items(list): 每项为 dict，须含 event_key、payload；可选 client_occurred_at（字符串）
        return:
            data(dict): 成功时为日志列表；失败时含 message
            success(bool): 是否成功
        """
        body = {"project_id": project_id, "items": items}
        return await self._request("POST", "/api/custom-events/report/batch", json=body)
