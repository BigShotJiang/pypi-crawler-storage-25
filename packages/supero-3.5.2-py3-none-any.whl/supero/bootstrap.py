#!/usr/bin/env python3
"""
bootstrap.py — One-call idempotent platform setup for Supero SDK

Location: ~/supero/platform/infra/libs/py/src/supero/bootstrap.py

v2.0: API-key-first mode — if SUPERO_API_KEY is set, skips register + login.
      Enables zero-prompt headless deployment on cloud/CI.

Usage:
    from supero import bootstrap

    # Interactive (with password):
    result = bootstrap(
        domain_name    = "wedding-planner",
        admin_email    = "admin@wedding-planner.com",
        admin_password = "Admin123!",
        schemas        = ALL_SCHEMAS,
    )

    # Headless (with API key — no password needed):
    os.environ["SUPERO_API_KEY"] = "ak_wedding-planner_..."
    result = bootstrap(
        domain_name    = "wedding-planner",
        admin_email    = "",
        admin_password = "",
        schemas        = ALL_SCHEMAS,
    )

The call is safe to run on every deploy — all steps are idempotent.
"""

from __future__ import annotations

import logging
import time
import os
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from supero.core import Supero


# ---------------------------------------------------------------------------
# Result dataclass
# ---------------------------------------------------------------------------

@dataclass
class BootstrapResult:
    domain_name: str = ""
    domain_uuid: str = ""
    project_name: str = "default-project"
    project_uuid: str = ""
    tenant_uuid: str = ""
    tenant_name: str = "default-tenant"
    api_key: str = ""
    jwt_token: str = ""

    schemas_uploaded: int = 0
    schemas_updated:  int = 0
    schemas_skipped:  int = 0
    schemas_failed:   int = 0

    tenants_created: int = 0
    tenants_skipped: int = 0
    tenants_failed:  int = 0

    users_created: int = 0
    users_skipped: int = 0
    users_failed:  int = 0

    errors: List[str] = field(default_factory=list)
    org: Optional[Any] = field(default=None, repr=False)

    @property
    def success(self) -> bool:
        return len(self.errors) == 0 or all("skipped" in e.lower() for e in self.errors)

    def print_summary(self) -> None:
        ok = "✓" if self.success else "✗"
        print(f"{ok} Bootstrap: {self.domain_name}/{self.project_name}")
        print(f"  Schemas  : {self.schemas_uploaded} uploaded, "
              f"{self.schemas_updated} updated, "
              f"{self.schemas_skipped} skipped, "
              f"{self.schemas_failed} failed")
        print(f"  Tenants  : {self.tenants_created} created, {self.tenants_skipped} skipped")
        print(f"  Users    : {self.users_created} created, {self.users_skipped} skipped")
        if self.api_key:
            print(f"  API Key  : {self.api_key[:20]}...")
        if self.errors:
            print(f"  Errors   : {len(self.errors)}")
            for e in self.errors:
                print(f"    - {e}")


# ---------------------------------------------------------------------------
# Bootstrap implementation
# ---------------------------------------------------------------------------

def _bootstrap(
    domain_name:    str,
    admin_email:    str,
    admin_password: str,
    *,
    project_name:   str = "default-project",
    schemas:        List[Dict] = None,
    tenants:        List[Dict] = None,
    users:          List[Dict] = None,
    idempotent:     bool = True,
    fail_fast:      bool = False,
    platform_core_host: str = None,
    platform_core_port: int = None,
    logger: logging.Logger = None,
) -> BootstrapResult:
    from supero.core import Supero

    log = logger or logging.getLogger("supero.bootstrap")
    result = BootstrapResult(domain_name=domain_name, project_name=project_name)

    conn_kwargs: Dict[str, Any] = {}
    if platform_core_host:
        conn_kwargs["platform_core_host"] = platform_core_host
    if platform_core_port:
        conn_kwargs["platform_core_port"] = platform_core_port

    _host = platform_core_host or os.getenv("PLATFORM_CORE_HOST", "localhost")
    _port = platform_core_port or int(os.getenv("PLATFORM_CORE_PORT", "8083"))
    _proto = "https" if _port == 443 else "http"
    _base_url = f"{_proto}://{_host}:{_port}"

    # =========================================================================
    # FAST PATH: API key pre-configured → skip register + login
    # =========================================================================
    pre_api_key = os.getenv("SUPERO_API_KEY", "") or ""
    _skip_auth = False

    if pre_api_key.startswith("ak_"):
        log.info(f"[bootstrap] API key found (ak_...{pre_api_key[-4:]}) — skipping register/login")
        result.api_key = pre_api_key

        # Try full ORM via Supero.connect (uses API key, no password)
        try:
            org = Supero.connect(
                domain_name=domain_name,
                api_key=pre_api_key,
                **conn_kwargs,
            )
            result.org = org
            log.info("[bootstrap] Supero.connect() OK — full ORM (API key mode)")
        except Exception as orm_err:
            log.info(f"[bootstrap] Supero.connect() skipped ({orm_err.__class__.__name__}) — HTTP session")
            org = _build_http_session(
                jwt_token="",
                api_key=pre_api_key,
                base_url=_base_url,
                domain_name=domain_name,
                admin_email=admin_email,
                admin_password=admin_password,
                result=result,
                platform_core_host=platform_core_host,
                platform_core_port=platform_core_port,
                log=log,
            )
            result.org = org

        # Resolve domain UUID
        try:
            resp = org.get(f"/api/v1/crud/{domain_name}/domain")
            if isinstance(resp, dict):
                for d in resp.get("results", []):
                    if d.get("name") == domain_name:
                        result.domain_uuid = d.get("uuid", "")
                        break
                if not result.domain_uuid and resp.get("uuid"):
                    result.domain_uuid = resp["uuid"]
        except Exception as e:
            log.warning(f"[bootstrap] Domain UUID lookup failed: {e}")

        log.info(f"[bootstrap] API key mode — domain_uuid={result.domain_uuid[:8] if result.domain_uuid else '?'}")
        _skip_auth = True

    # =========================================================================
    # STANDARD PATH: Register + Login (when no API key)
    # =========================================================================
    if not _skip_auth:

        # ── STEP 1: Register domain ──────────────────────────────────
        log.info(f"[bootstrap] Step 1 — register domain '{domain_name}'")
        try:
            reg_resp = _http_post(
                host=platform_core_host, port=platform_core_port,
                path="/api/v1/auth/register",
                json={
                    "email": admin_email, "password": admin_password,
                    "domain_name": domain_name, "full_name": "Domain Admin",
                },
            )
            status = reg_resp.get("_status_code", 0)

            if status == 201:
                auth_block = reg_resp.get("auth", {})
                result.api_key    = _extract_api_key_from_auth(auth_block)
                result.jwt_token  = auth_block.get("access_token", "") or auth_block.get("session_id", "")
                result.domain_uuid  = reg_resp.get("context", {}).get("domain_uuid", "")
                result.project_uuid = reg_resp.get("context", {}).get("project_uuid", "")
                result.tenant_uuid  = reg_resp.get("context", {}).get("tenant_uuid", "")
                result.tenant_name  = reg_resp.get("context", {}).get("tenant", "default-tenant")
                log.info(f"[bootstrap] Domain '{domain_name}' registered (api_key={'yes' if result.api_key else 'no'})")
            elif status in (200, 409) or reg_resp.get("idempotent"):
                log.info(f"[bootstrap] Domain '{domain_name}' already exists, logging in")
            else:
                error = reg_resp.get("error") or reg_resp.get("message") or str(reg_resp)
                if not idempotent or "already" not in error.lower():
                    msg = f"Domain registration failed (HTTP {status}): {error}"
                    result.errors.append(msg)
                    if fail_fast:
                        return result
                    log.warning(f"[bootstrap] {msg}")
        except Exception as exc:
            msg = f"Domain registration error: {exc}"
            result.errors.append(msg)
            if fail_fast:
                return result
            log.warning(f"[bootstrap] {msg} — attempting login anyway")

        # ── STEP 2: Login ────────────────────────────────────────────
        log.info(f"[bootstrap] Step 2 — login as '{admin_email}'")
        org = None
        jwt_token = ""

        login_resp = _http_post(
            host=platform_core_host, port=platform_core_port,
            path="/api/v1/auth/login",
            json={
                "username": admin_email, "password": admin_password,
                "domain": domain_name,
                "project": project_name,  # Scope login to project → api_key is project-scoped
            },
        )
        log.info(f"[bootstrap] Login scoped to project='{project_name}'")
        login_status = login_resp.get("_status_code", 0)

        if login_status in (200, 201):
            auth = login_resp.get("auth", {})
            ctx  = login_resp.get("context", login_resp.get("user", {}))

            jwt_token = auth.get("access_token", "") or auth.get("session_id", "") or auth.get("token", "")
            result.jwt_token = jwt_token

            login_api_key = _extract_api_key_from_auth(auth)
            if login_api_key and not result.api_key:
                result.api_key = login_api_key

            result.domain_uuid  = ctx.get("domain_uuid", "") or result.domain_uuid
            result.project_uuid = ctx.get("project_uuid", "") or result.project_uuid
            result.tenant_uuid  = ctx.get("tenant_uuid", "") or result.tenant_uuid
            result.tenant_name  = ctx.get("tenant", "default-tenant") or result.tenant_name

            log.info(f"[bootstrap] HTTP login OK — "
                     f"domain_uuid={result.domain_uuid[:8] if result.domain_uuid else '?'}..., "
                     f"jwt={'yes' if jwt_token else 'no'}, "
                     f"api_key={'yes' if result.api_key else 'no'}")
        else:
            error = login_resp.get("error") or login_resp.get("message") or str(login_resp)
            result.errors.append(f"Login failed: {error}")
            log.error(f"[bootstrap] Login failed: {error}")
            return result

        # Try Supero.login() for full ORM
        try:
            org = Supero.login(
                domain_name=domain_name, email=admin_email,
                password=admin_password, project=project_name,
                **conn_kwargs,
            )
            log.info(f"[bootstrap] Supero.login() scoped to project='{project_name}'")
            result.org = org
            if not result.api_key:
                sdk_key = _try_extract_api_key_from_supero(org)
                if sdk_key:
                    result.api_key = sdk_key
                    log.info(f"[bootstrap] Got API key from Supero session: ...{sdk_key[-4:]}")
            log.info("[bootstrap] Supero.login() OK — full ORM available")
        except Exception as orm_err:
            log.info(f"[bootstrap] Supero.login() skipped ({orm_err.__class__.__name__}: {orm_err}) — HTTP session")
            org = _build_http_session(
                jwt_token=jwt_token, api_key=result.api_key,
                base_url=_base_url, domain_name=domain_name,
                admin_email=admin_email, admin_password=admin_password,
                result=result, platform_core_host=platform_core_host,
                platform_core_port=platform_core_port, log=log,
            )
            result.org = org

        log.info(f"[bootstrap] Logged in — domain_uuid={result.domain_uuid[:8] if result.domain_uuid else '?'}...")

        # ── STEP 2b: Fetch API key if still missing ──────────────────
        if not result.api_key or not result.api_key.startswith("ak_"):
            log.info("[bootstrap] Step 2b — fetching API key via REST...")
            fetched_key = _fetch_api_key_via_rest(jwt_token=jwt_token, base_url=_base_url, domain_name=domain_name, log=log)
            if fetched_key:
                result.api_key = fetched_key
                log.info(f"[bootstrap] API key fetched: ...{fetched_key[-4:]}")
                if hasattr(org, 'headers') and isinstance(getattr(org, 'headers', None), dict):
                    org.headers["X-API-Key"] = fetched_key
            else:
                log.warning("[bootstrap] Could not fetch API key — will rely on JWT")

    # =========================================================================
    # STEP 3 — Create project (runs for both fast path and standard path)
    # =========================================================================
    # ═══════════════════════════════════════════════════════════════════
    # STEP 3 — Ensure project exists (idempotent)
    # ═══════════════════════════════════════════════════════════════════
    #
    # Contract: the project named `project_name` must exist when this
    # step completes, OR we already have its UUID from env.
    #
    # Never fails on "already exists" or "permission denied on existing
    # resource" — we verify via GET first and only create if missing.
    #
    # Special case: SUPERO_PROJECT_UUID in env is a trust signal that
    # the project was created previously. In that mode, we only verify
    # it exists; creation is never attempted.

    env_project_uuid = os.getenv("SUPERO_PROJECT_UUID", "").strip()

    if project_name and project_name != "default-project":

        def _find_project():
            # Prefer env UUID if present (no API call needed)
            if env_project_uuid:
                return env_project_uuid
            return _find_project_by_name(org, domain_name, project_name, log=log)

        def _create_project():
            """Attempt to create. Returns (uuid, error_msg)."""
            if env_project_uuid:
                # Don't attempt create if env says it should exist
                return "", "env has SUPERO_PROJECT_UUID but project not found on server"
            try:
                resp = org.post(
                    f"/api/v1/crud/{domain_name}/project",
                    json={
                        "name": project_name,
                        "display_name": project_name.replace("-", " ").title(),
                        "parent_type": "domain",
                    },
                )
                err = (resp or {}).get("error", "") or (resp or {}).get("message", "")
                uuid_val = (resp or {}).get("uuid") or ((resp or {}).get("data", {}) or {}).get("uuid", "")
                if uuid_val and not err:
                    # Capture project-scoped api key if returned
                    proj_api_key = (resp.get("api_key", {}) or {}).get("key", "")
                    if proj_api_key and proj_api_key.startswith("ak_"):
                        result.api_key = proj_api_key
                        log.info("[bootstrap] Captured project-scoped api_key from creation")
                    return uuid_val, ""
                return "", err or str(resp)[:200]
            except Exception as exc:
                return "", str(exc)

        resolved_uuid = _ensure_resource_by_fq_name(
            kind=f"project '{project_name}'",
            find_fn=_find_project,
            create_fn=_create_project,
            result_field="project_uuid",
            log=log,
            result=result,
            is_fatal=False,
        )
        if resolved_uuid:
            result.project_uuid = resolved_uuid

        # Switch project context (only relevant for JWT-based auth)
        if not _skip_auth and hasattr(org, "switch_project"):
            try:
                org.switch_project(project_name=project_name)
                log.info(f"[bootstrap] Switched to project '{project_name}'")
            except Exception as sw_exc:
                msg = f"switch_project('{project_name}') failed: {sw_exc}"
                result.errors.append(msg)
                log.warning(f"[bootstrap] {msg}")

        # Fetch API key if still missing (only in non-fast-path)
        if not _skip_auth and (not result.api_key or not result.api_key.startswith("ak_")):
            new_jwt = getattr(org, "jwt_token", "") or result.jwt_token
            fetched_key = _fetch_api_key_via_rest(
                jwt_token=new_jwt, base_url=_base_url,
                domain_name=domain_name, log=log,
            )
            if fetched_key:
                result.api_key = fetched_key
                log.info(f"[bootstrap] API key for project '{project_name}': ...{fetched_key[-4:]}")
                if hasattr(org, "headers") and isinstance(getattr(org, "headers", None), dict):
                    org.headers["X-API-Key"] = fetched_key
    else:
        log.info("[bootstrap] Step 3 — using default-project (no action)")


    # =========================================================================
    # STEP 4 — Upload schemas
    # =========================================================================
    if schemas:
        log.info(f"[bootstrap] Step 4 — upload {len(schemas)} schemas")
        try:
            # Auto-fix: map unsupported type "uuid" to "string"
            for _s in schemas:
                for _attr in _s.get("attributes", []):
                    if _attr.get("type") == "uuid":
                        _attr["type"] = "string"
            force = bool(os.getenv("SUPERO_RESET", ""))
            upload_resp = org.post("/api/v1/schemas/upload", json={
                "domain_name": domain_name, "schemas": schemas,
                "skip_existing": not force,
                "project_uuid": result.project_uuid or "",
            })
            summary = upload_resp.get("summary", {})
            result.schemas_uploaded = summary.get("uploaded", 0)
            result.schemas_updated  = summary.get("updated", 0)
            result.schemas_skipped  = summary.get("skipped", 0)
            result.schemas_failed   = summary.get("failed", 0)
            log.info(f"[bootstrap] Schemas: {result.schemas_uploaded} up, {result.schemas_updated} upd, "
                     f"{result.schemas_skipped} skip, {result.schemas_failed} fail")
            if result.schemas_failed > 0:
                failed_names = [f.get("name", "?") for f in upload_resp.get("failed", [])]
                msg = f"Schema upload partial failure: {failed_names}"
                result.errors.append(msg)
                if fail_fast:
                    return result
                log.warning(f"[bootstrap] {msg}")
        except Exception as exc:
            msg = f"Schema upload error: {exc}"
            result.errors.append(msg)
            if fail_fast:
                return result
            log.error(f"[bootstrap] {msg}")
    else:
        log.info("[bootstrap] Step 4 — no schemas provided, skipping")

    # =========================================================================
    # STEP 5 — Create tenants
    # =========================================================================
    # ═══════════════════════════════════════════════════════════════════
    # STEP 5 — Ensure tenants exist (idempotent)
    # ═══════════════════════════════════════════════════════════════════
    if tenants:
        log.info(f"[bootstrap] Step 5 — ensure {len(tenants)} tenant(s)")
        for tenant_def in tenants:
            t_name = tenant_def.get("name", "default-tenant")
            display = tenant_def.get("display_name", t_name)

            def _find_tenant(_t_name=t_name):
                return _find_tenant_by_fq(org, domain_name, project_name, _t_name, log=log)

            def _create_tenant(_t_name=t_name, _display=display):
                try:
                    resp = org.post(
                        f"/api/v1/crud/{domain_name}/tenant",
                        json={
                            "name": _t_name,
                            "display_name": _display,
                            "parent_type": "project",
                        },
                    )
                    err = (resp or {}).get("error", "") or (resp or {}).get("message", "")
                    uuid_val = (resp or {}).get("uuid") or ((resp or {}).get("data", {}) or {}).get("uuid", "")
                    if uuid_val and not err:
                        return uuid_val, ""
                    return "", err or str(resp)[:200]
                except Exception as exc:
                    return "", str(exc)

            pre_existing = _find_tenant()
            t_uuid = _ensure_resource_by_fq_name(
                kind=f"tenant '{t_name}'",
                find_fn=_find_tenant,
                create_fn=_create_tenant,
                result_field="tenant_uuid",
                log=log, result=result, is_fatal=False,
            )

            if t_uuid:
                # Fix G v2: sentinel means POST returned already-exists
                if pre_existing or t_uuid == "__existing__":
                    result.tenants_skipped += 1
                else:
                    result.tenants_created += 1
                # First tenant becomes the default context
                # Fix G v2: don't stash the sentinel as tenant_uuid
                if not result.tenant_uuid and t_uuid != "__existing__":
                    result.tenant_uuid = t_uuid
                    result.tenant_name = t_name
            else:
                result.tenants_failed += 1
                if fail_fast:
                    return result
    else:
        log.info("[bootstrap] Step 5 — no tenants provided, skipping")


    # =========================================================================
    # STEP 6 — Create users
    # =========================================================================
    # ═══════════════════════════════════════════════════════════════════
    # STEP 6 — Ensure users exist (idempotent)
    # ═══════════════════════════════════════════════════════════════════
    if users:
        log.info(f"[bootstrap] Step 6 — ensure {len(users)} user(s)")
        tenant_uuid_map = {}
        if result.tenant_uuid and result.tenant_name:
            tenant_uuid_map[result.tenant_name] = result.tenant_uuid

        for user_def in users:
            email = user_def.get("email") or user_def.get("name", "")
            password = user_def.get("password", "")
            role = user_def.get("role", "tenant_user")
            full_name = user_def.get("full_name", "")
            first_name = user_def.get("first_name",
                                      full_name.split()[0] if full_name else "")
            last_name = user_def.get("last_name",
                                     full_name.split()[-1]
                                     if full_name and " " in full_name else "")
            tenant_name = user_def.get("tenant", result.tenant_name or "default-tenant")

            if not email or not password:
                result.errors.append(f"User missing email or password: {user_def}")
                result.users_failed += 1
                continue

            tenant_uuid_to_use = tenant_uuid_map.get(tenant_name) or \
                                 _find_tenant_by_fq(org, domain_name, project_name,
                                                    tenant_name, log=log) or \
                                 result.tenant_uuid

            def _find_user(_email=email, _tn=tenant_name):
                return _find_user_by_email(org, domain_name, project_name, _tn, _email, log=log)

            def _create_user(_email=email, _password=password, _role=role,
                             _first=first_name, _last=last_name,
                             _tn=tenant_name, _tuu=tenant_uuid_to_use):
                try:
                    resp = org.post(
                        "/api/v1/users/register",
                        json={
                            "domain_name": domain_name,
                            "domain_uuid": result.domain_uuid,
                            "project_uuid": result.project_uuid,
                            "tenant_uuid": _tuu,
                            "project_name": project_name,
                            "tenant_name": _tn,
                            "email": _email,
                            "password": _password,
                            "first_name": _first,
                            "last_name": _last,
                            "role": _role,
                            "permissions": [],
                        },
                    )
                    err = (resp or {}).get("error", "")
                    msg_ = (resp or {}).get("message", "")
                    registered = (not err) and ("registered" in msg_ or "success" in msg_.lower())
                    uuid_val = (resp or {}).get("uuid", "") or \
                               ((resp or {}).get("data", {}) or {}).get("uuid", "")
                    if registered or uuid_val:
                        return uuid_val or "registered", ""
                    # Clearer error if scope mismatch
                    if "default-project" in err or "default-tenant" in err:
                        return "", (f"API key's tenant scope does not match target "
                                    f"tenant '{_tn}'. Platform-core ignores body's "
                                    f"tenant_name. Use a key scoped to the target tenant, "
                                    f"or fix /users/register. (original: {err})")
                    return "", err or str(resp)[:200]
                except Exception as exc:
                    return "", str(exc)

            pre_existing = _find_user()
            u_uuid = _ensure_resource_by_fq_name(
                kind=f"user '{email}' in tenant '{tenant_name}'",
                find_fn=_find_user,
                create_fn=_create_user,
                result_field="",
                log=log, result=result, is_fatal=False,
            )

            if u_uuid:
                # Fix G v2: sentinel means POST returned already-exists
                if pre_existing or u_uuid == "__existing__":
                    result.users_skipped += 1
                else:
                    result.users_created += 1
            else:
                result.users_failed += 1
                if fail_fast:
                    return result
    else:
        log.info("[bootstrap] Step 6 — no users provided, skipping")


    # =========================================================================
    # Done
    # =========================================================================
    log.info(
        f"[bootstrap] Complete — domain={domain_name}, "
        f"api_key={'...'+result.api_key[-4:] if result.api_key else 'none'}, "
        f"mode={'api_key' if _skip_auth else 'login'}, "
        f"schemas={result.schemas_uploaded}+{result.schemas_skipped}sk, "
        f"tenants={result.tenants_created}+{result.tenants_skipped}sk, "
        f"users={result.users_created}+{result.users_skipped}sk, "
        f"errors={len(result.errors)}"
    )
    return result


# ---------------------------------------------------------------------------
# API key helpers
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Idempotency helpers (Fix G)
# ---------------------------------------------------------------------------

def _find_project_by_name(org, domain_name, project_name, log=None):
    """
    GET project by name. Returns uuid if found, else empty string.
    Never raises — returns '' on any error.
    """
    if not project_name:
        return ""
    try:
        resp = org.get(f"/api/v1/crud/{domain_name}/project", params={"name": project_name}) \
               if _org_supports_params(org) else org.get(f"/api/v1/crud/{domain_name}/project")
        results = (resp or {}).get("results", []) if isinstance(resp, dict) else []
        if not results and isinstance(resp, dict):
            # Some endpoints return {"data": {"results": [...]}}
            results = (resp.get("data", {}) or {}).get("results", [])
        for item in results:
            if item.get("name") == project_name:
                return item.get("uuid", "")
        # Singleton response
        if isinstance(resp, dict) and resp.get("name") == project_name:
            return resp.get("uuid", "")
    except Exception as e:
        if log:
            log.debug(f"[bootstrap] project lookup failed: {e}")
    return ""


def _find_tenant_by_fq(org, domain_name, project_name, tenant_name, log=None):
    """GET tenant by name within project. Returns uuid if found."""
    if not tenant_name:
        return ""
    try:
        resp = org.get(f"/api/v1/crud/{domain_name}/tenant") if not _org_supports_params(org) \
               else org.get(f"/api/v1/crud/{domain_name}/tenant", params={"name": tenant_name})
        results = (resp or {}).get("results", []) if isinstance(resp, dict) else []
        if not results and isinstance(resp, dict):
            results = (resp.get("data", {}) or {}).get("results", [])
        for item in results:
            if item.get("name") != tenant_name:
                continue
            fq = item.get("fq_name") or []
            if len(fq) >= 2 and fq[1] == project_name:
                return item.get("uuid", "")
            # Tolerant: if no project in fq_name, still match on name
            if len(fq) < 2:
                return item.get("uuid", "")
    except Exception as e:
        if log:
            log.debug(f"[bootstrap] tenant lookup failed: {e}")
    return ""


def _find_user_by_email(org, domain_name, project_name, tenant_name, email, log=None):
    """GET user by email within project/tenant. Returns uuid if found."""
    if not email:
        return ""
    try:
        resp = org.get(f"/api/v1/crud/{domain_name}/user_account")
        results = (resp or {}).get("results", []) if isinstance(resp, dict) else []
        if not results and isinstance(resp, dict):
            results = (resp.get("data", {}) or {}).get("results", [])
        for item in results:
            if item.get("email", "").lower() != email.lower():
                continue
            fq = item.get("fq_name") or []
            # Best-effort match: email + project + tenant if we can; otherwise email alone
            if len(fq) >= 3:
                if fq[1] == project_name and fq[2] == tenant_name:
                    return item.get("uuid", "")
            else:
                return item.get("uuid", "")
    except Exception as e:
        if log:
            log.debug(f"[bootstrap] user lookup failed: {e}")
    return ""


def _org_supports_params(org):
    """Check if org.get supports params kwarg (HTTP session does; ORM may not)."""
    try:
        import inspect
        sig = inspect.signature(org.get)
        return "params" in sig.parameters or any(
            p.kind == inspect.Parameter.VAR_KEYWORD for p in sig.parameters.values()
        )
    except Exception:
        return False


def _is_already_exists_error(err_msg):
    """Fix G v2: detect already-exists error string from POST response."""
    if not err_msg:
        return False
    e = str(err_msg).lower()
    return (
        "already exists" in e
        or "already_exists" in e
        or "duplicate" in e
        or "conflict" in e
        or "409" in e
    )


def _ensure_resource_by_fq_name(
    kind, find_fn, create_fn, result_field, log, result, is_fatal=False
):
    """
    Core idempotency primitive (Fix G v2):
      1. find_fn() -> uuid or ''          [fast path]
      2. If found: return existing uuid
      3. Otherwise create_fn() -> (uuid, error_msg)
      4. If created: return new uuid
      5. If create_fn returned 'already exists' error → sentinel
      6. Otherwise find_fn() again (race window)
      7. Still missing → record error

    Returns:
      - uuid string when resource has an identifier
      - '__existing__' sentinel when resource exists but no UUID resolved
      - '' only on real failure
    """
    found = find_fn()
    if found:
        log.info(f"[bootstrap] {kind}: verified existing (uuid={found[:8]}...)")
        return found

    new_uuid, err = create_fn()
    if new_uuid:
        log.info(f"[bootstrap] {kind}: created (uuid={new_uuid[:8]}...)")
        return new_uuid

    if _is_already_exists_error(err):
        log.info(f"[bootstrap] {kind}: already exists (from POST response) — counted as skipped")
        return "__existing__"

    after = find_fn()
    if after:
        log.info(f"[bootstrap] {kind}: found on re-check after create-fail (uuid={after[:8]}...)")
        return after

    msg = f"{kind}: create failed and resource not found on re-check — {err or 'unknown error'}"
    result.errors.append(msg)
    if is_fatal:
        log.error(f"[bootstrap] {msg}")
    else:
        log.warning(f"[bootstrap] {msg}")
    return ""


def _extract_api_key_from_auth(auth: Dict) -> str:
    """Extract API key from auth response. Only accepts ak_ prefix."""
    for field in ("api_key", "api_key_value"):
        val = auth.get(field, "")
        if val and val.startswith("ak_"):
            return val
    return ""


def _try_extract_api_key_from_supero(org) -> str:
    """Try to extract API key from a full Supero instance."""
    if not org:
        return ""
    for attr in ('_api_key', 'api_key', '_cached_api_key', '_service_api_key'):
        val = getattr(org, attr, None)
        if val and isinstance(val, str) and val.startswith("ak_"):
            return val
    api_lib = getattr(org, '_api_lib', None)
    if api_lib:
        key = getattr(api_lib, '_api_key', None) or getattr(api_lib, 'api_key', None)
        if key and isinstance(key, str) and key.startswith("ak_"):
            return key
    return ""


def _fetch_api_key_via_rest(jwt_token: str, base_url: str, domain_name: str, log=None) -> str:
    """Fetch API key via REST. May return '' if plaintext not available."""
    if not jwt_token:
        return ""
    import requests as _requests
    try:
        s = _requests.Session()
        s.verify = False
        s.headers.update({"Authorization": f"Bearer {jwt_token}", "Content-Type": "application/json"})

        for url in (
            f"{base_url}/api/v1/crud/{domain_name}/api-key",
            f"{base_url}/api/v1/crud/{domain_name}/api-key?name=admin-key",
        ):
            r = s.get(url, timeout=15)
            if r.status_code in (200, 201):
                body = r.json() if r.content else {}
                for key_obj in body.get("results", []):
                    for field_name in ("api_key_value", "key", "api_key", "value"):
                        val = key_obj.get(field_name, "")
                        if val and val.startswith("ak_"):
                            return val
                    name = key_obj.get("name", "")
                    if name.startswith("ak_"):
                        return name

        if log:
            log.debug("[bootstrap] API key list — no plaintext found")
    except Exception as e:
        if log:
            log.debug(f"[bootstrap] API key fetch error: {e}")
    return ""


# ---------------------------------------------------------------------------
# HTTP-only session builder
# ---------------------------------------------------------------------------

def _build_http_session(
    jwt_token, api_key, base_url, domain_name, admin_email, admin_password,
    result, platform_core_host, platform_core_port, log,
):
    """Build minimal HTTP session when Supero ORM is unavailable."""
    import requests as _requests

    org = _requests.Session()
    org.verify = False
    org.headers.update({"Content-Type": "application/json"})
    if jwt_token:
        org.headers["Authorization"] = f"Bearer {jwt_token}"
    if api_key and api_key.startswith("ak_"):
        org.headers["X-API-Key"] = api_key

    org._domain_uuid = result.domain_uuid
    org.project_uuid = result.project_uuid
    org.tenant_uuid  = result.tenant_uuid
    org.tenant_name  = result.tenant_name
    org.jwt_token    = jwt_token
    org._jwt_token   = jwt_token
    org._domain_name = domain_name
    org._api_key     = api_key

    _orig_post = org.post
    _orig_get = org.get

    def _ensure_url(path_or_url):
        if path_or_url.startswith("http://") or path_or_url.startswith("https://"):
            return path_or_url
        path = path_or_url
        if not path.startswith("/api/"):
            path = f"/api/v1{path}"
        return f"{base_url}{path}"

    def _patched_post(path_or_url, **kw):
        url = _ensure_url(path_or_url)
        resp = _orig_post(url, **kw)
        try:
            data = resp.json() if resp.content else {}
        except Exception:
            data = {"error": resp.text}
        data["_status_code"] = resp.status_code
        return data
    org.post = _patched_post

    def _patched_get(path_or_url, **kw):
        url = _ensure_url(path_or_url)
        resp = _orig_get(url, **kw)
        try:
            data = resp.json() if resp.content else {}
        except Exception:
            data = {"error": resp.text}
        data["_status_code"] = resp.status_code
        return data
    org.get = _patched_get

    def _switch_project(project_name, **_kw):
        login_resp = _http_post(
            host=platform_core_host, port=platform_core_port,
            path="/api/v1/auth/login",
            json={"username": admin_email, "password": admin_password, "domain": domain_name, "project": project_name},
        )
        if login_resp.get("_status_code") in (200, 201):
            new_auth = login_resp.get("auth", {})
            new_token = new_auth.get("access_token", "") or new_auth.get("session_id", "") or new_auth.get("token", "")
            if new_token:
                org.headers["Authorization"] = f"Bearer {new_token}"
                org.jwt_token = new_token
                org._jwt_token = new_token
            new_api_key = _extract_api_key_from_auth(new_auth)
            if new_api_key:
                org.headers["X-API-Key"] = new_api_key
                org._api_key = new_api_key
                result.api_key = new_api_key
            log.info(f"[bootstrap] switch_project OK → '{project_name}'")
        else:
            log.warning(f"[bootstrap] switch_project failed (HTTP {login_resp.get('_status_code')})")
    org.switch_project = _switch_project

    def _generate_sdk(language="python", output_format="wheel", **_kw):
        return _patched_post("/api/v1/sdks/generate", json={"language": language, "output_format": output_format})
    org.generate_sdk = _generate_sdk

    return org


# ---------------------------------------------------------------------------
# HTTP helper
# ---------------------------------------------------------------------------

def _http_post(host, port, path, json):
    import requests as _requests
    _host = host or os.getenv("PLATFORM_CORE_HOST", "localhost")
    _port = port or int(os.getenv("PLATFORM_CORE_PORT", "8083"))
    protocol = "https" if _port == 443 else "http"
    url = f"{protocol}://{_host}:{_port}{path}"
    try:
        resp = _requests.post(url, json=json, timeout=30, verify=False)
        data = resp.json() if resp.content else {}
        data["_status_code"] = resp.status_code
        return data
    except Exception as exc:
        return {"error": str(exc), "_status_code": 0}


# ---------------------------------------------------------------------------
# Module-level convenience function
# ---------------------------------------------------------------------------

def bootstrap(
    domain_name:    str,
    admin_email:    str,
    admin_password: str,
    *,
    project_name:   str,
    schemas:        List[Dict] = None,
    tenants:        List[Dict] = None,
    users:          List[Dict] = None,
    idempotent:     bool = True,
    fail_fast:      bool = False,
    platform_core_host: str = None,
    platform_core_port: int = None,
    logger: logging.Logger = None,
) -> BootstrapResult:
    """
    One-call idempotent platform bootstrap.

    Two auth modes:
      1. API key (headless): Set SUPERO_API_KEY env var. No password needed.
      2. Password (interactive): Provide admin_email + admin_password.

    Safe to run on every deploy — all steps are idempotent.

    NOTE: project_name has NO default. The previous default of
    'default-project' caused apps to silently bootstrap into the admin
    placeholder project, where schemas are rejected by the platform.
    Callers MUST pass project_name explicitly.
    """
    # Defensive validation — reject empty strings even though Python
    # enforces the required kwarg. This catches cases like
    # bootstrap(project_name=os.getenv('SUPERO_PROJECT', '')) where
    # the env lookup returns an empty default.
    if not project_name or not project_name.strip():
        raise ValueError(
            "bootstrap() requires a non-empty project_name. There is no "
            "default — 'default-project' is an admin placeholder and "
            "schemas linked to it are rejected by the platform. Pass "
            "project_name explicitly from the calling context."
        )

    return _bootstrap(
        domain_name=domain_name, admin_email=admin_email,
        admin_password=admin_password, project_name=project_name,
        schemas=schemas, tenants=tenants, users=users,
        idempotent=idempotent, fail_fast=fail_fast,
        platform_core_host=platform_core_host,
        platform_core_port=platform_core_port, logger=logger,
    )
