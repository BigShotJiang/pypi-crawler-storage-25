"""Frontend library bundles.

Exposes filesystem paths to the bundled supero-ui.js (browser) and
supero-mobile.jsx (React Native) so:

- supero.server can serve supero-ui.js to browsers
- mobile/expo.sh can copy supero-mobile.jsx into projects (replacing
  the previous CDN curl per §1.3)
- platform-core's Cloud Build can extract these via extract_to_project
  (per §1.8)

The actual binary content (~544KB supero-ui.js, ~84KB supero-mobile.jsx)
lives next to this file inside the wheel. Per blueprint §1.1 the wheel
is the single source of truth for both.
"""
from importlib.resources import files
import os

_ROOT = files(__package__)


def get_path(name: str) -> str:
    """Return absolute path to the named bundled UI artifact.

    Raises FileNotFoundError if the artifact isn't bundled.
    """
    p = _ROOT / name
    if not os.path.isfile(str(p)):
        raise FileNotFoundError(
            f"No bundled UI artifact: {name!r}. "
            f"Looked in {_ROOT}."
        )
    return str(p)


def web_lib_path() -> str:
    """Filesystem path to supero-ui.js inside the installed wheel."""
    return get_path("supero-ui.js")


def mobile_lib_path() -> str:
    """Filesystem path to supero-mobile.jsx inside the installed wheel."""
    return get_path("supero-mobile.jsx")


__all__ = ['web_lib_path', 'mobile_lib_path', 'get_path']
