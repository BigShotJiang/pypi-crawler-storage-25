/**
 * @supero/mobile v3.0.1
 *
 * Supero Platform — React Native / Expo Components
 *
 * v3.0.1 — AuthProvider hang fix (2026-04-30):
 *   - SUPERO_MOBILE_AUTH_HANG_FIX_V1: AuthProvider's useEffect now
 *     handles client.init() rejection and ALWAYS flips isReady=true
 *     via .finally(). Without this fix, any rejection from init()
 *     (e.g. AsyncStorage TurboModule timeout on the new architecture)
 *     would leave isReady=false forever, causing _Root to render the
 *     ActivityIndicator indefinitely. The app would appear to spin
 *     forever and Expo Go would silently close after its watchdog
 *     timeout. No red error screen because the rejection was an
 *     unhandled promise that never reached a React error boundary.
 *
 * v3.0.0 — UX Overhaul (matches supero-ui.js v3):
 *   - Theme engine: full palette from primary color
 *   - Themed navigation bar and tab bar
 *   - Image-forward list cards with cardTemplate support
 *   - dashboardWidgets for KPI cards
 *   - actionButtons for email/sms on detail views
 *   - Improved visual quality across all screens
 *
 * Provides: SuperoClient, client, useAuth, AuthProvider,
 * formatters, AI chat client, workflow utils, InlineSelect,
 * buildFieldDefs, parse422Error, MobileShell, services.
 *
 * Usage in Expo app:
 *   import { MobileShell } from './src/lib/supero';
 *   import { APP_CONFIG, TABS, WORKFLOW_MAP } from './src/appConfig';
 *   export default () => MobileShell({ ...APP_CONFIG, tabs: TABS, workflowMap: WORKFLOW_MAP });
 *
 * ⚠️ Call setConfig() BEFORE any client operations.
 * ⛔ NEVER use expo-secure-store — triggers TurboModule crash.
 * ⛔ NEVER use @react-native-picker/picker — not in Expo SDK 54.
 * ⛔ NEVER use stream: true in AI chat — RN fetch can't stream.
 */

// ─────────────────────────────────────────────────────────
// Imports
// ─────────────────────────────────────────────────────────

import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import {
    View, Text, Pressable, StyleSheet, ScrollView, TextInput, Switch,
    Alert, RefreshControl, ActivityIndicator, Image, FlatList, Dimensions,
    TouchableOpacity, Animated, Platform, StatusBar, KeyboardAvoidingView,
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import AsyncStorage from '@react-native-async-storage/async-storage';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();
const { width: SCREEN_WIDTH } = Dimensions.get('window');

// ─────────────────────────────────────────────────────────
// Config
// ─────────────────────────────────────────────────────────

export const DEFAULT_CONFIG = {
    API_URL: 'http://localhost:5648',
    DOMAIN: 'app',
    PROJECT: 'app-project',
    TENANT: 'default-tenant',
    APP_NAME: 'Supero App',
};

let CONFIG = { ...DEFAULT_CONFIG };

export function setConfig(appConfig) {
    CONFIG = { ...DEFAULT_CONFIG };

    // Accept both camelCase (caller-friendly) and UPPER_CASE (output-shape) keys.
    // Lookup falls back left-to-right; first defined value wins.
    const apiUrl  = appConfig.serverUrl ?? appConfig.apiUrl  ?? appConfig.API_URL;
    const domain  = appConfig.domain    ?? appConfig.DOMAIN;
    const project = appConfig.project   ?? appConfig.PROJECT;
    const tenant  = appConfig.tenant    ?? appConfig.TENANT;
    const appName = appConfig.appName   ?? appConfig.APP_NAME;

    if (apiUrl)  CONFIG.API_URL  = apiUrl;
    if (domain)  CONFIG.DOMAIN   = domain;
    if (project) CONFIG.PROJECT  = project;
    if (tenant)  CONFIG.TENANT   = tenant;
    if (appName) CONFIG.APP_NAME = appName;

    // Loud failure for typos / wrong casing — silent no-ops were the original bug.
    const known = new Set([
        'serverUrl', 'apiUrl', 'API_URL',
        'domain',    'DOMAIN',
        'project',   'PROJECT',
        'tenant',    'TENANT',
        'appName',   'APP_NAME',
    ]);
    const unknown = Object.keys(appConfig).filter(k => !known.has(k));
    if (unknown.length && typeof console !== 'undefined' && console.warn) {
        console.warn('[supero] setConfig: ignoring unknown keys:', unknown);
    }

    if (typeof client !== 'undefined' && client && !client.token) {
        client.domain = CONFIG.DOMAIN;
        client.project = CONFIG.PROJECT;
        client.tenant = CONFIG.TENANT;
    }
}

export function getConfig() { return CONFIG; }

// ─────────────────────────────────────────────────────────
// Theme Engine — generates palette from primary hex
// ─────────────────────────────────────────────────────────

function _hexToHSL(hex) {
    hex = hex.replace('#', '');
    if (hex.length === 3) hex = hex[0]+hex[0]+hex[1]+hex[1]+hex[2]+hex[2];
    const r = parseInt(hex.substr(0,2), 16) / 255;
    const g = parseInt(hex.substr(2,2), 16) / 255;
    const b = parseInt(hex.substr(4,2), 16) / 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    let h, s, l = (max + min) / 2;
    if (max === min) { h = s = 0; }
    else {
        const d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        switch (max) {
            case r: h = ((g - b) / d + (g < b ? 6 : 0)) / 6; break;
            case g: h = ((b - r) / d + 2) / 6; break;
            case b: h = ((r - g) / d + 4) / 6; break;
        }
    }
    return { h: Math.round(h * 360), s: Math.round(s * 100), l: Math.round(l * 100) };
}

function _hslToHex(h, s, l) {
    s /= 100; l /= 100;
    const c = (1 - Math.abs(2 * l - 1)) * s;
    const x = c * (1 - Math.abs((h / 60) % 2 - 1));
    const m = l - c / 2;
    let r, g, b;
    if (h < 60) { r=c; g=x; b=0; }
    else if (h < 120) { r=x; g=c; b=0; }
    else if (h < 180) { r=0; g=c; b=x; }
    else if (h < 240) { r=0; g=x; b=c; }
    else if (h < 300) { r=x; g=0; b=c; }
    else { r=c; g=0; b=x; }
    r = Math.round((r+m)*255).toString(16).padStart(2,'0');
    g = Math.round((g+m)*255).toString(16).padStart(2,'0');
    b = Math.round((b+m)*255).toString(16).padStart(2,'0');
    return '#' + r + g + b;
}

function generatePalette(hex) {
    const hsl = _hexToHSL(hex);
    return {
        50:  _hslToHex(hsl.h, Math.min(100, hsl.s + 10), 97),
        100: _hslToHex(hsl.h, Math.min(100, hsl.s + 5), 93),
        200: _hslToHex(hsl.h, hsl.s, 85),
        300: _hslToHex(hsl.h, hsl.s, 73),
        400: _hslToHex(hsl.h, hsl.s, 60),
        500: hex,
        600: _hslToHex(hsl.h, hsl.s, Math.max(0, hsl.l - 8)),
        700: _hslToHex(hsl.h, hsl.s, Math.max(0, hsl.l - 16)),
        800: _hslToHex(hsl.h, Math.max(0, hsl.s - 5), Math.max(0, hsl.l - 24)),
        900: _hslToHex(hsl.h, Math.max(0, hsl.s - 10), Math.max(0, hsl.l - 32)),
    };
}

// Theme context — all components read from this
const ThemeContext = createContext({
    primary: '#6366f1', palette: generatePalette('#6366f1'),
});
const useTheme = () => useContext(ThemeContext);

// ─────────────────────────────────────────────────────────
// Formatters (identical to web)
// ─────────────────────────────────────────────────────────

export const formatCurrency = (v, c = 'USD') =>
    v != null ? new Intl.NumberFormat('en-US', { style: 'currency', currency: c }).format(v) : '$0';

export const formatNumber = (v) => {
    if (v == null) return '0';
    if (v >= 1e6) return (v / 1e6).toFixed(1) + 'M';
    if (v >= 1e3) return (v / 1e3).toFixed(1) + 'K';
    return new Intl.NumberFormat('en-US').format(v);
};

export const formatDate = (s) =>
    s ? new Date(s).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : '—';

export const formatDateTime = (s) =>
    s ? new Date(s).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }) : '—';

export const formatFieldValue = (field, value) => {
    if (value == null) return '—';
    if ((field.type === 'number' || field.type === 'float' || field.type === 'integer') &&
        ['amount', 'budget', 'price', 'cost', 'total', 'revenue', 'rent', 'rate', 'spent', 'fee', 'salary']
            .some(k => field.name.includes(k)))
        return formatCurrency(value);
    if (field.type === 'number' || field.type === 'float' || field.type === 'integer') return formatNumber(value);
    if (field.type === 'date' || field.type === 'datetime') return formatDate(value);
    if (typeof value === 'boolean') return value ? 'Yes' : 'No';
    if (typeof value === 'string' && value.includes('_')) return value.replace(/_/g, ' ');
    return String(value);
};

// ─────────────────────────────────────────────────────────
// Image URL resolver (matches web resolveImageUrl)
// ─────────────────────────────────────────────────────────

export function resolveImageUrl(val) {
    if (!val) return '';
    if (typeof val === 'string') return val;
    return val.thumbnail_url || val.url || '';
}

// ─────────────────────────────────────────────────────────
// Status colors (matches web getStatusColor)
// ─────────────────────────────────────────────────────────

const STATUS_COLORS = {
    active: { bg: '#dcfce7', text: '#166534' }, approved: { bg: '#dcfce7', text: '#166534' },
    hired: { bg: '#dcfce7', text: '#166534' }, paid: { bg: '#dcfce7', text: '#166534' },
    open: { bg: '#dcfce7', text: '#166534' }, completed: { bg: '#dcfce7', text: '#166534' },
    pending: { bg: '#fef3c7', text: '#92400e' }, processing: { bg: '#fef3c7', text: '#92400e' },
    on_leave: { bg: '#fef3c7', text: '#92400e' },
    scheduled: { bg: '#dbeafe', text: '#1e40af' }, screening: { bg: '#dbeafe', text: '#1e40af' },
    interview: { bg: '#f3e8ff', text: '#7c3aed' }, offer: { bg: '#eef2ff', text: '#4338ca' },
    applied: { bg: '#f1f5f9', text: '#64748b' }, draft: { bg: '#f1f5f9', text: '#64748b' },
    inactive: { bg: '#f1f5f9', text: '#64748b' },
    terminated: { bg: '#fee2e2', text: '#991b1b' }, rejected: { bg: '#fee2e2', text: '#991b1b' },
    failed: { bg: '#fee2e2', text: '#991b1b' }, cancelled: { bg: '#f1f5f9', text: '#64748b' },
};

function getStatusStyle(status) {
    return STATUS_COLORS[status] || { bg: '#f1f5f9', text: '#64748b' };
}

// ─────────────────────────────────────────────────────────
// SuperoClient (identical logic to web, AsyncStorage instead of localStorage)
// ─────────────────────────────────────────────────────────

export class SuperoClient {
    token = null;
    domain = CONFIG.DOMAIN;
    project = CONFIG.PROJECT;
    tenant = CONFIG.TENANT;
    userInfo = {};
    policy = null;

    async init() {
        try {
            const storedDomain = await AsyncStorage.getItem('supero_domain');
            // Stale auth from a different domain — clear it so the new config takes effect
            if (storedDomain && storedDomain !== CONFIG.DOMAIN) {
                await AsyncStorage.multiRemove(['supero_token', 'supero_domain', 'supero_project', 'supero_tenant', 'supero_user', 'supero_policy']);
                this.domain = CONFIG.DOMAIN;
                this.project = CONFIG.PROJECT;
                this.tenant = CONFIG.TENANT;
                return;
            }
            this.token = await AsyncStorage.getItem('supero_token');
            this.domain = storedDomain || CONFIG.DOMAIN;
            this.project = (await AsyncStorage.getItem('supero_project')) || CONFIG.PROJECT;
            this.tenant = (await AsyncStorage.getItem('supero_tenant')) || CONFIG.TENANT;
            const ui = await AsyncStorage.getItem('supero_user');
            this.userInfo = ui ? JSON.parse(ui) : {};
            const pol = await AsyncStorage.getItem('supero_policy');
            this.policy = pol ? JSON.parse(pol) : null;
        } catch { this.token = null; }
    }

    async setAuth(token, domain, project, tenant, userInfo, policy = null) {
        Object.assign(this, { token, domain, project, tenant, userInfo, policy });
        await AsyncStorage.setItem('supero_token', token);
        await AsyncStorage.setItem('supero_domain', domain);
        await AsyncStorage.setItem('supero_project', project);
        await AsyncStorage.setItem('supero_tenant', tenant);
        await AsyncStorage.setItem('supero_user', JSON.stringify(userInfo));
        if (policy !== null) await AsyncStorage.setItem('supero_policy', JSON.stringify(policy));
    }

    async clearAuth() {
        this.token = null; this.userInfo = {}; this.policy = null;
        this.domain = CONFIG.DOMAIN; this.project = CONFIG.PROJECT; this.tenant = CONFIG.TENANT;
        await AsyncStorage.multiRemove(['supero_token', 'supero_domain', 'supero_project', 'supero_tenant', 'supero_user', 'supero_policy']);
    }

    isAuthenticated() { return !!this.token; }

    _headers() {
        const h = { 'Content-Type': 'application/json', 'X-Domain': this.domain, 'X-Tenant': this.tenant };
        if (this.token) h['Authorization'] = `Bearer ${this.token}`;
        return h;
    }

    async request(method, path, data, retries = 2, extraHeaders = {}) {
        const url = `${CONFIG.API_URL}${path}`;
        for (let attempt = 0; attempt <= retries; attempt++) {
            try {
                const opts = { method, headers: { ...this._headers(), ...extraHeaders } };
                if (data) opts.body = JSON.stringify(data);
                const resp = await fetch(url, opts);
                const result = await resp.json().catch(() => ({}));
                if (!resp.ok) {
                    const msg = result.detail || result.message || result.error || `HTTP ${resp.status}`;
                    const err = new Error(msg); err.status = resp.status; err.body = result;
                    throw err;
                }
                return result;
            } catch (err) {
                if (attempt === retries) throw err;
                await new Promise(r => setTimeout(r, 1000 * (attempt + 1)));
            }
        }
    }

    async login(domain, email, password, project) {
        const r = await this.request('POST', '/api/v1/auth/login',
            { domain_name: domain, email, password, project },
            2, { 'X-Domain': domain });
        const policy = r.policy || null;
        await this.setAuth(r.auth.access_token, domain,
            project || r.context.project, r.context.tenant,
            { email, role: r.user?.role, fullName: r.user?.full_name }, policy);
        return r;
    }

    can(action, schema = null) {
        if (this.policy?.is_admin) return true;
        const p = this.policy;
        if (!p) {
            const role = this.userInfo?.role || '';
            return ['platform_admin', 'domain_admin', 'tenant_admin'].includes(role);
        }
        if (schema && p.entities?.[schema]) {
            const e = p.entities[schema];
            if (action === 'create') return !!e.can_create;
            if (action === 'update') return !!e.can_update;
            if (action === 'delete') return !!e.can_delete;
            return !!e.can_read;
        }
        const da = p.default_access || 'none';
        return da === 'full' ? true : da === 'read' ? action === 'read' : false;
    }

    canWrite(schema = null) { return this.can('create', schema) || this.can('update', schema); }

    async getObjects(schema) {
        return (await this.request('GET', `/api/v1/crud/${this.domain}/${schema}`)).results || [];
    }

    async createObject(schema, data) {
        const name = data.name || `${schema}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
        const payload = data.parent_uuid ? { name, ...data } : { name, parent_type: 'tenant', ...data };
        delete payload.fq_name;
        return this.request('POST', `/api/v1/crud/${this.domain}/${schema}`, payload);
    }

    _tenantFromItem(item) {
        if (!item) return null;
        const fq = item.fq_name;
        if (Array.isArray(fq) && fq.length >= 3) return fq[2];
        if (typeof fq === 'string') { const p = fq.split(':'); if (p.length >= 3) return p[2]; }
        return item.tenant_name || item.parent_name || null;
    }

    async updateObject(schema, uuid, data, item = null) {
        const th = this._tenantFromItem(item);
        return this.request('PUT', `/api/v1/crud/${this.domain}/${schema}/${uuid}`, data, 2, th ? { 'X-Tenant': th } : {});
    }

    async deleteObject(schema, uuid, item = null) {
        const th = this._tenantFromItem(item);
        return this.request('DELETE', `/api/v1/crud/${this.domain}/${schema}/${uuid}`, null, 2, th ? { 'X-Tenant': th } : {});
    }
}

export const client = new SuperoClient();

// ─────────────────────────────────────────────────────────
// AI Chat (non-streaming — RN safe)
// ─────────────────────────────────────────────────────────

export async function aiChat(message, sessionId = null) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 60000);
    try {
        const headers = { 'Content-Type': 'application/json', 'Accept': 'application/json', 'X-Domain': client.domain, 'X-Tenant': client.tenant };
        if (client.token) headers['Authorization'] = `Bearer ${client.token}`;
        const resp = await fetch(`${CONFIG.API_URL}/ai/v1/chat`, {
            method: 'POST', headers,
            body: JSON.stringify({ message, session_id: sessionId, stream: false }),
            signal: controller.signal,
        });
        if (!resp.ok) throw new Error(`AI failed (${resp.status})`);
        const data = await resp.json();
        return { response: data.response || data.message || data.content || '', sessionId: data.session_id || null, toolCalls: [] };
    } finally { clearTimeout(timeout); }
}

// ─────────────────────────────────────────────────────────
// Auth Context
// ─────────────────────────────────────────────────────────

const AuthContext = createContext({});

export function AuthProvider({ children }) {
    const [isReady, setIsReady] = useState(false);
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [userInfo, setUserInfo] = useState({});

    useEffect(() => {
        // SUPERO_MOBILE_AUTH_HANG_FIX_V1
        // Bug: original code was `client.init().then(() => { setIsReady(true); ... })`
        // with no .catch() and no .finally(). If client.init() rejected for any
        // reason (e.g. AsyncStorage TurboModule timeout under newArchEnabled:true),
        // isReady stayed false forever — _Root would render the ActivityIndicator
        // indefinitely and Expo Go would silently close after watchdog timeout.
        // Fix: chain .catch() + .finally() so isReady ALWAYS flips to true once
        // init() settles, even on rejection. Diagnostic console output kept so
        // we can observe behavior via Metro / Remote JS Debugger.
        console.log('[supero-mobile] AuthProvider mount, calling client.init()');
        const _t0 = Date.now();
        const _watchdog = setTimeout(() => {
            console.warn('[supero-mobile] client.init() did not settle within 5s');
        }, 5000);
        client.init()
            .then(() => {
                console.log('[supero-mobile] client.init() RESOLVED in', Date.now() - _t0, 'ms');
                setIsAuthenticated(client.isAuthenticated());
                setUserInfo(client.userInfo);
            })
            .catch((err) => {
                console.error('[supero-mobile] client.init() REJECTED:', err && err.message, err);
            })
            .finally(() => {
                clearTimeout(_watchdog);
                setIsReady(true);
            });
    }, []);

    const login = async (domain, email, password, project) => {
        await client.login(domain, email, password, project);
        setIsAuthenticated(true);
        setUserInfo(client.userInfo);
    };

    const logout = async () => {
        await client.clearAuth();
        setIsAuthenticated(false);
        setUserInfo({});
    };

    return (
        <AuthContext.Provider value={{ isReady, isAuthenticated, userInfo, login, logout }}>
            {children}
        </AuthContext.Provider>
    );
}

export const useAuth = () => useContext(AuthContext);

// ─────────────────────────────────────────────────────────
// Services — all 26 platform services (SINGLE definition)
// ─────────────────────────────────────────────────────────

function _svc(serviceId, operationId, input) {
    return client.request('POST', '/api/v1/services/execute',
        { service_id: serviceId, operation_id: operationId, input });
}

export const services = {
    email: { send: (p) => _svc('email', 'send_email', { to_email: p.to, subject: p.subject, body_html: p.bodyHtml || p.body, body_text: p.bodyText, from_name: p.fromName }) },
    emailSmtp: { send: (p) => _svc('email_smtp', 'send_email', { to_email: p.to, subject: p.subject, body_html: p.bodyHtml, body_text: p.bodyText }) },
    sms: { send: (p) => _svc('sms', 'send_sms', { to_number: p.to, body: p.body }) },
    whatsapp: {
        send: (p) => _svc('whatsapp', 'send_message', { to_number: p.to, body: p.body }),
        sendTemplate: (p) => _svc('whatsapp', 'send_template', { to_number: p.to, template_name: p.templateName, template_params: p.templateParams }),
    },
    push: {
        notify: (p) => _svc('push_notification', 'send_notification', { device_token: p.token, title: p.title, body: p.body }),
        broadcast: (p) => _svc('push_notification', 'send_topic_broadcast', { topic: p.topic, title: p.title, body: p.body }),
    },
    slack: {
        message: (p) => _svc('slack', 'send_message', { channel: p.channel, text: p.text }),
        createChannel: (p) => _svc('slack', 'create_channel', { channel_name: p.name, topic: p.topic }),
    },
    stripe: {
        checkout: (p) => _svc('stripe_checkout', 'create_checkout_session', { amount: p.amount, product_name: p.product, success_url: p.successUrl }),
        paymentLink: (p) => _svc('stripe_checkout', 'create_payment_link', { price_id: p.priceId }),
    },
    billing: {
        createCustomer: (p) => _svc('billing', 'create_customer', { email: p.email, company_name: p.company }),
        createInvoice: (p) => _svc('billing', 'create_invoice', { customer_uuid: p.customerUuid, amount: p.amount, currency: p.currency || 'USD', due_date: p.dueDate }),
    },
    paypal: { createOrder: (p) => _svc('billing_paypal', 'create_order', { amount: p.amount, currency: p.currency || 'USD', description: p.description }) },
    razorpay: { createOrder: (p) => _svc('billing_razorpay', 'create_order', { amount_paise: p.amountPaise, currency: p.currency || 'INR', customer_name: p.customerName }) },
    plaid: {
        createLinkToken: (p) => _svc('plaid', 'create_link_token', { client_user_id: p.userId, products: p.products || 'transactions' }),
        exchangeToken: (p) => _svc('plaid', 'exchange_public_token', { public_token: p.publicToken }),
    },
    salesforce: {
        createLead: (p) => _svc('salesforce', 'create_lead', { last_name: p.lastName, company: p.company, email: p.email }),
        createCase: (p) => _svc('salesforce', 'create_case', { subject: p.subject, priority: p.priority || 'Medium', case_origin: p.origin || 'Web' }),
    },
    instagram: { publish: (p) => _svc('instagram', 'publish_post', { media_type: p.mediaType || 'IMAGE', media_url: p.mediaUrl, caption: p.caption }) },
    twitter: {
        tweet: (p) => _svc('x_social', 'post_tweet', { text: p.text }),
        thread: (p) => _svc('x_social', 'post_thread', { tweets_text: p.tweets }),
    },
    linkedin: { post: (p) => _svc('linkedin', 'create_post', { text: p.text }) },
    youtube: { search: (p) => _svc('youtube', 'search_videos', { query: p.query, max_results: p.maxResults || 5 }) },
    github: {
        createIssue: (p) => _svc('github', 'create_issue', { repo_owner: p.owner, repo_name: p.repo, title: p.title, labels: p.labels }),
        createPR: (p) => _svc('github', 'create_pull_request', { repo_owner: p.owner, repo_name: p.repo, title: p.title, head_branch: p.head, base_branch: p.base || 'main' }),
    },
    bitbucket: { createRepo: (p) => _svc('bitbucket', 'create_repository', { workspace: p.workspace, repo_slug: p.slug, is_private: p.isPrivate !== false }) },
    s3: { uploadUrl: (p) => _svc('amazon_s3', 'generate_upload_url', { key: p.key, content_type: p.contentType }) },
    gdrive: { createFolder: (p) => _svc('google_drive', 'create_folder', { file_name: p.name, description: p.description }) },
    calendar: { createEvent: (p) => _svc('google_calendar', 'create_event', { summary: p.title, start_time: p.start, end_time: p.end, add_meet: !!p.addMeet }) },
    servicenow: {
        createIncident: (p) => _svc('servicenow', 'create_incident', { short_description: p.description, urgency: p.urgency || '3', impact: p.impact || '3' }),
        createChange: (p) => _svc('servicenow', 'create_change_request', { short_description: p.description, change_type: p.type || 'normal' }),
    },
    ai: {
        complete: (p) => _svc('ai', 'simple_completion', { prompt: p.prompt, model: p.model || 'claude-sonnet', max_tokens: p.maxTokens || 1000 }),
        chat: (p) => _svc('ai', 'chat_completion', { messages: p.messages, model: p.model || 'claude-sonnet' }),
    },
    search: { web: (p) => _svc('google_search', 'web_search', { query: p.query, num: p.num || 5 }) },
    otp: { send: (p) => _svc('auth_otp', 'send_otp', { channel: p.channel || 'sms', recipient: p.to, purpose: p.purpose || 'login' }) },
    googleAuth: {
        login: (p) => _svc('google_oauth', 'google_login', { auth_code: p.authCode, redirect_uri: p.redirectUri }),
        signup: (p) => _svc('google_oauth', 'google_signup', { auth_code: p.authCode, redirect_uri: p.redirectUri, signup: true }),
        linkAccount: (p) => _svc('google_oauth', 'link_account', { auth_code: p.authCode, redirect_uri: p.redirectUri, link_account: true }),
        getConfig: () => _svc('google_oauth', 'get_google_config', {}),
    },
    googleAds: {
        createCampaign: (p) => _svc('google_ads', 'create_campaign', { campaign_name: p.campaignName, budget_amount: p.budgetAmount || 50, channel_type: p.channelType || 'SEARCH', bidding_strategy: p.biddingStrategy }),
        listCampaigns: () => _svc('google_ads', 'list_campaigns', { list_campaigns: true }),
        getPerformance: (p) => _svc('google_ads', 'get_performance', p?.query ? { query: p.query } : {}),
    },
    googleReviews: {
        listReviews: (p) => _svc('google_reviews', 'list_reviews', { location_id: p?.locationId, page_size: p?.pageSize }),
        getRating: (locationId) => _svc('google_reviews', 'get_rating', { get_rating: true, location_id: locationId }),
    },
    quickbooks: {
        createCustomer: (p) => _svc('quickbooks', 'create_customer', { display_name: p.displayName, email: p.email, phone: p.phone, company: p.company }),
        createInvoice: (p) => _svc('quickbooks', 'create_invoice', { customer_ref: p.customerRef, line_items: p.lineItems, due_date: p.dueDate, currency: p.currency || 'USD', notes: p.notes }),
        recordPayment: (p) => _svc('quickbooks', 'record_payment', { customer_ref: p.customerRef, amount: p.amount, payment_method: p.paymentMethod, invoice_ref: p.invoiceRef }),
        getReport: (p) => _svc('quickbooks', 'get_report', { report_type: p.reportType, start_date: p.startDate, end_date: p.endDate }),
    },
    mcpServer: {
        registerTools: () => _svc('mcp_server', 'register_tools', {}),
        handleToolCall: (p) => _svc('mcp_server', 'handle_tool_call', { tool_name: p.toolName, arguments: p.arguments }),
        listResources: () => _svc('mcp_server', 'list_resources', {}),
        getEndpoint: () => _svc('mcp_server', 'get_endpoint', {}),
    },
    mcpClient: {
        callTool: (p) => _svc('mcp_client', 'call_tool', { server_url: p.serverUrl, server_name: p.serverName, tool_name: p.toolName, arguments: p.arguments }),
        listTools: (p) => _svc('mcp_client', 'list_tools', { server_url: p.serverUrl, server_name: p.serverName }),
        connectServer: (p) => _svc('mcp_client', 'connect_server', { server_url: p.serverUrl, name: p.name, auth_type: p.authType, auth_token: p.authToken }),
    },
    workflow: {
        run: (id, input) => _svc('workflows', 'execute_workflow', { workflow_id: id, ...input }),
        validate: (id) => _svc('workflows', 'validate_workflow', { workflow_id: id }),
    },
};

// ─────────────────────────────────────────────────────────
// Utilities (identical API to web)
// ─────────────────────────────────────────────────────────

export function buildFieldDefs(attrs) {
    return (attrs || []).map(a => ({
        name: a.name,
        label: a.name.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase()),
        type: a.values ? 'select' : a.type === 'Image' ? 'image' : a.type === 'File' ? 'file'
            : a.type === 'bool' ? 'bool' : (a.type === 'float' || a.type === 'integer') ? 'number'
            : (a.type === 'datetime' || a.type === 'date') ? 'date'
            : a.type === 'string' && a.name.includes('description') ? 'textarea' : 'text',
        required: !!a.mandatory, isList: !!a.list,
        options: a.values ? a.values.map(v => ({ value: v, label: v.replace(/_/g, ' ') })) : undefined,
    }));
}

export function parse422Error(error) {
    const msg = error?.body?.error || error?.body?.message || error?.message || '';
    if (msg.includes('Missing mandatory field')) {
        return msg.split(';').map(s => s.trim().replace(/.*Missing mandatory field:\s*/, '').replace(/_/g, ' ')).filter(Boolean);
    }
    return [];
}

export async function triggerWorkflow(workflowId, schema, item, inputFields = []) {
    return client.request('POST', '/api/v1/services/execute', {
        service_id: 'workflows', operation_id: 'execute_workflow',
        input: { workflow_id: workflowId, [`${schema}_uuid`]: item.uuid,
            ...Object.fromEntries(inputFields.map(f => [f, item[f] || ''])) },
    });
}

// ─────────────────────────────────────────────────────────
// InlineSelect (unchanged — no @react-native-picker/picker)
// ─────────────────────────────────────────────────────────

export function InlineSelect({ value, options = [], onChange, placeholder, required }) {
    const [expanded, setExpanded] = useState(false);
    const theme = useTheme();
    const selected = options.find(o => o.value === value);
    return (
        <View>
            <Pressable style={selS.btn} onPress={() => setExpanded(!expanded)}>
                <Text style={[selS.btnText, !value && { color: '#94a3b8' }]}>
                    {selected ? selected.label : placeholder || 'Select...'}
                </Text>
                <Text style={selS.arrow}>{expanded ? '▴' : '▾'}</Text>
            </Pressable>
            {expanded && (
                <View style={selS.list}>
                    {!required && (
                        <Pressable style={selS.clearBtn} onPress={() => { onChange(''); setExpanded(false); }}>
                            <Text style={selS.clearText}>✕ Clear</Text>
                        </Pressable>
                    )}
                    {options.map(o => (
                        <Pressable key={o.value}
                            style={[selS.item, value === o.value && { backgroundColor: theme.palette[50] }]}
                            onPress={() => { onChange(o.value); setExpanded(false); }}>
                            <Text style={[selS.itemText, value === o.value && { color: theme.primary, fontWeight: '700' }]}>
                                {value === o.value ? '✓  ' : '    '}{o.label}
                            </Text>
                        </Pressable>
                    ))}
                </View>
            )}
        </View>
    );
}

const selS = StyleSheet.create({
    btn: { backgroundColor: '#fff', borderWidth: 1, borderColor: '#e2e8f0', borderRadius: 12, padding: 14, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
    btnText: { fontSize: 15, color: '#1e293b', flex: 1 },
    arrow: { fontSize: 14, color: '#94a3b8' },
    list: { backgroundColor: '#fff', borderWidth: 1, borderColor: '#e2e8f0', borderRadius: 12, marginTop: 4, overflow: 'hidden' },
    clearBtn: { padding: 12, borderBottomWidth: 1, borderBottomColor: '#f1f5f9' },
    clearText: { fontSize: 12, color: '#94a3b8' },
    item: { padding: 14, borderBottomWidth: 1, borderBottomColor: '#f1f5f9' },
    itemText: { fontSize: 14, color: '#1e293b' },
});

// ═══════════════════════════════════════════════════════════
// SCREENS — v3 visual overhaul
// ═══════════════════════════════════════════════════════════

// ─────────────────────────────────────────────────────────
// LoginScreen — themed
// ─────────────────────────────────────────────────────────

function LoginScreen({ navigation, route }) {
    const { appName, domain, project, signupMode } = route.params;
    const { login } = useAuth();
    const theme = useTheme();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    const handleLogin = async () => {
        if (!email || !password) { setError('Please enter email and password'); return; }
        setLoading(true); setError('');
        try { await login(domain, email, password, project); }
        catch (err) { setError(err.message || 'Login failed'); }
        finally { setLoading(false); }
    };

    return (
        <ScrollView contentContainerStyle={{ flex: 1, justifyContent: 'center', padding: 24, backgroundColor: '#fff' }}>
            <View style={{ alignItems: 'center', marginBottom: 40 }}>
                <View style={{ width: 72, height: 72, borderRadius: 20, backgroundColor: theme.palette[50],
                    alignItems: 'center', justifyContent: 'center', marginBottom: 16 }}>
                    <Text style={{ fontSize: 36 }}>🚀</Text>
                </View>
                <Text style={{ fontSize: 26, fontWeight: '800', color: '#1e293b' }}>{appName || 'App'}</Text>
                <Text style={{ fontSize: 14, color: '#94a3b8', marginTop: 6 }}>Sign in to your account</Text>
            </View>

            {error ? <View style={{ backgroundColor: '#fef2f2', borderRadius: 14, padding: 14, marginBottom: 16 }}>
                <Text style={{ color: '#991b1b', fontSize: 13, fontWeight: '500' }}>{error}</Text>
            </View> : null}

            <TextInput placeholder="Email address" value={email} onChangeText={setEmail}
                keyboardType="email-address" autoCapitalize="none" placeholderTextColor="#94a3b8"
                style={{ borderWidth: 1, borderColor: '#e2e8f0', borderRadius: 14, padding: 16, fontSize: 15, marginBottom: 12, backgroundColor: '#f8fafc', color: '#1e293b' }} />
            <TextInput placeholder="Password" value={password} onChangeText={setPassword}
                secureTextEntry returnKeyType="go" onSubmitEditing={handleLogin} placeholderTextColor="#94a3b8"
                style={{ borderWidth: 1, borderColor: '#e2e8f0', borderRadius: 14, padding: 16, fontSize: 15, marginBottom: 24, backgroundColor: '#f8fafc', color: '#1e293b' }} />

            <Pressable onPress={handleLogin} disabled={loading}
                style={{ backgroundColor: theme.primary, borderRadius: 14, padding: 17, alignItems: 'center',
                    opacity: loading ? 0.6 : 1, shadowColor: theme.primary, shadowOffset: { width: 0, height: 4 },
                    shadowOpacity: 0.25, shadowRadius: 8, elevation: 4 }}>
                <Text style={{ color: '#fff', fontWeight: '700', fontSize: 15 }}>
                    {loading ? 'Signing in...' : 'Sign In'}
                </Text>
            </Pressable>

            {signupMode && signupMode !== 'none' &&
                <Pressable onPress={() => navigation.navigate('Signup')} style={{ marginTop: 24, alignItems: 'center' }}>
                    <Text style={{ color: theme.primary, fontSize: 14, fontWeight: '600' }}>
                        {signupMode === 'invite_only' ? 'Have an invite code?' : 'Create Account'}
                    </Text>
                </Pressable>
            }
        </ScrollView>
    );
}

// ─────────────────────────────────────────────────────────
// SignupScreen — themed
// ─────────────────────────────────────────────────────────

function SignupScreen({ navigation, route }) {
    const { appName, domain, project, signupMode } = route.params;
    const { login } = useAuth();
    const theme = useTheme();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [name, setName] = useState('');
    const [code, setCode] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    const handleSignup = async () => {
        if (!email || !password) { setError('Email and password required'); return; }
        if (password.length < 8) { setError('Password must be 8+ characters'); return; }
        if (signupMode === 'invite_only' && !code) { setError('Invite code required'); return; }
        setLoading(true); setError('');
        try {
            const payload = { email, password, domain, project };
            if (name) payload.full_name = name;
            if (code) payload.invite_code = code;
            await client.request('POST', '/api/signup', payload);
            await login(domain, email, password, project);
        } catch (err) { setError(err.message || 'Signup failed'); }
        finally { setLoading(false); }
    };

    const inputStyle = { borderWidth: 1, borderColor: '#e2e8f0', borderRadius: 14, padding: 16, fontSize: 15, marginBottom: 12, backgroundColor: '#f8fafc', color: '#1e293b' };

    return (
        <ScrollView contentContainerStyle={{ flex: 1, justifyContent: 'center', padding: 24, backgroundColor: '#fff' }}>
            <Text style={{ fontSize: 26, fontWeight: '800', color: '#1e293b', textAlign: 'center', marginBottom: 8 }}>Create Account</Text>
            <Text style={{ fontSize: 14, color: '#94a3b8', textAlign: 'center', marginBottom: 28 }}>Join {appName}</Text>
            {error ? <View style={{ backgroundColor: '#fef2f2', borderRadius: 14, padding: 14, marginBottom: 16 }}>
                <Text style={{ color: '#991b1b', fontSize: 13 }}>{error}</Text>
            </View> : null}
            <TextInput placeholder="Full name (optional)" value={name} onChangeText={setName} placeholderTextColor="#94a3b8" style={inputStyle} />
            <TextInput placeholder="Email address" value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" placeholderTextColor="#94a3b8" style={inputStyle} />
            <TextInput placeholder="Password (8+ characters)" value={password} onChangeText={setPassword} secureTextEntry placeholderTextColor="#94a3b8" style={inputStyle} />
            {signupMode === 'invite_only' && <TextInput placeholder="Invite code" value={code} onChangeText={setCode} placeholderTextColor="#94a3b8" style={inputStyle} />}
            <Pressable onPress={handleSignup} disabled={loading}
                style={{ backgroundColor: theme.primary, borderRadius: 14, padding: 17, alignItems: 'center', opacity: loading ? 0.6 : 1, marginTop: 8 }}>
                <Text style={{ color: '#fff', fontWeight: '700', fontSize: 15 }}>{loading ? 'Creating...' : 'Create Account'}</Text>
            </Pressable>
            <Pressable onPress={() => navigation.goBack()} style={{ marginTop: 20, alignItems: 'center' }}>
                <Text style={{ color: theme.primary, fontSize: 14 }}>← Back to login</Text>
            </Pressable>
        </ScrollView>
    );
}

// ─────────────────────────────────────────────────────────
// DashboardScreen v3 — dashboardWidgets support + themed
// ─────────────────────────────────────────────────────────

function DashboardScreen({ navigation, route }) {
    const { tabs, dashboardWidgets } = route.params;
    const theme = useTheme();
    const [stats, setStats] = useState({});
    const [allData, setAllData] = useState({});
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);

    const load = async () => {
        const readable = tabs.filter(t => client.can('read', t.schema));
        const results = await Promise.all(readable.map(async t => {
            try { const data = await client.getObjects(t.schema); return { schema: t.schema, data }; }
            catch { return { schema: t.schema, data: [] }; }
        }));
        const s = {}; const d = {};
        results.forEach(r => { s[r.schema] = r.data.length; d[r.schema] = r.data; });
        setStats(s); setAllData(d); setLoading(false);
    };

    useEffect(() => { load(); }, []);
    const onRefresh = async () => { setRefreshing(true); await load(); setRefreshing(false); };

    // Compute dashboardWidgets if provided
    let widgets = [];
    if (dashboardWidgets && !loading) {
        widgets = dashboardWidgets.map(w => {
            let data = allData[w.schema] || [];
            if (w.filter) data = data.filter(item => Object.keys(w.filter).every(k => item[k] === w.filter[k]));
            let value;
            if (w.aggregate === 'sum' && w.field) value = data.reduce((s, i) => s + (parseFloat(i[w.field]) || 0), 0);
            else if (w.aggregate === 'avg' && w.field) { const t = data.reduce((s, i) => s + (parseFloat(i[w.field]) || 0), 0); value = data.length > 0 ? t / data.length : 0; }
            else value = data.length;
            let formatted;
            if (w.format === 'currency') formatted = formatCurrency(value);
            else if (w.format === 'percent') formatted = value.toFixed(1) + '%';
            else formatted = formatNumber(value);
            return { label: w.label, value: formatted, icon: w.icon || '📊' };
        });
    }

    return (
        <ScrollView style={{ flex: 1, backgroundColor: '#f8fafc' }}
            refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={theme.primary} />}>
            <View style={{ padding: 20 }}>
                <Text style={{ fontSize: 24, fontWeight: '800', color: '#1e293b', marginBottom: 4 }}>Dashboard</Text>
                <Text style={{ fontSize: 13, color: '#94a3b8', marginBottom: 20 }}>Overview of your data</Text>

                {loading ? <ActivityIndicator size="large" color={theme.primary} /> :
                    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 12 }}>
                        {(widgets.length > 0 ? widgets : tabs.filter(t => client.can('read', t.schema)).map(t => ({
                            label: t.label, value: formatNumber(stats[t.schema] || 0), icon: t.icon
                        }))).map((w, i) => (
                            <Pressable key={i}
                                onPress={widgets.length === 0 ? () => navigation.navigate(tabs[i]?.id + '_Tab') : undefined}
                                style={{ backgroundColor: '#fff', borderRadius: 18, padding: 18, width: '47%',
                                    borderWidth: 1, borderColor: '#f1f5f9', borderLeftWidth: 3, borderLeftColor: theme.primary,
                                    shadowColor: '#000', shadowOpacity: 0.03, shadowRadius: 8, elevation: 2 }}>
                                <Text style={{ fontSize: 22, marginBottom: 4 }}>{w.icon}</Text>
                                <Text style={{ fontSize: 28, fontWeight: '900', color: '#1e293b', marginTop: 2 }}>{w.value}</Text>
                                <Text style={{ fontSize: 11, color: '#94a3b8', fontWeight: '500', marginTop: 2 }}>{w.label}</Text>
                            </Pressable>
                        ))}
                    </View>
                }
            </View>
        </ScrollView>
    );
}

// ─────────────────────────────────────────────────────────
// ListScreen v3 — image-forward cards, themed, cardTemplate
// ─────────────────────────────────────────────────────────

function ListScreen({ navigation, route }) {
    const { tab, workflowMap } = route.params;
    const theme = useTheme();
    const [items, setItems] = useState([]);
    const [search, setSearch] = useState('');
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);

    const canCreate = client.can('create', tab.schema);
    const canDelete = client.can('delete', tab.schema);

    const load = async () => {
        try { setItems(await client.getObjects(tab.schema)); }
        catch {} finally { setLoading(false); }
    };

    useEffect(() => { load(); }, [tab.schema]);
    useEffect(() => {
        const unsub = navigation.addListener('focus', () => { load(); });
        return unsub;
    }, [navigation]);

    const onRefresh = async () => { setRefreshing(true); await load(); setRefreshing(false); };

    const filtered = search
        ? items.filter(i => JSON.stringify(i).toLowerCase().includes(search.toLowerCase()))
        : items;

    // Determine card layout
    const tmpl = tab.cardTemplate;
    const imgAttr = tmpl ? tab.attrs.find(a => a.name === tmpl.image) : tab.attrs.find(a => a.type === 'Image' && !a.list);
    const hasImage = !!imgAttr;
    const featuredAttrs = tab.attrs.filter(a => a.featured).slice(0, 2);

    const handleDelete = (item) => {
        Alert.alert('Delete?', `Delete "${item.display_name || item.name}"?`, [
            { text: 'Cancel', style: 'cancel' },
            { text: 'Delete', style: 'destructive', onPress: async () => {
                try { await client.deleteObject(tab.schema, item.uuid, item); load(); }
                catch (err) { Alert.alert('Error', err.message); }
            }},
        ]);
    };

    const renderItem = ({ item }) => {
        const imgUrl = imgAttr ? resolveImageUrl(item[imgAttr.name]) : '';
        const title = (tmpl?.title && item[tmpl.title]) || item.display_name || item.name || '';
        const subtitle = tmpl?.subtitle && item[tmpl.subtitle] ? String(item[tmpl.subtitle]) : '';
        const priceAttr = tmpl?.price || tab.attrs.find(a => (a.type === 'float' || a.type === 'integer') && ['price','cost','amount','total','rent','rate','fee'].some(k => a.name.includes(k)))?.name;
        const priceVal = priceAttr && item[priceAttr] != null ? formatCurrency(item[priceAttr]) + (tmpl?.priceSuffix || '') : '';
        const statusVal = item.status || (tmpl?.badge && item[tmpl.badge]) || '';
        const statusStyle = getStatusStyle(statusVal);

        if (hasImage && imgUrl) {
            // Image card — two-column grid style
            return (
                <Pressable
                    onPress={() => navigation.navigate(tab.id + '_Detail', { item, tab, workflowMap })}
                    onLongPress={canDelete ? () => handleDelete(item) : undefined}
                    style={{ backgroundColor: '#fff', borderRadius: 16, marginBottom: 12, borderWidth: 1,
                        borderColor: '#f1f5f9', overflow: 'hidden', shadowColor: '#000', shadowOpacity: 0.04,
                        shadowRadius: 8, elevation: 2 }}>
                    <Image source={{ uri: imgUrl }}
                        style={{ width: '100%', height: 160, backgroundColor: '#f1f5f9' }} />
                    {priceVal ? <View style={{ position: 'absolute', top: 12, right: 12, backgroundColor: 'rgba(255,255,255,0.92)',
                        borderRadius: 10, paddingHorizontal: 10, paddingVertical: 5 }}>
                        <Text style={{ fontSize: 13, fontWeight: '800', color: '#1e293b' }}>{priceVal}</Text>
                    </View> : null}
                    {statusVal ? <View style={{ position: 'absolute', top: 12, left: 12,
                        backgroundColor: statusStyle.bg, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3 }}>
                        <Text style={{ fontSize: 10, fontWeight: '700', color: statusStyle.text }}>{statusVal.replace(/_/g, ' ')}</Text>
                    </View> : null}
                    <View style={{ padding: 14 }}>
                        <Text style={{ fontWeight: '700', fontSize: 15, color: '#1e293b' }}>{title}</Text>
                        {subtitle ? <Text style={{ fontSize: 12, color: '#94a3b8', marginTop: 2 }}>{subtitle}</Text> : null}
                        {featuredAttrs.length > 0 && !tmpl && <Text style={{ fontSize: 11, color: '#94a3b8', marginTop: 4 }}>
                            {featuredAttrs.map(a => item[a.name] != null ? formatFieldValue(a, item[a.name]) : null).filter(Boolean).join(' · ')}
                        </Text>}
                    </View>
                </Pressable>
            );
        }

        // Standard list card
        const hasPerson = tab.attrs.some(a => a.name.includes('email') || a.name.includes('phone'));
        const initials = title.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();

        return (
            <Pressable
                onPress={() => navigation.navigate(tab.id + '_Detail', { item, tab, workflowMap })}
                onLongPress={canDelete ? () => handleDelete(item) : undefined}
                style={{ backgroundColor: '#fff', borderRadius: 14, padding: 14, marginBottom: 10, borderWidth: 1,
                    borderColor: '#f1f5f9', flexDirection: 'row', alignItems: 'center', gap: 12,
                    borderLeftWidth: 3, borderLeftColor: theme.palette[300] }}>
                {hasPerson ? (
                    <View style={{ width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center',
                        backgroundColor: theme.palette[100] }}>
                        <Text style={{ fontSize: 14, fontWeight: '700', color: theme.primary }}>{initials || '?'}</Text>
                    </View>
                ) : (
                    <View style={{ width: 40, height: 40, borderRadius: 12, backgroundColor: theme.palette[50],
                        alignItems: 'center', justifyContent: 'center' }}>
                        <Text style={{ fontSize: 18 }}>{tab.icon}</Text>
                    </View>
                )}
                <View style={{ flex: 1 }}>
                    <Text style={{ fontWeight: '700', fontSize: 14, color: '#1e293b' }}>{title}</Text>
                    {subtitle ? <Text style={{ fontSize: 12, color: '#94a3b8', marginTop: 1 }}>{subtitle}</Text> : null}
                    {featuredAttrs.length > 0 && <Text style={{ fontSize: 11, color: '#b0b8c4', marginTop: 2 }}>
                        {featuredAttrs.map(a => item[a.name] != null ? formatFieldValue(a, item[a.name]) : null).filter(Boolean).join(' · ')}
                    </Text>}
                    {statusVal ? <View style={{ backgroundColor: statusStyle.bg, borderRadius: 8, paddingHorizontal: 8,
                        paddingVertical: 2, alignSelf: 'flex-start', marginTop: 4 }}>
                        <Text style={{ fontSize: 10, fontWeight: '700', color: statusStyle.text }}>{statusVal.replace(/_/g, ' ')}</Text>
                    </View> : null}
                </View>
                {priceVal ? <Text style={{ fontSize: 14, fontWeight: '800', color: theme.palette[700] }}>{priceVal}</Text>
                    : <Text style={{ color: '#cbd5e1', fontSize: 18 }}>›</Text>}
            </Pressable>
        );
    };

    return (
        <View style={{ flex: 1, backgroundColor: '#f8fafc' }}>
            <View style={{ paddingHorizontal: 16, paddingTop: 12, paddingBottom: 8, flexDirection: 'row', gap: 10, alignItems: 'center' }}>
                <View style={{ flex: 1, backgroundColor: '#fff', borderRadius: 12, flexDirection: 'row', alignItems: 'center',
                    borderWidth: 1, borderColor: '#e2e8f0', paddingHorizontal: 12 }}>
                    <Text style={{ color: '#94a3b8', marginRight: 8 }}>🔍</Text>
                    <TextInput placeholder={`Search ${tab.label}...`} value={search} onChangeText={setSearch}
                        placeholderTextColor="#94a3b8"
                        style={{ flex: 1, paddingVertical: 12, fontSize: 14, color: '#1e293b' }} />
                </View>
                {canCreate && <Pressable
                    onPress={() => navigation.navigate(tab.id + '_Form', { tab, mode: 'create' })}
                    style={{ backgroundColor: theme.primary, borderRadius: 12, paddingHorizontal: 16, paddingVertical: 13,
                        shadowColor: theme.primary, shadowOpacity: 0.25, shadowRadius: 8, elevation: 4 }}>
                    <Text style={{ color: '#fff', fontWeight: '700', fontSize: 15 }}>+</Text>
                </Pressable>}
            </View>
            {loading ? <ActivityIndicator style={{ marginTop: 40 }} color={theme.primary} /> :
                filtered.length === 0 ?
                    <View style={{ alignItems: 'center', paddingTop: 60 }}>
                        <Text style={{ fontSize: 48, opacity: 0.15, marginBottom: 8 }}>{tab.icon}</Text>
                        <Text style={{ color: '#94a3b8', fontSize: 15, fontWeight: '600' }}>No {tab.label.toLowerCase()} yet</Text>
                        <Text style={{ color: '#cbd5e1', fontSize: 13, marginTop: 4 }}>Create your first record</Text>
                        {canCreate && <Pressable
                            onPress={() => navigation.navigate(tab.id + '_Form', { tab, mode: 'create' })}
                            style={{ backgroundColor: theme.primary, borderRadius: 12, paddingHorizontal: 24, paddingVertical: 14, marginTop: 20 }}>
                            <Text style={{ color: '#fff', fontWeight: '700' }}>+ Create First</Text>
                        </Pressable>}
                    </View>
                :
                    <FlatList data={filtered} keyExtractor={item => item.uuid}
                        renderItem={renderItem}
                        contentContainerStyle={{ padding: 16 }}
                        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={theme.primary} />} />
            }
        </View>
    );
}

// ─────────────────────────────────────────────────────────
// DetailScreen v3 — actionButtons, themed fields
// ─────────────────────────────────────────────────────────

function DetailScreen({ navigation, route }) {
    const { item, tab, workflowMap, actionButtons: actionBtns } = route.params;
    const theme = useTheme();
    const canUpdate = client.can('update', tab.schema);
    const canDelete = client.can('delete', tab.schema);

    const heroImgAttr = tab.attrs.find(a => a.type === 'Image' && !a.list);
    const galleryAttr = tab.attrs.find(a => a.type === 'Image' && a.list);
    const heroUrl = heroImgAttr ? resolveImageUrl(item[heroImgAttr.name]) : '';
    const galleryItems = galleryAttr ? (item[galleryAttr.name] || []) : [];

    const displayFields = tab.attrs.filter(a =>
        a.type !== 'Image' && a.type !== 'File' &&
        !['workflow_status', 'processed_at', 'fq_name', 'uuid'].includes(a.name));

    const wf = workflowMap?.[tab.schema];
    const [triggering, setTriggering] = useState(false);
    const [sending, setSending] = useState({});

    const handleTrigger = async () => {
        setTriggering(true);
        try {
            await triggerWorkflow(wf.workflowId, tab.schema, item, wf.inputFields);
            Alert.alert('Success', wf.triggerLabel ? wf.triggerLabel + ' completed' : 'Workflow triggered');
        } catch (err) { Alert.alert('Error', err.message); }
        finally { setTriggering(false); }
    };

    const handleDelete = () => {
        Alert.alert('Delete?', `Delete "${item.display_name || item.name}"?`, [
            { text: 'Cancel', style: 'cancel' },
            { text: 'Delete', style: 'destructive', onPress: async () => {
                try { await client.deleteObject(tab.schema, item.uuid, item); navigation.goBack(); }
                catch (err) { Alert.alert('Error', err.message); }
            }},
        ]);
    };

    // actionButtons handler
    const resolveTemplate = (template, data) => {
        if (!template) return '';
        return template.replace(/\{\{(\w+)\}\}/g, (m, key) => data[key] || data.display_name || data.name || m);
    };

    const handleAction = async (btn, idx) => {
        setSending(p => ({ ...p, [idx]: true }));
        try {
            if (btn.service === 'email' && btn.emailField && item[btn.emailField]) {
                await services.email.send({ to: item[btn.emailField], subject: resolveTemplate(btn.subject || 'Notification', item), bodyHtml: '<p>' + resolveTemplate(btn.bodyTemplate || 'Hello!', item) + '</p>' });
            } else if (btn.service === 'sms' && btn.phoneField && item[btn.phoneField]) {
                await services.sms.send({ to: item[btn.phoneField], body: resolveTemplate(btn.bodyTemplate || 'Hello!', item) });
            } else { Alert.alert('Missing', 'Contact field not found'); return; }
            Alert.alert('Success', btn.successMessage || btn.label + ' sent!');
        } catch (err) { Alert.alert('Failed', err.message); }
        finally { setSending(p => ({ ...p, [idx]: false })); }
    };

    const schemaActions = actionBtns?.[tab.schema] || [];

    return (
        <ScrollView style={{ flex: 1, backgroundColor: '#fff' }}>
            {heroUrl ? <Image source={{ uri: heroUrl }} style={{ width: '100%', height: 240 }} /> : null}
            <View style={{ padding: 20 }}>
                <Text style={{ fontSize: 24, fontWeight: '800', color: '#1e293b' }}>{item.display_name || item.name}</Text>
                <View style={{ flexDirection: 'row', gap: 8, marginTop: 8, flexWrap: 'wrap' }}>
                    {item.status && (() => { const s = getStatusStyle(item.status); return (
                        <View style={{ backgroundColor: s.bg, borderRadius: 12, paddingHorizontal: 10, paddingVertical: 4 }}>
                            <Text style={{ fontSize: 11, fontWeight: '700', color: s.text }}>{item.status.replace(/_/g, ' ')}</Text>
                        </View>
                    ); })()}
                    {item.workflow_status && (() => { const ok = item.workflow_status === 'processed'; return (
                        <View style={{ backgroundColor: ok ? '#dcfce7' : '#fee2e2', borderRadius: 12, paddingHorizontal: 10, paddingVertical: 4 }}>
                            <Text style={{ fontSize: 11, fontWeight: '700', color: ok ? '#166534' : '#991b1b' }}>
                                {ok ? '✓ Processed' : '✕ Failed'}
                            </Text>
                        </View>
                    ); })()}
                </View>

                {/* Workflow trigger */}
                {wf && client.can('create', tab.schema) &&
                    <Pressable onPress={handleTrigger} disabled={triggering}
                        style={{ backgroundColor: theme.palette[50], borderRadius: 14, padding: 16, marginTop: 16, alignItems: 'center' }}>
                        <Text style={{ color: theme.palette[700], fontWeight: '700', fontSize: 13 }}>
                            {triggering ? '⏳ Running...' : (wf.triggerLabel || '⚡ Run Workflow')}
                        </Text>
                    </Pressable>
                }

                {/* Action buttons (declarative) */}
                {schemaActions.length > 0 && (
                    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 16 }}>
                        {schemaActions.map((btn, idx) => {
                            const fieldName = btn.emailField || btn.phoneField;
                            if (fieldName && !item[fieldName]) return null;
                            return (
                                <Pressable key={idx} onPress={() => handleAction(btn, idx)} disabled={!!sending[idx]}
                                    style={{ backgroundColor: theme.palette[50], borderRadius: 12, paddingHorizontal: 16,
                                        paddingVertical: 12, opacity: sending[idx] ? 0.6 : 1 }}>
                                    <Text style={{ color: theme.palette[700], fontWeight: '600', fontSize: 13 }}>
                                        {sending[idx] ? '⏳ Sending...' : btn.label}
                                    </Text>
                                </Pressable>
                            );
                        })}
                    </View>
                )}

                {/* Field grid */}
                <View style={{ marginTop: 20, gap: 8 }}>
                    {displayFields.map(attr => (
                        <View key={attr.name} style={{ backgroundColor: theme.palette[50], borderRadius: 14, padding: 14,
                            borderWidth: 1, borderColor: theme.palette[100] }}>
                            <Text style={{ fontSize: 10, color: theme.palette[400], textTransform: 'uppercase', letterSpacing: 0.6, marginBottom: 2 }}>
                                {attr.name.replace(/_/g, ' ')}
                            </Text>
                            <Text style={{ fontSize: 14, fontWeight: '500', color: '#1e293b' }}>
                                {formatFieldValue(attr, item[attr.name])}
                            </Text>
                        </View>
                    ))}
                </View>

                {/* Gallery */}
                {galleryItems.length > 0 && <View style={{ marginTop: 20 }}>
                    <Text style={{ fontWeight: '700', marginBottom: 8, color: '#1e293b' }}>Gallery</Text>
                    <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                        {galleryItems.map((img, i) => {
                            const url = resolveImageUrl(img);
                            return url ? <Image key={i} source={{ uri: url }}
                                style={{ width: 160, height: 110, borderRadius: 12, marginRight: 10 }} /> : null;
                        })}
                    </ScrollView>
                </View>}

                {/* Actions */}
                <View style={{ flexDirection: 'row', gap: 10, marginTop: 24 }}>
                    {canUpdate && <Pressable
                        onPress={() => navigation.navigate(tab.id + '_Form', { tab, mode: 'edit', item })}
                        style={{ flex: 1, backgroundColor: theme.primary, borderRadius: 14, padding: 15, alignItems: 'center' }}>
                        <Text style={{ color: '#fff', fontWeight: '700' }}>✏️ Edit</Text>
                    </Pressable>}
                    {canDelete && <Pressable onPress={handleDelete}
                        style={{ flex: 1, backgroundColor: '#fef2f2', borderRadius: 14, padding: 15, alignItems: 'center' }}>
                        <Text style={{ color: '#991b1b', fontWeight: '700' }}>🗑️ Delete</Text>
                    </Pressable>}
                </View>
            </View>
        </ScrollView>
    );
}

// ─────────────────────────────────────────────────────────
// FormScreen — themed, unchanged logic
// ─────────────────────────────────────────────────────────

function FormScreen({ navigation, route }) {
    const { tab, mode, item: existingItem } = route.params;
    const theme = useTheme();
    const [formData, setFormData] = useState(existingItem || {});
    const [saving, setSaving] = useState(false);
    const [error, setError] = useState('');
    const [parents, setParents] = useState([]);
    const fields = buildFieldDefs(tab.attrs);

    useEffect(() => {
        if (tab.parentSchema && mode === 'create') {
            client.getObjects(tab.parentSchema).then(setParents).catch(() => {});
        }
    }, []);

    const handleChange = (name, value) => setFormData(prev => ({ ...prev, [name]: value }));

    const handleSave = async () => {
        const missing = fields.filter(f => f.required && !formData[f.name]?.toString().trim()).map(f => f.label);
        if (missing.length) { setError('Required: ' + missing.join(', ')); return; }
        setSaving(true); setError('');
        try {
            if (mode === 'edit' && existingItem) {
                await client.updateObject(tab.schema, existingItem.uuid, formData, existingItem);
            } else {
                const data = { ...formData };
                if (tab.parentSchema && data._parent_uuid) {
                    data.parent_uuid = data._parent_uuid; data.parent_type = tab.parentSchema;
                    delete data._parent_uuid;
                }
                await client.createObject(tab.schema, data);
            }
            navigation.goBack();
        } catch (err) {
            const parsed = parse422Error(err);
            setError(parsed.length ? 'Missing: ' + parsed.join(', ') : err.message);
        } finally { setSaving(false); }
    };

    const inputStyle = { borderWidth: 1, borderColor: '#e2e8f0', borderRadius: 14, padding: 16, fontSize: 15, backgroundColor: '#f8fafc', color: '#1e293b' };

    return (
        <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView style={{ flex: 1, backgroundColor: '#fff' }} contentContainerStyle={{ padding: 20 }}>
            <Text style={{ fontSize: 22, fontWeight: '800', color: '#1e293b', marginBottom: 20 }}>
                {mode === 'edit' ? 'Edit' : 'New'} {tab.label.replace(/s$/, '')}
            </Text>
            {error ? <View style={{ backgroundColor: '#fef2f2', borderRadius: 14, padding: 14, marginBottom: 16 }}>
                <Text style={{ color: '#991b1b', fontSize: 13 }}>{error}</Text>
            </View> : null}
            {tab.parentSchema && mode === 'create' && parents.length > 0 &&
                <View style={{ marginBottom: 16 }}>
                    <Text style={{ fontSize: 13, fontWeight: '600', color: '#1e293b', marginBottom: 6 }}>
                        {tab.parentLabel || tab.parentSchema} <Text style={{ color: '#ef4444' }}>*</Text>
                    </Text>
                    <InlineSelect value={formData._parent_uuid || ''}
                        options={parents.map(p => ({ value: p.uuid, label: p.display_name || p.name }))}
                        onChange={v => handleChange('_parent_uuid', v)}
                        placeholder={'Select ' + (tab.parentLabel || tab.parentSchema) + '...'} required />
                </View>
            }
            {fields.map(f => (
                <View key={f.name} style={{ marginBottom: 16 }}>
                    <Text style={{ fontSize: 13, fontWeight: '600', color: '#1e293b', marginBottom: 6 }}>
                        {f.label} {f.required && <Text style={{ color: '#ef4444' }}>*</Text>}
                    </Text>
                    {f.type === 'select' ?
                        <InlineSelect value={formData[f.name] || ''} options={f.options || []}
                            onChange={v => handleChange(f.name, v)} placeholder="Select..." required={f.required} />
                    : f.type === 'bool' ?
                        <Switch value={!!formData[f.name]} onValueChange={v => handleChange(f.name, v)}
                            trackColor={{ true: theme.primary, false: '#e2e8f0' }} />
                    : f.type === 'image' || f.type === 'file' ?
                        <View style={{ backgroundColor: '#f8fafc', borderRadius: 14, padding: 18, alignItems: 'center' }}>
                            <Text style={{ color: '#94a3b8', fontSize: 13 }}>📷 Upload via web portal</Text>
                        </View>
                    : f.type === 'textarea' ?
                        <TextInput value={formData[f.name] || ''} onChangeText={v => handleChange(f.name, v)}
                            multiline numberOfLines={4} textAlignVertical="top" placeholderTextColor="#94a3b8"
                            style={[inputStyle, { minHeight: 100 }]} />
                    :
                        <TextInput value={formData[f.name] != null ? String(formData[f.name]) : ''}
                            onChangeText={v => handleChange(f.name, f.type === 'number' ? (v === '' ? '' : parseFloat(v) || '') : v)}
                            keyboardType={f.type === 'number' ? 'decimal-pad' : f.name.includes('email') ? 'email-address' : 'default'}
                            autoCapitalize={f.name.includes('email') ? 'none' : 'sentences'}
                            placeholderTextColor="#94a3b8"
                            style={inputStyle} />
                    }
                </View>
            ))}
            <Pressable onPress={handleSave} disabled={saving}
                style={{ backgroundColor: theme.primary, borderRadius: 14, padding: 17, alignItems: 'center',
                    opacity: saving ? 0.6 : 1, marginTop: 8, marginBottom: 40 }}>
                <Text style={{ color: '#fff', fontWeight: '700', fontSize: 15 }}>
                    {saving ? 'Saving...' : (mode === 'edit' ? 'Save Changes' : 'Create')}
                </Text>
            </Pressable>
        </ScrollView>
        </KeyboardAvoidingView>
    );
}

// ─────────────────────────────────────────────────────────
// AIChatScreen — themed
// ─────────────────────────────────────────────────────────

function AIChatScreen() {
    const theme = useTheme();
    const [messages, setMessages] = useState([
        { role: 'assistant', text: 'Hi! I\'m your AI assistant. Ask me anything about your data.' }
    ]);
    const [input, setInput] = useState('');
    const [loading, setLoading] = useState(false);
    const [sessionId, setSessionId] = useState(null);

    const handleSend = async () => {
        const msg = input.trim();
        if (!msg || loading) return;
        setInput('');
        setMessages(prev => [...prev, { role: 'user', text: msg }]);
        setLoading(true);
        try {
            const result = await aiChat(msg, sessionId);
            setSessionId(result.sessionId);
            setMessages(prev => [...prev, { role: 'assistant', text: result.response || 'No response.' }]);
        } catch (err) {
            setMessages(prev => [...prev, { role: 'assistant', text: '⚠️ ' + (err.message || 'AI request failed') }]);
        } finally { setLoading(false); }
    };

    return (
        <View style={{ flex: 1, backgroundColor: '#fff' }}>
            <FlatList data={messages} keyExtractor={(_, i) => String(i)}
                contentContainerStyle={{ padding: 16, paddingBottom: 80 }}
                renderItem={({ item: msg }) => (
                    <View style={{ alignItems: msg.role === 'user' ? 'flex-end' : 'flex-start', marginBottom: 12 }}>
                        <View style={{ maxWidth: '80%', padding: 12, borderRadius: 16,
                            backgroundColor: msg.role === 'user' ? theme.primary : '#f1f5f9',
                            borderBottomRightRadius: msg.role === 'user' ? 4 : 16,
                            borderBottomLeftRadius: msg.role === 'user' ? 16 : 4 }}>
                            <Text style={{ color: msg.role === 'user' ? '#fff' : '#1e293b', fontSize: 14, lineHeight: 20 }}>
                                {msg.text}
                            </Text>
                        </View>
                    </View>
                )} />
            {loading && <View style={{ padding: 12, alignItems: 'center' }}>
                <ActivityIndicator size="small" color={theme.primary} />
            </View>}
            <View style={{ position: 'absolute', bottom: 0, left: 0, right: 0, backgroundColor: '#fff',
                borderTopWidth: 1, borderTopColor: '#f1f5f9', padding: 12, flexDirection: 'row', gap: 8 }}>
                <TextInput value={input} onChangeText={setInput} placeholder="Ask anything..."
                    returnKeyType="send" onSubmitEditing={handleSend} placeholderTextColor="#94a3b8"
                    style={{ flex: 1, borderWidth: 1, borderColor: '#e2e8f0', borderRadius: 14, paddingHorizontal: 14, paddingVertical: 12, fontSize: 14, color: '#1e293b' }} />
                <Pressable onPress={handleSend} disabled={loading || !input.trim()}
                    style={{ backgroundColor: loading ? '#e2e8f0' : theme.primary, borderRadius: 14,
                        width: 46, height: 46, alignItems: 'center', justifyContent: 'center' }}>
                    <Text style={{ color: '#fff', fontWeight: '700', fontSize: 16 }}>↑</Text>
                </Pressable>
            </View>
        </View>
    );
}

// ─────────────────────────────────────────────────────────
// SettingsScreen — themed
// ─────────────────────────────────────────────────────────

function SettingsScreen() {
    const { logout } = useAuth();
    const theme = useTheme();
    const handleLogout = () => {
        Alert.alert('Sign Out', 'Are you sure?', [
            { text: 'Cancel', style: 'cancel' },
            { text: 'Sign Out', style: 'destructive', onPress: logout },
        ]);
    };
    return (
        <ScrollView style={{ flex: 1, backgroundColor: '#f8fafc' }} contentContainerStyle={{ padding: 20 }}>
            <View style={{ backgroundColor: '#fff', borderRadius: 18, padding: 20, marginBottom: 16, borderWidth: 1, borderColor: '#f1f5f9' }}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
                    <View style={{ width: 52, height: 52, borderRadius: 26, backgroundColor: theme.palette[50], alignItems: 'center', justifyContent: 'center' }}>
                        <Text style={{ fontSize: 20, fontWeight: '700', color: theme.primary }}>
                            {(client.userInfo?.email || '?')[0].toUpperCase()}
                        </Text>
                    </View>
                    <View>
                        <Text style={{ fontWeight: '700', fontSize: 16, color: '#1e293b' }}>
                            {client.userInfo?.fullName || client.userInfo?.email || 'User'}
                        </Text>
                        <Text style={{ fontSize: 13, color: '#94a3b8', marginTop: 2 }}>{client.userInfo?.email}</Text>
                        <Text style={{ fontSize: 11, color: theme.primary, fontWeight: '600', marginTop: 2 }}>
                            {(client.userInfo?.role || '').replace(/_/g, ' ')}
                        </Text>
                    </View>
                </View>
            </View>
            <Pressable onPress={handleLogout}
                style={{ backgroundColor: '#fef2f2', borderRadius: 16, padding: 18, alignItems: 'center' }}>
                <Text style={{ color: '#991b1b', fontWeight: '700', fontSize: 14 }}>🚪 Sign Out</Text>
            </Pressable>
        </ScrollView>
    );
}

// ═══════════════════════════════════════════════════════════
// MobileShell — THE MAIN ENTRY POINT
// ═══════════════════════════════════════════════════════════

const MobileConfigContext = React.createContext({});
const useMobileConfig = () => React.useContext(MobileConfigContext);

function _AuthStack() {
    const cfg = useMobileConfig();
    return (
        <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="Login" component={LoginScreen}
                initialParams={{ appName: cfg.appName, domain: cfg.domain, project: cfg.project, signupMode: cfg.signupMode }} />
            {cfg.signupMode && cfg.signupMode !== 'none' &&
                <Stack.Screen name="Signup" component={SignupScreen}
                    initialParams={{ appName: cfg.appName, domain: cfg.domain, project: cfg.project, signupMode: cfg.signupMode }} />
            }
        </Stack.Navigator>
    );
}

function _SchemaStack({ route }) {
    const cfg = useMobileConfig();
    const theme = useTheme();
    const tab = route.params.tab;
    return (
        <Stack.Navigator screenOptions={{ headerBackTitleVisible: false,
            headerTintColor: theme.primary, headerTitleStyle: { fontWeight: '700' } }}>
            <Stack.Screen name={tab.id + '_List'} component={ListScreen}
                options={{ title: tab.label }}
                initialParams={{ tab, workflowMap: cfg.workflowMap || {} }} />
            <Stack.Screen name={tab.id + '_Detail'} component={DetailScreen}
                options={{ title: 'Details' }}
                initialParams={{ actionButtons: cfg.actionButtons }} />
            <Stack.Screen name={tab.id + '_Form'} component={FormScreen}
                options={({ route: r }) => ({ title: (r.params.mode === 'edit' ? 'Edit' : 'New') + ' ' + tab.label.replace(/s$/, '') })} />
        </Stack.Navigator>
    );
}

function _MainTabs() {
    const cfg = useMobileConfig();
    const theme = useTheme();
    const tabs = cfg.tabs || [];
    const readableTabs = tabs.filter(t => client.can('read', t.schema));
    return (
        <Tab.Navigator screenOptions={{ headerShown: false,
            tabBarActiveTintColor: theme.primary, tabBarInactiveTintColor: '#94a3b8',
            tabBarLabelStyle: { fontSize: 10, fontWeight: '600' },
            tabBarStyle: { borderTopColor: '#f1f5f9', paddingTop: 4 } }}>
            <Tab.Screen name="Home" component={DashboardScreen}
                options={{ tabBarIcon: () => <Text style={{ fontSize: 18 }}>🏠</Text>, tabBarLabel: 'Home' }}
                initialParams={{ tabs, dashboardWidgets: cfg.dashboardWidgets }} />
            {readableTabs.map(tab => (
                <Tab.Screen key={tab.id} name={tab.id + '_Tab'} component={_SchemaStack}
                    options={{ tabBarIcon: () => <Text style={{ fontSize: 16 }}>{tab.icon}</Text>, tabBarLabel: tab.label }}
                    initialParams={{ tab }} />
            ))}
            <Tab.Screen name="AI" component={AIChatScreen}
                options={{ tabBarIcon: () => <Text style={{ fontSize: 16 }}>🤖</Text>, tabBarLabel: 'AI',
                    headerShown: true, headerTitle: 'AI Assistant' }} />
            <Tab.Screen name="Settings" component={SettingsScreen}
                options={{ tabBarIcon: () => <Text style={{ fontSize: 16 }}>⚙️</Text>, tabBarLabel: 'Settings', headerShown: true }} />
        </Tab.Navigator>
    );
}

function _Root() {
    const { isReady, isAuthenticated } = useAuth();
    const theme = useTheme();
    if (!isReady) return (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#fff' }}>
            <ActivityIndicator size="large" color={theme.primary} />
            <Text style={{ marginTop: 12, color: '#94a3b8', fontSize: 13 }}>Loading...</Text>
        </View>
    );
    return (
        <NavigationContainer>
            {isAuthenticated ? <_MainTabs /> : <_AuthStack />}
        </NavigationContainer>
    );
}

export function MobileShell(config) {
    setConfig({
        serverUrl: config.serverUrl, domain: config.domain,
        project: config.project, appName: config.appName,
    });

    const primary = config.theme?.primary || '#6366f1';
    const palette = generatePalette(primary);
    const themeValue = { primary, palette };

    return (
        <ThemeContext.Provider value={themeValue}>
            <MobileConfigContext.Provider value={config}>
                <AuthProvider>
                    <StatusBar barStyle="dark-content" />
                    <_Root />
                </AuthProvider>
            </MobileConfigContext.Provider>
        </ThemeContext.Provider>
    );
}

// ─────────────────────────────────────────────────────────
// Version
// ─────────────────────────────────────────────────────────

export const SUPERO_MOBILE_VERSION = '3.0.1';
