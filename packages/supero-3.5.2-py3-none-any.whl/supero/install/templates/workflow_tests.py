# WORKFLOW_TESTS_VERSION: 1
"""
workflow_tests.py — Workflow health-check suite.

Tests every WORKFLOW_DEFINITION in setup.py:
  1. Service probe  — is each referenced service configured?
  2. Registration   — is wf:workflow_definition registered in the domain?
  3. Execute        — does the workflow run end-to-end with synthetic inputs?

Exit 0 = all pass (or skipped due to missing config).
Exit 1 = one or more hard failures.

Run directly:
    python workflow_tests.py
    python workflow_tests.py --json          # machine-readable output
    python workflow_tests.py --verbose       # extra detail

Called by the UI via the /api/workflow-tests endpoint in ui/server.py.
"""

import os
import sys
import json
import time
import argparse
import importlib.util
import warnings

import requests

warnings.filterwarnings("ignore", message="Unverified HTTPS request")
try:
    import urllib3
    urllib3.disable_warnings()
except ImportError:
    pass

# ── Colour helpers ────────────────────────────────────────────────────────────

_NO_COLOR = not sys.stdout.isatty() or os.getenv("NO_COLOR")

def _c(code, text):
    return text if _NO_COLOR else f"\033[{code}m{text}\033[0m"

def _green(t):  return _c("32", t)
def _red(t):    return _c("31", t)
def _yellow(t): return _c("33", t)
def _dim(t):    return _c("2",  t)
def _bold(t):   return _c("1",  t)


# ── Test result dataclass (plain dict for JSON compat) ────────────────────────

def _result(workflow_id, display_name, step_count, status, message, step_results=None):
    return {
        "workflow_id":   workflow_id,
        "display_name":  display_name,
        "step_count":    step_count,
        "status":        status,   # "pass" | "fail" | "skip"
        "message":       message,
        "step_results":  step_results or [],
    }


# ── Synthetic input builder ───────────────────────────────────────────────────

_TYPE_DEFAULTS = {
    "string":   "test_value",
    "text":     "test_value",
    "float":    1.0,
    "integer":  1,
    "number":   1,
    "bool":     True,
    "boolean":  True,
    "date":     "2024-01-01",
    "datetime": "2024-01-01T00:00:00Z",
}
_EMAIL_HINTS = ("email", "mail", "e_mail")
_PHONE_HINTS = ("phone", "mobile", "cell", "tel")
_UUID_HINTS  = ("uuid", "_id", "id")
_URL_HINTS   = ("url", "link", "href", "uri", "website")
_NAME_HINTS  = ("name", "title", "label", "subject", "heading")


def _synthetic_value(field_name: str, field_def: dict):
    fn = field_name.lower()
    if any(h in fn for h in _EMAIL_HINTS):
        return "test@example.com"
    if any(h in fn for h in _PHONE_HINTS):
        return "+15005550006"
    if any(h in fn for h in _UUID_HINTS):
        return "00000000-0000-0000-0000-000000000001"
    if any(h in fn for h in _URL_HINTS):
        return "https://example.com"
    if any(h in fn for h in _NAME_HINTS):
        return f"Test {field_name.replace('_', ' ').title()}"
    ftype = (field_def.get("type") or "string").lower()
    return _TYPE_DEFAULTS.get(ftype, f"test_{field_name}")


def _build_inputs(wf_def: dict) -> dict:
    return {
        k: _synthetic_value(k, v)
        for k, v in wf_def.get("input_schema", {}).items()
    }


# ── Core test runner ──────────────────────────────────────────────────────────

def run_tests(base_url: str, auth_header: str, domain: str,
              project_uuid: str, api_key: str = "") -> dict:
    """
    Run the full workflow test suite.

    Returns a dict:
      {
        "domain":    str,
        "services":  [{service_id, status, http_status?, message?}],
        "workflows": [{workflow_id, display_name, step_count, status, message, step_results}],
        "summary":   {passed, failed, skipped},
        "success":   bool,
        "elapsed_ms": float,
      }
    """
    t0 = time.time()

    # ── Load WORKFLOW_DEFINITIONS from setup.py ───────────────────────────────
    wf_defs = _load_workflow_defs()

    result = {
        "domain":    domain,
        "services":  [],
        "workflows": [],
        "summary":   {"passed": 0, "failed": 0, "skipped": 0},
        "success":   True,
        "elapsed_ms": 0,
    }

    if not wf_defs:
        result["summary"]["skipped"] = 0
        result["elapsed_ms"] = round((time.time() - t0) * 1000, 1)
        return result

    # ── Build authenticated session ───────────────────────────────────────────
    s = requests.Session()
    s.verify = False
    hdrs = {"X-Domain": domain}
    if api_key:
        hdrs["X-Api-Key"] = api_key
    elif auth_header.startswith("Bearer "):
        hdrs["Authorization"] = auth_header
    s.headers.update(hdrs)

    base = base_url.rstrip("/")

    # ── Step 1: Probe each service referenced by any workflow step ────────────
    services_seen: dict = {}   # service_id → result dict
    for wf in wf_defs:
        for step in wf.get("steps", []):
            svc = step.get("service", "")
            if svc and svc not in services_seen:
                services_seen[svc] = _probe_service(s, base, domain, project_uuid, svc)
    result["services"] = list(services_seen.values())

    # ── Step 2: Check workflow registration ───────────────────────────────────
    registered_ids = _fetch_registered_ids(s, base, domain)

    # ── Step 3: Test each workflow ────────────────────────────────────────────
    for wf_def in wf_defs:
        wid      = wf_def.get("workflow_id", "")
        display  = wf_def.get("display_name", wid)
        steps    = wf_def.get("steps", [])

        # Check registration
        if registered_ids is None:
            # Could not reach platform at all
            r = _result(wid, display, len(steps), "fail",
                        "Could not reach platform — check SUPERO_URL and API key")
            result["workflows"].append(r)
            result["summary"]["failed"] += 1
            continue

        if wid not in registered_ids:
            r = _result(wid, display, len(steps), "fail",
                        f"Not registered in domain '{domain}' — run setup.py to import workflow service")
            result["workflows"].append(r)
            result["summary"]["failed"] += 1
            continue

        # Check that required services are configured
        svc_blockers = [
            svc for step in steps
            if (svc := step.get("service", ""))
            and services_seen.get(svc, {}).get("status") == "not_configured"
        ]
        if svc_blockers:
            r = _result(wid, display, len(steps), "skip",
                        f"Service(s) not configured: {', '.join(svc_blockers)}")
            result["workflows"].append(r)
            result["summary"]["skipped"] += 1
            continue

        # Execute with synthetic inputs
        inputs  = _build_inputs(wf_def)
        wf_res  = _execute_workflow(s, base, domain, project_uuid, wid, inputs)
        wf_res["display_name"] = display
        wf_res["step_count"]   = len(steps)
        result["workflows"].append(wf_res)
        _STATUS_KEY = {"pass": "passed", "fail": "failed", "skip": "skipped"}
        counter = _STATUS_KEY.get(wf_res["status"], "failed")
        result["summary"][counter] += 1

    result["success"]    = result["summary"]["failed"] == 0
    result["elapsed_ms"] = round((time.time() - t0) * 1000, 1)
    return result


# ── Helpers ───────────────────────────────────────────────────────────────────

def _load_workflow_defs() -> list:
    """Load WORKFLOW_DEFINITIONS from setup.py in the app root."""
    # Search: same dir, parent dir
    for candidate in [
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "setup.py"),
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "setup.py"),
    ]:
        if os.path.exists(candidate):
            try:
                spec = importlib.util.spec_from_file_location("_wt_setup", candidate)
                mod  = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mod)
                return getattr(mod, "WORKFLOW_DEFINITIONS", []) or []
            except Exception:
                return []
    return []


def _probe_service(s, base, domain, project_uuid, service_id) -> dict:
    """Return {service_id, status, http_status, message}."""
    try:
        r = s.post(
            f"{base}/api/v1/services/execute",
            json={
                "service_id":   service_id,
                "operation":    "probe",
                "input":        {},
                "domain":       domain,
                "project_uuid": project_uuid,
            },
            timeout=10,
        )
        body = r.text.lower()
        not_cfg = (
            r.status_code == 503
            or "not configured" in body
            or "no credentials" in body
            or "no api key"      in body
            or "missing credentials" in body
        )
        if not_cfg:
            return {"service_id": service_id, "status": "not_configured",
                    "http_status": r.status_code, "message": "Service not configured"}
        if r.status_code in (200, 400, 404, 422):
            return {"service_id": service_id, "status": "ok",
                    "http_status": r.status_code, "message": "Configured"}
        return {"service_id": service_id, "status": "error",
                "http_status": r.status_code, "message": r.text[:200]}
    except Exception as e:
        return {"service_id": service_id, "status": "error",
                "http_status": None, "message": str(e)}


def _fetch_registered_ids(s, base, domain) -> "set | None":
    """Return set of registered workflow_ids, or None if platform unreachable."""
    for schema in ("wf:workflow_definition", "workflow_definition"):
        try:
            r = s.get(f"{base}/api/v1/crud/{domain}/{schema}", timeout=10)
            if r.status_code == 200:
                return {w.get("workflow_id") for w in r.json().get("results", [])}
            if r.status_code == 409:
                continue  # try next schema name
            if r.status_code in (401, 403):
                return set()  # auth issue — treat as empty
        except Exception:
            return None
    return set()


def _execute_workflow(s, base, domain, project_uuid, workflow_id, inputs) -> dict:
    """Run the workflow; return a result dict with status/message."""
    try:
        payload = {
            "service_id":   "workflows",
            "operation":    "run_workflow",
            "domain":       domain,
            "project_uuid": project_uuid,
            "input": {"workflow_id": workflow_id, **inputs},
        }
        r = s.post(f"{base}/api/v1/services/execute", json=payload, timeout=20)
        body = r.text.lower()

        if r.status_code in (200, 201):
            return _result(workflow_id, "", 0, "pass", "Executed successfully")

        not_cfg = (
            r.status_code == 503
            or "not configured" in body
            or "no credentials" in body
        )
        if not_cfg:
            return _result(workflow_id, "", 0, "skip", "Workflow service not configured")

        if r.status_code in (401, 403):
            return _result(workflow_id, "", 0, "fail",
                           "Permission denied — check API key has workflow execute rights")

        # Parse error detail
        try:
            jb = r.json()
            msg = jb.get("detail") or jb.get("message") or jb.get("error") or r.text[:300]
        except Exception:
            msg = r.text[:300]

        return _result(workflow_id, "", 0, "fail", f"HTTP {r.status_code}: {msg}")

    except requests.Timeout:
        return _result(workflow_id, "", 0, "fail", "Timed out after 20 s")
    except Exception as e:
        return _result(workflow_id, "", 0, "fail", str(e))


# ── CLI entry-point ───────────────────────────────────────────────────────────

def _print_human(result: dict):
    """Pretty-print test results to stdout."""
    domain = result.get("domain", "")
    print()
    print(_bold(f"  Workflow Test Suite — domain: {domain}"))
    print()

    # Services
    services = result.get("services", [])
    if services:
        print(_bold("  Services"))
        for svc in services:
            sid  = svc["service_id"]
            st   = svc["status"]
            icon = _green("  ✓") if st == "ok" else (_yellow("  ⚠") if st == "not_configured" else _red("  ✗"))
            label = {"ok": "configured", "not_configured": "not configured", "error": "error"}.get(st, st)
            print(f"{icon}  {sid:<20} {_dim(label)}")
        print()

    # Workflows
    workflows = result.get("workflows", [])
    if not workflows:
        print(_dim("  No workflows defined in setup.py"))
    else:
        print(_bold("  Workflows"))
        for wf in workflows:
            wid     = wf["workflow_id"]
            display = wf.get("display_name") or wid
            st      = wf["status"]
            msg     = wf.get("message", "")
            steps   = wf.get("step_count", 0)
            if st == "pass":
                icon = _green("  ✓")
                label = _green("PASS")
            elif st == "skip":
                icon = _yellow("  ⚠")
                label = _yellow("SKIP")
            else:
                icon = _red("  ✗")
                label = _red("FAIL")
            step_info = _dim(f"  ({steps} steps)") if steps else ""
            print(f"{icon}  [{label}]  {display}{step_info}")
            if msg and st != "pass":
                print(f"       {_dim(msg)}")

    # Summary
    s = result.get("summary", {})
    passed  = s.get("passed",  0)
    failed  = s.get("failed",  0)
    skipped = s.get("skipped", 0)
    elapsed = result.get("elapsed_ms", 0)
    print()
    print(f"  {_bold('Summary')}: "
          f"{_green(str(passed))} passed, "
          f"{_red(str(failed))} failed, "
          f"{_yellow(str(skipped))} skipped  "
          f"{_dim(f'({elapsed:.0f} ms)')}")
    print()


def main():
    parser = argparse.ArgumentParser(description="Workflow health-check suite")
    parser.add_argument("--json",    action="store_true", help="JSON output")
    parser.add_argument("--verbose", action="store_true", help="Verbose HTTP detail")
    args = parser.parse_args()

    # Read env
    base_url     = os.getenv("SUPERO_URL",      "https://api.supero.dev")
    domain       = os.getenv("SUPERO_DOMAIN",   "")
    project_uuid = os.getenv("SUPERO_PROJECT_UUID", os.getenv("SUPERO_PROJECT", ""))
    api_key      = os.getenv("SUPERO_API_KEY",  "")

    if not domain:
        print("  ✗  SUPERO_DOMAIN not set — source .env or run ./run.sh first", file=sys.stderr)
        sys.exit(1)

    result = run_tests(
        base_url=base_url,
        auth_header="",
        domain=domain,
        project_uuid=project_uuid,
        api_key=api_key,
    )

    if args.json:
        print(json.dumps(result, indent=2))
    else:
        _print_human(result)

    sys.exit(0 if result["success"] else 1)


if __name__ == "__main__":
    main()
