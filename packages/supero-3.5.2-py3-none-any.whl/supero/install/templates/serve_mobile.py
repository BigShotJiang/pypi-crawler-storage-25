#!/usr/bin/env python3
import json
import mimetypes
import os
import sys
import uuid
from datetime import datetime, timezone


# ── Constants ────────────────────────────────────────────────────────────
# These are bound at module load time. In production, MOBILE_DIST is
# always /app/mobile-dist (set by Cloud Build stage 2 via COPY --from).
# If you need to override for testing, monkey-patch all three together
# (MOBILE_DIST, UNAVAILABLE_MARKER, METADATA_PATH) — the latter two are
# computed FROM MOBILE_DIST and won't auto-update if only MOBILE_DIST is
# patched.

MOBILE_DIST = "/app/mobile-dist"
UNAVAILABLE_MARKER = os.path.join(MOBILE_DIST, "UNAVAILABLE")
METADATA_PATH = os.path.join(MOBILE_DIST, "metadata.json")

# Runtime version is currently a constant; bump if/when the manifest format
# changes incompatibly. Expo Go uses this for cache invalidation.
_RUNTIME_VERSION = "1.0.0"


# ── Marker / state helpers ───────────────────────────────────────────────

def is_unavailable() -> bool:
    """True when Cloud Build stage 1 wrote the UNAVAILABLE marker."""
    return os.path.exists(UNAVAILABLE_MARKER)


def _read_unavailable_reason() -> str:
    """Read the failure reason JSON written by stage 1, or fallback string."""
    try:
        with open(UNAVAILABLE_MARKER, encoding="utf-8") as f:
            return json.load(f).get("reason", "unknown")
    except Exception:
        return "marker present but unreadable"


def _read_metadata() -> dict:
    """Read mobile-dist/metadata.json (input to manifest synthesis).

    NOTE: this is `expo export`'s output metadata, NOT the Expo Updates
    manifest we synthesize and return. The shape of THIS file may vary
    slightly across Expo SDK versions; manifest synthesis below adapts.
    """
    if not os.path.exists(METADATA_PATH):
        raise FileNotFoundError(f"metadata.json missing at {METADATA_PATH}")
    with open(METADATA_PATH, encoding="utf-8") as f:
        return json.load(f)


# ── Manifest synthesis (Expo Updates v1) ─────────────────────────────────

def _synthesize_manifest(host: str, scheme: str, platform: str) -> dict:
    """Build Expo Updates v1 manifest from expo export's metadata.json.

    Spec: https://docs.expo.dev/technical-specs/expo-updates-1/#manifest-body

    Required fields per spec:
      id (UUID), createdAt (ISO8601), runtimeVersion (string),
      launchAsset (Asset), assets (Asset[]),
      metadata ({[key]: string}), extra ({[key]: any})

    Asset required fields: key (string), contentType (string), url (string)
    Asset optional: hash (base64url SHA-256), fileExtension (must start with ".")
    """
    meta = _read_metadata()
    base = f"{scheme}://{host}/mobile"

    # Pick the platform's bundle/assets section. expo export's metadata.json
    # uses `fileMetadata.<platform>` per spec.
    fm = meta.get("fileMetadata", {})
    if platform not in fm:
        raise ValueError(
            f"No bundle for platform {platform!r} "
            f"(available: {sorted(fm.keys())})"
        )
    pdata = fm[platform]

    # launchAsset: per spec, fileExtension is OPTIONAL on launchAsset and
    # generally omitted (it's a JS bundle, contentType conveys the type).
    launch_bundle_path = pdata.get("bundle", "")
    if not launch_bundle_path:
        raise ValueError(
            f"metadata.json fileMetadata.{platform} has no 'bundle' field — "
            f"cannot synthesize manifest"
        )
    launch_asset = {
        "key": "main-bundle",
        "contentType": "application/javascript",
        "url": f"{base}/{launch_bundle_path}",
    }

    # assets: each must have key, contentType, url; fileExtension MUST start
    # with "." if present.
    assets = []
    for a in pdata.get("assets", []):
        # Skip malformed asset entries (missing path) — better than crashing
        # the whole manifest synthesis.
        path = a.get("path", "")
        if not path:
            continue
        # Defensive: lowercase ext for case-insensitive matching against
        # known image/font extensions.
        ext = (a.get("ext", "") or "").lower()
        ext_with_dot = f".{ext}" if ext and not ext.startswith(".") else ext

        if ext in ("png", "jpg", "jpeg", "gif", "webp"):
            content_type = f"image/{'jpeg' if ext == 'jpg' else ext}"
        elif ext in ("ttf", "otf"):
            content_type = f"font/{ext}"
        else:
            content_type = "application/octet-stream"

        asset_obj = {
            "key": path,
            "contentType": content_type,
            "url": f"{base}/{path}",
        }
        if ext_with_dot:
            asset_obj["fileExtension"] = ext_with_dot
        assets.append(asset_obj)

    return {
        "id": str(uuid.uuid4()),
        "createdAt": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
        "runtimeVersion": _RUNTIME_VERSION,
        "launchAsset": launch_asset,
        "assets": assets,
        # Per spec, both required (can be empty dicts).
        "metadata": {},
        "extra": {},
    }


# ── Handler functions (called from _Handler.do_GET) ──────────────────────

def _set_expo_response_headers(handler):
    """Set required Expo Updates v1 protocol response headers.

    Per spec section "Common response headers":
      expo-protocol-version: 1
      expo-sfv-version: 0
    """
    handler.send_header("expo-protocol-version", "1")
    handler.send_header("expo-sfv-version", "0")
    handler.send_header("Cache-Control", "private, max-age=0")
    handler.send_header("Access-Control-Allow-Origin", "*")


def _send_json(handler, status: int, body: dict, expo_headers: bool = False):
    """Send a JSON response. If expo_headers=True, add Expo protocol headers."""
    payload = json.dumps(body).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(payload)))
    if expo_headers:
        _set_expo_response_headers(handler)
    handler.end_headers()
    handler.wfile.write(payload)


def serve_health(handler):
    """GET /mobile/health → { ok, available, reason?, platforms?, dist? }."""
    if is_unavailable():
        _send_json(handler, 200, {
            "ok": True,
            "available": False,
            "reason": _read_unavailable_reason(),
        })
        return

    try:
        meta = _read_metadata()
    except FileNotFoundError as e:
        # Mobile claims to be available (no UNAVAILABLE marker) but
        # metadata.json is missing — surface clearly so ops can debug.
        print(f"[mobile] serve_health: {e}", file=sys.stderr)
        _send_json(handler, 200, {
            "ok": False,
            "available": False,
            "error": str(e),
        })
        return
    except Exception as e:
        print(f"[mobile] serve_health metadata.json error: {e}", file=sys.stderr)
        _send_json(handler, 500, {
            "ok": False,
            "available": False,
            "error": f"metadata.json read error: {e}",
        })
        return

    _send_json(handler, 200, {
        "ok": True,
        "available": True,
        "platforms": sorted(meta.get("fileMetadata", {}).keys()),
        "dist": MOBILE_DIST,
    })


def serve_manifest(handler):
    """GET /mobile/manifest.json → Expo Updates v1 manifest.

    Platform comes from `expo-platform` header (per spec). Falls back
    to ?platform= query param so curl/diagnostics still work.
    """
    if is_unavailable():
        _send_json(handler, 503, {
            "unavailable": True,
            "reason": _read_unavailable_reason(),
        }, expo_headers=True)
        return

    # Per Expo Updates v1 spec: platform is an HTTP header.
    # Headers are case-insensitive; BaseHTTPRequestHandler.headers handles that.
    platform_header = handler.headers.get("expo-platform") or ""
    platform_query = ""
    if "?" in handler.path:
        # Cheap query parse — we only need ?platform=...
        from urllib.parse import urlparse, parse_qs
        qs = parse_qs(urlparse(handler.path).query)
        platform_query = (qs.get("platform") or [""])[0]

    platform = (platform_header or platform_query or "ios").lower()
    if platform not in ("ios", "android"):
        _send_json(handler, 400, {
            "error": f"unsupported platform: {platform!r}",
        }, expo_headers=True)
        return

    host = handler.headers.get("Host", "localhost")
    # Cloud Run terminates TLS at the load balancer and forwards
    # X-Forwarded-Proto. Default to https since Expo Go requires it
    # for non-localhost URLs. Validate to prevent attacker-controlled
    # weird schemes from polluting our manifest URLs.
    scheme = handler.headers.get("X-Forwarded-Proto", "https").lower().strip()
    if scheme not in ("http", "https"):
        scheme = "https"

    try:
        manifest = _synthesize_manifest(host, scheme, platform)
    except FileNotFoundError as e:
        _send_json(handler, 503, {"error": str(e)}, expo_headers=True)
        return
    except ValueError as e:
        _send_json(handler, 404, {"error": str(e)}, expo_headers=True)
        return
    except Exception as e:
        print(f"[mobile] manifest synthesis failed: {e}", file=sys.stderr)
        _send_json(handler, 500, {
            "error": f"Manifest synthesis failed: {e}",
        }, expo_headers=True)
        return

    payload = json.dumps(manifest).encode("utf-8")
    handler.send_response(200)
    # Per spec: content-type MUST be application/json or application/expo+json
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(payload)))
    _set_expo_response_headers(handler)
    handler.end_headers()
    handler.wfile.write(payload)


def serve_static(handler, rel_path: str):
    """GET /mobile/<rel_path> → file from MOBILE_DIST.

    Covers _expo/<...> bundle paths and assets/<...> asset paths both.
    """
    if is_unavailable():
        _send_json(handler, 503, {"error": "Mobile bundle unavailable"})
        return

    # Strip query string if present
    if "?" in rel_path:
        rel_path = rel_path.split("?", 1)[0]

    # Path safety — disallow traversal
    if (
        not rel_path
        or rel_path.startswith("/")
        or ".." in rel_path.split("/")
        or "\x00" in rel_path
    ):
        _send_json(handler, 400, {"error": "Invalid path"})
        return

    full_path = os.path.join(MOBILE_DIST, rel_path)
    # Defense-in-depth: resolve and confirm we didn't escape MOBILE_DIST.
    real_full = os.path.realpath(full_path)
    real_root = os.path.realpath(MOBILE_DIST)
    if not real_full.startswith(real_root + os.sep) and real_full != real_root:
        _send_json(handler, 400, {"error": "Path escapes mobile-dist"})
        return

    if not os.path.isfile(real_full):
        _send_json(handler, 404, {"error": f"Not found: {rel_path}"})
        return

    # Content-Type from extension
    content_type, _ = mimetypes.guess_type(real_full)
    if not content_type:
        # Common Expo asset case: .hbc bundle (Hermes bytecode) returns
        # application/octet-stream by default — that's fine.
        content_type = "application/octet-stream"

    try:
        with open(real_full, "rb") as f:
            body = f.read()
    except OSError as e:
        # Log to stderr so Cloud Run captures it. Without this, ops sees
        # 500s with no explanation when serve_static fails.
        print(
            f"[mobile] serve_static read error for {rel_path!r}: {e}",
            file=sys.stderr,
        )
        _send_json(handler, 500, {"error": f"Read error: {e}"})
        return

    handler.send_response(200)
    handler.send_header("Content-Type", content_type)
    handler.send_header("Content-Length", str(len(body)))
    # Per spec: assets SHOULD have long cache-control with `immutable`
    handler.send_header("Cache-Control", "public, max-age=31536000, immutable")
    handler.send_header("Access-Control-Allow-Origin", "*")
    handler.end_headers()
    handler.wfile.write(body)

# MOBILE_DIAG_BC_HELPER_V1
# Diagnostics: shared summary helper, one-shot startup dump, /mobile/__diagnose.
# Imports are local to keep top-of-module clean and avoid touching existing imports.
def _build_diagnostics_summary():
    """Filesystem-only snapshot of mobile preview state. Cheap; no I/O outside /app."""
    import os as _os, json as _json, re as _re
    summary = {
        "MOBILE_DIST": MOBILE_DIST,
        "exists": _os.path.isdir(MOBILE_DIST),
        "unavailable_marker": is_unavailable(),
        "metadata_json": _os.path.isfile(METADATA_PATH),
        "expo_dir_exists": _os.path.isdir(_os.path.join(MOBILE_DIST, "_expo")),
        "runtime_version": _RUNTIME_VERSION,
    }
    for plat in ("ios", "android"):
        d = _os.path.join(MOBILE_DIST, "_expo", "static", "js", plat)
        if _os.path.isdir(d):
            try:
                files = sorted(f for f in _os.listdir(d) if f.endswith(".hbc"))
            except OSError:
                files = []
            summary[f"{plat}_bundles"] = files
            for f in files:
                try:
                    summary[f"{plat}_size_{f}"] = _os.path.getsize(_os.path.join(d, f))
                except OSError:
                    pass
    appconfig = "/app/mobile/src/appConfig.ts"
    if _os.path.isfile(appconfig):
        try:
            with open(appconfig, encoding="utf-8") as f:
                content = f.read()
            for field in ("domain", "project", "serverUrl", "appName"):
                m = _re.search(rf"{field}:\s*[\'\"]([^\'\"]+)", content)
                if m:
                    summary[f"appConfig.{field}"] = m.group(1)
        except OSError as e:
            summary["appConfig.error"] = str(e)
    else:
        summary["appConfig.present"] = False
    return summary


def log_startup_diagnostics():
    """One-shot dump at server startup. Read by ops via gcloud logs."""
    import sys as _sys, json as _json
    try:
        s = _build_diagnostics_summary()
        print(f"[mobile][startup] {_json.dumps(s, sort_keys=True)}",
              file=_sys.stderr, flush=True)
    except Exception as e:
        print(f"[mobile][startup] diagnostics failed: {e}",
              file=_sys.stderr, flush=True)


def serve_diagnose(handler):
    """GET /mobile/__diagnose -> same payload as startup dump, on demand."""
    try:
        s = _build_diagnostics_summary()
    except Exception as e:
        _send_json(handler, 500, {"error": f"diagnose failed: {e}"})
        return
    _send_json(handler, 200, s)
# /MOBILE_DIAG_BC_HELPER_V1
