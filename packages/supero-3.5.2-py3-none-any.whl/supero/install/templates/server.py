#!/usr/bin/env python3
import os
import ssl
import threading
import urllib.request

os.chdir(os.path.dirname(os.path.abspath(__file__)))

from supero.server import SuperoRequestHandler, SuperoServer

# ── Config ────────────────────────────────────────────────────────────────────

_LIB_VER = os.getenv("SUPERO_LIB_VERSION", "1.0.4")
_CDN_URL  = f"https://cdn.supero.dev/web-ui/supero-ui-{_LIB_VER}.js"
_UI_JS    = os.path.join(os.path.dirname(os.path.abspath(__file__)), "supero-ui.js")
_LOCK     = threading.Lock()

# Appended to supero-ui.js content at serve time (Fix B).
# Compact single-line to minimise served bytes.
_READY_SUFFIX = (
    b"\n;(function(){"
    b'if(typeof window!=="undefined"){'
    b"window.__superoUILoaded=true;"
    b'window.dispatchEvent(new CustomEvent("supero:ready"));'
    b"}})();\n"
)

# Disable SSL verification (matches supero.server default for dev environments)
ssl._create_default_https_context = ssl._create_unverified_context


# ── Auto-fetch helper (Fix A) ─────────────────────────────────────────────────

def _fetch_ui_js() -> bool:
    """
    Download supero-ui.js from CDN into the ui/ directory.
    Thread-safe — only one download runs at a time.
    Returns True on success, False on failure.
    """
    with _LOCK:
        # Re-check inside lock — another thread may have just finished
        if os.path.exists(_UI_JS) and os.path.getsize(_UI_JS) > 10_000:
            return True

        print(f"  ⬇  supero-ui.js missing — fetching from CDN: {_CDN_URL}")
        try:
            req = urllib.request.Request(
                _CDN_URL,
                headers={"User-Agent": "Mozilla/5.0 supero-server/auto-fetch"},
            )
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = resp.read()

            with open(_UI_JS, "wb") as f:
                f.write(data)

            size_kb = len(data) // 1024
            print(f"  ✓  supero-ui.js ready ({size_kb} KB)")
            return True

        except Exception as exc:
            print(f"  ✗  CDN fetch failed: {exc}")
            # Remove partial file so next request retries cleanly
            if os.path.exists(_UI_JS):
                try:
                    os.remove(_UI_JS)
                except OSError:
                    pass
            return False


# ── Request handler ───────────────────────────────────────────────────────────


# MOBILE_DIAG_BC_STARTUP_V1
# One-shot startup diagnostics: import the hydrated mobile module if present
# and dump filesystem state to stderr so Cloud Run logs capture it.
# Failure here MUST NOT break server startup; web preview must keep working
# even if the mobile module isn't there or raises.
try:
    import _serve_mobile as _sm_diag  # noqa: F401
    try:
        _sm_diag.log_startup_diagnostics()
    except AttributeError:
        # Older SDK without diag helpers — skip silently.
        pass
    except Exception as _diag_err:
        import sys as _diag_sys
        print(f"[mobile][startup] diagnostics failed: {_diag_err}",
              file=_diag_sys.stderr, flush=True)
except ImportError:
    # Web-only artifact or local ./run.sh — _serve_mobile.py absent.
    pass
# /MOBILE_DIAG_BC_STARTUP_V1

class _Handler(SuperoRequestHandler):
    """
    Extends SuperoRequestHandler with auto-fetch (Fix A) and
    supero:ready event injection (Fix B) for /supero-ui.js requests.
    All other requests are handled by the base class unchanged.
    """

    def do_GET(self):
        # ── MOBILE_PATCH_V1 ── do not remove (used by fix_server_template_mobile.sh idempotency)
        # Mobile preview: lazy-import _serve_mobile (hydrated into artifact root
        # by preview_service when app_type='all'). Web-only artifacts and local
        # `./run.sh` runs don't have this file — ImportError is the silent path.
        #
        # Match exactly /mobile, /mobile?..., or /mobile/... — NOT /mobilexyz.
        # The strict boundary check prevents path-prefix confusion attacks.
        _mobile_match = (
            self.path == "/mobile"
            or self.path.startswith("/mobile/")
            or self.path.startswith("/mobile?")
        )
        if _mobile_match:
# MOBILE_DIAG_A_REQ_LOG_V1
            try:
                import sys as _diag_sys
                _diag_ua = self.headers.get("User-Agent", "?")[:120]
                _diag_xff = self.headers.get("X-Forwarded-For", "?")[:80]
                _diag_xfp = self.headers.get("X-Forwarded-Proto", "?")
                _diag_ep = self.headers.get("expo-platform", "")
                print(
                    "[mobile][req] {} {} ua={!r} xff={} xfp={} expo-platform={!r}".format(
                        self.command, self.path, _diag_ua, _diag_xff, _diag_xfp, _diag_ep
                    ),
                    file=_diag_sys.stderr, flush=True,
                )
            except Exception as _diag_err:
                pass
            # /MOBILE_DIAG_A_REQ_LOG_V1
            try:
                import _serve_mobile as _sm
            except ImportError:
                self.send_error(404, "Mobile preview not available in this build")
                return
            try:
                # Order matters: most-specific paths first.
                # MOBILE_DIAG_BC_ROUTE_V1
                if self.path == "/mobile/__diagnose":
                    _sm.serve_diagnose(self)
                    return
                # /MOBILE_DIAG_BC_ROUTE_V1
                if self.path == "/mobile/health":
                    _sm.serve_health(self)
                    return
                # /mobile/manifest.json or /mobile/manifest.json?platform=ios
                if self.path == "/mobile/manifest.json" or self.path.startswith("/mobile/manifest.json?"):
                    _sm.serve_manifest(self)
                    return
                # /mobile or /mobile/ or /mobile?... → no static path → 404
                if self.path in ("/mobile", "/mobile/") or self.path.startswith("/mobile?"):
                    self.send_error(404, "Not found")
                    return
                # /mobile/<anything-else> → static file from mobile-dist/
                rel = self.path[len("/mobile/"):]
                _sm.serve_static(self, rel)
                return
            except Exception as _err:
                # Don't crash the web server. Log and 500.
                import sys as _sys, traceback as _tb
                print(f"[server] /mobile error: {_err}", file=_sys.stderr)
                _tb.print_exc()
                self.send_error(500, "Mobile route handler error")
                return

        if self.path.startswith("/supero-ui.js"):
            # Fix A: ensure file exists
            if not (os.path.exists(_UI_JS) and os.path.getsize(_UI_JS) > 10_000):
                if not _fetch_ui_js():
                    self._serve_error_shim()
                    return
            # Fix B: serve with ready-event suffix
            self._serve_ui_js()
            return

        # All other requests handled normally (API proxy, static files, etc.)
        super().do_GET()

    def do_POST(self):
        if self.path.rstrip("/") == "/api/workflow-tests":
            self._run_workflow_tests()
            return
        super().do_POST()

    # ── /api/workflow-tests ───────────────────────────────────────────────────
    #
    # Admin-only endpoint: runs the workflow_tests.py suite against the live
    # platform and returns structured JSON. Called by the "Test Workflows"
    # button rendered in the app sidebar for admin users.
    #
    def _run_workflow_tests(self):
        import json as _json
        import sys as _sys
        import importlib.util as _ilu

        auth_header = self.headers.get("Authorization", "")
        if not auth_header:
            self._send_json(401, {"error": "Unauthorized — Authorization header required"})
            return

        # Locate workflow_tests.py at app root (one level above ui/)
        _app_root = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
        _wt_path  = os.path.join(_app_root, "workflow_tests.py")

        if not os.path.exists(_wt_path):
            self._send_json(404, {
                "error": "workflow_tests.py not found — run ./run.sh once to generate it",
            })
            return

        try:
            _spec = _ilu.spec_from_file_location("_workflow_tests_mod", _wt_path)
            _mod  = _ilu.module_from_spec(_spec)
            _spec.loader.exec_module(_mod)
        except Exception as exc:
            self._send_json(500, {"error": f"Failed to load workflow_tests.py: {exc}"})
            return

        try:
            result = _mod.run_tests(
                base_url     = os.getenv("SUPERO_URL", "https://api.supero.dev"),
                auth_header  = auth_header,
                domain       = os.getenv("SUPERO_DOMAIN", ""),
                project_uuid = os.getenv("SUPERO_PROJECT_UUID",
                                         os.getenv("SUPERO_PROJECT", "")),
                api_key      = os.getenv("SUPERO_API_KEY", ""),
            )
        except Exception as exc:
            self._send_json(500, {"error": f"Test runner error: {exc}"})
            return

        self._send_json(200, result)

    def _serve_ui_js(self):
        """Serve supero-ui.js with supero:ready event appended."""
        try:
            with open(_UI_JS, "rb") as f:
                content = f.read()
        except OSError as exc:
            self._send_json(500, {"error": f"Could not read supero-ui.js: {exc}"})
            return

        body = content + _READY_SUFFIX

        self.send_response(200)
        self.send_header("Content-Type", "application/javascript; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "public, max-age=3600")
        self.end_headers()
        self.wfile.write(body)

    def _serve_error_shim(self):
        """
        Serve a JS console.error when CDN is completely unreachable.
        Visible in devtools — far better than a silent white screen.
        """
        msg = (
            f'console.error("[Supero] supero-ui.js could not be loaded. '
            f'CDN: {_CDN_URL}. '
            f'If this server has no CDN access, download it manually and '
            f'place it in the ui/ directory.");\n'
        ).encode()

        self.send_response(200)
        self.send_header("Content-Type", "application/javascript")
        self.send_header("Content-Length", str(len(msg)))
        self.end_headers()
        self.wfile.write(msg)


# ── Entry point ───────────────────────────────────────────────────────────────

port = int(os.getenv("PORT", os.getenv("UI_PORT", "5648")))
# PUBLIC_SCHEMAS — schemas.py is authoritative.
# An empty list there is a deliberate "no public schemas" signal and MUST
# be passed through as-is. Only fall back to the env var if the schemas.py
# import actually fails.
_pub = None
try:
    import sys as _sys
    _sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
    from schemas import PUBLIC_SCHEMAS
    _pub = list(PUBLIC_SCHEMAS)
except Exception:
    _env_pub = [s.strip() for s in os.getenv("PUBLIC_SCHEMAS", "").split(",") if s.strip()]
    _pub = _env_pub if _env_pub else None
SuperoServer(port=port, handler_class=_Handler, public_schemas=_pub).serve()
