#!/bin/bash
set -e
# ── Supero Mobile v2.1.1 — Expo Dev Setup ──
#
# v2.1.1 changes (2026-04-30):
#   - SUPERO_LIB_VERSION default bumped 2.1.0 -> 2.1.1
#   - Local-dev block (ENV reading + Cloudflare tunnel + full appConfig
#     rewrite) wrapped in CI=1 guard so Cloud Build skips it. In Cloud
#     Build, preview_service._patch_appconfig_server_url has already
#     written the correct Cloud Run URL into appConfig.ts before this
#     script runs; re-patching here would replace it with a dead tunnel.
#   - When NOT in Cloud Build, this script:
#       * reads SUPERO_DOMAIN / SUPERO_PROJECT from ../.env
#       * starts a Cloudflare tunnel for global HTTPS access (no LAN required)
#       * patches serverUrl / domain / project in src/appConfig.ts
#     Falls back to LAN-IP detection if cloudflared is unavailable.
#
# v2.1.0 changes:
#   - cwd-robust: cd to script's own directory first
#   - Generates App.tsx (was previously LLM-required boilerplate)
#   - Node version check with clear error
#   - LLM now generates ONLY: src/appConfig.ts (~50 lines)
#   - unset EXPO_TOKEN before start to avoid invalid-bearer-token error
#
# Usage: ./expo.sh [start|setup|android|ios|install|clean]

# ── cwd robustness ─────────────────────────────────────────────────
# Always operate relative to this script's location, regardless of
# where it was invoked from.
cd "$(dirname "$(readlink -f "$0")")"

# ── Node version check ─────────────────────────────────────────────
# Expo SDK 54 requires Node 18+. Fail early with a clear message
# rather than a confusing JavaScript stack trace later.
if ! command -v node >/dev/null 2>&1; then
    echo "  ❌ node not found in PATH"
    echo "     Install Node 20 via nvm:"
    echo "       curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash"
    echo "       source ~/.bashrc && nvm install 20 && nvm use 20"
    exit 1
fi

NODE_MAJOR=$(node --version 2>/dev/null | sed 's/^v//' | cut -d. -f1)
if [ -z "$NODE_MAJOR" ] || [ "$NODE_MAJOR" -lt 18 ]; then
    echo "  ❌ Node $(node --version) found; Expo SDK 54 requires Node 18+"
    echo "     Install Node 20 via nvm:"
    echo "       curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash"
    echo "       source ~/.bashrc && nvm install 20 && nvm use 20"
    exit 1
fi

ACTION="${1:-start}"
SUPERO_LIB_VERSION="${SUPERO_LIB_VERSION:-2.1.1}"
SUPERO_LIB_URL="https://cdn.supero.dev/mobile/${SUPERO_LIB_VERSION}/supero-mobile.jsx"

# ── Read PORT from parent project's .env ──
SERVER_PORT="${PORT:-5648}"
if [ -f "../.env" ]; then
    _env_port=$(grep -E '^PORT=' ../.env 2>/dev/null | head -1 | sed 's/PORT="\?\([0-9]*\)"\?/\1/')
    [ -n "$_env_port" ] && SERVER_PORT="$_env_port"
fi

# ── Extract app info from src/appConfig.ts ──
APP_NAME=$(grep -o "appName:.*'[^']*'" src/appConfig.ts 2>/dev/null | head -1 | sed "s/.*'\\([^']*\\)'.*/\\1/" || echo "Supero App")
APP_DOMAIN=$(grep -o "domain:.*'[^']*'" src/appConfig.ts 2>/dev/null | head -1 | sed "s/.*'\\([^']*\\)'.*/\\1/" || echo "supero-app")
APP_COLOR=$(grep -o "primary:.*'[^']*'" src/appConfig.ts 2>/dev/null | head -1 | sed "s/.*'\\([^']*\\)'.*/\\1/" || echo "#6366f1")
APP_SLUG=$(echo "${APP_DOMAIN}" | tr '[:upper:]' '[:lower:]' | sed 's/[^a-z0-9-]/-/g')

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║       ${APP_NAME} — Expo Mobile 📱"
echo "╚══════════════════════════════════════════════╝"
echo ""

# ── Generate App.tsx (fixed boilerplate, identical for every app) ──
# v2.1.0: previously required LLM; now generated automatically.
if [ ! -f "App.tsx" ]; then
    cat > App.tsx << 'TSXEOF'
import { MobileShell } from './src/lib/supero';
import { APP_CONFIG, TABS, WORKFLOW_MAP } from './src/appConfig';
export default () => MobileShell({ ...APP_CONFIG, tabs: TABS, workflowMap: WORKFLOW_MAP });
TSXEOF
    echo "  ✅ Generated App.tsx"
else
    echo "  ✅ App.tsx already present"
fi

# ── Verify LLM-generated file exists ──
if [ ! -f "src/appConfig.ts" ]; then
    echo "  ❌ src/appConfig.ts not found — LLM must generate this file."
    exit 1
fi

# ── Download supero-mobile.jsx library ──
# Patched by migrate_supero_3_5_0.sh — read from wheel instead of CDN
mkdir -p src/lib
if [ ! -f src/lib/supero-mobile.jsx ] || [ "${FORCE_DOWNLOAD:-false}" = "true" ]; then
    echo "  Reading supero-mobile.jsx from supero wheel…"
    SUPERO_MOBILE_LIB="$(python3 -c 'from supero.ui import mobile_lib_path; print(mobile_lib_path())' 2>/dev/null)"
    if [ -n "$SUPERO_MOBILE_LIB" ] && [ -f "$SUPERO_MOBILE_LIB" ]; then
        cp "$SUPERO_MOBILE_LIB" src/lib/supero-mobile.jsx \
            && echo "  ✅ supero-mobile.jsx (from wheel)" \
            || echo "  ⚠️  Failed to copy from wheel"
    else
        echo "  ⚠️  supero wheel not installed; src/lib/supero-mobile.jsx may be stale"
    fi
fi
# ── Generate package.json (if not present or wrong SDK) ──
# ⚠️ Pinned versions prevent TurboModule crashes
if [ ! -f "package.json" ] || ! grep -q '"expo": "~54' package.json 2>/dev/null; then
    echo "  Generating package.json (Expo SDK 54, pinned versions)…"
    cat > package.json << PKGJSON
{
  "name": "${APP_SLUG}",
  "version": "1.0.0",
  "scripts": {
    "start": "expo start",
    "android": "expo start --android",
    "ios": "expo start --ios"
  },
  "dependencies": {
    "expo": "~54.0.0",
    "expo-status-bar": "~3.0.9",
    "react": "19.1.0",
    "react-native": "0.81.5",
    "@react-navigation/native": "^7.1.0",
    "@react-navigation/native-stack": "^7.3.0",
    "@react-navigation/bottom-tabs": "^7.3.0",
    "react-native-screens": "~4.16.0",
    "react-native-safe-area-context": "~5.6.0",
    "@react-native-async-storage/async-storage": "2.2.0"
  },
  "devDependencies": {
    "@babel/core": "^7.25.2",
    "typescript": "~5.9.2",
    "@types/react": "~19.1.10"
  },
  "private": true
}
PKGJSON
    echo "  ✅ package.json generated"
else
    echo "  ✅ package.json present (SDK 54)"
fi

# ── Generate app.json from appConfig.ts values ──
if [ ! -f "app.json" ] || [ "$ACTION" = "setup" ]; then
    echo "  Generating app.json (name: ${APP_NAME}, slug: ${APP_SLUG})…"
    cat > app.json << APPJSON
{
  "expo": {
    "name": "${APP_NAME}",
    "slug": "${APP_SLUG}",
    "version": "1.0.0",
    "orientation": "portrait",
    "scheme": "${APP_SLUG}",
    "userInterfaceStyle": "light",
    "splash": { "backgroundColor": "${APP_COLOR}", "resizeMode": "contain" },
    "assetBundlePatterns": ["**/*"],
    "ios": { "supportsTablet": true, "bundleIdentifier": "com.supero.${APP_SLUG}" },
    "android": { "adaptiveIcon": { "backgroundColor": "${APP_COLOR}" }, "package": "com.supero.${APP_SLUG}" },
    "newArchEnabled": true
  }
}
APPJSON
    echo "  ✅ app.json generated"
else
    echo "  ✅ app.json present"
fi

# ── Generate tsconfig.json ──
if [ ! -f "tsconfig.json" ]; then
    cat > tsconfig.json << 'TSCONF'
{
  "extends": "expo/tsconfig.base",
  "compilerOptions": { "strict": false, "jsx": "react-jsx", "paths": { "@/*": ["./src/*"] } },
  "include": ["**/*.ts", "**/*.tsx"]
}
TSCONF
    echo "  ✅ tsconfig.json generated"
fi

# ── Generate babel.config.js ──
if [ ! -f "babel.config.js" ]; then
    cat > babel.config.js << 'BABEL'
module.exports = function (api) {
  api.cache(true);
  return { presets: ['babel-preset-expo'] };
};
BABEL
    echo "  ✅ babel.config.js generated"
fi

# ── Generate .gitignore ──
if [ ! -f ".gitignore" ]; then
    cat > .gitignore << 'GI'
node_modules/
.expo/
dist/
web-build/
src/lib/
*.jks
*.p8
*.p12
*.key
*.mobileprovision
GI
    echo "  ✅ .gitignore generated"
fi

# ════════════════════════════════════════════════════════════════════
# CLOUD_BUILD_GUARD_V1 (BEGIN) — local-dev only
#
# Cloud Build sets CI=1 (see preview_service.ALL_DOCKERFILE_TEMPLATE):
#     EXPO_NO_TELEMETRY=1 CI=1 ./expo.sh setup
# We MUST skip everything below in Cloud Build because:
#   1. ../.env doesn't exist in the build context (sanitized away)
#   2. The cloudflared tunnel URL would die when the build container exits
#   3. preview_service._patch_appconfig_server_url already wrote the
#      correct Cloud Run URL into src/appConfig.ts BEFORE this script
#      ran. Re-patching here would replace it with a tunnel URL that
#      doesn't survive the build.
#
# In local dev (no CI env var): everything below runs normally.
# ════════════════════════════════════════════════════════════════════
if [ "$CI" != "1" ]; then

    # ── Read SUPERO_DOMAIN / SUPERO_PROJECT from parent .env ──
    SUPERO_DOMAIN_VAL=""
    SUPERO_PROJECT_VAL=""
    if [ -f "../.env" ]; then
        SUPERO_DOMAIN_VAL=$(grep -E '^SUPERO_DOMAIN=' ../.env 2>/dev/null | head -1 | sed 's/SUPERO_DOMAIN="\?\([^"]*\)"\?/\1/')
        SUPERO_PROJECT_VAL=$(grep -E '^SUPERO_PROJECT=' ../.env 2>/dev/null | head -1 | sed 's/SUPERO_PROJECT="\?\([^"]*\)"\?/\1/')
    fi

    # ── Start cloudflared tunnel for global HTTPS access ──
    # Cloudflare Tunnel bypasses cloud firewall rules and gives an HTTPS URL
    # that works on any device, anywhere — no port-forwarding needed.
    CLOUDFLARED_BIN=""
    for _cf in cloudflared /tmp/cloudflared ~/.local/bin/cloudflared; do
        if command -v "$_cf" >/dev/null 2>&1 || [ -x "$_cf" ]; then
            CLOUDFLARED_BIN="$_cf"
            break
        fi
    done

    # Auto-download cloudflared if not present
    if [ -z "$CLOUDFLARED_BIN" ]; then
        echo "  Downloading cloudflared for HTTPS tunnel…"
        curl -fsSL https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 \
            -o /tmp/cloudflared 2>/dev/null && chmod +x /tmp/cloudflared \
            && CLOUDFLARED_BIN="/tmp/cloudflared" \
            && echo "  ✅ cloudflared downloaded" \
            || echo "  ⚠️  cloudflared download failed"
    fi

    TUNNEL_URL=""
    LAN_IP=""
    if [ -n "$CLOUDFLARED_BIN" ]; then
        # Kill any stale tunnel on this port
        pkill -f "cloudflared.*${SERVER_PORT}" 2>/dev/null || true
        sleep 1
        # Start tunnel, capture URL from its log output
        _CF_LOG="/tmp/cloudflared-${SERVER_PORT}.log"
        "$CLOUDFLARED_BIN" tunnel --url "http://localhost:${SERVER_PORT}" --no-autoupdate > "$_CF_LOG" 2>&1 &
        echo "  Starting Cloudflare Tunnel…"
        # Wait up to 15s for the URL to appear
        for _i in $(seq 1 15); do
            TUNNEL_URL=$(grep -o 'https://[a-z0-9-]*\.trycloudflare\.com' "$_CF_LOG" 2>/dev/null | head -1)
            [ -n "$TUNNEL_URL" ] && break
            sleep 1
        done
        if [ -n "$TUNNEL_URL" ]; then
            echo "  ✅ Tunnel ready: $TUNNEL_URL"
            LAN_IP="$TUNNEL_URL"
        else
            echo "  ⚠️  Tunnel URL not detected — falling back to direct IP"
        fi
    fi

    # ── Fall back to LAN/public IP if tunnel failed ──
    if [ -z "$TUNNEL_URL" ]; then
        if command -v ip >/dev/null 2>&1; then
            LAN_IP=$(ip addr show eth0 2>/dev/null | awk '/inet / {split($2,a,"/"); print a[1]; exit}')
        fi
        [ -z "$LAN_IP" ] && LAN_IP=$(ip route get 1 2>/dev/null | awk '{print $7; exit}' || echo "")
        [ -z "$LAN_IP" ] && LAN_IP=$(hostname -I 2>/dev/null | awk '{print $1}' || echo "")
        if command -v ipconfig >/dev/null 2>&1 && [ "$(uname)" = "Darwin" ]; then
            LAN_IP=$(ipconfig getifaddr en0 2>/dev/null || ipconfig getifaddr en1 2>/dev/null || echo "")
        fi
    fi

    # ── Patch appConfig.ts (serverUrl, domain, project) ──
    if [ -n "$TUNNEL_URL" ]; then
        sed -i.bak "s|serverUrl:[ ]*'[^']*'|serverUrl: '${TUNNEL_URL}'|g" src/appConfig.ts 2>/dev/null
        rm -f src/appConfig.ts.bak
        echo "  ✅ appConfig.ts serverUrl → ${TUNNEL_URL}"
    elif [ -n "$LAN_IP" ]; then
        sed -i.bak "s|serverUrl:[ ]*'[^']*'|serverUrl: 'http://${LAN_IP}:${SERVER_PORT}'|g" src/appConfig.ts 2>/dev/null
        rm -f src/appConfig.ts.bak
        echo "  ✅ appConfig.ts serverUrl → http://${LAN_IP}:${SERVER_PORT}"
    else
        echo "  ⚠️  Could not determine serverUrl — using value in appConfig.ts"
    fi

    if [ -n "$SUPERO_DOMAIN_VAL" ]; then
        sed -i.bak "s|domain:[ ]*'[^']*'|domain: '${SUPERO_DOMAIN_VAL}'|g" src/appConfig.ts 2>/dev/null
        rm -f src/appConfig.ts.bak
        echo "  ✅ appConfig.ts domain → ${SUPERO_DOMAIN_VAL}"
    fi
    if [ -n "$SUPERO_PROJECT_VAL" ]; then
        sed -i.bak "s|project:[ ]*'[^']*'|project: '${SUPERO_PROJECT_VAL}'|g" src/appConfig.ts 2>/dev/null
        rm -f src/appConfig.ts.bak
        echo "  ✅ appConfig.ts project → ${SUPERO_PROJECT_VAL}"
    fi

fi
# CLOUD_BUILD_GUARD_V1 (END)
# ════════════════════════════════════════════════════════════════════

# ── Install dependencies ──
if [ ! -d node_modules ] || [ "$ACTION" = "install" ] || [ "$ACTION" = "setup" ]; then
    echo "  Installing dependencies…"
    npm install --legacy-peer-deps --silent 2>&1 | tail -3
    echo "  ✅ Dependencies installed"
else
    echo "  ✅ node_modules present"
fi

echo ""
echo "  📋 Server Setup"
echo "  ──────────────────────────────────────────────"
echo "  Make sure server.py is running: ./run.sh"
if [ -n "$TUNNEL_URL" ]; then
    echo "  API URL: ${TUNNEL_URL}  (Cloudflare HTTPS tunnel)"
else
    echo "  API URL: http://${LAN_IP:-localhost}:${SERVER_PORT}"
fi
echo ""

# ── Run action ──
case "$ACTION" in
    setup)
        echo "  ✅ Setup complete! Run: ./expo.sh start"
        ;;
    install)
        echo "  ✅ Install complete."
        ;;
    clean)
        echo "  🧹 Cleaning…"
        rm -rf node_modules .expo dist
        rm -f package.json app.json tsconfig.json babel.config.js .gitignore
        rm -rf src/lib
        echo "  ✅ Cleaned. Run: ./expo.sh setup"
        ;;
    android)
        echo "  🤖 Starting Expo for Android…"
        unset EXPO_TOKEN
        npx expo start --android --clear
        ;;
    ios)
        echo "  🍎 Starting Expo for iOS…"
        unset EXPO_TOKEN
        npx expo start --ios --clear
        ;;
    start|*)
        echo "  🚀 Starting Expo dev server…"
        echo "  Scan the QR code with Expo Go on your device."
        echo ""
        unset EXPO_TOKEN
        npx expo start --clear
        ;;
esac
