"""
Auto-generated types from schemas.

This file enables backward compatibility by exposing all class names
when using `from pymodel.types import *`.

Generated classes:
- Address (from address)
- Address (from address)
- AddressType (from address_type)
- ApiKeySecretType (from api_key_secret_type)
- AppArtifact (from app_artifact)
- AppArtifact (from app_artifact)
- AppQrCode (from app_qr_code)
- AppQrCode (from app_qr_code)
- BasicAuthSecretType (from basic_auth_secret_type)
- BearerTokenSecretType (from bearer_token_secret_type)
- BusinessHoursType (from business_hours_type)
- CertificateSecretType (from certificate_secret_type)
- ComputedFieldType (from computed_field_type)
- Condition (from condition)
- ConnectorSourceType (from connector_source_type)
- ConnectorTargetType (from connector_target_type)
- ConnectorTransformType (from connector_transform_type)
- ConnectorTriggerType (from connector_trigger_type)
- ContactInfo (from contact_info)
- ContactInfo (from contact_info)
- CsvFileConfigType (from csv_file_config_type)
- Currency (from currency)
- Currency (from currency)
- DatabaseConfigType (from database_config_type)
- DatabaseIncrementalType (from database_incremental_type)
- DateRange (from date_range)
- DateRange (from date_range)
- DayHoursType (from day_hours_type)
- DisplayNameMap (from display_name_map)
- DisplayNameMap (from display_name_map)
- Email (from email)
- Email (from email)
- EntityRelationship (from entity_relationship)
- FieldMappingType (from field_mapping_type)
- File (from file)
- File (from file)
- FilterConditionType (from filter_condition_type)
- GeoLocation (from geo_location)
- GeoLocation (from geo_location)
- HttpApiAuthType (from http_api_auth_type)
- HttpApiConfigType (from http_api_config_type)
- HttpApiPaginationType (from http_api_pagination_type)
- HttpApiRateLimitType (from http_api_rate_limit_type)
- HttpApiResponseType (from http_api_response_type)
- HttpApiRetryType (from http_api_retry_type)
- Image (from image)
- Image (from image)
- OAuth2SecretType (from oauth2_secret_type)
- PhoneNumber (from phone_number)
- PhoneNumber (from phone_number)
- PluginCapabilitiesType (from plugin_capabilities_type)
- PluginConfigType (from plugin_config_type)
- Rule (from rule)
- SecretType (from secret_type)
- Signature (from signature)
- Signature (from signature)
- SshKeySecretType (from ssh_key_secret_type)
- StatusWorkflow (from status_workflow)
- URL (from url)
- URL (from url)
- WebhookConfigType (from webhook_config_type)
"""

# Import all generated classes
from .address import Address
from .address import Address
from .address_type import AddressType
from .api_key_secret_type import ApiKeySecretType
from .app_artifact import AppArtifact
from .app_artifact import AppArtifact
from .app_qr_code import AppQrCode
from .app_qr_code import AppQrCode
from .basic_auth_secret_type import BasicAuthSecretType
from .bearer_token_secret_type import BearerTokenSecretType
from .business_hours_type import BusinessHoursType
from .certificate_secret_type import CertificateSecretType
from .computed_field_type import ComputedFieldType
from .condition import Condition
from .connector_source_type import ConnectorSourceType
from .connector_target_type import ConnectorTargetType
from .connector_transform_type import ConnectorTransformType
from .connector_trigger_type import ConnectorTriggerType
from .contact_info import ContactInfo
from .contact_info import ContactInfo
from .csv_file_config_type import CsvFileConfigType
from .currency import Currency
from .currency import Currency
from .database_config_type import DatabaseConfigType
from .database_incremental_type import DatabaseIncrementalType
from .date_range import DateRange
from .date_range import DateRange
from .day_hours_type import DayHoursType
from .display_name_map import DisplayNameMap
from .display_name_map import DisplayNameMap
from .email import Email
from .email import Email
from .entity_relationship import EntityRelationship
from .field_mapping_type import FieldMappingType
from .file import File
from .file import File
from .filter_condition_type import FilterConditionType
from .geo_location import GeoLocation
from .geo_location import GeoLocation
from .http_api_auth_type import HttpApiAuthType
from .http_api_config_type import HttpApiConfigType
from .http_api_pagination_type import HttpApiPaginationType
from .http_api_rate_limit_type import HttpApiRateLimitType
from .http_api_response_type import HttpApiResponseType
from .http_api_retry_type import HttpApiRetryType
from .image import Image
from .image import Image
from .oauth2_secret_type import OAuth2SecretType
from .phone_number import PhoneNumber
from .phone_number import PhoneNumber
from .plugin_capabilities_type import PluginCapabilitiesType
from .plugin_config_type import PluginConfigType
from .rule import Rule
from .secret_type import SecretType
from .signature import Signature
from .signature import Signature
from .ssh_key_secret_type import SshKeySecretType
from .status_workflow import StatusWorkflow
from .url import URL
from .url import URL
from .webhook_config_type import WebhookConfigType

# Define __all__ for explicit control of `import *`
__all__ = [
    "Address",
    "Address",
    "AddressType",
    "ApiKeySecretType",
    "AppArtifact",
    "AppArtifact",
    "AppQrCode",
    "AppQrCode",
    "BasicAuthSecretType",
    "BearerTokenSecretType",
    "BusinessHoursType",
    "CertificateSecretType",
    "ComputedFieldType",
    "Condition",
    "ConnectorSourceType",
    "ConnectorTargetType",
    "ConnectorTransformType",
    "ConnectorTriggerType",
    "ContactInfo",
    "ContactInfo",
    "CsvFileConfigType",
    "Currency",
    "Currency",
    "DatabaseConfigType",
    "DatabaseIncrementalType",
    "DateRange",
    "DateRange",
    "DayHoursType",
    "DisplayNameMap",
    "DisplayNameMap",
    "Email",
    "Email",
    "EntityRelationship",
    "FieldMappingType",
    "File",
    "File",
    "FilterConditionType",
    "GeoLocation",
    "GeoLocation",
    "HttpApiAuthType",
    "HttpApiConfigType",
    "HttpApiPaginationType",
    "HttpApiRateLimitType",
    "HttpApiResponseType",
    "HttpApiRetryType",
    "Image",
    "Image",
    "OAuth2SecretType",
    "PhoneNumber",
    "PhoneNumber",
    "PluginCapabilitiesType",
    "PluginConfigType",
    "Rule",
    "SecretType",
    "Signature",
    "Signature",
    "SshKeySecretType",
    "StatusWorkflow",
    "URL",
    "URL",
    "WebhookConfigType",
]

# Backward compatibility aliases (if needed)
# Add any legacy name mappings here
