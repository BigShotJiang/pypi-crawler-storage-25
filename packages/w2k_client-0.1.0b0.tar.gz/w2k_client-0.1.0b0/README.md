# w2k-client

Python HTTP client for the Actisense W2K-1 NMEA 2000 Wi-Fi gateway.

Handles login / bearer-token authentication, device info, folder and file
listing, and streaming EBL file download.

## Requirements

- Python 3.9+
- [requests](https://docs.python-requests.org/) 2.28+

## Installation

```bash
pip install w2k-client
```

## Usage

```python
from w2k_client import W2KClient

with W2KClient("192.168.4.1", password="admin") as client:
    info = client.get_info()
    print(f"Serial number: {info.serial_number}")

    folders = client.list_data_folders()
    for folder in folders:
        files = client.list_files(folder.name)
        for f in files:
            print(f"  {folder.name}/{f.file_name}  ({f.file_size} bytes)")
            client.download_file(folder.name, f.file_name, dest_dir="/tmp/ebl/")
```

### Download an entire folder

```python
from w2k_client import W2KClient

with W2KClient("192.168.4.1", password="admin") as client:
    paths = client.download_folder("EBL000000", dest_dir="/tmp/ebl/")
    print(f"Downloaded {len(paths)} files")
```

## Notes

- The W2K-1 exposes its REST API over its own Wi-Fi access point
  (default SSID/IP: `192.168.4.1`).
- EBL files contain raw NMEA 2000 bus traffic and can be analysed with
  Actisense tools or third-party parsers.

## Disclaimer

This software is provided as-is, without any warranty. Use at your own risk.
The authors are not responsible for any damage to devices or data loss.

## License

MIT — see [LICENSE](LICENSE)
