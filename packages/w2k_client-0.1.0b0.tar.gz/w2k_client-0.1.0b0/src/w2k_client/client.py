"""
Actisense W2K-1 REST API Client Library

The Actisense W2K-1 is a Wi-Fi gateway for NMEA 2000 networks used on marine
vessels. It records NMEA 2000 bus traffic as EBL (Electronic Bus Log) files
on an SD card and exposes them via an HTTP REST API over its Wi-Fi access point
(default: 192.168.4.1).

This library provides a Python client for that REST API. It handles login /
bearer-token authentication, optional device clock synchronisation, folder and
file listing, and streaming file download.

API flow
--------
1. POST /api/login          → obtain a bearer token
2. GET  /api/info           → read device info (serial number, firmware, …)
3. GET  /api/data_logs      → list EBL folders (one per recording session)
4. GET  /api/data_logs?method=fileList&folder=<name>
                            → list EBL files inside a folder
5. GET  /api/download?file_name=<remote_path>
                            → stream-download a single EBL file

Data classes
------------
DataFolder — one entry per recording session folder:

    ===============  =======  =============================================
    Field            Type     Description
    ===============  =======  =============================================
    name             str      Folder name (e.g. ``"EBL000000"``)
    size             int      Total size of all files in the folder (bytes)
    is_expanded      bool     Whether the folder is currently open/active
    is_in_progress   bool     Whether recording is ongoing in this folder
    ===============  =======  =============================================

DataFile — one entry per EBL file inside a folder:

    ===============  =======  =============================================
    Field            Type     Description
    ===============  =======  =============================================
    file_name        str      File name (e.g. ``"000000_080.ebl"``)
    file_size        int      File size in bytes
    file_time        int      Recording start time (Unix timestamp, UTC)
    ===============  =======  =============================================

Usage
-----
    from w2k_client import W2KClient

    with W2KClient("192.168.4.1", password="admin") as client:
        info    = client.get_info()
        folders = client.list_data_folders()
        for folder in folders:
            files = client.list_files(folder.name)
            for f in files:
                client.download_file(folder.name, f.file_name, "/local/path/")
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator

import requests

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data classes (plain dataclasses, no external deps)
# ---------------------------------------------------------------------------

from dataclasses import dataclass, field


@dataclass
class DeviceInfo:
    serial_number: str
    raw: dict = field(repr=False, default_factory=dict)

    @classmethod
    def from_response(cls, data: dict) -> "DeviceInfo":
        sn = ""
        for col in data.get("statusColumns", []):
            if col.get("name") == "Device":
                for detail in col.get("statusDetails", []):
                    if detail.get("key") == "Serial Number":
                        sn = detail["value"]
        return cls(serial_number=sn, raw=data)


@dataclass
class DataFolder:
    name: str
    size: int
    is_expanded: bool
    is_in_progress: bool
    raw: dict = field(repr=False, default_factory=dict)

    @classmethod
    def from_dict(cls, d: dict) -> "DataFolder":
        return cls(
            name=d["name"],
            size=d["size"],
            is_expanded=d["isExpanded"],
            is_in_progress=d["isInProgress"],
            raw=d,
        )


@dataclass
class DataFile:
    file_name: str
    file_size: int
    file_time: int  # Unix timestamp

    @property
    def timestamp_utc(self) -> datetime:
        return datetime.fromtimestamp(self.file_time, timezone.utc)

    @classmethod
    def from_dict(cls, d: dict) -> "DataFile":
        return cls(
            file_name=d["file_name"],
            file_size=d["file_size"],
            file_time=d["file_time"],
        )


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class W2KError(Exception):
    """Base exception for W2K client errors."""


class W2KAuthError(W2KError):
    """Authentication failed."""


class W2KRequestError(W2KError):
    """An API request returned an error response."""

    def __init__(self, method: str, url: str, status_code: int, body: str = ""):
        self.method = method
        self.url = url
        self.status_code = status_code
        self.body = body
        super().__init__(f"{method} {url} → HTTP {status_code}: {body[:200]}")


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------


class W2KClient:
    """HTTP client for the Actisense W2K REST API.

    Parameters
    ----------
    host:
        IP address or hostname of the W2K device (without scheme).
        Defaults to ``"192.168.4.1"``.
    password:
        Admin password for the device.
    username:
        Login username. Defaults to ``"admin"``.
    timeout:
        Request timeout in seconds. Defaults to ``10``.
    sync_time_on_login:
        When ``True`` (default), set the device clock to local time
        immediately after a successful login.
    """

    DEFAULT_HOST = "192.168.4.1"
    EBL_BASE_PATH = "/sdcard/W2K-1/ebl_data_logs"

    def __init__(
        self,
        host: str = DEFAULT_HOST,
        password: str = "",
        username: str = "admin",
        timeout: int = 10,
        sync_time_on_login: bool = True,
    ) -> None:
        self._base = f"http://{host}"
        self._password = password
        self._username = username
        self._timeout = timeout
        self._sync_time_on_login = sync_time_on_login
        self._session: requests.Session | None = None

    # ------------------------------------------------------------------
    # Context manager support
    # ------------------------------------------------------------------

    def __enter__(self) -> "W2KClient":
        self.login()
        return self

    def __exit__(self, *_) -> None:
        self.close()

    # ------------------------------------------------------------------
    # Session management
    # ------------------------------------------------------------------

    def login(self) -> None:
        """Authenticate and store the bearer token in the session."""
        self._session = requests.Session()
        url = f"{self._base}/api/login"
        resp = self._session.post(
            url,
            json={"user": self._username, "password": self._password},
            timeout=self._timeout,
        )
        if not resp.ok:
            raise W2KAuthError(
                f"Login failed (HTTP {resp.status_code}): {resp.text[:200]}"
            )
        data = resp.json()
        token = data.get("token")
        if not token:
            raise W2KAuthError(f"No token in login response: {data}")
        self._session.headers.update({"Authorization": f"Bearer {token}"})
        logger.info("W2K login successful")

        if self._sync_time_on_login:
            self.sync_time()

    def close(self) -> None:
        if self._session:
            self._session.close()
            self._session = None

    def _ensure_session(self) -> requests.Session:
        if self._session is None:
            raise W2KError("Not logged in. Call login() or use as context manager.")
        return self._session

    # ------------------------------------------------------------------
    # Internal request helpers
    # ------------------------------------------------------------------

    def _get(self, path: str, **kwargs) -> requests.Response:
        session = self._ensure_session()
        url = f"{self._base}/{path.lstrip('/')}"
        resp = session.get(url, timeout=self._timeout, **kwargs)
        if not resp.ok:
            raise W2KRequestError("GET", url, resp.status_code, resp.text)
        return resp

    def _post(self, path: str, payload: dict) -> requests.Response:
        session = self._ensure_session()
        url = f"{self._base}/{path.lstrip('/')}"
        resp = session.post(url, json=payload, timeout=self._timeout)
        if not resp.ok:
            raise W2KRequestError("POST", url, resp.status_code, resp.text)
        return resp

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def sync_time(self, dt: datetime | None = None) -> None:
        """Set the device clock.

        Parameters
        ----------
        dt:
            Datetime to sync to. Defaults to ``datetime.now()`` (local time).
        """
        dt = dt or datetime.now()
        payload = {
            "year": dt.year,
            "month": dt.month,
            "mday": dt.day,
            "hour": dt.hour,
            "min": dt.minute,
            "sec": dt.second,
        }
        self._post("/api/date_time", payload)
        logger.info("W2K time synced to %s", dt.isoformat())

    def get_info(self) -> DeviceInfo:
        """Return device information including the serial number."""
        resp = self._get("/api/info")
        return DeviceInfo.from_response(resp.json())

    def get_paths(self) -> dict:
        """Return raw path configuration from the device."""
        return self._get("/paths").json()

    def list_data_folders(self) -> list[DataFolder]:
        """List all EBL data log folders on the device."""
        data = self._get("/api/data_logs").json()
        return [DataFolder.from_dict(f) for f in data.get("dataFolders", [])]

    def list_files(self, folder: str) -> list[DataFile]:
        """List EBL files inside a specific folder.

        Parameters
        ----------
        folder:
            Folder name as returned by :meth:`list_data_folders`, e.g. ``"EBL000000"``.
        """
        data = self._get(f"/api/data_logs?method=fileList&folder={folder}").json()
        return [DataFile.from_dict(f) for f in data.get("dataFiles", [])]

    def download_file(
        self,
        folder: str,
        file_name: str,
        dest_dir: str | Path = ".",
        chunk_size: int = 8192,
        progress_callback: "((int, int | None) -> None) | None" = None,
    ) -> Path:
        """Download a single EBL file from the device.

        Parameters
        ----------
        folder:
            Folder name on the device (e.g. ``"EBL000000"``).
        file_name:
            File name to download (e.g. ``"000000_080.ebl"``).
        dest_dir:
            Local directory to save the file into. Created if it doesn't exist.
        chunk_size:
            Streaming chunk size in bytes.
        progress_callback:
            Optional ``(bytes_downloaded, total_bytes_or_None) -> None`` callable
            called after each chunk.

        Returns
        -------
        Path
            Path to the saved file.
        """
        dest_dir = Path(dest_dir)
        dest_dir.mkdir(parents=True, exist_ok=True)
        dest_path = dest_dir / file_name

        remote_path = f"{self.EBL_BASE_PATH}/{folder}/{file_name}"
        resp = self._get(
            f"/api/download?file_name={remote_path}",
            stream=True,
        )

        total = int(resp.headers.get("Content-Length", 0)) or None
        downloaded = 0

        with open(dest_path, "wb") as fh:
            for chunk in resp.iter_content(chunk_size=chunk_size):
                fh.write(chunk)
                downloaded += len(chunk)
                if progress_callback:
                    progress_callback(downloaded, total)

        logger.info("Downloaded %s → %s (%d bytes)", file_name, dest_path, downloaded)
        return dest_path

    def download_folder(
        self,
        folder: str,
        dest_dir: str | Path = ".",
        skip_existing: bool = True,
        progress_callback: "((str, int, int | None) -> None) | None" = None,
    ) -> list[Path]:
        """Download all EBL files in a folder.

        Parameters
        ----------
        folder:
            Folder name on the device.
        dest_dir:
            Local directory to save files into.
        skip_existing:
            Skip files that already exist locally.
        progress_callback:
            Optional ``(file_name, bytes_downloaded, total_or_None) -> None`` callable.

        Returns
        -------
        list[Path]
            Paths of all downloaded (or already present) files.
        """
        dest_dir = Path(dest_dir)
        files = self.list_files(folder)
        paths: list[Path] = []

        for f in files:
            dest = dest_dir / f.file_name
            if skip_existing and dest.exists():
                logger.info("Skipping %s (already exists)", f.file_name)
                paths.append(dest)
                continue

            cb = None
            if progress_callback:

                def cb(downloaded: int, total: int | None, _name=f.file_name):
                    progress_callback(_name, downloaded, total)

            paths.append(
                self.download_file(folder, f.file_name, dest_dir, progress_callback=cb)
            )

        return paths
