"""Generate evaluation spec from analysis and (optionally) user preferences."""

import json
import logging
from pathlib import Path

from overmind import SpanType
from overmind.core.registry import project_root, project_root_from_agent_file
from overmind.tracing import observe_safe
from overmind.utils.code import _detect_entry_search_paths

logger = logging.getLogger(__name__)

IMPORTANCE_MULTIPLIERS = {"critical": 3, "important": 2, "minor": 1}


@observe_safe(span_name="overmind.setup.generate_spec", type=SpanType.FUNCTION)
def generate_spec_from_proposal(analysis: dict, policy_data: dict | None = None) -> dict:
    """Build an eval spec directly from the LLM's proposed criteria.

    When *policy_data* is provided, it is embedded into the spec so that
    downstream consumers (optimizer, data generator, judge) can access it
    without re-reading the Markdown file.
    """
    output_schema = analysis.get("output_schema", {})
    criteria = analysis.get("proposed_criteria", {})
    fields_criteria = criteria.get("fields", {})
    structure_weight = criteria.get("structure_weight", 20)

    field_importance = {name: fc.get("importance", "important") for name, fc in fields_criteria.items()}

    field_settings: dict[str, dict] = {}
    for field_name, fc in fields_criteria.items():
        ftype = output_schema.get(field_name, {}).get("type", "text")
        settings: dict = {}
        if ftype == "enum":
            settings["partial_credit"] = fc.get("partial_credit", True)
        elif ftype == "number":
            settings["tolerance"] = fc.get("tolerance", 10)
        elif ftype == "text":
            importance = fc.get("importance", "important")
            default_mode = "similarity" if importance in ("critical", "important") else "non_empty"
            settings["eval_mode"] = fc.get("eval_mode", default_mode)
        field_settings[field_name] = settings

    return _build_spec(
        analysis,
        output_schema,
        field_importance,
        field_settings,
        structure_weight,
        policy_data=policy_data,
    )


def _build_spec(
    analysis: dict,
    output_schema: dict,
    field_importance: dict[str, str],
    field_settings: dict[str, dict],
    structure_weight: int,
    policy_data: dict | None = None,
) -> dict:
    """Shared logic for assembling the final spec dict."""
    tool_analysis = analysis.get("tool_analysis", {})
    has_tools = bool(tool_analysis.get("tools"))

    # Reserve points for tool_usage if tools exist
    tool_usage_weight = 0
    if has_tools:
        tool_usage_weight = 10

    # Auto-allocate LLM judge weight when text or complex fields exist
    text_fields = [name for name, info in output_schema.items() if info.get("type") == "text"]
    text_weight_sum = sum(
        IMPORTANCE_MULTIPLIERS.get(field_importance.get(name, "important"), 2) for name in text_fields
    )
    llm_judge_weight = 0
    if text_weight_sum > 0 or policy_data:
        llm_judge_weight = 10

    available_points = 100 - structure_weight - tool_usage_weight - llm_judge_weight

    # Compute raw importance weights
    raw_weights: dict[str, int] = {}
    total_raw = 0
    for field_name in output_schema:
        importance = field_importance.get(field_name, "important")
        raw = IMPORTANCE_MULTIPLIERS.get(importance, 2)
        raw_weights[field_name] = raw
        total_raw += raw

    # Allocate points proportionally, then fix rounding
    weights: dict[str, int] = {}
    for field_name in output_schema:
        raw = raw_weights.get(field_name, 2)
        weights[field_name] = round((raw / max(total_raw, 1)) * available_points)

    weight_sum = sum(weights.values())
    if weight_sum != available_points and weights:
        first = next(iter(weights))
        weights[first] += available_points - weight_sum

    # Build per-field spec
    output_fields: dict[str, dict] = {}
    for field_name, info in output_schema.items():
        ftype = info.get("type", "text")
        weight = weights.get(field_name, 0)
        settings = field_settings.get(field_name, {})

        field_spec: dict = {
            "type": ftype,
            "description": info.get("description", ""),
            "weight": weight,
            "importance": field_importance.get(field_name, "important"),
        }

        if ftype == "enum":
            field_spec["values"] = info.get("values", [])
            field_spec["partial_credit"] = settings.get("partial_credit", True)
            field_spec["partial_score"] = max(1, round(weight * 0.2))

        elif ftype == "number":
            field_spec["range"] = info.get("range", [0, 100])
            tolerance = settings.get("tolerance", 10)
            field_spec["tolerance_bands"] = [
                {"within": max(1, tolerance // 2), "score_pct": 1.0},
                {"within": tolerance, "score_pct": 0.8},
                {"within": int(tolerance * 1.5), "score_pct": 0.5},
                {"within": int(tolerance * 2.5), "score_pct": 0.25},
            ]

        elif ftype == "text":
            field_spec["eval_mode"] = settings.get("eval_mode", "similarity")

        output_fields[field_name] = field_spec

    # Build tool_config from tool_analysis
    tool_config: dict = {}
    if tool_analysis:
        tool_config["expected_tools"] = tool_analysis.get("expected_tools", [])
        tool_config["dependencies"] = tool_analysis.get("dependencies", [])

        param_constraints: dict[str, dict] = {}
        for tool_name, tool_info in tool_analysis.get("tools", {}).items():
            constraints = tool_info.get("param_constraints", {})
            if constraints:
                param_constraints[tool_name] = constraints
        tool_config["param_constraints"] = param_constraints

    # Build consistency rules: use LLM-generated rules from analysis, then
    # auto-generate structural rules for field pairs that the LLM missed.
    consistency_rules = list(analysis.get("consistency_rules", []))
    auto_rules = _generate_consistency_rules(output_schema, output_fields)
    existing_pairs = {(r.get("field_a"), r.get("field_b")) for r in consistency_rules}
    for rule in auto_rules:
        pair = (rule["field_a"], rule["field_b"])
        if pair not in existing_pairs:
            consistency_rules.append(rule)

    spec: dict = {
        "agent_description": analysis.get("description", ""),
        "agent_path": analysis.get("_agent_path", ""),
        "input_schema": analysis.get("input_schema", {}),
        "output_fields": output_fields,
        "structure_weight": structure_weight,
        "total_points": 100,
        "optimizable_elements": analysis.get("optimizable_elements", []),
        "fixed_elements": analysis.get("fixed_elements", []),
    }

    if analysis.get("_entrypoint_fn"):
        spec["entrypoint_fn"] = analysis["_entrypoint_fn"]

    scope = dict(analysis.get("scope") or {})
    entry_rel = analysis.get("_entry_rel")
    agent_path = analysis.get("_agent_path") or ""

    if entry_rel:
        # The accept-step enforcement only protects files listed in
        # ``scope.read_only_paths``. The registered Overmind entrypoint
        # is an interaction harness, not agent logic, and must never be
        # edited by optimization candidates — even when the analyzer
        # forgets to declare it. We only auto-add when the entry isn't
        # already covered by ``optimizable_paths`` (single-file agents
        # where the entry IS the agent under test).
        opt_paths = list(scope.get("optimizable_paths") or [])
        ro_paths = list(scope.get("read_only_paths") or [])
        excl_paths = list(scope.get("exclude_paths") or [])

        # An entry that the LLM put in ``exclude_paths`` would collapse
        # the bundle: ``resolve_local_files`` refuses to ignore the
        # entry and raises ``BundleConfigError``. The entry MUST be
        # reachable for BFS; if the analyzer intended "don't edit it,"
        # that's what ``read_only_paths`` is for. Move the declaration
        # to the right field and warn so the user sees what happened.
        if entry_rel in excl_paths:
            excl_paths = [p for p in excl_paths if p != entry_rel]
            scope["exclude_paths"] = excl_paths
            logger.warning(
                "spec_generator: moved %r from exclude_paths to read_only_paths (entry must be reachable for BFS)",
                entry_rel,
            )
            if entry_rel not in opt_paths and entry_rel not in ro_paths:
                ro_paths.append(entry_rel)
                scope["read_only_paths"] = ro_paths
        elif entry_rel not in opt_paths and entry_rel not in ro_paths:
            ro_paths.append(entry_rel)
            scope["read_only_paths"] = ro_paths

    # Deterministic ``search_paths`` injection from the entry's own
    # ``sys.path`` mutations. The analyzer prompt asks the LLM to emit
    # this declaratively, but we cannot rely on the LLM remembering —
    # and getting it wrong silently fragments the bundle. We run the
    # same AST partial-evaluator the resolver uses at runtime and
    # append any missing entries. Existing user declarations are
    # always preserved.
    if agent_path:
        try:
            entry_path = Path(agent_path).resolve()
            pr = project_root_from_agent_file(agent_path) or project_root()
            root = Path(pr).resolve()
            detected = _detect_entry_search_paths(entry_path, root)
        except Exception:
            detected = []

        if detected:
            declared = list(scope.get("search_paths") or [])
            declared_resolved = set()
            for raw in declared:
                cand = Path(raw)
                if not cand.is_absolute():
                    cand = root / cand
                try:
                    declared_resolved.add(cand.resolve())
                except OSError:
                    continue
            injected: list[str] = []
            for path in detected:
                if path in declared_resolved:
                    continue
                try:
                    rel = str(path.relative_to(root))
                except ValueError:
                    continue
                declared.append(rel)
                injected.append(rel)
            if injected:
                scope["search_paths"] = declared
                logger.info(
                    "spec_generator: injected scope.search_paths=%s from entry sys.path mutation",
                    injected,
                )

    if scope:
        spec["scope"] = scope

    if tool_config:
        spec["tool_config"] = tool_config
        spec["tool_usage_weight"] = tool_usage_weight

    if llm_judge_weight > 0:
        spec["llm_judge_weight"] = llm_judge_weight

    if consistency_rules:
        spec["consistency_rules"] = consistency_rules

    if policy_data:
        spec["policy"] = policy_data

    # set_tag("overmind.setup.spec", json.dumps(spec))
    return spec


def _generate_consistency_rules(
    output_schema: dict,
    output_fields: dict,
) -> list[dict]:
    """Auto-generate consistency rules from field relationships.

    Detects:
    - Number ordering pairs (field names containing min/max, low/high patterns)
    - Number-vs-enum correlations (with direction derived from enum ordering)
    """
    rules: list[dict] = []
    number_fields = [n for n, info in output_schema.items() if info.get("type") == "number"]
    enum_fields = [n for n, info in output_schema.items() if info.get("type") == "enum"]

    _ORDERING_PAIRS = [
        ("min", "max"),
        ("low", "high"),
        ("lower", "upper"),
        ("start", "end"),
        ("from", "to"),
    ]
    for lo_kw, hi_kw in _ORDERING_PAIRS:
        lo_matches = [n for n in number_fields if lo_kw in n.lower()]
        hi_matches = [n for n in number_fields if hi_kw in n.lower()]
        for lo_f in lo_matches:
            for hi_f in hi_matches:
                if lo_f != hi_f:
                    rules.append({
                        "field_a": lo_f,
                        "field_b": hi_f,
                        "type": "ordering",
                        "operator": "<=",
                        "penalty": 3.0,
                    })

    for nf in number_fields:
        for ef in enum_fields:
            rules.append({
                "field_a": nf,
                "field_b": ef,
                "type": "correlation",
                "penalty": 3.0,
            })

    return rules


def save_spec(spec: dict, path: str):
    """Write the evaluation spec to a JSON file."""
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(spec, f, indent=2)
