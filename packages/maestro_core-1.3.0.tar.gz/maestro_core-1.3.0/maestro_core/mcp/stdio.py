"""
Processus MCP stdio : spawn, JSON-RPC, gestion des outils.

Traduit depuis mcp_stdio.rs (2717 lignes).
Ce module fournit les types et la logique de communication JSON-RPC
avec les serveurs MCP via stdin/stdout.
"""
from __future__ import annotations
import asyncio
import json as _json
import subprocess
from dataclasses import dataclass, field
from typing import Any

@dataclass
class JsonRpcId:
    value: int | str | None = None

@dataclass
class JsonRpcRequest:
    jsonrpc: str = "2.0"
    id: JsonRpcId = field(default_factory=lambda: JsonRpcId(value=0))
    method: str = ""
    params: Any = None

@dataclass
class JsonRpcError:
    code: int = 0
    message: str = ""
    data: Any = None

@dataclass
class JsonRpcResponse:
    jsonrpc: str = "2.0"
    id: JsonRpcId = field(default_factory=lambda: JsonRpcId(value=0))
    result: Any = None
    error: JsonRpcError | None = None

@dataclass
class McpInitializeClientInfo:
    name: str = ""
    version: str = ""

@dataclass
class McpInitializeParams:
    protocol_version: str = ""
    capabilities: dict = field(default_factory=dict)
    client_info: McpInitializeClientInfo = field(default_factory=McpInitializeClientInfo)

@dataclass
class McpInitializeServerInfo:
    name: str = ""
    version: str = ""

@dataclass
class McpInitializeResult:
    protocol_version: str = ""
    capabilities: dict = field(default_factory=dict)
    server_info: McpInitializeServerInfo = field(default_factory=McpInitializeServerInfo)

@dataclass
class McpTool:
    name: str = ""
    description: str | None = None
    input_schema: Any = None
    annotations: Any = None
    meta: Any = None

@dataclass
class ManagedMcpTool:
    server_name: str = ""
    qualified_name: str = ""
    tool: McpTool = field(default_factory=McpTool)

@dataclass
class McpListToolsParams:
    cursor: str | None = None

@dataclass
class McpListToolsResult:
    tools: list[McpTool] = field(default_factory=list)
    next_cursor: str | None = None

@dataclass
class McpToolCallParams:
    name: str = ""
    arguments: Any = None
    meta: Any = None

@dataclass
class McpToolCallContent:
    kind: str = ""
    data: dict = field(default_factory=dict)

@dataclass
class McpToolCallResult:
    content: list[McpToolCallContent] = field(default_factory=list)
    structured_content: Any = None
    is_error: bool | None = None
    meta: Any = None

@dataclass
class McpResource:
    uri: str = ""
    name: str | None = None
    description: str | None = None
    mime_type: str | None = None

@dataclass
class McpResourceContents:
    uri: str = ""
    mime_type: str | None = None
    text: str | None = None

@dataclass
class McpListResourcesParams:
    cursor: str | None = None

@dataclass
class McpListResourcesResult:
    resources: list[McpResource] = field(default_factory=list)
    next_cursor: str | None = None

@dataclass
class McpReadResourceParams:
    uri: str = ""

@dataclass
class McpReadResourceResult:
    contents: list[McpResourceContents] = field(default_factory=list)

class McpDiscoveryFailure(Exception):
    pass

@dataclass
class McpToolDiscoveryReport:
    tools: list[ManagedMcpTool] = field(default_factory=list)
    unsupported: list[UnsupportedMcpServer] = field(default_factory=list)

@dataclass
class UnsupportedMcpServer:
    server_name: str = ""
    reason: str = ""

class McpServerManagerError(Exception):
    pass

class McpStdioProcess:
    """Processus MCP via stdin/stdout."""
    def __init__(self, command: str, args: list[str], env: dict[str, str] | None = None) -> None:
        self._command = command
        self._args = args
        self._env = env
        self._process: subprocess.Popen | None = None
        self._request_id = 0

    async def start(self) -> None:
        import os
        full_env = dict(os.environ)
        if self._env:
            full_env.update(self._env)
        self._process = subprocess.Popen(
            [self._command] + self._args,
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            env=full_env,
        )

    async def send_request(self, method: str, params: Any = None, timeout_seconds: float = 10) -> JsonRpcResponse:
        if not self._process or not self._process.stdin or not self._process.stdout:
            raise McpServerManagerError("process not started")
        self._request_id += 1
        request = {"jsonrpc": "2.0", "id": self._request_id, "method": method}
        if params is not None:
            request["params"] = params
        payload = _json.dumps(request).encode("utf-8")
        header = f"Content-Length: {len(payload)}\r\n\r\n".encode("utf-8")
        self._process.stdin.write(header + payload)
        self._process.stdin.flush()

        # Notifications (no id expected back) — don't wait for response
        if method.startswith("notifications/"):
            return JsonRpcResponse()

        # Lire la réponse avec timeout via select (wait once for first byte)
        import select
        ready, _, _ = select.select([self._process.stdout], [], [], timeout_seconds)
        if not ready:
            raise McpServerManagerError(f"timeout waiting for response to {method} after {timeout_seconds}s")
        response_header = b""
        while not response_header.endswith(b"\r\n\r\n"):
            byte = self._process.stdout.read(1)
            if not byte:
                raise McpServerManagerError("connection closed")
            response_header += byte
        content_length = 0
        for line in response_header.decode().split("\r\n"):
            if line.lower().startswith("content-length:"):
                content_length = int(line.split(":", 1)[1].strip())
        body = self._process.stdout.read(content_length)
        data = _json.loads(body.decode("utf-8"))
        error = None
        if "error" in data:
            e = data["error"]
            error = JsonRpcError(code=e.get("code", 0), message=e.get("message", ""), data=e.get("data"))
        return JsonRpcResponse(id=JsonRpcId(value=data.get("id")), result=data.get("result"), error=error)

    async def shutdown(self) -> None:
        if self._process:
            self._process.terminate()
            self._process.wait(timeout=5)


class McpServerManager:
    """Gestionnaire de serveurs MCP."""
    def __init__(self) -> None:
        self._processes: dict[str, McpStdioProcess] = {}
        self._tools: list[ManagedMcpTool] = []

    async def add_server(self, name: str, process: McpStdioProcess) -> None:
        self._processes[name] = process

    async def discover_tools(self) -> McpToolDiscoveryReport:
        report = McpToolDiscoveryReport()
        for name, proc in self._processes.items():
            try:
                response = await proc.send_request("tools/list", {"cursor": None})
                if response.result and "tools" in response.result:
                    for tool_data in response.result["tools"]:
                        tool = McpTool(name=tool_data.get("name", ""), description=tool_data.get("description"), input_schema=tool_data.get("inputSchema"))
                        from maestro_core.mcp.client import mcp_tool_name
                        managed = ManagedMcpTool(server_name=name, qualified_name=mcp_tool_name(name, tool.name), tool=tool)
                        report.tools.append(managed)
                        self._tools.append(managed)
            except Exception as e:
                report.unsupported.append(UnsupportedMcpServer(server_name=name, reason=str(e)))
        return report

    async def call_tool(self, qualified_name: str, arguments: Any = None) -> JsonRpcResponse:
        for managed in self._tools:
            if managed.qualified_name == qualified_name:
                proc = self._processes.get(managed.server_name)
                if proc:
                    return await proc.send_request("tools/call", {"name": managed.tool.name, "arguments": arguments})
        raise McpServerManagerError(f"tool not found: {qualified_name}")

    async def shutdown(self) -> None:
        for proc in self._processes.values():
            await proc.shutdown()
        self._processes.clear()


def spawn_mcp_stdio_process(command: str, args: list[str], env: dict[str, str] | None = None) -> McpStdioProcess:
    return McpStdioProcess(command, args, env)
