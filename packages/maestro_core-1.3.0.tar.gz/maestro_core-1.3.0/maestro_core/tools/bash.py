"""BashTool — executes shell commands with timeout and output truncation.

Integrates CC bash_validation pipeline (destructive pattern detection,
read-only enforcement, sed validation, path checks) and optional
sandbox isolation (Linux unshare namespace/network/filesystem).
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any

from maestro_core.tools.base import RiskLevel, Tool, ToolResult

# --- CC bash_validation wiring ---
from maestro_core.runtime.bash_validation import (
    validate_command,
    classify_command,
    CommandIntent,
    ValidationBlock,
    ValidationResult,
    ValidationWarn,
)
from maestro_core.runtime.permissions import PermissionMode

# --- CC sandbox wiring ---
from maestro_core.runtime.sandbox import (
    SandboxConfig,
    SandboxStatus,
    build_linux_sandbox_command,
    resolve_sandbox_status,
)

MAX_OUTPUT_CHARS = 10_000


class BashTool(Tool):
    name = "bash"
    description = (
        "Executes a shell command and returns stdout + stderr. "
        "Output is truncated to 10000 characters. "
        "Use timeout parameter to adjust the max execution time in milliseconds."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "command": {
                "type": "string",
                "description": "The shell command to execute.",
            },
            "timeout": {
                "type": "integer",
                "description": "Max execution time in milliseconds (default 120000).",
                "default": 120000,
            },
            "sandbox": {
                "type": "boolean",
                "description": "Run command in isolated sandbox (Linux only). Default: false.",
                "default": False,
            },
        },
        "required": ["command"],
    }
    risk_level = RiskLevel.MEDIUM

    def __init__(
        self,
        permission_mode: PermissionMode = PermissionMode.DANGER_FULL_ACCESS,
        workspace: Path | None = None,
        sandbox_config: SandboxConfig | None = None,
    ) -> None:
        self._permission_mode = permission_mode
        self._workspace = workspace or Path.cwd()
        self._sandbox_config = sandbox_config or SandboxConfig()

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        command = args["command"]
        timeout_ms = args.get("timeout", 120000)
        timeout_s = timeout_ms / 1000.0
        use_sandbox = args.get("sandbox", False)

        # --- CC bash_validation: full pipeline ---
        validation = validate_command(command, self._permission_mode, self._workspace)
        if isinstance(validation, ValidationBlock):
            return ToolResult(
                content=f"Command blocked: {validation.reason}",
                is_error=True,
                metadata={"blocked": True, "reason": validation.reason},
            )

        # Classify command intent for metadata
        intent = classify_command(command)

        # Warn but allow (log the warning in metadata)
        warn_message = None
        if isinstance(validation, ValidationWarn):
            warn_message = validation.message

        # --- CC sandbox: optional isolated execution ---
        actual_command = command
        sandbox_env: dict[str, str] | None = None
        if use_sandbox:
            status = resolve_sandbox_status(self._sandbox_config, self._workspace)
            sandbox_cmd = build_linux_sandbox_command(command, self._workspace, status)
            if sandbox_cmd is not None:
                actual_command = f"{sandbox_cmd.program} {' '.join(sandbox_cmd.args)}"
                sandbox_env = {k: v for k, v in sandbox_cmd.env}

        try:
            env = None
            if sandbox_env:
                import os
                env = {**os.environ, **sandbox_env}

            proc = await asyncio.create_subprocess_shell(
                actual_command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=env,
            )
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=timeout_s
            )
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            return ToolResult(
                content=f"Command timed out after {timeout_ms}ms",
                is_error=True,
                metadata={"timeout": True},
            )
        except Exception as e:
            return ToolResult(content=f"Failed to execute command: {e}", is_error=True)

        output_parts: list[str] = []
        if stdout:
            output_parts.append(stdout.decode("utf-8", errors="replace"))
        if stderr:
            output_parts.append(stderr.decode("utf-8", errors="replace"))

        output = "\n".join(output_parts)

        truncated = False
        if len(output) > MAX_OUTPUT_CHARS:
            output = output[:MAX_OUTPUT_CHARS] + "\n... (output truncated)"
            truncated = True

        metadata: dict[str, Any] = {
            "exit_code": proc.returncode,
            "truncated": truncated,
            "intent": intent.value,
        }
        if warn_message:
            metadata["warning"] = warn_message
        if use_sandbox:
            metadata["sandbox"] = True

        return ToolResult(
            content=output if output else "(no output)",
            is_error=proc.returncode != 0,
            metadata=metadata,
        )
