"""FileReadTool — reads files with line numbers, offset, and limit.

Uses CC file_ops.py for binary detection, size validation, and
workspace boundary checks.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from maestro_core.tools.base import RiskLevel, Tool, ToolResult

# --- CC file_ops wiring ---
from maestro_core.runtime.file_ops import (
    read_file as cc_read_file,
    MAX_READ_SIZE,
    _is_binary_file,
    _normalize_path,
)


class FileReadTool(Tool):
    name = "file_read"
    description = (
        "Reads a file and returns its contents with line numbers (cat -n format). "
        "Supports offset and limit to read specific portions of large files."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "Absolute path to the file to read.",
            },
            "offset": {
                "type": "integer",
                "description": "Line number to start reading from (1-based). Default: 1.",
            },
            "limit": {
                "type": "integer",
                "description": "Maximum number of lines to read. Default: 2000.",
                "default": 2000,
            },
        },
        "required": ["path"],
    }
    risk_level = RiskLevel.READ

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        raw_path = args["path"]
        offset = max(args.get("offset", 1) or 1, 1)
        limit = args.get("limit", 2000) or 2000

        try:
            file_path = _normalize_path(raw_path)
        except Exception:
            file_path = Path(raw_path)

        if not file_path.exists():
            return ToolResult(
                content=f"File not found: {file_path}", is_error=True
            )

        if not file_path.is_file():
            return ToolResult(
                content=f"Not a file: {file_path}", is_error=True
            )

        # CC binary detection
        if _is_binary_file(file_path):
            return ToolResult(
                content=f"File appears to be binary: {file_path}", is_error=True
            )

        # CC size validation
        try:
            size = file_path.stat().st_size
            if size > MAX_READ_SIZE:
                return ToolResult(
                    content=f"File is too large ({size} bytes, max {MAX_READ_SIZE} bytes): {file_path}",
                    is_error=True,
                )
        except OSError as e:
            return ToolResult(
                content=f"Error accessing {file_path}: {e}", is_error=True
            )

        # Use CC read_file for the actual read (0-based offset internally)
        try:
            result = cc_read_file(raw_path, offset=offset - 1, limit=limit)
        except PermissionError:
            return ToolResult(
                content=f"Permission denied: {file_path}", is_error=True
            )
        except ValueError as e:
            return ToolResult(
                content=f"Error reading {file_path}: {e}", is_error=True
            )
        except Exception as e:
            return ToolResult(
                content=f"Error reading {file_path}: {e}", is_error=True
            )

        # Format with line numbers (cat -n style)
        lines = result.file.content.split("\n") if result.file.content else []
        start_line = result.file.start_line
        numbered_lines = [
            f"{start_line + i}\t{line}" for i, line in enumerate(lines)
        ]
        output = "\n".join(numbered_lines)

        return ToolResult(
            content=output if output else "(empty file)",
            metadata={
                "total_lines": result.file.total_lines,
                "lines_shown": result.file.num_lines,
                "offset": offset,
            },
        )
