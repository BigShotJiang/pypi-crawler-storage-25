"""Maestro tool framework — shared between CLI and OKE cloud.

Exports:
- Base classes: Tool, ToolRegistry, ToolResult, ToolDefinition, RiskLevel
- Tool implementations: BashTool, FileReadTool, FileWriteTool, FileEditTool,
  GrepTool, GlobTool, NotebookEditTool, TodoWriteTool, WebFetchTool, MCPBridgeTool
- Spec system: ToolSpec, PermissionMode, GlobalToolRegistry, mvp_tool_specs
- Execution: execute_tool_dispatch
"""

# --- Base framework ---
from maestro_core.tools.base import Tool, ToolRegistry, ToolResult, ToolDefinition, RiskLevel

# --- Concrete tool implementations (async) ---
from maestro_core.tools.bash import BashTool
from maestro_core.tools.file_read import FileReadTool
from maestro_core.tools.file_write import FileWriteTool
from maestro_core.tools.file_edit import FileEditTool
from maestro_core.tools.grep import GrepTool
from maestro_core.tools.glob_tool import GlobTool
from maestro_core.tools.notebook_edit import NotebookEditTool
from maestro_core.tools.todo_write import TodoWriteTool
from maestro_core.tools.web_fetch import WebFetchTool
from maestro_core.tools.mcp_bridge import MCPBridgeTool
from maestro_core.tools.git_tools import GitStatusTool, GitDiffTool, GitLogTool, GitCleanupTool
from maestro_core.tools.code_intel import CodeIntelTool

# --- Spec system (JSON schemas + registry from CC Rust harness) ---
from maestro_core.tools.specs import ToolSpec, PermissionMode
from maestro_core.tools.registry import (
    GlobalToolRegistry,
    RuntimeToolDefinition,
    ToolManifestEntry,
    ToolSearchOutput,
    ToolSource,
    mvp_tool_specs,
    execute_tool,
)

# --- Synchronous execution dispatch ---
from maestro_core.tools.execution import execute_tool_dispatch

# Re-export build_tool_backlog from the standalone tools.py
# (tools.py is shadowed by this package, so query_engine needs it here)
def build_tool_backlog():
    """Proxy to the standalone tools.py build_tool_backlog."""
    import sys
    import importlib.util
    _standalone_path = str(__import__("pathlib").Path(__file__).resolve().parent.parent / "tools.py")
    if "maestro_core._tools_standalone" not in sys.modules:
        spec = importlib.util.spec_from_file_location("maestro_core._tools_standalone", _standalone_path)
        if spec and spec.loader:
            mod = importlib.util.module_from_spec(spec)
            sys.modules["maestro_core._tools_standalone"] = mod
            spec.loader.exec_module(mod)
    return sys.modules["maestro_core._tools_standalone"].build_tool_backlog()


__all__ = [
    # Base
    "Tool",
    "ToolRegistry",
    "ToolResult",
    "ToolDefinition",
    "RiskLevel",
    # Tool implementations
    "BashTool",
    "FileReadTool",
    "FileWriteTool",
    "FileEditTool",
    "GrepTool",
    "GlobTool",
    "NotebookEditTool",
    "TodoWriteTool",
    "WebFetchTool",
    "MCPBridgeTool",
    "GitStatusTool",
    "GitDiffTool",
    "GitLogTool",
    "GitCleanupTool",
    "CodeIntelTool",
    # Spec system
    "ToolSpec",
    "PermissionMode",
    "GlobalToolRegistry",
    "RuntimeToolDefinition",
    "ToolManifestEntry",
    "ToolSearchOutput",
    "ToolSource",
    "mvp_tool_specs",
    "execute_tool",
    # Execution
    "execute_tool_dispatch",
]
