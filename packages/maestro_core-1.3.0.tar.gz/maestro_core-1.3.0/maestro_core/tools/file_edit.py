"""FileEditTool — edits files with search/replace.

Uses CC file_ops.py for structured patch generation, path normalization,
and atomic file operations.
"""

from __future__ import annotations

import difflib
from pathlib import Path
from typing import Any

from maestro_core.tools.base import RiskLevel, Tool, ToolResult

# --- CC file_ops wiring ---
from maestro_core.runtime.file_ops import (
    edit_file as cc_edit_file,
    _normalize_path,
)


class FileEditTool(Tool):
    name = "file_edit"
    description = (
        "Edits a file by replacing an exact string with a new string. "
        "When replace_all is false (default), the old_string must appear exactly once. "
        "When replace_all is true, all occurrences are replaced."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "Absolute path to the file to edit.",
            },
            "old_string": {
                "type": "string",
                "description": "The exact string to find and replace.",
            },
            "new_string": {
                "type": "string",
                "description": "The replacement string.",
            },
            "replace_all": {
                "type": "boolean",
                "description": "Replace all occurrences (default: false).",
                "default": False,
            },
        },
        "required": ["path", "old_string", "new_string"],
    }
    risk_level = RiskLevel.LOW

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        raw_path = args["path"]
        old_string = args["old_string"]
        new_string = args["new_string"]
        replace_all = args.get("replace_all", False)

        try:
            file_path = _normalize_path(raw_path)
        except Exception:
            file_path = Path(raw_path)

        if not file_path.exists():
            return ToolResult(
                content=f"File not found: {file_path}", is_error=True
            )

        if not file_path.is_file():
            return ToolResult(
                content=f"Not a file: {file_path}", is_error=True
            )

        # Pre-check: count occurrences for better error messages
        try:
            content = file_path.read_text(encoding="utf-8")
        except Exception as e:
            return ToolResult(
                content=f"Error reading {file_path}: {e}", is_error=True
            )

        occurrences = content.count(old_string)

        if occurrences == 0:
            return ToolResult(
                content=f"old_string not found in {file_path}",
                is_error=True,
            )

        if not replace_all and occurrences > 1:
            return ToolResult(
                content=(
                    f"old_string found {occurrences} times in {file_path}. "
                    "Use replace_all=true to replace all, or provide a more specific string."
                ),
                is_error=True,
            )

        # Use CC edit_file for the actual edit (atomic operation + structured patch)
        try:
            result = cc_edit_file(raw_path, old_string, new_string, replace_all)
        except ValueError as e:
            return ToolResult(
                content=f"Edit error: {e}", is_error=True
            )
        except FileNotFoundError as e:
            return ToolResult(
                content=f"old_string not found in {file_path}", is_error=True
            )
        except Exception as e:
            return ToolResult(
                content=f"Error writing {file_path}: {e}", is_error=True
            )

        # Generate a unified diff for display
        old_lines = result.original_file.splitlines(keepends=True)
        new_content = file_path.read_text(encoding="utf-8")
        new_lines = new_content.splitlines(keepends=True)
        diff = difflib.unified_diff(
            old_lines,
            new_lines,
            fromfile=f"a/{file_path.name}",
            tofile=f"b/{file_path.name}",
            lineterm="",
        )
        diff_text = "\n".join(diff)

        count = occurrences if replace_all else 1
        return ToolResult(
            content=f"Edited {result.file_path}: replaced {count} occurrence(s)\n\n```diff\n{diff_text}\n```",
            metadata={
                "diff": diff_text,
                "path": result.file_path,
                "replacements": count,
                "patch_hunks": len(result.structured_patch),
            },
        )
