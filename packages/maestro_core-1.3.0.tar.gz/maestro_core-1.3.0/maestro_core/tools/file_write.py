"""FileWriteTool — writes or creates files, creating parent directories as needed.

Uses CC file_ops.py for size validation, structured patch generation,
and path normalization.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from maestro_core.tools.base import RiskLevel, Tool, ToolResult

# --- CC file_ops wiring ---
from maestro_core.runtime.file_ops import (
    write_file as cc_write_file,
    MAX_WRITE_SIZE,
)


class FileWriteTool(Tool):
    name = "file_write"
    description = (
        "Writes content to a file. Creates parent directories if they don't exist. "
        "Overwrites the file if it already exists."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "Absolute path to the file to write.",
            },
            "content": {
                "type": "string",
                "description": "Content to write to the file.",
            },
        },
        "required": ["path", "content"],
    }
    risk_level = RiskLevel.LOW

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        raw_path = args["path"]
        content = args["content"]

        # CC size validation
        if len(content) > MAX_WRITE_SIZE:
            return ToolResult(
                content=f"Content is too large ({len(content)} bytes, max {MAX_WRITE_SIZE} bytes)",
                is_error=True,
            )

        try:
            result = cc_write_file(raw_path, content)
        except PermissionError:
            return ToolResult(
                content=f"Permission denied: {raw_path}", is_error=True
            )
        except ValueError as e:
            return ToolResult(
                content=f"Error writing {raw_path}: {e}", is_error=True
            )
        except Exception as e:
            return ToolResult(
                content=f"Error writing {raw_path}: {e}", is_error=True
            )

        preview = content[:500] + ("..." if len(content) > 500 else "")
        kind = result.kind  # "create" or "update"
        return ToolResult(
            content=f"{'Created' if kind == 'create' else 'Updated'} {result.file_path} ({len(content)} bytes)\n\n```\n{preview}\n```",
            metadata={
                "bytes_written": len(content.encode("utf-8")),
                "path": result.file_path,
                "kind": kind,
                "patch_hunks": len(result.structured_patch),
            },
        )
