"""Git tools — provide git context to the LLM.

Integrates CC stale_branch.py for branch freshness detection,
stale branch cleanup suggestions, and policy enforcement.
"""

from __future__ import annotations

import subprocess
from pathlib import Path
from typing import Any

from maestro_core.tools.base import RiskLevel, Tool, ToolResult

# --- CC stale_branch wiring ---
from maestro_core.runtime.stale_branch import (
    check_freshness,
    apply_policy,
    BranchFresh,
    BranchStale,
    BranchDiverged,
    StaleBranchPolicy,
    StaleBranchWarn,
    StaleBranchBlock,
    StaleBranchRebase,
    StaleBranchMergeForward,
    StaleBranchNoop,
)


class GitStatusTool(Tool):
    name = "git_status"
    description = "Shows the current git status (branch, staged, unstaged, untracked files)"
    input_schema: dict[str, Any] = {"type": "object", "properties": {}, "required": []}
    risk_level = RiskLevel.READ

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        try:
            result = subprocess.run(
                ["git", "status", "--porcelain", "-b"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode != 0:
                return ToolResult(
                    content=f"git status failed: {result.stderr.strip()}",
                    is_error=True,
                )

            lines = result.stdout.strip().splitlines()
            if not lines:
                return ToolResult(content="Not a git repository or empty output.")

            # Parse branch line
            branch_line = lines[0] if lines[0].startswith("## ") else ""
            file_lines = [l for l in lines if not l.startswith("## ")]

            staged = []
            unstaged = []
            untracked = []

            for line in file_lines:
                if len(line) < 2:
                    continue
                idx_status = line[0]
                wt_status = line[1]
                filename = line[3:]

                if idx_status == "?" and wt_status == "?":
                    untracked.append(filename)
                else:
                    if idx_status not in (" ", "?"):
                        staged.append(f"{idx_status} {filename}")
                    if wt_status not in (" ", "?"):
                        unstaged.append(f"{wt_status} {filename}")

            parts = []
            if branch_line:
                parts.append(f"Branch: {branch_line[3:]}")
            if staged:
                parts.append(f"\nStaged ({len(staged)}):")
                parts.extend(f"  {s}" for s in staged)
            if unstaged:
                parts.append(f"\nUnstaged ({len(unstaged)}):")
                parts.extend(f"  {u}" for u in unstaged)
            if untracked:
                parts.append(f"\nUntracked ({len(untracked)}):")
                parts.extend(f"  {u}" for u in untracked)
            if not staged and not unstaged and not untracked:
                parts.append("Working tree clean.")

            return ToolResult(content="\n".join(parts))

        except FileNotFoundError:
            return ToolResult(content="git not found in PATH.", is_error=True)
        except subprocess.TimeoutExpired:
            return ToolResult(content="git status timed out.", is_error=True)
        except Exception as e:
            return ToolResult(content=f"Error: {e}", is_error=True)


class GitDiffTool(Tool):
    name = "git_diff"
    description = "Shows git diff of staged or unstaged changes"
    input_schema: dict[str, Any] = {
        "type": "object",
        "properties": {
            "staged": {
                "type": "boolean",
                "description": "Show staged changes (--cached)",
                "default": False,
            },
            "file": {
                "type": "string",
                "description": "Specific file to diff (optional)",
            },
        },
    }
    risk_level = RiskLevel.READ

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        try:
            cmd = ["git", "diff"]
            if args.get("staged", False):
                cmd.append("--cached")
            if args.get("file"):
                cmd.append("--")
                cmd.append(args["file"])

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=15,
            )
            if result.returncode != 0:
                return ToolResult(
                    content=f"git diff failed: {result.stderr.strip()}",
                    is_error=True,
                )

            output = result.stdout.strip()
            if not output:
                label = "staged" if args.get("staged") else "unstaged"
                return ToolResult(content=f"No {label} changes.")

            # Truncate if very large
            if len(output) > 20_000:
                output = output[:20_000] + "\n\n... (truncated, diff too large)"

            return ToolResult(content=output)

        except FileNotFoundError:
            return ToolResult(content="git not found in PATH.", is_error=True)
        except subprocess.TimeoutExpired:
            return ToolResult(content="git diff timed out.", is_error=True)
        except Exception as e:
            return ToolResult(content=f"Error: {e}", is_error=True)


class GitLogTool(Tool):
    name = "git_log"
    description = "Shows recent git commit history"
    input_schema: dict[str, Any] = {
        "type": "object",
        "properties": {
            "count": {
                "type": "integer",
                "description": "Number of commits to show",
                "default": 10,
            },
            "oneline": {
                "type": "boolean",
                "description": "One line per commit",
                "default": True,
            },
        },
    }
    risk_level = RiskLevel.READ

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        try:
            count = args.get("count", 10)
            oneline = args.get("oneline", True)

            cmd = ["git", "log", f"-{count}"]
            if oneline:
                cmd.append("--oneline")
            else:
                cmd.extend(["--format=%h %s (%an, %ar)"])

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode != 0:
                return ToolResult(
                    content=f"git log failed: {result.stderr.strip()}",
                    is_error=True,
                )

            output = result.stdout.strip()
            if not output:
                return ToolResult(content="No commits found.")

            return ToolResult(content=output)

        except FileNotFoundError:
            return ToolResult(content="git not found in PATH.", is_error=True)
        except subprocess.TimeoutExpired:
            return ToolResult(content="git log timed out.", is_error=True)
        except Exception as e:
            return ToolResult(content=f"Error: {e}", is_error=True)


class GitAddTool(Tool):
    name = "git_add"
    description = "Stage files for the next git commit"
    input_schema: dict[str, Any] = {
        "type": "object",
        "properties": {
            "files": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Files to stage. Use ['.'] to stage all changes.",
            },
        },
        "required": ["files"],
    }
    risk_level = RiskLevel.MEDIUM

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        files = args.get("files", [])
        if not files:
            return ToolResult(content="No files specified.", is_error=True)

        try:
            cmd = ["git", "add"] + files
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=15,
            )
            if result.returncode != 0:
                return ToolResult(
                    content=f"git add failed: {result.stderr.strip()}",
                    is_error=True,
                )

            # Show what was staged
            status = subprocess.run(
                ["git", "status", "--porcelain"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            staged = [
                l[3:] for l in status.stdout.strip().splitlines()
                if len(l) >= 2 and l[0] not in (" ", "?")
            ]
            return ToolResult(
                content=f"Staged {len(staged)} file(s):\n" + "\n".join(f"  {f}" for f in staged),
            )

        except FileNotFoundError:
            return ToolResult(content="git not found in PATH.", is_error=True)
        except subprocess.TimeoutExpired:
            return ToolResult(content="git add timed out.", is_error=True)
        except Exception as e:
            return ToolResult(content=f"Error: {e}", is_error=True)


class GitCommitTool(Tool):
    name = "git_commit"
    description = "Create a git commit with staged changes"
    input_schema: dict[str, Any] = {
        "type": "object",
        "properties": {
            "message": {
                "type": "string",
                "description": "Commit message",
            },
            "files": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Files to stage before committing (optional, commits staged changes if empty)",
            },
        },
        "required": ["message"],
    }
    risk_level = RiskLevel.MEDIUM

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        message = args.get("message", "")
        files = args.get("files", [])

        if not message.strip():
            return ToolResult(content="Commit message cannot be empty.", is_error=True)

        try:
            # Stage files if specified
            if files:
                for f in files:
                    result = subprocess.run(
                        ["git", "add", f],
                        capture_output=True,
                        text=True,
                        timeout=10,
                    )
                    if result.returncode != 0:
                        return ToolResult(
                            content=f"git add {f} failed: {result.stderr.strip()}",
                            is_error=True,
                        )

            # Commit
            result = subprocess.run(
                ["git", "commit", "-m", message],
                capture_output=True,
                text=True,
                timeout=30,
            )

            if result.returncode != 0:
                return ToolResult(
                    content=f"git commit failed: {result.stderr.strip()}",
                    is_error=True,
                )

            return ToolResult(content=result.stdout.strip())

        except FileNotFoundError:
            return ToolResult(content="git not found in PATH.", is_error=True)
        except subprocess.TimeoutExpired:
            return ToolResult(content="git commit timed out.", is_error=True)
        except Exception as e:
            return ToolResult(content=f"Error: {e}", is_error=True)


class GitCleanupTool(Tool):
    """Detects stale branches and suggests cleanup using CC stale_branch module."""

    name = "git_cleanup"
    description = (
        "Detects stale git branches behind main and suggests cleanup actions. "
        "Uses CC stale branch detection with configurable policy "
        "(warn_only, block, auto_rebase, auto_merge_forward)."
    )
    input_schema: dict[str, Any] = {
        "type": "object",
        "properties": {
            "main_ref": {
                "type": "string",
                "description": "Main branch reference (default: 'main').",
                "default": "main",
            },
            "policy": {
                "type": "string",
                "description": "Policy to apply: warn_only, block, auto_rebase, auto_merge_forward.",
                "default": "warn_only",
                "enum": ["warn_only", "block", "auto_rebase", "auto_merge_forward"],
            },
        },
    }
    risk_level = RiskLevel.READ

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        main_ref = args.get("main_ref", "main")
        policy_str = args.get("policy", "warn_only")

        policy_map = {
            "warn_only": StaleBranchPolicy.WARN_ONLY,
            "block": StaleBranchPolicy.BLOCK,
            "auto_rebase": StaleBranchPolicy.AUTO_REBASE,
            "auto_merge_forward": StaleBranchPolicy.AUTO_MERGE_FORWARD,
        }
        policy = policy_map.get(policy_str, StaleBranchPolicy.WARN_ONLY)

        try:
            # List all local branches
            result = subprocess.run(
                ["git", "branch", "--format=%(refname:short)"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode != 0:
                return ToolResult(
                    content=f"git branch failed: {result.stderr.strip()}",
                    is_error=True,
                )

            branches = [b.strip() for b in result.stdout.strip().splitlines() if b.strip()]
            repo_path = Path.cwd()

            report_lines: list[str] = []
            stale_count = 0

            for branch in branches:
                if branch == main_ref:
                    continue

                freshness = check_freshness(branch, main_ref, repo_path)
                action = apply_policy(freshness, policy)

                if isinstance(freshness, BranchFresh):
                    continue  # Skip fresh branches

                stale_count += 1
                if isinstance(freshness, BranchStale):
                    report_lines.append(
                        f"  {branch}: {freshness.commits_behind} commit(s) behind"
                    )
                    if freshness.missing_fixes:
                        for fix in freshness.missing_fixes[:3]:
                            report_lines.append(f"    - {fix}")
                elif isinstance(freshness, BranchDiverged):
                    report_lines.append(
                        f"  {branch}: diverged ({freshness.ahead} ahead, {freshness.behind} behind)"
                    )

                if isinstance(action, StaleBranchWarn):
                    report_lines.append(f"    Action: {action.message}")
                elif isinstance(action, StaleBranchBlock):
                    report_lines.append(f"    BLOCKED: {action.message}")
                elif isinstance(action, StaleBranchRebase):
                    report_lines.append("    Suggested: rebase onto main")
                elif isinstance(action, StaleBranchMergeForward):
                    report_lines.append("    Suggested: merge main forward")

            if stale_count == 0:
                return ToolResult(
                    content=f"All {len(branches)} branches are up to date with {main_ref}.",
                    metadata={"stale_count": 0, "total_branches": len(branches)},
                )

            header = f"Found {stale_count} stale branch(es) (of {len(branches)} total):\n"
            return ToolResult(
                content=header + "\n".join(report_lines),
                metadata={"stale_count": stale_count, "total_branches": len(branches)},
            )

        except FileNotFoundError:
            return ToolResult(content="git not found in PATH.", is_error=True)
        except subprocess.TimeoutExpired:
            return ToolResult(content="git branch timed out.", is_error=True)
        except Exception as e:
            return ToolResult(content=f"Error: {e}", is_error=True)
