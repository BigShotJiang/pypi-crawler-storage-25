"""Team coordination tools — the real CC team/task/worker system.

Wires TaskRegistry, TeamRegistry into proper Tool classes that spawn
sub-agents (ConversationEngine) for background and parallel execution.
"""
from __future__ import annotations

import asyncio
import json
import time
import threading
from concurrent.futures import ThreadPoolExecutor, Future
from typing import Any, Optional

from maestro_core.tools.base import Tool, ToolResult, ToolRegistry, RiskLevel
from maestro_core.runtime.task_registry import TaskRegistry, TaskStatus, Task
from maestro_core.runtime.team_cron_registry import TeamRegistry, TeamStatus, CronRegistry


def _json(obj: Any) -> str:
    return json.dumps(obj, indent=2, ensure_ascii=False, default=str)


def _task_to_dict(task: Task) -> dict[str, Any]:
    return {
        "task_id": task.task_id,
        "prompt": task.prompt[:120] + ("..." if len(task.prompt) > 120 else ""),
        "description": task.description,
        "status": task.status.value,
        "team_id": task.team_id,
        "messages": len(task.messages),
        "output_length": len(task.output),
        "created_at": task.created_at,
        "updated_at": task.updated_at,
    }


# ── Shared executor for background tasks ──

_background_executor = ThreadPoolExecutor(max_workers=8, thread_name_prefix="maestro-task")
_running_futures: dict[str, Future] = {}


def _run_sub_agent_sync(
    router,
    tools: Optional[ToolRegistry],
    system_prompt: str,
    model: str,
    prompt: str,
    task_registry: TaskRegistry,
    task_id: str,
) -> str:
    """Run a ConversationEngine synchronously in a thread, updating the task registry."""
    from maestro_core.engine import ConversationEngine

    # Create a sub-registry without recursive tools
    sub_tools = ToolRegistry()
    if tools:
        for name, tool in tools.tools.items():
            if name not in ("agent", "team", "task_create", "team_create"):
                sub_tools.register(tool)

    # Each thread needs its own ProviderRouter to avoid sharing httpx clients
    from maestro_core.provider_router import ProviderRouter
    thread_router = ProviderRouter(
        router._config,
        routing_mode=router._routing_mode,
        trust_mode=router._trust_mode,
    )

    engine = ConversationEngine(
        router=thread_router,
        tools=sub_tools,
        max_tokens=4096,
        max_turns=15,
    )

    task_registry.set_status(task_id, TaskStatus.RUNNING)

    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            result = loop.run_until_complete(
                engine.run_turn(
                    user_text=prompt,
                    system_prompt=system_prompt,
                    model=model,
                )
            )
            # Close thread-local router
            loop.run_until_complete(thread_router.close())
        finally:
            loop.close()

        response = result.response_text or "<no response>"
        task_registry.append_output(task_id, response)
        task_registry.set_status(task_id, TaskStatus.COMPLETED)
        return response

    except Exception as e:
        error_msg = f"Error: {e}"
        task_registry.append_output(task_id, error_msg)
        task_registry.set_status(task_id, TaskStatus.FAILED)
        return error_msg


# ── Task Tools ──


class TaskCreateTool(Tool):
    """Create a background task that runs a sub-agent asynchronously."""

    name = "task_create"
    description = (
        "Create a background task that runs in a separate thread with its own sub-agent. "
        "Returns immediately with a task_id. Use task_get/task_output to check progress."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "prompt": {"type": "string", "description": "The task prompt for the sub-agent"},
            "description": {"type": "string", "description": "Short description of the task"},
        },
        "required": ["prompt"],
    }
    risk_level = RiskLevel.MEDIUM

    def __init__(
        self,
        task_registry: TaskRegistry,
        parent_router=None,
        parent_tools: Optional[ToolRegistry] = None,
        system_prompt: str = "",
        model: str = "",
    ):
        self._task_registry = task_registry
        self._router = parent_router
        self._tools = parent_tools
        self._system_prompt = system_prompt
        self._model = model

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        prompt = args.get("prompt", "")
        description = args.get("description")

        if not prompt:
            return ToolResult(content="prompt is required", is_error=True)
        if not self._router:
            return ToolResult(content="TaskCreate not configured (no router)", is_error=True)

        task = self._task_registry.create(prompt=prompt, description=description)

        future = _background_executor.submit(
            _run_sub_agent_sync,
            self._router,
            self._tools,
            self._system_prompt,
            self._model,
            prompt,
            self._task_registry,
            task.task_id,
        )
        _running_futures[task.task_id] = future

        return ToolResult(
            content=_json({
                "task_id": task.task_id,
                "status": "created",
                "description": description,
                "message": "Task created and running in background. Use task_get to check status.",
            })
        )


class TaskListTool(Tool):
    """List all tasks with their status."""

    name = "task_list"
    description = "List all background tasks and their current status."
    input_schema = {
        "type": "object",
        "properties": {
            "status": {
                "type": "string",
                "enum": ["created", "running", "completed", "failed", "stopped"],
                "description": "Filter by status (optional)",
            },
        },
        "additionalProperties": False,
    }
    risk_level = RiskLevel.READ

    def __init__(self, task_registry: TaskRegistry):
        self._task_registry = task_registry

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        status_filter = None
        if args.get("status"):
            try:
                status_filter = TaskStatus(args["status"])
            except ValueError:
                return ToolResult(content=f"Invalid status: {args['status']}", is_error=True)

        tasks = self._task_registry.list(status_filter=status_filter)
        if not tasks:
            return ToolResult(content=_json({"tasks": [], "count": 0, "message": "No tasks found."}))

        return ToolResult(content=_json({
            "tasks": [_task_to_dict(t) for t in tasks],
            "count": len(tasks),
        }))


class TaskGetTool(Tool):
    """Get details of a specific task."""

    name = "task_get"
    description = "Get the status, details, and output of a background task by ID."
    input_schema = {
        "type": "object",
        "properties": {
            "task_id": {"type": "string"},
        },
        "required": ["task_id"],
    }
    risk_level = RiskLevel.READ

    def __init__(self, task_registry: TaskRegistry):
        self._task_registry = task_registry

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        task_id = args.get("task_id", "")
        task = self._task_registry.get(task_id)
        if not task:
            return ToolResult(content=f"Task not found: {task_id}", is_error=True)

        info = _task_to_dict(task)
        # Include full output for task_get
        info["output"] = task.output if task.output else "<no output yet>"
        info["messages"] = [
            {"role": m.role, "content": m.content[:200], "timestamp": m.timestamp}
            for m in task.messages
        ]

        return ToolResult(content=_json(info))


class TaskStopTool(Tool):
    """Stop a running task."""

    name = "task_stop"
    description = "Stop a running background task by ID."
    input_schema = {
        "type": "object",
        "properties": {
            "task_id": {"type": "string"},
        },
        "required": ["task_id"],
    }
    risk_level = RiskLevel.MEDIUM

    def __init__(self, task_registry: TaskRegistry):
        self._task_registry = task_registry

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        task_id = args.get("task_id", "")
        try:
            task = self._task_registry.stop(task_id)
        except ValueError as e:
            return ToolResult(content=str(e), is_error=True)

        # Cancel the background future if still running
        future = _running_futures.pop(task_id, None)
        if future and not future.done():
            future.cancel()

        return ToolResult(content=_json({
            "task_id": task.task_id,
            "status": task.status.value,
            "message": "Task stopped.",
        }))


class TaskUpdateTool(Tool):
    """Send a message to a running task."""

    name = "task_update"
    description = "Send a message or update to a running background task."
    input_schema = {
        "type": "object",
        "properties": {
            "task_id": {"type": "string"},
            "message": {"type": "string"},
        },
        "required": ["task_id", "message"],
    }
    risk_level = RiskLevel.MEDIUM

    def __init__(self, task_registry: TaskRegistry):
        self._task_registry = task_registry

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        task_id = args.get("task_id", "")
        message = args.get("message", "")
        try:
            task = self._task_registry.update(task_id, message)
        except ValueError as e:
            return ToolResult(content=str(e), is_error=True)

        return ToolResult(content=_json({
            "task_id": task.task_id,
            "status": task.status.value,
            "message_count": len(task.messages),
        }))


class TaskOutputTool(Tool):
    """Read the output of a task."""

    name = "task_output"
    description = "Retrieve the output produced by a background task."
    input_schema = {
        "type": "object",
        "properties": {
            "task_id": {"type": "string"},
        },
        "required": ["task_id"],
    }
    risk_level = RiskLevel.READ

    def __init__(self, task_registry: TaskRegistry):
        self._task_registry = task_registry

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        task_id = args.get("task_id", "")
        try:
            output = self._task_registry.output(task_id)
        except ValueError as e:
            return ToolResult(content=str(e), is_error=True)

        task = self._task_registry.get(task_id)
        return ToolResult(content=_json({
            "task_id": task_id,
            "status": task.status.value if task else "unknown",
            "output": output if output else "<no output yet>",
        }))


# ── Team Tools ──


class TeamCreateTool(Tool):
    """Create a team of sub-agents for parallel task execution.

    This is the KEY coordination tool. It:
    1. Creates a Team in the TeamRegistry
    2. Creates a Task in the TaskRegistry for each sub-task
    3. Spawns a ConversationEngine for each task
    4. Runs them concurrently via ThreadPoolExecutor
    5. Collects results, updates statuses
    6. Returns a combined report
    """

    name = "team_create"
    description = (
        "Create a team of sub-agents for parallel task execution. "
        "Each task gets its own sub-agent running concurrently. "
        "Returns when all tasks complete with a combined report."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "name": {"type": "string", "description": "Team name"},
            "tasks": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "prompt": {"type": "string"},
                        "description": {"type": "string"},
                    },
                    "required": ["prompt"],
                },
                "description": "List of tasks to run in parallel",
            },
        },
        "required": ["name", "tasks"],
    }
    risk_level = RiskLevel.MEDIUM

    def __init__(
        self,
        task_registry: TaskRegistry,
        team_registry: TeamRegistry,
        parent_router=None,
        parent_tools: Optional[ToolRegistry] = None,
        system_prompt: str = "",
        model: str = "",
    ):
        self._task_registry = task_registry
        self._team_registry = team_registry
        self._router = parent_router
        self._tools = parent_tools
        self._system_prompt = system_prompt
        self._model = model

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        team_name = args.get("name", "unnamed")
        tasks_input = args.get("tasks", [])

        if not tasks_input:
            return ToolResult(content="tasks list is required and must not be empty", is_error=True)
        if not self._router:
            return ToolResult(content="TeamCreate not configured (no router)", is_error=True)

        # 1. Create tasks in the registry
        task_ids: list[str] = []
        for t in tasks_input:
            task = self._task_registry.create(
                prompt=t["prompt"],
                description=t.get("description"),
            )
            task_ids.append(task.task_id)

        # 2. Create team in the registry
        team = self._team_registry.create(name=team_name, task_ids=task_ids)

        # 3. Assign team_id to each task
        for tid in task_ids:
            self._task_registry.assign_team(tid, team.team_id)

        # 4. Mark team as running
        team.status = TeamStatus.RUNNING
        team.updated_at = int(time.time())

        # 5. Run all tasks concurrently
        start = time.time()
        futures: dict[str, Future] = {}

        for i, task_id in enumerate(task_ids):
            task_obj = self._task_registry.get(task_id)
            future = _background_executor.submit(
                _run_sub_agent_sync,
                self._router,
                self._tools,
                self._system_prompt,
                self._model,
                task_obj.prompt,
                self._task_registry,
                task_id,
            )
            futures[task_id] = future
            _running_futures[task_id] = future

        # 6. Wait for all to complete
        results: dict[str, str] = {}
        errors = 0
        for task_id, future in futures.items():
            try:
                result = future.result(timeout=300)  # 5 min max per task
                results[task_id] = result
            except Exception as e:
                results[task_id] = f"Error: {e}"
                errors += 1

        elapsed = time.time() - start

        # 7. Mark team as completed
        team.status = TeamStatus.COMPLETED
        team.updated_at = int(time.time())

        # 8. Build combined report
        parts: list[str] = []
        for i, task_id in enumerate(task_ids):
            task_obj = self._task_registry.get(task_id)
            desc = tasks_input[i].get("description", tasks_input[i]["prompt"][:60])
            status = task_obj.status.value if task_obj else "unknown"
            output = results.get(task_id, "<no output>")
            # Truncate long outputs
            if len(output) > 2000:
                output = output[:2000] + f"\n... (truncated, {len(output)} chars total)"
            parts.append(f"### {desc}\n**Status:** {status}\n**Task ID:** {task_id}\n\n{output}\n")

        summary = (
            f"[Team '{team_name}': {len(task_ids)} tasks, {elapsed:.1f}s"
            f"{f', {errors} errors' if errors else ''}]\n"
            f"**Team ID:** {team.team_id}\n\n"
            + "\n---\n".join(parts)
        )

        # Clean up futures refs
        for task_id in task_ids:
            _running_futures.pop(task_id, None)

        return ToolResult(
            content=summary,
            metadata={
                "team_id": team.team_id,
                "task_ids": task_ids,
                "agent_count": len(task_ids),
                "errors": errors,
                "duration_s": elapsed,
            },
        )


class TeamDeleteTool(Tool):
    """Delete a team and stop all its running tasks."""

    name = "team_delete"
    description = "Delete a team and stop all its running tasks."
    input_schema = {
        "type": "object",
        "properties": {
            "team_id": {"type": "string"},
        },
        "required": ["team_id"],
    }
    risk_level = RiskLevel.MEDIUM

    def __init__(self, task_registry: TaskRegistry, team_registry: TeamRegistry):
        self._task_registry = task_registry
        self._team_registry = team_registry

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        team_id = args.get("team_id", "")
        try:
            team = self._team_registry.delete(team_id)
        except ValueError as e:
            return ToolResult(content=str(e), is_error=True)

        # Stop all running tasks in the team
        stopped = 0
        for task_id in team.task_ids:
            try:
                self._task_registry.stop(task_id)
                future = _running_futures.pop(task_id, None)
                if future and not future.done():
                    future.cancel()
                stopped += 1
            except ValueError:
                pass  # already stopped/completed

        return ToolResult(content=_json({
            "team_id": team.team_id,
            "name": team.name,
            "status": "deleted",
            "tasks_stopped": stopped,
        }))


# ── Inter-agent Messaging ──


class SendMessageTool(Tool):
    """Send a message from one agent to another via the task message system."""

    name = "send_message"
    description = (
        "Send a message from one agent to another (via task messages). "
        "Use this for inter-agent communication within a team."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "task_id": {"type": "string", "description": "Target task ID to send the message to"},
            "message": {"type": "string", "description": "The message content"},
            "from_task_id": {"type": "string", "description": "Source task ID (optional)"},
        },
        "required": ["task_id", "message"],
    }
    risk_level = RiskLevel.LOW

    def __init__(self, task_registry: TaskRegistry):
        self._task_registry = task_registry

    async def execute(self, args: dict[str, Any]) -> ToolResult:
        task_id = args.get("task_id", "")
        message = args.get("message", "")
        from_task_id = args.get("from_task_id", "orchestrator")

        if not task_id or not message:
            return ToolResult(content="task_id and message are required", is_error=True)

        try:
            task = self._task_registry.update(task_id, f"[from:{from_task_id}] {message}")
        except ValueError as e:
            return ToolResult(content=str(e), is_error=True)

        return ToolResult(content=_json({
            "sent": True,
            "to": task_id,
            "from": from_task_id,
            "message_count": len(task.messages),
        }))
