"""Package commands — traduit de commands/lib.rs.

Fournit les slash commands, leur parsing, leur exécution,
et les commandes de gestion (plugins, agents, skills, MCP).
"""

from .specs import (
    SlashCommandSpec,
    SLASH_COMMAND_SPECS,
    slash_command_specs,
    resume_supported_slash_commands,
)
from .parser import (
    SlashCommand,
    SlashCommandParseError,
    validate_slash_command_input,
)
from .registry import (
    CommandManifestEntry,
    CommandRegistry,
    CommandSource,
)
from .help import (
    render_slash_command_help,
    render_slash_command_help_detail,
    suggest_slash_commands,
)
from .handler import (
    SlashCommandResult,
    handle_slash_command,
)

# Re-export build_command_backlog from the standalone commands module
# (commands.py is shadowed by this package, so query_engine needs it here)
def build_command_backlog():
    """Proxy to the standalone commands.py build_command_backlog."""
    import importlib
    _mod = importlib.import_module("maestro_core.commands")
    # Force reload the standalone .py, not this package
    import sys
    _standalone_path = str(__import__("pathlib").Path(__file__).resolve().parent.parent / "commands.py")
    if "maestro_core._commands_standalone" not in sys.modules:
        import importlib.util
        spec = importlib.util.spec_from_file_location("maestro_core._commands_standalone", _standalone_path)
        if spec and spec.loader:
            mod = importlib.util.module_from_spec(spec)
            sys.modules["maestro_core._commands_standalone"] = mod
            spec.loader.exec_module(mod)
    return sys.modules["maestro_core._commands_standalone"].build_command_backlog()


__all__ = [
    "CommandManifestEntry",
    "CommandRegistry",
    "CommandSource",
    "SlashCommand",
    "SlashCommandParseError",
    "SlashCommandResult",
    "SlashCommandSpec",
    "SLASH_COMMAND_SPECS",
    "build_command_backlog",
    "handle_slash_command",
    "render_slash_command_help",
    "render_slash_command_help_detail",
    "resume_supported_slash_commands",
    "slash_command_specs",
    "suggest_slash_commands",
    "validate_slash_command_input",
]
