"""
Register modules and methods in the database.

``register_module`` — create or update a module row.
``register_method`` — AST-scan a method's script and populate
  Method, TrackedFunction, and ParamDef rows.

These are the production functions behind ``pm register-module``
and ``pm register-method`` CLI commands.
"""

from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

from sqlmodel import select

from dflow.core.decorators import task, Step

from .ast_scanner import scan_script, ScriptInfo
from .contracts import parse_method_yaml, parse_module_yaml
from .database import get_session
from .models import (
    Module,
    Method,
    MethodContract,
    ModuleContract,
    TrackedFunction,
    ParamDef,
)


# =============================================================================
# Environment resolution
# =============================================================================

def resolve_python_for_env(env_name: str, pixi_root: str | Path) -> Path:
    """Glob for the python executable inside a pixi environment.

    Searches ``{pixi_root}/{env_name}-*/envs/default/`` for a python
    executable, handling both Unix (``bin/python``) and Windows
    (``Scripts/python.exe``) layouts.

    Args:
        env_name: The pixi environment name (e.g. ``"image-io"``).
        pixi_root: Absolute path to the pixi environment root directory.

    Returns:
        Absolute ``Path`` to the python executable.

    Raises:
        ValueError: If zero or multiple matching directories are found.
    """
    import sys as _sys

    pixi_root = Path(pixi_root)
    pattern = f"{env_name}-*/envs/default"
    matches = sorted(pixi_root.glob(pattern))

    if len(matches) == 0:
        raise ValueError(
            f"No pixi environment found for '{env_name}'. "
            f"Searched: {pixi_root / pattern}\n"
            f"Run `pixi install` in the environment directory first."
        )

    if len(matches) > 1:
        listing = "\n  ".join(str(m) for m in matches)
        raise ValueError(
            f"Multiple pixi environments match '{env_name}':\n  {listing}\n"
            f"Remove duplicates so only one {env_name}-* directory exists "
            f"under {pixi_root}."
        )

    env_dir = matches[0]

    # Cross-platform python path — conda/pixi envs put python at the env
    # root on Windows (python.exe), not in Scripts/.  Try both locations.
    if _sys.platform == "win32":
        candidates = [env_dir / "python.exe", env_dir / "Scripts" / "python.exe"]
    else:
        candidates = [env_dir / "bin" / "python"]

    python = None
    for c in candidates:
        if c.exists():
            python = c
            break

    if python is None:
        searched = ", ".join(str(c) for c in candidates)
        raise ValueError(
            f"Python executable not found. Searched: {searched}. "
            f"The environment directory {env_dir} exists but the python "
            f"binary is missing. Run `pixi install` to populate it."
        )

    return python.resolve()


def _resolve_env(env_name: str, project_dir: Path) -> str:
    """Resolve and validate a named shared environment.

    Reads the ``pixi_root`` from the project config, globs for the
    environment's python executable, and returns the env name (the name
    is what gets stored in the database).

    Args:
        env_name: The env name from method.yaml (not ``"inherit"``).
        project_dir: Root directory of the pm project.

    Returns:
        The validated env name (same as input).

    Raises:
        ValueError: If the env cannot be found or is ambiguous.
    """
    from .init import read_config

    config = read_config(project_dir)
    pixi_root = config.get("pixi_root", "")

    if not pixi_root:
        raise ValueError(
            "No [pixi] root configured in .pm/wf-canvas.toml. "
            "Run `pm init` to create a default config."
        )

    # This validates the env exists and has a python executable
    resolve_python_for_env(env_name, pixi_root)

    return env_name


# =============================================================================
# Git integration
# =============================================================================

def _git_commit_registration(
    method_dir: Path,
    method_name: str,
    module_name: str,
    project_root: Path | None = None,
) -> str | None:
    """Commit the method directory to the project git repo.

    Stages the method directory and creates a commit.  Does nothing if the
    project root is not a git repo (prints a warning instead).

    Args:
        method_dir: Directory containing the registered method scripts.
        method_name: Method name (used in commit message).
        module_name: Module name (used in commit message).
        project_root: Root of the project git repo.  Defaults to cwd.

    Returns:
        Commit SHA if committed, or ``None`` if not in a git repo.
    """
    root = str(project_root or Path.cwd())

    # Check if inside a git repo
    check = subprocess.run(
        ["git", "rev-parse", "--git-dir"],
        cwd=root, capture_output=True, text=True,
    )
    if check.returncode != 0:
        raise RuntimeError(
            f"{root!r} is not a git repository.\n"
            "Run `pm init --git` before registering methods.\n"
            "pm requires git to track method versions for cache-key computation."
        )

    # Stage the method directory
    stage = subprocess.run(
        ["git", "add", str(method_dir)],
        cwd=root, capture_output=True, text=True,
    )
    if stage.returncode != 0:
        raise RuntimeError(f"git add failed: {stage.stderr.strip()}")

    # Check if there is anything to commit (no-op if dir was already staged)
    status = subprocess.run(
        ["git", "diff", "--cached", "--quiet"],
        cwd=root, capture_output=True,
    )
    if status.returncode == 0:
        # Nothing new staged — method was already identical
        print(f"  git: no changes to commit for '{method_name}'")
        return None

    # Commit — use inline identity so repo doesn't need global git config
    commit = subprocess.run(
        [
            "git",
            "-c", "user.email=pm@pm",
            "-c", "user.name=pm",
            "commit",
            "-m", f"Register method {module_name}/{method_name}",
        ],
        cwd=root, capture_output=True, text=True,
    )
    if commit.returncode != 0:
        raise RuntimeError(f"git commit failed: {commit.stderr.strip()}")

    # Return the new HEAD SHA
    sha = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=root, capture_output=True, text=True,
    )
    sha_str = sha.stdout.strip()
    print(f"  git: committed as {sha_str[:12]}")
    return sha_str


@task(purpose="Create or update a module in the database")
def register_module(
    name: str,
    contracts: list[dict] | None = None,
    description: str | None = None,
    module_dir: Path | None = None,
) -> int:
    """Create or update a module row.

    If a module with the same name already exists, updates its description
    and contracts. Otherwise creates a new row.

    Contracts can come from three sources (highest priority first):
      1. The ``contracts`` argument (explicit CLI JSON)
      2. A ``module.yaml`` file in ``module_dir``
      3. If neither is provided, raises TypeError

    Args:
        name: Module name (e.g. 'data_preprocessing').
        contracts: List of contract dicts (pass ``[]`` for no contracts).
            Each dict must have:
            - ``type``: 'output' or 'metric'
            - ``name``: artifact/metric name
            - ``value_type``: file extension or data type (optional)
            - ``required``: bool (default True)
        description: Optional human-readable description.
        module_dir: Optional path to module directory containing ``module.yaml``.
            When provided and ``contracts`` is None, contracts and description
            are read from the YAML file.

    Returns:
        The module ID (existing or newly created).

    Raises:
        TypeError: If neither ``contracts`` nor a valid ``module.yaml`` is available.
    """
    # Resolve contracts from module.yaml if not explicitly provided
    if contracts is None and module_dir is not None:
        module_yaml_data = parse_module_yaml(module_dir)
        if module_yaml_data is not None:
            contracts = module_yaml_data["contracts"]
            if description is None:
                description = module_yaml_data.get("description")
            print(f"Loaded contracts from {module_dir / 'module.yaml'}")

    if contracts is None:
        raise TypeError(
            "register_module() requires 'contracts' argument or a module.yaml "
            "file in module_dir. Pass contracts=[] for no contracts."
        )
    口 = Step(step_num=1, name="Upsert module row",
             purpose="Create or update the module record in the database")
    with get_session() as session:
        module = session.exec(
            select(Module).where(Module.name == name)
        ).first()

        if module is None:
            module = Module(name=name, description=description)
            session.add(module)
            session.commit()
            session.refresh(module)
            print(f"Created module '{name}' (id={module.id})")
        else:
            if description is not None:
                module.description = description
            session.commit()
            session.refresh(module)
            print(f"Updated module '{name}' (id={module.id})")

        module_id = module.id

        口 = Step(step_num=2, name="Sync contracts",
                 purpose="Replace module-level output and metric contracts with the provided list")
        # Always sync — clear existing rows then insert the new set.
        # An empty list is a valid explicit choice (no contracts for this module).
        existing = session.exec(
            select(ModuleContract).where(
                ModuleContract.module_id == module_id
            )
        ).all()
        for c in existing:
            session.delete(c)

        for c in contracts:
            mc = ModuleContract(
                module_id=module_id,
                contract_type=c["type"],
                name=c["name"],
                value_type=c.get("value_type"),
                required=c.get("required", True),
            )
            session.add(mc)

        session.commit()
        print(f"  {len(contracts)} contract(s) registered")

    return module_id


@task(purpose="AST-scan a method script and register it with tracked functions and parameters")
def register_method(
    method_dir: Path,
    module_name: str,
    method_name: str | None = None,
    script_name: str | None = None,
) -> int:
    """Scan a method script and register it in the database.

    Performs:
      1. Find and AST-parse the script
      2. Upsert Method row (linked to the named module)
      3. Extract tracked functions and their parameter definitions
      4. Populate TrackedFunction + ParamDef rows

    Args:
        method_dir: Directory containing the method script.
        module_name: Name of the module this method belongs to.
        method_name: Method name (defaults to directory name).
        script_name: Script filename to scan (default: '{method_name}.py').

    Returns:
        The method ID.

    Raises:
        FileNotFoundError: If the script is not found.
        ValueError: If the module doesn't exist in the database.
    """
    method_dir = Path(method_dir).resolve()
    if method_name is None:
        method_name = method_dir.name
    if script_name is None:
        script_name = f"{method_name}.py"

    口 = Step(step_num=1, name="Locate and scan script",
             purpose="Find method script and extract function signatures via AST parsing")
    script_path = method_dir / script_name
    if not script_path.exists():
        raise FileNotFoundError(
            f"Script not found: {script_path}\n"
            f"Expected '{script_name}' in {method_dir}"
        )

    script_info = scan_script(script_path)
    print(f"Scanned {script_path}: {len(script_info.functions)} function(s)")

    口 = Step(step_num=2, name="Resolve module",
             purpose="Find the parent module in the database")
    with get_session() as session:
        module = session.exec(
            select(Module).where(Module.name == module_name)
        ).first()
        if module is None:
            raise ValueError(
                f"Module '{module_name}' not found in DB. "
                f"Run 'pm register-module --name {module_name}' first."
            )

        口 = Step(step_num=3, name="Upsert method row",
                 purpose="Create or update the method record linked to its module")
        # Compute script_path relative to project root (cwd)
        try:
            rel_script = script_path.relative_to(Path.cwd())
        except ValueError:
            rel_script = script_path

        method = session.exec(
            select(Method).where(
                Method.module_id == module.id,
                Method.name == method_name,
            )
        ).first()

        # Resolve env from method.yaml contract (or default to "inherit")
        contract_data = parse_method_yaml(method_dir)
        env_name = contract_data["env"] if contract_data else "inherit"

        if env_name != "inherit":
            # Validate the named env against project config
            project_dir = Path.cwd()
            _resolve_env(env_name, project_dir)
            print(f"  Env: {env_name} (validated)")

        if method is None:
            method = Method(
                module_id=module.id,
                name=method_name,
                script_path=str(rel_script),
                env=env_name,
            )
            session.add(method)
            session.commit()
            session.refresh(method)
            print(f"Created method '{method_name}' (id={method.id}, env={env_name})")
        else:
            method.script_path = str(rel_script)
            method.env = env_name
            session.commit()
            session.refresh(method)
            print(f"Updated method '{method_name}' (id={method.id}, env={env_name})")

        method_id = method.id

        口 = Step(step_num=4, name="Sync tracked functions and parameters",
                 purpose="Replace tracked function and parameter rows with fresh AST scan results")
        # Clear existing tracked functions (cascade to param_defs)
        existing_tfs = session.exec(
            select(TrackedFunction).where(
                TrackedFunction.method_id == method_id
            )
        ).all()
        for tf in existing_tfs:
            # Delete param_defs for this tracked function
            existing_pds = session.exec(
                select(ParamDef).where(
                    ParamDef.tracked_function_id == tf.id
                )
            ).all()
            for pd in existing_pds:
                session.delete(pd)
            session.delete(tf)
        session.commit()

        # Insert fresh tracked functions from AST scan
        for ordinal, func in enumerate(script_info.functions, start=1):
            tf = TrackedFunction(
                method_id=method_id,
                function_name=func.name,
                ordinal=ordinal,
            )
            session.add(tf)
            session.commit()
            session.refresh(tf)

            for param in func.params:
                pd_row = ParamDef(
                    tracked_function_id=tf.id,
                    param_name=param.name,
                    param_type=param.type_annotation,
                    default_value=param.default_value,
                )
                session.add(pd_row)

            session.commit()

            param_summary = ", ".join(
                f"{p.name}: {p.type_annotation or '?'}" + (f" = {p.default_value}" if p.default_value else "")
                for p in func.params
            )
            main_tag = " [main]" if func.is_main else ""
            ctx_tag = " [RunContext]" if func.uses_run_context else ""
            print(f"  {func.name}({param_summary}){main_tag}{ctx_tag}")

        口 = Step(step_num=5, name="Store method contract",
                 purpose="Store method.yaml slot definitions in the database (already parsed at step 3)")
        if contract_data is not None:
            # Remove existing contract for this method (upsert)
            existing_contract = session.exec(
                select(MethodContract).where(
                    MethodContract.method_id == method_id
                )
            ).first()
            if existing_contract is not None:
                session.delete(existing_contract)
                session.commit()

            mc = MethodContract(
                method_id=method_id,
                input_slots=contract_data["inputs"],
                output_slots=contract_data["outputs"],
                params_schema=contract_data["params"],
                executor=contract_data["executor"],
            )
            session.add(mc)
            session.commit()
            out_names = list(contract_data["outputs"].keys())
            print(f"  contract: {len(contract_data['inputs'])} input(s), "
                  f"{len(out_names)} output(s): {out_names}")
        else:
            print("  contract: no method.yaml found — skipped")

        口 = Step(step_num=6, name="Validate method against module contract",
                 purpose="Check that method outputs conform to the module's required output contracts")
        module_contracts = session.exec(
            select(ModuleContract).where(
                ModuleContract.module_id == module.id
            )
        ).all()
        required_outputs = [
            mc for mc in module_contracts
            if mc.contract_type == "output" and mc.required
        ]
        if required_outputs and contract_data is not None:
            method_output_names = set(contract_data["outputs"].keys())
            missing = []
            for req in required_outputs:
                if req.name not in method_output_names:
                    missing.append(req.name)
            if missing:
                raise ValueError(
                    f"Method '{method_name}' is missing required module output(s): "
                    f"{missing}. Module '{module_name}' requires outputs: "
                    f"{[mc.name for mc in required_outputs]}. "
                    f"Method declares: {sorted(method_output_names)}"
                )
            print(f"  module contract: validated ({len(required_outputs)} required output(s))")
        elif required_outputs and contract_data is None:
            print(f"  module contract: skipped (no method.yaml to validate)")

    口 = Step(step_num=7, name="Commit method to git",
             purpose="Stage the method directory and create a git commit so the "
                     "method code version is captured in the cache key")
    _git_commit_registration(method_dir, method_name, module_name)

    口 = Step(step_num=8, name="Copy source files to registered location",
             purpose="Snapshot method source files into methods/{method_name}/ "
                     "so the code fingerprint is always computed from the "
                     "registered copy, not whatever is on disk at run time")
    project_dir = Path.cwd()
    registered_dir = project_dir / "methods" / method_name
    # Only copy if the source directory differs from the registered location
    if method_dir.resolve() != registered_dir.resolve():
        registered_dir.mkdir(parents=True, exist_ok=True)
        for py_file in method_dir.rglob("*.py"):
            rel = py_file.relative_to(method_dir)
            dest = registered_dir / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(py_file, dest)
        # Also copy method.yaml if it exists (contract spec)
        yaml_file = method_dir / "method.yaml"
        if yaml_file.exists():
            shutil.copy2(yaml_file, registered_dir / "method.yaml")
        print(f"  source snapshot: copied to {registered_dir}")
    else:
        print(f"  source snapshot: already at registered location")

    return method_id
