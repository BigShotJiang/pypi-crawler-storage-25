<script lang="ts">
  import {
    filters,
    availableModules,
    availableMethods,
    availableSamples,
    selectedRunIds,
    clearSelection,
    resetFilters,
    loadRuns,
  } from './historyStore.js';
  import type { TimeRange } from './historyStore.js';

  function setTimeRange(value: string) {
    filters.update(f => ({ ...f, timeRange: value as TimeRange }));
  }

  function setModule(value: string) {
    filters.update(f => ({ ...f, module: value }));
  }

  function toggleMethod(method: string) {
    filters.update(f => {
      const methods = f.methods.includes(method)
        ? f.methods.filter(m => m !== method)
        : [...f.methods, method];
      return { ...f, methods };
    });
  }

  function toggleSample(sample: string) {
    filters.update(f => {
      const samples = f.sample.includes(sample)
        ? f.sample.filter(s => s !== sample)
        : [...f.sample, sample];
      return { ...f, sample: samples };
    });
  }

  function setSearchText(value: string) {
    filters.update(f => ({ ...f, searchText: value }));
  }

  function toggleFavoritesOnly() {
    filters.update(f => ({ ...f, favoritesOnly: !f.favoritesOnly }));
  }

  function toggleSelectMode() {
    filters.update(f => {
      const next = !f.selectMode;
      if (!next) clearSelection();
      return { ...f, selectMode: next };
    });
  }

  let methodDropdownOpen = $state(false);
  let sampleDropdownOpen = $state(false);
  let methodFilterEl: HTMLDivElement;
  let sampleFilterEl: HTMLDivElement;

  function handleWindowClick(event: MouseEvent) {
    if (methodDropdownOpen && methodFilterEl && !methodFilterEl.contains(event.target as Node)) {
      methodDropdownOpen = false;
    }
    if (sampleDropdownOpen && sampleFilterEl && !sampleFilterEl.contains(event.target as Node)) {
      sampleDropdownOpen = false;
    }
  }
</script>

<svelte:window onclick={handleWindowClick} />

<div class="filter-bar">
  <div class="filter-group">
    <label class="filter-label">Time</label>
    <select class="filter-select" value={$filters.timeRange} onchange={(e) => setTimeRange((e.target as HTMLSelectElement).value)}>
      <option value="all">All time</option>
      <option value="24h">Last 24h</option>
      <option value="7d">Last 7 days</option>
      <option value="30d">Last 30 days</option>
    </select>
  </div>

  <div class="filter-group">
    <label class="filter-label">Module</label>
    <select class="filter-select" value={$filters.module} onchange={(e) => setModule((e.target as HTMLSelectElement).value)}>
      <option value="">All modules</option>
      {#each $availableModules as mod}
        <option value={mod}>{mod}</option>
      {/each}
    </select>
  </div>

  <div class="filter-group method-filter" bind:this={methodFilterEl}>
    <label class="filter-label">Methods</label>
    <button class="filter-select method-toggle" onclick={() => { methodDropdownOpen = !methodDropdownOpen; }}>
      {$filters.methods.length === 0 ? 'All methods' : `${$filters.methods.length} selected`}
    </button>
    {#if methodDropdownOpen}
      <div class="dropdown">
        {#each $availableMethods as method}
          <label class="dropdown-option">
            <input type="checkbox" checked={$filters.methods.includes(method)} onchange={() => toggleMethod(method)} />
            <span>{method}</span>
          </label>
        {/each}
        {#if $availableMethods.length === 0}
          <span class="dropdown-empty">No methods loaded</span>
        {/if}
      </div>
    {/if}
  </div>

  <div class="filter-group sample-filter" bind:this={sampleFilterEl}>
    <label class="filter-label">Sample</label>
    <button
      class="filter-select sample-toggle"
      class:active={$filters.sample.length > 0}
      onclick={() => { sampleDropdownOpen = !sampleDropdownOpen; }}
    >
      {$filters.sample.length === 0 ? 'All samples' : `${$filters.sample.length} selected`}
    </button>
    {#if sampleDropdownOpen}
      <div class="dropdown">
        {#each $availableSamples as sample}
          <label class="dropdown-option">
            <input type="checkbox" checked={$filters.sample.includes(sample)} onchange={() => toggleSample(sample)} />
            <span>{sample}</span>
          </label>
        {/each}
        {#if $availableSamples.length === 0}
          <span class="dropdown-empty">No samples loaded</span>
        {/if}
      </div>
    {/if}
  </div>

  <div class="filter-group search-group">
    <label class="filter-label">Search</label>
    <input class="filter-input" type="text" placeholder="Filter runs..."
      value={$filters.searchText}
      oninput={(e) => setSearchText((e.target as HTMLInputElement).value)} />
  </div>

  <div class="filter-actions">
    <button class="filter-btn" class:active={$filters.favoritesOnly} onclick={toggleFavoritesOnly} title="Favorites only">
      {$filters.favoritesOnly ? '\u2605' : '\u2606'}
    </button>
    <button class="filter-btn" class:active={$filters.selectMode} onclick={toggleSelectMode} title="Select mode for export">
      {$filters.selectMode ? `\u2611 ${$selectedRunIds.size}` : '\u2610'}
    </button>
    <button class="filter-btn refresh-btn" onclick={() => loadRuns()} title="Refresh runs">
      {'\u21BB'} Refresh
    </button>
    <button class="filter-btn reset-btn" onclick={resetFilters} title="Reset all filters">
      Reset
    </button>
  </div>
</div>

<style>
  .filter-bar {
    display: flex;
    align-items: flex-end;
    gap: 10px;
    padding: 8px 12px;
    background: var(--bg-panel, #252526);
    border-bottom: 1px solid var(--border, #3e3e42);
    flex-shrink: 0;
    flex-wrap: wrap;
  }
  .filter-group {
    display: flex;
    flex-direction: column;
    gap: 2px;
    position: relative;
  }
  .filter-label {
    font-size: 9px;
    color: var(--text-muted, #666);
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }
  .filter-select, .filter-input {
    background: var(--bg-input, #1e1e1e);
    border: 1px solid var(--border, #3e3e42);
    border-radius: 3px;
    padding: 4px 8px;
    color: var(--text-primary, #ccc);
    font-size: 11px;
    outline: none;
    min-height: 26px;
  }
  .filter-select:focus, .filter-input:focus {
    border-color: var(--accent, #4A90D9);
  }
  .filter-select.active {
    border-color: var(--accent, #4A90D9);
    color: #fff;
  }
  .search-group {
    flex: 1;
    min-width: 120px;
  }
  .filter-input {
    width: 100%;
  }
  .filter-actions {
    display: flex;
    gap: 4px;
    align-items: flex-end;
    padding-bottom: 1px;
  }
  .filter-btn {
    background: var(--bg-input, #1e1e1e);
    border: 1px solid var(--border, #3e3e42);
    border-radius: 3px;
    padding: 4px 8px;
    color: var(--text-secondary, #888);
    font-size: 11px;
    cursor: pointer;
    min-height: 26px;
  }
  .filter-btn:hover {
    border-color: var(--accent, #4A90D9);
    color: var(--text-primary, #ccc);
  }
  .filter-btn.active {
    background: var(--accent, #4A90D9);
    color: white;
    border-color: var(--accent, #4A90D9);
  }
  .refresh-btn {
    color: var(--accent, #4A90D9);
    border-color: var(--accent, #4A90D9);
  }
  .reset-btn {
    color: var(--text-muted, #666);
    font-size: 10px;
  }
  .method-toggle, .sample-toggle {
    cursor: pointer;
    text-align: left;
  }
  .dropdown {
    position: absolute;
    top: 100%;
    left: 0;
    z-index: 100;
    background: var(--bg-panel, #252526);
    border: 1px solid var(--border, #3e3e42);
    border-radius: 4px;
    padding: 4px 0;
    max-height: 200px;
    overflow-y: auto;
    min-width: 180px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
  }
  .dropdown-option {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 4px 8px;
    font-size: 11px;
    color: var(--text-primary, #ccc);
    cursor: pointer;
  }
  .dropdown-option:hover {
    background: var(--bg-header, #2d2d30);
  }
  .dropdown-option input[type="checkbox"] {
    accent-color: var(--accent, #4A90D9);
  }
  .dropdown-empty {
    padding: 8px;
    font-size: 11px;
    color: var(--text-muted, #666);
  }
</style>
