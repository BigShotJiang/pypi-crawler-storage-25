/**
 * Reactive state management for the History view.
 * Uses svelte/store writable/derived for cross-component shared state
 * (matches the pattern in stores.ts).
 */
import { writable, derived, get } from 'svelte/store';
import type { PmRun } from './historyApi.js';
import { fetchRuns, fetchModules, fetchMethods } from './historyApi.js';

// ---------- Types ----------

export type TimeRange = 'all' | '24h' | '7d' | '30d';

export interface FilterState {
  timeRange: TimeRange;
  module: string;          // '' = all modules
  methods: string[];       // [] = all methods
  sample: string[];        // [] = all samples
  searchText: string;
  favoritesOnly: boolean;
  selectMode: boolean;
}

export interface PathRow {
  pathId: number;
  nodes: PmRun[];
}

// ---------- Stores ----------

export const runs = writable<PmRun[]>([]);
export const loading = writable<boolean>(false);
export const error = writable<string | null>(null);

export const filters = writable<FilterState>({
  timeRange: 'all',
  module: '',
  methods: [],
  sample: [],
  searchText: '',
  favoritesOnly: false,
  selectMode: false,
});

export const selectedRunId = writable<string | null>(null);
export const selectedRunIds = writable<Set<string>>(new Set());
export const descendantTreeRoot = writable<string | null>(null);

export const availableModules = writable<string[]>([]);
export const availableMethods = writable<string[]>([]);

// ---------- Favorites (localStorage) ----------

const FAVORITES_KEY = 'pm-history-favorites';

function loadFavorites(): Set<string> {
  try {
    const raw = localStorage.getItem(FAVORITES_KEY);
    if (raw) return new Set(JSON.parse(raw));
  } catch { /* ignore */ }
  return new Set();
}

function saveFavorites(favs: Set<string>): void {
  try {
    localStorage.setItem(FAVORITES_KEY, JSON.stringify([...favs]));
  } catch { /* ignore */ }
}

export const favorites = writable<Set<string>>(loadFavorites());

export function toggleFavorite(runId: string): void {
  favorites.update(favs => {
    const next = new Set(favs);
    if (next.has(runId)) {
      next.delete(runId);
    } else {
      next.add(runId);
    }
    saveFavorites(next);
    return next;
  });
}

// ---------- effectiveSample ----------

/**
 * Cache for effectiveSample lookups. Cleared on each loadRuns().
 */
let effectiveSampleCache = new Map<string, string | null>();

/**
 * Walk parentRunId root-ward through allRuns to find the root's sample.
 * Cycle-safe: caps at 1000 hops. Returns null if cap is hit or root has no sample.
 */
export function effectiveSample(run: PmRun, allRuns: PmRun[]): string | null {
  if (effectiveSampleCache.has(run.id)) {
    return effectiveSampleCache.get(run.id)!;
  }

  const runMap = new Map<string, PmRun>();
  for (const r of allRuns) runMap.set(r.id, r);

  let current: PmRun | undefined = run;
  let hops = 0;
  const MAX_HOPS = 1000;

  while (current && current.parentRunId && hops < MAX_HOPS) {
    current = runMap.get(current.parentRunId);
    hops++;
  }

  if (hops >= MAX_HOPS || !current) {
    effectiveSampleCache.set(run.id, null);
    return null;
  }

  const sample = current.dataSource || null;
  effectiveSampleCache.set(run.id, sample);
  return sample;
}

// ---------- Derived: availableSamples ----------

export const availableSamples = derived(runs, ($runs) => {
  const rootSamples = new Set<string>();
  for (const r of $runs) {
    if (r.parentRunId === null && r.dataSource) {
      rootSamples.add(r.dataSource);
    }
  }
  return Array.from(rootSamples).sort();
});

// ---------- Derived: filtered runs ----------

function timeRangeMs(range: TimeRange): number {
  const now = Date.now();
  switch (range) {
    case '24h': return now - 24 * 60 * 60 * 1000;
    case '7d': return now - 7 * 24 * 60 * 60 * 1000;
    case '30d': return now - 30 * 24 * 60 * 60 * 1000;
    default: return 0;
  }
}

export const filteredRuns = derived(
  [runs, filters, favorites],
  ([$runs, $filters, $favorites]) => {
    let result = $runs;

    // Time range filter
    if ($filters.timeRange !== 'all') {
      const cutoff = timeRangeMs($filters.timeRange);
      result = result.filter(r => r.timestamp >= cutoff);
    }

    // Module filter
    if ($filters.module) {
      result = result.filter(r => r.module === $filters.module);
    }

    // Methods filter
    if ($filters.methods.length > 0) {
      const methodSet = new Set($filters.methods);
      result = result.filter(r => methodSet.has(r.method));
    }

    // Sample filter (uses effectiveSample for lineage-aware filtering)
    if ($filters.sample.length > 0) {
      const sampleSet = new Set($filters.sample);
      result = result.filter(r => {
        const es = effectiveSample(r, $runs);
        return es !== null && sampleSet.has(es);
      });
    }

    // Search text filter (case-insensitive, matches run name, method, module, sample)
    if ($filters.searchText) {
      const term = $filters.searchText.toLowerCase();
      result = result.filter(r =>
        r.runName.toLowerCase().includes(term) ||
        r.method.toLowerCase().includes(term) ||
        r.module.toLowerCase().includes(term) ||
        r.dataSource.toLowerCase().includes(term) ||
        r.id.toLowerCase().includes(term)
      );
    }

    // Favorites only
    if ($filters.favoritesOnly) {
      result = result.filter(r => $favorites.has(r.id));
    }

    // Sort by timestamp descending (newest first)
    return result.sort((a, b) => b.timestamp - a.timestamp);
  }
);

// ---------- Derived: pathRows ----------

export const pathRows = derived(filteredRuns, ($filtered) => {
  // Build a lookup of filtered run ids and a parent map
  const filteredSet = new Set($filtered.map(r => r.id));
  const runMap = new Map<string, PmRun>();
  for (const r of $filtered) runMap.set(r.id, r);

  // Find children of each run within the filtered set
  const childrenMap = new Map<string, string[]>();
  for (const r of $filtered) {
    if (r.parentRunId && filteredSet.has(r.parentRunId)) {
      const children = childrenMap.get(r.parentRunId) || [];
      children.push(r.id);
      childrenMap.set(r.parentRunId, children);
    }
  }

  // Terminals: runs that have no children in the filtered set
  const terminals = $filtered.filter(r => !childrenMap.has(r.id) || childrenMap.get(r.id)!.length === 0);

  // For each terminal, walk parent-ward to build the path root -> terminal
  const rows: PathRow[] = [];
  let pathId = 1;

  for (const terminal of terminals) {
    const path: PmRun[] = [terminal];
    let current = terminal;
    let hops = 0;

    while (current.parentRunId && filteredSet.has(current.parentRunId) && hops < 1000) {
      const parent = runMap.get(current.parentRunId);
      if (!parent) break;
      path.unshift(parent);
      current = parent;
      hops++;
    }

    rows.push({ pathId: pathId++, nodes: path });
  }

  // Sort rows by timestamp of root node (newest first)
  rows.sort((a, b) => {
    const aTime = a.nodes[0]?.timestamp ?? 0;
    const bTime = b.nodes[0]?.timestamp ?? 0;
    return bTime - aTime;
  });

  return rows;
});

// ---------- Actions ----------

export async function loadRuns(): Promise<void> {
  loading.set(true);
  error.set(null);
  // Clear the effectiveSample cache on each load
  effectiveSampleCache = new Map();
  try {
    const [allRuns, mods, meths] = await Promise.all([
      fetchRuns(),
      fetchModules(),
      fetchMethods(),
    ]);
    runs.set(allRuns);
    availableModules.set(mods.sort());
    availableMethods.set(meths.map(m => m.name).sort());
  } catch (err) {
    error.set(err instanceof Error ? err.message : String(err));
  } finally {
    loading.set(false);
  }
}

export function selectRun(runId: string | null): void {
  selectedRunId.set(runId);
}

export function toggleRunSelection(runId: string): void {
  selectedRunIds.update(ids => {
    const next = new Set(ids);
    if (next.has(runId)) {
      next.delete(runId);
    } else {
      next.add(runId);
    }
    return next;
  });
}

export function clearSelection(): void {
  selectedRunIds.set(new Set());
}

export function showDescendants(runId: string): void {
  descendantTreeRoot.set(runId);
}

export function hideDescendants(): void {
  descendantTreeRoot.set(null);
}

export function resetFilters(): void {
  filters.set({
    timeRange: 'all',
    module: '',
    methods: [],
    sample: [],
    searchText: '',
    favoritesOnly: false,
    selectMode: false,
  });
}
