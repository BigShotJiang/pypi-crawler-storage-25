<script lang="ts">
  import type { PmRun } from './historyApi.js';
  import {
    favorites,
    filters,
    selectedRunIds,
    selectRun,
    toggleFavorite,
    toggleRunSelection,
  } from './historyStore.js';
  import { getModuleColor, hslToRgba, statusColor } from './historyUtils.js';

  interface Props {
    run: PmRun;
  }

  let { run }: Props = $props();

  let isFavorite = $derived($favorites.has(run.id));

  /**
   * Compute border color based on run status.
   * Running = amber, failed = red, completed/success = module color, other = grey.
   */
  let borderColor = $derived.by(() => {
    switch (run.status) {
      case 'running': return '#E9A847';
      case 'failed': return '#E74C3C';
      case 'success': return getModuleColor(run.module);
      default: return '#666';
    }
  });

  /**
   * Compute background tint based on run status.
   */
  let bgColor = $derived.by(() => {
    switch (run.status) {
      case 'running': return 'rgba(233, 168, 71, 0.14)';
      case 'failed': return 'rgba(231, 76, 60, 0.12)';
      case 'success': return hslToRgba(getModuleColor(run.module), 0.10);
      default: return 'transparent';
    }
  });

  /**
   * Compute box-shadow for running status (amber glow).
   */
  let boxShadow = $derived(run.status === 'running' ? '0 0 0 1px #E9A847' : 'none');

  function handleClick() {
    if ($filters.selectMode) {
      toggleRunSelection(run.id);
    } else {
      selectRun(run.id);
    }
  }

  function handleStarClick(e: MouseEvent) {
    e.stopPropagation();
    toggleFavorite(run.id);
  }

  function handleKeydown(e: KeyboardEvent) {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      handleClick();
    }
  }
</script>

<div
  class="path-node"
  class:running={run.status === 'running'}
  class:failed={run.status === 'failed'}
  class:selected={$filters.selectMode && $selectedRunIds.has(run.id)}
  style="border-left-color: {borderColor}; background: {bgColor}; box-shadow: {boxShadow};"
  role="button"
  tabindex="0"
  onclick={handleClick}
  onkeydown={handleKeydown}
>
  <div class="top">
    <button class="star" class:active={isFavorite} onclick={handleStarClick} title="Toggle favorite">
      {isFavorite ? '\u2605' : '\u2606'}
    </button>
    <span class="status-dot" style="color: {statusColor(run.status)}">
      {'\u25CF'}
    </span>
  </div>
  <div class="method">{run.method}</div>
  <div class="run-name">{run.runName || run.id.slice(0, 8)}</div>
  {#if $filters.selectMode}
    <span class="checkbox">{$selectedRunIds.has(run.id) ? '\u2611' : '\u2610'}</span>
  {/if}
</div>

<style>
  .path-node {
    padding: 10px 12px;
    border-radius: 6px;
    border-left: 4px solid var(--accent, #4A90D9);
    min-width: 130px;
    position: relative;
    cursor: pointer;
    transition: transform 0.08s;
  }
  .path-node:hover {
    transform: translateY(-1px);
  }
  .path-node.selected {
    outline: 2px solid var(--accent, #4A90D9);
    outline-offset: 1px;
  }
  .top {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 2px;
    font-size: 10px;
  }
  .star {
    background: none;
    border: none;
    color: var(--text-muted, #666);
    cursor: pointer;
    font-size: 14px;
    padding: 0;
    line-height: 1;
  }
  .star.active {
    color: var(--color-running, #E9A847);
  }
  .star:hover {
    transform: scale(1.2);
  }
  .status-dot {
    font-weight: 600;
    font-size: 10px;
  }
  .method {
    color: var(--text-secondary, #888);
    font-size: 10px;
  }
  .run-name {
    color: #fff;
    font-weight: 600;
    font-size: 12px;
  }
  .checkbox {
    position: absolute;
    top: 4px;
    right: 4px;
    font-size: 14px;
    color: var(--accent, #4A90D9);
  }
</style>
