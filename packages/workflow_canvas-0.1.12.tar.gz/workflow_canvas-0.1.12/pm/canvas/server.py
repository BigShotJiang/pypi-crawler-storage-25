"""
Workflow Canvas -- FastAPI backend (pm-native).

All data comes from the live pm SQLite database -- no mock data, no MLflow.

Endpoints
---------
GET  /                            Serve the canvas SPA
GET  /api/modules                 All modules + methods + slot contracts (live DB)
GET  /api/types                   Data-type metadata for slot colouring
POST /api/workflow/validate       Validate a workflow graph against the DB
POST /api/workflow/run            Submit a workflow for execution
POST /api/workflow/save           Save a workflow definition

POST /api/pm/load                 (Re)load PmProvider from a project path
POST /api/pm/refresh              Reload from current project_root
GET  /api/pm/status               Provider status
GET  /api/pm/runs                 All pm runs in canvas format
GET  /api/pm/experiments          Pipelines as experiment groups
GET  /api/pm/run/{id}             Single run
GET  /api/pm/lineage/{id}         Full ancestor + descendant lineage
GET  /api/pm/tree/{id}            Run + all descendants
GET  /api/pm/modules              Module names (from provider cache)
GET  /api/pm/datasources          Unique sample names
GET  /api/pm/methods              Method list
GET  /api/pm/run/{id}/artifacts   List artifacts in a run archive dir
GET  /api/pm/run/{id}/artifact/*  Serve an artifact file

POST /api/pm/export-artifacts     Zip download (filtered by type)
POST /api/pm/preview-artifacts    Export preview (counts + sizes)
POST /api/pm/export-csvs          Zip download (CSV only)
POST /api/pm/preview-csvs         Preview CSVs
"""

from __future__ import annotations

import io
import json
import os
import tempfile
import threading
import uuid
import zipfile
from contextlib import asynccontextmanager
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from sqlmodel import select

from ..database import get_session
from ..models import Method, MethodContract, Module, Run
from .pm_provider import PmProvider

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

_STATIC_DIR = Path(__file__).parent / "static" / "dist"

# ---------------------------------------------------------------------------
# Provider state
# ---------------------------------------------------------------------------

_pm_provider: Optional[PmProvider] = None

# ---------------------------------------------------------------------------
# Active job tracking (single pipeline at a time)
# ---------------------------------------------------------------------------

_active_jobs: Dict[str, Dict[str, Any]] = {}


def _import_run_pipeline():
    """Lazy import of run_pipeline from pm.cli.

    Module-level reference so tests can mock ``pm.canvas.server.run_pipeline_fn``
    and have the mock remain active during background thread execution.
    """
    from ..cli import run_pipeline
    return run_pipeline


def _import_fail_pipeline():
    """Lazy import of fail_pipeline from pm.cli."""
    from ..cli import fail_pipeline
    return fail_pipeline


# Callable references -- overridden in tests via mock
run_pipeline_fn = _import_run_pipeline
fail_pipeline_fn = _import_fail_pipeline

# Extension mapping for slot_outputs (type -> file extension)
_TYPE_EXT_MAP: Dict[str, str] = {
    "CSV": ".csv",
    "csv": ".csv",
    "ANNDATA": ".h5ad",
    "PNG": ".png",
    "png": ".png",
    "MODEL": ".pkl",
    "model": ".pkl",
    "FIGURE": ".png",
    "LABELS": ".csv",
    "FEATURE_SET": ".csv",
    "JSON": ".json",
    "json": ".json",
    "directory": "",
    "DIRECTORY": "",
}


def _enrich_pipeline(pipeline: "PipelineInput") -> Dict[str, Any]:
    """Enrich a PipelineJSON payload with script paths and slot_outputs from the DB.

    The canvas sends minimal node data (id, method, module, params).
    This function looks up each method's contract to add script_path
    and slot_outputs so load_pipeline() has everything it needs.

    Args:
        pipeline: The PipelineInput model from the canvas frontend.

    Returns:
        A dict with ``nodes``, ``links``, and ``samples`` keys matching
        the PipelineJSON format that ``load_pipeline()`` expects.
    """
    contract_map: Dict[str, Dict[str, Any]] = {}
    with get_session() as session:
        modules_db = {m.name: m for m in session.exec(select(Module)).all()}
        for mod in modules_db.values():
            for meth in mod.methods:
                mc = meth.contract
                contract_map[f"{mod.name}.{meth.name}"] = {
                    "output_slots": mc.output_slots if mc else {},
                    "script_path": meth.script_path,
                    "env": meth.env,
                }

    nodes = []
    for node in pipeline.nodes:
        key = f"{node.module or ''}.{node.method}"
        info = contract_map.get(key, {})
        output_slots = info.get("output_slots", {})
        script_path = info.get("script_path", f"methods/{node.method}/{node.method}.py")

        slot_outputs: Dict[str, str] = {}
        slot_types: Dict[str, str] = {}
        for slot_name, slot_spec in output_slots.items():
            slot_type = slot_spec.get("type", "CSV") if isinstance(slot_spec, dict) else "CSV"
            ext = _TYPE_EXT_MAP.get(slot_type, ".csv")
            slot_outputs[slot_name] = f"{slot_name}{ext}"
            # ADR-010: emit parallel slot_types so both snakemake_gen and
            # run_step can consult the contract-declared type as the single
            # source of truth for directory-slot detection.
            slot_types[slot_name] = slot_type

        nodes.append({
            "id": node.id,
            "method": node.method,
            "module": node.module or "",
            "script": script_path or f"methods/{node.method}/{node.method}.py",
            "params": node.params,
            "slot_outputs": slot_outputs,
            "slot_types": slot_types,
            "env": info.get("env", "inherit"),
        })

    links = []
    for link in pipeline.links:
        l: Dict[str, str] = {"source": link.source, "target": link.target}
        if link.sourceHandle:
            l["source_slot"] = link.sourceHandle
        if link.targetHandle:
            l["target_slot"] = link.targetHandle
        links.append(l)

    return {"nodes": nodes, "links": links, "samples": pipeline.samples}


def _require_provider() -> PmProvider:
    if _pm_provider is None:
        raise HTTPException(
            status_code=400,
            detail="No pm project configured. Call POST /api/pm/load first.",
        )
    return _pm_provider


# ---------------------------------------------------------------------------
# Lifespan -- auto-load provider from cwd on startup
# ---------------------------------------------------------------------------


def _switch_db(project_root: Path) -> None:
    """Update DATABASE_URL env var and reset the SQLAlchemy engine to point at
    a different project's pm.db.  Called on auto-load and on POST /api/pm/load."""
    from ..database import reset_engine
    new_url = f"sqlite:///{project_root / '.pm' / 'pm.db'}"
    os.environ["DATABASE_URL"] = new_url
    reset_engine()


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _pm_provider
    # Prefer explicit project root from CLI (--project-root) over the resolved
    # workflow-canvas root.  Never use Path.cwd() directly — cwd may shift or
    # be rewritten (e.g. C:\Windows on Snakemake subprocess spawns).
    from ..database import project_root as _resolve_project_root
    env_root = os.environ.get("PM_CANVAS_PROJECT_ROOT")
    if env_root:
        project_root = Path(env_root)
    else:
        try:
            project_root = _resolve_project_root()
        except RuntimeError:
            project_root = Path.cwd()
    db_path = project_root / ".pm" / "pm.db"
    if db_path.exists():
        try:
            _pm_provider = PmProvider(str(project_root))
            _pm_provider.load()
            _switch_db(project_root)
            print(f"[canvas] Auto-loaded pm project from {project_root}")
        except Exception as exc:  # pragma: no cover
            print(f"[canvas] Warning: auto-load failed: {exc}")
    else:
        print(
            f"[canvas] No .pm/pm.db found in {project_root} "
            "-- use POST /api/pm/load to configure"
        )
    yield


app = FastAPI(title="Workflow Canvas", lifespan=lifespan)


# =============================================================================
# Data-type metadata  (slot colouring in the canvas UI)
# =============================================================================

DATA_TYPES = {
    "anndata":     {"color": "#4A90D9", "label": "AnnData"},
    "labels":      {"color": "#E9A847", "label": "Labels"},
    "feature_set": {"color": "#50C878", "label": "FeatureSet"},
    "array":       {"color": "#9B59B6", "label": "Array"},
    "figure":      {"color": "#E74C3C", "label": "Figure"},
    "dataframe":   {"color": "#F39C12", "label": "DataFrame"},
    "path":        {"color": "#1ABC9C", "label": "Path"},
    "string":      {"color": "#95A5A6", "label": "String"},
    "number":      {"color": "#95A5A6", "label": "Number"},
}


# =============================================================================
# Pydantic models
# =============================================================================


class PipelineNode(BaseModel):
    id: str
    method: str
    module: Optional[str] = None
    params: Dict[str, Any] = {}
    position: Optional[Dict[str, float]] = None


class PipelineLink(BaseModel):
    source: str
    target: str
    sourceHandle: Optional[str] = None
    targetHandle: Optional[str] = None


class PipelineInput(BaseModel):
    name: Optional[str] = None
    nodes: List[PipelineNode]
    links: List[PipelineLink] = []
    samples: List[str] = []


class WorkflowResponse(BaseModel):
    status: str
    job_id: str
    message: str


class PmConfig(BaseModel):
    project_root: str


class ExportCSVsRequest(BaseModel):
    run_ids: Optional[List[str]] = None


class ExportArtifactsRequest(BaseModel):
    run_ids: Optional[List[str]] = None
    file_types: Optional[List[str]] = None


# =============================================================================
# Modules endpoint -- live DB query, no provider required
# =============================================================================


@app.get("/api/modules")
async def get_modules():
    """Return modules as a nested dict keyed by module/method name for the builder UI.

    Shape: {moduleName: {description, methods: {methodName: {inputs, outputs, ...}}}}
    This matches what nodes.js / populateModulePalette() expect.
    """
    with get_session() as session:
        modules = session.exec(select(Module)).all()
        result: Dict[str, Any] = {}
        for mod in modules:
            methods_dict: Dict[str, Any] = {}
            for meth in mod.methods:
                mc: Optional[MethodContract] = meth.contract
                methods_dict[meth.name] = {
                    "inputs":        mc.input_slots   if mc else {},
                    "outputs":       mc.output_slots  if mc else {},
                    "version":       "1.0.0",
                    "description":   f"{mod.name} — {meth.name}",
                    "params_schema": mc.params_schema if mc else {},
                    "env":           meth.env,
                    "executor":      mc.executor      if mc else "python",
                }
            result[mod.name] = {
                "description": mod.description or mod.name,
                "methods": methods_dict,
            }
    return result


@app.get("/api/types")
async def get_types():
    """Return data-type metadata for canvas UI slot colouring."""
    return DATA_TYPES


# =============================================================================
# Canvas SPA
# =============================================================================


@app.get("/")
async def root():
    """Serve the main SPA page."""
    return FileResponse(_STATIC_DIR / "index.html")


# =============================================================================
# Workflow builder endpoints
# =============================================================================


@app.post("/api/workflow/validate")
async def validate_workflow(pipeline: PipelineInput):
    """Validate a pipeline graph against registered methods in the DB."""
    errors: List[str] = []
    warnings: List[str] = []

    if not pipeline.nodes:
        errors.append("Pipeline has no nodes")
        return {"valid": False, "errors": errors, "warnings": warnings}

    with get_session() as session:
        modules_db = {m.name: m for m in session.exec(select(Module)).all()}
        # Eagerly load methods and contracts within the session
        method_lookup: Dict[str, Any] = {}
        for mod in modules_db.values():
            for meth in mod.methods:
                key = f"{mod.name}.{meth.name}"
                method_lookup[key] = {
                    "contract": meth.contract,
                    "module": mod.name,
                    "method": meth.name,
                }

    for node in pipeline.nodes:
        mod_name = node.module or ""
        key = f"{mod_name}.{node.method}"
        info = method_lookup.get(key)
        if info is None:
            errors.append(f"Unknown method: {mod_name}.{node.method!r}")
            continue
        mc = info["contract"]
        if mc and mc.input_slots:
            for slot_name, slot_spec in mc.input_slots.items():
                if slot_spec.get("required", True):
                    connected = any(
                        l.target == node.id and l.targetHandle == slot_name
                        for l in pipeline.links
                    )
                    if not connected:
                        warnings.append(
                            f"{node.method}: required input slot {slot_name!r} is not connected"
                        )

    return {"valid": len(errors) == 0, "errors": errors, "warnings": warnings}


@app.post("/api/workflow/run")
async def run_workflow(pipeline: PipelineInput):
    """Submit a pipeline for execution via Snakemake.

    Enriches the PipelineJSON with script paths and slot_outputs from the DB,
    writes it to a temp file, and spawns a background thread running
    ``run_pipeline()``. Returns the pipeline_id as the job_id immediately.

    Rejects empty pipelines with HTTP 400.  Multiple pipelines may run
    concurrently — each gets its own pipeline_id-scoped workspace.
    """
    if not pipeline.nodes:
        raise HTTPException(status_code=400, detail="Pipeline has no nodes")

    # Enrich nodes with script paths and slot_outputs from DB
    pipeline_json = _enrich_pipeline(pipeline)
    pipeline_id = str(uuid.uuid4())

    from ..database import project_root as _resolve_project_root
    env_root = os.environ.get("PM_CANVAS_PROJECT_ROOT")
    if env_root:
        project_root = env_root
    else:
        try:
            project_root = str(_resolve_project_root())
        except RuntimeError:
            project_root = str(Path.cwd())
    pipeline_dir = Path(project_root) / ".runs" / "pipelines" / pipeline_id
    pipeline_dir.mkdir(parents=True, exist_ok=True)

    pipeline_path = pipeline_dir / "pipeline.json"
    pipeline_path.write_text(json.dumps(pipeline_json, indent=2), encoding="utf-8")

    # Build step mapping: node_id -> method_name (for frontend status tracking)
    step_map = {n.id: n.method for n in pipeline.nodes}

    def _run_in_background():
        """Execute the pipeline in a background thread."""
        try:
            _rp = run_pipeline_fn()
            _rp(
                pipeline_path=str(pipeline_path),
                project_root=project_root,
                pipeline_id=pipeline_id,
                capture_output=True,
            )
        except Exception as exc:
            # Record failure -- fail_pipeline marks in-flight runs
            try:
                _fp = fail_pipeline_fn()
                _fp(pipeline_id)
            except Exception:
                pass  # Best-effort cleanup
            _active_jobs[pipeline_id]["error"] = str(exc)

    thread = threading.Thread(target=_run_in_background, daemon=True)
    _active_jobs[pipeline_id] = {
        "thread": thread,
        "pipeline_id": pipeline_id,
        "step_map": step_map,
        "log_dir": str(pipeline_dir),
        "error": None,
    }
    thread.start()

    return {
        "status": "submitted",
        "job_id": pipeline_id,
        "message": f"Pipeline '{pipeline.name or 'unnamed'}' submitted ({len(pipeline.nodes)} nodes)",
        "step_map": step_map,
    }


@app.get("/api/workflow/status/{job_id}")
async def get_workflow_status(job_id: str):
    """Return per-step and overall status for a running or completed pipeline.

    Queries the ``runs`` table by ``pipeline_id`` and derives overall status.
    Also returns whether the background thread is still alive and any captured
    log output.

    Args:
        job_id: The pipeline_id returned by the run endpoint.

    Returns:
        JSON with ``job_id``, ``overall_status``, ``steps``, ``thread_alive``,
        ``log``, and ``error`` fields.
    """
    if job_id not in _active_jobs:
        raise HTTPException(status_code=404, detail=f"Unknown job: {job_id}")

    job_info = _active_jobs[job_id]
    thread = job_info.get("thread")
    thread_alive = thread.is_alive() if thread else False
    log_dir = job_info.get("log_dir")
    job_error = job_info.get("error")

    # Query runs table for this pipeline
    steps: Dict[str, str] = {}
    with get_session() as session:
        runs = session.exec(
            select(Run).where(Run.pipeline_id == job_id)
        ).all()
        for run in runs:
            # Look up method name via relationship
            method = run.method
            if method:
                steps[method.name] = run.status
            else:
                steps[f"method_{run.method_id}"] = run.status

    # Derive overall status
    statuses = list(steps.values()) if steps else []
    if not statuses:
        overall = "pending"
    elif any(s == "failed" for s in statuses):
        overall = "failed"
    elif any(s == "running" for s in statuses):
        overall = "running"
    elif all(s == "completed" for s in statuses):
        overall = "completed"
    else:
        overall = "running"

    # If thread is dead and no runs exist or overall is pending,
    # and there was an error, mark as failed
    if not thread_alive and job_error and overall == "pending":
        overall = "failed"

    # Read log files if available
    log_content = ""
    if log_dir:
        log_path = Path(log_dir)
        stdout_log = log_path / "stdout.log"
        stderr_log = log_path / "stderr.log"
        if stdout_log.exists():
            log_content += stdout_log.read_text(encoding="utf-8", errors="replace")
        if stderr_log.exists():
            stderr_text = stderr_log.read_text(encoding="utf-8", errors="replace")
            if stderr_text:
                log_content += "\n--- STDERR ---\n" + stderr_text

    return {
        "job_id": job_id,
        "overall_status": overall,
        "steps": steps,
        "thread_alive": thread_alive,
        "log": log_content,
        "error": job_error,
    }


@app.post("/api/workflow/save")
async def save_workflow(workflow: Workflow):
    """Save a workflow definition."""
    return {"status": "saved", "name": workflow.name}


# =============================================================================
# PM Provider -- configure / reload
# =============================================================================


@app.post("/api/pm/load")
async def load_pm_data(config: PmConfig):
    """Load (or reload) the pm provider from a project path.

    Also updates DATABASE_URL and resets the SQLAlchemy engine so that
    GET /api/modules queries this project's DB, not the server's launch-cwd DB.
    """
    global _pm_provider
    try:
        _pm_provider = PmProvider(config.project_root)
        _pm_provider.load()
        # Point the SQLAlchemy session at the loaded project's DB
        _switch_db(Path(config.project_root))
        return {
            "status": "loaded",
            "path": config.project_root,
            "modules": len(_pm_provider.get_modules()),
            "methods": len(_pm_provider.get_methods()),
            "runs": len(_pm_provider.get_all_runs()),
        }
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@app.post("/api/pm/refresh")
async def refresh_pm_data():
    """Reload pm data from the current project root."""
    prov = _require_provider()
    try:
        prov.load()
        return {
            "status": "refreshed",
            "path": str(prov.project_root),
            "modules": len(prov.get_modules()),
            "runs": len(prov.get_all_runs()),
        }
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


# =============================================================================
# PM History endpoints
# =============================================================================


@app.get("/api/pm/status")
async def get_pm_status():
    if _pm_provider is None:
        return {"loaded": False, "path": None}
    return {
        "loaded": True,
        "path": str(_pm_provider.project_root),
        "modules": len(_pm_provider.get_modules()),
        "runs": len(_pm_provider.get_all_runs()),
    }


@app.get("/api/pm/runs")
async def get_pm_runs():
    return _require_provider().get_all_runs()


@app.get("/api/pm/experiments")
async def get_pm_experiments():
    return _require_provider().get_experiments()


@app.get("/api/pm/run/{run_id}")
async def get_pm_run(run_id: str):
    run = _require_provider().get_run(run_id)
    if run is None:
        raise HTTPException(status_code=404, detail=f"Run not found: {run_id}")
    return run


@app.get("/api/pm/lineage/{run_id}")
async def get_pm_lineage(run_id: str):
    return _require_provider().get_lineage(run_id)


@app.get("/api/pm/tree/{run_id}")
async def get_pm_run_tree(run_id: str):
    return _require_provider().get_run_tree(run_id)


@app.get("/api/pm/modules")
async def get_pm_modules():
    return _require_provider().get_modules()


@app.get("/api/pm/datasources")
async def get_pm_datasources():
    return _require_provider().get_data_sources()


@app.get("/api/pm/methods")
async def get_pm_methods():
    return _require_provider().get_methods()


@app.get("/api/pm/run/{run_id}/artifacts")
async def list_pm_artifacts(run_id: str):
    return _require_provider().list_artifacts(run_id)


@app.get("/api/pm/run/{run_id}/artifact/{artifact_path:path}")
async def get_pm_artifact(run_id: str, artifact_path: str):
    file_path = _require_provider().get_artifact_path(run_id, artifact_path)
    if file_path is None or not file_path.exists():
        raise HTTPException(status_code=404, detail=f"Artifact not found: {artifact_path}")
    return FileResponse(file_path)


# =============================================================================
# Artifact export helpers
# =============================================================================


def _sanitize(name: str) -> str:
    for ch in ['<', '>', ':', '"', '|', '?', '*', '\\', '/']:
        name = name.replace(ch, '_')
    return name.strip().strip('.')


def _build_artifact_zip(artifacts: list) -> io.BytesIO:
    buf = io.BytesIO()
    seen: set = set()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as zf:
        for item in artifacts:
            method = _sanitize(item['method'])
            run_name = _sanitize(item['run_name'])
            aname = _sanitize(item['artifact_name'])
            zip_path = f"{method}/{run_name}/{aname}"
            if zip_path in seen:
                base, _, ext = aname.rpartition('.')
                zip_path = f"{method}/{run_name}/{base}_{item['run_id'][:8]}.{ext}"
            seen.add(zip_path)
            if os.path.exists(item['file_path']):
                zf.write(item['file_path'], zip_path)
    buf.seek(0)
    return buf


def _build_preview_response(artifacts: list) -> dict:
    methods: set = set()
    runs: set = set()
    total_size = 0
    by_type: dict = {}
    for item in artifacts:
        methods.add(item['method'])
        runs.add(item['run_id'])
        fp = item.get('file_path', '')
        if fp and os.path.exists(fp):
            size = item.get('size_bytes', os.path.getsize(fp))
            total_size += size
            ext = item.get('extension', item.get('artifact_name', '').rsplit('.', 1)[-1].lower())
            entry = by_type.setdefault(ext, {'count': 0, 'size_bytes': 0})
            entry['count'] += 1
            entry['size_bytes'] += size
    return {
        "total_count": len(artifacts),
        "run_count": len(runs),
        "method_count": len(methods),
        "total_size_bytes": total_size,
        "methods": sorted(methods),
        "by_type": [
            {"ext": e, "count": d["count"], "size_bytes": d["size_bytes"]}
            for e, d in sorted(by_type.items())
        ],
        "files": [
            {
                "method": a['method'],
                "run_name": a['run_name'],
                "artifact": a['artifact_name'],
                "ext": a.get('extension', a.get('artifact_name', '').rsplit('.', 1)[-1].lower()),
                "size_bytes": a.get('size_bytes', 0),
            }
            for a in artifacts
        ],
    }


@app.post("/api/pm/export-artifacts")
async def export_pm_artifacts(request: ExportArtifactsRequest):
    """Zip download of pm run artifacts, optionally filtered by file type."""
    prov = _require_provider()
    artifacts = prov.get_artifacts(request.run_ids, extensions=request.file_types)
    if not artifacts:
        raise HTTPException(status_code=404, detail="No matching files found.")
    buf = _build_artifact_zip(artifacts)
    ts = datetime.now().strftime('%Y-%m-%d_%H%M%S')
    return StreamingResponse(
        buf,
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="pm_export_{ts}.zip"'},
    )


@app.post("/api/pm/preview-artifacts")
async def preview_pm_artifacts(request: ExportArtifactsRequest):
    """Preview what would be exported (all file types) without downloading."""
    return _build_preview_response(_require_provider().get_artifacts(request.run_ids))


@app.post("/api/pm/export-csvs")
async def export_pm_csvs(request: ExportCSVsRequest):
    """Zip download of CSV artifacts from pm runs."""
    prov = _require_provider()
    artifacts = prov.get_csv_artifacts(request.run_ids)
    if not artifacts:
        raise HTTPException(status_code=404, detail="No CSV files found.")
    buf = _build_artifact_zip(artifacts)
    ts = datetime.now().strftime('%Y-%m-%d_%H%M%S')
    return StreamingResponse(
        buf,
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="pm_export_{ts}.zip"'},
    )


@app.post("/api/pm/preview-csvs")
async def preview_pm_csvs(request: ExportCSVsRequest):
    """Preview CSV export (counts + sizes) without downloading."""
    return _build_preview_response(_require_provider().get_csv_artifacts(request.run_ids))


# =============================================================================
# Static files -- must come last (acts as catch-all for the SPA)
# =============================================================================

app.mount("/", StaticFiles(directory=str(_STATIC_DIR), html=True), name="static")
