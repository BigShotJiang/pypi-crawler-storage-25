"""
pm/version.py — Content-addressed versioning and input fingerprinting.

Five public functions:
  get_git_commit(repo_path)             Fail-fast on dirty working tree.
  build_code_fingerprint(method_source_dir)  SHA256 of method source files.
  get_or_create_version(method_id, code_fingerprint, git_commit)
  build_input_fingerprint(upstream_run_ids, sample_ids)
  build_cache_key(code_fingerprint, params, input_fingerprint)

Design notes (aligned with design/l2/gaps.md § Gap 15):
  - get_git_commit raises DirtyRepositoryError if there are uncommitted changes.
    Commit-then-run is the intended discipline; there is no --allow-dirty escape hatch.
  - build_code_fingerprint hashes .py files from the registered method copy,
    sorted by relative path.  This makes cache keys stable across non-code commits.
  - build_input_fingerprint uses upstream Run.cache_key (deterministic chain),
    NOT RunOutput.content_hash.  content_hash is archival-only.
    sorted() on the parts list is load-bearing, not an optimisation —
    DB row order is not guaranteed. Changing it silently breaks cache keys.
  - cache_key = SHA256(code_fingerprint + json.dumps(params, sort_keys=True) + fingerprint)
  - git_commit is retained as optional audit metadata on MethodVersion, not part of cache key.
"""

from __future__ import annotations

import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Sequence

from sqlalchemy.exc import IntegrityError
from sqlmodel import select

from .database import get_session, project_root
from .models import MethodVersion, Run, RunOutput, Sample


# =============================================================================
# Exceptions
# =============================================================================

class DirtyRepositoryError(RuntimeError):
    """Raised when the git working tree has uncommitted changes.

    The fix is always ``git commit`` (or ``git stash``), never a bypass flag.
    """


# =============================================================================
# Public API
# =============================================================================

def get_git_commit(repo_path: Path | str | None = None) -> str:
    """Return the current HEAD git commit SHA (40 hex chars).

    Args:
        repo_path: Directory within the git repository. Defaults to the
            resolved workflow-canvas project root (not ``Path.cwd()`` — the
            Snakemake hot path runs with cwd rewritten to ``C:\\Windows`` on
            Windows and ``pm run-step`` must still find the real repo).

    Returns:
        40-character SHA1 hex string.

    Raises:
        DirtyRepositoryError: If the working tree has uncommitted changes.
        RuntimeError: If git is not available or the path is not a git repo.
    """
    if repo_path is None:
        repo_path = project_root()
    cwd = str(repo_path)

    # Fail-fast: check working tree first
    status = subprocess.run(
        ["git", "status", "--porcelain"],
        cwd=cwd,
        capture_output=True,
        text=True,
    )
    if status.returncode != 0:
        raise RuntimeError(
            f"git status failed in {cwd!r}: {status.stderr.strip()}"
        )
    # Only tracked-file changes (modified, staged, deleted, renamed) block the
    # run.  Untracked files (??) do not affect the commit SHA cache key, so
    # they are ignored here.
    tracked_dirty = [
        line for line in status.stdout.strip().splitlines()
        if line[:2].strip() and not line.startswith("??")
    ]
    if tracked_dirty:
        dirty_lines = "\n".join(f"    {line}" for line in tracked_dirty)
        raise DirtyRepositoryError(
            "Working tree has uncommitted changes to tracked files — commit before running.\n"
            f"  Dirty files:\n{dirty_lines}"
        )

    result = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=cwd,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"git rev-parse HEAD failed in {cwd!r}: {result.stderr.strip()}"
        )
    return result.stdout.strip()


def build_code_fingerprint(method_source_dir: Path | str) -> str:
    """Build a SHA256 fingerprint of a method's source files.

    Walks the method source directory, reads all ``.py`` files, sorts them
    by relative path (load-bearing for determinism), concatenates their
    contents, and returns a SHA256 hex digest.

    This function is the content-addressed replacement for using git_commit
    as the code identity component in cache keys.  The directory should be
    the registered copy under ``methods/{method_name}/``.

    Args:
        method_source_dir: Path to the directory containing the method's
            registered source files.

    Returns:
        64-char hex SHA256 string.

    Raises:
        ValueError: If the directory does not exist or contains no ``.py`` files.
    """
    source_dir = Path(method_source_dir)
    if not source_dir.is_dir():
        raise ValueError(
            f"Method source directory does not exist: {source_dir}"
        )

    # Collect all .py files, sorted by relative path for determinism
    py_files = sorted(
        source_dir.rglob("*.py"),
        key=lambda p: p.relative_to(source_dir).as_posix(),
    )
    if not py_files:
        raise ValueError(
            f"Method source directory contains no .py files: {source_dir}"
        )

    hasher = hashlib.sha256()
    for py_file in py_files:
        rel_path = py_file.relative_to(source_dir).as_posix()
        content = py_file.read_text(encoding="utf-8")
        hasher.update(f"{rel_path}:{content}".encode("utf-8"))

    return hasher.hexdigest()


def get_or_create_version(method_id: int, code_fingerprint: str, git_commit: str | None = None) -> int:
    """Return MethodVersion.id for (method_id, code_fingerprint), creating if needed.

    The DB UniqueConstraint on (method_id, code_fingerprint) is the safety net;
    this function provides the upsert logic on top.  Concurrent callers (e.g. 4+
    parallel Snakemake workers sharing the same method/fingerprint) will race on
    the INSERT -- the loser catches IntegrityError and re-SELECTs the winning row.

    Args:
        method_id: Database ID of the Method row.
        code_fingerprint: 64-char SHA256 hex digest from build_code_fingerprint().
        git_commit: Optional 40-char git commit SHA for audit metadata.  Stored
            on the MethodVersion row but not used for identity or cache keys.

    Returns:
        MethodVersion.id (integer).
    """
    # Fast path: row already exists (common case after first worker wins).
    with get_session() as session:
        existing = session.exec(
            select(MethodVersion).where(
                MethodVersion.method_id == method_id,
                MethodVersion.code_fingerprint == code_fingerprint,
            )
        ).first()
        if existing is not None:
            return existing.id  # type: ignore[return-value]

    # Slow path: try to INSERT, fall back to SELECT if another worker beat us.
    try:
        with get_session() as session:
            version = MethodVersion(
                method_id=method_id,
                code_fingerprint=code_fingerprint,
                git_commit=git_commit,
                recorded_at=datetime.now(timezone.utc),
            )
            session.add(version)
            session.commit()
            session.refresh(version)
            return version.id  # type: ignore[return-value]
    except IntegrityError:
        # Another concurrent worker inserted the same (method_id, code_fingerprint)
        # first — retrieve their row.
        with get_session() as session:
            existing = session.exec(
                select(MethodVersion).where(
                    MethodVersion.method_id == method_id,
                    MethodVersion.code_fingerprint == code_fingerprint,
                )
            ).first()
            if existing is None:  # pragma: no cover — should be impossible
                raise RuntimeError(
                    f"get_or_create_version: INSERT failed with IntegrityError "
                    f"but follow-up SELECT found nothing for "
                    f"method_id={method_id}, code_fingerprint={code_fingerprint!r}"
                )
            return existing.id  # type: ignore[return-value]


def build_input_fingerprint(
    upstream_run_ids: Sequence[int],
    sample_ids: Sequence[int] | None = None,
    label: str | None = None,
    strict: bool = False,
) -> str:
    """Build a SHA256 fingerprint of all inputs to a run.

    Uses upstream Run.cache_key (deterministic cache key chain) instead of
    RunOutput.content_hash.  This decouples cache validity from archival
    state -- NULL content_hash (deferred archiving) has no effect on
    fingerprint computation.

    The cache key chain is deterministic: each node's cache_key is
    SHA256(code_fingerprint + params + upstream_cache_keys).  Using
    upstream cache_key here closes the chain.

    Handles both upstream Run rows (downstream nodes) and Sample rows
    (root nodes) in one call -- caller never branches.

    ``sorted()`` on the parts list is **load-bearing**, not an optimisation --
    DB row order is not guaranteed and will silently break cache key stability.

    Args:
        upstream_run_ids: IDs of upstream Run rows. Empty list for root nodes.
        sample_ids: IDs of Sample rows. Provided for root nodes only.
        label: Optional label for fingerprint context (unused, reserved).
        strict: If True, raise on missing data (unused, reserved).

    Returns:
        64-char hex SHA256 string.
    """
    parts: list[str] = []

    with get_session() as session:
        for run_id in upstream_run_ids:
            run = session.get(Run, run_id)
            if run is None:
                continue
            if run.cache_key:
                parts.append(f"key:{run.cache_key}")
            else:
                # Upstream run predates cache key integration -- use a
                # sentinel so the fingerprint is still deterministic
                # (always produces the same value for this run).
                parts.append(f"key:legacy-run-{run_id}")

        for sid in (sample_ids or []):
            sample = session.get(Sample, sid)
            if sample is None:
                continue
            path = sample.registered_path or ""
            size = sample.file_size or 0
            mtime = sample.file_mtime or 0.0
            parts.append(f"{path}:{size}:{mtime}")

    return hashlib.sha256(",".join(sorted(parts)).encode()).hexdigest()


def build_cache_key(
    code_fingerprint: str,
    params: dict,
    input_fingerprint: str,
) -> str:
    """Build a SHA256 cache key for a run.

    Pure function -- no DB access.  Uses the content-addressed code fingerprint
    (not git commit) so that unrelated commits do not invalidate cache keys.

    Args:
        code_fingerprint: 64-char SHA256 hex digest from build_code_fingerprint().
        params: Parameter dict for this run (serialised deterministically).
        input_fingerprint: Output of build_input_fingerprint().

    Returns:
        64-char hex SHA256 string.
    """
    raw = code_fingerprint + json.dumps(params, sort_keys=True) + input_fingerprint
    return hashlib.sha256(raw.encode()).hexdigest()
