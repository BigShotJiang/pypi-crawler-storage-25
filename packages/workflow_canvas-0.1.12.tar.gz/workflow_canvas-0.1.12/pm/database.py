"""
Database engine and session management.

Uses DATABASE_URL env var (defaults to SQLite at <project_root>/.pm/pm.db).
Auto-creates all tables on first access.

Project-root resolution is explicit (not cwd-derived): see ``project_root()``.
This matters for any pm subprocess whose cwd is not the project — notably
Snakemake-spawned shell rules under Windows UNC paths, where cmd.exe silently
rewrites cwd to C:\\Windows\\ and the old cwd-based resolver tried to mkdir
``C:\\Windows\\.pm``.
"""

import os
from contextlib import contextmanager
from pathlib import Path

from sqlmodel import SQLModel, Session, create_engine

# Import all models so SQLModel.metadata knows about them
from .models import (  # noqa: F401
    Module, Method, MethodVersion, TrackedFunction, ParamDef,
    Run, RunInput, RunOutput, Sample, ModuleContract, MethodContract,
)

_engine = None
_project_root_cache: Path | None = None


def project_root() -> Path:
    """Resolve the pm project root directory.

    Precedence:
      1. ``PM_PROJECT_ROOT`` environment variable, if set (must point at a
         directory containing ``.pm/wf-canvas.toml``).
      2. Walk upward from ``Path.cwd()`` looking for a ``.pm/wf-canvas.toml``
         marker.
      3. Raise ``RuntimeError`` — do not silently create ``.pm/`` in a wrong
         directory.

    Result is cached per-process. Call ``reset_engine()`` to clear the cache
    in tests.
    """
    global _project_root_cache
    if _project_root_cache is not None:
        return _project_root_cache

    env = os.environ.get("PM_PROJECT_ROOT")
    if env:
        root = Path(env).resolve()
        marker = root / ".pm" / "wf-canvas.toml"
        if not marker.exists():
            raise RuntimeError(
                f"PM_PROJECT_ROOT={root} does not contain .pm/wf-canvas.toml — "
                f"not a workflow-canvas project"
            )
        _project_root_cache = root
        return root

    start = Path.cwd().resolve()
    for candidate in (start, *start.parents):
        if (candidate / ".pm" / "wf-canvas.toml").exists():
            _project_root_cache = candidate
            return candidate

    raise RuntimeError(
        f"Could not resolve workflow-canvas project root from cwd={start}. "
        f"Set PM_PROJECT_ROOT or run pm from a directory inside a project "
        f"(one containing .pm/wf-canvas.toml)."
    )


def _default_db_url() -> str:
    """SQLite at ``<project_root>/.pm/pm.db``."""
    db_dir = project_root() / ".pm"
    db_dir.mkdir(exist_ok=True)
    return f"sqlite:///{db_dir / 'pm.db'}"


def get_engine():
    """Get or create the global SQLAlchemy engine."""
    global _engine
    if _engine is None:
        url = os.environ.get("DATABASE_URL") or _default_db_url()
        # SQLite needs check_same_thread=False for multi-thread use
        connect_args = {}
        if url.startswith("sqlite"):
            connect_args["check_same_thread"] = False
        _engine = create_engine(url, connect_args=connect_args)
        SQLModel.metadata.create_all(_engine)
    return _engine


@contextmanager
def get_session():
    """Yield a transactional DB session."""
    engine = get_engine()
    with Session(engine) as session:
        yield session


def reset_engine():
    """Reset engine and project-root cache (for tests)."""
    global _engine, _project_root_cache
    if _engine is not None:
        _engine.dispose()
    _engine = None
    _project_root_cache = None


def runs_dir() -> Path:
    """Return (and create) the ``.runs/`` artifact store under the project root."""
    d = project_root() / ".runs"
    d.mkdir(exist_ok=True)
    return d
