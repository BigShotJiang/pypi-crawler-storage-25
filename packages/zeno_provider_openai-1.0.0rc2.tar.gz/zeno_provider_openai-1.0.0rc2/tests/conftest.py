"""Shared fixtures for `zeno-provider-openai` tests.

Under `--import-mode=importlib` the test modules cannot `from conftest
import ...` directly. Every helper the tests reach for is therefore exposed
either as a pytest fixture or a tiny, re-importable module helper. The
pattern mirrors `zeno-channel-sendblue/tests/conftest.py`.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from datetime import UTC, datetime

import httpx
import pytest
from zeno.channels.messages import IncomingMessage
from zeno.context import Ctx
from zeno.memory.handles import (
    ConversationHandle,
    KnowledgeView,
    MemoryView,
    SessionHandle,
    UserMemoryView,
)
from zeno.testing import InMemoryConversationStore


class _FakeUserStore:
    async def search(self, user_id: str, query: str, k: int = 5) -> list[object]:
        return []

    async def add(self, user_id: str, text: str, meta: dict[str, object] | None = None) -> None:
        return None


class _FakeKnowledgeStore:
    async def search(self, user_id: str, query: str, k: int = 5) -> list[object]:
        return []

    async def add(self, user_id: str, text: str, meta: dict[str, object] | None = None) -> None:
        return None


class _FakeSessionStore:
    async def get(self, user_id: str, channel: str, thread_key: str | None) -> object | None:
        return None

    async def get_or_create(
        self,
        user_id: str,
        channel: str,
        thread_key: str | None,
        sdk_session_id_factory: object,
    ) -> object:
        raise NotImplementedError

    async def touch(self, record: object, summary: str | None = None) -> None:
        return None


def _make_memory_view(
    *,
    user_id: str = "u1",
    thread_key: str | None = "t1",
    conversation_store: InMemoryConversationStore | None = None,
) -> MemoryView:
    store = conversation_store or InMemoryConversationStore()
    return MemoryView(
        user=UserMemoryView(_store=_FakeUserStore(), _user_id=user_id),
        knowledge=KnowledgeView(_store=_FakeKnowledgeStore(), _user_id=user_id),
        session=SessionHandle(
            _store=_FakeSessionStore(),
            _user_id=user_id,
            _channel="test",
            _thread_key=thread_key,
        ),
        conversation=ConversationHandle(_store=store, _user_id=user_id, _thread_key=thread_key),
    )


class RecordingTracer:
    """Tracer stand-in that captures every event in an ordered list."""

    def __init__(self) -> None:
        self.events: list[object] = []

    def on_event(self, event: object) -> None:
        self.events.append(event)


def _make_ctx(
    *,
    http: httpx.AsyncClient,
    memory: MemoryView,
    tracer: RecordingTracer | None = None,
    composed_prompt: str | None = None,
    stream_sink: list[str] | None = None,
    finalize_sink: list[int] | None = None,
) -> Ctx:
    async def _stream(text: str) -> None:
        if stream_sink is not None:
            stream_sink.append(text)

    async def _reply(_msg: object) -> None:
        return None

    async def _finalize() -> None:
        if finalize_sink is not None:
            finalize_sink.append(1)

    state: dict[str, object] = {}
    if composed_prompt is not None:
        state["composed_prompt"] = composed_prompt

    return Ctx(
        user_id="u1",
        session_id=None,
        channel="test",
        memory=memory,
        reply=_reply,
        stream=_stream,
        finalize=_finalize,
        http=http,
        logger=None,
        tracer=tracer,
        state=state,
    )


def _make_msg(
    text: str = "hello",
    *,
    user_id: str = "u1",
    thread_key: str | None = "t1",
) -> IncomingMessage:
    return IncomingMessage(
        user_id=user_id,
        text=text,
        received_at=datetime.now(UTC),
        thread_key=thread_key,
    )


Handler = Callable[[httpx.Request], httpx.Response]
AsyncHandler = Callable[[httpx.Request], Awaitable[httpx.Response]]


def _transport_client(handler: Handler | AsyncHandler) -> httpx.AsyncClient:
    transport = httpx.MockTransport(handler)
    return httpx.AsyncClient(transport=transport)


def _sse_lines(*chunks: str) -> bytes:
    body = ""
    for chunk in chunks:
        body += f"data: {chunk}\n\n"
    return body.encode("utf-8")


@pytest.fixture
def conv_store() -> InMemoryConversationStore:
    return InMemoryConversationStore()


@pytest.fixture
def tracer() -> RecordingTracer:
    return RecordingTracer()


@pytest.fixture
def make_memory_view() -> Callable[..., MemoryView]:
    return _make_memory_view


@pytest.fixture
def make_ctx() -> Callable[..., Ctx]:
    return _make_ctx


@pytest.fixture
def make_msg() -> Callable[..., IncomingMessage]:
    return _make_msg


@pytest.fixture
def transport_client() -> Callable[..., httpx.AsyncClient]:
    return _transport_client


@pytest.fixture
def sse_lines() -> Callable[..., bytes]:
    return _sse_lines
