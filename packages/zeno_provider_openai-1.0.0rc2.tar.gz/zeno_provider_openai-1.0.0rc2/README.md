# zeno-provider-openai

OpenAI-compatible Chat Completions provider for Zeno. One adapter covers every
vendor that speaks the OpenAI REST shape: OpenAI, OpenRouter, LiteLLM, Azure v1,
Ollama, vLLM, and anything that clones the wire protocol.

## Install

```bash
uv add 'zeno-framework[openai]'
```

## Usage

```python
from zeno.agent import Agent
from zeno.app import ZenoApp
from zeno.channels.cli.channel import CliChannel
from zeno.providers.openai import OpenAIProvider

app = ZenoApp(
    agent=Agent(name="root", instructions="..."),
    channels=[CliChannel()],
    provider=OpenAIProvider(
        api_key="sk-...",
        base_url="https://api.openai.com/v1",
        model="gpt-5.1",
    ),
)
```

Swap providers without changing your `Agent`:

```python
# OpenRouter
OpenAIProvider(
    api_key="...",
    base_url="https://openrouter.ai/api/v1",
    model="anthropic/claude-4.7-sonnet",
    extra_headers={"HTTP-Referer": "https://yourapp", "X-Title": "yourapp"},
)

# LiteLLM
OpenAIProvider(api_key="...", base_url="http://litellm:4000/v1", model="anthropic/claude-4.7-sonnet")

# Azure v1 (/openai/v1/ surface)
OpenAIProvider(api_key="...", base_url="https://YOUR.openai.azure.com/openai/v1", model="gpt-5.1")

# Ollama — non-streaming when tools are present (known upstream bug)
OpenAIProvider(api_key="ollama", base_url="http://localhost:11434/v1", model="llama4",
               disable_stream_with_tools=True)
```

## Compatibility matrix

| Target        | Streaming | Tools (native) | Tools-with-streaming | Notes |
|---------------|-----------|----------------|----------------------|-------|
| OpenAI        | Yes       | Yes            | Yes                  | Reference |
| OpenRouter    | Yes       | Yes            | Yes                  | Optional `HTTP-Referer` / `X-Title` headers |
| LiteLLM       | Yes       | Yes            | Yes                  | Handles model translation server-side |
| Azure v1      | Yes       | Yes            | Yes                  | Use the v1 surface (`/openai/v1/...`) |
| Ollama        | Yes       | Yes            | **No** (upstream)    | Pass `disable_stream_with_tools=True` |
| vLLM          | Yes       | Yes            | Yes                  | Aggregator defaults missing `type` to `"function"` |

## What this provider does not support

- `built_in_tools` (Claude Agent SDK native tools — no OpenAI equivalent)
- `sub_agents` (Claude Agent SDK dispatch contract)
- `permission_mode` (Claude-specific)

Configure those on `ClaudeSDKProvider`. Zeno's `ZenoApp.start()` catches mismatches.

Part of the [Zeno framework](https://github.com/nkootstra/zeno).
