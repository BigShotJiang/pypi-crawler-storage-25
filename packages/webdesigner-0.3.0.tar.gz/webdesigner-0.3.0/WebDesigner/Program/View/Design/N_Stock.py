################################################################################################################################
#Stock
################################################################################################################################
#Default Libraries
import inspect

#Program
from .N_Stock_Frame import Stock_Frame
from .N_Stock_Popup import Stock_Popup
from .N_Stock_Label import Stock_Label
from .N_Stock_Bar import Stock_Bar
from .N_Stock_Button import Stock_Button
from .N_Stock_Compound import Stock_Compound
from .N_Stock_Image import Stock_Image
from .N_Stock_Line import Stock_Line
from .N_Stock_Entry import Stock_Entry
from .N_Stock_List import Stock_List
from .N_Stock_Select import Stock_Select
from .N_Stock_Scale import Stock_Scale
from .N_Stock_Check import Stock_Check
from .N_Stock_Radio import Stock_Radio
from .N_Stock_Switch import Stock_Switch
from .N_Stock_Text import Stock_Text
from .N_Stock_Tree import Stock_Tree

class Stock:
    def __init__(self, Global, Design):
        try:
            self.Global = Global
            self.Design = Design
            self.Widget = []
            
            #Line
            Fixture = self.Design.Frame.Locate(0.5, 90, 28.5, 10)
            self.Line = self.Global['Gluonix'].Line(self.Design.Frame)
            self.Line.Config(Width=Fixture[0], Height=Fixture[1], Left=Fixture[2], Top=Fixture[3])
            self.Line.Config(Border_Size=0, Display=True)
            self.Line.Config(Resize=True, Move=True)
            self.Line.Create()
            self.Design.Widget.append(self.Line)
            
            #Frame
            Fixture = self.Design.Frame.Locate(29.5, 90, 0, 10)
            self.Frame = self.Global['Gluonix'].Frame(self.Design.Frame)
            self.Frame.Config(Width=Fixture[0], Height=Fixture[1], Left=Fixture[2], Top=Fixture[3])
            self.Frame.Config(Background='#FFFFFF', Border_Size=0, Display=True)
            self.Frame.Config(Resize=True, Move=True)
            self.Frame.Create()
            self.Design.Widget.append(self.Frame)
            
            #Label
            Fixture = self.Frame.Locate(100, 3, 0, 1)
            self.Label = self.Global['Gluonix'].Label(self.Frame)
            self.Label.Config(Width=Fixture[0], Height=Fixture[1], Left=Fixture[2], Top=Fixture[3])
            self.Label.Config(Background='#FFFFFF', Border_Size=0, Display=True)
            self.Label.Config(Foreground='#000000', Font_Size=16, Font_Weight='normal', Align='w')
            self.Label.Config(Resize=True, Move=True)
            self.Label.Set(' ELEMENTS')
            self.Label.Create()
            
            #Frame
            Fixture = self.Frame.Locate(100, 95, 0, 5)
            self.Scroll = self.Global['Gluonix'].Frame(self.Frame)
            self.Scroll.Config(Width=Fixture[0], Height=Fixture[1], Left=Fixture[2], Top=Fixture[3])
            self.Scroll.Config(Background='#FFFFFF', Border_Size=0, Display=True)
            self.Scroll.Config(Resize=True, Move=True)
            self.Scroll.Create()
            
            #Objects
            
            self.Top = 3
            self.Left = 2.5
            self.Center = 35
            self.Right = 67.5
            
            # Containers
            
            #Label
            Fixture = self.Scroll.Locate(100, 3, 0, self.Top)
            self.Label_Container = self.Global['Gluonix'].Label(self.Scroll)
            self.Label_Container.Config(Width=Fixture[0], Height=Fixture[1], Left=Fixture[2], Top=Fixture[3])
            self.Label_Container.Config(Background='#FFFFFF', Border_Size=0, Display=True)
            self.Label_Container.Config(Foreground='#000000', Font_Size=12, Font_Weight='normal', Align='w')
            self.Label_Container.Config(Resize=True, Move=True)
            self.Label_Container.Set(' CONTAINER')
            self.Label_Container.Create()
            
            #Stock Frame
            self.Top += 4
            self.Stock_Frame = Stock_Frame(self.Global, self, self.Left, self.Top)
            
            #Stock Label
            self.Stock_Popup = Stock_Popup(self.Global, self, self.Center, self.Top)
            
            # Widget
            
            #Label
            self.Top += 7
            Fixture = self.Scroll.Locate(100, 3, 0, self.Top)
            self.Label_Widget = self.Global['Gluonix'].Label(self.Scroll)
            self.Label_Widget.Config(Width=Fixture[0], Height=Fixture[1], Left=Fixture[2], Top=Fixture[3])
            self.Label_Widget.Config(Background='#FFFFFF', Border_Size=0, Display=True)
            self.Label_Widget.Config(Foreground='#000000', Font_Size=12, Font_Weight='normal', Align='w')
            self.Label_Widget.Config(Resize=True, Move=True)
            self.Label_Widget.Set(' WIDGET')
            self.Label_Widget.Create()
            
            #Stock Line
            self.Top += 4
            self.Stock_Line = Stock_Line(self.Global, self, self.Left, self.Top)
            
            #Stock Label
            self.Stock_Label = Stock_Label(self.Global, self, self.Center, self.Top)
            
            #Stock Button
            self.Stock_Button = Stock_Button(self.Global, self, self.Right, self.Top)
            
            #Stock Image
            self.Top += 6
            self.Stock_Image = Stock_Image(self.Global, self, self.Left, self.Top)
            
            #Stock Compound
            self.Stock_Compound = Stock_Compound(self.Global, self, self.Center, self.Top)
            
            #Stock Text
            self.Stock_Text = Stock_Text(self.Global, self, self.Right, self.Top)
            
            #Stock Entry
            self.Top += 6
            self.Stock_Entry = Stock_Entry(self.Global, self, self.Left, self.Top)
            
            #Stock List
            self.Stock_List = Stock_List(self.Global, self, self.Center, self.Top)
            
            #Stock Select
            self.Stock_Select = Stock_Select(self.Global, self, self.Right, self.Top)
            
            #Stock Bar
            self.Top += 6
            self.Stock_Bar = Stock_Bar(self.Global, self, self.Left, self.Top)
            
            #Stock Scale
            self.Stock_Scale = Stock_Scale(self.Global, self, self.Center, self.Top)
            
            #Stock Tree
            self.Stock_Tree = Stock_Tree(self.Global, self, self.Right, self.Top)
            
            #Stock Check
            self.Top += 6
            self.Stock_Check = Stock_Check(self.Global, self, self.Left, self.Top)
            
            #Stock Radio
            self.Stock_Radio = Stock_Radio(self.Global, self, self.Center, self.Top)
            
            #Stock Switch
            self.Stock_Switch = Stock_Switch(self.Global, self, self.Right, self.Top)
            
            #Update Scroll
            #self.Scroll.Update(self.Stock_Switch.Label)
                   
        except Exception as E:
            self.Global['Error'](__class__.__name__+" -> "+inspect.currentframe().f_code.co_name+" -> "+str(E))