################################################################################################################################
#Menu
################################################################################################################################
import os
import sys
import math
import shutil
import inspect
import subprocess
from tkinter import colorchooser

class Overview:
    def __init__(self, Global, Panel):
        try:
            self.Global = Global
            self.Panel = Panel
            self.Widget = []
            self.Runtime = False
            self.Project_Path = False
            self.Runtime_Path = False
            self.TempDatabase = False
            self.Launch = False
            self.Direct = False
            self.Resize = False
            
            Fixture = self.Panel.Frame.Locate(100, 100, 0, 0)
            self.Frame = self.Global['Gluonix'].Frame(self.Panel.Frame)
            self.Frame.Config(Width=Fixture[0], Height=Fixture[1], Left=Fixture[2], Top=Fixture[3])
            self.Frame.Config(Border_Size=0, Display=False)
            self.Frame.Create()
            self.Panel.Widget.append(self.Frame)
            
                #Info Label
            Fixture = self.Frame.Locate(35, 8, 3, 5)
            self.Info_Label = self.Global['Gluonix'].Label(self.Frame)
            self.Info_Label.Config(Width=Fixture[0], Height=Fixture[1], Left=Fixture[2], Top=Fixture[3])
            self.Info_Label.Config(Foreground='black', Value="Project Configuration:", Font_Size=14, Font_Weight='bold', Align='w', Border_Size=0)
            self.Info_Label.Create()
            
                #Display Label
            Fixture = self.Frame.Locate(8, 4, 63, 7)
            self.Display_Label = self.Global['Gluonix'].Label(self.Frame)
            self.Display_Label.Config(Width=Fixture[0], Height=Fixture[1], Left=Fixture[2], Top=Fixture[3])
            self.Display_Label.Config(Foreground='black', Value="Display:", Font_Size=14, Font_Weight='bold', Align='w', Border_Size=0)
            self.Display_Label.Create()
            
                #Display Select
            Fixture = self.Frame.Locate(15, 4, 72, 7)
            self.Display_Select = self.Global['Gluonix'].Select(self.Frame)
            self.Display_Select.Config(Width=Fixture[0], Height=Fixture[1], Left=Fixture[2], Top=Fixture[3])
            self.Display_Select.Config(Background='#FFFFFF', Foreground='#000000', Font_Size=11, Font_Weight='normal', Align='center', Border_Size=1)
            self.Display_Select.Config(Hover_Background='#EEEEEE', Hover_Border_Color='#0078d7')
            self.Display_Select.Create()
            
                #Title Label
            Fixture = self.Frame.Locate(7, 5, 3, 16)
            self.Title_Label = self.Global['Gluonix'].Label(self.Frame)
            self.Title_Label.Config(Width=Fixture[0], Height=Fixture[1], Left=Fixture[2], Top=Fixture[3])
            self.Title_Label.Config(Foreground='black', Value="Title:", Font_Size=12, Font_Weight='normal', Align='w', Border_Size=0)
            self.Title_Label.Create()
            
                #Title Entry
            Fixture = self.Frame.Locate(30, 5, 12, 16)
            self.Title_Entry = self.Global['Gluonix'].Entry(self.Frame)
            self.Title_Entry.Config(Width=Fixture[0], Height=Fixture[1], Left=Fixture[2], Top=Fixture[3])
            self.Title_Entry.Config(Background='#FFFFFF', Foreground='#000000', Font_Size=10, Font_Weight='normal', Align='left', Border_Size=1)
            self.Title_Entry.Config(Hover_Background='#EEEEEE', Hover_Border_Color='#0078d7')
            self.Title_Entry.Create()
            
                #Background Label
            Fixture = self.Frame.Locate(15, 5, 47, 16)
            self.Background_Label = self.Global['Gluonix'].Label(self.Frame)
            self.Background_Label.Config(Width=Fixture[0], Height=Fixture[1], Left=Fixture[2], Top=Fixture[3])
            self.Background_Label.Config(Foreground='black', Value="Background:", Font_Size=12, Font_Weight='normal', Align='w', Border_Size=0)
            self.Background_Label.Create()
            
                #Background Color
            Fixture = self.Frame.Locate(4, 5, 61, 16)
            self.Background_Color = self.Global['Gluonix'].Label(self.Frame)
            self.Background_Color.Config(Width=Fixture[0], Height=Fixture[1], Left=Fixture[2], Top=Fixture[3])
            self.Background_Color.Config(Background='white', Foreground='black', Font_Size=10, Font_Weight='normal', Align='w', Border_Size=1)
            self.Background_Color.Bind(On_Click=lambda E: self.Select_Color())
            self.Background_Color.Create()
            
                #Width Label
            Fixture = self.Frame.Locate(7, 5, 3, 25)
            self.Width_Label = self.Global['Gluonix'].Label(self.Frame)
            self.Width_Label.Config(Width=Fixture[0], Height=Fixture[1], Left=Fixture[2], Top=Fixture[3])
            self.Width_Label.Config(Foreground='black', Value="Width:", Font_Size=12, Font_Weight='normal', Align='w', Border_Size=0)
            self.Width_Label.Create()

                #Width Entry
            Fixture = self.Frame.Locate(7, 5, 12, 25)
            self.Width_Entry = self.Global['Gluonix'].Entry(self.Frame)
            self.Width_Entry.Config(Width=Fixture[0], Height=Fixture[1], Left=Fixture[2], Top=Fixture[3])
            self.Width_Entry.Config(Background='#FFFFFF', Foreground='#000000', Font_Size=10, Font_Weight='normal', Align='center', Border_Size=1)
            self.Width_Entry.Config(Hover_Background='#EEEEEE', Hover_Border_Color='#0078d7')
            self.Width_Entry.Create()
            
                #Height Label
            Fixture = self.Frame.Locate(7, 5, 22, 25)
            self.Height_Label = self.Global['Gluonix'].Label(self.Frame)
            self.Height_Label.Config(Width=Fixture[0], Height=Fixture[1], Left=Fixture[2], Top=Fixture[3])
            self.Height_Label.Config(Foreground='black', Value="Height:", Font_Size=12, Font_Weight='normal', Align='w', Border_Size=0)
            self.Height_Label.Create()

                #Width Entry
            Fixture = self.Frame.Locate(7, 5, 31, 25)
            self.Height_Entry = self.Global['Gluonix'].Entry(self.Frame)
            self.Height_Entry.Config(Width=Fixture[0], Height=Fixture[1], Left=Fixture[2], Top=Fixture[3])
            self.Height_Entry.Config(Background='#FFFFFF', Foreground='#000000', Font_Size=10, Font_Weight='normal', Align='center', Border_Size=1)
            self.Height_Entry.Config(Hover_Background='#EEEEEE', Hover_Border_Color='#0078d7')
            self.Height_Entry.Create()
            
                #Left Label
            Fixture = self.Frame.Locate(7, 5, 41, 25)
            self.Left_Label = self.Global['Gluonix'].Label(self.Frame)
            self.Left_Label.Config(Width=Fixture[0], Height=Fixture[1], Left=Fixture[2], Top=Fixture[3])
            self.Left_Label.Config(Foreground='black', Value="Left:", Font_Size=12, Font_Weight='normal', Align='w', Border_Size=0)
            self.Left_Label.Create()

                #Left Entry
            Fixture = self.Frame.Locate(7, 5, 49, 25)
            self.Left_Entry = self.Global['Gluonix'].Entry(self.Frame)
            self.Left_Entry.Config(Width=Fixture[0], Height=Fixture[1], Left=Fixture[2], Top=Fixture[3])
            self.Left_Entry.Config(Background='#FFFFFF', Foreground='#000000', Font_Size=10, Font_Weight='normal', Align='center', Border_Size=1)
            self.Left_Entry.Config(Hover_Background='#EEEEEE', Hover_Border_Color='#0078d7')
            self.Left_Entry.Create()
            
                #Top Label
            Fixture = self.Frame.Locate(7, 5, 59, 25)
            self.Top_Label = self.Global['Gluonix'].Label(self.Frame)
            self.Top_Label.Config(Width=Fixture[0], Height=Fixture[1], Left=Fixture[2], Top=Fixture[3])
            self.Top_Label.Config(Foreground='black', Value="Top:", Font_Size=12, Font_Weight='normal', Align='w', Border_Size=0)
            self.Top_Label.Create()

                #Top Entry
            Fixture = self.Frame.Locate(7, 5, 67, 25)
            self.Top_Entry = self.Global['Gluonix'].Entry(self.Frame)
            self.Top_Entry.Config(Width=Fixture[0], Height=Fixture[1], Left=Fixture[2], Top=Fixture[3])
            self.Top_Entry.Config(Background='#FFFFFF', Foreground='#000000', Font_Size=10, Font_Weight='normal', Align='center', Border_Size=1)
            self.Top_Entry.Config(Hover_Background='#EEEEEE', Hover_Border_Color='#0078d7')
            self.Top_Entry.Create()
            
                #Port Label
            Fixture = self.Frame.Locate(7, 5, 3, 34)
            self.Port_Label = self.Global['Gluonix'].Label(self.Frame)
            self.Port_Label.Config(Width=Fixture[0], Height=Fixture[1], Left=Fixture[2], Top=Fixture[3])
            self.Port_Label.Config(Foreground='black', Value="Port:", Font_Size=12, Font_Weight='normal', Align='w', Border_Size=0)
            self.Port_Label.Create()

                #Port Entry
            Fixture = self.Frame.Locate(7, 5, 12, 34)
            self.Port_Entry = self.Global['Gluonix'].Entry(self.Frame)
            self.Port_Entry.Config(Width=Fixture[0], Height=Fixture[1], Left=Fixture[2], Top=Fixture[3])
            self.Port_Entry.Config(Background='#FFFFFF', Foreground='#000000', Font_Size=10, Font_Weight='normal', Align='center', Border_Size=1)
            self.Port_Entry.Config(Hover_Background='#EEEEEE', Hover_Border_Color='#0078d7')
            self.Port_Entry.Create()
            
                #IP Label
            Fixture = self.Frame.Locate(7, 5, 22, 34)
            self.IP_Label = self.Global['Gluonix'].Label(self.Frame)
            self.IP_Label.Config(Width=Fixture[0], Height=Fixture[1], Left=Fixture[2], Top=Fixture[3])
            self.IP_Label.Config(Foreground='black', Value="IP:", Font_Size=12, Font_Weight='normal', Align='w', Border_Size=0)
            self.IP_Label.Create()

                #IP Entry
            Fixture = self.Frame.Locate(17, 5, 31, 34)
            self.IP_Entry = self.Global['Gluonix'].Entry(self.Frame)
            self.IP_Entry.Config(Width=Fixture[0], Height=Fixture[1], Left=Fixture[2], Top=Fixture[3])
            self.IP_Entry.Config(Background='#FFFFFF', Foreground='#000000', Font_Size=10, Font_Weight='normal', Align='center', Border_Size=1)
            self.IP_Entry.Config(Hover_Background='#EEEEEE', Hover_Border_Color='#0078d7')
            self.IP_Entry.Create()
            
                #Icon Label
            Fixture = self.Frame.Locate(7, 5, 3, 43)
            self.Icon_Label = self.Global['Gluonix'].Label(self.Frame)
            self.Icon_Label.Config(Width=Fixture[0], Height=Fixture[1], Left=Fixture[2], Top=Fixture[3])
            self.Icon_Label.Config(Foreground='black', Value="Icon:", Font_Size=12, Font_Weight='normal', Align='w', Border_Size=0)
            self.Icon_Label.Create()
            
                #Icon Image
            Fixture = self.Frame.Locate(15, 15, 12, 43)
            self.Icon_Image = self.Global['Gluonix'].Image(self.Frame)
            self.Icon_Image.Config(Width=Fixture[0], Height=Fixture[1], Left=Fixture[2], Top=Fixture[3])
            self.Icon_Image.Config(Background='white', Border_Size=1, Hand_Cursor=True)
            self.Icon_Image.Create()
            
                #Icon Browser
            Fixture = self.Frame.Locate(12, 6, 30, 43)
            self.Icon_Browser = self.Global['Gluonix'].Label(self.Frame)
            self.Icon_Browser.Config(Width=Fixture[0], Height=Fixture[1], Left=Fixture[2], Top=Fixture[3])
            self.Icon_Browser.Config(Background='#e1e1e1', Foreground='black', Value='Browser...', Font_Size=9, Font_Weight='normal', Border_Size=1, Border_Color='#adadad')
            self.Icon_Browser.Config(Hover_Background='#d5dcf0', Hover_Border_Color='#0078d7')
            self.Icon_Browser.Bind(On_Click=lambda E: self.Select_Icon())
            self.Icon_Browser.Create()
            
                #Deploy Button
            Fixture = self.Frame.Locate(8, 6, 66, 88)
            self.Deploy_Button = self.Global['Gluonix'].Label(self.Frame)
            self.Deploy_Button.Config(Width=Fixture[0], Height=Fixture[1], Left=Fixture[2], Top=Fixture[3])
            self.Deploy_Button.Config(Background='#D2B4DE', Foreground='black', Value='Deploy', Font_Size=9, Font_Weight='normal', Border_Size=1, Border_Color='#5B2C6F')
            self.Deploy_Button.Config(Hover_Background='#BB8FCE')
            self.Deploy_Button.Bind(On_Click=lambda E: self.Deploy())
            self.Deploy_Button.Create()
            
                #Design Button
            Fixture = self.Frame.Locate(8, 6, 76, 88)
            self.Design_Button = self.Global['Gluonix'].Label(self.Frame)
            self.Design_Button.Config(Width=Fixture[0], Height=Fixture[1], Left=Fixture[2], Top=Fixture[3])
            self.Design_Button.Config(Background='#FAD7A0', Foreground='black', Value='Design', Font_Size=9, Font_Weight='normal', Border_Size=1, Border_Color='#935116')
            self.Design_Button.Config(Hover_Background='#F39C12')
            self.Design_Button.Bind(On_Click=lambda E: self.Save(Launch=True, Direct=True))
            self.Design_Button.Create()
            
                #Save Button
            Fixture = self.Frame.Locate(8, 6, 86, 88)
            self.Save_Button = self.Global['Gluonix'].Label(self.Frame)
            self.Save_Button.Config(Width=Fixture[0], Height=Fixture[1], Left=Fixture[2], Top=Fixture[3])
            self.Save_Button.Config(Background='#ABEBC6', Foreground='black', Value='Save', Font_Size=9, Font_Weight='normal', Border_Size=1, Border_Color='#1D8348')
            self.Save_Button.Config(Hover_Background='#2ECC71')
            self.Save_Button.Bind(On_Click=lambda E: self.Save())
            self.Save_Button.Create()
            
        except Exception as E:
            self.Global['Error'](__class__.__name__+" -> "+inspect.currentframe().f_code.co_name+" -> "+str(E))
            
    def Save(self, Loading=True, Launch=False, Direct=False):
        try:
            if Loading:
                self.Global['Loading'].Show()
                self.Global['GUI'].After(500, lambda:self.Save(Loading=False, Launch=Launch, Direct=Direct))
            else:
                Error = False
                if not Error and self.Title_Entry.Get()=='':
                    Error = True
                    self.Global['Message'].Show('Error', 'Enter Project Title')
                if not Error and not self.Is_Number(self.Width_Entry.Get()):
                    Error = True
                    self.Global['Message'].Show('Error', 'Incorrect Width Value')
                if not Error and not self.Is_Number(self.Height_Entry.Get()):
                    Error = True
                    self.Global['Message'].Show('Error', 'Incorrect Height Value')
                if not Error and not self.Is_Number(self.Left_Entry.Get()):
                    Error = True
                    self.Global['Message'].Show('Error', 'Incorrect Left Value')
                if not Error and not self.Is_Number(self.Top_Entry.Get()):
                    Error = True
                    self.Global['Message'].Show('Error', 'Incorrect Top Value')
                if not Error:
                    self.Display_ID = self.Display_Select.Get()
                    Project_Name = self.Title_Entry.Get()
                    if self.Display_ID=='Root':
                        for File_Name in os.listdir(self.Project_Path):
                            if File_Name.endswith('.ng'):
                                os.remove(f'{self.Project_Path}/{File_Name}')
                        if not self.Runtime:
                            with open(f'{self.Project_Path}/{Project_Name}.ng', 'w') as File:
                                File.write(Project_Name)
                        self.Project_Data['Name'] = Project_Name
                    self.Project_Data['NGD'] = f"{self.Global['Version']}.{self.Global['Revision']}"
                    self.Project_Data['IP'] = self.IP_Entry.Get()
                    self.Project_Data['Port'] = self.Port_Entry.Get()
                    self.Display_Data['Title'] = Project_Name
                    self.Display_Data['Background'] = self.Background_Color.Config_Get('Background')['Background']
                    self.Display_Data['Width'] = self.Width_Entry.Get()
                    self.Display_Data['Height'] = self.Height_Entry.Get()
                    self.Display_Data['Left'] = self.Left_Entry.Get()
                    self.Display_Data['Top'] = self.Top_Entry.Get()
                    TempDatabase = self.Global['Gluonix'].SQL(f'{self.Project_Path}/Data/NGD.dll')
                    Display_Data_Temp = TempDatabase.Get(f"SELECT * FROM `Display` WHERE `ID`='{self.Display_ID}'", Keys=True)
                    TempDatabase.Post(f"UPDATE `Display` SET `Title`='{self.Display_Data['Title']}' WHERE `ID`='{self.Display_ID}'")
                    TempDatabase.Post(f"UPDATE `Display` SET `Background`='{self.Display_Data['Background']}' WHERE `ID`='{self.Display_ID}'")
                    TempDatabase.Post(f"UPDATE `Variable` SET `Data`='{self.Project_Data['IP']}' WHERE `ID`='IP'")
                    TempDatabase.Post(f"UPDATE `Variable` SET `Data`='{self.Project_Data['Port']}' WHERE `ID`='Port'")
                    if f"{self.Project_Path}/Data/File/{self.Project_Data['Icon']}"!=self.Icon_Image.Config_Get('Path')['Path']:
                        if os.path.exists(f"{self.Project_Path}/Data/File/{self.Project_Data['Icon']}"):
                            os.remove(f"{self.Project_Path}/Data/File/{self.Project_Data['Icon']}")
                        shutil.copy(self.Icon_Image.Config_Get('Path')['Path'], f"{self.Project_Path}/Data/File/{self.Project_Data['Icon']}")
                    if not Direct:
                        self.Global['Loading'].Hide()
                        self.Global['Message'].Show('Success', 'Save Successfull')
                        self.Global['Message'].Hide(Delay=2)
                    if Launch:
                        self.Panel.Home.Main.Design.Configure.Reset_All()
                        self.Panel.Home.Main.Design.Project_Path = self.Project_Path
                        self.Panel.Home.Main.Design.Project_Data = self.Project_Data
                        self.Panel.Home.Main.Design.Display_ID = self.Display_ID
                        self.Panel.Home.Frame.Hide()
                        self.Panel.Home.Main.Design.Update(Loading=False)
                    TempDatabase.Close()
                    return True
                else:
                    self.Global['Loading'].Hide()
                    return False
        except Exception as E:
            self.Global['Error'](__class__.__name__+" -> "+inspect.currentframe().f_code.co_name+" -> "+str(E))
            
    def Deploy(self, Loading=True):
        try:
            if self.Runtime:
                Project_Path = self.Project_Path.rsplit('/Nucleon', 1)[0]
                Temp_Name = self.Title_Entry.Get()
                File_Path = f'{Project_Path}/{Temp_Name}.py'
                if os.path.exists(File_Path):
                    subprocess.Popen([sys.executable, File_Path])
            else:
                if Loading:
                    if self.Runtime_Path:
                        Initial = self.Runtime_Path
                    else:
                        Initial = os.path.join(os.path.expanduser('~'), 'Documents')
                    Path = self.Global['GUI'].Folder(Initial=Initial, Title='Select Runtime Folder')
                    if Path:
                        Temp_Path = Path.replace('/', '\\')
                        if Temp_Path!=self.Project_Path:
                            self.Runtime_Path = Path
                            self.Global['Loading'].Show()
                            self.Global['GUI'].After(500, lambda:self.Deploy(Loading=False))
                        else:
                            self.Global['Message'].Show('Error', 'Project Path Cannot Be Runtime Path')
                else:
                    if self.Save(Direct=True):
                        if os.path.exists(f'{self.Runtime_Path}/Nucleon'):
                            shutil.rmtree(f'{self.Runtime_Path}/Nucleon')
                        shutil.copytree(self.Global['Relative_Path']('Nucleon'), f'{self.Runtime_Path}/Nucleon')
                        shutil.copytree(f'{self.Project_Path}/Data', f'{self.Runtime_Path}/Nucleon/Data')
                        Temp_Name = self.Title_Entry.Get()
                        if not os.path.exists(f'{self.Runtime_Path}/{Temp_Name}.py'):
                            shutil.copy(self.Global['Relative_Path']('Program/Base/GUI.py'), f'{self.Runtime_Path}/{Temp_Name}.py')
                        self.Global['Message'].Show('Success', 'Project Deployed')
                        if self.Global['GUI']._Window:
                            os.startfile(self.Runtime_Path)
                    self.Global['Loading'].Hide()
        except Exception as E:
            self.Global['Error'](__class__.__name__+" -> "+inspect.currentframe().f_code.co_name+" -> "+str(E))
            
    def Update(self, Partial=False):
        try:
            if os.path.exists(f'{self.Project_Path}/Data/NGD.dll'):
                if self.Runtime:
                    Source = self.Global['Relative_Path']('Nucleon')
                    Destination = self.Project_Path
                    Wavionix_Source = os.path.join(Source, 'Wavionix')
                    Wavionix_Destination = os.path.join(Destination, 'Wavionix')
                    Runner_Source = os.path.join(Source, 'Runner.py')
                    Runner_Destination = os.path.join(Destination, 'Runner.py')
                    if os.path.exists(Wavionix_Destination):
                        shutil.rmtree(Wavionix_Destination)
                    if os.path.exists(Runner_Destination):
                        os.remove(Runner_Destination)
                    shutil.copytree(Wavionix_Source, Wavionix_Destination)
                    shutil.copy2(Runner_Source, Runner_Destination)
                self.Deploy_Button.Set('Run' if self.Runtime else 'Deploy')
                TempDatabase = self.Global['Gluonix'].SQL(f'{self.Project_Path}/Data/NGD.dll')
                if not Partial:
                    self.Project_Data = {}
                    Project_Data_Temp = TempDatabase.Get("SELECT * FROM `Variable`", Keys=True)
                    for Each in Project_Data_Temp:
                        self.Project_Data[Each['ID']] = Each['Data']
                    Display_Data_Temp = TempDatabase.Get("SELECT * FROM `Display`", Keys=True)
                    self.Display_Select.Clear()
                    for Each in Display_Data_Temp:
                        self.Display_Select.Add(Each['ID'])
                    self.Display_Select.Set('Root')
                    self.Icon_Image.Set(f"{self.Project_Path}/Data/File/{self.Project_Data['Icon']}")
                self.IP_Entry.Set(self.Project_Data['IP'])
                self.Port_Entry.Set(self.Project_Data['Port'])
                self.Display_ID = self.Display_Select.Get()
                self.Display_Select.Sort()
                Display_Data_Temp = TempDatabase.Get(f"SELECT * FROM `Display` WHERE `ID`='{self.Display_ID}'", Keys=True)
                self.Display_Data = Display_Data_Temp[0]
                self.Title_Entry.Set(self.Display_Data['Title'])
                self.Background_Color.Config(Background=self.Display_Data['Background'])
                self.Width_Entry.Set(self.Display_Data['Width'])
                self.Height_Entry.Set(self.Display_Data['Height'])
                self.Left_Entry.Set(self.Display_Data['Left'])
                self.Top_Entry.Set(self.Display_Data['Top'])
                self.Icon_Label.Show()
                self.Icon_Image.Show()
                self.Icon_Browser.Show()
                self.Frame.Show()
                TempDatabase.Close()
            else:
                self.Global['Message'].Show('Error', 'Project files not found')
        except Exception as E:
            self.Global['Error'](__class__.__name__+" -> "+inspect.currentframe().f_code.co_name+" -> "+str(E))

    def Is_Number(self, Value):
        try:
            try:
                float(Value)
                return True
            except ValueError:
                return False
        except Exception as E:
            self.Global['Error'](__class__.__name__+" -> "+inspect.currentframe().f_code.co_name+" -> "+str(E))
     
    def Select_Color(self):
        try:
            Color = colorchooser.askcolor(color=self.Background_Color.Config_Get('Background')['Background'], title ="Choose Background Color")[1]
            if Color is not None:
                self.Background_Color.Config(Background=Color)
        except Exception as E:
            self.Global['Error'](__class__.__name__+" -> "+inspect.currentframe().f_code.co_name+" -> "+str(E))
    
    def Select_Icon(self):
        try:
            Icon_File_Path = self.Global['GUI'].File(Initial=os.path.join(os.path.expanduser('~'), 'Documents'), Title='Select Icon', Default='.ico', Type=[["Icon (*.ico)", "*.ico"]])
            if Icon_File_Path:
                self.Icon_Image.Set(Icon_File_Path)
        except Exception as E:
            self.Global['Error'](__class__.__name__+" -> "+inspect.currentframe().f_code.co_name+" -> "+str(E))