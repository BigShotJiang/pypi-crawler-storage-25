################################################################################################################################
# Programming Start
################################################################################################################################

# -------------------------------------------------------------------------------------------------------------------------------
# Import Libraries
# -------------------------------------------------------------------------------------------------------------------------------
# Custom Libraries
from Nucleon import Wavionix

# Default Libraries
import os
import time
import atexit
import datetime
import warnings

# -------------------------------------------------------------------------------------------------------------------------------
# Customization
# -------------------------------------------------------------------------------------------------------------------------------
warnings.filterwarnings("ignore", category=DeprecationWarning)

# -------------------------------------------------------------------------------------------------------------------------------
# Global Variables
# -------------------------------------------------------------------------------------------------------------------------------
Error_List = []
Log_Folder = "./Log"
Log_File = "Wavionix_Error.log"
Error_Log = True
Root = False

# -------------------------------------------------------------------------------------------------------------------------------
# Error Log
# -------------------------------------------------------------------------------------------------------------------------------
def Error(E):
    global Error_List, Error_Display
    Error_Time = int(time.time())
    Error_List.append([E, Error_Time])
    if Error_Log:
        if not os.path.exists(Log_Folder):
            os.makedirs(Log_Folder)
        Log_Path = os.path.join(Log_Folder, Log_File)
        Date = datetime.datetime.fromtimestamp(Error_Time)
        Date = Date.strftime("%Y-%m-%d %H:%M:%S")
        Line = f"{Date} - {E}"
        File_Content = []
        if os.path.exists(Log_Path):
            with open(Log_Path, "r") as File:
                File_Content = File.readlines()
            if len(File_Content) >= 10000:
                File_Content.pop()
        with open(Log_Path, "w") as File:
            File.write(Line.rstrip("\r\n") + "\n")
            File.writelines(File_Content)
            
# -------------------------------------------------------------------------------------------------------------------------------
# Relative Path
# -------------------------------------------------------------------------------------------------------------------------------

def File(Name):
    try:
        Base_Dir = os.path.dirname(os.path.abspath(__file__))
        Path = os.path.join(Base_Dir, "Data", "File", f"{Name}")
        if os.path.exists(Path):
            return Path
        else:
            return ""
    except Exception as E:
        Error("Image -> " + str(E))

def Data(Name):
    try:
        Base_Dir = os.path.dirname(os.path.abspath(__file__))
        Path = os.path.join(Base_Dir, "Data", f"{Name}")
        if os.path.exists(Path):
            return Path
        else:
            return ""
    except Exception as E:
        Error("Data -> " + str(E))
        
# -------------------------------------------------------------------------------------------------------------------------------
# Database
# -------------------------------------------------------------------------------------------------------------------------------
Database = Wavionix.SQL(Data('NGD.dll'))

# -------------------------------------------------------------------------------------------------------------------------------
# Database Variables
# -------------------------------------------------------------------------------------------------------------------------------
Variable_Data = {}
Variable_Data_Temp = Database.Get("SELECT * FROM `Variable`", Keys=True)
for Each in Variable_Data_Temp:
        Variable_Data[Each['ID']] = Each['Data']

try:
    Error_Log = bool(int(Variable_Data['Error_Log']))
except:
    Error_Log = True

# -------------------------------------------------------------------------------------------------------------------------------
# Global Functions
# -------------------------------------------------------------------------------------------------------------------------------

def Error_Clear():
    try:
        global Error_List
        Error_List = []
    except Exception as E:
        Error("Error_Clear -> " + str(E))
        
def Load_Start(Root, Global):
    try:
        Display = Database.Get(f"SELECT * FROM `Display` WHERE `ID`='Root'", Keys=True)
        if len(Display)==1:
            Display = Display[0]
            Root.Address(IP=Variable_Data['IP'], Port=int(Variable_Data['Port']))
            Root.Config(Error_Log=Error_Log)
            Root.Config(Title=Display['Title'], Background=Display['Background'], Icon=File(Variable_Data['Icon']), Scroll=False)
            Root.Config(Width='100%', Height='100%', Min_Height='100vh', Style='position: relative;')
    except Exception as E:
        Error("Load_Start -> "+str(E))
        
def Load(Root, Global):
    try:
        Display = Database.Get(f"SELECT * FROM `Display` WHERE `ID`='Root'", Keys=True)
        if len(Display)==1:
            Display = Display[0]
            Global[Display['ID']] = Root
            Root.Lib = Wavionix
            Root.Create()
            Load_Child(Display['ID'], Root, Global)
    except Exception as E:
        Error("Load -> "+str(E))
        
def Load_Child(Parent, Root, Global):
    try:
        Widgets = Database.Get(f"SELECT * FROM `Widget` WHERE `Root`='{Parent}'", Keys=True)
        for Widget in Widgets:
            if Widget['Type']=='Image':
                if Widget['Dynamic']==0:
                    Temp_Class = getattr(Wavionix, "Image")
                elif Widget['Dynamic']==1:
                    Temp_Class = getattr(Wavionix, "Dynamic")
                elif Widget['Dynamic']==2:
                    Temp_Class = getattr(Wavionix, "Editor")
            else:
                Temp_Class = getattr(Wavionix, f"{Widget['Type']}")
            Temp_Widget = Temp_Class(Root)
            Temp_Widget.Config(Name=Widget['Name'])
            Temp_Widget.Config(Width=f"{Widget['Width']}%", Height=f"{Widget['Height']}%", Left=f"{Widget['Left']}%", Top=f"{Widget['Top']}%")
            if Widget['Background']=='False':
                Temp_Widget.Config(Background=False)
            else:
                Temp_Widget.Config(Background=Widget['Background'])
            Temp_Widget.Config(Foreground=Widget['Foreground'], Border_Size=Widget['Border_Size'], Border_Color=Widget['Border_Color'], Border_Radius=Widget['Radius'], Display=bool(Widget['Display']))
            Temp_Widget.Config(Shadow_Spread=Widget['Shadow_Size'], Shadow_Blur=Widget['Shadow_Size'], Shadow_Color=Widget['Shadow_Color'])
            Temp_Widget.Config(Font_Size=Widget['Font_Size'], Font_Weight=Widget['Font_Weight'], Font_Family=Widget['Font_Family'], Align=Widget['Align'], Value=Widget['Value'])
            Temp_Widget.Config(Path=File(Widget['ID']))
            Temp_Widget.Config(Url=bool(Widget['Url']), Transparent=bool(Widget['Transparent']), Rotate=Widget['Rotate'], Compound=Widget['Compound'], Aspect_Ratio=bool(Widget['Aspect_Ratio']))
            Temp_Widget.Create()
        Frames = Database.Get(f"SELECT * FROM `Frame` WHERE `Root`='{Parent}'", Keys=True)
        for Frame in Frames:
            Temp_Class = getattr(Wavionix, f"{Frame['Type']}")
            Temp_Frame = Temp_Class(Root)
            Temp_Frame.Config(Name=Frame['Name'])
            Temp_Frame.Config(Width=f"{Frame['Width']}%", Height=f"{Frame['Height']}%", Left=f"{Frame['Left']}%", Top=f"{Frame['Top']}%")
            if Frame['Background']=='False':
                Temp_Frame.Config(Background=False)
            else:
                Temp_Frame.Config(Background=Frame['Background'])
            Temp_Frame.Config(Border_Size=Frame['Border_Size'], Border_Color=Frame['Border_Color'], Border_Radius=Frame['Radius'], Display=bool(Frame['Display']))
            Temp_Frame.Config(Shadow_Spread=Frame['Shadow_Size'], Shadow_Blur=Frame['Shadow_Size'], Shadow_Color=Frame['Shadow_Color'])
            Temp_Frame.Create()
            Load_Child(Frame['ID'], Temp_Frame, Global)
    except Exception as E:
        Error("Load_Child -> "+str(E))
        
def Cleanup():
    try:
        global Database
        Database.Close()
    except Exception as E:
        Error("Close -> "+str(E))
        
atexit.register(Cleanup)

# -------------------------------------------------------------------------------------------------------------------------------
# GUI
# -------------------------------------------------------------------------------------------------------------------------------

Root = Wavionix.GUI()
Root.Start_Config(Load_Start, Root, globals())
Root.Page(Load, Root, globals())

################################################################################################################################
# Programming End
################################################################################################################################