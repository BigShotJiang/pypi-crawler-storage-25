"""meowcat loops — Loop dataclass + LoopRegistry + 5 default loops.

Loop = Chain + trigger event + exit event. Loop composes existing Chains, mounting them
into the cat's lifecycle via events to form automated execution cycles.

Developer experience::

    from meowcat.loops import Loop, BUILTIN_LOOPS, CONVERSATION_LOOP

    # inspect built-in loops
    for lp in BUILTIN_LOOPS:
        print(f"{lp.name}: trigger={lp.trigger}, chain={lp.chain.name}")

    # execute via cat
    result = await cat.run_loop("conversation", message="hello")

This file has zero third-party dependencies, zero meowagent imports.
"""
# (c) 2025-2026 Axonant. MIT License.


from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from meowcat.chain import BUILTIN_CHAINS, Chain
from meowcat.loop import Lifecycle


# -- Lookup reusable Chains from BUILTIN_CHAINS -------------------------

_MAINTENANCE_CHAIN: Chain = next(
    (c for c in BUILTIN_CHAINS if c.name == "maintenance"),
)
_DIAGNOSTIC_CHAIN: Chain = next(
    (c for c in BUILTIN_CHAINS if c.name == "diagnostic"),
)


# -- Loop dataclass -------------------------------------------------

@dataclass(frozen=True)
class Loop:
    """A named loop: Chain + trigger/exit events.

    A Loop encapsulates a :class:`Chain` execution plus lifecycle event triggers.
    Trigger event is emitted before chain execution, exit event after.

    Attributes:
        name: Unique loop name, e.g. ``"conversation"``
        description: Human-readable description
        chain: Associated chain
        trigger: Trigger event name (None means manual trigger)
        exit_event: Exit event name (None means no exit event)
    """

    name: str
    description: str
    chain: Chain
    trigger: str | None = None
    exit_event: str | None = None


# -- 5 default loops -------------------------------------------------

CONVERSATION_LOOP: Loop = Loop(
    "conversation",
    "Standard conversation loop — hear→route→find→reason→speak→remember",
    chain=Chain(
        "conversation_chain",
        ("hear", "decide_route", "locate", "deep_reason", "speak", "remember"),
        "Conversation chain",
    ),
    trigger=Lifecycle.PERCEIVE_START,
)

TOOL_EXECUTION_LOOP: Loop = Loop(
    "tool_execution",
    "Tool execution loop — hear→route→execute→speak→remember",
    chain=Chain(
        "tool_loop_chain",
        ("hear", "decide_route", "execute_tool", "speak", "remember"),
        "Tool chain",
    ),
    trigger="orchestrate.start",
)

DANGER_RESPONSE_LOOP: Loop = Loop(
    "danger_response",
    "Danger response loop — safety assessment",
    chain=Chain(
        "danger_chain",
        ("assess_safety",),
        "Danger chain",
    ),
    trigger="amygdala.alert",
)

MAINTENANCE_LOOP: Loop = Loop(
    "maintenance",
    "Self-maintenance loop — decay+cleanup",
    chain=_MAINTENANCE_CHAIN,
    trigger="heartbeat.tick",
)

DIAGNOSTIC_LOOP: Loop = Loop(
    "diagnostic",
    "Diagnostic loop — run Stethoscope checkup",
    chain=_DIAGNOSTIC_CHAIN,
    trigger=None,  # manual trigger
)

BUILTIN_LOOPS: tuple[Loop, ...] = (
    CONVERSATION_LOOP,
    TOOL_EXECUTION_LOOP,
    DANGER_RESPONSE_LOOP,
    MAINTENANCE_LOOP,
    DIAGNOSTIC_LOOP,
)


def register_default_loops(
    loop_registry: "LoopRegistry",
    chain_registry: Any,
) -> None:
    """Register the 5 default loops and their associated Chains into the registries.

    For each built-in loop:
    1. If its Chain is not yet registered, register the Chain first
    2. Register the Loop

    Args:
        loop_registry: Loop registry instance
        chain_registry: Chain registry instance (must support register/get)
    """
    for lp in BUILTIN_LOOPS:
        if chain_registry.get(lp.chain.name) is None:
            chain_registry.register(lp.chain)
        loop_registry.register(lp)


# -- LoopRegistry ---------------------------------------------------

@dataclass
class LoopRegistry:
    """Loop registry — manages Loop registration, lookup, and execution.

    Usage::

        registry = LoopRegistry()
        register_default_loops(registry, cat.chain_registry)

        # Lookup
        loop = registry.get("conversation")
        all_loops = registry.list_all()

        # Execute
        result = await registry.run(cat, "conversation", message="hello")
    """

    _loops: dict[str, Loop] = field(default_factory=dict, init=False)
    _loops_list: list[Loop] = field(default_factory=list, init=False)

    def register(self, loop: Loop) -> None:
        """Register a loop. Same name overwrites old value.

        Args:
            loop: Loop instance

        Raises:
            TypeError: loop is not a Loop instance
        """
        if not isinstance(loop, Loop):
            raise TypeError(
                f"Expected Loop instance, got {type(loop).__name__}",
            )
        if loop.name in self._loops:
            self._loops_list.remove(self._loops[loop.name])
        self._loops[loop.name] = loop
        self._loops_list.append(loop)

    def get(self, name: str) -> Loop | None:
        """Look up a loop by name.

        Args:
            name: Loop name

        Returns:
            Loop object, None if not found
        """
        return self._loops.get(name)

    def list_all(self) -> list[Loop]:
        """Return list of all registered loops (registration order)."""
        return list(self._loops_list)

    async def run(self, cat: Any, name: str, **initial_input: Any) -> dict[str, Any]:
        """Execute a loop: trigger event → run chain → exit event.

        Args:
            cat: CatBase instance (must support emit/chain_registry.run)
            name: Loop name
            **initial_input: Initial input

        Returns:
            Chain execution result (dict)

        Raises:
            KeyError: Loop not found, or chain not found
        """
        loop = self.get(name)
        if loop is None:
            raise KeyError(f"Loop '{name}' not found in registry")

        # Trigger event
        if loop.trigger:
            await cat.emit(loop.trigger, initial_input)

        # Execute chain
        result = await cat.chain_registry.run(
            cat, loop.chain.name, **initial_input,
        )

        # Exit event
        if loop.exit_event:
            await cat.emit(loop.exit_event, result)

        return result


# -- LoopSequence dataclass (v1.0.4) ----------------------------------

@dataclass(frozen=True)
class LoopSequence:
    """Meta-loop — sequential/event-driven composition of multiple Loops.

    Composition model layer 5::

        Path → Chain → Loop → LoopSequence

    LoopSequence assembles multiple registered loops into a larger execution unit.

    Attributes:
        name: Unique meta-loop name
        description: Human-readable description
        loops: Sequence of registered ``Loop`` names
        mode: ``"sequential"`` — execute sequentially, previous result
              passed to next step;
              ``"event_driven"`` — execute concurrently, each
              listens for its own trigger event
        stop_on_error: ``True`` — any Loop failure immediately raises
                       exception, stopping subsequent loops;
                       ``False`` — skip failed Loop and continue
    """

    name: str
    description: str = ""
    loops: tuple[str, ...] = ()
    mode: str = "sequential"
    stop_on_error: bool = True

    def __post_init__(self) -> None:
        if self.mode not in ("sequential", "event_driven"):
            raise ValueError(
                f"mode must be 'sequential' or 'event_driven', "
                f"got {self.mode!r}"
            )


# -- Built-in LoopSequence -----------------------------------------------

DAILY_MAINTENANCE_SEQ: LoopSequence = LoopSequence(
    "daily_maintenance",
    "Daily maintenance — self-maintenance then checkup",
    loops=("maintenance", "diagnostic"),
    mode="sequential",
)

BUILTIN_LOOPSEQS: tuple[LoopSequence, ...] = (
    DAILY_MAINTENANCE_SEQ,
)


# -- LoopSequenceRegistry (v1.0.4) ------------------------------------

@dataclass
class LoopSequenceRegistry:
    """Meta-loop registry — manages LoopSequence registration, lookup, and execution.

    Usage::

        registry = LoopSequenceRegistry()
        registry.register(DAILY_MAINTENANCE_SEQ)

        # Execute
        result = await registry.run(cat, "daily_maintenance")
    """

    _seqs: dict[str, LoopSequence] = field(default_factory=dict, init=False)
    _seqs_list: list[LoopSequence] = field(default_factory=list, init=False)

    def register(self, seq: LoopSequence) -> None:
        """Register a meta-loop. Same name overwrites old value.

        Args:
            seq: LoopSequence instance

        Raises:
            TypeError: seq is not a LoopSequence instance
        """
        if not isinstance(seq, LoopSequence):
            raise TypeError(
                f"Expected LoopSequence instance, got {type(seq).__name__}"
            )
        if seq.name in self._seqs:
            self._seqs_list.remove(self._seqs[seq.name])
        self._seqs[seq.name] = seq
        self._seqs_list.append(seq)

    def get(self, name: str) -> LoopSequence | None:
        """Look up a meta-loop by name.

        Args:
            name: Meta-loop name

        Returns:
            LoopSequence object, None if not found
        """
        return self._seqs.get(name)

    def list_all(self) -> list[LoopSequence]:
        """Return list of all registered meta-loops (registration order)."""
        return list(self._seqs_list)

    async def run(
        self, cat: Any, name: str, **initial_input: Any,
    ) -> dict[str, Any]:
        """Execute a meta-loop.

        **sequential mode**: Execute in ``loops`` order, previous step result
        becomes next step kwargs, last result is returned.

        **event_driven mode**: All Loops execute concurrently, each receives
        the same ``initial_input``. Results collected by Loop name as key.

        Args:
            cat: CatBase instance (must support ``cat.loop_registry.run(cat, name, **kw)``)
            name: Meta-loop name
            **initial_input: Initial input

        Returns:
            Last step result (sequential) or ``{loop_name: result, ...}``
            (event_driven)

        Raises:
            KeyError: Meta-loop not found, or referenced Loop not found
            Exception: A Loop failed and ``stop_on_error=True``
        """
        import asyncio

        seq = self.get(name)
        if seq is None:
            raise KeyError(f"LoopSequence '{name}' not found in registry")

        if not seq.loops:
            return {"": dict(initial_input)}

        if seq.mode == "sequential":
            return await self._run_sequential(
                cat, seq, **initial_input,
            )
        return await self._run_event_driven(
            cat, seq, **initial_input,
        )

    async def _run_sequential(
        self, cat: Any, seq: LoopSequence, **initial_input: Any,
    ) -> dict[str, Any]:
        """Execute loops sequentially, passing previous result to next step."""
        current_input: dict[str, Any] = dict(initial_input)
        last_result: Any = current_input

        for loop_name in seq.loops:
            try:
                last_result = await cat.loop_registry.run(
                    cat, loop_name, **current_input,
                )
                if isinstance(last_result, dict):
                    current_input = last_result
                else:
                    current_input = {"_result": last_result}
            except Exception:
                if seq.stop_on_error:
                    raise
                # stop_on_error=False → skip failure, continue
                current_input = dict(initial_input)

        if isinstance(last_result, dict):
            return last_result
        return {"_result": last_result}

    async def _run_event_driven(
        self, cat: Any, seq: LoopSequence, **initial_input: Any,
    ) -> dict[str, Any]:
        """Execute loops concurrently, each receives the same initial_input."""
        import asyncio

        async def _run_one(loop_name: str) -> tuple[str, Any]:
            try:
                result = await cat.loop_registry.run(
                    cat, loop_name, **initial_input,
                )
                return (loop_name, result)
            except Exception as e:
                if seq.stop_on_error:
                    raise
                return (loop_name, {"_error": str(e)})

        tasks = [asyncio.create_task(_run_one(ln)) for ln in seq.loops]
        results: dict[str, Any] = {}

        if seq.stop_on_error:
            # gather mode: any failure propagates exception, remaining tasks cancelled
            gathered = await asyncio.gather(*tasks)
            for loop_name, result in gathered:
                results[loop_name] = result
        else:
            # tolerate errors: wait one by one, collect all results
            for t in asyncio.as_completed(tasks):
                try:
                    loop_name, result = await t
                    results[loop_name] = result
                except Exception as e:
                    # find the failed task
                    for i, task in enumerate(tasks):
                        if task.done() and task.exception():
                            results[seq.loops[i]] = {
                                "_error": str(task.exception()),
                            }
                            break

        return results


__all__ = [
    "Loop", "LoopRegistry",
    "CONVERSATION_LOOP", "TOOL_EXECUTION_LOOP",
    "DANGER_RESPONSE_LOOP", "MAINTENANCE_LOOP", "DIAGNOSTIC_LOOP",
    "BUILTIN_LOOPS", "register_default_loops",
    "LoopSequence", "LoopSequenceRegistry",
    "DAILY_MAINTENANCE_SEQ", "BUILTIN_LOOPSEQS",
]
