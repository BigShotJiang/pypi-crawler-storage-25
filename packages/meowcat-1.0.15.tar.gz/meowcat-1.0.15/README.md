# meowcat

[![Python](https://img.shields.io/badge/Python-3.10+-3776AB?style=flat-square&logo=python&logoColor=white)]()
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg?style=flat-square)](LICENSE)
[![GitHub](https://img.shields.io/badge/GitHub-Axonant%2FMeowAgent-181717?style=flat-square&logo=github)](https://github.com/Axonant/MeowAgent)

**An agent framework built on the biological blueprint of a cat.**

meowcat is the framework layer of the MeowAgent ecosystem — pure cat anatomy:
protocols, wiring, reflexes, tools, and the four-layer abstraction from
atomic signals to composable loops. Bring your own LLM; the cat provides
everything else.

For the full AI agent application built on top of meowcat, see
**[MeowAgent](https://github.com/Axonant/MeowAgent)** — a dual-brain AI agent
with hippocampus memory, multi-cat colony, and cooperative hunting.

---

## Quick Start

```python
from meowcat import create_cat, MEMORY_SEARCH_CHAIN, CONVERSATION_LOOP

class MyBrain:
    name = "cerebrum"
    async def generate(self, prompt, **kw) -> str:
        return f"Meow! You said: {prompt[:50]}"

cat = create_cat("chat-cat", cerebrum=MyBrain())
await cat.chain_registry.run("memory_search", query="hello")
await cat.run_loop("conversation", message="Hello, cat!")
```

---

## Four-Layer Architecture

meowcat builds agents from atomic to composite:

```
  Organ  ->  Path        ->  Chain         ->  Loop
  single     one signal      named Path        Chain + trigger
  unit       recipe          sequence          + exit event
```

| Layer | Module       | Concept                                                     |
| ----- | ------------ | ----------------------------------------------------------- |
| Organ | `biology.py` | 20 default organs (THALAMUS, HIPPOCAMPUS, CEREBRUM...)      |
| Path  | `path.py`    | 26 builtin atomic paths ("locate", "deep_reason"...)        |
| Chain | `chain.py`   | 6 builtin chains (MEMORY_SEARCH_CHAIN, WORKFLOW_CHAIN...)   |
| Loop  | `loops.py`   | 5 default loops (CONVERSATION_LOOP, TOOL_EXECUTION_LOOP...) |

```python
from meowcat import (
    Path, MEMORY_SEARCH_CHAIN, CONVERSATION_LOOP,  # four-layer API
    CatBase, create_cat,                             # skeleton
)

# Path: atomic inter-organ signal
cat.path_registry.run("locate", query="weather")   # THALAMUS -> HIPPOCAMPUS

# Chain: named Path sequence
cat.chain_registry.run("full_reasoning", prompt="Why is the sky blue?")

# Loop: Chain + lifecycle triggers
await cat.run_loop("conversation", message="Hello!")
```

---

## Core Concepts

| Concept     | Module              | What it does                                           |
| ----------- | ------------------- | ------------------------------------------------------ |
| Protocol    | `meowcat.protocols` | Duck-typed organ blueprints (Cerebrum, Ears, Paws...)  |
| Wiring      | `meowcat.wiring`    | Neural connectivity table — who can talk to whom       |
| Signal      | `meowcat.nervous`   | Wiring-validated inter-organ calls (`signal()`)        |
| Reflex      | `meowcat.reflex`    | Stimulus -> response chains (trigger + path)           |
| Stethoscope | `meowcat.diagnose`  | Full-body diagnostic probe (`probe_all()` / `probe()`) |
| Needle      | `meowcat.inject`    | Bypass-wiring write (debug/admin only)                 |
| Tools       | `meowcat.tools`     | Tool/Skill/PawsEngine — every cat has claws            |
| Workflow    | `meowcat.models`    | Long-running workflows with checkpoint/resume          |

---

## Install

```bash
pip install meowcat
```

Dependencies: `pydantic>=2.0` + `anyio>=4.0`. Zero other hard deps.

---

## Architecture

`meowcat` is the **framework layer** — pure cat anatomy. Application logic
lives in **[MeowAgent](https://github.com/Axonant/MeowAgent)**
(the cat factory above this layer).

Read the full architecture: [docs/architecture/00-meowcat-framework.md](docs/架构/00-meowcat-框架架构.md)

---

## Examples

```bash
python -m meowcat.examples.01_organ_host_only   # OrganHost as typed container
python -m meowcat.examples.02_wiring_validation  # Wiring safety validation
python -m meowcat.examples.03_event_bus_only     # EventBus standalone
python -m meowcat.examples.04_custom_cat         # Build a cat from 5 subsystems
python -m meowcat.examples.05_minimal_chat_cat   # Minimal chat cat in <80 lines
python -m meowcat.examples.06_custom_organ       # Write + mount a custom organ
python -m meowcat.examples.07_custom_organ       # Custom organ + Path/Chain/Loop
```

---

## Version History

| Version | Date    | Highlights                                                   |
| ------- | ------- | ------------------------------------------------------------ |
| v1.0.15 | 2026-05 | Long-running workflows with checkpoint/resume                |
| v1.0.14 | 2026-05 | Lifecycle hooks (on_start / on_shutdown)                     |
| v1.0.13 | 2026-05 | Signal middleware pipeline                                   |
| v1.0.12 | 2026-05 | Colony federation transports (TCP/Redis)                     |
| v1.0.11 | 2026-05 | Synthesize path + Loop sequence registry                     |
| v1.0.10 | 2026-05 | Gateway abstraction (CLI / HTTP / WebSocket / Webhook / IPC) |
| v1.0.9  | 2026-05 | CLI facade methods (search_memory, memory_stats, etc.)       |
| v1.0.8  | 2026-05 | Growth organs named (Anomaly/Correction/Crystallizer/Role)   |
| v1.0.7  | 2026-05 | Pluggable component system                                   |
| v1.0.6  | 2026-05 | In-memory stores (GraphStore, VectorStore, SharedStore)      |
| v1.0.5  | 2026-05 | Pipeline + Building blocks                                   |
| v1.0.4  | 2026-05 | Loop sequences (meta-loops)                                  |
| v1.0.3  | 2026-05 | Chain rollback + wiring visualization                        |
| v1.0.2  | 2026-05 | Colony multi-cat management                                  |
| v1.0.1  | 2026-05 | Cat isolation (parent_id, allowed_organs, forbidden_methods) |
| v1.0.0  | 2026-05 | Initial framework release                                    |

---

## License

This project is licensed under the **MIT License**. See [LICENSE](LICENSE) for details.

---

_Built with the biological blueprint of a cat. The framework layer of [MeowAgent](https://github.com/Axonant/MeowAgent)._
