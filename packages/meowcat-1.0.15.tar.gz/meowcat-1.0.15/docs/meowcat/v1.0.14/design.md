# v1.0.14 设计文档 — Cat Lifecycle Hooks（生命周期钩子）

> 来源: `.qoder/plans/meowcat-v1.0.10-roadmap.md` v1.0.14 章节
> 架构参考: `docs/架构/00-meowcat-框架架构.md`

---

## 1. 设计目标

Organ 的 Protocol 定义了 `build_system_prompt()` / `cancel_current()` 等生命周期方法，但都在器官内部。Cat 级别缺少 "启动时做什么" "关闭时做什么" 的统一入口。Lifecycle Hooks 提供框架级的挂载位置。

## 2. 核心设计

### 2.1 CatHook 类型

```python
from collections.abc import Awaitable, Callable

CatHook = Callable[["CatBase"], Awaitable[None]]
```

接受 CatBase 实例的异步可调用对象。定义在 `assembly.py` 顶层。

### 2.2 CatBase 新增方法

```python
class CatBase:
    def on_start(self, hook: CatHook) -> None:
        """注册启动钩子。装配完成后按注册顺序依次调用。"""
        self._start_hooks.append(hook)

    def on_shutdown(self, hook: CatHook) -> None:
        """注册关闭钩子。关闭前按注册**逆序**依次调用。"""
        self._shutdown_hooks.append(hook)
```

### 2.3 start() / shutdown() 集成

```python
async def start(self) -> None:
    await self._events.emit(Lifecycle.START, {"cat": self})
    for hook in self._start_hooks:
        await hook(self)

async def shutdown(self) -> None:
    for hook in reversed(self._shutdown_hooks):
        await hook(self)
    await self._events.emit(Lifecycle.SHUTDOWN, {"cat": self})
```

**顺序逻辑**:

- **start**: 先发射 lifecycle.start 事件 → 再依次调用 on_start hooks。事件在前，表示"猫已启动"，随后 hooks 做初始化。
- **shutdown**: 先逆序调用 on_shutdown hooks → 再发射 lifecycle.shutdown 事件。hooks 在前，清理完后再宣告"猫已关闭"。

**shutdown 逆序原因**: 遵循资源释放的标准模式。后注册的 hook（如 Gateway）先关闭，先注册的 hook（如 DB 连接）后关闭。

### 2.4 与 Loop 的关系

| 概念            | 触发时机          | 用途                                      |
| --------------- | ----------------- | ----------------------------------------- |
| Loop.trigger    | 某个 event 发生时 | 自动化执行回路（已有）                    |
| Cat.on_start    | 猫启动时          | 初始化 Gateway、连接 DB、预热 Kitten Pool |
| Cat.on_shutdown | 猫关闭时          | 关闭 Gateway、保存状态、dismiss kittens   |

Loop 是"运行中的闭环"，Lifecycle Hook 是"出生/死亡时的一次性动作"。两者互补不冲突。

## 3. 设计原则

- **零开销关闭** — 无 hooks 时 start()/shutdown() 行为完全不变（空列表 for 循环零迭代）
- **不改变事件签名** — `Lifecycle.START` / `Lifecycle.SHUTDOWN` 不变
- **不污染器官体系** — hooks 列表在 CatBase 上，不占用 OrganSpec
- **顺序明确** — start 顺序调用，shutdown 逆序调用

## 4. 改动范围

| 文件                  | 改动                                                                 | 行数 |
| --------------------- | -------------------------------------------------------------------- | ---- |
| `meowcat/assembly.py` | CatHook 类型 + 钩子列表 + on_start/on_shutdown + start/shutdown 集成 | +43  |
| `meowcat/__init__.py` | 导出 CatHook                                                         | +2   |
| **合计**              |                                                                      | ~45  |
