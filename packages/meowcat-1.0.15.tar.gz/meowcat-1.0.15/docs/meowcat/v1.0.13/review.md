# v1.0.13 审查记录 — Signal Middleware

> 审查日期: 2026-05-03 | 基版本: v1.0.12

---

## 关键决策

| 决策                                         | 理由                                         |
| -------------------------------------------- | -------------------------------------------- |
| `SignalMiddleware` 定义为 Protocol（非 ABC） | 与框架现有风格一致，鸭子类型                 |
| 中间件方法全部可选（`hasattr` 检测）         | 允许只实现需要的钩子                         |
| `on_error` 不吞异常                          | 中间件是观察者，不应改变错误传播语义         |
| `before` 返回 `None` 短路                    | 简单明确的语义，不引入额外类型               |
| `_middleware` 放在 `Nervous` 上              | 不污染 OrganHost 或 EventBus                 |
| 内置中间件放独立 `middleware.py`             | `nervous.py` 保持核心调度逻辑清晰            |
| 测试用 `anyio.run()` 模式                    | 与 `test_assembly.py` 一致，兼容现有测试框架 |

## 设计质量

- **零开销**: 无中间件时仅多一次空列表 for 循环迭代
- **零入侵**: `signal()` 签名不变，所有现有调用方无需修改
- **可组合**: 多中间件按注册顺序链式执行

## 测试覆盖 (19 个)

| 测试集              | 数量 | 覆盖                                         |
| ------------------- | ---- | -------------------------------------------- |
| SignalCall 数据形状 | 3    | frozen dataclass 属性/默认值/不可变性        |
| 零中间件            | 2    | 同步/异步 signal 行为不变                    |
| before 短路         | 2    | None 短路 / ctx 放行                         |
| after 修改返回值    | 1    | 返回值包装                                   |
| on_error 通知       | 1    | 通知 + 异常继续传播                          |
| 多中间件顺序        | 1    | 注册顺序 = 执行顺序                          |
| SignalLogger        | 1    | 日志记录                                     |
| RateLimiter         | 2    | 限流内放行 / 超限阻断                        |
| TimeoutGuard        | 2    | 截止前放行 / 截止后阻断                      |
| ContextInjector     | 2    | 注入 / 不覆盖已有键                          |
| 边界条件            | 2    | enable_wiring=False / wiring 先于 middleware |
