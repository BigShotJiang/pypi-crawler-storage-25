# v1.0.13 任务清单 — Signal Middleware

> 创建日期: 2026-05-03 | 基版本: v1.0.12

---

## 任务拆解

- [x] 1. `nervous.py` 新增 SignalCall dataclass + SignalMiddleware Protocol + \_middleware 列表
- [x] 2. `nervous.py` Nervous.signal() 集成 before/after/on_error 中间件链
- [x] 3. 创建 `meowcat/middleware.py` 含 4 个内置中间件
- [x] 4. `assembly.py` CatBase 新增 use_middleware() 方法
- [x] 5. `__init__.py` 导出新类型
- [x] 6. 创建 v1.0.13 文档（design / tasks / README）
- [x] 7. 编写测试（19 个）
- [x] 8. 运行全部测试验证零回归
- [x] 9. 更新路线图标记 v1.0.13 完成

---

## 验收清单

- [x] SignalCall dataclass 属性完整 (from_organ/to_organ/method/args/kwargs/timestamp)
- [x] SignalMiddleware Protocol 定义 before/after/on_error
- [x] Nervous.signal() 无中间件时零开销（行为不变）
- [x] before 返回 None 正确短路
- [x] after 可修改/包装返回值
- [x] on_error 通知后异常继续传播
- [x] 多中间件按注册顺序执行
- [x] 4 个内置中间件全部可用
- [x] CatBase.use_middleware() 在 enable_wiring=False 时报错
- [x] 全部现有测试通过（零回归）
- [x] 新测试全部通过 (19 passed)
