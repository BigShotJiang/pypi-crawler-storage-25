# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE.
#

from zope.interface import Interface
from zope.schema import Bool, Int

__docformat__ = 'restructuredtext'

from pyams_app_msc import _


class ICatalogViewItemsPortletNewsletterRendererSettings(Interface):
    """Catalog view items portlet newsletter renderer settings"""

    display_illustrations = Bool(title=_("Display illustrations?"),
                                 description=_("If 'no', view contents will not display "
                                               "illustrations"),
                                 required=True,
                                 default=True)

    display_sessions = Bool(title=_("Display sessions"),
                            description=_("If 'no', incoming sessions will not be displayed"),
                            required=True,
                            default=True)

    sessions_weeks = Int(title=_("Sessions weeks"),
                         description=_("Number of weeks to display sessions"),
                         required=True,
                         default=4)

    min_synopsis_length = Int(title=_("Minimum synopsis length"),
                              description=_("Synopsis text will be truncated using phrases separators (., ! or ?), "
                                            "but final result will be at least of this length"),
                              required=True,
                              default=50)
