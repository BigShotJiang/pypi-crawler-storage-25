# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE.
#

from persistent import Persistent
from zope.container.contained import Contained
from zope.interface import Interface
from zope.schema.fieldproperty import FieldProperty

from pyams_app_msc.shared.catalog.interfaces import ICatalogEntryInfo
from pyams_app_msc.shared.catalog.portlet.skin import CatalogViewItemsPortletRendererMixin
from pyams_app_msc.shared.newsletter.portlet.skin.interfaces import ICatalogViewItemsPortletNewsletterRendererSettings
from pyams_app_msc.shared.newsletter.skin import IPyAMSMSCNewsletterLayer
from pyams_content.shared.view.portlet import IViewItemsPortletSettings
from pyams_content.shared.view.portlet.skin import BaseViewItemsPortletRenderer, WfSharedContentViewItemRenderer
from pyams_i18n.language import BASE_LANGUAGES
from pyams_layer.interfaces import IPyAMSLayer, IPyAMSUserLayer
from pyams_portal.interfaces import IPortalContext, IPortletRenderer
from pyams_template.template import override_template, template_config
from pyams_utils.adapter import adapter_config
from pyams_utils.factory import factory_config

__docformat__ = 'restructuredtext'

from pyams_app_msc import _


#
# Catalog view items portlet newsletter renderer
#

@factory_config(ICatalogViewItemsPortletNewsletterRendererSettings)
class CatalogViewItemsPortletNewsletterRendererSettings(Persistent, Contained):
    """Catalog view items portlet newsletter renderer settings"""

    display_illustrations = FieldProperty(ICatalogViewItemsPortletNewsletterRendererSettings['display_illustrations'])
    display_sessions = FieldProperty(ICatalogViewItemsPortletNewsletterRendererSettings['display_sessions'])
    sessions_weeks = FieldProperty(ICatalogViewItemsPortletNewsletterRendererSettings['sessions_weeks'])
    min_synopsis_length = FieldProperty(ICatalogViewItemsPortletNewsletterRendererSettings['min_synopsis_length'])


@adapter_config(name='catalog-newsletter',
                required=(IPortalContext, IPyAMSLayer, Interface, IViewItemsPortletSettings),
                provides=IPortletRenderer)
@template_config(template='templates/view-catalog-newsletter.pt',
                 layer=IPyAMSLayer)
class CatalogViewItemsPortletNewsletterRenderer(CatalogViewItemsPortletRendererMixin,
                                                BaseViewItemsPortletRenderer):
    """Catalog view items portlet newsletter renderer"""

    label = _("MSC: Newsletter catalog entries")
    weight = 130

    settings_interface = ICatalogViewItemsPortletNewsletterRendererSettings

    def get_entry_info(self, entry):
        """Catalog entry information getter"""
        return ICatalogEntryInfo(entry, None)

    def get_language(self, value):
        translate = self.request.localizer.translate
        return translate(BASE_LANGUAGES.get(value, _("(unknown)")))

    def get_duration(self, value):
        translate = self.request.localizer.translate
        hours = value // 60
        minutes = value % 60
        if hours == 0:
            return translate(_("{} minutes")).format(minutes)
        return translate(_("{}h {}min")).format(hours, minutes)


override_template(WfSharedContentViewItemRenderer,
                  name='catalog-item-newsletter',
                  template='templates/view-catalog-item-newsletter.pt',
                  layer=IPyAMSUserLayer)

override_template(WfSharedContentViewItemRenderer,
                  name='catalog-item-newsletter',
                  template='templates/view-catalog-item-newsletter-email.pt',
                  layer=IPyAMSMSCNewsletterLayer)
