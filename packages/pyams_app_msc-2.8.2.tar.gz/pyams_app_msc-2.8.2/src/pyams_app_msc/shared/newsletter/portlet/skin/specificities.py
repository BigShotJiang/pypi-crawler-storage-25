# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE.
#

from zope.interface import Interface

from pyams_app_msc.shared.newsletter.interfaces import INewsletterInfo
from pyams_content.shared.common.portlet.interfaces import ISharedContentSpecificitiesPortletSettings
from pyams_layer.interfaces import IPyAMSLayer
from pyams_portal.interfaces import IPortalContext, IPortletRenderer
from pyams_portal.skin import PortletRenderer
from pyams_template.template import template_config
from pyams_utils.adapter import adapter_config

__docformat__ = 'restructuredtext'

from pyams_app_msc import _


@adapter_config(name='msc:catalog_entry:newsletter',
                required=(IPortalContext, IPyAMSLayer, Interface, ISharedContentSpecificitiesPortletSettings),
                provides=IPortletRenderer)
@template_config(template='templates/specificities-newsletter.pt',
                 layer=IPyAMSLayer)
class CatalogEntryNewsletterSpecificitiesPortletRenderer(PortletRenderer):
    """Catalog entry newsletter specificities portlet renderer"""

    label = _("MSC: newsletter specificities")
    weight = 110

    newsletter_info = None

    def update(self):
        super().update()
        self.newsletter_info = INewsletterInfo(self.context, None)

    def render(self, template_name=''):
        if self.newsletter_info is None:
            return ''
        return super().render(template_name)
