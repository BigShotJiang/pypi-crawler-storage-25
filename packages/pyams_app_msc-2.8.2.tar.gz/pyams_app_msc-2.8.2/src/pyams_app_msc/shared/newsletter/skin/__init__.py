# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE.
#

from urllib.parse import urlencode

from pyams_app_msc.shared.newsletter.interfaces import IWfNewsletter
from pyams_app_msc.shared.newsletter.skin.layer import IPyAMSMSCNewsletterLayer, PyAMSMSCNewsletterSkin
from pyams_app_msc.shared.newsletter.zmi import NewsletterEmailPreviewPage
from pyams_app_msc.shared.theater.interfaces import IMovieTheater
from pyams_app_msc.skin import msc_email_css
from pyams_layer.interfaces import IPyAMSLayer, IResources
from pyams_pagelet.pagelet import pagelet_config
from pyams_portal.skin.page import PortalContextIndexPage
from pyams_sequence.interfaces import ISequentialIdInfo
from pyams_template.template import layout_config
from pyams_utils.adapter import ContextRequestAdapter, ContextRequestViewAdapter, adapter_config
from pyams_utils.interfaces.url import ICanonicalURL
from pyams_utils.traversing import get_parent
from pyams_utils.url import absolute_url

__docformat__ = 'restructuredtext'


@pagelet_config(name='',
                context=IWfNewsletter,
                layer=IPyAMSMSCNewsletterLayer)
@layout_config(template='templates/newsletter-layout.pt',
               layer=IPyAMSMSCNewsletterLayer)
class NewsletterIndexPage(PortalContextIndexPage):
    """Newsletter index page"""


@adapter_config(required=(IWfNewsletter, IPyAMSMSCNewsletterLayer, NewsletterIndexPage),
                provides=IResources)
@adapter_config(required=(IWfNewsletter, IPyAMSMSCNewsletterLayer, NewsletterEmailPreviewPage),
                provides=IResources)
class NewsletterIndexPageResources(ContextRequestViewAdapter):
    """Newsletter index page resources adapter"""

    resources = (msc_email_css,)


@adapter_config(required=(IWfNewsletter, IPyAMSLayer),
                provides=ICanonicalURL)
class NewsletterCanonicalURL(ContextRequestAdapter):
    """Newsletter canonical URL adapter"""

    def get_url(self, view_name=None, query=None):
        theater = get_parent(self.context, IMovieTheater)
        query = urlencode(query) if query else None
        return absolute_url(theater, self.request,
                            f"+/{ISequentialIdInfo(self.context).get_base_oid().strip()}"
                            f"::{self.context.content_url}"
                            f"{'/{}'.format(view_name) if view_name else '.html'}"
                            f"{'?{}'.format(query) if query else ''}")
