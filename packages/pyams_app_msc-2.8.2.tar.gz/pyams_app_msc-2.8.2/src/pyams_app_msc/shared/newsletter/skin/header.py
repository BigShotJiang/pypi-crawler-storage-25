#
# Copyright (c) 2015-2026 Thierry Florac <tflorac AT ulthar.net>
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE.
#

"""PyAMS_*** module

"""

from zope.interface import Interface

from pyams_layer.interfaces import IPyAMSLayer
from pyams_template.template import template_config
from pyams_viewlet.viewlet import contentprovider_config, ViewContentProvider


@contentprovider_config(name='newsletter-header',
                        layer=IPyAMSLayer, view=Interface)
@template_config(template='templates/newsletter-header.pt',
                 layer=IPyAMSLayer)
class NewsletterHeaderContentProvider(ViewContentProvider):
    """Newsletter header content provider"""
