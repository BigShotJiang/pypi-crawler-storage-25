#
# Copyright (c) 2015-2023 Thierry Florac <tflorac AT ulthar.net>
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE.
#

"""PyAMS_app_msc.shared.newsletter.skin.interfaces module

"""

from pyams_app_msc.skin import IPyAMSMSCLayer
from pyams_layer.interfaces import ISkin
from pyams_utils.registry import utility_config

__docformat__ = 'restructuredtext'


class IPyAMSMSCNewsletterLayer(IPyAMSMSCLayer):
    """Newsletter layer marker interface"""


@utility_config(name='PyAMS MSC newsletter skin',
                provides=ISkin)
class PyAMSMSCNewsletterSkin:
    """PyAMS MSC newsletter skin"""

    label = None  # not visible in the skins selection list
    layer = IPyAMSMSCNewsletterLayer
