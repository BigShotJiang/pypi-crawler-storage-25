#
# Copyright (c) 2015-2025 Thierry Florac <tflorac AT ulthar.net>
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE.
#

"""PyAMS_app_msc.shared.newsletter module

"""

from hypatia.catalog import CatalogQuery
from hypatia.interfaces import ICatalog
from hypatia.query import And, Eq
from persistent import Persistent
from pyramid.events import subscriber
from zope.container.contained import Contained
from zope.interface import implementer
from zope.lifecycleevent.interfaces import IObjectCreatedEvent
from zope.schema.fieldproperty import FieldProperty

from pyams_app_msc.feature.messaging.interfaces import IMessagingSettings
from pyams_app_msc.feature.profile.interfaces import IUserProfile
from pyams_app_msc.shared.newsletter.interfaces import INewsletter, INewsletterAudienceInfo, INewsletterInfo, \
    INewsletterRecipientsInfo, INewsletterRecipientsUpdateEvent, IWfNewsletter, NEWSLETTER_AUDIENCE_KEY, \
    NEWSLETTER_CONTENT_NAME, NEWSLETTER_CONTENT_TYPE, NEWSLETTER_INFORMATION_KEY, NEWSLETTER_PAGE_NAME, \
    NEWSLETTER_RECIPIENTS_KEY, NewsletterRecipientsUpdateEvent
from pyams_app_msc.shared.newsletter.skin.layer import PyAMSMSCNewsletterSkin
from pyams_app_msc.shared.theater.interfaces import IMovieTheater
from pyams_catalog.query import CatalogResultSet
from pyams_content.component.illustration.interfaces import IIllustrationTarget, ILinkIllustrationTarget
from pyams_content.component.paragraph.interfaces import IParagraphContainerTarget
from pyams_content.feature.preview.interfaces import IPreviewTarget
from pyams_content.feature.review.interfaces import IReviewTarget
from pyams_content.root import ISiteRootInfos
from pyams_content.shared.common import SharedContent, WfSharedContent
from pyams_content.shared.common.interfaces import ISharedContent, IWfSharedContent
from pyams_i18n.interfaces import II18n
from pyams_layer.skin import apply_skin
from pyams_mail.interfaces import IPrincipalMailInfo
from pyams_mail.message import HTMLMessage
from pyams_pagelet.interfaces import IPagelet
from pyams_portal.interfaces import IPortalContext
from pyams_security.interfaces import ISecurityManager, IViewContextPermissionChecker
from pyams_security.interfaces.base import IUnavailablePrincipalInfo
from pyams_sequence.interfaces import IInternalReferencesList
from pyams_sequence.reference import get_reference_target
from pyams_site.interfaces import ISiteRoot
from pyams_utils.adapter import ContextAdapter, adapter_config, get_annotation_adapter
from pyams_utils.factory import factory_config, get_interface_base_name
from pyams_utils.fanstatic import inject_resources
from pyams_utils.list import boolean_iter
from pyams_utils.registry import get_pyramid_registry, get_utility
from pyams_utils.request import INTERNAL_USER_ID, create_request, query_request
from pyams_utils.traversing import get_parent
from pyams_workflow.interfaces import IObjectClonedEvent, IWorkflow, IWorkflowState, IWorkflowTransitionEvent

__docformat__ = 'restructuredtext'


@factory_config(INewsletterInfo)
class NewsletterInfo(Persistent, Contained):
    """Newsletter persistent information"""

    legend = FieldProperty(INewsletterInfo['legend'])
    introduction = FieldProperty(INewsletterInfo['introduction'])


@adapter_config(required=IWfNewsletter,
                provides=INewsletterInfo)
def newsletter_info(context):
    """Newsletter information adapter"""
    return get_annotation_adapter(context, NEWSLETTER_INFORMATION_KEY, INewsletterInfo)


@factory_config(INewsletterAudienceInfo)
class NewsletterAudienceInfo(Persistent, Contained):
    """Newsletter audience persistent information"""

    activities = FieldProperty(INewsletterAudienceInfo['activities'])


@adapter_config(required=IWfNewsletter,
                provides=IInternalReferencesList)
class NewsletterInternalReferences(ContextAdapter):
    """Newsletter internal references adapter"""

    @property
    def references(self):
        audience_info = INewsletterAudienceInfo(self.context)
        if audience_info is not None:
            return audience_info.activities

    use_references_for_views = True

    def get_targets(self, state=None, request=None):
        """Internal references iterator"""
        yield from (
            get_reference_target(reference, state, request)
            for reference in self.references
        )


@adapter_config(required=IWfNewsletter,
                provides=INewsletterAudienceInfo)
def newsletter_audience(context):
    """Newsletter audience information adapter"""
    return get_annotation_adapter(context, NEWSLETTER_AUDIENCE_KEY, INewsletterAudienceInfo)


@factory_config(INewsletterRecipientsInfo)
class NewsletterRecipientsInfo(Persistent, Contained):
    """Newsletter recipients persistent information"""

    structures_types = FieldProperty(INewsletterRecipientsInfo['structures_types'])
    _recipients = FieldProperty(INewsletterRecipientsInfo['recipients'])
    sent_to = FieldProperty(INewsletterRecipientsInfo['sent_to'])

    @property
    def recipients(self):
        """Recipients property getter"""
        return self._recipients

    @recipients.setter
    def recipients(self, value):
        """Recipients property setter"""
        old_recipients = set(self.sent_to or ())
        new_recipients = set(value) - old_recipients
        self._recipients = value
        if new_recipients:
            sm = get_utility(ISecurityManager)
            new_principals = [
                sm.get_principal(principal_id)
                for principal_id in new_recipients
            ]
            newsletter = get_parent(self, IWfNewsletter)
            registry = get_pyramid_registry()
            registry.notify(NewsletterRecipientsUpdateEvent(newsletter, new_principals))

    def get_recipients(self):
        """Get full list of recipients"""
        sm = get_utility(ISecurityManager)
        theater = get_parent(self, IMovieTheater)
        catalog = get_utility(ICatalog)
        params = And(Eq(catalog['object_types'], get_interface_base_name(IUserProfile)),
                     Eq(catalog['profile_theaters'], theater.__name__))
        results = set()
        # get principals based on selected structures types
        for user_profile in CatalogResultSet(CatalogQuery(catalog).query(params)):
            principal_id = user_profile.principal_id
            if principal_id in results:
                continue
            principal = sm.get_principal(principal_id)
            if (principal is None) or IUnavailablePrincipalInfo.providedBy(principal):
                continue
            if (not IUserProfile.providedBy(user_profile)) or \
                    (not user_profile.active) or \
                    (not user_profile.subscribe_to_newsletters):
                continue
            if (principal_id in (self.recipients or ())) or \
                    (set(self.structures_types or ()) & set(user_profile.structures_types or ())):
                results.add(principal_id)
                yield principal
        # get principals selected manually
        for principal_id in self.recipients or ():
            if principal_id not in results:
                principal = sm.get_principal(principal_id)
                if (principal is None) or IUnavailablePrincipalInfo.providedBy(principal):
                    continue
                user_profile = IUserProfile(principal, None)
                if (not IUserProfile.providedBy(user_profile)) or \
                        (not user_profile.active) or \
                        (not user_profile.subscribe_to_newsletters):
                    continue
                results.add(principal_id)
                yield principal


@adapter_config(required=IWfNewsletter,
                provides=INewsletterRecipientsInfo)
def newsletter_recipients(context):
    """Newsletter recipients information adapter"""
    return get_annotation_adapter(context, NEWSLETTER_RECIPIENTS_KEY, INewsletterRecipientsInfo)


@adapter_config(required=INewsletterInfo,
                provides=IViewContextPermissionChecker)
@adapter_config(required=INewsletterAudienceInfo,
                provides=IViewContextPermissionChecker)
@adapter_config(required=INewsletterRecipientsInfo,
                provides=IViewContextPermissionChecker)
def newsletter_info_permission_checker(context):
    """Newsletter info permission checker"""
    entry = get_parent(context, IWfNewsletter)
    return IViewContextPermissionChecker(entry)


@factory_config(IWfNewsletter)
@factory_config(IWfSharedContent, name=NEWSLETTER_CONTENT_TYPE)
@implementer(IIllustrationTarget, ILinkIllustrationTarget,
             IParagraphContainerTarget, IPortalContext, IReviewTarget, IPreviewTarget)
class WfNewsletter(WfSharedContent):
    """Newsletter persistent class"""

    content_type = NEWSLETTER_CONTENT_TYPE
    content_name = NEWSLETTER_CONTENT_NAME
    content_intf = IWfNewsletter

    def publish(self, recipients=None):
        """Send published newsletter to it's recipients"""
        current_request = query_request()
        settings = IMessagingSettings(current_request.root, None)
        if settings is None:
            return
        mailer = settings.get_mailer()
        if mailer is None:
            return
        recipients_info = INewsletterRecipientsInfo(self)
        if recipients is None:
            recipients = recipients_info.get_recipients()
        has_recipients, recipients = boolean_iter(recipients)
        if has_recipients:
            theater = get_parent(self, IMovieTheater)
            root = get_parent(theater, ISiteRoot)
            infos = ISiteRootInfos(root, None)
            new_request = create_request(root=root,
                                         base_url=infos.public_url if infos is not None else None,
                                         path=f'/{theater.__name__}',
                                         context=self,
                                         view_name='',
                                         principal_id=INTERNAL_USER_ID)
            apply_skin(new_request, PyAMSMSCNewsletterSkin)
            registry = new_request.registry
            pagelet = registry.queryMultiAdapter((self, new_request), IPagelet)
            if pagelet is not None:
                sm = get_utility(ISecurityManager)
                message_body = inject_resources(new_request, registry, pagelet)
                send_to = recipients_info.sent_to or set()
                for principal in recipients:
                    raw_principal = sm.get_raw_principal(principal.id)
                    mail_info = IPrincipalMailInfo(raw_principal, None)
                    if mail_info is None:
                        continue
                    for title, email in mail_info.get_addresses():
                        message = HTMLMessage(subject=f"{settings.subject_prefix} "
                                                      f"{II18n(self).query_attribute('title', request=new_request)}",
                                              from_addr=f'{settings.source_name} <{settings.source_address}>',
                                              to_addr=f'{title} <{email}>',
                                              html=message_body)
                        mailer.send(message)
                    send_to.add(principal.id)
                recipients_info.sent_to = send_to


@factory_config(INewsletter)
@factory_config(ISharedContent, name=NEWSLETTER_CONTENT_TYPE)
class Newsletter(SharedContent):
    """Workflow managed newsletter"""

    content_type = NEWSLETTER_CONTENT_TYPE
    content_name = NEWSLETTER_CONTENT_NAME


@subscriber(IWorkflowTransitionEvent, context_selector=IWfNewsletter)
def handle_newsletter_transition(event):
    """Handle newsletter transition"""
    workflow = event.workflow
    if (event.source not in workflow.visible_states) and \
            (event.destination in workflow.visible_states):
        newsletter = IWfNewsletter(event.object)
        newsletter.publish()


@subscriber(INewsletterRecipientsUpdateEvent, context_selector=IWfNewsletter)
def handle_newsletter_recipients_update(event):
    """Handle newsletter recipients update"""
    newsletter = IWfNewsletter(event.object)
    workflow = IWorkflow(newsletter, None)
    if workflow is not None:
        wf_state = IWorkflowState(newsletter, None)
        if (wf_state is not None) and (wf_state.state in workflow.visible_states):
            newsletter.publish(event.new_recipients)


@subscriber(IObjectCreatedEvent, context_selector=IWfNewsletter)
@subscriber(IObjectClonedEvent, context_selector=IWfNewsletter)
def handle_cloned_newsletter(event):
    """Handle cloned newsletter"""
    newsletter = IWfNewsletter(event.object)
    recipients_info = INewsletterRecipientsInfo(newsletter)
    recipients_info.sent_to = set()
