#
# Copyright (c) 2015-2025 Thierry Florac <tflorac AT ulthar.net>
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE.
#

"""PyAMS_app_msc.shared.newsletter.manager module

"""

from zope.container.btree import BTreeContainer
from zope.location.interfaces import ISublocations
from zope.traversing.interfaces import ITraversable

from pyams_app_msc.shared.newsletter.interfaces import INewsletterManager, INewsletterManagerTarget, \
    NEWSLETTER_CONTENT_TYPE, NEWSLETTER_MANAGER_KEY
from pyams_app_msc.shared.theater.interfaces import IMovieTheater
from pyams_content.shared.common.manager import InnerSharedTool
from pyams_utils.adapter import ContextAdapter, adapter_config, get_annotation_adapter
from pyams_utils.factory import factory_config
from pyams_utils.traversing import get_parent

__docformat__ = 'restructuredtext'


@factory_config(INewsletterManager)
class NewsletterManager(BTreeContainer, InnerSharedTool):
    """Newsletter manager"""

    shared_content_type = NEWSLETTER_CONTENT_TYPE
    
    shared_content_menu = False
    shared_tool_dashboard = False

    @property
    def shared_content_workflow(self):
        parent = get_parent(self, IMovieTheater)
        return parent.shared_content_workflow


@adapter_config(required=INewsletterManagerTarget,
                provides=INewsletterManager)
def newsletter_manager(context):
    """Newsletter manager factory"""
    return get_annotation_adapter(context, NEWSLETTER_MANAGER_KEY, INewsletterManager,
                                  name='++newsletter++')


@adapter_config(name='newsletter',
                required=INewsletterManagerTarget,
                provides=ITraversable)
class NewsletterManagerTraverser(ContextAdapter):
    """Newsletter manager traverser"""

    def traverse(self, name, furtherPath=None):
        """Newsletter getter"""
        return INewsletterManager(self.context, None)


@adapter_config(name='newsletter',
                required=INewsletterManagerTarget,
                provides=ISublocations)
class NewsletterManagerSublocations(ContextAdapter):
    """Newsletter manager sub-locations"""

    def sublocations(self):
        """Newsletter manager sub-locations iterator"""
        manager = INewsletterManager(self.context, None)
        if manager is not None:
            yield from manager.values()
