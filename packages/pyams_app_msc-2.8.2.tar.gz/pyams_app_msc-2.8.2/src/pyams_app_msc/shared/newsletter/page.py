#
# Copyright (c) 2015-2023 Thierry Florac <tflorac AT ulthar.net>
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE.
#

"""PyAMS_*** module

"""

from pyams_app_msc.shared.newsletter.interfaces import INewsletterManager, INewsletterManagerTarget, \
    INewsletterManagerTargetPortalPage, IWfNewsletter, NEWSLETTER_PAGE_NAME
from pyams_content.shared.common.portal import shared_content_portal_page
from pyams_portal.interfaces import IPortalPage, IPortalPortletsConfiguration, PORTAL_PAGE_KEY
from pyams_portal.page import PortalPage, portal_context_portlets_configuration
from pyams_utils.adapter import adapter_config, get_annotation_adapter
from pyams_utils.factory import factory_config
from pyams_utils.traversing import get_parent
from pyams_utils.zodb import volatile_property

__docformat__ = 'restructuredtext'


#
# Newsletter manager target portal pages
#

class NewsletterManagerTargetPageMixin:
    """Newsletter manager target portal page mixin class"""
    
    @volatile_property
    def can_inherit(self):
        return False


@factory_config(INewsletterManagerTargetPortalPage)
class NewsletterManagerTargetPortalPage(NewsletterManagerTargetPageMixin, PortalPage):
    """Movie theater newsletter portal page"""


@adapter_config(name=NEWSLETTER_PAGE_NAME,
                required=INewsletterManagerTarget,
                provides=IPortalPage)
def newsletter_manager_target_page(context, page_name=NEWSLETTER_PAGE_NAME):
    """Newsletter manager target portal page factory"""
    
    def set_page_name(page):
        """Set page name after creation"""
        page.name = page_name
    
    key = f'{PORTAL_PAGE_KEY}::{page_name}' if page_name else PORTAL_PAGE_KEY
    return get_annotation_adapter(context, key, INewsletterManagerTargetPortalPage,
                                  name=f'++page++{page_name}',
                                  callback=set_page_name)


@adapter_config(name=NEWSLETTER_PAGE_NAME,
                required=INewsletterManagerTarget,
                provides=IPortalPortletsConfiguration)
def newsletter_manager_target_portlets_configuration(context):
    """Newsletter manager target portlets configuration"""
    return portal_context_portlets_configuration(context, page_name=NEWSLETTER_PAGE_NAME)


#
# Newsletter portal pages
#

@adapter_config(required=IWfNewsletter,
                provides=IPortalPage)
@adapter_config(name=NEWSLETTER_PAGE_NAME,
                required=IWfNewsletter,
                provides=IPortalPage)
def newsletter_page_factory(context):
    """Newsletter page factory"""
    return shared_content_portal_page(context, page_name=NEWSLETTER_PAGE_NAME)


@adapter_config(name=NEWSLETTER_PAGE_NAME,
                required=IWfNewsletter,
                provides=IPortalPortletsConfiguration)
def newsletter_portlets_configuration(context):
    """Newsletter portlets configuration"""
    return portal_context_portlets_configuration(context, page_name=NEWSLETTER_PAGE_NAME)


@adapter_config(name=NEWSLETTER_PAGE_NAME,
                required=INewsletterManager,
                provides=IPortalPortletsConfiguration)
def newsletter_manager_portlets_configuration(context):
    """Newsletter manager portlets configuration"""
    parent = get_parent(context, INewsletterManagerTarget)
    return portal_context_portlets_configuration(parent, page_name=NEWSLETTER_PAGE_NAME)
