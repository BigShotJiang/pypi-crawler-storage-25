#
# Copyright (c) 2015-2025 Thierry Florac <tflorac AT ulthar.net>
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE.
#

"""PyAMS_app_msc.shared.newsletter.interfaces module

"""

from zope.annotation.interfaces import IAttributeAnnotatable
from zope.container.constraints import contains
from zope.interface import Interface, implementer
from zope.interface.interfaces import IObjectEvent, ObjectEvent
from zope.schema import Choice, List

from pyams_app_msc.reference.structure import STRUCTURE_TYPES_VOCABULARY
from pyams_content.shared.common.interfaces import IInnerSharedToolPortalContext, ISharedContent, \
    IWfSharedContentPortalContext
from pyams_i18n.schema import I18nTextLineField
from pyams_portal.interfaces import IPortalPage
from pyams_security.schema import PrincipalsSetField
from pyams_sequence.schema import InternalReferencesListField
from pyams_utils.schema import HTMLField

__docformat__ = 'restructuredtext'

from pyams_app_msc import _


NEWSLETTER_INFORMATION_KEY = 'msc.newsletter_info'


class INewsletterInfo(Interface):
    """Newsletter additional information interface"""

    legend = I18nTextLineField(title=_("Legend"),
                               description=_("Introduction title"),
                               required=False)

    introduction = HTMLField(title=_("Introduction"),
                             required=False)


NEWSLETTER_AUDIENCE_KEY = 'msc.newsletter_audience'


class INewsletterAudienceInfo(Interface):
    """Newsletter audience information interface"""

    activities = InternalReferencesListField(title=_("Selected activities"),
                                             description=_("List of activities which will be included "
                                                           "into this newsletter"),
                                             required=False)


NEWSLETTER_RECIPIENTS_KEY = 'msc.newsletter_recipients'


class INewsletterRecipientsInfo(Interface):
    """Newsletter recipients information interface"""

    structures_types = List(title=_("Structures types"),
                            description=_("List of structures types associated with this newsletter; structures types "
                                          "are used to select principals to which this newsletter will be sent"),
                            value_type=Choice(vocabulary=STRUCTURE_TYPES_VOCABULARY),
                            required=True)

    recipients = PrincipalsSetField(title=_("newsletter-recipients", default="Specific recipients"),
                                    description=_("List of principals which will receive this newsletter, even if "
                                                  "located in different structures types; if this list is updated "
                                                  "while this newsletter has already been sent, the new recipients "
                                                  "will be notified immediately"),
                                    required=False)

    sent_to = PrincipalsSetField(title=_("Sended recipients"),
                                 description=_("This is the list of principals to which this newsletter was actually "
                                               "sent"),
                                 required=False)

    def get_recipients(self):
        """Get full list of recipients as principals"""


class INewsletterRecipientsUpdateEvent(IObjectEvent):
    """Newsletter recipients update event interface"""

    new_recipients = PrincipalsSetField(title=_("Sended recipients"),
                                        description=_("This is the list of principals to which this newsletter was actually "
                                                      "sent"),
                                        required=False)


@implementer(INewsletterRecipientsUpdateEvent)
class NewsletterRecipientsUpdateEvent(ObjectEvent):
    """Newsletter recipients update event"""

    def __init__(self, object, new_recipients):
        super().__init__(object)
        self.new_recipients = new_recipients


NEWSLETTER_CONTENT_TYPE = 'newsletter'
NEWSLETTER_CONTENT_NAME = _("Newsletter")


class IWfNewsletter(IWfSharedContentPortalContext):
    """Newsletter interface"""

    def publish(self, recipients=None):
        """Send published newsletter to it's recipients

        If `recipients` argument is set, the newsletter is only sent to provided recipients; otherwise,
        it is sent to all it's recipients.
        """


class INewsletter(ISharedContent):
    """Workflow managed newsletter interface"""


NEWSLETTER_MANAGER_KEY = 'msc.newsletter'


class INewsletterManager(IInnerSharedToolPortalContext):
    """Newsletter manager interface"""

    contains(INewsletter)


NEWSLETTER_PAGE_NAME = 'newsletter'


class INewsletterManagerTarget(IAttributeAnnotatable):
    """Newsletter manager target marker interface"""


class INewsletterManagerTargetPortalPage(IPortalPage):
    """Newsletter manager target portal page marker interface"""
