#
# Copyright (c) 2015-2023 Thierry Florac <tflorac AT ulthar.net>
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE.
#

"""PyAMS_*** module

"""

from zope.interface import Interface

from pyams_content.zmi.interfaces import IAllDashboardMenu, IDashboardTable, IMyDashboardMenu
from pyams_zmi.interfaces.viewlet import IContentManagementMenu

__docformat__ = 'restructuredtext'


class INewsletterManagementMenu(IContentManagementMenu):
    """Newsletter management menu"""


class IMyNewsletterDashboardMenu(IMyDashboardMenu):
    """My newsletter management menu marker interface"""


class IAllNewsletterDashboardMenu(IAllDashboardMenu):
    """All newsletter management menu marker interface"""


class INewsletterManagementView(Interface):
    """Newsletter management view marker interface"""


class INewsletterDashboardTable(IDashboardTable):
    """Newsletter dashboard table"""
