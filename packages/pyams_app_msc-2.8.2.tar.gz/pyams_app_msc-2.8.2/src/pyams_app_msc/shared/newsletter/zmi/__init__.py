# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE.
#

from zope.interface import Interface

from pyams_app_msc.interfaces import MANAGE_NEWSLETTER_PERMISSION
from pyams_app_msc.shared.newsletter.interfaces import INewsletterInfo, INewsletterManager, INewsletterManagerTarget, \
    IWfNewsletter, NEWSLETTER_CONTENT_TYPE
from pyams_app_msc.shared.newsletter.skin.layer import IPyAMSMSCNewsletterLayer, PyAMSMSCNewsletterSkin
from pyams_app_msc.shared.newsletter.zmi.interfaces import INewsletterManagementView
from pyams_app_msc.shared.theater.interfaces import IMovieTheater
from pyams_content.feature.preview.zmi import PreviewTargetActions
from pyams_content.shared.common.interfaces import ISharedContent
from pyams_content.shared.common.zmi import SharedContentAddAction, SharedContentAddForm, \
    SharedContentPropertiesEditForm
from pyams_content.shared.common.zmi.content import SharedContentHeaderViewlet
from pyams_form.ajax import AJAXFormRenderer, ajax_form_config
from pyams_form.field import Fields
from pyams_form.interfaces.form import IAJAXFormRenderer, IFormContent
from pyams_layer.interfaces import IPyAMSLayer
from pyams_layer.skin import apply_skin
from pyams_pagelet.pagelet import pagelet_config
from pyams_portal.skin.page import PortalContextPreviewPage
from pyams_security.interfaces import IViewContextPermissionChecker
from pyams_security.interfaces.base import VIEW_SYSTEM_PERMISSION
from pyams_skin.interfaces.viewlet import IHeaderViewletManager
from pyams_skin.viewlet.actions import ContextAction
from pyams_template.template import layout_config
from pyams_utils.adapter import adapter_config
from pyams_utils.factory import get_object_factory
from pyams_utils.traversing import get_parent
from pyams_utils.url import absolute_url
from pyams_viewlet.viewlet import viewlet_config
from pyams_zmi.form import AdminEditForm
from pyams_zmi.interfaces import IAdminLayer
from pyams_zmi.interfaces.viewlet import IPropertiesMenu, IToolbarViewletManager
from pyams_zmi.zmi.viewlet.menu import NavigationMenuItem

__docformat__ = 'restructuredtext'

from pyams_app_msc import _


@viewlet_config(name='add-newsletter.action',
                context=INewsletterManagerTarget, layer=IAdminLayer,
                view=INewsletterManagementView,
                manager=IToolbarViewletManager, weight=10,
                permission=MANAGE_NEWSLETTER_PERMISSION)
class NewsletterAddAction(SharedContentAddAction):
    """Newsletter add action"""

    label = _("Add new: newsletter")
    href = 'add-newsletter.html'
    
    
@ajax_form_config(name='add-newsletter.html',
                  context=INewsletterManagerTarget, layer=IPyAMSLayer,
                  permission=MANAGE_NEWSLETTER_PERMISSION)
class NewsletterAddForm(SharedContentAddForm):
    """Newsletter add form"""
    
    fields = Fields(IWfNewsletter).select('title', 'notepad')
    
    _edit_permission = MANAGE_NEWSLETTER_PERMISSION
    
    @property
    def shared_content_factory(self):
        return get_object_factory(ISharedContent, name=NEWSLETTER_CONTENT_TYPE)

    @property
    def container_target(self):
        return INewsletterManager(self.context)


@adapter_config(required=(INewsletterManagerTarget, IAdminLayer, NewsletterAddForm),
                provides=IAJAXFormRenderer)
class NewsletterAddFormRenderer(AJAXFormRenderer):
    """Newsletter add form renderer"""

    def render(self, changes):
        return {
            'status': 'redirect',
            'location': self.form.next_url()
        }


@viewlet_config(name='pyams.content_header',
                context=IWfNewsletter, layer=IAdminLayer,
                manager=IHeaderViewletManager, weight=10)
class NewsletterHeaderViewlet(SharedContentHeaderViewlet):
    """Newsletter header viewlet"""

    @property
    def parent_target_url(self):
        """Parent target URL"""
        tool = get_parent(self.context, IMovieTheater)
        if tool is None:
            return None
        return absolute_url(tool, self.request, 'admin#newsletters-dashboard.html')


@ajax_form_config(name='properties.html',
                  context=IWfNewsletter, layer=IPyAMSLayer,
                  permission=VIEW_SYSTEM_PERMISSION)
class NewsletterPropertiesEditForm(SharedContentPropertiesEditForm):
    """Newsletter properties edit form"""

    interface = IWfNewsletter
    fieldnames = ('title', 'short_name', 'content_url', 'header',
                  'description', 'notepad')


@viewlet_config(name='newsletter-info.menu',
                context=IWfNewsletter, layer=IPyAMSLayer,
                manager=IPropertiesMenu, weight=15,
                permission=VIEW_SYSTEM_PERMISSION)
class NewsletterInformationMenu(NavigationMenuItem):
    """Newsletter information menu"""

    label = _("Newsletter details")
    href = '#newsletter-info.html'


@ajax_form_config(name='newsletter-info.html',
                  context=IWfNewsletter, layer=IPyAMSLayer,
                  permission=VIEW_SYSTEM_PERMISSION)
class NewsletterInformationEditForm(AdminEditForm):
    """Newsletter information edit form"""

    title = _("Newsletter information")
    legend = _("Custom properties")

    fields = Fields(INewsletterInfo)


@adapter_config(required=(IWfNewsletter, IPyAMSLayer, NewsletterInformationEditForm),
                provides=IFormContent)
def newsletter_info_edit_form_content(context, request, form):
    """Newsletter information edit form content getter"""
    return INewsletterInfo(context)


@adapter_config(required=(INewsletterInfo, IAdminLayer, NewsletterInformationEditForm),
                provides=IViewContextPermissionChecker)
def newsletter_info_permission_checker(context, request, form):
    """Newsletter information edit form content getter"""
    newsletter = get_parent(context, IWfNewsletter)
    return IViewContextPermissionChecker(newsletter)


#
# NEwsletter email preview
#

@viewlet_config(name='pyams_app_msc.newsletter.email-preview',
                context=IWfNewsletter, layer=IAdminLayer, view=Interface,
                manager=PreviewTargetActions, weight=30)
class NewsletterEmailPreviewAction(ContextAction):
    """Blank window preview action"""

    icon_class = 'far fa-newspaper'
    hint = _("Open email preview in new tab")
    hint_placement = 'bottom'

    href = 'email-preview.html'
    target = '_blank'


@pagelet_config(name='email-preview.html',
                context=IWfNewsletter, layer=IPyAMSLayer,
                permission=VIEW_SYSTEM_PERMISSION)
@layout_config(template='../skin/templates/newsletter-layout.pt',
               layer=IPyAMSMSCNewsletterLayer)
class NewsletterEmailPreviewPage(PortalContextPreviewPage):
    """Newsletter email preview page"""

    def update(self):
        apply_skin(self.request, PyAMSMSCNewsletterSkin)
        super().update()
