# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE.
#

from pyramid.view import view_config
from zope.interface import Interface, implementer

from pyams_app_msc.shared.newsletter.interfaces import NEWSLETTER_CONTENT_NAME, INewsletterManagerTarget
from pyams_app_msc.shared.newsletter.zmi.dashboard import NewsletterManagerDashboardMenuMixin, \
    NewsletterManagerDashboardValuesMixin, NewsletterManagerDashboardView
from pyams_app_msc.shared.newsletter.zmi.interfaces import IAllNewsletterDashboardMenu, INewsletterDashboardTable
from pyams_content.shared.common.zmi.search import ISharedToolAdvancedSearchQuery, SharedToolAdvancedSearchForm, \
    SharedToolAdvancedSearchMenu, SharedToolAdvancedSearchResultsTable, SharedToolAdvancedSearchResultsValues, \
    SharedToolAdvancedSearchResultsView, SharedToolAdvancedSearchView, SharedToolQuickSearchPageView, \
    SharedToolQuickSearchResultsTable, SharedToolQuickSearchResultsValues, SharedToolQuickSearchView, \
    get_json_search_results
from pyams_form.field import Fields
from pyams_form.interfaces.form import IFormFields
from pyams_layer.interfaces import IPyAMSLayer
from pyams_pagelet.pagelet import pagelet_config
from pyams_security.interfaces.base import VIEW_SYSTEM_PERMISSION
from pyams_table.interfaces import IValues
from pyams_utils.adapter import adapter_config
from pyams_viewlet.viewlet import viewlet_config
from pyams_zmi.interfaces import IAdminLayer
from pyams_zmi.interfaces.table import IInnerTable

__docformat__ = 'restructuredtext'

from pyams_app_msc import _


#
# Newsletters quick search
#

@implementer(INewsletterDashboardTable)
class NewsletterManagerQuickSearchResultsTable(SharedToolQuickSearchResultsTable):
    """Newsletter manager quick search results table"""


@adapter_config(required=(INewsletterManagerTarget, IPyAMSLayer, NewsletterManagerQuickSearchResultsTable),
                provides=IValues)
class NewsletterManagerQuickSearchResultsValues(SharedToolQuickSearchResultsValues):
    """Newsletter manager quick search results values adapter"""


@view_config(name='quick-newsletter-search.json',
             context=INewsletterManagerTarget, request_type=IPyAMSLayer,
             permission=VIEW_SYSTEM_PERMISSION, renderer='json', xhr=True)
def newsletter_manager_quick_search_view(request):
    """Newsletter manager quick search view"""
    results = NewsletterManagerQuickSearchResultsTable(request.context, request)
    return get_json_search_results(request, results)


@adapter_config(name='quick-search',
                required=(INewsletterManagerTarget, IAdminLayer, NewsletterManagerDashboardView),
                provides=IInnerTable)
class NewsletterManagerQuickSearchView(SharedToolQuickSearchView):
    """Newsletter manager quick search view"""

    @property
    def legend(self):
        """Legend getter"""
        translate = self.request.localizer.translate
        return translate(_("Between all contents of « {} » content type")) \
            .format(translate(NEWSLETTER_CONTENT_NAME))

    quick_search_url = 'quick-newsletter-search.json'
    advanced_search_url = '#advanced-newsletter-search.html'


@pagelet_config(name='quick-newsletter-search.html',
                context=INewsletterManagerTarget, layer=IPyAMSLayer,
                permission=VIEW_SYSTEM_PERMISSION)
class NewsletterManagerQuickSearchPageView(SharedToolQuickSearchPageView):
    """Newsletter manager quick search page view"""

    table_class = NewsletterManagerQuickSearchResultsTable


#
# Newsletter advanced search
#

@viewlet_config(name='advanced-newsletter-search.menu',
                context=INewsletterManagerTarget, layer=IAdminLayer,
                manager=IAllNewsletterDashboardMenu, weight=40,
                permission=VIEW_SYSTEM_PERMISSION)
class NewsletterManagerAdvancedSearchMenu(NewsletterManagerDashboardMenuMixin, SharedToolAdvancedSearchMenu):
    """Newsletter manager advanced search menu"""

    href = "#advanced-newsletter-search.html"


class NewsletterManagerAdvancedSearchForm(SharedToolAdvancedSearchForm):
    """Newsletter manager advanced search form"""

    ajax_form_handler = 'advanced-newsletter-search-results.html'


@adapter_config(required=(Interface, IAdminLayer, NewsletterManagerAdvancedSearchForm),
                provides=IFormFields)
def newsletter_manager_advanced_search_form_fields(context, request, form):
    """Newsletter manager advanced search form fields getter"""
    return Fields(ISharedToolAdvancedSearchQuery).omit('data_type', 'tags', 'themes', 'collections')


@pagelet_config(name='advanced-newsletter-search.html',
                context=INewsletterManagerTarget, layer=IPyAMSLayer,
                permission=VIEW_SYSTEM_PERMISSION)
class NewsletterManagerAdvancedSearchView(SharedToolAdvancedSearchView):
    """Newsletter manager advanced search view"""

    search_form = NewsletterManagerAdvancedSearchForm


class NewsletterManagerAdvancedSearchResultsTable(SharedToolAdvancedSearchResultsTable):
    """Newsletter manager advanced search results table"""


@adapter_config(required=(INewsletterManagerTarget, IPyAMSLayer, NewsletterManagerAdvancedSearchResultsTable),
                provides=IValues)
class NewsletterManagerAdvancedSearchResultsValues(NewsletterManagerDashboardValuesMixin,
                                                   SharedToolAdvancedSearchResultsValues):
    """Newsletter manager advanced search results values"""


@pagelet_config(name='advanced-newsletter-search-results.html',
                context=INewsletterManagerTarget, layer=IPyAMSLayer,
                permission=VIEW_SYSTEM_PERMISSION, xhr=True)
class NewsletterManagerAdvancedSEarchResultsView(SharedToolAdvancedSearchResultsView):
    """Newsletter manager advanced search results view"""

    table_class = NewsletterManagerAdvancedSearchResultsTable
