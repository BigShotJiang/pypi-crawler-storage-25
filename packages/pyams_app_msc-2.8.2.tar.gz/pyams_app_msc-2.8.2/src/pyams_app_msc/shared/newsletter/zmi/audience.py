# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE.
#

from hypatia.catalog import CatalogQuery
from hypatia.interfaces import ICatalog
from hypatia.query import And, Any, Contains, Eq, Ge, Le
from pyramid.httpexceptions import HTTPBadRequest
from pyramid.view import view_config
from zope.interface import Interface, alsoProvides, implementer
from zope.intid.interfaces import IIntIds
from zope.schema import Choice, List, TextLine

from pyams_app_msc.interfaces import MANAGE_NEWSLETTER_PERMISSION
from pyams_app_msc.shared.catalog.interfaces import CATALOG_ENTRY_CONTENT_TYPE
from pyams_app_msc.shared.newsletter.interfaces import INewsletterAudienceInfo, IWfNewsletter
from pyams_app_msc.shared.theater.interfaces import IMovieTheater
from pyams_app_msc.shared.theater.interfaces.audience import AUDIENCES_VOCABULARY
from pyams_app_msc.zmi import msc
from pyams_catalog.query import CatalogResultSet
from pyams_content.shared.common.zmi.dashboard import DashboardTable
from pyams_form.ajax import ajax_form_config
from pyams_form.button import Buttons
from pyams_form.field import Fields
from pyams_form.interfaces import HIDDEN_MODE
from pyams_form.interfaces.form import IInnerSubForm
from pyams_i18n.interfaces import INegotiator
from pyams_layer.interfaces import IPyAMSLayer
from pyams_layer.skin import apply_skin
from pyams_pagelet.pagelet import pagelet_config
from pyams_security.interfaces.base import VIEW_SYSTEM_PERMISSION
from pyams_security.schema import PrincipalField
from pyams_sequence.interfaces import ISequentialIdInfo, ISequentialIntIds
from pyams_sequence.reference import get_reference_target
from pyams_sequence.sequence import get_sequence_dict
from pyams_sequence.workflow import get_last_version
from pyams_skin.interfaces.viewlet import IFooterViewletManager, IHeaderViewletManager
from pyams_skin.schema.button import ActionButton
from pyams_table.column import CheckBoxColumn
from pyams_table.interfaces import IColumn, IValues
from pyams_utils.adapter import ContextRequestViewAdapter, adapter_config
from pyams_utils.fanstatic import get_resource_path
from pyams_utils.interfaces.data import IObjectData
from pyams_utils.list import unique_iter
from pyams_utils.registry import get_utility
from pyams_utils.rest import http_error
from pyams_utils.schema import DatetimesRangeField
from pyams_utils.traversing import get_parent
from pyams_utils.url import absolute_url
from pyams_viewlet.viewlet import EmptyViewlet, ViewContentProvider, viewlet_config
from pyams_zmi.form import AdminEditForm
from pyams_zmi.interfaces import IAdminLayer
from pyams_zmi.interfaces.form import ISearchButtons
from pyams_zmi.interfaces.viewlet import IPropertiesMenu
from pyams_zmi.search import SearchForm, SearchResultsView
from pyams_zmi.skin import AdminSkin
from pyams_zmi.zmi.viewlet.menu import NavigationMenuItem

__docformat__ = 'restructuredtext'

from pyams_app_msc import _


@viewlet_config(name='newsletter-audience.menu',
                context=IWfNewsletter, layer=IAdminLayer,
                manager=IPropertiesMenu, weight=20,
                permission=VIEW_SYSTEM_PERMISSION)
class NewsletterAudienceMenu(NavigationMenuItem):
    """Newsletter audience menu"""

    label = _("Selected activities")
    href = '#newsletter-audience.html'


@ajax_form_config(name='newsletter-audience.html',
                  context=IWfNewsletter, layer=IPyAMSLayer,
                  permission=VIEW_SYSTEM_PERMISSION)
class NewsletterAudienceForm(AdminEditForm):
    """Newsletter audience edit form"""

    title = _("Newsletter activities")
    legend = _("Newsletter selected activities")

    prefix = 'audience_form.'
    fields = Fields(INewsletterAudienceInfo)
    
    def update_widgets(self, prefix=None):
        super().update_widgets(prefix)
        activities = self.widgets.get('activities')
        if activities is not None:
            theater = get_parent(self.context, IMovieTheater)
            activities.ajax_url = absolute_url(theater, self.request, 'find-references.json')
        

class INewsletterAudienceSearchInfo(Interface):
    """Newsletter audience search info interface"""

    selection = TextLine(title=_("Selected items"),
                         required=False)
    
    query = TextLine(title=_("Search text"),
                     required=False)

    audiences = List(title=_("Audiences"),
                     value_type=Choice(vocabulary=AUDIENCES_VOCABULARY),
                     required=False)

    owner = PrincipalField(title=_("Owner"),
                           required=False)

    created = DatetimesRangeField(title=_('creation_date', default="Creation date"),
                                  required=False)

    published = DatetimesRangeField(title=_("published_date", default="Publication date"),
                                    required=False)

    modified = DatetimesRangeField(title=_('modification_date', default="Modification date"),
                                   required=False)


class INewsletterAudienceSearchButtons(ISearchButtons):
    """Newsletter audience search info buttons interface"""
    
    add_selection = ActionButton(name='add_selection',
                                 title=_("Add selection to newsletter"))


@viewlet_config(name='newsletter-activities.search-form',
                context=IWfNewsletter, layer=IAdminLayer, view=NewsletterAudienceForm,
                manager=IFooterViewletManager, weight=10,
                permission=MANAGE_NEWSLETTER_PERMISSION)
@implementer(IObjectData)
class NewsletterAudienceActivitiesSearchForm(SearchForm):
    """Newsletter audience activities search form"""

    title = _("Newsletter activities search")
    legend = _("Newsletter search criterias")
    hide_toolbar = True

    prefix = 'search_form.'
    fields = Fields(INewsletterAudienceSearchInfo)
    buttons = Buttons(INewsletterAudienceSearchButtons).select('add_selection', 'search', 'cancel')

    def __init__(self, context, request, view, manager=None):
        super().__init__(context, request)
        self.view = self.__parent__ = view
        self.manager = manager

    ajax_form_handler = 'newsletter-activities-search-results.html'

    @property
    def ajax_form_target(self):
        return f'#{self.id}_search_results'

    object_data = {
        'ams-container-source': 'search_form.widgets.selection-input',
        'ams-container-target': 'search_form.widgets.selection'
    }

    def update_widgets(self, prefix=None):
        super().update_widgets(prefix)
        selection = self.widgets.get('selection')
        if selection is not None:
            selection.mode = HIDDEN_MODE

    def update_actions(self):
        super().update_actions()
        search = self.actions.get('search')
        if search is not None:
            search.add_class('btn-secondary')
        add_selection = self.actions.get('add_selection')
        if add_selection is not None:
            add_selection.add_class('btn-info mr-auto')
            add_selection.object_data = {
                'ams-modules': {
                    'msc': {
                        'src': get_resource_path(msc)
                    }
                },
                'ams-click-handler': 'MyAMS.msc.newsletter.updateAudience',
                'ams-click-target': absolute_url(self.context, self.request, 'set-newsletter-activities.json')
            }
            alsoProvides(add_selection, IObjectData)


@adapter_config(name='newsletter-activities.search-results',
                required=(IWfNewsletter, IAdminLayer, NewsletterAudienceActivitiesSearchForm),
                provides=IInnerSubForm)
class NewsletterAudienceActivitiesSearchResults(ViewContentProvider):
    """Newsletter audience activities search results viewlet"""
    
    weight = 10

    def render(self):
        return f'<div id="{self.view.ajax_form_target[1:]}"></div>'


class NewsletterAudienceActivitiesSearchResultsTable(DashboardTable):
    """Newsletter audience activities search results table"""


@adapter_config(required=(IWfNewsletter, IAdminLayer, NewsletterAudienceActivitiesSearchResultsTable),
                provides=IValues)
class NewsletterAudienceActivitiesSearchResultsValues(ContextRequestViewAdapter):
    """Newsletter audience activities search results values getter"""
    
    def get_params(self, data):
        intids = get_utility(IIntIds)
        catalog = get_utility(ICatalog)
        theater = get_parent(self.context, IMovieTheater)
        params = And(Eq(catalog['parents'], intids.register(theater)),
                     Eq(catalog['content_type'], CATALOG_ENTRY_CONTENT_TYPE))
        query = data.get('query')
        if query:
            sequence = get_utility(ISequentialIntIds)
            if query.startswith('+'):
                params &= Eq(catalog['oid'], sequence.get_full_oid(query))
            else:
                query_params = Eq(catalog['oid'], sequence.get_full_oid(query))
                negotiator = get_utility(INegotiator)
                for lang in {self.request.registry.settings.get('pyramid.default_locale_name',
                                                                'en'),
                             self.request.locale_name,
                             negotiator.server_language} | negotiator.offered_languages:
                    index_name = 'title:{0}'.format(lang)
                    if index_name in catalog:
                        index = catalog[index_name]
                        if index.check_query(query):
                            query_params |= Contains(index,
                                                     ' and '.join((w+'*' for w in query.split())))
                params &= query_params
        if data.get('audiences'):
            params &= Any(catalog['catalog_audience'], data['audiences'])
        if data.get('owner'):
            params &= Eq(catalog['role:owner'], data['owner'])
        created_after, created_before = data.get('created', (None, None))
        if created_after:
            params &= Ge(catalog['created_date'], created_after)
        if created_before:
            params &= Le(catalog['created_date'], created_before)
        published_after, published_before = data.get('published', (None, None))
        if published_after:
            params &= Ge(catalog['effective_date'], published_after)
        if published_before:
            params &= Le(catalog['effective_date'], published_before)
        modified_after, modified_before = data.get('modified', (None, None))
        if modified_after:
            params &= Ge(catalog['modified_date'], modified_after)
        if modified_before:
            params &= Le(catalog['modified_date'], modified_before)
        return params

    @property
    def values(self):
        """Audience activities search results"""
        form = NewsletterAudienceActivitiesSearchForm(self.context, self.request, self)
        form.update()
        data, _errors = form.extract_data()
        params = self.get_params(data)
        catalog = get_utility(ICatalog)
        yield from unique_iter(map(get_last_version,
                                   CatalogResultSet(CatalogQuery(catalog).query(
                                           params, sort_index='modified_date', reverse=True))))


@adapter_config(name='checked',
                required=(IWfNewsletter, IAdminLayer, NewsletterAudienceActivitiesSearchResultsTable),
                provides=IColumn)
class NewsletterAudienceActivitiesSearchResultsCheckedColumn(CheckBoxColumn):
    """Shared tool owner change checked column"""

    weight = 1
    sortable = 'false'

    def get_item_key(self, item):
        return 'search_form.widgets.selection-input'

    def get_item_value(self, item):
        return ISequentialIdInfo(item).hex_oid

    def is_selected(self, item):
        return False

    def render_head_cell(self):
        return ('<input type="checkbox" '
                '       data-ams-change-handler="MyAMS.container.selectAllElements" />')

    def render_cell(self, item):
        return super().render_cell(item).replace(' />',
                                                 ' data-ams-click-handler="MyAMS.container.selectElement" '
                                                 ' data-ams-stop-propagation="true" />')


@pagelet_config(name='newsletter-activities-search-results.html',
                context=IWfNewsletter, layer=IPyAMSLayer,
                permission=MANAGE_NEWSLETTER_PERMISSION, xhr=True)
class NewsletterAudienceActivitiesSearchResultsView(SearchResultsView):
    """Newsletter audience activities search results view"""
    
    table_label = _("Search results")
    table_class = NewsletterAudienceActivitiesSearchResultsTable
    
    hide_toolbar = True


@viewlet_config(name='pyams.content_header',
                context=IWfNewsletter, layer=IAdminLayer, view=NewsletterAudienceActivitiesSearchResultsView,
                manager=IHeaderViewletManager, weight=10)
@viewlet_config(name='workflow-status',
                context=IWfNewsletter, layer=IAdminLayer, view=NewsletterAudienceActivitiesSearchResultsView,
                manager=IHeaderViewletManager, weight=20)
class NewsletterAudienceActivitiesSearchResultsViewContentHeaderViewlet(EmptyViewlet):
    """Shared content header viewlet on results view"""


@view_config(name='set-newsletter-activities.json',
             context=IWfNewsletter, request_type=IPyAMSLayer,
             renderer='json', xhr=True,
             permission=MANAGE_NEWSLETTER_PERMISSION)
def set_newsletter_activities(request):
    """Set newsletter activities"""
    selected = request.params.get('activities')
    if not selected:
        return http_error(request, HTTPBadRequest, "Missing arguments")
    apply_skin(request, AdminSkin)
    audience = INewsletterAudienceInfo(request.context)
    activities = audience.activities or []
    results = []
    for oid in selected.split(','):
        if oid not in activities:
            activity = get_reference_target(oid, request=request)
            if activity is not None:
                activities.append(oid)
                results.append(get_sequence_dict(activity, request=request))
    audience.activities = activities
    if results:
        status = 'success'
        message = _("New activities were correctly added to newsletter.")
    else:
        status = 'info'
        message = _("No data was changed")
    return {
        'status': status,
        'message': request.localizer.translate(message),
        'results': results
    }
