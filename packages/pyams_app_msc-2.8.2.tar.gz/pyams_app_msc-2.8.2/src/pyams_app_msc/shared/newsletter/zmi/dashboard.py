#
# Copyright (c) 2015-2023 Thierry Florac <tflorac AT ulthar.net>
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE.
#

"""PyAMS_*** module

"""

from zope.interface import Interface, alsoProvides, implementer

from pyams_app_msc.interfaces import VIEW_CATALOG_PERMISSION, VIEW_NEWSLETTER_PERMISSION
from pyams_app_msc.shared.newsletter.interfaces import NEWSLETTER_CONTENT_TYPE, INewsletterManagerTarget
from pyams_app_msc.shared.newsletter.zmi.interfaces import IAllNewsletterDashboardMenu, IMyNewsletterDashboardMenu, \
    INewsletterDashboardTable, INewsletterManagementMenu, INewsletterManagementView
from pyams_content.shared.common.zmi.dashboard import SharedToolAllInterventionsMenu, \
    SharedToolArchivedContentsMenu, SharedToolArchivedContentsTable, SharedToolArchivedContentsView, \
    SharedToolDashboardManagerWaitingTable, SharedToolDashboardManagerWaitingView, \
    SharedToolDashboardMenu, SharedToolDashboardOwnerModifiedTable, SharedToolDashboardOwnerModifiedView, \
    SharedToolDashboardOwnerWaitingTable, SharedToolDashboardOwnerWaitingView, SharedToolDashboardView, \
    SharedToolLastModificationsMenu, SharedToolLastModificationsTable, SharedToolLastModificationsView, \
    SharedToolLastPublicationsMenu, SharedToolLastPublicationsTable, SharedToolLastPublicationsView, \
    SharedToolMyDashboardMenu, SharedToolPreparationsMenu, SharedToolPreparationsTable, \
    SharedToolPreparationsView, SharedToolPublicationsMenu, SharedToolPublicationsTable, SharedToolPublicationsView, \
    SharedToolRetiredContentsMenu, SharedToolRetiredContentsTable, SharedToolRetiredContentsView, \
    SharedToolSubmissionsMenu, SharedToolSubmissionsTable, SharedToolSubmissionsView
from pyams_content.zmi.interfaces import IDashboardTableContentTypes
from pyams_content_es.zmi.dashboard import EsSharedToolArchivedContentsValues, EsSharedToolLastModificationsValues, \
    EsSharedToolLastPublicationsValues, EsSharedToolPreparationsValues, EsSharedToolPublicationsValues, \
    EsSharedToolRetiredContentsValues, EsSharedToolSubmissionsValues
from pyams_layer.interfaces import IPyAMSLayer
from pyams_pagelet.pagelet import pagelet_config
from pyams_security.interfaces.base import VIEW_SYSTEM_PERMISSION
from pyams_table.interfaces import IValues
from pyams_utils.adapter import adapter_config
from pyams_viewlet.manager import viewletmanager_config
from pyams_viewlet.viewlet import viewlet_config
from pyams_zmi.interfaces import IAdminLayer
from pyams_zmi.interfaces.table import IInnerTable
from pyams_zmi.interfaces.viewlet import IMenuHeader, INavigationViewletManager
from pyams_zmi.zmi.viewlet.menu import ContentManagementMenu, NavigationMenuItem

__docformat__ = 'restructuredtext'

from pyams_app_msc import _


#
# Newsletters dashboards mixins and helpers
#

class NewsletterManagerDashboardMenuMixin:
    """Newsletter manager dashboard menu mixin"""
    
    def __new__(cls, context, request, view, manager=None):
        return NavigationMenuItem.__new__(cls)


class NewsletterManagerDashboardValuesMixin:
    """Newsletter manager dashboard values mixin"""
    
    def get_content_types(self):
        return (NEWSLETTER_CONTENT_TYPE,)
    
    
@adapter_config(required=(INewsletterManagerTarget, INewsletterDashboardTable),
                provides=IDashboardTableContentTypes)
def newsletter_manager_dashboard_table_content_types(context, table):
    return (NEWSLETTER_CONTENT_TYPE,)


#
# Newsletters dashboards components
#

@viewletmanager_config(name='newsletter-manager.menu',
                       context=INewsletterManagerTarget, layer=IAdminLayer,
                       manager=INavigationViewletManager, weight=150,
                       provides=INewsletterManagementMenu)
class NewsletterManagementMenu(ContentManagementMenu):
    """Newsletter management menu"""

    _header = _("Newsletters management")
    

class NewsletterManagementDashboardViewMixin:
    """Newsletter management dashboard mixin view"""

    def get_table(self, container):
        table = super().get_table(container)
        alsoProvides(table, INewsletterManagementView)
        return table


@adapter_config(required=(INewsletterManagerTarget, IAdminLayer, Interface, INewsletterManagementMenu),
                provides=IMenuHeader)
def newsletter_manager_menu_header(context, request, view, menu):
    """Newsletter manager menu header"""
    return request.localizer.translate(_("Newsletters management"))


@viewlet_config(name='newsletters-dashboard.menu',
                context=INewsletterManagerTarget, layer=IAdminLayer,
                manager=INewsletterManagementMenu, weight=5,
                permission=VIEW_NEWSLETTER_PERMISSION)
class NewsletterManagerDashboardMenu(NewsletterManagerDashboardMenuMixin, SharedToolDashboardMenu):
    """Newsletter manager dashboard menu"""
    
    href = '#newsletters-dashboard.html'


@pagelet_config(name='newsletters-dashboard.html',
                context=INewsletterManagerTarget, layer=IPyAMSLayer,
                permission=VIEW_NEWSLETTER_PERMISSION)
@implementer(INewsletterManagementView)
class NewsletterManagerDashboardView(SharedToolDashboardView):
    """Newsletter manager dashboard view"""


#
# Newsletter manager waiting contents dashboard
#

@implementer(INewsletterDashboardTable)
class NewsletterManagerDashboardManagerWaitingTable(SharedToolDashboardManagerWaitingTable):
    """Newsletter manager dashboard manager waiting table"""
    
    
@adapter_config(name='manager-waiting',
                required=(INewsletterManagerTarget, IAdminLayer, NewsletterManagerDashboardView),
                provides=IInnerTable)
class NewsletterManagerDashboardManagerWaitingView(SharedToolDashboardManagerWaitingView):
    """Newsletter manager dashboard waiting view"""

    table_class = NewsletterManagerDashboardManagerWaitingTable


#
# Owner waiting contents dashboard
#

@implementer(INewsletterDashboardTable)
class NewsletterManagerDashboardOwnerWaitingTable(SharedToolDashboardOwnerWaitingTable):
    """Newsletter manager dashboard owner waiting table"""


@adapter_config(name='owner-waiting',
                required=(INewsletterManagerTarget, IAdminLayer, NewsletterManagerDashboardView),
                provides=IInnerTable)
class NewsletterManagerDashboardOwnerWaitingView(SharedToolDashboardOwnerWaitingView):
    """View of owned contents waiting for action"""

    table_class = NewsletterManagerDashboardOwnerWaitingTable


#
# Owner modified contents dashboard
#

@implementer(INewsletterDashboardTable)
class NewsletterManagerDashboardOwnerModifiedTable(SharedToolDashboardOwnerModifiedTable):
    """Newsletter manager dashboard owner modified table"""


@adapter_config(name='owner-modified',
                required=(INewsletterManagerTarget, IAdminLayer, NewsletterManagerDashboardView),
                provides=IInnerTable)
class NewsletterManagerDashboardOwnerModifiedView(SharedToolDashboardOwnerModifiedView):
    """View of owned modified contents"""
    
    table_class = NewsletterManagerDashboardOwnerModifiedTable


#
# My newsletter dashboards
#

@viewletmanager_config(name='my-newsletters.menu',
                       context=INewsletterManagerTarget, layer=IAdminLayer,
                       manager=INewsletterManagementMenu, weight=10,
                       permission=VIEW_SYSTEM_PERMISSION,
                       provides=IMyNewsletterDashboardMenu)
class NewsletterManagerMyDashboardMenu(NewsletterManagerDashboardMenuMixin, SharedToolMyDashboardMenu):
    """Newsletter manager 'my contents' dashboard menu"""

    
#
# My prepared newsletters dashboard
#

@viewlet_config(name='my-prepared-newsletters.menu',
                context=INewsletterManagerTarget, layer=IAdminLayer,
                manager=IMyNewsletterDashboardMenu, weight=5,
                permission=VIEW_SYSTEM_PERMISSION)
class NewsletterManagerPreparationsMenu(NewsletterManagerDashboardMenuMixin, SharedToolPreparationsMenu):
    """Newsletters preparations dashboard menu"""
    
    href = '#my-prepared-newsletters.html'


class NewsletterManagerPreparationsTable(SharedToolPreparationsTable):
    """Newsletter manager preparations table"""
    

@adapter_config(required=(INewsletterManagerTarget, IAdminLayer, NewsletterManagerPreparationsTable),
                provides=IValues)
class NewsletterManagerPreparationsValues(NewsletterManagerDashboardValuesMixin, EsSharedToolPreparationsValues):
    """Newsletter manager preparations values"""


@pagelet_config(name='my-prepared-newsletters.html',
                context=INewsletterManagerTarget, layer=IPyAMSLayer,
                permission=VIEW_CATALOG_PERMISSION)
class NewsletterManagerPreparationsView(NewsletterManagementDashboardViewMixin, SharedToolPreparationsView):
    """Newsletter manager preparations view"""
    
    table_class = NewsletterManagerPreparationsTable


#
# My submitted newsletters dashboard
#

@viewlet_config(name='my-submitted-newsletters.menu',
                context=INewsletterManagerTarget, layer=IAdminLayer,
                manager=IMyNewsletterDashboardMenu, weight=10,
                permission=VIEW_SYSTEM_PERMISSION)
class NewsletterManagerSubmissionsMenu(NewsletterManagerDashboardMenuMixin, SharedToolSubmissionsMenu):
    """Newsletters submissions dashboard menu"""
    
    href = '#my-submitted-newsletters.html'


class NewsletterManagerSubmissionsTable(SharedToolSubmissionsTable):
    """Newsletter manager submissions table"""


@adapter_config(required=(INewsletterManagerTarget, IAdminLayer, NewsletterManagerSubmissionsTable),
                provides=IValues)
class NewsletterManagerSubmissionsValues(NewsletterManagerDashboardValuesMixin, EsSharedToolSubmissionsValues):
    """Newsletter manager submissions values"""


@pagelet_config(name='my-submitted-newsletters.html',
                context=INewsletterManagerTarget, layer=IPyAMSLayer,
                permission=VIEW_SYSTEM_PERMISSION)
class NewsletterManagerSubmissionsView(NewsletterManagementDashboardViewMixin, SharedToolSubmissionsView):
    """Newsletter manager submissions view"""

    table_class = NewsletterManagerSubmissionsTable


#
# My published newsletters dashboard
#

@viewlet_config(name='my-published-newsletters.menu',
                context=INewsletterManagerTarget, layer=IAdminLayer,
                manager=IMyNewsletterDashboardMenu, weight=15,
                permission=VIEW_SYSTEM_PERMISSION)
class NewsletterManagerPublicationsMenu(NewsletterManagerDashboardMenuMixin, SharedToolPublicationsMenu):
    """Newsletters publications dashboard menu"""
    
    href = '#my-published-newsletters.html'


class NewsletterManagerPublicationsTable(SharedToolPublicationsTable):
    """Newsletter manager publications table"""


@adapter_config(required=(INewsletterManagerTarget, IAdminLayer, NewsletterManagerPublicationsTable),
                provides=IValues)
class NewsletterManagerPublicationsValues(NewsletterManagerDashboardValuesMixin, EsSharedToolPublicationsValues):
    """Newsletter manager publications values"""


@pagelet_config(name='my-published-newsletters.html',
                context=INewsletterManagerTarget, layer=IPyAMSLayer,
                permission=VIEW_SYSTEM_PERMISSION)
class NewsletterManagerPublicationsView(NewsletterManagementDashboardViewMixin, SharedToolPublicationsView):
    """Newsletter manager publications view"""
    
    table_class = NewsletterManagerPublicationsTable


#
# My retired newsletters dashboard
#

@viewlet_config(name='my-retired-newsletters.menu',
                context=INewsletterManagerTarget, layer=IAdminLayer,
                manager=IMyNewsletterDashboardMenu, weight=20,
                permission=VIEW_SYSTEM_PERMISSION)
class NewsletterManagerRetiredContentsMenu(NewsletterManagerDashboardMenuMixin, SharedToolRetiredContentsMenu):
    """Retired newsletters dashboard menu"""
    
    href = '#my-retired-newsletters.html'


class NewsletterManagerRetiredContentsTable(SharedToolRetiredContentsTable):
    """Retired newsletters manager table"""


@adapter_config(required=(INewsletterManagerTarget, IAdminLayer, NewsletterManagerRetiredContentsTable),
                provides=IValues)
class NewsletterManagerRetiredContentsValues(NewsletterManagerDashboardValuesMixin, EsSharedToolRetiredContentsValues):
    """Retired newsletters manager values"""


@pagelet_config(name='my-retired-newsletters.html',
                context=INewsletterManagerTarget, layer=IPyAMSLayer,
                permission=VIEW_SYSTEM_PERMISSION)
class NewsletterManagerRetiredContentsView(NewsletterManagementDashboardViewMixin, SharedToolRetiredContentsView):
    """Newsletters manager retired contents view"""

    table_class = NewsletterManagerRetiredContentsTable


#
# My archived newsletters dashboard
#

@viewlet_config(name='my-archived-newsletters.menu',
                context=INewsletterManagerTarget, layer=IAdminLayer,
                manager=IMyNewsletterDashboardMenu, weight=25,
                permission=VIEW_SYSTEM_PERMISSION)
class NewsletterManagerArchivedContentsMenu(NewsletterManagerDashboardMenuMixin, SharedToolArchivedContentsMenu):
    """Archived newsletters dashboard menu"""
    
    href = '#my-archived-newsletters.html'


class NewsletterManagerArchivedContentsTable(SharedToolArchivedContentsTable):
    """Archived newsletter manager table"""


@adapter_config(required=(INewsletterManagerTarget, IAdminLayer, NewsletterManagerArchivedContentsTable),
                provides=IValues)
class NewsletterManagerArchivedContentsValues(NewsletterManagerDashboardValuesMixin, EsSharedToolArchivedContentsValues):
    """Archived newsletter manager values"""


@pagelet_config(name='my-archived-newsletters.html',
                context=INewsletterManagerTarget, layer=IPyAMSLayer,
                permission=VIEW_SYSTEM_PERMISSION)
class NewsletterManagerArchivedContentsView(NewsletterManagementDashboardViewMixin, SharedToolArchivedContentsView):
    """Newsletter manager archived contents view"""
    
    table_class = NewsletterManagerArchivedContentsTable


#
# Newsletters interventions dashboard menu
#

@viewletmanager_config(name='all-newsletters-interventions.menu',
                       context=INewsletterManagerTarget, layer=IAdminLayer,
                       manager=INewsletterManagementMenu, weight=20,
                       permission=VIEW_SYSTEM_PERMISSION,
                       provides=IAllNewsletterDashboardMenu)
class NewsletterManagerAllInterventionsMenu(NewsletterManagerDashboardMenuMixin, SharedToolAllInterventionsMenu):
    """Newsletter manager 'all interventions' dashboard menu"""

    css_class = ''


#
# Last published newsletters dashboard
#

@viewlet_config(name='last-published-newsletters.menu',
                context=INewsletterManagerTarget, layer=IAdminLayer,
                manager=IAllNewsletterDashboardMenu, weight=25,
                permission=VIEW_SYSTEM_PERMISSION)
class NewsletterManagerLastPublicationsMenu(NewsletterManagerDashboardMenuMixin, SharedToolLastPublicationsMenu):
    """Last published newsletters dashboard menu"""
    
    href = '#last-published-newsletters.html'


class NewsletterManagerLastPublicationsTable(SharedToolLastPublicationsTable):
    """Last published newsletter manager table"""


@adapter_config(required=(INewsletterManagerTarget, IAdminLayer, NewsletterManagerLastPublicationsTable),
                provides=IValues)
class NewsletterManagerLastPublicationsValues(NewsletterManagerDashboardValuesMixin, EsSharedToolLastPublicationsValues):
    """Last published newsletter manager values"""


@pagelet_config(name='last-published-newsletters.html',
                context=INewsletterManagerTarget, layer=IPyAMSLayer,
                permission=VIEW_SYSTEM_PERMISSION)
class NewsletterManagerLastPublicationsView(NewsletterManagementDashboardViewMixin, SharedToolLastPublicationsView):
    """Last published newsletters manager view"""
    
    table_class = NewsletterManagerLastPublicationsTable


#
# Last modified newsletters dashboard
#

@viewlet_config(name='last-modified-newsletters.menu',
                context=INewsletterManagerTarget, layer=IAdminLayer,
                manager=IAllNewsletterDashboardMenu, weight=25,
                permission=VIEW_SYSTEM_PERMISSION)
class NewsletterManagerLastModificationsMenu(NewsletterManagerDashboardMenuMixin, SharedToolLastModificationsMenu):
    """Last modified newsletters dashboard menu"""
    
    href = '#last-modified-newsletters.html'


class NewsletterManagerLastModificationsTable(SharedToolLastModificationsTable):
    """Archived newsletter manager table"""


@adapter_config(required=(INewsletterManagerTarget, IAdminLayer, NewsletterManagerLastModificationsTable),
                provides=IValues)
class NewsletterManagerLastModificationsValues(NewsletterManagerDashboardValuesMixin, EsSharedToolLastModificationsValues):
    """Archived newsletter manager values"""


@pagelet_config(name='last-modified-newsletters.html',
                context=INewsletterManagerTarget, layer=IPyAMSLayer,
                permission=VIEW_SYSTEM_PERMISSION)
class NewsletterManagerLastModificationsView(NewsletterManagementDashboardViewMixin, SharedToolLastModificationsView):
    """Newsletter manager last modifications view"""

    table_class = NewsletterManagerLastModificationsTable
