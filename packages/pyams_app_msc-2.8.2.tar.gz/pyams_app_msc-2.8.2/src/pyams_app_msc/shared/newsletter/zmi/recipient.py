# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE.
#

from pyams_app_msc.feature.profile.zmi.widget import PrincipalsSetSelectFieldWidget
from pyams_app_msc.shared.newsletter.interfaces import INewsletterRecipientsInfo, IWfNewsletter
from pyams_app_msc.shared.theater import IMovieTheater
from pyams_app_msc.shared.theater.api.interfaces import MSC_THEATER_PRINCIPALS_API_SEARCH_PATH, \
    MSC_THEATER_PRINCIPALS_API_SEARCH_ROUTE
from pyams_form.ajax import ajax_form_config
from pyams_form.field import Fields
from pyams_layer.interfaces import IPyAMSLayer
from pyams_security.interfaces.base import VIEW_SYSTEM_PERMISSION
from pyams_utils.traversing import get_parent
from pyams_viewlet.viewlet import viewlet_config
from pyams_zmi.form import AdminEditForm
from pyams_zmi.interfaces import IAdminLayer
from pyams_zmi.interfaces.viewlet import IPropertiesMenu
from pyams_zmi.zmi.viewlet.menu import NavigationMenuItem

__docformat__ = 'restructuredtext'

from pyams_app_msc import _


@viewlet_config(name='newsletter-recipients.menu',
                context=IWfNewsletter, layer=IAdminLayer,
                manager=IPropertiesMenu, weight=25,
                permission=VIEW_SYSTEM_PERMISSION)
class NewsletterRecipientsMenu(NavigationMenuItem):
    """Newsletter recipients menu item"""

    label = _('newsletter-recipients-menu', default="Recipients")
    href = '#newsletter-recipients.html'


@ajax_form_config(name='newsletter-recipients.html',
                  context=IWfNewsletter, layer=IPyAMSLayer,
                  permission=VIEW_SYSTEM_PERMISSION)
class NewsletterRecipientsForm(AdminEditForm):
    """Newsletter recipients form"""

    title = _("Newsletter recipients")
    legend = _("Newsletter selected recipients")

    prefix = 'recipients-form.'
    fields = Fields(INewsletterRecipientsInfo).omit('sent_to')
    fields['recipients'].widget_factory = PrincipalsSetSelectFieldWidget

    def update_widgets(self, prefix=None):
        super().update_widgets(prefix)
        recipients = self.widgets.get('recipients')
        if recipients is not None:
            theater = get_parent(self.context, IMovieTheater)
            path = self.request.registry.settings.get(f'{MSC_THEATER_PRINCIPALS_API_SEARCH_ROUTE}_route.path',
                                                      MSC_THEATER_PRINCIPALS_API_SEARCH_PATH).replace('{theater_name}',
                                                                                                      theater.__name__)
            recipients.ajax_url = path
