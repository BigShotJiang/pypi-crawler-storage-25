# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE.
#

import sys

from cornice import Service
from cornice.validators import colander_validator
from pyramid.httpexceptions import HTTPBadRequest

from pyams_app_msc.feature.profile.interfaces import IUserProfile
from pyams_app_msc.shared.theater.interfaces import IMovieTheater
from pyams_app_msc.shared.theater.api.interfaces import MSC_THEATER_PRINCIPALS_API_SEARCH_ROUTE
from pyams_security.interfaces import ISecurityManager
from pyams_security.interfaces.base import USE_INTERNAL_API_PERMISSION
from pyams_security.rest import check_cors_origin, set_cors_headers
from pyams_security_views.api.principal import PrincipalsSearchRequest, principals_get_responses
from pyams_utils.registry import get_utility, query_utility
from pyams_utils.rest import STATUS, http_error

__docformat__ = 'restructuredtext'


TEST_MODE = sys.argv[-1].endswith('/test')


principals_service = Service(name=MSC_THEATER_PRINCIPALS_API_SEARCH_ROUTE,
                             pyramid_route=MSC_THEATER_PRINCIPALS_API_SEARCH_ROUTE,
                             description="Principals management")


@principals_service.options(validators=(check_cors_origin, set_cors_headers))
def principals_options(request):
    """Principals service options"""
    return ''


@principals_service.get(permission=USE_INTERNAL_API_PERMISSION,
                        schema=PrincipalsSearchRequest(),
                        validators=(check_cors_origin, colander_validator, set_cors_headers),
                        response_schemas=principals_get_responses)
def get_principals(request):
    """Return list of principals matching given query"""

    def check_profile(principal):
        """Check user profile attached theaters"""
        profile = IUserProfile(principal, None)
        if profile is None:
            return False
        return (not profile.local_theaters) or (theater_name in profile.local_theaters)

    theater_name = request.matchdict.get('theater_name')
    if theater_name is None:
        return http_error(request, HTTPBadRequest, "Missing path argument")
    theater = get_utility(IMovieTheater, name=theater_name)
    if theater is None:
        return http_error(request, HTTPBadRequest, "Bad theater name")
    params = request.params if TEST_MODE else request.validated.get('querystring', {})
    query = params.get('term')
    if not query:
        return http_error(request, HTTPBadRequest, "Missing query argument")
    manager = query_utility(ISecurityManager)
    return {
        'status': STATUS.SUCCESS.value,
        'results': [{
            'id': principal.id,
            'text': principal.title
        } for principal in filter(check_profile, manager.find_principals(query))]
    }
