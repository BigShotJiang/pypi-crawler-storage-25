#
# Copyright (c) 2015-2023 Thierry Florac <tflorac AT ulthar.net>
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE.
#

"""PyAMS_*** module

"""

from zope.interface import Interface, alsoProvides, implementer

from pyams_app_msc.interfaces import VIEW_CATALOG_PERMISSION
from pyams_app_msc.shared.catalog.interfaces import CATALOG_ENTRY_CONTENT_TYPE, ICatalogManagerTarget
from pyams_app_msc.shared.catalog.zmi.interfaces import IAllCatalogDashboardMenu, ICatalogDashboardTable, \
    ICatalogManagementMenu, ICatalogManagementView, IMyCatalogDashboardMenu
from pyams_content.shared.common.zmi.dashboard import SharedToolAllInterventionsMenu, \
    SharedToolArchivedContentsMenu, SharedToolArchivedContentsTable, SharedToolArchivedContentsView, \
    SharedToolDashboardManagerWaitingTable, SharedToolDashboardManagerWaitingView, SharedToolDashboardMenu, \
    SharedToolDashboardOwnerModifiedTable, SharedToolDashboardOwnerModifiedView, SharedToolDashboardOwnerWaitingTable, \
    SharedToolDashboardOwnerWaitingView, SharedToolDashboardView, SharedToolLastModificationsMenu, \
    SharedToolLastModificationsTable, SharedToolLastModificationsView, SharedToolLastPublicationsMenu, \
    SharedToolLastPublicationsTable, SharedToolLastPublicationsView, SharedToolMyDashboardMenu, \
    SharedToolPreparationsMenu, SharedToolPreparationsTable, SharedToolPreparationsView, \
    SharedToolPublicationsMenu, SharedToolPublicationsTable, SharedToolPublicationsView, \
    SharedToolRetiredContentsMenu, SharedToolRetiredContentsTable, SharedToolRetiredContentsView, \
    SharedToolSubmissionsMenu, SharedToolSubmissionsTable, SharedToolSubmissionsView
from pyams_content.zmi.interfaces import IDashboardTableContentTypes
from pyams_content_es.zmi.dashboard import EsSharedToolArchivedContentsValues, EsSharedToolLastModificationsValues, \
    EsSharedToolLastPublicationsValues, EsSharedToolPreparationsValues, EsSharedToolPublicationsValues, \
    EsSharedToolRetiredContentsValues, EsSharedToolSubmissionsValues
from pyams_layer.interfaces import IPyAMSLayer
from pyams_pagelet.pagelet import pagelet_config
from pyams_security.interfaces.base import VIEW_SYSTEM_PERMISSION
from pyams_table.interfaces import IValues
from pyams_utils.adapter import adapter_config
from pyams_viewlet.manager import viewletmanager_config
from pyams_viewlet.viewlet import viewlet_config
from pyams_zmi.interfaces import IAdminLayer
from pyams_zmi.interfaces.table import IInnerTable
from pyams_zmi.interfaces.viewlet import IMenuHeader, INavigationViewletManager
from pyams_zmi.zmi.viewlet.menu import ContentManagementMenu, NavigationMenuItem

__docformat__ = 'restructuredtext'

from pyams_app_msc import _


#
# Activities catalog dashboards mixins and helpers
#

class CatalogManagerDashboardMenuMixin:
    """Catalog manager dashboard menu mixin"""
    
    def __new__(cls, context, request, view, manager=None):
        return NavigationMenuItem.__new__(cls)


class CatalogManagerDashboardValuesMixin:
    """Catalog manager dashboard values mixin"""
    
    def get_content_types(self):
        return (CATALOG_ENTRY_CONTENT_TYPE,)


@adapter_config(required=(ICatalogManagerTarget, ICatalogDashboardTable),
                provides=IDashboardTableContentTypes)
def catalog_manager_dashboard_table_content_types(context, table):
    return (CATALOG_ENTRY_CONTENT_TYPE,)


#
# Activities catalog dashboard
#

@viewletmanager_config(name='catalog-manager.menu',
                       context=ICatalogManagerTarget, layer=IAdminLayer,
                       manager=INavigationViewletManager, weight=100,
                       provides=ICatalogManagementMenu)
class CatalogManagementMenu(ContentManagementMenu):
    """Catalog management menu"""

    _header = _("Activities catalog")


class CatalogManagementDashboardViewMixin:
    """Catalog management dashboard mixin view"""

    def get_table(self, container):
        table = super().get_table(container)
        alsoProvides(table, ICatalogManagementView)
        return table


@adapter_config(required=(ICatalogManagerTarget, IAdminLayer, Interface, ICatalogManagementMenu),
                provides=IMenuHeader)
def catalog_manager_menu_header(context, request, view, menu):
    """Catalog manager menu header"""
    return request.localizer.translate(_("Activities catalog"))


@viewlet_config(name='catalog-dashboard.menu',
                context=ICatalogManagerTarget, layer=IAdminLayer,
                manager=ICatalogManagementMenu, weight=5,
                permission=VIEW_CATALOG_PERMISSION)
class CatalogManagerDashboardMenu(CatalogManagerDashboardMenuMixin, SharedToolDashboardMenu):
    """Catalog manager dashboard menu"""
    
    href = '#catalog-dashboard.html'
    

@pagelet_config(name='catalog-dashboard.html',
                context=ICatalogManagerTarget, layer=IPyAMSLayer,
                permission=VIEW_CATALOG_PERMISSION)
@implementer(ICatalogManagementView)
class CatalogManagerDashboardView(SharedToolDashboardView):
    """Catalog manager dashboard view"""


#
# Catalog manager waiting contents dashboard
#

@implementer(ICatalogDashboardTable)
class CatalogManagerDashboardManagerWaitingTable(SharedToolDashboardManagerWaitingTable):
    """Catalog manager dashboard manager waiting table"""


@adapter_config(name='manager-waiting',
                required=(ICatalogManagerTarget, IAdminLayer, CatalogManagerDashboardView),
                provides=IInnerTable)
class CatalogManagerDashboardManagerWaitingView(SharedToolDashboardManagerWaitingView):
    """Catalog manager dashboard waiting view"""
    
    table_class = CatalogManagerDashboardManagerWaitingTable


#
# Owner waiting contents dashboard
#

@implementer(ICatalogDashboardTable)
class CatalogManagerDashboardOwnerWaitingTable(SharedToolDashboardOwnerWaitingTable):
    """Catalog manager dashboard owner waiting table"""


@adapter_config(name='owner-waiting',
                required=(ICatalogManagerTarget, IAdminLayer, CatalogManagerDashboardView),
                provides=IInnerTable)
class CatalogManagerDashboardOwnerWaitingView(SharedToolDashboardOwnerWaitingView):
    """View of owned contents waiting for action"""

    table_class = CatalogManagerDashboardOwnerWaitingTable


#
# Owner modified contents dashboard
#

@implementer(ICatalogDashboardTable)
class CatalogManagerDashboardOwnerModifiedTable(SharedToolDashboardOwnerModifiedTable):
    """Catalog manager dashboard owner modified table"""


@adapter_config(name='owner-modified',
                required=(ICatalogManagerTarget, IAdminLayer, CatalogManagerDashboardView),
                provides=IInnerTable)
class CatalogManagerDashboardOwnerModifiedView(SharedToolDashboardOwnerModifiedView):
    """View of owned modified contents"""
    
    table_class = CatalogManagerDashboardOwnerModifiedTable


#
# My catalog dashboards
#

@viewletmanager_config(name='my-catalog.menu',
                       context=ICatalogManagerTarget, layer=IAdminLayer,
                       manager=ICatalogManagementMenu, weight=10,
                       permission=VIEW_SYSTEM_PERMISSION,
                       provides=IMyCatalogDashboardMenu)
class CatalogManagerMyDashboardMenu(CatalogManagerDashboardMenuMixin, SharedToolMyDashboardMenu):
    """Catalog manager 'my contents' dashboard menu"""


#
# My prepared catalog dashboard
#

@viewlet_config(name='my-prepared-catalog.menu',
                context=ICatalogManagerTarget, layer=IAdminLayer,
                manager=IMyCatalogDashboardMenu, weight=5,
                permission=VIEW_SYSTEM_PERMISSION)
class CatalogManagerPreparationsMenu(CatalogManagerDashboardMenuMixin, SharedToolPreparationsMenu):
    """Catalogs preparations dashboard menu"""
    
    href = '#my-prepared-catalog.html'


class CatalogManagerPreparationsTable(SharedToolPreparationsTable):
    """Catalog manager preparations table"""


@adapter_config(required=(ICatalogManagerTarget, IAdminLayer, CatalogManagerPreparationsTable),
                provides=IValues)
class CatalogManagerPreparationsValues(CatalogManagerDashboardValuesMixin, EsSharedToolPreparationsValues):
    """Catalog manager preparations values"""


@pagelet_config(name='my-prepared-catalog.html',
                context=ICatalogManagerTarget, layer=IPyAMSLayer,
                permission=VIEW_CATALOG_PERMISSION)
class CatalogManagerPreparationsView(CatalogManagementDashboardViewMixin, SharedToolPreparationsView):
    """Catalog manager preparations view"""
    
    table_class = CatalogManagerPreparationsTable


#
# My submitted catalog dashboard
#

@viewlet_config(name='my-submitted-catalog.menu',
                context=ICatalogManagerTarget, layer=IAdminLayer,
                manager=IMyCatalogDashboardMenu, weight=10,
                permission=VIEW_SYSTEM_PERMISSION)
class CatalogManagerSubmissionsMenu(CatalogManagerDashboardMenuMixin, SharedToolSubmissionsMenu):
    """Catalog submissions dashboard menu"""
    
    href = '#my-submitted-catalog.html'


class CatalogManagerSubmissionsTable(SharedToolSubmissionsTable):
    """Catalog manager submissions table"""


@adapter_config(required=(ICatalogManagerTarget, IAdminLayer, CatalogManagerSubmissionsTable),
                provides=IValues)
class CatalogManagerSubmissionsValues(CatalogManagerDashboardValuesMixin, EsSharedToolSubmissionsValues):
    """Catalog manager submissions values"""


@pagelet_config(name='my-submitted-catalog.html',
                context=ICatalogManagerTarget, layer=IPyAMSLayer,
                permission=VIEW_SYSTEM_PERMISSION)
class CatalogManagerSubmissionsView(CatalogManagementDashboardViewMixin, SharedToolSubmissionsView):
    """Catalog manager submissions view"""
    
    table_class = CatalogManagerSubmissionsTable


#
# My published catalog dashboard
#

@viewlet_config(name='my-published-catalog.menu',
                context=ICatalogManagerTarget, layer=IAdminLayer,
                manager=IMyCatalogDashboardMenu, weight=15,
                permission=VIEW_SYSTEM_PERMISSION)
class CatalogManagerPublicationsMenu(CatalogManagerDashboardMenuMixin, SharedToolPublicationsMenu):
    """Catalog manager publications dashboard menu"""
    
    href = '#my-published-catalog.html'


class CatalogManagerPublicationsTable(SharedToolPublicationsTable):
    """Catalog manager publications table"""


@adapter_config(required=(ICatalogManagerTarget, IAdminLayer, CatalogManagerPublicationsTable),
                provides=IValues)
class CatalogManagerPublicationsValues(CatalogManagerDashboardValuesMixin, EsSharedToolPublicationsValues):
    """Catalog manager publications values"""


@pagelet_config(name='my-published-catalog.html',
                context=ICatalogManagerTarget, layer=IPyAMSLayer,
                permission=VIEW_SYSTEM_PERMISSION)
class CatalogManagerPublicationsView(CatalogManagementDashboardViewMixin, SharedToolPublicationsView):
    """Catalog manager publications view"""
    
    table_class = CatalogManagerPublicationsTable


#
# My retired newsletters dashboard
#

@viewlet_config(name='my-retired-catalog.menu',
                context=ICatalogManagerTarget, layer=IAdminLayer,
                manager=IMyCatalogDashboardMenu, weight=20,
                permission=VIEW_SYSTEM_PERMISSION)
class CatalogManagerRetiredContentsMenu(CatalogManagerDashboardMenuMixin, SharedToolRetiredContentsMenu):
    """Retired catalog dashboard menu"""
    
    href = '#my-retired-catalog.html'


class CatalogManagerRetiredContentsTable(SharedToolRetiredContentsTable):
    """Retired catalog manager table"""


@adapter_config(required=(ICatalogManagerTarget, IAdminLayer, CatalogManagerRetiredContentsTable),
                provides=IValues)
class CatalogManagerRetiredContentsValues(CatalogManagerDashboardValuesMixin, EsSharedToolRetiredContentsValues):
    """Retired catalog manager values"""


@pagelet_config(name='my-retired-catalog.html',
                context=ICatalogManagerTarget, layer=IPyAMSLayer,
                permission=VIEW_SYSTEM_PERMISSION)
class CatalogManagerRetiredContentsView(CatalogManagementDashboardViewMixin, SharedToolRetiredContentsView):
    """Catalogs manager retired contents view"""
    
    table_class = CatalogManagerRetiredContentsTable


#
# My archived newsletters dashboard
#

@viewlet_config(name='my-archived-catalog.menu',
                context=ICatalogManagerTarget, layer=IAdminLayer,
                manager=IMyCatalogDashboardMenu, weight=25,
                permission=VIEW_SYSTEM_PERMISSION)
class CatalogManagerArchivedContentsMenu(CatalogManagerDashboardMenuMixin, SharedToolArchivedContentsMenu):
    """Archived catalog dashboard menu"""
    
    href = '#my-archived-catalog.html'


class CatalogManagerArchivedContentsTable(SharedToolArchivedContentsTable):
    """Archived catalog manager table"""


@adapter_config(required=(ICatalogManagerTarget, IAdminLayer, CatalogManagerArchivedContentsTable),
                provides=IValues)
class CatalogManagerArchivedContentsValues(CatalogManagerDashboardValuesMixin, EsSharedToolArchivedContentsValues):
    """Catalog manager archived values"""


@pagelet_config(name='my-archived-catalog.html',
                context=ICatalogManagerTarget, layer=IPyAMSLayer,
                permission=VIEW_SYSTEM_PERMISSION)
class CatalogManagerArchivedContentsView(CatalogManagementDashboardViewMixin, SharedToolArchivedContentsView):
    """Catalog manager archived contents view"""
    
    table_class = CatalogManagerArchivedContentsTable


#
# Catalog manager interventions dashboard menu
#

@viewletmanager_config(name='all-catalog-interventions.menu',
                       context=ICatalogManagerTarget, layer=IAdminLayer,
                       manager=ICatalogManagementMenu, weight=20,
                       permission=VIEW_SYSTEM_PERMISSION,
                       provides=IAllCatalogDashboardMenu)
class CatalogManagerAllInterventionsMenu(CatalogManagerDashboardMenuMixin, SharedToolAllInterventionsMenu):
    """Catalog manager 'all interventions' dashboard menu"""

    css_class = ''


#
# Last published newsletters dashboard
#

@viewlet_config(name='last-published-catalog.menu',
                context=ICatalogManagerTarget, layer=IAdminLayer,
                manager=IAllCatalogDashboardMenu, weight=25,
                permission=VIEW_SYSTEM_PERMISSION)
class CatalogManagerLastPublicationsMenu(CatalogManagerDashboardMenuMixin, SharedToolLastPublicationsMenu):
    """Last published catalog dashboard menu"""
    
    href = '#last-published-catalog.html'


class CatalogManagerLastPublicationsTable(SharedToolLastPublicationsTable):
    """Last published catalog manager table"""


@adapter_config(required=(ICatalogManagerTarget, IAdminLayer, CatalogManagerLastPublicationsTable),
                provides=IValues)
class CatalogManagerLastPublicationsValues(CatalogManagerDashboardValuesMixin, EsSharedToolLastPublicationsValues):
    """Last published catalog manager values"""


@pagelet_config(name='last-published-catalog.html',
                context=ICatalogManagerTarget, layer=IPyAMSLayer,
                permission=VIEW_SYSTEM_PERMISSION)
class CatalogManagerLastPublicationsView(CatalogManagementDashboardViewMixin, SharedToolLastPublicationsView):
    """Last published catalog manager view"""
    
    table_class = CatalogManagerLastPublicationsTable


#
# Last modified catalog dashboard
#

@viewlet_config(name='last-modified-catalog.menu',
                context=ICatalogManagerTarget, layer=IAdminLayer,
                manager=IAllCatalogDashboardMenu, weight=25,
                permission=VIEW_SYSTEM_PERMISSION)
class CatalogManagerLastModificationsMenu(CatalogManagerDashboardMenuMixin, SharedToolLastModificationsMenu):
    """Last modified catalog dashboard menu"""
    
    href = '#last-modified-catalog.html'


class CatalogManagerLastModificationsTable(SharedToolLastModificationsTable):
    """Archived catalog manager table"""


@adapter_config(required=(ICatalogManagerTarget, IAdminLayer, CatalogManagerLastModificationsTable),
                provides=IValues)
class CatalogManagerLastModificationsValues(CatalogManagerDashboardValuesMixin, EsSharedToolLastModificationsValues):
    """Archived catalog manager values"""


@pagelet_config(name='last-modified-catalog.html',
                context=ICatalogManagerTarget, layer=IPyAMSLayer,
                permission=VIEW_SYSTEM_PERMISSION)
class CatalogManagerLastModificationsView(CatalogManagementDashboardViewMixin, SharedToolLastModificationsView):
    """Catalog manager last modifications view"""
    
    table_class = CatalogManagerLastModificationsTable
