# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE.
#

from pyramid.view import view_config
from zope.interface import implementer

from pyams_app_msc.shared.catalog.interfaces import CATALOG_ENTRY_CONTENT_NAME, ICatalogManagerTarget
from pyams_app_msc.shared.catalog.zmi.dashboard import CatalogManagerDashboardMenuMixin, \
    CatalogManagerDashboardValuesMixin, CatalogManagerDashboardView
from pyams_app_msc.shared.catalog.zmi.interfaces import IAllCatalogDashboardMenu, ICatalogDashboardTable
from pyams_content.shared.common.zmi.search import SharedToolAdvancedSearchForm, SharedToolAdvancedSearchMenu, \
    SharedToolAdvancedSearchResultsTable, SharedToolAdvancedSearchResultsValues, \
    SharedToolAdvancedSearchResultsView, SharedToolAdvancedSearchView, SharedToolQuickSearchPageView, \
    SharedToolQuickSearchResultsTable, SharedToolQuickSearchResultsValues, SharedToolQuickSearchView, \
    get_json_search_results
from pyams_layer.interfaces import IPyAMSLayer
from pyams_pagelet.pagelet import pagelet_config
from pyams_security.interfaces.base import VIEW_SYSTEM_PERMISSION
from pyams_table.interfaces import IValues
from pyams_utils.adapter import adapter_config
from pyams_viewlet.viewlet import viewlet_config
from pyams_zmi.interfaces import IAdminLayer
from pyams_zmi.interfaces.table import IInnerTable

__docformat__ = 'restructuredtext'

from pyams_app_msc import _


#
# Catalogs quick search
#

@implementer(ICatalogDashboardTable)
class CatalogManagerQuickSearchResultsTable(SharedToolQuickSearchResultsTable):
    """Catalog manager quick search results table"""


@adapter_config(required=(ICatalogManagerTarget, IPyAMSLayer, CatalogManagerQuickSearchResultsTable),
                provides=IValues)
class CatalogManagerQuickSearchResultsValues(SharedToolQuickSearchResultsValues):
    """Catalog manager quick search results values adapter"""


@view_config(name='quick-catalog-search.json',
             context=ICatalogManagerTarget, request_type=IPyAMSLayer,
             permission=VIEW_SYSTEM_PERMISSION, renderer='json', xhr=True)
def catalog_manager_quick_search_view(request):
    """Catalog manager quick search view"""
    results = CatalogManagerQuickSearchResultsTable(request.context, request)
    return get_json_search_results(request, results)


@adapter_config(name='quick-search',
                required=(ICatalogManagerTarget, IAdminLayer, CatalogManagerDashboardView),
                provides=IInnerTable)
class CatalogManagerQuickSearchView(SharedToolQuickSearchView):
    """Catalog manager quick search view"""

    @property
    def legend(self):
        """Legend getter"""
        translate = self.request.localizer.translate
        return translate(_("Between all contents of « {} » content type")) \
            .format(translate(CATALOG_ENTRY_CONTENT_NAME))

    quick_search_url = 'quick-catalog-search.json'
    advanced_search_url = '#advanced-catalog-search.html'


@pagelet_config(name='quick-catalog-search.html',
                context=ICatalogManagerTarget, layer=IPyAMSLayer,
                permission=VIEW_SYSTEM_PERMISSION)
class CatalogManagerQuickSearchPageView(SharedToolQuickSearchPageView):
    """Catalog manager quick search page view"""

    table_class = CatalogManagerQuickSearchResultsTable


#
# Catalog advanced search
#

@viewlet_config(name='advanced-catalog-search.menu',
                context=ICatalogManagerTarget, layer=IAdminLayer,
                manager=IAllCatalogDashboardMenu, weight=40,
                permission=VIEW_SYSTEM_PERMISSION)
class CatalogManagerAdvancedSearchMenu(CatalogManagerDashboardMenuMixin, SharedToolAdvancedSearchMenu):
    """Catalog manager advanced search menu"""

    href = "#advanced-catalog-search.html"


class CatalogManagerAdvancedSearchForm(SharedToolAdvancedSearchForm):
    """Catalog manager advanced search form"""

    ajax_form_handler = 'advanced-catalog-search-results.html'


@pagelet_config(name='advanced-catalog-search.html',
                context=ICatalogManagerTarget, layer=IPyAMSLayer,
                permission=VIEW_SYSTEM_PERMISSION)
class CatalogManagerAdvancedSearchView(SharedToolAdvancedSearchView):
    """Catalog manager advanced search view"""

    search_form = CatalogManagerAdvancedSearchForm


class CatalogManagerAdvancedSearchResultsTable(SharedToolAdvancedSearchResultsTable):
    """Catalog manager advanced search results table"""


@adapter_config(required=(ICatalogManagerTarget, IPyAMSLayer, CatalogManagerAdvancedSearchResultsTable),
                provides=IValues)
class CatalogManagerAdvancedSearchResultsValues(CatalogManagerDashboardValuesMixin,
                                                   SharedToolAdvancedSearchResultsValues):
    """Catalog manager advanced search results values"""


@pagelet_config(name='advanced-catalog-search-results.html',
                context=ICatalogManagerTarget, layer=IPyAMSLayer,
                permission=VIEW_SYSTEM_PERMISSION, xhr=True)
class CatalogManagerAdvancedSEarchResultsView(SharedToolAdvancedSearchResultsView):
    """Catalog manager advanced search results view"""

    table_class = CatalogManagerAdvancedSearchResultsTable
