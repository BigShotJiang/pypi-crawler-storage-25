#
# Copyright (c) 2015-2023 Thierry Florac <tflorac AT ulthar.net>
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE.
#

"""PyAMS_*** module

"""

from pyams_app_msc.shared.catalog.interfaces import CATALOG_PAGE_NAME, ICatalogManager, ICatalogManagerTarget, \
    ICatalogManagerTargetPortalPage, IWfCatalogEntry
from pyams_content.shared.common.portal import shared_content_portal_page
from pyams_portal.interfaces import IPortalPage, IPortalPortletsConfiguration, PORTAL_PAGE_KEY
from pyams_portal.page import PortalPage, portal_context_portlets_configuration
from pyams_utils.adapter import adapter_config, get_annotation_adapter
from pyams_utils.factory import factory_config
from pyams_utils.traversing import get_parent
from pyams_utils.zodb import volatile_property

__docformat__ = 'restructuredtext'


#
# Catalog manager target portal pages
#

class CatalogManagerTargetPageMixin:
    """Catalog manager target portal page mixin class"""
    
    @volatile_property
    def can_inherit(self):
        return False


@factory_config(ICatalogManagerTargetPortalPage)
class CatalogManagerTargetPortalPage(CatalogManagerTargetPageMixin, PortalPage):
    """Catalog manager target portal page"""


@adapter_config(name=CATALOG_PAGE_NAME,
                required=ICatalogManagerTarget,
                provides=IPortalPage)
def catalog_manager_target_page(context, page_name=CATALOG_PAGE_NAME):
    """Catalog manager target portal page factory"""
    
    def set_page_name(page):
        """Set page name after creation"""
        page.name = page_name
    
    key = f'{PORTAL_PAGE_KEY}::{page_name}' if page_name else PORTAL_PAGE_KEY
    return get_annotation_adapter(context, key, ICatalogManagerTargetPortalPage,
                                  name=f'++page++{page_name}',
                                  callback=set_page_name)


@adapter_config(name=CATALOG_PAGE_NAME,
                required=ICatalogManagerTarget,
                provides=IPortalPortletsConfiguration)
def catalog_manager_target_portlets_configuration(context):
    """Catalog manager target portlets configuration"""
    return portal_context_portlets_configuration(context, page_name=CATALOG_PAGE_NAME)


#
# Catalog entry portal pages
#

@adapter_config(required=IWfCatalogEntry,
                provides=IPortalPage)
@adapter_config(name=CATALOG_PAGE_NAME,
                required=IWfCatalogEntry,
                provides=IPortalPage)
def catalog_entry_page_factory(context):
    """Catalog entry page factory"""
    return shared_content_portal_page(context, page_name=CATALOG_PAGE_NAME)


@adapter_config(name=CATALOG_PAGE_NAME,
                required=IWfCatalogEntry,
                provides=IPortalPortletsConfiguration)
def catalog_entry_portlets_configuration(context):
    """Catalog entry portlets configuration"""
    return portal_context_portlets_configuration(context, page_name=CATALOG_PAGE_NAME)


@adapter_config(name=CATALOG_PAGE_NAME,
                required=ICatalogManager,
                provides=IPortalPortletsConfiguration)
def catalog_manager_portlets_configuration(context):
    """Catalog manager portlets configuration"""
    parent = get_parent(context, ICatalogManagerTarget)
    return portal_context_portlets_configuration(parent, page_name=CATALOG_PAGE_NAME)
