# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE.
#

from pyams_app_msc.shared.theater import IMovieTheater
from pyams_app_msc.shared.theater.api.interfaces import MSC_THEATER_PRINCIPALS_API_SEARCH_PATH, \
    MSC_THEATER_PRINCIPALS_API_SEARCH_ROUTE
from pyams_form.ajax import ajax_form_config
from pyams_layer.interfaces import IPyAMSLayer
from pyams_security.interfaces import IDefaultProtectionPolicy
from pyams_security.interfaces.base import VIEW_SYSTEM_PERMISSION
from pyams_security_views.widget.principal import PrincipalWidget
from pyams_security_views.zmi.policy import ProtectedObjectRolesEditForm
from pyams_utils.traversing import get_parent

__docformat__ = 'restructuredtext'


@ajax_form_config(name='object-roles.html',
                  context=IDefaultProtectionPolicy, layer=IPyAMSLayer,
                  permission=VIEW_SYSTEM_PERMISSION)
class MSCProtectedObjectRolesEditForm(ProtectedObjectRolesEditForm):
    """MSC protected object roles edit form"""
    
    def update_widgets(self, prefix=None):
        super().update_widgets(prefix)
        theater = get_parent(self.context, IMovieTheater)
        if theater is not None:
            path = self.request.registry.settings.get(f'{MSC_THEATER_PRINCIPALS_API_SEARCH_ROUTE}_route.path',
                                                      MSC_THEATER_PRINCIPALS_API_SEARCH_PATH).replace('{theater_name}',
                                                                                                      theater.__name__)
            for widget in self.widgets.values():
                if isinstance(widget, PrincipalWidget):
                    widget.ajax_url = path
