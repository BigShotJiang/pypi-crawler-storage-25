# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE.
#

from hypatia.interfaces import ICatalog
from zope.intid.interfaces import IIntIds
from zope.location import locate
from zope.principalannotation.interfaces import IPrincipalAnnotationUtility

from pyams_catalog.utils import reindex_object
from pyams_utils.registry import get_utility

__docformat__ = 'restructuredtext'


def evolve(site):
    """Evolve 4: reset profiles parent"""
    catalog = get_utility(ICatalog)
    intids = get_utility(IIntIds)
    utility = get_utility(IPrincipalAnnotationUtility)
    profiles = utility.annotations
    for principal_id, annotations in profiles.items():
        print('.', end='')
        for key, annotation in annotations.items():
            annotation.principal_id = principal_id
            locate(annotation, site, f'++profile++{intids.register(annotation)}')
            reindex_object(annotation, catalog)
    print()
