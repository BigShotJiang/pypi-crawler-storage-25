# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE.
#

from hypatia.interfaces import ICatalog
from zope.principalannotation.interfaces import IPrincipalAnnotationUtility

from pyams_app_msc.feature.profile import IUserProfile, USER_PROFILE_KEY
from pyams_catalog.utils import reindex_object
from pyams_utils.registry import get_utility

__docformat__ = 'restructuredtext'


def evolve(site):
    """Evolve 3: update users profiles structures types"""
    catalog = get_utility(ICatalog)
    if 'profile_structure' in catalog:
        del catalog['profile_structure']
    utility = get_utility(IPrincipalAnnotationUtility)
    profiles = utility.annotations
    for principal_id, annotations in profiles.items():
        user_profile = annotations.get(USER_PROFILE_KEY, None)
        if not IUserProfile.providedBy(user_profile):
            continue
        if hasattr(user_profile, 'structure_type'):
            structure_type = getattr(user_profile, 'structure_type', None)
            if structure_type:
                user_profile.structures_types = [structure_type]
            delattr(user_profile, 'structure_type')
            reindex_object(user_profile, catalog)
