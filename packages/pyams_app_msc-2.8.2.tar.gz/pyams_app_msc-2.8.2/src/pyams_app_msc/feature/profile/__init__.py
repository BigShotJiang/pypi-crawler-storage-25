#
# Copyright (c) 2015-2023 Thierry Florac <tflorac AT ulthar.net>
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE.
#

"""PyAMS_*** module

"""

from persistent import Persistent
from pyramid.authorization import ALL_PERMISSIONS, Allow
from pyramid.events import subscriber
from pyramid.interfaces import IRequest
from zope.container.contained import Contained
from zope.intid.interfaces import IIntIds
from zope.lifecycleevent.interfaces import IObjectModifiedEvent
from zope.location import locate
from zope.schema.fieldproperty import FieldProperty

from pyams_app_msc.feature.profile.interfaces import IOperatorProfile, IUserProfile, OPERATOR_PROFILE_KEY, \
    USER_PROFILE_KEY
from pyams_app_msc.reference.structure.interfaces import IStructureTypeTable
from pyams_catalog.utils import reindex_object
from pyams_content.interfaces import IObjectType
from pyams_i18n.interfaces import II18n
from pyams_security.interfaces.base import IPrincipalInfo
from pyams_security.interfaces.names import ADMIN_USER_ID
from pyams_security.interfaces.plugin import ILocalUser
from pyams_utils.adapter import adapter_config, get_annotation_adapter
from pyams_utils.factory import factory_config, get_interface_base_name
from pyams_utils.interfaces import MISSING_INFO
from pyams_utils.registry import get_utility
from pyams_utils.request import query_request

__docformat__ = 'restructuredtext'


#
# User profile
#

@factory_config(IUserProfile)
class UserProfile(Persistent, Contained):
    """User profile persistent class"""

    principal_id = None

    active = FieldProperty(IUserProfile['active'])
    firstname = FieldProperty(IUserProfile['firstname'])
    lastname = FieldProperty(IUserProfile['lastname'])
    email = FieldProperty(IUserProfile['email'])
    phone_number = FieldProperty(IUserProfile['phone_number'])
    establishment = FieldProperty(IUserProfile['establishment'])
    structures_types = FieldProperty(IUserProfile['structures_types'])
    establishment_address = FieldProperty(IUserProfile['establishment_address'])
    local_theaters = FieldProperty(IUserProfile['local_theaters'])
    subscribe_to_newsletters = FieldProperty(IUserProfile['subscribe_to_newsletters'])

    def __acl__(self):
        return [
            (Allow, ADMIN_USER_ID, ALL_PERMISSIONS),
            (Allow, self.principal_id, ALL_PERMISSIONS)
        ]

    def get_structures_types(self):
        if not self.structures_types:
            return MISSING_INFO
        structures = get_utility(IStructureTypeTable)
        return ', '.join(map(lambda x: II18n(x).query_attribute('title'),
                             filter(lambda x: x is not None,
                                    map(lambda x: structures.get(x),
                                        self.structures_types)))) or MISSING_INFO


@adapter_config(required=IUserProfile,
                provides=IObjectType)
def user_profile_object_type(context):
    """User profile object type getter"""
    return get_interface_base_name(IUserProfile)


@adapter_config(required=IPrincipalInfo,
                provides=IUserProfile)
def principal_user_profile(principal):
    """Principal user profile factory"""

    def user_profile_callback(profile):
        profile.principal_id = principal.id
        request = query_request()
        if request is not None:
            root = request.root
            intids = get_utility(IIntIds)
            locate(profile, root)  # avoid NotYet exception
            locate(profile, root, '++profile++{0}'.format(intids.register(profile)))

    return get_annotation_adapter(principal, USER_PROFILE_KEY, IUserProfile,
                                  locate=False, callback=user_profile_callback)


@adapter_config(required=IRequest,
                provides=IUserProfile)
def request_user_profile(request):
    """Request user profile factory"""
    return IUserProfile(request.principal, None)


@adapter_config(required=ILocalUser,
                provides=IUserProfile)
def local_user_user_profile(user):
    """Local user profile factory"""
    principal = IPrincipalInfo(user, None)
    if principal is not None:
        return IUserProfile(principal, None)
    return None


@subscriber(IObjectModifiedEvent, context_selector=ILocalUser)
def handle_modified_local_user(event):
    """Handle modified local user event handler"""
    profile = IUserProfile(event.object, None)
    if profile is not None:
        profile.firstname = event.object.firstname
        profile.lastname = event.object.lastname
        profile.establishment = event.object.company_name
        reindex_object(profile)


#
# Operator profile
#

@factory_config(IOperatorProfile)
class OperatorProfile(Persistent, Contained):
    """Operator profile persistent class"""

    principal_id = None

    session_seats_display_mode = FieldProperty(IOperatorProfile['session_seats_display_mode'])
    today_program_length = FieldProperty(IOperatorProfile['today_program_length'])


@adapter_config(required=IPrincipalInfo,
                provides=IOperatorProfile)
def principal_operator_profile(principal):
    """Principal operator profile factory"""

    def operator_profile_callback(profile):
        profile.principal_id = principal.id
        request = query_request()
        if request is not None:
            root = request.root
            intids = get_utility(IIntIds)
            locate(profile, root)  # avoid NotYet exception
            locate(profile, root, '++profile++{0}'.format(intids.register(profile)))

    return get_annotation_adapter(principal, OPERATOR_PROFILE_KEY, IOperatorProfile,
                                  locate=False, callback=operator_profile_callback)


@adapter_config(required=IRequest,
                provides=IOperatorProfile)
def request_operator_profile(request):
    """Request operator profile factory"""
    return IOperatorProfile(request.principal, None)
