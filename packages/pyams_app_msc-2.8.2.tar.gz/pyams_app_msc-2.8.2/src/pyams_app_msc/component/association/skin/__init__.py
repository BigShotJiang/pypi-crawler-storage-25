# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE.
#

from pyams_app_msc.shared.newsletter.skin import IPyAMSMSCNewsletterLayer
from pyams_content.component.association.skin import AssociationsViewlet
from pyams_template.template import override_template

__docformat__ = 'restructuredtext'


override_template(AssociationsViewlet,
                  template='templates/association-viewlet-email.pt',
                  layer=IPyAMSMSCNewsletterLayer)
