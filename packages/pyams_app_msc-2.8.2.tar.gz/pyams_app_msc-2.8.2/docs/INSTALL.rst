
==================================
PyAMS MSC application installation
==================================

.. contents::


PyAMS MSC pre-requisites
------------------------

PyAMS MSC relies on several external products:
 - a RelStorage compatible database (tested with PostgreSQL)
 - a Redis cache server
 - an Elasticsearch index (see PyAMS_content_es documentation).


PyAMS MSC installation procedure
--------------------------------

PyAMS MSC is a Pyramid package which can be included like any standard PyAMS package.

PyAMS MSC is overriding a set of default PyAMS packages, which should **NOT** be included into
Pyramid configuration defined in *development.ini* and *production.ini* files. These packages are:
 - pyams_security_views
 - pyams_content_es
 - pyams_content_themes
 - pyams_content_api
