#  Srigram - Telegram MTProto API Client Library for Python
#  Copyright (C) 2017-present Dan <https://github.com/delivrance>
#  Copyright (C) 2026-present SrijanMajumdar <https://github.com/SrijanMajumdar>
#
#  This file is part of Srigram.
#
#  Srigram is free software: you can redistribute it and/or modify
#  it under the terms of the GNU Lesser General Public License as published
#  by the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  Srigram is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU Lesser General Public License for more details.
#
#  You should have received a copy of the GNU Lesser General Public License
#  along with Srigram.  If not, see <http://www.gnu.org/licenses/>.

from typing import Callable

from .handler import Handler


class PreCheckoutQueryHandler(Handler):
    """The PreCheckoutQueryHandler handler class. Used to handle pre-checkout queries coming from buy buttons.
    It is intended to be used with :meth:`~srigram.Client.add_handler`

    For a nicer way to register this handler, have a look at the
    :meth:`~srigram.Client.on_pre_checkout_query` decorator.

    Parameters:
        callback (``Callable``):
            Pass a function that will be called when a new PreCheckoutQuery arrives. It takes *(client, pre_checkout_query)*
            as positional arguments (look at the section below for a detailed description).

        filters (:obj:`Filters`):
            Pass one or more filters to allow only a subset of callback queries to be passed
            in your callback function.

    Other parameters:
        client (:obj:`~srigram.Client`):
            The Client itself, useful when you want to call other API methods inside the message handler.

        pre_checkout_query (:obj:`~srigram.types.PreCheckoutQuery`):
            New incoming pre-checkout query. Contains full information about checkout.

    """

    def __init__(self, callback: Callable, filters=None):
        super().__init__(callback, filters)
