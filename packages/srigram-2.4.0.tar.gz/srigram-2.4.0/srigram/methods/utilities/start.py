#  Srigram - Telegram MTProto API Client Library for Python
#  Copyright (C) 2017-present Dan <https://github.com/delivrance>
#  Copyright (C) 2026-present SrijanMajumdar <https://github.com/SrijanMajumdar>
#
#  This file is part of Srigram.
#
#  Srigram is free software: you can redistribute it and/or modify
#  it under the terms of the GNU Lesser General Public License as published
#  by the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  Srigram is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU Lesser General Public License for more details.
#
#  You should have received a copy of the GNU Lesser General Public License
#  along with Srigram.  If not, see <http://www.gnu.org/licenses/>.

import logging

import srigram
from srigram import raw

log = logging.getLogger(__name__)


class Start:
    async def start(
        self: "srigram.Client"
    ):
        """Start the client.

        This method connects the client to Telegram and, in case of new sessions, automatically manages the
        authorization process using an interactive prompt.

        Returns:
            :obj:`~srigram.Client`: The started client itself.

        Raises:
            ConnectionError: In case you try to start an already started client.

        Example:
            .. code-block:: python

                from srigram import Client

                app = Client("my_account")


                async def main():
                    await app.start()
                    ...  # Invoke API methods
                    await app.stop()


                app.run(main())
        """
        is_authorized = await self.connect()

        try:
            if not is_authorized:
                await self.authorize()

            if not await self.storage.is_bot() and self.takeout:
                self.takeout_id = (await self.invoke(raw.functions.account.InitTakeoutSession())).id
                log.info("Takeout session %s initiated", self.takeout_id)

            await self.invoke(raw.functions.updates.GetState())
        except (Exception, KeyboardInterrupt):
            await self.disconnect()
            raise
        else:
            self.me = await self.get_me()
            await self.initialize()

            # --- SRIGRAM STARTUP SEQUENCE ---
            import asyncio

            try:
                import tgcrypto
                print("🟢 Tgcrypto found.")
            except ImportError:
                print("🟠 Tgcrypto is missing. (Run 'pip install tgcrypto' for 10x speed)")
            await asyncio.sleep(1)

            print("🟢 API credentials are correct.")
            await asyncio.sleep(1)
            print("🟢 Establishing secured connection.")
            await asyncio.sleep(1)

            first_name = self.me.first_name
            username = f"@{self.me.username}" if self.me.username else "N/A"
            user_id = self.me.id

            print("\n==================================================")
            print(f"🚀 Bot is Online")
            print(f"Name: {first_name}")
            print(f"Username: {username}")
            print(f"ID: {user_id}")
            print("==================================================\n")

            print("💬 Thanks for using Srigram. For any kind of support, Check https://t.me/Srigram")
            # --------------------------------

            return self
