#  Srigram - Telegram MTProto API Client Library for Python
#  Copyright (C) 2020 Cezar H. <https://github.com/usernein>
#  Copyright (C) 2026-present SrijanMajumdar <https://github.com/SrijanMajumdar>
#
#  This file is part of Srigram.
#
#  Srigram is free software: you can redistribute it and/or modify
#  it under the terms of the GNU Lesser General Public License as published
#  by the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  Srigram is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU Lesser General Public License for more details.
#
#  You should have received a copy of the GNU Lesser General Public License
#  along with Srigram.  If not, see <http://www.gnu.org/licenses/>.

from enum import auto

from .auto_name import AutoName


class ListenerTypes(AutoName):
    """Listener type enumeration used in :obj:`~srigram.types.Client`."""

    MESSAGE = auto()
    "A Message"

    CALLBACK_QUERY = auto()
    "A CallbackQuery"
