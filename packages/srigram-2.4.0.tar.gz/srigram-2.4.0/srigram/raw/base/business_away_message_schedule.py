#  Srigram - Telegram MTProto API Framework for Python
#  Copyright (C) 2026 Srigram
#
#  This product is a fork and includes software originally developed by Dan Tès (Pyrogram).
#  Copyright (C) 2017-2024 Dan <https://github.com/delivrance>
#
#  This product also includes modifications by Pyrofork Contributors.

# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from typing import Union
from srigram import raw
from srigram.raw.core import TLObject

BusinessAwayMessageSchedule = Union[raw.types.BusinessAwayMessageScheduleAlways, raw.types.BusinessAwayMessageScheduleCustom, raw.types.BusinessAwayMessageScheduleOutsideWorkHours]


# noinspection PyRedeclaration
class BusinessAwayMessageSchedule:  # type: ignore
    """Telegram API base type.

    Constructors:
        This base type has 3 constructors available.

        .. currentmodule:: srigram.raw.types

        .. autosummary::
            :nosignatures:

            BusinessAwayMessageScheduleAlways
            BusinessAwayMessageScheduleCustom
            BusinessAwayMessageScheduleOutsideWorkHours
    """

    QUALNAME = "srigram.raw.base.BusinessAwayMessageSchedule"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes: "
                        "you tried to use a base type instance as argument, "
                        "but you need to instantiate one of its constructors instead. "
                        "More info: https://pyrofork.wulan17.dev/telegram/base/business-away-message-schedule")
