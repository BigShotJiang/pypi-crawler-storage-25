#  Srigram - Telegram MTProto API Framework for Python
#  Copyright (C) 2026 Srigram
#
#  This product is a fork and includes software originally developed by Dan Tès (Pyrogram).
#  Copyright (C) 2017-2024 Dan <https://github.com/delivrance>
#
#  This product also includes modifications by Pyrofork Contributors.

# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from typing import Union
from srigram import raw
from srigram.raw.core import TLObject

AttachMenuPeerType = Union[raw.types.AttachMenuPeerTypeBotPM, raw.types.AttachMenuPeerTypeBroadcast, raw.types.AttachMenuPeerTypeChat, raw.types.AttachMenuPeerTypePM, raw.types.AttachMenuPeerTypeSameBotPM]


# noinspection PyRedeclaration
class AttachMenuPeerType:  # type: ignore
    """Telegram API base type.

    Constructors:
        This base type has 5 constructors available.

        .. currentmodule:: srigram.raw.types

        .. autosummary::
            :nosignatures:

            AttachMenuPeerTypeBotPM
            AttachMenuPeerTypeBroadcast
            AttachMenuPeerTypeChat
            AttachMenuPeerTypePM
            AttachMenuPeerTypeSameBotPM
    """

    QUALNAME = "srigram.raw.base.AttachMenuPeerType"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes: "
                        "you tried to use a base type instance as argument, "
                        "but you need to instantiate one of its constructors instead. "
                        "More info: https://pyrofork.wulan17.dev/telegram/base/attach-menu-peer-type")
