#  Srigram - Telegram MTProto API Framework for Python
#  Copyright (C) 2026 Srigram
#
#  This product is a fork and includes software originally developed by Dan Tès (Pyrogram).
#  Copyright (C) 2017-2024 Dan <https://github.com/delivrance>
#
#  This product also includes modifications by Pyrofork Contributors.

# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from typing import Union
from srigram import raw
from srigram.raw.core import TLObject

BotCommand = Union[raw.types.BotCommand]


# noinspection PyRedeclaration
class BotCommand:  # type: ignore
    """Telegram API base type.

    Constructors:
        This base type has 1 constructor available.

        .. currentmodule:: srigram.raw.types

        .. autosummary::
            :nosignatures:

            BotCommand

    Functions:
        This object can be returned by 1 function.

        .. currentmodule:: srigram.raw.functions

        .. autosummary::
            :nosignatures:

            bots.GetBotCommands
    """

    QUALNAME = "srigram.raw.base.BotCommand"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes: "
                        "you tried to use a base type instance as argument, "
                        "but you need to instantiate one of its constructors instead. "
                        "More info: https://pyrofork.wulan17.dev/telegram/base/bot-command")
