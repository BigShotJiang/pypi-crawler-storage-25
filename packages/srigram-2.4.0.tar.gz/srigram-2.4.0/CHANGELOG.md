# Changelog

## [28-03-26]
### Version [2.4.0]

**✨ Telegram Bot API Updates (Buttons & Styling)**
Srigram now fully supports the newest Telegram UI features for both Inline and Standard Reply Keyboards!

* **Custom Emojis on Buttons:** Added native support for `icon_custom_emoji_id`. You can now attach premium and custom animated emojis directly to `InlineKeyboardButton` and `KeyboardButton`.
* **Button Styling:** Added support for the new `style` parameter. You can now color your buttons using `"primary"` (Blue), `"danger"` (Red), and `"success"` (Green).
* **Framework Optimization:** Safely implemented these features using the native `KeyboardButtonStyle` MTProto object to ensure complete stability with existing bot features (like Business Away Messages).

**Code Example:**
`InlineKeyboardButton("Click Me", style="primary", icon_custom_emoji_id=5368324170671202286)`


