#  -*- coding: utf-8 -*-
#
#  Copyright (c) 2023-2026 Featrix, Inc, All Rights Reserved
#
#  Proprietary and Confidential.  Unauthorized use, copying or dissemination
#  of these materials is strictly prohibited.
#

"""
FoundationalModel class for FeatrixSphere API.

Represents a trained embedding space (foundational model).
"""

import gc
import sys
import time
import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, Any, Optional, List, Union, TYPE_CHECKING

if TYPE_CHECKING:
    from .http_client import ClientContext
    import pandas as pd
    import numpy as np

from .predictor import Predictor
from .prediction_result import PredictionResult
from .vector_database import VectorDatabase
from .vector_view import VectorView
from .reference_record import ReferenceRecord

logger = logging.getLogger(__name__)


def _parse_datetime(value) -> Optional[datetime]:
    """Parse a datetime from ISO string or return as-is if already datetime."""
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        try:
            # Handle ISO format with or without timezone
            return datetime.fromisoformat(value.replace('Z', '+00:00'))
        except (ValueError, AttributeError):
            return None
    return None


# ── Client-side intent validation ────────────────────────────────────────────
# Vocabularies copied here so the SDK package stays standalone. Keep these in
# sync with ``src/lib/featrix/neural/user_intent.{BINARY,MULTICLASS,REGRESSION}_OBJECTIVES``.
_BINARY_INTENT_VOCAB = frozenset({
    "balanced",
    "only_alert_when_confident",
    "catch_everything",
    "catch_everything_aggressive",
    "minimize_cost",
    "rank",
    "predict_probabilities",
})

_MULTICLASS_INTENT_VOCAB = frozenset({
    "balanced",
    "accuracy",
    "rank_classes",
    "top_k_hit",
})

_REGRESSION_INTENT_VOCAB = frozenset({
    "balanced",
    "minimize_typical_error",
    "minimize_worst_case",
    "minimize_relative_error",
})


def _validate_binary_intent(
    *,
    intent: str,
    cost_false_positive: Optional[float],
    cost_false_negative: Optional[float],
) -> None:
    """Client-side early-fail. Server revalidates.

    Rules (same as ``user_intent.from_binary_kwargs``):
      * intent must be in the binary vocabulary.
      * ``intent="minimize_cost"`` requires both costs.
      * A non-cost intent combined with ``cost_false_*`` kwargs is incoherent —
        the customer must pick one.
    """
    if intent not in _BINARY_INTENT_VOCAB:
        raise ValueError(
            f"Unknown intent={intent!r}. "
            f"Must be one of: {sorted(_BINARY_INTENT_VOCAB)}."
        )
    if intent == "minimize_cost":
        if cost_false_positive is None or cost_false_negative is None:
            raise ValueError(
                "intent='minimize_cost' requires BOTH cost_false_positive and "
                "cost_false_negative."
            )
    else:
        if cost_false_positive is not None or cost_false_negative is not None:
            raise ValueError(
                f"intent={intent!r} is incompatible with cost_false_positive / "
                f"cost_false_negative. Either drop the costs, or use "
                f"intent='minimize_cost'."
            )


def _validate_multiclass_intent(*, intent: str, k: Optional[int]) -> None:
    """Client-side early-fail for multiclass intent + k= kwarg."""
    if intent not in _MULTICLASS_INTENT_VOCAB:
        raise ValueError(
            f"Unknown intent={intent!r}. "
            f"Must be one of: {sorted(_MULTICLASS_INTENT_VOCAB)}."
        )
    if intent == "top_k_hit":
        if k is None:
            raise ValueError(
                "intent='top_k_hit' requires k= (positive integer, e.g. k=3)."
            )
        if not isinstance(k, int) or k <= 0:
            raise ValueError(
                f"k= must be a positive integer, got {k!r}."
            )
    else:
        if k is not None:
            raise ValueError(
                f"intent={intent!r} is incompatible with k=. The k= kwarg "
                f"only applies to intent='top_k_hit'."
            )


def _validate_regression_intent(*, intent: str) -> None:
    """Client-side early-fail for regression intent (Tier-1 vocab is balanced only)."""
    if intent not in _REGRESSION_INTENT_VOCAB:
        raise ValueError(
            f"Unknown intent={intent!r}. "
            f"Must be one of: {sorted(_REGRESSION_INTENT_VOCAB)}."
        )


@dataclass
class FoundationalModel:
    """
    Represents a foundational model (embedding space).

    Attributes:
        id: Session ID / FM ID
        name: Model name
        status: Training status ("training", "done", "error")
        dimensions: Embedding dimensions (d_model)
        epochs: Training epochs completed
        created_at: Creation timestamp

    Usage:
        # Create from client
        fm = featrix.create_foundational_model(
            name="customer_embeddings",
            data_file="customers.csv"
        )

        # Wait for training
        fm.wait_for_training()

        # Create classifier
        predictor = fm.create_binary_classifier(
            name="churn_predictor",
            target_column="churned"
        )

        # Create vector database
        vdb = fm.create_vector_database(
            name="customer_search",
            records=customer_records
        )

        # Encode records
        vectors = fm.encode([{"age": 35}, {"age": 42}])
    """

    id: str
    name: Optional[str] = None
    status: Optional[str] = None
    dimensions: Optional[int] = None
    epochs: Optional[int] = None
    final_loss: Optional[float] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    session_type: Optional[str] = None
    compute_cluster: Optional[str] = None
    error_message: Optional[str] = None
    training_progress: Optional[Dict[str, Any]] = None
    jobs: Optional[Dict[str, Any]] = field(default_factory=dict, repr=False)

    # Internal
    _ctx: Optional['ClientContext'] = field(default=None, repr=False)

    @classmethod
    def from_response(
        cls,
        response: Dict[str, Any],
        ctx: Optional['ClientContext'] = None
    ) -> 'FoundationalModel':
        """Create FoundationalModel from API response."""
        session_id = response.get('session_id', '')

        return cls(
            id=session_id,
            name=response.get('name') or response.get('label'),
            status=response.get('status'),
            dimensions=response.get('d_model') or response.get('dimensions'),
            epochs=response.get('epochs') or response.get('final_epoch'),
            final_loss=response.get('final_loss'),
            created_at=_parse_datetime(response.get('created_at')),
            session_type=response.get('session_type'),
            compute_cluster=response.get('compute_cluster'),
            _ctx=ctx,
        )

    @classmethod
    def from_session_id(
        cls,
        session_id: str,
        ctx: 'ClientContext'
    ) -> 'FoundationalModel':
        """Load FoundationalModel from session ID."""
        # Get session info - response has {"session": {...}, "jobs": {...}}
        response_data = ctx.get_json(f"/compute/session/{session_id}")
        session = response_data.get('session', response_data)

        fm = cls(
            id=session_id,
            name=session.get('name'),
            status=session.get('status'),
            created_at=_parse_datetime(session.get('created_at')),
            session_type=session.get('session_type'),
            compute_cluster=session.get('compute_cluster'),
            _ctx=ctx,
        )

        # Extract model info, training stats, jobs, error_message
        fm._update_from_session(response_data)

        return fm

    def create_binary_classifier(
        self,
        target_column: str,
        name: Optional[str] = None,
        labels_file: Optional[str] = None,
        labels_df: Optional['pd.DataFrame'] = None,
        epochs: int = 0,
        rare_label_value: Optional[str] = None,
        class_imbalance: Optional[Dict[str, float]] = None,
        cost_false_positive: Optional[float] = None,
        cost_false_negative: Optional[float] = None,
        intent: Optional[str] = None,
        auto_collapse_synonyms: Optional[bool] = None,
        synonym_collapse_threshold: Optional[float] = None,
        label_mapping: Optional[Dict[str, str]] = None,
        webhooks: Optional[Dict[str, str]] = None,
        **kwargs
    ) -> Predictor:
        """
        Create a binary classifier on this foundational model.

        For target columns with exactly 2 classes. Supports cost-sensitive
        optimization for asymmetric error costs (e.g., fraud detection where
        missing fraud is much worse than a false alarm).

        Args:
            target_column: Column name to predict (must have exactly 2 unique values)
            name: Predictor name (optional)
            labels_file: Path to CSV with labels (optional - uses existing data if not provided)
            labels_df: DataFrame with labels (optional - alternative to labels_file)
            epochs: Training epochs (0 = automatic based on dataset complexity)
            rare_label_value: Which class is the minority/positive class for metrics
            class_imbalance: Expected real-world class distribution, e.g.
                {"approved": 0.97, "rejected": 0.03}. Use when training data
                is resampled but production distribution differs.
            cost_false_positive: Cost of a false positive (e.g., 100 = $100 per false alarm).
                Used for Bayes-optimal threshold selection. Implies intent="minimize_cost"
                when intent is not explicitly provided.
            cost_false_negative: Cost of a false negative (e.g., 5000 = $5000 per missed case).
                Used for Bayes-optimal threshold selection.
            intent: Plain-language objective. One of:
                "balanced" (default), "only_alert_when_confident" (high precision),
                "catch_everything" (catch ≥85% of positives), "catch_everything_aggressive"
                (catch ≥95% of positives — pick this on heavily skewed data or when
                missing positives is much worse than false alarms),
                "minimize_cost" (requires cost_false_positive + cost_false_negative),
                "rank" (AUC only, no threshold), or "predict_probabilities" (calibrated
                probabilities, fixed 0.5 threshold). When None, resolves from cost_*
                kwargs or defaults to "balanced".
            auto_collapse_synonyms: Auto-detect and merge near-duplicate class labels
                using BERT embedding similarity (default: True via config). Set False to disable.
            synonym_collapse_threshold: Cosine similarity threshold for synonym detection
                (default: 0.90 via config). Pairs above this are merged.
            label_mapping: Explicit old→new class name mapping, e.g.
                {"Unsafe & Dangerous": "Unsafe and Dangerous"}. Overrides auto-detection.
            webhooks: Webhook URLs for training events
            **kwargs: Additional training parameters

        Returns:
            Predictor object (training started). Call predictor.wait_for_training() to block.

        Example:
            # Basic binary classifier
            predictor = fm.create_binary_classifier(
                target_column="churned",
                rare_label_value="yes"
            )
            predictor.wait_for_training()

            # Cost-sensitive fraud detection
            predictor = fm.create_binary_classifier(
                target_column="is_fraud",
                rare_label_value="fraud",
                cost_false_positive=100,
                cost_false_negative=5000
            )
        """
        if cost_false_positive is not None:
            kwargs['cost_false_positive'] = cost_false_positive
        if cost_false_negative is not None:
            kwargs['cost_false_negative'] = cost_false_negative
        if intent is not None:
            _validate_binary_intent(
                intent=intent,
                cost_false_positive=cost_false_positive,
                cost_false_negative=cost_false_negative,
            )
            kwargs['intent'] = intent
        if auto_collapse_synonyms is not None:
            kwargs['auto_collapse_synonyms'] = auto_collapse_synonyms
        if synonym_collapse_threshold is not None:
            kwargs['synonym_collapse_threshold'] = synonym_collapse_threshold
        if label_mapping is not None:
            kwargs['label_mapping'] = label_mapping

        return self._create_predictor(
            target_column=target_column,
            target_type="set",
            name=name,
            labels_file=labels_file,
            labels_df=labels_df,
            epochs=epochs,
            rare_label_value=rare_label_value,
            class_imbalance=class_imbalance,
            webhooks=webhooks,
            **kwargs
        )

    def create_multi_classifier(
        self,
        target_column: str,
        name: Optional[str] = None,
        labels_file: Optional[str] = None,
        labels_df: Optional['pd.DataFrame'] = None,
        epochs: int = 0,
        class_imbalance: Optional[Dict[str, float]] = None,
        intent: Optional[str] = None,
        k: Optional[int] = None,
        auto_collapse_synonyms: Optional[bool] = None,
        synonym_collapse_threshold: Optional[float] = None,
        label_mapping: Optional[Dict[str, str]] = None,
        webhooks: Optional[Dict[str, str]] = None,
        **kwargs
    ) -> Predictor:
        """
        Create a multiclass classifier on this foundational model.

        For target columns with 3 or more classes. Architecture is auto-sized
        based on dataset complexity.

        Args:
            target_column: Column name to predict (3+ unique values)
            name: Predictor name (optional)
            labels_file: Path to CSV with labels (optional - uses existing data if not provided)
            labels_df: DataFrame with labels (optional - alternative to labels_file)
            epochs: Training epochs (0 = automatic based on dataset complexity)
            class_imbalance: Expected real-world class distribution, e.g.
                {"cat": 0.7, "dog": 0.2, "bird": 0.1}. Use when training data
                is resampled but production distribution differs.
            intent: Plain-language objective. One of:
                "balanced" (default, macro-F1 across classes),
                "accuracy" (plain accuracy — good for class-balanced data),
                "rank_classes" (per-class ranking, no argmax — call
                predict() and read result.probabilities instead of
                result.prediction; the model declines to pick a single
                class and returns the per-class scores for you to rank),
                "top_k_hit" (correct class in top-K — requires k=).
            k: Required when intent="top_k_hit". Number of top predictions to
                count as a hit (e.g. k=3).
            auto_collapse_synonyms: Auto-detect and merge near-duplicate class labels
                using BERT embedding similarity (default: True via config). Set False to disable.
            synonym_collapse_threshold: Cosine similarity threshold for synonym detection
                (default: 0.90 via config). Pairs above this are merged.
            label_mapping: Explicit old→new class name mapping, e.g.
                {"Unsafe & Dangerous": "Unsafe and Dangerous"}. Overrides auto-detection.
            webhooks: Webhook URLs for training events
            **kwargs: Additional training parameters

        Returns:
            Predictor object (training started). Call predictor.wait_for_training() to block.

        Example:
            predictor = fm.create_multi_classifier(
                target_column="product_category",
                intent="top_k_hit",
                k=3,
            )
            predictor.wait_for_training()
        """
        if intent is not None:
            _validate_multiclass_intent(intent=intent, k=k)
            kwargs['intent'] = intent
            if k is not None:
                kwargs['k'] = k
        if auto_collapse_synonyms is not None:
            kwargs['auto_collapse_synonyms'] = auto_collapse_synonyms
        if synonym_collapse_threshold is not None:
            kwargs['synonym_collapse_threshold'] = synonym_collapse_threshold
        if label_mapping is not None:
            kwargs['label_mapping'] = label_mapping

        return self._create_predictor(
            target_column=target_column,
            target_type="set",
            name=name,
            labels_file=labels_file,
            labels_df=labels_df,
            epochs=epochs,
            class_imbalance=class_imbalance,
            webhooks=webhooks,
            **kwargs
        )

    def create_regressor(
        self,
        target_column: str,
        allow_null: bool = False,
        name: Optional[str] = None,
        labels_file: Optional[str] = None,
        labels_df: Optional['pd.DataFrame'] = None,
        epochs: int = 0,
        intent: Optional[str] = None,
        webhooks: Optional[Dict[str, str]] = None,
        **kwargs
    ) -> Predictor:
        """
        Create a regressor predictor from this foundational model.

        Args:
            target_column: Column name to predict
            allow_null: If True, return null when model uncertainty is too high
            name: Predictor name (optional)
            labels_file: Path to labels file (optional)
            labels_df: DataFrame with labels (optional)
            epochs: Training epochs (0 = auto)
            intent: Plain-language objective. One of:
                "balanced" (default — MSE loss, best-epoch by R²),
                "minimize_typical_error" (Huber loss, best-epoch by MAE — outliers
                exist but you care about the typical case),
                "minimize_worst_case" (tail-weighted MSE, best-epoch by RMSE —
                big misses are catastrophic, no tolerance for outliers),
                "minimize_relative_error" (log-target MSE, best-epoch by sMAPE —
                "off by 10%" matters more than "off by $10"; targets must be ≥0).
                When None, defaults to "balanced".
            webhooks: Webhook URLs for events
            **kwargs: Additional training parameters

        Returns:
            Predictor object (training started)
        """
        if intent is not None:
            _validate_regression_intent(intent=intent)
            kwargs['intent'] = intent
        return self._create_predictor(
            target_column=target_column,
            target_type="numeric",
            name=name,
            labels_file=labels_file,
            labels_df=labels_df,
            epochs=epochs,
            webhooks=webhooks,
            allow_null=allow_null,
            **kwargs
        )

    def _create_predictor(
        self,
        target_column: str,
        target_type: str,
        name: Optional[str] = None,
        labels_file: Optional[str] = None,
        labels_df: Optional['pd.DataFrame'] = None,
        epochs: int = 0,
        rare_label_value: Optional[str] = None,
        class_imbalance: Optional[Dict[str, float]] = None,
        webhooks: Optional[Dict[str, str]] = None,
        allow_null: bool = False,
        **kwargs
    ) -> Predictor:
        """Internal method to create predictor."""
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        # If labels file/df provided, use train_on_foundational_model which
        # creates a NEW session. The proxy handles finding the FM on any node.
        if labels_file or labels_df is not None:
            return self._create_predictor_with_labels(
                target_column=target_column,
                target_type=target_type,
                name=name,
                labels_file=labels_file,
                labels_df=labels_df,
                epochs=epochs,
                rare_label_value=rare_label_value,
                class_imbalance=class_imbalance,
                webhooks=webhooks,
                allow_null=allow_null,
                **kwargs
            )

        # No labels file — train on the FM's existing data.
        # Uses the FM's session directly (data lives in its session dir).
        data = {
            "target_column": target_column,
            "target_column_type": target_type,
            "epochs": epochs,
        }
        if rare_label_value:
            data["rare_label_value"] = rare_label_value
        if class_imbalance:
            data["class_imbalance"] = class_imbalance
        if webhooks:
            data["webhooks"] = webhooks
        if allow_null:
            data["allow_null"] = True
        data.update(kwargs)

        # Include project_id if set on client
        if self._ctx.current_project_id:
            data['project_id'] = self._ctx.current_project_id

        response = self._ctx.post_json(
            f"/compute/session/{self.id}/train_predictor",
            data=data
        )

        predictor_id = response.get('predictor_id', '')
        if not predictor_id:
            raise ValueError(
                f"Server did not return a predictor_id for session {self.id}. "
                f"The predictor may not have been created. Response: {response}"
            )

        return Predictor(
            id=predictor_id,
            session_id=self.id,
            target_column=target_column,
            target_type=target_type,
            name=name,
            status="training",
            _ctx=self._ctx,
            _foundational_model=self,
        )

    def _create_predictor_with_labels(
        self,
        target_column: str,
        target_type: str,
        name: Optional[str] = None,
        labels_file: Optional[str] = None,
        labels_df: Optional['pd.DataFrame'] = None,
        epochs: int = 0,
        rare_label_value: Optional[str] = None,
        class_imbalance: Optional[Dict[str, float]] = None,
        webhooks: Optional[Dict[str, str]] = None,
        allow_null: bool = False,
        **kwargs
    ) -> Predictor:
        """Create predictor with separate labels file.

        Uses /compute/train_on_foundational_model which creates a NEW session.
        The proxy handles finding the FM on any node and forwarding its session
        data to the target compute node.
        """
        import io
        import gzip
        import json

        # Prepare the labels data
        if labels_df is not None:
            csv_buffer = io.StringIO()
            labels_df.to_csv(csv_buffer, index=False)
            file_content = csv_buffer.getvalue().encode('utf-8')
            filename = "labels.csv"
        elif labels_file:
            with open(labels_file, 'rb') as f:
                file_content = f.read()
            filename = labels_file.split('/')[-1]
        else:
            raise ValueError("Either labels_file or labels_df must be provided")

        # Compress if large
        if len(file_content) > 100_000:
            compressed = gzip.compress(file_content)
            if len(compressed) < len(file_content):
                file_content = compressed
                filename = filename + '.gz'

        # Build form data for train_on_foundational_model endpoint
        form_data = {
            "foundation_model_id": self.id,
            "target_column": target_column,
            "target_column_type": target_type,
            "epochs": str(epochs),
        }
        if name:
            form_data["name"] = name
        if rare_label_value:
            form_data["rare_label_value"] = rare_label_value
        if class_imbalance:
            form_data["class_imbalance"] = json.dumps(class_imbalance)
        if webhooks:
            form_data["webhooks"] = json.dumps(webhooks)
        if allow_null:
            form_data["allow_null"] = "true"
        # Pass through kwargs (session_name_prefix, user_metadata, etc.)
        for key, value in kwargs.items():
            if value is not None:
                if isinstance(value, (dict, list)):
                    form_data[key] = json.dumps(value)
                else:
                    form_data[key] = str(value)

        # Include project_id if set on client
        if self._ctx.current_project_id:
            form_data['project_id'] = self._ctx.current_project_id

        files = {"file": (filename, file_content)}

        response = self._ctx.post_multipart(
            "/compute/train_on_foundational_model",
            data=form_data,
            files=files
        )

        # The server creates a NEW session — use that session_id, not the FM's
        new_session_id = response.get('session_id', self.id)

        predictor_id = response.get('predictor_id', '')
        if not predictor_id:
            raise ValueError(
                f"Server did not return a predictor_id for foundation model {self.id}. "
                f"The predictor may not have been created. Response: {response}"
            )

        return Predictor(
            id=predictor_id,
            session_id=new_session_id,
            target_column=target_column,
            target_type=target_type,
            name=name,
            status="training",
            _ctx=self._ctx,
            _foundational_model=self,
        )

    def create_vector_database(
        self,
        name: str = "default",
        auto_populate: bool = True,
        records: Optional[Union[List[Dict[str, Any]], 'pd.DataFrame']] = None,
    ) -> VectorDatabase:
        """
        Create a named vector database from this foundational model.

        Uses cosine distance (embeddings live on a hypersphere).

        Args:
            name: Database name (default: "default")
            auto_populate: If True, populate with training data (default: True)
            records: Additional records to add after creation (optional)

        Returns:
            VectorDatabase object

        Example:
            # Auto-populated with training data
            vdb = fm.create_vector_database("customers")

            # Empty, fill manually
            vdb = fm.create_vector_database("vip_only", auto_populate=False)
            vdb.add_records(vip_records)

            # Search
            similar = vdb.similarity_search({"age": 35}, k=5)
        """
        response = self._ctx.post_json(
            f"/session/{self.id}/vector_databases",
            data={"name": name, "auto_populate": auto_populate},
        )

        vdb = VectorDatabase.from_api_response(
            data=response,
            session_id=self.id,
            ctx=self._ctx,
            foundational_model=self,
        )

        if records is not None:
            vdb.add_records(records)

        return vdb

    def get_vector_database(self, name: str = "default") -> VectorDatabase:
        """
        Get an existing named vector database.

        Args:
            name: Database name (default: "default")

        Returns:
            VectorDatabase object
        """
        response = self._ctx.get_json(
            f"/session/{self.id}/vector_databases/{name}"
        )
        return VectorDatabase.from_api_response(
            data=response,
            session_id=self.id,
            ctx=self._ctx,
            foundational_model=self,
        )

    def list_vector_databases(self) -> List[VectorDatabase]:
        """
        List all named vector databases for this foundational model.

        Returns:
            List of VectorDatabase objects
        """
        response = self._ctx.get_json(
            f"/session/{self.id}/vector_databases"
        )
        return [
            VectorDatabase.from_api_response(
                data=vdb_data,
                session_id=self.id,
                ctx=self._ctx,
                foundational_model=self,
            )
            for vdb_data in response.get("vector_databases", [])
        ]

    # ------------------------------------------------------------------
    # Vector Views
    # ------------------------------------------------------------------

    def create_vector_view(
        self,
        records: Union[List[Dict[str, Any]], 'pd.DataFrame'],
        target_column: str,
        name: Optional[str] = None,
    ) -> VectorView:
        """
        Create a vector view: encode records through this ES, run linear probe,
        and get an immediate SphereViewer URL.

        This is fast (seconds) — the ES is already trained, encoding is just inference.

        Args:
            records: Records to encode (list of dicts or DataFrame)
            target_column: Column to color by and run probe against
            name: View name (defaults to target_column)

        Returns:
            VectorView with viewer_url, linear_probe results, and metadata

        Example:
            view = fm.create_vector_view(
                records=df.to_dict('records'),
                target_column="credit_risk"
            )
            print(view.viewer_url)          # Open NOW in browser
            print(view.linear_probe_auc)    # Instant baseline
        """
        if hasattr(records, 'to_dict'):
            records = records.to_dict('records')

        payload = {
            "records": records,
            "target_column": target_column,
        }
        if name is not None:
            payload["name"] = name

        response = self._ctx.post_json(
            f"/session/{self.id}/vector_views",
            data=payload,
        )

        return VectorView.from_api_response(
            data=response,
            session_id=self.id,
            ctx=self._ctx,
            foundational_model=self,
        )

    def get_vector_view(self, name: str) -> VectorView:
        """
        Get an existing vector view by name.

        Args:
            name: View name

        Returns:
            VectorView object
        """
        response = self._ctx.get_json(
            f"/session/{self.id}/vector_views/{name}"
        )
        return VectorView.from_api_response(
            data=response,
            session_id=self.id,
            ctx=self._ctx,
            foundational_model=self,
        )

    def list_vector_views(self) -> List[VectorView]:
        """
        List all vector views for this foundational model.

        Returns:
            List of VectorView objects
        """
        response = self._ctx.get_json(
            f"/session/{self.id}/vector_views"
        )
        return [
            VectorView.from_api_response(
                data=vv_data,
                session_id=self.id,
                ctx=self._ctx,
                foundational_model=self,
            )
            for vv_data in response.get("vector_views", [])
        ]

    def ground_truth_stats(self) -> Dict[str, Any]:
        """Get ground truth feedback statistics for this foundational model.

        Returns:
            Dictionary with:
                - total_predictions: Total predictions made
                - total_corrections: Total ground truth labels submitted
                - corrections_since_last_training: Corrections since last SP training
                - last_trained_at: When the predictor was last trained
                - correction_rate: Fraction of predictions that have been corrected
                - ready_for_retraining: Whether enough corrections exist to retrain
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        return self._ctx.get_json(
            f"/compute/session/{self.id}/ground_truth_stats"
        )

    def create_reference_record(
        self,
        record: Dict[str, Any],
        name: Optional[str] = None
    ) -> ReferenceRecord:
        """
        Create a reference record from a specific record for similarity search.

        A reference record is a reference point in the embedding space that you can use
        to find similar records. Particularly useful when you only have a positive
        class but no negative class - just find more records like the positive example.

        Args:
            record: The record to create a reference from
            name: Optional name for the reference record

        Returns:
            ReferenceRecord object that can be used for similarity search

        Example:
            # Create a reference record from a high-value customer
            ref = fm.create_reference_record(
                record={"age": 35, "income": 100000, "plan": "premium"},
                name="high_value_customer"
            )

            # Find similar customers
            similar = ref.find_similar(k=10, vector_database=vdb)
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        return ReferenceRecord.from_record(
            record=record,
            session_id=self.id,
            name=name,
            ctx=self._ctx,
            foundational_model=self,
        )

    def wait_for_training(
        self,
        max_wait_time: int = 3600,
        poll_interval: int = 10,
        show_progress: bool = True
    ) -> 'FoundationalModel':
        """
        Wait for foundational model training to complete with tqdm progress bar.

        The timeout is a *stall detector*, not a wall-clock limit. Training
        can run for days as long as progress is being made (epochs advancing,
        status changing). The timer resets on every sign of progress and only
        fires when the job appears stuck.

        Args:
            max_wait_time: Maximum time in seconds to wait *without progress*
                before raising TimeoutError (default 3600 = 1 hour)
            poll_interval: Polling interval in seconds
            show_progress: Show progress bar (tqdm if available, fallback to simple)

        Returns:
            Self (updated with final status)

        Raises:
            TimeoutError: If no progress is detected for max_wait_time seconds
            RuntimeError: If training fails
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        if not show_progress:
            return self._wait_simple(max_wait_time, poll_interval, show_progress=False)

        # tqdm renders via \r to stderr and effectively goes silent under
        # non-TTY output (e.g. piped through tee). Fall back to _wait_simple
        # so each poll prints a status line that survives logging.
        is_tty = getattr(sys.stdout, 'isatty', lambda: False)() and getattr(sys.stderr, 'isatty', lambda: False)()
        if not is_tty:
            return self._wait_simple(max_wait_time, poll_interval, show_progress=True)

        try:
            from tqdm import tqdm
            return self._wait_with_tqdm(max_wait_time, poll_interval)
        except ImportError:
            return self._wait_simple(max_wait_time, poll_interval, show_progress=True)

    def _wait_with_tqdm(self, max_wait_time: int, poll_interval: int) -> 'FoundationalModel':
        """Wait for training with tqdm progress bar."""
        from tqdm import tqdm

        start_time = time.time()
        last_progress_time = time.time()
        last_gc_time = time.time()
        pbar = None
        last_total = None
        last_epoch = None
        last_job_status = None
        last_queue_position = None
        last_progress_fraction = None

        consecutive_errors = 0
        max_consecutive_errors = 30  # ~5 min at 10s poll interval

        try:
            while True:
                # Stall detection: timeout only when no progress is made
                stall_seconds = time.time() - last_progress_time
                if stall_seconds > max_wait_time:
                    if pbar:
                        pbar.close()
                    elapsed = int(time.time() - start_time)
                    raise TimeoutError(
                        f"Training stalled: no progress for {int(stall_seconds)}s "
                        f"(total elapsed: {elapsed}s). The job may still be running "
                        f"on the server — check status with client.get_foundational_model('{self.id}')"
                    )

                # Get session status — tolerate transient failures
                try:
                    response_data = self._ctx.get_json(f"/compute/session/{self.id}")
                    consecutive_errors = 0
                except Exception as e:
                    consecutive_errors += 1
                    elapsed = int(time.time() - start_time)
                    if pbar:
                        pbar.set_postfix_str(f"poll error {consecutive_errors}/{max_consecutive_errors}")
                    else:
                        print(f"[{elapsed}s] Poll error ({consecutive_errors}/{max_consecutive_errors}): {e}")
                    if consecutive_errors >= max_consecutive_errors:
                        if pbar:
                            pbar.close()
                        raise RuntimeError(
                            f"Training: lost contact with server after "
                            f"{consecutive_errors} consecutive poll failures over "
                            f"{elapsed}s. Last error: {e}"
                        )
                    time.sleep(poll_interval)
                    continue

                # Extract only the scalar values we need, then free the response
                session_data = response_data.get('session', response_data)
                status = session_data.get('status', 'unknown')

                # Queued: job is in the dispatch queue, no compute node yet.
                # Don't open a tqdm bar; just print queue status and keep polling.
                if status == 'queued':
                    queue_position = session_data.get('queue_position')
                    queue_msg = session_data.get('message', 'Waiting for a compute node to become available...')
                    elapsed = int(time.time() - start_time)
                    pos_str = f" (position {queue_position})" if queue_position else ""
                    if queue_position != last_queue_position or last_job_status != 'queued':
                        print(f"[{elapsed}s] 📥 Queued{pos_str} — {queue_msg}")
                        last_progress_time = time.time()
                        last_queue_position = queue_position
                        last_job_status = 'queued'
                    self.status = 'queued'
                    del response_data, session_data
                    time.sleep(poll_interval)
                    continue

                # Find ES training job and extract scalars
                current_epoch = None
                total_epochs = None
                progress_fraction = None
                job_status = status
                latest_fact = ''
                error_msg = None
                completion_data = None

                for job_id, job in response_data.get('jobs', {}).items():
                    if job.get('job_type') in ('train_embedding_space', 'train_es', 'training'):
                        current_epoch = job.get('current_epoch') or job.get('epoch')
                        total_epochs = job.get('total_epochs') or job.get('epochs')
                        progress_fraction = job.get('progress')
                        job_status = job.get('status', status)
                        fun_facts = job.get('fun_facts', [])
                        if fun_facts:
                            latest_fact = fun_facts[-1].get('message', '') if isinstance(fun_facts[-1], dict) else str(fun_facts[-1])
                        if job_status in ('failed', 'error'):
                            error_msg = (
                                job.get('error')
                                or job.get('error_message')
                                or job.get('failure_reason')
                                or 'Unknown error'
                            )
                        break

                # Keep response_data only if training is done (for _update_from_session)
                if job_status == 'done' or status == 'done':
                    completion_data = response_data

                # Free the response dict immediately — don't hold across sleep()
                del response_data, session_data

                # Reset stall timer on any sign of progress (epoch tick, status change,
                # or smooth fraction advancing — the latter ticks per-batch on the server)
                fraction_advanced = (
                    isinstance(progress_fraction, (int, float))
                    and (last_progress_fraction is None or progress_fraction > last_progress_fraction + 1e-6)
                )
                if current_epoch != last_epoch or job_status != last_job_status or fraction_advanced:
                    last_progress_time = time.time()
                    last_epoch = current_epoch
                    last_job_status = job_status
                    if isinstance(progress_fraction, (int, float)):
                        last_progress_fraction = progress_fraction

                # Initialize or update progress bar
                if current_epoch and total_epochs:
                    if pbar is None or last_total != total_epochs:
                        if pbar is not None:
                            pbar.close()
                        pbar = tqdm(
                            total=total_epochs,
                            desc=f"Training {self.name or self.id[:12]}",
                            unit="epoch",
                            ncols=100,
                            bar_format='{desc}: {percentage:6.2f}%|{bar}| {n_fmt}/{total_fmt} epochs [{elapsed}<{remaining}]'
                        )
                        last_total = total_epochs

                    # Prefer the smooth 0..1 progress fraction the server writes per-batch;
                    # falls back to integer epoch when the field is missing (older servers).
                    if isinstance(progress_fraction, (int, float)) and 0.0 <= progress_fraction <= 1.0:
                        target_n = float(progress_fraction) * total_epochs
                    else:
                        target_n = float(current_epoch)
                    if target_n > pbar.n:
                        pbar.update(target_n - pbar.n)
                        pbar.set_postfix_str(latest_fact or job_status)

                # Check completion
                if completion_data is not None:
                    if pbar:
                        pbar.n = pbar.total
                        pbar.refresh()
                        pbar.close()

                    self.status = 'done'
                    self._update_from_session(completion_data)
                    del completion_data
                    print(f"\n✅ Training complete!")
                    if self.dimensions:
                        print(f"   Dimensions: {self.dimensions}")
                    if self.epochs:
                        print(f"   Epochs: {self.epochs}")
                    return self

                elif job_status == 'failed' or status == 'failed':
                    if pbar:
                        pbar.close()
                    self.status = 'error'
                    raise RuntimeError(f"Training failed: {error_msg}")

                # Periodic gc to combat pymalloc arena fragmentation
                now = time.time()
                if now - last_gc_time > 60:
                    gc.collect()
                    last_gc_time = now

                time.sleep(poll_interval)

        except KeyboardInterrupt:
            if pbar:
                pbar.close()
            print("\n⚠️  Training interrupted by user")
            raise

    def _wait_simple(self, max_wait_time: int, poll_interval: int, show_progress: bool) -> 'FoundationalModel':
        """Simple progress display without external dependencies."""
        start_time = time.time()
        last_progress_time = time.time()
        last_gc_time = time.time()
        last_epoch = None
        last_status = None
        last_fact = None
        last_queue_position = None
        last_progress_fraction = None
        last_printed_fraction = None
        consecutive_errors = 0
        max_consecutive_errors = 30  # ~5 min at 10s poll interval

        while True:
            # Stall detection: timeout only when no progress is made
            stall_seconds = time.time() - last_progress_time
            if stall_seconds > max_wait_time:
                elapsed = int(time.time() - start_time)
                raise TimeoutError(
                    f"Training stalled: no progress for {int(stall_seconds)}s "
                    f"(total elapsed: {elapsed}s). The job may still be running "
                    f"on the server — check status with client.get_foundational_model('{self.id}')"
                )

            # Get session status — tolerate transient failures
            try:
                response_data = self._ctx.get_json(f"/compute/session/{self.id}")
                consecutive_errors = 0
            except Exception as e:
                consecutive_errors += 1
                elapsed = int(time.time() - start_time)
                if show_progress:
                    print(f"[{elapsed}s] Poll error ({consecutive_errors}/{max_consecutive_errors}): {e}")
                if consecutive_errors >= max_consecutive_errors:
                    raise RuntimeError(
                        f"Training: lost contact with server after "
                        f"{consecutive_errors} consecutive poll failures over "
                        f"{elapsed}s. Last error: {e}"
                    )
                time.sleep(poll_interval)
                continue

            # Extract only scalar values we need, then free the response
            session_data = response_data.get('session', response_data)
            status = session_data.get('status', 'unknown')

            # Queued: job is sitting in the dispatch queue. Print queue status
            # and keep polling until a compute node picks it up.
            if status == 'queued':
                queue_position = session_data.get('queue_position')
                queue_msg = session_data.get('message', 'Waiting for a compute node to become available...')
                if queue_position != last_queue_position or last_status != 'queued':
                    last_progress_time = time.time()
                    last_queue_position = queue_position
                    last_status = 'queued'
                    if show_progress:
                        elapsed = int(time.time() - start_time)
                        pos_str = f" (position {queue_position})" if queue_position else ""
                        print(f"[{elapsed}s] 📥 Queued{pos_str} — {queue_msg}")
                self.status = 'queued'
                del response_data, session_data
                time.sleep(poll_interval)
                continue

            current_epoch = None
            total_epochs = None
            progress_fraction = None
            job_status = status
            latest_fact = None
            error_msg = None
            completion_data = None

            for job_id, job in response_data.get('jobs', {}).items():
                if job.get('job_type') in ('train_embedding_space', 'train_es', 'training'):
                    current_epoch = job.get('current_epoch') or job.get('epoch')
                    total_epochs = job.get('total_epochs') or job.get('epochs')
                    progress_fraction = job.get('progress')
                    job_status = job.get('status', status)
                    fun_facts = job.get('fun_facts', [])
                    if fun_facts:
                        latest_fact = fun_facts[-1].get('message', '') if isinstance(fun_facts[-1], dict) else str(fun_facts[-1])
                    if job_status in ('failed', 'error'):
                        error_msg = (
                            job.get('error')
                            or job.get('error_message')
                            or job.get('failure_reason')
                            or 'Unknown error'
                        )
                    break

            # Keep response_data only if training is done (for _update_from_session)
            if job_status == 'done' or status == 'done':
                completion_data = response_data

            # Free the response dict immediately — don't hold across sleep()
            del response_data, session_data

            # Reset stall timer on any sign of progress (epoch tick, status change,
            # or smooth fraction advancing — the latter ticks per-batch on the server)
            fraction_advanced = (
                isinstance(progress_fraction, (int, float))
                and (last_progress_fraction is None or progress_fraction > last_progress_fraction + 1e-6)
            )
            if current_epoch != last_epoch or job_status != last_status or fraction_advanced:
                last_progress_time = time.time()
                if isinstance(progress_fraction, (int, float)):
                    last_progress_fraction = progress_fraction

            # Progress update — print on epoch/status changes OR on ≥1% smooth advance
            if show_progress:
                elapsed = int(time.time() - start_time)
                state_changed = current_epoch != last_epoch or job_status != last_status
                smooth_changed = (
                    isinstance(progress_fraction, (int, float))
                    and (last_printed_fraction is None or progress_fraction - last_printed_fraction >= 0.01)
                )
                if state_changed or smooth_changed:
                    if isinstance(progress_fraction, (int, float)) and 0.0 <= progress_fraction <= 1.0:
                        pct = int(progress_fraction * 100)
                    elif current_epoch and total_epochs:
                        pct = int(current_epoch / total_epochs * 100)
                    else:
                        pct = None
                    if pct is not None and current_epoch and total_epochs:
                        bar = "█" * (pct // 5) + "░" * (20 - pct // 5)
                        print(f"[{elapsed}s] [{bar}] {current_epoch}/{total_epochs} epochs ({pct}%) - {job_status}")
                    else:
                        print(f"[{elapsed}s] Training: {job_status}")
                    if isinstance(progress_fraction, (int, float)):
                        last_printed_fraction = progress_fraction
                if latest_fact and latest_fact != last_fact:
                    print(f"   {latest_fact}")
                    last_fact = latest_fact

            # Track progress (always, even when not showing)
            last_epoch = current_epoch
            last_status = job_status

            # Check completion
            if completion_data is not None:
                self.status = 'done'
                self._update_from_session(completion_data)
                del completion_data
                if show_progress:
                    print(f"✅ Training complete!")
                    if self.dimensions:
                        print(f"   Dimensions: {self.dimensions}")
                    if self.epochs:
                        print(f"   Epochs: {self.epochs}")
                return self

            elif job_status == 'failed' or status == 'failed':
                self.status = 'error'
                raise RuntimeError(f"Training failed: {error_msg}")

            # Periodic gc to combat pymalloc arena fragmentation
            now = time.time()
            if now - last_gc_time > 60:
                gc.collect()
                last_gc_time = now

            time.sleep(poll_interval)

    def encode(
        self,
        records: Union[Dict[str, Any], List[Dict[str, Any]], 'pd.DataFrame'],
        short: bool = False,
        *,
        intent: Optional[str] = None,
        representation: str = "auto",
    ) -> Union[List[Dict[str, Any]], List[List[float]]]:
        """
        Encode records to embedding vectors.

        Args:
            records: Single record, list of records, or DataFrame
            short: Deprecated. If True, return only 3D vectors. Use
                   intent='visualization' instead.
            intent: Customer-facing intent — one of 'clustering' (kNN /
                   similarity, default for external tools), 'visualization'
                   (2D/3D plots), 'near_lossless' (per-column fidelity,
                   good for downstream tree/linear models), 'highly_encoded'
                   (dense pooled representation). Task intents ('regression',
                   'binary_class', 'multiclass', 'multilabel') require a
                   trained Single Predictor — use Predictor.encode() with
                   intent= instead. When given, returns a single 'embedding'
                   field per record in the resolved port's shape.
            representation: 'auto' (default), 'preserved' (per-column),
                   or 'compressed' (dense pooled). Ignored unless intent
                   is given.

        Returns:
            intent=None (legacy): List of dicts with short+full embeddings,
                OR a list of 3D vectors if short=True.
            intent given: List of dicts with 'embedding' + 'intent' +
                'representation' + 'query_record' + 'port_spec' fields.
                ``port_spec`` describes the embedding the server actually
                produced — ``{name, width, encoding_depth, representation,
                available}`` — so the caller can introspect what they got.

        Example:
            vectors_for_kmeans = fm.encode(records, intent='clustering')
            vectors_for_plot = fm.encode(records, intent='visualization')
            per_col = fm.encode(records, intent='near_lossless')

            # Inspect what the server returned:
            r = fm.encode(records, intent='near_lossless')[0]
            r['port_spec']['name']             # → 'pre_transformer'
            r['port_spec']['width']            # → e.g. 1152
            r['port_spec']['encoding_depth']   # → 'near_lossless'
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        # Normalize input
        if isinstance(records, dict):
            records = [records]
        elif hasattr(records, 'to_dict'):
            records = records.to_dict('records')

        # Clean records
        cleaned = [self._clean_record(r) for r in records]

        body: Dict[str, Any] = {"records": cleaned}
        if intent is not None:
            body["intent"] = intent
            body["representation"] = representation

        response = self._ctx.post_json(
            f"/session/{self.id}/encode_records",
            data=body,
        )

        results = response.get('results', [])

        if short and intent is None:
            return [r["embedding"] for r in results]

        return results

    # ------------------------------------------------------------------
    # Imputation (Gibbs-style fill-in-the-blanks)
    # ------------------------------------------------------------------

    def impute(
        self,
        records: Union[Dict[str, Any], List[Dict[str, Any]], 'pd.DataFrame'],
        columns: Optional[List[str]] = None,
        strategy: str = "greedy",
    ) -> Union[Dict[str, Any], List[Dict[str, Any]]]:
        """Impute missing/null fields in partial records using Gibbs-style probe ensemble.

        Predicts the most-confident missing column first, feeds that prediction
        back into the ES for better context, then predicts the next column, and so on.

        Args:
            records: Single record, list of records, or DataFrame.
                     Missing fields should be None or absent.
            columns: Specific columns to impute. Default: all missing probeable columns.
            strategy: "greedy" (sequential, higher quality) or "parallel" (all-at-once).

        Returns:
            Single result dict or list of result dicts, each containing:
            - "record": The complete record with all fields filled
            - "imputed_fields": Dict mapping column -> {value, confidence, cascade_factor,
              effective_confidence, iteration, target_type, probabilities}
            - "skipped_columns": Columns that couldn't be imputed and why
            - "strategy": Which strategy was used
            - "n_iterations": How many Gibbs iterations were run

        Example:
            result = fm.impute({"age": 35, "income": None, "job": None})
            print(result["record"])           # {"age": 35, "income": 52000, "job": "engineer"}
            print(result["imputed_fields"])   # {"income": {"value": 52000, ...}, ...}
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        single = isinstance(records, dict)
        if single:
            records = [records]
        elif hasattr(records, 'to_dict'):
            records = records.to_dict('records')

        cleaned = [self._clean_record(r) for r in records]

        payload = {"records": cleaned, "strategy": strategy}
        if columns is not None:
            payload["columns"] = columns

        response = self._ctx.post_json(
            f"/session/{self.id}/impute",
            data=payload,
        )

        results = response.get("results", [])
        return results[0] if single else results

    def autocomplete_record(
        self,
        records: Union[Dict[str, Any], List[Dict[str, Any]], 'pd.DataFrame'],
        method: str = "beam",
        top_k: int = 1,
        columns: Optional[List[str]] = None,
        beam_width: int = 32,
        top_k_columns: int = 3,
        top_k_values: int = 5,
        score_fn: str = "log_sum",
    ) -> Union[Dict[str, Any], List[Dict[str, Any]]]:
        """Autocomplete missing fields, returning ranked completions instead of a single guess.

        Unlike `impute()`, which returns a single point estimate, this returns a
        ranked list of plausible completions plus per-column divergence — the
        honest output when a partial record admits multiple plausible fills.

        Args:
            records: Single record dict, list of dicts, or DataFrame. Missing
                fields should be None or absent from the dict.
            method: "parallel", "greedy", or "beam" (default). beam runs a
                batched beam search over (column, value) fill-in orders.
            top_k: Number of ranked completions to return per record (beam only;
                parallel/greedy always return 1).
            columns: Optional filter — only impute these columns.
            beam_width: Max live beams per iteration (beam only).
            top_k_columns: Branch on top-J columns by probe confidence (beam only).
            top_k_values: Branch on top-K values per column (beam only;
                classification only — regression currently uses K=1).
            score_fn: "log_sum" (default), "min", or "length_norm".

        Returns:
            For a single record input: a dict with keys:
              - "completions": list of {record, imputed_fields, score, min_confidence, n_iterations}
              - "divergence": per-column {entropy, modes, n_unique} across completions
              - "method", "top_k", "n_iterations", ...
            For a list/DataFrame input: a list of such dicts (one per record).

        Example:
            result = fm.autocomplete_record(
                {"age": 35, "income": None, "job": None},
                method="beam", top_k=10,
            )
            for c in result["completions"]:
                print(c["score"], c["record"])
            print(result["divergence"])  # which columns the model is uncertain about
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")
        if method not in ("parallel", "greedy", "beam"):
            raise ValueError(
                f"Invalid method: {method!r}. Must be 'parallel', 'greedy', or 'beam'."
            )

        single = isinstance(records, dict)
        if single:
            records = [records]
        elif hasattr(records, 'to_dict'):
            records = records.to_dict('records')

        cleaned = [self._clean_record(r) for r in records]

        payload: Dict[str, Any] = {
            "records": cleaned,
            "method": method,
            "top_k": top_k,
            "beam_width": beam_width,
            "top_k_columns": top_k_columns,
            "top_k_values": top_k_values,
            "score_fn": score_fn,
        }
        if columns is not None:
            payload["columns"] = columns

        response = self._ctx.post_json(
            f"/session/{self.id}/autocomplete_record",
            data=payload,
        )

        results = response.get("results", [])
        return results[0] if single else results

    # ------------------------------------------------------------------
    # ES Instant Prediction (probe-based ensemble)
    # ------------------------------------------------------------------

    def predict_linear(
        self,
        target_column: str,
        records: Union[Dict[str, Any], List[Dict[str, Any]], 'pd.DataFrame'],
    ) -> List[Dict[str, Any]]:
        """Instant prediction using linear probe on frozen embeddings.

        Uses LogisticRegression for classification, Ridge for regression.
        No neural SP training required — fits on first call, cached after.

        Args:
            target_column: Column to predict
            records: Single record, list of records, or DataFrame

        Returns:
            List of prediction dicts with prediction, confidence, probabilities, model.
        """
        return self._es_predict(target_column=target_column, records=records, model="linear")

    def predict_xgboost(
        self,
        target_column: str,
        records: Union[Dict[str, Any], List[Dict[str, Any]], 'pd.DataFrame'],
    ) -> List[Dict[str, Any]]:
        """Instant prediction using XGBoost probe on frozen embeddings.

        Args:
            target_column: Column to predict
            records: Single record, list of records, or DataFrame

        Returns:
            List of prediction dicts with prediction, confidence, probabilities, model.
        """
        return self._es_predict(target_column=target_column, records=records, model="xgboost")

    def predict_knn(
        self,
        target_column: str,
        records: Union[Dict[str, Any], List[Dict[str, Any]], 'pd.DataFrame'],
    ) -> List[Dict[str, Any]]:
        """Instant prediction using k-NN probe on frozen embeddings.

        Args:
            target_column: Column to predict
            records: Single record, list of records, or DataFrame

        Returns:
            List of prediction dicts with prediction, confidence, probabilities, model.
        """
        return self._es_predict(target_column=target_column, records=records, model="knn")

    def predict_random_forest(
        self,
        target_column: str,
        records: Union[Dict[str, Any], List[Dict[str, Any]], 'pd.DataFrame'],
    ) -> List[Dict[str, Any]]:
        """Instant prediction using Random Forest probe on frozen embeddings.

        Args:
            target_column: Column to predict
            records: Single record, list of records, or DataFrame

        Returns:
            List of prediction dicts with prediction, confidence, probabilities, model.
        """
        return self._es_predict(target_column=target_column, records=records, model="random_forest")

    def predict(
        self,
        target_column: str,
        records: Union[Dict[str, Any], List[Dict[str, Any]], 'pd.DataFrame'],
        model: str = "xgboost",
        model_type: Optional[str] = None,
        predictor_id: Optional[str] = None,
    ) -> Union[PredictionResult, List[PredictionResult]]:
        """Predict any column using the foundation model.

        Routing logic:
        - If model_type="sp" or predictor_id is given, forces SP prediction.
        - If model_type="foundation" (or "foundation+xgboost", etc.), forces
          foundation model prediction even if an SP exists.
        - If neither is given (default): uses the SP if one is trained for
          this target column, otherwise falls back to the foundation model.

        Returns full PredictionResult objects with prediction_uuid, model_type,
        confidence, probabilities — the same result shape either way.

        Args:
            target_column: Column to predict
            records: Single record, list of records, or DataFrame
            model: Foundation model to use — "xgboost" (default), "linear",
                   "knn", "random_forest", or "ensemble".
                   Only used for foundation predictions.
            model_type: Force a specific prediction path:
                   "sp" — use trained SinglePredictor (error if none exists)
                   "foundation" — use foundation model (skip SP even if available)
                   None (default) — auto-route: SP if available, else foundation
            predictor_id: Use a specific SP by ID (implies model_type="sp")

        Returns:
            Single PredictionResult if input was a single dict,
            list of PredictionResult if input was a list or DataFrame.

        Example:
            # Auto-route (SP if available, else foundation)
            result = fm.predict("churned", {"age": 35, "income": 50000})

            # Force foundation model
            result = fm.predict("churned", record, model_type="foundation")

            # Force SP
            result = fm.predict("churned", record, model_type="sp")

            # Check what was used
            print(result.model_type)  # "foundation+xgboost" or "sp"
        """
        # Explicit SP request
        use_sp = (
            model_type == "sp"
            or predictor_id is not None
        )
        # Explicit foundation request
        use_foundation = (
            model_type is not None
            and model_type.startswith("foundation")
        )

        if use_sp:
            sp = self._find_predictor(target_column, predictor_id=predictor_id)
            if sp is None:
                raise ValueError(
                    f"No trained SinglePredictor found for target_column='{target_column}'"
                    + (f", predictor_id='{predictor_id}'" if predictor_id else "")
                )
            single_input = isinstance(records, dict)
            if single_input:
                return sp.predict(records)
            return sp.batch_predict(records, show_progress=False)

        if use_foundation:
            # Parse model from model_type if given as "foundation+xgboost"
            if "+" in model_type:
                model = model_type.split("+", 1)[1]
            return self.foundation_predict(
                target_column=target_column, records=records, model=model,
            )

        # Auto-route: SP if available, else foundation
        sp = self._find_predictor(target_column)
        if sp is not None:
            single_input = isinstance(records, dict)
            if single_input:
                return sp.predict(records)
            return sp.batch_predict(records, show_progress=False)

        return self.foundation_predict(
            target_column=target_column, records=records, model=model,
        )

    def _find_predictor(
        self,
        target_column: str,
        predictor_id: Optional[str] = None,
    ) -> Optional[Predictor]:
        """Find a trained SP for the given target column (and optional ID), or None."""
        try:
            predictors = self.list_predictors()
            for p in predictors:
                if predictor_id and p.id != predictor_id:
                    continue
                if p.target_column == target_column and p.status == 'done':
                    return p
        except Exception:
            pass
        return None

    def _es_predict(
        self,
        target_column: str,
        records: Union[Dict[str, Any], List[Dict[str, Any]], 'pd.DataFrame'],
        model: str,
    ) -> List[Dict[str, Any]]:
        """Internal: ES probe-based prediction via compute node API."""
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        # Normalize input
        if isinstance(records, dict):
            records = [records]
        elif hasattr(records, 'to_dict'):
            records = records.to_dict('records')

        # Clean records
        cleaned = [self._clean_record(r) for r in records]

        response = self._ctx.post_json(
            f"/compute/session/{self.id}/es_predict",
            data={
                "target_column": target_column,
                "records": cleaned,
                "model": model,
            },
        )

        return response.get('predictions', [])

    def foundation_predict(
        self,
        target_column: str,
        records: Union[Dict[str, Any], List[Dict[str, Any]], 'pd.DataFrame'],
        model: str = "xgboost",
    ) -> Union[PredictionResult, List[PredictionResult]]:
        """Predict any column using the foundation model.

        Returns full PredictionResult objects with prediction_uuid for feedback
        loops, model_type identification, and all standard fields.

        If no SinglePredictor has been trained, this is the fastest way to get
        predictions from a foundation model.

        Args:
            target_column: Column to predict
            records: Single record, list of records, or DataFrame
            model: Model to use — "xgboost" (default), "linear",
                   "knn", "random_forest", or "ensemble"

        Returns:
            Single PredictionResult if input was a single dict,
            list of PredictionResult if input was a list or DataFrame.

        Example:
            result = fm.foundation_predict("churned", {"age": 35, "income": 50000})
            print(result.predicted_class)   # "yes"
            print(result.confidence)        # 0.82
            print(result.model_type)        # "foundation+xgboost"
            print(result.prediction_uuid)   # UUID for feedback

            # Batch
            results = fm.foundation_predict("churned", [{"age": 35}, {"age": 42}])
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        single_input = isinstance(records, dict)

        # Normalize input
        if single_input:
            records = [records]
        elif hasattr(records, 'to_dict'):
            records = records.to_dict('records')

        cleaned = [self._clean_record(r) for r in records]

        response = self._ctx.post_json(
            f"/compute/session/{self.id}/es_predict",
            data={
                "target_column": target_column,
                "records": cleaned,
                "model": model,
            },
        )

        results = []
        for i, pred in enumerate(response.get('predictions', [])):
            query_record = cleaned[i] if i < len(cleaned) else {}
            result = PredictionResult.from_response(pred, query_record, self._ctx)
            # Ensure model_type is set even if backend didn't include it
            if not result.model_type:
                result.model_type = f"foundation+{model}"
            results.append(result)

        if single_input:
            return results[0] if results else PredictionResult(
                model_type=f"foundation+{model}",
                target_column=target_column,
            )
        return results

    def extend(
        self,
        new_data_file: Optional[str] = None,
        new_data_df: Optional['pd.DataFrame'] = None,
        epochs: Optional[int] = None,
        **kwargs
    ) -> 'FoundationalModel':
        """
        Extend this foundational model with new data.

        Args:
            new_data_file: Path to new data file
            new_data_df: DataFrame with new data
            epochs: Additional training epochs
            **kwargs: Additional parameters

        Returns:
            New FoundationalModel instance (training started)
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        # This creates a new session with extended data
        # Implementation depends on server API
        raise NotImplementedError("extend() not yet implemented - use create_foundational_model with new data")

    def get_projections(self, limit: int = None, offset: int = 0) -> Dict[str, Any]:
        """Get 2D/3D projections for visualization.

        Args:
            limit: Max number of points to return. If None, returns all points.
            offset: Number of points to skip (for pagination).

        Returns:
            Dict with 'projections' key containing coords, total_count, offset, limit.
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        params = {}
        if limit is not None:
            params["limit"] = limit
        if offset:
            params["offset"] = offset
        return self._ctx.get_json(f"/session/{self.id}/projections", params=params or None)

    def get_epoch_projections(
        self,
        epoch: str = None,
        start_epoch: int = None,
        limit: int = None,
        point_limit: int = None,
        point_offset: int = 0,
        metadata_only: bool = False,
        include_source_data: bool = False,
    ) -> Dict[str, Any]:
        """Get epoch projection data for training movie visualization.

        Args:
            epoch: Single epoch to return ('last' or a number). Most efficient for thumbnails.
            start_epoch: Start epoch (1-indexed). If not specified, returns all epochs.
            limit: Max number of epochs to return.
            point_limit: Max number of points per epoch to return (for incremental loading).
            point_offset: Number of points to skip per epoch (for pagination).
            metadata_only: If True, only return metadata (epoch count, etc).
            include_source_data: If True, enrich coords with original dataset columns.

        Returns:
            Dict with 'epoch_projections' key. Each epoch contains coords with
            total_count, offset, limit when point pagination is used.
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        params = {}
        if epoch is not None:
            params["epoch"] = epoch
        if start_epoch is not None:
            params["start_epoch"] = start_epoch
        if limit is not None:
            params["limit"] = limit
        if point_limit is not None:
            params["point_limit"] = point_limit
        if point_offset:
            params["point_offset"] = point_offset
        if metadata_only:
            params["metadata_only"] = "true"
        if include_source_data:
            params["include_source_data"] = "true"
        return self._ctx.get_json(f"/session/{self.id}/epoch_projections", params=params or None)

    def get_sphere_preview(self, save_path: str = None) -> bytes:
        """
        Get the 2D sphere projection preview image (PNG).

        Args:
            save_path: Optional path to save the PNG file. If provided, the image
                      will be written to this path.

        Returns:
            Raw PNG image bytes.
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        png_bytes = self._ctx.get_bytes(f"/session/{self.id}/preview")

        if save_path:
            with open(save_path, 'wb') as f:
                f.write(png_bytes)

        return png_bytes

    def get_training_metrics(self) -> Dict[str, Any]:
        """Get training metrics and history."""
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        return self._ctx.get_json(f"/session/{self.id}/training_metrics")

    def get_model_card(self) -> Dict[str, Any]:
        """Get the model card for this foundational model."""
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        return self._ctx.get_json(f"/session/{self.id}/model_card")

    def list_predictors(self) -> List[Predictor]:
        """List all predictors for this foundational model."""
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        # Get session info which includes jobs
        response = self._ctx.get_json(f"/compute/session/{self.id}")
        jobs = response.get('jobs', {})

        predictors = []
        for job_id, job in jobs.items():
            if job.get('job_type') == 'train_single_predictor':
                target_column = job.get('target_column', '')
                pred_id = job.get('predictor_id', f"predictor-{target_column}")

                pred = Predictor(
                    id=pred_id,
                    session_id=self.id,
                    target_column=target_column,
                    target_type=job.get('target_column_type', 'set'),
                    name=job.get('name'),
                    status=job.get('status'),
                    accuracy=job.get('accuracy'),
                    _ctx=self._ctx,
                    _foundational_model=self,
                )
                predictors.append(pred)

        return predictors

    def refresh(self) -> Dict[str, Any]:
        """Re-fetch status from the server and update this object's fields.

        Returns:
            The raw session response dict.
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        response_data = self._ctx.get_json(f"/compute/session/{self.id}")
        self._update_from_session(response_data)
        return response_data

    def is_ready(self) -> bool:
        """Check if training is complete by refreshing status from the server.

        Returns:
            True if status is "done", False otherwise.
        """
        self.refresh()
        return self.status == "done"

    def _update_from_session(self, response_data: Dict[str, Any]) -> None:
        """Update fields from session API response.

        The response from GET /session/{id} has structure:
            {"session": {...}, "jobs": {...}, ...}
        """
        # Handle both nested and flat response formats
        session = response_data.get('session', response_data)
        jobs = response_data.get('jobs', {})
        self.jobs = jobs

        # Core session fields
        if session.get('name') and not self.name:
            self.name = session['name']
        if session.get('status'):
            self.status = session['status']
        if session.get('session_type'):
            self.session_type = session['session_type']
        if session.get('compute_cluster'):
            self.compute_cluster = session['compute_cluster']
        if session.get('created_at') and not self.created_at:
            self.created_at = _parse_datetime(session['created_at'])
        if session.get('finished_at'):
            self.updated_at = _parse_datetime(session['finished_at'])
        elif session.get('started_at'):
            self.updated_at = _parse_datetime(session['started_at'])

        # Model info from session
        model_info = session.get('model_info', {})
        training_stats = session.get('training_stats', {})

        self.dimensions = (
            model_info.get('d_model') or
            model_info.get('embedding_dim') or
            session.get('d_model')
        )
        self.epochs = (
            training_stats.get('final_epoch') or
            training_stats.get('epochs_trained') or
            session.get('epochs')
        )
        self.final_loss = (
            training_stats.get('final_loss') or
            session.get('final_loss')
        )

        # Extract error_message and training_progress from jobs
        for job_id, job in jobs.items():
            job_type = job.get('job_type', '')
            job_status = job.get('status', '')

            # Training progress from ES training job
            if job_type in ('train_embedding_space', 'train_es', 'training'):
                current_epoch = job.get('current_epoch') or job.get('epoch')
                total_epochs = job.get('total_epochs') or job.get('epochs')
                if current_epoch or total_epochs:
                    self.training_progress = {
                        'current_epoch': current_epoch,
                        'total_epochs': total_epochs,
                        'job_status': job_status,
                        'fun_facts': job.get('fun_facts', []),
                    }

            # Error message from any failed job
            if job_status in ('failed', 'error'):
                err = job.get('error') or job.get('error_message') or job.get('failure_reason')
                if err:
                    self.error_message = err

    def _clean_record(self, record: Dict[str, Any]) -> Dict[str, Any]:
        """Clean a record for API submission."""
        import math

        cleaned = {}
        for key, value in record.items():
            if isinstance(value, float):
                if math.isnan(value) or math.isinf(value):
                    value = None
            if hasattr(value, 'item'):
                value = value.item()
            cleaned[key] = value
        return cleaned

    def get_columns(self) -> List[str]:
        """
        Get the column names in this foundational model's embedding space.

        Returns:
            List of column name strings

        Example:
            columns = fm.get_columns()
            print(columns)  # ['age', 'income', 'city', ...]
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        response = self._ctx.get_json(f"/compute/session/{self.id}/columns")
        return response.get('column_names', response.get('columns', []))

    @property
    def columns(self) -> List[str]:
        """Column names in this foundational model's embedding space."""
        return self.get_columns()

    @property
    def schema_metadata(self) -> Dict[str, Any]:
        """Get schema metadata including column names and types.

        Returns:
            Dict with 'column_names', 'column_types', and 'num_columns'
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")
        return self._ctx.get_json(f"/compute/session/{self.id}/columns")

    def clone(
        self,
        target_compute_cluster: Optional[str] = None,
        new_name: Optional[str] = None,
        source_compute_cluster: Optional[str] = None,
    ) -> 'FoundationalModel':
        """
        Clone this embedding space, optionally to a different compute node.

        Args:
            target_compute_cluster: Target compute cluster (None = same node)
            new_name: Name for the cloned session
            source_compute_cluster: Source compute cluster (if routing needed)

        Returns:
            New FoundationalModel instance for the cloned embedding space

        Example:
            cloned = fm.clone(
                target_compute_cluster="churro",
                new_name="my-model-clone"
            )
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        data = {
            "to_compute": target_compute_cluster,
            "new_session_name": new_name,
        }

        response = self._ctx.post_json(
            f"/compute/session/{self.id}/clone_embedding_space",
            data=data
        )

        new_session_id = response.get('new_session_id', '')
        return FoundationalModel(
            id=new_session_id,
            name=new_name,
            status="done",
            created_at=datetime.now(),
            _ctx=self._ctx,
        )

    def refresh(self) -> Dict[str, Any]:
        """
        Refresh this foundational model's state from the server.

        Returns the full server-side info for this model, and updates
        local attributes (status, epochs, dimensions, etc.).

        Returns:
            Full model info dictionary from the server

        Example:
            info = fm.refresh()
            print(fm.status)   # Updated from server
            print(fm.epochs)   # Updated from server
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        data = self._ctx.get_json(f"/compute/session/{self.id}")
        self._update_from_session(data)
        return data

    def is_ready(self) -> bool:
        """
        Check if this foundational model has finished training and is ready for use.

        Returns:
            True if training is complete, False otherwise

        Example:
            if fm.is_ready():
                predictor = fm.create_binary_classifier(target_column="target")
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        data = self._ctx.get_json(f"/compute/session/{self.id}")
        self._update_from_session(data)
        return self.status == 'done'

    def publish(
        self,
        name: Optional[str] = None,
        max_wait_time: int = 600,
        poll_interval: int = 5,
    ) -> Dict[str, Any]:
        """
        Publish this foundational model to the production directory and cloud storage.

        Published models are protected from garbage collection and available
        across all compute nodes via the shared backplane. The model is also
        backed up to cloud storage (DO Spaces).

        The model is published under your organization (derived from your API key).
        This dispatches a background job and polls until complete.

        Args:
            name: Name for the published model (defaults to self.name)
            max_wait_time: Max seconds to wait for publish to complete (default 600)
            poll_interval: Seconds between status polls (default 5)

        Returns:
            dict with published_path, cloud_upload status, etc.

        Example:
            fm = featrix.create_foundational_model(name="my_model", data_file="data.csv")
            fm.wait_for_training()
            fm.publish(name="my_model_v1")
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        publish_name = name or self.name
        if not publish_name:
            raise ValueError("name is required (either pass it or set it on the model)")

        data = {
            "name": publish_name,
        }
        response = self._ctx.post_json(f"/compute/session/{self.id}/publish", data=data)

        # If already published, return immediately
        if response.get("status") == "already_published":
            return response

        # If the server returned a job_id, poll for completion
        job_id = response.get("job_id")
        if not job_id:
            # Old-style synchronous response (backwards compat)
            return response

        logger.info(f"Publishing model as '{publish_name}'... (job_id: {job_id})")

        start_time = time.time()
        last_message = None

        while time.time() - start_time < max_wait_time:
            time.sleep(poll_interval)

            status_response = self._ctx.get_json(
                f"/compute/session/{self.id}/publish_job/{job_id}"
            )
            status = status_response.get("status")
            message = status_response.get("message", "")

            # Show progress with ETA if available
            pct = status_response.get("progress_pct")
            eta = status_response.get("eta_minutes")
            if pct is not None:
                eta_str = f", ~{eta:.0f} min remaining" if eta and eta > 0.1 else ""
                progress_msg = f"  {message}{eta_str}"
            else:
                progress_msg = f"  {message}" if message else None

            if progress_msg and progress_msg != last_message:
                logger.info(progress_msg)
                last_message = progress_msg

            if status == "completed":
                logger.info(f"Published successfully: {status_response.get('published_path')}")
                return status_response

            elif status == "failed":
                error = status_response.get("error", "Unknown error")
                raise RuntimeError(f"Publish failed: {error}")

        raise TimeoutError(
            f"Publish did not complete within {max_wait_time}s (job_id: {job_id}). "
            f"The job may still be running — check status at /session/{self.id}/publish_job/{job_id}"
        )

    def deprecate(
        self,
        warning_message: str,
        expiration_date: str,
    ) -> Dict[str, Any]:
        """
        Deprecate this published model with a warning and expiration date.

        The model remains available until the expiration date. Prediction
        responses will include a model_expiration field warning consumers.

        Args:
            warning_message: Warning message to display
            expiration_date: ISO format date string (e.g., "2026-06-01T00:00:00Z")

        Returns:
            dict with deprecation status

        Example:
            from datetime import datetime, timedelta
            expiration = (datetime.now() + timedelta(days=90)).isoformat() + "Z"
            fm.deprecate(
                warning_message="Replaced by v2. Migrate by expiration.",
                expiration_date=expiration
            )
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        data = {
            "warning_message": warning_message,
            "expiration_date": expiration_date,
        }
        return self._ctx.post_json(f"/compute/session/{self.id}/deprecate", data=data)

    def unpublish(self) -> Dict[str, Any]:
        """
        Unpublish this model, moving it back from the published directory.

        WARNING: After unpublishing, the model is subject to garbage
        collection and may be deleted when disk space is low.

        Returns:
            dict with unpublish status

        Example:
            fm.unpublish()
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        return self._ctx.post_json(f"/compute/session/{self.id}/unpublish", data={})

    def delete(self) -> Dict[str, Any]:
        """
        Mark this model for deletion.

        The session will be picked up by the garbage collection process
        and deleted from the compute node.

        Returns:
            dict with deletion confirmation

        Example:
            fm.delete()
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        return self._ctx.post_json(f"/compute/session/{self.id}/mark_for_deletion", data={})

    def publish_checkpoint(
        self,
        name: str,
        org_id: Optional[str] = None,
        checkpoint_epoch: Optional[int] = None,
        session_name_prefix: Optional[str] = None,
        publish: bool = True,
    ) -> 'FoundationalModel':
        """
        Publish a checkpoint from this model's training as a new foundation model.

        Creates a NEW FoundationalModel from a training checkpoint with full
        provenance tracking. Useful for snapshotting good intermediate models
        while training continues.

        Args:
            name: Name for the new foundation model (required)
            org_id: Organization ID (required if publish=True)
            checkpoint_epoch: Which epoch checkpoint to use (None = best/latest)
            session_name_prefix: Optional prefix for the new session ID
            publish: Move to published directory (default: True)

        Returns:
            New FoundationalModel instance for the published checkpoint

        Example:
            # Snapshot epoch 50 while training continues
            checkpoint_fm = fm.publish_checkpoint(
                name="My Model v0.5",
                org_id="my_org",
                checkpoint_epoch=50
            )
            # Use immediately
            predictor = checkpoint_fm.create_binary_classifier(target_column="target")
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        if publish and not org_id:
            raise ValueError("org_id is required when publish=True")

        data = {
            "name": name,
            "publish": publish,
        }
        if checkpoint_epoch is not None:
            data["checkpoint_epoch"] = checkpoint_epoch
        if session_name_prefix:
            data["session_name_prefix"] = session_name_prefix
        if org_id:
            data["org_id"] = org_id

        response = self._ctx.post_json(
            f"/compute/session/{self.id}/publish_partial_foundation",
            data=data
        )

        new_fm = FoundationalModel(
            id=response.get("foundation_session_id", ""),
            name=name,
            status="done",
            epochs=response.get("checkpoint_epoch"),
            created_at=datetime.now(),
            _ctx=self._ctx,
        )

        return new_fm

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            'id': self.id,
            'name': self.name,
            'status': self.status,
            'dimensions': self.dimensions,
            'epochs': self.epochs,
            'final_loss': self.final_loss,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'session_type': self.session_type,
            'compute_cluster': self.compute_cluster,
            'error_message': self.error_message,
            'training_progress': self.training_progress,
        }

    def __repr__(self) -> str:
        name_str = f", name='{self.name}'" if self.name else ""
        status_str = f", status='{self.status}'" if self.status else ""
        dims_str = f", dims={self.dimensions}" if self.dimensions else ""
        return f"FoundationalModel(id='{self.id}'{name_str}{status_str}{dims_str})"
