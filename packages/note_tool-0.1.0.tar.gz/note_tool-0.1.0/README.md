# note-tool

> **一次安装，所有 AI Agent 都能搜索、读取、创建你的笔记。**

`note-tool` 是一个多平台笔记 MCP Server。装一个包，把飞书、OneNote、Obsidian、语雀、Notion、印象笔记整合到一个标准 MCP 入口。你的 AI Agent（Claude Code、Cursor、Cline、Hermes……）就能直接在对话中查你的笔记。

## 快速开始

```bash
# 1. 安装
pip install note-tool

# 2. 运行安装向导
note setup

# 3. 配置到你的 AI Agent（详见各 Agent 的 MCP 配置文档）
# Claude Code / Cursor / Cline:
# {
#   "note-tool": {
#     "command": "note",
#     "args": ["mcp"]
#   }
# }
```

## 支持的平台

| 平台 | 状态 | 配置难度 | 配置时间 | 指南 |
|:----|:----|:--------|:--------|:----|
| 🟣 **Obsidian** | ✅ 可用 | 自动 | 0 分钟 | [指南](docs/OBSIDIAN.md) |
| 🟢 **语雀 (Yuque)** | ✅ 可用 | 简单 | 2 分钟 | [指南](docs/YUQUE.md) |
| ⚪ **Notion** | ✅ 可用 | 简单 | 2 分钟 | [指南](docs/NOTION.md) |
| 🔵 **飞书 (Feishu)** | ✅ 可用 | 中等 | 10 分钟 | [指南](docs/FEISHU.md) |
| 🔵 **OneNote** | ✅ 可用 | 中等 | 15 分钟 | [指南](docs/ONENOTE.md) |
| 🟢 **印象笔记 (Evernote)** | ✅ 可用 | 复杂 | 5 天审批 | [指南](docs/EVERNOTE.md) |

**未配置的平台不会出现在 Agent 的工具列表中。** 运行时配置任意组合，互不干扰。

## 架构

```
AI Agent (Claude Code / Cursor / Cline / Hermes / ...)
    │
    ▼  MCP stdio 协议 (JSON-RPC)
┌──────────────────────┐
│   note mcp           │  ← MCP Server，标准协议
│   tools/list         │
│   tools/call         │
└──────┬───────────────┘
       │
┌──────▼────┐ ┌──────▼──────┐ ┌──────▼──────┐
│ Obsidian  │ │ 飞书        │ │ OneNote     │  ← 每个平台独立 adapter
│ (本地文件)  │ │ (Feishu)    │ │ (Microsoft  │
│           │ │             │ │  Graph)     │
└───────────┘ └─────────────┘ └─────────────┘
                   ...
```

**设计原则：**
- **MCP 优先** — 主入口是 MCP Server，所有 Agent 统一接入
- **可插拔** — 每个平台一个 adapter，互不影响
- **零噪音** — 只暴露已配置平台的 tool，未配的自动隐藏
- **CLI 副产品** — Agent 不直接调的，终端用户也能用 `note <platform> <command>`

## 用法

```bash
# 安装向导（推荐）
note setup

# 平台 CLI
note feishu search "关键词"
note onenote search "keyword"
note obsidian search "关键词"
note yuque search "关键词"
note notion search "keyword"
note evernote search "keyword"

# MCP Server（给 Agent 用）
note mcp
```

## MCP 配置

将以下配置添加到你的 AI Agent 的 MCP 配置文件中：

```json
{
  "note-tool": {
    "command": "note",
    "args": ["mcp"]
  }
}
```

**支持的 Agent：**
- Claude Code — `~/.claude/settings.json` 或项目级 `CLAUDE.md`
- Cursor — `~/.cursor/mcp.json`
- Cline — `~/.cline/mcp_settings.json`
- Hermes — `~/.hermes/config.yaml` 中配置 MCP tool

## Tool 列表

每个已配置的平台会暴露以下 tool（前缀为平台名）：

| Tool | 参数 | 说明 |
|:----|:----|:-----|
| `{platform}_search` | `query` | 搜索笔记，返回标题+链接+摘要 |
| `{platform}_read` | `page_id` / `filepath` | 读取笔记全文（Markdown） |
| `{platform}_list_notebooks` | — | 列出笔记本/知识库 |
| `{platform}_list_sections` | `notebook_id?` | 列出分区 |
| `{platform}_create` | `section_id, title` | 创建笔记 |

各平台具体实现略有差异，详见平台指南。

## 开发

```bash
git clone https://github.com/your-username/note-tool.git
cd note-tool
pip install -e .
```

## 项目状态

`note-tool` 处于早期开发阶段。当前已覆盖 6 个平台，代码就绪，部分平台需用户自行获取 API 凭证。

## License

MIT
