"""Tests for FeishuAdapter."""
import json
import os
import tempfile
from unittest.mock import patch, MagicMock, ANY
import pytest
import requests

from note_tool.adapters.feishu import FeishuAdapter, FeishuError


@pytest.fixture
def config_file():
    """Create a temporary config file."""
    config = {
        "app_id": "test_app_id",
        "app_secret": "test_app_secret"
    }
    tmp = tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False)
    json.dump(config, tmp)
    tmp.close()
    yield tmp.name
    os.unlink(tmp.name)


@pytest.fixture
def adapter(config_file):
    """Create adapter with test config."""
    return FeishuAdapter(config_path=config_file)


class TestAuth:
    """Test authentication flow."""

    def test_load_config(self, adapter):
        """Config should be loaded from file."""
        assert adapter.app_id == "test_app_id"
        assert adapter.app_secret == "test_app_secret"

    def test_load_config_file_not_found(self):
        """Should raise error when config file doesn't exist."""
        with pytest.raises(FeishuError, match="Config file not found"):
            FeishuAdapter(config_path="/nonexistent/path.json")

    @patch("note_tool.adapters.feishu.requests.post")
    def test_auth_success(self, mock_post, adapter):
        """Successful auth should return and cache token."""
        mock_post.return_value = MagicMock(
            status_code=200,
            json=lambda: {
                "code": 0,
                "msg": "success",
                "tenant_access_token": "test_token_123",
                "expire": 7200
            }
        )
        token = adapter.auth()
        assert token == "test_token_123"
        # Should cache the token
        assert adapter._token == "test_token_123"
        assert adapter._token_expire > 0

    @patch("note_tool.adapters.feishu.requests.post")
    def test_auth_failure(self, mock_post, adapter):
        """Failed auth should raise."""
        mock_post.return_value = MagicMock(
            status_code=200,
            json=lambda: {
                "code": 10003,
                "msg": "invalid app_id or app_secret"
            }
        )
        with pytest.raises(FeishuError, match="Auth failed"):
            adapter.auth()

    @patch("note_tool.adapters.feishu.requests.post")
    def test_auth_http_error(self, mock_post, adapter):
        """HTTP error should raise."""
        mock_post.return_value = MagicMock(
            status_code=401,
            json=lambda: {"code": 0}
        )
        mock_post.return_value.raise_for_status.side_effect = (
            requests.HTTPError("401 Client Error")
        )
        with pytest.raises(FeishuError, match="Auth HTTP error"):
            adapter.auth()

    @patch("note_tool.adapters.feishu.requests.post")
    def test_token_caching(self, mock_post, adapter):
        """Token should be reused before expiry."""
        mock_post.return_value = MagicMock(
            status_code=200,
            json=lambda: {
                "code": 0,
                "msg": "success",
                "tenant_access_token": "test_token_123",
                "expire": 7200
            }
        )
        # First call gets token
        token1 = adapter.auth()
        # Second call should use cache, not call API
        adapter._token_expire = 9999999999  # far future
        token2 = adapter.auth()
        assert token1 == token2
        assert mock_post.call_count == 1

    @patch("note_tool.adapters.feishu.requests.post")
    def test_token_expiry(self, mock_post, adapter):
        """Expired token should trigger re-auth."""
        mock_post.return_value = MagicMock(
            status_code=200,
            json=lambda: {
                "code": 0,
                "msg": "success",
                "tenant_access_token": "test_token_123",
                "expire": 7200
            }
        )
        token1 = adapter.auth()
        # Set expiry in the past
        adapter._token_expire = 0
        token2 = adapter.auth()
        assert token1 == token2
        assert mock_post.call_count == 2  # Called twice


class TestSearchDocs:
    """Test document search."""

    @patch("note_tool.adapters.feishu.requests.post")
    def test_search_success(self, mock_post, adapter):
        """Successful search should return formatted results."""
        def mock_auth():
            adapter._token = "test_token"
            adapter._token_expire = 9999999999

        adapter.auth = mock_auth

        mock_post.return_value = MagicMock(
            status_code=200,
            json=lambda: {
                "code": 0,
                "data": {
                    "items": [
                        {
                            "title": "API设计文档",
                            "url": "https://test.feishu.cn/wiki/123",
                            "doc_token": "123",
                            "summary": "本文档描述了API接口设计..."
                        },
                        {
                            "title": "产品需求文档",
                            "url": "https://test.feishu.cn/wiki/456",
                            "doc_token": "456",
                            "summary": "本文档记录了产品PRD..."
                        }
                    ],
                    "has_more": False
                }
            }
        )
        results = adapter.search_docs("API设计")
        assert len(results) == 2
        assert results[0]["title"] == "API设计文档"
        assert results[0]["doc_token"] == "123"

    @patch("note_tool.adapters.feishu.requests.post")
    def test_search_fallback_to_spaces(self, mock_post, adapter):
        """When search API fails, should fallback to listing spaces."""
        def mock_auth():
            adapter._token = "test_token"
            adapter._token_expire = 9999999999
        adapter.auth = mock_auth

        # Search API fails
        mock_post.return_value = MagicMock(
            status_code=404,
            json=lambda: {}
        )

        # Fallback get spaces
        from unittest.mock import ANY
        original_get = requests.get

        def mock_get(url, **kwargs):
            if "wiki/v2/spaces" in url:
                return MagicMock(
                    status_code=200,
                    json=lambda: {
                        "code": 0,
                        "data": {
                            "items": [
                                {"name": "产品文档", "space_id": "space_1", "url": "https://.../space_1"},
                            ]
                        }
                    }
                )
            return original_get(url, **kwargs)

        with patch("note_tool.adapters.feishu.requests.get", side_effect=mock_get):
            results = adapter.search_docs("产品")
            assert len(results) == 1
            assert results[0]["title"] == "产品文档"


class TestGetDocContent:
    """Test reading document content."""

    @patch("note_tool.adapters.feishu.requests.get")
    def test_get_content_success(self, mock_get, adapter):
        """Successful content fetch should return document text."""
        def mock_auth():
            adapter._token = "test_token"
            adapter._token_expire = 9999999999
        adapter.auth = mock_auth

        # Mock the docx raw_content endpoint
        mock_get.return_value = MagicMock(
            status_code=200,
            json=lambda: {
                "code": 0,
                "data": {
                    "content": "Hello World\n\nThis is a test document."
                }
            }
        )
        content = adapter.get_doc_content("test_doc_123")
        assert "Hello World" in content


class TestCreateDoc:
    """Test document creation."""

    @patch("note_tool.adapters.feishu.requests.post")
    def test_create_success(self, mock_post, adapter):
        """Successful creation should return document info."""
        def mock_auth():
            adapter._token = "test_token"
            adapter._token_expire = 9999999999
        adapter.auth = mock_auth

        mock_post.return_value = MagicMock(
            status_code=200,
            json=lambda: {
                "code": 0,
                "data": {
                    "document": {
                        "document_id": "new_doc_789",
                        "title": "测试文档"
                    }
                }
            }
        )
        result = adapter.create_doc("测试文档")
        assert result["document_id"] == "new_doc_789"
        assert result["title"] == "测试文档"


class TestValidateDocToken:
    """Test doc_token validation."""

    def test_valid_token(self, adapter):
        """Valid doc_token should pass."""
        assert adapter.validate_doc_token("abc123DEF-_") is True

    def test_empty_token(self, adapter):
        """Empty token should fail."""
        assert adapter.validate_doc_token("") is False

    def test_none_token(self, adapter):
        """None should fail."""
        assert adapter.validate_doc_token(None) is False

    def test_invalid_chars(self, adapter):
        """Token with invalid characters should fail."""
        assert adapter.validate_doc_token("abc 123") is False
        assert adapter.validate_doc_token("abc/def") is False
