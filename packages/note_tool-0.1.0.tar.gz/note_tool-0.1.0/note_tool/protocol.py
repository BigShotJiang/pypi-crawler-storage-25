"""Protocol definitions for note-tool adapters.

Defines the ToolDef and the adapter protocol that every platform
adapter must implement to be discoverable by the MCP Server.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class ToolDef:
    """Definition of a tool exposed by an adapter.

    Attributes:
        name: Tool name (e.g. 'onenote_search')
        description: Human-readable description for the Agent.
        input_schema: JSON Schema for the tool's input parameters.
    """
    name: str
    description: str
    input_schema: dict = field(default_factory=lambda: {"type": "object", "properties": {}})

    def to_dict(self) -> dict:
        """Serialize to MCP tool definition format."""
        return {
            "name": self.name,
            "description": self.description,
            "inputSchema": self.input_schema,
        }


class NoteAdapter:
    """Base class for note platform adapters.

    Subclasses must implement:
        - platform_name: str property
        - available(): bool — whether the adapter is configured/ready
        - get_tools(): list[ToolDef] — what tools this platform provides
        - handle_tool_call(name, args) -> str — execute a tool
    """

    @property
    def platform_name(self) -> str:
        """Platform identifier (e.g. 'onenote', 'feishu')."""
        raise NotImplementedError

    def available(self) -> bool:
        """Check if this adapter is ready to use (configured + authenticated)."""
        raise NotImplementedError

    def get_tools(self) -> list[ToolDef]:
        """Return tool definitions exposed by this adapter."""
        raise NotImplementedError

    def handle_tool_call(self, tool_name: str, args: dict) -> str:
        """Execute a tool call and return text result."""
        raise NotImplementedError


def make_string_schema(description: str = "") -> dict:
    """Helper: create a JSON Schema for a single string parameter."""
    return {
        "type": "object",
        "properties": {
            "value": {
                "type": "string",
                "description": description,
            }
        },
        "required": ["value"],
    }


def make_query_schema(description: str = "Search query") -> dict:
    """Helper: create a JSON Schema for a search tool."""
    return {
        "type": "object",
        "properties": {
            "query": {
                "type": "string",
                "description": description,
            }
        },
        "required": ["query"],
    }
