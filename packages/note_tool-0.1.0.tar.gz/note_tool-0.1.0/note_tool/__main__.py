"""Allow `python -m note_tool` to run as CLI."""
from note_tool.cli import main

main()
