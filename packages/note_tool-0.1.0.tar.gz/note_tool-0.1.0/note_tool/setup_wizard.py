#!/usr/bin/env python3
"""note setup — 交互式安装向导。

引导用户完成各平台的配置，推荐顺序：
  1. Obsidian（自动检测）
  2. 语雀（最简单）
  3. Notion（两分钟）
  4. 飞书 / OneNote / 印象笔记（需更多步骤）
"""

from __future__ import annotations

import os
import sys
from pathlib import Path


# Platform guidance data
PLATFORMS = [
    {
        "name": "Obsidian",
        "emoji": "🟣",
        "difficulty": "自动",
        "time": "0 分钟",
        "instructions": [
            "Obsidian Adapter 会自动检测你本地的知识库路径。",
            "如果检测失败，设置环境变量：export OBSIDIAN_VAULT_PATH=/path/to/vault",
        ],
        "check": lambda: _check_env("OBSIDIAN_VAULT_PATH") or _check_file("~/.obsidian_config.json"),
    },
    {
        "name": "语雀 (Yuque)",
        "emoji": "🟢",
        "difficulty": "简单",
        "time": "2 分钟",
        "instructions": [
            "1. 打开 https://www.yuque.com/settings/tokens",
            "2. 点击「新建 Token」，输入名称（如 note-tool）",
            "3. 复制生成的 Token",
            "4. 运行：echo '{\"token\": \"你的Token\"}' > ~/.yuque_config.json",
            "或设置环境变量：export YUQUE_TOKEN=你的Token",
        ],
        "check": lambda: _check_token("YUQUE_TOKEN", "~/.yuque_config.json"),
    },
    {
        "name": "Notion",
        "emoji": "⚪",
        "difficulty": "简单",
        "time": "2 分钟",
        "instructions": [
            "1. 打开 https://www.notion.so/my-integrations",
            "2. 点击「新建集成」(New Integration)",
            "3. 输入名称（如 note-tool），选择关联的工作空间",
            "4. 复制生成的「Internal Integration Secret」",
            "5. 运行：echo '{\"token\": \"你的Token\"}' > ~/.notion_config.json",
            "或设置环境变量：export NOTION_TOKEN=你的Token",
            "",
            "⚠️ 重要：还要在 Notion 中把集成分享给你想访问的页面：",
            "   打开页面 → 右上角 ... → Add connections → 选择 note-tool",
        ],
        "check": lambda: _check_token("NOTION_TOKEN", "~/.notion_config.json"),
    },
    {
        "name": "飞书 (Feishu)",
        "emoji": "🔵",
        "difficulty": "中等",
        "time": "10 分钟",
        "instructions": [
            "1. 打开 https://open.feishu.cn/app",
            "2. 创建「企业自建应用」，输入名称",
            "3. 在「权限管理」中添加：",
            "   - docx:document:readonly",
            "   - docx:document",
            "   - wiki:wiki:readonly",
            "   - search:search:readonly",
            "4. 发布应用（版本管理 → 创建版本 → 申请发布）",
            "5. 在「凭证与基础信息」复制 App ID 和 App Secret",
            "6. 保存到项目目录的 config.json 中",
        ],
        "check": lambda: False,  # Complex, always show instructions
    },
    {
        "name": "OneNote",
        "emoji": "🔵",
        "difficulty": "中等",
        "time": "15 分钟",
        "instructions": [
            "1. 打开 https://portal.azure.com → Azure Active Directory",
            "2. 进入「应用注册」→「新注册」",
            "3. 名称填 note-tool，账户类型选「个人 Microsoft 账户」",
            "4. 注册后复制「应用程序(客户端)ID」",
            "5. 左侧「API 权限」→ 添加权限 → Microsoft Graph → 委托权限",
            "6. 勾选 Notes.ReadWrite.All 和 offline_access",
            "7. 运行：echo '{\"client_id\": \"你的ID\"}' > ~/.onetool_config.json",
            "8. 运行：note onenote login（设备码登录）",
        ],
        "check": lambda: _check_file("~/.onetool_config.json"),
    },
    {
        "name": "印象笔记 (Evernote)",
        "emoji": "🟢",
        "difficulty": "复杂",
        "time": "5 天审批",
        "instructions": [
            "1. 打开 https://dev.evernote.com",
            "2. 申请 API Key（约 5 个工作日审批）",
            "3. 拿到 API Key 后完成 OAuth 认证",
            "4. 安装依赖：pip install evernote3",
            "5. 配置保存到 ~/.evernote_config.json",
        ],
        "check": lambda: _check_file("~/.evernote_config.json"),
    },
]


def _check_env(var: str) -> bool:
    return bool(os.environ.get(var))


def _check_file(path: str) -> bool:
    return Path(path).expanduser().exists()


def _check_token(env_var: str, config_path: str) -> bool:
    return _check_env(env_var) or _check_file(config_path)


# ── Setup Wizard ─────────────────────────────────────────────


def run_setup():
    """Run the interactive setup wizard."""
    print("┌──────────────────────────────────────┐")
    print("│  note-tool 安装向导                   │")
    print("│  一次安装，所有 Agent 都能读你的笔记    │")
    print("└──────────────────────────────────────┘")
    print()

    # Check status of all platforms
    configured = []
    not_configured = []

    for p in PLATFORMS:
        if p["check"]():
            configured.append(p)
        else:
            not_configured.append(p)

    # Show configured platforms
    if configured:
        print("✅ 已配置：")
        for p in configured:
            print(f"   {p['emoji']} {p['name']}")
        print()

    # Show recommended platforms to configure
    if not_configured:
        print("📋 待配置（推荐顺序）：")
        for i, p in enumerate(not_configured, 1):
            status = "已就绪" if p["check"]() else f"需配置（{p['time']}）"
            print(f"   {i}. {p['emoji']} {p['name']}  —  {status}")
        print()

    # Guide through first unconfigured platform
    for p in not_configured:
        if not p["check"]():
            print(f"─── {p['emoji']} {p['name']} 配置指南 ───")
            print()
            for line in p["instructions"]:
                print(f"   {line}")
            print()

            # Ask if they want to configure it now
            answer = input(f"   配置好了吗？(y=继续, n=跳过, q=退出) [y/n/q]: ").strip().lower()
            if answer == "q":
                print("\n安装向导已退出。运行 `note setup` 可随时继续。")
                return
            elif answer == "n":
                continue
            elif answer == "y":
                print("   ✅ 好的，已配置完成！")
            print()

    # Summary
    print()
    print("─── 🎉 完成 ───")
    print()

    # Re-check what's now configured
    final_configured = [p for p in PLATFORMS if p["check"]()]
    if final_configured:
        print(f"已配置 {len(final_configured)}/{len(PLATFORMS)} 个平台：")
        for p in final_configured:
            print(f"   ✅ {p['emoji']} {p['name']}")
        print()

    print("下一步：将 note-tool 配置到你的 AI Agent：")
    print()
    print("   Claude Code / Cursor / Cline 用户：")
    print('   在 MCP 配置中添加：')
    print('   {')
    print('     "note-tool": {')
    print('       "command": "note",')
    print('       "args": ["mcp"]')
    print('     }')
    print('   }')
    print()
    print("   然后重启 Agent，对话中就能直接查你的笔记了。")
    print("   运行 `note mcp` 可单独测试 MCP Server。")
    print()


def main():
    run_setup()


if __name__ == "__main__":
    main()
