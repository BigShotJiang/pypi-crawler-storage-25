#!/usr/bin/env python3
"""MCP Server for note-tool — exposes all note platform adapters via MCP stdio.

Usage:
    python -m note_tool.mcp_server          # Standalone
    note mcp                                 # Via CLI dispatcher

Protocol: JSON-RPC 2.0 over stdin/stdout.
One JSON object per line, delimited by \n.
"""

from __future__ import annotations

import json
import sys
import traceback
from typing import Any, Dict, List

from note_tool.protocol import NoteAdapter, ToolDef

MCP_PROTOCOL_VERSION = "2024-11-05"


# ── Adapter Registry ─────────────────────────────────────────

_adapters: Dict[str, NoteAdapter] = {}


def register_adapter(adapter: NoteAdapter):
    """Register a note platform adapter."""
    _adapters[adapter.platform_name] = adapter


def get_all_tools() -> List[dict]:
    """Aggregate tools from all registered adapters.

    Only includes tools from adapters that are available (configured).
    Unavailable adapters (no config / no auth) are silently skipped.
    """
    tools = []
    for name, adapter in _adapters.items():
        try:
            if not adapter.available():
                continue
            for tool in adapter.get_tools():
                tools.append(tool.to_dict())
        except Exception as e:
            # Adapter error during tool enumeration — skip
            pass
    return tools


def call_tool(tool_name: str, arguments: dict) -> str:
    """Route a tool call to the right adapter.

    Tool naming convention: {platform}_{action}
    e.g. 'onenote_search', 'feishu_read'
    """
    # Extract platform name from tool name
    for platform, adapter in _adapters.items():
        if tool_name.startswith(platform):
            try:
                return adapter.handle_tool_call(tool_name, arguments)
            except Exception as e:
                return f"❌ 错误：{e}\n{traceback.format_exc()}"
    return f"❌ 未知工具：{tool_name}"


# ── JSON-RPC Message Handling ─────────────────────────────────

Message = Dict[str, Any]


def make_response(id: Any, result: Any = None, error: Any = None) -> Message:
    """Build a JSON-RPC 2.0 response."""
    msg = {"jsonrpc": "2.0", "id": id}
    if error:
        msg["error"] = error
    else:
        msg["result"] = result
    return msg


def make_error(id: Any, code: int, message: str) -> Message:
    """Build a JSON-RPC error response."""
    return make_response(id, error={"code": code, "message": message})


def handle_message(msg: Message) -> List[Message]:
    """Process a single incoming JSON-RPC message.

    Returns a list of responses (usually 1, may be empty for notifications).
    """
    # Validate structure
    if not isinstance(msg, dict) or msg.get("jsonrpc") != "2.0":
        return [make_error(None, -32600, "Invalid Request")]

    method = msg.get("method", "")
    msg_id = msg.get("id")
    params = msg.get("params", {})

    # ── Notifications (no id = no response) ──────────────
    if msg_id is None:
        if method == "notifications/initialized":
            pass  # Agent notification, no action needed
        elif method == "notifications/cancelled":
            pass  # Cancellation notification
        # Other notifications are silently ignored
        return []

    # ── Requests ─────────────────────────────────────────

    if method == "initialize":
        client_version = params.get("protocolVersion", "")
        return [make_response(msg_id, {
            "protocolVersion": MCP_PROTOCOL_VERSION,
            "capabilities": {
                "tools": {},
            },
            "serverInfo": {
                "name": "note-tool",
                "version": "0.1.0",
            },
        })]

    elif method == "tools/list":
        tools = get_all_tools()
        return [make_response(msg_id, {"tools": tools})]

    elif method == "tools/call":
        name = params.get("name", "")
        arguments = params.get("arguments", {})
        result_text = call_tool(name, arguments)
        return [make_response(msg_id, {
            "content": [
                {"type": "text", "text": result_text}
            ]
        })]

    elif method == "shutdown":
        return [make_response(msg_id, {})]

    elif method == "ping":
        return [make_response(msg_id, {})]

    else:
        return [make_error(msg_id, -32601, f"Method not found: {method}")]


# ── Stdio Transport ──────────────────────────────────────────

def run_stdio():
    """Run the MCP server over stdin/stdout.

    Reads one JSON message per line from stdin,
    writes one JSON message per line to stdout.
    Flushes after each response.
    """
    # Signal readiness by writing an empty line (optional, helps debugging)
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue

        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            resp = make_error(None, -32700, "Parse error")
            sys.stdout.write(json.dumps(resp, ensure_ascii=False) + "\n")
            sys.stdout.flush()
            continue

        responses = handle_message(msg)
        for resp in responses:
            sys.stdout.write(json.dumps(resp, ensure_ascii=False) + "\n")
            sys.stdout.flush()

        # Shutdown after receiving shutdown response
        if isinstance(msg, dict) and msg.get("method") == "shutdown":
            break


# ── Entry ────────────────────────────────────────────────────

def main():
    """Main entry point for the MCP server.

    Discovers and registers all available adapters before
    starting the stdio loop.
    """
    # Discover adapters dynamically
    _discover_adapters()

    # Start stdio server
    try:
        run_stdio()
    except BrokenPipeError:
        # Agent disconnected — normal exit
        pass
    except KeyboardInterrupt:
        pass


def _discover_adapters():
    """Import and register all available adapters."""
    adapters_to_try = [
        ("note_tool.adapters.feishu_tool", "FeishuMCPAdapter"),
        ("note_tool.adapters.onenote_tool", "OneNoteMCPAdapter"),
        ("note_tool.adapters.obsidian", "ObsidianMCPAdapter"),
        ("note_tool.adapters.yuque", "YuqueMCPAdapter"),
        ("note_tool.adapters.notion", "NotionMCPAdapter"),
        ("note_tool.adapters.evernote", "EvernoteMCPAdapter"),
    ]
    for module_path, class_name in adapters_to_try:
        try:
            import importlib
            mod = importlib.import_module(module_path)
            cls = getattr(mod, class_name)
            adapter = cls()
            register_adapter(adapter)
        except Exception:
            pass


if __name__ == "__main__":
    main()
