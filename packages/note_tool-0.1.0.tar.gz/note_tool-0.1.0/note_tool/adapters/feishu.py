#!/usr/bin/env python3
"""
Feishu Document API Adapter.

Provides search, read, and create operations for Feishu documents
via the Feishu Open API. Used by both Hermes Agent tool and CLI.
"""

import json
import os
import time
import base64
from pathlib import Path

import requests


FEISHU_BASE = "https://open.feishu.cn/open-apis"

# Default config location
DEFAULT_CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")


class FeishuError(Exception):
    """Base exception for Feishu adapter errors."""
    pass


class FeishuAdapter:
    """Adapter for Feishu Document API."""

    def __init__(self, config_path=None):
        self.config_path = config_path or DEFAULT_CONFIG_PATH
        self._load_config()
        self._token = None
        self._token_expire = 0

    # ── Config ────────────────────────────────────────────────

    def _load_config(self):
        """Load App ID and Secret from config file."""
        path = Path(self.config_path)
        if not path.exists():
            raise FeishuError(
                f"Config file not found: {self.config_path}"
            )
        with open(path) as f:
            config = json.load(f)
        self.app_id = config.get("app_id")
        self.app_secret = config.get("app_secret")
        if not self.app_id or not self.app_secret:
            raise FeishuError(
                "Config file must contain 'app_id' and 'app_secret'"
            )

    # ── Auth ──────────────────────────────────────────────────

    def auth(self):
        """Get tenant_access_token. Cached until near expiry."""
        # Return cached token if still valid (5 min buffer)
        if self._token and time.time() < self._token_expire - 300:
            return self._token

        url = f"{FEISHU_BASE}/auth/v3/tenant_access_token/internal"
        payload = {
            "app_id": self.app_id,
            "app_secret": self.app_secret,
        }
        try:
            resp = requests.post(url, json=payload, timeout=10)
            resp.raise_for_status()
            data = resp.json()
        except requests.RequestException as e:
            raise FeishuError(f"Auth HTTP error: {e}")

        if data.get("code") != 0:
            raise FeishuError(
                f"Auth failed: {data.get('msg', 'unknown error')}"
            )

        self._token = data["tenant_access_token"]
        self._token_expire = time.time() + data["expire"]
        return self._token

    # ── Headers ───────────────────────────────────────────────

    def _headers(self):
        """Build auth headers."""
        token = self.auth()
        return {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        }

    # ── Search ────────────────────────────────────────────────

    def search_docs(self, query, page_size=10):
        """Search Feishu documents by query string.

        Requires the Feishu app to be published with appropriate permissions.
        If search API is unavailable, lists wiki spaces as fallback.

        Args:
            query: Search keywords
            page_size: Max results per page (default 10)

        Returns:
            List of dicts with keys: title, url, doc_token, summary
        """
        # Try dedicated search API (requires app to be published)
        url = f"{FEISHU_BASE}/search/v1/search"
        payload = {
            "query": query,
            "page_size": page_size,
        }
        try:
            resp = requests.post(url, json=payload,
                                 headers=self._headers(), timeout=10)
            if resp.status_code == 200:
                data = resp.json()
                if data.get("code") == 0:
                    items = data.get("data", {}).get("items", [])
                    return [
                        {
                            "title": item.get("title", ""),
                            "url": item.get("url", ""),
                            "doc_token": item.get("doc_token", ""),
                            "summary": item.get("summary", ""),
                        }
                        for item in items
                    ]
        except (requests.RequestException, ValueError):
            pass

        # Fallback: list wiki spaces (works without publishing)
        try:
            resp = requests.get(
                f"{FEISHU_BASE}/wiki/v2/spaces?page_size={page_size}",
                headers=self._headers(), timeout=10
            )
            resp.raise_for_status()
            data = resp.json()
            if data.get("code") == 0:
                items = data.get("data", {}).get("items", [])
                # Filter by query match in name
                results = []
                for item in items:
                    name = item.get("name", "")
                    if query.lower() in name.lower():
                        results.append({
                            "title": name,
                            "url": item.get("url", ""),
                            "doc_token": item.get("space_id", ""),
                            "summary": f"知识空间: {name}",
                        })
                if results:
                    return results
        except (requests.RequestException, ValueError):
            pass

        # No results, no search available without publishing
        return []

    # ── Read ──────────────────────────────────────────────────

    def get_doc_content(self, doc_token):
        """Read document content via Docx API.

        Args:
            doc_token: The document token

        Returns:
            Markdown string of the document content
        """
        if not self.validate_doc_token(doc_token):
            raise FeishuError(f"Invalid doc_token: {doc_token}")

        url = f"{FEISHU_BASE}/docx/v1/documents/{doc_token}/raw_content"
        try:
            resp = requests.get(url, headers=self._headers(), timeout=15)
            resp.raise_for_status()
            data = resp.json()
        except requests.RequestException as e:
            raise FeishuError(f"Read document failed: {e}")

        if data.get("code") != 0:
            raise FeishuError(
                f"Read document failed: {data.get('msg', 'unknown error')}"
            )

        return data.get("data", {}).get("content", "")

    # ── Create ────────────────────────────────────────────────

    def create_doc(self, title):
        """Create a new Feishu document.

        Args:
            title: Document title

        Returns:
            Dict with document_id and title
        """
        url = f"{FEISHU_BASE}/docx/v1/documents"
        payload = {"title": title}
        try:
            resp = requests.post(url, json=payload,
                                 headers=self._headers(), timeout=15)
            resp.raise_for_status()
            data = resp.json()
        except requests.RequestException as e:
            raise FeishuError(f"Create document failed: {e}")

        if data.get("code") != 0:
            raise FeishuError(
                f"Create document failed: {data.get('msg', 'unknown error')}"
            )

        doc_data = data.get("data", {}).get("document", {})
        return {
            "document_id": doc_data.get("document_id", ""),
            "title": doc_data.get("title", title),
        }

    # ── Validation ────────────────────────────────────────────

    @staticmethod
    def validate_doc_token(doc_token):
        """Validate a doc_token string.

        Tokens should be non-empty alphanumeric strings
        (may include hyphens and underscores).
        """
        if not doc_token or not isinstance(doc_token, str):
            return False
        return all(c.isalnum() or c in "-_" for c in doc_token)
