#!/usr/bin/env python3
"""Obsidian (Local) Adapter — reads notes from the local vault via file system.

No API needed. Just points to an Obsidian vault directory and
searches/reads markdown files directly. The fastest and most
reliable adapter since there's no network dependency.

Config:
    Set OBSIDIAN_VAULT_PATH environment variable, or create
    ~/.obsidian_config.json with {"vault_path": "/path/to/vault"}
"""

from __future__ import annotations

import json
import os
import re
import time
from pathlib import Path
from typing import List, Optional

from note_tool.protocol import NoteAdapter, ToolDef, make_query_schema

# Default config location
DEFAULT_CONFIG_PATH = os.path.expanduser("~/.obsidian_config.json")


class ObsidianError(Exception):
    """Base exception for Obsidian adapter errors."""
    pass


class ObsidianAdapter:
    """Adapter for local Obsidian vault — file system based."""

    def __init__(self, vault_path: Optional[str] = None):
        if vault_path:
            self.vault_path = vault_path
        else:
            self.vault_path = self._resolve_vault_path()
        self._verify_vault()

    def _resolve_vault_path(self) -> str:
        """Find vault path: env var → config file → default."""
        # 1. Environment variable
        env_path = os.environ.get("OBSIDIAN_VAULT_PATH")
        if env_path and os.path.isdir(env_path):
            return env_path

        # 2. Config file
        config_path = Path(DEFAULT_CONFIG_PATH)
        if config_path.exists():
            with open(config_path) as f:
                config = json.load(f)
            vp = config.get("vault_path")
            if vp and os.path.isdir(vp):
                return vp

        # 3. Default path (common locations)
        candidates = [
            os.path.expanduser("~/Documents/Obsidian"),
            os.path.expanduser("~/Documents/Obsidian Vault"),
            os.path.expanduser("~/Obsidian"),
            os.path.expanduser("~/Documents/Personal/HA_Hermes/ob_personal_hermes/OB_HA_HERMES"),
        ]
        for c in candidates:
            if os.path.isdir(c) and any(f.endswith(".md") for f in os.listdir(c)[:20]):
                return c

        raise ObsidianError(
            "Cannot find Obsidian vault. Set OBSIDIAN_VAULT_PATH env var "
            f"or create {DEFAULT_CONFIG_PATH} with {{\"vault_path\": \"...\"}}"
        )

    def _verify_vault(self):
        """Check that the vault path is a real Obsidian vault."""
        path = Path(self.vault_path)
        if not path.exists():
            raise ObsidianError(f"Vault path does not exist: {self.vault_path}")
        if not path.is_dir():
            raise ObsidianError(f"Vault path is not a directory: {self.vault_path}")

    # ── Public API ───────────────────────────────────────────

    def search_notes(self, query: str, page_size: int = 30) -> List[dict]:
        """Search notes by content or filename.

        Uses Python's built-in file search (no grep dependency).
        Searches both filename and file content.

        Args:
            query: Search keyword.
            page_size: Max results.

        Returns:
            List of dicts: path, filename, title, snippet, mtime
        """
        results = []
        query_lower = query.lower()
        vault = Path(self.vault_path)

        for md_file in vault.rglob("*.md"):
            # Skip hidden directories and certain system dirs
            rel = md_file.relative_to(vault)
            parts = rel.parts
            if any(p.startswith(".") for p in parts):
                continue
            if any(p.startswith("99-") for p in parts):
                continue  # Skip templates

            # Check filename match
            filename_match = query_lower in md_file.stem.lower()

            # Try to extract title from YAML frontmatter or first heading
            try:
                content = md_file.read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue

            title = self._extract_title(content, md_file.stem)

            # Check content match
            content_match = False
            snippet = ""
            if query_lower in content.lower():
                content_match = True
                # Find a snippet around the match
                idx = content.lower().find(query_lower)
                start = max(0, idx - 60)
                end = min(len(content), idx + len(query) + 60)
                snippet = content[start:end].replace("\n", " ").strip()
                if len(snippet) > 150:
                    snippet = snippet[:147] + "..."

            if filename_match or content_match:
                mtime = md_file.stat().st_mtime
                results.append({
                    "path": str(md_file),
                    "filename": md_file.name,
                    "title": title,
                    "snippet": snippet,
                    "mtime": time.strftime("%Y-%m-%d %H:%M", time.localtime(mtime)),
                })

            if len(results) >= page_size:
                break

        return results

    def read_note(self, filepath: str) -> dict:
        """Read a note's full content by its absolute path.

        Args:
            filepath: Absolute path to the .md file.

        Returns:
            Dict with path, title, content (markdown), mtime
        """
        path = Path(filepath)
        if not path.exists():
            raise ObsidianError(f"File not found: {filepath}")
        if path.suffix != ".md":
            raise ObsidianError(f"Not a markdown file: {filepath}")
        # Security: ensure path is within vault
        vault = Path(self.vault_path).resolve()
        file_resolved = path.resolve()
        if not str(file_resolved).startswith(str(vault)):
            raise ObsidianError(f"File is outside vault: {filepath}")

        content = path.read_text(encoding="utf-8", errors="replace")
        title = self._extract_title(content, path.stem)
        mtime = path.stat().st_mtime

        return {
            "path": str(path),
            "title": title,
            "content": content,
            "mtime": time.strftime("%Y-%m-%d %H:%M", time.localtime(mtime)),
            "size": path.stat().st_size,
        }

    def list_notes(self, subdir: str = "") -> List[dict]:
        """List notes in the vault, optionally in a subdirectory.

        Args:
            subdir: Optional subdirectory within vault (e.g. '10-笔记/文章/').

        Returns:
            List of dicts: path, filename, title, mtime, size
        """
        vault = Path(self.vault_path)
        search_path = vault / subdir if subdir else vault
        if not search_path.exists():
            raise ObsidianError(f"Directory not found: {search_path}")

        results = []
        for md_file in sorted(search_path.rglob("*.md")):
            rel = md_file.relative_to(vault)
            parts = rel.parts
            if any(p.startswith(".") for p in parts):
                continue
            try:
                content = md_file.read_text(encoding="utf-8", errors="replace")
            except Exception:
                content = ""
            title = self._extract_title(content, md_file.stem)
            mtime = md_file.stat().st_mtime
            results.append({
                "path": str(md_file),
                "filename": md_file.name,
                "title": title,
                "mtime": time.strftime("%Y-%m-%d %H:%M", time.localtime(mtime)),
                "size": md_file.stat().st_size,
            })
        return results

    def create_note(self, filepath: str, content: str) -> dict:
        """Create a new markdown note in the vault.

        Args:
            filepath: Relative path within vault (e.g. '10-笔记/想法/my-note.md').
            content: Markdown content.

        Returns:
            Dict with path and title.
        """
        vault = Path(self.vault_path)
        full_path = vault / filepath
        # Security check
        full_resolved = full_path.resolve()
        if not str(full_resolved).startswith(str(vault.resolve())):
            raise ObsidianError("Cannot write outside vault")

        full_path.parent.mkdir(parents=True, exist_ok=True)
        full_path.write_text(content, encoding="utf-8")
        return {
            "path": str(full_path),
            "title": Path(filepath).stem,
        }

    def vault_info(self) -> dict:
        """Get vault stats."""
        vault = Path(self.vault_path)
        md_files = list(vault.rglob("*.md"))
        total_size = sum(f.stat().st_size for f in md_files)
        return {
            "vault_path": str(vault),
            "total_notes": len(md_files),
            "total_size_kb": total_size // 1024,
        }

    # ── Helpers ──────────────────────────────────────────────

    @staticmethod
    def _extract_title(content: str, fallback: str) -> str:
        """Extract title from YAML frontmatter or first # heading."""
        # YAML title
        m = re.search(r'^---\s*\n\s*title:\s*["\']?(.+?)["\']?\s*\n', content)
        if m:
            return m.group(1).strip()
        # First # heading
        m = re.search(r'^#\s+(.+)$', content, re.MULTILINE)
        if m:
            return m.group(1).strip()
        return fallback


# ── Tool Wrapper ─────────────────────────────────────────────


class ObsidianTool:
    """Hermes-compatible tool wrapper for ObsidianAdapter."""

    def __init__(self, vault_path=None):
        self.adapter = ObsidianAdapter(vault_path)

    def search(self, query):
        try:
            results = self.adapter.search_notes(query)
        except ObsidianError as e:
            return f"Error: {e}"
        if not results:
            return f"没有找到与「{query}」相关的笔记。"
        lines = [f"找到 {len(results)} 篇相关笔记：\n"]
        for r in results:
            lines.append(f"📄 **{r['title']}**")
            lines.append(f"   路径: {r['path']}")
            lines.append(f"   修改: {r['mtime']}")
            if r['snippet']:
                lines.append(f"   片段: {r['snippet'][:100]}...")
            lines.append("")
        return "\n".join(lines)

    def read(self, filepath):
        try:
            note = self.adapter.read_note(filepath)
        except ObsidianError as e:
            return f"Error: {e}"
        return f"# {note['title']}\n\n---\n- 路径: {note['path']}\n- 修改: {note['mtime']}\n---\n\n{note['content']}"

    def list(self, subdir=""):
        try:
            notes = self.adapter.list_notes(subdir)
        except ObsidianError as e:
            return f"Error: {e}"
        if not notes:
            return "没有找到笔记。"
        lines = [f"找到 {len(notes)} 篇笔记：\n"]
        for n in notes:
            lines.append(f"📄 {n['title']}  —  {n['filename']}")
        return "\n".join(lines)

    def create(self, filepath, content):
        try:
            result = self.adapter.create_note(filepath, content)
        except ObsidianError as e:
            return f"Error: {e}"
        return f"✅ 笔记已创建\n   路径: {result['path']}"

    def info(self):
        try:
            info = self.adapter.vault_info()
        except ObsidianError as e:
            return f"Error: {e}"
        return (
            f"📂 Obsidian 知识库\n"
            f"   路径: {info['vault_path']}\n"
            f"   笔记数: {info['total_notes']}\n"
            f"   总大小: {info['total_size_kb']} KB"
        )


# ── MCP Adapter Wrapper ──────────────────────────────────────


class ObsidianMCPAdapter(NoteAdapter):
    """Wraps ObsidianAdapter for MCP Server."""

    def __init__(self):
        try:
            self._tool = ObsidianTool()
            self._ready = True
        except Exception:
            self._tool = None
            self._ready = False

    @property
    def platform_name(self) -> str:
        return "obsidian"

    def available(self) -> bool:
        return self._ready

    def get_tools(self) -> List[ToolDef]:
        if not self._ready:
            return []
        return [
            ToolDef(
                name="obsidian_search",
                description="Search local Obsidian vault notes by keyword. Searches both filenames and content. Returns matching notes with path, title, and content snippet.",
                input_schema=make_query_schema("Keyword to search in Obsidian vault"),
            ),
            ToolDef(
                name="obsidian_read",
                description="Read the full content of an Obsidian note by its absolute file path. Returns the complete markdown content.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "filepath": {
                            "type": "string",
                            "description": "Absolute path to the .md file in the vault",
                        }
                    },
                    "required": ["filepath"],
                },
            ),
            ToolDef(
                name="obsidian_list",
                description="List notes in the Obsidian vault, optionally filtered by subdirectory.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "subdir": {
                            "type": "string",
                            "description": "Optional subdirectory to list (e.g. '10-笔记/文章/')",
                        }
                    },
                },
            ),
            ToolDef(
                name="obsidian_create",
                description="Create a new markdown note in the Obsidian vault.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "filepath": {
                            "type": "string",
                            "description": "Relative path within vault (e.g. '10-笔记/想法/my-note.md')",
                        },
                        "content": {
                            "type": "string",
                            "description": "Markdown content of the note",
                        },
                    },
                    "required": ["filepath", "content"],
                },
            ),
            ToolDef(
                name="obsidian_info",
                description="Get Obsidian vault statistics: path, total notes, total size.",
            ),
        ]

    def handle_tool_call(self, tool_name: str, args: dict) -> str:
        if tool_name == "obsidian_search":
            return self._tool.search(args.get("query", ""))
        elif tool_name == "obsidian_read":
            return self._tool.read(args.get("filepath", ""))
        elif tool_name == "obsidian_list":
            return self._tool.list(args.get("subdir", ""))
        elif tool_name == "obsidian_create":
            return self._tool.create(
                args.get("filepath", ""),
                args.get("content", ""),
            )
        elif tool_name == "obsidian_info":
            return self._tool.info()
        else:
            return f"Unknown tool: {tool_name}"


# ── CLI Entry ────────────────────────────────────────────────

def main():
    """CLI entry: note obsidian <command> [args...]"""
    import sys
    if len(sys.argv) < 2:
        print("Usage: note obsidian <command> [args...]")
        print("Commands: search, read, list, create, info")
        sys.exit(1)

    command = sys.argv[1]
    args = sys.argv[2:]
    tool = ObsidianTool()

    if command == "search":
        result = tool.search(" ".join(args) if args else "")
    elif command == "read":
        result = tool.read(args[0] if args else "")
    elif command == "list":
        result = tool.list(args[0] if args else "")
    elif command == "create":
        if len(args) < 2:
            print("Usage: note obsidian create <filepath> <content>")
            sys.exit(1)
        result = tool.create(args[0], " ".join(args[1:]))
    elif command == "info":
        result = tool.info()
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)
    print(result)


if __name__ == "__main__":
    main()
