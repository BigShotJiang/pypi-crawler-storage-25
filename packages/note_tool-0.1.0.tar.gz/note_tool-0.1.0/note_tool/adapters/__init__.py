"""Adapters for note platforms."""
from . import feishu
from . import onenote
from . import obsidian
from . import yuque
from . import notion
from . import evernote

__all__ = ["feishu", "onenote", "obsidian", "yuque", "notion", "evernote"]
