#!/usr/bin/env python3
"""Yuque (语雀) Adapter — REST API with personal token.

API base: https://www.yuque.com/api/v2
Auth: X-Auth-Token header (personal token)

Features:
    - List repos (notebooks/groups)
    - List docs in a repo
    - Search by fetching docs and filtering client-side
      (语雀 has no server-side search API)
    - Read doc content (returns markdown)
    - Create doc
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import List, Optional

import requests

from note_tool.protocol import NoteAdapter, ToolDef, make_query_schema

YUQUE_BASE = "https://www.yuque.com/api/v2"

# Default config location
DEFAULT_CONFIG_PATH = os.path.expanduser("~/.yuque_config.json")


class YuqueError(Exception):
    """Base exception for Yuque adapter errors."""
    pass


class YuqueAdapter:
    """Adapter for Yuque (语雀) Document API."""

    def __init__(self, token: Optional[str] = None):
        if token:
            self.token = token
        else:
            self.token = self._load_token()
        self._session = requests.Session()

    def _load_token(self) -> str:
        """Load token from config file."""
        # 1. Environment variable
        env_token = os.environ.get("YUQUE_TOKEN")
        if env_token:
            return env_token
        # 2. Config file
        config_path = Path(DEFAULT_CONFIG_PATH)
        if config_path.exists():
            with open(config_path) as f:
                config = json.load(f)
            token = config.get("token")
            if token:
                return token
        raise YuqueError(
            f"语雀 token 未配置。请创建 {DEFAULT_CONFIG_PATH} 或设置 YUQUE_TOKEN\n"
            "Token 获取: https://www.yuque.com/settings/tokens"
        )

    def _headers(self):
        return {
            "X-Auth-Token": self.token,
            "Content-Type": "application/json",
            "User-Agent": "note-tool/0.1.0",
        }

    def _get(self, path: str, params: dict = None) -> dict:
        """Make a GET request to the Yuque API."""
        url = f"{YUQUE_BASE}/{path}"
        try:
            resp = self._session.get(url, headers=self._headers(),
                                     params=params, timeout=15)
            resp.raise_for_status()
            data = resp.json()
        except requests.RequestException as e:
            raise YuqueError(f"API 请求失败: {e}")
        if data.get("meta", {}).get("status") == 403:
            raise YuqueError("Token 无效或权限不足，请检查 YUQUE_TOKEN")
        return data.get("data", [])

    def _post(self, path: str, payload: dict) -> dict:
        """Make a POST request to the Yuque API."""
        url = f"{YUQUE_BASE}/{path}"
        try:
            resp = self._session.post(url, json=payload,
                                      headers=self._headers(), timeout=15)
            resp.raise_for_status()
            data = resp.json()
        except requests.RequestException as e:
            raise YuqueError(f"API 请求失败: {e}")
        return data.get("data", {})

    # ── User Info ────────────────────────────────────────────

    def get_user(self) -> str:
        """Get current user info (used for namespace resolution)."""
        try:
            data = self._get("user")
            if isinstance(data, list) and data:
                return data[0].get("login", "")
            return data.get("login", "")
        except Exception:
            return ""

    # ── Repos (知识库) ────────────────────────────────────────

    def list_repos(self) -> List[dict]:
        """List all accessible repos (知识库/notebooks)."""
        data = self._get("repos", {"type": "all"})
        if not isinstance(data, list):
            data = [data] if data else []
        return [
            {
                "id": r.get("id"),
                "name": r.get("name", "Untitled"),
                "namespace": r.get("namespace", ""),
                "slug": r.get("slug", ""),
                "description": r.get("description", ""),
                "type": r.get("type", ""),
                "toc_yml": r.get("toc_yml", ""),
                "updated_at": r.get("updated_at", ""),
            }
            for r in data
        ]

    # ── Docs ─────────────────────────────────────────────────

    def list_docs(self, namespace: str) -> List[dict]:
        """List docs in a repo given its namespace."""
        data = self._get(f"repos/{namespace}/docs")
        if not isinstance(data, list):
            data = [data] if data else []
        return [
            {
                "id": d.get("id"),
                "title": d.get("title", "Untitled"),
                "slug": d.get("slug", ""),
                "updated_at": d.get("updated_at", ""),
                "created_at": d.get("created_at", ""),
                "status": d.get("status", 0),
            }
            for d in data
        ]

    def search_docs(self, query: str, page_size: int = 20) -> List[dict]:
        """Search docs by fetching repos and filtering client-side.

        语雀 has no server-side search API, so we list all repos,
        list docs in each, and filter by title match.

        Args:
            query: Search keyword.
            page_size: Max results.

        Returns:
            List of dicts: title, slug, namespace, repo_name, updated_at
        """
        repos = self.list_repos()
        results = []
        query_lower = query.lower()

        for repo in repos:
            namespace = repo.get("namespace", "")
            if not namespace:
                continue
            try:
                docs = self.list_docs(namespace)
            except YuqueError:
                continue

            for doc in docs:
                title = doc.get("title", "")
                if query_lower in title.lower():
                    results.append({
                        "title": title,
                        "slug": doc.get("slug", ""),
                        "doc_id": doc.get("id"),
                        "namespace": namespace,
                        "repo_name": repo.get("name", ""),
                        "updated_at": doc.get("updated_at", ""),
                    })
                    if len(results) >= page_size:
                        return results

        return results

    def read_doc(self, namespace: str, slug: str) -> dict:
        """Read a doc's full content.

        Args:
            namespace: e.g. 'your_login/repo_slug'
            slug: Document slug.

        Returns:
            Dict with title, content (markdown), updated_at
        """
        data = self._get(f"repos/{namespace}/docs/{slug}")
        if not data:
            raise YuqueError(f"文档未找到: {namespace}/{slug}")

        return {
            "title": data.get("title", ""),
            "slug": data.get("slug", slug),
            "content": data.get("body", ""),   # body is markdown
            "content_html": data.get("body_html", ""),
            "updated_at": data.get("updated_at", ""),
            "created_at": data.get("created_at", ""),
            "id": data.get("id"),
        }

    def create_doc(self, namespace: str, title: str,
                   content: str = "", format: str = "markdown") -> dict:
        """Create a new doc in a repo.

        Args:
            namespace: e.g. 'your_login/repo_slug'.
            title: Doc title.
            content: Markdown body.
            format: 'markdown' or 'lake' (语雀格式).

        Returns:
            Dict with id, title, slug.
        """
        payload = {
            "title": title,
            "body": content,
            "format": format,
        }
        data = self._post(f"repos/{namespace}/docs", payload)
        return {
            "id": data.get("id"),
            "title": data.get("title", title),
            "slug": data.get("slug", ""),
        }


# ── Tool Wrapper ─────────────────────────────────────────────


class YuqueTool:
    """Hermes-compatible tool wrapper for YuqueAdapter."""

    def __init__(self, token=None):
        self.adapter = YuqueAdapter(token)

    def search(self, query):
        try:
            results = self.adapter.search_docs(query)
        except YuqueError as e:
            return f"Error: {e}"
        if not results:
            return f"没有找到与「{query}」相关的文档。"
        lines = [f"找到 {len(results)} 篇相关文档：\n"]
        for r in results:
            lines.append(f"📄 **{r['title']}**")
            lines.append(f"   Slug: {r['slug']}")
            lines.append(f"   知识库: {r['repo_name']}")
            lines.append(f"   Namespace: {r['namespace']}")
            lines.append("")
        return "\n".join(lines)

    def read(self, namespace, slug):
        try:
            doc = self.adapter.read_doc(namespace, slug)
        except YuqueError as e:
            return f"Error: {e}"
        return (
            f"# {doc['title']}\n\n"
            f"---\n- 更新: {doc.get('updated_at', '')}\n"
            f"- 创建: {doc.get('created_at', '')}\n---\n\n"
            f"{doc.get('content', '')}"
        )

    def repos(self):
        try:
            repos = self.adapter.list_repos()
        except YuqueError as e:
            return f"Error: {e}"
        if not repos:
            return "没有找到知识库。"
        lines = [f"找到 {len(repos)} 个知识库：\n"]
        for r in repos:
            lines.append(f"📚 **{r['name']}**")
            lines.append(f"   Namespace: {r['namespace']}")
            lines.append(f"   描述: {r.get('description', '')[:80]}")
            lines.append("")
        return "\n".join(lines)


# ── MCP Adapter Wrapper ──────────────────────────────────────


class YuqueMCPAdapter(NoteAdapter):
    """Wraps YuqueAdapter for MCP Server."""

    def __init__(self):
        try:
            self._tool = YuqueTool()
            self._ready = True
        except Exception:
            self._tool = None
            self._ready = False

    @property
    def platform_name(self) -> str:
        return "yuque"

    def available(self) -> bool:
        return self._ready

    def get_tools(self) -> List[ToolDef]:
        if not self._ready:
            return []
        return [
            ToolDef(
                name="yuque_search",
                description="Search 语雀 (Yuque) documents by keyword. Returns matching documents with title, slug, and repo name.",
                input_schema=make_query_schema("Search keyword for 语雀 documents"),
            ),
            ToolDef(
                name="yuque_read",
                description="Read the full content of a 语雀 document by namespace and slug. Returns content in Markdown format.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "namespace": {
                            "type": "string",
                            "description": "Document namespace, e.g. 'your_login/repo_slug'",
                        },
                        "slug": {
                            "type": "string",
                            "description": "Document slug",
                        },
                    },
                    "required": ["namespace", "slug"],
                },
            ),
            ToolDef(
                name="yuque_list_repos",
                description="List all accessible 语雀 repositories (知识库).",
            ),
        ]

    def handle_tool_call(self, tool_name: str, args: dict) -> str:
        if tool_name == "yuque_search":
            return self._tool.search(args.get("query", ""))
        elif tool_name == "yuque_read":
            return self._tool.read(
                args.get("namespace", ""),
                args.get("slug", ""),
            )
        elif tool_name == "yuque_list_repos":
            return self._tool.repos()
        else:
            return f"Unknown tool: {tool_name}"


# ── CLI Entry ────────────────────────────────────────────────


def main():
    import sys
    if len(sys.argv) < 2:
        print("Usage: note yuque <command> [args...]")
        print("Commands: search, read, repos")
        sys.exit(1)
    command = sys.argv[1]
    args = sys.argv[2:]
    tool = YuqueTool()
    if command == "search":
        result = tool.search(" ".join(args) if args else "")
    elif command == "read":
        if len(args) < 2:
            print("Usage: note yuque read <namespace> <slug>")
            sys.exit(1)
        result = tool.read(args[0], args[1])
    elif command == "repos":
        result = tool.repos()
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)
    print(result)


if __name__ == "__main__":
    main()
