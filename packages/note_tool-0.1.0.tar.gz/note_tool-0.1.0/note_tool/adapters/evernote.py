#!/usr/bin/env python3
"""Evernote (印象笔记) Adapter — Evernote Cloud API v2.

Requires:
    - pip install evernote3
    - Evernote API Key (申请: https://dev.evernote.com)
    - OAuth 1.0a authentication

API:
    Evernote uses Thrift protocol (not REST).
    The evernote3 SDK wraps the Thrift calls.

Auth flow:
    1. Get API key from dev.evernote.com (~5 business days)
    2. OAuth 1.0a: request_token → authorize → access_token
    3. Store token in ~/.evernote_config.json

Limitations:
    - API Key approval takes ~5 business days
    - SOAP/Thrift protocol is more complex than REST
    - Bending Spoons acquisition put API future in question
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import List, Optional

from note_tool.protocol import NoteAdapter, ToolDef, make_query_schema

# Default config location
DEFAULT_CONFIG_PATH = os.path.expanduser("~/.evernote_config.json")

# Note: evernote3 is optional — only needed for actual API calls
try:
    import evernote3
    from evernote3 import EvernoteClient
    from evernote.edam.type.ttypes import Note, Notebook
    from evernote.edam.error.ttypes import EDAMUserException, EDAMSystemException
    EVERNOTE_AVAILABLE = True
except ImportError:
    EVERNOTE_AVAILABLE = False


class EvernoteError(Exception):
    """Base exception for Evernote adapter errors."""
    pass


class EvernoteAdapter:
    """Adapter for Evernote Cloud API.

    NOTE: Requires `pip install evernote3` and an API Key from
    https://dev.evernote.com. The adapter will raise an error
    if the SDK is not installed or no token is configured.
    """

    def __init__(self, token: Optional[str] = None, sandbox: bool = False):
        if not EVERNOTE_AVAILABLE:
            raise EvernoteError(
                "Evernote SDK not installed. Run: pip install evernote3"
            )

        if token:
            self.token = token
        else:
            self.token = self._load_token()

        self.sandbox = sandbox
        self._client = None

    def _load_token(self) -> str:
        """Load access token from config file."""
        env_token = os.environ.get("EVERNOTE_TOKEN")
        if env_token:
            return env_token
        config_path = Path(DEFAULT_CONFIG_PATH)
        if config_path.exists():
            with open(config_path) as f:
                config = json.load(f)
            token = config.get("access_token")
            if token:
                return token
            token = config.get("token")
            if token:
                return token
        raise EvernoteError(
            "Evernote token 未配置。"
            f"请完成 OAuth 认证后创建 {DEFAULT_CONFIG_PATH}\n"
            "格式: {\"access_token\": \"your_token\"}\n"
            "API Key 申请: https://dev.evernote.com"
        )

    def _get_client(self):
        """Get or create EvernoteClient."""
        if self._client is None:
            self._client = EvernoteClient(
                token=self.token,
                sandbox=self.sandbox,
            )
        return self._client

    def _get_note_store(self):
        """Get the NoteStore for API calls."""
        client = self._get_client()
        return client.get_note_store()

    # ── Auth ─────────────────────────────────────────────────

    def auth_url(self) -> str:
        """Get the OAuth authorization URL.

        Returns the URL the user must visit to authorize access.
        """
        client = self._get_client()
        request_token = client.get_request_token(
            "https://localhost:8443/"  # callback URL
        )
        auth_url = client.get_authorize_url(request_token)
        return auth_url

    def complete_auth(self, oauth_verifier: str) -> str:
        """Complete OAuth authentication and get access token.

        Args:
            oauth_verifier: The verifier code from the auth callback.

        Returns:
            The access token string.
        """
        client = self._get_client()
        access_token = client.get_access_token(oauth_verifier)
        self.token = access_token
        # Save to config
        data = {"access_token": access_token}
        with open(DEFAULT_CONFIG_PATH, "w") as f:
            json.dump(data, f, indent=2)
        return access_token

    # ── Notebooks ────────────────────────────────────────────

    def list_notebooks(self) -> List[dict]:
        """List all notebooks."""
        note_store = self._get_note_store()
        try:
            notebooks = note_store.listNotebooks()
        except Exception as e:
            raise EvernoteError(f"列出笔记本失败: {e}")
        return [
            {
                "guid": nb.guid,
                "name": nb.name,
                "default": getattr(nb, 'defaultNotebook', False),
                "created": str(getattr(nb, 'serviceCreated', '')),
                "updated": str(getattr(nb, 'serviceUpdated', '')),
            }
            for nb in notebooks
        ]

    # ── Search ───────────────────────────────────────────────

    def search_notes(self, query: str, notebook_guid: str = None,
                     page_size: int = 20) -> List[dict]:
        """Search notes by keyword.

        Evernote has powerful search syntax: intitle:, tag:, created:,
        updated:, etc. Simple keyword search works without syntax.

        Args:
            query: Search keyword or Evernote search grammar.
            notebook_guid: Optional notebook to scope search.
            page_size: Max results.

        Returns:
            List of dicts: guid, title, notebook, created, updated, snippet
        """
        note_store = self._get_note_store()
        filter = evernote3.edam.type.ttypes.NoteFilter()

        # Build search query
        search_words = query
        if notebook_guid:
            search_words = f"notebookGuid:{notebook_guid} {search_words}"
        filter.words = search_words

        spec = evernote3.edam.type.ttypes.NotesMetadataResultSpec()
        spec.includeTitle = True
        spec.includeContentLength = True
        spec.includeUpdated = True
        spec.includeNotebookGuid = True

        try:
            meta_list = note_store.findNotesMetadata(
                filter, 0, page_size, spec
            )
        except Exception as e:
            raise EvernoteError(f"搜索笔记失败: {e}")

        results = []
        for note_meta in meta_list.notes:
            results.append({
                "guid": note_meta.guid,
                "title": note_meta.title,
                "notebook_guid": getattr(note_meta, 'notebookGuid', ''),
                "created": str(getattr(note_meta, 'created', '')),
                "updated": str(getattr(note_meta, 'updated', '')),
                "content_length": getattr(note_meta, 'contentLength', 0),
            })
        return results

    # ── Read ─────────────────────────────────────────────────

    def read_note(self, note_guid: str, with_content: bool = True) -> dict:
        """Read a note's full content.

        Evernote stores content as ENML (Evernote Markup Language),
        which is XML-based. We extract the text content.

        Args:
            note_guid: Note GUID.
            with_content: If True, fetch full content (slower).

        Returns:
            Dict with guid, title, content (plain text), created, updated,
            notebook_guid, tags.
        """
        note_store = self._get_note_store()
        try:
            note = note_store.getNote(
                note_guid,
                with_content,   # withContent
                True,           # withResourcesData
                False,          # withResourcesRecognition
                False,          # withResourcesAlternateData
            )
        except Exception as e:
            raise EvernoteError(f"读取笔记失败: {e}")

        # Extract plain text from ENML (XML)
        content = ""
        if note.content:
            content = self._enml_to_text(note.content)

        return {
            "guid": note.guid,
            "title": note.title,
            "content": content,
            "created": str(getattr(note, 'created', '')),
            "updated": str(getattr(note, 'updated', '')),
            "notebook_guid": getattr(note, 'notebookGuid', ''),
            "tags": getattr(note, 'tagNames', []),
            "url": getattr(note, 'attributes', {}).get('sourceURL', ''),
        }

    # ── Create ───────────────────────────────────────────────

    def create_note(self, notebook_guid: str, title: str,
                    content: str = "") -> dict:
        """Create a new note.

        Content is converted to ENML format.

        Args:
            notebook_guid: Target notebook GUID.
            title: Note title.
            content: Plain text content (converted to ENML).

        Returns:
            Dict with guid, title.
        """
        note_store = self._get_note_store()
        note = Note()
        note.title = title
        note.notebookGuid = notebook_guid
        note.content = self._text_to_enml(content)

        try:
            created = note_store.createNote(note)
        except Exception as e:
            raise EvernoteError(f"创建笔记失败: {e}")

        return {
            "guid": created.guid,
            "title": created.title,
        }

    # ── Helpers ──────────────────────────────────────────────

    @staticmethod
    def _enml_to_text(enml: str) -> str:
        """Extract plain text from ENML (Evernote XML format).

        Simple extraction: removes XML tags, decodes entities.
        """
        import html as html_mod
        import re
        # Remove XML tags
        text = re.sub(r'<[^>]+>', ' ', enml)
        # Decode HTML entities
        text = html_mod.unescape(text)
        # Collapse whitespace
        text = re.sub(r'\s+', ' ', text).strip()
        return text

    @staticmethod
    def _text_to_enml(text: str) -> str:
        """Convert plain text to ENML format.

        Evernote requires content wrapped in ENML.
        """
        import html as html_mod
        escaped = html_mod.escape(text)
        paragraphs = escaped.split("\n")
        body = "".join(f"<p>{p}</p>" for p in paragraphs if p.strip())
        return (
            '<?xml version="1.0" encoding="UTF-8"?>'
            '<!DOCTYPE en-note SYSTEM "http://xml.evernote.com/pub/enml2.dtd">'
            f'<en-note>{body}</en-note>'
        )


# ── Tool Wrapper ─────────────────────────────────────────────


class EvernoteTool:
    """Hermes-compatible tool wrapper for EvernoteAdapter."""

    def __init__(self, token=None):
        try:
            self.adapter = EvernoteAdapter(token)
            self._ready = True
        except EvernoteError:
            self._ready = False
            self.adapter = None

    def search(self, query):
        if not self._ready:
            return "❌ Evernote 未配置，请先完成 OAuth 认证"
        try:
            results = self.adapter.search_notes(query)
        except EvernoteError as e:
            return f"Error: {e}"
        if not results:
            return f"没有找到与「{query}」相关的笔记。"
        lines = [f"找到 {len(results)} 篇相关笔记：\n"]
        for r in results:
            lines.append(f"📄 **{r['title']}**")
            lines.append(f"   GUID: {r['guid']}")
            if r.get('content_length'):
                lines.append(f"   大小: {r['content_length']} bytes")
            lines.append("")
        return "\n".join(lines)

    def read(self, note_guid):
        if not self._ready:
            return "❌ Evernote 未配置"
        try:
            note = self.adapter.read_note(note_guid)
        except EvernoteError as e:
            return f"Error: {e}"
        return (
            f"# {note['title']}\n\n"
            f"---\n- GUID: {note['guid']}\n"
            f"- 创建: {note.get('created', '')}\n"
            f"- 更新: {note.get('updated', '')}\n"
            f"- 笔记本: {note.get('notebook_guid', '')}\n"
            f"- 标签: {', '.join(note.get('tags', []))}\n---\n\n"
            f"{note.get('content', '（内容为空）')}"
        )

    def notebooks(self):
        if not self._ready:
            return "❌ Evernote 未配置"
        try:
            notebooks = self.adapter.list_notebooks()
        except EvernoteError as e:
            return f"Error: {e}"
        if not notebooks:
            return "没有找到笔记本。"
        lines = [f"找到 {len(notebooks)} 个笔记本：\n"]
        for nb in notebooks:
            lines.append(f"📓 **{nb['name']}**")
            lines.append(f"   GUID: {nb['guid']}")
            if nb.get('default'):
                lines.append("   (默认笔记本)")
            lines.append("")
        return "\n".join(lines)


# ── MCP Adapter Wrapper ──────────────────────────────────────


class EvernoteMCPAdapter(NoteAdapter):
    """Wraps EvernoteAdapter for MCP Server."""

    def __init__(self):
        try:
            self._tool = EvernoteTool()
            self._ready = self._tool._ready
        except Exception:
            self._tool = None
            self._ready = False

    @property
    def platform_name(self) -> str:
        return "evernote"

    def available(self) -> bool:
        return self._ready

    def get_tools(self) -> List[ToolDef]:
        if not self._ready:
            return []
        return [
            ToolDef(
                name="evernote_search",
                description="Search Evernote notes by keyword. Supports Evernote search syntax (intitle:, tag:, created:). Returns matching notes with title, GUID, and content size.",
                input_schema=make_query_schema("Search keyword or Evernote query syntax"),
            ),
            ToolDef(
                name="evernote_read",
                description="Read the full content of an Evernote note by its GUID. Returns content as plain text.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "note_guid": {
                            "type": "string",
                            "description": "Evernote note GUID",
                        }
                    },
                    "required": ["note_guid"],
                },
            ),
            ToolDef(
                name="evernote_list_notebooks",
                description="List all Evernote notebooks with their GUIDs.",
            ),
        ]

    def handle_tool_call(self, tool_name: str, args: dict) -> str:
        if tool_name == "evernote_search":
            return self._tool.search(args.get("query", ""))
        elif tool_name == "evernote_read":
            return self._tool.read(args.get("note_guid", ""))
        elif tool_name == "evernote_list_notebooks":
            return self._tool.notebooks()
        else:
            return f"Unknown tool: {tool_name}"


# ── CLI Entry ────────────────────────────────────────────────


def main():
    import sys
    if len(sys.argv) < 2:
        print("Usage: note evernote <command> [args...]")
        print("Commands: search, read, notebooks")
        sys.exit(1)
    command = sys.argv[1]
    args = sys.argv[2:]
    tool = EvernoteTool()
    if command == "search":
        result = tool.search(" ".join(args) if args else "")
    elif command == "read":
        result = tool.read(args[0] if args else "")
    elif command == "notebooks":
        result = tool.notebooks()
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)
    print(result)


if __name__ == "__main__":
    main()
