#!/usr/bin/env python3
"""Notion Adapter — REST API with Integration Token.

API base: https://api.notion.com/v1
Auth: Bearer token (Internal Integration Secret)

Features:
    - Search pages/databases by title (Notion has no full-text search,
      but the /v1/search endpoint searches titles)
    - Read page content (blocks → markdown)
    - Create pages
    - List databases (useful for finding where to write)

Limitations:
    - API rate limit: 3 req/sec
    - No full-text search (searches titles only)
    - Rich content conversion is simplified (blocks → markdown)
"""

from __future__ import annotations

import json
import os
import re
import html as html_mod
from pathlib import Path
from typing import List, Optional, Dict, Any

import requests

from note_tool.protocol import NoteAdapter, ToolDef, make_query_schema

NOTION_BASE = "https://api.notion.com/v1"
NOTION_VERSION = "2022-06-28"

DEFAULT_CONFIG_PATH = os.path.expanduser("~/.notion_config.json")


class NotionError(Exception):
    """Base exception for Notion adapter errors."""
    pass


class NotionAdapter:
    """Adapter for Notion API."""

    def __init__(self, token: Optional[str] = None):
        if token:
            self.token = token
        else:
            self.token = self._load_token()
        self._session = requests.Session()

    def _load_token(self) -> str:
        env_token = os.environ.get("NOTION_TOKEN")
        if env_token:
            return env_token
        config_path = Path(DEFAULT_CONFIG_PATH)
        if config_path.exists():
            with open(config_path) as f:
                config = json.load(f)
            token = config.get("token")
            if token:
                return token
        raise NotionError(
            "Notion token 未配置。请创建 ~/.notion_config.json 或设置 NOTION_TOKEN\n"
            "Token 获取: https://www.notion.so/my-integrations"
        )

    def _headers(self):
        return {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json",
            "Notion-Version": NOTION_VERSION,
        }

    def _get(self, path: str, params: dict = None) -> dict:
        url = f"{NOTION_BASE}/{path}"
        try:
            resp = self._session.get(url, headers=self._headers(),
                                     params=params, timeout=15)
            resp.raise_for_status()
            return resp.json()
        except requests.RequestException as e:
            raise NotionError(f"API 请求失败: {e}")

    def _post(self, path: str, payload: dict) -> dict:
        url = f"{NOTION_BASE}/{path}"
        try:
            resp = self._session.post(url, json=payload,
                                      headers=self._headers(), timeout=15)
            resp.raise_for_status()
            return resp.json()
        except requests.RequestException as e:
            raise NotionError(f"API 请求失败: {e}")

    def _paginate(self, path: str, payload: dict,
                  data_key: str = "results") -> List[dict]:
        """Handle Notion pagination (cursor-based)."""
        results = []
        has_more = True
        while has_more:
            data = self._post(path, payload)
            results.extend(data.get(data_key, []))
            has_more = data.get("has_more", False)
            if has_more:
                payload["start_cursor"] = data["next_cursor"]
        return results

    # ── Search ───────────────────────────────────────────────

    def search(self, query: str, page_size: int = 20) -> List[dict]:
        """Search Notion pages and databases by title.

        Notion's /v1/search searches page titles and database titles.
        It does NOT search page body content.

        Args:
            query: Search keyword.
            page_size: Max results.

        Returns:
            List of dicts: id, title, type (page/database), url, last_edited.
        """
        payload = {
            "query": query,
            "page_size": min(page_size, 100),
            "sort": {"direction": "descending", "timestamp": "last_edited_time"},
        }
        results = self._paginate("search", payload)
        items = []
        for r in results:
            obj_type = r.get("object", "")
            props = r.get("properties", {})
            title = self._extract_title(props)

            url = r.get("url", "")
            if obj_type == "database":
                url = r.get("url", "")

            items.append({
                "id": r.get("id", ""),
                "title": title,
                "type": obj_type,
                "url": url,
                "last_edited": (
                    r.get("last_edited_time", "")
                    or props.get("last_edited_time", {}).get("last_edited_time", "")
                ),
            })
        return items

    # ── Read Page ────────────────────────────────────────────

    def read_page(self, page_id: str) -> dict:
        """Read a Notion page's properties and content.

        Args:
            page_id: The page ID (32 hex chars, with or without hyphens).

        Returns:
            Dict with title, properties, content (markdown).
        """
        page_id = self._normalize_id(page_id)
        # Get page properties
        page = self._get(f"pages/{page_id}")
        props = page.get("properties", {})
        title = self._extract_title(props)

        # Get page content blocks
        blocks = self._get_blocks(page_id)
        content = self._blocks_to_markdown(blocks)

        return {
            "id": page_id,
            "title": title,
            "url": page.get("url", ""),
            "content": content,
            "created_time": page.get("created_time", ""),
            "last_edited": page.get("last_edited_time", ""),
        }

    def _get_blocks(self, block_id: str) -> List[dict]:
        """Get all children blocks of a block/page (handles pagination)."""
        return self._paginate(
            f"blocks/{block_id}/children",
            {},
        )

    # ── List Databases ───────────────────────────────────────

    def list_databases(self) -> List[dict]:
        """List all databases the integration has access to."""
        data = self._post("databases", {})  # Notion doesn't have a list databases endpoint
        return []  # No list databases endpoint in Notion API

    # ── Create Page ──────────────────────────────────────────

    def create_page(self, parent_id: str, title: str,
                    content: str = "", is_database: bool = False) -> dict:
        """Create a new page.

        Args:
            parent_id: Parent page ID or database ID.
            title: Page title.
            content: Markdown content (converted to blocks).
            is_database: If True, parent_id is a database ID.

        Returns:
            Dict with id, title, url.
        """
        parent_id = self._normalize_id(parent_id)
        parent = {"page_id": parent_id} if not is_database else {"database_id": parent_id}

        payload = {
            "parent": parent,
            "properties": {
                "title": {
                    "title": [{"type": "text", "text": {"content": title}}]
                }
            },
            "children": self._markdown_to_blocks(content) if content else [],
        }

        result = self._post("pages", payload)
        return {
            "id": result.get("id", ""),
            "title": title,
            "url": result.get("url", ""),
        }

    # ── Helpers ──────────────────────────────────────────────

    @staticmethod
    def _normalize_id(page_id: str) -> str:
        """Normalize Notion ID (remove hyphens if present)."""
        return page_id.replace("-", "")

    @staticmethod
    def _extract_title(props: dict) -> str:
        """Extract title from Notion page properties."""
        # Try 'title' key first (most common)
        title_prop = props.get("title", {})
        if isinstance(title_prop, dict):
            title_parts = title_prop.get("title", [])
            if title_parts:
                return "".join(
                    t.get("plain_text", "") for t in title_parts
                )
        # Try any property that has 'title' type
        for key, prop in props.items():
            if isinstance(prop, dict) and prop.get("type") == "title":
                title_parts = prop.get("title", [])
                if title_parts:
                    return "".join(
                        t.get("plain_text", "") for t in title_parts
                    )
        return "Untitled"

    # ── Block → Markdown ─────────────────────────────────────

    def _blocks_to_markdown(self, blocks: List[dict], indent: int = 0) -> str:
        """Convert Notion blocks to Markdown."""
        lines = []
        prefix = "  " * indent

        for block in blocks:
            btype = block.get("type", "")
            bdata = block.get(btype, {})

            if btype == "paragraph":
                text = self._rich_text(bdata.get("rich_text", []))
                if text.strip():
                    lines.append(f"{prefix}{text}\n")

            elif btype == "heading_1":
                text = self._rich_text(bdata.get("rich_text", []))
                lines.append(f"{prefix}# {text}\n")

            elif btype == "heading_2":
                text = self._rich_text(bdata.get("rich_text", []))
                lines.append(f"{prefix}## {text}\n")

            elif btype == "heading_3":
                text = self._rich_text(bdata.get("rich_text", []))
                lines.append(f"{prefix}### {text}\n")

            elif btype == "bulleted_list_item":
                text = self._rich_text(bdata.get("rich_text", []))
                lines.append(f"{prefix}- {text}")

            elif btype == "numbered_list_item":
                text = self._rich_text(bdata.get("rich_text", []))
                lines.append(f"{prefix}1. {text}")

            elif btype == "to_do":
                text = self._rich_text(bdata.get("rich_text", []))
                checked = bdata.get("checked", False)
                box = "[x]" if checked else "[ ]"
                lines.append(f"{prefix}- {box} {text}")

            elif btype == "code":
                text = self._rich_text(bdata.get("rich_text", []))
                lang = bdata.get("language", "")
                lines.append(f"{prefix}```{lang}\n{text}\n```\n")

            elif btype == "quote":
                text = self._rich_text(bdata.get("rich_text", []))
                lines.append(f"{prefix}> {text}\n")

            elif btype == "callout":
                text = self._rich_text(bdata.get("rich_text", []))
                icon = bdata.get("icon", {}).get("emoji", "")
                lines.append(f"{prefix}> {icon} {text}\n")

            elif btype == "divider":
                lines.append(f"{prefix}---\n")

            elif btype == "image":
                caption = self._rich_text(bdata.get("caption", []))
                url = bdata.get("external", {}).get("url", "") or bdata.get("file", {}).get("url", "")
                if url:
                    alt = caption or "image"
                    lines.append(f"{prefix}![{alt}]({url})\n")

            elif btype in ("toggle", "synced_block"):
                text = self._rich_text(bdata.get("rich_text", []))
                lines.append(f"{prefix}**{text}**")
                # Process children if present
                if block.get("has_children"):
                    children = block.get("children", [])
                    if not children:
                        try:
                            children = self._get_blocks(block["id"])
                        except Exception:
                            children = []
                    child_md = self._blocks_to_markdown(children, indent + 1)
                    if child_md.strip():
                        lines.append(child_md)

            elif btype == "table":
                lines.append(f"{prefix}[表格 - 请直接在 Notion 中查看]\n")

            # Process children for nested blocks
            if block.get("has_children") and btype not in ("toggle", "synced_block"):
                try:
                    children = self._get_blocks(block["id"])
                    child_md = self._blocks_to_markdown(children, indent)
                    if child_md.strip():
                        lines.append(child_md)
                except Exception:
                    pass

        result = "".join(lines)
        result = re.sub(r"\n{3,}", "\n\n", result)
        return result.strip()

    @staticmethod
    def _rich_text(rich_text: List[dict]) -> str:
        """Convert Notion rich text to inline markdown."""
        parts = []
        for rt in rich_text:
            text = rt.get("plain_text", "")
            annotations = rt.get("annotations", {})
            if annotations.get("bold"):
                text = f"**{text}**"
            if annotations.get("italic"):
                text = f"*{text}*"
            if annotations.get("code"):
                text = f"`{text}`"
            if annotations.get("strikethrough"):
                text = f"~~{text}~~"
            href = rt.get("href")
            if href:
                text = f"[{text}]({href})"
            parts.append(text)
        return "".join(parts)

    # ── Markdown → Blocks (simplified) ───────────────────────

    @staticmethod
    def _markdown_to_blocks(markdown: str) -> List[dict]:
        """Convert simple markdown to Notion blocks.

        Simplified conversion — handles headings, paragraphs,
        bullet lists, code blocks, and dividers.
        """
        blocks = []
        lines = markdown.split("\n")
        i = 0
        while i < len(lines):
            line = lines[i]

            if line.startswith("### "):
                blocks.append({
                    "object": "block",
                    "type": "heading_3",
                    "heading_3": {
                        "rich_text": [{"type": "text", "text": {"content": line[4:]}}]
                    },
                })
            elif line.startswith("## "):
                blocks.append({
                    "object": "block",
                    "type": "heading_2",
                    "heading_2": {
                        "rich_text": [{"type": "text", "text": {"content": line[3:]}}]
                    },
                })
            elif line.startswith("# "):
                blocks.append({
                    "object": "block",
                    "type": "heading_1",
                    "heading_1": {
                        "rich_text": [{"type": "text", "text": {"content": line[2:]}}]
                    },
                })
            elif line.startswith("- "):
                blocks.append({
                    "object": "block",
                    "type": "bulleted_list_item",
                    "bulleted_list_item": {
                        "rich_text": [{"type": "text", "text": {"content": line[2:]}}]
                    },
                })
            elif line.startswith("```"):
                lang = line[3:].strip()
                code_lines = []
                i += 1
                while i < len(lines) and not lines[i].startswith("```"):
                    code_lines.append(lines[i])
                    i += 1
                code_text = "\n".join(code_lines)
                blocks.append({
                    "object": "block",
                    "type": "code",
                    "code": {
                        "rich_text": [{"type": "text", "text": {"content": code_text}}],
                        "language": lang or "plain text",
                    },
                })
            elif line.strip() == "---":
                blocks.append({
                    "object": "block",
                    "type": "divider",
                    "divider": {},
                })
            elif line.strip():
                blocks.append({
                    "object": "block",
                    "type": "paragraph",
                    "paragraph": {
                        "rich_text": [{"type": "text", "text": {"content": line.strip()}}]
                    },
                })
            i += 1

        return blocks


# ── Tool Wrapper ─────────────────────────────────────────────


class NotionTool:
    """Hermes-compatible tool wrapper for NotionAdapter."""

    def __init__(self, token=None):
        self.adapter = NotionAdapter(token)

    def search(self, query):
        try:
            results = self.adapter.search(query)
        except NotionError as e:
            return f"Error: {e}"
        if not results:
            return f"没有找到与「{query}」相关的页面。"
        lines = [f"找到 {len(results)} 篇相关页面：\n"]
        for r in results:
            lines.append(f"📄 **{r['title']}**")
            lines.append(f"   ID: {r['id']}")
            lines.append(f"   类型: {r['type']}")
            if r['url']:
                lines.append(f"   链接: {r['url']}")
            if r['last_edited']:
                lines.append(f"   编辑: {r['last_edited']}")
            lines.append("")
        return "\n".join(lines)

    def read(self, page_id):
        try:
            page = self.adapter.read_page(page_id)
        except NotionError as e:
            return f"Error: {e}"
        return (
            f"# {page['title']}\n\n"
            f"---\n- 创建: {page.get('created_time', '')}\n"
            f"- 编辑: {page.get('last_edited', '')}\n"
            f"- 链接: {page.get('url', '')}\n---\n\n"
            f"{page.get('content', '（内容为空）')}"
        )

    def create(self, parent_id, title, content=""):
        try:
            result = self.adapter.create_page(parent_id, title, content)
        except NotionError as e:
            return f"Error: {e}"
        return (
            f"✅ 页面已创建\n"
            f"   标题: {result['title']}\n"
            f"   链接: {result['url']}"
        )


# ── MCP Adapter Wrapper ──────────────────────────────────────


class NotionMCPAdapter(NoteAdapter):
    """Wraps NotionAdapter for MCP Server."""

    def __init__(self):
        try:
            self._tool = NotionTool()
            self._ready = True
        except Exception:
            self._tool = None
            self._ready = False

    @property
    def platform_name(self) -> str:
        return "notion"

    def available(self) -> bool:
        return self._ready

    def get_tools(self) -> List[ToolDef]:
        if not self._ready:
            return []
        return [
            ToolDef(
                name="notion_search",
                description="Search Notion pages and databases by title. Note: searches titles only, not page body content. Returns matching items with ID, URL, and last edit time.",
                input_schema=make_query_schema("Search keyword for Notion pages"),
            ),
            ToolDef(
                name="notion_read",
                description="Read the full content of a Notion page by its page ID. Returns content converted to Markdown format.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "page_id": {
                            "type": "string",
                            "description": "Notion page ID (32 hex chars)",
                        }
                    },
                    "required": ["page_id"],
                },
            ),
            ToolDef(
                name="notion_create",
                description="Create a new Notion page as a child of an existing page.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "parent_id": {
                            "type": "string",
                            "description": "ID of the parent page",
                        },
                        "title": {
                            "type": "string",
                            "description": "Title of the new page",
                        },
                        "content": {
                            "type": "string",
                            "description": "Optional markdown content for the page body",
                        },
                    },
                    "required": ["parent_id", "title"],
                },
            ),
        ]

    def handle_tool_call(self, tool_name: str, args: dict) -> str:
        if tool_name == "notion_search":
            return self._tool.search(args.get("query", ""))
        elif tool_name == "notion_read":
            return self._tool.read(args.get("page_id", ""))
        elif tool_name == "notion_create":
            return self._tool.create(
                args.get("parent_id", ""),
                args.get("title", ""),
                args.get("content", ""),
            )
        else:
            return f"Unknown tool: {tool_name}"


# ── CLI Entry ────────────────────────────────────────────────


def main():
    import sys
    if len(sys.argv) < 2:
        print("Usage: note notion <command> [args...]")
        print("Commands: search, read, create")
        sys.exit(1)
    command = sys.argv[1]
    args = sys.argv[2:]
    tool = NotionTool()
    if command == "search":
        result = tool.search(" ".join(args) if args else "")
    elif command == "read":
        result = tool.read(args[0] if args else "")
    elif command == "create":
        if len(args) < 2:
            print("Usage: note notion create <parent_id> <title>")
            sys.exit(1)
        result = tool.create(args[0], " ".join(args[1:]))
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)
    print(result)


if __name__ == "__main__":
    main()
