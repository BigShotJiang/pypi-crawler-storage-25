#!/usr/bin/env python3
"""OneNote Adapter Tool — Hermes Agent tool + CLI entry point.

Usage as CLI:
    note onenote login                          # authenticate
    note onenote notebooks                      # list notebooks
    note onenote sections [notebook_id]          # list sections
    note onenote search <query>                 # search notes
    note onenote read <page_id>                 # read page
    note onenote create <section_id> "<title>"  # create page
    note onenote status                         # auth status

Usage as Hermes tool:
    Import OneNoteTool and use its methods.
"""

from __future__ import annotations

import sys
import os

if __name__ == "__main__":
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from note_tool.adapters.onenote import (
    OneNoteAdapter,
    OneNoteError,
    AuthCancelled,
)
from note_tool.protocol import NoteAdapter, ToolDef, make_query_schema


class OneNoteTool:
    """Hermes-compatible tool wrapper for OneNoteAdapter."""

    def __init__(self, config_path=None):
        self.adapter = OneNoteAdapter(config_path)

    def login(self):
        """Interactive OAuth device code flow."""
        try:
            self.adapter.auth(interactive=True)
            return "✅ OneNote 认证成功！Token 已缓存到 ~/.onetool_token.json"
        except AuthCancelled as e:
            return f"⏹  认证已取消：{e}"
        except OneNoteError as e:
            return f"❌ 认证失败：{e}"

    def notebooks(self):
        """List all OneNote notebooks."""
        try:
            notebooks = self.adapter.list_notebooks()
        except OneNoteError as e:
            return f"Error: {e}"

        if not notebooks:
            return "没有找到笔记本。"

        lines = [f"找到 {len(notebooks)} 个笔记本：\n"]
        for n in notebooks:
            lines.append(f"📓 **{n['display_name']}**")
            lines.append(f"   ID: {n['id']}")
            lines.append(f"   创建: {n['created_time']}")
            if n['url']:
                lines.append(f"   链接: {n['url']}")
            lines.append("")
        return "\n".join(lines)

    def sections(self, notebook_id=None):
        """List sections, optionally filtered by notebook."""
        try:
            sections = self.adapter.list_sections(notebook_id)
        except OneNoteError as e:
            return f"Error: {e}"

        if not sections:
            return "没有找到分区。"

        lines = []
        if notebook_id:
            lines.append(f"笔记本 {notebook_id} 的分区：\n")
        else:
            lines.append(f"找到 {len(sections)} 个分区：\n")

        for s in sections:
            lines.append(f"📂 **{s['display_name']}**")
            lines.append(f"   ID: {s['id']}")
            if s['notebook_name']:
                lines.append(f"   笔记本: {s['notebook_name']}")
            lines.append(f"   页面数: {s['page_count']}")
            lines.append("")
        return "\n".join(lines)

    def search(self, query):
        """Search OneNote pages."""
        try:
            results = self.adapter.search_notes(query)
        except OneNoteError as e:
            return f"Error: {e}"

        if not results:
            return f"没有找到与「{query}」相关的笔记。"

        lines = [f"找到 {len(results)} 篇相关笔记：\n"]
        for r in results:
            lines.append(f"📄 **{r['title']}**")
            lines.append(f"   ID: {r['id']}")
            if r['notebook']:
                lines.append(f"   笔记本: {r['notebook']}")
            if r['section']:
                lines.append(f"   分区: {r['section']}")
            if r['created_time']:
                lines.append(f"   创建: {r['created_time']}")
            if r['url']:
                lines.append(f"   链接: {r['url']}")
            lines.append("")
        return "\n".join(lines)

    def read(self, page_id):
        """Read a OneNote page's full content."""
        try:
            note = self.adapter.read_note(page_id)
        except OneNoteError as e:
            return f"Error: {e}"

        header = (
            f"# {note['title']}\n\n"
            f"---\n"
            f"- 创建时间: {note.get('created_time', 'N/A')}\n"
            f"- 最后修改: {note.get('last_modified', 'N/A')}\n"
            f"---\n\n"
        )
        content = note.get("content", "（内容为空）")
        return header + content

    def create(self, section_id, title):
        """Create a new OneNote page (opens editor for content)."""
        try:
            # Create with empty body first; user can edit later
            result = self.adapter.create_note(section_id, title, "")
        except OneNoteError as e:
            return f"Error: {e}"

        return (
            f"✅ 笔记已创建\n"
            f"   标题: {result['title']}\n"
            f"   ID: {result['id']}\n"
            f"   链接: {result['url']}"
        )

    def status(self):
        """Show authentication status."""
        status = self.adapter.auth_status()
        if status["status"] == "authenticated":
            mins = status["expires_in"] // 60
            refresh = "有" if status["has_refresh"] else "无"
            return (
                f"✅ 已认证\n"
                f"   过期时间: {mins} 分钟后\n"
                f"   刷新令牌: {refresh}"
            )
        elif status["status"] == "expired":
            return "⚠️  令牌已过期，下次 API 调用会自动刷新"
        else:
            return "❌ 未认证。运行 `note onenote login` 进行认证"


# ── CLI Entry ────────────────────────────────────────────────

COMMANDS = {
    "login": "login",
    "notebooks": "notebooks",
    "sections": "sections",
    "search": "search",
    "read": "read",
    "create": "create",
    "status": "status",
}


def main():
    if len(sys.argv) < 2:
        print("Usage: note onenote <command> [args...]")
        print(f"Commands: {', '.join(COMMANDS.keys())}")
        print("\nExamples:")
        print("  note onenote login")
        print("  note onenote notebooks")
        print('  note onenote search "AI"')
        sys.exit(1)

    command = sys.argv[1]
    args = sys.argv[2:]

    if command not in COMMANDS:
        print(f"Unknown command: {command}")
        print(f"Available: {', '.join(COMMANDS.keys())}")
        sys.exit(1)

    tool = OneNoteTool()

    if command == "login":
        result = tool.login()
    elif command == "notebooks":
        result = tool.notebooks()
    elif command == "sections":
        notebook_id = args[0] if args else None
        result = tool.sections(notebook_id)
    elif command == "search":
        if not args:
            print("Usage: note onenote search <query>")
            sys.exit(1)
        result = tool.search(" ".join(args))
    elif command == "read":
        if not args:
            print("Usage: note onenote read <page_id>")
            sys.exit(1)
        result = tool.read(args[0])
    elif command == "create":
        if len(args) < 2:
            print("Usage: note onenote create <section_id> \"<title>\"")
            sys.exit(1)
        result = tool.create(args[0], " ".join(args[1:]))
    elif command == "status":
        result = tool.status()
    else:
        result = "Unknown command"

    print(result)


if __name__ == "__main__":
    main()


# ── MCP Adapter Wrapper ──────────────────────────────────────


class OneNoteMCPAdapter(NoteAdapter):
    """Wraps OneNoteTool as a NoteAdapter for MCP Server."""

    def __init__(self):
        try:
            self._tool = OneNoteTool()
            self._ready = True
        except Exception:
            self._tool = None
            self._ready = False

    @property
    def platform_name(self) -> str:
        return "onenote"

    def available(self) -> bool:
        if not self._ready or not self._tool:
            return False
        try:
            status = self._tool.adapter.auth_status()
            return status["status"] == "authenticated"
        except Exception:
            return False

    def get_tools(self) -> list[ToolDef]:
        if not self._ready or not self._tool:
            return []
        return [
            ToolDef(
                name="onenote_search",
                description="Search OneNote notes by keyword. Returns matching notes with title, notebook, section, and URL.",
                input_schema=make_query_schema("Search query for OneNote notes"),
            ),
            ToolDef(
                name="onenote_read",
                description="Read the full content of a OneNote page by its page ID. Returns content in Markdown format.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "page_id": {
                            "type": "string",
                            "description": "The OneNote page ID to read",
                        }
                    },
                    "required": ["page_id"],
                },
            ),
            ToolDef(
                name="onenote_list_notebooks",
                description="List all OneNote notebooks with their IDs and creation dates.",
            ),
            ToolDef(
                name="onenote_list_sections",
                description="List sections in a notebook or all sections across notebooks.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "notebook_id": {
                            "type": "string",
                            "description": "Optional notebook ID to filter sections by",
                        }
                    },
                },
            ),
            ToolDef(
                name="onenote_create",
                description="Create a new page in a OneNote section.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "section_id": {
                            "type": "string",
                            "description": "The section ID to create the page in",
                        },
                        "title": {
                            "type": "string",
                            "description": "Title of the new page",
                        },
                    },
                    "required": ["section_id", "title"],
                },
            ),
        ]

    def handle_tool_call(self, tool_name: str, args: dict) -> str:
        if tool_name == "onenote_search":
            return self._tool.search(args.get("query", ""))
        elif tool_name == "onenote_read":
            return self._tool.read(args.get("page_id", ""))
        elif tool_name == "onenote_list_notebooks":
            return self._tool.notebooks()
        elif tool_name == "onenote_list_sections":
            return self._tool.sections(args.get("notebook_id"))
        elif tool_name == "onenote_create":
            return self._tool.create(
                args.get("section_id", ""),
                args.get("title", ""),
            )
        else:
            return f"Unknown tool: {tool_name}"
