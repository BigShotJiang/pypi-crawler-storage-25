#!/usr/bin/env python3
"""OneNote Adapter via Microsoft Graph API.

Provides search, read, and create operations for OneNote notebooks
via the Graph API. Uses OAuth 2.0 Device Code flow for CLI-friendly
authentication.

Auth flow:
  1. Request device code -> user visits https://microsoft.com/devicelogin
  2. Poll for token -> receive access_token + refresh_token
  3. Cache tokens ~/.onetool_token.json
  4. Auto-refresh when expired
"""

import json
import os
import time
import re
import html
from pathlib import Path
from urllib.parse import quote, urlencode

import requests

GRAPH_BASE = "https://graph.microsoft.com/v1.0/me/onenote"
AUTH_BASE = "https://login.microsoftonline.com/common/oauth2/v2.0"

# Default token cache location
DEFAULT_TOKEN_CACHE = os.path.expanduser("~/.onetool_token.json")

# Default config location (for client_id / client_secret)
DEFAULT_CONFIG_PATH = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "..", "..", "config.json"
)

# Scopes needed for OneNote access
DEFAULT_SCOPES = "Notes.ReadWrite.All offline_access"


class OneNoteError(Exception):
    """Base exception for OneNote adapter errors."""
    pass


class AuthCancelled(OneNoteError):
    """User cancelled the device code auth flow."""
    pass


# ── HTML → Markdown ──────────────────────────────────────────

def _html_to_markdown(html_text):
    """Convert OneNote HTML to basic Markdown.

    OneNote's page content API returns HTML. This converter handles
    the most common elements. Not a full HTML parser — trades fidelity
    for simplicity (v1).
    """
    if not html_text:
        return ""

    text = html_text

    # Remove <head> and <style>
    text = re.sub(r'<head[^>]*>.*?</head>', '', text, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r'<style[^>]*>.*?</style>', '', text, flags=re.DOTALL | re.IGNORECASE)

    # Headings
    for i in range(1, 7):
        text = re.sub(
            rf'<h{i}[^>]*>(.*?)</h{i}>',
            lambda m: '\n' + '#' * i + ' ' + _strip_html_tags(m.group(1)).strip() + '\n',
            text, flags=re.DOTALL | re.IGNORECASE
        )

    # Bold / italic (word boundary to avoid matching <body>/<iframe> etc.)
    text = re.sub(r'<(?:b\b|strong)[^>]*>(.*?)</(?:b\b|strong)>', r'**\1**', text, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r'<(?:i\b|em)[^>]*>(.*?)</(?:i\b|em)>', r'*\1*', text, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r'<u[^>]*>(.*?)</u>', r'__\1__', text, flags=re.DOTALL | re.IGNORECASE)

    # Links
    text = re.sub(
        r'<a[^>]*href=[\'"]([^\'"]+)[\'"][^>]*>(.*?)</a>',
        r'[\2](\1)',
        text, flags=re.DOTALL | re.IGNORECASE
    )

    # Images → placeholder
    text = re.sub(r'<img[^>]*src=[\'"]([^\'"]+)[\'"][^>]*alt=[\'"]([^\'"]+)[\'"][^>]*/>',
                  r'![\2](\1)', text, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r'<img[^>]*src=[\'"]([^\'"]+)[\'"][^>]*/?>',
                  r'![image](\1)', text, flags=re.DOTALL | re.IGNORECASE)

    # Horizontal rules
    text = re.sub(r'<hr[^>]*/?>', '\n---\n', text, flags=re.IGNORECASE)

    # Pre / code blocks (process BEFORE inline <code> to avoid double-conversion)
    text = re.sub(
        r'<pre[^>]*>(.*?)</pre>',
        lambda m: '\n```\n' + _strip_html_tags(m.group(1)).strip() + '\n```\n',
        text, flags=re.DOTALL | re.IGNORECASE
    )

    # Code (inline) — only for <code> not inside <pre>
    text = re.sub(r'<code[^>]*>(.*?)</code>', r'`\1`', text, flags=re.DOTALL | re.IGNORECASE)

    # List items — process BEFORE removing list wrappers
    text = re.sub(
        r'<li[^>]*>\s*(?:<p[^>]*>)?\s*(.*?)\s*(?:</p>)?\s*</li>',
        lambda m: '\n- ' + _strip_html_tags(m.group(1)).strip(),
        text, flags=re.DOTALL | re.IGNORECASE
    )

    # Remove list wrappers (preserve inner content)
    text = re.sub(r'</?ol[^>]*>', '\n', text, flags=re.IGNORECASE)
    text = re.sub(r'</?ul[^>]*>', '\n', text, flags=re.IGNORECASE)

    # Paragraphs
    text = re.sub(r'<p[^>]*>(.*?)</p>', r'\1\n\n', text, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r'<div[^>]*>(.*?)</div>', r'\1\n', text, flags=re.DOTALL | re.IGNORECASE)

    # Line breaks
    text = re.sub(r'<br\s*/?>', '\n', text, flags=re.IGNORECASE)

    # Horizontal rules
    text = re.sub(r'<hr[^>]*/?>', '\n---\n', text, flags=re.IGNORECASE)

    # Strip remaining HTML tags
    text = re.sub(r'<[^>]+>', '', text)

    # Decode HTML entities
    text = html.unescape(text)

    # Collapse multiple blank lines
    text = re.sub(r'\n{3,}', '\n\n', text)

    # Strip leading/trailing whitespace
    text = text.strip()

    return text


def _strip_html_tags(text):
    """Remove HTML tags from a string, preserving text content."""
    text = re.sub(r'<[^>]+>', '', text)
    text = html.unescape(text)
    return text


# ── OneNoteAdapter ───────────────────────────────────────────

class OneNoteAdapter:
    """Adapter for OneNote via Microsoft Graph API.

    Args:
        config_path: Path to JSON config with 'client_id' and optional 'client_secret'.
        token_cache_path: Path to store/read OAuth tokens.
        scopes: OAuth scopes to request.
    """

    def __init__(self, config_path=None, token_cache_path=None, scopes=None):
        self.config_path = config_path or DEFAULT_CONFIG_PATH
        self.token_cache_path = token_cache_path or DEFAULT_TOKEN_CACHE
        self.scopes = scopes or DEFAULT_SCOPES
        self._load_config()
        self._load_tokens()
        self._session = requests.Session()

    # ── Config ────────────────────────────────────────────────

    def _load_config(self):
        """Load Azure AD app credentials from config file."""
        path = Path(self.config_path)
        if not path.exists():
            # Also try the user's home config
            home_config = os.path.expanduser("~/.onetool_config.json")
            path = Path(home_config)
            if not path.exists():
                raise OneNoteError(
                    f"Config file not found at {self.config_path} or {home_config}\n"
                    "Create a JSON file with: {\"client_id\": \"...\"}"
                )
        with open(path) as f:
            config = json.load(f)
        self.client_id = config.get("client_id")
        if not self.client_id:
            raise OneNoteError(
                "Config must contain 'client_id' (Azure AD app client ID)"
            )
        self.client_secret = config.get("client_secret")

    # ── Token Persistence ─────────────────────────────────────

    def _load_tokens(self):
        """Load cached tokens from disk."""
        path = Path(self.token_cache_path)
        if path.exists():
            with open(path) as f:
                data = json.load(f)
            self.access_token = data.get("access_token")
            self.refresh_token = data.get("refresh_token")
            self.token_expire = data.get("expires_at", 0)
        else:
            self.access_token = None
            self.refresh_token = None
            self.token_expire = 0

    def _save_tokens(self, access_token, refresh_token, expires_in):
        """Save tokens to disk cache."""
        data = {
            "access_token": access_token,
            "refresh_token": refresh_token,
            "expires_at": time.time() + expires_in,
        }
        with open(self.token_cache_path, "w") as f:
            json.dump(data, f, indent=2)
        self.access_token = access_token
        self.refresh_token = refresh_token
        self.token_expire = data["expires_at"]

    def _clear_tokens(self):
        """Remove cached tokens."""
        path = Path(self.token_cache_path)
        if path.exists():
            path.unlink()
        self.access_token = None
        self.refresh_token = None
        self.token_expire = 0

    # ── Auth ──────────────────────────────────────────────────

    def _request_device_code(self):
        """Step 1: Request a device code from Azure AD.

        Returns:
            Dict with device_code, user_code, verification_uri, interval, expires_in
        """
        url = f"{AUTH_BASE}/devicecode"
        payload = {
            "client_id": self.client_id,
            "scope": self.scopes,
        }
        try:
            resp = requests.post(url, data=payload, timeout=10)
            resp.raise_for_status()
            return resp.json()
        except requests.RequestException as e:
            raise OneNoteError(f"Device code request failed: {e}")

    def _poll_for_token(self, device_code, interval=5, timeout=300):
        """Step 3: Poll Azure AD until user completes login.

        Args:
            device_code: The device code from step 1.
            interval: Polling interval in seconds.
            timeout: Max seconds to wait.

        Returns:
            Dict with access_token, refresh_token, expires_in
        """
        url = f"{AUTH_BASE}/token"
        payload = {
            "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
            "code": device_code,
            "client_id": self.client_id,
        }

        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                resp = requests.post(url, data=payload, timeout=10)
                data = resp.json()
            except requests.RequestException as e:
                raise OneNoteError(f"Token poll error: {e}")

            if "access_token" in data:
                return data

            error = data.get("error", "")
            if error == "authorization_pending":
                time.sleep(interval)
                continue
            elif error == "authorization_declined":
                raise AuthCancelled("User declined the authentication request.")
            elif error == "expired_token":
                raise AuthCancelled("Device code expired. Please try again.")
            else:
                time.sleep(interval)

        raise AuthCancelled("Timed out waiting for authentication.")

    def _refresh_token(self):
        """Refresh the access token using the refresh token."""
        if not self.refresh_token:
            raise OneNoteError("No refresh token available. Re-authenticate.")

        url = f"{AUTH_BASE}/token"
        payload = {
            "grant_type": "refresh_token",
            "refresh_token": self.refresh_token,
            "client_id": self.client_id,
            "scope": self.scopes,
        }
        try:
            resp = requests.post(url, data=payload, timeout=10)
            resp.raise_for_status()
            data = resp.json()
        except requests.RequestException as e:
            # Refresh failed, force re-auth
            self._clear_tokens()
            raise OneNoteError(f"Token refresh failed: {e}. Re-authenticate.")

        new_refresh = data.get("refresh_token", self.refresh_token)
        self._save_tokens(
            data["access_token"],
            new_refresh,
            data.get("expires_in", 3600),
        )

    def auth(self, interactive=False):
        """Get a valid access token.

        Priority:
          1. Return cached token if still valid.
          2. Refresh if expired but refresh_token exists.
          3. If interactive=True, start device code flow.
          4. Raise error if no valid token.

        Args:
            interactive: If True, prompt user via device code flow.

        Returns:
            Access token string.
        """
        # 1. Cached token still valid (5 min buffer)
        if self.access_token and time.time() < self.token_expire - 300:
            return self.access_token

        # 2. Try refresh
        if self.refresh_token:
            try:
                self._refresh_token()
                return self.access_token
            except OneNoteError:
                if not interactive:
                    raise OneNoteError(
                        "Token expired and refresh failed. "
                        "Call auth(interactive=True) or re-run with --login"
                    )

        # 3. Interactive device code flow
        if not interactive:
            raise OneNoteError(
                "No valid token. Call auth(interactive=True) or run `note onenote login`"
            )

        print("🔑 Requesting OneNote access...")
        device = self._request_device_code()
        print(f"\n👉 Go to: {device.get('verification_uri', 'https://microsoft.com/devicelogin')}")
        print(f"   Enter code: {device['user_code']}")
        print(f"   (expires in {device.get('expires_in', 900)} seconds)\n")

        token_data = self._poll_for_token(
            device["device_code"],
            interval=device.get("interval", 5),
        )
        self._save_tokens(
            token_data["access_token"],
            token_data.get("refresh_token"),
            token_data.get("expires_in", 3600),
        )
        print("✅ Authentication successful!")
        return self.access_token

    # ── Headers ───────────────────────────────────────────────

    def _headers(self):
        """Build auth headers."""
        token = self.auth(interactive=False)
        return {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        }

    def _headers_html(self):
        """Build headers for HTML content requests (pages/content)."""
        token = self.auth(interactive=False)
        return {
            "Authorization": f"Bearer {token}",
        }

    # ── Notebooks ─────────────────────────────────────────────

    def list_notebooks(self):
        """List all OneNote notebooks.

        Returns:
            List of dicts: id, display_name, created_by, created_time, url
        """
        url = f"{GRAPH_BASE}/notebooks"
        try:
            resp = requests.get(url, headers=self._headers(), timeout=15)
            resp.raise_for_status()
            data = resp.json()
        except requests.RequestException as e:
            raise OneNoteError(f"List notebooks failed: {e}")

        items = data.get("value", [])
        return [
            {
                "id": n.get("id"),
                "display_name": n.get("displayName", "Untitled"),
                "created_by": (
                    n.get("createdBy", {})
                     .get("user", {})
                     .get("displayName", "")
                ),
                "created_time": n.get("createdTime", ""),
                "url": n.get("links", {})
                        .get("oneNoteClientUrl", {})
                        .get("href", ""),
            }
            for n in items
        ]

    # ── Sections ──────────────────────────────────────────────

    def list_sections(self, notebook_id=None):
        """List sections, optionally filtered by notebook.

        Args:
            notebook_id: If set, list sections in this notebook only.

        Returns:
            List of dicts: id, display_name, notebook_name, page_count
        """
        if notebook_id:
            url = f"{GRAPH_BASE}/notebooks/{notebook_id}/sections"
        else:
            url = f"{GRAPH_BASE}/sections"

        try:
            resp = requests.get(url, headers=self._headers(), timeout=15)
            resp.raise_for_status()
            data = resp.json()
        except requests.RequestException as e:
            raise OneNoteError(f"List sections failed: {e}")

        items = data.get("value", [])
        return [
            {
                "id": s.get("id"),
                "display_name": s.get("displayName", "Untitled"),
                "notebook_name": (
                    s.get("parentNotebook", {}).get("displayName", "")
                ),
                "page_count": s.get("pageCount", 0),
            }
            for s in items
        ]

    # ── Search ────────────────────────────────────────────────

    def search_notes(self, query, page_size=25):
        """Search OneNote pages by query string.

        Uses Graph API's $search OData parameter.

        Args:
            query: Search keywords.
            page_size: Max results to return (default 25).

        Returns:
            List of dicts: id, title, notebook, section, created_time, last_modified, url, preview
        """
        encoded = quote(query)
        url = f"{GRAPH_BASE}/pages?$search=\"{encoded}\"&$top={page_size}"
        try:
            resp = requests.get(url, headers=self._headers(), timeout=15)
            resp.raise_for_status()
            data = resp.json()
        except requests.RequestException as e:
            raise OneNoteError(f"Search notes failed: {e}")

        items = data.get("value", [])
        results = []
        for p in items:
            title = p.get("title", "Untitled")
            # Extract preview from contentUrl or snippet
            content_url = p.get("contentUrl", "")
            links = p.get("links", {})
            client_url = (
                links.get("oneNoteClientUrl", {}).get("href", "")
            )

            results.append({
                "id": p.get("id"),
                "title": title,
                "notebook": (
                    p.get("parentNotebook", {}).get("displayName", "")
                ),
                "section": (
                    p.get("parentSection", {}).get("displayName", "")
                ),
                "created_time": p.get("createdTime", ""),
                "last_modified": p.get("lastModifiedTime", ""),
                "url": client_url,
                "content_url": content_url,
            })

        return results

    # ── Read ──────────────────────────────────────────────────

    def read_note(self, page_id):
        """Read a OneNote page's full content.

        The API returns HTML; we convert to Markdown.

        Args:
            page_id: The page ID.

        Returns:
            Dict with title, content (markdown), created_time, last_modified
        """
        url = f"{GRAPH_BASE}/pages/{page_id}/content"
        try:
            resp = requests.get(url, headers=self._headers_html(), timeout=20)
            resp.raise_for_status()
            html_content = resp.text
        except requests.RequestException as e:
            raise OneNoteError(f"Read note failed: {e}")

        # Also get page metadata
        meta_url = f"{GRAPH_BASE}/pages/{page_id}"
        try:
            meta_resp = requests.get(meta_url, headers=self._headers(), timeout=10)
            meta_resp.raise_for_status()
            meta = meta_resp.json()
        except (requests.RequestException, ValueError):
            meta = {}

        title = meta.get("title", "Untitled")
        created = meta.get("createdTime", "")
        modified = meta.get("lastModifiedTime", "")
        markdown = _html_to_markdown(html_content)

        return {
            "id": page_id,
            "title": title,
            "content": markdown,
            "created_time": created,
            "last_modified": modified,
        }

    # ── Create ────────────────────────────────────────────────

    def create_note(self, section_id, title, content_markdown):
        """Create a new page in a section.

        The API expects HTML body. We wrap the markdown in
        basic HTML.

        Args:
            section_id: The section to create the page in.
            title: Page title.
            content_markdown: Page body in Markdown (converted to HTML).

        Returns:
            Dict with id, title, url
        """
        # Simple markdown → HTML conversion (basic)
        html_body = _markdown_to_html(title, content_markdown)

        url = f"{GRAPH_BASE}/sections/{section_id}/pages"
        headers = self._headers()
        headers["Content-Type"] = "text/html"

        try:
            resp = requests.post(url, data=html_body.encode("utf-8"),
                                 headers=headers, timeout=20)
            resp.raise_for_status()
            data = resp.json()
        except requests.RequestException as e:
            raise OneNoteError(f"Create note failed: {e}")

        doc_id = data.get("id", "")
        links = data.get("links", {})
        client_url = (
            links.get("oneNoteClientUrl", {}).get("href", "")
        )

        return {
            "id": doc_id,
            "title": data.get("title", title),
            "url": client_url,
        }

    # ── Auth status ───────────────────────────────────────────

    def auth_status(self):
        """Return current auth status (safe, no API call)."""
        if self.access_token and time.time() < self.token_expire:
            remaining = int(self.token_expire - time.time())
            return {
                "status": "authenticated",
                "expires_in": remaining,
                "has_refresh": bool(self.refresh_token),
            }
        elif self.refresh_token:
            return {
                "status": "expired",
                "expires_in": 0,
                "has_refresh": True,
                "message": "Token expired. Auto-refresh on next API call.",
            }
        else:
            return {
                "status": "not_authenticated",
                "expires_in": 0,
                "has_refresh": False,
                "message": "Run `note onenote login` to authenticate.",
            }


# ── Markdown → HTML (simple) ─────────────────────────────────

def _markdown_to_html(title, markdown_text):
    """Convert markdown body to OneNote-compatible HTML.

    Simple conversion for basic formatting. Not a full parser.
    """
    lines = markdown_text.split("\n")
    html_parts = [
        "<!DOCTYPE html>",
        "<html>",
        "<head>",
        f"<title>{html.escape(title)}</title>",
        "</head>",
        "<body>",
    ]

    in_code_block = False
    in_list = False
    code_buffer = []

    for line in lines:
        # Code block handling
        if line.startswith("```"):
            if in_code_block:
                html_parts.append(f"<pre><code>{html.escape(chr(10).join(code_buffer))}</code></pre>")
                code_buffer = []
                in_code_block = False
            else:
                in_code_block = True
            continue

        if in_code_block:
            code_buffer.append(line)
            continue

        # Headings
        if line.startswith("### "):
            if in_list:
                html_parts.append("</ol>")
                in_list = False
            html_parts.append(f"<h3>{html.escape(line[4:])}</h3>")
        elif line.startswith("## "):
            if in_list:
                html_parts.append("</ol>")
                in_list = False
            html_parts.append(f"<h2>{html.escape(line[3:])}</h2>")
        elif line.startswith("# "):
            if in_list:
                html_parts.append("</ol>")
                in_list = False
            html_parts.append(f"<h1>{html.escape(line[2:])}</h1>")

        # Horizontal rule
        elif line.strip() == "---":
            if in_list:
                html_parts.append("</ol>")
                in_list = False
            html_parts.append("<hr />")

        # Empty line
        elif not line.strip():
            if in_list:
                html_parts.append("</ol>")
                in_list = False
            html_parts.append("<p>&nbsp;</p>")

        # List items
        elif line.strip().startswith("- "):
            if not in_list:
                html_parts.append("<ol>")
                in_list = True
            text = line.strip()[2:]
            html_parts.append(f"<li><p>{_inline_md_to_html(text)}</p></li>")

        # Regular paragraph
        else:
            if in_list:
                html_parts.append("</ol>")
                in_list = False
            html_parts.append(f"<p>{_inline_md_to_html(line.strip())}</p>")

    if in_code_block:
        html_parts.append(f"<pre><code>{html.escape(chr(10).join(code_buffer))}</code></pre>")
    if in_list:
        html_parts.append("</ol>")

    html_parts.append("</body>")
    html_parts.append("</html>")

    return "\n".join(html_parts)


def _inline_md_to_html(text):
    """Convert inline markdown formatting to HTML."""
    # Bold
    text = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', text)
    # Italic
    text = re.sub(r'\*(.+?)\*', r'<i>\1</i>', text)
    # Code
    text = re.sub(r'`(.+?)`', r'<code>\1</code>', text)
    # Links
    text = re.sub(r'\[(.+?)\]\((.+?)\)', r'<a href="\2">\1</a>', text)
    return text
