#!/usr/bin/env python3
"""
Feishu Adapter Tool — Hermes Agent tool + CLI entry point.

Usage as CLI:
    python feishu_tool.py search <query>
    python feishu_tool.py read <doc_token>
    python feishu_tool.py create <title>

Usage as Hermes tool:
    Import FeishuTool from this module and register the methods
    as Hermes tools.
"""

from __future__ import annotations

import sys
import os

# Allow running as script or import from parent
if __name__ == "__main__":
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from note_tool.adapters.feishu import FeishuAdapter, FeishuError
from note_tool.protocol import NoteAdapter, ToolDef, make_query_schema


class FeishuTool:
    """Hermes-compatible tool wrapper for FeishuAdapter."""

    def __init__(self, config_path=None):
        self.adapter = FeishuAdapter(config_path)

    def search(self, query):
        """Search Feishu documents. Returns formatted string."""
        try:
            results = self.adapter.search_docs(query)
        except FeishuError as e:
            return f"Error: {e}"

        if not results:
            return f"没有找到与「{query}」相关的文档。"

        lines = [f"找到 {len(results)} 篇相关文档：\n"]
        for r in results:
            title = r.get("title", "无标题")
            url = r.get("url", "")
            summary = r.get("summary", "")
            doc_token = r.get("doc_token", "")
            lines.append(f"📄 **{title}**")
            lines.append(f"   Token: {doc_token}")
            if summary:
                lines.append(f"   摘要: {summary[:120]}...")
            if url:
                lines.append(f"   链接: {url}")
            lines.append("")
        return "\n".join(lines)

    def read(self, doc_token):
        """Read Feishu document content. Returns Markdown."""
        try:
            content = self.adapter.get_doc_content(doc_token)
        except FeishuError as e:
            return f"Error: {e}"
        return content if content else "（文档内容为空）"

    def create(self, title):
        """Create a new Feishu document. Returns confirmation."""
        try:
            result = self.adapter.create_doc(title)
        except FeishuError as e:
            return f"Error: {e}"

        doc_id = result["document_id"]
        url = f"https://my.feishu.cn/docx/{doc_id}"
        return (
            f"✅ 文档已创建\n"
            f"   标题: {result['title']}\n"
            f"   链接: {url}"
        )


# ── CLI Entry ────────────────────────────────────────────────

def main():
    if len(sys.argv) < 3:
        print("Usage:")
        print("  python feishu_tool.py search <query>")
        print("  python feishu_tool.py read <doc_token>")
        print("  python feishu_tool.py create <title>")
        sys.exit(1)

    command = sys.argv[1]
    arg = sys.argv[2]

    tool = FeishuTool()

    if command == "search":
        result = tool.search(arg)
    elif command == "read":
        result = tool.read(arg)
    elif command == "create":
        result = tool.create(arg)
    else:
        print(f"Unknown command: {command}")
        print("Available: search, read, create")
        sys.exit(1)

    print(result)


if __name__ == "__main__":
    main()


# ── MCP Adapter Wrapper ──────────────────────────────────────


class FeishuMCPAdapter(NoteAdapter):
    """Wraps FeishuTool as a NoteAdapter for MCP Server."""

    def __init__(self):
        # Use config.json at project root, not adapter dir
        project_root = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            "..", ".."
        )
        config_path = os.path.join(project_root, "config.json")
        self._tool = FeishuTool(config_path=config_path)

    @property
    def platform_name(self) -> str:
        return "feishu"

    def available(self) -> bool:
        """Feishu adapter is available if config file exists."""
        try:
            project_root = os.path.join(
                os.path.dirname(os.path.abspath(__file__)),
                "..", ".."
            )
            config_path = os.path.join(project_root, "config.json")
            return os.path.exists(config_path)
        except Exception:
            return False

    def get_tools(self) -> list[ToolDef]:
        return [
            ToolDef(
                name="feishu_search",
                description="Search Feishu/Lark documents by keyword. Returns matching documents with title, URL, and summary.",
                input_schema=make_query_schema("Search query for Feishu documents"),
            ),
            ToolDef(
                name="feishu_read",
                description="Read the full content of a Feishu document by its doc_token. Returns content as text.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "doc_token": {
                            "type": "string",
                            "description": "The Feishu document token to read",
                        }
                    },
                    "required": ["doc_token"],
                },
            ),
            ToolDef(
                name="feishu_create",
                description="Create a new Feishu document with a given title.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "title": {
                            "type": "string",
                            "description": "Title of the new document",
                        }
                    },
                    "required": ["title"],
                },
            ),
        ]

    def handle_tool_call(self, tool_name: str, args: dict) -> str:
        if tool_name == "feishu_search":
            return self._tool.search(args.get("query", ""))
        elif tool_name == "feishu_read":
            return self._tool.read(args.get("doc_token", ""))
        elif tool_name == "feishu_create":
            return self._tool.create(args.get("title", ""))
        else:
            return f"Unknown tool: {tool_name}"
