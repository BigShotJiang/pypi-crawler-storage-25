#!/usr/bin/env python3
"""
note — 多平台笔记统一 CLI

Usage:
    note feishu search <query>
    note feishu read <doc_token>
    note feishu create <title>
    note evernote search <query>    (coming soon)
    note notion search <query>      (coming soon)
"""

import sys

COMMANDS = {
    "feishu": "note_tool.adapters.feishu_tool",
    "onenote": "note_tool.adapters.onenote_tool",
    "obsidian": "note_tool.adapters.obsidian",
    "yuque": "note_tool.adapters.yuque",
    "notion": "note_tool.adapters.notion",
    "evernote": "note_tool.adapters.evernote",
    "mcp": "note_tool.mcp_server",
    "setup": "note_tool.setup_wizard",
}


def main():
    if len(sys.argv) < 2:
        print("Usage: note <platform> <command> [args...]")
        print(f"Available platforms: {', '.join(COMMANDS.keys())}")
        sys.exit(1)

    platform = sys.argv[1]
    if platform not in COMMANDS:
        print(f"Unknown platform: {platform}")
        print(f"Available: {', '.join(COMMANDS.keys())}")
        sys.exit(1)

    # Delegate to the platform's CLI entry
    module_path = COMMANDS[platform]
    import importlib
    mod = importlib.import_module(module_path)
    mod.main()


if __name__ == "__main__":
    main()
