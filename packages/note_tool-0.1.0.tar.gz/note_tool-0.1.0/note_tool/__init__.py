"""
note-tool — 多平台笔记统一 CLI 工具包

用法:
    pip install note-tool
    note search "关键词"
    note read <doc_token>
    note create "标题"

支持的平台:
    - 印象笔记 (Evernote)
    - Notion
    - 飞书 (Lark/Feishu)
    - 语雀 (Yuque)
    - OneNote
"""

from . import adapters

__version__ = "0.1.0"
