# I Built a Real-Time Object Tracking Analytics Framework on Top of YOLO — Here's How

## yolo26-analytics: From detection to dashboards in one pip install

If you've ever worked with YOLO for object detection, you know the pain. You get bounding boxes. Cool. Now what?

You still need tracking, zone analytics, heatmaps, alerting, data persistence, and some way to visualize it all. Every project ends up reinventing the same plumbing.

So I built **yolo26-analytics** — a pip-installable Python framework that takes you from raw video to real-time analytics with a pluggable pipeline architecture.

```
pip install yolo26-analytics
```

---

## What It Does

The framework connects five pipeline stages:

**VideoSource → Detector → Tracker → ZoneAnalyzer → AlertManager**

![Pipeline Architecture](https://excalidraw.com/#json=NTDM3mBNWbsmLzweIF7Kc,tF1MyEV2cC4lHFYIPZVRIw)

Each stage is defined as a Python Protocol, so you can swap any component without touching the rest. Use the built-in YOLO detector or bring your own. Use ByteTrack or plug in a custom tracker. The pipeline doesn't care — it just needs the right interface.

---

## The Core Features

### Multi-Object Tracking with ByteTrack

Wraps Ultralytics' ByteTrack implementation with a clean API. Get track IDs, centroids, and trajectories out of the box.

```python
from yolo26_analytics.detection.yolo26 import YOLO26Detector
from yolo26_analytics.tracking.bytetrack import ByteTrackAdapter

detector = YOLO26Detector("yolo11n.pt", confidence=0.4)
tracker = ByteTrackAdapter(max_age=30, min_hits=3)

detections = detector.predict(frame)
tracks = tracker.update(detections)

for track in tracks:
    print(f"Track {track.track_id}: {track.class_name} at {track.centroid}")
```

### Polygon Zone Analytics

Define zones as polygons. Track entries, exits, dwell time, and throughput per zone. The zone system uses Shapely for precise point-in-polygon checks.

```python
from yolo26_analytics.config.schema import ZoneAnalyticsRule, ZoneConfig
from yolo26_analytics.zones.analyzer import ZoneAnalyzer

zone_cfg = ZoneConfig(
    name="entrance",
    polygon=[[100, 100], [400, 100], [400, 400], [100, 400]],
    track_classes=["person"],
    analytics=[
        ZoneAnalyticsRule(type="count"),
        ZoneAnalyticsRule(type="entry_exit"),
        ZoneAnalyticsRule(type="dwell", alert_threshold=30),
    ],
    cooldown=5,
)

analyzer = ZoneAnalyzer([zone_cfg])
events = analyzer.check(tracks)
```

### Heatmap Generation

Accumulate track centroids over time into density heatmaps. Each point is rendered as a Gaussian blob, so the output actually looks good — not just scattered pixels.

### SAHI Integration

Small object detection via Slicing Aided Hyper Inference. Same Detector Protocol interface, but slices the frame into overlapping tiles for better detection of distant or small objects.

### Async Pipeline with YAML Config

Define your entire pipeline in a YAML file — source, model, tracking params, zones, alerts — and run it with one command:

```
y26a run --config pipeline.yaml
```

### Data Persistence

SQLite for development, PostgreSQL for production. Track history and events are stored via SQLAlchemy async, with configurable retention policies.

### Real-Time Dashboard

FastAPI + HTMX dashboard with MJPEG streaming and Server-Sent Events. See live detections, zone counts, and event logs in your browser.

### Alerting

Console alerts out of the box, MQTT for IoT integration. The AlertBackend Protocol makes it trivial to add Slack, email, or webhook alerts.

### Model Export

Export to ONNX, TFLite, or TensorRT with auto-benchmarking:

```
y26a export --weights yolo11n.pt --format onnx
```

---

## Architecture: Why Protocols Matter

![Protocol Architecture](https://excalidraw.com/#json=aSG1tB0-1ggxohTOnxrRC,IagjcFUmJusAd3T2_JPerQ)

The entire framework is built on Python's `typing.Protocol` with `runtime_checkable`. This means:

**No inheritance required.** Your custom detector just needs a `predict(frame) -> list[Detection]` method. That's it.

**Swap anything.** Replace ByteTrack with DeepSORT. Replace YOLO with a custom model. Replace SQLite with your own store. The pipeline doesn't know or care.

**Type safety.** mypy --strict passes across all 48 source files with zero errors.

```python
from yolo26_analytics.models import Detection
from yolo26_analytics.protocols import Detector

class MyDetector:
    def predict(self, frame):
        # your inference logic here
        return [
            Detection(
                bbox=(100, 100, 200, 200),
                confidence=0.95,
                class_name="person",
            )
        ]

# No base class needed — just the right method signature
assert isinstance(MyDetector(), Detector)  # True
```

This isn't an academic exercise. It means you can test with a mock detector that returns fixed data, then swap in the real model for production — without changing a single line in the pipeline.

---

## Code Quality

This isn't a weekend hack with no tests. The project ships with:

- 56 tests covering every pipeline stage
- mypy --strict compliance (0 errors, 48 files)
- ruff linting and formatting
- GitHub Actions CI running tests, mypy, and ruff on every push
- Apache 2.0 license

---

## Try It

The fastest way to see it in action is the Colab notebook:

[Open in Google Colab](https://colab.research.google.com/github/MohibShaikh/yolo26-analytics/blob/main/notebooks/demo.ipynb)

The demo walks through detection, tracking, zone analytics, heatmaps, SAHI comparison, full YAML pipeline config, and the Protocol pattern for custom detectors.

Or install locally:

```
pip install yolo26-analytics
```

- GitHub: [github.com/MohibShaikh/yolo26-analytics](https://github.com/MohibShaikh/yolo26-analytics)
- PyPI: [pypi.org/project/yolo26-analytics](https://pypi.org/project/yolo26-analytics)

---

## What's Next

- WebSocket-based live dashboard (replacing MJPEG polling)
- More alert backends (Slack, Discord, webhooks)
- Multi-camera support with cross-camera re-identification
- Pre-built Grafana dashboards for the PostgreSQL store

If you're building anything with YOLO that goes beyond "draw boxes on frames," give it a spin. PRs and issues welcome.

---

*Built with Ultralytics, OpenCV, Shapely, SQLAlchemy, FastAPI, and a lot of caffeine.*
