#
# Copyright (c) nexB Inc. and others. All rights reserved.
# purldb is a trademark of nexB Inc.
# SPDX-License-Identifier: Apache-2.0
# See http://www.apache.org/licenses/LICENSE-2.0 for the license text.
# See https://github.com/aboutcode-org/purldb for support or download.
# See https://aboutcode.org for more information about nexB OSS projects.
#


import logging
import shutil
import time
from collections.abc import Callable
from collections.abc import Iterable
from pathlib import Path

from aboutcode.federated import DataFederation
from aboutcode.pipeline import LoopProgress
from packageurl import PackageURL
from scanpipe.pipelines import Pipeline
from scanpipe.pipes import federatedcode

from minecode_pipelines import pipes
from minecode_pipelines.pipes import write_package_data_to_file
from minecode_pipelines.pipes import write_packageurls_to_file

module_logger = logging.getLogger(__name__)


class MineCodeBasePipeline(Pipeline):
    """
    Base pipeline for mining PackageURLs.

    Uses:
        Subclass this Pipeline and implement ``mine_packageurls`` and ``packages_count``
        method. Also override the ``steps`` and ``commit_message`` as needed.
    """

    download_inputs = False

    # Control whether to overwrite or append mined purls to existing `purls.yml` file
    append_purls = False

    checked_out_repos = {}

    @classmethod
    def steps(cls):
        return (
            cls.check_federatedcode_eligibility,
            cls.create_federatedcode_working_dir,
            # Add step(s) for downloading/cloning resource as required.
            cls.fetch_federation_config,
            cls.mine_and_publish_packageurls,
            cls.delete_working_dir,
        )

    def mine_packageurls(self) -> Iterable[tuple[str, list[str]]]:
        """
        Yield (base_purl, package_urls_list) tuples,

        where `base_purl` is a versionless PURL string,
        and `package_urls_list` is a list of versioned PURL strings.
        """
        raise NotImplementedError

    def packages_count(self) -> int:
        """
        Return the estimated number of packages for which PackageURLs are to be mined.

        Used by ``mine_and_publish_packageurls`` to log the progress of PackageURL mining.
        Note: If estimating package count is not feasible return `None`
        """
        raise NotImplementedError

    def check_federatedcode_eligibility(self):
        """
        Check if the project fulfills the following criteria for
        pushing the project result to FederatedCode.
        """
        federatedcode.check_federatedcode_configured_and_available()

    def create_federatedcode_working_dir(self):
        """Create temporary working dir."""
        self.working_path = federatedcode.create_federatedcode_working_dir()

    def fetch_federation_config(self):
        """Fetch config for PackageURL Federation."""
        data_federation = DataFederation.from_url(
            name="aboutcode-data",
            remote_root_url="https://github.com/aboutcode-data",
        )
        self.data_clusters = {
            "purls": data_federation.get_cluster("purls"),
            "api_package_version_response": data_federation.get_cluster(
                "api_package_version_response"
            ),
        }

    def mine_and_publish_packageurls(self):
        """Mine and publish PackageURLs."""

        _mine_and_publish_packageurls(
            packageurls=self.mine_packageurls(),
            total_package_count=self.packages_count(),
            data_clusters=self.data_clusters,
            checked_out_repos=self.checked_out_repos,
            working_path=self.working_path,
            append_purls=self.append_purls,
            commit_msg_func=self.commit_message,
            logger=self.log,
        )

    def delete_working_dir(self):
        """Remove temporary working dir."""
        shutil.rmtree(self.working_path)

    def commit_message(self, commit_count, total_commit_count="many"):
        """Return default commit message for pushing mined PackageURLs."""
        from django.conf import settings
        from scancodeio import VERSION

        author_name = settings.FEDERATEDCODE_GIT_SERVICE_NAME
        author_email = settings.FEDERATEDCODE_GIT_SERVICE_EMAIL

        tool_name = "pkg:github/aboutcode-org/scancode.io"

        return f"""\
            Add newly mined PackageURLs ({commit_count}/{total_commit_count})

            Tool: {tool_name}@v{VERSION}

            Signed-off-by: {author_name} <{author_email}>
            """

    def log(self, message, level=logging.INFO):
        """Log the given `message` to the current module logger and execution_log."""
        from datetime import datetime
        from datetime import timezone

        now_local = datetime.now(timezone.utc).astimezone()
        timestamp = now_local.strftime("%Y-%m-%d %T.%f %Z")
        message = f"{timestamp} {message}"
        module_logger.log(level, message)
        print(message)
        message = message.replace("\r", "\\r").replace("\n", "\\n")
        self.append_to_log(message)


def commit_and_push_packageurls(
    current_working_repos,
    commit_msg_func,
    checkpoint_func,
    checkpoint_on_commit,
    checkpoint_interval,
    last_checkpoint_call,
    logger,
):
    """
    Given a list of `current_working_repos`, commit and push changes to each repo with the commit message returned from `commit_msg_func`.

    If `checkpoint_on_commit` is True and `checkpoint_func` exists, then we execute `checkpoint_func`.

    If `checkpoint_on_commit` is False, then we determine if it is time to call `checkpoint_func` or not.
    """

    if logger:
        logger("Trying to commit PackageURLs.")

    for repo_checkout in current_working_repos:
        pipes.commit_and_push_checkout(
            local_checkout=repo_checkout,
            commit_message=commit_msg_func(repo_checkout["commit_count"] + 1),
            logger=logger,
        )

        if checkpoint_on_commit and checkpoint_func:
            checkpoint_func()

    if not checkpoint_on_commit:
        time_now = time.time()
        checkpoint_due = time_now - last_checkpoint_call >= checkpoint_interval
        if checkpoint_func and checkpoint_due:
            checkpoint_func()
            last_checkpoint_call = time_now


def get_repo_checkout_from_data_cluster(
    data_cluster, purl, checked_out_repos, working_path, logger, datafile_name=None
):
    """
    Return a `repo_checkout` and `datafile_path` for a given `purl`, `data_cluster`, and `working_path`.

    Add `repo_checkout` to `checked_out_repos`.
    """
    repo, datafile_path = data_cluster.get_datafile_repo_and_path(
        purl=purl, datafile_name=datafile_name
    )
    if repo not in checked_out_repos:
        checked_out_repos[repo] = pipes.init_local_checkout(
            repo_name=repo,
            working_path=working_path,
            logger=logger,
        )
    repo_checkout = checked_out_repos[repo]
    return repo_checkout, datafile_path


def _mine_and_publish_packageurls(
    packageurls: Iterable,
    total_package_count: int,
    data_clusters,
    checked_out_repos: dict,
    working_path: Path,
    append_purls: bool,
    commit_msg_func: Callable,
    logger: Callable,
    batch_size: int = 100,
    checkpoint_on_commit: bool = False,
    checkpoint_func: Callable = None,
    checkpoint_freq: int = 30,
):
    """Mine and publish PackageURLs."""
    total_file_processed_count = 0
    total_commit_count = 0
    iterator = packageurls

    last_checkpoint_call = time.time()
    checkpoint_interval = checkpoint_freq * 60

    if total_package_count:
        progress = LoopProgress(
            total_iterations=total_package_count,
            logger=logger,
            progress_step=1,
        )
        iterator = progress.iter(iterator)
        logger(f"Mine PackageURL for {total_package_count:,d} packages.")

    purls_data_cluster = data_clusters["purls"]
    api_package_version_response_data_cluster = data_clusters["api_package_version_response"]

    current_working_repos = []
    currently_processed_files_count = 0
    for base, purls, purls_and_package_data in iterator:
        if not purls or not base:
            continue

        purls_package_repo_checkout, purls_datafile_path = get_repo_checkout_from_data_cluster(
            data_cluster=purls_data_cluster,
            purl=base,
            checked_out_repos=checked_out_repos,
            working_path=working_path,
            logger=logger,
        )
        if purls_package_repo_checkout not in current_working_repos:
            current_working_repos.append(purls_package_repo_checkout)

        purl_file = write_packageurls_to_file(
            repo=purls_package_repo_checkout["repo"],
            relative_datafile_path=purls_datafile_path,
            packageurls=purls,
            append=append_purls,
        )
        purls_package_repo_checkout["file_to_commit"].add(purl_file)
        purls_package_repo_checkout["file_processed_count"] += 1
        currently_processed_files_count += 1

        if currently_processed_files_count > batch_size:
            commit_and_push_packageurls(
                current_working_repos=current_working_repos,
                commit_msg_func=commit_msg_func,
                checkpoint_func=checkpoint_func,
                checkpoint_on_commit=checkpoint_on_commit,
                checkpoint_interval=checkpoint_interval,
                last_checkpoint_call=last_checkpoint_call,
                logger=logger,
            )
            current_working_repos = []
            currently_processed_files_count = 0

        for purl, api_package_version_response in purls_and_package_data:
            if not isinstance(purl, PackageURL):
                package_url = PackageURL.from_string(purl)
            else:
                package_url = purl
            if package_url.type == "maven":
                datafile_name = "pom.xml"
            else:
                datafile_name = "api_package_version_response.json"
            api_package_version_response_repo_checkout, api_package_metadata_datafile_path = (
                get_repo_checkout_from_data_cluster(
                    data_cluster=api_package_version_response_data_cluster,
                    purl=purl,
                    checked_out_repos=checked_out_repos,
                    working_path=working_path,
                    logger=logger,
                    datafile_name=datafile_name,
                )
            )
            if api_package_version_response_repo_checkout not in current_working_repos:
                current_working_repos.append(api_package_version_response_repo_checkout)

            api_package_version_response_file = write_package_data_to_file(
                repo=api_package_version_response_repo_checkout["repo"],
                relative_api_package_metadata_datafile_path=api_package_metadata_datafile_path,
                package_data=api_package_version_response,
            )

            api_package_version_response_repo_checkout["file_to_commit"].add(
                api_package_version_response_file
            )
            api_package_version_response_repo_checkout["file_processed_count"] += 1
            currently_processed_files_count += 1

            if currently_processed_files_count > batch_size:
                commit_and_push_packageurls(
                    current_working_repos=current_working_repos,
                    commit_msg_func=commit_msg_func,
                    checkpoint_func=checkpoint_func,
                    checkpoint_on_commit=checkpoint_on_commit,
                    checkpoint_interval=checkpoint_interval,
                    last_checkpoint_call=last_checkpoint_call,
                    logger=logger,
                )
                current_working_repos = []
                currently_processed_files_count = 0

    for checkout in checked_out_repos.values():
        final_commit_count = checkout["commit_count"] + 1
        pipes.commit_and_push_checkout(
            local_checkout=checkout,
            commit_message=commit_msg_func(
                commit_count=final_commit_count,
                total_commit_count=final_commit_count,
            ),
            logger=logger,
        )
        total_commit_count += checkout["commit_count"]
        total_file_processed_count += checkout["file_processed_count"]

    if checkpoint_func:
        checkpoint_func()

    logger(f"Processed PackageURL for {total_file_processed_count:,d} packages.")
    logger(
        f"Pushed new PackageURL in {total_commit_count:,d} commits in {len(checked_out_repos):,d} repos."
    )
