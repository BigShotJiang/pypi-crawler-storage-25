use std::collections::HashMap;
use std::path::Path;

use ansible_utils::AnsibleValue;

use crate::error::PlaybookError;
use crate::types::*;

/// Known Ansible module/action names — used to distinguish module calls
/// from task attributes in the flattened task YAML mapping.
const KNOWN_TASK_ATTRIBUTES: &[&str] = &[
    "name",
    "when",
    "register",
    "loop",
    "with_items",
    "with_dict",
    "with_list",
    "with_fileglob",
    "with_first_found",
    "with_together",
    "with_subelements",
    "with_sequence",
    "with_random_choice",
    "with_indexed_items",
    "with_nested",
    "with_flattened",
    "loop_control",
    "notify",
    "tags",
    "become",
    "become_user",
    "become_method",
    "become_flags",
    "delegate_to",
    "delegate_facts",
    "ignore_errors",
    "ignore_unreachable",
    "changed_when",
    "failed_when",
    "retries",
    "delay",
    "until",
    "no_log",
    "args",
    "environment",
    "vars",
    "block",
    "rescue",
    "always",
    "connection",
    "timeout",
    "any_errors_fatal",
    "check_mode",
    "diff",
    "collections",
    "module_defaults",
    "throttle",
    "debugger",
    "run_once",
    "listen",
];

/// Load a playbook from a YAML file.
pub fn load_playbook(path: &Path) -> Result<Playbook, PlaybookError> {
    let content = ansible_parsing::read_file_efficient(path).map_err(PlaybookError::Io)?;
    let plays = parse_playbook_yaml(&content)?;

    Ok(Playbook {
        plays,
        filename: path.to_path_buf(),
    })
}

/// Parse playbook YAML content into a list of plays.
fn parse_playbook_yaml(content: &str) -> Result<Vec<Play>, PlaybookError> {
    let raw: Vec<serde_yaml::Value> = serde_yaml::from_str(content)
        .map_err(|e| PlaybookError::ParseError(format!("invalid YAML: {}", e)))?;

    let mut plays = Vec::new();
    for (idx, play_val) in raw.into_iter().enumerate() {
        let play = parse_play(play_val, idx)?;
        plays.push(play);
    }

    Ok(plays)
}

/// Parse a single play from a YAML value.
fn parse_play(val: serde_yaml::Value, idx: usize) -> Result<Play, PlaybookError> {
    let map = val
        .as_mapping()
        .ok_or_else(|| PlaybookError::InvalidPlay(format!("play {} is not a mapping", idx)))?;

    let name = get_str(map, "name");
    let hosts = parse_hosts(map)?;

    if hosts.is_none() {
        return Err(PlaybookError::InvalidPlay(format!(
            "play {} missing 'hosts' key",
            idx
        )));
    }

    let gather_facts = get_bool(map, "gather_facts");
    let strategy = get_str(map, "strategy").unwrap_or_else(|| "linear".to_string());
    let connection = get_str(map, "connection");
    let use_become = get_bool(map, "become");
    let become_user = get_str(map, "become_user");
    let become_method = get_str(map, "become_method");
    let any_errors_fatal = get_bool(map, "any_errors_fatal");
    let ignore_errors = get_bool(map, "ignore_errors");
    let ignore_unreachable = get_bool(map, "ignore_unreachable");
    let max_fail_percentage = get_f64(map, "max_fail_percentage");
    let force_handlers = get_bool(map, "force_handlers").unwrap_or(false);

    let tasks = parse_task_list(map, "tasks")?;
    let pre_tasks = parse_task_list(map, "pre_tasks")?;
    let post_tasks = parse_task_list(map, "post_tasks")?;
    let handlers = parse_task_list(map, "handlers")?;

    let vars = parse_vars_map(map, "vars");
    let vars_files = parse_string_list(map, "vars_files");
    let environment = parse_string_string_map(map, "environment");
    let when_conditions = parse_when(map);
    let tags = parse_tags(map);
    let serial = parse_serial(map);

    let roles = parse_roles(map)?;

    let collections = map
        .get(serde_yaml::Value::String("collections".into()))
        .and_then(|v| {
            serde_yaml::from_value::<Vec<String>>(v.clone()).ok()
        });

    let module_defaults = map
        .get(serde_yaml::Value::String("module_defaults".into()))
        .and_then(|v| {
            serde_yaml::from_value(v.clone()).ok()
        });

    Ok(Play {
        name,
        hosts,
        tasks,
        pre_tasks,
        post_tasks,
        handlers,
        roles,
        vars,
        vars_files,
        environment,
        gather_facts,
        strategy,
        serial,
        max_fail_percentage,
        force_handlers,
        use_become,
        become_user,
        become_method,
        connection,
        tags,
        when_conditions,
        any_errors_fatal,
        ignore_errors,
        ignore_unreachable,
        module_defaults,
        collections,
    })
}

/// Parse a list of tasks from a play mapping.
fn parse_task_list(
    map: &serde_yaml::Mapping,
    key: &str,
) -> Result<Vec<Task>, PlaybookError> {
    let val = match map.get(serde_yaml::Value::String(key.into())) {
        Some(v) => v,
        None => return Ok(Vec::new()),
    };

    let list = val
        .as_sequence()
        .ok_or_else(|| PlaybookError::ParseError(format!("'{}' must be a list", key)))?;

    let mut tasks = Vec::new();
    for item in list {
        let task = parse_task(item)?;
        tasks.push(task);
    }
    Ok(tasks)
}

/// Parse a single task from its YAML value.
/// Ansible tasks use a flat mapping where the module name is one of the keys.
fn parse_task(val: &serde_yaml::Value) -> Result<Task, PlaybookError> {
    let map = val
        .as_mapping()
        .ok_or_else(|| PlaybookError::ParseError("task must be a mapping".into()))?;

    let name = get_str(map, "name");
    let register = get_str(map, "register");
    let delegate_to = get_str(map, "delegate_to");
    let connection = get_str(map, "connection");
    let use_become = get_bool(map, "become");
    let become_user = get_str(map, "become_user");
    let become_method = get_str(map, "become_method");
    let become_flags = get_str(map, "become_flags");
    let become_pass = get_str(map, "become_pass");
    let ignore_errors = get_bool(map, "ignore_errors").unwrap_or(false);
    let run_once = get_bool(map, "run_once").unwrap_or(false);
    let no_log = get_bool(map, "no_log").unwrap_or(false);
    let retries = get_u32(map, "retries").unwrap_or(3);
    let delay = get_u32(map, "delay").unwrap_or(5);
    let timeout = get_u64(map, "timeout");
    let check_mode = get_bool(map, "check_mode");

    let when_conditions = parse_when(map);
    let changed_when = parse_string_or_list(map, "changed_when");
    let failed_when = parse_string_or_list(map, "failed_when");
    let until = parse_string_or_list(map, "until");
    let notify = parse_string_or_list(map, "notify");
    let tags = parse_tags(map);

    // Loop sources
    let loop_items = map
        .get(serde_yaml::Value::String("loop".into()))
        .and_then(yaml_to_ansible_value);
    let with_items = map
        .get(serde_yaml::Value::String("with_items".into()))
        .and_then(yaml_to_ansible_value);
    let loop_control = map
        .get(serde_yaml::Value::String("loop_control".into()))
        .and_then(|v| serde_yaml::from_value(v.clone()).ok());

    // Task vars
    let vars = map
        .get(serde_yaml::Value::String("vars".into()))
        .and_then(|v| {
            serde_yaml::from_value::<HashMap<String, AnsibleValue>>(v.clone()).ok()
        });

    // Args
    let args = map
        .get(serde_yaml::Value::String("args".into()))
        .and_then(|v| {
            serde_yaml::from_value::<HashMap<String, AnsibleValue>>(v.clone()).ok()
        });

    // Environment
    let environment = map
        .get(serde_yaml::Value::String("environment".into()))
        .and_then(|v| {
            serde_yaml::from_value::<HashMap<String, String>>(v.clone()).ok()
        });

    // Block/rescue/always
    let block = parse_optional_task_list(map, "block")?;
    let rescue = parse_optional_task_list(map, "rescue")?;
    let always = parse_optional_task_list(map, "always")?;

    // Extract the action (module call) — any key that's not a known task attribute
    let mut action = HashMap::new();
    for (k, v) in map {
        if let Some(key_str) = k.as_str() {
            if !KNOWN_TASK_ATTRIBUTES.contains(&key_str) {
                if let Some(av) = yaml_to_ansible_value(v) {
                    action.insert(key_str.to_string(), av);
                } else {
                    action.insert(key_str.to_string(), AnsibleValue::Null);
                }
            }
        }
    }

    Ok(Task {
        name,
        action,
        when_conditions,
        register,
        loop_source: None,
        loop_items,
        with_items,
        loop_control,
        notify,
        tags,
        use_become,
        become_user,
        become_method,
        become_flags,
        become_pass,
        delegate_to,
        ignore_errors,
        run_once,
        changed_when,
        failed_when,
        retries,
        delay,
        until,
        no_log,
        args,
        environment,
        vars,
        block,
        rescue,
        always,
        connection,
        timeout,
        check_mode,
    })
}

fn parse_optional_task_list(
    map: &serde_yaml::Mapping,
    key: &str,
) -> Result<Option<Vec<Task>>, PlaybookError> {
    if map.contains_key(serde_yaml::Value::String(key.into())) {
        Ok(Some(parse_task_list(map, key)?))
    } else {
        Ok(None)
    }
}

/// Parse roles from a play mapping.
fn parse_roles(map: &serde_yaml::Mapping) -> Result<Vec<RoleInclusion>, PlaybookError> {
    let val = match map.get(serde_yaml::Value::String("roles".into())) {
        Some(v) => v,
        None => return Ok(Vec::new()),
    };

    let list = val
        .as_sequence()
        .ok_or_else(|| PlaybookError::ParseError("'roles' must be a list".into()))?;

    let mut roles = Vec::new();
    for item in list {
        let role = match item {
            serde_yaml::Value::String(s) => RoleInclusion {
                role: s.clone(),
                vars: HashMap::new(),
                tags: TagSpec::None,
                when_conditions: Vec::new(),
                use_become: None,
                become_user: None,
            },
            serde_yaml::Value::Mapping(m) => {
                let role_name = get_str(m, "role")
                    .or_else(|| get_str(m, "name"))
                    .ok_or_else(|| {
                        PlaybookError::ParseError("role entry missing 'role' key".into())
                    })?;
                let tags = parse_tags(m);
                let when_conditions = parse_when(m);
                let use_become = get_bool(m, "become");
                let become_user = get_str(m, "become_user");

                // Everything else is treated as role params/vars
                let mut vars = HashMap::new();
                for (k, v) in m {
                    if let Some(key_str) = k.as_str() {
                        if !["role", "name", "tags", "when", "become", "become_user"]
                            .contains(&key_str)
                        {
                            if let Some(av) = yaml_to_ansible_value(v) {
                                vars.insert(key_str.to_string(), av);
                            }
                        }
                    }
                }

                RoleInclusion {
                    role: role_name,
                    vars,
                    tags,
                    when_conditions,
                    use_become,
                    become_user,
                }
            }
            _ => {
                return Err(PlaybookError::ParseError(
                    "role entry must be a string or mapping".into(),
                ))
            }
        };
        roles.push(role);
    }

    Ok(roles)
}

// ============ Helper functions ============

fn get_str(map: &serde_yaml::Mapping, key: &str) -> Option<String> {
    map.get(serde_yaml::Value::String(key.into()))
        .and_then(|v| v.as_str())
        .map(|s| s.to_string())
}

/// Parse the `hosts` key on a play. Accepts either a single string/scalar or a
/// YAML sequence of scalars; a sequence is joined with commas so the downstream
/// pattern resolver treats it as a union of patterns.
fn parse_hosts(map: &serde_yaml::Mapping) -> Result<Option<String>, PlaybookError> {
    let val = match map.get(serde_yaml::Value::String("hosts".into())) {
        Some(v) => v,
        None => return Ok(None),
    };

    if val.is_null() {
        return Ok(None);
    }

    if let Some(s) = val.as_str() {
        return Ok(Some(s.to_string()));
    }

    if let Some(seq) = val.as_sequence() {
        let mut parts = Vec::with_capacity(seq.len());
        for item in seq {
            let part = if let Some(s) = item.as_str() {
                s.to_string()
            } else if let Some(b) = item.as_bool() {
                b.to_string()
            } else if let Some(n) = item.as_i64() {
                n.to_string()
            } else if let Some(n) = item.as_u64() {
                n.to_string()
            } else if let Some(n) = item.as_f64() {
                n.to_string()
            } else {
                return Err(PlaybookError::InvalidPlay(format!(
                    "'hosts' list entry is not a scalar: {:?}",
                    item
                )));
            };
            if part.is_empty() {
                continue;
            }
            parts.push(part);
        }
        if parts.is_empty() {
            return Ok(None);
        }
        return Ok(Some(parts.join(",")));
    }

    Err(PlaybookError::InvalidPlay(
        "'hosts' must be a string or a list of strings".to_string(),
    ))
}

fn get_bool(map: &serde_yaml::Mapping, key: &str) -> Option<bool> {
    let v = map.get(serde_yaml::Value::String(key.into()))?;
    if let Some(b) = v.as_bool() {
        return Some(b);
    }
    // Ansible accepts YAML 1.1-style truthy strings: yes/no/on/off/true/false.
    // serde_yaml (1.2) only recognizes true/false, so fall back to string parsing.
    v.as_str().and_then(|s| match s.to_ascii_lowercase().as_str() {
        "yes" | "true" | "on" | "y" | "1" => Some(true),
        "no" | "false" | "off" | "n" | "0" => Some(false),
        _ => None,
    })
}

fn get_u32(map: &serde_yaml::Mapping, key: &str) -> Option<u32> {
    map.get(serde_yaml::Value::String(key.into()))
        .and_then(|v| v.as_u64())
        .map(|n| n as u32)
}

fn get_u64(map: &serde_yaml::Mapping, key: &str) -> Option<u64> {
    map.get(serde_yaml::Value::String(key.into()))
        .and_then(|v| v.as_u64())
}

fn get_f64(map: &serde_yaml::Mapping, key: &str) -> Option<f64> {
    map.get(serde_yaml::Value::String(key.into()))
        .and_then(|v| v.as_f64())
}

fn parse_when(map: &serde_yaml::Mapping) -> Vec<String> {
    match map.get(serde_yaml::Value::String("when".into())) {
        Some(serde_yaml::Value::String(s)) => vec![s.clone()],
        Some(serde_yaml::Value::Sequence(seq)) => seq
            .iter()
            .filter_map(|v| v.as_str().map(|s| s.to_string()))
            .collect(),
        Some(serde_yaml::Value::Bool(b)) => vec![b.to_string()],
        _ => Vec::new(),
    }
}

fn parse_string_or_list(map: &serde_yaml::Mapping, key: &str) -> Vec<String> {
    match map.get(serde_yaml::Value::String(key.into())) {
        Some(serde_yaml::Value::String(s)) => vec![s.clone()],
        Some(serde_yaml::Value::Sequence(seq)) => seq
            .iter()
            .filter_map(|v| v.as_str().map(|s| s.to_string()))
            .collect(),
        _ => Vec::new(),
    }
}

fn parse_string_list(map: &serde_yaml::Mapping, key: &str) -> Vec<String> {
    parse_string_or_list(map, key)
}

fn parse_tags(map: &serde_yaml::Mapping) -> TagSpec {
    match map.get(serde_yaml::Value::String("tags".into())) {
        Some(serde_yaml::Value::String(s)) => TagSpec::Single(s.clone()),
        Some(serde_yaml::Value::Sequence(seq)) => {
            let tags: crate::types::TagList = seq
                .iter()
                .filter_map(|v| v.as_str().map(|s| s.to_string()))
                .collect();
            if tags.is_empty() {
                TagSpec::None
            } else {
                TagSpec::Tags(tags)
            }
        }
        _ => TagSpec::None,
    }
}

fn parse_serial(map: &serde_yaml::Mapping) -> Vec<SerialSpec> {
    match map.get(serde_yaml::Value::String("serial".into())) {
        Some(serde_yaml::Value::Number(n)) => {
            vec![SerialSpec::Count(n.as_u64().unwrap_or(0) as usize)]
        }
        Some(serde_yaml::Value::String(s)) => {
            if s.ends_with('%') {
                vec![SerialSpec::Percentage(s.clone())]
            } else if let Ok(n) = s.parse::<usize>() {
                vec![SerialSpec::Count(n)]
            } else {
                Vec::new()
            }
        }
        Some(serde_yaml::Value::Sequence(seq)) => seq
            .iter()
            .filter_map(|v| match v {
                serde_yaml::Value::Number(n) => {
                    Some(SerialSpec::Count(n.as_u64().unwrap_or(0) as usize))
                }
                serde_yaml::Value::String(s) => {
                    if s.ends_with('%') {
                        Some(SerialSpec::Percentage(s.clone()))
                    } else {
                        s.parse::<usize>().ok().map(SerialSpec::Count)
                    }
                }
                _ => None,
            })
            .collect(),
        _ => Vec::new(),
    }
}

fn parse_vars_map(
    map: &serde_yaml::Mapping,
    key: &str,
) -> HashMap<String, AnsibleValue> {
    map.get(serde_yaml::Value::String(key.into()))
        .and_then(|v| {
            serde_yaml::from_value::<HashMap<String, AnsibleValue>>(v.clone()).ok()
        })
        .unwrap_or_default()
}

fn parse_string_string_map(
    map: &serde_yaml::Mapping,
    key: &str,
) -> HashMap<String, String> {
    map.get(serde_yaml::Value::String(key.into()))
        .and_then(|v| {
            serde_yaml::from_value::<HashMap<String, String>>(v.clone()).ok()
        })
        .unwrap_or_default()
}

/// Convert a serde_yaml::Value to an AnsibleValue.
fn yaml_to_ansible_value(val: &serde_yaml::Value) -> Option<AnsibleValue> {
    serde_yaml::from_value::<AnsibleValue>(val.clone()).ok()
}

/// Extract the module name and its arguments from a task's action map.
/// Returns (module_name, module_args).
pub fn extract_action(task: &Task) -> Option<(String, AnsibleValue)> {
    // The action map contains module_name: args plus any unknown keys.
    // In a well-formed task, there should be exactly one module key.
    task.action
        .iter()
        .next()
        .map(|(key, value)| (key.clone(), value.clone()))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_load_simple_playbook() {
        let yaml = r#"
- name: Test play
  hosts: all
  gather_facts: false
  vars:
    http_port: 8080
  tasks:
    - name: Print a message
      debug:
        msg: "Hello World"
    - name: Create a file
      file:
        path: /tmp/test
        state: touch
"#;
        let plays = parse_playbook_yaml(yaml).unwrap();
        assert_eq!(plays.len(), 1);
        assert_eq!(plays[0].name.as_deref(), Some("Test play"));
        assert_eq!(plays[0].hosts.as_deref(), Some("all"));
        assert_eq!(plays[0].gather_facts, Some(false));
        assert_eq!(plays[0].tasks.len(), 2);

        let task1 = &plays[0].tasks[0];
        assert_eq!(task1.name.as_deref(), Some("Print a message"));
        assert!(task1.action.contains_key("debug"));

        let task2 = &plays[0].tasks[1];
        assert_eq!(task2.name.as_deref(), Some("Create a file"));
        assert!(task2.action.contains_key("file"));
    }

    #[test]
    fn test_load_playbook_with_when() {
        let yaml = r#"
- name: Conditional play
  hosts: webservers
  tasks:
    - name: Only on Debian
      apt:
        name: nginx
      when: ansible_os_family == "Debian"
"#;
        let plays = parse_playbook_yaml(yaml).unwrap();
        let task = &plays[0].tasks[0];
        assert_eq!(task.when_conditions.len(), 1);
        assert_eq!(
            task.when_conditions[0],
            "ansible_os_family == \"Debian\""
        );
    }

    #[test]
    fn test_load_playbook_with_loop() {
        let yaml = r#"
- name: Loop play
  hosts: all
  tasks:
    - name: Install packages
      apt:
        name: "{{ item }}"
      loop:
        - nginx
        - curl
        - git
"#;
        let plays = parse_playbook_yaml(yaml).unwrap();
        let task = &plays[0].tasks[0];
        assert!(task.loop_items.is_some());
        match &task.loop_items {
            Some(AnsibleValue::Array(arr)) => assert_eq!(arr.len(), 3),
            _ => panic!("expected array loop items"),
        }
    }

    #[test]
    fn test_load_playbook_with_block() {
        let yaml = r#"
- name: Block play
  hosts: all
  tasks:
    - block:
        - name: Try this
          command: /bin/true
      rescue:
        - name: Handle failure
          debug:
            msg: "Failed!"
      always:
        - name: Always run
          debug:
            msg: "Cleanup"
"#;
        let plays = parse_playbook_yaml(yaml).unwrap();
        let task = &plays[0].tasks[0];
        assert!(task.block.is_some());
        assert_eq!(task.block.as_ref().unwrap().len(), 1);
        assert!(task.rescue.is_some());
        assert_eq!(task.rescue.as_ref().unwrap().len(), 1);
        assert!(task.always.is_some());
        assert_eq!(task.always.as_ref().unwrap().len(), 1);
    }

    #[test]
    fn test_load_playbook_with_roles() {
        let yaml = r#"
- name: Role play
  hosts: all
  roles:
    - common
    - role: nginx
      vars:
        port: 8080
      tags: web
"#;
        let plays = parse_playbook_yaml(yaml).unwrap();
        assert_eq!(plays[0].roles.len(), 2);
        assert_eq!(plays[0].roles[0].role, "common");
        assert_eq!(plays[0].roles[1].role, "nginx");
    }

    #[test]
    fn test_load_playbook_with_handlers() {
        let yaml = r#"
- name: Handler play
  hosts: all
  tasks:
    - name: Update config
      template:
        src: nginx.conf.j2
        dest: /etc/nginx/nginx.conf
      notify: restart nginx
  handlers:
    - name: restart nginx
      service:
        name: nginx
        state: restarted
"#;
        let plays = parse_playbook_yaml(yaml).unwrap();
        assert_eq!(plays[0].tasks[0].notify, vec!["restart nginx"]);
        assert_eq!(plays[0].handlers.len(), 1);
        assert_eq!(
            plays[0].handlers[0].name.as_deref(),
            Some("restart nginx")
        );
    }

    #[test]
    fn test_load_playbook_with_become() {
        let yaml = r#"
- name: Privileged play
  hosts: all
  become: true
  become_user: root
  become_method: sudo
  tasks:
    - name: Install package
      apt:
        name: nginx
"#;
        let plays = parse_playbook_yaml(yaml).unwrap();
        assert_eq!(plays[0].use_become, Some(true));
        assert_eq!(plays[0].become_user.as_deref(), Some("root"));
        assert_eq!(plays[0].become_method.as_deref(), Some("sudo"));
    }

    #[test]
    fn test_extract_action() {
        let yaml = r#"
- name: Test play
  hosts: all
  tasks:
    - name: Test task
      debug:
        msg: "Hello"
"#;
        let plays = parse_playbook_yaml(yaml).unwrap();
        let (module, _args) = extract_action(&plays[0].tasks[0]).unwrap();
        assert_eq!(module, "debug");
    }

    #[test]
    fn test_load_playbook_with_pre_post_tasks() {
        let yaml = r#"
- name: Full play
  hosts: all
  pre_tasks:
    - name: Pre task
      debug:
        msg: "before"
  tasks:
    - name: Main task
      debug:
        msg: "main"
  post_tasks:
    - name: Post task
      debug:
        msg: "after"
"#;
        let plays = parse_playbook_yaml(yaml).unwrap();
        assert_eq!(plays[0].pre_tasks.len(), 1);
        assert_eq!(plays[0].tasks.len(), 1);
        assert_eq!(plays[0].post_tasks.len(), 1);
    }

    #[test]
    fn test_load_multi_play_playbook() {
        let yaml = r#"
- name: Play 1
  hosts: webservers
  tasks:
    - debug:
        msg: "web"

- name: Play 2
  hosts: dbservers
  tasks:
    - debug:
        msg: "db"
"#;
        let plays = parse_playbook_yaml(yaml).unwrap();
        assert_eq!(plays.len(), 2);
        assert_eq!(plays[0].hosts.as_deref(), Some("webservers"));
        assert_eq!(plays[1].hosts.as_deref(), Some("dbservers"));
    }

    #[test]
    fn test_load_playbook_with_hosts_array() {
        let yaml = r#"
- name: Multi-target play
  hosts:
    - webservers
    - dbservers
    - host1.example.com
  tasks:
    - debug:
        msg: "hi"
"#;
        let plays = parse_playbook_yaml(yaml).unwrap();
        assert_eq!(plays.len(), 1);
        assert_eq!(
            plays[0].hosts.as_deref(),
            Some("webservers,dbservers,host1.example.com"),
        );
    }

    #[test]
    fn test_hosts_array_matches_comma_separated_string() {
        let array_yaml = r#"
- hosts:
    - webservers
    - dbservers
    - host1.example.com
  tasks:
    - debug:
        msg: x
"#;
        let string_yaml = r#"
- hosts: "webservers,dbservers,host1.example.com"
  tasks:
    - debug:
        msg: x
"#;
        let from_array = parse_playbook_yaml(array_yaml).unwrap();
        let from_string = parse_playbook_yaml(string_yaml).unwrap();
        assert_eq!(from_array[0].hosts, from_string[0].hosts);
    }

    #[test]
    fn test_hosts_single_element_array() {
        let yaml = r#"
- hosts:
    - all
  tasks:
    - debug:
        msg: x
"#;
        let plays = parse_playbook_yaml(yaml).unwrap();
        assert_eq!(plays[0].hosts.as_deref(), Some("all"));
    }

    #[test]
    fn test_hosts_empty_array_is_missing() {
        let yaml = r#"
- hosts: []
  tasks:
    - debug:
        msg: x
"#;
        let err = parse_playbook_yaml(yaml).unwrap_err();
        assert!(matches!(err, PlaybookError::InvalidPlay(_)));
    }

    #[test]
    fn test_hosts_non_scalar_entry_errors() {
        let yaml = r#"
- hosts:
    - webservers
    - [nested, list]
  tasks:
    - debug:
        msg: x
"#;
        let err = parse_playbook_yaml(yaml).unwrap_err();
        assert!(matches!(err, PlaybookError::InvalidPlay(_)));
    }
}
