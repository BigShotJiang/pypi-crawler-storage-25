use std::collections::HashMap;
use std::path::PathBuf;

use ansible_utils::AnsibleValue;
use serde::{Deserialize, Serialize};

/// A complete playbook file containing one or more plays.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Playbook {
    pub plays: Vec<Play>,
    #[serde(skip)]
    pub filename: PathBuf,
}

/// A single play targeting a set of hosts.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Play {
    pub name: Option<String>,
    pub hosts: Option<String>,
    #[serde(default)]
    pub tasks: Vec<Task>,
    #[serde(default)]
    pub pre_tasks: Vec<Task>,
    #[serde(default)]
    pub post_tasks: Vec<Task>,
    #[serde(default)]
    pub handlers: Vec<Task>,
    #[serde(default)]
    pub roles: Vec<RoleInclusion>,
    #[serde(default)]
    pub vars: HashMap<String, AnsibleValue>,
    #[serde(default)]
    pub vars_files: Vec<String>,
    #[serde(default)]
    pub environment: HashMap<String, String>,
    pub gather_facts: Option<bool>,
    #[serde(default = "default_strategy")]
    pub strategy: String,
    #[serde(default)]
    pub serial: Vec<SerialSpec>,
    pub max_fail_percentage: Option<f64>,
    /// When true, notified handlers fire at end-of-play even on hosts
    /// that failed after notifying. Mirrors `--force-handlers` and the
    /// play-level `force_handlers: yes` directive. Unreachable hosts
    /// are still skipped.
    #[serde(default)]
    pub force_handlers: bool,
    #[serde(default)]
    pub use_become: Option<bool>,
    pub become_user: Option<String>,
    pub become_method: Option<String>,
    pub connection: Option<String>,
    #[serde(default)]
    pub tags: TagSpec,
    #[serde(default, rename = "when")]
    pub when_conditions: Vec<String>,
    pub any_errors_fatal: Option<bool>,
    pub ignore_errors: Option<bool>,
    pub ignore_unreachable: Option<bool>,
    pub module_defaults: Option<HashMap<String, HashMap<String, AnsibleValue>>>,
    pub collections: Option<Vec<String>>,
}

fn default_strategy() -> String {
    "linear".to_string()
}

/// A single task within a play.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Task {
    pub name: Option<String>,
    /// The module/action to execute and its arguments.
    #[serde(flatten)]
    pub action: HashMap<String, AnsibleValue>,
    #[serde(default, rename = "when")]
    pub when_conditions: Vec<String>,
    pub register: Option<String>,
    pub loop_source: Option<AnsibleValue>,
    #[serde(rename = "loop")]
    pub loop_items: Option<AnsibleValue>,
    pub with_items: Option<AnsibleValue>,
    pub loop_control: Option<LoopControl>,
    #[serde(default)]
    pub notify: Vec<String>,
    #[serde(default)]
    pub tags: TagSpec,
    pub use_become: Option<bool>,
    pub become_user: Option<String>,
    pub become_method: Option<String>,
    pub become_flags: Option<String>,
    pub become_pass: Option<String>,
    pub delegate_to: Option<String>,
    #[serde(default)]
    pub ignore_errors: bool,
    /// When true, the task runs only once per serial batch — on the
    /// first host (or the `delegate_to` target) — and its result is
    /// propagated to every other host in the batch as if they had each
    /// run it. Honored by the linear strategy.
    #[serde(default)]
    pub run_once: bool,
    #[serde(default)]
    pub changed_when: Vec<String>,
    #[serde(default)]
    pub failed_when: Vec<String>,
    #[serde(default = "default_retries")]
    pub retries: u32,
    #[serde(default = "default_delay")]
    pub delay: u32,
    #[serde(default)]
    pub until: Vec<String>,
    #[serde(default)]
    pub no_log: bool,
    pub args: Option<HashMap<String, AnsibleValue>>,
    pub environment: Option<HashMap<String, String>>,
    pub vars: Option<HashMap<String, AnsibleValue>>,
    /// Block/rescue/always support
    pub block: Option<Vec<Task>>,
    pub rescue: Option<Vec<Task>>,
    pub always: Option<Vec<Task>>,
    pub connection: Option<String>,
    pub timeout: Option<u64>,
    /// Per-task check-mode override: `Some(true)` forces check mode,
    /// `Some(false)` disables it even if the run-level flag is set.
    #[serde(default)]
    pub check_mode: Option<bool>,
}

impl Task {
    /// Build a minimal task that just invokes `module` with `args`. Used
    /// by the execution engine to synthesize tasks (e.g. fact gathering)
    /// that aren't present in the playbook source.
    pub fn minimal_action(name: &str, module: &str, args: AnsibleValue) -> Self {
        let mut action = HashMap::new();
        action.insert(module.to_string(), args);
        Self {
            name: Some(name.to_string()),
            action,
            when_conditions: Vec::new(),
            register: None,
            loop_source: None,
            loop_items: None,
            with_items: None,
            loop_control: None,
            notify: Vec::new(),
            tags: TagSpec::default(),
            use_become: None,
            become_user: None,
            become_method: None,
            become_flags: None,
            become_pass: None,
            delegate_to: None,
            ignore_errors: false,
            run_once: false,
            changed_when: Vec::new(),
            failed_when: Vec::new(),
            retries: default_retries(),
            delay: default_delay(),
            until: Vec::new(),
            no_log: false,
            args: None,
            environment: None,
            vars: None,
            block: None,
            rescue: None,
            always: None,
            connection: None,
            timeout: None,
            check_mode: None,
        }
    }
}

fn default_retries() -> u32 {
    3
}

fn default_delay() -> u32 {
    5
}

/// Loop control settings.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LoopControl {
    pub loop_var: Option<String>,
    pub index_var: Option<String>,
    pub label: Option<String>,
    pub pause: Option<f64>,
    pub extended: Option<bool>,
}

/// Inline capacity for tag lists. Chosen to cover the common case of 0-2
/// tags per task without heap allocation; longer lists spill to the heap.
pub type TagList = smallvec::SmallVec<[String; 2]>;

/// Tag specification — can be a list of tags or special "always"/"never".
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
#[serde(untagged)]
pub enum TagSpec {
    #[default]
    None,
    Tags(TagList),
    Single(String),
}

impl TagSpec {
    /// Return the set of tags this spec carries as a borrowed slice.
    pub fn tags(&self) -> &[String] {
        match self {
            TagSpec::None => &[],
            TagSpec::Tags(v) => v.as_slice(),
            TagSpec::Single(s) => std::slice::from_ref(s),
        }
    }

    /// True when this spec explicitly carries the given tag.
    pub fn contains(&self, tag: &str) -> bool {
        self.tags().iter().any(|t| t == tag)
    }

    /// True when this spec declares the "always" tag, meaning matching
    /// tasks should run regardless of the user-provided --tags selection.
    pub fn is_always(&self) -> bool {
        self.contains("always")
    }

    /// True when this spec declares the "never" tag, meaning matching
    /// tasks should be skipped unless the user explicitly opts in via
    /// --tags.
    pub fn is_never(&self) -> bool {
        self.contains("never")
    }
}

/// A filter built from the user's `--tags` / `--skip-tags` CLI selection.
///
/// Semantics mirror Python Ansible:
/// - If the user passes `--tags`, only tasks whose tags intersect with the
///   selection run, except that the special tag `always` always runs unless
///   explicitly skipped, and `never` tags only run when the user opts in.
/// - If the user passes `--skip-tags`, any task whose tags intersect with
///   the skip list is skipped.
/// - With no filters configured, every task runs except tasks tagged
///   `never`.
/// - The magic tag `all` in `--tags` selects every tagged and untagged
///   task.
/// - The magic tag `tagged` / `untagged` select tasks that have / don't
///   have any tag.
#[derive(Debug, Clone, Default)]
pub struct TagFilter {
    include: Vec<String>,
    skip: Vec<String>,
}

impl TagFilter {
    /// Build a filter from comma-separated CLI strings. `None` means the
    /// user did not pass the flag at all.
    pub fn from_cli(tags: Option<&str>, skip_tags: Option<&str>) -> Self {
        fn parse(s: Option<&str>) -> Vec<String> {
            s.map(|raw| {
                raw.split(',')
                    .map(|t| t.trim())
                    .filter(|t| !t.is_empty())
                    .map(|t| t.to_string())
                    .collect()
            })
            .unwrap_or_default()
        }
        Self {
            include: parse(tags),
            skip: parse(skip_tags),
        }
    }

    /// True when there is no active filter.
    pub fn is_default(&self) -> bool {
        self.include.is_empty() && self.skip.is_empty()
    }

    /// Decide whether a task with the given tag spec should run.
    pub fn should_run(&self, task_tags: &TagSpec) -> bool {
        let tags = task_tags.tags();
        let has_always = task_tags.is_always();
        let has_never = task_tags.is_never();

        // Handle skip-tags first: an explicit skip always wins, even for
        // "always"-tagged tasks (matches Python Ansible behavior).
        if !self.skip.is_empty() {
            let user_asks_skip_always = self.skip.iter().any(|t| t == "all" || t == "always");
            if has_always && !user_asks_skip_always && !self.skip_matches(tags) {
                // Skip list doesn't cover us and we're tagged `always` — run.
            } else if self.skip_matches(tags) || (has_always && user_asks_skip_always) {
                return false;
            }
        }

        // With no include list active, run everything except `never`-tagged
        // tasks that weren't explicitly opted into.
        if self.include.is_empty() {
            if has_never {
                return false;
            }
            return true;
        }

        // Include list active: "always"-tagged tasks always run unless the
        // user explicitly skipped them above.
        if has_always {
            return true;
        }

        // "never"-tagged tasks run only if the user explicitly listed
        // `never` (or the tag itself) in --tags.
        if has_never && !self.include.iter().any(|t| t == "never" || tags.contains(t)) {
            return false;
        }

        // Magic selectors in --tags
        if self.include.iter().any(|t| t == "all") {
            return true;
        }
        if self.include.iter().any(|t| t == "tagged") && !tags.is_empty() {
            return true;
        }
        if self.include.iter().any(|t| t == "untagged") && tags.is_empty() {
            return true;
        }

        // Otherwise: run if the task's tags intersect with the include list.
        tags.iter().any(|t| self.include.iter().any(|i| i == t))
    }

    fn skip_matches(&self, tags: &[String]) -> bool {
        if self.skip.iter().any(|t| t == "all") {
            return true;
        }
        if self.skip.iter().any(|t| t == "tagged") && !tags.is_empty() {
            return true;
        }
        if self.skip.iter().any(|t| t == "untagged") && tags.is_empty() {
            return true;
        }
        tags.iter().any(|t| self.skip.iter().any(|s| s == t))
    }
}

/// Serial execution specification.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(untagged)]
pub enum SerialSpec {
    Count(usize),
    Percentage(String),
}

/// Role inclusion within a play.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RoleInclusion {
    pub role: String,
    #[serde(default)]
    pub vars: HashMap<String, AnsibleValue>,
    #[serde(default)]
    pub tags: TagSpec,
    #[serde(default, rename = "when")]
    pub when_conditions: Vec<String>,
    pub use_become: Option<bool>,
    pub become_user: Option<String>,
}

/// Privilege escalation settings.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct BecomeSettings {
    pub use_become: bool,
    pub become_method: String,
    pub become_user: String,
    pub become_pass: Option<String>,
    pub become_flags: Option<String>,
}

#[cfg(test)]
mod tag_filter_tests {
    use super::*;

    fn tags(values: &[&str]) -> TagSpec {
        TagSpec::Tags(values.iter().map(|s| s.to_string()).collect())
    }

    #[test]
    fn default_filter_runs_everything_except_never() {
        let f = TagFilter::default();
        assert!(f.is_default());
        assert!(f.should_run(&TagSpec::None));
        assert!(f.should_run(&tags(&["foo"])));
        assert!(!f.should_run(&tags(&["never"])));
        assert!(f.should_run(&tags(&["always"])));
    }

    #[test]
    fn include_filter_matches_by_tag() {
        let f = TagFilter::from_cli(Some("foo,bar"), None);
        assert!(f.should_run(&tags(&["foo"])));
        assert!(f.should_run(&tags(&["bar", "baz"])));
        assert!(!f.should_run(&tags(&["baz"])));
        assert!(!f.should_run(&TagSpec::None));
        // `always` still runs even when not in the include list
        assert!(f.should_run(&tags(&["always"])));
    }

    #[test]
    fn include_filter_all_magic() {
        let f = TagFilter::from_cli(Some("all"), None);
        assert!(f.should_run(&TagSpec::None));
        assert!(f.should_run(&tags(&["foo"])));
        // `never` is still excluded by `all`
        assert!(!f.should_run(&tags(&["never"])));
    }

    #[test]
    fn include_filter_tagged_magic() {
        let f = TagFilter::from_cli(Some("tagged"), None);
        assert!(f.should_run(&tags(&["foo"])));
        assert!(!f.should_run(&TagSpec::None));
    }

    #[test]
    fn include_filter_untagged_magic() {
        let f = TagFilter::from_cli(Some("untagged"), None);
        assert!(f.should_run(&TagSpec::None));
        assert!(!f.should_run(&tags(&["foo"])));
    }

    #[test]
    fn skip_filter_excludes_by_tag() {
        let f = TagFilter::from_cli(None, Some("foo"));
        assert!(!f.should_run(&tags(&["foo"])));
        assert!(f.should_run(&tags(&["bar"])));
        assert!(f.should_run(&TagSpec::None));
    }

    #[test]
    fn skip_filter_with_always_still_runs() {
        // A task tagged `always` is NOT automatically skipped just because
        // --skip-tags was provided — unless the user explicitly asks to
        // skip always.
        let f = TagFilter::from_cli(None, Some("foo"));
        assert!(f.should_run(&tags(&["always"])));
    }

    #[test]
    fn skip_filter_explicit_always() {
        let f = TagFilter::from_cli(None, Some("always"));
        assert!(!f.should_run(&tags(&["always"])));
    }

    #[test]
    fn include_and_skip_interact() {
        // User asks for tags "foo" but skip "foo.bar"
        let f = TagFilter::from_cli(Some("foo,bar"), Some("bar"));
        assert!(f.should_run(&tags(&["foo"])));
        // Tagged with both foo and bar — skip wins
        assert!(!f.should_run(&tags(&["foo", "bar"])));
    }

    #[test]
    fn never_runs_only_when_explicitly_listed() {
        let f = TagFilter::from_cli(Some("never"), None);
        assert!(f.should_run(&tags(&["never"])));

        let f2 = TagFilter::from_cli(Some("specialops"), None);
        assert!(!f2.should_run(&tags(&["never"])));
        // But a task tagged `never` AND `specialops` runs when the user
        // asks for `specialops`.
        assert!(f2.should_run(&tags(&["never", "specialops"])));
    }
}
