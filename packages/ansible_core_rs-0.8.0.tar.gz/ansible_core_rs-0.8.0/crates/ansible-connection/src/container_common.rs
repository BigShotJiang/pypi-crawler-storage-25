//! Shared command-construction and process-handling helpers for the
//! `docker` and `podman` connection plugins. Both runtimes expose the
//! same `exec` / `cp` / `inspect` CLI surface, so the connection
//! plugins differ only in the runtime program name.

use std::path::Path;
use std::process::Stdio;

use ansible_plugins::PluginError;
use tokio::process::Command;

/// Build the `<runtime> exec [-u USER] [-i] [extra...] CONTAINER /bin/sh -c CMD` Command.
///
/// Pulled out of [`exec_in_container`] so unit tests can inspect the
/// produced argv without spawning a subprocess.
pub(crate) fn build_exec_command(
    runtime: &str,
    container: &str,
    user: Option<&str>,
    extra_args: &[String],
    cmd: &str,
    with_stdin: bool,
) -> Command {
    let mut command = Command::new(runtime);
    command.arg("exec");
    if let Some(u) = user {
        command.arg("-u").arg(u);
    }
    if with_stdin {
        // -i keeps stdin open so module-via-stdin (pipelining) works.
        command.arg("-i");
    }
    for a in extra_args {
        command.arg(a);
    }
    command.arg(container).arg("/bin/sh").arg("-c").arg(cmd);
    command
}

pub(crate) async fn exec_in_container(
    runtime: &str,
    container: &str,
    user: Option<&str>,
    extra_args: &[String],
    cmd: &str,
    in_data: Option<&[u8]>,
) -> Result<(i32, Vec<u8>, Vec<u8>), PluginError> {
    let mut command =
        build_exec_command(runtime, container, user, extra_args, cmd, in_data.is_some());

    command
        .stdin(if in_data.is_some() {
            Stdio::piped()
        } else {
            Stdio::null()
        })
        .stdout(Stdio::piped())
        .stderr(Stdio::piped());

    let mut child = command
        .spawn()
        .map_err(|e| PluginError::ExecutionError(format!("{runtime} exec spawn: {e}")))?;

    if let Some(data) = in_data {
        use tokio::io::AsyncWriteExt;
        if let Some(mut stdin) = child.stdin.take() {
            stdin
                .write_all(data)
                .await
                .map_err(|e| PluginError::ExecutionError(format!("{runtime} stdin write: {e}")))?;
            drop(stdin);
        }
    }

    let output = child
        .wait_with_output()
        .await
        .map_err(|e| PluginError::ExecutionError(format!("{runtime} wait: {e}")))?;

    Ok((
        output.status.code().unwrap_or(-1),
        output.stdout,
        output.stderr,
    ))
}

/// Build the `<runtime> cp [extra...] LOCAL CONTAINER:REMOTE` Command.
pub(crate) fn build_cp_to_command(
    runtime: &str,
    container: &str,
    extra_args: &[String],
    local: &Path,
    remote: &Path,
) -> Command {
    let mut command = Command::new(runtime);
    command.arg("cp");
    for a in extra_args {
        command.arg(a);
    }
    command.arg(local);
    command.arg(format!("{}:{}", container, remote.display()));
    command
}

/// Build the `<runtime> cp [extra...] CONTAINER:REMOTE LOCAL` Command.
pub(crate) fn build_cp_from_command(
    runtime: &str,
    container: &str,
    extra_args: &[String],
    remote: &Path,
    local: &Path,
) -> Command {
    let mut command = Command::new(runtime);
    command.arg("cp");
    for a in extra_args {
        command.arg(a);
    }
    command.arg(format!("{}:{}", container, remote.display()));
    command.arg(local);
    command
}

pub(crate) async fn cp_to_container(
    runtime: &str,
    container: &str,
    extra_args: &[String],
    local: &Path,
    remote: &Path,
) -> Result<(), PluginError> {
    let mut command = build_cp_to_command(runtime, container, extra_args, local, remote);
    command.stdout(Stdio::piped()).stderr(Stdio::piped());
    let output = command
        .output()
        .await
        .map_err(|e| PluginError::ExecutionError(format!("{runtime} cp spawn: {e}")))?;
    if !output.status.success() {
        return Err(PluginError::ExecutionError(format!(
            "{runtime} cp put failed (rc={}): {}",
            output.status.code().unwrap_or(-1),
            String::from_utf8_lossy(&output.stderr).trim()
        )));
    }
    Ok(())
}

pub(crate) async fn cp_from_container(
    runtime: &str,
    container: &str,
    extra_args: &[String],
    remote: &Path,
    local: &Path,
) -> Result<(), PluginError> {
    let mut command = build_cp_from_command(runtime, container, extra_args, remote, local);
    command.stdout(Stdio::piped()).stderr(Stdio::piped());
    let output = command
        .output()
        .await
        .map_err(|e| PluginError::ExecutionError(format!("{runtime} cp spawn: {e}")))?;
    if !output.status.success() {
        return Err(PluginError::ExecutionError(format!(
            "{runtime} cp get failed (rc={}): {}",
            output.status.code().unwrap_or(-1),
            String::from_utf8_lossy(&output.stderr).trim()
        )));
    }
    Ok(())
}

/// Probe `<runtime> inspect CONTAINER` so `connect()` fails fast with a
/// clear error if the named container doesn't exist or the runtime
/// daemon isn't reachable.
pub(crate) async fn verify_container(runtime: &str, container: &str) -> Result<(), PluginError> {
    let mut cmd = Command::new(runtime);
    cmd.arg("inspect")
        .arg("--format")
        .arg("{{.State.Running}}")
        .arg(container);
    cmd.stdout(Stdio::piped()).stderr(Stdio::piped());

    let output = cmd
        .output()
        .await
        .map_err(|e| PluginError::ExecutionError(format!("{runtime} inspect spawn: {e}")))?;

    if !output.status.success() {
        return Err(PluginError::ExecutionError(format!(
            "{runtime} container {container:?} not found or {runtime} daemon unreachable: {}",
            String::from_utf8_lossy(&output.stderr).trim()
        )));
    }

    let running = String::from_utf8_lossy(&output.stdout).trim().to_string();
    if running != "true" {
        return Err(PluginError::ExecutionError(format!(
            "{runtime} container {container:?} is not running (state={running})"
        )));
    }
    Ok(())
}
