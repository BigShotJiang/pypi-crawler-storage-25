//! Podman connection plugin — runs commands inside a Podman container
//! via `podman exec` and `podman cp`.
//!
//! This mirrors upstream's `containers.podman.podman` connection plugin.
//! Podman is API-compatible with Docker for `exec`/`cp`/`inspect`, so the
//! implementation reuses the shared command builders in `container_common`.
//!
//! Ansible variables honored:
//! - `ansible_host` — container name or ID (defaults to the inventory hostname)
//! - `ansible_user` — user inside the container (passed as `podman exec -u USER`)
//! - `ansible_podman_extra_args` — extra args appended to every `podman` invocation

use std::path::Path;

use ansible_plugins::PluginError;
use async_trait::async_trait;
use tracing::debug;

use crate::container_common::{
    cp_from_container, cp_to_container, exec_in_container, verify_container,
};

const RUNTIME: &str = "podman";

pub struct PodmanConnection {
    pub container: String,
    pub user: Option<String>,
    pub extra_args: Vec<String>,
}

impl PodmanConnection {
    pub fn new(container: String) -> Self {
        Self {
            container,
            user: None,
            extra_args: Vec::new(),
        }
    }
}

#[async_trait]
impl ansible_plugins::ConnectionPlugin for PodmanConnection {
    async fn connect(&mut self) -> Result<(), PluginError> {
        debug!(
            "[{}] verifying podman container is running",
            self.container
        );
        verify_container(RUNTIME, &self.container).await
    }

    async fn exec_command(
        &self,
        cmd: &str,
        in_data: Option<&[u8]>,
    ) -> Result<(i32, Vec<u8>, Vec<u8>), PluginError> {
        exec_in_container(
            RUNTIME,
            &self.container,
            self.user.as_deref(),
            &self.extra_args,
            cmd,
            in_data,
        )
        .await
    }

    async fn put_file(&self, in_path: &Path, out_path: &Path) -> Result<(), PluginError> {
        debug!(
            "[{}] put_file {} -> {}",
            self.container,
            in_path.display(),
            out_path.display()
        );
        cp_to_container(
            RUNTIME,
            &self.container,
            &self.extra_args,
            in_path,
            out_path,
        )
        .await
    }

    async fn fetch_file(&self, in_path: &Path, out_path: &Path) -> Result<(), PluginError> {
        debug!(
            "[{}] fetch_file {} -> {}",
            self.container,
            in_path.display(),
            out_path.display()
        );
        cp_from_container(
            RUNTIME,
            &self.container,
            &self.extra_args,
            in_path,
            out_path,
        )
        .await
    }

    async fn close(&mut self) -> Result<(), PluginError> {
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::container_common::{build_cp_to_command, build_exec_command};
    use std::path::PathBuf;

    fn argv(cmd: &tokio::process::Command) -> Vec<String> {
        cmd.as_std()
            .get_args()
            .map(|a| a.to_string_lossy().to_string())
            .collect()
    }

    fn program(cmd: &tokio::process::Command) -> String {
        cmd.as_std().get_program().to_string_lossy().to_string()
    }

    #[test]
    fn new_defaults() {
        let conn = PodmanConnection::new("db".into());
        assert_eq!(conn.container, "db");
        assert!(conn.user.is_none());
        assert!(conn.extra_args.is_empty());
    }

    #[test]
    fn exec_command_uses_podman_program() {
        let cmd = build_exec_command(RUNTIME, "db", None, &[], "uptime", false);
        assert_eq!(program(&cmd), "podman");
        let args = argv(&cmd);
        assert_eq!(args[0], "exec");
    }

    #[test]
    fn exec_command_with_user_and_extra_args() {
        let extra = vec!["--log-level=debug".to_string()];
        let cmd = build_exec_command(RUNTIME, "db", Some("postgres"), &extra, "psql", true);
        let args = argv(&cmd);
        let u_idx = args.iter().position(|a| a == "-u").expect("missing -u");
        assert_eq!(args[u_idx + 1], "postgres");
        assert!(args.contains(&"-i".into()));
        assert!(args.contains(&"--log-level=debug".into()));
    }

    #[test]
    fn cp_command_targets_podman() {
        let cmd = build_cp_to_command(
            RUNTIME,
            "db",
            &[],
            &PathBuf::from("/local/dump.sql"),
            &PathBuf::from("/var/data/dump.sql"),
        );
        assert_eq!(program(&cmd), "podman");
        let args = argv(&cmd);
        assert_eq!(args[0], "cp");
        assert_eq!(args[args.len() - 1], "db:/var/data/dump.sql");
    }
}
