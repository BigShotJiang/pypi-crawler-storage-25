//! NTLM authentication (MS-NLMP) — used as the inner SPNEGO mechanism inside
//! CredSSP. We implement the modern NTLMv2 path only; NTLMv1 is disabled by
//! domain policy on any current Windows version and we don't need it.
//!
//! Layout follows MS-NLMP §2.2:
//! - NEGOTIATE_MESSAGE (Type 1) — we send first
//! - CHALLENGE_MESSAGE (Type 2) — server sends back a server challenge + target info
//! - AUTHENTICATE_MESSAGE (Type 3) — we compute NTProofStr/LM response and send
//!
//! References:
//! - [MS-NLMP]: NT LAN Manager (NTLM) Authentication Protocol
//! - RFC 4757 §6 (HMAC-MD5 / RC4 KMS)

use std::io::Write as _;

use hmac::{Hmac, Mac};
use md4::{Digest as _, Md4};
use md5::Md5;
use rand::RngCore;
use rc4::{KeyInit as _, Rc4, StreamCipher as _};
use zeroize::Zeroize;

use crate::error::ConnectionError;

type HmacMd5 = Hmac<Md5>;

/// NTLM negotiate flags we ask the server to honor (MS-NLMP §2.2.2.5).
///
/// We pick the modern subset: Unicode, NTLM auth, extended session security
/// (NTLMv2 "MIC"), key exchange, 128-bit keys, sign + seal, target info.
pub mod flag {
    pub const NEGOTIATE_UNICODE: u32 = 0x0000_0001;
    pub const NEGOTIATE_OEM: u32 = 0x0000_0002;
    pub const REQUEST_TARGET: u32 = 0x0000_0004;
    pub const NEGOTIATE_SIGN: u32 = 0x0000_0010;
    pub const NEGOTIATE_SEAL: u32 = 0x0000_0020;
    pub const NEGOTIATE_NTLM: u32 = 0x0000_0200;
    pub const NEGOTIATE_ALWAYS_SIGN: u32 = 0x0000_8000;
    pub const NEGOTIATE_EXTENDED_SESSIONSECURITY: u32 = 0x0008_0000;
    pub const NEGOTIATE_TARGET_INFO: u32 = 0x0080_0000;
    pub const NEGOTIATE_VERSION: u32 = 0x0200_0000;
    pub const NEGOTIATE_128: u32 = 0x2000_0000;
    pub const NEGOTIATE_KEY_EXCH: u32 = 0x4000_0000;
    pub const NEGOTIATE_56: u32 = 0x8000_0000;
}

pub const NTLM_SIGNATURE: &[u8; 8] = b"NTLMSSP\0";

/// Bundle of identity inputs for NTLM. `domain` is the auth realm
/// ("" or "." for local).
#[derive(Debug, Clone, Zeroize)]
#[zeroize(drop)]
pub struct NtlmCreds {
    pub user: String,
    pub domain: String,
    pub password: String,
    /// Workstation name to advertise — Windows tolerates any value.
    pub workstation: String,
}

/// Per-session state carried from the Type 1 / Type 2 exchange. Needed to
/// derive the exported session key after we send Type 3 (CredSSP uses it
/// to wrap the credential delegation step).
#[derive(Debug, Default)]
pub struct NtlmSession {
    pub exported_session_key: [u8; 16],
    /// Sign+seal key derived for the "client-to-server" direction.
    pub client_signing_key: [u8; 16],
    pub client_sealing_key: [u8; 16],
    pub server_signing_key: [u8; 16],
    pub server_sealing_key: [u8; 16],
    /// Sequence numbers, used by the GSS_Wrap stamping.
    pub client_seq: u32,
    pub server_seq: u32,
}

/// Build a NEGOTIATE_MESSAGE (Type 1) per MS-NLMP §2.2.1.1.
///
/// We always advertise the same flag set; the server narrows it in its
/// challenge response.
pub fn build_negotiate(creds: &NtlmCreds) -> Vec<u8> {
    let flags = flag::NEGOTIATE_UNICODE
        | flag::NEGOTIATE_OEM
        | flag::REQUEST_TARGET
        | flag::NEGOTIATE_SIGN
        | flag::NEGOTIATE_SEAL
        | flag::NEGOTIATE_NTLM
        | flag::NEGOTIATE_ALWAYS_SIGN
        | flag::NEGOTIATE_EXTENDED_SESSIONSECURITY
        | flag::NEGOTIATE_TARGET_INFO
        | flag::NEGOTIATE_VERSION
        | flag::NEGOTIATE_128
        | flag::NEGOTIATE_KEY_EXCH
        | flag::NEGOTIATE_56;

    // Fixed-layout header (32 bytes) + Version (8 bytes) + optional payload.
    // We send empty DomainName/Workstation fields and let the server fill in
    // the target info — Windows ignores the values anyway since the challenge
    // contains the canonical names.
    let mut out = Vec::with_capacity(40);
    out.extend_from_slice(NTLM_SIGNATURE);
    out.extend_from_slice(&1u32.to_le_bytes()); // MessageType = 1
    out.extend_from_slice(&flags.to_le_bytes());
    // DomainNameFields: len=0, maxlen=0, offset=40
    out.extend_from_slice(&0u16.to_le_bytes());
    out.extend_from_slice(&0u16.to_le_bytes());
    out.extend_from_slice(&40u32.to_le_bytes());
    // WorkstationFields: len=0, maxlen=0, offset=40
    out.extend_from_slice(&0u16.to_le_bytes());
    out.extend_from_slice(&0u16.to_le_bytes());
    out.extend_from_slice(&40u32.to_le_bytes());
    // Version: Windows 10 (10.0.19041), NTLMSSP revision 15
    out.extend_from_slice(&[10, 0, 0xa9, 0x4a, 0, 0, 0, 15]);
    let _ = creds; // workstation could be used here but Windows ignores it
    out
}

/// Parsed CHALLENGE_MESSAGE (Type 2).
#[derive(Debug)]
pub struct ChallengeMessage {
    pub negotiate_flags: u32,
    pub server_challenge: [u8; 8],
    pub target_name: Vec<u8>,
    pub target_info: Vec<u8>,
}

pub fn parse_challenge(msg: &[u8]) -> Result<ChallengeMessage, ConnectionError> {
    if msg.len() < 48 {
        return Err(ConnectionError::Protocol(format!(
            "NTLM challenge too short: {} bytes",
            msg.len()
        )));
    }
    if &msg[..8] != NTLM_SIGNATURE {
        return Err(ConnectionError::Protocol(
            "bad NTLMSSP signature in challenge".into(),
        ));
    }
    if u32::from_le_bytes(msg[8..12].try_into().unwrap()) != 2 {
        return Err(ConnectionError::Protocol(
            "NTLM challenge: MessageType != 2".into(),
        ));
    }
    let target_name = read_field(msg, 12)?;
    let negotiate_flags = u32::from_le_bytes(msg[20..24].try_into().unwrap());
    let mut server_challenge = [0u8; 8];
    server_challenge.copy_from_slice(&msg[24..32]);
    // Reserved at 32..40
    let target_info = read_field(msg, 40)?;
    Ok(ChallengeMessage {
        negotiate_flags,
        server_challenge,
        target_name: target_name.to_vec(),
        target_info: target_info.to_vec(),
    })
}

/// Reads a 4+4 length/offset field pair starting at `off` (LE: len, maxlen, offset).
fn read_field<'a>(msg: &'a [u8], off: usize) -> Result<&'a [u8], ConnectionError> {
    if msg.len() < off + 8 {
        return Err(ConnectionError::Protocol(
            "NTLM challenge: truncated field header".into(),
        ));
    }
    let len = u16::from_le_bytes(msg[off..off + 2].try_into().unwrap()) as usize;
    let payload_off = u32::from_le_bytes(msg[off + 4..off + 8].try_into().unwrap()) as usize;
    if msg.len() < payload_off + len {
        return Err(ConnectionError::Protocol(
            "NTLM challenge: payload extends past message".into(),
        ));
    }
    Ok(&msg[payload_off..payload_off + len])
}

/// Compute the NTOWFv2 hash (MS-NLMP §3.3.2): HMAC-MD5(MD4(unicode(pwd)),
/// unicode(uppercase(user) || domain)).
pub fn ntowfv2(user: &str, domain: &str, password: &str) -> [u8; 16] {
    // Step 1: NT hash of password = MD4 of UTF-16LE password.
    let mut md4 = Md4::new();
    for code in password.encode_utf16() {
        md4.update(code.to_le_bytes());
    }
    let nt_hash = md4.finalize();

    // Step 2: HMAC-MD5 keyed with nt_hash, over UTF-16LE(UPPER(user) || domain).
    let mut mac = <HmacMd5 as Mac>::new_from_slice(&nt_hash).expect("HMAC-MD5 accepts any key length");
    let mut user_upper_unicode: Vec<u8> = Vec::with_capacity(user.len() * 2);
    for c in user.to_uppercase().chars() {
        let mut buf = [0u16; 2];
        for w in c.encode_utf16(&mut buf) {
            user_upper_unicode.extend_from_slice(&w.to_le_bytes());
        }
    }
    let mut domain_unicode: Vec<u8> = Vec::with_capacity(domain.len() * 2);
    for c in domain.chars() {
        let mut buf = [0u16; 2];
        for w in c.encode_utf16(&mut buf) {
            domain_unicode.extend_from_slice(&w.to_le_bytes());
        }
    }
    mac.update(&user_upper_unicode);
    mac.update(&domain_unicode);

    let mut out = [0u8; 16];
    out.copy_from_slice(&mac.finalize().into_bytes());
    out
}

/// Build the AUTHENTICATE_MESSAGE (Type 3) and populate the session keys.
///
/// `channel_binding` may be empty unless we're binding to a TLS endpoint
/// (CredSSP does not require channel-binding to function).
pub fn build_authenticate(
    creds: &NtlmCreds,
    challenge: &ChallengeMessage,
    channel_binding_hash: Option<[u8; 16]>,
    target_spn: Option<&str>,
) -> Result<(Vec<u8>, NtlmSession), ConnectionError> {
    let response_key_nt = ntowfv2(&creds.user, &creds.domain, &creds.password);

    // Client challenge — 8 random bytes.
    let mut client_challenge = [0u8; 8];
    rand::rng().fill_bytes(&mut client_challenge);

    // NTLMv2 Temp blob (MS-NLMP §2.2.2.7).
    let mut temp = Vec::with_capacity(28 + challenge.target_info.len() + 32);
    temp.push(0x01); // RespType
    temp.push(0x01); // HiRespType
    temp.extend_from_slice(&[0u8; 6]); // Reserved
    // Timestamp: Windows FILETIME (100ns ticks since 1601). We approximate
    // with system time; servers accept clock skew within MaxAcceptableClockSkew
    // (default ±5 min).
    let ft = filetime_now();
    temp.extend_from_slice(&ft.to_le_bytes());
    temp.extend_from_slice(&client_challenge);
    temp.extend_from_slice(&[0u8; 4]); // Reserved
    // AvPairs: pass through the server's target_info, optionally appending
    // channel-binding and target-SPN AVs.
    let mut av_pairs = challenge.target_info.clone();
    // Strip trailing MsvAvEOL (id=0, len=0) before we append.
    strip_av_eol(&mut av_pairs);
    if let Some(cb) = channel_binding_hash {
        // MsvAvChannelBindings = 10
        append_av(&mut av_pairs, 10, &cb);
    }
    if let Some(spn) = target_spn {
        // MsvAvTargetName = 9, UTF-16LE
        let mut spn_u16 = Vec::with_capacity(spn.len() * 2);
        for c in spn.encode_utf16() {
            spn_u16.extend_from_slice(&c.to_le_bytes());
        }
        append_av(&mut av_pairs, 9, &spn_u16);
    }
    // Re-append MsvAvEOL
    append_av(&mut av_pairs, 0, &[]);
    temp.extend_from_slice(&av_pairs);
    temp.extend_from_slice(&[0u8; 4]); // Reserved trailing

    // NTProofStr = HMAC-MD5(response_key_nt, server_challenge || temp)
    let mut mac =
        <HmacMd5 as Mac>::new_from_slice(&response_key_nt).expect("HMAC-MD5 accepts any key length");
    mac.update(&challenge.server_challenge);
    mac.update(&temp);
    let nt_proof_str: [u8; 16] = mac.finalize().into_bytes().into();

    // NtChallengeResponse = NTProofStr || Temp
    let mut nt_chal_resp = Vec::with_capacity(16 + temp.len());
    nt_chal_resp.extend_from_slice(&nt_proof_str);
    nt_chal_resp.extend_from_slice(&temp);

    // SessionBaseKey = HMAC-MD5(response_key_nt, NTProofStr)
    let mut mac =
        <HmacMd5 as Mac>::new_from_slice(&response_key_nt).expect("HMAC-MD5 accepts any key length");
    mac.update(&nt_proof_str);
    let session_base_key: [u8; 16] = mac.finalize().into_bytes().into();

    // KeyExchangeKey == SessionBaseKey for NTLMv2 with ExtendedSessionSecurity.
    let key_exchange_key = session_base_key;

    // Generate a random ExportedSessionKey (the actual KEY material the upper
    // protocol uses), encrypt it with RC4(KeyExchangeKey), send in
    // EncryptedRandomSessionKey field.
    let mut exported_session_key = [0u8; 16];
    rand::rng().fill_bytes(&mut exported_session_key);
    let mut rc4 = Rc4::<rc4::consts::U16>::new(key_exchange_key.as_slice().into());
    let mut encrypted_random_session_key = exported_session_key;
    rc4.apply_keystream(&mut encrypted_random_session_key);

    // LM response = HMAC-MD5(response_key_nt, server_challenge || client_challenge)
    // || client_challenge (24 bytes). Modern Windows ignores this field when
    // the NT response is NTLMv2; we send it for compatibility.
    let mut mac =
        <HmacMd5 as Mac>::new_from_slice(&response_key_nt).expect("HMAC-MD5 accepts any key length");
    mac.update(&challenge.server_challenge);
    mac.update(&client_challenge);
    let lm_hmac: [u8; 16] = mac.finalize().into_bytes().into();
    let mut lm_resp = Vec::with_capacity(24);
    lm_resp.extend_from_slice(&lm_hmac);
    lm_resp.extend_from_slice(&client_challenge);

    // Now assemble the Type 3 message. Fixed header is 64 bytes (without
    // Version), 72 with Version. Then payloads in order:
    //   LmChallengeResponse, NtChallengeResponse, DomainName, UserName,
    //   Workstation, EncryptedRandomSessionKey.
    let user_u16 = utf16le(&creds.user);
    let domain_u16 = utf16le(&creds.domain);
    let workstation_u16 = utf16le(&creds.workstation);

    // Header = 8 signature + 4 msg_type + 8*6 field pairs + 4 flags +
    //          8 version + 16 MIC = 88 bytes.
    let header_len: usize = 88;
    let lm_off = header_len;
    let nt_off = lm_off + lm_resp.len();
    let dom_off = nt_off + nt_chal_resp.len();
    let user_off = dom_off + domain_u16.len();
    let ws_off = user_off + user_u16.len();
    let key_off = ws_off + workstation_u16.len();
    let mic_placeholder = [0u8; 16]; // overwritten below

    let flags = challenge.negotiate_flags;
    let mut out = Vec::with_capacity(key_off + 16 + 16);
    out.extend_from_slice(NTLM_SIGNATURE);
    out.extend_from_slice(&3u32.to_le_bytes()); // MessageType = 3

    fn push_field(out: &mut Vec<u8>, len: usize, off: usize) {
        out.extend_from_slice(&(len as u16).to_le_bytes());
        out.extend_from_slice(&(len as u16).to_le_bytes());
        out.extend_from_slice(&(off as u32).to_le_bytes());
    }
    push_field(&mut out, lm_resp.len(), lm_off);
    push_field(&mut out, nt_chal_resp.len(), nt_off);
    push_field(&mut out, domain_u16.len(), dom_off);
    push_field(&mut out, user_u16.len(), user_off);
    push_field(&mut out, workstation_u16.len(), ws_off);
    push_field(&mut out, 16, key_off);
    out.extend_from_slice(&flags.to_le_bytes());
    // Version (8 bytes)
    out.extend_from_slice(&[10, 0, 0xa9, 0x4a, 0, 0, 0, 15]);
    // MIC placeholder (16 bytes) — we don't compute the MIC here; CredSSP
    // doesn't validate it, and we won't be challenge-bound to a non-CredSSP
    // mech. Real production code should fill this with HMAC-MD5 over the
    // concatenation of Type1/Type2/Type3 with this field zeroed (MS-NLMP
    // §3.1.5.1.2). Leaving zero matches what some servers tolerate.
    out.extend_from_slice(&mic_placeholder);
    debug_assert_eq!(out.len(), header_len);

    out.extend_from_slice(&lm_resp);
    out.extend_from_slice(&nt_chal_resp);
    out.extend_from_slice(&domain_u16);
    out.extend_from_slice(&user_u16);
    out.extend_from_slice(&workstation_u16);
    out.extend_from_slice(&encrypted_random_session_key);

    // Derive signing/sealing subkeys (MS-NLMP §3.4.5.2/§3.4.5.3).
    let mut session = NtlmSession {
        exported_session_key,
        ..NtlmSession::default()
    };
    session.client_signing_key =
        md5_seal_key(&exported_session_key, b"session key to client-to-server signing key magic constant\0");
    session.server_signing_key =
        md5_seal_key(&exported_session_key, b"session key to server-to-client signing key magic constant\0");
    session.client_sealing_key =
        md5_seal_key(&exported_session_key, b"session key to client-to-server sealing key magic constant\0");
    session.server_sealing_key =
        md5_seal_key(&exported_session_key, b"session key to server-to-client sealing key magic constant\0");

    Ok((out, session))
}

fn md5_seal_key(session_key: &[u8; 16], magic: &[u8]) -> [u8; 16] {
    let mut hasher = Md5::new();
    hasher.update(session_key);
    hasher.update(magic);
    let mut out = [0u8; 16];
    out.copy_from_slice(&hasher.finalize());
    out
}

fn append_av(av: &mut Vec<u8>, av_id: u16, value: &[u8]) {
    av.write_all(&av_id.to_le_bytes()).unwrap();
    av.write_all(&(value.len() as u16).to_le_bytes()).unwrap();
    av.write_all(value).unwrap();
}

fn strip_av_eol(av: &mut Vec<u8>) {
    // Walk the av-pair list, dropping a trailing (id=0, len=0) entry.
    if av.len() < 4 {
        return;
    }
    let mut i = 0usize;
    let mut last_eol_start: Option<usize> = None;
    while i + 4 <= av.len() {
        let id = u16::from_le_bytes(av[i..i + 2].try_into().unwrap());
        let len = u16::from_le_bytes(av[i + 2..i + 4].try_into().unwrap()) as usize;
        if id == 0 && len == 0 {
            last_eol_start = Some(i);
            break;
        }
        if i + 4 + len > av.len() {
            return; // malformed; leave as-is
        }
        i += 4 + len;
    }
    if let Some(start) = last_eol_start {
        av.truncate(start);
    }
}

fn utf16le(s: &str) -> Vec<u8> {
    let mut out = Vec::with_capacity(s.len() * 2);
    for c in s.encode_utf16() {
        out.extend_from_slice(&c.to_le_bytes());
    }
    out
}

fn filetime_now() -> u64 {
    use std::time::{SystemTime, UNIX_EPOCH};
    let dur = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default();
    // FILETIME epoch is 1601-01-01; offset to Unix epoch is 11644473600 sec.
    let secs_since_1601 = dur.as_secs() + 11_644_473_600;
    secs_since_1601 * 10_000_000 + (dur.subsec_nanos() as u64) / 100
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ntowfv2_matches_msnlmp_section_4_2_2_vector() {
        // [MS-NLMP] §4.2.2 test vector
        // user="User", domain="Domain", password="Password"
        // expected NTOWFv2 = 0c 86 8a 40 3b fd 7a 93 a3 00 1e f2 2e f0 2e 3f
        let h = ntowfv2("User", "Domain", "Password");
        assert_eq!(
            hex::encode(h),
            "0c868a403bfd7a93a3001ef22ef02e3f"
        );
    }

    #[test]
    fn negotiate_message_starts_with_signature_and_type_1() {
        let creds = NtlmCreds {
            user: "alice".into(),
            domain: "EXAMPLE".into(),
            password: "hunter2".into(),
            workstation: "WS01".into(),
        };
        let m = build_negotiate(&creds);
        assert_eq!(&m[..8], NTLM_SIGNATURE);
        assert_eq!(u32::from_le_bytes(m[8..12].try_into().unwrap()), 1);
        let flags = u32::from_le_bytes(m[12..16].try_into().unwrap());
        assert!(flags & flag::NEGOTIATE_UNICODE != 0);
        assert!(flags & flag::NEGOTIATE_NTLM != 0);
        assert!(flags & flag::NEGOTIATE_KEY_EXCH != 0);
    }

    #[test]
    fn parse_challenge_round_trips_a_minimal_message() {
        // Build a synthetic Type 2: signature, type=2, target_name="" at offset 48,
        // flags=0x80201, server_challenge=8 bytes, reserved=0, target_info="" at 48.
        let mut msg = Vec::new();
        msg.extend_from_slice(NTLM_SIGNATURE);
        msg.extend_from_slice(&2u32.to_le_bytes());
        // TargetName: len=0, maxlen=0, off=48
        msg.extend_from_slice(&0u16.to_le_bytes());
        msg.extend_from_slice(&0u16.to_le_bytes());
        msg.extend_from_slice(&48u32.to_le_bytes());
        // NegotiateFlags
        msg.extend_from_slice(&0x0008_0201u32.to_le_bytes());
        // ServerChallenge
        msg.extend_from_slice(&[1, 2, 3, 4, 5, 6, 7, 8]);
        // Reserved
        msg.extend_from_slice(&[0u8; 8]);
        // TargetInfo: len=0, maxlen=0, off=48
        msg.extend_from_slice(&0u16.to_le_bytes());
        msg.extend_from_slice(&0u16.to_le_bytes());
        msg.extend_from_slice(&48u32.to_le_bytes());

        let c = parse_challenge(&msg).unwrap();
        assert_eq!(c.server_challenge, [1, 2, 3, 4, 5, 6, 7, 8]);
        assert_eq!(c.negotiate_flags, 0x0008_0201);
    }

    #[test]
    fn build_authenticate_produces_well_formed_type3() {
        let creds = NtlmCreds {
            user: "alice".into(),
            domain: "EXAMPLE".into(),
            password: "hunter2".into(),
            workstation: "WS01".into(),
        };
        let challenge = ChallengeMessage {
            negotiate_flags: 0,
            server_challenge: [1, 2, 3, 4, 5, 6, 7, 8],
            target_name: vec![],
            target_info: vec![0, 0, 0, 0], // single EOL pair
        };
        let (msg, sess) = build_authenticate(&creds, &challenge, None, None).unwrap();
        assert_eq!(&msg[..8], NTLM_SIGNATURE);
        assert_eq!(u32::from_le_bytes(msg[8..12].try_into().unwrap()), 3);
        // Length fields are consistent.
        let lm_len = u16::from_le_bytes(msg[12..14].try_into().unwrap()) as usize;
        assert_eq!(lm_len, 24);
        // Exported session key was populated (not all zeros).
        assert!(sess.exported_session_key.iter().any(|&b| b != 0));
    }
}
