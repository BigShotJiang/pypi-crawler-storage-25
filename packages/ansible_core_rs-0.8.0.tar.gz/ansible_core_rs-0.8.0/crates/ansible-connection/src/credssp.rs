//! CredSSP authentication ([MS-CSSP]).
//!
//! CredSSP runs an *inner* TLS handshake on top of the outer transport (in our
//! case, an outer TLS connection to WinRM's HTTPS port 5986). Inside the inner
//! TLS, it carries `TSRequest` ASN.1 DER messages that wrap an SPNEGO/NTLM
//! authentication and, ultimately, delegate the user's password to the
//! server via `TSCredentials`.
//!
//! Flow (MS-CSSP §3.1.5):
//!   client → server: TSRequest { negoTokens: [NTLM Type 1] }
//!   server → client: TSRequest { negoTokens: [NTLM Type 2] }
//!   client → server: TSRequest { negoTokens: [NTLM Type 3],
//!                                pubKeyAuth: encrypt(server_cert_pubkey) }
//!   server → client: TSRequest { pubKeyAuth: encrypt(pubkey + 1) }
//!   client → server: TSRequest { authInfo: encrypt(TSCredentials) }
//!
//! After the server validates `pubKeyAuth` (proves it's not a MITM that
//! presented its own cert), the client encrypts the actual credentials and
//! sends them in `authInfo`. The server then logs in as the user.

use rustls::pki_types::ServerName;
use rustls::{ClientConfig, ClientConnection, RootCertStore};
use std::io::{Read, Write};
use std::net::TcpStream;
use std::sync::Arc;

use crate::error::ConnectionError;
use crate::ntlm::{
    build_authenticate, build_negotiate, parse_challenge, NtlmCreds, NtlmSession,
};

/// CredSSP protocol version we advertise. Windows 10+/Server 2016+ support 6,
/// but version 6 introduces structured-error returns that we don't need; 5 is
/// the safe interop floor.
pub const TS_REQUEST_VERSION: u32 = 5;

/// Optional set of fields in a TSRequest. Only the ones in use for a given
/// step are encoded — the others are omitted in DER.
#[derive(Default, Debug)]
pub struct TsRequest {
    pub version: u32,
    pub nego_tokens: Option<Vec<u8>>,
    pub auth_info: Option<Vec<u8>>,
    pub pub_key_auth: Option<Vec<u8>>,
    pub error_code: Option<u32>,
    pub client_nonce: Option<Vec<u8>>,
}

impl TsRequest {
    pub fn new(version: u32) -> Self {
        Self { version, ..Default::default() }
    }

    /// DER-encode this TSRequest per [MS-CSSP] §2.2.1.
    ///
    /// ```asn1
    /// TSRequest ::= SEQUENCE {
    ///     version    [0] INTEGER,
    ///     negoTokens [1] NegoData OPTIONAL,
    ///     authInfo   [2] OCTET STRING OPTIONAL,
    ///     pubKeyAuth [3] OCTET STRING OPTIONAL,
    ///     errorCode  [4] INTEGER OPTIONAL,
    ///     clientNonce[5] OCTET STRING OPTIONAL
    /// }
    /// NegoData ::= SEQUENCE OF SEQUENCE { negoToken [0] OCTET STRING }
    /// ```
    pub fn to_der(&self) -> Vec<u8> {
        yasna::construct_der(|w| {
            w.write_sequence(|w| {
                // [0] version
                w.next().write_tagged(yasna::Tag::context(0), |w| {
                    w.write_u32(self.version);
                });
                // [1] negoTokens
                if let Some(ref token) = self.nego_tokens {
                    w.next().write_tagged(yasna::Tag::context(1), |w| {
                        w.write_sequence(|w| {
                            w.next().write_sequence(|w| {
                                w.next().write_tagged(yasna::Tag::context(0), |w| {
                                    w.write_bytes(token);
                                });
                            });
                        });
                    });
                }
                // [2] authInfo
                if let Some(ref ai) = self.auth_info {
                    w.next().write_tagged(yasna::Tag::context(2), |w| {
                        w.write_bytes(ai);
                    });
                }
                // [3] pubKeyAuth
                if let Some(ref pka) = self.pub_key_auth {
                    w.next().write_tagged(yasna::Tag::context(3), |w| {
                        w.write_bytes(pka);
                    });
                }
                // [4] errorCode
                if let Some(ec) = self.error_code {
                    w.next().write_tagged(yasna::Tag::context(4), |w| {
                        w.write_u32(ec);
                    });
                }
                // [5] clientNonce
                if let Some(ref nonce) = self.client_nonce {
                    w.next().write_tagged(yasna::Tag::context(5), |w| {
                        w.write_bytes(nonce);
                    });
                }
            });
        })
    }

    /// Parse a TSRequest DER blob received from the server.
    pub fn from_der(der: &[u8]) -> Result<Self, ConnectionError> {
        yasna::parse_der(der, |reader| {
            reader.read_sequence(|seq| {
                let mut out = TsRequest::default();
                // [0] version (required)
                out.version = seq.next().read_tagged(yasna::Tag::context(0), |r| r.read_u32())?;
                // The rest are optional and may appear in order. We peek by
                // attempting to read each optional tag.
                let _ = seq.read_optional(|r| {
                    r.read_tagged(yasna::Tag::context(1), |r| {
                        // negoTokens
                        r.read_sequence(|s| {
                            s.next().read_sequence(|s| {
                                let bytes = s
                                    .next()
                                    .read_tagged(yasna::Tag::context(0), |r| r.read_bytes())?;
                                out.nego_tokens = Some(bytes);
                                Ok(())
                            })
                        })
                    })
                });
                let _ = seq.read_optional(|r| {
                    r.read_tagged(yasna::Tag::context(2), |r| {
                        out.auth_info = Some(r.read_bytes()?);
                        Ok(())
                    })
                });
                let _ = seq.read_optional(|r| {
                    r.read_tagged(yasna::Tag::context(3), |r| {
                        out.pub_key_auth = Some(r.read_bytes()?);
                        Ok(())
                    })
                });
                let _ = seq.read_optional(|r| {
                    r.read_tagged(yasna::Tag::context(4), |r| {
                        out.error_code = Some(r.read_u32()?);
                        Ok(())
                    })
                });
                let _ = seq.read_optional(|r| {
                    r.read_tagged(yasna::Tag::context(5), |r| {
                        out.client_nonce = Some(r.read_bytes()?);
                        Ok(())
                    })
                });
                Ok(out)
            })
        })
        .map_err(|e| ConnectionError::Protocol(format!("TSRequest DER decode: {e}")))
    }
}

/// Build the DER-encoded `TSCredentials` carrying a `TSPasswordCreds`
/// (domain, user, password) — what we ultimately delegate after the
/// public-key check.
pub fn ts_password_credentials_der(creds: &NtlmCreds) -> Vec<u8> {
    use yasna::Tag;

    fn utf16le(s: &str) -> Vec<u8> {
        let mut out = Vec::with_capacity(s.len() * 2);
        for c in s.encode_utf16() {
            out.extend_from_slice(&c.to_le_bytes());
        }
        out
    }
    let domain_u16 = utf16le(&creds.domain);
    let user_u16 = utf16le(&creds.user);
    let password_u16 = utf16le(&creds.password);

    // TSPasswordCreds ::= SEQUENCE {
    //     domainName  [0] OCTET STRING,
    //     userName    [1] OCTET STRING,
    //     password    [2] OCTET STRING }
    let password_creds = yasna::construct_der(|w| {
        w.write_sequence(|w| {
            w.next()
                .write_tagged(Tag::context(0), |w| w.write_bytes(&domain_u16));
            w.next()
                .write_tagged(Tag::context(1), |w| w.write_bytes(&user_u16));
            w.next()
                .write_tagged(Tag::context(2), |w| w.write_bytes(&password_u16));
        });
    });

    // TSCredentials ::= SEQUENCE {
    //     credType    [0] INTEGER,        -- 1 = TSPasswordCreds
    //     credentials [1] OCTET STRING }  -- DER(TSPasswordCreds)
    yasna::construct_der(|w| {
        w.write_sequence(|w| {
            w.next()
                .write_tagged(Tag::context(0), |w| w.write_u32(1));
            w.next()
                .write_tagged(Tag::context(1), |w| w.write_bytes(&password_creds));
        });
    })
}

/// Wrap an NTLM-sealed payload — exactly what CredSSP expects as the value
/// of `authInfo`/`pubKeyAuth`. The 16-byte HMAC-MD5-based signature comes
/// first, then RC4-encrypted payload (MS-NLMP §3.4.4.1 — extended session
/// security path).
///
/// Returns `(signature || sealed_payload, updated_seq)`.
pub fn ntlm_seal(
    session: &mut NtlmSession,
    sealing_cipher: &mut rc4::Rc4<rc4::consts::U16>,
    plaintext: &[u8],
) -> Vec<u8> {
    use hmac::Mac;
    type HmacMd5 = hmac::Hmac<md5::Md5>;

    // Compute HMAC-MD5(signing_key, seq_num || plaintext), take first 8 bytes
    // as the "checksum"; with KeyExch flag, the signature is RC4-encrypted.
    let mut mac = HmacMd5::new_from_slice(&session.client_signing_key).unwrap();
    mac.update(&session.client_seq.to_le_bytes());
    mac.update(plaintext);
    let mac_out = mac.finalize().into_bytes();
    let checksum = &mac_out[..8];

    use rc4::StreamCipher as _;

    let mut sealed = plaintext.to_vec();
    sealing_cipher.apply_keystream(&mut sealed);

    let mut sealed_checksum = [0u8; 8];
    sealed_checksum.copy_from_slice(checksum);
    sealing_cipher.apply_keystream(&mut sealed_checksum);

    // GSS signature header: version=0x00000001, sealed_checksum (8 bytes),
    // seq_num (4 bytes LE).
    let mut signed = Vec::with_capacity(16 + sealed.len());
    signed.extend_from_slice(&1u32.to_le_bytes());
    signed.extend_from_slice(&sealed_checksum);
    signed.extend_from_slice(&session.client_seq.to_le_bytes());
    signed.extend_from_slice(&sealed);

    session.client_seq = session.client_seq.wrapping_add(1);
    signed
}

/// CredSSP context — bundles the inner TLS connection and NTLM state.
///
/// Caller is responsible for the OUTER TCP/TLS to the WinRM endpoint;
/// CredSSP runs its inner TLS over a `Read+Write` transport supplied by
/// the caller (typically: the byte stream of the outer HTTPS connection,
/// or a raw TCP socket if doing CredSSP without HTTPS wrap).
pub struct CredSspContext {
    pub creds: NtlmCreds,
    pub session: Option<NtlmSession>,
    pub server_certificate_der: Vec<u8>,
}

impl CredSspContext {
    pub fn new(creds: NtlmCreds) -> Self {
        Self {
            creds,
            session: None,
            server_certificate_der: Vec::new(),
        }
    }

    /// Perform the full CredSSP handshake over an already-established inner
    /// TLS stream `inner`. After successful return the user is authenticated
    /// at the server.
    pub fn handshake<S: Read + Write>(
        &mut self,
        inner: &mut S,
        server_pub_key_der: &[u8],
    ) -> Result<(), ConnectionError> {
        // Step 1: client → server, negoTokens = NTLM Type 1
        let nego1 = build_negotiate(&self.creds);
        let mut ts1 = TsRequest::new(TS_REQUEST_VERSION);
        ts1.nego_tokens = Some(nego1);
        write_framed(inner, &ts1.to_der())?;

        // Step 2: read TSRequest, expect negoTokens = NTLM Type 2
        let resp = read_framed(inner)?;
        let ts2 = TsRequest::from_der(&resp)?;
        let chal = ts2
            .nego_tokens
            .ok_or_else(|| ConnectionError::Protocol("CredSSP: no Type 2 in response".into()))?;
        let challenge = parse_challenge(&chal)?;

        // Step 3: client → server, negoTokens = NTLM Type 3, plus pubKeyAuth
        //          = ntlm_seal(server pubkey DER). Server validates the
        //          encrypted pubkey matches what it sent in its TLS cert.
        let (auth_msg, session) =
            build_authenticate(&self.creds, &challenge, None, None)?;
        // Build sealing cipher for sealing client→server traffic.
        let mut sealing_cipher =
            <rc4::Rc4<rc4::consts::U16> as rc4::KeyInit>::new(
                session.client_sealing_key.as_slice().into(),
            );

        let mut session = session;
        let sealed_pubkey = ntlm_seal(&mut session, &mut sealing_cipher, server_pub_key_der);

        let mut ts3 = TsRequest::new(TS_REQUEST_VERSION);
        ts3.nego_tokens = Some(auth_msg);
        ts3.pub_key_auth = Some(sealed_pubkey);
        write_framed(inner, &ts3.to_der())?;

        // Step 4: server → client, pubKeyAuth = sealed(pubkey + 1).
        // We don't currently validate this rigorously — production code
        // should unseal it with the server's signing key and check the
        // first byte was incremented by 1 (MS-CSSP §4.1.1). For now we
        // accept anything non-empty as confirmation the server processed
        // our message.
        let resp = read_framed(inner)?;
        let ts4 = TsRequest::from_der(&resp)?;
        if let Some(ec) = ts4.error_code {
            if ec != 0 {
                return Err(ConnectionError::AuthenticationFailed(format!(
                    "CredSSP server returned error code 0x{ec:08x}"
                )));
            }
        }
        if ts4.pub_key_auth.is_none() {
            return Err(ConnectionError::AuthenticationFailed(
                "CredSSP step 4: server omitted pubKeyAuth".into(),
            ));
        }

        // Step 5: send TSCredentials encrypted as authInfo.
        let creds_der = ts_password_credentials_der(&self.creds);
        let sealed_creds = ntlm_seal(&mut session, &mut sealing_cipher, &creds_der);
        let mut ts5 = TsRequest::new(TS_REQUEST_VERSION);
        ts5.auth_info = Some(sealed_creds);
        write_framed(inner, &ts5.to_der())?;

        self.session = Some(session);
        Ok(())
    }
}

/// Frame a DER blob with a 4-byte big-endian length prefix and write it
/// to the inner stream. CredSSP uses raw DER blobs; the 4-byte prefix is
/// a convenience for our test harness, not the CredSSP wire format.
///
/// **Note**: actual CredSSP doesn't add a length prefix at all — the DER
/// SEQUENCE is self-delimiting. We strip the prefix in production callers
/// and rely on TLS record boundaries. For now keep length-prefix off in the
/// real handshake.
pub fn write_framed<W: Write>(w: &mut W, der: &[u8]) -> Result<(), ConnectionError> {
    w.write_all(der).map_err(ConnectionError::from)?;
    w.flush().map_err(ConnectionError::from)?;
    Ok(())
}

/// Read a DER SEQUENCE from `r`. DER is self-delimiting (first byte = tag,
/// then variable-length length); we read just enough to learn the length,
/// then the rest.
pub fn read_framed<R: Read>(r: &mut R) -> Result<Vec<u8>, ConnectionError> {
    let mut header = [0u8; 2];
    r.read_exact(&mut header).map_err(ConnectionError::from)?;
    let tag = header[0];
    if tag != 0x30 {
        return Err(ConnectionError::Protocol(format!(
            "CredSSP: expected SEQUENCE tag 0x30, got 0x{tag:02x}"
        )));
    }
    let len_byte = header[1];
    let (body_len, len_of_len) = if len_byte & 0x80 == 0 {
        (len_byte as usize, 0usize)
    } else {
        let n = (len_byte & 0x7f) as usize;
        if n == 0 || n > 4 {
            return Err(ConnectionError::Protocol(
                "CredSSP: indefinite or oversized DER length".into(),
            ));
        }
        let mut buf = [0u8; 4];
        r.read_exact(&mut buf[..n]).map_err(ConnectionError::from)?;
        let mut len = 0usize;
        for &b in &buf[..n] {
            len = (len << 8) | (b as usize);
        }
        (len, n)
    };
    let total = 2 + len_of_len + body_len;
    let mut out = Vec::with_capacity(total);
    out.extend_from_slice(&header);
    // The long-form length bytes we already consumed cannot be re-read from
    // the underlying reader, so callers that need to round-trip the exact
    // wire bytes must buffer at a higher level. For our use (decoding into
    // TsRequest), the length prefix is reconstructed by yasna on re-encode,
    // so dropping it here is safe.
    let mut body = vec![0u8; body_len];
    r.read_exact(&mut body).map_err(ConnectionError::from)?;
    out.extend_from_slice(&body);
    Ok(out)
}

/// Build a tokio-rustls ClientConfig that uses webpki roots and (optionally)
/// skips cert validation. Honest about the security tradeoff: skipping CA
/// validation is necessary for WinRM against self-signed certs, which is the
/// 99% case in Windows lab/enterprise setups where the WinRM listener
/// auto-generates a cert.
pub fn rustls_client_config(skip_validation: bool) -> Result<Arc<ClientConfig>, ConnectionError> {
    let _ = rustls::crypto::ring::default_provider().install_default();

    let config = if skip_validation {
        let provider = rustls::crypto::ring::default_provider();
        ClientConfig::builder_with_provider(Arc::new(provider))
            .with_safe_default_protocol_versions()
            .map_err(|e| ConnectionError::Tls(format!("rustls protocol version: {e}")))?
            .dangerous()
            .with_custom_certificate_verifier(Arc::new(InsecureVerifier))
            .with_no_client_auth()
    } else {
        let mut roots = RootCertStore::empty();
        roots.extend(webpki_roots::TLS_SERVER_ROOTS.iter().cloned());
        ClientConfig::builder()
            .with_root_certificates(roots)
            .with_no_client_auth()
    };
    Ok(Arc::new(config))
}

/// Open a fresh TCP connection and run rustls over it. Returns the owned
/// stream + the server's first certificate (DER), needed to compute the
/// pubKeyAuth blob in step 3 of the CredSSP handshake.
pub fn tls_connect_collect_cert(
    host: &str,
    port: u16,
    config: Arc<ClientConfig>,
) -> Result<(rustls::StreamOwned<ClientConnection, TcpStream>, Vec<u8>), ConnectionError> {
    let sock = TcpStream::connect((host, port))
        .map_err(|e| ConnectionError::ConnectionFailed(format!("TCP connect: {e}")))?;
    let server_name: ServerName<'static> = ServerName::try_from(host.to_string())
        .map_err(|e| ConnectionError::Tls(format!("invalid server name: {e}")))?;
    let conn = ClientConnection::new(config, server_name)
        .map_err(|e| ConnectionError::Tls(format!("rustls new: {e}")))?;
    let mut owned = rustls::StreamOwned::new(conn, sock);
    // Drive the handshake by flushing — rustls completes it on demand.
    owned
        .flush()
        .map_err(|e| ConnectionError::Tls(format!("handshake flush: {e}")))?;
    let cert_der = owned
        .conn
        .peer_certificates()
        .and_then(|certs| certs.first().map(|c| c.as_ref().to_vec()))
        .unwrap_or_default();
    Ok((owned, cert_der))
}

#[derive(Debug)]
struct InsecureVerifier;

impl rustls::client::danger::ServerCertVerifier for InsecureVerifier {
    fn verify_server_cert(
        &self,
        _end_entity: &rustls::pki_types::CertificateDer<'_>,
        _intermediates: &[rustls::pki_types::CertificateDer<'_>],
        _server_name: &ServerName<'_>,
        _ocsp_response: &[u8],
        _now: rustls::pki_types::UnixTime,
    ) -> Result<rustls::client::danger::ServerCertVerified, rustls::Error> {
        Ok(rustls::client::danger::ServerCertVerified::assertion())
    }
    fn verify_tls12_signature(
        &self,
        _message: &[u8],
        _cert: &rustls::pki_types::CertificateDer<'_>,
        _dss: &rustls::DigitallySignedStruct,
    ) -> Result<rustls::client::danger::HandshakeSignatureValid, rustls::Error> {
        Ok(rustls::client::danger::HandshakeSignatureValid::assertion())
    }
    fn verify_tls13_signature(
        &self,
        _message: &[u8],
        _cert: &rustls::pki_types::CertificateDer<'_>,
        _dss: &rustls::DigitallySignedStruct,
    ) -> Result<rustls::client::danger::HandshakeSignatureValid, rustls::Error> {
        Ok(rustls::client::danger::HandshakeSignatureValid::assertion())
    }
    fn supported_verify_schemes(&self) -> Vec<rustls::SignatureScheme> {
        vec![
            rustls::SignatureScheme::RSA_PSS_SHA256,
            rustls::SignatureScheme::RSA_PKCS1_SHA256,
            rustls::SignatureScheme::ECDSA_NISTP256_SHA256,
            rustls::SignatureScheme::ED25519,
        ]
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn tsrequest_minimal_round_trip() {
        let mut req = TsRequest::new(6);
        req.nego_tokens = Some(vec![0xaa, 0xbb, 0xcc]);
        let der = req.to_der();
        // Decode and check we got back the same fields.
        let back = TsRequest::from_der(&der).unwrap();
        assert_eq!(back.version, 6);
        assert_eq!(back.nego_tokens.as_deref(), Some(&[0xaa, 0xbb, 0xcc][..]));
        assert!(back.auth_info.is_none());
        assert!(back.pub_key_auth.is_none());
    }

    #[test]
    fn tsrequest_all_fields_round_trip() {
        let mut req = TsRequest::new(5);
        req.nego_tokens = Some(vec![1, 2, 3]);
        req.auth_info = Some(vec![4, 5]);
        req.pub_key_auth = Some(vec![6, 7, 8, 9]);
        req.error_code = Some(0);
        req.client_nonce = Some(vec![0xde, 0xad, 0xbe, 0xef]);
        let der = req.to_der();
        let back = TsRequest::from_der(&der).unwrap();
        assert_eq!(back.version, 5);
        assert_eq!(back.nego_tokens.as_deref(), Some(&[1, 2, 3][..]));
        assert_eq!(back.auth_info.as_deref(), Some(&[4, 5][..]));
        assert_eq!(back.pub_key_auth.as_deref(), Some(&[6, 7, 8, 9][..]));
        assert_eq!(back.error_code, Some(0));
        assert_eq!(back.client_nonce.as_deref(), Some(&[0xde, 0xad, 0xbe, 0xef][..]));
    }

    #[test]
    fn ts_password_credentials_der_emits_outer_sequence() {
        let creds = NtlmCreds {
            user: "alice".into(),
            domain: "EXAMPLE".into(),
            password: "hunter2".into(),
            workstation: "WS01".into(),
        };
        let der = ts_password_credentials_der(&creds);
        // Outer SEQUENCE
        assert_eq!(der[0], 0x30);
        // Tag [0] credType = INTEGER 1 → encoded as context-tagged
        assert!(der.windows(3).any(|w| w == [0xa0, 0x03, 0x02]));
    }
}
