mod container_common;
pub mod docker;
pub mod error;
pub mod local;
pub mod podman;
pub mod ssh;

// Windows remote-management stack: WinRM (WSMan) and PSRP, with native
// CredSSP-over-HTTPS authentication.
pub mod credssp;
pub mod ntlm;
pub mod psrp;
pub mod winrm;
pub mod wsman;

pub use error::ConnectionError;
pub use psrp::PsrpConnection;
pub use winrm::WinRmConnection;
