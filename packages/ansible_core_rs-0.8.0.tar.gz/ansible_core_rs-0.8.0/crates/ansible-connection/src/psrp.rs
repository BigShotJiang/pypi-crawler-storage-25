//! PSRP (PowerShell Remoting Protocol, [MS-PSRP]) connection plugin.
//!
//! PSRP runs *on top of* WSMan: the WSMan Shell resource URI is
//! `Microsoft.PowerShell`, and "stdin"/"stdout" carry framed PSRP messages
//! (each message is fragmented into one-or-more 21-byte-header + payload
//! blobs, then base64-encoded into rsp:Stream).
//!
//! PSRP messages are CLI XML (Common Language Infrastructure XML) — a
//! verbose `<Obj>` tree serialization of .NET objects. We only need a
//! small subset:
//! - `SESSION_CAPABILITY` (0x00010002) — client/server version exchange
//! - `INIT_RUNSPACEPOOL` (0x00010004) — open a runspace pool
//! - `CREATE_PIPELINE` (0x00021006) — submit a script to run
//! - `PIPELINE_OUTPUT` (0x00041002) — captured output
//! - `ERROR_RECORD` (0x00041005)
//! - `PIPELINE_STATE` (0x00041006) — completed/failed/stopped
//! - `RUNSPACEPOOL_STATE` (0x00021005)
//!
//! Reference: [MS-PSRP] PowerShell Remoting Protocol Specification.

use std::path::Path;
use std::time::Duration;

use async_trait::async_trait;
use uuid::Uuid;

use ansible_plugins::{ConnectionPlugin, PluginError};

use crate::error::ConnectionError;
use crate::winrm::WinRmConnection;
use crate::wsman::{self, action, build_envelope, resource, EnvelopeParams};

/// PSRP message types we generate or recognize.
pub mod msg {
    pub const SESSION_CAPABILITY: u32 = 0x0001_0002;
    pub const INIT_RUNSPACEPOOL: u32 = 0x0001_0004;
    pub const PUBLIC_KEY: u32 = 0x0001_0005;
    pub const ENCRYPTED_SESSION_KEY: u32 = 0x0001_0006;
    pub const PUBLIC_KEY_REQUEST: u32 = 0x0001_0007;
    pub const CREATE_PIPELINE: u32 = 0x0002_1006;
    pub const RUNSPACEPOOL_STATE: u32 = 0x0002_1005;
    pub const PIPELINE_OUTPUT: u32 = 0x0004_1002;
    pub const ERROR_RECORD: u32 = 0x0004_1005;
    pub const PIPELINE_STATE: u32 = 0x0004_1006;
    pub const PIPELINE_HOST_CALL: u32 = 0x0004_1100;
}

/// Destinations (MS-PSRP §2.2.3.1).
pub mod dest {
    pub const CLIENT: u32 = 0x0000_0001;
    pub const SERVER: u32 = 0x0000_0002;
}

/// Build a PSRP message header + payload. Returns the 0x40-byte (no, 64-byte
/// actually 0x28 = 40-byte) PSRP header followed by `payload`.
///
/// Layout per [MS-PSRP] §2.2.1:
///   destination (4 LE) | message_type (4 LE) | runspace_pool_id (16) |
///   pipeline_id (16) | payload
pub fn build_message(
    destination: u32,
    msg_type: u32,
    rpid: Uuid,
    pid: Option<Uuid>,
    payload: &[u8],
) -> Vec<u8> {
    let mut out = Vec::with_capacity(40 + payload.len());
    out.extend_from_slice(&destination.to_le_bytes());
    out.extend_from_slice(&msg_type.to_le_bytes());
    // RPID/PID are stored as the .NET Guid byte order (mixed-endian per .NET).
    out.extend_from_slice(&guid_to_bytes_le(rpid));
    let pid_bytes = pid.map(guid_to_bytes_le).unwrap_or([0u8; 16]);
    out.extend_from_slice(&pid_bytes);
    out.extend_from_slice(payload);
    out
}

/// Fragment a PSRP message into a sequence of (header + chunk) blobs. The
/// fragment header is 21 bytes per [MS-PSRP] §2.2.4:
///   object_id (8 LE) | fragment_id (8 LE) | flags (1) | length (4 LE)
/// where flags bit 0 = START, bit 1 = END.
pub fn fragment_message(object_id: u64, message: &[u8], max_chunk: usize) -> Vec<Vec<u8>> {
    let mut out = Vec::new();
    let chunks: Vec<&[u8]> = if message.is_empty() {
        vec![&[]]
    } else {
        message.chunks(max_chunk).collect()
    };
    let last = chunks.len().saturating_sub(1);
    for (i, chunk) in chunks.iter().enumerate() {
        let mut flags = 0u8;
        if i == 0 {
            flags |= 0x01;
        }
        if i == last {
            flags |= 0x02;
        }
        let mut frag = Vec::with_capacity(21 + chunk.len());
        frag.extend_from_slice(&object_id.to_be_bytes());
        frag.extend_from_slice(&(i as u64).to_be_bytes());
        frag.push(flags);
        frag.extend_from_slice(&(chunk.len() as u32).to_be_bytes());
        frag.extend_from_slice(chunk);
        out.push(frag);
    }
    out
}

/// Reassemble defragmented PSRP messages from a stream of fragment bytes.
/// Returns the completed messages whose END flag was seen.
pub fn defragment(buf: &[u8]) -> Result<Vec<Vec<u8>>, ConnectionError> {
    let mut out = Vec::new();
    let mut pos = 0;
    let mut current = Vec::<u8>::new();
    while pos < buf.len() {
        if buf.len() - pos < 21 {
            return Err(ConnectionError::Protocol(
                "PSRP fragment: short header".into(),
            ));
        }
        let _object_id = u64::from_be_bytes(buf[pos..pos + 8].try_into().unwrap());
        let _frag_id = u64::from_be_bytes(buf[pos + 8..pos + 16].try_into().unwrap());
        let flags = buf[pos + 16];
        let len = u32::from_be_bytes(buf[pos + 17..pos + 21].try_into().unwrap()) as usize;
        pos += 21;
        if buf.len() < pos + len {
            return Err(ConnectionError::Protocol(
                "PSRP fragment: payload extends past buffer".into(),
            ));
        }
        if flags & 0x01 != 0 {
            current.clear();
        }
        current.extend_from_slice(&buf[pos..pos + len]);
        pos += len;
        if flags & 0x02 != 0 {
            out.push(std::mem::take(&mut current));
        }
    }
    Ok(out)
}

fn guid_to_bytes_le(g: Uuid) -> [u8; 16] {
    // .NET's Guid byte layout: Data1 (4 LE), Data2 (2 LE), Data3 (2 LE), Data4 (8 BE).
    let (d1, d2, d3, d4) = g.as_fields();
    let mut out = [0u8; 16];
    out[..4].copy_from_slice(&d1.to_le_bytes());
    out[4..6].copy_from_slice(&d2.to_le_bytes());
    out[6..8].copy_from_slice(&d3.to_le_bytes());
    out[8..].copy_from_slice(d4);
    out
}

/// CLI-XML payload for SESSION_CAPABILITY.
pub fn cli_xml_session_capability() -> String {
    String::from(
        r#"<Obj RefId="0"><MS>
            <Version N="protocolversion">2.3</Version>
            <Version N="PSVersion">2.0</Version>
            <Version N="SerializationVersion">1.1.0.1</Version>
        </MS></Obj>"#,
    )
}

/// CLI-XML payload for INIT_RUNSPACEPOOL (minimal — single-threaded apartment,
/// MinRunspaces=1, MaxRunspaces=1).
pub fn cli_xml_init_runspace_pool() -> String {
    String::from(
        r#"<Obj RefId="0"><MS>
            <I32 N="MinRunspaces">1</I32>
            <I32 N="MaxRunspaces">1</I32>
            <Obj N="PSThreadOptions" RefId="1">
                <TN RefId="0">
                    <T>System.Management.Automation.Runspaces.PSThreadOptions</T>
                    <T>System.Enum</T>
                    <T>System.ValueType</T>
                    <T>System.Object</T>
                </TN>
                <ToString>Default</ToString>
                <I32>0</I32>
            </Obj>
            <Obj N="ApartmentState" RefId="2">
                <TN RefId="1">
                    <T>System.Threading.ApartmentState</T>
                    <T>System.Enum</T>
                    <T>System.ValueType</T>
                    <T>System.Object</T>
                </TN>
                <ToString>Unknown</ToString>
                <I32>2</I32>
            </Obj>
            <Obj N="HostInfo" RefId="3">
                <MS>
                    <B N="_isHostNull">true</B>
                    <B N="_isHostUINull">true</B>
                    <B N="_isHostRawUINull">true</B>
                    <B N="_useRunspaceHost">true</B>
                </MS>
            </Obj>
            <Nil N="ApplicationArguments"/>
        </MS></Obj>"#,
    )
}

/// CLI-XML payload for CREATE_PIPELINE running a single command (`script`).
pub fn cli_xml_create_pipeline(script: &str) -> String {
    let mut out = String::new();
    out.push_str(r#"<Obj RefId="0"><MS>
        <Obj N="PowerShell" RefId="1"><MS>
            <Obj N="Cmds" RefId="2">
                <TN RefId="0">
                    <T>System.Collections.Generic.List`1[[System.Management.Automation.PSObject]]</T>
                    <T>System.Object</T>
                </TN>
                <LST>
                    <Obj RefId="3"><MS>
                        <S N="Cmd">"#);
    push_xml_text(&mut out, script);
    out.push_str(r#"</S>
                        <B N="IsScript">true</B>
                        <Nil N="UseLocalScope"/>
                        <Obj N="MergeMyResult" RefId="4">
                            <TN RefId="1">
                                <T>System.Management.Automation.Runspaces.PipelineResultTypes</T>
                                <T>System.Enum</T>
                                <T>System.ValueType</T>
                                <T>System.Object</T>
                            </TN>
                            <ToString>None</ToString>
                            <I32>0</I32>
                        </Obj>
                        <Obj N="MergeToResult" RefId="5">
                            <TNRef RefId="1"/>
                            <ToString>None</ToString>
                            <I32>0</I32>
                        </Obj>
                        <Obj N="MergePreviousResults" RefId="6">
                            <TNRef RefId="1"/>
                            <ToString>None</ToString>
                            <I32>0</I32>
                        </Obj>
                        <Obj N="Args" RefId="7">
                            <TNRef RefId="0"/>
                            <LST/>
                        </Obj>
                    </MS></Obj>
                </LST>
            </Obj>
            <B N="IsNested">false</B>
            <Nil N="History"/>
            <B N="RedirectShellErrorOutputPipe">false</B>
        </MS></Obj>
        <B N="NoInput">true</B>
        <Obj N="ApartmentState" RefId="8">
            <TN RefId="2">
                <T>System.Threading.ApartmentState</T>
                <T>System.Enum</T>
                <T>System.ValueType</T>
                <T>System.Object</T>
            </TN>
            <ToString>Unknown</ToString>
            <I32>2</I32>
        </Obj>
        <Obj N="RemoteStreamOptions" RefId="9">
            <TN RefId="3">
                <T>System.Management.Automation.RemoteStreamOptions</T>
                <T>System.Enum</T>
                <T>System.ValueType</T>
                <T>System.Object</T>
            </TN>
            <ToString>AddInvocationInfo</ToString>
            <I32>15</I32>
        </Obj>
        <B N="AddToHistory">false</B>
        <Obj N="HostInfo" RefId="10"><MS>
            <B N="_isHostNull">true</B>
            <B N="_isHostUINull">true</B>
            <B N="_isHostRawUINull">true</B>
            <B N="_useRunspaceHost">true</B>
        </MS></Obj>
        <B N="IsNested">false</B>
    </MS></Obj>"#);
    out
}

fn push_xml_text(out: &mut String, s: &str) {
    for c in s.chars() {
        match c {
            '<' => out.push_str("&lt;"),
            '>' => out.push_str("&gt;"),
            '&' => out.push_str("&amp;"),
            '\'' => out.push_str("&apos;"),
            '"' => out.push_str("&quot;"),
            _ => out.push(c),
        }
    }
}

/// Extract the textual content of `<S>...</S>` and `<S N="...">...</S>`
/// elements from a CLI-XML PIPELINE_OUTPUT payload. This is a minimal
/// CLI-XML reader — we only handle the string output case (the most
/// common form for `Write-Output`-style results).
pub fn extract_pipeline_output_strings(cli_xml: &str) -> Vec<String> {
    let mut out = Vec::new();
    let mut reader = quick_xml::Reader::from_str(cli_xml);
    reader.config_mut().trim_text(false);
    let mut buf = Vec::new();
    let mut in_s = false;
    let mut accum = String::new();
    loop {
        match reader.read_event_into(&mut buf) {
            Err(_) | Ok(quick_xml::events::Event::Eof) => break,
            Ok(quick_xml::events::Event::Start(e)) => {
                if e.name().as_ref() == b"S" {
                    in_s = true;
                    accum.clear();
                }
            }
            Ok(quick_xml::events::Event::Text(t)) => {
                if in_s {
                    if let Ok(s) = t.unescape() {
                        accum.push_str(&s);
                    }
                }
            }
            Ok(quick_xml::events::Event::End(e)) => {
                if e.name().as_ref() == b"S" && in_s {
                    out.push(std::mem::take(&mut accum));
                    in_s = false;
                }
            }
            _ => {}
        }
        buf.clear();
    }
    out
}

/// PSRP connection — wraps a WinRM connection but uses the PowerShell
/// resource URI and PSRP framing.
#[derive(Debug, Clone)]
pub struct PsrpConnection {
    inner: WinRmConnection,
    runspace_pool_id: Uuid,
    next_object_id: u64,
}

impl PsrpConnection {
    pub fn new(host: String, user: String, password: String) -> Self {
        Self {
            inner: WinRmConnection::new(host, user, password),
            runspace_pool_id: Uuid::new_v4(),
            next_object_id: 1,
        }
    }

    pub fn with_port(mut self, port: u16) -> Self {
        self.inner.port = port;
        self
    }

    pub fn skip_cert_validation(mut self, skip: bool) -> Self {
        self.inner.skip_cert_validation = skip;
        self
    }

    pub fn with_timeout(mut self, op: Duration, read: Duration) -> Self {
        self.inner.operation_timeout = op;
        self.inner.read_timeout = read;
        self
    }

    /// Enable censoring of stdout/stderr in trace logs for the current task,
    /// delegating to the underlying WinRm transport that emits the trace lines.
    pub fn set_no_log(&mut self, no_log: bool) {
        self.inner.set_no_log(no_log);
    }

    fn endpoint(&self) -> String {
        self.inner.endpoint()
    }

    fn next_oid(&mut self) -> u64 {
        let id = self.next_object_id;
        self.next_object_id += 1;
        id
    }

    /// Send a fragmented PSRP message via the WSMan `stdin` stream of the
    /// PowerShell shell. We use the underlying SOAP transport from the WinRm
    /// connection — calling `inner.exec_command()`-like primitives via the
    /// `wsman` module directly.
    async fn send_psrp_message(
        &mut self,
        shell_id: &str,
        msg_type: u32,
        pid: Option<Uuid>,
        payload_xml: &str,
    ) -> Result<(), ConnectionError> {
        let msg = build_message(
            dest::SERVER,
            msg_type,
            self.runspace_pool_id,
            pid,
            payload_xml.as_bytes(),
        );
        let oid = self.next_oid();
        let fragments = fragment_message(oid, &msg, 32 * 1024);
        let endpoint = self.endpoint();

        for (i, frag) in fragments.iter().enumerate() {
            let last = i + 1 == fragments.len();
            let body = wsman::body_send("stdin", None, frag, last);
            let params = EnvelopeParams::new(action::SEND, resource::POWERSHELL_SHELL, &endpoint)
                .with_shell(shell_id);
            let envelope = build_envelope(&params, &body);
            self.soap_post(&envelope).await?;
        }
        Ok(())
    }

    async fn soap_post(&self, _body: &str) -> Result<String, ConnectionError> {
        // Re-uses the inner WinRm HTTP path via a passthrough. Since the WinRm
        // SOAP-post helper is private, we duplicate it here using a dedicated
        // reqwest client built with the same TLS settings.
        // TODO: refactor to expose `WinRmConnection::soap_post` for reuse.
        Err(ConnectionError::Protocol(
            "PsrpConnection::soap_post needs WinRmConnection::soap_post to be exposed".into(),
        ))
    }
}

#[async_trait]
impl ConnectionPlugin for PsrpConnection {
    async fn connect(&mut self) -> Result<(), PluginError> {
        // 1. Run CredSSP via the inner connection's logic, but with the
        //    PowerShell resource URI so the resulting Shell is a PSRP runspace.
        self.inner.connect().await?;
        let shell_id = self
            .inner_shell_id()
            .ok_or_else(|| PluginError::ExecutionError("inner shell not opened".into()))?;

        // 2. Send SESSION_CAPABILITY + INIT_RUNSPACEPOOL on stdin.
        self.send_psrp_message(
            &shell_id,
            msg::SESSION_CAPABILITY,
            None,
            &cli_xml_session_capability(),
        )
        .await
        .map_err(|e| PluginError::ExecutionError(e.to_string()))?;
        self.send_psrp_message(
            &shell_id,
            msg::INIT_RUNSPACEPOOL,
            None,
            &cli_xml_init_runspace_pool(),
        )
        .await
        .map_err(|e| PluginError::ExecutionError(e.to_string()))?;

        // 3. Wait for RUNSPACEPOOL_STATE = Opened (state==2). The state
        //    arrives in a stdout Stream we pull via Receive. Skipping the
        //    poll loop here means callers may race on first command; the
        //    upstream pywinrm polls until the state-opened message is seen.
        //    Real implementation should drain until that point — left as a
        //    known gap, see issue #103.

        Ok(())
    }

    async fn exec_command(
        &self,
        cmd: &str,
        _in_data: Option<&[u8]>,
    ) -> Result<(i32, Vec<u8>, Vec<u8>), PluginError> {
        let shell_id = self
            .inner_shell_id()
            .ok_or_else(|| PluginError::ExecutionError("PSRP runspace not opened".into()))?;
        let pipeline_id = Uuid::new_v4();

        // CREATE_PIPELINE on stdin.
        let payload = cli_xml_create_pipeline(cmd);
        // self.send_psrp_message requires &mut self; we don't have it here.
        // exec_command on ConnectionPlugin is &self per trait, matching the
        // WinRm impl. To stay symmetric we'd want interior mutability for the
        // object_id counter — for now we accept that PSRP exec_command needs
        // a refactor to take &mut self or use an AtomicU64 counter.
        let _ = (payload, pipeline_id, shell_id);
        Err(PluginError::ExecutionError(
            "psrp.exec_command: requires &mut self refactor of ConnectionPlugin to send fragments".into(),
        ))
    }

    async fn put_file(&self, in_path: &Path, out_path: &Path) -> Result<(), PluginError> {
        // PSRP put_file uses Copy-Item-via-pipeline; for the first cut delegate
        // to the underlying WinRm cmd.exe shell which we also keep open.
        self.inner.put_file(in_path, out_path).await
    }

    async fn fetch_file(&self, in_path: &Path, out_path: &Path) -> Result<(), PluginError> {
        self.inner.fetch_file(in_path, out_path).await
    }

    async fn close(&mut self) -> Result<(), PluginError> {
        self.inner.close().await
    }
}

impl PsrpConnection {
    fn inner_shell_id(&self) -> Option<String> {
        // The inner WinRmConnection's state is private; we get it via a method
        // we add for this. For now: not yet exposed — return None.
        // TODO: expose a `shell_id()` accessor on WinRmConnection.
        None
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn psrp_message_header_layout() {
        let rpid = Uuid::nil();
        let m = build_message(dest::SERVER, msg::SESSION_CAPABILITY, rpid, None, b"hi");
        assert_eq!(&m[..4], &dest::SERVER.to_le_bytes());
        assert_eq!(&m[4..8], &msg::SESSION_CAPABILITY.to_le_bytes());
        assert_eq!(&m[8..24], &[0u8; 16]); // RPID nil
        assert_eq!(&m[24..40], &[0u8; 16]); // PID none → zero
        assert_eq!(&m[40..], b"hi");
    }

    #[test]
    fn fragment_single_chunk_sets_start_and_end_flags() {
        let frags = fragment_message(7, b"abc", 1024);
        assert_eq!(frags.len(), 1);
        let f = &frags[0];
        assert_eq!(&f[..8], &7u64.to_be_bytes());
        assert_eq!(&f[8..16], &0u64.to_be_bytes());
        assert_eq!(f[16], 0x03); // START | END
        assert_eq!(u32::from_be_bytes(f[17..21].try_into().unwrap()), 3);
        assert_eq!(&f[21..], b"abc");
    }

    #[test]
    fn fragment_multi_chunk_sets_start_only_then_end_only() {
        let payload: Vec<u8> = (0..2500u16).map(|i| (i & 0xff) as u8).collect();
        let frags = fragment_message(11, &payload, 1024);
        assert_eq!(frags.len(), 3);
        assert_eq!(frags[0][16], 0x01); // START
        assert_eq!(frags[1][16], 0x00);
        assert_eq!(frags[2][16], 0x02); // END
    }

    #[test]
    fn defragment_reassembles_split_message() {
        let payload: Vec<u8> = (0..2500u16).map(|i| (i & 0xff) as u8).collect();
        let frags = fragment_message(11, &payload, 1024);
        let stream: Vec<u8> = frags.into_iter().flatten().collect();
        let msgs = defragment(&stream).unwrap();
        assert_eq!(msgs.len(), 1);
        assert_eq!(msgs[0], payload);
    }

    #[test]
    fn extract_pipeline_output_strings_pulls_s_elements() {
        let xml = r#"<Objs><Obj><MS><S N="Foo">hello</S><I32 N="Bar">3</I32></MS></Obj><S>world</S></Objs>"#;
        let out = extract_pipeline_output_strings(xml);
        assert_eq!(out, vec!["hello".to_string(), "world".to_string()]);
    }

    #[test]
    fn guid_to_bytes_uses_dotnet_mixed_endian() {
        let g = Uuid::parse_str("01020304-0506-0708-090a-0b0c0d0e0f10").unwrap();
        let b = guid_to_bytes_le(g);
        assert_eq!(b[0], 0x04); // Data1 LE: 04 03 02 01
        assert_eq!(b[3], 0x01);
        assert_eq!(b[4], 0x06); // Data2 LE
        assert_eq!(b[6], 0x08); // Data3 LE
        assert_eq!(b[8], 0x09); // Data4 BE
    }
}
