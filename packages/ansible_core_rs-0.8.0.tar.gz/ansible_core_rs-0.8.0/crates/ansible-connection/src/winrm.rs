//! WinRM connection plugin — speaks WSMan/SOAP over HTTPS to a Windows host.
//!
//! Authentication: CredSSP over HTTPS only (per current `auth.rs`-equivalent
//! enum). CredSSP runs an inner TLS handshake whose records are tunneled
//! through HTTP `Authorization`/`WWW-Authenticate` headers, then carries
//! NTLM and finally `TSCredentials` (see `crate::credssp` for the protocol
//! details).
//!
//! After auth, every WSMan call is an HTTP POST with the SOAP envelope as
//! the body. We don't currently wrap each post in NTLM-sealed CredSSP
//! GSS_Wrap — Windows accepts post-auth requests in cleartext-over-HTTPS
//! as long as the connection's authenticated context is still alive.
//!
//! Variables honored (matching upstream `ansible.builtin.winrm`):
//! - `ansible_host` — target hostname
//! - `ansible_port` — default 5986
//! - `ansible_user` — auth username (may be `user@domain` or `domain\user`)
//! - `ansible_password` — auth password
//! - `ansible_winrm_transport` — must be `credssp`
//! - `ansible_winrm_scheme` — `https` (only supported value)
//! - `ansible_winrm_path` — URI path, default `/wsman`
//! - `ansible_winrm_server_cert_validation` — `ignore` to skip CA validation
//! - `ansible_winrm_operation_timeout_sec` — per-operation timeout
//! - `ansible_winrm_read_timeout_sec` — per-request read timeout
//! - `ansible_winrm_message_encryption` — informational; CredSSP always
//!   encrypts, so this knob is a no-op for us

use std::path::Path;
use std::sync::Arc;
use std::time::Duration;

use async_trait::async_trait;
use base64::Engine as _;
use reqwest::{Client, ClientBuilder};
use tracing::trace;

use ansible_plugins::{ConnectionPlugin, PluginError};

use crate::credssp::CredSspContext;
use crate::error::ConnectionError;
use crate::ntlm::NtlmCreds;
use crate::wsman::{
    self, action, build_envelope, build_envelope_with_options, parse_response, resource, signal,
    EnvelopeParams,
};

/// Authentication scheme. We expose the enum so the connection layer can
/// be extended (NTLM, Kerberos, Basic) later without a breaking API.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum WinRmAuth {
    CredSsp,
}

/// WinRM connection plugin configuration.
#[derive(Debug, Clone)]
pub struct WinRmConnection {
    pub host: String,
    pub port: u16,
    pub user: String,
    pub domain: String,
    pub password: String,
    pub path: String,
    pub auth: WinRmAuth,
    pub skip_cert_validation: bool,
    pub operation_timeout: Duration,
    pub read_timeout: Duration,
    pub locale: String,
    pub codepage: u32,
    pub no_profile: bool,
    /// Censor stdout/stderr in trace logs when the current task is `no_log`.
    /// Wired at the connection layer (not the caller) so verbose output of
    /// `win_command`/`win_shell` with sensitive args cannot leak via -vvvvv.
    pub no_log: bool,
    /// State populated by `connect()`.
    state: WinRmState,
}

#[derive(Debug, Clone, Default)]
struct WinRmState {
    http: Option<Arc<Client>>,
    shell_id: Option<String>,
    /// CredSSP context, populated post-auth. Reused for sealing/unsealing
    /// any post-auth GSS_Wrap operations.
    authenticated: bool,
}

impl WinRmConnection {
    pub fn new(host: String, user: String, password: String) -> Self {
        let (user, domain) = split_user_domain(&user);
        Self {
            host,
            port: 5986,
            user,
            domain,
            password,
            path: "/wsman".into(),
            auth: WinRmAuth::CredSsp,
            skip_cert_validation: false,
            operation_timeout: Duration::from_secs(60),
            read_timeout: Duration::from_secs(30),
            locale: "en-US".into(),
            codepage: 65001, // UTF-8
            no_profile: false,
            no_log: false,
            state: WinRmState::default(),
        }
    }

    /// Enable censoring of stdout/stderr in trace logs for the current task.
    pub fn set_no_log(&mut self, no_log: bool) {
        self.no_log = no_log;
    }

    pub fn endpoint(&self) -> String {
        format!("https://{}:{}{}", self.host, self.port, self.path)
    }

    fn build_http_client(&self) -> Result<Client, ConnectionError> {
        let mut b = ClientBuilder::new()
            .timeout(self.read_timeout)
            .connect_timeout(Duration::from_secs(10))
            .pool_idle_timeout(Duration::from_secs(90));
        if self.skip_cert_validation {
            b = b.danger_accept_invalid_certs(true);
        }
        b.build()
            .map_err(|e| ConnectionError::ConnectionFailed(format!("reqwest build: {e}")))
    }

    /// POST a SOAP envelope and return the response body as a string.
    async fn soap_post(&self, body: &str) -> Result<String, ConnectionError> {
        let client = self
            .state
            .http
            .as_ref()
            .ok_or_else(|| ConnectionError::ConnectionFailed("not connected".into()))?;
        let resp = client
            .post(self.endpoint())
            .header("Content-Type", "application/soap+xml;charset=UTF-8")
            .header("User-Agent", "ansible-core-rs/winrm")
            .body(body.to_owned())
            .send()
            .await
            .map_err(ConnectionError::from)?;
        let status = resp.status();
        let text = resp.text().await.map_err(ConnectionError::from)?;
        if !status.is_success() {
            return Err(ConnectionError::Http(format!(
                "WSMan POST returned {}: {}",
                status,
                text.chars().take(200).collect::<String>()
            )));
        }
        Ok(text)
    }

    /// Run the CredSSP handshake against the endpoint.
    ///
    /// This is the "CredSSP-over-HTTPS-Authorization" sub-handshake: each
    /// inner-TLS record from rustls is base64-encoded and shipped as the
    /// `Authorization: CredSSP <blob>` header value; the server's reply
    /// arrives in `WWW-Authenticate: CredSSP <blob>`. We loop until rustls
    /// reports the inner TLS is established, then run the NTLM/TSRequest
    /// dance carrying the TSRequest blobs the same way.
    ///
    /// Production note: this method is structurally complete but has not
    /// been exercised against a live Windows host in CI. See issue #103
    /// for the integration testing follow-up.
    async fn credssp_handshake(&mut self) -> Result<(), ConnectionError> {
        let client = self
            .state
            .http
            .as_ref()
            .ok_or_else(|| ConnectionError::ConnectionFailed("HTTP client missing".into()))?
            .clone();

        let creds = NtlmCreds {
            user: self.user.clone(),
            domain: self.domain.clone(),
            password: self.password.clone(),
            workstation: "WORKSTATION".into(),
        };
        let mut ctx = CredSspContext::new(creds);

        // Drive an in-memory rustls handshake whose I/O goes through HTTP.
        let tls_config = crate::credssp::rustls_client_config(self.skip_cert_validation)?;
        let server_name = rustls::pki_types::ServerName::try_from(self.host.clone())
            .map_err(|e| ConnectionError::Tls(format!("invalid server name: {e}")))?;
        let mut tls = rustls::ClientConnection::new(tls_config, server_name)
            .map_err(|e| ConnectionError::Tls(format!("rustls new: {e}")))?;

        // Pump TLS handshake messages back and forth via HTTP Authorization.
        loop {
            // Drain outbound TLS records.
            let mut out_buf = Vec::new();
            while tls.wants_write() {
                tls.write_tls(&mut out_buf)
                    .map_err(|e| ConnectionError::Tls(format!("write_tls: {e}")))?;
            }
            if out_buf.is_empty() && !tls.is_handshaking() {
                break;
            }
            let auth_header = format!(
                "CredSSP {}",
                base64::engine::general_purpose::STANDARD.encode(&out_buf)
            );
            let resp = client
                .post(self.endpoint())
                .header("Content-Type", "application/soap+xml;charset=UTF-8")
                .header("Authorization", auth_header)
                .body("")
                .send()
                .await
                .map_err(ConnectionError::from)?;
            let www_auth = resp
                .headers()
                .get("WWW-Authenticate")
                .and_then(|v| v.to_str().ok())
                .unwrap_or("")
                .to_string();
            if let Some(blob) = www_auth.strip_prefix("CredSSP ") {
                let inbound = base64::engine::general_purpose::STANDARD
                    .decode(blob.trim())
                    .map_err(|e| ConnectionError::Protocol(format!("CredSSP b64: {e}")))?;
                let mut reader = std::io::Cursor::new(inbound);
                while tls
                    .read_tls(&mut reader)
                    .map_err(|e| ConnectionError::Tls(format!("read_tls: {e}")))?
                    > 0
                {}
                tls.process_new_packets()
                    .map_err(|e| ConnectionError::Tls(format!("process_new_packets: {e}")))?;
            } else if !resp.status().is_success() {
                return Err(ConnectionError::AuthenticationFailed(format!(
                    "CredSSP HTTP {}: no WWW-Authenticate header",
                    resp.status()
                )));
            }
            if !tls.is_handshaking() && !tls.wants_write() && !tls.wants_read() {
                break;
            }
        }

        // Inner TLS is up. Now run the TSRequest/NTLM dance "inside" it. We
        // need the server's certificate so the pubKeyAuth step has something
        // to bind to.
        let server_pubkey_der = tls
            .peer_certificates()
            .and_then(|certs| certs.first().map(|c| c.as_ref().to_vec()))
            .unwrap_or_default();

        // Wrap the rustls state in a Read+Write adapter that ferries records
        // through HTTP, then call ctx.handshake().
        let mut adapter = HttpTlsAdapter {
            tls: &mut tls,
            client: &client,
            endpoint: self.endpoint(),
        };
        ctx.handshake(&mut adapter, &server_pubkey_der)?;

        self.state.authenticated = true;
        Ok(())
    }

    fn ensure_connected(&self) -> Result<(), ConnectionError> {
        if !self.state.authenticated {
            return Err(ConnectionError::ConnectionFailed(
                "WinRm not yet authenticated; call connect() first".into(),
            ));
        }
        Ok(())
    }
}

/// Adapter that exposes a rustls in-memory connection as Read+Write,
/// with each record ferried via HTTP Authorization headers.
struct HttpTlsAdapter<'a> {
    tls: &'a mut rustls::ClientConnection,
    client: &'a Client,
    endpoint: String,
}

impl std::io::Read for HttpTlsAdapter<'_> {
    fn read(&mut self, buf: &mut [u8]) -> std::io::Result<usize> {
        // Drain any plaintext already buffered.
        if self.tls.wants_read() == false {
            // Issue an HTTP exchange to flush our outbound + collect inbound.
            self.exchange()
                .map_err(|e| std::io::Error::new(std::io::ErrorKind::Other, e.to_string()))?;
        }
        self.tls.reader().read(buf)
    }
}

impl std::io::Write for HttpTlsAdapter<'_> {
    fn write(&mut self, buf: &[u8]) -> std::io::Result<usize> {
        // Encrypt + buffer; actual HTTP exchange happens on flush/read.
        self.tls.writer().write(buf)
    }
    fn flush(&mut self) -> std::io::Result<()> {
        self.exchange()
            .map_err(|e| std::io::Error::new(std::io::ErrorKind::Other, e.to_string()))
    }
}

impl HttpTlsAdapter<'_> {
    fn exchange(&mut self) -> Result<(), ConnectionError> {
        let mut out = Vec::new();
        while self.tls.wants_write() {
            self.tls
                .write_tls(&mut out)
                .map_err(|e| ConnectionError::Tls(format!("write_tls: {e}")))?;
        }
        if out.is_empty() {
            return Ok(());
        }
        let auth = format!(
            "CredSSP {}",
            base64::engine::general_purpose::STANDARD.encode(&out)
        );
        // The HTTP exchange has to be blocking from inside the Read/Write impl,
        // so we drive reqwest in a fresh runtime. This is the same trick
        // pywinrm uses (its CredSSP transport synchronously calls requests).
        let rt = tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()
            .map_err(|e| ConnectionError::Tls(format!("runtime: {e}")))?;
        let resp = rt
            .block_on(async {
                self.client
                    .post(&self.endpoint)
                    .header("Content-Type", "application/soap+xml;charset=UTF-8")
                    .header("Authorization", auth)
                    .body("")
                    .send()
                    .await
            })
            .map_err(ConnectionError::from)?;
        let header = resp
            .headers()
            .get("WWW-Authenticate")
            .and_then(|v| v.to_str().ok())
            .unwrap_or("")
            .to_string();
        if let Some(blob) = header.strip_prefix("CredSSP ") {
            let inbound = base64::engine::general_purpose::STANDARD
                .decode(blob.trim())
                .map_err(|e| ConnectionError::Protocol(format!("CredSSP b64: {e}")))?;
            let mut cursor = std::io::Cursor::new(inbound);
            while self
                .tls
                .read_tls(&mut cursor)
                .map_err(|e| ConnectionError::Tls(format!("read_tls: {e}")))?
                > 0
            {}
            self.tls
                .process_new_packets()
                .map_err(|e| ConnectionError::Tls(format!("process_new_packets: {e}")))?;
        }
        Ok(())
    }
}

#[async_trait]
impl ConnectionPlugin for WinRmConnection {
    async fn connect(&mut self) -> Result<(), PluginError> {
        let client = self
            .build_http_client()
            .map_err(|e| PluginError::ExecutionError(e.to_string()))?;
        self.state.http = Some(Arc::new(client));
        match self.auth {
            WinRmAuth::CredSsp => self
                .credssp_handshake()
                .await
                .map_err(|e| PluginError::ExecutionError(e.to_string()))?,
        }
        // Open the shell.
        let shell_body = body_create_shell(self.no_profile, self.codepage, &self.locale);
        let endpoint = self.endpoint();
        let codepage_str = self.codepage.to_string();
        let params = EnvelopeParams::new(action::CREATE, resource::CMD_SHELL, &endpoint);
        let envelope = build_envelope_with_options(
            &params,
            &shell_body,
            &[
                ("WINRS_NOPROFILE", if self.no_profile { "TRUE" } else { "FALSE" }),
                ("WINRS_CODEPAGE", &codepage_str),
            ],
        );
        let resp_xml = self
            .soap_post(&envelope)
            .await
            .map_err(|e| PluginError::ExecutionError(e.to_string()))?;
        let parsed = parse_response(&resp_xml)
            .map_err(|e| PluginError::ExecutionError(e.to_string()))?;
        let shell_id = parsed
            .created_id
            .ok_or_else(|| PluginError::ExecutionError("Shell Create returned no ShellId".into()))?;
        self.state.shell_id = Some(shell_id);
        Ok(())
    }

    async fn exec_command(
        &self,
        cmd: &str,
        in_data: Option<&[u8]>,
    ) -> Result<(i32, Vec<u8>, Vec<u8>), PluginError> {
        self.ensure_connected()
            .map_err(|e| PluginError::ExecutionError(e.to_string()))?;
        let shell_id = self
            .state
            .shell_id
            .as_deref()
            .ok_or_else(|| PluginError::ExecutionError("no active shell".into()))?;

        // Issue the Command.
        let endpoint = self.endpoint();
        let body = wsman::body_command(cmd, &[]);
        let params = EnvelopeParams::new(action::COMMAND, resource::CMD_SHELL, &endpoint)
            .with_shell(shell_id);
        let envelope = build_envelope(&params, &body);
        let resp_xml = self
            .soap_post(&envelope)
            .await
            .map_err(|e| PluginError::ExecutionError(e.to_string()))?;
        let parsed = parse_response(&resp_xml)
            .map_err(|e| PluginError::ExecutionError(e.to_string()))?;
        let command_id = parsed
            .created_id
            .ok_or_else(|| PluginError::ExecutionError("Command response missing CommandId".into()))?;

        // If we have stdin data, Send it.
        if let Some(data) = in_data {
            // WinRM caps a single Send at ~512KB; chunk if larger.
            const CHUNK: usize = 480 * 1024;
            let chunks: Vec<&[u8]> = data.chunks(CHUNK).collect();
            for (i, chunk) in chunks.iter().enumerate() {
                let end = i + 1 == chunks.len();
                let body = wsman::body_send("stdin", Some(&command_id), chunk, end);
                let params = EnvelopeParams::new(action::SEND, resource::CMD_SHELL, &endpoint)
                    .with_shell(shell_id);
                let envelope = build_envelope(&params, &body);
                let _ = self.soap_post(&envelope).await.map_err(|e| {
                    PluginError::ExecutionError(format!(
                        "failed to send input to {}: {}",
                        self.host, e
                    ))
                })?;
            }
        }

        // Pull stdout/stderr until CommandState=Done.
        let mut stdout = Vec::new();
        let mut stderr = Vec::new();
        let mut exit_code: i32 = -1;
        loop {
            let body = wsman::body_receive("stdout stderr", Some(&command_id));
            let params = EnvelopeParams::new(action::RECEIVE, resource::CMD_SHELL, &endpoint)
                .with_shell(shell_id);
            let envelope = build_envelope(&params, &body);
            let resp_xml = self
                .soap_post(&envelope)
                .await
                .map_err(|e| PluginError::ExecutionError(e.to_string()))?;
            let r = parse_response(&resp_xml)
                .map_err(|e| PluginError::ExecutionError(e.to_string()))?;
            if let Some(b) = r.streams.get("stdout") {
                stdout.extend_from_slice(b);
            }
            if let Some(b) = r.streams.get("stderr") {
                stderr.extend_from_slice(b);
            }
            if r.command_done {
                if let Some(code) = r.exit_code {
                    exit_code = code;
                }
                break;
            }
        }

        // Signal terminate on the command (clean teardown).
        let body = wsman::body_signal(&command_id, signal::TERMINATE);
        let params = EnvelopeParams::new(action::SIGNAL, resource::CMD_SHELL, &endpoint)
            .with_shell(shell_id);
        let envelope = build_envelope(&params, &body);
        let _ = self.soap_post(&envelope).await; // best-effort

        // Verbose protocol-layer trace, mirroring upstream's display.vvvvv().
        // Censoring happens here at the connection boundary so callers can't
        // accidentally bypass it.
        trace!(host = %self.host, rc = exit_code, "WINRM RC");
        trace!(
            host = %self.host,
            stdout = %censor_output(self.no_log, &stdout),
            "WINRM STDOUT"
        );
        trace!(
            host = %self.host,
            stderr = %censor_output(self.no_log, &stderr),
            "WINRM STDERR"
        );

        Ok((exit_code, stdout, stderr))
    }

    async fn put_file(&self, in_path: &Path, out_path: &Path) -> Result<(), PluginError> {
        // WinRM file transfer: read local file, base64-encode, drive a
        // PowerShell command that writes the bytes to `out_path`. Chunk in
        // ~3KB pieces so each base64 fragment fits in a SOAP envelope.
        let data = tokio::fs::read(in_path)
            .await
            .map_err(|e| PluginError::ExecutionError(format!("read {}: {e}", in_path.display())))?;
        let target = out_path.to_string_lossy().into_owned();
        // Create the file (truncate).
        let init = format!(
            "powershell.exe -NoProfile -NonInteractive -Command \
             \"Set-Content -Path '{}' -Value @() -Encoding Byte\"",
            ps_escape(&target)
        );
        let _ = self.exec_command(&init, None).await?;
        // Append each chunk.
        const CHUNK: usize = 2 * 1024;
        for chunk in data.chunks(CHUNK) {
            let b64 = base64::engine::general_purpose::STANDARD.encode(chunk);
            let cmd = format!(
                "powershell.exe -NoProfile -NonInteractive -Command \
                 \"$b = [Convert]::FromBase64String('{b64}'); \
                 Add-Content -Path '{path}' -Value $b -Encoding Byte\"",
                b64 = b64,
                path = ps_escape(&target)
            );
            let (rc, _, stderr) = self.exec_command(&cmd, None).await?;
            if rc != 0 {
                return Err(PluginError::ExecutionError(format!(
                    "put_file chunk failed (rc={rc}): {}",
                    String::from_utf8_lossy(&stderr)
                )));
            }
        }
        Ok(())
    }

    async fn fetch_file(&self, in_path: &Path, out_path: &Path) -> Result<(), PluginError> {
        let source = in_path.to_string_lossy().into_owned();
        let cmd = format!(
            "powershell.exe -NoProfile -NonInteractive -Command \
             \"[Convert]::ToBase64String([IO.File]::ReadAllBytes('{path}'))\"",
            path = ps_escape(&source)
        );
        let (rc, stdout, stderr) = self.exec_command(&cmd, None).await?;
        if rc != 0 {
            return Err(PluginError::ExecutionError(format!(
                "fetch_file failed (rc={rc}): {}",
                String::from_utf8_lossy(&stderr)
            )));
        }
        let trimmed: String = String::from_utf8_lossy(&stdout)
            .split_whitespace()
            .collect();
        let decoded = base64::engine::general_purpose::STANDARD
            .decode(trimmed.as_bytes())
            .map_err(|e| PluginError::ExecutionError(format!("fetch_file b64: {e}")))?;
        tokio::fs::write(out_path, &decoded)
            .await
            .map_err(|e| PluginError::ExecutionError(format!("write {}: {e}", out_path.display())))?;
        Ok(())
    }

    async fn close(&mut self) -> Result<(), PluginError> {
        if let Some(shell_id) = self.state.shell_id.clone() {
            let endpoint = self.endpoint();
            let params = EnvelopeParams::new(action::DELETE, resource::CMD_SHELL, &endpoint)
                .with_shell(&shell_id);
            let envelope = build_envelope(&params, "");
            let _ = self.soap_post(&envelope).await; // best-effort
        }
        self.state.shell_id = None;
        self.state.authenticated = false;
        self.state.http = None;
        Ok(())
    }
}

fn split_user_domain(user: &str) -> (String, String) {
    // Accept "DOMAIN\user", "user@domain", or bare "user".
    if let Some((domain, u)) = user.split_once('\\') {
        return (u.to_owned(), domain.to_owned());
    }
    if let Some((u, domain)) = user.split_once('@') {
        return (u.to_owned(), domain.to_owned());
    }
    (user.to_owned(), String::new())
}

fn body_create_shell(no_profile: bool, codepage: u32, _locale: &str) -> String {
    let _ = no_profile;
    let _ = codepage;
    // InputStreams=stdin, OutputStreams=stdout stderr (cmd.exe defaults).
    String::from(
        r#"<rsp:Shell xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
              <rsp:InputStreams>stdin</rsp:InputStreams>
              <rsp:OutputStreams>stdout stderr</rsp:OutputStreams>
              <rsp:IdleTimeOut>PT240S</rsp:IdleTimeOut>
            </rsp:Shell>"#,
    )
}

fn ps_escape(s: &str) -> String {
    // PowerShell single-quoted strings: only ' is special, doubled to escape.
    s.replace('\'', "''")
}

/// Render command output for inclusion in a trace log, substituting the
/// upstream sentinel when the task is `no_log` so secrets in stdout/stderr
/// don't leak via `-vvvvv`. Mirrors ansible/ansible#86919.
pub(crate) fn censor_output(no_log: bool, data: &[u8]) -> String {
    if no_log {
        "<censored due to no log>".to_string()
    } else {
        String::from_utf8_lossy(data).into_owned()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn endpoint_format_is_https_with_port() {
        let c = WinRmConnection::new("win.example".into(), "alice".into(), "pw".into());
        assert_eq!(c.endpoint(), "https://win.example:5986/wsman");
    }

    #[test]
    fn split_user_domain_backslash() {
        let (u, d) = split_user_domain("EXAMPLE\\alice");
        assert_eq!(u, "alice");
        assert_eq!(d, "EXAMPLE");
    }

    #[test]
    fn split_user_domain_at_sign() {
        let (u, d) = split_user_domain("alice@example.com");
        assert_eq!(u, "alice");
        assert_eq!(d, "example.com");
    }

    #[test]
    fn split_user_domain_bare() {
        let (u, d) = split_user_domain("alice");
        assert_eq!(u, "alice");
        assert_eq!(d, "");
    }

    #[test]
    fn ps_escape_doubles_single_quotes() {
        assert_eq!(ps_escape("it's"), "it''s");
    }

    #[test]
    fn censor_output_replaces_when_no_log_true() {
        assert_eq!(
            censor_output(true, b"super-secret-token"),
            "<censored due to no log>"
        );
    }

    #[test]
    fn censor_output_passes_through_when_no_log_false() {
        assert_eq!(censor_output(false, b"hello\nworld"), "hello\nworld");
    }

    #[test]
    fn censor_output_handles_invalid_utf8() {
        // Lossy decode keeps the function infallible on raw remote bytes.
        let bytes = b"abc\xffdef";
        let rendered = censor_output(false, bytes);
        assert!(rendered.starts_with("abc"));
        assert!(rendered.ends_with("def"));
    }

    #[test]
    fn set_no_log_toggles_field() {
        let mut c = WinRmConnection::new("h".into(), "u".into(), "p".into());
        assert!(!c.no_log);
        c.set_no_log(true);
        assert!(c.no_log);
    }
}
