//! WSMan (Web Services Management) SOAP envelope construction and parsing.
//!
//! This is the wire protocol underneath both WinRM and PSRP. Every operation
//! — open a shell, run a command, pull stdout, send stdin, close the shell —
//! is a SOAP request/response with a specific Action URI.
//!
//! References:
//! - MS-WSMV: WS-Management Protocol Extensions for Windows Vista
//! - DSP0226 (DMTF): WS-Management Specification

use std::collections::HashMap;
use std::fmt::Write as _;

use quick_xml::events::Event;
use quick_xml::Reader;
use uuid::Uuid;

use crate::error::ConnectionError;

/// WSMan namespaces — referenced by envelopes and parsers.
pub mod ns {
    pub const S: &str = "http://www.w3.org/2003/05/soap-envelope";
    pub const A: &str = "http://schemas.xmlsoap.org/ws/2004/08/addressing";
    pub const W: &str = "http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd";
    pub const P: &str = "http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd";
    pub const RSP: &str = "http://schemas.microsoft.com/wbem/wsman/1/windows/shell";
    pub const X: &str = "http://schemas.xmlsoap.org/ws/2004/09/transfer";
    pub const CMD: &str = "http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd";
}

/// WSMan Action URIs.
pub mod action {
    pub const CREATE: &str = "http://schemas.xmlsoap.org/ws/2004/09/transfer/Create";
    pub const DELETE: &str = "http://schemas.xmlsoap.org/ws/2004/09/transfer/Delete";
    pub const COMMAND: &str = "http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Command";
    pub const RECEIVE: &str = "http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Receive";
    pub const SEND: &str = "http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Send";
    pub const SIGNAL: &str = "http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Signal";
}

/// Resource URIs Windows recognizes for the Shell resource.
pub mod resource {
    pub const CMD_SHELL: &str =
        "http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd";
    pub const POWERSHELL_SHELL: &str =
        "http://schemas.microsoft.com/powershell/Microsoft.PowerShell";
}

/// Signal codes (MS-WSMV §3.1.4.13).
pub mod signal {
    pub const TERMINATE: &str =
        "http://schemas.microsoft.com/wbem/wsman/1/windows/shell/signal/terminate";
    pub const CTRL_C: &str =
        "http://schemas.microsoft.com/wbem/wsman/1/windows/shell/signal/ctrl_c";
}

/// Parameters that vary per-request. The envelope is otherwise boilerplate.
#[derive(Debug, Clone)]
pub struct EnvelopeParams<'a> {
    pub action: &'a str,
    pub resource_uri: &'a str,
    pub to: &'a str,
    /// Optional selector (e.g. ShellId for everything but Create).
    pub shell_id: Option<&'a str>,
    pub message_id: Uuid,
    /// MaxEnvelopeSize hint, in bytes. Windows defaults to 153600.
    pub max_envelope_size: u32,
    pub operation_timeout_sec: u32,
    pub locale: &'a str,
}

impl<'a> EnvelopeParams<'a> {
    pub fn new(action: &'a str, resource_uri: &'a str, to: &'a str) -> Self {
        Self {
            action,
            resource_uri,
            to,
            shell_id: None,
            message_id: Uuid::new_v4(),
            max_envelope_size: 153_600,
            operation_timeout_sec: 60,
            locale: "en-US",
        }
    }

    pub fn with_shell(mut self, shell_id: &'a str) -> Self {
        self.shell_id = Some(shell_id);
        self
    }

    pub fn with_timeout(mut self, secs: u32) -> Self {
        self.operation_timeout_sec = secs;
        self
    }
}

/// Build a SOAP envelope skeleton with the given `body` element appended
/// inside `<s:Body>`. `body` must be a well-formed XML fragment.
pub fn build_envelope(p: &EnvelopeParams<'_>, body: &str) -> String {
    let mut out = String::with_capacity(2048 + body.len());
    out.push_str(r#"<?xml version="1.0" encoding="UTF-8"?>"#);
    out.push_str(r#"<s:Envelope"#);
    write!(out, r#" xmlns:s="{}""#, ns::S).unwrap();
    write!(out, r#" xmlns:a="{}""#, ns::A).unwrap();
    write!(out, r#" xmlns:w="{}""#, ns::W).unwrap();
    write!(out, r#" xmlns:p="{}""#, ns::P).unwrap();
    write!(out, r#" xmlns:rsp="{}""#, ns::RSP).unwrap();
    write!(out, r#" xmlns:x="{}""#, ns::X).unwrap();
    out.push('>');
    out.push_str("<s:Header>");
    write!(
        out,
        "<a:To>{}</a:To>",
        xml_escape(p.to)
    )
    .unwrap();
    write!(
        out,
        r#"<w:ResourceURI s:mustUnderstand="true">{}</w:ResourceURI>"#,
        xml_escape(p.resource_uri)
    )
    .unwrap();
    out.push_str(r#"<a:ReplyTo>"#);
    out.push_str(
        r#"<a:Address s:mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</a:Address>"#,
    );
    out.push_str("</a:ReplyTo>");
    write!(
        out,
        "<a:Action s:mustUnderstand=\"true\">{}</a:Action>",
        xml_escape(p.action)
    )
    .unwrap();
    write!(
        out,
        "<w:MaxEnvelopeSize s:mustUnderstand=\"true\">{}</w:MaxEnvelopeSize>",
        p.max_envelope_size
    )
    .unwrap();
    write!(out, "<a:MessageID>uuid:{}</a:MessageID>", p.message_id).unwrap();
    write!(out, "<w:Locale xml:lang=\"{}\" s:mustUnderstand=\"false\" />", p.locale).unwrap();
    write!(
        out,
        "<p:DataLocale xml:lang=\"{}\" s:mustUnderstand=\"false\" />",
        p.locale
    )
    .unwrap();
    write!(
        out,
        "<w:OperationTimeout>PT{}S</w:OperationTimeout>",
        p.operation_timeout_sec
    )
    .unwrap();
    if let Some(sid) = p.shell_id {
        write!(
            out,
            r#"<w:SelectorSet><w:Selector Name="ShellId">{}</w:Selector></w:SelectorSet>"#,
            xml_escape(sid)
        )
        .unwrap();
    }
    out.push_str("</s:Header>");
    out.push_str("<s:Body>");
    out.push_str(body);
    out.push_str("</s:Body>");
    out.push_str("</s:Envelope>");
    out
}

/// Build a Shell-Create envelope body for cmd.exe.
pub fn body_create_cmd_shell(
    input_streams: &str,
    output_streams: &str,
    working_dir: Option<&str>,
    idle_timeout_sec: u32,
    no_profile: bool,
    codepage: u32,
) -> String {
    let mut body = String::with_capacity(512);
    body.push_str("<rsp:Shell>");
    write!(
        body,
        "<rsp:InputStreams>{}</rsp:InputStreams>",
        xml_escape(input_streams)
    )
    .unwrap();
    write!(
        body,
        "<rsp:OutputStreams>{}</rsp:OutputStreams>",
        xml_escape(output_streams)
    )
    .unwrap();
    if let Some(wd) = working_dir {
        write!(body, "<rsp:WorkingDirectory>{}</rsp:WorkingDirectory>", xml_escape(wd)).unwrap();
    }
    write!(
        body,
        "<rsp:IdleTimeOut>PT{}S</rsp:IdleTimeOut>",
        idle_timeout_sec
    )
    .unwrap();
    body.push_str("</rsp:Shell>");

    // OptionSet — separate from <Shell>. The caller's envelope builder doesn't
    // know about this, so we emit it inline; the WSMan server accepts it.
    let mut opts = String::new();
    opts.push_str(r#"<w:OptionSet>"#);
    write!(
        opts,
        r#"<w:Option Name="WINRS_NOPROFILE">{}</w:Option>"#,
        if no_profile { "TRUE" } else { "FALSE" }
    )
    .unwrap();
    write!(
        opts,
        r#"<w:Option Name="WINRS_CODEPAGE">{}</w:Option>"#,
        codepage
    )
    .unwrap();
    opts.push_str("</w:OptionSet>");

    // We can't change the Header from inside the body, so we cheat: prepend an
    // OptionSet that the SOAP parser tolerates in either position. The Windows
    // WSMan service accepts an OptionSet inside <s:Body> for legacy clients,
    // but for safety we keep it out and rely on Header-level OptionSet by
    // writing it into the envelope via [`build_envelope_with_options`] below.
    let _ = opts;
    body
}

/// Build a SOAP envelope with a Header-level `<w:OptionSet>` block.
pub fn build_envelope_with_options(
    p: &EnvelopeParams<'_>,
    body: &str,
    options: &[(&str, &str)],
) -> String {
    if options.is_empty() {
        return build_envelope(p, body);
    }
    let mut envelope = build_envelope(p, body);
    // Insert OptionSet just before </s:Header>.
    let insert_at = envelope
        .rfind("</s:Header>")
        .expect("envelope always contains </s:Header>");
    let mut opts = String::from(r#"<w:OptionSet>"#);
    for (k, v) in options {
        write!(
            opts,
            r#"<w:Option Name="{}">{}</w:Option>"#,
            xml_escape(k),
            xml_escape(v)
        )
        .unwrap();
    }
    opts.push_str("</w:OptionSet>");
    envelope.insert_str(insert_at, &opts);
    envelope
}

/// Build the body for `Command` (run a command line).
pub fn body_command(command: &str, arguments: &[&str]) -> String {
    let mut body = String::new();
    body.push_str(r#"<rsp:CommandLine>"#);
    write!(body, "<rsp:Command>{}</rsp:Command>", xml_escape(command)).unwrap();
    for arg in arguments {
        write!(body, "<rsp:Arguments>{}</rsp:Arguments>", xml_escape(arg)).unwrap();
    }
    body.push_str("</rsp:CommandLine>");
    body
}

/// Build the body for `Receive` — pull output from a running command.
///
/// `streams` is a comma-separated list, typically `"stdout stderr"` for cmd.exe
/// or `"stdout"` for PowerShell. `command_id` selects which command's output
/// we want; omit to pull from the shell's default output stream.
pub fn body_receive(streams: &str, command_id: Option<&str>) -> String {
    let mut body = String::new();
    body.push_str("<rsp:Receive>");
    match command_id {
        Some(cid) => write!(
            body,
            r#"<rsp:DesiredStream CommandId="{}">{}</rsp:DesiredStream>"#,
            xml_escape(cid),
            xml_escape(streams)
        )
        .unwrap(),
        None => write!(body, "<rsp:DesiredStream>{}</rsp:DesiredStream>", xml_escape(streams))
            .unwrap(),
    }
    body.push_str("</rsp:Receive>");
    body
}

/// Build the body for `Send` — feed stdin (or PSRP messages) into the shell.
pub fn body_send(
    stream_name: &str,
    command_id: Option<&str>,
    data: &[u8],
    end: bool,
) -> String {
    use base64::Engine as _;
    let b64 = base64::engine::general_purpose::STANDARD.encode(data);
    let mut body = String::new();
    body.push_str("<rsp:Send>");
    body.push_str("<rsp:Stream");
    write!(body, r#" Name="{}""#, xml_escape(stream_name)).unwrap();
    if let Some(cid) = command_id {
        write!(body, r#" CommandId="{}""#, xml_escape(cid)).unwrap();
    }
    if end {
        body.push_str(r#" End="true""#);
    }
    body.push('>');
    body.push_str(&b64);
    body.push_str("</rsp:Stream>");
    body.push_str("</rsp:Send>");
    body
}

/// Build the body for `Signal` — terminate a command or shell.
pub fn body_signal(command_id: &str, signal_uri: &str) -> String {
    let mut body = String::new();
    write!(body, r#"<rsp:Signal CommandId="{}">"#, xml_escape(command_id)).unwrap();
    write!(body, "<rsp:Code>{}</rsp:Code>", xml_escape(signal_uri)).unwrap();
    body.push_str("</rsp:Signal>");
    body
}

/// Parsed response from a successful WSMan call.
#[derive(Debug, Default, Clone)]
pub struct ParsedResponse {
    /// ShellId from a Create response, or CommandId from a Command response.
    pub created_id: Option<String>,
    /// Stream name → concatenated decoded bytes for that stream.
    pub streams: HashMap<String, Vec<u8>>,
    /// Whether the response declared CommandState=Done.
    pub command_done: bool,
    /// Exit code if `command_done` is set.
    pub exit_code: Option<i32>,
}

/// Decode a WSMan SOAP response. Recognizes:
/// - `<x:ResourceCreated>` ShellId selector → `created_id`
/// - `<rsp:CommandResponse><rsp:CommandId>` → `created_id`
/// - `<rsp:Stream Name="...">...</rsp:Stream>` (base64-decoded)
/// - `<rsp:CommandState State=".../Done">` + `<rsp:ExitCode>`
/// - `<s:Fault>` → returns Err
pub fn parse_response(xml: &str) -> Result<ParsedResponse, ConnectionError> {
    use base64::Engine as _;

    let mut reader = Reader::from_str(xml);
    reader.config_mut().trim_text(false);

    let mut out = ParsedResponse::default();
    let mut buf = Vec::new();
    let mut stack: Vec<String> = Vec::new();
    let mut current_stream: Option<String> = None;
    let mut text_accum = String::new();
    let mut fault_subcode: Option<String> = None;
    let mut fault_reason: Option<String> = None;
    let mut in_fault = false;
    let mut in_fault_reason = false;
    let mut last_selector_name: Option<String> = None;

    loop {
        match reader.read_event_into(&mut buf) {
            Err(e) => {
                return Err(ConnectionError::Protocol(format!(
                    "XML parse error at pos {}: {}",
                    reader.buffer_position(),
                    e
                )));
            }
            Ok(Event::Eof) => break,
            Ok(Event::Start(e)) => {
                let name = local_name(e.name().as_ref());
                stack.push(name.clone());
                text_accum.clear();
                match name.as_str() {
                    "Fault" => in_fault = true,
                    "Reason" if in_fault => in_fault_reason = true,
                    "Stream" => {
                        let mut sname = String::new();
                        for attr in e.attributes().flatten() {
                            if attr.key.as_ref() == b"Name" {
                                sname = String::from_utf8_lossy(&attr.value).to_string();
                            }
                        }
                        current_stream = Some(sname);
                    }
                    "Selector" => {
                        for attr in e.attributes().flatten() {
                            if attr.key.as_ref() == b"Name" {
                                last_selector_name =
                                    Some(String::from_utf8_lossy(&attr.value).to_string());
                            }
                        }
                    }
                    "CommandState" => {
                        for attr in e.attributes().flatten() {
                            if attr.key.as_ref() == b"State"
                                && String::from_utf8_lossy(&attr.value).ends_with("/Done")
                            {
                                out.command_done = true;
                            }
                        }
                    }
                    _ => {}
                }
            }
            Ok(Event::Empty(e)) => {
                let name = local_name(e.name().as_ref());
                if name == "Stream" {
                    // Empty stream tag; nothing to decode but mark end-of-stream
                    // via the End="true" attribute if we cared. Skip.
                }
                if name == "CommandState" {
                    for attr in e.attributes().flatten() {
                        if attr.key.as_ref() == b"State"
                            && String::from_utf8_lossy(&attr.value).ends_with("/Done")
                        {
                            out.command_done = true;
                        }
                    }
                }
            }
            Ok(Event::Text(t)) => {
                let s = t.unescape().map_err(|e| {
                    ConnectionError::Protocol(format!("xml text unescape: {e}"))
                })?;
                text_accum.push_str(&s);
            }
            Ok(Event::CData(t)) => {
                text_accum.push_str(&String::from_utf8_lossy(t.as_ref()));
            }
            Ok(Event::End(e)) => {
                let name = local_name(e.name().as_ref());
                let _popped = stack.pop();
                match name.as_str() {
                    "Stream" => {
                        if let Some(sname) = current_stream.take() {
                            let trimmed: String =
                                text_accum.split_whitespace().collect();
                            if !trimmed.is_empty() {
                                let decoded = base64::engine::general_purpose::STANDARD
                                    .decode(trimmed.as_bytes())
                                    .map_err(|e| {
                                        ConnectionError::Protocol(format!(
                                            "base64 decode of stream {sname}: {e}"
                                        ))
                                    })?;
                                out.streams
                                    .entry(sname)
                                    .or_default()
                                    .extend_from_slice(&decoded);
                            }
                        }
                    }
                    "Selector" => {
                        if last_selector_name.as_deref() == Some("ShellId") {
                            out.created_id = Some(text_accum.trim().to_string());
                        }
                        last_selector_name = None;
                    }
                    "CommandId" => {
                        // <CommandId> appears in CommandResponse for the
                        // freshly-issued command, and again as an attribute
                        // elsewhere. Only set if not already set by Selector.
                        if out.created_id.is_none() {
                            out.created_id = Some(text_accum.trim().to_string());
                        }
                    }
                    "ExitCode" => {
                        out.exit_code = text_accum.trim().parse().ok();
                    }
                    "Value" if in_fault && parent_is(&stack, "Subcode") => {
                        fault_subcode = Some(text_accum.trim().to_string());
                    }
                    "Text" if in_fault_reason => {
                        fault_reason = Some(text_accum.trim().to_string());
                    }
                    "Reason" => {
                        in_fault_reason = false;
                    }
                    "Fault" => {
                        in_fault = false;
                    }
                    _ => {}
                }
                text_accum.clear();
            }
            _ => {}
        }
        buf.clear();
    }

    if let Some(reason) = fault_reason {
        let code = fault_subcode.unwrap_or_else(|| "Unknown".into());
        return Err(ConnectionError::Protocol(format!(
            "WSMan fault ({code}): {reason}"
        )));
    }
    Ok(out)
}

fn parent_is(stack: &[String], name: &str) -> bool {
    stack.last().map(|s| s.as_str()) == Some(name)
}

fn local_name(qname: &[u8]) -> String {
    match qname.iter().position(|&b| b == b':') {
        Some(idx) => String::from_utf8_lossy(&qname[idx + 1..]).to_string(),
        None => String::from_utf8_lossy(qname).to_string(),
    }
}

fn xml_escape(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    for c in s.chars() {
        match c {
            '<' => out.push_str("&lt;"),
            '>' => out.push_str("&gt;"),
            '&' => out.push_str("&amp;"),
            '"' => out.push_str("&quot;"),
            '\'' => out.push_str("&apos;"),
            _ => out.push(c),
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn envelope_contains_required_headers() {
        let p = EnvelopeParams::new(
            action::CREATE,
            resource::CMD_SHELL,
            "http://win.example:5986/wsman",
        );
        let env = build_envelope(&p, "<rsp:Shell/>");
        assert!(env.contains("<a:Action"));
        assert!(env.contains(action::CREATE));
        assert!(env.contains("<a:MessageID>uuid:"));
        assert!(env.contains("<w:ResourceURI"));
        assert!(env.contains("<rsp:Shell/>"));
    }

    #[test]
    fn envelope_with_options_inserts_before_header_close() {
        let p = EnvelopeParams::new(
            action::CREATE,
            resource::CMD_SHELL,
            "http://win.example:5986/wsman",
        );
        let env = build_envelope_with_options(
            &p,
            "<rsp:Shell/>",
            &[("WINRS_NOPROFILE", "TRUE"), ("WINRS_CODEPAGE", "65001")],
        );
        let opts_idx = env.find("<w:OptionSet>").expect("OptionSet present");
        let hdr_close = env.find("</s:Header>").unwrap();
        assert!(opts_idx < hdr_close);
        assert!(env.contains(r#"<w:Option Name="WINRS_NOPROFILE">TRUE</w:Option>"#));
    }

    #[test]
    fn parse_resource_created_extracts_shell_id() {
        let xml = r#"<?xml version="1.0"?>
        <s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
                    xmlns:x="http://schemas.xmlsoap.org/ws/2004/09/transfer"
                    xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd"
                    xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing">
          <s:Body>
            <x:ResourceCreated>
              <a:ReferenceParameters>
                <w:SelectorSet>
                  <w:Selector Name="ShellId">F9B1B2A0-DEAD-BEEF-CAFE-1234567890AB</w:Selector>
                </w:SelectorSet>
              </a:ReferenceParameters>
            </x:ResourceCreated>
          </s:Body>
        </s:Envelope>"#;
        let resp = parse_response(xml).unwrap();
        assert_eq!(
            resp.created_id.as_deref(),
            Some("F9B1B2A0-DEAD-BEEF-CAFE-1234567890AB")
        );
    }

    #[test]
    fn parse_receive_extracts_streams_and_exit_code() {
        // "hi" base64 -> "aGk="
        let xml = r#"<?xml version="1.0"?>
        <s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
                    xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
          <s:Body>
            <rsp:ReceiveResponse>
              <rsp:Stream Name="stdout">aGk=</rsp:Stream>
              <rsp:CommandState State="http://schemas.microsoft.com/wbem/wsman/1/windows/shell/CommandState/Done">
                <rsp:ExitCode>0</rsp:ExitCode>
              </rsp:CommandState>
            </rsp:ReceiveResponse>
          </s:Body>
        </s:Envelope>"#;
        let resp = parse_response(xml).unwrap();
        assert_eq!(resp.streams.get("stdout").map(|v| v.as_slice()), Some(&b"hi"[..]));
        assert!(resp.command_done);
        assert_eq!(resp.exit_code, Some(0));
    }

    #[test]
    fn parse_fault_returns_err() {
        let xml = r#"<?xml version="1.0"?>
        <s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope">
          <s:Body>
            <s:Fault>
              <s:Code><s:Value>s:Sender</s:Value>
                <s:Subcode><s:Value>w:AccessDenied</s:Value></s:Subcode>
              </s:Code>
              <s:Reason><s:Text xml:lang="en-US">access denied</s:Text></s:Reason>
            </s:Fault>
          </s:Body>
        </s:Envelope>"#;
        let err = parse_response(xml).unwrap_err();
        let msg = err.to_string();
        assert!(msg.contains("WSMan fault"));
        assert!(msg.contains("access denied"));
    }

    #[test]
    fn body_command_escapes_xml() {
        let b = body_command("echo", &["<hi>", "&world"]);
        assert!(b.contains("&lt;hi&gt;"));
        assert!(b.contains("&amp;world"));
    }

    #[test]
    fn body_send_base64_encodes_payload() {
        let b = body_send("stdin", Some("cmd-1"), b"hi", true);
        // "hi" -> "aGk="
        assert!(b.contains("aGk="));
        assert!(b.contains(r#"Name="stdin""#));
        assert!(b.contains(r#"CommandId="cmd-1""#));
        assert!(b.contains(r#"End="true""#));
    }
}
