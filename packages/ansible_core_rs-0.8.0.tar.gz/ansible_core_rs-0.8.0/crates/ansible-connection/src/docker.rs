//! Docker connection plugin — runs commands inside a Docker container
//! via `docker exec` and `docker cp`.
//!
//! This mirrors upstream's `community.docker.docker` connection plugin.
//!
//! Ansible variables honored:
//! - `ansible_host` — container name or ID (defaults to the inventory hostname)
//! - `ansible_user` — user inside the container (passed as `docker exec -u USER`)
//! - `ansible_docker_extra_args` — extra args appended to every `docker` invocation

use std::path::Path;

use ansible_plugins::PluginError;
use async_trait::async_trait;
use tracing::debug;

use crate::container_common::{
    cp_from_container, cp_to_container, exec_in_container, verify_container,
};

const RUNTIME: &str = "docker";

pub struct DockerConnection {
    pub container: String,
    pub user: Option<String>,
    pub extra_args: Vec<String>,
}

impl DockerConnection {
    pub fn new(container: String) -> Self {
        Self {
            container,
            user: None,
            extra_args: Vec::new(),
        }
    }
}

#[async_trait]
impl ansible_plugins::ConnectionPlugin for DockerConnection {
    async fn connect(&mut self) -> Result<(), PluginError> {
        debug!(
            "[{}] verifying docker container is running",
            self.container
        );
        verify_container(RUNTIME, &self.container).await
    }

    async fn exec_command(
        &self,
        cmd: &str,
        in_data: Option<&[u8]>,
    ) -> Result<(i32, Vec<u8>, Vec<u8>), PluginError> {
        exec_in_container(
            RUNTIME,
            &self.container,
            self.user.as_deref(),
            &self.extra_args,
            cmd,
            in_data,
        )
        .await
    }

    async fn put_file(&self, in_path: &Path, out_path: &Path) -> Result<(), PluginError> {
        debug!(
            "[{}] put_file {} -> {}",
            self.container,
            in_path.display(),
            out_path.display()
        );
        cp_to_container(
            RUNTIME,
            &self.container,
            &self.extra_args,
            in_path,
            out_path,
        )
        .await
    }

    async fn fetch_file(&self, in_path: &Path, out_path: &Path) -> Result<(), PluginError> {
        debug!(
            "[{}] fetch_file {} -> {}",
            self.container,
            in_path.display(),
            out_path.display()
        );
        cp_from_container(
            RUNTIME,
            &self.container,
            &self.extra_args,
            in_path,
            out_path,
        )
        .await
    }

    async fn close(&mut self) -> Result<(), PluginError> {
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::container_common::{build_cp_from_command, build_cp_to_command, build_exec_command};
    use std::path::PathBuf;

    fn argv(cmd: &tokio::process::Command) -> Vec<String> {
        cmd.as_std()
            .get_args()
            .map(|a| a.to_string_lossy().to_string())
            .collect()
    }

    fn program(cmd: &tokio::process::Command) -> String {
        cmd.as_std().get_program().to_string_lossy().to_string()
    }

    #[test]
    fn new_defaults() {
        let conn = DockerConnection::new("web".into());
        assert_eq!(conn.container, "web");
        assert!(conn.user.is_none());
        assert!(conn.extra_args.is_empty());
    }

    #[test]
    fn exec_command_basic() {
        let cmd = build_exec_command(RUNTIME, "web", None, &[], "uptime", false);
        assert_eq!(program(&cmd), "docker");
        let args = argv(&cmd);
        assert_eq!(args[0], "exec");
        // Container name comes immediately before /bin/sh -c CMD.
        let sh_idx = args.iter().position(|a| a == "/bin/sh").unwrap();
        assert_eq!(args[sh_idx - 1], "web");
        assert_eq!(args[sh_idx + 1], "-c");
        assert_eq!(args[sh_idx + 2], "uptime");
        assert!(!args.contains(&"-u".into()));
        assert!(!args.contains(&"-i".into()));
    }

    #[test]
    fn exec_command_honors_user_and_stdin_and_extra_args() {
        let extra = vec!["--privileged".to_string()];
        let cmd = build_exec_command(RUNTIME, "web", Some("deploy"), &extra, "true", true);
        let args = argv(&cmd);
        // -u USER must precede the container name
        let u_idx = args.iter().position(|a| a == "-u").expect("missing -u");
        assert_eq!(args[u_idx + 1], "deploy");
        assert!(args.contains(&"-i".into()));
        assert!(args.contains(&"--privileged".into()));
        let sh_idx = args.iter().position(|a| a == "/bin/sh").unwrap();
        assert_eq!(args[sh_idx - 1], "web");
    }

    #[test]
    fn cp_to_container_command_shape() {
        let cmd = build_cp_to_command(
            RUNTIME,
            "web",
            &[],
            &PathBuf::from("/tmp/local.txt"),
            &PathBuf::from("/etc/remote.txt"),
        );
        assert_eq!(program(&cmd), "docker");
        let args = argv(&cmd);
        assert_eq!(args[0], "cp");
        assert_eq!(args[args.len() - 2], "/tmp/local.txt");
        assert_eq!(args[args.len() - 1], "web:/etc/remote.txt");
    }

    #[test]
    fn cp_from_container_command_shape() {
        let cmd = build_cp_from_command(
            RUNTIME,
            "web",
            &[],
            &PathBuf::from("/etc/remote.txt"),
            &PathBuf::from("/tmp/local.txt"),
        );
        let args = argv(&cmd);
        assert_eq!(args[0], "cp");
        assert_eq!(args[args.len() - 2], "web:/etc/remote.txt");
        assert_eq!(args[args.len() - 1], "/tmp/local.txt");
    }
}
