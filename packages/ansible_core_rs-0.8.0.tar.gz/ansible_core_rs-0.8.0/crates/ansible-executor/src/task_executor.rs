use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::Arc;

use ansible_playbook::{extract_action, Task};
use ansible_template::Templar;
use ansible_utils::{AnsibleValue, TaskResult};
use ansible_vars::VariableManager;
use tracing::{debug, warn};

use crate::ExecutorError;

/// Read `/etc/os-release` and return `(distribution, os_family)`.
/// Falls back to `("Unknown", "Unknown")` off-Linux or if the file is
/// missing or unparseable.
fn parse_os_release() -> (String, String) {
    let text = match std::fs::read_to_string("/etc/os-release") {
        Ok(t) => t,
        Err(_) => return ("Unknown".into(), "Unknown".into()),
    };
    let mut id = String::new();
    let mut id_like = String::new();
    for line in text.lines() {
        let Some((k, v)) = line.split_once('=') else {
            continue;
        };
        let v = v.trim().trim_matches('"').to_string();
        match k {
            "ID" => id = v,
            "ID_LIKE" => id_like = v,
            _ => {}
        }
    }
    let distro = if id.is_empty() { "Unknown".into() } else { id.clone() };
    // Map the first token of ID_LIKE (or ID itself) to the ansible OS family.
    let first = id_like.split_whitespace().next().unwrap_or(&id).to_string();
    let family = match first.as_str() {
        "debian" | "ubuntu" => "Debian",
        "rhel" | "fedora" | "centos" | "rocky" | "almalinux" => "RedHat",
        "arch" | "manjaro" => "Archlinux",
        "suse" | "opensuse" | "opensuse-leap" | "opensuse-tumbleweed" => "Suse",
        "alpine" => "Alpine",
        "" => "Unknown",
        _ => "Unknown",
    }
    .to_string();
    (distro, family)
}

/// Map an os-release ID or ID_LIKE token to an Ansible OS family name.
/// Used by both local `parse_os_release()` and remote fact gathering.
fn map_os_family(id: &str) -> String {
    match id {
        "debian" | "ubuntu" => "Debian",
        "rhel" | "fedora" | "centos" | "rocky" | "almalinux" => "RedHat",
        "arch" | "manjaro" => "Archlinux",
        "suse" | "opensuse" | "opensuse-leap" | "opensuse-tumbleweed" => "Suse",
        "alpine" => "Alpine",
        "" | "unknown" => "Unknown",
        _ => "Unknown",
    }
    .to_string()
}

fn shell_escape(s: &str) -> String {
    format!("'{}'", s.replace('\'', "'\\''"))
}

/// Return true if an executable named `name` is reachable via `$PATH`.
/// Used to decide whether optional helpers like `usermod` are present.
fn binary_in_path(name: &str) -> bool {
    let Some(path) = std::env::var_os("PATH") else {
        return false;
    };
    std::env::split_paths(&path).any(|dir| {
        let candidate = dir.join(name);
        candidate.is_file()
            || cfg!(windows) && candidate.with_extension("exe").is_file()
    })
}

/// Mode of operation for the pacman module's per-package action step.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum PacmanMode {
    Present,
    Latest,
    Remove,
}

/// Result of running a pacman command — captured separately from
/// `tokio::process::Output` so unit tests can construct it without spawning
/// a real process.
struct PacmanOutput {
    stdout: String,
    stderr: String,
    rc: i32,
    success: bool,
}

/// Parse an `extra_args`-style argument into a vector of strings. Accepts
/// either a string (split on whitespace, mirroring upstream Ansible's
/// behavior) or a list of strings.
fn parse_extra_args(value: Option<&AnsibleValue>) -> Vec<String> {
    match value {
        Some(AnsibleValue::String(s)) => s
            .split_whitespace()
            .map(|t| t.to_string())
            .collect(),
        Some(AnsibleValue::Array(arr)) => arr
            .iter()
            .filter_map(|v| v.as_str().map(|s| s.to_string()))
            .collect(),
        _ => Vec::new(),
    }
}

/// Map the `follow_redirects` argument (a string) and an HTTP method to a
/// `reqwest::redirect::Policy`. Matches upstream choices `all`, `none`,
/// `safe`, `urllib2` (ansible/ansible#86793 — the legacy `yes`/`no`
/// aliases were removed); rejects bool values from the start since the
/// Rust port has no legacy users to deprecate.
#[cfg(feature = "http")]
fn parse_follow_redirects(
    arg: Option<&AnsibleValue>,
    method: &str,
) -> Result<reqwest::redirect::Policy, String> {
    let value = match arg {
        None => "safe",
        Some(AnsibleValue::String(s)) => s.as_str(),
        Some(AnsibleValue::Bool(_)) => {
            return Err(
                "follow_redirects: boolean values are not accepted; use 'all' or 'none'"
                    .into(),
            );
        }
        Some(_) => return Err("follow_redirects: must be a string".into()),
    };

    let follow_anything = || reqwest::redirect::Policy::limited(50);
    let follow_none = reqwest::redirect::Policy::none;

    match value {
        "yes" | "no" => Err(format!(
            "follow_redirects: '{value}' was removed in upstream ansible/ansible#86793; \
             use {} instead",
            if value == "yes" { "'all'" } else { "'none'" }
        )),
        "all" => Ok(follow_anything()),
        "none" => Ok(follow_none()),
        "safe" | "urllib2" => {
            // urllib2 default behavior and ansible's 'safe' both restrict
            // redirect-following to idempotent methods.
            let m = method.to_ascii_uppercase();
            if m == "GET" || m == "HEAD" {
                Ok(follow_anything())
            } else {
                Ok(follow_none())
            }
        }
        other => Err(format!(
            "follow_redirects: invalid value '{other}'; must be one of \
             'all', 'none', 'safe', 'urllib2'"
        )),
    }
}

/// Validate a one-line-style apt source per `sources.list(5)`. Matches
/// upstream ansible/ansible#85881: the type must be `deb`/`deb-src`,
/// bracketed options are skipped, and the remaining fields must be at
/// least URI + suite (+ at least one component, unless the suite ends in
/// `/` which makes it an exact-path entry with no component).
fn validate_apt_source_line(line: &str) -> Result<(), String> {
    const VALID_TYPES: &[&str] = &["deb", "deb-src"];

    let parts: Vec<&str> = line.split_whitespace().collect();
    if parts.is_empty() {
        return Err("empty source line".into());
    }
    if !VALID_TYPES.contains(&parts[0]) {
        return Err(format!(
            "type must be one of {VALID_TYPES:?}, got '{}'",
            parts[0]
        ));
    }

    // Skip bracketed options.
    let mut idx = 1;
    if parts.get(idx).is_some_and(|p| p.starts_with('[')) {
        if parts[idx].ends_with(']') && parts[idx].len() > 1 {
            idx += 1;
        } else {
            // Multi-token options — scan for closing ']'.
            let mut closed = false;
            idx += 1;
            while let Some(tok) = parts.get(idx) {
                idx += 1;
                if tok.ends_with(']') {
                    closed = true;
                    break;
                }
            }
            if !closed {
                return Err("malformed options block (missing closing ']')".into());
            }
        }
    }

    let remaining: &[&str] = &parts[idx..];
    if remaining.len() < 2 {
        return Err("missing URI and/or suite after type/options".into());
    }
    let suite = remaining[1];
    if suite.ends_with('/') {
        // Exact-path suite — components must NOT be present.
        if remaining.len() > 2 {
            return Err(
                "suite ends with '/' (exact path) — components are not allowed".into(),
            );
        }
    } else if remaining.len() < 3 {
        return Err("at least one component is required after the suite".into());
    }
    Ok(())
}

/// Canonical form of an apt source line for equality checks: trim and
/// collapse internal whitespace to single spaces, dropping the trailing
/// newline / leading-comment marker.
fn normalize_source_line(line: &str) -> String {
    line.split_whitespace().collect::<Vec<_>>().join(" ")
}

/// Derive a default filename for a repo when the user didn't supply one.
/// Strategy: take the host part of the URI (or the URI itself if it
/// doesn't parse), strip dots, fall back to "ansible".
fn default_apt_filename(repo: &str) -> String {
    fn clean(input: &str) -> String {
        let stem: String = input
            .chars()
            .map(|c| {
                if c.is_ascii_alphanumeric() || c == '-' || c == '_' {
                    c
                } else {
                    '_'
                }
            })
            .collect();
        stem.trim_matches('_').to_string()
    }
    let parts: Vec<&str> = repo.split_whitespace().collect();
    let uri_tok = parts.iter().find(|p| {
        p.starts_with("http://")
            || p.starts_with("https://")
            || p.starts_with("ftp://")
            || p.starts_with("ftps://")
            || p.starts_with("file:")
    });
    if let Some(uri) = uri_tok {
        // Pull the host (or the path tail for file://) for naming.
        let after_scheme = uri.splitn(2, "://").nth(1).unwrap_or(uri);
        let host = after_scheme.split('/').next().unwrap_or("");
        let cleaned = clean(host);
        if !cleaned.is_empty() {
            return cleaned;
        }
    }
    "ansible".into()
}

/// Flatten an AnsibleValue (expected: object) into a vector of (key, value)
/// string pairs for `application/x-www-form-urlencoded` bodies. Scalar
/// values are stringified; arrays produce repeated keys.
#[cfg(feature = "http")]
fn flatten_form_body(body: &AnsibleValue) -> Result<Vec<(String, String)>, String> {
    let obj = match body {
        AnsibleValue::Object(m) => m,
        _ => return Err("body must be an object for form-urlencoded".into()),
    };
    let mut out: Vec<(String, String)> = Vec::new();
    for (k, v) in obj {
        match v {
            AnsibleValue::String(s) => out.push((k.clone(), s.clone())),
            AnsibleValue::Bool(b) => out.push((k.clone(), b.to_string())),
            AnsibleValue::Number(n) => out.push((k.clone(), n.to_string())),
            AnsibleValue::Null => {}
            AnsibleValue::Array(arr) => {
                for item in arr {
                    let s = match item {
                        AnsibleValue::String(s) => s.clone(),
                        AnsibleValue::Bool(b) => b.to_string(),
                        AnsibleValue::Number(n) => n.to_string(),
                        _ => {
                            return Err(format!(
                                "form-urlencoded: array entries under '{k}' must be scalars"
                            ));
                        }
                    };
                    out.push((k.clone(), s));
                }
            }
            AnsibleValue::Object(_) => {
                return Err(format!(
                    "form-urlencoded: nested object at '{k}' is not supported; \
                     use form-multipart for structured uploads"
                ));
            }
        }
    }
    Ok(out)
}

/// Build a `reqwest::multipart::Form` from an AnsibleValue body. Mirrors the
/// `form-multipart` body_format from upstream Python — replaces stdlib
/// `email` MIME generation per ansible/ansible#86687.
///
/// Each top-level field is either:
/// - A scalar (string/bool/number) — emitted as a text part.
/// - An object with `content` (string) + optional `filename`, `mime_type` —
///   emitted as a file part.
#[cfg(feature = "http")]
fn build_multipart_form(body: &AnsibleValue) -> Result<reqwest::multipart::Form, String> {
    let obj = match body {
        AnsibleValue::Object(m) => m,
        _ => return Err("body must be an object for form-multipart".into()),
    };
    let mut form = reqwest::multipart::Form::new();
    for (k, v) in obj {
        match v {
            AnsibleValue::String(s) => {
                form = form.text(k.clone(), s.clone());
            }
            AnsibleValue::Bool(b) => {
                form = form.text(k.clone(), b.to_string());
            }
            AnsibleValue::Number(n) => {
                form = form.text(k.clone(), n.to_string());
            }
            AnsibleValue::Null => {}
            AnsibleValue::Object(o) => {
                let content = match o.get("content").and_then(|v| v.as_str()) {
                    Some(s) => s.to_string(),
                    None => {
                        return Err(format!(
                            "form-multipart: object at '{k}' must have a 'content' string field"
                        ));
                    }
                };
                let mut part = reqwest::multipart::Part::text(content);
                if let Some(filename) = o.get("filename").and_then(|v| v.as_str()) {
                    part = part.file_name(filename.to_string());
                }
                if let Some(mime) = o.get("mime_type").and_then(|v| v.as_str()) {
                    part = part
                        .mime_str(mime)
                        .map_err(|e| format!("invalid mime_type '{mime}' at '{k}': {e}"))?;
                }
                form = form.part(k.clone(), part);
            }
            AnsibleValue::Array(_) => {
                return Err(format!(
                    "form-multipart: array values are not supported at '{k}'; \
                     repeat the field with distinct keys instead"
                ));
            }
        }
    }
    Ok(form)
}

/// Render a `[name] ... \n` repo section in the format dnf/yum expect.
/// Only the modern parameter set is honored; legacy params removed by
/// upstream ansible/ansible#86794 are rejected at the caller.
fn render_yum_repo_section(name: &str, args: &AnsibleValue) -> String {
    fn fmt_str(args: &AnsibleValue, key: &str, out_key: &str) -> Option<String> {
        args.get(key)
            .and_then(|v| v.as_str())
            .map(|s| format!("{out_key}={s}"))
    }
    fn fmt_bool(args: &AnsibleValue, key: &str, out_key: &str) -> Option<String> {
        args.get(key).and_then(|v| v.as_bool()).map(|b| {
            format!("{out_key}={}", if b { 1 } else { 0 })
        })
    }
    fn fmt_int(args: &AnsibleValue, key: &str, out_key: &str) -> Option<String> {
        args.get(key)
            .and_then(|v| v.as_i64())
            .map(|n| format!("{out_key}={n}"))
    }

    let mut lines = vec![format!("[{name}]")];

    let description = args
        .get("description")
        .and_then(|v| v.as_str())
        .unwrap_or(name);
    lines.push(format!("name={description}"));

    // Baseurl: accept a string or a list (joined per dnf convention).
    if let Some(bu) = args.get("baseurl") {
        let urls: Vec<String> = match bu {
            AnsibleValue::String(s) => vec![s.clone()],
            AnsibleValue::Array(arr) => arr
                .iter()
                .filter_map(|v| v.as_str().map(|s| s.to_string()))
                .collect(),
            _ => Vec::new(),
        };
        if !urls.is_empty() {
            lines.push(format!("baseurl={}", urls.join("\n        ")));
        }
    }

    for (key, out_key) in [
        ("mirrorlist", "mirrorlist"),
        ("metalink", "metalink"),
        ("gpgkey", "gpgkey"),
        ("proxy", "proxy"),
        ("proxy_username", "proxy_username"),
        ("proxy_password", "proxy_password"),
        ("password", "password"),
        ("username", "username"),
        ("sslcacert", "sslcacert"),
        ("sslclientcert", "sslclientcert"),
        ("sslclientkey", "sslclientkey"),
        ("includepkgs", "includepkgs"),
        ("exclude", "exclude"),
        ("type", "type"),
    ] {
        if let Some(line) = fmt_str(args, key, out_key) {
            lines.push(line);
        }
    }
    for (key, out_key) in [
        ("enabled", "enabled"),
        ("gpgcheck", "gpgcheck"),
        ("repo_gpgcheck", "repo_gpgcheck"),
        ("sslverify", "sslverify"),
        ("skip_if_unavailable", "skip_if_unavailable"),
        ("module_hotfixes", "module_hotfixes"),
    ] {
        if let Some(line) = fmt_bool(args, key, out_key) {
            lines.push(line);
        }
    }
    for (key, out_key) in [
        ("priority", "priority"),
        ("cost", "cost"),
        ("bandwidth", "bandwidth"),
        ("timeout", "timeout"),
        ("deltarpm_percentage", "deltarpm_percentage"),
        ("metadata_expire", "metadata_expire"),
    ] {
        if let Some(line) = fmt_int(args, key, out_key) {
            lines.push(line);
        }
    }

    let mut body = lines.join("\n");
    body.push('\n');
    body
}

/// Replace (or insert) a `[name]` section inside an existing .repo file.
fn upsert_yum_repo_section(existing: Option<&str>, name: &str, section: &str) -> String {
    let header = format!("[{name}]");
    match existing {
        None => section.to_string(),
        Some(content) => {
            let mut out = String::new();
            let mut in_target = false;
            let mut found = false;
            for line in content.split_inclusive('\n') {
                let trimmed = line.trim();
                if trimmed.starts_with('[') && trimmed.ends_with(']') {
                    if trimmed == header {
                        in_target = true;
                        found = true;
                        continue;
                    }
                    if in_target {
                        out.push_str(section);
                        if !section.ends_with('\n') {
                            out.push('\n');
                        }
                        in_target = false;
                    }
                }
                if !in_target {
                    out.push_str(line);
                }
            }
            if in_target {
                out.push_str(section);
                if !section.ends_with('\n') {
                    out.push('\n');
                }
            } else if !found {
                if !out.is_empty() && !out.ends_with('\n') {
                    out.push('\n');
                }
                if !out.is_empty() {
                    out.push('\n');
                }
                out.push_str(section);
            }
            out
        }
    }
}

/// Strip a `[name]` section from a .repo file. Returns the input unchanged
/// if the section isn't present.
fn remove_yum_repo_section(existing: &str, name: &str) -> String {
    let header = format!("[{name}]");
    let mut out = String::new();
    let mut in_target = false;
    for line in existing.split_inclusive('\n') {
        let trimmed = line.trim();
        if trimmed.starts_with('[') && trimmed.ends_with(']') {
            in_target = trimmed == header;
            if in_target {
                continue;
            }
        }
        if !in_target {
            out.push_str(line);
        }
    }
    out
}

/// Build the argv for `git submodule update`. When `track_submodules` is
/// set, append `--remote` — that flag tells git to read each submodule's
/// branch from `.gitmodules` rather than the hardcoded `master` that the
/// pre-ansible/ansible#86692 logic assumed.
fn build_git_submodule_update_args(track_submodules: bool, depth: Option<i64>) -> Vec<String> {
    let mut a: Vec<String> = vec!["submodule".into(), "update".into(), "--init".into()];
    a.push("--recursive".into());
    if track_submodules {
        a.push("--remote".into());
    }
    if let Some(d) = depth {
        a.push("--depth".into());
        a.push(d.to_string());
    }
    a
}

/// Resolve a version string to the ref we should checkout / reset against.
///
/// - `HEAD` → `<remote>/HEAD` (the remote's default branch).
/// - Otherwise, check whether `<remote>/<version>` is a known remote ref;
///   if so, return that. Otherwise return `version` as-is (lets tags and
///   raw SHAs flow through).
async fn resolve_git_target(
    git_path: &str,
    dest: &std::path::Path,
    remote: &str,
    version: &str,
    git_ssh_command: &str,
) -> Result<String, ExecutorError> {
    if version == "HEAD" {
        return Ok(format!("{remote}/HEAD"));
    }
    let mut cmd = tokio::process::Command::new(git_path);
    cmd.args(["show-ref", "--verify", "--quiet"])
        .arg(format!("refs/remotes/{remote}/{version}"))
        .current_dir(dest)
        .env("GIT_TERMINAL_PROMPT", "0")
        .env("GIT_SSH_COMMAND", git_ssh_command);
    let status = cmd
        .status()
        .await
        .map_err(|e| ExecutorError::TaskFailed(format!("git show-ref: {e}")))?;
    if status.success() {
        Ok(format!("{remote}/{version}"))
    } else {
        Ok(version.to_string())
    }
}

/// Spawn a pacman invocation and capture its output.
async fn run_pacman(cmd: &[String]) -> Result<PacmanOutput, ExecutorError> {
    let output = tokio::process::Command::new(&cmd[0])
        .args(&cmd[1..])
        .output()
        .await
        .map_err(|e| ExecutorError::TaskFailed(format!("pacman invocation failed: {e}")))?;
    Ok(PacmanOutput {
        stdout: String::from_utf8_lossy(&output.stdout).into_owned(),
        stderr: String::from_utf8_lossy(&output.stderr).into_owned(),
        rc: output.status.code().unwrap_or(-1),
        success: output.status.success(),
    })
}

/// Return the subset of `packages` currently installed, queried via
/// `pacman -Q`. A package is considered installed if its name (or any of its
/// provides) resolves; `pacman -Q <pkg>` exits 0 when found, non-zero
/// otherwise.
async fn query_installed(
    executable: &str,
    packages: &[String],
) -> Result<std::collections::HashSet<String>, ExecutorError> {
    let mut found = std::collections::HashSet::new();
    for pkg in packages {
        let output = tokio::process::Command::new(executable)
            .args(["-Q", pkg])
            .output()
            .await
            .map_err(|e| {
                ExecutorError::TaskFailed(format!("pacman -Q {pkg} failed to spawn: {e}"))
            })?;
        if output.status.success() {
            found.insert(pkg.clone());
        }
    }
    Ok(found)
}

/// Wrap a shell command in a privilege-escalation prefix using the
/// `BecomePlugin` trait implementations from `ansible-plugins`.
///
/// Resolves become settings from (in priority order):
/// 1. Task-level become settings (`become`, `become_user`, `become_method`,
///    `become_flags`, `become_pass`)
/// 2. Host-level variables (`ansible_become_*`)
/// 3. Defaults (method=sudo, user=root, flags per plugin default)
fn wrap_become(
    cmd: &str,
    use_become: bool,
    become_method: Option<&str>,
    become_user: Option<&str>,
    become_flags: Option<&str>,
    become_pass: Option<&str>,
) -> String {
    use ansible_plugins::BecomePlugin;
    use ansible_plugins::r#become::{SudoBecome, SuBecome, DoasBecome};

    if !use_become {
        return cmd.to_string();
    }
    let method = become_method.unwrap_or("sudo");
    let user = become_user.unwrap_or("root");
    let shell = "/bin/sh";

    let plugin: Box<dyn BecomePlugin> = match method {
        "sudo" => Box::new(SudoBecome::new(user, become_pass, become_flags)),
        "su" => Box::new(SuBecome::new(user, become_pass, become_flags)),
        "doas" => Box::new(DoasBecome {
            become_user: user.to_string(),
            become_pass: become_pass.map(|s| s.to_string()),
            become_flags: become_flags.unwrap_or("").to_string(),
        }),
        // Unknown methods fall through so the runtime still behaves
        // predictably in tests that don't have sudo available.
        _ => return cmd.to_string(),
    };

    match plugin.build_become_command(cmd, shell) {
        Ok(wrapped) => wrapped,
        Err(_) => cmd.to_string(),
    }
}

/// Build a connection plugin for a host based on its resolved variables.
///
/// Honors all `ansible_connection`, `ansible_host`, `ansible_port`,
/// `ansible_user`, and the full set of `ansible_ssh_*` variables.
///
/// Remote user precedence (matching upstream Ansible):
/// 1. `cli_user` — the `-u`/`--user` CLI flag (highest)
/// 2. `ansible_user` from host_vars / group_vars / inventory
/// 3. `config_user` — `remote_user` from ansible.cfg
/// 4. `$USER` environment variable (fallback)
fn build_connection(
    host: &str,
    vars: &HashMap<String, AnsibleValue>,
    cli_user: Option<&str>,
    config_user: &str,
) -> Result<Box<dyn ansible_plugins::ConnectionPlugin + Send>, ExecutorError> {
    let explicit_conn = vars
        .get("ansible_connection")
        .and_then(|v| v.as_str())
        .map(|s| s.to_string());
    // Match upstream Ansible: any inventory hostname is an SSH target by
    // default. Only the implicit localhost and explicit ansible_connection
    // overrides use the local plugin.
    let conn_type = explicit_conn.unwrap_or_else(|| {
        if host == "localhost" || host == "127.0.0.1" {
            "local".into()
        } else {
            "ssh".into()
        }
    });

    fn str_var<'a>(vars: &'a HashMap<String, AnsibleValue>, key: &str) -> Option<&'a str> {
        vars.get(key).and_then(|v| v.as_str())
    }

    fn split_args(vars: &HashMap<String, AnsibleValue>, key: &str) -> Vec<String> {
        str_var(vars, key)
            .map(|s| s.split_whitespace().map(|t| t.to_string()).collect())
            .unwrap_or_default()
    }

    match conn_type.as_str() {
        "local" => Ok(Box::new(ansible_connection::local::LocalConnection::new())),
        // The `paramiko` plugin was removed upstream (ansible/ansible PR #86840).
        // Refuse it explicitly so specifying `connection: paramiko` fails fast
        // instead of silently falling through to the unknown-type branch, which
        // would pick the local plugin and run the play on the control node.
        "paramiko" => Err(ExecutorError::TaskFailed(
            "the 'paramiko' connection plugin has been removed; \
             use 'connection: ssh' instead"
                .to_string(),
        )),
        // Upstream ansible/ansible PR #86757 made `connection: persistent` an
        // explicit redirect to `ansible.netcommon.persistent`. The Rust port
        // does not implement the netcommon persistent connection, and silently
        // falling back to local would run the play on the control node — so
        // reject it explicitly.
        "persistent" => Err(ExecutorError::TaskFailed(
            "the 'persistent' connection alias now redirects to \
             ansible.netcommon.persistent, which is not implemented in this \
             port; specify a concrete connection plugin (e.g. 'ssh')"
                .to_string(),
        )),
        "docker" | "podman" => {
            let target = str_var(vars, "ansible_host")
                .map(|s| s.to_string())
                .unwrap_or_else(|| host.to_string());
            let user = cli_user
                .map(|s| s.to_string())
                .or_else(|| str_var(vars, "ansible_user").map(|s| s.to_string()));
            let extra_key = if conn_type == "docker" {
                "ansible_docker_extra_args"
            } else {
                "ansible_podman_extra_args"
            };
            let extra_args = split_args(vars, extra_key);
            if conn_type == "docker" {
                let mut conn = ansible_connection::docker::DockerConnection::new(target);
                conn.user = user;
                conn.extra_args = extra_args;
                Ok(Box::new(conn))
            } else {
                let mut conn = ansible_connection::podman::PodmanConnection::new(target);
                conn.user = user;
                conn.extra_args = extra_args;
                Ok(Box::new(conn))
            }
        }
        "ssh" | "smart" => {
            let target = str_var(vars, "ansible_host")
                .map(|s| s.to_string())
                .unwrap_or_else(|| host.to_string());
            let user = cli_user
                .map(|s| s.to_string())
                .or_else(|| str_var(vars, "ansible_user").map(|s| s.to_string()))
                .unwrap_or_else(|| {
                    if config_user.is_empty() {
                        std::env::var("USER").unwrap_or_else(|_| "root".into())
                    } else {
                        config_user.to_string()
                    }
                });

            let mut conn = ansible_connection::ssh::SshConnection::new(target, user);

            if let Some(p) = vars.get("ansible_port").and_then(|v| v.as_i64()) {
                conn.port = p as u16;
            }
            if let Some(t) = vars.get("ansible_ssh_timeout").and_then(|v| v.as_i64()) {
                conn.timeout = t as u32;
            }
            if let Some(r) = vars.get("ansible_ssh_retries").and_then(|v| v.as_i64()) {
                conn.retries = r as u32;
            }
            if let Some(key) = str_var(vars, "ansible_ssh_private_key_file") {
                conn.private_key_file = Some(std::path::PathBuf::from(key));
            }
            if let Some(pw) = str_var(vars, "ansible_ssh_pass") {
                conn.password = Some(pw.to_string());
            }
            if let Some(exe) = str_var(vars, "ansible_ssh_executable") {
                conn.ssh_executable = std::path::PathBuf::from(exe);
            }
            if let Some(p) = vars.get("ansible_ssh_pipelining") {
                conn.pipelining = match p {
                    AnsibleValue::Bool(b) => *b,
                    AnsibleValue::String(s) => !matches!(s.as_str(), "false" | "False" | "no" | "0"),
                    _ => true,
                };
            }

            conn.ssh_common_args = split_args(vars, "ansible_ssh_common_args");
            conn.ssh_extra_args = split_args(vars, "ansible_ssh_extra_args");
            conn.scp_extra_args = split_args(vars, "ansible_scp_extra_args");
            conn.sftp_extra_args = split_args(vars, "ansible_sftp_extra_args");

            Ok(Box::new(conn))
        }
        other => {
            warn!(
                host = %host,
                connection = %other,
                "unknown ansible_connection value; falling back to local plugin"
            );
            Ok(Box::new(ansible_connection::local::LocalConnection::new()))
        }
    }
}

/// Executes a single task on a single host.
pub struct TaskExecutor {
    host: Arc<str>,
    task: Task,
    variable_manager: Arc<VariableManager>,
    /// Play-level vars (precedence level 12).
    play_vars: HashMap<String, serde_json::Value>,
    /// Block-level vars (precedence level 16), when the task lives
    /// inside a block that defines `vars:`.
    block_vars: Option<HashMap<String, serde_json::Value>>,
    /// Role name, when the task originates from a role — enables
    /// role defaults (level 2) and role vars (level 15) lookups.
    role_name: Option<String>,
    /// Directory containing the playbook being executed (for template src resolution).
    playbook_dir: Option<PathBuf>,
    /// Whether the run-level check mode is enabled (`--check`).
    check_mode: bool,
}

impl TaskExecutor {
    pub fn new(
        host: impl Into<Arc<str>>,
        task: Task,
        variable_manager: Arc<VariableManager>,
    ) -> Self {
        Self {
            host: host.into(),
            task,
            variable_manager,
            play_vars: HashMap::new(),
            block_vars: None,
            role_name: None,
            playbook_dir: None,
            check_mode: false,
        }
    }

    /// Construct a TaskExecutor with full variable context.
    pub fn with_context(
        host: impl Into<Arc<str>>,
        task: Task,
        variable_manager: Arc<VariableManager>,
        play_vars: HashMap<String, serde_json::Value>,
        block_vars: Option<HashMap<String, serde_json::Value>>,
        role_name: Option<String>,
    ) -> Self {
        Self {
            host: host.into(),
            task,
            variable_manager,
            play_vars,
            block_vars,
            role_name,
            playbook_dir: None,
            check_mode: false,
        }
    }

    /// Set the playbook directory for template/copy src resolution.
    pub fn with_playbook_dir(mut self, dir: PathBuf) -> Self {
        self.playbook_dir = Some(dir);
        self
    }

    /// Set the run-level check mode flag.
    pub fn with_check_mode(mut self, check_mode: bool) -> Self {
        self.check_mode = check_mode;
        self
    }

    /// Resolves `task.delegate_to` against the current task vars.
    /// Returns `Ok(None)` when the task has no `delegate_to`. When set,
    /// returns the templated host string and the delegated host's full
    /// var stack (so connection plugins see the delegated host's
    /// `ansible_host`/`ansible_user`/`ansible_port`/`ansible_connection`).
    fn resolve_delegate(
        &self,
        vars: &HashMap<String, AnsibleValue>,
    ) -> Result<Option<(String, HashMap<String, AnsibleValue>)>, ExecutorError> {
        let Some(template) = self.task.delegate_to.as_deref() else {
            return Ok(None);
        };
        let mut templar = Templar::new();
        templar.set_variables(vars.clone());
        let rendered = templar.template_string(template)?;
        let delegated = rendered.trim();
        if delegated.is_empty() {
            return Err(ExecutorError::TaskFailed(
                "delegate_to resolved to an empty host".into(),
            ));
        }
        let delegated_vars = self.variable_manager.get_vars(
            delegated,
            &self.play_vars,
            self.task.vars.as_ref(),
            self.block_vars.as_ref(),
            self.role_name.as_deref(),
        );
        Ok(Some((delegated.to_string(), delegated_vars)))
    }

    /// Build a connection plugin for the current host, applying the
    /// correct remote-user precedence:
    /// CLI `-u` > `ansible_user` from vars > config `remote_user` > `$USER`.
    /// Honors `task.delegate_to`: when set, the connection targets the
    /// delegated host and uses that host's vars.
    fn make_connection(
        &self,
        vars: &HashMap<String, AnsibleValue>,
    ) -> Result<Box<dyn ansible_plugins::ConnectionPlugin + Send>, ExecutorError> {
        if let Some((host, delegated_vars)) = self.resolve_delegate(vars)? {
            return build_connection(
                &host,
                &delegated_vars,
                self.variable_manager.cli_remote_user(),
                self.variable_manager.config_remote_user(),
            );
        }
        build_connection(
            &self.host,
            vars,
            self.variable_manager.cli_remote_user(),
            self.variable_manager.config_remote_user(),
        )
    }

    /// Execute the task and return the result.
    /// Uses `Box::pin` for the future to allow recursive include_role/include_tasks.
    pub fn run(&self) -> std::pin::Pin<Box<dyn std::future::Future<Output = Result<TaskResult, ExecutorError>> + Send + '_>> {
        Box::pin(self.run_inner())
    }

    /// Returns true if this host resolves to a local connection.
    /// Honors `task.delegate_to`: when set, the decision uses the
    /// delegated host's connection vars instead of the inventory host's.
    fn is_local(&self) -> bool {
        let vars = self.variable_manager.get_vars(
            &self.host,
            &self.play_vars,
            self.task.vars.as_ref(),
            self.block_vars.as_ref(),
            self.role_name.as_deref(),
        );
        let (effective_host, effective_vars) = match self.resolve_delegate(&vars) {
            Ok(Some((h, v))) => (h, v),
            _ => (self.host.to_string(), vars),
        };
        let explicit = effective_vars
            .get("ansible_connection")
            .and_then(|v| v.as_str());
        match explicit {
            Some("local") => true,
            Some(_) => false,
            None => effective_host == "localhost" || effective_host == "127.0.0.1",
        }
    }

    /// Build a connected connection plugin for the current host.
    async fn get_connection(&self) -> Result<Box<dyn ansible_plugins::ConnectionPlugin + Send>, ExecutorError> {
        let vars = self.variable_manager.get_vars(
            &self.host,
            &self.play_vars,
            self.task.vars.as_ref(),
            self.block_vars.as_ref(),
            self.role_name.as_deref(),
        );
        let mut conn = self.make_connection(&vars)?;
        conn.connect()
            .await
            .map_err(|e| ExecutorError::TaskFailed(format!("connect: {}", e)))?;
        Ok(conn)
    }

    async fn run_inner(&self) -> Result<TaskResult, ExecutorError> {
        // Build the variable context for this task, merging all 22
        // precedence levels via the VariableManager.
        let task_vars = self.task.vars.as_ref();
        let all_vars = self.variable_manager.get_vars(
            &self.host,
            &self.play_vars,
            task_vars,
            self.block_vars.as_ref(),
            self.role_name.as_deref(),
        );

        // Set up the template engine
        let mut templar = Templar::new();
        templar.set_variables(all_vars.clone());

        // 1. Check conditionals (when:)
        if !self.evaluate_conditionals(&templar)? {
            return Ok(TaskResult::skipped(self.host.clone()));
        }

        // 1b. Resolve effective check mode: per-task override wins.
        let effective_check_mode = match self.task.check_mode {
            Some(true) => true,
            Some(false) => false,
            None => self.check_mode,
        };

        // 2. Handle loops
        if let Some(ref items) = self.task.loop_items {
            return self.run_loop(items, &templar, effective_check_mode).await;
        }
        if let Some(ref items) = self.task.with_items {
            return self.run_loop(items, &templar, effective_check_mode).await;
        }

        // 3. Execute with retry/until semantics.
        //
        // When `until:` is set, the task is retried up to `retries` times
        // with `delay` seconds between attempts until the `until` expression
        // evaluates truthy. The most recent result is bound under the task's
        // `register` name (or an internal placeholder) so `until` can refer
        // to it the same way user expressions would after `register:`.
        let has_until = !self.task.until.is_empty();
        let max_attempts = if has_until {
            self.task.retries.max(1)
        } else {
            1
        };
        let delay_secs = self.task.delay as u64;
        let register_name = self
            .task
            .register
            .clone()
            .unwrap_or_else(|| "__retry_result__".to_string());

        let mut result: TaskResult;
        let mut attempt: u32 = 0;
        loop {
            attempt += 1;

            // Template task arguments against the current variable scope.
            let (module_name, module_args) = match extract_action(&self.task) {
                Some((name, args)) => {
                    let templated_args = templar.template_value(&args).map_err(|e| {
                        ExecutorError::TaskFailed(format!("template error: {}", e))
                    })?;
                    (name, templated_args)
                }
                None => {
                    return Err(ExecutorError::TaskFailed(
                        "task has no action/module defined".into(),
                    ));
                }
            };

            // Execute the module and post-process the result.
            result = self.execute_module(&module_name, &module_args, effective_check_mode).await?;
            result = self.apply_changed_when(result, &templar)?;
            result = self.apply_failed_when(result, &templar)?;
            result.attempts = attempt;

            if !has_until {
                break;
            }

            // Bind this attempt's result under the register name and
            // re-evaluate the `until` expression.
            let reg_value = serde_json::json!({
                "changed": result.changed,
                "failed": result.failed,
                "skipped": result.skipped,
                "unreachable": result.unreachable,
                "msg": result.msg.as_deref().unwrap_or(""),
                "rc": result.results.get("rc").and_then(|v| v.as_i64()).unwrap_or(0),
                "stdout": result.results.get("stdout").and_then(|v| v.as_str()).unwrap_or(""),
                "stderr": result.results.get("stderr").and_then(|v| v.as_str()).unwrap_or(""),
                "attempts": attempt,
                "results": result.results,
            });
            let mut retry_vars = all_vars.clone();
            retry_vars.insert(register_name.clone(), reg_value);
            let mut retry_templar = Templar::new();
            retry_templar.set_variables(retry_vars);

            if self.evaluate_until(&retry_templar)? {
                // Condition met — the task succeeded (clear any transient
                // failure flag so callers treat it as ok).
                result.failed = false;
                break;
            }

            if attempt >= max_attempts {
                // Retries exhausted — mark the task as failed so the
                // strategy stops the host (unless ignore_errors is set).
                result.failed = true;
                result.msg = Some(format!(
                    "Failed after {} attempts: until condition never satisfied",
                    attempt
                ));
                break;
            }

            debug!(
                "[{}] task '{}' attempt {} of {} — until condition not met, retrying in {}s",
                self.host,
                self.task.name.as_deref().unwrap_or("unnamed"),
                attempt,
                max_attempts,
                delay_secs
            );
            if delay_secs > 0 {
                tokio::time::sleep(std::time::Duration::from_secs(delay_secs)).await;
            }
        }

        Ok(result)
    }

    /// Evaluate all `until` conditions — every listed expression must be
    /// truthy for the retry loop to finish.
    fn evaluate_until(&self, templar: &Templar) -> Result<bool, ExecutorError> {
        for cond in &self.task.until {
            match templar.evaluate_conditional(cond) {
                Ok(true) => {}
                Ok(false) => return Ok(false),
                Err(e) => {
                    return Err(ExecutorError::TaskFailed(format!(
                        "until evaluation failed for '{}': {}",
                        cond, e
                    )))
                }
            }
        }
        Ok(true)
    }

    /// Evaluate `when:` conditionals using the template engine.
    fn evaluate_conditionals(&self, templar: &Templar) -> Result<bool, ExecutorError> {
        if self.task.when_conditions.is_empty() {
            return Ok(true);
        }

        for condition in &self.task.when_conditions {
            let result = templar.evaluate_conditional(condition).map_err(|e| {
                ExecutorError::TaskFailed(format!(
                    "conditional evaluation failed for '{}': {}",
                    condition, e
                ))
            })?;

            if !result {
                debug!(
                    "Skipping task '{}' on {} due to when condition: {}",
                    self.task.name.as_deref().unwrap_or("unnamed"),
                    self.host,
                    condition
                );
                return Ok(false);
            }
        }

        Ok(true)
    }

    /// Run a task in a loop over items.
    async fn run_loop(
        &self,
        items: &AnsibleValue,
        templar: &Templar,
        check_mode: bool,
    ) -> Result<TaskResult, ExecutorError> {
        // Template the loop items first
        let templated_items = templar.template_value(items)
            .map_err(|e| ExecutorError::TaskFailed(format!("template error in loop: {}", e)))?;

        let items_vec = match templated_items {
            AnsibleValue::Array(arr) => arr,
            other => vec![other],
        };

        let loop_var = self
            .task
            .loop_control
            .as_ref()
            .and_then(|lc| lc.loop_var.as_deref())
            .unwrap_or("item");

        let index_var = self
            .task
            .loop_control
            .as_ref()
            .and_then(|lc| lc.index_var.as_deref());

        let extended = self
            .task
            .loop_control
            .as_ref()
            .and_then(|lc| lc.extended)
            .unwrap_or(false);

        let mut loop_results = Vec::new();
        let mut any_changed = false;
        let mut any_failed = false;
        let total = items_vec.len();

        for (idx, item) in items_vec.iter().enumerate() {
            // Set up loop variables
            let mut loop_vars = HashMap::new();
            loop_vars.insert(loop_var.to_string(), item.clone());

            if let Some(idx_var) = index_var {
                loop_vars.insert(idx_var.to_string(), AnsibleValue::from(idx as i64));
            }

            if extended {
                let mut loop_info = serde_json::Map::new();
                loop_info.insert("index".into(), AnsibleValue::from(idx as i64));
                loop_info.insert("index0".into(), AnsibleValue::from(idx as i64));
                loop_info.insert("first".into(), AnsibleValue::Bool(idx == 0));
                loop_info.insert("last".into(), AnsibleValue::Bool(idx == total - 1));
                loop_info.insert("length".into(), AnsibleValue::from(total as i64));
                loop_info.insert(
                    "revindex".into(),
                    AnsibleValue::from((total - idx) as i64),
                );
                loop_info.insert(
                    "revindex0".into(),
                    AnsibleValue::from((total - idx - 1) as i64),
                );
                loop_vars.insert(
                    "ansible_loop".to_string(),
                    AnsibleValue::Object(loop_info),
                );
            }

            // Build a new templar with loop variables added
            let mut loop_templar = Templar::new();
            let mut all_vars = self.variable_manager.get_vars(
                &self.host,
                &self.play_vars,
                self.task.vars.as_ref(),
                self.block_vars.as_ref(),
                self.role_name.as_deref(),
            );
            all_vars.extend(loop_vars);
            loop_templar.set_variables(all_vars);

            // Evaluate conditionals for this loop iteration
            if !self.evaluate_conditionals(&loop_templar)? {
                let item_result = serde_json::json!({
                    "changed": false,
                    "failed": false,
                    "skipped": true,
                    "item": item,
                });
                loop_results.push(item_result);
                continue;
            }

            // Execute the module for this item
            let (module_name, module_args) = match extract_action(&self.task) {
                Some((name, args)) => {
                    let templated = loop_templar.template_value(&args)
                        .map_err(|e| ExecutorError::TaskFailed(format!("template error: {}", e)))?;
                    (name, templated)
                }
                None => {
                    return Err(ExecutorError::TaskFailed(
                        "task has no action in loop".into(),
                    ));
                }
            };

            let item_task_result = self.execute_module(&module_name, &module_args, check_mode).await?;

            if item_task_result.changed {
                any_changed = true;
            }
            if item_task_result.failed {
                any_failed = true;
            }

            let item_result = serde_json::json!({
                "changed": item_task_result.changed,
                "failed": item_task_result.failed,
                "skipped": item_task_result.skipped,
                "msg": item_task_result.msg,
                "item": item,
            });
            loop_results.push(item_result);

            // Pause between loop iterations if configured
            if let Some(ref lc) = self.task.loop_control {
                if let Some(pause) = lc.pause {
                    if pause > 0.0 {
                        tokio::time::sleep(std::time::Duration::from_secs_f64(pause)).await;
                    }
                }
            }
        }

        let mut result = TaskResult::ok(self.host.clone());
        result.changed = any_changed;
        result.failed = any_failed;
        result.results = serde_json::json!(loop_results);
        Ok(result)
    }

    /// Execute a module/action and return the result.
    /// Modules that support check mode — they can run in dry-run and still
    /// report meaningful changed/unchanged status without side effects.
    const CHECK_MODE_MODULES: &[&str] = &[
        "debug",
        "set_fact",
        "assert",
        "fail",
        "meta",
        "stat",
        "ping",
        "slurp",
        "setup",
        "gather_facts",
        "template",
        "copy",
        "file",
        "include_role",
        "import_role",
        "include_tasks",
        "import_tasks",
        "apt_repository",
        "yum_repository",
    ];

    async fn execute_module(
        &self,
        module_name: &str,
        module_args: &AnsibleValue,
        check_mode: bool,
    ) -> Result<TaskResult, ExecutorError> {
        // In check mode, skip modules that don't support it.
        if check_mode && !Self::CHECK_MODE_MODULES.contains(&module_name) {
            debug!(
                "[{}] skipping '{}': check mode not supported",
                self.host, module_name
            );
            let mut result = TaskResult::skipped(self.host.clone());
            result.msg = Some(format!(
                "check mode not supported for module '{}'",
                module_name
            ));
            return Ok(result);
        }

        // Built-in modules that can be handled natively
        match module_name {
            "debug" => self.module_debug(module_args),
            "set_fact" => self.module_set_fact(module_args),
            "assert" => self.module_assert(module_args),
            "fail" => self.module_fail(module_args),
            "meta" => self.module_meta(module_args),
            "command" | "shell" | "raw" => {
                self.module_command(module_name, module_args).await
            }
            "file" => self.module_file(module_args, check_mode).await,
            "copy" => self.module_copy(module_args).await,
            "stat" => self.module_stat(module_args).await,
            "template" => self.module_template(module_args).await,
            "lineinfile" => self.module_lineinfile(module_args),
            "blockinfile" => self.module_blockinfile(module_args),
            "replace" => self.module_replace(module_args),
            #[cfg(feature = "http")]
            "uri" => self.module_uri(module_args).await,
            #[cfg(feature = "http")]
            "get_url" => self.module_get_url(module_args).await,
            "wait_for_connection" => self.module_wait_for_connection(module_args).await,
            "ping" => self.module_ping(module_args).await,
            "slurp" => self.module_slurp(module_args).await,
            "setup" | "gather_facts" => self.module_setup(module_args).await,
            "include_role" | "import_role" => {
                self.module_include_role(module_name, module_args).await
            }
            "include_tasks" | "import_tasks" => {
                self.module_include_tasks(module_name, module_args).await
            }
            "apt" => self.module_apt(module_args).await,
            "apt_repository" => self.module_apt_repository(module_args, check_mode).await,
            "yum" | "dnf" => self.module_yum(module_args).await,
            "yum_repository" => self.module_yum_repository(module_args, check_mode).await,
            "pacman" => self.module_pacman(module_args).await,
            "git" => self.module_git(module_args).await,
            "service" => self.module_service(module_args).await,
            "systemd" | "systemd_service" => self.module_systemd(module_args).await,
            "user" => self.module_user(module_args).await,
            "group" => self.module_group(module_args).await,
            "package_facts" => self.module_package_facts(module_args).await,
            _ => self.module_ansiballz_fallback(module_name, module_args).await,
        }
    }

    /// Implement the `debug` module natively.
    fn module_debug(&self, args: &AnsibleValue) -> Result<TaskResult, ExecutorError> {
        let mut result = TaskResult::ok(self.host.clone());

        if let Some(msg) = args.get("msg").and_then(|v| v.as_str()) {
            result.msg = Some(msg.to_string());
        } else if let Some(var) = args.get("var").and_then(|v| v.as_str()) {
            // Look up the variable
            let all_vars = self.variable_manager.get_vars(
                &self.host,
                &self.play_vars,
                None,
                self.block_vars.as_ref(),
                self.role_name.as_deref(),
            );
            let val = all_vars
                .get(var)
                .map(|v| format!("{}: {}", var, v))
                .unwrap_or_else(|| format!("{}: VARIABLE IS NOT DEFINED!", var));
            result.msg = Some(val);
        } else {
            result.msg = Some("Hello world!".to_string());
        }

        Ok(result)
    }

    /// Implement the `set_fact` module natively.
    fn module_set_fact(&self, args: &AnsibleValue) -> Result<TaskResult, ExecutorError> {
        let mut result = TaskResult::ok(self.host.clone());
        // set_fact sets variables on the host — the actual variable setting
        // would be done by the strategy/caller after receiving the result
        if let Some(obj) = args.as_object() {
            let mut ansible_facts = serde_json::Map::new();
            for (k, v) in obj {
                if k != "cacheable" {
                    ansible_facts.insert(k.clone(), v.clone());
                }
            }
            result.results = serde_json::json!({"ansible_facts": ansible_facts});
        }
        Ok(result)
    }

    /// Implement the `assert` module natively.
    fn module_assert(&self, args: &AnsibleValue) -> Result<TaskResult, ExecutorError> {
        let mut result = TaskResult::ok(self.host.clone());

        let conditions = match args.get("that") {
            Some(AnsibleValue::Array(arr)) => arr
                .iter()
                .filter_map(|v| v.as_str().map(|s| s.to_string()))
                .collect::<Vec<_>>(),
            Some(AnsibleValue::String(s)) => vec![s.clone()],
            _ => {
                result.failed = true;
                result.msg = Some("assert requires 'that' parameter".into());
                return Ok(result);
            }
        };

        let all_vars = self.variable_manager.get_vars(
            &self.host,
            &self.play_vars,
            self.task.vars.as_ref(),
            self.block_vars.as_ref(),
            self.role_name.as_deref(),
        );
        let mut templar = Templar::new();
        templar.set_variables(all_vars);

        for condition in &conditions {
            match templar.evaluate_conditional(condition) {
                Ok(true) => {}
                Ok(false) => {
                    result.failed = true;
                    let fail_msg = args
                        .get("fail_msg")
                        .or_else(|| args.get("msg"))
                        .and_then(|v| v.as_str())
                        .unwrap_or("Assertion failed");
                    result.msg = Some(fail_msg.to_string());
                    return Ok(result);
                }
                Err(e) => {
                    result.failed = true;
                    result.msg = Some(format!("Assertion evaluation failed: {}", e));
                    return Ok(result);
                }
            }
        }

        let success_msg = args
            .get("success_msg")
            .and_then(|v| v.as_str())
            .unwrap_or("All assertions passed");
        result.msg = Some(success_msg.to_string());
        Ok(result)
    }

    /// Implement the `fail` module natively.
    fn module_fail(&self, args: &AnsibleValue) -> Result<TaskResult, ExecutorError> {
        let mut result = TaskResult::ok(self.host.clone());
        result.failed = true;
        result.msg = Some(
            args.get("msg")
                .and_then(|v| v.as_str())
                .unwrap_or("Failed as requested from task")
                .to_string(),
        );
        Ok(result)
    }

    /// Implement the `command`/`shell`/`raw` modules via the local connection.
    async fn module_command(
        &self,
        module_name: &str,
        args: &AnsibleValue,
    ) -> Result<TaskResult, ExecutorError> {
        // Extract the command line. Accept either a string ("free form")
        // or an object with a "cmd"/"_raw_params" key.
        let cmd_str: String = match args {
            AnsibleValue::String(s) => s.clone(),
            AnsibleValue::Object(_) => args
                .get("cmd")
                .or_else(|| args.get("_raw_params"))
                .and_then(|v| v.as_str())
                .map(|s| s.to_string())
                .unwrap_or_default(),
            _ => String::new(),
        };

        if cmd_str.trim().is_empty() {
            let mut result = TaskResult::ok(self.host.clone());
            result.failed = true;
            result.msg = Some(format!("{} requires a command", module_name));
            return Ok(result);
        }

        // For `command`, we should not invoke a shell — but for now we
        // route everything through the local connection which uses /bin/sh.
        // `chdir` support:
        let chdired = if let Some(chdir) = args.get("chdir").and_then(|v| v.as_str()) {
            format!("cd {} && {}", shell_escape(chdir), cmd_str)
        } else {
            cmd_str.clone()
        };
        // Resolve vars to pick connection and become settings.
        let all_vars = self.variable_manager.get_vars(
            &self.host,
            &self.play_vars,
            self.task.vars.as_ref(),
            self.block_vars.as_ref(),
            self.role_name.as_deref(),
        );

        // Apply become wrapping. Task-level settings override host vars.
        let use_become = self.task.use_become.unwrap_or_else(|| {
            all_vars.get("ansible_become")
                .and_then(|v| match v {
                    AnsibleValue::Bool(b) => Some(*b),
                    AnsibleValue::String(s) => Some(!matches!(s.as_str(), "false" | "False" | "no" | "0")),
                    _ => None,
                })
                .unwrap_or(false)
        });
        let become_method = self.task.become_method.as_deref()
            .or_else(|| all_vars.get("ansible_become_method").and_then(|v| v.as_str()));
        let become_user = self.task.become_user.as_deref()
            .or_else(|| all_vars.get("ansible_become_user").and_then(|v| v.as_str()));
        let become_flags = self.task.become_flags.as_deref()
            .or_else(|| all_vars.get("ansible_become_flags").and_then(|v| v.as_str()));
        let become_pass = self.task.become_pass.as_deref()
            .or_else(|| all_vars.get("ansible_become_pass").and_then(|v| v.as_str()));
        let final_cmd = wrap_become(
            &chdired,
            use_become,
            become_method,
            become_user,
            become_flags,
            become_pass,
        );

        let mut conn = self.make_connection(&all_vars)?;
        conn.connect()
            .await
            .map_err(|e| ExecutorError::TaskFailed(format!("connect: {}", e)))?;
        let (rc, stdout, stderr) = conn
            .exec_command(&final_cmd, None)
            .await
            .map_err(|e| ExecutorError::TaskFailed(format!("exec: {}", e)))?;

        let stdout_s = String::from_utf8_lossy(&stdout).into_owned();
        let stderr_s = String::from_utf8_lossy(&stderr).into_owned();

        let mut result = TaskResult::ok(self.host.clone());
        result.changed = rc == 0; // commands are always "changed" if they succeed
        result.failed = rc != 0;
        if result.failed {
            result.msg = Some(format!("non-zero return code: {}", rc));
        }
        result.results = serde_json::json!({
            "rc": rc,
            "stdout": stdout_s,
            "stdout_lines": stdout_s.lines().collect::<Vec<_>>(),
            "stderr": stderr_s,
            "stderr_lines": stderr_s.lines().collect::<Vec<_>>(),
            "cmd": cmd_str,
        });
        Ok(result)
    }

    /// Native `file` module: create/touch/remove paths and dirs.
    /// Works both locally and remotely via the connection plugin.
    async fn module_file(&self, args: &AnsibleValue, check_mode: bool) -> Result<TaskResult, ExecutorError> {
        let mut result = TaskResult::ok(self.host.clone());
        let path_s = match args.get("path").or_else(|| args.get("dest")).and_then(|v| v.as_str()) {
            Some(p) => p.to_string(),
            None => {
                result.failed = true;
                result.msg = Some("file: 'path' is required".into());
                return Ok(result);
            }
        };
        let state = args
            .get("state")
            .and_then(|v| v.as_str())
            .unwrap_or("file")
            .to_string();

        if self.is_local() {
            return self.module_file_local(&path_s, &state, check_mode);
        }

        // Remote: use exec_command for file operations
        let conn = self.get_connection().await?;
        let escaped = shell_escape(&path_s);

        if check_mode {
            // In check mode, probe existence to report what would change.
            let (rc, _, _) = conn
                .exec_command(&format!("test -e {escaped}"), None)
                .await
                .map_err(|e| ExecutorError::TaskFailed(format!("file: {}", e)))?;
            let exists = rc == 0;
            match state.as_str() {
                "absent" => {
                    if exists {
                        result.changed = true;
                    }
                }
                "directory" => {
                    if !exists {
                        result.changed = true;
                    }
                }
                "touch" => {
                    if !exists {
                        result.changed = true;
                    }
                }
                "file" => {
                    if !exists {
                        result.failed = true;
                        result.msg = Some(format!("file: {} does not exist", path_s));
                    }
                }
                other => {
                    result.failed = true;
                    result.msg = Some(format!("file: unsupported state '{}'", other));
                    return Ok(result);
                }
            }
        } else {
            match state.as_str() {
                "absent" => {
                    let (rc, _, stderr) = conn
                        .exec_command(&format!("rm -rf {escaped}"), None)
                        .await
                        .map_err(|e| ExecutorError::TaskFailed(format!("file: {}", e)))?;
                    if rc != 0 {
                        result.failed = true;
                        result.msg = Some(format!("file: remove failed: {}", String::from_utf8_lossy(&stderr)));
                        return Ok(result);
                    }
                    result.changed = true;
                }
                "directory" => {
                    let (rc, _, stderr) = conn
                        .exec_command(&format!("mkdir -p {escaped}"), None)
                        .await
                        .map_err(|e| ExecutorError::TaskFailed(format!("file: {}", e)))?;
                    if rc != 0 {
                        result.failed = true;
                        result.msg = Some(format!("file: mkdir failed: {}", String::from_utf8_lossy(&stderr)));
                        return Ok(result);
                    }
                    result.changed = true;
                }
                "touch" => {
                    let (rc, _, stderr) = conn
                        .exec_command(&format!("touch {escaped}"), None)
                        .await
                        .map_err(|e| ExecutorError::TaskFailed(format!("file: {}", e)))?;
                    if rc != 0 {
                        result.failed = true;
                        result.msg = Some(format!("file: touch failed: {}", String::from_utf8_lossy(&stderr)));
                        return Ok(result);
                    }
                    result.changed = true;
                }
                "file" => {
                    let (rc, _, _) = conn
                        .exec_command(&format!("test -e {escaped}"), None)
                        .await
                        .map_err(|e| ExecutorError::TaskFailed(format!("file: {}", e)))?;
                    if rc != 0 {
                        result.failed = true;
                        result.msg = Some(format!("file: {} does not exist", path_s));
                        return Ok(result);
                    }
                }
                other => {
                    result.failed = true;
                    result.msg = Some(format!("file: unsupported state '{}'", other));
                    return Ok(result);
                }
            }
        }

        result.results = serde_json::json!({"path": path_s, "state": state});
        Ok(result)
    }

    /// Local-only file module implementation.
    fn module_file_local(&self, path_s: &str, state: &str, check_mode: bool) -> Result<TaskResult, ExecutorError> {
        use std::path::Path;
        let mut result = TaskResult::ok(self.host.clone());
        let path = Path::new(path_s);
        let exists = path.exists();

        match state {
            "absent" => {
                if exists {
                    if check_mode {
                        result.changed = true;
                    } else {
                        let res = if path.is_dir() {
                            std::fs::remove_dir_all(path)
                        } else {
                            std::fs::remove_file(path)
                        };
                        if let Err(e) = res {
                            result.failed = true;
                            result.msg = Some(format!("file: remove failed: {}", e));
                            return Ok(result);
                        }
                        result.changed = true;
                    }
                }
            }
            "directory" => {
                if !exists {
                    if check_mode {
                        result.changed = true;
                    } else if let Err(e) = std::fs::create_dir_all(path) {
                        result.failed = true;
                        result.msg = Some(format!("file: mkdir failed: {}", e));
                        return Ok(result);
                    } else {
                        result.changed = true;
                    }
                } else if !path.is_dir() {
                    result.failed = true;
                    result.msg = Some(format!("file: {} exists and is not a directory", path_s));
                    return Ok(result);
                }
            }
            "touch" => {
                if !exists {
                    if check_mode {
                        result.changed = true;
                    } else if let Err(e) = std::fs::File::create(path) {
                        result.failed = true;
                        result.msg = Some(format!("file: touch failed: {}", e));
                        return Ok(result);
                    }
                    result.changed = true;
                } else {
                    result.changed = true;
                }
            }
            "file" => {
                if !exists {
                    result.failed = true;
                    result.msg = Some(format!("file: {} does not exist", path_s));
                    return Ok(result);
                }
            }
            other => {
                result.failed = true;
                result.msg = Some(format!("file: unsupported state '{}'", other));
                return Ok(result);
            }
        }

        result.results = serde_json::json!({"path": path_s, "state": state});
        Ok(result)
    }

    /// Native `copy` module: write `content` or copy `src` to `dest`.
    /// For remote hosts, writes content to a local temp file and uses put_file.
    async fn module_copy(&self, args: &AnsibleValue) -> Result<TaskResult, ExecutorError> {
        use std::path::Path;
        let mut result = TaskResult::ok(self.host.clone());
        let dest = match args.get("dest").and_then(|v| v.as_str()) {
            Some(d) => d.to_string(),
            None => {
                result.failed = true;
                result.msg = Some("copy: 'dest' is required".into());
                return Ok(result);
            }
        };

        let new_bytes: Vec<u8> = if let Some(content) = args.get("content").and_then(|v| v.as_str()) {
            content.as_bytes().to_vec()
        } else if let Some(src) = args.get("src").and_then(|v| v.as_str()) {
            match std::fs::read(src) {
                Ok(b) => b,
                Err(e) => {
                    result.failed = true;
                    result.msg = Some(format!("copy: read src failed: {}", e));
                    return Ok(result);
                }
            }
        } else {
            result.failed = true;
            result.msg = Some("copy: requires 'content' or 'src'".into());
            return Ok(result);
        };

        if self.is_local() {
            // Local path
            let dest_path = Path::new(&dest);
            let changed = match std::fs::read(dest_path) {
                Ok(existing) => existing != new_bytes,
                Err(_) => true,
            };
            if changed {
                if let Some(parent) = dest_path.parent() {
                    let _ = std::fs::create_dir_all(parent);
                }
                if let Err(e) = std::fs::write(dest_path, &new_bytes) {
                    result.failed = true;
                    result.msg = Some(format!("copy: write failed: {}", e));
                    return Ok(result);
                }
            }
            result.changed = changed;
        } else {
            // Remote path: write to temp file, put_file to remote
            let conn = self.get_connection().await?;

            let mut tmp = tempfile::NamedTempFile::new()
                .map_err(|e| ExecutorError::TaskFailed(format!("copy: tempfile: {}", e)))?;
            use std::io::Write;
            tmp.write_all(&new_bytes)
                .map_err(|e| ExecutorError::TaskFailed(format!("copy: write tmp: {}", e)))?;
            tmp.flush()
                .map_err(|e| ExecutorError::TaskFailed(format!("copy: flush tmp: {}", e)))?;

            let dest_path = Path::new(&dest);
            conn.put_file(tmp.path(), dest_path)
                .await
                .map_err(|e| ExecutorError::TaskFailed(format!("copy: put_file: {}", e)))?;

            result.changed = true;
        }

        result.results = serde_json::json!({
            "dest": dest,
            "size": new_bytes.len(),
        });
        Ok(result)
    }

    /// Native `stat` module: return file metadata matching ansible.builtin.stat output.
    /// For remote hosts, runs `stat` and `test` commands via the connection.
    async fn module_stat(&self, args: &AnsibleValue) -> Result<TaskResult, ExecutorError> {
        let mut result = TaskResult::ok(self.host.clone());
        let path_s = match args.get("path").and_then(|v| v.as_str()) {
            Some(p) => p.to_string(),
            None => {
                result.failed = true;
                result.msg = Some("stat: 'path' is required".into());
                return Ok(result);
            }
        };

        if self.is_local() {
            return self.module_stat_local(&path_s, args);
        }

        // Remote stat via shell commands
        let conn = self.get_connection().await?;
        let escaped = shell_escape(&path_s);

        // Check existence and get basic stat info via a single command
        let stat_cmd = format!(
            "if [ -e {escaped} ]; then stat -c '%F|%s|%a|%u|%g|%i|%h|%X|%Y|%Z' {escaped} 2>/dev/null || echo NOSTAT; else echo NOTFOUND; fi"
        );
        let (rc, stdout, _) = conn
            .exec_command(&stat_cmd, None)
            .await
            .map_err(|e| ExecutorError::TaskFailed(format!("stat: {}", e)))?;

        let out = String::from_utf8_lossy(&stdout).trim().to_string();
        let mut stat = serde_json::Map::new();
        stat.insert("path".into(), serde_json::json!(path_s));

        if rc != 0 || out == "NOTFOUND" {
            stat.insert("exists".into(), serde_json::Value::Bool(false));
        } else if out == "NOSTAT" {
            // stat command not available in expected format — basic fallback
            stat.insert("exists".into(), serde_json::Value::Bool(true));
        } else {
            stat.insert("exists".into(), serde_json::Value::Bool(true));
            let parts: Vec<&str> = out.split('|').collect();
            if parts.len() >= 10 {
                let file_type = parts[0];
                stat.insert("isdir".into(), serde_json::Value::Bool(file_type.contains("directory")));
                stat.insert("isreg".into(), serde_json::Value::Bool(file_type.contains("regular")));
                stat.insert("islnk".into(), serde_json::Value::Bool(file_type.contains("symbolic link")));
                if let Ok(size) = parts[1].parse::<u64>() {
                    stat.insert("size".into(), serde_json::json!(size));
                }
                stat.insert("mode".into(), serde_json::json!(parts[2]));
                if let Ok(uid) = parts[3].parse::<u64>() {
                    stat.insert("uid".into(), serde_json::json!(uid));
                }
                if let Ok(gid) = parts[4].parse::<u64>() {
                    stat.insert("gid".into(), serde_json::json!(gid));
                }
                if let Ok(ino) = parts[5].parse::<u64>() {
                    stat.insert("inode".into(), serde_json::json!(ino));
                }
                if let Ok(nlink) = parts[6].parse::<u64>() {
                    stat.insert("nlink".into(), serde_json::json!(nlink));
                }
                if let Ok(atime) = parts[7].parse::<f64>() {
                    stat.insert("atime".into(), serde_json::json!(atime));
                }
                if let Ok(mtime) = parts[8].parse::<f64>() {
                    stat.insert("mtime".into(), serde_json::json!(mtime));
                }
                if let Ok(ctime) = parts[9].parse::<f64>() {
                    stat.insert("ctime".into(), serde_json::json!(ctime));
                }
            }
        }

        result.results = serde_json::json!({"stat": stat});
        Ok(result)
    }

    /// Local-only stat implementation with full filesystem metadata.
    fn module_stat_local(&self, path_s: &str, args: &AnsibleValue) -> Result<TaskResult, ExecutorError> {
        use std::path::Path;
        let mut result = TaskResult::ok(self.host.clone());
        let path = Path::new(path_s);
        let exists = path.exists();
        let mut stat = serde_json::Map::new();
        stat.insert("exists".into(), serde_json::Value::Bool(exists));
        stat.insert("path".into(), serde_json::json!(path_s));

        if exists {
            let follow = args.get("follow").and_then(|v| v.as_bool()).unwrap_or(true);
            let md_result = if follow {
                std::fs::metadata(path)
            } else {
                std::fs::symlink_metadata(path)
            };

            if let Ok(md) = md_result {
                stat.insert("isdir".into(), serde_json::Value::Bool(md.is_dir()));
                stat.insert("isreg".into(), serde_json::Value::Bool(md.is_file()));
                stat.insert("islnk".into(), serde_json::Value::Bool(md.file_type().is_symlink()));
                stat.insert("size".into(), serde_json::json!(md.len()));

                #[cfg(unix)]
                {
                    use std::os::unix::fs::MetadataExt;
                    stat.insert("mode".into(), serde_json::json!(format!("{:04o}", md.mode() & 0o7777)));
                    stat.insert("uid".into(), serde_json::json!(md.uid()));
                    stat.insert("gid".into(), serde_json::json!(md.gid()));
                    stat.insert("inode".into(), serde_json::json!(md.ino()));
                    stat.insert("dev".into(), serde_json::json!(md.dev()));
                    stat.insert("nlink".into(), serde_json::json!(md.nlink()));
                    stat.insert("atime".into(), serde_json::json!(md.atime() as f64));
                    stat.insert("mtime".into(), serde_json::json!(md.mtime() as f64));
                    stat.insert("ctime".into(), serde_json::json!(md.ctime() as f64));

                    use std::os::unix::fs::FileTypeExt;
                    let ft = md.file_type();
                    stat.insert("isblk".into(), serde_json::Value::Bool(ft.is_block_device()));
                    stat.insert("ischr".into(), serde_json::Value::Bool(ft.is_char_device()));
                    stat.insert("isfifo".into(), serde_json::Value::Bool(ft.is_fifo()));
                    stat.insert("issock".into(), serde_json::Value::Bool(ft.is_socket()));
                }

                if md.file_type().is_symlink() {
                    if let Ok(target) = std::fs::read_link(path) {
                        stat.insert("lnk_source".into(), serde_json::json!(target.display().to_string()));
                        stat.insert("lnk_target".into(), serde_json::json!(target.display().to_string()));
                    }
                }

                let get_checksum = args.get("get_checksum").and_then(|v| v.as_bool()).unwrap_or(true);
                if md.is_file() && get_checksum {
                    if let Ok(bytes) = std::fs::read(path) {
                        use sha2::{Sha256, Digest};
                        let hash = Sha256::digest(&bytes);
                        stat.insert("checksum".into(), serde_json::json!(format!("{:x}", hash)));
                        stat.insert("checksum_algorithm".into(), serde_json::json!("sha256"));
                    }
                }

                stat.insert("readable".into(), serde_json::Value::Bool(
                    std::fs::File::open(path).is_ok()
                ));
                stat.insert("writeable".into(), serde_json::Value::Bool(
                    std::fs::OpenOptions::new().write(true).open(path).is_ok()
                ));
            }
        }
        result.results = serde_json::json!({"stat": stat});
        Ok(result)
    }

    /// Resolve a template `src` path using the upstream Ansible search order:
    /// 1. `<role>/templates/<src>` (when inside a role)
    /// 2. `<playbook_dir>/templates/<src>`
    /// 3. `<playbook_dir>/<src>`
    /// 4. absolute path (as-is)
    fn resolve_template_src(&self, src: &str) -> Result<PathBuf, Vec<PathBuf>> {
        let src_path = Path::new(src);

        // Absolute paths are used as-is
        if src_path.is_absolute() {
            if src_path.exists() {
                return Ok(src_path.to_path_buf());
            }
            return Err(vec![src_path.to_path_buf()]);
        }

        let mut searched = Vec::new();

        // 1. Role templates directory
        if let Some(role) = &self.role_name {
            let candidate = PathBuf::from(format!("roles/{}/templates/{}", role, src));
            if candidate.exists() {
                return Ok(candidate);
            }
            searched.push(candidate);
        }

        // 2-3. Playbook-dir relative paths
        let base = self.playbook_dir.as_deref().unwrap_or_else(|| {
            // Fall back to cwd when playbook_dir isn't set (e.g. unit tests)
            Path::new(".")
        });

        let candidate = base.join(format!("templates/{}", src));
        if candidate.exists() {
            return Ok(candidate);
        }
        searched.push(candidate);

        let candidate = base.join(src);
        if candidate.exists() {
            return Ok(candidate);
        }
        searched.push(candidate);

        Err(searched)
    }

    /// Native `template` module: render a Jinja2 template src to dest.
    /// Template source is always read locally; for remote hosts the rendered
    /// content is put_file'd to the remote dest.
    async fn module_template(&self, args: &AnsibleValue) -> Result<TaskResult, ExecutorError> {
        let mut result = TaskResult::ok(self.host.clone());
        let src = match args.get("src").and_then(|v| v.as_str()) {
            Some(s) => s.to_string(),
            None => {
                result.failed = true;
                result.msg = Some("template: 'src' is required".into());
                return Ok(result);
            }
        };
        let dest = match args.get("dest").and_then(|v| v.as_str()) {
            Some(d) => d.to_string(),
            None => {
                result.failed = true;
                result.msg = Some("template: 'dest' is required".into());
                return Ok(result);
            }
        };

        // Resolve the template source path on the controller
        let resolved_src = match self.resolve_template_src(&src) {
            Ok(p) => p,
            Err(searched) => {
                result.failed = true;
                let paths: Vec<String> = searched
                    .iter()
                    .map(|p| format!("  - {}", p.display()))
                    .collect();
                result.msg = Some(format!(
                    "template: src '{}' not found. Searched:\n{}",
                    src,
                    paths.join("\n")
                ));
                return Ok(result);
            }
        };

        let src_text = match std::fs::read_to_string(&resolved_src) {
            Ok(s) => s,
            Err(e) => {
                result.failed = true;
                result.msg = Some(format!(
                    "template: read src '{}' failed: {}",
                    resolved_src.display(),
                    e
                ));
                return Ok(result);
            }
        };

        let all_vars = self.variable_manager.get_vars(
            &self.host,
            &self.play_vars,
            self.task.vars.as_ref(),
            self.block_vars.as_ref(),
            self.role_name.as_deref(),
        );
        let mut templar = Templar::new();
        templar.set_variables(all_vars);
        let rendered = match templar.template_string(&src_text) {
            Ok(s) => s,
            Err(e) => {
                result.failed = true;
                result.msg = Some(format!("template: render failed: {}", e));
                return Ok(result);
            }
        };

        if self.is_local() {
            let dest_path = Path::new(&dest);
            let changed = match std::fs::read_to_string(dest_path) {
                Ok(existing) => existing != rendered,
                Err(_) => true,
            };
            if changed {
                if let Some(parent) = dest_path.parent() {
                    let _ = std::fs::create_dir_all(parent);
                }
                if let Err(e) = std::fs::write(dest_path, rendered.as_bytes()) {
                    result.failed = true;
                    result.msg = Some(format!("template: write failed: {}", e));
                    return Ok(result);
                }
            }
            result.changed = changed;
        } else {
            // Remote: write rendered content to temp, put_file to remote
            let conn = self.get_connection().await?;

            let mut tmp = tempfile::NamedTempFile::new()
                .map_err(|e| ExecutorError::TaskFailed(format!("template: tempfile: {}", e)))?;
            use std::io::Write;
            tmp.write_all(rendered.as_bytes())
                .map_err(|e| ExecutorError::TaskFailed(format!("template: write tmp: {}", e)))?;
            tmp.flush()
                .map_err(|e| ExecutorError::TaskFailed(format!("template: flush: {}", e)))?;

            conn.put_file(tmp.path(), Path::new(&dest))
                .await
                .map_err(|e| ExecutorError::TaskFailed(format!("template: put_file: {}", e)))?;

            result.changed = true;
        }

        result.results = serde_json::json!({"src": src, "dest": dest, "size": rendered.len()});
        Ok(result)
    }

    /// Native `lineinfile` module: ensure a line is present/absent in a file.
    fn module_lineinfile(&self, args: &AnsibleValue) -> Result<TaskResult, ExecutorError> {
        use std::path::Path;
        let mut result = TaskResult::ok(self.host.clone());
        let path_s = match args
            .get("path")
            .or_else(|| args.get("dest"))
            .and_then(|v| v.as_str())
        {
            Some(p) => p.to_string(),
            None => {
                result.failed = true;
                result.msg = Some("lineinfile: 'path' is required".into());
                return Ok(result);
            }
        };
        let state = args.get("state").and_then(|v| v.as_str()).unwrap_or("present").to_string();
        let line = args.get("line").and_then(|v| v.as_str()).map(|s| s.to_string());
        let regexp_s = args.get("regexp").and_then(|v| v.as_str()).map(|s| s.to_string());
        let create = args.get("create").and_then(|v| v.as_bool()).unwrap_or(false);

        let path = Path::new(&path_s);
        let original = match std::fs::read_to_string(path) {
            Ok(s) => s,
            Err(_) if create && state == "present" => String::new(),
            Err(e) => {
                result.failed = true;
                result.msg = Some(format!("lineinfile: read failed: {}", e));
                return Ok(result);
            }
        };

        // Compile regexp once if provided.
        let re = match regexp_s.as_deref() {
            Some(p) => match regex_lite::Regex::new(p) {
                Ok(r) => Some(r),
                Err(e) => {
                    result.failed = true;
                    result.msg = Some(format!("lineinfile: bad regexp: {}", e));
                    return Ok(result);
                }
            },
            None => None,
        };

        let mut lines: Vec<String> = if original.is_empty() {
            Vec::new()
        } else {
            original.lines().map(|s| s.to_string()).collect()
        };

        let mut changed = false;
        match state.as_str() {
            "present" => {
                let new_line = match &line {
                    Some(l) => l.clone(),
                    None => {
                        result.failed = true;
                        result.msg = Some("lineinfile: 'line' required for state=present".into());
                        return Ok(result);
                    }
                };
                let mut replaced = false;
                if let Some(re) = &re {
                    for l in lines.iter_mut() {
                        if re.is_match(l) {
                            if *l != new_line {
                                *l = new_line.clone();
                                changed = true;
                            }
                            replaced = true;
                            // Replace only the last match per ansible semantics
                        }
                    }
                }
                if !replaced && !lines.iter().any(|l| l == &new_line) {
                    lines.push(new_line);
                    changed = true;
                }
            }
            "absent" => {
                let before = lines.len();
                if let Some(re) = &re {
                    lines.retain(|l| !re.is_match(l));
                } else if let Some(l) = &line {
                    lines.retain(|x| x != l);
                }
                if lines.len() != before {
                    changed = true;
                }
            }
            other => {
                result.failed = true;
                result.msg = Some(format!("lineinfile: unsupported state '{}'", other));
                return Ok(result);
            }
        }

        if changed {
            let mut new_text = lines.join("\n");
            if !new_text.is_empty() {
                new_text.push('\n');
            }
            if let Some(parent) = path.parent() {
                let _ = std::fs::create_dir_all(parent);
            }
            if let Err(e) = std::fs::write(path, new_text.as_bytes()) {
                result.failed = true;
                result.msg = Some(format!("lineinfile: write failed: {}", e));
                return Ok(result);
            }
        }
        result.changed = changed;
        result.results = serde_json::json!({"path": path_s, "state": state});
        Ok(result)
    }

    /// Implement the `blockinfile` module natively.
    ///
    /// Manages a delimited block of text within a file. The block is
    /// identified by marker lines (default: `# BEGIN ANSIBLE MANAGED BLOCK`
    /// / `# END ANSIBLE MANAGED BLOCK`) and the content between them is
    /// replaced atomically.
    fn module_blockinfile(&self, args: &AnsibleValue) -> Result<TaskResult, ExecutorError> {
        use std::path::Path;
        let mut result = TaskResult::ok(self.host.clone());

        let path_s = match args
            .get("path")
            .or_else(|| args.get("dest"))
            .and_then(|v| v.as_str())
        {
            Some(p) => p.to_string(),
            None => {
                result.failed = true;
                result.msg = Some("blockinfile: 'path' is required".into());
                return Ok(result);
            }
        };
        let state = args
            .get("state")
            .and_then(|v| v.as_str())
            .unwrap_or("present");
        let block = args
            .get("block")
            .or_else(|| args.get("content"))
            .and_then(|v| v.as_str())
            .unwrap_or("");
        let marker = args
            .get("marker")
            .and_then(|v| v.as_str())
            .unwrap_or("# {mark} ANSIBLE MANAGED BLOCK");
        let marker_begin = args
            .get("marker_begin")
            .and_then(|v| v.as_str())
            .unwrap_or("BEGIN");
        let marker_end = args
            .get("marker_end")
            .and_then(|v| v.as_str())
            .unwrap_or("END");
        let create = args
            .get("create")
            .and_then(|v| v.as_bool())
            .unwrap_or(false);

        let begin_marker = marker.replace("{mark}", marker_begin);
        let end_marker = marker.replace("{mark}", marker_end);

        let path = Path::new(&path_s);
        let original = match std::fs::read_to_string(path) {
            Ok(s) => s,
            Err(_) if create => String::new(),
            Err(e) => {
                result.failed = true;
                result.msg = Some(format!("blockinfile: read failed: {}", e));
                return Ok(result);
            }
        };

        let lines: Vec<&str> = original.lines().collect();
        let mut new_lines: Vec<String> = Vec::new();
        let mut in_block = false;
        let mut found_block = false;
        let mut changed = false;

        for line in &lines {
            if *line == begin_marker {
                in_block = true;
                found_block = true;
                if state == "present" {
                    new_lines.push(begin_marker.clone());
                    for bl in block.lines() {
                        new_lines.push(bl.to_string());
                    }
                    new_lines.push(end_marker.clone());
                }
                // If state == absent, skip begin marker entirely
                continue;
            }
            if *line == end_marker {
                in_block = false;
                // End marker already pushed (present) or skipped (absent)
                continue;
            }
            if !in_block {
                new_lines.push(line.to_string());
            }
        }

        // If the block wasn't found and state is present, append it
        if !found_block && state == "present" && !block.is_empty() {
            new_lines.push(begin_marker.clone());
            for bl in block.lines() {
                new_lines.push(bl.to_string());
            }
            new_lines.push(end_marker.clone());
        }

        let mut new_text = new_lines.join("\n");
        if !new_text.is_empty() {
            new_text.push('\n');
        }

        // Compare
        let original_normalized = if original.is_empty() {
            String::new()
        } else if original.ends_with('\n') {
            original.clone()
        } else {
            format!("{}\n", original)
        };

        if new_text != original_normalized {
            changed = true;
            if let Some(parent) = path.parent() {
                let _ = std::fs::create_dir_all(parent);
            }
            if let Err(e) = std::fs::write(path, new_text.as_bytes()) {
                result.failed = true;
                result.msg = Some(format!("blockinfile: write failed: {}", e));
                return Ok(result);
            }
        }

        result.changed = changed;
        result.results = serde_json::json!({"path": path_s, "state": state});
        Ok(result)
    }

    /// Implement the `replace` module natively.
    ///
    /// Replaces all occurrences of a regex pattern with a replacement
    /// string within a file. Similar to `sed s/pattern/replace/g`.
    fn module_replace(&self, args: &AnsibleValue) -> Result<TaskResult, ExecutorError> {
        use std::path::Path;
        let mut result = TaskResult::ok(self.host.clone());

        let path_s = match args
            .get("path")
            .or_else(|| args.get("dest"))
            .and_then(|v| v.as_str())
        {
            Some(p) => p.to_string(),
            None => {
                result.failed = true;
                result.msg = Some("replace: 'path' is required".into());
                return Ok(result);
            }
        };
        let regexp_s = match args.get("regexp").and_then(|v| v.as_str()) {
            Some(r) => r,
            None => {
                result.failed = true;
                result.msg = Some("replace: 'regexp' is required".into());
                return Ok(result);
            }
        };
        let replace_str = args
            .get("replace")
            .and_then(|v| v.as_str())
            .unwrap_or("");
        let after = args.get("after").and_then(|v| v.as_str());
        let before = args.get("before").and_then(|v| v.as_str());

        let path = Path::new(&path_s);
        let original = match std::fs::read_to_string(path) {
            Ok(s) => s,
            Err(e) => {
                result.failed = true;
                result.msg = Some(format!("replace: read failed: {}", e));
                return Ok(result);
            }
        };

        let re = match regex_lite::Regex::new(regexp_s) {
            Ok(r) => r,
            Err(e) => {
                result.failed = true;
                result.msg = Some(format!("replace: bad regexp: {}", e));
                return Ok(result);
            }
        };

        // Determine the region to search in (bounded by after/before).
        let search_start = if let Some(after_pat) = after {
            match regex_lite::Regex::new(after_pat) {
                Ok(re_after) => re_after
                    .find(&original)
                    .map(|m| m.end())
                    .unwrap_or(0),
                Err(_) => 0,
            }
        } else {
            0
        };
        let search_end = if let Some(before_pat) = before {
            match regex_lite::Regex::new(before_pat) {
                Ok(re_before) => re_before
                    .find(&original[search_start..])
                    .map(|m| search_start + m.start())
                    .unwrap_or(original.len()),
                Err(_) => original.len(),
            }
        } else {
            original.len()
        };

        // Only replace within the bounded region.
        let prefix = &original[..search_start];
        let region = &original[search_start..search_end];
        let suffix = &original[search_end..];

        let replaced_region = re.replace_all(region, replace_str);
        let new_text = format!("{}{}{}", prefix, replaced_region, suffix);

        let changed = new_text != original;
        if changed {
            if let Err(e) = std::fs::write(path, new_text.as_bytes()) {
                result.failed = true;
                result.msg = Some(format!("replace: write failed: {}", e));
                return Ok(result);
            }
        }

        result.changed = changed;
        result.results = serde_json::json!({"path": path_s});
        Ok(result)
    }

    /// Implement the `setup` (fact gathering) module natively.
    ///
    /// This is a minimal subset of upstream ansible's setup.py, enough to
    /// populate `ansible_hostname`, `ansible_os_family`, `ansible_system`,
    /// `ansible_architecture`, `ansible_user_id`, `ansible_date_time`,
    /// and `ansible_python_interpreter` so conditionals and templates that
    /// reference the common facts just work without forking Python.
    ///
    /// Fact values are returned nested under `ansible_facts` (matching
    /// upstream's contract) and also surfaced via `set_fact` semantics so
    /// the rest of the play can read them as unprefixed variables.
    async fn module_setup(&self, _args: &AnsibleValue) -> Result<TaskResult, ExecutorError> {
        let mut result = TaskResult::ok(self.host.clone());
        let mut facts = serde_json::Map::new();

        if self.is_local() {
            // Local fact gathering: read directly from the filesystem.
            let hostname = std::fs::read_to_string("/etc/hostname")
                .ok()
                .map(|s| s.trim().to_string())
                .or_else(|| std::env::var("HOSTNAME").ok())
                .unwrap_or_else(|| self.host.to_string());
            facts.insert("ansible_hostname".into(), serde_json::json!(hostname));
            facts.insert("ansible_fqdn".into(), serde_json::json!(hostname));
            facts.insert("ansible_nodename".into(), serde_json::json!(hostname));

            let system = std::fs::read_to_string("/proc/sys/kernel/ostype")
                .ok()
                .map(|s| s.trim().to_string())
                .unwrap_or_else(|| std::env::consts::OS.to_string());
            facts.insert("ansible_system".into(), serde_json::json!(system));
            let kernel = std::fs::read_to_string("/proc/sys/kernel/osrelease")
                .ok()
                .map(|s| s.trim().to_string())
                .unwrap_or_default();
            facts.insert("ansible_kernel".into(), serde_json::json!(kernel));
            facts.insert(
                "ansible_architecture".into(),
                serde_json::json!(std::env::consts::ARCH),
            );

            let (distro, family) = parse_os_release();
            facts.insert("ansible_distribution".into(), serde_json::json!(distro));
            facts.insert("ansible_os_family".into(), serde_json::json!(family));

            let user = std::env::var("USER").unwrap_or_else(|_| "root".into());
            facts.insert("ansible_user_id".into(), serde_json::json!(user));
            facts.insert(
                "ansible_env".into(),
                serde_json::json!(std::env::vars().collect::<std::collections::HashMap<_, _>>()),
            );
        } else {
            // Remote fact gathering: execute commands via the connection plugin.
            let conn = self.get_connection().await?;

            // Gather hostname, system, kernel, architecture, user in one shot.
            let fact_script = concat!(
                "echo \"HOSTNAME=$(hostname 2>/dev/null || cat /etc/hostname 2>/dev/null || echo unknown)\";",
                "echo \"SYSTEM=$(uname -s 2>/dev/null || echo unknown)\";",
                "echo \"KERNEL=$(uname -r 2>/dev/null || echo unknown)\";",
                "echo \"ARCH=$(uname -m 2>/dev/null || echo unknown)\";",
                "echo \"USER=$(whoami 2>/dev/null || echo unknown)\";",
                "echo \"FQDN=$(hostname -f 2>/dev/null || hostname 2>/dev/null || echo unknown)\";",
                "if [ -f /etc/os-release ]; then . /etc/os-release; echo \"DISTRO=${ID:-unknown}\"; echo \"FAMILY=${ID_LIKE:-$ID}\"; ",
                "else echo \"DISTRO=unknown\"; echo \"FAMILY=unknown\"; fi"
            );
            let (rc, stdout, _stderr) = conn
                .exec_command(fact_script, None)
                .await
                .map_err(|e| ExecutorError::TaskFailed(format!("setup: {}", e)))?;

            if rc != 0 {
                // Still return what we can — partial facts are better than none.
                warn!("[{}] setup fact script returned rc={}", self.host, rc);
            }

            let output = String::from_utf8_lossy(&stdout);
            let mut fact_map: HashMap<String, String> = HashMap::new();
            for line in output.lines() {
                if let Some((key, val)) = line.split_once('=') {
                    fact_map.insert(key.to_string(), val.to_string());
                }
            }

            let hostname = fact_map.get("HOSTNAME").cloned().unwrap_or_else(|| self.host.to_string());
            facts.insert("ansible_hostname".into(), serde_json::json!(hostname));
            let fqdn = fact_map.get("FQDN").cloned().unwrap_or_else(|| hostname.clone());
            facts.insert("ansible_fqdn".into(), serde_json::json!(fqdn));
            facts.insert("ansible_nodename".into(), serde_json::json!(hostname));

            let system = fact_map.get("SYSTEM").cloned().unwrap_or_else(|| "Linux".to_string());
            facts.insert("ansible_system".into(), serde_json::json!(system));
            let kernel = fact_map.get("KERNEL").cloned().unwrap_or_default();
            facts.insert("ansible_kernel".into(), serde_json::json!(kernel));
            let arch = fact_map.get("ARCH").cloned().unwrap_or_else(|| "x86_64".to_string());
            facts.insert("ansible_architecture".into(), serde_json::json!(arch));

            let distro = fact_map.get("DISTRO").cloned().unwrap_or_else(|| "unknown".to_string());
            let family_raw = fact_map.get("FAMILY").cloned().unwrap_or_else(|| distro.clone());
            let family = map_os_family(&family_raw);
            facts.insert("ansible_distribution".into(), serde_json::json!(distro));
            facts.insert("ansible_os_family".into(), serde_json::json!(family));

            let user = fact_map.get("USER").cloned().unwrap_or_else(|| "root".to_string());
            facts.insert("ansible_user_id".into(), serde_json::json!(user));
        }

        facts.insert(
            "ansible_python_interpreter".into(),
            serde_json::json!("python3"),
        );

        let now = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_secs())
            .unwrap_or(0);
        facts.insert(
            "ansible_date_time".into(),
            serde_json::json!({
                "epoch": now.to_string(),
            }),
        );

        result.results = serde_json::json!({ "ansible_facts": facts });
        Ok(result)
    }

    /// Native `uri` module: make HTTP requests using reqwest.
    /// Matches ansible.builtin.uri output format.
    #[cfg(feature = "http")]
    async fn module_uri(&self, args: &AnsibleValue) -> Result<TaskResult, ExecutorError> {
        let mut result = TaskResult::ok(self.host.clone());

        let url = match args.get("url").and_then(|v| v.as_str()) {
            Some(u) => u.to_string(),
            None => {
                result.failed = true;
                result.msg = Some("uri: 'url' is required".into());
                return Ok(result);
            }
        };

        // ansible/ansible#86885 (#109) widened ftp:// support in upstream's
        // urllib-based fetcher. reqwest is HTTP-only, so we surface a clean
        // error instead of letting the request fail with an obscure
        // "URL scheme is not supported" message from the transport layer.
        if url.starts_with("ftp://") || url.starts_with("ftps://") {
            result.failed = true;
            result.msg = Some(format!(
                "uri: ftp/ftps URLs are not supported by this port \
                 (the underlying HTTP client is HTTP-only); got '{url}'"
            ));
            return Ok(result);
        }

        let method = args
            .get("method")
            .and_then(|v| v.as_str())
            .unwrap_or("GET")
            .to_uppercase();

        let redirect_policy = match parse_follow_redirects(args.get("follow_redirects"), &method) {
            Ok(p) => p,
            Err(why) => {
                result.failed = true;
                result.msg = Some(format!("uri: {why}"));
                return Ok(result);
            }
        };

        let client = reqwest::Client::builder()
            .danger_accept_invalid_certs(
                args.get("validate_certs")
                    .and_then(|v| v.as_bool())
                    .map(|v| !v)
                    .unwrap_or(false),
            )
            .timeout(std::time::Duration::from_secs(
                args.get("timeout")
                    .and_then(|v| v.as_u64())
                    .unwrap_or(30),
            ))
            .redirect(redirect_policy)
            .build()
            .map_err(|e| ExecutorError::TaskFailed(format!("uri: client build: {e}")))?;

        let mut request = match method.as_str() {
            "GET" => client.get(&url),
            "POST" => client.post(&url),
            "PUT" => client.put(&url),
            "DELETE" => client.delete(&url),
            "PATCH" => client.patch(&url),
            "HEAD" => client.head(&url),
            other => {
                result.failed = true;
                result.msg = Some(format!("uri: unsupported method '{other}'"));
                return Ok(result);
            }
        };

        // Add headers
        if let Some(headers) = args.get("headers").and_then(|v| v.as_object()) {
            for (k, v) in headers {
                if let Some(val) = v.as_str() {
                    request = request.header(k.as_str(), val);
                }
            }
        }

        // Add body
        // body_format controls how `body` is serialized:
        //   raw           — verbatim string body (default if body is a string)
        //   json          — serde_json::to_string + application/json header
        //   form-urlencoded — reqwest .form(...) (default if body is a dict)
        //   form-multipart — reqwest::multipart::Form (per ansible/ansible#86687)
        let body_format = args
            .get("body_format")
            .and_then(|v| v.as_str())
            .unwrap_or("raw")
            .to_string();
        if let Some(body) = args.get("body") {
            request = match body_format.as_str() {
                "raw" => match body {
                    AnsibleValue::String(s) => request.body(s.clone()),
                    other => {
                        // Back-compat: a dict/list body without body_format=json
                        // historically gets JSON-encoded. Preserve that.
                        let json_body = serde_json::to_string(other)
                            .map_err(|e| ExecutorError::TaskFailed(format!(
                                "uri: body serialize: {e}"
                            )))?;
                        request
                            .header("Content-Type", "application/json")
                            .body(json_body)
                    }
                },
                "json" => {
                    let json_body = match body {
                        AnsibleValue::String(s) => s.clone(),
                        other => serde_json::to_string(other).map_err(|e| {
                            ExecutorError::TaskFailed(format!("uri: body serialize: {e}"))
                        })?,
                    };
                    request
                        .header("Content-Type", "application/json")
                        .body(json_body)
                }
                "form-urlencoded" => {
                    let pairs = match flatten_form_body(body) {
                        Ok(p) => p,
                        Err(why) => {
                            result.failed = true;
                            result.msg = Some(format!("uri: {why}"));
                            return Ok(result);
                        }
                    };
                    request.form(&pairs)
                }
                "form-multipart" => {
                    let form = match build_multipart_form(body) {
                        Ok(f) => f,
                        Err(why) => {
                            result.failed = true;
                            result.msg = Some(format!("uri: {why}"));
                            return Ok(result);
                        }
                    };
                    request.multipart(form)
                }
                other => {
                    result.failed = true;
                    result.msg = Some(format!(
                        "uri: unknown body_format '{other}'; must be one of \
                         raw, json, form-urlencoded, form-multipart"
                    ));
                    return Ok(result);
                }
            };
        } else if body_format == "json" {
            // body_format=json with no body: still set the header (parity
            // with upstream Python — uri with method=GET, body_format=json,
            // no body sends the Accept negotiation hint).
            request = request.header("Content-Type", "application/json");
        }

        // Add basic auth
        if let Some(user) = args.get("url_username").or(args.get("user")).and_then(|v| v.as_str()) {
            let password = args
                .get("url_password")
                .or(args.get("password"))
                .and_then(|v| v.as_str())
                .unwrap_or("");
            request = request.basic_auth(user, Some(password));
        }

        // Force basic auth header
        if args.get("force_basic_auth").and_then(|v| v.as_bool()).unwrap_or(false) {
            // Already handled above if credentials are present
        }

        // Execute the request
        match request.send().await {
            Ok(response) => {
                let status = response.status().as_u16();
                let status_code = status;
                let reason = response
                    .status()
                    .canonical_reason()
                    .unwrap_or("Unknown")
                    .to_string();

                // Collect response headers
                let mut resp_headers = serde_json::Map::new();
                for (k, v) in response.headers() {
                    if let Ok(val) = v.to_str() {
                        resp_headers.insert(k.as_str().to_string(), serde_json::json!(val));
                    }
                }

                let content_type = response
                    .headers()
                    .get("content-type")
                    .and_then(|v| v.to_str().ok())
                    .unwrap_or("")
                    .to_string();
                let redirected = response.url().as_str() != url;
                let final_url = response.url().to_string();

                let body_bytes = response.bytes().await.map_err(|e| {
                    ExecutorError::TaskFailed(format!("uri: read body: {e}"))
                })?;
                let body_str = String::from_utf8_lossy(&body_bytes).into_owned();

                // Try to parse JSON response
                let json_body: Option<serde_json::Value> =
                    if content_type.contains("json") {
                        serde_json::from_str(&body_str).ok()
                    } else {
                        None
                    };

                // Check return codes
                let status_code_i = status_code as i64;
                let return_content = args
                    .get("return_content")
                    .and_then(|v| v.as_bool())
                    .unwrap_or(false);

                // Determine expected status codes
                let expected: Vec<i64> = args
                    .get("status_code")
                    .map(|v| match v {
                        AnsibleValue::Array(arr) => arr
                            .iter()
                            .filter_map(|x| x.as_i64())
                            .collect(),
                        AnsibleValue::Number(n) => n.as_i64().into_iter().collect(),
                        _ => vec![200],
                    })
                    .unwrap_or_else(|| vec![200]);

                let status_ok = expected.contains(&status_code_i);
                result.failed = !status_ok;
                result.changed = method != "GET" && method != "HEAD";

                let mut res = serde_json::Map::new();
                res.insert("status".into(), serde_json::json!(status_code));
                res.insert("msg".into(), serde_json::json!(format!("{status_code} {reason}")));
                res.insert("url".into(), serde_json::json!(final_url));
                res.insert("redirected".into(), serde_json::json!(redirected));
                res.insert("content_type".into(), serde_json::json!(content_type));
                res.insert("content_length".into(), serde_json::json!(body_bytes.len()));

                if return_content {
                    res.insert("content".into(), serde_json::json!(body_str));
                }
                if let Some(json) = json_body {
                    res.insert("json".into(), json);
                }

                result.msg = Some(format!("{status_code} {reason}"));
                result.results = AnsibleValue::Object(res);
            }
            Err(e) => {
                result.failed = true;
                result.msg = Some(format!("uri: request failed: {e}"));
            }
        }

        Ok(result)
    }

    /// Native `get_url` module: download a file from HTTP/HTTPS to a local path.
    #[cfg(feature = "http")]
    async fn module_get_url(&self, args: &AnsibleValue) -> Result<TaskResult, ExecutorError> {
        let mut result = TaskResult::ok(self.host.clone());

        let url = match args.get("url").and_then(|v| v.as_str()) {
            Some(u) => u.to_string(),
            None => {
                result.failed = true;
                result.msg = Some("get_url: 'url' is required".into());
                return Ok(result);
            }
        };
        let dest = match args.get("dest").and_then(|v| v.as_str()) {
            Some(d) => d.to_string(),
            None => {
                result.failed = true;
                result.msg = Some("get_url: 'dest' is required".into());
                return Ok(result);
            }
        };

        if url.starts_with("ftp://") || url.starts_with("ftps://") {
            result.failed = true;
            result.msg = Some(format!(
                "get_url: ftp/ftps URLs are not supported by this port \
                 (the underlying HTTP client is HTTP-only); got '{url}'"
            ));
            return Ok(result);
        }

        let redirect_policy = match parse_follow_redirects(args.get("follow_redirects"), "GET") {
            Ok(p) => p,
            Err(why) => {
                result.failed = true;
                result.msg = Some(format!("get_url: {why}"));
                return Ok(result);
            }
        };

        let client = reqwest::Client::builder()
            .danger_accept_invalid_certs(
                args.get("validate_certs")
                    .and_then(|v| v.as_bool())
                    .map(|v| !v)
                    .unwrap_or(false),
            )
            .timeout(std::time::Duration::from_secs(
                args.get("timeout")
                    .and_then(|v| v.as_u64())
                    .unwrap_or(300),
            ))
            .redirect(redirect_policy)
            .build()
            .map_err(|e| ExecutorError::TaskFailed(format!("get_url: client build: {e}")))?;

        let response = client
            .get(&url)
            .send()
            .await
            .map_err(|e| ExecutorError::TaskFailed(format!("get_url: request failed: {e}")))?;

        if !response.status().is_success() {
            result.failed = true;
            result.msg = Some(format!(
                "get_url: HTTP {} for {}",
                response.status(),
                url
            ));
            return Ok(result);
        }

        let body = response.bytes().await.map_err(|e| {
            ExecutorError::TaskFailed(format!("get_url: read body: {e}"))
        })?;

        // Check if dest content is already the same
        let dest_path = std::path::Path::new(&dest);
        let changed = match std::fs::read(dest_path) {
            Ok(existing) => existing != body.as_ref(),
            Err(_) => true,
        };

        if changed {
            if let Some(parent) = dest_path.parent() {
                let _ = std::fs::create_dir_all(parent);
            }
            std::fs::write(dest_path, &body)
                .map_err(|e| ExecutorError::TaskFailed(format!("get_url: write: {e}")))?;

            // Set mode if specified
            #[cfg(unix)]
            if let Some(mode_s) = args.get("mode").and_then(|v| v.as_str()) {
                if let Ok(mode) = u32::from_str_radix(mode_s, 8) {
                    use std::os::unix::fs::PermissionsExt;
                    let _ = std::fs::set_permissions(dest_path, std::fs::Permissions::from_mode(mode));
                }
            }
        }

        // Compute checksum of downloaded file
        let checksum = {
            use sha2::{Sha256, Digest};
            let hash = Sha256::digest(&body);
            format!("{:x}", hash)
        };

        result.changed = changed;
        result.results = serde_json::json!({
            "dest": dest,
            "url": url,
            "checksum_dest": checksum,
            "size": body.len(),
        });
        Ok(result)
    }

    /// Native `wait_for_connection` module: wait until the host is reachable.
    async fn module_wait_for_connection(
        &self,
        args: &AnsibleValue,
    ) -> Result<TaskResult, ExecutorError> {
        let mut result = TaskResult::ok(self.host.clone());

        let timeout = args
            .get("timeout")
            .and_then(|v| v.as_u64())
            .unwrap_or(600);
        let delay = args
            .get("delay")
            .and_then(|v| v.as_u64())
            .unwrap_or(0);
        let sleep_secs = args
            .get("sleep")
            .and_then(|v| v.as_u64())
            .unwrap_or(1);

        if delay > 0 {
            tokio::time::sleep(std::time::Duration::from_secs(delay)).await;
        }

        let all_vars = self.variable_manager.get_vars(
            &self.host,
            &self.play_vars,
            self.task.vars.as_ref(),
            self.block_vars.as_ref(),
            self.role_name.as_deref(),
        );
        let start = std::time::Instant::now();
        let deadline = std::time::Duration::from_secs(timeout);

        loop {
            let mut conn = self.make_connection(&all_vars)?;
            if let Ok(()) = conn.connect().await {
                // Try a simple echo to verify the connection actually works
                if let Ok((0, _, _)) = conn.exec_command("echo ok", None).await {
                    let elapsed = start.elapsed().as_secs();
                    result.results = serde_json::json!({
                        "elapsed": elapsed,
                    });
                    return Ok(result);
                }
            }

            if start.elapsed() >= deadline {
                result.failed = true;
                result.msg = Some(format!(
                    "Timed out waiting for connection ({}s)",
                    timeout
                ));
                return Ok(result);
            }

            tokio::time::sleep(std::time::Duration::from_secs(sleep_secs)).await;
        }
    }

    /// Implement the `ping` module natively. Always reports ok,
    /// optionally echoing a `data` argument. Matches ansible.builtin.ping.
    /// Implement the `ping` module: for local hosts, return the data
    /// string directly; for remote hosts, verify connectivity by executing
    /// `echo <data>` through the connection plugin and checking the output.
    async fn module_ping(&self, args: &AnsibleValue) -> Result<TaskResult, ExecutorError> {
        let mut result = TaskResult::ok(self.host.clone());
        let data = args
            .get("data")
            .and_then(|v| v.as_str())
            .unwrap_or("pong")
            .to_string();
        if data == "crash" {
            result.failed = true;
            result.msg = Some("boom".into());
            return Ok(result);
        }

        if self.is_local() {
            result.results = serde_json::json!({"ping": data});
            return Ok(result);
        }

        // Remote: verify connectivity by executing a command through the
        // connection plugin. This mirrors Python Ansible's ping module which
        // actually runs on the remote host.
        let conn = match self.get_connection().await {
            Ok(c) => c,
            Err(e) => {
                result.failed = true;
                result.unreachable = true;
                result.msg = Some(format!("ping: {}", e));
                return Ok(result);
            }
        };
        let escaped = shell_escape(&data);
        match conn.exec_command(&format!("echo {escaped}"), None).await {
            Ok((rc, stdout, _stderr)) => {
                if rc != 0 {
                    result.failed = true;
                    result.msg = Some(format!("ping: remote command returned rc={}", rc));
                    return Ok(result);
                }
                let out = String::from_utf8_lossy(&stdout).trim().to_string();
                if out != data {
                    result.failed = true;
                    result.msg = Some(format!(
                        "ping: expected '{}', got '{}'", data, out
                    ));
                    return Ok(result);
                }
                result.results = serde_json::json!({"ping": data});
            }
            Err(e) => {
                result.failed = true;
                result.unreachable = true;
                result.msg = Some(format!("ping: {}", e));
            }
        }
        Ok(result)
    }

    /// Implement the `slurp` module natively: read a file and return its
    /// base64-encoded contents. Mirrors ansible.builtin.slurp which is
    /// commonly used to read arbitrary files back to the controller.
    /// For remote hosts, reads the file via `base64` on the remote side.
    async fn module_slurp(&self, args: &AnsibleValue) -> Result<TaskResult, ExecutorError> {
        use base64::Engine;
        let mut result = TaskResult::ok(self.host.clone());
        let src = match args
            .get("src")
            .or_else(|| args.get("path"))
            .and_then(|v| v.as_str())
        {
            Some(s) => s.to_string(),
            None => {
                result.failed = true;
                result.msg = Some("slurp requires 'src'".into());
                return Ok(result);
            }
        };

        if self.is_local() {
            match std::fs::read(&src) {
                Ok(bytes) => {
                    let encoded = base64::engine::general_purpose::STANDARD.encode(&bytes);
                    result.results = serde_json::json!({
                        "content": encoded,
                        "encoding": "base64",
                        "source": src,
                    });
                }
                Err(e) => {
                    result.failed = true;
                    result.msg = Some(format!("slurp: {}", e));
                }
            }
        } else {
            // Remote: read via base64 command on the target
            let conn = self.get_connection().await?;
            let escaped = shell_escape(&src);
            let (rc, stdout, stderr) = conn
                .exec_command(&format!("base64 {escaped}"), None)
                .await
                .map_err(|e| ExecutorError::TaskFailed(format!("slurp: {}", e)))?;

            if rc != 0 {
                result.failed = true;
                result.msg = Some(format!("slurp: {}", String::from_utf8_lossy(&stderr).trim()));
            } else {
                // The remote base64 output may have newlines; strip them
                let encoded = String::from_utf8_lossy(&stdout)
                    .chars()
                    .filter(|c| !c.is_whitespace())
                    .collect::<String>();
                result.results = serde_json::json!({
                    "content": encoded,
                    "encoding": "base64",
                    "source": src,
                });
            }
        }
        Ok(result)
    }

    /// Fallback for non-native modules: try to package the module via
    /// AnsiballZ and execute it through the resolved connection plugin.
    /// Looks up the module source in `ANSIBLE_LIBRARY` (colon-separated).
    /// If no module file is found, returns a not-implemented placeholder
    /// so the existing test surface keeps working.
    async fn module_ansiballz_fallback(
        &self,
        module_name: &str,
        module_args: &AnsibleValue,
    ) -> Result<TaskResult, ExecutorError> {
        use crate::module::{ansiballz::AnsiballZPackager, remote_exec::run_ansiballz};
        use std::path::PathBuf;

        // FQCN path: if `module_name` looks like `ns.col.short`, walk
        // collection roots via the galaxy router. Otherwise fall back to
        // the flat `ANSIBLE_LIBRARY` lookup used by legacy playbooks.
        let module_path: Option<PathBuf> = if module_name.matches('.').count() >= 2 {
            ansible_galaxy::Fqcn::parse(module_name)
                .ok()
                .and_then(|fqcn| {
                    ansible_galaxy::CollectionRouter::from_env()
                        .resolve_fqcn(&fqcn, ansible_galaxy::PluginType::Module)
                        .ok()
                })
        } else {
            let library = std::env::var("ANSIBLE_LIBRARY").unwrap_or_default();
            library
                .split(':')
                .filter(|s| !s.is_empty())
                .map(|dir| PathBuf::from(dir).join(format!("{}.py", module_name)))
                .find(|p| p.is_file())
        };

        let Some(module_path) = module_path else {
            let mut result = TaskResult::ok(self.host.clone());
            result.msg = Some(format!(
                "module '{}' execution not yet implemented",
                module_name
            ));
            return Ok(result);
        };

        // Fast path: on local connections, try the in-process PyO3 runner
        // before falling through to the AnsiballZ subprocess. This avoids
        // one fork+exec per task for the common case (localhost and
        // `connection: local`). Remote connections must still use
        // AnsiballZ because the Python interpreter lives on the target.
        let all_vars_for_conn = self.variable_manager.get_vars(
            &self.host,
            &self.play_vars,
            self.task.vars.as_ref(),
            self.block_vars.as_ref(),
            self.role_name.as_deref(),
        );
        #[cfg(feature = "python-plugins")]
        let is_local = {
            let explicit = all_vars_for_conn
                .get("ansible_connection")
                .and_then(|v| v.as_str());
            match explicit {
                Some("local") => true,
                Some(_) => false,
                None => !all_vars_for_conn.contains_key("ansible_host")
                    || self.host.as_ref() == "localhost"
                    || self.host.as_ref() == "127.0.0.1"
            }
        };
        #[cfg(feature = "python-plugins")]
        if is_local {
            if let Ok(source) = std::fs::read_to_string(&module_path) {
                let runner = ansible_compat::PythonRunner::new();
                let args_json: serde_json::Value = module_args.clone();
                match runner.run_module(module_name, &source, &args_json) {
                    Ok(res) => {
                        let mut result = TaskResult::ok(self.host.clone());
                        if let Some(v) = res.parsed {
                            result.changed = v.get("changed").and_then(|x| x.as_bool()).unwrap_or(false);
                            result.failed = res.rc != 0
                                || v.get("failed").and_then(|x| x.as_bool()).unwrap_or(false);
                            if let Some(msg) = v.get("msg").and_then(|x| x.as_str()) {
                                result.msg = Some(msg.to_string());
                            }
                            result.results = AnsibleValue::from(v);
                        } else {
                            result.failed = res.rc != 0;
                            result.msg = Some(format!(
                                "module '{}' returned non-JSON output (rc={})",
                                module_name, res.rc
                            ));
                            result.results = serde_json::json!({
                                "rc": res.rc,
                                "stdout": res.stdout,
                                "stderr": res.stderr,
                            });
                        }
                        return Ok(result);
                    }
                    Err(e) => {
                        // Fall through to AnsiballZ subprocess — the in-process
                        // interpreter may be missing module_utils on sys.path.
                        debug!("in-process module '{}' failed, falling back to AnsiballZ: {}", module_name, e);
                    }
                }
            }
        }

        let module_utils_paths: Vec<PathBuf> = std::env::var("ANSIBLE_MODULE_UTILS")
            .unwrap_or_default()
            .split(':')
            .filter(|s| !s.is_empty())
            .map(PathBuf::from)
            .collect();
        let packager = AnsiballZPackager::new(module_utils_paths);
        let fqn = format!("ansible.modules.{}", module_name);
        let wrapper = packager.package(&module_path, module_args, &fqn)?;

        let all_vars = all_vars_for_conn;
        let python = all_vars
            .get("ansible_python_interpreter")
            .and_then(|v| v.as_str())
            .map(|s| s.to_string())
            .unwrap_or_else(|| "python3".to_string());

        let mut conn = self.make_connection(&all_vars)?;
        conn.connect()
            .await
            .map_err(|e| ExecutorError::TaskFailed(format!("connect: {}", e)))?;

        // Use pipelining if enabled. Check host var first, then env, then default true.
        let pipelining = all_vars
            .get("ansible_ssh_pipelining")
            .and_then(|v| match v {
                AnsibleValue::Bool(b) => Some(*b),
                AnsibleValue::String(s) => Some(!matches!(s.as_str(), "false" | "False" | "no" | "0")),
                _ => None,
            })
            .or_else(|| {
                std::env::var("ANSIBLE_PIPELINING")
                    .ok()
                    .map(|v| v == "1" || v.eq_ignore_ascii_case("true"))
            })
            .unwrap_or(true);

        let exec = if pipelining {
            use crate::module::remote_exec::run_ansiballz_pipelined;
            run_ansiballz_pipelined(&*conn, &wrapper, &python)
                .await
                .map_err(|e| ExecutorError::TaskFailed(format!("ansiballz pipelined: {}", e)))?
        } else {
            run_ansiballz(&mut *conn, &wrapper, &python)
                .await
                .map_err(|e| ExecutorError::TaskFailed(format!("ansiballz: {}", e)))?
        };

        let mut result = TaskResult::ok(self.host.clone());
        let stdout_s = String::from_utf8_lossy(&exec.stdout).into_owned();
        // AnsiballZ modules emit a JSON document on stdout.
        match serde_json::from_str::<serde_json::Value>(stdout_s.trim()) {
            Ok(v) => {
                result.changed = v.get("changed").and_then(|x| x.as_bool()).unwrap_or(false);
                result.failed = exec.rc != 0
                    || v.get("failed").and_then(|x| x.as_bool()).unwrap_or(false);
                if let Some(msg) = v.get("msg").and_then(|x| x.as_str()) {
                    result.msg = Some(msg.to_string());
                }
                result.results = AnsibleValue::from(v);
            }
            Err(_) => {
                result.failed = exec.rc != 0;
                result.msg = Some(format!(
                    "module '{}' returned non-JSON output (rc={})",
                    module_name, exec.rc
                ));
                result.results = serde_json::json!({
                    "rc": exec.rc,
                    "stdout": stdout_s,
                    "stderr": String::from_utf8_lossy(&exec.stderr),
                });
            }
        }
        Ok(result)
    }

    /// Implement `include_role`/`import_role`: load a role and execute its tasks.
    async fn module_include_role(
        &self,
        _module_name: &str,
        args: &AnsibleValue,
    ) -> Result<TaskResult, ExecutorError> {
        let role_name = match args.get("name").and_then(|v| v.as_str()) {
            Some(n) => n.to_string(),
            None => {
                let mut result = TaskResult::ok(self.host.clone());
                result.failed = true;
                result.msg = Some("include_role/import_role: 'name' is required".into());
                return Ok(result);
            }
        };

        // Determine role search paths
        let mut search_paths = Vec::new();
        if let Ok(roles_path) = std::env::var("ANSIBLE_ROLES_PATH") {
            for p in roles_path.split(':') {
                if !p.is_empty() {
                    search_paths.push(std::path::PathBuf::from(p));
                }
            }
        }
        // Default paths
        search_paths.push(std::path::PathBuf::from("./roles"));
        search_paths.push(std::path::PathBuf::from("/etc/ansible/roles"));

        let mut role_loader = ansible_playbook::role::loader::RoleLoader::new(search_paths);

        // Extract role params from args
        let role_params: HashMap<String, AnsibleValue> = args
            .get("vars")
            .and_then(|v| v.as_object())
            .map(|obj| obj.iter().map(|(k, v)| (k.clone(), v.clone())).collect())
            .unwrap_or_default();

        let role = match role_loader.load_role(
            &role_name,
            role_params.clone(),
            Default::default(),
            Vec::new(),
        ) {
            Ok(r) => r,
            Err(e) => {
                let mut result = TaskResult::ok(self.host.clone());
                result.failed = true;
                result.msg = Some(format!("include_role: failed to load role '{}': {}", role_name, e));
                return Ok(result);
            }
        };

        // Merge role defaults and vars into the variable context
        for (k, v) in &role.defaults {
            self.variable_manager.set_host_fact(&self.host, k.clone(), v.clone());
        }
        for (k, v) in &role.vars {
            self.variable_manager.set_host_fact(&self.host, k.clone(), v.clone());
        }
        // Role params override vars
        for (k, v) in &role_params {
            self.variable_manager.set_host_fact(&self.host, k.clone(), v.clone());
        }

        // Optionally filter to specific tasks_from file
        let tasks_from = args.get("tasks_from").and_then(|v| v.as_str());

        let tasks = if let Some(tasks_file) = tasks_from {
            // Load specific tasks file from the role
            let tasks_path = role.path.join("tasks").join(tasks_file);
            if tasks_path.is_file() {
                let content = std::fs::read_to_string(&tasks_path)
                    .map_err(|e| ExecutorError::TaskFailed(format!("read {}: {}", tasks_path.display(), e)))?;
                let value: AnsibleValue = serde_yaml::from_str(&content)
                    .map_err(|e| ExecutorError::TaskFailed(format!("parse {}: {}", tasks_path.display(), e)))?;
                match value {
                    AnsibleValue::Array(arr) => {
                        serde_json::from_value::<Vec<Task>>(AnsibleValue::Array(arr))
                            .unwrap_or_default()
                    }
                    _ => Vec::new(),
                }
            } else {
                Vec::new()
            }
        } else {
            role.tasks.clone()
        };

        // Execute role tasks sequentially
        let mut all_changed = false;
        let mut any_failed = false;
        let mut task_results = Vec::new();

        for task in &tasks {
            let executor = TaskExecutor::new(
                self.host.clone(),
                task.clone(),
                self.variable_manager.clone(),
            );
            let result = executor.run().await?;
            if result.changed {
                all_changed = true;
            }
            if result.failed {
                any_failed = true;
                task_results.push(serde_json::json!({
                    "task": task.name,
                    "changed": result.changed,
                    "failed": true,
                    "msg": result.msg,
                }));
                if !self.task.ignore_errors {
                    break;
                }
            } else {
                task_results.push(serde_json::json!({
                    "task": task.name,
                    "changed": result.changed,
                    "failed": false,
                    "msg": result.msg,
                }));
            }
        }

        let mut result = TaskResult::ok(self.host.clone());
        result.changed = all_changed;
        result.failed = any_failed;
        result.results = serde_json::json!({
            "role": role_name,
            "tasks_executed": task_results.len(),
            "include_results": task_results,
        });
        Ok(result)
    }

    /// Implement `include_tasks`/`import_tasks`: load and execute tasks from a file.
    async fn module_include_tasks(
        &self,
        _module_name: &str,
        args: &AnsibleValue,
    ) -> Result<TaskResult, ExecutorError> {
        let file_path = match args {
            AnsibleValue::String(s) => s.clone(),
            _ => {
                args.get("file")
                    .or_else(|| args.get("_raw_params"))
                    .and_then(|v| v.as_str())
                    .map(|s| s.to_string())
                    .unwrap_or_default()
            }
        };

        if file_path.is_empty() {
            let mut result = TaskResult::ok(self.host.clone());
            result.failed = true;
            result.msg = Some("include_tasks: file path required".into());
            return Ok(result);
        }

        let content = match std::fs::read_to_string(&file_path) {
            Ok(c) => c,
            Err(e) => {
                let mut result = TaskResult::ok(self.host.clone());
                result.failed = true;
                result.msg = Some(format!("include_tasks: {}: {}", file_path, e));
                return Ok(result);
            }
        };

        let value: AnsibleValue = serde_yaml::from_str(&content)
            .map_err(|e| ExecutorError::TaskFailed(format!("include_tasks parse: {e}")))?;

        let tasks: Vec<Task> = match value {
            AnsibleValue::Array(arr) => {
                serde_json::from_value(AnsibleValue::Array(arr))
                    .unwrap_or_default()
            }
            _ => Vec::new(),
        };

        let mut all_changed = false;
        let mut any_failed = false;

        for task in &tasks {
            let executor = TaskExecutor::new(
                self.host.clone(),
                task.clone(),
                self.variable_manager.clone(),
            );
            let result = executor.run().await?;
            if result.changed {
                all_changed = true;
            }
            if result.failed && !self.task.ignore_errors {
                any_failed = true;
                break;
            }
        }

        let mut result = TaskResult::ok(self.host.clone());
        result.changed = all_changed;
        result.failed = any_failed;
        result.results = serde_json::json!({
            "included": file_path,
            "tasks_executed": tasks.len(),
        });
        Ok(result)
    }

    /// Implement the `meta` module natively.
    fn module_meta(&self, _args: &AnsibleValue) -> Result<TaskResult, ExecutorError> {
        let mut result = TaskResult::ok(self.host.clone());
        // Meta actions are handled by the strategy, not executed as modules
        result.msg = Some("meta task processed".into());
        Ok(result)
    }

    /// Implement the `apt` module natively (Debian/Ubuntu package management).
    ///
    /// Supports: name (single or list), state (present/absent/latest),
    /// update_cache, cache_valid_time, install_recommends.
    async fn module_apt(&self, args: &AnsibleValue) -> Result<TaskResult, ExecutorError> {
        let update_cache = args
            .get("update_cache")
            .and_then(|v| v.as_bool())
            .unwrap_or(false);
        let state = args
            .get("state")
            .and_then(|v| v.as_str())
            .unwrap_or("present");

        // Collect package names
        let packages: Vec<String> = if let Some(name) = args.get("name") {
            match name {
                AnsibleValue::String(s) => s.split(',').map(|p| p.trim().to_string()).collect(),
                AnsibleValue::Array(arr) => arr
                    .iter()
                    .filter_map(|v| v.as_str().map(|s| s.to_string()))
                    .collect(),
                _ => vec![],
            }
        } else {
            vec![]
        };

        if !update_cache && packages.is_empty() {
            return Err(ExecutorError::TaskFailed(
                "apt: either 'name' or 'update_cache' is required".into(),
            ));
        }

        let mut result = TaskResult::ok(self.host.clone());

        // Update cache if requested
        if update_cache {
            let cache_valid_time = args
                .get("cache_valid_time")
                .and_then(|v| v.as_u64())
                .unwrap_or(0);

            let mut cmd_args = vec!["apt-get".to_string(), "update".to_string(), "-q".to_string()];
            // cache_valid_time: skip if apt cache is newer than N seconds
            if cache_valid_time > 0 {
                let apt_cache = std::path::Path::new("/var/cache/apt/pkgcache.bin");
                if let Ok(meta) = std::fs::metadata(apt_cache) {
                    if let Ok(modified) = meta.modified() {
                        let age = modified.elapsed().unwrap_or_default().as_secs();
                        if age < cache_valid_time {
                            // Cache is fresh, skip update
                            if packages.is_empty() {
                                result.msg = Some("cache is already up to date".into());
                                return Ok(result);
                            }
                            // Fall through to package install
                            cmd_args.clear();
                        }
                    }
                }
            }

            if !cmd_args.is_empty() {
                let output = tokio::process::Command::new(&cmd_args[0])
                    .args(&cmd_args[1..])
                    .output()
                    .await
                    .map_err(|e| ExecutorError::TaskFailed(format!("apt update failed: {e}")))?;

                if !output.status.success() {
                    result.failed = true;
                    result.msg = Some(format!(
                        "apt-get update failed: {}",
                        String::from_utf8_lossy(&output.stderr)
                    ));
                    return Ok(result);
                }
                result.changed = true;
            }
        }

        // Install/remove packages
        if !packages.is_empty() {
            let apt_action = match state {
                "absent" | "removed" => "remove",
                "latest" => "install",
                _ => "install", // present is default
            };

            let mut cmd_args = vec![
                "apt-get".to_string(),
                "-y".to_string(),
                "-q".to_string(),
                apt_action.to_string(),
            ];

            // --no-install-recommends if requested
            let install_recommends = args
                .get("install_recommends")
                .and_then(|v| v.as_bool())
                .unwrap_or(true);
            if !install_recommends && apt_action == "install" {
                cmd_args.push("--no-install-recommends".to_string());
            }

            cmd_args.extend(packages.iter().cloned());

            let output = tokio::process::Command::new(&cmd_args[0])
                .args(&cmd_args[1..])
                .env("DEBIAN_FRONTEND", "noninteractive")
                .output()
                .await
                .map_err(|e| ExecutorError::TaskFailed(format!("apt failed: {e}")))?;

            let stdout = String::from_utf8_lossy(&output.stdout);
            let stderr = String::from_utf8_lossy(&output.stderr);

            if !output.status.success() {
                result.failed = true;
                result.msg = Some(format!("apt-get {apt_action} failed: {stderr}"));
                return Ok(result);
            }

            // Check if anything was actually installed/removed
            let already_newest = stdout.contains("is already the newest version")
                || stdout.contains("0 newly installed");
            if !already_newest {
                result.changed = true;
            }

            result.msg = Some(format!(
                "apt-get {apt_action} {}",
                packages.join(", ")
            ));
            result.results = serde_json::json!({
                "stdout": stdout.to_string(),
                "stderr": stderr.to_string(),
                "rc": output.status.code().unwrap_or(-1),
            });
        }

        Ok(result)
    }

    /// Implement the `apt_repository` module natively. Manages one-line-style
    /// entries under `/etc/apt/sources.list.d/`.
    ///
    /// Validates the `repo` line per `sources.list(5)` — types must be `deb`
    /// or `deb-src`, options in `[ ... ]` are skipped, and there must be at
    /// least a URI + suite (+ component, unless the suite ends in `/`).
    /// This matches upstream ansible/ansible#85881.
    ///
    /// PPA shortcuts (`ppa:user/name`) are not yet supported — they require
    /// launchpad GPG key retrieval which is out of scope for this port.
    async fn module_apt_repository(
        &self,
        args: &AnsibleValue,
        check_mode: bool,
    ) -> Result<TaskResult, ExecutorError> {
        let mut result = TaskResult::ok(self.host.clone());

        let repo = match args.get("repo").and_then(|v| v.as_str()) {
            Some(s) => s.trim().to_string(),
            None => {
                result.failed = true;
                result.msg = Some("apt_repository: 'repo' is required".into());
                return Ok(result);
            }
        };

        if repo.starts_with("ppa:") {
            result.failed = true;
            result.msg = Some(
                "apt_repository: PPA shortcut not supported by the Rust port; \
                 specify the full deb line instead"
                    .into(),
            );
            return Ok(result);
        }

        let state = args
            .get("state")
            .and_then(|v| v.as_str())
            .unwrap_or("present");

        if !matches!(state, "present" | "absent") {
            result.failed = true;
            result.msg = Some(format!(
                "apt_repository: 'state' must be 'present' or 'absent', got '{state}'"
            ));
            return Ok(result);
        }

        if state == "present" {
            if let Err(why) = validate_apt_source_line(&repo) {
                result.failed = true;
                result.msg = Some(format!("apt_repository: invalid repo line: {why}"));
                return Ok(result);
            }
        }

        // Destination filename under sources.list.d. If `filename` is given use
        // it (appending .list if missing); otherwise derive from the URI host.
        let filename = args
            .get("filename")
            .and_then(|v| v.as_str())
            .map(|s| s.to_string())
            .unwrap_or_else(|| default_apt_filename(&repo));
        let filename = if filename.ends_with(".list") {
            filename
        } else {
            format!("{filename}.list")
        };
        let path = std::path::PathBuf::from("/etc/apt/sources.list.d").join(&filename);

        // Determine the existing content (if any) and whether the canonical
        // form of `repo` is already present as a non-comment line.
        let existing = std::fs::read_to_string(&path).ok();
        let already_present = existing
            .as_deref()
            .map(|content| {
                content.lines().any(|l| {
                    let trimmed = l.trim();
                    !trimmed.is_empty()
                        && !trimmed.starts_with('#')
                        && normalize_source_line(trimmed) == normalize_source_line(&repo)
                })
            })
            .unwrap_or(false);

        match state {
            "present" => {
                if already_present {
                    result.msg = Some(format!("repo already in {}", path.display()));
                } else {
                    if !check_mode {
                        if let Some(parent) = path.parent() {
                            std::fs::create_dir_all(parent).map_err(|e| {
                                ExecutorError::TaskFailed(format!(
                                    "apt_repository: mkdir {}: {e}",
                                    parent.display()
                                ))
                            })?;
                        }
                        let mut content = existing.unwrap_or_default();
                        if !content.is_empty() && !content.ends_with('\n') {
                            content.push('\n');
                        }
                        content.push_str(&repo);
                        content.push('\n');
                        std::fs::write(&path, content).map_err(|e| {
                            ExecutorError::TaskFailed(format!(
                                "apt_repository: write {}: {e}",
                                path.display()
                            ))
                        })?;
                    }
                    result.changed = true;
                    result.msg = Some(format!("added repo to {}", path.display()));
                }
            }
            "absent" => {
                if let Some(content) = existing {
                    let target = normalize_source_line(&repo);
                    let mut kept: Vec<&str> = Vec::new();
                    let mut removed = false;
                    for line in content.lines() {
                        let trimmed = line.trim();
                        if !trimmed.is_empty()
                            && !trimmed.starts_with('#')
                            && normalize_source_line(trimmed) == target
                        {
                            removed = true;
                            continue;
                        }
                        kept.push(line);
                    }
                    if removed {
                        if !check_mode {
                            if kept.is_empty()
                                || kept.iter().all(|l| {
                                    let t = l.trim();
                                    t.is_empty() || t.starts_with('#')
                                })
                            {
                                // Only comments / blanks left — drop the file.
                                std::fs::remove_file(&path).map_err(|e| {
                                    ExecutorError::TaskFailed(format!(
                                        "apt_repository: rm {}: {e}",
                                        path.display()
                                    ))
                                })?;
                            } else {
                                let mut new_content = kept.join("\n");
                                new_content.push('\n');
                                std::fs::write(&path, new_content).map_err(|e| {
                                    ExecutorError::TaskFailed(format!(
                                        "apt_repository: write {}: {e}",
                                        path.display()
                                    ))
                                })?;
                            }
                        }
                        result.changed = true;
                        result.msg = Some(format!("removed repo from {}", path.display()));
                    } else {
                        result.msg = Some(format!("repo not present in {}", path.display()));
                    }
                } else {
                    result.msg = Some(format!("{} does not exist", path.display()));
                }
            }
            _ => unreachable!(),
        }

        // update_cache: only run apt-get update on actual changes, never in check_mode.
        let update_cache = args
            .get("update_cache")
            .and_then(|v| v.as_bool())
            .unwrap_or(false);
        if update_cache && result.changed && !check_mode {
            let output = tokio::process::Command::new("apt-get")
                .args(["update", "-q"])
                .output()
                .await
                .map_err(|e| {
                    ExecutorError::TaskFailed(format!("apt_repository: apt-get update: {e}"))
                })?;
            if !output.status.success() {
                result.failed = true;
                result.msg = Some(format!(
                    "apt-get update failed: {}",
                    String::from_utf8_lossy(&output.stderr)
                ));
                return Ok(result);
            }
        }

        result.results = serde_json::json!({
            "repo": repo,
            "state": state,
            "sources_file": path.display().to_string(),
        });
        Ok(result)
    }

    /// Implement the `yum`/`dnf` module natively (RHEL/Fedora package management).
    ///
    /// Supports: name (single or list), state (present/absent/latest).
    async fn module_yum(&self, args: &AnsibleValue) -> Result<TaskResult, ExecutorError> {
        let state = args
            .get("state")
            .and_then(|v| v.as_str())
            .unwrap_or("present");

        let packages: Vec<String> = if let Some(name) = args.get("name") {
            match name {
                AnsibleValue::String(s) => s.split(',').map(|p| p.trim().to_string()).collect(),
                AnsibleValue::Array(arr) => arr
                    .iter()
                    .filter_map(|v| v.as_str().map(|s| s.to_string()))
                    .collect(),
                _ => vec![],
            }
        } else {
            return Err(ExecutorError::TaskFailed(
                "yum/dnf: 'name' is required".into(),
            ));
        };

        // Determine the package manager binary (prefer dnf, fallback to yum)
        let pkg_mgr = if std::path::Path::new("/usr/bin/dnf").exists() {
            "dnf"
        } else {
            "yum"
        };

        let action = match state {
            "absent" | "removed" => "remove",
            "latest" => "install",
            _ => "install",
        };

        let mut cmd_args = vec![
            pkg_mgr.to_string(),
            "-y".to_string(),
            "-q".to_string(),
            action.to_string(),
        ];
        cmd_args.extend(packages.iter().cloned());

        let output = tokio::process::Command::new(&cmd_args[0])
            .args(&cmd_args[1..])
            .output()
            .await
            .map_err(|e| ExecutorError::TaskFailed(format!("{pkg_mgr} failed: {e}")))?;

        let mut result = TaskResult::ok(self.host.clone());
        let stdout = String::from_utf8_lossy(&output.stdout);
        let stderr = String::from_utf8_lossy(&output.stderr);

        if !output.status.success() {
            result.failed = true;
            result.msg = Some(format!("{pkg_mgr} {action} failed: {stderr}"));
            return Ok(result);
        }

        let nothing_to_do = stdout.contains("Nothing to do")
            || stdout.contains("already installed");
        result.changed = !nothing_to_do;
        result.msg = Some(format!("{pkg_mgr} {action} {}", packages.join(", ")));
        result.results = serde_json::json!({
            "stdout": stdout.to_string(),
            "stderr": stderr.to_string(),
            "rc": output.status.code().unwrap_or(-1),
        });

        Ok(result)
    }

    /// Implement the `yum_repository` module natively. Manages `.repo` files
    /// under `/etc/yum.repos.d/` for dnf/yum.
    ///
    /// Supports the modern parameter set; the deprecated options removed by
    /// upstream ansible/ansible#86794 (`async`, `deltarpm_metadata_percentage`,
    /// `gpgcakey`, `http_caching`, `keepalive`, `metadata_expire_filter`,
    /// `mirrorlist_expire`, `retries`) are intentionally **not** accepted —
    /// dnf ignores them and they would only mislead users.
    async fn module_yum_repository(
        &self,
        args: &AnsibleValue,
        check_mode: bool,
    ) -> Result<TaskResult, ExecutorError> {
        let mut result = TaskResult::ok(self.host.clone());

        let name = match args.get("name").and_then(|v| v.as_str()) {
            Some(n) if !n.is_empty() => n.to_string(),
            _ => {
                result.failed = true;
                result.msg = Some("yum_repository: 'name' is required".into());
                return Ok(result);
            }
        };

        // Reject removed-upstream parameters loudly so playbooks that still
        // pass them don't silently get the wrong behavior.
        const REMOVED_PARAMS: &[&str] = &[
            "async",
            "deltarpm_metadata_percentage",
            "gpgcakey",
            "http_caching",
            "keepalive",
            "metadata_expire_filter",
            "mirrorlist_expire",
            "retries",
        ];
        for p in REMOVED_PARAMS {
            if args.get(p).is_some() {
                result.failed = true;
                result.msg = Some(format!(
                    "yum_repository: parameter '{p}' was removed upstream \
                     (ansible/ansible#86794) — drop it from the task"
                ));
                return Ok(result);
            }
        }

        let state = args
            .get("state")
            .and_then(|v| v.as_str())
            .unwrap_or("present");
        if !matches!(state, "present" | "absent") {
            result.failed = true;
            result.msg = Some(format!(
                "yum_repository: 'state' must be 'present' or 'absent', got '{state}'"
            ));
            return Ok(result);
        }

        let file_base = args
            .get("file")
            .and_then(|v| v.as_str())
            .map(|s| s.to_string())
            .unwrap_or_else(|| name.clone());
        let path = std::path::PathBuf::from("/etc/yum.repos.d")
            .join(format!("{file_base}.repo"));

        let existing = std::fs::read_to_string(&path).ok();

        match state {
            "present" => {
                // Build the section body from the supported parameter set.
                let section = render_yum_repo_section(&name, args);
                let new_content = upsert_yum_repo_section(existing.as_deref(), &name, &section);
                let changed = existing.as_deref() != Some(new_content.as_str());
                if changed && !check_mode {
                    if let Some(parent) = path.parent() {
                        std::fs::create_dir_all(parent).map_err(|e| {
                            ExecutorError::TaskFailed(format!(
                                "yum_repository: mkdir {}: {e}",
                                parent.display()
                            ))
                        })?;
                    }
                    std::fs::write(&path, &new_content).map_err(|e| {
                        ExecutorError::TaskFailed(format!(
                            "yum_repository: write {}: {e}",
                            path.display()
                        ))
                    })?;
                }
                result.changed = changed;
                result.msg = Some(if changed {
                    format!("updated {}", path.display())
                } else {
                    format!("{} already up to date", path.display())
                });
            }
            "absent" => {
                if let Some(content) = existing {
                    let new_content = remove_yum_repo_section(&content, &name);
                    let trimmed = new_content.trim();
                    let removed = new_content != content;
                    if removed && !check_mode {
                        if trimmed.is_empty() {
                            std::fs::remove_file(&path).map_err(|e| {
                                ExecutorError::TaskFailed(format!(
                                    "yum_repository: rm {}: {e}",
                                    path.display()
                                ))
                            })?;
                        } else {
                            std::fs::write(&path, &new_content).map_err(|e| {
                                ExecutorError::TaskFailed(format!(
                                    "yum_repository: write {}: {e}",
                                    path.display()
                                ))
                            })?;
                        }
                    }
                    result.changed = removed;
                    result.msg = Some(if removed {
                        format!("removed [{}] from {}", name, path.display())
                    } else {
                        format!("[{}] not present in {}", name, path.display())
                    });
                } else {
                    result.msg = Some(format!("{} does not exist", path.display()));
                }
            }
            _ => unreachable!(),
        }

        result.results = serde_json::json!({
            "repo": name,
            "state": state,
            "file": path.display().to_string(),
        });
        Ok(result)
    }

    /// Implement the `git` module natively. Clone or update a local working
    /// copy by shelling out to the `git` binary.
    ///
    /// Supports: `repo` (URL, required), `dest` (path, required), `version`
    /// (branch/tag/SHA, default `HEAD`), `force` (default false — see #108),
    /// `update`, `clone`, `recursive` (submodules), `track_submodules`
    /// (see #110), `depth`, `single_branch`, `accept_hostkey`, `key_file`,
    /// `ssh_opts`, `executable`.
    ///
    /// **Per ansible/ansible#86860 (#108):** when `version` advances the
    /// remote past local commits on the current branch, the update fails
    /// unless `force: true` is set. Previously `force: true` was a hard
    /// reset that silently destroyed local commits — now `force: false`
    /// uses `git merge --ff-only` so non-fast-forward updates are rejected.
    ///
    /// **Per ansible/ansible#86692 (#110):** submodule updates use
    /// `git submodule update --remote` rather than hardcoding `master`, so
    /// each submodule tracks the branch configured in `.gitmodules` (or
    /// the remote HEAD if none is set).
    ///
    /// Out of scope: archive output, `verify_commit` / GPG, `separate_git_dir`,
    /// `bare`, `reference`, arbitrary `refspec`.
    async fn module_git(&self, args: &AnsibleValue) -> Result<TaskResult, ExecutorError> {
        let mut result = TaskResult::ok(self.host.clone());

        let repo = match args.get("repo").and_then(|v| v.as_str()) {
            Some(s) if !s.is_empty() => s.to_string(),
            _ => {
                result.failed = true;
                result.msg = Some("git: 'repo' is required".into());
                return Ok(result);
            }
        };
        let dest_str = match args.get("dest").and_then(|v| v.as_str()) {
            Some(s) if !s.is_empty() => s.to_string(),
            _ => {
                result.failed = true;
                result.msg = Some("git: 'dest' is required".into());
                return Ok(result);
            }
        };
        let dest = std::path::PathBuf::from(&dest_str);

        let version = args
            .get("version")
            .and_then(|v| v.as_str())
            .unwrap_or("HEAD")
            .to_string();
        let force = args.get("force").and_then(|v| v.as_bool()).unwrap_or(false);
        let update = args.get("update").and_then(|v| v.as_bool()).unwrap_or(true);
        let clone = args.get("clone").and_then(|v| v.as_bool()).unwrap_or(true);
        let recursive = args
            .get("recursive")
            .and_then(|v| v.as_bool())
            .unwrap_or(true);
        let track_submodules = args
            .get("track_submodules")
            .and_then(|v| v.as_bool())
            .unwrap_or(false);
        let depth = args.get("depth").and_then(|v| v.as_i64());
        let single_branch = args
            .get("single_branch")
            .and_then(|v| v.as_bool())
            .unwrap_or(false);
        let accept_hostkey = args
            .get("accept_hostkey")
            .and_then(|v| v.as_bool())
            .unwrap_or(false);
        let key_file = args.get("key_file").and_then(|v| v.as_str()).map(String::from);
        let ssh_opts = args
            .get("ssh_opts")
            .and_then(|v| v.as_str())
            .map(String::from);
        let git_path = args
            .get("executable")
            .and_then(|v| v.as_str())
            .unwrap_or("git")
            .to_string();
        let remote = args
            .get("remote")
            .and_then(|v| v.as_str())
            .unwrap_or("origin")
            .to_string();

        // Compose GIT_SSH_COMMAND so accept_hostkey / key_file / ssh_opts
        // apply uniformly to clone, fetch, and submodule fetches.
        let mut ssh_cmd_parts: Vec<String> = vec!["ssh".into()];
        if accept_hostkey {
            ssh_cmd_parts.push("-o".into());
            ssh_cmd_parts.push("StrictHostKeyChecking=no".into());
        }
        if let Some(k) = &key_file {
            ssh_cmd_parts.push("-i".into());
            ssh_cmd_parts.push(k.clone());
        }
        if let Some(extra) = &ssh_opts {
            ssh_cmd_parts.extend(extra.split_whitespace().map(String::from));
        }
        let git_ssh_command = ssh_cmd_parts.join(" ");

        let run_git =
            |args: Vec<String>, cwd: Option<&std::path::Path>| -> tokio::process::Command {
                let mut cmd = tokio::process::Command::new(&git_path);
                cmd.args(args);
                if let Some(d) = cwd {
                    cmd.current_dir(d);
                }
                cmd.env("GIT_TERMINAL_PROMPT", "0")
                    .env("GIT_SSH_COMMAND", &git_ssh_command);
                cmd
            };

        async fn exec(
            mut cmd: tokio::process::Command,
        ) -> Result<(i32, String, String), ExecutorError> {
            let out = cmd
                .output()
                .await
                .map_err(|e| ExecutorError::TaskFailed(format!("git: spawn failed: {e}")))?;
            Ok((
                out.status.code().unwrap_or(-1),
                String::from_utf8_lossy(&out.stdout).into_owned(),
                String::from_utf8_lossy(&out.stderr).into_owned(),
            ))
        }

        // Determine whether the destination is already a valid git working tree.
        let is_repo = dest.join(".git").exists();

        if !is_repo {
            if !clone {
                result.failed = true;
                result.msg = Some(format!(
                    "git: {} does not exist and clone=false",
                    dest.display()
                ));
                return Ok(result);
            }
            // Fresh clone.
            let mut clone_args: Vec<String> = vec!["clone".into(), repo.clone(), dest_str.clone()];
            if let Some(d) = depth {
                clone_args.push("--depth".into());
                clone_args.push(d.to_string());
            }
            if single_branch {
                clone_args.push("--single-branch".into());
            }
            if version != "HEAD" {
                clone_args.push("--branch".into());
                clone_args.push(version.clone());
            }
            let (rc, _out, err) = exec(run_git(clone_args, None)).await?;
            if rc != 0 {
                result.failed = true;
                result.msg = Some(format!("git clone failed: {err}"));
                return Ok(result);
            }
            result.changed = true;
        } else if update {
            // Fetch from origin.
            let (rc, _out, err) = exec(run_git(
                vec!["fetch".into(), remote.clone()],
                Some(&dest),
            ))
            .await?;
            if rc != 0 {
                result.failed = true;
                result.msg = Some(format!("git fetch failed: {err}"));
                return Ok(result);
            }

            // Resolve target: a branch -> remote/<branch>; tag/SHA stays as is.
            let target = resolve_git_target(
                &git_path,
                &dest,
                &remote,
                &version,
                &git_ssh_command,
            )
            .await?;

            // Detect divergence: are there local commits ahead of the remote?
            // `git rev-list --count HEAD ^<target>` returns the number of
            // commits on HEAD not in the target. > 0 means local commits exist.
            let (rc, ahead, _) = exec(run_git(
                vec![
                    "rev-list".into(),
                    "--count".into(),
                    "HEAD".into(),
                    format!("^{target}"),
                ],
                Some(&dest),
            ))
            .await?;
            let ahead_count: i64 = if rc == 0 {
                ahead.trim().parse().unwrap_or(0)
            } else {
                0
            };

            if ahead_count > 0 && !force {
                // ansible/ansible#86860: refuse to discard local commits.
                result.failed = true;
                result.msg = Some(format!(
                    "git: refusing to advance to {target} because \
                     {ahead_count} local commit(s) would be lost. \
                     Use `force: true` to overwrite them."
                ));
                return Ok(result);
            }

            // Apply the update.
            let update_cmd = if force {
                vec!["reset".into(), "--hard".into(), target.clone()]
            } else {
                // Fast-forward only — fails non-zero on divergence (which we
                // already rejected above, but defensive belt-and-braces).
                vec!["merge".into(), "--ff-only".into(), target.clone()]
            };
            let (rc, _out, err) = exec(run_git(update_cmd, Some(&dest))).await?;
            if rc != 0 {
                result.failed = true;
                result.msg = Some(format!("git update failed: {err}"));
                return Ok(result);
            }
            // Determine "changed" by comparing pre-update vs post-update SHA.
            let (_, head_after, _) = exec(run_git(
                vec!["rev-parse".into(), "HEAD".into()],
                Some(&dest),
            ))
            .await?;
            result.changed = !head_after.trim().is_empty()
                && head_after.trim() != target.trim_start_matches(&format!("{remote}/"));
        }

        if recursive && dest.join(".gitmodules").exists() {
            let sub_args = build_git_submodule_update_args(track_submodules, depth);
            let (rc, _out, err) = exec(run_git(sub_args, Some(&dest))).await?;
            if rc != 0 {
                result.failed = true;
                result.msg = Some(format!("git submodule update failed: {err}"));
                return Ok(result);
            }
        }

        // Report the final HEAD.
        let (_, head_sha, _) =
            exec(run_git(vec!["rev-parse".into(), "HEAD".into()], Some(&dest))).await?;
        result.results = serde_json::json!({
            "repo": repo,
            "dest": dest_str,
            "version": version,
            "after": head_sha.trim(),
        });
        result.msg = Some(format!("repo at {}", dest.display()));
        Ok(result)
    }

    /// Implement the `pacman` module natively (Arch Linux package management).
    ///
    /// Supports: `name` (string or list), `state` (present/installed,
    /// absent/removed, latest), `update_cache`, `force` (turns `-Sy` into
    /// `-Syy`), `upgrade` (full system upgrade `-Syu`), `extra_args`,
    /// `update_cache_extra_args`, `executable` (override binary, e.g. `yay`),
    /// `reason` (`explicit` / `dependency`, sets `--asexplicit` / `--asdeps`).
    async fn module_pacman(&self, args: &AnsibleValue) -> Result<TaskResult, ExecutorError> {
        let state = args
            .get("state")
            .and_then(|v| v.as_str())
            .unwrap_or("present");
        let update_cache = args
            .get("update_cache")
            .and_then(|v| v.as_bool())
            .unwrap_or(false);
        let force = args.get("force").and_then(|v| v.as_bool()).unwrap_or(false);
        let upgrade = args
            .get("upgrade")
            .and_then(|v| v.as_bool())
            .unwrap_or(false);
        let executable = args
            .get("executable")
            .and_then(|v| v.as_str())
            .unwrap_or("pacman")
            .to_string();
        let extra_args = parse_extra_args(args.get("extra_args"));
        let update_cache_extra_args =
            parse_extra_args(args.get("update_cache_extra_args"));
        let reason = args.get("reason").and_then(|v| v.as_str());

        let packages: Vec<String> = match args.get("name") {
            Some(AnsibleValue::String(s)) => {
                s.split(',').map(|p| p.trim().to_string()).filter(|p| !p.is_empty()).collect()
            }
            Some(AnsibleValue::Array(arr)) => arr
                .iter()
                .filter_map(|v| v.as_str().map(|s| s.to_string()))
                .collect(),
            _ => Vec::new(),
        };

        if !update_cache && !upgrade && packages.is_empty() {
            return Err(ExecutorError::TaskFailed(
                "pacman: at least one of 'name', 'update_cache', or 'upgrade' is required"
                    .into(),
            ));
        }

        let mut result = TaskResult::ok(self.host.clone());
        let mut combined_stdout = String::new();
        let mut combined_stderr = String::new();
        let mut last_rc: i32 = 0;

        // --- 1. update_cache (-Sy / -Syy) -----------------------------------
        if update_cache && !upgrade {
            let sync_flag = if force { "-Syy" } else { "-Sy" };
            let mut cmd = vec![
                executable.clone(),
                sync_flag.to_string(),
                "--noconfirm".to_string(),
            ];
            cmd.extend(update_cache_extra_args.iter().cloned());

            let output = run_pacman(&cmd).await?;
            combined_stdout.push_str(&output.stdout);
            combined_stderr.push_str(&output.stderr);
            last_rc = output.rc;
            if !output.success {
                result.failed = true;
                result.msg = Some(format!(
                    "{executable} {sync_flag} failed: {}",
                    output.stderr.trim()
                ));
                result.results = serde_json::json!({
                    "stdout": combined_stdout,
                    "stderr": combined_stderr,
                    "rc": last_rc,
                });
                return Ok(result);
            }
            // pacman -Sy always touches the local db, so we mark changed.
            result.changed = true;
        }

        // --- 2. upgrade (-Syu) ----------------------------------------------
        if upgrade {
            let upgrade_flag = if force { "-Syyu" } else { "-Syu" };
            let mut cmd = vec![
                executable.clone(),
                upgrade_flag.to_string(),
                "--noconfirm".to_string(),
            ];
            cmd.extend(extra_args.iter().cloned());

            let output = run_pacman(&cmd).await?;
            combined_stdout.push_str(&output.stdout);
            combined_stderr.push_str(&output.stderr);
            last_rc = output.rc;
            if !output.success {
                result.failed = true;
                result.msg = Some(format!(
                    "{executable} {upgrade_flag} failed: {}",
                    output.stderr.trim()
                ));
                result.results = serde_json::json!({
                    "stdout": combined_stdout,
                    "stderr": combined_stderr,
                    "rc": last_rc,
                });
                return Ok(result);
            }
            // " there is nothing to do" => no change; otherwise something was upgraded.
            if !output.stdout.contains("there is nothing to do") {
                result.changed = true;
            }
        }

        // --- 3. install / remove / latest -----------------------------------
        if !packages.is_empty() {
            let mode = match state {
                "absent" | "removed" => PacmanMode::Remove,
                "latest" => PacmanMode::Latest,
                "present" | "installed" => PacmanMode::Present,
                other => {
                    return Err(ExecutorError::TaskFailed(format!(
                        "pacman: unknown state '{other}'"
                    )));
                }
            };

            // Pre-filter packages so idempotent calls don't error out and so
            // we can report `changed=false` accurately.
            let installed = query_installed(&executable, &packages).await?;

            let to_act: Vec<String> = match mode {
                PacmanMode::Remove => packages
                    .iter()
                    .filter(|p| installed.contains(*p))
                    .cloned()
                    .collect(),
                PacmanMode::Present => packages
                    .iter()
                    .filter(|p| !installed.contains(*p))
                    .cloned()
                    .collect(),
                PacmanMode::Latest => packages.clone(),
            };

            if to_act.is_empty() && mode != PacmanMode::Latest {
                result.msg = Some(format!(
                    "{} {}",
                    match mode {
                        PacmanMode::Remove => "already absent:",
                        _ => "already present:",
                    },
                    packages.join(", ")
                ));
                result.results = serde_json::json!({
                    "stdout": combined_stdout,
                    "stderr": combined_stderr,
                    "rc": last_rc,
                });
                return Ok(result);
            }

            let mut cmd = vec![executable.clone()];
            match mode {
                PacmanMode::Remove => {
                    cmd.push("-R".to_string());
                    cmd.push("--noconfirm".to_string());
                }
                PacmanMode::Present => {
                    cmd.push("-S".to_string());
                    cmd.push("--needed".to_string());
                    cmd.push("--noconfirm".to_string());
                }
                PacmanMode::Latest => {
                    // -S without --needed reinstalls/upgrades to latest.
                    cmd.push("-S".to_string());
                    cmd.push("--noconfirm".to_string());
                }
            }
            match reason {
                Some("explicit") => cmd.push("--asexplicit".to_string()),
                Some("dependency") => cmd.push("--asdeps".to_string()),
                Some(other) => {
                    return Err(ExecutorError::TaskFailed(format!(
                        "pacman: invalid reason '{other}' (expected 'explicit' or 'dependency')"
                    )));
                }
                None => {}
            }
            cmd.extend(extra_args.iter().cloned());
            cmd.extend(to_act.iter().cloned());

            let output = run_pacman(&cmd).await?;
            combined_stdout.push_str(&output.stdout);
            combined_stderr.push_str(&output.stderr);
            last_rc = output.rc;

            if !output.success {
                result.failed = true;
                result.msg = Some(format!(
                    "{executable} {} failed: {}",
                    match mode {
                        PacmanMode::Remove => "remove",
                        PacmanMode::Latest => "latest",
                        PacmanMode::Present => "install",
                    },
                    output.stderr.trim()
                ));
                result.results = serde_json::json!({
                    "stdout": combined_stdout,
                    "stderr": combined_stderr,
                    "rc": last_rc,
                });
                return Ok(result);
            }

            // For `latest`, pacman -S prints "there is nothing to do" when
            // every named package is already current.
            let nothing_changed = mode == PacmanMode::Latest
                && output.stdout.contains("there is nothing to do");
            if !nothing_changed {
                result.changed = true;
            }
            result.msg = Some(format!(
                "{} {}",
                match mode {
                    PacmanMode::Remove => "removed",
                    PacmanMode::Latest => "upgraded",
                    PacmanMode::Present => "installed",
                },
                to_act.join(", ")
            ));
        }

        result.results = serde_json::json!({
            "stdout": combined_stdout,
            "stderr": combined_stderr,
            "rc": last_rc,
        });

        Ok(result)
    }

    /// Implement the `service` module natively.
    ///
    /// Supports: name, state (started/stopped/restarted/reloaded), enabled.
    async fn module_service(&self, args: &AnsibleValue) -> Result<TaskResult, ExecutorError> {
        let name = args
            .get("name")
            .and_then(|v| v.as_str())
            .ok_or_else(|| ExecutorError::TaskFailed("service: 'name' is required".into()))?;
        let state = args.get("state").and_then(|v| v.as_str());
        let enabled = args.get("enabled").and_then(|v| v.as_bool());

        let mut result = TaskResult::ok(self.host.clone());

        // Determine service manager (systemctl or service)
        let use_systemd = std::path::Path::new("/run/systemd/system").exists();

        if let Some(state) = state {
            let action = match state {
                "started" => "start",
                "stopped" => "stop",
                "restarted" => "restart",
                "reloaded" => "reload",
                _ => {
                    return Err(ExecutorError::TaskFailed(format!(
                        "service: unsupported state '{state}'"
                    )));
                }
            };

            // Check current status first to determine if change is needed
            let (is_running, _) = if use_systemd {
                let status = tokio::process::Command::new("systemctl")
                    .args(["is-active", name])
                    .output()
                    .await
                    .map_err(|e| ExecutorError::TaskFailed(format!("systemctl failed: {e}")))?;
                let stdout = String::from_utf8_lossy(&status.stdout).trim().to_string();
                (stdout == "active", stdout)
            } else {
                let status = tokio::process::Command::new("service")
                    .args([name, "status"])
                    .output()
                    .await
                    .map_err(|e| ExecutorError::TaskFailed(format!("service failed: {e}")))?;
                (status.status.success(), String::new())
            };

            // Determine if action is needed
            let needs_action = match action {
                "start" => !is_running,
                "stop" => is_running,
                "restart" | "reload" => true,
                _ => true,
            };

            if needs_action {
                let output = if use_systemd {
                    tokio::process::Command::new("systemctl")
                        .args([action, name])
                        .output()
                        .await
                } else {
                    tokio::process::Command::new("service")
                        .args([name, action])
                        .output()
                        .await
                };

                let output = output.map_err(|e| {
                    ExecutorError::TaskFailed(format!("service {action} failed: {e}"))
                })?;

                if !output.status.success() {
                    result.failed = true;
                    result.msg = Some(format!(
                        "service {action} {name} failed: {}",
                        String::from_utf8_lossy(&output.stderr)
                    ));
                    return Ok(result);
                }
                result.changed = true;
            }
        }

        if let Some(enabled) = enabled {
            // Check current enabled state
            let currently_enabled = if use_systemd {
                let output = tokio::process::Command::new("systemctl")
                    .args(["is-enabled", name])
                    .output()
                    .await
                    .map_err(|e| ExecutorError::TaskFailed(format!("systemctl failed: {e}")))?;
                String::from_utf8_lossy(&output.stdout).trim() == "enabled"
            } else {
                false // fallback: assume not enabled
            };

            if enabled != currently_enabled {
                let action = if enabled { "enable" } else { "disable" };
                let output = if use_systemd {
                    tokio::process::Command::new("systemctl")
                        .args([action, name])
                        .output()
                        .await
                } else {
                    tokio::process::Command::new("chkconfig")
                        .args([name, if enabled { "on" } else { "off" }])
                        .output()
                        .await
                };

                let output = output.map_err(|e| {
                    ExecutorError::TaskFailed(format!("service {action} failed: {e}"))
                })?;

                if !output.status.success() {
                    result.failed = true;
                    result.msg = Some(format!(
                        "service {action} {name} failed: {}",
                        String::from_utf8_lossy(&output.stderr)
                    ));
                    return Ok(result);
                }
                result.changed = true;
            }
        }

        result.msg = Some(format!("service {name} managed"));
        result.results = serde_json::json!({
            "name": name,
            "state": state,
            "enabled": enabled,
        });

        Ok(result)
    }

    /// Implement the `user` module natively.
    ///
    /// Supports: name, state (present/absent), uid, group, groups, shell,
    /// home, create_home, move_home, system, comment, remove (for absent).
    async fn module_user(&self, args: &AnsibleValue) -> Result<TaskResult, ExecutorError> {
        let name = args
            .get("name")
            .and_then(|v| v.as_str())
            .ok_or_else(|| ExecutorError::TaskFailed("user: 'name' is required".into()))?;
        let state = args
            .get("state")
            .and_then(|v| v.as_str())
            .unwrap_or("present");

        let mut result = TaskResult::ok(self.host.clone());

        // Check if user exists
        let user_exists = tokio::process::Command::new("id")
            .arg(name)
            .output()
            .await
            .map(|o| o.status.success())
            .unwrap_or(false);

        match state {
            "absent" => {
                if !user_exists {
                    result.msg = Some(format!("user {name} already absent"));
                    return Ok(result);
                }
                let remove = args
                    .get("remove")
                    .and_then(|v| v.as_bool())
                    .unwrap_or(false);
                let mut cmd_args = vec!["userdel".to_string()];
                if remove {
                    cmd_args.push("-r".to_string());
                }
                cmd_args.push(name.to_string());

                let output = tokio::process::Command::new(&cmd_args[0])
                    .args(&cmd_args[1..])
                    .output()
                    .await
                    .map_err(|e| ExecutorError::TaskFailed(format!("userdel failed: {e}")))?;

                if !output.status.success() {
                    result.failed = true;
                    result.msg = Some(format!(
                        "userdel failed: {}",
                        String::from_utf8_lossy(&output.stderr)
                    ));
                    return Ok(result);
                }
                result.changed = true;
                result.msg = Some(format!("user {name} removed"));
            }
            _ => {
                // present
                let mut cmd_args = if user_exists {
                    vec!["usermod".to_string()]
                } else {
                    vec!["useradd".to_string()]
                };

                if let Some(uid) = args.get("uid").and_then(|v| v.as_u64()) {
                    cmd_args.extend(["-u".to_string(), uid.to_string()]);
                }
                if let Some(group) = args.get("group").and_then(|v| v.as_str()) {
                    cmd_args.extend(["-g".to_string(), group.to_string()]);
                }
                if let Some(groups) = args.get("groups").and_then(|v| v.as_str()) {
                    cmd_args.extend(["-G".to_string(), groups.to_string()]);
                }
                if let Some(shell) = args.get("shell").and_then(|v| v.as_str()) {
                    cmd_args.extend(["-s".to_string(), shell.to_string()]);
                }
                let home_arg = args.get("home").and_then(|v| v.as_str());
                if let Some(home) = home_arg {
                    cmd_args.extend(["-d".to_string(), home.to_string()]);
                }
                if let Some(comment) = args.get("comment").and_then(|v| v.as_str()) {
                    cmd_args.extend(["-c".to_string(), comment.to_string()]);
                }
                let move_home = args
                    .get("move_home")
                    .and_then(|v| v.as_bool())
                    .unwrap_or(false);
                if user_exists && move_home && home_arg.is_some() {
                    cmd_args.push("-m".to_string());
                    // Alpine ships busybox; `usermod` exists only when the
                    // `shadow` package is installed. Without it, upstream's
                    // user module silently reported success without moving
                    // the home dir (upstream #85521 / PR #86810). Detect
                    // that case and fail clearly.
                    let (distro, _family) = parse_os_release();
                    if distro == "alpine" && !binary_in_path("usermod") {
                        result.failed = true;
                        result.msg = Some(
                            "user: move_home requires the 'shadow' package on Alpine (usermod not found in PATH)"
                                .to_string(),
                        );
                        return Ok(result);
                    }
                }
                if args
                    .get("system")
                    .and_then(|v| v.as_bool())
                    .unwrap_or(false)
                    && !user_exists
                {
                    cmd_args.push("-r".to_string());
                }
                let create_home = args
                    .get("create_home")
                    .and_then(|v| v.as_bool())
                    .unwrap_or(true);
                if !user_exists {
                    if create_home {
                        cmd_args.push("-m".to_string());
                    } else {
                        cmd_args.push("-M".to_string());
                    }
                }

                cmd_args.push(name.to_string());

                let output = tokio::process::Command::new(&cmd_args[0])
                    .args(&cmd_args[1..])
                    .output()
                    .await
                    .map_err(|e| {
                        ExecutorError::TaskFailed(format!(
                            "{} failed: {e}",
                            if user_exists { "usermod" } else { "useradd" }
                        ))
                    })?;

                if !output.status.success() {
                    result.failed = true;
                    result.msg = Some(format!(
                        "{} failed: {}",
                        if user_exists { "usermod" } else { "useradd" },
                        String::from_utf8_lossy(&output.stderr)
                    ));
                    return Ok(result);
                }
                result.changed = !user_exists;
                result.msg = Some(format!(
                    "user {name} {}",
                    if user_exists { "modified" } else { "created" }
                ));
            }
        }

        result.results = serde_json::json!({
            "name": name,
            "state": state,
        });

        Ok(result)
    }

    /// Implement the `group` module natively.
    ///
    /// Supports: name, state (present/absent), gid, system.
    async fn module_group(&self, args: &AnsibleValue) -> Result<TaskResult, ExecutorError> {
        let name = args
            .get("name")
            .and_then(|v| v.as_str())
            .ok_or_else(|| ExecutorError::TaskFailed("group: 'name' is required".into()))?;
        let state = args
            .get("state")
            .and_then(|v| v.as_str())
            .unwrap_or("present");

        let mut result = TaskResult::ok(self.host.clone());

        // Check if group exists
        let group_exists = tokio::process::Command::new("getent")
            .args(["group", name])
            .output()
            .await
            .map(|o| o.status.success())
            .unwrap_or(false);

        match state {
            "absent" => {
                if !group_exists {
                    result.msg = Some(format!("group {name} already absent"));
                    return Ok(result);
                }
                let output = tokio::process::Command::new("groupdel")
                    .arg(name)
                    .output()
                    .await
                    .map_err(|e| ExecutorError::TaskFailed(format!("groupdel failed: {e}")))?;

                if !output.status.success() {
                    result.failed = true;
                    result.msg = Some(format!(
                        "groupdel failed: {}",
                        String::from_utf8_lossy(&output.stderr)
                    ));
                    return Ok(result);
                }
                result.changed = true;
                result.msg = Some(format!("group {name} removed"));
            }
            _ => {
                if group_exists {
                    result.msg = Some(format!("group {name} already exists"));
                    return Ok(result);
                }
                let mut cmd_args = vec!["groupadd".to_string()];
                if let Some(gid) = args.get("gid").and_then(|v| v.as_u64()) {
                    cmd_args.extend(["-g".to_string(), gid.to_string()]);
                }
                if args
                    .get("system")
                    .and_then(|v| v.as_bool())
                    .unwrap_or(false)
                {
                    cmd_args.push("-r".to_string());
                }
                cmd_args.push(name.to_string());

                let output = tokio::process::Command::new(&cmd_args[0])
                    .args(&cmd_args[1..])
                    .output()
                    .await
                    .map_err(|e| ExecutorError::TaskFailed(format!("groupadd failed: {e}")))?;

                if !output.status.success() {
                    result.failed = true;
                    result.msg = Some(format!(
                        "groupadd failed: {}",
                        String::from_utf8_lossy(&output.stderr)
                    ));
                    return Ok(result);
                }
                result.changed = true;
                result.msg = Some(format!("group {name} created"));
            }
        }

        result.results = serde_json::json!({
            "name": name,
            "state": state,
        });

        Ok(result)
    }

    /// Implement the `package_facts` module natively.
    ///
    /// Gathers installed package information and sets `ansible_facts.packages`.
    async fn module_package_facts(&self, args: &AnsibleValue) -> Result<TaskResult, ExecutorError> {
        let manager = args
            .get("manager")
            .and_then(|v| v.as_str())
            .unwrap_or("auto");

        let mut result = TaskResult::ok(self.host.clone());
        let mut packages = serde_json::Map::new();

        // Detect package manager
        let use_dpkg = manager == "apt"
            || (manager == "auto" && std::path::Path::new("/usr/bin/dpkg").exists());
        let use_rpm = manager == "rpm"
            || manager == "yum"
            || manager == "dnf"
            || (manager == "auto"
                && !use_dpkg
                && std::path::Path::new("/usr/bin/rpm").exists());

        if use_dpkg {
            let output = tokio::process::Command::new("dpkg-query")
                .args(["-W", "-f", "${Package}\t${Version}\t${Architecture}\n"])
                .output()
                .await
                .map_err(|e| ExecutorError::TaskFailed(format!("dpkg-query failed: {e}")))?;

            if output.status.success() {
                let stdout = String::from_utf8_lossy(&output.stdout);
                for line in stdout.lines() {
                    let parts: Vec<&str> = line.split('\t').collect();
                    if parts.len() >= 2 {
                        let pkg_info = serde_json::json!([{
                            "name": parts[0],
                            "version": parts[1],
                            "arch": parts.get(2).unwrap_or(&""),
                            "source": "apt",
                        }]);
                        packages.insert(parts[0].to_string(), pkg_info);
                    }
                }
            }
        } else if use_rpm {
            let output = tokio::process::Command::new("rpm")
                .args(["-qa", "--queryformat", "%{NAME}\t%{VERSION}-%{RELEASE}\t%{ARCH}\n"])
                .output()
                .await
                .map_err(|e| ExecutorError::TaskFailed(format!("rpm failed: {e}")))?;

            if output.status.success() {
                let stdout = String::from_utf8_lossy(&output.stdout);
                for line in stdout.lines() {
                    let parts: Vec<&str> = line.split('\t').collect();
                    if parts.len() >= 2 {
                        let pkg_info = serde_json::json!([{
                            "name": parts[0],
                            "version": parts[1],
                            "arch": parts.get(2).unwrap_or(&""),
                            "source": "rpm",
                        }]);
                        packages.insert(parts[0].to_string(), pkg_info);
                    }
                }
            }
        }

        result.results = serde_json::json!({
            "ansible_facts": {
                "packages": packages,
            }
        });
        result.msg = Some(format!("gathered {} package facts", packages.len()));

        Ok(result)
    }

    /// Implement the `systemd` module natively.
    ///
    /// Supports: name, state, enabled, daemon_reload, scope.
    async fn module_systemd(&self, args: &AnsibleValue) -> Result<TaskResult, ExecutorError> {
        let daemon_reload = args
            .get("daemon_reload")
            .or_else(|| args.get("daemon-reload"))
            .and_then(|v| v.as_bool())
            .unwrap_or(false);
        let scope = args
            .get("scope")
            .and_then(|v| v.as_str())
            .unwrap_or("system");

        let mut result = TaskResult::ok(self.host.clone());
        let mut scope_args: Vec<&str> = Vec::new();
        if scope == "user" {
            scope_args.push("--user");
        }

        if daemon_reload {
            let mut cmd = tokio::process::Command::new("systemctl");
            cmd.args(&scope_args);
            cmd.arg("daemon-reload");
            let output = cmd
                .output()
                .await
                .map_err(|e| ExecutorError::TaskFailed(format!("systemctl daemon-reload failed: {e}")))?;
            if !output.status.success() {
                result.failed = true;
                result.msg = Some(format!(
                    "systemctl daemon-reload failed: {}",
                    String::from_utf8_lossy(&output.stderr)
                ));
                return Ok(result);
            }
            result.changed = true;
        }

        // If name is specified, delegate to the service module logic
        if let Some(name) = args.get("name").and_then(|v| v.as_str()) {
            let state = args.get("state").and_then(|v| v.as_str());
            let enabled = args.get("enabled").and_then(|v| v.as_bool());

            if let Some(state) = state {
                let action = match state {
                    "started" => "start",
                    "stopped" => "stop",
                    "restarted" => "restart",
                    "reloaded" => "reload",
                    _ => {
                        return Err(ExecutorError::TaskFailed(format!(
                            "systemd: unsupported state '{state}'"
                        )));
                    }
                };

                // Check current state
                let mut status_cmd = tokio::process::Command::new("systemctl");
                status_cmd.args(&scope_args);
                status_cmd.args(["is-active", name]);
                let status = status_cmd.output().await.map_err(|e| {
                    ExecutorError::TaskFailed(format!("systemctl is-active failed: {e}"))
                })?;
                let is_active = String::from_utf8_lossy(&status.stdout).trim() == "active";

                let needs_action = match action {
                    "start" => !is_active,
                    "stop" => is_active,
                    _ => true,
                };

                if needs_action {
                    let mut cmd = tokio::process::Command::new("systemctl");
                    cmd.args(&scope_args);
                    cmd.args([action, name]);
                    let output = cmd.output().await.map_err(|e| {
                        ExecutorError::TaskFailed(format!("systemctl {action} failed: {e}"))
                    })?;
                    if !output.status.success() {
                        result.failed = true;
                        result.msg = Some(format!(
                            "systemctl {action} {name} failed: {}",
                            String::from_utf8_lossy(&output.stderr)
                        ));
                        return Ok(result);
                    }
                    result.changed = true;
                }
            }

            if let Some(enabled) = enabled {
                let mut check_cmd = tokio::process::Command::new("systemctl");
                check_cmd.args(&scope_args);
                check_cmd.args(["is-enabled", name]);
                let check = check_cmd.output().await.map_err(|e| {
                    ExecutorError::TaskFailed(format!("systemctl is-enabled failed: {e}"))
                })?;
                let currently_enabled =
                    String::from_utf8_lossy(&check.stdout).trim() == "enabled";

                if enabled != currently_enabled {
                    let action = if enabled { "enable" } else { "disable" };
                    let mut cmd = tokio::process::Command::new("systemctl");
                    cmd.args(&scope_args);
                    cmd.args([action, name]);
                    let output = cmd.output().await.map_err(|e| {
                        ExecutorError::TaskFailed(format!("systemctl {action} failed: {e}"))
                    })?;
                    if !output.status.success() {
                        result.failed = true;
                        result.msg = Some(format!(
                            "systemctl {action} {name} failed: {}",
                            String::from_utf8_lossy(&output.stderr)
                        ));
                        return Ok(result);
                    }
                    result.changed = true;
                }
            }

            result.msg = Some(format!("systemd unit {name} managed"));
        } else if daemon_reload {
            result.msg = Some("systemctl daemon-reload done".into());
        } else {
            return Err(ExecutorError::TaskFailed(
                "systemd: either 'name' or 'daemon_reload' is required".into(),
            ));
        }

        Ok(result)
    }

    /// Apply `changed_when` overrides to the result.
    fn apply_changed_when(
        &self,
        mut result: TaskResult,
        templar: &Templar,
    ) -> Result<TaskResult, ExecutorError> {
        if self.task.changed_when.is_empty() {
            return Ok(result);
        }

        // All changed_when conditions must be true for changed=true
        let mut all_true = true;
        for condition in &self.task.changed_when {
            match templar.evaluate_conditional(condition) {
                Ok(true) => {}
                Ok(false) => {
                    all_true = false;
                    break;
                }
                Err(e) => {
                    warn!("changed_when evaluation failed: {}", e);
                    all_true = false;
                    break;
                }
            }
        }
        result.changed = all_true;
        Ok(result)
    }

    /// Apply `failed_when` overrides to the result.
    fn apply_failed_when(
        &self,
        mut result: TaskResult,
        templar: &Templar,
    ) -> Result<TaskResult, ExecutorError> {
        if self.task.failed_when.is_empty() {
            return Ok(result);
        }

        // Any failed_when condition being true means failure
        for condition in &self.task.failed_when {
            match templar.evaluate_conditional(condition) {
                Ok(true) => {
                    result.failed = true;
                    return Ok(result);
                }
                Ok(false) => {}
                Err(e) => {
                    warn!("failed_when evaluation failed: {}", e);
                }
            }
        }
        result.failed = false;
        Ok(result)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use ansible_inventory::InventoryManager;

    fn make_executor(task: Task) -> TaskExecutor {
        let inv = Arc::new(InventoryManager::new());
        let vm = Arc::new(VariableManager::new(inv));
        TaskExecutor::new("localhost".to_string(), task, vm)
    }

    fn make_debug_task(msg: &str) -> Task {
        Task {
            name: Some("test debug".into()),
            action: {
                let mut m = HashMap::new();
                m.insert(
                    "debug".into(),
                    serde_json::json!({"msg": msg}),
                );
                m
            },
            when_conditions: Vec::new(),
            register: None,
            loop_source: None,
            loop_items: None,
            with_items: None,
            loop_control: None,
            notify: Vec::new(),
            tags: Default::default(),
            use_become: None,
            become_user: None,
            become_method: None,
            become_flags: None,
            become_pass: None,
            delegate_to: None,
            ignore_errors: false,
            run_once: false,
            changed_when: Vec::new(),
            failed_when: Vec::new(),
            retries: 3,
            delay: 5,
            until: Vec::new(),
            no_log: false,
            args: None,
            environment: None,
            vars: None,
            block: None,
            rescue: None,
            always: None,
            connection: None,
            timeout: None,
            check_mode: None,
        }
    }

    #[tokio::test]
    async fn test_debug_module() {
        let task = make_debug_task("Hello World");
        let executor = make_executor(task);
        let result = executor.run().await.unwrap();
        assert!(!result.failed);
        assert_eq!(result.msg.as_deref(), Some("Hello World"));
    }

    #[tokio::test]
    async fn test_fail_module() {
        let task = Task {
            action: {
                let mut m = HashMap::new();
                m.insert(
                    "fail".into(),
                    serde_json::json!({"msg": "something broke"}),
                );
                m
            },
            ..make_debug_task("")
        };
        let executor = make_executor(task);
        let result = executor.run().await.unwrap();
        assert!(result.failed);
        assert_eq!(result.msg.as_deref(), Some("something broke"));
    }

    #[tokio::test]
    async fn test_when_false_skips() {
        let task = Task {
            when_conditions: vec!["false".into()],
            ..make_debug_task("should not run")
        };
        let executor = make_executor(task);
        let result = executor.run().await.unwrap();
        assert!(result.skipped);
    }

    #[tokio::test]
    async fn test_when_true_runs() {
        let task = Task {
            when_conditions: vec!["true".into()],
            ..make_debug_task("should run")
        };
        let executor = make_executor(task);
        let result = executor.run().await.unwrap();
        assert!(!result.skipped);
        assert_eq!(result.msg.as_deref(), Some("should run"));
    }

    #[tokio::test]
    async fn test_loop_execution() {
        let task = Task {
            loop_items: Some(serde_json::json!(["a", "b", "c"])),
            ..make_debug_task("item: {{ item }}")
        };
        let executor = make_executor(task);
        let result = executor.run().await.unwrap();
        assert!(!result.failed);
        // Should have loop results
        match &result.results {
            AnsibleValue::Array(arr) => assert_eq!(arr.len(), 3),
            _ => panic!("expected array of loop results"),
        }
    }

    #[tokio::test]
    async fn test_assert_module_pass() {
        let task = Task {
            action: {
                let mut m = HashMap::new();
                m.insert(
                    "assert".into(),
                    serde_json::json!({"that": ["true"]}),
                );
                m
            },
            ..make_debug_task("")
        };
        let executor = make_executor(task);
        let result = executor.run().await.unwrap();
        assert!(!result.failed);
    }

    #[tokio::test]
    async fn test_template_module_renders_and_is_idempotent() {
        let dir = tempfile::tempdir().unwrap();
        let src = dir.path().join("greet.j2");
        let dest = dir.path().join("greet.txt");
        std::fs::write(&src, "hello {{ name }}").unwrap();

        let task = Task {
            action: {
                let mut m = HashMap::new();
                m.insert(
                    "template".into(),
                    serde_json::json!({
                        "src": src.to_str().unwrap(),
                        "dest": dest.to_str().unwrap(),
                    }),
                );
                m
            },
            vars: Some({
                let mut v = HashMap::new();
                v.insert("name".into(), AnsibleValue::from("world"));
                v
            }),
            ..make_debug_task("")
        };
        let executor = make_executor(task);
        let r = executor.run().await.unwrap();
        assert!(!r.failed, "first run failed: {:?}", r.msg);
        assert!(r.changed);
        assert_eq!(std::fs::read_to_string(&dest).unwrap(), "hello world");

        // Second run: same vars → not changed.
        let r2 = executor.run().await.unwrap();
        assert!(!r2.failed);
        assert!(!r2.changed);
    }

    #[tokio::test]
    async fn test_lineinfile_present_and_absent() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("hosts");
        std::fs::write(&path, "alpha\nbeta\n").unwrap();

        // Add a new line.
        let task = Task {
            action: {
                let mut m = HashMap::new();
                m.insert(
                    "lineinfile".into(),
                    serde_json::json!({
                        "path": path.to_str().unwrap(),
                        "line": "gamma",
                    }),
                );
                m
            },
            ..make_debug_task("")
        };
        let r = make_executor(task).run().await.unwrap();
        assert!(r.changed);
        let after = std::fs::read_to_string(&path).unwrap();
        assert!(after.contains("gamma"));

        // Idempotent re-run.
        let task2 = Task {
            action: {
                let mut m = HashMap::new();
                m.insert(
                    "lineinfile".into(),
                    serde_json::json!({
                        "path": path.to_str().unwrap(),
                        "line": "gamma",
                    }),
                );
                m
            },
            ..make_debug_task("")
        };
        let r2 = make_executor(task2).run().await.unwrap();
        assert!(!r2.changed);

        // Replace via regexp.
        let task3 = Task {
            action: {
                let mut m = HashMap::new();
                m.insert(
                    "lineinfile".into(),
                    serde_json::json!({
                        "path": path.to_str().unwrap(),
                        "regexp": "^beta$",
                        "line": "BETA",
                    }),
                );
                m
            },
            ..make_debug_task("")
        };
        let r3 = make_executor(task3).run().await.unwrap();
        assert!(r3.changed);
        let after = std::fs::read_to_string(&path).unwrap();
        assert!(after.contains("BETA") && !after.contains("\nbeta\n"));

        // Remove via state=absent.
        let task4 = Task {
            action: {
                let mut m = HashMap::new();
                m.insert(
                    "lineinfile".into(),
                    serde_json::json!({
                        "path": path.to_str().unwrap(),
                        "line": "alpha",
                        "state": "absent",
                    }),
                );
                m
            },
            ..make_debug_task("")
        };
        let r4 = make_executor(task4).run().await.unwrap();
        assert!(r4.changed);
        let after = std::fs::read_to_string(&path).unwrap();
        assert!(!after.contains("alpha"));
    }

    #[tokio::test]
    async fn test_ping_module_returns_pong() {
        let task = Task {
            action: {
                let mut m = HashMap::new();
                m.insert("ping".into(), serde_json::json!({}));
                m
            },
            ..make_debug_task("")
        };
        let r = make_executor(task).run().await.unwrap();
        assert!(!r.failed && !r.changed);
        assert_eq!(r.results.get("ping").and_then(|v| v.as_str()), Some("pong"));
    }

    #[tokio::test]
    async fn test_slurp_module_reads_file_as_base64() {
        use base64::Engine;
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("secret.txt");
        std::fs::write(&path, b"hello world").unwrap();
        let task = Task {
            action: {
                let mut m = HashMap::new();
                m.insert(
                    "slurp".into(),
                    serde_json::json!({"src": path.to_str().unwrap()}),
                );
                m
            },
            ..make_debug_task("")
        };
        let r = make_executor(task).run().await.unwrap();
        assert!(!r.failed);
        let content = r.results.get("content").and_then(|v| v.as_str()).unwrap();
        let decoded = base64::engine::general_purpose::STANDARD
            .decode(content)
            .unwrap();
        assert_eq!(decoded, b"hello world");
    }

    #[tokio::test]
    async fn test_stat_module_returns_metadata() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("test.txt");
        std::fs::write(&path, "hello world").unwrap();

        let task = Task {
            action: {
                let mut m = HashMap::new();
                m.insert(
                    "stat".into(),
                    serde_json::json!({"path": path.to_str().unwrap()}),
                );
                m
            },
            ..make_debug_task("")
        };
        let r = make_executor(task).run().await.unwrap();
        assert!(!r.failed);
        let stat = r.results.get("stat").unwrap();
        assert_eq!(stat.get("exists").and_then(|v| v.as_bool()), Some(true));
        assert_eq!(stat.get("isreg").and_then(|v| v.as_bool()), Some(true));
        assert_eq!(stat.get("isdir").and_then(|v| v.as_bool()), Some(false));
        assert_eq!(stat.get("size").and_then(|v| v.as_u64()), Some(11));
        // Should have a checksum
        assert!(stat.get("checksum").and_then(|v| v.as_str()).is_some());
        // Should have mode on Unix
        #[cfg(unix)]
        {
            assert!(stat.get("mode").and_then(|v| v.as_str()).is_some());
            assert!(stat.get("uid").is_some());
            assert!(stat.get("gid").is_some());
        }
    }

    #[tokio::test]
    async fn test_stat_module_nonexistent() {
        let task = Task {
            action: {
                let mut m = HashMap::new();
                m.insert(
                    "stat".into(),
                    serde_json::json!({"path": "/nonexistent/path/xyz"}),
                );
                m
            },
            ..make_debug_task("")
        };
        let r = make_executor(task).run().await.unwrap();
        assert!(!r.failed);
        let stat = r.results.get("stat").unwrap();
        assert_eq!(stat.get("exists").and_then(|v| v.as_bool()), Some(false));
    }

    #[tokio::test]
    async fn test_wait_for_connection_local() {
        let task = Task {
            action: {
                let mut m = HashMap::new();
                m.insert(
                    "wait_for_connection".into(),
                    serde_json::json!({"timeout": 5}),
                );
                m
            },
            ..make_debug_task("")
        };
        let r = make_executor(task).run().await.unwrap();
        assert!(!r.failed, "wait_for_connection should succeed locally: {:?}", r.msg);
    }

    #[tokio::test]
    async fn test_include_tasks_executes_file() {
        let dir = tempfile::tempdir().unwrap();
        let tasks_file = dir.path().join("subtasks.yml");
        std::fs::write(
            &tasks_file,
            r#"
- name: sub task 1
  debug:
    msg: "from included file"
- name: sub task 2
  debug:
    msg: "second included"
"#,
        )
        .unwrap();

        let task = Task {
            action: {
                let mut m = HashMap::new();
                m.insert(
                    "include_tasks".into(),
                    serde_json::json!(tasks_file.to_str().unwrap()),
                );
                m
            },
            ..make_debug_task("")
        };
        let r = make_executor(task).run().await.unwrap();
        assert!(!r.failed, "include_tasks failed: {:?}", r.msg);
        assert_eq!(
            r.results.get("tasks_executed").and_then(|v| v.as_u64()),
            Some(2)
        );
    }

    #[tokio::test]
    async fn test_include_tasks_missing_file_fails() {
        let task = Task {
            action: {
                let mut m = HashMap::new();
                m.insert(
                    "include_tasks".into(),
                    serde_json::json!("/nonexistent/tasks.yml"),
                );
                m
            },
            ..make_debug_task("")
        };
        let r = make_executor(task).run().await.unwrap();
        assert!(r.failed);
    }

    #[tokio::test]
    async fn test_include_role_missing_role_fails() {
        std::env::remove_var("ANSIBLE_ROLES_PATH");
        let task = Task {
            action: {
                let mut m = HashMap::new();
                m.insert(
                    "include_role".into(),
                    serde_json::json!({"name": "nonexistent_role_xyz"}),
                );
                m
            },
            ..make_debug_task("")
        };
        let r = make_executor(task).run().await.unwrap();
        assert!(r.failed);
        assert!(
            r.msg.unwrap_or_default().contains("failed to load role"),
            "should mention role load failure"
        );
    }

    #[tokio::test]
    async fn test_ansiballz_fallback_returns_placeholder_when_no_library() {
        // Ensure ANSIBLE_LIBRARY is not pointing anywhere we control.
        std::env::remove_var("ANSIBLE_LIBRARY");
        let task = Task {
            action: {
                let mut m = HashMap::new();
                m.insert("nonexistent_module".into(), serde_json::json!({}));
                m
            },
            ..make_debug_task("")
        };
        let r = make_executor(task).run().await.unwrap();
        assert!(!r.failed);
        assert!(r.msg.unwrap_or_default().contains("not yet implemented"));
    }

    #[test]
    fn test_wrap_become_sudo() {
        let wrapped = wrap_become("echo hi", true, Some("sudo"), Some("deploy"), None, None);
        assert!(wrapped.contains("sudo"), "expected sudo: {wrapped}");
        assert!(wrapped.contains("-u deploy"), "expected -u deploy: {wrapped}");
        assert!(wrapped.contains("echo hi"), "expected command: {wrapped}");
    }

    #[test]
    fn test_wrap_become_noop_when_disabled() {
        let wrapped = wrap_become("echo hi", false, None, None, None, None);
        assert_eq!(wrapped, "echo hi");
    }

    #[test]
    fn test_wrap_become_su() {
        let wrapped = wrap_become("id", true, Some("su"), Some("root"), None, None);
        assert!(wrapped.starts_with("su"), "expected su: {wrapped}");
        assert!(wrapped.contains("root"), "expected root: {wrapped}");
        assert!(wrapped.contains("-c"), "expected -c: {wrapped}");
    }

    #[test]
    fn test_wrap_become_doas() {
        let wrapped = wrap_become("whoami", true, Some("doas"), Some("admin"), None, None);
        assert!(wrapped.starts_with("doas"), "expected doas: {wrapped}");
        assert!(wrapped.contains("-u admin"), "expected -u admin: {wrapped}");
        assert!(wrapped.contains("whoami"), "expected command: {wrapped}");
    }

    #[test]
    fn test_wrap_become_sudo_custom_flags() {
        let wrapped = wrap_become("ls", true, Some("sudo"), Some("root"), Some("-H -S"), None);
        assert!(wrapped.contains("sudo"), "expected sudo: {wrapped}");
        assert!(wrapped.contains("-H -S"), "expected custom flags: {wrapped}");
    }

    #[test]
    fn test_wrap_become_unknown_method_passthrough() {
        let wrapped = wrap_become("cmd", true, Some("unknown_method"), None, None, None);
        assert_eq!(wrapped, "cmd", "unknown method should pass through");
    }

    #[test]
    fn test_build_connection_defaults_local() {
        let vars = HashMap::new();
        let _ = build_connection("myhost", &vars, None, "root").unwrap();
    }

    #[test]
    fn test_build_connection_respects_explicit_ssh() {
        let mut vars = HashMap::new();
        vars.insert("ansible_connection".into(), AnsibleValue::from("ssh"));
        vars.insert("ansible_host".into(), AnsibleValue::from("1.2.3.4"));
        vars.insert("ansible_port".into(), AnsibleValue::from(2222_i64));
        let _ = build_connection("myhost", &vars, None, "root").unwrap();
    }

    #[test]
    fn test_build_connection_accepts_docker() {
        let mut vars = HashMap::new();
        vars.insert("ansible_connection".into(), AnsibleValue::from("docker"));
        vars.insert("ansible_host".into(), AnsibleValue::from("my_container"));
        let _ = build_connection("inv-host", &vars, None, "root").unwrap();
    }

    #[test]
    fn test_build_connection_accepts_podman() {
        let mut vars = HashMap::new();
        vars.insert("ansible_connection".into(), AnsibleValue::from("podman"));
        let _ = build_connection("my_container", &vars, None, "root").unwrap();
    }

    #[test]
    fn test_build_connection_rejects_paramiko() {
        let mut vars = HashMap::new();
        vars.insert("ansible_connection".into(), AnsibleValue::from("paramiko"));
        match build_connection("myhost", &vars, None, "root") {
            Ok(_) => panic!("paramiko should be rejected"),
            Err(ExecutorError::TaskFailed(msg)) => {
                assert!(
                    msg.contains("paramiko"),
                    "error should mention paramiko: {msg}"
                );
            }
            Err(e) => panic!("unexpected error variant: {:?}", e),
        }
    }

    #[test]
    fn test_build_connection_rejects_persistent() {
        let mut vars = HashMap::new();
        vars.insert("ansible_connection".into(), AnsibleValue::from("persistent"));
        match build_connection("myhost", &vars, None, "root") {
            Ok(_) => panic!("persistent alias should be rejected, not silently fall back to local"),
            Err(ExecutorError::TaskFailed(msg)) => {
                assert!(
                    msg.contains("persistent") && msg.contains("netcommon"),
                    "error should mention persistent + netcommon: {msg}"
                );
            }
            Err(e) => panic!("unexpected error variant: {:?}", e),
        }
    }

    fn make_executor_with_host(host: &str, task: Task) -> TaskExecutor {
        let inv = Arc::new(InventoryManager::new());
        let vm = Arc::new(VariableManager::new(inv));
        TaskExecutor::new(host.to_string(), task, vm)
    }

    #[test]
    fn test_resolve_delegate_none_when_unset() {
        let executor = make_executor_with_host("remote-1", make_debug_task(""));
        let resolved = executor.resolve_delegate(&HashMap::new()).unwrap();
        assert!(resolved.is_none());
    }

    #[test]
    fn test_resolve_delegate_literal() {
        let task = Task {
            delegate_to: Some("localhost".into()),
            ..make_debug_task("")
        };
        let executor = make_executor_with_host("remote-1", task);
        let (host, _vars) = executor.resolve_delegate(&HashMap::new()).unwrap().unwrap();
        assert_eq!(host, "localhost");
    }

    #[test]
    fn test_resolve_delegate_templated() {
        let task = Task {
            delegate_to: Some("{{ target }}".into()),
            ..make_debug_task("")
        };
        let executor = make_executor_with_host("remote-1", task);
        let mut vars = HashMap::new();
        vars.insert("target".into(), AnsibleValue::from("controller"));
        let (host, _vars) = executor.resolve_delegate(&vars).unwrap().unwrap();
        assert_eq!(host, "controller");
    }

    #[test]
    fn test_resolve_delegate_empty_errors() {
        let task = Task {
            delegate_to: Some("   ".into()),
            ..make_debug_task("")
        };
        let executor = make_executor_with_host("remote-1", task);
        match executor.resolve_delegate(&HashMap::new()) {
            Err(ExecutorError::TaskFailed(msg)) => {
                assert!(msg.contains("delegate_to"), "expected delegate_to error: {msg}");
            }
            other => panic!("expected TaskFailed for empty delegate_to, got {:?}", other),
        }
    }

    #[test]
    fn test_make_connection_delegate_to_localhost_succeeds() {
        // Inventory host is remote (would default to ssh), but delegate_to=localhost
        // must build a connection without surfacing the inventory host's vars.
        let task = Task {
            delegate_to: Some("localhost".into()),
            ..make_debug_task("")
        };
        let executor = make_executor_with_host("remote-host", task);
        let mut vars = HashMap::new();
        // ansible_host on the inventory host shouldn't be applied to the delegated conn.
        vars.insert("ansible_host".into(), AnsibleValue::from("10.0.0.99"));
        let _ = executor.make_connection(&vars).unwrap();
    }

    #[test]
    fn test_is_local_honors_delegate_to_localhost() {
        let task = Task {
            delegate_to: Some("localhost".into()),
            ..make_debug_task("")
        };
        let executor = make_executor_with_host("remote-host", task);
        assert!(
            executor.is_local(),
            "delegate_to=localhost on a remote host should be treated as local"
        );
    }

    #[test]
    fn test_is_local_delegate_to_remote_from_localhost_is_remote() {
        // Inventory host is localhost (would normally be local), but delegate_to
        // to a non-local host without ansible_connection=local should be remote.
        let task = Task {
            delegate_to: Some("remote-target".into()),
            ..make_debug_task("")
        };
        let executor = make_executor_with_host("localhost", task);
        assert!(
            !executor.is_local(),
            "delegate_to=remote-target from localhost should be treated as remote"
        );
    }

    #[tokio::test]
    async fn test_command_module_runs() {
        let task = Task {
            action: {
                let mut m = HashMap::new();
                m.insert("command".into(), serde_json::json!("echo hello"));
                m
            },
            ..make_debug_task("")
        };
        let executor = make_executor(task);
        let result = executor.run().await.unwrap();
        assert!(!result.failed);
        let stdout = result
            .results
            .get("stdout")
            .and_then(|v| v.as_str())
            .unwrap_or("");
        assert!(stdout.contains("hello"));
    }

    #[tokio::test]
    async fn test_command_module_failure() {
        let task = Task {
            action: {
                let mut m = HashMap::new();
                m.insert("command".into(), serde_json::json!("false"));
                m
            },
            ..make_debug_task("")
        };
        let executor = make_executor(task);
        let result = executor.run().await.unwrap();
        assert!(result.failed);
    }

    #[tokio::test]
    async fn test_file_module_directory_and_absent() {
        let dir = std::env::temp_dir().join(format!("ansrs-{}", std::process::id()));
        let dir_s = dir.to_string_lossy().into_owned();

        // Create directory
        let mk = Task {
            action: {
                let mut m = HashMap::new();
                m.insert(
                    "file".into(),
                    serde_json::json!({"path": dir_s, "state": "directory"}),
                );
                m
            },
            ..make_debug_task("")
        };
        let r = make_executor(mk).run().await.unwrap();
        assert!(!r.failed);
        assert!(r.changed);
        assert!(dir.is_dir());

        // Absent
        let rm = Task {
            action: {
                let mut m = HashMap::new();
                m.insert(
                    "file".into(),
                    serde_json::json!({"path": dir_s, "state": "absent"}),
                );
                m
            },
            ..make_debug_task("")
        };
        let r = make_executor(rm).run().await.unwrap();
        assert!(!r.failed);
        assert!(r.changed);
        assert!(!dir.exists());
    }

    #[tokio::test]
    async fn test_copy_module_content_idempotent() {
        let path = std::env::temp_dir().join(format!("ansrs-cp-{}", std::process::id()));
        let path_s = path.to_string_lossy().into_owned();
        let _ = std::fs::remove_file(&path);

        let mk = |content: &str| Task {
            action: {
                let mut m = HashMap::new();
                m.insert(
                    "copy".into(),
                    serde_json::json!({"dest": path_s, "content": content}),
                );
                m
            },
            ..make_debug_task("")
        };

        let r = make_executor(mk("hello")).run().await.unwrap();
        assert!(!r.failed);
        assert!(r.changed);

        // Second run with same content -> not changed
        let r = make_executor(mk("hello")).run().await.unwrap();
        assert!(!r.failed);
        assert!(!r.changed);

        // Different content -> changed
        let r = make_executor(mk("world")).run().await.unwrap();
        assert!(r.changed);
        assert_eq!(std::fs::read_to_string(&path).unwrap(), "world");

        let _ = std::fs::remove_file(&path);
    }

    #[tokio::test]
    async fn test_assert_module_fail() {
        let task = Task {
            action: {
                let mut m = HashMap::new();
                m.insert(
                    "assert".into(),
                    serde_json::json!({"that": ["false"], "fail_msg": "nope"}),
                );
                m
            },
            ..make_debug_task("")
        };
        let executor = make_executor(task);
        let result = executor.run().await.unwrap();
        assert!(result.failed);
        assert_eq!(result.msg.as_deref(), Some("nope"));
    }

    /// Build a shell command that increments a counter file on each
    /// invocation and exits 0 once the counter reaches `target`. Used by
    /// retries/until tests to simulate a flaky task that eventually
    /// succeeds. The local connection runs commands under `/bin/sh -c`,
    /// so we don't need to wrap the script in an extra shell invocation.
    fn counter_cmd(path: &str, target: u32) -> String {
        format!(
            "c=$(cat {p} 2>/dev/null || echo 0); c=$((c+1)); echo $c > {p}; test $c -ge {t}",
            p = path,
            t = target
        )
    }

    #[tokio::test]
    async fn test_retries_until_succeeds_on_first_try() {
        // No `until` set — a plain successful command runs exactly once.
        let task = Task {
            action: {
                let mut m = HashMap::new();
                m.insert("command".into(), serde_json::json!("true"));
                m
            },
            delay: 0,
            ..make_debug_task("")
        };
        let result = make_executor(task).run().await.unwrap();
        assert!(!result.failed);
        assert_eq!(result.attempts, 1);
    }

    #[tokio::test]
    async fn test_retries_until_passes_after_retries() {
        let dir = tempfile::tempdir().unwrap();
        let counter = dir.path().join("ctr");
        let counter_s = counter.to_string_lossy().into_owned();

        let task = Task {
            action: {
                let mut m = HashMap::new();
                m.insert("command".into(), serde_json::json!(counter_cmd(&counter_s, 3)));
                m
            },
            register: Some("r".into()),
            until: vec!["r.rc == 0".into()],
            retries: 5,
            delay: 0,
            ..make_debug_task("")
        };
        let result = make_executor(task).run().await.unwrap();
        assert!(!result.failed, "should have succeeded within retries: {:?}", result.msg);
        // Counter hits 3 on the 3rd attempt — rc==0 satisfies `until`.
        assert_eq!(result.attempts, 3);
    }

    #[tokio::test]
    async fn test_retries_exhausted_marks_task_failed() {
        let task = Task {
            action: {
                let mut m = HashMap::new();
                // Command that always fails (rc != 0).
                m.insert("command".into(), serde_json::json!("false"));
                m
            },
            register: Some("r".into()),
            until: vec!["r.rc == 0".into()],
            retries: 2,
            delay: 0,
            ..make_debug_task("")
        };
        let result = make_executor(task).run().await.unwrap();
        assert!(result.failed);
        assert_eq!(result.attempts, 2);
        assert!(result
            .msg
            .as_deref()
            .unwrap_or("")
            .contains("until condition never satisfied"));
    }

    #[tokio::test]
    async fn test_until_without_register_uses_fallback_binding() {
        // Succeed immediately; until refers to the internal fallback name.
        let task = Task {
            action: {
                let mut m = HashMap::new();
                m.insert("command".into(), serde_json::json!("true"));
                m
            },
            register: None,
            until: vec!["__retry_result__.rc == 0".into()],
            retries: 3,
            delay: 0,
            ..make_debug_task("")
        };
        let result = make_executor(task).run().await.unwrap();
        assert!(!result.failed);
        assert_eq!(result.attempts, 1);
    }

    /// Verify that host facts stored in the VariableManager are available
    /// to the template engine during task execution.  This tests the full
    /// chain: VariableManager.set_host_fact → get_vars → Templar → render.
    #[tokio::test]
    async fn test_host_facts_available_in_templates() {
        let inv = Arc::new(InventoryManager::new());
        let vm = Arc::new(VariableManager::new(inv));

        // Simulate facts gathered by the setup module (stored flat, matching
        // what the strategy layer does after extracting ansible_facts).
        vm.set_host_fact(
            "localhost",
            "ansible_hostname".into(),
            AnsibleValue::String("web01".into()),
        );
        vm.set_host_fact(
            "localhost",
            "ansible_os_family".into(),
            AnsibleValue::String("Debian".into()),
        );
        vm.set_host_fact(
            "localhost",
            "ansible_kernel".into(),
            AnsibleValue::String("6.1.0".into()),
        );

        // Run a debug task whose msg references those facts.
        let task = Task {
            action: {
                let mut m = HashMap::new();
                m.insert(
                    "debug".into(),
                    serde_json::json!({
                        "msg": "{{ ansible_hostname }} runs {{ ansible_os_family }} kernel {{ ansible_kernel }}"
                    }),
                );
                m
            },
            ..make_debug_task("")
        };
        let executor = TaskExecutor::new("localhost".to_string(), task, vm);
        let result = executor.run().await.unwrap();
        assert!(!result.failed, "task failed: {:?}", result.msg);
        assert_eq!(
            result.msg.as_deref(),
            Some("web01 runs Debian kernel 6.1.0")
        );
    }

    /// Verify that a `when` conditional referencing a host fact works.
    #[tokio::test]
    async fn test_when_conditional_uses_host_facts() {
        let inv = Arc::new(InventoryManager::new());
        let vm = Arc::new(VariableManager::new(inv));

        vm.set_host_fact(
            "localhost",
            "ansible_os_family".into(),
            AnsibleValue::String("RedHat".into()),
        );

        // Should run — the condition matches the fact.
        let task_runs = Task {
            when_conditions: vec!["ansible_os_family == 'RedHat'".into()],
            ..make_debug_task("ran on redhat")
        };
        let executor = TaskExecutor::new("localhost".to_string(), task_runs, vm.clone());
        let result = executor.run().await.unwrap();
        assert!(!result.skipped);
        assert_eq!(result.msg.as_deref(), Some("ran on redhat"));

        // Should skip — the condition does not match.
        let task_skips = Task {
            when_conditions: vec!["ansible_os_family == 'Debian'".into()],
            ..make_debug_task("should not run")
        };
        let executor2 = TaskExecutor::new("localhost".to_string(), task_skips, vm);
        let result2 = executor2.run().await.unwrap();
        assert!(result2.skipped);
    }

    /// Verify that set_fact results override gathered facts in the template
    /// engine, matching the 22-level precedence (set_fact=19 > host_facts=11).
    #[tokio::test]
    async fn test_set_fact_overrides_gathered_fact_in_template() {
        let inv = Arc::new(InventoryManager::new());
        let mut vm = Arc::new(VariableManager::new(inv));

        // Simulate a gathered fact.
        vm.set_host_fact(
            "localhost",
            "ansible_hostname".into(),
            AnsibleValue::String("original-host".into()),
        );
        // Simulate the strategy layer storing a set_fact at the higher
        // precedence level (nonpersistent_facts, level 19).
        Arc::get_mut(&mut vm)
            .expect("no other Arc references")
            .set_nonpersistent_fact(
                "localhost",
                "ansible_hostname".into(),
                AnsibleValue::String("overridden-host".into()),
            );

        let task = Task {
            action: {
                let mut m = HashMap::new();
                m.insert(
                    "debug".into(),
                    serde_json::json!({"msg": "{{ ansible_hostname }}"}),
                );
                m
            },
            ..make_debug_task("")
        };
        let executor = TaskExecutor::new("localhost".to_string(), task, vm);
        let result = executor.run().await.unwrap();
        assert!(!result.failed, "task failed: {:?}", result.msg);
        assert_eq!(result.msg.as_deref(), Some("overridden-host"));
    }

    fn make_pacman_task(args: serde_json::Value) -> Task {
        Task {
            action: {
                let mut m = HashMap::new();
                m.insert("pacman".into(), args);
                m
            },
            ..make_debug_task("")
        }
    }

    #[test]
    fn test_pacman_parse_extra_args_string_splits_on_whitespace() {
        let v = AnsibleValue::String("--needed --foo bar".into());
        assert_eq!(parse_extra_args(Some(&v)), vec!["--needed", "--foo", "bar"]);
    }

    #[test]
    fn test_pacman_parse_extra_args_array_keeps_each_element() {
        let v = AnsibleValue::Array(vec![
            AnsibleValue::String("--needed".into()),
            AnsibleValue::String("--ignore=linux".into()),
        ]);
        assert_eq!(parse_extra_args(Some(&v)), vec!["--needed", "--ignore=linux"]);
    }

    #[test]
    fn test_pacman_parse_extra_args_none_yields_empty() {
        assert!(parse_extra_args(None).is_empty());
    }

    #[tokio::test]
    async fn test_pacman_module_requires_one_of_name_update_cache_upgrade() {
        let task = make_pacman_task(serde_json::json!({}));
        let err = make_executor(task).run().await.unwrap_err();
        let msg = format!("{err:?}");
        assert!(
            msg.contains("at least one of 'name'"),
            "unexpected error: {msg}"
        );
    }

    #[tokio::test]
    async fn test_pacman_module_invalid_state_fails() {
        let task = make_pacman_task(serde_json::json!({
            "name": "vim",
            "state": "bogus",
        }));
        let err = make_executor(task).run().await.unwrap_err();
        let msg = format!("{err:?}");
        assert!(msg.contains("unknown state 'bogus'"), "unexpected error: {msg}");
    }

    #[tokio::test]
    async fn test_pacman_module_invalid_reason_fails() {
        // Use `executable: /bin/true` so the up-front query_installed step
        // succeeds (treating every package as not-installed) and we exercise
        // the install path, which is where reason validation lives.
        let task = make_pacman_task(serde_json::json!({
            "name": "vim",
            "executable": "/bin/false",
            "reason": "neither",
        }));
        let err = make_executor(task).run().await.unwrap_err();
        let msg = format!("{err:?}");
        assert!(msg.contains("invalid reason 'neither'"), "unexpected error: {msg}");
    }

    #[tokio::test]
    async fn test_pacman_query_installed_uses_exit_status() {
        // /bin/true exits 0 → every "package" reports as installed.
        let pkgs = vec!["alpha".to_string(), "beta".to_string()];
        let installed = query_installed("/bin/true", &pkgs).await.unwrap();
        assert_eq!(installed.len(), 2);
        assert!(installed.contains("alpha") && installed.contains("beta"));

        // /bin/false exits 1 → nothing is reported as installed.
        let installed = query_installed("/bin/false", &pkgs).await.unwrap();
        assert!(installed.is_empty());
    }

    #[test]
    fn test_binary_in_path_finds_sh() {
        // POSIX systems always have /bin/sh; this also confirms PATH lookup works.
        assert!(binary_in_path("sh"));
    }

    #[test]
    fn test_binary_in_path_rejects_missing() {
        assert!(!binary_in_path("ansible-core-rs-nonexistent-binary-xyz123"));
    }

    // -- apt_repository: validate_apt_source_line --
    // Per `sources.list(5)` and upstream ansible/ansible#85881.

    #[test]
    fn validate_apt_accepts_standard_deb_line() {
        assert!(
            validate_apt_source_line(
                "deb http://archive.ubuntu.com/ubuntu jammy main restricted universe"
            )
            .is_ok()
        );
    }

    #[test]
    fn validate_apt_accepts_deb_src_with_single_component() {
        assert!(
            validate_apt_source_line("deb-src http://archive.ubuntu.com/ubuntu jammy main").is_ok()
        );
    }

    #[test]
    fn validate_apt_accepts_bracketed_options() {
        // Single-token option block: `[signed-by=/usr/share/keyrings/foo.gpg]`
        assert!(
            validate_apt_source_line(
                "deb [signed-by=/usr/share/keyrings/foo.gpg] https://example.com/repo stable main"
            )
            .is_ok()
        );
        // Multi-token option block: `[arch=amd64 signed-by=...]`
        assert!(
            validate_apt_source_line(
                "deb [arch=amd64 signed-by=/k.gpg] https://example.com/repo stable main"
            )
            .is_ok()
        );
    }

    #[test]
    fn validate_apt_accepts_exact_path_suite() {
        // Trailing-slash suite ⇒ component must be absent.
        assert!(validate_apt_source_line("deb https://example.com/repo ./").is_ok());
    }

    #[test]
    fn validate_apt_rejects_unknown_type() {
        let err = validate_apt_source_line("rpm http://example.com/foo bar baz")
            .expect_err("rpm is not a valid apt source type");
        assert!(err.contains("type must be"), "msg: {err}");
    }

    #[test]
    fn validate_apt_rejects_missing_component_when_suite_is_codename() {
        // 'jammy' doesn't end in '/' so at least one component is required.
        let err = validate_apt_source_line("deb http://example.com/repo jammy")
            .expect_err("missing component should fail");
        assert!(err.contains("component"), "msg: {err}");
    }

    #[test]
    fn validate_apt_rejects_component_after_exact_path_suite() {
        let err = validate_apt_source_line("deb http://example.com/repo ./ main")
            .expect_err("components after a `/` suite are not allowed");
        assert!(err.contains("exact path"), "msg: {err}");
    }

    #[test]
    fn validate_apt_rejects_empty_and_truncated_lines() {
        assert!(validate_apt_source_line("").is_err());
        assert!(validate_apt_source_line("deb").is_err());
        assert!(validate_apt_source_line("deb http://example.com/repo").is_err());
    }

    #[test]
    fn validate_apt_rejects_unterminated_option_block() {
        let err = validate_apt_source_line("deb [arch=amd64 http://example.com jammy main")
            .expect_err("missing closing ']' should fail");
        assert!(err.contains("closing ']'"), "msg: {err}");
    }

    #[test]
    fn normalize_source_line_collapses_whitespace() {
        assert_eq!(
            normalize_source_line("deb   http://x/y   jammy   main\t restricted "),
            "deb http://x/y jammy main restricted"
        );
    }

    #[test]
    fn default_apt_filename_derives_from_uri_host() {
        assert_eq!(
            default_apt_filename("deb http://archive.ubuntu.com/ubuntu jammy main"),
            "archive_ubuntu_com"
        );
        assert_eq!(
            default_apt_filename("deb [arch=amd64] https://repo.example.org/x stable main"),
            "repo_example_org"
        );
    }

    #[test]
    fn default_apt_filename_falls_back_when_no_uri() {
        assert_eq!(default_apt_filename("deb jammy main"), "ansible");
    }

    // -- follow_redirects parsing for uri/get_url --
    // Per upstream ansible/ansible#86793: 'yes'/'no' aliases were removed;
    // only 'all', 'none', 'safe', 'urllib2' are accepted.

    #[cfg(feature = "http")]
    #[test]
    fn follow_redirects_accepts_canonical_values() {
        for v in ["all", "none", "safe", "urllib2"] {
            assert!(
                parse_follow_redirects(Some(&AnsibleValue::from(v)), "GET").is_ok(),
                "expected '{v}' to be accepted"
            );
        }
    }

    #[cfg(feature = "http")]
    #[test]
    fn follow_redirects_defaults_to_safe_when_omitted() {
        assert!(parse_follow_redirects(None, "GET").is_ok());
        assert!(parse_follow_redirects(None, "POST").is_ok());
    }

    #[cfg(feature = "http")]
    #[test]
    fn follow_redirects_rejects_legacy_yes_no() {
        let err = parse_follow_redirects(Some(&AnsibleValue::from("yes")), "GET")
            .expect_err("'yes' must be rejected post-ansible/ansible#86793");
        assert!(err.contains("removed") && err.contains("'all'"), "msg: {err}");

        let err = parse_follow_redirects(Some(&AnsibleValue::from("no")), "GET")
            .expect_err("'no' must be rejected post-ansible/ansible#86793");
        assert!(err.contains("removed") && err.contains("'none'"), "msg: {err}");
    }

    #[cfg(feature = "http")]
    #[test]
    fn follow_redirects_rejects_boolean_form() {
        let err = parse_follow_redirects(Some(&AnsibleValue::Bool(true)), "GET")
            .expect_err("boolean form should not be accepted");
        assert!(err.contains("boolean"), "msg: {err}");
    }

    #[cfg(feature = "http")]
    #[test]
    fn follow_redirects_rejects_unknown_value() {
        let err = parse_follow_redirects(Some(&AnsibleValue::from("maybe")), "GET")
            .expect_err("unknown value should be rejected");
        assert!(err.contains("invalid value"), "msg: {err}");
    }

    // -- uri body_format helpers --
    // Cover the form-urlencoded flattening and form-multipart construction
    // (ansible/ansible#86687 replaced stdlib `email` MIME generation).

    #[cfg(feature = "http")]
    #[test]
    fn flatten_form_body_handles_scalars_and_arrays() {
        let body = AnsibleValue::Object(
            serde_json::from_value(serde_json::json!({
                "name": "alice",
                "age": 30,
                "admin": true,
                "tag": ["red", "green"],
                "skip": null,
            }))
            .unwrap(),
        );
        let pairs = flatten_form_body(&body).expect("flatten");
        let as_map: std::collections::HashMap<_, _> =
            pairs.iter().map(|(k, v)| (k.as_str(), v.as_str())).collect();
        assert_eq!(as_map.get("name").copied(), Some("alice"));
        assert_eq!(as_map.get("age").copied(), Some("30"));
        assert_eq!(as_map.get("admin").copied(), Some("true"));
        // Array entries should appear as repeated keys.
        let tag_values: Vec<&str> = pairs
            .iter()
            .filter(|(k, _)| k == "tag")
            .map(|(_, v)| v.as_str())
            .collect();
        assert_eq!(tag_values.len(), 2);
        assert!(tag_values.contains(&"red") && tag_values.contains(&"green"));
        // Null fields are dropped, not stringified.
        assert!(!as_map.contains_key("skip"));
    }

    #[cfg(feature = "http")]
    #[test]
    fn flatten_form_body_rejects_nested_object() {
        let body = AnsibleValue::Object(
            serde_json::from_value(serde_json::json!({
                "outer": {"inner": "x"},
            }))
            .unwrap(),
        );
        let err =
            flatten_form_body(&body).expect_err("nested objects need form-multipart, not urlencoded");
        assert!(err.contains("form-multipart"), "msg: {err}");
    }

    #[cfg(feature = "http")]
    #[test]
    fn flatten_form_body_rejects_non_object_root() {
        let body = AnsibleValue::from("just a string");
        assert!(flatten_form_body(&body).is_err());
    }

    #[cfg(feature = "http")]
    #[test]
    fn build_multipart_form_accepts_scalars_and_file_objects() {
        let body = AnsibleValue::Object(
            serde_json::from_value(serde_json::json!({
                "field_a": "value_a",
                "count": 7,
                "file": {
                    "content": "abc",
                    "filename": "report.txt",
                    "mime_type": "text/plain",
                },
            }))
            .unwrap(),
        );
        // We can't introspect the Form's body without sending it, but we can
        // at least assert construction succeeds for the supported shapes.
        let _form = build_multipart_form(&body).expect("multipart form");
    }

    #[cfg(feature = "http")]
    #[test]
    fn build_multipart_form_rejects_file_object_without_content() {
        let body = AnsibleValue::Object(
            serde_json::from_value(serde_json::json!({
                "file": {"filename": "report.txt"},
            }))
            .unwrap(),
        );
        let err = build_multipart_form(&body)
            .expect_err("file object must carry a 'content' field");
        assert!(err.contains("content"), "msg: {err}");
    }

    #[cfg(feature = "http")]
    #[test]
    fn build_multipart_form_rejects_invalid_mime_type() {
        let body = AnsibleValue::Object(
            serde_json::from_value(serde_json::json!({
                "file": {
                    "content": "x",
                    "mime_type": "not a mime",
                },
            }))
            .unwrap(),
        );
        assert!(build_multipart_form(&body).is_err());
    }

    // -- yum_repository helpers --

    #[test]
    fn yum_repo_section_renders_canonical_fields() {
        let args = AnsibleValue::Object(
            serde_json::from_value(serde_json::json!({
                "description": "My Repo",
                "baseurl": "https://repo.example.com/x",
                "enabled": true,
                "gpgcheck": false,
                "gpgkey": "https://repo.example.com/key",
                "priority": 5,
            }))
            .unwrap(),
        );
        let body = render_yum_repo_section("myrepo", &args);
        assert!(body.starts_with("[myrepo]\n"), "body: {body}");
        assert!(body.contains("name=My Repo"), "body: {body}");
        assert!(body.contains("baseurl=https://repo.example.com/x"), "body: {body}");
        assert!(body.contains("enabled=1"), "body: {body}");
        assert!(body.contains("gpgcheck=0"), "body: {body}");
        assert!(body.contains("gpgkey=https://repo.example.com/key"), "body: {body}");
        assert!(body.contains("priority=5"), "body: {body}");
    }

    #[test]
    fn yum_repo_section_uses_name_when_description_missing() {
        let args = AnsibleValue::Object(serde_json::from_value(serde_json::json!({})).unwrap());
        let body = render_yum_repo_section("myrepo", &args);
        // Falls back to the repo id for the human-readable name line.
        assert!(body.contains("name=myrepo"), "body: {body}");
    }

    #[test]
    fn yum_repo_section_joins_multiple_baseurls() {
        let args = AnsibleValue::Object(
            serde_json::from_value(serde_json::json!({
                "baseurl": ["https://a/", "https://b/"],
            }))
            .unwrap(),
        );
        let body = render_yum_repo_section("r", &args);
        // dnf accepts multiple baseurls on continuation lines; the indentation
        // is decorative but matches what Python's ConfigParser emits.
        assert!(body.contains("baseurl=https://a/\n        https://b/"), "body: {body}");
    }

    #[test]
    fn upsert_yum_inserts_when_file_empty() {
        let section = "[myrepo]\nname=test\nbaseurl=https://x\nenabled=1\n";
        let out = upsert_yum_repo_section(None, "myrepo", section);
        assert_eq!(out, section);
    }

    #[test]
    fn upsert_yum_replaces_existing_section_in_place() {
        let existing = "\
[other]
name=other repo
baseurl=https://other/

[myrepo]
name=old name
baseurl=https://old/
enabled=0

[trailing]
name=trailing
";
        let new_section = "[myrepo]\nname=new name\nbaseurl=https://new/\nenabled=1\n";
        let out = upsert_yum_repo_section(Some(existing), "myrepo", new_section);
        // Old section gone, new section present, [other] and [trailing] preserved.
        assert!(!out.contains("name=old name"), "out: {out}");
        assert!(out.contains("name=new name"), "out: {out}");
        assert!(out.contains("[other]"), "out: {out}");
        assert!(out.contains("[trailing]"), "out: {out}");
    }

    #[test]
    fn upsert_yum_appends_when_section_absent() {
        let existing = "[other]\nname=other\nbaseurl=https://other/\n";
        let new_section = "[myrepo]\nname=new\nbaseurl=https://new/\n";
        let out = upsert_yum_repo_section(Some(existing), "myrepo", new_section);
        assert!(out.contains("[other]"), "out: {out}");
        assert!(out.ends_with(new_section), "out: {out}");
    }

    #[test]
    fn remove_yum_strips_named_section_only() {
        let existing = "\
[a]
name=a
baseurl=https://a/

[b]
name=b
baseurl=https://b/

[c]
name=c
baseurl=https://c/
";
        let out = remove_yum_repo_section(existing, "b");
        assert!(out.contains("[a]"), "out: {out}");
        assert!(out.contains("[c]"), "out: {out}");
        assert!(!out.contains("[b]"), "out: {out}");
        assert!(!out.contains("https://b/"), "out: {out}");
    }

    #[test]
    fn remove_yum_no_op_when_section_absent() {
        let existing = "[a]\nname=a\n";
        let out = remove_yum_repo_section(existing, "missing");
        assert_eq!(out, existing);
    }

    // -- git module helpers --

    #[test]
    fn git_submodule_update_args_omit_remote_when_track_disabled() {
        let a = build_git_submodule_update_args(false, None);
        assert!(a.starts_with(&["submodule".into(), "update".into(), "--init".into()]));
        assert!(a.contains(&"--recursive".to_string()));
        assert!(
            !a.contains(&"--remote".to_string()),
            "without track_submodules, --remote must not appear: {a:?}"
        );
    }

    #[test]
    fn git_submodule_update_args_include_remote_when_track_enabled() {
        // Per ansible/ansible#86692 (#110): track_submodules must lead to
        // `git submodule update --remote`, which reads the branch from
        // .gitmodules instead of using a hardcoded `master`.
        let a = build_git_submodule_update_args(true, None);
        assert!(
            a.contains(&"--remote".to_string()),
            "with track_submodules, --remote must appear: {a:?}"
        );
    }

    #[test]
    fn git_submodule_update_args_pass_depth_when_set() {
        let a = build_git_submodule_update_args(true, Some(5));
        let pos = a
            .iter()
            .position(|s| s == "--depth")
            .expect("--depth must be present when depth is Some");
        assert_eq!(a[pos + 1], "5");
    }

    /// End-to-end-ish: spin up a bare repo + working clone, then verify that
    /// `resolve_git_target("HEAD")` and `resolve_git_target("<existing-branch>")`
    /// produce the expected fully-qualified remote refs. Uses the system
    /// `git` binary (provided by the nix dev shell).
    #[tokio::test]
    async fn resolve_git_target_against_local_bare_repo() {
        if !binary_in_path("git") {
            eprintln!("skipping: git binary not in PATH");
            return;
        }
        let tmp = tempfile::tempdir().expect("tempdir");
        let bare = tmp.path().join("upstream.git");
        let work = tmp.path().join("work");

        // Init a bare repo with one commit on a deterministic branch name.
        let mk = |args: &[&str], cwd: &std::path::Path| {
            std::process::Command::new("git")
                .args(args)
                .current_dir(cwd)
                .env("GIT_AUTHOR_NAME", "t")
                .env("GIT_AUTHOR_EMAIL", "t@t")
                .env("GIT_COMMITTER_NAME", "t")
                .env("GIT_COMMITTER_EMAIL", "t@t")
                .output()
                .expect("git invocation failed")
        };
        std::fs::create_dir_all(&bare).unwrap();
        let out = mk(&["init", "--bare", "-b", "main", "."], &bare);
        assert!(out.status.success(), "init bare: {out:?}");

        // Seed by cloning, committing, and pushing back to the bare repo.
        let seed = tmp.path().join("seed");
        let out = std::process::Command::new("git")
            .args(["clone", bare.to_str().unwrap(), seed.to_str().unwrap()])
            .output()
            .expect("seed clone");
        assert!(out.status.success(), "seed clone: {out:?}");
        std::fs::write(seed.join("hello.txt"), "hi").unwrap();
        let out = mk(&["add", "."], &seed);
        assert!(out.status.success(), "add: {out:?}");
        let out = mk(&["commit", "-m", "seed"], &seed);
        assert!(out.status.success(), "commit: {out:?}");
        let out = mk(&["push", "origin", "main"], &seed);
        assert!(out.status.success(), "push: {out:?}");

        // Clone for the test working tree.
        let out = std::process::Command::new("git")
            .args(["clone", bare.to_str().unwrap(), work.to_str().unwrap()])
            .output()
            .expect("clone");
        assert!(out.status.success(), "clone: {out:?}");

        // HEAD should resolve to origin/HEAD.
        let target = resolve_git_target("git", &work, "origin", "HEAD", "ssh")
            .await
            .expect("resolve HEAD");
        assert_eq!(target, "origin/HEAD");

        // Known branch resolves to origin/<branch>.
        let target = resolve_git_target("git", &work, "origin", "main", "ssh")
            .await
            .expect("resolve main");
        assert_eq!(target, "origin/main");

        // Unknown ref / SHA passes through as-is.
        let target = resolve_git_target("git", &work, "origin", "deadbeef", "ssh")
            .await
            .expect("resolve unknown");
        assert_eq!(target, "deadbeef");
    }
}
