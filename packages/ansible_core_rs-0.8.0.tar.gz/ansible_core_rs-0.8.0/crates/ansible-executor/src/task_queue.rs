//! TaskQueueManager — orchestrates execution of one or more plays.
//!
//! This is the top-level driver of the execution engine. Given a list of
//! plays and a resolved inventory, it:
//!
//! 1. Picks a strategy plugin for each play (`linear`, `free`, or
//!    `host_pinned`).
//! 2. Builds a [`PlayIterator`] for the play's host list.
//! 3. Delegates to the strategy, which walks every host through the
//!    standard pre_tasks → roles → tasks → post_tasks → handlers pipeline
//!    and flushes handlers at the end of the play.
//! 4. Aggregates per-host stats across all plays into a single
//!    [`AggregateStats`] for the final recap.
//!
//! The previous version of this file was a stub that naively iterated
//! `play.tasks` and never touched pre_tasks, post_tasks, handlers, or the
//! strategy layer. It's now the real entry point that `ansible-playbook`
//! should call for each play.

use std::sync::Arc;

use ansible_playbook::{Play, SerialSpec};
use ansible_utils::{AggregateStats, TaskResult};
use ansible_vars::VariableManager;

use crate::play_iterator::PlayIterator;
use crate::strategy::{free::FreeStrategy, host_pinned::HostPinnedStrategy, linear::LinearStrategy, StrategyPlugin};
use crate::ExecutorError;

/// Drives execution of one or more plays against a set of hosts.
///
/// Not itself `Send + Sync` — callers that want to run multiple
/// TaskQueueManagers concurrently should construct one per play batch.
pub struct TaskQueueManager {
    variable_manager: Arc<VariableManager>,
    forks: usize,
    stats: AggregateStats,
    check_mode: bool,
}

/// Outcome of running one or more plays. Mirrors ansible's exit-code
/// semantics: any failed/unreachable host flips `all_ok` to false.
pub struct RunResult {
    pub results: Vec<TaskResult>,
    pub all_ok: bool,
}

impl TaskQueueManager {
    pub fn new(variable_manager: Arc<VariableManager>, forks: usize) -> Self {
        Self {
            variable_manager,
            forks,
            stats: AggregateStats::new(),
            check_mode: false,
        }
    }

    /// Set the check-mode flag for all plays run through this manager.
    pub fn with_check_mode(mut self, check_mode: bool) -> Self {
        self.check_mode = check_mode;
        self
    }

    /// Aggregate stats accumulated so far across every `run_play` call.
    pub fn stats(&self) -> &AggregateStats {
        &self.stats
    }

    /// Run a single play across `hosts`, walking the full phase machine
    /// (pre_tasks → tasks → post_tasks → handler flush) through the
    /// strategy plugin selected by `play.strategy`.
    ///
    /// Honors `play.serial`: when set, the host list is split into
    /// rolling batches and the strategy runs once per batch with a fresh
    /// iterator, mirroring Python Ansible's rolling-update semantics. A
    /// batch whose strategy reports `all_ok == false` flips the play's
    /// overall result and, when `any_errors_fatal` is set, aborts the
    /// remaining batches.
    pub async fn run_play(
        &mut self,
        play: &Play,
        hosts: &[String],
    ) -> Result<RunResult, ExecutorError> {
        let batches = resolve_serial_batches(hosts.len(), &play.serial);
        let batched_hosts: Vec<Vec<String>> = if batches.is_empty() {
            vec![hosts.to_vec()]
        } else {
            let mut out = Vec::new();
            let mut idx = 0;
            for size in batches {
                if idx >= hosts.len() {
                    break;
                }
                let end = (idx + size).min(hosts.len());
                out.push(hosts[idx..end].to_vec());
                idx = end;
            }
            out
        };

        let mut all_results = Vec::new();
        let mut all_ok = true;
        for batch in batched_hosts {
            if batch.is_empty() {
                continue;
            }
            let mut iterator = PlayIterator::new(play.clone(), &batch);
            let strategy = pick_strategy(&play.strategy);
            let outcome = strategy
                .run(
                    &mut iterator,
                    self.variable_manager.clone(),
                    &mut self.stats,
                    self.forks,
                    self.check_mode,
                )
                .await?;
            all_results.extend(outcome.results);
            if !outcome.all_ok {
                all_ok = false;
                if play.any_errors_fatal.unwrap_or(false) {
                    break;
                }
            }
        }

        Ok(RunResult {
            results: all_results,
            all_ok,
        })
    }

    /// Run an entire playbook (a list of plays). Plays execute
    /// sequentially — ansible runs them in file order regardless of
    /// strategy. Returns a flat list of every task result across every
    /// play, and an overall ok/not-ok flag.
    pub async fn run_playbook(
        &mut self,
        plays: &[(Play, Vec<String>)],
    ) -> Result<RunResult, ExecutorError> {
        let mut all_results = Vec::new();
        let mut all_ok = true;
        for (play, hosts) in plays {
            let r = self.run_play(play, hosts).await?;
            all_results.extend(r.results);
            if !r.all_ok {
                all_ok = false;
                // Respect `any_errors_fatal` on the play: if set and the
                // play did not complete cleanly, stop the whole playbook.
                if play.any_errors_fatal.unwrap_or(false) {
                    break;
                }
            }
        }
        Ok(RunResult {
            results: all_results,
            all_ok,
        })
    }
}

fn pick_strategy(name: &str) -> Box<dyn StrategyPlugin> {
    match name {
        "free" => Box::new(FreeStrategy),
        "host_pinned" => Box::new(HostPinnedStrategy),
        "linear" | "" => Box::new(LinearStrategy),
        _ => Box::new(LinearStrategy),
    }
}

/// Resolve a play's `serial:` spec into a concrete list of batch sizes
/// that cover `total` hosts.
///
/// Mirrors Python Ansible's rolling-update semantics:
/// - An empty spec returns an empty vec (caller treats it as "one batch
///   with every host").
/// - `Count(n)` contributes a batch of `n` hosts (clamped to the remaining
///   host count).
/// - `Percentage("25%")` contributes `ceil(total * 25 / 100)` hosts,
///   with a minimum of 1. Bad strings fall back to "everyone remaining".
/// - When the spec list is exhausted but hosts remain, the **last** spec
///   is repeated, matching Ansible's behavior where `serial: [1, 5]`
///   against 20 hosts produces batches of 1, 5, 5, 5, 4.
pub fn resolve_serial_batches(total: usize, specs: &[SerialSpec]) -> Vec<usize> {
    if specs.is_empty() || total == 0 {
        return Vec::new();
    }

    let resolve_one = |spec: &SerialSpec, remaining: usize| -> usize {
        match spec {
            SerialSpec::Count(n) => (*n).min(remaining),
            SerialSpec::Percentage(s) => {
                let trimmed = s.trim().trim_end_matches('%');
                match trimmed.parse::<f64>() {
                    Ok(pct) if pct > 0.0 => {
                        let frac = pct / 100.0;
                        let count = (total as f64 * frac).ceil() as usize;
                        count.max(1).min(remaining)
                    }
                    _ => remaining,
                }
            }
        }
    };

    let mut batches = Vec::new();
    let mut remaining = total;
    let mut iter = specs.iter();
    let mut last: Option<&SerialSpec> = None;

    while remaining > 0 {
        let spec = match iter.next() {
            Some(s) => {
                last = Some(s);
                s
            }
            None => match last {
                Some(s) => s,
                None => return batches,
            },
        };
        let size = resolve_one(spec, remaining);
        if size == 0 {
            break;
        }
        batches.push(size);
        remaining -= size;
    }

    batches
}

#[cfg(test)]
mod tests {
    use super::*;
    use ansible_inventory::InventoryManager;
    use ansible_playbook::Task;
    use std::collections::HashMap;

    fn debug_task(msg: &str) -> Task {
        Task {
            name: Some(format!("say {msg}")),
            action: {
                let mut m = HashMap::new();
                m.insert("debug".into(), serde_json::json!({"msg": msg}));
                m
            },
            when_conditions: Vec::new(),
            register: None,
            loop_source: None,
            loop_items: None,
            with_items: None,
            loop_control: None,
            notify: Vec::new(),
            tags: Default::default(),
            use_become: None,
            become_user: None,
            become_method: None,
            become_flags: None,
            become_pass: None,
            delegate_to: None,
            ignore_errors: false,
            run_once: false,
            changed_when: Vec::new(),
            failed_when: Vec::new(),
            retries: 3,
            delay: 5,
            until: Vec::new(),
            no_log: false,
            args: None,
            environment: None,
            vars: None,
            block: None,
            rescue: None,
            always: None,
            connection: None,
            timeout: None,
            check_mode: None,
        }
    }

    fn play_with(pre: Vec<Task>, tasks: Vec<Task>, post: Vec<Task>) -> Play {
        Play {
            name: Some("p".into()),
            hosts: Some("all".into()),
            tasks,
            pre_tasks: pre,
            post_tasks: post,
            handlers: Vec::new(),
            roles: Vec::new(),
            vars: HashMap::new(),
            vars_files: Vec::new(),
            environment: HashMap::new(),
            gather_facts: Some(false),
            strategy: "linear".into(),
            serial: Vec::new(),
            max_fail_percentage: None,
            force_handlers: false,
            use_become: None,
            become_user: None,
            become_method: None,
            connection: None,
            tags: Default::default(),
            when_conditions: Vec::new(),
            any_errors_fatal: None,
            ignore_errors: None,
            ignore_unreachable: None,
            module_defaults: None,
            collections: None,
        }
    }

    #[tokio::test]
    async fn test_tqm_runs_all_phases_in_order() {
        let play = play_with(
            vec![debug_task("pre")],
            vec![debug_task("mid")],
            vec![debug_task("post")],
        );
        let inv = Arc::new(InventoryManager::new());
        let vm = Arc::new(VariableManager::new(inv));
        let mut tqm = TaskQueueManager::new(vm, 5);
        let hosts = vec!["h1".to_string()];
        let r = tqm.run_play(&play, &hosts).await.unwrap();
        assert_eq!(r.results.len(), 3);
        assert_eq!(r.results[0].msg.as_deref(), Some("pre"));
        assert_eq!(r.results[1].msg.as_deref(), Some("mid"));
        assert_eq!(r.results[2].msg.as_deref(), Some("post"));
        assert!(r.all_ok);
    }

    #[tokio::test]
    async fn test_tqm_runs_multiple_plays() {
        let inv = Arc::new(InventoryManager::new());
        let vm = Arc::new(VariableManager::new(inv));
        let mut tqm = TaskQueueManager::new(vm, 5);

        let p1 = play_with(vec![], vec![debug_task("a")], vec![]);
        let p2 = play_with(vec![], vec![debug_task("b"), debug_task("c")], vec![]);
        let hosts = vec!["h1".to_string()];
        let r = tqm
            .run_playbook(&[(p1, hosts.clone()), (p2, hosts)])
            .await
            .unwrap();
        assert_eq!(r.results.len(), 3);
        assert!(r.all_ok);
        // Stats should reflect 3 ok results across 1 host.
        let stats = tqm.stats();
        assert!(stats.ok.get("h1").copied().unwrap_or(0) >= 3);
    }

    #[test]
    fn test_resolve_serial_batches_empty_spec() {
        assert!(resolve_serial_batches(10, &[]).is_empty());
    }

    #[test]
    fn test_resolve_serial_batches_single_count() {
        let specs = vec![SerialSpec::Count(2)];
        // Last value repeats: 2, 2, 2, 2, 2 = 10 hosts.
        assert_eq!(resolve_serial_batches(10, &specs), vec![2, 2, 2, 2, 2]);
    }

    #[test]
    fn test_resolve_serial_batches_count_clamps_to_remaining() {
        let specs = vec![SerialSpec::Count(7)];
        // 10 hosts / batch 7 → 7, then 3 (clamped).
        assert_eq!(resolve_serial_batches(10, &specs), vec![7, 3]);
    }

    #[test]
    fn test_resolve_serial_batches_multi_value_list_repeats_last() {
        // serial: [1, 5] against 20 hosts → 1, 5, 5, 5, 4
        let specs = vec![SerialSpec::Count(1), SerialSpec::Count(5)];
        assert_eq!(resolve_serial_batches(20, &specs), vec![1, 5, 5, 5, 4]);
    }

    #[test]
    fn test_resolve_serial_batches_percentage() {
        // 25% of 8 = 2, repeated → 2,2,2,2
        let specs = vec![SerialSpec::Percentage("25%".into())];
        assert_eq!(resolve_serial_batches(8, &specs), vec![2, 2, 2, 2]);
    }

    #[test]
    fn test_resolve_serial_batches_mixed_count_and_percent() {
        // serial: [1, 50%] against 10 hosts → 1, then 50% of 10 = 5,
        // repeat last → 5, then remaining 4 hosts. 1 + 5 + 4 = 10.
        let specs = vec![SerialSpec::Count(1), SerialSpec::Percentage("50%".into())];
        assert_eq!(resolve_serial_batches(10, &specs), vec![1, 5, 4]);
    }

    #[test]
    fn test_resolve_serial_batches_percentage_rounds_up() {
        // 33% of 10 = 3.3 → ceil = 4; repeat → 4, 4, 2
        let specs = vec![SerialSpec::Percentage("33%".into())];
        assert_eq!(resolve_serial_batches(10, &specs), vec![4, 4, 2]);
    }

    #[test]
    fn test_resolve_serial_batches_zero_hosts() {
        let specs = vec![SerialSpec::Count(5)];
        assert!(resolve_serial_batches(0, &specs).is_empty());
    }

    #[tokio::test]
    async fn test_tqm_runs_play_in_serial_batches() {
        let mut play = play_with(vec![], vec![debug_task("t")], vec![]);
        play.serial = vec![SerialSpec::Count(2)];

        let inv = Arc::new(InventoryManager::new());
        let vm = Arc::new(VariableManager::new(inv));
        let mut tqm = TaskQueueManager::new(vm, 5);

        let hosts = vec![
            "h1".to_string(),
            "h2".to_string(),
            "h3".to_string(),
            "h4".to_string(),
            "h5".to_string(),
        ];
        let r = tqm.run_play(&play, &hosts).await.unwrap();

        // 1 task × 5 hosts = 5 results regardless of batching.
        assert_eq!(r.results.len(), 5);
        assert!(r.all_ok);

        // Result hosts should cover every host exactly once.
        let mut seen: Vec<String> = r.results.iter().map(|res| res.host.to_string()).collect();
        seen.sort();
        assert_eq!(seen, vec!["h1", "h2", "h3", "h4", "h5"]);
    }

    #[tokio::test]
    async fn test_tqm_run_once_produces_result_for_every_host() {
        let mut t = debug_task("hi");
        t.run_once = true;
        let play = play_with(vec![], vec![t], vec![]);
        let inv = Arc::new(InventoryManager::new());
        let vm = Arc::new(VariableManager::new(inv));
        let mut tqm = TaskQueueManager::new(vm, 5);
        let hosts = vec!["h1".into(), "h2".into(), "h3".into()];
        let r = tqm.run_play(&play, &hosts).await.unwrap();

        // run_once must NOT drop hosts: every host still sees a result so
        // register/changed_when/handler-notification semantics are uniform.
        assert_eq!(r.results.len(), 3);
        let mut hosts_seen: Vec<String> =
            r.results.iter().map(|res| res.host.to_string()).collect();
        hosts_seen.sort();
        assert_eq!(hosts_seen, vec!["h1", "h2", "h3"]);
        assert!(r.all_ok);

        // All synthesized results must be consistent with the primary's:
        // identical changed/failed/skipped flags and identical msg.
        let primary = &r.results[0];
        for res in &r.results {
            assert_eq!(res.changed, primary.changed);
            assert_eq!(res.failed, primary.failed);
            assert_eq!(res.skipped, primary.skipped);
            assert_eq!(res.msg, primary.msg);
        }
    }

    #[tokio::test]
    async fn test_tqm_run_once_propagates_failure_to_all_hosts() {
        // run_once on a failing task: every host must see the failure
        // (so that ignore_errors/any_errors_fatal apply uniformly).
        let mut t = debug_task("boom");
        t.action.clear();
        t.action
            .insert("fail".into(), serde_json::json!({"msg": "boom"}));
        t.run_once = true;
        t.ignore_errors = true; // keep play running so we observe all 3 results
        let play = play_with(vec![], vec![t], vec![]);
        let inv = Arc::new(InventoryManager::new());
        let vm = Arc::new(VariableManager::new(inv));
        let mut tqm = TaskQueueManager::new(vm, 5);
        let hosts = vec!["h1".into(), "h2".into(), "h3".into()];
        let r = tqm.run_play(&play, &hosts).await.unwrap();

        assert_eq!(r.results.len(), 3);
        for res in &r.results {
            assert!(res.failed, "every host should see the failure: {:?}", res);
        }
    }

    #[tokio::test]
    async fn test_tqm_serial_with_any_errors_fatal_stops_remaining_batches() {
        // Make a play whose task fails. With any_errors_fatal, the
        // second batch must not run.
        let mut fail = debug_task("boom");
        fail.action.clear();
        fail.action
            .insert("fail".into(), serde_json::json!({"msg": "boom"}));
        let mut play = play_with(vec![], vec![fail], vec![]);
        play.serial = vec![SerialSpec::Count(1)];
        play.any_errors_fatal = Some(true);

        let inv = Arc::new(InventoryManager::new());
        let vm = Arc::new(VariableManager::new(inv));
        let mut tqm = TaskQueueManager::new(vm, 5);

        let hosts = vec!["h1".into(), "h2".into(), "h3".into()];
        let r = tqm.run_play(&play, &hosts).await.unwrap();

        // Only h1 (the first batch) should have produced a result.
        assert_eq!(r.results.len(), 1);
        assert!(!r.all_ok);
        assert_eq!(r.results[0].host.as_ref(), "h1");
    }
}
