use std::collections::HashMap;
use std::sync::Arc;

use ansible_playbook::{Play, TagFilter, Task};

/// Tracks execution state per host through a play.
///
/// Mirrors Python's `PlayIterator` which walks each host through:
/// pre_tasks → roles → tasks → post_tasks → handlers
/// with block/rescue/always support at each level.
pub struct PlayIterator {
    pub play: Play,
    host_states: HashMap<Arc<str>, HostState>,
    /// Optional tag filter applied when deciding whether to return a task.
    /// Non-matching tasks are treated as "skipped" for iteration purposes.
    tag_filter: TagFilter,
    /// If set, the iterator skips tasks whose name does not match this
    /// value until one does — mirroring Ansible's `--start-at-task` flag.
    /// Once a matching task is found, all subsequent tasks run normally.
    /// The "have we reached it yet" bit lives per-host in `HostState` so
    /// that every host independently fast-forwards to the same position.
    start_at_task: Option<String>,
}

/// The execution phase within a play.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PlayPhase {
    Setup,
    PreTasks,
    Roles,
    Tasks,
    PostTasks,
    Handlers,
    Complete,
}

/// The execution state within a block (for block/rescue/always).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BlockPhase {
    Main,
    Rescue,
    Always,
}

/// The execution state of a single host within a play.
#[derive(Debug, Clone)]
pub struct HostState {
    pub phase: PlayPhase,
    pub task_idx: usize,
    pub block_phase: BlockPhase,
    pub block_task_idx: usize,
    pub did_rescue: bool,
    pub failed: bool,
    pub pending_setup: bool,
    pub run_state: RunState,
    /// True once the host has reached the `--start-at-task` target (or
    /// trivially true when no target is configured). While false, the
    /// iterator fast-forwards past non-matching tasks without running
    /// them. Flipped to true in `get_task_from_list` when a task whose
    /// name matches the target is found.
    pub start_at_reached: bool,
}

/// Whether the host is running, failed, or unreachable.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RunState {
    Running,
    Failed,
    Unreachable,
}

/// Info about the block at the host's current position.
struct BlockInfo {
    has_rescue: bool,
    has_always: bool,
}

impl Default for HostState {
    fn default() -> Self {
        Self {
            phase: PlayPhase::Setup,
            task_idx: 0,
            block_phase: BlockPhase::Main,
            block_task_idx: 0,
            did_rescue: false,
            failed: false,
            pending_setup: true,
            // Default: no start_at_task target → nothing to skip past,
            // so every host starts "already reached".
            start_at_reached: true,
            run_state: RunState::Running,
        }
    }
}

/// The result of asking the iterator for the next task.
pub enum NextTask<'a> {
    /// A task to execute.
    Task {
        task: &'a Task,
        host_state: HostState,
        /// Block-level vars (precedence level 16) when the task lives
        /// inside a block that defines `vars:`.
        block_vars: Option<HashMap<String, serde_json::Value>>,
    },
    /// Setup (fact gathering) needed.
    Setup {
        host_state: HostState,
    },
    /// No more tasks for this host.
    Complete,
}

impl PlayIterator {
    pub fn new(play: Play, hosts: &[String]) -> Self {
        Self::with_tag_filter(play, hosts, TagFilter::default())
    }

    /// Construct an iterator with a specific tag filter. Tasks whose tags
    /// don't match the filter will be skipped.
    pub fn with_tag_filter(play: Play, hosts: &[String], tag_filter: TagFilter) -> Self {
        let host_states = hosts
            .iter()
            .map(|h| (Arc::<str>::from(h.as_str()), HostState::default()))
            .collect();

        Self {
            play,
            host_states,
            tag_filter,
            start_at_task: None,
        }
    }

    /// Replace the active tag filter.
    pub fn set_tag_filter(&mut self, filter: TagFilter) {
        self.tag_filter = filter;
    }

    /// Configure the `--start-at-task` target. Passing `None` (or an
    /// empty string) disables fast-forwarding. When set, every host
    /// begins with `start_at_reached = false` and the iterator will
    /// silently skip past tasks whose name does not match until the
    /// target is found.
    pub fn set_start_at_task(&mut self, name: Option<String>) {
        let normalized = name.and_then(|n| {
            let trimmed = n.trim();
            if trimmed.is_empty() {
                None
            } else {
                Some(trimmed.to_string())
            }
        });
        let has_target = normalized.is_some();
        self.start_at_task = normalized;
        // Reset the per-host "reached" flags so previously-constructed
        // states honor the new filter. When no target is set, mark every
        // host as already-reached so get_task_from_list short-circuits
        // the skip logic.
        for state in self.host_states.values_mut() {
            state.start_at_reached = !has_target;
        }
    }

    /// Get the current state for a host.
    pub fn get_host_state(&self, host: &str) -> Option<&HostState> {
        self.host_states.get(host)
    }

    /// Set the state for a host. Reuses the existing interned `Arc<str>`
    /// key when the host is already known so we don't allocate a fresh
    /// string per state transition.
    pub fn set_host_state(&mut self, host: &str, state: HostState) {
        if let Some(slot) = self.host_states.get_mut(host) {
            *slot = state;
        } else {
            self.host_states.insert(Arc::from(host), state);
        }
    }

    /// Get the next task for a host, advancing state as needed.
    pub fn get_next_task_for_host(&self, host: &str) -> NextTask<'_> {
        let state = match self.host_states.get(host) {
            Some(s) => s,
            None => return NextTask::Complete,
        };

        if matches!(
            state.run_state,
            RunState::Unreachable | RunState::Failed
        ) {
            return NextTask::Complete;
        }

        match state.phase {
            PlayPhase::Setup => {
                if state.pending_setup && self.play.gather_facts.unwrap_or(true) {
                    return NextTask::Setup {
                        host_state: HostState {
                            phase: PlayPhase::PreTasks,
                            pending_setup: false,
                            ..state.clone()
                        },
                    };
                }
                // Skip setup, go to pre_tasks
                self.get_task_from_phase(state, PlayPhase::PreTasks)
            }
            PlayPhase::PreTasks => {
                self.get_task_from_list(state, &self.play.pre_tasks, PlayPhase::Roles)
            }
            PlayPhase::Roles => {
                // Roles are expanded into tasks in pre-processing; treat as a transition
                self.get_task_from_phase(state, PlayPhase::Tasks)
            }
            PlayPhase::Tasks => {
                self.get_task_from_list(state, &self.play.tasks, PlayPhase::PostTasks)
            }
            PlayPhase::PostTasks => {
                // After post_tasks the iterator stops; handlers are flushed
                // separately by the strategy for hosts that notified them.
                self.get_task_from_list(state, &self.play.post_tasks, PlayPhase::Complete)
            }
            PlayPhase::Handlers => {
                NextTask::Complete
            }
            PlayPhase::Complete => NextTask::Complete,
        }
    }

    /// Try to get a task from a phase's task list, advancing to next_phase if exhausted.
    fn get_task_from_list<'a>(
        &'a self,
        state: &HostState,
        tasks: &'a [Task],
        next_phase: PlayPhase,
    ) -> NextTask<'a> {
        let idx = state.task_idx;

        if idx >= tasks.len() {
            // Phase exhausted, move to next
            return self.get_task_from_phase(state, next_phase);
        }

        let task = &tasks[idx];

        // --start-at-task fast-forward. While the target has not been
        // reached, silently skip every task whose name does not match.
        // The match is set on the outbound state so all subsequent
        // tasks run normally. For v1, blocks are treated atomically —
        // matching against the block's own name — so a target buried
        // inside a block is not supported yet.
        if !state.start_at_reached {
            let target = self.start_at_task.as_deref().unwrap_or("");
            let task_name = task.name.as_deref().unwrap_or("");
            if task_name != target {
                let advanced = HostState {
                    task_idx: idx + 1,
                    block_phase: BlockPhase::Main,
                    block_task_idx: 0,
                    did_rescue: false,
                    ..state.clone()
                };
                return self.get_task_from_list(&advanced, tasks, next_phase);
            }
        }

        // Check if this is a block task. We descend unconditionally and
        // apply the tag filter at leaf tasks with the block's own tags
        // merged in (mirroring Python Ansible's tag inheritance semantics).
        if task.block.is_some() {
            // If start_at_task matched this block, flip the flag on a
            // scratch state before descending so children run normally.
            if !state.start_at_reached {
                let matched = HostState {
                    start_at_reached: true,
                    ..state.clone()
                };
                return self.get_task_from_block(&matched, task, tasks, next_phase);
            }
            return self.get_task_from_block(state, task, tasks, next_phase);
        }

        // Non-block task: apply the tag filter. A filtered-out task is
        // transparently skipped as if it weren't in the play at all.
        // Play-level tags are inherited into each task's effective tag set
        // so a play tagged `tags: [foo]` runs only when `--tags foo` is
        // requested, matching upstream Ansible semantics.
        if !self.task_should_run(&task.tags, None) {
            let advanced = HostState {
                task_idx: idx + 1,
                block_phase: BlockPhase::Main,
                block_task_idx: 0,
                did_rescue: false,
                ..state.clone()
            };
            return self.get_task_from_list(&advanced, tasks, next_phase);
        }

        NextTask::Task {
            task,
            host_state: HostState {
                phase: state.phase,
                task_idx: idx + 1,
                block_phase: BlockPhase::Main,
                block_task_idx: 0,
                did_rescue: false,
                // Once a matching task is found, every subsequent
                // task runs normally for this host.
                start_at_reached: true,
                ..state.clone()
            },
            block_vars: None,
        }
    }

    /// Get the next task from within a block/rescue/always structure.
    fn get_task_from_block<'a>(
        &'a self,
        state: &HostState,
        block_task: &'a Task,
        parent_tasks: &'a [Task],
        parent_next_phase: PlayPhase,
    ) -> NextTask<'a> {
        match state.block_phase {
            BlockPhase::Main => {
                if let Some(ref block_tasks) = block_task.block {
                    if state.block_task_idx < block_tasks.len() {
                        let task = &block_tasks[state.block_task_idx];
                        if !self.leaf_should_run(&block_task.tags, &task.tags) {
                            let advanced = HostState {
                                block_task_idx: state.block_task_idx + 1,
                                ..state.clone()
                            };
                            return self.get_task_from_block(
                                &advanced,
                                block_task,
                                parent_tasks,
                                parent_next_phase,
                            );
                        }
                        return NextTask::Task {
                            task,
                            host_state: HostState {
                                block_task_idx: state.block_task_idx + 1,
                                ..state.clone()
                            },
                            block_vars: block_task.vars.clone(),
                        };
                    }
                }
                // Main block done, go to always (skip rescue since no failure)
                if block_task.always.is_some() {
                    let new_state = HostState {
                        block_phase: BlockPhase::Always,
                        block_task_idx: 0,
                        ..state.clone()
                    };
                    return self.get_task_from_block(&new_state, block_task, parent_tasks, parent_next_phase);
                }
                // No always block, advance to next task in parent
                self.get_task_from_list(
                    &HostState {
                        task_idx: state.task_idx + 1,
                        block_phase: BlockPhase::Main,
                        block_task_idx: 0,
                        did_rescue: false,
                        ..state.clone()
                    },
                    parent_tasks,
                    parent_next_phase,
                )
            }
            BlockPhase::Rescue => {
                if let Some(ref rescue_tasks) = block_task.rescue {
                    if state.block_task_idx < rescue_tasks.len() {
                        let task = &rescue_tasks[state.block_task_idx];
                        if !self.leaf_should_run(&block_task.tags, &task.tags) {
                            let advanced = HostState {
                                block_task_idx: state.block_task_idx + 1,
                                ..state.clone()
                            };
                            return self.get_task_from_block(
                                &advanced,
                                block_task,
                                parent_tasks,
                                parent_next_phase,
                            );
                        }
                        return NextTask::Task {
                            task,
                            host_state: HostState {
                                block_task_idx: state.block_task_idx + 1,
                                did_rescue: true,
                                ..state.clone()
                            },
                            block_vars: block_task.vars.clone(),
                        };
                    }
                }
                // Rescue done, go to always
                if block_task.always.is_some() {
                    let new_state = HostState {
                        block_phase: BlockPhase::Always,
                        block_task_idx: 0,
                        ..state.clone()
                    };
                    return self.get_task_from_block(&new_state, block_task, parent_tasks, parent_next_phase);
                }
                // No always block
                self.get_task_from_list(
                    &HostState {
                        task_idx: state.task_idx + 1,
                        block_phase: BlockPhase::Main,
                        block_task_idx: 0,
                        did_rescue: false,
                        failed: false,
                        ..state.clone()
                    },
                    parent_tasks,
                    parent_next_phase,
                )
            }
            BlockPhase::Always => {
                if let Some(ref always_tasks) = block_task.always {
                    if state.block_task_idx < always_tasks.len() {
                        let task = &always_tasks[state.block_task_idx];
                        if !self.leaf_should_run(&block_task.tags, &task.tags) {
                            let advanced = HostState {
                                block_task_idx: state.block_task_idx + 1,
                                ..state.clone()
                            };
                            return self.get_task_from_block(
                                &advanced,
                                block_task,
                                parent_tasks,
                                parent_next_phase,
                            );
                        }
                        return NextTask::Task {
                            task,
                            host_state: HostState {
                                block_task_idx: state.block_task_idx + 1,
                                ..state.clone()
                            },
                            block_vars: block_task.vars.clone(),
                        };
                    }
                }
                // Always done, advance to next task in parent
                self.get_task_from_list(
                    &HostState {
                        task_idx: state.task_idx + 1,
                        block_phase: BlockPhase::Main,
                        block_task_idx: 0,
                        did_rescue: false,
                        failed: state.failed && !state.did_rescue,
                        ..state.clone()
                    },
                    parent_tasks,
                    parent_next_phase,
                )
            }
        }
    }

    /// Transition to a new phase, resetting task indices.
    fn get_task_from_phase(&self, state: &HostState, phase: PlayPhase) -> NextTask<'_> {
        let new_state = HostState {
            phase,
            task_idx: 0,
            block_phase: BlockPhase::Main,
            block_task_idx: 0,
            did_rescue: false,
            ..state.clone()
        };

        match phase {
            PlayPhase::PreTasks => {
                self.get_task_from_list(&new_state, &self.play.pre_tasks, PlayPhase::Roles)
            }
            PlayPhase::Roles => {
                self.get_task_from_phase(&new_state, PlayPhase::Tasks)
            }
            PlayPhase::Tasks => {
                self.get_task_from_list(&new_state, &self.play.tasks, PlayPhase::PostTasks)
            }
            PlayPhase::PostTasks => {
                self.get_task_from_list(&new_state, &self.play.post_tasks, PlayPhase::Complete)
            }
            PlayPhase::Handlers => NextTask::Complete,
            PlayPhase::Complete | PlayPhase::Setup => NextTask::Complete,
        }
    }

    /// Mark a host as failed. The iterator inspects the host's current
    /// position in the play to decide whether a rescue/always block can
    /// recover the host or whether it is terminally failed.
    ///
    /// Returns `true` if the host has follow-up work (rescue or always);
    /// `false` if the host is terminally failed and will be skipped.
    pub fn mark_host_failed(&mut self, host: &str) -> bool {
        // Snapshot the state and figure out whether we are inside a block.
        let (state_snapshot, block_ctx) = match self.host_states.get(host) {
            Some(s) => {
                let ctx = self.get_current_block_task_info(s);
                (s.clone(), ctx)
            }
            None => return false,
        };

        let Some(state) = self.host_states.get_mut(host) else {
            return false;
        };
        state.failed = true;

        match block_ctx {
            // Inside a block's main body
            Some(BlockInfo { has_rescue: true, .. }) if state_snapshot.block_phase == BlockPhase::Main => {
                // Fall through to rescue; rescue resets the failure flag —
                // if rescue succeeds, the host is considered recovered.
                state.block_phase = BlockPhase::Rescue;
                state.block_task_idx = 0;
                state.failed = false;
                state.run_state = RunState::Running;
                true
            }
            Some(BlockInfo { has_always: true, .. }) if state_snapshot.block_phase == BlockPhase::Main => {
                // No rescue available, but always must still run.
                state.block_phase = BlockPhase::Always;
                state.block_task_idx = 0;
                // Preserve failed=true so it propagates after always finishes.
                true
            }
            Some(_) if state_snapshot.block_phase == BlockPhase::Main => {
                // No rescue, no always — advance past block and mark terminal.
                state.task_idx = state_snapshot.task_idx + 1;
                state.block_phase = BlockPhase::Main;
                state.block_task_idx = 0;
                state.run_state = RunState::Failed;
                false
            }
            Some(BlockInfo { has_always: true, .. }) if state_snapshot.block_phase == BlockPhase::Rescue => {
                // Rescue itself failed — always still runs, then host fails.
                state.block_phase = BlockPhase::Always;
                state.block_task_idx = 0;
                true
            }
            Some(_) if state_snapshot.block_phase == BlockPhase::Rescue => {
                // Rescue failed, no always — advance past block and mark terminal.
                state.task_idx = state_snapshot.task_idx + 1;
                state.block_phase = BlockPhase::Main;
                state.block_task_idx = 0;
                state.run_state = RunState::Failed;
                false
            }
            Some(_) => {
                // Failure during Always — host is terminally failed.
                state.task_idx = state_snapshot.task_idx + 1;
                state.block_phase = BlockPhase::Main;
                state.block_task_idx = 0;
                state.run_state = RunState::Failed;
                false
            }
            None => {
                // Not inside a block at all — the host is done.
                state.run_state = RunState::Failed;
                false
            }
        }
    }

    /// Check whether a leaf task inside a block should run, accounting
    /// for the parent block's tags (Ansible inherits block tags into
    /// each child task). When either side carries an `always` tag the
    /// task runs regardless of the include list; when either side is
    /// tagged `never` the task is skipped unless explicitly opted in.
    fn leaf_should_run(
        &self,
        block_tags: &ansible_playbook::TagSpec,
        leaf_tags: &ansible_playbook::TagSpec,
    ) -> bool {
        self.task_should_run(leaf_tags, Some(block_tags))
    }

    /// Build the effective tag set for a task by merging play-level tags,
    /// the enclosing block's tags (if any), and the task's own tags, then
    /// run it through the configured `TagFilter`.
    ///
    /// Order is irrelevant for filter semantics — `should_run` only checks
    /// presence/intersection — but the merge dedupes to keep the spec compact.
    /// Mirrors upstream Ansible's tag inheritance: a play tagged
    /// `tags: [setup]` adds `setup` to every task it owns, including those
    /// nested inside blocks.
    fn task_should_run(
        &self,
        task_tags: &ansible_playbook::TagSpec,
        block_tags: Option<&ansible_playbook::TagSpec>,
    ) -> bool {
        let play_tags = self.play.tags.tags();
        let block_tags_slice = block_tags.map(|b| b.tags()).unwrap_or(&[]);
        let task_tags_slice = task_tags.tags();

        if play_tags.is_empty() && block_tags_slice.is_empty() {
            // Common path: no parent tags to inherit, just consult the filter.
            return self.tag_filter.should_run(task_tags);
        }

        let mut merged: ansible_playbook::TagList =
            ansible_playbook::TagList::with_capacity(
                play_tags.len() + block_tags_slice.len() + task_tags_slice.len(),
            );
        for src in [play_tags, block_tags_slice, task_tags_slice] {
            for t in src {
                if !merged.iter().any(|existing| existing == t) {
                    merged.push(t.clone());
                }
            }
        }
        let effective = ansible_playbook::TagSpec::Tags(merged);
        self.tag_filter.should_run(&effective)
    }

    /// Inspect the task the host is currently positioned at; if it is a
    /// block task, return info about which sub-sections it defines.
    fn get_current_block_task_info(&self, state: &HostState) -> Option<BlockInfo> {
        let tasks = match state.phase {
            PlayPhase::PreTasks => &self.play.pre_tasks,
            PlayPhase::Tasks => &self.play.tasks,
            PlayPhase::PostTasks => &self.play.post_tasks,
            _ => return None,
        };
        let task = tasks.get(state.task_idx)?;
        task.block.as_ref()?;
        Some(BlockInfo {
            has_rescue: task.rescue.as_ref().map(|r| !r.is_empty()).unwrap_or(false),
            has_always: task.always.as_ref().map(|a| !a.is_empty()).unwrap_or(false),
        })
    }

    /// Return the enclosing block's `vars:` map for the given host
    /// state, if the state points at a task inside a block that defines
    /// vars. Used by the strategy layer to feed block vars (precedence
    /// level 16) into the TaskExecutor.
    ///
    /// The caller should pass the **returned** `host_state` from
    /// `get_next_task_for_host` (which still carries the parent block's
    /// `task_idx`) rather than the host's pre-advance state.
    pub fn get_block_vars_for_state(
        &self,
        state: &HostState,
    ) -> Option<HashMap<String, serde_json::Value>> {
        let tasks = match state.phase {
            PlayPhase::PreTasks => &self.play.pre_tasks,
            PlayPhase::Tasks => &self.play.tasks,
            PlayPhase::PostTasks => &self.play.post_tasks,
            _ => return None,
        };
        let task = tasks.get(state.task_idx)?;
        task.block.as_ref()?;
        task.vars.clone()
    }

    /// Mark a host as unreachable.
    pub fn mark_host_unreachable(&mut self, host: &str) {
        if let Some(state) = self.host_states.get_mut(host) {
            state.run_state = RunState::Unreachable;
        }
    }

    /// Check if all hosts have completed.
    pub fn all_complete(&self) -> bool {
        self.host_states.values().all(|s| {
            matches!(s.phase, PlayPhase::Complete)
                || matches!(s.run_state, RunState::Unreachable)
        })
    }

    /// Get all hosts that are still active (not complete/unreachable).
    /// Returns interned `Arc<str>` handles so callers can clone them
    /// cheaply (refcount bump) instead of allocating fresh strings.
    pub fn get_active_hosts(&self) -> Vec<Arc<str>> {
        self.host_states
            .iter()
            .filter(|(_, s)| {
                !matches!(s.phase, PlayPhase::Complete)
                    && !matches!(s.run_state, RunState::Unreachable)
            })
            .map(|(h, _)| Arc::clone(h))
            .collect()
    }

    /// Get all host names.
    pub fn get_hosts(&self) -> Vec<Arc<str>> {
        self.host_states.keys().cloned().collect()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::HashMap;

    fn make_task(name: &str) -> Task {
        Task {
            name: Some(name.to_string()),
            action: HashMap::new(),
            when_conditions: Vec::new(),
            register: None,
            loop_source: None,
            loop_items: None,
            with_items: None,
            loop_control: None,
            notify: Vec::new(),
            tags: Default::default(),
            use_become: None,
            become_user: None,
            become_method: None,
            become_flags: None,
            become_pass: None,
            delegate_to: None,
            ignore_errors: false,
            run_once: false,
            changed_when: Vec::new(),
            failed_when: Vec::new(),
            retries: 3,
            delay: 5,
            until: Vec::new(),
            no_log: false,
            args: None,
            environment: None,
            vars: None,
            block: None,
            rescue: None,
            always: None,
            connection: None,
            timeout: None,
            check_mode: None,
        }
    }

    fn make_play(tasks: Vec<Task>) -> Play {
        Play {
            name: Some("test play".into()),
            hosts: Some("all".into()),
            tasks,
            pre_tasks: Vec::new(),
            post_tasks: Vec::new(),
            handlers: Vec::new(),
            roles: Vec::new(),
            vars: HashMap::new(),
            vars_files: Vec::new(),
            environment: HashMap::new(),
            gather_facts: Some(false),
            strategy: "linear".into(),
            serial: Vec::new(),
            max_fail_percentage: None,
            force_handlers: false,
            use_become: None,
            become_user: None,
            become_method: None,
            connection: None,
            tags: Default::default(),
            when_conditions: Vec::new(),
            any_errors_fatal: None,
            ignore_errors: None,
            ignore_unreachable: None,
            module_defaults: None,
            collections: None,
        }
    }

    #[test]
    fn test_simple_task_iteration() {
        let tasks = vec![make_task("task1"), make_task("task2")];
        let play = make_play(tasks);
        let iter = PlayIterator::new(play, &["host1".into()]);

        // First call should give task1
        match iter.get_next_task_for_host("host1") {
            NextTask::Task { task, host_state, .. } => {
                assert_eq!(task.name.as_deref(), Some("task1"));
                // Simulate advancing state
                let iter2 = {
                    let mut i = PlayIterator::new(iter.play.clone(), &["host1".into()]);
                    i.set_host_state("host1", host_state);
                    i
                };
                match iter2.get_next_task_for_host("host1") {
                    NextTask::Task { task, host_state, .. } => {
                        assert_eq!(task.name.as_deref(), Some("task2"));
                        let iter3 = {
                            let mut i = PlayIterator::new(iter2.play.clone(), &["host1".into()]);
                            i.set_host_state("host1", host_state);
                            i
                        };
                        match iter3.get_next_task_for_host("host1") {
                            NextTask::Complete => {}
                            _ => panic!("expected complete"),
                        }
                    }
                    _ => panic!("expected task2"),
                }
            }
            _ => panic!("expected task1"),
        }
    }

    #[test]
    fn test_setup_phase_with_gather_facts() {
        let play = Play {
            gather_facts: Some(true),
            ..make_play(vec![make_task("task1")])
        };
        let iter = PlayIterator::new(play, &["host1".into()]);

        match iter.get_next_task_for_host("host1") {
            NextTask::Setup { host_state } => {
                assert_eq!(host_state.phase, PlayPhase::PreTasks);
                assert!(!host_state.pending_setup);
            }
            _ => panic!("expected setup"),
        }
    }

    #[test]
    fn test_pre_tasks_before_tasks() {
        let play = Play {
            pre_tasks: vec![make_task("pre1")],
            gather_facts: Some(false),
            ..make_play(vec![make_task("task1")])
        };
        let iter = PlayIterator::new(play, &["host1".into()]);

        match iter.get_next_task_for_host("host1") {
            NextTask::Task { task, .. } => {
                assert_eq!(task.name.as_deref(), Some("pre1"));
            }
            _ => panic!("expected pre_task"),
        }
    }

    #[test]
    fn test_block_rescue_always() {
        let block_task = Task {
            block: Some(vec![make_task("main_task")]),
            rescue: Some(vec![make_task("rescue_task")]),
            always: Some(vec![make_task("always_task")]),
            ..make_task("block")
        };
        let play = make_play(vec![block_task]);
        let iter = PlayIterator::new(play, &["host1".into()]);

        // Should get main_task first
        match iter.get_next_task_for_host("host1") {
            NextTask::Task { task, host_state, .. } => {
                assert_eq!(task.name.as_deref(), Some("main_task"));
                // After main completes, should get always_task (no failure = skip rescue)
                let mut iter2 = PlayIterator::new(iter.play.clone(), &["host1".into()]);
                iter2.set_host_state("host1", host_state);
                match iter2.get_next_task_for_host("host1") {
                    NextTask::Task { task, .. } => {
                        assert_eq!(task.name.as_deref(), Some("always_task"));
                    }
                    _ => panic!("expected always_task"),
                }
            }
            _ => panic!("expected main_task"),
        }
    }

    #[test]
    fn test_unreachable_host_completes() {
        let play = make_play(vec![make_task("task1")]);
        let mut iter = PlayIterator::new(play, &["host1".into()]);
        iter.mark_host_unreachable("host1");

        match iter.get_next_task_for_host("host1") {
            NextTask::Complete => {}
            _ => panic!("expected complete for unreachable host"),
        }
        assert!(iter.all_complete());
    }

    #[test]
    fn test_active_hosts() {
        let play = make_play(vec![make_task("task1")]);
        let mut iter = PlayIterator::new(play, &["host1".into(), "host2".into()]);
        iter.mark_host_unreachable("host1");

        let active = iter.get_active_hosts();
        assert_eq!(active.len(), 1);
        assert!(active.iter().any(|h| h.as_ref() == "host2"));
    }

    fn tagged(name: &str, tags: &[&str]) -> Task {
        Task {
            tags: ansible_playbook::TagSpec::Tags(
                tags.iter().map(|s| s.to_string()).collect::<ansible_playbook::TagList>(),
            ),
            ..make_task(name)
        }
    }

    /// Drain every task the iterator emits for a single host, advancing
    /// state after each fetch. Returns the ordered list of task names.
    fn drain(play: Play, filter: TagFilter) -> Vec<String> {
        let hosts = vec!["h1".to_string()];
        let mut iter = PlayIterator::with_tag_filter(play, &hosts, filter);
        let mut out = Vec::new();
        loop {
            match iter.get_next_task_for_host("h1") {
                NextTask::Task { task, host_state, .. } => {
                    out.push(task.name.clone().unwrap_or_default());
                    iter.set_host_state("h1", host_state);
                }
                NextTask::Setup { host_state } => {
                    iter.set_host_state("h1", host_state);
                }
                NextTask::Complete => break,
            }
        }
        out
    }

    #[test]
    fn test_tag_filter_include_skips_non_matching() {
        let play = make_play(vec![
            tagged("t1", &["foo"]),
            tagged("t2", &["bar"]),
            tagged("t3", &["foo", "baz"]),
        ]);
        let filter = TagFilter::from_cli(Some("foo"), None);
        let names = drain(play, filter);
        assert_eq!(names, vec!["t1", "t3"]);
    }

    #[test]
    fn test_tag_filter_skip_excludes_matching() {
        let play = make_play(vec![
            tagged("t1", &["foo"]),
            tagged("t2", &["bar"]),
            make_task("untagged"),
        ]);
        let filter = TagFilter::from_cli(None, Some("foo"));
        let names = drain(play, filter);
        assert_eq!(names, vec!["t2", "untagged"]);
    }

    #[test]
    fn test_tag_filter_always_runs_regardless() {
        let play = make_play(vec![
            tagged("t1", &["foo"]),
            tagged("critical", &["always"]),
            tagged("t3", &["bar"]),
        ]);
        let filter = TagFilter::from_cli(Some("foo"), None);
        let names = drain(play, filter);
        assert_eq!(names, vec!["t1", "critical"]);
    }

    #[test]
    fn test_tag_filter_never_skipped_by_default() {
        let play = make_play(vec![
            make_task("normal"),
            tagged("risky", &["never"]),
            make_task("also_normal"),
        ]);
        let filter = TagFilter::default();
        let names = drain(play, filter);
        assert_eq!(names, vec!["normal", "also_normal"]);
    }

    #[test]
    fn test_tag_filter_block_with_matching_tag_descends() {
        // Block carries tag "foo"; inner tasks are untagged.
        let block = Task {
            name: Some("outer".into()),
            block: Some(vec![make_task("inner1"), make_task("inner2")]),
            tags: ansible_playbook::TagSpec::Tags(vec!["foo".into()].into()),
            ..make_task("outer")
        };
        let play = make_play(vec![block]);
        let filter = TagFilter::from_cli(Some("foo"), None);
        let names = drain(play, filter);
        assert_eq!(names, vec!["inner1", "inner2"]);
    }

    #[test]
    fn test_tag_filter_block_with_non_matching_tag_skipped_whole() {
        let block = Task {
            name: Some("outer".into()),
            block: Some(vec![make_task("inner1")]),
            always: Some(vec![make_task("inner_always")]),
            tags: ansible_playbook::TagSpec::Tags(vec!["bar".into()].into()),
            ..make_task("outer")
        };
        let play = make_play(vec![block, tagged("after", &["foo"])]);
        let filter = TagFilter::from_cli(Some("foo"), None);
        let names = drain(play, filter);
        // The entire block is skipped, including its always clause.
        assert_eq!(names, vec!["after"]);
    }

    #[test]
    fn test_tag_filter_inside_block_filters_leaves() {
        // Untagged block, inner tasks carry distinct tags.
        let block = Task {
            name: Some("outer".into()),
            block: Some(vec![tagged("in_foo", &["foo"]), tagged("in_bar", &["bar"])]),
            ..make_task("outer")
        };
        let play = make_play(vec![block]);
        let filter = TagFilter::from_cli(Some("foo"), None);
        let names = drain(play, filter);
        assert_eq!(names, vec!["in_foo"]);
    }

    /// Drain tasks with a configured `--start-at-task` target.
    fn drain_with_start_at(play: Play, target: &str) -> Vec<String> {
        let hosts = vec!["h1".to_string()];
        let mut iter = PlayIterator::new(play, &hosts);
        iter.set_start_at_task(Some(target.to_string()));
        let mut out = Vec::new();
        loop {
            match iter.get_next_task_for_host("h1") {
                NextTask::Task { task, host_state, .. } => {
                    out.push(task.name.clone().unwrap_or_default());
                    iter.set_host_state("h1", host_state);
                }
                NextTask::Setup { host_state } => {
                    iter.set_host_state("h1", host_state);
                }
                NextTask::Complete => break,
            }
        }
        out
    }

    #[test]
    fn test_start_at_task_skips_earlier_tasks_in_main_list() {
        let play = make_play(vec![
            make_task("one"),
            make_task("two"),
            make_task("three"),
        ]);
        let names = drain_with_start_at(play, "two");
        assert_eq!(names, vec!["two", "three"]);
    }

    #[test]
    fn test_start_at_task_spans_pre_and_main_tasks() {
        // Target is in main tasks; pre_tasks should all be skipped.
        let mut play = make_play(vec![make_task("main1"), make_task("main2")]);
        play.pre_tasks = vec![make_task("pre1"), make_task("pre2")];
        let names = drain_with_start_at(play, "main1");
        assert_eq!(names, vec!["main1", "main2"]);
    }

    #[test]
    fn test_start_at_task_target_in_pre_tasks_still_runs_main() {
        // Target is in pre_tasks; remaining pre_tasks plus all main
        // tasks must run.
        let mut play = make_play(vec![make_task("main1")]);
        play.pre_tasks = vec![make_task("pre1"), make_task("pre2"), make_task("pre3")];
        let names = drain_with_start_at(play, "pre2");
        assert_eq!(names, vec!["pre2", "pre3", "main1"]);
    }

    #[test]
    fn test_start_at_task_no_match_runs_nothing() {
        let play = make_play(vec![
            make_task("one"),
            make_task("two"),
            make_task("three"),
        ]);
        let names = drain_with_start_at(play, "nonexistent");
        assert!(names.is_empty());
    }

    #[test]
    fn test_start_at_task_matches_block_wrapper_name() {
        // A block named "deploy"; target is "deploy". The leaf tasks
        // inside the block should run once the block matches.
        let block = Task {
            name: Some("deploy".into()),
            block: Some(vec![make_task("child1"), make_task("child2")]),
            ..make_task("deploy")
        };
        let play = make_play(vec![
            make_task("before"),
            block,
            make_task("after"),
        ]);
        let names = drain_with_start_at(play, "deploy");
        assert_eq!(names, vec!["child1", "child2", "after"]);
    }

    #[test]
    fn test_start_at_task_unset_runs_everything() {
        // Sanity check: setting start_at_task to None leaves the
        // default "already reached" behavior intact.
        let play = make_play(vec![make_task("a"), make_task("b")]);
        let hosts = vec!["h1".to_string()];
        let mut iter = PlayIterator::new(play, &hosts);
        iter.set_start_at_task(None);
        let mut out = Vec::new();
        loop {
            match iter.get_next_task_for_host("h1") {
                NextTask::Task { task, host_state, .. } => {
                    out.push(task.name.clone().unwrap_or_default());
                    iter.set_host_state("h1", host_state);
                }
                NextTask::Setup { host_state } => {
                    iter.set_host_state("h1", host_state);
                }
                NextTask::Complete => break,
            }
        }
        assert_eq!(out, vec!["a", "b"]);
    }

    /// Regression guard for upstream ansible/ansible PR #86345 (fixes
    /// issue #86268, tracked here as #48): `--start-at-task` must not
    /// cause implicit fact-gathering to be skipped. Play-level setup
    /// runs first, then the iterator fast-forwards past non-matching
    /// tasks to the requested target.
    #[test]
    fn test_start_at_task_does_not_skip_setup() {
        let play = Play {
            gather_facts: Some(true),
            ..make_play(vec![
                make_task("one"),
                make_task("target"),
                make_task("three"),
            ])
        };
        let hosts = vec!["h1".to_string()];
        let mut iter = PlayIterator::new(play, &hosts);
        iter.set_start_at_task(Some("target".to_string()));

        let mut saw_setup = false;
        let mut names = Vec::new();
        loop {
            match iter.get_next_task_for_host("h1") {
                NextTask::Setup { host_state } => {
                    // Setup must surface *before* any task — a regression
                    // where start_at_task short-circuited the Setup phase
                    // would leave this flag false.
                    assert!(names.is_empty(), "setup must come before tasks");
                    saw_setup = true;
                    iter.set_host_state("h1", host_state);
                }
                NextTask::Task { task, host_state, .. } => {
                    names.push(task.name.clone().unwrap_or_default());
                    iter.set_host_state("h1", host_state);
                }
                NextTask::Complete => break,
            }
        }

        assert!(saw_setup, "fact gathering must run even when --start-at-task is set");
        assert_eq!(names, vec!["target", "three"]);
    }

    /// Sibling regression: a target that is never found must still not
    /// suppress fact gathering. Without the upstream fix, a missing
    /// target silently skipped both setup and every task.
    #[test]
    fn test_start_at_task_missing_target_still_gathers_facts() {
        let play = Play {
            gather_facts: Some(true),
            ..make_play(vec![make_task("one"), make_task("two")])
        };
        let hosts = vec!["h1".to_string()];
        let mut iter = PlayIterator::new(play, &hosts);
        iter.set_start_at_task(Some("nonexistent".to_string()));

        let mut saw_setup = false;
        let mut names = Vec::new();
        loop {
            match iter.get_next_task_for_host("h1") {
                NextTask::Setup { host_state } => {
                    saw_setup = true;
                    iter.set_host_state("h1", host_state);
                }
                NextTask::Task { task, host_state, .. } => {
                    names.push(task.name.clone().unwrap_or_default());
                    iter.set_host_state("h1", host_state);
                }
                NextTask::Complete => break,
            }
        }

        assert!(saw_setup, "missing start_at_task target must not suppress setup");
        assert!(names.is_empty(), "no task should run when target is never found");
    }

    // ── Play-level tag inheritance ──
    // Locks in upstream Ansible semantics where a play's `tags:` get
    // inherited by every task it owns (including those nested in blocks).
    // Prep work for the `validate_argspec` half of upstream PR
    // ansible/ansible#86345 (issue #127 here): once that task is synthesized,
    // it must inherit play tags rather than being auto-`always`. The Rust
    // port's existing iterator never read `play.tags`, so this change
    // wires up the inheritance machinery first.

    fn play_with_tags(tasks: Vec<Task>, play_tags: &[&str]) -> Play {
        Play {
            tags: ansible_playbook::TagSpec::Tags(
                play_tags
                    .iter()
                    .map(|s| s.to_string())
                    .collect::<ansible_playbook::TagList>(),
            ),
            ..make_play(tasks)
        }
    }

    #[test]
    fn test_play_tag_inherited_runs_with_matching_include() {
        // Play tagged [setup]; user passes --tags setup. Every task should
        // run even though the tasks themselves carry no tags.
        let play = play_with_tags(
            vec![make_task("a"), make_task("b")],
            &["setup"],
        );
        let names = drain(play, TagFilter::from_cli(Some("setup"), None));
        assert_eq!(names, vec!["a", "b"]);
    }

    #[test]
    fn test_play_tag_inherited_skips_with_non_matching_include() {
        // Play tagged [setup]; user passes --tags deploy. Nothing should
        // run — the play's tag does not intersect the include list.
        let play = play_with_tags(
            vec![make_task("a"), make_task("b")],
            &["setup"],
        );
        let names = drain(play, TagFilter::from_cli(Some("deploy"), None));
        assert!(names.is_empty());
    }

    #[test]
    fn test_play_tag_inheritance_into_block_children() {
        // Play tagged [setup]; block has no tags; leaf tasks have no tags.
        // --tags setup should still descend through the block and run
        // both children because they inherit the play tag.
        let block = Task {
            name: Some("outer".into()),
            block: Some(vec![make_task("inner1"), make_task("inner2")]),
            ..make_task("outer")
        };
        let play = play_with_tags(vec![block], &["setup"]);
        let names = drain(play, TagFilter::from_cli(Some("setup"), None));
        assert_eq!(names, vec!["inner1", "inner2"]);
    }

    #[test]
    fn test_play_tag_plus_block_tag_plus_leaf_tag_union() {
        // All three layers contribute. --tags deploy should run the leaf
        // whose own tag is [deploy], and --tags shared should run both
        // leaves because of the play-inherited tag.
        let block = Task {
            name: Some("outer".into()),
            block: Some(vec![
                tagged("leaf_deploy", &["deploy"]),
                tagged("leaf_extra", &["extra"]),
            ]),
            tags: ansible_playbook::TagSpec::Tags(vec!["blocky".into()].into()),
            ..make_task("outer")
        };
        let play = play_with_tags(vec![block], &["shared"]);

        let names = drain(play.clone(), TagFilter::from_cli(Some("deploy"), None));
        assert_eq!(names, vec!["leaf_deploy"]);

        let names = drain(play.clone(), TagFilter::from_cli(Some("blocky"), None));
        assert_eq!(names, vec!["leaf_deploy", "leaf_extra"]);

        let names = drain(play, TagFilter::from_cli(Some("shared"), None));
        assert_eq!(names, vec!["leaf_deploy", "leaf_extra"]);
    }

    #[test]
    fn test_play_tag_skip_filters_inherited() {
        // Play tagged [setup]; user passes --skip-tags setup. Nothing
        // should run — the inherited tag is in the skip list.
        let play = play_with_tags(
            vec![make_task("a"), make_task("b")],
            &["setup"],
        );
        let names = drain(play, TagFilter::from_cli(None, Some("setup")));
        assert!(names.is_empty());
    }

    #[test]
    fn test_no_play_tags_preserves_prior_behavior() {
        // Sanity guard: when play.tags is empty (the default), the iterator
        // must behave identically to before this change. A task with its
        // own tag should still be filterable, and untagged tasks still run
        // under the default empty filter.
        let play = make_play(vec![
            tagged("alpha", &["one"]),
            make_task("untagged"),
        ]);
        let names = drain(play.clone(), TagFilter::default());
        assert_eq!(names, vec!["alpha", "untagged"]);

        let names = drain(play, TagFilter::from_cli(Some("one"), None));
        assert_eq!(names, vec!["alpha"]);
    }
}
