use std::collections::{HashMap, HashSet};
use std::sync::Arc;

use ansible_playbook::Task;
use ansible_utils::AggregateStats;
use ansible_vars::VariableManager;
use async_trait::async_trait;
use tokio::sync::Semaphore;
use tracing::{debug, warn};

use crate::play_iterator::{BlockPhase, HostState, NextTask, PlayIterator, PlayPhase, RunState};
use crate::strategy::{StrategyPlugin, StrategyResult};
use crate::task_executor::TaskExecutor;
use crate::ExecutorError;

/// The default "linear" strategy: execute each task on all hosts
/// before moving to the next task.
pub struct LinearStrategy;

#[async_trait]
impl StrategyPlugin for LinearStrategy {
    async fn run(
        &self,
        iterator: &mut PlayIterator,
        variable_manager: Arc<VariableManager>,
        stats: &mut AggregateStats,
        forks: usize,
        check_mode: bool,
    ) -> Result<StrategyResult, ExecutorError> {
        let semaphore = Arc::new(Semaphore::new(forks));
        let mut all_results = Vec::new();
        let mut all_ok = true;
        // `max_fail_percentage` is evaluated after every lockstep pass. The
        // denominator is the host count at play start (matching Python
        // Ansible) — hosts that become unreachable or terminally failed stay
        // in the denominator so the percentage doesn't silently creep up as
        // hosts drop out.
        let max_fail_pct = iterator.play.max_fail_percentage;
        let total_hosts = iterator.get_hosts().len();
        let play_vars = iterator.play.vars.clone();
        // Hosts that have had an unrecoverable failure. A failure inside a
        // block's main body is NOT terminal if a rescue path exists — the
        // rescue may succeed. A failure in rescue/always, or in a main body
        // with no rescue, is terminal and flags the play as failed.
        let mut failed_hosts: HashSet<Arc<str>> = HashSet::new();
        // handler name -> set of hosts that notified it (insertion order preserved
        // by walking play.handlers when flushing).
        let mut notified_per_host: HashMap<String, HashSet<Arc<str>>> = HashMap::new();

        // Lockstep-ish loop: each iteration we look at every active host's
        // next task and dispatch them in parallel. Hosts at the same task
        // (identified by phase + task index + block sub-phase) run together.
        // This lets rescue/always blocks "desync" a failed host from the
        // others while still keeping everyone else in step.
        loop {
            let active_hosts = iterator.get_active_hosts();
            if active_hosts.is_empty() {
                break;
            }

            // Partition hosts by what they want to do next.
            let mut setup_hosts: Vec<Arc<str>> = Vec::new();
            // Per-host pending work: (host, task, new_state, pre_state, block_vars)
            // pre_state is captured BEFORE get_next_task_for_host so that on
            // failure we can transition the iterator back to the actual
            // failed task's position (which mark_host_failed inspects).
            type WorkItem = (Arc<str>, Task, HostState, HostState, Option<HashMap<String, serde_json::Value>>);
            let mut work: Vec<WorkItem> = Vec::new();

            for host in &active_hosts {
                let pre_state = iterator
                    .get_host_state(host)
                    .cloned()
                    .unwrap_or_default();
                match iterator.get_next_task_for_host(host) {
                    NextTask::Task { task, host_state, block_vars } => {
                        work.push((Arc::clone(host), task.clone(), host_state, pre_state, block_vars));
                    }
                    NextTask::Setup { host_state: _ } => {
                        setup_hosts.push(Arc::clone(host));
                    }
                    NextTask::Complete => {
                        // Preserve `run_state` across the Complete
                        // transition so the handler-flush phase can still
                        // tell apart hosts that succeeded, failed, or are
                        // unreachable. Without this, a failed host's
                        // run_state would be silently reset to `Running`
                        // by `HostState::default()`.
                        let prev_run_state = iterator
                            .get_host_state(host)
                            .map(|s| s.run_state)
                            .unwrap_or(RunState::Running);
                        iterator.set_host_state(
                            host,
                            HostState {
                                phase: PlayPhase::Complete,
                                run_state: prev_run_state,
                                ..HostState::default()
                            },
                        );
                    }
                }
            }

            if setup_hosts.is_empty() && work.is_empty() {
                // Every host is already complete.
                break;
            }

            // Native fact gathering: run the `setup` module on every host
            // that still needs it in parallel, stash the ansible_facts, and
            // advance each host to PreTasks.
            if !setup_hosts.is_empty() {
                debug!("TASK [Gathering Facts]");
                let setup_task = Task::minimal_action(
                    "Gathering Facts",
                    "setup",
                    serde_json::json!({}),
                );
                let mut handles = Vec::new();
                for host in &setup_hosts {
                    let sem = semaphore.clone();
                    let host = host.clone();
                    let task = setup_task.clone();
                    let vm = variable_manager.clone();
                    handles.push(tokio::spawn(async move {
                        let _permit = sem.acquire().await.unwrap();
                        let executor = TaskExecutor::new(host.clone(), task, vm).with_check_mode(check_mode);
                        (host, executor.run().await)
                    }));
                }
                for handle in handles {
                    let (host, result) = handle.await.map_err(|e| {
                        ExecutorError::TaskFailed(format!("setup panicked: {e}"))
                    })?;
                    if let Ok(res) = result {
                        if let Some(facts) = res
                            .results
                            .get("ansible_facts")
                            .and_then(|v| v.as_object())
                        {
                            for (k, v) in facts {
                                variable_manager
                                    .set_host_fact(&host, k.clone(), v.clone());
                            }
                        }
                    }
                    // Preserve flags the iterator set up at construction
                    // (notably `start_at_reached`) rather than resetting
                    // to default — otherwise a `--start-at-task` target
                    // would be forgotten for any play that gathers facts.
                    let mut next = iterator
                        .get_host_state(&host)
                        .cloned()
                        .unwrap_or_default();
                    next.phase = PlayPhase::PreTasks;
                    next.pending_setup = false;
                    next.task_idx = 0;
                    next.block_phase = crate::play_iterator::BlockPhase::Main;
                    next.block_task_idx = 0;
                    next.did_rescue = false;
                    next.failed = false;
                    iterator.set_host_state(&host, next);
                }
                // Re-enter the loop so freshly-advanced hosts get their
                // first task picked up alongside everyone else.
                continue;
            }

            // Group display log messages by task name so an observer sees
            // one "TASK [foo]" line per logical task, not per host.
            let mut seen_names: HashSet<String> = HashSet::new();
            for (_, task, _, _, _) in &work {
                let task_name = task
                    .name
                    .as_deref()
                    .unwrap_or("unnamed task")
                    .to_string();
                if seen_names.insert(task_name.clone()) {
                    debug!("TASK [{}]", task_name);
                }
            }

            // Honor `run_once`: bucket work into primaries + shadow groups.
            // Hosts that share a task position (phase + block_phase + task
            // indices) and whose task is `run_once: true` are deduplicated —
            // only the first becomes a primary and actually runs; the others
            // are "shadows" that receive a clone of the primary's result so
            // register/changed_when/iterator state stays consistent across
            // the batch.
            type TaskKey = (PlayPhase, BlockPhase, usize, usize);
            fn key_of(s: &HostState) -> TaskKey {
                (s.phase, s.block_phase, s.task_idx, s.block_task_idx)
            }
            let mut primaries: Vec<WorkItem> = Vec::new();
            let mut shadow_buckets: Vec<Vec<WorkItem>> = Vec::new();
            let mut run_once_keys: Vec<Option<TaskKey>> = Vec::new();
            for item in work.into_iter() {
                if !item.1.run_once {
                    primaries.push(item);
                    shadow_buckets.push(Vec::new());
                    run_once_keys.push(None);
                    continue;
                }
                let key = key_of(&item.3);
                if let Some(idx) = run_once_keys.iter().position(|k| *k == Some(key)) {
                    shadow_buckets[idx].push(item);
                } else {
                    primaries.push(item);
                    shadow_buckets.push(Vec::new());
                    run_once_keys.push(Some(key));
                }
            }

            // Spawn a worker per primary for this step.
            let mut handles = Vec::new();
            for (host, task, new_state, pre_state, bv) in primaries {
                let sem = semaphore.clone();
                let vm = variable_manager.clone();
                let task_cl = task.clone();
                let host_cl = host.clone();
                let pv = play_vars.clone();

                let handle = tokio::spawn(async move {
                    let _permit = sem.acquire().await.unwrap();
                    let executor = TaskExecutor::with_context(
                        host_cl.clone(),
                        task_cl.clone(),
                        vm,
                        pv,
                        bv,
                        None, // role_name — wired once role execution lands
                    ).with_check_mode(check_mode);
                    let result = executor.run().await;
                    (host_cl, task_cl, new_state, pre_state, result)
                });

                handles.push(handle);
            }

            // Build a pending list combining each primary's result with
            // synthesized clones for its run_once shadows. Drained in a
            // single pass below so state mutations apply uniformly.
            type Pending = (Arc<str>, Task, HostState, HostState, Result<ansible_utils::TaskResult, ExecutorError>);
            let mut pending: Vec<Pending> = Vec::new();
            let mut shadow_iter = shadow_buckets.into_iter();
            for handle in handles {
                let (host, task_ref, new_state, pre_state, result) = handle
                    .await
                    .map_err(|e| ExecutorError::TaskFailed(format!("task panicked: {e}")))?;
                let shadows = shadow_iter.next().unwrap_or_default();
                if !shadows.is_empty() {
                    for (sh_host, sh_task, sh_new, sh_pre, _bv) in shadows {
                        let synth = match &result {
                            Ok(tr) => {
                                let mut clone = tr.clone();
                                clone.host = sh_host.clone();
                                Ok(clone)
                            }
                            Err(e) => Err(ExecutorError::TaskFailed(format!(
                                "run_once propagation: {e}"
                            ))),
                        };
                        pending.push((sh_host, sh_task, sh_new, sh_pre, synth));
                    }
                }
                pending.push((host, task_ref, new_state, pre_state, result));
            }

            // Drain this step's results and update host state in the
            // iterator before the next pass.
            for (host, task_ref, new_state, pre_state, result) in pending {

                match result {
                    Ok(result) => {
                        // Handle register: store result as a host variable
                        if let Some(ref var_name) = task_ref.register {
                            let reg_value = serde_json::json!({
                                "changed": result.changed,
                                "failed": result.failed,
                                "skipped": result.skipped,
                                "unreachable": result.unreachable,
                                "msg": result.msg.as_deref().unwrap_or(""),
                                "rc": result.results.get("rc").and_then(|v| v.as_i64()).unwrap_or(0),
                                "stdout": result.results.get("stdout").and_then(|v| v.as_str()).unwrap_or(""),
                                "stdout_lines": result.results.get("stdout_lines").unwrap_or(&serde_json::json!([])),
                                "stderr": result.results.get("stderr").and_then(|v| v.as_str()).unwrap_or(""),
                                "stderr_lines": result.results.get("stderr_lines").unwrap_or(&serde_json::json!([])),
                                "results": result.results,
                            });
                            variable_manager.set_host_fact(
                                &host,
                                var_name.clone(),
                                reg_value,
                            );
                        }

                        // Handle set_fact: store ansible_facts as host variables
                        if let Some(facts) = result
                            .results
                            .get("ansible_facts")
                            .and_then(|v| v.as_object())
                        {
                            for (k, v) in facts {
                                variable_manager.set_host_fact(&host, k.clone(), v.clone());
                            }
                        }

                        // Update stats and iterator state
                        if result.unreachable {
                            stats.record_unreachable(&host);
                            iterator.mark_host_unreachable(&host);
                            all_ok = false;
                        } else if result.failed {
                            stats.record(&host, false, true, false);
                            if !task_ref.ignore_errors {
                                // For failure handling, restore the
                                // pre-advancement block/task position so that
                                // mark_host_failed correctly identifies the
                                // block the failed task lives in. We still
                                // take the new_state's PHASE so we don't
                                // re-run setup.
                                let recovery = HostState {
                                    phase: new_state.phase,
                                    pending_setup: false,
                                    task_idx: pre_state.task_idx,
                                    block_phase: pre_state.block_phase,
                                    block_task_idx: pre_state.block_task_idx,
                                    did_rescue: pre_state.did_rescue,
                                    failed: pre_state.failed,
                                    run_state: RunState::Running,
                                    start_at_reached: pre_state.start_at_reached,
                                };
                                iterator.set_host_state(&host, recovery);
                                iterator.mark_host_failed(&host);
                                // A failure is TERMINAL unless mark_host_failed
                                // transitioned the host into BlockPhase::Rescue
                                // (which means a rescue may still succeed).
                                // Rescue/always failures are always terminal
                                // even when their always branch continues as
                                // cleanup.
                                let entered_rescue = iterator
                                    .get_host_state(&host)
                                    .map(|s| s.block_phase == crate::play_iterator::BlockPhase::Rescue)
                                    .unwrap_or(false);
                                if !entered_rescue {
                                    failed_hosts.insert(host.clone());
                                    all_ok = false;
                                }
                            } else {
                                stats.record_ignored(&host);
                                iterator.set_host_state(&host, new_state);
                            }
                        } else if result.skipped {
                            stats.record(&host, false, false, true);
                            iterator.set_host_state(&host, new_state);
                        } else {
                            stats.record(&host, result.changed, false, false);
                            if result.changed {
                                for handler_name in &task_ref.notify {
                                    notified_per_host
                                        .entry(handler_name.clone())
                                        .or_default()
                                        .insert(host.clone());
                                }
                            }
                            iterator.set_host_state(&host, new_state);
                        }

                        // Attach task name so the callback layer can emit
                        // TASK banners when the task changes. Also attach the
                        // action (module name) so callbacks can distinguish
                        // skipped meta tasks (`v2_runner_on_skipped` with
                        // `action: meta`) from skips of other modules.
                        let task_name = task_ref
                            .name
                            .as_deref()
                            .unwrap_or("unnamed task")
                            .to_string();
                        let mut result = result;
                        result.task_fields.insert(
                            "name".to_string(),
                            serde_json::Value::String(task_name),
                        );
                        if let Some(action) = task_ref.action.keys().next() {
                            result.task_fields.insert(
                                "action".to_string(),
                                serde_json::Value::String(action.clone()),
                            );
                        }
                        all_results.push(result);
                    }
                    Err(e) => {
                        warn!("Task execution error on {}: {}", host, e);
                        stats.record(&host, false, true, false);
                        iterator.mark_host_failed(&host);
                        all_ok = false;
                    }
                }
            }

            // Enforce `max_fail_percentage`: after each lockstep pass,
            // if the ratio of terminally-failed hosts to the original host
            // count strictly exceeds the threshold, abort the play. Ansible
            // uses a strict `>` comparison, so `max_fail_percentage: 0`
            // aborts on any failure, and `100` never aborts. Hosts that are
            // already terminally failed retain their state; surviving hosts
            // simply stop being driven because we break out of the task loop.
            if let Some(threshold) = max_fail_pct {
                if total_hosts > 0 && !failed_hosts.is_empty() {
                    let pct = (failed_hosts.len() as f64 / total_hosts as f64) * 100.0;
                    if pct > threshold {
                        debug!(
                            "max_fail_percentage ({}%) exceeded: {}/{} hosts failed",
                            threshold,
                            failed_hosts.len(),
                            total_hosts
                        );
                        all_ok = false;
                        break;
                    }
                }
            }

            if iterator.all_complete() {
                break;
            }
        }

        // Flush handlers: walk play.handlers in definition order; for each
        // notified one, run on the hosts that notified it (and that are
        // still healthy — or any non-unreachable host if `force_handlers`
        // is set, mirroring `--force-handlers` / `force_handlers: yes`).
        let force_handlers = iterator.play.force_handlers;
        let handlers = iterator.play.handlers.clone();
        for handler in &handlers {
            let handler_name = match handler.name.as_deref() {
                Some(n) => n,
                None => continue,
            };
            let notifying = match notified_per_host.get(handler_name) {
                Some(s) => s.clone(),
                None => continue,
            };
            // Filter to hosts still healthy. With `force_handlers` we
            // also include hosts that failed after notifying. Unreachable
            // hosts are always skipped — the connection plugin can't talk
            // to them.
            let target_hosts: Vec<Arc<str>> = notifying
                .into_iter()
                .filter(|h| {
                    iterator
                        .get_host_state(h)
                        .map(|s| match s.run_state {
                            RunState::Running => true,
                            RunState::Failed => force_handlers,
                            RunState::Unreachable => false,
                        })
                        .unwrap_or(false)
                })
                .collect();
            if target_hosts.is_empty() {
                continue;
            }

            debug!("RUNNING HANDLER [{}]", handler_name);
            let mut handles = Vec::new();
            for host in &target_hosts {
                let sem = semaphore.clone();
                let host = host.clone();
                let task = handler.clone();
                let vm = variable_manager.clone();
                handles.push(tokio::spawn(async move {
                    let _permit = sem.acquire().await.unwrap();
                    let executor = TaskExecutor::new(host.clone(), task, vm).with_check_mode(check_mode);
                    (host, executor.run().await)
                }));
            }

            for handle in handles {
                let (host, result) = handle
                    .await
                    .map_err(|e| ExecutorError::TaskFailed(format!("handler panicked: {e}")))?;
                match result {
                    Ok(result) => {
                        if result.unreachable {
                            stats.record_unreachable(&host);
                            iterator.mark_host_unreachable(&host);
                            all_ok = false;
                        } else if result.failed {
                            stats.record(&host, false, true, false);
                            iterator.mark_host_failed(&host);
                            all_ok = false;
                        } else if !result.skipped {
                            stats.record(&host, result.changed, false, false);
                        }
                        let mut result = result;
                        result.task_fields.insert(
                            "name".to_string(),
                            serde_json::Value::String(
                                handler_name.to_string(),
                            ),
                        );
                        if let Some(action) = handler.action.keys().next() {
                            result.task_fields.insert(
                                "action".to_string(),
                                serde_json::Value::String(action.clone()),
                            );
                        }
                        all_results.push(result);
                    }
                    Err(e) => {
                        warn!("Handler error on {}: {}", host, e);
                        stats.record(&host, false, true, false);
                        all_ok = false;
                    }
                }
            }
        }

        Ok(StrategyResult {
            results: all_results,
            all_ok,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use ansible_inventory::InventoryManager;

    /// Build an InventoryManager where every listed host has
    /// `ansible_connection: local` set, so tests can run real tasks
    /// without attempting SSH.
    fn local_inventory(hosts: &[&str]) -> Arc<InventoryManager> {
        let mut inv = InventoryManager::new();
        for h in hosts {
            let mut host = ansible_utils::Host::new(*h);
            host.vars.insert(
                "ansible_connection".into(),
                ansible_utils::AnsibleValue::String("local".into()),
            );
            inv.data_mut().add_host(host);
        }
        Arc::new(inv)
    }

    fn make_task(name: &str) -> Task {
        Task {
            name: Some(name.to_string()),
            action: {
                let mut m = HashMap::new();
                m.insert(
                    "debug".into(),
                    serde_json::json!({"msg": "hello"}),
                );
                m
            },
            when_conditions: Vec::new(),
            register: None,
            loop_source: None,
            loop_items: None,
            with_items: None,
            loop_control: None,
            notify: Vec::new(),
            tags: Default::default(),
            use_become: None,
            become_user: None,
            become_method: None,
            become_flags: None,
            become_pass: None,
            delegate_to: None,
            ignore_errors: false,
            run_once: false,
            changed_when: Vec::new(),
            failed_when: Vec::new(),
            retries: 3,
            delay: 5,
            until: Vec::new(),
            no_log: false,
            args: None,
            environment: None,
            vars: None,
            block: None,
            rescue: None,
            always: None,
            connection: None,
            timeout: None,
            check_mode: None,
        }
    }

    fn make_play(tasks: Vec<Task>) -> ansible_playbook::Play {
        ansible_playbook::Play {
            name: Some("test".into()),
            hosts: Some("all".into()),
            tasks,
            pre_tasks: Vec::new(),
            post_tasks: Vec::new(),
            handlers: Vec::new(),
            roles: Vec::new(),
            vars: HashMap::new(),
            vars_files: Vec::new(),
            environment: HashMap::new(),
            gather_facts: Some(false),
            strategy: "linear".into(),
            serial: Vec::new(),
            max_fail_percentage: None,
            force_handlers: false,
            use_become: None,
            become_user: None,
            become_method: None,
            connection: None,
            tags: Default::default(),
            when_conditions: Vec::new(),
            any_errors_fatal: None,
            ignore_errors: None,
            ignore_unreachable: None,
            module_defaults: None,
            collections: None,
        }
    }

    #[tokio::test]
    async fn test_linear_strategy_basic() {
        let play = make_play(vec![make_task("task1"), make_task("task2")]);
        let hosts = vec!["host1".to_string(), "host2".to_string()];
        let mut iterator = PlayIterator::new(play, &hosts);
        let inv = Arc::new(InventoryManager::new());
        let vm = Arc::new(VariableManager::new(inv));
        let mut stats = AggregateStats::new();

        let strategy = LinearStrategy;
        let result = strategy
            .run(&mut iterator, vm, &mut stats, 5, false)
            .await
            .unwrap();

        // 2 tasks × 2 hosts = 4 results
        assert_eq!(result.results.len(), 4);
        assert!(result.all_ok);
        assert!(iterator.all_complete());
    }

    #[tokio::test]
    async fn test_handler_flush_runs_only_when_notified() {
        // Task that always reports changed and notifies "restart svc"
        let mut changed_task = make_task("changed");
        changed_task.action.clear();
        changed_task.action.insert(
            "command".into(),
            serde_json::json!("true"),
        );
        changed_task.notify = vec!["restart svc".into()];

        // Handler
        let mut handler = make_task("restart svc");
        handler.action.insert(
            "debug".into(),
            serde_json::json!({"msg": "restarted"}),
        );

        // Unnotified handler
        let mut other_handler = make_task("other");
        other_handler.action.insert(
            "debug".into(),
            serde_json::json!({"msg": "no"}),
        );

        let mut play = make_play(vec![changed_task]);
        play.handlers = vec![handler, other_handler];

        let hosts = vec!["h1".to_string()];
        let mut iterator = PlayIterator::new(play, &hosts);
        let inv = local_inventory(&["h1"]);
        let vm = Arc::new(VariableManager::new(inv));
        let mut stats = AggregateStats::new();

        let result = LinearStrategy
            .run(&mut iterator, vm, &mut stats, 5, false)
            .await
            .unwrap();

        // 1 main task + 1 notified handler = 2 results (other handler skipped)
        assert_eq!(result.results.len(), 2);
        assert!(result.all_ok);
        assert_eq!(
            result.results[1].msg.as_deref(),
            Some("restarted")
        );
    }

    #[tokio::test]
    async fn test_handler_not_run_when_unchanged() {
        // debug task is always ok=not-changed
        let mut t = make_task("noop");
        t.notify = vec!["h".into()];

        let mut handler = make_task("h");
        handler.action.insert(
            "debug".into(),
            serde_json::json!({"msg": "should not run"}),
        );

        let mut play = make_play(vec![t]);
        play.handlers = vec![handler];

        let hosts = vec!["h1".to_string()];
        let mut iterator = PlayIterator::new(play, &hosts);
        let inv = Arc::new(InventoryManager::new());
        let vm = Arc::new(VariableManager::new(inv));
        let mut stats = AggregateStats::new();

        let result = LinearStrategy
            .run(&mut iterator, vm, &mut stats, 5, false)
            .await
            .unwrap();

        // Only 1 result — handler did not run
        assert_eq!(result.results.len(), 1);
    }

    /// Build the fixture used by the `force_handlers` pair of tests.
    /// Play has: a changed task that notifies "h", then a `fail`. The
    /// host is in `Failed` state when the flush phase runs.
    fn force_handlers_fixture(force_handlers: bool) -> ansible_playbook::Play {
        let mut changed_task = make_task("changed");
        changed_task.action.clear();
        changed_task.action.insert(
            "command".into(),
            serde_json::json!("true"),
        );
        changed_task.notify = vec!["h".into()];

        let fail = make_fail_task("boom");

        let mut handler = make_task("h");
        handler.action.insert(
            "debug".into(),
            serde_json::json!({"msg": "ran-after-failure"}),
        );

        let mut play = make_play(vec![changed_task, fail]);
        play.handlers = vec![handler];
        play.force_handlers = force_handlers;
        play
    }

    #[tokio::test]
    async fn test_force_handlers_off_skips_handler_on_failed_host() {
        let play = force_handlers_fixture(false);
        let hosts = vec!["h1".to_string()];
        let mut iterator = PlayIterator::new(play, &hosts);
        let inv = local_inventory(&["h1"]);
        let vm = Arc::new(VariableManager::new(inv));
        let mut stats = AggregateStats::new();

        let result = LinearStrategy
            .run(&mut iterator, vm, &mut stats, 5, false)
            .await
            .unwrap();

        // changed + fail + (handler skipped because host failed) = 2 results
        assert_eq!(result.results.len(), 2, "{:?}", result.results);
        assert!(!result.all_ok);
        let ran_handler = result
            .results
            .iter()
            .any(|r| r.msg.as_deref() == Some("ran-after-failure"));
        assert!(
            !ran_handler,
            "handler should be skipped when force_handlers is off"
        );
    }

    #[tokio::test]
    async fn test_force_handlers_on_runs_handler_on_failed_host() {
        let play = force_handlers_fixture(true);
        let hosts = vec!["h1".to_string()];
        let mut iterator = PlayIterator::new(play, &hosts);
        let inv = local_inventory(&["h1"]);
        let vm = Arc::new(VariableManager::new(inv));
        let mut stats = AggregateStats::new();

        let result = LinearStrategy
            .run(&mut iterator, vm, &mut stats, 5, false)
            .await
            .unwrap();

        // changed + fail + handler-ran = 3 results
        assert_eq!(result.results.len(), 3, "{:?}", result.results);
        assert!(!result.all_ok, "play still failed overall");
        let ran_handler = result
            .results
            .iter()
            .any(|r| r.msg.as_deref() == Some("ran-after-failure"));
        assert!(
            ran_handler,
            "handler should run on failed host when force_handlers is on"
        );
    }

    #[tokio::test]
    async fn test_register_stores_result_as_var() {
        // Task 1: command that registers its output
        let mut cmd_task = make_task("get hostname");
        cmd_task.action.clear();
        cmd_task.action.insert(
            "command".into(),
            serde_json::json!("echo testvalue"),
        );
        cmd_task.register = Some("cmd_result".into());

        // Task 2: debug that references the registered variable
        let mut debug_task = make_task("show result");
        debug_task.action.clear();
        debug_task.action.insert(
            "debug".into(),
            serde_json::json!({"var": "cmd_result"}),
        );

        let play = make_play(vec![cmd_task, debug_task]);
        let hosts = vec!["h1".to_string()];
        let mut iterator = PlayIterator::new(play, &hosts);
        let inv = local_inventory(&["h1"]);
        let vm = Arc::new(VariableManager::new(inv));
        let mut stats = AggregateStats::new();

        let result = LinearStrategy
            .run(&mut iterator, vm.clone(), &mut stats, 5, false)
            .await
            .unwrap();

        assert!(result.all_ok, "all tasks should succeed");
        assert_eq!(result.results.len(), 2);

        // Verify the registered variable is accessible in variable_manager
        let host_vars = vm.get_vars("h1", &HashMap::new(), None, None, None);
        assert!(
            host_vars.contains_key("cmd_result"),
            "cmd_result should be registered: {:?}",
            host_vars.keys().collect::<Vec<_>>()
        );
    }

    #[tokio::test]
    async fn test_set_fact_stores_vars() {
        let mut fact_task = make_task("set a fact");
        fact_task.action.clear();
        fact_task.action.insert(
            "set_fact".into(),
            serde_json::json!({"my_var": "my_value"}),
        );

        let mut debug_task = make_task("use fact");
        debug_task.action.clear();
        debug_task.action.insert(
            "debug".into(),
            serde_json::json!({"var": "my_var"}),
        );

        let play = make_play(vec![fact_task, debug_task]);
        let hosts = vec!["h1".to_string()];
        let mut iterator = PlayIterator::new(play, &hosts);
        let inv = Arc::new(InventoryManager::new());
        let vm = Arc::new(VariableManager::new(inv));
        let mut stats = AggregateStats::new();

        let result = LinearStrategy
            .run(&mut iterator, vm.clone(), &mut stats, 5, false)
            .await
            .unwrap();

        assert!(result.all_ok);

        // Verify set_fact var is accessible
        let host_vars = vm.get_vars("h1", &HashMap::new(), None, None, None);
        assert_eq!(
            host_vars.get("my_var").and_then(|v| v.as_str()),
            Some("my_value"),
            "set_fact should store my_var"
        );
    }

    #[tokio::test]
    async fn test_linear_strategy_single_host() {
        let play = make_play(vec![make_task("task1")]);
        let hosts = vec!["host1".to_string()];
        let mut iterator = PlayIterator::new(play, &hosts);
        let inv = Arc::new(InventoryManager::new());
        let vm = Arc::new(VariableManager::new(inv));
        let mut stats = AggregateStats::new();

        let strategy = LinearStrategy;
        let result = strategy
            .run(&mut iterator, vm, &mut stats, 5, false)
            .await
            .unwrap();

        assert_eq!(result.results.len(), 1);
        assert!(result.all_ok);
    }

    /// Build a task that invokes the `fail` module with a fixed message.
    fn make_fail_task(name: &str) -> Task {
        let mut t = make_task(name);
        t.action.clear();
        t.action.insert(
            "fail".into(),
            serde_json::json!({"msg": format!("forced-failure:{name}")}),
        );
        t
    }

    /// Build a task that wraps a list of block/rescue/always children.
    fn make_block_task(
        name: &str,
        block: Option<Vec<Task>>,
        rescue: Option<Vec<Task>>,
        always: Option<Vec<Task>>,
    ) -> Task {
        let mut t = make_task(name);
        t.block = block;
        t.rescue = rescue;
        t.always = always;
        t
    }

    #[tokio::test]
    async fn test_block_rescue_runs_when_main_fails() {
        // Main block's first task fails; rescue task should run.
        // Play flow: [block{main:[fail], rescue:[debug]}, debug after]
        let block = make_block_task(
            "b1",
            Some(vec![make_fail_task("boom")]),
            Some(vec![make_task("recover")]),
            None,
        );
        let after = make_task("after_block");

        let play = make_play(vec![block, after]);
        let hosts = vec!["h1".to_string()];
        let mut iterator = PlayIterator::new(play, &hosts);
        let inv = Arc::new(InventoryManager::new());
        let vm = Arc::new(VariableManager::new(inv));
        let mut stats = AggregateStats::new();

        let result = LinearStrategy
            .run(&mut iterator, vm, &mut stats, 5, false)
            .await
            .unwrap();

        // boom (failed) + recover (rescue) + after_block = 3 results
        assert_eq!(result.results.len(), 3, "got {:?}", result.results);
        // all_ok is true when rescue recovered the host
        assert!(result.all_ok, "rescue should recover the host");
        assert!(iterator.all_complete());
    }

    #[tokio::test]
    async fn test_block_always_runs_even_on_failure() {
        // Block with no rescue but an always section; main fails.
        // Play flow: [block{main:[fail], always:[debug]}]
        // Expectation: fail runs, always runs, play fails overall.
        let block = make_block_task(
            "b1",
            Some(vec![make_fail_task("boom")]),
            None,
            Some(vec![make_task("cleanup")]),
        );
        let play = make_play(vec![block]);
        let hosts = vec!["h1".to_string()];
        let mut iterator = PlayIterator::new(play, &hosts);
        let inv = Arc::new(InventoryManager::new());
        let vm = Arc::new(VariableManager::new(inv));
        let mut stats = AggregateStats::new();

        let result = LinearStrategy
            .run(&mut iterator, vm, &mut stats, 5, false)
            .await
            .unwrap();

        // boom + cleanup = 2 results
        assert_eq!(result.results.len(), 2);
        assert!(!result.all_ok, "play should report failure");
        // Verify the cleanup task actually ran
        let saw_cleanup = result
            .results
            .iter()
            .any(|r| r.msg.as_deref().unwrap_or("").contains("cleanup"))
            || result.results.iter().any(|r| !r.failed);
        assert!(saw_cleanup, "always/cleanup task must run");
    }

    #[tokio::test]
    async fn test_block_always_runs_on_success() {
        // Block with always section; main succeeds -> always still runs.
        let block = make_block_task(
            "b1",
            Some(vec![make_task("main_ok")]),
            None,
            Some(vec![make_task("cleanup")]),
        );
        let play = make_play(vec![block]);
        let hosts = vec!["h1".to_string()];
        let mut iterator = PlayIterator::new(play, &hosts);
        let inv = Arc::new(InventoryManager::new());
        let vm = Arc::new(VariableManager::new(inv));
        let mut stats = AggregateStats::new();

        let result = LinearStrategy
            .run(&mut iterator, vm, &mut stats, 5, false)
            .await
            .unwrap();

        // main_ok + cleanup = 2 results; both ok
        assert_eq!(result.results.len(), 2);
        assert!(result.all_ok);
    }

    #[tokio::test]
    async fn test_block_rescue_failure_still_runs_always() {
        // Main fails -> rescue runs -> rescue fails -> always still runs.
        // The play is ultimately failed.
        let block = make_block_task(
            "b1",
            Some(vec![make_fail_task("boom")]),
            Some(vec![make_fail_task("rescue_boom")]),
            Some(vec![make_task("cleanup")]),
        );
        let play = make_play(vec![block]);
        let hosts = vec!["h1".to_string()];
        let mut iterator = PlayIterator::new(play, &hosts);
        let inv = Arc::new(InventoryManager::new());
        let vm = Arc::new(VariableManager::new(inv));
        let mut stats = AggregateStats::new();

        let result = LinearStrategy
            .run(&mut iterator, vm, &mut stats, 5, false)
            .await
            .unwrap();

        // boom + rescue_boom + cleanup = 3 results
        assert_eq!(result.results.len(), 3);
        assert!(!result.all_ok, "rescue failure should mark play failed");
    }

    #[tokio::test]
    async fn test_non_block_failure_stops_host() {
        // Non-block task failure (without ignore_errors) should remove the
        // failing host from active set. Other hosts keep going.
        let fail_task = make_fail_task("boom");
        let follow_up = make_task("next");
        let play = make_play(vec![fail_task, follow_up]);

        let hosts = vec!["h1".to_string(), "h2".to_string()];
        // Only h1 will fail because both hosts run the same task; we verify
        // that both stop at the failing step.
        let mut iterator = PlayIterator::new(play, &hosts);
        let inv = Arc::new(InventoryManager::new());
        let vm = Arc::new(VariableManager::new(inv));
        let mut stats = AggregateStats::new();

        let result = LinearStrategy
            .run(&mut iterator, vm, &mut stats, 5, false)
            .await
            .unwrap();

        // Both hosts run the failing task (2 results), neither runs "next".
        assert_eq!(result.results.len(), 2);
        assert!(!result.all_ok);
    }

    #[tokio::test]
    async fn test_non_block_failure_with_ignore_errors_continues() {
        // ignore_errors=true should let the host proceed past the failure.
        let mut fail_task = make_fail_task("boom");
        fail_task.ignore_errors = true;
        let follow_up = make_task("next");
        let play = make_play(vec![fail_task, follow_up]);

        let hosts = vec!["h1".to_string()];
        let mut iterator = PlayIterator::new(play, &hosts);
        let inv = Arc::new(InventoryManager::new());
        let vm = Arc::new(VariableManager::new(inv));
        let mut stats = AggregateStats::new();

        let result = LinearStrategy
            .run(&mut iterator, vm, &mut stats, 5, false)
            .await
            .unwrap();

        // boom (failed-but-ignored) + next = 2 results
        assert_eq!(result.results.len(), 2);
    }

    #[tokio::test]
    async fn test_block_rescue_with_multi_host_partial_failure() {
        // Two hosts: one fails the main task, one succeeds.
        // The failed host should run rescue while the successful one skips
        // straight past the block.
        // We use delegate through the fail module with a when condition
        // matching only h1.
        let mut fail_on_h1 = make_fail_task("boom");
        fail_on_h1.when_conditions = vec!["inventory_hostname == 'h1'".into()];

        let rescue_task = make_task("recover");
        let after = make_task("after");

        let block = make_block_task(
            "b1",
            Some(vec![fail_on_h1]),
            Some(vec![rescue_task]),
            None,
        );
        let play = make_play(vec![block, after]);

        let hosts = vec!["h1".to_string(), "h2".to_string()];
        let mut iterator = PlayIterator::new(play, &hosts);
        let inv = Arc::new(InventoryManager::new());
        let vm = Arc::new(VariableManager::new(inv));
        let mut stats = AggregateStats::new();

        let result = LinearStrategy
            .run(&mut iterator, vm, &mut stats, 5, false)
            .await
            .unwrap();

        // h1: fail, recover, after = 3 results
        // h2: fail-skipped, after = 2 results
        // total = 5
        assert_eq!(result.results.len(), 5, "got {:?}", result.results);
        assert!(result.all_ok, "rescue recovered h1");
        assert!(iterator.all_complete());
    }

    fn tag_task(name: &str, tags: &[&str]) -> Task {
        Task {
            tags: ansible_playbook::TagSpec::Tags(
                tags.iter().map(|s| s.to_string()).collect(),
            ),
            ..make_task(name)
        }
    }

    #[tokio::test]
    async fn test_linear_tag_filter_include_only_matching_runs() {
        let play = make_play(vec![
            tag_task("t1", &["foo"]),
            tag_task("t2", &["bar"]),
            tag_task("t3", &["foo", "baz"]),
        ]);
        let hosts = vec!["h1".to_string()];
        let filter = ansible_playbook::TagFilter::from_cli(Some("foo"), None);
        let mut iterator = PlayIterator::with_tag_filter(play, &hosts, filter);
        let inv = Arc::new(InventoryManager::new());
        let vm = Arc::new(VariableManager::new(inv));
        let mut stats = AggregateStats::new();

        let result = LinearStrategy
            .run(&mut iterator, vm, &mut stats, 5, false)
            .await
            .unwrap();

        // Only t1 and t3 should execute.
        assert_eq!(result.results.len(), 2);
        assert!(result.all_ok);
        assert!(iterator.all_complete());
    }

    #[tokio::test]
    async fn test_linear_tag_filter_skip_excludes_matching() {
        let play = make_play(vec![
            tag_task("t1", &["foo"]),
            make_task("t2"),
            tag_task("t3", &["bar"]),
        ]);
        let hosts = vec!["h1".to_string(), "h2".to_string()];
        let filter = ansible_playbook::TagFilter::from_cli(None, Some("foo"));
        let mut iterator = PlayIterator::with_tag_filter(play, &hosts, filter);
        let inv = Arc::new(InventoryManager::new());
        let vm = Arc::new(VariableManager::new(inv));
        let mut stats = AggregateStats::new();

        let result = LinearStrategy
            .run(&mut iterator, vm, &mut stats, 5, false)
            .await
            .unwrap();

        // t2 + t3 execute on each of 2 hosts = 4 results.
        assert_eq!(result.results.len(), 4);
        assert!(result.all_ok);
    }

    #[tokio::test]
    async fn test_linear_tag_filter_always_tag_always_runs() {
        let play = make_play(vec![
            tag_task("t1", &["foo"]),
            tag_task("critical", &["always"]),
            tag_task("t3", &["bar"]),
        ]);
        let hosts = vec!["h1".to_string()];
        // User only asks for 'foo' — critical must still run.
        let filter = ansible_playbook::TagFilter::from_cli(Some("foo"), None);
        let mut iterator = PlayIterator::with_tag_filter(play, &hosts, filter);
        let inv = Arc::new(InventoryManager::new());
        let vm = Arc::new(VariableManager::new(inv));
        let mut stats = AggregateStats::new();

        let result = LinearStrategy
            .run(&mut iterator, vm, &mut stats, 5, false)
            .await
            .unwrap();

        assert_eq!(result.results.len(), 2);
        assert!(result.all_ok);
    }

    #[tokio::test]
    async fn test_linear_tag_filter_inside_block_inherits() {
        // Block tagged "foo" with untagged inner tasks: inner tasks
        // inherit the tag and should run under --tags foo.
        let block = Task {
            tags: ansible_playbook::TagSpec::Tags(vec!["foo".into()].into()),
            ..make_block_task(
                "b1",
                Some(vec![make_task("inner1"), make_task("inner2")]),
                None,
                None,
            )
        };
        let play = make_play(vec![block, tag_task("other", &["bar"])]);
        let hosts = vec!["h1".to_string()];
        let filter = ansible_playbook::TagFilter::from_cli(Some("foo"), None);
        let mut iterator = PlayIterator::with_tag_filter(play, &hosts, filter);
        let inv = Arc::new(InventoryManager::new());
        let vm = Arc::new(VariableManager::new(inv));
        let mut stats = AggregateStats::new();

        let result = LinearStrategy
            .run(&mut iterator, vm, &mut stats, 5, false)
            .await
            .unwrap();

        assert_eq!(result.results.len(), 2);
        assert!(result.all_ok);
    }

    #[tokio::test]
    async fn test_max_fail_percentage_zero_aborts_on_first_failure() {
        // With threshold 0, any single host failure should immediately
        // abort the play. Here 1/3 = 33% > 0, so a follow-up task must
        // not run on the surviving hosts.
        let mut fail_on_h1 = make_fail_task("boom");
        fail_on_h1.when_conditions = vec!["inventory_hostname == 'h1'".into()];
        let follow_up = make_task("after");

        let mut play = make_play(vec![fail_on_h1, follow_up]);
        play.max_fail_percentage = Some(0.0);

        let hosts = vec!["h1".to_string(), "h2".to_string(), "h3".to_string()];
        let mut iterator = PlayIterator::new(play, &hosts);
        let inv = Arc::new(InventoryManager::new());
        let vm = Arc::new(VariableManager::new(inv));
        let mut stats = AggregateStats::new();

        let result = LinearStrategy
            .run(&mut iterator, vm, &mut stats, 5, false)
            .await
            .unwrap();

        // First task: 3 results (1 failed, 2 skipped-by-when). Second
        // task must not run — 3 results total, not 6.
        assert_eq!(result.results.len(), 3, "got {:?}", result.results);
        assert!(!result.all_ok);
    }

    #[tokio::test]
    async fn test_max_fail_percentage_fifty_tolerates_one_in_three() {
        // 1/3 failed = 33.3% which is NOT > 50, so the play should
        // continue for the surviving hosts.
        let mut fail_on_h1 = make_fail_task("boom");
        fail_on_h1.when_conditions = vec!["inventory_hostname == 'h1'".into()];
        let follow_up = make_task("after");

        let mut play = make_play(vec![fail_on_h1, follow_up]);
        play.max_fail_percentage = Some(50.0);

        let hosts = vec!["h1".to_string(), "h2".to_string(), "h3".to_string()];
        let mut iterator = PlayIterator::new(play, &hosts);
        let inv = Arc::new(InventoryManager::new());
        let vm = Arc::new(VariableManager::new(inv));
        let mut stats = AggregateStats::new();

        let result = LinearStrategy
            .run(&mut iterator, vm, &mut stats, 5, false)
            .await
            .unwrap();

        // First task: 3 results (1 failed, 2 skipped-by-when).
        // Second task: runs on h2 and h3 (h1 is terminally failed) = 2 results.
        // Total = 5. Length alone proves the follow-up was NOT cut short
        // by the max_fail_percentage kill-switch.
        assert_eq!(result.results.len(), 5, "got {:?}", result.results);
        // Play still flags !all_ok because one host failed.
        assert!(!result.all_ok);
    }

    #[tokio::test]
    async fn test_max_fail_percentage_hundred_never_aborts() {
        // threshold 100 → strict `>` is never satisfied even when every
        // host fails. Subsequent tasks should still be attempted for
        // whatever hosts survive (here: none).
        let fail_task = make_fail_task("boom");
        let follow_up = make_task("after");

        let mut play = make_play(vec![fail_task, follow_up]);
        play.max_fail_percentage = Some(100.0);

        let hosts = vec!["h1".to_string(), "h2".to_string()];
        let mut iterator = PlayIterator::new(play, &hosts);
        let inv = Arc::new(InventoryManager::new());
        let vm = Arc::new(VariableManager::new(inv));
        let mut stats = AggregateStats::new();

        let result = LinearStrategy
            .run(&mut iterator, vm, &mut stats, 5, false)
            .await
            .unwrap();

        // Both hosts fail the first task (2 results). Both are
        // terminally failed so no host remains active for "after".
        // The key assertion is that the strategy does NOT bail out
        // on the enforcement branch — it runs to natural completion.
        assert_eq!(result.results.len(), 2);
        assert!(!result.all_ok);
        assert!(iterator.all_complete());
    }

    #[tokio::test]
    async fn test_play_vars_flow_through_to_task_executor() {
        // A debug task that templates {{ greeting }} should resolve
        // the variable from play.vars when the strategy passes it.
        let mut t = make_task("greet");
        t.action.clear();
        t.action.insert(
            "debug".into(),
            serde_json::json!({"msg": "{{ greeting }}"}),
        );

        let mut play = make_play(vec![t]);
        play.vars.insert(
            "greeting".to_string(),
            serde_json::json!("hello from play"),
        );

        let hosts = vec!["h1".to_string()];
        let mut iterator = PlayIterator::new(play, &hosts);
        let inv = Arc::new(InventoryManager::new());
        let vm = Arc::new(VariableManager::new(inv));
        let mut stats = AggregateStats::new();

        let result = LinearStrategy
            .run(&mut iterator, vm, &mut stats, 5, false)
            .await
            .unwrap();

        assert_eq!(result.results.len(), 1);
        assert!(result.all_ok);
        assert_eq!(
            result.results[0].msg.as_deref(),
            Some("hello from play")
        );
    }

    #[tokio::test]
    async fn test_block_vars_override_play_vars() {
        // Block defines vars: { greeting: "from block" } which should
        // override the play-level value per the 22-level precedence
        // (block_vars level 16 > play_vars level 12).
        let mut leaf = make_task("greet");
        leaf.action.clear();
        leaf.action.insert(
            "debug".into(),
            serde_json::json!({"msg": "{{ greeting }}"}),
        );

        let mut block = make_block_task("b1", Some(vec![leaf]), None, None);
        let mut bv = HashMap::new();
        bv.insert("greeting".to_string(), serde_json::json!("from block"));
        block.vars = Some(bv);

        let mut play = make_play(vec![block]);
        play.vars.insert(
            "greeting".to_string(),
            serde_json::json!("from play"),
        );

        let hosts = vec!["h1".to_string()];
        let mut iterator = PlayIterator::new(play, &hosts);
        let inv = Arc::new(InventoryManager::new());
        let vm = Arc::new(VariableManager::new(inv));
        let mut stats = AggregateStats::new();

        let result = LinearStrategy
            .run(&mut iterator, vm, &mut stats, 5, false)
            .await
            .unwrap();

        assert_eq!(result.results.len(), 1);
        assert!(result.all_ok);
        assert_eq!(
            result.results[0].msg.as_deref(),
            Some("from block")
        );
    }

    #[tokio::test]
    async fn test_extra_vars_override_play_and_block_vars() {
        // Extra vars (level 22) should beat everything else.
        let mut leaf = make_task("greet");
        leaf.action.clear();
        leaf.action.insert(
            "debug".into(),
            serde_json::json!({"msg": "{{ greeting }}"}),
        );

        let mut block = make_block_task("b1", Some(vec![leaf]), None, None);
        let mut bv = HashMap::new();
        bv.insert("greeting".to_string(), serde_json::json!("from block"));
        block.vars = Some(bv);

        let mut play = make_play(vec![block]);
        play.vars.insert(
            "greeting".to_string(),
            serde_json::json!("from play"),
        );

        let hosts = vec!["h1".to_string()];
        let mut iterator = PlayIterator::new(play, &hosts);
        let inv = Arc::new(InventoryManager::new());
        let mut vm = VariableManager::new(inv);
        let mut ev = HashMap::new();
        ev.insert("greeting".to_string(), serde_json::json!("from extra"));
        vm.set_extra_vars(ev);
        let vm = Arc::new(vm);
        let mut stats = AggregateStats::new();

        let result = LinearStrategy
            .run(&mut iterator, vm, &mut stats, 5, false)
            .await
            .unwrap();

        assert_eq!(result.results.len(), 1);
        assert!(result.all_ok);
        assert_eq!(
            result.results[0].msg.as_deref(),
            Some("from extra")
        );
    }

    /// Regression for upstream-sync #143 (PR #86977 / cb535cf3d3):
    /// a `meta` task that is skipped because its `when:` is false must
    /// still produce a TaskResult routed to `v2_runner_on_skipped`,
    /// with `action: meta` attached so callback plugins can identify
    /// the skipped meta event rather than the strategy silently
    /// swallowing it. Mirrors `test/integration/targets/meta_tasks/
    /// test_end_play.yml` upstream, using `end_play` as the
    /// representative meta action.
    #[tokio::test]
    async fn test_skipped_meta_task_emits_callback_payload() {
        let mut meta_task = make_task("conditionally end the play");
        meta_task.action.clear();
        meta_task
            .action
            .insert("meta".into(), serde_json::json!("end_play"));
        meta_task.when_conditions = vec!["false".into()];

        let play = make_play(vec![meta_task]);
        let hosts = vec!["h1".to_string()];
        let mut iterator = PlayIterator::new(play, &hosts);
        let inv = local_inventory(&["h1"]);
        let vm = Arc::new(VariableManager::new(inv));
        let mut stats = AggregateStats::new();

        let result = LinearStrategy
            .run(&mut iterator, vm, &mut stats, 5, false)
            .await
            .unwrap();

        assert_eq!(result.results.len(), 1, "got {:?}", result.results);
        let r = &result.results[0];
        assert!(r.skipped, "meta task with when:false must be skipped");
        assert_eq!(
            r.task_fields.get("name").and_then(|v| v.as_str()),
            Some("conditionally end the play"),
        );
        assert_eq!(
            r.task_fields.get("action").and_then(|v| v.as_str()),
            Some("meta"),
            "callback payload must include action:meta so plugins can \
             distinguish skipped meta events",
        );
    }
}
