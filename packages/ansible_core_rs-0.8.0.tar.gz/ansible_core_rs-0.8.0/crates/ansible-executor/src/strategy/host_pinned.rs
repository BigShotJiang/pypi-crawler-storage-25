//! The "host_pinned" strategy: like free, each host runs through all
//! tasks independently, but a single fork slot is held for the entire
//! duration of that host's execution. This means a host that finishes
//! its tasks frees its slot for another host, but within its slot only
//! one task runs at a time — no interleaving with other hosts' tasks
//! on the same worker.
//!
//! In practice this behaves very similarly to `free`, but the
//! semaphore permit is acquired once per host rather than once per
//! task, which pins the host to its worker for the whole play.

use std::collections::{HashMap, HashSet};
use std::sync::Arc;

use ansible_playbook::Task;
use ansible_utils::AggregateStats;
use ansible_vars::VariableManager;
use async_trait::async_trait;
use tokio::sync::{Mutex, Semaphore};
use tracing::{debug, warn};

use crate::play_iterator::{HostState, NextTask, PlayIterator, PlayPhase, RunState};
use crate::strategy::{StrategyPlugin, StrategyResult};
use crate::task_executor::TaskExecutor;
use crate::ExecutorError;

/// The "host_pinned" strategy: each host is pinned to a single fork
/// slot for the entire play. Hosts run independently; the semaphore
/// limits how many hosts can execute concurrently.
pub struct HostPinnedStrategy;

#[async_trait]
impl StrategyPlugin for HostPinnedStrategy {
    async fn run(
        &self,
        iterator: &mut PlayIterator,
        variable_manager: Arc<VariableManager>,
        stats: &mut AggregateStats,
        forks: usize,
        check_mode: bool,
    ) -> Result<StrategyResult, ExecutorError> {
        let semaphore = Arc::new(Semaphore::new(forks));
        let all_results = Arc::new(Mutex::new(Vec::new()));
        let all_ok = Arc::new(Mutex::new(true));
        let notified_per_host: Arc<Mutex<HashMap<String, HashSet<Arc<str>>>>> =
            Arc::new(Mutex::new(HashMap::new()));

        let active_hosts = iterator.get_active_hosts();
        if active_hosts.is_empty() {
            return Ok(StrategyResult {
                results: Vec::new(),
                all_ok: true,
            });
        }

        let play_vars = iterator.play.vars.clone();

        // Handle fact gathering if needed
        let first_host = &active_hosts[0];
        let needs_setup = matches!(
            iterator.get_next_task_for_host(first_host),
            NextTask::Setup { .. }
        );

        if needs_setup {
            debug!("TASK [Gathering Facts] (host_pinned strategy)");
            let setup_task = ansible_playbook::Task::minimal_action(
                "Gathering Facts",
                "setup",
                serde_json::json!({}),
            );
            let mut handles = Vec::new();
            for host in &active_hosts {
                let sem = semaphore.clone();
                let host = host.clone();
                let task = setup_task.clone();
                let vm = variable_manager.clone();
                handles.push(tokio::spawn(async move {
                    let _permit = sem.acquire().await.unwrap();
                    let executor = TaskExecutor::new(host.clone(), task, vm)
                        .with_check_mode(check_mode);
                    (host, executor.run().await)
                }));
            }
            for handle in handles {
                let (host, result) = handle.await.map_err(|e| {
                    ExecutorError::TaskFailed(format!("setup panicked: {e}"))
                })?;
                if let Ok(res) = result {
                    if let Some(facts) = res
                        .results
                        .get("ansible_facts")
                        .and_then(|v| v.as_object())
                    {
                        for (k, v) in facts {
                            variable_manager.set_host_fact(&host, k.clone(), v.clone());
                        }
                    }
                }
                let mut next = iterator
                    .get_host_state(&host)
                    .cloned()
                    .unwrap_or_default();
                next.phase = PlayPhase::PreTasks;
                next.pending_setup = false;
                iterator.set_host_state(&host, next);
            }
        }

        // Collect all tasks per host, then spawn one worker per host.
        // The key difference from `free` is: the semaphore permit is
        // held for the entire host execution, not per-task.
        let mut handles = Vec::new();

        for host in &active_hosts {
            let host = host.clone();
            let vm = variable_manager.clone();
            let results = all_results.clone();
            let ok_flag = all_ok.clone();
            let notified = notified_per_host.clone();

            let mut host_tasks: Vec<(Task, HostState, Option<HashMap<String, serde_json::Value>>)> =
                Vec::new();
            loop {
                match iterator.get_next_task_for_host(&host) {
                    NextTask::Task {
                        task,
                        host_state,
                        block_vars,
                    } => {
                        host_tasks.push((task.clone(), host_state.clone(), block_vars));
                        iterator.set_host_state(&host, host_state);
                    }
                    NextTask::Setup { .. } => break,
                    NextTask::Complete => break,
                }
            }

            iterator.set_host_state(
                &host,
                HostState {
                    phase: PlayPhase::Complete,
                    ..HostState::default()
                },
            );

            let sem = semaphore.clone();
            let pv = play_vars.clone();
            handles.push(tokio::spawn(async move {
                // Acquire the permit ONCE for the entire host's run.
                let _permit = sem.acquire().await.unwrap();

                for (task, _state, bv) in host_tasks {
                    let task_name = task.name.as_deref().unwrap_or("unnamed").to_string();
                    let task_action = task.action.keys().next().cloned();
                    debug!("[{}] TASK [{}]", host, task_name);

                    let register_var = task.register.clone();
                    let notify_list = task.notify.clone();
                    let ignore_errors = task.ignore_errors;

                    let executor = TaskExecutor::with_context(
                        host.clone(),
                        task,
                        vm.clone(),
                        pv.clone(),
                        bv,
                        None,
                    )
                    .with_check_mode(check_mode);
                    match executor.run().await {
                        Ok(result) => {
                            if let Some(ref var_name) = register_var {
                                let reg_value = serde_json::json!({
                                    "changed": result.changed,
                                    "failed": result.failed,
                                    "skipped": result.skipped,
                                    "msg": result.msg.as_deref().unwrap_or(""),
                                    "stdout": result.results.get("stdout").and_then(|v| v.as_str()).unwrap_or(""),
                                    "stderr": result.results.get("stderr").and_then(|v| v.as_str()).unwrap_or(""),
                                    "results": result.results,
                                });
                                vm.set_host_fact(&host, var_name.clone(), reg_value);
                            }

                            if let Some(facts) = result
                                .results
                                .get("ansible_facts")
                                .and_then(|v| v.as_object())
                            {
                                for (k, v) in facts {
                                    vm.set_host_fact(&host, k.clone(), v.clone());
                                }
                            }

                            // Queue notified handlers when the task changed
                            if result.changed {
                                let mut np = notified.lock().await;
                                for handler_name in &notify_list {
                                    np.entry(handler_name.clone())
                                        .or_default()
                                        .insert(host.clone());
                                }
                            }

                            // Attach task name for TASK banner emission, and
                            // the action (module name) so callbacks can
                            // identify what was run/skipped (notably meta).
                            let mut result = result;
                            result.task_fields.insert(
                                "name".to_string(),
                                serde_json::Value::String(task_name.clone()),
                            );
                            if let Some(ref action) = task_action {
                                result.task_fields.insert(
                                    "action".to_string(),
                                    serde_json::Value::String(action.clone()),
                                );
                            }

                            if result.failed && !ignore_errors {
                                *ok_flag.lock().await = false;
                                results.lock().await.push(result);
                                break;
                            }

                            results.lock().await.push(result);
                        }
                        Err(e) => {
                            warn!("[{}] Task error: {}", host, e);
                            *ok_flag.lock().await = false;
                            break;
                        }
                    }
                }
            }));
        }

        for handle in handles {
            handle
                .await
                .map_err(|e| ExecutorError::TaskFailed(format!("host panicked: {e}")))?;
        }

        // Flush handlers: walk play.handlers in definition order; for each
        // notified one, run on the hosts that notified it (and that are
        // still healthy — or any non-unreachable host if `force_handlers`
        // is set).
        let mut all_ok = *all_ok.lock().await;
        let notified = notified_per_host.lock().await.clone();
        let force_handlers = iterator.play.force_handlers;
        let handlers = iterator.play.handlers.clone();

        for handler in &handlers {
            let handler_name = match handler.name.as_deref() {
                Some(n) => n,
                None => continue,
            };
            let notifying = match notified.get(handler_name) {
                Some(s) => s.clone(),
                None => continue,
            };
            let target_hosts: Vec<Arc<str>> = notifying
                .into_iter()
                .filter(|h| {
                    iterator
                        .get_host_state(h)
                        .map(|s| match s.run_state {
                            RunState::Running => true,
                            RunState::Failed => force_handlers,
                            RunState::Unreachable => false,
                        })
                        .unwrap_or(false)
                })
                .collect();
            if target_hosts.is_empty() {
                continue;
            }

            debug!("RUNNING HANDLER [{}]", handler_name);
            let mut handler_handles = Vec::new();
            for host in &target_hosts {
                let sem = semaphore.clone();
                let host = host.clone();
                let task = handler.clone();
                let vm = variable_manager.clone();
                handler_handles.push(tokio::spawn(async move {
                    let _permit = sem.acquire().await.unwrap();
                    let executor = TaskExecutor::new(host.clone(), task, vm)
                        .with_check_mode(check_mode);
                    (host, executor.run().await)
                }));
            }

            for handle in handler_handles {
                let (host, result) = handle
                    .await
                    .map_err(|e| ExecutorError::TaskFailed(format!("handler panicked: {e}")))?;
                match result {
                    Ok(result) => {
                        if result.unreachable {
                            stats.record_unreachable(&host);
                            iterator.mark_host_unreachable(&host);
                            all_ok = false;
                        } else if result.failed {
                            stats.record(&host, false, true, false);
                            iterator.mark_host_failed(&host);
                            all_ok = false;
                        } else if !result.skipped {
                            stats.record(&host, result.changed, false, false);
                        }
                        let mut result = result;
                        result.task_fields.insert(
                            "name".to_string(),
                            serde_json::Value::String(handler_name.to_string()),
                        );
                        if let Some(action) = handler.action.keys().next() {
                            result.task_fields.insert(
                                "action".to_string(),
                                serde_json::Value::String(action.clone()),
                            );
                        }
                        all_results.lock().await.push(result);
                    }
                    Err(e) => {
                        warn!("Handler error on {}: {}", host, e);
                        stats.record(&host, false, true, false);
                        all_ok = false;
                    }
                }
            }
        }

        let results = Arc::try_unwrap(all_results)
            .unwrap_or_else(|a| Mutex::new(a.try_lock().unwrap().clone()))
            .into_inner();

        Ok(StrategyResult {
            results,
            all_ok,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use ansible_inventory::InventoryManager;
    use crate::play_iterator::PlayIterator;

    fn make_task(name: &str) -> ansible_playbook::Task {
        ansible_playbook::Task {
            name: Some(name.to_string()),
            action: {
                let mut m = HashMap::new();
                m.insert(
                    "debug".into(),
                    serde_json::json!({"msg": "hello"}),
                );
                m
            },
            when_conditions: Vec::new(),
            register: None,
            loop_source: None,
            loop_items: None,
            with_items: None,
            loop_control: None,
            notify: Vec::new(),
            tags: Default::default(),
            use_become: None,
            become_user: None,
            become_method: None,
            become_flags: None,
            become_pass: None,
            delegate_to: None,
            ignore_errors: false,
            run_once: false,
            changed_when: Vec::new(),
            failed_when: Vec::new(),
            retries: 3,
            delay: 5,
            until: Vec::new(),
            no_log: false,
            args: None,
            environment: None,
            vars: None,
            block: None,
            rescue: None,
            always: None,
            connection: None,
            timeout: None,
            check_mode: None,
        }
    }

    fn make_play(tasks: Vec<ansible_playbook::Task>) -> ansible_playbook::Play {
        ansible_playbook::Play {
            name: Some("test".into()),
            hosts: Some("all".into()),
            tasks,
            pre_tasks: Vec::new(),
            post_tasks: Vec::new(),
            handlers: Vec::new(),
            roles: Vec::new(),
            vars: HashMap::new(),
            vars_files: Vec::new(),
            environment: HashMap::new(),
            gather_facts: Some(false),
            strategy: "host_pinned".into(),
            serial: Vec::new(),
            max_fail_percentage: None,
            force_handlers: false,
            use_become: None,
            become_user: None,
            become_method: None,
            connection: None,
            tags: Default::default(),
            when_conditions: Vec::new(),
            any_errors_fatal: None,
            ignore_errors: None,
            ignore_unreachable: None,
            module_defaults: None,
            collections: None,
        }
    }

    fn make_fail_task(name: &str) -> ansible_playbook::Task {
        let mut t = make_task(name);
        t.action.clear();
        t.action.insert(
            "fail".into(),
            serde_json::json!({"msg": format!("forced-failure:{name}")}),
        );
        t
    }

    #[tokio::test]
    async fn test_host_pinned_basic_execution() {
        let play = make_play(vec![make_task("t1"), make_task("t2")]);
        let hosts = vec!["h1".to_string(), "h2".to_string()];
        let mut iterator = PlayIterator::new(play, &hosts);
        let inv = Arc::new(InventoryManager::new());
        let vm = Arc::new(VariableManager::new(inv));
        let mut stats = AggregateStats::new();

        let result = HostPinnedStrategy
            .run(&mut iterator, vm, &mut stats, 5, false)
            .await
            .unwrap();

        // 2 tasks × 2 hosts = 4 results
        assert_eq!(result.results.len(), 4);
        assert!(result.all_ok);
    }

    #[tokio::test]
    async fn test_host_pinned_failure_stops_host_not_others() {
        // h1 fails on its first task; h2 should still complete both tasks.
        let mut fail_on_h1 = make_fail_task("boom");
        fail_on_h1.when_conditions = vec!["inventory_hostname == 'h1'".into()];
        let t2 = make_task("after");

        let play = make_play(vec![fail_on_h1, t2]);
        let hosts = vec!["h1".to_string(), "h2".to_string()];
        let mut iterator = PlayIterator::new(play, &hosts);
        let inv = Arc::new(InventoryManager::new());
        let vm = Arc::new(VariableManager::new(inv));
        let mut stats = AggregateStats::new();

        let result = HostPinnedStrategy
            .run(&mut iterator, vm, &mut stats, 5, false)
            .await
            .unwrap();

        // h1: fail (1 result, then stops)
        // h2: skip(when false) + after = 2 results
        // Total = 3
        assert_eq!(result.results.len(), 3, "got {:?}", result.results);
        assert!(!result.all_ok);
    }
}
