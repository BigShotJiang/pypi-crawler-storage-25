//! Order-preserving collection utilities.
//!
//! Mirrors `lib/ansible/module_utils/common/collections.py` upstream. The
//! `OrderedSet` here matches the insertion-order semantics of Python's
//! implementation so collections built against upstream behave identically.

use std::borrow::Borrow;
use std::collections::HashSet;
use std::hash::Hash;

/// An order-preserving set: iteration yields elements in the order they were
/// first inserted, and re-inserting an existing element is a no-op.
///
/// Equivalent to upstream's `module_utils.common.collections.OrderedSet`.
#[derive(Debug, Clone)]
pub struct OrderedSet<T>
where
    T: Eq + Hash + Clone,
{
    order: Vec<T>,
    seen: HashSet<T>,
}

impl<T> OrderedSet<T>
where
    T: Eq + Hash + Clone,
{
    /// Create an empty `OrderedSet`.
    pub fn new() -> Self {
        Self {
            order: Vec::new(),
            seen: HashSet::new(),
        }
    }

    /// Create an `OrderedSet` with the given capacity.
    pub fn with_capacity(cap: usize) -> Self {
        Self {
            order: Vec::with_capacity(cap),
            seen: HashSet::with_capacity(cap),
        }
    }

    /// Insert `value`. Returns `true` if it was newly inserted, `false` if it
    /// was already present (in which case insertion order is preserved).
    pub fn insert(&mut self, value: T) -> bool {
        if self.seen.insert(value.clone()) {
            self.order.push(value);
            true
        } else {
            false
        }
    }

    /// Remove `value` from the set. Returns `true` if it was present.
    pub fn remove<Q>(&mut self, value: &Q) -> bool
    where
        T: Borrow<Q>,
        Q: ?Sized + Hash + Eq,
    {
        if self.seen.remove(value) {
            if let Some(pos) = self.order.iter().position(|x| x.borrow() == value) {
                self.order.remove(pos);
            }
            true
        } else {
            false
        }
    }

    /// Test whether `value` is in the set.
    pub fn contains<Q>(&self, value: &Q) -> bool
    where
        T: Borrow<Q>,
        Q: ?Sized + Hash + Eq,
    {
        self.seen.contains(value)
    }

    /// Number of elements.
    pub fn len(&self) -> usize {
        self.order.len()
    }

    /// `true` if the set has no elements.
    pub fn is_empty(&self) -> bool {
        self.order.is_empty()
    }

    /// Remove all elements.
    pub fn clear(&mut self) {
        self.order.clear();
        self.seen.clear();
    }

    /// Iterate in insertion order.
    pub fn iter(&self) -> std::slice::Iter<'_, T> {
        self.order.iter()
    }

    /// Union: `self` followed by elements of `other` not already present.
    pub fn union(&self, other: &OrderedSet<T>) -> OrderedSet<T> {
        let mut out = self.clone();
        for v in other.iter() {
            out.insert(v.clone());
        }
        out
    }

    /// Intersection: elements of `self` that are also in `other`, in the
    /// order they appear in `self`.
    pub fn intersection(&self, other: &OrderedSet<T>) -> OrderedSet<T> {
        let mut out = OrderedSet::new();
        for v in self.iter() {
            if other.contains(v) {
                out.insert(v.clone());
            }
        }
        out
    }

    /// Difference: elements of `self` not in `other`, in `self`'s order.
    pub fn difference(&self, other: &OrderedSet<T>) -> OrderedSet<T> {
        let mut out = OrderedSet::new();
        for v in self.iter() {
            if !other.contains(v) {
                out.insert(v.clone());
            }
        }
        out
    }

    /// Symmetric difference: elements in either set but not both. `self`'s
    /// unique elements come first (in `self`'s order), then `other`'s.
    pub fn symmetric_difference(&self, other: &OrderedSet<T>) -> OrderedSet<T> {
        let mut out = OrderedSet::new();
        for v in self.iter() {
            if !other.contains(v) {
                out.insert(v.clone());
            }
        }
        for v in other.iter() {
            if !self.contains(v) {
                out.insert(v.clone());
            }
        }
        out
    }
}

impl<T> Default for OrderedSet<T>
where
    T: Eq + Hash + Clone,
{
    fn default() -> Self {
        Self::new()
    }
}

impl<T> PartialEq for OrderedSet<T>
where
    T: Eq + Hash + Clone,
{
    /// Two `OrderedSet`s are equal when they contain the same elements,
    /// regardless of insertion order — matching Python set equality.
    fn eq(&self, other: &Self) -> bool {
        self.seen == other.seen
    }
}

impl<T> Eq for OrderedSet<T> where T: Eq + Hash + Clone {}

impl<T> FromIterator<T> for OrderedSet<T>
where
    T: Eq + Hash + Clone,
{
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Self {
        let mut s = OrderedSet::new();
        for v in iter {
            s.insert(v);
        }
        s
    }
}

impl<T> Extend<T> for OrderedSet<T>
where
    T: Eq + Hash + Clone,
{
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        for v in iter {
            self.insert(v);
        }
    }
}

impl<'a, T> IntoIterator for &'a OrderedSet<T>
where
    T: Eq + Hash + Clone,
{
    type Item = &'a T;
    type IntoIter = std::slice::Iter<'a, T>;

    fn into_iter(self) -> Self::IntoIter {
        self.iter()
    }
}

impl<T> IntoIterator for OrderedSet<T>
where
    T: Eq + Hash + Clone,
{
    type Item = T;
    type IntoIter = std::vec::IntoIter<T>;

    fn into_iter(self) -> Self::IntoIter {
        self.order.into_iter()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn insert_preserves_first_occurrence_order() {
        let mut s = OrderedSet::new();
        assert!(s.insert("a"));
        assert!(s.insert("b"));
        assert!(s.insert("c"));
        assert!(!s.insert("a"));
        assert!(!s.insert("b"));

        let order: Vec<_> = s.iter().copied().collect();
        assert_eq!(order, vec!["a", "b", "c"]);
        assert_eq!(s.len(), 3);
    }

    #[test]
    fn remove_keeps_remaining_order() {
        let mut s: OrderedSet<i32> = [1, 2, 3, 4].into_iter().collect();
        assert!(s.remove(&2));
        assert!(!s.remove(&99));
        let order: Vec<_> = s.iter().copied().collect();
        assert_eq!(order, vec![1, 3, 4]);
    }

    #[test]
    fn contains_and_len() {
        let s: OrderedSet<&str> = ["x", "y"].into_iter().collect();
        assert!(s.contains("x"));
        assert!(!s.contains("z"));
        assert_eq!(s.len(), 2);
        assert!(!s.is_empty());
    }

    #[test]
    fn union_keeps_self_order_then_new_from_other() {
        let a: OrderedSet<&str> = ["a", "b", "c"].into_iter().collect();
        let b: OrderedSet<&str> = ["c", "d", "e"].into_iter().collect();
        let order: Vec<_> = a.union(&b).into_iter().collect();
        assert_eq!(order, vec!["a", "b", "c", "d", "e"]);
    }

    #[test]
    fn intersection_uses_self_order() {
        let a: OrderedSet<&str> = ["a", "b", "c", "d"].into_iter().collect();
        let b: OrderedSet<&str> = ["d", "b"].into_iter().collect();
        let order: Vec<_> = a.intersection(&b).into_iter().collect();
        assert_eq!(order, vec!["b", "d"]);
    }

    #[test]
    fn difference_excludes_other_elements() {
        let a: OrderedSet<&str> = ["a", "b", "c"].into_iter().collect();
        let b: OrderedSet<&str> = ["b"].into_iter().collect();
        let order: Vec<_> = a.difference(&b).into_iter().collect();
        assert_eq!(order, vec!["a", "c"]);
    }

    #[test]
    fn symmetric_difference_self_first_then_other() {
        let a: OrderedSet<&str> = ["a", "b", "c"].into_iter().collect();
        let b: OrderedSet<&str> = ["c", "d"].into_iter().collect();
        let order: Vec<_> = a.symmetric_difference(&b).into_iter().collect();
        assert_eq!(order, vec!["a", "b", "d"]);
    }

    #[test]
    fn equality_is_set_equality_not_order() {
        let a: OrderedSet<&str> = ["a", "b", "c"].into_iter().collect();
        let b: OrderedSet<&str> = ["c", "a", "b"].into_iter().collect();
        assert_eq!(a, b);
    }

    #[test]
    fn extend_skips_duplicates_and_keeps_order() {
        let mut s: OrderedSet<i32> = [1, 2].into_iter().collect();
        s.extend([2, 3, 1, 4]);
        let order: Vec<_> = s.iter().copied().collect();
        assert_eq!(order, vec![1, 2, 3, 4]);
    }
}
