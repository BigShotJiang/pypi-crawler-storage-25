pub mod collections;
pub mod error;
pub mod inventory;
pub mod result;
pub mod types;

pub use collections::OrderedSet;
pub use error::AnsibleError;
pub use inventory::{Group, Host, InventoryData};
pub use result::TaskResult;
pub use types::*;

/// The core value type used throughout Ansible.
/// Maps to Python's dict/list/scalar dynamic typing.
pub type AnsibleValue = serde_json::Value;
