//! Callback registry — fans event notifications out to a set of callback plugins.
//!
//! The executor speaks to a single [`CallbackRegistry`]; the registry forwards
//! each event to every registered [`CallbackPlugin`] in turn. A run typically
//! contains exactly one stdout callback (resolved from `[defaults]
//! stdout_callback`) plus zero or more notification-style callbacks.

use ansible_utils::AnsibleValue;

use crate::callback::default::DefaultCallback;
use crate::callback::json::JsonCallback;
use crate::traits::CallbackPlugin;

/// A collection of callback plugins that receive playbook events.
///
/// Forwards every event to all registered callbacks in registration order.
pub struct CallbackRegistry {
    callbacks: Vec<Box<dyn CallbackPlugin>>,
}

impl CallbackRegistry {
    /// Create an empty registry.
    pub fn new() -> Self {
        Self {
            callbacks: Vec::new(),
        }
    }

    /// Register a callback plugin. Events are dispatched in registration order.
    pub fn register(&mut self, plugin: Box<dyn CallbackPlugin>) {
        self.callbacks.push(plugin);
    }

    /// Number of registered callbacks.
    pub fn len(&self) -> usize {
        self.callbacks.len()
    }

    /// True if no callbacks are registered.
    pub fn is_empty(&self) -> bool {
        self.callbacks.is_empty()
    }

    /// Build a registry from a `stdout_callback` name and an optional list
    /// of additional notification callbacks (`callbacks_enabled`).
    ///
    /// Unknown names fall back to the `default` callback so that mis-typed
    /// config never leaves a run with no output.
    pub fn from_config(stdout_callback: &str, callbacks_enabled: &[String]) -> Self {
        let mut registry = Self::new();
        registry.register(resolve_stdout_callback(stdout_callback));
        for name in callbacks_enabled {
            if let Some(plugin) = resolve_notification_callback(name) {
                registry.register(plugin);
            }
        }
        registry
    }
}

impl Default for CallbackRegistry {
    fn default() -> Self {
        Self::new()
    }
}

impl CallbackPlugin for CallbackRegistry {
    fn v2_playbook_on_start(&self, playbook_file: &str) {
        for cb in &self.callbacks {
            cb.v2_playbook_on_start(playbook_file);
        }
    }

    fn v2_playbook_on_play_start(&self, play_name: &str) {
        for cb in &self.callbacks {
            cb.v2_playbook_on_play_start(play_name);
        }
    }

    fn v2_playbook_on_task_start(&self, task_name: &str, is_conditional: bool) {
        for cb in &self.callbacks {
            cb.v2_playbook_on_task_start(task_name, is_conditional);
        }
    }

    fn v2_runner_on_ok(&self, host: &str, result: &AnsibleValue) {
        for cb in &self.callbacks {
            cb.v2_runner_on_ok(host, result);
        }
    }

    fn v2_runner_on_failed(&self, host: &str, result: &AnsibleValue, ignore_errors: bool) {
        for cb in &self.callbacks {
            cb.v2_runner_on_failed(host, result, ignore_errors);
        }
    }

    fn v2_runner_on_skipped(&self, host: &str, result: &AnsibleValue) {
        for cb in &self.callbacks {
            cb.v2_runner_on_skipped(host, result);
        }
    }

    fn v2_runner_on_unreachable(&self, host: &str, result: &AnsibleValue) {
        for cb in &self.callbacks {
            cb.v2_runner_on_unreachable(host, result);
        }
    }

    fn v2_playbook_on_stats(&self, stats: &AnsibleValue) {
        for cb in &self.callbacks {
            cb.v2_playbook_on_stats(stats);
        }
    }

    fn v2_on_any(&self, event: &str, data: &AnsibleValue) {
        for cb in &self.callbacks {
            cb.v2_on_any(event, data);
        }
    }
}

/// Resolve a `stdout_callback` config value to a callback plugin.
///
/// `default` and `json` are built-ins. Anything else falls back to `default`.
fn resolve_stdout_callback(name: &str) -> Box<dyn CallbackPlugin> {
    match name {
        "json" => Box::new(JsonCallback::new()),
        // `default` and any unknown name use the default human-readable output.
        _ => Box::new(DefaultCallback::new()),
    }
}

/// Resolve a notification-style callback by name. Returns `None` for unknown
/// names rather than substituting a fallback — extra notification callbacks
/// are optional and a typo shouldn't double-emit the stdout output.
fn resolve_notification_callback(_name: &str) -> Option<Box<dyn CallbackPlugin>> {
    // No built-in notification callbacks ship today; user-installed callbacks
    // (loaded via the plugin loader) would be resolved here in the future.
    None
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::Mutex;

    /// A test callback that records every event it sees.
    struct RecordingCallback {
        events: Mutex<Vec<String>>,
    }

    impl RecordingCallback {
        fn new() -> Self {
            Self {
                events: Mutex::new(Vec::new()),
            }
        }

        fn events(&self) -> Vec<String> {
            self.events.lock().unwrap().clone()
        }
    }

    impl CallbackPlugin for RecordingCallback {
        fn v2_playbook_on_play_start(&self, play_name: &str) {
            self.events
                .lock()
                .unwrap()
                .push(format!("play_start:{play_name}"));
        }

        fn v2_runner_on_ok(&self, host: &str, _result: &AnsibleValue) {
            self.events
                .lock()
                .unwrap()
                .push(format!("ok:{host}"));
        }
    }

    #[test]
    fn registry_fans_events_to_all_plugins() {
        // Dispatching to two recording callbacks should leave each with the
        // same event log — the registry forwards every event in order.
        let mut registry = CallbackRegistry::new();
        // Use a wrapper that lets us inspect after-the-fact.
        struct Wrapped(std::sync::Arc<RecordingCallback>);
        impl CallbackPlugin for Wrapped {
            fn v2_playbook_on_play_start(&self, play_name: &str) {
                self.0.v2_playbook_on_play_start(play_name);
            }
            fn v2_runner_on_ok(&self, host: &str, result: &AnsibleValue) {
                self.0.v2_runner_on_ok(host, result);
            }
        }
        let a = std::sync::Arc::new(RecordingCallback::new());
        let b = std::sync::Arc::new(RecordingCallback::new());
        registry.register(Box::new(Wrapped(a.clone())));
        registry.register(Box::new(Wrapped(b.clone())));

        registry.v2_playbook_on_play_start("play1");
        registry.v2_runner_on_ok("host1", &serde_json::json!({}));

        assert_eq!(a.events(), vec!["play_start:play1", "ok:host1"]);
        assert_eq!(b.events(), vec!["play_start:play1", "ok:host1"]);
    }

    #[test]
    fn from_config_default_when_unknown() {
        // An unknown `stdout_callback` string should still produce a usable
        // registry (falling back to `default`) instead of erroring.
        let registry = CallbackRegistry::from_config("does-not-exist", &[]);
        assert_eq!(registry.len(), 1);
    }

    #[test]
    fn from_config_json_resolves_to_json_callback() {
        let registry = CallbackRegistry::from_config("json", &[]);
        assert_eq!(registry.len(), 1);
    }
}
