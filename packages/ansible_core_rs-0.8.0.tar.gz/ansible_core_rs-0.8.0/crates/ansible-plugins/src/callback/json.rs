//! JSON stdout callback — emits a single aggregate JSON document at end-of-run.
//!
//! Output schema mirrors upstream `ansible.posix.json` so existing tooling
//! that parses ansible's JSON callback output works unchanged. The schema is
//! roughly:
//!
//! ```json
//! {
//!   "stats": { "<host>": { "ok": N, "changed": N, "failures": N, ... } },
//!   "plays": [
//!     {
//!       "play": { "name": "..." },
//!       "tasks": [
//!         { "task": { "name": "..." }, "hosts": { "<host>": { ... } } }
//!       ]
//!     }
//!   ]
//! }
//! ```
//!
//! The document is buffered internally and printed once on
//! `v2_playbook_on_stats`, which the executor calls at the end of each
//! playbook.

use std::sync::Mutex;

use ansible_utils::{AggregateStats, AnsibleValue};
use serde_json::{json, Map, Value};

use crate::traits::CallbackPlugin;

/// Internal mutable state — kept in a `Mutex` because the trait methods take
/// `&self`.
#[derive(Default)]
struct JsonState {
    plays: Vec<PlayEntry>,
}

#[derive(Default)]
struct PlayEntry {
    name: String,
    tasks: Vec<TaskEntry>,
}

#[derive(Default)]
struct TaskEntry {
    name: String,
    /// host → result object
    hosts: Map<String, Value>,
}

/// JSON stdout callback plugin.
pub struct JsonCallback {
    state: Mutex<JsonState>,
}

impl JsonCallback {
    pub fn new() -> Self {
        Self {
            state: Mutex::new(JsonState::default()),
        }
    }

    fn current_play_mut(state: &mut JsonState) -> Option<&mut PlayEntry> {
        state.plays.last_mut()
    }

    fn current_task_mut(state: &mut JsonState) -> Option<&mut TaskEntry> {
        state.plays.last_mut().and_then(|p| p.tasks.last_mut())
    }

    fn record_host_result(&self, host: &str, result: &AnsibleValue) {
        let mut state = self.state.lock().unwrap();
        // If we somehow get a result without a preceding task_start (e.g. an
        // ad-hoc command), synthesize an unnamed task so the result still
        // shows up in the JSON document.
        if state.plays.is_empty() {
            state.plays.push(PlayEntry::default());
        }
        if Self::current_play_mut(&mut state)
            .map(|p| p.tasks.is_empty())
            .unwrap_or(true)
        {
            if let Some(p) = Self::current_play_mut(&mut state) {
                p.tasks.push(TaskEntry::default());
            }
        }
        if let Some(task) = Self::current_task_mut(&mut state) {
            task.hosts.insert(host.to_string(), result.clone());
        }
    }
}

impl Default for JsonCallback {
    fn default() -> Self {
        Self::new()
    }
}

impl CallbackPlugin for JsonCallback {
    fn v2_playbook_on_play_start(&self, play_name: &str) {
        let mut state = self.state.lock().unwrap();
        state.plays.push(PlayEntry {
            name: play_name.to_string(),
            tasks: Vec::new(),
        });
    }

    fn v2_playbook_on_task_start(&self, task_name: &str, _is_conditional: bool) {
        let mut state = self.state.lock().unwrap();
        if state.plays.is_empty() {
            // An ad-hoc invocation never emits play_start; synthesize a play.
            state.plays.push(PlayEntry::default());
        }
        if let Some(play) = Self::current_play_mut(&mut state) {
            play.tasks.push(TaskEntry {
                name: task_name.to_string(),
                hosts: Map::new(),
            });
        }
    }

    fn v2_runner_on_ok(&self, host: &str, result: &AnsibleValue) {
        self.record_host_result(host, result);
    }

    fn v2_runner_on_failed(&self, host: &str, result: &AnsibleValue, _ignore_errors: bool) {
        self.record_host_result(host, result);
    }

    fn v2_runner_on_skipped(&self, host: &str, result: &AnsibleValue) {
        self.record_host_result(host, result);
    }

    fn v2_runner_on_unreachable(&self, host: &str, result: &AnsibleValue) {
        self.record_host_result(host, result);
    }

    fn v2_playbook_on_stats(&self, stats: &AnsibleValue) {
        let state = self.state.lock().unwrap();

        let stats_json = build_stats_json(stats);
        let plays_json: Vec<Value> = state
            .plays
            .iter()
            .map(|p| {
                let tasks: Vec<Value> = p
                    .tasks
                    .iter()
                    .map(|t| {
                        json!({
                            "task": { "name": t.name },
                            "hosts": Value::Object(t.hosts.clone()),
                        })
                    })
                    .collect();
                json!({
                    "play": { "name": p.name },
                    "tasks": tasks,
                })
            })
            .collect();

        let document = json!({
            "stats": stats_json,
            "plays": plays_json,
        });

        // Pretty-printed for readability, matching upstream which also
        // pretty-prints by default.
        match serde_json::to_string_pretty(&document) {
            Ok(s) => println!("{s}"),
            Err(e) => eprintln!("json callback: serialize failed: {e}"),
        }
    }
}

/// Convert an `AggregateStats`-shaped value into the per-host map that
/// upstream's json callback emits under `stats`.
fn build_stats_json(stats: &AnsibleValue) -> Value {
    let Ok(agg) = serde_json::from_value::<AggregateStats>(stats.clone()) else {
        return Value::Object(Map::new());
    };
    let mut out = Map::new();
    for host in agg.all_hosts() {
        let entry = json!({
            "ok": agg.ok.get(&host).copied().unwrap_or(0),
            "changed": agg.changed.get(&host).copied().unwrap_or(0),
            "unreachable": agg.dark.get(&host).copied().unwrap_or(0),
            "failures": agg.failures.get(&host).copied().unwrap_or(0),
            "skipped": agg.skipped.get(&host).copied().unwrap_or(0),
            "rescued": agg.rescued.get(&host).copied().unwrap_or(0),
            "ignored": agg.ignored.get(&host).copied().unwrap_or(0),
        });
        out.insert(host, entry);
    }
    Value::Object(out)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn task_results_grouped_by_play_and_task() {
        let cb = JsonCallback::new();
        cb.v2_playbook_on_play_start("Configure web tier");
        cb.v2_playbook_on_task_start("Install nginx", false);
        cb.v2_runner_on_ok("web1", &json!({"changed": false}));
        cb.v2_runner_on_ok("web2", &json!({"changed": true}));
        cb.v2_playbook_on_task_start("Start nginx", false);
        cb.v2_runner_on_ok("web1", &json!({"changed": true}));

        let state = cb.state.lock().unwrap();
        assert_eq!(state.plays.len(), 1);
        assert_eq!(state.plays[0].name, "Configure web tier");
        assert_eq!(state.plays[0].tasks.len(), 2);
        assert_eq!(state.plays[0].tasks[0].hosts.len(), 2);
        assert_eq!(state.plays[0].tasks[1].hosts.len(), 1);
    }

    #[test]
    fn build_stats_json_emits_per_host_counters() {
        let stats = json!({
            "processed": {"web1": 1},
            "ok": {"web1": 3},
            "changed": {"web1": 1},
            "failures": {"web1": 0},
            "dark": {"web1": 0},
            "skipped": {"web1": 1},
            "rescued": {"web1": 0},
            "ignored": {"web1": 0},
        });
        let v = build_stats_json(&stats);
        let obj = v.as_object().unwrap();
        let host = obj.get("web1").unwrap().as_object().unwrap();
        assert_eq!(host.get("ok").unwrap().as_i64(), Some(3));
        assert_eq!(host.get("changed").unwrap().as_i64(), Some(1));
        assert_eq!(host.get("skipped").unwrap().as_i64(), Some(1));
    }

    #[test]
    fn host_result_without_task_start_synthesizes_entry() {
        // Ad-hoc-style invocation: result arrives before any task_start.
        // Should still end up in the document under a synthesized play+task.
        let cb = JsonCallback::new();
        cb.v2_runner_on_ok("web1", &json!({"changed": false}));

        let state = cb.state.lock().unwrap();
        assert_eq!(state.plays.len(), 1);
        assert_eq!(state.plays[0].tasks.len(), 1);
        assert!(state.plays[0].tasks[0].hosts.contains_key("web1"));
    }
}
