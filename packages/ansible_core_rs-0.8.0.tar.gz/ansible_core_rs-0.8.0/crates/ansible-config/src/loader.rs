use std::collections::HashMap;
use std::env;
use std::path::{Path, PathBuf};

use crate::error::ConfigError;
use crate::types::AnsibleConfig;

/// Config keys in `[defaults]` that were removed upstream and must not be
/// accepted by the loader. Maps INI key → upstream issue tracking removal.
static DEPRECATED_DEFAULTS_KEYS: &[(&str, &str)] = &[
    // Removed in upstream PR #86791 — ansible/ansible v2.21 devel
    ("connection_path", "#53"),
    // Removed in upstream PR #86792 — ansible/ansible v2.21 devel
    ("libvirt_lxc_noseclabel", "#56"),
];

/// Environment variables (ANSIBLE_* overrides) that were removed upstream.
static DEPRECATED_ENV_VARS: &[(&str, &str)] = &[
    ("ANSIBLE_CONNECTION_PATH", "#53"),
    ("ANSIBLE_LIBVIRT_LXC_NOSECLABEL", "#56"),
];

/// Load Ansible configuration by searching standard locations.
///
/// Search order:
/// 1. `ANSIBLE_CONFIG` environment variable
/// 2. `./ansible.cfg` (current directory)
/// 3. `~/.ansible.cfg`
/// 4. `/etc/ansible/ansible.cfg`
pub fn load_config() -> Result<AnsibleConfig, ConfigError> {
    let config_path = find_config_file();

    let mut config = AnsibleConfig::default();
    config.config_file = config_path.clone();

    if let Some(path) = config_path {
        load_ini_config(&path, &mut config)?;
    }

    // Environment variables override file config.
    // Ansible uses ANSIBLE_<UPPERCASE_KEY> pattern.
    apply_env_overrides(&mut config);

    Ok(config)
}

/// Find the config file using Ansible's standard search order.
fn find_config_file() -> Option<PathBuf> {
    // 1. ANSIBLE_CONFIG env var
    if let Ok(path) = env::var("ANSIBLE_CONFIG") {
        let p = PathBuf::from(&path);
        if p.exists() {
            return Some(p);
        }
    }

    // 2. ./ansible.cfg
    let cwd = PathBuf::from("ansible.cfg");
    if cwd.exists() {
        return Some(cwd);
    }

    // 3. ~/.ansible.cfg
    if let Ok(home) = env::var("HOME") {
        let home_cfg = PathBuf::from(home).join(".ansible.cfg");
        if home_cfg.exists() {
            return Some(home_cfg);
        }
    }

    // 4. /etc/ansible/ansible.cfg
    let etc_cfg = PathBuf::from("/etc/ansible/ansible.cfg");
    if etc_cfg.exists() {
        return Some(etc_cfg);
    }

    None
}

/// Parse an INI-format ansible.cfg file.
fn load_ini_config(path: &Path, config: &mut AnsibleConfig) -> Result<(), ConfigError> {
    let content = std::fs::read_to_string(path)?;

    let mut current_section = String::new();
    let mut sections: HashMap<String, HashMap<String, String>> = HashMap::new();

    for line in content.lines() {
        let line = line.trim();

        // Skip empty lines and comments
        if line.is_empty() || line.starts_with('#') || line.starts_with(';') {
            continue;
        }

        // Section header
        if line.starts_with('[') && line.ends_with(']') {
            current_section = line[1..line.len() - 1].to_string();
            continue;
        }

        // Key = value
        if let Some((key, value)) = line.split_once('=') {
            let key = key.trim().to_string();
            let value = value.trim().to_string();
            sections
                .entry(current_section.clone())
                .or_default()
                .insert(key, value);
        }
    }

    // Warn about deprecated config keys that were removed upstream.
    if let Some(defaults) = sections.get("defaults") {
        for (key, issue) in DEPRECATED_DEFAULTS_KEYS {
            if defaults.contains_key(*key) {
                tracing::warn!(
                    "deprecated config key '{key}' in [defaults] was removed upstream (see {issue}); ignoring"
                );
            }
        }
    }

    // Apply parsed values to config struct
    if let Some(defaults) = sections.get("defaults") {
        if let Some(v) = defaults.get("inventory") {
            config.defaults.inventory = v.clone();
        }
        if let Some(v) = defaults.get("remote_user") {
            config.defaults.remote_user = v.clone();
        }
        if let Some(v) = defaults.get("forks") {
            if let Ok(n) = v.parse() {
                config.defaults.forks = n;
            }
        }
        if let Some(v) = defaults.get("host_key_checking") {
            config.defaults.host_key_checking = parse_bool(v);
        }
        if let Some(v) = defaults.get("timeout") {
            if let Ok(n) = v.parse() {
                config.defaults.timeout = n;
            }
        }
        if let Some(v) = defaults.get("stdout_callback") {
            config.defaults.stdout_callback = v.clone();
        }
        if let Some(v) = defaults.get("nocows") {
            config.defaults.nocows = parse_bool(v);
        }
        if let Some(v) = defaults.get("vault_password_file") {
            config.defaults.vault_password_file = Some(PathBuf::from(v));
        }
        if let Some(v) = defaults.get("roles_path") {
            config.defaults.roles_path = v.split(':').map(PathBuf::from).collect();
        }
        if let Some(v) = defaults.get("collections_paths") {
            config.defaults.collections_paths = v.split(':').map(PathBuf::from).collect();
        }
        if let Some(v) = defaults.get("pipelining") {
            config.defaults.pipelining = parse_bool(v);
        }
    }

    if let Some(priv_esc) = sections.get("privilege_escalation") {
        if let Some(v) = priv_esc.get("become") {
            config.privilege_escalation.use_become = parse_bool(v);
        }
        if let Some(v) = priv_esc.get("become_method") {
            config.privilege_escalation.become_method = v.clone();
        }
        if let Some(v) = priv_esc.get("become_user") {
            config.privilege_escalation.become_user = v.clone();
        }
        if let Some(v) = priv_esc.get("become_ask_pass") {
            config.privilege_escalation.become_ask_pass = parse_bool(v);
        }
    }

    if let Some(ssh) = sections.get("ssh_connection") {
        if let Some(v) = ssh.get("ssh_args") {
            config.ssh_connection.ssh_args = v.clone();
        }
        if let Some(v) = ssh.get("retries") {
            if let Ok(n) = v.parse() {
                config.ssh_connection.retries = n;
            }
        }
        if let Some(v) = ssh.get("scp_if_ssh") {
            config.ssh_connection.scp_if_ssh = parse_bool(v);
        }
        if let Some(v) = ssh.get("control_path") {
            config.ssh_connection.control_path = Some(v.clone());
        }
    }

    Ok(())
}

/// Apply ANSIBLE_* environment variable overrides.
fn apply_env_overrides(config: &mut AnsibleConfig) {
    // Warn about deprecated env vars that were removed upstream.
    for (var, issue) in DEPRECATED_ENV_VARS {
        if env::var(var).is_ok() {
            tracing::warn!(
                "deprecated env var '{var}' was removed upstream (see {issue}); ignoring"
            );
        }
    }


    if let Ok(v) = env::var("ANSIBLE_REMOTE_USER") {
        config.defaults.remote_user = v;
    }
    if let Ok(v) = env::var("ANSIBLE_FORKS") {
        if let Ok(n) = v.parse() {
            config.defaults.forks = n;
        }
    }
    if let Ok(v) = env::var("ANSIBLE_HOST_KEY_CHECKING") {
        config.defaults.host_key_checking = parse_bool(&v);
    }
    if let Ok(v) = env::var("ANSIBLE_TIMEOUT") {
        if let Ok(n) = v.parse() {
            config.defaults.timeout = n;
        }
    }
    if let Ok(v) = env::var("ANSIBLE_INVENTORY") {
        config.defaults.inventory = v;
    }
    if let Ok(v) = env::var("ANSIBLE_ROLES_PATH") {
        config.defaults.roles_path = v.split(':').map(PathBuf::from).collect();
    }
    if let Ok(v) = env::var("ANSIBLE_VAULT_PASSWORD_FILE") {
        config.defaults.vault_password_file = Some(PathBuf::from(v));
    }
    if let Ok(v) = env::var("ANSIBLE_STDOUT_CALLBACK") {
        config.defaults.stdout_callback = v;
    }
    if let Ok(v) = env::var("ANSIBLE_NOCOWS") {
        config.defaults.nocows = parse_bool(&v);
    }
    if let Ok(v) = env::var("ANSIBLE_PIPELINING") {
        config.defaults.pipelining = parse_bool(&v);
    }
    if let Ok(v) = env::var("ANSIBLE_BECOME") {
        config.privilege_escalation.use_become = parse_bool(&v);
    }
    if let Ok(v) = env::var("ANSIBLE_BECOME_METHOD") {
        config.privilege_escalation.become_method = v;
    }
    if let Ok(v) = env::var("ANSIBLE_BECOME_USER") {
        config.privilege_escalation.become_user = v;
    }
    if let Ok(v) = env::var("ANSIBLE_SSH_ARGS") {
        config.ssh_connection.ssh_args = v;
    }
    if let Ok(v) = env::var("ANSIBLE_SSH_RETRIES") {
        if let Ok(n) = v.parse() {
            config.ssh_connection.retries = n;
        }
    }
}

/// Parse a boolean value from an INI/env var string.
fn parse_bool(value: &str) -> bool {
    matches!(
        value.to_lowercase().as_str(),
        "true" | "yes" | "1" | "on"
    )
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;

    /// Write content to a temporary INI file, returning its path.
    /// The caller is responsible for cleanup.
    fn write_tmp_ini(content: &str) -> PathBuf {
        static COUNTER: std::sync::atomic::AtomicU32 = std::sync::atomic::AtomicU32::new(0);
        let id = COUNTER.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
        let dir = std::env::temp_dir().join("ansible-config-test");
        std::fs::create_dir_all(&dir).unwrap();
        let path = dir.join(format!("test-{}-{}.cfg", std::process::id(), id));
        let mut f = std::fs::File::create(&path).unwrap();
        write!(f, "{content}").unwrap();
        path
    }

    #[test]
    fn deprecated_ini_key_connection_path_is_rejected() {
        let path = write_tmp_ini("[defaults]\nconnection_path = /usr/bin/ssh\n");
        let mut config = AnsibleConfig::default();
        load_ini_config(&path, &mut config).unwrap();
        // connection_path has no field on AnsibleConfig — verify defaults remain.
        assert_eq!(config.defaults.remote_user, "root");
        let _ = std::fs::remove_file(&path);
    }

    #[test]
    fn deprecated_ini_key_libvirt_lxc_noseclabel_is_rejected() {
        let path = write_tmp_ini("[defaults]\nlibvirt_lxc_noseclabel = true\n");
        let mut config = AnsibleConfig::default();
        load_ini_config(&path, &mut config).unwrap();
        assert_eq!(config.defaults.remote_user, "root");
        let _ = std::fs::remove_file(&path);
    }

    #[test]
    fn deprecated_ini_key_does_not_pollute_known_fields() {
        let path = write_tmp_ini("[defaults]\nconnection_path = /bad/value\nremote_user = deploy\n");
        let mut config = AnsibleConfig::default();
        load_ini_config(&path, &mut config).unwrap();
        assert_eq!(config.defaults.remote_user, "deploy");
        let _ = std::fs::remove_file(&path);
    }
}
