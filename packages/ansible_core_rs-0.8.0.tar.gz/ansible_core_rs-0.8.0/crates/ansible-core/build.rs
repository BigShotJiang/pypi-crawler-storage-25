use std::env;
use std::fs;
use std::path::Path;

fn main() {
    let manifest_dir = env::var("CARGO_MANIFEST_DIR").unwrap();
    let workspace_root = Path::new(&manifest_dir).parent().unwrap().parent().unwrap();

    set_minijinja_version(workspace_root);
    set_git_version(workspace_root);
}

fn set_minijinja_version(workspace_root: &Path) {
    let lock_path = workspace_root.join("Cargo.lock");

    if let Ok(content) = fs::read_to_string(&lock_path) {
        let mut found_name = false;
        for line in content.lines() {
            let trimmed = line.trim();
            if trimmed == "name = \"minijinja\"" {
                found_name = true;
                continue;
            }
            if found_name && trimmed.starts_with("version =") {
                let version = trimmed
                    .trim_start_matches("version =")
                    .trim()
                    .trim_matches('"');
                if !version.is_empty() {
                    println!("cargo:rustc-env=MINIJINJA_VERSION={version}");
                    return;
                }
            }
            if found_name && (trimmed.starts_with("name =") || trimmed.starts_with("source =")) {
                found_name = false;
            }
        }
    }

    println!("cargo:rustc-env=MINIJINJA_VERSION=2.x");
    println!("cargo:rerun-if-changed=../../Cargo.lock");
}

fn set_git_version(workspace_root: &Path) {
    let git_version = std::process::Command::new("git")
        .args(["describe", "--always", "--dirty"])
        .current_dir(workspace_root)
        .output()
        .ok()
        .and_then(|o| {
            if o.status.success() {
                String::from_utf8(o.stdout).ok().map(|s| s.trim().to_string())
            } else {
                None
            }
        });

    let version = git_version
        .map(|v| format!("{} ({})", env!("CARGO_PKG_VERSION"), v))
        .unwrap_or_else(|| env!("CARGO_PKG_VERSION").to_string());

    println!("cargo:rustc-env=ANSIBLE_VERSION={version}");
    println!("cargo:rerun-if-changed={}/.git/HEAD", workspace_root.display());
}
