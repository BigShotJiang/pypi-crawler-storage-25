//! Integration tests for the `ansible vault` subcommand.

use std::path::PathBuf;
use std::process::Command;

fn ansible_bin() -> PathBuf {
    let mut path = std::env::current_exe()
        .unwrap()
        .parent()
        .unwrap()
        .parent()
        .unwrap()
        .to_path_buf();
    path.push("ansible");
    if !path.exists() {
        path = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../../target/debug/ansible");
    }
    path
}

fn run(args: &[&str]) -> (i32, String, String) {
    let output = Command::new(ansible_bin())
        .args(args)
        .env("ANSIBLE_NOCOLOR", "1")
        .output()
        .expect("failed to run ansible binary");
    let code = output.status.code().unwrap_or(-1);
    let stdout = String::from_utf8_lossy(&output.stdout).to_string();
    let stderr = String::from_utf8_lossy(&output.stderr).to_string();
    (code, stdout, stderr)
}

/// Regression test for upstream sync of ansible/ansible@f6d0379191
/// (PR #86602, tracked in issue #60): `ansible-vault` decrypt/view errors
/// are operation-scoped and name the file in repr form, rather than
/// splatting the underlying exception text.
#[test]
fn vault_decrypt_failure_message_matches_upstream_format() {
    let dir = tempfile::tempdir().unwrap();
    let pw = dir.path().join("pw.txt");
    std::fs::write(&pw, "testpw\n").unwrap();
    let target = dir.path().join("not-a-vault.txt");
    std::fs::write(&target, "just plain text, no vault header\n").unwrap();

    let (code, _stdout, stderr) = run(&[
        "--vault-password-file",
        pw.to_str().unwrap(),
        "vault",
        "decrypt",
        target.to_str().unwrap(),
    ]);

    assert_ne!(code, 0, "decrypt of non-vault file must fail");
    let expected = format!("Failed to decrypt '{}'.", target.display());
    assert!(
        stderr.contains(&expected),
        "stderr should contain {expected:?}, got:\n{stderr}"
    );
}

#[test]
fn vault_view_failure_message_matches_upstream_format() {
    let dir = tempfile::tempdir().unwrap();
    let pw = dir.path().join("pw.txt");
    std::fs::write(&pw, "testpw\n").unwrap();
    let missing = dir.path().join("does-not-exist.yml");

    let (code, _stdout, stderr) = run(&[
        "--vault-password-file",
        pw.to_str().unwrap(),
        "vault",
        "view",
        missing.to_str().unwrap(),
    ]);

    assert_ne!(code, 0, "view of missing file must fail");
    let expected = format!("Failed to view '{}'.", missing.display());
    assert!(
        stderr.contains(&expected),
        "stderr should contain {expected:?}, got:\n{stderr}"
    );
}

#[test]
fn vault_rekey_reencrypts_with_new_password() {
    let dir = tempfile::tempdir().unwrap();
    let old_pw = dir.path().join("old_pw.txt");
    std::fs::write(&old_pw, "oldpassword\n").unwrap();
    let new_pw = dir.path().join("new_pw.txt");
    std::fs::write(&new_pw, "newpassword\n").unwrap();

    let secret_file = dir.path().join("secrets.yml");
    std::fs::write(&secret_file, "my-secret-data").unwrap();

    // Encrypt with old password
    let (code, stdout, stderr) = run(&[
        "--vault-password-file",
        old_pw.to_str().unwrap(),
        "vault",
        "encrypt",
        secret_file.to_str().unwrap(),
    ]);
    assert_eq!(code, 0, "encrypt failed:\n{stderr}\n{stdout}");

    // Rekey to new password
    let (code, stdout, stderr) = run(&[
        "--vault-password-file",
        old_pw.to_str().unwrap(),
        "vault",
        "rekey",
        "--new-vault-password-file",
        new_pw.to_str().unwrap(),
        secret_file.to_str().unwrap(),
    ]);
    assert_eq!(code, 0, "rekey failed:\n{stderr}\n{stdout}");
    assert!(
        stdout.contains("Rekey successful"),
        "stdout should mention success, got:\n{stdout}"
    );

    // Decrypt with new password should succeed
    let (code, stdout, stderr) = run(&[
        "--vault-password-file",
        new_pw.to_str().unwrap(),
        "vault",
        "decrypt",
        secret_file.to_str().unwrap(),
    ]);
    assert_eq!(code, 0, "decrypt with new pw failed:\n{stderr}\n{stdout}");

    let content = std::fs::read_to_string(&secret_file).unwrap();
    assert_eq!(content, "my-secret-data");
}

#[test]
fn vault_rekey_old_password_fails_to_decrypt_after_rekey() {
    let dir = tempfile::tempdir().unwrap();
    let old_pw = dir.path().join("old_pw.txt");
    std::fs::write(&old_pw, "oldpassword\n").unwrap();
    let new_pw = dir.path().join("new_pw.txt");
    std::fs::write(&new_pw, "newpassword\n").unwrap();

    let secret_file = dir.path().join("secrets.yml");
    std::fs::write(&secret_file, "my-secret-data").unwrap();

    // Encrypt with old password
    run(&[
        "--vault-password-file",
        old_pw.to_str().unwrap(),
        "vault",
        "encrypt",
        secret_file.to_str().unwrap(),
    ]);

    // Rekey
    run(&[
        "--vault-password-file",
        old_pw.to_str().unwrap(),
        "vault",
        "rekey",
        "--new-vault-password-file",
        new_pw.to_str().unwrap(),
        secret_file.to_str().unwrap(),
    ]);

    // Decrypt with OLD password should fail
    let (code, _stdout, stderr) = run(&[
        "--vault-password-file",
        old_pw.to_str().unwrap(),
        "vault",
        "decrypt",
        secret_file.to_str().unwrap(),
    ]);
    assert_ne!(code, 0, "old password should no longer work after rekey:\n{stderr}");
}

#[test]
fn vault_rekey_multiple_files() {
    let dir = tempfile::tempdir().unwrap();
    let old_pw = dir.path().join("old_pw.txt");
    std::fs::write(&old_pw, "oldpassword\n").unwrap();
    let new_pw = dir.path().join("new_pw.txt");
    std::fs::write(&new_pw, "newpassword\n").unwrap();

    let file_a = dir.path().join("a.yml");
    let file_b = dir.path().join("b.yml");
    std::fs::write(&file_a, "secret-a").unwrap();
    std::fs::write(&file_b, "secret-b").unwrap();

    // Encrypt both with old password
    run(&[
        "--vault-password-file",
        old_pw.to_str().unwrap(),
        "vault",
        "encrypt",
        file_a.to_str().unwrap(),
        file_b.to_str().unwrap(),
    ]);

    // Rekey both
    let (code, stdout, _stderr) = run(&[
        "--vault-password-file",
        old_pw.to_str().unwrap(),
        "vault",
        "rekey",
        "--new-vault-password-file",
        new_pw.to_str().unwrap(),
        file_a.to_str().unwrap(),
        file_b.to_str().unwrap(),
    ]);
    assert_eq!(code, 0, "rekey of multiple files failed");
    assert_eq!(
        stdout.matches("Rekey successful").count(),
        2,
        "should report success for each file, got:\n{stdout}"
    );
}

#[test]
fn vault_rekey_wrong_old_password_leaves_file_untouched() {
    let dir = tempfile::tempdir().unwrap();
    let real_pw = dir.path().join("real_pw.txt");
    std::fs::write(&real_pw, "realpassword\n").unwrap();
    let wrong_pw = dir.path().join("wrong_pw.txt");
    std::fs::write(&wrong_pw, "wrongpassword\n").unwrap();
    let new_pw = dir.path().join("new_pw.txt");
    std::fs::write(&new_pw, "newpassword\n").unwrap();

    let secret_file = dir.path().join("secrets.yml");
    std::fs::write(&secret_file, "my-secret-data").unwrap();

    // Encrypt with real password
    run(&[
        "--vault-password-file",
        real_pw.to_str().unwrap(),
        "vault",
        "encrypt",
        secret_file.to_str().unwrap(),
    ]);

    let encrypted_before = std::fs::read_to_string(&secret_file).unwrap();

    // Try to rekey with wrong old password
    let (code, _stdout, _stderr) = run(&[
        "--vault-password-file",
        wrong_pw.to_str().unwrap(),
        "vault",
        "rekey",
        "--new-vault-password-file",
        new_pw.to_str().unwrap(),
        secret_file.to_str().unwrap(),
    ]);
    assert_ne!(code, 0, "rekey with wrong old password should fail");

    // File should be untouched
    let encrypted_after = std::fs::read_to_string(&secret_file).unwrap();
    assert_eq!(encrypted_before, encrypted_after, "file should not be modified on failure");
}

#[test]
fn vault_rekey_missing_new_password_file_fails() {
    let dir = tempfile::tempdir().unwrap();
    let old_pw = dir.path().join("old_pw.txt");
    std::fs::write(&old_pw, "oldpassword\n").unwrap();
    let new_pw = dir.path().join("nonexistent.txt");

    let secret_file = dir.path().join("secrets.yml");
    std::fs::write(&secret_file, "my-secret-data").unwrap();

    // Encrypt
    run(&[
        "--vault-password-file",
        old_pw.to_str().unwrap(),
        "vault",
        "encrypt",
        secret_file.to_str().unwrap(),
    ]);

    // Try rekey with missing new password file
    let (code, _stdout, _stderr) = run(&[
        "--vault-password-file",
        old_pw.to_str().unwrap(),
        "vault",
        "rekey",
        "--new-vault-password-file",
        new_pw.to_str().unwrap(),
        secret_file.to_str().unwrap(),
    ]);
    assert_ne!(code, 0, "rekey with missing new pw file should fail");
}
