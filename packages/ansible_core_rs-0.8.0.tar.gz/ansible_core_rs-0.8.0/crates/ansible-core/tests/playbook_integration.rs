//! Integration tests that run the `ansible` binary against fixture playbooks
//! and verify exit codes and output patterns.
//!
//! These tests exercise the full stack: CLI parsing -> playbook loading ->
//! play iteration -> strategy -> task execution -> callback output. They are
//! the Phase 9 parity testing foundation.
//!
//! Previously known gaps (now fixed):
//! - TASK banners: strategy now stores task name in task_fields, playbook
//!   executor emits v2_playbook_on_task_start when task changes.
//! - debug msg: display_result_detail now checks TaskResult.msg as fallback.

use std::path::PathBuf;
use std::process::Command;

/// Locate the `ansible` binary built by cargo.
fn ansible_bin() -> PathBuf {
    let mut path = std::env::current_exe()
        .unwrap()
        .parent()
        .unwrap()
        .parent()
        .unwrap()
        .to_path_buf();
    path.push("ansible");
    if !path.exists() {
        path = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
            .join("../../target/debug/ansible");
    }
    path
}

/// Path to the fixtures directory.
fn fixtures_dir() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("tests/fixtures")
}

/// Run a playbook and return (exit_code, stdout, stderr).
fn run_playbook(fixture: &str) -> (i32, String, String) {
    run_playbook_with_args(fixture, &[])
}

/// Run a playbook with additional CLI args.
///
/// `pre_args` go before the `playbook` subcommand (e.g. `-e key=val`),
/// `post_args` go after (e.g. `--tags deploy`).
fn run_playbook_with_args(fixture: &str, post_args: &[&str]) -> (i32, String, String) {
    run_playbook_full(fixture, &[], post_args)
}

fn run_playbook_full(
    fixture: &str,
    pre_args: &[&str],
    post_args: &[&str],
) -> (i32, String, String) {
    let playbook = fixtures_dir().join(fixture);
    assert!(
        playbook.exists(),
        "fixture not found: {}",
        playbook.display()
    );

    let mut cmd = Command::new(ansible_bin());
    // Pre-subcommand args (top-level flags like -e)
    cmd.args(pre_args);
    cmd.arg("playbook").arg(&playbook);
    // Post-subcommand args (playbook-specific flags like --tags)
    cmd.args(post_args);
    cmd.env("ANSIBLE_NOCOLOR", "1");

    let output = cmd.output().expect("failed to run ansible binary");
    let code = output.status.code().unwrap_or(-1);
    let stdout = String::from_utf8_lossy(&output.stdout).to_string();
    let stderr = String::from_utf8_lossy(&output.stderr).to_string();
    (code, stdout, stderr)
}

/// Run an ad-hoc command and return (exit_code, stdout, stderr).
fn run_adhoc(pattern: &str, module: &str, args: Option<&str>) -> (i32, String, String) {
    let mut cmd = Command::new(ansible_bin());
    cmd.arg(pattern).arg("-m").arg(module);
    if let Some(a) = args {
        cmd.arg("-a").arg(a);
    }
    cmd.env("ANSIBLE_NOCOLOR", "1");

    let output = cmd.output().expect("failed to run ansible binary");
    let code = output.status.code().unwrap_or(-1);
    let stdout = String::from_utf8_lossy(&output.stdout).to_string();
    let stderr = String::from_utf8_lossy(&output.stderr).to_string();
    (code, stdout, stderr)
}

// ============ Playbook tests ============

#[test]
fn test_simple_ping_playbook() {
    let (code, stdout, _stderr) = run_playbook("simple_ping.yml");
    assert_eq!(code, 0, "ping playbook should exit 0");
    assert!(
        stdout.contains("PLAY [Simple ping test]"),
        "should show play banner, got:\n{stdout}"
    );
    assert!(
        stdout.contains("TASK [Ping localhost]"),
        "should show task banner, got:\n{stdout}"
    );
    assert!(
        stdout.contains("ok: [localhost]"),
        "should show ok result, got:\n{stdout}"
    );
    assert!(
        stdout.contains("PLAY RECAP"),
        "should show recap, got:\n{stdout}"
    );
    // Verify stats show ok=1
    assert!(
        stdout.contains("ok=1"),
        "recap should show ok=1, got:\n{stdout}"
    );
}

#[test]
fn test_debug_vars_playbook() {
    let (code, stdout, _stderr) = run_playbook("debug_vars.yml");
    assert_eq!(code, 0, "debug vars playbook should exit 0");
    // All 4 tasks should show ok
    assert_eq!(
        stdout.matches("ok: [localhost]").count(),
        4,
        "should have 4 ok results, got:\n{stdout}"
    );
    // TASK banners should appear for each task
    assert!(
        stdout.contains("TASK [Print greeting]"),
        "should show task banner for Print greeting, got:\n{stdout}"
    );
    assert!(
        stdout.contains("TASK [Print computed fact]"),
        "should show task banner for Print computed fact, got:\n{stdout}"
    );
    // Debug msg content should be displayed
    assert!(
        stdout.contains("msg: hello world"),
        "should show debug msg content, got:\n{stdout}"
    );
    assert!(
        stdout.contains("msg: Count is 42"),
        "should show interpolated debug msg, got:\n{stdout}"
    );
    assert!(
        stdout.contains("ok=4"),
        "recap should show ok=4, got:\n{stdout}"
    );
}

#[test]
fn test_conditionals_playbook() {
    let (code, stdout, _stderr) = run_playbook("conditionals.yml");
    assert_eq!(code, 0, "conditionals playbook should exit 0");
    // 2 tasks should run, 1 should skip
    assert!(
        stdout.contains("skipping:"),
        "disabled task should be skipped, got:\n{stdout}"
    );
    assert!(
        stdout.contains("ok=2"),
        "recap should show ok=2, got:\n{stdout}"
    );
}

#[test]
fn test_loops_playbook() {
    let (code, stdout, _stderr) = run_playbook("loops.yml");
    assert_eq!(code, 0, "loops playbook should exit 0");
    // Each loop task reports one aggregate ok result
    assert!(
        stdout.contains("ok=2"),
        "should show ok=2 (one per loop task), got:\n{stdout}"
    );
}

#[test]
fn test_command_module_playbook() {
    let (code, stdout, stderr) = run_playbook("command_module.yml");
    assert_eq!(
        code, 0,
        "command module playbook should exit 0, stderr:\n{stderr}\nstdout:\n{stdout}"
    );
    assert!(
        stdout.contains("ok=") || stdout.contains("changed="),
        "should show recap with results, got:\n{stdout}"
    );
}

#[test]
fn test_extra_vars() {
    let (code, stdout, _stderr) =
        run_playbook_full("extra_vars.yml", &["-e", "my_var=test_value"], &[]);
    assert_eq!(code, 0, "extra vars playbook should exit 0");
    assert!(
        stdout.contains("ok=1"),
        "should execute 1 task, got:\n{stdout}"
    );
}

#[test]
fn test_tags_filter() {
    // Run only the deploy tag
    let (code, stdout, _stderr) =
        run_playbook_with_args("tags_test.yml", &["--tags", "deploy"]);
    assert_eq!(code, 0, "tagged playbook should exit 0");
    // Should run only 1 task (the deploy-tagged one)
    assert!(
        stdout.contains("ok=1"),
        "should run exactly 1 tagged task, got:\n{stdout}"
    );
}

// ============ Ad-hoc tests ============

#[test]
fn test_adhoc_ping() {
    let (code, stdout, _stderr) = run_adhoc("localhost", "ping", None);
    assert_eq!(code, 0, "adhoc ping should exit 0");
    assert!(
        stdout.contains("ok: [localhost]"),
        "should show ok result, got:\n{stdout}"
    );
    assert!(
        stdout.contains("pong"),
        "ping module should return pong, got:\n{stdout}"
    );
}

/// Phase 6.6 deliverable: `ansible <pattern> -m ping` against a pattern
/// that resolves via an explicit inventory file. Verifies the full
/// CLI → inventory → executor → native ping module → callback path.
#[test]
fn test_adhoc_ping_with_inventory_all() {
    let tmp = tempfile::tempdir().unwrap();
    let inv_path = tmp.path().join("hosts");
    std::fs::write(
        &inv_path,
        "localhost ansible_connection=local\n",
    )
    .unwrap();

    let mut cmd = Command::new(ansible_bin());
    cmd.args(["-i"])
        .arg(&inv_path)
        .args(["all", "-m", "ping"]);
    cmd.env("ANSIBLE_NOCOLOR", "1");
    let output = cmd.output().expect("failed to run ansible binary");

    let code = output.status.code().unwrap_or(-1);
    let stdout = String::from_utf8_lossy(&output.stdout).to_string();
    let stderr = String::from_utf8_lossy(&output.stderr).to_string();

    assert_eq!(
        code, 0,
        "`ansible all -m ping` should exit 0, stderr:\n{stderr}\nstdout:\n{stdout}"
    );
    assert!(
        stdout.contains("ok: [localhost]"),
        "should show ok result, got:\n{stdout}"
    );
    assert!(
        stdout.contains("pong"),
        "should return pong, got:\n{stdout}"
    );
}

#[test]
fn test_adhoc_command() {
    let (code, stdout, _stderr) = run_adhoc("localhost", "command", Some("echo integration_test"));
    assert_eq!(code, 0, "adhoc command should exit 0");
    assert!(
        stdout.contains("integration_test"),
        "should show command output, got:\n{stdout}"
    );
}

// ============ Galaxy CLI tests ============

#[test]
fn test_galaxy_collection_list_empty() {
    let tmp = tempfile::tempdir().unwrap();
    let mut cmd = Command::new(ansible_bin());
    cmd.args(["galaxy", "collection", "list", "--collections-path"])
        .arg(tmp.path());
    cmd.env("ANSIBLE_NOCOLOR", "1");
    let output = cmd.output().unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(
        stdout.contains("No collections found"),
        "empty path should show no collections, got:\n{stdout}"
    );
}

// ============ File module tests ============

#[test]
fn test_blockinfile_playbook() {
    let (code, stdout, stderr) = run_playbook("blockinfile.yml");
    assert_eq!(
        code, 0,
        "blockinfile playbook should exit 0, stderr:\n{stderr}\nstdout:\n{stdout}"
    );
    // Should have changed=1 for insert (copy creates, blockinfile inserts, ...)
    assert!(
        stdout.contains("TASK [Insert a managed block]"),
        "should show task banner, got:\n{stdout}"
    );
    // The managed block content should appear in the cat output
    assert!(
        stdout.contains("ANSIBLE MANAGED BLOCK") || stdout.contains("managed_setting"),
        "should show managed block content, got:\n{stdout}"
    );
}

#[test]
fn test_replace_module_playbook() {
    let (code, stdout, stderr) = run_playbook("replace_module.yml");
    assert_eq!(
        code, 0,
        "replace module playbook should exit 0, stderr:\n{stderr}\nstdout:\n{stdout}"
    );
    assert!(
        stdout.contains("TASK [Replace port value]"),
        "should show task banner, got:\n{stdout}"
    );
    // After replacement, the cat output should contain the new port
    assert!(
        stdout.contains("server_port=9090"),
        "should show replaced port value, got:\n{stdout}"
    );
}

// ============ Error handling tests ============

#[test]
fn test_nonexistent_playbook() {
    let mut cmd = Command::new(ansible_bin());
    cmd.arg("playbook").arg("/tmp/definitely_does_not_exist.yml");
    cmd.env("ANSIBLE_NOCOLOR", "1");
    let output = cmd.output().unwrap();
    assert_ne!(output.status.code().unwrap_or(0), 0, "should fail for missing playbook");
}

#[test]
fn test_help_output() {
    let mut cmd = Command::new(ansible_bin());
    cmd.arg("--help");
    let output = cmd.output().unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("ansible-core-rs"), "help should mention project name");
    assert!(stdout.contains("playbook"), "help should list playbook subcommand");
    assert!(stdout.contains("galaxy"), "help should list galaxy subcommand");
}

// ============ Check-mode tests ============

#[test]
fn test_check_mode_skips_destructive_tasks() {
    let (code, stdout, stderr) = run_playbook_with_args("check_mode.yml", &["--check"]);
    assert_eq!(
        code, 0,
        "check mode playbook should exit 0, stderr:\n{stderr}\nstdout:\n{stdout}"
    );
    // The debug module should still run in check mode
    assert!(
        stdout.contains("check mode is working"),
        "debug task should run in check mode, got:\n{stdout}"
    );
    // The file task with check_mode: no should still run (override)
    // The command task should be skipped (not in CHECK_MODE_MODULES)
    assert!(
        stdout.contains("skipping"),
        "command task should be skipped in check mode, got:\n{stdout}"
    );
}

#[test]
fn test_check_mode_no_file_side_effects() {
    let test_path = "/tmp/ansible-core-rs-check-mode-no-side-effect";
    // Clean up from previous runs
    let _ = std::fs::remove_file(test_path);

    // Run a simple playbook with --check that would create a file
    let playbook_content = format!(
        r#"---
- name: Check mode no side effects
  hosts: localhost
  gather_facts: false
  connection: local
  tasks:
    - name: Touch a file
      file:
        path: {test_path}
        state: touch
"#
    );
    let tmp = tempfile::NamedTempFile::with_suffix(".yml").unwrap();
    std::fs::write(tmp.path(), &playbook_content).unwrap();
    let mut cmd = Command::new(ansible_bin());
    cmd.args(["playbook", tmp.path().to_str().unwrap(), "--check"])
        .env("ANSIBLE_NOCOLOR", "1");
    let output = cmd.output().unwrap();
    let code = output.status.code().unwrap_or(-1);
    let stdout = String::from_utf8_lossy(&output.stdout).to_string();
    let stderr = String::from_utf8_lossy(&output.stderr).to_string();
    assert_eq!(code, 0, "stderr:\n{stderr}\nstdout:\n{stdout}");

    // File should NOT exist after check mode
    assert!(
        !std::path::Path::new(test_path).exists(),
        "file should not be created in check mode"
    );

    // But the task should report changed
    assert!(
        stdout.contains("changed"),
        "task should report 'changed' in check mode, got:\n{stdout}"
    );
}

#[test]
fn test_check_mode_per_task_override() {
    // Verify that check_mode: no on a task overrides --check
    let test_path = "/tmp/ansible-core-rs-check-mode-override";
    let _ = std::fs::remove_file(test_path);

    let playbook_content = format!(
        r#"---
- name: Check mode override
  hosts: localhost
  gather_facts: false
  connection: local
  tasks:
    - name: Force run despite --check
      file:
        path: {test_path}
        state: touch
      check_mode: no
"#
    );
    let tmp = tempfile::NamedTempFile::with_suffix(".yml").unwrap();
    std::fs::write(tmp.path(), &playbook_content).unwrap();
    let mut cmd = Command::new(ansible_bin());
    cmd.args(["playbook", tmp.path().to_str().unwrap(), "--check"])
        .env("ANSIBLE_NOCOLOR", "1");
    let output = cmd.output().unwrap();
    let code = output.status.code().unwrap_or(-1);
    let stdout = String::from_utf8_lossy(&output.stdout).to_string();
    let stderr = String::from_utf8_lossy(&output.stderr).to_string();
    assert_eq!(code, 0, "stderr:\n{stderr}\nstdout:\n{stdout}");

    // File SHOULD exist because check_mode: no overrides --check
    assert!(
        std::path::Path::new(test_path).exists(),
        "file should be created when check_mode: no overrides --check"
    );

    let _ = std::fs::remove_file(test_path);
}
