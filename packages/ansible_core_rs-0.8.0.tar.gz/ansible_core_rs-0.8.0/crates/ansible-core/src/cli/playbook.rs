use std::path::PathBuf;
use std::sync::Arc;

use anyhow::Result;

use ansible_executor::play_iterator::PlayIterator;
use ansible_executor::strategy::free::FreeStrategy;
use ansible_executor::strategy::host_pinned::HostPinnedStrategy;
use ansible_executor::strategy::linear::LinearStrategy;
use ansible_executor::strategy::StrategyPlugin;
use ansible_inventory::{resolve_pattern, InventoryManager};
use ansible_playbook::{load_playbook, TagFilter};
use ansible_plugins::callback::CallbackRegistry;
use ansible_plugins::CallbackPlugin;
use ansible_utils::AggregateStats;
use ansible_vars::VariableManager;

/// Run one or more playbooks through the full execution pipeline.
#[allow(clippy::too_many_arguments)]
pub fn run_playbook(
    config: &ansible_config::AnsibleConfig,
    playbooks: &[PathBuf],
    inventory_source: Option<&str>,
    forks: usize,
    extra_vars: &[(String, ansible_utils::AnsibleValue)],
    tags: Option<&str>,
    skip_tags: Option<&str>,
    start_at_task: Option<&str>,
    limit: Option<&str>,
    check_mode: bool,
    cli_remote_user: Option<&str>,
    force_handlers: bool,
) -> Result<u8> {
    let tag_filter = TagFilter::from_cli(tags, skip_tags);
    // Set up inventory
    let mut inventory = InventoryManager::new();
    if let Some(inv_src) = inventory_source {
        inventory.add_source(PathBuf::from(inv_src));
        inventory.parse_sources().map_err(|e| {
            anyhow::anyhow!("failed to parse inventory '{}': {}", inv_src, e)
        })?;
    }
    let inventory = Arc::new(inventory);

    // Set up variable manager
    let mut variable_manager = VariableManager::new(inventory.clone());
    if !extra_vars.is_empty() {
        let mut ev = std::collections::HashMap::new();
        for (k, v) in extra_vars {
            ev.insert(k.clone(), v.clone());
        }
        variable_manager.set_extra_vars(ev);
    }
    variable_manager.set_cli_remote_user(cli_remote_user.map(|s| s.to_string()));
    variable_manager.set_config_remote_user(config.defaults.remote_user.clone());
    let variable_manager = Arc::new(variable_manager);

    // Set up callback registry from `[defaults] stdout_callback`. The
    // registry is the single dispatch point so additional callbacks can be
    // wired in without touching CLI code.
    let callback = CallbackRegistry::from_config(
        &config.defaults.stdout_callback,
        &[],
    );

    // Set up stats
    let mut stats = AggregateStats::new();

    // Create the async runtime
    let rt = tokio::runtime::Runtime::new()?;

    let mut exit_code = 0u8;

    for playbook_path in playbooks {
        // Load playbook
        let playbook = load_playbook(playbook_path).map_err(|e| {
            anyhow::anyhow!(
                "ERROR! couldn't load playbook {}: {}",
                playbook_path.display(),
                e
            )
        })?;

        callback.v2_playbook_on_start(&playbook_path.to_string_lossy());

        for play in &playbook.plays {
            // CLI `--force-handlers` is an OR over the play-level setting:
            // either source turning it on flushes handlers on failed hosts.
            let mut play = play.clone();
            if force_handlers {
                play.force_handlers = true;
            }
            let play = &play;
            let play_name = play.name.as_deref().unwrap_or("unnamed");
            callback.v2_playbook_on_play_start(play_name);

            // Resolve host pattern
            let host_pattern = play.hosts.as_deref().unwrap_or("all");
            let mut hosts = resolve_pattern(host_pattern, inventory.data());

            // Apply --limit to further restrict matched hosts
            if let Some(limit_pattern) = limit {
                let limit_hosts: std::collections::HashSet<String> =
                    resolve_pattern(limit_pattern, inventory.data())
                        .into_iter()
                        .collect();
                hosts.retain(|h| limit_hosts.contains(h));
            }

            if hosts.is_empty() {
                println!(
                    "\nWARNING: No hosts matched pattern '{}', skipping play",
                    host_pattern
                );
                continue;
            }

            // Create play iterator with tag filter applied.
            let mut iterator =
                PlayIterator::with_tag_filter(play.clone(), &hosts, tag_filter.clone());
            // Apply --start-at-task fast-forward if requested.
            if let Some(name) = start_at_task {
                iterator.set_start_at_task(Some(name.to_string()));
            }

            // Select strategy
            let strategy: Box<dyn StrategyPlugin> = match play.strategy.as_str() {
                "free" => Box::new(FreeStrategy),
                "host_pinned" => Box::new(HostPinnedStrategy),
                _ => Box::new(LinearStrategy),
            };

            // Run the strategy
            let result = rt.block_on(async {
                strategy
                    .run(&mut iterator, variable_manager.clone(), &mut stats, forks, check_mode)
                    .await
            });

            match result {
                Ok(strategy_result) => {
                    // Report results via callback, emitting TASK banners
                    // when the task name changes between consecutive results.
                    let mut current_task_name: Option<String> = None;
                    for task_result in &strategy_result.results {
                        // Emit TASK banner when we transition to a new task.
                        if let Some(name) = task_result
                            .task_fields
                            .get("name")
                            .and_then(|v| v.as_str())
                        {
                            let emit = current_task_name
                                .as_deref() != Some(name);
                            if emit {
                                callback.v2_playbook_on_task_start(name, false);
                                current_task_name = Some(name.to_string());
                            }
                        }

                        let result_val = serde_json::to_value(task_result)
                            .unwrap_or(serde_json::Value::Null);

                        if task_result.unreachable {
                            callback.v2_runner_on_unreachable(
                                &task_result.host,
                                &result_val,
                            );
                        } else if task_result.failed {
                            callback.v2_runner_on_failed(
                                &task_result.host,
                                &result_val,
                                false,
                            );
                        } else if task_result.skipped {
                            callback.v2_runner_on_skipped(&task_result.host, &result_val);
                        } else {
                            callback.v2_runner_on_ok(&task_result.host, &result_val);
                        }
                    }

                    if !strategy_result.all_ok {
                        exit_code = 2;
                    }
                }
                Err(e) => {
                    eprintln!("ERROR! play execution failed: {}", e);
                    exit_code = 1;
                    break;
                }
            }
        }

        // Display stats via callback (handles formatting and colors)
        let stats_val = serde_json::to_value(&stats)
            .unwrap_or(serde_json::Value::Null);
        callback.v2_playbook_on_stats(&stats_val);
    }

    Ok(exit_code)
}
