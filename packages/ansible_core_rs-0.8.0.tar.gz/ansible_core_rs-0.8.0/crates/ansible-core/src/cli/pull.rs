use std::path::{Path, PathBuf};
use std::process::Command;

use anyhow::{bail, Context, Result};

/// Run `ansible-pull`: clone (or update) a playbook repository on the local
/// host and run a playbook from it against `localhost`.
///
/// Mirrors the upstream contract: pull-based deployment where the managed
/// node fetches its own configuration rather than being pushed to.
#[allow(clippy::too_many_arguments)]
pub fn run_pull(
    config: &ansible_config::AnsibleConfig,
    url: Option<String>,
    directory: Option<PathBuf>,
    checkout: Option<String>,
    accept_host_key: bool,
    purge: bool,
    clean: bool,
    full: bool,
    playbook: Option<PathBuf>,
    inventory_source: Option<&str>,
    extra_vars: &[(String, ansible_utils::AnsibleValue)],
    tags: Option<&str>,
    skip_tags: Option<&str>,
    limit: Option<&str>,
    check_mode: bool,
    cli_remote_user: Option<&str>,
    forks: usize,
) -> Result<u8> {
    let url = url.ok_or_else(|| {
        anyhow::anyhow!("ERROR! the URL of the playbook repository is required (-U or positional)")
    })?;

    let dest = directory.unwrap_or_else(default_pull_dir);

    fetch_repo(
        &url,
        &dest,
        checkout.as_deref(),
        accept_host_key,
        full,
        clean,
    )?;

    let playbook_name = playbook.unwrap_or_else(|| PathBuf::from("local.yml"));
    let playbook_path = if playbook_name.is_absolute() {
        playbook_name
    } else {
        dest.join(&playbook_name)
    };

    if !playbook_path.exists() {
        bail!(
            "ERROR! the playbook {} could not be found",
            playbook_path.display()
        );
    }

    // If the operator did not provide an inventory, fabricate one that points
    // at the local host with `ansible_connection=local`. ansible-pull is a
    // local-only deploy by definition, so this matches operator intent and
    // works around the fact that the CLI's `--connection` flag is currently
    // ignored by the executor (see `cli::playbook::run_playbook`).
    let temp_inv = if inventory_source.is_none() {
        let temp = tempfile::NamedTempFile::new()
            .context("failed to create temp inventory for ansible-pull")?;
        std::fs::write(temp.path(), "localhost ansible_connection=local\n")
            .context("failed to write temp inventory for ansible-pull")?;
        Some(temp)
    } else {
        None
    };

    let inv_owned = inventory_source
        .map(|s| s.to_string())
        .or_else(|| temp_inv.as_ref().map(|t| t.path().to_string_lossy().into_owned()));

    let exit_code = crate::cli::playbook::run_playbook(
        config,
        std::slice::from_ref(&playbook_path),
        inv_owned.as_deref(),
        forks,
        extra_vars,
        tags,
        skip_tags,
        None,
        limit,
        check_mode,
        cli_remote_user,
        false,
    )?;

    drop(temp_inv);

    if purge {
        if let Err(e) = std::fs::remove_dir_all(&dest) {
            tracing::warn!("failed to purge {}: {}", dest.display(), e);
        }
    }

    Ok(exit_code)
}

fn default_pull_dir() -> PathBuf {
    let hostname = std::env::var("HOSTNAME")
        .ok()
        .or_else(|| {
            std::fs::read_to_string("/etc/hostname")
                .ok()
                .map(|s| s.trim().to_string())
                .filter(|s| !s.is_empty())
        })
        .unwrap_or_else(|| "localhost".to_string());
    let home = std::env::var_os("HOME")
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from("."));
    home.join(".ansible").join("pull").join(hostname)
}

fn fetch_repo(
    url: &str,
    dest: &Path,
    checkout: Option<&str>,
    accept_host_key: bool,
    full: bool,
    clean: bool,
) -> Result<()> {
    let ssh_command = accept_host_key
        .then_some("ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null");

    if dest.join(".git").is_dir() {
        if clean {
            run_git(&["reset", "--hard", "HEAD"], Some(dest), ssh_command)
                .context("git reset failed")?;
            run_git(&["clean", "-fd"], Some(dest), ssh_command).context("git clean failed")?;
        }
        run_git(&["fetch", "--all"], Some(dest), ssh_command).context("git fetch failed")?;

        let target = checkout.unwrap_or("HEAD");
        run_git(
            &["checkout", "--force", target],
            Some(dest),
            ssh_command,
        )
        .with_context(|| format!("git checkout {target} failed"))?;
    } else {
        if let Some(parent) = dest.parent() {
            std::fs::create_dir_all(parent).ok();
        }
        let mut clone_args: Vec<&str> = vec!["clone"];
        if !full {
            clone_args.extend(["--depth", "1"]);
            if let Some(branch) = checkout {
                clone_args.extend(["--branch", branch]);
            }
        }
        let dest_str = dest.to_string_lossy().into_owned();
        clone_args.push(url);
        clone_args.push(&dest_str);
        run_git(&clone_args, None, ssh_command).context("git clone failed")?;

        if full {
            if let Some(target) = checkout {
                run_git(
                    &["checkout", "--force", target],
                    Some(dest),
                    ssh_command,
                )
                .with_context(|| format!("git checkout {target} failed"))?;
            }
        }
    }
    Ok(())
}

fn run_git(args: &[&str], cwd: Option<&Path>, ssh_command: Option<&str>) -> Result<()> {
    let mut cmd = Command::new("git");
    cmd.args(args);
    if let Some(dir) = cwd {
        cmd.current_dir(dir);
    }
    if let Some(ssh) = ssh_command {
        cmd.env("GIT_SSH_COMMAND", ssh);
    }
    let status = cmd
        .status()
        .with_context(|| format!("failed to spawn git {:?}", args))?;
    if !status.success() {
        bail!("git {:?} exited with {}", args, status);
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn git_available() -> bool {
        Command::new("git")
            .arg("--version")
            .status()
            .map(|s| s.success())
            .unwrap_or(false)
    }

    fn init_repo_with_playbook(path: &Path, playbook_name: &str, playbook_body: &str) {
        std::fs::create_dir_all(path).unwrap();
        Command::new("git")
            .args(["-c", "init.defaultBranch=main", "init", "-q"])
            .current_dir(path)
            .status()
            .expect("git init");
        Command::new("git")
            .args(["config", "user.email", "test@example.com"])
            .current_dir(path)
            .status()
            .unwrap();
        Command::new("git")
            .args(["config", "user.name", "Test"])
            .current_dir(path)
            .status()
            .unwrap();
        std::fs::write(path.join(playbook_name), playbook_body).unwrap();
        Command::new("git")
            .args(["add", "."])
            .current_dir(path)
            .status()
            .unwrap();
        Command::new("git")
            .args(["commit", "-q", "-m", "init"])
            .current_dir(path)
            .status()
            .unwrap();
    }

    #[test]
    fn missing_url_is_an_error() {
        let cfg = ansible_config::AnsibleConfig::default();
        let res = run_pull(
            &cfg, None, None, None, false, false, false, false, None, None, &[], None, None,
            None, false, None, 5,
        );
        let err = res.unwrap_err().to_string();
        assert!(
            err.contains("URL of the playbook repository is required"),
            "got: {err}"
        );
    }

    #[test]
    fn fetch_repo_clones_and_updates() {
        if !git_available() {
            eprintln!("skipping: git not available");
            return;
        }
        let tmp = tempfile::tempdir().unwrap();
        let upstream = tmp.path().join("upstream");
        init_repo_with_playbook(&upstream, "local.yml", "- hosts: localhost\n  tasks: []\n");

        let dest = tmp.path().join("checkout");
        let url = upstream.to_string_lossy().to_string();

        // Initial clone
        fetch_repo(&url, &dest, None, false, true, false).expect("first fetch");
        assert!(dest.join("local.yml").exists());
        assert!(dest.join(".git").is_dir());

        // Re-run: should fetch + checkout without error.
        fetch_repo(&url, &dest, None, false, true, false).expect("second fetch");
    }

    #[test]
    fn missing_playbook_is_an_error() {
        if !git_available() {
            eprintln!("skipping: git not available");
            return;
        }
        let tmp = tempfile::tempdir().unwrap();
        let upstream = tmp.path().join("upstream");
        init_repo_with_playbook(&upstream, "site.yml", "- hosts: localhost\n  tasks: []\n");

        let cfg = ansible_config::AnsibleConfig::default();
        let res = run_pull(
            &cfg,
            Some(upstream.to_string_lossy().into_owned()),
            Some(tmp.path().join("checkout")),
            None,
            false,
            false,
            false,
            true,
            None, // playbook -> defaults to local.yml, which does not exist
            None,
            &[],
            None,
            None,
            None,
            false,
            None,
            5,
        );
        let err = res.unwrap_err().to_string();
        assert!(err.contains("could not be found"), "got: {err}");
    }

    #[test]
    fn default_pull_dir_under_home() {
        // Set HOME to a known path; the function must locate the pull dir
        // under it regardless of the host's actual hostname.
        let tmp = tempfile::tempdir().unwrap();
        let prev_home = std::env::var_os("HOME");
        // SAFETY: tests in this crate are not run in parallel against
        // process-wide env vars in any way that touches HOME today.
        std::env::set_var("HOME", tmp.path());
        let dir = default_pull_dir();
        assert!(
            dir.starts_with(tmp.path().join(".ansible").join("pull")),
            "expected pull dir under HOME, got {}",
            dir.display()
        );
        match prev_home {
            Some(v) => std::env::set_var("HOME", v),
            None => std::env::remove_var("HOME"),
        }
    }
}
