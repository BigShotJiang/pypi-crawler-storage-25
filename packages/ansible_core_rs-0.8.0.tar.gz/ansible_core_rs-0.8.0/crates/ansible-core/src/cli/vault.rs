use std::path::PathBuf;
use std::process::Command;

use anyhow::{Context, Result};

use crate::VaultAction;

/// Run vault operations.
pub fn run_vault(
    _config: &ansible_config::AnsibleConfig,
    action: VaultAction,
    vault_password_file: Option<&PathBuf>,
) -> Result<u8> {
    // Get vault password
    let password = get_vault_password(vault_password_file)?;
    let secret = ansible_vault::VaultSecret::new(password);
    let vault = ansible_vault::VaultLib::new(vec![secret.clone()]);

    match action {
        VaultAction::Encrypt { files, vault_id: _ } => {
            for file in &files {
                let content = std::fs::read(file)?;
                let encrypted = vault.encrypt(&content, &secret)?;
                std::fs::write(file, encrypted)?;
                println!("Encryption successful: {}", file.display());
            }
        }
        VaultAction::Decrypt { files } => {
            for file in &files {
                (|| -> Result<()> {
                    let content = std::fs::read_to_string(file)?;
                    let decrypted = vault.decrypt(&content)?;
                    std::fs::write(file, decrypted)?;
                    Ok(())
                })()
                .with_context(|| format!("Failed to decrypt '{}'.", file.display()))?;
                println!("Decryption successful: {}", file.display());
            }
        }
        VaultAction::View { file } => {
            let decrypted = (|| -> Result<String> {
                let content = std::fs::read_to_string(&file)?;
                Ok(vault.decrypt_str(&content)?)
            })()
            .with_context(|| format!("Failed to view '{}'.", file.display()))?;
            print!("{decrypted}");
        }
        VaultAction::Edit { file } => {
            vault_edit(&vault, &secret, &file)?;
        }
        VaultAction::Rekey {
            files,
            new_vault_password_file,
            new_vault_id: _,
        } => {
            let new_password = get_vault_password(new_vault_password_file.as_ref())?;
            let new_secret = ansible_vault::VaultSecret::new(new_password);
            let new_vault = ansible_vault::VaultLib::new(vec![new_secret.clone()]);

            for file in &files {
                (|| -> Result<()> {
                    let content = std::fs::read_to_string(file)
                        .with_context(|| format!("Failed to read '{}'", file.display()))?;
                    let plaintext = vault
                        .decrypt_str(&content)
                        .with_context(|| format!("Failed to decrypt '{}'", file.display()))?;

                    let encrypted = new_vault.encrypt(plaintext.as_bytes(), &new_secret)?;

                    // Atomic write: write to temp file in same directory, then rename
                    let dir = file.parent().unwrap_or(std::path::Path::new("."));
                    let tmp_file = tempfile::Builder::new()
                        .suffix(".vault-rekey")
                        .tempfile_in(dir)
                        .context("Failed to create temp file")?;
                    std::fs::write(tmp_file.path(), &encrypted)?;
                    tmp_file
                        .persist(file)
                        .with_context(|| format!("Failed to write '{}'", file.display()))?;

                    println!("Rekey successful: {}", file.display());
                    Ok(())
                })()
                .with_context(|| format!("Failed to rekey '{}'.", file.display()))?;
            }
        }
        VaultAction::EncryptString { string, name } => {
            let text = match string {
                Some(s) => s,
                None => {
                    let mut buf = String::new();
                    std::io::Read::read_to_string(&mut std::io::stdin(), &mut buf)?;
                    buf
                }
            };
            let encrypted = vault.encrypt(text.as_bytes(), &secret)?;
            if let Some(var_name) = name {
                println!("{var_name}: !vault |");
                for line in encrypted.lines() {
                    println!("    {line}");
                }
            } else {
                println!("{encrypted}");
            }
        }
    }

    Ok(0)
}

fn get_vault_password(vault_password_file: Option<&PathBuf>) -> Result<Vec<u8>> {
    if let Some(path) = vault_password_file {
        let password = std::fs::read_to_string(path)?;
        return Ok(password.trim().as_bytes().to_vec());
    }

    if let Ok(password) = std::env::var("ANSIBLE_VAULT_PASSWORD") {
        return Ok(password.into_bytes());
    }

    Err(anyhow::anyhow!(
        "no vault password provided. Use --vault-password-file or set ANSIBLE_VAULT_PASSWORD"
    ))
}

/// Edit a vault-encrypted file in an external editor.
///
/// Decrypts to a temp file, launches the editor, and only re-encrypts
/// and overwrites the original if the editor exits successfully.
/// On non-zero editor exit the original file is left untouched.
fn vault_edit(
    vault: &ansible_vault::VaultLib,
    secret: &ansible_vault::VaultSecret,
    file: &PathBuf,
) -> Result<()> {
    vault_edit_inner(vault, secret, file)
        .with_context(|| format!("Failed to edit '{}'.", file.display()))
}

fn vault_edit_inner(
    vault: &ansible_vault::VaultLib,
    secret: &ansible_vault::VaultSecret,
    file: &PathBuf,
) -> Result<()> {
    let content = std::fs::read_to_string(file).context("read vault file")?;
    let decrypted = vault.decrypt_str(&content).context("decrypt vault file")?;

    let dir = file.parent().unwrap_or(std::path::Path::new("."));
    let tmp_file = tempfile::Builder::new()
        .suffix(".vault-edit")
        .tempfile_in(dir)
        .context("create temp file for editor")?;
    std::fs::write(tmp_file.path(), &decrypted)?;

    let editor = std::env::var("EDITOR").unwrap_or_else(|_| "vi".to_string());

    let status = Command::new(&editor)
        .arg(tmp_file.path())
        .status()
        .with_context(|| format!("launch editor '{}'", editor))?;

    if !status.success() {
        anyhow::bail!(
            "Editor '{}' exited with status {}. Original file left unchanged.",
            editor,
            status
                .code()
                .map(|c| c.to_string())
                .unwrap_or_else(|| "unknown (signaled)".into()),
        );
    }

    let edited = std::fs::read_to_string(tmp_file.path()).context("read edited temp file")?;
    let encrypted = vault.encrypt(edited.as_bytes(), secret)?;
    std::fs::write(file, encrypted)?;

    println!("Editing successful: {}", file.display());
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    /// `vault edit` must leave the original ciphertext untouched when the
    /// editor process exits non-zero. Mirrors upstream PR ansible/ansible#86731.
    #[test]
    fn vault_edit_aborts_when_editor_exits_nonzero() {
        let secret = ansible_vault::VaultSecret::new(b"password".to_vec());
        let vault = ansible_vault::VaultLib::new(vec![secret.clone()]);
        let encrypted_original = vault
            .encrypt(b"key: value\n", &secret)
            .expect("encrypt seed plaintext");

        let dir = tempfile::tempdir().expect("create tempdir");
        let file = dir.path().join("secret.yml");
        std::fs::write(&file, &encrypted_original).expect("write seed file");

        // Stub editor that exits non-zero without touching the temp file.
        // SAFETY: tests in this crate run on a single thread (no `#[test]`
        // currently spawns threads observing EDITOR) so the env mutation is
        // local to this test.
        unsafe {
            std::env::set_var("EDITOR", "false");
        }

        let result = vault_edit(&vault, &secret, &file);
        assert!(result.is_err(), "expected vault_edit to fail on editor exit");
        let msg = format!("{:#}", result.unwrap_err());
        assert!(
            msg.starts_with(&format!("Failed to edit '{}'.", file.display())),
            "error should start with the unified 'Failed to edit' wrapper: {msg}"
        );
        assert!(
            msg.contains("Original file left unchanged"),
            "error message should signal that the file was preserved: {msg}"
        );

        let after = std::fs::read_to_string(&file).expect("re-read encrypted file");
        assert_eq!(
            after, encrypted_original,
            "ciphertext must be byte-identical after editor failure"
        );
    }

    /// `vault edit` on a non-vault file must surface the unified
    /// "Failed to edit '<file>'." wrapper, matching upstream ansible/ansible#86602.
    #[test]
    fn vault_edit_error_uses_failed_to_edit_prefix() {
        let secret = ansible_vault::VaultSecret::new(b"password".to_vec());
        let vault = ansible_vault::VaultLib::new(vec![secret.clone()]);

        let dir = tempfile::tempdir().expect("create tempdir");
        let file = dir.path().join("not-a-vault.yml");
        std::fs::write(&file, b"key: value\n").expect("write plain (non-vault) file");

        let err = vault_edit(&vault, &secret, &file)
            .expect_err("expected vault_edit to fail decrypting a non-vault file");
        let msg = format!("{:#}", err);
        assert!(
            msg.starts_with(&format!("Failed to edit '{}'.", file.display())),
            "error should start with 'Failed to edit '<file>'.': {msg}"
        );
    }
}
