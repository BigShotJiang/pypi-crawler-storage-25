use std::path::PathBuf;

use anyhow::Result;

use crate::{GalaxyAction, GalaxyCollectionAction};

/// Dispatch galaxy subcommands.
pub fn run_galaxy(action: GalaxyAction) -> Result<u8> {
    match action {
        GalaxyAction::Collection { action } => run_collection(action),
    }
}

fn run_collection(action: GalaxyCollectionAction) -> Result<u8> {
    match action {
        GalaxyCollectionAction::Install {
            collections,
            requirements,
            collections_path,
            force: _force,
            server,
        } => run_collection_install(collections, requirements, collections_path, server),
        GalaxyCollectionAction::Build { path, output_path } => {
            run_collection_build(&path, &output_path)
        }
        GalaxyCollectionAction::List {
            collections_path,
            format_json,
        } => run_collection_list(collections_path, format_json),
    }
}

/// `ansible galaxy collection install`
fn run_collection_install(
    collections: Vec<String>,
    requirements: Option<PathBuf>,
    collections_path: Option<PathBuf>,
    server: Option<String>,
) -> Result<u8> {
    use ansible_galaxy::{
        Fetcher, FilesystemFetcher, GalaxyApiFetcher, Installer, Resolver,
    };

    // Gather requirements from CLI args and/or requirements file
    let mut reqs = Vec::new();
    for spec in &collections {
        let req = parse_collection_spec(spec)?;
        reqs.push(req);
    }
    if let Some(req_file) = requirements {
        let file_reqs = parse_requirements_file(&req_file)?;
        reqs.extend(file_reqs);
    }

    if reqs.is_empty() {
        eprintln!("ERROR! You must specify at least one collection or a requirements file.");
        return Ok(1);
    }

    // Determine install path
    let install_root = collections_path.unwrap_or_else(default_collections_path);
    std::fs::create_dir_all(&install_root)?;

    println!("Starting galaxy collection install process");
    println!("Process install dependency map");

    let rt = tokio::runtime::Runtime::new()?;

    // Pick a fetcher. ANSIBLE_GALAXY_LOCAL_MIRROR keeps the air-gapped path
    // available; otherwise talk to the Galaxy v3 API at --server,
    // ANSIBLE_GALAXY_SERVER, or galaxy.ansible.com.
    let fetcher: Box<dyn Fetcher> = match std::env::var("ANSIBLE_GALAXY_LOCAL_MIRROR").ok() {
        Some(mirror_path) => Box::new(FilesystemFetcher::new(&mirror_path)),
        None => {
            let server_url = server
                .or_else(|| std::env::var("ANSIBLE_GALAXY_SERVER").ok())
                .unwrap_or_else(|| "https://galaxy.ansible.com".to_string());
            let mut api = GalaxyApiFetcher::new(&server_url);
            if let Ok(token) = std::env::var("ANSIBLE_GALAXY_SERVER_TOKEN") {
                if !token.is_empty() {
                    api = api.with_token(token);
                }
            }
            println!("Using galaxy server: {server_url}");
            Box::new(api)
        }
    };

    let plan = rt
        .block_on(async {
            let resolver = Resolver::new(fetcher.as_ref());
            resolver.resolve(&reqs).await
        })
        .map_err(|e| anyhow::anyhow!("{}", e))?;

    println!("Resolved {} collection(s) to install:", plan.entries.len());
    for entry in &plan.entries {
        println!(
            "  - {}.{} ({})",
            entry.collection.namespace, entry.collection.name, entry.version
        );
    }

    let written = rt
        .block_on(async {
            let installer = Installer::new(fetcher.as_ref(), &install_root);
            installer.install(&plan).await
        })
        .map_err(|e| anyhow::anyhow!("{}", e))?;

    for path in &written {
        println!("Installed: {}", path.display());
    }

    println!("Successfully installed {} collection(s).", written.len());
    Ok(0)
}

/// `ansible galaxy collection build`
fn run_collection_build(path: &std::path::Path, output_path: &std::path::Path) -> Result<u8> {
    // Read galaxy.yml from the source directory
    let galaxy_yml = path.join("galaxy.yml");
    if !galaxy_yml.is_file() {
        eprintln!(
            "ERROR! The collection galaxy.yml path '{}' does not exist.",
            galaxy_yml.display()
        );
        return Ok(1);
    }

    let content = std::fs::read_to_string(&galaxy_yml)?;
    let manifest: serde_json::Value = serde_yaml::from_str(&content)
        .map_err(|e| anyhow::anyhow!("Failed to parse galaxy.yml: {}", e))?;

    let namespace = manifest
        .get("namespace")
        .and_then(|v| v.as_str())
        .ok_or_else(|| anyhow::anyhow!("galaxy.yml missing 'namespace'"))?;
    let name = manifest
        .get("name")
        .and_then(|v| v.as_str())
        .ok_or_else(|| anyhow::anyhow!("galaxy.yml missing 'name'"))?;
    let version = manifest
        .get("version")
        .and_then(|v| v.as_str())
        .ok_or_else(|| anyhow::anyhow!("galaxy.yml missing 'version'"))?;

    let tarball_name = format!("{namespace}-{name}-{version}.tar.gz");
    let tarball_path = output_path.join(&tarball_name);

    println!("Created collection for {namespace}.{name} at {}", tarball_path.display());

    // Collect all files+dirs, sorted by relative path in ASCII (byte) order so
    // successive builds of the same source tree produce byte-identical archives.
    // Mirrors the upstream behaviour added in ansible/ansible#86770: `FILES.json`
    // entries are sorted by name.
    let mut entries = collect_collection_entries(path)?;
    entries.sort_by(|a, b| a.rel_path.as_bytes().cmp(b.rel_path.as_bytes()));

    // Build FILES.json with sorted entries + sha256 checksums.
    let files_json = build_files_json(&entries)?;
    let files_bytes = serde_json::to_vec_pretty(&files_json)?;

    // Build MANIFEST.json, including the FILES.json checksum so consumers can
    // verify the file manifest separately (matching upstream's shape).
    let files_chksum = sha256_hex(&files_bytes);
    let manifest_json = serde_json::json!({
        "collection_info": {
            "namespace": namespace,
            "name": name,
            "version": version,
            "dependencies": manifest.get("dependencies").cloned().unwrap_or(serde_json::json!({})),
        },
        "file_manifest_file": {
            "name": "FILES.json",
            "ftype": "file",
            "chksum_type": "sha256",
            "chksum_sha256": files_chksum,
            "format": 1,
        },
        "format": 1,
    });
    let manifest_bytes = serde_json::to_vec_pretty(&manifest_json)?;

    // Create tarball
    use flate2::write::GzEncoder;
    use flate2::Compression;
    use std::io::Write;

    let tar_file = std::fs::File::create(&tarball_path)?;
    let enc = GzEncoder::new(tar_file, Compression::default());
    let mut tar_builder = tar::Builder::new(enc);

    append_deterministic(&mut tar_builder, "MANIFEST.json", &manifest_bytes, 0o644)?;
    append_deterministic(&mut tar_builder, "FILES.json", &files_bytes, 0o644)?;

    // Walk in the same sorted order used for FILES.json so tar entry order is
    // also deterministic.
    for entry in &entries {
        if entry.is_dir {
            // Directories are recorded in FILES.json but tar doesn't strictly
            // need explicit dir entries; skip to keep the archive minimal and
            // match upstream's tarball contents (files only).
            continue;
        }
        let bytes = std::fs::read(&entry.abs_path)?;
        append_deterministic(&mut tar_builder, &entry.rel_path, &bytes, 0o644)?;
    }

    tar_builder.finish()?;
    let mut enc = tar_builder.into_inner()?;
    enc.flush()?;
    enc.finish()?;

    println!("To install the collection, run:");
    println!("    ansible galaxy collection install {}", tarball_path.display());

    Ok(0)
}

/// One file or directory included in the collection tarball.
struct CollectionEntry {
    /// Path inside the tarball, forward-slash separated.
    rel_path: String,
    abs_path: std::path::PathBuf,
    is_dir: bool,
}

/// Walk `root`, returning every regular file and directory we want to ship.
/// Skips dotfiles, `__pycache__`, and `.pyc` so the output matches what the
/// previous tar walker produced.
fn collect_collection_entries(root: &std::path::Path) -> Result<Vec<CollectionEntry>> {
    let mut out = Vec::new();
    walk(root, root, &mut out)?;
    return Ok(out);

    fn walk(
        base: &std::path::Path,
        dir: &std::path::Path,
        out: &mut Vec<CollectionEntry>,
    ) -> Result<()> {
        for entry in std::fs::read_dir(dir)?.flatten() {
            let p = entry.path();
            let name = match p.file_name().and_then(|n| n.to_str()) {
                Some(n) => n,
                None => continue,
            };
            if name.starts_with('.') || name == "__pycache__" || name.ends_with(".pyc") {
                continue;
            }
            let rel = p.strip_prefix(base).unwrap_or(&p);
            // Always emit forward-slashes so archives built on Windows match
            // those built on Unix.
            let rel_str = rel
                .components()
                .map(|c| c.as_os_str().to_string_lossy().into_owned())
                .collect::<Vec<_>>()
                .join("/");
            if p.is_dir() {
                out.push(CollectionEntry {
                    rel_path: rel_str,
                    abs_path: p.clone(),
                    is_dir: true,
                });
                walk(base, &p, out)?;
            } else if p.is_file() {
                out.push(CollectionEntry {
                    rel_path: rel_str,
                    abs_path: p,
                    is_dir: false,
                });
            }
        }
        Ok(())
    }
}

/// Build a `FILES.json` value matching the upstream Galaxy shape.
fn build_files_json(entries: &[CollectionEntry]) -> Result<serde_json::Value> {
    let mut files = Vec::with_capacity(entries.len() + 1);
    // The collection root itself is always recorded as the first entry.
    files.push(serde_json::json!({
        "name": ".",
        "ftype": "dir",
        "chksum_type": null,
        "chksum_sha256": null,
        "format": 1,
    }));
    for e in entries {
        if e.is_dir {
            files.push(serde_json::json!({
                "name": e.rel_path,
                "ftype": "dir",
                "chksum_type": null,
                "chksum_sha256": null,
                "format": 1,
            }));
        } else {
            let bytes = std::fs::read(&e.abs_path)?;
            files.push(serde_json::json!({
                "name": e.rel_path,
                "ftype": "file",
                "chksum_type": "sha256",
                "chksum_sha256": sha256_hex(&bytes),
                "format": 1,
            }));
        }
    }
    Ok(serde_json::json!({
        "files": files,
        "format": 1,
    }))
}

fn sha256_hex(bytes: &[u8]) -> String {
    use sha2::{Digest, Sha256};
    let mut hasher = Sha256::new();
    hasher.update(bytes);
    let digest = hasher.finalize();
    let mut s = String::with_capacity(digest.len() * 2);
    for b in digest {
        use std::fmt::Write;
        let _ = write!(&mut s, "{b:02x}");
    }
    s
}

/// Write a single file entry to the archive with deterministic metadata
/// (mtime=0, uid=0, gid=0, no username/groupname). Reproducible builds depend
/// on these all being fixed.
fn append_deterministic<W: std::io::Write>(
    builder: &mut tar::Builder<W>,
    name: &str,
    data: &[u8],
    mode: u32,
) -> Result<()> {
    let mut header = tar::Header::new_gnu();
    header.set_path(name)?;
    header.set_size(data.len() as u64);
    header.set_mode(mode);
    header.set_mtime(0);
    header.set_uid(0);
    header.set_gid(0);
    header.set_entry_type(tar::EntryType::Regular);
    header.set_cksum();
    builder.append(&header, data)?;
    Ok(())
}

/// `ansible galaxy collection list`
fn run_collection_list(
    collections_path: Option<PathBuf>,
    format_json: bool,
) -> Result<u8> {
    let roots = match collections_path {
        Some(p) => vec![p],
        None => {
            let mut paths = Vec::new();
            if let Some(home) = std::env::var_os("HOME") {
                paths.push(PathBuf::from(home).join(".ansible/collections"));
            }
            paths.push(PathBuf::from("/usr/share/ansible/collections"));
            paths
        }
    };

    let mut found: Vec<(String, String, String)> = Vec::new(); // (namespace, name, version)

    for root in &roots {
        let ac_dir = root.join("ansible_collections");
        if !ac_dir.is_dir() {
            continue;
        }
        let Ok(ns_entries) = std::fs::read_dir(&ac_dir) else {
            continue;
        };
        for ns_entry in ns_entries.flatten() {
            if !ns_entry.path().is_dir() {
                continue;
            }
            let namespace = ns_entry.file_name().to_string_lossy().to_string();
            let Ok(col_entries) = std::fs::read_dir(ns_entry.path()) else {
                continue;
            };
            for col_entry in col_entries.flatten() {
                if !col_entry.path().is_dir() {
                    continue;
                }
                let name = col_entry.file_name().to_string_lossy().to_string();
                // Try to read version from MANIFEST.json or galaxy.yml
                let version = read_installed_version(&col_entry.path());
                found.push((namespace.clone(), name, version));
            }
        }
    }

    if format_json {
        let json: serde_json::Value = found
            .iter()
            .map(|(ns, name, ver)| {
                serde_json::json!({
                    "fqcn": format!("{ns}.{name}"),
                    "version": ver,
                })
            })
            .collect();
        println!("{}", serde_json::to_string_pretty(&json)?);
    } else {
        if found.is_empty() {
            println!("No collections found.");
        } else {
            println!("# {:<40} Version", "Collection");
            println!("# {:<40} -------", "----------");
            for (ns, name, ver) in &found {
                println!("{ns}.{name:<38} {ver}");
            }
        }
    }

    Ok(0)
}

// ---- Helpers ----

/// Parse `namespace.name` or `namespace.name:>=1.0` from CLI args.
fn parse_collection_spec(spec: &str) -> Result<ansible_galaxy::CollectionRequirement> {
    if let Some((name, version)) = spec.split_once(':') {
        ansible_galaxy::CollectionRequirement::new(name, version)
            .map_err(|e| anyhow::anyhow!("{}", e))
    } else {
        ansible_galaxy::CollectionRequirement::any(spec)
            .map_err(|e| anyhow::anyhow!("{}", e))
    }
}

/// Parse a `requirements.yml` file into collection requirements.
fn parse_requirements_file(path: &PathBuf) -> Result<Vec<ansible_galaxy::CollectionRequirement>> {
    let content = std::fs::read_to_string(path)
        .map_err(|e| anyhow::anyhow!("Failed to read requirements file '{}': {}", path.display(), e))?;

    let doc: serde_json::Value = serde_yaml::from_str(&content)
        .map_err(|e| anyhow::anyhow!("Failed to parse requirements file: {}", e))?;

    let mut reqs = Vec::new();

    // Format 1: { collections: [ {name: "ns.col", version: ">=1.0"}, ... ] }
    // Format 2: [ {name: "ns.col", version: ">=1.0"}, ... ]
    let items = if let Some(collections) = doc.get("collections").and_then(|v| v.as_array()) {
        collections.clone()
    } else if let Some(arr) = doc.as_array() {
        arr.clone()
    } else {
        return Err(anyhow::anyhow!(
            "requirements.yml must contain a 'collections' list or be a list of collections"
        ));
    };

    for item in &items {
        if let Some(name) = item.as_str() {
            // Simple string form: "namespace.name"
            reqs.push(
                ansible_galaxy::CollectionRequirement::any(name)
                    .map_err(|e| anyhow::anyhow!("{}", e))?,
            );
        } else if let Some(obj) = item.as_object() {
            let name = obj
                .get("name")
                .and_then(|v| v.as_str())
                .ok_or_else(|| anyhow::anyhow!("Collection entry missing 'name'"))?;
            let version = obj
                .get("version")
                .and_then(|v| v.as_str())
                .unwrap_or("*");
            reqs.push(
                ansible_galaxy::CollectionRequirement::new(name, version)
                    .map_err(|e| anyhow::anyhow!("{}", e))?,
            );
        }
    }

    Ok(reqs)
}

/// Read the version of an installed collection from MANIFEST.json or galaxy.yml.
fn read_installed_version(col_path: &std::path::Path) -> String {
    // Try MANIFEST.json first
    let manifest_path = col_path.join("MANIFEST.json");
    if manifest_path.is_file() {
        if let Ok(content) = std::fs::read_to_string(&manifest_path) {
            if let Ok(manifest) = ansible_galaxy::parse_manifest(&content) {
                return manifest.version;
            }
        }
    }
    // Try galaxy.yml
    let galaxy_path = col_path.join("galaxy.yml");
    if galaxy_path.is_file() {
        if let Ok(content) = std::fs::read_to_string(&galaxy_path) {
            if let Ok(doc) = serde_yaml::from_str::<serde_json::Value>(&content) {
                if let Some(v) = doc.get("version").and_then(|v| v.as_str()) {
                    return v.to_string();
                }
            }
        }
    }
    "*".to_string()
}

/// Default collections install path.
fn default_collections_path() -> PathBuf {
    if let Some(home) = std::env::var_os("HOME") {
        PathBuf::from(home).join(".ansible/collections")
    } else {
        PathBuf::from("/usr/share/ansible/collections")
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;

    fn write(p: &std::path::Path, body: &str) {
        if let Some(parent) = p.parent() {
            fs::create_dir_all(parent).unwrap();
        }
        fs::write(p, body).unwrap();
    }

    fn make_fixture(root: &std::path::Path) {
        write(
            &root.join("galaxy.yml"),
            "namespace: ns\nname: col\nversion: 1.0.0\n",
        );
        // Names chosen so directory-iteration order is unlikely to match the
        // sorted order on its own.
        write(&root.join("plugins/modules/zeta.py"), "z\n");
        write(&root.join("plugins/modules/alpha.py"), "a\n");
        write(&root.join("README.md"), "readme\n");
        // Things that should be excluded from the build.
        write(&root.join(".git/HEAD"), "ignored\n");
        write(&root.join("plugins/__pycache__/x.cpython.pyc"), "ignored\n");
        write(&root.join("foo.pyc"), "ignored\n");
    }

    fn read_archive_member(tarball: &std::path::Path, member: &str) -> Vec<u8> {
        use std::io::Read;
        let f = fs::File::open(tarball).unwrap();
        let dec = flate2::read::GzDecoder::new(f);
        let mut ar = tar::Archive::new(dec);
        for entry in ar.entries().unwrap() {
            let mut e = entry.unwrap();
            if e.path().unwrap().to_string_lossy() == member {
                let mut buf = Vec::new();
                e.read_to_end(&mut buf).unwrap();
                return buf;
            }
        }
        panic!("member {member} not in archive");
    }

    #[test]
    fn collection_build_files_json_is_sorted() {
        let src = tempfile::tempdir().unwrap();
        let out = tempfile::tempdir().unwrap();
        make_fixture(src.path());

        run_collection_build(src.path(), out.path()).unwrap();
        let tarball = out.path().join("ns-col-1.0.0.tar.gz");
        assert!(tarball.is_file());

        let files_json: serde_json::Value =
            serde_json::from_slice(&read_archive_member(&tarball, "FILES.json")).unwrap();
        let names: Vec<&str> = files_json["files"]
            .as_array()
            .unwrap()
            .iter()
            .map(|v| v["name"].as_str().unwrap())
            .collect();

        // First entry is always the collection root.
        assert_eq!(names[0], ".");
        // Remaining entries must be in ASCII byte-order.
        let rest: Vec<&str> = names.iter().skip(1).copied().collect();
        let mut sorted = rest.clone();
        sorted.sort_by(|a, b| a.as_bytes().cmp(b.as_bytes()));
        assert_eq!(rest, sorted, "FILES.json entries are not sorted");

        // Excluded paths must not show up.
        assert!(!names.iter().any(|n| n.starts_with(".git")));
        assert!(!names.iter().any(|n| n.contains("__pycache__")));
        assert!(!names.iter().any(|n| n.ends_with(".pyc")));
    }

    #[test]
    fn collection_build_is_reproducible() {
        let src = tempfile::tempdir().unwrap();
        let out_a = tempfile::tempdir().unwrap();
        let out_b = tempfile::tempdir().unwrap();
        make_fixture(src.path());

        run_collection_build(src.path(), out_a.path()).unwrap();
        run_collection_build(src.path(), out_b.path()).unwrap();

        let bytes_a = fs::read(out_a.path().join("ns-col-1.0.0.tar.gz")).unwrap();
        let bytes_b = fs::read(out_b.path().join("ns-col-1.0.0.tar.gz")).unwrap();
        assert_eq!(
            bytes_a, bytes_b,
            "two builds of the same source produced different tarballs"
        );
    }
}
