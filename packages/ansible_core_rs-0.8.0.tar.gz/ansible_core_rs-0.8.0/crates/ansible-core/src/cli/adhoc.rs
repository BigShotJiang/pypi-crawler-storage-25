use std::collections::HashMap;
use std::path::PathBuf;
use std::sync::Arc;

use anyhow::Result;

use ansible_executor::task_executor::TaskExecutor;
use ansible_inventory::{resolve_pattern, InventoryManager};
use ansible_playbook::Task;
use ansible_plugins::callback::CallbackRegistry;
use ansible_plugins::CallbackPlugin;
use ansible_utils::{AggregateStats, AnsibleValue};
use ansible_vars::VariableManager;

/// Run an ad-hoc command against matched hosts.
///
/// This is the `ansible <host-pattern> -m <module> -a <args>` path.
#[allow(clippy::too_many_arguments)]
pub fn run_adhoc(
    config: &ansible_config::AnsibleConfig,
    pattern: &str,
    module: &str,
    module_args: Option<&str>,
    inventory_source: Option<&str>,
    forks: usize,
    extra_vars: &[(String, AnsibleValue)],
    use_become: bool,
    become_method: &str,
    become_user: &str,
    cli_remote_user: Option<&str>,
) -> Result<u8> {
    // Set up inventory
    let mut inventory = InventoryManager::new();
    if let Some(inv_src) = inventory_source {
        inventory.add_source(PathBuf::from(inv_src));
        inventory.parse_sources().map_err(|e| {
            anyhow::anyhow!("failed to parse inventory '{}': {}", inv_src, e)
        })?;
    }
    let inventory = Arc::new(inventory);

    // Set up variable manager
    let mut variable_manager = VariableManager::new(inventory.clone());
    if !extra_vars.is_empty() {
        let mut ev = HashMap::new();
        for (k, v) in extra_vars {
            ev.insert(k.clone(), v.clone());
        }
        variable_manager.set_extra_vars(ev);
    }
    variable_manager.set_cli_remote_user(cli_remote_user.map(|s| s.to_string()));
    variable_manager.set_config_remote_user(config.defaults.remote_user.clone());
    let variable_manager = Arc::new(variable_manager);

    // Resolve hosts from pattern
    let hosts = resolve_pattern(pattern, inventory.data());
    if hosts.is_empty() {
        eprintln!(
            "[WARNING]: No hosts matched, nothing to do"
        );
        return Ok(0);
    }

    // Build the module args
    let args_value: AnsibleValue = if let Some(args_str) = module_args {
        // Try to parse as key=value pairs first, fall back to _raw_params
        if args_str.contains('=') && !args_str.starts_with('{') {
            let mut map = serde_json::Map::new();
            for part in shell_words(args_str) {
                if let Some((k, v)) = part.split_once('=') {
                    map.insert(k.to_string(), AnsibleValue::String(v.to_string()));
                } else {
                    // Free-form argument
                    map.insert("_raw_params".to_string(), AnsibleValue::String(part));
                }
            }
            AnsibleValue::Object(map)
        } else {
            // Treat as free-form (command/shell module style)
            serde_json::json!({"_raw_params": args_str})
        }
    } else {
        serde_json::json!({})
    };

    // Build the task
    let mut action = HashMap::new();
    action.insert(module.to_string(), args_value);

    let task = Task {
        name: Some(module.to_string()),
        action,
        when_conditions: Vec::new(),
        register: None,
        loop_source: None,
        loop_items: None,
        with_items: None,
        loop_control: None,
        notify: Vec::new(),
        tags: Default::default(),
        use_become: if use_become { Some(true) } else { None },
        become_user: if use_become { Some(become_user.to_string()) } else { None },
        become_method: if use_become { Some(become_method.to_string()) } else { None },
        become_flags: None,
        become_pass: None,
        delegate_to: None,
        ignore_errors: false,
        run_once: false,
        changed_when: Vec::new(),
        failed_when: Vec::new(),
        retries: 3,
        delay: 5,
        until: Vec::new(),
        no_log: false,
        args: None,
        environment: None,
        vars: None,
        block: None,
        rescue: None,
        always: None,
        connection: None,
        timeout: None,
        check_mode: None,
    };

    // Set up callback registry from `[defaults] stdout_callback`. The
    // registry is the single dispatch point so additional callbacks can be
    // wired in without touching CLI code.
    let callback = CallbackRegistry::from_config(
        &config.defaults.stdout_callback,
        &[],
    );

    // Set up stats
    let mut stats = AggregateStats::new();

    // Create the async runtime
    let rt = tokio::runtime::Runtime::new()?;

    let mut exit_code: u8 = 0;

    // Run the task on each host (using forks for parallelism)
    let results = rt.block_on(async {
        let semaphore = Arc::new(tokio::sync::Semaphore::new(forks));
        let mut handles = Vec::new();

        for host in &hosts {
            let host = host.clone();
            let task = task.clone();
            let vm = variable_manager.clone();
            let sem = semaphore.clone();

            handles.push(tokio::spawn(async move {
                let _permit = sem.acquire().await.unwrap();
                let executor = TaskExecutor::new(host.clone(), task, vm);
                let result = executor.run().await;
                (host, result)
            }));
        }

        let mut results = Vec::new();
        for handle in handles {
            if let Ok(r) = handle.await {
                results.push(r);
            }
        }
        results
    });

    // Process and display results
    for (host, result) in &results {
        match result {
            Ok(task_result) => {
                let result_val = serde_json::to_value(task_result)
                    .unwrap_or(serde_json::Value::Null);

                if task_result.unreachable {
                    callback.v2_runner_on_unreachable(host, &result_val);
                    stats.record_unreachable(host);
                    exit_code = 4;
                } else if task_result.failed {
                    callback.v2_runner_on_failed(host, &result_val, false);
                    stats.record(host, false, true, false);
                    if exit_code < 2 {
                        exit_code = 2;
                    }
                } else if task_result.skipped {
                    callback.v2_runner_on_skipped(host, &result_val);
                    stats.record(host, false, false, true);
                } else {
                    callback.v2_runner_on_ok(host, &result_val);
                    stats.record(host, task_result.changed, false, false);
                }
            }
            Err(e) => {
                eprintln!("{host} | FAILED! => {e}");
                stats.record(host, false, true, false);
                if exit_code < 2 {
                    exit_code = 2;
                }
            }
        }
    }

    // Hand the recap to the callback registry so the chosen stdout callback
    // controls the format (default prints PLAY RECAP, json prints a JSON
    // document, etc.).
    let stats_val = serde_json::to_value(&stats).unwrap_or(serde_json::Value::Null);
    callback.v2_playbook_on_stats(&stats_val);

    Ok(exit_code)
}

/// Minimal shell-like word splitting for module args.
/// Splits on whitespace but respects single and double quotes.
fn shell_words(s: &str) -> Vec<String> {
    let mut words = Vec::new();
    let mut current = String::new();
    let mut in_single = false;
    let mut in_double = false;

    for ch in s.chars() {
        match ch {
            '\'' if !in_double => {
                in_single = !in_single;
            }
            '"' if !in_single => {
                in_double = !in_double;
            }
            ' ' | '\t' if !in_single && !in_double => {
                if !current.is_empty() {
                    words.push(std::mem::take(&mut current));
                }
            }
            _ => current.push(ch),
        }
    }
    if !current.is_empty() {
        words.push(current);
    }
    words
}
