//! `ansible-doc` — print plugin/module documentation.
//!
//! Initial implementation covers the natively-handled modules in
//! `ansible-executor::task_executor` plus the plugin types that have a
//! native registry (`callback`, `connection`, `become`, `shell`, `lookup`,
//! `action`). Documentation is held in a static catalog rather than
//! extracted from source — when a new module is added natively, add an
//! entry to `MODULE_DOCS` so `ansible-doc` keeps in sync.

use anyhow::Result;

/// One option for a module/plugin.
struct OptionDoc {
    name: &'static str,
    description: &'static str,
    required: bool,
    default: Option<&'static str>,
}

/// One module or plugin documentation record.
struct PluginDoc {
    name: &'static str,
    short_description: &'static str,
    description: &'static str,
    options: &'static [OptionDoc],
    example: &'static str,
}

const MODULE_DOCS: &[PluginDoc] = &[
    PluginDoc {
        name: "command",
        short_description: "Execute commands on targets",
        description: "Runs a command on a remote host. Does not pass through a shell, so variable expansion and pipes are not supported. Use `shell` for those.",
        options: &[
            OptionDoc { name: "cmd", description: "The command to run.", required: true, default: None },
            OptionDoc { name: "chdir", description: "Change into this directory before running the command.", required: false, default: None },
            OptionDoc { name: "creates", description: "Skip the task if this path exists.", required: false, default: None },
            OptionDoc { name: "removes", description: "Skip the task if this path does not exist.", required: false, default: None },
        ],
        example: "- name: Run uptime\n  command: uptime",
    },
    PluginDoc {
        name: "shell",
        short_description: "Execute shell commands on targets",
        description: "Runs the command through the remote user's shell, so pipes, redirection, and variable expansion work.",
        options: &[
            OptionDoc { name: "cmd", description: "The shell command to run.", required: true, default: None },
            OptionDoc { name: "chdir", description: "Change into this directory before running.", required: false, default: None },
            OptionDoc { name: "executable", description: "Shell to invoke (default /bin/sh).", required: false, default: Some("/bin/sh") },
        ],
        example: "- name: Count lines\n  shell: \"wc -l < /var/log/syslog\"",
    },
    PluginDoc {
        name: "raw",
        short_description: "Run a low-level command without going through the module subsystem",
        description: "Sends the command directly over the connection. Useful for hosts without Python or for early bootstrap steps.",
        options: &[
            OptionDoc { name: "cmd", description: "The command to send.", required: true, default: None },
        ],
        example: "- name: Bootstrap python\n  raw: apt-get -y install python3",
    },
    PluginDoc {
        name: "debug",
        short_description: "Print statements during execution",
        description: "Prints messages or evaluated variables. No-op on remote hosts.",
        options: &[
            OptionDoc { name: "msg", description: "String message to print.", required: false, default: Some("Hello world!") },
            OptionDoc { name: "var", description: "Name of a variable to dump.", required: false, default: None },
            OptionDoc { name: "verbosity", description: "Minimum verbosity (-v count) to print.", required: false, default: Some("0") },
        ],
        example: "- debug:\n    msg: \"hello {{ inventory_hostname }}\"",
    },
    PluginDoc {
        name: "set_fact",
        short_description: "Set host-scoped facts at runtime",
        description: "Sets one or more variables on the current host that persist for the rest of the play.",
        options: &[
            OptionDoc { name: "<key>", description: "Any key/value pair becomes a host fact.", required: true, default: None },
            OptionDoc { name: "cacheable", description: "Persist the fact to the fact cache.", required: false, default: Some("false") },
        ],
        example: "- set_fact:\n    deploy_ts: \"{{ lookup('pipe','date +%s') }}\"",
    },
    PluginDoc {
        name: "assert",
        short_description: "Assert that one or more conditions are true",
        description: "Fails the task if any expression in `that` evaluates falsy.",
        options: &[
            OptionDoc { name: "that", description: "List of expressions; all must be truthy.", required: true, default: None },
            OptionDoc { name: "fail_msg", description: "Message used on failure.", required: false, default: None },
            OptionDoc { name: "success_msg", description: "Message used on success.", required: false, default: None },
        ],
        example: "- assert:\n    that:\n      - ansible_distribution == 'Debian'",
    },
    PluginDoc {
        name: "fail",
        short_description: "Fail the play with a custom message",
        description: "Halts the current host with an error.",
        options: &[
            OptionDoc { name: "msg", description: "Error message.", required: false, default: Some("Failed as requested from task") },
        ],
        example: "- fail:\n    msg: \"unsupported distro\"",
    },
    PluginDoc {
        name: "meta",
        short_description: "Execute Ansible meta actions",
        description: "Special action that affects play behavior. Common values: `flush_handlers`, `clear_facts`, `end_play`, `noop`, `refresh_inventory`, `reset_connection`.",
        options: &[
            OptionDoc { name: "free-form", description: "The meta keyword (e.g. flush_handlers).", required: true, default: None },
        ],
        example: "- meta: flush_handlers",
    },
    PluginDoc {
        name: "file",
        short_description: "Manage files and file properties",
        description: "Create, remove, or change attributes of files, directories, and symlinks.",
        options: &[
            OptionDoc { name: "path", description: "Target path.", required: true, default: None },
            OptionDoc { name: "state", description: "One of: file, directory, link, hard, touch, absent.", required: false, default: Some("file") },
            OptionDoc { name: "mode", description: "Permission mode (octal string or symbolic).", required: false, default: None },
            OptionDoc { name: "owner", description: "User the file should belong to.", required: false, default: None },
            OptionDoc { name: "group", description: "Group the file should belong to.", required: false, default: None },
            OptionDoc { name: "src", description: "Source for `link` and `hard` states.", required: false, default: None },
        ],
        example: "- file:\n    path: /var/log/myapp\n    state: directory\n    mode: \"0750\"",
    },
    PluginDoc {
        name: "copy",
        short_description: "Copy files to remote locations",
        description: "Copy a file from the controller (or in-line content) to a remote host.",
        options: &[
            OptionDoc { name: "src", description: "Local file or directory to copy.", required: false, default: None },
            OptionDoc { name: "content", description: "Inline content to write at `dest`.", required: false, default: None },
            OptionDoc { name: "dest", description: "Remote destination path.", required: true, default: None },
            OptionDoc { name: "mode", description: "File mode for the destination.", required: false, default: None },
            OptionDoc { name: "owner", description: "Owner of the destination.", required: false, default: None },
            OptionDoc { name: "group", description: "Group of the destination.", required: false, default: None },
            OptionDoc { name: "backup", description: "Create a timestamped backup of the destination.", required: false, default: Some("false") },
        ],
        example: "- copy:\n    src: nginx.conf\n    dest: /etc/nginx/nginx.conf\n    mode: \"0644\"",
    },
    PluginDoc {
        name: "template",
        short_description: "Render a Jinja2 template to a remote file",
        description: "Render `src` as a Jinja2 template against the host's variables and write it to `dest`.",
        options: &[
            OptionDoc { name: "src", description: "Template path under role `templates/` or absolute.", required: true, default: None },
            OptionDoc { name: "dest", description: "Destination path on the remote host.", required: true, default: None },
            OptionDoc { name: "mode", description: "File mode.", required: false, default: None },
            OptionDoc { name: "owner", description: "Owner.", required: false, default: None },
            OptionDoc { name: "group", description: "Group.", required: false, default: None },
        ],
        example: "- template:\n    src: app.conf.j2\n    dest: /etc/app.conf",
    },
    PluginDoc {
        name: "stat",
        short_description: "Retrieve file or filesystem status",
        description: "Returns metadata about a path (existence, mode, ownership, sha checksums, link target).",
        options: &[
            OptionDoc { name: "path", description: "Path to inspect.", required: true, default: None },
            OptionDoc { name: "follow", description: "Follow symlinks.", required: false, default: Some("false") },
            OptionDoc { name: "checksum_algorithm", description: "Hash algorithm for checksum.", required: false, default: Some("sha1") },
        ],
        example: "- stat:\n    path: /etc/passwd\n  register: passwd_stat",
    },
    PluginDoc {
        name: "lineinfile",
        short_description: "Ensure a single line is present (or absent) in a file",
        description: "Edits a file in place, adding, removing, or replacing a line matched by regex.",
        options: &[
            OptionDoc { name: "path", description: "File to edit.", required: true, default: None },
            OptionDoc { name: "line", description: "Line to ensure is present.", required: false, default: None },
            OptionDoc { name: "regexp", description: "Regex to match.", required: false, default: None },
            OptionDoc { name: "state", description: "present or absent.", required: false, default: Some("present") },
            OptionDoc { name: "create", description: "Create the file if missing.", required: false, default: Some("false") },
        ],
        example: "- lineinfile:\n    path: /etc/hosts\n    line: \"10.0.0.1 db.internal\"",
    },
    PluginDoc {
        name: "blockinfile",
        short_description: "Insert/remove a marked block in a file",
        description: "Inserts a multi-line block delimited by markers, idempotently.",
        options: &[
            OptionDoc { name: "path", description: "File to edit.", required: true, default: None },
            OptionDoc { name: "block", description: "Block content.", required: false, default: None },
            OptionDoc { name: "marker", description: "Marker template (use {mark}).", required: false, default: Some("# {mark} ANSIBLE MANAGED BLOCK") },
            OptionDoc { name: "state", description: "present or absent.", required: false, default: Some("present") },
        ],
        example: "- blockinfile:\n    path: /etc/ssh/sshd_config\n    block: |\n      Match User deploy\n        AllowTcpForwarding yes",
    },
    PluginDoc {
        name: "replace",
        short_description: "Replace all occurrences of a regex match",
        description: "Search and replace across a file. Unlike `lineinfile`, all matches are substituted.",
        options: &[
            OptionDoc { name: "path", description: "File to edit.", required: true, default: None },
            OptionDoc { name: "regexp", description: "Regex to match.", required: true, default: None },
            OptionDoc { name: "replace", description: "Replacement string.", required: false, default: None },
        ],
        example: "- replace:\n    path: /etc/motd\n    regexp: '^Welcome.*'\n    replace: 'Welcome to {{ inventory_hostname }}'",
    },
    PluginDoc {
        name: "uri",
        short_description: "Interact with HTTP/HTTPS endpoints",
        description: "Issue an HTTP request and capture the response. Mirrors `ansible.builtin.uri`.",
        options: &[
            OptionDoc { name: "url", description: "Target URL.", required: true, default: None },
            OptionDoc { name: "method", description: "HTTP method (GET, POST, …).", required: false, default: Some("GET") },
            OptionDoc { name: "body", description: "Request body.", required: false, default: None },
            OptionDoc { name: "body_format", description: "raw, json, or form-urlencoded.", required: false, default: Some("raw") },
            OptionDoc { name: "headers", description: "Map of additional headers.", required: false, default: None },
            OptionDoc { name: "status_code", description: "Acceptable response codes.", required: false, default: Some("[200]") },
        ],
        example: "- uri:\n    url: https://api.example.com/health\n    status_code: [200]",
    },
    PluginDoc {
        name: "get_url",
        short_description: "Download a file from a URL",
        description: "Download `url` to `dest`. Optional checksum verification.",
        options: &[
            OptionDoc { name: "url", description: "Source URL.", required: true, default: None },
            OptionDoc { name: "dest", description: "Path on the remote host.", required: true, default: None },
            OptionDoc { name: "mode", description: "Permission mode.", required: false, default: None },
            OptionDoc { name: "checksum", description: "<algo>:<hex> to verify the download.", required: false, default: None },
        ],
        example: "- get_url:\n    url: https://example.com/foo.tar.gz\n    dest: /tmp/foo.tar.gz",
    },
    PluginDoc {
        name: "wait_for_connection",
        short_description: "Wait until the remote becomes reachable",
        description: "Polls the connection until `ping` succeeds or the timeout elapses.",
        options: &[
            OptionDoc { name: "timeout", description: "Total seconds to wait.", required: false, default: Some("600") },
            OptionDoc { name: "delay", description: "Seconds to wait before the first poll.", required: false, default: Some("0") },
            OptionDoc { name: "sleep", description: "Seconds between attempts.", required: false, default: Some("1") },
        ],
        example: "- wait_for_connection:\n    delay: 5\n    timeout: 120",
    },
    PluginDoc {
        name: "ping",
        short_description: "Verify the connection works",
        description: "Returns `pong` (or echoes `data`) if the remote is reachable.",
        options: &[
            OptionDoc { name: "data", description: "String to echo back instead of `pong`.", required: false, default: Some("pong") },
        ],
        example: "- ping:",
    },
    PluginDoc {
        name: "slurp",
        short_description: "Slurp a file from a remote host (base64-encoded)",
        description: "Reads a remote file and returns its base64-encoded contents.",
        options: &[
            OptionDoc { name: "src", description: "Remote file to read.", required: true, default: None },
        ],
        example: "- slurp:\n    src: /etc/issue\n  register: issue",
    },
    PluginDoc {
        name: "setup",
        short_description: "Gather facts about remote hosts",
        description: "Collects host facts (hardware, network, OS, packages). Run automatically at the start of a play unless `gather_facts: no`.",
        options: &[
            OptionDoc { name: "gather_subset", description: "Subset(s) to collect (all, min, hardware, network, virtual, …).", required: false, default: Some("all") },
            OptionDoc { name: "gather_timeout", description: "Per-subset timeout in seconds.", required: false, default: Some("10") },
            OptionDoc { name: "filter", description: "Glob to filter returned facts.", required: false, default: None },
        ],
        example: "- setup:\n    gather_subset:\n      - network",
    },
    PluginDoc {
        name: "include_role",
        short_description: "Include and run a role dynamically",
        description: "Runs a role mid-play. Conditionals and loops apply to the include itself.",
        options: &[
            OptionDoc { name: "name", description: "Role name.", required: true, default: None },
            OptionDoc { name: "tasks_from", description: "Override tasks file.", required: false, default: Some("main.yml") },
            OptionDoc { name: "vars_from", description: "Override vars file.", required: false, default: Some("main.yml") },
        ],
        example: "- include_role:\n    name: webserver",
    },
    PluginDoc {
        name: "import_role",
        short_description: "Statically import a role at parse time",
        description: "Like `include_role` but resolved when the playbook is parsed (no per-task loops).",
        options: &[
            OptionDoc { name: "name", description: "Role name.", required: true, default: None },
        ],
        example: "- import_role:\n    name: common",
    },
    PluginDoc {
        name: "include_tasks",
        short_description: "Include a tasks file dynamically",
        description: "Loads and runs a tasks file at runtime.",
        options: &[
            OptionDoc { name: "file", description: "Path to the tasks file.", required: true, default: None },
        ],
        example: "- include_tasks: install.yml",
    },
    PluginDoc {
        name: "import_tasks",
        short_description: "Statically import a tasks file",
        description: "Loads and inlines a tasks file at parse time.",
        options: &[
            OptionDoc { name: "file", description: "Path to the tasks file.", required: true, default: None },
        ],
        example: "- import_tasks: install.yml",
    },
    PluginDoc {
        name: "apt",
        short_description: "Manage Debian/Ubuntu packages with apt",
        description: "Install, remove, or upgrade packages via apt.",
        options: &[
            OptionDoc { name: "name", description: "Package name(s).", required: false, default: None },
            OptionDoc { name: "state", description: "present, absent, latest, build-dep.", required: false, default: Some("present") },
            OptionDoc { name: "update_cache", description: "Run apt-get update first.", required: false, default: Some("false") },
        ],
        example: "- apt:\n    name: nginx\n    state: present\n    update_cache: yes",
    },
    PluginDoc {
        name: "yum",
        short_description: "Manage RHEL/CentOS packages with yum",
        description: "Install, remove, or upgrade packages via yum.",
        options: &[
            OptionDoc { name: "name", description: "Package name(s).", required: false, default: None },
            OptionDoc { name: "state", description: "present, absent, latest.", required: false, default: Some("present") },
        ],
        example: "- yum:\n    name: httpd\n    state: latest",
    },
    PluginDoc {
        name: "dnf",
        short_description: "Manage Fedora/RHEL packages with dnf",
        description: "Install, remove, or upgrade packages via dnf.",
        options: &[
            OptionDoc { name: "name", description: "Package name(s).", required: false, default: None },
            OptionDoc { name: "state", description: "present, absent, latest.", required: false, default: Some("present") },
        ],
        example: "- dnf:\n    name: httpd\n    state: latest",
    },
    PluginDoc {
        name: "pacman",
        short_description: "Manage Arch Linux packages with pacman",
        description: "Install, remove, or upgrade packages via pacman.",
        options: &[
            OptionDoc { name: "name", description: "Package name(s).", required: false, default: None },
            OptionDoc { name: "state", description: "present, absent, latest.", required: false, default: Some("present") },
            OptionDoc { name: "update_cache", description: "Refresh package databases first.", required: false, default: Some("false") },
        ],
        example: "- pacman:\n    name: vim\n    state: present",
    },
    PluginDoc {
        name: "service",
        short_description: "Manage services (legacy SysV/init wrapper)",
        description: "Start, stop, restart, enable, or disable a service. Prefer `systemd` on systemd hosts.",
        options: &[
            OptionDoc { name: "name", description: "Service name.", required: true, default: None },
            OptionDoc { name: "state", description: "started, stopped, restarted, reloaded.", required: false, default: None },
            OptionDoc { name: "enabled", description: "Whether to enable on boot.", required: false, default: None },
        ],
        example: "- service:\n    name: nginx\n    state: started\n    enabled: yes",
    },
    PluginDoc {
        name: "systemd",
        short_description: "Manage systemd units",
        description: "Start, stop, restart, enable, or daemon-reload systemd services.",
        options: &[
            OptionDoc { name: "name", description: "Unit name.", required: false, default: None },
            OptionDoc { name: "state", description: "started, stopped, restarted, reloaded.", required: false, default: None },
            OptionDoc { name: "enabled", description: "Enable at boot.", required: false, default: None },
            OptionDoc { name: "daemon_reload", description: "Run systemctl daemon-reload first.", required: false, default: Some("false") },
        ],
        example: "- systemd:\n    name: nginx.service\n    state: restarted\n    daemon_reload: yes",
    },
    PluginDoc {
        name: "user",
        short_description: "Manage user accounts",
        description: "Create, modify, or remove a user account.",
        options: &[
            OptionDoc { name: "name", description: "User name.", required: true, default: None },
            OptionDoc { name: "state", description: "present or absent.", required: false, default: Some("present") },
            OptionDoc { name: "uid", description: "User ID.", required: false, default: None },
            OptionDoc { name: "groups", description: "Supplementary groups.", required: false, default: None },
            OptionDoc { name: "shell", description: "Login shell.", required: false, default: None },
        ],
        example: "- user:\n    name: deploy\n    shell: /bin/bash",
    },
    PluginDoc {
        name: "group",
        short_description: "Manage groups",
        description: "Create or remove a group.",
        options: &[
            OptionDoc { name: "name", description: "Group name.", required: true, default: None },
            OptionDoc { name: "state", description: "present or absent.", required: false, default: Some("present") },
            OptionDoc { name: "gid", description: "Group ID.", required: false, default: None },
        ],
        example: "- group:\n    name: deploy\n    state: present",
    },
    PluginDoc {
        name: "package_facts",
        short_description: "Collect installed-package facts",
        description: "Populates `ansible_facts.packages` with the installed package list using the host's package manager.",
        options: &[
            OptionDoc { name: "manager", description: "Force a specific package manager (apt, rpm, pacman, …).", required: false, default: Some("auto") },
        ],
        example: "- package_facts:\n    manager: auto",
    },
];

const CALLBACK_DOCS: &[PluginDoc] = &[
    PluginDoc {
        name: "default",
        short_description: "Default human-readable callback",
        description: "Renders TASK and PLAY banners and per-host result lines. Used when no `stdout_callback` is configured.",
        options: &[],
        example: "[defaults]\nstdout_callback = default",
    },
];

const CONNECTION_DOCS: &[PluginDoc] = &[
    PluginDoc {
        name: "ssh",
        short_description: "Connect over SSH",
        description: "Default connection plugin for non-local hosts. Uses an external `ssh` client.",
        options: &[
            OptionDoc { name: "host", description: "Target hostname.", required: true, default: None },
            OptionDoc { name: "port", description: "TCP port.", required: false, default: Some("22") },
            OptionDoc { name: "remote_user", description: "User to log in as.", required: false, default: None },
        ],
        example: "ansible_connection: ssh",
    },
    PluginDoc {
        name: "local",
        short_description: "Run tasks on the controller",
        description: "Skips SSH and executes commands directly on the local host.",
        options: &[],
        example: "ansible_connection: local",
    },
    PluginDoc {
        name: "docker",
        short_description: "Connect via the docker CLI",
        description: "Executes tasks inside a Docker container using `docker exec`.",
        options: &[
            OptionDoc { name: "remote_user", description: "User to run commands as inside the container.", required: false, default: None },
        ],
        example: "ansible_connection: docker",
    },
    PluginDoc {
        name: "podman",
        short_description: "Connect via the podman CLI",
        description: "Executes tasks inside a Podman container using `podman exec`.",
        options: &[
            OptionDoc { name: "remote_user", description: "User to run commands as inside the container.", required: false, default: None },
        ],
        example: "ansible_connection: podman",
    },
];

const BECOME_DOCS: &[PluginDoc] = &[
    PluginDoc {
        name: "sudo",
        short_description: "Privilege escalation via sudo",
        description: "Wraps the remote command with sudo. Default `become_method`.",
        options: &[
            OptionDoc { name: "become_user", description: "User to become.", required: false, default: Some("root") },
            OptionDoc { name: "become_flags", description: "Extra sudo flags.", required: false, default: None },
        ],
        example: "become: yes\nbecome_method: sudo",
    },
    PluginDoc {
        name: "su",
        short_description: "Privilege escalation via su",
        description: "Wraps the remote command with su.",
        options: &[
            OptionDoc { name: "become_user", description: "User to become.", required: false, default: Some("root") },
        ],
        example: "become: yes\nbecome_method: su",
    },
    PluginDoc {
        name: "doas",
        short_description: "Privilege escalation via doas",
        description: "Wraps the remote command with doas (OpenBSD).",
        options: &[
            OptionDoc { name: "become_user", description: "User to become.", required: false, default: Some("root") },
        ],
        example: "become: yes\nbecome_method: doas",
    },
];

const SHELL_DOCS: &[PluginDoc] = &[
    PluginDoc {
        name: "sh",
        short_description: "POSIX sh shell plugin",
        description: "Default shell plugin for Linux/BSD targets.",
        options: &[],
        example: "ansible_shell_type: sh",
    },
    PluginDoc {
        name: "powershell",
        short_description: "PowerShell shell plugin",
        description: "Used for Windows targets.",
        options: &[],
        example: "ansible_shell_type: powershell",
    },
];

const LOOKUP_DOCS: &[PluginDoc] = &[
    PluginDoc {
        name: "items",
        short_description: "Iterate over a flat list",
        description: "Returns each element of the supplied list. Equivalent to `loop` over a list.",
        options: &[],
        example: "loop: \"{{ lookup('items', ['a', 'b']) }}\"",
    },
    PluginDoc {
        name: "dict",
        short_description: "Iterate over a dict as key/value pairs",
        description: "Returns each entry of a dict as `{key, value}`.",
        options: &[],
        example: "loop: \"{{ lookup('dict', some_dict) }}\"",
    },
];

const ACTION_DOCS: &[PluginDoc] = &[
    PluginDoc {
        name: "normal",
        short_description: "Default action plugin",
        description: "Used by modules without a specialised action plugin.",
        options: &[],
        example: "(internal — selected automatically)",
    },
    PluginDoc {
        name: "copy",
        short_description: "Action plugin for the `copy` module",
        description: "Handles the controller-side work of resolving `src` and producing the remote payload for `copy`.",
        options: &[],
        example: "- copy: { src: a, dest: /tmp/a }",
    },
    PluginDoc {
        name: "template",
        short_description: "Action plugin for the `template` module",
        description: "Renders the Jinja2 template on the controller before invoking the remote `copy` module.",
        options: &[],
        example: "- template: { src: a.j2, dest: /tmp/a }",
    },
];

fn catalog_for(plugin_type: &str) -> Option<&'static [PluginDoc]> {
    match plugin_type {
        "module" => Some(MODULE_DOCS),
        "callback" => Some(CALLBACK_DOCS),
        "connection" => Some(CONNECTION_DOCS),
        "become" => Some(BECOME_DOCS),
        "shell" => Some(SHELL_DOCS),
        "lookup" => Some(LOOKUP_DOCS),
        "action" => Some(ACTION_DOCS),
        _ => None,
    }
}

fn supported_types() -> &'static [&'static str] {
    &["module", "callback", "connection", "become", "shell", "lookup", "action"]
}

fn print_list(plugin_type: &str, catalog: &[PluginDoc]) {
    println!("# {} plugins", plugin_type);
    let max = catalog.iter().map(|p| p.name.len()).max().unwrap_or(0);
    for p in catalog {
        println!("{:width$}  {}", p.name, p.short_description, width = max);
    }
}

fn print_doc(plugin_type: &str, doc: &PluginDoc, snippet: bool) {
    if snippet {
        println!("- name: {}", doc.short_description);
        println!("  {}:", doc.name);
        for opt in doc.options {
            let val = opt.default.unwrap_or("");
            println!("    {}: {}", opt.name, val);
        }
        return;
    }
    println!("> {} ({})", doc.name.to_uppercase(), plugin_type);
    println!();
    println!("{}", doc.short_description);
    println!();
    println!("{}", doc.description);
    if !doc.options.is_empty() {
        println!();
        println!("OPTIONS:");
        for opt in doc.options {
            let req = if opt.required { " (required)" } else { "" };
            let default = match opt.default {
                Some(d) => format!(" [default: {d}]"),
                None => String::new(),
            };
            println!("  {}{}{}", opt.name, req, default);
            println!("    {}", opt.description);
        }
    }
    println!();
    println!("EXAMPLES:");
    for line in doc.example.lines() {
        println!("  {line}");
    }
    println!();
}

/// Run the `ansible-doc` subcommand.
pub fn run_doc(
    plugin: Option<String>,
    plugin_type: &str,
    list: bool,
    snippet: bool,
) -> Result<u8> {
    let catalog = match catalog_for(plugin_type) {
        Some(c) => c,
        None => {
            eprintln!(
                "ansible-doc: unknown plugin type '{plugin_type}'. Supported: {}",
                supported_types().join(", ")
            );
            return Ok(1);
        }
    };

    if list {
        print_list(plugin_type, catalog);
        return Ok(0);
    }

    let Some(name) = plugin else {
        eprintln!("ansible-doc: a plugin name is required (or use --list)");
        return Ok(1);
    };

    let stripped = name.strip_prefix("ansible.builtin.").unwrap_or(&name);
    match catalog.iter().find(|p| p.name == stripped) {
        Some(doc) => {
            print_doc(plugin_type, doc, snippet);
            Ok(0)
        }
        None => {
            eprintln!(
                "ansible-doc: no documentation found for {plugin_type} '{name}'.\n\
                 Use `ansible-doc -t {plugin_type} -l` to list available plugins."
            );
            Ok(1)
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn lookup_includes_native_modules() {
        let names: Vec<_> = MODULE_DOCS.iter().map(|p| p.name).collect();
        for must_have in [
            "command", "shell", "debug", "set_fact", "file", "copy", "template",
            "service", "systemd", "apt", "yum", "ping", "setup",
        ] {
            assert!(names.contains(&must_have), "missing module doc: {must_have}");
        }
    }

    #[test]
    fn unknown_type_returns_error() {
        let rc = run_doc(Some("foo".into()), "unknown", false, false).unwrap();
        assert_eq!(rc, 1);
    }

    #[test]
    fn list_succeeds() {
        let rc = run_doc(None, "module", true, false).unwrap();
        assert_eq!(rc, 0);
    }

    #[test]
    fn known_module_succeeds() {
        let rc = run_doc(Some("ping".into()), "module", false, false).unwrap();
        assert_eq!(rc, 0);
    }

    #[test]
    fn ansible_builtin_prefix_is_stripped() {
        let rc = run_doc(Some("ansible.builtin.ping".into()), "module", false, false).unwrap();
        assert_eq!(rc, 0);
    }

    #[test]
    fn unknown_module_returns_error() {
        let rc = run_doc(Some("doesnotexist".into()), "module", false, false).unwrap();
        assert_eq!(rc, 1);
    }

    #[test]
    fn callback_default_present() {
        let rc = run_doc(Some("default".into()), "callback", false, false).unwrap();
        assert_eq!(rc, 0);
    }

    #[test]
    fn missing_plugin_name_without_list() {
        let rc = run_doc(None, "module", false, false).unwrap();
        assert_eq!(rc, 1);
    }
}
