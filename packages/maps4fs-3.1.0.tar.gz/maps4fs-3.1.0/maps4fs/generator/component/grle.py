"""This module contains the GRLE class for generating InfoLayer PNG files based on GRLE schema."""

from __future__ import annotations

import json
import os
from random import choice, randint
from typing import Any, NamedTuple

import cv2
import numpy as np
from shapely.geometry import Polygon
from tqdm import tqdm

from maps4fs.generator.component.base.component_image import ImageComponent
from maps4fs.generator.component.layer import Layer
from maps4fs.generator.component.xml_document import XmlDocument
from maps4fs.generator.monitor import monitor_performance
from maps4fs.generator.settings import Parameters


class GRLELayer(NamedTuple):
    """Named tuple for GRLE layer.

    Arguments:
        name (str): name of the layer including file extension (e.g., "infoLayer_tipCollision.png").
        height_multiplier (float): multiplier for the height of the layer relative to the map size.
        width_multiplier (float): multiplier for the width of the layer relative to the map size.
        channels (int): number of channels in the layer (e.g., 1 for grayscale, 3 for RGB).
        data_type (str): data type of the layer (e.g., "uint8", "float32").
    """

    name: str
    height_multiplier: float
    width_multiplier: float
    channels: int
    data_type: str


class GRLE(ImageComponent):
    """Component for to generate InfoLayer PNG files based on GRLE schema.

    Arguments:
        game (Game): The game instance for which the map is generated.
        coordinates (tuple[float, float]): The latitude and longitude of the center of the map.
        map_size (int): The size of the map in pixels.
        map_rotated_size (int): The size of the map in pixels after rotation.
        rotation (int): The rotation angle of the map.
        map_directory (str): The directory where the map files are stored.
        logger (Any, optional): The logger to use. Must have at least three basic methods: debug,
            info, warning. If not provided, default logging will be used.
    """

    def preprocess(self) -> None:
        """Gets the path to the map I3D file from the game instance and saves it to the instance
        attribute. If the game does not support I3D files, the attribute is set to None."""
        self.preview_paths: dict[str, str] = {}
        self.xml_path = self.game.farmlands_xml_path

    def _read_grle_schema(self) -> list[GRLELayer]:
        grle_schema_path = self.game.grle_schema

        try:
            with open(grle_schema_path, "r", encoding="utf-8") as file:
                grle_schema = json.load(file)
            self.logger.debug("GRLE schema loaded from: %s.", grle_schema_path)
        except (json.JSONDecodeError, FileNotFoundError) as error:
            self.logger.error("Error loading GRLE schema from %s: %s.", grle_schema_path, error)
            grle_schema = None

        try:
            return [
                GRLELayer(
                    name=layer["name"],
                    height_multiplier=layer["height_multiplier"],
                    width_multiplier=layer["width_multiplier"],
                    channels=layer["channels"],
                    data_type=layer["data_type"],
                )
                for layer in grle_schema
            ]

        except (KeyError, TypeError) as e:
            self.logger.error("Error parsing GRLE schema: %s.", e)
            return []

    @monitor_performance
    def process(self) -> None:
        """Generates InfoLayer PNG files based on the GRLE schema."""
        grle_schema = self._read_grle_schema()
        if not grle_schema:
            self.logger.debug("GRLE schema is not obtained, skipping the processing.")
            return

        for info_layer in tqdm(grle_schema, desc="Preparing GRLE files", unit="layer"):
            file_path = os.path.join(self.game.weights_dir_path, info_layer.name)

            height = int(self.scaled_size * info_layer.height_multiplier)
            width = int(self.scaled_size * info_layer.width_multiplier)
            channels = info_layer.channels
            data_type = info_layer.data_type
            info_layer_data: np.ndarray

            # Create the InfoLayer PNG file with zeros.
            if channels == 1:
                info_layer_data = np.zeros((height, width), dtype=data_type)
            else:
                info_layer_data = np.zeros((height, width, channels), dtype=data_type)
            self.logger.debug("Shape of %s: %s.", info_layer.name, info_layer_data.shape)
            cv2.imwrite(file_path, info_layer_data)
            self.logger.debug("InfoLayer PNG file %s created.", file_path)

        self.grle_schema = grle_schema

        self._add_farmlands()
        if self.map.grle_settings.add_grass:
            self._add_plants()
        self._process_environment()
        self._process_indoor()

    def get_info_layer_by_name(self, name: str) -> GRLELayer | None:
        """Returns the GRLELayer object for the given name.

        Arguments:
            name (str): The name of the InfoLayer PNG file.

        Returns:
            GRLELayer | None: The GRLELayer object if found, else None.
        """
        if not hasattr(self, "grle_schema") or not isinstance(self.grle_schema, list):
            return None
        for layer in self.grle_schema:
            if layer.name == name:
                return layer
        return None

    @monitor_performance
    def previews(self) -> list[str]:
        """Returns a list of paths to the preview images (empty list).
        The component does not generate any preview images so it returns an empty list.

        Returns:
            list[str]: An empty list.
        """
        preview_paths = []
        for preview_name, preview_path in self.preview_paths.items():
            save_path = os.path.join(self.previews_directory, f"{preview_name}.png")
            # Resize the preview image to the maximum size allowed for previews.
            image = cv2.imread(preview_path, cv2.IMREAD_GRAYSCALE)
            if image is None:
                self.logger.warning("Preview source could not be loaded: %s", preview_path)
                continue
            if (
                image.shape[0] > Parameters.PREVIEW_MAXIMUM_SIZE
                or image.shape[1] > Parameters.PREVIEW_MAXIMUM_SIZE
            ):
                image = cv2.resize(
                    image, (Parameters.PREVIEW_MAXIMUM_SIZE, Parameters.PREVIEW_MAXIMUM_SIZE)
                )
            image_normalized = np.empty_like(image)
            cv2.normalize(image, image_normalized, 0, 255, cv2.NORM_MINMAX)
            image_colored = cv2.applyColorMap(image_normalized, cv2.COLORMAP_JET)
            cv2.imwrite(save_path, image_colored)
            preview_paths.append(save_path)

            if preview_name != "farmlands":
                continue

            with_fields_save_path = os.path.join(
                self.previews_directory, f"{preview_name}_with_fields.png"
            )
            image_with_fields = self.overlay_fields(image_colored)
            if image_with_fields is None:
                continue
            cv2.imwrite(with_fields_save_path, image_with_fields)
            preview_paths.append(with_fields_save_path)

        return preview_paths

    @monitor_performance
    def overlay_fields(self, farmlands_np: np.ndarray) -> np.ndarray | None:
        """Overlay fields on the farmlands preview image.

        Arguments:
            farmlands_np (np.ndarray): The farmlands preview image.

        Returns:
            np.ndarray | None: The farmlands preview image with fields overlayed on top of it.
        """
        fields_layer = self.map.context.get_layer_by_usage("field")
        if not fields_layer:
            self.logger.debug("Fields layer not found in the texture component.")
            return None

        fields_layer_path = fields_layer.get_preview_or_path(self.game.weights_dir_path)
        if not fields_layer_path or not os.path.isfile(fields_layer_path):
            self.logger.debug("Fields layer not found in the texture component.")
            return None
        fields_np = cv2.imread(fields_layer_path)
        if fields_np is None:
            self.logger.debug("Fields preview image could not be loaded: %s", fields_layer_path)
            return None
        # Resize fields_np to the same size as farmlands_np.
        fields_np = cv2.resize(fields_np, (farmlands_np.shape[1], farmlands_np.shape[0]))

        # use fields_np as base layer and overlay farmlands_np on top of it with 50% alpha blending.
        return cv2.addWeighted(fields_np, 0.5, farmlands_np, 0.5, 0)

    @monitor_performance
    def _add_farmlands(self) -> None:
        """Adds farmlands to the InfoLayer PNG file."""
        farmlands = []

        fields = self.get_infolayer_data(Parameters.TEXTURES, Parameters.FIELDS)
        if fields:
            self.logger.debug("Found %s fields in textures info layer.", len(fields))
            farmlands.extend(fields)

        farmyards = self.get_infolayer_data(Parameters.TEXTURES, Parameters.FARMYARDS)
        if farmyards and self.map.grle_settings.add_farmyards:
            farmlands.extend(farmyards)
            self.logger.debug("Found %s farmyards in textures info layer.", len(farmyards))

        if not farmlands:
            self.logger.warning(
                "No farmlands was obtained from fields or farmyards, skipping the processing."
            )
            return

        info_layer_farmlands_path = self.game.farmlands_path

        self.logger.debug(
            "Adding farmlands to the InfoLayer PNG file: %s.", info_layer_farmlands_path
        )

        if not os.path.isfile(info_layer_farmlands_path):
            self.logger.warning("InfoLayer PNG file %s not found.", info_layer_farmlands_path)
            return

        image = cv2.imread(info_layer_farmlands_path, cv2.IMREAD_UNCHANGED)
        if image is None:
            self.logger.warning(
                "Could not read farmlands info layer image: %s", info_layer_farmlands_path
            )
            return

        doc = XmlDocument(self.xml_path)
        if doc.get("farmlands") is None:
            raise ValueError("Farmlands XML element not found in the farmlands XML file.")

        doc.set_attrs("farmlands", pricePerHa=str(self.map.grle_settings.base_price))

        farmland_id = 1

        for farmland in tqdm(farmlands, desc="Adding farmlands", unit="farmland"):
            farmland_points = self._extract_farmland_points(farmland)
            if not farmland_points:
                self.logger.debug(
                    "Skipping farmland %s due to invalid polygon format.", farmland_id
                )
                continue

            try:
                fitted_farmland = self.fit_object_into_bounds(
                    polygon_points=farmland_points,
                    margin=self.map.grle_settings.farmland_margin,
                    angle=self.rotation,
                )
            except ValueError as e:
                self.logger.debug(
                    "Farmland %s could not be fitted into the map bounds with error: %s",
                    farmland_id,
                    e,
                )
                continue

            # divide argument depends on the width and height multipliers of the farmlands info layer.
            # By default, it's 2, since farmlands is 0.5 to the map size in both width and height.
            farmlands_grle_layer = self.get_info_layer_by_name(Parameters.INFO_LAYER_FARMLANDS)
            if not farmlands_grle_layer:
                self.logger.error("Farmlands InfoLayer PNG file not found in the GRLE schema.")
                return

            if not farmlands_grle_layer.height_multiplier == farmlands_grle_layer.width_multiplier:
                self.logger.error(
                    "Farmlands InfoLayer PNG file has different height and width multipliers, "
                    "which is not supported by Giants Editor."
                )
                raise ValueError(
                    "Farmlands InfoLayer PNG file has different height and width multipliers."
                )

            divide = int(1 / farmlands_grle_layer.height_multiplier)
            self.logger.debug("Using divide value of %s for farmland ID %s.", divide, farmland_id)

            farmland_np = self.polygon_points_to_np(fitted_farmland, divide=divide)

            if farmland_id > Parameters.FARMLAND_ID_LIMIT:
                self.logger.warning(
                    "Farmland ID limit reached. Skipping the rest of the farmlands. "
                    "Giants Editor supports maximum 254 farmlands."
                )
                break

            try:
                cv2.fillPoly(image, [farmland_np], (float(farmland_id),))
            except Exception as e:
                self.logger.debug(
                    "Farmland %s could not be added to the InfoLayer PNG file with error: %s",
                    farmland_id,
                    e,
                )
                continue

            doc.append_child(
                "farmlands",
                "farmland",
                id=str(farmland_id),
                priceScale="1",
                npcName="FORESTER",
            )

            farmland_id += 1

        doc.save()

        # Replace all the zero values on the info layer image with 255.
        if self.map.grle_settings.fill_empty_farmlands:
            image[image == 0] = 255

        cv2.imwrite(info_layer_farmlands_path, image)

        self.assets.farmlands = info_layer_farmlands_path

        self.preview_paths["farmlands"] = info_layer_farmlands_path

    @staticmethod
    def _extract_farmland_points(farmland: Any) -> list[tuple[int, int]]:
        """Return legacy polygon point list for farmland rasterization.

        Field entries may contain hole metadata for scene export. Farmlands should keep
        the previous behavior and use only the exterior ring.
        """
        if isinstance(farmland, dict):
            points = farmland.get(Parameters.POINTS)
            return points if isinstance(points, list) else []
        if isinstance(farmland, list):
            return farmland
        return []

    @monitor_performance
    def _add_plants(self) -> None:
        """Adds plants to the InfoLayer PNG file."""
        grass_layer = self.map.context.get_layer_by_usage("grass")
        if not grass_layer:
            self.logger.warning("Grass layer not found in the texture component.")
            return

        weights_directory = self.game.weights_dir_path
        grass_image_path = grass_layer.get_preview_or_path(weights_directory)
        self.logger.debug("Grass image path: %s.", grass_image_path)

        forest_layer = self.map.context.get_layer_by_usage("forest")
        forest_image = None
        if forest_layer:
            forest_image_path = forest_layer.get_preview_or_path(weights_directory)
            self.logger.debug("Forest image path: %s.", forest_image_path)
            if forest_image_path:

                forest_image = cv2.imread(forest_image_path, cv2.IMREAD_UNCHANGED)

        if not grass_image_path or not os.path.isfile(grass_image_path):
            self.logger.warning("Base image not found in %s.", grass_image_path)
            return

        density_map_fruit_path = self.game.density_map_fruits_path

        self.logger.debug("Density map for fruits path: %s.", density_map_fruit_path)

        if not os.path.isfile(density_map_fruit_path):
            self.logger.warning("Density map for fruits not found in %s.", density_map_fruit_path)
            return

        # Single channeled 8-bit image, where non-zero values (255) are where the grass is.
        grass_image = cv2.imread(grass_image_path, cv2.IMREAD_UNCHANGED)
        if grass_image is None:
            self.logger.warning("Could not load grass mask image: %s", grass_image_path)
            return

        grle_density_map_fruits = self.get_info_layer_by_name(Parameters.DENSITY_MAP_FRUITS)
        if not grle_density_map_fruits:
            self.logger.error(
                "Density map for fruits InfoLayer PNG file not found in the GRLE schema."
            )
            return
        normalized_dtype = str(grle_density_map_fruits.data_type).strip().lower()
        use_extended_foliage_values = normalized_dtype in {"uint16", "np.uint16", "numpy.uint16"}
        self.map.context.foliage_density_map_uint16 = use_extended_foliage_values

        height_multiplier = int(grle_density_map_fruits.height_multiplier)
        width_multiplier = int(grle_density_map_fruits.width_multiplier)
        self.logger.debug(
            "Resizing grass and forest images with height multiplier %s and width multiplier %s.",
            height_multiplier,
            width_multiplier,
        )

        # Density map of the fruits by default is 2X size of the base image, so we need to resize it.
        # However, it's possible to customize the values in the schema, so we need to take that into account.
        grass_image = cv2.resize(
            grass_image,
            (grass_image.shape[1] * width_multiplier, grass_image.shape[0] * height_multiplier),
            interpolation=cv2.INTER_NEAREST,
        )
        if forest_image is not None:
            forest_image = cv2.resize(
                forest_image,
                (
                    forest_image.shape[1] * width_multiplier,
                    forest_image.shape[0] * height_multiplier,
                ),
                interpolation=cv2.INTER_NEAREST,
            )

            # Add non zero values from the forest image to the grass image.
            grass_image[forest_image != 0] = 255

        base_grass = self.map.grle_settings.base_grass
        base_layer_pixel_value = self._get_base_grass_pixel_value(
            str(base_grass),
            use_extended_foliage_values,
        )

        grass_image_copy: np.ndarray
        if use_extended_foliage_values:
            # uint16 target values can exceed 255, so keep working buffer in uint16.
            grass_image_copy = grass_image.astype(np.uint16, copy=True)
        else:
            grass_image_copy = grass_image.copy()
        if forest_image is not None:
            # Add the forest layer to the base image, to merge the masks.
            grass_image_copy[forest_image != 0] = base_layer_pixel_value

        grass_image_copy[grass_image != 0] = base_layer_pixel_value

        # Add islands of plants to the base image.
        island_count = int(self.scaled_size * Parameters.PLANTS_ISLAND_PERCENT // 100)
        self.logger.debug("Adding %s islands of plants to the base image.", island_count)
        if self.map.grle_settings.random_plants:
            grass_image_copy = self.create_island_of_plants(
                grass_image_copy,
                island_count,
                use_extended_foliage_values=use_extended_foliage_values,
            )
            self.logger.debug("Added %s islands of plants to the base image.", island_count)

        # Sligtly reduce the size of the grass_image, that we'll use as mask.
        kernel = np.ones((3, 3), np.uint8)
        grass_image = cv2.erode(grass_image, kernel, iterations=1)

        # Remove the values where the base image has zeros.
        grass_image_copy[grass_image == 0] = 0
        self.logger.debug("Removed the values where the base image has zeros.")

        grass_image_copy = self.remove_edge_pixel_values(grass_image_copy)

        # Three channeled density map image where non-zero values in channel 0
        # represent foliage types. Depending on schema, dtype can be uint8 or uint16.
        density_map_fruits = cv2.imread(density_map_fruit_path, cv2.IMREAD_UNCHANGED)
        if density_map_fruits is None:
            self.logger.warning("Could not load density map for fruits: %s", density_map_fruit_path)
            return
        self.logger.debug("Density map for fruits loaded, shape: %s.", density_map_fruits.shape)

        if grass_image_copy.dtype != density_map_fruits.dtype:
            grass_image_copy = grass_image_copy.astype(density_map_fruits.dtype)

        # Put the updated base image as the B channel in the density map.
        density_map_fruits[:, :, 0] = grass_image_copy
        self.logger.debug("Updated base image added as the B channel in the density map.")

        # Save the updated density map.
        # Ensure that order of channels is correct because CV2 uses BGR and we need RGB.
        density_map_fruits = cv2.cvtColor(density_map_fruits, cv2.COLOR_BGR2RGB)
        cv2.imwrite(density_map_fruit_path, density_map_fruits)

        self.assets.plants = density_map_fruit_path

        self.logger.debug("Updated density map for fruits saved in %s.", density_map_fruit_path)

    def _get_base_grass_pixel_value(
        self, base_grass: str, use_extended_foliage_values: bool
    ) -> int:
        """Return base grass pixel value for uint8 or uint16 mode.

        Arguments:
            base_grass (str): Base grass type key from settings.
            use_extended_foliage_values (bool): Whether uint16 foliage mode is active.

        Returns:
            int: Pixel value to write into densityMap_fruits channel for base grass.
        """
        bit_depth = 16 if use_extended_foliage_values else 8
        plant_values = Parameters.PLANT_PIXEL_VALUES_BY_BIT_DEPTH.get(bit_depth, {})
        default_pixel_value = Parameters.DEFAULT_GRASS_PIXEL_VALUE_BY_BIT_DEPTH[bit_depth]
        return plant_values.get(base_grass) or default_pixel_value

    @monitor_performance
    def create_island_of_plants(
        self,
        image: np.ndarray,
        count: int,
        use_extended_foliage_values: bool = False,
    ) -> np.ndarray:
        """Create an island of plants in the image.

        Arguments:
            image (np.ndarray): The image where the island of plants will be created.
            count (int): The number of islands of plants to create.
            use_extended_foliage_values (bool): Whether uint16 foliage mode is active.

        Returns:
            np.ndarray: The input image with randomly generated plant islands.
        """
        # B and G channels remain the same (zeros), while we change the R channel.
        bit_depth = 16 if use_extended_foliage_values else 8
        possible_r_values = list(
            Parameters.PLANT_ISLAND_PIXEL_VALUES_BY_BIT_DEPTH.get(bit_depth, [])
        )

        for _ in tqdm(range(count), desc="Adding islands of plants", unit="island"):
            # Randomly choose the value for the island.
            plant_value = choice(possible_r_values)
            # Randomly choose the size of the island.
            island_size = randint(
                Parameters.PLANTS_ISLAND_MINIMUM_SIZE,
                Parameters.PLANTS_ISLAND_MAXIMUM_SIZE,
            )
            # Randomly choose the position of the island.
            x = randint(0, image.shape[1] - island_size)
            y = randint(0, image.shape[0] - island_size)

            try:
                polygon_points = self.get_rounded_polygon(
                    num_vertices=Parameters.PLANTS_ISLAND_VERTEX_COUNT,
                    center=(x + island_size // 2, y + island_size // 2),
                    radius=island_size // 2,
                    rounding_radius=Parameters.PLANTS_ISLAND_ROUNDING_RADIUS,
                )
                if not polygon_points:
                    continue

                nodes = np.array(polygon_points, np.int32)
                cv2.fillPoly(image, [nodes], (float(plant_value),))
            except Exception:
                continue

        return image

    @staticmethod
    def get_rounded_polygon(
        num_vertices: int, center: tuple[int, int], radius: int, rounding_radius: int
    ) -> list[tuple[int, int]] | None:
        """Get a randomly rounded polygon.

        Arguments:
            num_vertices (int): The number of vertices of the polygon.
            center (tuple[int, int]): The center of the polygon.
            radius (int): The radius of the polygon.
            rounding_radius (int): The rounding radius of the polygon.

        Returns:
            list[tuple[int, int]] | None: The rounded polygon.
        """
        island_distortion = 0.3

        angle_offset = np.pi / num_vertices
        angles = np.linspace(0, 2 * np.pi, num_vertices, endpoint=False) + angle_offset
        random_angles = angles + np.random.uniform(
            -island_distortion, island_distortion, num_vertices
        )  # Add randomness to angles
        random_radii = radius + np.random.uniform(
            -radius * island_distortion, radius * island_distortion, num_vertices
        )  # Add randomness to radii

        points = [
            (center[0] + np.cos(a) * r, center[1] + np.sin(a) * r)
            for a, r in zip(random_angles, random_radii)
        ]
        polygon = Polygon(points)
        buffered_polygon = polygon.buffer(rounding_radius, quad_segs=16)
        rounded_polygon = list(buffered_polygon.exterior.coords)
        if not rounded_polygon:
            return None
        return rounded_polygon

    @staticmethod
    def remove_edge_pixel_values(image_np: np.ndarray) -> np.ndarray:
        """Remove the edge pixel values from the image.

        Arguments:
            image_np (np.ndarray): The image to remove the edge pixel values from.

        Returns:
            np.ndarray: The image with the edge pixel values removed.
        """
        # Set zeros on all sides of the image
        image_np[0, :] = 0  # Top side
        image_np[-1, :] = 0  # Bottom side
        image_np[:, 0] = 0  # Left side
        image_np[:, -1] = 0  # Right side
        return image_np

    @monitor_performance
    def _process_environment(self) -> None:
        info_layer_environment_path = self.game.environment_path
        if not info_layer_environment_path or not os.path.isfile(info_layer_environment_path):
            self.logger.warning(
                "Environment InfoLayer PNG file not found in %s.", info_layer_environment_path
            )
            return

        self.logger.debug(
            "Processing environment InfoLayer PNG file: %s.", info_layer_environment_path
        )

        environment_image = cv2.imread(info_layer_environment_path, cv2.IMREAD_UNCHANGED)
        if environment_image is None:
            self.logger.error("Failed to read the environment InfoLayer PNG file.")
            return

        self.logger.debug(
            "Environment InfoLayer PNG file loaded, shape: %s.", environment_image.shape
        )

        environment_size = int(environment_image.shape[0])

        # 1. Get the texture layers that contain "area_type" property.
        # 2. Read the corresponding weight image (not the dissolved ones!).
        # 3. Resize it to match the environment image size (probably 1/4 of the texture size).
        # 4. Dilate the texture mask to make it little bit bigger.
        # 5. Set the corresponding pixel values of the environment image to the pixel value of the area type.
        # 6. Get the texture layer that "area_water" is True.
        # 7. Same as resize, dilate, etc.
        # 8. Sum the current pixel value with the WATER_AREA_PIXEL_VALUE.

        texture_component = self.map.context
        if not texture_component.texture_layers:
            self.logger.warning("Texture layers not found in context.")
            return

        for layer in texture_component.get_area_type_layers():
            pixel_value = Parameters.ENVIRONMENT_AREA_TYPES.get(layer.area_type)
            if pixel_value is None:
                continue
            weight_image = self.get_resized_weight(layer, environment_size)
            if weight_image is None:
                self.logger.warning("Weight image for area type layer not found in %s.", layer.name)
                continue
            environment_image[weight_image > 0] = pixel_value

        for layer in texture_component.get_water_area_layers():
            weight_image = self.get_resized_weight(layer, environment_size)
            if weight_image is None:
                self.logger.warning(
                    "Weight image for water area layer not found in %s.", layer.name
                )
                continue
            water_mask = weight_image > 0
            environment_image[water_mask] = environment_image[water_mask] + int(
                Parameters.WATER_AREA_PIXEL_VALUE
            )

        cv2.imwrite(info_layer_environment_path, environment_image)
        self.logger.debug("Environment InfoLayer PNG file saved: %s.", info_layer_environment_path)
        self.preview_paths["environment"] = info_layer_environment_path

    @monitor_performance
    def get_resized_weight(
        self, layer: Layer, resize_to: int, dilations: int = 3
    ) -> np.ndarray | None:
        """Get the resized weight image for a given layer.

        Arguments:
            layer (Layer): The layer for which to get the weight image.
            resize_to (int): The size to which the weight image should be resized.
            dilations (int): The number of dilations to apply to the weight image.

        Returns:
            np.ndarray | None: The resized and dilated weight image, or None if the image could not be loaded.
        """
        weight_image_path = layer.get_preview_or_path(self.game.weights_dir_path)
        self.logger.debug("Weight image path for area type layer: %s.", weight_image_path)

        if not weight_image_path or not os.path.isfile(weight_image_path):
            self.logger.warning(
                "Weight image for area type layer not found in %s.", weight_image_path
            )
            return None

        weight_image = cv2.imread(weight_image_path, cv2.IMREAD_UNCHANGED)
        if weight_image is None:
            self.logger.error("Failed to read the weight image for area type layer.")
            return None

        self.logger.debug("Weight image for area type layer loaded, shape: %s.", weight_image.shape)

        # Resize the weight image to match the environment image size.
        weight_image = cv2.resize(
            weight_image,
            (resize_to, resize_to),
            interpolation=cv2.INTER_NEAREST,
        )

        self.logger.debug(
            "Resized weight image for area type layer, new shape: %s.", weight_image.shape
        )

        if dilations <= 0:
            return weight_image

        dilated_weight_image = cv2.dilate(
            weight_image.astype(np.uint8),
            np.ones((dilations, dilations), np.uint8),
            iterations=dilations,
        )

        return dilated_weight_image

    def _process_indoor(self) -> None:
        """Processes the indoor layers."""
        info_layer_indoor_path = self.game.indoor_mask_path
        if not info_layer_indoor_path or not os.path.isfile(info_layer_indoor_path):
            self.logger.warning(
                "Indoor InfoLayer PNG file not found in %s.", info_layer_indoor_path
            )
            return

        indoor_mask_image = cv2.imread(info_layer_indoor_path, cv2.IMREAD_UNCHANGED)
        if indoor_mask_image is None:
            self.logger.warning(
                "Failed to read the indoor InfoLayer PNG file %s.", info_layer_indoor_path
            )
            return

        indoor_mask_size = int(indoor_mask_image.shape[0])
        self.logger.debug("Indoor InfoLayer PNG file loaded, shape: %s.", indoor_mask_image.shape)

        texture_context = self.map.context
        if not texture_context.texture_layers:
            self.logger.warning("Texture layers not found in context.")
            return

        for layer in texture_context.get_indoor_layers():
            weight_image = self.get_resized_weight(layer, indoor_mask_size, dilations=0)
            if weight_image is None:
                self.logger.warning("Weight image for indoor layer not found in %s.", layer.name)
                continue

            indoor_mask_image[weight_image > 0] = 1

        cv2.imwrite(info_layer_indoor_path, indoor_mask_image)
        self.logger.debug("Indoor InfoLayer PNG file saved: %s.", info_layer_indoor_path)
        self.preview_paths["indoor"] = info_layer_indoor_path
