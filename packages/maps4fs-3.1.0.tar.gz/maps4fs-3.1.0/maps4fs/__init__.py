"""Public package exports and startup bootstrap for maps4fs."""

from __future__ import annotations

# pylint: disable=wrong-import-position
import cv2

# Increase OpenCV image size limit for large map generation
# Default is 1024 * 1024 * 1024 = ~1 billion pixels (32,768 x 32,768 images)
# Setting to 4x larger: 4096 * 1024 * 1024 = ~4 billion pixels (65,536 x 65,536 images)

try:
    setattr(cv2, "CV_IO_MAX_IMAGE_PIXELS", 4096 * 1024 * 1024 * 2)
except Exception as e:
    print(f"Warning: Could not set CV_IO_MAX_IMAGE_PIXELS: {e}")

import pydtmdl.providers as dtm
from pydtmdl import DTMProvider

from maps4fs.generator import component, settings
from maps4fs.generator.bootstrap import Bootstrap
from maps4fs.generator.game import FS25, Game
from maps4fs.generator.map import Map
from maps4fs.generator.monitor import Logger
from maps4fs.generator.settings import GenerationSettings, MainSettings

Bootstrap.run()
