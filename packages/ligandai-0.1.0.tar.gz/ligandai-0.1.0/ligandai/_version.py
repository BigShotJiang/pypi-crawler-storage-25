# Copyright © 2025 Ligandal, Inc. All rights reserved.
"""Single source of truth for the SDK version.

Keep in sync with `[project] version` in `pyproject.toml`.
"""

__version__: str = "0.1.0"
