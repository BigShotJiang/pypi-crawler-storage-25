from typing import Annotated, Any, ClassVar, Literal

from pydantic import Field

from cognite_toolkit._cdf_tk.client._resource_base import (
    BaseModelObject,
    ResponseResource,
    UpdatableRequestResource,
)
from cognite_toolkit._cdf_tk.client.identifiers import DataProductVersionId, SemanticVersion
from cognite_toolkit._cdf_tk.constants import SPACE_FORMAT_PATTERN

SpaceId = Annotated[str, Field(pattern=SPACE_FORMAT_PATTERN, max_length=43)]


class ViewInstanceSpaces(BaseModelObject):
    read: list[SpaceId] = Field(default_factory=list)
    write: list[SpaceId] = Field(default_factory=list)


class DataProductVersionView(BaseModelObject):
    space: SpaceId
    external_id: str
    version: str
    instance_spaces: ViewInstanceSpaces = Field(default_factory=ViewInstanceSpaces)


class DataProductVersionTerms(BaseModelObject):
    usage: str | None = None
    limitations: str | None = None


class RuleSetVersionRef(BaseModelObject):
    """Wire representation of a RuleSetVersionReference as defined in the API spec."""

    external_id: str
    version: SemanticVersion


class DataProductVersionQuality(BaseModelObject):
    rules: list[RuleSetVersionRef] = Field(default_factory=list)


class DataProductVersion(BaseModelObject):
    data_product_external_id: str = Field(exclude=True)
    version: SemanticVersion
    views: list[DataProductVersionView] = Field(default_factory=list)
    status: Literal["draft", "published", "deprecated"] = "draft"
    description: str | None = None
    terms: DataProductVersionTerms | None = None
    quality: DataProductVersionQuality | None = None

    def as_id(self) -> DataProductVersionId:
        return DataProductVersionId(
            data_product_external_id=self.data_product_external_id,
            version=self.version,
        )


class DataProductVersionRequest(DataProductVersion, UpdatableRequestResource):
    container_fields: ClassVar[frozenset[str]] = frozenset()

    def as_update(
        self,
        mode: Literal["patch", "replace"],
        *,
        cdf_views: list[DataProductVersionView] | None = None,
    ) -> dict[str, Any]:
        # DataProductVersionPatch only defines views.add (OpenAPI); append-only updates must not
        # resend existing view refs (duplicate 400). Diff by view identity (space + externalId + version).
        update_item: dict[str, Any] = {"version": self.version}
        update: dict[str, Any] = {}
        exclude_unset = mode == "patch"
        dumped = self.model_dump(mode="json", by_alias=True, exclude_unset=exclude_unset)

        for key in ("status", "description"):
            if key not in dumped:
                continue
            if dumped[key] is None:
                update[key] = {"setNull": True}
            else:
                update[key] = {"set": dumped[key]}

        if "terms" in dumped and dumped["terms"] is not None:
            terms_modify: dict[str, Any] = {}
            for sub_key in ("usage", "limitations"):
                if sub_key in dumped["terms"]:
                    val = dumped["terms"][sub_key]
                    terms_modify[sub_key] = {"setNull": True} if val is None else {"set": val}
            if terms_modify:
                update["terms"] = {"modify": terms_modify}

        if "views" in dumped:
            # View refs are append-only per the API spec — once added they cannot be removed.
            # Only send views.add for refs not already in CDF (avoids duplicate-400 on redeploy).
            existing_keys = {(v.space, v.external_id, v.version) for v in (cdf_views or [])}
            to_add = [v for v in self.views if (v.space, v.external_id, v.version) not in existing_keys]
            if to_add:
                update["views"] = {"add": [v.model_dump(mode="json", by_alias=True) for v in to_add]}

        update_item["update"] = update
        return update_item


class DataProductVersionResponse(DataProductVersion, ResponseResource[DataProductVersionRequest]):
    data_product_external_id: str = Field(default="", exclude=True)
    created_time: int
    last_updated_time: int

    @classmethod
    def request_cls(cls) -> type[DataProductVersionRequest]:
        return DataProductVersionRequest

    def as_request_resource(self) -> DataProductVersionRequest:
        data = self.dump(camel_case=False)
        data["data_product_external_id"] = self.data_product_external_id
        return DataProductVersionRequest.model_validate(data, extra="ignore")
