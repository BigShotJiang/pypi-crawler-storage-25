"""Embedder — pluggable text embedding with multiple provider support.

Provides an abstract Embedder interface and concrete implementations
for OpenAI-compatible APIs (LM Studio, Ollama /v1, vLLM, etc.),
Ollama native API, and a null embedder for testing.
"""

from __future__ import annotations

import struct
from abc import ABC, abstractmethod
from enum import Enum

import httpx
import msgspec


class EmbeddingType(str, Enum):
    """Indicates whether text is being embedded as a document or a query.

    Some embedding models (Nomic, Cohere, etc.) produce better retrieval
    results when the input is prefixed with a task-type hint. The
    ``Embedder.apply_prefix`` method uses this enum to select the
    correct prefix for the provider.
    """

    DOCUMENT = "document"
    QUERY = "query"


class ModelSpec(msgspec.Struct, frozen=True, gc=False):
    """Static description of a model an Embedder subclass supports.

    Used by ``spkt init`` and similar tooling to populate the model
    picker without hardcoding a registry in core. Each concrete
    :class:`Embedder` subclass that ships with a fixed catalogue of
    paid/known models exposes them via
    :meth:`Embedder.supported_models`. Local-server subclasses
    (LM Studio, Ollama) return ``[]`` and rely on
    :meth:`Embedder.detect_dimension` instead.

    Attributes:
        name: Provider-side model identifier.
        dimensions: Allowed embedding dimensions. Single-value tuple
            for fixed-dim models; multi-value for Matryoshka models
            like Gemini ``gemini-embedding-001``
            (e.g. ``(3072, 1536, 768)``).
        prefix_style: Default ``prefix_style`` to use with this model
            (``"none"`` if the model doesn't need task-type prefixes).
        notes: Optional human-readable note for the picker UI.
    """

    name: str
    dimensions: tuple[int, ...]
    prefix_style: str = "none"
    notes: str = ""


class Embedder(ABC):
    """Abstract base for text embedding providers.

    Subclasses must implement [`dimension`][spikuit_core.Embedder.dimension]
    and [`embed`][spikuit_core.Embedder.embed]. Override
    [`embed_batch`][spikuit_core.Embedder.embed_batch] for providers that
    support batched requests natively.
    """

    @property
    @abstractmethod
    def dimension(self) -> int:
        """Dimensionality of the embedding vectors."""
        ...

    @classmethod
    def supported_models(cls) -> list[ModelSpec]:
        """Static catalogue of models this subclass officially supports.

        Returns ``[]`` by default. Subclasses that target paid providers
        with a known fixed model list (OpenAI, Gemini, Voyage, ...)
        should override this so ``spkt init`` can render a picker
        without hardcoding a registry in core.

        Local-server subclasses (LM Studio, Ollama) should leave this
        empty and rely on :meth:`detect_dimension` instead — the user
        already chose the model on the server side.
        """
        return []

    async def detect_dimension(self) -> int:
        """Probe the live endpoint to determine the embedding dimension.

        Calls :meth:`embed` once with a tiny payload and returns the
        length of the resulting vector. Useful for `spkt init` and
        similar tooling that wants to fill in ``dimension`` automatically
        without making the user count it themselves.

        Subclasses do **not** normally need to override this — but a
        provider that bills per call (OpenAI, Gemini, etc.) is expected
        to refuse the probe and rely on :meth:`supported_models`
        instead, so the metered providers don't surprise users with a
        cost during ``spkt init``.
        """
        vec = await self.embed("ping")
        return len(vec)

    @abstractmethod
    async def embed(self, text: str) -> list[float]:
        """Embed a single text string.

        Args:
            text: Input text to embed.

        Returns:
            Vector of floats with length equal to ``dimension``.
        """
        ...

    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        """Embed multiple texts.

        Default implementation calls ``embed()`` sequentially.
        Override for providers that support native batching.

        Args:
            texts: List of input texts.

        Returns:
            List of embedding vectors, one per input text.
        """
        return [await self.embed(t) for t in texts]

    def apply_prefix(self, text: str, embedding_type: EmbeddingType) -> str:
        """Prepend a task-type prefix appropriate for this provider.

        The default implementation is a no-op. Subclasses whose models
        benefit from task-type prefixes (e.g. Nomic, Cohere) should
        override this or accept a ``prefix_style`` at construction time.

        Args:
            text: Raw text to embed.
            embedding_type: Whether the text is a stored document or a query.

        Returns:
            Text with the appropriate prefix prepended (or unchanged).
        """
        return text


class OpenAICompatEmbedder(Embedder):
    """Embedder using any OpenAI-compatible ``/v1/embeddings`` endpoint.

    Works with LM Studio, Ollama (``/v1``), vLLM, OpenAI, and any
    service that implements the OpenAI embeddings API.

    Example:
        ```python
        embedder = OpenAICompatEmbedder(
            base_url="http://localhost:1234/v1",
            model="text-embedding-nomic-embed-text-v1.5",
            dimension=768,
            prefix_style="nomic",
        )
        vec = await embedder.embed("hello world")
        ```

    Args:
        base_url: API base URL (without trailing slash).
        model: Model identifier.
        dimension: Expected embedding dimension.
        api_key: Bearer token (default ``"not-needed"`` for local servers).
        timeout: HTTP request timeout in seconds.
        prefix_style: Task-type prefix style. Pick the one that matches
            your model family — using the wrong prefix silently degrades
            retrieval quality.

            * ``"nomic"`` → ``search_document: `` / ``search_query: ``
              (Nomic AI ``nomic-embed-text-v1.5`` and friends)
            * ``"cohere"`` → ``search_document: `` / ``search_query: ``
              (Cohere ``embed-english-v3.0`` etc., same surface as Nomic)
            * ``"e5"`` → ``passage: `` / ``query: `` (intfloat
              ``e5-large-v2``, ``multilingual-e5-large-instruct``, ...)
            * ``"mxbai"`` → empty / ``Represent this sentence for
              searching relevant passages: `` (MixedBread AI
              ``mxbai-embed-large-v1``)
            * ``"bge"`` → empty / ``Represent this sentence for
              searching relevant passages: `` (BAAI ``bge-large-en-v1.5``;
              ``bge-m3`` does not need a prefix — use ``"none"`` instead)
            * ``"none"`` (default) → no prefix
    """

    PREFIX_MAP: dict[str, dict[str, str]] = {
        "nomic": {"document": "search_document: ", "query": "search_query: "},
        "cohere": {"document": "search_document: ", "query": "search_query: "},
        "e5": {"document": "passage: ", "query": "query: "},
        "mxbai": {
            "document": "",
            "query": "Represent this sentence for searching relevant passages: ",
        },
        "bge": {
            "document": "",
            "query": "Represent this sentence for searching relevant passages: ",
        },
    }

    def __init__(
        self,
        *,
        base_url: str = "http://localhost:1234/v1",
        model: str = "text-embedding-nomic-embed-text-v1.5",
        dimension: int = 768,
        api_key: str = "not-needed",
        timeout: float = 30.0,
        prefix_style: str = "none",
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._model = model
        self._dimension = dimension
        self._api_key = api_key
        self._timeout = timeout
        self._prefix_style = prefix_style

    def apply_prefix(self, text: str, embedding_type: EmbeddingType) -> str:
        prefixes = self.PREFIX_MAP.get(self._prefix_style)
        if prefixes is None:
            return text
        return prefixes[embedding_type.value] + text

    @property
    def dimension(self) -> int:
        return self._dimension

    async def embed(self, text: str) -> list[float]:
        results = await self.embed_batch([text])
        return results[0]

    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            resp = await client.post(
                f"{self._base_url}/embeddings",
                json={"input": texts, "model": self._model},
                headers={"Authorization": f"Bearer {self._api_key}"},
            )
            resp.raise_for_status()
            data = resp.json()
        # Sort by index to preserve order
        embeddings = sorted(data["data"], key=lambda x: x["index"])
        return [e["embedding"] for e in embeddings]


class OllamaEmbedder(Embedder):
    """Embedder using Ollama's native ``/api/embed`` endpoint.

    Use this when connecting directly to Ollama without the OpenAI
    compatibility layer.

    Example:
        ```python
        embedder = OllamaEmbedder(
            base_url="http://localhost:11434",
            model="nomic-embed-text",
            dimension=768,
            prefix_style="nomic",
        )
        ```

    Args:
        base_url: Ollama server URL.
        model: Model name as shown in ``ollama list``.
        dimension: Expected embedding dimension.
        timeout: HTTP request timeout in seconds.
        prefix_style: Task-type prefix style (same as ``OpenAICompatEmbedder``).
    """

    PREFIX_MAP: dict[str, dict[str, str]] = OpenAICompatEmbedder.PREFIX_MAP

    def __init__(
        self,
        *,
        base_url: str = "http://localhost:11434",
        model: str = "nomic-embed-text",
        dimension: int = 768,
        timeout: float = 30.0,
        prefix_style: str = "none",
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._model = model
        self._dimension = dimension
        self._timeout = timeout
        self._prefix_style = prefix_style

    def apply_prefix(self, text: str, embedding_type: EmbeddingType) -> str:
        prefixes = self.PREFIX_MAP.get(self._prefix_style)
        if prefixes is None:
            return text
        return prefixes[embedding_type.value] + text

    @property
    def dimension(self) -> int:
        return self._dimension

    async def embed(self, text: str) -> list[float]:
        results = await self.embed_batch([text])
        return results[0]

    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            resp = await client.post(
                f"{self._base_url}/api/embed",
                json={"input": texts, "model": self._model},
            )
            resp.raise_for_status()
            data = resp.json()
        return data["embeddings"]


class NullEmbedder(Embedder):
    """Returns zero vectors. For testing and when no provider is configured.

    Args:
        dimension: Vector dimension (default 768).
    """

    def __init__(self, dimension: int = 768) -> None:
        self._dimension = dimension

    @property
    def dimension(self) -> int:
        return self._dimension

    async def embed(self, text: str) -> list[float]:
        return [0.0] * self._dimension

    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        return [[0.0] * self._dimension for _ in texts]


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def create_embedder(
    provider: str,
    *,
    base_url: str = "",
    model: str = "",
    dimension: int = 768,
    api_key: str = "not-needed",
    timeout: float = 30.0,
    prefix_style: str = "none",
) -> Embedder | None:
    """Factory: create an Embedder from config values.

    Args:
        provider: ``"openai-compat"``, ``"ollama"``, or ``"none"``.
        base_url: API base URL.
        model: Model identifier.
        dimension: Embedding dimension.
        api_key: Bearer token (OpenAI-compat only).
        timeout: HTTP timeout in seconds.
        prefix_style: Task-type prefix style. One of ``"nomic"``,
            ``"cohere"``, ``"e5"``, ``"mxbai"``, ``"bge"``, or ``"none"``.
            See ``OpenAICompatEmbedder`` for the per-style mapping.

    Returns:
        An Embedder instance, or ``None`` if provider is ``"none"``.

    Raises:
        ValueError: If the provider is unknown.
    """
    if provider == "none":
        return None
    if provider == "openai-compat":
        return OpenAICompatEmbedder(
            base_url=base_url or "http://localhost:1234/v1",
            model=model or "text-embedding-nomic-embed-text-v1.5",
            dimension=dimension,
            api_key=api_key,
            timeout=timeout,
            prefix_style=prefix_style,
        )
    if provider == "ollama":
        return OllamaEmbedder(
            base_url=base_url or "http://localhost:11434",
            model=model or "nomic-embed-text",
            dimension=dimension,
            timeout=timeout,
            prefix_style=prefix_style,
        )
    raise ValueError(f"Unknown embedder provider: {provider!r}")


# ---------------------------------------------------------------------------
# Serialization helpers for sqlite-vec
# ---------------------------------------------------------------------------


def vec_to_blob(vec: list[float]) -> bytes:
    """Pack a float list into a little-endian binary blob for sqlite-vec.

    Args:
        vec: Embedding vector.

    Returns:
        Binary blob suitable for ``INSERT INTO neuron_vec``.
    """
    return struct.pack(f"{len(vec)}f", *vec)


def blob_to_vec(blob: bytes) -> list[float]:
    """Unpack a sqlite-vec binary blob into a float list.

    Args:
        blob: Binary blob from sqlite-vec.

    Returns:
        List of floats.
    """
    n = len(blob) // 4
    return list(struct.unpack(f"{n}f", blob))
