class PendingInvitationConflictError(Exception):
    pass
