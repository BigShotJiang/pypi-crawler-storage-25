from __future__ import annotations

import typing as t
from dataclasses import field

from query_cache_common.decorators import proto_dataclass
from query_cache_common.models.base import BaseSerDeModel
from query_cache_common.models.converters import dict_to_struct, struct_to_dict
from query_cache_protobuf.query_cache.services import execution_service_pb2


@proto_dataclass(execution_service_pb2.ConfirmExecutionRequest)
class ConfirmExecutionRequest(BaseSerDeModel):
    request_id: str
    last_modified_epoch: t.Optional[int]
    failed_to_clone: bool = False
    table_type: t.Optional[str] = None
    execution_results: t.Dict[str, t.Any] = field(
        default_factory=dict,
        metadata={
            "proto_converter": {
                "from_proto": struct_to_dict,
                "to_proto": dict_to_struct,
            }
        },
    )
    execution_runtime_ms: t.Optional[int] = None
    labels: t.Dict[str, str] = field(default_factory=dict)


@proto_dataclass(execution_service_pb2.ConfirmExecutionResponse)
class ConfirmExecutionResponse(BaseSerDeModel):
    request_id: str
    success: bool
