import pytest

from foff.config import Config


def test_valid_config():
    cfg = Config(api_key="key", base_url="http://localhost", scope="prod")
    cfg.is_valid()


def test_missing_api_key():
    cfg = Config(api_key="", base_url="http://localhost", scope="prod")
    with pytest.raises(ValueError, match="api_key is required"):
        cfg.is_valid()


def test_missing_base_url():
    cfg = Config(api_key="key", base_url="", scope="prod")
    with pytest.raises(ValueError, match="base_url is required"):
        cfg.is_valid()


def test_missing_scope():
    cfg = Config(api_key="key", base_url="http://localhost", scope="")
    with pytest.raises(ValueError, match="scope is required"):
        cfg.is_valid()


def test_default_polling_interval():
    cfg = Config(api_key="key", base_url="http://localhost", scope="prod")
    assert cfg.polling_interval == 30
