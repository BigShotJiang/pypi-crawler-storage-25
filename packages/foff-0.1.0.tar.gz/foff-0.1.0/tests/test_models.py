from foff.models import AllConfigsForScope


def test_from_dict():
    data = {
        "ordered_hierarchy": ["env", "region"],
        "features": {
            "dark_mode": {
                "default": {"enabled": False},
                "prod": {"enabled": True},
            }
        },
    }
    result = AllConfigsForScope.from_dict(data)
    assert result.ordered_hierarchy == ["env", "region"]
    assert result.features["dark_mode"]["prod"] == {"enabled": True}


def test_from_dict_empty():
    result = AllConfigsForScope.from_dict({})
    assert result.ordered_hierarchy == []
    assert result.features == {}
