from unittest.mock import MagicMock, patch

import pytest

from foff.client import Client
from foff.config import Config


def _make_config(**overrides):
    defaults = {
        "api_key": "test-key",
        "base_url": "http://localhost:8080",
        "scope": "test-scope",
        "polling_interval": 0,
    }
    defaults.update(overrides)
    return Config(**defaults)


def _mock_response(data, status_code=200):
    resp = MagicMock()
    resp.status_code = status_code
    resp.json.return_value = data
    resp.text = str(data)
    return resp


_SAMPLE_DATA = {
    "ordered_hierarchy": ["env", "region", "tenant"],
    "features": {
        "dark_mode": {
            "default": {"enabled": False},
            "prod": {"enabled": True},
            "prod#us-east": {"enabled": True, "beta": True},
            "prod#us-east#acme": {"enabled": True, "beta": True, "custom": 1},
        },
        "rate_limit": {
            "default": 100,
        },
    },
}


class TestClientInit:
    @patch("foff.client.httpx.Client")
    def test_invalid_config_raises(self, mock_client_cls):
        with pytest.raises(ValueError):
            Client(Config(api_key="", base_url="http://x", scope="s"))

    @patch("foff.client.httpx.Client")
    def test_failed_fetch_raises(self, mock_client_cls):
        session = mock_client_cls.return_value
        session.get.return_value = _mock_response({}, status_code=500)
        with pytest.raises(RuntimeError, match="unexpected status 500"):
            Client(_make_config())

    @patch("foff.client.httpx.Client")
    def test_failed_fetch_closes_session(self, mock_client_cls):
        session = mock_client_cls.return_value
        session.get.return_value = _mock_response({}, status_code=500)
        with pytest.raises(RuntimeError):
            Client(_make_config())
        session.close.assert_called_once()

    @patch("foff.client.httpx.Client")
    def test_scope_with_reserved_chars_is_encoded(self, mock_client_cls):
        session = mock_client_cls.return_value
        session.get.return_value = _mock_response(_SAMPLE_DATA)
        Client(_make_config(scope="team/a"))
        url = session.get.call_args[0][0]
        assert "/scopes/team%2Fa/configs" in url

    @patch("foff.client.httpx.Client")
    def test_scope_with_hash_is_encoded(self, mock_client_cls):
        session = mock_client_cls.return_value
        session.get.return_value = _mock_response(_SAMPLE_DATA)
        Client(_make_config(scope="scope#1"))
        url = session.get.call_args[0][0]
        assert "/scopes/scope%231/configs" in url

    @patch("foff.client.httpx.Client")
    def test_successful_init(self, mock_client_cls):
        session = mock_client_cls.return_value
        session.get.return_value = _mock_response(_SAMPLE_DATA)
        client = Client(_make_config())
        client.close()
        session.get.assert_called_once()


class TestGetFeatureConfig:
    @patch("foff.client.httpx.Client")
    def setup_method(self, method, mock_client_cls):
        session = mock_client_cls.return_value
        session.get.return_value = _mock_response(_SAMPLE_DATA)
        self.client = Client(_make_config())

    def teardown_method(self, method):
        self.client.close()

    def test_most_specific_match(self):
        result = self.client.get_feature_config(
            "dark_mode", ["prod", "us-east", "acme"]
        )
        assert result == {"enabled": True, "beta": True, "custom": 1}

    def test_partial_hierarchy_match(self):
        result = self.client.get_feature_config(
            "dark_mode", ["prod", "us-east"]
        )
        assert result == {"enabled": True, "beta": True}

    def test_single_level_match(self):
        result = self.client.get_feature_config("dark_mode", ["prod"])
        assert result == {"enabled": True}

    def test_fallback_to_default(self):
        result = self.client.get_feature_config(
            "dark_mode", ["staging", "eu-west"]
        )
        assert result == {"enabled": False}

    def test_nonexistent_feature_returns_none(self):
        result = self.client.get_feature_config(
            "nonexistent", ["prod"]
        )
        assert result is None

    def test_scalar_feature_value(self):
        result = self.client.get_feature_config("rate_limit", ["prod"])
        assert result == 100

    def test_empty_hierarchy_returns_default(self):
        result = self.client.get_feature_config("dark_mode", [])
        assert result == {"enabled": False}


class TestClientContextManager:
    @patch("foff.client.httpx.Client")
    def test_context_manager(self, mock_client_cls):
        session = mock_client_cls.return_value
        session.get.return_value = _mock_response(_SAMPLE_DATA)
        with Client(_make_config()) as client:
            result = client.get_feature_config("dark_mode", ["prod"])
            assert result == {"enabled": True}
        session.close.assert_called_once()
