import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from foff.async_client import AsyncClient
from foff.config import Config


pytestmark = pytest.mark.asyncio


def _make_config(**overrides):
    defaults = {
        "api_key": "test-key",
        "base_url": "http://localhost:8080",
        "scope": "test-scope",
        "polling_interval": 0,
    }
    defaults.update(overrides)
    return Config(**defaults)


def _mock_response(data, status_code=200):
    resp = MagicMock()
    resp.status_code = status_code
    resp.json.return_value = data
    resp.text = str(data)
    return resp


_SAMPLE_DATA = {
    "ordered_hierarchy": ["env", "region", "tenant"],
    "features": {
        "dark_mode": {
            "default": {"enabled": False},
            "prod": {"enabled": True},
            "prod#us-east": {"enabled": True, "beta": True},
            "prod#us-east#acme": {"enabled": True, "beta": True, "custom": 1},
        },
        "rate_limit": {
            "default": 100,
        },
    },
}


def _patch_session(data=_SAMPLE_DATA, status_code=200):
    mock_session = AsyncMock()
    mock_session.get.return_value = _mock_response(data, status_code)
    mock_session.aclose = AsyncMock()
    mock_cls = MagicMock(return_value=mock_session)
    return patch("foff.async_client.httpx.AsyncClient", mock_cls), mock_session


class TestAsyncClientInit:
    async def test_invalid_config_raises(self):
        with pytest.raises(ValueError):
            AsyncClient(Config(api_key="", base_url="http://x", scope="s"))

    async def test_failed_fetch_raises(self):
        patcher, _ = _patch_session(data={}, status_code=500)
        with patcher:
            client = AsyncClient(_make_config())
            with pytest.raises(RuntimeError, match="unexpected status 500"):
                await client.start()

    async def test_failed_fetch_closes_session(self):
        patcher, mock_session = _patch_session(data={}, status_code=500)
        with patcher:
            client = AsyncClient(_make_config())
            with pytest.raises(RuntimeError):
                await client.start()
            mock_session.aclose.assert_called_once()
            assert client._session is None

    async def test_scope_with_reserved_chars_is_encoded(self):
        patcher, mock_session = _patch_session()
        with patcher:
            client = AsyncClient(_make_config(scope="team/a"))
            await client.start()
            url = mock_session.get.call_args[0][0]
            assert "/scopes/team%2Fa/configs" in url
            await client.close()

    async def test_scope_with_hash_is_encoded(self):
        patcher, mock_session = _patch_session()
        with patcher:
            client = AsyncClient(_make_config(scope="scope#1"))
            await client.start()
            url = mock_session.get.call_args[0][0]
            assert "/scopes/scope%231/configs" in url
            await client.close()

    async def test_successful_init(self):
        patcher, mock_session = _patch_session()
        with patcher:
            client = AsyncClient(_make_config())
            await client.start()
            await client.close()
            mock_session.get.assert_called_once()


class TestGetFeatureConfig:
    async def _with_client(self):
        patcher, _ = _patch_session()
        patcher.start()
        self._patcher = patcher
        client = AsyncClient(_make_config())

        class _Ctx:
            async def __aenter__(ctx):
                await client.start()
                return client

            async def __aexit__(ctx, *args):
                await client.close()
                self._patcher.stop()

        return _Ctx()

    async def test_most_specific_match(self):
        async with await self._with_client() as client:
            result = client.get_feature_config(
                "dark_mode", ["prod", "us-east", "acme"]
            )
            assert result == {"enabled": True, "beta": True, "custom": 1}

    async def test_partial_hierarchy_match(self):
        async with await self._with_client() as client:
            result = client.get_feature_config(
                "dark_mode", ["prod", "us-east"]
            )
            assert result == {"enabled": True, "beta": True}

    async def test_single_level_match(self):
        async with await self._with_client() as client:
            result = client.get_feature_config("dark_mode", ["prod"])
            assert result == {"enabled": True}

    async def test_fallback_to_default(self):
        async with await self._with_client() as client:
            result = client.get_feature_config(
                "dark_mode", ["staging", "eu-west"]
            )
            assert result == {"enabled": False}

    async def test_nonexistent_feature_returns_none(self):
        async with await self._with_client() as client:
            result = client.get_feature_config("nonexistent", ["prod"])
            assert result is None

    async def test_scalar_feature_value(self):
        async with await self._with_client() as client:
            result = client.get_feature_config("rate_limit", ["prod"])
            assert result == 100

    async def test_empty_hierarchy_returns_default(self):
        async with await self._with_client() as client:
            result = client.get_feature_config("dark_mode", [])
            assert result == {"enabled": False}


class TestAsyncClientContextManager:
    async def test_context_manager(self):
        patcher, mock_session = _patch_session()
        with patcher:
            async with AsyncClient(_make_config()) as client:
                result = client.get_feature_config("dark_mode", ["prod"])
                assert result == {"enabled": True}
            mock_session.aclose.assert_called_once()
