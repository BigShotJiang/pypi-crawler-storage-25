from dataclasses import dataclass


@dataclass
class Config:
    api_key: str
    base_url: str
    scope: str
    polling_interval: int = 30

    def is_valid(self) -> None:
        if not self.api_key:
            raise ValueError("api_key is required")
        if not self.base_url:
            raise ValueError("base_url is required")
        if not self.scope:
            raise ValueError("scope is required")
