from __future__ import annotations

import asyncio
from typing import Any
from urllib.parse import quote

import httpx

from foff.config import Config
from foff.constants import API_KEY_HEADER, DEFAULT_KEY, HIERARCHY_SEPARATOR, HTTP_TIMEOUT
from foff.models import AllConfigsForScope


class AsyncClient:
    def __init__(self, config: Config) -> None:
        config.is_valid()
        self._config = config
        self._cache: AllConfigsForScope | None = None
        self._lock = asyncio.Lock()
        self._stop_event = asyncio.Event()
        self._poll_task: asyncio.Task[None] | None = None
        self._session: httpx.AsyncClient | None = None

    def _build_url(self) -> str:
        base = self._config.base_url.rstrip("/")
        scope = quote(self._config.scope, safe="")
        return f"{base}/api/v1/scopes/{scope}/configs"

    async def start(self) -> None:
        self._session = httpx.AsyncClient(
            headers={API_KEY_HEADER: self._config.api_key},
            timeout=HTTP_TIMEOUT,
        )
        try:
            await self._fetch_configs()
        except Exception:
            await self._session.aclose()
            self._session = None
            raise
        if self._config.polling_interval > 0:
            self._poll_task = asyncio.create_task(self._poll())

    async def close(self) -> None:
        self._stop_event.set()
        if self._poll_task is not None:
            self._poll_task.cancel()
            try:
                await self._poll_task
            except asyncio.CancelledError:
                pass
        if self._session is not None:
            await self._session.aclose()

    async def __aenter__(self) -> AsyncClient:
        await self.start()
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    async def _fetch_configs(self) -> None:
        assert self._session is not None
        resp = await self._session.get(self._build_url())
        if resp.status_code != 200:
            raise RuntimeError(
                f"foff: unexpected status {resp.status_code}: {resp.text}"
            )
        data = resp.json()
        cache = AllConfigsForScope.from_dict(data)
        async with self._lock:
            self._cache = cache

    async def _poll(self) -> None:
        while not self._stop_event.is_set():
            await asyncio.sleep(self._config.polling_interval)
            try:
                await self._fetch_configs()
            except Exception:
                pass

    def get_feature_config(
        self, feature_name: str, ordered_hierarchy: list[str]
    ) -> Any:
        cache = self._cache
        if cache is None or feature_name not in cache.features:
            return None
        feature = cache.features[feature_name]
        for i in range(len(ordered_hierarchy), 0, -1):
            key = HIERARCHY_SEPARATOR.join(ordered_hierarchy[:i])
            if key in feature:
                return feature[key]
        return feature.get(DEFAULT_KEY)
