from __future__ import annotations

import threading
from typing import Any
from urllib.parse import quote

import httpx

from foff.config import Config
from foff.constants import API_KEY_HEADER, DEFAULT_KEY, HIERARCHY_SEPARATOR, HTTP_TIMEOUT
from foff.models import AllConfigsForScope


class Client:
    def __init__(self, config: Config) -> None:
        config.is_valid()
        self._config = config
        self._session = httpx.Client(
            headers={API_KEY_HEADER: config.api_key},
            timeout=HTTP_TIMEOUT,
        )
        self._lock = threading.Lock()
        self._cache: AllConfigsForScope | None = None
        self._stop_event = threading.Event()
        self._poll_thread: threading.Thread | None = None

        try:
            self._fetch_configs()
        except Exception:
            self._session.close()
            raise

        if config.polling_interval > 0:
            self._poll_thread = threading.Thread(
                target=self._poll, daemon=True
            )
            self._poll_thread.start()

    def _build_url(self) -> str:
        base = self._config.base_url.rstrip("/")
        scope = quote(self._config.scope, safe="")
        return f"{base}/api/v1/scopes/{scope}/configs"

    def _fetch_configs(self) -> None:
        resp = self._session.get(self._build_url())
        if resp.status_code != 200:
            raise RuntimeError(
                f"foff: unexpected status {resp.status_code}: {resp.text}"
            )
        data = resp.json()
        cache = AllConfigsForScope.from_dict(data)
        with self._lock:
            self._cache = cache

    def _poll(self) -> None:
        while not self._stop_event.wait(self._config.polling_interval):
            try:
                self._fetch_configs()
            except Exception:
                pass

    def get_feature_config(
        self, feature_name: str, ordered_hierarchy: list[str]
    ) -> Any:
        with self._lock:
            cache = self._cache
        if cache is None or feature_name not in cache.features:
            return None
        feature = cache.features[feature_name]
        for i in range(len(ordered_hierarchy), 0, -1):
            key = HIERARCHY_SEPARATOR.join(ordered_hierarchy[:i])
            if key in feature:
                return feature[key]
        return feature.get(DEFAULT_KEY)

    def close(self) -> None:
        self._stop_event.set()
        if self._poll_thread is not None:
            self._poll_thread.join()
        self._session.close()

    def __enter__(self) -> Client:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
