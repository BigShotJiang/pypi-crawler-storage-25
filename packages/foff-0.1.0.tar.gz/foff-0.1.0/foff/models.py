from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class AllConfigsForScope:
    ordered_hierarchy: list[str] = field(default_factory=list)
    features: dict[str, dict[str, Any]] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AllConfigsForScope:
        return cls(
            ordered_hierarchy=data.get("ordered_hierarchy", []),
            features=data.get("features", {}),
        )
