# FOFF Feature Config Python SDK

Python SDK for the FOFF Feature Config service. Provides both sync and async clients with built-in caching and background polling.

## Installation

```bash
pip install foff
```

## Quick Start

### Sync Client

```python
from foff import Client, Config

config = Config(
    api_key="your-api-key",
    base_url="https://foff.twospoon.ai/live",
    scope="production",
    polling_interval=30,  # refresh configs every 30 seconds (0 to disable)
)

with Client(config) as client:
    value = client.get_feature_config("dark_mode", ["prod", "us-east", "acme"])
    print(value)  # e.g. {"enabled": True, "beta": True}
```

### Async Client

```python
import asyncio
from foff import AsyncClient, Config

config = Config(
    api_key="your-api-key",
    base_url="https://foff.twospoon.ai/live",
    scope="production",
    polling_interval=30,
)

async def main():
    async with AsyncClient(config) as client:
        value = client.get_feature_config("dark_mode", ["prod", "us-east", "acme"])
        print(value)

asyncio.run(main())
```

## Configuration

| Parameter          | Type  | Required | Default | Description                                      |
|--------------------|-------|----------|---------|--------------------------------------------------|
| `api_key`          | `str` | Yes      |         | API key for authentication                       |
| `base_url`         | `str` | Yes      |         | Base URL of the FOFF service                     |
| `scope`            | `str` | Yes      |         | Scope identifier for your configs                |
| `polling_interval` | `int` | No       | `30`    | Polling interval in seconds (0 disables polling) |

## Feature Lookup

```python
value = client.get_feature_config(feature_name, ordered_hierarchy)
```

- `feature_name` — the name of the feature flag
- `ordered_hierarchy` — a list of hierarchy levels from broadest to most specific

The SDK resolves configs from most specific to least specific. Given `["prod", "us-east", "acme"]`, it checks:

1. `prod#us-east#acme`
2. `prod#us-east`
3. `prod`
4. `default`

Returns the first match, or `None` if the feature doesn't exist.

## Client Lifecycle

### Sync

The `Client` constructor performs a blocking initial fetch. If the fetch fails, an exception is raised and no resources are leaked.

```python
# Context manager (recommended)
with Client(config) as client:
    ...

# Manual
client = Client(config)
try:
    ...
finally:
    client.close()
```

### Async

The `AsyncClient` constructor is lightweight — no network calls. Call `start()` or use `async with` to initialize.

```python
# Context manager (recommended)
async with AsyncClient(config) as client:
    ...

# Manual
client = AsyncClient(config)
await client.start()
try:
    ...
finally:
    await client.close()
```

## Background Polling

When `polling_interval > 0`, the client refreshes configs in the background. Polling errors are silently ignored — the client continues serving the last successfully fetched configs.

Call `close()` (or exit the context manager) to stop polling and release resources.

## Development

```bash
pip install -e ".[dev]"
pytest tests/
```

## Contributing

<!-- TODO: add contribution guidelines (issue tracker, PR process, code of conduct). -->

## License

<!-- TODO: update once a license is chosen in LICENSE. -->
See [LICENSE](LICENSE).
