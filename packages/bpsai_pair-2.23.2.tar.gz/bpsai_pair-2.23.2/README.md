# bpsai-pair

> AI-augmented pair programming framework with 200+ CLI commands

[![PyPI version](https://img.shields.io/pypi/v/bpsai-pair)](https://pypi.org/project/bpsai-pair/)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/license-Proprietary-red.svg)](LICENSE)

## Overview

**bpsai-pair** (PairCoder) is a comprehensive AI pair programming framework that provides structured workflows, enforcement gates, and integrations to ensure AI agents follow proper development practices.

- **Planning & Task Management** — Sprint planning, task lifecycle, Trello sync, and budget tracking
- **Skill-Based Workflows** — 9 built-in skills for TDD, code review, releases, architecture, and more
- **Integration Hub** — Trello, GitHub, MCP servers, and Toggl time tracking
- **Architecture Enforcement** — File size limits, function boundaries, import caps, and auto-split suggestions
- **Telemetry & Feedback** — Session telemetry, self-calibrating estimation, anomaly detection
- **Workspace Orchestration** — Multi-project workspaces, cross-repo contract detection, impact analysis
- **Intelligence Pipeline** — Usage snapshots, value extraction scoring, tamper detection
- **Interactive Setup Wizard** — Web-based project configuration with AI-guided setup
- **Licensing & Security** — Tiered feature gating, secret scanning, containment mode
- **Quality Control** — Browser-based QC with spec format, execution runtime, and gate enforcement
- **Containment Mode** — Tiered file access control via PreToolUse hooks
- **Autonomous Sprint Execution** — `bpsai-pair engage` runs full sprints: branch, tasks, PR, review, observations
- **Machine Interface** — `--json` envelope on all commands for programmatic consumption
- **Health Check** — `bpsai-pair doctor` validates setup with 9 checks and auto-repair
- **Slash Commands** — `/make-it-so` (intent to PR), `/draft-backlog` (engage-compatible backlogs)

## Installation

```bash
# Core installation
pip install bpsai-pair

# With integrations
pip install bpsai-pair[trello]      # Trello board sync
pip install bpsai-pair[github]      # GitHub PR management
pip install bpsai-pair[mcp]         # MCP server support
pip install bpsai-pair[all]         # All extras
```

## Quick Start

```bash
# Initialize a new project
bpsai-pair init

# Or use the interactive wizard
bpsai-pair wizard

# Check project status
bpsai-pair status

# Create a sprint plan
bpsai-pair plan new my-feature --type feature

# Start a task (with Trello sync)
bpsai-pair ttask start TRELLO-123

# Run architecture checks
bpsai-pair arch check

# Pack context for AI assistants
bpsai-pair pack
```

## Key Command Groups

| Group | Commands | Description |
|-------|----------|-------------|
| `plan` | 8 | Sprint planning, task creation, Trello sync |
| `task` | 12 | Task lifecycle, status updates, archival |
| `trello` / `ttask` | 27 | Trello board management, card workflows |
| `github` | 8 | PR creation, merge, auto-archive |
| `skill` | 8 | Workflow skills, export to Cursor/Windsurf |
| `license` | 10 | License management, feature gating |
| `telemetry` | 3 | Session telemetry, privacy config, export |
| `feedback` | 4 | Calibration, accuracy, task-type estimates |
| `workspace` | 5 | Multi-project orchestration, impact analysis |
| `arch` | 2 | Architecture enforcement, split suggestions |
| `budget` | 3 | Token budget tracking, task cost estimates |
| `security` | 4 | Secret scanning, containment mode |
| `qc` | 6 | Quality check specs, execution, reporting |
| `query` | 3 | Cross-agent state and telemetry queries |
| `engage` | 1 | Autonomous sprint execution from backlog |
| `fleet` | 1 | Workspace version compliance checking |
| `release` | 2 | Pre-release validation, version file checking |
| `containment` | 2 | File access enforcement and status |

## License Tiers

| Feature | Solo | Pro | Enterprise |
|---------|:----:|:---:|:----------:|
| Planning & tasks | Y | Y | Y |
| Skills & enforcement | Y | Y | Y |
| Setup wizard | Y | Y | Y |
| Telemetry & feedback | Y | Y | Y |
| Trello integration | | Y | Y |
| GitHub integration | | Y | Y |
| MCP servers | | Y | Y |
| Token budget & cost tracking | | Y | Y |
| Workspace orchestration | | Y | Y |
| Remote access & SSO | | | Y |

Check your license: `bpsai-pair license status`

## What's New

**v2.23.2 -- Hotfix: Engage Lifecycle + CI Test Suite**
- Engage lifecycle hooks pass `--allow-dirty` (dirty-tree guard no longer blocks automated task completion)
- Full CI test suite green: 13,253 tests passing on every push
- `BPSAI_UNLOCK_ALL_FEATURES` env var for CI testing without a license
- `NO_COLOR` in CI prevents Rich ANSI codes from breaking assertions

**v2.23.1 -- Hotfix: Engage Commit Verification + Upgrade Commit**
- Fixed false positive `engage_commit_empty` on every task when repo had a stale CLI version
- Auto-upgrade now commits config artifacts to git (clean tree after upgrade)
- `upgrade --commit` flag for explicit commit after manual upgrade
- `fleet check --upgrade --commit` triggers project upgrade + commit per repo

**v2.23.0 -- Engage Reliability + Hook Intelligence + Resume**
- `engage --resume`: skip completed tasks on retry, no more re-running entire sprints
- Security agent fail-closed for ALL exceptions (not just OSError). Diff piped via temp file.
- Hook failure propagation: tasks no longer silently succeed when hooks fail
- On-disk dependency verification prevents stale in-memory state
- Human-gated tasks: `requires: human` in backlog frontmatter pauses engage
- `--create-branch` / `--branch` flags for branch lifecycle management
- Pre-engage containment audit warns about protected path conflicts
- TaskCompleted verifies meaningful output (empty commits flagged)
- StopFailure blocks next task and surfaces reason
- SubagentStop + TeammateIdle push status to A2A channels
- Pre-task budget heuristic warns before session limits hit
- Review skills use `context: fork` for agent isolation
- Forgiving backlog parser (em dash, double hyphen, single hyphen)
- UTF-8 encoding on all engage subprocess calls (Windows cp1252 fix)
- Full test suite CI on every push to dev/main
- 13,275+ tests passing

**v2.22.1 -- Hotfix: License Activation Auth**
- Machine activation, deactivation, and listing now send the required `X-License-Key` auth header

**v2.22.0 -- Mythology Agent Identity + Vaivora Review Agent**
- All agents use mythology names as identifiers: Nayru (reviewer), Laverna (security auditor), Bellona (pre-execution gatekeeper), Vaivora (cross-module review), Divona (QC)
- Vaivora wired as third review agent for large diffs (>500 lines or >10 files)
- Review pipeline refactored: engage, branch, and PR review use shared dispatch with mythology display names
- REVIEW intent type: "review these PRs" routes to the review skill instead of generic reasoning
- Laverna upgraded to Opus model for complete security findings
- Engage auto-created PRs now target dev branch when dev exists
- 12,844+ tests passing

**v2.21.5 -- Branch Enforcement + Intent Merge Strategy**
- Branch enforcement: source code on main/dev is blocked, docs/state allowed through
- Intent-driven merge strategy: squash vs merge based on work intent and branch pattern
- PR labels (`merge:squash`, `merge:merge`) carry strategy to merge time
- Auto-upgrade stages .paircoder/ files to prevent dirty tree in engage
- Stale containment stash cleanup in engage pre-flight
- 12,500+ tests passing

**v2.21.4 -- Review Command + Targeted Tests + Engage Fixes**
- `bpsai-pair review pr/branch/task`: Python-enforced review dispatch with agent scaling
- Intent sub-classification routes review requests to the right variant
- Engage tasks run targeted tests (seconds) instead of full suite (minutes)
- Engage executor no longer crashes on lifecycle hook failures
- Engage commits exclude .paircoder/ bookkeeping files (no more merge conflicts)
- Agent mythology display names in review dispatch and output
- Error-as-approval bug fixed: failed reviews no longer pass as approvals
- 12,500+ tests passing

**v2.21.3 -- Release Hardening + Engage Review Loop**
- Version downgrade protection: CLI no longer overwrites config with older versions
- `bpsai-pair release validate-versions`: pre-tag gate with `--fix` auto-repair
- `bpsai-pair fleet check`: workspace version compliance with `--upgrade` and `--json`
- Per-task review loop in autonomous sprints with automatic correction
- Pre-PR security gate blocks pull requests with critical findings
- Agent upgrade preserves custom fields (`memory`, `maxTurns`, display names)
- `support open` shows actual error details instead of generic messages
- 12,500+ tests passing

**v2.21.1 -- Remote Session Enforcement**
- SessionStart hook auto-installs PairCoder in remote sessions
- API error surfacing across all license, support, and subscription commands

**v2.21.0 -- Enforcement + Observability**
- Intent recognition and approval gate for autonomous dispatch
- Operational signals: uncommitted code, abandoned sessions, gate blocks
- Protected branch guard: engage refuses to run on main/dev

**v2.20.0 -- Engage Pipeline**
- `bpsai-pair engage` runs full sprints autonomously (branch, tasks, PR, review)
- `/make-it-so` command: intent to shipped PR in one command
- `bpsai-pair doctor` with 9 health checks and `--fix` auto-repair

## Documentation

- [Website & Docs](https://paircoder.ai)
- [Quick Start Guide](https://paircoder.ai/docs/getting-started/)

## Requirements

- Python 3.10 or higher
- Git (for project management features)

## Support

- Email: support@bpsaisoftware.com
