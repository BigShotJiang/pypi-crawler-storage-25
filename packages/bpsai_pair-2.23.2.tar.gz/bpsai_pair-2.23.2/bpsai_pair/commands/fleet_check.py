"""Fleet version compliance check.

RH4: Scans workspace repos for bpsai-pair version compliance.
Registered as `bpsai-pair fleet check`.
"""

from __future__ import annotations

import json as json_mod
import logging
import subprocess
from pathlib import Path
from typing import Optional

import typer
import yaml
from rich.console import Console
from rich.table import Table

logger = logging.getLogger(__name__)
console = Console()

app = typer.Typer(
    help="Fleet management commands",
    context_settings={"help_option_names": ["-h", "--help"]},
    invoke_without_command=True,
)


@app.callback()
def _callback():
    """Fleet management commands."""


def _find_project_root() -> Path:
    """Find project root (.paircoder parent)."""
    from ..core.ops import find_paircoder_dir
    return find_paircoder_dir().parent


def _get_current_version() -> str:
    """Get the current CLI version."""
    from .. import __version__
    return __version__


def _find_pip_path(repo_dir: Path) -> Optional[Path]:
    """Find pip executable in a repo's venv (Unix or Windows)."""
    unix_pip = repo_dir / ".venv" / "bin" / "pip"
    if unix_pip.exists():
        return unix_pip
    win_pip = repo_dir / ".venv" / "Scripts" / "pip.exe"
    if win_pip.exists():
        return win_pip
    return None


def _get_installed_version(repo_dir: Path) -> Optional[str]:
    """Check installed bpsai-pair version in a repo's venv."""
    pip_path = _find_pip_path(repo_dir)
    if pip_path is None:
        return None
    try:
        result = subprocess.run(
            [str(pip_path), "show", "bpsai-pair"],
            capture_output=True, text=True, timeout=15,
        )
        if result.returncode != 0:
            return None
        for line in result.stdout.splitlines():
            if line.startswith("Version:"):
                return line.split(":", 1)[1].strip()
    except Exception:
        pass
    return None


def _is_valid_repo_name(name: str, workspace_root: Path) -> bool:
    """Validate a repo name: no traversal, no dot-prefix, no separators."""
    if not name or name.startswith("."):
        return False
    if ".." in name:
        return False
    # Ensure resolved path stays within workspace
    resolved = (workspace_root / name).resolve()
    if resolved.parent != workspace_root.resolve():
        return False
    return True


def _parse_repo_names(workspace_root: Path) -> list[str]:
    """Extract unique repo directory names from workspace-index.yaml."""
    index_path = workspace_root / "workspace-index.yaml"
    data = yaml.safe_load(index_path.read_text(encoding="utf-8")) or {}
    entries = data.get("entries", [])
    seen: set[str] = set()
    repos: list[str] = []
    for entry in entries:
        path_str = entry.get("path", "")
        parts = path_str.split("/")
        if not parts or not parts[0]:
            continue
        name = parts[0]
        if name in seen:
            continue
        if not _is_valid_repo_name(name, workspace_root):
            logger.warning("Skipping invalid repo name: %s", name)
            continue
        seen.add(name)
        repos.append(name)
    return repos


@app.command("check")
def fleet_check(
    upgrade: bool = typer.Option(False, "--upgrade", help="Upgrade stale venvs"),
    commit: bool = typer.Option(
        False, "--commit", help="Commit upgrade artifacts to git in each repo"
    ),
    json_out: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Check bpsai-pair version compliance across workspace repos."""
    project_root = _find_project_root()
    workspace_root = project_root.parent

    index_path = workspace_root / "workspace-index.yaml"
    if not index_path.exists():
        console.print(
            f"[red]No workspace-index.yaml found at {index_path}[/red]"
        )
        raise typer.Exit(1)

    current = _get_current_version()
    repo_names = _parse_repo_names(workspace_root)

    results: list[dict] = []
    stale: list[dict] = []

    for name in repo_names:
        repo_dir = workspace_root / name
        installed = _get_installed_version(repo_dir)
        compliant = installed == current
        entry = {
            "name": name,
            "installed": installed,
            "compliant": compliant,
        }
        results.append(entry)
        if not compliant:
            stale.append(entry)

    if json_out:
        payload = {
            "current_version": current,
            "repos": results,
            "all_compliant": len(stale) == 0,
        }
        console.print(json_mod.dumps(payload, indent=2))
        raise typer.Exit(0 if not stale else 1)

    console.print(_build_compliance_table(results, current))

    if upgrade and stale:
        _run_upgrades(workspace_root, stale, current, commit=commit)
        # Recompute compliance after upgrades
        still_stale = []
        for entry in results:
            new_ver = _get_installed_version(workspace_root / entry["name"])
            entry["installed"] = new_ver
            entry["compliant"] = new_ver == current
            if not entry["compliant"]:
                still_stale.append(entry)
        stale = still_stale

    _evaluate_compliance(results, stale, upgrade)


def _build_compliance_table(results: list[dict], current: str) -> Table:
    """Build a Rich table showing repo compliance status."""
    table = Table(title=f"Fleet Compliance (current: {current})")
    table.add_column("Repo")
    table.add_column("Installed")
    table.add_column("Status")

    for entry in results:
        ver = entry["installed"] or "N/A (not installed)"
        status = "[green]ok[/green]" if entry["compliant"] else "[red]STALE[/red]"
        table.add_row(entry["name"], ver, status)

    return table


def _evaluate_compliance(
    results: list[dict], stale: list[dict], upgrade: bool,
) -> None:
    """Print compliance summary and exit with appropriate code."""
    if not stale:
        console.print(f"\n[green]All {len(results)} repos compliant.[/green]")
        raise typer.Exit(0)

    console.print(f"\n[red]{len(stale)} repo(s) out of date.[/red]")
    if not upgrade:
        console.print("Run with [cyan]--upgrade[/cyan] to update.")
    raise typer.Exit(1)


def _run_upgrades(
    workspace_root: Path, stale: list[dict], current: str,
    *, commit: bool = False,
) -> None:
    """Run pip install --upgrade bpsai-pair in stale repos."""
    for entry in stale:
        repo_dir = workspace_root / entry["name"]
        pip_path = _find_pip_path(repo_dir)
        if pip_path is None:
            console.print(f"  [yellow]Skip {entry['name']}: no .venv[/yellow]")
            continue
        console.print(f"  Upgrading {entry['name']}...")
        result = subprocess.run(
            [str(pip_path), "install", "--upgrade", "bpsai-pair"],
            capture_output=True, text=True, timeout=120,
        )
        if result.returncode != 0:
            console.print(
                f"  [red]Failed to upgrade {entry['name']}: "
                f"{result.stderr[:200]}[/red]"
            )
            continue
        if commit:
            _trigger_project_upgrade_and_commit(repo_dir, entry["name"], current)


def _trigger_project_upgrade_and_commit(
    repo_dir: Path, repo_name: str, version: str,
) -> None:
    """Run project config upgrade + commit in a repo after pip upgrade."""
    bpsai_pair_path = _find_pip_path(repo_dir)
    if bpsai_pair_path is None:
        return
    # Use the repo's own bpsai-pair to run upgrade --auto --commit
    bin_dir = bpsai_pair_path.parent
    cli_path = bin_dir / "bpsai-pair"
    if not cli_path.exists():
        # Fallback: commit upgrade artifacts directly
        from bpsai_pair.commands.upgrade_prompt import _commit_upgrade_artifacts
        _commit_upgrade_artifacts(repo_dir, version)
        return
    try:
        result = subprocess.run(
            [str(cli_path), "upgrade", "--auto", "--commit"],
            cwd=str(repo_dir),
            capture_output=True, text=True, timeout=120,
        )
        if result.returncode == 0:
            console.print(f"  [green]{repo_name}: upgraded and committed[/green]")
        else:
            console.print(
                f"  [yellow]{repo_name}: upgraded but commit failed[/yellow]"
            )
    except Exception as exc:
        console.print(f"  [yellow]{repo_name}: commit error: {exc}[/yellow]")
