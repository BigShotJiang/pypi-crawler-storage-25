"""Commit verification — post-commit dirty-state signal emission.

Extracted from sprint_executor.py (Reviewer finding #1).
Checks for uncommitted changes after git commit and emits
engage_commit_empty signals when dirty state is detected.
Filters out known churn paths (ER1.4 CHURN_EXCLUSIONS) so that
expected cache/telemetry changes don't trigger false positives.
"""

from __future__ import annotations

import fnmatch
import json
import logging
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path

from bpsai_pair.engage.constants import CHURN_EXCLUSIONS

logger = logging.getLogger(__name__)

# OP-001: Safe task ID pattern
_TASK_ID_PATTERN = re.compile(r"^[A-Za-z0-9._-]+$")

# Runtime artifacts that should not trigger engage_commit_empty.
# Paths are relative to project root, matched as prefixes.
# Includes files intentionally unstaged by sprint_commit._UNSTAGE_PATTERNS
# (config.yaml, capabilities.yaml, state.md) to prevent merge conflicts.
_RUNTIME_ARTIFACT_PREFIXES = (
    ".paircoder/data/",
    ".paircoder/cache/",
    ".paircoder/history/",
    ".paircoder/telemetry/signals.jsonl",
    ".paircoder/telemetry/heartbeat",
    ".paircoder/telemetry/telemetry.jsonl",
    ".paircoder/telemetry/audit.jsonl",
    ".paircoder/telemetry/session_snapshot.json",
    ".paircoder/feedback/calibration.json",
    ".paircoder/.cli_version",
    ".paircoder/context/state.md",
    ".paircoder/config.yaml",
    ".paircoder/capabilities.yaml",
    ".paircoder/data/store.db",
)


def _is_runtime_artifact(entry: str) -> bool:
    """Check if a git status entry is a .paircoder runtime artifact."""
    # git status -z format: "XY path" where XY is 2-char status + space
    path = entry[3:] if len(entry) > 3 else ""
    return any(path == p or path.startswith(p) for p in _RUNTIME_ARTIFACT_PREFIXES)


def _is_churn_path(filepath: str) -> bool:
    """Return True if filepath matches any CHURN_EXCLUSIONS glob pattern."""
    for pattern in CHURN_EXCLUSIONS:
        if fnmatch.fnmatch(filepath, pattern):
            return True
    return False


def _classify_entries(
    entries: list[str], task_id: str,
) -> list[str]:
    """Separate churn from real task entries, log churn count.

    Returns only the non-churn (task) entries.
    git status -z format: ``XY path`` — status code is first 2 chars.
    """
    churn_count = 0
    task_entries: list[str] = []
    for entry in entries:
        filepath = entry[3:]  # skip "XY " status prefix
        if _is_churn_path(filepath):
            churn_count += 1
        else:
            task_entries.append(entry)
    if churn_count:
        logger.info(
            "verify_commit: ignored %d churn file(s) for %s",
            churn_count, task_id,
        )
    return task_entries


def verify_commit(
    project_root: Path,
    task_id: str,
    commit_rc: int,
    commit_stderr: str,
) -> None:
    """Check for uncommitted changes after commit; emit signal if dirty.

    Files matching CHURN_EXCLUSIONS are silently ignored — they represent
    expected cache/telemetry churn, not real uncommitted task output.
    """
    try:
        # OP-002: use -z (null-byte separated) instead of --short
        status = subprocess.run(
            ["git", "status", "-z"],
            cwd=project_root,
            capture_output=True, check=False,
            encoding="utf-8", errors="replace",
        )
        raw = status.stdout
        entries = [e for e in raw.split("\0") if e.strip()]
        # Filter runtime artifacts that are expected to be dirty
        entries = [e for e in entries if not _is_runtime_artifact(e)]
        if not entries:
            return

        task_entries = _classify_entries(entries, task_id)
        if not task_entries:
            return

        # Extract status codes only (first 2 chars), not file paths
        status_codes = [e[:2].strip() for e in task_entries]
        _emit_commit_empty_signal(
            project_root, task_id, status_codes,
            len(task_entries), commit_rc, commit_stderr,
        )
    except Exception as exc:
        logger.warning("Commit verification failed for %s: %s", task_id, exc)


def _emit_commit_empty_signal(
    project_root: Path,
    task_id: str,
    status_codes: list[str],
    file_count: int,
    commit_rc: int,
    commit_stderr: str,
) -> None:
    """Emit engage_commit_empty signal when uncommitted changes remain."""
    # OP-001: validate task_id, strip newlines from all strings
    safe_id = task_id.replace("\n", "").replace("\r", "")
    if not _TASK_ID_PATTERN.match(safe_id):
        safe_id = "INVALID_TASK_ID"
    safe_stderr = commit_stderr.replace("\n", " ").replace("\r", "")

    signals_path = project_root / ".paircoder" / "telemetry" / "signals.jsonl"
    record = {
        "signal_type": "engage_commit_empty",
        "severity": "critical",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "session_id": "",
        "payload": {
            "task_id": safe_id,
            "uncommitted_file_count": file_count,
            "file_list": status_codes[:10],
            "commit_returncode": commit_rc,
            "commit_stderr": safe_stderr,
        },
        "source": "automated",
    }
    signals_path.parent.mkdir(parents=True, exist_ok=True)
    with open(signals_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(record) + "\n")
    logger.warning(
        "engage_commit_empty: %s has %d uncommitted files after commit",
        safe_id, file_count,
    )
