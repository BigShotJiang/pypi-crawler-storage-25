from __future__ import annotations

import asyncio
import platform
import shlex
from typing import Any

from ..base import BaseTool, ToolResult


class ShellTool(BaseTool):
    """Execute shell commands and return their output."""

    name = "shell"
    description = (
        "Execute a shell command and return stdout/stderr. "
        "Input: a command string. "
        "Optional: allowed_commands to restrict which commands can be run."
    )
    parameters = {
        "type": "object",
        "properties": {
            "command": {
                "type": "string",
                "description": "The shell command to execute",
            },
        },
        "required": ["command"],
    }

    def __init__(
        self,
        timeout: int = 30,
        allowed_commands: list[str] | None = None,
    ) -> None:
        self.timeout = timeout
        self.allowed_commands = allowed_commands

    async def run(self, command: str = "", **kwargs: Any) -> ToolResult:
        """Execute the shell command."""
        target = command or kwargs.get("input", "")
        if not target:
            return ToolResult(output="", error="No command provided.")

        try:
            argv = shlex.split(target)
        except ValueError as e:
            return ToolResult(output="", error=f"Invalid command: {e}")

        if not argv:
            return ToolResult(output="", error="No command provided.")

        if self.allowed_commands is not None and argv[0] not in self.allowed_commands:
            return ToolResult(
                output="",
                error=f"Command {argv[0]!r} is not in the allowed list.",
            )

        try:
            # On Windows, use shell=True to support builtins like echo, dir, etc.
            if platform.system() == "Windows":
                proc = await asyncio.create_subprocess_shell(
                    target,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
            else:
                proc = await asyncio.create_subprocess_exec(
                    *argv,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=self.timeout)
            output = stdout.decode() if stdout else ""
            err = stderr.decode() if stderr else ""

            # Ensure subprocess is fully cleaned up
            if proc.returncode is None:
                proc.kill()
                await proc.wait()

            if proc.returncode != 0:
                return ToolResult(
                    output=output,
                    error=f"Exit code {proc.returncode}: {err}".strip(),
                )
            return ToolResult(output=output + err)
        except TimeoutError:
            return ToolResult(output="", error=f"Command timed out after {self.timeout}s.")
        except Exception as e:
            return ToolResult(output="", error=f"Shell error: {e}")
