# Changelog

<!--next-version-placeholder-->

## v0.6.1 (2026-04-03)

### Fix

* Replace M_PI with std::numbers::pi_v for improved precision ([`4af6e76`](https://github.com/louischereau/Hadronis/commit/4af6e767b05e830c5ae482ac7827da4e67d4b04e))
