"""Sync and async clients for the TrustLayer API."""

from __future__ import annotations

import httpx

BASE_URL = "https://api.thetrustlayer.xyz"


class TrustLayer:
    """Synchronous TrustLayer client.

    Usage:
        tl = TrustLayer()
        report = tl.trust("base:1378")
        score = tl.score("ethereum:42")
    """

    def __init__(self, base_url: str = BASE_URL, timeout: float = 30.0):
        self._base_url = base_url.rstrip("/")
        self._client = httpx.Client(timeout=timeout)

    def _get(self, path: str) -> dict:
        resp = self._client.get(f"{self._base_url}{path}")
        resp.raise_for_status()
        return resp.json()

    def trust(self, agent_id: str) -> dict:
        """Full trust forensics: Sybil risk, reviewer quality, cross-chain identity, anomaly flags."""
        return self._get(f"/demo/trust/{agent_id}")

    def score(self, agent_id: str) -> dict:
        """Basic trust score (0-100) with component breakdown."""
        return self._get(f"/demo/trust/{agent_id}")

    def solana(self, address: str) -> dict:
        """Solana wallet trust scoring via Helius analysis."""
        return self._get(f"/solana/{address}")

    def leaderboard(self, chain: str = "all", limit: int = 10) -> dict:
        """Top agents by trust score. Free, rate-limited."""
        return self._get(f"/leaderboard?chain={chain}&limit={limit}")

    def stats(self) -> dict:
        """Network-wide stats: agent counts, chains, Sybil flags."""
        return self._get("/stats")

    def close(self):
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()


class AsyncTrustLayer:
    """Async TrustLayer client for use with asyncio/LangChain/CrewAI.

    Usage:
        async with AsyncTrustLayer() as tl:
            report = await tl.trust("base:1378")
    """

    def __init__(self, base_url: str = BASE_URL, timeout: float = 30.0):
        self._base_url = base_url.rstrip("/")
        self._client = httpx.AsyncClient(timeout=timeout)

    async def _get(self, path: str) -> dict:
        resp = await self._client.get(f"{self._base_url}{path}")
        resp.raise_for_status()
        return resp.json()

    async def trust(self, agent_id: str) -> dict:
        """Full trust forensics: Sybil risk, reviewer quality, cross-chain identity, anomaly flags."""
        return await self._get(f"/demo/trust/{agent_id}")

    async def score(self, agent_id: str) -> dict:
        """Basic trust score (0-100) with component breakdown."""
        return await self._get(f"/demo/trust/{agent_id}")

    async def solana(self, address: str) -> dict:
        """Solana wallet trust scoring via Helius analysis."""
        return await self._get(f"/solana/{address}")

    async def leaderboard(self, chain: str = "all", limit: int = 10) -> dict:
        """Top agents by trust score. Free, rate-limited."""
        return await self._get(f"/leaderboard?chain={chain}&limit={limit}")

    async def stats(self) -> dict:
        """Network-wide stats: agent counts, chains, Sybil flags."""
        return await self._get("/stats")

    async def close(self):
        await self._client.aclose()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()
