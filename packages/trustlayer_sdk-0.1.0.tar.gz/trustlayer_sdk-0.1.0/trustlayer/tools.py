"""LangChain and CrewAI tool wrappers for TrustLayer."""

from __future__ import annotations

from trustlayer.client import TrustLayer

_client = None


def _get_client() -> TrustLayer:
    global _client
    if _client is None:
        _client = TrustLayer()
    return _client


def check_agent_trust(agent_id: str) -> str:
    """Check the trust score and Sybil risk for an AI agent before transacting.

    Args:
        agent_id: Agent ID in chain:id format (e.g. 'base:1378', 'ethereum:42', 'bsc:100')

    Returns:
        Trust report with score (0-100), risk level, Sybil risk, and anomaly flags.
    """
    import json

    report = _get_client().trust(agent_id)
    score = report.get("trust_score", "unknown")
    risk = report.get("risk_level", "unknown")
    sybil = report.get("sybil_risk", "unknown")
    flags = report.get("anomaly_flags", [])
    name = report.get("agent", {}).get("name", agent_id)

    summary = (
        f"Agent: {name} ({agent_id})\n"
        f"Trust Score: {score}/100\n"
        f"Risk Level: {risk}\n"
        f"Sybil Risk: {sybil}\n"
    )
    if flags:
        summary += f"Anomaly Flags: {', '.join(flags)}\n"
    if report.get("recommended_max_exposure_usd") is not None:
        summary += f"Recommended Max Exposure: ${report['recommended_max_exposure_usd']}\n"

    return summary


def get_top_agents(chain: str = "all", limit: int = 10) -> str:
    """Get the top-rated AI agents by trust score.

    Args:
        chain: Filter by chain (base, ethereum, bsc, polygon, monad, solana, or 'all')
        limit: Number of agents to return (max 50)

    Returns:
        Leaderboard of top agents with trust scores.
    """
    data = _get_client().leaderboard(chain=chain, limit=limit)
    agents = data.get("agents", [])
    if not agents:
        return f"No agents found for chain: {chain}"

    lines = [f"Top {len(agents)} agents ({chain}):"]
    for a in agents:
        lines.append(f"  {a.get('name', 'Unknown')} ({a.get('agent_id')}) — score: {a.get('trust_score')}")
    return "\n".join(lines)


# --- LangChain integration ---

def as_langchain_tools():
    """Return TrustLayer tools as LangChain Tool objects.

    Usage:
        from trustlayer.tools import as_langchain_tools
        tools = as_langchain_tools()
        # Add to your agent: agent = create_react_agent(llm, tools)
    """
    from langchain_core.tools import Tool

    return [
        Tool(
            name="check_agent_trust",
            description=(
                "Check the trust score and Sybil risk for an AI agent before transacting. "
                "Input: agent ID in chain:id format (e.g. 'base:1378', 'ethereum:42'). "
                "Returns trust score 0-100, risk level, Sybil risk, and anomaly flags."
            ),
            func=check_agent_trust,
        ),
        Tool(
            name="get_top_agents",
            description=(
                "Get the top-rated AI agents by trust score. "
                "Input: chain name (base, ethereum, bsc, solana, or 'all'). "
                "Returns leaderboard with agent names and scores."
            ),
            func=get_top_agents,
        ),
    ]


# --- CrewAI integration ---

def as_crewai_tools():
    """Return TrustLayer tools as CrewAI Tool objects.

    Usage:
        from trustlayer.tools import as_crewai_tools
        tools = as_crewai_tools()
        # Add to your agent: Agent(tools=tools)
    """
    from crewai.tools import tool

    @tool("Check Agent Trust")
    def crewai_check_trust(agent_id: str) -> str:
        """Check trust score and Sybil risk for an AI agent. Input: agent ID like 'base:1378'."""
        return check_agent_trust(agent_id)

    @tool("Get Top Agents")
    def crewai_top_agents(chain: str = "all") -> str:
        """Get top-rated AI agents by trust score. Input: chain name like 'base' or 'all'."""
        return get_top_agents(chain=chain)

    return [crewai_check_trust, crewai_top_agents]
