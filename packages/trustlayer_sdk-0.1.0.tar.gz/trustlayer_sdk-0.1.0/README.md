# trustlayer

Reputation intelligence for AI agents. Trust scores, Sybil detection, and cross-chain identity resolution for 133K+ agents across 20 blockchains.

## Install

```bash
pip install trustlayer
```

With LangChain support:
```bash
pip install trustlayer[langchain]
```

With CrewAI support:
```bash
pip install trustlayer[crewai]
```

## Quick Start

```python
from trustlayer import TrustLayer

tl = TrustLayer()
report = tl.trust("base:1378")
print(report["trust_score"])      # 73
print(report["sybil_risk"])       # "medium"
print(report["risk_level"])       # "medium"
```

### Async

```python
from trustlayer import AsyncTrustLayer

async with AsyncTrustLayer() as tl:
    report = await tl.trust("base:1378")
```

## LangChain

```python
from trustlayer.tools import as_langchain_tools

tools = as_langchain_tools()
# Add to your agent
agent = create_react_agent(llm, tools)
```

## CrewAI

```python
from trustlayer.tools import as_crewai_tools

tools = as_crewai_tools()
# Add to your agent
agent = Agent(role="Risk Analyst", tools=tools)
```

## Standalone Tool Functions

```python
from trustlayer.tools import check_agent_trust, get_top_agents

# Check before transacting with an agent
print(check_agent_trust("base:1378"))
# Agent: QuickNick (base:1378)
# Trust Score: 73/100
# Risk Level: medium
# Sybil Risk: medium

# Get top agents
print(get_top_agents("base", limit=5))
```

## API Methods

| Method | Description | Rate Limit |
|--------|-------------|------------|
| `trust(agent_id)` | Full Sybil forensics report | 5 req/hr (free demo) |
| `score(agent_id)` | Basic trust score | 5 req/hr (free demo) |
| `solana(address)` | Solana wallet scoring | x402 $0.001 |
| `leaderboard(chain, limit)` | Top agents | 5 req/hr |
| `stats()` | Network stats | Unlimited |

Agent IDs use `chain:id` format: `base:1378`, `ethereum:42`, `bsc:100`, `polygon:56`, `monad:1000`.

## Links

- API docs: https://api.thetrustlayer.xyz/openapi.json
- Website: https://thetrustlayer.xyz
- MCP server: https://api.thetrustlayer.xyz/mcp
