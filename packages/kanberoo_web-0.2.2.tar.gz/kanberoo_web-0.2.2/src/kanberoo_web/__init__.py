"""
This package has been renamed to kanbaroo-web.

Install kanbaroo-web instead: pip install kanbaroo-web
"""

import warnings

warnings.warn(
    "The 'kanberoo-web' package has been renamed to 'kanbaroo-web'. "
    "Please update your installation: pip install kanbaroo-web",
    DeprecationWarning,
    stacklevel=2,
)

__version__ = "0.2.2"
