# `kanberoo-web` has been renamed

This package has been renamed to [`kanbaroo-web`](https://pypi.org/project/kanbaroo-web/). The name is a portmanteau of `kangaroo` + `kanban`; the middle letter should have been `a` from the start.

## What to install

```
pip install kanbaroo-web
```

## Compatibility

This `kanberoo-web` package remains on PyPI as a version-`0.2.2` compatibility stub that transitively installs `kanbaroo-web==0.2.2`. `pip install kanberoo-web` still works; the canonical name going forward is `kanbaroo-web`. Please update your requirements files and scripts.

## Links

- New package: https://pypi.org/project/kanbaroo-web/
- GitHub: https://github.com/areese801/kanbaroo
