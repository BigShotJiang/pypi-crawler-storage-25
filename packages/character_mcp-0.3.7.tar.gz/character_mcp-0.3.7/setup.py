from __future__ import annotations

import subprocess
from pathlib import Path

from setuptools import setup
from setuptools.command.build_py import build_py as _build_py

VERSION = "0.3.3"


def _git_commit() -> str:
    try:
        return subprocess.check_output(["git", "rev-parse", "--short=12", "HEAD"], cwd=Path(__file__).parent, text=True).strip()
    except Exception:
        return "unknown"


class build_py(_build_py):
    def run(self) -> None:
        super().run()
        target = Path(self.build_lib) / "character_mcp" / "_build.py"
        target.write_text(
            f'VERSION = "{VERSION}"\nGIT_COMMIT = "{_git_commit()}"\n',
            encoding="utf-8",
        )


setup(cmdclass={"build_py": build_py})
