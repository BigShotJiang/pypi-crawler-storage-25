from character_mcp import __git_commit__, __version__, format_build_info, get_build_info


def test_build_info_surface_is_available():
    info = get_build_info()

    assert info["version"] == __version__
    assert info["git_commit"] == __git_commit__
    assert format_build_info().startswith(__version__)
