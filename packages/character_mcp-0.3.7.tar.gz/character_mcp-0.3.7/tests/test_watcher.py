import shutil

from character_mcp.service import CharacterService
from character_mcp.watcher import PollingEntityWatcher


def test_watcher_detects_file_change_and_triggers_rescan(sample_root, tmp_path, monkeypatch):
    root = tmp_path / "characters_root"
    shutil.copytree(sample_root, root)

    service = CharacterService(root)
    watcher = PollingEntityWatcher(service, interval=0.01)
    calls = {"count": 0}

    original_rescan = service.rescan

    def wrapped_rescan():
        calls["count"] += 1
        original_rescan()

    monkeypatch.setattr(service, "rescan", wrapped_rescan)

    assert watcher.poll_once() is False

    voice_file = root / "characters" / "dara" / "voice.md"
    voice_file.write_text("# Voice\n\nUpdated voice.\n", encoding="utf-8")

    assert watcher.poll_once() is True
    assert calls["count"] == 1
