from character_mcp.loader import load_entities


def test_load_entities_returns_valid_entities_and_load_errors(sample_root):
    result = load_entities(sample_root)

    assert len(result.entities) == 3
    assert len(result.errors) == 1

    dara = next(entity for entity in result.entities if entity.id == "dara")
    assert dara.type == "character"
    assert dara.files["identity"].name == "identity.md"
    assert dara.relationships[0].target_id == "obsidian-sanctuary"

    assert result.errors[0].entity_dir.name == "bad-yaml"


def test_schema_validation_rejects_invalid_character_without_status(sample_root, tmp_path):
    invalid_root = tmp_path / "characters_root"
    entity_dir = invalid_root / "characters" / "no-status"
    entity_dir.mkdir(parents=True)
    (entity_dir / "entity.yaml").write_text(
        """
        schema_version: 1
        id: no-status
        type: character
        name: No Status
        files:
          identity: identity.md
        """,
        encoding="utf-8",
    )
    (entity_dir / "identity.md").write_text("# Identity\n", encoding="utf-8")

    result = load_entities(invalid_root)

    assert len(result.entities) == 0
    assert len(result.errors) == 1
    assert "schema validation failed" in result.errors[0].message
