import asyncio
from pathlib import Path

import pytest

from character_mcp.server import build_runtime, build_server, resolve_root


EXPECTED_TOOLS = {
    "get_dataset_status",
    "initialize_character_root",
    "start_existing_character_import",
    "get_server_build_info",
    "list_entities",
    "get_entity_summary",
    "list_entity_facets",
    "get_entity_facet",
    "list_entity_relationships",
    "get_related_entities",
    "get_visual_profile",
    "get_character_gap_report",
    "get_character_agent_binding",
    "doctor_entity_index",
    "rescan_entities",
    "create_entity",
    "start_character_intake",
    "get_character_intake_status",
    "get_character_intake_next_step",
    "suggest_next_character_questions",
    "apply_character_intake_answers",
    "link_character_agent",
    "update_entity_yaml",
    "write_entity_facet",
    "add_relationship",
    "append_entity_alias",
    "add_asset_reference",
    "update_visual_profile",
}


def test_build_server_registers_expected_tools(sample_root):
    server = build_server(sample_root)

    tool_names = {tool.name for tool in asyncio.run(server.list_tools())}

    assert EXPECTED_TOOLS <= tool_names


def test_build_runtime_can_enable_watcher(sample_root):
    runtime = build_runtime(sample_root, watch=True, watch_interval=0.01)

    assert runtime.watcher is not None
    assert runtime.watcher.interval == 0.01


def test_runtime_writes_trace_file_on_tool_call(sample_root):
    runtime = build_runtime(sample_root)

    asyncio.run(runtime.server.call_tool("get_entity_summary", {"entity_id": "dara"}))

    trace_text = runtime.trace.path.read_text(encoding="utf-8")
    assert '"tool": "get_entity_summary"' in trace_text
    assert '"entity_id": "dara"' in trace_text


def test_resolve_root_prefers_explicit_value(sample_root, monkeypatch):
    monkeypatch.setenv("CHARACTER_MCP_ROOT", "/tmp/ignored")

    resolved = resolve_root(sample_root)

    assert resolved == Path(sample_root).resolve()


def test_resolve_root_reads_env(monkeypatch, tmp_path):
    monkeypatch.setenv("CHARACTER_MCP_ROOT", str(tmp_path))

    resolved = resolve_root()

    assert resolved == tmp_path.resolve()


def test_resolve_root_requires_value(monkeypatch):
    monkeypatch.delenv("CHARACTER_MCP_ROOT", raising=False)

    with pytest.raises(ValueError):
        resolve_root()
