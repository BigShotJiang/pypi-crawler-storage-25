import shutil
import yaml
from character_mcp.loader import load_entities
from character_mcp.validator import validate_load_result


def test_validator_reports_load_error_missing_relationship_target_and_type_warning(sample_root):
    result = load_entities(sample_root)
    issues = validate_load_result(result)

    issue_map = {(issue.code, issue.entity_id) for issue in issues}

    assert ("load-error", None) in issue_map
    assert ("unknown-relationship-target", "broken-target") in issue_map
    assert ("unexpected-status", "obsidian-sanctuary") in issue_map


def test_validator_reports_only_gap_warnings_for_valid_character_entity(sample_root):
    result = load_entities(sample_root)
    issues = validate_load_result(result)

    dara_issues = [issue for issue in issues if issue.entity_id == "dara"]
    assert {(issue.code, issue.level) for issue in dara_issues} == {("thin-facet-content", "warning")}


def test_validator_reports_duplicate_relationship(sample_root, tmp_path):
    import shutil

    root = tmp_path / "characters_root"
    shutil.copytree(sample_root, root)
    shutil.rmtree(root / "characters" / "bad-yaml")
    (root / "characters" / "broken-target" / "entity.yaml").write_text("""schema_version: 1
id: broken-target
type: character
name: Broken Target
status: active
facets:
  - identity
files:
  identity: identity.md
relationships:
  - target_id: obsidian-sanctuary
    kind: knows
""", encoding="utf-8")
    entity_path = root / "characters" / "dara" / "entity.yaml"
    payload = yaml.safe_load(entity_path.read_text(encoding="utf-8"))
    payload["relationships"] = [
        {"target_id": "obsidian-sanctuary", "kind": "inhabits"},
        {"target_id": "obsidian-sanctuary", "kind": "inhabits"},
    ]
    entity_path.write_text(yaml.safe_dump(payload, sort_keys=False), encoding="utf-8")

    result = load_entities(root)
    issues = validate_load_result(result)

    assert any(issue.code == "duplicate-relationship" and issue.entity_id == "dara" for issue in issues)


def test_validator_warns_on_broad_character_facets(sample_root, tmp_path):
    root = tmp_path / "characters_root"
    shutil.copytree(sample_root, root)
    shutil.rmtree(root / "characters" / "bad-yaml")
    (root / "characters" / "broken-target" / "entity.yaml").write_text("""schema_version: 1
id: broken-target
type: character
name: Broken Target
status: active
facets:
  - identity
files:
  identity: identity.md
relationships:
  - target_id: obsidian-sanctuary
    kind: knows
""", encoding="utf-8")
    entity_path = root / "characters" / "dara" / "entity.yaml"
    payload = yaml.safe_load(entity_path.read_text(encoding="utf-8"))
    payload["facets"].append("wardrobe")
    payload["files"]["wardrobe"] = "wardrobe.md"
    (root / "characters" / "dara" / "wardrobe.md").write_text("# Wardrobe\n\nOne file for many outfits.\n", encoding="utf-8")
    entity_path.write_text(yaml.safe_dump(payload, sort_keys=False), encoding="utf-8")

    result = load_entities(root)
    issues = validate_load_result(result)

    assert any(issue.code == "broad-character-facet" and issue.entity_id == "dara" for issue in issues)


def test_validator_warns_on_location_data_in_character_facet(sample_root, tmp_path):
    root = tmp_path / "characters_root"
    shutil.copytree(sample_root, root)
    shutil.rmtree(root / "characters" / "bad-yaml")
    (root / "characters" / "broken-target" / "entity.yaml").write_text("""schema_version: 1
id: broken-target
type: character
name: Broken Target
status: active
facets:
  - identity
files:
  identity: identity.md
relationships:
  - target_id: obsidian-sanctuary
    kind: knows
""", encoding="utf-8")
    facet_path = root / "characters" / "dara" / "lore.md"
    facet_path.write_text(
        "# Lore\n\nThe building is located in the district near the palace. "
        "The corridor leads north of the tower. The chamber is bordered by the old quarter.",
        encoding="utf-8",
    )
    entity_path = root / "characters" / "dara" / "entity.yaml"
    payload = yaml.safe_load(entity_path.read_text(encoding="utf-8"))
    payload["facets"].append("lore")
    payload["files"]["lore"] = "lore.md"
    entity_path.write_text(yaml.safe_dump(payload, sort_keys=False), encoding="utf-8")

    result = load_entities(root)
    issues = validate_load_result(result)
    assert any(issue.code == "location-data-in-character-facet" and issue.entity_id == "dara" for issue in issues)


def test_validator_warns_on_object_data_in_character_facet(sample_root, tmp_path):
    root = tmp_path / "characters_root"
    shutil.copytree(sample_root, root)
    shutil.rmtree(root / "characters" / "bad-yaml")
    (root / "characters" / "broken-target" / "entity.yaml").write_text("""schema_version: 1
id: broken-target
type: character
name: Broken Target
status: active
facets:
  - identity
files:
  identity: identity.md
relationships:
  - target_id: obsidian-sanctuary
    kind: knows
""", encoding="utf-8")
    facet_path = root / "characters" / "dara" / "gear.md"
    facet_path.write_text(
        "# Gear\n\nThe blade was forged from obsidian. The hilt is crafted from "
        "silverwood, inlaid with runes. The artifact weighs about two kilograms.",
        encoding="utf-8",
    )
    entity_path = root / "characters" / "dara" / "entity.yaml"
    payload = yaml.safe_load(entity_path.read_text(encoding="utf-8"))
    payload["facets"].append("gear")
    payload["files"]["gear"] = "gear.md"
    entity_path.write_text(yaml.safe_dump(payload, sort_keys=False), encoding="utf-8")

    result = load_entities(root)
    issues = validate_load_result(result)
    assert any(issue.code == "object-data-in-character-facet" and issue.entity_id == "dara" for issue in issues)


def test_validator_warns_on_place_with_no_character_back_link(sample_root, tmp_path):
    root = tmp_path / "characters_root"
    shutil.copytree(sample_root, root)
    shutil.rmtree(root / "characters" / "bad-yaml")
    shutil.rmtree(root / "characters" / "broken-target")
    # Remove the relationship from dara so obsidian-sanctuary becomes unreferenced
    entity_path = root / "characters" / "dara" / "entity.yaml"
    payload = yaml.safe_load(entity_path.read_text(encoding="utf-8"))
    payload["relationships"] = []
    entity_path.write_text(yaml.safe_dump(payload, sort_keys=False), encoding="utf-8")

    result = load_entities(root)
    issues = validate_load_result(result)
    assert any(issue.code == "no-character-back-link" and issue.entity_id == "obsidian-sanctuary" for issue in issues)
