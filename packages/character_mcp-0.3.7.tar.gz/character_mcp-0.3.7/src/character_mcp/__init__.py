"""Character MCP package."""

from .version import __git_commit__, __version__, format_build_info, get_build_info

__all__ = [
    "__version__",
    "__git_commit__",
    "get_build_info",
    "format_build_info",
]
