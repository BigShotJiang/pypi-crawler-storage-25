from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class ToolTrace:
    def __init__(self, root: str | Path):
        self.root = Path(root).expanduser().resolve()
        self.path = self.root / ".character-mcp-trace.jsonl"
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def log(self, *, tool: str, status: str, arguments: dict[str, Any], result: Any | None = None, error: str | None = None) -> None:
        payload = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "tool": tool,
            "status": status,
            "arguments": self._sanitize(arguments),
        }
        if result is not None:
            payload["result"] = self._sanitize(result)
        if error is not None:
            payload["error"] = error
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(payload, ensure_ascii=True) + "\n")

    def _sanitize(self, value: Any) -> Any:
        if isinstance(value, str):
            return value if len(value) <= 240 else value[:237] + "..."
        if isinstance(value, Path):
            return str(value)
        if isinstance(value, dict):
            return {str(key): self._sanitize(val) for key, val in value.items()}
        if isinstance(value, list):
            return [self._sanitize(item) for item in value]
        return value
