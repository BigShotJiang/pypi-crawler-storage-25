from __future__ import annotations

import json
import logging
import logging.handlers
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def _log_path() -> Path:
    return Path.home() / ".character-mcp" / "debug.log"


class _NdjsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        return json.dumps(record.msg, default=str)


def _build_logger() -> logging.Logger:
    log_path = _log_path()
    log_path.parent.mkdir(parents=True, exist_ok=True)

    logger = logging.getLogger("character_mcp.debug")
    logger.setLevel(logging.DEBUG)
    logger.propagate = False

    if not logger.handlers:
        handler = logging.handlers.RotatingFileHandler(
            log_path,
            maxBytes=5 * 1024 * 1024,
            backupCount=2,
            encoding="utf-8",
        )
        handler.setFormatter(_NdjsonFormatter())
        logger.addHandler(handler)

    return logger


class DebugLog:
    """Optional per-call logger. All methods are no-ops when disabled."""

    def __init__(self, enabled: bool, level: str = "info", root: str | Path | None = None):
        self._logger = _build_logger() if enabled else None
        self._verbose = level.lower() == "debug"
        self._root = str(root) if root is not None else None

    @property
    def enabled(self) -> bool:
        return self._logger is not None

    def record(
        self,
        tool: str,
        arguments: dict[str, Any],
        *,
        result: Any = None,
        error: str | None = None,
        duration_ms: float,
    ) -> None:
        if self._logger is None:
            return
        entry: dict[str, Any] = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "tool": tool,
            "args": arguments,
            "duration_ms": round(duration_ms, 1),
        }
        if self._root is not None:
            entry["root"] = self._root
        if error is not None:
            entry["error"] = error
        else:
            entry["result_hint"] = _result_hint(result)
            if self._verbose:
                entry["result"] = result
        self._logger.info(entry)


def _result_hint(result: Any) -> dict[str, Any]:
    if result is None:
        return {"type": "null"}
    if isinstance(result, str):
        return {"type": "str", "len": len(result)}
    if isinstance(result, list):
        return {"type": "list", "count": len(result)}
    if isinstance(result, dict):
        keys = list(result.keys())
        hint: dict[str, Any] = {"type": "dict", "keys": keys}
        for key in ("related_entities", "character_essentials"):
            if key in result and isinstance(result[key], list):
                hint[key + "_count"] = len(result[key])
        return hint
    return {"type": type(result).__name__}
