from __future__ import annotations

import json
from functools import lru_cache
from importlib import resources
from typing import Any

from jsonschema import Draft202012Validator


@lru_cache(maxsize=1)
def entity_validator() -> Draft202012Validator:
    schema_text = resources.files("character_mcp.schemas").joinpath("entity.schema.json").read_text(encoding="utf-8")
    schema = json.loads(schema_text)
    return Draft202012Validator(schema)


def validate_entity_payload(payload: Any) -> list[str]:
    validator = entity_validator()
    errors = sorted(validator.iter_errors(payload), key=lambda err: list(err.absolute_path))
    messages: list[str] = []
    for error in errors:
        location = ".".join(str(part) for part in error.absolute_path)
        if location:
            messages.append(f"{location}: {error.message}")
        else:
            messages.append(error.message)
    return messages
