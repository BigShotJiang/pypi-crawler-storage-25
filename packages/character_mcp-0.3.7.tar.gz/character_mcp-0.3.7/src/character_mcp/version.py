from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version as package_version

from ._build import GIT_COMMIT as _BUILD_GIT_COMMIT


def _resolved_version() -> str:
    try:
        return package_version("character-mcp")
    except PackageNotFoundError:
        pass
    # Running from source without installing — read pyproject.toml
    try:
        import tomllib
        from pathlib import Path
        pyproject = Path(__file__).parent.parent.parent / "pyproject.toml"
        with open(pyproject, "rb") as f:
            return tomllib.load(f)["project"]["version"]
    except Exception:
        return "dev"


__version__ = _resolved_version()
__git_commit__ = _BUILD_GIT_COMMIT


def get_build_info() -> dict[str, str]:
    return {"version": __version__, "git_commit": __git_commit__}


def format_build_info() -> str:
    if __git_commit__ and __git_commit__ != "unknown":
        return f"{__version__} ({__git_commit__})"
    return __version__
