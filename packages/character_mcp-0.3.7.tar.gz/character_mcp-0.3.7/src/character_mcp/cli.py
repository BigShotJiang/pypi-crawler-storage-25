from __future__ import annotations

import argparse
import json
from pathlib import Path

from .service import CharacterService, EntityNotFoundError, FacetNotFoundError
from .writer import WriteError
from .version import format_build_info


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="character-mcp")
    parser.add_argument("--version", action="version", version=f"%(prog)s {format_build_info()}")
    subparsers = parser.add_subparsers(dest="command", required=True)

    doctor = subparsers.add_parser("doctor", help="Validate an external character data root")
    doctor.add_argument("root", type=Path, help="Path to the character data root")
    doctor.add_argument("--json", action="store_true", help="Emit JSON output")
    doctor.add_argument("--fix-filenames", action="store_true", help="Rename legacy underscore facet files to kebab-case")

    roster = subparsers.add_parser("list", help="List entities from an external character data root")
    roster.add_argument("root", type=Path, help="Path to the character data root")
    roster.add_argument("--type", dest="entity_type", help="Filter by entity type")

    summary = subparsers.add_parser("summary", help="Show one entity summary")
    summary.add_argument("root", type=Path)
    summary.add_argument("entity_id")

    facets = subparsers.add_parser("facets", help="List facets for one entity")
    facets.add_argument("root", type=Path)
    facets.add_argument("entity_id")

    show = subparsers.add_parser("show", help="Show one facet markdown document")
    show.add_argument("root", type=Path)
    show.add_argument("entity_id")
    show.add_argument("facet")

    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    service = CharacterService(args.root)

    if args.command == "doctor":
        return _doctor(service, emit_json=args.json, fix_filenames=args.fix_filenames)
    if args.command == "list":
        return _list_entities(service, entity_type=args.entity_type)
    if args.command == "summary":
        return _summary(service, args.entity_id)
    if args.command == "facets":
        return _facets(service, args.entity_id)
    if args.command == "show":
        return _show(service, args.entity_id, args.facet)

    parser.error(f"unknown command: {args.command}")
    return 2


def _doctor(service: CharacterService, emit_json: bool, fix_filenames: bool = False) -> int:
    if fix_filenames:
        _fix_legacy_filenames(service, emit_json)
        service.rescan()
    report = service.doctor_report()
    payload = {
        "entity_count": report.entity_count,
        "load_error_count": report.load_error_count,
        "issue_count": report.issue_count,
        "error_count": report.error_count,
        "warning_count": report.warning_count,
        "issues": [
            {
                "level": issue.level,
                "entity_id": issue.entity_id,
                "file": str(issue.file) if issue.file else None,
                "code": issue.code,
                "message": issue.message,
            }
            for issue in report.issues
        ],
    }

    if emit_json:
        print(json.dumps(payload, indent=2))
    else:
        print(
            f"entities={report.entity_count} load_errors={report.load_error_count} "
            f"errors={report.error_count} warnings={report.warning_count}"
        )
        for issue in report.issues:
            location = issue.entity_id or "<load>"
            print(f"[{issue.level}] {location} {issue.code}: {issue.message}")

    return 1 if report.error_count else 0


def _fix_legacy_filenames(service: CharacterService, emit_json: bool) -> None:
    from .validator import FACET_PATTERN
    results = []
    for summary in service.list_entities():
        entity = service._entities.get(summary.id)
        if entity is None:
            continue
        needs_fix = any(not FACET_PATTERN.match(f) for f in list(entity.files) + list(entity.facets))
        if not needs_fix:
            continue
        try:
            result = service._writer.fix_legacy_facet_names(entity)
            results.append(result)
        except WriteError as exc:
            results.append({"status": "error", "entity_id": summary.id, "error": str(exc)})

    if emit_json:
        print(json.dumps({"fix_filenames": results}, indent=2))
    else:
        if not results:
            print("No legacy underscore filenames found.")
        else:
            for result in results:
                if result.get("status") == "error":
                    print(f"[error] {result['entity_id']}: {result['error']}")
                else:
                    for rename in result.get("renames", []):
                        print(f"renamed {result['entity_id']}: {rename['from']} -> {rename['to']}")


def _list_entities(service: CharacterService, entity_type: str | None) -> int:
    for entity in service.list_entities(entity_type=entity_type):
        print(f"{entity.type}:{entity.id} {entity.name}")
    return 0


def _summary(service: CharacterService, entity_id: str) -> int:
    try:
        entity = service.get_entity_summary(entity_id)
    except EntityNotFoundError as exc:
        print(str(exc))
        return 1

    print(json.dumps(entity.__dict__, indent=2))
    return 0


def _facets(service: CharacterService, entity_id: str) -> int:
    try:
        for facet in service.list_entity_facets(entity_id):
            print(facet)
    except EntityNotFoundError as exc:
        print(str(exc))
        return 1
    return 0


def _show(service: CharacterService, entity_id: str, facet: str) -> int:
    try:
        document = service.get_entity_facet(entity_id, facet)
    except (EntityNotFoundError, FacetNotFoundError) as exc:
        print(str(exc))
        return 1

    print(document.content)
    return 0
