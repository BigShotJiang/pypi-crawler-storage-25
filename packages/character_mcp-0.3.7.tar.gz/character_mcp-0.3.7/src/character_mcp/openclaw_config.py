from __future__ import annotations

import json
from pathlib import Path


class OpenClawConfig:
    def __init__(self, path: str | Path | None = None):
        self.path = Path(path).expanduser().resolve() if path else Path.home() / ".openclaw" / "openclaw.json"

    def agent_ids(self) -> set[str]:
        if not self.path.exists():
            return set()
        try:
            payload = json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            return set()
        agents = payload.get("agents", {}).get("list", [])
        ids = {agent.get("id") for agent in agents if isinstance(agent, dict) and isinstance(agent.get("id"), str)}
        default_agent = payload.get("acp", {}).get("defaultAgent")
        if isinstance(default_agent, str):
            ids.add(default_agent)
        return {agent_id for agent_id in ids if agent_id}
