from __future__ import annotations

import re

from .models import (
    ALLOWED_FACETS_BY_TYPE,
    Entity,
    LoadResult,
    REQUIRED_FIELDS_BY_TYPE,
    VALID_ENTITY_TYPES,
    ValidationIssue,
)

ID_PATTERN = re.compile(r"^[a-z0-9]+(?:[-_][a-z0-9]+)*$")
FACET_PATTERN = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
CORE_FACETS_BY_TYPE = {
    "character": {"identity", "appearance", "voice"},
    "place": {"profile"},
    "object": {"profile"},
}
BROAD_CHARACTER_FACETS = {"rituals", "wardrobe", "outfits", "rituals-and-wardrobe"}

LOCATION_CONTENT_SIGNALS = [
    "coordinates", "latitude", "longitude", "floor plan",
    "situated at", "located at", "located in", "located near",
    "bordered by", "north of", "south of", "east of", "west of",
    "the building", "the tower", "the palace", "the castle", "the fortress",
    "the district", "the quarter", "the neighborhood",
    "the entrance", "the corridor", "the hallway", "the chamber",
    "architecture", "the layout", "ground floor", "upper level",
]
OBJECT_CONTENT_SIGNALS = [
    "crafted from", "made of", "forged in", "forged from",
    "carved from", "carved out of",
    "the blade", "the hilt", "the pendant", "the amulet",
    "the artifact", "the relic", "the talisman", "the weapon",
    "inlaid with", "encrusted with", "enchanted with", "imbued with",
    "inches long", "centimeters long", "weighs ", "weight:", "dimensions:",
]
_MISPLACEMENT_THRESHOLD = 5
ALLOWED_TOP_LEVEL_KEYS = {
    "schema_version",
    "id",
    "type",
    "name",
    "aliases",
    "status",
    "tags",
    "summary",
    "facets",
    "files",
    "assets",
    "visual",
    "relationships",
    "integration",
    "metadata",
}


def validate_load_result(result: LoadResult) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    issues.extend(_load_errors_to_issues(result))
    issues.extend(validate_entities(result.entities))
    return issues


def validate_entities(entities: list[Entity]) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    ids: dict[str, Entity] = {}

    for entity in entities:
        issues.extend(validate_entity(entity))
        if entity.id in ids:
            issues.append(
                ValidationIssue(
                    level="error",
                    entity_id=entity.id,
                    file=entity.entity_file,
                    code="duplicate-id",
                    message=f"duplicate entity id '{entity.id}'",
                )
            )
        else:
            ids[entity.id] = entity

    known_ids = set(ids)
    for entity in entities:
        for relationship in entity.relationships:
            if relationship.target_id not in known_ids:
                issues.append(
                    ValidationIssue(
                        level="error",
                        entity_id=entity.id,
                        file=entity.entity_file,
                        code="unknown-relationship-target",
                        message=f"relationship target '{relationship.target_id}' does not exist",
                    )
                )

    character_referenced_ids: set[str] = set()
    for entity in entities:
        if entity.type == "character":
            for rel in entity.relationships:
                character_referenced_ids.add(rel.target_id)

    for entity in entities:
        if entity.type in {"place", "object"} and entity.id not in character_referenced_ids:
            issues.append(
                ValidationIssue(
                    level="warning",
                    entity_id=entity.id,
                    file=entity.entity_file,
                    code="no-character-back-link",
                    message="no character has a relationship pointing to this entity — add a relationship from the owning character, or mark as standalone if intentional",
                )
            )

    return issues


def validate_entity(entity: Entity) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []

    if entity.type not in VALID_ENTITY_TYPES:
        issues.append(_issue(entity, "error", "invalid-type", f"invalid entity type '{entity.type}'"))
    else:
        required = REQUIRED_FIELDS_BY_TYPE[entity.type]
        for field_name in required:
            if getattr(entity, field_name, None) in (None, ""):
                issues.append(_issue(entity, "error", "missing-required-field", f"missing required field '{field_name}'"))

    if not ID_PATTERN.match(entity.id):
        issues.append(_issue(entity, "error", "invalid-id", "id must be slug-like ASCII"))

    for key in entity.raw:
        if key not in ALLOWED_TOP_LEVEL_KEYS:
            issues.append(_issue(entity, "warning", "unknown-key", f"unknown top-level key '{key}'"))

    facet_keys = set(entity.files)
    declared_facets = set(entity.facets)

    for facet in declared_facets:
        if not FACET_PATTERN.match(facet):
            issues.append(_issue(entity, "warning", "legacy-facet-name", f"facet '{facet}' is not kebab-case; run doctor --fix-filenames to rename"))

    for facet in facet_keys:
        if not FACET_PATTERN.match(facet):
            issues.append(_issue(entity, "warning", "legacy-facet-name", f"facet '{facet}' is not kebab-case; run doctor --fix-filenames to rename"))

    allowed_facets = ALLOWED_FACETS_BY_TYPE.get(entity.type)
    if allowed_facets is not None:
        for facet in sorted(facet_keys | declared_facets):
            if facet not in allowed_facets:
                issues.append(
                    _issue(
                        entity,
                        "warning",
                        "facet-not-typical-for-type",
                        f"facet '{facet}' is unusual for entity type '{entity.type}'",
                    )
                )

    if entity.type == "character":
        for facet in sorted(facet_keys | declared_facets):
            if facet in BROAD_CHARACTER_FACETS:
                issues.append(
                    _issue(
                        entity,
                        "warning",
                        "broad-character-facet",
                        f"facet '{facet}' bundles multiple ideas; prefer narrow ritual-* and outfit-* files instead",
                    )
                )

    if entity.type in {"place", "object"} and entity.status is not None:
        issues.append(
            _issue(
                entity,
                "warning",
                "unexpected-status",
                f"status is usually unnecessary for entity type '{entity.type}'",
            )
        )

    for facet in declared_facets - facet_keys:
        issues.append(_issue(entity, "warning", "missing-facet-file", f"facet '{facet}' declared but not mapped in files"))

    for facet in facet_keys - declared_facets:
        issues.append(_issue(entity, "warning", "undeclared-facet-file", f"facet file '{facet}' exists in files but not facets"))

    for facet, path in entity.files.items():
        if not path.is_file():
            issues.append(_issue(entity, "error", "missing-file", f"facet file '{facet}' not found at {path.name}"))
        elif path.suffix.lower() != ".md":
            issues.append(_issue(entity, "warning", "non-markdown-facet", f"facet file '{facet}' is not a markdown file"))
        else:
            content_issue = _facet_content_issue(entity, facet, path)
            if content_issue is not None:
                issues.append(content_issue)
            if entity.type == "character":
                body = _facet_body_text(path.read_text(encoding="utf-8"))
                misplacement = _character_facet_misplacement_issue(entity, facet, body)
                if misplacement is not None:
                    issues.append(misplacement)

    image_assets = entity.assets.get("images", [])
    image_asset_ids = {ref.id for ref in image_assets if ref.id}

    seen_relationships: set[tuple[str, str]] = set()
    for relationship in entity.relationships:
        key = (relationship.target_id, relationship.kind)
        if key in seen_relationships:
            issues.append(
                _issue(
                    entity,
                    "warning",
                    "duplicate-relationship",
                    f"relationship '{relationship.kind}' to '{relationship.target_id}' is duplicated",
                )
            )
        else:
            seen_relationships.add(key)

    for bucket, refs in entity.assets.items():
        if bucket not in {"images", "audio"}:
            issues.append(_issue(entity, "warning", "unknown-asset-bucket", f"unknown asset bucket '{bucket}'"))
        for ref in refs:
            if not ref.path.exists():
                issues.append(_issue(entity, "error", "missing-asset", f"asset '{bucket}' missing at {ref.path.name}"))

    for image_id in entity.visual.canonical_image_ids:
        if image_id not in image_asset_ids:
            issues.append(
                _issue(
                    entity,
                    "error",
                    "unknown-canonical-image-id",
                    f"visual canonical image id '{image_id}' does not match any image asset id",
                )
            )

    for image_id in entity.visual.optional_image_ids:
        if image_id not in image_asset_ids:
            issues.append(
                _issue(
                    entity,
                    "error",
                    "unknown-optional-image-id",
                    f"visual optional image id '{image_id}' does not match any image asset id",
                )
            )

    if entity.visual.default_seed is not None and entity.visual.default_seed < 0:
        issues.append(_issue(entity, "error", "negative-default-seed", "visual default_seed must be >= 0"))

    for lora_ref in entity.visual.lora_refs:
        if lora_ref.path is not None and not lora_ref.path.exists():
            issues.append(
                _issue(
                    entity,
                    "error",
                    "missing-lora-ref",
                    f"visual LoRA '{lora_ref.name}' missing at {lora_ref.path.name}",
                )
            )

    if image_assets and not entity.visual.canonical_image_ids:
        issues.append(
            _issue(
                entity,
                "warning",
                "uncurated-image-references",
                "image assets exist but no visual canonical_image_ids are defined",
            )
        )

    if entity.visual.canonical_image_ids and not entity.visual.preferred_models:
        issues.append(
            _issue(
                entity,
                "warning",
                "missing-preferred-image-models",
                "visual canonical references exist but preferred_models is empty",
            )
        )

    if entity.visual.preferred_models and not entity.visual.canonical_image_ids:
        issues.append(
            _issue(
                entity,
                "warning",
                "model-hints-without-canonical-refs",
                "visual preferred_models are set but canonical_image_ids is empty",
            )
        )

    return issues


def _load_errors_to_issues(result: LoadResult) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    for error in result.errors:
        issues.append(
            ValidationIssue(
                level="error",
                entity_id=None,
                file=error.entity_file,
                code="load-error",
                message=f"{error.entity_dir.name}: {error.message}",
            )
        )
    return issues


def _issue(entity: Entity, level: str, code: str, message: str) -> ValidationIssue:
    return ValidationIssue(
        level=level,
        entity_id=entity.id,
        file=entity.entity_file,
        code=code,
        message=message,
    )


def _facet_content_issue(entity: Entity, facet: str, path) -> ValidationIssue | None:
    if facet not in CORE_FACETS_BY_TYPE.get(entity.type, set()):
        return None
    body = _facet_body_text(path.read_text(encoding="utf-8"))
    if not body:
        return _issue(entity, "warning", "empty-facet-content", f"facet '{facet}' is effectively empty")
    lowered = body.lower()
    if lowered.startswith("describe ") and lowered.endswith(" here."):
        return _issue(entity, "warning", "placeholder-facet-content", f"facet '{facet}' still contains placeholder text")
    if len(body.split()) < 8:
        return _issue(entity, "warning", "thin-facet-content", f"facet '{facet}' is very short and may be too weak to guide agents reliably")
    return None


def _facet_body_text(content: str) -> str:
    lines = content.splitlines()
    if lines and lines[0].lstrip().startswith("#"):
        lines = lines[1:]
    while lines and not lines[0].strip():
        lines = lines[1:]
    return "\n".join(lines).strip()


def _character_facet_misplacement_issue(entity: Entity, facet: str, body: str) -> ValidationIssue | None:
    lowered = body.lower()
    location_hits = sum(1 for signal in LOCATION_CONTENT_SIGNALS if signal in lowered)
    if location_hits >= _MISPLACEMENT_THRESHOLD:
        return _issue(
            entity,
            "warning",
            "location-data-in-character-facet",
            f"facet '{facet}' appears to contain location descriptions ({location_hits} signals); consider extracting to a places/ entity with a relationship link",
        )
    object_hits = sum(1 for signal in OBJECT_CONTENT_SIGNALS if signal in lowered)
    if object_hits >= _MISPLACEMENT_THRESHOLD:
        return _issue(
            entity,
            "warning",
            "object-data-in-character-facet",
            f"facet '{facet}' appears to contain object details ({object_hits} signals); consider extracting to an objects/ entity with a relationship link",
        )
