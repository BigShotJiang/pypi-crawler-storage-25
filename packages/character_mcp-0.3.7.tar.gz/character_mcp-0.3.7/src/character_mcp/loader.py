from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from .models import AssetRef, Entity, EntityLoadError, LoadResult, Relationship, VisualLoraRef, VisualProfile
from .schema import validate_entity_payload


class LoaderError(Exception):
    pass


TOP_LEVEL_COLLECTIONS = ("characters", "places", "objects")


def discover_entity_dirs(root: Path) -> list[Path]:
    entity_dirs: list[Path] = []
    for collection in TOP_LEVEL_COLLECTIONS:
        collection_dir = root / collection
        if not collection_dir.is_dir():
            continue
        for child in sorted(collection_dir.iterdir()):
            if child.is_dir():
                entity_dirs.append(child)
    return entity_dirs


def load_entities(root: str | Path) -> LoadResult:
    root_path = Path(root).expanduser().resolve()
    result = LoadResult()
    for entity_dir in discover_entity_dirs(root_path):
        try:
            result.entities.append(load_entity(root_path, entity_dir))
        except LoaderError as exc:
            result.errors.append(
                EntityLoadError(
                    entity_dir=entity_dir,
                    entity_file=(entity_dir / "entity.yaml") if (entity_dir / "entity.yaml").exists() else None,
                    message=str(exc),
                )
            )
    return result


def load_entity(root: Path, entity_dir: Path) -> Entity:
    entity_file = entity_dir / "entity.yaml"
    if not entity_file.is_file():
        raise LoaderError("missing entity.yaml")

    try:
        raw = yaml.safe_load(entity_file.read_text(encoding="utf-8"))
    except yaml.YAMLError as exc:
        raise LoaderError(f"invalid YAML: {exc}") from exc

    if not isinstance(raw, dict):
        raise LoaderError("entity.yaml must contain a mapping")

    schema_errors = validate_entity_payload(raw)
    if schema_errors:
        raise LoaderError(f"schema validation failed: {'; '.join(schema_errors)}")

    entity_id = raw["id"].strip()
    entity_type = raw["type"].strip()
    name = raw["name"].strip()

    return Entity(
        root=root,
        entity_dir=entity_dir,
        entity_file=entity_file,
        schema_version=_optional_int(raw.get("schema_version")),
        id=entity_id,
        type=entity_type,
        name=name,
        aliases=_list_of_str(raw.get("aliases", [])),
        status=_optional_str(raw.get("status")),
        tags=_list_of_str(raw.get("tags", [])),
        summary=_optional_str(raw.get("summary")),
        facets=_list_of_str(raw.get("facets", [])),
        files=_files_map(entity_dir, raw.get("files", {})),
        assets=_assets_map(entity_dir, raw.get("assets", {})),
        visual=_visual_profile(entity_dir, raw.get("visual", {})),
        relationships=_relationships(raw.get("relationships", [])),
        metadata=_dict_or_empty(raw.get("metadata")),
        raw=raw,
    )


def _optional_str(value: Any) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise LoaderError("expected string value")
    stripped = value.strip()
    return stripped or None


def _optional_int(value: Any) -> int | None:
    if value is None:
        return None
    if not isinstance(value, int):
        raise LoaderError("schema_version must be an integer")
    return value


def _optional_float(value: Any) -> float | None:
    if value is None:
        return None
    if not isinstance(value, (int, float)):
        raise LoaderError("expected numeric value")
    return float(value)


def _list_of_str(value: Any) -> list[str]:
    if not isinstance(value, list):
        raise LoaderError("expected list value")
    cleaned: list[str] = []
    for item in value:
        if not isinstance(item, str) or not item.strip():
            raise LoaderError("list values must be non-empty strings")
        cleaned.append(item.strip())
    return cleaned


def _dict_or_empty(value: Any) -> dict[str, Any]:
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise LoaderError("expected mapping value")
    return value


def _files_map(entity_dir: Path, value: Any) -> dict[str, Path]:
    raw_files = _dict_or_empty(value)
    resolved: dict[str, Path] = {}
    for facet, rel_path in raw_files.items():
        resolved[facet.strip()] = entity_dir / rel_path
    return resolved


def _assets_map(entity_dir: Path, value: Any) -> dict[str, list[AssetRef]]:
    raw_assets = _dict_or_empty(value)
    resolved: dict[str, list[AssetRef]] = {}
    for bucket, items in raw_assets.items():
        refs: list[AssetRef] = []
        for item in items:
            refs.append(
                AssetRef(
                    id=_optional_str(item.get("id")),
                    path=entity_dir / item["path"],
                    label=_optional_str(item.get("label")),
                    kind=_optional_str(item.get("kind")),
                    tags=_list_of_str(item.get("tags", [])),
                )
            )
        resolved[bucket.strip()] = refs
    return resolved


def _visual_profile(entity_dir: Path, value: Any) -> VisualProfile:
    raw_visual = _dict_or_empty(value)
    lora_refs: list[VisualLoraRef] = []
    for item in raw_visual.get("lora_refs", []) or []:
        lora_refs.append(
            VisualLoraRef(
                name=item["name"].strip(),
                path=(entity_dir / item["path"]) if item.get("path") else None,
                weight=_optional_float(item.get("weight")),
                notes=_optional_str(item.get("notes")),
            )
        )
    return VisualProfile(
        canonical_image_ids=_list_of_str(raw_visual.get("canonical_image_ids", [])),
        optional_image_ids=_list_of_str(raw_visual.get("optional_image_ids", [])),
        preferred_models=_list_of_str(raw_visual.get("preferred_models", [])),
        default_seed=_optional_int(raw_visual.get("default_seed")),
        prompt_notes=_optional_str(raw_visual.get("prompt_notes")),
        negative_prompt=_optional_str(raw_visual.get("negative_prompt")),
        lora_refs=lora_refs,
    )


def _relationships(value: Any) -> list[Relationship]:
    if not isinstance(value, list):
        raise LoaderError("relationships must be a list")
    resolved: list[Relationship] = []
    for item in value:
        resolved.append(
            Relationship(
                target_id=item["target_id"].strip(),
                kind=item["kind"].strip(),
                status=_optional_str(item.get("status")),
                notes=_optional_str(item.get("notes")),
            )
        )
    return resolved
