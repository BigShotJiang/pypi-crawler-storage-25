from __future__ import annotations

import threading
import time
from pathlib import Path

from .service import CharacterService


class PollingEntityWatcher:
    def __init__(self, service: CharacterService, interval: float = 1.0):
        self.service = service
        self.interval = interval
        self._snapshot = self._take_snapshot()
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._run, name="character-mcp-watcher", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=self.interval * 2)

    def poll_once(self) -> bool:
        snapshot = self._take_snapshot()
        if snapshot != self._snapshot:
            self._snapshot = snapshot
            self.service.rescan()
            return True
        return False

    def _run(self) -> None:
        while not self._stop_event.wait(self.interval):
            self.poll_once()

    def _take_snapshot(self) -> dict[str, int]:
        root = self.service.root
        snapshot: dict[str, int] = {}
        if not root.exists():
            return snapshot
        for path in sorted(root.rglob("*")):
            if path.is_file():
                snapshot[str(path.relative_to(root))] = path.stat().st_mtime_ns
        return snapshot
