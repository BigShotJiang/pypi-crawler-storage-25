from __future__ import annotations

import shutil
from dataclasses import replace as dc_replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .loader import load_entities
from .models import DoctorReport, Entity, EntitySummary, FacetDocument, ValidationIssue
from .openclaw_config import OpenClawConfig
from .validator import validate_load_result
from .writer import DatasetWriter, WriteError


class EntityNotFoundError(KeyError):
    pass


class FacetNotFoundError(KeyError):
    pass


TOP_LEVEL_COLLECTIONS = ("characters", "places", "objects")


class CharacterService:
    def __init__(self, root: str | Path, openclaw_config_path: str | Path | None = None):
        self.root = Path(root)
        self._writer = DatasetWriter(self.root)
        self._openclaw_config = OpenClawConfig(openclaw_config_path)
        self._refresh()

    def _refresh(self) -> None:
        self._load_result = load_entities(self.root)
        self._entities = {entity.id: entity for entity in self._load_result.entities}
        self._character_owners: dict[str, list[Entity]] = {}
        for entity in self._entities.values():
            if entity.type == "character":
                for rel in entity.relationships:
                    self._character_owners.setdefault(rel.target_id, []).append(entity)

    def rescan(self) -> None:
        self._refresh()

    def list_entities(self, entity_type: str | None = None) -> list[EntitySummary]:
        entities = sorted(self._entities.values(), key=lambda entity: (entity.type, entity.id))
        if entity_type:
            entities = [entity for entity in entities if entity.type == entity_type]
        return [self._to_summary(entity) for entity in entities]

    def get_dataset_status(self) -> dict[str, Any]:
        collections = {}
        for collection in TOP_LEVEL_COLLECTIONS:
            collection_dir = self.root / collection
            collections[collection] = {
                "exists": collection_dir.exists(),
                "path": str(collection_dir),
                "entity_dir_count": len([child for child in collection_dir.iterdir() if child.is_dir()]) if collection_dir.is_dir() else 0,
            }
        is_initialized = any(info["exists"] for info in collections.values())
        is_empty = len(self._load_result.entities) == 0 and len(self._load_result.errors) == 0
        next_actions = []
        if not is_initialized or is_empty:
            next_actions = [
                "initialize_character_root",
                "start_character_intake",
                "start_existing_character_import",
            ]
        return {
            "root": str(self.root),
            "exists": self.root.exists(),
            "is_initialized": is_initialized,
            "is_empty": is_empty,
            "entity_count": len(self._load_result.entities),
            "load_error_count": len(self._load_result.errors),
            "collections": collections,
            "next_actions": next_actions,
            "empty_dataset_prompt": (
                "The character root is empty. You can initialize it, then either start a new character or import an already-known one."
                if is_empty else None
            ),
        }

    def initialize_character_root(self) -> dict[str, Any]:
        self.root.mkdir(parents=True, exist_ok=True)
        created: list[str] = []
        for collection in TOP_LEVEL_COLLECTIONS:
            collection_dir = self.root / collection
            if not collection_dir.exists():
                collection_dir.mkdir(parents=True, exist_ok=True)
                created.append(str(collection_dir))
        readme_path = self.root / "README.md"
        if not readme_path.exists():
            readme_path.write_text(
                "# Character Root\n\nThis directory stores Character MCP data.\n\n- `characters/` for character entities\n- `places/` for place entities\n- `objects/` for object entities\n",
                encoding="utf-8",
            )
            created.append(str(readme_path))
        self.rescan()
        return {
            "status": "ok",
            "created": created,
            "dataset_status": self.get_dataset_status(),
            "next_actions": ["start_character_intake", "start_existing_character_import"],
        }

    def start_existing_character_import(self, character_id: str, name: str, summary: str | None = None) -> dict[str, Any]:
        result = self.create_entity(
            entity_type="character",
            entity_id=character_id,
            name=name,
            summary=summary,
            tags=["intake", "imported"],
            status="draft",
        )
        self.write_entity_facet(character_id, "appearance", f"# Appearance\n\nDescribe {name}'s appearance anchors here.\n")
        self.write_entity_facet(character_id, "voice", f"# Voice\n\nDescribe {name}'s voice here.\n")
        return {
            "status": "ok",
            "entity_id": character_id,
            "created": result["created"],
            "mode": "existing-character-import",
            "storage_concepts": [
                "summary",
                "proposed_identity",
                "identity",
                "appearance",
                "voice",
                "relationships",
                "reference_assets",
                "visual_profile",
                "linked_agent",
            ],
            "next_step": self.get_character_intake_next_step(character_id),
            "questions": self.suggest_next_character_questions(character_id),
            "intake_status": self.get_character_intake_status(character_id),
            "import_prompt": "Treat recalled knowledge as proposed data, confirm it gradually, then write it into the dataset.",
        }

    def get_entity_summary(self, entity_id: str) -> EntitySummary:
        entity = self._get_entity(entity_id)
        base = self._to_summary(entity)
        related: list[dict[str, Any]] = []
        for rel in entity.relationships:
            target = self._entities.get(rel.target_id)
            entry: dict[str, Any] = {"id": rel.target_id, "kind": rel.kind}
            if target is not None:
                entry["type"] = target.type
                entry["name"] = target.name
            related.append(entry)
        owned_by = self.get_character_owner_refs(entity_id) if entity.type != "character" else []
        return dc_replace(base, related_entities=related, owned_by=owned_by)

    def get_character_owner_refs(self, entity_id: str) -> list[dict[str, Any]]:
        return [
            {
                "id": owner.id,
                "name": owner.name,
                "hint": f"Call get_visual_profile('{owner.id}') before generating images of this entity.",
            }
            for owner in self._character_owners.get(entity_id, [])
        ]

    def get_entity_hints(self, entity_id: str) -> list[str]:
        entity = self._get_entity(entity_id)
        hints = []
        if entity.type == "character":
            if entity.status == "draft":
                hints.append(f"Character is draft — call get_character_intake_next_step('{entity_id}') to continue onboarding.")
            if not entity.aliases:
                hints.append(f"No aliases set — call append_entity_alias('{entity_id}', alias) to allow flexible name lookups and avoid lookup errors.")
            integration = entity.raw.get("integration", {})
            if isinstance(integration, dict) and isinstance(integration.get("openclaw"), dict) and integration["openclaw"].get("agent_id"):
                hints.append(f"Agent binding exists — call get_character_agent_binding('{entity_id}') to inspect it.")
        return hints

    def list_entity_facets(self, entity_id: str) -> list[str]:
        entity = self._get_entity(entity_id)
        return sorted(entity.files)

    def get_entity_facet(self, entity_id: str, facet: str) -> FacetDocument:
        entity = self._get_entity(entity_id)
        path = entity.files.get(facet)
        if path is None:
            raise FacetNotFoundError(f"facet '{facet}' not found for entity '{entity_id}'")
        return FacetDocument(
            entity_id=entity.id,
            facet=facet,
            path=path,
            content=path.read_text(encoding="utf-8"),
        )

    def list_entity_relationships(self, entity_id: str) -> list[dict[str, Any]]:
        entity = self._get_entity(entity_id)
        return [
            {
                "target_id": relationship.target_id,
                "kind": relationship.kind,
                "status": relationship.status,
                "notes": relationship.notes,
            }
            for relationship in entity.relationships
        ]

    def get_visual_profile(self, entity_id: str) -> dict[str, Any]:
        entity = self._get_entity(entity_id)
        payload = self._visual_profile_payload(entity)
        payload["available_facets"] = sorted(entity.files)
        return payload

    def get_character_gap_report(self, entity_id: str) -> dict[str, Any]:
        entity = self._get_entity(entity_id)
        self._ensure_character(entity)
        return self._character_gap_report(entity)

    def get_character_agent_binding(self, entity_id: str) -> dict[str, Any]:
        entity = self._get_entity(entity_id)
        self._ensure_character(entity)
        return self._agent_binding_payload(entity)

    def get_related_entities(self, entity_id: str) -> list[dict[str, Any]]:
        entity = self._get_entity(entity_id)
        related: list[dict[str, Any]] = []
        for relationship in entity.relationships:
            target = self._entities.get(relationship.target_id)
            related.append(
                {
                    "relationship": {
                        "target_id": relationship.target_id,
                        "kind": relationship.kind,
                        "status": relationship.status,
                        "notes": relationship.notes,
                    },
                    "target": as_summary_dict(self._to_summary(target)) if target is not None else None,
                }
            )
        return related

    def doctor(self) -> list[ValidationIssue]:
        issues = validate_load_result(self._load_result)
        issues.extend(self._integration_issues())
        return issues

    def doctor_report(self) -> DoctorReport:
        issues = self.doctor()
        error_count = sum(1 for issue in issues if issue.level == "error")
        warning_count = sum(1 for issue in issues if issue.level == "warning")
        return DoctorReport(
            entity_count=len(self._load_result.entities),
            load_error_count=len(self._load_result.errors),
            issue_count=len(issues),
            error_count=error_count,
            warning_count=warning_count,
            issues=issues,
        )

    def cleanup_dataset(self, *, apply: bool = False) -> dict[str, Any]:
        orphan_dirs = self._find_orphan_entity_dirs()
        stale_facet_refs = self._find_stale_facet_refs()
        result = {
            "status": "ok",
            "apply": apply,
            "orphan_entity_dirs": orphan_dirs,
            "stale_facet_refs": stale_facet_refs,
            "orphan_entity_dir_count": len(orphan_dirs),
            "stale_facet_ref_count": len(stale_facet_refs),
        }
        if not apply:
            return result

        quarantined: list[dict[str, str]] = []
        quarantine_root: str | None = None
        if orphan_dirs:
            timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
            quarantine_dir = self.root / ".character-mcp-quarantine" / timestamp
            for entry in orphan_dirs:
                source = self.root / entry["path"]
                destination = quarantine_dir / entry["path"]
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(source), str(destination))
                quarantined.append({"from": str(source), "to": str(destination)})
            quarantine_root = str(quarantine_dir)
            self.rescan()

        pruned_facet_refs: list[dict[str, Any]] = []
        for item in stale_facet_refs:
            entity = self._get_entity(item["entity_id"])
            prune = self._writer.prune_missing_facets(entity, item["facets"])
            pruned_facet_refs.append(
                {
                    "entity_id": item["entity_id"],
                    "removed_facets": prune["removed_facets"],
                    "backup_dir": prune["backup_dir"],
                }
            )
            self.rescan()

        self.rescan()
        report = self.doctor_report()
        result.update(
            {
                "quarantine_root": quarantine_root,
                "quarantined": quarantined,
                "pruned_facet_refs": pruned_facet_refs,
                "doctor_report": {
                    "entity_count": report.entity_count,
                    "load_error_count": report.load_error_count,
                    "issue_count": report.issue_count,
                    "error_count": report.error_count,
                    "warning_count": report.warning_count,
                },
            }
        )
        return result

    def create_entity(
        self,
        *,
        entity_type: str,
        entity_id: str,
        name: str,
        summary: str | None = None,
        tags: list[str] | None = None,
        status: str | None = None,
    ) -> dict[str, Any]:
        result = self._writer.create_entity(
            entity_type=entity_type,
            entity_id=entity_id,
            name=name,
            summary=summary,
            tags=tags,
            status=status,
        )
        self.rescan()
        return result

    def start_character_intake(self, character_id: str, name: str, *, agent_id: str | None = None, summary: str | None = None) -> dict[str, Any]:
        result = self.create_entity(
            entity_type="character",
            entity_id=character_id,
            name=name,
            summary=summary,
            tags=["intake"],
            status="draft",
        )
        self.write_entity_facet(character_id, "appearance", f"# Appearance\n\nDescribe {name}'s appearance anchors here.\n")
        self.write_entity_facet(character_id, "voice", f"# Voice\n\nDescribe {name}'s voice here.\n")
        if agent_id:
            self.link_character_agent(character_id, agent_id)
        next_step = self.get_character_intake_next_step(character_id)
        return {
            "status": "ok",
            "entity_id": character_id,
            "next_step": next_step,
            "questions": self.suggest_next_character_questions(character_id),
            "intake_status": self.get_character_intake_status(character_id),
            "resume_hint": "Use get_character_intake_next_step later to resume from the next logical question.",
            "created": result["created"],
        }

    def get_character_intake_status(self, entity_id: str) -> dict[str, Any]:
        entity = self._get_entity(entity_id)
        self._ensure_character(entity)
        progress = self._character_intake_progress(entity)
        linked_agent_id = self._linked_agent_id(entity)
        completed = [step for step, done in progress.items() if done]
        missing = [step for step, done in progress.items() if not done]
        next_step = self.get_character_intake_next_step(entity_id)
        return {
            "status": "ok",
            "entity_id": entity.id,
            "draft_status": entity.status,
            "linked_agent_id": linked_agent_id,
            "progress": progress,
            "completed_steps": completed,
            "missing_steps": missing,
            "completed_count": len(completed),
            "total_steps": len(progress),
            "next_step": next_step,
            "next_questions": self.suggest_next_character_questions(entity_id),
            "completion_summary": self._character_completion_summary(entity),
            "gap_report": self._character_gap_report(entity),
        }

    def get_character_intake_next_step(self, entity_id: str) -> dict[str, Any]:
        entity = self._get_entity(entity_id)
        self._ensure_character(entity)
        progress = self._character_intake_progress(entity)
        ordered_steps = self._intake_question_plan()
        current = next((step for step in ordered_steps if not progress[step["step"]]), None)
        required_remaining = [step["step"] for step in ordered_steps if not step["optional"] and not progress[step["step"]]]
        optional_remaining = [step["step"] for step in ordered_steps if step["optional"] and not progress[step["step"]]]
        return {
            "status": "ok",
            "entity_id": entity.id,
            "step": current["step"] if current else None,
            "question": current["question"] if current else None,
            "optional": current["optional"] if current else False,
            "required_remaining": required_remaining,
            "optional_remaining": optional_remaining,
            "is_complete": current is None,
        }

    def suggest_next_character_questions(self, entity_id: str) -> list[str]:
        entity = self._get_entity(entity_id)
        self._ensure_character(entity)
        progress = self._character_intake_progress(entity)
        ordered_steps = [step for step in self._intake_question_plan() if not progress[step["step"]]]
        if not ordered_steps:
            return []
        core_missing = [step["question"] for step in ordered_steps if not step["optional"]]
        if core_missing:
            return [core_missing[0]]
        return [step["question"] for step in ordered_steps[:3]]

    def link_character_agent(self, entity_id: str, agent_id: str, behavior_hint: str | None = None) -> dict[str, Any]:
        available = self._openclaw_config.agent_ids()
        if available and agent_id not in available:
            raise WriteError(f"OpenClaw agent '{agent_id}' does not exist")
        if behavior_hint is not None and not behavior_hint.strip():
            raise WriteError("behavior_hint must be non-empty when provided")
        entity = self._get_entity(entity_id)
        self._ensure_character(entity)
        result = self._writer.link_character_agent(entity, agent_id, behavior_hint=behavior_hint)
        self.rescan()
        return result

    def apply_character_intake_answers(self, entity_id: str, answers: dict[str, Any]) -> dict[str, Any]:
        entity = self._get_entity(entity_id)
        self._ensure_character(entity)
        self._validate_intake_answers(entity, answers)
        result = self._writer.apply_character_intake_answers(entity, answers)
        self.rescan()
        refreshed = self._get_entity(entity_id)
        return {
            **result,
            "next_step": self.get_character_intake_next_step(entity_id),
            "questions": self.suggest_next_character_questions(entity_id),
            "intake_status": self.get_character_intake_status(entity_id),
            "completion_summary": self._character_completion_summary(refreshed),
            "gap_report": self._character_gap_report(refreshed),
        }

    def update_entity_yaml(self, entity_id: str, changes: dict[str, Any]) -> dict[str, Any]:
        entity = self._get_entity(entity_id)
        result = self._writer.update_entity_yaml(entity, changes)
        self.rescan()
        return result

    def write_entity_facet(self, entity_id: str, facet: str, content: str) -> dict[str, Any]:
        entity = self._get_entity(entity_id)
        result = self._writer.write_entity_facet(entity, facet, content)
        self.rescan()
        return result

    def add_relationship(
        self,
        entity_id: str,
        *,
        target_id: str,
        kind: str,
        status: str | None = None,
        notes: str | None = None,
    ) -> dict[str, Any]:
        entity = self._get_entity(entity_id)
        result = self._writer.add_relationship(
            entity,
            target_id=target_id,
            kind=kind,
            status=status,
            notes=notes,
        )
        self.rescan()
        return result

    def append_entity_alias(self, entity_id: str, alias: str) -> dict[str, Any]:
        entity = self._get_entity(entity_id)
        result = self._writer.append_entity_alias(entity, alias)
        self.rescan()
        return result

    def add_asset_reference(
        self,
        entity_id: str,
        *,
        bucket: str,
        path: str,
        label: str | None = None,
        kind: str | None = None,
        tags: list[str] | None = None,
        asset_id: str | None = None,
    ) -> dict[str, Any]:
        entity = self._get_entity(entity_id)
        result = self._writer.add_asset_reference(
            entity,
            bucket=bucket,
            path=path,
            label=label,
            kind=kind,
            tags=tags,
            asset_id=asset_id,
        )
        self.rescan()
        return result

    def update_visual_profile(
        self,
        entity_id: str,
        *,
        canonical_image_ids: list[str] | None = None,
        optional_image_ids: list[str] | None = None,
        preferred_models: list[str] | None = None,
        default_seed: int | None = None,
        prompt_notes: str | None = None,
        negative_prompt: str | None = None,
        lora_refs: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        entity = self._get_entity(entity_id)
        image_asset_ids = {ref.id for ref in entity.assets.get("images", []) if ref.id}
        for bucket_name, image_ids in (("canonical_image_ids", canonical_image_ids), ("optional_image_ids", optional_image_ids)):
            if image_ids is None:
                continue
            missing = [image_id for image_id in image_ids if image_id not in image_asset_ids]
            if missing:
                raise WriteError(f"{bucket_name} contains unknown image asset ids: {', '.join(missing)}")

        result = self._writer.update_visual_profile(
            entity,
            canonical_image_ids=canonical_image_ids,
            optional_image_ids=optional_image_ids,
            preferred_models=preferred_models,
            default_seed=default_seed,
            prompt_notes=prompt_notes,
            negative_prompt=negative_prompt,
            lora_refs=lora_refs,
        )
        self.rescan()
        return result

    def _find_orphan_entity_dirs(self) -> list[dict[str, str]]:
        orphans: list[dict[str, str]] = []
        for collection in TOP_LEVEL_COLLECTIONS:
            collection_dir = self.root / collection
            if not collection_dir.is_dir():
                continue
            for child in sorted(collection_dir.iterdir()):
                if not child.is_dir():
                    continue
                if not (child / "entity.yaml").exists():
                    orphans.append(
                        {
                            "collection": collection,
                            "entity_id": child.name,
                            "path": str(child.relative_to(self.root)),
                        }
                    )
        return orphans

    def _find_stale_facet_refs(self) -> list[dict[str, Any]]:
        stale: list[dict[str, Any]] = []
        for entity in sorted(self._entities.values(), key=lambda item: item.id):
            raw_files = entity.raw.get("files", {})
            raw_facets = entity.raw.get("facets", [])
            if not isinstance(raw_files, dict):
                continue
            facets_to_remove: list[str] = []
            details: list[dict[str, str]] = []
            all_facets = sorted(set(raw_files) | {facet for facet in raw_facets if isinstance(facet, str)})
            for facet in all_facets:
                if facet not in raw_files:
                    facets_to_remove.append(facet)
                    details.append({"facet": facet, "reason": "declared in facets but missing from files"})
                    continue
                filename = raw_files.get(facet)
                if not isinstance(filename, str) or not filename.strip():
                    facets_to_remove.append(facet)
                    details.append({"facet": facet, "reason": "files entry is empty or invalid"})
                    continue
                facet_path = entity.entity_dir / filename
                if not facet_path.exists():
                    facets_to_remove.append(facet)
                    details.append({"facet": facet, "reason": f"mapped file '{filename}' is missing"})
            if facets_to_remove:
                stale.append(
                    {
                        "entity_id": entity.id,
                        "path": str(entity.entity_file.relative_to(self.root)),
                        "facets": facets_to_remove,
                        "details": details,
                    }
                )
        return stale

    def _integration_issues(self) -> list[ValidationIssue]:
        issues: list[ValidationIssue] = []
        available = self._openclaw_config.agent_ids()
        for entity in self._entities.values():
            integration = entity.raw.get("integration")
            if not isinstance(integration, dict):
                continue
            openclaw = integration.get("openclaw")
            if not isinstance(openclaw, dict):
                continue
            agent_id = openclaw.get("agent_id")
            behavior_hint = openclaw.get("behavior_hint")
            if available and isinstance(agent_id, str) and agent_id not in available:
                issues.append(
                    ValidationIssue(
                        level="warning",
                        entity_id=entity.id,
                        file=entity.entity_file,
                        code="unknown-openclaw-agent",
                        message=f"linked OpenClaw agent '{agent_id}' does not exist",
                    )
                )
            if behavior_hint and not isinstance(agent_id, str):
                issues.append(
                    ValidationIssue(
                        level="warning",
                        entity_id=entity.id,
                        file=entity.entity_file,
                        code="orphaned-agent-behavior-hint",
                        message="OpenClaw behavior_hint is set but no agent_id is linked",
                    )
                )
        return issues

    def _validate_intake_answers(self, entity: Entity, answers: dict[str, Any]) -> None:
        agent_id = answers.get("agent_id")
        available = self._openclaw_config.agent_ids()
        if agent_id and available and agent_id not in available:
            raise WriteError(f"OpenClaw agent '{agent_id}' does not exist")
        agent_behavior_hint = answers.get("agent_behavior_hint")
        if agent_behavior_hint is not None and not isinstance(agent_behavior_hint, str):
            raise WriteError("agent_behavior_hint must be a string")
        if agent_behavior_hint and not agent_id and not self._linked_agent_id(entity):
            raise WriteError("agent_behavior_hint requires a linked agent or an agent_id in this intake answer")

        if answers.get("home_location") and answers.get("home_location_id"):
            raise WriteError("use either home_location or home_location_id, not both")
        if answers.get("signature_object") and answers.get("signature_object_id"):
            raise WriteError("use either signature_object or signature_object_id, not both")

        for field_name, entity_type in (("home_location", "place"), ("signature_object", "object")):
            payload = answers.get(field_name)
            if payload is None:
                continue
            self._validate_seed_entity_payload(payload, entity_type=entity_type, field_name=field_name)

        canonical_image_ids = answers.get("canonical_image_ids")
        optional_image_ids = answers.get("optional_image_ids")
        if canonical_image_ids is not None or optional_image_ids is not None:
            image_refs = []
            for item in answers.get("image_refs", []) or []:
                if isinstance(item, dict) and isinstance(item.get("id"), str):
                    image_refs.append(item["id"])
            for path in answers.get("image_paths", []) or []:
                image_refs.append(self._asset_id_from_path(path))
            known_image_ids = {ref.id for ref in entity.assets.get("images", []) if ref.id} | set(image_refs)
            for bucket_name, image_ids in (("canonical_image_ids", canonical_image_ids), ("optional_image_ids", optional_image_ids)):
                if image_ids is None:
                    continue
                missing = [image_id for image_id in image_ids if image_id not in known_image_ids]
                if missing:
                    raise WriteError(f"{bucket_name} contains unknown image asset ids: {', '.join(missing)}")

        try:
            if answers.get("home_location_id"):
                home = self._get_entity(answers["home_location_id"])
                if home.type != "place":
                    raise WriteError(f"home_location_id '{home.id}' must point to a place")
            if answers.get("signature_object_id"):
                obj = self._get_entity(answers["signature_object_id"])
                if obj.type != "object":
                    raise WriteError(f"signature_object_id '{obj.id}' must point to an object")
            for relationship in answers.get("relationships", []) or []:
                if not isinstance(relationship, dict):
                    raise WriteError("relationships must be a list of mappings")
                target_id = relationship.get("target_id")
                kind = relationship.get("kind")
                if not target_id or not kind:
                    raise WriteError("each relationship requires target_id and kind")
                self._get_entity(target_id)
        except EntityNotFoundError as exc:
            raise WriteError(str(exc)) from exc

    def _ensure_character(self, entity: Entity) -> None:
        if entity.type != "character":
            raise WriteError(f"intake tools only support character entities, not '{entity.type}'")

    def _linked_agent_id(self, entity: Entity) -> str | None:
        integration = entity.raw.get("integration", {})
        if not isinstance(integration, dict):
            return None
        openclaw = integration.get("openclaw", {})
        if not isinstance(openclaw, dict):
            return None
        agent_id = openclaw.get("agent_id")
        return agent_id if isinstance(agent_id, str) and agent_id else None

    def _agent_binding_payload(self, entity: Entity) -> dict[str, Any]:
        integration = entity.raw.get("integration", {})
        openclaw = integration.get("openclaw", {}) if isinstance(integration, dict) else {}
        available_agents = sorted(self._openclaw_config.agent_ids())
        agent_id = openclaw.get("agent_id") if isinstance(openclaw, dict) else None
        previous_agent_id = openclaw.get("previous_agent_id") if isinstance(openclaw, dict) else None
        behavior_hint = openclaw.get("behavior_hint") if isinstance(openclaw, dict) else None
        last_linked_at = openclaw.get("last_linked_at") if isinstance(openclaw, dict) else None
        is_valid = isinstance(agent_id, str) and (not available_agents or agent_id in available_agents)
        return {
            "entity_id": entity.id,
            "agent_id": agent_id if isinstance(agent_id, str) else None,
            "previous_agent_id": previous_agent_id if isinstance(previous_agent_id, str) else None,
            "behavior_hint": behavior_hint if isinstance(behavior_hint, str) else None,
            "last_linked_at": last_linked_at if isinstance(last_linked_at, str) else None,
            "available_agent_ids": available_agents,
            "is_linked": isinstance(agent_id, str) and bool(agent_id),
            "is_valid": is_valid,
        }

    def _character_intake_progress(self, entity: Entity) -> dict[str, bool]:
        home_location = False
        signature_object = False
        for relationship in entity.relationships:
            target = self._entities.get(relationship.target_id)
            if target is None:
                continue
            if target.type == "place" and relationship.kind in {"lives-in", "inhabits", "based-in"}:
                home_location = True
            if target.type == "object" and relationship.kind in {"uses", "owns", "wears", "carries", "wields"}:
                signature_object = True

        return {
            "summary": bool(entity.summary),
            "identity": self._facet_has_real_content(entity, "identity"),
            "appearance": self._facet_has_real_content(entity, "appearance"),
            "voice": self._facet_has_real_content(entity, "voice"),
            "linked_agent": bool(self._linked_agent_id(entity)),
            "home_location": home_location,
            "signature_object": signature_object,
            "relationships": bool(entity.relationships),
            "reference_assets": any(bucket for bucket in entity.assets.values()),
            "visual_profile": bool(
                entity.visual.canonical_image_ids
                or entity.visual.optional_image_ids
                or entity.visual.preferred_models
                or entity.visual.default_seed is not None
                or entity.visual.prompt_notes
                or entity.visual.negative_prompt
                or entity.visual.lora_refs
            ),
        }

    @staticmethod
    def _intake_question_plan() -> list[dict[str, Any]]:
        return [
            {"step": "summary", "question": "What is the one-line summary of this character?", "optional": False},
            {"step": "identity", "question": "Who is this character at their core, and what role or vibe should come through first?", "optional": False},
            {"step": "appearance", "question": "What visual anchors define this character's appearance?", "optional": False},
            {"step": "voice", "question": "How should this character sound when speaking?", "optional": False},
            {"step": "home_location", "question": "Does this character have a home location or signature base in the world?", "optional": True},
            {"step": "signature_object", "question": "Does this character have a signature object, outfit piece, or anchor item?", "optional": True},
            {"step": "relationships", "question": "What relationships does this character have to existing characters, places, or objects?", "optional": True},
            {"step": "reference_assets", "question": "Do you have any reference images or audio for this character?", "optional": True},
            {"step": "visual_profile", "question": "Do you want canonical image references or generation hints so this character stays visually consistent?", "optional": True},
            {"step": "linked_agent", "question": "Should this character be linked to a specific OpenClaw agent profile?", "optional": True},
        ]

    def _visual_profile_payload(self, entity: Entity) -> dict[str, Any]:
        return {
            "canonical_image_ids": list(entity.visual.canonical_image_ids),
            "optional_image_ids": list(entity.visual.optional_image_ids),
            "preferred_models": list(entity.visual.preferred_models),
            "default_seed": entity.visual.default_seed,
            "prompt_notes": entity.visual.prompt_notes,
            "negative_prompt": entity.visual.negative_prompt,
            "lora_refs": [
                {
                    "name": ref.name,
                    "path": str(ref.path.relative_to(entity.entity_dir)) if ref.path is not None else None,
                    "weight": ref.weight,
                    "notes": ref.notes,
                }
                for ref in entity.visual.lora_refs
            ],
        }

    def _character_completion_summary(self, entity: Entity) -> dict[str, Any]:
        progress = self._character_intake_progress(entity)
        required_steps = [step["step"] for step in self._intake_question_plan() if not step["optional"]]
        optional_steps = [step["step"] for step in self._intake_question_plan() if step["optional"]]
        completed_required = [step for step in required_steps if progress[step]]
        completed_optional = [step for step in optional_steps if progress[step]]

        linked_entities: dict[str, str] = {}
        for relationship in entity.relationships:
            target = self._entities.get(relationship.target_id)
            if target is None:
                continue
            if target.type == "place" and relationship.kind in {"lives-in", "inhabits", "based-in"}:
                linked_entities["home_location"] = target.id
            if target.type == "object" and relationship.kind in {"uses", "owns", "wears", "carries", "wields"}:
                linked_entities["signature_object"] = target.id

        gap_report = self._character_gap_report(entity)
        return {
            "core_ready": len(completed_required) == len(required_steps),
            "completed_required_steps": completed_required,
            "completed_optional_steps": completed_optional,
            "linked_entities": linked_entities,
            "has_canonical_visual_reference": bool(entity.visual.canonical_image_ids),
            "suggested_next": self.suggest_next_character_questions(entity.id),
            "best_next_improvement": gap_report["best_next_improvement"],
        }

    def _character_gap_report(self, entity: Entity) -> dict[str, Any]:
        progress = self._character_intake_progress(entity)
        required_missing = [step["step"] for step in self._intake_question_plan() if not step["optional"] and not progress[step["step"]]]
        optional_missing = [step["step"] for step in self._intake_question_plan() if step["optional"] and not progress[step["step"]]]
        weak_facets = []
        for facet in ("identity", "appearance", "voice"):
            reason = self._facet_gap_reason(entity, facet)
            if reason is not None:
                weak_facets.append({"facet": facet, "reason": reason})

        visual_gaps: list[str] = []
        if entity.assets.get("images") and not entity.visual.canonical_image_ids:
            visual_gaps.append("Choose canonical image references from the available image assets.")
        if entity.visual.canonical_image_ids and not entity.visual.preferred_models:
            visual_gaps.append("Add preferred image models so visual generation has a stable default.")
        if entity.visual.canonical_image_ids and not entity.visual.prompt_notes:
            visual_gaps.append("Add prompt notes describing what visual anchors must stay consistent.")

        best_next = None
        if required_missing:
            step = next(step for step in self._intake_question_plan() if step["step"] == required_missing[0])
            best_next = step["question"]
        elif weak_facets:
            best_next = f"Strengthen the {weak_facets[0]['facet']} facet: {weak_facets[0]['reason']}"
        elif visual_gaps:
            best_next = visual_gaps[0]
        elif optional_missing:
            step = next(step for step in self._intake_question_plan() if step["step"] == optional_missing[0])
            best_next = step["question"]

        return {
            "required_missing": required_missing,
            "optional_missing": optional_missing,
            "weak_facets": weak_facets,
            "visual_gaps": visual_gaps,
            "best_next_improvement": best_next,
        }

    def _facet_gap_reason(self, entity: Entity, facet: str) -> str | None:
        path = entity.files.get(facet)
        if path is None or not path.exists():
            return "facet is missing"
        body = self._facet_body_text(path.read_text(encoding="utf-8"))
        if not body:
            return "facet is empty"
        lowered = body.lower()
        if lowered.startswith("describe ") and lowered.endswith(" here."):
            return "still contains placeholder text"
        if len(body.split()) < 8:
            return "is too short to anchor the character reliably"
        return None

    def _validate_seed_entity_payload(self, payload: Any, *, entity_type: str, field_name: str) -> None:
        if not isinstance(payload, dict):
            raise WriteError(f"{field_name} must be a mapping")
        entity_id = payload.get("id")
        name = payload.get("name")
        if not isinstance(entity_id, str) or not entity_id.strip():
            raise WriteError(f"{field_name} requires a non-empty id")
        if not isinstance(name, str) or not name.strip():
            raise WriteError(f"{field_name} requires a non-empty name")
        existing = self._entities.get(entity_id.strip())
        if existing is not None:
            raise WriteError(f"{field_name} id '{entity_id.strip()}' already exists; use the *_id field instead")
        summary = payload.get("summary")
        if summary is not None and (not isinstance(summary, str) or not summary.strip()):
            raise WriteError(f"{field_name} summary must be a non-empty string when provided")
        profile = payload.get("profile")
        if not isinstance(profile, str) or not profile.strip():
            raise WriteError(f"{field_name} requires a non-empty profile")
        normalized_profile = self._facet_body_text(profile)
        lowered_profile = normalized_profile.lower()
        if lowered_profile.startswith("describe ") and lowered_profile.endswith(" here."):
            raise WriteError(f"{field_name} profile must contain real descriptive content, not placeholder text")
        tags = payload.get("tags")
        if tags is not None and (not isinstance(tags, list) or not all(isinstance(tag, str) for tag in tags)):
            raise WriteError(f"{field_name} tags must be a list of strings")

    @staticmethod
    def _asset_id_from_path(path: str) -> str:
        stem = Path(path).stem.strip().lower()
        cleaned = [character if character.isalnum() else '-' for character in stem]
        slug = ''.join(cleaned).strip('-')
        while '--' in slug:
            slug = slug.replace('--', '-')
        return slug or 'asset'

    @staticmethod
    def _slugify_identifier(value: str) -> str:
        cleaned = [character.lower() if character.isalnum() else '-' for character in value.strip()]
        slug = ''.join(cleaned).strip('-')
        while '--' in slug:
            slug = slug.replace('--', '-')
        return slug or 'character'

    def _facet_has_real_content(self, entity: Entity, facet: str) -> bool:
        path = entity.files.get(facet)
        if path is None or not path.exists():
            return False
        body = self._facet_body_text(path.read_text(encoding="utf-8"))
        if not body:
            return False
        lowered = body.lower()
        return not (lowered.startswith("describe ") and lowered.endswith(" here."))

    @staticmethod
    def _facet_body_text(content: str) -> str:
        lines = content.splitlines()
        if lines and lines[0].lstrip().startswith("#"):
            lines = lines[1:]
        while lines and not lines[0].strip():
            lines = lines[1:]
        return "\n".join(lines).strip()

    def _get_entity(self, entity_id: str) -> Entity:
        try:
            return self._entities[entity_id]
        except KeyError as exc:
            raise EntityNotFoundError(f"entity '{entity_id}' not found") from exc

    @staticmethod
    def _to_summary(entity: Entity) -> EntitySummary:
        return EntitySummary(
            id=entity.id,
            type=entity.type,
            name=entity.name,
            status=entity.status,
            summary=entity.summary,
            tags=list(entity.tags),
            facets=sorted(entity.files),
        )


def as_summary_dict(summary: EntitySummary) -> dict[str, Any]:
    return {
        "id": summary.id,
        "type": summary.type,
        "name": summary.name,
        "status": summary.status,
        "summary": summary.summary,
        "tags": list(summary.tags),
        "facets": list(summary.facets),
        "related_entities": list(summary.related_entities),
        "owned_by": list(summary.owned_by),
    }
