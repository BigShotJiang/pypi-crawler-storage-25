# Copyright (c) 2026, California Institute of Technology and contributors
#
# You should have received a copy of the licensing terms for this
# software included in the file "LICENSE" located in the top-level
# directory of this package. If you did not, you can view a copy at
# https://git.ligo.org/ngdd/pytest-arrakis/-/raw/main/LICENSE

"""Arrakis publish-related fixtures.

Requires ``arrakis-backend-kafka`` and ``pytest-kafka-broker`` (the
``publish`` extra).  These fixtures are conditionally registered by
:func:`plugin.pytest_configure` when both packages are importable.
"""

from __future__ import annotations

import pytest
from arrakis_backend_kafka.backend import KafkaBackend
from arrakis_server.server import ArrakisFlightServer


@pytest.fixture(scope="function")
def arrakis_publish_backend(kafka_broker, arrakis_channel_configs, tmp_path, monkeypatch):
    """Create a real KafkaBackend pointed at the embedded broker.

    Redirects the metadata cache to tmp_path so tests don't pollute
    the user's home directory cache.
    """
    monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path))
    return KafkaBackend(
        kafka_url=kafka_broker.bootstrap_server,
        publisher_configs=arrakis_channel_configs,
        retention_time=900,
    )


@pytest.fixture(scope="function")
def arrakis_publish_server(arrakis_publish_backend):
    """Start a publish-capable ArrakisFlightServer backed by Kafka."""
    with ArrakisFlightServer(url=None, backend=arrakis_publish_backend) as server:
        yield server


@pytest.fixture(scope="function")
def arrakis_publisher(arrakis_publish_server):
    """Provide a real Publisher registered against the embedded Kafka broker."""
    from arrakis.publish import Publisher

    publisher = Publisher("FAKE_H1", arrakis_publish_server.url)
    publisher.register()

    with publisher:
        yield publisher
