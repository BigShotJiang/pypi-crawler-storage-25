# Copyright (c) 2026, California Institute of Technology and contributors
#
# You should have received a copy of the licensing terms for this
# software included in the file "LICENSE" located in the top-level
# directory of this package. If you did not, you can view a copy at
# https://git.ligo.org/ngdd/pytest-arrakis/-/raw/main/LICENSE

"""Pytest plugin providing Arrakis mock server fixtures."""

from __future__ import annotations

import os
from importlib.resources import as_file, files
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


@pytest.fixture(scope="session")
def arrakis_channel_configs() -> list[Path]:
    """Return paths to the bundled per-publisher config files."""
    data = files("pytest_arrakis.data")
    with (
        as_file(data.joinpath("FAKE_H1.toml")) as h1,
        as_file(data.joinpath("FAKE_L1.toml")) as l1,
        as_file(data.joinpath("FAKE_DYNAMIC.toml")) as dynamic,
    ):
        yield [h1, l1, dynamic]


@pytest.fixture(scope="session")
def arrakis_backend(arrakis_channel_configs):
    """Create a MockBackend configured with the bundled test channels."""
    from arrakis_server.backends.mock import MockBackend

    return MockBackend(channel_files=arrakis_channel_configs)


@pytest.fixture(scope="session")
def arrakis_server(arrakis_backend):
    """Start a mock ArrakisFlightServer, set ARRAKIS_SERVER env var, and yield it."""
    from arrakis_server.server import ArrakisFlightServer

    with ArrakisFlightServer(url=None, backend=arrakis_backend) as server:
        old = os.environ.get("ARRAKIS_SERVER")
        os.environ["ARRAKIS_SERVER"] = server.url
        yield server
        if old is None:
            del os.environ["ARRAKIS_SERVER"]
        else:
            os.environ["ARRAKIS_SERVER"] = old


@pytest.fixture(scope="session")
def arrakis_channels(arrakis_channel_configs):
    """Load channel metadata from the bundled configs and return the metadata dict."""
    from arrakis_server.metadata import ChannelConfigBackend

    backend = ChannelConfigBackend()
    for config in arrakis_channel_configs:
        backend.load(config)
    return backend.metadata


@pytest.fixture
def arrakis_mock_publisher(arrakis_channels):
    """Provide a mocked Publisher with FakeProducer for sink testing.

    Patches the Arrakis Client and Kafka Producer so that no server or
    broker is needed.  Yields ``(publisher, fake_producer)`` where
    *fake_producer* can be used to inspect ``.produce()`` calls.
    """
    from arrakis.publish import Publisher
    from mockafka import FakeProducer

    fake_producer = FakeProducer()

    # Mock Client so that register() returns channels for FAKE_H1.
    fake_h1_channels = [
        ch for ch in arrakis_channels.values() if ch.publisher == "FAKE_H1"
    ]
    mock_client = MagicMock()
    mock_client.return_value.find.return_value = iter(fake_h1_channels)

    with patch("arrakis.publish.Client", mock_client):
        publisher = Publisher("FAKE_H1")
        publisher.register()

        # Bypass enter() (which needs a real Flight server) by
        # directly assigning the fake producer and stubbing enter().
        publisher._producer = fake_producer
        publisher.enter = lambda: None

        # Capture published blocks for test assertions
        published_blocks = []

        def capturing_publish(block, **kwargs):
            published_blocks.append(block)

        publisher.publish = capturing_publish

        yield publisher, fake_producer, published_blocks

        publisher.close()


def pytest_configure(config):
    """Conditionally register the publish module for Tier 3 fixtures."""
    try:
        import arrakis_backend_kafka  # noqa: F401
        import pytest_kafka_broker  # noqa: F401
    except ImportError:
        pass
    else:
        from . import publish

        config.pluginmanager.register(publish)
