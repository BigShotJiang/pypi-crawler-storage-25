SELECT
   t.id
FROM df
CROSS JOIN t
WHERE list_contains(df.filter.sku_keys::text[], t.sku_key)
;
