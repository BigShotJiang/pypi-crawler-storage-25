# Platformcraft provider for octoDNS

### Activate venv and install dependencies

```shell
python3 -m venv .venv
source .venv/bin/activate
pip install -e .
```

#### For testing, additionally
```shell
pip install -e .[dev]
```

### Configuration

[Example](/examples/config/pc.yaml)


### Octodns examples

#### Checking entries

```shell
LOGIN={your_login} PASSWORD={your_password} octodns-sync --config-file examples/config/pc.yaml --debug
```

#### Applying entries

```shell
LOGIN={your_login} PASSWORD={your_password} octodns-sync --config-file examples/config/pc.yaml --debug --doit
```

### Test run

```shell
LOGIN={your_login} PASSWORD={your_password} python -m pytest tests/ --debug --log-cli-level=INFO
```
