import os
from os.path import dirname, join

from octodns.zone import Zone
from octodns.provider.yaml import YamlProvider

from octodns_platformcraft import *
from unittest import TestCase

import logging

log = logging.getLogger(__name__)


class TestPlatformcraftProvider(TestCase):
    BASE_URL = os.getenv("BASE_URL", "https://susanin.platformcraft.ru")
    AUTH_URL = os.getenv("AUTH_URL", "https://account.platformcraft.ru")
    LOGIN = os.getenv("LOGIN", "")
    PASSWORD = os.getenv("PASSWORD", "")
    ZONE_NAME = os.getenv("ZONE_NAME", "test.pc.")

    desired = Zone(ZONE_NAME, [])
    source = YamlProvider("test", join(dirname(__file__), "config"))
    source.populate(desired)

    def get_provider(self):
        return PlatformcraftProvider(
            "test",
            login=self.LOGIN,
            password=self.PASSWORD,
            base_url=self.BASE_URL,
            auth_url=self.AUTH_URL,
        )

    def test_bad_auth(self):
        with self.assertRaises(Exception) as ctx:
            provider = PlatformcraftProvider(
                "test", login=self.LOGIN, password="bad password"
            )
        self.assertEqual(
            "PlatformcraftAuthenticationError", type(ctx.exception).__name__
        )

    def test_populate(self):
        provider = self.get_provider()
        zone = Zone(self.ZONE_NAME, [])
        provider.populate(zone)
        plan = provider.plan(self.desired)

        self.assertIsNotNone(plan)
        has_txt = any(change.record._type == "TXT" for change in plan.changes)
        self.assertTrue(has_txt, "txt record must be in plan")
        has_srv_tcp_weight_20 = any(
            change.record.name == "_srv._tcp"
            and any(val.weight == 20 for val in change.record.values)
            for change in plan.changes
        )
        self.assertTrue(has_srv_tcp_weight_20, "check _srv._tcp with weight=20")
        for i, change in enumerate(plan.changes):
            log.debug(f"Change: {i}: {change}")
        self.assertEqual(len(plan.changes), 18)

    def test_apply(self):
        provider = self.get_provider()
        zone = Zone(self.ZONE_NAME, [])
        try:
            provider.populate(zone)
            plan = provider.plan(self.desired)

            for i, change in enumerate(plan.changes):
                log.debug(f"Change: {i}: {change}")

            provider._apply(plan)
            provider.populate(zone)
            plan = provider.plan(self.desired)

            self.assertIsNone(plan)
        finally:
            provider.delete_zone(zone)
