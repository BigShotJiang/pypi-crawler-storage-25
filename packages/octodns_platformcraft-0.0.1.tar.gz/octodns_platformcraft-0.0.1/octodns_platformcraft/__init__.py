import logging
import requests
from requests.exceptions import RequestException
from requests_ratelimiter import LimiterSession

from octodns.provider.base import BaseProvider
from octodns.record import Record
from octodns.zone import Zone
from octodns.provider import ProviderException

from octodns.record.sshfp import SshfpValue
from octodns.record.srv import SrvValue
from octodns.record.caa import CaaValue
from octodns.record.https import HttpsValue
from octodns.record.naptr import NaptrValue
from octodns.record.mx import MxValue
from octodns.record.svcb import SvcbValue

__all__ = (
    "PlatformcraftProvider",
    "PlatformcraftAuthenticationError",
    "PlatformcraftNotFoundError",
    "PlatformcraftBadRequestError",
)

LOG = logging.getLogger("PlatformcraftProvider")


class PlatformcraftError(ProviderException):
    def __init__(self, data):
        super().__init__(data)


class PlatformcraftAuthenticationError(PlatformcraftError):
    def __init__(self, data):
        super().__init__(data)


class PlatformcraftForbiddenError(PlatformcraftError):
    def __init__(self, data):
        super().__init__(data)


class PlatformcraftNotFoundError(PlatformcraftError):
    def __init__(self, data):
        super().__init__(data)


class PlatformcraftBadRequestError(PlatformcraftError):
    def __init__(self, data):
        super().__init__(data)


class PlatformcraftProvider(BaseProvider):
    SUPPORTS_GEO = False
    SUPPORTS_DYNAMIC = True
    SUPPORTS = set(
        (
            "ALIAS",
            "A",
            "AAAA",
            "CAA",
            "CNAME",
            "DS",
            "MX",
            "NS",
            "PTR",
            "SSHFP",
            "SRV",
            "TLSA",
            "TXT",
            "SVCB",
            "HTTPS",
            "NAPTR",
        )
    )

    """
    OctoDNS provider for Platformcraft DNS-service API (v1).

    :param id: Provider ID in OctoDNS config
    :param base_url: Base URL of the API (e.g. 'https://susanin.platformcraft.ru')
    :param token: Bearer token for authentication or
    :param login: Platformcraft account login
    :param password: Platformcraft account password
    :param timeout: Request timeout in seconds (default: 30)
    """

    def __init__(
        self,
        id,
        token="",
        login="",
        password="",
        base_url="https://susanin.platformcraft.ru",
        auth_url="https://account.platformcraft.ru",
        timeout=30,
        rps=40,
        *args,
        **kwargs,
    ):
        self.log = logging.getLogger("PlatformcraftProvider[{}]".format(id))
        self.log.debug("__init__: id=%s, base_url=%s", id, base_url)
        super(PlatformcraftProvider, self).__init__(id, *args, **kwargs)
        if token:
            self._token = token
        else:
            self._token = self._get_token(auth_url, login, password)
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._session = LimiterSession(per_second=rps)
        self._session.headers.update(
            {
                "Authorization": "Bearer {}".format(self._token),
                "Content-Type": "application/json",
                "Accept": "application/json",
            }
        )

    def populate(self, zone, target=False, lenient=False):
        self.log.debug("_populate: zone=%s, target=%s", zone.name, target)

        try:
            self._request("GET", f"/zones/{zone.name}", expected_codes=[200])
        except Exception as e:
            if "404" in str(e):
                return True
            raise e

        try:
            rrsets_preview = self._request(
                "GET", f"/zones/{zone.name}/rrsets", expected_codes=[200]
            )
        except Exception as e:
            if target:
                raise
            self.log.error("Failed to list rrsets: %s", e)
            return False

        if not rrsets_preview:
            self.log.debug("No rrsets found")
            return False

        for item in rrsets_preview:
            rr_type = item["rr_type"].upper()
            if rr_type in ("SOA",):
                self.log.debug("populate: skipping %s record", rr_type)
                continue

            rr_name = item["rr_name"]
            try:
                rrset_detail = self._request(
                    "GET",
                    f"/zones/{zone.name}/rrsets/{rr_name}/{rr_type}",
                    expected_codes=[200],
                )
            except Exception as e:
                self.log.error("Failed to fetch RRset %s/%s: %s", rr_name, rr_type, e)
                continue

            name, data = self._parse_rrset(zone.name, rrset_detail)
            record = Record.new(zone, name, data, source=self, lenient=lenient)
            zone.add_record(record)

        return True

    def _apply(self, plan):
        desired = plan.desired
        changes = plan.changes
        zone_name = desired.name

        try:
            self._request("GET", f"/zones/{zone_name}", expected_codes=[200])
        except Exception as e:
            if "404" in str(e):
                self.create_zone(desired)
            else:
                raise e

        self.log.debug("_apply: zone=%s, changes=%d", zone_name, len(changes))

        for change in changes:
            self.log.debug(f"_apply: change: {change}")

            existing = change.existing
            new = change.new

            if new is None:
                rr_name = existing.name
                if not rr_name:
                    rr_name = "@"
                rr_type = existing._type
                self.log.debug("Deleting RRset %s/%s", rr_name, rr_type)
                try:
                    self._request(
                        "DELETE",
                        f"/zones/{zone_name}/rrsets/{rr_name}/{rr_type}",
                        expected_codes=[204],
                    )
                except Exception as e:
                    raise Exception(f"Failed to delete RRset: {e}")

            elif existing is None:
                rrset = self._build_rrset_data(new)
                body = [rrset]
                self.log.debug("Creating RRset %s/%s", new.name, new._type)
                try:
                    self._request(
                        "POST",
                        f"/zones/{zone_name}/rrsets",
                        expected_codes=[200],
                        data=body,
                    )
                except Exception as e:
                    raise Exception(f"Failed to create RRset: {e}")

            else:
                rrset_update = self._build_rrset_data(new)
                self.log.debug("Updating RRset %s/%s", new.name, new._type)
                try:
                    self._request(
                        "PUT",
                        f"/zones/{zone_name}/rrsets/{new.name}/{new._type}",
                        expected_codes=[200],
                        data=rrset_update,
                    )
                except Exception as e:
                    raise Exception(f"Failed to update RRset: {e}")

    def _get_token(self, auth_url, login, password):
        try:
            response = requests.post(
                f"{auth_url}/token?login={login}&password={password}"
            )
            if response.status_code != 200:
                raise PlatformcraftAuthenticationError(
                    f"invalid response status code: {response.status_code}"
                )
            data = response.json()
            return data["access_token"]
        except Exception as e:
            raise PlatformcraftAuthenticationError(f"get token failed: {e}")

    def _request(self, method, path, expected_codes=None, data=None):
        if expected_codes is None:
            expected_codes = [200]
        url = f"{self._base_url}{path}"
        self.log.debug("_request: %s %s", method, url)
        try:
            resp = self._session.request(method, url, json=data, timeout=self._timeout)
        except RequestException as e:
            raise Exception(f"Request failed: {e}")

        if resp.status_code == 204:
            return None
        if resp.status_code in expected_codes:
            if resp.content:
                return resp.json()
            return None

        try:
            error_msg = resp.json().get("msg", resp.text)
        except:
            error_msg = resp.text
        if resp.status_code == 403:
            raise PlatformcraftForbiddenError("forbidden")
        raise Exception(f"Unexpected response {resp.status_code}: {error_msg}")

    def _build_rrset_data(self, record):
        stored_records = record.data.get("_records", [])
        weights_enabled = record.data.get("_weights_enabled", False)
        values = record.values if hasattr(record, "values") else [record.value]

        if not stored_records and values:
            weights = {}
            dynamic = record.data.get("dynamic")
            if dynamic:
                rules = dynamic.get("rules", [])
                if rules:
                    active_pool_name = rules[0].get("pool")
                    pool_values = (
                        dynamic.get("pools", {})
                        .get(active_pool_name, {})
                        .get("values", [])
                    )
                    weights = {v["value"]: v["weight"] for v in pool_values}

            for v in values:
                if record._type == "NAPTR":
                    val = f"{v.order} {v.preference} {v.flags or ''} {v.service or ''} {v.regexp or ''} {v.replacement}"
                elif hasattr(v, "rdata_text"):
                    val = v.rdata_text
                else:
                    val = str(v)
                if hasattr(v, "weight"):
                    weight = v.get("weight", 0)
                else:
                    weight = weights.get(val, 0)
                stored_records.append(
                    {"content": val, "disabled": False, "weight": weight}
                )

        if not weights_enabled:
            weights_enabled = any(r["weight"] > 0 for r in stored_records)

        rrset = {
            "ttl": record.ttl,
            "records": [
                {
                    "content": [r["content"]]
                    if isinstance(r["content"], str)
                    else r["content"],
                    "disabled": r.get("disabled", False),
                    "weight": r.get("weight", 0),
                }
                for r in stored_records
            ],
            "weights_enabled": weights_enabled,
        }
        rr_name = record.name
        if not rr_name:
            rr_name = "@"
        rrset["rr_name"] = rr_name
        rrset["rr_type"] = record._type
        return rrset

    def _parse_rrset(self, zone_name, rrset_data):
        name = rrset_data["rr_name"]
        if name == "@":
            name = ""
        _type = rrset_data["rr_type"]
        ttl = rrset_data["ttl"]
        records = rrset_data.get("records", [])
        weights_enabled = rrset_data.get("weights_enabled", False)

        values = []
        _records = []
        for r in records:
            content = self._parse_content(
                _type,
                r["content"][0] if len(r["content"]) == 1 else " ".join(r["content"]),
            )
            if not r.get("disabled", False):
                values.append(content)
            _records.append(
                {
                    "content": content,
                    "disabled": r.get("disabled", False),
                    "weight": r.get("weight", 0),
                }
            )

        data = {
            "ttl": ttl,
            "type": _type,
            "values": values,
            "_records": _records,
            "_weights_enabled": weights_enabled,
        }

        if weights_enabled:
            data["dynamic"] = {
                "pools": {
                    "main": {
                        "values": [
                            {"value": r["content"], "weight": r["weight"]}
                            for r in _records
                        ]
                    }
                },
                "rules": [{"pool": "main"}],
            }

        if _type in ("CNAME", "PTR", "DNAME"):
            data["value"] = values[0] if values else None
        return name, data

    VALUE_CLASSES = {
        "SSHFP": SshfpValue,
        "SRV": SrvValue,
        "CAA": CaaValue,
        "HTTPS": HttpsValue,
        "NAPTR": NaptrValue,
        "MX": MxValue,
        "SVCB": SvcbValue,
    }

    def _parse_content(self, record_type, content):
        _cls = self.VALUE_CLASSES.get(record_type.upper())
        if not _cls:
            return content
        return _cls.parse_rdata_text(content)

    def create_zone(self, zone, ttl=None):
        self.log.debug("create_zone: %s", zone.name)
        data = {"name": zone.name, "enabled": True}
        try:
            self._request("POST", "/zones", expected_codes=[200], data=data)
        except Exception as e:
            if "400" in str(e):
                raise PlatformcraftBadRequestError(
                    f"Cannot create zone {zone.name}: {e}"
                )
            raise

    def delete_zone(self, zone):
        self.log.debug("delete_zone: %s", zone.name)
        try:
            self._request("DELETE", f"/zones/{zone.name}", expected_codes=[204])
        except Exception as e:
            if "404" in str(e):
                return
            if "400" in str(e):
                raise PlatformcraftBadRequestError(
                    f"Cannot delete zone {zone.name}: {e}"
                )
            raise

