"""Connection configuration models for database engines."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal


@dataclass(frozen=True)
class ConnectionConfig:
    """Configuration for one named database connection."""

    name: str
    dialect: Literal["sqlite", "postgresql", "mssql", "mysql"]
    encrypted_connection_string: str
    pool_size: int = 5
    max_overflow: int = 10
    pool_timeout: int = 30
    echo: bool = False
