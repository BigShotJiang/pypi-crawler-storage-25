"""Public database interfaces for appcore."""

from __future__ import annotations

from sqlalchemy.orm import DeclarativeBase, Session
from sqlalchemy.engine import Engine

from appcore.database.connection_config import ConnectionConfig
from appcore.database.db_manager import DatabaseManager


class Base(DeclarativeBase):
    """Base class for SQLAlchemy ORM models."""


_manager: DatabaseManager | None = None


def configure_manager(manager: DatabaseManager) -> None:
    """Store the active DatabaseManager for module-level accessors."""
    global _manager
    _manager = manager


def get_engine(name: str | None = None) -> Engine:
    """Return the configured engine from the active manager."""
    if _manager is None:
        raise RuntimeError("Database manager has not been configured")
    return _manager.get_engine(name)


def get_session(name: str | None = None) -> Session:
    """Return the scoped session from the active manager."""
    if _manager is None:
        raise RuntimeError("Database manager has not been configured")
    return _manager.get_session(name)


__all__ = [
    "Base",
    "ConnectionConfig",
    "DatabaseManager",
    "configure_manager",
    "get_engine",
    "get_session",
]
