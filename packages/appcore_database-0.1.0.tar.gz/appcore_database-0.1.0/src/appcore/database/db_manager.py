"""Database engine and session lifecycle management."""

from __future__ import annotations

from collections.abc import Generator
from contextlib import contextmanager

from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, scoped_session, sessionmaker

from appcore.common import exceptions as common_exceptions
from appcore.crypto import crypto
from appcore.database import connection_config


class DatabaseManager:
    """Manage named SQLAlchemy engines and scoped sessions."""

    def __init__(
        self,
        configs: list[connection_config.ConnectionConfig],
        crypto_service: crypto.CryptoService,
        default_name: str = "primary",
    ) -> None:
        """Create and verify all configured engines and sessions."""
        self._default_name = default_name
        self._engines: dict[str, Engine] = {}
        self._sessions: dict[str, scoped_session[Session]] = {}

        for config in configs:
            connection_string = crypto_service.decrypt_if_encrypted(
                config.encrypted_connection_string
            )
            engine_kwargs: dict[str, object] = {"echo": config.echo}
            if config.dialect != "sqlite":
                engine_kwargs.update(
                    {
                        "pool_size": config.pool_size,
                        "max_overflow": config.max_overflow,
                        "pool_timeout": config.pool_timeout,
                    }
                )

            try:
                engine = create_engine(connection_string, **engine_kwargs)
                with engine.connect() as connection:
                    connection.execute(text("SELECT 1"))
            except Exception as exc:
                raise common_exceptions.DatabaseError(
                    f"Failed to initialize database connection {config.name!r}: {exc}"
                ) from exc

            factory = scoped_session(sessionmaker(bind=engine, autoflush=False, autocommit=False))
            self._engines[config.name] = engine
            self._sessions[config.name] = factory

    def get_engine(self, name: str | None = None) -> Engine:
        """Return the configured engine for the given name."""
        key = name or self._default_name
        try:
            return self._engines[key]
        except KeyError as exc:
            raise KeyError(f"Unknown database connection: {key}") from exc

    def get_session(self, name: str | None = None) -> Session:
        """Return the thread-local scoped session for the given name."""
        key = name or self._default_name
        try:
            factory = self._sessions[key]
        except KeyError as exc:
            raise KeyError(f"Unknown database session: {key}") from exc
        return factory()

    @contextmanager
    def session_context(self, name: str | None = None) -> Generator[Session, None, None]:
        """Provide a transactional session context."""
        key = name or self._default_name
        session = self.get_session(key)
        try:
            yield session
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()
            self._sessions[key].remove()

    def dispose_all(self) -> None:
        """Dispose all managed engine pools."""
        for session_factory in self._sessions.values():
            session_factory.remove()
        for engine in self._engines.values():
            engine.dispose()
