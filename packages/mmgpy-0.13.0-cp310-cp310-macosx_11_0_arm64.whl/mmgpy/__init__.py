"""Python bindings for the MMG library."""

from __future__ import annotations

from ._cli import _find_mmg_executable  # noqa: F401  # Used by tests
from ._logging import (
    configure_logging,
    disable_logging,
    enable_debug,
    get_log_file,
    get_logger,
    set_log_file,
    set_log_level,
)

# Version info
try:
    from . import _version  # type: ignore[attr-defined]

    __version__ = _version.__version__
except ImportError:
    __version__ = "unknown"

# Core C++ bindings
from . import interactive, lagrangian, metrics, progress, repair, sizing
from ._io import read
from ._mesh import MeshKind
from ._mmgpy import MMG_VERSION  # type: ignore[attr-defined]
from ._options import Mmg2DOptions, Mmg3DOptions, MmgSOptions
from ._progress import CancellationError, ProgressEvent, rich_progress
from ._pyvista import from_pyvista, polydata_from_2d_triangles, to_pyvista
from ._remesh import mmg2d, mmg3d, mmgs  # noqa: F401
from ._reorder import reorder_cuthill_mckee
from ._result import RemeshResult
from ._transfer import interpolate_field, transfer_fields
from ._validation import (
    IssueSeverity,
    QualityStats,
    ValidationError,
    ValidationIssue,
    ValidationReport,
)
from .lagrangian import (
    detect_boundary_vertices,
    move_mesh,
    propagate_displacement,
    propagate_displacement_elasticity,
)
from .sizing import (
    BoxSize,
    CylinderSize,
    PointSize,
    SizingConstraint,
    SphereSize,
    apply_sizing_constraints,
)

__all__ = [
    "MMG_VERSION",
    "BoxSize",
    "CancellationError",
    "CylinderSize",
    "IssueSeverity",
    "MeshKind",
    "Mmg2DOptions",
    "Mmg3DOptions",
    "MmgSOptions",
    "PointSize",
    "ProgressEvent",
    "QualityStats",
    "RemeshResult",
    "SizingConstraint",
    "SphereSize",
    "ValidationError",
    "ValidationIssue",
    "ValidationReport",
    "__version__",
    "apply_sizing_constraints",
    "configure_logging",
    "detect_boundary_vertices",
    "disable_logging",
    "enable_debug",
    "from_pyvista",
    "get_log_file",
    "get_logger",
    "interactive",
    "interpolate_field",
    "lagrangian",
    "metrics",
    "move_mesh",
    "polydata_from_2d_triangles",
    "progress",
    "propagate_displacement",
    "propagate_displacement_elasticity",
    "read",
    "reorder_cuthill_mckee",
    "repair",
    "rich_progress",
    "set_log_file",
    "set_log_level",
    "sizing",
    "to_pyvista",
    "transfer_fields",
]
