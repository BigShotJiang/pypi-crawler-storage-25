"""Sherpa reconciliation processor"""

__version__ = "1.8.41"
