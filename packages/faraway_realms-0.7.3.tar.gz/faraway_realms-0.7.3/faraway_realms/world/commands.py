"""Command parsing — converts raw slash-command strings into Command objects."""

from __future__ import annotations

import dataclasses
from dataclasses import dataclass
from enum import Enum, auto


class CommandType(Enum):
    """Enumeration of supported command types."""

    MOVE = auto()
    ATTACK = auto()
    OPPORTUNITY_ATTACK = auto()
    TARGET = auto()
    SPAWN = auto()
    PRIME_COOLDOWN = auto()
    CLEAR_PRIME = auto()
    CAST = auto()
    INTERACT = auto()
    UNKNOWN = auto()


@dataclass(frozen=True)
class Command:
    """An immutable parsed game command.

    Parameters
    ----------
    command_type : CommandType
        The type of command.
    actor : str
        Entity reference the command acts as (e.g. ``"@self"`` or a numeric ID).
    args : tuple[str, ...]
        Additional positional arguments.
    raw : str
        Original unparsed string, preserved for display.
    """

    command_type: CommandType
    actor: str
    args: tuple[str, ...]
    raw: str


# ---------------------------------------------------------------------------
# Self-documenting command specifications
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ParamSpec:
    """Describes a single command parameter.

    Parameters
    ----------
    name : str
        Parameter name (used in usage strings and help text).
    description : str
        Human-readable description shown in ``/help``.
    required : bool
        Whether the parameter must be supplied.
    choices : tuple[str, ...] | None
        Allowed values, or ``None`` when unconstrained.
    """

    name: str
    description: str
    required: bool = True
    choices: tuple[str, ...] | None = None


@dataclass(frozen=True)
class CommandSpec:
    """Describes a user-facing (or internal) command.

    Parameters
    ----------
    verb : str | None
        Slash-command verb (e.g. ``"move"``).  ``None`` for internal commands
        that have no user-visible syntax.
    description : str
        Human-readable description shown in ``/help``.
    params : tuple[ParamSpec, ...]
        Ordered parameter specifications.
    user_facing : bool
        When ``False`` the command is hidden from the general help listing.
    """

    verb: str | None
    description: str
    params: tuple[ParamSpec, ...] = ()
    user_facing: bool = True


COMMAND_SPECS: dict[CommandType, CommandSpec] = {
    CommandType.MOVE: CommandSpec(
        verb="move",
        description="Move your character one tile in a direction.",
        params=(
            ParamSpec(
                "direction",
                "Cardinal direction.",
                choices=("left", "right", "up", "down"),
            ),
        ),
    ),
    CommandType.ATTACK: CommandSpec(
        verb="attack",
        description="Perform a melee attack on a target.",
        params=(
            ParamSpec(
                "target",
                "Target entity ID or @target for your current target.",
            ),
        ),
    ),
    CommandType.TARGET: CommandSpec(
        verb="target",
        description="Set, cycle, or clear your current target.",
        params=(
            ParamSpec(
                "target",
                "Entity ID, 'next' to cycle to nearest hostile, or omit to clear.",
                required=False,
            ),
        ),
    ),
    CommandType.CAST: CommandSpec(
        verb="cast",
        description="Cast an ability on a target.",
        params=(
            ParamSpec("ability", "Ability name (e.g. kick, firebolt)."),
            ParamSpec(
                "target",
                "Target entity ID or @target.  Use @self for self-targeted abilities.",
                required=False,
            ),
        ),
    ),
    CommandType.INTERACT: CommandSpec(
        verb="open",
        description="Open or close an interactable tile (e.g. a door) in a direction.",
        params=(
            ParamSpec(
                "direction",
                "Cardinal direction.",
                choices=("left", "right", "up", "down"),
            ),
        ),
    ),
    CommandType.SPAWN: CommandSpec(
        verb="spawn",
        description="(GM) Spawn a creature at a map position.",
        params=(
            ParamSpec("creature", "Creature type name from the registry."),
            ParamSpec(
                "position",
                "Tile coordinate 'x,y' or 'random' for a random visible tile.",
            ),
        ),
    ),
    # Internal commands — no slash syntax, hidden from help
    CommandType.PRIME_COOLDOWN: CommandSpec(
        verb=None,
        description="(internal) Prime attack cooldown.",
        user_facing=False,
    ),
    CommandType.CLEAR_PRIME: CommandSpec(
        verb=None,
        description="(internal) Clear attack cooldown prime.",
        user_facing=False,
    ),
    CommandType.OPPORTUNITY_ATTACK: CommandSpec(
        verb=None,
        description="(internal) Opportunity attack on move-away.",
        user_facing=False,
    ),
    CommandType.UNKNOWN: CommandSpec(
        verb=None,
        description="(internal) Unrecognised command.",
        user_facing=False,
    ),
}


# ---------------------------------------------------------------------------
# Command factory helpers
# ---------------------------------------------------------------------------


def make_attack_command(
    attacker_id: int,
    target_id: int,
    command_type: CommandType = CommandType.ATTACK,
) -> Command:
    """Build an attack-family command.

    Parameters
    ----------
    attacker_id : int
        Entity ID of the attacker.
    target_id : int
        Entity ID of the target.
    command_type : CommandType
        ``ATTACK`` (default) or ``OPPORTUNITY_ATTACK``.

    Returns
    -------
    Command
        An immutable command with *attacker_id* as actor and *target_id* as
        the first arg.
    """
    verb = command_type.name.lower()
    return Command(
        command_type=command_type,
        actor=str(attacker_id),
        args=(str(target_id),),
        raw=f"/{verb} {attacker_id} {target_id}",
    )


def make_prime_cooldown_command(entity_id: int) -> Command:
    """Build a PRIME_COOLDOWN command to initialise an entity's attack cooldown.

    Parameters
    ----------
    entity_id : int
        Entity whose cooldown should be primed.

    Returns
    -------
    Command
        A PRIME_COOLDOWN command with *entity_id* as actor.
    """
    return Command(
        command_type=CommandType.PRIME_COOLDOWN,
        actor=str(entity_id),
        args=(),
        raw=f"/prime_cooldown {entity_id}",
    )


def make_clear_prime_command(entity_id: int) -> Command:
    """Build a CLEAR_PRIME command to reset an entity's attack-cooldown bar.

    Parameters
    ----------
    entity_id : int
        Entity whose cooldown tracking should be cleared.

    Returns
    -------
    Command
        A CLEAR_PRIME command with *entity_id* as actor.
    """
    return Command(
        command_type=CommandType.CLEAR_PRIME,
        actor=str(entity_id),
        args=(),
        raw=f"/clear_prime {entity_id}",
    )


def make_target_command(actor_id: int, target_id: int) -> Command:
    """Build a TARGET command to assign a new target to an entity.

    Parameters
    ----------
    actor_id : int
        Entity ID of the entity acquiring the target.
    target_id : int
        Entity ID of the new target.

    Returns
    -------
    Command
        A TARGET command.
    """
    return Command(
        command_type=CommandType.TARGET,
        actor=str(actor_id),
        args=(str(target_id),),
        raw=f"/target {actor_id} {target_id}",
    )


def make_cast_command(actor_id: int, ability_name: str, target_id: int) -> Command:
    """Build a CAST command.

    Parameters
    ----------
    actor_id : int
        Entity ID of the caster.
    ability_name : str
        Name of the ability to cast.
    target_id : int
        Entity ID of the target.

    Returns
    -------
    Command
        An immutable CAST command.
    """
    return Command(
        command_type=CommandType.CAST,
        actor=str(actor_id),
        args=(ability_name, str(target_id)),
        raw=f"/cast {actor_id} {ability_name} {target_id}",
    )


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------


class CommandParser:
    """Converts a raw slash-command string into a :class:`Command`.

    Actor inference
    ---------------
    The second token is treated as an explicit actor only when it is
    ``"@self"`` or a bare integer (explicit entity ID for GM use).
    Anything else is treated as the first *argument*, with ``"@self"``
    implied as the actor.  This means ``/move left`` and
    ``/move @self left`` are equivalent.

    Examples
    --------
    >>> parser = CommandParser()
    >>> cmd = parser.parse("/move left")
    >>> cmd.command_type
    <CommandType.MOVE: 1>
    >>> cmd.actor
    '@self'
    """

    # Derived from COMMAND_SPECS so adding a new spec automatically registers
    # its verb — no second place to update.
    _VERB_TYPES: dict[str, CommandType] = {
        spec.verb: ct for ct, spec in COMMAND_SPECS.items() if spec.verb is not None
    }

    def parse(self, text: str) -> Command:
        """Parse a raw string and return a :class:`Command`.

        Parameters
        ----------
        text : str
            Raw input, optionally prefixed with ``/``.

        Returns
        -------
        Command
            Parsed command, or one with ``CommandType.UNKNOWN`` if unrecognised.
        """
        stripped = text.strip().lstrip("/")
        if not stripped:
            return self._build_unknown(text)
        return self._parse_tokens(stripped.split(), text)

    def _parse_tokens(self, tokens: list[str], raw: str) -> Command:
        command_type = self._VERB_TYPES.get(tokens[0].lower())
        if command_type is None:
            return self._build_unknown(raw)
        return self._build_command(tokens, raw, command_type)

    @staticmethod
    def _build_command(
        tokens: list[str], raw: str, command_type: CommandType
    ) -> Command:
        if len(tokens) < 2:
            return Command(command_type=command_type, actor="@self", args=(), raw=raw)
        second = tokens[1]
        if second == "@self" or second.lstrip("-").isdigit():
            # Explicit actor: @self or a numeric entity ID (GM use)
            return Command(
                command_type=command_type,
                actor=second,
                args=tuple(tokens[2:]),
                raw=raw,
            )
        # Implied @self — second token is the first argument
        return Command(
            command_type=command_type,
            actor="@self",
            args=tuple(tokens[1:]),
            raw=raw,
        )

    @staticmethod
    def _build_unknown(raw: str) -> Command:
        return Command(command_type=CommandType.UNKNOWN, actor="", args=(), raw=raw)


# ---------------------------------------------------------------------------
# Resolver
# ---------------------------------------------------------------------------


class CommandResolver:
    """Normalises client-side shorthands in a :class:`Command` for a specific session.

    Applied once per incoming network message before the command enters the
    game's dispatch layer.  Handles shorthands whose meaning depends on
    *who* sent the command (session context).  Shorthands that require live
    game state (``@target``) are intentionally left for the game's own
    dispatch layer to resolve at tick time.

    Currently resolved tokens
    -------------------------
    ``@self``
        The session owner's entity ID.

    Parameters
    ----------
    actor_id : int
        Entity ID of the owning session.
    """

    def __init__(self, actor_id: int) -> None:
        self._eid = str(actor_id)

    def resolve(self, cmd: Command) -> Command:
        """Return a new :class:`Command` with all session shorthands expanded.

        Parameters
        ----------
        cmd : Command
            Parsed but unresolved command from the client.

        Returns
        -------
        Command
            Identical command with ``@self`` replaced by the session entity ID
            in both the actor and every argument position.
        """
        return dataclasses.replace(
            cmd,
            actor=self._expand(cmd.actor),
            args=tuple(self._expand(a) for a in cmd.args),
        )

    def _expand(self, ref: str) -> str:
        return self._eid if ref == "@self" else ref
