"""EventBus — typed publish/subscribe event bus for inter-system communication."""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from faraway_realms.world.events import Event, EventType


class EventBus:
    """Central event bus: systems publish typed events; subscribers receive them.

    Subscribers are registered with a priority (lower int = called first).
    Within the same priority they are called in insertion order.
    ``flush`` delivers all ready events in bounded rounds; each round may
    publish new events that are picked up in the next round.

    Parameters
    ----------
    (none — construct with default args)
    """

    def __init__(self) -> None:
        # event_type → list of (priority, seq, handler)  — sorted on insert
        self._subscribers: dict[
            EventType, list[tuple[int, int, Callable[[Event], None]]]
        ] = {}
        self._queue: list[Event] = []
        self._seq: int = 0
        self._events_fired: int = 0
        self._max_cascade_depth: int = 0

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def subscribe(
        self,
        event_type: EventType,
        handler: Callable[[Event], None],
        priority: int = 0,
    ) -> None:
        """Register a handler for *event_type*.

        Parameters
        ----------
        event_type : EventType
            The event type to listen for.
        handler : Callable[[Event], None]
            Callable invoked with each matching event.
        priority : int
            Delivery order; lower = called first.  Within the same priority
            handlers are called in insertion order.
        """
        bucket = self._subscribers.setdefault(event_type, [])
        bucket.append((priority, self._seq, handler))
        self._seq += 1
        bucket.sort(key=lambda t: (t[0], t[1]))

    # ------------------------------------------------------------------
    # Publishing
    # ------------------------------------------------------------------

    def publish(self, event: Event) -> None:
        """Enqueue *event* for delivery on the next ``flush``.

        Parameters
        ----------
        event : Event
            The event to publish.
        """
        self._queue.append(event)

    # ------------------------------------------------------------------
    # Delivery
    # ------------------------------------------------------------------

    def flush(self, abs_tick: int, depth: int = 10) -> None:
        """Deliver all ready events, allowing cascades up to *depth* rounds.

        Parameters
        ----------
        abs_tick : int
            Current absolute tick; events with ``resolve_at_tick <= abs_tick``
            are considered ready.
        depth : int
            Maximum number of delivery rounds.  Prevents infinite cascades.
        """
        rounds = 0
        for _ in range(depth):
            if not self._deliver_ready(abs_tick):
                break
            rounds += 1
        if rounds > self._max_cascade_depth:
            self._max_cascade_depth = rounds

    def _deliver_ready(self, abs_tick: int) -> bool:
        """Deliver one batch of ready events; return True when any were delivered."""
        ready = [e for e in self._queue if e.resolve_at_tick <= abs_tick]
        self._queue = [e for e in self._queue if e.resolve_at_tick > abs_tick]
        for event in ready:
            self._dispatch(event)
        return bool(ready)

    def _dispatch(self, event: Event) -> None:
        self._events_fired += 1
        for _priority, _seq, handler in self._subscribers.get(event.event_type, []):
            handler(event)

    # ------------------------------------------------------------------
    # Maintenance
    # ------------------------------------------------------------------

    def purge(self, predicate: Callable[[Event], bool]) -> None:
        """Remove queued events that match *predicate*.

        Parameters
        ----------
        predicate : Callable[[Event], bool]
            Returns ``True`` for events that should be removed.
        """
        self._queue = [e for e in self._queue if not predicate(e)]

    # ------------------------------------------------------------------
    # Diagnostics
    # ------------------------------------------------------------------

    @property
    def pending_count(self) -> int:
        """Number of events currently queued (not yet delivered)."""
        return len(self._queue)

    def take_tick_stats(self) -> dict[str, int]:
        """Return and reset per-tick event counters.

        Returns
        -------
        dict[str, int]
            ``events_fired`` — total events dispatched since last call.
            ``max_cascade_depth`` — deepest flush round reached since last call.
        """
        stats = {
            "events_fired": self._events_fired,
            "max_cascade_depth": self._max_cascade_depth,
        }
        self._events_fired = 0
        self._max_cascade_depth = 0
        return stats
