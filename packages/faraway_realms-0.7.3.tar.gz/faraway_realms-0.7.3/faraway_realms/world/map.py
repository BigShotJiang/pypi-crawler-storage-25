"""Game map — a 2-D grid of Tiles with entity position tracking."""

from __future__ import annotations

import numpy as np

from faraway_realms.types import Pos
from faraway_realms.world.tile import (
    TILE_REGISTRY,
    Tile,
    floor_tile,
    unknown_tile,
    wall_tile,
)


class Map:
    """A 2-D grid of Tiles with entity position tracking.

    Parameters
    ----------
    width : int
        Number of columns.
    height : int
        Number of rows.
    tiles : list[list[Tile]]
        Row-major (y, x) 2-D list of Tile instances.
    """

    def __init__(self, width: int, height: int, tiles: list[list[Tile]]) -> None:
        self.width = width
        self.height = height
        self._tiles = tiles
        self._entity_positions: dict[int, Pos] = {}
        self._occupied: set[Pos] = set()
        self._transparency_cache: np.ndarray | None = None
        self._original_bg: dict[Pos, tuple[int, int, int]] = {}
        self._dirty_tiles: set[Pos] = set()
        self.tile_zones: dict[Pos, str] = {}
        self.tile_type_ids: dict[Pos, str] = {}

    def get_tile(self, x: int, y: int) -> Tile:
        """Return the tile at (x, y).

        Parameters
        ----------
        x : int
            Column index.
        y : int
            Row index.

        Returns
        -------
        Tile
            The tile at the given position.
        """
        return self._tiles[y][x]

    def is_walkable(self, x: int, y: int) -> bool:
        """Return whether the tile at (x, y) can be entered.

        Parameters
        ----------
        x : int
            Column index.
        y : int
            Row index.

        Returns
        -------
        bool
            True if the tile is walkable and within bounds.
        """
        if not (0 <= x < self.width and 0 <= y < self.height):
            return False
        return self._tiles[y][x].walkable

    def place_entity(self, entity_id: int, x: int, y: int) -> None:
        """Place an entity at (x, y).

        Parameters
        ----------
        entity_id : int
            Unique entity identifier.
        x : int
            Column index.
        y : int
            Row index.
        """
        self._entity_positions[entity_id] = (x, y)
        self._occupied.add((x, y))

    def move_entity(self, entity_id: int, dx: int, dy: int) -> bool:
        """Attempt to move an entity by (dx, dy).

        Parameters
        ----------
        entity_id : int
            Unique entity identifier.
        dx : int
            Column delta.
        dy : int
            Row delta.

        Returns
        -------
        bool
            True if the move succeeded, False if blocked.
        """
        x, y = self._entity_positions[entity_id]
        new_x, new_y = x + dx, y + dy
        if not self.is_walkable(new_x, new_y):
            return False
        self._occupied.discard((x, y))
        self._entity_positions[entity_id] = (new_x, new_y)
        self._occupied.add((new_x, new_y))
        return True

    def get_entity_position(self, entity_id: int) -> Pos:
        """Return the current (x, y) position of an entity.

        Parameters
        ----------
        entity_id : int
            Unique entity identifier.

        Returns
        -------
        tuple[int, int]
            The (x, y) position.
        """
        return self._entity_positions[entity_id]

    def is_occupied(self, x: int, y: int) -> bool:
        """Return whether any entity currently occupies (x, y).

        Parameters
        ----------
        x : int
            Column index.
        y : int
            Row index.

        Returns
        -------
        bool
            True if at least one entity is positioned at (x, y).
        """
        return (x, y) in self._occupied

    def has_entity(self, entity_id: int) -> bool:
        """Return whether *entity_id* is currently placed on the map.

        Parameters
        ----------
        entity_id : int
            Unique entity identifier.

        Returns
        -------
        bool
            True if the entity has a position on this map.
        """
        return entity_id in self._entity_positions

    def get_all_positions(self) -> dict[int, Pos]:
        """Return a snapshot of all entity positions.

        Returns
        -------
        dict[int, tuple[int, int]]
            Mapping of ``entity_id → (x, y)`` for every placed entity.
        """
        return dict(self._entity_positions)

    @property
    def transparency_array(self) -> np.ndarray:
        """Return a (height, width) bool array; True = transparent tile.

        Computed once and cached; invalidated by :meth:`set_tile`.
        """
        if self._transparency_cache is None:
            arr = np.zeros((self.height, self.width), dtype=bool)
            for y in range(self.height):
                for x in range(self.width):
                    arr[y, x] = self._tiles[y][x].walkable
            self._transparency_cache = arr
        return self._transparency_cache

    def set_tile(self, x: int, y: int, tile: Tile) -> None:
        """Replace the tile at (x, y).

        Parameters
        ----------
        x : int
            Column index.
        y : int
            Row index.
        tile : Tile
            New tile to place.
        """
        self._tiles[y][x] = tile
        self._transparency_cache = None

    def replace_tile(self, x: int, y: int, tile_name: str) -> None:
        """Swap the tile at (x, y) to a named type and mark it dirty.

        Parameters
        ----------
        x : int
            Column index.
        y : int
            Row index.
        tile_name : str
            Key in ``TILE_REGISTRY`` for the new tile type.
        """
        self.set_tile(x, y, TILE_REGISTRY[tile_name].make())
        self._dirty_tiles.add((x, y))
        self.tile_type_ids[(x, y)] = tile_name

    def apply_blood(
        self,
        x: int,
        y: int,
        blood_color: tuple[int, int, int],
        alpha: int,
    ) -> None:
        """Composite blood onto a tile's background colour and mark it dirty.

        The original background colour is saved on first contact so that
        accumulated alpha is always composited against the pristine tile,
        preventing progressive colour drift.

        Parameters
        ----------
        x, y : int
            Tile position.
        blood_color : tuple[int, int, int]
            RGB colour of the blood.
        alpha : int
            Accumulated alpha 0–255 from ``BloodMap``.
        """
        pos = (x, y)
        tile = self._tiles[y][x]
        if pos not in self._original_bg:
            self._original_bg[pos] = tile.bg_color
        orig = self._original_bg[pos]
        f = alpha / 255.0
        tile.bg_color = (
            int(orig[0] * (1.0 - f) + blood_color[0] * f),
            int(orig[1] * (1.0 - f) + blood_color[1] * f),
            int(orig[2] * (1.0 - f) + blood_color[2] * f),
        )
        self._dirty_tiles.add(pos)

    def drain_dirty_tiles(self) -> set[Pos]:
        """Return tiles modified since the last call and clear the dirty set."""
        dirty, self._dirty_tiles = self._dirty_tiles, set()
        return dirty

    def remove_entity(self, entity_id: int) -> None:
        """Remove an entity from position tracking.

        Parameters
        ----------
        entity_id : int
            Unique entity identifier.
        """
        pos = self._entity_positions.pop(entity_id)
        if pos not in self._entity_positions.values():
            self._occupied.discard(pos)


def chebyshev(ax: int, ay: int, bx: int, by: int) -> int:
    """Return Chebyshev (8-directional) distance between two points.

    Parameters
    ----------
    ax : int
        Column of point A.
    ay : int
        Row of point A.
    bx : int
        Column of point B.
    by : int
        Row of point B.

    Returns
    -------
    int
        Chebyshev distance.
    """
    return max(abs(ax - bx), abs(ay - by))


def is_adjacent(x1: int, y1: int, x2: int, y2: int) -> bool:
    """Return True if two positions are adjacent (including diagonals).

    Parameters
    ----------
    x1 : int
        Column of the first position.
    y1 : int
        Row of the first position.
    x2 : int
        Column of the second position.
    y2 : int
        Row of the second position.

    Returns
    -------
    bool
        True if positions differ by at most 1 in each axis and are not equal.
    """
    return abs(x1 - x2) <= 1 and abs(y1 - y2) <= 1 and (x1, y1) != (x2, y2)


def make_bordered_map(width: int, height: int) -> Map:
    """Build a map with wall borders and a walkable interior.

    Parameters
    ----------
    width : int
        Total number of columns including border.
    height : int
        Total number of rows including border.

    Returns
    -------
    Map
        A map where the outermost ring of tiles are walls.
    """

    def _is_border(x: int, y: int) -> bool:
        return x == 0 or x == width - 1 or y == 0 or y == height - 1

    tiles = [
        [wall_tile() if _is_border(x, y) else floor_tile() for x in range(width)]
        for y in range(height)
    ]
    return Map(width, height, tiles)


def make_blank_map(width: int, height: int) -> Map:
    """Return a map filled entirely with unknown (unexplored) placeholder tiles.

    Parameters
    ----------
    width : int
        Number of columns.
    height : int
        Number of rows.

    Returns
    -------
    Map
        A map where every tile is an impassable black placeholder.
        Revealed tiles are applied later via ``Map.set_tile``.
    """
    tiles = [[unknown_tile() for _ in range(width)] for _ in range(height)]
    return Map(width, height, tiles)
