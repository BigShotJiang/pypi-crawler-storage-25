"""NPC intent system — produces NPC commands from live game state each tick."""

from __future__ import annotations

from typing import TYPE_CHECKING

from faraway_realms.ai.behaviour import BehaviourContext
from faraway_realms.combat.stats import Pool
from faraway_realms.entities.components import BehaviourComponent
from faraway_realms.entities.entity import Entity, GameEntity
from faraway_realms.systems.base import System
from faraway_realms.world.commands import Command, CommandType
from faraway_realms.world.events import Event, EventType
from faraway_realms.world.factions import FactionRelations
from faraway_realms.world.map import Map

if TYPE_CHECKING:
    from faraway_realms.ai.behaviour import Behaviour
    from faraway_realms.systems.casting import CastingSystem
    from faraway_realms.world.event_bus import EventBus


def _get_behaviour(npc: Entity) -> Behaviour | None:
    """Return the behaviour strategy for *npc*, or ``None`` if player-controlled."""
    bc = npc.components.get("behaviour")
    if isinstance(bc, BehaviourComponent):
        return bc.behaviour
    return None


def _compute_hp_fraction(npc: Entity) -> float:
    """Return the NPC's health as a fraction of its maximum.

    Parameters
    ----------
    npc : Entity
        The NPC to inspect.

    Returns
    -------
    float
        Current HP / max HP, or ``1.0`` when health is undefined.
    """
    hp = npc.stats.get("health")
    if hp is None or not isinstance(hp, Pool) or hp.value == 0:
        return 1.0
    return hp.current / hp.value


class NpcIntentSystem(System):
    """Produces NPC commands from live game state each tick.

    Parameters
    ----------
    game_map : Map
        The active map.
    npcs : list[Entity]
        All registered NPCs (shared reference; mutations are visible).
    entities : dict[int, GameEntity]
        Shared entity registry.
    faction_relations : FactionRelations
        Used to compute hostile target sets.
    casting_system : CastingSystem | None
        When provided, ability cooldown data is passed to BehaviourContext.
    bus : EventBus | None
        When provided, NPC_STATE_CHANGED events are published on transitions.
    """

    def __init__(
        self,
        game_map: Map,
        npcs: list[Entity],
        entities: dict[int, GameEntity],
        faction_relations: FactionRelations,
        casting_system: CastingSystem | None = None,
        bus: EventBus | None = None,
    ) -> None:
        self._game_map = game_map
        self._npcs = npcs
        self._entities = entities
        self._faction_relations = faction_relations
        self._casting_system = casting_system
        self._bus = bus

    def gather(self, abs_tick: int) -> list[Command]:
        """Return all NPC commands for this tick.

        Parameters
        ----------
        abs_tick : int
            Current tick number, used for move-rate throttling.

        Returns
        -------
        list[Command]
            Commands to prepend to the command queue before draining.
        """
        all_positions = self._game_map.get_all_positions()
        occupied = frozenset(all_positions.values())
        commands: list[Command] = []
        for npc in self._npcs:
            commands.extend(self._gather_one(npc, all_positions, occupied, abs_tick))
        return commands

    def _gather_one(
        self,
        npc: Entity,
        all_positions: dict[int, tuple[int, int]],
        occupied: frozenset[tuple[int, int]],
        abs_tick: int,
    ) -> list[Command]:
        behaviour = _get_behaviour(npc)
        if behaviour is None:
            return []
        target_ids = self._hostile_targets_for(npc, all_positions)
        hp_fraction = _compute_hp_fraction(npc)
        ability_cds = (
            self._casting_system.cooldowns_for(npc.entity_id, abs_tick)
            if self._casting_system is not None
            else frozenset()
        )
        ctx = BehaviourContext(
            game_map=self._game_map,
            all_positions=all_positions,
            target_ids=target_ids,
            occupied=occupied,
            abs_tick=abs_tick,
            ability_cooldowns=ability_cds,
            hp_fraction=hp_fraction,
        )
        before = behaviour.current_state_name
        cmds = behaviour.act(npc.entity_id, ctx)
        after = behaviour.current_state_name
        self._maybe_publish_state_change(npc.entity_id, before, after, abs_tick)
        result: list[Command] = []
        for cmd in cmds:
            gated = self._gate_command(npc, cmd, abs_tick)
            if gated is not None:
                result.append(gated)
        return result

    def _maybe_publish_state_change(
        self, npc_id: int, before: str, after: str, abs_tick: int
    ) -> None:
        """Publish NPC_STATE_CHANGED when the behaviour state has transitioned."""
        if before == after or self._bus is None:
            return
        self._bus.publish(
            Event(
                event_type=EventType.NPC_STATE_CHANGED,
                source_id=npc_id,
                resolve_at_tick=abs_tick,
                payload={"from_state": before, "to_state": after},
            )
        )

    def _gate_command(
        self, npc: Entity, command: Command, abs_tick: int
    ) -> Command | None:
        if command.command_type != CommandType.MOVE:
            return command
        return command if self._move_allowed(npc, abs_tick) else None

    def _move_allowed(self, npc: Entity, abs_tick: int) -> bool:
        behaviour = _get_behaviour(npc)
        if behaviour is not None:
            effective = behaviour.current_move_every(npc.move_every)
        else:
            effective = npc.move_every
        return abs_tick % effective == 0

    def _hostile_targets_for(
        self,
        npc: Entity,
        all_positions: dict[int, tuple[int, int]],
    ) -> frozenset[int]:
        return frozenset(
            eid
            for eid, entity in self._entities.items()
            if self._is_hostile_target(npc, eid, entity, all_positions)
        )

    def _is_hostile_target(
        self,
        npc: Entity,
        eid: int,
        entity: GameEntity,
        all_positions: dict[int, tuple[int, int]],
    ) -> bool:
        return (
            self._faction_relations.are_hostile(npc.faction, entity.faction)
            and eid in all_positions
            and eid != npc.entity_id
        )
