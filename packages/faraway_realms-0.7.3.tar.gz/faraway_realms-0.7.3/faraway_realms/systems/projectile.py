"""Projectile system — tick-based homing projectile movement and detonation."""

from __future__ import annotations

from typing import TYPE_CHECKING

from faraway_realms.combat.damage_types import compute_ability_damage
from faraway_realms.combat.projectile import Projectile
from faraway_realms.combat.stats import Pool
from faraway_realms.entities.entity import get_combat_profile
from faraway_realms.systems.base import System
from faraway_realms.world.events import Event, EventType

if TYPE_CHECKING:
    from faraway_realms.combat.abilities import ProjectileEffect
    from faraway_realms.entities.entity import GameEntity
    from faraway_realms.systems.ability_effects import AbilityEffectsSystem
    from faraway_realms.world.event_bus import EventBus
    from faraway_realms.world.map import Map


class ProjectileSystem(System):
    """Manages in-flight projectiles: movement, wall collision, and detonation.

    Parameters
    ----------
    entities : dict[int, GameEntity]
        Shared entity registry.
    game_map : Map
        Shared map reference for walkability and position lookups.
    bus : EventBus
        Event bus; ENTITY_HIT and ENTITY_DYING events are published on detonation.
        PROJECTILE_SPAWN events are consumed to spawn new projectiles.
    ability_effects : AbilityEffectsSystem
        Used to apply on-hit status effects when a projectile detonates.
    """

    def __init__(
        self,
        entities: dict[int, GameEntity],
        game_map: Map,
        bus: EventBus,
        ability_effects: AbilityEffectsSystem,
    ) -> None:
        self._entities = entities
        self._game_map = game_map
        self._bus = bus
        self._ability_effects = ability_effects
        self._projectiles: list[Projectile] = []
        bus.subscribe(EventType.PROJECTILE_SPAWN, self._on_projectile_spawn, priority=0)
        bus.subscribe(EventType.TICK, self._on_tick, priority=40)

    @property
    def active_projectiles(self) -> list[Projectile]:
        """Return the list of currently in-flight projectiles (read-only view)."""
        return self._projectiles

    def tick(self, abs_tick: int) -> None:
        """Advance all projectiles one tick, publishing events for detonations.

        Parameters
        ----------
        abs_tick : int
            Current absolute tick, forwarded to detonation helpers.
        """
        self._projectiles[:] = [p for p in self._projectiles if self._step(p, abs_tick)]

    def spawn(
        self,
        caster_id: int,
        target_id: int,
        effect: ProjectileEffect,
    ) -> None:
        """Create a new in-flight projectile from a ProjectileEffect.

        Parameters
        ----------
        caster_id : int
            Entity ID of the caster.
        target_id : int
            Entity ID of the target (locked at cast time).
        effect : ProjectileEffect
            Ability effect describing the projectile's properties.
        """
        if not (
            self._game_map.has_entity(caster_id)
            and self._game_map.has_entity(target_id)
        ):
            return
        cx, cy = self._game_map.get_entity_position(caster_id)
        tx, ty = self._game_map.get_entity_position(target_id)
        from faraway_realms.entities.components import LightEmitter

        emitter = effect.components.get("light_emitter")
        light_source = emitter if isinstance(emitter, LightEmitter) else None
        self._projectiles.append(
            Projectile(
                source_id=caster_id,
                target_id=target_id,
                x=cx,
                y=cy,
                target_x=tx,
                target_y=ty,
                speed=effect.speed,
                base_damage=effect.base,
                damage_type=effect.damage_type,
                on_hit_statuses=effect.on_hit_statuses,
                color=effect.color,
                visual_type=effect.visual_type,
                trail_length=effect.trail_length,
                trail_char=effect.trail_char,
                light_source=light_source,
            )
        )

    def _on_tick(self, event: Event) -> None:
        """Advance all projectiles one tick."""
        self.tick(event.resolve_at_tick)

    def _on_projectile_spawn(self, event: Event) -> None:
        """Handle PROJECTILE_SPAWN: extract effect from payload and spawn."""
        if event.payload is None or event.target_id is None:
            return
        from faraway_realms.combat.abilities import (
            ProjectileEffect as _PE,  # noqa: PLC0415
        )

        effect = event.payload.get("effect")
        if not isinstance(effect, _PE):
            return
        self.spawn(event.source_id, event.target_id, effect)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _step(self, p: Projectile, abs_tick: int) -> bool:
        """Accumulate speed and advance N tiles; return ``False`` to despawn."""
        p.dist_accum += p.speed
        moves = int(p.dist_accum)
        p.dist_accum -= moves
        self._sync_target(p)
        for _ in range(moves):
            if not self._advance(p, abs_tick):
                return False
        return True

    def _sync_target(self, p: Projectile) -> None:
        """Follow a living target; stop homing when target leaves the map."""
        if not p.homing:
            return
        if self._game_map.has_entity(p.target_id):
            p.target_x, p.target_y = self._game_map.get_entity_position(p.target_id)
        else:
            p.homing = False

    def _advance(self, p: Projectile, abs_tick: int) -> bool:
        """Step one tile toward destination; return ``False`` on wall or impact."""
        dx = (p.target_x > p.x) - (p.target_x < p.x)
        dy = (p.target_y > p.y) - (p.target_y < p.y)
        nx, ny = p.x + dx, p.y + dy
        if not self._game_map.get_tile(nx, ny).walkable:
            return False
        p.trail.appendleft((p.x, p.y))
        p.x, p.y = nx, ny
        if p.x == p.target_x and p.y == p.target_y:
            self._detonate(p, abs_tick)
            return False
        return True

    def _detonate(self, p: Projectile, abs_tick: int) -> None:
        """Apply damage, publish ENTITY_HIT and DEATH, apply on-hit statuses."""
        target = self._entities.get(p.target_id)
        if target is None:
            return
        damage, died = self._deal_damage(p)
        self._bus.publish(
            Event(
                event_type=EventType.ENTITY_HIT,
                source_id=p.source_id,
                target_id=p.target_id,
                resolve_at_tick=abs_tick,
                payload={"damage": damage, "crit": False, "is_ability": True},
            )
        )
        if died:
            self._bus.publish(
                Event(
                    event_type=EventType.ENTITY_DYING,
                    source_id=p.target_id,
                    resolve_at_tick=abs_tick,
                )
            )
        self._ability_effects.apply_on_hit_statuses(
            p.source_id, p.target_id, p.on_hit_statuses, abs_tick
        )

    def _deal_damage(self, p: Projectile) -> tuple[int, bool]:
        """Apply impact damage; return ``(damage_dealt, target_died)``."""
        target = self._entities.get(p.target_id)
        if target is None:
            return 0, False
        tcp = get_combat_profile(target)
        pool = target.stats.get(tcp.death_stat)
        if not isinstance(pool, Pool):
            return 0, False
        armor = target.stats.get("armor")
        armor_val = armor.value if armor is not None else 0
        damage = compute_ability_damage(
            p.base_damage, p.damage_type, tcp.armor_type, armor_val
        )
        pool.modify(-damage)
        return damage, pool.is_empty
