"""SpawnSystem — GM creature spawning extracted from Game."""

from __future__ import annotations

import random
from collections.abc import Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING

import numpy as np

from faraway_realms.ai import fov as _fov
from faraway_realms.systems.base import System

if TYPE_CHECKING:
    from faraway_realms.entities.entity import Entity, GameEntity, Player
    from faraway_realms.world.map import Map


@dataclass
class SpawnResult:
    """Result of a successful GM spawn command.

    Parameters
    ----------
    entity : Entity
        The newly created NPC.
    x : int
        Map x position to place the entity on.
    y : int
        Map y position to place the entity on.
    message : str
        Chat message to log confirming the spawn.
    """

    entity: Entity
    x: int
    y: int
    message: str


class SpawnSystem(System):
    """Handles GM ``/spawn`` logic: validation, position resolution, entity creation.

    Parameters
    ----------
    entities : dict[int, GameEntity]
        Shared entity dict for FOV and occupancy checks.
    game_map : Map
        The active map.
    players : dict[str, Player]
        Shared player dict for GM privilege checks.
    creature_registry : dict[str, Callable[[int], Entity]]
        Creature factory registry populated by ``Game.register_creature``.
    allocate_id : Callable[[], int]
        Callback that allocates and returns the next free entity ID.
    """

    def __init__(
        self,
        entities: dict[int, GameEntity],
        game_map: Map,
        players: dict[str, Player],
        creature_registry: dict[str, Callable[[int], Entity]],
        allocate_id: Callable[[], int],
    ) -> None:
        self._entities = entities
        self._game_map = game_map
        self._players = players
        self._creature_registry = creature_registry
        self._allocate_id = allocate_id

    def handle(self, actor_id: int, args: tuple[str, ...]) -> SpawnResult | None:
        """Attempt to spawn a creature for *actor_id*.

        Parameters
        ----------
        actor_id : int
            Resolved entity ID of the commanding player.
        args : tuple[str, ...]
            Spawn arguments: ``(creature_type, position)``.

        Returns
        -------
        SpawnResult | None
            Spawn result on success; ``None`` on any validation failure.
        """
        if not self._is_game_master(actor_id):
            return None
        return self._do_spawn(actor_id, args)

    def _do_spawn(self, actor_id: int, args: tuple[str, ...]) -> SpawnResult | None:
        resolved = self._resolve_spawn_args(args, actor_id)
        if resolved is None:
            return None
        factory, (x, y) = resolved
        entity_id = self._allocate_id()
        npc = factory(entity_id)
        return SpawnResult(
            entity=npc,
            x=x,
            y=y,
            message=f"[GM] Spawned {npc.display_name} at ({x}, {y})",
        )

    def _is_game_master(self, entity_id: int) -> bool:
        return any(
            p.entity.entity_id == entity_id and p.is_game_master
            for p in self._players.values()
        )

    def _resolve_spawn_args(
        self,
        args: tuple[str, ...],
        actor_id: int,
    ) -> tuple[Callable[[int], Entity], tuple[int, int]] | None:
        if len(args) < 2:
            return None
        factory = self._creature_registry.get(args[0])
        if factory is None:
            return None
        pos = self._resolve_spawn_position(args[1], actor_id)
        if pos is None:
            return None
        return factory, pos

    def _resolve_spawn_position(
        self, pos_arg: str, actor_id: int
    ) -> tuple[int, int] | None:
        if pos_arg == "random":
            return self._random_visible_tile(actor_id)
        return self._parse_spawn_position(pos_arg)

    @staticmethod
    def _parse_spawn_position(pos_arg: str) -> tuple[int, int] | None:
        try:
            x_str, y_str = pos_arg.split(",")
            return int(x_str), int(y_str)
        except ValueError:
            return None

    def _visible_spawn_candidates(
        self,
        visible: np.ndarray,
        occupied: frozenset[tuple[int, int]],
    ) -> list[tuple[int, int]]:
        return [
            (x, y)
            for y in range(self._game_map.height)
            for x in range(self._game_map.width)
            if visible[y, x]
            and self._game_map.is_walkable(x, y)
            and (x, y) not in occupied
        ]

    def _random_visible_tile(self, actor_id: int) -> tuple[int, int] | None:
        if not self._game_map.has_entity(actor_id):
            return None
        ax, ay = self._game_map.get_entity_position(actor_id)
        entity = self._entities.get(actor_id)
        sight = (
            _fov.entity_sight(entity)
            if entity is not None
            else _fov.DEFAULT_SIGHT_RANGE
        )
        visible = _fov.compute_fov(self._game_map, ax, ay, sight)
        occupied = frozenset(self._game_map.get_all_positions().values())
        candidates = self._visible_spawn_candidates(visible, occupied)
        if not candidates:
            return None
        return random.choice(candidates)  # noqa: S311 — game logic, not crypto
