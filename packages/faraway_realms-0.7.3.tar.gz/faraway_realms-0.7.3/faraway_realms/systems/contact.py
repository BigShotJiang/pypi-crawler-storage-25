"""Contact resolution system — handles CONTACT events."""

from __future__ import annotations

from typing import TYPE_CHECKING

from faraway_realms.entities.entity import GameEntity
from faraway_realms.systems.base import System
from faraway_realms.world.commands import (
    Command,
    CommandType,
    make_attack_command,
    make_prime_cooldown_command,
)
from faraway_realms.world.events import Event, EventType

if TYPE_CHECKING:
    from faraway_realms.entities.entity import Player
    from faraway_realms.world.event_bus import EventBus


class ContactResolutionSystem(System):
    """Handles CONTACT events: auto-targets both parties and queues an attack.

    Parameters
    ----------
    entities : dict[int, GameEntity]
        Shared entity registry.
    command_queue : list[Command]
        Shared command queue; resolved commands are appended directly.
    players : dict[str, Player]
        Shared player registry; used to filter player-initiated attacks.
    bus : EventBus | None
        Event bus.  When provided, subscribes to CONTACT at priority 10.
    """

    def __init__(
        self,
        entities: dict[int, GameEntity],
        command_queue: list[Command] | None = None,
        players: dict[str, Player] | None = None,
        bus: EventBus | None = None,
    ) -> None:
        self._entities = entities
        self._command_queue = command_queue
        self._players = players if players is not None else {}
        if bus is not None and command_queue is not None:
            bus.subscribe(EventType.CONTACT, self._on_contact, priority=10)

    def _on_contact(self, event: Event) -> None:
        """Resolve a CONTACT event and enqueue resulting commands."""
        player_ids = {p.entity.entity_id for p in self._players.values()}
        for cmd in self._generate(event):
            if int(cmd.actor) not in player_ids or cmd.command_type in (
                CommandType.PRIME_COOLDOWN,
                CommandType.CLEAR_PRIME,
            ):
                self._command_queue.append(cmd)  # type: ignore[union-attr]

    def _generate(self, event: Event) -> list[Command]:
        """Resolve a CONTACT event and return resulting attack commands.

        Parameters
        ----------
        event : Event
            Must be ``EventType.CONTACT``.

        Returns
        -------
        list[Command]
            Zero or one ATTACK command to enqueue.
        """
        if event.target_id is None:
            return []
        if not self._both_alive(event.source_id, event.target_id):
            return []
        if event.payload and event.payload.get("opportunity"):
            return self._resolve_opportunity(event.source_id, event.target_id)
        return self._resolve_normal(event.source_id, event.target_id)

    def _resolve_opportunity(self, source_id: int, target_id: int) -> list[Command]:
        """Opportunity attack: source attacks, both sides auto-target."""
        cmds: list[Command] = []
        if self._set_target_if_unset(source_id, target_id):
            cmds.append(make_prime_cooldown_command(source_id))
        if self._set_target_if_unset(target_id, source_id):
            cmds.append(make_prime_cooldown_command(target_id))
        cmds.append(
            make_attack_command(source_id, target_id, CommandType.OPPORTUNITY_ATTACK)
        )
        return cmds

    def _resolve_normal(self, source_id: int, target_id: int) -> list[Command]:
        """Mover attacks; both sides auto-target if not already targeting anyone.

        Attack timing is governed by the cooldown system — the mover's attack
        command is gated by ``CombatSystem`` on the next tick if their cooldown
        is not yet ready.  Initiative is therefore determined by *when* the NPC
        started its chase (PRIME_COOLDOWN) rather than by target bookkeeping here.
        """
        cmds: list[Command] = []
        if self._set_target_if_unset(source_id, target_id):
            cmds.append(make_prime_cooldown_command(source_id))
        if self._set_target_if_unset(target_id, source_id):
            cmds.append(make_prime_cooldown_command(target_id))
        cmds.append(make_attack_command(source_id, target_id))
        return cmds

    def _both_alive(self, a: int, b: int) -> bool:
        return a in self._entities and b in self._entities

    def _set_target_if_unset(self, entity_id: int, new_target_id: int) -> bool:
        """Set target if unset; return True when a new target was assigned."""
        entity = self._entities.get(entity_id)
        if entity is None or entity.target_id is not None:
            return False
        entity.target_id = new_target_id
        return True
