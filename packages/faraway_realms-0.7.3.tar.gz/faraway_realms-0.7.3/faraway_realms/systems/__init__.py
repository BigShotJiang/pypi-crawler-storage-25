"""Game systems — each system handles one slice of game logic."""

from faraway_realms.systems.ability_effects import AbilityEffectsSystem
from faraway_realms.systems.base import System
from faraway_realms.systems.blood import BloodSystem
from faraway_realms.systems.casting import CastingSystem
from faraway_realms.systems.combat import CombatSystem
from faraway_realms.systems.combat_log import CombatLog
from faraway_realms.systems.contact import ContactResolutionSystem
from faraway_realms.systems.death import DeathSystem
from faraway_realms.systems.movement import MovementSystem
from faraway_realms.systems.npc_intent import NpcIntentSystem
from faraway_realms.systems.projectile import ProjectileSystem
from faraway_realms.systems.spawn import SpawnResult, SpawnSystem
from faraway_realms.systems.status import StatusEffectSystem
from faraway_realms.systems.targeting import TargetingSystem

__all__ = [
    "AbilityEffectsSystem",
    "BloodSystem",
    "CastingSystem",
    "CombatLog",
    "CombatSystem",
    "ContactResolutionSystem",
    "DeathSystem",
    "MovementSystem",
    "NpcIntentSystem",
    "ProjectileSystem",
    "SpawnResult",
    "SpawnSystem",
    "StatusEffectSystem",
    "System",
    "TargetingSystem",
]
