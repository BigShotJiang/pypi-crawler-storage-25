"""Blood system — records hit animations and composites blood stains into the map."""

from __future__ import annotations

from typing import TYPE_CHECKING

from faraway_realms.effects.blood import BloodMap
from faraway_realms.entities.entity import get_combat_profile
from faraway_realms.systems.base import System
from faraway_realms.world.events import Event, EventType

if TYPE_CHECKING:
    from faraway_realms.entities.entity import GameEntity
    from faraway_realms.world.event_bus import EventBus
    from faraway_realms.world.map import Map


class BloodSystem(System):
    """Owns blood stain state and records melee hit metadata on entities.

    Subscribes to ENTITY_HIT at priority 10; on each hit it:
    - increments the target's hit sequence counter
    - composites blood stains directly into :class:`~faraway_realms.world.map.Map`
      tile background colours via :meth:`Map.apply_blood`
    - records ``last_hit_tick`` / ``last_hit_by`` on the target entity so the
      client can reconstruct attack-flash animations from state alone

    Parameters
    ----------
    entities : dict[int, GameEntity]
        Shared entity registry.
    game_map : Map
        The active map; blood stains are composited into its tile colours.
    bus : EventBus
        Event bus; subscribes to ENTITY_HIT.
    """

    def __init__(
        self,
        entities: dict[int, GameEntity],
        game_map: Map,
        bus: EventBus,
        melee_anims: list,
    ) -> None:
        self._entities = entities
        self._game_map = game_map
        self._blood_map = BloodMap(game_map.width, game_map.height)
        self._hit_seqs: dict[int, int] = {}
        self._crit_dealt_seq: dict[int, int] = {}
        self._melee_anims = melee_anims
        bus.subscribe(EventType.ENTITY_HIT, self._on_entity_hit, priority=10)

    # ------------------------------------------------------------------
    # Public accessors
    # ------------------------------------------------------------------

    def get_hit_seq(self, entity_id: int) -> int:
        """Return how many times *entity_id* has been hit."""
        return self._hit_seqs.get(entity_id, 0)

    def get_crit_dealt_seq(self, entity_id: int) -> int:
        """Return how many crits *entity_id* has landed."""
        return self._crit_dealt_seq.get(entity_id, 0)

    # ------------------------------------------------------------------
    # Event handler
    # ------------------------------------------------------------------

    def _on_entity_hit(self, event: Event) -> None:
        if event.payload is None or event.target_id is None:
            return
        damage = int(event.payload["damage"])  # type: ignore[call-overload]
        if damage <= 0:
            return
        attacker_id, target_id = event.source_id, event.target_id
        self._hit_seqs[target_id] = self._hit_seqs.get(target_id, 0) + 1
        if not event.payload.get("is_ability"):
            self._on_melee_hit(
                attacker_id,
                target_id,
                bool(event.payload.get("crit")),
                event.resolve_at_tick,
            )
        self._record_blood_splat(attacker_id, target_id)

    def _on_melee_hit(
        self, attacker_id: int, target_id: int, crit: bool, abs_tick: int
    ) -> None:
        if crit:
            self._crit_dealt_seq[attacker_id] = (
                self._crit_dealt_seq.get(attacker_id, 0) + 1
            )
        target = self._entities.get(target_id)
        if target is not None:
            target.last_hit_tick = abs_tick
            target.last_hit_by = attacker_id
        self._capture_anim(attacker_id, target_id, target)

    def _capture_anim(
        self, attacker_id: int, target_id: int, target: GameEntity | None
    ) -> None:
        """Capture animation data into the shared list while entities are alive."""
        if not (
            self._game_map.has_entity(attacker_id)
            and self._game_map.has_entity(target_id)
        ):
            return
        ax, ay = self._game_map.get_entity_position(attacker_id)
        tx, ty = self._game_map.get_entity_position(target_id)
        attacker = self._entities.get(attacker_id)
        acolor = attacker.fg_color if attacker else (255, 255, 255)
        blood_color = get_combat_profile(target).blood_color if target else None
        self._melee_anims.append(((ax, ay), (tx, ty), acolor, blood_color))

    def _record_blood_splat(self, attacker_id: int, target_id: int) -> None:
        target = self._entities.get(target_id)
        if target is None:
            return
        blood_color = get_combat_profile(target).blood_color
        if blood_color is None:
            return
        if not (
            self._game_map.has_entity(attacker_id)
            and self._game_map.has_entity(target_id)
        ):
            return
        self._splat_blood(attacker_id, target_id, blood_color)

    def _splat_blood(
        self,
        attacker_id: int,
        target_id: int,
        blood_color: tuple[int, int, int],
    ) -> None:
        ax, ay = self._game_map.get_entity_position(attacker_id)
        tx, ty = self._game_map.get_entity_position(target_id)
        self._blood_map.splat(tx, ty, ax, ay, blood_color)
        for (x, y), blood_tile in self._blood_map.drain_dirty().items():
            self._game_map.apply_blood(x, y, blood_tile.color, blood_tile.alpha)
