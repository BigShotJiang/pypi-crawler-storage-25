"""CombatLog — chat history ownership and combat message formatting."""

from __future__ import annotations

from typing import TYPE_CHECKING

from faraway_realms.chat import (
    DEFAULT_COLOR,
    NPC_HIT_COLOR,
    OPP_ATTACK_COLOR,
    PLAYER_HIT_COLOR,
    ChatMessage,
)
from faraway_realms.combat.abilities import ABILITY_REGISTRY
from faraway_realms.systems.base import System
from faraway_realms.types import Color
from faraway_realms.world.events import Event, EventType

if TYPE_CHECKING:
    from faraway_realms.combat.abilities import Ability
    from faraway_realms.entities.entity import GameEntity, Player
    from faraway_realms.world.event_bus import EventBus

_CAST_COLOR: Color = (100, 180, 255)
_STATUS_COLOR: Color = (200, 100, 220)


class CombatLog(System):
    """Owns the chat/combat log history and formats combat messages.

    Parameters
    ----------
    entities : dict[int, GameEntity]
        Shared entity dict; used for display names.
    players : dict[str, Player]
        Shared player dict; used to determine player entity IDs for colour
        selection.
    """

    def __init__(
        self,
        entities: dict[int, GameEntity],
        players: dict[str, Player],
        bus: EventBus | None = None,
    ) -> None:
        self._entities = entities
        self._players = players
        self._history: list[ChatMessage] = []
        if bus is not None:
            bus.subscribe(EventType.ENTITY_HIT, self._on_entity_hit, priority=5)
            bus.subscribe(EventType.CAST_STARTED, self._on_cast_started, priority=5)
            bus.subscribe(EventType.CAST_COMPLETE, self._on_cast_complete, priority=5)
            bus.subscribe(EventType.CHANNEL_TICK, self._on_cast_complete, priority=5)
            bus.subscribe(EventType.CAST_CANCELLED, self._on_cast_cancelled, priority=5)
            bus.subscribe(EventType.STATUS_APPLIED, self._on_status_applied, priority=5)
            bus.subscribe(EventType.CONTACT, self._on_contact, priority=5)
            bus.subscribe(
                EventType.TILE_INTERACTED, self._on_tile_interacted, priority=5
            )

    # ------------------------------------------------------------------
    # History API (mirrors the GameProtocol surface on Game)
    # ------------------------------------------------------------------

    def add_message(
        self,
        text: str,
        color: Color = DEFAULT_COLOR,
    ) -> None:
        """Append a message to the log."""
        self._history.append(ChatMessage(text=text, color=color))

    def get_since(self, offset: int) -> list[ChatMessage]:
        """Return messages added since *offset*."""
        return self._history[offset:]

    def get_history(self, last_n: int = 20) -> list[ChatMessage]:
        """Return the most recent *last_n* messages."""
        return self._history[-last_n:]

    @property
    def count(self) -> int:
        """Total messages ever added (monotonically increasing)."""
        return len(self._history)

    # ------------------------------------------------------------------
    # Bus subscription handlers
    # ------------------------------------------------------------------

    def _on_entity_hit(self, event: Event) -> None:
        if event.payload is None or event.target_id is None:
            return
        damage = int(event.payload["damage"])  # type: ignore[call-overload]
        if damage <= 0:
            return
        if event.payload.get("is_ability"):
            self.log_ability_hit(event.source_id, event.target_id, damage)
        else:
            self.log_hit(
                event.source_id,
                event.target_id,
                damage,
                bool(event.payload.get("crit")),
            )

    def _on_cast_started(self, event: Event) -> None:
        if event.payload is None:
            return
        ability = ABILITY_REGISTRY.get(str(event.payload.get("ability_name", "")))
        if ability is None:
            return
        self.log_cast_start(event.source_id, ability)

    def _on_cast_complete(self, event: Event) -> None:
        if event.payload is None or event.target_id is None:
            return
        ability = ABILITY_REGISTRY.get(str(event.payload.get("ability", "")))
        if ability is None:
            return
        self.log_cast_complete(event.source_id, event.target_id, ability)

    def _on_cast_cancelled(self, event: Event) -> None:
        if event.payload is None:
            return
        self.log_cast_cancelled(
            event.source_id, str(event.payload.get("ability_name", ""))
        )

    def _on_status_applied(self, event: Event) -> None:
        if event.payload is None or event.target_id is None:
            return
        if not event.payload.get("show_message"):
            return
        self.log_status_applied(
            event.source_id,
            event.target_id,
            str(event.payload.get("status_name", "")),
        )

    def _on_contact(self, event: Event) -> None:
        if event.payload and event.payload.get("opportunity"):
            self.log_opportunity_attack(event.source_id, event.target_id)

    def _on_tile_interacted(self, event: Event) -> None:
        if not event.payload:
            return
        actor_id = event.source_id
        is_player = any(p.entity.entity_id == actor_id for p in self._players.values())
        if not is_player:
            return
        action = str(event.payload.get("action", ""))
        self.add_message(f"You {action} the door.")

    # ------------------------------------------------------------------
    # Formatting helpers
    # ------------------------------------------------------------------

    def _player_ids(self) -> frozenset[int]:
        return frozenset(p.entity.entity_id for p in self._players.values())

    def _cast_complete_text(
        self,
        caster: GameEntity,
        target: GameEntity,
        ability: Ability,
    ) -> str:
        if ability.name == "bite":
            return f"{caster.display_name} sinks its teeth into {target.display_name}!"
        return f"{caster.display_name} uses {ability.name} on {target.display_name}!"

    # ------------------------------------------------------------------
    # Combat log entries
    # ------------------------------------------------------------------

    def log_hit(
        self,
        attacker_id: int,
        target_id: int,
        damage: int,
        crit: bool = False,
    ) -> None:
        """Log a melee hit."""
        attacker = self._entities.get(attacker_id)
        target = self._entities.get(target_id)
        if attacker is None or target is None:
            return
        color = PLAYER_HIT_COLOR if attacker_id in self._player_ids() else NPC_HIT_COLOR
        prefix = "Critical! " if crit else ""
        text = (
            f"{prefix}{attacker.display_name} hits {target.display_name} for {damage}"
        )
        self.add_message(text, color)

    def log_ability_hit(self, caster_id: int, target_id: int, damage: int) -> None:
        """Log ability damage dealt."""
        color = PLAYER_HIT_COLOR if target_id in self._player_ids() else NPC_HIT_COLOR
        self.add_message(f"  ({damage} damage)", color)

    def log_cast_start(self, caster_id: int, ability: Ability) -> None:
        """Log that a cast has begun."""
        caster = self._entities.get(caster_id)
        if caster is None:
            return
        self.add_message(
            f"{caster.display_name} begins casting {ability.name}...",
            _CAST_COLOR,
        )

    def log_cast_complete(
        self, caster_id: int, target_id: int, ability: Ability
    ) -> None:
        """Log a completed cast."""
        caster = self._entities.get(caster_id)
        target = self._entities.get(target_id)
        if caster is None or target is None:
            return
        text = self._cast_complete_text(caster, target, ability)
        color = PLAYER_HIT_COLOR if target_id in self._player_ids() else NPC_HIT_COLOR
        self.add_message(text, color)

    def log_cast_cancelled(self, caster_id: int, ability_name: str) -> None:
        """Log a cancelled or interrupted cast."""
        caster = self._entities.get(caster_id)
        if caster is None:
            return
        self.add_message(
            f"{caster.display_name}'s {ability_name} was interrupted!",
            _CAST_COLOR,
        )

    def log_status_applied(
        self, caster_id: int, target_id: int, status_name: str
    ) -> None:
        """Log a status effect application."""
        caster = self._entities.get(caster_id)
        target = self._entities.get(target_id)
        if caster is None or target is None:
            return
        self.add_message(
            f"{caster.display_name} afflicts {target.display_name} with {status_name}.",
            _STATUS_COLOR,
        )

    def log_opportunity_attack(self, attacker_id: int, target_id: int | None) -> None:
        """Log an opportunity attack message."""
        attacker = self._entities.get(attacker_id)
        target = self._entities.get(target_id) if target_id is not None else None
        if attacker is None or target is None:
            return
        self.add_message(
            f"{attacker.display_name} strikes {target.display_name} as they flee!",
            OPP_ATTACK_COLOR,
        )
