"""Death system — handles ENTITY_DYING events, entity removal, and target cleanup."""

from __future__ import annotations

from typing import TYPE_CHECKING

from faraway_realms.entities.entity import Entity, GameEntity
from faraway_realms.systems.base import System
from faraway_realms.world.events import Event, EventType
from faraway_realms.world.map import Map

if TYPE_CHECKING:
    from faraway_realms.world.event_bus import EventBus


class DeathSystem(System):
    """Handles ENTITY_DYING events: removes the entity and publishes ENTITY_DIED.

    Subscribes to ENTITY_DYING at priority 50, so all read-only observers
    (observability, XP, loot attribution) at lower priorities fire first while
    the entity is still present in ``_entities`` and on the map.

    After cleanup, publishes ENTITY_DIED so downstream systems (combat cooldown
    forget, targeting auto-acquire) can react knowing the entity is gone.

    Parameters
    ----------
    game_map : Map
        The active map.
    entities : dict[int, GameEntity]
        Shared entity registry; the entry is popped on death.
    npcs : list[Entity]
        NPC registry; mutated in place via slice assignment on death.
    bus : EventBus | None
        Event bus.  When provided, subscribes to ENTITY_DYING at priority 50.
    """

    def __init__(
        self,
        game_map: Map,
        entities: dict[int, GameEntity],
        npcs: list[Entity],
        bus: EventBus | None = None,
    ) -> None:
        self._game_map = game_map
        self._entities = entities
        self._npcs = npcs
        self._bus = bus
        if bus is not None:
            bus.subscribe(EventType.ENTITY_DYING, self.handle, priority=50)

    def handle(self, event: Event) -> None:
        """Remove the dying entity, clear targeting references, publish ENTITY_DIED.

        Parameters
        ----------
        event : Event
            Must be ``EventType.ENTITY_DYING``.
        """
        entity_id = event.source_id
        if self._game_map.has_entity(entity_id):
            self._game_map.remove_entity(entity_id)
        self._entities.pop(entity_id, None)
        self._npcs[:] = [n for n in self._npcs if n.entity_id != entity_id]
        self._clear_targets_to(entity_id)
        if self._bus is not None:
            self._bus.publish(
                Event(
                    event_type=EventType.ENTITY_DIED,
                    source_id=entity_id,
                    resolve_at_tick=event.resolve_at_tick,
                )
            )

    def _clear_targets_to(self, dead_id: int) -> None:
        for entity in self._entities.values():
            if entity.target_id == dead_id:
                entity.target_id = None
