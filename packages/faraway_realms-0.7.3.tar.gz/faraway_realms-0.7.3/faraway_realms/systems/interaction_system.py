"""Interaction system — handles INTERACT commands (open/close doors, etc.)."""

from __future__ import annotations

from typing import TYPE_CHECKING

from faraway_realms.entities.components import OpenableComponent
from faraway_realms.systems.base import System
from faraway_realms.world.events import Event, EventType

if TYPE_CHECKING:
    from faraway_realms.world.event_bus import EventBus
    from faraway_realms.world.map import Map

_DIRECTION_DELTAS: dict[str, tuple[int, int]] = {
    "left": (-1, 0),
    "right": (1, 0),
    "up": (0, -1),
    "down": (0, 1),
}


class InteractionSystem(System):
    """Handles INTERACT commands: resolves direction, toggles openable tiles.

    Parameters
    ----------
    game_map : Map
        Shared game map; used to read tiles and call ``replace_tile``.
    bus : EventBus
        Event bus; used to publish ``TILE_INTERACTED``.
    """

    def __init__(self, game_map: Map, bus: EventBus) -> None:
        self._game_map = game_map
        self._bus = bus

    def handle(self, actor_id: int, direction: str) -> None:
        """Open or close the tile adjacent to *actor_id* in *direction*.

        Parameters
        ----------
        actor_id : int
            Entity performing the interaction.
        direction : str
            One of ``"left"``, ``"right"``, ``"up"``, ``"down"``.
        """
        delta = _DIRECTION_DELTAS.get(direction)
        if delta is None:
            return
        dx, dy = delta
        ax, ay = self._game_map.get_entity_position(actor_id)
        tx, ty = ax + dx, ay + dy
        tile = self._game_map.get_tile(tx, ty)
        openable = tile.components.get("openable")
        if not isinstance(openable, OpenableComponent):
            return
        if tile.walkable:
            new_name = openable.closed_tile
            action = "closed"
        else:
            new_name = openable.open_tile
            action = "opened"
        self._game_map.replace_tile(tx, ty, new_name)
        self._bus.publish(
            Event(
                event_type=EventType.TILE_INTERACTED,
                source_id=actor_id,
                payload={"x": tx, "y": ty, "tile_name": new_name, "action": action},
            )
        )
