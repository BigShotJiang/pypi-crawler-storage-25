"""Casting system — ability cooldowns, cast time, GCD, channeling, and interrupts."""

from __future__ import annotations

from typing import TYPE_CHECKING

from faraway_realms.combat.abilities import ABILITY_REGISTRY
from faraway_realms.combat.stats import Pool
from faraway_realms.systems.base import System
from faraway_realms.world.events import Event, EventType
from faraway_realms.world.map import chebyshev as _chebyshev

if TYPE_CHECKING:
    from faraway_realms.combat.abilities import Ability, AbilityEffect
    from faraway_realms.entities.entity import GameEntity
    from faraway_realms.world.event_bus import EventBus
    from faraway_realms.world.map import Map

_GCD_TICKS: int = 10  # 1 s global cooldown at 10 Hz
_CAST_PURGE_TYPES = (EventType.CAST_COMPLETE, EventType.CHANNEL_TICK)


class CastingSystem(System):
    """Handles ability cooldowns, cast time, GCD, channeling, and interrupts.

    Parameters
    ----------
    entities : dict[int, GameEntity]
        Shared entity registry.
    game_map : Map
        The active map; used to look up entity positions.
    bus : EventBus
        Event bus; CAST_STARTED, CAST_CANCELLED, CAST_COMPLETE, CHANNEL_TICK
        events are published directly.  Subscribes to STUN_APPLIED.
    """

    def __init__(
        self,
        entities: dict[int, GameEntity],
        game_map: Map,
        bus: EventBus | None = None,
    ) -> None:
        self._entities = entities
        self._game_map = game_map
        self._bus = bus
        # (entity_id, ability_name) → tick when ability becomes available again
        self._cooldowns: dict[tuple[int, str], int] = {}
        # entity_id → tick when GCD expires
        self._gcd: dict[int, int] = {}
        # entity_id → (ability_name, target_id, start_tick, cast_time)
        self._casting: dict[int, tuple[str, int, int, int]] = {}
        if bus is not None:
            bus.subscribe(EventType.STUN_APPLIED, self._on_stun, priority=0)
            bus.subscribe(EventType.CAST_COMPLETE, self._on_cast_complete, priority=0)
            bus.subscribe(EventType.ENTITY_DYING, self._on_death, priority=0)
            bus.subscribe(EventType.TICK, self._on_tick, priority=10)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def begin_cast(
        self,
        entity_id: int,
        ability: "Ability",
        target_id: int,
        abs_tick: int,
    ) -> bool:
        """Attempt to begin casting an ability, publishing scheduled events.

        Parameters
        ----------
        entity_id : int
            Entity ID of the caster.
        ability : Ability
            The ability to cast.
        target_id : int
            Entity ID of the target.
        abs_tick : int
            Current absolute tick.

        Returns
        -------
        bool
            ``True`` when the cast was accepted and events were published.
        """
        if not self._validate_cast(entity_id, ability, target_id, abs_tick):
            return False
        self._enqueue_cast(entity_id, ability, target_id, abs_tick)
        return True

    def interrupt(self, entity_id: int) -> None:
        """Remove any in-progress cast for this entity.

        Parameters
        ----------
        entity_id : int
            Entity whose cast should be cancelled.
        """
        self._casting.pop(entity_id, None)

    def cancel(self, entity_id: int, ability_name: str, abs_tick: int = 0) -> None:
        """Interrupt a cast and refund its ability cooldown.

        Use this for external interruptions (e.g. target moved out of range)
        where the caster should be able to retry immediately.  For stun-based
        interruptions use :meth:`interrupt` instead so the cooldown is kept.

        Parameters
        ----------
        entity_id : int
            Entity whose cast should be cancelled.
        ability_name : str
            Ability whose cooldown should be refunded.
        abs_tick : int
            Current tick; used for the CAST_CANCELLED event timestamp.
        """
        self._casting.pop(entity_id, None)
        self._cooldowns.pop((entity_id, ability_name), None)
        if self._bus is not None:
            self._bus.publish(
                Event(
                    event_type=EventType.CAST_CANCELLED,
                    source_id=entity_id,
                    resolve_at_tick=abs_tick,
                    payload={"ability_name": ability_name},
                )
            )

    def tick(self, abs_tick: int) -> None:
        """Cancel casts whose target has moved out of range this tick.

        Parameters
        ----------
        abs_tick : int
            Current absolute tick.
        """
        for entity_id in list(self._entities):
            self._check_cast_range(entity_id, abs_tick)

    def _check_cast_range(self, entity_id: int, abs_tick: int) -> None:
        cast_info = self.active_cast(entity_id)
        if cast_info is None:
            return
        ability_name, target_id = cast_info
        ability = ABILITY_REGISTRY.get(ability_name)
        if ability is not None and not self._in_range(
            entity_id, target_id, ability.range_tiles
        ):
            self.cancel(entity_id, ability_name, abs_tick)
            self._purge_cast_events(entity_id)

    def _purge_cast_events(self, entity_id: int) -> None:
        if self._bus is not None:
            self._bus.purge(
                lambda e: e.source_id == entity_id and e.event_type in _CAST_PURGE_TYPES
            )

    def _on_stun(self, event: Event) -> None:
        """Interrupt the cast of a stunned entity; purge its pending cast events."""
        eid = event.target_id or event.source_id
        entry = self._casting.get(eid)
        self.interrupt(eid)
        self._purge_cast_events(eid)
        if entry is not None:
            self._publish_stun_cancelled(eid, entry[0], event.resolve_at_tick)

    def _publish_stun_cancelled(
        self, eid: int, ability_name: str, abs_tick: int
    ) -> None:
        """Publish CAST_CANCELLED for a stun-interrupted cast."""
        if self._bus is not None:
            self._bus.publish(
                Event(
                    event_type=EventType.CAST_CANCELLED,
                    source_id=eid,
                    resolve_at_tick=abs_tick,
                    payload={"ability_name": ability_name},
                )
            )

    def _on_cast_complete(self, event: Event) -> None:
        """Remove the completed cast from active tracking."""
        self.interrupt(event.source_id)

    def _on_death(self, event: Event) -> None:
        """Interrupt and purge cast events for a dying entity."""
        entity_id = event.source_id
        self.interrupt(entity_id)
        self._purge_cast_events(entity_id)

    def _on_tick(self, event: Event) -> None:
        """Cancel casts whose target moved out of range this tick."""
        self.tick(event.resolve_at_tick)

    def active_cast(self, entity_id: int) -> tuple[str, int] | None:
        """Return ``(ability_name, target_id)`` if casting, else ``None``.

        Parameters
        ----------
        entity_id : int
            Entity to query.

        Returns
        -------
        tuple[str, int] | None
            The ability name and target entity ID, or ``None`` when not casting.
        """
        entry = self._casting.get(entity_id)
        if entry is None:
            return None
        return entry[0], entry[1]

    def is_casting(self, entity_id: int) -> bool:
        """Return ``True`` when this entity has a cast actively in progress.

        Parameters
        ----------
        entity_id : int
            Entity to query.

        Returns
        -------
        bool
            ``True`` when a timed cast is underway (cast_time > 0).
        """
        return entity_id in self._casting

    def cast_fraction(self, entity_id: int, abs_tick: int) -> float | None:
        """Return cast progress 0.0–1.0 if actively casting, else ``None``.

        Parameters
        ----------
        entity_id : int
            Entity to query.
        abs_tick : int
            Current absolute tick.

        Returns
        -------
        float | None
            Fraction through the cast time, or ``None`` when not casting.
        """
        entry = self._casting.get(entity_id)
        if entry is None:
            return None
        _, _, start_tick, cast_time = entry
        return min(1.0, (abs_tick - start_tick) / cast_time)

    def gcd_fraction(self, entity_id: int, abs_tick: int) -> float | None:
        """Return GCD progress 0.0–1.0 while the GCD is active, else ``None``.

        Parameters
        ----------
        entity_id : int
            Entity to query.
        abs_tick : int
            Current absolute tick.

        Returns
        -------
        float | None
            Fraction through the GCD window, or ``None`` when the GCD has
            expired or was never triggered.
        """
        gcd_end = self._gcd.get(entity_id)
        if gcd_end is None or abs_tick >= gcd_end:
            return None
        return min(1.0, 1.0 - (gcd_end - abs_tick) / _GCD_TICKS)

    def is_on_cooldown(self, entity_id: int, ability_name: str, abs_tick: int) -> bool:
        """Return whether the ability is currently on cooldown.

        Parameters
        ----------
        entity_id : int
            Entity to query.
        ability_name : str
            Ability name.
        abs_tick : int
            Current absolute tick.

        Returns
        -------
        bool
            True when the ability cannot yet be used.
        """
        return abs_tick < self._cooldowns.get((entity_id, ability_name), 0)

    def ability_cooldown_fraction(
        self, entity_id: int, ability_name: str, cooldown: int, abs_tick: int
    ) -> float:
        """Return remaining cooldown fraction (1.0 = just used, 0.0 = ready).

        Parameters
        ----------
        entity_id : int
            Entity to query.
        ability_name : str
            Ability name.
        cooldown : int
            Total cooldown window in ticks (from ``Ability.cooldown``).
        abs_tick : int
            Current absolute tick.

        Returns
        -------
        float
            0.0 when ready or ``cooldown`` is 0; otherwise fraction remaining.
        """
        if cooldown == 0:
            return 0.0
        avail_at = self._cooldowns.get((entity_id, ability_name), 0)
        if abs_tick >= avail_at:
            return 0.0
        return min(1.0, (avail_at - abs_tick) / cooldown)

    def cooldowns_for(self, entity_id: int, abs_tick: int) -> frozenset[str]:
        """Return ability names currently on cooldown for this entity.

        Parameters
        ----------
        entity_id : int
            Entity to query.
        abs_tick : int
            Current absolute tick.

        Returns
        -------
        frozenset[str]
            Names of abilities that cannot yet be used.
        """
        return frozenset(
            name
            for (eid, name), avail_at in self._cooldowns.items()
            if eid == entity_id and abs_tick < avail_at
        )

    def get_effects(
        self, event: Event, ability_registry: dict[str, "Ability"]
    ) -> list["AbilityEffect"]:
        """Return effects for the ability named in a CAST_COMPLETE/CHANNEL_TICK event.

        Parameters
        ----------
        event : Event
            The resolved casting event.
        ability_registry : dict[str, Ability]
            Registry mapping ability names to Ability objects.

        Returns
        -------
        list[AbilityEffect]
            Effects to apply, or empty list if unresolvable.
        """
        if event.payload is None:
            return []
        name = event.payload.get("ability", "")
        ability = ability_registry.get(str(name))
        if ability is None:
            return []
        return list(ability.effects)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _validate_cast(
        self,
        entity_id: int,
        ability: "Ability",
        target_id: int,
        abs_tick: int,
    ) -> bool:
        """Return True when the cast passes all validation checks."""
        if not self._entities_present(entity_id, target_id):
            return False
        if not self._has_resource(entity_id, ability.resource_cost):
            return False
        return self._timing_ok(entity_id, ability, target_id, abs_tick)

    def _has_resource(self, entity_id: int, cost: "tuple[str, int] | None") -> bool:
        """Return True when the entity can afford the resource cost."""
        if cost is None:
            return True
        pool_name, amount = cost
        entity = self._entities.get(entity_id)
        if entity is None:
            return False
        pool = entity.stats.get(pool_name)
        return isinstance(pool, Pool) and pool.current >= amount

    def _entities_present(self, entity_id: int, target_id: int) -> bool:
        """Return True when both entities are on the map."""
        return self._game_map.has_entity(entity_id) and self._game_map.has_entity(
            target_id
        )

    def _timing_ok(
        self,
        entity_id: int,
        ability: "Ability",
        target_id: int,
        abs_tick: int,
    ) -> bool:
        """Return True when range, cooldown, and GCD checks all pass."""
        if not self._in_range(entity_id, target_id, ability.range_tiles):
            return False
        if self.is_on_cooldown(entity_id, ability.name, abs_tick):
            return False
        if ability.gcd and abs_tick < self._gcd.get(entity_id, 0):
            return False
        return True

    def _in_range(self, entity_id: int, target_id: int, range_tiles: int) -> bool:
        """Return True when Chebyshev distance is within range_tiles."""
        ex, ey = self._game_map.get_entity_position(entity_id)
        tx, ty = self._game_map.get_entity_position(target_id)
        return _chebyshev(ex, ey, tx, ty) <= range_tiles

    def _enqueue_cast(
        self,
        entity_id: int,
        ability: "Ability",
        target_id: int,
        abs_tick: int,
    ) -> None:
        """Record cooldowns, deduct resource cost, publish scheduled cast events."""
        avail_at = abs_tick + ability.cast_time + ability.cooldown
        self._cooldowns[(entity_id, ability.name)] = avail_at
        if ability.gcd:
            self._gcd[entity_id] = abs_tick + _GCD_TICKS
        self._deduct_resource(entity_id, ability.resource_cost)
        self._schedule_events(entity_id, ability, target_id, abs_tick)

    def _deduct_resource(self, entity_id: int, cost: "tuple[str, int] | None") -> None:
        """Subtract the resource cost from the appropriate pool."""
        if cost is None:
            return
        pool_name, amount = cost
        entity = self._entities.get(entity_id)
        if entity is None:
            return
        pool = entity.stats.get(pool_name)
        if isinstance(pool, Pool):
            pool.modify(-amount)
            self._publish(
                Event(
                    event_type=EventType.RESOURCE_CHANGED,
                    source_id=entity_id,
                    resolve_at_tick=0,
                    payload={
                        "pool": pool_name,
                        "delta": -amount,
                        "current": pool.current,
                        "maximum": pool.value,
                    },
                )
            )

    def _publish(self, event: Event) -> None:
        """Publish *event* to the bus if one is configured."""
        if self._bus is not None:
            self._bus.publish(event)

    def _schedule_events(
        self,
        entity_id: int,
        ability: "Ability",
        target_id: int,
        abs_tick: int,
    ) -> None:
        """Publish the appropriate cast events based on ability timing."""
        if ability.channel_interval is not None:
            self._publish_channel_events(
                entity_id, ability.name, target_id, abs_tick, ability
            )
            return
        resolve_at = abs_tick + ability.cast_time
        if ability.cast_time > 0:
            self._casting[entity_id] = (
                ability.name,
                target_id,
                abs_tick,
                ability.cast_time,
            )
            self._publish(
                Event(
                    event_type=EventType.CAST_STARTED,
                    source_id=entity_id,
                    target_id=target_id,
                    resolve_at_tick=abs_tick,
                    payload={"ability_name": ability.name},
                )
            )
        self._publish(
            self._make_complete_event(entity_id, ability.name, target_id, resolve_at)
        )

    def _make_complete_event(
        self,
        caster_id: int,
        ability_name: str,
        target_id: int,
        resolve_at: int,
    ) -> Event:
        """Build a CAST_COMPLETE event.

        Parameters
        ----------
        caster_id : int
            Entity ID of the caster.
        ability_name : str
            Name of the ability being cast.
        target_id : int
            Entity ID of the target.
        resolve_at : int
            Tick on which the event becomes ready.

        Returns
        -------
        Event
            A frozen CAST_COMPLETE event.
        """
        return Event(
            event_type=EventType.CAST_COMPLETE,
            source_id=caster_id,
            target_id=target_id,
            resolve_at_tick=resolve_at,
            payload={"ability": ability_name},
        )

    def _publish_channel_events(
        self,
        caster_id: int,
        ability_name: str,
        target_id: int,
        abs_tick: int,
        ability: "Ability",
    ) -> None:
        """Publish CHANNEL_TICK events plus a final CAST_COMPLETE.

        Parameters
        ----------
        caster_id : int
            Entity ID of the caster.
        ability_name : str
            Name of the ability.
        target_id : int
            Entity ID of the target.
        abs_tick : int
            Current absolute tick.
        ability : Ability
            The channeled ability.
        """
        if self._bus is None:
            return
        interval = ability.channel_interval
        if interval is None:
            return
        t = abs_tick + interval
        while t <= abs_tick + ability.cast_time:
            self._bus.publish(
                Event(
                    event_type=EventType.CHANNEL_TICK,
                    source_id=caster_id,
                    target_id=target_id,
                    resolve_at_tick=t,
                    payload={"ability": ability_name},
                )
            )
            t += interval
        self._bus.publish(
            self._make_complete_event(
                caster_id, ability_name, target_id, abs_tick + ability.cast_time
            )
        )
