"""AbilityEffectsSystem — applies ability effects, publishing events to the bus."""

from __future__ import annotations

from collections.abc import Sequence
from typing import TYPE_CHECKING

from faraway_realms.combat.abilities import ABILITY_REGISTRY
from faraway_realms.combat.damage_types import compute_ability_damage
from faraway_realms.combat.stats import Pool
from faraway_realms.combat.status import StatusInstance
from faraway_realms.entities.entity import get_combat_profile
from faraway_realms.systems.base import System
from faraway_realms.world.events import Event, EventType

if TYPE_CHECKING:
    from faraway_realms.combat.abilities import (
        Ability,
        ApplyStatusEffect,
        BackstepEffect,
        DamageEffect,
        KnockbackEffect,
        ProjectileEffect,
    )
    from faraway_realms.entities.entity import GameEntity
    from faraway_realms.world.event_bus import EventBus
    from faraway_realms.world.map import Map


class AbilityEffectsSystem(System):
    """Applies the effects of an ability, publishing events to the bus.

    Parameters
    ----------
    entities : dict[int, GameEntity]
        Shared entity dict.
    game_map : Map
        The active map; used for position queries and entity movement.
    bus : EventBus
        Event bus; ENTITY_HIT, ENTITY_DYING, STATUS_APPLIED, STUN_APPLIED, and
        PROJECTILE_SPAWN events are published directly.
    """

    def __init__(
        self,
        entities: dict[int, GameEntity],
        game_map: Map,
        bus: EventBus,
        movement_trails: list | None = None,
    ) -> None:
        self._entities = entities
        self._game_map = game_map
        self._bus = bus
        self._movement_trails: list = (
            movement_trails if movement_trails is not None else []
        )
        bus.subscribe(EventType.CAST_COMPLETE, self._on_cast, priority=0)
        bus.subscribe(EventType.CHANNEL_TICK, self._on_cast, priority=0)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def apply(
        self,
        caster_id: int,
        target_id: int,
        ability: Ability,
        abs_tick: int,
    ) -> None:
        """Apply all effects of *ability* from *caster_id* to *target_id*.

        Parameters
        ----------
        caster_id : int
            Entity ID of the caster.
        target_id : int
            Entity ID of the primary target.
        ability : Ability
            The ability being applied.
        abs_tick : int
            Current absolute tick, used for status expiry and event timing.
        """
        for effect in ability.effects:
            self._apply_single_effect(caster_id, target_id, effect, abs_tick)

    def apply_on_hit_statuses(
        self,
        source_id: int,
        target_id: int,
        statuses: Sequence[ApplyStatusEffect],
        abs_tick: int,
    ) -> None:
        """Apply a list of on-hit status effects (used by projectile detonations).

        Parameters
        ----------
        source_id : int
            Entity ID of the source (projectile owner).
        target_id : int
            Entity ID of the hit target.
        statuses : list[ApplyStatusEffect]
            Status effects to apply.
        abs_tick : int
            Current absolute tick.
        """
        for effect in statuses:
            self._apply_status_effect(source_id, target_id, effect, abs_tick)

    # ------------------------------------------------------------------
    # Effect dispatch
    # ------------------------------------------------------------------

    def _apply_single_effect(
        self,
        caster_id: int,
        target_id: int,
        effect: object,
        abs_tick: int,
    ) -> None:
        from faraway_realms.combat.abilities import (  # noqa: PLC0415
            DamageEffect,
            ProjectileEffect,
        )

        if isinstance(effect, DamageEffect):
            self._apply_damage_effect(caster_id, target_id, effect, abs_tick)
        elif isinstance(effect, ProjectileEffect):
            self._publish_projectile_spawn(caster_id, target_id, effect, abs_tick)
        else:
            self._apply_nondamage_effect(caster_id, target_id, effect, abs_tick)

    def _apply_nondamage_effect(
        self,
        caster_id: int,
        target_id: int,
        effect: object,
        abs_tick: int,
    ) -> None:
        from faraway_realms.combat.abilities import (  # noqa: PLC0415
            ApplyStatusEffect,
            BackstepEffect,
            KnockbackEffect,
        )

        if isinstance(effect, KnockbackEffect):
            self._apply_knockback_effect(caster_id, target_id, effect)
        elif isinstance(effect, BackstepEffect):
            self._apply_backstep(caster_id, target_id, effect)
        elif isinstance(effect, ApplyStatusEffect):
            self._apply_status_effect(caster_id, target_id, effect, abs_tick)

    # ------------------------------------------------------------------
    # Damage
    # ------------------------------------------------------------------

    def _apply_damage_effect(
        self,
        caster_id: int,
        target_id: int,
        effect: DamageEffect,
        abs_tick: int,
    ) -> None:
        target = self._entities.get(target_id)
        caster = self._entities.get(caster_id)
        if target is None or caster is None:
            return
        tcp = get_combat_profile(target)
        pool = target.stats.get(tcp.death_stat)
        if not isinstance(pool, Pool):
            return
        armor = target.stats.get("armor")
        armor_val = armor.value if armor is not None else 0
        damage = compute_ability_damage(
            effect.base, effect.damage_type, tcp.armor_type, armor_val
        )
        self._bus.publish(
            Event(
                event_type=EventType.ENTITY_HIT,
                source_id=caster_id,
                target_id=target_id,
                resolve_at_tick=abs_tick,
                payload={"damage": damage, "crit": False, "is_ability": True},
            )
        )
        pool.modify(-damage)
        if pool.is_empty:
            self._bus.publish(
                Event(
                    event_type=EventType.ENTITY_DYING,
                    source_id=target_id,
                    resolve_at_tick=abs_tick,
                )
            )

    def _publish_projectile_spawn(
        self,
        caster_id: int,
        target_id: int,
        effect: ProjectileEffect,
        abs_tick: int,
    ) -> None:
        self._bus.publish(
            Event(
                event_type=EventType.PROJECTILE_SPAWN,
                source_id=caster_id,
                target_id=target_id,
                resolve_at_tick=abs_tick,
                payload={"effect": effect},
            )
        )

    # ------------------------------------------------------------------
    # Movement effects
    # ------------------------------------------------------------------

    def _apply_knockback_effect(
        self,
        caster_id: int,
        target_id: int,
        effect: KnockbackEffect,
    ) -> None:
        if not (
            self._game_map.has_entity(caster_id)
            and self._game_map.has_entity(target_id)
        ):
            return
        cx, cy = self._game_map.get_entity_position(caster_id)
        tx, ty = self._game_map.get_entity_position(target_id)
        dx = (tx > cx) - (tx < cx)
        dy = (ty > cy) - (ty < cy)
        path = self._push_entity(target_id, dx, dy, effect.distance)
        self._record_trail(target_id, path)

    def _apply_backstep(
        self,
        caster_id: int,
        target_id: int,
        effect: BackstepEffect,
    ) -> None:
        if not (
            self._game_map.has_entity(caster_id)
            and self._game_map.has_entity(target_id)
        ):
            return
        cx, cy = self._game_map.get_entity_position(caster_id)
        tx, ty = self._game_map.get_entity_position(target_id)
        dx = (cx > tx) - (cx < tx)
        dy = (cy > ty) - (cy < ty)
        path = self._push_entity(caster_id, dx, dy, effect.distance)
        self._record_trail(caster_id, path)

    def _push_entity(
        self, entity_id: int, dx: int, dy: int, distance: int
    ) -> list[tuple[int, int]]:
        path: list[tuple[int, int]] = []
        for _ in range(distance):
            if not self._game_map.has_entity(entity_id):
                break
            pos = self._game_map.get_entity_position(entity_id)
            if not self._push_step(entity_id, dx, dy):
                break
            path.append(pos)
        return path

    def _record_trail(self, entity_id: int, path: list[tuple[int, int]]) -> None:
        if not path:
            return
        entity = self._entities.get(entity_id)
        if entity is not None:
            self._movement_trails.append(
                (entity_id, entity.char, entity.fg_color, path)
            )

    def _push_step(self, entity_id: int, dx: int, dy: int) -> bool:
        """Attempt one push step; return ``False`` when blocked or entity missing."""
        if not self._game_map.has_entity(entity_id):
            return False
        x, y = self._game_map.get_entity_position(entity_id)
        nx, ny = x + dx, y + dy
        if self._game_map.is_occupied(nx, ny) or not self._game_map.is_walkable(nx, ny):
            return False
        self._game_map.move_entity(entity_id, dx, dy)
        return True

    # ------------------------------------------------------------------
    # Status effects
    # ------------------------------------------------------------------

    def _apply_status_effect(
        self,
        caster_id: int,
        target_id: int,
        effect: ApplyStatusEffect,
        abs_tick: int,
    ) -> None:
        target = self._entities.get(target_id)
        if target is None:
            return
        target.status_effects = [
            s for s in target.status_effects if s.name != effect.status_name
        ]
        target.status_effects.append(
            StatusInstance(
                name=effect.status_name,
                expires_at=abs_tick + effect.duration,
                tick_damage=effect.tick_damage,
                tick_heal=effect.tick_heal,
                dot_interval=effect.dot_interval,
                next_dot_tick=abs_tick + effect.dot_interval,
                immobilize=effect.immobilize,
                stun=effect.stun,
                haste=effect.haste,
            )
        )
        self._bus.publish(
            Event(
                event_type=EventType.STATUS_APPLIED,
                source_id=caster_id,
                target_id=target_id,
                resolve_at_tick=abs_tick,
                payload={
                    "status_name": effect.status_name,
                    "show_message": effect.show_message,
                    "stun": effect.stun,
                    "immobilize": effect.immobilize,
                },
            )
        )
        if effect.stun:
            self._bus.publish(
                Event(
                    event_type=EventType.STUN_APPLIED,
                    source_id=caster_id,
                    target_id=target_id,
                    resolve_at_tick=abs_tick,
                )
            )
        if effect.immobilize:
            self._bus.publish(
                Event(
                    event_type=EventType.IMMOBILIZE_APPLIED,
                    source_id=caster_id,
                    target_id=target_id,
                    resolve_at_tick=abs_tick,
                )
            )

    def _on_cast(self, event: Event) -> None:
        """Apply ability effects when a cast completes or a channel tick fires."""
        if event.target_id is None or event.payload is None:
            return
        if event.source_id not in self._entities:
            return  # caster died before cast completed
        ability = ABILITY_REGISTRY.get(str(event.payload.get("ability", "")))
        if ability is None:
            return
        self.apply(event.source_id, event.target_id, ability, event.resolve_at_tick)
