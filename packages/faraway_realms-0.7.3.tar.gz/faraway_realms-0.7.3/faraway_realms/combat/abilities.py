"""Ability and effect type definitions.

Ability instances are loaded at runtime from YAML via
:mod:`faraway_realms.content_parsers.abilities`.  This module provides only
the dataclass types and the shared ``ABILITY_REGISTRY`` dict that the loader
populates.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field

from faraway_realms.entities.components import Component


@dataclass(frozen=True)
class AbilityEffect(ABC):
    """Abstract base for a single effect applied when an ability resolves.

    Subclasses represent distinct effect kinds (damage, knockback, status).
    """

    @abstractmethod
    def kind(self) -> str:
        """Short string identifier for this effect type.

        Returns
        -------
        str
            Effect kind key (e.g. ``"damage"``).
        """


@dataclass(frozen=True)
class DamageEffect(AbilityEffect):
    """Deal a fixed amount of damage of a specific type.

    Parameters
    ----------
    base : int
        Base damage before armor and type modifiers.
    damage_type : str
        Damage type string (e.g. ``"bludgeoning"``).
    """

    base: int = 5
    damage_type: str = "bludgeoning"

    def kind(self) -> str:
        """Return ``"damage"``.

        Returns
        -------
        str
            Always ``"damage"``.
        """
        return "damage"


@dataclass(frozen=True)
class KnockbackEffect(AbilityEffect):
    """Push the target away from the caster.

    Parameters
    ----------
    distance : int
        Number of tiles to push the target.
    """

    distance: int = 1

    def kind(self) -> str:
        """Return ``"knockback"``.

        Returns
        -------
        str
            Always ``"knockback"``.
        """
        return "knockback"


@dataclass(frozen=True)
class BackstepEffect(AbilityEffect):
    """Move the caster away from the target.

    Parameters
    ----------
    distance : int
        Number of tiles to step back.
    """

    distance: int = 2

    def kind(self) -> str:
        """Return ``"backstep"``."""
        return "backstep"


@dataclass(frozen=True)
class ApplyStatusEffect(AbilityEffect):
    """Apply a named status condition to the target.

    Parameters
    ----------
    status_name : str
        Name of the status condition (e.g. ``"bleed"``).
    duration : int
        Duration in ticks.
    tick_damage : int
        Damage dealt per DoT interval. ``0`` means no damage.
    tick_heal : int
        HP restored per HoT interval. ``0`` means no healing.
    dot_interval : int
        Ticks between DoT/HoT applications (default 10 = once per second).
    immobilize : bool
        When ``True``, the target cannot move for the duration.
    stun : bool
        When ``True``, the target cannot attack or cast for the duration.
    haste : float
        Attack-speed multiplier while active (>1.0 = faster; 1.0 = none).
    show_message : bool
        When ``False``, no chat message is logged on application.
    """

    status_name: str = ""
    duration: int = 0
    tick_damage: int = 0
    tick_heal: int = 0
    dot_interval: int = 10
    immobilize: bool = False
    stun: bool = False
    haste: float = 1.0
    show_message: bool = True

    def kind(self) -> str:
        """Return ``"status"``.

        Returns
        -------
        str
            Always ``"status"``.
        """
        return "status"


@dataclass(frozen=True)
class ProjectileEffect(AbilityEffect):
    """Launch a homing projectile with configurable speed and visual trail.

    Parameters
    ----------
    base : int
        Base damage on impact before armor and type modifiers.
    damage_type : str
        Damage type string (e.g. ``"fire"``).
    speed : float
        Tiles moved per tick. ``<1`` slows the projectile (e.g. ``0.5`` =
        1 tile every 2 ticks); ``>1`` moves multiple tiles per tick (e.g.
        ``2.0`` = 2 tiles/tick).
    color : tuple[int, int, int]
        RGB colour of the in-flight ``*`` glyph.
    visual_type : str
        Visual category hint for the client (``"spell"``, ``"arrow"``).
    trail_length : int
        Number of past positions rendered as a dimming trail. ``0`` = none.
    trail_char : str
        Single character drawn at each trail position (default ``"+"``).
    on_hit_statuses : tuple[ApplyStatusEffect, ...]
        Status effects applied to the target on impact.
    components : dict[str, Component]
        Optional cross-cutting capabilities (e.g. ``"light_emitter"``).
    """

    base: int = 10
    damage_type: str = "fire"
    speed: float = 1.0
    color: tuple[int, int, int] = (255, 100, 0)
    visual_type: str = "spell"
    trail_length: int = 0
    trail_char: str = "+"
    on_hit_statuses: tuple[ApplyStatusEffect, ...] = ()
    components: dict[str, Component] = field(
        default_factory=dict, hash=False, compare=False
    )

    def kind(self) -> str:
        """Return ``"projectile"``.

        Returns
        -------
        str
            Always ``"projectile"``.
        """
        return "projectile"


@dataclass(frozen=True)
class Ability:
    """An action that entities can use, with timing and effect data.

    Parameters
    ----------
    name : str
        Unique name used as a registry key.
    cooldown : int
        Ability-specific cooldown in ticks; ``0`` means GCD-gated only.
    cast_time : int
        Ticks before the ability resolves; ``0`` = instant.
    range_tiles : int
        Maximum Chebyshev distance to the target.
    can_move_while_casting : bool
        Whether the caster may move during cast time.
    gcd : bool
        Whether using this ability consumes the global cooldown.
    channel_interval : int | None
        ``None`` for non-channeled abilities; number of ticks between
        channel ticks for channeled abilities.
    effects : tuple[AbilityEffect, ...]
        Ordered sequence of effects applied on resolution.
    description : str
        Human-readable description shown in the UI.
    resource_cost : tuple[str, int] | None
        Pool key and amount deducted when the cast begins; ``None`` = free.
        Examples: ``("mana", 15)``, ``("rage", 30)``.
    """

    name: str
    cooldown: int
    cast_time: int = 0
    range_tiles: int = 1
    can_move_while_casting: bool = False
    gcd: bool = True
    channel_interval: int | None = None
    effects: tuple[AbilityEffect, ...] = ()
    description: str = ""
    abbreviation: str = ""  # 2-char hotbar label; falls back to first 2 letters of name
    resource_cost: tuple[str, int] | None = None


ABILITY_REGISTRY: dict[str, Ability] = {}
