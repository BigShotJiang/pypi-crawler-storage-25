"""Non-blocking structured JSON event logger for game observability."""

from __future__ import annotations

import json
import logging
import logging.handlers
import queue
import time
import urllib.request
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

# Module-level logger.  Disabled (level=WARNING) until setup_game_logger() is
# called, so log_event() is a no-op in test contexts and pure-client mode.
game_log = logging.getLogger("faraway_realms.events")
game_log.propagate = False
game_log.setLevel(logging.WARNING)

_listener: logging.handlers.QueueListener | None = None


class _JSONFormatter(logging.Formatter):
    """Format a LogRecord as a single JSON line."""

    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "ts": datetime.now(UTC).isoformat(),
            "event": record.getMessage(),
        }
        payload.update(getattr(record, "_fields", {}))
        return json.dumps(payload)


class _LokiHandler(logging.Handler):
    """Push each log record directly to Loki's HTTP push API.

    Runs in the QueueListener background thread so it never blocks the game
    tick loop.  Network failures are silently dropped; the file handler is
    the primary durable record.
    """

    def __init__(self, url: str) -> None:
        super().__init__()
        self._push_url = url.rstrip("/") + "/loki/api/v1/push"

    def emit(self, record: logging.LogRecord) -> None:
        try:
            self._push(record)
        except Exception:  # noqa: BLE001, S110 — silently dropped; file log is primary
            pass

    def _push(self, record: logging.LogRecord) -> None:
        line = self.format(record)
        ts_ns = str(int(time.time() * 1_000_000_000))
        body = json.dumps(
            {
                "streams": [
                    {
                        "stream": {"job": "faraway", "event": record.getMessage()},
                        "values": [[ts_ns, line]],
                    }
                ]
            }
        ).encode()
        req = urllib.request.Request(  # noqa: S310 — URL supplied by operator config
            self._push_url,
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=2.0):  # noqa: S310
            pass


def setup_game_logger(log_dir: Path, loki_url: str | None = None) -> None:
    """Wire a non-blocking JSON file handler and an optional Loki push handler.

    Writes newline-delimited JSON to ``<log_dir>/game.jsonl`` (durable local
    archive).  When *loki_url* is provided, each record is also pushed directly
    to Loki over HTTP for real-time dashboard feeds.  Both handlers run on a
    background thread via :class:`logging.handlers.QueueListener` so
    :func:`log_event` never blocks the game tick loop.

    Safe to call multiple times (subsequent calls are no-ops).

    Parameters
    ----------
    log_dir : Path
        Directory for ``game.jsonl``.  Created if it does not exist.
    loki_url : str | None
        Base URL for the Loki push API (e.g. ``http://localhost:3100``).
        Pass ``None`` (the default) to disable Loki push.  Network failures
        are silently dropped and never affect gameplay.
    """
    global _listener
    if _listener is not None:
        return
    log_dir.mkdir(parents=True, exist_ok=True)
    formatter = _JSONFormatter()

    file_handler = logging.FileHandler(log_dir / "game.jsonl")
    file_handler.setFormatter(formatter)

    handlers: list[logging.Handler] = [file_handler]
    if loki_url is not None:
        loki_handler = _LokiHandler(loki_url)
        loki_handler.setFormatter(formatter)
        handlers.append(loki_handler)

    q: queue.Queue[logging.LogRecord] = queue.Queue()
    queue_handler = logging.handlers.QueueHandler(q)
    _listener = logging.handlers.QueueListener(q, *handlers, respect_handler_level=True)
    _listener.start()

    game_log.setLevel(logging.INFO)
    game_log.addHandler(queue_handler)


def log_event(event: str, **fields: Any) -> None:
    """Emit one structured event to the game log (non-blocking).

    No-op when :func:`setup_game_logger` has not been called (e.g. in tests
    or pure-client mode).

    Parameters
    ----------
    event : str
        Event name (becomes the ``event`` field in the JSON line and a Loki
        stream label).
    **fields :
        Additional key/value pairs merged into the JSON object.
    """
    if not game_log.isEnabledFor(logging.INFO):
        return
    record = game_log.makeRecord(game_log.name, logging.INFO, "", 0, event, (), None)
    record._fields = fields  # type: ignore[attr-defined]
    game_log.handle(record)
