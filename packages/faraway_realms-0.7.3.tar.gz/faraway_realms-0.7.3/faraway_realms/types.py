"""Shared primitive type aliases used across the codebase."""

from __future__ import annotations

Color = tuple[int, int, int]
"""RGB colour as a three-int tuple."""

Pos = tuple[int, int]
"""2-D map position as an (x, y) integer tuple."""
