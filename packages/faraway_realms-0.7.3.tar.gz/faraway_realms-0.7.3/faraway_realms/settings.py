"""Display and admin settings — loaded from YAML, overridable via ~/.faraway_realms/."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

import yaml

_DATA_SETTINGS = Path(__file__).parent / "data" / "settings.yaml"
_USER_SETTINGS = Path.home() / ".faraway_realms" / "settings.yaml"


@dataclass(frozen=True)
class DisplaySettings:
    """Display configuration loaded from settings.yaml.

    Parameters
    ----------
    fullscreen : bool
        Borderless fullscreen at desktop resolution (SDL_WINDOW_FULLSCREEN).
    integer_scale : int
        Integer tile scaling multiplier (1 = native 12 px tiles).
    vsync : bool
        Enable vertical sync.
    allow_highdpi : bool
        Use physical Retina/HiDPI pixels — gives free 2× on Mac without
        changing the logical window size.
    borderless : bool
        Borderless windowed mode (no title bar, stays on desktop).
    maximized : bool
        Start the window maximized.
    window_x : int | None
        Horizontal window position in screen pixels (None = OS default).
    window_y : int | None
        Vertical window position in screen pixels (None = OS default).
    scale_quality : str
        Texture filtering when the window size is not an exact pixel multiple.
        ``"nearest"`` (crisp, default), ``"linear"`` (smooth), ``"best"``
        (anisotropic where supported).
    """

    fullscreen: bool = False
    integer_scale: int = 1
    vsync: bool = False
    allow_highdpi: bool = False
    borderless: bool = False
    maximized: bool = False
    resizable: bool = True
    window_x: int | None = None
    window_y: int | None = None
    scale_quality: str = "nearest"


def load_display_settings() -> DisplaySettings:
    """Load display settings, merging user overrides on top of shipped defaults."""
    cfg = _read_yaml(_DATA_SETTINGS).get("display", {})
    cfg.update(_read_yaml(_USER_SETTINGS).get("display", {}))
    return DisplaySettings(
        fullscreen=bool(cfg.get("fullscreen", False)),
        integer_scale=max(1, int(cfg.get("integer_scale", 1))),
        vsync=bool(cfg.get("vsync", False)),
        allow_highdpi=bool(cfg.get("allow_highdpi", False)),
        borderless=bool(cfg.get("borderless", False)),
        maximized=bool(cfg.get("maximized", False)),
        resizable=bool(cfg.get("resizable", True)),
        window_x=int(cfg["window_x"]) if "window_x" in cfg else None,
        window_y=int(cfg["window_y"]) if "window_y" in cfg else None,
        scale_quality=str(cfg.get("scale_quality", "nearest")),
    )


@dataclass(frozen=True)
class AdminSettings:
    """Admin / server-operator configuration loaded from settings.yaml.

    Parameters
    ----------
    loki_url : str | None
        Base URL for the Loki push API (e.g. ``http://localhost:3100``).
        ``None`` disables Loki push entirely.  Can be overridden by the
        ``--loki-url`` CLI flag or the ``FARAWAY_LOKI_URL`` environment variable.
    """

    loki_url: str | None = None


def load_admin_settings() -> AdminSettings:
    """Load admin settings, merging user overrides on top of shipped defaults."""
    cfg = _read_yaml(_DATA_SETTINGS).get("admin") or {}
    cfg.update(_read_yaml(_USER_SETTINGS).get("admin") or {})
    raw_url: str | None = cfg.get("loki_url") or os.getenv("FARAWAY_LOKI_URL")
    return AdminSettings(loki_url=raw_url or None)


def _read_yaml(path: Path) -> dict:
    if not path.exists():
        return {}
    with path.open() as fh:
        return yaml.safe_load(fh) or {}
