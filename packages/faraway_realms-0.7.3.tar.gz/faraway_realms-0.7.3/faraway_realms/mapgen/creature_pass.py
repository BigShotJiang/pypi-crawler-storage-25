"""Creature population pass — places NPCs from the creature registry into rooms."""

from __future__ import annotations

import random
from dataclasses import dataclass

from faraway_realms.entities.creature_type import CREATURE_REGISTRY
from faraway_realms.mapgen.base import MapGenResult, PopulationPass


def _by_labels(
    labels: tuple[str, ...] | None,
) -> list:
    """Return registry entries matching any of the given labels.

    Parameters
    ----------
    labels : tuple[str, ...] or None
        ``None`` returns all types.  An empty tuple returns nothing.
        Otherwise only types carrying at least one matching label are returned.

    Returns
    -------
    list
        Matching :class:`~faraway_realms.entities.creature_type.CreatureType` instances.
    """
    types = list(CREATURE_REGISTRY.values())
    if labels is None:
        return types
    label_set = set(labels)
    return [ct for ct in types if ct.labels & label_set]


@dataclass
class CreaturePopulationPass(PopulationPass):
    """Place creatures drawn from the creature registry.

    Two placement modes:

    **Zone mode** (``count == 0``, default): one creature per non-player zone.
    Works well for room-based generators where each zone is a distinct room.

    **Scatter mode** (``count > 0``): place exactly *count* creatures at random
    walkable positions.  Positions inside the player zone are only eligible when
    they are at least *min_player_distance* Manhattan units from *player_start*.
    Use this for open CA maps where a single large region is the only zone.

    Parameters
    ----------
    labels : tuple[str, ...] or None
        ``None`` makes all creature types eligible.  An empty tuple spawns
        nothing.  Otherwise only types carrying at least one of these labels
        are eligible.
    count : int
        Number of creatures to place in scatter mode.  ``0`` uses zone mode.
    min_player_distance : int
        Minimum Manhattan distance from ``player_start`` when picking positions
        inside the player zone.  Ignored in zone mode (player zone is skipped).
    """

    labels: tuple[str, ...] | None = None
    count: int = 0
    min_player_distance: int = 0

    def apply(self, result: MapGenResult, rng: random.Random) -> None:
        """Populate the map with creatures from the registry.

        Parameters
        ----------
        result : MapGenResult
            The map and room layout produced by the generator.
        rng : random.Random
            Seeded random number generator for deterministic placement.
        """
        types = _by_labels(self.labels)
        if not types:
            return
        if self.count > 0:
            self._place_scatter(result, types, rng)
        elif result.spawn_zones:
            self._place_from_zones(result, types, rng)
        else:
            self._place_from_rooms(result, types, rng)

    def _place_scatter(
        self, result: MapGenResult, types: list, rng: random.Random
    ) -> None:
        eligible = self._eligible_tiles(result)
        if not eligible:
            return
        for _ in range(self.count):
            ct = rng.choice(types)  # noqa: S311 — game logic, not crypto
            x, y = rng.choice(eligible)  # noqa: S311 — game logic, not crypto
            result.creature_placements.append((ct, x, y))

    def _eligible_tiles(self, result: MapGenResult) -> list[tuple[int, int]]:
        px, py = result.player_start
        tiles: list[tuple[int, int]] = []
        for i, zone in enumerate(result.spawn_zones):
            if i == result.player_zone_index:
                tiles.extend(
                    (x, y)
                    for x, y in zone
                    if abs(x - px) + abs(y - py) >= self.min_player_distance
                )
            else:
                tiles.extend(zone)
        return tiles

    def _place_from_zones(
        self, result: MapGenResult, types: list, rng: random.Random
    ) -> None:
        for i, zone in enumerate(result.spawn_zones):
            if i == result.player_zone_index:
                continue
            ct = rng.choice(types)  # noqa: S311 — game logic, not crypto
            x, y = rng.choice(zone)  # noqa: S311 — game logic, not crypto
            result.creature_placements.append((ct, x, y))

    def _place_from_rooms(
        self, result: MapGenResult, types: list, rng: random.Random
    ) -> None:
        for room in result.rooms[1:]:
            ct = rng.choice(types)  # noqa: S311 — game logic, not crypto
            cx, cy = room.center
            result.creature_placements.append((ct, cx, cy))
