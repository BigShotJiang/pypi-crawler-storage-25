"""Static object population pass — places decorations from the registry."""

from __future__ import annotations

import random
from dataclasses import dataclass

from faraway_realms.entities.static_object import STATIC_OBJECT_REGISTRY
from faraway_realms.mapgen.base import MapGenResult, PopulationPass


def _by_labels(
    labels: tuple[str, ...] | None,
) -> list:
    """Return registry entries matching any of the given labels.

    Parameters
    ----------
    labels : tuple[str, ...] or None
        ``None`` returns all types.  An empty tuple returns nothing.
        Otherwise only types carrying at least one matching label are returned.

    Returns
    -------
    list
        Matching :class:`~faraway_realms.entities.static_object.StaticObjectType`
        instances.
    """
    types = list(STATIC_OBJECT_REGISTRY.values())
    if labels is None:
        return types
    label_set = set(labels)
    return [sot for sot in types if sot.labels & label_set]


@dataclass
class StaticObjectPopulationPass(PopulationPass):
    """Place static objects (torches, mushrooms, …) drawn from the registry.

    Two placement modes:

    **Zone mode** (``count == 0``, default): each non-player zone has a
    *density* chance to receive one object.  Works well for room-based generators.

    **Scatter mode** (``count > 0``): place exactly *count* objects at random
    walkable positions, subject to *min_player_distance* for positions in the
    player zone.  Suitable for open CA maps.

    Parameters
    ----------
    labels : tuple[str, ...] or None
        ``None`` makes all types eligible.  An empty tuple spawns nothing.
        Otherwise only types carrying at least one of these labels are eligible.
    density : float
        Probability [0, 1] that a given zone/room receives an object in zone
        mode.  Ignored in scatter mode.
    count : int
        Number of objects to place in scatter mode.  ``0`` uses zone mode.
    min_player_distance : int
        Minimum Manhattan distance from ``player_start`` when picking positions
        in the player zone.  Ignored in zone mode.
    """

    labels: tuple[str, ...] | None = None
    density: float = 0.4
    count: int = 0
    min_player_distance: int = 0

    def apply(self, result: MapGenResult, rng: random.Random) -> None:
        """Populate the map with static objects from the registry.

        Parameters
        ----------
        result : MapGenResult
            The map and room layout produced by the generator.
        rng : random.Random
            Seeded random number generator for deterministic placement.
        """
        types = _by_labels(self.labels)
        if not types:
            return
        if self.count > 0:
            self._place_scatter(result, types, rng)
        elif result.spawn_zones:
            self._place_from_zones(result, types, rng)
        else:
            self._place_from_rooms(result, types, rng)

    def _place_scatter(
        self, result: MapGenResult, types: list, rng: random.Random
    ) -> None:
        eligible = self._eligible_tiles(result)
        if not eligible:
            return
        for _ in range(self.count):
            sot = rng.choice(types)  # noqa: S311 — game logic, not crypto
            x, y = rng.choice(eligible)  # noqa: S311 — game logic, not crypto
            result.static_object_placements.append((sot, x, y))

    def _eligible_tiles(self, result: MapGenResult) -> list[tuple[int, int]]:
        px, py = result.player_start
        tiles: list[tuple[int, int]] = []
        for i, zone in enumerate(result.spawn_zones):
            if i == result.player_zone_index:
                tiles.extend(
                    (x, y)
                    for x, y in zone
                    if abs(x - px) + abs(y - py) >= self.min_player_distance
                )
            else:
                tiles.extend(zone)
        return tiles

    def _place_from_zones(
        self, result: MapGenResult, types: list, rng: random.Random
    ) -> None:
        for i, zone in enumerate(result.spawn_zones):
            if i == result.player_zone_index:
                continue
            if rng.random() > self.density:
                continue
            sot = rng.choice(types)  # noqa: S311 — game logic, not crypto
            x, y = rng.choice(zone)  # noqa: S311 — game logic, not crypto
            result.static_object_placements.append((sot, x, y))

    def _place_from_rooms(
        self, result: MapGenResult, types: list, rng: random.Random
    ) -> None:
        for room in result.rooms[1:]:
            if rng.random() > self.density:
                continue
            sot = rng.choice(types)  # noqa: S311 — game logic, not crypto
            cx, cy = room.center
            result.static_object_placements.append((sot, cx, cy))
