"""MapGenerator ABC and generator factory."""

from __future__ import annotations

import random
from abc import ABC, abstractmethod
from dataclasses import dataclass, field

from faraway_realms.mapgen.base import MapGenResult


class MapGenerator(ABC):
    """Abstract base class for map generators.

    All generators must produce a :class:`~faraway_realms.mapgen.base.MapGenResult`
    with ``map``, ``player_start``, and ``spawn_zones`` populated.
    ``rooms`` and ``door_candidates`` are optional and may be left empty.
    """

    @abstractmethod
    def generate(self, width: int, height: int, rng: random.Random) -> MapGenResult:
        """Generate a map of the given dimensions.

        Parameters
        ----------
        width : int
            Map width in tiles.
        height : int
            Map height in tiles.
        rng : random.Random
            Seeded RNG for deterministic output.

        Returns
        -------
        MapGenResult
            Generated map with spawn zones and player start populated.
        """


@dataclass(frozen=True)
class GeneratorConfig:
    """Frozen, hashable configuration for a map generator.

    Parameters
    ----------
    kind : str
        Generator identifier (``"cave"`` or ``"cellular_automata"``).
    params : tuple[tuple[str, int | float | str | bool], ...]
        Key-value pairs forwarded to the generator constructor.
    """

    kind: str = "cave"
    params: tuple[tuple[str, int | float | str | bool], ...] = field(
        default_factory=tuple
    )

    def as_dict(self) -> dict[str, int | float | str | bool]:
        """Return params as a plain dict for use as keyword arguments."""
        return dict(self.params)


def make_generator(config: GeneratorConfig) -> MapGenerator:
    """Instantiate the generator described by *config*.

    Parameters
    ----------
    config : GeneratorConfig
        Generator kind and constructor parameters.

    Returns
    -------
    MapGenerator
        Ready-to-use generator instance.

    Raises
    ------
    ValueError
        When ``config.kind`` is not a recognised generator name.
    """
    from faraway_realms.mapgen.cave import CaveGenerator
    from faraway_realms.mapgen.cellular import CellularAutomataGenerator

    # p values are int|float|str|bool from YAML; mypy can't verify they match
    # each constructor's exact parameter types — suppressed intentionally.
    p = config.as_dict()
    if config.kind == "cave":
        return CaveGenerator(**p)  # type: ignore[arg-type]
    if config.kind == "cellular_automata":
        return CellularAutomataGenerator(**p)  # type: ignore[arg-type]
    raise ValueError(f"Unknown map generator: {config.kind!r}")
