"""Map generation pipeline — generators and population passes."""

from faraway_realms.mapgen.base import DoorCandidate, MapGenResult, PopulationPass, Rect
from faraway_realms.mapgen.cave import CaveGenerator
from faraway_realms.mapgen.cellular import CellularAutomataGenerator
from faraway_realms.mapgen.corridor_narrowing_pass import CorridorNarrowingPass
from faraway_realms.mapgen.creature_pass import CreaturePopulationPass
from faraway_realms.mapgen.door_population_pass import DoorPopulationPass
from faraway_realms.mapgen.generator import GeneratorConfig, MapGenerator, make_generator
from faraway_realms.mapgen.scatter_pass import ScatterRule, TileScatterPass
from faraway_realms.mapgen.static_object_pass import StaticObjectPopulationPass
from faraway_realms.mapgen.texture import (
    MOSS_OVERLAY,
    TILE_OVERLAY_REGISTRY,
    TILE_TYPE_PATCH_REGISTRY,
    NoiseTexturePass,
    TileOverlay,
    TileTypePatch,
)

__all__ = [
    "CaveGenerator",
    "CellularAutomataGenerator",
    "CorridorNarrowingPass",
    "CreaturePopulationPass",
    "DoorCandidate",
    "DoorPopulationPass",
    "GeneratorConfig",
    "MapGenResult",
    "MapGenerator",
    "MOSS_OVERLAY",
    "NoiseTexturePass",
    "PopulationPass",
    "Rect",
    "ScatterRule",
    "StaticObjectPopulationPass",
    "TILE_OVERLAY_REGISTRY",
    "TILE_TYPE_PATCH_REGISTRY",
    "TileOverlay",
    "TileScatterPass",
    "TileTypePatch",
    "make_generator",
]
