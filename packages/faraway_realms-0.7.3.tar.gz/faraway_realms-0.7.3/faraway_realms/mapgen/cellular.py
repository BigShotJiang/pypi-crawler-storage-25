"""Cellular automata map generator — organic open caverns."""

from __future__ import annotations

import random
from dataclasses import dataclass

from faraway_realms.mapgen.base import MapGenResult, seed_base_tile_types
from faraway_realms.mapgen.generator import MapGenerator
from faraway_realms.types import Pos
from faraway_realms.world.map import Map
from faraway_realms.world.tile import (
    TILE_REGISTRY,
    Tile,
    cave_floor_tile,
    cave_wall_tile,
)


@dataclass
class CellularAutomataGenerator(MapGenerator):
    """Generate organic open caverns using a cellular automata smoothing rule.

    The B5678/S45678 "cave" rule is applied for several iterations on a
    randomly seeded grid, producing irregular open regions with no corridors.
    Tiny disconnected voids are filled in; remaining regions become spawn zones.

    Parameters
    ----------
    fill_prob : float
        Probability (0–1) that each tile starts as a wall during seeding.
        Higher values produce denser, more fragmented caves.
    iterations : int
        Number of CA smoothing passes.  5 is a good default.
    min_region_size : int
        Connected walkable regions smaller than this are filled as walls.
    floor_tile_name : str
        TILE_REGISTRY key for the base floor tile.
    wall_tile_name : str
        TILE_REGISTRY key for the base wall tile.
    """

    fill_prob: float = 0.45
    iterations: int = 5
    min_region_size: int = 30
    floor_tile_name: str = "cave_floor"
    wall_tile_name: str = "cave_wall"

    def _make_floor(self) -> Tile:
        tt = TILE_REGISTRY.get(self.floor_tile_name)
        return tt.make() if tt is not None else cave_floor_tile()

    def _make_wall(self) -> Tile:
        tt = TILE_REGISTRY.get(self.wall_tile_name)
        return tt.make() if tt is not None else cave_wall_tile()

    def generate(self, width: int, height: int, rng: random.Random) -> MapGenResult:
        """Build and return an organic cave map.

        Parameters
        ----------
        width : int
            Map width in tiles.
        height : int
            Map height in tiles.
        rng : random.Random
            Seeded RNG for deterministic output.

        Returns
        -------
        MapGenResult
            Generated map with spawn zones populated.  ``rooms`` is empty.
        """
        grid = self._seed(width, height, rng)
        for _ in range(self.iterations):
            grid = self._smooth_once(grid, width, height)
        regions = self._flood_fill_regions(grid, width, height)
        grid = self._cull_small(grid, regions, width, height)
        regions = self._flood_fill_regions(grid, width, height)
        tiles = self._build_tiles(grid, width, height)
        game_map = Map(width, height, tiles)
        player_start, player_region = self._pick_player_start(regions)
        result = MapGenResult(
            map=game_map,
            rooms=[],
            player_start=player_start,
            player_zone_index=0,
        )
        self._fill_spawn_zones(result, regions, player_region)
        seed_base_tile_types(result, self.floor_tile_name, self.wall_tile_name)
        return result

    def _seed(self, width: int, height: int, rng: random.Random) -> list[list[bool]]:
        """Return a 2D grid; True = wall, border always wall."""
        grid = []
        for y in range(height):
            row = []
            for x in range(width):
                is_border = x == 0 or y == 0 or x == width - 1 or y == height - 1
                row.append(is_border or rng.random() < self.fill_prob)
            grid.append(row)
        return grid

    def _smooth_once(
        self, grid: list[list[bool]], width: int, height: int
    ) -> list[list[bool]]:
        """Apply one CA pass: a tile becomes wall when ≥ 5 of 8 neighbours are walls."""
        new_grid = []
        for y in range(height):
            row = []
            for x in range(width):
                row.append(self._next_cell(grid, x, y, width, height))
            new_grid.append(row)
        return new_grid

    def _next_cell(
        self,
        grid: list[list[bool]],
        x: int,
        y: int,
        width: int,
        height: int,
    ) -> bool:
        neighbours = [(x + dx, y + dy) for dy in range(-1, 2) for dx in range(-1, 2)]
        wall_count = sum(
            1
            for nx, ny in neighbours
            if nx < 0 or ny < 0 or nx >= width or ny >= height or grid[ny][nx]
        )
        return wall_count >= 5

    def _flood_fill_regions(
        self, grid: list[list[bool]], width: int, height: int
    ) -> list[list[Pos]]:
        """Return all connected walkable regions via 4-connectivity flood fill."""
        visited = [[False] * width for _ in range(height)]
        regions: list[list[Pos]] = []
        for sy in range(height):
            for sx in range(width):
                if not grid[sy][sx] and not visited[sy][sx]:
                    regions.append(self._bfs(grid, visited, sx, sy, width, height))
        return regions

    def _bfs(
        self,
        grid: list[list[bool]],
        visited: list[list[bool]],
        start_x: int,
        start_y: int,
        width: int,
        height: int,
    ) -> list[Pos]:
        region: list[Pos] = []
        queue = [(start_x, start_y)]
        visited[start_y][start_x] = True
        while queue:
            x, y = queue.pop()
            region.append((x, y))
            self._enqueue_neighbours(grid, visited, queue, x, y, width, height)
        return region

    def _enqueue_neighbours(
        self,
        grid: list[list[bool]],
        visited: list[list[bool]],
        queue: list[Pos],
        x: int,
        y: int,
        width: int,
        height: int,
    ) -> None:
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx, ny = x + dx, y + dy
            if 0 <= nx < width and 0 <= ny < height:
                if not grid[ny][nx] and not visited[ny][nx]:
                    visited[ny][nx] = True
                    queue.append((nx, ny))

    def _cull_small(
        self,
        grid: list[list[bool]],
        regions: list[list[Pos]],
        width: int,
        height: int,
    ) -> list[list[bool]]:
        """Fill regions smaller than min_region_size with walls."""
        new_grid = [row[:] for row in grid]
        for region in regions:
            if len(region) < self.min_region_size:
                for x, y in region:
                    new_grid[y][x] = True
        return new_grid

    def _build_tiles(
        self, grid: list[list[bool]], width: int, height: int
    ) -> list[list[Tile]]:
        return [
            [
                self._make_wall() if grid[y][x] else self._make_floor()
                for x in range(width)
            ]
            for y in range(height)
        ]

    def _pick_player_start(self, regions: list[list[Pos]]) -> tuple[Pos, list[Pos]]:
        """Return (player_start, player_region) using the largest region."""
        largest = max(regions, key=len)
        cx = sum(x for x, _ in largest) // len(largest)
        cy = sum(y for _, y in largest) // len(largest)
        start = min(largest, key=lambda p: abs(p[0] - cx) + abs(p[1] - cy))
        return start, largest

    def _fill_spawn_zones(
        self,
        result: MapGenResult,
        regions: list[list[Pos]],
        player_region: list[Pos],
    ) -> None:
        """Populate result.spawn_zones; player region goes at player_zone_index=0."""
        result.spawn_zones.append(list(player_region))
        player_set = set(player_region)
        for region in regions:
            if set(region) != player_set:
                result.spawn_zones.append(list(region))
