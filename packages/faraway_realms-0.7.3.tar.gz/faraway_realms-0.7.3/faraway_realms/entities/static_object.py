"""Static map objects: decorations and environmental light sources."""

from __future__ import annotations

from dataclasses import dataclass, field

from faraway_realms.entities.components import Component


@dataclass
class StaticObject:
    """A non-entity object placed on the map.

    Static objects are rendered between the blood layer and entities.  They do
    not participate in the entity-position system and therefore do not block
    movement or trigger collision events — entities walk freely through them.

    Parameters
    ----------
    x : int
        Map x coordinate.
    y : int
        Map y coordinate.
    char : int
        Unicode codepoint rendered as the object's glyph.
    fg_color : tuple[int, int, int]
        RGB foreground color of the glyph.
    type_id : str
        Registry key from ``STATIC_OBJECT_REGISTRY`` (empty string if unknown).
    components : dict[str, Component]
        Optional cross-cutting capabilities (e.g. ``"light_emitter"``).
    """

    x: int
    y: int
    char: int
    fg_color: tuple[int, int, int]
    type_id: str = field(default="")
    components: dict[str, Component] = field(default_factory=dict)


@dataclass(frozen=True)
class StaticObjectType:
    """Database template for a placeable static world object.

    Analogous to :class:`~faraway_realms.entities.creature_type.CreatureType` for
    entities.  Stored in the game database and queried by label to populate
    maps with appropriate decorations.

    Parameters
    ----------
    name : str
        Unique identifier used as the database primary key.
    char : int
        Unicode codepoint rendered as the object's glyph.
    fg_color : tuple[int, int, int]
        RGB foreground color of the glyph.
    components : dict[str, Component]
        Optional cross-cutting capabilities (e.g. ``"light_emitter"``).
    labels : frozenset[str]
        Free-form tags used to filter types during map population.
    """

    name: str
    char: int
    fg_color: tuple[int, int, int]
    components: dict[str, Component] = field(
        default_factory=dict, hash=False, compare=False
    )
    labels: frozenset[str] = field(default_factory=frozenset)
    display_name: str = ""
    description: str | None = None

    def to_static_object(self, x: int, y: int) -> StaticObject:
        """Instantiate a :class:`StaticObject` at the given map position.

        Parameters
        ----------
        x : int
            Map x coordinate.
        y : int
            Map y coordinate.

        Returns
        -------
        StaticObject
            A new instance positioned at *(x, y)*.
        """
        return StaticObject(
            x=x,
            y=y,
            char=self.char,
            fg_color=self.fg_color,
            type_id=self.name,
            components=dict(self.components),
        )


STATIC_OBJECT_REGISTRY: dict[str, StaticObjectType] = {}
