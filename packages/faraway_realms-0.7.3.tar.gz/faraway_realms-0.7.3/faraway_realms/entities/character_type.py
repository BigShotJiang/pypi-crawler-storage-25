"""Character type registry — player archetype templates."""

from faraway_realms.entities.creature_type import CreatureType

CHARACTER_REGISTRY: dict[str, CreatureType] = {}
