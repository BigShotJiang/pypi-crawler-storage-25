"""Game entities — anything that occupies a tile and has a display glyph."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from faraway_realms.entities.components import CombatProfile, Component

if TYPE_CHECKING:
    from faraway_realms.ai.behaviour import Behaviour
    from faraway_realms.combat.abilities import Ability
    from faraway_realms.combat.stats import Stat
    from faraway_realms.combat.status import StatusInstance


@dataclass
class GameEntity(ABC):
    """Abstract base for anything that occupies a tile and has a glyph.

    Parameters
    ----------
    entity_id : int
        Unique integer identifier.
    char : int
        Unicode codepoint to display (use ``ord("@")`` for ASCII glyphs or
        ``URIZEN_BASE + N`` for Urizen sprites).
    fg_color : tuple[int, int, int]
        Foreground color for the glyph.
    faction : str
        Faction this entity belongs to. Hostility between factions is
        determined by :class:`~faraway_realms.world.factions.FactionRelations`.
        Defaults to ``"neutral"``.
    """

    entity_id: int
    char: int
    fg_color: tuple[int, int, int]
    faction: str = field(default="neutral", kw_only=True)
    stats: dict[str, Stat] = field(default_factory=dict, kw_only=True)
    target_id: int | None = field(default=None, kw_only=True)
    abilities: dict[str, "Ability"] = field(default_factory=dict, kw_only=True)
    status_effects: list[StatusInstance] = field(default_factory=list, kw_only=True)
    components: dict[str, Component] = field(default_factory=dict, kw_only=True)
    last_hit_tick: int = field(default=0, kw_only=True)
    last_hit_by: int | None = field(default=None, kw_only=True)
    type_id: str = field(default="", kw_only=True)

    @property
    @abstractmethod
    def display_name(self) -> str:
        """Human-readable name for this entity."""


@dataclass
class Entity(GameEntity):
    """Unified entity class for players and NPCs.

    The distinction between player and NPC lives entirely in the presence or
    absence of a ``BehaviourComponent``:

    - **NPC**: ``components["behaviour"] = BehaviourComponent(behaviour)``
    - **Player**: no ``BehaviourComponent``; commands arrive from the network.

    Parameters
    ----------
    name : str
        Display name.
    move_every : int
        Move once every this many ticks; ``1`` = no throttle (player default).
    """

    name: str
    move_every: int = 1

    @property
    def display_name(self) -> str:
        """Return the entity's name.

        Returns
        -------
        str
            The entity name.
        """
        return self.name


@dataclass
class CharacterEntity(Entity):
    """Backward-compatible entity subclass with flat combat fields.

    New code should use :class:`Entity` with a ``CombatProfile`` component.
    This subclass exists so existing test and construction code that passes
    ``attack_every``, ``armor_type`` etc. to the constructor continues to work
    without changes.
    """

    attack_every: int = field(default=5, kw_only=True)
    armor_type: str = field(default="none", kw_only=True)
    damage_type: str = field(default="bludgeoning", kw_only=True)
    blood_color: tuple[int, int, int] | None = field(default=(180, 0, 0), kw_only=True)
    death_stat: str = field(default="health", kw_only=True)


@dataclass
class NonPlayerEntity(Entity):
    """Backward-compatible NPC entity with flat combat fields and behaviour.

    New code should use :class:`Entity` with ``CombatProfile`` and
    ``BehaviourComponent`` components.  This subclass auto-converts the
    ``behaviour`` constructor argument to a ``BehaviourComponent`` so that
    :class:`~faraway_realms.systems.npc_intent.NpcIntentSystem` can discover it
    via the standard component lookup.
    """

    behaviour: Behaviour | None = field(default=None, kw_only=True)
    attack_every: int = field(default=5, kw_only=True)
    armor_type: str = field(default="none", kw_only=True)
    damage_type: str = field(default="bludgeoning", kw_only=True)
    blood_color: tuple[int, int, int] | None = field(default=(180, 0, 0), kw_only=True)
    death_stat: str = field(default="health", kw_only=True)

    def __post_init__(self) -> None:
        """Convert the legacy ``behaviour`` field to a ``BehaviourComponent``."""
        from faraway_realms.entities.components import BehaviourComponent

        if self.behaviour is not None and "behaviour" not in self.components:
            self.components["behaviour"] = BehaviourComponent(self.behaviour)


@dataclass
class Player:
    """Holds player account metadata and a reference to their world entity.

    Parameters
    ----------
    username : str
        Player's account name.
    entity : Entity
        The in-world entity this player controls.
    explored : set[tuple[int, int]]
        Tiles this player has seen at least once; used for fog-of-war rendering.
        Per-player so that multiple players on the same map have independent vision.
    """

    username: str
    entity: Entity
    explored: set[tuple[int, int]] = field(default_factory=set)
    is_game_master: bool = False


def get_combat_profile(entity: GameEntity) -> CombatProfile:
    """Return the ``CombatProfile`` for an entity.

    Checks ``entity.components["combat_profile"]`` first.  Falls back to
    reading flat fields (``attack_every``, ``armor_type``, etc.) via
    ``getattr`` for backward-compatible :class:`CharacterEntity` and
    :class:`NonPlayerEntity` instances that still carry those as attributes.

    Parameters
    ----------
    entity : GameEntity
        Any entity.

    Returns
    -------
    CombatProfile
        The entity's combat profile, constructed from defaults if absent.
    """
    cp = entity.components.get("combat_profile")
    if isinstance(cp, CombatProfile):
        return cp
    return CombatProfile(
        attack_every=getattr(entity, "attack_every", 5),
        armor_type=getattr(entity, "armor_type", "none"),
        damage_type=getattr(entity, "damage_type", "bludgeoning"),
        death_stat=getattr(entity, "death_stat", "health"),
        blood_color=getattr(entity, "blood_color", (180, 0, 0)),
    )
