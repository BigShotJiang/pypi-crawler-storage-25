"""Inspect overlay: InspectOverlay (MapOverlay) and InspectPanel (Panel)."""

from __future__ import annotations

from typing import TYPE_CHECKING

import tcod.console
import tcod.event

from faraway_realms.describe import describe_position
from faraway_realms.types import Pos
from faraway_realms.ui.layout import (
    INSPECT_CURSOR_COLOR,
    MAP_HEIGHT,
    MAP_WIDTH,
    MAP_X,
    MAP_Y,
)
from faraway_realms.ui.overlays import MapOverlay
from faraway_realms.ui.panels import Panel

if TYPE_CHECKING:
    from faraway_realms.game_protocol import GameProtocol

_TEXT_COLOR = (220, 220, 220)
_DIM_COLOR = (120, 120, 120)
_HEADING_COLOR = (220, 220, 180)
_COORD_COLOR = (100, 160, 200)

_CURSOR_MOVES: dict[tcod.event.KeySym, Pos] = {
    tcod.event.KeySym(ord("h")): (-1, 0),
    tcod.event.KeySym(ord("j")): (0, 1),
    tcod.event.KeySym(ord("k")): (0, -1),
    tcod.event.KeySym(ord("l")): (1, 0),
    tcod.event.KeySym.LEFT: (-1, 0),
    tcod.event.KeySym.DOWN: (0, 1),
    tcod.event.KeySym.UP: (0, -1),
    tcod.event.KeySym.RIGHT: (1, 0),
}


class InspectPanel(Panel):
    """Details pane panel that shows a description of the inspect cursor position."""

    def __init__(self, game: GameProtocol, overlay: InspectOverlay) -> None:
        self._game = game
        self._overlay = overlay

    @property
    def title(self) -> str:
        """Panel header label."""
        return "Inspect"

    def render(self, console: tcod.console.Console, x: int, y: int, width: int) -> int:
        """Draw inspect description at the cursor position."""
        result = describe_position(
            self._game,
            self._overlay.cursor_x,
            self._overlay.cursor_y,
            width - 1,
        )
        row = y
        coord = f"({self._overlay.cursor_x}, {self._overlay.cursor_y})"
        console.print(x, row, coord[:width], fg=_COORD_COLOR)
        row += 2
        console.print(x, row, result.heading[: width - 1], fg=_HEADING_COLOR)
        row += 2
        for text, color in result.lines:
            if row >= console.height - 1:
                break
            console.print(x, row, text[:width], fg=color)
            row += 1
        return row - y


class InspectOverlay(MapOverlay):
    """Map overlay that draws a crosshair cursor and handles directional keys.

    Parameters
    ----------
    game : GameProtocol
        The game state (for map bounds).
    x : int
        Initial cursor x coordinate (world space).
    y : int
        Initial cursor y coordinate (world space).
    """

    def __init__(self, game: GameProtocol, x: int, y: int) -> None:
        self.cursor_x = x
        self.cursor_y = y
        self._game = game
        self._panel = InspectPanel(game, self)

    def render(self, console: tcod.console.Console, cam: tuple[int, int]) -> None:
        """Draw the ``+`` crosshair at the cursor's screen position."""
        cam_x, cam_y = cam
        sx, sy = self.cursor_x - cam_x, self.cursor_y - cam_y
        if not (0 <= sx < MAP_WIDTH and 0 <= sy < MAP_HEIGHT):
            return
        col, row = MAP_X + sx, MAP_Y + sy
        ch = int(console.rgb[row, col]["ch"])
        if not ch or ch == ord(" "):
            console.rgb[row, col]["ch"] = ord("+")
        console.rgb[row, col]["fg"] = INSPECT_CURSOR_COLOR

    def handle_key(self, event: tcod.event.KeyDown) -> bool:
        """Move the cursor or close the overlay; return ``False`` to close."""
        if event.sym == tcod.event.KeySym.ESCAPE:
            return False
        delta = _CURSOR_MOVES.get(event.sym)
        if delta is not None:
            gm = self._game.game_map
            self.cursor_x = max(0, min(self.cursor_x + delta[0], gm.width - 1))
            self.cursor_y = max(0, min(self.cursor_y + delta[1], gm.height - 1))
        return True

    @property
    def side_panel(self) -> InspectPanel:
        """Return the InspectPanel for the details pane."""
        return self._panel
