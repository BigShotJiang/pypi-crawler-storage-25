"""Mode indicator bar — one row at the bottom of the left pane, vim-style."""

from __future__ import annotations

import tcod.console

from faraway_realms.types import Color
from faraway_realms.ui.layout import CHAT_WIDTH, MODE_BAR_Y

_INSPECT_COLOR: Color = (0, 200, 220)
_DIRECTION_COLOR: Color = (100, 220, 100)
_CHAT_COLOR: Color = (180, 180, 100)


class ModeBar:
    """Renders a one-row mode indicator below the chat input."""

    def render(
        self,
        console: tcod.console.Console,
        overlay_label: str | None,
        chat_focused: bool,
    ) -> None:
        """Draw the mode indicator row; silent in normal (non-modal) mode."""
        if overlay_label is not None:
            text = overlay_label
            color = _DIRECTION_COLOR if "DIRECTION" in overlay_label else _INSPECT_COLOR
        elif chat_focused:
            text = "-- CHAT --"
            color = _CHAT_COLOR
        else:
            return
        console.print(1, MODE_BAR_Y, text[: CHAT_WIDTH - 2], fg=color)
