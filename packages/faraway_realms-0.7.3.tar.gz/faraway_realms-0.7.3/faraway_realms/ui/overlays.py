"""Overlay system: Overlay ABC and built-in HelpOverlay."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Callable
from dataclasses import dataclass, field

import tcod.console
import tcod.event
from tcod.libtcodpy import BKGND_ALPHA, BKGND_SET

from faraway_realms.text_utils import wrap_text
from faraway_realms.types import Color
from faraway_realms.ui.layout import MAP_HEIGHT, MAP_WIDTH, MAP_X, MAP_Y
from faraway_realms.ui.scroll_view import ScrollView
from faraway_realms.world.commands import COMMAND_SPECS, CommandParser, CommandSpec

# ------------------------------------------------------------------
# Help content colours
# ------------------------------------------------------------------

_HEADER_COLOR: Color = (140, 140, 80)
_TEXT_COLOR: Color = (220, 220, 220)
_KEY_COLOR: Color = (100, 200, 255)
_CMD_COLOR: Color = (100, 255, 160)
_DIM_COLOR: Color = (120, 120, 120)

# Static key-binding section shown at the top of general help.
_KEY_BINDING_LINES: list[tuple[str, Color]] = [
    ("  Movement & Combat", _HEADER_COLOR),
    ("", _TEXT_COLOR),
    ("  hjkl / arrows   Move", _TEXT_COLOR),
    ("  f                Attack target", _TEXT_COLOR),
    ("  t / Tab          Cycle targets", _TEXT_COLOR),
    ("", _TEXT_COLOR),
    ("  Abilities", _HEADER_COLOR),
    ("", _TEXT_COLOR),
    ("  e   Kick         Knockback + brief root", _TEXT_COLOR),
    ("  q   Backstep     Disengage 2 tiles back", _TEXT_COLOR),
    ("  r   Haste        +50% attack speed (3s)", _TEXT_COLOR),
    ("  g   Parry        Stun target (0.5s)", _TEXT_COLOR),
    ("  c   Second Wind  Heal 30 HP over 3s", _TEXT_COLOR),
    ("", _TEXT_COLOR),
    ("  Interface", _HEADER_COLOR),
    ("", _TEXT_COLOR),
    ("  / or Enter       Open chat", _TEXT_COLOR),
    ("  { / }            Scroll chat history", _TEXT_COLOR),
    ("  i                Inspect mode (hjkl to move)", _TEXT_COLOR),
    ("  o                Open/close door (pick direction)", _TEXT_COLOR),
    ("  ?                This help screen", _TEXT_COLOR),
    ("  Esc              Close overlay / unfocus", _TEXT_COLOR),
    ("", _TEXT_COLOR),
]

# Special entry for /help itself (not in CommandType).
_HELP_SPEC_LINES: list[tuple[str, Color]] = [
    ("  /help [command]", _HEADER_COLOR),
    ("", _TEXT_COLOR),
    ("  Show general help, or detailed help for a specific command.", _TEXT_COLOR),
]


_OVERLAY_W = MAP_WIDTH
_OVERLAY_H = MAP_HEIGHT + 2  # covers status bar row too
_SCROLL_H = _OVERLAY_H - 4  # inside border + footer
_SCROLL_W = _OVERLAY_W - 2  # inside border

_OVERLAY_BG: Color = (10, 12, 20)  # dark blueish fill
_OVERLAY_ALPHA: int = 210  # opacity 0–255 (255 = opaque); ≈ 0.82 × 255


# ------------------------------------------------------------------
# Dynamic help generation from CommandSpec
# ------------------------------------------------------------------


def _wrap_desc(
    text: str, indent: str, color: Color, width: int = _SCROLL_W - 2
) -> list[tuple[str, Color]]:
    """Wrap *text* at *width* columns, preserving *indent* on each line."""
    return wrap_text(text, color, width, indent)


def _format_usage(spec: CommandSpec) -> str:
    parts: list[str] = [spec.verb] if spec.verb else []
    for p in spec.params:
        parts.append(f"[{p.name}]" if not p.required else f"<{p.name}>")
    return " ".join(parts)


def _build_general_lines() -> list[tuple[str, Color]]:
    lines: list[tuple[str, Color]] = list(_KEY_BINDING_LINES)
    lines.append(("  Commands", _HEADER_COLOR))
    lines.append(("", _TEXT_COLOR))
    for ct, spec in COMMAND_SPECS.items():  # noqa: B007
        if not spec.user_facing or not spec.verb:
            continue
        lines.append((f"  /{_format_usage(spec)}", _CMD_COLOR))
        lines.extend(_wrap_desc(spec.description, "    ", _TEXT_COLOR))
    lines.append(("", _TEXT_COLOR))
    lines.append(("  Type /help <command> for details.", _DIM_COLOR))
    return lines


def _param_lines(spec: CommandSpec) -> list[tuple[str, Color]]:
    lines: list[tuple[str, Color]] = [
        ("", _TEXT_COLOR),
        ("  Parameters", _HEADER_COLOR),
    ]
    for p in spec.params:
        req = "" if p.required else "  (optional)"
        lines.append((f"    <{p.name}>{req}", _KEY_COLOR))
        lines.extend(_wrap_desc(p.description, "      ", _TEXT_COLOR))
        if p.choices:
            lines.extend(
                _wrap_desc(f"Choices: {', '.join(p.choices)}", "      ", _DIM_COLOR)
            )
    return lines


def _build_command_lines(verb: str) -> list[tuple[str, Color]]:
    if verb == "help":
        return list(_HELP_SPEC_LINES)
    ct = CommandParser._VERB_TYPES.get(verb)  # noqa: SLF001
    spec = COMMAND_SPECS.get(ct) if ct is not None else None
    if spec is None or not spec.verb:
        return [(f"  Unknown command: {verb}", _TEXT_COLOR)]
    lines: list[tuple[str, Color]] = [
        (f"  /{_format_usage(spec)}", _HEADER_COLOR),
        ("", _TEXT_COLOR),
        *_wrap_desc(spec.description, "  ", _TEXT_COLOR),
    ]
    if spec.params:
        lines.extend(_param_lines(spec))
    return lines


# ------------------------------------------------------------------
# Overlay ABC
# ------------------------------------------------------------------


class Overlay(ABC):
    """Abstract base for full-screen map-pane overlays (help, menus, pause).

    Renders *over* the entire map area and captures all key input while active.
    """

    @abstractmethod
    def render(self, console: tcod.console.Console) -> None:
        """Draw the overlay into *console*."""

    def handle_key(self, event: tcod.event.KeyDown) -> bool:
        """Handle a key event; return ``False`` to close the overlay."""
        return event.sym != tcod.event.KeySym.ESCAPE


class MapOverlay(ABC):
    """Abstract base for overlays that render *on* the map and handle directional input.

    Unlike :class:`Overlay`, a ``MapOverlay`` does not cover the full screen —
    it draws glyphs onto map tiles (crosshair, reticle, arrow) and may
    optionally replace the details pane.  Suitable for inspect mode, direction
    pickers, and spell-aiming selectors.
    """

    @abstractmethod
    def render(self, console: tcod.console.Console, cam: tuple[int, int]) -> None:
        """Draw the overlay glyph(s) onto map tiles.

        Called after the map and entities are rendered, before screen-space
        post-processing effects.

        Parameters
        ----------
        console : tcod.console.Console
            Target console.
        cam : tuple[int, int]
            Camera origin ``(cam_x, cam_y)`` for world-to-screen conversion.
        """

    def handle_key(self, event: tcod.event.KeyDown) -> bool:
        """Handle a key event; return ``False`` to close the overlay."""
        return event.sym != tcod.event.KeySym.ESCAPE

    @property
    def mode_label(self) -> str | None:
        """Short mode string for the mode bar, e.g. ``"-- INSPECT --"``."""
        return None

    @property
    def side_panel(self) -> object | None:
        """Return a :class:`Panel` to substitute in the details pane, or ``None``.

        When non-``None``, the returned panel replaces the normal panel list
        for as long as this overlay is active.
        """
        return None


# ------------------------------------------------------------------
# DirectionOverlay
# ------------------------------------------------------------------

_DIRECTION_MAP: dict[tcod.event.KeySym, str] = {
    tcod.event.KeySym(ord("h")): "left",
    tcod.event.KeySym(ord("l")): "right",
    tcod.event.KeySym(ord("k")): "up",
    tcod.event.KeySym(ord("j")): "down",
    tcod.event.KeySym.LEFT: "left",
    tcod.event.KeySym.RIGHT: "right",
    tcod.event.KeySym.UP: "up",
    tcod.event.KeySym.DOWN: "down",
}


class DirectionOverlay(MapOverlay):
    """Prompts the player to pick a direction, then invokes *callback*.

    The overlay is closed immediately after a direction key is pressed or
    ESC is pressed (cancelling the action).

    Parameters
    ----------
    callback : Callable[[str], None]
        Called with the direction string (``"left"`` / ``"right"`` / ``"up"`` /
        ``"down"``) when the player makes a choice.
    """

    def __init__(self, callback: Callable[[str], None]) -> None:
        self._callback = callback

    def render(self, console: tcod.console.Console, cam: tuple[int, int]) -> None:
        """No visual needed — the mode bar shows ``-- DIRECTION --``."""

    def handle_key(self, event: tcod.event.KeyDown) -> bool:
        """Route arrow/hjkl to the callback; ESC cancels."""
        direction = _DIRECTION_MAP.get(event.sym)
        if direction is not None:
            self._callback(direction)
            return False
        return event.sym != tcod.event.KeySym.ESCAPE

    @property
    def mode_label(self) -> str | None:
        """Return the mode bar label for direction-picking mode."""
        return "-- DIRECTION --"


# ------------------------------------------------------------------
# HelpOverlay
# ------------------------------------------------------------------

_SCROLL_KEYS: dict[tcod.event.KeySym, int] = {
    tcod.event.KeySym.UP: -1,
    tcod.event.KeySym.DOWN: 1,
    tcod.event.KeySym.PAGEUP: -_SCROLL_H,
    tcod.event.KeySym.PAGEDOWN: _SCROLL_H,
}


@dataclass
class HelpOverlay(Overlay):
    """Help screen rendered over the map pane.

    Parameters
    ----------
    topic : str | None
        Command name for per-command detail (e.g. ``"move"``).
        ``None`` shows general key-binding and command overview.
    transparent : bool
        When ``True`` (default) the overlay background is alpha-blended
        with whatever is already in the console (map tiles, status bar),
        giving a frosted-glass effect.  ``False`` uses a solid fill.
    """

    topic: str | None = None
    transparent: bool = True
    _scroll: ScrollView = field(init=False, repr=False)

    def __post_init__(self) -> None:  # noqa: D105
        if self.topic:
            lines = _build_command_lines(self.topic)
        else:
            lines = _build_general_lines()
        self._scroll = ScrollView(lines=lines, height=_SCROLL_H, width=_SCROLL_W)

    def render(self, console: tcod.console.Console) -> None:
        """Draw the help overlay into *console*."""
        ox, oy = MAP_X, MAP_Y
        blend = BKGND_ALPHA(_OVERLAY_ALPHA) if self.transparent else BKGND_SET
        console.draw_frame(
            ox,
            oy,
            _OVERLAY_W,
            _OVERLAY_H,
            fg=_HEADER_COLOR,
            bg=_OVERLAY_BG,
            bg_blend=blend,
            clear=True,
        )
        title = f" HELP \u2014 /{self.topic} " if self.topic else " HELP "
        console.print(ox + 2, oy, title, fg=_HEADER_COLOR)
        self._scroll.render(console, ox + 1, oy + 1)
        footer = "\u2191\u2193 scroll \u00b7 Esc close"
        console.print(ox + 2, oy + _OVERLAY_H - 1, footer, fg=_DIM_COLOR)

    def handle_key(self, event: tcod.event.KeyDown) -> bool:
        """Route scroll keys to the ScrollView; ESC closes the overlay."""
        if event.sym == tcod.event.KeySym.ESCAPE:
            return False
        delta = _SCROLL_KEYS.get(event.sym)
        if delta is not None:
            if delta < 0:
                self._scroll.scroll_up(-delta)
            else:
                self._scroll.scroll_down(delta)
        return True
