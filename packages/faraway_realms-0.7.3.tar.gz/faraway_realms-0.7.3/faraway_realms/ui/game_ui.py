"""GameUI — thin coordinator that owns MapView, ChatView, StatusBar, and overlays."""

from __future__ import annotations

import os
import time
from pathlib import Path
from typing import TYPE_CHECKING, Callable

import tcod.console
import tcod.context
import tcod.event
import tcod.tileset

from faraway_realms.ai import fov as _fov
from faraway_realms.effects.fog import render_fog
from faraway_realms.effects.light import LightMap, animate_light_sources
from faraway_realms.settings import DisplaySettings, load_display_settings
from faraway_realms.types import Pos
from faraway_realms.ui.ability_bar import AbilityBar
from faraway_realms.ui.animation import AnimationController
from faraway_realms.ui.chat_view import ChatView
from faraway_realms.ui.effects import (
    ScreenFlash,
)
from faraway_realms.ui.inspect import InspectOverlay
from faraway_realms.ui.layout import (
    _FRAME_DURATION,
    _INPUT_BG,
    BINDINGS,
    CHAT_HEIGHT,
    CHAT_WIDTH,
    CHAT_X,
    CHAT_Y,
    CONSOLE_HEIGHT,
    CONSOLE_WIDTH,
    DETAILS_WIDTH,
    DETAILS_X,
    DETAILS_Y,
    INPUT_Y,
    MAP_HEIGHT,
    MAP_WIDTH,
    MAP_X,
    MAP_Y,
    TILE_PX,
    TILESET_CHARMAP,
    TILESET_ROWS,
)
from faraway_realms.ui.map_view import MapView
from faraway_realms.ui.mode_bar import ModeBar
from faraway_realms.ui.overlays import (
    DirectionOverlay,
    HelpOverlay,
    MapOverlay,
    Overlay,
)
from faraway_realms.ui.panels import Panel
from faraway_realms.ui.status_bar import NameBar, StatusBar
from faraway_realms.world.commands import CommandParser

# libtcod 2.x uses SDL3 where SDL_WINDOW_FULLSCREEN gives borderless desktop
# fullscreen by default.  0x1001 (old SDL_WINDOW_FULLSCREEN_DESKTOP) is now
# SDL_WINDOW_FULLSCREEN | SDL_WINDOW_MODAL and crashes on macOS.
#
# Table mapping DisplaySettings bool attributes → SDL window flag values.
_SDL_FLAG_MAP: tuple[tuple[str, int], ...] = (
    ("fullscreen", tcod.context.SDL_WINDOW_FULLSCREEN),
    ("allow_highdpi", tcod.context.SDL_WINDOW_ALLOW_HIGHDPI),
    ("borderless", tcod.context.SDL_WINDOW_BORDERLESS),
    ("maximized", tcod.context.SDL_WINDOW_MAXIMIZED),
    ("resizable", tcod.context.SDL_WINDOW_RESIZABLE),
)

# Maps scale_quality setting strings to SDL hint values.
_SCALE_QUALITY: dict[str, str] = {"nearest": "0", "linear": "1", "best": "2"}


if TYPE_CHECKING:
    from faraway_realms.entities.entity import Player
    from faraway_realms.game_protocol import GameProtocol


def _sdl_flags(settings: DisplaySettings) -> int:
    """OR together all SDL window flags enabled by *settings*."""
    return sum(flag for attr, flag in _SDL_FLAG_MAP if getattr(settings, attr))


def _pixel_size(settings: DisplaySettings) -> dict[str, int]:
    """Return explicit window pixel dimensions when integer scaling is active."""
    if settings.fullscreen or settings.integer_scale <= 1:
        return {}
    return {
        "width": CONSOLE_WIDTH * TILE_PX * settings.integer_scale,
        "height": CONSOLE_HEIGHT * TILE_PX * settings.integer_scale,
    }


def _context_kwargs(settings: DisplaySettings) -> dict:
    """Build keyword arguments for tcod.context.new from display settings."""
    flags = _sdl_flags(settings)
    _wpos = [("x", settings.window_x), ("y", settings.window_y)]
    pos = {k: v for k, v in _wpos if v is not None}
    kwargs: dict = {"vsync": settings.vsync, **pos, **_pixel_size(settings)}
    if flags:
        kwargs["sdl_window_flags"] = flags
    return kwargs


# ------------------------------------------------------------------
# Client-side slash command registry
# ------------------------------------------------------------------


def _cmd_help(ui: GameUI, parts: list[str]) -> None:
    topic = parts[1].lower() if len(parts) > 1 else None
    ui._overlay = HelpOverlay(topic=topic)  # noqa: SLF001


def _cmd_inspect(ui: GameUI, parts: list[str]) -> None:
    arg = parts[1] if len(parts) > 1 else "@self"
    ui._handle_inspect_command(arg)  # noqa: SLF001


_CLIENT_COMMANDS: dict[str, Callable[[GameUI, list[str]], None]] = {
    "help": _cmd_help,
    "inspect": _cmd_inspect,
}


class GameUI:
    """Manages the TCOD window and three-pane layout.

    Parameters
    ----------
    game : Game
        The game state to render.
    tileset_path : str | Path
        Path to the unified 12×12 tilesheet PNG (CP437 + Urizen sprites).
    viewing_player : Player
        The player this UI instance belongs to.
    panels : list[Panel] | None
        Optional list of detail-pane panels to display.
    """

    def __init__(
        self,
        game: GameProtocol,
        tileset_path: str | Path,
        viewing_player: Player,
        panels: list[Panel] | None = None,
    ) -> None:
        self._game = game
        self._tileset_path = Path(tileset_path)
        self._viewing_player = viewing_player
        self._parser = CommandParser()
        self._panels: list[Panel] = list(panels) if panels else []
        self._panel_idx: int = 0
        self._overlay: Overlay | None = None
        self._map_overlay: MapOverlay | None = None
        self._map_view = MapView(game=game, viewing_player=viewing_player)
        self._chat = ChatView(game=game)
        self._status_bar = StatusBar(game=game, viewing_player=viewing_player)
        self._name_bar = NameBar(game=game, viewing_player=viewing_player)
        self._ability_bar = AbilityBar(game=game, viewing_player=viewing_player)
        self._mode_bar = ModeBar()
        self._fog_params = game.fog_params
        self._light_map = LightMap(
            game.game_map.width, game.game_map.height, ambient=game.ambient
        )
        self._anim = AnimationController(game=game, viewing_player=viewing_player)
        self._ctx: tcod.context.Context  # set in run()

    # ------------------------------------------------------------------
    # Compatibility shims — kept for tests
    # ------------------------------------------------------------------

    @property
    def _damage_flash(self) -> ScreenFlash:
        return self._anim._damage_flash  # noqa: SLF001

    @property
    def _crit_flash(self) -> ScreenFlash:
        return self._anim._crit_flash  # noqa: SLF001

    # Inspect-mode shims for backwards-compatible test access
    @property
    def _inspect(self) -> InspectOverlay | None:
        if isinstance(self._map_overlay, InspectOverlay):
            return self._map_overlay
        return None

    @property
    def _inspect_panel(self) -> object | None:
        if isinstance(self._map_overlay, InspectOverlay):
            return self._map_overlay.side_panel
        return None

    def _maybe_tick(self) -> None:
        """Call tick() on the game if it supports server-side ticking."""
        if hasattr(self._game, "tick"):
            self._game.tick()  # type: ignore[union-attr]

    def run(self) -> None:
        """Open the window and enter the render/event loop."""
        settings = load_display_settings()
        # SDL reads this hint before creating the renderer; must be set early.
        os.environ["SDL_RENDER_SCALE_QUALITY"] = _SCALE_QUALITY.get(
            settings.scale_quality, "0"
        )
        tileset = tcod.tileset.load_tilesheet(
            self._tileset_path, 16, TILESET_ROWS, TILESET_CHARMAP
        )
        console = tcod.console.Console(CONSOLE_WIDTH, CONSOLE_HEIGHT, order="C")
        with tcod.context.new(
            console=console,
            tileset=tileset,
            title="Faraway Realms",
            **_context_kwargs(settings),
        ) as ctx:
            self._ctx = ctx
            last_tick = time.monotonic()
            tick_interval = 1.0 / self._game.tick_rate

            while True:
                now = time.monotonic()
                if now - last_tick >= tick_interval:
                    self._maybe_tick()
                    last_tick = now

                if not self._handle_events(ctx):
                    break

                self._render_frame(console)
                ctx.present(console)

                elapsed = time.monotonic() - now
                time.sleep(max(0.0, _FRAME_DURATION - elapsed))

    # ------------------------------------------------------------------
    # Rendering
    # ------------------------------------------------------------------

    def _sync_viewing_player(self) -> None:
        """Copy mutable snapshot fields back to the stub entity each frame."""
        pid = self._viewing_player.entity.entity_id
        snap_e = self._game.entity(pid)
        if snap_e is not None:
            self._viewing_player.entity.target_id = snap_e.target_id

    def _render_frame(self, console: tcod.console.Console) -> None:
        self._sync_viewing_player()
        console.clear()
        self._render_borders(console)  # first — draw_frame clears interior cells
        cam = self._map_view.camera_origin()
        visible = self._map_view.compute_fov()
        self._light_map.compute(
            animate_light_sources(self._game.light_sources(), time.time()),
            _fov.build_transparency(self._game.game_map),
        )
        self._map_view._color_overrides = self._anim.hit_flash_overrides  # noqa: SLF001
        self._map_view.render(console, cam, visible, self._light_map)
        render_fog(
            console,
            cam,
            MAP_X,
            MAP_Y,
            MAP_WIDTH,
            MAP_HEIGHT,
            time.time(),
            self._fog_params,
        )
        self._anim.render(console, cam, visible, self._light_map)
        if self._map_overlay is not None:
            self._map_overlay.render(console, cam)
        self._render_details(console)
        self._chat.render(console)
        self._status_bar.render(console)
        self._name_bar.render(console)
        self._ability_bar.render(console)
        overlay_label = (
            self._map_overlay.mode_label if self._map_overlay is not None else None
        )
        self._mode_bar.render(console, overlay_label, self._chat.focused)
        if self._overlay is not None:
            self._overlay.render(console)

    def _render_borders(self, console: tcod.console.Console) -> None:
        # Vertical divider between map/chat and details
        console.draw_frame(DETAILS_X - 1, DETAILS_Y, DETAILS_WIDTH + 1, CONSOLE_HEIGHT)
        # Horizontal divider between map and chat
        console.draw_frame(MAP_X, CHAT_Y - 1, MAP_WIDTH, CONSOLE_HEIGHT - CHAT_Y + 1)

    def _render_details(self, console: tcod.console.Console) -> None:
        x = DETAILS_X + 1
        width = DETAILS_WIDTH - 2
        if self._try_render_overlay_panel(console, x, width):
            return
        if not self._panels:
            return
        panel = self._panels[self._panel_idx]
        self._render_panel_header(console, x, 1, width, panel.title)
        panel.render(console, x, 3, width)
        if len(self._panels) > 1:
            hint = "(]) next panel"
            console.print(x, CONSOLE_HEIGHT - 2, hint[:width], fg=(100, 100, 100))

    def _try_render_overlay_panel(
        self, console: tcod.console.Console, x: int, width: int
    ) -> bool:
        if self._map_overlay is None:
            return False
        raw_panel = self._map_overlay.side_panel
        if not isinstance(raw_panel, Panel):
            return False
        self._render_panel_header(console, x, 1, width, raw_panel.title)
        raw_panel.render(console, x, 3, width)
        return True

    def _render_panel_header(
        self,
        console: tcod.console.Console,
        x: int,
        y: int,
        width: int,
        title: str,
    ) -> None:
        w = width - 1
        label = f"\u2500 {title} "
        padding = "\u2500" * max(0, w - len(label))
        console.print(x, y, (label + padding)[:w], fg=(140, 140, 80))

    # ------------------------------------------------------------------
    # Compatibility shims — delegate to sub-components
    # Used by tests that access private attributes directly.
    # ------------------------------------------------------------------

    def _render_chat(self, console: tcod.console.Console) -> None:
        history = self._game.get_chat_history(last_n=CHAT_HEIGHT)
        for i, message in enumerate(history):
            console.print(
                CHAT_X + 1, CHAT_Y + i, message.text[: CHAT_WIDTH - 2], fg=message.color
            )

    def _render_input_line(self, console: tcod.console.Console) -> None:
        console.rgb[INPUT_Y, CHAT_X + 1 : CHAT_X + CHAT_WIDTH - 1]["bg"] = _INPUT_BG
        prompt = "> " + self._chat._buffer  # noqa: SLF001
        if self._chat._focused:  # noqa: SLF001
            prompt += "_"
        console.print(CHAT_X + 1, INPUT_Y, prompt[: CHAT_WIDTH - 2], fg=(255, 255, 255))

    @property
    def _input_buffer(self) -> str:  # noqa: D401
        return self._chat._buffer  # noqa: SLF001

    @_input_buffer.setter
    def _input_buffer(self, value: str) -> None:
        self._chat._buffer = value  # noqa: SLF001

    @property
    def _chat_focused(self) -> bool:
        return self._chat._focused  # noqa: SLF001

    @_chat_focused.setter
    def _chat_focused(self, value: bool) -> None:
        self._chat._focused = value  # noqa: SLF001

    @property
    def _command_history(self) -> list[str]:
        return self._chat._history  # noqa: SLF001

    @_command_history.setter
    def _command_history(self, value: list[str]) -> None:
        self._chat._history = value  # noqa: SLF001

    @property
    def _history_idx(self) -> int:
        return self._chat._history_idx  # noqa: SLF001

    @_history_idx.setter
    def _history_idx(self, value: int) -> None:
        self._chat._history_idx = value  # noqa: SLF001

    @property
    def _history_buffer(self) -> str:
        return self._chat._history_buffer  # noqa: SLF001

    @_history_buffer.setter
    def _history_buffer(self, value: str) -> None:
        self._chat._history_buffer = value  # noqa: SLF001

    def _submit_input(self) -> None:
        text = self._chat._buffer.strip()  # noqa: SLF001
        self._game.add_chat_message(text)
        if text.startswith("/"):
            parts = text.lstrip("/").split()
            verb = parts[0].lower() if parts else ""
            if verb != "help":
                self._game.enqueue_command(self._parser.parse(text))
            self._chat.record_history(text)
        self._chat._buffer = ""  # noqa: SLF001
        self._chat._history_idx = -1  # noqa: SLF001
        self._chat._history_buffer = ""  # noqa: SLF001

    def _handle_text_input(self, event: tcod.event.TextInput) -> None:
        self._chat.handle_text_input(event)

    def _history_older(self) -> None:
        self._chat._history_older()  # noqa: SLF001

    def _history_newer(self) -> None:
        self._chat._history_newer()  # noqa: SLF001

    def _handle_history_key(self, event: tcod.event.KeyDown) -> bool:
        return self._chat.handle_history_key(event)

    def _focus_chat(self, ctx: tcod.context.Context) -> None:
        self._chat.focus(ctx)

    def _unfocus_chat(self, ctx: tcod.context.Context) -> None:
        self._chat.unfocus(ctx)

    def _handle_backspace(self) -> None:
        if self._chat.focused:
            self._chat._buffer = self._chat._buffer[:-1]  # noqa: SLF001

    def _cycle_panel(self) -> None:
        if self._panels and not self._chat.focused:
            self._panel_idx = (self._panel_idx + 1) % len(self._panels)

    def _handle_escape(self, ctx: tcod.context.Context) -> bool:
        """Close inspect mode or unfocus chat; return True if something was closed."""
        if self._map_overlay is not None:
            self._map_overlay = None
            return True
        if self._chat.focused:
            self._chat.unfocus(ctx)
            return True
        return False

    def _enter_inspect(self, x: int, y: int) -> None:
        self._map_overlay = InspectOverlay(self._game, x, y)

    def _exit_inspect(self) -> None:
        self._map_overlay = None

    def _handle_inspect_key(self, event: tcod.event.KeyDown) -> None:
        """Route key events while inspect mode is active."""
        if self._map_overlay is None:
            return
        if not self._map_overlay.handle_key(event):
            self._map_overlay = None

    def _handle_bound_key(self, event: tcod.event.KeyDown) -> None:
        if self._chat.focused:
            return
        if self._handle_special_key(event):
            return
        raw = BINDINGS.get(event.sym)
        if raw is None:
            return
        self._game.enqueue_command(self._parser.parse(raw))

    def _player_position(self) -> Pos:
        eid = self._viewing_player.entity.entity_id
        try:
            return self._game.game_map.get_entity_position(eid)
        except KeyError:
            return (0, 0)

    def _handle_special_key(self, event: tcod.event.KeyDown) -> bool:
        """Handle ``?``, ``/``, ``i``, ``o`` quick-keys; return True if consumed."""
        if self._is_help_key(event):
            self._overlay = HelpOverlay()
            return True
        if event.sym == tcod.event.KeySym.SLASH:
            self._chat.focus(self._ctx)
            self._chat._buffer = "/"  # noqa: SLF001
            return True
        return self._handle_overlay_key(event)

    def _handle_overlay_key(self, event: tcod.event.KeyDown) -> bool:
        """Handle keys that open map overlays (``i``, ``o``)."""
        if self._map_overlay is not None:
            return False
        if event.sym == tcod.event.KeySym(ord("i")):
            px, py = self._player_position()
            self._enter_inspect(px, py)
            return True
        if event.sym == tcod.event.KeySym(ord("o")):
            self._map_overlay = DirectionOverlay(self._on_interact_direction)
            return True
        return False

    def _on_interact_direction(self, direction: str) -> None:
        """Send the /open command after DirectionOverlay resolves a direction."""
        self._dispatch_slash_command(f"/open {direction}")

    @staticmethod
    def _is_help_key(event: tcod.event.KeyDown) -> bool:
        """Return True for ``?`` (SDL may report it as QUESTION or SLASH+Shift)."""
        if event.sym == tcod.event.KeySym.QUESTION:
            return True
        return event.sym == tcod.event.KeySym.SLASH and bool(
            event.mod & tcod.event.Modifier.SHIFT
        )

    def _on_return(self, ctx: tcod.context.Context) -> None:
        if not self._chat.focused:
            self._chat.focus(ctx)
        elif self._chat.buffer.strip():
            self._submit_chat(ctx)
        else:
            self._chat.unfocus(ctx)

    # ------------------------------------------------------------------
    # Event handling
    # ------------------------------------------------------------------

    def _handle_events(self, ctx: tcod.context.Context) -> bool:
        for event in tcod.event.get():
            if not self._dispatch_event(event, ctx):
                return False
        return True

    def _dispatch_event(
        self, event: tcod.event.Event, ctx: tcod.context.Context
    ) -> bool:
        if isinstance(event, tcod.event.Quit):
            return False
        if isinstance(event, tcod.event.KeyDown):
            return self._handle_keydown(event, ctx)
        if isinstance(event, tcod.event.TextInput):
            self._chat.handle_text_input(event)
        return True

    def _handle_keydown(
        self, event: tcod.event.KeyDown, ctx: tcod.context.Context
    ) -> bool:
        if self._overlay is not None:
            return self._route_to_overlay(event)
        if event.sym == tcod.event.KeySym.ESCAPE:
            self._handle_escape(ctx)
            return True  # ESC never exits the game
        if self._map_overlay is not None:
            return self._route_to_map_overlay(event)
        self._handle_normal_key(event, ctx)
        return True

    def _route_to_map_overlay(self, event: tcod.event.KeyDown) -> bool:
        if not self._map_overlay.handle_key(event):  # type: ignore[union-attr]
            self._map_overlay = None
        return True

    def _handle_normal_key(
        self, event: tcod.event.KeyDown, ctx: tcod.context.Context
    ) -> None:
        if event.sym == tcod.event.KeySym.RETURN:
            self._on_return(ctx)
        else:
            self._handle_other_key(event)

    def _route_to_overlay(self, event: tcod.event.KeyDown) -> bool:
        if not self._overlay.handle_key(event):  # type: ignore[union-attr]
            self._overlay = None
        return True

    def _handle_other_key(self, event: tcod.event.KeyDown) -> None:
        if event.sym == tcod.event.KeySym.BACKSPACE:
            self._handle_backspace()
        elif event.sym == tcod.event.KeySym(ord("]")) and not (
            event.mod & tcod.event.Modifier.SHIFT
        ):
            self._cycle_panel()
        else:
            self._handle_navigation_key(event)

    def _handle_navigation_key(self, event: tcod.event.KeyDown) -> None:
        if not self._chat.handle_history_key(event):
            if not self._chat.handle_scroll_key(event):
                self._handle_bound_key(event)

    def _submit_chat(self, ctx: tcod.context.Context) -> None:
        text = self._chat.submit()
        if text is None:
            self._chat.unfocus(ctx)
            return
        self._game.add_chat_message(text)
        if text.startswith("/"):
            self._chat.record_history(text)
            self._dispatch_slash_command(text)
        self._chat.unfocus(ctx)

    def _dispatch_slash_command(self, text: str) -> None:
        parts = text.lstrip("/").split()
        verb = parts[0].lower() if parts else ""
        handler = _CLIENT_COMMANDS.get(verb)
        if handler is not None:
            handler(self, parts)
        else:
            self._game.enqueue_command(self._parser.parse(text))

    def _handle_inspect_command(self, arg: str) -> None:
        """Resolve /inspect argument and enter inspect mode."""
        if arg == "@self":
            self._inspect_self()
        elif arg == "@target":
            self._inspect_target()
        else:
            self._inspect_coords(arg)

    def _inspect_self(self) -> None:
        x, y = self._player_position()
        self._enter_inspect(x, y)

    def _inspect_target(self) -> None:
        target_id = self._viewing_player.entity.target_id
        if target_id is None:
            self._game.add_chat_message("No target selected.", color=(160, 160, 160))
            return
        try:
            x, y = self._game.game_map.get_entity_position(target_id)
            self._enter_inspect(x, y)
        except KeyError:
            self._game.add_chat_message("Target not found.", color=(160, 160, 160))

    def _inspect_coords(self, arg: str) -> None:
        for sep in (",", ":"):
            if sep in arg:
                parts = arg.split(sep, 1)
                try:
                    self._enter_inspect(int(parts[0].strip()), int(parts[1].strip()))
                    return
                except ValueError, IndexError:
                    pass
        self._game.add_chat_message(
            "Usage: /inspect @self | @target | x,y", color=(160, 160, 160)
        )
