"""AnimationController — owns all per-frame animation state for the map pane."""

from __future__ import annotations

from typing import TYPE_CHECKING

import tcod.console

from faraway_realms.effects.blood import blood_drop_positions
from faraway_realms.ui.effects import (
    BloodParticle,
    EntityHitFlash,
    MeleeAttackAnimation,
    ScreenFlash,
    TrailAnimation,
    _swing_char,
    _swing_tiles,
)

if TYPE_CHECKING:
    import numpy as np

    from faraway_realms.effects.light import LightMap
    from faraway_realms.entities.entity import GameEntity, Player
    from faraway_realms.game_protocol import GameProtocol
    from faraway_realms.types import Color, Pos
    from faraway_realms.world.map import Map


class AnimationController:
    """Owns all animation state and renders it each frame.

    Parameters
    ----------
    game : GameProtocol
        The game state to read animation events from.
    viewing_player : Player
        The player whose hit/crit sequences drive screen flashes.
    """

    def __init__(self, game: GameProtocol, viewing_player: Player) -> None:
        self._game = game
        self._viewing_player = viewing_player
        self._attack_anims: list[MeleeAttackAnimation] = []
        self._blood_particles: list[BloodParticle] = []
        self._trail_anims: list[TrailAnimation] = []
        self._hit_flashes: dict[int, EntityHitFlash] = {}
        self._prev_hit_ticks: dict[int, int] = {}
        self._last_anim_tick: int = -1
        self._last_trail_tick: int = -1
        self._damage_flash = ScreenFlash()
        self._crit_flash = ScreenFlash(color=(255, 210, 0), peak_alpha=200)
        self._last_hit_seq: int = game.get_hit_seq(viewing_player.entity.entity_id)
        self._last_crit_seq: int = game.get_crit_dealt_seq(
            viewing_player.entity.entity_id
        )

    @property
    def hit_flash_overrides(self) -> dict[int, Color]:
        """Entity id to current interpolated color for active hit flashes."""
        return {
            eid: f.current_color for eid, f in self._hit_flashes.items() if f.active
        }

    def render(
        self,
        console: tcod.console.Console,
        cam: Pos,
        visible: np.ndarray | None,
        light_map: LightMap,
    ) -> None:
        """Run all animation ticks and render; called once per frame."""
        self._tick_trail_anims(console, cam, visible)
        self._tick_attack_anims(console, cam)
        self._tick_blood_particles(console, cam, light_map)
        self._update_hit_flashes()
        self._tick_damage_flash(console)
        self._tick_crit_flash(console)

    def _tick_damage_flash(self, console: tcod.console.Console) -> None:
        eid = self._viewing_player.entity.entity_id
        hit_seq = self._game.get_hit_seq(eid)
        if hit_seq != self._last_hit_seq:
            self._last_hit_seq = hit_seq
            self._damage_flash.trigger()
        if self._damage_flash.active:
            self._damage_flash.render(console)

    def _tick_crit_flash(self, console: tcod.console.Console) -> None:
        eid = self._viewing_player.entity.entity_id
        crit_seq = self._game.get_crit_dealt_seq(eid)
        if crit_seq != self._last_crit_seq:
            self._last_crit_seq = crit_seq
            self._crit_flash.trigger()
        if self._crit_flash.active:
            self._crit_flash.render(console)

    def _tick_attack_anims(self, console: tcod.console.Console, cam: Pos) -> None:
        cur_tick = self._game.abs_tick
        if cur_tick != self._last_anim_tick:
            self._last_anim_tick = cur_tick
            self._spawn_anims_for_tick()
        self._attack_anims = [a for a in self._attack_anims if a.active]
        for anim in self._attack_anims:
            anim.render(console, cam)

    def _spawn_anims_for_tick(self) -> None:
        for from_pos, to_pos, color, blood_color in self._game.melee_anim_events():
            x0, y0 = from_pos
            x1, y1 = to_pos
            char = _swing_char(x1 - x0, y1 - y0)
            self._attack_anims.append(
                MeleeAttackAnimation(
                    tiles=_swing_tiles(x0, y0, x1, y1), char=char, color=color
                )
            )
            if blood_color is not None:
                self._spawn_blood_particles(x1, y1, x0, y0, blood_color)

    def _spawn_blood_particles(
        self,
        tx: int,
        ty: int,
        ax: int,
        ay: int,
        blood_color: tuple[int, int, int],
    ) -> None:
        game_map = self._game.game_map
        for lx, ly in blood_drop_positions(tx, ty, ax, ay):
            path = self._clip_path_to_walkable(game_map, _swing_tiles(tx, ty, lx, ly))
            if path:
                self._blood_particles.append(
                    BloodParticle(path=path, color=blood_color)
                )

    @staticmethod
    def _clip_path_to_walkable(game_map: Map, path: list) -> list:
        """Truncate *path* at the first non-walkable tile (inclusive)."""
        result = []
        for pos in path:
            result.append(pos)
            if not game_map.is_walkable(*pos):
                break
        return result

    def _tick_blood_particles(
        self,
        console: tcod.console.Console,
        cam: Pos,
        light_map: LightMap,
    ) -> None:
        self._blood_particles = [p for p in self._blood_particles if p.active]
        for particle in self._blood_particles:
            particle.render(console, cam, light_map)

    def _update_hit_flashes(self) -> None:
        for flash in self._hit_flashes.values():
            flash.advance()
        entities = self._game.all_npcs() + self._game.all_player_entities()
        for entity in entities:
            self._check_entity_hit(entity)

    def _check_entity_hit(self, entity: GameEntity) -> None:
        eid = entity.entity_id
        prev = self._prev_hit_ticks.get(eid, -1)
        if entity.last_hit_tick == prev or entity.last_hit_tick == 0:
            return
        self._prev_hit_ticks[eid] = entity.last_hit_tick
        if eid not in self._hit_flashes:
            self._hit_flashes[eid] = EntityHitFlash(original_color=entity.fg_color)
        flash = self._hit_flashes[eid]
        flash.original_color = entity.fg_color
        flash.trigger()

    def _tick_trail_anims(
        self,
        console: tcod.console.Console,
        cam: Pos,
        visible: np.ndarray | None,
    ) -> None:
        cur_tick = self._game.abs_tick
        if cur_tick != self._last_trail_tick:
            self._last_trail_tick = cur_tick
            self._spawn_trail_anims()
        self._trail_anims = [a for a in self._trail_anims if a.active]
        for anim in self._trail_anims:
            anim.render(console, cam, visible)

    def _spawn_trail_anims(self) -> None:
        for _eid, char, color, path in self._game.movement_trail_events():
            if path:
                self._trail_anims.append(
                    TrailAnimation(positions=list(path), char=char, color=color)
                )
