"""Parser for creature type YAML definitions."""

from faraway_realms.content_parsers import parse_color, parse_glyph
from faraway_realms.content_parsers.components import parse_components
from faraway_realms.entities.components import CombatProfile
from faraway_realms.entities.creature_type import CREATURE_REGISTRY, CreatureType


def parse_creatures(entries: dict) -> None:
    """Populate CREATURE_REGISTRY from a parsed YAML entries dict.

    Parameters
    ----------
    entries : dict
        Mapping of creature name → raw YAML dict, as produced by
        :class:`~faraway_realms.content.ContentLoader`.
    """
    for name, data in entries.items():
        CREATURE_REGISTRY[name] = _parse_creature(name, data)


def _parse_creature(name: str, data: dict) -> CreatureType:
    raw_color = data["fg_color"]
    stats_raw = data.get("stats") or {}
    components = data.get("components") or {}

    cp_raw = components.get("combat_profile") or {}
    beh_raw = components.get("behaviour")

    combat_profile = _parse_combat_profile(cp_raw)
    behaviour_kind, preferred_ability = _parse_behaviour(beh_raw)

    known = {"combat_profile", "behaviour"}
    extra = {k: v for k, v in components.items() if k not in known}
    creature_components = parse_components(extra)

    return CreatureType(
        name=name,
        char=parse_glyph(str(data["char"])),
        fg_color=parse_color(raw_color),
        faction=str(data.get("faction", "hostile")),
        stats={k: int(v) for k, v in stats_raw.items()},
        move_every=int(data.get("move_every", 3)),
        sight_range=int(data.get("sight_range", 8)),
        labels=frozenset(data.get("labels") or []),
        abilities=tuple(data.get("abilities") or []),
        combat_profile=combat_profile,
        behaviour_kind=behaviour_kind,
        preferred_ability=preferred_ability,
        display_name=data.get("display_name") or "",
        description=data.get("description") or None,
        components=creature_components,
    )


def _parse_combat_profile(cp_raw: dict) -> CombatProfile:
    blood_key_present = "blood_color" in cp_raw
    raw_blood = cp_raw.get("blood_color")
    if not blood_key_present:
        blood_color: tuple[int, int, int] | None = (180, 0, 0)
    elif raw_blood is None:
        blood_color = None
    else:
        blood_color = parse_color(raw_blood)
    return CombatProfile(
        attack_every=int(cp_raw.get("attack_every", 5)),
        armor_type=str(cp_raw.get("armor_type", "none")),
        damage_type=str(cp_raw.get("damage_type", "bludgeoning")),
        death_stat=str(cp_raw.get("death_stat", "health")),
        blood_color=blood_color,
    )


def _parse_behaviour(
    beh_raw: dict | None,
) -> tuple[str | None, str | None]:
    if beh_raw is None:
        return None, None
    kind = beh_raw.get("kind") or None
    preferred = beh_raw.get("preferred_ability") or None
    return (str(kind) if kind is not None else None), preferred
