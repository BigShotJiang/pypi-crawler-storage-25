"""Parser for faction relations YAML definitions."""

from faraway_realms.world.factions import FACTION_RELATIONS


def parse_factions(entries: dict) -> None:
    """Populate FACTION_RELATIONS from a parsed YAML entries dict.

    Parameters
    ----------
    entries : dict
        Mapping with a ``hostile_pairs`` key containing a list of
        ``[faction_a, faction_b]`` pairs, as produced by
        :class:`~faraway_realms.content.ContentLoader`.
    """
    for pair in entries.get("hostile_pairs") or []:
        FACTION_RELATIONS.set_hostile(str(pair[0]), str(pair[1]), True)
