"""Parser for character type YAML definitions."""

from faraway_realms.content_parsers.creatures import _parse_creature
from faraway_realms.entities.character_type import CHARACTER_REGISTRY


def parse_character_types(entries: dict) -> None:
    """Populate CHARACTER_REGISTRY from a parsed YAML entries dict.

    Character types use the same schema as creature types but omit the
    ``components.behaviour`` block — absence of a behaviour component
    signals that the entity is player-controlled.

    Parameters
    ----------
    entries : dict
        Mapping of archetype name → raw YAML dict, as produced by
        :class:`~faraway_realms.content.ContentLoader`.
    """
    for name, data in entries.items():
        CHARACTER_REGISTRY[name] = _parse_creature(name, data)
