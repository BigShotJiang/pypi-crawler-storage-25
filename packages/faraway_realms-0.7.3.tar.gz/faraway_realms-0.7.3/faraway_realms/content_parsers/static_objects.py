"""Parser for static object type YAML definitions."""

from faraway_realms.content_parsers import parse_color, parse_glyph
from faraway_realms.content_parsers.components import parse_components
from faraway_realms.entities.static_object import (
    STATIC_OBJECT_REGISTRY,
    StaticObjectType,
)


def parse_static_objects(entries: dict) -> None:
    """Populate STATIC_OBJECT_REGISTRY from a parsed YAML entries dict.

    Parameters
    ----------
    entries : dict
        Mapping of static object name → raw YAML dict, as produced by
        :class:`~faraway_realms.content.ContentLoader`.
    """
    for name, data in entries.items():
        STATIC_OBJECT_REGISTRY[name] = _parse_static_object(name, data)


def _parse_static_object(name: str, data: dict) -> StaticObjectType:
    raw_color = data["fg_color"]
    return StaticObjectType(
        name=name,
        char=parse_glyph(str(data["char"])),
        fg_color=parse_color(raw_color),
        components=parse_components(data.get("components") or {}),
        labels=frozenset(data.get("labels") or []),
        display_name=data.get("display_name") or "",
        description=data.get("description") or None,
    )
