"""Shared component parser — single entry point for all object types."""

from faraway_realms.content_parsers import parse_color
from faraway_realms.effects.light import LightAnimation
from faraway_realms.entities.components import (
    Component,
    LightEmitter,
    OpenableComponent,
)


def parse_components(raw: dict) -> dict[str, Component]:
    """Parse a raw ``components:`` YAML dict into a typed components dict.

    Parameters
    ----------
    raw : dict
        The value of a ``components:`` key from any YAML object definition.

    Returns
    -------
    dict[str, Component]
        Populated components dict, keyed by component name.
    """
    out: dict[str, Component] = {}
    if "light_emitter" in raw:
        out["light_emitter"] = _parse_light_emitter(raw["light_emitter"])
    if "openable" in raw:
        d = raw["openable"]
        out["openable"] = OpenableComponent(
            open_tile=d["open_tile"],
            closed_tile=d["closed_tile"],
        )
    return out


def _parse_animation(data: dict | None) -> LightAnimation | None:
    if data is None:
        return None
    return LightAnimation(
        kind=data["kind"],
        intensity_min=float(data["intensity_min"]),
        intensity_max=float(data["intensity_max"]),
        period=float(data.get("period", 3.0)),
        color_shift=int(data.get("color_shift", 0)),
    )


def _parse_light_emitter(data: dict) -> LightEmitter:
    return LightEmitter(
        radius=int(data["radius"]),
        intensity=float(data["intensity"]),
        color=parse_color(data["color"]),
        animation=_parse_animation(data.get("animation")),
    )
