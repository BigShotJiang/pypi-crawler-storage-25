"""Light types and per-tile LightMap computation."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import TYPE_CHECKING, cast

import numpy as np
import tcod.map

if TYPE_CHECKING:
    from collections.abc import Iterable

    from faraway_realms.entities.components import Component


@dataclass(frozen=True)
class LightAnimation:
    """Per-frame animation config for a light source.

    Parameters
    ----------
    kind : str
        ``"flicker"`` (organic noise) or ``"glow"`` (smooth sinusoidal pulse).
    intensity_min : float
        Minimum brightness reached during animation (0.0–1.0).
    intensity_max : float
        Maximum brightness reached during animation (0.0–1.0).
    period : float
        Seconds per full glow cycle.  Unused for flicker.
    color_shift : int
        ±RGB channel shift tied to intensity for flicker warmth: brighter →
        warmer (more red, less blue); dimmer → cooler.  ``0`` disables.
    """

    kind: str
    intensity_min: float
    intensity_max: float
    period: float = 3.0
    color_shift: int = 0


@dataclass(frozen=True)
class LightSource:
    """A point light that illuminates tiles within a circular radius.

    Parameters
    ----------
    radius : int
        Maximum illumination distance in tiles.
    intensity : float
        Peak brightness at the source tile (0.0–1.0).  Falls off linearly
        to zero at the edge of the radius.
    color : tuple[int, int, int]
        RGB tint of the light.  Each channel is applied independently so
        a warm torch and a cool mushroom produce visibly different tints.
    animation : LightAnimation | None
        Optional per-frame intensity/colour animation.  ``None`` = static.
    """

    radius: int
    intensity: float
    color: tuple[int, int, int] = (255, 200, 120)
    animation: LightAnimation | None = None


class LightMap:
    """Per-tile RGB brightness array recomputed each frame from light sources.

    Three float32 arrays (R, G, B) each start at ``AMBIENT``.  Every source
    accumulates its colour-weighted falloff into the relevant channel, capped
    at ``1.0``.  Explored-but-not-visible tiles are rendered using a separate
    "memory" tint supplied by the renderer.

    Parameters
    ----------
    width : int
        Map width in tiles.
    height : int
        Map height in tiles.
    """

    AMBIENT: float = 0.35

    def __init__(self, width: int, height: int, ambient: float = AMBIENT) -> None:
        self._w = width
        self._h = height
        self._ambient = ambient
        shape = (height, width)
        self._r: np.ndarray = np.full(shape, self._ambient, dtype=np.float32)
        self._g: np.ndarray = np.full(shape, self._ambient, dtype=np.float32)
        self._b: np.ndarray = np.full(shape, self._ambient, dtype=np.float32)

    def compute(
        self,
        sources: list[tuple[int, int, LightSource]],
        transparency: np.ndarray | None = None,
    ) -> None:
        """Recompute brightness from *sources*; resets to ambient first.

        Parameters
        ----------
        sources : list[tuple[int, int, LightSource]]
            Sequence of ``(x, y, light_source)`` tuples for all active emitters.
        transparency : np.ndarray or None
            ``(height, width)`` bool array; ``True`` = transparent (floor).
            Walls block light from passing through but are themselves illuminated.
            When ``None``, the map is treated as fully open (no blocking).
        """
        eff_transparency = (
            transparency
            if transparency is not None
            else np.ones((self._h, self._w), dtype=bool)
        )
        self._r[:] = self._ambient
        self._g[:] = self._ambient
        self._b[:] = self._ambient
        for x, y, src in sources:
            self._add_source(x, y, src, eff_transparency)

    def at(self, x: int, y: int) -> float:
        """Return peak channel brightness at tile ``(x, y)``.

        Returns the maximum of the three RGB channels.  Useful for tests and
        scalar comparisons; the renderer uses :meth:`rgb_at` for full colour.

        Parameters
        ----------
        x : int
            Map x coordinate.
        y : int
            Map y coordinate.

        Returns
        -------
        float
            Brightness in ``[0.0, 1.0]``.
        """
        return max(float(self._r[y, x]), float(self._g[y, x]), float(self._b[y, x]))

    def rgb_at(self, x: int, y: int) -> tuple[float, float, float]:
        """Return the RGB light factor at tile ``(x, y)``.

        Parameters
        ----------
        x : int
            Map x coordinate.
        y : int
            Map y coordinate.

        Returns
        -------
        tuple[float, float, float]
            Per-channel brightness factors in ``[0.0, 1.0]``.
        """
        return (float(self._r[y, x]), float(self._g[y, x]), float(self._b[y, x]))

    def _add_source(
        self, cx: int, cy: int, src: LightSource, transparency: np.ndarray
    ) -> None:
        """Accumulate one light source, blocked by walls via FOV shadow-casting."""
        r = src.radius
        fov = tcod.map.compute_fov(transparency, (cy, cx), radius=r, light_walls=True)
        y0 = max(0, cy - r)
        y1 = min(self._h, cy + r + 1)
        x0 = max(0, cx - r)
        x1 = min(self._w, cx + r + 1)
        ys = np.arange(y0, y1, dtype=np.float32)[:, None]
        xs = np.arange(x0, x1, dtype=np.float32)[None, :]
        dist = np.sqrt((xs - cx) ** 2 + (ys - cy) ** 2)
        contrib = np.where(dist <= r, (1.0 - dist / r) * src.intensity, 0.0)
        contrib *= fov[y0:y1, x0:x1]
        cr, cg, cb = src.color[0] / 255.0, src.color[1] / 255.0, src.color[2] / 255.0
        sl = np.s_[y0:y1, x0:x1]
        self._r[sl] = np.minimum(1.0, self._r[sl] + contrib * cr)
        self._g[sl] = np.minimum(1.0, self._g[sl] + contrib * cg)
        self._b[sl] = np.minimum(1.0, self._b[sl] + contrib * cb)


def _flicker_intensity(x: int, y: int, anim: LightAnimation, t: float) -> float:
    """Organic noise via three sines at irrational frequencies; per-source phase."""
    phase = (x * 1.6180339887 + y * 2.7182818284) % (2 * math.pi)
    v = (
        math.sin(t * 7.3 + phase) * 0.50
        + math.sin(t * 13.7 + phase * 1.4) * 0.30
        + math.sin(t * 23.1 + phase * 0.7) * 0.20
    )
    norm = max(0.0, min(1.0, (v + 1.0) / 2.0))
    return anim.intensity_min + norm * (anim.intensity_max - anim.intensity_min)


def _glow_intensity(anim: LightAnimation, t: float) -> float:
    """Smooth sinusoidal pulse between intensity_min and intensity_max."""
    norm = (math.sin(2 * math.pi * t / anim.period) + 1.0) / 2.0
    return anim.intensity_min + norm * (anim.intensity_max - anim.intensity_min)


def _shift_color(
    color: tuple[int, int, int],
    intensity: float,
    base_intensity: float,
    shift: int,
) -> tuple[int, int, int]:
    """Warm/cool tint shift proportional to intensity deviation from base."""
    if shift == 0:
        return color
    delta = round((intensity - base_intensity) / max(base_intensity, 0.001) * shift)
    r, g, b = color
    return (min(255, max(0, r + delta)), g, min(255, max(0, b - delta)))


def _animated_source(x: int, y: int, src: LightSource, t: float) -> LightSource:
    anim = src.animation
    if anim is None:
        return src
    if anim.kind == "glow":
        intensity = _glow_intensity(anim, t)
    else:
        intensity = _flicker_intensity(x, y, anim, t)
    color = _shift_color(src.color, intensity, src.intensity, anim.color_shift)
    return LightSource(radius=src.radius, intensity=intensity, color=color)


def animate_light_sources(
    sources: list[tuple[int, int, LightSource]],
    t: float,
) -> list[tuple[int, int, LightSource]]:
    """Apply per-source animation for render time ``t`` (wall-clock seconds).

    Sources without animation are returned unchanged.  Called client-side each
    render frame — not part of the tick pipeline.
    """
    return [
        (x, y, _animated_source(x, y, src, t))
        if src.animation is not None
        else (x, y, src)
        for x, y, src in sources
    ]


def collect_light_sources(
    positioned: Iterable[tuple[int, int, dict[str, Component]]],
) -> list[tuple[int, int, LightSource]]:
    """Return ``(x, y, LightSource)`` for every active light emitter.

    Accepts any iterable of ``(x, y, components)`` tuples and returns entries
    whose ``components`` dict contains a ``"light_emitter"`` key.  The parser
    invariant guarantees that key always holds a ``LightSource`` instance.
    Called by ``Game.light_sources()`` at render time — not part of the tick
    pipeline.

    Parameters
    ----------
    positioned : Iterable[tuple[int, int, dict[str, Component]]]
        Any sequence of ``(x, y, components)`` from static objects, entities,
        tiles, or any future positioned object type.

    Returns
    -------
    list[tuple[int, int, LightSource]]
        Only entries that have a ``"light_emitter"`` component.
    """
    result: list[tuple[int, int, LightSource]] = []
    for x, y, components in positioned:
        emitter = components.get("light_emitter")
        if emitter is not None:
            result.append((x, y, cast(LightSource, emitter)))
    return result
