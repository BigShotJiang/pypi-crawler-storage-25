"""Wind-driven Simplex noise fog overlay rendered over the map pane."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import tcod.console
import tcod.noise


@dataclass(frozen=True)
class FogParams:
    """Wind-driven fog overlay parameters.

    Parameters
    ----------
    density : float
        Overall fog strength multiplier (0–1).  Scales the noise amplitude
        before mapping to the opacity range.
    scale : float
        Noise spatial frequency — higher values produce finer-grained fog.
    wind_x : float
        Horizontal drift speed in tiles per second.
    wind_y : float
        Vertical drift speed in tiles per second.
    color : tuple[int, int, int]
        RGB target colour the fog blends toward.
    opacity_min : float
        Minimum alpha at the quietest noise regions.
    opacity_max : float
        Maximum alpha at the densest noise regions.
    seed : int
        Noise seed; controls the fog's spatial pattern.
    """

    density: float = 0.6
    scale: float = 0.12
    wind_x: float = 0.3
    wind_y: float = 0.1
    color: tuple[int, int, int] = (140, 160, 180)
    opacity_min: float = 0.0
    opacity_max: float = 0.45
    seed: int = 7


_noise_cache: dict[int, tcod.noise.Noise] = {}


def _get_noise(seed: int) -> tcod.noise.Noise:
    if seed not in _noise_cache:
        _noise_cache[seed] = tcod.noise.Noise(dimensions=2, seed=seed)
    return _noise_cache[seed]


def fog_alpha(
    cam: tuple[int, int],
    h: int,
    w: int,
    t: float,
    params: FogParams,
) -> np.ndarray:
    """Return an ``(h, w)`` float32 alpha array in ``[0, 1]``.

    Parameters
    ----------
    cam : tuple[int, int]
        World-space camera origin ``(cam_x, cam_y)``.  Fog is anchored to
        world coordinates so it stays consistent as the player moves.
    h : int
        Pane height in tiles.
    w : int
        Pane width in tiles.
    t : float
        Wall-clock time in seconds; drives wind drift.
    params : FogParams
        Fog configuration.

    Returns
    -------
    np.ndarray
        Float32 array of shape ``(h, w)`` with values in ``[0, 1]``.
    """
    noise = _get_noise(params.seed)
    cam_x, cam_y = cam
    y_i, x_i = np.mgrid[0:h, 0:w]
    # Wrap t to keep float32 precision: epoch-scale seconds (~1.7e9) cause all
    # noise coordinates to collapse to the same float32 value, making the fog
    # appear flat and static.  10000 s keeps values safely in float32 range
    # (max ULP ~0.0024) without visible seams — any pattern repeat is 10000/wind
    # seconds away (~1.4 hrs at default speed).
    t_f = np.float32(t % 10000.0)
    scale_f = np.float32(params.scale)
    wx = (x_i + cam_x).astype(np.float32) * scale_f + np.float32(params.wind_x) * t_f
    wy = (y_i + cam_y).astype(np.float32) * scale_f + np.float32(params.wind_y) * t_f
    raw = noise[wx, wy]  # float32 in [-1, 1]
    norm = (raw + 1.0) * 0.5  # remap to [0, 1]
    # Smoothstep (3t²−2t³): zero derivative at 0 and 1 → soft patch edges
    norm = norm * norm * (3.0 - 2.0 * norm)
    span = params.opacity_max - params.opacity_min
    return np.clip(params.opacity_min + norm * params.density * span, 0.0, 1.0).astype(
        np.float32
    )


def render_fog(
    console: tcod.console.Console,
    cam: tuple[int, int],
    pane_x: int,
    pane_y: int,
    pane_w: int,
    pane_h: int,
    t: float,
    params: FogParams,
) -> None:
    """Blend fog over a rectangular pane region of *console*.

    Both ``fg`` and ``bg`` channels are blended toward ``params.color`` so
    that foreground characters are visually obscured alongside the background.

    Parameters
    ----------
    console : tcod.console.Console
        Target console (modified in place).
    cam : tuple[int, int]
        World-space camera origin ``(cam_x, cam_y)``.
    pane_x : int
        Left column of the pane in console coordinates.
    pane_y : int
        Top row of the pane in console coordinates.
    pane_w : int
        Pane width in tiles.
    pane_h : int
        Pane height in tiles.
    t : float
        Wall-clock time in seconds.
    params : FogParams
        Fog configuration.
    """
    alpha = fog_alpha(cam, pane_h, pane_w, t, params)
    fog = np.array(params.color, dtype=np.float32)
    alpha3 = alpha[:, :, np.newaxis]
    region = console.rgb[pane_y : pane_y + pane_h, pane_x : pane_x + pane_w]
    region["fg"] = np.clip(
        region["fg"].astype(np.float32) * (1.0 - alpha3) + fog * alpha3,
        0,
        255,
    ).astype(np.uint8)
    region["bg"] = np.clip(
        region["bg"].astype(np.float32) * (1.0 - alpha3) + fog * alpha3,
        0,
        255,
    ).astype(np.uint8)
