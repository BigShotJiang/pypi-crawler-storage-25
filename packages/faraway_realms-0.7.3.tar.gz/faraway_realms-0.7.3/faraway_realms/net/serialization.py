"""Game-state serialization: TickSnapshot, serialize_tick, deserialize_snapshot."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from faraway_realms.types import Pos

if TYPE_CHECKING:
    from faraway_realms.game import Game
    from faraway_realms.world.map import Map


# ---------------------------------------------------------------------------
# Snapshot dataclasses
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class EntitySnapshot:
    """Serialized view of one entity for the client.

    Static fields (char, fg_color, display_name, faction, abilities,
    blood_color, is_player) are omitted — the client resolves them from
    the ``type_catalogue`` sent in the welcome message.
    """

    entity_id: int
    x: int
    y: int
    type_id: str
    target_id: int | None
    stats: dict[str, Any]
    status_effects: list[dict[str, Any]]
    last_hit_tick: int = 0
    last_hit_by: int | None = None


@dataclass
class TickSnapshot:
    """All game state the client needs to render one frame."""

    entities: list[EntitySnapshot] = field(default_factory=list)
    tile_updates: list[dict[str, Any]] = field(default_factory=list)
    projectiles: list[dict[str, Any]] = field(default_factory=list)
    light_sources: list[Any] = field(default_factory=list)
    melee_animations: list[Any] = field(default_factory=list)
    movement_trails: list[Any] = field(default_factory=list)
    static_objects: list[dict[str, Any]] = field(default_factory=list)
    chat_messages: list[dict[str, Any]] = field(default_factory=list)
    removed_entity_ids: list[int] = field(default_factory=list)
    tile_reveals: list[dict[str, Any]] = field(default_factory=list)
    static_object_reveals: list[dict[str, Any]] = field(default_factory=list)
    map_tiles: list[list[dict[str, Any]]] | None = None  # only in welcome
    attack_cooldown_fraction: float = 0.0
    gcd_fraction: float | None = None
    cast_fraction: float | None = None
    ability_cooldowns: dict[str, float | None] = field(default_factory=dict)
    # Fractions for the player's current target (drives the enemy status bar)
    target_entity_id: int | None = None
    target_attack_fraction: float = 0.0
    target_cast_fraction: float | None = None
    target_gcd_fraction: float | None = None
    # Monotonically-increasing counters for screen-flash triggers
    hit_seq: int = 0
    crit_dealt_seq: int = 0
    abs_tick: int = 0


# ---------------------------------------------------------------------------
# Serialization helpers
# ---------------------------------------------------------------------------


def _ser_stat(stat: Any) -> dict[str, Any]:
    """Serialize a Stat or Pool to a plain dict."""
    from faraway_realms.combat.stats import Pool

    d: dict[str, Any] = {
        "base": stat.base,
        "bonus": stat.bonus,
        "abbreviation": stat.abbreviation,
        "bar_filled": list(stat.bar_filled) if stat.bar_filled else None,
        "bar_empty": list(stat.bar_empty) if stat.bar_empty else None,
    }
    if isinstance(stat, Pool):
        d["current"] = stat.current
        d["is_pool"] = True
    else:
        d["is_pool"] = False
    return d


def _ser_status(s: Any) -> dict[str, Any]:
    return {
        "name": s.name,
        "expires_at": s.expires_at,
        "immobilize": s.immobilize,
        "stun": s.stun,
        "haste": s.haste,
    }


def _ser_entity(game: Game, entity: Any) -> EntitySnapshot:
    try:
        x, y = game.game_map.get_entity_position(entity.entity_id)
    except KeyError:
        x, y = -1, -1
    stats = {k: _ser_stat(v) for k, v in entity.stats.items()}
    statuses = [_ser_status(s) for s in entity.status_effects]
    return EntitySnapshot(
        entity_id=entity.entity_id,
        x=x,
        y=y,
        type_id=entity.type_id,
        target_id=entity.target_id,
        stats=stats,
        status_effects=statuses,
        last_hit_tick=entity.last_hit_tick,
        last_hit_by=entity.last_hit_by,
    )


def _ser_light_source(x: int, y: int, ls: Any) -> list:
    anim = ls.animation
    base = [x, y, ls.radius, ls.intensity, list(ls.color)]
    if anim is None:
        return base
    return base + [
        [
            anim.kind,
            anim.intensity_min,
            anim.intensity_max,
            anim.period,
            anim.color_shift,
        ]
    ]


def _deser_animation(data: list | None) -> Any:
    if data is None:
        return None
    from faraway_realms.effects.light import LightAnimation  # noqa: PLC0415

    return LightAnimation(
        kind=data[0],
        intensity_min=data[1],
        intensity_max=data[2],
        period=data[3],
        color_shift=data[4],
    )


def _ser_projectile(p: Any) -> dict[str, Any]:
    return {
        "x": p.x,
        "y": p.y,
        "color": list(p.color),
        "trail": [list(pos) for pos in p.trail],
        "trail_char": p.trail_char,
    }


def _collect_static_reveals(
    game: Game,
    new_tiles: set[Pos] | frozenset[Pos],
) -> list[dict[str, Any]]:
    """Return static objects whose position falls within newly-explored tiles."""
    return [
        {
            "x": o.x,
            "y": o.y,
            "char": o.char,
            "fg_color": list(o.fg_color),
            "type_id": o.type_id,
        }
        for o in game.static_objects
        if (o.x, o.y) in new_tiles
    ]


def serialize_tile_sparse(
    game_map: Map,
    tiles: set[Pos] | frozenset[Pos],
) -> list[dict[str, Any]]:
    """Serialize a sparse set of tiles as a list of positioned tile dicts.

    Parameters
    ----------
    game_map : Map
        Source of tile data.
    tiles : set or frozenset of (x, y) pairs
        Which tiles to include; order is not guaranteed.
    """
    result = []
    for x, y in tiles:
        tile = game_map.get_tile(x, y)
        result.append(
            {
                "x": x,
                "y": y,
                "walkable": tile.walkable,
                "char": tile.char,
                "fg": list(tile.fg_color),
                "bg": list(tile.bg_color),
                "tile_type_id": game_map.tile_type_ids.get((x, y)),
            }
        )
    return result


def serialize_tile_reveal(
    game_map: Map,
    tiles: set[Pos] | frozenset[Pos],
) -> list[dict[str, Any]]:
    """Like serialize_tile_sparse but adds zone/type metadata for describe support.

    Used only for first-visit tile reveals (not dirty-tile updates), so the
    client can populate ``game_map.tile_zones`` and ``game_map.tile_type_ids``.
    """
    result = []
    for x, y in tiles:
        tile = game_map.get_tile(x, y)
        result.append(
            {
                "x": x,
                "y": y,
                "walkable": tile.walkable,
                "char": tile.char,
                "fg": list(tile.fg_color),
                "bg": list(tile.bg_color),
                "zone_name": game_map.tile_zones.get((x, y)),
                "tile_type_id": game_map.tile_type_ids.get((x, y)),
            }
        )
    return result


def collect_entities(game: Game) -> list[EntitySnapshot]:
    """Serialize all entities once per tick.

    Filter per client via ``serialize_per_client``.
    """
    entities: list[EntitySnapshot] = []
    for player in game.all_player_entities():
        entities.append(_ser_entity(game, player))
    for npc in game.all_npcs():
        entities.append(_ser_entity(game, npc))
    return entities


def _collect_ability_cds(game: Game, player_entity_id: int) -> dict[str, float | None]:
    entity = game.entity(player_entity_id)
    if entity is None:
        return {}
    return {
        name: game.ability_cooldown_fraction(player_entity_id, name)
        for name in entity.abilities
    }


def _collect_target_fractions(game: Game, player_entity_id: int) -> dict[str, Any]:
    """Return cooldown fractions for the player's current target entity."""
    player = game.entity(player_entity_id)
    target_id = player.target_id if player is not None else None
    if target_id is None:
        return {
            "target_entity_id": None,
            "target_attack_fraction": 0.0,
            "target_cast_fraction": None,
            "target_gcd_fraction": None,
        }
    return {
        "target_entity_id": target_id,
        "target_attack_fraction": game.attack_cooldown_fraction(target_id),
        "target_cast_fraction": game.cast_fraction(target_id),
        "target_gcd_fraction": game.gcd_fraction(target_id),
    }


def serialize_shared(game: Game) -> dict[str, Any]:
    """Build the tick payload fields that are identical for every connected client.

    Only includes data that does not vary per-client: projectiles and light
    sources.  Events (attack anims, blood) and chat are per-client and handled
    by ``collect_tick_events`` + ``serialize_per_client``.

    ``entities`` is intentionally absent — it is per-client (FOV-filtered) and
    added by ``serialize_per_client``.
    """
    return {
        "type": "tick",
        "projectiles": [_ser_projectile(p) for p in game.active_projectiles],
        "light_sources": [
            _ser_light_source(x, y, ls) for x, y, ls in game.light_sources()
        ],
        "melee_animations": [
            [list(fp), list(tp), list(col), list(bc) if bc else None]
            for fp, tp, col, bc in game.melee_anim_events()
        ],
        "movement_trails": [
            [eid, char, list(fg), [[x, y] for x, y in path]]
            for eid, char, fg, path in game.movement_trail_events()
        ],
    }


def serialize_per_client(
    game: Game,
    player_entity_id: int,
    all_snaps: list[EntitySnapshot],
    visible_tiles: frozenset[Pos],
    removed_ids: frozenset[int],
    new_tiles: set[Pos] | frozenset[Pos],
    *,
    dirty_tiles: set[Pos] | frozenset[Pos] | None = None,
    explored_tiles: set[Pos] | frozenset[Pos] | None = None,
    new_messages: list | None = None,
) -> dict[str, Any]:
    """Build the per-client tick payload: FOV-filtered entities + tile updates + chat.

    Parameters
    ----------
    all_snaps : list[EntitySnapshot]
        All entities serialized once this tick (from ``collect_entities``).
    visible_tiles : frozenset[tuple[int, int]]
        (x, y) tiles currently visible to this client.  Entities whose
        position falls outside this set are excluded.  The player's own
        entity is always included regardless of position.
    removed_ids : frozenset[int]
        Entity IDs that were visible last tick but are not this tick.
        Sent so the client can evict them from its cache.
    dirty_tiles
        Map tiles modified since last tick (e.g. blood baked into bg_color).
        Filtered by ``explored_tiles`` before sending.
    explored_tiles
        All tiles this client has ever seen; used to filter dirty-tile deltas.
    new_messages
        Chat messages new since this client's last delivery (delta only).
    """
    visible_snaps = [
        s
        for s in all_snaps
        if (s.x, s.y) in visible_tiles or s.entity_id == player_entity_id
    ]

    if dirty_tiles and explored_tiles:
        client_dirty = dirty_tiles & explored_tiles
    else:
        client_dirty = dirty_tiles or set()

    return {
        "entities": [_entity_snap_to_dict(s) for s in visible_snaps],
        "removed_entity_ids": list(removed_ids),
        "tile_reveals": serialize_tile_reveal(game.game_map, new_tiles),
        "tile_updates": serialize_tile_sparse(game.game_map, client_dirty),
        "static_object_reveals": _collect_static_reveals(game, new_tiles),
        "chat_messages": [
            {"text": m.text, "color": list(m.color)} for m in (new_messages or [])
        ],
        "attack_cooldown_fraction": game.attack_cooldown_fraction(player_entity_id),
        "gcd_fraction": game.gcd_fraction(player_entity_id),
        "cast_fraction": game.cast_fraction(player_entity_id),
        "ability_cooldowns": _collect_ability_cds(game, player_entity_id),
        "hit_seq": game.get_hit_seq(player_entity_id),
        "crit_dealt_seq": game.get_crit_dealt_seq(player_entity_id),
        "abs_tick": game.abs_tick,
        **_collect_target_fractions(game, player_entity_id),
    }


def _entity_snap_to_dict(e: EntitySnapshot) -> dict[str, Any]:
    return {
        "entity_id": e.entity_id,
        "x": e.x,
        "y": e.y,
        "type_id": e.type_id,
        "target_id": e.target_id,
        "stats": e.stats,
        "status_effects": e.status_effects,
        "last_hit_tick": e.last_hit_tick,
        "last_hit_by": e.last_hit_by,
    }


def deserialize_snapshot(data: dict[str, Any]) -> TickSnapshot:
    """Convert a raw tick dict (from JSON) into a TickSnapshot."""
    entities = [_dict_to_entity_snap(e) for e in data.get("entities", [])]
    return TickSnapshot(
        entities=entities,
        tile_updates=data.get("tile_updates", []),
        projectiles=data.get("projectiles", []),
        light_sources=data.get("light_sources", []),
        melee_animations=data.get("melee_animations", []),
        movement_trails=data.get("movement_trails", []),
        static_objects=data.get("static_objects", []),
        chat_messages=data.get("chat_messages", []),
        removed_entity_ids=data.get("removed_entity_ids", []),
        tile_reveals=data.get("tile_reveals", []),
        static_object_reveals=data.get("static_object_reveals", []),
        map_tiles=data.get("map_tiles"),
        attack_cooldown_fraction=data.get("attack_cooldown_fraction", 0.0),
        gcd_fraction=data.get("gcd_fraction"),
        cast_fraction=data.get("cast_fraction"),
        ability_cooldowns=data.get("ability_cooldowns", {}),
        target_entity_id=data.get("target_entity_id"),
        target_attack_fraction=data.get("target_attack_fraction", 0.0),
        target_cast_fraction=data.get("target_cast_fraction"),
        target_gcd_fraction=data.get("target_gcd_fraction"),
        hit_seq=data.get("hit_seq", 0),
        crit_dealt_seq=data.get("crit_dealt_seq", 0),
        abs_tick=data.get("abs_tick", 0),
    )


def _dict_to_entity_snap(d: dict[str, Any]) -> EntitySnapshot:
    return EntitySnapshot(
        entity_id=d["entity_id"],
        x=d["x"],
        y=d["y"],
        type_id=d.get("type_id", ""),
        target_id=d.get("target_id"),
        stats=d.get("stats", {}),
        status_effects=d.get("status_effects", []),
        last_hit_tick=d.get("last_hit_tick", 0),
        last_hit_by=d.get("last_hit_by"),
    )


def serialize_map(game: Game) -> list[list[dict[str, Any]]]:
    """Serialize the full map tile grid (sent once in welcome message)."""
    gmap = game.game_map
    rows = []
    for y in range(gmap.height):
        row = []
        for x in range(gmap.width):
            tile = gmap.get_tile(x, y)
            row.append(
                {
                    "walkable": tile.walkable,
                    "char": tile.char,
                    "fg": list(tile.fg_color),
                    "bg": list(tile.bg_color),
                }
            )
        rows.append(row)
    return rows
