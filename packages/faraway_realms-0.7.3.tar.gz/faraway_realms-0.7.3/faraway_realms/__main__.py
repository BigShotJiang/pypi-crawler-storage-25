"""Entry point — run with ``python -m faraway_realms``."""

from __future__ import annotations

import argparse
import asyncio
import functools
import logging
import random
import threading
import uuid
from pathlib import Path

from faraway_realms.content import ContentLoader
from faraway_realms.content_parsers.abilities import parse_abilities
from faraway_realms.content_parsers.character_types import parse_character_types
from faraway_realms.content_parsers.creatures import parse_creatures
from faraway_realms.content_parsers.damage_types import parse_damage_effectiveness
from faraway_realms.content_parsers.factions import parse_factions
from faraway_realms.content_parsers.maps import parse_map_profiles
from faraway_realms.content_parsers.stat_definitions import parse_stat_definitions
from faraway_realms.content_parsers.static_objects import parse_static_objects
from faraway_realms.content_parsers.status_effects import parse_status_effects
from faraway_realms.content_parsers.tiles import (
    parse_tile_overlays,
    parse_tile_type_patches,
    parse_tiles,
)
from faraway_realms.effects.fog import FogParams
from faraway_realms.entities.character_type import CHARACTER_REGISTRY
from faraway_realms.entities.creature_type import CREATURE_REGISTRY
from faraway_realms.entities.entity import Entity, Player
from faraway_realms.game import Game
from faraway_realms.game_logger import log_event, setup_game_logger
from faraway_realms.mapgen import (
    CorridorNarrowingPass,
    CreaturePopulationPass,
    DoorPopulationPass,
    NoiseTexturePass,
    StaticObjectPopulationPass,
    TileScatterPass,
)
from faraway_realms.mapgen.base import MapGenResult
from faraway_realms.mapgen.generator import make_generator
from faraway_realms.mapgen.map_profile import MAP_PROFILE_REGISTRY, MapProfile
from faraway_realms.mapgen.texture import (
    TILE_OVERLAY_REGISTRY,
    TILE_TYPE_PATCH_REGISTRY,
)
from faraway_realms.settings import load_admin_settings
from faraway_realms.ui import GameUI
from faraway_realms.ui.panels import LiveStatsPanel
from faraway_realms.world.events import Event, EventType
from faraway_realms.world.factions import FACTION_RELATIONS
from faraway_realms.world.map import Map, make_blank_map, make_bordered_map
from faraway_realms.world.tile import Tile

_log = logging.getLogger(__name__)

_ASSETS = Path(__file__).parent / "assets"
_TILESET = _ASSETS / "unified_12x12.png"
_DATA_STATS = Path(__file__).parent / "data" / "stats"
_USER_STATS = Path.home() / ".faraway_realms" / "stats"
_DATA_ABILITIES = Path(__file__).parent / "data" / "abilities"
_USER_ABILITIES = Path.home() / ".faraway_realms" / "abilities"
_DATA_CREATURES = Path(__file__).parent / "data" / "creatures"
_USER_CREATURES = Path.home() / ".faraway_realms" / "creatures"
_DATA_CHARACTERS = Path(__file__).parent / "data" / "characters"
_USER_CHARACTERS = Path.home() / ".faraway_realms" / "characters"
_DATA_STATIC_OBJECTS = Path(__file__).parent / "data" / "static_objects"
_USER_STATIC_OBJECTS = Path.home() / ".faraway_realms" / "static_objects"
_DATA_DAMAGE_TYPES = Path(__file__).parent / "data" / "damage_types"
_USER_DAMAGE_TYPES = Path.home() / ".faraway_realms" / "damage_types"
_DATA_FACTIONS = Path(__file__).parent / "data" / "factions"
_USER_FACTIONS = Path.home() / ".faraway_realms" / "factions"
_DATA_TILES = Path(__file__).parent / "data" / "tiles"
_USER_TILES = Path.home() / ".faraway_realms" / "tiles"
_DATA_STATUS_EFFECTS = Path(__file__).parent / "data" / "status_effects"
_USER_STATUS_EFFECTS = Path.home() / ".faraway_realms" / "status_effects"
_DATA_MAPS = Path(__file__).parent / "data" / "maps"
_USER_MAPS = Path.home() / ".faraway_realms" / "maps"
_UUID_FILE = Path.home() / ".faraway_realms" / "client.uuid"

_MAP_WIDTH = 100
_MAP_HEIGHT = 60
_MAP_SEED = 42
_DEFAULT_COLOR = (255, 255, 0)


def _parse_color(s: str) -> tuple[int, int, int]:
    r, g, b = (int(c) for c in s.split(","))
    return r, g, b


def _room_spawn_tiles(game_map: Map, result: MapGenResult) -> list[tuple[int, int]]:
    if result.rooms:
        room = result.rooms[0]
        return [
            (x, y)
            for y in range(room.y, room.y2)
            for x in range(room.x, room.x2)
            if game_map.is_walkable(x, y)
        ]
    if result.spawn_zones:
        return list(result.spawn_zones[result.player_zone_index])
    px, py = result.player_start
    return [
        (x, y)
        for dx in range(-3, 4)
        for dy in range(-3, 4)
        if game_map.is_walkable(x := px + dx, y := py + dy)
    ]


def _validate_damage_types() -> None:
    from faraway_realms.combat.damage_types import EFFECTIVENESS

    known_damage = {dt for dt, _ in EFFECTIVENESS}
    known_armor = {at for _, at in EFFECTIVENESS}
    for ct in [*CREATURE_REGISTRY.values(), *CHARACTER_REGISTRY.values()]:
        cp = ct.combat_profile
        if cp.damage_type not in known_damage:
            _log.warning(
                "Content: %r has unknown damage_type %r (not in effectiveness matrix)",
                ct.name,
                cp.damage_type,
            )
        if cp.armor_type != "none" and cp.armor_type not in known_armor:
            _log.warning(
                "Content: %r has unknown armor_type %r (not in effectiveness matrix)",
                ct.name,
                cp.armor_type,
            )


def _load_content() -> None:
    loader = ContentLoader(
        dirs=[
            _DATA_STATS,
            _USER_STATS,
            _DATA_ABILITIES,
            _USER_ABILITIES,
            _DATA_CREATURES,
            _USER_CREATURES,
            _DATA_CHARACTERS,
            _USER_CHARACTERS,
            _DATA_STATIC_OBJECTS,
            _USER_STATIC_OBJECTS,
            _DATA_DAMAGE_TYPES,
            _USER_DAMAGE_TYPES,
            _DATA_FACTIONS,
            _USER_FACTIONS,
            _DATA_TILES,
            _USER_TILES,
            _DATA_STATUS_EFFECTS,
            _USER_STATUS_EFFECTS,
            _DATA_MAPS,
            _USER_MAPS,
        ]
    )
    loader.register_parser("stat_definitions", parse_stat_definitions)
    loader.register_parser("abilities", parse_abilities)
    loader.register_parser("creatures", parse_creatures)
    loader.register_parser("character_types", parse_character_types)
    loader.register_parser("static_objects", parse_static_objects)
    loader.register_parser("damage_effectiveness", parse_damage_effectiveness)
    loader.register_parser("factions", parse_factions)
    loader.register_parser("tiles", parse_tiles)
    loader.register_parser("tile_overlays", parse_tile_overlays)
    loader.register_parser("tile_type_patches", parse_tile_type_patches)
    loader.register_parser("status_effects", parse_status_effects)
    loader.register_parser("maps", parse_map_profiles)
    loader.load()
    _validate_damage_types()


def _load_or_create_uuid() -> str:
    _UUID_FILE.parent.mkdir(parents=True, exist_ok=True)
    if _UUID_FILE.exists():
        return _UUID_FILE.read_text().strip()
    uid = str(uuid.uuid4())
    _UUID_FILE.write_text(uid)
    return uid


def _resolve_profile(map_name: str) -> MapProfile:
    if map_name in MAP_PROFILE_REGISTRY:
        return MAP_PROFILE_REGISTRY[map_name]
    return MapProfile(name=map_name)


def _profile_patches(profile: MapProfile):  # type: ignore[return]
    if profile.texture_patches is None:
        return tuple(TILE_TYPE_PATCH_REGISTRY.values())
    return tuple(TILE_TYPE_PATCH_REGISTRY[k] for k in profile.texture_patches)


def _profile_overlays(profile: MapProfile):  # type: ignore[return]
    if profile.texture_overlays is None:
        return tuple(TILE_OVERLAY_REGISTRY.values())
    return tuple(TILE_OVERLAY_REGISTRY[k] for k in profile.texture_overlays)


def _generate_map(profile: MapProfile, rng: random.Random) -> MapGenResult:
    gen_result = make_generator(profile.generator).generate(
        _MAP_WIDTH, _MAP_HEIGHT, rng
    )
    CorridorNarrowingPass(profile).apply(gen_result, rng)
    if profile.noise_texture:
        NoiseTexturePass(
            patches=_profile_patches(profile),
            overlays=_profile_overlays(profile),
            scale=profile.noise_scale,
            strength=profile.noise_strength,
        ).apply(gen_result, rng)
    TileScatterPass(rules=profile.scatter).apply(gen_result, rng)
    CreaturePopulationPass(
        labels=profile.creature_labels,
        count=profile.creature_count,
        min_player_distance=profile.creature_min_player_distance,
    ).apply(gen_result, rng)
    StaticObjectPopulationPass(
        labels=profile.static_object_labels,
        count=profile.static_object_count,
        min_player_distance=profile.static_object_min_player_distance,
    ).apply(gen_result, rng)
    DoorPopulationPass(profile).apply(gen_result, rng)
    return gen_result


def _build_game(
    seed: int,
    username: str = "player1",
    char_name: str = "Hero",
    color: tuple[int, int, int] = _DEFAULT_COLOR,
    map_name: str = "cave",
) -> tuple[Game, Player]:
    profile = _resolve_profile(map_name)
    random.seed(seed)  # noqa: S311 — seeds global module for runtime game logic
    rng = random.Random(seed)  # noqa: S311 — game logic, not crypto
    gen_result = _generate_map(profile, rng)
    game_map = gen_result.map
    game_map.tile_zones.update(gen_result.tile_zones)
    game_map.tile_type_ids.update(gen_result.tile_type_ids)

    entity = CHARACTER_REGISTRY["hero"].to_entity(entity_id=1)
    entity.name = char_name
    entity.fg_color = color
    player = Player(username=username, entity=entity, is_game_master=True)
    spawn_tiles = _room_spawn_tiles(game_map, gen_result)

    game = Game(
        game_map=game_map,
        faction_relations=FACTION_RELATIONS,
        player_spawn_tiles=spawn_tiles,
        ambient=profile.ambient,
        fog_params=profile.fog,
    )
    for ct in CREATURE_REGISTRY.values():
        game.register_creature(ct.name, ct.to_npc)
    game.add_player(player)
    px, py = gen_result.player_start
    game_map.place_entity(entity.entity_id, px, py)

    for i, (creature_type, cx, cy) in enumerate(
        gen_result.creature_placements, start=2
    ):
        npc = creature_type.to_npc(entity_id=i)
        game.add_npc(npc)
        game_map.place_entity(i, cx, cy)

    for sot, sx, sy in gen_result.static_object_placements:
        game.add_static_object(sot.to_static_object(sx, sy))

    return game, player


def _player_ids(game: Game) -> frozenset[int]:
    return frozenset(e.entity_id for e in game.all_player_entities())


def _entity_name(entity: object) -> str:
    if entity is None:
        return "unknown"
    return getattr(entity, "name", f"#{getattr(entity, 'entity_id', '?')}")


def _obs_death(game: Game, event: Event) -> None:
    pids = _player_ids(game)
    entity = game.entity(event.source_id)
    killer_id = getattr(entity, "last_hit_by", None)
    killer = game.entity(killer_id) if killer_id is not None else None
    hp_stat = entity.stats.get("health") if entity is not None else None
    log_event(
        "entity_death",
        entity_id=event.source_id,
        name=_entity_name(entity),
        is_player=event.source_id in pids,
        killer_id=killer_id,
        killer_name=_entity_name(killer),
        is_player_killer=(killer_id in pids) if killer_id is not None else False,
        hp_max=hp_stat.value if hp_stat is not None else 0,
        tick=game.abs_tick,
    )


def _obs_hit(game: Game, event: Event) -> None:
    payload = event.payload or {}
    pids = _player_ids(game)
    src = game.entity(event.source_id)
    tgt = game.entity(event.target_id) if event.target_id is not None else None
    cp = src.components.get("combat_profile") if src is not None else None
    log_event(
        "entity_hit",
        source_id=event.source_id,
        source_name=_entity_name(src),
        source_is_player=event.source_id in pids,
        target_id=event.target_id,
        target_name=_entity_name(tgt),
        target_is_player=event.target_id in pids,
        damage=payload.get("damage", 0),
        crit=payload.get("crit", False),
        is_ability=payload.get("is_ability", False),
        damage_type=getattr(cp, "damage_type", "unknown"),
        tick=game.abs_tick,
    )


def _obs_cast(game: Game, event: Event) -> None:
    pids = _player_ids(game)
    entity = game.entity(event.source_id)
    payload = event.payload or {}
    log_event(
        "cast_complete",
        caster_id=event.source_id,
        caster_name=_entity_name(entity),
        caster_is_player=event.source_id in pids,
        ability_name=str(payload.get("ability", "unknown")),
        tick=game.abs_tick,
    )


def _obs_status(game: Game, event: Event) -> None:
    pids = _player_ids(game)
    payload = event.payload or {}
    src = game.entity(event.source_id)
    tgt = game.entity(event.target_id) if event.target_id is not None else None
    log_event(
        "status_applied",
        source_id=event.source_id,
        source_name=_entity_name(src),
        target_id=event.target_id,
        target_name=_entity_name(tgt),
        target_is_player=event.target_id in pids,
        status_name=payload.get("status_name", "unknown"),
        tick=game.abs_tick,
    )


def _subscribe_observability(game: Game) -> None:
    """Subscribe read-only event observers that emit structured log events."""
    _bind = functools.partial
    game.subscribe_events(EventType.ENTITY_DYING, _bind(_obs_death, game), priority=0)
    game.subscribe_events(EventType.ENTITY_HIT, _bind(_obs_hit, game), priority=20)
    game.subscribe_events(EventType.CAST_COMPLETE, _bind(_obs_cast, game), priority=20)
    game.subscribe_events(
        EventType.STATUS_APPLIED, _bind(_obs_status, game), priority=20
    )


def _start_server_thread(server: object) -> None:
    def _run() -> None:
        asyncio.run(server.run())  # type: ignore[attr-defined]

    t = threading.Thread(target=_run, daemon=True, name="GameServer")
    t.start()


def _wait_for_server(server: object) -> int:
    import time

    for _ in range(50):  # up to 5 seconds
        try:
            return server.bound_port  # type: ignore[attr-defined]
        except RuntimeError:
            time.sleep(0.1)
    raise RuntimeError("Server did not start in time")


def _parse_addr(addr: str) -> tuple[str, int]:
    parts = addr.rsplit(":", 1)
    return parts[0], int(parts[1])


def _reconstruct_map(tiles_data: list, width: int, height: int) -> Map:
    """Build a Map from a sparse tile list received in the welcome message."""
    game_map = make_blank_map(width, height)
    for cell in tiles_data:
        game_map.set_tile(
            cell["x"],
            cell["y"],
            Tile(
                walkable=cell["walkable"],
                fg_color=tuple(cell["fg"]),  # type: ignore[arg-type]
                bg_color=tuple(cell["bg"]),  # type: ignore[arg-type]
                char=cell.get("char", ord(".")),
            ),
        )
        zone = cell.get("zone_name")
        if zone:
            game_map.tile_zones[(cell["x"], cell["y"])] = zone
        tile_type_id = cell.get("tile_type_id")
        if tile_type_id:
            game_map.tile_type_ids[(cell["x"], cell["y"])] = tile_type_id
    return game_map


def _map_from_welcome(welcome: dict) -> Map:
    map_tiles_data = welcome.get("map_tiles")
    width = welcome.get("map_width", _MAP_WIDTH)
    height = welcome.get("map_height", _MAP_HEIGHT)
    if map_tiles_data is not None:
        return _reconstruct_map(map_tiles_data, width, height)
    return make_bordered_map(width, height)


def _fog_from_welcome(welcome: dict) -> FogParams:
    fog = welcome.get("fog") or {}
    color_raw = fog.get("color", [130, 145, 165])
    return FogParams(
        density=float(fog.get("density", 0.5)),
        scale=float(fog.get("scale", 0.15)),
        wind_x=float(fog.get("wind_x", 0.25)),
        wind_y=float(fog.get("wind_y", 0.10)),
        color=(int(color_raw[0]), int(color_raw[1]), int(color_raw[2])),
        opacity_min=float(fog.get("opacity_min", 0.0)),
        opacity_max=float(fog.get("opacity_max", 0.20)),
        seed=int(fog.get("seed", 7)),
    )


def _run_as_client(
    addr: str,
    username: str = "player1",
    char_name: str = "Hero",
    color: tuple[int, int, int] = _DEFAULT_COLOR,
) -> None:
    import time

    from faraway_realms.client_game import ClientGame
    from faraway_realms.net.client import NetworkClient

    host, port = _parse_addr(addr)
    uid = _load_or_create_uuid()
    client = NetworkClient(
        host, port, uid, username=username, char_name=char_name, color=color
    )
    client.start()

    for _ in range(100):
        if client.welcome_info() is not None:
            break
        time.sleep(0.05)

    welcome = client.welcome_info()
    if welcome is None:
        _log.error("No welcome from %s after 5 s — server unreachable or full", addr)
        client.stop()
        return
    game_map = _map_from_welcome(welcome)
    entity_id = welcome.get("entity_id", 1)
    cg = ClientGame(
        client,
        game_map,
        initial_static_objects=welcome.get("static_objects", []),
        ambient=float(welcome.get("ambient", 0.35)),
        fog_params=_fog_from_welcome(welcome),
        type_catalogue=welcome.get("type_catalogue", {}),
    )

    stub_entity = Entity(
        entity_id=entity_id,
        char=ord("@"),
        fg_color=color,
        name=char_name,
        faction="player",
    )
    viewing_player = Player(username=username, entity=stub_entity)

    ui = GameUI(
        game=cg,
        tileset_path=_TILESET,
        viewing_player=viewing_player,
        panels=[LiveStatsPanel(cg, entity_id)],
    )
    ui.run()
    client.stop()


def _run_as_server(
    seed: int,
    serve_addr: str,
    headless: bool,
    username: str = "player1",
    char_name: str = "Hero",
    color: tuple[int, int, int] = _DEFAULT_COLOR,
    map_name: str = "cave",
) -> None:
    from faraway_realms.net.server import GameServer

    _load_content()
    game, _player = _build_game(seed, username, char_name, color, map_name)
    _subscribe_observability(game)
    host, port = _parse_addr(serve_addr)
    server = GameServer(game, host=host, port=port)

    if headless:
        asyncio.run(server.run())
    else:
        _start_server_thread(server)
        port = _wait_for_server(server)
        _run_as_client(f"{host}:{port}", username, char_name, color)


def _run_singleplayer(
    seed: int,
    username: str = "player1",
    char_name: str = "Hero",
    color: tuple[int, int, int] = _DEFAULT_COLOR,
    map_name: str = "cave",
) -> None:
    from faraway_realms.net.server import GameServer

    _load_content()
    game, _player = _build_game(seed, username, char_name, color, map_name)
    _subscribe_observability(game)
    server = GameServer(game, host="127.0.0.1", port=0)
    _start_server_thread(server)
    port = _wait_for_server(server)
    _run_as_client(f"127.0.0.1:{port}", username, char_name, color)


def main(
    seed: int = _MAP_SEED,
    serve: str | None = None,
    connect: str | None = None,
    headless: bool = False,
    username: str = "player1",
    char_name: str = "Hero",
    color: tuple[int, int, int] = _DEFAULT_COLOR,
    map_name: str = "cave",
    loki_url: str | None = None,
) -> None:
    """Bootstrap a default game and open the window."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)-8s %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )
    resolved_loki = loki_url or load_admin_settings().loki_url
    setup_game_logger(Path.home() / ".faraway_realms" / "logs", resolved_loki)
    from faraway_realms import __version__  # noqa: PLC0415

    _log.info("faraway-realms %s", __version__)
    if connect:
        _load_content()
        _run_as_client(connect, username, char_name, color)
    elif serve:
        _run_as_server(seed, serve, headless, username, char_name, color, map_name)
    else:
        _run_singleplayer(seed, username, char_name, color, map_name)


def cli() -> None:
    """Entry point: parse CLI arguments then call main()."""
    parser = argparse.ArgumentParser(prog="faraway-realms")
    parser.add_argument("seed", nargs="?", type=int, default=_MAP_SEED)
    parser.add_argument("--serve", default=None, metavar="HOST:PORT")
    parser.add_argument("--connect", default=None, metavar="HOST:PORT")
    parser.add_argument("--headless", action="store_true")
    parser.add_argument("--username", default="player1", metavar="NAME")
    parser.add_argument("--name", default=None, metavar="CHARNAME")
    parser.add_argument("--color", default="255,255,0", metavar="R,G,B")
    parser.add_argument("--map", default="cave", metavar="NAME", dest="map_name")
    parser.add_argument(
        "--loki-url",
        default=None,
        metavar="URL",
        help="Loki push URL (e.g. http://localhost:3100). Overrides settings.yaml.",
    )
    args = parser.parse_args()
    char_name = args.name or args.username
    color = _parse_color(args.color)
    main(
        seed=args.seed,
        serve=args.serve,
        connect=args.connect,
        headless=args.headless,
        username=args.username,
        char_name=char_name,
        color=color,
        map_name=args.map_name,
        loki_url=args.loki_url,
    )


if __name__ == "__main__":
    cli()
