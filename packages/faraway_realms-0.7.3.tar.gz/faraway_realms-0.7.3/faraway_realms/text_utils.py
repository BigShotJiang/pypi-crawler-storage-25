"""Shared text utility functions."""

from __future__ import annotations

from faraway_realms.types import Color


def wrap_text(
    text: str,
    color: Color,
    width: int,
    indent: str = "",
) -> list[tuple[str, Color]]:
    """Wrap *text* into lines of at most *width* columns.

    Parameters
    ----------
    text : str
        Input text to wrap.
    color : Color
        Foreground colour applied to every output line.
    width : int
        Maximum total line width including *indent*.
    indent : str
        Prefix prepended to every output line (counts toward *width*).

    Returns
    -------
    list[tuple[str, Color]]
        Wrapped lines as ``(text, color)`` pairs.
    """
    max_text = width - len(indent)
    words = text.split()
    lines: list[tuple[str, Color]] = []
    current = ""
    for word in words:
        if current and len(current) + 1 + len(word) > max_text:
            lines.append((indent + current, color))
            current = word
        else:
            current = f"{current} {word}".lstrip() if current else word
    if current:
        lines.append((indent + current, color))
    return lines
