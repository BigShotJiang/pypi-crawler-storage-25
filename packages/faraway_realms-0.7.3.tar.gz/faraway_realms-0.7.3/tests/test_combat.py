"""Tests for the combat system."""

from faraway_realms.ai.behaviour import StateMachineBehaviour, WanderState
from faraway_realms.chat import NPC_HIT_COLOR, PLAYER_HIT_COLOR
from faraway_realms.combat.stats import Pool, Stat
from faraway_realms.entities.entity import CharacterEntity, NonPlayerEntity, Player
from faraway_realms.game import Game
from faraway_realms.world.commands import Command, CommandParser, CommandType
from faraway_realms.world.event_bus import EventBus
from faraway_realms.world.events import Event, EventType
from faraway_realms.world.factions import FactionRelations
from faraway_realms.world.map import make_bordered_map


def _make_game() -> tuple[Game, Player]:
    game_map = make_bordered_map(20, 20)
    entity = CharacterEntity(
        entity_id=1,
        char=ord("@"),
        fg_color=(255, 255, 0),
        name="Hero",
        faction="player",
        stats={"health": Pool(base=100), "strength": Stat(base=5)},
    )
    player = Player(username="tester", entity=entity)
    relations = FactionRelations()
    relations.set_hostile("player", "hostile", True)
    game = Game(game_map=game_map, faction_relations=relations)
    game.add_player(player)
    game_map.place_entity(entity.entity_id, 10, 10)
    return game, player


def _hostile_npc(
    entity_id: int,
    x: int,
    y: int,
    game: Game,
    health: int = 20,
    strength: int = 3,
    attack_every: int = 1,
) -> NonPlayerEntity:
    npc = NonPlayerEntity(
        entity_id=entity_id,
        char=ord("Z"),
        fg_color=(0, 180, 0),
        name="Zombie",
        faction="hostile",
        attack_every=attack_every,
        stats={"health": Pool(base=health), "strength": Stat(base=strength)},
    )
    game.add_npc(npc)
    game.game_map.place_entity(npc.entity_id, x, y)
    return npc


# ---------------------------------------------------------------------------
# Targeting
# ---------------------------------------------------------------------------


def test_target_command_sets_target_id() -> None:
    game, player = _make_game()
    _hostile_npc(2, 12, 10, game)
    game.enqueue_command(
        Command(
            command_type=CommandType.TARGET,
            actor="@self",
            args=("2",),
            raw="/target @self 2",
        )
    )
    game.tick()
    assert player.entity.target_id == 2


def test_target_command_clears_target() -> None:
    game, player = _make_game()
    player.entity.target_id = 2
    game.enqueue_command(
        Command(
            command_type=CommandType.TARGET, actor="@self", args=(), raw="/target @self"
        )
    )
    game.tick()
    assert player.entity.target_id is None


def test_target_command_unknown_entity_is_noop() -> None:
    game, player = _make_game()
    game.enqueue_command(
        Command(
            command_type=CommandType.TARGET,
            actor="@self",
            args=("9999",),
            raw="/target @self 9999",
        )
    )
    game.tick()  # should not raise; maintain_los clears unknown targets after tick
    assert player.entity.target_id is None


def test_at_target_resolves_to_current_target() -> None:
    game, player = _make_game()
    npc = _hostile_npc(2, 11, 10, game, health=50, attack_every=1)
    player.entity.target_id = npc.entity_id

    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK,
            actor="@self",
            args=("@target",),
            raw="/attack @self @target",
        )
    )
    game.tick()

    npc_health: Pool = npc.stats["health"]  # type: ignore[assignment]
    assert npc_health.current < 50  # damage landed


def test_at_target_with_no_target_set_is_noop() -> None:
    game, player = _make_game()
    npc = _hostile_npc(2, 11, 10, game, health=50, attack_every=1)
    assert player.entity.target_id is None

    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK,
            actor="@self",
            args=("@target",),
            raw="/attack @self @target",
        )
    )
    game.tick()

    npc_health: Pool = npc.stats["health"]  # type: ignore[assignment]
    assert npc_health.current == 50  # no damage — target was unset


def test_target_command_parser() -> None:
    parser = CommandParser()
    cmd = parser.parse("/target @self 5")
    assert cmd.command_type == CommandType.TARGET
    assert cmd.actor == "@self"
    assert cmd.args == ("5",)


# ---------------------------------------------------------------------------
# Contact resolution
# ---------------------------------------------------------------------------


def test_mover_attacks_on_contact_npc_vs_npc() -> None:
    """Mover (source) always gets the contact attack command."""
    game, _ = _make_game()
    _hostile_npc(2, 11, 10, game)
    _hostile_npc(3, 12, 10, game)

    from faraway_realms.world.events import Event

    game.emit_event(
        Event(event_type=EventType.CONTACT, source_id=2, target_id=3, resolve_at_tick=0)
    )
    game._drain_events()  # noqa: SLF001

    attack_cmds = [
        c for c in game._command_queue if c.command_type == CommandType.ATTACK
    ]
    assert any(c.actor == "2" for c in attack_cmds)


def test_contact_sets_both_targets() -> None:
    """Both mover and defender get auto-targeted on contact."""
    game, _ = _make_game()
    npc_a = _hostile_npc(2, 11, 10, game)
    npc_b = _hostile_npc(3, 12, 10, game)

    from faraway_realms.world.events import Event

    game.emit_event(
        Event(event_type=EventType.CONTACT, source_id=2, target_id=3, resolve_at_tick=0)
    )
    game._drain_events()  # noqa: SLF001

    assert npc_a.target_id == 3
    assert npc_b.target_id == 2


def test_player_does_not_auto_retaliate_on_contact() -> None:
    """Player must never get an auto-queued attack from a CONTACT event.

    Auto-targeting still fires; only the automatic attack command is suppressed.
    """
    game, player = _make_game()
    _hostile_npc(2, 11, 10, game)
    player.entity.target_id = 2  # player was already targeting the NPC

    from faraway_realms.world.events import Event

    game.emit_event(
        Event(event_type=EventType.CONTACT, source_id=2, target_id=1, resolve_at_tick=0)
    )
    game._drain_events()  # noqa: SLF001

    player_attacks = [
        c
        for c in game._command_queue  # noqa: SLF001
        if c.command_type == CommandType.ATTACK and c.actor == "1"
    ]
    assert not player_attacks


def test_contact_does_not_overwrite_existing_target() -> None:
    """Auto-target on contact must not overwrite a target already set."""
    game, player = _make_game()
    _hostile_npc(2, 11, 10, game)
    _hostile_npc(3, 11, 11, game)
    player.entity.target_id = 3  # targeting a different enemy

    from faraway_realms.world.events import Event

    game.emit_event(
        Event(event_type=EventType.CONTACT, source_id=2, target_id=1, resolve_at_tick=0)
    )
    game._drain_events()  # noqa: SLF001

    assert player.entity.target_id == 3


def test_auto_target_set_on_surprise() -> None:
    game, player = _make_game()
    _hostile_npc(2, 11, 10, game)
    assert player.entity.target_id is None

    from faraway_realms.world.events import Event

    game.emit_event(
        Event(event_type=EventType.CONTACT, source_id=2, target_id=1, resolve_at_tick=0)
    )
    game._drain_events()  # noqa: SLF001

    assert player.entity.target_id == 2


# ---------------------------------------------------------------------------
# Damage formula
# ---------------------------------------------------------------------------


def test_attack_applies_strength_damage() -> None:
    game, player = _make_game()
    _hostile_npc(2, 11, 10, game, strength=7)
    health: Pool = player.entity.stats["health"]  # type: ignore[assignment]

    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK,
            actor="2",
            args=("1",),
            raw="/attack 2 1",
        )
    )
    game.tick()
    assert health.current == 100 - 7


def test_attack_out_of_melee_range_does_no_damage() -> None:
    game, _ = _make_game()
    npc = _hostile_npc(
        2, 15, 10, game, health=50
    )  # 5 tiles away from player at (10,10)

    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK, actor="1", args=("2",), raw="/attack 1 2"
        )
    )
    game.tick()

    npc_health: Pool = npc.stats["health"]  # type: ignore[assignment]
    assert npc_health.current == 50  # out of range — no damage


def test_attack_diagonal_melee_range_hits() -> None:
    game, _ = _make_game()
    npc = _hostile_npc(
        2, 11, 11, game, health=50
    )  # diagonally adjacent to player at (10,10)

    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK, actor="1", args=("2",), raw="/attack 1 2"
        )
    )
    game.tick()

    npc_health: Pool = npc.stats["health"]  # type: ignore[assignment]
    assert npc_health.current < 50  # diagonal is valid melee range


def test_attack_defaults_to_1_damage_when_no_strength() -> None:
    game, player = _make_game()
    npc = NonPlayerEntity(
        entity_id=2,
        char=ord("X"),
        fg_color=(0, 0, 0),
        name="Weak",
        faction="hostile",
        attack_every=1,
        stats={"health": Pool(base=10)},  # no strength
    )
    game.add_npc(npc)
    game.game_map.place_entity(npc.entity_id, 11, 10)
    health: Pool = player.entity.stats["health"]  # type: ignore[assignment]

    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK, actor="2", args=("1",), raw="/attack 2 1"
        )
    )
    game.tick()
    assert health.current == 99


def test_attack_no_crash_when_target_has_no_health_pool() -> None:
    game, _ = _make_game()
    npc = NonPlayerEntity(
        entity_id=2,
        char=ord("X"),
        fg_color=(0, 0, 0),
        name="Indestructible",
        faction="hostile",
        attack_every=1,
        stats={},  # no health pool, no death_stat hit
    )
    game.add_npc(npc)
    game.game_map.place_entity(npc.entity_id, 11, 10)

    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK, actor="1", args=("2",), raw="/attack 1 2"
        )
    )
    game.tick()  # should not raise


# ---------------------------------------------------------------------------
# Attack cooldown
# ---------------------------------------------------------------------------


def test_attack_cooldown_limits_rate() -> None:
    game, player = _make_game()
    _hostile_npc(2, 11, 10, game, health=200, strength=10)
    health: Pool = player.entity.stats["health"]  # type: ignore[assignment]

    # NPC has attack_every=1 (default in _hostile_npc helper)
    # Spam 5 attack commands in the same tick
    for _ in range(5):
        game.enqueue_command(
            Command(
                command_type=CommandType.ATTACK,
                actor="2",
                args=("1",),
                raw="/attack 2 1",
            )
        )
    game.tick()
    # Only one should land (cooldown = 1 tick, all in same tick)
    assert health.current == 100 - 10


def test_attack_fires_again_after_cooldown() -> None:
    game, player = _make_game()
    _hostile_npc(2, 11, 10, game, strength=10, attack_every=2)
    health: Pool = player.entity.stats["health"]  # type: ignore[assignment]

    # Tick 1: first attack lands
    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK, actor="2", args=("1",), raw="/attack 2 1"
        )
    )
    game.tick()
    assert health.current == 90

    # Tick 2: still on cooldown (attack_every=2)
    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK, actor="2", args=("1",), raw="/attack 2 1"
        )
    )
    game.tick()
    assert health.current == 90  # no damage

    # Tick 3: cooldown expired
    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK, actor="2", args=("1",), raw="/attack 2 1"
        )
    )
    game.tick()
    assert health.current == 80


def test_npc_behaviour_respects_attack_cooldown() -> None:
    """NPC emits ATTACK every tick via behaviour; cooldown must gate actual hits."""
    game, player = _make_game()
    health: Pool = player.entity.stats["health"]  # type: ignore[assignment]

    # NPC adjacent to player, attack_every=4, behaviour drives ATTACK each tick
    npc = NonPlayerEntity(
        entity_id=2,
        char=ord("Z"),
        fg_color=(0, 180, 0),
        name="Zombie",
        faction="hostile",
        move_every=1,
        attack_every=4,
        behaviour=StateMachineBehaviour(WanderState(sight_range=10)),
        stats={"health": Pool(base=100), "strength": Stat(base=10)},
    )
    game.add_npc(npc)
    game.game_map.place_entity(npc.entity_id, 11, 10)
    from faraway_realms.ai.behaviour import ChaseState

    npc.behaviour._state = ChaseState(sight_range=10, target_id=player.entity.entity_id)  # noqa: SLF001

    # Run 8 ticks — cooldown of 4 means exactly 2 hits should land
    for _ in range(8):
        game.tick()

    assert health.current == 100 - 10 * 2


def test_attack_speed_exceeding_base_floors_to_1() -> None:
    """Effective cooldown can never go below 1 tick."""
    game, player = _make_game()
    player.entity.attack_every = 3
    player.entity.stats["attack_speed"] = Stat(base=99)  # would give negative cooldown
    npc = _hostile_npc(2, 11, 10, game, health=200)
    npc_health: Pool = npc.stats["health"]  # type: ignore[assignment]

    # Fire twice in consecutive ticks — should land both times (cooldown = 1)
    for _ in range(2):
        game.enqueue_command(
            Command(
                command_type=CommandType.ATTACK,
                actor="1",
                args=("2",),
                raw="/attack 1 2",
            )
        )
        game.tick()

    assert npc_health.current == 200 - 5 * 2  # both hits landed


def test_attack_speed_stat_reduces_cooldown() -> None:
    game, player = _make_game()
    player.entity.attack_every = 10
    player.entity.stats["attack_speed"] = Stat(
        base=8
    )  # effective cooldown = max(1, 10-8) = 2
    npc = _hostile_npc(2, 11, 10, game, health=200)
    npc_health: Pool = npc.stats["health"]  # type: ignore[assignment]

    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK, actor="1", args=("2",), raw="/attack 1 2"
        )
    )
    game.tick()
    first_hp = npc_health.current

    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK, actor="1", args=("2",), raw="/attack 1 2"
        )
    )
    game.tick()
    assert npc_health.current == first_hp  # still on 2-tick cooldown

    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK, actor="1", args=("2",), raw="/attack 1 2"
        )
    )
    game.tick()
    assert npc_health.current < first_hp  # fired again after cooldown


# ---------------------------------------------------------------------------
# Death
# ---------------------------------------------------------------------------


def test_death_event_emitted_when_health_reaches_zero() -> None:
    game, _ = _make_game()
    _hostile_npc(2, 11, 10, game, health=3, strength=5)

    death_called = []
    game._bus.subscribe(EventType.ENTITY_DYING, death_called.append, priority=15)  # noqa: SLF001

    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK, actor="1", args=("2",), raw="/attack 1 2"
        )
    )
    game.tick()
    assert any(e.source_id == 2 for e in death_called)


def test_death_removes_entity_from_map() -> None:
    game, _ = _make_game()
    _hostile_npc(2, 11, 10, game, health=3)
    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK, actor="1", args=("2",), raw="/attack 1 2"
        )
    )
    game.tick()
    assert not game.game_map.has_entity(2)


def test_death_removes_entity_from_entities() -> None:
    game, _ = _make_game()
    _hostile_npc(2, 11, 10, game, health=3)
    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK, actor="1", args=("2",), raw="/attack 1 2"
        )
    )
    game.tick()
    assert 2 not in game._entities  # noqa: SLF001


def test_death_removes_npc_from_npcs() -> None:
    game, _ = _make_game()
    npc = _hostile_npc(2, 11, 10, game, health=3)
    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK, actor="1", args=("2",), raw="/attack 1 2"
        )
    )
    game.tick()
    assert npc not in game._npcs  # noqa: SLF001


def test_death_clears_target_references() -> None:
    game, player = _make_game()
    _hostile_npc(2, 11, 10, game, health=3)
    player.entity.target_id = 2

    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK, actor="1", args=("2",), raw="/attack 1 2"
        )
    )
    game.tick()
    assert player.entity.target_id is None


def test_death_clears_targets_for_all_entities() -> None:
    """Multiple entities targeting the deceased all get cleared."""
    game, player = _make_game()
    _hostile_npc(2, 11, 10, game, health=3)
    npc_b = _hostile_npc(3, 12, 10, game)
    player.entity.target_id = 2
    npc_b.target_id = 2  # second entity also targeting the doomed NPC

    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK, actor="1", args=("2",), raw="/attack 1 2"
        )
    )
    game.tick()
    assert player.entity.target_id is None
    assert npc_b.target_id is None


# ---------------------------------------------------------------------------
# Opportunity attack
# ---------------------------------------------------------------------------


def test_opportunity_attack_emitted_when_fleeing_targeted_entity() -> None:
    game, player = _make_game()
    npc = _hostile_npc(2, 11, 10, game)  # adjacent to player at (10,10)
    npc.target_id = 1  # NPC is targeting the player

    contact_events = []
    game._bus.subscribe(EventType.CONTACT, contact_events.append, priority=15)  # noqa: SLF001

    # Player moves left (away from NPC)
    parser = CommandParser()
    game.enqueue_command(parser.parse("/move left"))
    game.tick()

    # Player should still have moved
    assert game.game_map.get_entity_position(1) == (9, 10)
    # Opportunity attack CONTACT should have fired with NPC as source
    assert any(e.source_id == 2 and e.target_id == 1 for e in contact_events)


def test_no_opportunity_attack_when_not_targeted() -> None:
    game, player = _make_game()
    npc = _hostile_npc(2, 11, 10, game)
    npc.target_id = None  # NPC is not targeting anyone
    npc.move_every = 100  # prevent random movement from generating unrelated contact

    contact_events = []
    game._bus.subscribe(EventType.CONTACT, contact_events.append, priority=15)  # noqa: SLF001

    parser = CommandParser()
    game.enqueue_command(parser.parse("/move left"))
    game.tick()

    assert not any(e.source_id == 2 and e.target_id == 1 for e in contact_events)


def test_opportunity_contact_enqueues_opportunity_attack_command_type() -> None:
    """CONTACT with opportunity payload must produce OPPORTUNITY_ATTACK, not ATTACK."""
    from faraway_realms.world.events import Event

    game, _ = _make_game()
    _hostile_npc(2, 11, 10, game)

    game.emit_event(
        Event(
            event_type=EventType.CONTACT,
            source_id=2,
            target_id=1,
            resolve_at_tick=0,
            payload={"opportunity": True},
        )
    )
    game._drain_events()  # noqa: SLF001

    opp_cmds = [
        c
        for c in game._command_queue  # noqa: SLF001
        if c.command_type == CommandType.OPPORTUNITY_ATTACK
    ]
    assert any(c.actor == "2" for c in opp_cmds)


def test_opportunity_attack_source_wins_initiative_even_when_player_prepared() -> None:
    """Regression: player targeting NPC must NOT win initiative on opportunity attack.

    Old bug: ContactResolutionSystem saw player.target_id == npc_id and gave the
    player initiative, so the NPC's opportunity attack silently became a player attack.
    """
    game, player = _make_game()
    npc = _hostile_npc(2, 11, 10, game, health=100, strength=8)
    npc.target_id = 1  # NPC is targeting the player
    player.entity.target_id = (
        2  # player already targeting NPC (the trigger of the old bug)
    )

    player_health: Pool = player.entity.stats["health"]  # type: ignore[assignment]
    npc_health: Pool = npc.stats["health"]  # type: ignore[assignment]

    parser = CommandParser()
    game.enqueue_command(parser.parse("/move left"))
    game.tick()  # move executes, OPPORTUNITY_ATTACK enqueued
    game.tick()  # OPPORTUNITY_ATTACK processed (one-tick delay, same as all contact)

    # NPC must deal damage to the player (opportunity attack fired correctly)
    assert player_health.current < 100
    # Player must NOT have dealt damage to the NPC via the opportunity attack
    assert npc_health.current == 100


def test_opportunity_attack_bypasses_cooldown() -> None:
    """Regression: opportunity attack must land even when attacker is on cooldown.

    Old bug: NPC attacks every tick, so its cooldown is always fresh.  When the
    player flees the damage was silently swallowed by the cooldown gate.
    """
    game, player = _make_game()
    npc = _hostile_npc(2, 11, 10, game, health=100, strength=8, attack_every=100)
    npc.target_id = 1

    player_health: Pool = player.entity.stats["health"]  # type: ignore[assignment]

    # First hit lands and records the tick, setting a 100-tick cooldown
    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK, actor="2", args=("1",), raw="/attack 2 1"
        )
    )
    game.tick()
    hp_after_first = player_health.current
    assert hp_after_first < 100  # sanity: first hit landed

    # Player flees — NPC opp attack must bypass the 100-tick cooldown
    parser = CommandParser()
    game.enqueue_command(parser.parse("/move left"))
    game.tick()  # move executes, OPPORTUNITY_ATTACK enqueued
    game.tick()  # OPPORTUNITY_ATTACK processed — bypass_cooldown=True skips the gate
    assert player_health.current < hp_after_first  # opp attack landed despite cooldown


def test_no_opportunity_attack_when_destination_still_adjacent() -> None:
    """Moving while adjacent but staying in melee range must not trigger OA.

    Regression: a chasing NPC stepping diagonally (still adjacent after the move)
    was incorrectly giving the player a free opportunity attack every step.
    """
    game, _ = _make_game()
    # Player at (10,10). NPC at (11,10). NPC targets player.
    npc = _hostile_npc(2, 11, 10, game)
    npc.target_id = 1

    contact_events = []
    game._bus.subscribe(EventType.CONTACT, contact_events.append, priority=15)  # noqa: SLF001

    # NPC moves up to (11,9) — still adjacent (diagonal) to player at (10,10)
    game.enqueue_command(
        Command(
            command_type=CommandType.MOVE, actor="2", args=("up",), raw="/move 2 up"
        )
    )
    game.tick()

    # (11,9) is still adjacent to (10,10): no OA should fire with NPC as mover
    opp_events = [
        e for e in contact_events if e.payload and e.payload.get("opportunity")
    ]
    assert not any(e.target_id == 2 for e in opp_events)


def test_no_opportunity_attack_when_not_adjacent() -> None:
    game, _ = _make_game()
    npc = _hostile_npc(2, 15, 10, game)  # 5 tiles away
    npc.target_id = 1

    contact_events = []
    game._bus.subscribe(EventType.CONTACT, contact_events.append, priority=15)  # noqa: SLF001

    parser = CommandParser()
    game.enqueue_command(parser.parse("/move left"))
    game.tick()

    assert not any(e.source_id == 2 and e.target_id == 1 for e in contact_events)


# ---------------------------------------------------------------------------
# Integration
# ---------------------------------------------------------------------------


def test_full_combat_kills_weak_npc() -> None:
    game, _ = _make_game()
    _hostile_npc(2, 11, 10, game, health=5, strength=1, attack_every=1)

    # Player (strength=5) adjacent to NPC (health=5): one hit kills
    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK, actor="1", args=("2",), raw="/attack 1 2"
        )
    )
    game.tick()
    assert not game.game_map.has_entity(2)


def test_subsequent_ticks_safe_after_npc_death() -> None:
    game, _ = _make_game()
    _hostile_npc(2, 11, 10, game, health=3, attack_every=1)

    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK, actor="1", args=("2",), raw="/attack 1 2"
        )
    )
    game.tick()

    # Run a few more ticks without errors
    for _ in range(5):
        game.tick()


# ---------------------------------------------------------------------------
# Combat log messages
# ---------------------------------------------------------------------------


def test_npc_hit_logged_with_dark_red_color() -> None:
    game, player = _make_game()
    _hostile_npc(2, 11, 10, game, strength=4, attack_every=1)

    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK, actor="2", args=("1",), raw="/attack 2 1"
        )
    )
    game.tick()

    messages = game.get_chat_history()
    assert len(messages) == 1
    assert messages[0].text == "Zombie hits Hero for 4"
    assert messages[0].color == NPC_HIT_COLOR


def test_player_hit_logged_with_yellow_color() -> None:
    game, _ = _make_game()
    _hostile_npc(2, 11, 10, game, health=50, attack_every=1)

    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK, actor="1", args=("2",), raw="/attack 1 2"
        )
    )
    game.tick()

    messages = game.get_chat_history()
    assert len(messages) == 1
    assert messages[0].text == "Hero hits Zombie for 5"
    assert messages[0].color == PLAYER_HIT_COLOR


# ---------------------------------------------------------------------------
# Cooldown fraction
# ---------------------------------------------------------------------------


def test_cooldown_fraction_is_zero_before_any_prime() -> None:
    """Entity that has never been primed shows empty bar (fraction = 0.0)."""
    game, player = _make_game()
    assert game.attack_cooldown_fraction(player.entity.entity_id) == 0.0


def test_cooldown_fraction_is_zero_immediately_after_attack() -> None:
    """Fraction = 0.0 on the tick the attack lands."""
    game, _ = _make_game()
    _hostile_npc(2, 11, 10, game, health=200, attack_every=10)

    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK, actor="1", args=("2",), raw="/attack 1 2"
        )
    )
    game.tick()  # abs_tick becomes 1, last_attack_tick[1] = 1

    assert game.attack_cooldown_fraction(1) == 0.0


def test_cooldown_fraction_midway() -> None:
    """Fraction = 0.5 halfway through the cooldown window."""
    game, player = _make_game()
    player.entity.attack_every = 10
    _hostile_npc(2, 11, 10, game, health=200, attack_every=10)

    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK, actor="1", args=("2",), raw="/attack 1 2"
        )
    )
    game.tick()  # tick 1: attack lands, cooldown = 10

    # Run 5 more ticks without attacking
    for _ in range(5):
        game.tick()  # ticks 2–6; elapsed = 5 of 10 → fraction = 0.5

    assert game.attack_cooldown_fraction(1) == 0.5


def test_cooldown_fraction_caps_at_one() -> None:
    """Fraction never exceeds 1.0, even many ticks after the cooldown expires."""
    game, _ = _make_game()
    _hostile_npc(2, 11, 10, game, health=200, attack_every=2)

    # Land an attack at tick 1
    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK, actor="1", args=("2",), raw="/attack 1 2"
        )
    )
    game.tick()

    # Advance 50 more ticks — far past the 2-tick cooldown
    for _ in range(50):
        game.tick()

    assert game.attack_cooldown_fraction(1) == 1.0


def test_cooldown_fraction_unknown_entity_returns_zero() -> None:
    """Unknown (never-primed) entity ID returns 0.0 (bar starts empty)."""
    game, _ = _make_game()
    assert game.attack_cooldown_fraction(99999) == 0.0


def test_no_combat_log_when_attack_blocked_by_cooldown() -> None:
    game, _ = _make_game()
    _hostile_npc(2, 11, 10, game, health=50, attack_every=5)

    attack_cmd = Command(
        command_type=CommandType.ATTACK, actor="1", args=("2",), raw="/attack 1 2"
    )
    game.enqueue_command(attack_cmd)
    game.tick()  # first hit lands

    player_hits = [m for m in game.get_chat_history() if m.text.startswith("Hero hits")]
    assert len(player_hits) == 1

    game.enqueue_command(attack_cmd)
    game.tick()  # blocked by cooldown — no new player-hit message

    player_hits = [m for m in game.get_chat_history() if m.text.startswith("Hero hits")]
    assert len(player_hits) == 1


# ---------------------------------------------------------------------------
# Armor and damage types
# ---------------------------------------------------------------------------


def _cs_with_bus(entities: dict) -> tuple:
    """Return (CombatSystem, EventBus, hits_list) for unit tests."""
    from faraway_realms.systems.combat import CombatSystem

    bus = EventBus()
    hits: list = []
    bus.subscribe(EventType.ENTITY_HIT, hits.append)
    cs = CombatSystem(entities, bus)
    return cs, bus, hits


def test_armor_reduces_damage() -> None:
    entities: dict = {}
    attacker = CharacterEntity(
        entity_id=1,
        char=ord("@"),
        fg_color=(255, 255, 0),
        name="Hero",
        stats={"strength": Stat(base=5)},
    )
    target = NonPlayerEntity(
        entity_id=2,
        char=ord("Z"),
        fg_color=(0, 180, 0),
        name="Zombie",
        stats={"health": Pool(base=100), "armor": Stat(base=3)},
    )
    entities[1] = attacker
    entities[2] = target
    cs, bus, hits = _cs_with_bus(entities)
    cs.handle(1, 2, abs_tick=1)
    bus.flush(abs_tick=1)
    assert hits[0].payload["damage"] == 2  # str=5, armor=3, mult=1.0 → max(1, 2)


def test_armor_cannot_reduce_below_1() -> None:
    entities: dict = {}
    attacker = CharacterEntity(
        entity_id=1,
        char=ord("@"),
        fg_color=(255, 255, 0),
        name="Hero",
        stats={"strength": Stat(base=2)},
    )
    target = NonPlayerEntity(
        entity_id=2,
        char=ord("Z"),
        fg_color=(0, 180, 0),
        name="Zombie",
        stats={"health": Pool(base=100), "armor": Stat(base=10)},
    )
    entities[1] = attacker
    entities[2] = target
    cs, bus, hits = _cs_with_bus(entities)
    cs.handle(1, 2, abs_tick=1)
    bus.flush(abs_tick=1)
    assert hits[0].payload["damage"] == 1  # max(1, ...) floor


def test_type_effectiveness_multiplies() -> None:
    entities: dict = {}
    attacker = CharacterEntity(
        entity_id=1,
        char=ord("@"),
        fg_color=(255, 255, 0),
        name="Hero",
        damage_type="bludgeoning",
        stats={"strength": Stat(base=4)},
    )
    target = NonPlayerEntity(
        entity_id=2,
        char=ord("G"),
        fg_color=(140, 130, 110),
        name="Golem",
        armor_type="stone",
        stats={"health": Pool(base=200)},
    )
    entities[1] = attacker
    entities[2] = target
    cs, bus, hits = _cs_with_bus(entities)
    cs.handle(1, 2, abs_tick=1)
    bus.flush(abs_tick=1)
    # str=4, armor=0, mult=1.5 → round(4*1.5)=6
    assert hits[0].payload["damage"] == 6


# ---------------------------------------------------------------------------
# Critical hits
# ---------------------------------------------------------------------------


def test_crit_deals_double_damage() -> None:
    from unittest.mock import patch

    entities: dict = {}
    attacker = CharacterEntity(
        entity_id=1,
        char=ord("@"),
        fg_color=(255, 255, 0),
        name="Hero",
        stats={"strength": Stat(base=5), "crit_chance": Stat(base=50)},
    )
    target = NonPlayerEntity(
        entity_id=2,
        char=ord("Z"),
        fg_color=(0, 180, 0),
        name="Zombie",
        stats={"health": Pool(base=200)},
    )
    entities[1] = attacker
    entities[2] = target
    cs, bus, hits = _cs_with_bus(entities)

    with patch("faraway_realms.systems.combat.random.randint", return_value=1):
        cs.handle(1, 2, abs_tick=1)
    bus.flush(abs_tick=1)

    assert hits[0].payload["crit"] is True
    assert hits[0].payload["damage"] == 10  # 5 * 2


def test_no_crit_when_crit_chance_zero() -> None:
    entities: dict = {}
    attacker = CharacterEntity(
        entity_id=1,
        char=ord("@"),
        fg_color=(255, 255, 0),
        name="Hero",
        stats={"strength": Stat(base=5)},
    )
    target = NonPlayerEntity(
        entity_id=2,
        char=ord("Z"),
        fg_color=(0, 180, 0),
        name="Zombie",
        stats={"health": Pool(base=200)},
    )
    entities[1] = attacker
    entities[2] = target
    cs, bus, hits = _cs_with_bus(entities)

    for tick in range(1, 50):
        cs.handle(1, 2, abs_tick=tick, bypass_cooldown=True)
    bus.flush(abs_tick=100)
    assert all(not h.payload["crit"] for h in hits)


def test_crit_result_flag_true_on_forced_crit() -> None:
    from unittest.mock import patch

    entities: dict = {}
    attacker = CharacterEntity(
        entity_id=1,
        char=ord("@"),
        fg_color=(255, 255, 0),
        name="Hero",
        stats={"strength": Stat(base=5), "crit_chance": Stat(base=1)},
    )
    target = NonPlayerEntity(
        entity_id=2,
        char=ord("Z"),
        fg_color=(0, 180, 0),
        name="Zombie",
        stats={"health": Pool(base=200)},
    )
    entities[1] = attacker
    entities[2] = target
    cs, bus, hits = _cs_with_bus(entities)

    with patch("faraway_realms.systems.combat.random.randint", return_value=1):
        cs.handle(1, 2, abs_tick=1)
    bus.flush(abs_tick=1)
    assert hits[0].payload["crit"] is True

    with patch("faraway_realms.systems.combat.random.randint", return_value=2):
        cs.handle(1, 2, abs_tick=2, bypass_cooldown=True)
    bus.flush(abs_tick=2)
    assert hits[1].payload["crit"] is False


# ---------------------------------------------------------------------------
# Stagger — WoW-style pushback: extends remaining cooldown mid-swing only
# ---------------------------------------------------------------------------


def _stagger_setup(
    attacker_strength: int,
    target_attack_every: int,
) -> tuple:
    """Return (CombatSystem, attacker_id, target_id) with entities registered."""
    from faraway_realms.systems.combat import CombatSystem

    entities: dict = {}
    attacker = CharacterEntity(
        entity_id=1,
        char=ord("@"),
        fg_color=(255, 255, 0),
        name="Hero",
        attack_every=1,
        stats={"strength": Stat(base=attacker_strength), "health": Pool(base=100)},
    )
    target = NonPlayerEntity(
        entity_id=2,
        char=ord("Z"),
        fg_color=(0, 180, 0),
        name="Zombie",
        attack_every=target_attack_every,
        stats={"health": Pool(base=200), "strength": Stat(base=2)},
    )
    entities[1] = attacker
    entities[2] = target
    bus = EventBus()
    return CombatSystem(entities, bus), 1, 2


def test_stagger_pushes_back_mid_cooldown_target() -> None:
    # Target attacks at tick 1 (last=1, attack_every=20, ready at tick 21).
    # Player hits target at tick 5 (4 ticks into a 20-tick cooldown).
    # pushback = max(1, 4//2)=2 → new last=min(5, 1+2)=3 → ready at tick 23.
    # fraction at tick 5: (5-3)/20 = 0.1, vs 0.2 without stagger.
    cs, attacker_id, target_id = _stagger_setup(
        attacker_strength=4, target_attack_every=20
    )
    cs.handle(target_id, attacker_id, abs_tick=1)  # target swings first
    cs.handle(attacker_id, target_id, abs_tick=5)  # player hits mid-cooldown
    assert cs.cooldown_fraction(target_id, abs_tick=5) < 0.2


def test_no_stagger_when_target_already_ready() -> None:
    # Target that has never attacked: stagger check uses -(10**9) sentinel so
    # elapsed is huge, target is considered "fully ready" — no stagger applied.
    cs, attacker_id, target_id = _stagger_setup(
        attacker_strength=4, target_attack_every=20
    )
    cs.handle(attacker_id, target_id, abs_tick=5)
    # target never primed → cooldown_fraction == 0.0 (untracked), stagger unchanged
    assert cs.cooldown_fraction(target_id, abs_tick=5) == 0.0


def test_no_stagger_when_cooldown_just_expired() -> None:
    # Target attacked at tick 1, attack_every=4. At tick 5 cooldown is exactly
    # expired (5-1=4 >= 4). Stagger must not apply.
    cs, attacker_id, target_id = _stagger_setup(
        attacker_strength=4, target_attack_every=4
    )
    cs.handle(target_id, attacker_id, abs_tick=1)
    cs.handle(attacker_id, target_id, abs_tick=5)
    # cooldown fully expired; stagger should not have pushed it back past 1.0
    assert cs.cooldown_fraction(target_id, abs_tick=5) == 1.0


def test_stagger_expires_naturally() -> None:
    # After pushback, the target becomes ready at the new (later) tick.
    # last pushed to 3, attack_every=20 → ready at tick 23.
    cs, attacker_id, target_id = _stagger_setup(
        attacker_strength=4, target_attack_every=20
    )
    cs.handle(target_id, attacker_id, abs_tick=1)
    cs.handle(attacker_id, target_id, abs_tick=5)
    assert cs.cooldown_fraction(target_id, abs_tick=23) == 1.0


def test_stagger_scales_with_strength() -> None:
    # Stronger attacker pushes the cooldown bar back further.
    # Both hit a target that attacked at tick 1; player hits at tick 5.
    cs_weak, a1, t1 = _stagger_setup(attacker_strength=2, target_attack_every=20)
    cs_strong, a2, t2 = _stagger_setup(attacker_strength=10, target_attack_every=20)

    for cs, attacker_id, target_id in ((cs_weak, a1, t1), (cs_strong, a2, t2)):
        cs.handle(target_id, attacker_id, abs_tick=1)  # target attacks at tick 1
        cs.handle(attacker_id, target_id, abs_tick=5)  # attacker hits at tick 5

    # Weak: pushback=1 → last=2 → frac=(5-2)/20=0.15
    # Strong: pushback=5 → last=min(5,1+5)=5 → frac=(5-5)/20=0.0
    assert cs_strong.cooldown_fraction(t2, abs_tick=5) < cs_weak.cooldown_fraction(
        t1, abs_tick=5
    )


# ---------------------------------------------------------------------------
# Critical hit — game-level integration
# ---------------------------------------------------------------------------


def test_crit_chat_message_prefixed() -> None:
    from unittest.mock import patch

    game, player = _make_game()
    player.entity.stats["crit_chance"] = Stat(base=100)
    _hostile_npc(2, 11, 10, game, health=200, attack_every=1)

    attack_cmd = Command(
        command_type=CommandType.ATTACK, actor="1", args=("2",), raw="/attack 1 2"
    )
    game.enqueue_command(attack_cmd)
    with patch("faraway_realms.systems.combat.random.randint", return_value=1):
        game.tick()

    msgs = [m.text for m in game.get_chat_history()]
    assert any(m.startswith("Critical!") for m in msgs)


def test_crit_seq_increments_on_player_crit() -> None:
    from unittest.mock import patch

    game, player = _make_game()
    player.entity.stats["crit_chance"] = Stat(base=100)
    _hostile_npc(2, 11, 10, game, health=200, attack_every=1)

    eid = player.entity.entity_id
    assert game.get_crit_dealt_seq(eid) == 0

    attack_cmd = Command(
        command_type=CommandType.ATTACK, actor="1", args=("2",), raw="/attack 1 2"
    )
    game.enqueue_command(attack_cmd)
    with patch("faraway_realms.systems.combat.random.randint", return_value=1):
        game.tick()

    assert game.get_crit_dealt_seq(eid) == 1


# ---------------------------------------------------------------------------
# Targeting primes cooldown
# ---------------------------------------------------------------------------


def _target_cmd(actor: str, target: str) -> Command:
    return Command(
        command_type=CommandType.TARGET,
        actor=actor,
        args=(target,),
        raw=f"/target {actor} {target}",
    )


def test_targeting_new_enemy_primes_cooldown() -> None:
    """Acquiring a new target starts the player's attack cooldown immediately."""
    game, player = _make_game()
    _hostile_npc(2, 11, 10, game)
    assert player.entity.target_id is None

    game.enqueue_command(_target_cmd("1", "2"))
    game.tick()

    # Cooldown was primed at tick 0; attacking immediately should be blocked.
    attack_cmd = Command(
        command_type=CommandType.ATTACK, actor="1", args=("2",), raw="/attack 1 2"
    )
    game.enqueue_command(attack_cmd)
    game.tick()

    assert player.entity.stats["health"].current == 100  # NPC was not hit yet


def test_targeting_same_enemy_does_not_reprime() -> None:
    """Re-targeting the same enemy must not reset the cooldown (exploit guard).

    After an attack, the cooldown is rebuilding.  Re-targeting the same enemy
    must not restart it back to zero — that would let the player spam tab to
    skip the cooldown.
    """
    game, player = _make_game()
    _hostile_npc(2, 11, 10, game, health=100, strength=1)

    # Target and let cooldown expire, then attack to consume it.
    game.enqueue_command(_target_cmd("1", "2"))
    for _ in range(6):
        game.tick()
    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK, actor="1", args=("2",), raw="/attack 1 2"
        )
    )
    game.tick()
    # Cooldown just reset to 0 from the attack; fraction is near 0.
    fraction_after_attack = game.attack_cooldown_fraction(player.entity.entity_id)

    # Re-target same enemy — must not push fraction back to 0.
    game.enqueue_command(_target_cmd("1", "2"))
    game.tick()
    fraction_after_retarget = game.attack_cooldown_fraction(player.entity.entity_id)

    # One tick has elapsed since attack; re-target must not reset the counter.
    assert fraction_after_retarget >= fraction_after_attack


def test_target_clear_does_not_prime() -> None:
    """Clearing the target must not reset the cooldown."""
    game, player = _make_game()
    _hostile_npc(2, 11, 10, game)

    # Target via command to prime, then wait for cooldown to expire.
    game.enqueue_command(_target_cmd("1", "2"))
    for _ in range(7):
        game.tick()
    assert game.attack_cooldown_fraction(player.entity.entity_id) == 1.0

    # Clear target — fraction must stay at 1.0.
    clear_cmd = Command(
        command_type=CommandType.TARGET, actor="1", args=(), raw="/target 1"
    )
    game.enqueue_command(clear_cmd)
    game.tick()

    assert player.entity.target_id is None
    assert game.attack_cooldown_fraction(player.entity.entity_id) == 1.0


def test_tab_cycle_to_new_target_primes_cooldown() -> None:
    """Tab-cycling to a new target also primes the cooldown."""
    game, player = _make_game()
    _hostile_npc(2, 11, 10, game)
    assert player.entity.target_id is None

    cycle_cmd = Command(
        command_type=CommandType.TARGET,
        actor="1",
        args=("next",),
        raw="/target 1 next",
    )
    game.enqueue_command(cycle_cmd)
    game.tick()

    assert player.entity.target_id == 2
    assert game.attack_cooldown_fraction(player.entity.entity_id) < 1.0


def test_contact_primes_player_cooldown_on_surprise() -> None:
    """Player cooldown starts when an NPC engages them without a prior target."""
    from faraway_realms.world.events import Event

    game, player = _make_game()
    _hostile_npc(2, 11, 10, game)
    assert player.entity.target_id is None

    game.emit_event(
        Event(event_type=EventType.CONTACT, source_id=2, target_id=1, resolve_at_tick=0)
    )
    game._drain_events()  # noqa: SLF001

    assert player.entity.target_id == 2
    assert game.attack_cooldown_fraction(player.entity.entity_id) < 1.0


def test_cooldown_resets_when_target_dies() -> None:
    """Cooldown bar resets to empty when the targeted entity dies."""
    game, player = _make_game()
    npc = _hostile_npc(2, 11, 10, game, health=1, attack_every=2)
    player.entity.attack_every = 1  # ready every tick

    target_cmd = Command(
        command_type=CommandType.TARGET, actor="1", args=("2",), raw="/target 1 2"
    )
    game.enqueue_command(target_cmd)
    game.tick()
    assert game.attack_cooldown_fraction(player.entity.entity_id) < 1.0

    attack_cmd = Command(
        command_type=CommandType.ATTACK, actor="1", args=("2",), raw="/attack 1 2"
    )
    game.enqueue_command(attack_cmd)
    game.tick()

    assert npc not in game._npcs  # noqa: SLF001
    assert player.entity.target_id is None
    assert game.attack_cooldown_fraction(player.entity.entity_id) == 0.0


# ---------------------------------------------------------------------------
# prime() guard — cooldown already full
# ---------------------------------------------------------------------------


def test_prime_noop_when_already_fully_charged() -> None:
    """prime(force=False) must not reset a cooldown that is already fully charged.

    Bug: NPC could arrive at melee range after chasing and prime() would reset
    the cooldown built up during the chase, forcing a full wait on contact.
    """
    from faraway_realms.systems.combat import CombatSystem

    entities: dict = {}
    npc = NonPlayerEntity(
        entity_id=2,
        char=ord("Z"),
        fg_color=(0, 180, 0),
        name="Zombie",
        faction="hostile",
        attack_every=5,
        stats={"health": Pool(base=20), "strength": Stat(base=3)},
    )
    entities[2] = npc
    cs = CombatSystem(entities, EventBus())

    # Record an attack at tick 0; advance to tick 5 (cooldown fully expired).
    cs.prime(2, abs_tick=0, force=True)
    assert cs.cooldown_fraction(2, abs_tick=5) == 1.0

    # prime(force=False) on a fully-charged entity: must be a no-op.
    cs.prime(2, abs_tick=5, force=False)
    assert cs.cooldown_fraction(2, abs_tick=5) == 1.0


def test_prime_force_resets_when_fully_charged() -> None:
    """prime(force=True) always resets the cooldown regardless of charge state."""
    from faraway_realms.systems.combat import CombatSystem

    entities: dict = {}
    npc = NonPlayerEntity(
        entity_id=2,
        char=ord("Z"),
        fg_color=(0, 180, 0),
        name="Zombie",
        faction="hostile",
        attack_every=5,
        stats={"health": Pool(base=20), "strength": Stat(base=3)},
    )
    entities[2] = npc
    cs = CombatSystem(entities, EventBus())

    # Charge the cooldown fully.
    cs.prime(2, abs_tick=0, force=True)
    assert cs.cooldown_fraction(2, abs_tick=5) == 1.0

    # force=True resets even when fully charged.
    cs.prime(2, abs_tick=5, force=True)
    assert cs.cooldown_fraction(2, abs_tick=5) == 0.0


def test_npc_contact_preserves_charge_built_during_chase() -> None:
    """Regression: NPC arriving after a chase must not lose the cooldown it charged.

    Old bug: ContactResolutionSystem calls prime(force=False) for both parties
    on contact, which would reset _last_attack_tick even for an entity that was
    already fully ready to attack.
    """
    from faraway_realms.world.events import Event

    game, player = _make_game()
    _hostile_npc(2, 12, 10, game, health=100, attack_every=5)

    # Manually prime the NPC's cooldown at tick 0 and let it fully charge.
    game._combat.prime(2, abs_tick=0, force=True)  # noqa: SLF001
    for _ in range(6):  # 6 ticks > attack_every=5 → fully charged
        game.tick()

    assert game.attack_cooldown_fraction(2) == 1.0

    # Simulate contact (NPC arrives adjacent to player); prime must not fire.
    game.emit_event(
        Event(event_type=EventType.CONTACT, source_id=2, target_id=1, resolve_at_tick=6)
    )
    game._drain_events()  # noqa: SLF001

    # Cooldown must still be fully charged — the charge should be preserved.
    assert game.attack_cooldown_fraction(2) == 1.0


# ---------------------------------------------------------------------------
# Auto-target after kill
# ---------------------------------------------------------------------------


def test_auto_target_acquires_attacker_after_kill() -> None:
    """Player auto-acquires an NPC that was already targeting them after the kill."""
    game, player = _make_game()
    npc_a = _hostile_npc(2, 11, 10, game, health=3)  # player kills this
    npc_b = _hostile_npc(3, 11, 11, game, health=50)  # already targeting the player
    npc_b.target_id = 1  # NPC B is attacking the player
    player.entity.target_id = 2  # player targets NPC A

    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK, actor="1", args=("2",), raw="/attack 1 2"
        )
    )
    game.tick()  # kill lands; TARGET command enqueued
    game.tick()  # TARGET command processed

    assert npc_a not in game._npcs  # noqa: SLF001 — NPC A is dead
    assert player.entity.target_id == 3  # auto-acquired NPC B


def test_auto_target_does_not_fire_when_no_hostile_is_attacking() -> None:
    """No auto-target when nobody is targeting the player after the kill."""
    game, player = _make_game()
    _hostile_npc(2, 11, 10, game, health=3)
    player.entity.target_id = 2

    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK, actor="1", args=("2",), raw="/attack 1 2"
        )
    )
    game.tick()
    game.tick()

    assert player.entity.target_id is None  # no attacker to switch to


def test_auto_target_does_not_override_existing_target() -> None:
    """If the player already has a different target when the kill happens, keep it."""
    game, player = _make_game()
    # NPC A is the one being killed; NPC B targets the player but the player
    # already acquired NPC C before the kill lands.
    npc_a = _hostile_npc(2, 11, 10, game, health=3)
    npc_b = _hostile_npc(3, 11, 11, game, health=50)
    _hostile_npc(4, 12, 10, game, health=50)
    npc_b.target_id = 1
    player.entity.target_id = 2  # about to kill NPC A

    # Player targets NPC C (entity 4) instead of NPC A — death of NPC A does not
    # clear the player's target, so auto_target never runs for them.
    player.entity.target_id = 4  # player targets NPC C (entity 4), not NPC A

    # Manually trigger death for NPC A without going through an ATTACK command.
    from faraway_realms.world.events import Event

    game.emit_event(
        Event(
            event_type=EventType.ENTITY_DYING,
            source_id=npc_a.entity_id,
            resolve_at_tick=0,
        )
    )
    game._drain_events()  # noqa: SLF001

    # Player was not targeting NPC A, so DeathSystem does not clear their target,
    # and auto_target does not run for them.
    assert player.entity.target_id == 4


# ---------------------------------------------------------------------------
# ENTITY_DIED — CombatSystem cleanup via bus
# ---------------------------------------------------------------------------


def _combat_and_bus(attack_every: int = 20):  # type: ignore[return]
    from faraway_realms.systems.combat import CombatSystem

    entities: dict = {}
    npc = NonPlayerEntity(
        entity_id=9,
        char=ord("Z"),
        fg_color=(0, 180, 0),
        name="Zombie",
        attack_every=attack_every,
        stats={"health": Pool(base=100), "strength": Stat(base=5)},
    )
    entities[9] = npc
    bus = EventBus()
    cs = CombatSystem(entities, bus)
    return cs, bus, 9


def test_combat_forgets_cooldown_on_entity_died() -> None:
    cs, bus, eid = _combat_and_bus()
    cs.prime(eid, 0)
    assert cs.cooldown_fraction(eid, abs_tick=5) > 0.0

    bus.publish(
        Event(event_type=EventType.ENTITY_DIED, source_id=eid, resolve_at_tick=5)
    )
    bus.flush(5)

    # After ENTITY_DIED the cooldown entry is gone; fraction returns 0.0.
    assert cs.cooldown_fraction(eid, abs_tick=5) == 0.0


def test_combat_drops_casting_entity_on_entity_died() -> None:
    cs, bus, eid = _combat_and_bus()
    bus.publish(
        Event(event_type=EventType.CAST_STARTED, source_id=eid, resolve_at_tick=0)
    )
    bus.flush(0)
    assert eid in cs._casting_entities  # noqa: SLF001

    bus.publish(
        Event(event_type=EventType.ENTITY_DIED, source_id=eid, resolve_at_tick=1)
    )
    bus.flush(1)
    assert eid not in cs._casting_entities  # noqa: SLF001


# ---------------------------------------------------------------------------
# TICK event — stun bar frozen dynamically via is_stunned() check
# ---------------------------------------------------------------------------


def test_stun_status_holds_bar_at_zero_dynamically() -> None:
    # cooldown_fraction checks is_stunned() at query time — no per-tick polling.
    from faraway_realms.combat.status import StatusInstance

    cs, bus, eid = _combat_and_bus(attack_every=20)
    entity = cs._entities[eid]  # noqa: SLF001
    entity.status_effects.append(
        StatusInstance(name="stun", expires_at=1000, stun=True)
    )
    cs.prime(eid, 0)

    # 20 ticks elapsed on a 20-tick bar — bar would be full without stun.
    assert cs.cooldown_fraction(eid, abs_tick=20) == 0.0


def test_cast_started_and_cancelled_via_bus_update_tracking() -> None:
    cs, bus, eid = _combat_and_bus()

    bus.publish(
        Event(event_type=EventType.CAST_STARTED, source_id=eid, resolve_at_tick=0)
    )
    bus.flush(0)
    assert eid in cs._casting_entities  # noqa: SLF001

    bus.publish(
        Event(event_type=EventType.CAST_CANCELLED, source_id=eid, resolve_at_tick=1)
    )
    bus.flush(1)
    assert eid not in cs._casting_entities  # noqa: SLF001


# ---------------------------------------------------------------------------
# Attack bar frozen while stunned or casting — dynamic gate, no polling loop
# ---------------------------------------------------------------------------


def _combat_system_with_entity(attack_every: int = 20):  # type: ignore[return]
    from faraway_realms.systems.combat import CombatSystem

    entities: dict = {}
    npc = NonPlayerEntity(
        entity_id=9,
        char=ord("Z"),
        fg_color=(0, 180, 0),
        name="Zombie",
        attack_every=attack_every,
        stats={"health": Pool(base=100), "strength": Stat(base=5)},
    )
    entities[9] = npc
    bus = EventBus()
    return CombatSystem(entities, bus), 9


def test_stun_status_holds_bar_at_zero() -> None:
    # is_stunned() checked at query time — bar stays 0.0 while stun is active.
    from faraway_realms.combat.status import StatusInstance

    cs, eid = _combat_system_with_entity(attack_every=20)
    entity = cs._entities[eid]  # noqa: SLF001
    entity.status_effects.append(
        StatusInstance(name="stun", expires_at=1000, stun=True)
    )
    cs.prime(eid, 0)
    # 25 ticks on a 20-tick bar — would be full without stun gate.
    assert cs.cooldown_fraction(eid, abs_tick=25) == 0.0


def test_prime_no_force_is_noop_when_already_tracked() -> None:
    # prime(force=False) is a no-op when entity is already tracked.
    cs, eid = _combat_system_with_entity(attack_every=20)
    cs.prime(eid, 0)
    for t in range(1, 26):
        cs.prime(eid, t)  # force=False → no-op (entity already tracked)
    # Bar advanced: 25 ticks on a 20-tick cooldown → capped at 1.0.
    assert cs.cooldown_fraction(eid, abs_tick=25) == 1.0


def test_casting_entity_holds_bar_at_zero() -> None:
    # Entity in _casting_entities → cooldown_fraction returns 0.0.
    cs, eid = _combat_system_with_entity(attack_every=20)
    cs.prime(eid, 0)
    cs._casting_entities.add(eid)  # noqa: SLF001
    # 30 ticks on a 20-tick bar — would be full without cast gate.
    assert cs.cooldown_fraction(eid, abs_tick=30) == 0.0


def test_not_casting_allows_bar_to_advance() -> None:
    # Entity not in _casting_entities → bar fills normally.
    cs, eid = _combat_system_with_entity(attack_every=20)
    cs.prime(eid, 0)
    assert cs.cooldown_fraction(eid, abs_tick=10) > 0.0


def test_stun_expiry_resets_bar_to_zero() -> None:
    # STATUS_EXPIRED (stun) force-reprimes → bar starts from 0 at expiry tick.
    from faraway_realms.combat.status import StatusInstance

    cs, bus, eid = _combat_and_bus(attack_every=20)
    entity = cs._entities[eid]  # noqa: SLF001
    stun = StatusInstance(name="stun", expires_at=15, stun=True)
    entity.status_effects.append(stun)
    cs.prime(eid, 0)
    bus.publish(
        Event(
            event_type=EventType.STATUS_EXPIRED,
            source_id=eid,
            resolve_at_tick=15,
            payload={"status_name": "stun", "stun": True, "immobilize": False},
        )
    )
    bus.flush(15)
    # Reprimed at tick 15 → ready at tick 35 (attack_every=20).
    assert cs.cooldown_fraction(eid, abs_tick=34) < 1.0
    assert cs.cooldown_fraction(eid, abs_tick=35) == 1.0


def test_stunned_entity_blocked_even_with_bypass_cooldown() -> None:
    # Regression: bypass_cooldown=True (opportunity attacks) must not let a
    # stunned entity attack. The stun gate must fire before the cooldown bypass.
    from faraway_realms.combat.status import StatusInstance

    entities: dict = {}
    attacker = NonPlayerEntity(
        entity_id=1,
        char=ord("Z"),
        fg_color=(0, 180, 0),
        name="Zombie",
        attack_every=1,
        stats={"health": Pool(base=100), "strength": Stat(base=5)},
    )
    target = NonPlayerEntity(
        entity_id=2,
        char=ord("Z"),
        fg_color=(255, 0, 0),
        name="Target",
        attack_every=20,
        stats={"health": Pool(base=100), "strength": Stat(base=5)},
    )
    entities[1] = attacker
    entities[2] = target
    from faraway_realms.systems.combat import CombatSystem
    from faraway_realms.world.event_bus import EventBus

    bus = EventBus()
    cs = CombatSystem(entities, bus)
    attacker.status_effects.append(
        StatusInstance(name="stun", expires_at=1000, stun=True)
    )
    cs.prime(1, 0)
    target_hp: Pool = target.stats["health"]  # type: ignore[assignment]
    cs.handle(1, 2, abs_tick=5, bypass_cooldown=True)
    assert target_hp.current == 100  # stunned attacker dealt no damage


def test_cast_complete_resets_bar_to_zero() -> None:
    # CAST_COMPLETE force-reprimes → bar starts from 0 after cast completes.
    cs, bus, eid = _combat_and_bus(attack_every=20)
    cs.prime(eid, 0)
    bus.publish(
        Event(event_type=EventType.CAST_STARTED, source_id=eid, resolve_at_tick=1)
    )
    bus.flush(1)
    bus.publish(
        Event(event_type=EventType.CAST_COMPLETE, source_id=eid, resolve_at_tick=30)
    )
    bus.flush(30)
    # Reprimed at tick 30 → ready at tick 50 (attack_every=20).
    assert cs.cooldown_fraction(eid, abs_tick=49) < 1.0
    assert cs.cooldown_fraction(eid, abs_tick=50) == 1.0


# ---------------------------------------------------------------------------
# Stun event handler behaviour
# ---------------------------------------------------------------------------


def test_stun_applied_primes_entity() -> None:
    # STUN_APPLIED primes _last_attack_tick so the bar is tracked from stun start.
    cs, bus, eid = _combat_and_bus()
    bus.publish(
        Event(
            event_type=EventType.STUN_APPLIED,
            source_id=eid,
            resolve_at_tick=0,
        )
    )
    bus.flush(0)
    assert eid in cs._last_attack_tick  # noqa: SLF001


def test_status_expired_stun_reprimes_entity() -> None:
    # STATUS_EXPIRED (stun) force-reprimes → bar resets to 0 at expiry tick.
    cs, bus, eid = _combat_and_bus(attack_every=20)
    cs.prime(eid, 0)
    bus.publish(
        Event(
            event_type=EventType.STATUS_EXPIRED,
            source_id=eid,
            resolve_at_tick=10,
            payload={"status_name": "stun", "stun": True, "immobilize": False},
        )
    )
    bus.flush(10)
    assert cs.cooldown_fraction(eid, abs_tick=10) == 0.0


def test_status_expired_non_stun_does_not_reprime() -> None:
    # Non-stun STATUS_EXPIRED must not reset the attack bar.
    cs, bus, eid = _combat_and_bus(attack_every=20)
    cs.prime(eid, 0)
    bus.publish(
        Event(
            event_type=EventType.STATUS_EXPIRED,
            source_id=eid,
            resolve_at_tick=10,
            payload={"status_name": "bleed", "stun": False, "immobilize": False},
        )
    )
    bus.flush(10)
    # Bar should have advanced (non-stun expiry doesn't reprime).
    assert cs.cooldown_fraction(eid, abs_tick=10) > 0.0
