"""Tests for the LightMap and LightSource."""

import numpy as np
import pytest

from faraway_realms.effects.light import (
    LightAnimation,
    LightMap,
    LightSource,
    _animated_source,
    _flicker_intensity,
    _glow_intensity,
    _shift_color,
    animate_light_sources,
    collect_light_sources,
)

_WARM = LightSource(radius=5, intensity=1.0, color=(255, 200, 120))
_DIM = LightSource(radius=3, intensity=0.5, color=(100, 100, 200))


def _make_map(w: int = 20, h: int = 20) -> LightMap:
    return LightMap(w, h)


# ------------------------------------------------------------------
# Ambient baseline
# ------------------------------------------------------------------


def test_fresh_map_at_ambient():
    lm = _make_map()
    assert lm.at(10, 10) == pytest.approx(LightMap.AMBIENT)


def test_compute_with_no_sources_resets_to_ambient():
    lm = _make_map()
    lm.compute([])
    assert lm.at(5, 5) == pytest.approx(LightMap.AMBIENT)


def test_custom_ambient_used_at_rest():
    lm = LightMap(20, 20, ambient=0.1)
    assert lm.at(10, 10) == pytest.approx(0.1)


def test_custom_ambient_reset_after_compute():
    lm = LightMap(20, 20, ambient=0.1)
    lm.compute([])
    assert lm.at(5, 5) == pytest.approx(0.1)


def test_custom_ambient_does_not_affect_class_constant():
    LightMap(20, 20, ambient=0.99)
    assert LightMap.AMBIENT == pytest.approx(0.35)


# ------------------------------------------------------------------
# Single source: intensity and falloff
# ------------------------------------------------------------------


def test_source_centre_at_full_intensity():
    lm = _make_map()
    lm.compute([(10, 10, _WARM)])
    # Centre = ambient + intensity (capped at 1.0)
    assert lm.at(10, 10) == 1.0


def test_source_falls_off_at_radius_edge():
    lm = _make_map()
    lm.compute([(10, 10, _WARM)])
    # Exactly at radius distance the contribution is 0; ambient remains
    assert lm.at(10, 10 + _WARM.radius) == pytest.approx(LightMap.AMBIENT)


def test_brightness_decreases_with_distance():
    lm = _make_map()
    src = LightSource(radius=8, intensity=0.5, color=(255, 255, 255))
    lm.compute([(10, 10, src)])
    assert lm.at(10, 11) > lm.at(10, 12) > lm.at(10, 13)


def test_brightness_capped_at_1():
    """Two overlapping strong sources should not exceed 1.0."""
    lm = _make_map()
    src = LightSource(radius=5, intensity=1.0, color=(255, 255, 255))
    lm.compute([(10, 10, src), (10, 10, src)])
    assert lm.at(10, 10) == 1.0


# ------------------------------------------------------------------
# Multiple sources: additive
# ------------------------------------------------------------------


def test_two_sources_brighter_than_one():
    lm = _make_map()
    src = LightSource(radius=5, intensity=0.4, color=(255, 255, 255))
    lm.compute([(5, 5, src)])
    single = lm.at(5, 5)
    lm.compute([(5, 5, src), (5, 5, src)])
    double = lm.at(5, 5)
    assert double > single


def test_sources_dont_affect_tiles_beyond_radius():
    lm = _make_map()
    lm.compute([(10, 10, _DIM)])  # radius=3; tile at (10,18) is far away
    assert lm.at(10, 18) == pytest.approx(LightMap.AMBIENT)


# ------------------------------------------------------------------
# Map edges: out-of-bounds sources clamp gracefully
# ------------------------------------------------------------------


def test_source_near_corner_does_not_raise():
    lm = _make_map()
    lm.compute([(0, 0, _WARM)])  # circle extends outside map; must not crash
    assert lm.at(0, 0) == 1.0


def test_source_at_bottom_right_corner():
    lm = _make_map(20, 20)
    lm.compute([(19, 19, _WARM)])
    assert lm.at(19, 19) == 1.0


# ------------------------------------------------------------------
# Successive compute() calls reset the map
# ------------------------------------------------------------------


def test_compute_resets_previous_sources():
    lm = _make_map()
    lm.compute([(10, 10, _WARM)])
    bright = lm.at(10, 10)
    lm.compute([])  # no sources → reset to ambient
    assert lm.at(10, 10) < bright
    assert lm.at(10, 10) == pytest.approx(LightMap.AMBIENT)


# ------------------------------------------------------------------
# Symmetry
# ------------------------------------------------------------------


def test_source_is_symmetric():
    lm = _make_map()
    lm.compute([(10, 10, _WARM)])
    assert abs(lm.at(10, 12) - lm.at(10, 8)) < 1e-4
    assert abs(lm.at(12, 10) - lm.at(8, 10)) < 1e-4


# ------------------------------------------------------------------
# Wall blocking
# ------------------------------------------------------------------


def _open_transparency(w: int = 20, h: int = 20) -> np.ndarray:
    """All-floor (fully transparent) grid."""
    return np.ones((h, w), dtype=bool)


def _wall_at(trans: np.ndarray, x: int, y: int) -> np.ndarray:
    """Return a copy of *trans* with tile (x, y) set to opaque."""
    t = trans.copy()
    t[y, x] = False
    return t


def test_wall_blocks_light_behind_it():
    # Torch at (5, 10); wall at (7, 10); tile at (9, 10) should be ambient.
    lm = LightMap(20, 20)
    src = LightSource(radius=8, intensity=1.0, color=(255, 255, 255))
    trans = _wall_at(_open_transparency(), x=7, y=10)
    lm.compute([(5, 10, src)], trans)
    assert lm.at(9, 10) == pytest.approx(LightMap.AMBIENT)


def test_wall_tile_itself_is_lit():
    # The wall that faces the source should still be illuminated.
    lm = LightMap(20, 20)
    src = LightSource(radius=8, intensity=1.0, color=(255, 255, 255))
    trans = _wall_at(_open_transparency(), x=7, y=10)
    lm.compute([(5, 10, src)], trans)
    assert lm.at(7, 10) > LightMap.AMBIENT


def test_light_reaches_around_wall():
    # Torch at (5, 10); wall only at (7, 10); tile at (9, 12) (diagonal) is reachable.
    lm = LightMap(20, 20)
    src = LightSource(radius=8, intensity=1.0, color=(255, 255, 255))
    trans = _wall_at(_open_transparency(), x=7, y=10)
    lm.compute([(5, 10, src)], trans)
    assert lm.at(9, 12) > LightMap.AMBIENT


def test_no_wall_lighting_matches_open_transparency():
    # compute() with no transparency arg must equal all-open transparency.
    lm1 = LightMap(20, 20)
    lm2 = LightMap(20, 20)
    src = LightSource(radius=5, intensity=0.8, color=(255, 200, 120))
    lm1.compute([(10, 10, src)])
    lm2.compute([(10, 10, src)], _open_transparency())
    assert lm1.at(10, 10) == pytest.approx(lm2.at(10, 10))
    assert lm1.at(12, 10) == pytest.approx(lm2.at(12, 10))


# ------------------------------------------------------------------
# rgb_at: per-channel brightness (kills __init__ mutmut_21, compute mutmut_9,
# and at mutmut_5)
# ------------------------------------------------------------------


def test_rgb_at_all_channels_at_ambient():
    lm = _make_map()
    r, g, b = lm.rgb_at(10, 10)
    assert r == pytest.approx(LightMap.AMBIENT)
    assert g == pytest.approx(LightMap.AMBIENT)
    assert b == pytest.approx(LightMap.AMBIENT)


def test_rgb_at_blue_channel_after_compute():
    # Kills compute mutmut_9: _b[:] = None → blue becomes NaN/0 instead of ambient
    lm = _make_map()
    lm.compute([])
    r, g, b = lm.rgb_at(5, 5)
    assert r == pytest.approx(LightMap.AMBIENT)
    assert g == pytest.approx(LightMap.AMBIENT)
    assert b == pytest.approx(LightMap.AMBIENT)


def test_at_uses_green_channel():
    # Kills at mutmut_5: removing _g from max() would return wrong value
    # for a pure-green source where g > r and g > b
    lm = _make_map()
    src = LightSource(radius=5, intensity=0.5, color=(0, 255, 0))
    lm.compute([(10, 10, src)])
    r, g, b = lm.rgb_at(10, 10)
    assert g > r
    assert g > b
    assert lm.at(10, 10) == pytest.approx(g)


def test_at_uses_blue_channel():
    # Kills at mutmut_6: removing _b from max() returns wrong value for blue source
    lm = _make_map()
    src = LightSource(radius=5, intensity=0.5, color=(0, 0, 255))
    lm.compute([(10, 10, src)])
    r, g, b = lm.rgb_at(10, 10)
    assert b > r
    assert b > g
    assert lm.at(10, 10) == pytest.approx(b)


# ------------------------------------------------------------------
# _add_source: channel arithmetic (kills mutmut_77, mutmut_86, mutmut_97, mutmut_98)
# ------------------------------------------------------------------


def test_right_side_of_source_lit_within_radius():
    # Kills _add_source mutmut_39: x1 = cx+r-1 instead of cx+r+1 shrinks bbox,
    # excluding tiles at x = cx+r-1 and cx+r which are within illumination range.
    lm = _make_map()
    src = LightSource(radius=3, intensity=1.0, color=(255, 255, 255))
    lm.compute([(10, 10, src)])
    # Tile at (12, 10): dist=2 from source, should be lit above ambient
    assert lm.at(12, 10) > LightMap.AMBIENT


def test_no_contribution_in_bbox_corner_outside_radius():
    # Kills mutmut_77: fallback 0.0 → 1.0 in np.where
    # Source at (10,10) radius=3; corner (7,7) is inside bounding box
    # but dist=sqrt(18)≈4.24 > 3, so contrib should be zero.
    lm = _make_map()
    src = LightSource(radius=3, intensity=1.0, color=(255, 255, 255))
    lm.compute([(10, 10, src)])
    assert lm.at(7, 7) == pytest.approx(LightMap.AMBIENT)


def test_red_source_increases_red_channel():
    # Kills mutmut_97: += → -= would make red channel fall below ambient
    lm = _make_map()
    src = LightSource(radius=5, intensity=0.5, color=(255, 0, 0))
    lm.compute([(10, 10, src)])
    r, g, b = lm.rgb_at(10, 10)
    assert r > LightMap.AMBIENT
    assert g == pytest.approx(LightMap.AMBIENT)
    assert b == pytest.approx(LightMap.AMBIENT)


def test_blue_source_increases_blue_channel():
    # Kills _add_source mutmut_113: blue += → -= would make blue fall below ambient
    lm = _make_map()
    src = LightSource(radius=5, intensity=0.5, color=(0, 0, 255))
    lm.compute([(10, 10, src)])
    r, g, b = lm.rgb_at(10, 10)
    assert b > LightMap.AMBIENT
    assert r == pytest.approx(LightMap.AMBIENT)
    assert g == pytest.approx(LightMap.AMBIENT)


def test_red_channel_proportional_to_color():
    # Kills mutmut_98: * cr → / cr would give r ≈ 1.0 (capped) instead of ~0.6
    # color=(128,0,0) → cr=128/255; at center dist=0, contrib=intensity=0.5
    # r = AMBIENT + 0.5 * (128/255.0)
    lm = _make_map()
    src = LightSource(radius=5, intensity=0.5, color=(128, 0, 0))
    lm.compute([(10, 10, src)])
    r, _, _ = lm.rgb_at(10, 10)
    assert r == pytest.approx(LightMap.AMBIENT + 0.5 * (128 / 255.0), abs=1e-3)


def test_green_channel_uses_255_divisor():
    # Kills mutmut_86: color[1]/256.0 instead of 255.0
    # Pure green source, radius=5, intensity=1.0; at distance 3:
    # contrib = 1.0 * (1 - 3/5) = 0.4
    # g = AMBIENT + 0.4 * (255/255.0)
    lm = _make_map()
    src = LightSource(radius=5, intensity=1.0, color=(0, 255, 0))
    lm.compute([(10, 10, src)])
    _, g, _ = lm.rgb_at(10, 13)
    assert g == pytest.approx(LightMap.AMBIENT + 0.4 * (255 / 255.0), abs=1e-4)


def test_red_channel_uses_255_divisor():
    # Kills _add_source mutmut_83: color[0]/256.0 instead of 255.0
    # Pure red source, radius=5, intensity=1.0; at distance 3:
    # contrib = 1.0 * (1 - 3/5) = 0.4
    # r = AMBIENT + 0.4 * (255/255.0) = 0.75
    # with mutation: r = AMBIENT + 0.4 * (255/256) ≈ 0.7484
    lm = _make_map()
    src = LightSource(radius=5, intensity=1.0, color=(255, 0, 0))
    lm.compute([(10, 10, src)])
    r, _, _ = lm.rgb_at(10, 13)
    assert r == pytest.approx(LightMap.AMBIENT + 0.4 * (255 / 255.0), abs=1e-4)


# ------------------------------------------------------------------
# _glow_intensity
# ------------------------------------------------------------------


def test_glow_at_zero_time():
    # sin(0)=0, norm=0.5 → midpoint of range
    anim = LightAnimation(kind="glow", intensity_min=0.3, intensity_max=0.7, period=4.0)
    assert _glow_intensity(anim, 0.0) == pytest.approx(0.5)


def test_glow_at_quarter_period():
    # sin(2π * period/4 / period) = sin(π/2) = 1.0, norm=1.0 → max
    anim = LightAnimation(kind="glow", intensity_min=0.2, intensity_max=0.8, period=4.0)
    assert _glow_intensity(anim, 1.0) == pytest.approx(0.8)


def test_glow_at_three_quarter_period():
    # sin(3π/2) = -1, norm=0.0 → min
    anim = LightAnimation(kind="glow", intensity_min=0.2, intensity_max=0.8, period=4.0)
    assert _glow_intensity(anim, 3.0) == pytest.approx(0.2)


def test_glow_stays_in_range():
    anim = LightAnimation(kind="glow", intensity_min=0.1, intensity_max=0.9, period=2.0)
    for t in [0.0, 0.5, 1.0, 1.5, 2.0]:
        v = _glow_intensity(anim, t)
        assert 0.1 - 1e-6 <= v <= 0.9 + 1e-6


# ------------------------------------------------------------------
# _flicker_intensity
# ------------------------------------------------------------------


def _ref_flicker(x: int, y: int, anim: LightAnimation, t: float) -> float:
    """Reference implementation of the correct flicker formula."""
    import math as _m

    phase = (x * 1.6180339887 + y * 2.7182818284) % (2 * _m.pi)
    v = (
        _m.sin(t * 7.3 + phase) * 0.50
        + _m.sin(t * 13.7 + phase * 1.4) * 0.30
        + _m.sin(t * 23.1 + phase * 0.7) * 0.20
    )
    norm = max(0.0, min(1.0, (v + 1.0) / 2.0))
    return anim.intensity_min + norm * (anim.intensity_max - anim.intensity_min)


def test_flicker_exact_formula():
    # Kills all 8 _flicker_intensity mutants by pinning exact output.
    # Inputs chosen to exercise phase, y-term, x-term, t-term, and norm formula.
    anim = LightAnimation(kind="flicker", intensity_min=0.0, intensity_max=1.0)
    for x, y, t in [(1, 0, 0.0), (0, 1, 0.0), (3, 5, 1.5), (7, 2, 0.3), (1, 1, 2.0)]:
        expected = _ref_flicker(x, y, anim, t)
        assert _flicker_intensity(x, y, anim, t) == pytest.approx(expected, abs=1e-6)


def test_flicker_stays_in_range():
    anim = LightAnimation(kind="flicker", intensity_min=0.2, intensity_max=0.8)
    for t in [0.0, 1.0, 2.0, 3.14, 7.5]:
        v = _flicker_intensity(5, 10, anim, t)
        assert 0.2 - 1e-6 <= v <= 0.8 + 1e-6


def test_flicker_varies_with_time():
    anim = LightAnimation(kind="flicker", intensity_min=0.0, intensity_max=1.0)
    values = {_flicker_intensity(5, 5, anim, t) for t in [0.0, 0.1, 0.5, 1.23]}
    assert len(values) > 1


def test_flicker_varies_with_position():
    anim = LightAnimation(kind="flicker", intensity_min=0.0, intensity_max=1.0)
    v1 = _flicker_intensity(3, 7, anim, 1.23)
    v2 = _flicker_intensity(9, 2, anim, 1.23)
    assert v1 != pytest.approx(v2)


# ------------------------------------------------------------------
# _shift_color
# ------------------------------------------------------------------


def test_shift_color_zero_shift_unchanged():
    color = (200, 150, 80)
    assert _shift_color(color, 0.5, 0.5, 0) == color


def test_shift_color_shift_1_changes_output():
    # Kills _shift_color mutmut_2: shift==0 → shift==1 short-circuits the computation
    # With shift=1 and intensity != base, delta != 0 so result differs from input
    color = (150, 100, 80)
    result = _shift_color(color, 0.8, 0.5, 1)
    # delta = round((0.8-0.5)/0.5 * 1) = round(0.6) = 1; r=151, b=79
    assert result != color


def test_shift_color_exact_values():
    # Kills _shift_color mutmut_5: * shift → / shift would give delta≈0
    # color=(150,100,80), intensity=0.8, base=0.5, shift=20
    # delta = round((0.3/0.5) * 20) = round(12.0) = 12
    color = (150, 100, 80)
    r, g, b = _shift_color(color, 0.8, 0.5, 20)
    assert r == 162
    assert g == 100
    assert b == 68


def test_shift_color_brighter_warms():
    # intensity > base → delta > 0 → red up, blue down
    color = (150, 100, 80)
    r, g, b = _shift_color(color, 0.8, 0.5, 20)
    assert r >= 150
    assert b <= 80
    assert g == 100


def test_shift_color_dimmer_cools():
    # intensity < base → delta < 0 → red down, blue up
    color = (150, 100, 80)
    r, g, b = _shift_color(color, 0.2, 0.5, 20)
    assert r <= 150
    assert b >= 80


def test_shift_color_red_clamps_to_zero():
    # Kills _shift_color mutmut_23: max(0, r+delta) → max(1, r+delta)
    # With large negative delta, r+delta should clamp to 0 not 1
    # color=(10,100,100), intensity=0.1, base=0.5, shift=50
    # delta = round((0.1-0.5)/0.5 * 50) = round(-40) = -40; r+delta = -30 → 0
    r, g, b = _shift_color((10, 100, 100), 0.1, 0.5, 50)
    assert r == 0


def test_shift_color_blue_clamps_to_zero():
    # Kills _shift_color mutmut_34: max(0, b-delta) → max(1, b-delta)
    # With large positive delta, b-delta should clamp to 0 not 1
    # color=(100,100,5), intensity=0.9, base=0.3, shift=50
    # delta = round((0.9-0.3)/0.3 * 50) = round(100) = 100; b-delta = -95 → 0
    r, g, b = _shift_color((100, 100, 5), 0.9, 0.3, 50)
    assert b == 0


def test_shift_color_clamps_to_valid_range():
    r, g, b = _shift_color((255, 100, 0), 1.0, 0.1, 100)
    assert 0 <= r <= 255
    assert 0 <= b <= 255


# ------------------------------------------------------------------
# _animated_source
# ------------------------------------------------------------------


def test_animated_source_static_passthrough():
    src = LightSource(radius=5, intensity=0.8, color=(255, 200, 120))
    assert _animated_source(10, 10, src, 0.0) is src


def test_animated_source_glow_changes_intensity():
    # Quarter period → sin=1 → max intensity
    anim = LightAnimation(kind="glow", intensity_min=0.2, intensity_max=0.6, period=4.0)
    src = LightSource(radius=5, intensity=0.5, color=(255, 255, 255), animation=anim)
    result = _animated_source(10, 10, src, 1.0)
    assert result.intensity == pytest.approx(0.6)
    assert result.radius == 5


def test_animated_source_flicker_in_range():
    anim = LightAnimation(kind="flicker", intensity_min=0.1, intensity_max=0.9)
    src = LightSource(radius=5, intensity=0.5, color=(255, 255, 255), animation=anim)
    result = _animated_source(10, 10, src, 0.5)
    assert 0.1 - 1e-6 <= result.intensity <= 0.9 + 1e-6


def test_animated_source_has_valid_color():
    # Kills _animated_source mutmut_20: color = None instead of _shift_color(...)
    anim = LightAnimation(kind="glow", intensity_min=0.2, intensity_max=0.6, period=4.0)
    src = LightSource(radius=5, intensity=0.5, color=(255, 200, 100), animation=anim)
    result = _animated_source(10, 10, src, 1.0)
    assert result.color is not None
    assert len(result.color) == 3


def test_animated_source_preserves_source_color():
    # Kills _animated_source mutmut_34: missing color=color → default (255,200,120) used
    # color_shift=0 means _shift_color returns src.color unchanged
    anim = LightAnimation(
        kind="glow", intensity_min=0.2, intensity_max=0.6, period=4.0, color_shift=0
    )
    src = LightSource(radius=5, intensity=0.5, color=(100, 50, 200), animation=anim)
    result = _animated_source(10, 10, src, 1.0)
    assert result.color == (100, 50, 200)


def test_animated_source_passes_base_intensity():
    # Kills mutmut_23: base_intensity=None → TypeError when color_shift != 0
    anim = LightAnimation(
        kind="glow", intensity_min=0.2, intensity_max=0.6, period=4.0, color_shift=10
    )
    src = LightSource(radius=5, intensity=0.5, color=(200, 100, 80), animation=anim)
    # With mutation, _shift_color(color, intensity, None, 10) → max(None, 0.001) crashes
    result = _animated_source(10, 10, src, 1.0)
    assert isinstance(result, LightSource)


# ------------------------------------------------------------------
# animate_light_sources
# ------------------------------------------------------------------


def test_animate_light_sources_static_unchanged():
    src = LightSource(radius=5, intensity=0.8, color=(255, 200, 120))
    result = animate_light_sources([(5, 5, src)], 1.0)
    assert result == [(5, 5, src)]


def test_animate_light_sources_animated_changes_intensity():
    anim = LightAnimation(kind="glow", intensity_min=0.2, intensity_max=0.8, period=4.0)
    src = LightSource(radius=5, intensity=0.5, color=(255, 200, 120), animation=anim)
    result = animate_light_sources([(5, 5, src)], 1.0)
    assert result[0][2].intensity != src.intensity


def test_animate_light_sources_preserves_position():
    anim = LightAnimation(kind="glow", intensity_min=0.2, intensity_max=0.8, period=4.0)
    src = LightSource(radius=5, intensity=0.5, color=(200, 200, 200), animation=anim)
    result = animate_light_sources([(7, 3, src)], 0.5)
    assert result[0][0] == 7
    assert result[0][1] == 3


def test_animate_light_sources_empty():
    assert animate_light_sources([], 1.0) == []


def test_animate_light_sources_flicker_uses_y_position():
    # Kills animate_light_sources mutmut_2: passing y=None crashes _flicker_intensity
    anim = LightAnimation(kind="flicker", intensity_min=0.0, intensity_max=1.0)
    src = LightSource(radius=5, intensity=0.5, color=(255, 200, 100), animation=anim)
    result = animate_light_sources([(5, 7, src)], 0.3)
    assert result[0][1] == 7  # y preserved


# ------------------------------------------------------------------
# collect_light_sources
# ------------------------------------------------------------------

_MOCK_SRC = LightSource(radius=4, intensity=0.9, color=(255, 200, 100))


def test_collect_light_sources_with_emitter():
    positioned = [(3, 5, {"light_emitter": _MOCK_SRC})]
    assert collect_light_sources(positioned) == [(3, 5, _MOCK_SRC)]


def test_collect_light_sources_no_emitter():
    positioned = [(3, 5, {})]
    assert collect_light_sources(positioned) == []


def test_collect_light_sources_combines_all():
    positioned = [
        (1, 2, {"light_emitter": _MOCK_SRC}),
        (3, 4, {"light_emitter": _MOCK_SRC}),
        (5, 6, {}),
    ]
    result = collect_light_sources(positioned)
    assert (1, 2, _MOCK_SRC) in result
    assert (3, 4, _MOCK_SRC) in result
    assert len(result) == 2


def test_collect_light_sources_empty():
    assert collect_light_sources([]) == []
