"""Tests for MapProfile and parse_map_profiles."""

from pathlib import Path

import pytest

from faraway_realms.content import ContentLoader
from faraway_realms.content_parsers.maps import parse_map_profiles
from faraway_realms.effects.fog import FogParams
from faraway_realms.mapgen.map_profile import MAP_PROFILE_REGISTRY, MapProfile

_MAPS_DIR = Path(__file__).parent.parent / "faraway_realms" / "data" / "maps"


@pytest.fixture(autouse=True)
def clean_registry():
    saved = dict(MAP_PROFILE_REGISTRY)
    MAP_PROFILE_REGISTRY.clear()
    yield
    MAP_PROFILE_REGISTRY.clear()
    MAP_PROFILE_REGISTRY.update(saved)


@pytest.fixture()
def load_shipped():
    loader = ContentLoader(dirs=[_MAPS_DIR])
    loader.register_parser("maps", parse_map_profiles)
    loader.load()


# ---------------------------------------------------------------------------
# MapProfile defaults
# ---------------------------------------------------------------------------


def test_map_profile_default_creature_labels():
    p = MapProfile(name="test")
    assert p.creature_labels == ("cave",)


def test_map_profile_default_static_object_labels():
    p = MapProfile(name="test")
    assert p.static_object_labels == ("cave",)


def test_map_profile_default_texture_patches_none():
    p = MapProfile(name="test")
    assert p.texture_patches is None


def test_map_profile_default_texture_overlays_none():
    p = MapProfile(name="test")
    assert p.texture_overlays is None


def test_map_profile_default_scatter_empty():
    p = MapProfile(name="test")
    assert p.scatter == ()


def test_map_profile_default_ambient():
    p = MapProfile(name="test")
    assert p.ambient == pytest.approx(0.35)


def test_map_profile_default_fog_is_fog_params():
    p = MapProfile(name="test")
    assert isinstance(p.fog, FogParams)


def test_map_profile_default_fog_density():
    assert MapProfile(name="test").fog.density == pytest.approx(0.5)


def test_map_profile_default_fog_scale():
    assert MapProfile(name="test").fog.scale == pytest.approx(0.15)


def test_map_profile_default_fog_wind_x():
    assert MapProfile(name="test").fog.wind_x == pytest.approx(0.25)


def test_map_profile_default_fog_wind_y():
    assert MapProfile(name="test").fog.wind_y == pytest.approx(0.10)


def test_map_profile_default_fog_color():
    assert MapProfile(name="test").fog.color == (130, 145, 165)


def test_map_profile_default_fog_opacity_min():
    assert MapProfile(name="test").fog.opacity_min == pytest.approx(0.0)


def test_map_profile_default_fog_opacity_max():
    assert MapProfile(name="test").fog.opacity_max == pytest.approx(0.20)


# ---------------------------------------------------------------------------
# parse_map_profiles — basic round-trip
# ---------------------------------------------------------------------------


def test_parse_single_profile_added_to_registry():
    parse_map_profiles(
        {
            "mymap": {
                "creature_labels": ["dungeon"],
                "static_object_labels": ["dungeon"],
                "ambient": 0.2,
            }
        }
    )
    assert "mymap" in MAP_PROFILE_REGISTRY


def test_parse_creature_labels():
    parse_map_profiles({"m": {"creature_labels": ["undead", "cave"]}})
    assert MAP_PROFILE_REGISTRY["m"].creature_labels == ("undead", "cave")


def test_parse_static_object_labels():
    parse_map_profiles({"m": {"static_object_labels": ["torch"]}})
    assert MAP_PROFILE_REGISTRY["m"].static_object_labels == ("torch",)


def test_parse_ambient():
    parse_map_profiles({"m": {"ambient": 0.1}})
    assert MAP_PROFILE_REGISTRY["m"].ambient == pytest.approx(0.1)


def test_parse_texture_patches():
    parse_map_profiles({"m": {"texture": {"patches": ["gray_rock"]}}})
    assert MAP_PROFILE_REGISTRY["m"].texture_patches == ("gray_rock",)


def test_parse_texture_overlays():
    parse_map_profiles({"m": {"texture": {"overlays": ["moss"]}}})
    assert MAP_PROFILE_REGISTRY["m"].texture_overlays == ("moss",)


def test_parse_no_texture_key_leaves_none():
    parse_map_profiles({"m": {}})
    assert MAP_PROFILE_REGISTRY["m"].texture_patches is None
    assert MAP_PROFILE_REGISTRY["m"].texture_overlays is None


# ---------------------------------------------------------------------------
# parse_map_profiles — scatter rules
# ---------------------------------------------------------------------------


def test_parse_scatter_rule_target():
    parse_map_profiles(
        {
            "m": {
                "scatter": [
                    {
                        "target": "floor",
                        "replacements": [
                            {"tile": "cave_bone_floor", "probability": 0.02}
                        ],
                    }
                ]
            }
        }
    )
    rule = MAP_PROFILE_REGISTRY["m"].scatter[0]
    assert rule.target == "floor"


def test_parse_scatter_replacement():
    parse_map_profiles(
        {
            "m": {
                "scatter": [
                    {
                        "target": "floor",
                        "replacements": [
                            {"tile": "cave_bone_floor", "probability": 0.02}
                        ],
                    }
                ]
            }
        }
    )
    rep = MAP_PROFILE_REGISTRY["m"].scatter[0].replacements[0]
    assert rep.tile == "cave_bone_floor"
    assert rep.probability == pytest.approx(0.02)


def test_parse_scatter_inherit_bg_default_false():
    parse_map_profiles(
        {
            "m": {
                "scatter": [
                    {
                        "target": "floor",
                        "replacements": [
                            {"tile": "cave_bone_floor", "probability": 0.02}
                        ],
                    }
                ]
            }
        }
    )
    rep = MAP_PROFILE_REGISTRY["m"].scatter[0].replacements[0]
    assert rep.inherit_bg is False


def test_parse_scatter_inherit_bg_true():
    parse_map_profiles(
        {
            "m": {
                "scatter": [
                    {
                        "target": "floor",
                        "replacements": [
                            {
                                "tile": "cave_bone_floor",
                                "probability": 0.02,
                                "inherit_bg": True,
                            }
                        ],
                    }
                ]
            }
        }
    )
    rep = MAP_PROFILE_REGISTRY["m"].scatter[0].replacements[0]
    assert rep.inherit_bg is True


def test_parse_scatter_zone():
    parse_map_profiles(
        {
            "m": {
                "scatter": [
                    {
                        "target": "floor",
                        "zone": "moss",
                        "replacements": [
                            {"tile": "cave_grass_floor", "probability": 0.06}
                        ],
                    }
                ]
            }
        }
    )
    rule = MAP_PROFILE_REGISTRY["m"].scatter[0]
    assert rule.zone == "moss"


def test_parse_scatter_no_zone_defaults_none():
    parse_map_profiles(
        {
            "m": {
                "scatter": [
                    {
                        "target": "floor",
                        "replacements": [
                            {"tile": "cave_bone_floor", "probability": 0.01}
                        ],
                    }
                ]
            }
        }
    )
    assert MAP_PROFILE_REGISTRY["m"].scatter[0].zone is None


def test_parse_scatter_exclude_zones():
    parse_map_profiles(
        {
            "m": {
                "scatter": [
                    {
                        "target": "floor",
                        "exclude_zones": ["gray_rock", "moss"],
                        "replacements": [
                            {"tile": "cave_bone_floor", "probability": 0.01}
                        ],
                    }
                ]
            }
        }
    )
    rule = MAP_PROFILE_REGISTRY["m"].scatter[0]
    assert "gray_rock" in rule.exclude_zones
    assert "moss" in rule.exclude_zones


def test_parse_scatter_no_exclude_zones_defaults_empty():
    parse_map_profiles(
        {
            "m": {
                "scatter": [
                    {
                        "target": "floor",
                        "replacements": [
                            {"tile": "cave_bone_floor", "probability": 0.01}
                        ],
                    }
                ]
            }
        }
    )
    assert MAP_PROFILE_REGISTRY["m"].scatter[0].exclude_zones == ()


# ---------------------------------------------------------------------------
# parse_map_profiles — fog params
# ---------------------------------------------------------------------------


def test_parse_fog_density():
    parse_map_profiles({"m": {"fog": {"density": 0.8}}})
    assert MAP_PROFILE_REGISTRY["m"].fog.density == pytest.approx(0.8)


def test_parse_fog_color():
    parse_map_profiles({"m": {"fog": {"color": [100, 110, 120]}}})
    assert MAP_PROFILE_REGISTRY["m"].fog.color == (100, 110, 120)


def test_parse_fog_opacity_min_max():
    parse_map_profiles({"m": {"fog": {"opacity_min": 0.05, "opacity_max": 0.30}}})
    fog = MAP_PROFILE_REGISTRY["m"].fog
    assert fog.opacity_min == pytest.approx(0.05)
    assert fog.opacity_max == pytest.approx(0.30)


def test_parse_fog_missing_uses_defaults():
    parse_map_profiles({"m": {}})
    fog = MAP_PROFILE_REGISTRY["m"].fog
    assert isinstance(fog, FogParams)
    assert fog.density == pytest.approx(0.5)


# ---------------------------------------------------------------------------
# parse_map_profiles — name field
# ---------------------------------------------------------------------------


def test_parse_profile_name_set_from_key():
    parse_map_profiles({"my_profile": {}})
    assert MAP_PROFILE_REGISTRY["my_profile"].name == "my_profile"


def test_parse_profile_default_creature_labels():
    parse_map_profiles({"m": {}})
    assert MAP_PROFILE_REGISTRY["m"].creature_labels is None


def test_parse_profile_default_static_object_labels():
    parse_map_profiles({"m": {}})
    assert MAP_PROFILE_REGISTRY["m"].static_object_labels is None


def test_parse_profile_default_ambient():
    parse_map_profiles({"m": {}})
    assert MAP_PROFILE_REGISTRY["m"].ambient == pytest.approx(0.35)


# ---------------------------------------------------------------------------
# parse_map_profiles — scatter missing replacements
# ---------------------------------------------------------------------------


def test_parse_scatter_missing_replacements_defaults_empty():
    parse_map_profiles({"m": {"scatter": [{"target": "floor"}]}})
    assert MAP_PROFILE_REGISTRY["m"].scatter[0].replacements == ()


# ---------------------------------------------------------------------------
# parse_map_profiles — fog individual key defaults
# ---------------------------------------------------------------------------


def test_parse_fog_missing_scale_uses_default():
    parse_map_profiles({"m": {"fog": {"density": 0.9}}})
    assert MAP_PROFILE_REGISTRY["m"].fog.scale == pytest.approx(0.15)


def test_parse_fog_scale_key_read():
    parse_map_profiles({"m": {"fog": {"scale": 0.99}}})
    assert MAP_PROFILE_REGISTRY["m"].fog.scale == pytest.approx(0.99)


def test_parse_fog_missing_wind_y_uses_default():
    parse_map_profiles({"m": {"fog": {"density": 0.9}}})
    assert MAP_PROFILE_REGISTRY["m"].fog.wind_y == pytest.approx(0.10)


def test_parse_fog_wind_y_key_read():
    parse_map_profiles({"m": {"fog": {"wind_y": 0.77}}})
    assert MAP_PROFILE_REGISTRY["m"].fog.wind_y == pytest.approx(0.77)


def test_parse_fog_missing_wind_x_uses_default():
    parse_map_profiles({"m": {"fog": {"density": 0.9}}})
    assert MAP_PROFILE_REGISTRY["m"].fog.wind_x == pytest.approx(0.25)


def test_parse_fog_wind_x_key_read():
    parse_map_profiles({"m": {"fog": {"wind_x": 0.88}}})
    assert MAP_PROFILE_REGISTRY["m"].fog.wind_x == pytest.approx(0.88)


def test_parse_fog_missing_color_uses_default():
    parse_map_profiles({"m": {"fog": {}}})
    assert MAP_PROFILE_REGISTRY["m"].fog.color == (130, 145, 165)


def test_parse_fog_missing_opacity_min_uses_default():
    parse_map_profiles({"m": {"fog": {}}})
    assert MAP_PROFILE_REGISTRY["m"].fog.opacity_min == pytest.approx(0.0)


def test_parse_fog_missing_opacity_max_uses_default():
    parse_map_profiles({"m": {"fog": {}}})
    assert MAP_PROFILE_REGISTRY["m"].fog.opacity_max == pytest.approx(0.20)


def test_parse_fog_missing_seed_uses_default():
    parse_map_profiles({"m": {"fog": {}}})
    assert MAP_PROFILE_REGISTRY["m"].fog.seed == 7


def test_parse_fog_seed_key_read():
    parse_map_profiles({"m": {"fog": {"seed": 42}}})
    assert MAP_PROFILE_REGISTRY["m"].fog.seed == 42


# ---------------------------------------------------------------------------
# Shipped cave profile
# ---------------------------------------------------------------------------


def test_shipped_cave_profile_loaded(load_shipped):
    assert "cave" in MAP_PROFILE_REGISTRY


def test_shipped_cave_profile_has_scatter(load_shipped):
    assert len(MAP_PROFILE_REGISTRY["cave"].scatter) > 0


def test_shipped_cave_profile_ambient(load_shipped):
    assert MAP_PROFILE_REGISTRY["cave"].ambient == pytest.approx(0.35)


def test_shipped_cave_profile_fog_color(load_shipped):
    fog = MAP_PROFILE_REGISTRY["cave"].fog
    assert len(fog.color) == 3
