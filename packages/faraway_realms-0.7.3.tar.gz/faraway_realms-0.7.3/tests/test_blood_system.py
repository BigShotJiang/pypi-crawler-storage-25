"""Tests for BloodSystem — hit sequences, blood splats, and attack animations."""

from faraway_realms.combat.stats import Pool, Stat
from faraway_realms.entities.entity import CharacterEntity, NonPlayerEntity, Player
from faraway_realms.game import Game
from faraway_realms.world.commands import Command, CommandType
from faraway_realms.world.events import Event, EventType
from faraway_realms.world.factions import FactionRelations
from faraway_realms.world.map import make_bordered_map


def _make_game() -> tuple[Game, Player]:
    game_map = make_bordered_map(20, 20)
    entity = CharacterEntity(
        entity_id=1,
        char=ord("@"),
        fg_color=(255, 255, 0),
        name="Hero",
        faction="player",
        stats={"health": Pool(base=100), "strength": Stat(base=10)},
    )
    player = Player(username="tester", entity=entity)
    relations = FactionRelations()
    relations.set_hostile("player", "hostile", True)
    game = Game(game_map=game_map, faction_relations=relations)
    game.add_player(player)
    game_map.place_entity(entity.entity_id, 10, 10)
    return game, player


def _add_npc(
    game: Game, entity_id: int, x: int, y: int, health: int = 20
) -> NonPlayerEntity:
    npc = NonPlayerEntity(
        entity_id=entity_id,
        char=ord("Z"),
        fg_color=(0, 180, 0),
        name="Zombie",
        faction="hostile",
        stats={"health": Pool(base=health), "strength": Stat(base=3)},
    )
    game.add_npc(npc)
    game.game_map.place_entity(npc.entity_id, x, y)
    return npc


def _hit_event(
    source_id: int, target_id: int, damage: int = 5, crit: bool = False
) -> Event:
    return Event(
        event_type=EventType.ENTITY_HIT,
        source_id=source_id,
        target_id=target_id,
        resolve_at_tick=1,
        payload={"damage": damage, "crit": crit, "is_ability": False},
    )


def test_hit_seq_increments_on_entity_hit() -> None:
    game, _ = _make_game()
    _add_npc(game, 2, 11, 10)
    assert game.get_hit_seq(2) == 0
    game.emit_event(_hit_event(1, 2))
    game.tick()
    assert game.get_hit_seq(2) == 1


def test_hit_seq_untracked_entity_returns_zero() -> None:
    game, _ = _make_game()
    assert game.get_hit_seq(999) == 0


def test_crit_dealt_seq_increments_on_crit() -> None:
    game, _ = _make_game()
    _add_npc(game, 2, 11, 10)
    assert game.get_crit_dealt_seq(1) == 0
    game.emit_event(_hit_event(1, 2, crit=True))
    game.tick()
    assert game.get_crit_dealt_seq(1) == 1


def test_crit_dealt_seq_no_increment_for_non_crit() -> None:
    game, _ = _make_game()
    _add_npc(game, 2, 11, 10)
    game.emit_event(_hit_event(1, 2, crit=False))
    game.tick()
    assert game.get_crit_dealt_seq(1) == 0


def test_melee_hit_sets_last_hit_tick() -> None:
    game, _ = _make_game()
    _add_npc(game, 2, 11, 10)
    game.emit_event(_hit_event(1, 2))
    game.tick()
    npc = game.entity(2)
    assert npc is not None
    assert npc.last_hit_tick == game.abs_tick
    assert npc.last_hit_by == 1


def test_blood_baked_into_map_tiles() -> None:
    game, _ = _make_game()
    _add_npc(game, 2, 11, 10)
    game.emit_event(_hit_event(1, 2))
    game.tick()
    dirty = game.game_map.drain_dirty_tiles()
    assert len(dirty) > 0


def test_no_blood_for_zero_damage_hit() -> None:
    game, _ = _make_game()
    _add_npc(game, 2, 11, 10)
    zero_hit = Event(
        event_type=EventType.ENTITY_HIT,
        source_id=1,
        target_id=2,
        resolve_at_tick=1,
        payload={"damage": 0, "crit": False, "is_ability": False},
    )
    game.emit_event(zero_hit)
    game.tick()
    assert game.get_hit_seq(2) == 0
    assert game.melee_anim_events() == []


def test_melee_attack_generates_anim_event() -> None:
    game, player = _make_game()
    npc = _add_npc(game, 2, 11, 10)
    player.entity.target_id = 2
    npc.target_id = 1
    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK, actor="1", args=("2",), raw="/attack 1 2"
        )
    )
    game.tick()
    assert len(game.melee_anim_events()) >= 1


def test_game_has_no_bus_subscriptions() -> None:
    """Game itself must not subscribe to the event bus after the refactor."""
    from faraway_realms.game import Game
    from faraway_realms.world.map import make_bordered_map

    g = Game(game_map=make_bordered_map(5, 5))
    bus = g._bus  # noqa: SLF001
    for _evt_type, handlers in bus._subscribers.items():  # noqa: SLF001
        for _priority, _seq, handler in handlers:
            bound = getattr(handler, "__self__", None)
            assert bound is not g, (
                f"Game still subscribes to bus via method {handler.__name__}"
            )
