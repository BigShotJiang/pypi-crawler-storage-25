"""Tests for DeathSystem: ENTITY_DYING/ENTITY_DIED pipeline and entity cleanup."""

from faraway_realms.combat.stats import Pool, Stat
from faraway_realms.entities.entity import NonPlayerEntity
from faraway_realms.systems.death import DeathSystem
from faraway_realms.world.event_bus import EventBus
from faraway_realms.world.events import Event, EventType
from faraway_realms.world.map import make_bordered_map


def _npc(entity_id: int = 2) -> NonPlayerEntity:
    return NonPlayerEntity(
        entity_id=entity_id,
        char=ord("Z"),
        fg_color=(0, 200, 0),
        name="Zombie",
        faction="hostile",
        stats={"health": Pool(base=10), "strength": Stat(base=2)},
    )


def _dying(source_id: int, tick: int = 0) -> Event:
    return Event(
        event_type=EventType.ENTITY_DYING, source_id=source_id, resolve_at_tick=tick
    )


def _setup(place: bool = True):
    game_map = make_bordered_map(20, 20)
    entities: dict = {}
    npcs: list = []
    npc = _npc(2)
    entities[2] = npc
    npcs.append(npc)
    if place:
        game_map.place_entity(2, 10, 10)
    bus = EventBus()
    death_sys = DeathSystem(game_map, entities, npcs, bus)
    return game_map, entities, npcs, bus, death_sys


# ---------------------------------------------------------------------------
# ENTITY_DYING → entity is still alive when priority-0 observers fire
# ---------------------------------------------------------------------------


def test_entity_present_in_map_during_entity_dying() -> None:
    game_map, entities, npcs, bus, _ = _setup()
    seen_on_map = []

    def observer(event: Event) -> None:
        seen_on_map.append(game_map.has_entity(event.source_id))

    bus.subscribe(EventType.ENTITY_DYING, observer, priority=0)
    bus.publish(_dying(2))
    bus.flush(0)

    assert seen_on_map == [True]


def test_entity_present_in_registry_during_entity_dying() -> None:
    game_map, entities, npcs, bus, _ = _setup()
    seen_in_registry = []

    def observer(event: Event) -> None:
        seen_in_registry.append(event.source_id in entities)

    bus.subscribe(EventType.ENTITY_DYING, observer, priority=0)
    bus.publish(_dying(2))
    bus.flush(0)

    assert seen_in_registry == [True]


# ---------------------------------------------------------------------------
# ENTITY_DIED → entity is gone when subscribers fire
# ---------------------------------------------------------------------------


def test_entity_absent_from_map_during_entity_died() -> None:
    game_map, entities, npcs, bus, _ = _setup()
    seen_on_map = []

    def observer(event: Event) -> None:
        seen_on_map.append(game_map.has_entity(event.source_id))

    bus.subscribe(EventType.ENTITY_DIED, observer, priority=0)
    bus.publish(_dying(2))
    bus.flush(0)

    assert seen_on_map == [False]


def test_entity_absent_from_registry_during_entity_died() -> None:
    game_map, entities, npcs, bus, _ = _setup()
    seen_in_registry = []

    def observer(event: Event) -> None:
        seen_in_registry.append(event.source_id in entities)

    bus.subscribe(EventType.ENTITY_DIED, observer, priority=0)
    bus.publish(_dying(2))
    bus.flush(0)

    assert seen_in_registry == [False]


def test_entity_died_source_id_matches_dying_source_id() -> None:
    _, entities, _, bus, _ = _setup()
    died_events = []
    bus.subscribe(EventType.ENTITY_DIED, died_events.append, priority=0)
    bus.publish(_dying(2))
    bus.flush(0)

    assert len(died_events) == 1
    assert died_events[0].source_id == 2


# ---------------------------------------------------------------------------
# DeathSystem cleanup
# ---------------------------------------------------------------------------


def test_death_removes_entity_from_map() -> None:
    game_map, _, _, bus, _ = _setup()
    bus.publish(_dying(2))
    bus.flush(0)
    assert not game_map.has_entity(2)


def test_death_removes_entity_from_registry() -> None:
    _, entities, _, bus, _ = _setup()
    bus.publish(_dying(2))
    bus.flush(0)
    assert 2 not in entities


def test_death_removes_entity_from_npc_list() -> None:
    _, _, npcs, bus, _ = _setup()
    bus.publish(_dying(2))
    bus.flush(0)
    assert all(n.entity_id != 2 for n in npcs)


def test_death_clears_target_references() -> None:
    game_map, entities, npcs, bus, _ = _setup()
    # A second entity targeting the dying one.
    attacker = _npc(3)
    attacker.target_id = 2
    entities[3] = attacker
    game_map.place_entity(3, 11, 10)

    bus.publish(_dying(2))
    bus.flush(0)

    assert attacker.target_id is None


def test_death_of_entity_not_on_map_does_not_crash() -> None:
    game_map, entities, npcs, bus, _ = _setup(place=False)
    bus.publish(_dying(2))
    bus.flush(0)
    assert 2 not in entities


# ---------------------------------------------------------------------------
# ENTITY_DIED not published without a bus
# ---------------------------------------------------------------------------


def test_no_entity_died_without_bus() -> None:
    game_map = make_bordered_map(20, 20)
    entities: dict = {}
    npcs: list = []
    npc = _npc(2)
    entities[2] = npc
    npcs.append(npc)
    game_map.place_entity(2, 10, 10)
    death_sys = DeathSystem(game_map, entities, npcs, bus=None)

    # Without a bus, handle() must not crash; ENTITY_DIED is simply skipped.
    death_sys.handle(
        Event(event_type=EventType.ENTITY_DYING, source_id=2, resolve_at_tick=0)
    )
    assert 2 not in entities
