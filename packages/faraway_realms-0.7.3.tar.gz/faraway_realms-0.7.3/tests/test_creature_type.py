"""Tests for faraway_realms.entities.creature_type."""

import pytest

from faraway_realms.combat.stats import Pool, Stat
from faraway_realms.entities.components import BehaviourComponent, CombatProfile
from faraway_realms.entities.creature_type import CreatureType
from faraway_realms.entities.entity import Entity


def _make_ct(**kwargs) -> CreatureType:
    defaults = {"name": "TestBeast", "char": "T", "fg_color": (10, 20, 30)}
    defaults.update(kwargs)
    return CreatureType(**defaults)


def test_to_npc_sets_entity_id():
    ct = _make_ct()
    assert ct.to_npc(42).entity_id == 42


def test_to_npc_sets_char():
    ct = _make_ct(char=ord("X"))
    assert ct.to_npc(1).char == ord("X")


def test_to_npc_sets_fg_color():
    ct = _make_ct(fg_color=(11, 22, 33))
    assert ct.to_npc(1).fg_color == (11, 22, 33)


def test_to_npc_health_pool():
    ct = _make_ct(stats={"health": 55})
    npc = ct.to_npc(1)
    assert isinstance(npc.stats.get("health"), Pool)
    assert npc.stats["health"].value == 55


def test_to_npc_strength_stat():
    ct = _make_ct(stats={"strength": 7})
    npc = ct.to_npc(1)
    assert isinstance(npc.stats.get("strength"), Stat)
    assert npc.stats["strength"].value == 7


def test_to_npc_returns_entity():
    ct = _make_ct()
    assert isinstance(ct.to_npc(1), Entity)


def test_to_npc_has_behaviour_component():
    ct = _make_ct()
    npc = ct.to_npc(1)
    assert isinstance(npc.components.get("behaviour"), BehaviourComponent)


def test_unknown_behaviour_raises():
    ct = CreatureType(
        name="X", char=ord("x"), fg_color=(0, 0, 0), behaviour_kind="unknown"
    )
    with pytest.raises(ValueError):
        ct.to_npc(1)


def test_to_npc_includes_armor_stat_when_present():
    ct = _make_ct(stats={"armor": 4})
    npc = ct.to_npc(1)
    assert "armor" in npc.stats
    assert npc.stats["armor"].value == 4


def test_to_npc_omits_armor_stat_when_absent():
    ct = _make_ct(stats={})
    assert "armor" not in ct.to_npc(1).stats


def test_entity_has_correct_armor_type_and_damage_type():
    ct = _make_ct(
        combat_profile=CombatProfile(armor_type="chitin", damage_type="piercing")
    )
    npc = ct.to_npc(1)
    cp = npc.components.get("combat_profile")
    assert isinstance(cp, CombatProfile)
    assert cp.armor_type == "chitin"
    assert cp.damage_type == "piercing"


def test_to_npc_passes_blood_color():
    ct = _make_ct(combat_profile=CombatProfile(blood_color=(200, 10, 10)))
    cp = ct.to_npc(1).components.get("combat_profile")
    assert isinstance(cp, CombatProfile)
    assert cp.blood_color == (200, 10, 10)


def test_to_npc_none_blood_color():
    ct = _make_ct(combat_profile=CombatProfile(blood_color=None))
    cp = ct.to_npc(1).components.get("combat_profile")
    assert isinstance(cp, CombatProfile)
    assert cp.blood_color is None


def test_unknown_stat_key_ignored():
    # stats keys not in STAT_DEF_REGISTRY are silently dropped
    ct = _make_ct(stats={"unknown_stat": 99})
    npc = ct.to_npc(1)
    assert "unknown_stat" not in npc.stats
