"""Tests for the status effect system."""

from faraway_realms.combat.abilities import ApplyStatusEffect
from faraway_realms.combat.stats import Pool, Stat
from faraway_realms.combat.status import StatusInstance, is_immobilized, is_stunned
from faraway_realms.entities.entity import CharacterEntity, NonPlayerEntity
from faraway_realms.game import Game
from faraway_realms.systems.status import StatusEffectSystem
from faraway_realms.world.event_bus import EventBus
from faraway_realms.world.events import EventType
from faraway_realms.world.factions import FactionRelations
from faraway_realms.world.map import make_bordered_map

# ---------------------------------------------------------------------------
# StatusInstance helpers
# ---------------------------------------------------------------------------


def test_is_expired_before_and_after():
    s = StatusInstance(name="test", expires_at=10)
    assert not s.is_expired(9)
    assert s.is_expired(10)


def test_dot_due_when_tick_damage_zero():
    s = StatusInstance(name="test", expires_at=20, tick_damage=0, next_dot_tick=5)
    assert not s.dot_due(5)


def test_dot_due_when_tick_arrives():
    s = StatusInstance(name="test", expires_at=20, tick_damage=3, next_dot_tick=5)
    assert not s.dot_due(4)
    assert s.dot_due(5)


def test_is_immobilized_and_is_stunned():
    entity = CharacterEntity(
        entity_id=1, char=ord("@"), fg_color=(255, 255, 0), name="Hero"
    )
    entity.status_effects.append(
        StatusInstance(name="immobilize", expires_at=20, immobilize=True)
    )
    entity.status_effects.append(StatusInstance(name="stun", expires_at=20, stun=True))
    assert is_immobilized(entity, abs_tick=5)
    assert is_stunned(entity, abs_tick=5)
    assert not is_immobilized(entity, abs_tick=20)
    assert not is_stunned(entity, abs_tick=20)


# ---------------------------------------------------------------------------
# StatusEffectSystem
# ---------------------------------------------------------------------------


def _make_entity_with_hp(entity_id: int, hp: int) -> CharacterEntity:
    return CharacterEntity(
        entity_id=entity_id,
        char=ord("@"),
        fg_color=(255, 255, 0),
        name="Hero",
        stats={"health": Pool(base=hp)},
    )


def _make_status_system(entities: dict) -> tuple:
    """Return (StatusEffectSystem, EventBus, death_events_list)."""
    bus = EventBus()
    deaths: list = []
    bus.subscribe(EventType.ENTITY_DYING, deaths.append)
    return StatusEffectSystem(entities, bus), bus, deaths


def test_status_system_removes_expired():
    entity = _make_entity_with_hp(1, 50)
    entity.status_effects.append(StatusInstance(name="bleed", expires_at=10))
    system, bus, _ = _make_status_system({1: entity})
    system.tick(abs_tick=10)
    assert entity.status_effects == []


def test_status_system_applies_dot_damage():
    entity = _make_entity_with_hp(1, 50)
    entity.status_effects.append(
        StatusInstance(
            name="bleed",
            expires_at=30,
            tick_damage=3,
            dot_interval=10,
            next_dot_tick=10,
        )
    )
    system, bus, _ = _make_status_system({1: entity})
    system.tick(abs_tick=10)
    hp: Pool = entity.stats["health"]  # type: ignore[assignment]
    assert hp.current == 47


def test_status_system_advances_next_dot_tick():
    entity = _make_entity_with_hp(1, 50)
    s = StatusInstance(
        name="bleed", expires_at=30, tick_damage=1, dot_interval=10, next_dot_tick=10
    )
    entity.status_effects.append(s)
    system, bus, _ = _make_status_system({1: entity})
    system.tick(abs_tick=10)
    assert s.next_dot_tick == 20


def test_dot_death_emits_death_event():
    entity = _make_entity_with_hp(1, 1)
    entity.status_effects.append(
        StatusInstance(
            name="bleed",
            expires_at=30,
            tick_damage=5,
            dot_interval=10,
            next_dot_tick=10,
        )
    )
    system, bus, deaths = _make_status_system({1: entity})
    system.tick(abs_tick=10)
    bus.flush(abs_tick=10)
    assert any(e.event_type == EventType.ENTITY_DYING for e in deaths)


def test_hot_heals_entity():
    entity = _make_entity_with_hp(1, 50)
    hp: Pool = entity.stats["health"]  # type: ignore[assignment]
    hp.modify(-20)
    assert hp.current == 30
    entity.status_effects.append(
        StatusInstance(
            name="second_wind",
            expires_at=30,
            tick_heal=5,
            dot_interval=10,
            next_dot_tick=10,
        )
    )
    system, bus, _ = _make_status_system({1: entity})
    system.tick(abs_tick=10)
    assert hp.current == 35


def test_dot_no_health_pool_is_noop():
    entity = CharacterEntity(
        entity_id=1, char=ord("@"), fg_color=(255, 255, 0), name="Hero"
    )
    # no stats → no Pool → _apply_dot returns []
    entity.status_effects.append(
        StatusInstance(
            name="bleed",
            expires_at=30,
            tick_damage=5,
            dot_interval=10,
            next_dot_tick=10,
        )
    )
    system, bus, deaths = _make_status_system({1: entity})
    system.tick(abs_tick=10)
    bus.flush(abs_tick=10)
    assert deaths == []


# ---------------------------------------------------------------------------
# Integration — status applied via game
# ---------------------------------------------------------------------------


def _make_game():
    game_map = make_bordered_map(20, 20)
    from faraway_realms.entities.entity import Player

    entity = CharacterEntity(
        entity_id=1,
        char=ord("@"),
        fg_color=(255, 255, 0),
        name="Hero",
        faction="player",
        stats={"health": Pool(base=100), "strength": Stat(base=5)},
    )
    player = Player(username="tester", entity=entity)
    npc = NonPlayerEntity(
        entity_id=2,
        char=ord("Z"),
        fg_color=(0, 180, 0),
        name="Zombie",
        faction="hostile",
        stats={"health": Pool(base=50)},
    )
    relations = FactionRelations()
    relations.set_hostile("player", "hostile", True)
    game = Game(game_map=game_map, faction_relations=relations)
    game.add_player(player)
    game.add_npc(npc)
    game_map.place_entity(1, 5, 5)
    game_map.place_entity(2, 6, 5)
    return game, entity, npc, player


def test_kick_applies_immobilize():
    from faraway_realms.world.commands import Command, CommandType

    game, entity, npc, _ = _make_game()
    cmd = Command(
        command_type=CommandType.CAST,
        actor="1",
        args=("kick", "2"),
        raw="/cast 1 kick 2",
    )
    game.enqueue_command(cmd)
    game.tick()
    assert is_immobilized(npc, abs_tick=game._abs_tick)  # noqa: SLF001


def test_immobilized_entity_cannot_move():
    from faraway_realms.world.commands import Command, CommandType

    game, _, npc, _ = _make_game()
    npc.status_effects.append(
        StatusInstance(name="immobilize", expires_at=100, immobilize=True)
    )
    cmd = Command(
        command_type=CommandType.MOVE, actor="2", args=("left",), raw="/move 2 left"
    )
    game.enqueue_command(cmd)
    pos_before = game.game_map.get_entity_position(2)
    game.tick()
    assert game.game_map.get_entity_position(2) == pos_before


def test_stunned_entity_cannot_attack():
    from faraway_realms.world.commands import Command, CommandType

    game, entity, npc, _ = _make_game()
    entity.status_effects.append(StatusInstance(name="stun", expires_at=100, stun=True))
    cmd = Command(
        command_type=CommandType.ATTACK, actor="1", args=("2",), raw="/attack 1 2"
    )
    game.enqueue_command(cmd)
    game.tick()
    hp: Pool = npc.stats["health"]  # type: ignore[assignment]
    assert hp.current == 50  # no damage dealt


def test_bleed_applied_by_bite():
    from faraway_realms.world.commands import Command, CommandType

    game, entity, npc, _ = _make_game()
    cmd = Command(
        command_type=CommandType.CAST,
        actor="1",
        args=("bite", "2"),
        raw="/cast 1 bite 2",
    )
    game.enqueue_command(cmd)
    # Run enough ticks for the 10-tick cast to complete
    for _ in range(12):
        game.tick()
    assert any(s.name == "bleed" for s in npc.status_effects)


def test_apply_status_effect_refreshes_existing():
    """Applying the same status twice resets duration rather than stacking."""
    game, _, npc, _ = _make_game()
    effect = ApplyStatusEffect(status_name="bleed", duration=30, tick_damage=1)
    game._ability_effects._apply_status_effect(1, 2, effect, 0)  # noqa: SLF001
    game._ability_effects._apply_status_effect(1, 2, effect, 0)  # noqa: SLF001
    assert sum(1 for s in npc.status_effects if s.name == "bleed") == 1


# ---------------------------------------------------------------------------
# STATUS_EXPIRED events
# ---------------------------------------------------------------------------


def _make_status_system_with_entity(
    entity_id: int,
    stats: dict | None = None,
) -> tuple:
    """Return (system, bus, entity, expired_events)."""
    entity = CharacterEntity(
        entity_id=entity_id,
        char=ord("@"),
        fg_color=(255, 255, 0),
        name="Hero",
        stats=stats or {},
    )
    bus = EventBus()
    expired: list = []
    bus.subscribe(EventType.STATUS_EXPIRED, expired.append)
    system = StatusEffectSystem({entity_id: entity}, bus)
    return system, bus, entity, expired


def test_status_expired_published_when_status_expires():
    system, bus, entity, expired = _make_status_system_with_entity(1)
    entity.status_effects.append(StatusInstance(name="bleed", expires_at=5))
    system.tick(abs_tick=5)
    bus.flush(abs_tick=5)
    assert len(expired) == 1
    assert expired[0].source_id == 1
    assert expired[0].payload["status_name"] == "bleed"  # type: ignore[index]


def test_stun_expired_payload_has_stun_true():
    system, bus, entity, expired = _make_status_system_with_entity(2)
    entity.status_effects.append(StatusInstance(name="stun", expires_at=5, stun=True))
    system.tick(abs_tick=5)
    bus.flush(abs_tick=5)
    assert len(expired) == 1
    assert expired[0].payload["stun"] is True  # type: ignore[index]


def test_status_expired_not_published_before_expiry():
    system, bus, entity, expired = _make_status_system_with_entity(3)
    entity.status_effects.append(StatusInstance(name="bleed", expires_at=10))
    system.tick(abs_tick=9)
    bus.flush(abs_tick=9)
    assert expired == []


# ---------------------------------------------------------------------------
# RESOURCE_CHANGED from mana regen
# ---------------------------------------------------------------------------


def test_resource_changed_published_on_mana_regen():
    from faraway_realms.combat.stats import Pool

    bus = EventBus()
    resource_events: list = []
    bus.subscribe(EventType.RESOURCE_CHANGED, resource_events.append)
    entity = CharacterEntity(
        entity_id=10,
        char=ord("@"),
        fg_color=(255, 255, 0),
        name="Hero",
        stats={"mana": Pool(base=100, regen_per_tick=2)},
    )
    mana: Pool = entity.stats["mana"]  # type: ignore[assignment]
    mana.current = 50
    system = StatusEffectSystem({10: entity}, bus)
    system.tick(abs_tick=1)
    bus.flush(abs_tick=1)
    rc = [e for e in resource_events if e.payload and e.payload.get("pool") == "mana"]
    assert len(rc) == 1
    assert rc[0].source_id == 10
    assert rc[0].payload["delta"] == 2  # type: ignore[index]
