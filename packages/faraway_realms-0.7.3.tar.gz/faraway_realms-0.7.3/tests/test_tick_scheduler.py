"""Tests for the fixed-timestep scheduler in GameServer._tick_loop."""

from __future__ import annotations

import asyncio
from contextlib import ExitStack
from unittest.mock import AsyncMock, MagicMock, patch

from faraway_realms.net.server import GameServer


class _StopTick(Exception):
    pass


def _make_server() -> GameServer:
    game = MagicMock()
    game.tick_rate = 10  # 100 ms interval
    game.command_queue_size = 0
    server = GameServer(game, "localhost", 0)
    server._sessions = {}
    server._broadcast_tick = AsyncMock()
    server._reap_expired_sessions = MagicMock()
    return server


class _SleepCollector:
    """Sync callable used as AsyncMock side_effect; stops after n calls."""

    def __init__(self, n: int) -> None:
        self.calls: list[float] = []
        self._remaining = n

    def __call__(self, delay: float) -> None:
        self.calls.append(delay)
        self._remaining -= 1
        if self._remaining <= 0:
            raise _StopTick


def _monotonic_fn(values: list[float]):
    """Return values in sequence; repeat the last one when exhausted.

    time.monotonic is patched globally (time is a module singleton), so asyncio
    internals also hit this mock. Repeating the last value prevents StopIteration
    from exhausting the list mid-coroutine.
    """
    it = iter(values)
    last = [values[-1]]

    def fn() -> float:
        v = next(it, last[0])
        last[0] = v
        return v

    return fn


async def _run_tick_loop(
    server: GameServer, time_sequence: list[float], collector: _SleepCollector
) -> None:
    """Drive _tick_loop with mocked time and sleep until collector stops it."""
    with ExitStack() as stack:
        stack.enter_context(
            patch("faraway_realms.net.server._ServerMetrics", return_value=MagicMock())
        )
        stack.enter_context(
            patch(
                "faraway_realms.net.server.time.monotonic",
                side_effect=_monotonic_fn(time_sequence),
            )
        )
        stack.enter_context(
            patch("faraway_realms.net.server.time.sleep", side_effect=collector)
        )
        try:
            await server._tick_loop()
        except _StopTick:
            pass


def _collect_sleep_calls(time_sequence: list[float], n_sleeps: int) -> list[float]:
    """Run _tick_loop with controlled time; return the first n_sleeps delay values.

    _ServerMetrics is mocked to avoid its own time.monotonic() calls, keeping
    the sequence predictable:
      - 1 call on init  (next_tick = time.monotonic())
      - per normal tick: 5 calls  (t0 / t_game / game_tick_done / work_measure /
        delay_calc)
      - per overrun:     6 calls  (+ resync)
    """
    server = _make_server()
    collector = _SleepCollector(n_sleeps)
    asyncio.run(_run_tick_loop(server, time_sequence, collector))
    return collector.calls


class TestTickScheduler:
    def test_normal_tick_sleeps_remainder(self):
        """5 ms of work on a 100 ms interval → sleep for 95 ms."""
        # calls: [init, t0, t_game, game_tick_done, work_measure, delay_calc]
        time_seq = [0.000, 0.000, 0.000, 0.002, 0.005, 0.005]
        sleeps = _collect_sleep_calls(time_seq, n_sleeps=1)
        assert len(sleeps) == 1
        assert abs(sleeps[0] - 0.095) < 1e-9

    def test_overrun_skips_sleep_and_resyncs(self):
        """120 ms of work overruns the 100 ms interval; sleep is skipped,
        next_tick resyncs, and the following tick sleeps the full remainder."""
        # Tick 1 overrun: [init, t0, t_game, game_tick_done, work_measure,
        #                  delay_calc, resync]
        # Tick 2 normal:  [t0, t_game, game_tick_done, work_measure, delay_calc]
        time_seq = [
            0.000,  # init  → next_tick = 0.0
            0.000,  # t0    tick 1
            0.000,  # t_game tick 1
            0.060,  # game_tick done (60 ms)
            0.120,  # work  tick 1 = 120 ms
            0.120,  # delay = 0.1 - 0.120 = -0.020 → overrun
            0.120,  # resync → next_tick = 0.120
            0.120,  # t0    tick 2
            0.120,  # t_game tick 2
            0.123,  # game_tick done (3 ms)
            0.125,  # work  tick 2 = 5 ms
            0.125,  # delay = (0.120 + 0.1) - 0.125 = 0.095
        ]
        sleeps = _collect_sleep_calls(time_seq, n_sleeps=1)
        assert len(sleeps) == 1
        assert abs(sleeps[0] - 0.095) < 1e-9

    def test_schedule_does_not_drift(self):
        """next_tick advances by exactly interval each tick regardless of work time;
        three consecutive ticks with 5 ms work each all sleep for 95 ms."""
        # calls: [init] + 3 × [t0, t_game, game_tick_done, work_measure, delay_calc]
        time_seq = [0.000]
        for i in range(3):
            base = i * 0.1
            time_seq += [base, base, base + 0.002, base + 0.005, base + 0.005]

        sleeps = _collect_sleep_calls(time_seq, n_sleeps=3)
        assert len(sleeps) == 3
        for s in sleeps:
            assert abs(s - 0.095) < 1e-9
