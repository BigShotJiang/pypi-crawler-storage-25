"""Tests for the ability YAML parser."""

from pathlib import Path

import pytest

from faraway_realms.combat.abilities import (
    ABILITY_REGISTRY,
    Ability,
    ApplyStatusEffect,
    BackstepEffect,
    DamageEffect,
    KnockbackEffect,
    ProjectileEffect,
)
from faraway_realms.content import ContentLoader
from faraway_realms.content_parsers.abilities import parse_abilities
from faraway_realms.entities.components import LightEmitter

_ABILITIES_DIR = Path(__file__).parent.parent / "faraway_realms" / "data" / "abilities"


@pytest.fixture(autouse=True)
def clean_registry():
    """Isolate each test — clear and restore the registry."""
    saved = dict(ABILITY_REGISTRY)
    ABILITY_REGISTRY.clear()
    yield
    ABILITY_REGISTRY.clear()
    ABILITY_REGISTRY.update(saved)


@pytest.fixture()
def load_shipped():
    """Load the shipped YAML data files into the registry."""
    loader = ContentLoader(dirs=[_ABILITIES_DIR])
    loader.register_parser("abilities", parse_abilities)
    loader.load()


# ------------------------------------------------------------------
# Full-stack: parse_abilities populates registry
# ------------------------------------------------------------------


def test_parse_abilities_populates_registry():
    parse_abilities({"kick": {"cooldown": 300, "effects": []}})
    assert "kick" in ABILITY_REGISTRY
    assert isinstance(ABILITY_REGISTRY["kick"], Ability)


# ------------------------------------------------------------------
# Ability field parsing
# ------------------------------------------------------------------


def test_parse_ability_minimal():
    parse_abilities({"zap": {"cooldown": 10}})
    ability = ABILITY_REGISTRY["zap"]
    assert ability.cast_time == 0
    assert ability.range_tiles == 1
    assert ability.can_move_while_casting is False
    assert ability.gcd is True
    assert ability.channel_interval is None
    assert ability.description == ""
    assert ability.abbreviation == ""
    assert ability.resource_cost is None
    assert ability.effects == ()


def test_parse_ability_resource_cost():
    parse_abilities({"fireball": {"cooldown": 30, "resource_cost": ["mana", 15]}})
    assert ABILITY_REGISTRY["fireball"].resource_cost == ("mana", 15)


def test_parse_ability_no_resource_cost():
    parse_abilities({"punch": {"cooldown": 10}})
    assert ABILITY_REGISTRY["punch"].resource_cost is None


def test_parse_ability_no_effects():
    parse_abilities({"taunt": {"cooldown": 20, "effects": []}})
    assert ABILITY_REGISTRY["taunt"].effects == ()


def test_channeled_ability_channel_interval():
    parse_abilities({"channel": {"cooldown": 50, "channel_interval": 5}})
    assert ABILITY_REGISTRY["channel"].channel_interval == 5


# ------------------------------------------------------------------
# Effect parsing
# ------------------------------------------------------------------


def test_parse_damage_effect():
    parse_abilities(
        {
            "stab": {
                "cooldown": 10,
                "effects": [{"kind": "damage", "base": 10, "damage_type": "piercing"}],
            }
        }
    )
    effects = ABILITY_REGISTRY["stab"].effects
    assert len(effects) == 1
    assert isinstance(effects[0], DamageEffect)
    assert effects[0].base == 10
    assert effects[0].damage_type == "piercing"


def test_parse_knockback_effect():
    parse_abilities(
        {"shove": {"cooldown": 10, "effects": [{"kind": "knockback", "distance": 2}]}}
    )
    effect = ABILITY_REGISTRY["shove"].effects[0]
    assert isinstance(effect, KnockbackEffect)
    assert effect.distance == 2


def test_parse_backstep_effect():
    parse_abilities(
        {"flee": {"cooldown": 10, "effects": [{"kind": "backstep", "distance": 3}]}}
    )
    effect = ABILITY_REGISTRY["flee"].effects[0]
    assert isinstance(effect, BackstepEffect)
    assert effect.distance == 3


def test_parse_status_effect_all_fields():
    parse_abilities(
        {
            "curse": {
                "cooldown": 10,
                "effects": [
                    {
                        "kind": "status",
                        "status_name": "bleed",
                        "duration": 20,
                        "tick_damage": 2,
                        "tick_heal": 0,
                        "dot_interval": 5,
                        "immobilize": True,
                        "stun": False,
                        "haste": 0.8,
                        "show_message": False,
                    }
                ],
            }
        }
    )
    effect = ABILITY_REGISTRY["curse"].effects[0]
    assert isinstance(effect, ApplyStatusEffect)
    assert effect.status_name == "bleed"
    assert effect.duration == 20
    assert effect.tick_damage == 2
    assert effect.dot_interval == 5
    assert effect.immobilize is True
    assert effect.stun is False
    assert effect.haste == pytest.approx(0.8)
    assert effect.show_message is False


def test_parse_projectile_effect_with_light_source():
    parse_abilities(
        {
            "firebolt": {
                "cooldown": 30,
                "effects": [
                    {
                        "kind": "projectile",
                        "base": 20,
                        "damage_type": "fire",
                        "speed": 1.5,
                        "color": [255, 100, 0],
                        "trail_length": 4,
                        "trail_char": "+",
                        "components": {
                            "light_emitter": {
                                "radius": 3,
                                "intensity": 0.9,
                                "color": [255, 100, 0],
                            }
                        },
                    }
                ],
            }
        }
    )
    effect = ABILITY_REGISTRY["firebolt"].effects[0]
    assert isinstance(effect, ProjectileEffect)
    assert effect.base == 20
    assert effect.color == (255, 100, 0)
    emitter = effect.components.get("light_emitter")
    assert isinstance(emitter, LightEmitter)
    assert emitter.radius == 3
    assert emitter.intensity == pytest.approx(0.9)
    assert emitter.color == (255, 100, 0)


def test_parse_projectile_effect_on_hit_statuses():
    parse_abilities(
        {
            "icebolt": {
                "cooldown": 40,
                "effects": [
                    {
                        "kind": "projectile",
                        "base": 10,
                        "on_hit_statuses": [
                            {"status_name": "slow", "duration": 30, "haste": 0.6}
                        ],
                    }
                ],
            }
        }
    )
    effect = ABILITY_REGISTRY["icebolt"].effects[0]
    assert isinstance(effect, ProjectileEffect)
    assert len(effect.on_hit_statuses) == 1
    assert effect.on_hit_statuses[0].status_name == "slow"
    assert effect.on_hit_statuses[0].haste == pytest.approx(0.6)


# ------------------------------------------------------------------
# Error cases
# ------------------------------------------------------------------


def test_unknown_effect_kind_raises():
    with pytest.raises(ValueError, match="Unknown ability effect kind"):
        parse_abilities(
            {"teleport": {"cooldown": 10, "effects": [{"kind": "teleport"}]}}
        )


def test_parse_color_invalid_length_raises():
    with pytest.raises(ValueError, match="Color must have exactly 3 components"):
        parse_abilities(
            {
                "bad": {
                    "cooldown": 10,
                    "effects": [{"kind": "projectile", "color": [255, 0]}],
                }
            }
        )


# ------------------------------------------------------------------
# Shipped YAML round-trip
# ------------------------------------------------------------------


def test_shipped_yaml_loads_all_abilities(load_shipped):
    for name in (
        "kick",
        "backstep",
        "parry",
        "second_wind",
        "haste",
        "firebolt",
        "frostbolt",
        "bite",
    ):
        assert name in ABILITY_REGISTRY, f"Missing ability: {name}"


def test_firebolt_from_yaml_has_correct_resource_cost(load_shipped):
    assert ABILITY_REGISTRY["firebolt"].resource_cost == ("mana", 15)


def test_frostbolt_from_yaml_has_light_emitter(load_shipped):
    effect = ABILITY_REGISTRY["frostbolt"].effects[0]
    assert isinstance(effect, ProjectileEffect)
    emitter = effect.components.get("light_emitter")
    assert isinstance(emitter, LightEmitter)
    assert emitter.radius == 2
