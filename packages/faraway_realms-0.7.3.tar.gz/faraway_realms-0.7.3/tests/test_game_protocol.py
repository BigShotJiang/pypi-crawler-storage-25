"""Test that Game satisfies GameProtocol at runtime."""

from __future__ import annotations

import pytest

from faraway_realms.effects.fog import FogParams
from faraway_realms.game import Game
from faraway_realms.game_protocol import GameProtocol
from faraway_realms.world.factions import FactionRelations
from faraway_realms.world.map import make_bordered_map


def _make_game() -> Game:
    return Game(
        game_map=make_bordered_map(20, 20),
        faction_relations=FactionRelations(),
    )


def test_game_satisfies_protocol() -> None:
    game = _make_game()
    assert isinstance(game, GameProtocol)


def test_all_player_entities_empty() -> None:
    game = _make_game()
    assert game.all_player_entities() == []


def test_all_npcs_empty() -> None:
    game = _make_game()
    assert game.all_npcs() == []


def test_entity_missing() -> None:
    game = _make_game()
    assert game.entity(999) is None


def test_game_ambient_default() -> None:
    game = _make_game()
    assert game.ambient == pytest.approx(0.35)


def test_game_ambient_custom() -> None:
    game = Game(
        game_map=make_bordered_map(20, 20),
        faction_relations=FactionRelations(),
        ambient=0.1,
    )
    assert game.ambient == pytest.approx(0.1)


def test_game_fog_params_is_fog_params() -> None:
    game = _make_game()
    assert isinstance(game.fog_params, FogParams)


def test_game_fog_params_custom() -> None:
    fp = FogParams(
        density=0.9,
        scale=0.2,
        wind_x=0.5,
        wind_y=0.3,
        color=(200, 200, 200),
        opacity_min=0.1,
        opacity_max=0.4,
    )
    game = Game(
        game_map=make_bordered_map(20, 20),
        faction_relations=FactionRelations(),
        fog_params=fp,
    )
    assert game.fog_params is fp
