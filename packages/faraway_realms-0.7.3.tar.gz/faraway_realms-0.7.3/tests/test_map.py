import pytest

from faraway_realms.world.map import Map, is_adjacent, make_bordered_map
from faraway_realms.world.tile import floor_tile, wall_tile


def _simple_map(w: int = 5, h: int = 5) -> Map:
    tiles = [[floor_tile() for _ in range(w)] for _ in range(h)]
    return Map(w, h, tiles)


def test_make_bordered_map_dimensions():
    m = make_bordered_map(10, 8)
    assert m.width == 10
    assert m.height == 8


def test_bordered_map_interior_walkable():
    m = make_bordered_map(5, 5)
    for y in range(1, 4):
        for x in range(1, 4):
            assert m.is_walkable(x, y), f"Interior ({x},{y}) should be walkable"


def test_bordered_map_border_not_walkable():
    w, h = 5, 5
    m = make_bordered_map(w, h)
    border_coords = (
        [(x, 0) for x in range(w)]
        + [(x, h - 1) for x in range(w)]
        + [(0, y) for y in range(h)]
        + [(w - 1, y) for y in range(h)]
    )
    for x, y in border_coords:
        assert not m.is_walkable(x, y), f"Border ({x},{y}) should not be walkable"


def test_place_and_get_entity_position():
    m = _simple_map()
    m.place_entity(1, 2, 3)
    assert m.get_entity_position(1) == (2, 3)


def test_move_entity_into_floor():
    m = _simple_map()
    m.place_entity(1, 1, 1)
    result = m.move_entity(1, 1, 0)
    assert result is True
    assert m.get_entity_position(1) == (2, 1)


def test_move_entity_blocked_by_wall():
    m = make_bordered_map(5, 5)
    m.place_entity(1, 1, 1)
    result = m.move_entity(1, -1, 0)  # into left wall
    assert result is False
    assert m.get_entity_position(1) == (1, 1)


def test_move_entity_out_of_bounds():
    m = _simple_map(3, 3)
    m.place_entity(1, 0, 0)
    result = m.move_entity(1, -1, 0)
    assert result is False
    assert m.get_entity_position(1) == (0, 0)


def test_remove_entity():
    m = _simple_map()
    m.place_entity(1, 2, 2)
    m.remove_entity(1)
    with pytest.raises(KeyError):
        m.get_entity_position(1)


def test_remove_entity_missing_raises():
    m = _simple_map()
    with pytest.raises(KeyError):
        m.remove_entity(999)


# ---------------------------------------------------------------------------
# is_adjacent
# ---------------------------------------------------------------------------


def test_is_adjacent_same_tile_false():
    assert not is_adjacent(3, 3, 3, 3)


def test_is_adjacent_cardinal():
    assert is_adjacent(3, 3, 4, 3)
    assert is_adjacent(3, 3, 2, 3)
    assert is_adjacent(3, 3, 3, 4)
    assert is_adjacent(3, 3, 3, 2)


def test_is_adjacent_diagonal():
    assert is_adjacent(3, 3, 4, 4)
    assert is_adjacent(3, 3, 2, 2)


def test_is_adjacent_far_false():
    assert not is_adjacent(0, 0, 5, 5)
    assert not is_adjacent(3, 3, 5, 3)


def test_set_tile_changes_walkability() -> None:
    m = _simple_map()
    assert m.is_walkable(2, 2)
    m.set_tile(2, 2, wall_tile())
    assert not m.is_walkable(2, 2)


def test_set_tile_changes_char() -> None:
    m = _simple_map()
    m.set_tile(1, 1, wall_tile())
    assert m.get_tile(1, 1).char == ord("#")
