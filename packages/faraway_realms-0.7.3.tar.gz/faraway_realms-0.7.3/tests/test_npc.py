from faraway_realms.ai.behaviour import StateMachineBehaviour, WanderState
from faraway_realms.entities.entity import NonPlayerEntity
from faraway_realms.game import Game
from faraway_realms.world.map import make_bordered_map


def _make_game_with_npc(move_every: int = 1) -> tuple[Game, NonPlayerEntity]:
    game_map = make_bordered_map(10, 10)
    npc = NonPlayerEntity(
        entity_id=10,
        char=ord("z"),
        fg_color=(180, 0, 0),
        name="Zombie",
        move_every=move_every,
        faction="hostile",
        behaviour=StateMachineBehaviour(WanderState()),
    )
    game = Game(game_map=game_map)
    game.add_npc(npc)
    game_map.place_entity(npc.entity_id, 5, 5)
    return game, npc


def test_npc_display_name():
    npc = NonPlayerEntity(entity_id=1, char=ord("z"), fg_color=(0, 0, 0), name="Zombie")
    assert npc.display_name == "Zombie"


def test_npc_faction_defaults_to_neutral():
    npc = NonPlayerEntity(
        entity_id=1, char=ord("s"), fg_color=(0, 0, 0), name="Merchant"
    )
    assert npc.faction == "neutral"


def test_npc_faction_can_be_set():
    npc = NonPlayerEntity(
        entity_id=1, char=ord("z"), fg_color=(0, 0, 0), name="Zombie", faction="hostile"
    )
    assert npc.faction == "hostile"


def test_npc_move_every_default():
    npc = NonPlayerEntity(entity_id=1, char=ord("z"), fg_color=(0, 0, 0), name="Zombie")
    assert npc.move_every == 1


def test_npc_moves_every_tick():
    game, npc = _make_game_with_npc(move_every=1)
    start = game.game_map.get_entity_position(npc.entity_id)
    moved = False
    for _ in range(20):
        game.tick()
        if game.game_map.get_entity_position(npc.entity_id) != start:
            moved = True
            break
    assert moved


def test_npc_respects_move_every():
    game, npc = _make_game_with_npc(move_every=3)
    start = game.game_map.get_entity_position(npc.entity_id)

    # Tick 1: no move (1 % 3 != 0)
    game.tick()
    assert game.game_map.get_entity_position(npc.entity_id) == start

    # Tick 2: no move (2 % 3 != 0)
    game.tick()
    assert game.game_map.get_entity_position(npc.entity_id) == start

    # Tick 3: move allowed (3 % 3 == 0) — position may or may not change due to
    # random direction possibly being blocked, so we only assert the tick fires
    game.tick()  # should not raise


def test_npc_behaviour_defaults_to_none():
    npc = NonPlayerEntity(entity_id=1, char=ord("z"), fg_color=(0, 0, 0), name="Zombie")
    assert npc.behaviour is None


def test_npc_behaviour_can_be_set():
    b = StateMachineBehaviour(WanderState(sight_range=6))
    npc = NonPlayerEntity(
        entity_id=1, char=ord("z"), fg_color=(0, 0, 0), name="Zombie", behaviour=b
    )
    assert npc.behaviour is b


def test_add_npc_registers_in_game():
    game_map = make_bordered_map(5, 5)
    game = Game(game_map=game_map)
    npc = NonPlayerEntity(
        entity_id=99,
        char=ord("g"),
        fg_color=(0, 255, 0),
        name="Goblin",
        faction="hostile",
    )
    game.add_npc(npc)
    assert npc in game._npcs  # noqa: SLF001
