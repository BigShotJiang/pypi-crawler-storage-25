"""Tests for faraway_realms.effects.blood."""

from faraway_realms.effects.blood import BloodMap, _blend_color, _pool_alpha


def _make_map(w: int = 20, h: int = 20) -> BloodMap:
    return BloodMap(w, h)


def test_splat_returns_landing_positions():
    bm = _make_map()
    positions = bm.splat(10, 10, 5, 10, (180, 0, 0))
    assert len(positions) == 3


def test_splat_adds_tiles_to_blood_map():
    bm = _make_map()
    bm.splat(10, 10, 5, 10, (180, 0, 0))
    assert len(bm.tiles) > 0


def test_pool_alpha_decreases_with_distance():
    assert _pool_alpha(0) > _pool_alpha(1) > _pool_alpha(2)


def test_pool_alpha_zero_beyond_range():
    assert _pool_alpha(4) == 0
    assert _pool_alpha(10) == 0


def test_blend_color_linear_interpolation():
    result = _blend_color((0, 0, 0), (200, 100, 50), 0.5)
    assert result == (100, 50, 25)


def test_blend_color_at_zero():
    result = _blend_color((100, 50, 0), (200, 100, 50), 0.0)
    assert result == (100, 50, 0)


def test_blend_color_at_one():
    result = _blend_color((0, 0, 0), (200, 100, 50), 1.0)
    assert result == (200, 100, 50)


def test_no_splat_outside_bounds():
    bm = BloodMap(5, 5)
    # Attacker at (0,2), target at (2,2) — drops go rightward, most land outside
    bm.splat(2, 2, 0, 2, (180, 0, 0))
    for pos in bm.tiles:
        assert 0 <= pos[0] < 5
        assert 0 <= pos[1] < 5


def test_blood_direction_away_from_attacker():
    """Drops should land at x < target_x when attacker is to the right."""
    bm = BloodMap(40, 20)
    # Attacker at (20,10), target at (15,10) — blood goes left (x < 15)
    positions = bm.splat(15, 10, 20, 10, (180, 0, 0))
    assert all(px < 15 for px, _ in positions)


def test_alpha_accumulates_on_repeated_hits():
    bm = _make_map()
    bm.splat(10, 10, 5, 10, (180, 0, 0))
    first_alpha = max(t.alpha for t in bm.tiles.values())
    bm.splat(10, 10, 5, 10, (180, 0, 0))
    second_alpha = max(t.alpha for t in bm.tiles.values())
    assert second_alpha >= first_alpha
