"""Tests for display and admin settings loading."""

from faraway_realms.settings import (
    AdminSettings,
    DisplaySettings,
    load_admin_settings,
    load_display_settings,
)

# ---------------------------------------------------------------------------
# DisplaySettings — defaults
# ---------------------------------------------------------------------------


def test_display_defaults(tmp_path, monkeypatch):
    monkeypatch.setattr(
        "faraway_realms.settings._DATA_SETTINGS", tmp_path / "data.yaml"
    )
    monkeypatch.setattr(
        "faraway_realms.settings._USER_SETTINGS", tmp_path / "user.yaml"
    )
    s = load_display_settings()
    assert s == DisplaySettings()


def test_display_data_yaml_overrides_defaults(tmp_path, monkeypatch):
    data = tmp_path / "data.yaml"
    data.write_text("display:\n  integer_scale: 2\n  vsync: true\n")
    monkeypatch.setattr("faraway_realms.settings._DATA_SETTINGS", data)
    monkeypatch.setattr(
        "faraway_realms.settings._USER_SETTINGS", tmp_path / "missing.yaml"
    )
    s = load_display_settings()
    assert s.integer_scale == 2
    assert s.vsync is True


def test_display_user_yaml_wins_over_data(tmp_path, monkeypatch):
    data = tmp_path / "data.yaml"
    data.write_text("display:\n  integer_scale: 2\n")
    user = tmp_path / "user.yaml"
    user.write_text("display:\n  integer_scale: 3\n")
    monkeypatch.setattr("faraway_realms.settings._DATA_SETTINGS", data)
    monkeypatch.setattr("faraway_realms.settings._USER_SETTINGS", user)
    s = load_display_settings()
    assert s.integer_scale == 3


def test_display_window_position(tmp_path, monkeypatch):
    data = tmp_path / "data.yaml"
    data.write_text("display:\n  window_x: 100\n  window_y: 200\n")
    monkeypatch.setattr("faraway_realms.settings._DATA_SETTINGS", data)
    monkeypatch.setattr(
        "faraway_realms.settings._USER_SETTINGS", tmp_path / "missing.yaml"
    )
    s = load_display_settings()
    assert s.window_x == 100
    assert s.window_y == 200


def test_display_no_window_position_is_none(tmp_path, monkeypatch):
    monkeypatch.setattr(
        "faraway_realms.settings._DATA_SETTINGS", tmp_path / "missing.yaml"
    )
    monkeypatch.setattr(
        "faraway_realms.settings._USER_SETTINGS", tmp_path / "missing.yaml"
    )
    s = load_display_settings()
    assert s.window_x is None
    assert s.window_y is None


# ---------------------------------------------------------------------------
# AdminSettings — defaults
# ---------------------------------------------------------------------------


def test_admin_defaults_no_loki(tmp_path, monkeypatch):
    monkeypatch.setattr(
        "faraway_realms.settings._DATA_SETTINGS", tmp_path / "missing.yaml"
    )
    monkeypatch.setattr(
        "faraway_realms.settings._USER_SETTINGS", tmp_path / "missing.yaml"
    )
    monkeypatch.delenv("FARAWAY_LOKI_URL", raising=False)
    s = load_admin_settings()
    assert s == AdminSettings()
    assert s.loki_url is None


def test_admin_loki_url_from_data_yaml(tmp_path, monkeypatch):
    data = tmp_path / "data.yaml"
    data.write_text("admin:\n  loki_url: http://data-loki:3100\n")
    monkeypatch.setattr("faraway_realms.settings._DATA_SETTINGS", data)
    monkeypatch.setattr(
        "faraway_realms.settings._USER_SETTINGS", tmp_path / "missing.yaml"
    )
    monkeypatch.delenv("FARAWAY_LOKI_URL", raising=False)
    s = load_admin_settings()
    assert s.loki_url == "http://data-loki:3100"


def test_admin_user_yaml_wins_over_data(tmp_path, monkeypatch):
    data = tmp_path / "data.yaml"
    data.write_text("admin:\n  loki_url: http://data-loki:3100\n")
    user = tmp_path / "user.yaml"
    user.write_text("admin:\n  loki_url: http://user-loki:3100\n")
    monkeypatch.setattr("faraway_realms.settings._DATA_SETTINGS", data)
    monkeypatch.setattr("faraway_realms.settings._USER_SETTINGS", user)
    monkeypatch.delenv("FARAWAY_LOKI_URL", raising=False)
    s = load_admin_settings()
    assert s.loki_url == "http://user-loki:3100"


def test_admin_env_var_fallback(tmp_path, monkeypatch):
    monkeypatch.setattr(
        "faraway_realms.settings._DATA_SETTINGS", tmp_path / "missing.yaml"
    )
    monkeypatch.setattr(
        "faraway_realms.settings._USER_SETTINGS", tmp_path / "missing.yaml"
    )
    monkeypatch.setenv("FARAWAY_LOKI_URL", "http://env-loki:3100")
    s = load_admin_settings()
    assert s.loki_url == "http://env-loki:3100"


def test_admin_yaml_wins_over_env_var(tmp_path, monkeypatch):
    data = tmp_path / "data.yaml"
    data.write_text("admin:\n  loki_url: http://yaml-loki:3100\n")
    monkeypatch.setattr("faraway_realms.settings._DATA_SETTINGS", data)
    monkeypatch.setattr(
        "faraway_realms.settings._USER_SETTINGS", tmp_path / "missing.yaml"
    )
    monkeypatch.setenv("FARAWAY_LOKI_URL", "http://env-loki:3100")
    s = load_admin_settings()
    assert s.loki_url == "http://yaml-loki:3100"


def test_admin_null_admin_key_in_yaml(tmp_path, monkeypatch):
    """admin: key present but empty (no sub-keys) must not crash."""
    data = tmp_path / "data.yaml"
    data.write_text("admin:\n")
    monkeypatch.setattr("faraway_realms.settings._DATA_SETTINGS", data)
    monkeypatch.setattr(
        "faraway_realms.settings._USER_SETTINGS", tmp_path / "missing.yaml"
    )
    monkeypatch.delenv("FARAWAY_LOKI_URL", raising=False)
    s = load_admin_settings()
    assert s.loki_url is None


def test_admin_null_admin_key_user_yaml(tmp_path, monkeypatch):
    """admin: key present but empty in user settings must not crash."""
    user = tmp_path / "user.yaml"
    user.write_text("admin:\n")
    monkeypatch.setattr(
        "faraway_realms.settings._DATA_SETTINGS", tmp_path / "missing.yaml"
    )
    monkeypatch.setattr("faraway_realms.settings._USER_SETTINGS", user)
    monkeypatch.delenv("FARAWAY_LOKI_URL", raising=False)
    s = load_admin_settings()
    assert s.loki_url is None
