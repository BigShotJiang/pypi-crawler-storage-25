"""Tests for fog overlay rendering — alpha shape/range, wind, render blending."""

import numpy as np
import tcod.console

from faraway_realms.effects.fog import FogParams, fog_alpha, render_fog


def _console(w: int = 20, h: int = 15) -> tcod.console.Console:
    return tcod.console.Console(w, h, order="C")


# ---------------------------------------------------------------------------
# fog_alpha
# ---------------------------------------------------------------------------


def test_fog_alpha_shape():
    alpha = fog_alpha((0, 0), 10, 15, 0.0, FogParams())
    assert alpha.shape == (10, 15)


def test_fog_alpha_in_range():
    alpha = fog_alpha((0, 0), 10, 15, 0.0, FogParams())
    assert float(alpha.min()) >= 0.0
    assert float(alpha.max()) <= 1.0


def test_fog_alpha_zero_opacity_is_zero():
    params = FogParams(opacity_min=0.0, opacity_max=0.0)
    alpha = fog_alpha((0, 0), 5, 5, 0.0, params)
    assert np.all(alpha == 0.0)


def test_fog_alpha_wind_shifts_output():
    params = FogParams(wind_x=10.0, wind_y=0.0)
    a1 = fog_alpha((0, 0), 10, 10, 0.0, params)
    a2 = fog_alpha((0, 0), 10, 10, 1.0, params)
    assert not np.allclose(a1, a2)


def test_fog_alpha_cam_produces_different_pattern():
    params = FogParams(wind_x=0.0, wind_y=0.0)
    a1 = fog_alpha((0, 0), 8, 8, 0.0, params)
    a2 = fog_alpha((50, 50), 8, 8, 0.0, params)
    assert not np.allclose(a1, a2)


def test_fog_alpha_different_seeds_differ():
    a1 = fog_alpha((0, 0), 8, 8, 0.0, FogParams(seed=1))
    a2 = fog_alpha((0, 0), 8, 8, 0.0, FogParams(seed=99))
    assert not np.allclose(a1, a2)


# ---------------------------------------------------------------------------
# render_fog
# ---------------------------------------------------------------------------


def test_render_fog_blends_bg_toward_fog_color():
    console = _console()
    console.rgb["bg"] = (200, 200, 200)
    # half opacity, black fog → result should be ~100 per channel
    params = FogParams(opacity_min=0.5, opacity_max=0.5, color=(0, 0, 0))
    render_fog(console, (0, 0), 0, 0, 20, 15, 0.0, params)
    assert int(console.rgb["bg"][5, 10][0]) < 200


def test_render_fog_blends_fg_toward_fog_color():
    console = _console()
    console.rgb["fg"] = (200, 200, 200)
    params = FogParams(opacity_min=0.5, opacity_max=0.5, color=(0, 0, 0))
    render_fog(console, (0, 0), 0, 0, 20, 15, 0.0, params)
    assert int(console.rgb["fg"][5, 10][0]) < 200


def test_render_fog_zero_opacity_leaves_console_unchanged():
    console = _console()
    console.rgb["bg"] = (100, 150, 200)
    console.rgb["fg"] = (50, 60, 70)
    bg_before = console.rgb["bg"].copy()
    fg_before = console.rgb["fg"].copy()
    params = FogParams(opacity_min=0.0, opacity_max=0.0)
    render_fog(console, (0, 0), 0, 0, 20, 15, 0.0, params)
    assert np.array_equal(console.rgb["bg"], bg_before)
    assert np.array_equal(console.rgb["fg"], fg_before)


def test_render_fog_full_opacity_produces_fog_color():
    console = _console()
    console.rgb["bg"] = (200, 150, 100)
    # opacity_min == opacity_max == 1.0 → alpha is always 1.0
    fog_color = (30, 40, 50)
    params = FogParams(opacity_min=1.0, opacity_max=1.0, color=fog_color)
    render_fog(console, (0, 0), 0, 0, 20, 15, 0.0, params)
    assert tuple(console.rgb["bg"][7, 7].tolist()) == fog_color


def test_render_fog_only_affects_pane_region():
    console = _console()
    console.rgb["bg"] = (200, 200, 200)
    # full opacity black fog in a 5×5 sub-pane starting at (5, 5)
    params = FogParams(opacity_min=1.0, opacity_max=1.0, color=(0, 0, 0))
    render_fog(console, (0, 0), 5, 5, 5, 5, 0.0, params)
    # outside pane: unchanged
    assert int(console.rgb["bg"][0, 0][0]) == 200
    assert int(console.rgb["bg"][4, 4][0]) == 200
    # inside pane: fog applied
    assert int(console.rgb["bg"][7, 7][0]) == 0
