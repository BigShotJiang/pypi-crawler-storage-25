"""Tests for InteractionSystem and door tile mechanics."""

from __future__ import annotations

from faraway_realms.entities.components import OpenableComponent
from faraway_realms.systems.interaction_system import InteractionSystem
from faraway_realms.world.events import EventType
from faraway_realms.world.map import Map
from faraway_realms.world.tile import TILE_REGISTRY, Tile

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_walkable_tile() -> Tile:
    return Tile(walkable=True, bg_color=(0, 0, 0), fg_color=(255, 255, 255))


def _make_wall_tile() -> Tile:
    return Tile(walkable=False, bg_color=(0, 0, 0), fg_color=(255, 255, 255))


def _simple_map(width: int = 5, height: int = 5) -> Map:
    tiles = [[_make_walkable_tile() for _ in range(width)] for _ in range(height)]
    return Map(width, height, tiles)


class FakeBus:
    def __init__(self) -> None:
        self.published: list = []

    def publish(self, event) -> None:
        self.published.append(event)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_interact_no_openable_component_is_noop() -> None:
    game_map = _simple_map()
    actor_id = 1
    game_map.place_entity(actor_id, 2, 2)
    bus = FakeBus()
    system = InteractionSystem(game_map, bus)

    system.handle(actor_id, "right")

    assert bus.published == []


def test_interact_opens_closed_door() -> None:
    game_map = _simple_map()
    actor_id = 1
    game_map.place_entity(actor_id, 1, 2)

    # Place a closed door tile to the right
    closed = Tile(
        walkable=False,
        bg_color=(30, 25, 18),
        fg_color=(160, 120, 60),
        components={
            "openable": OpenableComponent(
                open_tile="dungeon_door_open",
                closed_tile="dungeon_door_closed",
            )
        },
    )
    game_map._tiles[2][2] = closed  # noqa: SLF001

    bus = FakeBus()
    system = InteractionSystem(game_map, bus)

    system.handle(actor_id, "right")

    # Tile should be replaced with the open variant from registry
    new_tile = game_map.get_tile(2, 2)
    assert new_tile.walkable is True
    assert len(bus.published) == 1
    event = bus.published[0]
    assert event.event_type == EventType.TILE_INTERACTED
    assert event.payload["action"] == "opened"
    assert (2, 2) in game_map._dirty_tiles  # noqa: SLF001


def test_interact_closes_open_door() -> None:
    game_map = _simple_map()
    actor_id = 1
    game_map.place_entity(actor_id, 1, 2)

    # Place an open door tile to the right
    open_door = Tile(
        walkable=True,
        bg_color=(30, 25, 18),
        fg_color=(130, 95, 45),
        components={
            "openable": OpenableComponent(
                open_tile="dungeon_door_open",
                closed_tile="dungeon_door_closed",
            )
        },
    )
    game_map._tiles[2][2] = open_door  # noqa: SLF001

    bus = FakeBus()
    system = InteractionSystem(game_map, bus)

    system.handle(actor_id, "right")

    new_tile = game_map.get_tile(2, 2)
    assert new_tile.walkable is False
    assert bus.published[0].payload["action"] == "closed"


def test_interact_unknown_direction_is_noop() -> None:
    game_map = _simple_map()
    actor_id = 1
    game_map.place_entity(actor_id, 2, 2)
    bus = FakeBus()
    system = InteractionSystem(game_map, bus)

    system.handle(actor_id, "diagonal")

    assert bus.published == []


def test_door_tiles_registered() -> None:
    assert "dungeon_door_closed" in TILE_REGISTRY
    assert "dungeon_door_open" in TILE_REGISTRY
    closed_type = TILE_REGISTRY["dungeon_door_closed"]
    open_type = TILE_REGISTRY["dungeon_door_open"]
    assert closed_type.walkable is False
    assert open_type.walkable is True
    openable_closed = closed_type.components.get("openable")
    assert isinstance(openable_closed, OpenableComponent)
    assert openable_closed.open_tile == "dungeon_door_open"
    assert openable_closed.closed_tile == "dungeon_door_closed"


def test_interact_command_parsed() -> None:
    from faraway_realms.world.commands import CommandParser, CommandType

    parser = CommandParser()
    cmd = parser.parse("/open left")
    assert cmd.command_type == CommandType.INTERACT
    assert cmd.args == ("left",)
    assert cmd.actor == "@self"


def test_interact_all_directions() -> None:
    directions = ["left", "right", "up", "down"]
    deltas = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    for direction, (edx, edy) in zip(directions, deltas, strict=True):
        game_map = _simple_map()
        actor_id = 1
        ax, ay = 2, 2
        game_map.place_entity(actor_id, ax, ay)
        tx, ty = ax + edx, ay + edy
        closed = Tile(
            walkable=False,
            bg_color=(0, 0, 0),
            fg_color=(0, 0, 0),
            components={
                "openable": OpenableComponent(
                    open_tile="dungeon_door_open",
                    closed_tile="dungeon_door_closed",
                )
            },
        )
        game_map._tiles[ty][tx] = closed  # noqa: SLF001
        bus = FakeBus()
        system = InteractionSystem(game_map, bus)
        system.handle(actor_id, direction)
        assert game_map.get_tile(tx, ty).walkable is True, f"failed for {direction}"
