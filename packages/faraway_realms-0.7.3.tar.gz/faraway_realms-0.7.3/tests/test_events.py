"""Tests for the event system."""

from faraway_realms.entities.entity import CharacterEntity, NonPlayerEntity, Player
from faraway_realms.game import Game
from faraway_realms.world.commands import Command, CommandParser, CommandType
from faraway_realms.world.events import Event, EventType
from faraway_realms.world.factions import FactionRelations
from faraway_realms.world.map import make_bordered_map


def _make_game() -> tuple[Game, Player]:
    game_map = make_bordered_map(20, 20)
    entity = CharacterEntity(
        entity_id=1,
        char=ord("@"),
        fg_color=(255, 255, 0),
        name="Hero",
        faction="player",
    )
    player = Player(username="tester", entity=entity)
    relations = FactionRelations()
    relations.set_hostile("player", "hostile", True)
    game = Game(game_map=game_map, faction_relations=relations)
    game.add_player(player)
    game_map.place_entity(entity.entity_id, 10, 10)
    return game, player


def _hostile_npc(entity_id: int, x: int, y: int, game: Game) -> NonPlayerEntity:
    npc = NonPlayerEntity(
        entity_id=entity_id,
        char=ord("Z"),
        fg_color=(0, 180, 0),
        name="Zombie",
        faction="hostile",
    )
    game.add_npc(npc)
    game.game_map.place_entity(npc.entity_id, x, y)
    return npc


# ---------------------------------------------------------------------------
# Event dataclass
# ---------------------------------------------------------------------------


def test_event_is_frozen() -> None:
    event = Event(event_type=EventType.CONTACT, source_id=1, target_id=2)
    try:
        event.source_id = 99  # type: ignore[misc]
        raise AssertionError("Should have raised")
    except AttributeError, TypeError:
        pass


def test_event_resolve_at_tick_defaults_to_zero() -> None:
    event = Event(event_type=EventType.CONTACT, source_id=1)
    assert event.resolve_at_tick == 0


def test_event_payload_defaults_to_none() -> None:
    event = Event(event_type=EventType.ENTITY_DYING, source_id=1)
    assert event.payload is None


def test_event_deferred_tick() -> None:
    event = Event(event_type=EventType.CONTACT, source_id=1, resolve_at_tick=5)
    assert event.resolve_at_tick == 5


# ---------------------------------------------------------------------------
# emit_event / event queue
# ---------------------------------------------------------------------------


def test_emit_event_adds_to_queue() -> None:
    game, _ = _make_game()
    event = Event(event_type=EventType.CONTACT, source_id=2, target_id=1)
    game.emit_event(event)
    assert event in game._bus._queue  # noqa: SLF001


def test_drain_events_clears_ready_events() -> None:
    game, _ = _make_game()
    game.emit_event(Event(event_type=EventType.CONTACT, source_id=2, target_id=1))
    game.tick()
    assert game._bus.pending_count == 0  # noqa: SLF001


def test_deferred_event_stays_in_queue_until_tick() -> None:
    game, _ = _make_game()
    game.emit_event(
        Event(event_type=EventType.CONTACT, source_id=2, target_id=1, resolve_at_tick=5)
    )
    game.tick()  # _abs_tick = 1
    assert game._bus.pending_count == 1  # noqa: SLF001


def test_deferred_event_resolves_at_correct_tick() -> None:
    game, _ = _make_game()
    game.emit_event(
        Event(event_type=EventType.CONTACT, source_id=2, target_id=1, resolve_at_tick=3)
    )
    for _ in range(2):
        game.tick()
    assert game._bus.pending_count == 1  # noqa: SLF001 — _abs_tick=2, still deferred
    game.tick()  # _abs_tick = 3 — now ready
    assert game._bus.pending_count == 0  # noqa: SLF001


# ---------------------------------------------------------------------------
# Contact detection — player moves
# ---------------------------------------------------------------------------


def test_contact_emitted_when_player_moves_adjacent_to_hostile() -> None:
    game, _ = _make_game()
    _hostile_npc(2, 12, 10, game)  # two tiles right of player
    called = []
    game._bus.subscribe(EventType.CONTACT, called.append, priority=5)  # noqa: SLF001
    parser = CommandParser()
    game.enqueue_command(parser.parse("/move right"))
    game.tick()
    # Player moves to (11, 10), zombie at (12, 10) — adjacent
    assert any(e.source_id == 1 and e.target_id == 2 for e in called)


def test_contact_not_emitted_for_neutral_npc() -> None:
    game, _ = _make_game()
    npc = NonPlayerEntity(
        entity_id=2,
        char=ord("M"),
        fg_color=(0, 180, 0),
        name="Merchant",
        faction="neutral",
    )
    game.add_npc(npc)
    game.game_map.place_entity(npc.entity_id, 12, 10)
    called = []
    game._bus.subscribe(EventType.CONTACT, called.append, priority=5)  # noqa: SLF001
    parser = CommandParser()
    game.enqueue_command(parser.parse("/move right"))
    game.tick()
    assert called == []


# ---------------------------------------------------------------------------
# Contact detection — NPC moves
# ---------------------------------------------------------------------------


def test_contact_emitted_when_npc_moves_adjacent_to_player() -> None:
    game, _ = _make_game()
    _hostile_npc(2, 12, 10, game)  # 2 tiles right of player
    called = []
    game._bus.subscribe(EventType.CONTACT, called.append, priority=5)  # noqa: SLF001
    game.enqueue_command(
        Command(
            command_type=CommandType.MOVE,
            actor="2",
            args=("left",),
            raw="/move 2 left",
        )
    )
    game.tick()
    # NPC moves to (11, 10), player at (10, 10) — adjacent
    assert any(e.source_id == 2 and e.target_id == 1 for e in called)


# ---------------------------------------------------------------------------
# Contact detection — NPC vs NPC (different factions)
# ---------------------------------------------------------------------------


def test_contact_emitted_for_npc_vs_npc_hostile_factions() -> None:
    game_map = make_bordered_map(20, 20)
    relations = FactionRelations()
    relations.set_hostile("guard", "hostile", True)
    game = Game(game_map=game_map, faction_relations=relations)

    goblin = NonPlayerEntity(
        entity_id=1,
        char=ord("g"),
        fg_color=(0, 200, 0),
        name="Goblin",
        faction="hostile",
    )
    guard = NonPlayerEntity(
        entity_id=2,
        char=ord("G"),
        fg_color=(200, 200, 0),
        name="Guard",
        faction="guard",
    )
    game.add_npc(goblin)
    game.add_npc(guard)
    game_map.place_entity(goblin.entity_id, 5, 5)
    game_map.place_entity(guard.entity_id, 7, 5)

    called = []
    game._bus.subscribe(EventType.CONTACT, called.append, priority=5)  # noqa: SLF001
    game.enqueue_command(
        Command(
            command_type=CommandType.MOVE,
            actor="1",
            args=("right",),
            raw="/move 1 right",
        )
    )
    game.tick()
    # Goblin moves to (6, 5), guard at (7, 5) — adjacent, hostile factions
    assert any(e.source_id == 1 and e.target_id == 2 for e in called)


def test_no_contact_between_same_faction_npcs() -> None:
    game_map = make_bordered_map(20, 20)
    game = Game(game_map=game_map)  # no hostile pairs configured

    goblin1 = NonPlayerEntity(
        entity_id=1,
        char=ord("g"),
        fg_color=(0, 200, 0),
        name="Goblin1",
        faction="hostile",
    )
    goblin2 = NonPlayerEntity(
        entity_id=2,
        char=ord("g"),
        fg_color=(0, 200, 0),
        name="Goblin2",
        faction="hostile",
    )
    game.add_npc(goblin1)
    game.add_npc(goblin2)
    game_map.place_entity(goblin1.entity_id, 5, 5)
    game_map.place_entity(goblin2.entity_id, 7, 5)

    called = []
    game._bus.subscribe(EventType.CONTACT, called.append, priority=5)  # noqa: SLF001
    game.enqueue_command(
        Command(
            command_type=CommandType.MOVE,
            actor="1",
            args=("right",),
            raw="/move 1 right",
        )
    )
    game.tick()
    assert called == []


# ---------------------------------------------------------------------------
# _resolve_actor handles numeric IDs
# ---------------------------------------------------------------------------


def test_resolve_actor_numeric_id() -> None:
    game, _ = _make_game()
    game.game_map.place_entity(99, 5, 5)
    game.enqueue_command(
        Command(
            command_type=CommandType.MOVE,
            actor="99",
            args=("right",),
            raw="/move 99 right",
        )
    )
    game.tick()
    assert game.game_map.get_entity_position(99) == (6, 5)
