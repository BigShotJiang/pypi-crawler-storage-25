"""Tests for the EventBus."""

from faraway_realms.world.event_bus import EventBus
from faraway_realms.world.events import Event, EventType


def _contact(resolve_at: int = 0) -> Event:
    return Event(event_type=EventType.CONTACT, source_id=1, resolve_at_tick=resolve_at)


def _death(resolve_at: int = 0) -> Event:
    return Event(
        event_type=EventType.ENTITY_DYING, source_id=2, resolve_at_tick=resolve_at
    )


# ---------------------------------------------------------------------------
# subscribe / publish / flush basics
# ---------------------------------------------------------------------------


def test_handler_called_on_flush() -> None:
    bus = EventBus()
    received = []
    bus.subscribe(EventType.CONTACT, received.append)
    bus.publish(_contact())
    bus.flush(abs_tick=1)
    assert len(received) == 1
    assert received[0].event_type == EventType.CONTACT


def test_handler_not_called_before_flush() -> None:
    bus = EventBus()
    received = []
    bus.subscribe(EventType.CONTACT, received.append)
    bus.publish(_contact())
    assert received == []


def test_handler_not_called_for_different_type() -> None:
    bus = EventBus()
    received = []
    bus.subscribe(EventType.ENTITY_DYING, received.append)
    bus.publish(_contact())
    bus.flush(abs_tick=1)
    assert received == []


def test_pending_count_before_and_after_flush() -> None:
    bus = EventBus()
    bus.publish(_contact())
    bus.publish(_death())
    assert bus.pending_count == 2
    bus.flush(abs_tick=1)
    assert bus.pending_count == 0


# ---------------------------------------------------------------------------
# Deferred events
# ---------------------------------------------------------------------------


def test_deferred_event_not_delivered_early() -> None:
    bus = EventBus()
    received = []
    bus.subscribe(EventType.CONTACT, received.append)
    bus.publish(_contact(resolve_at=5))
    bus.flush(abs_tick=3)
    assert received == []
    assert bus.pending_count == 1


def test_deferred_event_delivered_at_correct_tick() -> None:
    bus = EventBus()
    received = []
    bus.subscribe(EventType.CONTACT, received.append)
    bus.publish(_contact(resolve_at=5))
    bus.flush(abs_tick=5)
    assert len(received) == 1


# ---------------------------------------------------------------------------
# Priority ordering
# ---------------------------------------------------------------------------


def test_lower_priority_called_first() -> None:
    bus = EventBus()
    order = []
    bus.subscribe(EventType.CONTACT, lambda _: order.append("high"), priority=10)
    bus.subscribe(EventType.CONTACT, lambda _: order.append("low"), priority=0)
    bus.publish(_contact())
    bus.flush(abs_tick=1)
    assert order == ["low", "high"]


def test_same_priority_fifo() -> None:
    bus = EventBus()
    order = []
    bus.subscribe(EventType.CONTACT, lambda _: order.append("first"), priority=5)
    bus.subscribe(EventType.CONTACT, lambda _: order.append("second"), priority=5)
    bus.publish(_contact())
    bus.flush(abs_tick=1)
    assert order == ["first", "second"]


# ---------------------------------------------------------------------------
# Cascade / depth limiting
# ---------------------------------------------------------------------------


def test_cascade_handler_can_publish_new_event() -> None:
    bus = EventBus()
    received = []

    def on_contact(event: Event) -> None:
        # Cascade: publish an ENTITY_DYING when CONTACT arrives
        bus.publish(_death())

    bus.subscribe(EventType.CONTACT, on_contact)
    bus.subscribe(EventType.ENTITY_DYING, received.append)
    bus.publish(_contact())
    bus.flush(abs_tick=1)
    assert len(received) == 1


def test_depth_limit_prevents_infinite_cascade() -> None:
    bus = EventBus()
    count = []

    def on_contact(event: Event) -> None:
        count.append(1)
        bus.publish(_contact())  # infinite loop without depth limit

    bus.subscribe(EventType.CONTACT, on_contact)
    bus.publish(_contact())
    bus.flush(abs_tick=1, depth=5)
    assert len(count) == 5


# ---------------------------------------------------------------------------
# purge
# ---------------------------------------------------------------------------


def test_purge_removes_matching_events() -> None:
    bus = EventBus()
    bus.publish(_contact(resolve_at=10))
    bus.publish(_death(resolve_at=10))
    bus.purge(lambda e: e.event_type == EventType.CONTACT)
    assert bus.pending_count == 1
    bus.flush(abs_tick=10)
    # only the ENTITY_DYING event remains
    received = []
    bus.subscribe(EventType.CONTACT, received.append)
    assert received == []


def test_purge_by_source_id() -> None:
    bus = EventBus()
    e1 = Event(event_type=EventType.CAST_COMPLETE, source_id=1, resolve_at_tick=5)
    e2 = Event(event_type=EventType.CAST_COMPLETE, source_id=2, resolve_at_tick=5)
    bus.publish(e1)
    bus.publish(e2)
    bus.purge(lambda e: e.source_id == 1)
    assert bus.pending_count == 1
    assert bus._queue[0].source_id == 2  # noqa: SLF001


def test_purge_noop_when_no_match() -> None:
    bus = EventBus()
    bus.publish(_contact(resolve_at=5))
    bus.purge(lambda e: e.event_type == EventType.ENTITY_DYING)
    assert bus.pending_count == 1


# ---------------------------------------------------------------------------
# Multiple subscribers same type
# ---------------------------------------------------------------------------


def test_multiple_handlers_all_called() -> None:
    bus = EventBus()
    a, b = [], []
    bus.subscribe(EventType.CONTACT, a.append)
    bus.subscribe(EventType.CONTACT, b.append)
    bus.publish(_contact())
    bus.flush(abs_tick=1)
    assert len(a) == 1
    assert len(b) == 1
