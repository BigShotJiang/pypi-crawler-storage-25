"""Tests for per-client visibility culling in the network layer."""

from __future__ import annotations

from unittest.mock import MagicMock

from faraway_realms.net.serialization import (
    EntitySnapshot,
    serialize_per_client,
    serialize_shared,
)


def _make_snap(
    entity_id: int, x: int, y: int, is_player: bool = False
) -> EntitySnapshot:
    return EntitySnapshot(
        entity_id=entity_id,
        x=x,
        y=y,
        type_id="hero" if is_player else "zombie",
        target_id=None,
        stats={},
        status_effects=[],
    )


def _make_game_stub():
    stub = MagicMock()
    stub.attack_cooldown_fraction.return_value = 0.0
    stub.gcd_fraction.return_value = None
    stub.cast_fraction.return_value = None
    stub.entity.return_value = None
    stub.ability_cooldown_fraction.return_value = None
    # game_map.get_tile is called by serialize_tile_sparse for each new tile
    stub.game_map.get_tile.return_value = MagicMock(
        walkable=True, char=ord("."), fg_color=(200, 200, 200), bg_color=(50, 50, 50)
    )
    return stub


class TestFovFiltering:
    def test_entity_in_fov_included(self):
        snaps = [_make_snap(1, 5, 5, is_player=True), _make_snap(2, 6, 6)]
        visible = frozenset([(5, 5), (6, 6)])
        result = serialize_per_client(
            _make_game_stub(), 1, snaps, visible, frozenset(), set()
        )
        ids = [e["entity_id"] for e in result["entities"]]
        assert 2 in ids

    def test_entity_outside_fov_excluded(self):
        snaps = [_make_snap(1, 5, 5, is_player=True), _make_snap(2, 50, 50)]
        visible = frozenset([(5, 5)])
        result = serialize_per_client(
            _make_game_stub(), 1, snaps, visible, frozenset(), set()
        )
        ids = [e["entity_id"] for e in result["entities"]]
        assert 2 not in ids

    def test_player_entity_always_included(self):
        snaps = [_make_snap(1, 5, 5, is_player=True)]
        # Player tile is not in visible_tiles — should still appear
        result = serialize_per_client(
            _make_game_stub(), 1, snaps, frozenset(), frozenset(), set()
        )
        ids = [e["entity_id"] for e in result["entities"]]
        assert 1 in ids

    def test_removed_ids_in_payload(self):
        snaps = [_make_snap(1, 5, 5, is_player=True)]
        removed = frozenset([99, 100])
        result = serialize_per_client(
            _make_game_stub(), 1, snaps, frozenset([(5, 5)]), removed, set()
        )
        assert set(result["removed_entity_ids"]) == {99, 100}

    def test_no_removed_ids_when_empty(self):
        snaps = [_make_snap(1, 5, 5, is_player=True)]
        result = serialize_per_client(
            _make_game_stub(), 1, snaps, frozenset([(5, 5)]), frozenset(), set()
        )
        assert result["removed_entity_ids"] == []

    def test_shared_has_no_entities_key(self):
        """serialize_shared must not include 'entities' — that is per-client."""
        from unittest.mock import MagicMock

        game = MagicMock()
        game.active_projectiles = []
        game.light_sources.return_value = []
        result = serialize_shared(game)
        assert "entities" not in result


class TestSessionVisibilityTracking:
    def test_update_session_entities_tracks_visible(self):
        from faraway_realms.net.server import _ClientSession, _update_session_entities

        session = _ClientSession(uuid="x", entity_id=1)
        snaps = [_make_snap(1, 5, 5, is_player=True), _make_snap(2, 6, 6)]
        visible = frozenset([(5, 5), (6, 6)])
        removed = _update_session_entities(session, snaps, visible)
        assert removed == frozenset()
        assert 1 in session.visible_entity_ids
        assert 2 in session.visible_entity_ids

    def test_update_session_entities_detects_leaving(self):
        from faraway_realms.net.server import _ClientSession, _update_session_entities

        session = _ClientSession(uuid="x", entity_id=1)
        session.visible_entity_ids = frozenset([1, 2])
        # Entity 2 moved out of FOV this tick
        snaps = [_make_snap(1, 5, 5, is_player=True), _make_snap(2, 50, 50)]
        visible = frozenset([(5, 5)])
        removed = _update_session_entities(session, snaps, visible)
        assert 2 in removed
        assert 2 not in session.visible_entity_ids

    def test_player_entity_never_removed(self):
        from faraway_realms.net.server import _ClientSession, _update_session_entities

        session = _ClientSession(uuid="x", entity_id=1)
        session.visible_entity_ids = frozenset([1])
        snaps = [_make_snap(1, 5, 5, is_player=True)]
        # Player tile not in visible — still not removed (always kept)
        removed = _update_session_entities(session, snaps, frozenset())
        assert 1 not in removed
        assert 1 in session.visible_entity_ids

    def test_explored_tiles_accumulate(self):
        from faraway_realms.net.server import _ClientSession

        session = _ClientSession(uuid="x", entity_id=1)
        session.explored_tiles = {(0, 0), (1, 0)}
        new_visible = frozenset([(1, 0), (2, 0)])
        new_tiles = new_visible - session.explored_tiles
        session.explored_tiles |= new_visible
        assert new_tiles == {(2, 0)}
        assert session.explored_tiles == {(0, 0), (1, 0), (2, 0)}

    def test_tile_reveals_in_per_client_payload(self):
        snaps = [_make_snap(1, 5, 5, is_player=True)]
        new_tiles = {(5, 5), (6, 5)}
        result = serialize_per_client(
            _make_game_stub(), 1, snaps, frozenset([(5, 5)]), frozenset(), new_tiles
        )
        coords = {(t["x"], t["y"]) for t in result["tile_reveals"]}
        assert coords == {(5, 5), (6, 5)}


class TestStaticObjectReveals:
    """serialize_per_client static_object_reveals content."""

    def test_collect_only_objects_on_new_tiles(self):
        from faraway_realms.entities.static_object import StaticObject
        from faraway_realms.net.serialization import _collect_static_reveals

        game = MagicMock()
        game.static_objects = [
            StaticObject(x=5, y=5, char=ord("T"), fg_color=(255, 200, 0)),
            StaticObject(x=10, y=10, char=ord("M"), fg_color=(0, 200, 100)),
        ]
        result = _collect_static_reveals(game, {(5, 5)})
        assert len(result) == 1
        assert result[0]["x"] == 5
        assert result[0]["y"] == 5

    def test_collect_empty_when_no_new_tiles(self):
        from faraway_realms.entities.static_object import StaticObject
        from faraway_realms.net.serialization import _collect_static_reveals

        game = MagicMock()
        game.static_objects = [
            StaticObject(x=5, y=5, char=ord("T"), fg_color=(255, 200, 0)),
        ]
        assert _collect_static_reveals(game, set()) == []

    def test_per_client_payload_has_static_object_reveals_key(self):
        """Key must always be present so client never KeyErrors on it."""
        game = _make_game_stub()
        game.static_objects = []
        snaps = [_make_snap(1, 5, 5, is_player=True)]
        result = serialize_per_client(
            game, 1, snaps, frozenset([(5, 5)]), frozenset(), set()
        )
        assert "static_object_reveals" in result

    def test_per_client_payload_reveals_on_new_tiles(self):
        from faraway_realms.entities.static_object import StaticObject

        game = _make_game_stub()
        game.static_objects = [
            StaticObject(x=5, y=5, char=ord("T"), fg_color=(255, 200, 0)),
        ]
        snaps = [_make_snap(1, 5, 5, is_player=True)]
        result = serialize_per_client(
            game, 1, snaps, frozenset([(5, 5)]), frozenset(), {(5, 5)}
        )
        reveals = result["static_object_reveals"]
        assert len(reveals) == 1
        assert reveals[0]["x"] == 5
        assert reveals[0]["char"] == ord("T")

    def test_per_client_no_reveals_when_no_new_tiles(self):
        from faraway_realms.entities.static_object import StaticObject

        game = _make_game_stub()
        game.static_objects = [
            StaticObject(x=5, y=5, char=ord("T"), fg_color=(255, 200, 0)),
        ]
        snaps = [_make_snap(1, 5, 5, is_player=True)]
        result = serialize_per_client(
            game, 1, snaps, frozenset([(5, 5)]), frozenset(), set()
        )
        assert result["static_object_reveals"] == []


def _make_tick_snapshot(**kwargs):
    from faraway_realms.net.serialization import TickSnapshot

    return TickSnapshot(**kwargs)


def _make_client_game(snap):
    from faraway_realms.client_game import ClientGame
    from faraway_realms.world.map import make_blank_map

    client = MagicMock()
    client.latest_snapshot.return_value = snap
    client.player_overrides.return_value = {}
    return ClientGame(client, make_blank_map(20, 20))


class TestClientGameSync:
    """ClientGame correctly applies TickSnapshot deltas each frame."""

    def test_static_objects_appear_from_reveals(self):
        """Regression guard: static_object_reveals must populate static_objects."""
        snap = _make_tick_snapshot(
            static_object_reveals=[
                {"x": 3, "y": 4, "char": "T", "fg_color": [255, 200, 0]}
            ],
        )
        cg = _make_client_game(snap)
        _ = cg.game_map  # triggers _sync_entity_positions
        assert any(o.x == 3 and o.y == 4 for o in cg.static_objects)

    def test_static_objects_not_duplicated_on_repeat_reveals(self):
        """Same (x, y) delivered twice must not create a duplicate entry."""
        reveal = {"x": 3, "y": 4, "char": "T", "fg_color": [255, 200, 0]}
        snap = _make_tick_snapshot(static_object_reveals=[reveal])
        cg = _make_client_game(snap)
        _ = cg.game_map  # first sync; clears list
        snap.static_object_reveals = [reveal]  # simulate re-delivery
        _ = cg.game_map  # second sync
        count = sum(1 for o in cg.static_objects if o.x == 3 and o.y == 4)
        assert count == 1

    def test_static_object_reveals_cleared_after_sync(self):
        snap = _make_tick_snapshot(
            static_object_reveals=[
                {"x": 1, "y": 2, "char": "M", "fg_color": [0, 200, 100]}
            ],
        )
        cg = _make_client_game(snap)
        _ = cg.game_map
        assert snap.static_object_reveals == []

    def test_tile_reveals_update_map(self):
        snap = _make_tick_snapshot(
            tile_reveals=[
                {
                    "x": 2,
                    "y": 3,
                    "walkable": True,
                    "char": ord("."),
                    "fg": [200, 200, 200],
                    "bg": [50, 50, 50],
                }
            ],
        )
        cg = _make_client_game(snap)
        tile = cg.game_map.get_tile(2, 3)
        assert tile.walkable is True
        assert tile.char == ord(".")

    def test_tile_reveals_cleared_after_sync(self):
        snap = _make_tick_snapshot(
            tile_reveals=[
                {
                    "x": 2,
                    "y": 3,
                    "walkable": True,
                    "char": ord("."),
                    "fg": [200, 200, 200],
                    "bg": [50, 50, 50],
                }
            ],
        )
        cg = _make_client_game(snap)
        _ = cg.game_map
        assert snap.tile_reveals == []

    def test_removed_entity_ids_evict_cache(self):
        """Entities in removed_entity_ids must be purged from the entity cache."""
        snap = _make_tick_snapshot(entities=[_make_snap(42, 5, 5)])
        cg = _make_client_game(snap)
        cg.entity(42)  # populates cache
        assert 42 in cg._entities_cache
        snap.entities = []
        snap.removed_entity_ids = [42]
        _ = cg.game_map  # triggers sync → eviction
        assert 42 not in cg._entities_cache

    def test_removed_entity_ids_cleared_after_sync(self):
        snap = _make_tick_snapshot(removed_entity_ids=[99])
        cg = _make_client_game(snap)
        _ = cg.game_map
        assert snap.removed_entity_ids == []


class TestWelcomeCulling:
    """_build_welcome culls all content to explored tiles (anti-maphack)."""

    def _make_server_with_content(self):
        from faraway_realms.entities.static_object import StaticObject
        from faraway_realms.net.server import GameServer

        game = MagicMock()
        game.static_objects = [
            StaticObject(x=5, y=5, char=ord("T"), fg_color=(255, 200, 0)),
            StaticObject(x=20, y=20, char=ord("M"), fg_color=(0, 200, 100)),
        ]
        game.game_map.width = 30
        game.game_map.height = 30
        game.game_map.get_tile.return_value = MagicMock(
            walkable=True,
            char=ord("."),
            fg_color=(200, 200, 200),
            bg_color=(50, 50, 50),
        )
        return GameServer(game, host="127.0.0.1", port=0)

    def test_static_objects_culled_to_explored(self):
        from faraway_realms.net.server import _ClientSession

        server = self._make_server_with_content()
        session = _ClientSession(uuid="x", entity_id=1)
        welcome = server._build_welcome(session, explored={(5, 5)})
        positions = {(o["x"], o["y"]) for o in welcome["static_objects"]}
        assert (5, 5) in positions
        assert (20, 20) not in positions

    def test_map_tiles_culled_to_explored(self):
        from faraway_realms.net.server import _ClientSession

        server = self._make_server_with_content()
        session = _ClientSession(uuid="x", entity_id=1)
        welcome = server._build_welcome(session, explored={(5, 5), (6, 5)})
        coords = {(t["x"], t["y"]) for t in welcome["map_tiles"]}
        assert coords == {(5, 5), (6, 5)}

    def test_unexplored_tiles_absent_from_welcome(self):
        from faraway_realms.net.server import _ClientSession

        server = self._make_server_with_content()
        session = _ClientSession(uuid="x", entity_id=1)
        # Explore nothing at (0, 0) but not (20, 20)
        welcome = server._build_welcome(session, explored={(0, 0)})
        coords = {(t["x"], t["y"]) for t in welcome["map_tiles"]}
        assert (20, 20) not in coords
