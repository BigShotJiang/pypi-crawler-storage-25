"""Tests for GM spawn command and dynamic player spawning."""

from unittest.mock import MagicMock

from faraway_realms.combat.stats import Pool
from faraway_realms.entities.entity import CharacterEntity, NonPlayerEntity, Player
from faraway_realms.game import Game
from faraway_realms.net.server import GameServer
from faraway_realms.world.commands import Command, CommandParser, CommandType
from faraway_realms.world.factions import FactionRelations
from faraway_realms.world.map import make_bordered_map


def _zombie_factory(entity_id: int) -> NonPlayerEntity:
    return NonPlayerEntity(
        entity_id=entity_id,
        char=ord("Z"),
        fg_color=(100, 180, 100),
        name="Zombie",
        faction="hostile",
        stats={"health": Pool(base=10)},
    )


def _make_game(is_gm: bool = True) -> tuple[Game, Player]:
    game_map = make_bordered_map(20, 20)
    entity = CharacterEntity(
        entity_id=1,
        char=ord("@"),
        fg_color=(255, 255, 0),
        name="Hero",
        faction="player",
    )
    player = Player(username="tester", entity=entity, is_game_master=is_gm)
    relations = FactionRelations()
    relations.set_hostile("player", "hostile", True)
    game = Game(game_map=game_map, faction_relations=relations)
    game.register_creature("zombie", _zombie_factory)
    game.add_player(player)
    game_map.place_entity(entity.entity_id, 10, 10)
    return game, player


def _spawn_cmd(pos: str = "12,10") -> Command:
    return Command(
        command_type=CommandType.SPAWN,
        actor="@self",
        args=("zombie", pos),
        raw=f"/spawn @self zombie {pos}",
    )


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------


def test_parse_spawn_command() -> None:
    parser = CommandParser()
    cmd = parser.parse("/spawn zombie 5,7")
    assert cmd.command_type == CommandType.SPAWN
    assert cmd.actor == "@self"
    assert cmd.args == ("zombie", "5,7")


# ---------------------------------------------------------------------------
# Fixed-position spawn
# ---------------------------------------------------------------------------


def test_spawn_places_npc_on_map() -> None:
    game, _ = _make_game()
    game.enqueue_command(_spawn_cmd("12,10"))
    game.tick()
    positions = game.game_map.get_all_positions()
    assert (12, 10) in positions.values()


def test_spawn_registers_npc_in_entities() -> None:
    game, _ = _make_game()
    before = set(game._entities)  # noqa: SLF001
    game.enqueue_command(_spawn_cmd("12,10"))
    game.tick()
    assert len(game._entities) == len(before) + 1  # noqa: SLF001


def test_spawn_registers_npc_in_npcs() -> None:
    game, _ = _make_game()
    game.enqueue_command(_spawn_cmd("12,10"))
    game.tick()
    assert any(n.display_name == "Zombie" for n in game._npcs)  # noqa: SLF001


def test_spawn_assigns_unique_entity_id() -> None:
    game, _ = _make_game()
    game.enqueue_command(_spawn_cmd("12,10"))
    game.enqueue_command(_spawn_cmd("13,10"))
    game.tick()
    ids = [n.entity_id for n in game._npcs]  # noqa: SLF001
    assert len(ids) == len(set(ids))


def test_spawn_logs_chat_message() -> None:
    game, _ = _make_game()
    game.enqueue_command(_spawn_cmd("12,10"))
    game.tick()
    assert any("[GM]" in m.text for m in game.get_chat_history())


# ---------------------------------------------------------------------------
# GM gate
# ---------------------------------------------------------------------------


def test_spawn_rejected_for_non_gm() -> None:
    game, _ = _make_game(is_gm=False)
    game.enqueue_command(_spawn_cmd("12,10"))
    game.tick()
    assert all(n.display_name != "Zombie" for n in game._npcs)  # noqa: SLF001


def test_spawn_rejected_for_unknown_creature_type() -> None:
    game, _ = _make_game()
    cmd = Command(
        command_type=CommandType.SPAWN,
        actor="@self",
        args=("dragon", "12,10"),
        raw="/spawn @self dragon 12,10",
    )
    game.enqueue_command(cmd)
    game.tick()  # should not raise; nothing spawned
    assert game._npcs == []  # noqa: SLF001


def test_spawn_rejected_for_bad_position() -> None:
    game, _ = _make_game()
    cmd = Command(
        command_type=CommandType.SPAWN,
        actor="@self",
        args=("zombie", "notaposition"),
        raw="/spawn @self zombie notaposition",
    )
    game.enqueue_command(cmd)
    game.tick()  # should not raise
    assert game._npcs == []  # noqa: SLF001


# ---------------------------------------------------------------------------
# Random-position spawn
# ---------------------------------------------------------------------------


def test_spawn_random_places_npc_somewhere() -> None:
    game, _ = _make_game()
    game.enqueue_command(_spawn_cmd("random"))
    game.tick()
    assert any(n.display_name == "Zombie" for n in game._npcs)  # noqa: SLF001


def test_spawn_random_places_npc_on_walkable_tile() -> None:
    game, _ = _make_game()
    game.enqueue_command(_spawn_cmd("random"))
    game.tick()
    npc = next(n for n in game._npcs if n.display_name == "Zombie")  # noqa: SLF001
    x, y = game.game_map.get_entity_position(npc.entity_id)
    assert game.game_map.is_walkable(x, y)


def test_spawn_random_does_not_stack_on_existing_entity() -> None:
    game, _ = _make_game()
    game.enqueue_command(_spawn_cmd("random"))
    game.tick()
    positions = list(game.game_map.get_all_positions().values())
    assert len(positions) == len(set(positions))


# ---------------------------------------------------------------------------
# Game.spawn_player
# ---------------------------------------------------------------------------


def _make_game_with_spawn_tiles() -> Game:
    game_map = make_bordered_map(20, 20)
    entity = CharacterEntity(
        entity_id=1, char=ord("@"), fg_color=(255, 255, 0), name="Host"
    )
    player = Player(username="host", entity=entity)
    # Mark a 3x3 interior region as spawn tiles
    spawn_tiles = [(x, y) for x in range(5, 8) for y in range(5, 8)]
    game = Game(
        game_map=game_map,
        player_spawn_tiles=spawn_tiles,
    )
    game.add_player(player)
    game_map.place_entity(1, 10, 10)
    return game


def test_spawn_player_registers_new_player() -> None:
    game = _make_game_with_spawn_tiles()
    game.spawn_player("alice", "Alice", (100, 150, 255))
    assert game.player_entity_id("alice") is not None


def test_spawn_player_uses_given_name() -> None:
    game = _make_game_with_spawn_tiles()
    eid = game.spawn_player("alice", "Alice", (100, 150, 255))
    entity = game.entity(eid)
    assert entity is not None
    assert entity.display_name == "Alice"


def test_spawn_player_uses_given_color() -> None:
    game = _make_game_with_spawn_tiles()
    eid = game.spawn_player("alice", "Alice", (100, 150, 255))
    entity = game.entity(eid)
    assert entity is not None
    assert entity.fg_color == (100, 150, 255)


def test_spawn_player_places_on_spawn_tile() -> None:
    game = _make_game_with_spawn_tiles()
    eid = game.spawn_player("alice", "Alice", (100, 150, 255))
    pos = game.game_map.get_entity_position(eid)
    assert pos in game.player_spawn_tiles


def test_spawn_player_assigns_unique_entity_id() -> None:
    game = _make_game_with_spawn_tiles()
    id_a = game.spawn_player("alice", "Alice", (100, 150, 255))
    id_b = game.spawn_player("bob", "Bob", (255, 100, 100))
    assert id_a != id_b


def test_spawn_player_does_not_stack_on_occupied_tile() -> None:
    game = _make_game_with_spawn_tiles()
    # Fill all spawn tiles
    for i, (x, y) in enumerate(game.player_spawn_tiles, start=2):
        game.game_map.place_entity(i, x, y)
    eid = game.spawn_player("alice", "Alice", (100, 150, 255))
    pos = game.game_map.get_entity_position(eid)
    assert pos not in game.player_spawn_tiles
    assert game.game_map.is_walkable(*pos)


def test_spawn_player_falls_back_when_no_spawn_tiles() -> None:
    game_map = make_bordered_map(10, 10)
    entity = CharacterEntity(
        entity_id=1, char=ord("@"), fg_color=(255, 255, 0), name="Host"
    )
    game = Game(game_map=game_map)
    game.add_player(Player(username="host", entity=entity))
    game_map.place_entity(1, 5, 5)
    eid = game.spawn_player("alice", "Alice", (100, 150, 255))
    pos = game.game_map.get_entity_position(eid)
    assert game.game_map.is_walkable(*pos)


# ---------------------------------------------------------------------------
# GameServer._create_session — dynamic player spawning
# ---------------------------------------------------------------------------


def _make_server_with_game() -> tuple[GameServer, Game]:
    game_map = make_bordered_map(20, 20)
    entity = CharacterEntity(
        entity_id=1, char=ord("@"), fg_color=(255, 255, 0), name="Host"
    )
    player = Player(username="host", entity=entity)
    spawn_tiles = [(x, y) for x in range(5, 8) for y in range(5, 8)]
    game = Game(
        game_map=game_map,
        player_spawn_tiles=spawn_tiles,
        faction_relations=FactionRelations(),
    )
    game.add_player(player)
    game_map.place_entity(1, 10, 10)
    server = GameServer(game, "localhost", 0)
    server._sessions = {}
    return server, game


def _make_writer() -> MagicMock:
    w = MagicMock()
    w.is_closing.return_value = False
    return w


def test_create_session_spawns_unknown_username() -> None:
    server, game = _make_server_with_game()
    auth = {
        "uuid": "uuid-1",
        "username": "alice",
        "char_name": "Alice",
        "color": [100, 150, 255],
    }
    session = server._auth_session(auth, _make_writer())
    assert session is not None
    assert game.player_entity_id("alice") is not None


def test_create_session_uses_char_name_from_auth() -> None:
    server, game = _make_server_with_game()
    auth = {
        "uuid": "uuid-1",
        "username": "alice",
        "char_name": "Alice",
        "color": [100, 150, 255],
    }
    session = server._auth_session(auth, _make_writer())
    assert session is not None
    entity = game.entity(session.entity_id)
    assert entity is not None
    assert entity.display_name == "Alice"


def test_create_session_uses_color_from_auth() -> None:
    server, game = _make_server_with_game()
    auth = {
        "uuid": "uuid-1",
        "username": "alice",
        "char_name": "Alice",
        "color": [100, 150, 255],
    }
    session = server._auth_session(auth, _make_writer())
    assert session is not None
    entity = game.entity(session.entity_id)
    assert entity is not None
    assert entity.fg_color == (100, 150, 255)


def test_create_session_defaults_char_name_to_username() -> None:
    server, game = _make_server_with_game()
    auth = {"uuid": "uuid-1", "username": "bob", "color": [255, 100, 100]}
    session = server._auth_session(auth, _make_writer())
    assert session is not None
    entity = game.entity(session.entity_id)
    assert entity is not None
    assert entity.display_name == "bob"


def test_create_session_known_username_reuses_entity() -> None:
    server, game = _make_server_with_game()
    auth = {
        "uuid": "uuid-host",
        "username": "host",
        "char_name": "Host",
        "color": [255, 255, 0],
    }
    session = server._auth_session(auth, _make_writer())
    assert session is not None
    assert session.entity_id == 1


def test_handle_command_msg_routes_actor_to_session_entity() -> None:
    """me in actor position must resolve to the session's entity."""
    server, game = _make_server_with_game()
    auth = {
        "uuid": "uuid-alice",
        "username": "alice",
        "char_name": "Alice",
        "color": [100, 150, 255],
    }
    session = server._auth_session(auth, _make_writer())
    assert session is not None
    alice_id = session.entity_id

    from faraway_realms.world.commands import CommandParser, CommandResolver

    parser = CommandParser()
    resolver = CommandResolver(alice_id)
    server._handle_command_msg({"raw": "/move left"}, parser, resolver)
    cmd = game._command_queue[0]  # noqa: SLF001
    assert cmd.actor == str(alice_id)


def test_handle_command_msg_routes_self_in_args_to_session_entity() -> None:
    """@self in args (e.g. self-targeted cast) must resolve to the session's entity."""
    server, game = _make_server_with_game()
    auth = {
        "uuid": "uuid-alice",
        "username": "alice",
        "char_name": "Alice",
        "color": [100, 150, 255],
    }
    session = server._auth_session(auth, _make_writer())
    assert session is not None
    alice_id = session.entity_id

    from faraway_realms.world.commands import CommandParser, CommandResolver

    parser = CommandParser()
    resolver = CommandResolver(alice_id)
    server._handle_command_msg({"raw": "/cast second_wind @self"}, parser, resolver)
    cmd = game._command_queue[0]  # noqa: SLF001
    assert cmd.actor == str(alice_id)
    assert cmd.args[1] == str(alice_id)


def test_create_session_two_players_get_different_entities() -> None:
    server, _ = _make_server_with_game()
    auth_a = {
        "uuid": "uuid-a",
        "username": "alice",
        "char_name": "Alice",
        "color": [100, 150, 255],
    }
    auth_b = {
        "uuid": "uuid-b",
        "username": "bob",
        "char_name": "Bob",
        "color": [255, 100, 100],
    }
    session_a = server._auth_session(auth_a, _make_writer())
    session_b = server._auth_session(auth_b, _make_writer())
    assert session_a is not None
    assert session_b is not None
    assert session_a.entity_id != session_b.entity_id


# ---------------------------------------------------------------------------
# _parse_color / _room_spawn_tiles helpers
# ---------------------------------------------------------------------------


def test_parse_color_parses_rgb_string() -> None:
    from faraway_realms.__main__ import _parse_color

    assert _parse_color("100,150,255") == (100, 150, 255)


def test_parse_color_zero_values() -> None:
    from faraway_realms.__main__ import _parse_color

    assert _parse_color("0,0,0") == (0, 0, 0)


def test_room_spawn_tiles_returns_walkable_interior() -> None:
    from faraway_realms.__main__ import _room_spawn_tiles
    from faraway_realms.mapgen import MapGenResult, Rect

    game_map = make_bordered_map(20, 20)
    room = Rect(x=3, y=3, width=5, height=5)
    result = MapGenResult(map=game_map, rooms=[room], player_start=room.center)
    tiles = _room_spawn_tiles(game_map, result)
    assert len(tiles) > 0
    for x, y in tiles:
        assert game_map.is_walkable(x, y)
        assert room.x <= x < room.x2
        assert room.y <= y < room.y2
