"""Tests for TileScatterPass, ScatterRule, and ScatterReplacement."""

import random

from faraway_realms.mapgen import CaveGenerator, NoiseTexturePass
from faraway_realms.mapgen.scatter_pass import (
    ScatterReplacement,
    ScatterRule,
    TileScatterPass,
    _zone_matches,
)
from faraway_realms.world.tile import TILE_REGISTRY, Tile


def _floor() -> Tile:
    return TILE_REGISTRY["cave_floor"].make()


def _wall() -> Tile:
    return TILE_REGISTRY["cave_wall"].make()


def _gen(seed: int = 42):
    rng = random.Random(seed)
    result = CaveGenerator().generate(60, 40, rng)
    return result, rng


def _first_wall(result) -> tuple[int, int]:
    for y in range(result.map.height):
        for x in range(result.map.width):
            if not result.map.is_walkable(x, y):
                return x, y
    raise AssertionError("no wall tile found")


def _bone_rule(zone=None, exclude_zones=(), probability=1.0, inherit_bg=False):
    return ScatterRule(
        target="floor",
        replacements=(
            ScatterReplacement(
                tile="cave_bone_floor", probability=probability, inherit_bg=inherit_bg
            ),
        ),
        zone=zone,
        exclude_zones=exclude_zones,
    )


# ---------------------------------------------------------------------------
# _zone_matches
# ---------------------------------------------------------------------------


def test_zone_matches_none_zone_matches_any():
    rule = ScatterRule(target="floor", replacements=(), zone=None)
    assert _zone_matches(rule, "base") is True
    assert _zone_matches(rule, "moss") is True
    assert _zone_matches(rule, "gray_rock") is True


def test_zone_matches_specific_zone_matches_only_that():
    rule = ScatterRule(target="floor", replacements=(), zone="moss")
    assert _zone_matches(rule, "moss") is True
    assert _zone_matches(rule, "base") is False
    assert _zone_matches(rule, "gray_rock") is False


def test_zone_matches_exclude_zones_takes_precedence():
    rule = ScatterRule(
        target="floor", replacements=(), zone=None, exclude_zones=("gray_rock",)
    )
    assert _zone_matches(rule, "base") is True
    assert _zone_matches(rule, "moss") is True
    assert _zone_matches(rule, "gray_rock") is False


def test_zone_matches_exclude_overrides_matching_zone():
    rule = ScatterRule(
        target="floor", replacements=(), zone="moss", exclude_zones=("moss",)
    )
    assert _zone_matches(rule, "moss") is False


# ---------------------------------------------------------------------------
# ScatterReplacement defaults
# ---------------------------------------------------------------------------


def test_scatter_replacement_inherit_bg_defaults_false():
    rep = ScatterReplacement(tile="cave_bone_floor", probability=0.5)
    assert rep.inherit_bg is False


# ---------------------------------------------------------------------------
# TileScatterPass — floor / wall targeting
# ---------------------------------------------------------------------------


def test_scatter_replaces_floor_tiles():
    result, rng = _gen()
    px, py = result.player_start
    rule = _bone_rule(probability=1.0)
    TileScatterPass(rules=(rule,)).apply(result, rng)
    tile = result.map.get_tile(px, py)
    expected = TILE_REGISTRY["cave_bone_floor"]
    assert tile.char == expected.char


def test_scatter_does_not_replace_wall_tiles_with_floor_rule():
    result, rng = _gen()
    wx, wy = _first_wall(result)
    original_char = result.map.get_tile(wx, wy).char
    TileScatterPass(rules=(_bone_rule(probability=1.0),)).apply(result, rng)
    assert result.map.get_tile(wx, wy).char == original_char


def test_scatter_wall_rule_replaces_wall_tiles():
    result, rng = _gen()
    wx, wy = _first_wall(result)
    wall_rule = ScatterRule(
        target="wall",
        replacements=(ScatterReplacement(tile="cave_gray_rock_wall", probability=1.0),),
    )
    TileScatterPass(rules=(wall_rule,)).apply(result, rng)
    expected_char = TILE_REGISTRY["cave_gray_rock_wall"].char
    assert result.map.get_tile(wx, wy).char == expected_char


# ---------------------------------------------------------------------------
# TileScatterPass — probability
# ---------------------------------------------------------------------------


def test_scatter_probability_zero_never_replaces():
    result, rng = _gen()
    px, py = result.player_start
    original_char = result.map.get_tile(px, py).char
    TileScatterPass(rules=(_bone_rule(probability=0.0),)).apply(result, rng)
    assert result.map.get_tile(px, py).char == original_char


def test_scatter_probability_one_always_replaces():
    result, rng = _gen()
    px, py = result.player_start
    TileScatterPass(rules=(_bone_rule(probability=1.0),)).apply(result, rng)
    expected_char = TILE_REGISTRY["cave_bone_floor"].char
    assert result.map.get_tile(px, py).char == expected_char


# ---------------------------------------------------------------------------
# TileScatterPass — first-rule-wins
# ---------------------------------------------------------------------------


def test_scatter_first_matching_rule_wins():
    result, rng = _gen()
    px, py = result.player_start
    rule_a = ScatterRule(
        target="floor",
        replacements=(ScatterReplacement(tile="cave_bone_floor", probability=1.0),),
    )
    rule_b = ScatterRule(
        target="floor",
        replacements=(ScatterReplacement(tile="cave_grass_floor", probability=1.0),),
    )
    TileScatterPass(rules=(rule_a, rule_b)).apply(result, rng)
    tile = result.map.get_tile(px, py)
    bone_char = TILE_REGISTRY["cave_bone_floor"].char
    assert tile.char == bone_char


# ---------------------------------------------------------------------------
# TileScatterPass — zone filtering
# ---------------------------------------------------------------------------


def test_scatter_zone_filter_only_affects_matching_zone():
    """Rule with zone='moss' should only fire on tiles in the moss zone."""
    result, rng = _gen()
    # Apply texture pass so some tiles get zone assignments
    NoiseTexturePass(seed=1).apply(result, rng)
    moss_positions = {pos for pos, z in result.tile_zones.items() if z == "moss"}
    if not moss_positions:
        # No moss zones with this seed/map — skip test
        return

    rule = _bone_rule(zone="moss", probability=1.0)
    TileScatterPass(rules=(rule,)).apply(result, rng)

    bone_char = TILE_REGISTRY["cave_bone_floor"].char
    for pos, zone in result.tile_zones.items():
        x, y = pos
        tile = result.map.get_tile(x, y)
        if zone != "moss" and tile.walkable:
            assert tile.char != bone_char, (
                f"non-moss tile at {pos} (zone={zone!r}) got moss-scatter replacement"
            )


def test_scatter_exclude_zone_skips_excluded():
    """Rule with exclude_zones=('gray_rock',) should not fire in gray_rock zone."""
    result, rng = _gen()
    NoiseTexturePass(seed=1).apply(result, rng)
    rock_positions = [
        (x, y)
        for (x, y), z in result.tile_zones.items()
        if z == "gray_rock" and result.map.is_walkable(x, y)
    ]
    if not rock_positions:
        return

    rule = _bone_rule(exclude_zones=("gray_rock",), probability=1.0)
    TileScatterPass(rules=(rule,)).apply(result, rng)

    bone_char = TILE_REGISTRY["cave_bone_floor"].char
    for x, y in rock_positions:
        tile = result.map.get_tile(x, y)
        assert tile.char != bone_char, (
            f"gray_rock tile at ({x},{y}) should have been excluded from scatter"
        )


def test_scatter_no_zone_filter_replaces_all_floor_zones():
    """Rule with zone=None should affect tiles regardless of their zone."""
    result, rng = _gen()
    NoiseTexturePass(seed=1).apply(result, rng)

    rule = _bone_rule(probability=1.0)
    TileScatterPass(rules=(rule,)).apply(result, rng)

    bone_char = TILE_REGISTRY["cave_bone_floor"].char
    px, py = result.player_start
    assert result.map.get_tile(px, py).char == bone_char


# ---------------------------------------------------------------------------
# TileScatterPass — inherit_bg
# ---------------------------------------------------------------------------


def test_scatter_inherit_bg_uses_original_bg():
    result, rng = _gen()
    px, py = result.player_start
    original_bg = result.map.get_tile(px, py).bg_color
    rule = _bone_rule(probability=1.0, inherit_bg=True)
    TileScatterPass(rules=(rule,)).apply(result, rng)
    tile = result.map.get_tile(px, py)
    assert tile.bg_color == original_bg


def test_scatter_no_inherit_bg_uses_tile_registry_bg():
    result, rng = _gen()
    px, py = result.player_start
    expected_bg = TILE_REGISTRY["cave_bone_floor"].bg_color
    rule = _bone_rule(probability=1.0, inherit_bg=False)
    TileScatterPass(rules=(rule,)).apply(result, rng)
    tile = result.map.get_tile(px, py)
    assert tile.bg_color == expected_bg


def test_scatter_inherit_bg_preserves_fg_and_char():
    result, rng = _gen()
    px, py = result.player_start
    rule = _bone_rule(probability=1.0, inherit_bg=True)
    TileScatterPass(rules=(rule,)).apply(result, rng)
    tile = result.map.get_tile(px, py)
    expected = TILE_REGISTRY["cave_bone_floor"]
    assert tile.fg_color == expected.fg_color
    assert tile.char == expected.char


# ---------------------------------------------------------------------------
# TileScatterPass — determinism
# ---------------------------------------------------------------------------


def test_scatter_deterministic_same_seed():
    result1, rng1 = _gen(seed=42)
    result2, rng2 = _gen(seed=42)
    NoiseTexturePass(seed=7).apply(result1, rng1)
    NoiseTexturePass(seed=7).apply(result2, rng2)
    rule = _bone_rule(probability=0.05)
    TileScatterPass(rules=(rule,)).apply(result1, rng1)
    TileScatterPass(rules=(rule,)).apply(result2, rng2)
    for y in range(result1.map.height):
        for x in range(result1.map.width):
            c1 = result1.map.get_tile(x, y).char
            c2 = result2.map.get_tile(x, y).char
            assert c1 == c2


def test_scatter_different_seeds_differ():
    result1, rng1 = _gen(seed=1)
    result2, rng2 = _gen(seed=2)
    rule = _bone_rule(probability=0.05)
    TileScatterPass(rules=(rule,)).apply(result1, rng1)
    TileScatterPass(rules=(rule,)).apply(result2, rng2)
    chars1 = [
        result1.map.get_tile(x, y).char
        for y in range(result1.map.height)
        for x in range(result1.map.width)
    ]
    chars2 = [
        result2.map.get_tile(x, y).char
        for y in range(result2.map.height)
        for x in range(result2.map.width)
    ]
    assert chars1 != chars2


# ---------------------------------------------------------------------------
# TileScatterPass — walkability preserved
# ---------------------------------------------------------------------------


def test_scatter_preserves_walkability():
    result, rng = _gen()
    walkable_before = {
        (x, y): result.map.is_walkable(x, y)
        for y in range(result.map.height)
        for x in range(result.map.width)
    }
    wall_rule = ScatterRule(
        target="wall",
        replacements=(ScatterReplacement(tile="cave_gray_rock_wall", probability=1.0),),
    )
    TileScatterPass(rules=(_bone_rule(probability=1.0), wall_rule)).apply(result, rng)
    for (x, y), was_walkable in walkable_before.items():
        assert result.map.is_walkable(x, y) == was_walkable
