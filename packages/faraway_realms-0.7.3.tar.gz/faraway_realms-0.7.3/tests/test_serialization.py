"""Tests for TickSnapshot serialization/deserialization."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from faraway_realms.net.serialization import (
    TickSnapshot,
    deserialize_snapshot,
    serialize_map,
    serialize_tile_reveal,
    serialize_tile_sparse,
)


def test_deserialize_empty_tick() -> None:
    data = {
        "type": "tick",
        "entities": [],
        "blood_tiles": {},
        "attack_anim_events": [],
        "blood_events": [],
        "projectiles": [],
        "light_sources": [],
        "static_objects": [],
        "chat_messages": [],
        "attack_cooldown_fraction": 0.5,
        "gcd_fraction": None,
        "cast_fraction": None,
        "ability_cooldowns": {},
    }
    snap = deserialize_snapshot(data)
    assert isinstance(snap, TickSnapshot)
    assert snap.attack_cooldown_fraction == pytest.approx(0.5)
    assert snap.gcd_fraction is None
    assert snap.entities == []


def test_deserialize_with_entity() -> None:
    data = {
        "type": "tick",
        "entities": [
            {
                "entity_id": 1,
                "x": 5,
                "y": 10,
                "type_id": "hero",
                "target_id": None,
                "stats": {},
                "status_effects": [],
            }
        ],
        "blood_tiles": {},
        "attack_anim_events": [],
        "blood_events": [],
        "projectiles": [],
        "light_sources": [],
        "static_objects": [],
        "chat_messages": [{"text": "hello", "color": [200, 200, 200]}],
        "attack_cooldown_fraction": 1.0,
        "gcd_fraction": None,
        "cast_fraction": None,
        "ability_cooldowns": {},
    }
    snap = deserialize_snapshot(data)
    assert len(snap.entities) == 1
    e = snap.entities[0]
    assert e.entity_id == 1
    assert e.x == 5
    assert e.type_id == "hero"
    assert snap.chat_messages[0]["text"] == "hello"


def test_deserialize_hit_seq_and_crit_dealt_seq() -> None:
    data = {
        "type": "tick",
        "entities": [],
        "blood_tiles": {},
        "attack_anim_events": [],
        "blood_events": [],
        "projectiles": [],
        "light_sources": [],
        "static_objects": [],
        "chat_messages": [],
        "attack_cooldown_fraction": 0.0,
        "hit_seq": 5,
        "crit_dealt_seq": 2,
    }
    snap = deserialize_snapshot(data)
    assert snap.hit_seq == 5
    assert snap.crit_dealt_seq == 2


def test_deserialize_hit_seq_defaults_to_zero() -> None:
    data = {"type": "tick", "entities": [], "attack_cooldown_fraction": 0.0}
    snap = deserialize_snapshot(data)
    assert snap.hit_seq == 0
    assert snap.crit_dealt_seq == 0


def test_deserialize_target_fractions() -> None:
    data = {
        "type": "tick",
        "entities": [],
        "attack_cooldown_fraction": 0.0,
        "target_entity_id": 7,
        "target_attack_fraction": 0.5,
        "target_cast_fraction": 0.3,
        "target_gcd_fraction": None,
    }
    snap = deserialize_snapshot(data)
    assert snap.target_entity_id == 7
    assert snap.target_attack_fraction == pytest.approx(0.5)
    assert snap.target_cast_fraction == pytest.approx(0.3)
    assert snap.target_gcd_fraction is None


def test_deserialize_entity_last_hit_fields() -> None:
    data = {
        "type": "tick",
        "entities": [
            {
                "entity_id": 2,
                "x": 3,
                "y": 4,
                "type_id": "zombie",
                "target_id": None,
                "stats": {},
                "status_effects": [],
                "last_hit_tick": 42,
                "last_hit_by": 7,
            }
        ],
        "attack_cooldown_fraction": 0.0,
    }
    snap = deserialize_snapshot(data)
    assert snap.entities[0].last_hit_tick == 42
    assert snap.entities[0].last_hit_by == 7


def test_serialize_tile_sparse_basic_fields() -> None:
    from faraway_realms.world.map import make_bordered_map

    game_map = make_bordered_map(5, 4)
    cells = serialize_tile_sparse(game_map, {(1, 1)})
    assert len(cells) == 1
    cell = cells[0]
    assert cell["x"] == 1 and cell["y"] == 1
    assert "walkable" in cell and "char" in cell
    assert "fg" in cell and "bg" in cell


def test_serialize_tile_sparse_includes_tile_type_id_when_set() -> None:
    from faraway_realms.world.map import make_bordered_map

    game_map = make_bordered_map(5, 4)
    game_map.tile_type_ids[(1, 1)] = "dungeon_door_closed"
    cells = serialize_tile_sparse(game_map, {(1, 1)})
    assert cells[0]["tile_type_id"] == "dungeon_door_closed"


def test_serialize_tile_sparse_tile_type_id_none_when_absent() -> None:
    from faraway_realms.world.map import make_bordered_map

    game_map = make_bordered_map(5, 4)
    cells = serialize_tile_sparse(game_map, {(1, 1)})
    assert cells[0]["tile_type_id"] is None


def test_serialize_tile_reveal_includes_type_and_zone() -> None:
    from faraway_realms.world.map import make_bordered_map

    game_map = make_bordered_map(5, 4)
    game_map.tile_type_ids[(2, 2)] = "cave_floor"
    game_map.tile_zones[(2, 2)] = "moss"
    cells = serialize_tile_reveal(game_map, {(2, 2)})
    assert len(cells) == 1
    assert cells[0]["tile_type_id"] == "cave_floor"
    assert cells[0]["zone_name"] == "moss"


def test_serialize_tile_sparse_multiple_tiles() -> None:
    from faraway_realms.world.map import make_bordered_map

    game_map = make_bordered_map(10, 10)
    game_map.tile_type_ids[(1, 1)] = "dungeon_door_open"
    cells = serialize_tile_sparse(game_map, {(1, 1), (2, 2)})
    by_pos = {(c["x"], c["y"]): c for c in cells}
    assert by_pos[(1, 1)]["tile_type_id"] == "dungeon_door_open"
    assert by_pos[(2, 2)]["tile_type_id"] is None


def test_serialize_map_produces_row_col_grid() -> None:
    from faraway_realms.world.map import make_bordered_map

    game_map = make_bordered_map(5, 4)
    mock_game = MagicMock()
    mock_game.game_map = game_map
    rows = serialize_map(mock_game)
    assert len(rows) == 4
    assert len(rows[0]) == 5
    cell = rows[0][0]
    assert "walkable" in cell
    assert "char" in cell
    assert "fg" in cell
    assert "bg" in cell
