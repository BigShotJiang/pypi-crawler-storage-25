"""Tests for the FOV helper and TargetingSystem cycle/maintain_los."""

import faraway_realms.ai.fov as fov_module
from faraway_realms.ai.fov import DEFAULT_SIGHT_RANGE
from faraway_realms.combat.stats import Stat
from faraway_realms.entities.entity import CharacterEntity, NonPlayerEntity, Player
from faraway_realms.systems.targeting import TargetingSystem
from faraway_realms.world.commands import Command, CommandType
from faraway_realms.world.event_bus import EventBus
from faraway_realms.world.events import Event, EventType
from faraway_realms.world.factions import FactionRelations
from faraway_realms.world.map import make_bordered_map

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _player(entity_id: int, x: int = 5, y: int = 5) -> CharacterEntity:
    return CharacterEntity(
        entity_id=entity_id,
        char=ord("@"),
        fg_color=(255, 255, 0),
        name="Hero",
        faction="player",
    )


def _npc(entity_id: int, faction: str = "hostile") -> NonPlayerEntity:
    return NonPlayerEntity(
        entity_id=entity_id,
        char=ord("Z"),
        fg_color=(0, 200, 0),
        name="Zombie",
        faction=faction,
    )


def _setup(map_size: int = 20):
    game_map = make_bordered_map(map_size, map_size)
    relations = FactionRelations()
    relations.set_hostile("player", "hostile", True)
    entities: dict = {}
    return game_map, relations, entities


def _system(game_map, entities, relations):
    return TargetingSystem(entities, game_map, relations)


# ---------------------------------------------------------------------------
# FOV helper
# ---------------------------------------------------------------------------


def test_fov_origin_is_visible():
    game_map = make_bordered_map(10, 10)
    visible = fov_module.compute_fov(game_map, 5, 5, DEFAULT_SIGHT_RANGE)
    assert visible[5, 5]


def test_fov_far_interior_tile_visible():
    game_map = make_bordered_map(20, 20)
    visible = fov_module.compute_fov(game_map, 5, 5, DEFAULT_SIGHT_RANGE)
    assert visible[10, 10]


def test_fov_tile_beyond_radius_not_visible():
    game_map = make_bordered_map(40, 40)
    visible = fov_module.compute_fov(game_map, 5, 5, radius=3)
    assert not visible[5, 15]  # 10 tiles away, well beyond radius 3


# ---------------------------------------------------------------------------
# cycle — basic selection
# ---------------------------------------------------------------------------


def test_cycle_selects_nearest_visible_hostile():
    game_map, relations, entities = _setup()
    player = _player(1)
    near = _npc(2)
    far = _npc(3)
    entities[1] = player
    entities[2] = near
    entities[3] = far
    game_map.place_entity(1, 5, 5)
    game_map.place_entity(2, 6, 5)  # distance 1
    game_map.place_entity(3, 10, 5)  # distance 5

    sys = _system(game_map, entities, relations)
    sys.cycle(1)

    assert player.target_id == 2


def test_cycle_advances_past_current_target():
    game_map, relations, entities = _setup()
    player = _player(1)
    near = _npc(2)
    far = _npc(3)
    entities[1] = player
    entities[2] = near
    entities[3] = far
    game_map.place_entity(1, 5, 5)
    game_map.place_entity(2, 6, 5)
    game_map.place_entity(3, 10, 5)
    player.target_id = 2

    sys = _system(game_map, entities, relations)
    sys.cycle(1)

    assert player.target_id == 3


def test_cycle_wraps_around():
    game_map, relations, entities = _setup()
    player = _player(1)
    near = _npc(2)
    far = _npc(3)
    entities[1] = player
    entities[2] = near
    entities[3] = far
    game_map.place_entity(1, 5, 5)
    game_map.place_entity(2, 6, 5)
    game_map.place_entity(3, 10, 5)
    player.target_id = 3  # already at last

    sys = _system(game_map, entities, relations)
    sys.cycle(1)

    assert player.target_id == 2  # wraps back to nearest


# ---------------------------------------------------------------------------
# cycle — visibility filtering
# ---------------------------------------------------------------------------


def test_cycle_skips_enemy_beyond_sight_range():
    game_map, relations, entities = _setup(map_size=40)
    player = _player(1)
    player.stats["sight"] = Stat(base=3)
    far = _npc(2)
    entities[1] = player
    entities[2] = far
    game_map.place_entity(1, 5, 5)
    game_map.place_entity(2, 15, 5)  # beyond sight range of 3

    sys = _system(game_map, entities, relations)
    sys.cycle(1)

    assert player.target_id is None


def test_cycle_clears_target_when_no_hostiles_visible():
    game_map, relations, entities = _setup()
    player = _player(1)
    entities[1] = player
    game_map.place_entity(1, 5, 5)

    sys = _system(game_map, entities, relations)
    sys.cycle(1)

    assert player.target_id is None


def test_cycle_ignores_friendly_entities():
    game_map, relations, entities = _setup()
    player = _player(1)
    ally = _npc(2, faction="player")
    entities[1] = player
    entities[2] = ally
    game_map.place_entity(1, 5, 5)
    game_map.place_entity(2, 6, 5)

    sys = _system(game_map, entities, relations)
    sys.cycle(1)

    assert player.target_id is None


# ---------------------------------------------------------------------------
# maintain_los
# ---------------------------------------------------------------------------


def test_maintain_los_keeps_target_when_visible():
    game_map, relations, entities = _setup()
    player = _player(1)
    enemy = _npc(2)
    entities[1] = player
    entities[2] = enemy
    game_map.place_entity(1, 5, 5)
    game_map.place_entity(2, 6, 5)
    player.target_id = 2

    sys = _system(game_map, entities, relations)
    sys.maintain_los(1)

    assert player.target_id == 2


def test_maintain_los_clears_target_when_out_of_range():
    game_map, relations, entities = _setup(map_size=40)
    player = _player(1)
    player.stats["sight"] = Stat(base=3)
    enemy = _npc(2)
    entities[1] = player
    entities[2] = enemy
    game_map.place_entity(1, 5, 5)
    game_map.place_entity(2, 15, 5)  # beyond sight range
    player.target_id = 2

    sys = _system(game_map, entities, relations)
    sys.maintain_los(1)

    assert player.target_id is None


def test_maintain_los_clears_target_when_dead():
    game_map, relations, entities = _setup()
    player = _player(1)
    enemy = _npc(2)
    entities[1] = player
    entities[2] = enemy
    game_map.place_entity(1, 5, 5)
    game_map.place_entity(2, 6, 5)
    player.target_id = 2

    # simulate death
    del entities[2]
    game_map.remove_entity(2)

    sys = _system(game_map, entities, relations)
    sys.maintain_los(1)

    assert player.target_id is None


def test_maintain_los_noop_when_no_target():
    game_map, relations, entities = _setup()
    player = _player(1)
    entities[1] = player
    game_map.place_entity(1, 5, 5)
    player.target_id = None

    sys = _system(game_map, entities, relations)
    sys.maintain_los(1)  # should not raise

    assert player.target_id is None


# ---------------------------------------------------------------------------
# Guard: unknown entity IDs
# ---------------------------------------------------------------------------


def test_handle_unknown_entity_is_noop():
    game_map, relations, entities = _setup()
    sys = _system(game_map, entities, relations)
    sys.handle(99, 1)  # entity 99 not in registry — should not raise


def test_cycle_unknown_entity_is_noop():
    game_map, relations, entities = _setup()
    sys = _system(game_map, entities, relations)
    sys.cycle(99)  # entity 99 not in registry — should not raise


def test_cycle_clears_target_when_actor_not_on_map():
    game_map, relations, entities = _setup()
    player = _player(1)
    entities[1] = player
    player.target_id = 2  # had a target before
    # player NOT placed on map → _player_fov returns None → target cleared
    sys = _system(game_map, entities, relations)
    sys.cycle(1)
    assert player.target_id is None


def test_maintain_los_unknown_entity_is_noop():
    game_map, relations, entities = _setup()
    sys = _system(game_map, entities, relations)
    sys.maintain_los(99)  # should not raise


def test_maintain_los_clears_when_actor_not_on_map():
    game_map, relations, entities = _setup()
    player = _player(1)
    enemy = _npc(2)
    entities[1] = player
    entities[2] = enemy
    game_map.place_entity(2, 6, 5)
    player.target_id = 2
    # player NOT on map → _player_fov returns None → target cleared
    sys = _system(game_map, entities, relations)
    sys.maintain_los(1)
    assert player.target_id is None


# ---------------------------------------------------------------------------
# ENTITY_DIED — auto-target via bus subscription
# ---------------------------------------------------------------------------


def _setup_with_bus():
    game_map = make_bordered_map(20, 20)
    relations = FactionRelations()
    relations.set_hostile("player", "hostile", True)
    entities: dict = {}
    command_queue: list[Command] = []
    players: dict = {}
    bus = EventBus()
    return game_map, relations, entities, players, command_queue, bus


def _make_player(entity_id: int, x: int = 5, y: int = 5) -> Player:
    entity = CharacterEntity(
        entity_id=entity_id,
        char=ord("@"),
        fg_color=(255, 255, 0),
        name="Hero",
        faction="player",
    )
    return Player(username=f"player{entity_id}", entity=entity)


def _make_npc(entity_id: int) -> NonPlayerEntity:
    return NonPlayerEntity(
        entity_id=entity_id,
        char=ord("Z"),
        fg_color=(0, 200, 0),
        name="Zombie",
        faction="hostile",
    )


def test_auto_target_queued_on_entity_died_when_player_has_no_target() -> None:
    game_map, relations, entities, players, command_queue, bus = _setup_with_bus()
    player = _make_player(1)
    attacker = _make_npc(3)
    attacker.target_id = 1  # NPC is attacking the player
    entities[1] = player.entity
    entities[3] = attacker
    players["player1"] = player
    game_map.place_entity(1, 5, 5)
    game_map.place_entity(3, 6, 5)

    TargetingSystem(entities, game_map, relations, players, command_queue, bus)

    bus.publish(Event(event_type=EventType.ENTITY_DIED, source_id=2, resolve_at_tick=0))
    bus.flush(0)

    assert any(
        c.command_type == CommandType.TARGET and c.actor == "1" for c in command_queue
    )


def test_auto_target_not_queued_when_player_already_has_target() -> None:
    game_map, relations, entities, players, command_queue, bus = _setup_with_bus()
    player = _make_player(1)
    attacker = _make_npc(3)
    attacker.target_id = 1
    player.entity.target_id = 3  # player already targeting the attacker
    entities[1] = player.entity
    entities[3] = attacker
    players["player1"] = player
    game_map.place_entity(1, 5, 5)
    game_map.place_entity(3, 6, 5)

    TargetingSystem(entities, game_map, relations, players, command_queue, bus)

    bus.publish(Event(event_type=EventType.ENTITY_DIED, source_id=2, resolve_at_tick=0))
    bus.flush(0)

    assert not command_queue


def test_entity_died_not_subscribed_without_command_queue() -> None:
    game_map, relations, entities, players, _, bus = _setup_with_bus()

    TargetingSystem(entities, game_map, relations, players, command_queue=None, bus=bus)

    # Only TICK should be subscribed — ENTITY_DIED requires command_queue.
    assert not any(
        et == EventType.ENTITY_DIED
        for et in bus._subscribers  # noqa: SLF001
    )
