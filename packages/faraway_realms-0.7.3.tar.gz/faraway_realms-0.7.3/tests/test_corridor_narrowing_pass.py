"""Tests for CorridorNarrowingPass and 1-wide door placement."""

from __future__ import annotations

import random

from faraway_realms.mapgen.base import DoorCandidate, MapGenResult
from faraway_realms.mapgen.corridor_narrowing_pass import CorridorNarrowingPass
from faraway_realms.mapgen.door_population_pass import DoorPopulationPass
from faraway_realms.mapgen.map_profile import MapProfile
from faraway_realms.world.map import Map
from faraway_realms.world.tile import TILE_REGISTRY, Tile

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _floor() -> Tile:
    return Tile(walkable=True, bg_color=(0, 0, 0), fg_color=(255, 255, 255))


def _wall() -> Tile:
    return Tile(walkable=False, bg_color=(50, 50, 50), fg_color=(100, 100, 100))


def _map_with_corridor() -> tuple[Map, dict]:
    """5×5 map: column 2 rows 1-2 is a 2-wide vertical corridor, rest walls."""
    tiles = [[_wall() for _ in range(5)] for _ in range(5)]
    tiles[1][2] = _floor()
    tiles[2][2] = _floor()
    game_map = Map(5, 5, tiles)
    tile_type_ids = {
        (2, 1): "dungeon_floor",
        (2, 2): "dungeon_floor",
        (0, 0): "dungeon_wall",
        (1, 1): "dungeon_wall",
    }
    return game_map, tile_type_ids


def _result_with_candidate(horizontal: bool = False) -> MapGenResult:
    game_map, tile_type_ids = _map_with_corridor()
    result = MapGenResult(map=game_map, rooms=[], player_start=(2, 1))
    result.tile_type_ids.update(tile_type_ids)
    result.door_candidates.append(DoorCandidate(x=2, y=1, horizontal=horizontal))
    return result


def _profile(narrow: bool = True) -> MapProfile:
    return MapProfile(
        name="test",
        generate_doors=True,
        door_tile="dungeon_door_closed",
        door_density=1.0,
        narrow_doors=narrow,
    )


# ---------------------------------------------------------------------------
# CorridorNarrowingPass
# ---------------------------------------------------------------------------


def test_narrowing_skipped_when_disabled() -> None:
    result = _result_with_candidate()
    CorridorNarrowingPass(_profile(narrow=False)).apply(result, random.Random(0))
    assert result.map.is_walkable(2, 1)
    assert result.map.is_walkable(2, 2)


def test_narrowing_blocks_second_tile() -> None:
    result = _result_with_candidate()
    CorridorNarrowingPass(_profile()).apply(result, random.Random(0))
    assert result.map.is_walkable(2, 1)
    assert not result.map.is_walkable(2, 2)


def test_narrowing_updates_tile_type_ids() -> None:
    result = _result_with_candidate()
    CorridorNarrowingPass(_profile()).apply(result, random.Random(0))
    tid = result.tile_type_ids.get((2, 2))
    assert tid is not None
    assert TILE_REGISTRY[tid].walkable is False


def test_narrowing_infers_wall_from_neighbour() -> None:
    result = _result_with_candidate()
    # Seed a specific wall type at a neighbour so we can assert it's picked up
    result.tile_type_ids[(1, 1)] = "dungeon_wall"
    CorridorNarrowingPass(_profile()).apply(result, random.Random(0))
    assert result.tile_type_ids[(2, 2)] == "dungeon_wall"


def test_narrowing_skips_already_blocked_candidate() -> None:
    result = _result_with_candidate()
    # Pre-block t2
    result.map._tiles[2][2] = _wall()  # noqa: SLF001
    CorridorNarrowingPass(_profile()).apply(result, random.Random(0))
    # t1 still walkable, nothing changed
    assert result.map.is_walkable(2, 1)


# ---------------------------------------------------------------------------
# DoorPopulationPass — 1-wide branch
# ---------------------------------------------------------------------------


def test_door_placed_on_single_walkable_tile() -> None:
    result = _result_with_candidate()
    # Narrow the corridor first
    CorridorNarrowingPass(_profile()).apply(result, random.Random(0))
    DoorPopulationPass(_profile()).apply(result, random.Random(0))
    door_tile = result.map.get_tile(2, 1)
    assert not door_tile.walkable
    assert result.tile_type_ids[(2, 1)] == "dungeon_door_closed"
    # The blocked tile stays a wall, not a door
    assert result.tile_type_ids[(2, 2)] != "dungeon_door_closed"


def test_door_not_placed_when_both_tiles_blocked() -> None:
    result = _result_with_candidate()
    result.map._tiles[1][2] = _wall()  # noqa: SLF001
    result.map._tiles[2][2] = _wall()  # noqa: SLF001
    DoorPopulationPass(_profile()).apply(result, random.Random(0))
    assert result.tile_type_ids.get((2, 1)) != "dungeon_door_closed"


def test_two_wide_door_still_placed_without_narrowing() -> None:
    result = _result_with_candidate()
    # No narrowing — corridor is still 2-wide; need a wall at t3 position
    result.map._tiles[3][2] = _wall()  # noqa: SLF001
    result.tile_type_ids[(2, 3)] = "dungeon_wall"
    DoorPopulationPass(_profile(narrow=False)).apply(result, random.Random(0))
    assert result.tile_type_ids.get((2, 1)) == "dungeon_door_closed"
    assert result.tile_type_ids.get((2, 2)) == "dungeon_door_closed"
