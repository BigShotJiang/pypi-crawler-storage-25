import pytest

from faraway_realms.world.tile import (
    TILE_REGISTRY,
    Tile,
    floor_tile,
    unknown_tile,
    wall_tile,
)


@pytest.fixture()
def empty_registry():
    saved = dict(TILE_REGISTRY)
    TILE_REGISTRY.clear()
    yield
    TILE_REGISTRY.clear()
    TILE_REGISTRY.update(saved)


def test_floor_tile_is_walkable():
    assert floor_tile().walkable is True


def test_wall_tile_is_not_walkable():
    assert wall_tile().walkable is False


def test_tile_default_char():
    tile = Tile(walkable=True, bg_color=(0, 0, 0), fg_color=(255, 255, 255))
    assert tile.char == ord(" ")


def test_tile_custom_char():
    tile = Tile(
        walkable=True, bg_color=(0, 0, 0), fg_color=(255, 255, 255), char=ord("@")
    )
    assert tile.char == ord("@")


def test_tile_color_fields():
    bg = (10, 20, 30)
    fg = (40, 50, 60)
    tile = Tile(walkable=False, bg_color=bg, fg_color=fg)
    assert tile.bg_color == bg
    assert tile.fg_color == fg


def test_cave_floor_tile_char_from_registry() -> None:
    from faraway_realms.world.tile import cave_floor_tile

    assert cave_floor_tile().char == ord(" ")


def test_cave_floor_tile_is_walkable() -> None:
    from faraway_realms.world.tile import cave_floor_tile

    t = cave_floor_tile()
    assert t.walkable is True


def test_cave_wall_tile_is_not_walkable() -> None:
    from faraway_realms.world.tile import cave_wall_tile

    t = cave_wall_tile()
    assert t.walkable is False


# ------------------------------------------------------------------
# floor_tile fallback (registry absent)
# ------------------------------------------------------------------


def test_floor_tile_fallback_walkable(empty_registry):
    assert floor_tile().walkable is True


def test_floor_tile_fallback_bg_color(empty_registry):
    assert floor_tile().bg_color == (50, 50, 50)


def test_floor_tile_fallback_fg_color(empty_registry):
    assert floor_tile().fg_color == (200, 200, 200)


def test_floor_tile_fallback_char(empty_registry):
    assert floor_tile().char == ord(".")


# ------------------------------------------------------------------
# wall_tile fallback (registry absent)
# ------------------------------------------------------------------


def test_wall_tile_fallback_walkable(empty_registry):
    assert wall_tile().walkable is False


def test_wall_tile_fallback_bg_color(empty_registry):
    assert wall_tile().bg_color == (100, 100, 100)


def test_wall_tile_fallback_fg_color(empty_registry):
    assert wall_tile().fg_color == (200, 200, 200)


def test_wall_tile_fallback_char(empty_registry):
    assert wall_tile().char == ord("#")


# ------------------------------------------------------------------
# cave_floor_tile fallback (registry absent)
# ------------------------------------------------------------------


def test_cave_floor_tile_fallback_walkable(empty_registry):
    from faraway_realms.world.tile import cave_floor_tile

    assert cave_floor_tile().walkable is True


def test_cave_floor_tile_fallback_bg_color(empty_registry):
    from faraway_realms.world.tile import cave_floor_tile

    assert cave_floor_tile().bg_color == (60, 45, 30)


def test_cave_floor_tile_fallback_fg_color(empty_registry):
    from faraway_realms.world.tile import cave_floor_tile

    assert cave_floor_tile().fg_color == (160, 130, 80)


def test_cave_floor_tile_fallback_char(empty_registry):
    from faraway_realms.world.tile import cave_floor_tile

    assert cave_floor_tile().char == ord(".")


# ------------------------------------------------------------------
# cave_wall_tile — registry path uses different char than fallback
# ------------------------------------------------------------------


def test_cave_wall_tile_registry_char():
    from faraway_realms.world.tile import cave_wall_tile

    assert cave_wall_tile().char == TILE_REGISTRY["cave_wall"].char


def test_cave_wall_tile_fallback_walkable(empty_registry):
    from faraway_realms.world.tile import cave_wall_tile

    assert cave_wall_tile().walkable is False


def test_cave_wall_tile_fallback_bg_color(empty_registry):
    from faraway_realms.world.tile import cave_wall_tile

    assert cave_wall_tile().bg_color == (35, 25, 15)


def test_cave_wall_tile_fallback_fg_color(empty_registry):
    from faraway_realms.world.tile import cave_wall_tile

    assert cave_wall_tile().fg_color == (80, 60, 40)


def test_cave_wall_tile_fallback_char(empty_registry):
    from faraway_realms.world.tile import cave_wall_tile

    assert cave_wall_tile().char == ord("#")


# ------------------------------------------------------------------
# unknown_tile
# ------------------------------------------------------------------


def test_unknown_tile_is_walkable():
    assert unknown_tile().walkable is True


def test_unknown_tile_bg_color():
    assert unknown_tile().bg_color == (0, 0, 0)


def test_unknown_tile_fg_color():
    assert unknown_tile().fg_color == (0, 0, 0)


def test_unknown_tile_char():
    assert unknown_tile().char == ord(" ")


# ------------------------------------------------------------------
def test_cave_tiles_have_brownish_bg() -> None:
    from faraway_realms.world.tile import cave_floor_tile, cave_wall_tile

    floor = cave_floor_tile()
    wall = cave_wall_tile()
    # Brown = more red than blue, meaningful green
    assert floor.bg_color[0] > floor.bg_color[2]  # red > blue
    assert wall.bg_color[0] > wall.bg_color[2]
