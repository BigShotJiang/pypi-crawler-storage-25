"""Integration tests: GameServer + raw TCP client over real localhost sockets.

These tests verify the full server pipeline: game tick → serialization →
msgpack framing → TCP → deserialization, plus the command path back from
client to server.  A minimal 10×10 map is used so tests run fast and FOV
always covers the entire interior.
"""

from __future__ import annotations

import asyncio

import pytest
import pytest_asyncio

from faraway_realms.game import Game
from faraway_realms.net.protocol import recv_message, send_message
from faraway_realms.net.server import GameServer
from faraway_realms.world.factions import FACTION_RELATIONS
from faraway_realms.world.map import make_bordered_map

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

# 10×10 map: 8×8 walkable interior; max diagonal ≈ 11 tiles — always within
# the server's sight range of 12 so all players are visible to each other.
_MAP_W = 10
_MAP_H = 10


def _make_test_game(tick_rate: float = 50.0) -> Game:
    """Minimal game suitable for integration tests."""
    game_map = make_bordered_map(_MAP_W, _MAP_H)
    # Restrict spawn to the inner area (2 tiles from each border) so the player
    # always has room to move in any cardinal direction — prevents flaky test
    # failures when the player spawns adjacent to the border wall.
    spawn_tiles = [
        (x, y)
        for y in range(2, _MAP_H - 2)
        for x in range(2, _MAP_W - 2)
        if game_map.is_walkable(x, y)
    ]
    return Game(
        game_map=game_map,
        faction_relations=FACTION_RELATIONS,
        player_spawn_tiles=spawn_tiles,
        tick_rate=tick_rate,
    )


async def _auth_payload(
    uuid: str = "test-uuid",
    username: str = "player",
) -> dict:
    return {
        "type": "auth",
        "uuid": uuid,
        "username": username,
        "char_name": "Tester",
        "color": [200, 200, 200],
    }


async def _connect(port: int) -> tuple[asyncio.StreamReader, asyncio.StreamWriter]:
    return await asyncio.open_connection("localhost", port)


async def _connect_and_auth(
    port: int,
    uuid: str = "test-uuid",
    username: str = "player",
) -> tuple[asyncio.StreamReader, asyncio.StreamWriter, dict]:
    """Open connection, send auth, receive welcome (or error) message."""
    reader, writer = await _connect(port)
    await send_message(writer, await _auth_payload(uuid, username))
    msg = await asyncio.wait_for(recv_message(reader), timeout=2.0)
    return reader, writer, msg


async def _recv_tick(reader: asyncio.StreamReader, timeout: float = 2.0) -> dict:
    """Read messages from *reader* until a ``'tick'`` message arrives."""
    while True:
        msg = await asyncio.wait_for(recv_message(reader), timeout=timeout)
        if msg.get("type") == "tick":
            return msg


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest_asyncio.fixture
async def server():
    """Spin up a real GameServer on localhost:0; yield it; cancel on teardown."""
    game = _make_test_game()
    srv = GameServer(game, "localhost", 0)
    srv_task = asyncio.create_task(srv.run())
    await asyncio.sleep(0.05)  # let asyncio.start_server bind the socket
    yield srv
    # Cancel the server task AND all tasks it spawned (tick loop, etc.)
    pending = [t for t in asyncio.all_tasks() if t is not asyncio.current_task()]
    for t in pending:
        t.cancel()
    await asyncio.gather(*pending, return_exceptions=True)
    del srv_task  # silence "task was destroyed but it is pending" warnings


# ---------------------------------------------------------------------------
# Welcome message — structure and content
# ---------------------------------------------------------------------------


async def test_welcome_type(server):
    _, writer, welcome = await _connect_and_auth(server.bound_port)
    assert welcome.get("type") == "welcome"
    writer.close()


async def test_welcome_entity_id_is_positive_int(server):
    _, writer, welcome = await _connect_and_auth(server.bound_port)
    assert isinstance(welcome.get("entity_id"), int)
    assert welcome["entity_id"] > 0
    writer.close()


async def test_welcome_map_dimensions(server):
    _, writer, welcome = await _connect_and_auth(server.bound_port)
    assert welcome["map_width"] == _MAP_W
    assert welcome["map_height"] == _MAP_H
    writer.close()


async def test_welcome_map_tiles_non_empty(server):
    _, writer, welcome = await _connect_and_auth(server.bound_port)
    assert len(welcome.get("map_tiles", [])) > 0
    writer.close()


async def test_welcome_tile_has_expected_fields(server):
    _, writer, welcome = await _connect_and_auth(server.bound_port)
    tile = welcome["map_tiles"][0]
    for key in ("x", "y", "walkable", "char", "fg", "bg"):
        assert key in tile
    writer.close()


async def test_welcome_ambient_value(server):
    _, writer, welcome = await _connect_and_auth(server.bound_port)
    assert welcome["ambient"] == pytest.approx(0.35)
    writer.close()


async def test_welcome_fog_structure(server):
    _, writer, welcome = await _connect_and_auth(server.bound_port)
    fog = welcome.get("fog", {})
    for key in (
        "density",
        "scale",
        "wind_x",
        "wind_y",
        "color",
        "opacity_min",
        "opacity_max",
    ):
        assert key in fog, f"fog missing key {key!r}"
    assert len(fog["color"]) == 3
    writer.close()


# ---------------------------------------------------------------------------
# Tick snapshots — delivery and content
# ---------------------------------------------------------------------------


async def test_tick_snapshot_arrives(server):
    reader, writer, _ = await _connect_and_auth(server.bound_port)
    tick = await _recv_tick(reader)
    assert tick.get("type") == "tick"
    writer.close()


async def test_tick_abs_tick_is_monotonically_increasing(server):
    reader, writer, _ = await _connect_and_auth(server.bound_port)
    tick1 = await _recv_tick(reader)
    tick2 = await _recv_tick(reader)
    tick3 = await _recv_tick(reader)
    assert tick1["abs_tick"] < tick2["abs_tick"] < tick3["abs_tick"]
    writer.close()


async def test_tick_has_expected_top_level_keys(server):
    reader, writer, _ = await _connect_and_auth(server.bound_port)
    tick = await _recv_tick(reader)
    for key in (
        "abs_tick",
        "entities",
        "tile_reveals",
        "projectiles",
        "light_sources",
        "attack_cooldown_fraction",
    ):
        assert key in tick, f"tick snapshot missing key {key!r}"
    writer.close()


async def test_welcome_contains_initial_map_tiles(server):
    """Initial visible tiles are delivered in the welcome message as map_tiles."""
    _, writer, welcome = await _connect_and_auth(server.bound_port)
    assert len(welcome.get("map_tiles", [])) > 0
    writer.close()


async def test_stable_ticks_have_empty_tile_reveals(server):
    """When not moving, subsequent ticks should not re-reveal already-seen tiles."""
    reader, writer, _ = await _connect_and_auth(server.bound_port)
    # Skip the first tick (may still carry initial reveals from racing connects)
    await _recv_tick(reader)
    for _ in range(3):
        tick = await _recv_tick(reader)
        assert tick["tile_reveals"] == []
    writer.close()


# ---------------------------------------------------------------------------
# Player entity in snapshot
# ---------------------------------------------------------------------------


async def test_player_entity_appears_in_snapshot(server):
    reader, writer, welcome = await _connect_and_auth(server.bound_port)
    entity_id = welcome["entity_id"]
    tick = await _recv_tick(reader)
    ids = [e["entity_id"] for e in tick.get("entities", [])]
    assert entity_id in ids
    writer.close()


async def test_player_entity_has_is_player_true(server):
    reader, writer, welcome = await _connect_and_auth(server.bound_port)
    entity_id = welcome["entity_id"]
    tick = await _recv_tick(reader)
    entity = next(e for e in tick["entities"] if e["entity_id"] == entity_id)
    catalogue = welcome.get("type_catalogue", {})
    entity_type = catalogue.get("entity_types", {}).get(entity["type_id"], {})
    assert entity_type.get("is_player") is True
    writer.close()


async def test_player_entity_has_stats(server):
    reader, writer, welcome = await _connect_and_auth(server.bound_port)
    entity_id = welcome["entity_id"]
    tick = await _recv_tick(reader)
    entity = next(e for e in tick["entities"] if e["entity_id"] == entity_id)
    assert len(entity["stats"]) > 0
    writer.close()


async def test_player_entity_position_is_within_map(server):
    reader, writer, welcome = await _connect_and_auth(server.bound_port)
    entity_id = welcome["entity_id"]
    tick = await _recv_tick(reader)
    entity = next(e for e in tick["entities"] if e["entity_id"] == entity_id)
    assert 0 <= entity["x"] < _MAP_W
    assert 0 <= entity["y"] < _MAP_H
    writer.close()


# ---------------------------------------------------------------------------
# MOVE command — verifies command → game → snapshot pipeline
# ---------------------------------------------------------------------------


async def test_move_command_changes_player_position(server):
    """Send a single MOVE right; verify position in snapshot changes."""
    reader, writer, welcome = await _connect_and_auth(server.bound_port)
    entity_id = welcome["entity_id"]

    tick0 = await _recv_tick(reader)
    entity0 = next(e for e in tick0["entities"] if e["entity_id"] == entity_id)
    x0, y0 = entity0["x"], entity0["y"]

    # Interior is fully walkable; moving right always succeeds unless at border.
    await send_message(writer, {"type": "command", "raw": "/move right"})

    moved_entity = None
    for _ in range(20):
        tick = await _recv_tick(reader)
        ents = {e["entity_id"]: e for e in tick.get("entities", [])}
        if entity_id in ents:
            e = ents[entity_id]
            if (e["x"], e["y"]) != (x0, y0):
                moved_entity = e
                break

    assert moved_entity is not None, "Position never changed after MOVE right"
    writer.close()


async def test_move_command_position_stays_on_walkable_tile(server):
    """Player position must always be on a walkable tile after moving."""
    reader, writer, welcome = await _connect_and_auth(server.bound_port)
    entity_id = welcome["entity_id"]

    for direction in ("right", "down"):
        await send_message(writer, {"type": "command", "raw": f"/move {direction}"})
        await _recv_tick(reader)

    tick = await _recv_tick(reader)
    ents = {e["entity_id"]: e for e in tick.get("entities", [])}
    assert entity_id in ents
    x, y = ents[entity_id]["x"], ents[entity_id]["y"]
    assert server._game.game_map.is_walkable(x, y)
    writer.close()


# ---------------------------------------------------------------------------
# Two concurrent clients
# ---------------------------------------------------------------------------


async def test_two_clients_get_different_entity_ids(server):
    _, w1, welcome1 = await _connect_and_auth(
        server.bound_port, uuid="uuid-a", username="alpha"
    )
    _, w2, welcome2 = await _connect_and_auth(
        server.bound_port, uuid="uuid-b", username="beta"
    )
    assert welcome1["entity_id"] != welcome2["entity_id"]
    w1.close()
    w2.close()


async def test_two_clients_both_receive_ticks(server):
    r1, w1, _ = await _connect_and_auth(
        server.bound_port, uuid="uuid-a", username="alpha"
    )
    r2, w2, _ = await _connect_and_auth(
        server.bound_port, uuid="uuid-b", username="beta"
    )
    tick1 = await _recv_tick(r1)
    tick2 = await _recv_tick(r2)
    assert tick1["abs_tick"] >= 1
    assert tick2["abs_tick"] >= 1
    w1.close()
    w2.close()


async def test_two_clients_see_each_other(server):
    """On a 10×10 map the full interior is always within FOV sight range."""
    r1, w1, welcome1 = await _connect_and_auth(
        server.bound_port, uuid="uuid-a", username="alpha"
    )
    _, w2, welcome2 = await _connect_and_auth(
        server.bound_port, uuid="uuid-b", username="beta"
    )
    eid2 = welcome2["entity_id"]

    # Drain up to 15 ticks for both entities to appear in client-1's FOV.
    visible_ids: list[int] = []
    for _ in range(15):
        tick = await _recv_tick(r1)
        visible_ids = [e["entity_id"] for e in tick.get("entities", [])]
        if eid2 in visible_ids:
            break

    assert eid2 in visible_ids, "Second player never appeared in first player's FOV"
    w1.close()
    w2.close()


# ---------------------------------------------------------------------------
# Ping / pong
# ---------------------------------------------------------------------------


async def test_ping_pong_roundtrip(server):
    reader, writer, _ = await _connect_and_auth(server.bound_port)
    t_sent = 42.0
    await send_message(writer, {"type": "ping", "t": t_sent})
    pong = None
    for _ in range(30):
        msg = await asyncio.wait_for(recv_message(reader), timeout=2.0)
        if msg.get("type") == "pong":
            pong = msg
            break
    assert pong is not None
    assert pong["t"] == pytest.approx(t_sent)
    writer.close()


# ---------------------------------------------------------------------------
# Protocol error handling
# ---------------------------------------------------------------------------


async def test_wrong_auth_type_returns_error(server):
    reader, writer = await _connect(server.bound_port)
    await send_message(writer, {"type": "not_auth", "data": "nope"})
    response = await asyncio.wait_for(recv_message(reader), timeout=2.0)
    assert response["type"] == "error"
    assert "auth" in response["message"]
    writer.close()


async def test_server_full_returns_error():
    """A server with max_clients=1 rejects the second client."""
    game = _make_test_game()
    srv = GameServer(game, "localhost", 0, max_clients=1)
    task = asyncio.create_task(srv.run())
    await asyncio.sleep(0.05)
    port = srv.bound_port
    try:
        _, w1, welcome1 = await _connect_and_auth(port, uuid="u1", username="p1")
        assert welcome1["type"] == "welcome"
        _, w2, response = await _connect_and_auth(port, uuid="u2", username="p2")
        assert response["type"] == "error"
        assert "full" in response["message"]
        w1.close()
        w2.close()
    finally:
        pending = [t for t in asyncio.all_tasks() if t is not asyncio.current_task()]
        for t in pending:
            t.cancel()
        await asyncio.gather(*pending, return_exceptions=True)
        del task


# ---------------------------------------------------------------------------
# Reconnect — same UUID reuses existing session
# ---------------------------------------------------------------------------


async def test_reconnect_same_uuid_reuses_entity_id(server):
    """Reconnecting with the same UUID must yield the same entity_id."""
    _, w1, welcome1 = await _connect_and_auth(
        server.bound_port, uuid="stable-uuid", username="bob"
    )
    eid1 = welcome1["entity_id"]
    w1.close()
    await asyncio.sleep(0.05)  # let server notice the disconnect

    _, w2, welcome2 = await _connect_and_auth(
        server.bound_port, uuid="stable-uuid", username="bob"
    )
    eid2 = welcome2["entity_id"]
    assert eid1 == eid2
    w2.close()


# ---------------------------------------------------------------------------
# Serialization round-trip
# ---------------------------------------------------------------------------


async def test_deserialize_snapshot_from_live_tick(server):
    """End-to-end: tick dict from server is valid input to deserialize_snapshot."""
    from faraway_realms.net.serialization import deserialize_snapshot

    reader, writer, _ = await _connect_and_auth(server.bound_port)
    tick = await _recv_tick(reader)
    snap = deserialize_snapshot(tick)
    assert snap.abs_tick >= 1
    assert isinstance(snap.entities, list)
    writer.close()


async def test_deserialize_snapshot_player_entity(server):
    """Deserialized snapshot contains the player's EntitySnapshot."""
    from faraway_realms.net.serialization import deserialize_snapshot

    reader, writer, welcome = await _connect_and_auth(server.bound_port)
    entity_id = welcome["entity_id"]
    tick = await _recv_tick(reader)
    snap = deserialize_snapshot(tick)
    ids = [e.entity_id for e in snap.entities]
    assert entity_id in ids
    writer.close()


async def test_entity_snapshot_stats_round_trip(server):
    """Stats serialized on the server must survive the msgpack round-trip."""
    from faraway_realms.net.serialization import deserialize_snapshot

    reader, writer, welcome = await _connect_and_auth(server.bound_port)
    entity_id = welcome["entity_id"]
    tick = await _recv_tick(reader)
    snap = deserialize_snapshot(tick)
    entity = next(e for e in snap.entities if e.entity_id == entity_id)
    assert len(entity.stats) > 0
    for stat_data in entity.stats.values():
        assert "base" in stat_data
        assert "abbreviation" in stat_data
    writer.close()
