"""Tests for describe_position — client-side inspect logic."""

from __future__ import annotations

from unittest.mock import MagicMock

from faraway_realms.describe import InspectResult, describe_position
from faraway_realms.world.map import make_bordered_map
from faraway_realms.world.tile import unknown_tile


def _make_game(snap=None, catalogue=None):
    from faraway_realms.client_game import ClientGame

    client = MagicMock()
    client.latest_snapshot.return_value = snap
    client.player_overrides.return_value = {}
    return ClientGame(
        client=client,
        game_map=make_bordered_map(20, 20),
        type_catalogue=catalogue or {},
    )


def test_unexplored_tile_returns_unexplored():
    game = _make_game()
    # Blank map starts with unknown tiles; set one explicitly
    game.game_map.set_tile(5, 5, unknown_tile())
    result = describe_position(game, 5, 5)
    assert result.heading == "Unexplored"


def test_walkable_tile_describes_as_floor():
    from faraway_realms.world.tile import floor_tile

    game = _make_game()
    game.game_map.set_tile(5, 5, floor_tile())
    result = describe_position(game, 5, 5)
    assert "floor" in result.heading.lower()


def test_wall_tile_describes_as_wall():
    from faraway_realms.world.tile import wall_tile

    game = _make_game()
    game.game_map.set_tile(5, 5, wall_tile())
    result = describe_position(game, 5, 5)
    assert "wall" in result.heading.lower()


def test_tile_with_overlay_includes_overlay_description():
    from faraway_realms.world.tile import floor_tile

    catalogue = {"tile_overlays": {"moss": {"description": "mossy", "name": "moss"}}}
    game = _make_game(catalogue=catalogue)
    game.game_map.set_tile(5, 5, floor_tile())
    game.game_map.tile_zones[(5, 5)] = "moss"
    result = describe_position(game, 5, 5)
    assert "mossy" in result.heading.lower()
    assert "floor" in result.heading.lower()


def test_entity_at_position_takes_priority_over_tile():
    from faraway_realms.net.serialization import EntitySnapshot, TickSnapshot
    from faraway_realms.world.tile import floor_tile

    snap_e = EntitySnapshot(
        entity_id=1,
        x=5,
        y=5,
        type_id="hero",
        target_id=None,
        stats={},
        status_effects=[],
    )
    snap = TickSnapshot(entities=[snap_e], attack_cooldown_fraction=0.0)
    catalogue = {
        "entity_types": {
            "hero": {
                "char": ord("@"),
                "fg_color": [255, 255, 0],
                "display_name": "Hero",
                "faction": "player",
                "abilities": [],
                "blood_color": None,
                "is_player": True,
                "description": "A brave adventurer.",
            }
        }
    }
    game = _make_game(snap=snap, catalogue=catalogue)
    game.game_map.set_tile(5, 5, floor_tile())
    game.game_map.place_entity(1, 5, 5)
    result = describe_position(game, 5, 5)
    assert result.heading == "Hero"
    texts = [t for t, _ in result.lines]
    assert any("adventurer" in t.lower() for t in texts)


def test_static_object_description_from_catalogue():
    from faraway_realms.entities.static_object import StaticObject
    from faraway_realms.world.tile import floor_tile

    catalogue = {
        "static_object_types": {
            "torch": {
                "description": "A burning torch.",
            }
        }
    }
    game = _make_game(catalogue=catalogue)
    game.game_map.set_tile(3, 3, floor_tile())
    game._static_objects_cache.append(  # noqa: SLF001
        StaticObject(x=3, y=3, char=ord("T"), fg_color=(255, 200, 0), type_id="torch")
    )
    result = describe_position(game, 3, 3)
    assert "torch" in result.heading.lower()
    texts = [t for t, _ in result.lines]
    assert any("burning" in t.lower() for t in texts)


def test_describe_result_is_inspect_result_instance():
    game = _make_game()
    result = describe_position(game, 5, 5)
    assert isinstance(result, InspectResult)
