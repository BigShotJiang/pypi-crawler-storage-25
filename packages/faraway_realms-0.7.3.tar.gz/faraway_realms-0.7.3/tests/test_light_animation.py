"""Tests for light source animation — flicker, glow, color shift, wire round-trip."""

import math

import pytest

from faraway_realms.effects.light import (
    LightAnimation,
    LightSource,
    _animated_source,
    _flicker_intensity,
    _glow_intensity,
    _shift_color,
    animate_light_sources,
)
from faraway_realms.net.serialization import _deser_animation, _ser_light_source

# ---------------------------------------------------------------------------
# _glow_intensity
# ---------------------------------------------------------------------------


def _glow_anim(lo=0.5, hi=0.9, period=4.0):
    return LightAnimation(
        kind="glow", intensity_min=lo, intensity_max=hi, period=period
    )


def test_glow_within_range():
    anim = _glow_anim()
    for t in range(0, 100):
        v = _glow_intensity(anim, t * 0.1)
        assert anim.intensity_min <= v <= anim.intensity_max


def test_glow_full_cycle_returns_to_start():
    anim = _glow_anim(period=2.0)
    assert math.isclose(
        _glow_intensity(anim, 0.0), _glow_intensity(anim, 2.0), abs_tol=1e-6
    )


def test_glow_midpoint_is_max():
    anim = _glow_anim(lo=0.4, hi=1.0, period=4.0)
    # sin peaks at t = period/4
    assert math.isclose(_glow_intensity(anim, 1.0), 1.0, abs_tol=1e-6)


# ---------------------------------------------------------------------------
# _flicker_intensity
# ---------------------------------------------------------------------------


def _flicker_anim(lo=0.6, hi=0.95):
    return LightAnimation(kind="flicker", intensity_min=lo, intensity_max=hi)


def test_flicker_within_range():
    anim = _flicker_anim()
    for t in range(0, 200):
        v = _flicker_intensity(5, 10, anim, t * 0.05)
        assert anim.intensity_min <= v <= anim.intensity_max


def test_flicker_different_positions_differ():
    anim = _flicker_anim()
    t = 1.234
    v1 = _flicker_intensity(3, 7, anim, t)
    v2 = _flicker_intensity(8, 2, anim, t)
    assert v1 != pytest.approx(v2), "adjacent torches must not be in phase"


def test_flicker_same_position_deterministic():
    anim = _flicker_anim()
    assert _flicker_intensity(4, 4, anim, 0.5) == _flicker_intensity(4, 4, anim, 0.5)


# ---------------------------------------------------------------------------
# _shift_color
# ---------------------------------------------------------------------------


def test_shift_color_zero_shift_unchanged():
    assert _shift_color((200, 100, 50), 0.8, 0.8, 0) == (200, 100, 50)


def test_shift_color_brighter_warms():
    # intensity > base → positive delta → more red, less blue
    r, g, b = _shift_color((200, 100, 50), 1.0, 0.5, 30)
    assert r > 200
    assert b < 50
    assert g == 100  # green unchanged


def test_shift_color_dimmer_cools():
    # intensity < base → negative delta → less red, more blue
    r, g, b = _shift_color((200, 100, 50), 0.1, 0.9, 30)
    assert r < 200
    assert b > 50


def test_shift_color_clamped():
    r, g, b = _shift_color((255, 128, 0), 2.0, 0.5, 100)
    assert r == 255
    assert b == 0


# ---------------------------------------------------------------------------
# _animated_source
# ---------------------------------------------------------------------------


def test_animated_source_no_animation_returns_same():
    src = LightSource(radius=5, intensity=0.8, color=(200, 150, 100))
    result = _animated_source(0, 0, src, 1.0)
    assert result is src


def test_animated_source_glow_modifies_intensity():
    anim = _glow_anim(lo=0.4, hi=0.9)
    src = LightSource(radius=5, intensity=0.8, color=(200, 150, 100), animation=anim)
    result = _animated_source(0, 0, src, 1.0)
    assert result.intensity != src.intensity
    assert anim.intensity_min <= result.intensity <= anim.intensity_max


def test_animated_source_has_no_animation_field():
    # The returned source should not carry animation (already applied)
    anim = _flicker_anim()
    src = LightSource(radius=4, intensity=0.7, color=(255, 100, 50), animation=anim)
    result = _animated_source(3, 5, src, 0.5)
    assert result.animation is None


def test_animated_source_preserves_radius():
    anim = _glow_anim()
    src = LightSource(radius=7, intensity=0.8, color=(80, 40, 200), animation=anim)
    assert _animated_source(1, 1, src, 0.0).radius == 7


# ---------------------------------------------------------------------------
# animate_light_sources
# ---------------------------------------------------------------------------


def test_animate_leaves_static_sources_unchanged():
    static = LightSource(radius=3, intensity=0.6, color=(255, 200, 100))
    sources = [(1, 2, static)]
    result = animate_light_sources(sources, 0.0)
    assert result[0][2] is static


def test_animate_modifies_animated_source():
    anim = _glow_anim(lo=0.3, hi=0.7)
    src = LightSource(radius=5, intensity=0.8, color=(80, 40, 200), animation=anim)
    sources = [(3, 4, src)]
    result = animate_light_sources(sources, 1.0)
    assert result[0][2].intensity != src.intensity


def test_animate_preserves_position():
    anim = _flicker_anim()
    src = LightSource(radius=5, intensity=0.8, color=(255, 150, 60), animation=anim)
    sources = [(7, 9, src)]
    x, y, _ = animate_light_sources(sources, 0.5)[0]
    assert (x, y) == (7, 9)


def test_animate_mixed_sources():
    static = LightSource(radius=3, intensity=0.5, color=(255, 200, 100))
    animated = LightSource(
        radius=5, intensity=0.8, color=(80, 40, 200), animation=_glow_anim()
    )
    result = animate_light_sources([(0, 0, static), (1, 1, animated)], 1.0)
    assert result[0][2] is static
    assert result[1][2] is not animated


# ---------------------------------------------------------------------------
# Wire round-trip
# ---------------------------------------------------------------------------


def test_ser_light_source_no_animation_has_five_elements():
    src = LightSource(radius=5, intensity=0.8, color=(255, 150, 60))
    wire = _ser_light_source(3, 4, src)
    assert len(wire) == 5


def test_ser_light_source_with_animation_has_six_elements():
    anim = LightAnimation(
        kind="flicker", intensity_min=0.6, intensity_max=0.95, color_shift=20
    )
    src = LightSource(radius=7, intensity=0.95, color=(255, 150, 60), animation=anim)
    wire = _ser_light_source(1, 2, src)
    assert len(wire) == 6


def test_animation_round_trip():
    anim = LightAnimation(
        kind="glow", intensity_min=0.55, intensity_max=0.85, period=3.5, color_shift=0
    )
    src = LightSource(radius=5, intensity=0.85, color=(80, 40, 200), animation=anim)
    wire = _ser_light_source(2, 3, src)
    recovered = _deser_animation(wire[5])
    assert recovered is not None
    assert recovered.kind == anim.kind
    assert recovered.intensity_min == anim.intensity_min
    assert recovered.intensity_max == anim.intensity_max
    assert recovered.period == anim.period
    assert recovered.color_shift == anim.color_shift


def test_deser_animation_none_returns_none():
    assert _deser_animation(None) is None
