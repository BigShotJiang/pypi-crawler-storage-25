"""Tests for the map generation pipeline."""

import random

import pytest

from faraway_realms.mapgen import (
    CaveGenerator,
    CellularAutomataGenerator,
    GeneratorConfig,
    MapGenResult,
    Rect,
    make_generator,
)
from faraway_realms.mapgen.cave import _padded

# ---------------------------------------------------------------------------
# Rect
# ---------------------------------------------------------------------------


def test_rect_x2_y2() -> None:
    r = Rect(2, 3, 6, 4)
    assert r.x2 == 8
    assert r.y2 == 7


def test_rect_center_even_dimensions() -> None:
    assert Rect(0, 0, 10, 10).center == (5, 5)


def test_rect_center_odd_dimensions() -> None:
    assert Rect(0, 0, 5, 5).center == (2, 2)


def test_rect_intersects_overlapping() -> None:
    a = Rect(0, 0, 5, 5)
    b = Rect(3, 3, 5, 5)
    assert a.intersects(b)
    assert b.intersects(a)


def test_rect_intersects_fully_inside() -> None:
    outer = Rect(0, 0, 10, 10)
    inner = Rect(2, 2, 4, 4)
    assert outer.intersects(inner)


def test_rect_no_intersect_separated() -> None:
    a = Rect(0, 0, 3, 3)
    b = Rect(5, 5, 3, 3)
    assert not a.intersects(b)


def test_rect_no_intersect_touching_edge() -> None:
    """Rects that share only an edge (x2 == other.x) must not intersect."""
    a = Rect(0, 0, 3, 3)
    b = Rect(3, 0, 3, 3)
    assert not a.intersects(b)


def test_rect_padded_expands_correctly() -> None:
    r = Rect(5, 5, 4, 4)
    p = _padded(r, 1)
    assert p.x == 4
    assert p.y == 4
    assert p.width == 6
    assert p.height == 6


# ---------------------------------------------------------------------------
# CaveGenerator — map structure
# ---------------------------------------------------------------------------


def _gen(seed: int = 42, width: int = 80, height: int = 50) -> MapGenResult:
    return CaveGenerator().generate(width, height, random.Random(seed))


def test_cave_generator_correct_dimensions() -> None:
    result = _gen()
    assert result.map.width == 80
    assert result.map.height == 50


def test_cave_generator_produces_rooms() -> None:
    assert len(_gen().rooms) > 0


def test_cave_generator_player_start_walkable() -> None:
    result = _gen()
    x, y = result.player_start
    assert result.map.is_walkable(x, y)


def test_cave_generator_player_start_is_first_room_centre() -> None:
    result = _gen()
    assert result.player_start == result.rooms[0].center


def test_cave_generator_room_centres_are_walkable() -> None:
    result = _gen()
    for room in result.rooms:
        cx, cy = room.center
        assert result.map.is_walkable(cx, cy)


def test_cave_generator_border_stays_impassable() -> None:
    """The outermost ring of tiles must never be carved."""
    result = _gen()
    m = result.map
    for x in range(m.width):
        assert not m.is_walkable(x, 0), f"top border at x={x} is walkable"
        assert not m.is_walkable(x, m.height - 1), f"bottom border at x={x} is walkable"
    for y in range(m.height):
        assert not m.is_walkable(0, y), f"left border at y={y} is walkable"
        assert not m.is_walkable(m.width - 1, y), f"right border at y={y} is walkable"


def test_cave_generator_rooms_do_not_overlap() -> None:
    result = _gen()
    rooms = result.rooms
    for i, r1 in enumerate(rooms):
        for r2 in rooms[i + 1 :]:
            assert not r1.intersects(r2), f"rooms {i} and {i + 1} overlap"


def test_cave_generator_corridors_two_tiles_wide() -> None:
    """Both the primary row and row+1 of each horizontal tunnel are walkable."""
    result = _gen()
    if len(result.rooms) < 2:
        pytest.skip("need at least 2 rooms")
    r1, r2 = result.rooms[0], result.rooms[1]
    _, cy1 = r1.center
    cx1, _ = r1.center
    cx2, _ = r2.center
    mid_x = (cx1 + cx2) // 2
    assert result.map.is_walkable(mid_x, cy1), "horizontal corridor row missing"
    assert result.map.is_walkable(mid_x, cy1 + 1), "second corridor row missing"


def test_cave_generator_rooms_minimum_size() -> None:
    result = _gen()
    for room in result.rooms:
        assert room.width >= 4
        assert room.height >= 4


def test_cave_generator_deterministic() -> None:
    """Same seed must produce identical room lists."""
    r1 = CaveGenerator().generate(80, 50, random.Random(7))
    r2 = CaveGenerator().generate(80, 50, random.Random(7))
    assert r1.rooms == r2.rooms
    assert r1.player_start == r2.player_start


def test_cave_generator_different_seeds_differ() -> None:
    r1 = CaveGenerator().generate(80, 50, random.Random(1))
    r2 = CaveGenerator().generate(80, 50, random.Random(999))
    assert r1.rooms != r2.rooms


def test_cave_generator_custom_params() -> None:
    gen = CaveGenerator(max_rooms=5, room_min_size=5, room_max_size=6)
    result = gen.generate(80, 50, random.Random(42))
    assert len(result.rooms) <= 5
    for room in result.rooms:
        assert 5 <= room.width <= 6
        assert 5 <= room.height <= 6


def test_cave_generator_empty_fallback_when_no_rooms_fit() -> None:
    """Tiny map that can't fit any room returns empty rooms list and fallback start."""
    gen = CaveGenerator(room_min_size=4, room_max_size=4)
    # 4x4 interior + 1 border on each side = exactly 6 wide/tall
    result = gen.generate(6, 6, random.Random(0))
    # May or may not fit; just verify the result is valid
    x, y = result.player_start
    assert 0 <= x < result.map.width
    assert 0 <= y < result.map.height


# ---------------------------------------------------------------------------
# CaveGenerator — spawn zones
# ---------------------------------------------------------------------------


def test_cave_generator_spawn_zones_count_matches_rooms() -> None:
    result = _gen()
    assert len(result.spawn_zones) == len(result.rooms)


def test_cave_generator_spawn_zones_all_walkable() -> None:
    result = _gen()
    for zone in result.spawn_zones:
        for x, y in zone:
            assert result.map.is_walkable(x, y)


def test_cave_generator_player_zone_index_is_zero() -> None:
    assert _gen().player_zone_index == 0


def test_cave_generator_player_start_in_player_zone() -> None:
    result = _gen()
    player_zone = set(result.spawn_zones[result.player_zone_index])
    assert result.player_start in player_zone


def test_cave_generator_door_candidates_produced() -> None:
    result = CaveGenerator().generate(80, 50, random.Random(42))
    if len(result.rooms) >= 2:
        assert len(result.door_candidates) > 0


# ---------------------------------------------------------------------------
# CellularAutomataGenerator
# ---------------------------------------------------------------------------


def _ca_gen(seed: int = 42, width: int = 80, height: int = 50) -> MapGenResult:
    return CellularAutomataGenerator().generate(width, height, random.Random(seed))


def test_ca_generator_correct_dimensions() -> None:
    result = _ca_gen()
    assert result.map.width == 80
    assert result.map.height == 50


def test_ca_generator_player_start_walkable() -> None:
    result = _ca_gen()
    x, y = result.player_start
    assert result.map.is_walkable(x, y)


def test_ca_generator_no_rooms() -> None:
    assert _ca_gen().rooms == []


def test_ca_generator_has_spawn_zones() -> None:
    result = _ca_gen()
    assert len(result.spawn_zones) > 0


def test_ca_generator_player_zone_index_zero() -> None:
    assert _ca_gen().player_zone_index == 0


def test_ca_generator_player_start_in_player_zone() -> None:
    result = _ca_gen()
    player_zone = set(result.spawn_zones[result.player_zone_index])
    assert result.player_start in player_zone


def test_ca_generator_spawn_zones_all_walkable() -> None:
    result = _ca_gen()
    for zone in result.spawn_zones:
        for x, y in zone:
            assert result.map.is_walkable(x, y)


def test_ca_generator_border_stays_impassable() -> None:
    result = _ca_gen()
    m = result.map
    for x in range(m.width):
        assert not m.is_walkable(x, 0)
        assert not m.is_walkable(x, m.height - 1)
    for y in range(m.height):
        assert not m.is_walkable(0, y)
        assert not m.is_walkable(m.width - 1, y)


def test_ca_generator_deterministic() -> None:
    r1 = CellularAutomataGenerator().generate(80, 50, random.Random(7))
    r2 = CellularAutomataGenerator().generate(80, 50, random.Random(7))
    assert r1.player_start == r2.player_start
    assert len(r1.spawn_zones) == len(r2.spawn_zones)


def test_ca_generator_different_seeds_differ() -> None:
    r1 = CellularAutomataGenerator().generate(80, 50, random.Random(1))
    r2 = CellularAutomataGenerator().generate(80, 50, random.Random(999))
    assert r1.player_start != r2.player_start or len(r1.spawn_zones) != len(
        r2.spawn_zones
    )


def test_ca_generator_min_region_culled() -> None:
    """With a high min_region_size, tiny voids should be filled."""
    gen = CellularAutomataGenerator(min_region_size=100)
    result = gen.generate(80, 50, random.Random(42))
    for zone in result.spawn_zones:
        assert len(zone) >= 100


# ---------------------------------------------------------------------------
# GeneratorConfig and make_generator factory
# ---------------------------------------------------------------------------


def test_generator_config_default_is_cave() -> None:
    config = GeneratorConfig()
    gen = make_generator(config)
    assert isinstance(gen, CaveGenerator)


def test_generator_config_cellular_automata() -> None:
    config = GeneratorConfig(kind="cellular_automata")
    gen = make_generator(config)
    assert isinstance(gen, CellularAutomataGenerator)


def test_generator_config_params_forwarded() -> None:
    config = GeneratorConfig(kind="cave", params=(("max_rooms", 5),))
    gen = make_generator(config)
    assert isinstance(gen, CaveGenerator)
    assert gen.max_rooms == 5


def test_make_generator_unknown_kind_raises() -> None:
    config = GeneratorConfig(kind="unknown_generator")
    with pytest.raises(ValueError, match="unknown_generator"):
        make_generator(config)
