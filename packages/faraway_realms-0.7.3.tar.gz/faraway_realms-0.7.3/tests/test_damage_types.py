"""Tests for faraway_realms.combat.damage_types."""

import logging

import pytest

from faraway_realms.combat.damage_types import (
    EFFECTIVENESS,
    compute_ability_damage,
    effectiveness,
)


def test_known_pair_returns_correct_multiplier():
    assert effectiveness("bludgeoning", "stone") == 1.5


def test_slashing_flesh_returns_correct_multiplier():
    assert effectiveness("slashing", "flesh") == 1.2


def test_piercing_chitin_returns_correct_multiplier():
    assert effectiveness("piercing", "chitin") == 0.6


def test_unknown_pair_returns_1_0():
    assert effectiveness("fire", "wood") == 1.0


def test_none_armor_type_not_in_matrix_defaults_to_1_0():
    assert effectiveness("slashing", "none") == 1.0


def test_unknown_damage_type_defaults_to_1_0():
    assert effectiveness("unknown", "flesh") == 1.0


# ------------------------------------------------------------------
# compute_ability_damage
# ------------------------------------------------------------------


def test_compute_ability_damage_applies_effectiveness():
    # fire vs flesh = 1.2; (10 - 0) * 1.2 = 12
    assert compute_ability_damage(10, "fire", "flesh", 0) == 12


def test_compute_ability_damage_subtracts_armor():
    # fire vs flesh = 1.2; (10 - 4) * 1.2 = 7.2 → 7
    assert compute_ability_damage(10, "fire", "flesh", 4) == 7


def test_compute_ability_damage_minimum_is_1():
    # high armor; result would be 0 or negative
    assert compute_ability_damage(5, "piercing", "stone", 1000) == 1


def test_compute_ability_damage_unknown_pair_uses_1_0():
    # unknown vs unknown = 1.0; (8 - 2) * 1.0 = 6
    assert compute_ability_damage(8, "unknown", "unknown", 2) == 6


def test_compute_ability_damage_bludgeoning_stone():
    # bludgeoning vs stone = 1.5; (10 - 2) * 1.5 = 12
    assert compute_ability_damage(10, "bludgeoning", "stone", 2) == 12


# ------------------------------------------------------------------
# YAML round-trip
# ------------------------------------------------------------------


def test_shipped_yaml_populates_effectiveness():
    assert len(EFFECTIVENESS) > 0


def test_shipped_yaml_all_five_damage_types_present():
    damage_types = {dt for dt, _ in EFFECTIVENESS}
    assert damage_types == {"bludgeoning", "slashing", "piercing", "fire", "frost"}


def test_shipped_yaml_all_four_armor_types_covered():
    armor_types = {at for _, at in EFFECTIVENESS}
    assert {"flesh", "bone", "chitin", "stone"}.issubset(armor_types)


# ------------------------------------------------------------------
# Unknown pair warning
# ------------------------------------------------------------------


def test_unknown_pair_emits_warning(caplog):
    with caplog.at_level(logging.WARNING, logger="faraway_realms.combat.damage_types"):
        result = effectiveness("sonic", "rubber")
    assert result == 1.0
    assert any("sonic" in r.message for r in caplog.records)


def test_unknown_pair_warning_fires_only_once(caplog):
    with caplog.at_level(logging.WARNING, logger="faraway_realms.combat.damage_types"):
        effectiveness("arcane", "void")
        effectiveness("arcane", "void")
    warnings = [r for r in caplog.records if "arcane" in r.message]
    assert len(warnings) == 1


# ------------------------------------------------------------------
# Parser isolation
# ------------------------------------------------------------------


@pytest.fixture()
def clean_effectiveness():
    saved = dict(EFFECTIVENESS)
    EFFECTIVENESS.clear()
    yield
    EFFECTIVENESS.clear()
    EFFECTIVENESS.update(saved)


def test_parse_damage_effectiveness_populates_dict(clean_effectiveness):
    from faraway_realms.content_parsers.damage_types import parse_damage_effectiveness

    parse_damage_effectiveness({"acid": {"wood": 1.8, "stone": 0.5}})
    assert EFFECTIVENESS[("acid", "wood")] == pytest.approx(1.8)
    assert EFFECTIVENESS[("acid", "stone")] == pytest.approx(0.5)


def test_parse_damage_effectiveness_coerces_to_float(clean_effectiveness):
    from faraway_realms.content_parsers.damage_types import parse_damage_effectiveness

    parse_damage_effectiveness({"holy": {"undead": 2}})
    assert isinstance(EFFECTIVENESS[("holy", "undead")], float)
