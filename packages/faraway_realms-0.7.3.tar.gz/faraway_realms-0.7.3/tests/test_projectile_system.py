"""Tests for ProjectileSystem."""

from faraway_realms.combat.abilities import ApplyStatusEffect, ProjectileEffect
from faraway_realms.combat.stats import Pool, Stat
from faraway_realms.entities.entity import CharacterEntity, NonPlayerEntity
from faraway_realms.systems.ability_effects import AbilityEffectsSystem
from faraway_realms.systems.projectile import ProjectileSystem
from faraway_realms.world.event_bus import EventBus
from faraway_realms.world.events import EventType
from faraway_realms.world.map import make_bordered_map


def _make_system():
    """Return a ProjectileSystem with caster (1) at (2,5) and target (2) at (7,5)."""
    game_map = make_bordered_map(15, 15)
    caster = CharacterEntity(
        entity_id=1,
        char=ord("@"),
        fg_color=(255, 255, 0),
        name="Hero",
        stats={"health": Pool(base=100)},
    )
    target = NonPlayerEntity(
        entity_id=2,
        char=ord("Z"),
        fg_color=(0, 180, 0),
        name="Zombie",
        stats={"health": Pool(base=50)},
    )
    entities = {1: caster, 2: target}
    game_map.place_entity(1, 2, 5)
    game_map.place_entity(2, 7, 5)
    bus = EventBus()
    ability_effects = AbilityEffectsSystem(entities, game_map, bus)
    sys = ProjectileSystem(entities, game_map, bus, ability_effects)
    return sys, game_map, caster, target, bus


_SIMPLE_EFFECT = ProjectileEffect(
    base=10,
    damage_type="fire",
    speed=1.0,
    color=(255, 0, 0),
    visual_type="spell",
)


# ------------------------------------------------------------------
# spawn
# ------------------------------------------------------------------


def test_spawn_adds_to_active_projectiles():
    sys, _, _, _, _ = _make_system()
    sys.spawn(1, 2, _SIMPLE_EFFECT)
    assert len(sys.active_projectiles) == 1


def test_spawn_no_op_when_caster_missing():
    sys, _, _, _, _ = _make_system()
    sys.spawn(99, 2, _SIMPLE_EFFECT)
    assert len(sys.active_projectiles) == 0


def test_spawn_no_op_when_target_missing():
    sys, _, _, _, _ = _make_system()
    sys.spawn(1, 99, _SIMPLE_EFFECT)
    assert len(sys.active_projectiles) == 0


def test_spawn_sets_correct_origin():
    sys, _, _, _, _ = _make_system()
    sys.spawn(1, 2, _SIMPLE_EFFECT)
    p = sys.active_projectiles[0]
    assert (p.x, p.y) == (2, 5)


def test_spawn_sets_correct_target_pos():
    sys, _, _, _, _ = _make_system()
    sys.spawn(1, 2, _SIMPLE_EFFECT)
    p = sys.active_projectiles[0]
    assert (p.target_x, p.target_y) == (7, 5)


# ------------------------------------------------------------------
# movement
# ------------------------------------------------------------------


def test_tick_advances_projectile_one_tile_at_speed_1():
    sys, _, _, _, _ = _make_system()
    sys.spawn(1, 2, _SIMPLE_EFFECT)
    sys.tick(1)
    p = sys.active_projectiles[0]
    assert p.x == 3  # one step toward x=7


def test_tick_sub_tile_speed_does_not_move_every_tick():
    """speed=0.5 should move once every two ticks."""
    effect = ProjectileEffect(base=10, damage_type="fire", speed=0.5, color=(255, 0, 0))
    sys, _, _, _, _ = _make_system()
    sys.spawn(1, 2, effect)
    sys.tick(1)  # accum=0.5, moves=0
    p = sys.active_projectiles[0]
    assert p.x == 2  # no movement yet
    sys.tick(2)  # accum=1.0, moves=1
    p = sys.active_projectiles[0]
    assert p.x == 3


def test_tick_multi_tile_speed_moves_multiple_tiles():
    """speed=2.0 should move two tiles per tick."""
    effect = ProjectileEffect(base=10, damage_type="fire", speed=2.0, color=(255, 0, 0))
    sys, _, _, _, _ = _make_system()
    sys.spawn(1, 2, effect)
    sys.tick(1)
    p = sys.active_projectiles[0]
    assert p.x == 4  # 2+2


def test_projectile_removed_after_reaching_target():
    """After reaching target the projectile is despawned."""
    effect = ProjectileEffect(base=1, damage_type="fire", speed=10.0, color=(255, 0, 0))
    sys, _, _, _, _ = _make_system()
    sys.spawn(1, 2, effect)
    sys.tick(1)
    assert len(sys.active_projectiles) == 0


def test_projectile_despawned_on_wall_hit():
    sys, game_map, _, _, _ = _make_system()
    # Move target next to a wall column so the projectile path crosses it
    game_map.place_entity(2, 13, 5)
    effect = ProjectileEffect(base=5, damage_type="fire", speed=20.0, color=(0, 0, 255))
    sys.spawn(1, 2, effect)
    sys.tick(1)
    # Projectile should have been despawned when it hit the right border wall
    assert len(sys.active_projectiles) == 0


# ------------------------------------------------------------------
# trail
# ------------------------------------------------------------------


def test_trail_populated_during_flight():
    effect = ProjectileEffect(
        base=5, damage_type="fire", speed=1.0, color=(255, 0, 0), trail_length=3
    )
    sys, _, _, _, _ = _make_system()
    sys.spawn(1, 2, effect)
    sys.tick(1)
    sys.tick(2)
    p = sys.active_projectiles[0]
    assert len(p.trail) > 0


def test_trail_length_zero_stays_empty():
    sys, _, _, _, _ = _make_system()
    sys.spawn(1, 2, _SIMPLE_EFFECT)  # trail_length=0
    sys.tick(1)
    sys.tick(2)
    p = sys.active_projectiles[0]
    assert len(p.trail) == 0


# ------------------------------------------------------------------
# detonation
# ------------------------------------------------------------------


_FAST_EFFECT = ProjectileEffect(
    base=10, damage_type="fire", speed=10.0, color=(255, 0, 0)
)


def test_detonation_publishes_entity_hit():
    sys, _, _, _, bus = _make_system()
    hits = []
    bus.subscribe(EventType.ENTITY_HIT, hits.append)
    sys.spawn(1, 2, _FAST_EFFECT)
    sys.tick(1)
    bus.flush(abs_tick=1)
    assert len(hits) == 1


def test_detonation_damage_applied_to_target_hp():
    effect = ProjectileEffect(
        base=20, damage_type="fire", speed=10.0, color=(255, 0, 0)
    )
    sys, _, _, target, _ = _make_system()
    hp_before = target.stats["health"].current
    sys.spawn(1, 2, effect)
    sys.tick(1)
    hp_after = target.stats["health"].current
    assert hp_after < hp_before


def test_detonation_armor_reduces_damage():
    sys, game_map, caster, target, _ = _make_system()
    target.stats["armor"] = Stat(base=8)
    effect = ProjectileEffect(
        base=10, damage_type="fire", speed=10.0, color=(255, 0, 0)
    )
    sys.spawn(1, 2, effect)
    sys.tick(1)
    # fire vs flesh=1.2; (10-8)*1.2 = 2.4 → 2; HP was 50 → 48
    assert target.stats["health"].current == 48


def test_detonation_minimum_damage_is_1():
    sys, game_map, caster, target, _ = _make_system()
    target.stats["armor"] = Stat(base=1000)
    effect = ProjectileEffect(base=5, damage_type="fire", speed=10.0, color=(255, 0, 0))
    sys.spawn(1, 2, effect)
    sys.tick(1)
    # min damage is 1; HP was 50 → 49
    assert target.stats["health"].current == 49


def test_detonation_death_event_published_when_fatal():
    effect = ProjectileEffect(
        base=999, damage_type="fire", speed=10.0, color=(255, 0, 0)
    )
    sys, _, _, _, bus = _make_system()
    deaths = []
    bus.subscribe(EventType.ENTITY_DYING, deaths.append)
    sys.spawn(1, 2, effect)
    sys.tick(1)
    bus.flush(abs_tick=1)
    assert len(deaths) == 1


def test_detonation_no_death_event_when_not_fatal():
    effect = ProjectileEffect(base=1, damage_type="fire", speed=10.0, color=(255, 0, 0))
    sys, _, _, _, bus = _make_system()
    deaths = []
    bus.subscribe(EventType.ENTITY_DYING, deaths.append)
    sys.spawn(1, 2, effect)
    sys.tick(1)
    assert len(deaths) == 0


def test_detonation_applies_on_hit_statuses():
    burn = ApplyStatusEffect(status_name="burn", duration=20, tick_damage=3)
    effect = ProjectileEffect(
        base=5,
        damage_type="fire",
        speed=10.0,
        color=(255, 0, 0),
        on_hit_statuses=(burn,),
    )
    sys, _, _, target, _ = _make_system()
    sys.spawn(1, 2, effect)
    sys.tick(1)
    assert any(s.name == "burn" for s in target.status_effects)


# ------------------------------------------------------------------
# homing
# ------------------------------------------------------------------


def test_homing_projectile_follows_moving_target():
    sys, game_map, _, target, _ = _make_system()
    effect = ProjectileEffect(base=5, damage_type="fire", speed=1.0, color=(255, 0, 0))
    sys.spawn(1, 2, effect)
    # Move target up one row before tick
    game_map.move_entity(2, 0, -1)
    sys.tick(1)
    p = sys.active_projectiles[0]
    # target is now at (7,4); projectile should have updated target_y
    assert p.target_y == 4


def test_homing_becomes_non_homing_when_target_leaves_map():
    sys, game_map, _, _, _ = _make_system()
    effect = ProjectileEffect(base=5, damage_type="fire", speed=0.5, color=(255, 0, 0))
    sys.spawn(1, 2, effect)
    game_map.remove_entity(2)
    sys.tick(1)
    p = sys.active_projectiles[0]
    assert p.homing is False


# ------------------------------------------------------------------
# multiple projectiles
# ------------------------------------------------------------------


def test_multiple_projectiles_tick_independently():
    sys, _, _, _, _ = _make_system()
    effect = ProjectileEffect(base=1, damage_type="fire", speed=1.0, color=(255, 0, 0))
    sys.spawn(1, 2, effect)
    sys.spawn(1, 2, effect)
    sys.tick(1)
    assert len(sys.active_projectiles) == 2
