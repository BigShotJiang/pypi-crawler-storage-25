import pytest

from faraway_realms.world.commands import (
    CommandParser,
    CommandResolver,
    CommandType,
    make_attack_command,
)


@pytest.fixture
def parser() -> CommandParser:
    return CommandParser()


def test_parse_move_command(parser: CommandParser):
    cmd = parser.parse("/move left")
    assert cmd.command_type == CommandType.MOVE
    assert cmd.actor == "@self"
    assert cmd.args == ("left",)


@pytest.mark.parametrize("direction", ["left", "right", "up", "down"])
def test_parse_move_all_directions(parser: CommandParser, direction: str):
    cmd = parser.parse(f"/move {direction}")
    assert cmd.command_type == CommandType.MOVE
    assert cmd.args == (direction,)


def test_parse_unknown_command(parser: CommandParser):
    cmd = parser.parse("/foobar")
    assert cmd.command_type == CommandType.UNKNOWN


def test_parse_non_slash_string(parser: CommandParser):
    cmd = parser.parse("hello world")
    assert cmd.command_type == CommandType.UNKNOWN


def test_parse_empty_string(parser: CommandParser):
    cmd = parser.parse("")
    assert cmd.command_type == CommandType.UNKNOWN


def test_command_is_frozen(parser: CommandParser):
    cmd = parser.parse("/move left")
    with pytest.raises(AttributeError):
        cmd.actor = "other"  # type: ignore[misc]


def test_make_attack_command_raw_format():
    cmd = make_attack_command(1, 2)
    assert cmd.raw == "/attack 1 2"
    assert cmd.actor == "1"
    assert cmd.args == ("2",)
    assert cmd.command_type == CommandType.ATTACK


def test_make_attack_command_opportunity_attack():
    cmd = make_attack_command(3, 7, CommandType.OPPORTUNITY_ATTACK)
    assert cmd.command_type == CommandType.OPPORTUNITY_ATTACK
    assert cmd.raw == "/opportunity_attack 3 7"


# ---------------------------------------------------------------------------
# CommandResolver
# ---------------------------------------------------------------------------


@pytest.fixture
def resolver() -> CommandResolver:
    return CommandResolver(actor_id=42)


def test_resolver_replaces_self_in_actor(resolver, parser):
    cmd = resolver.resolve(parser.parse("/move left"))
    assert cmd.actor == "42"
    assert cmd.args == ("left",)


def test_resolver_replaces_self_in_args(resolver, parser):
    cmd = resolver.resolve(parser.parse("/cast second_wind @self"))
    assert cmd.actor == "42"
    assert cmd.args == ("second_wind", "42")


def test_resolver_leaves_numeric_actor_unchanged(resolver, parser):
    cmd = resolver.resolve(parser.parse("/move 99 right"))
    assert cmd.actor == "99"


def test_resolver_leaves_at_target_unchanged(resolver, parser):
    cmd = resolver.resolve(parser.parse("/cast kick @target"))
    assert cmd.args == ("kick", "@target")


def test_resolver_replaces_only_self_not_substrings(resolver, parser):
    # "zombie" contains no @self token — only exact "@self" is expanded
    cmd = resolver.resolve(parser.parse("/spawn zombie 5,5"))
    assert cmd.actor == "42"
    assert cmd.args == ("zombie", "5,5")


def test_resolver_preserves_command_type(resolver, parser):
    cmd = resolver.resolve(parser.parse("/move up"))
    assert cmd.command_type == CommandType.MOVE


def test_resolver_different_actor_ids():
    r1 = CommandResolver(1)
    r2 = CommandResolver(1001)
    parser = CommandParser()
    assert r1.resolve(parser.parse("/move left")).actor == "1"
    assert r2.resolve(parser.parse("/move left")).actor == "1001"
