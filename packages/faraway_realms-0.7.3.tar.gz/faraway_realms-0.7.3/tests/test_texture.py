"""Tests for the noise texture pass."""

import random

from faraway_realms.mapgen import CaveGenerator, NoiseTexturePass
from faraway_realms.mapgen.texture import (
    MOSS_OVERLAY,
    TILE_OVERLAY_REGISTRY,
    TILE_TYPE_PATCH_REGISTRY,
    TileOverlay,
    TileTypePatch,
    _blend_overlay_tile,
    _clamp,
    _overlay_tile,
    _patch_tile,
    _shift_color,
    _shifted_tile,
)
from faraway_realms.world.tile import TILE_REGISTRY, cave_floor_tile, cave_wall_tile


def _gen(seed=42):
    rng = random.Random(seed)
    result = CaveGenerator().generate(60, 40, rng)
    return result, rng


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------


def test_shifted_tile_lightens_with_high_v():
    tile = cave_floor_tile()
    shifted = _shifted_tile(tile, 1.0, 0.2)
    assert shifted.bg_color[0] > tile.bg_color[0]


def test_shifted_tile_darkens_with_low_v():
    tile = cave_floor_tile()
    shifted = _shifted_tile(tile, 0.0, 0.2)
    assert shifted.bg_color[0] < tile.bg_color[0]


def test_shifted_tile_zero_strength_no_change():
    tile = cave_floor_tile()
    shifted = _shifted_tile(tile, 0.8, 0.0)
    assert shifted.bg_color == tile.bg_color
    assert shifted.fg_color == tile.fg_color


def test_shifted_tile_preserves_walkability():
    floor = cave_floor_tile()
    wall = cave_wall_tile()
    assert _shifted_tile(floor, 0.9, 0.3).walkable is True
    assert _shifted_tile(wall, 0.9, 0.3).walkable is False


def test_shifted_tile_clamps_channels():
    """Channels must never go below 0 or above 255."""
    tile = cave_floor_tile()
    high = _shifted_tile(tile, 1.0, 1.0)
    low = _shifted_tile(tile, 0.0, 1.0)
    for ch in high.bg_color + low.bg_color:
        assert 0 <= ch <= 255


def test_overlay_tile_floor_is_walkable():
    result = _overlay_tile(cave_floor_tile(), MOSS_OVERLAY)
    assert result.walkable is True


def test_overlay_tile_wall_is_not_walkable():
    result = _overlay_tile(cave_wall_tile(), MOSS_OVERLAY)
    assert result.walkable is False


def test_overlay_tile_floor_uses_overlay_colors():
    result = _overlay_tile(cave_floor_tile(), MOSS_OVERLAY)
    assert result.bg_color == MOSS_OVERLAY.floor_bg
    assert result.fg_color == MOSS_OVERLAY.floor_fg


def test_overlay_tile_wall_uses_overlay_colors():
    result = _overlay_tile(cave_wall_tile(), MOSS_OVERLAY)
    assert result.bg_color == MOSS_OVERLAY.wall_bg
    assert result.fg_color == MOSS_OVERLAY.wall_fg


def test_moss_overlay_floor_is_greenish():
    r, g, b = MOSS_OVERLAY.floor_bg
    assert g > r and g > b


# ---------------------------------------------------------------------------
# _blend_overlay_tile
# ---------------------------------------------------------------------------


def test_blend_overlay_tile_at_zero_returns_base():
    tile = cave_floor_tile()
    result = _blend_overlay_tile(tile, MOSS_OVERLAY, 0.0)
    assert result.bg_color == tile.bg_color
    assert result.fg_color == tile.fg_color


def test_blend_overlay_tile_at_one_returns_overlay():
    tile = cave_floor_tile()
    result = _blend_overlay_tile(tile, MOSS_OVERLAY, 1.0)
    assert result.bg_color == MOSS_OVERLAY.floor_bg
    assert result.fg_color == MOSS_OVERLAY.floor_fg


def test_blend_overlay_tile_midpoint_is_between():
    tile = cave_floor_tile()
    base_r = tile.bg_color[0]
    overlay_r = MOSS_OVERLAY.floor_bg[0]
    mid_r = _blend_overlay_tile(tile, MOSS_OVERLAY, 0.5).bg_color[0]
    lo, hi = min(base_r, overlay_r), max(base_r, overlay_r)
    assert lo <= mid_r <= hi


def test_blend_overlay_tile_preserves_walkability():
    assert _blend_overlay_tile(cave_floor_tile(), MOSS_OVERLAY, 0.5).walkable is True
    assert _blend_overlay_tile(cave_wall_tile(), MOSS_OVERLAY, 0.5).walkable is False


def test_blend_overlay_tile_wall_uses_wall_colors():
    tile = cave_wall_tile()
    result = _blend_overlay_tile(tile, MOSS_OVERLAY, 1.0)
    assert result.bg_color == MOSS_OVERLAY.wall_bg


# ---------------------------------------------------------------------------
# NoiseTexturePass — basic behaviour
# ---------------------------------------------------------------------------


def test_texture_pass_changes_tile_colors():
    result, rng = _gen()
    original = [
        result.map.get_tile(x, y).bg_color for y in range(2, 10) for x in range(2, 10)
    ]
    NoiseTexturePass(seed=1).apply(result, rng)
    after = [
        result.map.get_tile(x, y).bg_color for y in range(2, 10) for x in range(2, 10)
    ]
    assert original != after


def test_texture_pass_preserves_walkability():
    result, rng = _gen()
    walkable_before = {
        (x, y): result.map.is_walkable(x, y)
        for y in range(result.map.height)
        for x in range(result.map.width)
    }
    NoiseTexturePass(seed=1).apply(result, rng)
    for (x, y), was_walkable in walkable_before.items():
        assert result.map.is_walkable(x, y) == was_walkable, (
            f"walkability changed at ({x}, {y})"
        )


def test_texture_pass_player_start_still_walkable():
    result, rng = _gen()
    NoiseTexturePass(seed=1).apply(result, rng)
    x, y = result.player_start
    assert result.map.is_walkable(x, y)


def test_texture_pass_overlay_appears_with_low_threshold():
    """With threshold=0 every tile should be covered by the first overlay."""
    always_on = TileOverlay(
        floor_bg=MOSS_OVERLAY.floor_bg,
        floor_fg=MOSS_OVERLAY.floor_fg,
        wall_bg=MOSS_OVERLAY.wall_bg,
        wall_fg=MOSS_OVERLAY.wall_fg,
        threshold=0.0,
        noise_offset=0.0,
    )
    result, rng = _gen()
    px, py = result.player_start
    NoiseTexturePass(seed=1, overlays=(always_on,), patches=()).apply(result, rng)
    assert result.map.get_tile(px, py).bg_color == always_on.floor_bg


def test_texture_pass_no_overlay_with_high_threshold():
    """With threshold > 1 no tile should get an overlay."""
    never_on = TileOverlay(
        floor_bg=MOSS_OVERLAY.floor_bg,
        floor_fg=MOSS_OVERLAY.floor_fg,
        wall_bg=MOSS_OVERLAY.wall_bg,
        wall_fg=MOSS_OVERLAY.wall_fg,
        threshold=1.1,
        noise_offset=0.0,
    )
    result, rng = _gen()
    px, py = result.player_start
    original_bg = result.map.get_tile(px, py).bg_color
    NoiseTexturePass(seed=1, overlays=(never_on,), patches=()).apply(result, rng)
    assert result.map.get_tile(px, py).bg_color != never_on.floor_bg
    assert result.map.get_tile(px, py).bg_color != original_bg


def test_texture_pass_deterministic_with_explicit_seed():
    result1, rng1 = _gen(seed=10)
    result2, rng2 = _gen(seed=10)
    NoiseTexturePass(seed=99).apply(result1, rng1)
    NoiseTexturePass(seed=99).apply(result2, rng2)
    for y in range(result1.map.height):
        for x in range(result1.map.width):
            t1 = result1.map.get_tile(x, y).bg_color
            t2 = result2.map.get_tile(x, y).bg_color
            assert t1 == t2


def test_texture_pass_rng_derived_seed_is_deterministic():
    """seed=0 uses rng; same generation seed → same texture."""
    result1, rng1 = _gen(seed=7)
    result2, rng2 = _gen(seed=7)
    NoiseTexturePass(seed=0).apply(result1, rng1)
    NoiseTexturePass(seed=0).apply(result2, rng2)
    for y in range(result1.map.height):
        for x in range(result1.map.width):
            t1 = result1.map.get_tile(x, y).bg_color
            t2 = result2.map.get_tile(x, y).bg_color
            assert t1 == t2


def test_texture_pass_zero_strength_only_overlay_changes():
    """strength=0 means no colour shift; only overlay tiles should differ."""
    always_on = TileOverlay(
        floor_bg=MOSS_OVERLAY.floor_bg,
        floor_fg=MOSS_OVERLAY.floor_fg,
        wall_bg=MOSS_OVERLAY.wall_bg,
        wall_fg=MOSS_OVERLAY.wall_fg,
        threshold=0.0,
        noise_offset=0.0,
    )
    result, rng = _gen()
    px, py = result.player_start
    NoiseTexturePass(seed=1, strength=0.0, overlays=(always_on,), patches=()).apply(
        result, rng
    )
    assert result.map.get_tile(px, py).bg_color == always_on.floor_bg


def test_texture_pass_blend_produces_gradient():
    """blend=True overlay should yield more than two distinct bg colours."""
    always_blend = TileOverlay(
        floor_bg=(0, 200, 0),
        floor_fg=(0, 100, 0),
        wall_bg=(0, 80, 0),
        wall_fg=(0, 40, 0),
        threshold=0.0,
        noise_offset=0.0,
        blend=True,
    )
    result, rng = _gen()
    NoiseTexturePass(seed=1, overlays=(always_blend,), patches=()).apply(result, rng)
    floor_greens = {
        result.map.get_tile(x, y).bg_color[1]
        for y in range(result.map.height)
        for x in range(result.map.width)
        if result.map.is_walkable(x, y)
    }
    # A proper gradient produces many distinct green-channel values, not just two
    assert len(floor_greens) > 5


def test_texture_pass_blend_fades_into_base_overlay():
    """Blended overlay at low factor should reveal the non-blended base below it."""
    base_ov = TileOverlay(
        floor_bg=(0, 0, 200),
        floor_fg=(0, 0, 100),
        wall_bg=(0, 0, 80),
        wall_fg=(0, 0, 40),
        threshold=0.0,  # covers every cell
        noise_offset=500.0,
        blend=False,
    )
    top_ov = TileOverlay(
        floor_bg=(200, 0, 0),
        floor_fg=(100, 0, 0),
        wall_bg=(80, 0, 0),
        wall_fg=(40, 0, 0),
        threshold=0.0,
        noise_offset=0.0,
        blend=True,
    )
    result, rng = _gen()
    NoiseTexturePass(seed=1, overlays=(base_ov, top_ov), patches=()).apply(result, rng)
    px, py = result.player_start
    tile = result.map.get_tile(px, py)
    # With both thresholds at 0, the red blend-factor varies with noise.
    # The blue channel from base_ov must be present (> 0) — not zeroed out.
    assert tile.bg_color[2] > 0, "base overlay blue channel lost under blended overlay"


def test_texture_pass_two_overlays_are_spatially_distinct():
    """Overlays with different noise_offsets should not coincide everywhere."""
    overlay_a = TileOverlay(
        floor_bg=(0, 255, 0),
        floor_fg=(0, 128, 0),
        wall_bg=(0, 64, 0),
        wall_fg=(0, 32, 0),
        threshold=0.5,
        noise_offset=0.0,
    )
    overlay_b = TileOverlay(
        floor_bg=(0, 0, 255),
        floor_fg=(0, 0, 128),
        wall_bg=(0, 0, 64),
        wall_fg=(0, 0, 32),
        threshold=0.5,
        noise_offset=500.0,
    )
    result, rng = _gen()
    NoiseTexturePass(seed=1, overlays=(overlay_a, overlay_b), patches=()).apply(
        result, rng
    )
    colors = {
        result.map.get_tile(x, y).bg_color
        for y in range(result.map.height)
        for x in range(result.map.width)
    }
    # Both overlay colors and shifted (no-overlay) tiles should appear
    assert overlay_a.floor_bg in colors or overlay_a.wall_bg in colors
    assert overlay_b.floor_bg in colors or overlay_b.wall_bg in colors


# ---------------------------------------------------------------------------
# YAML round-trip — registries
# ---------------------------------------------------------------------------


def test_shipped_yaml_tile_overlay_registry_has_moss():
    assert "moss" in TILE_OVERLAY_REGISTRY


def test_shipped_yaml_moss_overlay_is_blended():
    assert TILE_OVERLAY_REGISTRY["moss"].blend is True


def test_shipped_yaml_moss_overlay_has_description():
    assert TILE_OVERLAY_REGISTRY["moss"].description == "mossy"


def test_shipped_yaml_tile_type_patch_registry_has_gray_rock():
    assert "gray_rock" in TILE_TYPE_PATCH_REGISTRY


def test_shipped_yaml_gray_rock_references_tile_registry():
    patch = TILE_TYPE_PATCH_REGISTRY["gray_rock"]
    assert patch.floor in TILE_REGISTRY
    assert patch.wall in TILE_REGISTRY


def test_shipped_yaml_gray_rock_tile_type_has_description():
    assert TILE_REGISTRY["cave_gray_rock_floor"].description is not None
    assert TILE_REGISTRY["cave_gray_rock_wall"].description is not None


# ---------------------------------------------------------------------------
# TileTypePatch — _patch_tile
# ---------------------------------------------------------------------------


def test_patch_tile_replaces_floor_colors():
    patch = TILE_TYPE_PATCH_REGISTRY["gray_rock"]
    floor = cave_floor_tile()
    result = _patch_tile(floor, patch)
    expected = TILE_REGISTRY[patch.floor]
    assert result.bg_color == expected.bg_color
    assert result.fg_color == expected.fg_color


def test_patch_tile_replaces_wall_colors():
    patch = TILE_TYPE_PATCH_REGISTRY["gray_rock"]
    wall = cave_wall_tile()
    result = _patch_tile(wall, patch)
    expected = TILE_REGISTRY[patch.wall]
    assert result.bg_color == expected.bg_color


def test_patch_tile_preserves_walkability():
    patch = TILE_TYPE_PATCH_REGISTRY["gray_rock"]
    assert _patch_tile(cave_floor_tile(), patch).walkable is True
    assert _patch_tile(cave_wall_tile(), patch).walkable is False


def test_patch_appears_in_texture_pass():
    always_patch = TileTypePatch(
        floor="cave_gray_rock_floor",
        wall="cave_gray_rock_wall",
        threshold=0.0,
        noise_offset=0.0,
    )
    result, rng = _gen()
    px, py = result.player_start
    NoiseTexturePass(seed=1, patches=(always_patch,), overlays=()).apply(result, rng)
    expected_bg = TILE_REGISTRY["cave_gray_rock_floor"].bg_color
    assert result.map.get_tile(px, py).bg_color == expected_bg


# ---------------------------------------------------------------------------
# TileOverlay — description and char fields
# ---------------------------------------------------------------------------


def test_moss_overlay_has_description():
    assert MOSS_OVERLAY.description == "mossy"


def test_overlay_char_none_preserves_tile_char():
    overlay = TileOverlay(
        floor_bg=(0, 100, 0),
        floor_fg=(0, 200, 0),
        wall_bg=(0, 50, 0),
        wall_fg=(0, 80, 0),
        char=None,
    )
    tile = cave_floor_tile()
    result = _overlay_tile(tile, overlay)
    assert result.char == tile.char


def test_overlay_char_overrides_tile_char():
    overlay = TileOverlay(
        floor_bg=(0, 100, 0),
        floor_fg=(0, 200, 0),
        wall_bg=(0, 50, 0),
        wall_fg=(0, 80, 0),
        char=ord(","),
    )
    result = _overlay_tile(cave_floor_tile(), overlay)
    assert result.char == ord(",")


def test_blend_overlay_char_overrides_tile_char():
    overlay = TileOverlay(
        floor_bg=(0, 100, 0),
        floor_fg=(0, 200, 0),
        wall_bg=(0, 50, 0),
        wall_fg=(0, 80, 0),
        blend=True,
        char=ord("'"),
    )
    result = _blend_overlay_tile(cave_floor_tile(), overlay, 0.5)
    assert result.char == ord("'")


# ---------------------------------------------------------------------------
# TileOverlay / TileTypePatch — name field
# ---------------------------------------------------------------------------


def test_tile_overlay_default_name_empty():
    overlay = TileOverlay(
        floor_bg=(0, 100, 0),
        floor_fg=(0, 200, 0),
        wall_bg=(0, 50, 0),
        wall_fg=(0, 80, 0),
    )
    assert overlay.name == ""


def test_tile_type_patch_default_name_empty():
    patch = TileTypePatch(floor="cave_gray_rock_floor", wall="cave_gray_rock_wall")
    assert patch.name == ""


def test_shipped_moss_overlay_has_name():
    assert TILE_OVERLAY_REGISTRY["moss"].name == "moss"


def test_shipped_gray_rock_patch_has_name():
    assert TILE_TYPE_PATCH_REGISTRY["gray_rock"].name == "gray_rock"


# ---------------------------------------------------------------------------
# NoiseTexturePass — tile_zones population
# ---------------------------------------------------------------------------


def test_tile_zones_empty_before_texture_pass():
    result, _ = _gen()
    assert result.tile_zones == {}


def test_tile_zones_populated_after_pass_with_named_overlay():
    named_overlay = TileOverlay(
        floor_bg=(0, 150, 0),
        floor_fg=(0, 255, 0),
        wall_bg=(0, 60, 0),
        wall_fg=(0, 80, 0),
        threshold=0.0,
        noise_offset=0.0,
        name="test_zone",
    )
    result, rng = _gen()
    NoiseTexturePass(seed=1, overlays=(named_overlay,), patches=()).apply(result, rng)
    assert len(result.tile_zones) > 0
    assert all(v == "test_zone" for v in result.tile_zones.values())


def test_tile_zones_not_populated_for_unnamed_overlay():
    unnamed_overlay = TileOverlay(
        floor_bg=(0, 150, 0),
        floor_fg=(0, 255, 0),
        wall_bg=(0, 60, 0),
        wall_fg=(0, 80, 0),
        threshold=0.0,
        noise_offset=0.0,
        name="",
    )
    result, rng = _gen()
    NoiseTexturePass(seed=1, overlays=(unnamed_overlay,), patches=()).apply(result, rng)
    assert result.tile_zones == {}


def test_tile_zones_populated_for_named_patch():
    named_patch = TileTypePatch(
        floor="cave_gray_rock_floor",
        wall="cave_gray_rock_wall",
        threshold=0.0,
        noise_offset=0.0,
        name="rock_zone",
    )
    result, rng = _gen()
    NoiseTexturePass(seed=1, patches=(named_patch,), overlays=()).apply(result, rng)
    assert len(result.tile_zones) > 0
    assert all(v == "rock_zone" for v in result.tile_zones.values())


def test_tile_zones_keys_are_valid_coordinates():
    result, rng = _gen()
    NoiseTexturePass(seed=1).apply(result, rng)
    for x, y in result.tile_zones:
        assert 0 <= x < result.map.width
        assert 0 <= y < result.map.height


def test_tile_zones_blend_overlay_records_zone():
    blend_overlay = TileOverlay(
        floor_bg=(0, 150, 0),
        floor_fg=(0, 255, 0),
        wall_bg=(0, 60, 0),
        wall_fg=(0, 80, 0),
        threshold=0.0,
        noise_offset=0.0,
        blend=True,
        name="blend_zone",
    )
    result, rng = _gen()
    NoiseTexturePass(seed=1, overlays=(blend_overlay,), patches=()).apply(result, rng)
    assert len(result.tile_zones) > 0
    assert all(v == "blend_zone" for v in result.tile_zones.values())


# ---------------------------------------------------------------------------
# _shift_color — channel direction (kills mutmut_5, mutmut_8)
# ---------------------------------------------------------------------------


def test_shift_color_positive_shift_raises_all_channels():
    # Kills mutmut_5/8: green/blue get -shift instead of +shift
    result = _shift_color((100, 100, 100), 20)
    assert result == (120, 120, 120)


def test_shift_color_negative_shift_lowers_all_channels():
    result = _shift_color((100, 100, 100), -20)
    assert result == (80, 80, 80)


def test_shift_color_green_channel_matches_direction():
    # Explicit green-channel check: with shift=+30, index 1 must increase
    r, g, b = _shift_color((50, 80, 50), 30)
    assert g == 110


def test_shift_color_blue_channel_matches_direction():
    # Explicit blue-channel check: with shift=+30, index 2 must increase
    r, g, b = _shift_color((50, 50, 80), 30)
    assert b == 110


# ---------------------------------------------------------------------------
# _shifted_tile — exact formula (kills mutmut_5, mutmut_8, mutmut_9,
#                                 mutmut_13, mutmut_17)
# ---------------------------------------------------------------------------


def test_shifted_tile_exact_scale_factor():
    # Kills mutmut_5 (*2 → /2) and mutmut_8 (*2 → *3):
    # v=0.75, strength=1.0 → shift = int(0.25*2.0*255) = 127
    # ÷2 mutant: int(0.25/2.0*255) = 31   (*3 mutant: int(0.25*3.0*255) = 191)
    from faraway_realms.world.tile import Tile

    tile = Tile(walkable=True, bg_color=(50, 50, 50), fg_color=(50, 50, 50))
    result = _shifted_tile(tile, 0.75, 1.0)
    assert result.bg_color == (177, 177, 177)


def test_shifted_tile_exact_255_divisor():
    # Kills mutmut_9 (255 → 256):
    # v = 0.5 + 1/512, strength=1.0 → f=1/256
    # int(1/256 * 255) = 0;  int(1/256 * 256) = 1
    from faraway_realms.world.tile import Tile

    tile = Tile(walkable=True, bg_color=(100, 100, 100), fg_color=(100, 100, 100))
    result = _shifted_tile(tile, 0.5 + 1 / 512, 1.0)
    assert result.bg_color == (100, 100, 100)


def test_shifted_tile_preserves_char():
    # Kills mutmut_13 (char=tile.char → char=None) and mutmut_17 (removes char kwarg)
    from faraway_realms.world.tile import Tile

    tile = Tile(
        walkable=True, bg_color=(50, 50, 50), fg_color=(50, 50, 50), char=ord("@")
    )
    assert _shifted_tile(tile, 0.7, 0.2).char == ord("@")


# ---------------------------------------------------------------------------
# _blend_overlay_tile — wall fg_color (kills mutmut_26)
# ---------------------------------------------------------------------------


def test_blend_overlay_tile_wall_fg_color_is_not_none():
    # Kills mutmut_26: fg_color=_lerp_color(...) → fg_color=None on wall branch
    result = _blend_overlay_tile(cave_wall_tile(), MOSS_OVERLAY, 0.5)
    assert result.fg_color is not None
    assert len(result.fg_color) == 3


# ---------------------------------------------------------------------------
# _clamp — lower bound (kills mutmut_5: max(0,…) → max(1,…))
# ---------------------------------------------------------------------------


def test_clamp_zero_for_negative():
    # Kills mutmut_5: max(1,...) would return 1 here instead of 0
    assert _clamp(-10) == 0


def test_clamp_zero_for_exactly_zero():
    assert _clamp(0) == 0


# ---------------------------------------------------------------------------
# _patch_tile — char preserved (kills mutmut_6: char=tt.char → char=None)
# ---------------------------------------------------------------------------


def test_patch_tile_preserves_char_from_registry():
    # Kills mutmut_6: char=None would produce default instead of registry char
    patch = TileTypePatch(
        floor="cave_gray_rock_floor",
        wall="cave_gray_rock_wall",
        threshold=0.0,
        noise_offset=0.0,
    )
    result = _patch_tile(cave_floor_tile(), patch)
    assert result.char == TILE_REGISTRY["cave_gray_rock_floor"].char


# ---------------------------------------------------------------------------
# _overlay_tile — wall char (kills mutmut_19: removes char= from wall branch)
# ---------------------------------------------------------------------------


def test_overlay_tile_wall_applies_overlay_char():
    # Kills mutmut_19: wall branch missing char= would default to tile.char
    overlay = TileOverlay(
        floor_bg=(0, 150, 0),
        floor_fg=(0, 255, 0),
        wall_bg=(0, 60, 0),
        wall_fg=(0, 80, 0),
        char=ord("+"),
    )
    result = _overlay_tile(cave_wall_tile(), overlay)
    assert result.char == ord("+")


# ---------------------------------------------------------------------------
# _blend_overlay_tile — wall char (kills mutmut_31: removes char= from wall)
# ---------------------------------------------------------------------------


def test_blend_overlay_tile_wall_applies_overlay_char():
    # Kills mutmut_31: wall branch missing char= would use default char
    overlay = TileOverlay(
        floor_bg=(0, 150, 0),
        floor_fg=(0, 255, 0),
        wall_bg=(0, 60, 0),
        wall_fg=(0, 80, 0),
        char=ord("+"),
    )
    result = _blend_overlay_tile(cave_wall_tile(), overlay, 0.5)
    assert result.char == ord("+")
