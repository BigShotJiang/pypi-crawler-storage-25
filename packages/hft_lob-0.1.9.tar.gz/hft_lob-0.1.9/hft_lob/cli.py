import os
import sys
import subprocess


def get_binary_path():
    pkg_dir = os.path.dirname(os.path.abspath(__file__))
    bin_name = "orderbook-linux-x86_64"
    return os.path.join(pkg_dir, "bin", bin_name)


def get_lob_for_token(file_path, token):
    binpath = get_binary_path()
    if not os.path.isfile(binpath):
        raise FileNotFoundError(f"Rust binary not found at {binpath}")
    result = subprocess.run([binpath, file_path, str(token)], capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(result.stderr)
    return result.stdout


class Reader:
    def __init__(self, file_path, tokens):
        """
        Args:
            file_path: path to binary data file
            tokens: a single token (int) or a list of tokens
        """
        binpath = get_binary_path()
        if not os.path.isfile(binpath):
            raise FileNotFoundError(f"Rust binary not found at {binpath}")
        if not os.path.isfile(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")
        if isinstance(tokens, (int, str)):
            tokens = [tokens]
        self.header = None
        self._messages = []
        for token in tokens:
            result = subprocess.run([binpath, file_path, str(token)], capture_output=True, text=True)
            if result.returncode != 0:
                raise RuntimeError(f"Token {token}: {result.stderr}")
            lines = result.stdout.strip().splitlines()
            if not lines:
                continue
            # Extract header from first token only
            if not lines[0][0].isdigit():
                if self.header is None:
                    self.header = lines[0]
                self._messages.extend(lines[1:])
            else:
                self._messages.extend(lines)
        self._index = 0
        self._eof = len(self._messages) == 0

    def get_all_messages(self):
        """Returns all LOB messages as a list of CSV strings."""
        self._eof = True
        return self._messages

    def get_next_message(self):
        """Returns the next LOB message as a CSV string, or None if EOF."""
        if self._index < len(self._messages):
            msg = self._messages[self._index]
            self._index += 1
            if self._index >= len(self._messages):
                self._eof = True
            return msg
        self._eof = True
        return None

    def is_end_of_file(self):
        """Returns True if all messages have been read."""
        return self._eof

    def close(self):
        pass  # No file handle to close; Rust binary was run as subprocess


def main():
    binpath = get_binary_path()
    if not os.path.isfile(binpath):
        sys.stderr.write(f"Error: Rust binary not found at {binpath}\n")
        sys.exit(1)
    sys.exit(subprocess.call([binpath] + sys.argv[1:]))
