from setuptools import setup, find_packages
import os

with open(os.path.join(os.path.dirname(__file__), "README.md"), encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="hft_lob",
    version="0.1.9",
    description="Python wrapper for a high-performance Rust orderbook CLI.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Pratima Kumari",
    author_email="pratima.kumari@example.com",
    url="https://github.com/pratima/hft_lob",
    packages=find_packages(),
    package_data={"hft_lob": ["bin/orderbook-linux-x86_64"]},
    include_package_data=True,
    entry_points={
        "console_scripts": [
            "hft_lob = hft_lob.cli:main",
        ],
    },
    install_requires=[],
    python_requires=">=3.7",
    zip_safe=False,
)