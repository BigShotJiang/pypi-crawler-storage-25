"""CATAPA Private Python Client - Main Wrapper Class.

This module provides an ergonomic wrapper around the CATAPA Private API
with automatic authentication and session management.

Authors:
    Handrian Alandi (handrian.alandi@gdplabs.id)

References:
    NONE
"""

from catapa_private.auth.catapa_private_auth import CatapaPrivateConfig
from catapa_private.session_client import SessionClient


class CatapaPrivate(SessionClient):
    """Main CATAPA Private wrapper class providing access to CATAPA Private API with automatic authentication.

    This wrapper provides a clean interface to all CATAPA Private API endpoints
    with automatic authentication and session management.

    Features:
    - Automatic session-based authentication with username/password
    - Direct bearer-token authentication with access_token
    - Session cookies (SESSION-{tenant} and XSRF-TOKEN) are managed automatically
    - Thread-safe session management
    - No need to re-authenticate after session expiration (auto-refresh)
    - Simple, intuitive API for making authenticated requests

    Attributes:
        config (CatapaPrivateConfig): Configuration for CATAPA Private API authentication.

    Example:
        # Initialize the client
        client = CatapaPrivate(
            tenant="your-tenant",
            username="your-username",
            password="your-password"
        )

        # Initialize with an existing access token
        client = CatapaPrivate(
            tenant="your-tenant",
            access_token="your-access-token"
        )

        # Make authenticated requests
        response = client.get("/timemanagement/attendance-statuses", params={"query": "(code:CUTPOT)"})
        data = response.json()

        # POST request
        response = client.post(
            "/timemanagement/jobs/missing-attendance-process",
            json={
                "attendanceStatusInId": "status-id",
                "startDate": "2025-01-01",
                "endDate": "2025-01-31"
            }
        )
    """

    def __init__(  # noqa: PLR0913
        self,
        *,
        tenant: str,
        username: str | None = None,
        password: str | None = None,
        base_url: str = "https://api.catapa.com",
        timeout: int = 30,
        access_token: str | None = None,
    ) -> None:
        """Initialize the CATAPA Private client.

        Args:
            tenant (str): CATAPA tenant identifier.
            username (str | None, optional): Username for authentication.
            password (str | None, optional): Password for authentication.
            access_token (str | None, optional): Access token for direct bearer-token authentication.
            base_url (str, optional): Base URL for the CATAPA API. Defaults to "https://api.catapa.com".
            timeout (int, optional): Timeout for HTTP requests in seconds. Defaults to 30.
        """
        config = CatapaPrivateConfig(
            base_url=base_url,
            tenant=tenant,
            username=username,
            password=password,
            access_token=access_token,
            timeout=timeout,
        )
        super().__init__(config)
        self.config = config
