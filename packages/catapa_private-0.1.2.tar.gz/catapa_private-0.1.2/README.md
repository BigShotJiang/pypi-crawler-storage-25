# CATAPA Private Python SDK

A Python client library for the CATAPA Private API with session-based authentication.

## Documentation

📚 **Full documentation, tutorials, and API reference:**

**[https://gdplabs.gitbook.io/catapa/developer-documentation/hris-private-api](https://gdplabs.gitbook.io/catapa/developer-documentation/hris-private-api)**
