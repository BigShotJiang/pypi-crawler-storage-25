from datetime import datetime, timezone
from unittest.mock import AsyncMock, patch

import pytest

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBProject, DBSession
from hypergolic.dispatch.conclude import (
    ConcludeInput,
    _handle_conclude,
    _set_concluded_at,
)
from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.tools.schemas import ToolContext


def _seed(sid="s1", parent_id=None):
    with get_db() as db:
        if not db.get(DBProject, "p1"):
            db.add(DBProject(id="p1", name="Proj", path="/tmp/p"))
        if parent_id and not db.get(DBSession, parent_id):
            db.add(DBSession(
                id=parent_id, model_tier="Medium", system_prompt=[], project_id="p1",
            ))
        db.add(DBSession(
            id=sid, model_tier="Medium", system_prompt=[], project_id="p1",
            parent_id=parent_id,
        ))


def _make_session(sid="s1", parent_id=None):
    return Session(
        id=sid,
        model_tier=ModelTier.MEDIUM,
        project_id="p1",
        project_path="/tmp/p",
        parent_id=parent_id,
    )


def _make_ctx(session, broadcast=None):
    return ToolContext(
        session=session,
        broadcast=broadcast or AsyncMock(),
        tool_id="conclude",
    )


def test_set_concluded_at_writes_to_db():
    _seed()
    with get_db() as db:
        row = db.get(DBSession, "s1")
        assert row is not None
        assert row.concluded_at is None

    result = _set_concluded_at("s1")

    assert isinstance(result, datetime)
    assert result.tzinfo is not None
    with get_db() as db:
        row = db.get(DBSession, "s1")
        assert row is not None
        assert row.concluded_at is not None


@pytest.mark.asyncio
async def test_conclude_resolved_sets_concluded_at_and_schedules_retrospective():
    _seed("child", parent_id="parent")
    session = _make_session("child", parent_id="parent")
    broadcast = AsyncMock()
    ctx = _make_ctx(session, broadcast)
    inp = ConcludeInput(outcome="success", conclusion="Done")

    with (
        patch("hypergolic.dispatch.conclude.resolve_dispatch", return_value=True),
        patch("hypergolic.dispatch.conclude.set_session_status_and_broadcast", new=AsyncMock()) as mock_status,
        patch("hypergolic.dispatch.conclude.schedule_retrospective") as mock_retro,
        patch("hypergolic.dispatch.conclude._set_concluded_at", return_value=datetime.now(timezone.utc)) as mock_concluded,
    ):
        output = await _handle_conclude(inp, ctx)

    assert not output.is_error
    text_block: dict = output.content[0]  # type: ignore[assignment]
    assert "success" in text_block["text"]
    mock_status.assert_called_once()
    mock_concluded.assert_called_once_with("child")
    mock_retro.assert_called_once_with("child", broadcast)

    # dispatch_concluded event should be broadcast
    assert broadcast.call_count == 1
    event = broadcast.call_args[0][0]
    assert event.type == "dispatch_concluded"


@pytest.mark.asyncio
async def test_conclude_not_resolved_with_parent_still_concludes():
    _seed("child", parent_id="parent")
    session = _make_session("child", parent_id="parent")
    broadcast = AsyncMock()
    ctx = _make_ctx(session, broadcast)
    inp = ConcludeInput(outcome="failure", conclusion="Could not finish")

    with (
        patch("hypergolic.dispatch.conclude.resolve_dispatch", return_value=False),
        patch("hypergolic.dispatch.conclude.set_session_status_and_broadcast", new=AsyncMock()) as mock_status,
        patch("hypergolic.dispatch.conclude.schedule_retrospective") as mock_retro,
        patch("hypergolic.dispatch.conclude._set_concluded_at", return_value=datetime.now(timezone.utc)) as mock_concluded,
    ):
        output = await _handle_conclude(inp, ctx)

    assert not output.is_error
    text_block: dict = output.content[0]  # type: ignore[assignment]
    assert "failure" in text_block["text"]
    mock_status.assert_called_once()
    mock_concluded.assert_called_once_with("child")
    mock_retro.assert_called_once_with("child", broadcast)


@pytest.mark.asyncio
async def test_conclude_not_resolved_no_parent_returns_error():
    _seed("orphan")
    session = _make_session("orphan", parent_id=None)
    broadcast = AsyncMock()
    ctx = _make_ctx(session, broadcast)
    inp = ConcludeInput(outcome="success", conclusion="Done")

    with (
        patch("hypergolic.dispatch.conclude.resolve_dispatch", return_value=False),
        patch("hypergolic.dispatch.conclude.set_session_status_and_broadcast", new=AsyncMock()) as mock_status,
        patch("hypergolic.dispatch.conclude.schedule_retrospective") as mock_retro,
    ):
        output = await _handle_conclude(inp, ctx)

    assert output.is_error
    text_block: dict = output.content[0]  # type: ignore[assignment]
    assert "No pending dispatch" in text_block["text"]
    mock_status.assert_not_called()
    mock_retro.assert_not_called()


@pytest.mark.asyncio
async def test_conclude_resolved_no_parent_no_dispatch_concluded_event():
    """When resolved but no parent_id, dispatch_concluded event is not broadcast."""
    _seed("orphan")
    session = _make_session("orphan", parent_id=None)
    broadcast = AsyncMock()
    ctx = _make_ctx(session, broadcast)
    inp = ConcludeInput(outcome="success", conclusion="Done")

    with (
        patch("hypergolic.dispatch.conclude.resolve_dispatch", return_value=True),
        patch("hypergolic.dispatch.conclude.set_session_status_and_broadcast", new=AsyncMock()),
        patch("hypergolic.dispatch.conclude.schedule_retrospective"),
        patch("hypergolic.dispatch.conclude._set_concluded_at", return_value=datetime.now(timezone.utc)),
    ):
        output = await _handle_conclude(inp, ctx)

    assert not output.is_error
    # broadcast should NOT have been called (no parent → no dispatch_concluded)
    broadcast.assert_not_called()
