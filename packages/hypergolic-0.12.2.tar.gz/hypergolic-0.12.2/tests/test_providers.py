from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from hypergolic.enums import ModelTier
from hypergolic.providers import generate_text


@pytest.mark.asyncio
async def test_generate_text_returns_text():
    mock_block = MagicMock()
    mock_block.type = "text"
    mock_block.text = "Hello world"
    mock_response = MagicMock()
    mock_response.content = [mock_block]

    with patch("hypergolic.providers.create_client") as mock_client:
        mock_client.return_value.messages.create = AsyncMock(return_value=mock_response)
        result = await generate_text(
            system="You are helpful.",
            messages=[{"role": "user", "content": "Hi"}],
            max_tokens=100,
        )

    assert result == "Hello world"
    call_kwargs = mock_client.return_value.messages.create.call_args[1]
    assert call_kwargs["system"] == "You are helpful."
    assert call_kwargs["max_tokens"] == 100
    assert call_kwargs["messages"] == [{"role": "user", "content": "Hi"}]


@pytest.mark.asyncio
async def test_generate_text_returns_none_on_empty_response():
    mock_response = MagicMock()
    mock_response.content = []

    with patch("hypergolic.providers.create_client") as mock_client:
        mock_client.return_value.messages.create = AsyncMock(return_value=mock_response)
        result = await generate_text(
            system="sys",
            messages=[{"role": "user", "content": "Hi"}],
            max_tokens=100,
        )

    assert result is None


@pytest.mark.asyncio
async def test_generate_text_returns_none_on_whitespace_only():
    mock_block = MagicMock()
    mock_block.type = "text"
    mock_block.text = "   \n  "
    mock_response = MagicMock()
    mock_response.content = [mock_block]

    with patch("hypergolic.providers.create_client") as mock_client:
        mock_client.return_value.messages.create = AsyncMock(return_value=mock_response)
        result = await generate_text(
            system="sys",
            messages=[{"role": "user", "content": "Hi"}],
            max_tokens=100,
        )

    assert result is None


@pytest.mark.asyncio
async def test_generate_text_uses_model_tier():
    mock_block = MagicMock()
    mock_block.type = "text"
    mock_block.text = "result"
    mock_response = MagicMock()
    mock_response.content = [mock_block]

    with patch("hypergolic.providers.create_client") as mock_client:
        mock_client.return_value.messages.create = AsyncMock(return_value=mock_response)
        await generate_text(
            system="sys",
            messages=[{"role": "user", "content": "Hi"}],
            max_tokens=100,
            model_tier=ModelTier.HIGH,
        )

    call_kwargs = mock_client.return_value.messages.create.call_args[1]
    assert call_kwargs["model"] == "claude-opus-4-6"
