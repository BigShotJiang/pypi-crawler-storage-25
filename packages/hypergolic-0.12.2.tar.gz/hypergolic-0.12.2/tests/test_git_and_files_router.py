"""Integration tests for git, files, and attachments routers."""

from pathlib import Path
from unittest.mock import patch

import pytest

from hypergolic.git.operations import GitCommandError
from hypergolic.git.schemas import (
    ChangedFile,
    GitCommitDetailResponse,
    GitDiffResponse,
    GitLogEntry,
    GitLogResponse,
    GitStatusResponse,
)
from hypergolic.files.schemas import FileNode, FileSearchMatch
from tests.conftest import make_project


# ---------------------------------------------------------------------------
# Git router tests
# ---------------------------------------------------------------------------


def test_git_status(api_client):
    status = GitStatusResponse(
        branch="main",
        ahead=1,
        behind=0,
        staged=[ChangedFile(path="a.py", status="M", staged=True, additions=3, deletions=1)],
        unstaged=[ChangedFile(path="b.py", status="M", staged=False, additions=0, deletions=2)],
        untracked=["new.txt"],
    )
    with patch("hypergolic.git.router.get_git_status", return_value=status):
        resp = api_client.get("/api/git/status")
    assert resp.status_code == 200
    data = resp.json()
    assert data["branch"] == "main"
    assert data["ahead"] == 1
    assert len(data["staged"]) == 1
    assert data["staged"][0]["path"] == "a.py"
    assert len(data["unstaged"]) == 1
    assert data["untracked"] == ["new.txt"]


def test_git_diff(api_client):
    diff_resp = GitDiffResponse(path="file.py", diff="--- a/file.py\n+++ b/file.py\n@@ -1 +1 @@")
    with patch("hypergolic.git.router.get_git_diff", return_value=diff_resp):
        resp = api_client.post("/api/git/diff", json={"path": "file.py", "staged": False})
    assert resp.status_code == 200
    data = resp.json()
    assert data["path"] == "file.py"
    assert "---" in data["diff"]


def test_git_stage_success(api_client):
    with patch("hypergolic.git.router.git_stage") as mock_stage:
        resp = api_client.post("/api/git/stage", json={"paths": ["a.py", "b.py"]})
    assert resp.status_code == 200
    assert resp.json() == {"status": "ok"}
    mock_stage.assert_called_once_with(["a.py", "b.py"], repo=None)


def test_git_stage_error(api_client):
    err = GitCommandError(command="add", returncode=128, stderr="fatal: not a git repo", stdout="")
    with patch("hypergolic.git.router.git_stage", side_effect=err):
        resp = api_client.post("/api/git/stage", json={"paths": ["bad.py"]})
    assert resp.status_code == 422
    assert "fatal: not a git repo" in resp.json()["detail"]


def test_git_commit_success(api_client):
    with patch("hypergolic.git.router.git_commit", return_value="[main abc1234] fix stuff"):
        resp = api_client.post("/api/git/commit", json={"message": "fix stuff"})
    assert resp.status_code == 200
    assert resp.json()["output"] == "[main abc1234] fix stuff"


def test_git_commit_error(api_client):
    err = GitCommandError(command="commit", returncode=1, stderr="nothing to commit", stdout="")
    with patch("hypergolic.git.router.git_commit", side_effect=err):
        resp = api_client.post("/api/git/commit", json={"message": "oops"})
    assert resp.status_code == 422
    assert "nothing to commit" in resp.json()["detail"]


def test_git_push_and_pull(api_client):
    with patch("hypergolic.git.router.git_push", return_value="Everything up-to-date"):
        resp = api_client.post("/api/git/push")
    assert resp.status_code == 200
    assert resp.json()["output"] == "Everything up-to-date"

    with patch("hypergolic.git.router.git_pull", return_value="Already up to date."):
        resp = api_client.post("/api/git/pull")
    assert resp.status_code == 200
    assert resp.json()["output"] == "Already up to date."


def test_git_log(api_client):
    log = GitLogResponse(entries=[
        GitLogEntry(
            hash="abc123def456", short_hash="abc123d",
            author="Dev", date="2025-01-01T00:00:00+00:00",
            message="init commit", refs="HEAD -> main",
        ),
    ])
    with patch("hypergolic.git.router.get_git_log", return_value=log):
        resp = api_client.get("/api/git/log?count=10")
    assert resp.status_code == 200
    data = resp.json()
    assert len(data["entries"]) == 1
    assert data["entries"][0]["message"] == "init commit"


def test_git_show_commit(api_client):
    detail = GitCommitDetailResponse(
        hash="abc123def456", short_hash="abc123d",
        author="Dev", date="2025-01-01T00:00:00+00:00",
        message="fix bug", diff="diff --git a/x b/x",
    )
    with patch("hypergolic.git.router.get_git_commit_detail", return_value=detail):
        resp = api_client.get("/api/git/show/abc123def456")
    assert resp.status_code == 200
    data = resp.json()
    assert data["hash"] == "abc123def456"
    assert data["message"] == "fix bug"
    assert "diff" in data["diff"]


def test_git_with_project_id(api_client):
    """Test that project_id resolves to the project's path for git operations."""
    proj = make_project(pid="git-proj", name="GitTest", path="/tmp/gitrepo")
    status = GitStatusResponse(
        branch="dev", ahead=0, behind=0,
        staged=[], unstaged=[], untracked=[],
    )
    with patch("hypergolic.git.router.get_git_status", return_value=status) as mock_status:
        resp = api_client.get("/api/git/status", params={"project_id": "git-proj"})
    assert resp.status_code == 200
    # The resolved path should be passed to the operation
    mock_status.assert_called_once_with(repo=Path("/tmp/gitrepo"))


def test_git_unstage_and_discard(api_client):
    """Cover the unstage and discard endpoints."""
    with patch("hypergolic.git.router.git_unstage") as mock_unstage:
        resp = api_client.post("/api/git/unstage", json={"paths": ["c.py"]})
    assert resp.status_code == 200
    assert resp.json() == {"status": "ok"}
    mock_unstage.assert_called_once_with(["c.py"], repo=None)

    with patch("hypergolic.git.router.git_discard") as mock_discard:
        resp = api_client.post("/api/git/discard", json={"paths": ["d.py"]})
    assert resp.status_code == 200
    assert resp.json() == {"status": "ok"}
    mock_discard.assert_called_once_with(["d.py"], repo=None)


def test_git_unstage_error(api_client):
    err = GitCommandError(command="reset", returncode=128, stderr="fatal: unstage failed", stdout="")
    with patch("hypergolic.git.router.git_unstage", side_effect=err):
        resp = api_client.post("/api/git/unstage", json={"paths": ["bad.py"]})
    assert resp.status_code == 422
    assert "fatal: unstage failed" in resp.json()["detail"]


def test_git_discard_error(api_client):
    err = GitCommandError(command="checkout", returncode=1, stderr="error: discard failed", stdout="")
    with patch("hypergolic.git.router.git_discard", side_effect=err):
        resp = api_client.post("/api/git/discard", json={"paths": ["bad.py"]})
    assert resp.status_code == 422
    assert "error: discard failed" in resp.json()["detail"]


def test_git_pull_error(api_client):
    err = GitCommandError(command="pull", returncode=1, stderr="error: pull failed", stdout="")
    with patch("hypergolic.git.router.git_pull", side_effect=err):
        resp = api_client.post("/api/git/pull")
    assert resp.status_code == 422
    assert "error: pull failed" in resp.json()["detail"]


def test_git_error_detail_fallback(api_client):
    """When stdout and stderr are both empty, _error_detail uses fallback message."""
    err = GitCommandError(command="push", returncode=1, stderr="", stdout="")
    with patch("hypergolic.git.router.git_push", side_effect=err):
        resp = api_client.post("/api/git/push")
    assert resp.status_code == 422
    assert "git push failed (exit 1)" in resp.json()["detail"]


def test_git_project_not_found(api_client):
    """Passing a non-existent project_id returns 404."""
    resp = api_client.get("/api/git/status", params={"project_id": "no-such-proj"})
    assert resp.status_code == 404
    assert "not found" in resp.json()["detail"].lower()


# ---------------------------------------------------------------------------
# Files router tests
# ---------------------------------------------------------------------------


def test_file_tree(api_client):
    tree = [
        FileNode(name="src", path="src", is_dir=True, children=[
            FileNode(name="main.py", path="src/main.py", is_dir=False, git_status="M"),
        ]),
        FileNode(name="README.md", path="README.md", is_dir=False),
    ]
    with (
        patch("hypergolic.files.router.get_repo_root", return_value="/tmp/repo"),
        patch("hypergolic.files.router.build_file_tree", return_value=tree),
    ):
        resp = api_client.get("/api/files/tree")
    assert resp.status_code == 200
    data = resp.json()
    assert data["root"] == "/tmp/repo"
    assert len(data["tree"]) == 2
    assert data["tree"][0]["name"] == "src"
    assert data["tree"][0]["children"][0]["git_status"] == "M"


def test_file_tree_with_project_id(api_client):
    """Test that project_id resolves to the project's path for file tree."""
    make_project(pid="file-proj", name="FileTest", path="/tmp/filerepo")
    tree = [
        FileNode(name="app.py", path="app.py", is_dir=False),
    ]
    with (
        patch("hypergolic.files.router.get_repo_root", return_value="/tmp/filerepo") as mock_root,
        patch("hypergolic.files.router.build_file_tree", return_value=tree) as mock_tree,
    ):
        resp = api_client.get("/api/files/tree", params={"project_id": "file-proj"})
    assert resp.status_code == 200
    data = resp.json()
    assert data["root"] == "/tmp/filerepo"
    assert len(data["tree"]) == 1
    # Verify the resolved project path was passed
    mock_root.assert_called_once_with(Path("/tmp/filerepo"))
    mock_tree.assert_called_once_with(Path("/tmp/filerepo"))


def test_read_file_success(api_client, tmp_path):
    """Create a real file in tmp_path and read it through the endpoint."""
    test_file = tmp_path / "hello.py"
    test_file.write_text("print('hello')\n")

    with patch("hypergolic.files.router.get_repo_root", return_value=str(tmp_path)):
        resp = api_client.get("/api/files/read", params={"path": "hello.py"})
    assert resp.status_code == 200
    data = resp.json()
    assert data["path"] == "hello.py"
    assert data["content"] == "print('hello')\n"
    assert data["language"] == "python"


def test_read_file_not_found(api_client, tmp_path):
    with patch("hypergolic.files.router.get_repo_root", return_value=str(tmp_path)):
        resp = api_client.get("/api/files/read", params={"path": "nonexistent.py"})
    assert resp.status_code == 404
    assert "not found" in resp.json()["detail"].lower()


def test_read_file_path_traversal(api_client, tmp_path):
    # Create a file outside the repo root to verify we can't access it
    with patch("hypergolic.files.router.get_repo_root", return_value=str(tmp_path)):
        resp = api_client.get("/api/files/read", params={"path": "../../../etc/passwd"})
    assert resp.status_code == 403
    assert "denied" in resp.json()["detail"].lower()


def test_file_search(api_client):
    name_matches = [
        FileSearchMatch(path="src/utils.py"),
        FileSearchMatch(path="src/helpers.py"),
    ]
    content_matches = [
        FileSearchMatch(path="src/main.py", line=10, text="import utils"),
    ]
    with (
        patch("hypergolic.files.router.get_repo_root", return_value="/tmp/repo"),
        patch("hypergolic.files.router.search_file_names", return_value=name_matches),
        patch("hypergolic.files.router.search_file_contents", return_value=content_matches),
    ):
        resp = api_client.post("/api/files/search", json={"query": "utils", "mode": "all"})
    assert resp.status_code == 200
    data = resp.json()
    assert len(data["matches"]) == 3


def test_file_search_empty_query(api_client):
    """Empty query returns no matches without calling search operations."""
    resp = api_client.post("/api/files/search", json={"query": "  ", "mode": "files"})
    assert resp.status_code == 200
    assert resp.json()["matches"] == []


def test_read_file_language_detection(api_client, tmp_path):
    """Test _detect_language for various extensions."""
    for filename, expected_lang in [
        ("app.ts", "typescript"),
        ("style.css", "css"),
        ("config.yaml", "yaml"),
        ("Dockerfile", "docker"),
        ("Makefile", "makefile"),
        ("data.xml", "xml"),
        ("unknown.zzz", "text"),
    ]:
        f = tmp_path / filename
        f.write_text("content")
        with patch("hypergolic.files.router.get_repo_root", return_value=str(tmp_path)):
            resp = api_client.get("/api/files/read", params={"path": filename})
        assert resp.status_code == 200, f"Failed for {filename}"
        assert resp.json()["language"] == expected_lang, f"Wrong language for {filename}"


# ---------------------------------------------------------------------------
# Attachments router tests
# ---------------------------------------------------------------------------


def test_upload_image_success(api_client):
    with patch(
        "hypergolic.attachments.router.process_image",
        return_value=("base64encodeddata", "image/png"),
    ):
        resp = api_client.post(
            "/api/attachments/upload",
            files={"file": ("test.png", b"\x89PNG\r\n\x1a\nfakedata", "image/png")},
        )
    assert resp.status_code == 200
    data = resp.json()
    assert data["type"] == "image"
    assert data["source"]["type"] == "base64"
    assert data["source"]["media_type"] == "image/png"
    assert data["source"]["data"] == "base64encodeddata"


def test_upload_unsupported_type(api_client):
    resp = api_client.post(
        "/api/attachments/upload",
        files={"file": ("doc.pdf", b"fake pdf content", "application/pdf")},
    )
    assert resp.status_code == 400
    assert "Unsupported media type" in resp.json()["detail"]


def test_upload_empty_file(api_client):
    resp = api_client.post(
        "/api/attachments/upload",
        files={"file": ("empty.png", b"", "image/png")},
    )
    assert resp.status_code == 400
    assert "Empty file" in resp.json()["detail"]
