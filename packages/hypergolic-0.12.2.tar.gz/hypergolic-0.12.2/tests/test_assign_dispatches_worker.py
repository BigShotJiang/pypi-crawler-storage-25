"""Tests that the assign tool dispatches a worker role."""

import pytest
from unittest.mock import AsyncMock, patch

from hypergolic.base.tools.assign import (
    AssignInput,
    run_assign,
    assign_tool,
    ASSIGN_DISPATCH_PROMPT,
)
from hypergolic.dispatch.core import DispatchResult
from hypergolic.enums import ModelTier
from hypergolic.toolkit.primitives import ToolContext
from hypergolic.schemas import Session


def _make_session() -> Session:
    return Session(
        id="s1",
        model_tier=ModelTier.HIGH,
        project_id="p1",
        project_path="/tmp/test",
        role="generalist",
    )


def _make_ctx(session: Session, broadcast: AsyncMock | None = None) -> ToolContext:
    return ToolContext(
        session=session,
        broadcast=broadcast or AsyncMock(),
        tool_id="assign",
    )


def test_assign_tool_id():
    assert assign_tool.id == "assign"


def test_assign_dispatch_prompt_says_worker():
    assert "worker" in ASSIGN_DISPATCH_PROMPT.lower()


@pytest.mark.asyncio
async def test_assign_dispatches_worker_role():
    session = _make_session()
    broadcast = AsyncMock()
    ctx = _make_ctx(session, broadcast)
    inp = AssignInput(task="Implement the feature")

    with patch("hypergolic.base.tools.assign.dispatch", new=AsyncMock(
        return_value=DispatchResult(outcome="success", conclusion="Done")
    )) as mock_dispatch:
        await run_assign(inp, ctx)

    mock_dispatch.assert_called_once()
    call_kwargs = mock_dispatch.call_args[1]
    assert call_kwargs["role"] == "worker"


@pytest.mark.asyncio
async def test_assign_passes_model_tier():
    session = _make_session()
    ctx = _make_ctx(session)
    inp = AssignInput(task="Do something", model_tier=ModelTier.LOW)

    with patch("hypergolic.base.tools.assign.dispatch", new=AsyncMock(
        return_value=DispatchResult(outcome="success", conclusion="ok")
    )) as mock_dispatch:
        await run_assign(inp, ctx)

    assert mock_dispatch.call_args[1]["model_tier"] == ModelTier.LOW


@pytest.mark.asyncio
async def test_assign_success():
    session = _make_session()
    ctx = _make_ctx(session)
    inp = AssignInput(task="Build it")

    with patch("hypergolic.base.tools.assign.dispatch", new=AsyncMock(
        return_value=DispatchResult(outcome="success", conclusion="All done")
    )):
        result = await run_assign(inp, ctx)

    assert result.outcome == "SUCCESS"
    assert "All done" in result.content[0]["text"]


@pytest.mark.asyncio
async def test_assign_failure():
    session = _make_session()
    ctx = _make_ctx(session)
    inp = AssignInput(task="Build it")

    with patch("hypergolic.base.tools.assign.dispatch", new=AsyncMock(
        return_value=DispatchResult(outcome="failure", conclusion="Couldn't do it")
    )):
        result = await run_assign(inp, ctx)

    assert result.outcome == "FAILURE"
    assert "failed" in result.content[0]["text"].lower()


@pytest.mark.asyncio
async def test_assign_interrupted():
    session = _make_session()
    ctx = _make_ctx(session)
    inp = AssignInput(task="Build it")

    with patch("hypergolic.base.tools.assign.dispatch", new=AsyncMock(
        return_value=DispatchResult(outcome="suppressed", conclusion="interrupted")
    )):
        result = await run_assign(inp, ctx)

    assert result.outcome == "FAILURE"
    assert "interrupted" in result.content[0]["text"].lower()
