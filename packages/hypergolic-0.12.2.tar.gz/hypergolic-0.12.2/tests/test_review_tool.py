"""Tests for the review dispatch tool."""

import pytest
from unittest.mock import AsyncMock, patch

from hypergolic.base.tools.review import (
    ReviewInput,
    run_review,
    review_tool,
    REVIEW_DISPATCH_PROMPT,
)
from hypergolic.dispatch.core import DispatchResult
from hypergolic.enums import ModelTier
from hypergolic.toolkit.primitives import ToolContext
from hypergolic.schemas import Session


def _make_session() -> Session:
    return Session(
        id="s1",
        model_tier=ModelTier.HIGH,
        project_id="p1",
        project_path="/tmp/test",
        role="generalist",
    )


def _make_ctx(session: Session, broadcast: AsyncMock | None = None) -> ToolContext:
    return ToolContext(
        session=session,
        broadcast=broadcast or AsyncMock(),
        tool_id="review",
    )


# --- Tool metadata ---


def test_review_tool_id():
    assert review_tool.id == "review"


def test_review_tool_name():
    assert review_tool.name == "Review"


def test_review_tool_has_diff_source_examples_in_description():
    assert "main..HEAD" in review_tool.description
    assert "HEAD~3" in review_tool.description
    assert "--staged" in review_tool.description


# --- Input schema ---


def test_review_input_has_required_fields():
    inp = ReviewInput(description="test", diff_source="main..HEAD")
    assert inp.description == "test"
    assert inp.diff_source == "main..HEAD"


# --- Dispatch ---


@pytest.mark.asyncio
async def test_review_dispatches_reviewer_role():
    session = _make_session()
    broadcast = AsyncMock()
    ctx = _make_ctx(session, broadcast)
    inp = ReviewInput(description="Check the refactor", diff_source="main..HEAD")

    with patch("hypergolic.base.tools.review.dispatch", new=AsyncMock(
        return_value=DispatchResult(outcome="success", conclusion="LGTM")
    )) as mock_dispatch:
        await run_review(inp, ctx)

    mock_dispatch.assert_called_once()
    call_kwargs = mock_dispatch.call_args[1]
    assert call_kwargs["role"] == "reviewer"
    assert call_kwargs["model_tier"] == ModelTier.HIGH
    assert call_kwargs["parent_session_id"] == "s1"


@pytest.mark.asyncio
async def test_review_passes_description_and_diff_source():
    session = _make_session()
    ctx = _make_ctx(session)
    inp = ReviewInput(description="Review the new feature", diff_source="HEAD~3")

    with patch("hypergolic.base.tools.review.dispatch", new=AsyncMock(
        return_value=DispatchResult(outcome="success", conclusion="ok")
    )) as mock_dispatch:
        await run_review(inp, ctx)

    content_blocks = mock_dispatch.call_args[1]["content_blocks"]
    text = content_blocks[0]["text"]
    assert "Review the new feature" in text
    assert "git diff HEAD~3" in text


@pytest.mark.asyncio
async def test_review_success_returns_conclusion():
    session = _make_session()
    ctx = _make_ctx(session)
    inp = ReviewInput(description="test", diff_source="main..HEAD")

    with patch("hypergolic.base.tools.review.dispatch", new=AsyncMock(
        return_value=DispatchResult(outcome="success", conclusion="All good, APPROVE")
    )):
        result = await run_review(inp, ctx)

    assert result.outcome == "SUCCESS"
    assert "All good, APPROVE" in result.content[0]["text"]


@pytest.mark.asyncio
async def test_review_failure_returns_failure():
    session = _make_session()
    ctx = _make_ctx(session)
    inp = ReviewInput(description="test", diff_source="main..HEAD")

    with patch("hypergolic.base.tools.review.dispatch", new=AsyncMock(
        return_value=DispatchResult(outcome="failure", conclusion="Could not read diff")
    )):
        result = await run_review(inp, ctx)

    assert result.outcome == "FAILURE"
    assert "Review failed" in result.content[0]["text"]


@pytest.mark.asyncio
async def test_review_interrupted_returns_failure():
    session = _make_session()
    ctx = _make_ctx(session)
    inp = ReviewInput(description="test", diff_source="main..HEAD")

    with patch("hypergolic.base.tools.review.dispatch", new=AsyncMock(
        return_value=DispatchResult(outcome="suppressed", conclusion="Parent interrupted")
    )):
        result = await run_review(inp, ctx)

    assert result.outcome == "FAILURE"
    assert "interrupted" in result.content[0]["text"]


def test_review_dispatch_prompt_mentions_git_diff():
    assert "git diff" in REVIEW_DISPATCH_PROMPT
