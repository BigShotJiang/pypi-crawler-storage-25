"""Tests for role-scoped tool architecture.

Verifies that each role gets only its declared tools plus universal (app-level)
tools, and that dispatch tools send the correct role.
"""

import pytest
from unittest.mock import patch

from hypergolic.base.roles.registry import (
    ALL_BASE_ROLES,
    generalist_role,
    worker_role,
    reviewer_role,
    researcher_role,
)
from hypergolic.base.tools.registry import UNIVERSAL_TOOLS
from hypergolic.enums import ModelTier
from hypergolic.toolkit.app.core import App
from hypergolic.toolkit.app.state import set_app
from hypergolic.schemas import Session


def _make_app() -> App:
    app = App()
    app.register_tools(UNIVERSAL_TOOLS)
    app.register_roles(ALL_BASE_ROLES)
    set_app(app)
    return app


def _make_session(role: str = "generalist") -> Session:
    return Session(
        id="s1",
        model_tier=ModelTier.MEDIUM,
        project_id="p1",
        project_path="/tmp/test",
        role=role,
    )


UNIVERSAL_IDS = {t.id for t in UNIVERSAL_TOOLS}


# --- Role declarations ---


def test_generalist_has_write_tools():
    tool_ids = {t.id for t in generalist_role.tools}
    assert "write_files" in tool_ids
    assert "edit_files" in tool_ids
    assert "make_directory" in tool_ids
    assert "delete_files" in tool_ids


def test_generalist_has_dispatch_tools():
    tool_ids = {t.id for t in generalist_role.tools}
    assert "research" in tool_ids
    assert "assign" in tool_ids
    assert "review" in tool_ids


def test_generalist_has_admin_tools():
    tool_ids = {t.id for t in generalist_role.tools}
    assert "manage_mcp" in tool_ids
    assert "command" in tool_ids


def test_worker_has_write_tools():
    tool_ids = {t.id for t in worker_role.tools}
    assert "write_files" in tool_ids
    assert "edit_files" in tool_ids
    assert "make_directory" in tool_ids
    assert "delete_files" in tool_ids


def test_worker_has_no_dispatch_or_admin_tools():
    tool_ids = {t.id for t in worker_role.tools}
    assert "research" not in tool_ids
    assert "assign" not in tool_ids
    assert "review" not in tool_ids
    assert "command" not in tool_ids
    assert "manage_mcp" not in tool_ids


def test_reviewer_has_no_tools():
    assert reviewer_role.tools == []


def test_researcher_has_no_tools():
    assert researcher_role.tools == []


def test_all_base_roles_contains_all_four():
    role_ids = {r.id for r in ALL_BASE_ROLES}
    assert role_ids == {"generalist", "worker", "reviewer", "researcher"}


# --- build_tools integration ---


def test_build_tools_generalist_gets_all():
    _make_app()
    session = _make_session("generalist")

    with patch("hypergolic.tools.tool_list.get_session_workflow", return_value=None), \
         patch("hypergolic.tools.tool_list.get_active_skill_ids", return_value=set()), \
         patch("hypergolic.tools.tool_list.get_enabled_servers", return_value=set()):
        from hypergolic.tools.tool_list import build_tools
        tools = build_tools(session)

    tool_ids = {t.id for t in tools}
    # Universal
    assert UNIVERSAL_IDS <= tool_ids
    # Role-specific
    assert "command" in tool_ids
    assert "assign" in tool_ids
    assert "research" in tool_ids
    assert "review" in tool_ids
    assert "write_files" in tool_ids
    assert "manage_mcp" in tool_ids


def test_build_tools_worker_gets_universal_plus_write():
    _make_app()
    session = _make_session("worker")

    with patch("hypergolic.tools.tool_list.get_session_workflow", return_value=None), \
         patch("hypergolic.tools.tool_list.get_active_skill_ids", return_value=set()), \
         patch("hypergolic.tools.tool_list.get_enabled_servers", return_value=set()):
        from hypergolic.tools.tool_list import build_tools
        tools = build_tools(session)

    tool_ids = {t.id for t in tools}
    # Universal
    assert UNIVERSAL_IDS <= tool_ids
    # Write tools
    assert "write_files" in tool_ids
    assert "edit_files" in tool_ids
    assert "make_directory" in tool_ids
    assert "delete_files" in tool_ids
    # Must NOT have dispatch/admin
    assert "command" not in tool_ids
    assert "assign" not in tool_ids
    assert "research" not in tool_ids
    assert "review" not in tool_ids
    assert "manage_mcp" not in tool_ids


def test_build_tools_reviewer_gets_only_universal():
    _make_app()
    session = _make_session("reviewer")

    with patch("hypergolic.tools.tool_list.get_session_workflow", return_value=None), \
         patch("hypergolic.tools.tool_list.get_active_skill_ids", return_value=set()), \
         patch("hypergolic.tools.tool_list.get_enabled_servers", return_value=set()):
        from hypergolic.tools.tool_list import build_tools
        tools = build_tools(session)

    tool_ids = {t.id for t in tools}
    assert tool_ids == UNIVERSAL_IDS


def test_build_tools_researcher_gets_only_universal():
    _make_app()
    session = _make_session("researcher")

    with patch("hypergolic.tools.tool_list.get_session_workflow", return_value=None), \
         patch("hypergolic.tools.tool_list.get_active_skill_ids", return_value=set()), \
         patch("hypergolic.tools.tool_list.get_enabled_servers", return_value=set()):
        from hypergolic.tools.tool_list import build_tools
        tools = build_tools(session)

    tool_ids = {t.id for t in tools}
    assert tool_ids == UNIVERSAL_IDS


def test_build_tools_unknown_role_raises():
    _make_app()
    session = _make_session("nonexistent")

    with patch("hypergolic.tools.tool_list.get_session_workflow", return_value=None), \
         patch("hypergolic.tools.tool_list.get_active_skill_ids", return_value=set()), \
         patch("hypergolic.tools.tool_list.get_enabled_servers", return_value=set()):
        from hypergolic.tools.tool_list import build_tools
        with pytest.raises(AssertionError, match="Role 'nonexistent' not found"):
            build_tools(session)


def test_build_tools_child_session_gets_conclude():
    _make_app()
    session = _make_session("worker")
    session = Session(
        id="s1",
        model_tier=ModelTier.MEDIUM,
        project_id="p1",
        project_path="/tmp/test",
        role="worker",
        parent_id="parent-1",
    )

    with patch("hypergolic.tools.tool_list.get_session_workflow", return_value=None), \
         patch("hypergolic.tools.tool_list.get_active_skill_ids", return_value=set()), \
         patch("hypergolic.tools.tool_list.get_enabled_servers", return_value=set()):
        from hypergolic.tools.tool_list import build_tools
        tools = build_tools(session)

    tool_ids = {t.id for t in tools}
    assert "conclude" in tool_ids


# --- build_tools_with_reasons ---


def test_build_tools_with_reasons_labels_role_tools():
    _make_app()
    session = _make_session("generalist")

    with patch("hypergolic.tools.tool_list.get_session_workflow", return_value=None), \
         patch("hypergolic.tools.tool_list.get_active_skill_ids", return_value=set()), \
         patch("hypergolic.tools.tool_list.get_enabled_servers", return_value=set()):
        from hypergolic.tools.tool_list import build_tools_with_reasons
        tools_with_reasons = build_tools_with_reasons(session)

    reasons = {t.id: reason for t, reason in tools_with_reasons}
    # Universal tools come from app
    assert reasons["list_files"] == "app"
    assert reasons["git"] == "app"
    # Role-specific tools come from role
    assert reasons["command"] == "role"
    assert reasons["assign"] == "role"
    assert reasons["write_files"] == "role"


def test_build_tools_with_reasons_unknown_role_raises():
    _make_app()
    session = _make_session("nonexistent")

    with patch("hypergolic.tools.tool_list.get_session_workflow", return_value=None), \
         patch("hypergolic.tools.tool_list.get_active_skill_ids", return_value=set()), \
         patch("hypergolic.tools.tool_list.get_enabled_servers", return_value=set()):
        from hypergolic.tools.tool_list import build_tools_with_reasons
        with pytest.raises(AssertionError, match="Role 'nonexistent' not found"):
            build_tools_with_reasons(session)
