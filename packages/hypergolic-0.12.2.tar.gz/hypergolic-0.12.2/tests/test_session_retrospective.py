from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBMessage, DBProject, DBSession
from hypergolic.sessions.retrospective import (
    _generate_retrospective,
    schedule_retrospective,
)


def _seed(sid="s1"):
    with get_db() as db:
        if not db.get(DBProject, "p1"):
            db.add(DBProject(id="p1", name="Proj", path="/tmp/p"))
        db.add(DBSession(
            id=sid, model_tier="Medium", system_prompt=[], project_id="p1",
        ))


def _add_msg(sid, role, text):
    with get_db() as db:
        db.add(DBMessage(
            session_id=sid, role=role,
            content=[{"type": "text", "text": text}],
        ))


@pytest.mark.asyncio
async def test_generate_retrospective_calls_api_and_saves():
    _seed()
    _add_msg("s1", "user", "Please refactor the auth module")
    _add_msg("s1", "assistant", "I've refactored the auth module successfully.")

    summary_text = "**What went well**: Clean refactor. **Improvements**: None. **Unresolved**: None."

    broadcast = AsyncMock()
    with patch("hypergolic.sessions.retrospective.generate_text", new=AsyncMock(return_value=summary_text)):
        await _generate_retrospective("s1", broadcast)

    # Verify summary was saved to DB
    with get_db() as db:
        session = db.get(DBSession, "s1")
        assert session is not None
        assert session.conclusion_summary == summary_text

    # Verify broadcast
    broadcast.assert_called_once()
    event = broadcast.call_args[0][0]
    assert event.type == "conclusion_summary_ready"
    assert event.session_id == "s1"
    assert event.content == [{"summary": summary_text}]


@pytest.mark.asyncio
async def test_generate_retrospective_skips_when_no_messages():
    _seed()
    broadcast = AsyncMock()
    await _generate_retrospective("s1", broadcast)

    with get_db() as db:
        session = db.get(DBSession, "s1")
        assert session is not None
        assert session.conclusion_summary is None
    broadcast.assert_not_called()


@pytest.mark.asyncio
async def test_generate_retrospective_skips_empty_transcript():
    """Messages with no extractable text content produce no transcript blocks."""
    _seed()
    # Add a message with only non-text content
    with get_db() as db:
        db.add(DBMessage(
            session_id="s1", role="user",
            content=[{"type": "tool_result", "tool_use_id": "t1", "content": []}],
        ))

    broadcast = AsyncMock()
    await _generate_retrospective("s1", broadcast)

    with get_db() as db:
        session = db.get(DBSession, "s1")
        assert session is not None
        assert session.conclusion_summary is None
    broadcast.assert_not_called()


@pytest.mark.asyncio
async def test_generate_retrospective_skips_empty_response():
    _seed()
    _add_msg("s1", "user", "some work happened")

    broadcast = AsyncMock()
    with patch("hypergolic.sessions.retrospective.generate_text", new=AsyncMock(return_value=None)):
        await _generate_retrospective("s1", broadcast)

    with get_db() as db:
        session = db.get(DBSession, "s1")
        assert session is not None
        assert session.conclusion_summary is None
    broadcast.assert_not_called()


@pytest.mark.asyncio
async def test_generate_retrospective_handles_api_error():
    _seed()
    _add_msg("s1", "user", "some work happened")

    broadcast = AsyncMock()
    with patch(
        "hypergolic.sessions.retrospective.generate_text",
        new=AsyncMock(side_effect=RuntimeError("API down")),
    ):
        await _generate_retrospective("s1", broadcast)

    with get_db() as db:
        session = db.get(DBSession, "s1")
        assert session is not None
        assert session.conclusion_summary is None
    broadcast.assert_not_called()


def test_schedule_retrospective_creates_task():
    broadcast = AsyncMock()
    sentinel = object()
    with patch(
        "hypergolic.sessions.retrospective._generate_retrospective",
        new=MagicMock(return_value=sentinel),
    ):
        with patch("hypergolic.sessions.retrospective.asyncio") as mock_asyncio:
            schedule_retrospective("s1", broadcast)
            mock_asyncio.create_task.assert_called_once_with(sentinel)
