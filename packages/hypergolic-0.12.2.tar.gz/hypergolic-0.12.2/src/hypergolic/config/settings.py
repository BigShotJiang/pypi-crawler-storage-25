from pathlib import Path

from pydantic_settings import BaseSettings

PROMPTS_DIR = Path(__file__).parent.parent / "base" / "prompts"


class Settings(BaseSettings):
    HYPERGOLIC_API_KEY: str = ""
    HYPERGOLIC_BASE_URL: str = "https://api.anthropic.com"
    HYPERGOLIC_DATABASE_URL: str = f"sqlite:///{Path.home() / '.hypergolic' / 'hypergolic.db'}"
    MAX_TOKENS: int = 16384


settings = Settings()
