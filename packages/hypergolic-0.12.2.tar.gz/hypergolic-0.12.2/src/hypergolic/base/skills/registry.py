from hypergolic.base.tools.registry import TOOLKIT_ENGINEER_TOOLS
from hypergolic.toolkit.primitives import Skill

toolkit_engineer_skill = Skill(
    id="toolkit-engineer",
    name="Toolkit Engineering",
    description="Build, improve, and maintain the user's Hypergolic toolkit \u2014 tools, skills, roles, workflows, prompts, and projects",
    prompt_path="~/.hypergolic/base/prompts/skills/toolkit-engineer.md",
    tools=TOOLKIT_ENGINEER_TOOLS,
)

product_management_skill = Skill(
    id="product-management",
    name="Product Management",
    description="Collaborate on requirements, challenge assumptions, define scope, and produce a PRD before implementation begins",
    prompt_path="~/.hypergolic/base/prompts/skills/product-management.md",
)

prompt_engineer_skill = Skill(
    id="prompt-engineer",
    name="Prompt Engineering",
    description="Write, evaluate, and refine prompts for LLM-based systems — system prompts, role prompts, skill prompts, workflow state prompts, and project prompts",
    prompt_path="~/.hypergolic/base/prompts/skills/prompt-engineer.md",
)

ALL_BASE_SKILLS = [
    toolkit_engineer_skill,
    product_management_skill,
    prompt_engineer_skill,
]
