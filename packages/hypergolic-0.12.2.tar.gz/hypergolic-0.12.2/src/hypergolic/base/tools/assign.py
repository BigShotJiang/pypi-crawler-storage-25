import logging


from hypergolic.toolkit.primitives import InputSchema, Tool, ToolContext, ToolResult
from hypergolic.dispatch.core import dispatch
from hypergolic.enums import ModelTier

logger = logging.getLogger(__name__)

ASSIGN_DISPATCH_PROMPT = """You are a worker agent dispatched to complete a task. Your parent session is blocked waiting for you to complete it.

Guidelines:
- The user can see your conversation, but strongly prefer to work autonomously
- The task description from your parent is your specification — implement it precisely
- Be thorough but efficient — the parent session is blocked waiting for your result
- Use outcome "success" with a summary of what you did, or "failure" with the reason you couldn't complete it"""


class AssignInput(InputSchema):
    task: str
    model_tier: ModelTier = ModelTier.MEDIUM


async def run_assign(inp: AssignInput, ctx: ToolContext) -> ToolResult:
    result = await dispatch(
        parent_session_id=ctx.session.id,
        content_blocks=[{"type": "text", "text": inp.task}],
        dispatch_prompt=ASSIGN_DISPATCH_PROMPT,
        broadcast=ctx.broadcast,
        role="worker",
        model_tier=inp.model_tier,
    )

    if result.outcome == "success":
        return ToolResult(
            content=[{"type": "text", "text": result.conclusion}],
            outcome="SUCCESS",
        )
    elif result.outcome == "failure":
        return ToolResult(
            content=[
                {"type": "text", "text": f"Assignment failed: {result.conclusion}"}
            ],
            outcome="FAILURE",
        )
    else:
        return ToolResult(
            content=[
                {
                    "type": "text",
                    "text": f"Assignment was interrupted: {result.conclusion}",
                }
            ],
            outcome="FAILURE",
        )


assign_tool = Tool(
    id="assign",
    name="Assign",
    description="Dispatch a task to an agent",
    input_schema=AssignInput,
    run=run_assign,
)
