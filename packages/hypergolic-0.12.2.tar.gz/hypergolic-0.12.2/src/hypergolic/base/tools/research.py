import logging


from hypergolic.toolkit.primitives import InputSchema, Tool, ToolContext, ToolResult
from hypergolic.dispatch.core import dispatch
from hypergolic.enums import ModelTier

logger = logging.getLogger(__name__)

RESEARCH_DISPATCH_PROMPT = """You are a research agent dispatched to answer a question. Your parent session is waiting for your answer.

Guidelines:
- The user can see your conversation, but strongly prefer to work autonomously
- Use available tools to gather information and answer thoroughly
- Be thorough but efficient — the parent session is blocked waiting for your result
- Use outcome "success" with your answer, or "failure" with the reason you couldn't answer"""


class ResearchInput(InputSchema):
    question: str


async def run_research(inp: ResearchInput, ctx: ToolContext) -> ToolResult:
    result = await dispatch(
        parent_session_id=ctx.session.id,
        content_blocks=[{"type": "text", "text": inp.question}],
        dispatch_prompt=RESEARCH_DISPATCH_PROMPT,
        broadcast=ctx.broadcast,
        role="researcher",
        model_tier=ModelTier.LOW,
    )

    if result.outcome == "success":
        return ToolResult(
            content=[{"type": "text", "text": result.conclusion}],
            outcome="SUCCESS",
        )
    elif result.outcome == "failure":
        return ToolResult(
            content=[{"type": "text", "text": f"Research failed: {result.conclusion}"}],
            outcome="FAILURE",
        )
    else:
        return ToolResult(
            content=[
                {
                    "type": "text",
                    "text": f"Research was interrupted: {result.conclusion}",
                }
            ],
            outcome="FAILURE",
        )


research_tool = Tool(
    id="research",
    name="Research",
    description="Dispatch a read-only research question to an agent",
    input_schema=ResearchInput,
    run=run_research,
)
