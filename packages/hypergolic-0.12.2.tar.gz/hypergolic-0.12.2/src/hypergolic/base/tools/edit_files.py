
from hypergolic.base.tools.approvals.paths import (
    ALLOW,
    REQUIRE_APPROVAL,
    in_project_or_toolkit,
)
from hypergolic.toolkit.primitives import (
    InputSchema,
    Tool,
    ToolApprovalDecision,
    ToolContext,
    ToolResult,
)
from hypergolic.schemas import Session
from hypergolic.tools.paths import resolve_path


class EditFileEntry(InputSchema):
    path: str
    old_string: str
    new_string: str


class EditFilesInput(InputSchema):
    files: list[EditFileEntry]


def _edit_single_file(entry: EditFileEntry, session: Session) -> str | None:
    path = resolve_path(entry.path, session)

    if not path.exists():
        return f"Error: {entry.path} does not exist"

    if not path.is_file():
        return f"Error: {entry.path} is not a file"

    try:
        content = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return f"Error reading {entry.path}: File is not valid UTF-8 text"
    except PermissionError:
        return f"Error reading {entry.path}: Permission denied"

    occurrences = content.count(entry.old_string)
    if occurrences == 0:
        return f"Error: old_string not found in {entry.path}. Make sure it matches exactly, including whitespace and indentation."
    if occurrences > 1:
        return f"Error: old_string appears {occurrences} times in {entry.path}. It must appear exactly once. Include more surrounding context to make the match unique."

    new_content = content.replace(entry.old_string, entry.new_string, 1)

    try:
        path.write_text(new_content, encoding="utf-8")
        return None
    except PermissionError:
        return f"Error writing {entry.path}: Permission denied"
    except Exception as e:
        return f"Error writing {entry.path}: {e}"


async def run_edit_files(inp: EditFilesInput, ctx: ToolContext) -> ToolResult:
    if not inp.files:
        return ToolResult(
            content=[{"type": "text", "text": "No edits provided."}], outcome="FAILURE"
        )

    errors = [e for entry in inp.files if (e := _edit_single_file(entry, ctx.session))]
    if errors:
        return ToolResult(
            content=[{"type": "text", "text": "\n".join(errors)}],
            outcome="FAILURE",
        )

    return ToolResult(content=[{"type": "text", "text": "OK"}], outcome="SUCCESS")


def edit_files_approval(inp: EditFilesInput, session: Session) -> ToolApprovalDecision:
    """Allow edits inside the project (or ~/.hypergolic if that IS the project)."""
    for entry in inp.files:
        if not in_project_or_toolkit(entry.path, session):
            return REQUIRE_APPROVAL
    return ALLOW


edit_files_tool = Tool(
    id="edit_files",
    name="Edit Files",
    description="",
    input_schema=EditFilesInput,
    run=run_edit_files,
    approval=edit_files_approval,
)
