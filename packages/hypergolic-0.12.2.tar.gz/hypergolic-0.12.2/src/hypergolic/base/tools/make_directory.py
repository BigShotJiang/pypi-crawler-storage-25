
from hypergolic.base.tools.approvals.paths import (
    ALLOW,
    REQUIRE_APPROVAL,
    in_project,
)
from hypergolic.toolkit.primitives import (
    InputSchema,
    Tool,
    ToolApprovalDecision,
    ToolContext,
    ToolResult,
)
from hypergolic.schemas import Session
from hypergolic.tools.paths import resolve_path


class MakeDirectoryInput(InputSchema):
    path: str | None = None
    paths: list[str] | None = None


def _make_single_directory(dir_path: str, session: Session) -> str | None:
    p = resolve_path(dir_path, session)
    try:
        p.mkdir(parents=True, exist_ok=True)
        return None
    except PermissionError:
        return f"Permission denied: {dir_path}"
    except Exception as e:
        return f"Error creating directory {dir_path}: {e}"


async def run_make_directory(inp: MakeDirectoryInput, ctx: ToolContext) -> ToolResult:
    dir_paths: list[str] = []
    if inp.paths:
        dir_paths = inp.paths
    elif inp.path:
        dir_paths = [inp.path]
    else:
        return ToolResult(
            content=[{"type": "text", "text": "Error: 'path' or 'paths' is required."}],
            outcome="FAILURE",
        )

    errors = [e for dp in dir_paths if (e := _make_single_directory(dp, ctx.session))]
    if errors:
        return ToolResult(
            content=[{"type": "text", "text": "\n".join(errors)}],
            outcome="FAILURE",
        )

    return ToolResult(content=[{"type": "text", "text": "OK"}], outcome="SUCCESS")


def make_directory_approval(inp: MakeDirectoryInput, session: Session) -> ToolApprovalDecision:
    paths: list[str] = []
    if inp.paths:
        paths = inp.paths
    elif inp.path:
        paths = [inp.path]
    for p in paths:
        if not in_project(p, session):
            return REQUIRE_APPROVAL
    return ALLOW


make_directory_tool = Tool(
    id="make_directory",
    name="Make Directory",
    description="",
    input_schema=MakeDirectoryInput,
    run=run_make_directory,
    approval=make_directory_approval,
)
