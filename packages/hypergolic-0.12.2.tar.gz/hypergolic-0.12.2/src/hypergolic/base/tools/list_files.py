import fnmatch
from pathlib import Path
from typing import Optional

from pydantic import Field

from hypergolic.base.tools.approvals.paths import ALLOW
from hypergolic.toolkit.primitives import (
    InputSchema,
    Tool,
    ToolApprovalDecision,
    ToolContext,
    ToolResult,
)
from hypergolic.schemas import Session
from hypergolic.tools.gitignore import collect_ignore_rules
from hypergolic.tools.paths import resolve_path
from hypergolic.tools.subprocess_util import has_ripgrep, run_subprocess


class ListFilesInput(InputSchema):
    directory: str
    pattern: Optional[str] = Field(default=None, description="Glob pattern")
    max_depth: Optional[int] = None
    include_hidden: bool = False


def _python_list_files(directory: Path, inp: ListFilesInput) -> list[str]:
    rules = collect_ignore_rules(directory)
    entries: list[str] = []
    for path in sorted(directory.rglob("*")):
        rel = path.relative_to(directory)
        is_dir = path.is_dir()

        if not is_dir and not path.is_file():
            continue

        if not inp.include_hidden and any(p.startswith(".") for p in rel.parts):
            continue

        if inp.max_depth is not None and len(rel.parts) > inp.max_depth:
            continue

        if rules.is_ignored(path):
            continue

        if is_dir:
            entries.append(f"{rel}/")
        else:
            if inp.pattern and not fnmatch.fnmatch(rel.name, inp.pattern):
                continue
            entries.append(str(rel))
    return entries


def _collect_directories(
    directory: Path, inp: ListFilesInput, *, prefix: str = ""
) -> list[str]:
    rules = collect_ignore_rules(directory)
    dirs: list[str] = []
    for path in sorted(directory.rglob("*")):
        if not path.is_dir():
            continue
        rel = path.relative_to(directory)
        if not inp.include_hidden and any(p.startswith(".") for p in rel.parts):
            continue
        if inp.max_depth is not None and len(rel.parts) > inp.max_depth:
            continue
        if rules.is_ignored(path):
            continue
        dirs.append(f"{prefix}{rel}/")
    return dirs


async def _rg_list_files(directory: Path, inp: ListFilesInput) -> list[str]:
    cmd = ["rg", "--files"]

    if inp.max_depth is not None:
        cmd.extend(["--max-depth", str(inp.max_depth)])
    if inp.include_hidden:
        cmd.append("--hidden")
    if inp.pattern:
        cmd.extend(["-g", inp.pattern])

    cmd.append(str(directory))

    result = await run_subprocess(cmd, timeout=30)

    files: list[str] = []
    if result.returncode != 0 and result.stderr:
        if "No files were searched" not in result.stderr:
            raise RuntimeError(result.stderr)
    elif result.stdout.strip():
        files = result.stdout.strip().split("\n")

    prefix = f"{directory}/" if str(directory) != "." else ""
    dirs = _collect_directories(directory, inp, prefix=prefix)
    return sorted(files + dirs)


async def run_list_files(inp: ListFilesInput, ctx: ToolContext) -> ToolResult:
    directory = resolve_path(inp.directory, ctx.session)

    if not directory.exists():
        return ToolResult(
            content=[
                {
                    "type": "text",
                    "text": f"Error: directory '{inp.directory}' does not exist.",
                }
            ],
            outcome="FAILURE",
        )
    if not directory.is_dir():
        return ToolResult(
            content=[
                {
                    "type": "text",
                    "text": f"Error: '{inp.directory}' is not a directory.",
                }
            ],
            outcome="FAILURE",
        )

    try:
        if has_ripgrep():
            files = await _rg_list_files(directory, inp)
        else:
            files = _python_list_files(directory, inp)

        if not files:
            return ToolResult(
                content=[
                    {
                        "type": "text",
                        "text": "No entries found in the specified directory.",
                    }
                ],
                outcome="SUCCESS",
            )

        return ToolResult(
            content=[{"type": "text", "text": "\n".join(files)}], outcome="SUCCESS"
        )

    except Exception as e:
        return ToolResult(
            content=[{"type": "text", "text": f"Error listing files: {str(e)}"}],
            outcome="FAILURE",
        )


def list_files_approval(inp: ListFilesInput, session: Session) -> ToolApprovalDecision:
    """list_files is always allowed — it only reveals filenames."""
    return ALLOW


list_files_tool = Tool(
    id="list_files",
    name="List Files",
    description="",
    input_schema=ListFilesInput,
    run=run_list_files,
    approval=list_files_approval,
)
