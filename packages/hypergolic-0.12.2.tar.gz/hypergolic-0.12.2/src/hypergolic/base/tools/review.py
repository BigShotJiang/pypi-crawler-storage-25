import logging


from hypergolic.toolkit.primitives import InputSchema, Tool, ToolContext, ToolResult
from hypergolic.dispatch.core import dispatch
from hypergolic.enums import ModelTier

logger = logging.getLogger(__name__)

REVIEW_DISPATCH_PROMPT = """You are a code review agent dispatched to review changes. Your parent session is waiting for your assessment.

Guidelines:
- The user can see your conversation, but strongly prefer to work autonomously
- Start by running the git diff using the diff_source provided, then read relevant files for full context
- Evaluate the changes against your review criteria
- Be thorough but efficient — the parent session is blocked waiting for your result
- Use outcome "success" with your review, or "failure" with the reason you couldn't complete the review"""


class ReviewInput(InputSchema):
    description: str
    diff_source: str


async def run_review(inp: ReviewInput, ctx: ToolContext) -> ToolResult:
    content_text = f"""## Review Request

**What these changes should accomplish:**
{inp.description}

**Diff source:** `git diff {inp.diff_source}`"""

    result = await dispatch(
        parent_session_id=ctx.session.id,
        content_blocks=[{"type": "text", "text": content_text}],
        dispatch_prompt=REVIEW_DISPATCH_PROMPT,
        broadcast=ctx.broadcast,
        role="reviewer",
        model_tier=ModelTier.HIGH,
    )

    if result.outcome == "success":
        return ToolResult(
            content=[{"type": "text", "text": result.conclusion}],
            outcome="SUCCESS",
        )
    elif result.outcome == "failure":
        return ToolResult(
            content=[{"type": "text", "text": f"Review failed: {result.conclusion}"}],
            outcome="FAILURE",
        )
    else:
        return ToolResult(
            content=[
                {
                    "type": "text",
                    "text": f"Review was interrupted: {result.conclusion}",
                }
            ],
            outcome="FAILURE",
        )


review_tool = Tool(
    id="review",
    name="Review",
    description='Dispatch a code review to a reviewer agent.\n\ndiff_source examples: "main..HEAD", "HEAD~3", "--staged", "abc123..def456"',
    input_schema=ReviewInput,
    run=run_review,
)
