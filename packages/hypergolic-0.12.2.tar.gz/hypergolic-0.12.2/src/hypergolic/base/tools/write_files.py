from pydantic import Field

from hypergolic.base.tools.approvals.paths import (
    ALLOW,
    REQUIRE_APPROVAL,
    in_project_or_toolkit,
)
from hypergolic.toolkit.primitives import (
    InputSchema,
    Tool,
    ToolApprovalDecision,
    ToolContext,
    ToolResult,
)
from hypergolic.schemas import Session
from hypergolic.tools.paths import resolve_path


class WriteFileEntry(InputSchema):
    path: str
    content: str = Field(description="Complete file contents (replaces existing)")


class WriteFilesInput(InputSchema):
    files: list[WriteFileEntry]


async def run_write_files(inp: WriteFilesInput, ctx: ToolContext) -> ToolResult:
    errors: list[str] = []

    for entry in inp.files:
        path = resolve_path(entry.path, ctx.session)
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(entry.content, encoding="utf-8")
        except PermissionError:
            errors.append(f"Error writing {entry.path}: Permission denied")
        except Exception as e:
            errors.append(f"Error writing {entry.path}: {e}")

    if errors:
        return ToolResult(
            content=[{"type": "text", "text": "\n".join(errors)}],
            outcome="FAILURE",
        )

    return ToolResult(content=[{"type": "text", "text": "OK"}], outcome="SUCCESS")


def write_files_approval(inp: WriteFilesInput, session: Session) -> ToolApprovalDecision:
    """Allow writes inside the project (or ~/.hypergolic if that IS the project)."""
    for entry in inp.files:
        if not in_project_or_toolkit(entry.path, session):
            return REQUIRE_APPROVAL
    return ALLOW


write_files_tool = Tool(
    id="write_files",
    name="Write Files",
    description="",
    input_schema=WriteFilesInput,
    run=run_write_files,
    approval=write_files_approval,
)
