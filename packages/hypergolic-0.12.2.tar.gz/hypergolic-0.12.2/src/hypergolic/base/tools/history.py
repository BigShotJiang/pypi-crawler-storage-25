import json
from typing import Any, Literal

from sqlalchemy import String as SAString, func, select
from sqlalchemy.sql.expression import cast

from hypergolic.toolkit.primitives import InputSchema, Tool, ToolContext, ToolResult
from hypergolic.db.engine import get_db
from hypergolic.db.models import DBMessage, DBSession
from hypergolic.db.utils import to_iso_utc

MAX_SESSIONS = 50
MAX_MESSAGES = 100
MAX_CONTENT_PREVIEW = 500


class HistoryInput(InputSchema):
    command: Literal["list_sessions", "get_messages", "search_messages"]
    query: str | None = None
    session_id: str | None = None
    role: Literal["user", "assistant"] | None = None
    limit: int | None = None
    offset: int | None = None


def _extract_text(content: list[Any]) -> str:
    parts: list[str] = []
    for block in content:
        if isinstance(block, dict):
            if block.get("type") == "text":
                parts.append(block.get("text", ""))
            elif block.get("type") == "tool_use":
                parts.append(f"[tool_use: {block.get('name', '?')}]")
            elif block.get("type") == "tool_result":
                parts.append("[tool_result]")
        elif isinstance(block, str):
            parts.append(block)
    return "\n".join(parts)


def _serialize_session(
    session: DBSession,
    message_count: int | None = None,
    first_message_preview: str | None = None,
) -> dict:
    result: dict[str, Any] = {
        "id": session.id,
        "model_tier": session.model_tier,
        "created_at": to_iso_utc(session.created_at),
        "updated_at": to_iso_utc(session.updated_at),
    }
    if message_count is not None:
        result["message_count"] = message_count
    if first_message_preview is not None:
        result["first_message"] = first_message_preview
    return result


def _serialize_message(msg: DBMessage, truncate: int | None = None) -> dict:
    text = _extract_text(msg.content)
    if truncate and len(text) > truncate:
        text = text[:truncate] + "..."
    result: dict[str, Any] = {
        "id": msg.id,
        "session_id": msg.session_id,
        "role": msg.role,
        "text": text,
        "model": msg.model,
        "created_at": to_iso_utc(msg.created_at),
    }
    if msg.truncated:
        result["truncated"] = True
    if msg.stop_reason:
        result["stop_reason"] = msg.stop_reason
    if msg.usage:
        result["usage"] = msg.usage
    return result


def _content_contains(query: str):
    return cast(DBMessage.content, SAString).contains(query)


def _handle_list_sessions(inp: HistoryInput) -> ToolResult:
    limit = min(inp.limit or 20, MAX_SESSIONS)
    offset = inp.offset or 0

    with get_db() as db:
        msg_count_subq = (
            select(
                DBMessage.session_id,
                func.count(DBMessage.id).label("msg_count"),
            )
            .group_by(DBMessage.session_id)
            .subquery()
        )

        query = (
            select(DBSession, msg_count_subq.c.msg_count)
            .outerjoin(msg_count_subq, DBSession.id == msg_count_subq.c.session_id)
            .order_by(DBSession.created_at.desc())
            .limit(limit)
            .offset(offset)
        )

        if inp.query:
            matching_session_ids = (
                select(DBMessage.session_id)
                .where(DBMessage.role == "user")
                .where(_content_contains(inp.query))
                .distinct()
            )
            query = query.where(DBSession.id.in_(matching_session_ids))

        rows = db.execute(query).all()

        results = []
        for row in rows:
            session = row[0]
            msg_count = row[1] or 0

            preview = None
            first_msg = db.execute(
                select(DBMessage)
                .where(DBMessage.session_id == session.id, DBMessage.role == "user")
                .order_by(DBMessage.created_at)
                .limit(1)
            ).scalar_one_or_none()
            if first_msg:
                text = _extract_text(first_msg.content)
                preview = (
                    text[:MAX_CONTENT_PREVIEW]
                    if len(text) > MAX_CONTENT_PREVIEW
                    else text
                )

            results.append(_serialize_session(session, msg_count, preview))

    return ToolResult(
        content=[{"type": "text", "text": json.dumps(results, indent=2)}],
        outcome="SUCCESS",
    )


def _handle_get_messages(inp: HistoryInput) -> ToolResult:
    if not inp.session_id:
        return ToolResult(
            content=[
                {
                    "type": "text",
                    "text": "Error: 'session_id' is required for get_messages.",
                }
            ],
            outcome="FAILURE",
        )

    limit = min(inp.limit or 50, MAX_MESSAGES)
    offset = inp.offset or 0

    with get_db() as db:
        session = db.execute(
            select(DBSession).where(DBSession.id == inp.session_id)
        ).scalar_one_or_none()
        if not session:
            return ToolResult(
                content=[
                    {
                        "type": "text",
                        "text": f"Error: Session '{inp.session_id}' not found.",
                    }
                ],
                outcome="FAILURE",
            )

        query = (
            select(DBMessage)
            .where(DBMessage.session_id == inp.session_id)
            .order_by(DBMessage.created_at)
            .limit(limit)
            .offset(offset)
        )
        if inp.role:
            query = query.where(DBMessage.role == inp.role)

        msgs = db.execute(query).scalars().all()
        results = [_serialize_message(msg) for msg in msgs]

    return ToolResult(
        content=[{"type": "text", "text": json.dumps(results, indent=2)}],
        outcome="SUCCESS",
    )


def _handle_search_messages(inp: HistoryInput) -> ToolResult:
    if not inp.query:
        return ToolResult(
            content=[
                {
                    "type": "text",
                    "text": "Error: 'query' is required for search_messages.",
                }
            ],
            outcome="FAILURE",
        )

    limit = min(inp.limit or 20, MAX_MESSAGES)
    offset = inp.offset or 0

    with get_db() as db:
        query = (
            select(DBMessage)
            .where(_content_contains(inp.query))
            .order_by(DBMessage.created_at.desc())
            .limit(limit)
            .offset(offset)
        )

        if inp.role:
            query = query.where(DBMessage.role == inp.role)

        msgs = db.execute(query).scalars().all()
        results = [
            _serialize_message(msg, truncate=MAX_CONTENT_PREVIEW) for msg in msgs
        ]

    return ToolResult(
        content=[{"type": "text", "text": json.dumps(results, indent=2)}],
        outcome="SUCCESS",
    )


async def run_history(inp: HistoryInput, ctx: ToolContext) -> ToolResult:
    match inp.command:
        case "list_sessions":
            return _handle_list_sessions(inp)
        case "get_messages":
            return _handle_get_messages(inp)
        case "search_messages":
            return _handle_search_messages(inp)


history_tool = Tool(
    id="history",
    name="History",
    description="Search and query past conversation sessions and messages",
    input_schema=HistoryInput,
    run=run_history,
)
