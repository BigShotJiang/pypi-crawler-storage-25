
from hypergolic.base.tools.approvals.paths import (
    ALLOW,
    REQUIRE_APPROVAL,
    in_project_or_toolkit,
)
from hypergolic.toolkit.primitives import (
    InputSchema,
    Tool,
    ToolApprovalDecision,
    ToolContext,
    ToolResult,
)
from hypergolic.schemas import Session
from hypergolic.tools.paths import resolve_path


class DeleteFilesInput(InputSchema):
    paths: list[str]


async def run_delete_files(inp: DeleteFilesInput, ctx: ToolContext) -> ToolResult:
    errors: list[str] = []

    for file_path in inp.paths:
        path = resolve_path(file_path, ctx.session)
        try:
            if not path.exists():
                errors.append(f"File not found: {file_path}")
            elif path.is_dir():
                errors.append(f"Is a directory (use rmdir instead): {file_path}")
            else:
                path.unlink()
        except PermissionError:
            errors.append(f"Permission denied: {file_path}")
        except Exception as e:
            errors.append(f"Error deleting {file_path}: {e}")

    if errors:
        return ToolResult(
            content=[{"type": "text", "text": "\n".join(errors)}],
            outcome="FAILURE",
        )

    return ToolResult(content=[{"type": "text", "text": "OK"}], outcome="SUCCESS")


def delete_files_approval(inp: DeleteFilesInput, session: Session) -> ToolApprovalDecision:
    """Allow deletes inside the project (or ~/.hypergolic if that IS the project)."""
    for entry in inp.paths:
        if not in_project_or_toolkit(entry, session):
            return REQUIRE_APPROVAL
    return ALLOW


delete_files_tool = Tool(
    id="delete_files",
    name="Delete Files",
    description="",
    input_schema=DeleteFilesInput,
    run=run_delete_files,
    approval=delete_files_approval,
)
