"""Allowlisted paths for read-only file access outside the project directory.

Paths listed here are accessible to read-only tools (read_files, search_files,
list_files) without requiring user approval, even when they fall outside the
current project directory.

Each entry is resolved via Path.expanduser() so ~ is supported.
"""

from pathlib import Path

# Paths (files or directories) that read-only tools may access without approval.
# Directory entries grant access to the entire subtree.
READONLY_ALLOWLIST: list[str] = [
    "~/.hypergolic",
    "~/.aws/config",
]

HYPERGOLIC_TOOLKIT_DIR = Path("~/.hypergolic")
