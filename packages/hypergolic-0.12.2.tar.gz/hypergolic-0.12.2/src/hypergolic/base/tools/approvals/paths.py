"""Shared path-resolution and boundary-check helpers for tool approval functions.

The per-tool approval callbacks live **in each tool file** alongside the tool
they guard.  This module provides the reusable building blocks those callbacks
import.
"""

from pathlib import Path

from hypergolic.base.tools.approvals.constants import (
    HYPERGOLIC_TOOLKIT_DIR,
    READONLY_ALLOWLIST,
)
from hypergolic.toolkit.primitives import ToolApprovalDecision
from hypergolic.schemas import Session
from hypergolic.tools.paths import resolve_path

ALLOW = ToolApprovalDecision(decision="ALLOW")
REQUIRE_APPROVAL = ToolApprovalDecision(decision="REQUIRE_APPROVAL")


def _resolved_allowlist(session: Session) -> list[Path]:
    return [resolve_path(p, session) for p in READONLY_ALLOWLIST]


def _project_dir(session: Session) -> Path:
    return Path(session.project_path).expanduser().resolve()


def _is_within(path: Path, parent: Path) -> bool:
    """Return True if *path* is equal to or nested inside *parent*."""
    try:
        return path == parent or path.is_relative_to(parent)
    except (ValueError, TypeError):
        return False


def _is_toolkit_project(session: Session) -> bool:
    """Return True if the session's project IS the ~/.hypergolic toolkit."""
    toolkit = Path(str(HYPERGOLIC_TOOLKIT_DIR)).expanduser().resolve()
    project = _project_dir(session)
    return project == toolkit


def in_project_or_readonly_allowlist(
    raw_path: str,
    session: Session,
) -> bool:
    """True if *raw_path* is inside the project dir or on the readonly allowlist."""
    resolved = resolve_path(raw_path, session)
    if _is_within(resolved, _project_dir(session)):
        return True
    for allowed in _resolved_allowlist(session):
        if _is_within(resolved, allowed):
            return True
    return False


def in_project(raw_path: str, session: Session) -> bool:
    """True if *raw_path* is inside the project directory."""
    return _is_within(resolve_path(raw_path, session), _project_dir(session))


def in_project_or_toolkit(raw_path: str, session: Session) -> bool:
    """True if *raw_path* is in the project dir, or in ~/.hypergolic when the
    session's project IS the toolkit."""
    if in_project(raw_path, session):
        return True
    if _is_toolkit_project(session):
        toolkit = Path(str(HYPERGOLIC_TOOLKIT_DIR)).expanduser().resolve()
        return _is_within(resolve_path(raw_path, session), toolkit)
    return False
