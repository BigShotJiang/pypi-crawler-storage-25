from hypergolic.toolkit.primitives import Role
from hypergolic.base.tools.command import command_tool
from hypergolic.base.tools.registry import WRITE_TOOLS, DISPATCH_TOOLS, ADMIN_TOOLS

generalist_role = Role(
    id="generalist",
    name="Generalist",
    prompt_path="~/.hypergolic/base/prompts/roles/generalist.md",
    tools=[*WRITE_TOOLS, *DISPATCH_TOOLS, *ADMIN_TOOLS, command_tool],
)

worker_role = Role(
    id="worker",
    name="Worker",
    prompt_path="~/.hypergolic/base/prompts/roles/worker.md",
    tools=[*WRITE_TOOLS],
)

reviewer_role = Role(
    id="reviewer",
    name="Reviewer",
    prompt_path="~/.hypergolic/base/prompts/roles/reviewer.md",
)

researcher_role = Role(
    id="researcher",
    name="Researcher",
    prompt_path="~/.hypergolic/base/prompts/roles/researcher.md",
)

ALL_BASE_ROLES = [
    generalist_role,
    researcher_role,
    reviewer_role,
    worker_role,
]
