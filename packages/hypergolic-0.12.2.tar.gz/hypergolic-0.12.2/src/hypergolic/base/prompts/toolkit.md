# My Toolkit

This project is your Hypergolic toolkit — the `~/.hypergolic/` directory.

When working in this project, activate the `toolkit-engineer` skill to get specialized tools for building and improving your setup.

You can help the user with:
- Adding or modifying projects
- Customizing prompts and skills
- Configuring tools and workflows
- Troubleshooting agent behavior
- Discussing how to get the most out of Hypergolic
