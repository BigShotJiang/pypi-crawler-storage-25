from __future__ import annotations

import inspect
import logging
from typing import Any, cast

from anthropic.types.tool_result_block_param import Content
from pydantic import BaseModel

from hypergolic.toolkit.primitives import (
    Tool as ToolkitTool,
    ToolApprovalDecision,
    ToolContext as ToolkitToolContext,
    ToolResult,
)
from hypergolic.tools.schemas import (
    Tool as InternalTool,
    ToolContext as InternalToolContext,
    ToolOutput,
)

logger = logging.getLogger(__name__)


class _EmptyInput(BaseModel):
    pass


def _param_count(fn: Any) -> int:
    sig = inspect.signature(fn)
    return len([p for p in sig.parameters.values() if p.name != "self"])


def _result_to_output(result: ToolResult) -> ToolOutput:
    return ToolOutput(
        content=cast(list[Content], result.content),
        is_error=result.outcome == "FAILURE",
    )


def _build_call_tool(toolkit_tool: ToolkitTool) -> Any:
    run_fn = toolkit_tool.run
    has_input = _param_count(run_fn) >= 2

    async def call_tool(inp: Any, ctx: InternalToolContext) -> ToolOutput:
        toolkit_ctx = ToolkitToolContext(
            session=ctx.session,
            broadcast=ctx.broadcast,
            tool_id=ctx.tool_id,
        )
        try:
            if has_input:
                result = await run_fn(inp, toolkit_ctx)
            else:
                result = await run_fn(toolkit_ctx)
            return _result_to_output(result)
        except Exception as e:
            logger.error("Toolkit tool '%s' failed: %s", toolkit_tool.id, e, exc_info=True)
            return ToolOutput(
                content=[{"type": "text", "text": f"Error: {e}"}],
                is_error=True,
            )

    return call_tool


def convert_tool(toolkit_tool: ToolkitTool) -> InternalTool:
    input_model = toolkit_tool.input_schema or _EmptyInput

    return InternalTool(
        id=toolkit_tool.id,
        name=toolkit_tool.name,
        description=toolkit_tool.description,
        input=input_model,
        call_tool=_build_call_tool(toolkit_tool),
        source="toolkit",
    )


def convert_tools(toolkit_tools: list[ToolkitTool]) -> list[InternalTool]:
    return [convert_tool(t) for t in toolkit_tools]


def evaluate_toolkit_approval(
    toolkit_tool: ToolkitTool,
    raw_input: dict[str, Any],
    session: Any | None = None,
) -> ToolApprovalDecision:
    approval = toolkit_tool.approval

    if isinstance(approval, str):
        if approval == "ALLOW":
            return ToolApprovalDecision(decision="ALLOW")
        if approval == "DENY":
            return ToolApprovalDecision(decision="DENY")
        return ToolApprovalDecision(decision="REQUIRE_APPROVAL")

    try:
        nparams = _param_count(approval)
        if nparams >= 2 and toolkit_tool.input_schema and session is not None:
            parsed = toolkit_tool.input_schema.model_validate(raw_input)
            return approval(parsed, session)
        if nparams >= 1 and toolkit_tool.input_schema:
            parsed = toolkit_tool.input_schema.model_validate(raw_input)
            return approval(parsed)
        return approval()
    except Exception:
        logger.warning(
            "Approval callback for tool '%s' raised an exception; defaulting to REQUIRE_APPROVAL",
            toolkit_tool.id,
            exc_info=True,
        )
        return ToolApprovalDecision(decision="REQUIRE_APPROVAL")
