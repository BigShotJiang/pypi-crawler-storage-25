from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from hypergolic.toolkit.app.core import App


def validate_app(app: App) -> list[str]:
    """Return a list of configuration error strings (empty = valid)."""
    errors: list[str] = []

    if not app.roles:
        errors.append("No roles registered. Register at least the base roles with app.register_roles(ALL_BASE_ROLES).")

    role_ids = [r.id for r in app.roles]
    if app.roles and "generalist" not in role_ids:
        errors.append("No 'generalist' role registered. The generalist role is required as the default session role.")

    tool_ids: list[str] = []
    for t in app.tools:
        tool_ids.append(t.id)
    for p in app.projects:
        for t in p.tools:
            tool_ids.append(t.id)
    for wf in app.workflows:
        for t in wf.tools:
            tool_ids.append(t.id)
    for p in app.projects:
        for wf in p.workflows:
            for t in wf.tools:
                tool_ids.append(t.id)
    seen: set[str] = set()
    for tid in tool_ids:
        if tid in seen:
            errors.append(f"Duplicate tool ID: '{tid}'")
        seen.add(tid)

    proj_ids = [p.id for p in app.projects]
    seen_proj: set[str] = set()
    for pid in proj_ids:
        if pid in seen_proj:
            errors.append(f"Duplicate project ID: '{pid}'")
        seen_proj.add(pid)

    for p in app.projects:
        root = Path(p.git_root).expanduser()
        if not root.exists():
            errors.append(f"Project '{p.id}' git_root does not exist: {root}")
        elif not (root / ".git").exists():
            errors.append(f"Project '{p.id}' git_root is not a git repo: {root}")

    for p in app.projects:
        if p.prompt_path:
            path = Path(p.prompt_path).expanduser()
            if not path.exists():
                errors.append(f"Project '{p.id}' prompt_path not found: {path}")

    for wf in app.workflows:
        state_ids = {s.id for s in wf.states}
        if wf.initial_state not in state_ids:
            errors.append(f"Workflow '{wf.id}' initial_state '{wf.initial_state}' not found in states")
        for s in wf.states:
            for o in s.output_schemas:
                if o.next_state and o.next_state not in state_ids:
                    errors.append(f"Workflow '{wf.id}' state '{s.id}' output references unknown state '{o.next_state}'")

    return errors
