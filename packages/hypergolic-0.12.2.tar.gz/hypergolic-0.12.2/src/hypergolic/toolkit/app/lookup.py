from __future__ import annotations

from typing import Protocol

from hypergolic.toolkit.primitives import Role, Skill, Workflow
from hypergolic.toolkit.project import Project


class _SkillSearchable(Protocol):
    skills: list[Skill]
    projects: list[Project]
    roles: list[Role]
    workflows: list[Workflow]


def find_skill(skill_id: str, app: _SkillSearchable) -> Skill | None:
    for s in app.skills:
        if s.id == skill_id:
            return s
    for p in app.projects:
        for s in p.skills:
            if s.id == skill_id:
                return s
    for r in app.roles:
        for s in r.skills:
            if s.id == skill_id:
                return s
    for wf in app.workflows:
        for s in wf.skills:
            if s.id == skill_id:
                return s
        for state in wf.states:
            for s in state.skills:
                if s.id == skill_id:
                    return s
    for p in app.projects:
        for wf in p.workflows:
            for s in wf.skills:
                if s.id == skill_id:
                    return s
            for state in wf.states:
                for s in state.skills:
                    if s.id == skill_id:
                        return s
    return None
