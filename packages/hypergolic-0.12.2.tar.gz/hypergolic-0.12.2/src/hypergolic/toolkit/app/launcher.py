from __future__ import annotations

import os
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import TYPE_CHECKING

import uvicorn
import webview
from rich.console import Console

from hypergolic.auth import init_bootstrap_token
from hypergolic.cli.setup import run_migrations
from hypergolic.config.settings import settings

if TYPE_CHECKING:
    from hypergolic.toolkit.app.core import App


def _wait_for_server(host: str, port: int, timeout: float = 30.0) -> bool:
    health_url = f"http://{host}:{port}/api/health"
    start = time.time()
    while time.time() - start < timeout:
        try:
            with urllib.request.urlopen(health_url, timeout=1) as resp:
                if resp.status == 200:
                    return True
        except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError):
            pass
        time.sleep(0.1)
    return False


def launch(app: App, *, safe: bool = False) -> None:
    console = Console()

    app._expand_paths()

    db_path = Path(app.db_path).expanduser()
    db_path.parent.mkdir(parents=True, exist_ok=True)
    settings.HYPERGOLIC_DATABASE_URL = f"sqlite:///{db_path}"

    run_migrations()
    app._register_projects_in_db()

    from hypergolic.api import app as fastapi_app

    fastapi_app.state.toolkit_app = app

    bootstrap_token = init_bootstrap_token()
    host = "127.0.0.1"
    port = int(os.environ.get("HYPERGOLIC_PORT", "54322"))
    url = f"http://{host}:{port}?token={bootstrap_token}"

    server_thread = threading.Thread(
        target=uvicorn.run,
        kwargs={
            "app": "hypergolic.api:app",
            "host": host,
            "port": port,
            "log_level": "info",
        },
        daemon=True,
    )
    server_thread.start()

    if not _wait_for_server(host, port):
        console.print("[red]Error:[/] Server failed to start within timeout.")
        return

    if safe:
        console.print(
            "[yellow]\u26a0 Running in safe mode \u2014 base tools only, no user config[/]"
        )

    largest_screen = max(webview.screens, key=lambda s: s.width * s.height)
    window = webview.create_window(
        "Hypergolic",
        url,
        screen=largest_screen,
        background_color="#0a0a0f",
        maximized=True,
        text_select=True,
    )

    def _maximize():
        if window:
            window.move(0, 0)
            window.resize(largest_screen.width, largest_screen.height)

    webview.start(func=_maximize, debug=False)
