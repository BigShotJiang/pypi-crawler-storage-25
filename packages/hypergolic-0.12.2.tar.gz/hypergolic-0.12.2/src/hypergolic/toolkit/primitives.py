from __future__ import annotations

import inspect
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Literal, cast

from anthropic.types import ToolUnionParam
from pydantic import BaseModel, Field, model_validator

from hypergolic.messages.types import BroadcastFn
from hypergolic.schemas import Session


class InputSchema(BaseModel):
    pass


def _strip_schema_noise(schema: dict) -> None:
    schema.pop("title", None)
    # Ensure additionalProperties is False for all object types
    if schema.get("type") == "object" or "properties" in schema:
        schema["additionalProperties"] = False
    for value in schema.values():
        if isinstance(value, dict):
            _strip_schema_noise(value)
        elif isinstance(value, list):
            for item in value:
                if isinstance(item, dict):
                    _strip_schema_noise(item)


class ToolResult(BaseModel):
    content: list[dict]
    outcome: Literal["SUCCESS", "FAILURE"]


class ToolApprovalDecision(BaseModel):
    decision: Literal["ALLOW", "DENY", "REQUIRE_APPROVAL"]
    reason: str | None = None
    context: str | None = None


@dataclass
class ToolContext:
    session: Session
    broadcast: BroadcastFn
    tool_id: str


class Tool(BaseModel):
    id: str
    name: str
    description: str
    timeout: int = 30
    input_schema: type[InputSchema] | None = None
    run: Callable
    approval: Callable | str = "ALLOW"

    model_config = {"arbitrary_types_allowed": True}

    @model_validator(mode="after")
    def _validate_run_is_async(self) -> "Tool":
        if not inspect.iscoroutinefunction(self.run):
            fn_name = getattr(self.run, "__name__", "<unknown>")
            raise ValueError(
                f"Tool '{self.id}' run function must be async. "
                f"Change 'def {fn_name}(...)' to 'async def {fn_name}(...)'."
            )
        return self

    def to_param(self) -> ToolUnionParam:
        if self.input_schema:
            schema = self.input_schema.model_json_schema()
            schema["additionalProperties"] = False
            _strip_schema_noise(schema)
        else:
            schema = {"type": "object", "properties": {}, "additionalProperties": False}
        param: dict = {"name": self.id, "input_schema": schema}
        if self.description:
            param["description"] = self.description
        return cast(ToolUnionParam, param)


class ToolRegistryMixin:
    tools: list[Tool]

    def register_tool(self, tool: Tool) -> None:
        self.tools.append(tool)

    def register_tools(self, tools: list[Tool]) -> None:
        self.tools.extend(tools)


VALID_DISPLAY_TYPES = {"markdown", "list", "badge", "text"}


class OutputSchema(BaseModel):
    model_config = {"populate_by_name": True}

    outcome: str
    artifact_id: str | None = None
    requires_approval: bool = False
    display: dict[str, str] | None = None
    schema_def: dict = Field(alias="schema")
    next_state: str | None = None

    @model_validator(mode="after")
    def validate_display(self) -> "OutputSchema":
        if self.display is None:
            return self
        schema_props = set(self.schema_def.get("properties", {}).keys())
        for field_name, render_type in self.display.items():
            if field_name not in schema_props:
                raise ValueError(
                    f"display key '{field_name}' not found in schema properties: {sorted(schema_props)}"
                )
            if render_type not in VALID_DISPLAY_TYPES:
                raise ValueError(
                    f"display type '{render_type}' for field '{field_name}' is invalid. "
                    f"Valid types: {sorted(VALID_DISPLAY_TYPES)}"
                )
        return self


def validate_prompt_exclusivity(self: Any) -> Any:
    set_count = sum(1 for x in [self.prompt, self.prompt_path, self.prompt_fn] if x is not None)
    if set_count > 1:
        raise ValueError("Specify at most one of 'prompt', 'prompt_path', or 'prompt_fn'")
    return self


class Skill(ToolRegistryMixin, BaseModel):
    id: str
    name: str
    description: str
    prompt_path: str | None = None
    prompt: str | None = None
    prompt_fn: Callable[..., str] | None = None
    tools: list[Tool] = Field(default_factory=list)

    model_config = {"arbitrary_types_allowed": True}

    _validate_prompt = model_validator(mode="after")(validate_prompt_exclusivity)


class WorkflowState(ToolRegistryMixin, BaseModel):
    id: str
    name: str
    prompt_path: str | None = None
    prompt: str | None = None
    prompt_fn: Callable[..., str] | None = None
    truncate_on_entry: bool = False
    include_artifacts: list[str] = Field(default_factory=list)
    skills: list[Skill] = Field(default_factory=list)
    tools: list[Tool] = Field(default_factory=list)
    output_schemas: list[OutputSchema] = Field(default_factory=list)

    model_config = {"arbitrary_types_allowed": True}

    _validate_prompt = model_validator(mode="after")(validate_prompt_exclusivity)


class Workflow(ToolRegistryMixin, BaseModel):
    id: str
    name: str
    description: str
    prompt_path: str | None = None
    prompt: str | None = None
    prompt_fn: Callable[..., str] | None = None
    initial_state: str
    states: list[WorkflowState] = Field(default_factory=list)
    tools: list[Tool] = Field(default_factory=list)
    skills: list[Skill] = Field(default_factory=list)

    model_config = {"arbitrary_types_allowed": True}

    _validate_prompt = model_validator(mode="after")(validate_prompt_exclusivity)


class Role(ToolRegistryMixin, BaseModel):
    id: str
    name: str
    prompt_path: str | None = None
    prompt: str | None = None
    prompt_fn: Callable[..., str] | None = None
    skills: list[Skill] = Field(default_factory=list)
    tools: list[Tool] = Field(default_factory=list)

    model_config = {"arbitrary_types_allowed": True}

    _validate_prompt = model_validator(mode="after")(validate_prompt_exclusivity)


def resolve_prompt(obj: Any, app: Any) -> str | None:
    """Resolve prompt content from prompt_fn, prompt, or prompt_path (in that order)."""
    if hasattr(obj, "prompt_fn") and obj.prompt_fn is not None:
        return obj.prompt_fn(app)
    if hasattr(obj, "prompt") and obj.prompt is not None:
        return obj.prompt
    if hasattr(obj, "prompt_path") and obj.prompt_path is not None:
        path = Path(obj.prompt_path).expanduser()
        if path.exists():
            return path.read_text()
    return None
