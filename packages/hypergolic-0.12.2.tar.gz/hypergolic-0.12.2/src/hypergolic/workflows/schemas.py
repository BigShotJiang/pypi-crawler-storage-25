from typing import Any

from pydantic import BaseModel


class ArtifactResponse(BaseModel):
    id: str
    session_id: str
    workflow_id: str
    state_id: str
    outcome: str
    artifact_id: str
    content: dict[str, Any]
    created_at: str


class WorkflowToolDetail(BaseModel):
    id: str
    name: str
    description: str


class WorkflowOutputSchemaDetail(BaseModel):
    outcome: str
    next_state: str | None = None
    artifact_id: str | None = None
    requires_approval: bool = False
    display: dict[str, str] | None = None
    schema_def: dict[str, Any] = {}


class WorkflowSkillDetail(BaseModel):
    id: str
    name: str


class WorkflowStateDetail(BaseModel):
    id: str
    name: str
    prompt_path: str | None = None
    skills: list[WorkflowSkillDetail] = []
    tools: list[WorkflowToolDetail] = []
    truncate_on_entry: bool = False
    include_artifacts: list[str] = []
    output_schemas: list[WorkflowOutputSchemaDetail] = []


class WorkflowDetailResponse(BaseModel):
    id: str
    name: str
    description: str
    prompt_path: str | None = None
    initial_state: str
    states: list[WorkflowStateDetail] = []


class PromptContentResponse(BaseModel):
    path: str
    content: str
