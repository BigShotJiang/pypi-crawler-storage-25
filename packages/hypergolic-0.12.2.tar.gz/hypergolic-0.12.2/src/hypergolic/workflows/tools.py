import logging
from typing import Any

from pydantic import BaseModel, create_model

from hypergolic.toolkit.primitives import OutputSchema
from hypergolic.schemas import Session
from hypergolic.tools.schemas import Tool, ToolContext, ToolOutput
from hypergolic.workflows.resolver import get_session_workflow, get_workflow

logger = logging.getLogger(__name__)

PYTHON_TYPE_MAP: dict[str, type] = {
    "string": str,
    "integer": int,
    "number": float,
    "boolean": bool,
}


def _json_schema_to_pydantic_fields(
    schema: dict[str, Any],
) -> dict[str, tuple[type, Any]]:
    properties = schema.get("properties", {})
    required = set(schema.get("required", []))
    fields: dict[str, tuple[type, Any]] = {}

    for name, prop in properties.items():
        prop_type = prop.get("type", "string")

        if prop_type == "array":
            python_type: type = list[str]
        elif prop_type == "object":
            python_type = dict[str, Any]
        else:
            python_type = PYTHON_TYPE_MAP.get(prop_type, str)

        if name in required:
            fields[name] = (python_type, ...)
        else:
            fields[name] = (python_type | None, None)  # type: ignore[assignment]

    return fields


def _build_transition_tool(
    workflow_id: str,
    state_id: str,
    output_schema: OutputSchema,
    state_name: str,
) -> Tool:
    outcome = output_schema.outcome
    tool_id = f"workflow_transition_{outcome}"

    fields = _json_schema_to_pydantic_fields(output_schema.schema_def)
    if not fields:
        fields = {"_placeholder": (str | None, None)}
    InputModel = create_model(f"WorkflowTransition_{outcome}_Input", **fields)  # type: ignore[call-overload]

    next_desc = f" \u2192 {output_schema.next_state}" if output_schema.next_state else " \u2192 exit workflow"
    description = (
        f"Complete the '{state_name}' state with outcome '{outcome}'{next_desc}. "
        f"Provide the structured output for this transition."
    )

    _wf_id = workflow_id
    _state_id = state_id
    _outcome = outcome

    async def _handle(inp: BaseModel, ctx: ToolContext) -> ToolOutput:
        from hypergolic.workflows.engine import handle_workflow_transition

        output_data = inp.model_dump(mode="json")
        output_data.pop("_placeholder", None)

        return await handle_workflow_transition(
            session=ctx.session,
            workflow_id=_wf_id,
            from_state_id=_state_id,
            outcome=_outcome,
            output=output_data,
            broadcast=ctx.broadcast,
        )

    return Tool(
        id=tool_id,
        name=f"Workflow Transition: {outcome}",
        description=description,
        input=InputModel,
        call_tool=_handle,
        requires_approval=output_schema.requires_approval,
        display=output_schema.display,
    )


def build_workflow_tools_with_state(session: Session) -> tuple[list[Tool], str | None]:
    wf_state = get_session_workflow(session.id)
    if wf_state is None:
        return [], None

    workflow_id, current_state_id = wf_state
    wf = get_workflow(workflow_id)
    if wf is None:
        logger.warning("Active workflow '%s' not found in config", workflow_id)
        return [], current_state_id

    state = None
    for s in wf.states:
        if s.id == current_state_id:
            state = s
            break
    if state is None:
        logger.warning("Active state '%s' not found in workflow '%s'", current_state_id, workflow_id)
        return [], current_state_id

    tools: list[Tool] = []
    for output_schema in state.output_schemas:
        tools.append(_build_transition_tool(
            workflow_id=workflow_id,
            state_id=current_state_id,
            output_schema=output_schema,
            state_name=state.name,
        ))

    return tools, current_state_id


def build_workflow_tools(session: Session) -> list[Tool]:
    wf_state = get_session_workflow(session.id)
    if wf_state is None:
        return []

    workflow_id, current_state_id = wf_state
    wf = get_workflow(workflow_id)
    if wf is None:
        logger.warning("Active workflow '%s' not found in config", workflow_id)
        return []

    state = None
    for s in wf.states:
        if s.id == current_state_id:
            state = s
            break
    if state is None:
        logger.warning("Active state '%s' not found in workflow '%s'", current_state_id, workflow_id)
        return []

    tools: list[Tool] = []
    for output_schema in state.output_schemas:
        tools.append(_build_transition_tool(
            workflow_id=workflow_id,
            state_id=current_state_id,
            output_schema=output_schema,
            state_name=state.name,
        ))

    return tools
