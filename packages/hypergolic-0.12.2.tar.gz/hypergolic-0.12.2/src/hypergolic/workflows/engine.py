import logging
from typing import Any

from sqlalchemy import delete as sa_delete, select, update
from sqlalchemy.sql import func

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBArtifact, DBSessionSkill, DBSessionWorkflow
from hypergolic.toolkit.primitives import Skill
from hypergolic.messages.types import BroadcastEvent, BroadcastFn
from hypergolic.schemas import Session
from hypergolic.tools.schemas import ToolOutput
from hypergolic.workflows.resolver import get_workflow, get_session_workflow

logger = logging.getLogger(__name__)


class WorkflowError(Exception):
    pass


async def activate_workflow(
    session: Session,
    workflow_id: str,
    broadcast: BroadcastFn,
) -> None:
    wf = get_workflow(workflow_id)
    if wf is None:
        raise WorkflowError(f"Workflow '{workflow_id}' not found")

    existing = get_session_workflow(session.id)
    if existing is not None:
        raise WorkflowError(
            f"Session already has active workflow '{existing[0]}'. "
            "Deactivate it first."
        )

    initial_state = None
    for s in wf.states:
        if s.id == wf.initial_state:
            initial_state = s
            break
    if initial_state is None:
        raise WorkflowError(
            f"Initial state '{wf.initial_state}' not found in workflow '{workflow_id}'"
        )

    with get_db() as db:
        db.add(DBSessionWorkflow(
            session_id=session.id,
            workflow_id=workflow_id,
            current_state_id=initial_state.id,
        ))

    if wf.skills:
        _activate_state_skills(session.id, wf.skills)

    if initial_state.skills:
        _activate_state_skills(session.id, initial_state.skills)

    await broadcast(BroadcastEvent(
        type="workflow_state_change",
        role="system",
        content=[{
            "workflow_id": workflow_id,
            "workflow_name": wf.name,
            "workflow_state_id": initial_state.id,
            "workflow_state_name": initial_state.name,
        }],
        session_id=session.id,
    ))


async def handle_workflow_transition(
    session: Session,
    workflow_id: str,
    from_state_id: str,
    outcome: str,
    output: dict[str, Any],
    broadcast: BroadcastFn | None = None,
) -> ToolOutput:
    wf = get_workflow(workflow_id)
    if wf is None:
        return ToolOutput(
            content=[{"type": "text", "text": f"Workflow '{workflow_id}' not found"}],
            is_error=True,
        )

    from_state = None
    for s in wf.states:
        if s.id == from_state_id:
            from_state = s
            break
    if from_state is None:
        return ToolOutput(
            content=[{"type": "text", "text": f"State '{from_state_id}' not found"}],
            is_error=True,
        )

    output_schema = None
    for os_def in from_state.output_schemas:
        if os_def.outcome == outcome:
            output_schema = os_def
            break
    if output_schema is None:
        return ToolOutput(
            content=[{"type": "text", "text": f"Outcome '{outcome}' not defined for state '{from_state_id}'"}],
            is_error=True,
        )

    if output_schema.artifact_id:
        with get_db() as db:
            db.add(DBArtifact(
                session_id=session.id,
                workflow_id=workflow_id,
                state_id=from_state_id,
                outcome=outcome,
                artifact_id=output_schema.artifact_id,
                content=output,
            ))

    next_state_id = output_schema.next_state

    if next_state_id is None:
        await deactivate_workflow(session.id)
        _deactivate_state_skills(session.id, from_state.skills, session)
        if wf.skills:
            _deactivate_state_skills(session.id, wf.skills, session)

        if broadcast:
            await broadcast(BroadcastEvent(
                type="workflow_state_change",
                role="system",
                content=[{
                    "workflow_id": None,
                    "workflow_name": None,
                    "workflow_state_id": None,
                    "workflow_state_name": None,
                }],
                session_id=session.id,
            ))

        return ToolOutput(
            content=[{"type": "text", "text": f"Workflow '{wf.name}' ({workflow_id}) completed. Session returned to freeform mode."}],
        )

    next_state = None
    for s in wf.states:
        if s.id == next_state_id:
            next_state = s
            break
    if next_state is None:
        return ToolOutput(
            content=[{"type": "text", "text": f"Next state '{next_state_id}' not found in workflow"}],
            is_error=True,
        )

    with get_db() as db:
        db.execute(
            update(DBSessionWorkflow)
            .where(DBSessionWorkflow.session_id == session.id)
            .where(DBSessionWorkflow.deleted_at.is_(None))
            .values(current_state_id=next_state_id)
        )

    wf_protected = {s.id for s in wf.skills} if wf.skills else None
    _transition_skills(session.id, from_state.skills, next_state.skills, session, wf_protected)

    if broadcast:
        await broadcast(BroadcastEvent(
            type="workflow_state_change",
            role="system",
            content=[{
                "workflow_id": workflow_id,
                "workflow_name": wf.name,
                "workflow_state_id": next_state.id,
                "workflow_state_name": next_state.name,
            }],
            session_id=session.id,
        ))

    result_text = f"Transitioned to state '{next_state.name}' ({next_state_id})."
    if next_state.truncate_on_entry:
        result_text += " Context will be truncated."

    return ToolOutput(
        content=[{"type": "text", "text": result_text}],
        should_truncate=next_state.truncate_on_entry,
    )


async def deactivate_workflow(session_id: str) -> None:
    with get_db() as db:
        db.execute(
            update(DBSessionWorkflow)
            .where(DBSessionWorkflow.session_id == session_id)
            .where(DBSessionWorkflow.deleted_at.is_(None))
            .values(deleted_at=func.now())
        )


def load_artifacts(
    session_id: str,
    artifact_ids: list[str],
) -> list[tuple[str, dict, str]]:
    with get_db() as db:
        rows = db.execute(
            select(DBArtifact)
            .where(DBArtifact.session_id == session_id)
            .where(DBArtifact.artifact_id.in_(artifact_ids))
            .order_by(DBArtifact.created_at.asc())
        ).scalars().all()
        return [
            (row.artifact_id, row.content, str(row.created_at))
            for row in rows
        ]


def _activate_state_skills(session_id: str, skills: list[Skill]) -> None:
    with get_db() as db:
        existing = set(
            db.execute(
                select(DBSessionSkill.skill_id)
                .where(DBSessionSkill.session_id == session_id)
            ).scalars().all()
        )
        for skill in skills:
            if skill.id not in existing:
                db.add(DBSessionSkill(
                    session_id=session_id,
                    skill_id=skill.id,
                ))


def _deactivate_state_skills(
    session_id: str,
    state_skills: list[Skill],
    session: Session,
    protected_ids: set[str] | None = None,
) -> None:
    if not state_skills:
        return
    from hypergolic.skills.resolver import resolve_roles
    role_skills: set[str] = set()
    roles = resolve_roles()
    for role in roles:
        if role["id"] == session.role:
            role_skills = set(role.get("skills", []))
            break

    all_protected = role_skills | (protected_ids or set())

    for skill in state_skills:
        if skill.id in all_protected:
            continue
        with get_db() as db:
            db.execute(
                sa_delete(DBSessionSkill)
                .where(DBSessionSkill.session_id == session_id)
                .where(DBSessionSkill.skill_id == skill.id)
            )


def _transition_skills(
    session_id: str,
    old_skills: list[Skill],
    new_skills: list[Skill],
    session: Session,
    protected_ids: set[str] | None = None,
) -> None:
    old_ids = {s.id for s in old_skills}
    new_ids = {s.id for s in new_skills}
    new_by_id = {s.id: s for s in new_skills}
    old_by_id = {s.id: s for s in old_skills}

    to_remove = [old_by_id[sid] for sid in old_ids - new_ids]
    to_add = [new_by_id[sid] for sid in new_ids - old_ids]

    if to_remove:
        _deactivate_state_skills(session_id, to_remove, session, protected_ids)
    if to_add:
        _activate_state_skills(session_id, to_add)
