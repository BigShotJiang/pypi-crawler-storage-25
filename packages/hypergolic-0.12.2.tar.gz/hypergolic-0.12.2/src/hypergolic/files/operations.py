import subprocess
from pathlib import Path

from hypergolic.files.schemas import FileNode, FileSearchMatch
from hypergolic.git.operations import git_repo_root
from hypergolic.tools.subprocess_util import has_ripgrep
from hypergolic.tools.python_search import PythonSearchParams, python_search


def _git_status_map(repo_root: Path) -> dict[str, str]:
    try:
        result = subprocess.run(
            ["git", "status", "--porcelain", "-uall"],
            capture_output=True,
            text=True,
            check=True,
            cwd=repo_root,
        )
    except (subprocess.CalledProcessError, FileNotFoundError):
        return {}

    status_map: dict[str, str] = {}
    for line in result.stdout.splitlines():
        if len(line) < 4:
            continue
        xy = line[:2]
        filepath = line[3:].strip()
        if " -> " in filepath:
            filepath = filepath.split(" -> ", 1)[1]
        status_map[filepath] = xy.strip()
    return status_map


def _git_ignored_set(repo_root: Path) -> set[str]:
    try:
        result = subprocess.run(
            ["git", "ls-files", "--others", "--ignored", "--exclude-standard", "--directory"],
            capture_output=True,
            text=True,
            check=True,
            cwd=repo_root,
        )
    except (subprocess.CalledProcessError, FileNotFoundError):
        return set()

    ignored: set[str] = set()
    for line in result.stdout.splitlines():
        entry = line.strip().rstrip("/")
        if entry:
            ignored.add(entry)
    return ignored


def _build_tree(
    directory: Path,
    repo_root: Path,
    status_map: dict[str, str],
    ignored_set: set[str],
) -> list[FileNode]:
    nodes: list[FileNode] = []
    try:
        entries = sorted(directory.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
    except PermissionError:
        return nodes

    for entry in entries:
        if entry.name.startswith("."):
            continue

        rel = str(entry.relative_to(repo_root))

        is_ignored = rel in ignored_set or any(
            rel.startswith(ign + "/") or rel == ign for ign in ignored_set
        )

        if entry.is_dir():
            if entry.name == "node_modules" or entry.name == "__pycache__":
                continue
            children = _build_tree(entry, repo_root, status_map, ignored_set)
            git_status = "ignored" if is_ignored else _dir_aggregate_status(rel, status_map)
            nodes.append(FileNode(
                name=entry.name,
                path=rel,
                is_dir=True,
                git_status=git_status,
                children=children,
            ))
        else:
            if is_ignored:
                git_status = "ignored"
            else:
                git_status = status_map.get(rel)
            nodes.append(FileNode(
                name=entry.name,
                path=rel,
                is_dir=False,
                git_status=git_status,
            ))

    return nodes


def _dir_aggregate_status(dir_rel: str, status_map: dict[str, str]) -> str | None:
    prefix = dir_rel + "/"
    statuses = {v for k, v in status_map.items() if k.startswith(prefix)}
    if not statuses:
        return None
    if "M" in statuses or "MM" in statuses or "AM" in statuses:
        return "M"
    if "A" in statuses:
        return "A"
    if "??" in statuses:
        return "??"
    return next(iter(statuses))


def build_file_tree(repo_root: Path | None = None) -> list[FileNode]:
    root = repo_root or git_repo_root()
    status_map = _git_status_map(root)
    ignored_set = _git_ignored_set(root)
    return _build_tree(root, root, status_map, ignored_set)


def get_repo_root(repo_root: Path | None = None) -> str:
    return str(repo_root or git_repo_root())


def search_file_names(
    query: str, repo_root: Path, respect_gitignore: bool, include_hidden: bool, max_results: int,
) -> list[FileSearchMatch]:
    cmd = ["git", "ls-files", "--cached", "--others"]
    if respect_gitignore:
        cmd.append("--exclude-standard")
    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, check=True, cwd=repo_root, timeout=10,
        )
    except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired):
        return []

    query_lower = query.lower()
    query_parts = query_lower.split()
    matches: list[FileSearchMatch] = []

    for line in result.stdout.splitlines():
        path = line.strip()
        if not path:
            continue
        if not include_hidden and any(part.startswith(".") for part in Path(path).parts):
            continue
        path_lower = path.lower()
        if all(part in path_lower for part in query_parts):
            matches.append(FileSearchMatch(path=path))
            if len(matches) >= max_results:
                break

    def sort_key(m: FileSearchMatch) -> tuple[int, int, str]:
        name = Path(m.path).name.lower()
        basename_match = 0 if all(p in name for p in query_parts) else 1
        return (basename_match, len(m.path), m.path.lower())

    matches.sort(key=sort_key)
    return matches[:max_results]


def _search_contents_rg(
    query: str, repo_root: Path, respect_gitignore: bool, include_hidden: bool, max_results: int,
) -> list[FileSearchMatch]:
    cmd = ["rg", "--line-number", "--color=never", "--no-heading",
           "--max-count", "3", "--fixed-strings", "--ignore-case"]
    if not respect_gitignore:
        cmd.append("--no-ignore")
    if include_hidden:
        cmd.append("--hidden")
    cmd.extend([query, str(repo_root)])

    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=10, cwd=repo_root,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return []

    if result.returncode > 1:
        return []

    return _parse_search_output(result.stdout, repo_root, max_results)


def _search_contents_python(
    query: str, repo_root: Path, respect_gitignore: bool, include_hidden: bool, max_results: int,
) -> list[FileSearchMatch]:
    params = PythonSearchParams(
        pattern=query,
        directory=str(repo_root),
        fixed_string=True,
        case_sensitive=False,
        include_hidden=include_hidden,
        max_results=3,
        show_line_numbers=True,
    )
    result = python_search(params)
    if result.returncode != 0:
        return []

    return _parse_search_output(result.stdout, repo_root, max_results)


def _parse_search_output(
    stdout: str, repo_root: Path, max_results: int,
) -> list[FileSearchMatch]:
    matches: list[FileSearchMatch] = []
    for line in stdout.splitlines():
        if not line or line == "--":
            continue
        try:
            path_rest = line.split(":", 2)
            if len(path_rest) < 3:
                continue
            raw_path, line_no_str, text = path_rest
            try:
                rel_path = str(Path(raw_path).relative_to(repo_root))
            except ValueError:
                rel_path = raw_path
            matches.append(FileSearchMatch(
                path=rel_path, line=int(line_no_str), text=text.strip()[:200],
            ))
        except (ValueError, TypeError):
            continue
        if len(matches) >= max_results:
            break

    return matches


def search_file_contents(
    query: str, repo_root: Path, respect_gitignore: bool, include_hidden: bool, max_results: int,
) -> list[FileSearchMatch]:
    if has_ripgrep():
        return _search_contents_rg(query, repo_root, respect_gitignore, include_hidden, max_results)
    return _search_contents_python(query, repo_root, respect_gitignore, include_hidden, max_results)
