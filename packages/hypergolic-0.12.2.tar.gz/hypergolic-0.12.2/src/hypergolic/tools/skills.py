from enum import Enum
from typing import Any

from pydantic import BaseModel
from sqlalchemy import select

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBSessionSkill
from hypergolic.skills.resolver import get_skill_prompt_content, resolve_skills
from hypergolic.tools.schemas import Tool, ToolContext, ToolOutput


# TODO: Consider moving handle_skills + build_skills_description to base/tools/skills.py.
# Option A: Split — move the static handler & description builder to base/tools/,
#   keep dynamic enum construction + tool assembly here (cleanest, minimal change).
# Option B: Add a DynamicTool / factory pattern to toolkit primitives so base tools
#   can support session-dependent input schemas (bigger architectural shift).


async def handle_skills(inp: BaseModel, ctx: ToolContext) -> ToolOutput:

    skill_id = inp.skill_id  # type: ignore[attr-defined]
    session = ctx.session

    with get_db() as db:
        already_active = db.execute(
            select(DBSessionSkill)
            .where(DBSessionSkill.session_id == session.id)
            .where(DBSessionSkill.skill_id == skill_id)
        ).scalar_one_or_none()
        if already_active:
            return ToolOutput(
                content=[{"type": "text", "text": f"Skill '{skill_id}' is already active."}],
            )

    result = get_skill_prompt_content(skill_id)
    if result is None:
        return ToolOutput(
            content=[{"type": "text", "text": f"Skill '{skill_id}' not found."}],
            is_error=True,
        )

    skill_name, prompt_content = result

    if prompt_content is None:
        return ToolOutput(
            content=[{"type": "text", "text": f"Skill '{skill_id}' prompt file not found."}],
            is_error=True,
        )

    with get_db() as db:
        db.add(DBSessionSkill(
            session_id=ctx.session.id,
            skill_id=skill_id,
        ))

    return ToolOutput(
        content=[{"type": "text", "text": f"Skill Added: {skill_name}\n\n{prompt_content}"}],
    )


def build_skills_description(skills: list[dict[str, Any]]) -> str:
    skill_ids = {s["id"] for s in skills}
    desc = "Activate a skill to gain specialized expertise for the current session.\n\n"
    if "product-management" in skill_ids:
        desc += (
            "When a user asks for a new feature or significant change, "
            "activate `product-management` to collaborate on requirements "
            "before implementation.\n\n"
        )
    desc += "Available skills:\n"
    for skill in skills:
        desc += f"- `{skill['id']}`: {skill['description']}\n"
    return desc.rstrip()


def build_skills_tool() -> Tool | None:
    skills = resolve_skills()
    if not skills:
        return None

    skill_ids = [s["id"] for s in skills]
    SkillIdEnum = Enum("SkillIdEnum", {sid: sid for sid in skill_ids}, type=str)

    class SkillsInput(BaseModel):
        skill_id: SkillIdEnum

    return Tool(
        id="skills",
        name="Skills",
        description=build_skills_description(skills),
        input=SkillsInput,
        call_tool=handle_skills,
    )
