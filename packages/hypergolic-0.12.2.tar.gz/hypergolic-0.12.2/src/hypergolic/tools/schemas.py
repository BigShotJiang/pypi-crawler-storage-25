from dataclasses import dataclass, field
from typing import Awaitable, Callable, Generic, TypeVar, Type

from anthropic.types import ToolUnionParam
from anthropic.types.tool_result_block_param import Content
from pydantic import BaseModel

from hypergolic.messages.types import BroadcastFn
from hypergolic.schemas import Session

T = TypeVar("T", bound=BaseModel)


def _strip_schema_noise(schema: dict) -> None:
    schema.pop("title", None)
    # Ensure additionalProperties is False for all object types
    if schema.get("type") == "object" or "properties" in schema:
        schema["additionalProperties"] = False
    for value in schema.values():
        if isinstance(value, dict):
            _strip_schema_noise(value)
        elif isinstance(value, list):
            for item in value:
                if isinstance(item, dict):
                    _strip_schema_noise(item)


ToolContent = list[Content]


@dataclass
class ToolContext:
    session: Session
    broadcast: BroadcastFn
    tool_id: str


@dataclass
class ToolOutput:
    content: list[Content] = field(default_factory=list)
    is_error: bool = False
    should_truncate: bool = False


class Tool(BaseModel, Generic[T]):
    id: str
    name: str
    description: str
    input: Type[T]
    call_tool: Callable[[T, ToolContext], Awaitable[ToolOutput]]
    should_truncate: bool = False
    requires_approval: bool = False
    display: dict[str, str] | None = None
    source: str = "standard"

    model_config = {"arbitrary_types_allowed": True}

    def to_param(self) -> ToolUnionParam:
        schema = self.input.model_json_schema()
        schema["additionalProperties"] = False
        _strip_schema_noise(schema)

        return {
            "name": self.id,
            "description": self.description,
            "input_schema": schema,
        }
