import fnmatch
import re
import subprocess
from dataclasses import dataclass
from pathlib import Path

from hypergolic.tools.gitignore import collect_ignore_rules

SKIP_DIRS = {"node_modules", "__pycache__", ".git", ".hg", ".svn", "venv", ".venv", ".tox", ".eggs"}


@dataclass
class PythonSearchParams:
    pattern: str
    directory: str = "."
    fixed_string: bool = False
    case_sensitive: bool = True
    include_hidden: bool = False
    file_glob: str | None = None
    max_depth: int | None = None
    context_lines: int = 0
    max_results: int | None = None
    invert_match: bool = False
    files_only: bool = False
    multiline: bool = False
    show_line_numbers: bool = True


def _compile_pattern(params: PythonSearchParams) -> re.Pattern:
    pat = re.escape(params.pattern) if params.fixed_string else params.pattern
    flags = re.DOTALL if params.multiline else 0
    if not params.case_sensitive:
        flags |= re.IGNORECASE
    return re.compile(pat, flags)


def _walk_files(root: Path, params: PythonSearchParams):
    rules = collect_ignore_rules(root)

    def _recurse(directory: Path, depth: int):
        if params.max_depth is not None and depth > params.max_depth:
            return
        try:
            entries = sorted(directory.iterdir(), key=lambda p: p.name.lower())
        except PermissionError:
            return

        for entry in entries:
            if not params.include_hidden and entry.name.startswith("."):
                continue
            if entry.is_dir():
                if entry.name in SKIP_DIRS:
                    continue
                if rules.is_ignored(entry):
                    continue
                yield from _recurse(entry, depth + 1)
            elif entry.is_file():
                if rules.is_ignored(entry):
                    continue
                if params.file_glob and not fnmatch.fnmatch(entry.name, params.file_glob):
                    continue
                yield entry

    yield from _recurse(root, 1)


def _is_binary(path: Path) -> bool:
    try:
        chunk = path.read_bytes()[:8192]
        return b"\x00" in chunk
    except (OSError, PermissionError):
        return True


def _search_file_multiline(
    path: Path, root: Path, regex: re.Pattern, params: PythonSearchParams,
) -> list[str]:
    try:
        content = path.read_text(errors="replace")
    except (OSError, PermissionError):
        return []

    if regex.search(content):
        rel = str(path.relative_to(root))
        if params.files_only:
            return [rel]
        return [f"{rel}:1:{content.splitlines()[0] if content.splitlines() else ''}"]
    return []


def _search_file(
    path: Path, root: Path, regex: re.Pattern, params: PythonSearchParams,
) -> list[str]:
    if _is_binary(path):
        return []

    if params.multiline:
        return _search_file_multiline(path, root, regex, params)

    try:
        lines = path.read_text(errors="replace").splitlines()
    except (OSError, PermissionError):
        return []

    rel = str(path.relative_to(root))

    if params.files_only:
        for line in lines:
            match = regex.search(line)
            matched = (match is not None) != params.invert_match
            if matched:
                return [rel]
        return []

    matching_indices: list[int] = []
    for i, line in enumerate(lines):
        match = regex.search(line)
        matched = (match is not None) != params.invert_match
        if matched:
            matching_indices.append(i)
            if params.max_results is not None and len(matching_indices) >= params.max_results:
                break

    if not matching_indices:
        return []

    output_indices: set[int] = set()
    for idx in matching_indices:
        start = max(0, idx - params.context_lines)
        end = min(len(lines) - 1, idx + params.context_lines)
        for i in range(start, end + 1):
            output_indices.add(i)

    result: list[str] = []
    sorted_indices = sorted(output_indices)
    prev_idx = -2
    for i in sorted_indices:
        if prev_idx >= 0 and i > prev_idx + 1:
            result.append("--")
        line_num = i + 1
        sep = ":" if i in matching_indices else "-"
        if params.show_line_numbers:
            result.append(f"{rel}:{line_num}{sep}{lines[i]}")
        else:
            result.append(f"{rel}{sep}{lines[i]}")
        prev_idx = i

    return result


def python_search(params: PythonSearchParams) -> subprocess.CompletedProcess:
    root = Path(params.directory).resolve()
    regex = _compile_pattern(params)

    all_output: list[str] = []
    match_count = 0

    for file_path in _walk_files(root, params):
        file_results = _search_file(file_path, root, regex, params)
        if file_results:
            if params.files_only:
                all_output.extend(file_results)
                match_count += len(file_results)
            else:
                match_lines = [line for line in file_results if line != "--" and not _is_context_line(line)]
                match_count += len(match_lines)
                all_output.extend(file_results)

            if params.max_results is not None and match_count >= params.max_results:
                break

    stdout = "\n".join(all_output) if all_output else ""
    returncode = 0 if all_output else 1

    return subprocess.CompletedProcess(
        args=["python-search"], returncode=returncode, stdout=stdout, stderr="",
    )


def _is_context_line(line: str) -> bool:
    parts = line.split("-", 2)
    if len(parts) >= 2:
        try:
            int(parts[1])
            return True
        except ValueError:
            pass
    return False
