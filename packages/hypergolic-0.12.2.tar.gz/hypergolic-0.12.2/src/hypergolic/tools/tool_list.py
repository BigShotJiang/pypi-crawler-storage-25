import logging
from copy import deepcopy
from enum import Enum
from typing import Any

from anthropic.types import ToolUnionParam
from pydantic import BaseModel

from hypergolic.toolkit.app.core import App
from hypergolic.toolkit.app.state import get_app
from hypergolic.toolkit.bridge import convert_tools
from hypergolic.toolkit.primitives import Workflow as ToolkitWorkflow
from hypergolic.toolkit.project import Project as ToolkitProject
from hypergolic.mcptools.tool_bridge import get_mcp_tools_for_session, parse_mcp_tool_id
from hypergolic.schemas import Session
from hypergolic.skills.resolver import get_active_skill_ids
from hypergolic.mcptools.sessions import get_enabled_servers
from hypergolic.tools.schemas import Tool
from hypergolic.tools.skills import handle_skills, build_skills_description
from hypergolic.tools.activate_workflow import handle_activate_workflow, build_workflow_description
from hypergolic.dispatch.conclude import ConcludeTool
from hypergolic.workflows.resolver import get_session_workflow
from hypergolic.workflows.tools import build_workflow_tools, build_workflow_tools_with_state

logger = logging.getLogger(__name__)


def _find_workflow(
    app: App, project: ToolkitProject | None, workflow_id: str
) -> ToolkitWorkflow | None:
    for wf in app.workflows:
        if wf.id == workflow_id:
            return wf
    if project:
        for wf in project.workflows:
            if wf.id == workflow_id:
                return wf
    return None


def _build_skills_tool_from_app(app: App, session: Session) -> Tool | None:
    skills_data: list[dict[str, Any]] = []
    seen: set[str] = set()

    for s in app.skills:
        if s.id not in seen:
            skills_data.append({"id": s.id, "name": s.name, "description": s.description})
            seen.add(s.id)

    project = app.get_project(session.project_id)
    if project:
        for s in project.skills:
            if s.id not in seen:
                skills_data.append({"id": s.id, "name": s.name, "description": s.description})
                seen.add(s.id)

    role = app.get_role(session.role)
    if role:
        for s in role.skills:
            if s.id not in seen:
                skills_data.append({"id": s.id, "name": s.name, "description": s.description})
                seen.add(s.id)

    wf_state = get_session_workflow(session.id)
    if wf_state:
        workflow_id, _ = wf_state
        wf = _find_workflow(app, project, workflow_id)
        if wf:
            for s in wf.skills:
                if s.id not in seen:
                    skills_data.append({"id": s.id, "name": s.name, "description": s.description})
                    seen.add(s.id)

    if not skills_data:
        return None

    skill_ids = [s["id"] for s in skills_data]
    SkillIdEnum = Enum("SkillIdEnum", {sid: sid for sid in skill_ids}, type=str)

    class SkillsInput(BaseModel):
        skill_id: SkillIdEnum

    return Tool(
        id="skills",
        name="Skills",
        description=build_skills_description(skills_data),
        input=SkillsInput,
        call_tool=handle_skills,
    )


def _build_activate_workflow_tool_from_app(
    app: App, project: ToolkitProject | None, session: Session
) -> Tool | None:
    wf_state = get_session_workflow(session.id)
    if wf_state is not None:
        return None

    wf_dicts: list[dict[str, Any]] = []
    wf_ids: list[str] = []
    seen: set[str] = set()

    for wf in app.workflows:
        if wf.id not in seen:
            wf_dicts.append({"id": wf.id, "name": wf.name, "description": wf.description})
            wf_ids.append(wf.id)
            seen.add(wf.id)

    if project:
        for wf in project.workflows:
            if wf.id not in seen:
                wf_dicts.append({"id": wf.id, "name": wf.name, "description": wf.description})
                wf_ids.append(wf.id)
                seen.add(wf.id)

    if not wf_dicts:
        return None

    WorkflowIdEnum = Enum("WorkflowIdEnum", {wid: wid for wid in wf_ids}, type=str)

    class ActivateWorkflowInput(BaseModel):
        workflow_id: WorkflowIdEnum

    return Tool(
        id="activate_workflow",
        name="Activate Workflow",
        description=build_workflow_description(wf_dicts),
        input=ActivateWorkflowInput,
        call_tool=handle_activate_workflow,
    )


def build_tools(session: Session) -> list[Tool]:
    app = get_app()
    tools: dict[str, Tool] = {}

    for t in convert_tools(app.tools):
        tools[t.id] = t

    project = app.get_project(session.project_id)
    if project:
        for t in convert_tools(project.tools):
            tools[t.id] = t

    role = app.get_role(session.role)
    assert role is not None, f"Role '{session.role}' not found"
    for t in convert_tools(role.tools):
        tools[t.id] = t

    active_skill_ids = get_active_skill_ids(session.id)
    for skill_id in active_skill_ids:
        skill = app.get_skill(skill_id)
        if skill and skill.tools:
            for t in convert_tools(skill.tools):
                tools[t.id] = t

    wf_state = get_session_workflow(session.id)
    if wf_state:
        workflow_id, current_state_id = wf_state
        wf = _find_workflow(app, project, workflow_id)
        if wf:
            for t in convert_tools(wf.tools):
                tools[t.id] = t
            for state in wf.states:
                if state.id == current_state_id and state.tools:
                    for t in convert_tools(state.tools):
                        tools[t.id] = t

    skills_tool = _build_skills_tool_from_app(app, session)
    if skills_tool:
        tools[skills_tool.id] = skills_tool

    workflow_tool = _build_activate_workflow_tool_from_app(app, project, session)
    if workflow_tool:
        tools[workflow_tool.id] = workflow_tool

    enabled_servers = get_enabled_servers(session.id)
    if enabled_servers:
        mcp_tools = get_mcp_tools_for_session(enabled_servers)
        for t in mcp_tools:
            t.source = "mcp"
            tools[t.id] = t

    workflow_tools = build_workflow_tools(session)
    for wt in workflow_tools:
        if wt.id not in tools:
            tools[wt.id] = wt

    if session.parent_id and ConcludeTool.id not in tools:
        tools[ConcludeTool.id] = ConcludeTool

    return list(tools.values())


def build_tools_with_reasons(session: Session) -> list[tuple[Tool, str]]:
    app = get_app()
    tools: dict[str, Tool] = {}
    reasons: dict[str, str] = {}

    for t in convert_tools(app.tools):
        tools[t.id] = t
        reasons[t.id] = "app"

    project = app.get_project(session.project_id)
    if project:
        for t in convert_tools(project.tools):
            tools[t.id] = t
            reasons[t.id] = "project"

    role = app.get_role(session.role)
    assert role is not None, f"Role '{session.role}' not found"
    for t in convert_tools(role.tools):
        tools[t.id] = t
        reasons[t.id] = "role"

    active_skill_ids = get_active_skill_ids(session.id)
    for skill_id in active_skill_ids:
        skill = app.get_skill(skill_id)
        if skill and skill.tools:
            for t in convert_tools(skill.tools):
                tools[t.id] = t
                reasons[t.id] = f"skill:{skill_id}"

    wf_state = get_session_workflow(session.id)
    if wf_state:
        workflow_id, current_state_id = wf_state
        wf = _find_workflow(app, project, workflow_id)
        if wf:
            for t in convert_tools(wf.tools):
                tools[t.id] = t
                reasons[t.id] = f"workflow:{workflow_id}"
            for state in wf.states:
                if state.id == current_state_id and state.tools:
                    for t in convert_tools(state.tools):
                        tools[t.id] = t
                        reasons[t.id] = f"workflow_state:{current_state_id}"

    skills_tool = _build_skills_tool_from_app(app, session)
    if skills_tool:
        tools[skills_tool.id] = skills_tool
        reasons[skills_tool.id] = "app"

    workflow_tool = _build_activate_workflow_tool_from_app(app, project, session)
    if workflow_tool:
        tools[workflow_tool.id] = workflow_tool
        reasons[workflow_tool.id] = "app"

    enabled_servers = get_enabled_servers(session.id)
    if enabled_servers:
        mcp_tools = get_mcp_tools_for_session(enabled_servers)
        for t in mcp_tools:
            t.source = "mcp"
            tools[t.id] = t
            mcp_parsed = parse_mcp_tool_id(t.id)
            server_name = mcp_parsed[0] if mcp_parsed else "unknown"
            reasons[t.id] = f"mcp:{server_name}"

    workflow_transition_tools, transition_state_id = build_workflow_tools_with_state(session)
    for wt in workflow_transition_tools:
        if wt.id not in tools:
            tools[wt.id] = wt
            if transition_state_id:
                reasons[wt.id] = f"workflow_state:{transition_state_id}"
            else:
                reasons[wt.id] = "app"

    if session.parent_id and ConcludeTool.id not in tools:
        tools[ConcludeTool.id] = ConcludeTool
        reasons[ConcludeTool.id] = "app"

    return [(tool, reasons[tool.id]) for tool in tools.values()]


def get_tool_schemas(tools: list[Tool]) -> list[ToolUnionParam]:
    return [t.to_param() for t in tools]


def set_tools_cache_breakpoint(
    tool_schemas: list[ToolUnionParam],
) -> list[ToolUnionParam]:
    schemas = deepcopy(tool_schemas)
    schemas[-1]["cache_control"] = {"type": "ephemeral"}
    return schemas
