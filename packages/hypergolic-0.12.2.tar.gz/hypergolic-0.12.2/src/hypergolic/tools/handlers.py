import asyncio
import logging
from dataclasses import dataclass
from typing import Any, Callable, Awaitable

from anthropic.types import MessageParam, ToolResultBlockParam, ToolUseBlock
from anthropic.types.message import Message
from anthropic.types.tool_result_block_param import Content

from hypergolic.toolkit.app.state import get_app
from hypergolic.toolkit.bridge import evaluate_toolkit_approval
from hypergolic.toolkit.primitives import Tool as ToolkitTool
from hypergolic.mcptools.tool_bridge import execute_mcp_tool
from hypergolic.messages.types import BroadcastFn
from hypergolic.schemas import Session
from hypergolic.skills.resolver import get_active_skill_ids
from hypergolic.tools.schemas import Tool, ToolContext, ToolOutput
from hypergolic.workflows.resolver import get_session_workflow

logger = logging.getLogger(__name__)

MAX_TOOL_OUTPUT_CHARS = 80_000


def _result_block(tool_use_id: str, output: ToolOutput) -> ToolResultBlockParam:
    return ToolResultBlockParam(
        tool_use_id=tool_use_id,
        type="tool_result",
        content=output.content,
        is_error=output.is_error,
    )


def _truncate_tool_output(output: ToolOutput, limit: int = MAX_TOOL_OUTPUT_CHARS) -> ToolOutput:
    total_chars = 0
    for block in output.content:
        if isinstance(block, dict) and block.get("type") == "text":
            total_chars += len(block.get("text", ""))

    if total_chars <= limit:
        return output

    truncated_content: list[Content] = []
    remaining = limit

    for block in output.content:
        if isinstance(block, dict) and block.get("type") == "text":
            text = block.get("text", "")
            if len(text) <= remaining:
                truncated_content.append(block)
                remaining -= len(text)
            elif remaining > 0:
                truncated_content.append({"type": "text", "text": text[:remaining]})
                remaining = 0
        else:
            truncated_content.append(block)

    truncated_content.append({
        "type": "text",
        "text": f"\n\n[Output truncated: {total_chars:,} chars exceeded {limit:,} char limit. Request smaller ranges or more specific queries.]",
    })

    logger.warning("Tool output truncated: %s chars -> %s char limit", total_chars, limit)

    return ToolOutput(content=truncated_content, is_error=output.is_error)


@dataclass
class ToolUseResult:
    message: MessageParam
    should_truncate: bool = False


@dataclass
class DisplayBlock:
    field: str
    type: str
    label: str
    value: Any


@dataclass
class ApprovalRequest:
    tool_use_id: str
    tool_name: str
    tool_input: dict[str, Any]
    session_id: str | None = None
    display_blocks: list[DisplayBlock] | None = None
    tool_display_name: str | None = None


@dataclass
class AnnotationItem:
    highlighted_text: str
    comment: str


@dataclass
class ApprovalResponse:
    approved: bool
    denial_reason: str | None = None
    annotations: list[AnnotationItem] | None = None


ApprovalCallback = Callable[[ApprovalRequest], Awaitable[ApprovalResponse]]


async def _execute_tool(tool: Tool, raw_input: Any, ctx: ToolContext) -> ToolOutput:
    try:
        parsed_input = tool.input.model_validate(raw_input)
        return await tool.call_tool(parsed_input, ctx)
    except Exception as e:
        logger.error("Tool '%s' failed: %s", tool.id, e, exc_info=True)
        return ToolOutput(
            content=[{"type": "text", "text": f"Error with tool call: {e}"}],
            is_error=True,
        )


def find_toolkit_tool(tool_id: str, session: Session) -> ToolkitTool | None:
    app = get_app()

    for t in app.tools:
        if t.id == tool_id:
            return t

    project = app.get_project(session.project_id)
    if project:
        for t in project.tools:
            if t.id == tool_id:
                return t

    role = app.get_role(session.role)
    if role:
        for t in role.tools:
            if t.id == tool_id:
                return t

    active_skill_ids = get_active_skill_ids(session.id)
    for skill_id in active_skill_ids:
        skill = app.get_skill(skill_id)
        if skill:
            for t in skill.tools:
                if t.id == tool_id:
                    return t

    wf_state = get_session_workflow(session.id)
    if wf_state:
        workflow_id, current_state_id = wf_state
        for wf in app.workflows:
            if wf.id == workflow_id:
                for t in wf.tools:
                    if t.id == tool_id:
                        return t
                for state in wf.states:
                    if state.id == current_state_id:
                        for t in state.tools:
                            if t.id == tool_id:
                                return t
        if project:
            for wf in project.workflows:
                if wf.id == workflow_id:
                    for t in wf.tools:
                        if t.id == tool_id:
                            return t
                    for state in wf.states:
                        if state.id == current_state_id:
                            for t in state.tools:
                                if t.id == tool_id:
                                    return t

    return None


_REQUIRE_APPROVAL = "REQUIRE_APPROVAL"
_ALLOW = "ALLOW"
_DENY = "DENY"


async def _process_single_tool(
    content: ToolUseBlock,
    tool_map: dict[str, Tool],
    session: Session,
    broadcast: BroadcastFn,
    approval_callback: ApprovalCallback | None,
) -> tuple[ToolResultBlockParam, bool]:
    tool = tool_map.get(content.name)
    if tool is None:
        logger.error("Tool '%s' not found in tool_map (available: %s)", content.name, list(tool_map.keys()))
        block = ToolResultBlockParam(
            tool_use_id=content.id,
            type="tool_result",
            content=f"Tool '{content.name}' is not available. Check active skills and available tools.",
            is_error=True,
        )
        return block, False

    tool_input = content.input if isinstance(content.input, dict) else {}

    toolkit_tool = find_toolkit_tool(content.name, session)

    if toolkit_tool:
        decision = evaluate_toolkit_approval(toolkit_tool, tool_input, session)
        approval_decision = decision.decision
    elif content.name.startswith("mcp_"):
        approval_decision = _REQUIRE_APPROVAL
    else:
        approval_decision = _REQUIRE_APPROVAL if tool.requires_approval else _ALLOW

    if approval_decision == _DENY:
        return _result_block(content.id, ToolOutput(
            content=[{"type": "text", "text": "Tool call denied by approval rule."}],
            is_error=True,
        )), False

    approved_annotations: list[AnnotationItem] | None = None
    if approval_decision == _REQUIRE_APPROVAL:
        if approval_callback:
            display_blocks = None
            if tool.display:
                display_blocks = [
                    DisplayBlock(
                        field=fname,
                        type=rtype,
                        label=fname.replace("_", " ").title(),
                        value=tool_input.get(fname),
                    )
                    for fname, rtype in tool.display.items()
                    if tool_input.get(fname) is not None
                ]
            request = ApprovalRequest(
                tool_use_id=content.id,
                tool_name=content.name,
                tool_input=tool_input,
                session_id=session.id,
                display_blocks=display_blocks,
                tool_display_name=tool.name,
            )
            response = await approval_callback(request)

            if not response.approved:
                denial_text = "User denied tool call."
                if response.denial_reason:
                    denial_text += f" Reason: {response.denial_reason}"
                if response.annotations:
                    denial_text += "\n\nUser annotations:\n"
                    for ann in response.annotations:
                        denial_text += f"- \"{ann.highlighted_text}\": {ann.comment}\n"
                return _result_block(content.id, ToolOutput(
                    content=[{"type": "text", "text": denial_text}],
                    is_error=True,
                )), False

            approved_annotations = response.annotations

    if content.name.startswith("mcp_"):
        raw = content.input if isinstance(content.input, dict) else {}
        output = await execute_mcp_tool(content.name, raw)
    else:
        ctx = ToolContext(
            session=session,
            broadcast=broadcast,
            tool_id=tool.id,
        )
        output = await _execute_tool(tool, content.input, ctx)

    output = _truncate_tool_output(output)

    trigger_truncation = (tool.should_truncate or output.should_truncate) and not output.is_error

    if approved_annotations and not output.is_error:
        annotation_text = "\n\nUser feedback on this artifact:\n"
        for ann in approved_annotations:
            annotation_text += f"- \"{ann.highlighted_text}\": {ann.comment}\n"
        output = ToolOutput(
            content=[*output.content, {"type": "text", "text": annotation_text}],
            is_error=output.is_error,
            should_truncate=output.should_truncate,
        )

    return _result_block(content.id, output), trigger_truncation


async def handle_tool_use(
    agent_message: Message,
    tools: list[Tool],
    session: Session,
    broadcast: BroadcastFn,
    approval_callback: ApprovalCallback | None = None,
) -> ToolUseResult:
    tool_map = {tool.id: tool for tool in tools}

    tool_use_blocks = [
        content for content in agent_message.content
        if isinstance(content, ToolUseBlock)
    ]

    results = await asyncio.gather(*[
        _process_single_tool(content, tool_map, session, broadcast, approval_callback)
        for content in tool_use_blocks
    ])

    tool_result_blocks: list[ToolResultBlockParam] = []
    trigger_truncation = False
    for block, should_truncate in results:
        tool_result_blocks.append(block)
        if should_truncate:
            trigger_truncation = True

    return ToolUseResult(
        message=MessageParam(role="user", content=tool_result_blocks),
        should_truncate=trigger_truncation,
    )
