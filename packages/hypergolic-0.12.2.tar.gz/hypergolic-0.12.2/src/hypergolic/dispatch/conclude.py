import logging
from datetime import datetime, timezone
from typing import Literal

from pydantic import BaseModel
from sqlalchemy import update

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBSession
from hypergolic.dispatch.core import DispatchResult, resolve_dispatch
from hypergolic.enums import SessionStatus
from hypergolic.messages.types import BroadcastEvent
from hypergolic.sessions.retrospective import schedule_retrospective
from hypergolic.sessions.status import set_session_status_and_broadcast
from hypergolic.tools.schemas import Tool, ToolContext, ToolOutput

logger = logging.getLogger(__name__)


class ConcludeInput(BaseModel):
    outcome: Literal["success", "failure", "suppressed"]
    conclusion: str


def _set_concluded_at(session_id: str) -> datetime:
    concluded_at = datetime.now(timezone.utc)
    with get_db() as db:
        db.execute(
            update(DBSession)
            .where(DBSession.id == session_id)
            .values(concluded_at=concluded_at)
        )
    return concluded_at


async def _handle_conclude(inp: ConcludeInput, ctx: ToolContext) -> ToolOutput:
    result = DispatchResult(outcome=inp.outcome, conclusion=inp.conclusion)
    resolved = resolve_dispatch(ctx.session.id, result)

    if not resolved:
        parent_id = ctx.session.parent_id
        if parent_id:
            await set_session_status_and_broadcast(
                ctx.session.id, SessionStatus.CONCLUDED, ctx.broadcast,
            )
            _set_concluded_at(ctx.session.id)
            schedule_retrospective(ctx.session.id, ctx.broadcast)
            return ToolOutput(
                content=[{"type": "text", "text": f"Session concluded with outcome: {inp.outcome}"}],
            )
        return ToolOutput(
            content=[{"type": "text", "text": "No pending dispatch to conclude."}],
            is_error=True,
        )

    await set_session_status_and_broadcast(
        ctx.session.id, SessionStatus.CONCLUDED, ctx.broadcast,
    )
    _set_concluded_at(ctx.session.id)

    parent_id = ctx.session.parent_id
    if parent_id:
        await ctx.broadcast(BroadcastEvent(
            type="dispatch_concluded",
            role="system",
            content=[],
            session_id=ctx.session.id,
        ))

    schedule_retrospective(ctx.session.id, ctx.broadcast)

    return ToolOutput(
        content=[{"type": "text", "text": f"Session concluded with outcome: {inp.outcome}"}],
    )


ConcludeTool = Tool(
    id="conclude",
    name="conclude",
    description="Conclude this dispatched session and return the result to the parent session. Use 'success' when you have an answer, 'failure' when you cannot answer, or 'suppressed' to cancel",
    input=ConcludeInput,
    call_tool=_handle_conclude,
    source="dispatch",
)
