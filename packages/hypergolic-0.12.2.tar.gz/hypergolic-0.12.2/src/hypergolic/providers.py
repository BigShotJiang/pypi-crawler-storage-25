from anthropic import AsyncAnthropic
from anthropic.types import MessageParam, ModelParam

from hypergolic.config.settings import settings
from hypergolic.enums import ModelTier


def create_client():
    return AsyncAnthropic(
        api_key=settings.HYPERGOLIC_API_KEY,
        base_url=settings.HYPERGOLIC_BASE_URL,
    )


def tier_to_model_id(tier: ModelTier) -> ModelParam:
    match tier:
        case ModelTier.LOW:
            return "claude-haiku-4-5"
        case ModelTier.MEDIUM:
            return "claude-sonnet-4-6"
        case ModelTier.HIGH:
            return "claude-opus-4-6"


async def generate_text(
    *,
    system: str,
    messages: list[MessageParam],
    max_tokens: int,
    model_tier: ModelTier = ModelTier.LOW,
) -> str | None:
    """Make a single LLM call and return the extracted text, or None if empty."""
    client = create_client()
    response = await client.messages.create(
        max_tokens=max_tokens,
        model=tier_to_model_id(model_tier),
        messages=messages,
        system=system,
    )
    text = "".join(
        getattr(b, "text", "") for b in response.content
        if getattr(b, "type", None) == "text"
    ).strip()
    return text or None
