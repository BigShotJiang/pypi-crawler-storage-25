# Advanced Usage

## Custom Tools

Custom tools are Python functions with typed inputs, structured outputs, and approval policies. A tool's availability depends on where you register it:

| Registered on | Available when |
|---------------|----------------|
| `app` | All sessions, always |
| `project` | Only in that project's sessions |
| `skill` | Only when that skill is active |
| `role` | Only when that role is active |
| `workflow_state` | Only during that workflow state |

### Defining Tools

A tool needs four things: an ID, a description (so the agent knows when to use it), an input schema, and a run function.

```python
from hypergolic import Tool, InputSchema, ToolResult, ToolContext

class ValidateInput(InputSchema):
    fix: bool = False

async def run_validate(inp: ValidateInput, ctx: ToolContext) -> ToolResult:
    import subprocess
    cmd = ["./bin/validate"]
    if inp.fix:
        cmd.append("--fix")
    result = subprocess.run(cmd, capture_output=True, text=True)
    return ToolResult(
        content=[{"type": "text", "text": result.stdout + result.stderr}],
        outcome="SUCCESS" if result.returncode == 0 else "FAILURE",
    )

validate_tool = Tool(
    id="validate",
    name="Validate",
    description="Run the project's validation suite. Use --fix to auto-fix issues.",
    input_schema=ValidateInput,
    run=run_validate,
    approval="ALLOW",
)
```

Register it globally or on a specific project:

```python
# Available in all sessions
app.register_tool(validate_tool)

# Available only in this project
project.register_tool(validate_tool)
```

### Approval Policies

The `approval` field controls whether the user is prompted before the tool runs. It can be a string shortcut or a callable:

```python
from hypergolic import ToolApprovalDecision

# String shortcuts
tool = Tool(..., approval="ALLOW")              # Never ask
tool = Tool(..., approval="REQUIRE_APPROVAL")   # Always ask
tool = Tool(..., approval="DENY")               # Never run

# Dynamic approval based on input
def deploy_approval(inp):
    if inp.environment == "production":
        return ToolApprovalDecision(
            decision="REQUIRE_APPROVAL",
            context=f"Deploying to production",
        )
    return ToolApprovalDecision(decision="ALLOW")

tool = Tool(..., approval=deploy_approval)
```

### Tool Parameters

Define parameters as fields on your `InputSchema` subclass. Pydantic handles validation and type coercion:

```python
class DeployInput(InputSchema):
    environment: str = "staging"
    dry_run: bool = False
    timeout: int = 300
```

The schema is automatically converted to JSON Schema for the LLM.

### Skill-Gated Tools

Tools registered on a skill are only available when that skill is active:

```python
semgrep_tool = Tool(
    id="semgrep",
    name="Semgrep",
    description="Run semgrep security scan on the codebase",
    input_schema=SemgrepInput,
    run=run_semgrep,
)

security_skill = Skill(
    id="security-reviewer",
    name="Security Review",
    description="Review code for security vulnerabilities",
    prompt_path="~/.hypergolic/prompts/skills/security-reviewer.md",
    tools=[semgrep_tool],
)
app.register_skill(security_skill)
```

## MCP Servers

Hypergolic supports the [Model Context Protocol](https://modelcontextprotocol.io/) for connecting external tool servers. MCP servers expose their own tools that the assistant can invoke.

### Configuration

Register MCP servers in your `main.py`:

```python
# stdio transport (spawns a local process)
app.register_mcp_server(
    "my-server",
    transport="stdio",
    command="npx",
    args=["-y", "@my-org/mcp-server"],
)

# HTTP transport
app.register_mcp_server(
    "my-api",
    transport="streamable_http",
    url="https://my-server.example.com/mcp",
    auth={"type": "token", "token_env_var": "MY_SERVER_TOKEN"},
)

# SSE transport
app.register_mcp_server(
    "my-sse-server",
    transport="sse",
    url="https://my-server.example.com/sse",
)
```

### Supported Transports

| Transport | Fields | Description |
|-----------|--------|-------------|
| `stdio` | `command`, `args`, `env` | Spawns a local process and communicates over stdin/stdout |
| `streamable_http` | `url`, `auth` | Connects to an HTTP endpoint |
| `sse` | `url`, `auth` | Connects via Server-Sent Events |

### Authentication

For HTTP-based transports, configure auth with a token read from an environment variable:

```python
app.register_mcp_server(
    "my-server",
    transport="streamable_http",
    url="https://my-server.example.com/mcp",
    auth={
        "type": "token",
        "token_env_var": "MY_SERVER_TOKEN",
        "token_header": "Authorization",
        "token_prefix": "Bearer",
    },
)
```

### Managing MCP Servers

The assistant can use the `manage_mcp` tool to list, enable, and disable MCP servers during a session. You can also manage them from the UI.

## Skills

Skills are specialized prompt injections that shape the assistant's behavior for specific tasks. When activated, a skill's prompt is appended to the system prompt and its tools become available for the remainder of the session.

### Defining Skills

```python
from hypergolic import Skill, Tool

query_tool = Tool(
    id="query-api",
    name="Query API",
    description="Query the platform API for data",
    input_schema=QueryInput,
    run=run_query,
)

platform_skill = Skill(
    id="platform-expertise",
    name="Platform Expertise",
    description="Deep knowledge of the platform architecture and APIs",
    prompt_path="~/.hypergolic/prompts/skills/platform.md",
    tools=[query_tool],
)
app.register_skill(platform_skill)
```

Activate skills during conversation by asking the assistant, or it may activate them on its own when appropriate.

### Prompt Sources

Like all prompt-bearing objects, skills accept `prompt_path`, `prompt`, or `prompt_fn` (mutually exclusive):

```python
# From a markdown file
Skill(id="debug", name="Debug", description="...", prompt_path="~/.hypergolic/prompts/skills/debug.md")

# Inline
Skill(id="debug", name="Debug", description="...", prompt="You are a debugging expert...")

# Dynamic
Skill(id="debug", name="Debug", description="...", prompt_fn=lambda: build_debug_prompt())
```

## Roles

Roles replace the base system prompt entirely. While skills are additive (they append to the prompt), a role changes the foundational behavior of the assistant.

### Defining Roles

```python
from hypergolic import Role

reviewer = Role(
    id="reviewer",
    name="Code Reviewer",
    prompt_path="~/.hypergolic/prompts/roles/reviewer.md",
    skills=[security_skill],   # Auto-activated when this role is selected
    tools=[read_files_tool, search_files_tool, git_tool],  # Scoped tools
)
app.register_role(reviewer)
```

The `skills` field lists skills that are automatically activated when the role is selected. The `tools` field scopes which tools are available under this role. The role's prompt is used *instead of* the default role prompt.

## Knowledge Graph

The knowledge graph is a persistent, tagged store of facts that the assistant builds over time.

### Scopes

| Scope | Injected When |
|-------|---------------|
| `universal` | Every session |
| `user` | Every session |
| `project` | When working in the matching project |
| `session` | Only in that session |

### Default Tags

`code-style` · `tooling` · `architecture` · `domain` · `team` · `workflow` · `debugging` · `preference` · `correction`

You can create custom tags and delete defaults from the Knowledge panel in the sidebar.

### How It Works

- When you correct the assistant or state a preference, it stores that as a knowledge item.
- Items are tagged and scoped.
- Relevant items are automatically retrieved and injected into the system prompt each turn.
- You can browse, create, edit, and delete items from the Knowledge panel (`⌘/Ctrl + 3`).

## Browser Automation

The `browser` tool provides headless Chrome automation via [rodney](https://github.com/nichochar/rodney). The assistant can:

- Navigate to URLs, click elements, fill forms
- Take screenshots and PDFs
- Execute JavaScript
- Read page text, HTML, and accessibility trees
- Wait for load states and network idle

Useful for testing web apps, scraping, and verifying UI changes.

## Session History

The assistant can search across past sessions using the `history` tool. This enables it to recall previous conversations, find how a problem was solved before, or continue interrupted work.

## Tips for Effective Prompt Engineering

The prompts you write for roles, skills, projects, and workflow states are the primary way you shape your assistant's behavior. Here are some guidelines:

### Writing Role Prompts

Role prompts set the foundational persona. Be specific about:

- **Communication style** — Concise vs. detailed? Formal vs. casual? Should it explain its reasoning?
- **Behavioral constraints** — What should it always or never do? (e.g., "Always run tests before committing," "Never modify generated files")
- **Decision-making approach** — Should it ask before acting, or be autonomous? When should it escalate?
- **Tool preferences** — Which tools should it favor or avoid?

```markdown
# Code Reviewer

You are a thorough code reviewer. Focus on correctness, maintainability, and test coverage.

- Read the full diff before commenting
- Flag potential bugs, not style preferences
- Suggest specific fixes, not vague advice
- If tests are missing for changed code, say so
- Never modify files directly — only comment on what should change
```

### Writing Skill Prompts

Skill prompts inject domain expertise. They should be:

- **Focused on a specific domain** — What does this expertise cover?
- **Actionable** — What should the assistant do differently when this skill is active?
- **Tool-aware** — If the skill includes tools, explain when and how to use them

```markdown
# Database Migration Expertise

You have deep expertise in database migrations and schema design.

- Always check for existing migrations before creating new ones
- Prefer reversible migrations
- Consider data migration needs alongside schema changes
- Use the `db-validate` tool to check migration consistency
- Warn about migrations that lock tables on large datasets
```

### Writing Project Prompts

Project prompts encode conventions specific to a codebase. Cover:

- **Tech stack** — Languages, frameworks, key libraries, versions
- **Project structure** — Where things live, naming conventions
- **Testing approach** — How to run tests, coverage requirements, testing patterns
- **Things to avoid** — Deprecated patterns, files not to touch, common pitfalls

```markdown
# My App

## Stack
Python 3.14, FastAPI, SQLAlchemy, Alembic, Pydantic 2.x
Tests: pytest, 100% coverage required
Lint: ruff | Types: ty

## Conventions
- Run `bin/check` before committing (lint + type check + tests)
- Never edit files in `src/app/generated/`
- All API endpoints need OpenAPI descriptions
- Use `uv` for package management, never pip
```

### Writing Workflow State Prompts

Workflow state prompts should be **self-contained**. When `truncate_on_entry` is true, the agent loses prior conversation and only has artifacts and the state prompt:

- **Explain the phase** — What is this step trying to accomplish?
- **Reference artifacts** — Tell the agent which artifacts from prior states it has and how to use them
- **Define the output** — What should the structured output contain? What makes a good vs. bad output?
- **Explain transitions** — When to use success vs. failure vs. suppressed

```markdown
# Implementation Planning

You have a PRD artifact from the requirements phase. Your job is to produce an implementation plan.

1. Read the PRD carefully
2. Identify the key files that need to change
3. Break the work into ordered steps
4. For each step, note what changes and what tests to write

Use `workflow_transition_success` when the plan is complete.
Use `workflow_transition_failure` if the PRD is unclear or contradictory.
```

### Iterating on Prompts

- **Conclude sessions with feedback.** The retrospective summaries help you spot patterns in what works and what doesn't.
- **Start specific, then generalize.** Write prompts for a specific task first, then extract reusable patterns.
- **Watch tool usage.** If the assistant isn't using the right tools or is using them poorly, your prompt probably needs to be more explicit about tool selection.
- **Check knowledge graph entries.** Corrections you make during sessions get stored — if you keep correcting the same thing, it belongs in a prompt.
