import os
import re
import shutil
import subprocess
from pathlib import Path

import typer
from rich.console import Console

from hypergolic.cli.version import get_version

console = Console()

HYPERGOLIC_DIR = Path.home() / ".hypergolic"


def _package_base_dir() -> Path:
    return Path(__file__).resolve().parent.parent / "base"


def _package_source_dir() -> Path:
    return Path(__file__).resolve().parent.parent


def init() -> None:
    """Initialize ~/.hypergolic/ with default configuration."""
    if HYPERGOLIC_DIR.exists():
        console.print(f"[yellow]Warning:[/] {HYPERGOLIC_DIR} already exists.")
        overwrite = typer.confirm("Reinitialize? (base/ will be recreated, your files won't be touched)")
        if not overwrite:
            raise typer.Exit()

    console.print(f"Initializing {HYPERGOLIC_DIR}...")

    # Create directory structure
    HYPERGOLIC_DIR.mkdir(parents=True, exist_ok=True)
    (HYPERGOLIC_DIR / "prompts" / "roles").mkdir(parents=True, exist_ok=True)
    (HYPERGOLIC_DIR / "prompts" / "skills").mkdir(parents=True, exist_ok=True)
    (HYPERGOLIC_DIR / "projects").mkdir(parents=True, exist_ok=True)

    sync_base()

    main_py = HYPERGOLIC_DIR / "main.py"
    if not main_py.exists():
        template = _package_base_dir() / "main_template.py"
        if template.exists():
            shutil.copy2(template, main_py)
            console.print(f"  Created {main_py}")
    else:
        console.print(f"  [dim]Skipping {main_py} (already exists)[/]")

    sync_ref()
    setup_gitignore()
    generate_pyproject()
    _setup_shell_alias()
    _initial_git_commit(HYPERGOLIC_DIR)

    console.print(f"\n[green]\u2713 Hypergolic initialized at {HYPERGOLIC_DIR}[/]")
    console.print("\nNext steps:")
    console.print(f"  1. Edit {main_py} to configure your projects")
    console.print("  2. Restart your shell (or run: source ~/.zshrc)")
    console.print("  3. Run: h")


def sync_base() -> None:
    base_dest = HYPERGOLIC_DIR / "base"
    if base_dest.exists():
        shutil.rmtree(base_dest)
    base_src = _package_base_dir()
    if base_src.exists():
        shutil.copytree(base_src, base_dest)
        console.print(f"  Synced {base_dest}")


def sync_ref() -> None:
    ref_dest = HYPERGOLIC_DIR / ".ref"
    if ref_dest.exists():
        shutil.rmtree(ref_dest)
    source = _package_source_dir()
    if source.exists():
        shutil.copytree(source, ref_dest, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "ui_dist"))
        console.print(f"  Synced {ref_dest}")


def setup_gitignore() -> None:
    gitignore = HYPERGOLIC_DIR / ".gitignore"
    if gitignore.exists():
        return
    source = HYPERGOLIC_DIR / "base" / ".gitignore"
    if source.exists():
        shutil.copy2(source, gitignore)


def _is_dev_mode() -> bool:
    return os.environ.get("HYPERGOLIC_DEV_MODE", "").lower() in ("1", "true", "yes")


def _package_root() -> Path:
    return Path(__file__).resolve().parent.parent.parent.parent


def generate_pyproject() -> None:
    pyproject = HYPERGOLIC_DIR / "pyproject.toml"
    version = get_version()

    if _is_dev_mode():
        root = _package_root()
        content = f'''[project]
name = "my-hypergolic"
version = "0.1.0"
requires-python = ">=3.14"
dependencies = [
    "hypergolic",
]

[tool.uv]
package = false

[tool.uv.sources]
hypergolic = {{ path = "{root}", editable = true }}
'''
        pyproject.write_text(content)
        console.print(f"  {'Updated' if pyproject.exists() else 'Created'} {pyproject} (dev mode)")
    elif pyproject.exists():
        content = pyproject.read_text()
        content = re.sub(
            r'hypergolic[><=!~]+[\d.]+',
            f'hypergolic>={version}',
            content,
        )
        pyproject.write_text(content)
        console.print(f"  Updated {pyproject}")
    else:
        content = f'''[project]
name = "my-hypergolic"
version = "0.1.0"
requires-python = ">=3.14"
dependencies = [
    "hypergolic>={version}",
]

[tool.uv]
package = false
'''
        pyproject.write_text(content)
        console.print(f"  Created {pyproject}")


def _initial_git_commit(directory: Path) -> None:
    if not (directory / ".git").exists():
        subprocess.run(["git", "init"], cwd=directory, capture_output=True)

    subprocess.run(["git", "add", "-A"], cwd=directory, capture_output=True, check=True)

    result = subprocess.run(["git", "diff", "--cached", "--quiet"], cwd=directory, capture_output=True)
    if result.returncode != 0:
        subprocess.run(
            ["git", "commit", "-m", "Initial toolkit configuration"],
            cwd=directory,
            capture_output=True,
            check=True,
        )
        console.print("  Created initial git commit")


def _setup_shell_alias() -> None:
    alias_line = f"alias h='uv run {HYPERGOLIC_DIR / 'main.py'}'"

    shell_configs = [
        Path.home() / ".zshrc",
        Path.home() / ".bashrc",
    ]

    for config_path in shell_configs:
        if not config_path.exists():
            continue
        content = config_path.read_text()
        if "alias h=" in content:
            new_content = re.sub(r"alias h=.*", alias_line, content)
            if new_content != content:
                config_path.write_text(new_content)
                console.print(f"  Updated alias in {config_path}")
        else:
            with open(config_path, "a") as f:
                f.write(f"\n# Hypergolic\n{alias_line}\n")
            console.print(f"  Added alias to {config_path}")
        return

    console.print("  [yellow]Could not find shell config. Add this to your shell profile:[/]")
    console.print(f"    {alias_line}")
