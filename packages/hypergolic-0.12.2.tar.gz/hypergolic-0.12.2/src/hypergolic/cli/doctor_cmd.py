import ast
from pathlib import Path

import typer
from rich.console import Console

console = Console()

HYPERGOLIC_DIR = Path.home() / ".hypergolic"


def doctor() -> None:
    """Validate Hypergolic setup: files, deps, paths, database."""
    issues: list[str] = []
    warnings: list[str] = []
    checks_passed = 0

    main_py = HYPERGOLIC_DIR / "main.py"
    if not main_py.exists():
        issues.append(f"main.py not found at {main_py}")
    else:
        checks_passed += 1
        try:
            ast.parse(main_py.read_text())
            checks_passed += 1
        except SyntaxError as e:
            issues.append(f"main.py has syntax error: {e}")

    pyproject = HYPERGOLIC_DIR / "pyproject.toml"
    if not pyproject.exists():
        issues.append(f"pyproject.toml not found at {pyproject}")
    else:
        checks_passed += 1

    base_dir = HYPERGOLIC_DIR / "base"
    if not base_dir.exists():
        issues.append("base/ directory not found. Run `hypergolic update`.")
    else:
        checks_passed += 1

    base_tools_init = base_dir / "tools" / "__init__.py"
    if base_dir.exists() and not base_tools_init.exists():
        issues.append("base/tools/__init__.py not found. Run `hypergolic update`.")
    else:
        checks_passed += 1

    db_path = HYPERGOLIC_DIR / "hypergolic.db"
    if not db_path.exists():
        warnings.append(f"Database not found at {db_path} (will be created on first run)")
    else:
        checks_passed += 1

    ref_dir = HYPERGOLIC_DIR / ".ref"
    if not ref_dir.exists():
        warnings.append(".ref/ directory not found. Run `hypergolic update` to sync.")
    else:
        checks_passed += 1

    console.print()
    if issues:
        console.print(f"[red]\u2717 {len(issues)} issue(s) found:[/]")
        for issue in issues:
            console.print(f"  [red]\u2022[/] {issue}")
    if warnings:
        console.print(f"[yellow]\u26a0 {len(warnings)} warning(s):[/]")
        for warning in warnings:
            console.print(f"  [yellow]\u2022[/] {warning}")

    console.print(f"\n[green]\u2713 {checks_passed} check(s) passed[/]")

    if issues:
        raise typer.Exit(1)
