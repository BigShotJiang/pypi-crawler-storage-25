import uuid

from sqlalchemy import select, delete as sa_delete

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBProject, DBSession, DBSessionSkill
from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.skills.resolver import resolve_roles
from hypergolic.toolkit.app.state import get_app


def load_session(session_id: str) -> Session:
    with get_db() as db:
        row = db.execute(
            select(DBSession, DBProject.path)
            .join(DBProject, DBSession.project_id == DBProject.id)
            .where(DBSession.id == session_id)
        ).one()
        db_session, project_path = row
        return Session(
            id=db_session.id,
            model_tier=db_session.model_tier,
            project_id=db_session.project_id,
            project_path=project_path,
            role=db_session.role,
            parent_id=db_session.parent_id,
            dispatch_prompt=db_session.dispatch_prompt,
        )


def delete_session_tree(session_id: str) -> None:
    """Delete a session and all descendants (via FK CASCADE)."""
    with get_db() as db:
        db.execute(sa_delete(DBSession).where(DBSession.id == session_id))


def _get_role_skills(role_id: str) -> list[str]:
    roles = resolve_roles()
    for role in roles:
        if role["id"] == role_id:
            return role.get("skills", [])
    return []


def create_session(
    project_id: str,
    model_tier: ModelTier | None = None,
    role: str = "generalist",
    parent_id: str | None = None,
    dispatch_prompt: str | None = None,
) -> Session:
    if model_tier is None:
        model_tier = get_app().default_model_tier
    session_id = str(uuid.uuid7())
    system_prompt = [{"type": "text", "text": "placeholder"}]

    with get_db() as db:
        project = db.execute(
            select(DBProject).where(DBProject.id == project_id)
        ).scalar_one()

        db_session = DBSession(
            id=session_id,
            model_tier=model_tier,
            system_prompt=system_prompt,
            role=role,
            project_id=project_id,
            parent_id=parent_id,
            dispatch_prompt=dispatch_prompt,
        )
        db.add(db_session)

        role_skill_ids = _get_role_skills(role)
        for skill_id in role_skill_ids:
            db.add(DBSessionSkill(
                session_id=session_id,
                skill_id=skill_id,
            ))

        return Session(
            id=session_id,
            model_tier=model_tier,
            project_id=project_id,
            project_path=project.path,
            role=role,
            parent_id=parent_id,
            dispatch_prompt=dispatch_prompt,
        )
