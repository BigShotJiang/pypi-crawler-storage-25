"""Pure helpers for building session API responses.

These are extracted from the router so they can be unit-tested without
HTTP or database fixtures.
"""

from hypergolic.db.models import DBSession
from hypergolic.db.utils import to_iso_utc
from hypergolic.toolkit.bridge import evaluate_toolkit_approval
from hypergolic.toolkit.primitives import Tool as ToolkitTool
from hypergolic.mcptools.tool_bridge import parse_mcp_tool_id
from hypergolic.sessions.schemas import (
    SessionResponse,
    SkillInfo,
    ToolInfo,
)
from hypergolic.tools.schemas import Tool


def session_response(
    row: DBSession,
    project_name: str,
    message_count: int = 0,
    workflow_id: str | None = None,
    workflow_state_id: str | None = None,
    workflow_name: str | None = None,
    workflow_state_name: str | None = None,
) -> SessionResponse:
    """Map a DBSession row to a SessionResponse."""
    return SessionResponse(
        id=row.id,
        model_tier=row.model_tier,
        project_id=row.project_id,
        project_name=project_name,
        role=row.role,
        status=row.status,
        created_at=to_iso_utc(row.created_at),
        updated_at=to_iso_utc(row.updated_at),
        message_count=message_count,
        workflow_id=workflow_id,
        workflow_name=workflow_name,
        workflow_state_id=workflow_state_id,
        workflow_state_name=workflow_state_name,
        parent_id=row.parent_id,
        description=row.description,
        conclusion_rating=row.conclusion_rating,
        conclusion_feedback=row.conclusion_feedback,
        conclusion_summary=row.conclusion_summary,
        concluded_at=to_iso_utc(row.concluded_at) if row.concluded_at else None,
    )


def check_requires_approval(
    toolkit_tool: ToolkitTool | None,
    internal_tool: Tool | None = None,
) -> bool:
    """Return True if a tool needs user approval before execution.

    Resolution order:
    1. If a toolkit tool exists, use its approval setting.
    2. Otherwise fall back to the internal tool's ``requires_approval`` flag.
    3. If neither is available, default to ``True`` (deny-by-default).

    For toolkit tools with callable approval that accept input (and
    optionally session), we conservatively report True because the
    decision is input-dependent.
    """
    if toolkit_tool is not None:
        approval = toolkit_tool.approval
        if isinstance(approval, str):
            return approval != "ALLOW"
        if callable(approval) and toolkit_tool.input_schema:
            return True
        decision = evaluate_toolkit_approval(toolkit_tool, {})
        return decision.decision != "ALLOW"

    if internal_tool is not None:
        return internal_tool.requires_approval

    return True


def build_tool_info(
    tool: Tool,
    reason: str,
    toolkit_tool: ToolkitTool | None,
) -> ToolInfo:
    """Build a single ToolInfo from an internal Tool + its toolkit entry."""
    mcp_parsed = parse_mcp_tool_id(tool.id)
    requires_approval = check_requires_approval(toolkit_tool, tool)
    try:
        raw = tool.to_param().get("input_schema")
        schema = dict(raw) if raw else None
    except Exception:
        schema = None
    return ToolInfo(
        id=tool.id,
        name=tool.name,
        description=tool.description,
        reason=reason,
        requires_approval=requires_approval,
        mcp_server=mcp_parsed[0] if mcp_parsed else None,
        input_schema=schema,
    )


def build_skill_infos(
    all_skills: list[dict],
    active_skill_ids: set[str],
) -> list[SkillInfo]:
    """Build SkillInfo list from resolved skills and active IDs."""
    return [
        SkillInfo(
            id=s["id"],
            name=s["name"],
            description=s["description"],
            source=s["source"],
            active=s["id"] in active_skill_ids,
        )
        for s in all_skills
    ]
