import asyncio
import logging

from sqlalchemy import update

from hypergolic.config.settings import PROMPTS_DIR
from hypergolic.db.engine import get_db
from hypergolic.db.models import DBSession
from hypergolic.messages.persistence import load_session_messages
from hypergolic.messages.summarization import build_conversation_transcript
from hypergolic.messages.types import BroadcastEvent, BroadcastFn
from hypergolic.providers import generate_text

logger = logging.getLogger(__name__)

RETROSPECTIVE_MAX_TOKENS = 2048
SYSTEM_PROMPT_PATH = PROMPTS_DIR / "retrospective.md"


def _load_system_prompt() -> str:
    return SYSTEM_PROMPT_PATH.read_text()


async def _generate_retrospective(session_id: str, broadcast: BroadcastFn) -> None:
    try:
        messages = load_session_messages(session_id)
        if not messages:
            return

        transcript_blocks = build_conversation_transcript(messages)
        if not transcript_blocks:
            return

        transcript_blocks.append({
            "type": "text",
            "text": "Please provide a retrospective summary of this session.",
        })

        summary = await generate_text(
            system=_load_system_prompt(),
            messages=[{"role": "user", "content": transcript_blocks}],
            max_tokens=RETROSPECTIVE_MAX_TOKENS,
        )
        if not summary:
            return

        with get_db() as db:
            db.execute(
                update(DBSession)
                .where(DBSession.id == session_id)
                .values(conclusion_summary=summary)
            )

        await broadcast(BroadcastEvent(
            type="conclusion_summary_ready",
            role="system",
            content=[{"summary": summary}],
            session_id=session_id,
        ))
    except Exception:
        logger.exception("Failed to generate retrospective for %s", session_id)


def schedule_retrospective(session_id: str, broadcast: BroadcastFn) -> None:
    """Fire-and-forget retrospective generation for a concluded session."""
    asyncio.create_task(_generate_retrospective(session_id, broadcast))
