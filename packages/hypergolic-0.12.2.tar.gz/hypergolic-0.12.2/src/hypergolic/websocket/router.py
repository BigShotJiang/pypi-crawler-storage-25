import asyncio
import logging
from datetime import datetime, timezone
from typing import Any

from anthropic.types import MessageParam
from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from sqlalchemy import select, update

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBSession
from hypergolic.dispatch.core import cancel_child_dispatches, fail_dispatch_if_child, register_turn_runner
from hypergolic.enums import SessionStatus
from hypergolic.git.operations import get_git_status
from hypergolic.messages.conversation.loop import create_message
from hypergolic.messages.types import BroadcastEvent, UserInterrupt
from hypergolic.providers import create_client
from hypergolic.sessions.operations import create_session, load_session
from hypergolic.sessions.retrospective import schedule_retrospective
from hypergolic.sessions.status import finalize_turn, set_session_status_and_broadcast
from hypergolic.workflows.engine import activate_workflow, WorkflowError
from hypergolic.tools.handlers import AnnotationItem, ApprovalRequest, ApprovalResponse
from hypergolic.websocket.helpers import (
    build_content_blocks,
    format_error_detail,
    persist_error,
    persist_error_message,
    serialize_event,
)
from hypergolic.websocket.turn_manager import TurnManager
from hypergolic.auth import verify_token
from hypergolic.websocket.schemas import (
    ApprovalResponseMessage,
    ConcludeSessionMessage,
    ConnectMessage,
    parse_client_message,
)

logger = logging.getLogger(__name__)

router = APIRouter()

_client = None


def get_client():
    global _client
    if _client is None:
        _client = create_client()
    return _client


@router.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    token = ws.cookies.get("h_token", "")
    if not verify_token(token):
        await ws.close(code=4003, reason="Unauthorized")
        return
    await ws.accept()
    tm = TurnManager()

    async def broadcast(event: BroadcastEvent) -> None:
        await ws.send_json(serialize_event(event))

    async def approval_callback(req: ApprovalRequest) -> ApprovalResponse:
        if req.session_id:
            await set_session_status_and_broadcast(
                req.session_id, SessionStatus.AWAITING_APPROVAL, broadcast,
            )
        payload: dict[str, Any] = {
            "type": "tool_approval_request",
            "tool_use_id": req.tool_use_id,
            "tool_name": req.tool_name,
            "tool_display_name": req.tool_display_name or req.tool_name,
            "tool_input": req.tool_input,
            "session_id": req.session_id,
        }
        if req.display_blocks:
            payload["display_blocks"] = [
                {"field": b.field, "type": b.type, "label": b.label, "value": b.value}
                for b in req.display_blocks
            ]
        await ws.send_json(payload)

        loop = asyncio.get_event_loop()
        future: asyncio.Future[ApprovalResponse] = loop.create_future()
        tm.pending_approvals[req.tool_use_id] = (req.session_id or "", future)

        try:
            response = await future
            if req.session_id:
                await set_session_status_and_broadcast(
                    req.session_id, SessionStatus.TOOL_USE, broadcast,
                )
            return response
        finally:
            tm.pending_approvals.pop(req.tool_use_id, None)

    async def _run_session_turn(session_id: str, message: MessageParam, cancel_event: asyncio.Event) -> None:
        client = get_client()
        session = load_session(session_id)

        try:
            await create_message(
                client=client,
                session=session,
                message=message,
                broadcast=broadcast,
                cancel_event=cancel_event,
                approval_callback=approval_callback,
            )

            await finalize_turn(session_id, broadcast)
            done_payload: dict[str, Any] = {"type": "done", "session_id": session_id}
            try:
                session_obj = load_session(session_id)
                git_status = get_git_status(repo=session_obj.working_directory())
                done_payload["git_status"] = git_status.model_dump()
            except Exception:
                logger.debug("Failed to include git_status in done event", exc_info=True)
            await ws.send_json(done_payload)
        except UserInterrupt as ui:
            await set_session_status_and_broadcast(session_id, SessionStatus.IDLE, broadcast)
            try:
                payload: dict[str, Any] = {"type": "interrupted", "session_id": session_id}
                if ui.partial_text:
                    payload["partial_text"] = ui.partial_text
                await ws.send_json(payload)
            except Exception:
                logger.warning("Failed to send interrupt payload to WebSocket", exc_info=True)
        except Exception as exc:
            logger.error("Error during session turn %s", session_id, exc_info=True)
            detail = format_error_detail(exc)
            await set_session_status_and_broadcast(session_id, SessionStatus.ERROR, broadcast)
            persist_error_message(session_id, detail)
            persist_error(session_id, exc)
            fail_dispatch_if_child(session_id, detail)
            try:
                await ws.send_json({"type": "error", "detail": detail, "session_id": session_id})
            except Exception:
                logger.warning("Failed to send error payload to WebSocket", exc_info=True)

    def start_child_turn(child_session_id: str, message: MessageParam) -> None:
        async def _child_coro(cancel_event: asyncio.Event) -> None:
            await _run_session_turn(child_session_id, message, cancel_event)

        tm.start_turn(child_session_id, _child_coro)

    register_turn_runner(start_child_turn)

    async def _handle_conclude_session(msg: ConcludeSessionMessage) -> None:
        session_id = msg.session_id

        # 1. Interrupt active turn if any
        await tm.cancel_existing_turn(session_id)

        # 2. Cancel any active child dispatches
        cancel_child_dispatches(session_id)

        # Also conclude any child sessions that are still active
        with get_db() as db:
            child_rows = db.execute(
                select(DBSession.id, DBSession.status)
                .where(DBSession.parent_id == session_id)
                .where(DBSession.status.notin_([SessionStatus.CONCLUDED.value, SessionStatus.INTERRUPTED.value]))
            ).all()
            for child_id, _status in child_rows:
                await tm.cancel_existing_turn(child_id)
                db.execute(
                    update(DBSession)
                    .where(DBSession.id == child_id)
                    .values(status=SessionStatus.CONCLUDED.value)
                )

        # 3. Set conclusion fields on the session
        concluded_at = datetime.now(timezone.utc)
        with get_db() as db:
            db.execute(
                update(DBSession)
                .where(DBSession.id == session_id)
                .values(
                    conclusion_rating=msg.rating,
                    conclusion_feedback=msg.feedback,
                    concluded_at=concluded_at,
                    status=SessionStatus.CONCLUDED.value,
                )
            )

        # 4. Broadcast status change
        await broadcast(BroadcastEvent(
            type="session_status_change",
            role="system",
            content=[{"status": SessionStatus.CONCLUDED.value}],
            session_id=session_id,
        ))

        # 5. Send session_concluded event
        await ws.send_json({
            "type": "session_concluded",
            "session_id": session_id,
            "conclusion_rating": msg.rating,
            "conclusion_feedback": msg.feedback,
            "concluded_at": concluded_at.isoformat(),
        })

        # 6. Generate retrospective summary (fire-and-forget, single LLM call)
        schedule_retrospective(session_id, broadcast)

    try:
        while True:
            raw = await ws.receive_json()
            msg = parse_client_message(raw)

            if isinstance(msg, ApprovalResponseMessage):
                entry = tm.pending_approvals.get(msg.tool_use_id)
                if entry:
                    _sid, future = entry
                    if not future.done():
                        annotations = None
                        if msg.annotations:
                            annotations = [
                                AnnotationItem(
                                    highlighted_text=a.highlighted_text,
                                    comment=a.comment,
                                )
                                for a in msg.annotations
                            ]
                        future.set_result(ApprovalResponse(
                            approved=msg.approved,
                            denial_reason=msg.denial_reason,
                            annotations=annotations,
                        ))
                continue

            if isinstance(msg, ConcludeSessionMessage):
                await _handle_conclude_session(msg)
                continue

            request = msg
            target_session_id = request.session_id or "__new__"

            cancel_child_dispatches(target_session_id)
            await tm.cancel_existing_turn(target_session_id)

            async def _bound_run_turn(cancel_event: asyncio.Event, req: ConnectMessage = request) -> None:
                session_id: str | None = None
                try:
                    if req.session_id:
                        session = load_session(req.session_id)
                    else:
                        if not req.project_id:
                            raise ValueError("project_id is required to create a new session")
                        session = create_session(project_id=req.project_id, model_tier=req.model_tier)

                    session_id = session.id

                    if req.workflow_id:
                        try:
                            await activate_workflow(session, req.workflow_id, broadcast)
                        except WorkflowError as wfe:
                            await ws.send_json({"type": "error", "detail": str(wfe), "session_id": session.id})
                            return

                    content_blocks = build_content_blocks(req)
                    user_message: MessageParam = {
                        "role": "user",
                        "content": content_blocks,
                    }

                    await _run_session_turn(session.id, user_message, cancel_event)
                except Exception as exc:
                    logger.error("Error during WebSocket turn", exc_info=True)
                    detail = format_error_detail(exc)
                    if session_id:
                        await set_session_status_and_broadcast(session_id, SessionStatus.ERROR, broadcast)
                        persist_error_message(session_id, detail)
                        persist_error(session_id, exc)
                    try:
                        await ws.send_json({"type": "error", "detail": detail, "session_id": session_id})
                    except Exception:
                        logger.warning("Failed to send error payload to WebSocket", exc_info=True)

            tm.start_turn(target_session_id, _bound_run_turn)
    except WebSocketDisconnect:
        logger.info("WebSocket client disconnected")
    except Exception:
        logger.error("Unexpected WebSocket error", exc_info=True)
    finally:
        await tm.cleanup()
        try:
            await ws.close()
        except Exception:
            logger.debug("Failed to close WebSocket cleanly", exc_info=True)
