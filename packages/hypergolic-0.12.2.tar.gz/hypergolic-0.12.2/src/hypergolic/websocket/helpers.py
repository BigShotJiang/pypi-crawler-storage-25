import logging
import traceback as tb_module
from typing import Any

from anthropic import APIConnectionError, APIStatusError
from anthropic.types import TextBlockParam, ImageBlockParam
from pydantic import BaseModel

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBError, DBMessage
from hypergolic.messages.persistence import load_session_messages, strip_excluded_fields
from hypergolic.messages.types import BroadcastEvent
from hypergolic.websocket.schemas import ConnectMessage

logger = logging.getLogger(__name__)

__all__ = [
    "serialize_event",
    "strip_excluded_fields",
    "load_session_messages",
    "build_content_blocks",
    "persist_error_message",
    "persist_error",
    "format_error_detail",
]


def serialize_event(event: BroadcastEvent) -> dict[str, Any]:
    content = []
    for block in event.content:
        if isinstance(block, BaseModel):
            content.append(block.model_dump(mode="json"))
        elif isinstance(block, dict):
            content.append(block)
        else:
            content.append(str(block))

    payload: dict[str, Any] = {
        "type": event.type,
        "role": event.role,
        "content": content,
    }
    if event.session_id:
        payload["session_id"] = event.session_id
    if event.model:
        payload["model"] = event.model
    if event.stop_reason:
        payload["stop_reason"] = event.stop_reason
    if event.message_id:
        payload["message_id"] = event.message_id
    if event.usage:
        payload["usage"] = event.usage
    return payload


def build_content_blocks(
    request: ConnectMessage,
) -> list[TextBlockParam | ImageBlockParam]:
    blocks: list[TextBlockParam | ImageBlockParam] = []
    if request.content_blocks:
        for raw_block in request.content_blocks:
            if raw_block.get("type") == "image" and "source" in raw_block:
                blocks.append(ImageBlockParam(type="image", source=raw_block["source"]))
            elif raw_block.get("type") == "text" and "text" in raw_block:
                blocks.append(TextBlockParam(type="text", text=raw_block["text"]))
    blocks.append(TextBlockParam(type="text", text=request.message))
    return blocks


def persist_error_message(session_id: str, detail: str) -> None:
    with get_db() as db:
        db.add(DBMessage(
            session_id=session_id,
            content=[{"type": "text", "text": detail}],
            model=None,
            role="assistant",
            stop_reason="error",
            stop_sequence=None,
            usage=None,
        ))


def persist_error(session_id: str, exc: BaseException) -> None:
    try:
        with get_db() as db:
            db.add(DBError(
                session_id=session_id,
                error_type=type(exc).__qualname__,
                message=str(exc),
                traceback="".join(tb_module.format_exception(exc)),
            ))
    except Exception:
        logger.warning("Failed to persist error to database", exc_info=True)


def format_error_detail(exc: Exception) -> str:
    if isinstance(exc, APIConnectionError):
        return f"Lost connection to AI provider: {exc}"
    if isinstance(exc, APIStatusError):
        return f"AI provider error (HTTP {exc.status_code}): {exc.message}"
    return str(exc)
