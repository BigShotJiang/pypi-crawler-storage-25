import logging
from pathlib import Path
from typing import Any

from sqlalchemy import select

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBSessionSkill
from hypergolic.toolkit.app.state import get_app
from hypergolic.toolkit.primitives import resolve_prompt

logger = logging.getLogger(__name__)


def resolve_roles() -> list[dict[str, Any]]:
    app = get_app()
    roles: list[dict[str, Any]] = []
    seen_ids: set[str] = set()

    for role in app.roles:
        if role.id not in seen_ids:
            prompt_path = ""
            if role.prompt_path:
                prompt_path = str(Path(role.prompt_path).expanduser())
            roles.append({
                "id": role.id,
                "name": role.name,
                "prompt_path": prompt_path,
                "prompt": role.prompt if hasattr(role, "prompt") else None,
                "tools": [t.id for t in role.tools] if role.tools else [],
                "skills": [s.id for s in role.skills] if role.skills else [],
                "source": "toolkit",
            })
            seen_ids.add(role.id)

    return roles


def resolve_skills() -> list[dict[str, Any]]:
    app = get_app()
    skills: list[dict[str, Any]] = []
    seen_ids: set[str] = set()

    for skill in app.skills:
        if skill.id not in seen_ids:
            prompt_path = ""
            if skill.prompt_path:
                prompt_path = str(Path(skill.prompt_path).expanduser())
            skills.append({
                "id": skill.id,
                "name": skill.name,
                "description": skill.description,
                "prompt_path": prompt_path,
                "prompt": skill.prompt if hasattr(skill, "prompt") else None,
                "tools": [t.id for t in skill.tools] if skill.tools else [],
                "source": "toolkit",
            })
            seen_ids.add(skill.id)

    # Project-scoped skills
    for project in app.projects:
        for skill in project.skills:
            if skill.id not in seen_ids:
                prompt_path = ""
                if skill.prompt_path:
                    prompt_path = str(Path(skill.prompt_path).expanduser())
                skills.append({
                    "id": skill.id,
                    "name": skill.name,
                    "description": skill.description,
                    "prompt_path": prompt_path,
                    "prompt": skill.prompt if hasattr(skill, "prompt") else None,
                    "tools": [t.id for t in skill.tools] if skill.tools else [],
                    "source": "toolkit",
                })
                seen_ids.add(skill.id)

    return skills


def get_skill_prompt_content(skill_id: str) -> tuple[str, str | None] | None:
    """Returns (name, prompt_content) for a skill, or None if not found.

    If the skill exists but its prompt file is missing, returns (name, None).
    """
    app = get_app()
    for skill_data in resolve_skills():
        if skill_data["id"] == skill_id:
            skill_obj = app.get_skill(skill_id)
            if skill_obj:
                content = resolve_prompt(skill_obj, app)
                if content:
                    return skill_data["name"], content
            return skill_data["name"], None
    return None


def get_active_skill_ids(session_id: str) -> set[str]:
    with get_db() as db:
        rows = db.execute(
            select(DBSessionSkill.skill_id)
            .where(DBSessionSkill.session_id == session_id)
        ).scalars().all()
    return set(rows)


def get_active_skill_prompts(session_id: str) -> list[tuple[str, str]]:
    with get_db() as db:
        active_ids = list(
            db.execute(
                select(DBSessionSkill.skill_id)
                .where(DBSessionSkill.session_id == session_id)
                .order_by(DBSessionSkill.created_at)
            ).scalars().all()
        )

    if not active_ids:
        return []

    app = get_app()
    results: list[tuple[str, str]] = []
    for sid in active_ids:
        skill_obj = app.get_skill(sid)
        if not skill_obj:
            continue
        content = resolve_prompt(skill_obj, app)
        if content:
            results.append((skill_obj.name, content))
    return results
