from datetime import datetime
import uuid
from typing import Any

from anthropic.types.tool_result_block_param import Content
from sqlalchemy import JSON, ForeignKey, func
from sqlalchemy import DateTime, String
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

from hypergolic.enums import (
    ModelTier,
    SessionStatus,
    WorkflowOutcome,
)


class Base(DeclarativeBase):
    id: Mapped[str] = mapped_column(
        String,
        primary_key=True,
        nullable=False,
        default=lambda: str(uuid.uuid7()),
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=func.now(),
        nullable=False,
        index=True,
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=func.now(), onupdate=func.now(), nullable=False
    )


class DBSession(Base):
    __tablename__ = "sessions"

    model_tier: Mapped[ModelTier] = mapped_column(String, nullable=False)
    system_prompt: Mapped[list[Content]] = mapped_column(JSON, nullable=False)
    role: Mapped[str] = mapped_column(String, nullable=False, default="generalist")
    status: Mapped[SessionStatus] = mapped_column(
        String, nullable=False, default=SessionStatus.IDLE
    )
    project_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("projects.id", name="fk_sessions_projects", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    parent_id: Mapped[str | None] = mapped_column(
        String,
        ForeignKey("sessions.id", name="fk_sessions_parent", ondelete="CASCADE"),
        nullable=True,
        index=True,
    )
    dispatch_prompt: Mapped[str | None] = mapped_column(String, nullable=True)
    description: Mapped[str | None] = mapped_column(String, nullable=True, default=None)
    conclusion_rating: Mapped[int | None] = mapped_column(nullable=True, default=None)
    conclusion_feedback: Mapped[str | None] = mapped_column(String, nullable=True, default=None)
    conclusion_summary: Mapped[str | None] = mapped_column(String, nullable=True, default=None)
    concluded_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True, default=None
    )


class DBMessage(Base):
    __tablename__ = "messages"

    content: Mapped[list[Content]] = mapped_column(JSON, nullable=False)
    session_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("sessions.id", name="fk_messages_sessions", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    model: Mapped[str] = mapped_column(String, nullable=True)
    role: Mapped[str] = mapped_column(String, nullable=False)
    stop_reason: Mapped[str | None] = mapped_column(String, nullable=True)
    stop_sequence: Mapped[str | None] = mapped_column(String, nullable=True)
    usage: Mapped[dict[str, Any] | None] = mapped_column(JSON, nullable=True)
    truncated: Mapped[bool] = mapped_column(default=False, nullable=False)


class DBProject(Base):
    __tablename__ = "projects"

    name: Mapped[str] = mapped_column(String, nullable=False)
    path: Mapped[str] = mapped_column(String, nullable=False, unique=True)


class DBSessionSkill(Base):
    __tablename__ = "session_skills"

    session_id: Mapped[str] = mapped_column(
        String,
        ForeignKey(
            "sessions.id", name="fk_session_skills_sessions", ondelete="CASCADE"
        ),
        nullable=False,
        index=True,
    )
    skill_id: Mapped[str] = mapped_column(String, nullable=False)


class DBSessionWorkflow(Base):
    __tablename__ = "session_workflows"

    session_id: Mapped[str] = mapped_column(
        String,
        ForeignKey(
            "sessions.id", name="fk_session_workflows_sessions", ondelete="CASCADE"
        ),
        nullable=False,
        index=True,
    )
    workflow_id: Mapped[str] = mapped_column(String, nullable=False)
    current_state_id: Mapped[str] = mapped_column(String, nullable=False)
    deleted_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True, default=None
    )


class DBArtifact(Base):
    __tablename__ = "artifacts"

    session_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("sessions.id", name="fk_artifacts_sessions", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    workflow_id: Mapped[str] = mapped_column(String, nullable=False)
    state_id: Mapped[str] = mapped_column(String, nullable=False)
    outcome: Mapped[WorkflowOutcome] = mapped_column(String, nullable=False)
    artifact_id: Mapped[str] = mapped_column(String, nullable=False, index=True)
    content: Mapped[dict] = mapped_column(JSON, nullable=False)


class DBError(Base):
    __tablename__ = "errors"

    session_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("sessions.id", name="fk_errors_sessions", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    error_type: Mapped[str] = mapped_column(String, nullable=False)
    message: Mapped[str] = mapped_column(String, nullable=False)
    traceback: Mapped[str | None] = mapped_column(String, nullable=True)
