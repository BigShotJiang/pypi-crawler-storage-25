from pathlib import Path

from pydantic import BaseModel

from hypergolic.enums import ModelTier


class SessionMessage(BaseModel):
    id: str
    session_id: str


class Session(BaseModel):
    id: str
    model_tier: ModelTier
    project_id: str
    project_path: str
    role: str = "generalist"
    parent_id: str | None = None
    dispatch_prompt: str | None = None

    def working_directory(self) -> Path:
        return Path(self.project_path)
