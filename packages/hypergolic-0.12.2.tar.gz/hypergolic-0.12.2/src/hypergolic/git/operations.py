import subprocess
from pathlib import Path

from hypergolic.git.schemas import (
    ChangedFile,
    GitCommitDetailResponse,
    GitDiffResponse,
    GitLogEntry,
    GitLogResponse,
    GitStatusResponse,
)


class GitCommandError(Exception):
    def __init__(
        self, command: str, returncode: int, stderr: str, stdout: str = "",
    ):
        self.command = command
        self.returncode = returncode
        self.stderr = stderr
        self.stdout = stdout
        super().__init__(f"git {command} failed (exit {returncode}): {stderr}")


def git_repo_root() -> Path:
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True,
            text=True,
            check=True,
        )
        return Path(result.stdout.strip())
    except (subprocess.CalledProcessError, FileNotFoundError):
        return Path.cwd()


def run_git_command(*args: str, cwd: Path | None = None, check: bool = False) -> subprocess.CompletedProcess[str]:
    repo = cwd or git_repo_root()
    result = subprocess.run(
        ["git", *args],
        capture_output=True,
        text=True,
        cwd=repo,
    )
    if check and result.returncode != 0:
        raise GitCommandError(
            command=args[0] if args else "unknown",
            returncode=result.returncode,
            stderr=result.stderr.strip(),
            stdout=result.stdout.strip(),
        )
    return result


def _parse_numstat(repo: Path, staged: bool) -> dict[str, tuple[int, int]]:
    args = ["diff", "--numstat"]
    if staged:
        args.append("--cached")
    result = run_git_command(*args, cwd=repo)
    stats: dict[str, tuple[int, int]] = {}
    for line in result.stdout.splitlines():
        parts = line.split("\t")
        if len(parts) == 3:
            adds = int(parts[0]) if parts[0] != "-" else 0
            dels = int(parts[1]) if parts[1] != "-" else 0
            filepath = parts[2]
            stats[filepath] = (adds, dels)
    return stats


def get_git_status(repo: Path | None = None) -> GitStatusResponse:
    repo = repo or git_repo_root()

    branch_result = run_git_command("branch", "--show-current", cwd=repo)
    branch = branch_result.stdout.strip() or "HEAD"

    ahead = 0
    behind = 0
    ab_result = run_git_command("rev-list", "--left-right", "--count", "@{upstream}...HEAD", cwd=repo)
    if ab_result.returncode == 0:
        parts = ab_result.stdout.strip().split()
        if len(parts) == 2:
            behind = int(parts[0])
            ahead = int(parts[1])

    status_result = run_git_command("status", "--porcelain", "-uall", cwd=repo)

    staged_stats = _parse_numstat(repo, staged=True)
    unstaged_stats = _parse_numstat(repo, staged=False)

    staged: list[ChangedFile] = []
    unstaged: list[ChangedFile] = []
    untracked: list[str] = []

    for line in status_result.stdout.splitlines():
        if len(line) < 4:
            continue
        index_status = line[0]
        worktree_status = line[1]
        filepath = line[3:].strip()
        if " -> " in filepath:
            filepath = filepath.split(" -> ", 1)[1]

        if index_status == "?" and worktree_status == "?":
            untracked.append(filepath)
            continue

        if index_status not in (" ", "?"):
            adds, dels = staged_stats.get(filepath, (0, 0))
            staged.append(ChangedFile(
                path=filepath,
                status=index_status,
                staged=True,
                additions=adds,
                deletions=dels,
            ))

        if worktree_status not in (" ", "?"):
            adds, dels = unstaged_stats.get(filepath, (0, 0))
            unstaged.append(ChangedFile(
                path=filepath,
                status=worktree_status,
                staged=False,
                additions=adds,
                deletions=dels,
            ))

    return GitStatusResponse(
        branch=branch,
        ahead=ahead,
        behind=behind,
        staged=staged,
        unstaged=unstaged,
        untracked=untracked,
    )


def _is_tracked(path: str, repo: Path) -> bool:
    result = run_git_command("ls-files", "--error-unmatch", "--", path, cwd=repo)
    return result.returncode == 0


def get_git_diff(path: str | None, staged: bool, repo: Path | None = None) -> GitDiffResponse:
    repo = repo or git_repo_root()
    args = ["diff"]
    if staged:
        args.append("--cached")
    if path:
        args.append("--")
        args.append(path)
    result = run_git_command(*args, cwd=repo)
    diff_text = result.stdout
    if path and not diff_text and not staged and not _is_tracked(path, repo):
        new_result = run_git_command("diff", "--no-index", "/dev/null", path, cwd=repo)
        diff_text = new_result.stdout
    return GitDiffResponse(path=path or "", diff=diff_text)


def git_stage(paths: list[str], repo: Path | None = None) -> None:
    repo = repo or git_repo_root()
    run_git_command("add", "--", *paths, cwd=repo, check=True)


def git_unstage(paths: list[str], repo: Path | None = None) -> None:
    repo = repo or git_repo_root()
    run_git_command("reset", "HEAD", "--", *paths, cwd=repo, check=True)


def git_discard(paths: list[str], repo: Path | None = None) -> None:
    repo = repo or git_repo_root()
    run_git_command("checkout", "--", *paths, cwd=repo, check=True)


def git_commit(message: str, repo: Path | None = None) -> str:
    repo = repo or git_repo_root()
    result = run_git_command("commit", "-m", message, cwd=repo, check=True)
    return result.stdout.strip()


def _current_branch(repo: Path) -> str:
    result = run_git_command("branch", "--show-current", cwd=repo)
    return result.stdout.strip() or "HEAD"


def git_push(repo: Path | None = None) -> str:
    repo = repo or git_repo_root()
    branch = _current_branch(repo)
    result = run_git_command("push", "-u", "origin", branch, cwd=repo, check=True)
    return result.stdout.strip() or result.stderr.strip()


def _has_upstream(repo: Path) -> bool:
    result = run_git_command("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{upstream}", cwd=repo)
    return result.returncode == 0


def git_pull(repo: Path | None = None) -> str:
    repo = repo or git_repo_root()
    if not _has_upstream(repo):
        return "No upstream branch to pull from (push first to create it)."
    result = run_git_command("pull", cwd=repo, check=True)
    return result.stdout.strip() or result.stderr.strip()


def get_git_commit_detail(commit_hash: str, repo: Path | None = None) -> GitCommitDetailResponse:
    repo = repo or git_repo_root()
    sep = "\x1f"
    fmt = sep.join(["%H", "%h", "%an", "%aI", "%s"])
    result = run_git_command("log", f"--format={fmt}", "-1", "--end-of-options", commit_hash, cwd=repo)
    parts = result.stdout.strip().split(sep)
    if len(parts) != 5:
        return GitCommitDetailResponse(
            hash=commit_hash, short_hash=commit_hash[:7],
            author="", date="", message="", diff="",
        )
    diff_result = run_git_command("diff-tree", "-p", "--no-commit-id", "--end-of-options", commit_hash, cwd=repo)
    return GitCommitDetailResponse(
        hash=parts[0], short_hash=parts[1],
        author=parts[2], date=parts[3], message=parts[4],
        diff=diff_result.stdout,
    )


def get_git_log(count: int = 50, repo: Path | None = None) -> GitLogResponse:
    repo = repo or git_repo_root()
    sep = "\x1f"
    fmt = sep.join(["%H", "%h", "%an", "%aI", "%s", "%D"])
    result = run_git_command("log", f"--format={fmt}", f"-{count}", cwd=repo)
    entries: list[GitLogEntry] = []
    for line in result.stdout.splitlines():
        parts = line.split(sep)
        if len(parts) != 6:
            continue
        entries.append(GitLogEntry(
            hash=parts[0],
            short_hash=parts[1],
            author=parts[2],
            date=parts[3],
            message=parts[4],
            refs=parts[5],
        ))
    return GitLogResponse(entries=entries)
