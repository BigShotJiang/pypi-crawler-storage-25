from copy import deepcopy
from typing import Any, cast

from anthropic.types import MessageParam


def _strip_cache_control(messages: list[MessageParam]) -> None:
    for message in messages:
        if not isinstance(message, dict):
            continue
        content = message.get("content")
        if not content or not isinstance(content, list):
            continue
        for block in content:
            if isinstance(block, dict) and "cache_control" in block:
                raw = cast(dict[str, Any], block)
                del raw["cache_control"]


def set_message_cache_breakpoint(
    messages: list[MessageParam],
) -> list[MessageParam]:
    result = deepcopy(messages)
    _strip_cache_control(result)

    if len(result) >= 2:
        target_msg = result[-2]
    else:
        target_msg = result[-1]

    content = target_msg.get("content") if isinstance(target_msg, dict) else None
    if content is None or not isinstance(content, list) or len(content) == 0:
        return result

    last_block = content[-1]
    if isinstance(last_block, dict):
        raw = cast(dict[str, Any], last_block)
        raw["cache_control"] = {"type": "ephemeral"}

    return result
