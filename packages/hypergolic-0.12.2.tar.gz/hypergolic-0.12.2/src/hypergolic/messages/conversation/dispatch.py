import asyncio
from typing import Callable

from anthropic.types import Message, StopReason

from hypergolic.enums import SessionStatus
from hypergolic.messages.content_blocks import serialize_content_blocks
from hypergolic.messages.conversation.interrupts import persist_interrupt_tool_results
from hypergolic.messages.persistence import persist_user_message
from hypergolic.messages.truncation import truncate_conversation
from hypergolic.messages.types import BroadcastEvent, BroadcastFn, UserInterrupt
from hypergolic.schemas import Session
from hypergolic.sessions.status import set_session_status_and_broadcast
from hypergolic.tools.handlers import (
    ApprovalCallback,
    ToolUseResult,
    handle_tool_use,
)


async def handle_tool_use_stop(
    response: Message,
    tools: list,
    session: Session,
    broadcast: BroadcastFn,
    approval_callback: ApprovalCallback | None,
    check_cancelled: Callable[[], None],
) -> ToolUseResult:
    check_cancelled()
    await set_session_status_and_broadcast(
        session.id, SessionStatus.TOOL_USE, broadcast
    )
    tool_use_result = await handle_tool_use(
        agent_message=response,
        tools=tools,
        session=session,
        broadcast=broadcast,
        approval_callback=approval_callback,
    )
    check_cancelled()

    await persist_user_message(
        session_id=session.id, message=tool_use_result.message
    )
    raw_content = tool_use_result.message.get("content", [])
    await broadcast(
        BroadcastEvent(
            type="tool_result",
            role="user",
            content=serialize_content_blocks(raw_content),
            session_id=session.id,
        )
    )
    if tool_use_result.should_truncate:
        await truncate_conversation(session, broadcast)
    return tool_use_result


async def broadcast_response(
    response: Message, session_id: str, broadcast: BroadcastFn,
    tool_display_names: dict[str, str] | None = None,
) -> None:
    await broadcast(
        BroadcastEvent(
            type="assistant_message",
            role="assistant",
            content=serialize_content_blocks(response.content, tool_display_names),
            session_id=session_id,
            model=response.model,
            stop_reason=response.stop_reason,
            message_id=response.id,
            usage=(
                response.usage.model_dump(mode="json")
                if response.usage
                else None
            ),
        )
    )


async def dispatch_stop_reason(
    stop_reason: StopReason,
    response: Message,
    tools: list,
    session: Session,
    broadcast: BroadcastFn,
    approval_callback: ApprovalCallback | None,
    check_cancelled: Callable[[], None],
    refresh_tools: Callable[[], None],
    tool_display_names: dict[str, str] | None = None,
) -> None:
    try:
        await broadcast_response(response, session.id, broadcast, tool_display_names)

        match stop_reason:
            case "end_turn":
                pass
            case "tool_use":
                await handle_tool_use_stop(
                    response, tools, session, broadcast,
                    approval_callback, check_cancelled,
                )
                refresh_tools()
            case _:
                raise Exception(f"Unhandled stop reason: {stop_reason}")
    except (UserInterrupt, asyncio.CancelledError):
        if stop_reason == "tool_use":
            await persist_interrupt_tool_results(session.id, response)
        raise UserInterrupt()
    except Exception:
        if stop_reason == "tool_use":
            await persist_interrupt_tool_results(session.id, response)
        raise
