import asyncio

from anthropic import AsyncAnthropic
from anthropic.types import Message, MessageParam, StopReason

from hypergolic.dispatch.core import auto_conclude_if_needed
from hypergolic.enums import SessionStatus
from hypergolic.messages.caching import set_message_cache_breakpoint
from hypergolic.messages.conversation.dispatch import dispatch_stop_reason
from hypergolic.messages.conversation.retry import stream_response
from hypergolic.messages.persistence import (
    load_session_messages,
    persist_agent_message,
    persist_user_message,
)
from hypergolic.messages.truncation import should_truncate, truncate_conversation
from hypergolic.messages.types import BroadcastFn, UserInterrupt
from hypergolic.prompts.builder import build_session_prompt
from hypergolic.schemas import Session
from hypergolic.sessions.description.generate import maybe_generate_description
from hypergolic.sessions.status import (
    TERMINAL_STATUSES,
    get_session_status,
    set_session_status_and_broadcast,
)
from hypergolic.tools.handlers import ApprovalCallback
from hypergolic.tools.tool_list import (
    build_tools,
    get_tool_schemas,
    set_tools_cache_breakpoint,
)


async def create_message(
    client: AsyncAnthropic,
    session: Session,
    message: MessageParam,
    broadcast: BroadcastFn,
    cancel_event: asyncio.Event | None = None,
    approval_callback: ApprovalCallback | None = None,
) -> Message:
    response: Message | None = None
    stop_reason: StopReason | None = None

    prompt = list(build_session_prompt(session))
    tools = build_tools(session=session)
    tool_schemas = set_tools_cache_breakpoint(get_tool_schemas(tools))
    tool_display_names = {t.id: t.name for t in tools}

    def _refresh_tools() -> None:
        nonlocal tools, tool_schemas, tool_display_names
        tools = build_tools(session=session)
        tool_schemas = set_tools_cache_breakpoint(get_tool_schemas(tools))
        tool_display_names = {t.id: t.name for t in tools}

    await persist_user_message(session_id=session.id, message=message)
    maybe_generate_description(session.id, broadcast)

    def _check_cancelled() -> None:
        if cancel_event and cancel_event.is_set():
            raise UserInterrupt()

    while stop_reason != "end_turn":
        _check_cancelled()

        if should_truncate(session.id):
            await truncate_conversation(session, broadcast)

        await set_session_status_and_broadcast(
            session.id, SessionStatus.THINKING, broadcast
        )

        messages = load_session_messages(session.id)
        cached_messages = set_message_cache_breakpoint(messages)

        response = await stream_response(
            client, session, prompt, tool_schemas,
            cached_messages, broadcast, _check_cancelled,
            tool_display_names,
        )

        assert response.stop_reason is not None
        stop_reason = response.stop_reason
        await persist_agent_message(session_id=session.id, message=response)

        await dispatch_stop_reason(
            stop_reason, response, tools, session, broadcast,
            approval_callback, _check_cancelled, _refresh_tools,
            tool_display_names,
        )

        if get_session_status(session.id) in TERMINAL_STATUSES:
            break

    assert response is not None
    auto_conclude_if_needed(session.id, session.parent_id, response)
    return response
