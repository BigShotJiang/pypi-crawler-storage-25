import seaborn as sns
import matplotlib.pyplot as plt

# Clean cool theme
sns.set_style("whitegrid")


# =========================================================
# 🔹 CORRELATION HEATMAP
# =========================================================
def plot_correlation(df):
    plt.figure(figsize=(10, 7))

    sns.heatmap(
        df.corr(numeric_only=True),
        annot=True,
        cmap="coolwarm",
        linewidths=0.5,
        fmt=".2f"
    )

    plt.title(
        "Correlation Heatmap\nShows how features are related to each other",
        fontsize=14,
        weight="bold",
        pad=20
    )

    plt.xticks(rotation=45, ha="right")
    plt.yticks(rotation=0)

    plt.tight_layout()
    plt.show()


# =========================================================
# 🔹 FEATURE IMPORTANCE
# =========================================================
def plot_feature_importance(feature_scores):
    features = [f[0] for f in feature_scores]
    scores = [f[1] for f in feature_scores]

    plt.figure(figsize=(10, 6))

    ax = sns.barplot(
        x=scores,
        y=features,
        hue=features,
        palette="Blues_d",
        legend=False
    )

    plt.title(
        "Feature Importance Ranking\nShows which features affect prediction the most",
        fontsize=14,
        weight="bold",
        pad=20
    )

    plt.xlabel("Score")
    plt.ylabel("Features")

    # Add labels
    for i, v in enumerate(scores):
        ax.text(v + 0.01, i, f"{v:.2f}", va='center')

    plt.tight_layout()
    plt.show()


# =========================================================
# 🔹 FEATURE DISTRIBUTION
# =========================================================
def plot_feature_distribution(df, feature):
    plt.figure(figsize=(10, 6))

    sns.histplot(df[feature], kde=True, color="#4C72B0")

    plt.title(
        f"Distribution of {feature}\nShows how values are spread",
        fontsize=14,
        weight="bold",
        pad=20
    )

    plt.xlabel(feature)
    plt.ylabel("Count")

    plt.tight_layout()
    plt.show()


# =========================================================
# 🔹 FEATURE VS TARGET
# =========================================================
def plot_feature_vs_target(df, feature, target):
    plt.figure(figsize=(10, 6))

    sns.scatterplot(
        x=df[feature],
        y=df[target],
        color="#3A86FF",
        alpha=0.7
    )

    plt.title(
        f"{feature} vs {target}\nShows how feature affects target",
        fontsize=14,
        weight="bold",
        pad=20
    )

    plt.xlabel(feature)
    plt.ylabel(target)

    plt.tight_layout()
    plt.show()