import pandas as pd
from .correlation import get_correlation
from .importance import get_feature_importance
from .ai_explainer import explain_feature
from .visualizer import (
    plot_correlation,
    plot_feature_importance,
    plot_feature_distribution,
    plot_feature_vs_target
)


def analyze(data, target, show_graphs=False):
    """
    data: str (file path) OR pandas DataFrame
    target: pandas Series (df['target'])
    """

    # =====================================================
    # ✅ HANDLE INPUT
    # =====================================================
    if isinstance(data, str):
        df = pd.read_csv(data)
    elif isinstance(data, pd.DataFrame):
        df = data.copy()
    else:
        raise ValueError("data must be a file path or pandas DataFrame")

    # =====================================================
    # 🔥 TARGET MUST BE SERIES
    # =====================================================
    if not isinstance(target, pd.Series):
        raise ValueError("target must be a pandas Series like df['column']")

    y = target

    # Remove target column if present
    if target.name in df.columns:
        X = df.drop(columns=[target.name])
    else:
        X = df.copy()

    # =====================================================
    # 🔹 CALCULATIONS
    # =====================================================
    # Add target temporarily for correlation
    df_temp = df.copy()
    df_temp[target.name] = y

    corr = get_correlation(df_temp, target.name)
    importance = get_feature_importance(X, y)

    final_scores = {}

    for feature in X.columns:
        corr_val = abs(corr.get(feature, 0))
        imp_val = importance.get(feature, 0)

        final_scores[feature] = 0.5 * corr_val + 0.5 * imp_val

    ranked_features = sorted(final_scores.items(), key=lambda x: x[1], reverse=True)

    # =====================================================
    # 🔹 AI EXPLANATIONS
    # =====================================================
    explanations = {}

    for feature, score in ranked_features:
        explanations[feature] = explain_feature(
            feature,
            round(corr.get(feature, 0), 3),
            round(importance.get(feature, 0), 3)
        )

    # =====================================================
    # 🔹 OUTPUT
    # =====================================================
    format_output(ranked_features, explanations)
    generate_summary(ranked_features)

    # =====================================================
    # 🔹 VISUALIZATION
    # =====================================================
    if show_graphs:
        plot_correlation(df_temp)
        plot_feature_importance(ranked_features)

        # Top 2 features
        top_features = [f[0] for f in ranked_features[:2]]

        for feature in top_features:
            plot_feature_distribution(df, feature)
            plot_feature_vs_target(df_temp, feature, target.name)


# =====================================================
# 🔹 OUTPUT FORMAT
# =====================================================
def format_output(ranked_features, explanations):
    print("\n Feature Analysis Report\n")

    for feature, score in ranked_features:
        print(f"🔹 Feature: {feature}")
        print(f"   Score: {round(score, 3)}")
        print(f"   Insight: {explanations.get(feature, 'N/A')}")
        print("-" * 40)


# =====================================================
# 🔹 SUMMARY
# =====================================================
def generate_summary(ranked_features):
    print("\n📌 Summary:\n")

    top_feature = ranked_features[0][0]
    print(f"- {top_feature} is the most important feature.")

    if len(ranked_features) > 1:
        print(f"- {ranked_features[1][0]} has moderate importance.")

    if len(ranked_features) > 2:
        print(f"- {ranked_features[-1][0]} has lower contribution.")