import pandas as pd

def get_correlation(df, target):
    corr_matrix = df.corr(numeric_only=True)
    
    if target not in corr_matrix:
        raise ValueError("Target must be numeric")
    
    target_corr = corr_matrix[target].drop(target)
    
    return target_corr.sort_values(ascending=False)