from sklearn.ensemble import RandomForestClassifier

def get_feature_importance(X, y):
    model = RandomForestClassifier()
    model.fit(X, y)
    
    importance = model.feature_importances_
    
    return dict(zip(X.columns, importance))