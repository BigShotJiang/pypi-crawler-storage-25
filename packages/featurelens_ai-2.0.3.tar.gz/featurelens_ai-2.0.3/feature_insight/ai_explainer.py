from google import genai

# =========================================================
# 🔑 GEMINI CLIENT SETUP
# =========================================================

api_key = "AIzaSyBM5dLebi_otvaHEv-8j8gVfUP9HcKAi2w"  # 🔥 put your key here OR use env

if not api_key:
    api_key = "AIzaSyBM5dLebi_otvaHEv-8j8gVfUP9HcKAi2w"

if not api_key:
    raise ValueError("❌ API key not provided")

client = genai.Client(api_key=api_key)


# =========================================================
# 🔹 IMPORTANCE LEVEL
# =========================================================
def get_importance_level(score):
    if score >= 0.6:
        return "highly important"
    elif score >= 0.4:
        return "moderately important"
    else:
        return "less important"


# =========================================================
# 🔹 CORRELATION DIRECTION
# =========================================================
def get_correlation_direction(corr):
    if corr > 0:
        return "positive"
    elif corr < 0:
        return "negative"
    else:
        return "neutral"


# =========================================================
# 🔹 RULE-BASED FALLBACK
# =========================================================
def rule_based_explanation(feature, corr, importance):
    level = get_importance_level(importance)
    direction = get_correlation_direction(corr)

    return (
        f"{feature} affects prediction because it has a {direction} relation "
        f"with the target and its impact is {level}."
    )


# =========================================================
# 🔹 SAFE TEXT EXTRACTION
# =========================================================
def extract_text(response):
    try:
        return response.candidates[0].content.parts[0].text
    except Exception:
        return None


# =========================================================
# 🔥 BATCH AI EXPLANATION (MAIN UPGRADE)
# =========================================================
def explain_all_features(features_data):
    """
    features_data: list of dicts
    [{name, score, corr}, ...]
    """

    prompt = """
You are a teacher explaining things to a 5th class student.

Explain why each feature affects prediction in very simple English.

Rules:
- Use very simple words
- Keep sentences short and clear
- Explain cause → effect
- Do NOT use difficult or technical words
- 1–2 lines per feature

Format strictly:
Feature: <name>
Insight: <explanation>

Now explain:
"""

    # Add all features in one prompt
    for f in features_data:
        prompt += f"""
Feature: {f['name']}
Score: {round(f['score'], 3)}
Correlation: {round(f['corr'], 3)}
"""

    try:
        response = client.models.generate_content(
            model="gemini-2.5-flash",
            contents=prompt
        )

        text = extract_text(response)

        # print("✅ BATCH AI RESPONSE:\n", text)

        return parse_ai_output(text, features_data)

    except Exception as e:
        print("❌ AI ERROR:", e)

        # fallback for all features
        return {
            f["name"]: rule_based_explanation(f["name"], f["corr"], f["score"])
            for f in features_data
        }


# =========================================================
# 🔹 PARSE AI OUTPUT
# =========================================================
def parse_ai_output(text, features_data):
    explanations = {}

    if not text:
        return {
            f["name"]: rule_based_explanation(f["name"], f["corr"], f["score"])
            for f in features_data
        }

    lines = text.split("\n")
    current_feature = None

    for line in lines:
        line = line.strip()

        if line.lower().startswith("feature:"):
            current_feature = line.split(":", 1)[1].strip()

        elif line.lower().startswith("insight:") and current_feature:
            explanations[current_feature] = line.split(":", 1)[1].strip()

    # fallback for missing features
    for f in features_data:
        if f["name"] not in explanations:
            explanations[f["name"]] = rule_based_explanation(
                f["name"], f["corr"], f["score"]
            )

    return explanations


# =========================================================
# 🔹 OLD SINGLE FEATURE (OPTIONAL - KEEP FOR FLEXIBILITY)
# =========================================================
def explain_feature(feature, corr, importance, mode="smart"):
    if mode == "fast":
        return rule_based_explanation(feature, corr, importance)

    elif mode in ["ai", "smart"]:
        result = explain_all_features([
            {"name": feature, "score": importance, "corr": corr}
        ])
        return result.get(feature)

    else:
        raise ValueError("Mode must be 'fast', 'ai', or 'smart'")