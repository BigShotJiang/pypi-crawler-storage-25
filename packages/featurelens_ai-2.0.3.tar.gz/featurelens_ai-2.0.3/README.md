# FeatureLens

FeatureLens is a Python library for analyzing feature importance using statistical methods, machine learning, and optional AI-based explanations. It helps developers and data scientists understand which features contribute most to a target variable before model training.

## Overview

Feature selection and understanding feature importance are critical steps in building effective machine learning models. FeatureLens simplifies this process by combining:

* Statistical correlation analysis
* Machine learning-based importance scoring
* Automated ranking of features
* Optional AI-generated explanations
* Visual insights for better interpretation

This allows users to quickly identify which features are most relevant for prediction tasks.

## Features

* Correlation analysis between features and the target variable.
* Machine learning-based feature importance (e.g., Random Forest).
* Combined scoring system for ranking features.
* Clean and structured output report.
* Summary of the most and least important features.
* Optional visualization:
  * Correlation heatmap
  * Feature importance bar chart
* AI-based explanations for feature relevance (optional mode).

## Installation

Install the latest version via pip:

```bash
pip install featurelens-ai==2.0.3
```

## Usage

### Basic Analysis

```python
import pandas as pd
from feature_insight import analyze

# Load Data
df = pd.read_csv("data.csv")

# Run Analysis
analyze(df, df["target"])
```

### Analysis With Graphs

To generate visual insights, simply set `show_graphs=True`.

```python
import pandas as pd
from feature_insight import analyze

df = pd.read_csv("student_data.csv")

analyze(df, df["pass_exam"], show_graphs=True)
```

## Expected Output

### Feature Report

```text
Feature Analysis Report

Feature: hours_studied
Score: 0.72
Insight: If a student studies more, they understand better and are more likely to pass.
```

### Summary

```text
Summary:
- hours_studied is the most important feature.
- practice_tests has moderate importance.
- sleep_hours has lower contribution.
```

### Graphs (Optional)

When `show_graphs=True`, the library generates:
* Correlation Heatmap
* Feature Importance Chart
* Feature Distribution (top features)
* Feature vs Target Relationship

## Input Requirements

* **Data (`data`)**: Must be a pandas DataFrame or a valid CSV file path.
* **Target (`target`)**: Must be a pandas Series.

**Correct Usage:**
```python
analyze(df, df["buy"])
```

**Incorrect Usage:**
```python
analyze(df, "buy")  # Passing a string for the target is not currently supported
```

## Parameters

| Parameter | Type | Description |
| :--- | :--- | :--- |
| `data` | DataFrame / str | The input dataset to analyze. |
| `target` | Series | The target column (pandas Series) to predict. |
| `show_graphs` | bool | Set to `True` to show visual charts and graphs. |
```
