"""OpenAI / Azure 音频转写请求参数 - 对应 OpenAI audio.transcriptions.create"""

from typing import Optional, List, Union, Literal

import httpx
from openai._types import FileTypes, Headers, Query, Body, NotGiven, not_given
from openai.types.audio_model import AudioModel
from openai.types.audio_response_format import AudioResponseFormat
from openai.types.audio.transcription_include import TranscriptionInclude
from pydantic import BaseModel

from tamar_model_client.schemas.inputs.base import TamarFileIdInput


class OpenAIAudioTranscriptionInput(BaseModel):
    """音频转写请求参数 - 对应 OpenAI audio.transcriptions.create"""
    file: Union[FileTypes, TamarFileIdInput]
    model: Union[str, AudioModel]
    chunking_strategy: Optional[dict] = None
    include: Optional[List[TranscriptionInclude]] = None
    known_speaker_names: Optional[List[str]] = None
    known_speaker_references: Optional[List[str]] = None
    language: Optional[str] = None
    prompt: Optional[str] = None
    response_format: Optional[AudioResponseFormat] = None
    stream: Optional[Union[Literal[False], Literal[True]]] = None
    temperature: Optional[float] = None
    timestamp_granularities: Optional[List[Literal["word", "segment"]]] = None
    extra_headers: Optional[Headers] = None
    extra_query: Optional[Query] = None
    extra_body: Optional[Body] = None
    timeout: Optional[Union[float, httpx.Timeout, NotGiven]] = not_given

    model_config = {
        "arbitrary_types_allowed": True
    }
