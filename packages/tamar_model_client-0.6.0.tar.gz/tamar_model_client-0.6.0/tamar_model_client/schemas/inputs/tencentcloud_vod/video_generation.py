"""
TencentCloud VOD AIGC Video Generation Input Schema

腾讯云 VOD AIGC 融合服务平台，统一接入 Kling、Vidu、Hailuo、Jimeng、Hunyuan 等视频大模型。
"""

from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field


class TencentCloudVodVideoInput(BaseModel):
    """腾讯云 VOD AIGC 视频生成请求参数

    model 字段格式: "{model_name}-{version}"，如 "kling-3.0"、"vidu-q2-pro"
    """

    model: str = Field(
        ...,
        description="模型名称，格式: {model_name}-{version}，如 kling-3.0、vidu-q2-pro、hailuo-2.3"
    )

    prompt: Optional[str] = Field(
        None,
        description="文本提示词，用于文生视频或作为图生视频的补充描述"
    )

    file_infos: Optional[List[Dict[str, Any]]] = Field(
        None,
        description=(
            "输入文件信息列表。格式:\n"
            "[{'Type': 'Url', 'Category': 'Image', 'Url': 'https://...'}]\n"
            "Category 可选: Image, Video"
        )
    )

    last_frame_url: Optional[str] = Field(
        None,
        description="尾帧图片 URL（首尾帧模式，通过顶层 LastFrameUrl 传递给腾讯云 API）"
    )

    negative_prompt: Optional[str] = Field(
        None,
        description="反向提示词（通过顶层 NegativePrompt 传递给腾讯云 API）"
    )

    enhance_prompt: Optional[str] = Field(
        None,
        description="是否启用提示词增强。可选值: Enabled, Disabled"
    )

    scene_type: Optional[str] = Field(
        None,
        description="场景类型，如 motion_control, lip_sync 等"
    )

    ext_info: Optional[Dict[str, Any]] = Field(
        None,
        description="额外参数（腾讯 VOD 特有的双层 JSON 序列化参数）"
    )

    output_config: Optional[Dict[str, Any]] = Field(
        None,
        description="输出配置，包含 StorageMode, Resolution, EnhanceSwitch, AspectRatio 等"
    )

    duration: Optional[str] = Field(
        None,
        description="视频时长（字符串格式，如 '5'、'10'）"
    )

    callback_url: Optional[str] = Field(
        None,
        description="异步任务回调地址"
    )

    enable_async_task: Optional[bool] = Field(
        True,
        description="是否启用异步任务处理（视频生成为长时间任务，建议启用）"
    )
