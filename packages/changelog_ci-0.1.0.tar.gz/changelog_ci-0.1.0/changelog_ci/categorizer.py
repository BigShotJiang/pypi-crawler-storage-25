"""Categorize parsed commits into changelog sections."""

from dataclasses import dataclass, field
from typing import Optional

from .parser import ParsedCommit


@dataclass
class ChangeEntry:
    """A single changelog entry."""
    description: str
    pr_number: Optional[int] = None
    author: str = ""
    scope: Optional[str] = None
    breaking: bool = False
    raw: str = ""


@dataclass
class ChangelogSection:
    """A section in the changelog (e.g. Features, Bug Fixes)."""
    name: str
    entries: list[ChangeEntry] = field(default_factory=list)


@dataclass
class ChangelogData:
    """Full categorized changelog data."""
    version: str
    date: str
    sections: list[ChangelogSection] = field(default_factory=list)

    def get_section(self, name: str) -> ChangelogSection:
        for s in self.sections:
            if s.name == name:
                return s
        section = ChangelogSection(name=name)
        self.sections.append(section)
        return section


# Default category mappings
DEFAULT_CATEGORIES = [
    {"name": "Features", "prefixes": ["feat"], "labels": ["enhancement", "feature"]},
    {"name": "Bug Fixes", "prefixes": ["fix"], "labels": ["bug", "bugfix"]},
    {"name": "Performance", "prefixes": ["perf"], "labels": ["performance"]},
    {"name": "Documentation", "prefixes": ["docs"], "labels": ["documentation"]},
    {"name": "Internal", "prefixes": ["chore", "refactor", "test", "ci", "build", "style"], "labels": ["internal"]},
]

# Keywords in title that hint at category
KEYWORD_MAP = {
    "add": "Features",
    "new": "Features",
    "support": "Features",
    "fix": "Bug Fixes",
    "repair": "Bug Fixes",
    "resolve": "Bug Fixes",
    "break": "Breaking Changes",
    "remove": "Breaking Changes",
    "deprecat": "Breaking Changes",
    "speed": "Performance",
    "optim": "Performance",
    "document": "Documentation",
    "readme": "Documentation",
}


def categorize_commits(
    commits: list[ParsedCommit],
    categories: Optional[list[dict]] = None,
    ignore_labels: Optional[list[str]] = None,
) -> ChangelogData:
    """Categorize a list of parsed commits. Returns uncategorized as 'Other'."""
    import datetime

    cats = categories or DEFAULT_CATEGORIES
    ignore = set(ignore_labels or [])

    # Build prefix -> category name map
    prefix_map: dict[str, str] = {}
    label_map: dict[str, str] = {}
    for cat in cats:
        for p in cat.get("prefixes", []):
            prefix_map[p] = cat["name"]
        for l in cat.get("labels", []):
            label_map[l] = cat["name"]

    data = ChangelogData(version="Unreleased", date=datetime.date.today().isoformat())

    for commit in commits:
        # Check if ignored (by prefix or keyword match - simplified)
        # In real use, labels come from GitHub PR data

        # Determine category
        category_name = None

        # 1. From prefix
        if commit.prefix and commit.prefix in prefix_map:
            category_name = prefix_map[commit.prefix]

        # 2. From keyword in description
        if not category_name and not commit.prefix:
            desc_lower = commit.description.lower()
            for keyword, cat_name in KEYWORD_MAP.items():
                if keyword in desc_lower:
                    category_name = cat_name
                    break

        # 3. Default to "Other"
        if not category_name:
            category_name = "Other"

        # Breaking changes get dual-listed
        if commit.breaking:
            section = data.get_section("Breaking Changes")
            section.entries.append(ChangeEntry(
                description=commit.description,
                pr_number=commit.pr_number,
                author=commit.author,
                scope=commit.scope,
                breaking=True,
                raw=commit.raw,
            ))

        section = data.get_section(category_name)
        section.entries.append(ChangeEntry(
            description=commit.description,
            pr_number=commit.pr_number,
            author=commit.author,
            scope=commit.scope,
            breaking=commit.breaking,
            raw=commit.raw,
        ))

    # Remove empty sections
    data.sections = [s for s in data.sections if s.entries]

    # Sort sections by standard order
    order = ["Breaking Changes", "Features", "Bug Fixes", "Performance", "Documentation", "Internal", "Other"]
    data.sections.sort(key=lambda s: order.index(s.name) if s.name in order else len(order))

    return data
