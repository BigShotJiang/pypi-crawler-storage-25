"""Git operations: tags, log, diff."""

import subprocess
from typing import Optional


def run_git(*args: str, cwd: Optional[str] = None) -> str:
    """Run a git command and return stdout."""
    result = subprocess.run(
        ["git"] + list(args),
        capture_output=True,
        text=True,
        cwd=cwd,
    )
    if result.returncode != 0:
        raise RuntimeError(f"git {args[0]} failed: {result.stderr.strip()}")
    return result.stdout.strip()


def get_latest_tag(cwd: Optional[str] = None, prefix: str = "v") -> Optional[str]:
    """Get the latest git tag."""
    try:
        return run_git("describe", "--tags", "--abbrev=0", f"--match={prefix}*", cwd=cwd)
    except RuntimeError:
        return None


def get_all_tags(cwd: Optional[str] = None, prefix: str = "v") -> list[str]:
    """Get all tags sorted by version."""
    try:
        out = run_git("tag", "-l", f"{prefix}*", "--sort=-version:refname", cwd=cwd)
        return out.split("\n") if out else []
    except RuntimeError:
        return []


def get_commits_since_tag(
    tag: Optional[str] = None, cwd: Optional[str] = None
) -> list[tuple[str, str, str]]:
    """Get commits since a tag. Returns list of (hash, message, author)."""
    if tag:
        ref = f"{tag}..HEAD"
    else:
        ref = "HEAD"

    try:
        out = run_git(
            "log", ref, "--pretty=format:%H|||%s|||%an", cwd=cwd
        )
    except RuntimeError:
        return []

    if not out:
        return []

    commits = []
    for line in out.split("\n"):
        parts = line.split("|||")
        if len(parts) >= 3:
            commits.append((parts[0], parts[1], parts[2]))
    return commits


def get_contributors(
    since_tag: Optional[str] = None, cwd: Optional[str] = None
) -> list[dict]:
    """Get unique contributors (name, email, commit count)."""
    ref = f"{since_tag}..HEAD" if since_tag else "HEAD"
    try:
        out = run_git(
            "log", ref, "--pretty=format:%an|||%ae", cwd=cwd
        )
    except RuntimeError:
        return []

    if not out:
        return []

    contributors: dict[str, dict] = {}
    for line in out.split("\n"):
        parts = line.split("|||")
        if len(parts) >= 2:
            name, email = parts[0], parts[1]
            key = email.lower()
            if key not in contributors:
                contributors[key] = {"name": name, "email": email, "commits": 0}
            contributors[key]["commits"] += 1

    return sorted(contributors.values(), key=lambda c: c["commits"], reverse=True)


def create_tag(version: str, cwd: Optional[str] = None, prefix: str = "v") -> str:
    """Create a git tag."""
    tag = f"{prefix}{version}"
    run_git("tag", "-a", tag, "-m", f"Release {tag}", cwd=cwd)
    return tag


def create_release_commit(version: str, cwd: Optional[str] = None) -> None:
    """Stage CHANGELOG.md and commit."""
    run_git("add", "CHANGELOG.md", cwd=cwd)
    run_git("commit", "-m", f"chore(release): {version}", cwd=cwd)
