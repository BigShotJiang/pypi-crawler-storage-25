"""GitHub API client for fetching merged PRs."""

import os
from typing import Optional

import requests

from .parser import ParsedCommit, parse_commit


class GitHubClient:
    """Fetch merged PRs from GitHub API."""

    def __init__(
        self,
        owner: str,
        repo: str,
        token: Optional[str] = None,
        base_url: str = "https://api.github.com",
    ):
        self.owner = owner
        self.repo = repo
        self.token = token or os.environ.get("GITHUB_TOKEN", "")
        self.base_url = base_url.rstrip("/")
        self.session = requests.Session()
        if self.token:
            self.session.headers["Authorization"] = f"token {self.token}"
        self.session.headers["Accept"] = "application/vnd.github.v3+json"

    def _url(self, path: str) -> str:
        return f"{self.base_url}/repos/{self.owner}/{self.repo}{path}"

    def get_merged_prs(
        self, since_tag: Optional[str] = None, base: str = "main"
    ) -> list[ParsedCommit]:
        """Fetch merged PRs, optionally since a tag's date."""
        params: dict = {
            "state": "closed",
            "sort": "updated",
            "direction": "desc",
            "per_page": 100,
            "base": base,
        }

        if since_tag:
            # Get tag date
            try:
                tag_info = self.session.get(
                    self._url(f"/git/refs/tags/{since_tag}")
                ).json()
                if "object" in tag_info:
                    sha = tag_info["object"]["sha"]
                    commit_info = self.session.get(
                        self._url(f"/git/commits/{sha}")
                    ).json()
                    if "committer" in commit_info:
                        from datetime import datetime
                        date_str = commit_info["committer"]["date"]
                        params["since"] = date_str
            except Exception:
                pass

        resp = self.session.get(self._url("/pulls"), params=params)
        resp.raise_for_status()

        prs = []
        for pr in resp.json():
            if not pr.get("merged_at"):
                continue

            title = pr.get("title", "")
            number = pr.get("number")
            author = ""
            if pr.get("user"):
                author = f"@{pr['user'].get('login', '')}"

            parsed = parse_commit(title, author)
            if not parsed.pr_number:
                parsed.pr_number = number
            if not parsed.author:
                parsed.author = author

            # Store labels for categorization
            parsed._labels = [l["name"] for l in pr.get("labels", [])]  # type: ignore[attr-defined]

            prs.append(parsed)

        return prs

    @staticmethod
    def from_remote(remote_url: str, token: Optional[str] = None) -> "GitHubClient":
        """Parse owner/repo from a git remote URL."""
        # Handle https://github.com/owner/repo.git or git@github.com:owner/repo.git
        url = remote_url.rstrip("/")
        if url.endswith(".git"):
            url = url[:-4]

        if "://" in url:
            parts = url.split("/")[-2:]
        else:
            # git@host:owner/repo
            parts = url.split(":")[-1].split("/")

        if len(parts) != 2:
            raise ValueError(f"Cannot parse remote URL: {remote_url}")

        return GitHubClient(owner=parts[0], repo=parts[1], token=token)
