"""Format changelog data as markdown or JSON."""

import json
from typing import Optional

from .categorizer import ChangelogData


def format_markdown(
    data: ChangelogData,
    header: str = "# Changelog",
    unreleased: bool = False,
    contributors: bool = True,
) -> str:
    """Format changelog as Keep-a-Changelog markdown."""
    lines = [header, ""]

    version_label = data.version
    if version_label == "Unreleased" and not unreleased:
        return ""

    if version_label == "Unreleased":
        lines.append("## [Unreleased]")
    else:
        lines.append(f"## [{version_label}] - {data.date}")
    lines.append("")

    for section in data.sections:
        emoji = "⚠️ " if section.name == "Breaking Changes" else ""
        lines.append(f"### {emoji}{section.name}")
        lines.append("")

        for entry in section.entries:
            parts = [f"- {entry.description}"]
            if entry.pr_number:
                parts.append(f" (#{entry.pr_number})")
            if entry.author and contributors:
                parts.append(f" — {entry.author}")
            lines.append("".join(parts))

        lines.append("")

    return "\n".join(lines)


def format_json(data: ChangelogData, contributors: bool = True) -> str:
    """Format changelog as JSON."""
    output = {
        "version": data.version,
        "date": data.date,
        "sections": {},
    }

    for section in data.sections:
        entries = []
        for entry in section.entries:
            e: dict = {"description": entry.description}
            if entry.pr_number:
                e["pr"] = entry.pr_number
            if entry.author and contributors:
                e["author"] = entry.author
            if entry.scope:
                e["scope"] = entry.scope
            if entry.breaking:
                e["breaking"] = True
            entries.append(e)
        output["sections"][section.name] = entries

    return json.dumps(output, indent=2)


def prepend_to_changelog(existing: str, new_section: str) -> str:
    """Prepend a new version section to an existing CHANGELOG."""
    if not existing:
        return new_section

    # Find the first version header after the main header
    lines = existing.split("\n")
    insert_idx = 0
    for i, line in enumerate(lines):
        if line.startswith("## "):
            insert_idx = i
            break
        if line.startswith("# ") and insert_idx == 0:
            insert_idx = i + 2  # Skip header + blank line

    new_lines = new_section.rstrip().split("\n")
    result = lines[:insert_idx] + new_lines + lines[insert_idx:]
    return "\n".join(result)
