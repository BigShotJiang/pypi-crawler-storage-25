"""Release management: generate changelog, commit, tag."""

from typing import Optional

from . import git as git_ops
from .categorizer import ChangelogData, categorize_commits
from .collector import collect_from_git
from .config import Config
from .formatter import format_markdown, prepend_to_changelog
from .parser import ParsedCommit


def create_release(
    version: str,
    config: Optional[Config] = None,
    cwd: Optional[str] = None,
    dry_run: bool = False,
) -> str:
    """Generate changelog, commit, and tag a release."""
    cfg = config or Config.load()
    tag = f"{cfg.tag_prefix}{version}"

    # Get commits since last tag
    last_tag = git_ops.get_latest_tag(cwd=cwd, prefix=cfg.tag_prefix)
    commits = collect_from_git(since_tag=last_tag, cwd=cwd)

    if not commits:
        return "No new commits since last release."

    # Categorize
    data = categorize_commits(commits, cfg.categories, cfg.ignore_labels)
    data.version = version

    # Format
    new_section = format_markdown(
        data, header="", unreleased=False, contributors=cfg.contributors
    )

    if dry_run:
        return new_section

    # Read existing changelog
    changelog_path = "CHANGELOG.md"
    existing = ""
    if cwd:
        import os
        full_path = os.path.join(cwd, changelog_path)
        if os.path.exists(full_path):
            with open(full_path) as f:
                existing = f.read()
    else:
        if os.path.exists(changelog_path):
            with open(changelog_path) as f:
                existing = f.read()

    # Prepend new section
    if existing:
        updated = prepend_to_changelog(existing, new_section)
    else:
        updated = f"{cfg.header}\n\n{new_section}"

    # Write
    write_path = os.path.join(cwd, changelog_path) if cwd else changelog_path
    with open(write_path, "w") as f:
        f.write(updated)

    # Commit and tag
    git_ops.create_release_commit(version, cwd=cwd)
    git_ops.create_tag(version, cwd=cwd, prefix=cfg.tag_prefix)

    return f"Released {tag}. CHANGELOG.md updated and tagged."
