"""changelog-ci: Auto-generate CHANGELOG.md from merged PRs and git history."""

__version__ = "0.1.0"
