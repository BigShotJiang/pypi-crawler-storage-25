"""Click CLI for changelog-ci."""

from __future__ import annotations

import json
import os
import sys

import click
from rich.console import Console
from rich.table import Table

from . import __version__
from .categorizer import categorize_commits
from .collector import collect_from_git, collect_from_github
from .config import Config
from .formatter import format_json, format_markdown
from . import git as git_ops
from .release import create_release
from .template import get_template

console = Console()


def get_cwd(ctx: click.Context) -> str:
    """Get working directory from context or cwd."""
    return ctx.obj.get("cwd", os.getcwd()) if ctx.obj else os.getcwd()


@click.group()
@click.version_option(__version__, prog_name="changelog-ci")
@click.option("--repo", "-r", default=".", help="Path to git repository")
@click.pass_context
def cli(ctx: click.Context, repo: str) -> None:
    """Auto-generate CHANGELOG.md from merged PRs and git history."""
    ctx.ensure_object(dict)
    ctx.obj["cwd"] = os.path.abspath(repo)


@cli.command()
@click.option("--since", "-s", default=None, help="Generate changelog since this tag")
@click.option("--local", "use_local", is_flag=True, help="Use git log instead of GitHub API")
@click.option("--dry-run", is_flag=True, help="Preview without writing")
@click.option("--format", "fmt", type=click.Choice(["markdown", "json"]), default="markdown")
@click.option("--owner", default=None, help="GitHub repo owner")
@click.option("--repo-name", default=None, help="GitHub repo name")
@click.pass_context
def generate(
    ctx: click.Context,
    since: str | None,
    use_local: bool,
    dry_run: bool,
    fmt: str,
    owner: str | None,
    repo_name: str | None,
) -> None:
    """Generate CHANGELOG from PRs or git history."""
    cwd = get_cwd(ctx)
    config = Config.load()

    # Determine since tag
    since_tag = since or git_ops.get_latest_tag(cwd=cwd, prefix=config.tag_prefix)

    if use_local or not owner:
        commits = collect_from_git(since_tag=since_tag, cwd=cwd)
    else:
        if not repo_name:
            console.print("[red]--owner and --repo-name required for GitHub mode[/red]")
            sys.exit(1)
        token = os.environ.get("GITHUB_TOKEN")
        commits = collect_from_github(
            owner=owner, repo=repo_name, since_tag=since_tag, token=token
        )

    if not commits:
        console.print("[yellow]No new commits found.[/yellow]")
        return

    data = categorize_commits(commits, config.categories, config.ignore_labels)
    if since_tag:
        data.version = "Unreleased"
    else:
        data.version = "Unreleased"

    if fmt == "json":
        output = format_json(data, contributors=config.contributors)
        console.print(output)
        if not dry_run:
            with open(os.path.join(cwd, "CHANGELOG.md"), "w") as f:
                f.write(output)
    else:
        new_section = format_markdown(
            data, header=config.header, unreleased=config.unreleased,
            contributors=config.contributors,
        )
        console.print(new_section)

        if not dry_run:
            changelog_path = os.path.join(cwd, "CHANGELOG.md")
            existing = ""
            if os.path.exists(changelog_path):
                with open(changelog_path) as f:
                    existing = f.read()

            if existing:
                from .formatter import prepend_to_changelog
                updated = prepend_to_changelog(existing, new_section)
            else:
                updated = new_section

            with open(changelog_path, "w") as f:
                f.write(updated)
            console.print(f"[green]CHANGELOG.md updated ({len(commits)} commits)[/green]")


@cli.command()
@click.option("--template", "-t", default="keepachangelog", help="Template to use")
@click.pass_context
def init(ctx: click.Context, template: str) -> None:
    """Create initial CHANGELOG.md."""
    cwd = get_cwd(ctx)
    changelog_path = os.path.join(cwd, "CHANGELOG.md")

    if os.path.exists(changelog_path):
        console.print("[yellow]CHANGELOG.md already exists.[/yellow]")
        return

    content = get_template(template)
    with open(changelog_path, "w") as f:
        f.write(content)
    console.print("[green]Created CHANGELOG.md[/green]")


@cli.command()
@click.pass_context
def validate(ctx: click.Context) -> None:
    """Check if CHANGELOG is up to date."""
    cwd = get_cwd(ctx)
    config = Config.load()
    changelog_path = os.path.join(cwd, "CHANGELOG.md")

    if not os.path.exists(changelog_path):
        console.print("[red]CHANGELOG.md not found.[/red]")
        sys.exit(1)

    since_tag = git_ops.get_latest_tag(cwd=cwd, prefix=config.tag_prefix)
    commits = collect_from_git(since_tag=since_tag, cwd=cwd)

    if not commits:
        console.print("[green]CHANGELOG is up to date.[/green]")
        return

    console.print(f"[yellow]Found {len(commits)} unreleased commits not in CHANGELOG.[/yellow]")
    for commit in commits[:5]:
        console.print(f"  - {commit.description}")
    if len(commits) > 5:
        console.print(f"  ... and {len(commits) - 5} more")
    sys.exit(1)


@cli.command()
@click.argument("version")
@click.option("--dry-run", is_flag=True, help="Preview without creating release")
@click.pass_context
def release(ctx: click.Context, version: str, dry_run: bool) -> None:
    """Generate changelog, commit, and tag a release."""
    cwd = get_cwd(ctx)
    config = Config.load()

    result = create_release(version, config=config, cwd=cwd, dry_run=dry_run)
    console.print(result)


@cli.command()
@click.option("--since", "-s", default=None, help="Since tag")
@click.pass_context
def contributors(ctx: click.Context, since: str | None) -> None:
    """List all contributors."""
    cwd = get_cwd(ctx)
    config = Config.load()
    since_tag = since or git_ops.get_latest_tag(cwd=cwd, prefix=config.tag_prefix)

    contribs = git_ops.get_contributors(since_tag=since_tag, cwd=cwd)

    if not contribs:
        console.print("[yellow]No contributors found.[/yellow]")
        return

    table = Table(title="Contributors")
    table.add_column("Name", style="bold")
    table.add_column("Email")
    table.add_column("Commits", justify="right")

    for c in contribs:
        table.add_row(c["name"], c["email"], str(c["commits"]))

    console.print(table)


if __name__ == "__main__":
    cli()
