"""Collect commits from git log or GitHub API."""

from typing import Optional

from . import git as git_ops
from .github import GitHubClient
from .parser import ParsedCommit, parse_commit


def collect_from_git(
    since_tag: Optional[str] = None,
    cwd: Optional[str] = None,
) -> list[ParsedCommit]:
    """Collect commits from local git log."""
    raw_commits = git_ops.get_commits_since_tag(tag=since_tag, cwd=cwd)
    return [parse_commit(msg, author) for _hash, msg, author in raw_commits]


def collect_from_github(
    owner: str,
    repo: str,
    since_tag: Optional[str] = None,
    token: Optional[str] = None,
    base: str = "main",
) -> list[ParsedCommit]:
    """Collect merged PRs from GitHub API."""
    client = GitHubClient(owner=owner, repo=repo, token=token)
    return client.get_merged_prs(since_tag=since_tag, base=base)
