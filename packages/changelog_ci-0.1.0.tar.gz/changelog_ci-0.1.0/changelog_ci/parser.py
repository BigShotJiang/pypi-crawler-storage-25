"""Parse conventional commit messages and PR titles."""

import re
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class ParsedCommit:
    """Represents a parsed conventional commit."""
    raw: str
    prefix: Optional[str] = None
    scope: Optional[str] = None
    description: str = ""
    breaking: bool = False
    body: str = ""
    pr_number: Optional[int] = None
    author: str = ""

    @property
    def category_hint(self) -> Optional[str]:
        """Map prefix to category."""
        mapping = {
            "feat": "Features",
            "fix": "Bug Fixes",
            "docs": "Documentation",
            "perf": "Performance",
            "refactor": "Internal",
            "test": "Internal",
            "ci": "Internal",
            "chore": "Internal",
            "build": "Internal",
            "style": "Internal",
        }
        if self.prefix:
            return mapping.get(self.prefix)
        return None


# Conventional commit: type(scope)!: description (#123)
CC_RE = re.compile(
    r"^(?P<prefix>[a-z]+)"
    r"(?:\((?P<scope>[^)]+)\))?"
    r"(?P<breaking>!)?"
    r":\s*(?P<desc>.+?)"
    r"(?:\s+\(#(?P<pr>\d+)\))?$",
    re.IGNORECASE,
)

# PR number in parens anywhere
PR_RE = re.compile(r"\(#(\d+)\)")

# Breaking change footer
BREAKING_FOOTER_RE = re.compile(
    r"^BREAKING[ -]CHANGE:\s*(.+)", re.MULTILINE | re.IGNORECASE
)


def parse_commit(message: str, author: str = "") -> ParsedCommit:
    """Parse a git commit message into a ParsedCommit."""
    lines = message.strip().split("\n")
    title = lines[0]
    body = "\n".join(lines[1:]).strip() if len(lines) > 1 else ""

    pc = ParsedCommit(raw=message, description=title, body=body, author=author)

    # Try conventional commit format
    m = CC_RE.match(title)
    if m:
        pc.prefix = m.group("prefix").lower()
        pc.scope = m.group("scope")
        pc.description = m.group("desc").strip()
        pc.breaking = m.group("breaking") == "!"
        pc.pr_number = int(m.group("pr")) if m.group("pr") else None
    else:
        # Try to extract PR number from title
        pr_match = PR_RE.search(title)
        if pr_match:
            pc.pr_number = int(pr_match.group(1))

    # Check body for BREAKING CHANGE footer
    if not pc.breaking and body:
        if BREAKING_FOOTER_RE.search(body):
            pc.breaking = True

    return pc


def parse_commits(messages: list[tuple[str, str]]) -> list[ParsedCommit]:
    """Parse multiple commit messages. Input: list of (message, author)."""
    return [parse_commit(msg, author) for msg, author in messages]
