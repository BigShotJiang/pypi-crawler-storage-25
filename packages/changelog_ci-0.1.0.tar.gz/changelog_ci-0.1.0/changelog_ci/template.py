"""Customizable changelog templates."""

TEMPLATE_KEEPACHANGELOG = """\
# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).
"""

TEMPLATE_COMPACT = """\
# Changelog
"""

TEMPLATES = {
    "keepachangelog": TEMPLATE_KEEPACHANGELOG,
    "compact": TEMPLATE_COMPACT,
}


def get_template(name: str = "keepachangelog") -> str:
    """Get a changelog template by name."""
    return TEMPLATES.get(name, TEMPLATE_KEEPACHANGELOG)
