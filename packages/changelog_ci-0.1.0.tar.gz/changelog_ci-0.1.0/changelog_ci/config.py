"""Config file support for .changelog-ci.yaml."""

import os
from dataclasses import dataclass, field
from typing import Optional

import yaml


DEFAULT_CONFIG = {
    "categories": [
        {"name": "Features", "prefixes": ["feat"], "labels": ["enhancement", "feature"]},
        {"name": "Bug Fixes", "prefixes": ["fix"], "labels": ["bug", "bugfix"]},
        {"name": "Performance", "prefixes": ["perf"], "labels": ["performance"]},
        {"name": "Documentation", "prefixes": ["docs"], "labels": ["documentation"]},
        {"name": "Internal", "prefixes": ["chore", "refactor", "test", "ci", "build", "style"], "labels": ["internal"]},
    ],
    "header": "# Changelog",
    "template": "keepachangelog",
    "unreleased": True,
    "tag_prefix": "v",
    "ignore_labels": ["skip-changelog", "dependencies"],
    "contributors": True,
}


@dataclass
class Config:
    """Configuration for changelog-ci."""
    categories: list[dict] = field(default_factory=lambda: DEFAULT_CONFIG["categories"].copy())  # type: ignore
    header: str = "# Changelog"
    template: str = "keepachangelog"
    unreleased: bool = True
    tag_prefix: str = "v"
    ignore_labels: list[str] = field(default_factory=lambda: ["skip-changelog", "dependencies"])
    contributors: bool = True

    @classmethod
    def load(cls, path: Optional[str] = None) -> "Config":
        """Load config from file, falling back to defaults."""
        if path is None:
            candidates = [".changelog-ci.yaml", ".changelog-ci.yml"]
            for c in candidates:
                if os.path.exists(c):
                    path = c
                    break

        if path and os.path.exists(path):
            with open(path) as f:
                data = yaml.safe_load(f) or {}
            return cls(
                categories=data.get("categories", DEFAULT_CONFIG["categories"]),
                header=data.get("header", DEFAULT_CONFIG["header"]),
                template=data.get("template", DEFAULT_CONFIG["template"]),
                unreleased=data.get("unreleased", DEFAULT_CONFIG["unreleased"]),
                tag_prefix=data.get("tag_prefix", DEFAULT_CONFIG["tag_prefix"]),
                ignore_labels=data.get("ignore_labels", DEFAULT_CONFIG["ignore_labels"]),
                contributors=data.get("contributors", DEFAULT_CONFIG["contributors"]),
            )

        return cls()

    def save(self, path: str = ".changelog-ci.yaml") -> None:
        """Save config to file."""
        data = {
            "categories": self.categories,
            "header": self.header,
            "template": self.template,
            "unreleased": self.unreleased,
            "tag_prefix": self.tag_prefix,
            "ignore_labels": self.ignore_labels,
            "contributors": self.contributors,
        }
        with open(path, "w") as f:
            yaml.dump(data, f, default_flow_style=False, sort_keys=False)
