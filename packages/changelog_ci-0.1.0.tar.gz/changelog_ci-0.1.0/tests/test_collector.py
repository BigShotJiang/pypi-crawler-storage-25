"""Tests for the collector."""

from unittest.mock import patch, MagicMock

from changelog_ci.collector import collect_from_git, collect_from_github
from changelog_ci.parser import ParsedCommit


class TestCollectFromGit:
    @patch("changelog_ci.collector.git_ops.get_commits_since_tag")
    def test_basic_collection(self, mock_log):
        mock_log.return_value = [
            ("abc", "feat: new thing (#1)", "Alice"),
            ("def", "fix: bug (#2)", "Bob"),
        ]
        commits = collect_from_git(since_tag="v1.0.0")
        assert len(commits) == 2
        assert commits[0].prefix == "feat"
        assert commits[0].pr_number == 1
        assert commits[1].prefix == "fix"

    @patch("changelog_ci.collector.git_ops.get_commits_since_tag")
    def test_empty(self, mock_log):
        mock_log.return_value = []
        commits = collect_from_git()
        assert commits == []

    @patch("changelog_ci.collector.git_ops.get_commits_since_tag")
    def test_with_author(self, mock_log):
        mock_log.return_value = [("abc", "feat: x", "@charlie")]
        commits = collect_from_git()
        assert commits[0].author == "@charlie"


class TestCollectFromGithub:
    @patch("changelog_ci.collector.GitHubClient")
    def test_basic_collection(self, mock_client_cls):
        mock_client = MagicMock()
        mock_client_cls.return_value = mock_client
        mock_client.get_merged_prs.return_value = [
            ParsedCommit(raw="feat: wow", description="wow", prefix="feat", pr_number=10, author="@user")
        ]

        commits = collect_from_github("owner", "repo", since_tag="v1.0.0")
        assert len(commits) == 1
        assert commits[0].pr_number == 10

    @patch("changelog_ci.collector.GitHubClient")
    def test_with_token(self, mock_client_cls):
        mock_client = MagicMock()
        mock_client_cls.return_value = mock_client
        mock_client.get_merged_prs.return_value = []

        collect_from_github("owner", "repo", token="abc123")
        mock_client_cls.assert_called_with(owner="owner", repo="repo", token="abc123")
