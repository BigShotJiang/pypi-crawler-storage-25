"""Tests for the categorizer."""

from changelog_ci.parser import parse_commit
from changelog_ci.categorizer import categorize_commits, ChangelogData, ChangelogSection


class TestCategorizeCommits:
    def test_feat_goes_to_features(self):
        commits = [parse_commit("feat: add thing (#1)", "@alice")]
        data = categorize_commits(commits)
        sections = {s.name: s for s in data.sections}
        assert "Features" in sections
        assert any("add thing" in e.description for e in sections["Features"].entries)

    def test_fix_goes_to_bugfixes(self):
        commits = [parse_commit("fix: resolve bug (#2)", "@bob")]
        data = categorize_commits(commits)
        sections = {s.name: s for s in data.sections}
        assert "Bug Fixes" in sections

    def test_breaking_dual_listed(self):
        commits = [parse_commit("feat!: change API (#3)", "@charlie")]
        data = categorize_commits(commits)
        sections = {s.name: s for s in data.sections}
        assert "Breaking Changes" in sections
        assert "Features" in sections

    def test_perf_category(self):
        commits = [parse_commit("perf: speed up queries")]
        data = categorize_commits(commits)
        sections = {s.name: s for s in data.sections}
        assert "Performance" in sections

    def test_docs_category(self):
        commits = [parse_commit("docs: update readme")]
        data = categorize_commits(commits)
        sections = {s.name: s for s in data.sections}
        assert "Documentation" in sections

    def test_internal_category(self):
        commits = [parse_commit("chore: bump deps")]
        data = categorize_commits(commits)
        sections = {s.name: s for s in data.sections}
        assert "Internal" in sections

    def test_keyword_detection(self):
        commits = [parse_commit("Add new feature for users")]
        data = categorize_commits(commits)
        sections = {s.name: s for s in data.sections}
        assert "Features" in sections

    def test_unknown_goes_to_other(self):
        commits = [parse_commit("some random change")]
        data = categorize_commits(commits)
        sections = {s.name: s for s in data.sections}
        assert "Other" in sections

    def test_empty_commits(self):
        data = categorize_commits([])
        assert len(data.sections) == 0

    def test_section_order(self):
        commits = [
            parse_commit("chore: cleanup"),
            parse_commit("fix: bug"),
            parse_commit("feat: new thing"),
        ]
        data = categorize_commits(commits)
        names = [s.name for s in data.sections]
        assert names.index("Features") < names.index("Bug Fixes")
        assert names.index("Bug Fixes") < names.index("Internal")

    def test_custom_categories(self):
        custom = [{"name": "New Stuff", "prefixes": ["feat"], "labels": []}]
        commits = [parse_commit("feat: wow")]
        data = categorize_commits(commits, categories=custom)
        assert any(s.name == "New Stuff" for s in data.sections)

    def test_version_default(self):
        data = categorize_commits([])
        assert data.version == "Unreleased"

    def test_multiple_entries_per_section(self):
        commits = [
            parse_commit("feat: a"),
            parse_commit("feat: b"),
        ]
        data = categorize_commits(commits)
        features = {s.name: s for s in data.sections}.get("Features")
        assert features is not None
        assert len(features.entries) == 2
