"""Tests for git operations (mocked)."""

import os
import subprocess
from unittest.mock import patch, MagicMock

import pytest

from changelog_ci.git import (
    run_git,
    get_latest_tag,
    get_all_tags,
    get_commits_since_tag,
    get_contributors,
    create_tag,
    create_release_commit,
)


class TestRunGit:
    @patch("changelog_ci.git.subprocess.run")
    def test_success(self, mock_run):
        mock_run.return_value = MagicMock(stdout="output\n", returncode=0)
        assert run_git("status") == "output"

    @patch("changelog_ci.git.subprocess.run")
    def test_failure(self, mock_run):
        mock_run.return_value = MagicMock(stderr="error", returncode=1)
        with pytest.raises(RuntimeError, match="git status failed"):
            run_git("status")


class TestGetLatestTag:
    @patch("changelog_ci.git.run_git")
    def test_has_tag(self, mock_git):
        mock_git.return_value = "v1.0.0"
        assert get_latest_tag() == "v1.0.0"

    @patch("changelog_ci.git.run_git")
    def test_no_tags(self, mock_git):
        mock_git.side_effect = RuntimeError("no tags")
        assert get_latest_tag() is None


class TestGetAllTags:
    @patch("changelog_ci.git.run_git")
    def test_multiple_tags(self, mock_git):
        mock_git.return_value = "v2.0.0\nv1.0.0"
        tags = get_all_tags()
        assert tags == ["v2.0.0", "v1.0.0"]

    @patch("changelog_ci.git.run_git")
    def test_no_tags(self, mock_git):
        mock_git.side_effect = RuntimeError("no tags")
        assert get_all_tags() == []


class TestGetCommits:
    @patch("changelog_ci.git.run_git")
    def test_with_tag(self, mock_git):
        mock_git.return_value = "abc123|||feat: new (#1)|||Alice\n"
        commits = get_commits_since_tag("v1.0.0")
        assert len(commits) == 1
        assert commits[0][1] == "feat: new (#1)"

    @patch("changelog_ci.git.run_git")
    def test_no_commits(self, mock_git):
        mock_git.return_value = ""
        commits = get_commits_since_tag("v1.0.0")
        assert commits == []

    @patch("changelog_ci.git.run_git")
    def test_git_error(self, mock_git):
        mock_git.side_effect = RuntimeError("fail")
        commits = get_commits_since_tag()
        assert commits == []


class TestGetContributors:
    @patch("changelog_ci.git.run_git")
    def test_multiple_contributors(self, mock_git):
        mock_git.return_value = "Alice|||alice@example.com\nBob|||bob@example.com\nAlice|||alice@example.com"
        contribs = get_contributors()
        assert len(contribs) == 2
        assert contribs[0]["commits"] == 2  # Alice has 2

    @patch("changelog_ci.git.run_git")
    def test_no_contributors(self, mock_git):
        mock_git.side_effect = RuntimeError("fail")
        assert get_contributors() == []


class TestCreateTag:
    @patch("changelog_ci.git.run_git")
    def test_create_tag(self, mock_git):
        mock_git.return_value = ""
        tag = create_tag("1.0.0")
        assert tag == "v1.0.0"
        mock_git.assert_called_once()


class TestCreateReleaseCommit:
    @patch("changelog_ci.git.run_git")
    def test_commit(self, mock_git):
        mock_git.return_value = ""
        create_release_commit("1.0.0")
        assert mock_git.call_count == 2  # add + commit
