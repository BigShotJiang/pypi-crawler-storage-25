"""Tests for the CLI."""

import os
import json
from unittest.mock import patch, MagicMock

import pytest
from click.testing import CliRunner

from changelog_ci.cli import cli
from changelog_ci import __version__


@pytest.fixture
def runner():
    return CliRunner()


class TestVersion:
    def test_version(self, runner):
        result = runner.invoke(cli, ["--version"])
        assert __version__ in result.output


class TestInit:
    def test_init_creates_file(self, runner, tmp_path):
        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(cli, ["init"])
            assert result.exit_code == 0
            assert os.path.exists("CHANGELOG.md")

    @patch("changelog_ci.cli.os.path.exists", return_value=True)
    def test_init_already_exists(self, mock_exists, runner):
        result = runner.invoke(cli, ["init"])
        assert "already exists" in result.output


class TestGenerate:
    @patch("changelog_ci.cli.collect_from_git")
    @patch("changelog_ci.cli.git_ops.get_latest_tag", return_value="v1.0.0")
    def test_dry_run_local(self, mock_tag, mock_collect, runner):
        from changelog_ci.parser import ParsedCommit
        mock_collect.return_value = [
            ParsedCommit(raw="feat: test", description="test", prefix="feat", pr_number=1, author="@a")
        ]
        result = runner.invoke(cli, ["generate", "--dry-run"])
        assert result.exit_code == 0

    @patch("changelog_ci.cli.collect_from_git")
    @patch("changelog_ci.cli.git_ops.get_latest_tag", return_value=None)
    def test_no_commits(self, mock_tag, mock_collect, runner):
        mock_collect.return_value = []
        result = runner.invoke(cli, ["generate"])
        assert "No new commits" in result.output

    @patch("changelog_ci.cli.collect_from_git")
    @patch("changelog_ci.cli.git_ops.get_latest_tag", return_value=None)
    def test_json_output(self, mock_tag, mock_collect, runner):
        from changelog_ci.parser import ParsedCommit
        mock_collect.return_value = [
            ParsedCommit(raw="feat: wow", description="wow", prefix="feat", author="@a")
        ]
        result = runner.invoke(cli, ["generate", "--dry-run", "--format", "json"])
        assert result.exit_code == 0

    @patch("changelog_ci.cli.collect_from_git")
    @patch("changelog_ci.cli.git_ops.get_latest_tag", return_value="v1.0.0")
    def test_with_since(self, mock_tag, mock_collect, runner):
        mock_collect.return_value = []
        result = runner.invoke(cli, ["generate", "--since", "v0.9.0"])
        assert "No new commits" in result.output


class TestValidate:
    @patch("changelog_ci.cli.collect_from_git")
    @patch("changelog_ci.cli.git_ops.get_latest_tag", return_value="v1.0.0")
    def test_up_to_date(self, mock_tag, mock_collect, runner, tmp_path):
        mock_collect.return_value = []
        with runner.isolated_filesystem(temp_dir=tmp_path):
            with open("CHANGELOG.md", "w") as f:
                f.write("# Changelog")
            result = runner.invoke(cli, ["validate"])
            assert "up to date" in result.output

    @patch("changelog_ci.cli.collect_from_git")
    @patch("changelog_ci.cli.git_ops.get_latest_tag", return_value="v1.0.0")
    def test_not_up_to_date(self, mock_tag, mock_collect, runner, tmp_path):
        from changelog_ci.parser import ParsedCommit
        mock_collect.return_value = [
            ParsedCommit(raw="feat: new", description="new", prefix="feat")
        ]
        with runner.isolated_filesystem(temp_dir=tmp_path):
            with open("CHANGELOG.md", "w") as f:
                f.write("# Changelog")
            with patch("changelog_cli.cli.os.path.exists" if False else "changelog_ci.cli.os.path.exists", return_value=True):
                result = runner.invoke(cli, ["validate"])
                assert result.exit_code == 1


class TestRelease:
    @patch("changelog_ci.cli.create_release")
    def test_release_dry_run(self, mock_release, runner):
        mock_release.return_value = "preview"
        result = runner.invoke(cli, ["release", "2.0.0", "--dry-run"])
        assert "preview" in result.output


class TestContributors:
    @patch("changelog_ci.cli.git_ops.get_contributors")
    @patch("changelog_ci.cli.git_ops.get_latest_tag", return_value="v1.0.0")
    def test_with_contributors(self, mock_tag, mock_contribs, runner):
        mock_contribs.return_value = [
            {"name": "Alice", "email": "a@b.com", "commits": 5},
        ]
        result = runner.invoke(cli, ["contributors"])
        assert result.exit_code == 0
        assert "Alice" in result.output

    @patch("changelog_ci.cli.git_ops.get_contributors")
    @patch("changelog_ci.cli.git_ops.get_latest_tag", return_value=None)
    def test_no_contributors(self, mock_tag, mock_contribs, runner):
        mock_contribs.return_value = []
        result = runner.invoke(cli, ["contributors"])
        assert "No contributors" in result.output
