"""Tests for the conventional commit parser."""

import pytest

from changelog_ci.parser import parse_commit, parse_commits, ParsedCommit


class TestParseCommit:
    def test_simple_feat(self):
        pc = parse_commit("feat: add login page")
        assert pc.prefix == "feat"
        assert pc.description == "add login page"
        assert pc.breaking is False
        assert pc.pr_number is None

    def test_feat_with_scope(self):
        pc = parse_commit("feat(auth): add OAuth2 support")
        assert pc.prefix == "feat"
        assert pc.scope == "auth"
        assert pc.description == "add OAuth2 support"

    def test_fix_with_pr(self):
        pc = parse_commit("fix: resolve crash on startup (#42)")
        assert pc.prefix == "fix"
        assert pc.pr_number == 42
        assert pc.description == "resolve crash on startup"

    def test_breaking_bang(self):
        pc = parse_commit("feat!: redesign API")
        assert pc.prefix == "feat"
        assert pc.breaking is True

    def test_breaking_scope_bang(self):
        pc = parse_commit("feat(api)!: change response format")
        assert pc.scope == "api"
        assert pc.breaking is True

    def test_breaking_footer(self):
        msg = "feat: new thing\n\nBREAKING CHANGE: old thing removed"
        pc = parse_commit(msg)
        assert pc.breaking is True
        assert pc.body != ""

    def test_breaking_dash_footer(self):
        msg = "feat: new thing\n\nBREAKING-CHANGE: old thing removed"
        pc = parse_commit(msg)
        assert pc.breaking is True

    def test_non_conventional(self):
        pc = parse_commit("just a regular commit message")
        assert pc.prefix is None
        assert pc.description == "just a regular commit message"

    def test_pr_number_only(self):
        pc = parse_commit("Update README (#10)")
        assert pc.pr_number == 10

    def test_author(self):
        pc = parse_commit("feat: something", author="@alice")
        assert pc.author == "@alice"

    def test_perf(self):
        pc = parse_commit("perf(db): optimize query")
        assert pc.prefix == "perf"
        assert pc.scope == "db"

    def test_category_hint(self):
        assert parse_commit("feat: x").category_hint == "Features"
        assert parse_commit("fix: x").category_hint == "Bug Fixes"
        assert parse_commit("docs: x").category_hint == "Documentation"
        assert parse_commit("perf: x").category_hint == "Performance"
        assert parse_commit("chore: x").category_hint == "Internal"
        assert parse_commit("refactor: x").category_hint == "Internal"
        assert parse_commit("test: x").category_hint == "Internal"

    def test_no_category_hint(self):
        pc = parse_commit("random message")
        assert pc.category_hint is None

    def test_empty_message(self):
        pc = parse_commit("")
        assert pc.prefix is None

    def test_multiline_body(self):
        msg = "feat: add feature\n\nThis is the body.\nMultiple lines."
        pc = parse_commit(msg)
        assert "This is the body" in pc.body

    def test_parse_commits_batch(self):
        messages = [("feat: a (#1)", "@a"), ("fix: b (#2)", "@b")]
        results = parse_commits(messages)
        assert len(results) == 2
        assert results[0].pr_number == 1
        assert results[1].pr_number == 2

    def test_scope_only(self):
        pc = parse_commit("refactor(core): simplify module")
        assert pc.prefix == "refactor"
        assert pc.scope == "core"

    def test_ci_prefix(self):
        pc = parse_commit("ci: update workflow")
        assert pc.prefix == "ci"

    def test_build_prefix(self):
        pc = parse_commit("build: update deps")
        assert pc.prefix == "build"
