"""Tests for the formatter."""

from changelog_ci.categorizer import ChangelogData, ChangelogSection, ChangeEntry
from changelog_ci.formatter import format_markdown, format_json, prepend_to_changelog


def _sample_data() -> ChangelogData:
    data = ChangelogData(version="2.2.0", date="2026-04-07")
    section = ChangelogSection(name="Features")
    section.entries.append(ChangeEntry(
        description="Add pagination support", pr_number=142, author="@johndoe"
    ))
    data.sections.append(section)
    section2 = ChangelogSection(name="Bug Fixes")
    section2.entries.append(ChangeEntry(
        description="Fix race condition", pr_number=145, author="@janedoe"
    ))
    data.sections.append(section2)
    return data


class TestFormatMarkdown:
    def test_basic_output(self):
        data = _sample_data()
        md = format_markdown(data)
        assert "## [2.2.0] - 2026-04-07" in md
        assert "### Features" in md
        assert "Add pagination support (#142)" in md
        assert "@johndoe" in md

    def test_custom_header(self):
        data = _sample_data()
        md = format_markdown(data, header="# My Changes")
        assert "# My Changes" in md

    def test_no_contributors(self):
        data = _sample_data()
        md = format_markdown(data, contributors=False)
        assert "@johndoe" not in md

    def test_unreleased_hidden(self):
        data = ChangelogData(version="Unreleased", date="2026-04-07")
        md = format_markdown(data, unreleased=False)
        assert md == ""

    def test_unreleased_shown(self):
        data = ChangelogData(version="Unreleased", date="2026-04-07")
        section = ChangelogSection(name="Features")
        section.entries.append(ChangeEntry(description="test"))
        data.sections.append(section)
        md = format_markdown(data, unreleased=True)
        assert "## [Unreleased]" in md

    def test_breaking_emoji(self):
        data = ChangelogData(version="1.0.0", date="2026-04-07")
        section = ChangelogSection(name="Breaking Changes")
        section.entries.append(ChangeEntry(description="Remove old API"))
        data.sections.append(section)
        md = format_markdown(data)
        assert "⚠️" in md

    def test_entry_without_pr(self):
        data = ChangelogData(version="1.0.0", date="2026-04-07")
        section = ChangelogSection(name="Features")
        section.entries.append(ChangeEntry(description="Something new"))
        data.sections.append(section)
        md = format_markdown(data)
        assert "- Something new" in md


class TestFormatJson:
    def test_basic_json(self):
        data = _sample_data()
        j = format_json(data)
        parsed = __import__("json").loads(j)
        assert parsed["version"] == "2.2.0"
        assert "Features" in parsed["sections"]

    def test_json_pr_number(self):
        data = _sample_data()
        j = format_json(data)
        parsed = __import__("json").loads(j)
        entry = parsed["sections"]["Features"][0]
        assert entry["pr"] == 142

    def test_json_breaking_flag(self):
        data = ChangelogData(version="1.0.0", date="2026-04-07")
        section = ChangelogSection(name="Features")
        section.entries.append(ChangeEntry(description="test", breaking=True))
        data.sections.append(section)
        j = format_json(data)
        parsed = __import__("json").loads(j)
        assert parsed["sections"]["Features"][0]["breaking"] is True


class TestPrepend:
    def test_prepend_to_empty(self):
        result = prepend_to_changelog("", "# Changelog\n\n## [1.0.0]")
        assert "## [1.0.0]" in result

    def test_prepend_to_existing(self):
        existing = "# Changelog\n\n## [1.0.0] - 2026-01-01\n\n### Features\n- stuff\n"
        new = "# Changelog\n\n## [2.0.0] - 2026-04-07\n\n### Features\n- new stuff\n"
        result = prepend_to_changelog(existing, new)
        assert result.index("2.0.0") < result.index("1.0.0")
