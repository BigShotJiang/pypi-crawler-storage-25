# TokenPak Commercial License

## Open Source

TokenPak is licensed under the MIT License. See [LICENSE](./LICENSE) for details.

You may use TokenPak for any purpose, including commercial applications, without charge or restriction. All features are included in the open-source release.

---

## Usage Restrictions

The following restrictions apply to all usage:

1. Reselling or sublicensing TokenPak as a standalone product is not permitted
2. Removing or obscuring TokenPak branding in managed services is not permitted
3. Sharing credentials across organizations is not permitted

## Ownership

TokenPak and all features remain the intellectual property of TokenPak. The MIT license grants usage rights as described in [LICENSE](./LICENSE).

## Support

- **Community support** — GitHub Issues (no SLA)
- **Email support** — hello@tokenpak.ai

## Questions?

- Email: hello@tokenpak.ai
- Documentation: https://docs.tokenpak.ai
