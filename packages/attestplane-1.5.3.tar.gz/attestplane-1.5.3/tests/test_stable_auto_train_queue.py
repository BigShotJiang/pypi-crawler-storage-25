from __future__ import annotations

import importlib.util
import json
import subprocess
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[3]
SCRIPT_PATH = REPO_ROOT / "scripts/release/stable_auto_train.py"

spec = importlib.util.spec_from_file_location("stable_auto_train", SCRIPT_PATH)
assert spec is not None and spec.loader is not None
stable_auto_train = importlib.util.module_from_spec(spec)
sys.modules["stable_auto_train"] = stable_auto_train
spec.loader.exec_module(stable_auto_train)


def test_target_queue_loads_strictly_increasing_stable_targets(tmp_path: Path) -> None:
    queue = tmp_path / "queue.json"
    queue.write_text(
        json.dumps(
            {
                "schema": "attestplane_autodev_train_targets.v2",
                "targets": [
                    {"version": "0.8.6", "status": "queued", "channel": "latest", "min_soak_hours": 0},
                    {"version": "0.9.0", "status": "queued", "channel": "latest", "min_soak_hours": 0},
                ],
            }
        ),
        encoding="utf-8",
    )

    targets = stable_auto_train.load_target_queue(queue)

    assert [target.version.tag for target in targets] == ["v0.8.6", "v0.9.0"]
    assert all(target.channel == "latest" for target in targets)


def test_target_queue_rejects_rc_channel(tmp_path: Path) -> None:
    queue = tmp_path / "queue.json"
    queue.write_text(
        json.dumps(
            {
                "schema": "attestplane_autodev_train_targets.v2",
                "targets": [
                    {"version": "0.8.6", "status": "queued", "channel": "rc", "min_soak_hours": 0},
                ],
            }
        ),
        encoding="utf-8",
    )

    with pytest.raises(RuntimeError, match="unsupported"):
        stable_auto_train.load_target_queue(queue)


def test_target_queue_rejects_non_increasing_versions(tmp_path: Path) -> None:
    queue = tmp_path / "queue.json"
    queue.write_text(
        json.dumps(
            {
                "schema": "attestplane_autodev_train_targets.v2",
                "targets": [
                    {"version": "0.8.7", "status": "queued", "channel": "latest", "min_soak_hours": 0},
                    {"version": "0.8.6", "status": "queued", "channel": "latest", "min_soak_hours": 0},
                ],
            }
        ),
        encoding="utf-8",
    )

    with pytest.raises(RuntimeError, match="strictly increasing"):
        stable_auto_train.load_target_queue(queue)


def test_next_stable_after_advances_patch_until_ten() -> None:
    current = stable_auto_train.StableVersion.parse("0.8.9")

    assert stable_auto_train.next_stable_after(current).tag == "v0.8.10"


def test_next_stable_after_rolls_patch_ten_to_next_minor_zero() -> None:
    current = stable_auto_train.StableVersion.parse("0.8.10")

    assert stable_auto_train.next_stable_after(current).tag == "v0.9.0"


def test_next_stable_after_continues_after_minor_boundary() -> None:
    current = stable_auto_train.StableVersion.parse("0.9.0")

    assert stable_auto_train.next_stable_after(current).tag == "v0.9.1"


def test_next_stable_after_rolls_zero_nine_ten_to_one_zero_zero() -> None:
    current = stable_auto_train.StableVersion.parse("0.9.10")

    assert stable_auto_train.next_stable_after(current).tag == "v1.0.0"


def test_next_stable_after_rolls_post_one_patch_ten_to_next_minor_zero() -> None:
    current = stable_auto_train.StableVersion.parse("1.0.10")

    assert stable_auto_train.next_stable_after(current).tag == "v1.1.0"


def test_sync_main_with_origin_fast_forwards_when_local_is_behind(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[list[str]] = []

    def fake_capture(argv: list[str], *, timeout: int | None = None) -> str:
        del timeout
        if argv == ["git", "rev-parse", "HEAD"]:
            return "local"
        if argv == ["git", "rev-parse", "origin/main"]:
            return "remote"
        raise AssertionError(argv)

    def fake_is_ancestor(ancestor: str, descendant: str) -> bool:
        return (ancestor, descendant) == ("HEAD", "origin/main")

    monkeypatch.setattr(stable_auto_train, "capture", fake_capture)
    monkeypatch.setattr(stable_auto_train, "git_ref_is_ancestor", fake_is_ancestor)
    monkeypatch.setattr(stable_auto_train, "run", calls.append)

    stable_auto_train.sync_main_with_origin()

    assert calls == [["git", "merge", "--ff-only", "origin/main"]]


def test_sync_main_with_origin_allows_local_ahead(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[list[str]] = []

    def fake_capture(argv: list[str], *, timeout: int | None = None) -> str:
        del timeout
        if argv == ["git", "rev-parse", "HEAD"]:
            return "local"
        if argv == ["git", "rev-parse", "origin/main"]:
            return "remote"
        raise AssertionError(argv)

    def fake_is_ancestor(ancestor: str, descendant: str) -> bool:
        return (ancestor, descendant) == ("origin/main", "HEAD")

    monkeypatch.setattr(stable_auto_train, "capture", fake_capture)
    monkeypatch.setattr(stable_auto_train, "git_ref_is_ancestor", fake_is_ancestor)
    monkeypatch.setattr(stable_auto_train, "run", calls.append)

    stable_auto_train.sync_main_with_origin()

    assert calls == []


def test_sync_main_with_origin_blocks_divergence(monkeypatch: pytest.MonkeyPatch) -> None:
    def fake_capture(argv: list[str], *, timeout: int | None = None) -> str:
        del timeout
        if argv == ["git", "rev-parse", "HEAD"]:
            return "local"
        if argv == ["git", "rev-parse", "origin/main"]:
            return "remote"
        raise AssertionError(argv)

    monkeypatch.setattr(stable_auto_train, "capture", fake_capture)
    monkeypatch.setattr(stable_auto_train, "git_ref_is_ancestor", lambda ancestor, descendant: False)

    with pytest.raises(RuntimeError, match="have diverged"):
        stable_auto_train.sync_main_with_origin()


def test_select_target_recovers_latest_incomplete_tag(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    queue = tmp_path / "queue.json"
    queue.write_text(
        json.dumps(
            {
                "schema": "attestplane_autodev_train_targets.v2",
                "targets": [
                    {"version": "1.0.7", "status": "queued", "channel": "latest", "min_soak_hours": 0},
                ],
            }
        ),
        encoding="utf-8",
    )
    latest = stable_auto_train.StableVersion.parse("1.0.6")
    monkeypatch.setattr(stable_auto_train, "latest_stable", lambda: latest)
    monkeypatch.setattr(
        stable_auto_train,
        "publication_status",
        lambda version: stable_auto_train.PublicationStatus(
            python_visible=False,
            npm_visible=True,
            npm_latest=True,
            github_release=False,
        ),
    )

    target = stable_auto_train.select_target(queue)

    assert target.version.tag == "v1.0.6"


def test_recover_existing_release_repairs_transient_python_publish(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    version = stable_auto_train.StableVersion.parse("1.0.6")
    status_checks = iter(
        [
            stable_auto_train.PublicationStatus(
                python_visible=False,
                npm_visible=True,
                npm_latest=True,
                github_release=False,
            ),
            stable_auto_train.PublicationStatus(
                python_visible=True,
                npm_visible=True,
                npm_latest=True,
                github_release=True,
            ),
        ]
    )
    calls: list[str] = []
    monkeypatch.setattr(stable_auto_train, "publication_status", lambda target: next(status_checks))
    monkeypatch.setattr(stable_auto_train, "dispatch_publish_python", lambda target: calls.append("publish-python"))
    monkeypatch.setattr(stable_auto_train, "wait_for_pypi", lambda target: calls.append("wait-pypi"))
    monkeypatch.setattr(stable_auto_train, "ensure_github_release", lambda target: calls.append("github-release"))

    stable_auto_train.recover_existing_release(version)

    assert calls == ["publish-python", "wait-pypi", "github-release"]


def test_recover_existing_release_refuses_incomplete_npm_state() -> None:
    version = stable_auto_train.StableVersion.parse("1.0.6")

    with pytest.MonkeyPatch.context() as monkeypatch:
        monkeypatch.setattr(
            stable_auto_train,
            "publication_status",
            lambda target: stable_auto_train.PublicationStatus(
                python_visible=True,
                npm_visible=False,
                npm_latest=False,
                github_release=False,
            ),
        )
        with pytest.raises(RuntimeError, match="npm state is incomplete"):
            stable_auto_train.recover_existing_release(version)


def test_recover_existing_release_retries_later_on_unknown_probe() -> None:
    version = stable_auto_train.StableVersion.parse("1.0.6")

    with pytest.MonkeyPatch.context() as monkeypatch:
        monkeypatch.setattr(
            stable_auto_train,
            "publication_status",
            lambda target: stable_auto_train.PublicationStatus(
                python_visible=None,
                npm_visible=True,
                npm_latest=True,
                github_release=True,
            ),
        )
        with pytest.raises(RuntimeError, match="probe is incomplete"):
            stable_auto_train.recover_existing_release(version)


def test_run_once_resumes_locally_tagged_unpublished_release(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    queue = tmp_path / "queue.json"
    queue.write_text(
        json.dumps(
            {
                "schema": "attestplane_autodev_train_targets.v2",
                "targets": [
                    {"version": "1.0.9", "status": "queued", "channel": "latest", "min_soak_hours": 0},
                ],
            }
        ),
        encoding="utf-8",
    )
    version = stable_auto_train.StableVersion.parse("1.0.9")
    calls: list[str] = []

    monkeypatch.setattr(stable_auto_train, "assert_clean_tree", lambda: None)
    monkeypatch.setattr(stable_auto_train, "assert_on_main", lambda: None)
    monkeypatch.setattr(stable_auto_train, "best_effort_fetch_tags", lambda: None)
    monkeypatch.setattr(stable_auto_train, "sync_main_with_origin", lambda: None)
    monkeypatch.setattr(stable_auto_train, "latest_stable", lambda: version)
    monkeypatch.setattr(
        stable_auto_train,
        "latest_stable_before",
        lambda target: stable_auto_train.StableVersion.parse("1.0.8"),
    )
    monkeypatch.setattr(stable_auto_train, "assert_release_gate_allows_target", lambda target: None)
    monkeypatch.setattr(stable_auto_train, "git_ref_exists", lambda ref: ref == "refs/tags/v1.0.9")
    monkeypatch.setattr(stable_auto_train, "remote_tag_exists", lambda tag: False)
    monkeypatch.setattr(stable_auto_train, "local_tag_points_to_head", lambda tag: True)
    monkeypatch.setattr(
        stable_auto_train,
        "publication_status",
        lambda target: stable_auto_train.PublicationStatus(
            python_visible=False,
            npm_visible=False,
            npm_latest=False,
            github_release=False,
        ),
    )
    monkeypatch.setattr(
        stable_auto_train,
        "resume_tagged_release_publish",
        lambda target, *, wait: calls.append(f"resume:{target.tag}:wait={wait}"),
    )
    monkeypatch.setattr(stable_auto_train, "recover_existing_release", lambda target: calls.append("recover"))

    result = stable_auto_train.run_once(publish=True, wait=True, target_queue=queue, dry_run=False)

    assert result == "v1.0.9"
    assert calls == ["resume:v1.0.9:wait=True"]


def test_reconcile_unpublished_local_stable_tag_deletes_superseded_local_tag(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    version = stable_auto_train.StableVersion.parse("1.0.9")
    calls: list[list[str]] = []

    monkeypatch.setattr(stable_auto_train, "latest_stable", lambda: version)
    monkeypatch.setattr(stable_auto_train, "git_ref_exists", lambda ref: ref == "refs/tags/v1.0.9")
    monkeypatch.setattr(stable_auto_train, "remote_tag_exists", lambda tag: False)
    monkeypatch.setattr(stable_auto_train, "local_tag_points_to_head", lambda tag: False)
    monkeypatch.setattr(
        stable_auto_train,
        "publication_status",
        lambda target: stable_auto_train.PublicationStatus(
            python_visible=False,
            npm_visible=False,
            npm_latest=False,
            github_release=False,
        ),
    )
    monkeypatch.setattr(stable_auto_train, "git_ref_is_ancestor", lambda ancestor, descendant: True)
    monkeypatch.setattr(stable_auto_train, "run", calls.append)

    stable_auto_train.reconcile_unpublished_local_stable_tag()

    assert calls == [["git", "tag", "-d", "v1.0.9"]]


def test_reconcile_unpublished_local_stable_tag_keeps_remote_tag(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    version = stable_auto_train.StableVersion.parse("1.0.9")
    calls: list[list[str]] = []

    monkeypatch.setattr(stable_auto_train, "latest_stable", lambda: version)
    monkeypatch.setattr(stable_auto_train, "git_ref_exists", lambda ref: ref == "refs/tags/v1.0.9")
    monkeypatch.setattr(stable_auto_train, "remote_tag_exists", lambda tag: True)
    monkeypatch.setattr(stable_auto_train, "run", calls.append)

    stable_auto_train.reconcile_unpublished_local_stable_tag()

    assert calls == []


def test_run_once_reconciles_superseded_local_tag_before_target_selection(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    queue = tmp_path / "queue.json"
    queue.write_text(
        json.dumps(
            {
                "schema": "attestplane_autodev_train_targets.v2",
                "targets": [
                    {"version": "1.0.9", "status": "queued", "channel": "latest", "min_soak_hours": 0},
                ],
            }
        ),
        encoding="utf-8",
    )
    calls: list[str] = []

    monkeypatch.setattr(stable_auto_train, "assert_clean_tree", lambda: None)
    monkeypatch.setattr(stable_auto_train, "assert_on_main", lambda: None)
    monkeypatch.setattr(stable_auto_train, "best_effort_fetch_tags", lambda: None)
    monkeypatch.setattr(stable_auto_train, "sync_main_with_origin", lambda: calls.append("sync"))
    monkeypatch.setattr(stable_auto_train, "reconcile_unpublished_local_stable_tag", lambda: calls.append("reconcile"))
    monkeypatch.setattr(stable_auto_train, "latest_stable", lambda: stable_auto_train.StableVersion.parse("1.0.8"))
    monkeypatch.setattr(
        stable_auto_train,
        "latest_stable_before",
        lambda target: stable_auto_train.StableVersion.parse("1.0.8"),
    )
    monkeypatch.setattr(
        stable_auto_train,
        "publication_status",
        lambda target: stable_auto_train.PublicationStatus(
            python_visible=True,
            npm_visible=True,
            npm_latest=True,
            github_release=True,
        ),
    )
    monkeypatch.setattr(stable_auto_train, "assert_release_gate_allows_target", lambda target: None)
    monkeypatch.setattr(stable_auto_train, "git_ref_exists", lambda ref: False)
    monkeypatch.setattr(stable_auto_train, "remote_tag_exists", lambda tag: False)
    monkeypatch.setattr(
        stable_auto_train,
        "commits_since_tag_have_real_work",
        lambda tag: calls.append(f"cadence:{tag}") or True,
    )

    result = stable_auto_train.run_once(publish=False, wait=False, target_queue=queue, dry_run=True)

    assert result == "v1.0.9"
    assert calls[:2] == ["sync", "reconcile"]


def test_run_once_skips_generated_target_before_remote_probe_when_no_real_work(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    queue = tmp_path / "queue.json"
    queue.write_text(
        json.dumps(
            {
                "schema": "attestplane_autodev_train_targets.v2",
                "targets": [
                    {"version": "1.0.8", "status": "queued", "channel": "latest", "min_soak_hours": 0},
                ],
            }
        ),
        encoding="utf-8",
    )
    latest = stable_auto_train.StableVersion.parse("1.0.8")
    calls: list[str] = []

    monkeypatch.setattr(stable_auto_train, "assert_clean_tree", lambda: None)
    monkeypatch.setattr(stable_auto_train, "assert_on_main", lambda: None)
    monkeypatch.setattr(stable_auto_train, "best_effort_fetch_tags", lambda: None)
    monkeypatch.setattr(stable_auto_train, "sync_main_with_origin", lambda: None)
    monkeypatch.setattr(stable_auto_train, "reconcile_unpublished_local_stable_tag", lambda: None)
    monkeypatch.setattr(stable_auto_train, "latest_stable", lambda: latest)
    monkeypatch.setattr(stable_auto_train, "latest_stable_before", lambda target: latest)
    monkeypatch.setattr(
        stable_auto_train,
        "publication_status",
        lambda target: stable_auto_train.PublicationStatus(
            python_visible=True,
            npm_visible=True,
            npm_latest=True,
            github_release=True,
        ),
    )
    monkeypatch.setattr(stable_auto_train, "assert_release_gate_allows_target", lambda target: None)
    monkeypatch.setattr(stable_auto_train, "git_ref_exists", lambda ref: ref == "refs/tags/v1.0.8")
    monkeypatch.setattr(
        stable_auto_train,
        "remote_tag_exists",
        lambda tag: (_ for _ in ()).throw(AssertionError(f"unexpected remote probe for {tag}")),
    )
    monkeypatch.setattr(
        stable_auto_train,
        "commits_since_tag_have_real_work",
        lambda tag: calls.append(f"cadence:{tag}") or False,
    )

    result = stable_auto_train.run_once(publish=True, wait=True, target_queue=queue, dry_run=False)

    assert result == "v1.0.8"
    assert calls == ["cadence:v1.0.8"]


def test_run_once_refuses_unknown_status_for_existing_tag(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    queue = tmp_path / "queue.json"
    queue.write_text(
        json.dumps(
            {
                "schema": "attestplane_autodev_train_targets.v2",
                "targets": [
                    {"version": "1.0.9", "status": "queued", "channel": "latest", "min_soak_hours": 0},
                ],
            }
        ),
        encoding="utf-8",
    )
    version = stable_auto_train.StableVersion.parse("1.0.9")

    monkeypatch.setattr(stable_auto_train, "assert_clean_tree", lambda: None)
    monkeypatch.setattr(stable_auto_train, "assert_on_main", lambda: None)
    monkeypatch.setattr(stable_auto_train, "best_effort_fetch_tags", lambda: None)
    monkeypatch.setattr(stable_auto_train, "sync_main_with_origin", lambda: None)
    monkeypatch.setattr(stable_auto_train, "latest_stable", lambda: version)
    monkeypatch.setattr(
        stable_auto_train,
        "latest_stable_before",
        lambda target: stable_auto_train.StableVersion.parse("1.0.8"),
    )
    monkeypatch.setattr(stable_auto_train, "assert_release_gate_allows_target", lambda target: None)
    monkeypatch.setattr(stable_auto_train, "git_ref_exists", lambda ref: ref == "refs/tags/v1.0.9")
    monkeypatch.setattr(stable_auto_train, "remote_tag_exists", lambda tag: False)
    monkeypatch.setattr(stable_auto_train, "local_tag_points_to_head", lambda tag: True)
    monkeypatch.setattr(
        stable_auto_train,
        "publication_status",
        lambda target: stable_auto_train.PublicationStatus(
            python_visible=None,
            npm_visible=False,
            npm_latest=False,
            github_release=False,
        ),
    )

    with pytest.raises(RuntimeError, match="publication status probe is incomplete"):
        stable_auto_train.run_once(publish=True, wait=True, target_queue=queue, dry_run=False)


def test_stable_train_blocks_unverified_major_boundary() -> None:
    target = stable_auto_train.ReleaseTarget(
        version=stable_auto_train.StableVersion.parse("1.0.0"),
        channel="latest",
        min_soak_hours=0,
    )

    with pytest.raises(RuntimeError, match="audit_required_without_verified_plan"):
        stable_auto_train.assert_release_gate_allows_target(target)


def test_stable_train_allows_minor_zero_after_major_boundary() -> None:
    target = stable_auto_train.ReleaseTarget(
        version=stable_auto_train.StableVersion.parse("1.1.0"),
        channel="latest",
        min_soak_hours=0,
    )

    stable_auto_train.assert_release_gate_allows_target(target)


def test_wait_for_push_ci_allows_successful_required_workflows(monkeypatch: pytest.MonkeyPatch) -> None:
    head_sha = "abc123"
    runs = [
        {
            "conclusion": "success",
            "databaseId": index,
            "headSha": head_sha,
            "name": name,
            "status": "completed",
            "url": f"https://example.test/{name}",
        }
        for index, name in enumerate(stable_auto_train.PUSH_CI_WORKFLOWS, start=1)
    ]

    monkeypatch.setattr(stable_auto_train, "capture", lambda argv: json.dumps(runs))

    stable_auto_train.wait_for_push_ci(head_sha)


def test_push_and_dispatch_uses_timed_pushes_before_release_cd(monkeypatch: pytest.MonkeyPatch) -> None:
    version = stable_auto_train.StableVersion.parse("1.1.3")
    calls: list[tuple[str, list[str]]] = []

    monkeypatch.setattr(
        stable_auto_train,
        "run_git_push",
        lambda argv: calls.append(("push", argv)),
    )
    monkeypatch.setattr(stable_auto_train, "capture", lambda argv: "abc123")
    monkeypatch.setattr(stable_auto_train, "wait_for_push_ci", lambda head_sha: calls.append(("ci", [head_sha])))
    monkeypatch.setattr(stable_auto_train, "run", lambda argv: calls.append(("run", argv)))

    stable_auto_train.push_and_dispatch(version, wait=False)

    assert calls == [
        ("push", ["git", "push", "origin", "main"]),
        ("ci", ["abc123"]),
        ("push", ["git", "push", "origin", "v1.1.3"]),
        ("run", stable_auto_train.release_cd_dispatch_args(version)),
    ]


def test_run_git_push_skips_when_remote_already_converged(monkeypatch: pytest.MonkeyPatch) -> None:
    attempts: list[list[str]] = []

    def fail_if_attempted(argv: list[str]) -> None:
        attempts.append(argv)

    monkeypatch.setattr(stable_auto_train, "git_push_remote_status", lambda argv: (True, None))
    monkeypatch.setattr(stable_auto_train, "attempt_git_push_once", fail_if_attempted)

    result = stable_auto_train.run_git_push(["git", "push", "origin", "main"])

    assert result.returncode == 0
    assert result.args == ["git", *stable_auto_train.GIT_HTTP_CONFIG_ARGS, "push", "origin", "main"]
    assert attempts == []


def test_run_git_push_attempts_push_when_preflight_probe_fails(monkeypatch: pytest.MonkeyPatch) -> None:
    attempts: list[list[str]] = []

    monkeypatch.setattr(stable_auto_train, "git_push_remote_status", lambda argv: (False, "git_push_timeout"))

    def fake_attempt(argv: list[str]) -> subprocess.CompletedProcess[str]:
        attempts.append(argv)
        return subprocess.CompletedProcess(argv, 0, "", "")

    monkeypatch.setattr(stable_auto_train, "attempt_git_push_once", fake_attempt)

    result = stable_auto_train.run_git_push(["git", "push", "origin", "main"])

    assert result.returncode == 0
    assert attempts == [["git", *stable_auto_train.GIT_HTTP_CONFIG_ARGS, "push", "origin", "main"]]


def test_run_git_push_retries_timeouts(monkeypatch: pytest.MonkeyPatch) -> None:
    calls = {"attempts": 0}

    monkeypatch.setattr(stable_auto_train, "git_push_remote_status", lambda argv: (False, None))
    monkeypatch.setattr(stable_auto_train, "git_push_remote_converged", lambda argv: False)
    monkeypatch.setattr(stable_auto_train.time, "sleep", lambda seconds: None)

    def fake_attempt(argv: list[str]) -> object:
        calls["attempts"] += 1
        if calls["attempts"] < 2:
            raise subprocess.TimeoutExpired(argv, stable_auto_train.REMOTE_PUSH_TIMEOUT_SECONDS)
        return subprocess.CompletedProcess(argv, 0, "", "")

    monkeypatch.setattr(stable_auto_train, "attempt_git_push_once", fake_attempt)

    result = stable_auto_train.run_git_push(["git", "push", "origin", "v1.1.3"])

    assert result.returncode == 0
    assert calls["attempts"] == 2


def test_wait_for_push_ci_blocks_failed_required_workflow(monkeypatch: pytest.MonkeyPatch) -> None:
    head_sha = "abc123"
    runs = [
        {
            "conclusion": "success",
            "databaseId": index,
            "headSha": head_sha,
            "name": name,
            "status": "completed",
            "url": f"https://example.test/{name}",
        }
        for index, name in enumerate(stable_auto_train.PUSH_CI_WORKFLOWS, start=1)
    ]
    runs[0] = {**runs[0], "conclusion": "failure"}

    monkeypatch.setattr(stable_auto_train, "capture", lambda argv: json.dumps(runs))

    with pytest.raises(RuntimeError, match=r"push CI failed.*ci=failure"):
        stable_auto_train.wait_for_push_ci(head_sha)


def test_wait_for_push_ci_accepts_manual_dispatch_for_path_filtered_workflow(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    head_sha = "abc123"
    runs = [
        {
            "conclusion": "success",
            "databaseId": index,
            "event": "push",
            "headSha": head_sha,
            "name": name,
            "status": "completed",
            "url": f"https://example.test/{name}",
        }
        for index, name in enumerate(stable_auto_train.PUSH_CI_WORKFLOWS, start=1)
        if name != "sdk-typescript"
    ]
    runs.append(
        {
            "conclusion": "success",
            "databaseId": 999,
            "event": "workflow_dispatch",
            "headSha": head_sha,
            "name": "sdk-typescript",
            "status": "completed",
            "url": "https://example.test/sdk-typescript",
        }
    )

    monkeypatch.setattr(stable_auto_train, "capture", lambda argv: json.dumps(runs))

    stable_auto_train.wait_for_push_ci(head_sha)


def test_wait_for_push_ci_dispatches_missing_path_filtered_workflow(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    head_sha = "abc123"
    base_runs = [
        {
            "conclusion": "success",
            "databaseId": index,
            "event": "push",
            "headSha": head_sha,
            "name": name,
            "status": "completed",
            "url": f"https://example.test/{name}",
        }
        for index, name in enumerate(stable_auto_train.PUSH_CI_WORKFLOWS, start=1)
        if name != "sdk-typescript"
    ]
    manual_run = {
        "conclusion": "success",
        "databaseId": 999,
        "event": "workflow_dispatch",
        "headSha": head_sha,
        "name": "sdk-typescript",
        "status": "completed",
        "url": "https://example.test/sdk-typescript",
    }
    calls = {"capture": 0}
    dispatched: list[list[str]] = []

    def fake_capture(argv: list[str]) -> str:
        calls["capture"] += 1
        return json.dumps(base_runs if calls["capture"] <= 2 else [*base_runs, manual_run])

    def fake_run(argv: list[str]) -> None:
        dispatched.append(argv)

    monkeypatch.setattr(stable_auto_train, "capture", fake_capture)
    monkeypatch.setattr(stable_auto_train.time, "sleep", lambda seconds: None)
    monkeypatch.setattr(stable_auto_train.time, "monotonic", iter([0.0, 1.0, 2.0, 63.0, 64.0, 65.0]).__next__)
    monkeypatch.setattr(stable_auto_train, "run", fake_run)

    stable_auto_train.wait_for_push_ci(head_sha)

    assert dispatched == [["gh", "workflow", "run", "sdk-typescript.yml", "--ref", "main"]]


def test_release_cd_dispatch_args_omits_audit_inputs_by_default(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("ATTESTPLANE_RELEASE_AUDIT_VERIFIED", raising=False)
    monkeypatch.delenv("ATTESTPLANE_RELEASE_AUDIT_PLAN_URL", raising=False)
    version = stable_auto_train.StableVersion.parse("0.9.10")

    argv = stable_auto_train.release_cd_dispatch_args(version)

    assert "audit_verified=true" not in argv
    assert all(not item.startswith("audit_plan_url=") for item in argv)
    assert argv[-2:] == ["--ref", "main"]


def test_release_cd_dispatch_args_forwards_verified_audit_inputs(monkeypatch: pytest.MonkeyPatch) -> None:
    audit_plan_url = (
        "https://github.com/attestplane/attestplane/blob/main/"
        "docs/validation/v1_0_0_release_audit_plan_20260520.md"
    )
    monkeypatch.setenv("ATTESTPLANE_RELEASE_AUDIT_VERIFIED", "1")
    monkeypatch.setenv("ATTESTPLANE_RELEASE_AUDIT_PLAN_URL", audit_plan_url)
    version = stable_auto_train.StableVersion.parse("1.0.0")

    argv = stable_auto_train.release_cd_dispatch_args(version)

    assert "audit_verified=true" in argv
    assert f"audit_plan_url={audit_plan_url}" in argv
    assert argv[-2:] == ["--ref", "main"]


def test_write_release_notes_uses_subjects_without_commit_hashes(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    (tmp_path / "docs/release-notes").mkdir(parents=True)
    monkeypatch.setattr(stable_auto_train, "ROOT", tmp_path)
    monkeypatch.setattr(
        stable_auto_train,
        "capture",
        lambda argv: "fix(release): wait for push CI before publishing stable train\n"
        "docs(release): approve v1.0.0 audit gate",
    )

    stable_auto_train.write_release_notes(
        stable_auto_train.StableVersion.parse("0.9.10"),
        stable_auto_train.StableVersion.parse("1.0.0"),
    )

    notes = (tmp_path / "docs/release-notes/v1.0.0.draft.md").read_text(encoding="utf-8")
    assert "abc1234" not in notes
    assert "- fix(release): wait for push CI before publishing stable train" in notes


def test_trigger_sign_release_returns_true_on_success(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[list[str]] = []

    monkeypatch.setattr(stable_auto_train, "run", lambda argv, **kwargs: calls.append(argv))
    monkeypatch.setattr(
        stable_auto_train,
        "capture",
        lambda argv: (
            "["
            '{"databaseId":11111,"headBranch":"main","createdAt":"2026-05-21T07:50:00Z"},'
            '{"databaseId":12345,"headBranch":"main","createdAt":"2026-05-21T08:00:01Z"}'
            "]"
        ),
    )
    monkeypatch.setattr(stable_auto_train, "utc_now_iso", lambda: "2026-05-21T08:00:00Z")
    monkeypatch.setattr(stable_auto_train.time, "monotonic", iter([0.0, 1.0, 2.0]).__next__)
    monkeypatch.setattr(stable_auto_train.time, "sleep", lambda seconds: None)

    assert stable_auto_train.trigger_sign_release("v1.3.9") is True
    dispatch = calls[0]
    assert dispatch[:5] == ["gh", "workflow", "run", "sign-release.yml", "--ref"]
    assert "tag=v1.3.9" in dispatch
    assert "execute=true" in dispatch
    assert calls[-1] == ["gh", "run", "watch", "12345", "--exit-status"]


def test_trigger_sign_release_returns_false_on_workflow_failure(monkeypatch: pytest.MonkeyPatch) -> None:
    def fake_run(argv: list[str], **kwargs: object) -> None:
        if argv[:3] == ["gh", "run", "watch"]:
            raise subprocess.CalledProcessError(1, argv)

    monkeypatch.setattr(stable_auto_train, "run", fake_run)
    monkeypatch.setattr(
        stable_auto_train,
        "capture",
        lambda argv: '[{"databaseId":99999,"headBranch":"main","createdAt":"2026-05-21T08:00:01Z"}]',
    )
    monkeypatch.setattr(stable_auto_train, "utc_now_iso", lambda: "2026-05-21T08:00:00Z")
    monkeypatch.setattr(stable_auto_train.time, "monotonic", iter([0.0, 1.0]).__next__)
    monkeypatch.setattr(stable_auto_train.time, "sleep", lambda seconds: None)

    assert stable_auto_train.trigger_sign_release("v1.3.9") is False


def test_trigger_slsa_provenance_returns_true_on_success(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[list[str]] = []

    monkeypatch.setattr(stable_auto_train, "run", lambda argv, **kwargs: calls.append(argv))
    monkeypatch.setattr(
        stable_auto_train,
        "capture",
        lambda argv: '[{"databaseId":67890,"headBranch":"main","createdAt":"2026-05-21T08:00:01Z"}]',
    )
    monkeypatch.setattr(stable_auto_train, "utc_now_iso", lambda: "2026-05-21T08:00:00Z")
    monkeypatch.setattr(stable_auto_train.time, "monotonic", iter([0.0, 1.0, 2.0]).__next__)
    monkeypatch.setattr(stable_auto_train.time, "sleep", lambda seconds: None)

    assert stable_auto_train.trigger_slsa_provenance("v1.3.9") is True
    dispatch = calls[0]
    assert dispatch[:5] == ["gh", "workflow", "run", "slsa-provenance.yml", "--ref"]
    assert "tag=v1.3.9" in dispatch
    assert "execute=true" in dispatch
    assert calls[-1] == ["gh", "run", "watch", "67890", "--exit-status"]


def test_trigger_slsa_provenance_returns_false_on_timeout(monkeypatch: pytest.MonkeyPatch) -> None:
    def fake_run(argv: list[str], **kwargs: object) -> None:
        return None

    def fake_capture(argv: list[str]) -> str:
        raise subprocess.CalledProcessError(1, argv)

    # First call deadline = 0 + 600 = 600; advance the clock past 600 quickly.
    clock = iter([0.0, 700.0, 800.0, 900.0])

    monkeypatch.setattr(stable_auto_train, "run", fake_run)
    monkeypatch.setattr(stable_auto_train, "capture", fake_capture)
    monkeypatch.setattr(stable_auto_train.time, "monotonic", lambda: next(clock))
    monkeypatch.setattr(stable_auto_train.time, "sleep", lambda seconds: None)

    assert stable_auto_train.trigger_slsa_provenance("v1.3.9") is False


def test_cadence_limiter_skips_when_only_release_prep_commits(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    subjects = (
        "chore(release): prepare v1.4.0\n"
        "chore(release): prepare v1.3.10\n"
        "chore(release): prepare v1.3.9"
    )

    monkeypatch.setattr(stable_auto_train, "capture", lambda argv, *, timeout=None: subjects)

    assert stable_auto_train.commits_since_tag_have_real_work("v1.3.8") is False


def test_cadence_limiter_proceeds_when_real_feat_present(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    subjects = (
        "chore(release): prepare v1.4.0\n"
        "feat(release): autorelease cadence limiter — skip cycles with only release-prep commits\n"
        "chore(release): prepare v1.3.10"
    )

    monkeypatch.setattr(stable_auto_train, "capture", lambda argv, *, timeout=None: subjects)

    assert stable_auto_train.commits_since_tag_have_real_work("v1.3.8") is True


def test_cadence_limiter_proceeds_when_real_fix_present(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    subjects = (
        "chore(release): prepare v1.4.0\n"
        "fix(release): wait for push CI before publishing stable train\n"
        "chore(release): prepare v1.3.10"
    )

    monkeypatch.setattr(stable_auto_train, "capture", lambda argv, *, timeout=None: subjects)

    assert stable_auto_train.commits_since_tag_have_real_work("v1.3.8") is True


def test_cadence_limiter_returns_false_on_empty_range(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(stable_auto_train, "capture", lambda argv, *, timeout=None: "")

    assert stable_auto_train.commits_since_tag_have_real_work("v1.3.8") is False


def test_cadence_limiter_returns_true_conservatively_on_missing_tag(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def fake_capture(argv: list[str], *, timeout: int | None = None) -> str:
        raise subprocess.CalledProcessError(128, argv, output="", stderr="unknown revision")

    monkeypatch.setattr(stable_auto_train, "capture", fake_capture)

    assert stable_auto_train.commits_since_tag_have_real_work("v999.999.999") is True


def test_cadence_limiter_handles_force_env_var(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    queue = tmp_path / "queue.json"
    queue.write_text(
        json.dumps(
            {
                "schema": "attestplane_autodev_train_targets.v2",
                "targets": [
                    {"version": "1.4.1", "status": "queued", "channel": "latest", "min_soak_hours": 0},
                ],
            }
        ),
        encoding="utf-8",
    )
    version = stable_auto_train.StableVersion.parse("1.4.1")
    previous = stable_auto_train.StableVersion.parse("1.4.0")
    calls: list[str] = []

    monkeypatch.setenv(stable_auto_train.FORCE_CADENCE_ENV, "1")
    monkeypatch.setattr(stable_auto_train, "assert_clean_tree", lambda: None)
    monkeypatch.setattr(stable_auto_train, "assert_on_main", lambda: None)
    monkeypatch.setattr(stable_auto_train, "best_effort_fetch_tags", lambda: None)
    monkeypatch.setattr(stable_auto_train, "sync_main_with_origin", lambda: None)
    monkeypatch.setattr(stable_auto_train, "latest_stable", lambda: previous)
    monkeypatch.setattr(stable_auto_train, "latest_stable_before", lambda target: previous)
    monkeypatch.setattr(stable_auto_train, "assert_release_gate_allows_target", lambda target: None)
    monkeypatch.setattr(stable_auto_train, "git_ref_exists", lambda ref: False)
    monkeypatch.setattr(stable_auto_train, "remote_tag_exists", lambda tag: False)
    monkeypatch.setattr(
        stable_auto_train,
        "publication_status",
        lambda target: stable_auto_train.PublicationStatus(
            python_visible=True, npm_visible=True, npm_latest=True, github_release=True
        ),
    )
    # If the cadence limiter were applied (it should NOT be, under force env),
    # the cycle would short-circuit. We sentinel by asserting the dry-run path
    # actually runs (returns the new tag, not the previous tag).
    def fake_commits_since(tag: str) -> bool:
        calls.append(f"cadence_called_for_{tag}")
        return False

    monkeypatch.setattr(stable_auto_train, "commits_since_tag_have_real_work", fake_commits_since)

    result = stable_auto_train.run_once(publish=False, wait=False, target_queue=queue, dry_run=True)

    assert result == version.tag
    assert calls == []
