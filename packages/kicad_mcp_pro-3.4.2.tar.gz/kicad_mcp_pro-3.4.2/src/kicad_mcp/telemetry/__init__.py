"""Telemetry event helpers."""
