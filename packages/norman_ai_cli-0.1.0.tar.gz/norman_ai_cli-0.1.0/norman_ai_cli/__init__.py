"""Norman AI CLI — Agentic accounting & taxes from the terminal."""

__version__ = "0.1.0"
