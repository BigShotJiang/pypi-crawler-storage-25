"""Category commands (SKR chart of accounts for SME)."""

from typing import Optional

import typer

from norman_ai_cli.client import get_api_client
from norman_ai_cli.output import get_formatter, TableConfig
from norman_ai_cli.utils import handle_errors, dry_run_guard

app = typer.Typer(name="categories", help="Transaction categories (SKR for SME)")


@app.command()
@handle_errors
def search(
    code: str = typer.Argument(..., help="SKR account code to search"),
) -> None:
    """Search SKR categories by account code."""
    client = get_api_client()
    result = client.get(
        f"api/v1/companies/{client.company_id}/accounting/categories/skr-search/",
        code=code,
    )
    get_formatter().output(result, TableConfig(
        columns=[("code", "Code"), ("name", "Name"), ("cashflowType", "Type")],
        title=f"SKR Results for '{code}'",
    ))


@app.command()
@handle_errors
def suggest(
    query: str = typer.Argument(..., help="Description to get category suggestions"),
) -> None:
    """Get AI-powered category suggestion."""
    client = get_api_client()
    result = client.post(
        f"api/v1/companies/{client.company_id}/accounting/categories/suggest/",
        {"query": query},
    )
    get_formatter().output(result)


@app.command()
@handle_errors
def create(
    code: str = typer.Option(..., help="Account code"),
    name: str = typer.Option(..., help="Category name"),
    cashflow_type: str = typer.Option(..., "--type", help="INCOME or EXPENSE"),
    name_de: Optional[str] = typer.Option(None, "--name-de", help="German name"),
    description: Optional[str] = typer.Option(None, "-d", help="Description"),
) -> None:
    """Create a custom company category."""
    from norman_ai_cli.app import state
    data = {"code": code, "name": name, "cashflowType": cashflow_type}
    if name_de: data["nameDe"] = name_de
    if description: data["description"] = description

    if dry_run_guard(state.dry_run, "POST", "company-categories/", data):
        return

    client = get_api_client()
    result = client.post(
        f"api/v1/companies/{client.company_id}/accounting/company-categories/", data
    )
    get_formatter().output(result)
