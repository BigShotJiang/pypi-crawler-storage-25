"""Invoice commands."""

from typing import Optional

import typer

from norman_ai_cli.client import get_api_client
from norman_ai_cli.output import get_formatter, TableConfig
from norman_ai_cli.utils import handle_errors, dry_run_guard

app = typer.Typer(name="invoices", help="Invoice management")

INV_TABLE = TableConfig(
    columns=[
        ("publicId", "ID"),
        ("invoiceNumber", "Number"),
        ("client", "Client"),
        ("totalAmount", "Amount"),
        ("status", "Status"),
        ("issued", "Issued"),
        ("dueTo", "Due"),
    ],
    wide_columns=[("currency", "Currency"), ("invoiceType", "Type")],
    title="Invoices",
)


@app.command("list")
@handle_errors
def list_invoices(
    status: Optional[str] = typer.Option(None, "--status", help="DRAFT, SENT, PAID, OVERDUE"),
    name: Optional[str] = typer.Option(None, "--name", help="Search by client name"),
    from_date: Optional[str] = typer.Option(None, "--from", help="From date (YYYY-MM-DD)"),
    to_date: Optional[str] = typer.Option(None, "--to", help="To date (YYYY-MM-DD)"),
    limit: int = typer.Option(100, "--limit", help="Max results"),
) -> None:
    """List invoices."""
    client = get_api_client()
    params = {"limit": limit}
    if status: params["status"] = status
    if name: params["name"] = name
    if from_date: params["dateFrom"] = from_date
    if to_date: params["dateTo"] = to_date

    result = client.get(f"api/v1/companies/{client.company_id}/invoices/", **params)
    get_formatter().output(result, INV_TABLE)


@app.command("get")
@handle_errors
def get_invoice(
    invoice_id: str = typer.Argument(..., help="Invoice ID"),
) -> None:
    """Get invoice details."""
    client = get_api_client()
    result = client.get(f"api/v1/companies/{client.company_id}/invoices/{invoice_id}/")
    get_formatter().output(result)


@app.command()
@handle_errors
def create(
    client_id: str = typer.Option(..., "--client", help="Client ID"),
    amount: float = typer.Option(..., help="Item amount"),
    description: str = typer.Option(..., "-d", help="Item description"),
    quantity: int = typer.Option(1, "--qty", help="Item quantity"),
    vat_rate: int = typer.Option(19, "--vat", help="VAT rate (0, 7, 19)"),
    currency: str = typer.Option("EUR", help="Currency"),
    invoice_type: str = typer.Option("SERVICES", "--type", help="SERVICES or GOODS"),
    notes: Optional[str] = typer.Option(None, help="Invoice notes"),
    send: bool = typer.Option(False, "--send", help="Send invoice via email after creation"),
) -> None:
    """Create a new invoice."""
    from norman_ai_cli.app import state
    data = {
        "clientId": client_id,
        "currency": currency,
        "invoiceType": invoice_type,
        "items": [
            {
                "description": description,
                "quantity": quantity,
                "unitPrice": amount,
                "vatRate": vat_rate,
            }
        ],
    }
    if notes: data["notes"] = notes
    if send: data["isToSend"] = True

    if dry_run_guard(state.dry_run, "POST", "invoices/", data):
        return

    api = get_api_client()
    result = api.post(f"api/v1/companies/{api.company_id}/invoices/", data)
    get_formatter().output(result)


@app.command("create-recurring")
@handle_errors
def create_recurring(
    client_id: str = typer.Option(..., "--client", help="Client ID"),
    amount: float = typer.Option(..., help="Item amount"),
    description: str = typer.Option(..., "-d", help="Item description"),
    frequency: str = typer.Option("MONTHLY", "--freq", help="WEEKLY, MONTHLY, QUARTERLY, YEARLY"),
    starts: str = typer.Option(..., "--starts", help="Start date (YYYY-MM-DD)"),
    currency: str = typer.Option("EUR", help="Currency"),
) -> None:
    """Create a recurring invoice."""
    from norman_ai_cli.app import state
    data = {
        "clientId": client_id,
        "currency": currency,
        "frequencyType": frequency,
        "frequencyUnit": 1,
        "startsFromDate": starts,
        "items": [{"description": description, "quantity": 1, "unitPrice": amount, "vatRate": 19}],
    }

    if dry_run_guard(state.dry_run, "POST", "recurring-invoices/", data):
        return

    api = get_api_client()
    result = api.post(f"api/v1/companies/{api.company_id}/invoices/recurring/", data)
    get_formatter().output(result)


@app.command()
@handle_errors
def send(
    invoice_id: str = typer.Argument(..., help="Invoice ID"),
    subject: str = typer.Option(..., help="Email subject"),
    body: str = typer.Option(..., help="Email body"),
    email: Optional[str] = typer.Option(None, "--email", help="Override recipient email"),
) -> None:
    """Send an invoice via email."""
    from norman_ai_cli.app import state
    data = {"subject": subject, "body": body}
    if email: data["customClientEmail"] = email

    if dry_run_guard(state.dry_run, "POST", f"invoices/{invoice_id}/send/", data):
        return

    api = get_api_client()
    result = api.post(f"api/v1/companies/{api.company_id}/invoices/{invoice_id}/send/", data)
    get_formatter().success("Invoice sent.")


@app.command()
@handle_errors
def remind(
    invoice_id: str = typer.Argument(..., help="Invoice ID"),
    subject: str = typer.Option(..., help="Email subject"),
    body: str = typer.Option(..., help="Email body"),
) -> None:
    """Send an overdue payment reminder."""
    from norman_ai_cli.app import state
    if dry_run_guard(state.dry_run, "POST", f"invoices/{invoice_id}/remind/", None):
        return

    api = get_api_client()
    result = api.post(
        f"api/v1/companies/{api.company_id}/invoices/{invoice_id}/send-overdue-reminder/",
        {"subject": subject, "body": body},
    )
    get_formatter().success("Reminder sent.")


@app.command()
@handle_errors
def link(
    invoice_id: str = typer.Argument(..., help="Invoice ID"),
    transaction_id: str = typer.Argument(..., help="Transaction ID"),
) -> None:
    """Link a transaction to an invoice."""
    api = get_api_client()
    result = api.post(
        f"api/v1/companies/{api.company_id}/invoices/{invoice_id}/link-transaction/",
        {"transactionId": transaction_id},
    )
    get_formatter().success("Transaction linked to invoice.")


@app.command()
@handle_errors
def xml(
    invoice_id: str = typer.Argument(..., help="Invoice ID"),
) -> None:
    """Get e-invoice XML (ZUGFeRD/XRechnung)."""
    api = get_api_client()
    result = api.get(f"api/v1/companies/{api.company_id}/invoices/{invoice_id}/e-invoice-xml/")
    get_formatter().output(result)
