"""Client management commands."""

from typing import Optional

import typer

from norman_ai_cli.client import get_api_client
from norman_ai_cli.output import get_formatter, TableConfig
from norman_ai_cli.utils import handle_errors, confirm_action, dry_run_guard

app = typer.Typer(name="clients", help="Client (customer) management")

CLIENT_TABLE = TableConfig(
    columns=[
        ("publicId", "ID"),
        ("name", "Name"),
        ("clientType", "Type"),
        ("email", "Email"),
        ("country", "Country"),
    ],
    wide_columns=[("vatNumber", "VAT"), ("phone", "Phone"), ("city", "City")],
    title="Clients",
)


@app.command("list")
@handle_errors
def list_clients() -> None:
    """List all clients."""
    client = get_api_client()
    result = client.get(f"api/v1/companies/{client.company_id}/crm/clients/")
    get_formatter().output(result, CLIENT_TABLE)


@app.command("get")
@handle_errors
def get_client(
    client_id: str = typer.Argument(..., help="Client ID"),
) -> None:
    """Get client details."""
    api = get_api_client()
    result = api.get(f"api/v1/companies/{api.company_id}/crm/clients/{client_id}/")
    get_formatter().output(result)


@app.command()
@handle_errors
def create(
    name: str = typer.Option(..., help="Client name"),
    client_type: str = typer.Option("business", "--type", help="business or person"),
    email: Optional[str] = typer.Option(None, help="Email"),
    country: Optional[str] = typer.Option(None, help="Country code (DE, PL, etc.)"),
    address: Optional[str] = typer.Option(None, help="Street address"),
    city: Optional[str] = typer.Option(None, help="City"),
    zip_code: Optional[str] = typer.Option(None, "--zip", help="ZIP code"),
    vat_number: Optional[str] = typer.Option(None, "--vat", help="VAT number"),
    phone: Optional[str] = typer.Option(None, help="Phone number"),
) -> None:
    """Create a new client."""
    from norman_ai_cli.app import state
    data = {"name": name, "clientType": client_type}
    if email: data["email"] = email
    if country: data["country"] = country
    if address: data["address"] = address
    if city: data["city"] = city
    if zip_code: data["zipCode"] = zip_code
    if vat_number: data["vatNumber"] = vat_number
    if phone: data["phone"] = phone

    if dry_run_guard(state.dry_run, "POST", "clients/", data):
        return

    api = get_api_client()
    result = api.post(f"api/v1/companies/{api.company_id}/crm/clients/", data)
    get_formatter().output(result)


@app.command()
@handle_errors
def update(
    client_id: str = typer.Argument(..., help="Client ID"),
    name: Optional[str] = typer.Option(None, help="Client name"),
    email: Optional[str] = typer.Option(None, help="Email"),
    country: Optional[str] = typer.Option(None, help="Country code"),
    address: Optional[str] = typer.Option(None, help="Street address"),
    city: Optional[str] = typer.Option(None, help="City"),
    zip_code: Optional[str] = typer.Option(None, "--zip", help="ZIP code"),
    vat_number: Optional[str] = typer.Option(None, "--vat", help="VAT number"),
    phone: Optional[str] = typer.Option(None, help="Phone number"),
) -> None:
    """Update a client."""
    from norman_ai_cli.app import state
    data = {}
    if name: data["name"] = name
    if email: data["email"] = email
    if country: data["country"] = country
    if address: data["address"] = address
    if city: data["city"] = city
    if zip_code: data["zipCode"] = zip_code
    if vat_number: data["vatNumber"] = vat_number
    if phone: data["phone"] = phone

    if not data:
        get_formatter().error({"error": "No fields to update."})
        return
    if dry_run_guard(state.dry_run, "PATCH", f"clients/{client_id}", data):
        return

    api = get_api_client()
    result = api.patch(f"api/v1/companies/{api.company_id}/crm/clients/{client_id}/", data)
    get_formatter().output(result)


@app.command()
@handle_errors
def delete(
    client_id: str = typer.Argument(..., help="Client ID"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
) -> None:
    """Delete a client."""
    from norman_ai_cli.app import state
    confirm_action(f"Delete client {client_id}?", no_input=state.no_input or yes)

    api = get_api_client()
    result = api.delete(f"api/v1/companies/{api.company_id}/crm/clients/{client_id}/")
    get_formatter().success(f"Client {client_id} deleted.")
