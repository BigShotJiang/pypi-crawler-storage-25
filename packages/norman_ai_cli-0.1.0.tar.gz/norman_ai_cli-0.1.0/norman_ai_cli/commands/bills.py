"""Bill and payment commands."""

from typing import Optional

import typer

from norman_ai_cli.client import get_api_client
from norman_ai_cli.output import get_formatter, TableConfig
from norman_ai_cli.utils import handle_errors, confirm_action, dry_run_guard

app = typer.Typer(name="bills", help="Bills and payments")

BILL_TABLE = TableConfig(
    columns=[
        ("publicId", "ID"),
        ("vendorName", "Vendor"),
        ("amount", "Amount"),
        ("status", "Status"),
        ("dueDate", "Due"),
    ],
    wide_columns=[("currency", "Currency"), ("reference", "Reference")],
    title="Bills",
)


@app.command("list")
@handle_errors
def list_bills(
    status: Optional[str] = typer.Option(None, "--status", help="DRAFT, PENDING, PAID, OVERDUE, etc."),
    limit: int = typer.Option(100, "--limit"),
) -> None:
    """List bills/payables."""
    client = get_api_client()
    params = {"limit": limit}
    if status: params["status"] = status
    result = client.get(f"api/v1/companies/{client.company_id}/accounting/bills/", **params)
    get_formatter().output(result, BILL_TABLE)


@app.command()
@handle_errors
def create(
    vendor: str = typer.Option(..., help="Vendor name"),
    amount: float = typer.Option(..., help="Bill amount"),
    currency: str = typer.Option("EUR", help="Currency"),
    status: str = typer.Option("PENDING", "--status", help="Bill status"),
    due_date: Optional[str] = typer.Option(None, "--due", help="Due date (YYYY-MM-DD)"),
    vendor_iban: Optional[str] = typer.Option(None, "--iban", help="Vendor IBAN"),
    reference: Optional[str] = typer.Option(None, "--ref", help="Reference number"),
    description: Optional[str] = typer.Option(None, "-d", help="Description"),
) -> None:
    """Create a new bill."""
    from norman_ai_cli.app import state
    data = {"vendorName": vendor, "amount": amount, "currency": currency, "status": status}
    if due_date: data["dueDate"] = due_date
    if vendor_iban: data["vendorIban"] = vendor_iban
    if reference: data["reference"] = reference
    if description: data["description"] = description

    if dry_run_guard(state.dry_run, "POST", "bills/", data):
        return

    client = get_api_client()
    result = client.post(f"api/v1/companies/{client.company_id}/accounting/bills/", data)
    get_formatter().output(result)


@app.command()
@handle_errors
def scan(
    attachment_id: str = typer.Argument(..., help="Attachment ID to scan"),
) -> None:
    """Scan a bill document to extract payment details."""
    client = get_api_client()
    result = client.post(
        f"api/v1/companies/{client.company_id}/accounting/bills/scan/",
        {"attachmentId": attachment_id},
    )
    get_formatter().output(result)


@app.command()
@handle_errors
def pay(
    bill_id: str = typer.Argument(..., help="Bill ID"),
    account_id: str = typer.Option(..., "--account", help="Bank account ID"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
) -> None:
    """Initiate a SEPA payment for a bill."""
    from norman_ai_cli.app import state
    confirm_action(f"Pay bill {bill_id}?", no_input=state.no_input or yes)

    if dry_run_guard(state.dry_run, "POST", f"bills/{bill_id}/pay/", {"accountId": account_id}):
        return

    client = get_api_client()
    result = client.post(
        f"api/v1/companies/{client.company_id}/accounting/bills/{bill_id}/pay/",
        {"accountId": account_id},
    )
    get_formatter().output(result)


@app.command()
@handle_errors
def accounts() -> None:
    """List bank accounts available for payment."""
    client = get_api_client()
    result = client.get(f"api/v1/companies/{client.company_id}/accounting/bank-accounts/")
    get_formatter().output(result, TableConfig(
        columns=[("publicId", "ID"), ("accountName", "Name"), ("iban", "IBAN"), ("balance", "Balance")],
        title="Payment Accounts",
    ))


@app.command()
@handle_errors
def payments(
    status: Optional[str] = typer.Option(None, "--status", help="CREATED, PENDING_AUTH, COMPLETED, FAILED"),
    limit: int = typer.Option(50, "--limit"),
) -> None:
    """List payment orders."""
    client = get_api_client()
    params = {"limit": limit}
    if status: params["status"] = status
    result = client.get(f"api/v1/companies/{client.company_id}/accounting/payment-orders/", **params)
    get_formatter().output(result, TableConfig(
        columns=[("publicId", "ID"), ("status", "Status"), ("amount", "Amount"), ("createdAt", "Created")],
        title="Payment Orders",
    ))


@app.command()
@handle_errors
def payment(
    payment_id: str = typer.Argument(..., help="Payment order ID"),
) -> None:
    """Get payment order status."""
    client = get_api_client()
    result = client.get(
        f"api/v1/companies/{client.company_id}/accounting/payment-orders/{payment_id}/"
    )
    get_formatter().output(result)
