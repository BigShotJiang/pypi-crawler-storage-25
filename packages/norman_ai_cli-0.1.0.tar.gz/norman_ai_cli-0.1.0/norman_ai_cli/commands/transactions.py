"""Transaction commands."""

from typing import Optional

import typer

from norman_ai_cli.client import get_api_client
from norman_ai_cli.output import get_formatter, TableConfig
from norman_ai_cli.utils import handle_errors, dry_run_guard

app = typer.Typer(name="transactions", help="Transaction management")

TX_TABLE = TableConfig(
    columns=[
        ("publicId", "ID"),
        ("description", "Description"),
        ("amount", "Amount"),
        ("cashflowType", "Type"),
        ("date", "Date"),
        ("status", "Status"),
    ],
    wide_columns=[
        ("category", "Category"),
        ("vatRate", "VAT"),
        ("currency", "Currency"),
        ("supplierCountry", "Country"),
    ],
    title="Transactions",
)


@app.command("list")
@handle_errors
def list_transactions(
    description: Optional[str] = typer.Option(None, "-d", "--description", help="Search description"),
    from_date: Optional[str] = typer.Option(None, "--from", help="Start date (YYYY-MM-DD)"),
    to_date: Optional[str] = typer.Option(None, "--to", help="End date (YYYY-MM-DD)"),
    min_amount: Optional[float] = typer.Option(None, "--min", help="Minimum amount"),
    max_amount: Optional[float] = typer.Option(None, "--max", help="Maximum amount"),
    category: Optional[str] = typer.Option(None, "--category", help="Category name"),
    status: Optional[str] = typer.Option(None, "--status", help="UNVERIFIED or VERIFIED"),
    cashflow_type: Optional[str] = typer.Option(None, "--type", help="INCOME or EXPENSE"),
    limit: int = typer.Option(100, "--limit", help="Max results"),
) -> None:
    """List transactions with optional filters."""
    client = get_api_client()
    params = {"limit": limit}
    if description: params["description"] = description
    if from_date: params["dateFrom"] = from_date
    if to_date: params["dateTo"] = to_date
    if min_amount: params["minAmount"] = min_amount
    if max_amount: params["maxAmount"] = max_amount
    if category: params["categoryName"] = category
    if status: params["status"] = status
    if cashflow_type: params["cashflowType"] = cashflow_type

    result = client.get(f"api/v1/companies/{client.company_id}/accounting/transactions/", **params)
    get_formatter().output(result, TX_TABLE)


@app.command("get")
@handle_errors
def get_transaction(
    transaction_id: str = typer.Argument(..., help="Transaction ID"),
) -> None:
    """Get transaction details."""
    client = get_api_client()
    result = client.get(f"api/v1/companies/{client.company_id}/accounting/transactions/{transaction_id}/")
    get_formatter().output(result)


@app.command()
@handle_errors
def create(
    amount: float = typer.Option(..., help="Transaction amount"),
    description: str = typer.Option(..., "-d", help="Description"),
    cashflow_type: str = typer.Option(..., "--type", help="INCOME or EXPENSE"),
    supplier_country: str = typer.Option("DE", "--country", help="Supplier country code"),
    vat_rate: Optional[int] = typer.Option(None, "--vat", help="VAT rate (0, 7, 19)"),
    category_id: Optional[str] = typer.Option(None, "--category-id", help="Category ID"),
    currency: str = typer.Option("EUR", help="Currency code"),
    date: Optional[str] = typer.Option(None, help="Date (YYYY-MM-DD)"),
) -> None:
    """Create a manual transaction."""
    from norman_ai_cli.app import state
    data = {
        "amount": amount,
        "description": description,
        "cashflowType": cashflow_type,
        "supplierCountry": supplier_country,
        "currency": currency,
    }
    if vat_rate is not None: data["vatRate"] = vat_rate
    if category_id: data["categoryId"] = category_id
    if date: data["date"] = date

    if dry_run_guard(state.dry_run, "POST", "transactions/", data):
        return

    client = get_api_client()
    result = client.post(f"api/v1/companies/{client.company_id}/accounting/transactions/", data)
    get_formatter().output(result)


@app.command()
@handle_errors
def update(
    transaction_id: str = typer.Argument(..., help="Transaction ID"),
    amount: Optional[float] = typer.Option(None, help="Amount"),
    description: Optional[str] = typer.Option(None, "-d", help="Description"),
    vat_rate: Optional[int] = typer.Option(None, "--vat", help="VAT rate"),
    category_id: Optional[str] = typer.Option(None, "--category-id", help="Category ID"),
    date: Optional[str] = typer.Option(None, help="Date (YYYY-MM-DD)"),
) -> None:
    """Update a transaction."""
    from norman_ai_cli.app import state
    data = {}
    if amount is not None: data["amount"] = amount
    if description: data["description"] = description
    if vat_rate is not None: data["vatRate"] = vat_rate
    if category_id: data["categoryId"] = category_id
    if date: data["date"] = date

    if not data:
        get_formatter().error({"error": "No fields to update."})
        return
    if dry_run_guard(state.dry_run, "PATCH", f"transactions/{transaction_id}", data):
        return

    client = get_api_client()
    result = client.patch(
        f"api/v1/companies/{client.company_id}/accounting/transactions/{transaction_id}/", data
    )
    get_formatter().output(result)


@app.command()
@handle_errors
def categorize(
    amount: float = typer.Option(..., help="Transaction amount"),
    description: str = typer.Option(..., "-d", help="Description"),
    tx_type: str = typer.Option(..., "--type", help="INCOME or EXPENSE"),
) -> None:
    """Get AI category suggestion for a transaction."""
    client = get_api_client()
    result = client.post(
        f"api/v1/companies/{client.company_id}/assistant/detect-category/",
        {"amount": amount, "description": description, "type": tx_type},
    )
    get_formatter().output(result)


@app.command()
@handle_errors
def verify(
    transaction_id: str = typer.Argument(..., help="Transaction ID"),
    unverify: bool = typer.Option(False, "--unverify", help="Unverify instead of verify"),
) -> None:
    """Verify (finalize) or unverify a transaction."""
    from norman_ai_cli.app import state
    action = "unverify" if unverify else "verify"
    if dry_run_guard(state.dry_run, "POST", f"transactions/{transaction_id}/{action}", None):
        return

    client = get_api_client()
    result = client.post(
        f"api/v1/companies/{client.company_id}/accounting/transactions/{transaction_id}/{action}/",
    )
    get_formatter().output(result)
