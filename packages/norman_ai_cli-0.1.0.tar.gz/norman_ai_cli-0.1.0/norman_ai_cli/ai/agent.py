"""AI Agent — launches MCP server subprocess and runs OpenAI Agent against it."""

import logging
import os
import sys

from agents import Agent, Runner, ModelSettings
from agents.mcp import MCPServerStdio

from norman_ai_cli.ai.prompts import build_system_prompt
from norman_ai_cli.ai.streaming import stream_to_terminal
from norman_ai_cli.config import get_token, get_company_id, get_environment, load_config
from norman_ai_cli.client import get_api_client

logger = logging.getLogger(__name__)


def _get_mcp_command() -> list[str]:
    """Get the command to launch the MCP server as stdio subprocess."""
    return [
        sys.executable, "-m", "norman_mcp",
        "--transport", "stdio",
        "--environment", get_environment(),
    ]


def _get_mcp_env() -> dict[str, str]:
    """Build environment for the MCP subprocess."""
    env = os.environ.copy()
    token = get_token()
    company_id = get_company_id()
    if token:
        env["NORMAN_USER_TOKEN"] = token
    if company_id:
        env["NORMAN_COMPANY_ID"] = company_id
    return env


def _fetch_company_info() -> dict | None:
    """Fetch company details for prompt context."""
    try:
        client = get_api_client()
        result = client.get(f"api/v1/companies/{client.company_id}/")
        if "error" not in result:
            return result
    except Exception:
        pass
    return None


async def run_one_shot(prompt: str, model: str = "gpt-4.1") -> None:
    """Run a one-shot AI agent query and stream the response."""
    company_info = _fetch_company_info()
    instructions = build_system_prompt(company_info)

    mcp_cmd = _get_mcp_command()
    mcp_env = _get_mcp_env()

    # Add user token to command args
    token = get_token()
    if token:
        mcp_cmd.extend(["--user-token", token])
    company_id = get_company_id()
    if company_id:
        mcp_cmd.extend(["--company-id", company_id])

    async with MCPServerStdio(
        name="Norman MCP",
        cache_tools_list=True,
        client_session_timeout_seconds=60,
        params={
            "command": mcp_cmd[0],
            "args": mcp_cmd[1:],
            "env": mcp_env,
        },
    ) as mcp_server:
        agent = Agent(
            name="Norman AI",
            instructions=instructions,
            model=model,
            mcp_servers=[mcp_server],
            model_settings=ModelSettings(tool_choice="auto", truncation="auto"),
        )

        result = Runner.run_streamed(agent, input=prompt, max_turns=20)
        await stream_to_terminal(result)


async def run_chat_turn(
    prompt: str,
    history: list[dict],
    model: str = "gpt-4.1",
    mcp_server=None,
    agent=None,
    previous_response_id: str | None = None,
) -> tuple[str, str | None]:
    """Run a single chat turn. Returns (response_text, response_id).

    If mcp_server and agent are provided, reuses them (for chat session).
    """
    # Build messages input
    messages = []
    for msg in history:
        messages.append({"role": msg["role"], "content": msg["content"]})
    messages.append({"role": "user", "content": prompt})

    result = Runner.run_streamed(
        agent,
        input=messages,
        max_turns=20,
        previous_response_id=previous_response_id,
    )

    response_text = await stream_to_terminal(result)
    response_id = getattr(result, "last_response_id", None)

    return response_text, response_id
