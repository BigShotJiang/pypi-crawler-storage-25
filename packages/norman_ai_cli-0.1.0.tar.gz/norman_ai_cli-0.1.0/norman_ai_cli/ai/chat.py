"""Interactive AI chat REPL."""

import json
import sys
import uuid
from datetime import datetime
from pathlib import Path

from agents import Agent, ModelSettings
from agents.mcp import MCPServerStdio
from rich.console import Console
from rich.prompt import Prompt

from norman_ai_cli.ai.agent import _get_mcp_command, _get_mcp_env, _fetch_company_info, run_chat_turn
from norman_ai_cli.ai.prompts import build_system_prompt
from norman_ai_cli.config import THREADS_DIR, get_token, get_company_id

console = Console()


def _save_thread(thread_id: str, history: list[dict], response_id: str | None) -> None:
    """Save chat thread to disk."""
    THREADS_DIR.mkdir(parents=True, exist_ok=True)
    path = THREADS_DIR / f"{thread_id}.json"
    data = {
        "thread_id": thread_id,
        "updated_at": datetime.now().isoformat(),
        "response_id": response_id,
        "messages": history,
    }
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False))


def _load_thread(thread_id: str) -> tuple[list[dict], str | None]:
    """Load chat thread from disk. Returns (history, last_response_id)."""
    path = THREADS_DIR / f"{thread_id}.json"
    if not path.exists():
        return [], None
    try:
        data = json.loads(path.read_text())
        return data.get("messages", []), data.get("response_id")
    except (json.JSONDecodeError, OSError):
        return [], None


async def run_chat(model: str = "gpt-4.1") -> None:
    """Run interactive chat session."""
    console.print("[bold]Norman AI Chat[/bold]")
    console.print("[dim]Type your message. Commands: /clear, /exit, /history[/dim]")
    console.print()

    company_info = _fetch_company_info()
    instructions = build_system_prompt(company_info)

    thread_id = str(uuid.uuid4())[:8]
    history: list[dict] = []
    response_id: str | None = None

    mcp_cmd = _get_mcp_command()
    mcp_env = _get_mcp_env()

    token = get_token()
    if token:
        mcp_cmd.extend(["--user-token", token])
    company_id = get_company_id()
    if company_id:
        mcp_cmd.extend(["--company-id", company_id])

    try:
        async with MCPServerStdio(
            name="Norman MCP",
            cache_tools_list=True,
            client_session_timeout_seconds=120,
            params={
                "command": mcp_cmd[0],
                "args": mcp_cmd[1:],
                "env": mcp_env,
            },
        ) as mcp_server:
            agent = Agent(
                name="Norman AI",
                instructions=instructions,
                model=model,
                mcp_servers=[mcp_server],
                model_settings=ModelSettings(tool_choice="auto", truncation="auto"),
            )

            while True:
                try:
                    user_input = Prompt.ask("\n[bold cyan]you[/bold cyan]")
                except (KeyboardInterrupt, EOFError):
                    console.print("\n[dim]Bye![/dim]")
                    break

                if not user_input.strip():
                    continue

                # Handle slash commands
                cmd = user_input.strip().lower()
                if cmd in ("/exit", "/quit", "/q"):
                    console.print("[dim]Bye![/dim]")
                    break
                elif cmd == "/clear":
                    history.clear()
                    response_id = None
                    thread_id = str(uuid.uuid4())[:8]
                    console.print("[dim]Conversation cleared.[/dim]")
                    continue
                elif cmd == "/history":
                    if not history:
                        console.print("[dim]No history yet.[/dim]")
                    else:
                        for msg in history[-10:]:
                            role = "[cyan]you[/cyan]" if msg["role"] == "user" else "[green]norman[/green]"
                            text = msg["content"][:100]
                            console.print(f"  {role}: {text}...")
                    continue

                # Run agent turn
                console.print()
                try:
                    response_text, response_id = await run_chat_turn(
                        prompt=user_input,
                        history=history,
                        model=model,
                        mcp_server=mcp_server,
                        agent=agent,
                        previous_response_id=response_id,
                    )

                    # Update history
                    history.append({"role": "user", "content": user_input})
                    if response_text:
                        history.append({"role": "assistant", "content": response_text})

                    # Keep history manageable (last 40 messages)
                    if len(history) > 40:
                        history = history[-40:]

                    # Save thread
                    _save_thread(thread_id, history, response_id)

                except Exception as e:
                    console.print(f"[red]Error:[/red] {e}")
                    console.print("[dim]Try again or /clear to reset.[/dim]")

    except KeyboardInterrupt:
        console.print("\n[dim]Bye![/dim]")
