"""Terminal streaming renderer for AI agent responses."""

import sys

from rich.console import Console
from rich.live import Live
from rich.markdown import Markdown
from rich.spinner import Spinner
from rich.text import Text

from agents import RunResultStreaming
from agents.stream_events import AgentUpdatedStreamEvent, RawResponsesStreamEvent, RunItemStreamEvent

console = Console()


async def stream_to_terminal(result: RunResultStreaming) -> str:
    """Stream agent response to terminal with live rendering.

    Returns the accumulated response text.
    """
    accumulated = ""
    current_tool = None

    with Live(console=console, refresh_per_second=15, transient=False) as live:
        async for event in result.stream_events():
            if isinstance(event, RunItemStreamEvent):
                item = event.item

                # Tool call start
                if item.type == "tool_call_item":
                    tool_name = getattr(item, "name", None) or getattr(item, "tool_name", "tool")
                    # Make tool names more friendly
                    friendly = tool_name.replace("_", " ").title()
                    current_tool = friendly
                    live.update(
                        Text.assemble(
                            ("  ", "dim"),
                            Spinner("dots"),
                            (f" {friendly}...", "dim italic"),
                        )
                    )

                # Tool call result
                elif item.type == "tool_call_output_item":
                    current_tool = None

                # Message output
                elif item.type == "message_output_item":
                    for content in getattr(item, "content", []):
                        if hasattr(content, "text"):
                            accumulated = content.text

            elif isinstance(event, RawResponsesStreamEvent):
                # Handle text deltas from the raw stream
                data = event.data
                if hasattr(data, "delta") and hasattr(data.delta, "text"):
                    accumulated += data.delta.text
                    live.update(Markdown(accumulated))

        # Final render
        if accumulated:
            live.update(Markdown(accumulated))

    # Print newline after live display
    if not accumulated:
        console.print("[dim]No response.[/dim]")

    return accumulated
