import json
import re
import os
import pymysql
from elasticsearch import Elasticsearch
from elasticsearch.helpers import bulk
from pymysql.cursors import DictCursor
from typing import Dict, List, Generator, Any
from pypinyin import lazy_pinyin, Style
from datetime import datetime
import random
import string
import requests


# 写入章节或者栏目
class lanmu:
    # 初始化数据
    def __init__(self, user_json):
        self.user_json = user_json
        self.connection = pymysql.connect(host=user_json['host'],
                                          user=user_json['user'],
                                          password=user_json['password'],
                                          database=user_json['user'],
                                          port=user_json['port'],
                                          charset="utf8mb4",
                                          cursorclass=DictCursor,
                                          autocommit=True)
        # 连接 Elasticsearch
        username = os.getenv('ES_USERNAME', user_json['es_user'])
        password = os.getenv('ES_PASSWORD', user_json['es_password'])
        self.es_db = Elasticsearch(
            hosts=[f"http://{user_json['host']}:9200"],
            basic_auth=(username, password),  # 使用basic_auth替换http_auth
            verify_certs=False,
            max_retries=3,
            retry_on_timeout=True
        ).options(ignore_status=404)
        self.max_id = 0
        self.category_map = {}  # 用于存储name到id的映射
        self.next_id = 1  # 本地自增ID计数器
        self.dirname_map = {}  # 记录已生成的目录名，避免重复
        # 判断es索引是否创建
        self.if_es_suoyin()

    def generate_code(self, length=20):
        # 生成数字和小写字母的字符集合
        characters = string.digits + string.ascii_lowercase
        # 从字符集合中随机选择指定长度的字符，并拼接成字符串
        return ''.join(random.choice(characters) for _ in range(length))

    # 判断是否为题库
    def lanmu_id_pd(self, lanmu_id):
        query = "SELECT" + " child FROM dr_exam_category WHERE id = " + str(lanmu_id)
        cursor = self.connection.cursor()
        cursor.execute(query)
        result = cursor.fetchone()
        cursor.close()
        if result['child'] == 1:
            print('此栏目非题库，请检查！')
            exit()

    # 获取表中当前最大ID
    def _get_max_id(self):
        query = "SELECT MAX(id) as max_id FROM " + self.biao_name
        cursor = self.connection.cursor()
        cursor.execute(query)
        result = cursor.fetchone()
        cursor.close()
        if result and result['max_id']:
            self.max_id = result['max_id']
            self.next_id = self.max_id + 1
            return self.next_id
        else:
            self.max_id = 0
            self.next_id = 1
            return self.next_id

    # 根据栏目名称生成目录名
    def _generate_dirname(self, name: str, parent_dirname: str = "") -> str:
        # 步骤1: 过滤特殊字符，只保留汉字、字母、数字
        # 正则表达式：匹配汉字、字母、数字
        pattern = re.compile(r'[\u4e00-\u9fa5a-zA-Z0-9]+')
        matches = pattern.findall(name)
        cleaned_name = ''.join(matches)

        # 步骤2: 检查是否是纯字母数字
        if re.match(r'^[a-zA-Z0-9]+$', cleaned_name):
            # 纯字母数字，直接转换为小写
            base_dirname = cleaned_name.lower()
        else:
            # 检查是否是纯汉字
            if re.match(r'^[\u4e00-\u9fa5]+$', cleaned_name):
                # 纯汉字
                if len(cleaned_name) > 3:
                    # 大于3个字：取拼音首字母
                    pinyin_list = lazy_pinyin(cleaned_name, style=Style.FIRST_LETTER)
                    base_dirname = ''.join(pinyin_list).lower()
                else:
                    # 不大于3个字：全拼
                    pinyin_list = lazy_pinyin(cleaned_name)
                    base_dirname = ''.join(pinyin_list).lower()
            else:
                # 混合类型（汉字+字母数字），分别处理
                result = []
                for char in cleaned_name:
                    if re.match(r'[\u4e00-\u9fa5]', char):
                        # 汉字
                        if len(cleaned_name) > 3:
                            pinyin = lazy_pinyin(char, style=Style.FIRST_LETTER)[0]
                        else:
                            pinyin = lazy_pinyin(char)[0]
                        result.append(pinyin)
                    else:
                        # 字母数字
                        result.append(char.lower())
                base_dirname = ''.join(result)

        # 步骤3: 确保目录名只包含字母、数字、下划线、连字符
        base_dirname = re.sub(r'[^a-z0-9_-]', '', base_dirname)

        # 步骤4: 避免重复
        dirname = base_dirname
        counter = 1

        # 生成完整的目录路径用于检查
        full_dirname = parent_dirname + dirname if parent_dirname else dirname

        while full_dirname in self.dirname_map:
            # 如果目录名已存在，添加数字后缀
            dirname = f"{base_dirname}_{counter}"
            full_dirname = parent_dirname + dirname if parent_dirname else dirname
            counter += 1

        # 记录已使用的目录名
        self.dirname_map[full_dirname] = True

        return dirname

    # 获取父级ID和所有上级ID
    def _get_parent_ids(self, parent_name) -> tuple:
        if not parent_name or parent_name == "":
            return 0, "0"  # 没有父级

        if parent_name in self.category_map:
            parent_id = self.category_map[parent_name]["id"]
            parent_pids = self.category_map[parent_name]["pids"]
            pids = f"{parent_pids},{parent_id}" if parent_pids != "0" else f"0,{parent_id}"
            return parent_id, pids

        return 0, "0"  # 父级不存在，设为顶级

    # 获取上级目录路径
    def _get_pdirname(self, parent_name: str) -> str:
        if parent_name in self.category_map:
            parent = self.category_map[parent_name]
            parent_dirname = parent["dirname"]
            parent_pdirname = parent["pdirname"]

            if parent_pdirname:
                return f"{parent_pdirname}{parent_dirname}/"
            else:
                return f"{parent_dirname}/"

        return ""

    # 获取上级目录路径
    def _build_category_tree(self, categories: List[Dict], parent_name: str = "") -> List[Dict]:
        result = []
        for category in categories:
            category_data = category.copy()
            name = category_data.get("name", "")

            # 处理当前栏目
            current_id = self.next_id
            self.next_id += 1

            pid, pids = self._get_parent_ids(parent_name)
            # 获取上级目录路径
            pdirname = self._get_pdirname(parent_name)

            # 生成目录名
            dirname = category_data.get("dirname")
            if not dirname:
                dirname = self._generate_dirname(name, pdirname)

            # 是否有子级
            has_children = "children" in category_data and len(category_data["children"]) > 0

            # 构建栏目数据
            processed_category = {}
            if self.biao_name == "dr_exam_category":
                processed_category = {
                    "id": current_id,
                    "pid": pid,
                    "pids": pids,
                    "name": name,
                    "dirname": dirname,
                    "pdirname": pdirname,
                    "child": 1 if has_children else 0,
                    "disabled": 0,  # 默认不禁用
                    "childids": "",  # 初始为空，稍后更新
                    "show": 1,  # 默认显示
                    "setting": "",  # 属性配置，可根据需要设置
                    "displayorder": 0,  # 显示顺序
                    "group": '["1","3"]'  # 用户组，默认为1
                }
            elif self.biao_name == "dr_exam_chapter":
                processed_category = {
                    "id": current_id,
                    "pid": pid,
                    "pids": pids,
                    "name": name,
                    "dirname": dirname,
                    "pdirname": pdirname,
                    "child": 1 if has_children else 0,
                    "disabled": 0,  # 默认不禁用
                    "childids": "",  # 初始为空，稍后更新
                    "show": 1,  # 默认显示
                    "setting": "",  # 属性配置，可根据需要设置
                    "displayorder": 0,  # 显示顺序
                    "catid": self.lanmu_id  # 所属栏目
                }

            # 存储到映射表
            self.category_map[name] = {
                "id": current_id,
                "pids": pids,
                "dirname": dirname,
                "pdirname": pdirname
            }

            result.append(processed_category)

            # 递归处理子栏目
            if has_children:
                children = self._build_category_tree(category_data["children"], name)
                result.extend(children)

                # 更新childids
                child_ids = ",".join([str(child["id"]) for child in children if "id" in child])
                if child_ids:
                    processed_category["childids"] = child_ids

        return result

    # 更新所有父级栏目的childids字段
    def _update_childids(self, categories: List[Dict]):
        # 按pid分组
        children_by_parent = {}
        for category in categories:
            pid = category["pid"]
            if pid not in children_by_parent:
                children_by_parent[pid] = []
            children_by_parent[pid].append(category["id"])

        # 更新每个父级栏目的childids
        for pid, child_ids in children_by_parent.items():
            if pid > 0:  # 跳过顶级栏目
                child_ids_str = ",".join(map(str, child_ids))
                # 找到对应的栏目并更新
                for category in categories:
                    if category["id"] == pid:
                        category["childids"] = child_ids_str
                        break

    # 将栏目数据插入数据库
    def _insert_categories(self, categories: List[Dict]):
        if not categories:
            print("没有数据需要插入")
            return

        # SQL插入语句
        if self.biao_name == 'dr_exam_category':
            insert_query = "INSERT INTO " + self.biao_name + " (id, pid, pids, name, dirname, pdirname, child, disabled, childids, `show`, setting, displayorder, `group`) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
        else:
            insert_query = "INSERT INTO " + self.biao_name + " (id, pid, pids, name, dirname, pdirname, child, disabled, childids, `show`, setting, displayorder,catid) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
        # 准备数据
        values = []
        for category in categories:
            if self.biao_name == 'dr_exam_category':
                values.append((
                    category["id"],
                    category["pid"],
                    category["pids"],
                    category["name"],
                    category["dirname"],
                    category["pdirname"],
                    category["child"],
                    category["disabled"],
                    category["childids"],
                    category["show"],
                    category["setting"],
                    category["displayorder"],
                    category["group"]
                ))
            elif self.biao_name == 'dr_exam_chapter':
                insert_query = "INSERT INTO " + self.biao_name + " (id, pid, pids, name, dirname, pdirname, child, disabled, childids, `show`, setting, displayorder,catid) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
                values.append((
                    category["id"],
                    category["pid"],
                    category["pids"],
                    category["name"],
                    category["dirname"],
                    category["pdirname"],
                    category["child"],
                    category["disabled"],
                    category["childids"],
                    category["show"],
                    category["setting"],
                    category["displayorder"],
                    category["catid"]
                ))
        # 批量插入
        cursor = self.connection.cursor()
        cursor.executemany(insert_query, values)
        cursor.close()
        print(f"成功插入 {len(categories)} 条记录")

    # 递归删除子节点的catid，只保留顶层节点的catid
    def _remove_child_catids(self, tree_nodes):
        for node in tree_nodes:
            if 'children' in node and node['children']:
                # 递归处理子节点
                self._remove_child_catids(node['children'])
                # 遍历子节点，删除它们的catid字段
                for child in node['children']:
                    if 'catid' in child:
                        del child['catid']

    # 检查索引是否存在，如果不存在则创建
    def if_es_suoyin(self):
        # 试题表
        mapping = {
            "mappings": {
                "properties": {
                    "tid": {"type": "integer"},
                    "title": {"type": "text", "index": False},
                    "seotitle": {"type": "text", "analyzer": "ik_max_word", "search_analyzer": "ik_smart"},
                    "keyword": {"type": "keyword"},
                    "papr_list": {"type": "keyword"},
                    "value": {"type": "text", "index": False},
                    "tips": {"type": "text", "index": False},
                    "answer": {"type": "text", "index": False},
                    "inputtime": {"type": "integer"},
                    "cid": {"type": "integer"},
                    "module": {"type": "text", "index": False},
                    "group": {"type": "text", "index": False},
                    "dedupe": {"type": "keyword"},
                }
            },
            "settings": {
                "number_of_shards": 1,
                "number_of_replicas": 0
            }
        }
        if not self.es_db.indices.exists(index="es_exam_question"):
            self.es_db.indices.create(index="es_exam_question", body=mapping)
        # 题目归属表
        mapping = {
            "mappings": {
                "properties": {
                    "qid": {"type": "text", "index": False},
                    "catid": {"type": "integer"},
                    "cid": {"type": "integer"},
                }
            },
            "settings": {
                "number_of_shards": 1,
                "number_of_replicas": 0
            }
        }
        if not self.es_db.indices.exists(index="es_exam_category_question"):
            self.es_db.indices.create(index="es_exam_category_question", body=mapping)
        # 试卷表
        mapping = {
            "mappings": {
                "properties": {
                    "title": {"type": "text", "analyzer": "ik_max_word", "search_analyzer": "ik_smart"},
                    "paper": {"type": "text", "index": False},
                }
            },
            "settings": {
                "number_of_shards": 1,
                "number_of_replicas": 0
            }
        }
        if not self.es_db.indices.exists(index="es_exam_paper"):
            self.es_db.indices.create(index="es_exam_paper", body=mapping)
        # 材料表
        mapping = {
            "mappings": {
                "properties": {
                    "title": {"type": "text", "analyzer": "ik_max_word", "search_analyzer": "ik_smart"},
                    "qids": {"type": "text", "index": False},
                    "inputtime": {"type": "integer"},
                    "cid": {"type": "text", "index": False}
                }
            },
            "settings": {
                "number_of_shards": 1,
                "number_of_replicas": 0
            }
        }
        if not self.es_db.indices.exists(index="es_exam_composite"):
            self.es_db.indices.create(index="es_exam_composite", body=mapping)

    # 根据栏目名称和章节名称查找对应的 ID
    def get_lanmu_zhangjie_id(self, lanmu_name, zhangjie, lanmu_all, zhangjie_all):
        def find_column(node_list, target_name):
            for node in node_list:
                if node.get("name") == target_name:
                    return node.get("id")
                if "children" in node and node["children"]:
                    found = find_column(node["children"], target_name)
                    if found is not None:
                        return found

        column_id = find_column(lanmu_all, lanmu_name)
        # 在章节列表中查找对应章节
        chapter_id = 0
        for chapter in zhangjie_all:
            if chapter.get("name") == zhangjie and chapter.get("catid") == column_id:
                chapter_id = chapter.get("id")
                break
        if not chapter_id:
            pass
        return column_id, chapter_id

    # 试题生成es器函数 格式化文档
    def shiti_generator(self, data_list: List[Dict]) -> Generator[Dict[str, Any], None, None]:
        for item in data_list:
            # 生成文档操作
            yield {
                "_index": "es_exam_question",
                "_id": self.generate_code(),
                "_source": {
                    "tid": item['tid'],
                    "title": item['title'],
                    "seotitle": item['seotitle'],
                    "keyword": item['keyword'],
                    "value": item['value'],
                    "tips": item['tips'],
                    "answer": item['answer'],
                    "inputtime": item['inputtime'],
                    "cid": item['cid'],
                    "papr_list": item['papr'],
                    "module": item['module'],
                    "group": item['group']}}

    # 试卷生成es器函数 格式化文档
    def shijuan_generator(self, data_list: List[Dict]) -> Generator[Dict[str, Any], None, None]:
        self.shijuan_id_list = []
        for item in data_list:
            linshi_id = self.generate_code()
            self.shijuan_id_list.append(linshi_id)
            # 生成文档操作
            yield {
                "_index": "es_exam_paper",
                "_id": linshi_id,
                "_source": {
                    "title": item['name'].replace('-', '_'),
                    "paper": item['data_value']}}

    # 归属生成es器函数 格式化文档
    def guishu_generator(self, data_list: List[Dict]) -> Generator[Dict[str, Any], None, None]:
        for item in data_list:
            # 生成文档操作
            yield {
                "_id": self.generate_code(),
                "_index": "es_exam_category_question",
                "_source": {
                    "qid": item['qid'],
                    "catid": item['catid'],
                    "cid": item['cid']}}

    # 从JSON文件导入数据
    def post_lanmu(self, leibie, data_json, lanmu_id=0):
        if leibie == "栏目":
            self.biao_name = 'dr_exam_category'
        else:
            self.biao_name = 'dr_exam_chapter'
            self.lanmu_id = lanmu_id
            # 判断栏目是否为题库
            self.lanmu_id_pd(lanmu_id)

        # 获取最大id
        self._get_max_id()
        # 重置目录名映射
        self.dirname_map = {}

        # 构建栏目数据
        all_categories = self._build_category_tree(data_json)

        # 更新所有栏目的childids
        self._update_childids(all_categories)

        # 插入数据到数据库
        self._insert_categories(all_categories)

        print(f"成功导入 {len(all_categories)} 个栏目")

    # json根据栏目id章节导入
    def post_zhangjie(self, data_json):
        lanmu_all = self.get_lanmu('栏目')
        for item in data_json:
            lanmu_id = self.get_lanmu_zhangjie_id(item['name'], '', lanmu_all, [])[0]
            self.lanmu_id = lanmu_id
            for ite in item['children']:
                new_item = [{"name": ite, "children": []}]
                self.post_lanmu(leibie='章节', data_json=new_item, lanmu_id=lanmu_id)

    # 导出为JSON
    def get_lanmu(self, leibie):
        if leibie == "栏目":
            biao_name = 'dr_exam_category'
        else:
            biao_name = 'dr_exam_chapter'
        # 获取数据
        if biao_name == 'dr_exam_category':
            query = "SELECT" + f" id, pid, name FROM `{biao_name}` ORDER BY pid, id"
        else:  # 章节表需要catid字段
            query = "SELECT" + f" id, pid, name, catid FROM `{biao_name}` ORDER BY pid, id"
        cursor = self.connection.cursor()
        cursor.execute(query)
        data = cursor.fetchall()
        cursor.close()
        # 构建映射字典
        node_dict = {}
        for row in data:
            if leibie == "栏目":
                node = {"id": row['id'], "name": row['name'], "children": []}
            else:
                node = {"id": row['id'], "catid": row['catid'], "name": row['name'], "children": []}
            node_dict[row['id']] = node

        # 构建树
        tree_data = []
        for row in data:
            node = node_dict[row['id']]
            if row['pid'] == 0 or row['pid'] not in node_dict:
                tree_data.append(node)
            else:
                parent = node_dict.get(row['pid'])
                if parent:
                    parent["children"].append(node)

        # 对于章节数据，删除子节点的catid，只保留顶层节点的catid
        if biao_name == 'dr_exam_chapter':
            self._remove_child_catids(tree_data)
        return tree_data

    # 试题发布
    def post_shiti(self, data_list: List[Dict]):
        # 获取生成器
        doc_generator = self.shiti_generator(data_list)
        # 执行批量插入
        bulk(self.es_db, doc_generator, chunk_size=5000, stats_only=False, raise_on_error=False)

    # 模块试卷发布
    def post_mokuai(self, url, data):
        requests.post(url, data)

    # 更新 ES 中多个文档的 cid 字段
    def update_cid_in_es(self, shiti_list, cid_value):
        index = "es_exam_question"
        for _id in shiti_list:
            # 更新单个文档
            self.es_db.update(
                index=index,
                id=_id,
                body={
                    "doc": {
                        "cid": cid_value
                    }
                }
            )

    # 更新es
    def gengxin_es(self, shijuan_id, shiti_list):
        index = "es_exam_question"
        for _id in shiti_list:
            # ✅ 正确的（有去重检查）
            d = self.es_db.update(
                index=index,
                id=_id,
                body={
                    "script": {
                        "source": """
                            if (ctx._source.papr_list == null) {
                                ctx._source.papr_list = [params.keyword];
                            } else {
                                // 关键：检查是否已存在
                                if (!ctx._source.papr_list.contains(params.keyword)) {
                                    ctx._source.papr_list.add(params.keyword);
                                }
                            }
                        """,
                        "params": {"keyword": shijuan_id}
                    }
                }
            )

    # 发布编程模块试卷
    def post_mokuai_dzxh_shijuan(self, url, data, shijuan_id):
        title = data["name"].replace('-', '_')
        shiti_list = json.dumps(data["shiti_ids"])
        lanmu_name = data["lanmu_name"]
        time = data["shijuan_time"]
        nianfen = data["nianfen"]

        tixing_name = data["tixing_name"]
        lqjibie_name = data["lqjibie_name"]
        noijibie_name = data["noijibie_name"]
        dzxhjibie_name = data["dzxhjibie_name"]
        gespjibie_name = data["gespjibie_name"]
        zubie_name = data["zubie_name"]
        csplc_name = data["csplc"]
        xxleixing_name = data["xxleixing_name"]

        collapi_catname = data["collapi_catname"]
        self.biao_name = "dr_1_kjjs"
        shijuan_mokuai_id = self._get_max_id()
        shijuan_mokuai_id += 1
        nianfen_list = {"2026年": 1, "2025年": 2, "2024年": 3, "2023年": 4, "2022年": 5, "2021年": 6, "2020年": 7,
                        "更早": 8}

        tixing_list = {"客观题": 1, "实操/编程": 2}

        jibie_list = {"一级": 1, "二级": 2, "三级": 3, "四级": 4, "五级": 5, "六级": 6, "七级": 7, "八级": 8,
                      "九级": 9, "十级": 10}

        lqjibie_list = {"STEMA": 1, "省赛": 2, "国赛": 3, "模拟": 4}

        noijibie_list = {None: "", "初赛": 1, "复赛": 2}
        leixing_list = {None: "", "真题": 1, "模拟": 2}
        csplc_list = {None: "", "第一轮": 1, "第二轮": 2}
        zubie_list = {None: "", "小低": 1, "小高": 2, "小学": 3, "初中": 4, "其他": 5}

        match = re.search(r'\d{4}', nianfen)
        nianfen_pd = match.group()
        if int(nianfen_pd) < 2020:
            nianfen_cl = "更早"
        else:
            nianfen_cl = nianfen
        if data["leixing"] == "电子学会":
            data = {"id": shijuan_mokuai_id,
                    "collapi_catname": collapi_catname,
                    "title": title,
                    "keywords": nianfen + "电子学会" + lanmu_name + "试卷",
                    "description": title,
                    "inputtime": time,
                    "updatetime": time,
                    "paper_id": shijuan_id,
                    "question_list": shiti_list,
                    "nianfen": nianfen_list[nianfen_cl],
                    "tixing": tixing_list[tixing_name],
                    "jibie": jibie_list[dzxhjibie_name.replace("机器人", "").replace(
                        "Scratch", "").replace("Python", "").replace("C/C++", "")]}
        elif data["leixing"] == "蓝桥杯":
            data = {"id": shijuan_mokuai_id,
                    "collapi_catname": collapi_catname,
                    "title": title,
                    "keywords": nianfen + "蓝桥杯" + lanmu_name + "试卷",
                    "description": title,
                    "inputtime": time,
                    "updatetime": time,
                    "paper_id": shijuan_id,
                    "question_list": shiti_list,
                    "nianfen": nianfen_list[nianfen_cl],
                    "lqjb": lqjibie_list[lqjibie_name]}
        elif data["leixing"] == "信息素养大赛":
            data = {"id": shijuan_mokuai_id,
                    "collapi_catname": collapi_catname,
                    "title": title,
                    "keywords": nianfen + "信息素养大赛" + lanmu_name + "试卷",
                    "description": title,
                    "inputtime": time,
                    "updatetime": time,
                    "paper_id": shijuan_id,
                    "question_list": shiti_list,
                    "nianfen": nianfen_list[nianfen_cl],
                    "noipjb": noijibie_list[noijibie_name],
                    "leixing": leixing_list[xxleixing_name],
                    "xxzb": zubie_list[zubie_name]}

        elif data["leixing"] == "信息学奥赛":
            if "CSP-" in lanmu_name:
                data = {"id": shijuan_mokuai_id,
                        "collapi_catname": collapi_catname,
                        "title": title,
                        "keywords": nianfen + "信息学奥赛" + lanmu_name + "试卷",
                        "description": title,
                        "inputtime": time,
                        "updatetime": time,
                        "paper_id": shijuan_id,
                        "question_list": shiti_list,
                        "nianfen": nianfen_list[nianfen_cl],
                        "csplc": csplc_list[csplc_name]}
            elif "NOIP" in lanmu_name:
                data = {"id": shijuan_mokuai_id,
                        "collapi_catname": collapi_catname,
                        "title": title,
                        "keywords": nianfen + "信息学奥赛" + lanmu_name + "试卷",
                        "description": title,
                        "inputtime": time,
                        "updatetime": time,
                        "paper_id": shijuan_id,
                        "question_list": shiti_list,
                        "nianfen": nianfen_list[nianfen_cl],
                        "noipjb": noijibie_list[noijibie_name]}
            else:
                data = {"id": shijuan_mokuai_id,
                        "collapi_catname": collapi_catname,
                        "title": title,
                        "keywords": nianfen + "信息学奥赛" + lanmu_name + "试卷",
                        "description": title,
                        "inputtime": time,
                        "updatetime": time,
                        "paper_id": shijuan_id,
                        "question_list": shiti_list,
                        "nianfen": nianfen_list[nianfen_cl]}

        elif data["leixing"] == "gesp":
            data = {"id": shijuan_mokuai_id,
                    "collapi_catname": collapi_catname,
                    "title": title,
                    "keywords": nianfen + "CCF-GESP " + lanmu_name + "试卷",
                    "description": title,
                    "inputtime": time,
                    "updatetime": time,
                    "paper_id": shijuan_id,
                    "question_list": shiti_list,
                    "nianfen": nianfen_list[nianfen_cl],
                    "jibie": jibie_list[gespjibie_name.replace(
                        "Scratch", "").replace("Python", "").replace("C++", "").replace("图形化", "")]}

        # 发布模块试卷
        self.post_mokuai(url, data)
        # 更新es试卷字段
        self.gengxin_es(shijuan_mokuai_id, json.loads(shiti_list))

    # 试卷发布
    def post_shijuan(self, url, data_list):
        # 获取生成器
        doc_generator = self.shijuan_generator(data_list)
        # 执行批量插入
        bulk(self.es_db, doc_generator, chunk_size=5000, stats_only=False, raise_on_error=False)
        insert_query = "INSERT INTO " + "dr_exam_paper (title,paper) VALUES (%s, %s)"
        # 逐条插入
        cursor = self.connection.cursor()
        # 当转es试卷时使用如下
        # for shijuan_id,data in zip(self.shijuan_id_list,data_list):
        #     self.post_mokuai_dzxh_shijuan(url, data, shijuan_id)
        # 当转es试卷时注释如下
        for data in data_list:
            data["name"] = data["name"].replace('-', '_')
            cursor.execute(insert_query, (data["name"], data["data_value"]))
            id_shijuan = cursor.lastrowid
            # 发布模块试卷
            self.post_mokuai_dzxh_shijuan(url, data, id_shijuan)
        cursor.close()

    # 试题归属发布
    def post_guishu(self, data_list: List[Dict]):
        # 获取生成器
        doc_generator = self.guishu_generator(data_list)
        # 执行批量插入
        bulk(self.es_db, doc_generator, chunk_size=5000, stats_only=False, raise_on_error=False)
        values = []
        insert_query = "INSERT INTO " + "dr_exam_category_question (qid,catid,cid) VALUES (%s, %s, %s)"
        for data in data_list:
            values.append((
                data['qid'],
                data['catid'],
                data['cid']
            ))
        # 批量插入
        cursor = self.connection.cursor()
        cursor.executemany(insert_query, values)
        cursor.close()

    # 材料题发布
    def post_cailiao(self, data_list):
        # 获取生成器
        doc_id = self.generate_code()
        doc_data = {"title": data_list[0], "qids": data_list[1], "inputtime": data_list[2], "cid": data_list[3]}
        self.es_db.index(index="es_exam_composite", id=doc_id, body=doc_data)
        insert_query = "INSERT INTO " + "dr_exam_composite (title,qids,inputtime,cid) VALUES (%s, %s, %s, %s)"
        # 插入
        cursor = self.connection.cursor()
        var = (data_list[0], data_list[1], data_list[2], data_list[3])
        cursor.execute(insert_query, var)
        # 获取刚插入记录的自增ID
        inserted_id = cursor.lastrowid
        cursor.close()
        return inserted_id, doc_id

    # 考级竞赛处理
    def post_kaoji_chuli(self, it, lanmu_all, zhangjie_all, shijuan_time):
        lanmu_name = it['栏目']
        zhangjie = it['章节']
        xinxi = self.get_lanmu_zhangjie_id(lanmu_name, zhangjie, lanmu_all, zhangjie_all)
        lanmu_id = xinxi[0]
        zhangjie_id = xinxi[1]
        if not zhangjie_id:
            zhangjie_id = 0
        dt = datetime.strptime(it['inputtime'], "%Y-%m-%d %H:%M:%S")
        time = int(dt.timestamp())
        if not shijuan_time:
            shijuan_time = it['inputtime']
        if not it['cid']:
            it['cid'] = 0
        ti_es_id = self.generate_code()
        collapi_catname = it['collapi_catname']
        doc = {
            "tid": it['tid'],
            "title": it['title'],
            "seotitle": it['seotitle'],
            "dedupe": it['dedupe'],
            "keyword": list(set(it['keyword'])),
            "value": json.dumps(it['value']),
            "tips": it['tips'],
            "answer": it['answer'],
            "inputtime": time,
            "cid": it['cid'],
            "papr_list": [],
            "module": "kjjs",
            "group": it['group'],
        }
        # 发布数据
        self.es_db.index(index="es_exam_question", id=ti_es_id, document=doc)
        # 关联数据id
        return {'qid': ti_es_id, 'catid': lanmu_id, 'cid': zhangjie_id,
                'linshi': it}, ti_es_id, lanmu_name, collapi_catname

    # 发布编程考级
    def post_kaoji(self, url, data_list):
        lanmu_all = self.get_lanmu('栏目')
        zhangjie_all = self.get_lanmu('章节')
        guishu_all = []
        shijuan_list = []
        for data in data_list:
            name = next(iter(data))

            tixing_name = None
            if "tixing_name" in data:
                tixing_name = data["tixing_name"]

            lqjibie_name = None
            if "lqjibie_name" in data:
                lqjibie_name = data["lqjibie_name"]

            noijibie_name = None
            if "noijibie_name" in data:
                noijibie_name = data["noijibie_name"]

            dzxhjibie_name = None
            if "dzxhjibie_name" in data:
                dzxhjibie_name = data["dzxhjibie_name"]

            gespjibie_name = None
            if "gespjibie_name" in data:
                gespjibie_name = data["gespjibie_name"]

            zubie_name = None
            if "zubie_name" in data:
                zubie_name = data["zubie_name"]

            csplc_name = None
            if "csplc" in data:
                csplc_name = data["csplc"]

            xxleixing_name = None
            if "xxleixing_name" in data:
                xxleixing_name = data["xxleixing_name"]

            shiti_ids = []
            shijuan_time = None
            for it in data[name]:
                pattern = re.compile(
                    r'<p>\s*<a\s[^>]*>\s*&gt;&gt;试试在线提交？季卡以上会员请联系客服，\s*'
                    r'<span[^>]*>免费</span>\s*开通OJ账号\s*</a>\s*</p>',
                    re.IGNORECASE
                )
                if 'answer' in it and it['answer'] and type(it['answer']) != list:
                    it['answer'] = pattern.sub('', it['answer'])

                it['title'] = pattern.sub('', it['title'])
                if 'tips' in it and it['tips']:
                    it['tips'] = pattern.sub('', it['tips'])

                nianfen = it['nianfen']
                match = re.search(r'(\d{4})年', nianfen)
                nianfen = match.group(0)

                if "timu_list" in it:
                    zuhe_ids = []
                    guishu_zuhe = None
                    for zi_ti in it["timu_list"]:
                        linshi = self.post_kaoji_chuli(zi_ti, lanmu_all, zhangjie_all, shijuan_time)
                        if not guishu_zuhe:
                            guishu_zuhe = linshi[0]
                        zuhe_ids.append(linshi[1])
                        lanmu_name = linshi[2]
                        collapi_catname = linshi[3]

                    # 材料发布
                    dt = datetime.strptime(it['inputtime'], "%Y-%m-%d %H:%M:%S")
                    time = int(dt.timestamp())
                    # 当需要调整为es_id时，需要把[0]改为[1]，注意试卷发布模块post_shijuan也要改
                    cailiao_id = self.post_cailiao([it['title'], '1', time, json.dumps(zuhe_ids)])[0]

                    # 更新试题表
                    self.update_cid_in_es(zuhe_ids, cailiao_id)
                    guishu_zuhe['qid'] = cailiao_id
                    guishu_all.append(guishu_zuhe)
                    shiti_ids.append(cailiao_id)
                else:
                    linshi = self.post_kaoji_chuli(it, lanmu_all, zhangjie_all, shijuan_time)
                    guishu_all.append(linshi[0])
                    shiti_ids.append(linshi[1])
                    lanmu_name = linshi[2]
                    collapi_catname = linshi[3]

            data_value = {"1": {"value": {}, "rand": {"tid": "0", "score": "1", "num": "0"}}}
            data_value["1"]["value"] = {i: "" for i in shiti_ids}
            shijuan_list.append(
                {"name": name, "data_value": json.dumps(data_value), "shiti_ids": shiti_ids,
                 "shijuan_time": shijuan_time, "nianfen": nianfen, "tixing_name": tixing_name,
                 "collapi_catname": collapi_catname, "lanmu_name": lanmu_name,
                 "lqjibie_name": lqjibie_name, "noijibie_name": noijibie_name, "dzxhjibie_name": dzxhjibie_name,
                 "gespjibie_name": gespjibie_name,
                 "zubie_name": zubie_name, "csplc": csplc_name, "xxleixing_name": xxleixing_name,
                 "leixing": data["leixing"], })

        # 发布关联数据
        self.post_guishu(guishu_all)
        try:
            self.connection.ping(reconnect=False)  # 不自动重连，只检查
        except Exception:
            self.connection = pymysql.connect(host=self.user_json['host'],
                                              user=self.user_json['user'],
                                              password=self.user_json['password'],
                                              database=self.user_json['user'],
                                              port=self.user_json['port'],
                                              charset="utf8mb4",
                                              cursorclass=DictCursor)
        # 发布试卷数据
        self.post_shijuan(url, shijuan_list)

    def post_lego(self):
        pass
