# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.0] - 2026-04-06

### Changed

- First public release (0.1.x versions burned on PyPI due to filename reuse restriction).

## [0.1.0] - 2026-04-06 (unpublished)

### Added

- Initial release with Typer-based CLI (`vanty` command).
- **Hetzner Cloud**: server lifecycle (create, list, delete, SSH), firewall
  management, volume management, image snapshots, and full deploy workflow.
- **Cloudflare**: DNS record management and zone listing.
- **Neon**: project and branch management for serverless Postgres.
- **GitHub**: repository creation and listing via the GitHub API.
- **Resend**: send transactional emails from the command line.
- **Deploy**: end-to-end deployment orchestrator combining Hetzner server
  provisioning, Cloudflare DNS, and SSH-based application setup.
- Rich-formatted console output throughout.
