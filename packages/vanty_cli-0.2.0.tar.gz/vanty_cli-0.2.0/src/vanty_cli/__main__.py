"""Allow running as `python -m vanty_cli`."""

from vanty_cli.main import app

if __name__ == "__main__":
    app()
