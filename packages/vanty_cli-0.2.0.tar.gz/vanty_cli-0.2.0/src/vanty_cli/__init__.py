"""Vanty CLI - Infrastructure and deployment management."""

__version__ = "0.1.0"
