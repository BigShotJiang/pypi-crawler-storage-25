"""Neon Database API provider."""

from typing import Any

from neon_api import NeonAPI

from vanty_cli.config import get_settings


def get_neon_client() -> NeonAPI:
    """Return an authenticated Neon API client."""
    settings = get_settings()
    if not settings.neon_api_key:
        raise ValueError("NEON_API_KEY is required")
    return NeonAPI(api_key=settings.neon_api_key)


class NeonProvider:
    """Wrapper for Neon API operations."""

    def __init__(self) -> None:
        self.client = get_neon_client()

    def _to_dict(self, obj: Any) -> dict[str, Any]:
        """Convert SDK responses to plain dicts."""
        if hasattr(obj, "model_dump"):
            return obj.model_dump()
        if hasattr(obj, "__dict__"):
            return {key: value for key, value in obj.__dict__.items() if not key.startswith("_")}
        if isinstance(obj, dict):
            return obj
        return {}

    def list_projects(self) -> list[dict[str, Any]]:
        """List Neon projects."""
        response = self.client.projects()
        return [self._to_dict(project) for project in response.projects]

    def create_project(
        self,
        name: str,
        region_id: str = "aws-us-east-2",
        pg_version: int = 16,
    ) -> dict[str, Any]:
        """Create a new project and return metadata plus a connection URI if available."""
        response = self.client.project_create(
            project={"name": name, "region_id": region_id, "pg_version": pg_version}
        )
        project = self._to_dict(response.project)
        project_id = project.get("id")
        branches = self.client.branches(project_id=project_id) if project_id else None
        branch = self._to_dict(branches.branches[0]) if branches and branches.branches else {}

        connection_uri = ""
        if project_id:
            try:
                connection_uri = self.client.connection_uri(
                    project_id=project_id,
                    database_name="neondb",
                    role_name="neondb_owner",
                    pooled=True,
                ).uri
            except Exception:
                connection_uri = ""

        return {
            "project": project,
            "branch": branch,
            "connection_uri": connection_uri,
        }

    def get_project(self, project_id: str) -> dict[str, Any]:
        """Get project details."""
        response = self.client.project(project_id=project_id)
        return self._to_dict(response.project)

    def rename_project(self, project_id: str, name: str) -> dict[str, Any]:
        """Rename a project."""
        response = self.client.project_update(project_id=project_id, project={"name": name})
        return self._to_dict(response.project)

    def delete_project(self, project_id: str) -> bool:
        """Delete a project."""
        self.client.project_delete(project_id=project_id)
        return True

    def list_branches(self, project_id: str) -> list[dict[str, Any]]:
        """List branches for a project."""
        response = self.client.branches(project_id=project_id)
        return [self._to_dict(branch) for branch in response.branches]

    def create_branch(self, project_id: str, name: str, parent_id: str | None = None) -> dict[str, Any]:
        """Create a branch."""
        branch_config: dict[str, Any] = {"name": name}
        if parent_id:
            branch_config["parent_id"] = parent_id
        response = self.client.branch_create(project_id=project_id, branch=branch_config)
        return {
            "branch": self._to_dict(response.branch),
            "endpoints": [self._to_dict(endpoint) for endpoint in (response.endpoints or [])],
            "connection_uris": [self._to_dict(uri) for uri in (response.connection_uris or [])],
        }

    def delete_branch(self, project_id: str, branch_id: str) -> bool:
        """Delete a branch."""
        self.client.branch_delete(project_id=project_id, branch_id=branch_id)
        return True

    def get_connection_uri(
        self,
        project_id: str,
        database_name: str = "neondb",
        role_name: str = "neondb_owner",
        pooled: bool = True,
    ) -> str:
        """Get a connection URI for a project."""
        response = self.client.connection_uri(
            project_id=project_id,
            database_name=database_name,
            role_name=role_name,
            pooled=pooled,
        )
        return response.uri

    def list_databases(self, project_id: str, branch_id: str) -> list[dict[str, Any]]:
        """List databases in a branch."""
        response = self.client.databases(project_id=project_id, branch_id=branch_id)
        return [self._to_dict(database) for database in response.databases]

    def create_database(
        self,
        project_id: str,
        branch_id: str,
        name: str,
        owner_name: str = "neondb_owner",
    ) -> dict[str, Any]:
        """Create a database in a branch."""
        response = self.client.database_create(
            project_id=project_id,
            branch_id=branch_id,
            database={"name": name, "owner_name": owner_name},
        )
        return self._to_dict(response.database)

    def delete_database(self, project_id: str, branch_id: str, database_name: str) -> bool:
        """Delete a database from a branch."""
        self.client.database_delete(
            project_id=project_id,
            branch_id=branch_id,
            database_name=database_name,
        )
        return True
