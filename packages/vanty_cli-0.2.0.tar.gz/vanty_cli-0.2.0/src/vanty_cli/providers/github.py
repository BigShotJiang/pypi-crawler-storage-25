"""GitHub API wrapper for webhooks and deploy keys."""

import secrets
from typing import Any

import httpx

from vanty_cli.config import get_settings


class GitHubProvider:
    """Wrapper for GitHub API operations."""

    base_url = "https://api.github.com"

    def __init__(self, token: str | None = None) -> None:
        settings = get_settings()
        self.token = token or settings.github_token
        if not self.token:
            raise ValueError("GITHUB_TOKEN is required")
        self.client = httpx.Client(
            base_url=self.base_url,
            headers={
                "Authorization": f"Bearer {self.token}",
                "Accept": "application/vnd.github+json",
                "X-GitHub-Api-Version": "2022-11-28",
            },
            timeout=30.0,
        )

    def get_repo(self, owner: str, repo: str) -> dict[str, Any]:
        """Fetch repository information."""
        response = self.client.get(f"/repos/{owner}/{repo}")
        response.raise_for_status()
        return response.json()

    def list_webhooks(self, owner: str, repo: str) -> list[dict[str, Any]]:
        """List repository webhooks."""
        response = self.client.get(f"/repos/{owner}/{repo}/hooks")
        response.raise_for_status()
        return response.json()

    def create_webhook(
        self,
        owner: str,
        repo: str,
        url: str,
        secret: str | None = None,
        events: list[str] | None = None,
    ) -> dict[str, Any]:
        """Create a repository webhook."""
        resolved_secret = secret or secrets.token_hex(32)
        payload = {
            "name": "web",
            "active": True,
            "events": events or ["push"],
            "config": {
                "url": url,
                "content_type": "json",
                "secret": resolved_secret,
                "insecure_ssl": "0",
            },
        }
        response = self.client.post(f"/repos/{owner}/{repo}/hooks", json=payload)
        response.raise_for_status()
        result = response.json()
        result["_secret"] = resolved_secret
        return result

    def delete_webhook(self, owner: str, repo: str, hook_id: int) -> None:
        """Delete a repository webhook."""
        response = self.client.delete(f"/repos/{owner}/{repo}/hooks/{hook_id}")
        response.raise_for_status()

    def list_deploy_keys(self, owner: str, repo: str) -> list[dict[str, Any]]:
        """List deploy keys for a repository."""
        response = self.client.get(f"/repos/{owner}/{repo}/keys")
        response.raise_for_status()
        return response.json()

    def create_deploy_key(
        self,
        owner: str,
        repo: str,
        title: str,
        key: str,
        read_only: bool = True,
    ) -> dict[str, Any]:
        """Create a deploy key for a repository."""
        response = self.client.post(
            f"/repos/{owner}/{repo}/keys",
            json={"title": title, "key": key, "read_only": read_only},
        )
        response.raise_for_status()
        return response.json()

    def delete_deploy_key(self, owner: str, repo: str, key_id: int) -> None:
        """Delete a deploy key."""
        response = self.client.delete(f"/repos/{owner}/{repo}/keys/{key_id}")
        response.raise_for_status()
