"""Resend Email API provider."""

from typing import Any

import resend

from vanty_cli.config import get_settings


def get_resend_client() -> None:
    """Initialize the global Resend client."""
    settings = get_settings()
    if not settings.resend_api_key:
        raise ValueError("RESEND_API_KEY is required")
    resend.api_key = settings.resend_api_key


class ResendProvider:
    """Wrapper for Resend operations."""

    def __init__(self) -> None:
        get_resend_client()

    def list_domains(self) -> list[dict[str, Any]]:
        """List all domains."""
        response = resend.Domains.list()
        return response.get("data", [])

    def get_domain(self, domain_id: str) -> dict[str, Any]:
        """Get domain details."""
        return resend.Domains.get(domain_id)

    def create_domain(self, name: str, region: str = "us-east-1") -> dict[str, Any]:
        """Create a sending domain."""
        return resend.Domains.create({"name": name, "region": region})

    def verify_domain(self, domain_id: str) -> dict[str, Any]:
        """Trigger domain verification."""
        return resend.Domains.verify(domain_id)

    def delete_domain(self, domain_id: str) -> bool:
        """Delete a domain."""
        resend.Domains.remove(domain_id)
        return True

    def update_domain(
        self,
        domain_id: str,
        open_tracking: bool | None = None,
        click_tracking: bool | None = None,
        tls: str | None = None,
    ) -> dict[str, Any]:
        """Update domain settings."""
        payload: dict[str, Any] = {}
        if open_tracking is not None:
            payload["open_tracking"] = open_tracking
        if click_tracking is not None:
            payload["click_tracking"] = click_tracking
        if tls is not None:
            payload["tls"] = tls
        return resend.Domains.update(domain_id, payload)

    def list_api_keys(self) -> list[dict[str, Any]]:
        """List API keys."""
        response = resend.ApiKeys.list()
        return response.get("data", [])

    def create_api_key(
        self,
        name: str,
        permission: str = "full_access",
        domain_id: str | None = None,
    ) -> dict[str, Any]:
        """Create an API key."""
        payload: dict[str, Any] = {"name": name, "permission": permission}
        if domain_id:
            payload["domain_id"] = domain_id
        return resend.ApiKeys.create(payload)

    def delete_api_key(self, api_key_id: str) -> bool:
        """Delete an API key."""
        resend.ApiKeys.remove(api_key_id)
        return True

    def send_test_email(
        self,
        from_email: str,
        to_email: str,
        subject: str = "Test Email from Vanty CLI",
    ) -> dict[str, Any]:
        """Send a test email."""
        return resend.Emails.send(
            {
                "from": from_email,
                "to": to_email,
                "subject": subject,
                "html": "<p>This is a test email sent from the Vanty CLI.</p>",
            }
        )
