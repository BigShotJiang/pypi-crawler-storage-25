"""Hetzner Cloud SDK wrapper."""

import base64
import hashlib
import time
from pathlib import Path

import paramiko
from hcloud import Client
from hcloud.firewalls import FirewallRule
from hcloud.images import Image
from hcloud.load_balancer_types import LoadBalancerType
from hcloud.load_balancers import (
    LoadBalancer,
    LoadBalancerAlgorithm,
    LoadBalancerService,
    LoadBalancerServiceHttp,
    LoadBalancerTarget,
)
from hcloud.locations import Location
from hcloud.server_types import ServerType
from hcloud.servers import Server
from hcloud.ssh_keys import SSHKey
from hcloud.volumes import Volume

from vanty_cli.config import get_settings


class HetznerProvider:
    """Wrapper for Hetzner Cloud operations."""

    def __init__(self, token: str | None = None) -> None:
        settings = get_settings()
        self.token = token or settings.hetzner_api_token
        if not self.token:
            raise ValueError("HETZNER_API_TOKEN is required")
        self.client = Client(token=self.token)

    def list_ssh_keys(self) -> list[dict[str, str | int]]:
        """List SSH keys."""
        return [
            {"id": key.id, "name": key.name, "fingerprint": key.fingerprint}
            for key in self.client.ssh_keys.get_all()
        ]

    def get_or_create_ssh_key(self, name: str, public_key: str) -> SSHKey:
        """Get an existing SSH key or create one."""
        existing = self.client.ssh_keys.get_by_name(name)
        if existing:
            return existing

        key_parts = public_key.split()
        if len(key_parts) >= 2:
            key_data = base64.b64decode(key_parts[1])
            fingerprint = hashlib.md5(key_data).hexdigest()
            fingerprint = ":".join(fingerprint[index : index + 2] for index in range(0, 32, 2))
            for key in self.client.ssh_keys.get_all():
                if key.fingerprint == fingerprint:
                    return key

        return self.client.ssh_keys.create(name=name, public_key=public_key)

    def get_or_create_firewall(self, name: str):
        """Get or create a basic web firewall."""
        existing = self.client.firewalls.get_by_name(name)
        if existing:
            return existing
        rules = [
            FirewallRule(direction="in", protocol="tcp", port="22", source_ips=["0.0.0.0/0", "::/0"]),
            FirewallRule(direction="in", protocol="tcp", port="80", source_ips=["0.0.0.0/0", "::/0"]),
            FirewallRule(direction="in", protocol="tcp", port="443", source_ips=["0.0.0.0/0", "::/0"]),
        ]
        return self.client.firewalls.create(name=name, rules=rules)

    def list_locations(self) -> list[dict[str, str | int]]:
        """List datacenter locations."""
        return [
            {
                "id": location.id,
                "name": location.name,
                "description": location.description,
                "city": location.city,
                "country": location.country,
            }
            for location in self.client.locations.get_all()
        ]

    def list_server_types(self) -> list[dict[str, str | int | float]]:
        """List server types."""
        return [
            {
                "id": server_type.id,
                "name": server_type.name,
                "description": server_type.description,
                "cores": server_type.cores,
                "memory": server_type.memory,
                "disk": server_type.disk,
            }
            for server_type in self.client.server_types.get_all()
        ]

    def list_servers(self, label_selector: str | None = None) -> list[Server]:
        """List servers."""
        return self.client.servers.get_all(label_selector=label_selector)

    def get_server(self, name: str) -> Server | None:
        """Get a server by name."""
        return self.client.servers.get_by_name(name)

    def create_server(
        self,
        name: str,
        server_type: str,
        image: str,
        location: str,
        ssh_keys: list[SSHKey],
        firewalls: list,
        labels: dict[str, str],
        user_data: str,
    ) -> Server:
        """Create a server."""
        response = self.client.servers.create(
            name=name,
            server_type=ServerType(name=server_type),
            image=Image(name=image),
            location=Location(name=location),
            ssh_keys=ssh_keys,
            firewalls=firewalls,
            labels=labels,
            user_data=user_data,
        )
        return response.server

    def delete_server(self, server: Server) -> None:
        """Delete a server."""
        self.client.servers.delete(server)

    def create_volume(self, name: str, size: int, location: str, server: Server | None = None) -> Volume:
        """Create a volume."""
        response = self.client.volumes.create(
            name=name,
            size=size,
            location=Location(name=location),
            server=server,
            format="ext4",
        )
        return response.volume

    def list_load_balancers(self) -> list[LoadBalancer]:
        """List load balancers."""
        return self.client.load_balancers.get_all()

    def get_load_balancer(self, name: str) -> LoadBalancer | None:
        """Get a load balancer by name."""
        return self.client.load_balancers.get_by_name(name)

    def create_load_balancer(
        self,
        name: str,
        lb_type: str,
        location: str,
        algorithm: str = "round_robin",
    ) -> LoadBalancer:
        """Create a load balancer."""
        response = self.client.load_balancers.create(
            name=name,
            load_balancer_type=LoadBalancerType(name=lb_type),
            location=Location(name=location),
            algorithm=LoadBalancerAlgorithm(type=algorithm),
        )
        return response.load_balancer

    def add_lb_service(
        self,
        lb: LoadBalancer,
        protocol: str,
        listen_port: int,
        destination_port: int,
        health_check_path: str = "/health/",
    ) -> None:
        """Add a load balancer service."""
        service = LoadBalancerService(
            protocol=protocol,
            listen_port=listen_port,
            destination_port=destination_port,
            http=LoadBalancerServiceHttp(
                cookie_name="SERVERID",
                cookie_lifetime=300,
                sticky_sessions=True,
            )
            if protocol in {"http", "https"}
            else None,
        )
        self.client.load_balancers.add_service(lb, service)

    def add_lb_target(self, lb: LoadBalancer, server: Server) -> None:
        """Add a server target to a load balancer."""
        target = LoadBalancerTarget(type="server", server=server, use_private_ip=False)
        self.client.load_balancers.add_target(lb, target)

    def delete_load_balancer(self, lb: LoadBalancer) -> None:
        """Delete a load balancer."""
        self.client.load_balancers.delete(lb)

    def get_cloud_init_script(self, repo_url: str = "", branch: str = "main", github_token: str = "") -> str:
        """Load the bundled cloud-init file with template substitution."""
        script_path = Path(__file__).resolve().parents[3] / "ops" / "cloud-init.yaml"
        content = script_path.read_text()
        resolved_repo_url = repo_url
        if github_token and repo_url.startswith("https://github.com/"):
            resolved_repo_url = repo_url.replace(
                "https://github.com/",
                f"https://{github_token}@github.com/",
            )
        return content.replace("{{REPO_URL}}", resolved_repo_url).replace("{{BRANCH}}", branch)

    def wait_for_cloud_init(self, ip: str, ssh_key_path: str, timeout: int = 600) -> bool:
        """Wait until the cloud-init completion marker exists."""
        start = time.time()
        while time.time() - start < timeout:
            try:
                ssh = paramiko.SSHClient()
                ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                ssh.connect(ip, username="root", key_filename=ssh_key_path, timeout=10)
                _, stdout, _ = ssh.exec_command("test -f /opt/app/.cloud-init-complete && echo ready")
                if "ready" in stdout.read().decode():
                    ssh.close()
                    return True
                ssh.close()
            except Exception:
                pass
            time.sleep(15)
        return False

    def copy_file_to_server(self, ip: str, local_path: str, remote_path: str, ssh_key_path: str) -> None:
        """Copy a file to the server over SFTP."""
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(ip, username="root", key_filename=ssh_key_path)
        sftp = ssh.open_sftp()
        sftp.put(local_path, remote_path)
        sftp.close()
        ssh.close()

    def run_ssh_command(self, ip: str, command: str, ssh_key_path: str) -> tuple[str, str]:
        """Run an SSH command and return stdout/stderr."""
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(ip, username="root", key_filename=ssh_key_path)
        _, stdout, stderr = ssh.exec_command(command)
        output = stdout.read().decode()
        error = stderr.read().decode()
        ssh.close()
        return output, error
