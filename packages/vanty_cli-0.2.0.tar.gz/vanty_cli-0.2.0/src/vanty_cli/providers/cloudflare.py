"""Cloudflare SDK wrapper."""

import contextlib
from typing import Any

import cloudflare

from vanty_cli.config import get_settings


class CloudflareProvider:
    """Wrapper for Cloudflare DNS, zones, R2, and token operations."""

    def __init__(self, token: str | None = None) -> None:
        settings = get_settings()
        self.token = token or settings.cloudflare_api_token
        self.account_id = settings.cloudflare_account_id
        if not self.token:
            raise ValueError("CF_API_TOKEN or CLOUDFLARE_API_TOKEN is required")
        self.client = cloudflare.Cloudflare(api_token=self.token)

    def _to_dict(self, obj: Any) -> dict[str, Any]:
        """Convert SDK responses to plain dicts."""
        if hasattr(obj, "to_dict"):
            return obj.to_dict()
        if hasattr(obj, "model_dump"):
            return obj.model_dump()
        if hasattr(obj, "__dict__"):
            return {key: value for key, value in obj.__dict__.items() if not key.startswith("_")}
        if isinstance(obj, dict):
            return obj
        return {}

    def get_zone(self, domain: str) -> dict[str, Any] | None:
        """Get a zone by domain name."""
        zones = self.client.zones.list(name=domain)
        if zones.result:
            return self._to_dict(zones.result[0])
        return None

    def list_zones(self) -> list[dict[str, Any]]:
        """List all zones."""
        zones = self.client.zones.list()
        return [self._to_dict(zone) for zone in (zones.result or [])]

    def create_zone(self, domain: str, jump_start: bool = True) -> dict[str, Any]:
        """Create a Cloudflare zone."""
        if not self.account_id:
            raise ValueError("CF_ACCOUNT_ID or CLOUDFLARE_ACCOUNT_ID is required")
        result = self.client.zones.create(
            name=domain,
            account={"id": self.account_id},
            jump_start=jump_start,
        )
        return self._to_dict(result)

    def delete_zone(self, zone_id: str) -> None:
        """Delete a Cloudflare zone."""
        self.client.zones.delete(zone_id=zone_id)

    def check_zone_activation(self, zone_id: str) -> dict[str, Any]:
        """Trigger an activation check for a zone."""
        result = self.client.zones.activation_check.trigger(zone_id=zone_id)
        return self._to_dict(result)

    def list_dns_records(self, zone_id: str) -> list[dict[str, Any]]:
        """List DNS records in a zone."""
        records = self.client.dns.records.list(zone_id=zone_id)
        return [self._to_dict(record) for record in (records.result or [])]

    def get_dns_record(self, zone_id: str, record_type: str, name: str) -> dict[str, Any] | None:
        """Get a specific DNS record."""
        records = self.client.dns.records.list(zone_id=zone_id, name=name, type=record_type)
        if records.result:
            return self._to_dict(records.result[0])
        return None

    def upsert_dns_record(
        self,
        zone_id: str,
        record_type: str,
        name: str,
        content: str,
        proxied: bool = True,
        ttl: int = 1,
    ) -> dict[str, Any]:
        """Create or update a DNS record."""
        existing = self.get_dns_record(zone_id, record_type, name)
        if existing:
            result = self.client.dns.records.update(
                zone_id=zone_id,
                dns_record_id=existing["id"],
                type=record_type,
                name=name,
                content=content,
                proxied=proxied,
                ttl=ttl,
            )
        else:
            result = self.client.dns.records.create(
                zone_id=zone_id,
                type=record_type,
                name=name,
                content=content,
                proxied=proxied,
                ttl=ttl,
            )
        return self._to_dict(result)

    def delete_dns_record(self, zone_id: str, record_id: str) -> None:
        """Delete a DNS record."""
        self.client.dns.records.delete(zone_id=zone_id, dns_record_id=record_id)

    def set_ssl_mode(self, zone_id: str, mode: str = "full") -> None:
        """Set SSL mode when the token has zone settings permissions."""
        with contextlib.suppress(Exception):
            self.client.zones.settings.edit(zone_id=zone_id, setting_id="ssl", value=mode)

    def get_ssl_mode(self, zone_id: str) -> str | None:
        """Get SSL mode when the token has zone settings permissions."""
        try:
            result = self.client.zones.settings.get(zone_id=zone_id, setting_id="ssl")
        except Exception:
            return None
        return result.value

    def list_r2_buckets(self) -> list[dict[str, Any]]:
        """List R2 buckets."""
        if not self.account_id:
            raise ValueError("CF_ACCOUNT_ID or CLOUDFLARE_ACCOUNT_ID is required")
        buckets = self.client.r2.buckets.list(account_id=self.account_id)
        return [self._to_dict(bucket) for bucket in (buckets.buckets or [])]

    def create_r2_bucket(self, name: str, location: str = "wnam") -> dict[str, Any]:
        """Create an R2 bucket."""
        if not self.account_id:
            raise ValueError("CF_ACCOUNT_ID or CLOUDFLARE_ACCOUNT_ID is required")
        result = self.client.r2.buckets.create(
            account_id=self.account_id,
            name=name,
            location_hint=location,
        )
        return self._to_dict(result)

    def delete_r2_bucket(self, name: str) -> None:
        """Delete an R2 bucket."""
        if not self.account_id:
            raise ValueError("CF_ACCOUNT_ID or CLOUDFLARE_ACCOUNT_ID is required")
        self.client.r2.buckets.delete(account_id=self.account_id, bucket_name=name)

    def get_r2_bucket_domains(self, bucket_name: str) -> dict[str, Any]:
        """Get custom domains for an R2 bucket."""
        if not self.account_id:
            raise ValueError("CF_ACCOUNT_ID or CLOUDFLARE_ACCOUNT_ID is required")
        custom_domains = self.client.r2.buckets.domains.custom.list(
            account_id=self.account_id,
            bucket_name=bucket_name,
        )
        return {
            "custom_domains": [self._to_dict(domain) for domain in (custom_domains.domains or [])],
        }

    def add_r2_bucket_domain(
        self,
        bucket_name: str,
        domain: str,
        zone_id: str,
        min_tls: str = "1.2",
    ) -> dict[str, Any]:
        """Add a custom domain to an R2 bucket."""
        if not self.account_id:
            raise ValueError("CF_ACCOUNT_ID or CLOUDFLARE_ACCOUNT_ID is required")
        result = self.client.r2.buckets.domains.custom.create(
            account_id=self.account_id,
            bucket_name=bucket_name,
            domain=domain,
            zone_id=zone_id,
            min_tls=min_tls,
            enabled=True,
        )
        return self._to_dict(result)

    def remove_r2_bucket_domain(self, bucket_name: str, domain: str) -> None:
        """Remove a custom domain from an R2 bucket."""
        if not self.account_id:
            raise ValueError("CF_ACCOUNT_ID or CLOUDFLARE_ACCOUNT_ID is required")
        self.client.r2.buckets.domains.custom.delete(
            account_id=self.account_id,
            bucket_name=bucket_name,
            domain=domain,
        )

    def verify_api_token(self) -> dict[str, Any]:
        """Verify the currently configured API token."""
        result = self.client.user.tokens.verify()
        return self._to_dict(result)
