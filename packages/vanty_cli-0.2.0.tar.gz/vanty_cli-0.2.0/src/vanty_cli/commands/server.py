"""Hetzner server provisioning commands."""

import subprocess
from typing import Annotated

import typer
from rich.console import Console
from rich.table import Table

from vanty_cli.config import get_settings
from vanty_cli.providers.cloudflare import CloudflareProvider
from vanty_cli.providers.hetzner import HetznerProvider

app = typer.Typer(no_args_is_help=True)
console = Console()


def _success(message: str) -> None:
    console.print(f"[green]OK[/green] {message}")


def _error(message: str) -> None:
    console.print(f"[red]ERROR[/red] {message}")


def _info(message: str) -> None:
    console.print(f"[blue]INFO[/blue] {message}")


@app.command("provision")
def provision_server(
    name: Annotated[str, typer.Option("--name", "-n", help="Server name")],
    domain: Annotated[str, typer.Option("--domain", "-d", help="Domain for the server")],
    repo: Annotated[str, typer.Option("--repo", "-r", help="GitHub repo URL to clone")],
    branch: Annotated[str, typer.Option("--branch", "-b", help="Git branch")] = "main",
    env_file: Annotated[str | None, typer.Option("--env-file", "-e", help="Path to .env file")] = None,
    server_type: Annotated[str | None, typer.Option("--type", "-t", help="Server type")] = None,
    location: Annotated[str | None, typer.Option("--location", "-l", help="Datacenter location")] = None,
    image: Annotated[str | None, typer.Option("--image", help="OS image")] = None,
    wait: Annotated[bool, typer.Option("--wait/--no-wait", help="Wait for cloud-init to complete")] = True,
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Preview changes")] = False,
) -> None:
    """Provision a server with DNS and an initial Docker-ready setup."""
    settings = get_settings()
    resolved_server_type = server_type or settings.default_server_type
    resolved_location = location or settings.default_location
    resolved_image = image or settings.default_image

    domain_parts = domain.split(".")
    zone_name = ".".join(domain_parts[-2:]) if len(domain_parts) > 2 else domain

    if dry_run:
        console.print("[dim][DRY RUN][/dim] Provision request")
        console.print(f"  server: {name} ({resolved_server_type} in {resolved_location})")
        console.print(f"  domain: {domain} (zone: {zone_name})")
        console.print(f"  repo:   {repo} ({branch})")
        console.print(f"  env:    {env_file or 'not provided'}")
        return

    hetzner = HetznerProvider()
    cloudflare = CloudflareProvider()

    console.print("\n[bold]Step 1: Creating server[/bold]")
    ssh_public_key = settings.ssh_public_key_path.read_text().strip()
    ssh_key = hetzner.get_or_create_ssh_key(f"vanty-{name}", ssh_public_key)
    firewall_result = hetzner.get_or_create_firewall(f"fw-{name}")
    firewall = getattr(firewall_result, "firewall", firewall_result)
    cloud_init = hetzner.get_cloud_init_script(repo_url=repo, branch=branch, github_token=settings.github_token)
    server = hetzner.create_server(
        name=name,
        server_type=resolved_server_type,
        image=resolved_image,
        location=resolved_location,
        ssh_keys=[ssh_key],
        firewalls=[firewall],
        labels={"managed-by": "vanty-cli"},
        user_data=cloud_init,
    )
    server_ip = server.public_net.ipv4.ip
    _success(f"Created server {name} ({server_ip})")

    console.print("\n[bold]Step 2: Configuring DNS[/bold]")
    zone = cloudflare.get_zone(zone_name)
    if not zone:
        _error(f"Zone '{zone_name}' not found in Cloudflare")
        raise typer.Exit(1)
    cloudflare.upsert_dns_record(
        zone_id=zone["id"],
        record_type="A",
        name=domain,
        content=server_ip,
        proxied=True,
    )
    _success(f"Configured DNS {domain} -> {server_ip}")

    if wait:
        console.print("\n[bold]Step 3: Waiting for cloud-init[/bold]")
        _info("This usually takes 3-5 minutes.")
        with console.status("Waiting for server setup..."):
            ready = hetzner.wait_for_cloud_init(server_ip, str(settings.ssh_key_path), timeout=600)
        if not ready:
            _error(f"Cloud-init timed out. Check logs with: ssh root@{server_ip}")
            raise typer.Exit(1)
        _success("Cloud-init completed")

        if env_file:
            console.print("\n[bold]Step 4: Copying environment file[/bold]")
            hetzner.copy_file_to_server(server_ip, env_file, "/opt/app/.env", str(settings.ssh_key_path))
            _success(f"Copied {env_file} to /opt/app/.env")

        console.print("\n[bold]Step 5: Verifying repository[/bold]")
        output, _ = hetzner.run_ssh_command(
            server_ip,
            "test -f /opt/app/docker-compose.prod.yml && echo OK || echo MISSING",
            str(settings.ssh_key_path),
        )
        if "MISSING" in output:
            _error("Repository clone is incomplete. This is expected for private repositories without a deploy key.")
            console.print("Add a deploy key, clone the repo over SSH, then run `vanty deploy full`.")
            raise typer.Exit(1)
        _success("Repository is present")

        console.print("\n[bold]Step 6: Starting application[/bold]")
        _output, error = hetzner.run_ssh_command(
            server_ip,
            "cd /opt/app && docker compose -f docker-compose.prod.yml up -d",
            str(settings.ssh_key_path),
        )
        if error and "error" in error.lower():
            _error(f"Failed to start containers: {error}")
        else:
            _success("Containers started")

        console.print("\n[bold]Step 7: Running migrations[/bold]")
        migrate_command = (
            "cd /opt/app && docker compose -f docker-compose.prod.yml "
            "exec -T django python manage.py migrate --noinput"
        )
        _output, error = hetzner.run_ssh_command(
            server_ip,
            migrate_command,
            str(settings.ssh_key_path),
        )
        if error and "error" in error.lower():
            _error(f"Migrations failed: {error}")
        else:
            _success("Migrations completed")

    console.print("\n[bold green]Server provisioned successfully[/bold green]")
    console.print(f"server: {name}")
    console.print(f"ip:     {server_ip}")
    console.print(f"url:    https://{domain}")
    console.print(f"ssh:    ssh root@{server_ip}")
    if not wait:
        console.print("[yellow]Run `vanty deploy push` when the server is ready.[/yellow]")


@app.command("list")
def list_servers(
    label: Annotated[str | None, typer.Option("--label", "-l", help="Optional label selector")] = None,
) -> None:
    """List Hetzner servers."""
    hetzner = HetznerProvider()
    servers = hetzner.list_servers(label_selector=label)
    if not servers:
        _info("No servers found")
        return
    table = Table(title="Hetzner Servers")
    table.add_column("Name")
    table.add_column("Type")
    table.add_column("Status")
    table.add_column("IP")
    table.add_column("Location")
    for server in servers:
        table.add_row(
            server.name,
            server.server_type.name,
            server.status,
            server.public_net.ipv4.ip if server.public_net.ipv4 else "N/A",
            server.datacenter.name,
        )
    console.print(table)


@app.command("destroy")
def destroy_server(
    name: Annotated[str, typer.Option("--name", "-n", help="Server name")],
    confirm: Annotated[bool, typer.Option("--yes", "-y", help="Skip confirmation")] = False,
) -> None:
    """Destroy a server."""
    if not confirm and not typer.confirm(f"Destroy server '{name}'?"):
        raise typer.Abort()
    hetzner = HetznerProvider()
    server = hetzner.get_server(name)
    if not server:
        _error(f"Server '{name}' not found")
        raise typer.Exit(1)
    hetzner.delete_server(server)
    _success(f"Destroyed server '{name}'")


@app.command("ssh")
def ssh_to_server(
    name: Annotated[str, typer.Option("--name", "-n", help="Server name")],
    user: Annotated[str, typer.Option("--user", "-u", help="SSH user")] = "root",
    command: Annotated[str | None, typer.Option("--command", "-c", help="Command to run")] = None,
) -> None:
    """Open an SSH session or run a single command."""
    settings = get_settings()
    hetzner = HetznerProvider()
    server = hetzner.get_server(name)
    if not server:
        _error(f"Server '{name}' not found")
        raise typer.Exit(1)
    ssh_args = [
        "ssh",
        "-i",
        str(settings.ssh_key_path),
        "-o",
        "StrictHostKeyChecking=accept-new",
        f"{user}@{server.public_net.ipv4.ip}",
    ]
    if command:
        ssh_args.append(command)
    subprocess.run(ssh_args, check=False)


@app.command("ip")
def get_server_ip(
    name: Annotated[str, typer.Option("--name", "-n", help="Server name")],
) -> None:
    """Print a server IP address."""
    hetzner = HetznerProvider()
    server = hetzner.get_server(name)
    if not server:
        _error(f"Server '{name}' not found")
        raise typer.Exit(1)
    console.print(server.public_net.ipv4.ip)


@app.command("locations")
def list_locations() -> None:
    """List available datacenter locations."""
    hetzner = HetznerProvider()
    table = Table(title="Datacenter Locations")
    table.add_column("Name")
    table.add_column("City")
    table.add_column("Country")
    for location in hetzner.list_locations():
        table.add_row(location["name"], str(location.get("city", "N/A")), str(location.get("country", "N/A")))
    console.print(table)


@app.command("types")
def list_server_types() -> None:
    """List available server types."""
    hetzner = HetznerProvider()
    table = Table(title="Server Types")
    table.add_column("Name")
    table.add_column("Cores")
    table.add_column("Memory")
    table.add_column("Disk")
    for server_type in hetzner.list_server_types():
        table.add_row(
            str(server_type["name"]),
            str(server_type["cores"]),
            str(server_type["memory"]),
            str(server_type["disk"]),
        )
    console.print(table)
