"""Load balancer management commands."""

from typing import Annotated

import typer
from rich.console import Console
from rich.table import Table

from vanty_cli.config import get_settings
from vanty_cli.providers.cloudflare import CloudflareProvider
from vanty_cli.providers.hetzner import HetznerProvider

app = typer.Typer(no_args_is_help=True)
console = Console()


def _success(message: str) -> None:
    console.print(f"[green]OK[/green] {message}")


def _error(message: str) -> None:
    console.print(f"[red]ERROR[/red] {message}")


def _info(message: str) -> None:
    console.print(f"[blue]INFO[/blue] {message}")


def _dry_run(message: str) -> None:
    console.print(f"[dim][DRY RUN][/dim] {message}")


@app.command("create")
def create_load_balancer(
    name: Annotated[str, typer.Option("--name", "-n", help="Load balancer name")],
    backends: Annotated[str, typer.Option("--backends", "-b", help="Comma-separated server names")],
    lb_type: Annotated[str, typer.Option("--type", "-t", help="Load balancer type")] = "lb11",
    location: Annotated[str | None, typer.Option("--location", "-l")] = None,
    algorithm: Annotated[str, typer.Option("--algorithm", help="Load balancing algorithm")] = "round_robin",
    health_check_path: Annotated[str, typer.Option("--health-path")] = "/health/",
    dry_run: Annotated[bool, typer.Option("--dry-run")] = False,
) -> None:
    """Create a Hetzner load balancer and attach backend servers."""
    settings = get_settings()
    hetzner = HetznerProvider()
    resolved_location = location or settings.default_location
    backend_names = [backend.strip() for backend in backends.split(",")]
    backend_servers = []
    for backend_name in backend_names:
        server = hetzner.get_server(backend_name)
        if not server:
            _error(f"Server '{backend_name}' not found")
            raise typer.Exit(1)
        backend_servers.append(server)

    if dry_run:
        _dry_run(f"Would create load balancer {name}")
        console.print(f"  type:      {lb_type}")
        console.print(f"  location:  {resolved_location}")
        console.print(f"  algorithm: {algorithm}")
        console.print(f"  backends:  {', '.join(backend_names)}")
        return

    with console.status(f"Creating load balancer '{name}'..."):
        lb = hetzner.create_load_balancer(
            name=name,
            lb_type=lb_type,
            location=resolved_location,
            algorithm=algorithm,
        )
        hetzner.add_lb_service(
            lb=lb,
            protocol="http",
            listen_port=80,
            destination_port=80,
            health_check_path=health_check_path,
        )
        hetzner.add_lb_service(
            lb=lb,
            protocol="https",
            listen_port=443,
            destination_port=80,
            health_check_path=health_check_path,
        )
        for server in backend_servers:
            hetzner.add_lb_target(lb, server)
            _info(f"Added backend: {server.name}")

    _success(f"Load balancer ready: {lb.name}")
    console.print(f"[bold]Public IP:[/bold] {lb.public_net.ipv4.ip}")


@app.command("list")
def list_load_balancers() -> None:
    """List load balancers."""
    hetzner = HetznerProvider()
    load_balancers = hetzner.list_load_balancers()
    if not load_balancers:
        _info("No load balancers found")
        return
    table = Table(title="Load Balancers")
    table.add_column("Name")
    table.add_column("Type")
    table.add_column("IP")
    table.add_column("Targets")
    table.add_column("Algorithm")
    for load_balancer in load_balancers:
        table.add_row(
            load_balancer.name,
            load_balancer.load_balancer_type.name,
            load_balancer.public_net.ipv4.ip if load_balancer.public_net.ipv4 else "N/A",
            str(len(load_balancer.targets) if load_balancer.targets else 0),
            load_balancer.algorithm.type if load_balancer.algorithm else "N/A",
        )
    console.print(table)


@app.command("dns")
def setup_lb_dns(
    lb_name: Annotated[str, typer.Option("--lb", "-l", help="Load balancer name")],
    domain: Annotated[str, typer.Option("--domain", "-d", help="Domain name")],
    subdomain: Annotated[str | None, typer.Option("--subdomain", "-s")] = None,
    dry_run: Annotated[bool, typer.Option("--dry-run")] = False,
) -> None:
    """Point a domain or subdomain at a load balancer."""
    hetzner = HetznerProvider()
    cloudflare = CloudflareProvider()
    load_balancer = hetzner.get_load_balancer(lb_name)
    if not load_balancer:
        _error(f"Load balancer '{lb_name}' not found")
        raise typer.Exit(1)
    zone = cloudflare.get_zone(domain)
    if not zone:
        _error(f"Zone '{domain}' not found in Cloudflare")
        raise typer.Exit(1)
    record_name = f"{subdomain}.{domain}" if subdomain else domain
    load_balancer_ip = load_balancer.public_net.ipv4.ip
    if dry_run:
        _dry_run(f"Would create DNS {record_name} -> {load_balancer_ip}")
        return
    cloudflare.upsert_dns_record(zone["id"], "A", record_name, load_balancer_ip, proxied=True)
    _success(f"DNS configured: {record_name} -> {load_balancer_ip}")


@app.command("destroy")
def destroy_load_balancer(
    name: Annotated[str, typer.Option("--name", "-n", help="Load balancer name")],
    confirm: Annotated[bool, typer.Option("--yes", "-y")] = False,
) -> None:
    """Destroy a load balancer."""
    if not confirm and not typer.confirm(f"Destroy load balancer '{name}'?"):
        raise typer.Abort()
    hetzner = HetznerProvider()
    load_balancer = hetzner.get_load_balancer(name)
    if not load_balancer:
        _error(f"Load balancer '{name}' not found")
        raise typer.Exit(1)
    hetzner.delete_load_balancer(load_balancer)
    _success(f"Load balancer '{name}' destroyed")
