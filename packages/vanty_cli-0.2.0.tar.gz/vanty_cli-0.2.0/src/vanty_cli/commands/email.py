"""Resend email management commands."""

from typing import Annotated

import typer
from rich.console import Console
from rich.table import Table

from vanty_cli.providers.cloudflare import CloudflareProvider
from vanty_cli.providers.resend import ResendProvider

app = typer.Typer(help="Resend email management commands")
console = Console()


def _success(message: str) -> None:
    console.print(f"[green]OK[/green] {message}")


def _error(message: str) -> None:
    console.print(f"[red]ERROR[/red] {message}")


def _info(message: str) -> None:
    console.print(f"[blue]INFO[/blue] {message}")


domains_app = typer.Typer(no_args_is_help=True)
app.add_typer(domains_app, name="domains", help="Manage email domains")


@domains_app.command("list")
def list_domains() -> None:
    """List all Resend domains."""
    try:
        resend_provider = ResendProvider()
        domains = resend_provider.list_domains()
        if not domains:
            _info("No domains found")
            return
        table = Table(title="Resend Domains")
        table.add_column("Name", style="cyan")
        table.add_column("ID", style="dim")
        table.add_column("Status")
        table.add_column("Region")
        table.add_column("Created")
        for domain in domains:
            status = domain.get("status", "unknown")
            status_style = "green" if status == "verified" else "yellow"
            table.add_row(
                domain.get("name", "N/A"),
                f"{domain.get('id', 'N/A')[:12]}...",
                f"[{status_style}]{status}[/{status_style}]",
                domain.get("region", "N/A"),
                str(domain.get("created_at", "N/A"))[:10],
            )
        console.print(table)
    except Exception as exc:
        _error(f"Failed to list domains: {exc}")
        raise typer.Exit(1) from None


@domains_app.command("add")
def add_domain(
    name: Annotated[str, typer.Argument(help="Domain name, for example emails.example.com")],
    region: Annotated[str, typer.Option("--region", "-r", help="AWS region")] = "eu-west-1",
    setup_cloudflare: Annotated[
        bool,
        typer.Option("--cloudflare/--no-cloudflare", "-c", help="Auto-add DNS records to Cloudflare"),
    ] = False,
    zone: Annotated[str | None, typer.Option("--zone", "-z", help="Cloudflare zone name")] = None,
) -> None:
    """Add a new sending domain."""
    try:
        resend_provider = ResendProvider()
        with console.status(f"Creating domain '{name}'..."):
            result = resend_provider.create_domain(name, region)
        _success(f"Domain '{name}' created")
        domain_id = result.get("id")
        console.print(f"\n[bold]Domain ID:[/bold] {domain_id}")
        console.print(f"[bold]Status:[/bold] {result.get('status')}")

        records = result.get("records", [])
        if setup_cloudflare:
            console.print("\n[bold]Setting up Cloudflare DNS[/bold]")
            cloudflare = CloudflareProvider()
            zone_name = zone or ".".join(name.split(".")[-2:])
            cloudflare_zone = cloudflare.get_zone(zone_name)
            if not cloudflare_zone:
                _error(f"Zone '{zone_name}' not found in Cloudflare")
                _info("Add DNS manually or re-run with --zone")
                return
            zone_id = cloudflare_zone["id"]
            for record in records:
                record_type = record.get("type", "TXT")
                record_name = record.get("name")
                value = record.get("value")
                priority = record.get("priority")
                full_name = f"{record_name}.{zone_name}" if not record_name.endswith(zone_name) else record_name
                if record_type == "MX":
                    existing = cloudflare.get_dns_record(zone_id, "MX", full_name)
                    if existing:
                        cloudflare.client.dns.records.update(
                            zone_id=zone_id,
                            dns_record_id=existing["id"],
                            type="MX",
                            name=full_name,
                            content=value,
                            priority=priority or 10,
                            proxied=False,
                            ttl=1,
                        )
                    else:
                        cloudflare.client.dns.records.create(
                            zone_id=zone_id,
                            type="MX",
                            name=full_name,
                            content=value,
                            priority=priority or 10,
                            proxied=False,
                            ttl=1,
                        )
                else:
                    cloudflare.upsert_dns_record(
                        zone_id=zone_id,
                        record_type=record_type,
                        name=full_name,
                        content=value,
                        proxied=False,
                    )
                _success(f"{record_type}: {record_name}")
            console.print("\n[bold]Triggering verification[/bold]")
            resend_provider.verify_domain(domain_id)
            _info("Verification triggered. Check status in a few minutes.")
            _info(f"Run: vanty email domains info {domain_id}")
            return

        if records:
            console.print("\n[bold]Add these DNS records manually:[/bold]")
            table = Table()
            table.add_column("Type", style="cyan")
            table.add_column("Name")
            table.add_column("Value", style="dim")
            table.add_column("Priority")
            table.add_column("TTL")
            for record in records:
                value = record.get("value", "N/A")
                table.add_row(
                    record.get("record", record.get("type", "N/A")),
                    record.get("name", "N/A"),
                    value[:50] + "..." if len(value) > 50 else value,
                    str(record.get("priority", "-")),
                    str(record.get("ttl", "Auto")),
                )
            console.print(table)
            console.print(f"\n[dim]Or run: vanty email domains setup-dns {domain_id}[/dim]")
    except Exception as exc:
        _error(f"Failed to create domain: {exc}")
        raise typer.Exit(1) from None


@domains_app.command("info")
def domain_info(domain_id: Annotated[str, typer.Argument(help="Domain ID")]) -> None:
    """Show domain details and DNS records."""
    try:
        resend_provider = ResendProvider()
        domain = resend_provider.get_domain(domain_id)
        console.print(f"\n[bold]Domain:[/bold] {domain.get('name')}")
        console.print(f"[bold]ID:[/bold] {domain.get('id')}")
        console.print(f"[bold]Status:[/bold] {domain.get('status')}")
        console.print(f"[bold]Region:[/bold] {domain.get('region')}")
        console.print(f"[bold]Created:[/bold] {domain.get('created_at')}")
        records = domain.get("records", [])
        if records:
            console.print("\n[bold]DNS Records:[/bold]")
            table = Table()
            table.add_column("Type", style="cyan")
            table.add_column("Name")
            table.add_column("Value", style="dim", max_width=60)
            table.add_column("Status")
            for record in records:
                status = record.get("status", "pending")
                status_style = "green" if status == "verified" else "yellow"
                table.add_row(
                    record.get("record", record.get("type", "N/A")),
                    record.get("name", "N/A"),
                    record.get("value", "N/A"),
                    f"[{status_style}]{status}[/{status_style}]",
                )
            console.print(table)
    except Exception as exc:
        _error(f"Failed to get domain: {exc}")
        raise typer.Exit(1) from None


@domains_app.command("verify")
def verify_domain(domain_id: Annotated[str, typer.Argument(help="Domain ID")]) -> None:
    """Trigger domain verification."""
    try:
        resend_provider = ResendProvider()
        with console.status("Verifying domain..."):
            result = resend_provider.verify_domain(domain_id)
        status = result.get("status", "unknown")
        if status == "verified":
            _success("Domain verified successfully")
        else:
            _info(f"Verification triggered. Status: {status}")
    except Exception as exc:
        _error(f"Failed to verify domain: {exc}")
        raise typer.Exit(1) from None


@domains_app.command("remove")
def remove_domain(
    domain_id: Annotated[str, typer.Argument(help="Domain ID to remove")],
    confirm: Annotated[bool, typer.Option("--yes", "-y")] = False,
) -> None:
    """Remove a sending domain."""
    if not confirm and not typer.confirm(f"Remove domain {domain_id}?"):
        raise typer.Abort()
    try:
        resend_provider = ResendProvider()
        resend_provider.delete_domain(domain_id)
        _success(f"Domain {domain_id} removed")
    except Exception as exc:
        _error(f"Failed to remove domain: {exc}")
        raise typer.Exit(1) from None


@domains_app.command("update")
def update_domain(
    domain_id: Annotated[str, typer.Argument(help="Domain ID")],
    open_tracking: Annotated[
        bool | None,
        typer.Option("--open-tracking/--no-open-tracking", help="Enable open tracking"),
    ] = None,
    click_tracking: Annotated[
        bool | None,
        typer.Option("--click-tracking/--no-click-tracking", help="Enable click tracking"),
    ] = None,
    tls: Annotated[str | None, typer.Option("--tls", help="TLS mode")] = None,
) -> None:
    """Update domain settings."""
    if open_tracking is None and click_tracking is None and tls is None:
        _error("Specify at least one setting to update")
        raise typer.Exit(1)
    try:
        resend_provider = ResendProvider()
        result = resend_provider.update_domain(
            domain_id,
            open_tracking=open_tracking,
            click_tracking=click_tracking,
            tls=tls,
        )
        _success(f"Domain {result.get('id')} updated")
    except Exception as exc:
        _error(f"Failed to update domain: {exc}")
        raise typer.Exit(1) from None


keys_app = typer.Typer(no_args_is_help=True)
app.add_typer(keys_app, name="keys", help="Manage API keys")


@keys_app.command("list")
def list_api_keys() -> None:
    """List Resend API keys."""
    try:
        resend_provider = ResendProvider()
        keys = resend_provider.list_api_keys()
        if not keys:
            _info("No API keys found")
            return
        table = Table(title="Resend API Keys")
        table.add_column("Name", style="cyan")
        table.add_column("ID", style="dim")
        table.add_column("Created")
        for key in keys:
            table.add_row(
                key.get("name", "N/A"),
                key.get("id", "N/A"),
                str(key.get("created_at", "N/A"))[:10],
            )
        console.print(table)
    except Exception as exc:
        _error(f"Failed to list API keys: {exc}")
        raise typer.Exit(1) from None


@keys_app.command("create")
def create_api_key(
    name: Annotated[str, typer.Argument(help="API key name")],
    permission: Annotated[str, typer.Option("--permission", "-p", help="Permission level")] = "full_access",
    domain_id: Annotated[str | None, typer.Option("--domain", "-d", help="Restrict to domain ID")] = None,
) -> None:
    """Create a new Resend API key."""
    try:
        resend_provider = ResendProvider()
        with console.status(f"Creating API key '{name}'..."):
            result = resend_provider.create_api_key(name, permission, domain_id)
        _success(f"API key '{name}' created")
        console.print("\n[bold red]Save this key now. It is only shown once.[/bold red]")
        console.print(f"[cyan]{result.get('token')}[/cyan]")
        console.print(f"\n[dim]Key ID: {result.get('id')}[/dim]")
    except Exception as exc:
        _error(f"Failed to create API key: {exc}")
        raise typer.Exit(1) from None


@keys_app.command("remove")
def remove_api_key(
    key_id: Annotated[str, typer.Argument(help="API key ID to remove")],
    confirm: Annotated[bool, typer.Option("--yes", "-y")] = False,
) -> None:
    """Remove an API key."""
    if not confirm and not typer.confirm(f"Remove API key {key_id}?"):
        raise typer.Abort()
    try:
        resend_provider = ResendProvider()
        resend_provider.delete_api_key(key_id)
        _success(f"API key {key_id} removed")
    except Exception as exc:
        _error(f"Failed to remove API key: {exc}")
        raise typer.Exit(1) from None


@domains_app.command("setup-dns")
def setup_dns(
    domain_id: Annotated[str, typer.Argument(help="Resend domain ID")],
    zone: Annotated[str | None, typer.Option("--zone", "-z", help="Cloudflare zone")] = None,
    verify: Annotated[bool, typer.Option("--verify/--no-verify", help="Trigger verification")] = True,
) -> None:
    """Add Resend DNS records to Cloudflare and optionally verify the domain."""
    try:
        resend_provider = ResendProvider()
        cloudflare = CloudflareProvider()
        with console.status("Fetching domain info..."):
            domain = resend_provider.get_domain(domain_id)
        domain_name = domain.get("name")
        records = domain.get("records", [])
        if not records:
            _error("No DNS records found for this domain")
            raise typer.Exit(1)
        zone_name = zone or ".".join(domain_name.split(".")[-2:])
        cloudflare_zone = cloudflare.get_zone(zone_name)
        if not cloudflare_zone:
            _error(f"Zone '{zone_name}' not found in Cloudflare")
            raise typer.Exit(1)
        zone_id = cloudflare_zone["id"]
        console.print(f"\n[bold]Domain:[/bold] {domain_name}")
        console.print(f"[bold]Status:[/bold] {domain.get('status')}")
        console.print(f"[bold]Cloudflare Zone:[/bold] {zone_name} ({zone_id[:12]}...)")
        console.print("\n[bold]Adding DNS records[/bold]")
        for record in records:
            record_type = record.get("type", "TXT")
            record_name = record.get("name")
            value = record.get("value")
            priority = record.get("priority")
            full_name = f"{record_name}.{zone_name}" if not record_name.endswith(zone_name) else record_name
            if record_type == "MX":
                existing = cloudflare.get_dns_record(zone_id, "MX", full_name)
                if existing:
                    cloudflare.client.dns.records.update(
                        zone_id=zone_id,
                        dns_record_id=existing["id"],
                        type="MX",
                        name=full_name,
                        content=value,
                        priority=priority or 10,
                        proxied=False,
                        ttl=1,
                    )
                else:
                    cloudflare.client.dns.records.create(
                        zone_id=zone_id,
                        type="MX",
                        name=full_name,
                        content=value,
                        priority=priority or 10,
                        proxied=False,
                        ttl=1,
                    )
            else:
                cloudflare.upsert_dns_record(
                    zone_id=zone_id,
                    record_type=record_type,
                    name=full_name,
                    content=value,
                    proxied=False,
                )
            _success(f"{record_type}: {record_name}")
        if verify:
            console.print("\n[bold]Triggering verification[/bold]")
            with console.status("Verifying domain..."):
                resend_provider.verify_domain(domain_id)
            _info("Verification triggered. DNS propagation may take a few minutes.")
    except Exception as exc:
        _error(f"Failed to set up DNS: {exc}")
        raise typer.Exit(1) from None


@app.command("test")
def send_test_email(
    from_email: Annotated[str, typer.Option("--from", "-f", help="From email address")],
    to_email: Annotated[str, typer.Option("--to", "-t", help="To email address")],
    subject: Annotated[str, typer.Option("--subject", "-s")] = "Test Email from Vanty CLI",
) -> None:
    """Send a test email."""
    try:
        resend_provider = ResendProvider()
        with console.status(f"Sending test email to {to_email}..."):
            result = resend_provider.send_test_email(from_email, to_email, subject)
        _success("Test email sent")
        console.print(f"[bold]Email ID:[/bold] {result.get('id')}")
    except Exception as exc:
        _error(f"Failed to send test email: {exc}")
        raise typer.Exit(1) from None
