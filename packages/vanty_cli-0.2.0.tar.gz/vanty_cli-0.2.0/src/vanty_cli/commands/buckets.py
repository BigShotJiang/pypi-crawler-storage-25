"""Cloudflare bucket management commands (DNS + R2)."""

from typing import Annotated

import typer
from rich.console import Console
from rich.table import Table

from vanty_cli.providers.cloudflare import CloudflareProvider

app = typer.Typer(no_args_is_help=True)
console = Console()


def _success(message: str) -> None:
    console.print(f"[green]OK[/green] {message}")


def _error(message: str) -> None:
    console.print(f"[red]ERROR[/red] {message}")


def _info(message: str) -> None:
    console.print(f"[blue]INFO[/blue] {message}")


def _dry_run(message: str) -> None:
    console.print(f"[dim][DRY RUN][/dim] {message}")


@app.command("create")
def create_bucket(
    domain: Annotated[str, typer.Option("--domain", "-d", help="Domain name")],
    target_ip: Annotated[str | None, typer.Option("--target-ip", "-t", help="Target server IP")] = None,
    subdomain: Annotated[str | None, typer.Option("--subdomain", "-s", help="Optional subdomain")] = None,
    ssl_mode: Annotated[str, typer.Option("--ssl", help="SSL mode")] = "full",
    proxied: Annotated[bool, typer.Option("--proxied/--no-proxied", help="Enable Cloudflare proxy")] = True,
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Preview changes")] = False,
) -> None:
    """Create a Cloudflare zone/DNS bucket layout."""
    cloudflare = CloudflareProvider()
    record_name = f"{subdomain}.{domain}" if subdomain else domain
    with console.status(f"Creating bucket for {record_name}..."):
        zone = cloudflare.get_zone(domain)
        if not zone:
            _error(f"Zone '{domain}' not found. Add it to Cloudflare first.")
            raise typer.Exit(1)
        _info(f"Found zone: {zone['name']} ({zone['id']})")

        if target_ip:
            if dry_run:
                _dry_run(f"Would create/update A record {record_name} -> {target_ip}")
            else:
                cloudflare.upsert_dns_record(
                    zone_id=zone["id"],
                    record_type="A",
                    name=record_name,
                    content=target_ip,
                    proxied=proxied,
                )
                _success(f"DNS record {record_name} -> {target_ip}")

        if dry_run:
            _dry_run(f"Would set SSL mode to {ssl_mode}")
        else:
            cloudflare.set_ssl_mode(zone["id"], ssl_mode)
            _success(f"SSL mode set to {ssl_mode}")

    _success(f"Bucket ready: https://{record_name}")


@app.command("status")
def bucket_status(
    domain: Annotated[str, typer.Option("--domain", "-d", help="Domain name")],
) -> None:
    """Show zone status and DNS records."""
    cloudflare = CloudflareProvider()
    zone = cloudflare.get_zone(domain)
    if not zone:
        _error(f"Zone '{domain}' not found")
        raise typer.Exit(1)

    console.print(f"\n[bold]Zone:[/bold] {zone['name']}")
    console.print(f"[bold]Status:[/bold] {zone['status']}")
    console.print(f"[bold]Name Servers:[/bold] {', '.join(zone.get('name_servers', []))}")

    ssl_mode = cloudflare.get_ssl_mode(zone["id"])
    if ssl_mode:
        console.print(f"[bold]SSL Mode:[/bold] {ssl_mode}")
    else:
        console.print("[bold]SSL Mode:[/bold] unavailable for this token")

    records = cloudflare.list_dns_records(zone["id"])
    if records:
        console.print("\n[bold]DNS Records:[/bold]")
        for record in records:
            proxy_status = "proxied" if record.get("proxied") else "dns-only"
            console.print(f"  {proxy_status:8} {record['type']:6} {record['name']} -> {record['content']}")


@app.command("dns")
def upsert_dns(
    domain: Annotated[str, typer.Option("--domain", "-d", help="Domain name")],
    content: Annotated[str, typer.Option("--content", "-c", help="Record content")],
    record_type: Annotated[str, typer.Option("--type", "-t", help="Record type")] = "A",
    name: Annotated[str, typer.Option("--name", "-n", help="Record name")] = "@",
    proxied: Annotated[bool, typer.Option("--proxied/--no-proxied")] = True,
    dry_run: Annotated[bool, typer.Option("--dry-run")] = False,
) -> None:
    """Create or update a DNS record."""
    cloudflare = CloudflareProvider()
    zone = cloudflare.get_zone(domain)
    if not zone:
        _error(f"Zone '{domain}' not found")
        raise typer.Exit(1)

    record_name = domain if name == "@" else f"{name}.{domain}"
    if dry_run:
        _dry_run(f"Would upsert {record_type} record {record_name} -> {content}")
        return

    cloudflare.upsert_dns_record(zone["id"], record_type, record_name, content, proxied)
    _success(f"DNS record updated: {record_name}")


@app.command("delete")
def delete_bucket(
    domain: Annotated[str, typer.Option("--domain", "-d", help="Domain name")],
    confirm: Annotated[bool, typer.Option("--yes", "-y", help="Skip confirmation")] = False,
) -> None:
    """Delete all DNS records for a domain while keeping the zone."""
    if not confirm and not typer.confirm(f"Delete all DNS records for {domain}?"):
        raise typer.Abort()
    cloudflare = CloudflareProvider()
    zone = cloudflare.get_zone(domain)
    if not zone:
        _error(f"Zone '{domain}' not found")
        raise typer.Exit(1)
    for record in cloudflare.list_dns_records(zone["id"]):
        cloudflare.delete_dns_record(zone["id"], record["id"])
        _info(f"Deleted {record['name']}")
    _success(f"Bucket cleaned: {domain}")


zones_app = typer.Typer(no_args_is_help=True)
app.add_typer(zones_app, name="zones", help="Cloudflare zone/domain management")


@zones_app.command("list")
def list_zones() -> None:
    """List Cloudflare zones."""
    cloudflare = CloudflareProvider()
    zones = cloudflare.list_zones()
    if not zones:
        _info("No zones found")
        return
    table = Table(title="Cloudflare Zones")
    table.add_column("Name", style="cyan")
    table.add_column("ID", style="dim")
    table.add_column("Status")
    table.add_column("Name Servers")
    for zone in zones:
        name_servers = ", ".join(zone.get("name_servers", [])[:2])
        if len(zone.get("name_servers", [])) > 2:
            name_servers += "..."
        table.add_row(
            zone.get("name", "N/A"),
            f"{zone.get('id', 'N/A')[:12]}...",
            zone.get("status", "N/A"),
            name_servers,
        )
    console.print(table)


@zones_app.command("add")
def add_zone(
    domain: Annotated[str, typer.Argument(help="Domain to add")],
    jump_start: Annotated[bool, typer.Option("--jump-start/--no-jump-start", help="Scan existing DNS")] = True,
) -> None:
    """Add a domain to Cloudflare."""
    cloudflare = CloudflareProvider()
    existing = cloudflare.get_zone(domain)
    if existing:
        _info(f"Zone '{domain}' already exists ({existing['id']})")
        return
    with console.status(f"Adding zone '{domain}'..."):
        result = cloudflare.create_zone(domain, jump_start=jump_start)
    _success(f"Zone '{domain}' added")
    console.print(f"\n[bold]Zone ID:[/bold] {result.get('id')}")
    console.print(f"[bold]Status:[/bold] {result.get('status')}")
    name_servers = result.get("name_servers", [])
    if name_servers:
        console.print("\n[bold]Update your registrar with:[/bold]")
        for name_server in name_servers:
            console.print(f"  - {name_server}")


@zones_app.command("remove")
def remove_zone(
    domain: Annotated[str, typer.Argument(help="Domain to remove")],
    confirm: Annotated[bool, typer.Option("--yes", "-y", help="Skip confirmation")] = False,
) -> None:
    """Remove a Cloudflare zone."""
    cloudflare = CloudflareProvider()
    zone = cloudflare.get_zone(domain)
    if not zone:
        _error(f"Zone '{domain}' not found")
        raise typer.Exit(1)
    if not confirm and not typer.confirm(f"Remove zone '{domain}' from Cloudflare?"):
        raise typer.Abort()
    with console.status(f"Removing zone '{domain}'..."):
        cloudflare.delete_zone(zone["id"])
    _success(f"Zone '{domain}' removed")


@zones_app.command("check")
def check_zone(domain: Annotated[str, typer.Argument(help="Domain to check")]) -> None:
    """Trigger a zone activation check."""
    cloudflare = CloudflareProvider()
    zone = cloudflare.get_zone(domain)
    if not zone:
        _error(f"Zone '{domain}' not found")
        raise typer.Exit(1)
    with console.status(f"Checking activation for '{domain}'..."):
        cloudflare.check_zone_activation(zone["id"])
    _success(f"Activation check triggered for '{domain}'")


r2_app = typer.Typer(no_args_is_help=True)
app.add_typer(r2_app, name="r2", help="Cloudflare R2 storage management")


@r2_app.command("create")
def create_r2_bucket(
    name: Annotated[str, typer.Option("--name", "-n", help="Bucket name")],
    location: Annotated[str, typer.Option("--location", "-l", help="Location hint")] = "wnam",
    dry_run: Annotated[bool, typer.Option("--dry-run")] = False,
) -> None:
    """Create an R2 bucket."""
    cloudflare = CloudflareProvider()
    if dry_run:
        _dry_run(f"Would create R2 bucket {name} in {location}")
        return
    with console.status(f"Creating R2 bucket '{name}'..."):
        cloudflare.create_r2_bucket(name, location)
    _success(f"R2 bucket created: {name}")


@r2_app.command("list")
def list_r2_buckets() -> None:
    """List R2 buckets."""
    cloudflare = CloudflareProvider()
    buckets = cloudflare.list_r2_buckets()
    if not buckets:
        _info("No R2 buckets found")
        return
    table = Table(title="R2 Buckets")
    table.add_column("Name")
    table.add_column("Location")
    table.add_column("Created")
    for bucket in buckets:
        table.add_row(
            bucket.get("name", "N/A"),
            bucket.get("location", "N/A"),
            str(bucket.get("creation_date", "N/A")),
        )
    console.print(table)


@r2_app.command("delete")
def delete_r2_bucket(
    name: Annotated[str, typer.Option("--name", "-n", help="Bucket name")],
    confirm: Annotated[bool, typer.Option("--yes", "-y")] = False,
) -> None:
    """Delete an R2 bucket."""
    if not confirm and not typer.confirm(f"Delete R2 bucket '{name}'?"):
        raise typer.Abort()
    cloudflare = CloudflareProvider()
    cloudflare.delete_r2_bucket(name)
    _success(f"R2 bucket '{name}' deleted")


@r2_app.command("info")
def r2_bucket_info(
    name: Annotated[str, typer.Option("--name", "-n", help="Bucket name")],
) -> None:
    """Show R2 bucket details."""
    cloudflare = CloudflareProvider()
    bucket = cloudflare.client.r2.buckets.get(account_id=cloudflare.account_id, bucket_name=name)
    console.print(f"\n[bold]Bucket:[/bold] {bucket.name}")
    console.print(f"[bold]Location:[/bold] {bucket.location}")
    console.print(f"[bold]Storage Class:[/bold] {bucket.storage_class}")
    console.print(f"[bold]Created:[/bold] {bucket.creation_date}")
    domains = cloudflare.get_r2_bucket_domains(name)
    if domains["custom_domains"]:
        console.print("\n[bold]Custom Domains:[/bold]")
        for domain in domains["custom_domains"]:
            status = domain.get("status", {})
            ssl_status = status.get("ssl", "unknown") if isinstance(status, dict) else "unknown"
            console.print(f"  - {domain.get('domain')} (SSL: {ssl_status})")
    else:
        console.print("\n[dim]No custom domains configured[/dim]")
    console.print(f"\n[bold]S3 Endpoint:[/bold] https://{cloudflare.account_id}.r2.cloudflarestorage.com")
    console.print(f"[bold]Bucket URL:[/bold] https://{cloudflare.account_id}.r2.cloudflarestorage.com/{name}")


@r2_app.command("add-domain")
def r2_add_domain(
    bucket: Annotated[str, typer.Option("--bucket", "-b", help="Bucket name")],
    domain: Annotated[str, typer.Option("--domain", "-d", help="Custom domain")],
    zone: Annotated[str | None, typer.Option("--zone", "-z", help="Zone name")] = None,
) -> None:
    """Add a custom domain to an R2 bucket."""
    cloudflare = CloudflareProvider()
    zone_name = zone or ".".join(domain.split(".")[-2:])
    zone_info = cloudflare.get_zone(zone_name)
    if not zone_info:
        _error(f"Zone '{zone_name}' not found in Cloudflare")
        raise typer.Exit(1)
    with console.status(f"Adding domain '{domain}' to bucket '{bucket}'..."):
        cloudflare.add_r2_bucket_domain(bucket, domain, zone_info["id"])
    _success(f"Domain '{domain}' added to bucket '{bucket}'")


@r2_app.command("remove-domain")
def r2_remove_domain(
    bucket: Annotated[str, typer.Option("--bucket", "-b", help="Bucket name")],
    domain: Annotated[str, typer.Option("--domain", "-d", help="Custom domain")],
    confirm: Annotated[bool, typer.Option("--yes", "-y")] = False,
) -> None:
    """Remove a custom domain from an R2 bucket."""
    if not confirm and not typer.confirm(f"Remove domain '{domain}' from bucket '{bucket}'?"):
        raise typer.Abort()
    cloudflare = CloudflareProvider()
    cloudflare.remove_r2_bucket_domain(bucket, domain)
    _success(f"Domain '{domain}' removed from bucket '{bucket}'")


tokens_app = typer.Typer(no_args_is_help=True)
app.add_typer(tokens_app, name="tokens", help="Cloudflare API token helpers")


@tokens_app.command("verify")
def verify_token() -> None:
    """Verify the current Cloudflare API token."""
    cloudflare = CloudflareProvider()
    try:
        result = cloudflare.verify_api_token()
    except Exception as exc:
        _error(f"Token verification failed: {exc}")
        raise typer.Exit(1) from None
    _success(f"Token is valid (ID: {result.get('id', 'N/A')})")
    console.print(f"[bold]Status:[/bold] {result.get('status', 'N/A')}")


@tokens_app.command("list")
def list_tokens(
    scope: Annotated[str, typer.Option("--scope", "-s", help="Token scope: account, user, all")] = "all",
) -> None:
    """List account and/or user API tokens."""
    cloudflare = CloudflareProvider()

    if scope in {"account", "all"}:
        console.print("\n[bold]Account API Tokens[/bold]")
        try:
            tokens = cloudflare.client.accounts.tokens.list(account_id=cloudflare.account_id)
            if tokens.result:
                table = Table()
                table.add_column("Name", style="cyan")
                table.add_column("ID", style="dim")
                table.add_column("Status")
                for token in tokens.result:
                    table.add_row(token.name, f"{token.id[:16]}...", token.status)
                console.print(table)
            else:
                _info("No account tokens found")
        except Exception as exc:
            _error(f"Failed to list account tokens: {exc}")

    if scope in {"user", "all"}:
        console.print("\n[bold]User API Tokens[/bold]")
        try:
            tokens = cloudflare.client.user.tokens.list()
            if tokens.result:
                table = Table()
                table.add_column("Name", style="cyan")
                table.add_column("ID", style="dim")
                table.add_column("Status")
                for token in tokens.result:
                    table.add_row(token.name, f"{token.id[:16]}...", token.status)
                console.print(table)
            else:
                _info("No user tokens found")
        except Exception as exc:
            _error(f"Failed to list user tokens: {exc}")


@tokens_app.command("create-r2")
def create_r2_token(
    name: Annotated[str, typer.Option("--name", "-n", help="Token name")],
    scope: Annotated[str, typer.Option("--scope", "-s", help="Token scope: account or user")] = "account",
    buckets: Annotated[str | None, typer.Option("--buckets", "-b", help="Comma-separated bucket names")] = None,
    read_only: Annotated[bool, typer.Option("--read-only", "-r", help="Create a read-only token")] = False,
) -> None:
    """Create an R2 API token."""
    cloudflare = CloudflareProvider()
    if buckets:
        read_permission_id = "6a018a9f2fc74eb6b293b0c548f38b39"
        write_permission_id = "2efd5506f9c8494dacb1fa10a3e7d5b6"
    else:
        read_permission_id = "b4992e1108244f5d8bfbd5744320c2e1"
        write_permission_id = "bf7481a1826f439697cb59a20b22293e"

    permission_groups = [{"id": read_permission_id}]
    if not read_only:
        permission_groups.append({"id": write_permission_id})

    if buckets:
        resources = {
            f"com.cloudflare.edge.r2.bucket.{cloudflare.account_id}_default_{bucket.strip()}": "*"
            for bucket in buckets.split(",")
        }
    else:
        resources = {f"com.cloudflare.edge.r2.bucket.{cloudflare.account_id}_default_*": "*"}

    policies = [{"effect": "allow", "permission_groups": permission_groups, "resources": resources}]
    try:
        with console.status(f"Creating R2 token '{name}'..."):
            if scope == "account":
                result = cloudflare.client.accounts.tokens.create(
                    account_id=cloudflare.account_id,
                    name=name,
                    policies=policies,
                )
            else:
                result = cloudflare.client.user.tokens.create(name=name, policies=policies)
    except Exception as exc:
        _error(f"Failed to create token: {exc}")
        raise typer.Exit(1) from None

    _success(f"R2 token '{name}' created ({scope} scope)")
    console.print("\n[bold red]Save this token now. It is only shown once.[/bold red]")
    console.print(f"[cyan]{result.value}[/cyan]")
    console.print(f"\n[dim]Token ID: {result.id}[/dim]")


@tokens_app.command("delete")
def delete_token(
    token_id: Annotated[str, typer.Argument(help="Token ID to delete")],
    scope: Annotated[str, typer.Option("--scope", "-s", help="Token scope: account or user")] = "user",
    confirm: Annotated[bool, typer.Option("--yes", "-y")] = False,
) -> None:
    """Delete a Cloudflare API token."""
    if not confirm and not typer.confirm(f"Delete token {token_id}?"):
        raise typer.Abort()
    cloudflare = CloudflareProvider()
    try:
        if scope == "account":
            cloudflare.client.accounts.tokens.delete(account_id=cloudflare.account_id, token_id=token_id)
        else:
            cloudflare.client.user.tokens.delete(token_id=token_id)
    except Exception as exc:
        _error(f"Failed to delete token: {exc}")
        raise typer.Exit(1) from None
    _success(f"Token {token_id} deleted")
