"""Database (Neon) management commands."""

import typer
from rich import print as rprint
from rich.console import Console
from rich.table import Table

from vanty_cli.providers.neon import NeonProvider

app = typer.Typer(help="Neon database management commands")
console = Console()


@app.command("list-projects")
def list_projects() -> None:
    """List all Neon projects."""
    try:
        neon = NeonProvider()
        projects = neon.list_projects()
        if not projects:
            rprint("[yellow]No projects found.[/yellow]")
            return
        table = Table(title="Neon Projects")
        table.add_column("ID", style="cyan")
        table.add_column("Name", style="green")
        table.add_column("Region", style="blue")
        table.add_column("PG Version", style="magenta")
        table.add_column("Created", style="dim")
        for project in projects:
            table.add_row(
                project.get("id", "N/A"),
                project.get("name", "N/A"),
                project.get("region_id", "N/A"),
                str(project.get("pg_version", "N/A")),
                project.get("created_at", "N/A")[:10] if project.get("created_at") else "N/A",
            )
        console.print(table)
    except Exception as exc:
        rprint(f"[red]Error: {exc}[/red]")
        raise typer.Exit(1) from None


@app.command("create-project")
def create_project(
    name: str = typer.Argument(..., help="Project name"),
    region: str = typer.Option("aws-us-east-2", "--region", "-r", help="Region ID"),
    pg_version: int = typer.Option(16, "--pg-version", "-v", help="PostgreSQL version"),
) -> None:
    """Create a Neon project."""
    try:
        neon = NeonProvider()
        with console.status(f"[bold green]Creating project '{name}'..."):
            result = neon.create_project(name=name, region_id=region, pg_version=pg_version)
        project = result.get("project", {})
        rprint("\n[green]OK project created[/green]\n")
        rprint(f"[bold]Project ID:[/bold] {project.get('id', 'N/A')}")
        rprint(f"[bold]Name:[/bold] {project.get('name', 'N/A')}")
        rprint(f"[bold]Region:[/bold] {project.get('region_id', 'N/A')}")
        connection_uri = result.get("connection_uri", "")
        if connection_uri:
            rprint("\n[bold]Connection URI:[/bold]")
            rprint(f"[cyan]{connection_uri}[/cyan]")
            rprint("\n[dim]Export as environment variable:[/dim]")
            rprint(f"export DATABASE_URL='{connection_uri}'")
        branch = result.get("branch", {})
        if branch:
            rprint(f"\n[bold]Default Branch:[/bold] {branch.get('name', 'main')} (ID: {branch.get('id', 'N/A')})")
    except Exception as exc:
        rprint(f"[red]Error: {exc}[/red]")
        raise typer.Exit(1) from None


@app.command("rename-project")
def rename_project(
    project_id: str = typer.Argument(..., help="Project ID to rename"),
    name: str = typer.Argument(..., help="New project name"),
) -> None:
    """Rename a Neon project."""
    try:
        neon = NeonProvider()
        with console.status(f"[bold green]Renaming project to '{name}'..."):
            result = neon.rename_project(project_id, name)
        rprint(f"\n[green]OK project renamed to '{result.get('name')}'[/green]")
    except Exception as exc:
        rprint(f"[red]Error: {exc}[/red]")
        raise typer.Exit(1) from None


@app.command("delete-project")
def delete_project(
    project_id: str = typer.Argument(..., help="Project ID to delete"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    """Delete a Neon project."""
    if not force and not typer.confirm(f"Are you sure you want to delete project {project_id}?"):
        rprint("[yellow]Cancelled.[/yellow]")
        raise typer.Exit(0)
    try:
        neon = NeonProvider()
        with console.status(f"[bold red]Deleting project '{project_id}'..."):
            neon.delete_project(project_id)
        rprint(f"[green]OK project {project_id} deleted.[/green]")
    except Exception as exc:
        rprint(f"[red]Error: {exc}[/red]")
        raise typer.Exit(1) from None


@app.command("list-branches")
def list_branches(project_id: str = typer.Argument(..., help="Project ID")) -> None:
    """List branches for a project."""
    try:
        neon = NeonProvider()
        branches = neon.list_branches(project_id)
        if not branches:
            rprint("[yellow]No branches found.[/yellow]")
            return
        table = Table(title=f"Branches for {project_id}")
        table.add_column("ID", style="cyan")
        table.add_column("Name", style="green")
        table.add_column("Parent", style="blue")
        table.add_column("Primary", style="magenta")
        table.add_column("Created", style="dim")
        for branch in branches:
            table.add_row(
                branch.get("id", "N/A"),
                branch.get("name", "N/A"),
                branch.get("parent_id") or "-",
                "yes" if branch.get("primary") else "",
                branch.get("created_at", "N/A")[:10] if branch.get("created_at") else "N/A",
            )
        console.print(table)
    except Exception as exc:
        rprint(f"[red]Error: {exc}[/red]")
        raise typer.Exit(1) from None


@app.command("create-branch")
def create_branch(
    project_id: str = typer.Argument(..., help="Project ID"),
    name: str = typer.Argument(..., help="Branch name"),
    parent: str | None = typer.Option(None, "--parent", "-p", help="Parent branch ID"),
) -> None:
    """Create a new branch."""
    try:
        neon = NeonProvider()
        with console.status(f"[bold green]Creating branch '{name}'..."):
            result = neon.create_branch(project_id=project_id, name=name, parent_id=parent)
        branch = result.get("branch", {})
        rprint("\n[green]OK branch created[/green]\n")
        rprint(f"[bold]Branch ID:[/bold] {branch.get('id', 'N/A')}")
        rprint(f"[bold]Name:[/bold] {branch.get('name', 'N/A')}")
        rprint(f"[bold]Parent:[/bold] {branch.get('parent_id') or 'N/A'}")
        connection_uris = result.get("connection_uris", [])
        if connection_uris:
            uri = connection_uris[0].get("connection_uri", "")
            rprint("\n[bold]Connection URI:[/bold]")
            rprint(f"[cyan]{uri}[/cyan]")
    except Exception as exc:
        rprint(f"[red]Error: {exc}[/red]")
        raise typer.Exit(1) from None


@app.command("delete-branch")
def delete_branch(
    project_id: str = typer.Argument(..., help="Project ID"),
    branch_id: str = typer.Argument(..., help="Branch ID to delete"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    """Delete a branch."""
    if not force and not typer.confirm(f"Are you sure you want to delete branch {branch_id}?"):
        rprint("[yellow]Cancelled.[/yellow]")
        raise typer.Exit(0)
    try:
        neon = NeonProvider()
        with console.status(f"[bold red]Deleting branch '{branch_id}'..."):
            neon.delete_branch(project_id, branch_id)
        rprint(f"[green]OK branch {branch_id} deleted.[/green]")
    except Exception as exc:
        rprint(f"[red]Error: {exc}[/red]")
        raise typer.Exit(1) from None


@app.command("connection-uri")
def connection_uri(
    project_id: str = typer.Argument(..., help="Project ID"),
    database: str = typer.Option("neondb", "--database", "-d", help="Database name"),
    role: str = typer.Option("neondb_owner", "--role", "-r", help="Role name"),
    pooled: bool = typer.Option(True, "--pooled/--direct", help="Use connection pooling"),
) -> None:
    """Get a connection URI for a project."""
    try:
        neon = NeonProvider()
        uri = neon.get_connection_uri(
            project_id=project_id,
            database_name=database,
            role_name=role,
            pooled=pooled,
        )
        rprint("\n[bold]Connection URI:[/bold]")
        rprint(f"[cyan]{uri}[/cyan]")
        rprint("\n[dim]Export as environment variable:[/dim]")
        rprint(f"export DATABASE_URL='{uri}'")
    except Exception as exc:
        rprint(f"[red]Error: {exc}[/red]")
        raise typer.Exit(1) from None


@app.command("list-databases")
def list_databases(
    project_id: str = typer.Argument(..., help="Project ID"),
    branch_id: str = typer.Argument(..., help="Branch ID"),
) -> None:
    """List databases in a branch."""
    try:
        neon = NeonProvider()
        databases = neon.list_databases(project_id, branch_id)
        if not databases:
            rprint("[yellow]No databases found.[/yellow]")
            return
        table = Table(title=f"Databases in branch {branch_id}")
        table.add_column("ID", style="cyan")
        table.add_column("Name", style="green")
        table.add_column("Owner", style="blue")
        for database in databases:
            table.add_row(
                str(database.get("id", "N/A")),
                database.get("name", "N/A"),
                database.get("owner_name", "N/A"),
            )
        console.print(table)
    except Exception as exc:
        rprint(f"[red]Error: {exc}[/red]")
        raise typer.Exit(1) from None


@app.command("create-database")
def create_database(
    project_id: str = typer.Argument(..., help="Project ID"),
    branch_id: str = typer.Argument(..., help="Branch ID"),
    name: str = typer.Argument(..., help="Database name"),
    owner: str = typer.Option("neondb_owner", "--owner", "-o", help="Owner role name"),
) -> None:
    """Create a new database."""
    try:
        neon = NeonProvider()
        with console.status(f"[bold green]Creating database '{name}'..."):
            result = neon.create_database(
                project_id=project_id,
                branch_id=branch_id,
                name=name,
                owner_name=owner,
            )
        rprint("\n[green]OK database created[/green]\n")
        rprint(f"[bold]Database:[/bold] {result.get('name', 'N/A')}")
        rprint(f"[bold]Owner:[/bold] {result.get('owner_name', 'N/A')}")
    except Exception as exc:
        rprint(f"[red]Error: {exc}[/red]")
        raise typer.Exit(1) from None
