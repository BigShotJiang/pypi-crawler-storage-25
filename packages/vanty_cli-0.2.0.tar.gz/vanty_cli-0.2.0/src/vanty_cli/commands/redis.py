"""Redis management commands."""

import subprocess
import time
from typing import Annotated

import paramiko
import typer
from rich.console import Console

from vanty_cli.config import get_settings
from vanty_cli.providers.hetzner import HetznerProvider

app = typer.Typer(no_args_is_help=True)
console = Console()


def _success(message: str) -> None:
    console.print(f"[green]OK[/green] {message}")


def _error(message: str) -> None:
    console.print(f"[red]ERROR[/red] {message}")


def _info(message: str) -> None:
    console.print(f"[blue]INFO[/blue] {message}")


def _resolve_server_ip(server: str) -> str:
    """Resolve a server name to an IP address."""
    if server.replace(".", "").isdigit():
        return server
    hetzner = HetznerProvider()
    server_obj = hetzner.get_server(server)
    if not server_obj:
        _error(f"Server '{server}' not found")
        raise typer.Exit(1)
    return server_obj.public_net.ipv4.ip


def _run_ssh_command(host: str, command: str, user: str = "root") -> str:
    """Run an SSH command and return stdout/stderr."""
    settings = get_settings()
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        ssh.connect(hostname=host, username=user, key_filename=str(settings.ssh_key_path))
        _, stdout, stderr = ssh.exec_command(command)
        return stdout.read().decode() + stderr.read().decode()
    finally:
        ssh.close()


@app.command("status")
def redis_status(
    server: Annotated[str, typer.Option("--server", "-s", help="Server name or IP")],
    user: Annotated[str, typer.Option("--user", "-u", help="SSH user")] = "root",
    app_dir: Annotated[str, typer.Option("--dir", help="App directory")] = "/opt/app",
) -> None:
    """Check Redis status on a server."""
    host = _resolve_server_ip(server)
    _info(f"Checking Redis on {host}")
    result = _run_ssh_command(
        host,
        f"cd {app_dir} && docker compose -f docker-compose.prod.yml exec -T redis redis-cli ping",
        user,
    )
    if "PONG" not in result:
        _error("Redis is not responding")
        console.print(f"[dim]{result}[/dim]")
        return
    _success("Redis is running")
    server_info = _run_ssh_command(
        host,
        f"cd {app_dir} && docker compose -f docker-compose.prod.yml exec -T redis redis-cli info server | head -15",
        user,
    )
    memory_info = _run_ssh_command(
        host,
        f"cd {app_dir} && docker compose -f docker-compose.prod.yml "
        "exec -T redis redis-cli info memory | grep used_memory_human",
        user,
    )
    console.print(f"\n[dim]{server_info}[/dim]")
    console.print(f"[dim]{memory_info}[/dim]")


@app.command("update")
def update_redis(
    server: Annotated[str, typer.Option("--server", "-s", help="Server name or IP")],
    version: Annotated[str, typer.Option("--version", "-v", help="Redis version tag")] = "7-alpine",
    backup: Annotated[bool, typer.Option("--backup/--no-backup", help="Backup before update")] = True,
    user: Annotated[str, typer.Option("--user", "-u", help="SSH user")] = "root",
    app_dir: Annotated[str, typer.Option("--dir", help="App directory")] = "/opt/app",
) -> None:
    """Update Redis on a server."""
    host = _resolve_server_ip(server)
    with console.status(f"Updating Redis to {version}..."):
        if backup:
            _info("Creating Redis backup")
            _run_ssh_command(
                host,
                f"cd {app_dir} && docker compose -f docker-compose.prod.yml exec -T redis redis-cli BGSAVE",
                user,
            )
            time.sleep(5)
            _success("Backup created")
        _info(f"Pulling redis:{version}")
        _run_ssh_command(host, f"docker pull redis:{version}", user)
        _info("Restarting Redis")
        _run_ssh_command(
            host,
            f"cd {app_dir} && docker compose -f docker-compose.prod.yml up -d redis",
            user,
        )
        time.sleep(3)
        result = _run_ssh_command(
            host,
            f"cd {app_dir} && docker compose -f docker-compose.prod.yml exec -T redis redis-cli ping",
            user,
        )
    if "PONG" not in result:
        _error("Redis failed to start after update")
        raise typer.Exit(1)
    _success(f"Redis updated to {version}")


@app.command("flush")
def flush_redis(
    server: Annotated[str, typer.Option("--server", "-s", help="Server name or IP")],
    db: Annotated[int, typer.Option("--db", help="Database number to flush (-1 for all)")] = -1,
    confirm: Annotated[bool, typer.Option("--yes", "-y")] = False,
    user: Annotated[str, typer.Option("--user", "-u", help="SSH user")] = "root",
    app_dir: Annotated[str, typer.Option("--dir", help="App directory")] = "/opt/app",
) -> None:
    """Flush Redis data."""
    if not confirm:
        prompt = "Flush ALL Redis databases?" if db == -1 else f"Flush Redis database {db}?"
        if not typer.confirm(prompt):
            raise typer.Abort()
    host = _resolve_server_ip(server)
    if db == -1:
        _run_ssh_command(
            host,
            f"cd {app_dir} && docker compose -f docker-compose.prod.yml exec -T redis redis-cli FLUSHALL",
            user,
        )
        _success("All Redis databases flushed")
        return
    _run_ssh_command(
        host,
        f"cd {app_dir} && docker compose -f docker-compose.prod.yml exec -T redis redis-cli -n {db} FLUSHDB",
        user,
    )
    _success(f"Redis database {db} flushed")


@app.command("cli")
def redis_cli(
    server: Annotated[str, typer.Option("--server", "-s", help="Server name or IP")],
    user: Annotated[str, typer.Option("--user", "-u", help="SSH user")] = "root",
    app_dir: Annotated[str, typer.Option("--dir", help="App directory")] = "/opt/app",
) -> None:
    """Open an interactive Redis CLI on the remote host."""
    host = _resolve_server_ip(server)
    command = f"cd {app_dir} && docker compose -f docker-compose.prod.yml exec redis redis-cli"
    subprocess.run(["ssh", "-t", f"{user}@{host}", command], check=False)
