"""Application deployment commands."""

import subprocess
from pathlib import Path
from typing import Annotated

import paramiko
import typer
from rich.console import Console

from vanty_cli.config import get_settings
from vanty_cli.providers.github import GitHubProvider
from vanty_cli.providers.hetzner import HetznerProvider

app = typer.Typer(no_args_is_help=True)
console = Console()


def _success(message: str) -> None:
    console.print(f"[green]OK[/green] {message}")


def _error(message: str) -> None:
    console.print(f"[red]ERROR[/red] {message}")


def _info(message: str) -> None:
    console.print(f"[blue]INFO[/blue] {message}")


def _get_server(server: str | None) -> str:
    """Resolve the target server from an explicit value or DEFAULT_SERVER."""
    if server:
        return server
    settings = get_settings()
    if settings.default_server:
        return settings.default_server
    _error("No server specified. Use --server or set DEFAULT_SERVER.")
    raise typer.Exit(1)


def _resolve_server(server: str | None) -> tuple[str, str]:
    """Resolve a server name or raw IP to (name, ip)."""
    resolved_server = _get_server(server)
    if resolved_server.replace(".", "").isdigit():
        return resolved_server, resolved_server
    hetzner = HetznerProvider()
    server_obj = hetzner.get_server(resolved_server)
    if not server_obj:
        _error(f"Server '{resolved_server}' not found")
        raise typer.Exit(1)
    return server_obj.name, server_obj.public_net.ipv4.ip


def _target_server(server: str | None, action: str) -> tuple[str, str]:
    """Resolve server and render a standard heading."""
    name, host = _resolve_server(server)
    console.print(f"\n[bold cyan]Server:[/bold cyan] {name} ({host})")
    console.print(f"[bold cyan]Action:[/bold cyan] {action}\n")
    return name, host


def _run_ssh_command(host: str, command: str, user: str = "root", capture: bool = False) -> str | None:
    """Run an SSH command via Paramiko."""
    settings = get_settings()
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        ssh.connect(hostname=host, username=user, key_filename=str(settings.ssh_key_path))
        _, stdout, stderr = ssh.exec_command(command)
        output = stdout.read().decode()
        error = stderr.read().decode()
        if capture:
            return output
        if output:
            console.print(output)
        if error:
            console.print(f"[red]{error}[/red]")
        return output
    finally:
        ssh.close()


def _copy_file_to_server(host: str, local_path: str, remote_path: str, user: str = "root") -> None:
    """Copy a file to the server via SFTP."""
    settings = get_settings()
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        ssh.connect(hostname=host, username=user, key_filename=str(settings.ssh_key_path))
        sftp = ssh.open_sftp()
        sftp.put(local_path, remote_path)
        sftp.close()
    finally:
        ssh.close()


@app.command("env")
def deploy_env(
    server: Annotated[str | None, typer.Option("--server", "-s", help="Server name or IP")] = None,
    env_file: Annotated[str, typer.Option("--file", "-f", help="Path to .env file")] = ".env.prod",
    user: Annotated[str, typer.Option("--user", "-u", help="SSH user")] = "root",
    app_dir: Annotated[str, typer.Option("--dir", help="App directory")] = "/opt/app",
) -> None:
    """Copy an environment file to a server."""
    name, host = _target_server(server, f"Copy {env_file}")
    if not Path(env_file).exists():
        _error(f"File not found: {env_file}")
        raise typer.Exit(1)
    with console.status(f"Copying {env_file}..."):
        _copy_file_to_server(host, env_file, f"{app_dir}/.env", user)
    _success(f"Copied {env_file} to {name}:{app_dir}/.env")


@app.command("migrate")
def deploy_migrate(
    server: Annotated[str | None, typer.Option("--server", "-s", help="Server name or IP")] = None,
    user: Annotated[str, typer.Option("--user", "-u", help="SSH user")] = "root",
    app_dir: Annotated[str, typer.Option("--dir", help="App directory")] = "/opt/app",
) -> None:
    """Run database migrations on the remote host."""
    _name, host = _target_server(server, "Run migrations")
    migrate_command = (
        f"cd {app_dir} && docker compose -f docker-compose.prod.yml "
        "exec -T django python manage.py migrate --noinput"
    )
    with console.status("Running migrations..."):
        _run_ssh_command(host, migrate_command, user)
    _success("Migrations complete")


@app.command("push")
def deploy_to_server(
    server: Annotated[str | None, typer.Option("--server", "-s", help="Server name or IP")] = None,
    branch: Annotated[str, typer.Option("--branch", "-b", help="Git branch")] = "main",
    user: Annotated[str, typer.Option("--user", "-u", help="SSH user")] = "root",
    app_dir: Annotated[str, typer.Option("--dir", help="App directory")] = "/opt/app",
    migrate: Annotated[bool, typer.Option("--migrate/--no-migrate", help="Run migrations")] = True,
    rebuild: Annotated[bool, typer.Option("--rebuild/--no-rebuild", help="Rebuild images")] = True,
    zero_downtime: Annotated[
        bool,
        typer.Option("--zero-downtime/--force-recreate", help="Use zero-downtime strategy"),
    ] = True,
) -> None:
    """Deploy code to a server."""
    _name, host = _target_server(server, "Deploy")
    compose = "docker compose -f docker-compose.prod.yml"

    _info("Step 1: Pulling latest code")
    _run_ssh_command(
        host,
        f"cd {app_dir} && git fetch origin && git checkout {branch} && git pull origin {branch}",
        user,
    )
    _success("Code updated")

    if rebuild:
        _info("Step 2: Building images")
        _run_ssh_command(host, f"cd {app_dir} && {compose} build django worker beat webhook", user)
        _success("Images built")
    else:
        _info("Step 2: Skipping rebuild")

    if zero_downtime:
        _info("Step 3: Scaling django to two instances")
        _run_ssh_command(host, f"cd {app_dir} && {compose} up -d --no-recreate --scale django=2 django", user)
        _info("Step 4: Waiting for health checks")
        healthcheck_command = (
            f"cd {app_dir} && for i in $(seq 1 60); do "
            f"{compose} ps django --format json | grep -q healthy && break || sleep 2; done"
        )
        _run_ssh_command(
            host,
            healthcheck_command,
            user,
        )
        _success("New django container is healthy")
        _info("Step 5: Scaling django back to one instance")
        _run_ssh_command(host, f"cd {app_dir} && {compose} up -d --scale django=1 django", user)
        _info("Step 6: Restarting worker and beat")
        _run_ssh_command(host, f"cd {app_dir} && {compose} up -d --force-recreate worker beat", user)
        _success("Background workers restarted")
    else:
        _info("Step 3: Force-recreating services")
        _run_ssh_command(host, f"cd {app_dir} && {compose} up -d --force-recreate", user)
        _success("Services restarted")

    _info("Collecting static files")
    collectstatic_command = (
        f"cd {app_dir} && {compose} "
        "exec -T django python manage.py collectstatic --noinput"
    )
    _run_ssh_command(
        host,
        collectstatic_command,
        user,
    )
    _success("Static files collected")

    if migrate:
        _info("Running migrations")
        _run_ssh_command(
            host,
            f"cd {app_dir} && {compose} exec -T django python manage.py migrate --noinput",
            user,
        )
        _success("Migrations complete")

    _info("Checking service status")
    _run_ssh_command(host, f"cd {app_dir} && {compose} ps", user)
    console.print("\n[bold green]Deployment complete[/bold green]")


@app.command("full")
def deploy_full(
    server: Annotated[str | None, typer.Option("--server", "-s", help="Server name or IP")] = None,
    env_file: Annotated[str, typer.Option("--env-file", "-e", help="Path to .env file")] = ".env.prod",
    branch: Annotated[str, typer.Option("--branch", "-b", help="Git branch")] = "main",
    user: Annotated[str, typer.Option("--user", "-u", help="SSH user")] = "root",
    app_dir: Annotated[str, typer.Option("--dir", help="App directory")] = "/opt/app",
) -> None:
    """Copy env, pull code, rebuild, restart, and migrate."""
    _name, host = _target_server(server, "Full deployment")
    if not Path(env_file).exists():
        _error(f"Env file not found: {env_file}")
        raise typer.Exit(1)

    _info("Step 1: Copying environment file")
    _copy_file_to_server(host, env_file, f"{app_dir}/.env", user)
    _success(f"Copied {env_file}")

    _info("Step 2: Pulling latest code")
    _run_ssh_command(
        host,
        f"cd {app_dir} && git fetch origin && git checkout {branch} && git pull origin {branch}",
        user,
    )
    _success("Code updated")

    _info("Step 3: Rebuilding all containers")
    _run_ssh_command(host, f"cd {app_dir} && docker compose -f docker-compose.prod.yml build --no-cache", user)
    _success("Images rebuilt")

    _info("Step 4: Restarting services")
    _run_ssh_command(host, f"cd {app_dir} && docker compose -f docker-compose.prod.yml up -d --force-recreate", user)
    _success("Services restarted")

    _info("Step 5: Collecting static files")
    collectstatic_command = (
        f"cd {app_dir} && docker compose -f docker-compose.prod.yml "
        "exec -T django python manage.py collectstatic --noinput"
    )
    _run_ssh_command(
        host,
        collectstatic_command,
        user,
    )
    _success("Static files collected")

    _info("Step 6: Running migrations")
    _run_ssh_command(
        host,
        f"cd {app_dir} && docker compose -f docker-compose.prod.yml exec -T django python manage.py migrate --noinput",
        user,
    )
    _success("Migrations complete")

    _info("Step 7: Checking service status")
    _run_ssh_command(host, f"cd {app_dir} && docker compose -f docker-compose.prod.yml ps", user)
    console.print("\n[bold green]Full deployment complete[/bold green]")


@app.command("logs")
def view_logs(
    server: Annotated[str | None, typer.Option("--server", "-s", help="Server name or IP")] = None,
    service: Annotated[str, typer.Option("--service", help="Service name")] = "django",
    follow: Annotated[bool, typer.Option("--follow", "-f", help="Follow logs")] = False,
    tail: Annotated[int, typer.Option("--tail", "-n", help="Number of lines")] = 100,
    user: Annotated[str, typer.Option("--user", "-u", help="SSH user")] = "root",
    app_dir: Annotated[str, typer.Option("--dir", help="App directory")] = "/opt/app",
) -> None:
    """Stream service logs."""
    settings = get_settings()
    _name, host = _resolve_server(server)
    follow_flag = "-f" if follow else ""
    command = f"cd {app_dir} && docker compose -f docker-compose.prod.yml logs {follow_flag} --tail={tail} {service}"
    subprocess.run(
        [
            "ssh",
            "-i",
            str(settings.ssh_key_path),
            "-o",
            "StrictHostKeyChecking=accept-new",
            f"{user}@{host}",
            command,
        ],
        check=False,
    )


@app.command("exec")
def exec_command(
    server: Annotated[str | None, typer.Option("--server", "-s", help="Server name or IP")] = None,
    service: Annotated[str, typer.Option("--service", help="Service name")] = "django",
    command: Annotated[str, typer.Argument(help="Command to run")] = "bash",
    user: Annotated[str, typer.Option("--user", "-u", help="SSH user")] = "root",
    app_dir: Annotated[str, typer.Option("--dir", help="App directory")] = "/opt/app",
) -> None:
    """Execute a command inside a remote container."""
    settings = get_settings()
    _name, host = _resolve_server(server)
    remote_command = f"cd {app_dir} && docker compose -f docker-compose.prod.yml exec {service} {command}"
    subprocess.run(
        [
            "ssh",
            "-t",
            "-i",
            str(settings.ssh_key_path),
            "-o",
            "StrictHostKeyChecking=accept-new",
            f"{user}@{host}",
            remote_command,
        ],
        check=False,
    )


@app.command("status")
def deployment_status(
    server: Annotated[str | None, typer.Option("--server", "-s", help="Server name or IP")] = None,
    user: Annotated[str, typer.Option("--user", "-u", help="SSH user")] = "root",
    app_dir: Annotated[str, typer.Option("--dir", help="App directory")] = "/opt/app",
) -> None:
    """Show deployment and git status."""
    _name, host = _target_server(server, "Check status")
    console.print("\n[bold]Container Status[/bold]")
    _run_ssh_command(host, f"cd {app_dir} && docker compose -f docker-compose.prod.yml ps", user)
    console.print("\n[bold]Git Status[/bold]")
    _run_ssh_command(host, f"cd {app_dir} && git log -1 --format='%h %s (%cr)'", user)


webhook_app = typer.Typer(no_args_is_help=True)
app.add_typer(webhook_app, name="webhook", help="GitHub webhook management")


@webhook_app.command("setup")
def setup_webhook(
    repo: Annotated[str, typer.Option("--repo", "-r", help="GitHub repo in owner/repo format")],
    domain: Annotated[str, typer.Option("--domain", "-d", help="Webhook domain")],
) -> None:
    """Create a GitHub push webhook for auto-deploy."""
    owner, repo_name = repo.split("/", maxsplit=1)
    github = GitHubProvider()
    webhook_url = f"https://{domain}/_deploy"
    with console.status("Setting up webhook..."):
        result = github.create_webhook(owner=owner, repo=repo_name, url=webhook_url, events=["push"])
    _success(f"Webhook created: {result['id']}")
    _info(f"URL: {webhook_url}")
    console.print("\n[bold]Webhook Secret[/bold]")
    console.print(result["_secret"])
    console.print("[yellow]Add WEBHOOK_SECRET to your env file and redeploy.[/yellow]")


@webhook_app.command("list")
def list_webhooks(
    repo: Annotated[str, typer.Option("--repo", "-r", help="GitHub repo in owner/repo format")],
) -> None:
    """List repository webhooks."""
    owner, repo_name = repo.split("/", maxsplit=1)
    github = GitHubProvider()
    webhooks = github.list_webhooks(owner, repo_name)
    if not webhooks:
        _info("No webhooks found")
        return
    for hook in webhooks:
        console.print(f"[bold]ID:[/bold] {hook['id']}")
        console.print(f"  URL: {hook['config'].get('url', 'N/A')}")
        console.print(f"  Events: {', '.join(hook['events'])}")
        console.print(f"  Active: {hook['active']}")
        console.print()


@webhook_app.command("delete")
def delete_webhook(
    repo: Annotated[str, typer.Option("--repo", "-r", help="GitHub repo in owner/repo format")],
    hook_id: Annotated[int, typer.Option("--id", help="Webhook ID")],
    confirm: Annotated[bool, typer.Option("--yes", "-y", help="Skip confirmation")] = False,
) -> None:
    """Delete a repository webhook."""
    if not confirm and not typer.confirm(f"Delete webhook {hook_id}?"):
        raise typer.Abort()
    owner, repo_name = repo.split("/", maxsplit=1)
    github = GitHubProvider()
    github.delete_webhook(owner, repo_name, hook_id)
    _success(f"Webhook {hook_id} deleted")


key_app = typer.Typer(no_args_is_help=True)
app.add_typer(key_app, name="key", help="GitHub deploy key management")


@key_app.command("add")
def add_deploy_key(
    repo: Annotated[str, typer.Option("--repo", "-r", help="GitHub repo in owner/repo format")],
    server: Annotated[str | None, typer.Option("--server", "-s", help="Server name or IP")] = None,
    user: Annotated[str, typer.Option("--user", "-u", help="SSH user")] = "root",
) -> None:
    """Add a server SSH key to GitHub as a read-only deploy key."""
    server_name, host = _target_server(server, "Add deploy key to GitHub")
    owner, repo_name = repo.split("/", maxsplit=1)
    public_key_command = (
        "cat /root/.ssh/id_ed25519.pub 2>/dev/null || "
        "cat /root/.ssh/id_rsa.pub 2>/dev/null || "
        "(ssh-keygen -t ed25519 -f /root/.ssh/id_ed25519 -N '' -q && "
        "cat /root/.ssh/id_ed25519.pub)"
    )
    public_key = _run_ssh_command(
        host,
        public_key_command,
        user,
        capture=True,
    )
    if not public_key or not public_key.strip():
        _error("Could not read the server's SSH public key")
        raise typer.Exit(1)
    github = GitHubProvider()
    with console.status("Adding deploy key to GitHub..."):
        result = github.create_deploy_key(
            owner=owner,
            repo=repo_name,
            title=f"deploy-{server_name}",
            key=public_key.strip(),
            read_only=True,
        )
    _success(f"Deploy key added: {result['id']}")


@key_app.command("list")
def list_deploy_keys(
    repo: Annotated[str, typer.Option("--repo", "-r", help="GitHub repo in owner/repo format")],
) -> None:
    """List deploy keys for a repository."""
    owner, repo_name = repo.split("/", maxsplit=1)
    github = GitHubProvider()
    keys = github.list_deploy_keys(owner, repo_name)
    if not keys:
        _info("No deploy keys found")
        return
    for key in keys:
        console.print(f"[bold]ID:[/bold] {key['id']}")
        console.print(f"  Title: {key['title']}")
        console.print(f"  Read-only: {key['read_only']}")
        console.print(f"  Created: {key['created_at']}")
        console.print()


@key_app.command("delete")
def delete_deploy_key(
    repo: Annotated[str, typer.Option("--repo", "-r", help="GitHub repo in owner/repo format")],
    key_id: Annotated[int, typer.Option("--id", help="Deploy key ID")],
    confirm: Annotated[bool, typer.Option("--yes", "-y", help="Skip confirmation")] = False,
) -> None:
    """Delete a deploy key."""
    if not confirm and not typer.confirm(f"Delete deploy key {key_id}?"):
        raise typer.Abort()
    owner, repo_name = repo.split("/", maxsplit=1)
    github = GitHubProvider()
    github.delete_deploy_key(owner, repo_name, key_id)
    _success(f"Deploy key {key_id} deleted")


@key_app.command("setup-git")
def setup_git_ssh(
    server: Annotated[str | None, typer.Option("--server", "-s", help="Server name or IP")] = None,
    user: Annotated[str, typer.Option("--user", "-u", help="SSH user")] = "root",
) -> None:
    """Configure the server to use GitHub SSH remotes."""
    _name, host = _target_server(server, "Configure Git SSH")
    _run_ssh_command(host, "ssh-keyscan -t ed25519 github.com >> /root/.ssh/known_hosts 2>/dev/null", user)
    update_remote_command = (
        "cd /opt/app && "
        "git remote set-url origin "
        "git@github.com:$(git remote get-url origin | sed 's|https://github.com/||' | "
        "sed 's|\\.git$||').git 2>/dev/null || true"
    )
    _run_ssh_command(
        host,
        update_remote_command,
        user,
    )
    _success("Git configured for SSH")
