"""
Vanty CLI - Infrastructure and deployment management.

Usage:
    vanty server provision --name prod-1 --type cx23
    vanty deploy push --server prod-1
    vanty buckets create --domain example.com --target-ip 1.2.3.4
"""

import os

import typer
from rich.console import Console
from rich.table import Table

from vanty_cli import __version__
from vanty_cli.commands import buckets, db, deploy, email, lb, redis, server
from vanty_cli.config import get_settings

HELP_TEXT = """
[bold]Vanty CLI[/bold] - Infrastructure and deployment management for Hetzner, Cloudflare, Neon, GitHub, and Resend.

[bold cyan]Required Environment Variables:[/bold cyan]

  [bold]Hetzner Cloud[/bold] (for server provisioning)
    HETZNER_API_TOKEN     Your Hetzner Cloud API token
                          Get it from: https://console.hetzner.cloud/projects/*/security/tokens

  [bold]Cloudflare[/bold] (for DNS and R2 storage)
    CF_API_TOKEN          Cloudflare API token with Zone and R2 permissions
    CF_ACCOUNT_ID         Your Cloudflare account ID
                          Also supports CLOUDFLARE_API_TOKEN / CLOUDFLARE_ACCOUNT_ID

  [bold]Neon[/bold] (for database management)
    NEON_API_KEY          Neon API key
                          Get it from: https://console.neon.tech/app/settings/api-keys

  [bold]Resend[/bold] (for email)
    RESEND_API_KEY        Resend API key
                          Get it from: https://resend.com/api-keys

[bold cyan]Quick Start:[/bold cyan]

  1. Create a .env file with your API keys
  2. Run: vanty server provision --name my-server --type cx23
  3. Run: vanty buckets dns --domain example.com --content <server-ip>
  4. Run: vanty deploy push --server my-server
"""

app = typer.Typer(
    name="vanty",
    help=HELP_TEXT,
    invoke_without_command=True,
    rich_markup_mode="rich",
)
console = Console()

app.add_typer(server.app, name="server", help="Hetzner server management")
app.add_typer(deploy.app, name="deploy", help="Git and Docker Compose deployment")
app.add_typer(buckets.app, name="buckets", help="Cloudflare DNS and R2 management")
app.add_typer(lb.app, name="lb", help="Hetzner load balancer management")
app.add_typer(redis.app, name="redis", help="Redis maintenance commands")
app.add_typer(db.app, name="db", help="Neon database management")
app.add_typer(email.app, name="email", help="Resend email management")


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Enable verbose output"),
) -> None:
    """Vanty CLI for infrastructure and deployment management."""
    if verbose:
        console.print("[dim]Verbose mode enabled[/dim]")
    if ctx.invoked_subcommand is None:
        console.print(ctx.get_help())


@app.command()
def version() -> None:
    """Show CLI version."""
    console.print(f"[bold]vanty-cli[/bold] v{__version__}")


@app.command()
def env() -> None:
    """Show which environment variables are configured."""
    get_settings.cache_clear()
    settings = get_settings()

    table = Table(title="Environment Configuration")
    table.add_column("Variable", style="cyan")
    table.add_column("Status", style="bold")
    table.add_column("Source")

    def check_var(value: str, env_names: list[str]) -> tuple[str, str]:
        if value:
            source = ", ".join(name for name in env_names if os.environ.get(name))
            return "[green]set[/green]", f"from {source}" if source else "from .env"
        return "[red]not set[/red]", ""

    rows = [
        ("HETZNER_API_TOKEN", settings.hetzner_api_token, ["HETZNER_API_TOKEN"]),
        (
            "CF_API_TOKEN",
            settings.cloudflare_api_token,
            ["CF_API_TOKEN", "CLOUDFLARE_API_TOKEN"],
        ),
        (
            "CF_ACCOUNT_ID",
            settings.cloudflare_account_id,
            ["CF_ACCOUNT_ID", "CLOUDFLARE_ACCOUNT_ID"],
        ),
        ("NEON_API_KEY", settings.neon_api_key, ["NEON_API_KEY"]),
        ("GITHUB_TOKEN", settings.github_token, ["GITHUB_TOKEN"]),
        ("RESEND_API_KEY", settings.resend_api_key, ["RESEND_API_KEY"]),
    ]
    for variable, value, env_names in rows:
        status, source = check_var(value, env_names)
        table.add_row(variable, status, source)

    console.print(table)
    console.print("\n[dim]Tip: create a .env file in the package root.[/dim]")


if __name__ == "__main__":
    app()
