"""Configuration management using pydantic-settings."""

from functools import lru_cache
from pathlib import Path

from pydantic import AliasChoices, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """CLI configuration loaded from environment variables and `.env`."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    hetzner_api_token: str = Field(default="", alias="HETZNER_API_TOKEN")
    cloudflare_api_token: str = Field(
        default="",
        validation_alias=AliasChoices("CF_API_TOKEN", "CLOUDFLARE_API_TOKEN"),
    )
    cloudflare_account_id: str = Field(
        default="",
        validation_alias=AliasChoices("CF_ACCOUNT_ID", "CLOUDFLARE_ACCOUNT_ID"),
    )
    ssh_key_path: Path = Field(
        default=Path.home() / ".ssh" / "id_ed25519",
        alias="SSH_KEY_PATH",
    )
    default_server_type: str = Field(default="cx23", alias="DEFAULT_SERVER_TYPE")
    default_location: str = Field(default="nbg1", alias="DEFAULT_LOCATION")
    default_image: str = Field(default="ubuntu-24.04", alias="DEFAULT_IMAGE")
    default_server: str = Field(default="", alias="DEFAULT_SERVER")
    github_token: str = Field(default="", alias="GITHUB_TOKEN")
    neon_api_key: str = Field(default="", alias="NEON_API_KEY")
    resend_api_key: str = Field(default="", alias="RESEND_API_KEY")

    @property
    def ssh_public_key_path(self) -> Path:
        """Return the public key path matching the configured private key."""
        return self.ssh_key_path.with_suffix(".pub")


@lru_cache
def get_settings() -> Settings:
    """Return a cached settings instance."""
    return Settings()
