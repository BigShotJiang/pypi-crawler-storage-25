# Vanty CLI

`vanty-cli` is a standalone Typer-based CLI for infrastructure and deployment work across Hetzner, Cloudflare, Neon, GitHub, and Resend.

## Install

```bash
uv tool install .
vanty --help
```

For local development:

```bash
uv sync --dev
uv run vanty --help
```

## Environment

Create a `.env` file in the package root or export the variables directly:

```env
HETZNER_API_TOKEN=
CF_API_TOKEN=
CF_ACCOUNT_ID=
NEON_API_KEY=
RESEND_API_KEY=
GITHUB_TOKEN=
SSH_KEY_PATH=~/.ssh/id_ed25519
DEFAULT_SERVER=
DEFAULT_SERVER_TYPE=cx23
DEFAULT_LOCATION=nbg1
DEFAULT_IMAGE=ubuntu-24.04
```

Cloudflare also supports `CLOUDFLARE_API_TOKEN` and `CLOUDFLARE_ACCOUNT_ID`.

## Command Groups

- `vanty server`: Hetzner server provisioning, listing, SSH, IP lookup
- `vanty deploy`: deploy, logs, exec, status, webhook, deploy keys
- `vanty buckets`: Cloudflare zones, DNS, R2 buckets, token helpers
- `vanty db`: Neon projects, branches, databases, connection URIs
- `vanty email`: Resend domains, API keys, test emails
- `vanty lb`: Hetzner load balancers and DNS
- `vanty redis`: remote Redis maintenance commands

## Examples

```bash
vanty env
vanty server provision --name api-1 --domain api.example.com --repo https://github.com/advantch/app.git
vanty deploy full --server api-1 --env-file .env.prod
vanty buckets dns --domain example.com --name api --content 1.2.3.4
vanty db create-project my-project --region aws-eu-central-1
vanty email domains add emails.example.com --cloudflare
```

## CI/CD

- `tests.yml` runs Ruff, pytest, and package builds on pushes and pull requests.
- `release.yml` builds artifacts, publishes a GitHub release, and publishes to PyPI on `v*` tags.

## Notes

- `server provision` reads `ops/cloud-init.yaml` from this package.
- The CLI is intentionally standalone and does not depend on Django or `llm-data-kit`.
