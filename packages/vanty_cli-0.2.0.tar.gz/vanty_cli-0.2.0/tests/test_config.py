"""Configuration tests."""

from pathlib import Path

from vanty_cli.config import get_settings


def test_settings_accept_cloudflare_aliases(monkeypatch) -> None:
    """Cloudflare settings should resolve from the short aliases."""
    monkeypatch.delenv("CF_API_TOKEN", raising=False)
    monkeypatch.delenv("CF_ACCOUNT_ID", raising=False)
    monkeypatch.setenv("CLOUDFLARE_API_TOKEN", "alt-token")
    monkeypatch.setenv("CLOUDFLARE_ACCOUNT_ID", "alt-account")
    get_settings.cache_clear()

    settings = get_settings()

    assert settings.cloudflare_api_token == "alt-token"
    assert settings.cloudflare_account_id == "alt-account"


def test_ssh_public_key_path_uses_private_key_suffix(monkeypatch) -> None:
    """The public key path should mirror the configured private key."""
    monkeypatch.setenv("SSH_KEY_PATH", "/tmp/custom_ed25519")
    get_settings.cache_clear()

    settings = get_settings()

    assert settings.ssh_key_path == Path("/tmp/custom_ed25519")
    assert settings.ssh_public_key_path == Path("/tmp/custom_ed25519.pub")
