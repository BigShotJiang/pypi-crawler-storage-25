"""Shared pytest fixtures for vanty-cli."""

import pytest

from vanty_cli.config import get_settings


@pytest.fixture(autouse=True)
def set_test_env(monkeypatch: pytest.MonkeyPatch) -> None:
    """Provide predictable test configuration."""
    monkeypatch.setenv("HETZNER_API_TOKEN", "test-hetzner")
    monkeypatch.setenv("CF_API_TOKEN", "test-cloudflare")
    monkeypatch.setenv("CF_ACCOUNT_ID", "test-account")
    monkeypatch.setenv("NEON_API_KEY", "test-neon")
    monkeypatch.setenv("RESEND_API_KEY", "test-resend")
    monkeypatch.setenv("GITHUB_TOKEN", "test-github")
    monkeypatch.setenv("DEFAULT_SERVER", "default-server")
    get_settings.cache_clear()
    yield
    get_settings.cache_clear()
