"""CLI integration tests with stubbed providers."""

from types import SimpleNamespace

from typer.testing import CliRunner

from vanty_cli.main import app

runner = CliRunner()


def test_version_command() -> None:
    """The version command should print the package version."""
    result = runner.invoke(app, ["version"])

    assert result.exit_code == 0
    assert "vanty-cli" in result.stdout


def test_env_command() -> None:
    """The env command should show configured variables."""
    result = runner.invoke(app, ["env"])

    assert result.exit_code == 0
    assert "Environment Configuration" in result.stdout
    assert "HETZNER_API_TOKEN" in result.stdout
    assert "CF_API_TOKEN" in result.stdout
    assert "NEON_API_KEY" in result.stdout


def test_help_mentions_command_groups() -> None:
    """Top-level help should expose the main groups."""
    result = runner.invoke(app, ["--help"])

    assert result.exit_code == 0
    assert "server" in result.stdout
    assert "deploy" in result.stdout
    assert "buckets" in result.stdout
    assert "email" in result.stdout


def test_db_list_projects_command(monkeypatch) -> None:
    """The db list-projects command should render provider output."""

    class FakeNeonProvider:
        def list_projects(self):
            return [
                {
                    "id": "project-1",
                    "name": "My Project",
                    "region_id": "aws-us-east-1",
                    "pg_version": 16,
                    "created_at": "2026-01-01T00:00:00Z",
                }
            ]

    monkeypatch.setattr("vanty_cli.commands.db.NeonProvider", FakeNeonProvider)

    result = runner.invoke(app, ["db", "list-projects"])

    assert result.exit_code == 0
    assert "Neon Projects" in result.stdout
    assert "My Project" in result.stdout


def test_server_list_command(monkeypatch) -> None:
    """The server list command should render server rows."""

    class FakeHetznerProvider:
        def list_servers(self, label_selector=None):
            return [
                SimpleNamespace(
                    name="api-1",
                    server_type=SimpleNamespace(name="cx23"),
                    status="running",
                    public_net=SimpleNamespace(ipv4=SimpleNamespace(ip="1.2.3.4")),
                    datacenter=SimpleNamespace(name="nbg1-dc3"),
                )
            ]

    monkeypatch.setattr("vanty_cli.commands.server.HetznerProvider", FakeHetznerProvider)

    result = runner.invoke(app, ["server", "list"])

    assert result.exit_code == 0
    assert "Hetzner Servers" in result.stdout
    assert "api-1" in result.stdout
