"""Provider unit tests with fake SDK clients."""

from types import SimpleNamespace

from vanty_cli.providers.cloudflare import CloudflareProvider
from vanty_cli.providers.github import GitHubProvider
from vanty_cli.providers.neon import NeonProvider
from vanty_cli.providers.resend import ResendProvider


def test_cloudflare_upsert_uses_update_for_existing_record(monkeypatch) -> None:
    """Existing DNS records should be updated instead of recreated."""

    class FakeRecordsApi:
        def __init__(self):
            self.updated = None
            self.created = None

        def list(self, **kwargs):
            if kwargs.get("name") == "api.example.com":
                return SimpleNamespace(result=[SimpleNamespace(to_dict=lambda: {"id": "rec-1"})])
            return SimpleNamespace(result=[])

        def update(self, **kwargs):
            self.updated = kwargs
            return {"id": "rec-1"}

        def create(self, **kwargs):
            self.created = kwargs
            return {"id": "rec-2"}

    records_api = FakeRecordsApi()
    fake_client = SimpleNamespace(dns=SimpleNamespace(records=records_api))
    monkeypatch.setattr("vanty_cli.providers.cloudflare.cloudflare.Cloudflare", lambda api_token: fake_client)

    provider = CloudflareProvider(token="token")
    provider.upsert_dns_record("zone-1", "A", "api.example.com", "1.2.3.4")

    assert records_api.updated is not None
    assert records_api.created is None
    assert records_api.updated["dns_record_id"] == "rec-1"


def test_github_create_webhook_returns_secret(monkeypatch) -> None:
    """Webhook creation should expose the generated secret for operator use."""

    class FakeResponse:
        def raise_for_status(self) -> None:
            return None

        def json(self):
            return {"id": 99}

    class FakeClient:
        def __init__(self, *args, **kwargs):
            self.last_payload = None

        def post(self, path, json):
            self.last_payload = {"path": path, "json": json}
            return FakeResponse()

    fake_client = FakeClient()
    monkeypatch.setattr("vanty_cli.providers.github.httpx.Client", lambda *args, **kwargs: fake_client)
    monkeypatch.setattr("vanty_cli.providers.github.secrets.token_hex", lambda length: "generated-secret")

    provider = GitHubProvider(token="token")
    result = provider.create_webhook("advantch", "vanty-cli", "https://example.com/_deploy")

    assert result["_secret"] == "generated-secret"
    assert fake_client.last_payload["path"] == "/repos/advantch/vanty-cli/hooks"


def test_neon_create_project_includes_branch_and_connection_uri(monkeypatch) -> None:
    """Project creation should include branch metadata and connection info."""

    class FakeNeonClient:
        def project_create(self, project):
            return SimpleNamespace(project=SimpleNamespace(id="project-1", name=project["name"]))

        def branches(self, project_id):
            return SimpleNamespace(branches=[SimpleNamespace(id="branch-1", name="main")])

        def connection_uri(self, **kwargs):
            return SimpleNamespace(uri="postgresql://example")

    monkeypatch.setattr("vanty_cli.providers.neon.get_neon_client", lambda: FakeNeonClient())

    provider = NeonProvider()
    result = provider.create_project("demo")

    assert result["project"]["id"] == "project-1"
    assert result["branch"]["id"] == "branch-1"
    assert result["connection_uri"] == "postgresql://example"


def test_resend_create_api_key_passes_domain(monkeypatch) -> None:
    """API key creation should pass the optional domain restriction."""
    created_payload = {}

    monkeypatch.setattr("vanty_cli.providers.resend.get_resend_client", lambda: None)
    monkeypatch.setattr(
        "vanty_cli.providers.resend.resend.ApiKeys.create",
        lambda payload: created_payload.setdefault("payload", payload) or {"id": "key-1", "token": "secret"},
    )

    provider = ResendProvider()
    provider.create_api_key("ops-key", "sending_access", "domain-1")

    assert created_payload["payload"] == {
        "name": "ops-key",
        "permission": "sending_access",
        "domain_id": "domain-1",
    }
