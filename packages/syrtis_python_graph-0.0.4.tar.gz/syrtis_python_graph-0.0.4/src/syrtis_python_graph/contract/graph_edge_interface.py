from __future__ import annotations

from abc import ABC, abstractmethod


class GraphEdgeInterface(ABC):
    @abstractmethod
    def get_graph_id(self) -> str | int:
        pass

    @abstractmethod
    def get_source_node_id(self) -> str | int:
        pass

    @abstractmethod
    def get_source_port(self) -> str | None:
        pass

    @abstractmethod
    def get_target_node_id(self) -> str | int:
        pass

    @abstractmethod
    def get_target_port(self) -> str | None:
        pass
