from __future__ import annotations

from abc import ABC, abstractmethod


class GraphNodeInterface(ABC):
    @abstractmethod
    def get_graph_id(self) -> str | int:
        pass
