from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class CycleDetectionResult:
    back_edges: list[tuple[str | int, str | int]]
    cycles: list[list[str | int]]
    has_cycles: bool

    nodes_in_cycles: set[str | int] = field(default_factory=set)

    def is_back_edge(self, source_id: str | int, target_id: str | int) -> bool:
        return (source_id, target_id) in self.back_edges
