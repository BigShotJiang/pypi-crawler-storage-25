from __future__ import annotations

from syrtis_python_graph.contract.graph_edge_interface import GraphEdgeInterface
from syrtis_python_graph.contract.graph_node_interface import GraphNodeInterface


class GraphDefinition:
    def __init__(self) -> None:
        self._nodes: dict[str | int, GraphNodeInterface] = {}
        self._edges: dict[str | int, GraphEdgeInterface] = {}
        self._outgoing: dict[str | int, list[GraphEdgeInterface]] = {}
        self._incoming: dict[str | int, list[GraphEdgeInterface]] = {}

    def add_edge(self, edge: GraphEdgeInterface) -> None:
        edge_id = edge.get_graph_id()
        source_id = edge.get_source_node_id()
        target_id = edge.get_target_node_id()

        self._edges[edge_id] = edge
        self._outgoing.setdefault(source_id, []).append(edge)
        self._incoming.setdefault(target_id, []).append(edge)

    def add_node(self, node: GraphNodeInterface) -> None:
        node_id = node.get_graph_id()
        self._nodes[node_id] = node
        self._outgoing.setdefault(node_id, [])
        self._incoming.setdefault(node_id, [])

    def get_edges(self) -> dict[str | int, GraphEdgeInterface]:
        return self._edges

    def get_incoming_edges(self, node_id: str | int) -> list[GraphEdgeInterface]:
        return self._incoming.get(node_id, [])

    def get_node(self, node_id: str | int) -> GraphNodeInterface | None:
        return self._nodes.get(node_id)

    def get_nodes(self) -> dict[str | int, GraphNodeInterface]:
        return self._nodes

    def get_outgoing_edges(self, node_id: str | int) -> list[GraphEdgeInterface]:
        return self._outgoing.get(node_id, [])
