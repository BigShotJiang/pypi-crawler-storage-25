from __future__ import annotations

from syrtis_python_graph.model.cycle_detection_result import CycleDetectionResult
from syrtis_python_graph.model.graph_definition import GraphDefinition

_WHITE = 0
_GRAY = 1
_BLACK = 2


class GraphCycleDetector:
    def detect(self, definition: GraphDefinition) -> CycleDetectionResult:
        color: dict[str | int, int] = {}
        parent: dict[str | int, str | int | None] = {}
        back_edges: list[tuple[str | int, str | int]] = []
        cycles: list[list[str | int]] = []

        for node_id in definition.get_nodes():
            color[node_id] = _WHITE
            parent[node_id] = None

        for node_id in definition.get_nodes():
            if color[node_id] == _WHITE:
                self._dfs(node_id, definition, color, parent, back_edges, cycles)

        nodes_in_cycles: set[str | int] = {
            node_id for cycle in cycles for node_id in cycle
        }

        return CycleDetectionResult(
            has_cycles=bool(back_edges),
            cycles=cycles,
            back_edges=back_edges,
            nodes_in_cycles=nodes_in_cycles,
        )

    def _dfs(
        self,
        node_id: str | int,
        definition: GraphDefinition,
        color: dict[str | int, int],
        parent: dict[str | int, str | int | None],
        back_edges: list[tuple[str | int, str | int]],
        cycles: list[list[str | int]],
    ) -> None:
        color[node_id] = _GRAY

        for edge in definition.get_outgoing_edges(node_id):
            target_id = edge.get_target_node_id()

            if color.get(target_id) == _GRAY:
                back_edges.append((node_id, target_id))
                cycles.append(self._extract_cycle(node_id, target_id, parent))
            elif color.get(target_id, _WHITE) == _WHITE:
                parent[target_id] = node_id
                self._dfs(target_id, definition, color, parent, back_edges, cycles)

        color[node_id] = _BLACK

    def _extract_cycle(
        self,
        from_id: str | int,
        to_id: str | int,
        parent: dict[str | int, str | int | None],
    ) -> list[str | int]:
        cycle: list[str | int] = [from_id]
        current: str | int = from_id

        while current != to_id:
            current = parent[current]  # type: ignore[assignment]
            cycle.append(current)

        return list(reversed(cycle))
