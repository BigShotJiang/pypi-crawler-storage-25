from __future__ import annotations

from syrtis_python_graph.model.graph_definition import GraphDefinition


class GraphReadinessChecker:
    def is_ready(
        self,
        node_id: str | int,
        completed_ids: list[str | int],
        definition: GraphDefinition,
        back_edges: list[tuple[str | int, str | int]] | None = None,
    ) -> bool:
        completed_set = {str(i) for i in completed_ids}
        back_edge_set = {(src, tgt) for src, tgt in (back_edges or [])}

        for edge in definition.get_incoming_edges(node_id):
            if (edge.get_source_node_id(), edge.get_target_node_id()) in back_edge_set:
                continue
            if str(edge.get_source_node_id()) not in completed_set:
                return False

        return True
