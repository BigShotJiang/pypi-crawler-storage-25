from __future__ import annotations

from syrtis_python_graph.contract.graph_node_interface import GraphNodeInterface
from syrtis_python_graph.model.graph_definition import GraphDefinition


class GraphResolver:
    def __init__(self, definition: GraphDefinition) -> None:
        self._definition = definition

    def get_end_nodes(self) -> list[GraphNodeInterface]:
        return [
            node
            for node in self._definition.get_nodes().values()
            if not self._definition.get_outgoing_edges(node.get_graph_id())
        ]

    def get_predecessor_ids(self, node_id: str | int) -> list[str | int]:
        return [
            edge.get_source_node_id()
            for edge in self._definition.get_incoming_edges(node_id)
        ]

    def get_predecessors(self, node_id: str | int) -> list[GraphNodeInterface]:
        return [
            node
            for edge in self._definition.get_incoming_edges(node_id)
            if (node := self._definition.get_node(edge.get_source_node_id()))
            is not None
        ]

    def get_start_nodes(self) -> list[GraphNodeInterface]:
        return [
            node
            for node in self._definition.get_nodes().values()
            if not self._definition.get_incoming_edges(node.get_graph_id())
        ]

    def get_successor_ids(self, node_id: str | int) -> list[str | int]:
        return [
            edge.get_target_node_id()
            for edge in self._definition.get_outgoing_edges(node_id)
        ]

    def get_successors(self, node_id: str | int) -> list[GraphNodeInterface]:
        return [
            node
            for edge in self._definition.get_outgoing_edges(node_id)
            if (node := self._definition.get_node(edge.get_target_node_id()))
            is not None
        ]
