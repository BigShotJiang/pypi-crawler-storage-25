"""
Activation System — helps users understand and feel OpenMemo working.

Provides:
  - ActivationStore: tracks install state, task milestones, insight cards
  - Generates Memory Created / Optimization Detected cards on task completion
  - Reuse Indicator when workflow_adopted == True
"""

from openmemo_openclaw.activation.activation_store import ActivationStore

__all__ = ["ActivationStore"]
