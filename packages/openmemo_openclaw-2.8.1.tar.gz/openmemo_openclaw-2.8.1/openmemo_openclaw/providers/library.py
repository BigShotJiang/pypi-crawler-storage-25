"""
Library provider — direct OpenMemo SDK calls (no server needed).

Designed to be resilient against API differences across openmemo versions.
All methods degrade gracefully and never raise to the caller.
"""

import logging
from typing import List

logger = logging.getLogger("openmemo_openclaw.providers.library")


class LibraryProvider:
    def __init__(self, db_path: str = "openmemo.db"):
        from openmemo import OpenMemo
        self._memory = OpenMemo(db_path=db_path)

    def write_memory(self, content: str, scene: str = "",
                     memory_type: str = "observation",
                     agent_id: str = "",
                     confidence: float = 0.8,
                     metadata: dict = None) -> str:
        # Try with all parameters first; fall back progressively for older versions
        try:
            return self._memory.write_memory(
                content=content,
                scene=scene,
                memory_type=memory_type,
                agent_id=agent_id,
                confidence=confidence,
                metadata=metadata,
            ) or ""
        except TypeError:
            pass
        try:
            return self._memory.write_memory(
                content=content,
                scene=scene,
                memory_type=memory_type,
                agent_id=agent_id,
            ) or ""
        except TypeError:
            pass
        try:
            return self._memory.write_memory(content=content, scene=scene) or ""
        except Exception as e:
            logger.warning("[openmemo] write_memory failed: %s", e)
            return ""

    def recall_context(self, query: str, scene: str = "",
                       agent_id: str = "",
                       limit: int = 5) -> List[str]:
        # Try with mode="kv" (newer versions), fall back for older versions
        for kwargs in [
            {"query": query, "scene": scene, "agent_id": agent_id, "limit": limit, "mode": "kv"},
            {"query": query, "scene": scene, "agent_id": agent_id, "limit": limit},
            {"query": query, "scene": scene, "limit": limit},
            {"query": query, "limit": limit},
        ]:
            try:
                result = self._memory.recall_context(**kwargs)
                # Handle both dict and list return shapes
                if isinstance(result, dict):
                    ctx = result.get("context") or result.get("memories") or result.get("results") or []
                    return [str(c) for c in ctx] if ctx else []
                if isinstance(result, list):
                    return [str(r) for r in result if r]
                return []
            except TypeError:
                continue
            except Exception as e:
                logger.debug("[openmemo] recall_context attempt failed: %s", e)
                continue
        return []

    def search_memory(self, query: str, scene: str = "",
                      agent_id: str = "",
                      limit: int = 10) -> List[dict]:
        for kwargs in [
            {"query": query, "scene": scene, "agent_id": agent_id, "limit": limit},
            {"query": query, "scene": scene, "limit": limit},
            {"query": query, "limit": limit},
        ]:
            try:
                results = self._memory.search_memory(**kwargs)
                if isinstance(results, list):
                    return results
                return []
            except TypeError:
                continue
            except Exception as e:
                logger.debug("[openmemo] search_memory attempt failed: %s", e)
                continue
        return []

    def list_scenes(self, agent_id: str = "") -> List[str]:
        try:
            return self._memory.list_scenes(agent_id=agent_id) or []
        except TypeError:
            try:
                return self._memory.list_scenes() or []
            except Exception:
                return []
        except Exception:
            return []

    def close(self):
        try:
            self._memory.close()
        except Exception:
            pass
