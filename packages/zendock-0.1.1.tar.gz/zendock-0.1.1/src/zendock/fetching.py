from __future__ import annotations

from pathlib import Path
from urllib.request import urlopen

from .utils import ensure_directory


class RcsbStructureFetcher:
    """Fetches raw PDB structures from the RCSB archive."""

    def __init__(self, timeout: float = 30.0):
        self.timeout = timeout

    def fetch_pdb(self, pdb_id: str, output_dir: str | Path = "receptors") -> str:
        receptor_dir = ensure_directory(Path(output_dir) / pdb_id)
        raw_pdb_path = receptor_dir / f"{pdb_id}.pdb"
        url = f"https://files.rcsb.org/view/{pdb_id}.pdb"
        with urlopen(url, timeout=self.timeout) as response:
            raw_pdb_path.write_bytes(response.read())
        return str(raw_pdb_path)


DEFAULT_STRUCTURE_FETCHER = RcsbStructureFetcher()

