from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class DockingPose:
    pose_index: int
    pdbqt_block: str
    energy: list[Any] = field(default_factory=list)
    pdbqt_path: Path | None = None
    pdb_path: Path | None = None
    sdf_path: Path | None = None

    @property
    def pose_number(self) -> int:
        return self.pose_index + 1


@dataclass
class LigandResult:
    ligand_name: str
    receptor_name: str
    poses: list[DockingPose]
    result_dir: Path | None = None

    @property
    def best_pose(self) -> DockingPose:
        if not self.poses:
            raise ValueError(f"No poses are available for ligand '{self.ligand_name}'.")
        return self.poses[0]


@dataclass
class DockingResult:
    receptor_name: str
    ligand_results: dict[str, LigandResult] = field(default_factory=dict)
    result_dir: Path | None = None

    def add_ligand_result(self, ligand_result: LigandResult) -> None:
        self.ligand_results[ligand_result.ligand_name] = ligand_result

    def get_ligand(self, ligand_name: str) -> LigandResult:
        try:
            return self.ligand_results[ligand_name]
        except KeyError as exc:
            raise ValueError(f"Unknown ligand '{ligand_name}'.") from exc


def split_pose_models(poses: str) -> list[str]:
    """Split a Vina PDBQT pose string into individual pose blocks."""

    if "MODEL" not in poses:
        stripped = poses.strip()
        return [stripped] if stripped else []

    models: list[str] = []
    for block in poses.split("ENDMDL"):
        stripped = block.strip()
        if stripped:
            models.append(f"{stripped}\nENDMDL")
    return models

