from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .exceptions import PreparationError
from .models import PreparedLigand
from .tools import CommandSpec
from .utils import ensure_directory, require_dependency, run_command


@dataclass
class Ligand:
    """Ligand preparation facade for SMILES or PDB inputs."""

    name: str
    smiles: str = ""
    ph: float = 7.4
    skip_tautomer: bool = False
    skip_acidbase: bool = True
    output_dir: str | Path = "ligands"
    pdbqt_path: str | None = None
    pdb_path: str | None = None
    sdf_path: str | None = None
    prepared: PreparedLigand | None = None

    def _resolve_output_dir(self, output_dir: str | Path | None = None) -> Path:
        """Return the output directory for ligand artifacts."""
        return Path(self.output_dir) if output_dir is None else Path(output_dir)

    def _build_output_paths(
        self,
        output_dir: str | Path | None = None,
        *,
        sdf_filename: str,
    ) -> tuple[Path, Path]:
        """Create the ligand output directory and return SDF/PDBQT paths."""
        ligand_dir = ensure_directory(self._resolve_output_dir(output_dir) / self.name)
        ligand_sdf = ligand_dir / sdf_filename
        ligand_pdbqt = ligand_dir / f"{self.name}.pdbqt"
        return ligand_sdf, ligand_pdbqt

    def _prepare_pdbqt(self, ligand_sdf: Path, ligand_pdbqt: Path) -> None:
        """Run the ligand preparation command that generates a PDBQT file."""
        run_command(self._prepare_pdbqt_command(ligand_sdf, ligand_pdbqt))

    def _prepare_pdbqt_command(self, ligand_sdf: Path, ligand_pdbqt: Path) -> CommandSpec:
        return CommandSpec(
            "mk_prepare_ligand.py",
            ("-i", str(ligand_sdf), "-o", str(ligand_pdbqt)),
        )

    def _scrub_command(self, ligand_sdf: Path) -> CommandSpec:
        args = [self.smiles, "-o", str(ligand_sdf), "--ph", str(self.ph)]
        if self.skip_tautomer:
            args.append("--skip_tautomer")
        if self.skip_acidbase:
            args.append("--skip_acidbase")
        return CommandSpec("scrub.py", tuple(args))

    def _store_prepared_paths(
        self,
        ligand_sdf: Path,
        ligand_pdbqt: Path,
    ) -> None:
        """Persist prepared ligand file paths on the instance."""
        self.sdf_path = str(ligand_sdf)
        self.pdbqt_path = str(ligand_pdbqt)
        self.prepared = PreparedLigand(
            name=self.name,
            pdbqt_path=ligand_pdbqt,
            sdf_path=ligand_sdf,
            pdb_path=Path(self.pdb_path) if self.pdb_path is not None else None,
        )

    def prepare_ligand(
        self,
        output_dir: str | Path | None = None,
    ) -> tuple[str, str]:
        if not self.smiles:
            raise ValueError(
                "No SMILES string provided. Use prepare_from_pdb() for PDB inputs."
            )

        ligand_sdf, ligand_pdbqt = self._build_output_paths(
            output_dir,
            sdf_filename=f"{self.name}_scrubbed.sdf",
        )

        try:
            run_command(self._scrub_command(ligand_sdf))
            self._prepare_pdbqt(ligand_sdf, ligand_pdbqt)
        except Exception as exc:
            raise PreparationError(f"Failed to prepare ligand '{self.name}'.") from exc

        self._store_prepared_paths(ligand_sdf, ligand_pdbqt)
        return self.pdbqt_path, self.sdf_path

    def prepare_from_pdb(
        self,
        pdb_path: str | None = None,
        output_dir: str | Path | None = None,
    ) -> str:
        chem = require_dependency("rdkit.Chem")

        source_pdb = pdb_path or self.pdb_path
        if source_pdb is None:
            raise ValueError(
                "No PDB path provided. Pass pdb_path or set self.pdb_path."
            )

        self.pdb_path = source_pdb
        ligand_sdf, ligand_pdbqt = self._build_output_paths(
            output_dir,
            sdf_filename=f"{self.name}.sdf",
        )

        mol = chem.MolFromPDBFile(str(source_pdb), removeHs=False)
        if mol is None:
            raise PreparationError(f"RDKit failed to read PDB file: {source_pdb}")

        fragments = chem.GetMolFrags(mol, asMols=True, sanitizeFrags=False)
        if len(fragments) > 1:
            mol = max(fragments, key=lambda fragment: fragment.GetNumAtoms())

        mol = chem.AddHs(mol, addCoords=True)
        writer = chem.SDWriter(str(ligand_sdf))
        writer.write(mol)
        writer.close()

        try:
            self._prepare_pdbqt(ligand_sdf, ligand_pdbqt)
        except Exception as exc:
            raise PreparationError(
                f"Failed to convert ligand '{self.name}' from PDB."
            ) from exc

        self._store_prepared_paths(ligand_sdf, ligand_pdbqt)
        return self.pdbqt_path

    def visualize_ligand(self, width: int = 400, height: int = 400):
        py3dmol = require_dependency("py3Dmol")

        if self.sdf_path is None:
            raise ValueError(
                "Ligand files not prepared. Run prepare_ligand() or prepare_from_pdb() first."
            )

        sdf_path = Path(self.sdf_path)
        if not sdf_path.exists():
            raise FileNotFoundError(f"Prepared ligand SDF not found: {sdf_path}")

        view = py3dmol.view(width=width, height=height)
        view.addModel(sdf_path.read_text(), "sdf")
        view.zoomTo()
        view.setBackgroundColor("white")
        view.addStyle({"stick": {"colorscheme": "cyanCarbon"}})
        return view
