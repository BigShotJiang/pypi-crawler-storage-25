from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class OutputLayout:
    """Centralized default output paths for docking workflows."""

    root: str | Path = "."
    ligand_dir_name: str = "ligands"
    receptor_dir_name: str = "receptors"
    docking_results_dir_name: str = "Docking_Result"
    docking_pose_dir_name: str = "Docking_Pose"

    def _under_root(self, path: str | Path) -> Path:
        resolved = Path(path)
        return resolved if resolved.is_absolute() else Path(self.root) / resolved

    @property
    def ligand_dir(self) -> Path:
        return self._under_root(self.ligand_dir_name)

    @property
    def receptor_dir(self) -> Path:
        return self._under_root(self.receptor_dir_name)

    @property
    def docking_results_dir(self) -> Path:
        return self._under_root(self.docking_results_dir_name)

    @property
    def docking_pose_dir(self) -> Path:
        return self._under_root(self.docking_pose_dir_name)

    def receptor_interaction_dir(self, receptor_json_path: str | Path) -> Path:
        return self.docking_results_dir

    def docking_pose_html(self, ligand_name: str, receptor_name: str, pose_number: int) -> Path:
        return self.docking_pose_dir / f"{ligand_name}_{receptor_name}_pose{pose_number}.html"


DEFAULT_OUTPUT_LAYOUT = OutputLayout()

