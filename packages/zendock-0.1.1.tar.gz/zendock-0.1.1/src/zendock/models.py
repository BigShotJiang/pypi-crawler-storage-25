from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class RawReceptor:
    name: str
    pdb_id: str
    pdb_path: Path


@dataclass(frozen=True)
class ParsedReceptor:
    name: str
    raw_pdb_path: Path
    structure_path: Path
    receptor_selection: str


@dataclass(frozen=True)
class PreparedReceptor:
    name: str
    pdbqt_path: Path
    prepared_pdb_path: Path
    json_path: Path
    box_center: tuple[float, float, float]
    box_size: tuple[float, float, float]


@dataclass(frozen=True)
class PreparedLigand:
    name: str
    pdbqt_path: Path
    sdf_path: Path | None = None
    pdb_path: Path | None = None

