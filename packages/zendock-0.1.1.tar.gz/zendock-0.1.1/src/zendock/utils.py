from __future__ import annotations

from importlib import import_module
from pathlib import Path
from typing import Any

from .exceptions import DependencyNotAvailableError
from .tools import CommandSpec, ToolRunner, run_command


def ensure_directory(path: str | Path) -> Path:
    target = Path(path)
    target.mkdir(parents=True, exist_ok=True)
    return target


def require_dependency(module_name: str) -> Any:
    try:
        return import_module(module_name)
    except ImportError as exc:
        raise DependencyNotAvailableError(
            f"Dependency '{module_name}' is required for this operation. Install the full package dependencies first."
        ) from exc


def export_visualization(view, output_path: str | Path, title: str) -> str:
    resolved_output_path = Path(output_path)
    ensure_directory(resolved_output_path.parent)

    html_fragment = view._make_html()
    html_content = (
        "<!DOCTYPE html>\n"
        '<html lang="en">\n'
        "<head>\n"
        '    <meta charset="utf-8">\n'
        '    <meta name="viewport" content="width=device-width, initial-scale=1">\n'
        f"    <title>{title}</title>\n"
        "    <style>\n"
        "        body {\n"
        "            margin: 0;\n"
        "            min-height: 100vh;\n"
        "            display: flex;\n"
        "            align-items: center;\n"
        "            justify-content: center;\n"
        "            background: white;\n"
        "        }\n"
        "        .viewer-shell {\n"
        "            max-width: 100%;\n"
        "            padding: 16px;\n"
        "            box-sizing: border-box;\n"
        "        }\n"
        "    </style>\n"
        "</head>\n"
        "<body>\n"
        '    <div class="viewer-shell">\n'
        f"{html_fragment}\n"
        "    </div>\n"
        "</body>\n"
        "</html>\n"
    )
    with resolved_output_path.open("w", encoding="utf-8") as f:
        f.write(html_content)
    return str(resolved_output_path)
