from __future__ import annotations

from pathlib import Path

from .exceptions import DockingExecutionError
from .results import LigandResult
from .tools import CommandSpec
from .utils import ensure_directory, run_command


class DockingResultStore:
    """Persists docking results using the current best-pose export policy."""

    def __init__(self, output_dir: str | Path):
        self.output_dir = ensure_directory(output_dir)

    def save_best_pose(
        self,
        ligand_result: LigandResult,
        receptor_json_path: str | Path,
    ) -> Path:
        ligand_name = ligand_result.ligand_name
        receptor_name = ligand_result.receptor_name
        best_pose = ligand_result.best_pose

        output_pdbqt = self.output_dir / f"{ligand_name}_{receptor_name}.pdbqt"
        output_pdb = self.output_dir / f"{ligand_name}_{receptor_name}.pdb"
        output_sdf = self.output_dir / f"{ligand_name}_{receptor_name}.sdf"
        output_pdbqt.write_text(best_pose.pdbqt_block)
        best_pose.pdbqt_path = output_pdbqt

        try:
            run_command(
                CommandSpec(
                    "mk_export.py",
                    (
                        str(output_pdbqt),
                        "-j",
                        str(receptor_json_path),
                        "-s",
                        str(output_sdf),
                        "-p",
                        str(output_pdb),
                    ),
                )
            )
        except Exception as exc:
            raise DockingExecutionError(
                f"Failed to export docking result for '{ligand_name}'."
            ) from exc

        best_pose.pdb_path = output_pdb
        best_pose.sdf_path = output_sdf
        ligand_result.result_dir = self.output_dir
        return output_sdf

