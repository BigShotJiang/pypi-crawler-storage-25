from __future__ import annotations

from pathlib import Path

from .exceptions import PreparationError
from .fetching import DEFAULT_STRUCTURE_FETCHER
from .models import ParsedReceptor, PreparedReceptor, RawReceptor
from .tools import CommandSpec
from .utils import (
    export_visualization,
    require_dependency,
    run_command,
    ensure_directory,
)


class StructureFetcher:
    @staticmethod
    def fetch_pdb(pdb_id: str, output_dir: str | Path = "receptors") -> str:
        """Download a PDB structure from the RCSB archive."""
        return DEFAULT_STRUCTURE_FETCHER.fetch_pdb(pdb_id, output_dir)


class ProteinLigandParser:
    @staticmethod
    def parse_receptor(
        raw_pdb_path: str,
        receptor_selection: str = "not water and not hetero",
        output_dir: str | Path = "receptors",
        receptor_name: str | None = None,
    ) -> str:
        """Extract receptor atoms from a raw PDB file and write them to disk.

        Args:
            raw_pdb_path: Path to the input PDB structure.
            receptor_selection: ProDy selection string used to keep receptor atoms.
                The default excludes waters and hetero atoms, matching the intended
                LePro-style receptor extraction workflow.
            output_dir: Base directory where the parsed receptor file will be stored.
            receptor_name: Optional output name. Defaults to the input file stem.

        Returns:
            Path to the parsed receptor PDB file.

        Raises:
            PreparationError: If no atoms match the requested selection.
        """
        prody = require_dependency("prody")

        atoms = prody.parsePDB(raw_pdb_path, altloc="A", occupancy=0.5)
        receptor_atoms = atoms.select(receptor_selection)
        if receptor_atoms is None or receptor_atoms.numAtoms() == 0:
            raise PreparationError(
                f"No atoms matched selection '{receptor_selection}'."
            )

        output_name = receptor_name or Path(raw_pdb_path).stem
        receptor_dir = ensure_directory(Path(output_dir) / output_name)
        structure_path = receptor_dir / f"{output_name}_receptor_atoms.pdb"
        prody.writePDB(str(structure_path), receptor_atoms)
        return str(structure_path)

    @staticmethod
    def list_residue_names(raw_pdb_path: str, selection: str = "all") -> list[str]:
        """List unique residue names present in a PDB structure.

        Args:
            raw_pdb_path: Path to the input PDB structure.
            selection: ProDy selection string used to filter atoms before collecting
                residue names.

        Returns:
            Sorted unique residue names from the selected atoms. Returns an empty
            list when the selection matches nothing.
        """
        prody = require_dependency("prody")

        atoms = prody.parsePDB(raw_pdb_path)
        selected = atoms.select(selection) if atoms is not None else None
        if selected is None:
            return []
        return sorted(set(selected.getResnames()))


class LigandSelector:
    @staticmethod
    def _build_residue_selection(
        resname: str,
        chain: str | None = None,
        resnum: int | None = None,
    ) -> str:
        """Build a ProDy selection string for a residue identity."""
        selection_parts = [f"resname {resname}"]
        if chain is not None:
            selection_parts.append(f"chain {chain}")
        if resnum is not None:
            selection_parts.append(f"resnum {resnum}")
        return " and ".join(selection_parts)

    @staticmethod
    def _resolve_residue_identity(
        atoms,
        full_selection: str,
        resname: str,
    ) -> tuple[object, str, int]:
        """Resolve a selection to exactly one residue identity."""
        ligand_atoms = atoms.select(full_selection) if atoms is not None else None
        if ligand_atoms is None:
            raise PreparationError(f"No atoms matched selection: {full_selection}")

        residue_pairs = sorted(
            {
                (chid, residue_number)
                for residue_number, chid in zip(
                    ligand_atoms.getResnums(), ligand_atoms.getChids()
                )
            },
            key=lambda item: (item[0], item[1]),
        )
        if len(residue_pairs) > 1:
            duplicates = "\n".join(
                f"- chain {matched_chain}, resnum {matched_resnum}"
                for matched_chain, matched_resnum in residue_pairs
            )
            example_chain, example_resnum = residue_pairs[0]
            raise PreparationError(
                "Duplicate residues found!\n"
                "Matching residues:\n"
                f"{duplicates}\n\n"
                "Please specify the residue explicitly, for example:\n"
                "choose_reference_ligand(\n"
                f'    resname="{resname}",\n'
                f'    chain="{example_chain}",\n'
                f"    resnum={example_resnum},\n"
                ")"
            )

        matched_chain, matched_resnum = residue_pairs[0]
        resolved_selection = LigandSelector._build_residue_selection(
            resname,
            chain=matched_chain,
            resnum=matched_resnum,
        )
        resolved_atoms = atoms.select(resolved_selection)
        return resolved_atoms, matched_chain, matched_resnum

    @staticmethod
    def choose_reference_ligand(
        raw_pdb_path: str,
        receptor_name: str,
        resname: str,
        chain: str | None = None,
        resnum: int | None = None,
        output_dir: str | Path = "receptors",
    ) -> str:
        """Extract a reference ligand residue from a raw PDB structure.

        Args:
            raw_pdb_path: Path to the input PDB structure.
            receptor_name: Receptor name used to build the output path.
            resname: Residue name of the ligand to extract.
            chain: Optional chain identifier used to disambiguate matching residues.
            resnum: Optional residue number used to disambiguate matching residues.
            output_dir: Base directory where the ligand file will be stored.

        Returns:
            Path to the extracted ligand PDB file created using ProDy.

        Raises:
            PreparationError: If no atoms match the requested residue or the
                provided inputs still match multiple residues.
        """
        prody = require_dependency("prody")

        atoms = prody.parsePDB(raw_pdb_path)
        full_selection = LigandSelector._build_residue_selection(
            resname,
            chain=chain,
            resnum=resnum,
        )
        ligand_atoms, _, _ = LigandSelector._resolve_residue_identity(
            atoms,
            full_selection,
            resname,
        )

        receptor_dir = ensure_directory(Path(output_dir) / receptor_name)
        ligand_pdb = receptor_dir / f"{receptor_name}_ligand_atoms.pdb"
        prody.writePDB(str(ligand_pdb), ligand_atoms)
        return str(ligand_pdb)


class BoxConfigurator:
    @staticmethod
    def calculate_box_center(ligand_pdb_path: str) -> tuple[float, float, float]:
        """Compute the docking box center from a ligand structure.

        Args:
            ligand_pdb_path: Path to the ligand PDB file.

        Returns:
            Mass-weighted center of the ligand as ``(x, y, z)``.
        """
        prody = require_dependency("prody")

        atoms = prody.parsePDB(ligand_pdb_path)
        center = prody.calcCenter(atoms, weights=atoms.getMasses())
        return (float(center[0]), float(center[1]), float(center[2]))

    @staticmethod
    def set_box_size(
        box_size: tuple[float, float, float] | None = None,
    ) -> tuple[float, float, float]:
        """Return the docking box size to use for receptor preparation.

        Args:
            box_size: Optional explicit box dimensions as ``(x, y, z)``.

        Returns:
            The provided box size, or the default ``(20.0, 20.0, 20.0)`` when no
            value is supplied.
        """
        return box_size or (20.0, 20.0, 20.0)


class ReceptorPreparator:
    @staticmethod
    def prepare_receptor_command(
        structure_path: str,
        receptor_pdbqt: Path,
        prepared_pdb: Path,
        receptor_json: Path,
        box_center: tuple[float, float, float],
        box_size: tuple[float, float, float],
    ) -> CommandSpec:
        cx, cy, cz = box_center
        sx, sy, sz = box_size
        return CommandSpec(
            "mk_prepare_receptor.py",
            (
                "-i",
                structure_path,
                "-o",
                str(receptor_pdbqt),
                "--write_pdb",
                str(prepared_pdb),
                "--write_pdbqt",
                str(receptor_pdbqt),
                "--write_json",
                str(receptor_json),
                "--box_center",
                str(cx),
                str(cy),
                str(cz),
                "--box_size",
                str(sx),
                str(sy),
                str(sz),
                "--allow_bad_res",
                "--default_altloc",
                "A",
                "-v",
            ),
        )

    @staticmethod
    def prepare_receptor(
        structure_path: str,
        receptor_name: str,
        box_center: tuple[float, float, float],
        box_size: tuple[float, float, float],
        output_dir: str | Path = "receptors",
    ) -> tuple[str, str, str]:
        """Prepare a receptor structure and generate docking input files.

        Args:
            structure_path: Path to the parsed receptor PDB file.
            receptor_name: Receptor name used to build output filenames.
            box_center: Docking box center as ``(x, y, z)``.
            box_size: Docking box dimensions as ``(x, y, z)``.
            output_dir: Base directory where prepared receptor files will be stored.

        Returns:
            Tuple containing paths to the prepared PDBQT, prepared PDB, and JSON
            metadata files.

        Raises:
            PreparationError: If receptor preparation fails.
        """
        receptor_dir = ensure_directory(Path(output_dir) / receptor_name)
        base = receptor_dir / receptor_name
        receptor_pdbqt = base.with_suffix(".pdbqt")
        receptor_json = base.with_suffix(".json")
        prepared_pdb = receptor_dir / f"{receptor_name}_prepared.pdb"
        try:
            run_command(
                ReceptorPreparator.prepare_receptor_command(
                    structure_path,
                    receptor_pdbqt,
                    prepared_pdb,
                    receptor_json,
                    box_center,
                    box_size,
                )
            )
        except Exception as exc:
            raise PreparationError(
                f"Failed to prepare receptor '{receptor_name}'."
            ) from exc

        return str(receptor_pdbqt), str(prepared_pdb), str(receptor_json)


class Receptor:
    def __init__(
        self,
        name: str,
        pdb_id: str,
        output_dir: str | Path = "receptors",
    ):
        """Initialize a receptor workflow object.

        Args:
            name: User-defined receptor name used for output files.
            pdb_id: PDB accession identifier used to download the structure.
            output_dir: Base directory where receptor workflow files are stored by
                default.
        """
        self.name = name
        self.pdb_id = pdb_id
        self.output_dir = Path(output_dir)
        self.receptor_selection = "not water and not hetero"
        self.selected_residue: dict[str, str | int] | None = None
        self.box_size: tuple[float, float, float] | None = None
        self.box_center: tuple[float, float, float] | None = None
        self.structure_path: str | None = None
        self.pdbqt_path: str | None = None
        self.raw_pdb_path: str | None = None
        self.prody_ligand_pdb: str | None = None
        self.prepared_pdb_path: str | None = None
        self.json_path: str | None = None
        self.raw_receptor: RawReceptor | None = None
        self.parsed_receptor: ParsedReceptor | None = None
        self.prepared_receptor: PreparedReceptor | None = None

    def download_structure(self, output_dir: str | Path | None = None) -> str:
        """Download the receptor structure and store its raw PDB path.

        Args:
            output_dir: Optional base directory where the raw PDB file will be
                stored. Defaults to the instance output directory.

        Returns:
            Path to the downloaded raw PDB file.
        """
        resolved_output_dir = (
            self.output_dir if output_dir is None else Path(output_dir)
        )
        self.raw_pdb_path = StructureFetcher.fetch_pdb(self.pdb_id, resolved_output_dir)
        self.raw_receptor = RawReceptor(
            name=self.name,
            pdb_id=self.pdb_id,
            pdb_path=Path(self.raw_pdb_path),
        )
        return self.raw_pdb_path

    def parse_receptor(self, output_dir: str | Path | None = None) -> str:
        """Parse the downloaded structure into receptor-only atoms.

        Args:
            output_dir: Optional base directory where the parsed receptor file will
                be stored. Defaults to the instance output directory.

        Returns:
            Path to the parsed receptor PDB file.

        Raises:
            ValueError: If the raw PDB file has not been downloaded yet.
        """
        if self.raw_pdb_path is None:
            raise ValueError(
                "No raw receptor PDB is set. Run download_structure() first."
            )

        resolved_output_dir = (
            self.output_dir if output_dir is None else Path(output_dir)
        )
        parsed_path = ProteinLigandParser.parse_receptor(
            self.raw_pdb_path,
            receptor_selection=self.receptor_selection,
            output_dir=resolved_output_dir,
            receptor_name=self.name,
        )
        self.structure_path = parsed_path
        self.parsed_receptor = ParsedReceptor(
            name=self.name,
            raw_pdb_path=Path(self.raw_pdb_path),
            structure_path=Path(parsed_path),
            receptor_selection=self.receptor_selection,
        )
        return self.structure_path

    def list_resnames(self, selection: str = "all") -> list[str]:
        """List residue names from the downloaded structure.

        Args:
            selection: ProDy selection string used to filter atoms before listing
                residue names.

        Returns:
            Sorted unique residue names from the selected atoms.

        Raises:
            ValueError: If the raw PDB file has not been downloaded yet.
        """
        if self.raw_pdb_path is None:
            raise ValueError(
                "No raw receptor PDB is set. Run download_structure() first."
            )

        return ProteinLigandParser.list_residue_names(self.raw_pdb_path, selection)

    def choose_reference_ligand(
        self,
        resname: str | None = None,
        chain: str | None = None,
        resnum: int | None = None,
        output_dir: str | Path | None = None,
    ) -> str:
        """Extract and store a reference ligand from the downloaded structure.

        Args:
            resname: Optional residue name of the ligand to extract. When omitted,
                the stored selected residue name is reused.
            chain: Optional chain identifier used to disambiguate the ligand residue.
            resnum: Optional residue number used to disambiguate the ligand residue.
            output_dir: Optional base directory where the ligand file will be
                stored. Defaults to the instance output directory.

        Returns:
            Path to the extracted ligand PDB file.

        Raises:
            ValueError: If the raw PDB file has not been downloaded or no ligand
                residue name is available.
        """
        if self.raw_pdb_path is None:
            raise ValueError(
                "No raw receptor PDB is set. Run download_structure() first."
            )

        selected_residue = self.selected_residue or {}
        resolved_resname = resname or selected_residue.get("resname")
        resolved_chain = chain or selected_residue.get("chain")
        resolved_resnum = (
            resnum if resnum is not None else selected_residue.get("resnum")
        )
        if resolved_resname is None:
            raise ValueError("No residue name provided.")

        resolved_output_dir = (
            self.output_dir if output_dir is None else Path(output_dir)
        )
        atoms = require_dependency("prody").parsePDB(self.raw_pdb_path)
        full_selection = LigandSelector._build_residue_selection(
            resolved_resname,
            chain=resolved_chain if isinstance(resolved_chain, str) else None,
            resnum=resolved_resnum if isinstance(resolved_resnum, int) else None,
        )
        _, matched_chain, matched_resnum = LigandSelector._resolve_residue_identity(
            atoms,
            full_selection,
            resolved_resname,
        )

        self.prody_ligand_pdb = LigandSelector.choose_reference_ligand(
            self.raw_pdb_path,
            receptor_name=self.name,
            resname=resolved_resname,
            chain=matched_chain,
            resnum=matched_resnum,
            output_dir=resolved_output_dir,
        )
        self.selected_residue = {
            "resname": resolved_resname,
            "chain": matched_chain,
            "resnum": matched_resnum,
        }
        return self.prody_ligand_pdb

    def calculate_box_center(
        self, ligand_pdb_path: str | None = None
    ) -> tuple[float, float, float]:
        """Calculate and store the docking box center from a ligand structure.

        Args:
            ligand_pdb_path: Optional ligand PDB path. When omitted, the stored
                reference ligand path is used.

        Returns:
            Mass-weighted ligand center as ``(x, y, z)``.

        Raises:
            ValueError: If no ligand PDB path is available.
        """
        source_ligand = ligand_pdb_path or self.prody_ligand_pdb
        if source_ligand is None:
            raise ValueError(
                "No ligand PDB path set. Run choose_reference_ligand() first."
            )

        self.box_center = BoxConfigurator.calculate_box_center(source_ligand)
        return self.box_center

    def set_box_size(
        self, box_size: tuple[float, float, float] | None = None
    ) -> tuple[float, float, float]:
        """Set and store the docking box dimensions.

        Args:
            box_size: Optional explicit box dimensions as ``(x, y, z)``.

        Returns:
            The stored docking box size.
        """
        self.box_size = BoxConfigurator.set_box_size(box_size)
        return self.box_size

    def prepare_receptor(
        self, output_dir: str | Path | None = None
    ) -> tuple[str, str, str]:
        """Prepare the receptor for docking using the stored box settings.

        Args:
            output_dir: Optional base directory where prepared receptor files will
                be stored. Defaults to the instance output directory.

        Returns:
            Tuple containing paths to the prepared PDBQT, prepared PDB, and JSON
            metadata files.

        Raises:
            ValueError: If the parsed receptor or docking box settings are missing.
        """
        if self.structure_path is None:
            raise ValueError(
                "Receptor structure not parsed. Run parse_receptor() first."
            )
        if self.box_center is None or self.box_size is None:
            raise ValueError(
                "Set box_center and box_size before preparing the receptor."
            )

        resolved_output_dir = (
            self.output_dir if output_dir is None else Path(output_dir)
        )
        self.pdbqt_path, self.prepared_pdb_path, self.json_path = (
            ReceptorPreparator.prepare_receptor(
                self.structure_path,
                receptor_name=self.name,
                box_center=self.box_center,
                box_size=self.box_size,
                output_dir=resolved_output_dir,
            )
        )
        self.prepared_receptor = PreparedReceptor(
            name=self.name,
            pdbqt_path=Path(self.pdbqt_path),
            prepared_pdb_path=Path(self.prepared_pdb_path),
            json_path=Path(self.json_path),
            box_center=self.box_center,
            box_size=self.box_size,
        )
        return self.pdbqt_path, self.prepared_pdb_path, self.json_path

    def visualize_raw_receptor(
        self,
        width: int = 400,
        height: int = 400,
        save_html: bool = False,
        output_path: str | Path | None = None,
    ):
        """Build a 3D view of the downloaded receptor structure.

        Args:
            width: Viewer width in pixels.
            height: Viewer height in pixels.
            save_html: Whether to also save the rendered view as HTML.
            output_path: Optional HTML output path. Defaults to
                ``<instance output dir>/<name>_raw.html``.

        Returns:
            A ``py3Dmol`` view object containing the raw receptor representation.

        Raises:
            ValueError: If the raw PDB file has not been downloaded yet.
        """
        py3dmol = require_dependency("py3Dmol")

        if self.raw_pdb_path is None:
            raise ValueError(
                "Receptor structure not downloaded. Run download_structure() first."
            )

        view = py3dmol.view(width=width, height=height)
        view.addModel(Path(self.raw_pdb_path).read_text(), "pdb")
        view.setStyle({"protein": True}, {"cartoon": {"colorscheme": "spectrum"}})
        view.zoomTo()
        view.setBackgroundColor("white")

        if save_html:
            resolved_output_path = (
                self.output_dir / f"{self.name}_raw.html"
                if output_path is None
                else Path(output_path)
            )
            export_visualization(
                view,
                resolved_output_path,
                title=f"{self.name} raw visualization",
            )
            print(f"Saved raw receptor visualization to {resolved_output_path}")

        return view

    def visualize_prepared_receptor(
        self,
        width: int = 800,
        height: int = 800,
        save_html: bool = False,
        output_path: str | Path | None = None,
    ):
        """Build a 3D view of the prepared receptor and docking box.

        Args:
            width: Viewer width in pixels.
            height: Viewer height in pixels.
            save_html: Whether to also save the rendered view as HTML.
            output_path: Optional HTML output path. Defaults to
                ``<instance output dir>/<name>_prepared.html``.

        Returns:
            A ``py3Dmol`` view object containing the prepared receptor and box.

        Raises:
            ValueError: If the prepared receptor or box settings are missing.
        """
        py3dmol = require_dependency("py3Dmol")

        if self.prepared_pdb_path is None:
            raise ValueError(
                "Prepared receptor not found. Run prepare_receptor() first."
            )
        if self.box_center is None or self.box_size is None:
            raise ValueError("Box center and box size are required for visualization.")

        cx, cy, cz = self.box_center
        sx, sy, sz = self.box_size
        view = py3dmol.view(width=width, height=height)
        view.addModel(Path(self.prepared_pdb_path).read_text(), "pdb")
        view.setStyle({"cartoon": {"colorscheme": "spectrum"}})
        view.addStyle({"hetflag": True}, {"stick": {"colorscheme": "greenCarbon"}})
        view.addBox(
            {
                "center": {"x": cx, "y": cy, "z": cz},
                "dimensions": {"w": sx, "h": sy, "d": sz},
                "color": "blue",
                "opacity": 0.6,
            }
        )
        view.zoomTo()
        view.setBackgroundColor("white")

        if save_html:
            resolved_output_path = (
                self.output_dir / f"{self.name}_prepared.html"
                if output_path is None
                else Path(output_path)
            )
            export_visualization(
                view,
                resolved_output_path,
                title=f"{self.name} prepared visualization",
            )
            print(f"Saved prepared receptor visualization to {resolved_output_path}")

        return view
