from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import subprocess
from typing import Mapping

from .exceptions import CommandExecutionError


@dataclass(frozen=True)
class CommandSpec:
    """Description of an external command invocation."""

    executable: str
    args: tuple[str, ...] = ()
    cwd: str | Path | None = None
    env: Mapping[str, str] | None = None
    timeout: float | None = None

    @classmethod
    def from_sequence(
        cls,
        command: list[str] | tuple[str, ...],
        *,
        cwd: str | Path | None = None,
        timeout: float | None = None,
    ) -> "CommandSpec":
        if not command:
            raise ValueError("Command cannot be empty.")
        return cls(command[0], tuple(str(part) for part in command[1:]), cwd=cwd, timeout=timeout)

    @property
    def argv(self) -> list[str]:
        return [self.executable, *self.args]


@dataclass
class ToolRunner:
    """Executes external scientific command-line tools."""

    base_env: Mapping[str, str] = field(default_factory=dict)

    def run(self, spec: CommandSpec) -> subprocess.CompletedProcess[str]:
        env = None
        if self.base_env or spec.env:
            env = {**self.base_env, **(spec.env or {})}

        result = subprocess.run(
            spec.argv,
            capture_output=True,
            text=True,
            cwd=spec.cwd,
            env=env,
            timeout=spec.timeout,
        )
        if result.returncode != 0:
            joined = " ".join(spec.argv)
            raise CommandExecutionError(
                f"Command failed: {joined}\nstdout:\n{result.stdout}\nstderr:\n{result.stderr}"
            )
        return result


DEFAULT_TOOL_RUNNER = ToolRunner()


def run_command(
    command: list[str] | tuple[str, ...] | CommandSpec,
    *,
    cwd: str | Path | None = None,
    timeout: float | None = None,
    runner: ToolRunner | None = None,
) -> subprocess.CompletedProcess[str]:
    """Compatibility wrapper for executing an external command."""

    spec = command if isinstance(command, CommandSpec) else CommandSpec.from_sequence(command, cwd=cwd, timeout=timeout)
    return (runner or DEFAULT_TOOL_RUNNER).run(spec)

