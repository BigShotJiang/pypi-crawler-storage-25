from __future__ import annotations

from copy import deepcopy
from pathlib import Path
import tempfile
from typing import Any

from .exceptions import DockingExecutionError
from .ligand import Ligand
from .receptor import Receptor
from .result_store import DockingResultStore
from .results import DockingPose, DockingResult, LigandResult, split_pose_models
from .tools import CommandSpec
from .utils import (
    export_visualization,
    ensure_directory,
    require_dependency,
    run_command,
)
from .workspace import DEFAULT_OUTPUT_LAYOUT, OutputLayout


class DockingRunner:
    def __init__(self, receptor: Receptor, output_layout: OutputLayout | None = None):
        self.receptor = receptor
        self.output_layout = output_layout or DEFAULT_OUTPUT_LAYOUT
        self.ligands: dict[str, Ligand] = {}
        self.vina_instance = None
        self.last_poses: dict[str, str] = {}
        self.last_energies: dict[str, list] = {}
        self.results_dir: str | None = None
        self.last_result: DockingResult | None = None

    def add_ligand(self, ligand: Ligand) -> Ligand:
        if ligand.pdbqt_path is None:
            raise ValueError("Ligand must be prepared before adding it to docking.")
        self.ligands[ligand.name] = ligand
        return ligand

    def list_ligands(self) -> list[str]:
        return list(self.ligands)

    def list_receptors(self) -> list[str]:
        return [self.receptor.name]

    def setup_vina(self):
        vina = require_dependency("vina")

        if (
            self.receptor.pdbqt_path is None
            or self.receptor.box_center is None
            or self.receptor.box_size is None
        ):
            raise ValueError(
                "Prepared receptor, box center, and box size are required before setup."
            )

        cx, cy, cz = self.receptor.box_center
        sx, sy, sz = self.receptor.box_size
        self.vina_instance = vina.Vina(sf_name="vina", verbosity=2)
        self.vina_instance.set_receptor(rigid_pdbqt_filename=self.receptor.pdbqt_path)
        self.vina_instance.compute_vina_maps(center=[cx, cy, cz], box_size=[sx, sy, sz])
        return self.vina_instance

    def run_docking(self, exhaustiveness: int = 8, n_poses: int = 10) -> dict[str, str]:
        if self.vina_instance is None:
            raise ValueError("Vina is not initialized. Run setup_vina() first.")
        if not self.ligands:
            raise ValueError("No ligands are registered for docking.")

        self.last_poses = {}
        self.last_energies = {}
        docking_result = DockingResult(receptor_name=self.receptor.name)
        for ligand_name, ligand in self.ligands.items():
            self.vina_instance.set_ligand_from_file(ligand.pdbqt_path)
            self.vina_instance.dock(exhaustiveness=exhaustiveness, n_poses=n_poses)
            poses = self.vina_instance.poses(n_poses=n_poses, energy_range=3.0)
            self.last_poses[ligand_name] = poses
            self.last_energies[ligand_name] = self.vina_instance.energies(
                n_poses=n_poses, energy_range=3.0
            )
            pose_models = split_pose_models(poses)
            ligand_result = LigandResult(
                ligand_name=ligand_name,
                receptor_name=self.receptor.name,
                poses=[
                    DockingPose(
                        pose_index=index,
                        pdbqt_block=model,
                        energy=self.last_energies[ligand_name][index]
                        if index < len(self.last_energies[ligand_name])
                        else [],
                    )
                    for index, model in enumerate(pose_models)
                ],
            )
            docking_result.add_ligand_result(ligand_result)
        self.last_result = docking_result
        return self.last_poses

    def save_docking_results(
        self, output_dir: str | Path | None = None
    ) -> dict[str, str]:
        if self.receptor.json_path is None:
            raise ValueError(
                "Prepared receptor JSON is required. Run receptor.prepare_receptor() first."
            )
        if not self.last_poses:
            raise ValueError("No docking poses are cached. Run run_docking() first.")

        destination = ensure_directory(output_dir or self.output_layout.docking_results_dir)
        self.results_dir = str(destination)
        if self.last_result is None:
            self.last_result = DockingResult(receptor_name=self.receptor.name)
        self.last_result.result_dir = destination
        outputs: dict[str, str] = {}

        for ligand_name, poses in self.last_poses.items():
            ligand_result = self.last_result.ligand_results.get(ligand_name)
            if ligand_result is None:
                pose_models = split_pose_models(poses)
                ligand_result = LigandResult(
                    ligand_name=ligand_name,
                    receptor_name=self.receptor.name,
                    poses=[
                        DockingPose(index, model)
                        for index, model in enumerate(pose_models)
                    ],
                )
                self.last_result.add_ligand_result(ligand_result)
            ligand_result.result_dir = destination
            output_sdf = DockingResultStore(destination).save_best_pose(
                ligand_result,
                self.receptor.json_path,
            )
            outputs[ligand_name] = str(output_sdf)
        return outputs

    def get_docking_summary(
        self, n_poses: int = 5
    ) -> dict[str, list[dict[str, float | int | None]]]:
        if not self.last_energies:
            raise ValueError(
                "No cached docking results found. Run run_docking() first."
            )

        summary: dict[str, list[dict[str, float | int | None]]] = {}
        for ligand_name, energies in self.last_energies.items():
            rows = []
            for index, energy in enumerate(energies[:n_poses]):
                rows.append(
                    {
                        "pose": index + 1,
                        "affinity": energy[0],
                        "intermolecular": energy[1] if len(energy) > 1 else None,
                        "intramolecular": energy[2] if len(energy) > 2 else None,
                    }
                )
            summary[ligand_name] = rows
        return summary

    def trial_dock(
        self, n_trials: int = 10, exhaustiveness: int = 8
    ) -> list[dict[str, float | int]]:
        chem = require_dependency("rdkit.Chem")
        rd_mol_align = require_dependency("rdkit.Chem.rdMolAlign")

        if self.receptor.prody_ligand_pdb is None:
            raise ValueError(
                "Reference ligand PDB is missing. Run choose_reference_ligand() first."
            )
        if self.receptor.pdbqt_path is None:
            raise ValueError(
                "Prepared receptor PDBQT is missing. Run prepare_receptor() first."
            )

        ref_ligand_name = f"{self.receptor.name}_ref_ligand"
        reference_ligand = Ligand(
            name=ref_ligand_name, pdb_path=self.receptor.prody_ligand_pdb
        )
        ref_pdbqt = reference_ligand.prepare_from_pdb(
            output_dir=self.output_layout.ligand_dir
        )

        redock = DockingRunner(self.receptor, output_layout=self.output_layout)
        redock.add_ligand(Ligand(name=ref_ligand_name, pdbqt_path=ref_pdbqt))
        redock.setup_vina()
        redock.run_docking(exhaustiveness=exhaustiveness, n_poses=n_trials)

        energies = redock.last_energies[ref_ligand_name]
        poses_str = redock.last_poses[ref_ligand_name]

        with tempfile.TemporaryDirectory() as directory:
            pose_pdbqt = Path(directory) / "poses.pdbqt"
            pose_sdf = Path(directory) / "poses.sdf"
            pose_pdbqt.write_text(poses_str)
            run_command(CommandSpec("mk_export.py", (str(pose_pdbqt), "-s", str(pose_sdf))))
            docked_molecules = [
                mol
                for mol in chem.SDMolSupplier(str(pose_sdf), removeHs=True)
                if mol is not None
            ]

        ref_sdf = self.output_layout.ligand_dir / ref_ligand_name / f"{ref_ligand_name}.sdf"
        reference_molecule = chem.SDMolSupplier(str(ref_sdf), removeHs=True)[0]
        if reference_molecule is None:
            raise DockingExecutionError(f"Failed to read reference SDF: {ref_sdf}")

        results = []
        for index, docked_molecule in enumerate(docked_molecules[:n_trials]):
            match = docked_molecule.GetSubstructMatch(reference_molecule)
            if not match:
                reverse_match = reference_molecule.GetSubstructMatch(docked_molecule)
                rmsd = (
                    float("nan")
                    if not reverse_match
                    else rd_mol_align.AlignMol(
                        docked_molecule,
                        reference_molecule,
                        atomMap=list(
                            zip(range(docked_molecule.GetNumAtoms()), reverse_match)
                        ),
                    )
                )
            else:
                rmsd = rd_mol_align.AlignMol(
                    docked_molecule,
                    reference_molecule,
                    atomMap=list(zip(match, range(reference_molecule.GetNumAtoms()))),
                )
            results.append(
                {
                    "pose": index + 1,
                    "rmsd": rmsd,
                    "affinity": energies[index][0]
                    if index < len(energies)
                    else float("nan"),
                }
            )
        return results

    def visualize_docking_pose(
        self,
        ligand_name: str | None = None,
        pose_index: int = 0,
        width: int = 800,
        height: int = 800,
        save_html: bool = False,
        output_path: str | Path | None = None,
    ):
        py3dmol = require_dependency("py3Dmol")
        chem = require_dependency("rdkit.Chem")

        if self.receptor.box_center is None or self.receptor.box_size is None:
            raise ValueError("Receptor box metadata is missing.")
        if pose_index != 0:
            raise ValueError(
                "Only pose_index=0 is supported because save_docking_results() persists only the best pose."
            )

        selected_ligand = self._resolve_visualization_ligand(ligand_name)
        receptor_pdb = self._resolve_saved_result_pdb(selected_ligand)
        ligand_sdf = self._resolve_saved_result_sdf(selected_ligand)
        conformers = [
            mol for mol in chem.SDMolSupplier(str(ligand_sdf), removeHs=False) if mol is not None
        ]
        if not conformers:
            raise DockingExecutionError(
                f"Failed to read saved docking result for '{selected_ligand}'."
            )
        cx, cy, cz = self.receptor.box_center
        sx, sy, sz = self.receptor.box_size

        view = py3dmol.view(width=width, height=height)
        view.addModel(receptor_pdb.read_text(), "pdb")
        view.setStyle({"protein": True}, {"cartoon": {"colorscheme": "spectrum"}})
        view.addModel(chem.MolToMolBlock(conformers[0]), "mol")
        view.setStyle({"model": 1}, {"stick": {"colorscheme": "greenCarbon"}})
        view.addBox(
            {
                "center": {"x": cx, "y": cy, "z": cz},
                "dimensions": {"w": sx, "h": sy, "d": sz},
                "color": "red",
                "opacity": 0.6,
            }
        )
        view.zoomTo()
        view.setBackgroundColor("white")

        if save_html:
            resolved_output_path = (
                self.output_layout.docking_pose_html(
                    selected_ligand,
                    self.receptor.name,
                    pose_index + 1,
                )
                if output_path is None
                else Path(output_path)
            )

            export_visualization(
                view=view,
                output_path=resolved_output_path,
                title=f"{selected_ligand} Pose {pose_index + 1} in {self.receptor.name}",
            )
            print(f"Saved docking pose visualization to: {resolved_output_path}")

        return view

    def _resolve_visualization_ligand(self, ligand_name: str | None) -> str:
        if self.results_dir is None:
            raise ValueError(
                "No results directory is available. Run save_docking_results() first."
            )

        available_ligands = list(self.ligands)
        if not available_ligands:
            results_dir = Path(self.results_dir)
            available_ligands = sorted(
                path.name[: -len(f"_{self.receptor.name}.pdb")]
                for path in results_dir.glob(f"*_{self.receptor.name}.pdb")
            )
        if not available_ligands:
            raise ValueError(
                "No saved docking results found. Run save_docking_results() first."
            )

        if ligand_name is None and len(available_ligands) > 1:
            raise ValueError(
                "Multiple saved ligands are available; pass ligand_name explicitly."
            )

        selected_ligand = ligand_name or available_ligands[0]
        if selected_ligand not in available_ligands:
            raise ValueError(f"Unknown ligand '{selected_ligand}'.")
        return selected_ligand

    def _resolve_saved_result_pdb(self, ligand_name: str) -> Path:
        if self.results_dir is None:
            raise ValueError(
                "No results directory is available. Run save_docking_results() first."
            )

        complex_pdb = Path(self.results_dir) / f"{ligand_name}_{self.receptor.name}.pdb"
        if not complex_pdb.is_file():
            raise DockingExecutionError(
                f"Failed to prepare saved docking result for '{ligand_name}'."
            )
        return complex_pdb

    def _resolve_saved_result_sdf(self, ligand_name: str) -> Path:
        if self.results_dir is None:
            raise ValueError(
                "No results directory is available. Run save_docking_results() first."
            )

        ligand_sdf = Path(self.results_dir) / f"{ligand_name}_{self.receptor.name}.sdf"
        if not ligand_sdf.is_file():
            raise DockingExecutionError(
                f"Failed to prepare saved docking result for '{ligand_name}'."
            )
        return ligand_sdf

    def _resolve_interaction_output_dir(self) -> Path:
        if self.receptor.prepared_pdb_path is None or self.receptor.json_path is None:
            raise ValueError(
                "Prepared receptor PDB and JSON are required. Run receptor.prepare_receptor() first."
            )
        return ensure_directory(self.output_layout.receptor_interaction_dir(self.receptor.json_path))

    def _resolve_interaction_receptor_pdb(self) -> Path:
        if self.receptor.structure_path is None:
            raise ValueError(
                "Parsed receptor PDB is required. Run receptor.parse_receptor() before exporting interactions."
            )

        receptor_pdb = Path(self.receptor.structure_path)
        if not receptor_pdb.is_file():
            raise DockingExecutionError(f"Parsed receptor PDB not found: {receptor_pdb}")
        return receptor_pdb

    def _prepare_pose_visualization_inputs(
        self,
        ligand_name: str,
        pose_index: int,
    ) -> tuple[Path, Path, Path, str]:
        chem = require_dependency("rdkit.Chem")

        if pose_index != 0:
            raise ValueError(
                "Only pose_index=0 is supported because save_docking_results() persists only the best pose."
            )

        output_dir = self._resolve_interaction_output_dir()
        output_stem = f"{ligand_name}_{self.receptor.name}_pose{pose_index + 1}"
        ligand_pdb = output_dir / f"{output_stem}_ligand.pdb"
        receptor_pdb = output_dir / f"{output_stem}_receptor.pdb"
        parsed_receptor_pdb = self._resolve_interaction_receptor_pdb()
        ligand_sdf = self._resolve_saved_result_sdf(ligand_name)

        try:
            receptor_pdb.write_text(parsed_receptor_pdb.read_text())
            molecule = chem.SDMolSupplier(str(ligand_sdf), removeHs=False)[0]
            if molecule is None:
                raise DockingExecutionError(
                    f"Failed to read saved docking result for '{ligand_name}'."
                )
            ligand_pdb.write_text(chem.MolToPDBBlock(molecule))
        except DockingExecutionError:
            raise
        except Exception as exc:
            raise DockingExecutionError(
                f"Failed to prepare saved docking result for '{ligand_name}'."
            ) from exc

        return receptor_pdb, ligand_pdb, output_dir, output_stem

    def export_2d_interaction_diagram(
        self,
        ligand_name: str | None = None,
        pose_index: int = 0,
        output_file: str | Path | None = None,
    ) -> Path:
        selected_ligand = self._resolve_visualization_ligand(ligand_name)
        receptor_pdb, ligand_pdb, output_dir, output_stem = self._prepare_pose_visualization_inputs(
            selected_ligand,
            pose_index,
        )
        visualizer = DockingVisualizer(
            receptor_pdb, ligand_pdb, output_dir, output_stem=output_stem
        )
        resolved_output_file = (
            output_dir
            / f"{selected_ligand}_{self.receptor.name}_pose{pose_index + 1}_interaction_2d.png"
            if output_file is None
            else Path(output_file)
        )
        return visualizer.export_2d_interaction_diagram(resolved_output_file)

    def export_3d_interaction_diagram(
        self,
        ligand_name: str | None = None,
        pose_index: int = 0,
        output_file: str | Path | None = None,
        *,
        width: int = 1074,
        height: int = 768,
        show_surface: bool = True,
    ) -> Path:
        selected_ligand = self._resolve_visualization_ligand(ligand_name)
        receptor_pdb, ligand_pdb, output_dir, output_stem = self._prepare_pose_visualization_inputs(
            selected_ligand,
            pose_index,
        )
        visualizer = DockingVisualizer(
            receptor_pdb, ligand_pdb, output_dir, output_stem=output_stem
        )
        resolved_output_file = (
            output_dir
            / f"{selected_ligand}_{self.receptor.name}_pose{pose_index + 1}_interaction_3d.html"
            if output_file is None
            else Path(output_file)
        )
        return visualizer.export_3d_interaction_diagram(
            resolved_output_file,
            width=width,
            height=height,
            show_surface=show_surface,
        )

    def export_interaction_table(
        self,
        ligand_name: str | None = None,
        pose_index: int = 0,
        output_file: str | Path | None = None,
    ) -> Path:
        selected_ligand = self._resolve_visualization_ligand(ligand_name)
        receptor_pdb, ligand_pdb, output_dir, output_stem = self._prepare_pose_visualization_inputs(
            selected_ligand,
            pose_index,
        )
        visualizer = DockingVisualizer(
            receptor_pdb, ligand_pdb, output_dir, output_stem=output_stem
        )
        resolved_output_file = (
            output_dir
            / f"{selected_ligand}_{self.receptor.name}_pose{pose_index + 1}_interaction_table.txt"
            if output_file is None
            else Path(output_file)
        )
        return visualizer.export_interaction_table(resolved_output_file)


class DockingVisualizer:
    def __init__(
        self,
        receptor_pdb: str | Path,
        ligand_pdb: str | Path,
        output_dir: str | Path,
        output_stem: str | None = None,
    ):
        self.receptor_pdb = Path(receptor_pdb)
        self.ligand_pdb = Path(ligand_pdb)
        self.output_dir = Path(output_dir)
        self.output_stem = output_stem
        self.merged_structure_path: Path | None = None
        self.mapper: Any | None = None
        self._mapper_prepared = False

    def _ensure_output_dir(self) -> Path:
        return ensure_directory(self.output_dir)

    def _default_output_stem(self) -> str:
        return self.output_stem or f"{self.receptor_pdb.stem}_{self.ligand_pdb.stem}"

    def _default_2d_output_path(self) -> Path:
        return self._ensure_output_dir() / (
            f"{self._default_output_stem()}_interaction_2d.html"
        )

    def _default_3d_output_path(self) -> Path:
        return self._ensure_output_dir() / (
            f"{self._default_output_stem()}_interaction_3d.html"
        )

    def _default_table_output_path(self) -> Path:
        return self._ensure_output_dir() / (
            f"{self._default_output_stem()}_interaction_table.txt"
        )

    def build_complex(self) -> Path:
        bio_pdb = require_dependency("Bio.PDB")
        if self.merged_structure_path is not None:
            return self.merged_structure_path

        parser = bio_pdb.PDBParser(QUIET=True)
        receptor = parser.get_structure(self.receptor_pdb.stem, str(self.receptor_pdb))
        ligand = parser.get_structure(self.ligand_pdb.stem, str(self.ligand_pdb))

        merged_model = deepcopy(receptor[0])
        existing_chain_ids = {chain.id for chain in merged_model.get_chains()}

        for chain in ligand[0]:
            copied_chain = deepcopy(chain)
            if copied_chain.id in existing_chain_ids:
                copied_chain.id = self._next_available_chain_id(existing_chain_ids)
            merged_model.add(copied_chain)
            existing_chain_ids.add(copied_chain.id)

        io = bio_pdb.PDBIO()
        io.set_structure(merged_model)
        complex_filename = (
            f"{self.output_stem}_complex.pdb"
            if self.output_stem is not None
            else f"{self.receptor_pdb.stem}_{self.ligand_pdb.stem}_merged.pdb"
        )
        self.merged_structure_path = self._ensure_output_dir() / complex_filename
        io.save(str(self.merged_structure_path))

        return self.merged_structure_path

    @staticmethod
    def _next_available_chain_id(existing_chain_ids: set[str]) -> str:
        for (
            candidate
        ) in "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz":
            if candidate not in existing_chain_ids:
                return candidate
        raise DockingExecutionError("No available chain id remains for ligand merge.")

    def build_mapper(self):
        if self.mapper is not None:
            return self.mapper

        merged_structure_path = self.build_complex()
        pandamap = require_dependency("pandamap")
        mapper_class = pandamap.HybridProtLigMapper
        self.mapper = mapper_class(merged_structure_path)
        return self.mapper

    def prepare_mapper_for_interactions(self):
        mapper = self.build_mapper()
        if self._mapper_prepared:
            return mapper

        if not hasattr(mapper, "detect_interactions"):
            raise DockingExecutionError(
                "The installed PandaMap HybridProtLigMapper does not expose detect_interactions()."
            )

        try:
            mapper.detect_interactions()

            try:
                mapper.calculate_dssp_solvent_accessibility()
                interacting_count = len(getattr(mapper, "interacting_residues", []))
                accessible_count = len(getattr(mapper, "solvent_accessible", []))
                if interacting_count and accessible_count > interacting_count * 0.5:
                    mapper.calculate_realistic_solvent_accessibility()
                elif accessible_count < 2:
                    mapper.calculate_realistic_solvent_accessibility()
            except Exception:
                mapper.calculate_realistic_solvent_accessibility(exposure_threshold=0.2)

            interacting_count = len(getattr(mapper, "interacting_residues", []))
            accessible_count = len(getattr(mapper, "solvent_accessible", []))
            if interacting_count and accessible_count == interacting_count:
                mapper.calculate_realistic_solvent_accessibility(
                    exposure_threshold=0.3,
                    max_percent=0.4,
                )
        except DockingExecutionError:
            raise
        except Exception as exc:
            raise DockingExecutionError(
                f"Failed to prepare PandaMap interactions for {self.build_complex()}: {exc}"
            ) from exc

        self._mapper_prepared = True
        return mapper

    def export_2d_interaction_diagram(
        self, output_file: Path | str | None = None
    ) -> Path:
        mapper = self.prepare_mapper_for_interactions()
        resolved_output_file = (
            self._default_2d_output_path() if output_file is None else Path(output_file)
        )
        ensure_directory(resolved_output_file.parent)
        mapper.visualize(output_file=resolved_output_file)
        return resolved_output_file

    def export_3d_interaction_diagram(
        self,
        output_file: str | Path | None = None,
        *,
        width: int = 1074,
        height: int = 768,
        show_surface: bool = True,
    ) -> Path:
        panda3dmap = require_dependency("pandamap.create_3d_view")
        mapper = self.prepare_mapper_for_interactions()
        self._sanitize_mapper_interaction_atoms_for_3d(mapper)
        resolved_output_file = (
            self._default_3d_output_path() if output_file is None else Path(output_file)
        )
        ensure_directory(resolved_output_file.parent)
        panda3dmap.create_pandamap_3d_viz(
            mapper=mapper,
            output_file=resolved_output_file,
            width=width,
            height=height,
            show_surface=show_surface,
        )
        return resolved_output_file

    @staticmethod
    def _sanitize_mapper_interaction_atoms_for_3d(mapper) -> None:
        """Unwrap Biopython disordered atoms before PandaMap's 3D exporter.

        Some PandaMap versions test interaction atoms with ``if not atom``.
        Biopython ``DisorderedAtom``/``DisorderedEntityWrapper`` truthiness can
        call ``__len__`` on the selected child, which raises ``TypeError`` for a
        plain ``Atom``. Replacing wrappers with their selected atom keeps the
        exporter behavior intact while avoiding that truthiness bug.
        """
        interactions = getattr(mapper, "interactions", None)
        if not isinstance(interactions, dict):
            return

        for interaction_group in interactions.values():
            if not interaction_group:
                continue
            for interaction in interaction_group:
                if not isinstance(interaction, dict):
                    continue
                for atom_key in ("protein_atom", "ligand_atom"):
                    atom = interaction.get(atom_key)
                    selected_child = getattr(atom, "selected_child", None)
                    if selected_child is not None and hasattr(atom, "child_dict"):
                        interaction[atom_key] = selected_child

    def export_interaction_table(
        self, output_file: Path | str | None = None
    ) -> Path:
        mapper = self.prepare_mapper_for_interactions()
        if not hasattr(mapper, "generate_interaction_report"):
            raise DockingExecutionError(
                "The installed PandaMap HybridProtLigMapper does not expose generate_interaction_report()."
            )

        resolved_output_file = (
            self._default_table_output_path() if output_file is None else Path(output_file)
        )
        ensure_directory(resolved_output_file.parent)
        try:
            mapper.generate_interaction_report(output_file=resolved_output_file)
        except Exception as exc:
            raise DockingExecutionError(
                f"Failed to export PandaMap interaction table to {resolved_output_file}: {exc}"
            ) from exc
        return resolved_output_file
