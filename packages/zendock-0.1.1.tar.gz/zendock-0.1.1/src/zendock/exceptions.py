class DockingError(Exception):
    """Base package exception."""


class DependencyNotAvailableError(DockingError):
    """Raised when an optional dependency is required but missing."""


class CommandExecutionError(DockingError):
    """Raised when an external command fails."""


class PreparationError(DockingError):
    """Raised when receptor or ligand preparation fails."""


class DockingExecutionError(DockingError):
    """Raised when docking execution or export fails."""
