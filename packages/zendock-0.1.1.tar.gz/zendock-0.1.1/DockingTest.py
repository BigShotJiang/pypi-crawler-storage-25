import marimo

__generated_with = "0.23.6"
app = marimo.App(width="medium")


@app.cell(hide_code=True)
def _():
    import importlib.util
    from pathlib import Path
    import shutil
    import traceback

    import marimo as mo

    from zendock import DockingRunner, Ligand, OutputLayout, Receptor

    return (
        DockingRunner,
        Ligand,
        OutputLayout,
        Path,
        Receptor,
        importlib,
        mo,
        shutil,
        traceback,
    )


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    # Real-world docking smoke test

    This marimo app exercises the public `zendock` API in a realistic workflow:

    1. Download and parse a real PDB receptor (`1M17`, EGFR kinase domain).
    2. Prepare a real small-molecule ligand from SMILES.
    3. Prepare receptor files and a docking box.
    4. Run AutoDock Vina.
    5. Export docking results and optionally render the best pose.

    The workflow is intentionally gated behind a button because it downloads data,
    invokes external chemistry tools, and can take several minutes.
    """)
    return


@app.cell(hide_code=True)
def _(Path, mo):
    pdb_id = mo.ui.text(value="1M17", label="PDB ID")
    receptor_name = mo.ui.text(value="egfr_1m17", label="Receptor name")
    ligand_name = mo.ui.text(value="erlotinib_smoke", label="Ligand name")
    ligand_smiles = mo.ui.text(
        value="C#Cc1cccc(Nc2ncnc3cc(OCCOC)c(OCCOC)cc23)c1",
        label="Ligand SMILES",
        full_width=True,
    )
    workspace = mo.ui.text(
        value=str(Path("DockingTest_Run")),
        label="Workspace directory",
        full_width=True,
    )
    exhaustiveness = mo.ui.slider(1, 16, value=4, label="Vina exhaustiveness")
    n_poses = mo.ui.slider(1, 10, value=3, label="Number of poses")
    clean_workspace = mo.ui.checkbox(value=False, label="Delete workspace before run")
    render_pose = mo.ui.checkbox(value=True, label="Render best docking pose after export")
    run = mo.ui.run_button(label="Run real-world docking smoke test")

    mo.vstack(
        [
            mo.md("## Inputs"),
            pdb_id,
            receptor_name,
            ligand_name,
            ligand_smiles,
            workspace,
            mo.hstack([exhaustiveness, n_poses]),
            clean_workspace,
            render_pose,
            run,
        ]
    )
    return (
        clean_workspace,
        exhaustiveness,
        ligand_name,
        ligand_smiles,
        n_poses,
        pdb_id,
        receptor_name,
        render_pose,
        run,
        workspace,
    )


@app.cell(hide_code=True)
def _(importlib, mo, shutil):
    required_python_modules = ["prody", "rdkit", "vina", "py3Dmol", "Bio"]
    optional_python_modules = ["pandamap"]
    required_commands = [
        "scrub.py",
        "mk_prepare_ligand.py",
        "mk_prepare_receptor.py",
        "mk_export.py",
    ]

    module_status = {
        name: importlib.util.find_spec(name) is not None
        for name in required_python_modules
    }
    optional_module_status = {
        name: importlib.util.find_spec(name) is not None
        for name in optional_python_modules
    }
    command_status = {name: shutil.which(name) is not None for name in required_commands}

    missing_modules = [name for name, ok in module_status.items() if not ok]
    missing_commands = [name for name, ok in command_status.items() if not ok]

    rows = []
    for name, ok in module_status.items():
        rows.append({"kind": "python module", "name": name, "available": ok})
    for name, ok in optional_module_status.items():
        rows.append({"kind": "optional python module", "name": name, "available": ok})
    for name, ok in command_status.items():
        rows.append({"kind": "command", "name": name, "available": ok})

    mo.vstack(
        [
            mo.md("## Environment preflight"),
            mo.ui.table(rows),
            mo.md(
                "✅ Required tools are available."
                if not missing_modules and not missing_commands
                else "⚠️ Missing required runtime pieces. Install `zendock[all]` and make sure Meeko/MolScrub command-line tools are on `PATH`."
            ),
        ]
    )
    return missing_commands, missing_modules


@app.cell(hide_code=True)
def _(
    DockingRunner,
    Ligand,
    OutputLayout,
    Path,
    Receptor,
    clean_workspace,
    exhaustiveness,
    ligand_name,
    ligand_smiles,
    missing_commands,
    missing_modules,
    mo,
    n_poses,
    pdb_id,
    receptor_name,
    render_pose,
    run,
    shutil,
    traceback,
    workspace,
):
    mo.stop(not run.value, mo.md("Press **Run real-world docking smoke test** to start."))
    mo.stop(
        bool(missing_modules or missing_commands),
        mo.md(
            "Cannot run until required modules/commands are available. See the preflight table above."
        ),
    )

    workspace_path = Path(workspace.value).expanduser().resolve()
    if clean_workspace.value and workspace_path.exists():
        shutil.rmtree(workspace_path)
    workspace_path.mkdir(parents=True, exist_ok=True)

    layout = OutputLayout(root=workspace_path)
    steps: list[dict[str, str]] = []

    def record(step: str, status: str, detail: object = "") -> None:
        steps.append({"step": step, "status": status, "detail": str(detail)})

    try:
        receptor = Receptor(
            name=receptor_name.value,
            pdb_id=pdb_id.value,
            output_dir=layout.receptor_dir,
        )
        record("Create receptor", "ok", receptor.name)

        raw_pdb = receptor.download_structure()
        record("Download receptor", "ok", raw_pdb)

        parsed_pdb = receptor.parse_receptor()
        record("Parse receptor atoms", "ok", parsed_pdb)

        receptor.box_center = (21.0, 0.5, 52.0)
        receptor.box_size = (22.0, 22.0, 22.0)
        receptor_pdbqt, prepared_pdb, receptor_json = receptor.prepare_receptor()
        record("Prepare receptor", "ok", (receptor_pdbqt, prepared_pdb, receptor_json))

        ligand = Ligand(
            name=ligand_name.value,
            smiles=ligand_smiles.value,
            output_dir=layout.ligand_dir,
        )
        ligand_pdbqt, ligand_sdf = ligand.prepare_ligand()
        record("Prepare ligand", "ok", (ligand_pdbqt, ligand_sdf))

        runner = DockingRunner(receptor, output_layout=layout)
        runner.add_ligand(ligand)
        runner.setup_vina()
        record("Setup Vina", "ok", receptor.pdbqt_path)

        runner.run_docking(
            exhaustiveness=int(exhaustiveness.value),
            n_poses=int(n_poses.value),
        )
        summary = runner.get_docking_summary(n_poses=int(n_poses.value))
        record("Run docking", "ok", summary)

        exported = runner.save_docking_results()
        record("Export docking results", "ok", exported)

        pose_output = mo.md("Pose rendering disabled.")
        if render_pose.value:
            pose_html_path = layout.docking_pose_html(ligand.name, receptor.name, 1)
            runner.visualize_docking_pose(
                ligand_name=ligand.name,
                pose_index=0,
                save_html=True,
            )
            pose_output = mo.Html(pose_html_path.read_text(encoding="utf-8"))
            record(
                "Render best pose",
                "ok",
                pose_html_path,
            )

        result = {
            "workspace": str(workspace_path),
            "summary": summary,
            "exported": exported,
            "typed_result_ligands": list(runner.last_result.ligand_results)
            if runner.last_result is not None
            else [],
        }
        output = mo.vstack(
            [
                mo.md("## Real-world smoke test result"),
                mo.ui.table(steps),
                mo.md("### Docking summary"),
                mo.ui.table(summary.get(ligand.name, [])),
                mo.md("### Output artifact summary"),
                mo.as_html(result),
                pose_output,
            ]
        )
    except Exception as exc:
        record("Workflow failed", "error", exc)
        output = mo.vstack(
            [
                mo.md("## Real-world smoke test failed"),
                mo.ui.table(steps),
                mo.md("### Traceback"),
                mo.as_html(f"<pre>{traceback.format_exc()}</pre>"),
            ]
        )

    output
    return


if __name__ == "__main__":
    app.run()
