# zendock

`zendock` is a focused Python package for the molecular docking workflow sketched in `Docking.ipynb`.

This package aims to provede the entire stack needed to perform molecular docking for scientific use, sacrificing performance and flexibility for access and ease of use.

The base package keeps imports lightweight. Install extras for ligand/receptor preparation, docking, and visualization workflows.

## Philosophy

- Lightweight import by default, optional extras for full workflows
- Notebook prototype, package implementation
- `uv` for development
- `pip` works for end users

## Install

### Users

Install from PyPI with regular `pip`:

```bash
pip install zendock
```

Install the complete workflow stack with:

```bash
pip install "zendock[all]"
```

Targeted extras are also available:

```bash
pip install "zendock[prep]"  # ligand/receptor preparation
pip install "zendock[dock]"  # Vina docking
pip install "zendock[viz]"   # 3D/interaction visualization
```

### Development with `uv`

Create an environment and install the package in editable mode:

```bash
uv venv
source .venv/bin/activate
uv pip install -e ".[all]"
```

Install developer tools too:

```bash
uv pip install -e ".[dev]"
```
## Development Workflow

Typical loop:

```bash
uv venv
source .venv/bin/activate
uv pip install -e ".[all,dev]"
pytest
python -m build
```

## Project Layout

```text
src/zendock/
  __init__.py
  docking.py
  exceptions.py
  fetching.py
  ligand.py
  models.py
  receptor.py
  result_store.py
  results.py
  tools.py
  utils.py
  workspace.py
tests/
Docking.ipynb
pyproject.toml
```

## Current Public API

```python
from zendock import DockingRunner, Ligand, OutputLayout, Receptor
```

`DockingRunner` remains the notebook-friendly facade. New code can pass an `OutputLayout` to centralize output directories and use the typed result objects cached on `runner.last_result` after docking.

## Visualization Example

```python
from zendock import DockingRunner, Ligand, Receptor

receptor = Receptor(name="egfr", pdb_id="1M17")
# Prepare the receptor, add at least one prepared ligand, and set up Vina first.
runner = DockingRunner(receptor)

runner.run_docking()
runner.export_2d_interaction_diagram("ligand_a")
runner.export_3d_interaction_diagram("ligand_a", pose_index=0)
```


## Notes

- The package is licensed under MIT.
