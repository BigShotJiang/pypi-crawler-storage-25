from pathlib import Path

from zendock.ligand import Ligand
from zendock.receptor import ReceptorPreparator
from zendock.results import split_pose_models
from zendock.tools import CommandSpec
from zendock.workspace import OutputLayout


def test_ligand_builds_scrub_command_with_flags(tmp_path: Path):
    ligand = Ligand(
        name="aspirin",
        smiles="CC(=O)OC1=CC=CC=C1C(=O)O",
        skip_tautomer=True,
        skip_acidbase=True,
    )

    spec = ligand._scrub_command(tmp_path / "aspirin.sdf")

    assert spec.executable == "scrub.py"
    assert "--skip_tautomer" in spec.args
    assert "--skip_acidbase" in spec.args


def test_receptor_preparator_builds_command_spec(tmp_path: Path):
    spec = ReceptorPreparator.prepare_receptor_command(
        "input.pdb",
        tmp_path / "receptor.pdbqt",
        tmp_path / "receptor_prepared.pdb",
        tmp_path / "receptor.json",
        (1.0, 2.0, 3.0),
        (10.0, 11.0, 12.0),
    )

    assert isinstance(spec, CommandSpec)
    assert spec.executable == "mk_prepare_receptor.py"
    assert "--box_center" in spec.args
    assert "--box_size" in spec.args


def test_split_pose_models_handles_multiple_models():
    poses = "MODEL 1\nATOM a\nENDMDL\nMODEL 2\nATOM b\nENDMDL\n"

    assert split_pose_models(poses) == [
        "MODEL 1\nATOM a\nENDMDL",
        "MODEL 2\nATOM b\nENDMDL",
    ]


def test_output_layout_preserves_legacy_defaults():
    layout = OutputLayout()

    assert layout.ligand_dir == Path("ligands")
    assert layout.docking_results_dir == Path("Docking_Result")
    assert layout.docking_pose_html("lig", "rec", 1) == Path(
        "Docking_Pose/lig_rec_pose1.html"
    )

