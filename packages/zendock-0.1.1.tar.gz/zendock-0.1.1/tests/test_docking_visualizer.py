from __future__ import annotations

from pathlib import Path

import pytest

from zendock.docking import DockingVisualizer
from zendock.utils import require_dependency as real_require_dependency


RECEPTOR_PDB = """\
ATOM      1  N   GLY A   1      11.104  13.207   9.447  1.00 20.00           N
ATOM      2  CA  GLY A   1      12.000  12.100   9.000  1.00 20.00           C
TER
END
"""

LIGAND_PDB = """\
HETATM    1  C1  LIG B   1       5.000   5.000   5.000  1.00 20.00           C
HETATM    2  O1  LIG B   1       6.000   5.000   5.000  1.00 20.00           O
TER
END
"""

LIGAND_PDB_CHAIN_A = """\
HETATM    1  C1  LIG A   1       5.000   5.000   5.000  1.00 20.00           C
HETATM    2  O1  LIG A   1       6.000   5.000   5.000  1.00 20.00           O
TER
END
"""


def _write_pdb(path: Path, content: str) -> Path:
    path.write_text(content)
    return path


def test_build_complex_writes_merged_structure_and_creates_output_dir(tmp_path: Path):
    pytest.importorskip("Bio")

    receptor_pdb = _write_pdb(tmp_path / "receptor.pdb", RECEPTOR_PDB)
    ligand_pdb = _write_pdb(tmp_path / "ligand.pdb", LIGAND_PDB)
    output_dir = tmp_path / "nested" / "visualizations"

    visualizer = DockingVisualizer(
        receptor_pdb=receptor_pdb,
        ligand_pdb=ligand_pdb,
        output_dir=output_dir,
    )

    merged_path = visualizer.build_complex()

    assert merged_path == output_dir / "receptor_ligand_merged.pdb"
    assert merged_path.is_file()
    merged_text = merged_path.read_text()
    assert "GLY A   1" in merged_text
    assert "LIG B   1" in merged_text


def test_build_complex_uses_explicit_output_stem_for_concise_complex_name(tmp_path: Path):
    pytest.importorskip("Bio")

    receptor_pdb = _write_pdb(tmp_path / "ligand_receptor_pose1_receptor.pdb", RECEPTOR_PDB)
    ligand_pdb = _write_pdb(tmp_path / "ligand_receptor_pose1_ligand.pdb", LIGAND_PDB)
    output_dir = tmp_path / "visualizations"

    visualizer = DockingVisualizer(
        receptor_pdb=receptor_pdb,
        ligand_pdb=ligand_pdb,
        output_dir=output_dir,
        output_stem="ligand_receptor_pose1",
    )

    merged_path = visualizer.build_complex()

    assert merged_path == output_dir / "ligand_receptor_pose1_complex.pdb"
    repetitive_merged_path = (
        output_dir
        / "ligand_receptor_pose1_receptor_ligand_receptor_pose1_ligand_merged.pdb"
    )
    assert not repetitive_merged_path.exists()


def test_export_2d_interaction_diagram_builds_mapper_lazily(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    class FakeMapper:
        def __init__(self, merged_structure_path: Path):
            self.merged_structure_path = Path(merged_structure_path)
            self.visualized_to: Path | None = None
            self.interacting_residues = [object(), object(), object(), object()]
            self.solvent_accessible = [object(), object()]
            self.calls: list[str] = []

        def detect_interactions(self):
            self.calls.append("detect_interactions")

        def calculate_dssp_solvent_accessibility(self):
            self.calls.append("calculate_dssp_solvent_accessibility")

        def calculate_realistic_solvent_accessibility(self, **kwargs):
            self.calls.append("calculate_realistic_solvent_accessibility")

        def visualize(self, output_file: Path | str):
            output_path = Path(output_file)
            output_path.write_text("2d")
            self.visualized_to = output_path

    class FakePandamapModule:
        HybridProtLigMapper = FakeMapper

    def fake_require_dependency(name: str):
        if name == "pandamap":
            return FakePandamapModule
        return real_require_dependency(name)

    receptor_pdb = _write_pdb(tmp_path / "receptor.pdb", RECEPTOR_PDB)
    ligand_pdb = _write_pdb(tmp_path / "ligand.pdb", LIGAND_PDB)
    output_dir = tmp_path / "visualizer"

    monkeypatch.setattr("zendock.docking.require_dependency", fake_require_dependency)

    visualizer = DockingVisualizer(receptor_pdb, ligand_pdb, output_dir)
    output_file = output_dir / "diagrams" / "interaction_2d.html"

    exported_path = visualizer.export_2d_interaction_diagram(output_file)

    assert exported_path == output_file
    assert exported_path.is_file()
    assert visualizer.merged_structure_path is not None
    assert visualizer.mapper is not None
    assert visualizer.mapper.visualized_to == output_file
    assert visualizer.mapper.calls == ["detect_interactions", "calculate_dssp_solvent_accessibility"]


def test_export_3d_interaction_diagram_uses_cached_mapper_and_creates_parent_dir(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
):
    class FakeMapper:
        def __init__(self, merged_structure_path: Path):
            self.merged_structure_path = Path(merged_structure_path)
            self.interacting_residues = [object(), object(), object(), object()]
            self.solvent_accessible = []

        def detect_interactions(self):
            pass

        def calculate_dssp_solvent_accessibility(self):
            pass

        def calculate_realistic_solvent_accessibility(self, **kwargs):
            self.solvent_accessible = [object(), object()]

    class FakePandamapModule:
        HybridProtLigMapper = FakeMapper

    class FakeCreate3DView:
        def __init__(self):
            self.calls: list[dict[str, object]] = []

        def create_pandamap_3d_viz(self, **kwargs):
            output_path = Path(kwargs["output_file"])
            output_path.write_text("3d")
            self.calls.append(kwargs)

    fake_3d_view = FakeCreate3DView()

    def fake_require_dependency(name: str):
        if name == "pandamap":
            return FakePandamapModule
        if name == "pandamap.create_3d_view":
            return fake_3d_view
        return real_require_dependency(name)

    receptor_pdb = _write_pdb(tmp_path / "receptor.pdb", RECEPTOR_PDB)
    ligand_pdb = _write_pdb(tmp_path / "ligand.pdb", LIGAND_PDB)

    monkeypatch.setattr("zendock.docking.require_dependency", fake_require_dependency)

    visualizer = DockingVisualizer(receptor_pdb, ligand_pdb, tmp_path / "visualizer")
    output_file = tmp_path / "exports" / "3d" / "interaction.html"

    exported_path = visualizer.export_3d_interaction_diagram(output_file, width=640, height=480)

    assert exported_path == output_file
    assert exported_path.is_file()
    assert len(fake_3d_view.calls) == 1
    assert fake_3d_view.calls[0]["mapper"] is visualizer.mapper
    assert fake_3d_view.calls[0]["output_file"] == output_file
    assert fake_3d_view.calls[0]["width"] == 640
    assert fake_3d_view.calls[0]["height"] == 480
    assert fake_3d_view.calls[0]["show_surface"] is True


def test_export_3d_interaction_diagram_unwraps_disordered_atoms_before_pandamap(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
):
    class FakeAtom:
        pass

    class BoolBrokenDisorderedAtom:
        def __init__(self):
            self.selected_child = FakeAtom()
            self.child_dict = {"A": self.selected_child}

        def __len__(self):
            raise TypeError("object of type 'Atom' has no len()")

    class FakeMapper:
        def __init__(self, merged_structure_path: Path):
            self.merged_structure_path = Path(merged_structure_path)
            self.interacting_residues = [object()]
            self.solvent_accessible = []
            self.interactions = {
                "hydrogen_bonds": [
                    {
                        "protein_atom": BoolBrokenDisorderedAtom(),
                        "ligand_atom": BoolBrokenDisorderedAtom(),
                    }
                ]
            }

        def detect_interactions(self):
            pass

        def calculate_dssp_solvent_accessibility(self):
            pass

        def calculate_realistic_solvent_accessibility(self, **kwargs):
            pass

    class FakePandamapModule:
        HybridProtLigMapper = FakeMapper

    class FakeCreate3DView:
        def create_pandamap_3d_viz(self, **kwargs):
            interaction = kwargs["mapper"].interactions["hydrogen_bonds"][0]
            assert isinstance(interaction["protein_atom"], FakeAtom)
            assert isinstance(interaction["ligand_atom"], FakeAtom)
            Path(kwargs["output_file"]).write_text("3d")

    def fake_require_dependency(name: str):
        if name == "pandamap":
            return FakePandamapModule
        if name == "pandamap.create_3d_view":
            return FakeCreate3DView()
        return real_require_dependency(name)

    receptor_pdb = _write_pdb(tmp_path / "receptor.pdb", RECEPTOR_PDB)
    ligand_pdb = _write_pdb(tmp_path / "ligand.pdb", LIGAND_PDB)

    monkeypatch.setattr("zendock.docking.require_dependency", fake_require_dependency)

    visualizer = DockingVisualizer(receptor_pdb, ligand_pdb, tmp_path / "visualizer")
    output_file = tmp_path / "exports" / "3d" / "interaction.html"

    assert visualizer.export_3d_interaction_diagram(output_file) == output_file
    assert output_file.read_text() == "3d"


def test_export_interaction_table_generates_pandamap_report(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    class FakeMapper:
        def __init__(self, merged_structure_path: Path):
            self.merged_structure_path = Path(merged_structure_path)
            self.interacting_residues = [object(), object(), object(), object()]
            self.solvent_accessible = [object(), object()]
            self.calls: list[str] = []

        def detect_interactions(self):
            self.calls.append("detect_interactions")

        def calculate_dssp_solvent_accessibility(self):
            self.calls.append("calculate_dssp_solvent_accessibility")

        def calculate_realistic_solvent_accessibility(self, **kwargs):
            self.calls.append("calculate_realistic_solvent_accessibility")

        def generate_interaction_report(self, output_file: Path | str):
            self.calls.append("generate_interaction_report")
            Path(output_file).write_text("table")

    class FakePandamapModule:
        HybridProtLigMapper = FakeMapper

    def fake_require_dependency(name: str):
        if name == "pandamap":
            return FakePandamapModule
        return real_require_dependency(name)

    receptor_pdb = _write_pdb(tmp_path / "receptor.pdb", RECEPTOR_PDB)
    ligand_pdb = _write_pdb(tmp_path / "ligand.pdb", LIGAND_PDB)
    output_file = tmp_path / "reports" / "interactions.txt"

    monkeypatch.setattr("zendock.docking.require_dependency", fake_require_dependency)

    visualizer = DockingVisualizer(receptor_pdb, ligand_pdb, tmp_path / "visualizer")

    exported_path = visualizer.export_interaction_table(output_file)

    assert exported_path == output_file
    assert exported_path.read_text() == "table"
    assert visualizer.mapper.calls == [
        "detect_interactions",
        "calculate_dssp_solvent_accessibility",
        "generate_interaction_report",
    ]


def test_interaction_table_uses_dssp_fallback_and_cached_preparation(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
):
    class FakeMapper:
        def __init__(self, merged_structure_path: Path):
            self.merged_structure_path = Path(merged_structure_path)
            self.interacting_residues = [object(), object(), object()]
            self.solvent_accessible = []
            self.calls: list[tuple[str, dict[str, object]]] = []

        def detect_interactions(self):
            self.calls.append(("detect_interactions", {}))

        def calculate_dssp_solvent_accessibility(self):
            self.calls.append(("calculate_dssp_solvent_accessibility", {}))
            raise RuntimeError("dssp unavailable")

        def calculate_realistic_solvent_accessibility(self, **kwargs):
            self.calls.append(("calculate_realistic_solvent_accessibility", kwargs))
            self.solvent_accessible = [object()]

        def generate_interaction_report(self, output_file: Path | str):
            self.calls.append(("generate_interaction_report", {}))
            Path(output_file).write_text("table")

        def visualize(self, output_file: Path | str):
            self.calls.append(("visualize", {}))
            Path(output_file).write_text("2d")

    class FakePandamapModule:
        HybridProtLigMapper = FakeMapper

    def fake_require_dependency(name: str):
        if name == "pandamap":
            return FakePandamapModule
        return real_require_dependency(name)

    receptor_pdb = _write_pdb(tmp_path / "receptor.pdb", RECEPTOR_PDB)
    ligand_pdb = _write_pdb(tmp_path / "ligand.pdb", LIGAND_PDB)

    monkeypatch.setattr("zendock.docking.require_dependency", fake_require_dependency)

    visualizer = DockingVisualizer(receptor_pdb, ligand_pdb, tmp_path / "visualizer")

    table_path = visualizer.export_interaction_table(tmp_path / "reports" / "interactions.txt")
    diagram_path = visualizer.export_2d_interaction_diagram(tmp_path / "diagrams" / "interactions.png")

    assert table_path.read_text() == "table"
    assert diagram_path.read_text() == "2d"
    assert visualizer.mapper.calls == [
        ("detect_interactions", {}),
        ("calculate_dssp_solvent_accessibility", {}),
        ("calculate_realistic_solvent_accessibility", {"exposure_threshold": 0.2}),
        ("generate_interaction_report", {}),
        ("visualize", {}),
    ]


def test_build_complex_remaps_conflicting_ligand_chain_ids(tmp_path: Path):
    pytest.importorskip("Bio")

    receptor_pdb = _write_pdb(tmp_path / "receptor.pdb", RECEPTOR_PDB)
    ligand_pdb = _write_pdb(tmp_path / "ligand_chain_a.pdb", LIGAND_PDB_CHAIN_A)

    visualizer = DockingVisualizer(
        receptor_pdb=receptor_pdb,
        ligand_pdb=ligand_pdb,
        output_dir=tmp_path / "visualizer",
    )

    merged_path = visualizer.build_complex()

    merged_text = merged_path.read_text()
    assert "GLY A   1" in merged_text
    assert "LIG A   1" not in merged_text
    assert "LIG B   1" in merged_text
