from zendock import DockingRunner, Ligand, Receptor


def test_public_api_imports():
    assert DockingRunner.__name__ == "DockingRunner"
    assert Ligand.__name__ == "Ligand"
    assert Receptor.__name__ == "Receptor"


def test_ligand_defaults():
    ligand = Ligand(name="aspirin", smiles="CC(=O)OC1=CC=CC=C1C(=O)O")
    assert ligand.name == "aspirin"
    assert ligand.ph == 7.4


def test_receptor_does_not_download_on_init():
    receptor = Receptor(name="egfr", pdb_id="1M17")
    assert receptor.raw_pdb_path is None
