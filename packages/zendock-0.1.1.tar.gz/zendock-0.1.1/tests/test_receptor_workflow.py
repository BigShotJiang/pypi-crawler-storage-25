from __future__ import annotations

import numbers
import shutil
from pathlib import Path

import pytest

from zendock.receptor import (
    BoxConfigurator,
    LigandSelector,
    ProteinLigandParser,
    Receptor,
    ReceptorPreparator,
    StructureFetcher,
)


PDB_ID = "1M17"
RECEPTOR_NAME = "egfr"
REFERENCE_RESNAME = "AQ4"


def _require_workflow_dependencies() -> None:
    pytest.importorskip("prody")
    pytest.importorskip("py3Dmol")
    if shutil.which("mk_prepare_receptor.py") is None:
        pytest.skip("mk_prepare_receptor.py is not available in PATH")


@pytest.mark.integration
def test_receptor_workflow_end_to_end(tmp_path: Path):
    _require_workflow_dependencies()

    output_dir = tmp_path / "receptors"

    raw_pdb_path = StructureFetcher.fetch_pdb(PDB_ID, output_dir=output_dir)
    assert Path(raw_pdb_path).is_file()

    residue_names = ProteinLigandParser.list_residue_names(raw_pdb_path)
    assert REFERENCE_RESNAME in residue_names

    receptor_structure_path = ProteinLigandParser.parse_receptor(
        raw_pdb_path,
        output_dir=output_dir,
        receptor_name=RECEPTOR_NAME,
    )
    assert Path(receptor_structure_path).is_file()

    ligand_pdb_path = LigandSelector.choose_reference_ligand(
        raw_pdb_path,
        receptor_name=RECEPTOR_NAME,
        resname=REFERENCE_RESNAME,
        output_dir=output_dir,
    )
    assert Path(ligand_pdb_path).is_file()

    box_center = BoxConfigurator.calculate_box_center(ligand_pdb_path)
    assert len(box_center) == 3
    assert all(isinstance(value, float) for value in box_center)

    box_size = BoxConfigurator.set_box_size()
    assert box_size == (20.0, 20.0, 20.0)

    receptor_pdbqt, prepared_pdb, receptor_json = ReceptorPreparator.prepare_receptor(
        receptor_structure_path,
        receptor_name=RECEPTOR_NAME,
        box_center=box_center,
        box_size=box_size,
        output_dir=output_dir,
    )
    assert Path(receptor_pdbqt).is_file()
    assert Path(prepared_pdb).is_file()
    assert Path(receptor_json).is_file()

    receptor = Receptor(name=RECEPTOR_NAME, pdb_id=PDB_ID, output_dir=output_dir)

    downloaded_path = receptor.download_structure(output_dir=output_dir)
    assert Path(downloaded_path).is_file()
    assert receptor.raw_pdb_path == downloaded_path

    receptor_residue_names = receptor.list_resnames()
    assert REFERENCE_RESNAME in receptor_residue_names

    selected_ligand_path = receptor.choose_reference_ligand(
        resname=REFERENCE_RESNAME,
        output_dir=output_dir,
    )
    assert Path(selected_ligand_path).is_file()
    assert receptor.selected_residue is not None
    assert receptor.selected_residue["resname"] == REFERENCE_RESNAME
    assert isinstance(receptor.selected_residue["chain"], str)
    assert isinstance(receptor.selected_residue["resnum"], numbers.Integral)

    parsed_path = receptor.parse_receptor(output_dir=output_dir)
    assert Path(parsed_path).is_file()

    calculated_center = receptor.calculate_box_center()
    assert len(calculated_center) == 3
    assert all(isinstance(value, float) for value in calculated_center)

    configured_box_size = receptor.set_box_size()
    assert configured_box_size == (20.0, 20.0, 20.0)

    pdbqt_path, prepared_pdb_path, json_path = receptor.prepare_receptor(
        output_dir=output_dir
    )
    assert Path(pdbqt_path).is_file()
    assert Path(prepared_pdb_path).is_file()
    assert Path(json_path).is_file()

    raw_view = receptor.visualize_raw_receptor()
    prepared_view = receptor.visualize_prepared_receptor()
    assert hasattr(raw_view, "_make_html")
    assert hasattr(prepared_view, "_make_html")

    exported_html = tmp_path / f"{RECEPTOR_NAME}_prepared.html"
    saved_view = receptor.visualize_prepared_receptor(
        save_html=True,
        output_path=exported_html,
    )
    assert hasattr(saved_view, "_make_html")
    assert exported_html.is_file()
    html_content = exported_html.read_text()
    assert "<html" in html_content.lower()
