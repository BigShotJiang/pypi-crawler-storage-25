from __future__ import annotations

from pathlib import Path

import pytest

from zendock.docking import DockingExecutionError, DockingRunner
from zendock.receptor import Receptor
from zendock.workspace import OutputLayout


RECEPTOR_PDB = """\
ATOM      1  N   GLY A   1      11.104  13.207   9.447  1.00 20.00           N
ATOM      2  CA  GLY A   1      12.000  12.100   9.000  1.00 20.00           C
TER
END
"""

PARSED_RECEPTOR_PDB = """\
ATOM      1  N   ALA C   7      21.104  23.207  19.447  1.00 20.00           N
ATOM      2  CA  ALA C   7      22.000  22.100  19.000  1.00 20.00           C
TER
END
"""

LIGAND_PDB = """\
HETATM    1  C1  LIG B   1       5.000   5.000   5.000  1.00 20.00           C
HETATM    2  O1  LIG B   1       6.000   5.000   5.000  1.00 20.00           O
TER
END
"""


def _build_runner(tmp_path: Path) -> DockingRunner:
    receptor = Receptor(name="receptor", pdb_id="1ABC")
    receptor.json_path = str(tmp_path / "receptor.json")
    receptor.prepared_pdb_path = str(tmp_path / "receptor_prepared.pdb")
    receptor.structure_path = str(tmp_path / "receptor_atoms.pdb")
    receptor.box_center = (1.0, 2.0, 3.0)
    receptor.box_size = (10.0, 10.0, 10.0)
    Path(receptor.json_path).write_text("{}")
    Path(receptor.prepared_pdb_path).write_text("receptor pdb")
    Path(receptor.structure_path).write_text(PARSED_RECEPTOR_PDB)

    runner = DockingRunner(receptor, output_layout=OutputLayout(root=tmp_path))
    runner.ligands["ligand"] = object()  # selected by name only in these tests
    runner.results_dir = str(tmp_path / "results")
    Path(runner.results_dir).mkdir()
    (Path(runner.results_dir) / "ligand_receptor.pdb").write_text(RECEPTOR_PDB)
    (Path(runner.results_dir) / "ligand_receptor.sdf").write_text("ligand sdf")
    return runner


def test_export_2d_interaction_diagram_requires_saved_results(tmp_path: Path):
    runner = DockingRunner(Receptor(name="receptor", pdb_id="1ABC"))

    with pytest.raises(ValueError, match=r"Run save_docking_results\(\) first"):
        runner.export_2d_interaction_diagram()


def test_export_2d_interaction_diagram_rejects_unknown_ligand(tmp_path: Path):
    runner = _build_runner(tmp_path)

    with pytest.raises(ValueError, match="Unknown ligand 'missing'"):
        runner.export_2d_interaction_diagram(ligand_name="missing")


def test_export_2d_interaction_diagram_rejects_non_best_pose_index(tmp_path: Path):
    runner = _build_runner(tmp_path)

    with pytest.raises(ValueError, match=r"Only pose_index=0 is supported"):
        runner.export_2d_interaction_diagram(pose_index=1)


def test_export_2d_interaction_diagram_uses_parsed_receptor_pdb_and_delegates(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
):
    class FakeVisualizer:
        def __init__(
            self,
            receptor_pdb: str | Path,
            ligand_pdb: str | Path,
            output_dir: str | Path,
            output_stem: str | None = None,
        ):
            self.receptor_pdb = Path(receptor_pdb)
            self.ligand_pdb = Path(ligand_pdb)
            self.output_dir = Path(output_dir)
            self.output_stem = output_stem

        def export_2d_interaction_diagram(self, output_file: str | Path | None = None) -> Path:
            exported = self.output_dir / "interaction_2d.html" if output_file is None else Path(output_file)
            exported.parent.mkdir(parents=True, exist_ok=True)
            exported.write_text("2d")
            return exported

    visualizer_calls: list[FakeVisualizer] = []

    class FakeChem:
        @staticmethod
        def SDMolSupplier(path: str, removeHs: bool = False):
            return [object()]

        @staticmethod
        def MolToPDBBlock(molecule: object) -> str:
            return LIGAND_PDB

    def fake_visualizer(
        receptor_pdb: str | Path,
        ligand_pdb: str | Path,
        output_dir: str | Path,
        output_stem: str | None = None,
    ):
        instance = FakeVisualizer(receptor_pdb, ligand_pdb, output_dir, output_stem)
        visualizer_calls.append(instance)
        return instance

    runner = _build_runner(tmp_path)
    monkeypatch.setattr("zendock.docking.DockingVisualizer", fake_visualizer)
    monkeypatch.setattr(
        "zendock.docking.require_dependency",
        lambda name: FakeChem if name == "rdkit.Chem" else None,
    )

    exported_path = runner.export_2d_interaction_diagram(ligand_name="ligand")

    assert exported_path == tmp_path / "Docking_Result" / "ligand_receptor_pose1_interaction_2d.png"
    assert exported_path.is_file()
    assert len(visualizer_calls) == 1
    assert visualizer_calls[0].receptor_pdb == tmp_path / "Docking_Result" / "ligand_receptor_pose1_receptor.pdb"
    assert visualizer_calls[0].ligand_pdb == tmp_path / "Docking_Result" / "ligand_receptor_pose1_ligand.pdb"
    assert visualizer_calls[0].output_stem == "ligand_receptor_pose1"
    assert visualizer_calls[0].receptor_pdb.read_text() == PARSED_RECEPTOR_PDB
    assert "ALA C   7" in visualizer_calls[0].receptor_pdb.read_text()
    assert "GLY A   1" not in visualizer_calls[0].receptor_pdb.read_text()
    assert "HETATM" not in visualizer_calls[0].receptor_pdb.read_text()
    assert "LIG B   1" in visualizer_calls[0].ligand_pdb.read_text()


def test_export_3d_interaction_diagram_forwards_options(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    class FakeVisualizer:
        def __init__(
            self,
            receptor_pdb: str | Path,
            ligand_pdb: str | Path,
            output_dir: str | Path,
            output_stem: str | None = None,
        ):
            self.receptor_pdb = Path(receptor_pdb)
            self.ligand_pdb = Path(ligand_pdb)
            self.output_dir = Path(output_dir)
            self.output_stem = output_stem

        def export_3d_interaction_diagram(
            self,
            output_file: str | Path | None = None,
            *,
            width: int = 1074,
            height: int = 768,
            show_surface: bool = True,
        ) -> Path:
            assert width == 640
            assert height == 480
            assert show_surface is False
            exported = self.output_dir / "interaction_3d.html" if output_file is None else Path(output_file)
            exported.parent.mkdir(parents=True, exist_ok=True)
            exported.write_text("3d")
            return exported

    class FakeChem:
        @staticmethod
        def SDMolSupplier(path: str, removeHs: bool = False):
            return [object()]

        @staticmethod
        def MolToPDBBlock(molecule: object) -> str:
            return LIGAND_PDB

    runner = _build_runner(tmp_path)
    monkeypatch.setattr("zendock.docking.DockingVisualizer", FakeVisualizer)
    monkeypatch.setattr(
        "zendock.docking.require_dependency",
        lambda name: FakeChem if name == "rdkit.Chem" else None,
    )

    exported_path = runner.export_3d_interaction_diagram(
        width=640,
        height=480,
        show_surface=False,
    )

    assert exported_path == tmp_path / "Docking_Result" / "ligand_receptor_pose1_interaction_3d.html"
    assert exported_path.is_file()


def test_export_interaction_table_uses_parsed_receptor_pdb_and_delegates(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
):
    class FakeVisualizer:
        def __init__(
            self,
            receptor_pdb: str | Path,
            ligand_pdb: str | Path,
            output_dir: str | Path,
            output_stem: str | None = None,
        ):
            self.receptor_pdb = Path(receptor_pdb)
            self.ligand_pdb = Path(ligand_pdb)
            self.output_dir = Path(output_dir)
            self.output_stem = output_stem

        def export_interaction_table(self, output_file: str | Path | None = None) -> Path:
            exported = self.output_dir / "interaction_table.txt" if output_file is None else Path(output_file)
            exported.parent.mkdir(parents=True, exist_ok=True)
            exported.write_text("table")
            return exported

    visualizer_calls: list[FakeVisualizer] = []

    class FakeChem:
        @staticmethod
        def SDMolSupplier(path: str, removeHs: bool = False):
            return [object()]

        @staticmethod
        def MolToPDBBlock(molecule: object) -> str:
            return LIGAND_PDB

    def fake_visualizer(
        receptor_pdb: str | Path,
        ligand_pdb: str | Path,
        output_dir: str | Path,
        output_stem: str | None = None,
    ):
        instance = FakeVisualizer(receptor_pdb, ligand_pdb, output_dir, output_stem)
        visualizer_calls.append(instance)
        return instance

    runner = _build_runner(tmp_path)
    monkeypatch.setattr("zendock.docking.DockingVisualizer", fake_visualizer)
    monkeypatch.setattr(
        "zendock.docking.require_dependency",
        lambda name: FakeChem if name == "rdkit.Chem" else None,
    )

    exported_path = runner.export_interaction_table(ligand_name="ligand")

    assert exported_path == tmp_path / "Docking_Result" / "ligand_receptor_pose1_interaction_table.txt"
    assert exported_path.read_text() == "table"
    assert len(visualizer_calls) == 1
    assert visualizer_calls[0].receptor_pdb == tmp_path / "Docking_Result" / "ligand_receptor_pose1_receptor.pdb"
    assert visualizer_calls[0].ligand_pdb == tmp_path / "Docking_Result" / "ligand_receptor_pose1_ligand.pdb"
    assert visualizer_calls[0].output_stem == "ligand_receptor_pose1"


def test_export_2d_interaction_diagram_wraps_export_failures(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    runner = _build_runner(tmp_path)

    (Path(runner.results_dir) / "ligand_receptor.sdf").unlink()

    with pytest.raises(DockingExecutionError, match="Failed to prepare saved docking result for 'ligand'"):
        runner.export_2d_interaction_diagram()


def test_visualize_docking_pose_reads_saved_result_pdb(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
):
    class FakeView:
        def __init__(self):
            self.models: list[tuple[str, str]] = []
            self.styles: list[tuple[dict[str, object], dict[str, object]]] = []
            self.boxes: list[dict[str, object]] = []
            self.zoom_target = None

        def addModel(self, text: str, fmt: str = ""):
            self.models.append((text, fmt))

        def setStyle(self, selector: dict[str, object], style: dict[str, object] | None = None):
            if style is None:
                style = selector
                selector = {}
            self.styles.append((selector, style))

        def addBox(self, config: dict[str, object]):
            self.boxes.append(config)

        def zoomTo(self, target: dict[str, object] | None = None):
            self.zoom_target = target

        def setBackgroundColor(self, color: str):
            self.background = color

    class FakePy3Dmol:
        @staticmethod
        def view(width: int, height: int):
            return FakeView()

    class FakeChem:
        @staticmethod
        def SDMolSupplier(path: str, removeHs: bool = False):
            return [object()]

        @staticmethod
        def MolToMolBlock(molecule: object) -> str:
            return "ligand mol"

    runner = _build_runner(tmp_path)
    monkeypatch.setattr(
        "zendock.docking.require_dependency",
        lambda name: FakePy3Dmol if name == "py3Dmol" else FakeChem if name == "rdkit.Chem" else None,
    )

    view = runner.visualize_docking_pose()

    assert len(view.models) == 2
    assert view.models[0][1] == "pdb"
    assert "GLY A   1" in view.models[0][0]
    assert view.models[1] == ("ligand mol", "mol")
    assert ({"protein": True}, {"cartoon": {"colorscheme": "spectrum"}}) in view.styles
    assert ({"model": 1}, {"stick": {"colorscheme": "greenCarbon"}}) in view.styles
