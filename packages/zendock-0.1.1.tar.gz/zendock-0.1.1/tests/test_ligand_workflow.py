from __future__ import annotations

import numbers
import shutil
from pathlib import Path

import pytest

from zendock.ligand import Ligand

SMILES: str = "O=C1c3c(O/C(=C1/O)c2ccc(O)c(O)c2)cc(O)cc3O"
LIGAND_NAME: str = "quercetin"


def _require_workflow_dependencies() -> None:
    pytest.importorskip("rdkit")
    pytest.importorskip("py3Dmol")
    if shutil.which("mk_prepare_ligand.py") is None:
        pytest.skip("mk_prepare_ligand.py is not available in PATH")


@pytest.mark.integration
def test_ligand_workflow_end_to_end(tmp_path: Path):
    _require_workflow_dependencies()

    output_dir = tmp_path / "ligands"

    Quercetin = Ligand(name=LIGAND_NAME, smiles=SMILES, output_dir=output_dir)

    Quercetin.prepare_ligand()
    Quercetin.visualize_ligand()

    assert Path(Quercetin.sdf_path).is_file()
    assert Path(Quercetin.pdbqt_path).is_file()
