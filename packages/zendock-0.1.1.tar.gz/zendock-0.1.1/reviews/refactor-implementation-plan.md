# Refactor Implementation Plan

Source reviews:
- `reviews/design-review.md`
- `reviews/clutter-review.md`

Goal: reduce hidden mutable workflow state, split broad responsibilities, make results and output paths explicit, and remove low-risk clutter while preserving the current notebook-friendly public API.

## Guiding constraints

- Keep the existing public facade usable: `Receptor`, `Ligand`, and `DockingRunner` should continue to work for current README/notebook workflows during the refactor.
- Prefer additive seams first, then migrate internals, then remove compatibility code only when tests cover the replacement behavior.
- Do not change scientific defaults or generated file formats unless a phase explicitly calls that out.
- Each phase should end with `pytest -q`; phases touching packaging should also run an import/build smoke test.

## Phase 0 — Safety baseline and quick clutter wins

Purpose: remove no-risk clutter and add guardrails before architectural changes.

1. Add or update `.gitignore` entries for generated Python caches and notebook checkpoints:
   - `__pycache__/`
   - `*.py[cod]`
   - `.ipynb_checkpoints/`
2. Remove tracked `__pycache__` files from the repo if present.
3. Remove unused test import:
   - `tests/test_ligand_workflow.py`: delete unused `numbers` import.
4. Clean stale comments/doc noise:
   - `src/opinionated_docking/ligand.py`: move the misplaced class-level string into a real class docstring or delete it.
   - `src/opinionated_docking/receptor.py`: remove or resolve stale TODO/self-evident comments.
5. Delete dead helper if still unused:
   - `src/opinionated_docking/docking.py`: remove `_extract_pose_model`, unless multi-pose export is implemented in Phase 3.
6. Notebook cleanup decision:
   - Keep `Docking.ipynb` only if it is the documented prototype; clear outputs.
   - Remove or archive `test.ipynb` unless it has a documented role.

Validation:
- `pytest -q`
- `python -m py_compile src/opinionated_docking/*.py`

## Phase 1 — Explicit dependency, command, and fetch seams

Purpose: isolate external process/network behavior before moving workflow logic.

1. Add `src/opinionated_docking/tools.py`.
2. Introduce a small `ToolRunner` abstraction:
   - `CommandSpec` dataclass: executable, args, optional env, timeout, cwd.
   - `ToolRunner.run(spec) -> subprocess.CompletedProcess[str]` or equivalent.
   - Default implementation wraps current `run_command()` behavior.
3. Keep `src/opinionated_docking/utils.py::run_command()` as a compatibility wrapper around the default `ToolRunner` at first.
4. Replace direct command assembly/execution call sites with command-spec builders plus injected/default runner:
   - `src/opinionated_docking/ligand.py`: ligand preparation command.
   - `src/opinionated_docking/receptor.py`: receptor preparation command.
   - `src/opinionated_docking/docking.py`: result export and trial docking commands.
5. Add `src/opinionated_docking/fetching.py` with a minimal `StructureFetcher`/repository interface for network PDB fetches:
   - timeout-aware default fetcher.
   - cache-path behavior matching current `Receptor` behavior.
6. Add unit tests for command-spec generation without invoking external tools.

Validation:
- `pytest -q`
- Add tests that monkeypatch `ToolRunner.run()` instead of monkeypatching module-level `run_command()`.

## Phase 2 — Centralized output layout

Purpose: make file writes predictable and reusable across ligands, receptors, docking, visualization, and interactions.

1. Add `src/opinionated_docking/workspace.py`.
2. Introduce `Workspace` or `OutputLayout` dataclass:
   - root directory.
   - ligand directory.
   - receptor/preparation directory if needed.
   - docking results directory.
   - pose visualization directory.
   - interaction diagram directory.
3. Encode current defaults to preserve behavior:
   - ligand outputs currently default to `ligands`.
   - docking results currently default to `Docking_Result`.
   - pose visualization currently defaults to `Docking_Pose/...`.
   - interaction diagrams currently default near receptor JSON under `Docking_Interactions`.
4. Update `Ligand`, `Receptor`, and `DockingRunner` constructors/factories to accept optional `workspace`/`output_layout` while preserving old `output_dir` parameters.
5. Replace hidden relative path construction with calls to `OutputLayout` methods.
6. Add unit tests for output path resolution and concurrent-safe custom workspace use.

Validation:
- `pytest -q`
- Existing tests should pass without changing caller code.
- New tests should assert legacy default paths and custom workspace paths.

## Phase 3 — Typed docking results and multi-pose policy

Purpose: replace raw pose strings and filename reconstruction with explicit result objects.

1. Add `src/opinionated_docking/results.py`.
2. Introduce dataclasses:
   - `DockingPose`: pose index, PDBQT block, affinity/energy terms, optional exported PDB/SDF paths.
   - `LigandResult`: ligand identity, receptor identity, pose list, result directory, summary metadata.
   - `DockingResult`: one or more `LigandResult` objects plus run metadata.
3. Update `DockingRunner.run_docking()` to construct and return/store typed result objects while maintaining existing return shape if callers rely on it.
4. Update `save_docking_results()` to make the persistence policy explicit:
   - short-term: persist best pose only but store all pose metadata in memory, and document the limitation.
   - better target: persist all poses with deterministic filenames including pose index.
5. Replace `_resolve_visualization_ligand()`, `_resolve_saved_result_pdb()`, and `_resolve_saved_result_sdf()` filename guessing with object-driven lookup.
6. If legacy lookup remains, make default ligand selection deterministic and raise a clear error when multiple results exist and no ligand is specified.
7. Add tests for:
   - multiple ligands.
   - multiple poses.
   - deterministic default behavior.
   - invalid `pose_index` errors.

Validation:
- `pytest -q`
- Add regression tests around current visualization/export paths.

## Phase 4 — Split `DockingRunner` responsibilities

Purpose: shrink the orchestration class without breaking the facade.

1. Keep `DockingRunner` as the high-level user facade.
2. Extract focused collaborators:
   - `src/opinionated_docking/engines.py`: `DockingEngine` protocol and `VinaEngine` implementation.
   - `src/opinionated_docking/result_store.py`: result persistence/export logic.
   - `src/opinionated_docking/visualization.py`: `PoseVisualizer` and existing `DockingVisualizer` behavior.
   - `src/opinionated_docking/interactions.py`: pandamap interaction diagram export/prep.
3. Move methods out of `src/opinionated_docking/docking.py` in small PR-sized steps:
   - setup/execution first.
   - result save/load second.
   - visualization third.
   - interaction diagrams last.
4. Update imports while keeping backwards-compatible access where practical.
5. Add integration-style tests that exercise `DockingRunner` as a facade and unit tests for each collaborator.

Validation:
- `pytest -q`
- `python -c "from opinionated_docking import DockingRunner, Ligand, Receptor"`

## Phase 5 — Receptor and ligand workflow state objects

Purpose: make workflow ordering explicit and reduce nullable mutable attributes.

1. Add `src/opinionated_docking/models.py` or extend `results.py` with state/value objects:
   - `RawReceptor`
   - `ParsedReceptor`
   - `PreparedReceptor`
   - `PreparedLigand`
2. Change lower-level methods to return value objects instead of only mutating `self`.
3. Keep `Receptor` and `Ligand` as compatibility facades that store the latest returned state for notebook ergonomics.
4. Replace runtime ordering checks with typed inputs in lower-level services where possible.
5. Address stale `Receptor.ligand_info`:
   - remove it and raw visualization highlighting if unused, or
   - populate it from `choose_reference_ligand()` and add tests if highlighting is a desired feature.
6. Add tests for invalid state transitions and serialization-friendly state objects.

Validation:
- `pytest -q`
- Existing README/notebook-equivalent workflow still works through facades.

## Phase 6 — Packaging and dependency policy

Purpose: align runtime dependencies with lazy optional imports and reduce install weight.

1. Move `pytest` out of base dependencies; keep it in `dev` only.
2. Verify whether these are actually required by package runtime:
   - `numpy`
   - `ringtail`
   - `gemmi`
3. Remove unused runtime dependencies or move them to extras if needed by optional workflows.
4. Split optional dependency groups, for example:
   - `prep`: `prody`, `rdkit`, `molscrub`, `meeko`.
   - `dock`: `vina`.
   - `viz`: `py3Dmol`, `pandamap`.
   - `all`: complete workflow stack.
   - `dev`: tests/build tooling.
5. Decide whether `requires-python = "==3.10.*"` is truly necessary; loosen only after testing supported versions.
6. Document external CLI requirements and uv-only git source behavior.

Validation:
- Fresh environment smoke test for base install/import.
- Fresh environment smoke test for `[all]` or equivalent.
- `pytest -q` in dev environment.

## Phase 7 — Documentation and migration notes

Purpose: make refactors discoverable and safe for users.

1. Update `README.md` examples to show:
   - optional custom workspace.
   - explicit result objects.
   - best-pose vs all-pose behavior.
2. Add a short migration section:
   - old facade calls still supported.
   - new recommended typed workflow.
   - dependency extras to install for each workflow.
3. If notebooks remain, clear outputs and update them to use the new facade/result objects.

Validation:
- Run README import examples manually or via doctest-style smoke tests if practical.

## Recommended execution order

1. Phase 0: quick cleanup.
2. Phase 1: `ToolRunner` and fetch seams.
3. Phase 2: `OutputLayout`.
4. Phase 3: typed results.
5. Phase 4: split `DockingRunner` internals.
6. Phase 5: typed receptor/ligand workflow states.
7. Phase 6: dependency extras.
8. Phase 7: docs/notebooks.

## Risk notes

- Highest regression risk: changing result persistence and visualization lookup. Mitigate with tests around current filenames and best-pose behavior before Phase 3.
- Highest user-facing risk: dependency extras. Mitigate with clear install docs and a temporary `all` extra.
- Highest design payoff: typed result/state objects plus `OutputLayout`; these make later module splits much safer.

