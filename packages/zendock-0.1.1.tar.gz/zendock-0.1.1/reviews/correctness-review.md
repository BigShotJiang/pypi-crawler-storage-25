## Review

- Correct: Public API matches README (`DockingRunner`, `Ligand`, `Receptor`) and import/default tests pass.
- Correct: Unit and integration test suite passed in the current environment: `pytest -q` -> `16 passed in 8.39s`.
- Correct: Python source compiles successfully: `python -m py_compile src/opinionated_docking/*.py` -> `py_compile_ok`.
- Note: No evidence-backed functional correctness bugs were found in the inspected code paths.
- Note: Requested context files `plan.md` and `progress.md` were not present in `/home/john/Projects/zendock`, so review was based on README, project config, source, tests, CLI help checks, and test execution.

## Validation

- Ran `pytest -q` successfully.
- Ran `python -m py_compile src/opinionated_docking/*.py` successfully.
- Inspected `README.md`, `pyproject.toml`, `src/opinionated_docking/*.py`, and tests under `tests/`.
- Checked relevant external CLI help for `mk_export.py`, `mk_prepare_receptor.py`, `mk_prepare_ligand.py`, and `scrub.py` where command invocations were used by the package.
