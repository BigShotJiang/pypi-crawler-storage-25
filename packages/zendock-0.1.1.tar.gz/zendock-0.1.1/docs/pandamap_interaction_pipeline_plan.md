# PandaMap Interaction Pipeline Implementation Plan

## Status

Implemented in `src/opinionated_docking/docking.py`.

The current implementation now prepares a PandaMap `HybridProtLigMapper` before exporting:

- 2D interaction diagrams
- 3D interaction diagrams
- plain-text interaction tables/reports

Validation: `pytest -q` passed with `23 passed`.

## Goal

Generate 2D interaction diagrams, 3D interaction diagrams, and interaction tables from a fully prepared PandaMap mapper, matching PandaMap CLI behavior more closely than direct visualization-only calls.

## Implemented Public Methods

### `DockingRunner.export_2d_interaction_diagram(...)`

Creates pose-specific receptor/ligand PDB inputs, constructs a `DockingVisualizer`, and delegates 2D export.

Default output:

```text
Docking_Result/<ligand>_<receptor>_pose<N>_interaction_2d.png
```

### `DockingRunner.export_3d_interaction_diagram(...)`

Creates pose-specific receptor/ligand PDB inputs, constructs a `DockingVisualizer`, and delegates 3D export.

Default output:

```text
Docking_Result/<ligand>_<receptor>_pose<N>_interaction_3d.html
```

### `DockingRunner.export_interaction_table(...)`

Creates pose-specific receptor/ligand PDB inputs, constructs a `DockingVisualizer`, and delegates PandaMap report/table export.

Default output:

```text
Docking_Result/<ligand>_<receptor>_pose<N>_interaction_table.txt
```

### `DockingVisualizer.export_2d_interaction_diagram(...)`

Prepares the mapper, then calls:

```python
mapper.visualize(output_file=resolved_output_file)
```

### `DockingVisualizer.export_3d_interaction_diagram(...)`

Prepares the mapper, then calls:

```python
pandamap.create_3d_view.create_pandamap_3d_viz(...)
```

### `DockingVisualizer.export_interaction_table(...)`

Prepares the mapper, then calls:

```python
mapper.generate_interaction_report(output_file=resolved_output_file)
```

If the installed PandaMap mapper does not expose `generate_interaction_report`, the method raises `DockingExecutionError`.

## Implemented Mapper Preparation

`DockingVisualizer.prepare_mapper_for_interactions()` now centralizes PandaMap preparation.

Pipeline:

1. Build or reuse cached mapper via `build_mapper()`.
2. Return immediately if `_mapper_prepared` is already true.
3. Require `detect_interactions()`.
4. Run `mapper.detect_interactions()`.
5. Try `mapper.calculate_dssp_solvent_accessibility()`.
6. Fall back to `mapper.calculate_realistic_solvent_accessibility()` when DSSP output looks suspicious:
   - too many accessible residues
   - fewer than two accessible residues
7. If DSSP raises, run:

```python
mapper.calculate_realistic_solvent_accessibility(exposure_threshold=0.2)
```

8. If all interacting residues are marked solvent-accessible, rerun stricter filtering:

```python
mapper.calculate_realistic_solvent_accessibility(
    exposure_threshold=0.3,
    max_percent=0.4,
)
```

9. Mark `_mapper_prepared = True`.

This avoids rerunning interaction detection when the same `DockingVisualizer` instance exports multiple artifacts.

## Default `DockingVisualizer` Outputs

When no explicit output path is supplied:

- 2D: `<receptor_pdb_stem>_<ligand_pdb_stem>_interaction_2d.html`
- 3D: `<receptor_pdb_stem>_<ligand_pdb_stem>_interaction_3d.html`
- table: `<receptor_pdb_stem>_<ligand_pdb_stem>_interaction_table.txt`

When `DockingRunner` constructs the visualizer, it supplies a concise output stem (`<ligand>_<receptor>_pose<N>`). This keeps internal artifacts from repeating receptor/ligand names:

- receptor input: `Docking_Result/<ligand>_<receptor>_pose<N>_receptor.pdb`
- ligand input: `Docking_Result/<ligand>_<receptor>_pose<N>_ligand.pdb`
- complex input for PandaMap: `Docking_Result/<ligand>_<receptor>_pose<N>_complex.pdb`

Note: runner-level 2D defaults use `.png`; visualizer-level legacy default still uses the existing `_interaction_2d.html` name unless an explicit output stem is supplied.

## Error Handling

- Missing PandaMap preparation APIs raise `DockingExecutionError`.
- Failure during interaction preparation is wrapped in `DockingExecutionError` with the merged complex path.
- Failure during report/table generation is wrapped in `DockingExecutionError` with the output path.
- DSSP failures are not fatal; they fall back to realistic/geometric solvent accessibility.

## Test Coverage

Added/updated tests cover:

- 2D export prepares interactions before visualization.
- 3D export prepares interactions before `create_pandamap_3d_viz()`.
- Interaction table export calls `generate_interaction_report()`.
- Runner-level table export delegates through `DockingVisualizer`.
- Export paths and parent-directory creation.
- Existing visualization delegation behavior.

## Future Follow-Ups

- Add CLI surface, if/when this package exposes command-line commands.
- Optionally rename visualizer-level default 2D extension from `.html` to `.png` for consistency with the actual PandaMap 2D output.
- Consider adding a structured CSV/JSON interaction table exporter later; current table output is PandaMap’s plain-text report.
