"""Drift measurement strategies."""
