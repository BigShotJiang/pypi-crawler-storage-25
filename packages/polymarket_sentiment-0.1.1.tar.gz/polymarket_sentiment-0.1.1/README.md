# polymarket-sentiment

Prediction market sentiment analysis and probability estimation.

Standalone re-export from [polymarket-trading-mcp](https://github.com/whitmorelabs/polymarket-mcp).

## Install

```bash
pip install polymarket-sentiment
```

## Usage

```python
from polymarket_sentiment import analyze_market_sentiment
```

## Source

Part of [Whitmore Labs polymarket-mcp](https://github.com/whitmorelabs/polymarket-mcp).
