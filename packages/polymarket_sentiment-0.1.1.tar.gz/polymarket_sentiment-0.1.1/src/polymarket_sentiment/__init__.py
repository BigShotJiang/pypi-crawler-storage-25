"""
polymarket-sentiment — Prediction market sentiment analysis and probability estimation.

Standalone re-export from polymarket-trading-mcp.
"""
from polymarket_mcp.tools.sentiment import analyze_market_sentiment

__all__ = ["analyze_market_sentiment"]
__version__ = "0.1.0"
