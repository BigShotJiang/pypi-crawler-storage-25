"""Close-out pipeline handlers."""
