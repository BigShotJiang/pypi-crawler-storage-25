"""HandlerCloseOut — FSM state machine for the close-out pipeline.

Pure state machine logic. Phase order mirrors
omniclaude/scripts/closeout-phase-contract.yaml closeout phases.

Circuit breaker: 3 consecutive failures -> FAILED.
"""

from __future__ import annotations

import json
import logging
from datetime import UTC, datetime

from omnimarket.nodes.node_close_out.close_out_lease import (
    CloseOutLeaseHeldError,
    acquire_close_out_lease,
    release_close_out_lease,
)
from omnimarket.nodes.node_close_out.models.model_close_out_completed_event import (
    ModelCloseOutCompletedEvent,
)
from omnimarket.nodes.node_close_out.models.model_close_out_phase_event import (
    ModelCloseOutPhaseEvent,
)
from omnimarket.nodes.node_close_out.models.model_close_out_skipped import (
    ModelCloseOutSkipped,
)
from omnimarket.nodes.node_close_out.models.model_close_out_start_command import (
    ModelCloseOutStartCommand,
)
from omnimarket.nodes.node_close_out.models.model_close_out_state import (
    TERMINAL_PHASES,
    EnumCloseOutPhase,
    ModelCloseOutState,
    next_phase,
)

logger = logging.getLogger(__name__)


class HandlerCloseOut:
    """FSM handler for the close-out pipeline.

    Pure logic — no external I/O. Callers wire event bus publish/subscribe.
    """

    def start(self, command: ModelCloseOutStartCommand) -> ModelCloseOutState:
        """Initialize close-out state from a start command."""
        return ModelCloseOutState(
            correlation_id=command.correlation_id,
            current_phase=EnumCloseOutPhase.IDLE,
            dry_run=command.dry_run,
            max_consecutive_failures=3,
        )

    def advance(
        self,
        state: ModelCloseOutState,
        phase_success: bool,
        error_message: str | None = None,
        prs_merged: int = 0,
        prs_polished: int = 0,
    ) -> tuple[ModelCloseOutState, ModelCloseOutPhaseEvent]:
        """Advance the FSM by one phase."""
        from_phase = state.current_phase

        if from_phase in TERMINAL_PHASES:
            msg = f"Cannot advance from terminal phase: {from_phase}"
            raise ValueError(msg)

        now = datetime.now(tz=UTC)

        if not phase_success:
            new_failures = state.consecutive_failures + 1
            if new_failures >= state.max_consecutive_failures:
                to_phase = EnumCloseOutPhase.FAILED
                err = (
                    error_message
                    or f"Circuit breaker: {new_failures} consecutive failures"
                )
                new_state = state.model_copy(
                    update={
                        "current_phase": to_phase,
                        "consecutive_failures": new_failures,
                        "error_message": err,
                    }
                )
            else:
                to_phase = from_phase
                new_state = state.model_copy(
                    update={
                        "consecutive_failures": new_failures,
                        "error_message": error_message,
                    }
                )

            event = ModelCloseOutPhaseEvent(
                correlation_id=state.correlation_id,
                from_phase=from_phase,
                to_phase=to_phase,
                success=False,
                timestamp=now,
                error_message=error_message,
            )
            return new_state, event

        to_phase = next_phase(from_phase)
        new_state = state.model_copy(
            update={
                "current_phase": to_phase,
                "consecutive_failures": 0,
                "error_message": None,
                "prs_merged": state.prs_merged + prs_merged,
                "prs_polished": state.prs_polished + prs_polished,
            }
        )

        event = ModelCloseOutPhaseEvent(
            correlation_id=state.correlation_id,
            from_phase=from_phase,
            to_phase=to_phase,
            success=True,
            timestamp=now,
        )
        return new_state, event

    def make_completed_event(
        self,
        state: ModelCloseOutState,
        started_at: datetime,
    ) -> ModelCloseOutCompletedEvent:
        """Create a completion event from the final state."""
        return ModelCloseOutCompletedEvent(
            correlation_id=state.correlation_id,
            final_phase=state.current_phase,
            started_at=started_at,
            completed_at=datetime.now(tz=UTC),
            prs_merged=state.prs_merged,
            prs_polished=state.prs_polished,
            error_message=state.error_message,
        )

    def serialize_event(self, event: ModelCloseOutPhaseEvent) -> bytes:
        """Serialize a phase event to bytes."""
        return json.dumps(event.model_dump(mode="json")).encode()

    def serialize_completed(self, event: ModelCloseOutCompletedEvent) -> bytes:
        """Serialize a completed event to bytes."""
        return json.dumps(event.model_dump(mode="json")).encode()

    def handle(self, command: ModelCloseOutStartCommand) -> ModelCloseOutCompletedEvent:
        """Execute the close-out pipeline."""
        _state, _events, completed = self.run_full_pipeline(command)
        return completed

    def handle_with_guard(
        self,
        command: ModelCloseOutStartCommand,
        state_dir: str,
        holder: str = "node_close_out",
    ) -> ModelCloseOutCompletedEvent | ModelCloseOutSkipped:
        """Execute the close-out pipeline under the concurrent-run guard.

        If another run is already holding the lease (non-stale), this returns
        a ``ModelCloseOutSkipped`` terminal event with
        ``reason='concurrent_run_in_progress'`` instead of running the pipeline.
        Callers must treat ``ModelCloseOutSkipped`` as a success (exit 0) — it
        is the expected outcome when cron ticks overlap.

        Stale leases (older than 2x the expected close-out duration) are
        reclaimed automatically; a crashed prior run never wedges the pipeline.
        """
        correlation_id = str(command.correlation_id)
        try:
            acquire_close_out_lease(state_dir, correlation_id, holder)
        except CloseOutLeaseHeldError as held:
            logger.info(
                "Close-out skipped: concurrent run in progress (holder=%s, "
                "acquired_at=%s)",
                held.holder,
                held.acquired_at.isoformat(),
            )
            return ModelCloseOutSkipped(
                correlation_id=command.correlation_id,
                reason="concurrent_run_in_progress",
                skipped_at=datetime.now(tz=UTC),
                holder=held.holder,
                holder_acquired_at=held.acquired_at,
            )

        try:
            return self.handle(command)
        finally:
            release_close_out_lease(state_dir, correlation_id=correlation_id)

    def run_full_pipeline(
        self,
        command: ModelCloseOutStartCommand,
        phase_results: dict[EnumCloseOutPhase, bool] | None = None,
    ) -> tuple[
        ModelCloseOutState,
        list[ModelCloseOutPhaseEvent],
        ModelCloseOutCompletedEvent,
    ]:
        """Run a complete close-out pipeline with provided results.

        Deterministic entry point for testing.
        """
        started_at = datetime.now(tz=UTC)
        state = self.start(command)
        events: list[ModelCloseOutPhaseEvent] = []
        results = phase_results or {}

        while state.current_phase not in TERMINAL_PHASES:
            target = next_phase(state.current_phase)
            success = results.get(target, True)
            error_msg = None if success else f"Phase {target.value} failed"

            state, event = self.advance(
                state,
                phase_success=success,
                error_message=error_msg,
            )
            events.append(event)

            if not success and state.current_phase not in TERMINAL_PHASES:
                break

        completed = self.make_completed_event(state, started_at)
        return state, events, completed


__all__: list[str] = ["HandlerCloseOut"]
