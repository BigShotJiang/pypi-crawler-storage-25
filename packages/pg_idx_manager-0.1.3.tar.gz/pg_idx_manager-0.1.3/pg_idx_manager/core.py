import logging
import csv
import os
import inspect
from datetime import datetime

class IndexManagerCore:
    """
    Core engine handling PostgreSQL index auditing and safe background cleanup.
    Does not require superuser privileges or invasive external extensions.
    """
    def __init__(self, connection, min_table_rows=0):
        self.conn = connection
        # min_table_rows is retained for backwards compatibility but no longer acts as a constraint

    def parse_explain_plan(self, node, anomalies=None):
        """Recursively traverses the EXPLAIN JSON tree to detect Sequential Scans."""
        if anomalies is None:
            anomalies = []

        if node.get("Node Type") == "Seq Scan":
            anomalies.append({
                "table": node.get("Relation Name"),
                "filter": node.get("Filter")
            })

        if "Plans" in node:
            for sub_node in node["Plans"]:
                self.parse_explain_plan(sub_node, anomalies)

        return anomalies

    def log_to_csv(self, execution_time, scan_type, query):
        """
        Logs query execution metrics to a local CSV file for historical performance auditing.
        Verifies if the file exists: if not, creates it with an initialization header row.
        """
        csv_file = "pg_query_audit.csv"
        file_exists = os.path.isfile(csv_file)
        
        # Capture current execution timestamp
        execution_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Inspect execution stack to identify the external function calling the database
        calling_function = "unknown_context"
        stack = inspect.stack()
        for frame in stack:
            if "pg_idx_manager" not in frame.filename and "inspect" not in frame.filename:
                calling_function = frame.function
                break

        # Open file in append mode (automatically creates the file if it does not exist)
        with open(csv_file, mode="a", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            
            # If the file did not exist, write the column headers first
            if not file_exists:
                writer.writerow(["execution_date", "calling_function", "execution_time_ms", "scan_type", "raw_sql"])
                
            # Append the current query execution metrics row
            writer.writerow([execution_timestamp, calling_function, execution_time, scan_type, query.strip()])

    def analyze_query(self, query, params=None):
        """
        Executes an EXPLAIN (ANALYZE, FORMAT JSON) on the target query.
        Safely unpacks the driver architecture and logs metrics to CSV automatically.
        """
        anomalies_detected = []
        with self.conn.cursor() as cursor:
            # Pass bind parameters to prevent placeholder syntax errors on "%" symbols
            cursor.execute(f"EXPLAIN (ANALYZE, FORMAT JSON) {query}", params)
            raw_result = cursor.fetchone()
            
            # Step 1: Extract the list from the psycopg2 tuple
            if isinstance(raw_result, tuple) and len(raw_result) > 0:
                raw_result = raw_result[0]
            
            # Step 2: Extract the internal dictionary from the list
            if isinstance(raw_result, list) and len(raw_result) > 0:
                raw_result = raw_result[0]
                
            # Final validation: check if we successfully unpacked into a dictionary
            if not isinstance(raw_result, dict):
                raise ValueError("Failed to parse PostgreSQL JSON plan into a dictionary configuration.")
                
            plan = raw_result.get("Plan")
            execution_time_ms = raw_result.get("Execution Time", 0.0)
            
            if not plan:
                raise ValueError("The 'Plan' root node is missing from the database engine response.")
                
            raw_anomalies = self.parse_explain_plan(plan)
            
            # Populate reporting details
            for anomaly in raw_anomalies:
                anomaly["execution_time"] = execution_time_ms
                anomalies_detected.append(anomaly)
            
            # AUTOMATIC LOGGING TRIGGER
            # Categorize the query based on the presence of Sequential Scan anomalies
            scan_type = "SEQUENTIAL SCAN" if anomalies_detected else "INDEX SCAN"
            self.log_to_csv(execution_time_ms, scan_type, query)
                    
        return anomalies_detected, execution_time_ms

    def get_unused_indexes(self):
        """Scans pg_stat_user_indexes for dead indexes (idx_scan = 0)."""
        sql = """
            SELECT schemaname, relname AS table_name, indexrelname AS index_name
            FROM pg_stat_user_indexes
            JOIN pg_index ON pg_stat_user_indexes.indexrelid = pg_index.indexrelid
            WHERE idx_scan = 0 AND indisunique = FALSE
            ORDER BY relname ASC;
        """
        unused = []
        with self.conn.cursor() as cursor:
            cursor.execute(sql)
            for row in cursor.fetchall():
                unused.append({"schema": row[0], "table": row[1], "index": row[2]})
        return unused

    def drop_index_safely(self, index_name, schema="public"):
        """Drops an index asynchronously without acquiring exclusive locks."""
        sql = f"DROP INDEX CONCURRENTLY {schema}.{index_name};"
        with self.conn.cursor() as cursor:
            cursor.execute(sql)
            self.conn.commit()
