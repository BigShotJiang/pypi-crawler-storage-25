# SPDX-FileCopyrightText: Copyright © 2024-2026 Damian Anders <damian.anders@tu-dresden.de>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

"""Functions for determining properties of \"harmonic suppression\""""

import numba as nb
import numpy as np
from numpy import typing as npt

__all__ = ["sensor_angle_condition_numbers"]

@nb.njit(cache=True, parallel=True)
def sensor_angle_condition_numbers(harmonics: npt.NDArray[np.float64],
                                   positions: npt.NDArray[np.float64],
                                   ) -> npt.NDArray[np.float64]:
	"""
	Determines the condition of the frequency-dependent sensor position matrix from the sensor angle positions and the frequency lines.

	Parameters
	----------
	harmonics : npt.NDArray[np.float64]
		Harmonics at which the condition is to be determined.
	positions : npt.NDArray[np.float64]
		Sensor angle positions in rad.

	Returns
	-------
	npt.NDArray[np.float64]
		  Condition numbers of the position matrix for ``harmonics``.
	"""

	posVektor = np.exp(1j * positions)

	condition_numbers = np.empty(harmonics.shape[0], dtype=np.float64)
	for f in nb.prange(harmonics.shape[0]):
		posMatrix = np.column_stack((posVektor,  # eigene `posMatrix` für jeden Thread, sonst race conditions
									 np.exp(1j * harmonics[f] * positions)))
		condition_numbers[f] = np.linalg.cond(posMatrix)

	return condition_numbers
# SCHÖÖÖÖÖÖÖÖÖÖÖÖÖÖÖÖÖÖÖÖÖÖÖÖÖÖÖÖÖÖÖÖÖÖÖÖÖÖÖÖÖÖN!