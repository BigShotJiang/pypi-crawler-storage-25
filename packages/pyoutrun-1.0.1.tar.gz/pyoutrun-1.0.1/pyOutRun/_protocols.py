# SPDX-FileCopyrightText: Copyright © 2024-2026 Damian Anders <damian.anders@tu-dresden.de>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from typing import Protocol

import numpy as np
import numpy.typing as npt

__all__ = ["FitFunction"]

class FitFunction(Protocol):
	def __call__(self,
				 params: list[float],
				 xVektor: npt.NDArray[np.float64],
				 yArray: npt.NDArray[np.float64],
				 *args,
) -> np.float64:
		...
