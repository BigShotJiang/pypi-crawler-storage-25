import hashlib
import queue
import threading

import numpy as np
from .message import AssistantMessage, MessageChunk, SystemMessage
from .utils import truncate
from modict import modict
import io
import os
from openai import OpenAI, OpenAIError
from typing import Union, List
from .stream_utils import MappingStreamProcessor
from .event import (
    AssistantInterrupted,
    ResponseContentDeltaEvent,
    ResponseDoneEvent,
    ResponseMessageDeltaEvent,
    ResponseOutputItemEvent,
    ResponseReasoningDeltaEvent,
    ResponseStartEvent,
    ResponseToolCallsDeltaEvent,
    ServerToolCallEvent,
)
from codex_backend_sdk import CodexClient

class ChunkStreamer(MappingStreamProcessor):
    """Stream processor for AI response chunks, handling content, reasoning, and tool calls.

    Args:
        agent: The agent instance.
        threaded: Whether to process streams in separate threads.
    """

    def __init__(self,agent, threaded=True):
        self.agent=agent
        super().__init__(
            defaults=dict(content='',reasoning='',tool_calls=None,output_items=None),
            processors=dict(content=self.agent.get_stream_processors("content")),
            type=MessageChunk,
            threaded=threaded
        )


class AIClientError(Exception):
    """Base exception for AI client errors."""
    pass


class AIBadRequestError(AIClientError):
    """Raised when the backend rejects the request as malformed."""
    pass


class APIAuthenticationError(AIClientError):
    """Exception raised for API authentication failures."""
    pass


MAX_EMBEDDING_INPUT_TOKENS = 7500

class AIClient:
    """Client for Codex backend LLM/embedding/STT calls plus OpenAI-key TTS/token helpers."""

    _api_key_validation_cache = {}
    _api_key_validation_lock = threading.Lock()

    def __init__(self, agent):
        """Initialize AI clients from agent config.

        Args:
            agent: The agent instance containing configuration and API key.
        """
        self.agent=agent
        self._client = None
        self._codex_client = None

    @property
    def client(self):
        if self._client is None:
            api_key = self.openai_api_key()
            try:
                self._client = OpenAI(api_key=api_key, timeout=180, max_retries=3)
                if self.agent.config.get("validate_openai_api_key", True) and not self.api_key_is_valid(api_key):
                    self._client = None
                    raise self.authentication_error()
            except OpenAIError:
                self._client = None
                raise self.authentication_error()
        return self._client

    @property
    def codex_client(self):
        """Client used for LLM calls through the ChatGPT Codex backend."""
        if self._codex_client is None:
            model = self.agent.config.get('model') or "gpt-5.4"
            self._codex_client = CodexClient(model=model).authenticate(request_api_key=False)
        return self._codex_client

    def abort(self):
        if self._codex_client is not None and hasattr(self._codex_client, "abort"):
            self._codex_client.abort()

    def openai_api_key(self):
        return self.agent.config.get("openai_api_key") or os.getenv("OPENAI_API_KEY")

    def authentication_error(self):
        return APIAuthenticationError(
            "Missing or invalid OpenAI API key. You can pass it when creating the agent with "
            "`agent=Agent(openai_api_key='your_api_key')` or via `agent.config.openai_api_key` "
            "or set the OPENAI_API_KEY environment variable. You can get an API key at "
            "https://platform.openai.com/account/api-keys."
        )

    def api_key_cache_key(self, api_key):
        return hashlib.sha256((api_key or "").encode()).hexdigest()

    def api_key_is_valid(self, api_key=None):
        """Verify the OpenAI API key once per key value."""
        api_key = self.openai_api_key() if api_key is None else api_key
        cache_key = self.api_key_cache_key(api_key)
        with self._api_key_validation_lock:
            if cache_key in self._api_key_validation_cache:
                return self._api_key_validation_cache[cache_key]

        try:
            validation_client = self._client or OpenAI(api_key=api_key, timeout=180, max_retries=3)
            validation_client.models.list()
            valid = True
        except Exception:
            valid = False

        with self._api_key_validation_lock:
            self._api_key_validation_cache[cache_key] = valid
        return valid

    def text_to_audio(self, model=None, voice=None, input='', voice_instructions='', **kwargs):
        """
        Generate speech audio from text using OpenAI TTS.

        Args:
            model: TTS model identifier (default: "gpt-4o-mini-tts")
            voice: OpenAI-style voice name (alloy, echo, fable, onyx, nova, shimmer)
            input: Text to synthesize
            voice_instructions: Tone hint
            **kwargs: Additional parameters

        Returns:
            BytesIO buffer containing MP3 audio
        """
        # Build TTS input
        params = modict(
            model=model or "gpt-4o-mini-tts",
            voice=voice or "nova",
            instructions=voice_instructions or "You speak with a friendly and casual tone.",
            input=input
        )

        # Override with any additional kwargs
        params.update(kwargs)

        # Call OpenAI API
        try:
            from pydub import AudioSegment

            mp3_buffer = io.BytesIO()

            response = self.client.audio.speech.create(**params)

            for chunk in response.iter_bytes():
                mp3_buffer.write(chunk)

            mp3_buffer.seek(0)

            audio = AudioSegment.from_file(mp3_buffer,format="mp3").set_channels(1)

            return audio

        except Exception as e:
            raise AIClientError(f"TTS generation failed: {str(e)}")

    def audio_to_text(
        self,
        source: Union[str, io.BytesIO, bytes],
        model: str = "gpt-4o-mini-transcribe",
        language: str = None,
        prompt: str = None,
        response_format: str = "text",
        temperature: float = 0.0
    ) -> str:
        """
        Convert audio to text using the Codex backend SDK OAuth client.

        Args:
            source: Audio data as file_path string, BytesIO object or bytes
            model: Transcription model to use (default: "gpt-4o-mini-transcribe")
            language: ISO-639-1 language code (e.g., "en", "fr"). If None, language is auto-detected.
            prompt: Optional text to guide the model's style
            response_format: Format of output ("text", "json", "verbose_json", "srt", "vtt")
            temperature: Sampling temperature between 0 and 1 (default: 0.0)

        Returns:
            Transcribed text as a string, or raw subtitle text for srt/vtt formats.
        """
        filename = "audio.mp3"
        if isinstance(source, str) and os.path.isfile(source):
            filename = os.path.basename(source) or filename
            with open(source, "rb") as f:
                audio = io.BytesIO(f.read())
        elif isinstance(source, bytes):
            audio = io.BytesIO(source)
        elif isinstance(source, io.BytesIO):
            audio = source
            filename = getattr(source, "name", filename) or filename
        else:
            raise NotImplementedError(f"Unsupported audio source: {source}")

        audio.seek(0)
        audio.name = filename

        transcription_params = {
            "model": model,
            "file": audio,
            "response_format": response_format,
            "temperature": temperature,
        }
        if language:
            transcription_params["language"] = language
        if prompt:
            transcription_params["prompt"] = prompt

        try:
            transcript = self.codex_client.audio.transcriptions.create(**transcription_params)
        except Exception as e:
            raise AIClientError(f"Failed to transcribe audio with Codex backend SDK: {str(e)}")

        if isinstance(transcript, str):
            return transcript
        if hasattr(transcript, "text"):
            return transcript.text
        return transcript

    def _stream_chunks(self, params):
        params['tools'] = [
            tool.to_response_tool() if hasattr(tool, "to_response_tool") else tool
            for tool in params.get('tools') or []
        ] or None

        try:
            response_params = self._to_codex_response_params(params)
            response = self.codex_client.responses.create(**response_params, stream=True)
        except Exception as e:
            if self.is_bad_request_error(e):
                raise AIBadRequestError(str(e)) from e
            import traceback
            import sys
            print("\n[ERROR in ai.run setup]:", file=sys.stderr)
            traceback.print_exc(file=sys.stderr)
            yield MessageChunk(content=f"Hmmm, sorry! There was an error while calling the Codex backend client. Here is the error message I got:\n\n ```\n{str(e)}\n```")
            return

        try:
            tool_call_index = 0
            for event in self._iter_response_events(response):
                self.agent.mainloop_manager.touch_activity("response_stream")
                if getattr(event, "type", None) == "response.completed":
                    completed = self._event_response(event)
                    self.agent.status_manager.cache_api_status(
                        usage=modict(completed.get("usage") or {}),
                        model=completed.get("model") or response_params.get("model"),
                        quota=self.get_quota_usage(),
                    )
                    continue
                msg_chunk = self._codex_event_to_message_chunk(event, tool_call_index)
                if msg_chunk and msg_chunk.get("tool_calls"):
                    tool_call_index += 1
                if msg_chunk:
                    yield msg_chunk
        except Exception as e:
            if self.is_bad_request_error(e):
                raise AIBadRequestError(str(e)) from e
            yield MessageChunk(content=f"Hmmm, sorry! There was an error while reading the Codex backend stream. Here is the error message I got:\n\n ```\n{str(e)}\n```")

    def _iter_response_events(self, response):
        timeout = float(self.agent.config.get("codex_stream_idle_timeout", 0) or 0)
        if timeout <= 0:
            yield from response
            return

        events = queue.Queue()
        sentinel = object()

        def consume():
            try:
                for event in response:
                    events.put(("event", event))
            except BaseException as exc:
                events.put(("error", exc))
            finally:
                events.put(("done", sentinel))

        threading.Thread(target=consume, name="codex-response-stream", daemon=True).start()
        while True:
            try:
                kind, value = events.get(timeout=timeout)
            except queue.Empty as exc:
                try:
                    self.abort()
                finally:
                    raise AIClientError(
                        f"Codex backend stream produced no events for {timeout:g}s"
                    ) from exc
            if kind == "done":
                break
            if kind == "error":
                raise value
            yield value

    def is_bad_request_error(self, exc):
        response = getattr(exc, "response", None)
        status_code = getattr(response, "status_code", None)
        if status_code == 400:
            return True
        status_code = getattr(exc, "status_code", None)
        if status_code == 400:
            return True
        return "400" in str(exc) and "Bad Request" in str(exc)

    def get_quota_usage(self):
        try:
            return self.codex_client.codex.usage()
        except Exception:
            return None

    def count_input_tokens(self, **payload):
        try:
            response = self.client.responses.input_tokens.count(**payload)
        except Exception as e:
            raise AIClientError(f"Failed to count input tokens: {str(e)}")
        return int(response.input_tokens)

    def _split_codex_messages(self, messages):
        instructions = []
        history = []
        in_instruction_prefix = True
        for msg in messages:
            if in_instruction_prefix and isinstance(msg, SystemMessage):
                instruction = msg.instruction_text()
                if instruction:
                    instructions.append(instruction)
                continue
            in_instruction_prefix = False
            response_format = msg.to_response_format()
            if response_format is None:
                continue
            if isinstance(response_format, list):
                history.extend(response_format)
            else:
                history.append(response_format)
        return "\n\n".join(instructions), history

    def _to_codex_response_params(self, params):
        instructions, history = self._split_codex_messages(params.get("messages", []))
        tools = params.get("tools") or []
        model = params.get("model") or "gpt-5.4"
        reasoning = modict(params.get("reasoning") or {})
        text = modict(params.get("text") or {})
        if not reasoning and params.get("reasoning_effort"):
            reasoning = modict(effort=params.get("reasoning_effort"), summary="auto")
        if not text and params.get("verbosity"):
            text = modict(verbosity=params.get("verbosity"))
        payload = {
            "input": history,
            "instructions": instructions,
            "model": model,
            "tools": tools or None,
            "tool_choice": "auto" if tools else "none",
            "parallel_tool_calls": params.get("parallel_tool_calls"),
            "prompt_cache_key": params.get("prompt_cache_key"),
        }
        if reasoning:
            payload["reasoning"] = reasoning
            payload["include"] = ["reasoning.encrypted_content"]
        if text:
            payload["text"] = text
        return payload

    def _codex_event_to_message_chunk(self, event, tool_call_index=0):
        event_type = getattr(event, "type", "")
        if event_type in {"response.output_text.delta", "response.content_part.delta"}:
            return MessageChunk(content=self._event_delta_text(event))
        if event_type == "response.reasoning_summary_part.delta":
            return MessageChunk(reasoning=self._event_delta_text(event))
        if event_type == "response.output_item.done":
            item = modict(getattr(event, "item", None) or {})
            if item.get("type") in {"function_call", "custom_tool_call"}:
                return self._tool_call_item_to_message_chunk(item, tool_call_index)
            if item.get("type") == "reasoning":
                return MessageChunk(reasoning=self._reasoning_item_text(item))
            return MessageChunk(output_items=[item])
        if event_type in {"response.failed", "error"}:
            error = self._event_error(event)
            code = str(error.get("code") or "")
            message = str(error.get("message") or "Response failed")
            if code == "400" or "bad_request" in code.lower():
                raise AIBadRequestError(message)
            return MessageChunk(
                content=(
                    "Hmmm, sorry! The Codex backend returned an error:\n\n"
                    f"```\n[{code or 'error'}] {message}\n```"
                )
            )
        return None

    def _tool_call_item_to_message_chunk(self, item, tool_call_index=0):
        if item.get("type") == "custom_tool_call":
            tool_call = modict({
                "index": tool_call_index,
                "type": "custom_tool_call",
                "call_id": item.get("call_id", ""),
                "name": item.get("name", ""),
                "input": item.get("input", ""),
            })
            return MessageChunk(tool_calls=[tool_call])
        tool_call = modict({
            "index": tool_call_index,
            "type": "function_call",
            "call_id": item.get("call_id", ""),
            "name": item.get("name", ""),
            "arguments": item.get("arguments", "{}"),
        })
        return MessageChunk(tool_calls=[tool_call])

    def _event_delta_text(self, event):
        delta = getattr(event, "delta", "")
        if isinstance(delta, dict):
            return delta.get("text", "")
        return delta or ""

    def _reasoning_item_text(self, item):
        parts = []
        for part in item.get("summary") or []:
            if isinstance(part, dict):
                parts.append(part.get("text", ""))
        return "".join(parts) or item.get("encrypted_content", "")

    def _event_response(self, event):
        response = getattr(event, "response", None)
        if hasattr(response, "model_dump"):
            return response.model_dump()
        return response if isinstance(response, dict) else {}

    def _event_error(self, event):
        response = self._event_response(event)
        error = response.get("error") or getattr(event, "error", None) or {}
        if hasattr(error, "model_dump"):
            return error.model_dump()
        return error if isinstance(error, dict) else {"message": str(error)}

    def run(self, **params):
        stream = ChunkStreamer(self.agent)(self._stream_chunks(params))
        message = AssistantMessage(name=self.agent.config.get('name','assistant'))

        self.agent.emit(ResponseStartEvent, message=message)

        try:
            for chunk in stream:
                self.agent.check_interrupt()
                message.add_chunk(chunk)

                if chunk.get('content'):
                    self.agent.emit(
                        ResponseContentDeltaEvent,
                        delta=chunk.content,
                    )

                if chunk.get('reasoning'):
                    self.agent.emit(
                        ResponseReasoningDeltaEvent,
                        delta=chunk.reasoning,
                    )

                if chunk.get('tool_calls'):
                    self.agent.emit(
                        ResponseToolCallsDeltaEvent,
                        tool_calls=chunk.tool_calls,
                    )

                for item in chunk.get('output_items') or []:
                    self.agent.emit(
                        ResponseOutputItemEvent,
                        item=item,
                        chunk=chunk,
                        message=message,
                    )
                    server_tool = self.agent.tools_manager.server_tool_for_item(item)
                    if server_tool:
                        self.agent.emit(
                            ServerToolCallEvent,
                            item=item,
                            tool=server_tool,
                            name=server_tool.type,
                            call_id=item.get("call_id") or item.get("id") or server_tool.type,
                            status=item.get("status", ""),
                        )

                message_delta = modict({
                    key: chunk.get(key)
                    for key in ("content", "reasoning", "tool_calls", "output_items")
                    if chunk.get(key)
                })
                if message_delta:
                    self.agent.emit(ResponseMessageDeltaEvent, delta=message_delta)
        except KeyboardInterrupt:
            self.agent.interrupt("keyboard_interrupt")
            raise AssistantInterrupted()

        self.agent.emit(ResponseDoneEvent, message=message)
        return message

    def _normalize(self, vect, precision=5):
        """Normalize a vector and round to specified precision."""
        inv_norm = 1.0 / np.linalg.norm(vect, ord=2)
        return [round(x_i * inv_norm, precision) for x_i in vect]

    def truncate_embedding_input(self, content, model="text-embedding-3-small"):
        return truncate(content, max_tokens=MAX_EMBEDDING_INPUT_TOKENS, model=model)

    def embed_content(self, content: str, precision=5, dimensions=128, model="text-embedding-3-small"):
        """
        Embed a text string using the Codex backend SDK OAuth client.

        Args:
            content: Text string to embed
            precision: Number of decimal places for rounding (default: 5)
            dimensions: Embedding dimensions (default: 128)
            model: Embedding model to use (default: text-embedding-3-small)

        Returns:
            A normalized embedding vector
        """
        if not isinstance(content, str):
            raise ValueError(f"Content must be a string, got {type(content)}")
        content = self.truncate_embedding_input(content, model=model)
        if not content.strip():
            raise ValueError("Content must not be empty")

        try:
            response = self.codex_client.embeddings.create(
                model=model,
                input=content,
                dimensions=dimensions
            )
            embedding = response.data[0].embedding
        except Exception as e:
            raise AIClientError(f"Failed to generate embedding: {str(e)}")

        return self._normalize(embedding, precision)

    def embed_contents(self, contents: List[str], precision=5, dimensions=128, model="text-embedding-3-small"):
        """
        Embed multiple text strings using the Codex backend SDK OAuth client.

        Args:
            contents: List of text strings to embed
            precision: Number of decimal places for rounding (default: 5)
            dimensions: Embedding dimensions (default: 128)
            model: Embedding model to use (default: text-embedding-3-small)

        Returns:
            List of normalized embedding vectors

        Note:
            The embeddings API handles batching automatically for better performance.
        """
        if not contents:
            return []
        if not all(isinstance(content, str) for content in contents):
            raise ValueError("All contents must be strings")
        contents = [self.truncate_embedding_input(content) for content in contents]
        if any(not content.strip() for content in contents):
            raise ValueError("Embedding contents must not contain empty strings")

        try:
            response = self.codex_client.embeddings.create(
                model=model,
                input=contents,
                dimensions=dimensions
            )
            embeddings = [self._normalize(item.embedding, precision) for item in response.data]
        except Exception as e:
            raise AIClientError(f"Failed to generate embeddings: {str(e)}")

        return embeddings

    def message_embedding_content(self, msg):
        if hasattr(msg, 'content') and isinstance(msg.content, str):
            return msg.content.strip()
        raise ValueError("Message must have text content")

    def zero_embedding(self, dimensions=128):
        return [0.0] * int(dimensions)

    def similarity(self, emb1, emb2):
        """
        Calculate shifted positive cosine similarity between two embeddings.
        Returns a score between 0 and 1.
        """
        return 0.5 + 0.5 * np.dot(np.array(emb1), np.array(emb2))

    def embed_message(self, msg, precision=5, dimensions=128, model="text-embedding-3-small"):
        """
        Embed a Message object and assign the result to msg.embedding.

        Args:
            msg: Message object with text content
            precision: Number of decimal places for rounding (default: 5)
            dimensions: Embedding dimensions (default: 128)
            model: Embedding model to use through the Codex backend SDK (default: text-embedding-3-small)

        Returns:
            The embedding vector (also assigned to msg.embedding)

        Note:
            Only text content is supported.
        """
        content = self.message_embedding_content(msg)
        if not content:
            embedding = self.zero_embedding(dimensions)
            msg.embedding = embedding
            return embedding
        embedding = self.embed_content(content, precision, dimensions, model)
        msg.embedding = embedding
        return embedding

    def embed_messages(self, messages, precision=5, dimensions=128, model="text-embedding-3-small"):
        """
        Embed multiple Message objects in one embeddings API request and assign
        the resulting vectors to each message.
        """
        messages = list(messages)
        if not messages:
            return []

        embeddings = [None] * len(messages)
        batch = []
        batch_indices = []
        for index, msg in enumerate(messages):
            content = self.message_embedding_content(msg)
            if not content:
                embedding = self.zero_embedding(dimensions)
                msg.embedding = embedding
                embeddings[index] = embedding
                continue
            batch.append(content)
            batch_indices.append(index)

        if not batch:
            return embeddings

        batch_embeddings = self.embed_contents(
            batch,
            precision=precision,
            dimensions=dimensions,
            model=model,
        )
        if len(batch_embeddings) != len(batch):
            raise AIClientError(
                f"Expected {len(batch)} embeddings, got {len(batch_embeddings)}"
            )
        for index, embedding in zip(batch_indices, batch_embeddings):
            msg = messages[index]
            msg.embedding = embedding
            embeddings[index] = embedding
        return embeddings
