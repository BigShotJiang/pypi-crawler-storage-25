"""Playwright-backed browser session utilities.

This module centralizes browser automation for the agent runtime. It uses a
persistent Chromium profile under the agent runtime directory by default so web
sessions, cookies, permissions, and local storage can survive between launches.
"""

from __future__ import annotations

import asyncio
import json
import os
import subprocess
import sys
import threading
from dataclasses import dataclass, field
from typing import Any, Callable

from . import utils


DEFAULT_VIEWPORT = {"width": 1365, "height": 900}
BROWSER_AGENT_ID_ATTR = "data-agent-browser-id"


class BrowserError(RuntimeError):
    """Raised when the Playwright browser backend cannot be used."""


SNAPSHOT_SCRIPT = r"""
({ idAttr, maxElements, maxTextLength }) => {
  const interestingTags = new Set(['A', 'BUTTON', 'INPUT', 'TEXTAREA', 'SELECT', 'OPTION', 'SUMMARY', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6']);
  const interactiveRoles = new Set(['button', 'link', 'checkbox', 'radio', 'textbox', 'searchbox', 'combobox', 'listbox', 'option', 'tab', 'menuitem', 'switch', 'slider', 'spinbutton']);

  function normalize(text) {
    return (text || '').replace(/\s+/g, ' ').trim();
  }

  function isVisible(el) {
    if (!el || el.nodeType !== Node.ELEMENT_NODE) return false;
    const style = window.getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity) === 0) return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function isClickable(el) {
    return !!(el.onclick || el.closest('a,button,[role="button"],[role="link"],[onclick]'));
  }

  function roleFor(el) {
    const explicit = normalize(el.getAttribute('role')).toLowerCase();
    if (explicit) return explicit;
    const tag = el.tagName;
    const type = normalize(el.getAttribute('type')).toLowerCase();
    if (tag === 'A') return 'link';
    if (tag === 'BUTTON') return 'button';
    if (tag === 'TEXTAREA') return 'textarea';
    if (tag === 'SELECT') return 'select';
    if (tag === 'INPUT') {
      if (['button', 'submit', 'reset'].includes(type)) return 'button';
      if (['checkbox', 'radio', 'range'].includes(type)) return type;
      return type || 'input';
    }
    if (/^H[1-6]$/.test(tag)) return 'heading';
    if (tag === 'SUMMARY') return 'summary';
    if (tag === 'LABEL') return 'label';
    if (isClickable(el)) return 'clickable';
    return tag.toLowerCase();
  }

  function nameFor(el) {
    const aria = normalize(el.getAttribute('aria-label'));
    if (aria) return aria;
    const labelledBy = normalize(el.getAttribute('aria-labelledby'));
    if (labelledBy) {
      const text = labelledBy.split(/\s+/).map(id => normalize(document.getElementById(id)?.innerText)).filter(Boolean).join(' ');
      if (text) return text;
    }
    const tag = el.tagName;
    if (tag === 'INPUT') {
      const id = el.getAttribute('id');
      if (id) {
        const label = document.querySelector(`label[for="${CSS.escape(id)}"]`);
        const labelText = normalize(label?.innerText);
        if (labelText) return labelText;
      }
      return normalize(el.getAttribute('placeholder') || el.getAttribute('name') || el.value || el.getAttribute('type'));
    }
    if (tag === 'TEXTAREA') return normalize(el.getAttribute('placeholder') || el.getAttribute('name') || el.value || el.innerText);
    if (tag === 'SELECT') return normalize(el.getAttribute('name') || el.selectedOptions?.[0]?.innerText || el.innerText);
    if (tag === 'A') return normalize(el.innerText || el.getAttribute('title') || el.getAttribute('href'));
    return normalize(el.innerText || el.getAttribute('title') || el.getAttribute('name') || el.value);
  }

  function isInteresting(el) {
    const role = roleFor(el);
    if (interactiveRoles.has(role)) return true;
    if (interestingTags.has(el.tagName)) return true;
    if (el.hasAttribute('contenteditable')) return true;
    if (el.hasAttribute('tabindex') && Number(el.getAttribute('tabindex')) >= 0) return true;
    if (isClickable(el)) return true;
    return false;
  }

  const elements = [];
  let nextId = 1;
  for (const el of Array.from(document.querySelectorAll('body *'))) {
    if (elements.length >= maxElements) break;
    if (!isVisible(el) || !isInteresting(el)) continue;
    const role = roleFor(el);
    let name = nameFor(el).slice(0, maxTextLength);
    if (!name && !['input', 'textarea', 'select', 'checkbox', 'radio', 'button'].includes(role)) continue;

    const id = String(nextId++);
    el.setAttribute(idAttr, id);
    const rect = el.getBoundingClientRect();
    const item = {
      id,
      role,
      name,
      tag: el.tagName.toLowerCase(),
      text: normalize(el.innerText).slice(0, maxTextLength),
      href: el.href || null,
      type: el.getAttribute('type') || null,
      value: el.value || null,
      placeholder: el.getAttribute('placeholder') || null,
      disabled: !!el.disabled || el.getAttribute('aria-disabled') === 'true',
      checked: !!el.checked,
      rect: { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height) }
    };
    elements.push(item);
  }

  return {
    url: location.href,
    title: document.title,
    elements,
    truncated: elements.length >= maxElements
  };
}
"""


def browser_profile_dir(profile_name: str = "default") -> str:
    """Return the persistent Chromium profile directory for a browser profile."""
    safe_name = str(profile_name or "default").strip() or "default"
    return utils.runtime_join("browser", safe_name)


def ensure_browser_profile_dir(profile_name: str = "default") -> str:
    """Create and return the persistent Chromium profile directory."""
    path = browser_profile_dir(profile_name)
    os.makedirs(path, exist_ok=True)
    return path


def install_playwright_chromium() -> subprocess.CompletedProcess[str]:
    """Install Playwright's managed Chromium browser for the current Python env."""
    return subprocess.run(
        [sys.executable, "-m", "playwright", "install", "chromium"],
        text=True,
        capture_output=True,
        check=False,
    )


def _playwright_import_error() -> BrowserError:
    return BrowserError(
        "Playwright is not installed. Install the package and browser runtime with: "
        "python -m pip install playwright && python -m playwright install chromium"
    )


def _default_async_playwright():
    try:
        from playwright.async_api import async_playwright
    except ImportError as exc:  # pragma: no cover - exercised only without dependency
        raise _playwright_import_error() from exc
    return async_playwright()


@dataclass
class BrowserSession:
    """A persistent Chromium browser session backed by Playwright.

    The session owns one persistent browser context. Pages created from the
    context share the profile stored under ``runtime/browser/<profile_name>`` by
    default.
    """

    headless: bool = True
    profile_name: str = "default"
    profile_dir: str | None = None
    viewport: dict[str, int] | None = field(default_factory=lambda: dict(DEFAULT_VIEWPORT))
    extra_args: list[str] = field(default_factory=list)
    playwright_factory: Callable[[], Any] | None = None

    _playwright_manager: Any = field(default=None, init=False, repr=False)
    _playwright: Any = field(default=None, init=False, repr=False)
    _context: Any = field(default=None, init=False, repr=False)
    _active_page: Any = field(default=None, init=False, repr=False)
    _active_page_explicit: bool = field(default=False, init=False, repr=False)

    @property
    def user_data_dir(self) -> str:
        return self.profile_dir or browser_profile_dir(self.profile_name)

    @property
    def context(self) -> Any:
        if self._context is None:
            raise BrowserError("Browser session is not started. Call start() first.")
        return self._context

    @property
    def is_started(self) -> bool:
        return self._context is not None

    async def start(self) -> "BrowserSession":
        """Start Chromium with a persistent profile if not already started."""
        if self._context is not None:
            return self

        os.makedirs(self.user_data_dir, exist_ok=True)
        self._playwright_manager = (
            self.playwright_factory() if self.playwright_factory else _default_async_playwright()
        )
        self._playwright = await self._playwright_manager.start()
        self._context = await self._playwright.chromium.launch_persistent_context(
            user_data_dir=self.user_data_dir,
            headless=self.headless,
            viewport=self.viewport,
            args=list(self.extra_args),
        )
        return self

    async def stop(self) -> None:
        """Close the browser context and stop Playwright."""
        context = self._context
        playwright = self._playwright
        self._context = None
        self._playwright = None
        self._playwright_manager = None
        self._active_page = None
        self._active_page_explicit = False

        if context is not None:
            await context.close()
        if playwright is not None:
            await playwright.stop()

    async def __aenter__(self) -> "BrowserSession":
        return await self.start()

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.stop()

    async def new_page(self) -> Any:
        """Open a new page in the persistent context and make it active."""
        await self.start()
        self._active_page = await self.context.new_page()
        self._active_page_explicit = True
        return self._active_page

    async def pages(self) -> list[Any]:
        """Return currently open pages in the context."""
        await self.start()
        return list(getattr(self.context, "pages", []))

    async def current_page(self) -> Any:
        """Return the active target page, creating one if needed."""
        await self.start()
        pages = await self.pages()
        # Prefer explicit agent selections. Plain cached values can be stale,
        # so Chromium detection is still used unless the page was selected by an
        # agent action such as select_tab(), new_page(), or goto().
        if self._active_page_explicit and self._active_page in pages:
            return self._active_page
        browser_active_page = await self.detect_browser_active_page(pages)
        if browser_active_page is not None:
            self._active_page = browser_active_page
            self._active_page_explicit = False
            return browser_active_page
        if pages:
            self._active_page = pages[-1]
            return self._active_page
        return await self.new_page()

    async def detect_browser_active_page(self, pages: list[Any] | None = None) -> Any | None:
        """Ask Chromium which page is currently foregrounded."""
        pages = pages if pages is not None else await self.pages()
        focused_page = None
        visible_page = None
        for page in pages:
            try:
                state = await page.evaluate(
                    "() => ({ visibilityState: document.visibilityState, hasFocus: document.hasFocus() })"
                )
            except Exception:
                continue
            if state.get("visibilityState") == "visible":
                visible_page = page
            if state.get("hasFocus"):
                focused_page = page
        return focused_page or visible_page

    async def bring_page_to_front(self, page: Any) -> None:
        """Ask Chromium to foreground a page using Playwright, then CDP if available."""
        await page.bring_to_front()
        try:
            cdp = await self.context.new_cdp_session(page)
            await cdp.send("Page.bringToFront")
            try:
                await cdp.detach()
            except Exception:
                pass
        except Exception:
            pass

    async def select_tab(self, index: int) -> Any:
        """Select an open tab by zero-based index and make that page active."""
        pages = await self.pages()
        if not pages:
            raise BrowserError("No browser tabs are open.")
        if index < 0:
            index = len(pages) + index
        if index < 0 or index >= len(pages):
            raise BrowserError(f"Tab index out of range: {index}. Open tabs: {len(pages)}")
        selected_page = pages[index]
        await self.bring_page_to_front(selected_page)
        # Chromium UI performs the visible switch, but Playwright can report
        # ambiguous visibility/focus states for pages in a headed persistent
        # context. After an explicit selection, keep the selected Playwright Page
        # as the active target for snapshots/actions.
        self._active_page = selected_page
        self._active_page_explicit = True
        return selected_page

    async def tab_info(self) -> list[dict[str, Any]]:
        """Return compact information about open tabs."""
        pages = await self.pages()
        if self._active_page_explicit and self._active_page in pages:
            active = self._active_page
        else:
            browser_active = await self.detect_browser_active_page(pages) if pages else None
            if browser_active is not None:
                self._active_page = browser_active
                self._active_page_explicit = False
            fallback_active = self._active_page if self._active_page in pages else None
            active = browser_active or fallback_active
            if active is None and pages:
                active = await self.current_page()
        info = []
        for index, page in enumerate(pages):
            title = ""
            url = getattr(page, "url", "") or ""
            try:
                title = await page.title()
            except Exception:
                title = ""
            info.append({"index": index, "active": page is active, "title": title, "url": url})
        return info

    async def previous_page(self, *, page: Any | None = None, wait_until: str = "domcontentloaded", timeout: float = 30_000) -> Any:
        """Navigate the active page back in history and return it."""
        target = page or await self.current_page()
        await target.go_back(wait_until=wait_until, timeout=timeout)
        self._active_page = target
        self._active_page_explicit = True
        return target

    async def goto(
        self,
        url: str,
        *,
        page: Any | None = None,
        wait_until: str = "domcontentloaded",
        timeout: float = 30_000,
    ) -> Any:
        """Navigate a page to ``url`` and return that page."""
        target = page or await self.current_page()
        await target.goto(url, wait_until=wait_until, timeout=timeout)
        self._active_page = target
        self._active_page_explicit = True
        return target

    async def content(self, url: str | None = None, **goto_kwargs: Any) -> str:
        """Return HTML content from the current page, optionally after navigation."""
        page = await self.current_page()
        if url:
            await self.goto(url, page=page, **goto_kwargs)
        return await page.content()

    async def text_content(self, url: str | None = None, selector: str = "body", **goto_kwargs: Any) -> str:
        """Return rendered text content for a selector, optionally after navigation."""
        page = await self.current_page()
        if url:
            await self.goto(url, page=page, **goto_kwargs)
        text = await page.locator(selector).inner_text(timeout=goto_kwargs.get("timeout", 30_000))
        return text

    async def screenshot(
        self,
        path: str,
        url: str | None = None,
        *,
        full_page: bool = True,
        **goto_kwargs: Any,
    ) -> str:
        """Save a screenshot and return its absolute path."""
        page = await self.current_page()
        if url:
            await self.goto(url, page=page, **goto_kwargs)
        absolute_path = os.path.abspath(os.path.expanduser(path))
        parent = os.path.dirname(absolute_path)
        if parent:
            os.makedirs(parent, exist_ok=True)
        await page.screenshot(path=absolute_path, full_page=full_page)
        return absolute_path

    async def snapshot(
        self,
        url: str | None = None,
        *,
        max_elements: int = 120,
        max_text_length: int = 140,
        include_json: bool = False,
        **goto_kwargs: Any,
    ) -> str:
        """Return a compact, action-oriented snapshot of the current page.

        Elements in the snapshot are assigned stable IDs for the current DOM
        state. Use those IDs with ``click()``, ``fill()``, ``select()``, etc.
        """
        page = await self.current_page()
        if url:
            await self.goto(url, page=page, **goto_kwargs)
        data = await self.snapshot_data(page=page, max_elements=max_elements, max_text_length=max_text_length)
        return self.format_snapshot(data, include_json=include_json)

    async def snapshot_data(
        self,
        *,
        page: Any | None = None,
        max_elements: int = 120,
        max_text_length: int = 140,
    ) -> dict[str, Any]:
        """Return structured snapshot data for the current page."""
        target = page or await self.current_page()
        return await target.evaluate(
            SNAPSHOT_SCRIPT,
            {
                "idAttr": BROWSER_AGENT_ID_ATTR,
                "maxElements": max_elements,
                "maxTextLength": max_text_length,
            },
        )

    def format_snapshot(self, data: dict[str, Any], *, include_json: bool = False) -> str:
        """Format structured snapshot data for agent-readable navigation."""
        lines = [
            f"Page: {data.get('title') or '(untitled)'}",
            f"URL: {data.get('url') or ''}",
            "",
            "Elements:",
        ]
        elements = data.get("elements") or []
        if not elements:
            lines.append("  (no useful visible elements found)")
        for element in elements:
            lines.append(self._format_snapshot_element(element))
        if data.get("truncated"):
            lines.append("  ... snapshot truncated; narrow the page or increase max_elements")
        if include_json:
            lines.extend(["", "JSON:", json.dumps(data, ensure_ascii=False, indent=2)])
        return "\n".join(lines)

    def _format_snapshot_element(self, element: dict[str, Any]) -> str:
        role = element.get("role") or "element"
        name = element.get("name") or element.get("text") or ""
        parts = [f"[{element.get('id')}]", role]
        if name:
            parts.append(json.dumps(name, ensure_ascii=False))
        details = []
        if element.get("href"):
            details.append(f"href={element['href']}")
        if element.get("placeholder"):
            details.append(f"placeholder={json.dumps(element['placeholder'], ensure_ascii=False)}")
        if element.get("value") and role in {"input", "textarea", "select", "search", "textbox"}:
            details.append(f"value={json.dumps(element['value'], ensure_ascii=False)}")
        if element.get("checked"):
            details.append("checked")
        if element.get("disabled"):
            details.append("disabled")
        suffix = f" ({'; '.join(details)})" if details else ""
        return "  " + " ".join(parts) + suffix

    async def element_locator(self, element_id: str | int, *, page: Any | None = None) -> Any:
        """Return a locator for an element previously exposed by ``snapshot``."""
        if page is None:
            page = await self.current_page()
        selector = f'[{BROWSER_AGENT_ID_ATTR}="{element_id}"]'
        return page.locator(selector)

    async def click(self, element_id: str | int, *, page: Any | None = None, **kwargs: Any) -> None:
        """Click an element ID from the latest snapshot."""
        await (await self.element_locator(element_id, page=page)).click(**kwargs)

    async def fill(self, element_id: str | int, text: str, *, page: Any | None = None, **kwargs: Any) -> None:
        """Fill an input/textarea/contenteditable element ID from the snapshot."""
        await (await self.element_locator(element_id, page=page)).fill(text, **kwargs)

    async def select(self, element_id: str | int, value: str | list[str], *, page: Any | None = None, **kwargs: Any) -> Any:
        """Select option values on a select element ID from the snapshot."""
        return await (await self.element_locator(element_id, page=page)).select_option(value, **kwargs)

    async def press(self, key: str, *, element_id: str | int | None = None, page: Any | None = None, **kwargs: Any) -> None:
        """Press a key globally or on a snapshot element ID."""
        if element_id is not None:
            await (await self.element_locator(element_id, page=page)).press(key, **kwargs)
            return
        target = page or await self.current_page()
        await target.keyboard.press(key, **kwargs)

    async def wait_for_load_state(self, state: str = "domcontentloaded", *, page: Any | None = None, **kwargs: Any) -> None:
        """Wait for the current page load state."""
        target = page or await self.current_page()
        await target.wait_for_load_state(state, **kwargs)


class BrowserController:
    """Synchronous controller keeping one BrowserSession on a dedicated loop."""

    def __init__(self) -> None:
        self._loop: asyncio.AbstractEventLoop | None = None
        self._thread: threading.Thread | None = None
        self._session: BrowserSession | None = None
        self._lock = threading.Lock()

    @property
    def session(self) -> BrowserSession | None:
        return self._session

    @property
    def is_open(self) -> bool:
        return bool(self._session and self._session.is_started)

    def _ensure_loop(self) -> asyncio.AbstractEventLoop:
        with self._lock:
            if self._loop and self._loop.is_running():
                return self._loop
            self._loop = asyncio.new_event_loop()
            self._thread = threading.Thread(target=self._run_loop, name="codex-agent-browser", daemon=True)
            self._thread.start()
            return self._loop

    def _run_loop(self) -> None:
        assert self._loop is not None
        asyncio.set_event_loop(self._loop)
        self._loop.run_forever()

    def run(self, coro):
        loop = self._ensure_loop()
        future = asyncio.run_coroutine_threadsafe(coro, loop)
        return future.result()

    def open(
        self,
        url: str | None = None,
        *,
        headless: bool = False,
        profile_name: str = "default",
        new_tab: bool | None = None,
        wait_until: str = "domcontentloaded",
        timeout: float = 30_000,
    ) -> dict[str, Any]:
        async def _open() -> dict[str, Any]:
            created_session = False
            if self._session is None or not self._session.is_started:
                self._session = BrowserSession(headless=headless, profile_name=profile_name)
                await self._session.start()
                created_session = True

            pages = await self._session.pages()
            should_new_tab = new_tab if new_tab is not None else bool(pages and not created_session)
            page = await self._session.new_page() if should_new_tab or not pages else await self._session.current_page()
            if url:
                await self._session.goto(url, page=page, wait_until=wait_until, timeout=timeout)
            else:
                self._session._active_page = page
            return await self._status_async()

        return self.run(_open())

    def close(self) -> str:
        async def _close() -> str:
            if self._session is None or not self._session.is_started:
                return "Browser is already closed."
            await self._session.stop()
            self._session = None
            return "Browser closed."

        return self.run(_close())

    async def _status_async(self) -> dict[str, Any]:
        if self._session is None or not self._session.is_started:
            return {"open": False, "tabs": []}
        return {"open": True, "profile_dir": self._session.user_data_dir, "tabs": await self._session.tab_info()}

    def status(self) -> dict[str, Any]:
        return self.run(self._status_async())

    def require_session(self) -> BrowserSession:
        if self._session is None or not self._session.is_started:
            raise BrowserError("Browser is not open. Call browser_open first.")
        return self._session

    def snapshot(self, **kwargs: Any) -> str:
        session = self.require_session()
        return self.run(session.snapshot(**kwargs))

    def screenshot(self, path: str, **kwargs: Any) -> str:
        session = self.require_session()
        return self.run(session.screenshot(path, **kwargs))

    def select_tab(self, index: int) -> dict[str, Any]:
        async def _select() -> dict[str, Any]:
            session = self.require_session()
            await session.select_tab(index)
            return await session.tab_info()

        return {"open": True, "tabs": self.run(_select())}

    def previous_page(self, **kwargs: Any) -> str:
        async def _previous() -> str:
            session = self.require_session()
            await session.previous_page(**kwargs)
            return "Navigated to the previous browser page."

        return self.run(_previous())

    def goto(self, url: str, **kwargs: Any) -> str:
        async def _goto() -> str:
            session = self.require_session()
            await session.goto(url, **kwargs)
            return f"Navigated browser tab to {url}."

        return self.run(_goto())

    def click(self, element_id: str | int, **kwargs: Any) -> str:
        async def _click() -> str:
            session = self.require_session()
            await session.click(element_id, **kwargs)
            return f"Clicked browser element {element_id}."

        return self.run(_click())

    def fill(self, element_id: str | int, text: str, **kwargs: Any) -> str:
        async def _fill() -> str:
            session = self.require_session()
            await session.fill(element_id, text, **kwargs)
            return f"Filled browser element {element_id}."

        return self.run(_fill())

    def select(self, element_id: str | int, value: str | list[str], **kwargs: Any) -> str:
        async def _select() -> str:
            session = self.require_session()
            await session.select(element_id, value, **kwargs)
            return f"Selected browser element {element_id}."

        return self.run(_select())

    def press(self, key: str, element_id: str | int | None = None, **kwargs: Any) -> str:
        async def _press() -> str:
            session = self.require_session()
            await session.press(key, element_id=element_id, **kwargs)
            if element_id is None:
                return f"Pressed browser key {key}."
            return f"Pressed browser key {key} on element {element_id}."

        return self.run(_press())

    def fetch_rendered_html(self, url: str, *, headless: bool = True, profile_name: str = "default", **goto_kwargs: Any) -> str:
        """Fetch rendered HTML with a temporary browser session."""

        async def _fetch() -> str:
            async with BrowserSession(headless=headless, profile_name=profile_name) as browser:
                return await browser.content(url, **goto_kwargs)

        return run_browser_coro(_fetch())

    def capture_page_screenshot(
        self,
        url: str,
        path: str,
        *,
        headless: bool = True,
        profile_name: str = "default",
        full_page: bool = True,
        **goto_kwargs: Any,
    ) -> str:
        """Capture a rendered page screenshot with a temporary browser session."""

        async def _capture() -> str:
            async with BrowserSession(headless=headless, profile_name=profile_name) as browser:
                return await browser.screenshot(path, url=url, full_page=full_page, **goto_kwargs)

        return run_browser_coro(_capture())


_browser_controller = BrowserController()


def get_browser_controller() -> BrowserController:
    return _browser_controller


def run_browser_coro(coro):
    """Run a browser coroutine from synchronous code.

    This helper is intended for sync entry points. In an already-running event
    loop, callers should use the async API directly.
    """
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)
    raise BrowserError("Cannot run sync browser helper inside an active event loop; use the async API.")


