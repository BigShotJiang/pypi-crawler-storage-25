from modict import modict

from codex_backend_sdk import CodexClient
from .tool import Tool


class Worker:
    """One-shot backend worker base class.

    Subclasses specialize behavior by overriding class fields such as
    ``system_prompt``, ``tools``, and model defaults.
    """

    system_prompt = "Complete the requested task directly and return only the useful result."
    model = "gpt-5.4"
    reasoning_effort = "medium"
    verbosity = "medium"
    tools = []
    tool_choice = None
    response_text = None
    resolve_tools = True
    name = "worker"
    max_retries = 3

    def __init__(
        self,
        *,
        client=None,
        system_prompt=None,
        model=None,
        reasoning_effort=None,
        verbosity=None,
        tools=None,
        tool_choice=None,
        response_text=None,
        resolve_tools=None,
        name=None,
        max_retries=None,
    ):
        self.system_prompt = system_prompt if system_prompt is not None else self.system_prompt
        self.model = model if model is not None else self.model
        self.reasoning_effort = reasoning_effort if reasoning_effort is not None else self.reasoning_effort
        self.verbosity = verbosity if verbosity is not None else self.verbosity
        self.tools = list(tools if tools is not None else self.tools)
        self.tool_choice = tool_choice if tool_choice is not None else self.tool_choice
        self.response_text = (
            response_text if response_text is not None else self.response_text
        )
        self.resolve_tools = resolve_tools if resolve_tools is not None else self.resolve_tools
        self.name = name if name is not None else self.name
        self.max_retries = max_retries if max_retries is not None else self.max_retries
        self._client = client

    @property
    def client(self):
        if self._client is None:
            self._client = CodexClient(model=self.model).authenticate()
        return self._client

    def get_tools(self):
        return [
            tool.to_response_tool() if hasattr(tool, "to_response_tool") else dict(tool)
            for tool in self.tools
        ]

    def get_local_tools(self):
        return {
            tool.name: tool
            for tool in self.tools
            if isinstance(tool, Tool)
        }

    def run(
        self,
        prompt,
        *,
        input=None,
        tools=None,
        model=None,
        reasoning_effort=None,
        verbosity=None,
        tool_choice=None,
        response_text=None,
        resolve_tools=None,
    ):
        text = ""
        reasoning = ""
        tool_calls = []
        tool_results = []
        output_items = []

        try:
            resolved_tools = tools if tools is not None else self.get_tools()
            resolved_tool_choice = tool_choice or self.tool_choice or ("auto" if resolved_tools else "none")
            resolved_text = (
                response_text if response_text is not None else self.response_text
            )
            resolved_verbosity = verbosity or self.verbosity

            response_params = {
                "input": [*(input or []), {"role": "user", "content": prompt}],
                "instructions": self.system_prompt,
                "model": model or self.model,
                "tools": resolved_tools,
                "tool_choice": resolved_tool_choice,
                "parallel_tool_calls": False,
            }
            resolved_reasoning = reasoning_effort or self.reasoning_effort
            if resolved_reasoning:
                response_params["reasoning"] = {
                    "effort": resolved_reasoning,
                    "summary": "auto",
                }
                response_params["include"] = ["reasoning.encrypted_content"]
            if resolved_text is not None:
                response_params["text"] = resolved_text
            elif resolved_verbosity:
                response_params["text"] = {"verbosity": resolved_verbosity}

            events = self.client.responses.create(**response_params, stream=True)
            self.params = response_params
            for event in events:
                event_type = getattr(event, "type", "")
                if event_type in {"response.output_text.delta", "response.content_part.delta"}:
                    text += self._event_delta_text(event)
                elif event_type == "response.reasoning_summary_part.delta":
                    reasoning += self._event_delta_text(event)
                elif event_type == "response.output_item.done":
                    item = modict(getattr(event, "item", None) or {})
                    if item.get("type") == "reasoning":
                        reasoning += self._reasoning_item_text(item)
                        continue
                    if item.get("type") not in {"function_call", "custom_tool_call"}:
                        output_items.append(item)
                        continue
                    tool_calls.append(item)
                    should_resolve = self.resolve_tools if resolve_tools is None else resolve_tools
                    if should_resolve and len(tool_results) == 0:
                        tool = self.get_local_tools().get(item.get("name"))
                        if tool is not None:
                            args = item.get("arguments") or item.get("input") or "{}"
                            if isinstance(args, str):
                                import json

                                args = json.loads(args) if args else {}
                            output = str(tool(**args))
                            tool_results.append(modict(
                                call_id=item.get("call_id", ""),
                                name=item.get("name", ""),
                                output=output,
                            ))
                elif event_type in {"response.failed", "error"}:
                    raise RuntimeError(self._event_error_message(event))
        except Exception:
            raise

        if tool_results:
            tool_output = "\n".join(result.output for result in tool_results)
            text = f"{text}\n{tool_output}".strip() if text else tool_output

        return modict(
            content=text,
            reasoning=reasoning,
            tool_calls=tool_calls,
            tool_results=tool_results,
            output_items=output_items,
        )

    def __call__(self, prompt, **kwargs):
        return self.run(prompt, **kwargs).content

    def abort(self):
        if self._client is not None and hasattr(self._client, "abort"):
            self._client.abort()

    def _event_delta_text(self, event):
        delta = getattr(event, "delta", "")
        if isinstance(delta, dict):
            return delta.get("text", "")
        return delta or ""

    def _reasoning_item_text(self, item):
        parts = []
        for part in item.get("summary") or []:
            if isinstance(part, dict):
                parts.append(part.get("text", ""))
        return "".join(parts) or item.get("encrypted_content", "")

    def _event_error_message(self, event):
        response = getattr(event, "response", None)
        if hasattr(response, "model_dump"):
            response = response.model_dump()
        response = response if isinstance(response, dict) else {}
        error = response.get("error") or getattr(event, "error", None) or {}
        if hasattr(error, "model_dump"):
            error = error.model_dump()
        if isinstance(error, dict):
            return f"[{error.get('code', 'error')}] {error.get('message', 'Response failed')}"
        return str(error)


class SummarizerWorker(Worker):
    name = "summarizer"
    system_prompt = """You are a focused summarization worker.

Return a compact, faithful summary of the supplied content.
Preserve names, decisions, constraints, unresolved questions, and concrete facts.
Remove repetition and conversational filler.
"""


class TurnSummaryWorker(Worker):
    name = "turn_summary"
    model = "gpt-5.4-mini"
    system_prompt = """You are a RAG archive worker.

Summarize one complete conversation turn into exactly one dense, semantically meaningful paragraph.
This will be used to populate a long-term memory store that the AI assistant can retrieve from in future conversations.
Focus on what is worth remembering long term for the AI assistant, not on the incidental details that are only relevant in the moment.
The supplied turn contains only conversational user and assistant messages; bulky tool-result wrappers and other operational context are filtered before archival.
Preserve the user's intent, important facts, constraints, decisions, actions performed, concrete artifacts such as file paths or commands, final outcome, and any unresolved state.
Ignore operational noise, raw payloads, duplicate stream fragments, and incidental logs unless they changed the outcome.
If the turn does not contain anything genuinely useful to remember long term, such as a simple greeting, thanks, acknowledgement, or other exchange with no durable user information, durable decision, artifact, or unresolved state, return an empty string.
Return only the paragraph, with no title, bullets, Markdown, JSON, or commentary.
"""

    def summarize_turn(self, turn, previous_summary=None, **kwargs):
        prompt = "\n\n".join(message.as_string() for message in turn)
        if previous_summary:
            prompt = (
                "Previous turn summary for background only. Do not summarize this previous summary; "
                "use it only to understand the immediate prior context and formulate the new turn summary better.\n"
                f"<previous_turn_summary>\n{previous_summary}\n</previous_turn_summary>\n\n"
                "<turn_to_summarize>\n"
                f"{prompt}\n"
                "</turn_to_summarize>"
            )
        return self.run(prompt, **kwargs).content
