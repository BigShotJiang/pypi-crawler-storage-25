import os
import sys

from modict import modict
from ..client import AgentClient
from ..event import (
    AssistantStepEndEvent,
    AssistantStepStartEvent,
    AssistantTurnEndEvent,
    AssistantTurnErrorEvent,
    AssistantTurnStartEvent,
    CompactionCompletedEvent,
    MessageAddedEvent,
    ResponseContentDeltaEvent,
    ResponseDoneEvent,
    ServerToolCallEvent,
    SlashCommandDoneEvent,
    SlashCommandStartEvent,
    ToolCallDoneEvent,
    ToolCallStartEvent,
)
from .app import AgentTextualApp
from .lifecycle import register_tui
from .state import DisplayDeduper, LiveDeltaBuffer, ReplayDeltaBuffer, TuiAppBridge
from .status_bar import StatusBar
from .transcript import Transcript


TUI_MOUSE_ENV = "CODEX_AGENT_TUI_MOUSE"
TRUE_ENV_VALUES = {"1", "true", "yes", "on"}
FALSE_ENV_VALUES = {"0", "false", "no", "off"}


def tui_mouse_enabled(value=None, default=True):
    value = os.environ.get(TUI_MOUSE_ENV) if value is None else value
    if value is None:
        return default
    normalized = str(value).strip().lower()
    if normalized in TRUE_ENV_VALUES:
        return True
    if normalized in FALSE_ENV_VALUES:
        return False
    return default


class Chat:
    """Textual-based chat UI client for a codex-agent server."""

    def __init__(self, client=None, base_url="http://127.0.0.1:8765"):
        self.client = client or AgentClient(base_url=base_url)
        self.app = None
        self.view = TuiAppBridge(self)
        self.deduper = DisplayDeduper()
        self.transcript = Transcript()
        self._server_connected = False
        self._server_error = ""
        self._replaying_events = False
        self.replay_delta = ReplayDeltaBuffer()
        self.live_delta = LiveDeltaBuffer()

    def attach(self):
        self.client.on(AssistantTurnStartEvent, self._once(self._on_assistant_turn_start))
        self.client.on(AssistantStepStartEvent, self._once(self._on_assistant_step_start))
        self.client.on(AssistantStepEndEvent, self._once(self._on_assistant_step_end))
        self.client.on(AssistantTurnEndEvent, self._once(self._on_assistant_turn_end))
        self.client.on(AssistantTurnErrorEvent, self._once(self._on_assistant_turn_error))
        self.client.on(CompactionCompletedEvent, self._once(self._on_compaction_completed))
        self.client.on(MessageAddedEvent, self._once(self._on_message_added))
        self.client.on(ResponseContentDeltaEvent, self._once(self._on_content_delta))
        self.client.on(ResponseDoneEvent, self._once(self._on_response_done))
        self.client.on(ToolCallStartEvent, self._once(self._on_tool_call_start))
        self.client.on(ToolCallDoneEvent, self._once(self._on_tool_call_done))
        self.client.on(ServerToolCallEvent, self._once(self._on_server_tool_call))
        self.client.on(SlashCommandStartEvent, self._once(self._on_slash_command_start))
        self.client.on(SlashCommandDoneEvent, self._once(self._on_slash_command_done))
        self.client.on("server_connected", self._on_server_connected)
        self.client.on("server_offline", self._on_server_offline)
        self.client.on("server_subscribed", self._on_server_subscribed)
        self.client.on("turn_error", self._on_turn_error)
        self.client.on("client_event_error", self._on_client_event_error)
        return self

    def _on_server_connected(self, event):
        self._mark_server_connected(announce=True)
        self.view.refresh_status()

    def _mark_server_connected(self, announce=False):
        was_offline = not self._server_connected
        self._server_connected = True
        self._server_error = ""
        if announce and was_offline:
            self.view.write_info("server connected")

    def _on_server_offline(self, event):
        was_connected = self._server_connected
        self._server_connected = False
        self._server_error = event.get("error", "")
        if was_connected:
            self.view.write_info("server offline")
        self.view.refresh_status()

    def _on_server_subscribed(self, event):
        self._mark_server_connected(announce=event.get("after_sequence") is not None)
        register_tui(base_url=self.client.base_url)
        self.replay_startup_events(event.get("replay_before_sequence"), session_id=event.get("session_id"))

    def replay_startup_events(self, before_sequence=None, session_id=None):
        try:
            replay = self.client.replay_events(before_sequence=before_sequence, session_id=session_id)
        except Exception as exc:
            self.view.write_error(f"failed to replay session events: {exc}")
            return
        self._replaying_events = True
        self.replay_delta.clear()
        self.view.begin_transcript_batch()
        try:
            for event in self.coalesced_replay_events(replay.get("events") or []):
                self.client.remember_event_sequence(event)
                self.client.emit_local(event)
        finally:
            self._flush_replay_delta_buffer()
            self._replaying_events = False
            self.view.end_transcript_batch()
            self.view.refresh_status()

    def coalesced_replay_events(self, events):
        pending_delta = ""
        pending_event = None

        def flush_pending():
            nonlocal pending_delta, pending_event
            if pending_event is None:
                return None
            event = pending_event.copy()
            event.delta = pending_delta
            pending_delta = ""
            pending_event = None
            return event

        for event in events:
            event = modict(event)
            if event.get("type") == "response_content_delta_event":
                pending_delta += str(event.get("delta") or "")
                pending_event = event
                continue
            flushed = flush_pending()
            if flushed is not None:
                yield flushed
            yield event
        flushed = flush_pending()
        if flushed is not None:
            yield flushed

    def _on_compaction_completed(self, event):
        self._mark_server_connected()
        self.view.refresh_status()

    def run(self):
        mouse_enabled = tui_mouse_enabled()
        mouse_mode_hint = "mouse scroll on · drag chat text then Ctrl+C to copy"
        AgentTextualApp(self, mouse_mode_hint).run(mouse=mouse_enabled)

    def begin_turn_rendering(self):
        self.transcript.begin_agent_turn()
        self.deduper.reset_turn_scope()

    def username(self):
        try:
            return self.client.config.get("username") or "You"
        except Exception:
            return "You"

    def agent_name(self):
        try:
            return self.client.config.get("name") or "Pandora"
        except Exception:
            return "Pandora"

    @property
    def replaying_events(self):
        return self._replaying_events

    def status_renderable(self):
        if not self._server_connected:
            suffix = f" · {self._server_error}" if self._server_error else ""
            return f"server offline · reconnecting{suffix}"
        try:
            return StatusBar.render(self.client.get_status())
        except Exception as exc:
            self._server_error = str(exc)
            return f"status unavailable · {exc}"

    def resync_from_status(self, status=None):
        try:
            status = status or self.client.get_status()
        except Exception:
            return False
        event_stream = status.get("event_stream") or {}
        server_sequence = event_stream.get("last_event_sequence")
        if server_sequence is None:
            return False
        try:
            server_sequence = int(server_sequence)
        except (TypeError, ValueError):
            return False
        local_sequence = self.client._last_event_sequence
        if local_sequence is not None and int(local_sequence) >= server_sequence:
            return False
        self.replay_startup_events(server_sequence, session_id=status.get("session_id"))
        return True

    def _flush_live_delta(self):
        delta = self.live_delta.pop()
        if delta:
            self.view.write_agent_delta(delta)
        return delta

    def _request_live_delta_flush(self):
        if not self.live_delta.mark_flush_requested():
            return False
        self.view.schedule_agent_delta_flush()
        return True

    def _once(self, handler):
        def wrapped(event):
            if not self.deduper.remember_event(event):
                return
            return handler(event)
        return wrapped

    def _on_message_added(self, event):
        self._mark_server_connected()
        message = event.get("message") or {}
        if message.get("type") == "user_message":
            self.view.write_user(str(message.get("content") or ""))
        self.view.refresh_status()

    def _on_assistant_turn_start(self, event):
        self._mark_server_connected()
        self.view.write_agent_start(self.agent_name())
        self.view.refresh_status()

    def _on_assistant_step_start(self, event):
        self._mark_server_connected()
        self._flush_live_delta()
        self.transcript.agent_buffer = ""
        self.view.start_agent_step()

    def _on_assistant_step_end(self, event):
        self._mark_server_connected()
        self._flush_replay_delta_buffer()
        self._flush_live_delta()
        self.view.end_agent_step()
        self.view.refresh_status()

    def _on_assistant_turn_end(self, event):
        self._mark_server_connected()
        self._flush_replay_delta_buffer()
        result = event.get("result")
        self._flush_live_delta()
        if result not in (None, True, False):
            self.view.write_info(result)
        self.view.refresh_status()

    def _on_assistant_turn_error(self, event):
        self._mark_server_connected()
        self._flush_live_delta()
        self.view.write_error(event.get("error", "turn error"))
        self.view.refresh_status()

    def _on_content_delta(self, event):
        self._mark_server_connected()
        delta = event.get("delta", "")
        if self._replaying_events:
            self.replay_delta.push(delta)
            return
        if self.live_delta.push(delta):
            self._request_live_delta_flush()

    def _on_response_done(self, event):
        self._mark_server_connected()
        self._flush_replay_delta_buffer()
        self._flush_live_delta()

    def _flush_replay_delta_buffer(self):
        delta = self.replay_delta.pop()
        if delta:
            self.view.write_agent_delta(delta)

    def _on_tool_call_start(self, event):
        self._mark_server_connected()
        self._flush_live_delta()
        tool_call = event.get("tool_call") or {}
        name = tool_call.get("name") or "unknown"
        call_id = tool_call.get("call_id") or name
        self._print_tool_call(name, call_id, status="running")

    def _on_tool_call_done(self, event):
        self._mark_server_connected()
        self._flush_live_delta()
        tool_call = event.get("tool_call") or {}
        name = tool_call.get("name") or "unknown"
        call_id = tool_call.get("call_id") or name
        self._print_tool_call(name, call_id, status="done")

    def _on_server_tool_call(self, event):
        self._mark_server_connected()
        self._flush_live_delta()
        name = event.get("name") or "unknown"
        call_id = event.get("call_id") or name
        status = event.get("status") or ""
        self._print_tool_call(name, call_id, status=status)

    def _print_tool_call(self, name, call_id, status=None):
        status = status or "running"
        if not self.deduper.remember_tool(call_id, status):
            return
        self.view.write_tool(name, call_id, status)

    def _on_slash_command_start(self, event):
        self._mark_server_connected()
        self._flush_live_delta()
        self._print_slash_command(event.get("name") or "", event.get("args") or "", status="running")

    def _on_slash_command_done(self, event):
        self._mark_server_connected()
        self._flush_live_delta()
        status = event.get("status") or ("failed" if event.get("error") else "done")
        self._print_slash_command(event.get("name") or "", event.get("args") or "", status=status)
        result = "" if event.get("result") is None else str(event.get("result"))
        if result:
            self.view.write_agent_delta(result)
        if event.get("error"):
            self.view.write_error(event.get("error"))
        self.view.refresh_status()

    def _print_slash_command(self, name, args="", status=None):
        status = status or "running"
        if not self.deduper.remember_slash_command(name, args, status):
            return
        self.view.write_slash_command(name, args, status)

    def _on_turn_error(self, event):
        self.view.write_error(event.get("error", "turn error"))
        self.view.refresh_status()

    def _on_client_event_error(self, event):
        message = event.get("detail") or event.get("error", "event stream error")
        if event.get("status_code") == 409:
            print(f"warning: {message}", file=sys.stderr)
            if self.app is not None:
                self.view.exit()
            return
        if event.get("source") == "event_stream":
            was_connected = self._server_connected
            self._server_connected = False
            self._server_error = message
            if was_connected:
                self.view.write_info("server offline")
            self.view.refresh_status()
            return
        self.view.write_error(message)
