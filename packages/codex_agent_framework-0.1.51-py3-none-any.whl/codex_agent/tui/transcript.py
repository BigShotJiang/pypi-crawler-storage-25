from modict import modict
from rich.text import Text

from .log import SelectableRichLog


class TranscriptEntry(modict):
    _config = modict.config(extra="forbid", require_all="never")

    kind: str
    text: str = ""
    name: str = ""
    style: str = ""
    call_id: str = ""
    status: str = ""
    args: str = ""


class Transcript:
    def __init__(self, *, visible_entries=240, load_chunk_entries=160, max_chars=80_000, max_lines=1_600):
        self.entries = []
        self.last_role = None
        self.visible_entries = visible_entries
        self.default_visible_entries = visible_entries
        self.load_chunk_entries = load_chunk_entries
        self.max_chars = max_chars
        self.max_lines = max_lines
        self.loading_older = False
        self.agent_buffer = ""
        self.step_had_content = False

    def clear(self):
        self.entries.clear()
        self.last_role = None
        self.reset_visible()

    def reset_visible(self):
        self.visible_entries = self.default_visible_entries

    def visible(self):
        count = max(0, int(self.visible_entries or 0))
        if count <= 0 or len(self.entries) <= count:
            return list(self.entries)
        return self.entries[-count:]

    def hidden_count(self):
        return max(0, len(self.entries) - max(0, int(self.visible_entries or 0)))

    def has_hidden(self):
        return self.hidden_count() > 0

    def load_older(self):
        before = self.hidden_count()
        if before <= 0:
            return False
        self.visible_entries = min(
            len(self.entries),
            max(0, int(self.visible_entries or 0)) + self.load_chunk_entries,
        )
        return self.hidden_count() != before

    def display_text(self, text, *, style):
        text = str(text or "")
        visible_text = text
        omitted_chars = 0

        max_chars = max(0, int(self.max_chars or 0))
        if max_chars and len(visible_text) > max_chars:
            omitted_chars += len(visible_text) - max_chars
            visible_text = visible_text[-max_chars:]

        max_lines = max(0, int(self.max_lines or 0))
        if max_lines:
            lines = visible_text.splitlines(keepends=True)
            if len(lines) > max_lines:
                omitted_chars += sum(len(line) for line in lines[:-max_lines])
                visible_text = "".join(lines[-max_lines:])

        if omitted_chars <= 0:
            return Text(visible_text, style=style)

        return (
            Text(f"... {omitted_chars} earlier output chars hidden in UI window\n", style="italic #6e7681")
            + Text(visible_text, style=style)
        )

    def text_is_windowed(self, text):
        text = str(text or "")
        max_chars = max(0, int(self.max_chars or 0))
        if max_chars and len(text) > max_chars:
            return True
        max_lines = max(0, int(self.max_lines or 0))
        if max_lines and text.count("\n") + (1 if text else 0) > max_lines:
            return True
        return False

    def append_user(self, prompt, username):
        self.agent_buffer = ""
        self.entries.append(TranscriptEntry(kind="speaker", name=username, style="#88b38a"))
        self.entries.append(TranscriptEntry(kind="user", text=str(prompt)))
        self.entries.append(TranscriptEntry(kind="user_end"))
        self.last_role = "user"

    def ensure_agent(self, name):
        if self.last_role == "assistant":
            return False
        self.entries.append(TranscriptEntry(kind="speaker", name=name, style="#789fbe"))
        self.last_role = "assistant"
        return True

    def append_tool(self, name, call_id=None, status=None):
        self.entries.append(TranscriptEntry(kind="tool", name=str(name or ""), call_id=str(call_id or ""), status=str(status or "")))
        self.step_had_content = True

    def append_slash_command(self, name, args="", status=None):
        self.entries.append(TranscriptEntry(kind="slash_command", name=str(name or ""), args=str(args or ""), status=str(status or "")))
        self.step_had_content = True

    def append_info(self, text):
        self.entries.append(TranscriptEntry(kind="info", text=str(text)))

    def append_error(self, text):
        self.entries.append(TranscriptEntry(kind="error", text=str(text)))

    def begin_agent_turn(self):
        self.agent_buffer = ""
        self.step_had_content = False

    def begin_step(self):
        self.step_had_content = False

    def apply_agent_delta(self, delta):
        self.agent_buffer += str(delta)
        if self.entries and self.entries[-1].kind == "agent":
            self.entries[-1].text = self.agent_buffer
        else:
            self.entries.append(TranscriptEntry(kind="agent", text=self.agent_buffer))

    def end_step(self):
        had_content = bool(self.agent_buffer or self.step_had_content)
        if self.entries and self.entries[-1].kind == "agent":
            if self.agent_buffer:
                self.entries[-1].text = self.agent_buffer
            else:
                self.entries.pop()
        if had_content and (not self.entries or self.entries[-1].kind != "step_end"):
            self.entries.append(TranscriptEntry(kind="step_end"))


class TranscriptRenderer:
    def __init__(self, chat, app):
        self.chat = chat
        self.app = app
        self.suspended = False
        self.pending = False
        self.last_agent_entry_index = None
        self.last_agent_content_start = None

    @property
    def log(self):
        return self.app.query_one("#conversation", SelectableRichLog)

    def log_width(self):
        return max(32, self.log.text_width())

    def speaker_rule(self, name, style):
        label = f" {name} "
        available = max(2, self.log_width() - len(label))
        left = available // 2
        right = available - left
        return Text("-" * left + label + "-" * right, style=style)

    def qed_marker(self, style="#6f98bd"):
        return Text(" " * max(0, self.log_width() - 1) + "*", style=style)

    def at_end(self, log=None):
        log = log or self.log
        try:
            return bool(log.is_vertical_scroll_end) or log.scroll_y >= log.max_scroll_y - 1
        except Exception:
            return True

    def render(self, *, keep_scroll=False):
        if self.suspended:
            self.pending = True
            return
        log = self.log
        was_at_end = self.at_end(log)
        previous_scroll_y = log.scroll_y
        self.last_agent_entry_index = None
        self.last_agent_content_start = None
        log.begin_content_update()
        try:
            log.clear()
            hidden = self.chat.transcript.hidden_count()
            if hidden:
                log.write(Text(f"... {hidden} older transcript entries hidden - scroll to top to load more", style="italic #6e7681"))
                log.write("")
            hidden_entries = self.chat.transcript.hidden_count()
            for offset, entry in enumerate(self.chat.transcript.visible()):
                self.write_entry(log, hidden_entries + offset, entry)
        finally:
            log.end_content_update()
        if keep_scroll or not was_at_end:
            log.call_after_refresh(lambda: log.scroll_to_synced(y=previous_scroll_y))
        else:
            log.call_after_refresh(log.scroll_end_synced)

    def write_entry(self, log, entry_index, entry):
        if entry.kind == "speaker":
            log.write(self.speaker_rule(entry.name, entry.style))
            log.write("")
        elif entry.kind == "user":
            log.write(self.chat.transcript.display_text(entry.text, style="#aeb0aa"))
        elif entry.kind == "agent":
            self.last_agent_entry_index = entry_index
            self.last_agent_content_start = len(log._content)
            log.write(self.chat.transcript.display_text(entry.text, style="#aeb0aa"))
        elif entry.kind == "tool":
            log.write(self.tool_call_line(entry.name, call_id=entry.call_id, status=entry.status))
        elif entry.kind == "slash_command":
            log.write(self.slash_command_line(entry.name, args=entry.args, status=entry.status))
        elif entry.kind == "step_end":
            log.write(self.qed_marker())
        elif entry.kind == "user_end":
            log.write(self.qed_marker("#88b38a"))
        elif entry.kind == "info":
            log.write(Text("info > ", style="bold #7d8590") + Text(str(entry.text), style="#8b949e"))
        elif entry.kind == "error":
            log.write(Text("error > ", style="bold #ff7b72") + Text(str(entry.text), style="#ff7b72"))

    def begin_batch(self):
        self.suspended = True
        self.pending = False

    def end_batch(self):
        self.suspended = False
        if self.pending:
            self.pending = False
            self.render()

    def load_older(self):
        if self.chat.transcript.loading_older:
            return
        self.chat.transcript.loading_older = True
        try:
            if self.chat.transcript.load_older():
                self.render(keep_scroll=True)
        finally:
            self.chat.transcript.loading_older = False

    def update_last_agent(self, delta=None, previous_text=None):
        if self.suspended:
            self.pending = True
            return False
        if self.last_agent_entry_index is None:
            return False
        if not self.chat.transcript.entries or self.chat.transcript.entries[-1].kind != "agent":
            return False
        if self.last_agent_entry_index != len(self.chat.transcript.entries) - 1:
            return False
        if self.chat.transcript.has_hidden():
            return False
        if self.last_agent_content_start is None:
            return False
        log = self.log
        was_at_end = self.at_end(log)
        last_text = self.chat.transcript.entries[-1].text
        if (
            delta is not None
            and previous_text is not None
            and not self.chat.transcript.text_is_windowed(previous_text)
            and not self.chat.transcript.text_is_windowed(last_text)
        ):
            log.append_to_last_line(delta, style="#aeb0aa")
            if was_at_end:
                log.call_after_refresh(log.scroll_end_synced)
            return True
        log._content = log._content[:self.last_agent_content_start] + self.chat.transcript.display_text(last_text, style="#aeb0aa")
        log._invalidate_content_cache()
        log._sync_content_window()
        if was_at_end:
            log.call_after_refresh(log.scroll_end_synced)
        return True

    @classmethod
    def tool_call_line(cls, name, call_id=None, status=None):
        icon, style = cls._status_badge(status)
        text = Text("  ", style="#4b5563")
        text += Text(f"{icon} ", style=style)
        text += Text(name or "tool", style="bold white")
        short_id = cls._short_call_id(call_id)
        if short_id:
            text += Text(f"  #{short_id}", style="#6e7681")
        return text

    @classmethod
    def slash_command_line(cls, name, args="", status=None):
        icon, style = cls._status_badge(status)
        command = f"/{name}" if name else "/"
        text = Text("  ", style="#4b5563")
        text += Text(f"{icon} ", style=style)
        text += Text(command, style="bold white")
        if args:
            text += Text(f" {args}", style="#8b949e")
        return text

    @staticmethod
    def _status_badge(status):
        status = _normalized_status(status)
        if status == "done":
            return "✓", "bold #3fb950"
        if status == "failed":
            return "✕", "bold #ff7b72"
        return "→", "bold #58a6ff"

    @staticmethod
    def _short_call_id(call_id, *, max_length=16):
        if not call_id:
            return ""
        call_id = str(call_id)
        if len(call_id) <= max_length:
            return call_id
        keep = max(4, max_length - 2)
        head = max(4, keep // 2)
        tail = max(4, keep - head)
        return f"{call_id[:head]}…{call_id[-tail:]}"


def _normalized_status(status):
    if status in {"done", "completed", "success"}:
        return "done"
    if status in {"failed", "failure", "error"}:
        return "failed"
    if status in {None, "", "running"}:
        return "running"
    return str(status)
