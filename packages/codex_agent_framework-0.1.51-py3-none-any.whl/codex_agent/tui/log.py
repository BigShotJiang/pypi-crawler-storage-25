from bisect import bisect_left, bisect_right

from rich.text import Text
from textual.app import ComposeResult
from textual.containers import VerticalScroll
from textual.strip import Strip
from textual.widgets import Static


class SelectableRichLog(VerticalScroll):
    """Scrollable rich text area backed by Static so Textual selection works."""

    ALLOW_SELECT = True
    DEFAULT_WINDOW_OVERSCAN_LINES = 80

    def __init__(self, *args, on_scroll_top=None, on_resize=None, right_padding=0, **kwargs):
        for rich_log_arg in ["max_lines", "min_width", "wrap", "highlight", "markup", "auto_scroll"]:
            kwargs.pop(rich_log_arg, None)
        super().__init__(*args, **kwargs)
        self.on_scroll_top = on_scroll_top
        self.on_resize_callback = on_resize
        self.right_padding = max(0, int(right_padding or 0))
        self._content = Text()
        self._content_lines = None
        self._content_line_metrics = None
        self._window_overscan_lines = self.DEFAULT_WINDOW_OVERSCAN_LINES
        self._suspend_content_sync = False
        self._content_sync_pending = False

    def compose(self) -> ComposeResult:
        yield WindowedStatic(self._content, id="conversation-content", markup=False)

    @property
    def content_widget(self):
        return self.query_one("#conversation-content", Static)

    def clear(self):
        self._content = Text()
        self._invalidate_content_cache()
        if self.is_attached:
            self._sync_content_window()
        return self

    def write(self, content="", *args, **kwargs):
        if len(self._content):
            self._content.append("\n")
        if isinstance(content, Text):
            self._content.append_text(content.copy())
        else:
            self._content.append(str(content))
        self._invalidate_content_cache()
        if self.is_attached:
            self._sync_content_window()
        return self

    def append_to_last_line(self, content="", *, style=None):
        text = content.copy() if isinstance(content, Text) else Text(str(content), style=style)
        changed_index = self._append_cached_content_lines(text)
        self._content.append_text(text)
        if changed_index is None:
            self._invalidate_content_cache()
        else:
            self._refresh_content_line_metrics_from(changed_index)
        if self.is_attached:
            self._sync_content_window()
        return self

    def begin_content_update(self):
        self._suspend_content_sync = True
        self._content_sync_pending = False

    def end_content_update(self):
        self._suspend_content_sync = False
        if self._content_sync_pending:
            self._content_sync_pending = False
            self._sync_content_window()

    def invalidate_layout(self):
        self._content_line_metrics = None
        if self.is_attached:
            self._sync_content_window()

    def on_resize(self):
        self.invalidate_layout()
        if self.on_resize_callback is not None:
            self.on_resize_callback()

    def scroll_to_synced(self, *, y, animate=False):
        self.scroll_to(y=y, animate=animate, immediate=True)
        self._sync_content_window(layout=False)

    def scroll_end_synced(self, *, animate=False):
        self.scroll_end(animate=animate, immediate=True)
        self._sync_content_window(layout=False)

    def watch_scroll_y(self, old_value, new_value):
        super().watch_scroll_y(old_value, new_value)
        self._sync_content_window(layout=False)
        if new_value <= 0 and self.on_scroll_top is not None:
            self.on_scroll_top()

    def _invalidate_content_cache(self):
        self._content_lines = None
        self._content_line_metrics = None

    def _logical_lines(self):
        if self._content_lines is None:
            self._content_lines = [] if not len(self._content) else list(self._content.split("\n", allow_blank=True))
        return self._content_lines

    def _sync_content_window(self, *, layout=True):
        if self._suspend_content_sync:
            self._content_sync_pending = True
            return
        if not self.is_attached:
            return
        if self.right_padding:
            self.content_widget.styles.width = self.text_width()
        lines = self._logical_lines()
        starts, _, visual_line_count = self._line_metrics(lines)
        start, end, visible_start, visible_end = self._content_window_bounds(starts, visual_line_count)
        window = Text("\n").join(lines[start:end]) if start < end else Text()
        self.content_widget.set_window(
            starts[start] if start < len(starts) else 0,
            window,
            visual_line_count,
            visible_start,
            visible_end - visible_start,
            layout=layout,
        )

    def _line_metrics(self, lines):
        width = self._content_width()
        if self._content_line_metrics is not None and self._content_line_metrics[0] == width:
            return self._content_line_metrics[1:]
        starts = []
        heights = []
        total = 0
        for line in lines:
            starts.append(total)
            height = max(1, (max(0, line.cell_len) + width - 1) // width)
            heights.append(height)
            total += height
        self._content_line_metrics = (width, starts, heights, total)
        return starts, heights, total

    def _refresh_content_line_metrics_from(self, start_index):
        if self._content_line_metrics is None or self._content_lines is None:
            return
        width, starts, heights, _ = self._content_line_metrics
        if width != self._content_width():
            self._content_line_metrics = None
            return
        start_index = max(0, min(int(start_index or 0), len(self._content_lines)))
        total = starts[start_index] if start_index < len(starts) else sum(heights[:start_index])
        starts = starts[:start_index]
        heights = heights[:start_index]
        for line in self._content_lines[start_index:]:
            starts.append(total)
            height = max(1, (max(0, line.cell_len) + width - 1) // width)
            heights.append(height)
            total += height
        self._content_line_metrics = (width, starts, heights, total)

    def _append_cached_content_lines(self, content):
        if self._content_lines is None:
            return None
        lines = list(content.split("\n", allow_blank=True)) if len(content) else [Text()]
        if not self._content_lines:
            self._content_lines = [line.copy() for line in lines]
            return 0
        changed_index = len(self._content_lines) - 1
        self._content_lines[-1].append_text(lines[0].copy())
        self._content_lines.extend(line.copy() for line in lines[1:])
        return changed_index

    def _content_width(self):
        return self.text_width()

    def text_width(self):
        if self.right_padding:
            return max(1, int(self.size.width or 80) - self.right_padding)
        try:
            width = self.content_widget.size.width
        except Exception:
            width = 0
        return max(1, int(width or self.size.width or 80))

    def _content_window_bounds(self, line_starts, visual_line_count):
        if visual_line_count <= 0:
            return 0, 0, 0, 0
        overscan = max(0, int(self._window_overscan_lines or 0))
        height = max(1, int(self.size.height or 1))
        scroll_y = max(0, int(self.scroll_y or 0))
        visual_start = max(0, scroll_y - overscan)
        visual_end = min(visual_line_count, scroll_y + height + overscan)
        start = max(0, bisect_right(line_starts, visual_start) - 1)
        end = bisect_left(line_starts, visual_end)
        if start == end and start < len(line_starts):
            end += 1
        return start, max(start, end), visual_start, max(visual_start, visual_end)


class WindowedStatic(Static):
    """Static content with a large virtual height and a small rendered line window."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._content_start_line = 0
        self._window_start_line = 0
        self._window_line_count = 0

    def set_window(self, content_start_line, content, total_lines, window_start_line=None, window_line_count=None, *, layout=True):
        self._content_start_line = max(0, int(content_start_line or 0))
        self._window_start_line = max(0, int(window_start_line if window_start_line is not None else content_start_line or 0))
        if window_line_count is None:
            window_line_count = len(content.split("\n", allow_blank=True)) if len(content) else 0
        self._window_line_count = max(0, int(window_line_count or 0))
        self.styles.height = max(1, int(total_lines or 0))
        self.update(content, layout=layout)

    def render_line(self, y):
        if y < self._window_start_line or y >= self._window_start_line + self._window_line_count:
            return Strip.blank(self.size.width, self.visual_style.rich_style)
        return super().render_line(y - self._content_start_line)
