"""Textual TUI client package."""

from .chat import Chat
from .lifecycle import (
    clear_tui,
    current_tui,
    install_tui_cleanup_handlers,
    open_tui_terminal,
    register_tui,
    terminal_command_candidates,
    terminal_process_kwargs,
    terminate_tui,
)

__all__ = [
    "Chat",
    "clear_tui",
    "current_tui",
    "install_tui_cleanup_handlers",
    "open_tui_terminal",
    "register_tui",
    "terminal_command_candidates",
    "terminal_process_kwargs",
    "terminate_tui",
]
