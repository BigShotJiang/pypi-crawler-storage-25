CHAT_CSS = """
Screen {
    background: #000000;
    color: #aeb0aa;
}
Screen > .screen--selection {
    background: #6f98bd;
    color: #000000;
}
#main {
    height: 100%;
    padding: 0 1;
    background: #000000;
}
#conversation {
    height: 1fr;
    padding: 1 1;
    background: #000000;
    scrollbar-background: #000000;
    scrollbar-background-hover: #000000;
    scrollbar-background-active: #000000;
    scrollbar-color: #202020;
    scrollbar-color-hover: #2a2a2a;
    scrollbar-color-active: #343434;
}
#status {
    height: 1;
    color: #8b949e;
    background: #161b22;
    padding: 0 1;
}
#input {
    height: 3;
    margin-top: 0;
    padding: 0 1;
    background: #000000;
    color: #aeb0aa;
    border: blank #000000;
    scrollbar-size-vertical: 1;
    scrollbar-size-horizontal: 0;
    scrollbar-background: #000000;
    scrollbar-background-hover: #000000;
    scrollbar-background-active: #000000;
    scrollbar-color: #202020;
    scrollbar-color-hover: #2a2a2a;
    scrollbar-color-active: #343434;
}
TextArea > .text-area--cursor {
    background: #6f98bd;
    color: #0d1117;
}
Footer {
    background: #000000;
    color: #7d8590;
}
"""
