import atexit
import os
import shlex
import signal
import subprocess
import sys
import threading

from modict import modict

from ..utils import project_python_env, runtime_join, timestamp

TERMINAL_ENV_PREFIXES_TO_DROP = ("LD_", "SNAP")
TERMINAL_ENV_KEYS_TO_DROP = {
    "GI_TYPELIB_PATH",
    "GIO_MODULE_DIR",
    "GTK_DATA_PREFIX",
    "GTK_EXE_PREFIX",
    "GTK_IM_MODULE_FILE",
    "GTK_PATH",
    "PYTHONHOME",
}


def tui_file():
    return runtime_join("tui.json")


def current_tui():
    path = tui_file()
    if not os.path.isfile(path):
        return None
    try:
        data = modict.load(path)
    except Exception:
        return None
    pid = data.get("pid")
    if not pid or not pid_alive(pid):
        clear_tui()
        return None
    return data


def register_tui(pid=None, base_url="http://127.0.0.1:8765"):
    data = modict(
        pid=int(pid or os.getpid()),
        base_url=str(base_url).rstrip("/"),
        timestamp=timestamp(),
    )
    data.dump(tui_file(), indent=2, ensure_ascii=False)
    return data


def install_tui_cleanup_handlers(pid=None):
    pid = int(pid or os.getpid())
    atexit.register(clear_tui, pid=pid)
    if threading.current_thread() is not threading.main_thread():
        return False
    for signum in (signal.SIGTERM, signal.SIGHUP, signal.SIGINT):
        previous_handler = signal.getsignal(signum)

        def handler(received_signum, frame, previous_handler=previous_handler):
            clear_tui(pid=pid)
            if callable(previous_handler):
                previous_handler(received_signum, frame)
            elif previous_handler == signal.SIG_DFL:
                signal.signal(received_signum, signal.SIG_DFL)
                os.kill(os.getpid(), received_signum)

        signal.signal(signum, handler)
    return True


def clear_tui(pid=None):
    data = None
    path = tui_file()
    if os.path.isfile(path):
        try:
            data = modict.load(path)
        except Exception:
            data = None
    if pid is not None and data and int(data.get("pid") or -1) != int(pid):
        return data
    try:
        os.remove(path)
    except FileNotFoundError:
        pass
    return None


def pid_alive(pid):
    try:
        os.kill(int(pid), 0)
    except OSError:
        return False
    return True


def open_tui_terminal(base_url="http://127.0.0.1:8765"):
    env = tui_terminal_env()
    shell_command = tui_shell_command(base_url=base_url, env=env)
    for terminal_command in terminal_command_candidates(shell_command):
        try:
            return subprocess.Popen(
                terminal_command,
                **terminal_process_kwargs(env=env),
            )
        except FileNotFoundError:
            continue
    return None


def tui_terminal_env(env=None):
    env = project_python_env(env)
    env["AGENT_RUNTIME_DIR"] = os.path.expanduser(env.get("AGENT_RUNTIME_DIR") or runtime_join(""))
    env = sanitize_terminal_env(env)
    return env


def sanitize_terminal_env(env):
    env = dict(env)
    for key in list(env):
        if key in TERMINAL_ENV_KEYS_TO_DROP or key.startswith(TERMINAL_ENV_PREFIXES_TO_DROP):
            env.pop(key, None)
    snap_xdg_data_dirs = env.pop("XDG_DATA_DIRS_VSCODE_SNAP_ORIG", None)
    if snap_xdg_data_dirs:
        env["XDG_DATA_DIRS"] = snap_xdg_data_dirs
    return env


def tui_shell_command(base_url="http://127.0.0.1:8765", env=None):
    env = tui_terminal_env(env)
    command = [
        env.get("PYTHON_EXECUTABLE") or env.get("PYTHON") or sys.executable,
        "-m",
        "codex_agent",
        "chat",
        "--url",
        str(base_url).rstrip("/"),
    ]
    assignments = {
        "AGENT_RUNTIME_DIR": env["AGENT_RUNTIME_DIR"],
        "PATH": env["PATH"],
        "PYTHON": env["PYTHON"],
        "PYTHON_EXECUTABLE": env["PYTHON_EXECUTABLE"],
    }
    prefix = " ".join(f"{key}={shlex.quote(str(value))}" for key, value in assignments.items())
    return f"{prefix} exec {shlex.join(command)}"


def terminal_process_kwargs(env=None):
    kwargs = dict(
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        stdin=subprocess.DEVNULL,
    )
    if env is not None:
        kwargs["env"] = env
    if os.name == "posix":
        kwargs["start_new_session"] = True
    elif os.name == "nt":
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    return kwargs


def terminal_command_candidates(shell_command):
    env_terminal = os.environ.get("TERMINAL")
    if env_terminal:
        yield [env_terminal, "-e", "bash", "-lc", shell_command]
    if sys.platform == "darwin":
        yield ["osascript", "-e", f'tell application "Terminal" to do script "{shell_command}"']
        return
    if sys.platform.startswith("win"):
        yield ["wt.exe", "powershell", "-NoExit", "-Command", shell_command]
        yield ["powershell", "-NoExit", "-Command", shell_command]
        yield ["cmd", "/c", "start", "Codex Agent", "cmd", "/k", shell_command]
        return
    yield ["x-terminal-emulator", "-e", "bash", "-lc", shell_command]
    yield ["gnome-terminal", "--", "bash", "-lc", shell_command]
    yield ["konsole", "-e", "bash", "-lc", shell_command]
    yield ["xfce4-terminal", "--command", f"bash -lc {shlex.quote(shell_command)}"]
    yield ["alacritty", "-e", "bash", "-lc", shell_command]
    yield ["kitty", "bash", "-lc", shell_command]


def terminate_tui(pid):
    if os.name == "posix":
        try:
            os.killpg(int(pid), signal.SIGTERM)
            return
        except Exception:
            pass
    if os.name == "nt" and hasattr(signal, "CTRL_BREAK_EVENT"):
        try:
            os.kill(int(pid), signal.CTRL_BREAK_EVENT)
            return
        except Exception:
            pass
    os.kill(int(pid), signal.SIGTERM)
