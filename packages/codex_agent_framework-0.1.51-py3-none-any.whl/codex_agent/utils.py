import os
import shutil
import tiktoken
import re
from datetime import datetime
import random
import string
import json
import regex
import sys
from importlib import import_module
from io import BytesIO
import shlex

SOURCE_ROOT = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
RUNTIME_DIR = os.path.abspath(os.path.expanduser(os.environ.get("AGENT_RUNTIME_DIR", "~/.codex-agent")))
ROOT_PATH = os.path.abspath(os.path.expanduser(os.environ.get("AGENT_ROOT_PATH") or SOURCE_ROOT))


def runtime_join(*args):
    runtime_dir = os.path.abspath(os.path.expanduser(os.fspath(RUNTIME_DIR)))
    return os.path.abspath(os.path.join(runtime_dir, *map(os.fspath, args)))


def atomic_write_json(path, data, *, ensure_ascii=False, indent=2, default=None):
    """Write JSON atomically by replacing the target file with a complete temp file."""
    path = os.fspath(path)
    folder = os.path.dirname(path)
    if folder:
        os.makedirs(folder, exist_ok=True)
    tmp_path = f"{path}.tmp"
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=ensure_ascii, indent=indent, default=default)
    os.replace(tmp_path, path)
    return path


def ensure_runtime_dir():
    if not os.path.isdir(RUNTIME_DIR):
        os.makedirs(RUNTIME_DIR,exist_ok=True)

def load_runtime_env(file=None, override=False):
    file = file or runtime_join(".env")
    file = os.path.expanduser(str(file))
    if not os.path.isfile(file):
        return {}
    loaded = {}
    with open(file, encoding="utf-8") as f:
        for raw_line in f:
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("export "):
                line = line[len("export "):].strip()
            key, separator, value = line.partition("=")
            if not separator:
                continue
            key = key.strip()
            if not key:
                continue
            value = value.strip()
            try:
                parsed = shlex.split(value, comments=True, posix=True)
            except ValueError:
                parsed = [value]
            value = parsed[0] if parsed else ""
            if override or key not in os.environ:
                os.environ[key] = value
                loaded[key] = value
    return loaded

def set_root_path(file=None):
    global ROOT_PATH
    file = file or __file__
    ROOT_PATH = os.path.dirname(os.path.abspath(os.fspath(file)))
    os.environ["AGENT_ROOT_PATH"] = ROOT_PATH


def root_join(*args):
    root = os.path.abspath(os.path.expanduser(os.fspath(ROOT_PATH or SOURCE_ROOT)))
    return os.path.abspath(os.path.join(root, *map(os.fspath, args)))

def project_python_env(env=None, executable=None):
    env = dict(os.environ if env is None else env)
    executable = os.path.abspath(executable or sys.executable)
    python_bin = os.path.dirname(executable)
    path_parts = [
        part for part in env.get("PATH", "").split(os.pathsep)
        if part and os.path.abspath(part) != python_bin
    ]
    env["PATH"] = os.pathsep.join([python_bin, *path_parts])
    env["PYTHON"] = executable
    env["PYTHON_EXECUTABLE"] = executable
    return env

def text_content(file):
    if os.path.isfile(file):
        with open(file,encoding="utf-8") as f:
            return f.read()
    else:
        return None
    
def _number_lines(lines: list[str], start_line: int = 1, total_lines: int | None = None) -> str:
    last_line = (start_line + len(lines) - 1) if total_lines is None else max(total_lines, start_line + len(lines) - 1)
    width = len(str(max(1, last_line)))
    return "\n".join(
        f"{i:0{width}d}|{line}"
        for i, line in enumerate(lines, start=start_line)
    )


def add_line_numbers(text: str, start_line: int = 1, total_lines: int | None = None) -> str:
    return _number_lines(text.splitlines(), start_line=start_line, total_lines=total_lines)


def pattern_line_numbers(text: str, pattern, regex_pattern: bool = True) -> list[int]:
    pattern_text = str(pattern)
    lines = text.splitlines()
    if regex_pattern:
        try:
            compiled_pattern = re.compile(pattern_text)
        except re.error as exc:
            raise ValueError(f"Invalid regex pattern {pattern_text!r}: {exc}") from exc
        return [index for index, line in enumerate(lines, start=1) if compiled_pattern.search(line)]
    return [index for index, line in enumerate(lines, start=1) if pattern_text in line]


def _numbered_snippets_for_matches(text: str, matches: list[int], context_lines: int = 10) -> str:
    lines = text.splitlines()
    total_lines = len(lines)
    if not matches:
        return _number_lines(lines, start_line=1, total_lines=total_lines)

    context_lines = max(0, int(context_lines or 0))
    ranges = []
    for match_line in matches:
        start = max(1, match_line - context_lines)
        end = min(total_lines, match_line + context_lines)
        if ranges and start <= ranges[-1][1] + 1:
            ranges[-1] = (ranges[-1][0], max(ranges[-1][1], end))
        else:
            ranges.append((start, end))

    parts = []
    for number, (start, end) in enumerate(ranges, start=1):
        snippet_lines = lines[start - 1:end]
        parts.append(
            f"--- match snippet {number}/{len(ranges)}: lines {start}-{end} ---\n"
            + _number_lines(snippet_lines, start_line=start, total_lines=total_lines)
        )
    return "\n\n".join(parts)


def pattern_snippets(text: str, pattern, context_lines: int = 10, regex_pattern: bool = True) -> str:
    return _numbered_snippets_for_matches(
        text,
        pattern_line_numbers(text, pattern, regex_pattern=regex_pattern),
        context_lines=context_lines,
    )

def short_id(length=8):
    return "".join(random.choices(string.ascii_letters,k=length))

def session_id():
    """Generate a unique, lexicographically sortable session ID."""
    return datetime.now().strftime("%Y%m%d_%H%M%S_%f")

DEFAULT_TOKEN_MODEL = "gpt-5"
MODEL_ENCODING_ALIASES = {
    "gpt-5.5": "o200k_base",
    "gpt-5.4": "o200k_base",
    "gpt-5.4-mini": "o200k_base",
    "gpt-5.3-codex": "o200k_base",
    "gpt-5.3-codex-spark": "o200k_base",
    "gpt-5.2": "o200k_base",
}


def tokenizer_for_model(model=None):
    model = model or DEFAULT_TOKEN_MODEL
    encoding = MODEL_ENCODING_ALIASES.get(str(model))
    if encoding:
        return tiktoken.get_encoding(encoding)
    try:
        return tiktoken.encoding_for_model(str(model))
    except KeyError:
        if str(model).startswith("gpt-5"):
            return tiktoken.get_encoding("o200k_base")
        return tiktoken.get_encoding("cl100k_base")


def tokenize(string, model=None):
    tokenizer = tokenizer_for_model(model)
    int_tokens = tokenizer.encode(string)
    str_tokens = [tokenizer.decode([int_token]) for int_token in int_tokens]
    return str_tokens

def utf8_safe_tokenize(s):
    return regex.findall(r'\X', s)

def token_count(string, model=None):
    return len(tokenizer_for_model(model).encode(string))


def token_count_payload(payload, model=None):
    if payload is None:
        return 0
    text = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return token_count(text, model=model)

def sort(messages):
    return sorted(messages, key=lambda msg: msg.timestamp)

def snake_case_type(cls):
    name = cls.__name__
    chars = []
    for i, char in enumerate(name):
        if char.isupper() and i > 0:
            chars.append('_')
        chars.append(char.lower())
    return ''.join(chars)


def type_hierarchy(cls, root):
    return [
        snake_case_type(base)
        for base in reversed(cls.mro())
        if isinstance(base, type) and issubclass(base, root) and base is not object
    ]


def truncate(string, max_tokens=2000, start_line=1, model=None):
    """
    Truncate a string to a maximum number of tokens using line-based chunking.

    Args:
        string: The string to truncate
        max_tokens: Maximum number of tokens to keep
        start_line: The line number of the first line in the string (1-indexed).
                   Used for skipping content and tracking line numbers in truncation messages.

    Returns:
        Truncated string with indication of removed content
    """
    # line-based pagination
    lines = string.splitlines(keepends=True)
    if start_line > 1:
        if start_line > len(lines):
            return ""
        string = ''.join(lines[start_line - 1:])
        lines = string.splitlines(keepends=True)

    # Quick check - if already under limit after pagination, return as-is
    tokens = tokenize(string, model=model)
    if len(tokens) <= max_tokens:
        return string

    # Calculate the actual last line number after skipping
    remaining_lines = len(lines)

    # Assemble lines up to max_tokens
    result_lines = []
    current_tokens = 0

    for line in lines:
        line_tokens = token_count(line, model=model)
        if current_tokens + line_tokens <= max_tokens:
            result_lines.append(line)
            current_tokens += line_tokens
        else:
            break

    if result_lines:
        result = ''.join(result_lines)
        num_kept = len(result_lines)

        # Only show truncation message if we didn't include all lines
        if num_kept < remaining_lines:
            first_truncated = start_line + num_kept
            last_line = start_line + remaining_lines - 1

            if not result.endswith('\n'):
                result += '\n'
            result += f"\n...\n\n[Lines {first_truncated}-{last_line} truncated]\n"

        return result
    else:
        return f"[Lines {start_line}-{start_line + remaining_lines - 1} truncated - first line exceeds token limit]\n"

def pack_msgs(messages):
    text = ''
    for message in messages:
        text += message.name + ':\n'
        text += message.content.strip() + '\n\n'
    return text

def msg_token_count(msg, model=None):
    return msg.api_token_count(model=model)

def total_tokens(messages, model=None):
    return sum(msg_token_count(msg, model=model) for msg in messages)

def split_history_turns(messages):
    """Split a message history into complete turns and a trailing remainder.

    A turn is bounded by final assistant messages or interruptions: the
    previous end marker is excluded, and the closing end marker is included. A
    compaction is a hard boundary and is excluded from the next turn. Assistant
    messages with tool calls are intermediate loop messages, not final answers.
    """
    turns = []
    current = []

    def msg_type(msg):
        return msg.get("type") if isinstance(msg, dict) else getattr(msg, "type", None)

    def is_final_assistant(msg):
        if msg_type(msg) != "assistant_message":
            return False
        tool_calls = msg.get("tool_calls") if isinstance(msg, dict) else getattr(msg, "tool_calls", None)
        return not tool_calls

    def is_compaction(msg):
        return msg_type(msg) == "compaction_message"

    def is_interruption_marker(msg):
        if msg_type(msg) == "interrupt_message":
            return True
        if msg_type(msg) != "developer_message":
            return False
        content = msg.get("content") if isinstance(msg, dict) else getattr(msg, "content", "")
        content = str(content).lower()
        return (
            "user interrupted the current turn" in content
            or "interrupted by the user" in content
        )

    for msg in messages:
        if is_compaction(msg):
            turns = []
            current = []
            continue
        current.append(msg)
        if is_final_assistant(msg) or is_interruption_marker(msg):
            turns.append(current)
            current = []

    return turns, current

def find_pattern(text, pattern=None):
    """
    Renvoie une liste de tuples contenant TOUS les groupes capturés par le pattern.

    - Si le pattern contient 1 groupe  -> tuple de 1 élément
    - Si le pattern contient n groupes -> tuple de n éléments
    """

    pattern = pattern or r'```python(.*?)```'
    iterator = re.finditer(pattern, text, re.DOTALL)

    return [
        tuple(match.groups())     # groups() renvoie *tous* les groupes capturés
        for match in iterator
    ]

def format(string, context=None):
    # Si aucun contexte n'est fourni, utiliser un dictionnaire vide
    if context is None:
        context = {}
    # Trouver les expressions entre <<...>>
    def replace_expr(match):
        expr = match.group(1)
        try:
            # Évaluer l'expression dans le contexte donné et la convertir en chaîne
            return str(eval(expr, context))
        except Exception:
            # print(f"could not evaluate expr: {expr}\n Exception:\n {str(e)}")
            # En cas d'erreur, retourner l'expression non évaluée
            return '<<' + expr + '>>'
    # Remplacer chaque expression par son évaluation
    return re.sub(r'<<(.*?)>>', replace_expr, string)

def timestamp(digits=3):
    base = datetime.now().strftime("%Y%m%dT%H%M%S.%f")
    if digits == 0:
        return base[:15]  # Jusqu'à la seconde uniquement
    return base[:15 + 1 + digits]

def guess_extension_from_bytes(data):
    """
    Guess file extension from byte content using filetype library.
    Returns None if unable to determine the file type.

    Args:
        data: bytes or BytesIO object containing file data

    Returns:
        str: File extension with leading dot (e.g., '.png') or None if unable to determine
    """
    import filetype
    from io import BytesIO

    # Ensure we have bytes
    if isinstance(data, BytesIO):
        data = data.getvalue()
    elif hasattr(data, 'read'):
        data = data.read()

    if not data or len(data) == 0:
        return None

    kind = filetype.guess(data)
    if kind is not None:
        return f'.{kind.extension}'

    return None

def _uploaded_filename(source, data, name=None):
    if name is None:
        if isinstance(source, str):
            name = os.path.basename(source)
        elif hasattr(source, 'name') and source.name:
            name = source.name
        else:
            name = f"uploaded_file_{short_id()}"

    _, name_ext = os.path.splitext(name)
    if name_ext:
        extension = name_ext
    elif isinstance(source, str):
        extension = os.path.splitext(source)[1]
    else:
        extension = guess_extension_from_bytes(data) or ''

    return os.path.splitext(name)[0] + extension

def upload_file_to_folder(source, folder, name=None):
    """Copy or write a file-like source into folder and return its absolute path."""
    if source is None:
        raise ValueError("A file source must be provided")

    os.makedirs(folder, exist_ok=True)

    if isinstance(source, str):
        if not os.path.exists(source):
            raise ValueError(f"File not found: {source}")
        data = None
        filename = _uploaded_filename(source, data, name=name)
        dest_path = os.path.join(folder, filename)
        shutil.copy2(source, dest_path)
    elif isinstance(source, BytesIO):
        data = source.getvalue()
        filename = _uploaded_filename(source, data, name=name)
        dest_path = os.path.join(folder, filename)
        with open(dest_path, 'wb') as f:
            f.write(data)
    elif isinstance(source, bytes):
        data = source
        filename = _uploaded_filename(source, data, name=name)
        dest_path = os.path.join(folder, filename)
        with open(dest_path, 'wb') as f:
            f.write(data)
    else:
        raise TypeError(f"Unsupported source type: {type(source)}. Expected str, BytesIO, or bytes.")

    return os.path.abspath(dest_path)

class Logger:

    def __init__(self,file=None):
        self.file=file or root_join('logs',"log.txt")
        open(self.file,'w', encoding='utf-8').close()

    def log(self,message):
        with open(self.file,'a',encoding="utf-8") as f:
            f.write(str(message)+'\n')

    def log_to_file(self,content,file=None):
        file = file or self.file
        with open(file,'w',encoding="utf-8") as f:
            f.write(str(content)+'\n')

def _render_numbered_read_text(text: str, start_at_line=1, end_at_line=None, max_tokens=8000, pattern=None, pattern_context_lines=10, regex=True):
    effective_start_at_line = max(1, int(start_at_line or 1))
    total_lines = len(text.splitlines())
    if pattern:
        text = pattern_snippets(text, pattern, context_lines=pattern_context_lines, regex_pattern=regex)
        if max_tokens > 0:
            text = truncate(text, max_tokens=max_tokens, start_line=1)
        return text

    if end_at_line is not None:
        effective_end_at_line = int(end_at_line)
        if effective_end_at_line < effective_start_at_line:
            raise ValueError("end_at_line must be greater than or equal to start_at_line")
        lines = text.splitlines(keepends=True)
        if effective_start_at_line > len(lines):
            text = ""
        else:
            selected_lines = lines[effective_start_at_line - 1:effective_end_at_line]
            if max_tokens > 0:
                result_lines = []
                current_tokens = 0
                for line in selected_lines:
                    line_tokens = token_count(line)
                    if current_tokens + line_tokens <= max_tokens:
                        result_lines.append(line)
                        current_tokens += line_tokens
                    else:
                        break
                text = ''.join(result_lines)
                if len(result_lines) < len(selected_lines):
                    if not text.endswith('\n'):
                        text += '\n'
                    first_truncated = effective_start_at_line + len(result_lines)
                    last_truncated = effective_start_at_line + len(selected_lines) - 1
                    text += f"\n...\n\n[Lines {first_truncated}-{last_truncated} truncated]\n"
            else:
                text = ''.join(selected_lines)
        return add_line_numbers(text, start_line=effective_start_at_line, total_lines=total_lines)

    # Apply pagination and truncation - truncate function handles smart chunking internally
    if max_tokens > 0:
        text = truncate(text, max_tokens=max_tokens, start_line=effective_start_at_line)
    elif effective_start_at_line > 1:
        lines = text.splitlines(keepends=True)
        text = "" if effective_start_at_line > len(lines) else ''.join(lines[effective_start_at_line - 1:])
    return add_line_numbers(text, start_line=effective_start_at_line, total_lines=total_lines)


def _view_search_snippets(text: str, search_query, context_lines: int = 10) -> str:
    query = str(search_query)
    lines = text.splitlines()
    matches = [index for index, line in enumerate(lines, start=1) if query in line]
    if not matches:
        return f"No results for search_query: {query!r}"

    context_lines = max(0, int(context_lines or 0))
    ranges = []
    for match_line in matches:
        start = max(1, match_line - context_lines)
        end = min(len(lines), match_line + context_lines)
        if ranges and start <= ranges[-1][1] + 1:
            ranges[-1] = (ranges[-1][0], max(ranges[-1][1], end))
        else:
            ranges.append((start, end))

    parts = []
    for number, (start, end) in enumerate(ranges, start=1):
        snippet = "\n".join(lines[start - 1:end])
        parts.append(f"--- search result {number}/{len(ranges)} ---\n{snippet}")
    return "\n\n".join(parts)


READ_DIRECTORY_EXCLUDES = {
    ".git",
    ".hg",
    ".svn",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    ".tox",
    ".venv",
    "__pycache__",
    "build",
    "dist",
    "node_modules",
}


def _directory_entries(path):
    try:
        entries = list(os.scandir(path))
    except OSError as exc:
        raise OSError(f"failed to list directory {path}: {exc}") from exc
    entries = [entry for entry in entries if entry.name not in READ_DIRECTORY_EXCLUDES]
    return sorted(entries, key=lambda entry: (not entry.is_dir(follow_symlinks=False), entry.name.lower()))


def _render_directory_tree(path, max_tokens=8000):
    root = os.path.abspath(path)
    lines = [f"{os.path.basename(root) or root}/"]
    entries = _directory_entries(root)
    for index, entry in enumerate(entries):
        is_last = index == len(entries) - 1
        connector = "└── " if is_last else "├── "
        child_prefix = "    " if is_last else "│   "
        suffix = "/" if entry.is_dir(follow_symlinks=False) else ""
        lines.append(f"{connector}{entry.name}{suffix}")
        if entry.is_dir(follow_symlinks=False):
            children = _directory_entries(entry.path)
            for child_index, child in enumerate(children):
                child_connector = "└── " if child_index == len(children) - 1 else "├── "
                child_suffix = "/" if child.is_dir(follow_symlinks=False) else ""
                lines.append(f"{child_prefix}{child_connector}{child.name}{child_suffix}")
    text = "\n".join(lines)
    if max_tokens > 0:
        text = truncate(text, max_tokens=max_tokens, start_line=1)
    return text


def _iter_directory_files(path):
    for root, dirnames, filenames in os.walk(path):
        dirnames[:] = sorted(
            [dirname for dirname in dirnames if dirname not in READ_DIRECTORY_EXCLUDES],
            key=str.lower,
        )
        for filename in sorted(filenames, key=str.lower):
            yield os.path.join(root, filename)


def _read_utf8_text_file(path):
    with open(path, "rb") as f:
        data = f.read()
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise UnicodeDecodeError(exc.encoding, exc.object, exc.start, exc.end, f"{exc.reason}. read requires UTF-8 text files; use view for extracted content.") from exc


def _directory_pattern_search(path, pattern, max_tokens=8000, pattern_context_lines=10, regex=True):
    pattern_text = str(pattern)
    parts = []
    skipped = 0
    for file_path in _iter_directory_files(path):
        try:
            text = _read_utf8_text_file(file_path)
        except UnicodeDecodeError:
            skipped += 1
            continue
        matches = pattern_line_numbers(text, pattern_text, regex_pattern=regex)
        if not matches:
            continue
        snippet = _numbered_snippets_for_matches(text, matches, context_lines=pattern_context_lines)
        rel_path = os.path.relpath(file_path, path)
        parts.append(f"--- file: {rel_path} ---\n{snippet}")
    if not parts:
        result = f"No matches for pattern: {pattern_text!r}"
    else:
        result = "\n\n".join(parts)
        if skipped:
            result += f"\n\n[Skipped {skipped} non-UTF-8 file(s)]"
    if max_tokens > 0:
        result = truncate(result, max_tokens=max_tokens, start_line=1)
    return result


def read_document_content(source, start_at_line=1, end_at_line=None, max_tokens=8000, pattern=None, pattern_context_lines=10, regex=True):
    """Read local UTF-8 files, list directories, or recursively search directories by pattern."""
    if not isinstance(source, (str, os.PathLike)):
        raise TypeError("read only accepts a local file or directory path. Use view for objects or extracted document content.")
    path = os.fspath(source)
    if path.startswith(("http://", "https://")):
        raise ValueError("read only accepts local UTF-8 files or directories. Use view for URLs.")
    if os.path.isdir(path):
        if pattern:
            return _directory_pattern_search(path, pattern, max_tokens=max_tokens, pattern_context_lines=pattern_context_lines, regex=regex)
        return _render_directory_tree(path, max_tokens=max_tokens)
    if not os.path.isfile(path):
        raise FileNotFoundError(f"File not found: {path}")
    text = _read_utf8_text_file(path)
    return _render_numbered_read_text(text, start_at_line=start_at_line, end_at_line=end_at_line, max_tokens=max_tokens, pattern=pattern, pattern_context_lines=pattern_context_lines, regex=regex)


def view_document_content(source, start_at_line=1, max_tokens=8000, search_query=None, search_context_lines=10):
    """Extract text from varied sources via get_text. This view is not line-structure reliable."""
    get_text = import_module(".get_text.get_text", __package__).get_text
    text = get_text(source)
    effective_start_at_line = int(start_at_line or 1)
    if search_query:
        text = _view_search_snippets(text, search_query, context_lines=search_context_lines)
        if max_tokens > 0:
            text = truncate(text, max_tokens=max_tokens, start_line=1)
        return text
    if max_tokens > 0:
        return truncate(text, max_tokens=max_tokens, start_line=effective_start_at_line)
    if effective_start_at_line > 1:
        lines = text.splitlines(keepends=True)
        return "" if effective_start_at_line > len(lines) else ''.join(lines[effective_start_at_line - 1:])
    return text
