from modict import modict


class HookContext(modict):
    """Mutable context passed to hook handlers.

    Hooks are intentionally generic extension points. Handlers may inspect or
    mutate ``payload`` in place, or return a mapping whose keys are merged back
    into the context. A future permission layer can build on top of the same
    primitive without changing call sites.
    """

    name = ""
    payload = modict.factory(modict)
    results = modict.factory(list)
    stopped = False
    error = None

    def stop(self, reason=None):
        self.stopped = True
        if reason is not None:
            self.reason = reason
        return self


class HookManager:
    def __init__(self, agent=None):
        self.agent = agent
        self.handlers = modict()
        self.owners = {}

    def add(self, name, func=None, owner=None):
        if func is None:
            def decorator(f):
                return self.add(name, f, owner=owner)
            return decorator
        hook_name = str(name)
        self.handlers.setdefault(hook_name, []).append(func)
        if owner is not None:
            self.owners.setdefault(hook_name, {})[func] = owner
        return func

    on = add

    def has(self, name):
        return bool(self.handlers.get(str(name)))

    def run(self, name, **payload):
        context = HookContext(name=str(name), payload=modict(payload), results=[])
        for handler in list(self.handlers.get(str(name), ())):
            result = handler(context)
            context.results.append(result)
            if isinstance(result, dict):
                context.update(result)
            if context.stopped:
                break
        return context

    def run_legacy(self, name, *args):
        results = []
        for handler in list(self.handlers.get(str(name), ())):
            results.append(handler(*args))
        return results

    def remove_by_owner(self, owner):
        removed = modict()
        for name, handlers in list(self.handlers.items()):
            owners = self.owners.get(name, {})
            kept = []
            for handler in handlers:
                if owners.get(handler) == owner:
                    removed.setdefault(name, []).append(handler)
                    owners.pop(handler, None)
                else:
                    kept.append(handler)
            if kept:
                self.handlers[name] = kept
            else:
                self.handlers.pop(name, None)
                self.owners.pop(name, None)
        return removed

    def get(self, name, default=None):
        return self.handlers.get(str(name), default)

    def setdefault(self, name, default):
        return self.handlers.setdefault(str(name), default)

    def __contains__(self, name):
        return str(name) in self.handlers

    def __iter__(self):
        return iter(self.handlers)
