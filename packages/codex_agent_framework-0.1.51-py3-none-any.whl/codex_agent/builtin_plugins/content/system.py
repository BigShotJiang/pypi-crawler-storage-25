import os
import subprocess
import sys
import webbrowser

from ...tool import get_agent, tool

@tool
def show(file_or_url: str):
    """
    description: |
        Open a local file, folder, or URL with the system default application/browser.
        Use this tool when the user wants to visually inspect a source outside the chat.
    parameters:
        file_or_url:
            description: Absolute or relative local path, folder path, file URI, or HTTP(S) URL to open.
            type: string
    required:
        - file_or_url
    """
    target = str(file_or_url)
    if not target.startswith(("http://", "https://", "file://")):
        target = get_agent().resolve_path(target)

    opened = open_silently(target)
    if opened:
        return f"Opened: {target}"
    return f"Could not open: {target}"


@tool
def open_tui():
    """
    description: |
        Open the Textual chat TUI client in a separate terminal connected to an existing local agent server.
        This tool never starts an agent server. If the server is not already reachable, it fails instead of creating a second agent instance.
    """
    result = get_agent().open_tui()
    if result.get("already_open"):
        return f"TUI is already open with pid {result.tui.pid}."
    if result.get("opened"):
        return f"Opened TUI terminal process {result.terminal_pid}."
    return f"TUI not opened: {result.get('reason', 'unknown reason')}."


@tool
def close_tui():
    """
    description: Close the TUI client process previously opened by open_tui. This does not stop the agent server.
    """
    result = get_agent().close_tui()
    if result.get("closed"):
        return f"Closed TUI process {result.pid}."
    return result.get("reason") or "No active TUI."


def open_silently(target: str) -> bool:
    if os.name == "posix":
        opener = "open" if sys.platform == "darwin" else "xdg-open"
        try:
            subprocess.Popen(
                [opener, target],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,
                start_new_session=True,
            )
            return True
        except FileNotFoundError:
            pass

    return webbrowser.open(target)
