"""Built-in agent plugins.

Each non-private module in this package is loaded automatically by Agent at
startup. Modules can expose ``Plugin`` subclasses whose decorated methods are
registered as tools, providers, and slash commands.
"""

from ..plugin import Plugin

__all__ = ["Plugin"]
