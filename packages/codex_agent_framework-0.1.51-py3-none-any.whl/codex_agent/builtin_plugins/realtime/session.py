from __future__ import annotations

import base64
import json
import threading
import time
from pathlib import Path
from typing import Any, Callable

from ...event import RealtimeSessionRefreshEvent
from .bridge import RealtimeAgentBridge
from .audio import SoundDeviceAudioIO


EventLogger = Callable[[dict[str, Any]], None]


def build_text_input_event(text: str) -> dict[str, Any]:
    return {
        "type": "conversation.item.create",
        "item": {
            "type": "message",
            "role": "user",
            "content": [{"type": "input_text", "text": text}],
        },
    }


def build_response_create_event(*, output_modalities: list[str] | None = None) -> dict[str, Any]:
    event: dict[str, Any] = {"type": "response.create"}
    if output_modalities:
        event["response"] = {"output_modalities": output_modalities}
    return event


class HeadlessRealtimeSession:
    def __init__(
        self,
        *,
        client: Any,
        model: str,
        voice: str,
        instructions: str,
        session_id: str,
        agent_bridge: RealtimeAgentBridge | None = None,
        text_input: str | None = None,
        audio_output_path: Path | None = None,
        audio_io: SoundDeviceAudioIO | None = None,
        pause_input_during_output: bool = False,
        close_after_response: bool = False,
        stop_event: threading.Event | None = None,
        event_logger: EventLogger | None = None,
    ):
        self.client = client
        self.model = model
        self.voice = voice
        self.instructions = instructions
        self.session_id = session_id
        self.agent_bridge = agent_bridge
        self.text_input = text_input
        self.audio_output_path = audio_output_path
        self.audio_io = audio_io
        self.pause_input_during_output = pause_input_during_output
        self.close_after_response = close_after_response
        self.stop_event = stop_event or threading.Event()
        self.event_logger = event_logger
        self._socket: Any = None
        self._connected: threading.Event | None = None
        self._send_lock = threading.Lock()
        self._last_refresh_at = 0.0

    def stop_now(self) -> None:
        self.stop_event.set()
        if self.audio_io is not None:
            self.audio_io.stop()
        socket = self._socket
        if socket is not None:
            try:
                socket.close()
            except Exception:
                pass

    def build_session(self) -> dict[str, Any]:
        if self.agent_bridge is not None:
            session = self.agent_bridge.build_session(
                model=self.model,
                voice=self.voice,
                instructions=self.instructions,
            )
        else:
            session = {
                "type": "realtime",
                "model": self.model,
                "instructions": self.instructions,
                "audio": {"output": {"voice": self.voice}},
            }
        if self.audio_io is not None:
            audio = session.setdefault("audio", {})
            audio["input"] = {
                **dict(audio.get("input") or {}),
                "format": {"type": "audio/pcm", "rate": self.audio_io.sample_rate},
            }
            audio["output"] = {
                **dict(audio.get("output") or {}),
                "format": {"type": "audio/pcm", "rate": self.audio_io.sample_rate},
                "voice": self.voice,
            }
        return session

    def initial_events(self) -> list[dict[str, Any]]:
        events = [{"type": "session.update", "session": self.build_session()}]
        if self.agent_bridge is not None:
            events.extend(self.agent_bridge.initial_conversation_events())
            provider_event = self.agent_bridge.provider_context_event()
            if provider_event is not None:
                events.append(provider_event)
        if self.text_input:
            events.append(build_text_input_event(self.text_input))
            events.append(build_response_create_event(output_modalities=["text"]))
        return events

    def run(self) -> None:
        try:
            import websocket
        except ImportError as exc:
            raise RuntimeError("Headless realtime mode requires the websocket-client package.") from exc
        if self.client is None:
            raise RuntimeError("Headless realtime mode requires a Codex realtime client.")

        audio_file = self.audio_output_path.open("ab") if self.audio_output_path is not None else None
        unbind_agent_events = None
        connected = threading.Event()
        try:
            if self.audio_io is not None:
                self.audio_io.start()
            url = self.client.realtime_websocket_url(model=self.model)
            headers = [
                f"{key}: {value}"
                for key, value in self.client.realtime_websocket_headers(session_id=self.session_id).items()
            ]
            ws = websocket.WebSocketApp(
                url,
                header=headers,
                on_open=lambda socket: self._on_open(socket, connected),
                on_message=lambda socket, message: self._on_message(socket, message, audio_file),
                on_error=lambda _socket, error: self._on_error(error),
                on_close=lambda _socket, _code, _reason: self._on_close(connected),
            )
            self._socket = ws
            self._connected = connected
            if self.agent_bridge is not None:
                def _send_bridge_event(event: dict[str, Any]) -> None:
                    if connected.is_set():
                        with self._send_lock:
                            ws.send(json.dumps(event))

                unbind_agent_events = self.agent_bridge.bind_agent_events(
                    _send_bridge_event,
                    refresh_session=lambda event: self.send_refresh(reason=getattr(event, "reason", "runtime_state_changed")),
                )
            threading.Thread(target=self._close_when_stopped, args=(ws,), name="codex-agent-realtime-stop", daemon=True).start()
            if self.audio_io is not None:
                threading.Thread(target=self._send_audio_input, args=(connected, ws), name="codex-agent-realtime-audio-input", daemon=True).start()
            while not self.stop_event.is_set():
                ws.run_forever(ping_interval=20, ping_timeout=10)
                if not self.stop_event.is_set():
                    self.stop_event.set()
        finally:
            if unbind_agent_events is not None:
                unbind_agent_events()
            if self.audio_io is not None:
                self.audio_io.stop()
            self._socket = None
            self._connected = None
            connected.clear()
            if audio_file is not None:
                audio_file.close()

    def refresh_events(self, reason: str = "runtime_state_changed") -> list[dict[str, Any]]:
        if self.agent_bridge is None:
            return []
        return self.agent_bridge.refresh_events(model=self.model, voice=self.voice, instructions=self.instructions, reason=reason)

    def send_refresh(self, reason: str = "runtime_state_changed", *, debounce_seconds: float = 0.25) -> bool:
        socket = self._socket
        connected = self._connected
        if socket is None or connected is None or not connected.is_set() or self.agent_bridge is None:
            return False
        now = time.monotonic()
        if debounce_seconds > 0 and now - self._last_refresh_at < debounce_seconds:
            return False
        events = self.refresh_events(reason=reason)
        with self._send_lock:
            for event in events:
                socket.send(json.dumps(event))
            self._last_refresh_at = now
        self._log_event({"type": "codex_agent.realtime.session_refreshed", "reason": reason, "event_count": len(events)})
        agent = getattr(self.agent_bridge, "agent", None)
        if agent is not None:
            agent.emit(RealtimeSessionRefreshEvent, session_id=self.session_id, reason=reason, session=events[0].get("session") if events else None)
        return True

    def _on_open(self, socket: Any, connected: threading.Event) -> None:
        with self._send_lock:
            for event in self.initial_events():
                socket.send(json.dumps(event))
        connected.set()

    def _on_close(self, connected: threading.Event) -> None:
        connected.clear()
        self.stop_event.set()

    def _close_when_stopped(self, socket: Any) -> None:
        self.stop_event.wait()
        socket.close()

    def _on_message(self, socket: Any, message: str | bytes, audio_file: Any) -> None:
        if isinstance(message, bytes):
            message = message.decode("utf-8")
        event = json.loads(message)
        self._log_event(event)
        self._handle_audio_delta(event, audio_file)
        if self.agent_bridge is not None:
            self.agent_bridge.handle_sync_event(event)
            result = self.agent_bridge.handle_event(event)
            if result is not None:
                with self._send_lock:
                    for client_event in result.client_events():
                        socket.send(json.dumps(client_event))
        if self.close_after_response and event.get("type") == "response.done":
            socket.close()

    def _handle_audio_delta(self, event: dict[str, Any], audio_file: Any) -> None:
        if event.get("type") != "response.output_audio.delta":
            return
        delta = event.get("delta")
        if not isinstance(delta, str):
            return
        pcm16 = base64.b64decode(delta)
        if audio_file is not None:
            audio_file.write(pcm16)
            audio_file.flush()
        if self.audio_io is not None:
            self.audio_io.write_output(pcm16)

    def _on_error(self, error: Any) -> None:
        self._log_event({"type": "error", "error": str(error)})

    def _log_event(self, event: dict[str, Any]) -> None:
        if self.event_logger is not None:
            self.event_logger(event)

    def _send_audio_input(self, connected: threading.Event, socket: Any) -> None:
        if self.audio_io is None:
            return
        while not self.stop_event.is_set():
            if not connected.wait(timeout=0.2):
                continue
            if self.pause_input_during_output and self.audio_io.output_playing():
                self.audio_io.clear_input()
                continue
            chunk = self.audio_io.read_chunk(timeout=0.2)
            if not chunk:
                continue
            try:
                with self._send_lock:
                    socket.send(json.dumps({
                        "type": "input_audio_buffer.append",
                        "audio": base64.b64encode(chunk).decode("ascii"),
                    }))
            except Exception as exc:  # noqa: BLE001
                self._on_error(exc)
                self.stop_event.set()
                socket.close()
                return
