from __future__ import annotations

import json
from typing import Any, Callable

from modict import modict

from ...event import MessageAddedEvent, RuntimeStateChangedEvent, ToolCallDoneEvent, ToolCallStartEvent
from ...message import AssistantMessage, ToolResultWrapper, UserMessage
from ...tool import ServerTool, reset_current_agent, reset_current_call_id, set_current_agent, set_current_call_id


DEFAULT_REALTIME_INSTRUCTIONS = """
You are in realtime voice mode. Keep replies conversational, concise, and easy to interrupt.
If a tool is needed, call it normally and summarize the result briefly for the user.
""".strip()


def build_realtime_system_note(text: str) -> dict[str, Any]:
    return {
        "type": "conversation.item.create",
        "item": {
            "type": "message",
            "role": "system",
            "content": [{"type": "input_text", "text": text}],
        },
    }


class RealtimeToolResult(modict):
    call_id = ""
    name = ""
    output = ""

    def client_events(self) -> list[dict[str, Any]]:
        return [
            {
                "type": "conversation.item.create",
                "item": {
                    "type": "function_call_output",
                    "call_id": self.call_id,
                    "output": self.output,
                },
            },
            {"type": "response.create"},
        ]


class RealtimeAgentBridge:
    """Adapt a codex-agent instance to an OpenAI Realtime session."""

    def __init__(
        self,
        agent,
        *,
        realtime_instructions: str = DEFAULT_REALTIME_INSTRUCTIONS,
        voice_system_prompt: str = "",
        include_context: bool = True,
        input_transcription_model: str | None = "gpt-4o-mini-transcribe",
        tool_choice: str | dict[str, Any] = "auto",
        initial_context_messages: int = 40,
    ) -> None:
        self.agent = agent
        self.realtime_instructions = realtime_instructions
        self.voice_system_prompt = voice_system_prompt
        self.include_context = include_context
        self.input_transcription_model = input_transcription_model
        self.tool_choice = tool_choice
        self.initial_context_messages = max(0, int(initial_context_messages))
        self._synced_items: set[tuple[str, str]] = set()

    def build_session(self, *, model: str, voice: str, instructions: str = "") -> dict[str, Any]:
        session: dict[str, Any] = {
            "type": "realtime",
            "model": model,
            "instructions": self.build_instructions(instructions),
            "audio": self._audio_config(voice),
        }
        tools = self.realtime_tools()
        session["tools"] = tools
        session["tool_choice"] = self.tool_choice if tools else "none"
        return session

    def refresh_session_event(self, *, model: str, voice: str, instructions: str = "", reason: str = "runtime_state_changed") -> dict[str, Any]:
        return {
            "type": "session.update",
            "session": self.build_session(model=model, voice=voice, instructions=instructions),
        }

    def provider_context_event(self) -> dict[str, Any] | None:
        text = self.provider_context_text()
        return build_realtime_system_note("Current dynamic agent context snapshot:\n" + text) if text else None

    def provider_context_text(self) -> str:
        manager = getattr(self.agent, "context_manager", None)
        if manager is None:
            return ""
        parts: list[str] = []
        try:
            for message in manager.get_providers_messages():
                text = self._text_from_message_content(message.get("content", "") if hasattr(message, "get") else "")
                if text:
                    parts.append(text)
        except Exception as exc:  # noqa: BLE001
            parts.append(f"[provider context refresh failed: {exc}]")
        return "\n\n".join(parts).strip()

    def refresh_events(self, *, model: str, voice: str, instructions: str = "", reason: str = "runtime_state_changed") -> list[dict[str, Any]]:
        events = [self.refresh_session_event(model=model, voice=voice, instructions=instructions, reason=reason)]
        provider_event = self.provider_context_event()
        if provider_event is not None:
            events.append(provider_event)
        return events

    def build_instructions(self, extra: str = "") -> str:
        system = self.agent.config_manager.system_message().instruction_text()
        parts = [system]
        if self.voice_system_prompt.strip():
            parts.append(self.voice_system_prompt.strip())
        realtime_parts = [self.realtime_instructions, extra]
        realtime = "\n\n".join(part for part in realtime_parts if part)
        if realtime:
            parts.append("Realtime voice mode instructions:\n" + realtime)
        return "\n\n".join(part for part in parts if part)

    def initial_conversation_events(self) -> list[dict[str, Any]]:
        if not self.include_context:
            return []
        events: list[dict[str, Any]] = []
        messages = []
        if getattr(self.agent, "session", None) is not None:
            messages = list(self.agent.session.context_messages())
        max_messages = self.initial_context_messages
        if max_messages <= 0:
            return []
        for message in messages[-max_messages:]:
            events.extend(self._conversation_events_from_message(message))
        return events

    def _conversation_events_from_message(self, message: Any) -> list[dict[str, Any]]:
        tags = set(message.get("tags") or []) if hasattr(message, "get") else set()
        if "realtime" in tags and "mode_switch" not in tags:
            return []
        role = getattr(message, "role", message.get("role", "") if hasattr(message, "get") else "")
        if role not in {"user", "assistant", "system", "developer"}:
            return []
        text = self._text_from_message_content(message.get("content", "") if hasattr(message, "get") else "")
        if not text:
            return []
        if role in {"system", "developer"}:
            return [build_realtime_system_note(text)]
        content_type = "output_text" if role == "assistant" else "input_text"
        return [{
            "type": "conversation.item.create",
            "item": {
                "type": "message",
                "role": role,
                "content": [{"type": content_type, "text": text}],
            },
        }]

    def realtime_tools(self) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        seen: set[str] = set()
        for tool in self.agent.tools_manager.get_tools():
            name = str(tool.get("name") or tool.get("type") or "")
            if not name or name in seen:
                continue
            spec = self._realtime_tool_spec(tool)
            if spec is None:
                continue
            out.append(spec)
            seen.add(name)
        return out

    def _realtime_tool_spec(self, tool: Any) -> dict[str, Any] | None:
        if isinstance(tool, ServerTool):
            # Realtime cannot execute Responses server-side tools directly here.
            return None
        if tool.get("type") != "tool":
            return None
        return {
            "type": "function",
            "name": tool.name,
            "description": tool.get("description") or "No description provided",
            "parameters": {
                "type": "object",
                "properties": dict(tool.get("parameters") or {}),
                "required": list(tool.get("required") or []),
            },
        }

    def _audio_config(self, voice: str) -> dict[str, Any]:
        audio: dict[str, Any] = {"output": {"voice": voice}}
        if self.input_transcription_model:
            audio["input"] = {"transcription": {"model": self.input_transcription_model}}
        return audio

    def handle_event(self, event: dict[str, Any]) -> RealtimeToolResult | None:
        if event.get("type") != "response.function_call_arguments.done":
            return None
        name = str(event.get("name") or "")
        call_id = str(event.get("call_id") or event.get("item_id") or "")
        if not name or not call_id:
            return None
        arguments = self._parse_arguments(event.get("arguments"))
        raw = self._execute_tool_for_realtime(name, arguments, call_id)
        return RealtimeToolResult(call_id=call_id, name=name, output=raw)

    def _execute_tool_for_realtime(self, name: str, arguments: Any, call_id: str) -> str:
        tool = self.agent.tools.get(name)
        tool_call = {"name": name, "call_id": call_id, "arguments": json.dumps(arguments, ensure_ascii=False)}
        self.agent.emit(ToolCallStartEvent, tool_call=tool_call, tool=tool)
        status = "success"
        try:
            if tool is None or tool.get("type") != "tool":
                raise RuntimeError(f"Tool {name!r} not found or not executable in realtime mode.")
            kwargs = arguments if isinstance(arguments, dict) else {}
            args = [] if isinstance(arguments, dict) else [arguments]
            agent_context = set_current_agent(self.agent)
            call_id_context = set_current_call_id(call_id)
            try:
                hook = self.agent.run_hook("tool.call.before", tool=tool, tool_call=tool_call, args=args, kwargs=kwargs)
                output = self.agent.mainloop_manager.invoke_tool(tool, hook.payload.args, hook.payload.kwargs)
                hook = self.agent.run_hook("tool.call.after", tool=tool, tool_call=tool_call, output=output, status=status)
                output = hook.payload.output
            finally:
                reset_current_call_id(call_id_context)
                reset_current_agent(agent_context)
            raw = self._stringify_output(output)
        except Exception as exc:  # noqa: BLE001
            status = "failure"
            raw = f"Error executing tool {name!r}: {exc}"
            self.agent.run_hook("tool.call.error", tool=tool, tool_call=tool_call, error=exc)
        self.agent.emit(ToolCallDoneEvent, tool_call=tool_call, tool=tool, content=raw)
        self._add_transient_tool_wrapper(name=name, call_id=call_id, status=status, content=raw)
        return raw

    def _add_transient_tool_wrapper(self, *, name: str, call_id: str, status: str, content: str) -> None:
        try:
            self.agent.sessions_manager.append_message(ToolResultWrapper(
                tool_name=name,
                call_id=call_id,
                status=status,
                content=content,
                turns_left=1,
            ))
        except Exception:
            pass

    @staticmethod
    def _stringify_output(output: Any) -> str:
        if isinstance(output, str):
            return output
        try:
            return json.dumps(output, ensure_ascii=False, default=str)
        except Exception:
            return str(output)

    def bind_agent_events(self, send_event: Callable[[dict[str, Any]], None], refresh_session: Callable[[Any], Any] | None = None) -> Callable[[], None]:
        handlers: list[tuple[Any, Callable[[Any], None]]] = []

        def _bind(event_type: Any, handler: Callable[[Any], None]) -> None:
            self.agent.events.on(event_type, handler)
            handlers.append((event_type, handler))

        def _send_many(events: list[dict[str, Any]]) -> None:
            for event in events:
                send_event(event)

        _bind(MessageAddedEvent, lambda event: _send_many(self._message_added_events(event)))
        if refresh_session is not None:
            _bind(RuntimeStateChangedEvent, refresh_session)

        def _unbind() -> None:
            for event_type, handler in handlers:
                self.agent.events.off(event_type, handler)

        return _unbind

    def _message_added_events(self, event: Any) -> list[dict[str, Any]]:
        message = event.get("message") if hasattr(event, "get") else None
        if message is None:
            return []
        return self._conversation_events_from_message(message)

    def handle_sync_event(self, event: dict[str, Any]) -> None:
        event_type = str(event.get("type") or "")
        if event_type in {"conversation.item.input_audio_transcription.completed", "conversation.input_transcript.done"}:
            self._sync_text("user", self._first_text(event, "transcript", "input_transcript", "text"), self._event_item_id(event), event_type)
        elif event_type in {"response.output_audio_transcript.done", "response.output_text.done", "conversation.output_transcript.done"}:
            self._sync_text("assistant", self._first_text(event, "transcript", "text", "output_text"), self._event_item_id(event), event_type)

    def _sync_text(self, role: str, text: str, item_id: str, event_type: str) -> None:
        text = text.strip()
        if not text:
            return
        key = (role, item_id or f"{event_type}:{text}")
        if key in self._synced_items:
            return
        self._synced_items.add(key)
        cls = UserMessage if role == "user" else AssistantMessage
        self.agent.sessions_manager.append_message(cls(content=text, tags=["realtime"]))

    @staticmethod
    def _parse_arguments(arguments: Any) -> Any:
        if arguments in (None, ""):
            return {}
        if isinstance(arguments, str):
            parsed = json.loads(arguments)
            return parsed if isinstance(parsed, dict) else parsed
        return arguments

    @staticmethod
    def _event_item_id(event: dict[str, Any]) -> str:
        return str(event.get("item_id") or event.get("content_index") or event.get("output_index") or event.get("response_id") or event.get("event_id") or "")

    @staticmethod
    def _first_text(event: dict[str, Any], *keys: str) -> str:
        for key in keys:
            value = event.get(key)
            if isinstance(value, str) and value.strip():
                return value
        return ""

    @classmethod
    def _text_from_message_content(cls, content: Any) -> str:
        if isinstance(content, str):
            return content.strip()
        if not isinstance(content, list):
            return ""
        parts: list[str] = []
        for block in content:
            if isinstance(block, str):
                parts.append(block)
            elif isinstance(block, dict):
                text = cls._first_text(block, "text", "transcript", "input_transcript", "content")
                if text:
                    parts.append(text)
        return "\n".join(parts).strip()
