from __future__ import annotations

import threading
import uuid
from pathlib import Path
from typing import Any

from modict import modict

from ...event import (
    RealtimeApiEvent,
    RealtimeErrorEvent,
    RealtimeStartedEvent,
    RealtimeStartingEvent,
    RealtimeStoppedEvent,
)
from .audio import LiveKitAudioIO, SoundDeviceAudioIO
from .bridge import RealtimeAgentBridge
from .session import HeadlessRealtimeSession


class RealtimeManager:
    session_class = HeadlessRealtimeSession

    def __init__(self, agent: Any, config: Any):
        self.agent = agent
        self.config = config
        self._thread: threading.Thread | None = None
        self._session: HeadlessRealtimeSession | None = None
        self._stop_event: threading.Event | None = None
        self._session_id: str | None = None
        self._state = "stopped"
        self._last_error: str | None = None
        self._last_event_type: str | None = None
        self._stop_reason: str | None = None
        self._stopped_session_ids: set[str] = set()
        self._lock = threading.RLock()

    def status(self) -> modict:
        with self._lock:
            active = self._thread is not None and self._thread.is_alive()
            state = "active" if active and self._state == "active" else self._state
            if not active and state in {"starting", "active", "stopping"}:
                state = "stopped" if not self._last_error else "error"
            return modict(
                active=active,
                state=state,
                model=self.config.get("model"),
                voice=self.config.get("voice"),
                audio_backend=self.config.get("audio_backend"),
                session_id=self._session_id,
                last_error=self._last_error,
                last_event_type=self._last_event_type,
            )

    def start(self, text: str | None = None, *, audio: bool | None = None, close_after_response: bool | None = None) -> modict:
        with self._lock:
            if self._thread is not None and self._thread.is_alive():
                return modict(status="already_running", **self.status())
            self._clear_finished_locked()
            self._last_error = None
            self._last_event_type = None
            self._stop_reason = None
            self._state = "starting"
            stop_event = threading.Event()
            session_id = uuid.uuid4().hex
            audio_enabled = self._bool_config("audio_enabled") if audio is None else bool(audio)
            close_after = self._bool_config("close_after_response") if close_after_response is None else bool(close_after_response)
            try:
                session = self._build_session(
                    session_id=session_id,
                    text=text,
                    audio=audio_enabled,
                    close_after_response=close_after,
                    stop_event=stop_event,
                )
            except Exception as exc:  # noqa: BLE001
                self._session_id = session_id
                self._stop_event = None
                self._state = "error"
                self._set_error(str(exc), session_id=session_id)
                return modict(status="error", **self.status())
            self._stop_event = stop_event
            self._session_id = session_id
            self._session = session
            self._thread = threading.Thread(
                target=self._run_session,
                args=(session, session_id, audio_enabled),
                name="codex-agent-realtime",
                daemon=True,
            )
            self.agent.emit(
                RealtimeStartingEvent,
                session_id=session_id,
                model=self.config.get("model"),
                voice=self.config.get("voice"),
                audio_enabled=audio_enabled,
            )
            self._thread.start()
            self._state = "active"
            self.agent.emit(
                RealtimeStartedEvent,
                session_id=session_id,
                model=self.config.get("model"),
                voice=self.config.get("voice"),
                audio_enabled=audio_enabled,
            )
            return modict(status="started", **self.status())

    def stop(self, timeout: float | None = None, reason: str = "requested") -> modict:
        with self._lock:
            session = self._session
            thread = self._thread
            session_id = self._session_id or ""
            if session is None and thread is None:
                self._state = "stopped" if not self._last_error else "error"
                return modict(status="stopped", **self.status())
            self._state = "stopping"
            self._stop_reason = reason
            if self._stop_event is not None:
                self._stop_event.set()
            if session is not None:
                session.stop_now()
        if thread is not None and thread.is_alive():
            thread.join(timeout=timeout if timeout is not None else float(self.config.get("stop_timeout", 3.0)))
        with self._lock:
            self._clear_finished_locked()
            if self._thread is None:
                self._state = "stopped" if not self._last_error else "error"
            return modict(status="stopped", **self.status())

    def command(self, action: str = "status", text: str | None = None):
        action = (action or "status").strip().lower()
        if action in {"on", "start"}:
            return self._format_status(self.start(text=text))
        if action in {"off", "stop"}:
            return self._format_status(self.stop(reason="command"))
        if action == "status":
            return self._format_status(self.status())
        return "Usage: /realtime [start|stop|status] [optional text]"

    def _build_session(self, *, session_id: str, text: str | None, audio: bool, close_after_response: bool, stop_event: threading.Event) -> HeadlessRealtimeSession:
        audio_io = self._build_audio_io() if audio else None
        bridge = RealtimeAgentBridge(
            self.agent,
            realtime_instructions=str(self.config.get("instructions") or ""),
            voice_system_prompt=str(self.config.get("voice_system_prompt") or ""),
            include_context=self._bool_config("include_context"),
            input_transcription_model=self.config.get("input_transcription_model"),
            tool_choice=self.config.get("tool_choice") or "auto",
            initial_context_messages=int(self.config.get("initial_context_messages") or 40),
        )
        return self.session_class(
            client=self._realtime_client(),
            model=self.config.get("model"),
            voice=self.config.get("voice"),
            instructions=str(self.config.get("session_instructions") or ""),
            session_id=session_id,
            agent_bridge=bridge,
            text_input=text,
            audio_output_path=self._audio_output_path(),
            audio_io=audio_io,
            pause_input_during_output=self._bool_config("pause_input_during_output"),
            close_after_response=close_after_response,
            stop_event=stop_event,
            event_logger=self._log_event,
        )

    def _realtime_client(self):
        client = getattr(self.agent, "client", None)
        if client is not None:
            return client
        ai = getattr(self.agent, "ai", None)
        if ai is None:
            raise RuntimeError("Realtime mode requires an agent AI client.")
        cached = getattr(ai, "_codex_client", None)
        return cached if cached is not None else ai.codex_client

    def _build_audio_io(self):
        backend = str(self.config.get("audio_backend") or "sounddevice").lower()
        common = dict(
            sample_rate=int(self.config.get("sample_rate") or 24000),
            input_device=self.config.get("input_device"),
            output_device=self.config.get("output_device"),
            input_rms_threshold=float(self.config.get("input_rms_threshold") or 0.0),
            quiet_tail_ms=int(self.config.get("quiet_tail_ms") or 1000),
            on_error=self._set_error,
        )
        if backend == "sounddevice":
            return SoundDeviceAudioIO(**common)
        if backend == "livekit":
            return LiveKitAudioIO(
                **common,
                enable_aec=self._bool_config("enable_aec"),
                noise_suppression=self._bool_config("noise_suppression"),
                high_pass_filter=self._bool_config("high_pass_filter"),
                auto_gain_control=self._bool_config("auto_gain_control"),
                stream_delay_ms=int(self.config.get("stream_delay_ms") or 50),
            )
        raise ValueError(f"Unsupported realtime audio backend: {backend!r}")

    def _audio_output_path(self) -> Path | None:
        value = self.config.get("audio_output_path")
        return Path(value).expanduser() if value else None

    def _run_session(self, session: HeadlessRealtimeSession, session_id: str, audio_enabled: bool) -> None:
        try:
            session.run()
        except Exception as exc:  # noqa: BLE001
            self._set_error(str(exc), session_id=session_id)
        finally:
            with self._lock:
                reason = self._stop_reason or "ended"
                if self._session is session:
                    self._session = None
                    self._thread = None
                    self._stop_event = None
                    self._state = "error" if self._last_error else "stopped"
            self._emit_stopped(session_id, reason)

    def _log_event(self, event: dict[str, Any]) -> None:
        event_type = str(event.get("type") or "")
        if event_type:
            self._last_event_type = event_type
            self.agent.emit(RealtimeApiEvent, session_id=self._session_id or "", api_event=event, event_type=event_type)
        if event_type == "error":
            error = event.get("error")
            self._set_error(error if isinstance(error, str) else str(error))

    def _set_error(self, message: str, *, session_id: str | None = None) -> None:
        self._last_error = str(message)
        self._state = "error"
        self._emit_error(session_id or self._session_id or "", self._last_error)

    def _emit_error(self, session_id: str, error: str) -> None:
        self.agent.emit(RealtimeErrorEvent, session_id=session_id, error=error)

    def _emit_stopped(self, session_id: str, reason: str) -> None:
        if session_id in self._stopped_session_ids:
            return
        self._stopped_session_ids.add(session_id)
        self.agent.emit(RealtimeStoppedEvent, session_id=session_id, reason=reason)

    def _clear_finished_locked(self) -> None:
        if self._thread is not None and not self._thread.is_alive():
            self._thread = None
            self._session = None
            self._stop_event = None

    def _bool_config(self, key: str) -> bool:
        return bool(self.config.get(key))

    @staticmethod
    def _format_status(status: dict[str, Any]) -> str:
        state = status.get("state") or ("active" if status.get("active") else "stopped")
        details = f"Realtime voice is {state}."
        if status.get("model"):
            details += f" model={status.get('model')}"
        if status.get("voice"):
            details += f" voice={status.get('voice')}"
        if status.get("last_error"):
            details += f" last_error={status.get('last_error')}"
        return details
