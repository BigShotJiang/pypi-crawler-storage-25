from __future__ import annotations

import queue
import threading
from typing import Any, Callable

try:
    import numpy as np
except ImportError:  # pragma: no cover - exercised only on minimal audio-less installs
    np = None


AudioErrorHandler = Callable[[str], None]


def _require_numpy():
    if np is None:
        raise RuntimeError("Realtime audio requires the numpy package.")


def _to_pcm16_bytes(frames) -> bytes:
    _require_numpy()
    mono = frames
    if mono.ndim > 1:
        mono = mono[:, 0]
    clipped = np.clip(mono, -1.0, 1.0)
    return (clipped * 32767.0).astype("<i2").tobytes()


def _mono_rms(frames) -> float:
    _require_numpy()
    mono = frames
    if mono.ndim > 1:
        mono = mono[:, 0]
    if mono.size == 0:
        return 0.0
    return float(np.sqrt(np.mean(np.square(mono, dtype=np.float64))))


def _pcm16_rms(pcm16: bytes) -> float:
    _require_numpy()
    if not pcm16:
        return 0.0
    samples = np.frombuffer(pcm16, dtype="<i2")
    if samples.size == 0:
        return 0.0
    normalized = samples.astype(np.float64) / 32768.0
    return float(np.sqrt(np.mean(np.square(normalized))))


class SoundDeviceAudioIO:
    def __init__(
        self,
        *,
        sample_rate: int = 24000,
        block_ms: int = 100,
        input_device: str | int | None = None,
        output_device: str | int | None = None,
        input_rms_threshold: float = 0.0,
        quiet_tail_ms: int = 1000,
        on_error: AudioErrorHandler | None = None,
    ):
        self.sample_rate = sample_rate
        self.block_ms = block_ms
        self.input_device = input_device
        self.output_device = output_device
        self.input_rms_threshold = input_rms_threshold
        self.quiet_tail_ms = quiet_tail_ms
        self.on_error = on_error
        self._input_stream: Any = None
        self._output_stream: Any = None
        self._input_queue: queue.Queue[bytes] = queue.Queue(maxsize=50)
        self._output_queue: queue.Queue[bytes] = queue.Queue(maxsize=100)
        self._closed = threading.Event()
        self._partial_output = b""
        self._input_active = False
        self._quiet_blocks = 0
        self._output_lock = threading.Lock()
        self._stop_lock = threading.Lock()
        self._output_pending_bytes = 0

    def start(self) -> None:
        _require_numpy()
        try:
            import sounddevice as sd
        except ImportError as exc:
            raise RuntimeError("Realtime audio requires the sounddevice package.") from exc

        blocksize = max(1, int(self.sample_rate * self.block_ms / 1000))
        self._input_stream = sd.InputStream(
            samplerate=self.sample_rate,
            channels=1,
            dtype="float32",
            blocksize=blocksize,
            device=self.input_device,
            callback=self._on_input,
        )
        self._output_stream = sd.OutputStream(
            samplerate=self.sample_rate,
            channels=1,
            dtype="int16",
            blocksize=blocksize,
            device=self.output_device,
            callback=self._on_output,
        )
        self._input_stream.start()
        self._output_stream.start()

    def stop(self) -> None:
        with self._stop_lock:
            self._closed.set()
            self.clear_output()
            for stream in (self._input_stream, self._output_stream):
                if stream is None:
                    continue
                try:
                    stream.stop()
                    stream.close()
                except Exception as exc:  # noqa: BLE001
                    self._report(f"audio stream close failed: {exc}")
            self._input_stream = None
            self._output_stream = None

    def read_chunk(self, timeout: float = 0.2) -> bytes | None:
        if self._closed.is_set():
            return None
        try:
            return self._input_queue.get(timeout=timeout)
        except queue.Empty:
            return None

    def clear_input(self) -> None:
        self._input_active = False
        self._quiet_blocks = 0
        self._drain(self._input_queue)

    def clear_output(self) -> None:
        self._partial_output = b""
        self._drain(self._output_queue)
        with self._output_lock:
            self._output_pending_bytes = 0

    def write_output(self, pcm16: bytes) -> None:
        if self._closed.is_set() or not pcm16:
            return
        with self._output_lock:
            self._output_pending_bytes += len(pcm16)
        try:
            self._output_queue.put_nowait(pcm16)
        except queue.Full:
            with self._output_lock:
                self._output_pending_bytes = max(0, self._output_pending_bytes - len(pcm16))
            self._report("audio output queue full; dropping model audio chunk")

    def output_playing(self) -> bool:
        with self._output_lock:
            return self._output_pending_bytes > 0 or bool(self._partial_output)

    def _on_input(self, indata, _frames: int, _time: Any, status: Any) -> None:
        if status:
            self._report(str(status))
        if self._closed.is_set() or not self._should_enqueue_input(indata):
            return
        try:
            self._input_queue.put_nowait(_to_pcm16_bytes(indata.copy()))
        except queue.Full:
            self._report("audio input queue full; dropping microphone chunk")

    def _should_enqueue_input(self, frames) -> bool:
        if self.input_rms_threshold <= 0:
            return True
        rms = _mono_rms(frames)
        if rms >= self.input_rms_threshold:
            self._input_active = True
            self._quiet_blocks = 0
            return True
        if not self._input_active:
            return False
        self._quiet_blocks += 1
        tail_blocks = max(1, int(self.quiet_tail_ms / self.block_ms))
        if self._quiet_blocks <= tail_blocks:
            return True
        self._input_active = False
        self._quiet_blocks = 0
        return False

    def _on_output(self, outdata, frames: int, _time: Any, status: Any) -> None:
        _require_numpy()
        if status:
            self._report(str(status))
        needed = frames * 2
        chunk = self._partial_output
        self._partial_output = b""
        while len(chunk) < needed and not self._closed.is_set():
            try:
                chunk += self._output_queue.get_nowait()
            except queue.Empty:
                break
        if len(chunk) < needed:
            consumed = len(chunk)
            chunk += b"\x00" * (needed - len(chunk))
        elif len(chunk) > needed:
            self._partial_output = chunk[needed:]
            chunk = chunk[:needed]
            consumed = needed
        else:
            consumed = needed
        with self._output_lock:
            self._output_pending_bytes = max(0, self._output_pending_bytes - consumed)
        outdata[:] = np.frombuffer(chunk, dtype="<i2").reshape(-1, 1)

    def _report(self, message: str) -> None:
        if self.on_error is not None:
            self.on_error(message)

    @staticmethod
    def _drain(q: queue.Queue) -> None:
        while True:
            try:
                q.get_nowait()
            except queue.Empty:
                return


class LiveKitAudioIO(SoundDeviceAudioIO):
    def __init__(
        self,
        *,
        sample_rate: int = 24000,
        block_ms: int = 10,
        input_device: str | int | None = None,
        output_device: str | int | None = None,
        input_rms_threshold: float = 0.003,
        quiet_tail_ms: int = 500,
        on_error: AudioErrorHandler | None = None,
        enable_aec: bool = True,
        noise_suppression: bool = True,
        high_pass_filter: bool = True,
        auto_gain_control: bool = True,
        stream_delay_ms: int = 50,
    ):
        super().__init__(
            sample_rate=sample_rate,
            block_ms=10,
            input_device=input_device,
            output_device=output_device,
            input_rms_threshold=input_rms_threshold,
            quiet_tail_ms=quiet_tail_ms,
            on_error=on_error,
        )
        self.enable_aec = enable_aec
        self.noise_suppression = noise_suppression
        self.high_pass_filter = high_pass_filter
        self.auto_gain_control = auto_gain_control
        self.stream_delay_ms = stream_delay_ms
        self._apm: Any = None
        self._frame_samples = max(1, int(self.sample_rate * self.block_ms / 1000))
        self._input_queue = queue.Queue(maxsize=100)
        self._output_queue = queue.Queue(maxsize=200)

    def start(self) -> None:
        _require_numpy()
        try:
            import sounddevice as sd
            from livekit import rtc
        except ImportError as exc:
            raise RuntimeError("LiveKit realtime audio requires the livekit and sounddevice packages.") from exc

        self._apm = rtc.AudioProcessingModule(
            echo_cancellation=self.enable_aec,
            noise_suppression=self.noise_suppression,
            high_pass_filter=self.high_pass_filter,
            auto_gain_control=self.auto_gain_control,
        )
        if self.enable_aec:
            try:
                self._apm.set_stream_delay_ms(self.stream_delay_ms)
            except Exception as exc:  # noqa: BLE001
                self._report(f"livekit apm stream delay setup failed: {exc}")

        self._input_stream = sd.InputStream(
            samplerate=self.sample_rate,
            channels=1,
            dtype="int16",
            blocksize=self._frame_samples,
            device=self.input_device,
            callback=self._on_input,
        )
        self._output_stream = sd.OutputStream(
            samplerate=self.sample_rate,
            channels=1,
            dtype="int16",
            blocksize=self._frame_samples,
            device=self.output_device,
            callback=self._on_output,
        )
        self._input_stream.start()
        self._output_stream.start()

    def stop(self) -> None:
        super().stop()
        self._apm = None

    def _on_input(self, indata, _frames: int, time_info: Any, status: Any) -> None:
        if status:
            self._report(str(status))
        if self._closed.is_set():
            return
        pcm16 = indata.copy().tobytes()
        processed = self._process_capture(pcm16, time_info)
        if not self._should_enqueue_pcm16(processed):
            return
        try:
            self._input_queue.put_nowait(processed)
        except queue.Full:
            self._report("livekit audio input queue full; dropping microphone chunk")

    def _process_capture(self, pcm16: bytes, time_info: Any) -> bytes:
        if self._apm is None:
            return pcm16
        self._update_stream_delay(time_info)
        frame = self._frame(pcm16)
        try:
            self._apm.process_stream(frame)
        except Exception as exc:  # noqa: BLE001
            self._report(f"livekit apm capture processing failed: {exc}")
            return pcm16
        return frame.data.tobytes()

    def _update_stream_delay(self, time_info: Any) -> None:
        if self._apm is None or not self.enable_aec:
            return
        try:
            delay_ms = int(max(float(time_info.currentTime - time_info.inputBufferAdcTime), 0.0) * 1000.0)
        except Exception:
            delay_ms = self.stream_delay_ms
        try:
            self._apm.set_stream_delay_ms(max(delay_ms, self.stream_delay_ms))
        except Exception:
            pass

    def _should_enqueue_pcm16(self, pcm16: bytes) -> bool:
        if self.input_rms_threshold <= 0:
            return True
        rms = _pcm16_rms(pcm16)
        if rms >= self.input_rms_threshold:
            self._input_active = True
            self._quiet_blocks = 0
            return True
        if not self._input_active:
            return False
        self._quiet_blocks += 1
        tail_blocks = max(1, int(self.quiet_tail_ms / self.block_ms))
        if self._quiet_blocks <= tail_blocks:
            return True
        self._input_active = False
        self._quiet_blocks = 0
        return False

    def _on_output(self, outdata, frames: int, _time: Any, status: Any) -> None:
        super()._on_output(outdata, frames, _time, status)
        self._process_reverse(bytes(outdata.tobytes()))

    def _process_reverse(self, pcm16: bytes) -> None:
        if self._apm is None or not self.enable_aec:
            return
        frame_bytes = self._frame_samples * 2
        for offset in range(0, len(pcm16) - frame_bytes + 1, frame_bytes):
            frame = self._frame(pcm16[offset:offset + frame_bytes])
            try:
                self._apm.process_reverse_stream(frame)
            except Exception as exc:  # noqa: BLE001
                self._report(f"livekit apm reverse processing failed: {exc}")
                return

    def _frame(self, pcm16: bytes) -> Any:
        from livekit import rtc

        expected = self._frame_samples * 2
        if len(pcm16) != expected:
            pcm16 = pcm16[:expected].ljust(expected, b"\x00")
        return rtc.AudioFrame(bytearray(pcm16), self.sample_rate, 1, self._frame_samples)
