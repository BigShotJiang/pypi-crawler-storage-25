from __future__ import annotations

from modict import modict

from ...command import command
from ...event import AssistantInterruptRequestedEvent
from ...plugin import Plugin, event_handler
from ...provider import provider
from ...tool import tool
from .manager import RealtimeManager


class RealtimePlugin(Plugin):
    name = "realtime"
    description = "Optional realtime voice mode with local audio capture/playback through Codex-authenticated Realtime WebSocket sessions."
    requires_openai = False
    prefix_tools = False
    config_defaults = modict(
        model="gpt-realtime-1.5",
        voice="marin",
        audio_backend="sounddevice",
        audio_enabled=True,
        sample_rate=24000,
        input_device=None,
        output_device=None,
        input_rms_threshold=0.0,
        quiet_tail_ms=1000,
        enable_aec=True,
        noise_suppression=True,
        high_pass_filter=True,
        auto_gain_control=True,
        stream_delay_ms=50,
        pause_input_during_output=False,
        close_after_response=False,
        stop_timeout=3.0,
        include_context=True,
        initial_context_messages=40,
        input_transcription_model="gpt-4o-mini-transcribe",
        tool_choice="auto",
        instructions="Keep realtime voice replies concise, natural, and easy to interrupt.",
        session_instructions="",
        voice_system_prompt="",
        audio_output_path=None,
    )
    system_prompt = """
Realtime voice mode may be available through the optional realtime plugin. When active, keep spoken replies concise, conversational, and interrupt-friendly. Use realtime_start, realtime_stop, and realtime_status only when explicitly asked or when managing the voice session state.
""".strip()

    def __init__(self, agent):
        super().__init__(agent)
        self.manager: RealtimeManager | None = None

    def start(self):
        self.manager = RealtimeManager(self.agent, self.config)
        return self

    def stop(self, timeout=None):
        if self.manager is not None:
            self.manager.stop(timeout=timeout)
        return self

    @property
    def realtime_manager(self) -> RealtimeManager:
        if self.manager is None:
            self.manager = RealtimeManager(self.agent, self.config)
        return self.manager

    @provider
    def realtime_status_monitor(self):
        """Expose current realtime voice status in the agent context."""
        status = self.realtime_manager.status()
        lines = [
            "Realtime voice status:",
            f"- state: {status.state}",
            f"- model: {status.model}",
            f"- voice: {status.voice}",
            f"- audio_backend: {status.audio_backend}",
        ]
        if status.last_error:
            lines.append(f"- last_error: {status.last_error}")
        return "\n".join(lines)

    @tool
    def realtime_status(self):
        """
        description: Return realtime voice session status.
        parameters: {}
        required: []
        """
        return self.realtime_manager.status()

    @tool
    def realtime_start(self, text: str = None, audio: bool = None, close_after_response: bool = None):
        """
        description: Start a realtime voice session. Optionally send an initial text prompt and/or disable local audio.
        parameters:
          text:
            type: string
            description: Optional initial text prompt sent to the realtime session.
          audio:
            type: boolean
            description: Whether to enable local microphone/speaker audio. Defaults to plugin config.
          close_after_response:
            type: boolean
            description: Whether to close after the first response completes. Defaults to plugin config.
        required: []
        """
        return self.realtime_manager.start(text=text, audio=audio, close_after_response=close_after_response)

    @tool
    def realtime_stop(self):
        """
        description: Stop the active realtime voice session, if any.
        parameters: {}
        required: []
        """
        return self.realtime_manager.stop()

    @command
    def realtime(self, action="status", *text_parts):
        """Control realtime voice: /realtime start|stop|status [optional text]."""
        text = " ".join(str(part) for part in text_parts) or None
        return self.realtime_manager.command(action=action, text=text)

    @event_handler(AssistantInterruptRequestedEvent)
    def stop_on_interrupt(self, event):
        if self.manager is not None:
            self.manager.stop(timeout=0.5, reason="interrupt")


__all__ = ["RealtimePlugin", "RealtimeManager"]
