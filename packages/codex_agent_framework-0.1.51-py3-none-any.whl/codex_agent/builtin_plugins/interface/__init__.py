"""Built-in local interface plugin."""

from ...plugin import Plugin
from ...provider import provider
from ...tool import tool
from ...tui import current_tui, open_tui_terminal, terminate_tui


class InterfacePlugin(Plugin):
    name = "interface"
    description = "Open and close the local TUI interface."
    prefix_tools = False

    @provider
    def tui_status(self):
        """Expose whether the local TUI client is currently open."""
        tui = current_tui()
        if not tui:
            return "TUI status: closed."
        return (
            "TUI status: open. "
            f"pid={tui.get('pid')} "
            f"base_url={tui.get('base_url')} "
            f"timestamp={tui.get('timestamp')}"
        )

    @tool(name="open_tui")
    def open_tui(self):
        """
        description: Open the Textual chat TUI client in a separate terminal connected to the local agent server.
        parameters: {}
        required: []
        """
        tui = current_tui()
        if tui:
            return {"status": "already_open", "tui": tui}
        process = open_tui_terminal(base_url=self.agent.config.get("server_url", "http://127.0.0.1:8765"))
        if process is None:
            raise RuntimeError("No supported terminal emulator found to open the TUI")
        return {"status": "opened", "pid": process.pid}

    @tool(name="close_tui")
    def close_tui(self):
        """
        description: Close the currently registered Textual chat TUI client process.
        parameters: {}
        required: []
        """
        tui = current_tui()
        if not tui:
            return {"status": "not_open"}
        terminate_tui(tui.pid)
        return {"status": "closed", "tui": tui}
