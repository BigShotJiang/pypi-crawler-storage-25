"""Subagents plugin: delegate focused tasks to ephemeral child agents."""

import json
import os
from pathlib import Path

from modict import modict

from ...event import SubagentEvent
from ...plugin import Plugin
from ...tool import tool


class SubagentResult(modict):
    _config = modict.config(require_all="never")

    type = "subagent_result"
    profile = ""
    name = ""
    task = ""
    status = ""
    result = None
    error = None


class SubagentsPlugin(Plugin):
    name = "subagents"
    description = "Delegate focused tasks to ephemeral child agents with their own config and plugins."
    profiles_dir = Path(__file__).parent / "profiles"
    system_prompt = """
# Subagents

Use `subagents_run` to delegate a focused task to a subagent profile with its own predefined config, tools and plugins.
Choose one of the available profiles and provide a focused task. The child agent receives its own `set_result` tool to provide a structured result. The parent receives that result and should report it back clearly.
"""
    child_system_prompt = """
You are a focused subagent running inside a parent agent.

Fundamentals:
- Work only on the delegated task.
- Use your available tools autonomously when useful.
- You may perform multiple reasoning/tool steps before finishing.
- Keep your work scoped to your role and available capabilities.
- When the task is complete, call the local `set_result` tool with the result to return to the parent agent.
- Do not ask the user for follow-up; report uncertainty or missing inputs in the structured result instead.
"""

    def __init__(self, agent):
        super().__init__(agent)
        self.profiles = modict()
        self.load_profiles()

    def load_profiles(self):
        profiles_dir = Path(self.profiles_dir)
        if not profiles_dir.is_dir():
            return self.profiles
        for path in sorted(profiles_dir.glob("*.json")):
            self.load_profile_file(path)
        return self.profiles

    def load_profile_file(self, path):
        with open(path, encoding="utf-8") as f:
            profile = json.load(f)
        if not isinstance(profile, dict):
            raise ValueError(f"Invalid subagent profile {path}: expected JSON object")
        profile_name = profile.pop("id", None) or path.stem
        self.register_profile(profile_name, **profile)
        return profile_name

    def register_profile(self, profile_name, **profile):
        self.profiles[profile_name] = modict(profile)
        return self.profiles[profile_name]

    def get_system_prompt_sections(self):
        if not self.profiles:
            return [self.system_prompt.strip() + "\n\nNo subagent profiles are currently available."]
        lines = [self.system_prompt.strip(), "", "Available subagent profiles:"]
        for name, profile in self.profiles.items():
            description = profile.get("description", "No description provided.")
            lines.append(f"- `{name}`: {description}")
        return ["\n".join(lines)]

    def profile(self, name):
        if not name:
            raise ValueError("A subagent profile is required")
        if name not in self.profiles:
            raise ValueError(f"Unknown subagent profile: {name}")
        return modict(self.profiles[name])

    def profile_system_prompt(self, profile):
        sections = [self.child_system_prompt.strip()]
        structured = []
        for key, title in (
            ("role", "Role"),
            ("goal", "Goal"),
            ("means", "Means"),
            ("objective", "Objective"),
        ):
            value = profile.get(key)
            if value:
                structured.append(f"## {title}\n{value}")
        if structured:
            sections.append("\n\n".join(structured))
        if profile.get("system_prompt"):
            sections.append(str(profile.system_prompt).strip())
        return "\n\n".join(section for section in sections if section)

    def child_config(self, profile):
        data = modict(profile)
        config = modict(data.pop("config", {}) or {})

        for key in ("name", "builtin_plugins", "custom_plugins", "exclude_tools", "model", "reasoning_effort", "verbosity"):
            if key in data:
                config[key] = data[key]

        config.system = self.profile_system_prompt(data)
        config.setdefault("name", data.get("name") or f"{self.agent.config.name} subagent")
        config.setdefault("username", self.agent.config.get("username"))
        config.setdefault("userage", self.agent.config.get("userage"))
        config.setdefault("openai_api_key", self.agent.config.get("openai_api_key"))
        config.setdefault("builtin_plugins", [])
        config.setdefault("custom_plugins", [])
        config.setdefault("exclude_tools", [])
        return config

    def relay_child_event(self, subagent, child, event):
        self.agent.emit(SubagentEvent(
            subagent=subagent,
            event=event,
            session_id=getattr(child, "current_session_id", ""),
        ))
        return event

    def install_child_tools(self, child):
        def set_result(data):
            """
            description: |
                Set some data as this turn's result and finish the turn after the current step.
                data can be a string (for reporting) or any json-serializable structured data.
                The result will be accessible by the caller (user or other Agent) as `AgentTurn.result`
                Use this when your task is complete and you need to return a final result to the caller.
            parameters:
                data:
                    description: text or JSON data to return as result for the current subagent turn.
            required:
                - data
            """
            child.set_turn_result(data)
            return "Subagent result set."

        child.add_tool(set_result, name="set_result")
        return child

    def cleanup_session(self, child):
        session = getattr(child, "session", None)
        if session is None:
            return
        for path in (session.session_file, session.api_success_backup_file):
            if path and os.path.exists(path):
                os.remove(path)

    def create_child(self, profile_data):
        from ...agent import Agent

        child = Agent(session="new", **self.child_config(profile_data))
        if "tts" in child.plugins:
            child.plugins.tts.config.enabled = False
        self.install_child_tools(child)
        return child

    def run_subagent(self, profile, task):
        child = None
        profile_data = None
        try:
            profile_data = self.profile(profile)
            child = self.create_child(profile_data)
            child.on("*", lambda event: self.relay_child_event(profile, child, event))
            prompt = (
                f"{task}\n\n"
                "When the delegated task is complete, call the `set_result` tool with the structured result to return to the parent agent."
            )
            turn = child(prompt)
            return SubagentResult(
                profile=profile,
                name=child.config.name,
                task=task,
                status=turn.status,
                result=turn.result,
            )
        except Exception as exc:
            return SubagentResult(
                profile=profile,
                name=(profile_data or {}).get("name", profile),
                task=task,
                status="error",
                error=str(exc),
            )
        finally:
            if child is not None:
                child.stop(timeout=1.0)
                if not (profile_data or {}).get("keep_session", False):
                    self.cleanup_session(child)

    @tool(name="run")
    def run(self, profile: str, task: str):
        """
        description: |
            Run a focused task in an ephemeral child agent selected from predefined profiles.
            The calling agent must only choose an existing profile and provide the specific task.
            The child agent receives a local `set_result` tool to return structured data to the parent.
        parameters:
            profile:
                description: Registered subagent profile to use.
                type: string
            task:
                description: Specific task prompt to give to the selected subagent profile.
                type: string
        required:
            - profile
            - task
        """
        return self.run_subagent(profile=profile, task=task)
