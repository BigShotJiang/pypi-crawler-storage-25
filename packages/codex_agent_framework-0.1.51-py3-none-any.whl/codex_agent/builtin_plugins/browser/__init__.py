"""Browser plugin: persistent Chromium tools and active-tab context."""

from ...image import ImageMessage
from ...plugin import Plugin
from ...provider import provider
from ...tool import tool
from ...utils import runtime_join
from ...browser import BrowserError, get_browser_controller


def _format_browser_status(status: dict) -> str:
    if not status.get("open"):
        return "Browser closed."
    lines = ["Browser open."]
    if status.get("profile_dir"):
        lines.append(f"Profile: {status['profile_dir']}")
    tabs = status.get("tabs") or []
    if tabs:
        lines.append("Tabs:")
        for tab in tabs:
            marker = "*" if tab.get("active") else " "
            title = tab.get("title") or "(untitled)"
            url = tab.get("url") or ""
            lines.append(f"  {marker} [{tab.get('index')}] {title} :: {url}")
    else:
        lines.append("No open tabs.")
    return "\n".join(lines)


class BrowserPlugin(Plugin):
    name = "browser"
    description = "Persistent Chromium browser tools and active-tab context provider."
    system_prompt = """
# Browser

Use browser tools for interactive web pages, logged-in sessions, and workflows that require navigation, clicks, forms, or keyboard input in Chromium.
When the browser is open, the browser_state provider gives the current active tab snapshot and screenshot; treat that provider context as the source of truth.
Use the element ids from the latest browser_state snapshot with browser_click, browser_fill, browser_select, and browser_press.
Prefer browser_goto to navigate the current tab, browser_open when you need to start the browser or open a new tab, and browser_select_tab when the user explicitly wants another tab.
"""

    @property
    def controller(self):
        return get_browser_controller()

    def tool_result(self, call):
        try:
            return call()
        except BrowserError as exc:
            return f"Browser error: {exc}"

    @tool
    def open(self, url: str = None, headless: bool = False, profile_name: str = "default", new_tab: bool = None):
        """
        description: |
            Open the persistent Playwright/Chromium browser. If the browser is closed, this starts it.
            If the browser is already open, this opens a new tab by default. Optionally navigate to a URL.
        parameters:
            url:
                description: Optional URL to open in the active/new tab.
                type: string
            headless:
                description: Whether to start Chromium headless when opening a new browser session.
                type: boolean
            profile_name:
                description: Persistent browser profile name stored under runtime/browser/<profile_name>.
                type: string
            new_tab:
                description: Force opening a new tab. Defaults to true when browser is already open, false for a fresh session.
                type: boolean
        """
        return self.tool_result(lambda: _format_browser_status(self.controller.open(url=url, headless=headless, profile_name=profile_name, new_tab=new_tab)))

    @tool
    def close(self):
        """
        description: Close the persistent Playwright/Chromium browser session.
        """
        return self.tool_result(lambda: self.controller.close())

    @tool
    def select_tab(self, index: int):
        """
        description: Select an open browser tab by zero-based index.
        parameters:
            index:
                description: Zero-based tab index. Negative indexes count from the end.
                type: integer
        required:
            - index
        """
        return self.tool_result(lambda: _format_browser_status(self.controller.select_tab(index)))

    @tool
    def previous_page(self):
        """
        description: Navigate the active browser tab back in history.
        """
        return self.tool_result(lambda: self.controller.previous_page())

    @tool
    def goto(self, url: str):
        """
        description: Navigate the active browser tab to a URL, without opening or switching tabs.
        parameters:
            url:
                description: URL to load in the active browser tab.
                type: string
        required:
            - url
        """
        return self.tool_result(lambda: self.controller.goto(url))

    def snapshot(self, max_elements: int = 120, include_json: bool = False):
        """
        description: |
            Return a compact, action-oriented snapshot of the active web browser page.
            Snapshot IDs can be used with browser_click, browser_fill, browser_select, and browser_press.
        parameters:
            max_elements:
                description: Maximum number of useful visible elements to include.
                type: integer
            include_json:
                description: Include structured JSON snapshot data after the readable snapshot.
                type: boolean
        """
        return self.tool_result(lambda: self.controller.snapshot(max_elements=max_elements, include_json=include_json))

    @tool
    def click(self, element_id: str):
        """
        description: Click an element from the latest browser provider snapshot by ID.
        parameters:
            element_id:
                description: Element ID shown in the browser provider snapshot, e.g. "12".
                type: string
        required:
            - element_id
        """
        return self.tool_result(lambda: self.controller.click(element_id))

    @tool
    def fill(self, element_id: str, text: str):
        """
        description: Fill an input/textarea/contenteditable element from the latest browser provider snapshot by ID.
        parameters:
            element_id:
                description: Element ID shown in the browser provider snapshot.
                type: string
            text:
                description: Text to enter.
                type: string
        required:
            - element_id
            - text
        """
        return self.tool_result(lambda: self.controller.fill(element_id, text))

    @tool
    def select(self, element_id: str, value):
        """
        description: Select an option value on a select element from the latest browser provider snapshot by ID.
        parameters:
            element_id:
                description: Element ID shown in the browser provider snapshot.
                type: string
            value:
                description: Option value, or list of values for multi-select.
        required:
            - element_id
            - value
        """
        return self.tool_result(lambda: self.controller.select(element_id, value))

    @tool
    def press(self, key: str, element_id: str = None):
        """
        description: Press a keyboard key globally or on a browser provider snapshot element ID.
        parameters:
            key:
                description: Playwright key name, e.g. Enter, Escape, Tab.
                type: string
            element_id:
                description: Optional element ID shown in the browser provider snapshot.
                type: string
        required:
            - key
        """
        return self.tool_result(lambda: self.controller.press(key, element_id=element_id))

    @provider
    def browser_state(self):
        """Expose the active browser tab as ephemeral context when Chromium is open."""
        if not self.controller.is_open:
            return None

        try:
            snapshot = self.controller.snapshot(max_elements=80, include_json=False)
        except BrowserError:
            return None
        except Exception as exc:
            return f"Active browser state is unavailable: {exc}"

        messages = [snapshot]
        screenshot_path = runtime_join("browser", "screenshots", "active_tab.png")
        try:
            saved_path = self.controller.screenshot(screenshot_path, full_page=False)
        except Exception as exc:
            messages.append(f"Active browser screenshot is unavailable: {exc}")
        else:
            messages.append(ImageMessage(
                content=saved_path,
                description="Fresh screenshot of the active browser tab.",
                image_name="active_browser_tab.png",
            ))
        return messages
