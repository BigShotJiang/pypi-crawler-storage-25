"""Scheduler plugin: scheduled wakeup tools."""

from ...plugin import Plugin
from ...tool import tool


class SchedulerPlugin(Plugin):
    name = "scheduler"
    description = "Scheduled wakeup and post-restart continuation tools."
    system_prompt = """
# Scheduler

Use scheduler tools when the user asks you to wake up later, resume work at a specific time, repeat a task, or continue after a server restart.
Scheduled wakeups submit a future user turn with the prompt you provide, so write wakeup prompts with enough context to resume safely.
Use scheduler_list and scheduler_cancel when the user asks about pending scheduled work or wants to change it.
Use scheduler_restart_and_wakeup after changes that require the local server to reload and the agent should continue automatically after restart.
"""

    def schedule(self, prompt, run_at=None, delay_seconds=None, interval_seconds=None, title=""):
        return self.agent.schedule_wakeup(
            prompt=prompt,
            run_at=run_at,
            delay_seconds=delay_seconds,
            interval_seconds=interval_seconds,
            title=title,
        )

    def cancel(self, job_id):
        return self.agent.cancel_wakeup(job_id)

    def delete(self, job_id):
        return self.agent.delete_wakeup(job_id)

    def list(self, include_done=True):
        return self.agent.list_wakeups(include_done=include_done)

    @tool(name="schedule")
    def schedule_wakeup(self, prompt: str, run_at: str = None, delay_seconds: float = None, interval_seconds: float = None, title: str = ""):
        """
        description: |
            Schedule an automatic agent wakeup. At the due time, the agent runtime will submit a new turn with the provided prompt.
            Use delay_seconds for relative wakeups, run_at for ISO datetimes, and interval_seconds for periodic wakeups.
        parameters:
            prompt:
                description: Prompt to send to the agent when the wakeup triggers.
                type: string
            run_at:
                description: Optional ISO datetime, e.g. 2026-05-04T09:00:00+02:00.
                type: string
            delay_seconds:
                description: Optional relative delay in seconds.
                type: number
            interval_seconds:
                description: Optional positive interval in seconds for periodic wakeups.
                type: number
            title:
                description: Optional human-readable title.
                type: string
        required:
            - prompt
        """
        job = self.schedule(
            prompt=prompt,
            run_at=run_at,
            delay_seconds=delay_seconds,
            interval_seconds=interval_seconds,
            title=title,
        )
        return f"Scheduled wakeup {job.id} at {job.run_at}: {job.title}"

    @tool(name="cancel")
    def cancel_wakeup(self, job_id: str):
        """
        description: Cancel a scheduled wakeup by id.
        parameters:
            job_id:
                description: Wakeup job id.
                type: string
        required:
            - job_id
        """
        job = self.cancel(job_id)
        if job is None:
            return f"Wakeup not found: {job_id}"
        return f"Cancelled wakeup {job.id}: {job.title}"

    @tool(name="list")
    def list_wakeups(self, include_done: bool = True):
        """
        description: List scheduled wakeups.
        parameters:
            include_done:
                description: Include completed and cancelled wakeups.
                type: boolean
        """
        jobs = self.list(include_done=include_done)
        if not jobs:
            return "No scheduled wakeups."
        return "\n".join(
            f"- {job.id} [{job.status}] {job.run_at} :: {job.title}"
            for job in jobs
        )

    @tool(name="restart_and_wakeup")
    def restart_server_and_wakeup(self, prompt: str, title: str = "post-restart wakeup"):
        """
        description: |
            Persist a wakeup request, then ask the local agent server service to restart.
            On the next server startup, the persisted request is consumed and submitted as a new agent turn.
            Use this after code updates when the server must reload the new code and the agent should continue autonomously.
        parameters:
            prompt:
                description: Prompt to wake the agent with after the service restart.
                type: string
            title:
                description: Optional human-readable title for the persisted post-restart wakeup.
                type: string
        required:
            - prompt
        """
        self.agent.mainloop_manager.stop_loop_after_current_step()
        result = self.agent.runtime.restart_server(prompt=prompt, title=title)
        if result.get("restarting"):
            return f"Server restart requested. Post-restart wakeup persisted: {bool(result.get('wakeup_persisted'))}."
        return f"Server restart not requested: {result}"
