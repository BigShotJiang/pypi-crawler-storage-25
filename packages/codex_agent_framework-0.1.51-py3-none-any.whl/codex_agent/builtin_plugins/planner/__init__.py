"""Planner plugin: persistent named todo tracking."""

import json
import os
from xml.sax.saxutils import escape, quoteattr

from modict import modict

from ...plugin import Plugin
from ...provider import provider
from ...tool import tool
from ...utils import atomic_write_json, runtime_join


class TodoEntry(modict):
    _config = modict.config(enforce_json=True, require_all="never")

    title = ""
    description = ""
    done_state = False


class Todo(modict):
    _config = modict.config(enforce_json=True, require_all="never")

    name = ""
    entries = modict.factory(list)


class PlannerPlugin(Plugin):
    name = "planner"
    description = "Persistent named todo tracking tools and current-todos context provider."
    system_prompt = """
# Planner

Use the planner tools to organize and keep track of work that benefits from explicit named todo lists.
Create a named todo with concise entries before starting substantial work, add entries to an existing unfinished todo when the scope grows, and check entries as done when they are actually completed.
Active todos appear in context while they have unfinished entries. A todo is cleared automatically when all of its entries are done, without affecting other active todos.
"""

    def __init__(self, agent):
        super().__init__(agent)
        self.file = runtime_join("planner.json")
        self.todos = modict()
        self.load()

    def load(self):
        if not os.path.isfile(self.file):
            self.todos = modict()
            return self
        with open(self.file, "r", encoding="utf-8") as f:
            data = json.load(f)
        self.todos = self.normalize_todos(data)
        self.active_todos()
        return self

    def save(self):
        data = modict(type="planner", todos=list(self.todos.values()))
        atomic_write_json(self.file, data)
        return self

    def normalize_todos(self, data):
        raw_todos = data.get("todos", []) if isinstance(data, dict) else []
        if isinstance(raw_todos, dict):
            raw_todos = [
                modict(name=name, entries=entries)
                for name, entries in raw_todos.items()
            ]
        todos = modict()
        for todo in raw_todos:
            todo = self.normalize_todo(todo)
            todos[todo.name] = todo
        return todos

    def normalize_todo(self, todo):
        if not isinstance(todo, dict):
            raise ValueError("each todo must be an object.")
        name = self.normalize_name(todo.get("name"))
        entries = todo.get("entries") or []
        return Todo(name=name, entries=[self.normalize_entry(entry) for entry in entries])

    def normalize_name(self, name):
        name = str(name or "").strip()
        if not name:
            raise ValueError("todo name is required.")
        return name

    def normalize_entry(self, entry):
        if not isinstance(entry, dict):
            raise ValueError("each entry must be an object.")
        title = str(entry.get("title") or "").strip()
        if not title:
            raise ValueError("each entry must have a title.")
        return TodoEntry(
            title=title,
            description=str(entry.get("description") or "").strip(),
            done_state=bool(entry.get("done_state", False)),
        )

    def active_todos(self):
        completed = [
            name for name, todo in self.todos.items()
            if todo.entries and all(entry.done_state for entry in todo.entries)
        ]
        for name in completed:
            self.todos.pop(name, None)
        return self.todos

    @provider
    def current_todos(self):
        todos = self.active_todos()
        if not todos:
            return None

        lines = ["<current_todos>"]
        for todo in todos.values():
            lines.append(f"  <todo name={quoteattr(str(todo.name))}>")
            for index, entry in enumerate(todo.entries, start=1):
                done_state = "done" if entry.done_state else "pending"
                lines.append(
                    f"    <entry index={quoteattr(str(index))} done_state={quoteattr(done_state)} "
                    f"title={quoteattr(str(entry.title))}>"
                )
                if entry.description:
                    lines.append(f"      {escape(str(entry.description))}")
                lines.append("    </entry>")
            lines.append("  </todo>")
        lines.append("</current_todos>")
        return "\n".join(lines)

    @tool
    def create(self, name: str, entries: list[dict]):
        """
        description: |
            Create or replace one named todo list.
            Each entry object should contain: title, description, and optional done_state.
            If all entries are already done, the todo is immediately cleared.
        parameters:
            name:
                description: Todo name.
                type: string
            entries:
                description: Ordered list of todo entry objects.
                type: array
                items:
                    type: object
                    properties:
                        title:
                            type: string
                            description: Short entry title.
                        description:
                            type: string
                            description: Brief entry description.
                        done_state:
                            type: boolean
                            description: Whether this entry is already done. Defaults to false.
        required:
            - name
            - entries
        """
        name = self.normalize_name(name)
        entries = self.normalize_entries(entries)
        self.todos[name] = Todo(name=name, entries=entries)
        self.active_todos()
        self.save()
        return self.todo_status(name)

    @tool
    def add(self, name: str, entries: list[dict]):
        """
        description: Add entries to an existing unfinished named todo.
        parameters:
            name:
                description: Existing todo name.
                type: string
            entries:
                description: Entries to append to the todo.
                type: array
                items:
                    type: object
        required:
            - name
            - entries
        """
        name = self.normalize_name(name)
        self.active_todos()
        todo = self.todos.get(name)
        if not todo:
            return f"Todo not found or already complete: {name}"
        todo.entries.extend(self.normalize_entries(entries))
        self.active_todos()
        self.save()
        return self.todo_status(name)

    @tool
    def check(self, name: str, entries: list[int]):
        """
        description: |
            Mark one or several entries of a named todo as done by 1-based index.
            If all entries become done, only that todo is cleared automatically.
        parameters:
            name:
                description: Todo name.
                type: string
            entries:
                description: One-based indexes of entries to mark as done.
                type: array
                items:
                    type: integer
        required:
            - name
            - entries
        """
        name = self.normalize_name(name)
        if isinstance(entries, int):
            entries = [entries]
        if not isinstance(entries, list) or not entries:
            raise ValueError("entries must be a non-empty list of indexes.")
        self.active_todos()
        todo = self.todos.get(name)
        if not todo:
            return f"Todo not found or already complete: {name}"

        indexes = []
        for index in entries:
            index = int(index)
            if index < 1 or index > len(todo.entries):
                raise ValueError(f"Unknown todo entry index for {name}: {index}")
            indexes.append(index)

        for index in indexes:
            todo.entries[index - 1].done_state = True
        self.active_todos()
        self.save()
        return self.todo_status(name)

    @tool
    def clear(self, name: str = ""):
        """
        description: Clear one named todo, or all todos when name is omitted.
        parameters:
            name:
                description: Optional todo name to clear. Omit to clear every todo.
                type: string
        """
        name = str(name or "").strip()
        if name:
            existed = self.todos.pop(name, None) is not None
            self.save()
            return f"Todo cleared: {name}" if existed else f"Todo not found: {name}"
        self.todos = modict()
        self.save()
        return "All todos cleared."

    def normalize_entries(self, entries):
        if not isinstance(entries, list) or not entries:
            raise ValueError("entries must be a non-empty list.")
        return [self.normalize_entry(entry) for entry in entries]

    def todo_status(self, name):
        todo = self.todos.get(name)
        if not todo:
            return f"Todo complete. Cleared todo: {name}"
        done = sum(1 for entry in todo.entries if entry.done_state)
        remaining = len(todo.entries) - done
        return f"Todo {name!r} has {len(todo.entries)} entry(s), {done} done and {remaining} remaining."
