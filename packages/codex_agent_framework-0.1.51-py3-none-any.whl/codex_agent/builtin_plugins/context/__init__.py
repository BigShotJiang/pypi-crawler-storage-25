"""Built-in live context management plugin."""

from modict import modict

from ...message import ToolResultWrapper
from ...plugin import Plugin
from ...provider import provider
from ...tool import tool


class ContextPlugin(Plugin):
    name = "context"
    description = "Live context window status, compaction, and selective temporary wrapper pruning."
    system_prompt = """
# Context Management

Use context tools to inspect and manage you own active working context during long tasks.
Tool result wrappers expose stable `wrapper_id` values in their XML representation; use `context_list_wrappers` and `context_prune_wrappers` to remove bulky temporary tool outputs once you have extracted what you need.
"""

    def context_public_status(self):
        status = self.agent.status_manager.context_status()
        return modict(
            used_tokens=status.used_tokens,
            input_token_limit=status.input_token_limit,
            percent=round(float(status.percent or 0), 2),
            fixed_tokens=status.get("fixed_tokens", 0),
            tool_spec_tokens=status.get("tool_spec_tokens", 0),
            token_count_source=status.get("token_count_source"),
            sent_session_messages=status.sent_session_messages,
            total_session_messages=status.total_session_messages,
            visible_history_messages=status.get("visible_history_messages", 0),
            total_history_messages=status.get("total_history_messages", 0),
            persistent_session_messages=status.get("persistent_session_messages", 0),
            temporary_session_messages=status.get("temporary_session_messages", 0),
            active_wrapper_messages=status.get("active_wrapper_messages", 0),
            vanished_wrapper_messages=status.get("vanished_wrapper_messages", 0),
            total_wrapper_messages=status.get("total_wrapper_messages", 0),
            base_context_tokens=status.get("base_context_tokens", status.used_tokens),
            active_wrapper_tokens=status.get("active_wrapper_tokens", 0),
            vanished_wrapper_tokens=status.get("vanished_wrapper_tokens", 0),
            compactable_turns=status.get("compactable_turns", 0),
            compactable_messages=status.get("compactable_messages", 0),
            compactable_tokens=status.get("compactable_tokens", 0),
            context_session_messages=status.get("context_session_messages", 0),
            image_messages=status.get("image_messages", 0),
            pending_messages=status.get("pending_messages", 0),
            auto_compact=status.get("auto_compact", True),
            auto_compact_threshold=status.get("auto_compact_threshold", 0),
            session_id=status.get("session_id"),
        )

    @provider
    def context_status_monitor(self):
        """Expose compact live context/window status to the agent."""
        status = self.context_public_status()
        return "\n".join([
            "Context status:",
            f"- tokens: {status.used_tokens}/{status.input_token_limit} ({status.percent:.2f}%)",
            f"- token split base/active_wrappers/vanished_wrappers: {status.base_context_tokens}/{status.active_wrapper_tokens}/{status.vanished_wrapper_tokens}",
            f"- messages sent/total: {status.sent_session_messages}/{status.total_session_messages}",
            f"- persistent/temporary context messages: {status.persistent_session_messages}/{status.temporary_session_messages}",
            f"- wrappers active/vanished/total: {status.active_wrapper_messages}/{status.vanished_wrapper_messages}/{status.total_wrapper_messages}",
            f"- compactable turns/messages/tokens: {status.compactable_turns}/{status.compactable_messages}/{status.compactable_tokens}",
            f"- visible/total history messages: {status.visible_history_messages}/{status.total_history_messages}",
            f"- tool spec tokens: {status.tool_spec_tokens}",
            f"- auto_compact: {status.auto_compact} threshold={status.auto_compact_threshold}",
            "Context tools: context_status, context_compact, context_list_wrappers, context_prune_wrappers.",
        ])

    @tool
    def status(self):
        """
        description: Return live context window, message, temporary wrapper, and activity status.
        parameters: {}
        required: []
        """
        return self.context_public_status()

    def decay_context_messages(self, wrappers_only=True, steps=1):
        if not self.agent.session:
            return modict(decayed=0, expired=0, skipped=0)
        steps = max(1, int(steps or 1))
        decayed = 0
        expired = 0
        skipped = 0
        for message in self.agent.session.messages:
            turns_left = message.get("turns_left", -1)
            if not isinstance(turns_left, int) or turns_left <= 0:
                skipped += 1
                continue
            if wrappers_only and not isinstance(message, ToolResultWrapper):
                skipped += 1
                continue
            new_value = max(0, turns_left - steps)
            if new_value != turns_left:
                message.turns_left = new_value
                decayed += 1
                if new_value == 0:
                    expired += 1
        if decayed:
            self.agent.status_manager.invalidate_context_cache()
            self.agent.save_session()
        return modict(decayed=decayed, expired=expired, skipped=skipped, steps=steps, wrappers_only=wrappers_only)

    @tool
    def compact(self, max_compacted_turns: int = None):
        """
        description: Compact the current session context using the backend compaction mechanism (replaces the leading turns of the session by a compaction summary).
        parameters:
          max_compacted_turns:
            type: integer
            description: Optional number of oldest completed turns to compact. Omit/null to compact all eligible completed turns.
        required: []
        """
        if max_compacted_turns is not None:
            max_compacted_turns = int(max_compacted_turns)
        before = self.context_public_status()
        message = self.agent.compact_session(
            model=self.agent.config.model,
            instructions=self.agent.config_manager.system_message().content,
            max_compacted_turns=max_compacted_turns,
        )
        after = self.context_public_status()
        if message is None:
            return {"status": "noop", "message": "Nothing to compact.", "before": before, "after": after}
        if message.get("status") == "failed":
            return {
                "status": "failed",
                "error": message.error,
                "reason": message.reason,
                "before": before,
                "after": after,
            }
        return {
            "status": "compacted",
            "compacted_message_count": message.compacted_message_count,
            "compacted_turns": max_compacted_turns,
            "before": before,
            "after": after,
        }

    def wrapper_info(self, message):
        content = str(message.get("content") or "")
        preview = content.replace("\n", "\\n")[:80]
        return modict(
            wrapper_id=message.id,
            call_id=message.get("call_id", ""),
            tool_name=message.get("tool_name", ""),
            status=message.get("status", ""),
            turns_left=message.get("turns_left"),
            timestamp=message.get("timestamp"),
            content_length=len(content),
            content_preview=preview,
        )

    @tool
    def list_wrappers(self):
        """
        description: List current ToolResultWrapper messages in the session, including stable wrapper ids for selective pruning.
        parameters: {}
        required: []
        """
        messages = self.agent.session.messages if self.agent.session else []
        wrappers = [self.wrapper_info(message) for message in messages if isinstance(message, ToolResultWrapper)]
        return modict(count=len(wrappers), wrappers=wrappers)

    @tool
    def prune_wrappers(self, wrapper_ids):
        """
        description: Hide selected ToolResultWrapper messages from the active context by setting turns_left to 0, without deleting session history.
        parameters:
          wrapper_ids:
            description: One wrapper id string, or a list of wrapper id strings to hide from context.
        required: [wrapper_ids]
        """
        if not self.agent.session:
            return modict(status="noop", requested=[], pruned=0, missing=[])
        if isinstance(wrapper_ids, str):
            requested = [wrapper_ids]
        else:
            requested = [str(wrapper_id) for wrapper_id in (wrapper_ids or [])]
        requested_set = set(requested)
        pruned = []
        matched_ids = set()
        for message in self.agent.session.messages:
            if isinstance(message, ToolResultWrapper) and message.id in requested_set:
                matched_ids.add(message.id)
                if message.get("turns_left", -1) != 0:
                    message.turns_left = 0
                    pruned.append(message)
        if pruned:
            self.agent.status_manager.invalidate_context_cache()
            self.agent.save_session()
        missing = [wrapper_id for wrapper_id in requested if wrapper_id not in matched_ids]
        return modict(
            status="pruned" if pruned else ("already_pruned" if matched_ids else "not_found"),
            requested=requested,
            pruned=len(pruned),
            missing=missing,
            wrappers=[self.wrapper_info(message) for message in pruned],
        )
