import os
from collections.abc import Mapping

from ...tool import get_agent, tool
from ...utils import read_document_content, view_document_content

@tool
def read(reads):
    """
    description: |
        Read one or more local UTF-8 text files or folders as source-of-truth content.
        File reads always prefix returned content with reliable source line numbers.
        Folder reads without `pattern` render a compact tree with one level of recursion.
        Folder reads with `pattern` recursively search UTF-8 files under the folder and return numbered snippets per matching file.
        This tool does not extract document formats, fetch URLs, or inspect Python objects; use `view` for URLs, PDFs, DOCX, ODT, HTML, XLSX, archives, and other extracted or transformed content.

        For large outputs: the output is automatically truncated. When truncated, a message indicates the omitted line range.
        When `pattern` is provided, it is treated as a Python regex by default and all matches are returned as separated numbered snippets with up to 10 lines before and after each match.
        Pass either a single read object or a list of read objects. Each read object contains the parameters below.
    parameters:
        reads:
            description: |
                A single read object or a list of read objects.
                Each object must contain `source` and may contain `start_at_line`, `end_at_line`, `pattern`, and `regex`.
            anyOf:
                - type: object
                  properties:
                    source:
                        description: Local UTF-8 text file or folder path. Folders are listed as a compact tree, or searched recursively when pattern is provided. For URLs, rich documents, archives, or Python objects, use `view` instead.
                        type: string
                    start_at_line:
                        description: Line number to start reading from (1-indexed). Default is 1 (start from beginning).
                        type: integer
                    end_at_line:
                        description: Optional inclusive line number to stop reading at for direct file reads.
                        type: integer
                    pattern:
                        description: Optional search pattern. Treated as a Python regular expression by default.
                        type: string
                    regex:
                        description: Whether to treat `pattern` as a Python regular expression. Default true. Set false for literal substring search.
                        type: boolean
                  required:
                    - source
                - type: array
                  items:
                    type: object
                    properties:
                        source:
                            description: Local UTF-8 text file or folder path. Folders are listed as a compact tree, or searched recursively when pattern is provided.
                            type: string
                        start_at_line:
                            type: integer
                        end_at_line:
                            type: integer
                        pattern:
                            type: string
                        regex:
                            type: boolean
                    required:
                        - source
    required:
        - reads
    """
    if isinstance(reads, Mapping):
        read_items = [reads]
    elif isinstance(reads, list):
        read_items = reads
    else:
        return "Failed: reads must be an object or a list of objects."

    return [apply_file_read(item) for item in read_items]


def apply_file_read(item):
    if not isinstance(item, Mapping):
        return "failed: read must be an object."

    source = item.get("source")
    if not source:
        return "failed: source must not be empty."

    agent = get_agent()
    source_path = source if str(source).startswith(("http://", "https://")) else agent.resolve_path(source)
    max_tokens = agent.config.get('max_input_tokens', 8000)
    try:
        return read_document_content(
            source_path,
            start_at_line=item.get("start_at_line", 1),
            end_at_line=item.get("end_at_line"),
            max_tokens=max_tokens,
            pattern=item.get("pattern"),
            regex=item.get("regex", True),
        )
    except Exception as exc:
        return f"failed to read file {source}: {exc}"


@tool
def view(source, start_at_line: int = 1, search_query: str = None):
    """
    description: |
        View/extract text content from varied sources using the document extraction pipeline.
        Use this for folders, URLs, PDFs, DOCX, ODT, HTML, XLSX, archives, and Python objects.
        This is a convenience extraction view, not a strict source-of-truth file reader; use `read` for local UTF-8 files that must be read faithfully before editing.

        `view` never prefixes line numbers, including search result snippets, because extracted line structure is not reliable.
        For large outputs: the output is automatically truncated.
    parameters:
        source:
            description: |
                Source to view/extract: local folder or file, URL, or Python object/variable.
        start_at_line:
            description: |
                Line number to start viewing from (1-indexed). Pagination only; line numbers are not rendered.
            type: integer
        search_query:
            description: |
                Optional literal text query for simple search within the extracted content. Results are returned as unnumbered snippets.
            type: string
    required:
        - source
    """
    agent = get_agent()
    if isinstance(source, (str, os.PathLike)) and not str(source).startswith(("http://", "https://", "file://")):
        source = agent.resolve_path(source)
    max_tokens = agent.config.get('max_input_tokens', 8000)
    return view_document_content(source, start_at_line=start_at_line, max_tokens=max_tokens, search_query=search_query)

@tool
def write(writes):
    """
    description: |
        Write or overwrite one or more complete UTF-8 text files.
        Use this when creating new text files or replacing entire files is clearer than targeted edits.
        Parent directories are created automatically.
        Pass either a single write object or a list of write objects.
    parameters:
        writes:
            description: |
                A single write object or a list of write objects.
                Each object must contain file_path and content.
            anyOf:
                - type: object
                  properties:
                    file_path:
                        type: string
                    content:
                        type: string
                  required:
                    - file_path
                    - content
                - type: array
                  items:
                    type: object
                    properties:
                        file_path:
                            type: string
                        content:
                            type: string
                    required:
                        - file_path
                        - content
    """
    if isinstance(writes, Mapping):
        writes = [writes]
    elif not isinstance(writes, list):
        return "Failed: writes must be an object or a list of objects."

    reports = []
    for index, item in enumerate(writes, start=1):
        reports.append(apply_file_write(index, item))
    return "\n".join(reports)


def apply_file_write(index, item):
    if not isinstance(item, Mapping):
        return f"{index}. failed: write must be an object."

    file_path = item.get("file_path")
    content = item.get("content")
    if not file_path:
        return f"{index}. failed: file_path must not be empty."
    if content is None:
        return f"{index}. failed: content must not be null."

    agent = get_agent()
    path = agent.resolve_path(file_path)
    hook = agent.run_hook("file.write.before", index=index, file_path=path, content=content)
    path = hook.payload.file_path
    content = hook.payload.content
    try:
        parent = os.path.dirname(path)
        if parent:
            os.makedirs(parent, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(str(content))
    except OSError as exc:
        return f"{index}. failed: could not write {path}: {exc}"

    report = f"{index}. success: wrote {len(str(content))} characters to {path}."
    hook = agent.run_hook("file.write.after", index=index, file_path=path, content=content, report=report)
    return hook.payload.report


@tool
def edit(edits):
    """
    description: |
        Perform targeted exact-string replacements in local text files.
        Pass either a single edit object or a list of edit objects.
        Each edit object must contain:
        - file_path: path to the file to edit
        - old_string: exact text to replace
        - new_string: replacement text
        - replace_all: optional boolean, default false

        old_string must match exactly once in the file, otherwise that edit fails and the file is left unchanged.
        edits are thus made more reliable by including surrounding context in the replacement : AXB -> AYB instead of direct X -> Y
        Set replace_all=true explicitely when the intention is to replace every match.
        Multiple edits are tried in sequence; later edits see the result of earlier successful edits.
    parameters:
        edits:
            description: A single edit object or a list of edit objects.
    required:
        - edits
    """
    if isinstance(edits, Mapping):
        edit_items = [edits]
    elif isinstance(edits, list):
        edit_items = edits
    else:
        return "Failed: edits must be an object or a list of objects."

    reports = []
    for index, item in enumerate(edit_items, start=1):
        reports.append(apply_text_edit(index, item))
    return "\n".join(reports)


def apply_text_edit(index, item):
    if not isinstance(item, Mapping):
        return f"{index}. failed: edit must be an object."

    file_path = item.get("file_path")
    old_string = item.get("old_string")
    new_string = item.get("new_string")
    replace_all = bool(item.get("replace_all", False))

    missing = [
        key for key, value in (
            ("file_path", file_path),
            ("old_string", old_string),
            ("new_string", new_string),
        )
        if value is None
    ]
    if missing:
        return f"{index}. failed: missing {', '.join(missing)}."
    if old_string == "":
        return f"{index}. failed: old_string must not be empty."

    agent = get_agent()
    path = agent.resolve_path(file_path)
    hook = agent.run_hook(
        "file.edit.before",
        index=index,
        file_path=path,
        old_string=old_string,
        new_string=new_string,
        replace_all=replace_all,
    )
    path = hook.payload.file_path
    old_string = hook.payload.old_string
    new_string = hook.payload.new_string
    replace_all = hook.payload.replace_all
    if not os.path.isfile(path):
        return f"{index}. failed: file not found: {path}"

    try:
        with open(path, "r", encoding="utf-8") as f:
            content = f.read()
    except UnicodeDecodeError:
        return f"{index}. failed: file is not valid UTF-8 text: {path}"
    except OSError as exc:
        return f"{index}. failed: could not read {path}: {exc}"

    old_string = str(old_string)
    new_string = str(new_string)
    matches = content.count(old_string)
    if matches == 0:
        return f"{index}. failed: old_string not found in {path}."
    if matches > 1 and not replace_all:
        return f"{index}. failed: old_string matched {matches} times in {path}; set replace_all=true to replace all matches."

    updated = content.replace(old_string, new_string) if replace_all else content.replace(old_string, new_string, 1)
    try:
        with open(path, "w", encoding="utf-8") as f:
            f.write(updated)
    except OSError as exc:
        return f"{index}. failed: could not write {path}: {exc}"

    replaced = matches if replace_all else 1
    report = f"{index}. success: replaced {replaced} match{'es' if replaced != 1 else ''} in {path}."
    hook = agent.run_hook("file.edit.after", index=index, file_path=path, replaced=replaced, report=report)
    return hook.payload.report
