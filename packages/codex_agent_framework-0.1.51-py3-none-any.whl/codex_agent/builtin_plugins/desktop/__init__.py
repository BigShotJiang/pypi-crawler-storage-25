"""Desktop plugin: local desktop automation tools and live context."""

import json
import os
import time
from collections.abc import Mapping

from PIL import Image, ImageDraw, ImageFont

from ...image import ImageMessage
from ...plugin import Plugin
from ...provider import provider
from ...tool import tool
from ...utils import runtime_join
from ...desktop import DesktopControlError, get_desktop_controller


def _window_data(window):
    return window.to_dict() if hasattr(window, "to_dict") else dict(window)


def _format_desktop_windows(windows):
    lines = []
    for window in windows:
        window = _window_data(window)
        size = ""
        if window.get("width") is not None and window.get("height") is not None:
            size = f" {window.get('width')}x{window.get('height')}+{window.get('x')}+{window.get('y')}"
        klass = f" [{window.get('wm_class')}]" if window.get("wm_class") else ""
        state = []
        if window.get("active") is True:
            state.append("active")
        if window.get("visible") is False:
            state.append("hidden")
        elif window.get("visible") is True:
            state.append("visible")
        suffix = f" ({', '.join(state)})" if state else ""
        title = window.get("title") or "(untitled)"
        lines.append(f"- {window.get('id')}{size}{klass}{suffix} :: {title}")
    return "\n".join(lines)


def _format_desktop_context_windows(windows) -> str:
    if not windows:
        return "Open windows: none reported by the desktop backend."
    return "Open windows, usable with desktop window commands:\n" + _format_desktop_windows(windows)


def _draw_desktop_grid(source_path: str) -> str:
    """Overlay a light coordinate grid on a screenshot and return the annotated path."""
    grid_path = runtime_join("images", "screenshots", "live_desktop_grid.png")
    os.makedirs(os.path.dirname(grid_path), exist_ok=True)

    with Image.open(source_path) as image:
        image = image.convert("RGBA")
        overlay = Image.new("RGBA", image.size, (0, 0, 0, 0))
        draw = ImageDraw.Draw(overlay)
        width, height = image.size
        font = ImageFont.load_default()

        minor_step = 100
        major_step = 500
        minor_color = (255, 255, 255, 45)
        major_color = (255, 255, 255, 85)
        text_bg = (0, 0, 0, 95)
        text_color = (255, 255, 255, 180)

        for x in range(0, width, minor_step):
            color = major_color if x % major_step == 0 else minor_color
            line_width = 2 if x % major_step == 0 else 1
            draw.line([(x, 0), (x, height)], fill=color, width=line_width)
            if x % major_step == 0:
                label = str(x)
                draw.rectangle((x + 3, 3, x + 3 + len(label) * 7, 15), fill=text_bg)
                draw.text((x + 5, 4), label, font=font, fill=text_color)

        for y in range(0, height, minor_step):
            color = major_color if y % major_step == 0 else minor_color
            line_width = 2 if y % major_step == 0 else 1
            draw.line([(0, y), (width, y)], fill=color, width=line_width)
            if y % major_step == 0:
                label = str(y)
                draw.rectangle((3, y + 3, 3 + len(label) * 7, y + 15), fill=text_bg)
                draw.text((5, y + 4), label, font=font, fill=text_color)

        Image.alpha_composite(image, overlay).convert("RGB").save(grid_path)
    return grid_path


def _parse_desktop_payload(content):
    if content is None or content == "":
        raise ValueError("desktop custom tool input is required.")
    if isinstance(content, (Mapping, list)):
        return content
    if not isinstance(content, str):
        raise ValueError("desktop input must be raw JSON text, an object, or a list of objects.")
    try:
        return json.loads(content)
    except json.JSONDecodeError as exc:
        raise ValueError(f"invalid desktop JSON input: {exc.msg} at line {exc.lineno} column {exc.colno}.") from exc


def _desktop_int(command, key, *, default=None, required=False, minimum=None):
    value = command.get(key, default)
    if value is None:
        if required:
            raise ValueError(f"{key} is required")
        return None
    try:
        value = int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{key} must be an integer") from exc
    if minimum is not None and value < minimum:
        raise ValueError(f"{key} must be >= {minimum}")
    return value


def _nice_step(value):
    value = max(1, float(value))
    magnitude = 1
    while value >= 10:
        value /= 10
        magnitude *= 10
    if value <= 1:
        nice = 1
    elif value <= 2:
        nice = 2
    elif value <= 5:
        nice = 5
    else:
        nice = 10
    return nice * magnitude


def _zoom_layout(width, height):
    target_long_edge = 900
    scale = target_long_edge / max(width, height)
    scale = min(16, max(0.5, scale))
    grid_step = _nice_step(min(width, height) / 8)
    label_step = _nice_step(grid_step * 4)
    return scale, grid_step, max(label_step, grid_step)


class DesktopPlugin(Plugin):
    name = "desktop"
    description = "Local desktop automation tools and live screenshot context provider."
    command_settle_seconds = 1
    system_prompt = """
# Desktop

Desktop control has an explicit lifecycle:
1. Call desktop_start_session before any desktop action.
2. Wait for the next context step/provider refresh and use the desktop_state provider as the source of truth for current windows, screen contents, coordinates, and whether the live session is active.
3. Call desktop_run_commands only after desktop_state confirms the live session is active and you have the visual/context needed to act.
4. Call desktop_stop_session when you are done with desktop control.

desktop_run_commands is for actions only. It does not expose status/observation commands, and it fails when the live session is not active.
Use the provider screenshot/grid for observation; 
For pecision tasks, first use the `zoom` command to get a tighter gridded image of the area of interest. Then act once you have it.
Batch related GUI actions in one desktop_run_commands call when visual feedback isn't needed in between, wait for resolution and feedback to confirm proper effect, and keep destructive actions such as closing windows or overwriting clipboard contents intentional.
"""

    def __init__(self, agent):
        super().__init__(agent)
        self.desktop_controller = get_desktop_controller()

    @tool
    def start_session(self):
        """
        description: Start the live desktop session required before running desktop action commands.
        """
        self.desktop_controller.start_live_session()
        return "Desktop live session started. Fresh desktop screenshots will be included in context."

    @tool
    def stop_session(self):
        """
        description: Stop the live desktop session when desktop action commands and fresh screenshot context are no longer needed.
        """
        self.desktop_controller.stop_live_session()
        return "Desktop live session stopped."

    @provider
    def desktop_state(self):
        """Expose a fresh desktop screenshot while DesktopController live mode is active."""
        if not getattr(self.desktop_controller, "live_session", False):
            return None

        window_listing = "Open windows: unavailable."
        try:
            window_listing = _format_desktop_context_windows(self.desktop_controller.list_windows())
        except DesktopControlError as exc:
            window_listing = f"Open windows: listing failed: {exc}"
        except Exception as exc:
            window_listing = f"Open windows: listing unavailable: {exc}"

        screenshot_path = runtime_join("images", "screenshots", "live_desktop.png")
        try:
            saved_path = self.desktop_controller.capture_screen(screenshot_path)
            saved_path = _draw_desktop_grid(saved_path)
        except DesktopControlError as exc:
            return f"Desktop live session is active, but screenshot capture failed: {exc}\n\n{window_listing}"
        except Exception as exc:
            return f"Desktop live session is active, but screenshot capture is unavailable: {exc}\n\n{window_listing}"

        return [
            "Desktop live session is active. The following image is a fresh screenshot of the current desktop "
            "with a light 100 px coordinate grid and labels every 500 px.\n\n"
            f"{window_listing}",
            ImageMessage(
                content=saved_path,
                description="Fresh screenshot of the current local desktop with a light coordinate grid because DesktopController live_session=True.",
                image_name="live_desktop_grid.png",
            ),
        ]

    @tool(tool_type="custom")
    def run_commands(self, content=None):
        """
        description: |
            Run one or more local desktop action command objects in sequence.
            The desktop_state provider is the source of truth for desktop state, screenshots, mouse/window context, and live session status.
            This tool exposes actions only. Every command fails when the desktop live session is not active.
            Use desktop_start_session before this tool and desktop_stop_session when desktop control is no longer needed.

            Pass raw JSON as the custom tool input. It must be either:
            - a single command object, e.g. {"command": "press", "keys": "Return"}
            - or a list of command objects, e.g. [{"command": "activate_window", "window_id": "0x123456"}, {"command": "press", "keys": "Return"}]

            Every command object must contain a `command` string.

            Supported payloads:
            - {"command": "activate_window", "window_id": "0x123456"}
            - {"command": "move_resize_window", "window_id": "0x123456", "x": 100, "y": 100, "width": 900, "height": 600}
            - {"command": "minimize_window", "window_id": "0x123456"}
            - {"command": "close_window", "window_id": "0x123456"}
            - {"command": "move_mouse", "x": 1200, "y": 700}
            - {"command": "click_mouse", "button": 1}
            - {"command": "click_mouse", "button": 1, "x": 1200, "y": 700, "clicks": 2}
            - {"command": "click_drag_release", "x": 600, "y": 450, "to_x": 900, "to_y": 450, "button": 1}
            - {"command": "copy", "text": "hello"}
            - {"command": "copy"}
            - {"command": "paste"}
            - {"command": "press", "keys": "Return"}
            - {"command": "press", "keys": "ctrl+l"}
            - {"command": "zoom", "x": 600, "y": 300, "width": 400, "height": 250}

            For press, `keys` is one simultaneous key chord in xdotool key format, such as "Return", "ctrl+l", "ctrl+shift+a", or "shift+Return".
            Do not put a natural-language sequence in one press command; use several press commands for sequential key presses.

            Typical batches:
            - [{"command": "activate_window", "window_id": "0x123456"}, {"command": "copy", "text": "hello"}, {"command": "paste"}, {"command": "press", "keys": "Return"}]
        """
        try:
            commands = _parse_desktop_payload(content)
        except ValueError as exc:
            return f"failed: {exc}"
        if isinstance(commands, Mapping):
            command_items = [commands]
        elif isinstance(commands, list):
            command_items = commands
        else:
            return "failed: desktop input must be a JSON object or a JSON array of objects."

        outputs = []
        for command in command_items:
            result = self.run_desktop_command(command)
            if isinstance(result, list):
                outputs.extend(result)
            else:
                outputs.append(result)
        self.wait_for_desktop_refresh()
        return outputs

    def wait_for_desktop_refresh(self):
        if self.command_settle_seconds > 0:
            time.sleep(self.command_settle_seconds)

    def zoom(self, command):
        x = _desktop_int(command, "x", required=True, minimum=0)
        y = _desktop_int(command, "y", required=True, minimum=0)
        width = _desktop_int(command, "width", required=True, minimum=1)
        height = _desktop_int(command, "height", required=True, minimum=1)
        scale, grid_step, label_step = _zoom_layout(width, height)

        screenshots_dir = runtime_join("images", "screenshots")
        os.makedirs(screenshots_dir, exist_ok=True)
        raw_path = os.path.join(screenshots_dir, "desktop_zoom_source.png")
        output_path = command.get("output_path") or os.path.join(
            screenshots_dir,
            f"desktop_zoom_{x}_{y}_{width}x{height}.png",
        )

        captured_path = self.desktop_controller.capture_screen(raw_path)
        with Image.open(captured_path) as image:
            if x + width > image.width or y + height > image.height:
                raise ValueError(
                    f"region {width}x{height}+{x}+{y} exceeds screenshot bounds {image.width}x{image.height}"
                )
            region = image.crop((x, y, x + width, y + height)).convert("RGBA")

        scaled_size = (max(1, round(width * scale)), max(1, round(height * scale)))
        region = region.resize(scaled_size, Image.Resampling.NEAREST)

        overlay = Image.new("RGBA", region.size, (0, 0, 0, 0))
        draw = ImageDraw.Draw(overlay)
        font = ImageFont.load_default()
        line_color = (255, 255, 255, 70)
        label_line_color = (255, 255, 255, 125)
        text_bg = (0, 0, 0, 130)
        text_color = (255, 255, 255, 230)

        def draw_label(px, py, text):
            bbox = draw.textbbox((px, py), text, font=font)
            pad = 2
            draw.rectangle((bbox[0] - pad, bbox[1] - pad, bbox[2] + pad, bbox[3] + pad), fill=text_bg)
            draw.text((px, py), text, font=font, fill=text_color)

        local_x = 0
        while local_x <= width:
            px = round(local_x * scale)
            is_label = local_x % label_step == 0
            draw.line([(px, 0), (px, region.height)], fill=label_line_color if is_label else line_color, width=2 if is_label else 1)
            if is_label:
                draw_label(px + 4, 4, f"x={x + local_x}")
            local_x += grid_step

        local_y = 0
        while local_y <= height:
            py = round(local_y * scale)
            is_label = local_y % label_step == 0
            draw.line([(0, py), (region.width, py)], fill=label_line_color if is_label else line_color, width=2 if is_label else 1)
            if is_label:
                draw_label(4, py + 4, f"y={y + local_y}")
            local_y += grid_step

        draw_label(6, max(6, region.height - 18), f"zoom {width}x{height}+{x}+{y} - grid {grid_step}px - scale {scale:g}x")
        annotated = Image.alpha_composite(region, overlay).convert("RGB")
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        annotated.save(output_path)

        return [
            f"Zoomed desktop region {width}x{height}+{x}+{y} with {grid_step}px grid, labels every {label_step}px, scale {scale:g}x. Coordinates shown are absolute desktop coordinates.",
            ImageMessage(
                content=output_path,
                image_name=f"desktop_zoom_{x}_{y}_{width}x{height}.png",
                description=(
                    f"Zoomed desktop region {width}x{height}+{x}+{y}, annotated with a {grid_step}px grid. "
                    "Grid labels are absolute desktop coordinates."
                ),
                turns_left=3,
            ),
        ]

    def run_desktop_command(self, command):
        if not isinstance(command, Mapping):
            return "failed: desktop command must be an object."
        name = command.get("command")
        if not name:
            return "failed: desktop command requires a 'command' field."
        try:
            if not getattr(self.desktop_controller, "live_session", False):
                return "failed: desktop live session is not active. Start it with desktop_start_session before sending desktop actions."
            if name == "activate_window":
                window_id = command.get("window_id") or command.get("id")
                self.desktop_controller.activate_window(window_id)
                return f"Activated window {window_id}."
            if name == "move_resize_window":
                window_id = command.get("window_id") or command.get("id")
                x, y, width, height = command.get("x"), command.get("y"), command.get("width"), command.get("height")
                self.desktop_controller.move_resize_window(window_id, x, y, width, height)
                return f"Moved/resized window {window_id} to {width}x{height}+{x}+{y}."
            if name == "minimize_window":
                window_id = command.get("window_id") or command.get("id")
                self.desktop_controller.minimize_window(window_id)
                return f"Minimized window {window_id}."
            if name == "close_window":
                window_id = command.get("window_id") or command.get("id")
                self.desktop_controller.close_window(window_id)
                return f"Closed window {window_id}."
            if name == "move_mouse":
                x, y = command.get("x"), command.get("y")
                self.desktop_controller.move_mouse(x, y)
                return f"Moved mouse to {x},{y}."
            if name == "click_mouse":
                button = command.get("button", 1)
                x, y = command.get("x"), command.get("y")
                clicks = command.get("clicks", 1)
                self.desktop_controller.click_mouse(button=button, x=x, y=y, clicks=clicks)
                where = f" at {x},{y}" if x is not None and y is not None else ""
                return f"Clicked mouse button {button}{where} ({clicks} click(s))."
            if name == "click_drag_release":
                button = command.get("button", 1)
                x, y = command.get("x"), command.get("y")
                to_x, to_y = command.get("to_x"), command.get("to_y")
                self.desktop_controller.click_drag_release(x=x, y=y, to_x=to_x, to_y=to_y, button=button)
                return f"Dragged mouse button {button} from {x},{y} to {to_x},{to_y}."
            if name == "copy":
                text = command.get("text")
                self.desktop_controller.copy(text)
                if text is None:
                    return "Copied current selection to the clipboard."
                return f"Copied {len(text)} character(s) to the clipboard."
            if name == "paste":
                self.desktop_controller.paste()
                return "Pasted clipboard at the cursor location."
            if name == "press":
                keys = command.get("keys")
                self.desktop_controller.press(keys)
                return f"Pressed keys {keys}."
            if name == "zoom":
                return self.zoom(command)
            return f"failed: unsupported desktop command: {name!r}"
        except DesktopControlError as exc:
            return f"failed: desktop command {name!r}: {exc}"
        except Exception as exc:
            return f"failed: desktop command {name!r}: {exc}"
