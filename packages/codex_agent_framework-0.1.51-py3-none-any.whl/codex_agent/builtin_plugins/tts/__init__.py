import re
import time
from threading import Lock, current_thread

from ...command import command
from ...event import AssistantInterruptedEvent, AssistantStepEndEvent, AudioPlaybackEvent
from ...plugin import Plugin, event_handler, stream_processor
from ...stream_utils import Streamer, Task, TokenStreamer, fenced
from ...utils import utf8_safe_tokenize
from modict import modict


def silent_play(audio):
    """Play audio using the best available backend without console output."""
    try:
        from pydub.playback import _play_with_simpleaudio
        return _play_with_simpleaudio(audio)
    except Exception:
        pass
    try:
        from pydub.playback import _play_with_pyaudio
        return _play_with_pyaudio(audio)
    except Exception:
        pass
    try:
        import subprocess
        import tempfile
        with tempfile.NamedTemporaryFile("w+b", suffix=".wav", delete=True) as f:
            audio.export(f.name, "wav")
            subprocess.call(
                ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet", f.name],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        print("Aucun backend audio fonctionnel trouvé.")


class PlayAudio(Task):
    def __init__(self, agent, args=None, kwargs=None):
        super().__init__(args=args, kwargs=kwargs)
        self.agent = agent

    def target(self, audio):
        if audio is not None:
            self.agent.emit(AudioPlaybackEvent, audio=audio)


class MuteTagProcessor(Streamer):
    def __init__(self, agent):
        super().__init__()
        self.agent = agent
        self.token_streamer = TokenStreamer([
            (fenced('<MUTE>', '</MUTE>', flags=re.DOTALL | re.MULTILINE), lambda m: m.group()),
            (fenced('```', '```', flags=re.DOTALL | re.MULTILINE), lambda m: f'<MUTE>{m.group()}</MUTE>'),
            (fenced(r'\$\$', r'\$\$', flags=re.DOTALL | re.MULTILINE), lambda m: f'<MUTE>{m.group()}</MUTE>'),
            (fenced(r'\\\[', r'\\\]', flags=re.DOTALL | re.MULTILINE), lambda m: f'<MUTE>{m.group()}</MUTE>'),
            (fenced(r'\\\(', r'\\\)', flags=re.DOTALL | re.MULTILINE), lambda m: f'<MUTE>{m.group()}</MUTE>'),
            (r'\$[^$\n]+?\$', lambda m: f'<MUTE>{m.group()}</MUTE>'),
            (r'https?://\S+', lambda m: f'<MUTE>{m.group()}</MUTE>'),
        ], threaded=False)

    def stream_processor(self, stream):
        return self.token_streamer.process(stream)


class MuteAnalyzer(Streamer):
    def __init__(self, agent):
        super().__init__()
        self.agent = agent

    def stream_processor(self, stream):
        for token in stream:
            if token.startswith('<MUTE>') and token.endswith('</MUTE>'):
                yield ('mute', token[6:-7])
            else:
                yield ('speak', token)


class LineAgregator(Streamer):
    def __init__(self, agent):
        super().__init__()
        self.agent = agent

    def stream_processor(self, stream):
        lines = ""
        token_count = 0
        last_mode = None
        for mode, token in stream:
            if mode != last_mode:
                if lines and last_mode is not None:
                    yield (last_mode, lines)
                lines = ""
                token_count = 0
                last_mode = mode

            token_count += 1
            while '\n' in token:
                parts = token.split('\n')
                lines += parts[0] + '\n'
                if token_count > 50:
                    yield (last_mode, lines)
                    lines = ""
                    token_count = 0
                token = '\n'.join(parts[1:])
            else:
                lines += token
        if lines and last_mode is not None:
            yield (last_mode, lines)


class LineToAudio(Streamer):
    def __init__(self, agent):
        super().__init__()
        self.agent = agent

    def text_to_audio(self, text):
        if text.strip():
            params = modict(
                model=self.agent.plugins.tts.config.get('model', 'gpt-4o-mini-tts'),
                voice=self.agent.plugins.tts.config.get('voice', 'nova'),
                instructions=self.agent.plugins.tts.config.get('instructions', 'You speak with a friendly and casual tone.'),
                input=text,
            )
            return self.agent.ai.text_to_audio(**params)
        return None

    def stream_processor(self, stream):
        for mode, line in stream:
            if not line:
                continue
            if mode == 'mute' or not self.agent.plugins.tts.config.get('enabled', False):
                audio = None
            else:
                audio = self.text_to_audio(line)
            yield (line, audio)


class AudioPlayer(Streamer):
    def __init__(self, agent, voice_processor):
        super().__init__()
        self.agent = agent
        self.voice_processor = voice_processor

    def stream_processor(self, stream):
        for line, audio in stream:
            tokenized = utf8_safe_tokenize(line)
            if audio is not None and self.agent.plugins.tts.config.get('enabled', False):
                sleep_time_per_token = 0.95 * (audio.duration_seconds / len(tokenized))
                task = PlayAudio(self.agent, args=(audio,))
                self.voice_processor.start_audio_task(task)
                for token in tokenized:
                    yield token
                    time.sleep(sleep_time_per_token)
                self.voice_processor.join_audio_tasks()
            else:
                for token in tokenized:
                    yield token
                    if self.agent.plugins.tts.config.get('enabled', False):
                        time.sleep(0.02)


class Throttler(Streamer):
    def __init__(self, agent):
        super().__init__()
        self.agent = agent

    def stream_processor(self, stream):
        buffer = ''
        buffer_size = self.agent.plugins.tts.config.get('buffer_size', 3)
        for i, token in enumerate(stream):
            buffer += token
            if i % buffer_size == 0:
                yield buffer
                buffer = ''
        if buffer:
            yield buffer


class VoiceProcessor(Streamer):
    def __init__(self, agent):
        super().__init__(threaded=False)
        self.agent = agent
        self.mute_tag_processor = MuteTagProcessor(self.agent)
        self.line_splitter = LineAgregator(self.agent)
        self.line_to_audio = LineToAudio(self.agent)
        self.speech_processor = AudioPlayer(self.agent, self)
        self.mute_analyzer = MuteAnalyzer(self.agent)
        self.throttler = Throttler(self.agent)
        self.audio_tasks = []
        self.audio_tasks_lock = Lock()

    @property
    def enabled(self):
        return bool(self.agent.plugins.tts.config.get('enabled', False))

    def start_audio_task(self, task):
        with self.audio_tasks_lock:
            self.audio_tasks.append(task)
        task.start()
        return task

    def join_audio_tasks(self, timeout=None):
        while True:
            with self.audio_tasks_lock:
                tasks = list(self.audio_tasks)
            if not tasks:
                return
            for task in tasks:
                thread = task.thread
                if thread and thread is not current_thread() and thread.is_alive():
                    thread.join(timeout=timeout)
                with self.audio_tasks_lock:
                    if not thread or not thread.is_alive():
                        if task in self.audio_tasks:
                            self.audio_tasks.remove(task)

    def stream_processor(self, stream):
        if not self.enabled:
            return stream
        return self.voice_stream(stream)

    def voice_stream(self, stream):
        tagged_stream = self.mute_tag_processor.process(stream)
        analyzed_stream = self.mute_analyzer.process(tagged_stream)
        marked_lines = self.line_splitter.process(analyzed_stream)
        lines_with_playback = self.line_to_audio.process(marked_lines)
        synced_stream = self.speech_processor.process(lines_with_playback)
        return self.throttler.process(synced_stream)


class TTSPlugin(Plugin):
    name = "tts"
    description = "Synchronized text-to-speech stream processor and audio playback."
    requires_openai = False
    config_defaults = modict(
        model="gpt-4o-mini-tts",
        voice="nova",
        instructions="You speak with a friendly and intelligent tone.",
        enabled=False,
        buffer_size=2,
    )
    config_legacy_aliases = {}
    config_legacy_sections = ("plugins.tts",)
    system_prompt = """
# TTS and Conversation tone

Your text output is rendered by a realistic TTS engine adapting its tone according to tone instructions given as a prompt.

Current prompt used:
<<agent.plugins.tts.config.instructions>>

Use it as well as a guide to adapt your text output style to align and match well with these tone guidelines.

For best TTS results, use shorter outputs in a very conversational format (avoid lengthy outputs, too much markdown formatting, etc.).
"""

    def __init__(self, agent):
        super().__init__(agent)
        self.voice_processor = VoiceProcessor(agent)

    def apply_config_defaults(self):
        config = super().apply_config_defaults()
        if not self.agent.config_manager.has_openai_api_key():
            config.enabled = False
        return config

    @stream_processor("content")
    def process_content_stream(self, stream):
        return self.voice_processor(stream)

    @event_handler(AssistantStepEndEvent)
    def join_audio_after_step(self, event):
        self.voice_processor.join_audio_tasks()

    @event_handler(AssistantInterruptedEvent)
    def join_audio_after_interrupt(self, event):
        self.voice_processor.join_audio_tasks(timeout=0)

    @event_handler(AudioPlaybackEvent)
    def handle_audio_playback(self, event):
        audio = event.get("audio")
        if audio is None:
            return None
        if self.agent.has_hook("audio_playback_hook"):
            return self.agent.run_hooks("audio_playback_hook", audio)
        return silent_play(audio)

    @command
    def voice(self, value=None):
        if value is None:
            state = "on" if self.config.get("enabled", False) else "off"
            return f"voice: {state}; voice={self.config.get('voice')!r}"

        lowered = str(value).lower()
        if lowered in ("on", "true", "yes", "1"):
            self.config.enabled = True
            self.save_config()
            return f"Updated tts config: enabled={self.config.enabled!r}"
        if lowered in ("off", "false", "no", "0"):
            self.config.enabled = False
            self.save_config()
            return f"Updated tts config: enabled={self.config.enabled!r}"

        self.config.voice = str(value)
        self.config.enabled = True
        self.save_config()
        return f"Updated tts config: voice={self.config.voice!r}, enabled={self.config.enabled!r}"

    def speak(self, text, **kwargs):
        params = modict(
            model=self.config.get("model", "gpt-4o-mini-tts"),
            voice=self.config.get("voice", "nova"),
            instructions=self.config.get("instructions", "You speak with a friendly and casual tone."),
            input=text,
        )
        params.update(kwargs)
        audio = self.agent.ai.text_to_audio(**params)
        if audio is not None:
            self.agent.emit(AudioPlaybackEvent, audio=audio)

    def stop(self, timeout=None):
        self.voice_processor.join_audio_tasks(timeout=timeout)
        return self
