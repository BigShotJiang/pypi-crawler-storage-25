from codex_agent.agent_runtime import InProcessAgentRuntime, ProcessAgentRuntime
from codex_agent.client import AgentClient


class ServerRuntimeClient:
    """HTTP client adapter exposing the AgentRuntime surface used by the CLI."""

    def __init__(self, base_url="http://127.0.0.1:8765"):
        self.client = AgentClient(base_url=base_url)

    def start(self):
        return self

    def stop(self, timeout=None):
        self.client.stop_events(timeout=timeout or 0.2)
        return self

    def on_event(self, handler):
        return self.client.on("*", handler)

    def start_events(self):
        self.client.start_events()
        return self

    def stop_events(self):
        self.client.stop_events()
        return self

    @property
    def busy(self):
        return self.client.busy

    @property
    def current_turn_id(self):
        try:
            return self.client.get_status().get("current_turn_id")
        except Exception:
            return None

    @property
    def current_session_id(self):
        try:
            return self.client.get_status().get("session_id")
        except Exception:
            return None

    def get_status(self):
        return self.client.get_status()

    def config(self):
        return self.client.get_config()

    def update_config(self, values=None, save=True, **kwargs):
        return self.client.update_config(values, save=save, **kwargs)

    def tools(self):
        return self.client.tools()

    def sessions(self):
        return self.client.sessions()

    def start_new_session(self):
        return self.client.new_session()

    def load_session(self, session_id):
        return self.client.load_session(session_id)

    def delete_session(self, session_id):
        return self.client.delete_session(session_id)

    def interrupt(self, reason="cli"):
        return self.client.interrupt(reason=reason)

    def submit_prompt(self, prompt):
        return self.client.submit_prompt(prompt)


def server_runner(base_url="http://127.0.0.1:8765"):
    return ServerRuntimeClient(base_url=base_url)


def process_runner(agent_kwargs=None):
    return ProcessAgentRuntime(agent_kwargs=agent_kwargs or {})


def in_process_runner(agent):
    return InProcessAgentRuntime(agent)
