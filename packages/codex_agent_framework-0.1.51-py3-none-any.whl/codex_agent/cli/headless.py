import json
import sys
import threading

from .output import dump_ndjson, output_payload, key_value_text
from .runner import in_process_runner, process_runner, server_runner


TERMINAL_EVENTS = {"assistant_turn_end_event", "assistant_turn_error_event", "server_shutdown"}


def runner_from_args(args):
    runtime = getattr(args, "runtime", "server") or "server"
    if runtime == "server":
        return server_runner(base_url=args.url or f"http://{args.host}:{args.port}")
    if runtime == "process":
        from .main import default_agent_kwargs
        return process_runner(agent_kwargs=default_agent_kwargs())
    if runtime == "in-process":
        from .main import default_agent
        return in_process_runner(default_agent())
    raise SystemExit(f"unsupported runtime: {runtime}")


def should_stop_runner(args):
    return (getattr(args, "runtime", "server") or "server") != "server"


def output_format(args):
    if getattr(args, "json", False):
        return "json"
    return getattr(args, "format", None) or "text"


def read_prompt(args, extra_args):
    if getattr(args, "stdin", False):
        prompt = sys.stdin.read()
    else:
        prompt = " ".join(extra_args).strip()
    if not prompt:
        raise SystemExit("prompt is required; pass it as arguments or use --stdin")
    return prompt


def with_runner(args, callback):
    runner = runner_from_args(args).start()
    try:
        return callback(runner)
    finally:
        if should_stop_runner(args):
            runner.stop()


def run_status(args, extra_args=None):
    payload = with_runner(args, lambda runner: runner.get_status())
    output_payload(payload, fmt=output_format(args), text_formatter=key_value_text)
    return payload


def run_tools(args, extra_args=None):
    payload = with_runner(args, lambda runner: runner.tools())

    def format_tools(data):
        if isinstance(data, dict):
            names = sorted(data.keys())
        else:
            names = [str(item) for item in data or []]
        return "\n".join(names)

    output_payload(payload, fmt=output_format(args), text_formatter=format_tools)
    return payload


def parse_config_value(value):
    text = str(value)
    lowered = text.lower()
    if lowered == "true":
        return True
    if lowered == "false":
        return False
    if lowered == "null" or lowered == "none":
        return None
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return value


def parse_config_set_args(extra_args):
    args = list(extra_args or [])
    if not args:
        raise SystemExit("config set requires KEY VALUE or KEY=VALUE")
    values = {}
    if len(args) == 1 and "=" in args[0]:
        key, value = args[0].split("=", 1)
        values[key] = parse_config_value(value)
        return values
    if len(args) % 2 != 0:
        raise SystemExit("config set requires KEY VALUE pairs or KEY=VALUE")
    for index in range(0, len(args), 2):
        values[args[index]] = parse_config_value(args[index + 1])
    return values


def run_config(args, extra_args=None):
    extra_args = list(extra_args or [])
    command = extra_args[0] if extra_args else "get"
    if command == "get":
        payload = with_runner(args, lambda runner: runner.config())
        if len(extra_args) >= 2:
            key = extra_args[1]
            payload = payload.get(key)
    elif command == "set":
        values = parse_config_set_args(extra_args[1:])
        payload = with_runner(args, lambda runner: runner.update_config(values, save=not getattr(args, "no_save", False)))
    else:
        raise SystemExit(f"unsupported config command: {command}")
    output_payload(payload, fmt=output_format(args), text_formatter=lambda data: key_value_text(data) if isinstance(data, dict) else str(data))
    return payload


def run_sessions(args, extra_args=None):
    extra_args = list(extra_args or [])
    command = extra_args[0] if extra_args else "list"

    def action(runner):
        if command == "list":
            return runner.sessions()
        if command == "new":
            return runner.start_new_session()
        if command == "load":
            if len(extra_args) < 2:
                raise SystemExit("sessions load requires a session id")
            return runner.load_session(extra_args[1])
        if command == "delete":
            if len(extra_args) < 2:
                raise SystemExit("sessions delete requires a session id")
            return runner.delete_session(extra_args[1])
        raise SystemExit(f"unsupported sessions command: {command}")

    payload = with_runner(args, action)

    def format_sessions(data):
        if command != "list" or not isinstance(data, dict):
            return key_value_text(data) if isinstance(data, dict) else str(data)
        current = data.get("current")
        sessions = data.get("sessions") or []
        lines = []
        for session in sessions:
            session_id = session.get("id") if isinstance(session, dict) else str(session)
            prefix = "*" if session_id == current else " "
            title = session.get("title") or session.get("name") or "" if isinstance(session, dict) else ""
            lines.append(f"{prefix} {session_id} {title}".rstrip())
        return "\n".join(lines)

    output_payload(payload, fmt=output_format(args), text_formatter=format_sessions)
    return payload


def run_interrupt(args, extra_args=None):
    reason = " ".join(extra_args or []).strip() or "cli"
    payload = with_runner(args, lambda runner: runner.interrupt(reason=reason))
    output_payload(payload, fmt=output_format(args), text_formatter=key_value_text)
    return payload


def run_prompt(args, extra_args=None):
    prompt = read_prompt(args, extra_args or [])
    fmt = output_format(args)
    runner = runner_from_args(args).start()
    done = threading.Event()
    result = {"ok": True, "text": "", "events": [], "accepted": None, "error": None}

    def handle_event(event):
        event_type = event.get("type")
        if fmt == "ndjson":
            dump_ndjson(event)
        elif fmt == "text" and event_type == "response_content_delta_event":
            delta = event.get("delta") or ""
            result["text"] += delta
            print(delta, end="", flush=True)
        result["events"].append(dict(event))
        if event_type == "assistant_turn_error_event":
            result["ok"] = False
            result["error"] = event.get("error") or "assistant turn failed"
        if event_type in TERMINAL_EVENTS:
            done.set()

    runner.on_event(handle_event)
    runner.start_events()
    try:
        accepted = runner.submit_prompt(prompt)
        result["accepted"] = dict(accepted)
        timeout = getattr(args, "wait_timeout", None)
        if timeout != 0:
            done.wait(timeout)
        if fmt == "text" and result["text"]:
            print()
        if fmt == "json":
            output_payload(result, fmt="json")
        return result
    finally:
        runner.stop()
