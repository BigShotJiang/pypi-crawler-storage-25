import os
import subprocess
import sys
from collections.abc import Callable

from codex_agent.client import AgentClient
from codex_agent.service import SERVER_SERVICE_NAME, TRAY_SERVICE_NAME, service_controller
from codex_agent.utils import ensure_runtime_dir, project_python_env, runtime_join


SERVICE_UNITS = {
    "server": SERVER_SERVICE_NAME,
    "tray": TRAY_SERVICE_NAME,
}
OPEN_INTERFACES = {"tui"}
CLOSE_INTERFACES = {"tui"}
ROOT_COMMANDS = {
    "local", "chat", "run", "prompt", "status", "tools", "sessions", "config", "interrupt",
    "install-service", "uninstall-service", "install-system-deps", "bootstrap",
    "start", "stop", "restart", "open", "close",
}


def build_root_parser():
    import argparse

    parser = argparse.ArgumentParser(
        prog="codex-agent",
        description="Codex Agent command line interface",
        epilog=(
            "Examples:\n"
            "  codex-agent run 'summarize this repository'\n"
            "  codex-agent run --stdin --format ndjson\n"
            "  codex-agent status --json\n"
            "  codex-agent start server\n"
            "  codex-agent open tui"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "command",
        nargs="?",
        choices=sorted(ROOT_COMMANDS),
        default="local",
        help=(
            "Agent command. Use start/stop/restart for services, open/close for interfaces, "
            "run/prompt for headless prompts, or chat/local for interactive use."
        ),
    )
    parser.add_argument("args", nargs="*", help="Arguments forwarded to the selected command.")
    parser.add_argument("--version", action="store_true", help="Print version and exit.")
    return parser


def print_root_help():
    build_root_parser().print_help()


def _base_url(host="127.0.0.1", port=8765, url=None):
    return url or f"http://{host}:{port}"


def _parse_connection_args(args):
    import argparse

    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--url", default=None)
    parser.add_argument("--foreground", action="store_true", help=argparse.SUPPRESS)
    return parser.parse_known_args(args)


def _start_log_file(name):
    ensure_runtime_dir()
    logs_dir = runtime_join("logs")
    os.makedirs(logs_dir, exist_ok=True)
    return runtime_join("logs", f"{name}.log")


def _detached_start(name, args):
    log_path = _start_log_file(name)
    command = [sys.executable, "-m", "codex_agent", "start", name, *args, "--foreground"]
    with open(log_path, "ab", buffering=0) as log:
        process = subprocess.Popen(
            command,
            stdin=subprocess.DEVNULL,
            stdout=log,
            stderr=subprocess.STDOUT,
            cwd=os.getcwd(),
            env=project_python_env(),
            start_new_session=True,
            close_fds=True,
        )
    print(f"Started {name} in background with PID {process.pid}. Logs: {log_path}")
    return process


def start_service(name, args):
    parsed, extra = _parse_connection_args(args)
    if extra:
        raise SystemExit(f"unrecognized arguments: {' '.join(extra)}")
    if name == "server":
        if parsed.foreground:
            from .main import run_server
            run_server(parsed.host, parsed.port)
        else:
            forwarded = ["--host", parsed.host, "--port", str(parsed.port)]
            _detached_start(name, forwarded)
        return
    if name == "tray":
        base_url = _base_url(parsed.host, parsed.port, parsed.url)
        if parsed.foreground:
            from .main import run_tray_mode
            run_tray_mode(base_url)
        else:
            _detached_start(name, ["--url", base_url])
        return
    raise SystemExit(f"usage: codex-agent start {{{','.join(SERVICE_UNITS)}}}")


def stop_service(name, args=None):
    if name not in SERVICE_UNITS:
        raise SystemExit(f"usage: codex-agent stop {{{','.join(SERVICE_UNITS)}}}")
    service_controller().run("stop", SERVICE_UNITS[name], check=False)


def restart_service(name, args=None):
    if name not in SERVICE_UNITS:
        raise SystemExit(f"usage: codex-agent restart {{{','.join(SERVICE_UNITS)}}}")
    service_controller().restart(SERVICE_UNITS[name], check=False)


def open_interface(name, args):
    if name != "tui":
        raise SystemExit("usage: codex-agent open {tui}")
    parsed, extra = _parse_connection_args(args)
    if extra:
        raise SystemExit(f"unrecognized arguments: {' '.join(extra)}")
    payload = AgentClient(_base_url(parsed.host, parsed.port, parsed.url)).open_tui()
    opened = payload.get("opened") if isinstance(payload, dict) else None
    if opened is False and isinstance(payload, dict) and payload.get("already_open"):
        print("TUI already open")
    else:
        print("TUI open requested")


def close_interface(name, args):
    if name != "tui":
        raise SystemExit("usage: codex-agent close {tui}")
    parsed, extra = _parse_connection_args(args)
    if extra:
        raise SystemExit(f"unrecognized arguments: {' '.join(extra)}")
    AgentClient(_base_url(parsed.host, parsed.port, parsed.url)).close_tui()
    print("TUI close requested")


def dispatch(argv, *, fallback: Callable[[list[str]], None]):
    args = list(sys.argv[1:] if argv is None else argv)
    if not args:
        fallback([])
        return
    if args[0] in {"-h", "--help"}:
        print_root_help()
        return
    if args[0] == "start":
        if len(args) < 2:
            raise SystemExit(f"usage: codex-agent start {{{','.join(SERVICE_UNITS)}}}")
        start_service(args[1], args[2:])
        return
    if args[0] == "stop":
        if len(args) < 2:
            raise SystemExit(f"usage: codex-agent stop {{{','.join(SERVICE_UNITS)}}}")
        stop_service(args[1], args[2:])
        return
    if args[0] == "restart":
        if len(args) < 2:
            raise SystemExit(f"usage: codex-agent restart {{{','.join(SERVICE_UNITS)}}}")
        restart_service(args[1], args[2:])
        return
    if args[0] == "open":
        if len(args) < 2:
            raise SystemExit("usage: codex-agent open {tui}")
        open_interface(args[1], args[2:])
        return
    if args[0] == "close":
        if len(args) < 2:
            raise SystemExit("usage: codex-agent close {tui}")
        close_interface(args[1], args[2:])
        return
    if args[0] in SERVICE_UNITS:
        print(
            f"error: service '{args[0]}' must be managed with 'codex-agent start {args[0]}' or 'codex-agent stop {args[0]}'",
            file=sys.stderr,
        )
        raise SystemExit(2)
    if args[0] in OPEN_INTERFACES:
        print(
            f"error: interface '{args[0]}' must be opened with 'codex-agent open {args[0]}'",
            file=sys.stderr,
        )
        raise SystemExit(2)
    fallback(args)
