import json
import sys


def dump_json(payload, *, stream=None):
    print(json.dumps(payload, ensure_ascii=False, indent=2, default=str), file=stream or sys.stdout)


def dump_ndjson(payload, *, stream=None):
    print(json.dumps(payload, ensure_ascii=False, default=str), file=stream or sys.stdout, flush=True)


def output_payload(payload, *, fmt="text", text_formatter=None):
    if fmt == "json":
        dump_json(payload)
        return
    if fmt == "ndjson":
        dump_ndjson(payload)
        return
    if text_formatter is not None:
        text = text_formatter(payload)
    else:
        text = str(payload)
    if text:
        print(text)


def key_value_text(payload):
    if not isinstance(payload, dict):
        return str(payload)
    return "\n".join(f"{key}: {value}" for key, value in payload.items())
