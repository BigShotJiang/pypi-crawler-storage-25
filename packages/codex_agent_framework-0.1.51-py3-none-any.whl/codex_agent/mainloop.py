import concurrent.futures
import contextvars
import json
import queue
import time
from threading import Event as ThreadEvent, Lock, Thread as BackgroundThread, get_ident

from modict import modict

from .command import (
    TURN_OUTCOME_TYPE,
    TURN_REASON_COMPLETED,
    TURN_REASON_ERROR,
    TURN_REASON_INTERRUPTED,
    TURN_REASON_REQUIRES_NEXT_STEP,
    TURN_REASON_RESULT_SET,
    AgentCommand,
    AgentFuture,
    AgentTurn,
)
from .event import (
    AssistantInterrupted,
    AssistantStepEndEvent,
    AssistantStepStartEvent,
    AssistantTurnEndEvent,
    AssistantTurnErrorEvent,
    AssistantTurnStartEvent,
    MessageSubmittedEvent,
    ToolCallDoneEvent,
    ToolCallStartEvent,
)
from .message import InterruptMessage, Message, ToolResultMessage, ToolResultWrapper, UserMessage
from .tool import reset_current_agent, reset_current_call_id, set_current_agent, set_current_call_id
from .utils import timestamp


class MainLoopManager:
    def __init__(self, agent):
        self.agent = agent
        self.command_queue = queue.Queue()
        self.futures = modict()
        self.thread = None
        self.thread_id = None
        self.running = ThreadEvent()
        self.current_future = None
        self.pending = []
        self.pending_lock = Lock()
        self.dumping_pending = False
        self.require_next_step = False
        self.stop_agentic_loop = False
        self.turn_result_set = False
        self.turn_result = None
        self.activity_phase = "idle"
        self.activity_detail = ""
        self.activity_started_at = None
        self.activity_updated_at = None

    def set_activity(self, phase, detail=""):
        now = time.time()
        if self.activity_phase != phase or self.activity_detail != detail:
            self.activity_started_at = now
        self.activity_phase = phase or "idle"
        self.activity_detail = detail or ""
        self.activity_updated_at = now
        return self

    def touch_activity(self, phase=None, detail=None):
        if phase is not None or detail is not None:
            return self.set_activity(
                phase if phase is not None else self.activity_phase,
                detail if detail is not None else self.activity_detail,
            )
        self.activity_updated_at = time.time()
        return self

    def clear_activity(self):
        self.activity_phase = "idle"
        self.activity_detail = ""
        self.activity_started_at = None
        self.activity_updated_at = None
        return self

    def activity_timeout(self):
        if self.activity_phase == "tool_call":
            return float(self.agent.config.get("tool_call_timeout", 0) or 0)
        return float(self.agent.config.get("codex_stream_idle_timeout", 0) or 0)

    def activity_status(self):
        now = time.time()
        updated_at = self.activity_updated_at
        started_at = self.activity_started_at
        timeout = self.activity_timeout()
        idle_for = (now - updated_at) if updated_at else 0
        return modict(
            phase=self.activity_phase,
            detail=self.activity_detail,
            started_at=started_at,
            updated_at=updated_at,
            age_seconds=(now - started_at) if started_at else 0,
            idle_seconds=idle_for,
            stalled=bool(self.busy and timeout > 0 and idle_for > timeout),
            stall_timeout=timeout,
        )

    @property
    def busy(self):
        return any(
            future.command in ("turn", "command") and future.status in ("pending", "running")
            for future in self.futures.values()
        )

    @property
    def current_turn_id(self):
        if self.current_future is not None:
            return self.current_future.id
        for future in self.futures.values():
            if future.command in ("turn", "command") and future.status in ("pending", "running"):
                return future.id
        return None

    def start(self):
        if self.thread and self.thread.is_alive():
            return self.agent
        self.running.set()
        self.thread = BackgroundThread(target=self.mainloop, daemon=True)
        self.thread.start()
        self.agent.scheduler.start()
        self.agent.plugins_manager.start()
        return self.agent

    def stop(self, timeout=None):
        if not self.thread:
            return self.agent
        self.running.clear()
        self.agent.scheduler.stop(timeout=timeout)
        self.agent.plugins_manager.stop(timeout=timeout)
        self.command_queue.put((AgentCommand(name="stop"), None))
        self.thread.join(timeout)
        return self.agent

    def submit(self, command, **payload):
        self.start()
        agent_command = command if isinstance(command, AgentCommand) else AgentCommand(name=command, payload=payload)
        turn = payload.pop("turn", None)
        future = AgentFuture(command_id=agent_command.id, command=agent_command.name)
        future.turn = self.prepare_turn(future, agent_command, turn=turn)
        future.set_manager(self)
        self.futures[future.id] = future
        self.command_queue.put((agent_command, future))
        return future

    def prepare_turn(self, future, command, turn=None):
        if turn is None:
            message_start = len(self.agent.session.messages) if getattr(self.agent, "session", None) is not None else 0
            return AgentTurn(
                id=future.id,
                command_id=command.id,
                command=command.name,
                session_id=getattr(self.agent, "current_session_id", ""),
                message_start=message_start,
                message_end=message_start,
            )
        future.id = turn.id
        turn.status = "pending"
        turn.command_id = command.id
        return turn

    def start_turn(self):
        if self.busy:
            return None
        return self.submit("turn")

    def resume_turn(self, turn):
        if self.busy:
            return None
        if turn is None or turn.completed:
            raise ValueError("Only an incomplete AgentTurn can be resumed")
        future = self.submit("turn", resume=True, turn=turn)
        future.set_attr("explicit_turn_result", bool(turn.result is not None and turn.reason == "result_set"))
        return future

    def submit_message(self, message):
        hook = self.agent.run_hook("message.submit.before", message=message)
        message = hook.payload.message
        message = self.agent.add_message(message)
        future = None if self.busy else self.start_turn()
        turn_id = future.id if future is not None else self.current_turn_id
        self.agent.emit(MessageSubmittedEvent, message=message, turn_id=turn_id)
        self.agent.run_hook("message.submit.after", message=message, turn_id=turn_id)
        return modict(message=message, turn_id=turn_id)

    def in_thread(self):
        return self.thread_id == get_ident()

    def should_queue_state_command(self):
        return (
            self.thread is not None
            and self.thread.is_alive()
            and not self.in_thread()
        )

    def mainloop(self):
        self.thread_id = get_ident()
        try:
            while self.running.is_set():
                command, future = self.command_queue.get()
                if command.name == "stop":
                    if future:
                        future.set_result(True)
                    break
                self.run_command_item(command, future)
        finally:
            self.thread_id = None

    def record_event(self, event):
        turn_id = event.get("turn_id") if hasattr(event, "get") else None
        future = self.futures.get(turn_id) if turn_id else self.current_future
        if future is not None and hasattr(future, "record_event"):
            future.record_event(event)
        return event

    def run_command_item(self, command, future):
        if future:
            self.current_future = future
            future.start()
        try:
            result = self.run_command(command)
        except Exception as exc:
            if future:
                future.set_error(exc)
            else:
                raise
        else:
            if future:
                future.set_result(result)
            return result
        finally:
            if self.current_future is future:
                self.current_future = None
            if future and future.command in ("turn", "command"):
                self.clear_activity()

    def run_command(self, command):
        self.agent.run_hook("command.run.before", command=command)
        if command.name == "turn":
            result = self.run_agentic_turn(resume=command.payload.get("resume", False))
            self.agent.run_hook("command.run.after", command=command, result=result)
            return result
        if command.name == "command":
            hook = self.agent.run_hook("command.prompt.before", prompt=command.payload.prompt, command=command)
            result = self.agent.command_manager.run_turn(hook.payload.prompt)
            self.agent.run_hook("command.run.after", command=command, result=result)
            return result
        if command.name == "load_session":
            return self.agent.load_session(command.payload.session)
        if command.name == "start_new_session":
            return self.agent.start_new_session(
                root_dir=command.payload.get("root_dir"),
                cwd=command.payload.get("cwd"),
            )
        if command.name == "delete_session":
            return self.agent.delete_session(command.payload.session)
        if command.name == "navigate_session":
            return self.agent.navigate_session(command.payload.direction)
        if command.name == "update_config":
            return self.agent.config_manager.update(
                command.payload.get("config"),
                save=command.payload.get("save", True),
                **command.payload.get("kwargs", {}),
            )
        if command.name == "save_config":
            return self.agent.config_manager.save()
        if command.name == "save_session":
            return self.agent.save_session()
        if command.name == "compact_session":
            return self.agent.compact_session(**command.payload)
        if command.name == "add_tool":
            return self.agent.add_tool(**command.payload)
        if command.name == "add_provider":
            return self.agent.add_provider(**command.payload)
        if command.name == "add_command":
            return self.agent.add_command(**command.payload)
        if command.name == "add_hook":
            return self.agent.add_hook(**command.payload)
        if command.name == "schedule_wakeup":
            return self.agent.scheduler.schedule(**command.payload)
        if command.name == "cancel_wakeup":
            return self.agent.scheduler.cancel(command.payload.job_id)
        if command.name == "delete_wakeup":
            return self.agent.scheduler.delete(command.payload.job_id)
        raise ValueError(f"Unknown agent command: {command.name}")

    def request_next_step(self):
        self.require_next_step = True
        return True

    def stop_loop_after_current_step(self):
        self.stop_agentic_loop = True
        return True

    def set_turn_result(self, data):
        if self.current_future is None:
            raise RuntimeError("No active agent turn is available")
        self.turn_result = data
        self.turn_result_set = True
        self.current_future.set_attr("explicit_turn_result", True)
        self.current_future.result = data
        self.current_future.turn.result = data
        self.stop_loop_after_current_step()
        return data

    def add_pending_message(self, msg):
        with self.pending_lock:
            self.pending.append(msg)
        return msg

    def dump_pending(self):
        with self.pending_lock:
            pending = self.pending
            self.pending = []
        self.dumping_pending = True
        try:
            for msg in pending:
                msg.timestamp = timestamp()
                self.agent.sessions_manager.append_message(msg)
        finally:
            self.dumping_pending = False

    def age_context_messages(self):
        aged = False
        for msg in self.agent.session.messages:
            turns_left = msg.get("turns_left", -1)
            if isinstance(turns_left, int) and turns_left > 0:
                msg.turns_left = turns_left - 1
                aged = True
        if aged:
            self.agent.save_session()

    def run_agentic_turn(self, resume=False):
        return self.process(resume=resume)

    def turn_outcome(self, completed, reason, result=None):
        return modict(type=TURN_OUTCOME_TYPE, completed=completed, reason=reason, result=result)

    def finish_turn(self, reason, message=None, result=None):
        self.agent.emit(AssistantTurnEndEvent, prompt=None, message=message, reason=reason)
        return self.turn_outcome(completed=True, reason=reason, result=result)

    def process(self, resume=False):
        self.agent.clear_interrupt()
        if not resume:
            self.agent.emit(AssistantTurnStartEvent, prompt=None)
            self.age_context_messages()
            self.turn_result_set = False
            self.turn_result = None
        self.stop_agentic_loop = False
        turn_message = None
        try:
            while True:
                self.agent.check_interrupt()
                self.dump_pending()
                message = None
                called_tools = False
                self.require_next_step = False
                self.set_activity("response", "waiting for Codex backend")
                self.agent.emit(AssistantStepStartEvent)
                try:
                    message = self.agent.get_response()
                    turn_message = message
                    self.agent.check_interrupt()
                    called_tools = self.call_tools(message)
                    self.dump_pending()
                finally:
                    self.agent.emit(
                        AssistantStepEndEvent,
                        message=message,
                        called_tools=called_tools,
                        require_next_step=self.require_next_step,
                        stop_agentic_loop=self.stop_agentic_loop,
                    )

                if self.turn_result_set:
                    return self.finish_turn(TURN_REASON_RESULT_SET, message=turn_message, result=self.turn_result)
                if self.require_next_step and not self.stop_agentic_loop:
                    if self.agent.config.auto_proceed:
                        continue
                    return self.turn_outcome(completed=False, reason=TURN_REASON_REQUIRES_NEXT_STEP)
                return self.finish_turn(TURN_REASON_COMPLETED, message=turn_message)
        except AssistantInterrupted:
            self.dump_pending()
            self.agent.sessions_manager.append_message(InterruptMessage())
            return self.finish_turn(TURN_REASON_INTERRUPTED, message=turn_message)
        except Exception as exc:
            self.agent.emit(AssistantTurnErrorEvent, prompt=None, message=turn_message, error=str(exc))
            self.agent.emit(AssistantTurnEndEvent, prompt=None, message=turn_message, reason=TURN_REASON_ERROR)
            raise

    def call_tools(self, message):
        called_tools = False
        if message.get("tool_calls"):
            tool_calls = list(message.tool_calls)
            for index, tool_call in enumerate(tool_calls):
                tool = self.agent.tools.get(tool_call.name)
                self.set_activity("tool_call", tool_call.name)
                self.agent.emit(ToolCallStartEvent, tool_call=tool_call, tool=tool)
                status = "success"
                if tool and tool.type == "tool":
                    self.require_next_step = True
                    agent_context = set_current_agent(self.agent)
                    call_id_context = set_current_call_id(tool_call.call_id)
                    try:
                        if tool_call.get("type") == "custom_tool_call":
                            args = [tool_call.get("input", "")]
                            kwargs = {}
                        else:
                            args = []
                            kwargs = json.loads(tool_call.arguments)
                        hook = self.agent.run_hook("tool.call.before", tool=tool, tool_call=tool_call, args=args, kwargs=kwargs)
                        args = hook.payload.args
                        kwargs = hook.payload.kwargs
                        output = self.invoke_tool(tool, args, kwargs)
                        hook = self.agent.run_hook("tool.call.after", tool=tool, tool_call=tool_call, output=output, status=status)
                        output = hook.payload.output
                    except Exception as exc:
                        status = "failure"
                        output = f"Error: {str(exc)}"
                        self.agent.run_hook("tool.call.error", tool=tool, tool_call=tool_call, error=exc)
                    finally:
                        reset_current_call_id(call_id_context)
                        reset_current_agent(agent_context)
                else:
                    self.require_next_step = True
                    status = "failure"
                    output = f"Error: Tool '{tool_call.name}' not found."
                call_wrappers = self.tool_output_wrappers(output, tool_call, status=status)
                content = "\n".join(str(wrapper.get("content") or "") for wrapper in call_wrappers)
                self.agent.emit(ToolCallDoneEvent, tool_call=tool_call, tool=tool, content=content)
                summary = self.tool_output_summary(tool_call, call_wrappers, status=status)
                self.agent.add_message(ToolResultMessage(
                    name=tool_call.name,
                    call_id=tool_call.call_id,
                    content=summary,
                    tool_call_type=tool_call.get("type"),
                ))
                for wrapper in call_wrappers:
                    self.agent.add_message(wrapper, pending=True)
                called_tools = True
                if self.agent.is_interrupted():
                    self.stop_agentic_loop = True
                    self.add_interrupted_tool_results(tool_calls[index + 1:])
                    self.agent.check_interrupt()
        return called_tools

    def invoke_tool(self, tool, args, kwargs):
        timeout = float(self.agent.config.get("tool_call_timeout", 0) or 0)
        if timeout <= 0:
            return tool(*args, **kwargs)

        context = contextvars.copy_context()
        executor = concurrent.futures.ThreadPoolExecutor(max_workers=1, thread_name_prefix=f"tool-{tool.name}")
        future = executor.submit(context.run, tool, *args, **kwargs)
        try:
            return future.result(timeout=timeout)
        except concurrent.futures.TimeoutError as exc:
            future.cancel()
            raise TimeoutError(f"Tool '{tool.name}' did not finish before {timeout:g}s") from exc
        finally:
            executor.shutdown(wait=False, cancel_futures=True)

    def add_interrupted_tool_results(self, tool_calls):
        for tool_call in tool_calls:
            self.agent.add_message(ToolResultMessage(
                name=tool_call.name,
                call_id=tool_call.call_id,
                content="interrupted: tool call was not started because the assistant turn was interrupted.",
                tool_call_type=tool_call.get("type"),
            ))

    def tool_output_wrappers(self, output, tool_call, status="success"):
        items = output if isinstance(output, list) else [output]

        wrappers = []
        for item in items:
            if isinstance(item, ToolResultWrapper):
                wrapper = item
                if not wrapper.get("call_id"):
                    wrapper.call_id = tool_call.call_id
                if not wrapper.get("tool_name"):
                    wrapper.tool_name = tool_call.name
                if not wrapper.get("status"):
                    wrapper.status = status
            elif isinstance(item, Message):
                wrapper = item
            else:
                wrapper = ToolResultWrapper(
                    tool_name=tool_call.name,
                    call_id=tool_call.call_id,
                    status=status,
                    content=str(item),
                )
            wrappers.append(wrapper)
        return wrappers

    def tool_output_summary(self, tool_call, wrappers, status="success"):
        if len(wrappers) == 1:
            wrapper = wrappers[0]
            kind = type(wrapper).__name__
            return (
                f"{status}: call_id={tool_call.call_id}; "
                f"full output in {kind} id={wrapper.id}."
            )
        if all(isinstance(wrapper, ToolResultWrapper) for wrapper in wrappers):
            wrapper_ids = ", ".join(wrapper.id for wrapper in wrappers)
            return (
                f"{status}: call_id={tool_call.call_id}; "
                f"{len(wrappers)} outputs in ToolResultWrapper ids={wrapper_ids}."
            )
        wrapper_refs = ", ".join(f"{type(wrapper).__name__}:{wrapper.id}" for wrapper in wrappers)
        return (
            f"{status}: call_id={tool_call.call_id}; "
            f"{len(wrappers)} outputs in pending messages ids={wrapper_refs}."
        )

    def call(self, prompt=None):
        mainloop_was_running = self.thread is not None and self.thread.is_alive()
        if prompt is None:
            future = self.start_turn()
        elif self.agent.command_manager.is_prompt(prompt):
            future = self.agent.submit_command(prompt)
        else:
            result = self.agent.submit_message(UserMessage(content=prompt))
            future = self.futures[result.turn_id]
        if future is None:
            return None
        try:
            return future.wait()
        finally:
            if not mainloop_was_running:
                self.agent.stop(timeout=1.0)
