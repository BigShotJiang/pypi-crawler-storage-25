import json
import os
import shutil
from datetime import datetime
from typing import List

from codex_backend_sdk import CodexClient
from modict import modict

from .event import (
    CompactionCompletedEvent,
    CompactionFailedEvent,
    CompactionRequestedEvent,
    MessageAddedEvent,
    SessionDeletedEvent,
    SessionLoadedEvent,
)
from .message import (
    AssistantMessage,
    CompactionMessage,
    DeveloperMessage,
    Message,
    SystemMessage,
    ToolResultMessage,
    ToolResultWrapper,
    message_from_data,
)
from .utils import (
    atomic_write_json,
    runtime_join,
    session_id,
    sort,
    split_history_turns,
    timestamp,
    total_tokens,
    truncate,
)


UNRESOLVED_TOOL_RESULT_CONTENT = (
    "This tool call could not be resolved or has been interrupted: result unavailable."
)
DEFAULT_COMPACTION_MAX_INPUT_TOKENS = 8000


class AgentSession(modict):
    session_id: str = modict.factory(session_id)
    root_dir: str = ""
    cwd: str = ""
    messages: List[Message] = modict.factory(list)

    @modict.computed(deps=["session_id"])
    def session_file(self):
        return runtime_join("sessions", f"{self.session_id}.json")

    @modict.computed(deps=["session_id"])
    def api_success_backup_file(self):
        return runtime_join("sessions", f"{self.session_id}.api_success_backup")

    def as_string(self):
        return "\n\n".join(message.as_string() for message in self.messages)

    def latest_compaction_index(self):
        for index in range(len(self.messages) - 1, -1, -1):
            if isinstance(self.messages[index], CompactionMessage):
                return index
        return None

    def context_messages(self):
        index = self.latest_compaction_index()
        return self.messages[index:] if index is not None else self.messages

    def is_message_visible_in_context(self, message):
        return message.get("turns_left", -1) != 0

    def truncate_message_for_compaction(
        self,
        message,
        max_input_tokens=DEFAULT_COMPACTION_MAX_INPUT_TOKENS,
        model=None,
    ):
        message = message.copy()
        if message.get("content") and isinstance(message.content, str):
            message.content = truncate(message.content, max_tokens=max_input_tokens, model=model)
        return message

    def compaction_plan(
        self,
        max_input_tokens=DEFAULT_COMPACTION_MAX_INPUT_TOKENS,
        model=None,
        max_compacted_turns=None,
    ):
        compaction_index = self.latest_compaction_index()
        start = compaction_index + 1 if compaction_index is not None else 0
        anchor = self.messages[compaction_index] if compaction_index is not None else None
        source_messages = self.messages[start:]
        messages = [
            message for message in source_messages
            if self.is_message_visible_in_context(message)
            and not isinstance(message, ToolResultWrapper)
        ]
        turns, remainder = split_history_turns(messages)
        if max_compacted_turns is not None:
            max_compacted_turns = max(0, int(max_compacted_turns))
            selected_turns = turns[:max_compacted_turns]
        else:
            selected_turns = turns
        preserved_turns = turns[len(selected_turns):]
        compacted_messages = [message for turn in selected_turns for message in turn]
        compacted_source_end = start
        if compacted_messages:
            last_compacted = compacted_messages[-1]
            for index, message in enumerate(self.messages[start:], start=start):
                if message is last_compacted:
                    compacted_source_end = index + 1
                    break
        preserved_messages = [
            message for message in self.messages[compacted_source_end:]
            if self.is_message_visible_in_context(message)
        ]
        history_messages = ([anchor] if anchor is not None else []) + [
            self.truncate_message_for_compaction(message, max_input_tokens=max_input_tokens, model=model)
            for message in compacted_messages
        ]
        return modict(
            start=start,
            anchor=anchor,
            messages=messages,
            turns=turns,
            selected_turns=selected_turns,
            preserved_turns=preserved_turns,
            compacted_messages=compacted_messages,
            compacted_source_end=compacted_source_end,
            history_messages=history_messages,
            remainder=remainder,
            preserved_messages=preserved_messages,
            max_compacted_turns=max_compacted_turns,
            completed_turn_count=len(turns),
            compacted_turn_count=len(selected_turns),
            preserved_turn_count=len(preserved_turns),
            compacted_message_count=len(compacted_messages),
            compacted_token_count=total_tokens(
                history_messages[1:] if anchor is not None else history_messages,
                model=model,
            ),
            context_message_count=len(history_messages) + len(preserved_messages),
        )

    def compact(
        self,
        client=None,
        model="gpt-5.4",
        instructions="",
        max_input_tokens=DEFAULT_COMPACTION_MAX_INPUT_TOKENS,
        max_compacted_turns=None,
    ):
        plan = self.compaction_plan(
            max_input_tokens=max_input_tokens,
            model=model,
            max_compacted_turns=max_compacted_turns,
        )
        compacted_messages = plan.compacted_messages
        if not compacted_messages:
            return None

        history = self.messages_to_response_history(plan.history_messages)
        client = client or CodexClient(model=model, instructions=instructions).authenticate()
        result = client.responses.compact(
            input=history,
            model=model,
            instructions=instructions,
        )
        message = CompactionMessage(
            response_id=result.id,
            summaries=CompactionMessage.summary_items(result.output),
            compacted_message_count=len(compacted_messages),
            compacted_turn_count=plan.compacted_turn_count,
            preserved_turn_count=plan.preserved_turn_count,
            completed_turn_count=plan.completed_turn_count,
            max_compacted_turns=plan.max_compacted_turns,
        )

        previous_anchor = [plan.anchor] if plan.anchor is not None else []
        self.messages = previous_anchor + [message] + list(plan.preserved_messages)
        self.save()
        return message

    def messages_to_response_history(self, messages):
        history = []
        for message in messages:
            item = message.to_response_format()
            if item is None:
                continue
            if isinstance(item, list):
                for subitem in item:
                    self.append_response_history_item(history, subitem)
            else:
                self.append_response_history_item(history, item)
        self.close_orphaned_tool_calls(history)
        return history

    def prune_orphaned_tool_outputs(self):
        history = []
        kept = []
        removed = []
        for message in self.messages:
            item = message.to_response_format()
            if item is None:
                kept.append(message)
                continue

            items = item if isinstance(item, list) else [item]
            if any(self.is_orphaned_response_tool_output(history, subitem) for subitem in items):
                removed.append(message)
                continue

            for subitem in items:
                self.append_response_history_item(history, subitem)
            kept.append(message)

        if removed:
            self.messages = kept
            self.save()
        return removed

    def append_response_history_item(self, history, item):
        if self.is_orphaned_response_tool_output(history, item):
            return
        self.close_orphaned_tool_calls(history, before=item)
        history.append(item)

    def is_orphaned_response_tool_output(self, history, item):
        if not self.is_response_tool_output(item):
            return False
        call_id = item.get("call_id")
        return not call_id or call_id not in self.pending_response_tool_calls(history)

    def close_orphaned_tool_calls(self, history, before=None):
        pending = self.pending_response_tool_calls(history)
        if not pending:
            return
        if before and self.is_response_tool_boundary(before):
            return
        for call_id, tool_type in pending.items():
            if tool_type == "custom_tool_call":
                history.append({
                    "type": "custom_tool_call_output",
                    "call_id": call_id,
                    "output": "Tool call was interrupted before an output was recorded.",
                })
            else:
                history.append({
                    "type": "function_call_output",
                    "call_id": call_id,
                    "output": "Tool call was interrupted before an output was recorded.",
                })

    def pending_response_tool_calls(self, history):
        pending = {}
        for item in history:
            item_type = item.get("type")
            if item_type in ("function_call", "custom_tool_call"):
                pending[item.get("call_id")] = item_type
            elif item_type in ("function_call_output", "custom_tool_call_output"):
                pending.pop(item.get("call_id"), None)
        return pending

    def is_response_tool_output(self, item):
        return item.get("type") in ("function_call_output", "custom_tool_call_output")

    def is_response_tool_boundary(self, item):
        return item.get("type") in (
            "function_call",
            "custom_tool_call",
            "function_call_output",
            "custom_tool_call_output",
        )

    def is_sane(self):
        return not self.sanity_issues()

    def sanity_issues(self):
        issues = []
        seen_non_system = False
        seen_call_ids = set()
        pending = modict()

        for index, message in enumerate(self.messages):
            if isinstance(message, SystemMessage):
                if seen_non_system:
                    issues.append(modict(
                        code="system_message_after_prefix",
                        index=index,
                        message_id=message.id,
                    ))
                continue

            seen_non_system = True

            if isinstance(message, ToolResultMessage):
                call_id = message.get("call_id")
                if not call_id:
                    issues.append(modict(
                        code="tool_result_missing_call_id",
                        index=index,
                        message_id=message.id,
                    ))
                    continue
                if call_id not in pending:
                    issues.append(modict(
                        code="orphaned_tool_result",
                        index=index,
                        message_id=message.id,
                        call_id=call_id,
                    ))
                    continue

                expected_type = pending[call_id].tool_call_type
                actual_type = message.get("tool_call_type") or "function_call"
                if actual_type != expected_type:
                    issues.append(modict(
                        code="tool_result_type_mismatch",
                        index=index,
                        message_id=message.id,
                        call_id=call_id,
                        expected=expected_type,
                        actual=actual_type,
                    ))
                pending.pop(call_id, None)
                continue

            if pending:
                issues.append(modict(
                    code="unresolved_tool_calls_before_message",
                    index=index,
                    message_id=message.id,
                    pending_call_ids=list(pending.keys()),
                ))
                pending.clear()

            if not isinstance(message, AssistantMessage) or not message.get("tool_calls"):
                continue

            local_call_ids = set()
            for tool_call in message.get("tool_calls") or []:
                call_id = tool_call.get("call_id")
                tool_call_type = tool_call.get("type") or "function_call"
                if tool_call_type not in ("function_call", "custom_tool_call"):
                    issues.append(modict(
                        code="unsupported_tool_call_type",
                        index=index,
                        message_id=message.id,
                        call_id=call_id or "",
                        tool_call_type=tool_call_type,
                    ))
                if not call_id:
                    issues.append(modict(
                        code="tool_call_missing_call_id",
                        index=index,
                        message_id=message.id,
                        tool_call_type=tool_call_type,
                    ))
                    continue
                if call_id in seen_call_ids or call_id in local_call_ids:
                    issues.append(modict(
                        code="duplicate_tool_call_id",
                        index=index,
                        message_id=message.id,
                        call_id=call_id,
                    ))
                    continue
                local_call_ids.add(call_id)
                pending[call_id] = modict(
                    index=index,
                    message_id=message.id,
                    tool_call_type=tool_call_type,
                )
            seen_call_ids.update(local_call_ids)

        for call_id, pending_call in pending.items():
            issues.append(modict(
                code="unresolved_tool_call",
                index=pending_call.index,
                message_id=pending_call.message_id,
                call_id=call_id,
            ))
        return issues

    def session_payload(self):
        return modict(
            session_id=self.session_id,
            root_dir=self.root_dir,
            cwd=self.cwd,
            messages=self.messages,
        )

    def write_messages_file(self, path):
        return atomic_write_json(path, self.session_payload())

    def save(self):
        self.write_messages_file(self.session_file)

    def save_api_success_backup(self):
        return self.write_messages_file(self.api_success_backup_file)

    def save_broken_backup(self):
        if not os.path.isfile(self.session_file):
            return ""
        backup_file = f"{self.session_file}.broken_{timestamp()}"
        shutil.copy2(self.session_file, backup_file)
        return backup_file

    def restore_api_success_backup(self):
        if not os.path.isfile(self.api_success_backup_file):
            return False
        with open(self.api_success_backup_file, encoding="utf-8") as f:
            data = json.load(f)
        session = self.from_payload(data, session_id_value=self.session_id)
        self.root_dir = session.root_dir
        self.cwd = session.cwd
        self.messages = session.messages
        self.save()
        return True

    def repair(self, save=True, backup=True):
        issues = self.sanity_issues()
        if not issues:
            return modict(repaired=False, removed=0, added=0, backup_file="", issues=[])

        seen_call_ids = set()
        pending = modict()
        kept = []
        removed = []
        added = []

        def synthesize_pending_results():
            nonlocal pending
            if not pending:
                return
            for call_id, tool_call in pending.items():
                result = ToolResultMessage(
                    name=tool_call.tool_name,
                    call_id=call_id,
                    tool_call_type=tool_call.tool_call_type,
                    content=UNRESOLVED_TOOL_RESULT_CONTENT,
                    session_id=self.session_id,
                )
                kept.append(result)
                added.append(result)
            pending = modict()

        seen_non_system = False
        for index, message in enumerate(self.messages):
            if isinstance(message, SystemMessage):
                if seen_non_system:
                    removed.append(message)
                    continue
                kept.append(message)
                continue

            seen_non_system = True

            if isinstance(message, AssistantMessage) and message.get("tool_calls"):
                synthesize_pending_results()

                local_call_ids = set()
                valid_tool_calls = []
                for tool_call in message.get("tool_calls") or []:
                    call_id = tool_call.get("call_id")
                    tool_call_type = tool_call.get("type") or "function_call"
                    if (
                        not call_id
                        or call_id in seen_call_ids
                        or call_id in local_call_ids
                        or tool_call_type not in ("function_call", "custom_tool_call")
                    ):
                        removed.append(message)
                        break
                    local_call_ids.add(call_id)
                    valid_tool_calls.append(tool_call)
                if message in removed:
                    continue

                for tool_call in valid_tool_calls:
                    call_id = tool_call.get("call_id")
                    pending[call_id] = modict(
                        index=index,
                        message_id=message.id,
                        tool_name=tool_call.get("name", ""),
                        tool_call_type=tool_call.get("type") or "function_call",
                    )
                seen_call_ids.update(local_call_ids)
                kept.append(message)
                continue

            if isinstance(message, ToolResultMessage):
                call_id = message.get("call_id")
                if not call_id or call_id not in pending:
                    removed.append(message)
                    continue

                expected_type = pending[call_id].tool_call_type
                actual_type = message.get("tool_call_type") or "function_call"
                if actual_type != expected_type:
                    result = ToolResultMessage(
                        name=pending[call_id].tool_name,
                        call_id=call_id,
                        tool_call_type=expected_type,
                        content=UNRESOLVED_TOOL_RESULT_CONTENT,
                        session_id=self.session_id,
                    )
                    kept.append(result)
                    added.append(result)
                    pending.pop(call_id, None)
                    removed.append(message)
                    continue

                pending.pop(call_id, None)
                kept.append(message)
                continue

            if pending:
                synthesize_pending_results()

            kept.append(message)

        synthesize_pending_results()

        if not removed and not added:
            return modict(repaired=False, removed=0, added=0, backup_file="", issues=issues)

        backup_file = self.save_broken_backup() if backup else ""

        self.messages = kept
        if save:
            self.save()
        return modict(
            repaired=True,
            removed=len(removed),
            added=len(added),
            backup_file=backup_file,
            removed_message_ids=[message.id for message in removed],
            added_message_ids=[message.id for message in added],
            issues=issues,
        )

    def repair_interrupted_tool_call_tail(self, save=True, backup=True):
        return self.repair(save=save, backup=backup)

    def truncate_for_repair(self, index, save=True, backup=True):
        index = 0 if index is None else int(index)
        removed = self.messages[index:]
        if not removed:
            return modict(repaired=False, removed=0, index=index, backup_file="")

        backup_file = self.save_broken_backup() if backup else ""

        self.messages = self.messages[:index]
        if save:
            self.save()
        return modict(
            repaired=True,
            removed=len(removed),
            index=index,
            backup_file=backup_file,
            removed_message_ids=[message.id for message in removed],
        )

    @classmethod
    def session_path(cls, session):
        if os.path.isfile(str(session)):
            return str(session)
        return runtime_join("sessions", f"{session}.json")

    @classmethod
    def can_load(cls, session):
        path = cls.session_path(session)
        if not os.path.isfile(path):
            return False
        try:
            with open(path, "r", encoding="utf-8") as f:
                json.load(f)
        except (OSError, json.JSONDecodeError, TypeError):
            return False
        return True

    @classmethod
    def from_payload(cls, data, session_id_value=None):
        if isinstance(data, list):
            return cls(
                session_id=session_id_value or session_id(),
                messages=[message_from_data(msg) for msg in data],
            )
        if isinstance(data, dict):
            payload_session_id = data.get("session_id") or session_id_value or session_id()
            return cls(
                session_id=payload_session_id,
                root_dir=data.get("root_dir") or "",
                cwd=data.get("cwd") or "",
                messages=[message_from_data(msg) for msg in data.get("messages") or []],
            )
        raise TypeError(f"Unsupported session payload type: {type(data).__name__}")

    @classmethod
    def load(cls, session):
        path = cls.session_path(session)
        loaded_session_id = os.path.splitext(os.path.basename(path))[0]
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
            except json.JSONDecodeError as exc:
                raise ValueError(f"Session file is not valid JSON: {path}") from exc
            return cls.from_payload(data, session_id_value=loaded_session_id)
        raise ValueError(f"Session file not found: {path}")

    @classmethod
    def list_sessions(cls):
        session_folder = runtime_join("sessions")
        if not os.path.isdir(session_folder):
            return []
        session_ids = []
        for filename in os.listdir(session_folder):
            if not filename.endswith(".json"):
                continue
            session_id = filename.replace(".json", "")
            if cls.can_load(session_id):
                session_ids.append(session_id)
        return sorted(session_ids, reverse=True)

    @classmethod
    def delete(cls, session):
        if os.path.isfile(str(session)):
            path = str(session)
        else:
            path = runtime_join("sessions", f"{session}.json")
        if not os.path.isfile(path):
            raise ValueError(f"Session file not found: {path}")
        os.remove(path)
        return os.path.splitext(os.path.basename(path))[0]


class SessionsManager:
    def __init__(self, agent):
        self.agent = agent

    def init_folder(self):
        session_folder = runtime_join("sessions")
        if not os.path.isdir(session_folder):
            os.makedirs(session_folder, exist_ok=True)
        return session_folder

    def list(self):
        return AgentSession.list_sessions()

    def latest_id(self):
        sessions = self.list()
        return sessions[0] if sessions else None

    def load(self, session):
        if self.agent.mainloop_manager.should_queue_state_command():
            return self.agent.submit("load_session", session=session).wait().result
        if session == "latest":
            session = self.latest_id()
            if session is None:
                return self.start_new()
        self.agent.session = AgentSession.load(session)
        self.agent.apply_session_working_directories()
        repair = self.agent.session.repair()
        self.agent.current_session_id = self.agent.session.session_id
        if repair.repaired:
            self.agent.status_manager.invalidate_context_cache()
        self.append_message(
            DeveloperMessage(
                content=f"Resuming chat session at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}."
            )
        )
        self.agent.emit(
            SessionLoadedEvent,
            session=self.agent.session,
            session_id=self.agent.session.session_id,
        )
        return self.agent.session

    def start_new(self, root_dir=None, cwd=None):
        if self.agent.mainloop_manager.should_queue_state_command():
            return self.agent.submit("start_new_session", root_dir=root_dir, cwd=cwd).wait().result
        if root_dir is not None or cwd is not None:
            self.agent.init_working_directories(root_dir=root_dir or cwd, cwd=cwd)
        self.agent.session = AgentSession(
            root_dir=self.agent.config.root_dir,
            cwd=self.agent.config.cwd,
        )
        self.agent.apply_session_working_directories()
        self.agent.current_session_id = self.agent.session.session_id
        self.append_message(
            DeveloperMessage(
                content=f"Starting a new chat session at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}."
            )
        )
        self.agent.emit(
            SessionLoadedEvent,
            session=self.agent.session,
            session_id=self.agent.session.session_id,
        )
        return self.agent.session

    def delete(self, session):
        if self.agent.mainloop_manager.should_queue_state_command():
            return self.agent.submit("delete_session", session=session).wait().result
        deleted_id = AgentSession.delete(session)
        if deleted_id == self.agent.current_session_id:
            latest = self.latest_id()
            self.load(latest) if latest else self.start_new()
        self.agent.emit(SessionDeletedEvent, session_id=deleted_id)
        return deleted_id

    def navigate(self, direction):
        if self.agent.mainloop_manager.should_queue_state_command():
            return self.agent.submit("navigate_session", direction=direction).wait().result
        sessions = self.list()
        if not sessions:
            return self.start_new()
        if self.agent.current_session_id not in sessions:
            return self.load(sessions[0])

        index = sessions.index(self.agent.current_session_id)
        if direction in ("next", "newer"):
            target_index = max(index - 1, 0)
        elif direction in ("previous", "prev", "older"):
            target_index = min(index + 1, len(sessions) - 1)
        else:
            raise ValueError(f"Unknown session navigation direction: {direction}")
        return self.load(sessions[target_index])

    def save(self):
        if self.agent.mainloop_manager.should_queue_state_command():
            return self.agent.submit("save_session").wait().result
        if not self.agent.current_session_id:
            return None
        self.agent.session.save()
        return self.agent.session

    def save_api_success_backup(self):
        if not self.agent.session:
            return None
        return self.agent.session.save_api_success_backup()

    def restore_api_success_backup(self):
        if not self.agent.session:
            return False
        restored = self.agent.session.restore_api_success_backup()
        if restored:
            self.agent.status_manager.invalidate_context_cache()
        return restored

    def compact(self, client=None, model=None, instructions=None, max_compacted_turns=None):
        if self.agent.mainloop_manager.should_queue_state_command():
            return self.agent.submit(
                "compact_session",
                client=client,
                model=model,
                instructions=instructions,
                max_compacted_turns=max_compacted_turns,
            ).wait().result

        model = model or self.agent.config.model
        if instructions is None:
            instructions = self.agent.config_manager.system_message().content
        max_input_tokens = self.agent.config.get(
            "max_input_tokens",
            DEFAULT_COMPACTION_MAX_INPUT_TOKENS,
        )
        plan = self.agent.session.compaction_plan(
            max_input_tokens=max_input_tokens,
            model=model,
            max_compacted_turns=max_compacted_turns,
        )
        if not plan.compacted_messages:
            return None

        self.agent.emit(
            CompactionRequestedEvent,
            compacted_message_count=plan.compacted_message_count,
            compacted_token_count=plan.compacted_token_count,
            context_message_count=plan.context_message_count,
            total_session_messages=len(self.agent.session.messages),
        )
        compact_kwargs = modict(
            model=model,
            instructions=instructions,
            max_input_tokens=max_input_tokens,
        )
        if max_compacted_turns is not None:
            compact_kwargs.max_compacted_turns = max_compacted_turns
        if client is not None:
            compact_kwargs.client = client
        try:
            message = self.agent.session.compact(**compact_kwargs)
        except Exception as exc:  # noqa: BLE001
            error = str(exc)
            self.agent.status_manager.invalidate_context_cache()
            self.agent.session.save()
            self.agent.emit(
                CompactionFailedEvent,
                error=error,
                reason=type(exc).__name__,
                compacted_message_count=plan.compacted_message_count,
                compacted_token_count=plan.compacted_token_count,
                context_message_count=plan.context_message_count,
                total_session_messages=len(self.agent.session.messages),
            )
            return modict(
                status="failed",
                error=error,
                reason=type(exc).__name__,
                compacted_message_count=plan.compacted_message_count,
                compacted_token_count=plan.compacted_token_count,
                context_message_count=plan.context_message_count,
                total_session_messages=len(self.agent.session.messages),
            )
        self.agent.status_manager.invalidate_context_cache()
        status = self.agent.status_manager.refresh_estimated_status_cache()
        self.agent.emit(
            CompactionCompletedEvent,
            message=message,
            status=status,
            compacted_message_count=plan.compacted_message_count,
            compacted_token_count=plan.compacted_token_count,
            post_compaction_message_count=len(self.agent.session.context_messages()),
            total_session_messages=len(self.agent.session.messages),
        )
        return message

    def append_message(self, msg):
        if not msg.session_id:
            msg.session_id = self.agent.current_session_id
        self.agent.session.messages.append(msg)
        msg.timestamp = msg.timestamp or timestamp()
        self.agent.status_manager.invalidate_context_cache()
        self.save()
        self.agent.emit(MessageAddedEvent, message=msg)
        return msg

    def messages(self, filter=None):
        if filter:
            return [msg for msg in self.agent.session.messages if filter(msg)]
        return sort(self.agent.session.messages)
