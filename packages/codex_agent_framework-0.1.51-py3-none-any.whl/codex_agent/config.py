import os
import platform

from modict import modict

from .event import RuntimeStateChangedEvent
from .message import SystemMessage
from .utils import runtime_join, text_content


DEFAULT_SYSTEM_PROMPT_PATH = os.path.join(os.path.dirname(__file__), "prompts", "system_prompt.txt")
DEFAULT_SYSTEM_PROMPT = text_content(DEFAULT_SYSTEM_PROMPT_PATH)


class AgentConfig(modict):
    _config = modict.config(enforce_json=True)

    model = "gpt-5.4"
    system = DEFAULT_SYSTEM_PROMPT
    auto_proceed = True
    openai_api_key = None
    validate_openai_api_key = True
    history = None
    name = "Pandora"
    username = "Unknown"
    userage = "Unknown"
    input_token_limit = 200000
    auto_compact = True
    max_input_tokens = 8000
    reasoning = modict.factory(lambda: modict(effort="medium", summary="auto"))
    text = modict.factory(lambda: modict(verbosity="medium"))
    parallel_tool_calls = True
    codex_stream_idle_timeout = 120
    tool_call_timeout = 0
    vision_enabled = True
    max_images = 10
    prune_orphaned_tool_outputs_on_context_build = True
    web_search_enabled = False
    image_generation_enabled = False
    image_generation_output_format = "png"
    image_generation_size = None
    image_generation_quality = None
    image_generation_background = None
    image_generation_moderation = None
    builtin_plugins = None
    custom_plugins = None
    exclude_tools = modict.factory(list)
    server_url = "http://127.0.0.1:8765"
    root_dir = modict.factory(lambda: os.path.abspath(os.getcwd()))
    cwd = modict.factory(lambda: os.path.abspath(os.getcwd()))
    workfolder = modict.factory(lambda: runtime_join("workfolder"))

    @modict.computed()
    def runtime_dir(self):
        from . import utils
        return utils.RUNTIME_DIR

    @modict.computed()
    def source_dir(self):
        return os.path.abspath(os.path.dirname(os.path.dirname(__file__)))

    @modict.computed()
    def platform(self):
        return (
            f"{platform.system()} {platform.release()} ({platform.machine()}), "
            f"Python {platform.python_version()}, shell {os.environ.get('SHELL', 'unknown')}"
        )


class PluginConfig(modict):
    _config = modict.config(enforce_json=True)


def _as_name_set(value):
    if value is None:
        return None
    if isinstance(value, str):
        return {value}
    return {str(item) for item in value}


def _as_modict(value):
    return value if isinstance(value, modict) else modict(value or {})


class ConfigManager:
    def __init__(self, agent):
        self.agent = agent
        self.config = AgentConfig()
        self.configs = modict(agent=self.config)
        self.config_files = modict(agent=self.file)

    @property
    def file(self):
        return runtime_join("agent.config.json")

    @property
    def legacy_file(self):
        return runtime_join("agent_config.json")

    def config_file(self, namespace="agent", file=None):
        if file is not None:
            return str(file)
        if namespace == "agent":
            return self.file
        return runtime_join(f"{namespace}_config.json")

    def save(self):
        return self.save_config("agent")

    def save_config(self, namespace="agent"):
        if namespace == "agent" and self.should_queue_state_command():
            return self.agent.submit("save_config").wait().result
        config = self.configs.get(namespace)
        if config is None:
            raise KeyError(f"Unknown config namespace: {namespace}")
        file = self.config_files.get(namespace) or self.config_file(namespace)
        parent = os.path.dirname(file)
        if parent:
            os.makedirs(parent, exist_ok=True)
        config.dump(file, indent=2, ensure_ascii=False)
        return config

    def load(self):
        source = self.file if os.path.isfile(self.file) else self.legacy_file
        if os.path.isfile(source):
            self.config = AgentConfig.load(source)
            self.agent.config = self.config
        self.configs.agent = self.config
        self.config_files.agent = self.file
        return self.config

    def load_config(self, namespace, *, config_class=PluginConfig, file=None, defaults=None):
        namespace = str(namespace)
        file = self.config_file(namespace, file=file)
        if os.path.isfile(file):
            config = config_class.load(file)
        else:
            config = config_class()
        for key, value in _as_modict(defaults).items():
            config.setdefault(key, value)
        self.configs[namespace] = config
        self.config_files[namespace] = file
        return config

    def update(self, config=None, save=True, **kwargs):
        if self.should_queue_state_command():
            return self.agent.submit(
                "update_config",
                config=config,
                save=save,
                kwargs=kwargs,
            ).wait().result
        data = modict(config or {})
        data.update(kwargs)
        if data:
            self.config.update(data)
            self.agent.config = self.config
            if save:
                self.save()
            self.emit_state_changed(
                reason="config_updated",
                namespace="config",
                name="agent",
                details=data,
            )
        return self.config

    def update_config(self, namespace="agent", config=None, save=True, **kwargs):
        if namespace == "agent":
            return self.update(config, save=save, **kwargs)
        target = self.configs.get(namespace)
        if target is None:
            raise KeyError(f"Unknown config namespace: {namespace}")
        data = modict(config or {})
        data.update(kwargs)
        if data:
            target.update(data)
            if save:
                self.save_config(namespace)
            self.emit_state_changed(
                reason="config_updated",
                namespace="config",
                name=namespace,
                details=data,
            )
        return target

    def emit_state_changed(self, **data):
        if hasattr(self.agent, "events"):
            self.agent.emit(RuntimeStateChangedEvent, **data)

    def has_openai_api_key(self):
        return bool(self.config.get("openai_api_key") or os.getenv("OPENAI_API_KEY"))

    def apply_openai_capability_defaults(self):
        """Normalize legacy agent config keys to SDK-shaped request fields."""
        reasoning = self.config.get("reasoning")
        if not isinstance(reasoning, dict):
            reasoning = modict()
        else:
            reasoning = modict(reasoning)
        if "reasoning_effort" in self.config and "effort" not in reasoning:
            reasoning.effort = self.config.get("reasoning_effort")
        if reasoning:
            self.config.reasoning = reasoning
        self.config.pop("reasoning_effort", None)

        text = self.config.get("text")
        if not isinstance(text, dict):
            text = modict()
        else:
            text = modict(text)
        if "verbosity" in self.config and "verbosity" not in text:
            text.verbosity = self.config.get("verbosity")
        if text:
            self.config.text = text
        self.config.pop("verbosity", None)

        # Voice configuration is plugin-scoped; consume old top-level aliases so
        # existing constructors do not leave stale agent-level config behind.
        for key in ("voice_enabled", "voice_model", "voice", "voice_instructions", "voice_buffer_size"):
            self.config.pop(key, None)
        return self.config

    def pop_legacy_section(self, section):
        parts = str(section).split(".")
        parent = self.config
        for part in parts[:-1]:
            parent = parent.get(part) if isinstance(parent, dict) else None
            if parent is None:
                return None
        if isinstance(parent, dict):
            return parent.pop(parts[-1], None)
        return None

    def prune_empty_legacy_containers(self):
        plugins = self.config.get("plugins")
        if isinstance(plugins, dict) and not plugins:
            self.config.pop("plugins", None)

    def apply_config_defaults(
        self,
        namespace,
        *,
        file=None,
        config_class=PluginConfig,
        defaults=None,
        legacy_agent_aliases=None,
        legacy_agent_sections=None,
    ):
        config = self.load_config(namespace, config_class=config_class, file=file, defaults=defaults)
        migrated = False
        for section in legacy_agent_sections or ():
            legacy = self.pop_legacy_section(section)
            if isinstance(legacy, dict):
                config.update(legacy)
                migrated = True
        for legacy_key, plugin_key in (legacy_agent_aliases or {}).items():
            if legacy_key in self.config:
                config[plugin_key] = self.config.pop(legacy_key)
                migrated = True
        self.prune_empty_legacy_containers()
        self.agent.config = self.config
        if migrated:
            self.save_config(namespace)
            self.save()
        return config

    def system_message(self):
        return SystemMessage(content=self.system_prompt())

    def system_prompt(self):
        if not self.config.get("system"):
            prompt = DEFAULT_SYSTEM_PROMPT
        elif os.path.isfile(self.config.system):
            prompt = text_content(self.config.system)
        elif isinstance(self.config.system, str):
            prompt = self.config.system
        else:
            raise ValueError(
                "Invalid system message configuration. "
                f"Expected path or string, got {type(self.config.system)}"
            )
        sections = [str(prompt or "").strip()]
        plugins_manager = getattr(self.agent, "plugins_manager", None)
        if plugins_manager is not None:
            sections.extend(plugins_manager.get_system_prompt_sections())
        return "\n\n".join(section for section in sections if section)

    def builtin_plugin_names(self):
        return _as_name_set(self.config.get("builtin_plugins"))

    def builtin_plugin_enabled(self, name):
        names = self.builtin_plugin_names()
        if names is None:
            return True
        return str(name) in names

    def custom_plugin_names(self):
        return _as_name_set(self.config.get("custom_plugins"))

    def custom_plugin_enabled(self, name):
        names = self.custom_plugin_names()
        if names is None:
            return True
        return str(name) in names

    def should_queue_state_command(self):
        return (
            hasattr(self.agent, "mainloop_manager")
            and self.agent.mainloop_manager.should_queue_state_command()
        )
