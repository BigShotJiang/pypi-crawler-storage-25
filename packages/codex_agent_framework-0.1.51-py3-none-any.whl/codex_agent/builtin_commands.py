"""Built-in slash commands."""

from .command import command
from .tool import get_agent


MODEL_CONFIG_KEYS = (
    "model",
    "reasoning",
    "text",
    "parallel_tool_calls",
    "input_token_limit",
    "max_input_tokens",
    "auto_compact",
)


def parse_config_value(value):
    if isinstance(value, bool):
        return value
    if not isinstance(value, str):
        return value

    lowered = value.lower()
    if lowered in ("true", "yes", "on", "1"):
        return True
    if lowered in ("false", "no", "off", "0"):
        return False
    if value.isdigit():
        return int(value)
    if (value.startswith("{") and value.endswith("}")) or (value.startswith("[") and value.endswith("]")):
        import json
        return json.loads(value)
    return value


def format_model_config(agent):
    return "\n".join(f"{key}: {agent.config.get(key)!r}" for key in MODEL_CONFIG_KEYS)


def update_model_config(**values):
    agent = get_agent()
    updates = {key: parse_config_value(value) for key, value in values.items()}
    unknown = sorted(key for key in updates if key not in MODEL_CONFIG_KEYS)
    if unknown:
        raise ValueError(f"Unknown model config keys: {', '.join(unknown)}")
    agent.config_manager.update(updates)
    changed = ", ".join(f"{key}={agent.config.get(key)!r}" for key in updates)
    return f"Updated config: {changed}" if changed else format_model_config(agent)


@command
def help():
    agent = get_agent()
    names = ", ".join(f"/{name}" for name in sorted(agent.commands))
    return f"Available commands: {names}"


@command
def compact(max_compacted_turns=None):
    agent = get_agent()
    max_compacted_turns = None if max_compacted_turns in (None, "", "all") else int(max_compacted_turns)
    message = agent.compact_session(
        model=agent.config.model,
        instructions=agent.config_manager.system_message().content,
        max_compacted_turns=max_compacted_turns,
    )
    if message is None:
        return "Nothing to compact."
    if message.get("status") == "failed":
        return f"Compaction failed: {message.error}"
    suffix = "" if max_compacted_turns is None else f" from {max_compacted_turns} compacted turn(s)"
    return f"Compacted {message.compacted_message_count} messages{suffix}."


@command
def sessions():
    agent = get_agent()
    session_ids = agent.get_sessions()
    if not session_ids:
        return "No saved sessions."
    lines = []
    for session_id in session_ids:
        prefix = "* " if session_id == agent.current_session_id else "  "
        lines.append(f"{prefix}{session_id}")
    return "\n".join(lines)


@command
def new_session(root_dir=None, cwd=None):
    agent = get_agent()
    session = agent.start_new_session(root_dir=root_dir, cwd=cwd)
    return f"Created session: {session.session_id}"


@command
def load_session(session_id="latest"):
    agent = get_agent()
    session = agent.load_session(session_id)
    return f"Loaded session: {session.session_id}"


@command
def delete_session(session_id):
    agent = get_agent()
    deleted_id = agent.delete_session(session_id)
    return f"Deleted session: {deleted_id}"


@command
def next_session():
    session = get_agent().navigate_session("next")
    return f"Loaded session: {session.session_id}"


@command
def previous_session():
    session = get_agent().navigate_session("previous")
    return f"Loaded session: {session.session_id}"


@command
def config(**values):
    return update_model_config(**values)


@command
def model(value=None):
    if value is None:
        return f"model: {get_agent().config.model!r}"
    return update_model_config(model=value)


@command
def reasoning(value=None):
    agent = get_agent()
    if value is None:
        return f"reasoning: {agent.config.get('reasoning')!r}"
    current = dict(agent.config.get("reasoning") or {})
    current["effort"] = value
    current.setdefault("summary", "auto")
    return update_model_config(reasoning=current)


@command
def verbosity(value=None):
    agent = get_agent()
    if value is None:
        return f"text: {agent.config.get('text')!r}"
    current = dict(agent.config.get("text") or {})
    current["verbosity"] = value
    return update_model_config(text=current)
