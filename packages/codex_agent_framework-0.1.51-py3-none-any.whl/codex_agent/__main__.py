"""Compatibility entrypoint for ``python -m codex_agent``."""

from .cli.main import main


if __name__ == '__main__':
    main()
