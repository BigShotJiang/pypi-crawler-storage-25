import os
import sys
import threading
import time
from pathlib import Path
from urllib.parse import urlparse

from PIL import Image, ImageDraw

from .service import SERVER_SERVICE_NAME, service_controller
from .tui import current_tui, open_tui_terminal, terminate_tui
from .utils import runtime_join

SYSTEM_DIST_PACKAGES = "/usr/lib/python3/dist-packages"


class AgentTray:
    def __init__(self, base_url="http://127.0.0.1:8765", service=None):
        self.base_url = str(base_url).rstrip("/")
        self.service = service or service_controller()
        self.icon = None
        self._server_running = False
        self._tui_running = False
        self._gtk_items = {}
        self._ui_thread = None

    def service_active(self):
        try:
            return self.service.active(SERVER_SERVICE_NAME)
        except Exception:
            return False

    def refresh_state(self):
        previous = (self._server_running, self._tui_running)
        self._server_running = self.service_active()
        self._tui_running = current_tui() is not None
        return previous != (self._server_running, self._tui_running)

    def server_running(self):
        return self._server_running

    def tui_running(self):
        return self._tui_running

    def run_systemctl(self, command, *extra_args):
        result = self.service.run(command, SERVER_SERVICE_NAME, *extra_args, check=False)
        if result.returncode:
            command_text = " ".join([str(command), *(str(arg) for arg in extra_args)])
            self.notify(
                "Codex Agent",
                (result.stderr or result.stdout or f"systemctl {command_text} failed").strip(),
            )
        return result

    def run_in_background(self, name, target):
        thread = threading.Thread(target=target, name=name, daemon=True)
        thread.start()
        return thread

    def wait_for_server(self, running=True, timeout=8.0, interval=0.25):
        deadline = time.monotonic() + timeout
        while True:
            self.refresh_state()
            if self._server_running is bool(running):
                return True
            if time.monotonic() >= deadline:
                return False
            time.sleep(interval)

    def install_services(self):
        parsed = urlparse(self.base_url)
        host = parsed.hostname or "127.0.0.1"
        port = parsed.port or (443 if parsed.scheme == "https" else 80)
        return self.service.install(host=host, port=port, enable=True, start=False)

    def service_missing(self, result):
        output = f"{result.stderr or ''}\n{result.stdout or ''}".lower()
        return "could not be found" in output or "not found" in output or "not loaded" in output

    def notify(self, title, message):
        print(f"{title}: {message}", file=sys.stderr)
        if self.icon is not None and hasattr(self.icon, "notify"):
            try:
                self.icon.notify(message, title=title)
            except Exception:
                pass

    def start_server(self, _icon=None, _item=None):
        def target():
            result = self.run_systemctl("start", "--no-block")
            if result.returncode and self.service_missing(result):
                self.notify("Codex Agent", "Server service not installed. Installing it now.")
                try:
                    self.install_services()
                except Exception as exc:
                    self.notify("Codex Agent", f"Could not install service: {exc}")
                    self.refresh_state()
                    self.update_menu()
                    return
                result = self.run_systemctl("start", "--no-block")
            if not result.returncode and not self.wait_for_server(running=True):
                self.notify("Codex Agent", "Server service started, but service state is not active yet.")
            self.refresh_state()
            self.update_menu()

        return self.run_in_background("codex-agent-tray-start-server", target)

    def stop_server(self, _icon=None, _item=None):
        def target():
            result = self.run_systemctl("stop", "--no-block")
            if not result.returncode:
                self.wait_for_server(running=False, timeout=5.0)
            self.refresh_state()
            self.update_menu()

        return self.run_in_background("codex-agent-tray-stop-server", target)

    def open_tui(self, _icon=None, _item=None):
        try:
            if open_tui_terminal(base_url=self.base_url) is None:
                self.notify("Codex Agent", "Could not find a terminal to open the TUI.")
        except Exception as exc:
            self.notify("Codex Agent", f"Could not open TUI: {exc}")
        self.refresh_state()
        self.update_menu()

    def close_tui(self, _icon=None, _item=None):
        try:
            tui = current_tui()
            if tui and tui.get("pid"):
                terminate_tui(tui.get("pid"))
        except Exception as exc:
            self.notify("Codex Agent", f"Could not close TUI: {exc}")
        self.refresh_state()
        self.update_menu()

    def apply_menu_state(self):
        running = self._server_running
        tui_running = self._tui_running
        if self._gtk_items:
            state = {
                "open_tui": not tui_running,
                "close_tui": tui_running,
                "start": not running,
                "stop": running,
            }
            for name, sensitive in state.items():
                item = self._gtk_items.get(name)
                if item is not None and hasattr(item, "set_sensitive"):
                    item.set_sensitive(sensitive)

    def poll_state(self):
        if self.refresh_state():
            self.apply_menu_state()
        return True

    def quit(self, icon=None, _item=None):
        if hasattr(self, "Gtk"):
            self.Gtk.main_quit()

    def update_menu(self):
        if (
            hasattr(self, "GLib")
            and self._ui_thread is not None
            and threading.current_thread() is not self._ui_thread
        ):
            self.GLib.idle_add(self._update_menu_now)
            return
        return self._update_menu_now()

    def _update_menu_now(self):
        if self.icon is None:
            return
        if self._gtk_items:
            self.apply_menu_state()
        else:
            self.icon.set_menu(self.gtk_menu())

    def run(self):
        if not wait_for_display():
            self.notify("Codex Agent", "No graphical display is available for the tray.")
            return
        gi = import_gi()
        gi.require_version("Gtk", "3.0")
        from gi.repository import Gtk
        if not Gtk.init_check()[0]:
            self.notify("Codex Agent", "GTK could not connect to the graphical display.")
            return
        wait_for_status_notifier_host(gi)
        AppIndicator = import_appindicator(gi)

        self.Gtk = Gtk
        self._ui_thread = threading.current_thread()
        icon_path = icon_file()
        icon_name = Path(icon_path).stem
        self.icon = AppIndicator.Indicator.new_with_path(
            "codex-agent",
            icon_name,
            AppIndicator.IndicatorCategory.APPLICATION_STATUS,
            str(Path(icon_path).parent),
        )
        self.icon.set_title("Codex Agent")
        self.icon.set_icon_full(icon_name, "Codex Agent")
        self.refresh_state()
        self.icon.set_menu(self.gtk_menu())
        self.icon.set_status(AppIndicator.IndicatorStatus.ACTIVE)
        self.start_gtk_polling(Gtk)
        Gtk.main()

    def start_gtk_polling(self, Gtk):
        from gi.repository import GLib
        self.GLib = GLib
        return GLib.timeout_add_seconds(1, self.poll_state)

    def gtk_menu(self):
        Gtk = self.Gtk
        running = self._server_running
        tui_running = self._tui_running
        menu = Gtk.Menu()

        open_tui_item = Gtk.MenuItem(label="Open TUI")
        self._gtk_items["open_tui"] = open_tui_item
        open_tui_item.set_sensitive(not tui_running)
        open_tui_item.connect("activate", self.open_tui)
        menu.append(open_tui_item)

        close_tui_item = Gtk.MenuItem(label="Close TUI")
        self._gtk_items["close_tui"] = close_tui_item
        close_tui_item.set_sensitive(tui_running)
        close_tui_item.connect("activate", self.close_tui)
        menu.append(close_tui_item)

        menu.append(Gtk.SeparatorMenuItem())

        start_item = Gtk.MenuItem(label="Start server")
        self._gtk_items["start"] = start_item
        start_item.set_sensitive(not running)
        start_item.connect("activate", self.start_server)
        menu.append(start_item)

        stop_item = Gtk.MenuItem(label="Stop server")
        self._gtk_items["stop"] = stop_item
        stop_item.set_sensitive(running)
        stop_item.connect("activate", self.stop_server)
        menu.append(stop_item)

        menu.append(Gtk.SeparatorMenuItem())
        quit_item = Gtk.MenuItem(label="Quit tray")
        quit_item.connect("activate", self.quit)
        menu.append(quit_item)

        menu.show_all()
        return menu


def create_icon(size=64):
    image = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(image)
    margin = size // 8
    draw.ellipse(
        (margin, margin, size - margin, size - margin),
        fill=(255, 255, 255, 255),
    )
    return image


def import_gi():
    try:
        import gi
        return gi
    except ImportError:
        if os.path.isdir(SYSTEM_DIST_PACKAGES) and SYSTEM_DIST_PACKAGES not in sys.path:
            sys.path.append(SYSTEM_DIST_PACKAGES)
        try:
            import gi
            return gi
        except ImportError as exc:
            raise RuntimeError("python3-gi is required to run the GTK tray") from exc


def import_appindicator(gi):
    for name in ("AyatanaAppIndicator3", "AppIndicator3"):
        try:
            gi.require_version(name, "0.1")
            module = __import__("gi.repository", fromlist=[name])
            return getattr(module, name)
        except (ImportError, ValueError, AttributeError):
            continue
    raise RuntimeError("AyatanaAppIndicator3 or AppIndicator3 is required to show the tray icon")


def display_available():
    return bool(os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"))


def wait_for_display(timeout=20.0, interval=0.25):
    deadline = time.monotonic() + float(timeout)
    while True:
        if display_available():
            return True
        if time.monotonic() >= deadline:
            return False
        time.sleep(interval)


def status_notifier_host_registered(gi=None):
    gi = gi or import_gi()
    from gi.repository import Gio, GLib

    bus = Gio.bus_get_sync(Gio.BusType.SESSION, None)
    result = bus.call_sync(
        "org.kde.StatusNotifierWatcher",
        "/StatusNotifierWatcher",
        "org.freedesktop.DBus.Properties",
        "Get",
        GLib.Variant(
            "(ss)",
            (
                "org.kde.StatusNotifierWatcher",
                "IsStatusNotifierHostRegistered",
            ),
        ),
        GLib.VariantType.new("(v)"),
        Gio.DBusCallFlags.NONE,
        500,
        None,
    )
    return bool(result.unpack()[0])


def wait_for_status_notifier_host(gi=None, timeout=20.0, interval=0.25, stable_for=8.0):
    deadline = time.monotonic() + float(timeout)
    while True:
        try:
            if status_notifier_host_registered(gi):
                if stable_for:
                    time.sleep(stable_for)
                return True
        except Exception:
            pass
        if time.monotonic() >= deadline:
            return False
        time.sleep(interval)


def icon_file():
    path = runtime_join("tray-icon.png")
    create_icon().save(path)
    return path


def run_tray(base_url="http://127.0.0.1:8765"):
    AgentTray(base_url=base_url).run()
