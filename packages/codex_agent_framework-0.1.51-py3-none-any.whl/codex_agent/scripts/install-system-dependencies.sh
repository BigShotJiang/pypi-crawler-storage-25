#!/usr/bin/env bash
set -euo pipefail

WITH_PLAYWRIGHT_DEPS=0
WITH_BROWSER=1
WITH_TRAY=1
WITH_DESKTOP=1
WITH_AUDIO=1
DRY_RUN=0
ASSUME_YES=0

usage() {
  cat <<'EOF'
Usage: scripts/install-system-dependencies.sh [options]

Install non-Python system dependencies used by codex-agent on Debian/Ubuntu.
Python dependencies are installed by pip from pyproject.toml; this script focuses
on external commands/libraries and Playwright's managed Chromium runtime.

Options:
  -y, --yes                  Pass -y to apt-get.
      --dry-run              Print commands without executing them.
      --no-browser           Skip Playwright Chromium installation.
      --with-playwright-deps Run `python -m playwright install --with-deps chromium` instead of only `chromium`.
      --no-tray              Skip GTK/AppIndicator tray packages.
      --no-desktop           Skip X11 desktop automation packages.
      --no-audio             Skip ffmpeg/ffplay package.
  -h, --help                 Show this help.

Notes:
  - Desktop automation is reliable on X11; Wayland may block global automation.
  - The script never runs during `pip install` automatically. Use the packaged
    command `codex-agent install-system-deps` after installing the Python package.
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    -y|--yes) ASSUME_YES=1 ;;
    --dry-run) DRY_RUN=1 ;;
    --no-browser) WITH_BROWSER=0 ;;
    --with-playwright-deps) WITH_PLAYWRIGHT_DEPS=1 ;;
    --no-tray) WITH_TRAY=0 ;;
    --no-desktop) WITH_DESKTOP=0 ;;
    --no-audio) WITH_AUDIO=0 ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown option: $1" >&2; usage >&2; exit 2 ;;
  esac
  shift
done

run() {
  echo "+ $*"
  if [[ "$DRY_RUN" -eq 0 ]]; then
    "$@"
  fi
}

run_shell() {
  echo "+ $*"
  if [[ "$DRY_RUN" -eq 0 ]]; then
    bash -lc "$*"
  fi
}

if [[ "${OSTYPE:-}" != linux* ]]; then
  echo "This installer currently supports Debian/Ubuntu Linux only." >&2
  echo "See dependencies.txt for macOS/Windows notes." >&2
  exit 1
fi

if ! command -v apt-get >/dev/null 2>&1; then
  echo "apt-get not found. This installer currently targets Debian/Ubuntu." >&2
  echo "See dependencies.txt and install equivalent packages for your distribution." >&2
  exit 1
fi

SUDO=()
if [[ "${EUID}" -ne 0 ]]; then
  if command -v sudo >/dev/null 2>&1; then
    SUDO=(sudo)
  else
    echo "This script needs root privileges for apt-get. Install sudo or run as root." >&2
    exit 1
  fi
fi

APT_INSTALL=(apt-get install)
if [[ "$ASSUME_YES" -eq 1 ]]; then
  APT_INSTALL+=("-y")
fi

packages=(
  python3
  python3-pip
  bash
  xdg-utils
  dbus-user-session
)

if [[ "$WITH_DESKTOP" -eq 1 ]]; then
  packages+=(
    wmctrl
    xdotool
    xclip
    libx11-6
    libxext6
    libxinerama1
    libxrandr2
    libxtst6
  )
fi

if [[ "$WITH_TRAY" -eq 1 ]]; then
  packages+=(
    python3-gi
    gir1.2-gtk-3.0
    gir1.2-ayatanaappindicator3-0.1
    libayatana-appindicator3-1
  )
  # Some older distributions package the legacy AppIndicator typelib separately.
  # Install opportunistically below; do not make it fatal.
fi

if [[ "$WITH_AUDIO" -eq 1 ]]; then
  packages+=(ffmpeg)
fi

run "${SUDO[@]}" apt-get update
run "${SUDO[@]}" "${APT_INSTALL[@]}" "${packages[@]}"

if [[ "$WITH_TRAY" -eq 1 ]]; then
  echo "+ optional legacy AppIndicator typelib"
  if [[ "$DRY_RUN" -eq 0 ]]; then
    "${SUDO[@]}" "${APT_INSTALL[@]}" gir1.2-appindicator3-0.1 || true
  else
    echo "+ ${SUDO[*]} ${APT_INSTALL[*]} gir1.2-appindicator3-0.1 || true"
  fi
fi

if [[ "$WITH_BROWSER" -eq 1 ]]; then
  if [[ "$WITH_PLAYWRIGHT_DEPS" -eq 1 ]]; then
    run_shell "python -m playwright install --with-deps chromium"
  else
    run_shell "python -m playwright install chromium"
  fi
fi

echo "System dependency installation completed."
