# Changelog

## [0.2.4](https://github.com/erikmunkby/yamlium/compare/v0.2.3...v0.2.4) (2026-05-07)


### Bug Fixes

* normalize quoted keys at parse time ([1111497](https://github.com/erikmunkby/yamlium/commit/1111497a366c69175473edaf69775a6f714574ea))

## [0.2.3](https://github.com/erikmunkby/yamlium/compare/v0.2.2...v0.2.3) (2026-04-10)


### Bug Fixes

* **lexer:** 🐛 preserve flow mappings in sequences ([b831f82](https://github.com/erikmunkby/yamlium/commit/b831f82844676fbbb3836e790b2cbf3c557c1c81))

## [0.2.2](https://github.com/erikmunkby/yamlium/compare/v0.2.1...v0.2.2) (2026-03-27)


### Bug Fixes

* empty collections and inline parsing without newline ([c04eee0](https://github.com/erikmunkby/yamlium/commit/c04eee059cf9233084a48bc25f569c117ac69e72))
* multiline strings from from_dict/from_json produce valid YAML ([f4b9f74](https://github.com/erikmunkby/yamlium/commit/f4b9f7411d2e3d1a573e8ac0a622b0d2ec7b4aa2))
* standalone flow-style documents and bare empty root trailing newline ([9f44878](https://github.com/erikmunkby/yamlium/commit/9f44878a28f07d4ff980cd0468d2f15f5c8cc2d1))

## [0.2.1](https://github.com/erikmunkby/yamlium/compare/v0.2.0...v0.2.1) (2026-01-28)


### Bug Fixes

* **lexer:** 🩹 handle escaped quotes in single-quoted strings ([d77198d](https://github.com/erikmunkby/yamlium/commit/d77198d9466f96bfe85d28edc9390fdfdc203d98))
* support double quote escape ([161fd6e](https://github.com/erikmunkby/yamlium/commit/161fd6e1692ec9fcad5c481c256ef5f851818dc1))

## [0.2.0](https://github.com/erikmunkby/yamlium/compare/v0.1.17...v0.2.0) (2026-01-22)


### Features

* comment ownership ([4ff4645](https://github.com/erikmunkby/yamlium/commit/4ff4645c9136cbe972044962a194603184359e31))


### Bug Fixes

* dedented comments no longer raises error ([314fff0](https://github.com/erikmunkby/yamlium/commit/314fff0ddabc366427671801422b6920cc7b837d))
* security updates ([c74d49c](https://github.com/erikmunkby/yamlium/commit/c74d49c6cf707b8d47b87d336f218880ed5b052d))

## [0.1.17](https://github.com/erikmunkby/yamlium/compare/v0.1.16...v0.1.17) (2025-12-28)


### Bug Fixes

* typing closer to native python ([3f2aaf6](https://github.com/erikmunkby/yamlium/commit/3f2aaf60c00a52e7648492e49e110d4804bfb727))

## [0.1.16](https://github.com/erikmunkby/yamlium/compare/v0.1.15...v0.1.16) (2025-12-28)


### Bug Fixes

* preserve whitespaces in lists ([4aa6744](https://github.com/erikmunkby/yamlium/commit/4aa6744cdb266cb96e654a2fa1a8a4fa86a7a967))

## [0.1.15](https://github.com/erikmunkby/yamlium/compare/v0.1.14...v0.1.15) (2025-12-27)


### Bug Fixes

* indentations in multiline scalar ([83cc317](https://github.com/erikmunkby/yamlium/commit/83cc3172e465d5ac3d0763d0adaa604c80094efa))
* maintain mapping newlines ([43b59b8](https://github.com/erikmunkby/yamlium/commit/43b59b8005acb6c196395c24a8222d5f2d870e1e))
* newlines in quotes ([e9cf9b5](https://github.com/erikmunkby/yamlium/commit/e9cf9b5aee48ce636829443fa690bebeeac6bf42))

## [0.1.14](https://github.com/erikmunkby/yamlium/compare/v0.1.13...v0.1.14) (2025-07-23)


### Bug Fixes

* allow irregular multiline ([0dd1812](https://github.com/erikmunkby/yamlium/commit/0dd18123e05226c02dc2fa8dc243ae90f81aac9b))

## [0.1.13](https://github.com/erikmunkby/yamlium/compare/v0.1.12...v0.1.13) (2025-07-13)


### Bug Fixes

* allow empty yaml document ([32338f9](https://github.com/erikmunkby/yamlium/commit/32338f935c7481e2355c49669f3e2a5944c74d05))

## [0.1.12](https://github.com/erikmunkby/yamlium/compare/v0.1.11...v0.1.12) (2025-07-07)


### Bug Fixes

* quoted strings remain strings ([863ff7f](https://github.com/erikmunkby/yamlium/commit/863ff7fcd3b64186fca211a5f6a9a139a089f76e))

## [0.1.11](https://github.com/erikmunkby/yamlium/compare/v0.1.10...v0.1.11) (2025-07-07)


### Bug Fixes

* comments in sequences ([5c4512a](https://github.com/erikmunkby/yamlium/commit/5c4512a10bd6e9febcbc204b6f81c9e82fb43f7b))

## [0.1.10](https://github.com/erikmunkby/yamlium/compare/v0.1.9...v0.1.10) (2025-07-07)


### Bug Fixes

* indentation of multiline in sequence ([bf96bf1](https://github.com/erikmunkby/yamlium/commit/bf96bf14c68ece0ec357c12ff2e09cc6110cc289))

## [0.1.9](https://github.com/erikmunkby/yamlium/compare/v0.1.8...v0.1.9) (2025-07-06)


### Bug Fixes

* allow &lt; in scalar ([1b285af](https://github.com/erikmunkby/yamlium/commit/1b285afee431d137f4f80907a7bc76af2025a2ef))
* keys must be followed by newline or blankspace ([14dfe6b](https://github.com/erikmunkby/yamlium/commit/14dfe6b5e8596d5c9fb68c0764f7d9887420a5f7))
* next line scalars ([56efbb5](https://github.com/erikmunkby/yamlium/commit/56efbb5b22130596849a44dfa60edb32b316c5cc))

## [0.1.8](https://github.com/erikmunkby/yamlium/compare/v0.1.7...v0.1.8) (2025-06-15)


### Bug Fixes

* allow quoted keys ([38a397a](https://github.com/erikmunkby/yamlium/commit/38a397a2e5302e34897751ae33033029d617a84b))

## [0.1.7](https://github.com/erikmunkby/yamlium/compare/v0.1.6...v0.1.7) (2025-06-15)


### Bug Fixes

* allow negative scalars in sequence ([6eecdbf](https://github.com/erikmunkby/yamlium/commit/6eecdbf906462d36c52238751edbc0238d8f3d87))

## [0.1.6](https://github.com/erikmunkby/yamlium/compare/v0.1.5...v0.1.6) (2025-06-15)


### Bug Fixes

* better multiline scalar support ([b55f39e](https://github.com/erikmunkby/yamlium/commit/b55f39e172aa3d95008a46859e50783dffb18372))
* dashes now count as indentations ([4196769](https://github.com/erikmunkby/yamlium/commit/41967694d70b75f342ac50d308f9d8ab521fefe2))
* make lexer recursive ([4cd94ac](https://github.com/erikmunkby/yamlium/commit/4cd94ace5af9406c481c4d997b39e2e5d3bdf35e))

## [0.1.5](https://github.com/erikmunkby/yamlium/compare/v0.1.4...v0.1.5) (2025-06-13)


### Bug Fixes

* remove quotes from string values ([3ff2cd9](https://github.com/erikmunkby/yamlium/commit/3ff2cd9390aa2f77adc627cae109722d0643990e))

## [0.1.4](https://github.com/erikmunkby/yamlium/compare/v0.1.3...v0.1.4) (2025-06-08)


### Bug Fixes

* typing on default value ([e524ade](https://github.com/erikmunkby/yamlium/commit/e524adea105d9e0ef9cb6efbe372668e9a7f0f21))

## [0.1.3](https://github.com/erikmunkby/yamlium/compare/v0.1.2...v0.1.3) (2025-06-06)


### Bug Fixes

* remove test pypi ([e195642](https://github.com/erikmunkby/yamlium/commit/e195642eb113eb16df3a440e374112cebc922003))

## [0.1.2](https://github.com/erikmunkby/yamlium/compare/v0.1.1...v0.1.2) (2025-06-06)


### Bug Fixes

* add normal pypi publishing ([4299b3b](https://github.com/erikmunkby/yamlium/commit/4299b3b40bf70b46039ca8d1d18855154b4f169c))

## [0.1.1](https://github.com/erikmunkby/yamlium/compare/v0.1.0...v0.1.1) (2025-06-06)


### Bug Fixes

* pypi descriptions ([32b102e](https://github.com/erikmunkby/yamlium/commit/32b102ecf754f19cf68e8473c8cdf5eb0e07a2a9))

## 0.1.0 (2025-06-06)


### Features

* initial release ([c2a0afd](https://github.com/erikmunkby/yamlium/commit/c2a0afd3f3e4b3b000a9af59dd212418836aa408))
