"""Base classes for SPOT analyzer implementations.

Provides:
- BaseAnalyzerSettings: Common settings fields all analyzers share
- settings_singleton: Decorator to add caching to a get_settings() function
- merge_settings: Merge base settings with central config overrides
- create_analyzer_app: Factory for FastAPI app with standard analyzer endpoints

Usage in an analyzer's config.py::

    from spot_sdk.analyzer_base import BaseAnalyzerSettings, settings_singleton

    class Settings(BaseAnalyzerSettings):
        app_name: str = "analyzer-nlp"
        model_path: str = "/models/distilbert"
        use_gpu: bool = False

    @settings_singleton
    def get_settings() -> Settings:
        return Settings()

Usage in an analyzer's main.py::

    from spot_sdk.analyzer_base import create_analyzer_app

    app, state = create_analyzer_app(
        title="SPOT NLP Analyzer",
        description="NLP-based phishing email analyzer",
        analyzer_id="analyzer-nlp",
        settings_factory=get_settings,
    )
"""

from __future__ import annotations

import os
from collections.abc import Awaitable, Callable
from functools import wraps
from typing import Any, TypeVar

import uvicorn
from fastapi import FastAPI
from pydantic_settings import BaseSettings, SettingsConfigDict
from starlette.responses import Response

from .config_client import ConfigClient
from .logging import configure_logging, get_logger

logger = get_logger(__name__)

T = TypeVar("T", bound=BaseSettings)


class BaseAnalyzerSettings(BaseSettings):
    """Common settings shared by all SPOT analyzers.

    Analyzers extend this class with their own specific fields::

        class Settings(BaseAnalyzerSettings):
            app_name: str = "analyzer-nlp"
            model_path: str = "/models/distilbert"
            use_gpu: bool = False

    Fields:
        app_name: Human-readable analyzer name
        app_version: Semantic version string
        debug: Enable debug mode (hot reload, verbose logging)
        log_level: Python log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        host: Server bind address
        port: Server bind port
        platform_url: URL of the SPOT API gateway for config fetching
    """

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_name: str = "spot-analyzer"
    app_version: str = "1.0.0"
    debug: bool = False
    log_level: str = "INFO"

    # Server
    host: str = "0.0.0.0"
    port: int = 8000

    # Platform URL for ConfigClient
    platform_url: str = "http://api-gateway:8000"


def settings_singleton(func: Callable[[], T]) -> Callable[[], T]:
    """Decorator that turns a settings factory into a cached singleton.

    Usage::

        @settings_singleton
        def get_settings() -> Settings:
            return Settings()

        # First call creates the instance, subsequent calls return cached value
        settings = get_settings()

    The cache can be cleared by setting the internal list element to None::

        get_settings._instance[0] = None
    """
    instance: list[T | None] = [None]

    @wraps(func)
    def wrapper() -> T:
        if instance[0] is None:
            instance[0] = func()
        result = instance[0]
        assert result is not None
        return result

    # Allow cache clearing for testing
    wrapper._instance = instance  # type: ignore[attr-defined]
    return wrapper


def merge_settings(base: T, overrides: dict[str, Any]) -> T:
    """Merge base settings with central config overrides.

    Override keys match the Pydantic field names case-insensitively, so
    the dashboard's uppercase convention (``MODEL_PATH``, ``USE_GPU``)
    maps onto the lowercase Python field names. Keys with no
    corresponding field are silently dropped.

    Args:
        base: Base Settings instance from local env/defaults
        overrides: Dict of override values from central config (any case)

    Returns:
        New Settings instance with overrides applied. The original is
        not mutated.
    """
    field_by_lower = {name.lower(): name for name in type(base).model_fields}
    filtered: dict[str, Any] = {}
    for key, value in overrides.items():
        canonical = field_by_lower.get(key.lower())
        if canonical is not None:
            filtered[canonical] = value
    return base.model_copy(update=filtered)


class AnalyzerState:
    """Shared mutable state for an analyzer application.

    Holds the settings, config client, and analysis service references
    that are initialized during the lifespan and used by endpoints.

    Attributes:
        settings: Current merged settings (None before startup)
        config_client: ConfigClient for central config fetching
        analysis_service: The analyzer's AnalysisService instance (None before startup)
        settings_factory: Callable that returns a fresh Settings instance
        on_reload: Optional async callback invoked after config reload
    """

    def __init__(
        self,
        config_client: ConfigClient,
        settings_factory: Callable[[], BaseAnalyzerSettings],
    ) -> None:
        self.settings: BaseAnalyzerSettings | None = None
        self.config_client = config_client
        self.analysis_service: Any = None
        self.settings_factory = settings_factory
        self.on_reload: Callable[[], Awaitable[None]] | None = None

    def apply_settings(self) -> BaseAnalyzerSettings:
        """Load base settings, merge with central overrides, configure logging.

        Updates ``self.settings`` with the merged result and configures
        the logging level. Does NOT touch ``self.analysis_service`` --
        that is the caller's responsibility.

        Returns:
            Merged settings instance.
        """
        base = self.settings_factory()
        overrides = self.config_client.config
        self.settings = merge_settings(base, overrides)
        configure_logging(log_level=self.settings.log_level)
        return self.settings


def create_analyzer_app(
    *,
    title: str,
    description: str,
    analyzer_id: str,
    settings_factory: Callable[[], BaseAnalyzerSettings],
    platform_url: str | None = None,
    lifespan: Any | None = None,
) -> tuple[FastAPI, AnalyzerState]:
    """Create a FastAPI app with standard analyzer endpoints.

    Returns the app and a state object. The caller is responsible for:

    1. Adding a lifespan or startup handler that calls
       ``state.config_client.fetch_config()``, ``state.apply_settings()``,
       and sets ``state.analysis_service``.
    2. Adding a ``/health`` endpoint (health checks are analyzer-specific).
    3. Adding a ``/internal/analyze`` endpoint (pre-checks are analyzer-specific).
    4. Optionally setting ``state.on_reload`` for post-reload logic.

    Standard endpoints provided:

    - GET  /capabilities        -- delegates to analysis_service.get_capabilities()
    - GET  /config              -- delegates to analysis_service.get_configuration()
    - POST /admin/reload-config -- reloads central config, calls state.on_reload if set

    Args:
        title: FastAPI app title
        description: FastAPI app description
        analyzer_id: Unique analyzer identifier for config client
        settings_factory: Callable returning a Settings instance
        platform_url: Override platform URL (default: from settings or env)
        lifespan: Optional lifespan async context manager for the app

    Returns:
        Tuple of (FastAPI app, AnalyzerState).
    """
    initial_settings = settings_factory()

    # Determine platform URL
    if platform_url is None:
        _platform_url = getattr(
            initial_settings,
            "platform_url",
            os.getenv("SPOT_PLATFORM_URL", "http://api-gateway:8000"),
        )
    else:
        _platform_url = platform_url

    default_version = initial_settings.app_version

    config_client = ConfigClient(
        analyzer_id=analyzer_id,
        platform_url=_platform_url,
    )

    state = AnalyzerState(
        config_client=config_client,
        settings_factory=settings_factory,
    )

    app_kwargs: dict[str, Any] = {
        "title": title,
        "description": description,
        "version": default_version,
    }
    if lifespan is not None:
        app_kwargs["lifespan"] = lifespan

    app = FastAPI(**app_kwargs)

    # --- Standard endpoints ---

    @app.get("/capabilities")
    async def get_capabilities() -> list[str]:
        """Get analyzer capabilities."""
        if state.analysis_service is None:
            return []
        capabilities = await state.analysis_service.get_capabilities()
        return [cap.value for cap in capabilities]

    @app.get("/config")
    async def get_configuration() -> dict[str, Any]:
        """Get analyzer configuration."""
        if state.analysis_service is None:
            return {}
        config: dict[str, Any] = await state.analysis_service.get_configuration()
        return config

    @app.post("/admin/reload-config", status_code=204, response_class=Response)
    async def reload_config() -> Response:
        """Reload configuration from central platform.

        Called by spot-cli config reload when analyzer config changes.
        Fetches fresh central overrides, re-applies settings, and
        invokes the on_reload callback if one is registered.
        """
        logger.info("Reloading configuration...")

        # Fetch fresh central overrides
        await config_client.reload()

        # Apply settings
        state.apply_settings()

        # Invoke analyzer-specific post-reload logic
        if state.on_reload is not None:
            await state.on_reload()

        logger.info(
            "Configuration reloaded (version: %s)",
            config_client.version or "local-only",
        )
        return Response(status_code=204)

    return app, state


def run_analyzer(app_import_path: str, settings: BaseAnalyzerSettings) -> None:
    """Run an analyzer with uvicorn using standard settings.

    Intended for use in ``if __name__ == "__main__":`` blocks::

        if __name__ == "__main__":
            run_analyzer("src.main:app", get_settings())

    Args:
        app_import_path: Dotted import path to the app (e.g. "src.main:app")
        settings: Settings instance for host/port/log_level/debug
    """
    uvicorn.run(
        app_import_path,
        host=settings.host,
        port=settings.port,
        log_level=settings.log_level.lower(),
        reload=settings.debug,
    )
