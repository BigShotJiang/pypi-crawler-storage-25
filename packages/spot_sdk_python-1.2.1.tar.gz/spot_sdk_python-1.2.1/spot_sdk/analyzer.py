"""Analyzer interface definition."""

from __future__ import annotations

from abc import ABC, abstractmethod
from enum import Enum
from typing import TYPE_CHECKING, Any

from .email import Email

if TYPE_CHECKING:
    from .results import AnalysisResult


class ThreatLevel(str, Enum):
    """Email threat level classification."""

    SAFE = "safe"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

    def __str__(self) -> str:
        return self.value


class AnalyzerCapability(str, Enum):
    """Analyzer capability types."""

    SENTIMENT_ANALYSIS = "sentiment_analysis"
    ENTITY_RECOGNITION = "entity_recognition"
    URL_ANALYSIS = "url_analysis"
    ATTACHMENT_SCANNING = "attachment_scanning"
    LANGUAGE_DETECTION = "language_detection"
    PHISHING_PATTERNS = "phishing_patterns"
    SOCIAL_ENGINEERING = "social_engineering"
    DOMAIN_REPUTATION = "domain_reputation"

    def __str__(self) -> str:
        return self.value


class AnalyzerInterface(ABC):
    """
    Standard interface that all SPOT analyzers must implement.

    This interface ensures compatibility across all analyzer plugins,
    enabling the orchestrator to coordinate analysis workflows.
    """

    @abstractmethod
    async def analyze(self, email: Email) -> AnalysisResult:
        """
        Analyze an email and return threat assessment.

        Args:
            email: Email object containing headers, body, and attachments

        Returns:
            AnalysisResult: Structured analysis result with threat assessment

        Raises:
            AnalysisError: If analysis cannot be completed
        """
        pass

    @abstractmethod
    async def get_capabilities(self) -> list[AnalyzerCapability]:
        """
        Return list of analysis capabilities this analyzer provides.

        Returns:
            List of AnalyzerCapability enums
        """
        pass

    @abstractmethod
    async def health_check(self) -> bool:
        """
        Check if analyzer is healthy and ready to process emails.

        Returns:
            True if healthy, False otherwise
        """
        pass

    @abstractmethod
    def get_version(self) -> str:
        """
        Return analyzer version string.

        Returns:
            Semantic version string (e.g., "1.2.3")
        """
        pass

    @abstractmethod
    async def get_configuration(self) -> dict[str, Any]:
        """
        Return current analyzer configuration.

        Returns:
            Dictionary containing analyzer configuration parameters
        """
        pass
