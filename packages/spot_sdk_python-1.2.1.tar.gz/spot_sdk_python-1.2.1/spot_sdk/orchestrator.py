"""Orchestrator result models for SPOT platform."""

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field

from .analyzer import ThreatLevel
from .results import AnalysisIndicator


class AnalyzerResult(BaseModel):
    """Result from a single analyzer execution."""

    analyzer_id: str = Field(..., description="Analyzer ID")
    analyzer_type: str = Field(..., description="Type of analyzer")
    execution_time_ms: int = Field(..., description="Execution time in milliseconds")
    status: str = Field(..., description="Execution status (success, failed, timeout)")
    is_phishing: bool = Field(..., description="Whether phishing was detected")
    confidence: float = Field(..., description="Confidence score (0.0 to 1.0)")
    threat_level: ThreatLevel = Field(
        default=ThreatLevel.SAFE, description="Threat level from analyzer"
    )
    indicators: list[AnalysisIndicator] = Field(
        default_factory=list, description="Detected indicators"
    )
    analyzer_details: dict[str, Any] = Field(
        default_factory=dict, description="Additional analyzer-specific details"
    )


class WorkflowStageResult(BaseModel):
    """Result from a single workflow stage execution."""

    stage_name: str = Field(..., description="Stage name")
    stage_type: str = Field(..., description="Stage type")
    execution_time_ms: int = Field(
        ..., description="Stage execution time in milliseconds"
    )
    analyzer_results: list[AnalyzerResult] = Field(
        default_factory=list, description="Results from all analyzers in this stage"
    )
    weighted_confidence: float = Field(..., description="Aggregated confidence score")


class OrchestrationResult(BaseModel):
    """Final orchestration result combining all analyzer outputs."""

    id: str = Field(..., description="Result ID")
    email_id: str = Field(..., description="Email ID")
    workflow_id: str = Field(..., description="Workflow ID used")
    workflow_version: int = Field(..., description="Workflow version")
    is_phishing: bool = Field(..., description="Final phishing determination")
    threat_level: ThreatLevel = Field(..., description="Overall threat level")
    confidence: float = Field(..., description="Final confidence score (0.0 to 1.0)")
    total_execution_time_ms: int = Field(
        ..., description="Total execution time in milliseconds"
    )
    analyzed_at: datetime = Field(..., description="Analysis timestamp")
    summary: str = Field(..., description="Human-readable summary")
    recommended_action: str = Field(..., description="Recommended action")
    reasoning: dict[str, Any] = Field(
        default_factory=dict, description="Reasoning behind the decision"
    )
    config_snapshot: dict[str, Any] = Field(
        default_factory=dict, description="Snapshot of configuration used"
    )
    indicators: list[AnalysisIndicator] = Field(
        default_factory=list, description="All detected indicators"
    )
    stage_results: list[WorkflowStageResult] = Field(
        default_factory=list,
        description=(
            "Per-stage breakdown of the workflow execution: each entry "
            "carries the stage's analyzers (status, timing, threat level, "
            "indicators, free-form analyzer_details). Empty by default for "
            "consumers built against earlier SDK releases."
        ),
    )
