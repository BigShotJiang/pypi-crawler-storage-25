"""SPOT API interfaces and data models."""

from .analysis_context import AnalysisContextReader
from .analyzer import AnalyzerCapability, AnalyzerInterface, ThreatLevel
from .config import ConfigOption, ConfigReloadResult, ConfigStatus, ConfigUpdateRequest
from .config_client import ConfigClient
from .config_helpers import merge_settings
from .email import Attachment, Email, EmailHeader
from .errors import ErrorResponse
from .knowledge import KnowledgeClient, KnowledgeDocument, chunk_text, content_hash
from .knowledge_tags import KnowledgeTag
from .logging import configure_logging, get_logger, get_logging_config
from .ollama import LLMResponse, OllamaClientProtocol
from .orchestrator import AnalyzerResult, OrchestrationResult, WorkflowStageResult
from .plugin import PluginKind
from .results import (
    AnalysisIndicator,
    AnalysisMetadata,
    AnalysisResult,
    IndicatorType,
)
from .retriever import (
    IngestionRequest,
    IngestionResult,
    IngestionStatus,
    MailRetrieverClient,
)
from .settings_schema import register_settings_schema
from .threat_levels import confidence_to_threat_level
from .workflow import (
    AnalyzerConfig,
    FailureStrategy,
    RetrievalLimits,
    RetryConfig,
    Workflow,
    WorkflowStage,
)

__all__ = [
    # Analyzer interface
    "AnalyzerInterface",
    "AnalyzerCapability",
    "ThreatLevel",
    # Config models
    "ConfigOption",
    "ConfigStatus",
    "ConfigUpdateRequest",
    "ConfigReloadResult",
    "ConfigClient",
    # Error response
    "ErrorResponse",
    # Email models
    "Email",
    "EmailHeader",
    "Attachment",
    "AnalysisContextReader",
    # Analysis results
    "AnalysisResult",
    "AnalysisIndicator",
    "AnalysisMetadata",
    "IndicatorType",
    # Logging
    "configure_logging",
    "get_logger",
    "get_logging_config",
    # Workflow
    "Workflow",
    "WorkflowStage",
    "AnalyzerConfig",
    "RetryConfig",
    "RetrievalLimits",
    "FailureStrategy",
    # Knowledge Store
    "KnowledgeDocument",
    "KnowledgeClient",
    "KnowledgeTag",
    "chunk_text",
    "content_hash",
    # Plugin vocabulary
    "PluginKind",
    # Mail-retriever ingest contract
    "IngestionRequest",
    "IngestionResult",
    "IngestionStatus",
    "MailRetrieverClient",
    # Orchestration
    "OrchestrationResult",
    "AnalyzerResult",
    "WorkflowStageResult",
    # Ollama protocol
    "OllamaClientProtocol",
    "LLMResponse",
    # Settings schema
    "register_settings_schema",
    # Config helpers
    "merge_settings",
    # Threat levels
    "confidence_to_threat_level",
]
