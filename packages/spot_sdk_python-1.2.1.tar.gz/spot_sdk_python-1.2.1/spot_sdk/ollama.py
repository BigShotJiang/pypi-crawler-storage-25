"""Protocol for Ollama-compatible LLM clients and shared response model."""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

from pydantic import BaseModel, Field


@runtime_checkable
class OllamaClientProtocol(Protocol):
    """Protocol defining the interface for Ollama-compatible clients.

    Both real and mock Ollama clients should implement this protocol.
    The protocol captures the minimal shared surface: generating a text
    response from a prompt and (optionally) lifecycle management.

    Existing client classes already satisfy this protocol structurally --
    no code changes are needed in analyzer-llm or analyzer-fake-llm.
    """

    async def generate_response(self, prompt: str, model: str) -> str:
        """Generate a text response from the LLM.

        Args:
            prompt: The prompt to send to the LLM.
            model: Model name to use for generation.

        Returns:
            Generated text response (typically JSON for analysis prompts).
        """
        ...

    async def check_connection(self) -> bool:
        """Check if the Ollama service is reachable.

        Returns:
            True if the service is reachable, False otherwise.
        """
        ...

    async def close(self) -> None:
        """Release any resources held by the client."""
        ...


class LLMResponse(BaseModel):
    """Schema for validating LLM JSON responses.

    Shared between analyzer-llm and analyzer-fake-llm so the response
    format is defined in a single place.
    """

    is_phishing: bool = False
    confidence: float = Field(default=0.0, ge=0.0, le=1.0)
    threat_level: str = "safe"
    explanation: str = "Analysis completed"
    indicators: list[dict[str, Any]] = Field(default_factory=list)
