"""Configuration management models for SPOT platform."""

from typing import Any

from pydantic import BaseModel, Field


class ConfigOption(BaseModel):
    """Single configuration option with full metadata."""

    path: str = Field(description="Dot-notation path (e.g., 'platform.log_level')")
    value: Any = Field(description="Current value")
    default: Any = Field(description="Default value from schema")
    type: str = Field(description="JSON Schema type (string, boolean, integer, etc.)")
    description: str = Field(default="", description="Human-readable description")
    is_default: bool = Field(description="True if current value equals default")
    enum: list[str] | None = Field(
        default=None, description="Allowed values if restricted"
    )
    minimum: float | None = Field(default=None, description="Minimum value for numbers")
    maximum: float | None = Field(default=None, description="Maximum value for numbers")


class ConfigStatus(BaseModel):
    """Configuration synchronization status."""

    applied_hash: str = Field(description="Hash of last-applied configuration")
    pending_hash: str = Field(description="Hash of current in-memory configuration")
    needs_reload: bool = Field(description="True if pending differs from applied")
    pending_changes: int = Field(
        default=0, description="Number of options changed since last reload"
    )


class ConfigUpdateRequest(BaseModel):
    """Request to update a single configuration option."""

    value: Any = Field(description="New value for the option")


class ConfigReloadResult(BaseModel):
    """Result of a configuration reload operation."""

    status: ConfigStatus = Field(description="Updated configuration status")
    reloaded: bool = Field(description="True if reload was performed")
    message: str = Field(default="", description="Optional status message")
