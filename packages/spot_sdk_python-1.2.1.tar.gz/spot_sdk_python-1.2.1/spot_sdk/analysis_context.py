"""Ergonomic accessor for Email.analysis_context.

Wraps the stage-scoped dict produced by the orchestrator so analyzers can
look up previous stage results without writing manual dict traversal.

The underlying structure is:

    {
      "<stage-name>": {
        "analyzers": {"<analyzer-id>": {...AnalyzerResult fields...}}
      },
      ...
    }
"""

from __future__ import annotations

from typing import Any, cast


class AnalysisContextReader:
    """Read-only accessor for Email.analysis_context data.

    Use via the Email.ctx property:

        nlp = email.ctx.analyzer("analyzer-nlp")
        if nlp:
            confidence = nlp["confidence"]

        # All analyzers in a specific stage
        for aid, data in email.ctx.analyzers_in("parallel-analysis").items():
            ...

    Missing keys return None (single accessors) or empty dict (bulk accessors).
    Nothing in this class raises.
    """

    def __init__(self, context: dict[str, Any] | None) -> None:
        self._ctx: dict[str, Any] = context or {}

    # ------------------------------------------------------------------
    # Stage listing
    # ------------------------------------------------------------------
    def stages(self) -> list[str]:
        """Return the names of all stages that have completed, in insertion order."""
        return list(self._ctx.keys())

    def has_stage(self, stage: str) -> bool:
        """Return True if the given stage has completed."""
        return stage in self._ctx

    # ------------------------------------------------------------------
    # Analyzer accessors
    # ------------------------------------------------------------------
    def analyzer_ids(self) -> list[str]:
        """Return all analyzer IDs across all stages (deduplicated, stable order)."""
        seen: dict[str, None] = {}
        for stage in self._ctx.values():
            for aid in (stage.get("analyzers") or {}).keys():
                seen[aid] = None
        return list(seen.keys())

    def analyzer_ids_in(self, stage: str) -> list[str]:
        """Return analyzer IDs in a specific stage. Empty list if stage is absent."""
        return list((self._ctx.get(stage, {}).get("analyzers") or {}).keys())

    def analyzer(
        self, analyzer_id: str, stage: str | None = None
    ) -> dict[str, Any] | None:
        """Return a single analyzer result, or None if not found.

        If ``stage`` is given, only look in that stage.
        If ``stage`` is None, return the first match across all stages (in stage order).
        """
        if stage is not None:
            hit = (self._ctx.get(stage, {}).get("analyzers") or {}).get(analyzer_id)
            return cast("dict[str, Any] | None", hit)
        for stage_data in self._ctx.values():
            analyzers = stage_data.get("analyzers") or {}
            if analyzer_id in analyzers:
                return cast("dict[str, Any]", analyzers[analyzer_id])
        return None

    def analyzers_in(self, stage: str) -> dict[str, dict[str, Any]]:
        """Return all analyzer results in a stage as {analyzer_id: data}.

        Empty dict if the stage is absent or has no analyzers.
        """
        return dict(self._ctx.get(stage, {}).get("analyzers") or {})

    def all_analyzers(self) -> dict[str, dict[str, dict[str, Any]]]:
        """Return all analyzer results across every stage.

        Shape: ``{stage_name: {analyzer_id: data, ...}, ...}``
        """
        return {
            stage_name: dict(stage_data.get("analyzers") or {})
            for stage_name, stage_data in self._ctx.items()
        }
