"""
Standard logging configuration for SPOT platform.

Uses Python's built-in logging with dictConfig.
Simple, configurable via environment variables.
"""

from __future__ import annotations

import logging
import logging.config
import os
from typing import Any, Optional


def get_log_level() -> str:
    """Get log level from environment, default to INFO."""
    return os.getenv("LOG_LEVEL", "INFO").upper()


def get_log_format() -> str:
    """Get log format from environment, default to simple."""
    return os.getenv("LOG_FORMAT", "simple").lower()


def get_logging_config(
    log_level: Optional[str] = None, log_format: Optional[str] = None
) -> dict[str, Any]:
    """
    Get logging configuration dictionary for dictConfig.

    Args:
        log_level: Log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_format: Format style (simple, detailed, json)

    Returns:
        Dictionary suitable for logging.config.dictConfig
    """
    level = log_level or get_log_level()
    fmt = log_format or get_log_format()

    # Choose format string
    if fmt == "json":
        format_str = '{"timestamp": "%(asctime)s", "level": "%(levelname)s", "logger": "%(name)s", "message": "%(message)s"}'
    elif fmt == "detailed":
        format_str = "%(asctime)s - %(name)-20s - %(levelname)-8s - [%(filename)s:%(lineno)d] - %(message)s"
    else:  # simple
        format_str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

    config = {
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "default": {
                "format": format_str,
                "datefmt": "%Y-%m-%d %H:%M:%S" if fmt == "detailed" else "%H:%M:%S",
            }
        },
        "handlers": {
            "console": {
                "class": "logging.StreamHandler",
                "formatter": "default",
                "stream": "ext://sys.stdout",
            }
        },
        "root": {"level": level, "handlers": ["console"]},
    }

    # Add file handler if LOG_FILE is specified
    log_file = os.getenv("LOG_FILE")
    if log_file:
        config["handlers"]["file"] = {  # type: ignore[index]
            "class": "logging.FileHandler",
            "formatter": "default",
            "filename": log_file,
            "mode": "a",
        }
        config["root"]["handlers"].append("file")  # type: ignore[index]

    return config


def configure_logging(
    log_level: Optional[str] = None, log_format: Optional[str] = None
) -> None:
    """
    Configure logging for the application.

    Call this once during application startup.

    Args:
        log_level: Log level (default: from LOG_LEVEL env var or INFO)
        log_format: Format style (default: from LOG_FORMAT env var or simple)

    Environment Variables:
        LOG_LEVEL: DEBUG, INFO, WARNING, ERROR, CRITICAL (default: INFO)
        LOG_FORMAT: json, simple, detailed (default: simple)
        LOG_FILE: Path to log file (optional, logs to console if not set)
    """
    config = get_logging_config(log_level, log_format)
    logging.config.dictConfig(config)

    # Log configuration
    logger = logging.getLogger("spot.logging")
    level = log_level or get_log_level()
    fmt = log_format or get_log_format()
    log_file = os.getenv("LOG_FILE")

    log_targets = "console"
    if log_file:
        log_targets += f" and file ({log_file})"

    logger.info(
        f"Logging configured - Level: {level}, Format: {fmt}, Output: {log_targets}"
    )


def get_logger(name: str) -> logging.Logger:
    """
    Get a logger instance for the given name.

    Args:
        name: Logger name, typically __name__

    Returns:
        Standard Python logger

    Example:
        logger = get_logger(__name__)
        logger.info("Service started")
        logger.debug("Processing email", extra={"email_id": "123"})
    """
    return logging.getLogger(name)
