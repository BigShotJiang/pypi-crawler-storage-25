"""Configuration client for SPOT analyzers.

Provides:
- Remote config fetching from core platform
- Graceful handling of network errors (preserves last known good config)
- Simple interface for getting config values

Error handling:
- On 404: Reset config (no central config, use local defaults)
- On network/timeout errors: Keep last known good config unchanged

Usage in analyzer main.py:
    from spot_sdk.config_client import ConfigClient

    config_client = ConfigClient(
        analyzer_id="spot-analyzer-nlp",
        platform_url="http://api-gateway:8000",
    )

    # Fetch config on startup
    await config_client.fetch_config()

    # Get config values (with fallback to defaults)
    threshold = config_client.get("confidence_threshold", 0.7)

    # Reload config (called from /admin/reload-config endpoint)
    await config_client.reload()
"""

from __future__ import annotations

from typing import Any

import httpx

from .logging import get_logger

logger = get_logger(__name__)


class ConfigClient:
    """Client for fetching configuration from SPOT platform.

    Analyzers use this to fetch their centralized configuration overrides
    from the api-gateway's /api/v1/config/analyzer/{id} endpoint.

    The config is stored internally and can be accessed via get() method.
    On network errors, the last known good config is preserved.
    On 404, config is reset (meaning no central config exists).
    """

    def __init__(
        self,
        analyzer_id: str,
        platform_url: str = "http://api-gateway:8000",
        timeout: float = 10.0,
    ) -> None:
        """Initialize ConfigClient.

        Args:
            analyzer_id: The analyzer identifier (e.g., "spot-analyzer-nlp")
            platform_url: Base URL of the api-gateway (default: http://api-gateway:8000)
            timeout: HTTP request timeout in seconds (default: 10.0)
        """
        self.analyzer_id = analyzer_id
        self.platform_url = platform_url.rstrip("/")
        self.timeout = timeout

        # Internal state
        self._config: dict[str, Any] = {}
        self._version: str | None = None
        self._enabled: bool = True

    @property
    def config(self) -> dict[str, Any]:
        """Get the current configuration dict."""
        return self._config

    @property
    def version(self) -> str | None:
        """Get the current config version (None if never fetched successfully)."""
        return self._version

    @property
    def enabled(self) -> bool:
        """Check if analyzer is enabled in central config."""
        return self._enabled

    async def fetch_config(self) -> dict[str, Any]:
        """Fetch configuration from platform.

        Makes HTTP GET request to /api/v1/config/analyzer/{analyzer_id}.

        On success: Updates internal state with new settings.
        On 404: Resets config to empty (no central config, use local defaults).
        On network error: Keeps last known good config unchanged.

        Returns:
            Dict of configuration settings (may be unchanged on network error).
        """
        url = f"{self.platform_url}/api/v1/config/analyzer/{self.analyzer_id}"

        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(url)

                if response.status_code == 404:
                    # No central config for this analyzer - reset to empty
                    logger.info(
                        "No central config for %s, using local defaults",
                        self.analyzer_id,
                    )
                    self._config = {}
                    self._version = None
                    self._enabled = True
                    return self._config

                response.raise_for_status()
                data = response.json()

                # Update state only on successful response
                self._config = data.get("settings", {})
                self._version = data.get("config_version")
                self._enabled = data.get("enabled", True)

                logger.info(
                    "Fetched config for %s (version=%s, enabled=%s, keys=%s)",
                    self.analyzer_id,
                    self._version,
                    self._enabled,
                    list(self._config.keys()),
                )

                return self._config

        except httpx.ConnectError as e:
            # Network error - keep last known good config
            logger.warning(
                "Cannot connect to platform at %s: %s. Keeping current config.",
                self.platform_url,
                e,
            )
            return self._config

        except httpx.TimeoutException:
            # Timeout - keep last known good config
            logger.warning(
                "Timeout fetching config from %s. Keeping current config.",
                url,
            )
            return self._config

        except httpx.HTTPStatusError as e:
            # HTTP error (not 404) - keep last known good config
            logger.warning(
                "HTTP error fetching config for %s: %s. Keeping current config.",
                self.analyzer_id,
                e,
            )
            return self._config

        except Exception as e:
            # Unexpected error - keep last known good config
            logger.warning(
                "Unexpected error fetching config for %s: %s. Keeping current config.",
                self.analyzer_id,
                e,
            )
            return self._config

    async def reload(self) -> dict[str, Any]:
        """Reload configuration from platform.

        Alias for fetch_config(), called when analyzer receives reload signal.

        Returns:
            Dict of configuration settings.
        """
        logger.info("Reloading config for %s", self.analyzer_id)
        return await self.fetch_config()

    def get(self, key: str, default: Any = None) -> Any:
        """Get a configuration value.

        Args:
            key: Configuration key name
            default: Default value if key not found

        Returns:
            Configuration value or default.
        """
        return self._config.get(key, default)

    def has(self, key: str) -> bool:
        """Check if a configuration key exists.

        Args:
            key: Configuration key name

        Returns:
            True if key exists in config.
        """
        return key in self._config
