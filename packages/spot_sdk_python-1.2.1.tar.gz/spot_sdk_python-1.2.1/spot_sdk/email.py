"""Email data models."""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel, EmailStr, Field, field_validator, model_validator

if TYPE_CHECKING:
    from .analysis_context import AnalysisContextReader


class EmailHeader(BaseModel):
    """Email header fields."""

    message_id: str
    subject: str
    sender: EmailStr
    recipients: list[EmailStr] = Field(..., min_length=1)
    cc: list[EmailStr] = Field(default_factory=list)
    bcc: list[EmailStr] = Field(default_factory=list)
    date: datetime
    reply_to: EmailStr | None = None
    return_path: EmailStr | None = None

    # Raw headers for advanced analysis
    raw_headers: dict[str, str] = Field(default_factory=dict)

    @field_validator("recipients", "cc", "bcc", mode="before")
    @classmethod
    def ensure_list(cls, v: Any) -> list[str]:
        if isinstance(v, str):
            return [v]
        return v or []


class Attachment(BaseModel):
    """Email attachment."""

    filename: str
    content_type: str
    size_bytes: int
    content_hash: str  # SHA256 hash
    is_inline: bool = False

    # Optional: actual content for analysis (base64 encoded)
    content: str | None = None

    @field_validator("content_hash")
    @classmethod
    def validate_hash(cls, v: str) -> str:
        if len(v) != 64:  # SHA256 is 64 hex chars
            raise ValueError("content_hash must be a valid SHA256 hash")
        return v


class Email(BaseModel):
    """
    Complete email representation for analysis.

    This model contains all email data needed for phishing detection
    while maintaining GDPR compliance through optional anonymization.
    """

    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    headers: EmailHeader
    body_text: str | None = None
    body_html: str | None = None
    attachments: list[Attachment] = Field(default_factory=list)

    # Metadata
    received_at: datetime = Field(default_factory=datetime.utcnow)
    language: str | None = None  # ISO 639-1 language code
    source: str = "unknown"  # imap, smtp, api, etc.

    # Analysis context
    organization_context: dict[str, str] = Field(default_factory=dict)

    # Context from previously-executed workflow stages, populated by the orchestrator.
    #
    # Structure:
    #   {
    #     "<stage-name>": {
    #       "providers": {"<provider-id>": {...data...}},
    #       "analyzers": {"<analyzer-id>": {...AnalyzerResult fields...}}
    #     },
    #     ...
    #   }
    #
    # Only stages that have already completed are included. Empty dict by default.
    analysis_context: dict[str, Any] = Field(default_factory=dict)

    # Operator policy for Knowledge Store retrieval inside the current stage.
    # Populated by the orchestrator from WorkflowStage.retrieval_limits and
    # consumed transparently by KnowledgeClient.for_analysis(email). Empty
    # dict means "no caps" (use analyzer-supplied parameters as-is).
    retrieval_limits: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def ensure_content(self) -> "Email":
        """Ensure at least one body format is provided."""
        if not self.body_text and not self.body_html:
            raise ValueError("Email must have either body_text or body_html")
        return self

    @property
    def content(self) -> str:
        """Get email content, preferring text over HTML."""
        return self.body_text or self.body_html or ""

    @property
    def has_attachments(self) -> bool:
        """Check if email has attachments."""
        return len(self.attachments) > 0

    @property
    def ctx(self) -> "AnalysisContextReader":
        """Ergonomic accessor for analysis_context from previous stages.

        Example:
            nlp = email.ctx.analyzer("analyzer-nlp")
            if nlp:
                confidence = nlp["confidence"]
        """
        # Imported lazily to avoid a circular reference at module import time
        from .analysis_context import AnalysisContextReader

        return AnalysisContextReader(self.analysis_context)

    def get_urls(self) -> list[str]:
        """Extract URLs from email content (to be implemented in analyzer)."""
        # This would be implemented in the actual analyzer
        # Placeholder for interface definition
        return []
