"""Plugin vocabulary shared across the platform.

A "plugin" is any pluggable component registered with a SPOT platform
through the plugin catalog, installer, and sources. Plugins come in
three kinds today:

- ``analyzer``: runs ``POST /internal/analyze`` and produces an
  ``AnalysisResult`` (a phishing verdict contributing to aggregation).
- ``context_provider``: runs ``POST /internal/enrich`` and produces an
  ``EnrichmentResult`` whose data populates ``analysis_context`` for
  downstream analyzers.
- ``mail_retriever``: ingests emails from any source (SMTP filter,
  IMAP, mailbox API, ...) and submits them to the platform via
  ``POST /internal/ingest`` on the mail-orchestrator. Retrievers push;
  the platform never polls them.

The ``PluginKind`` value is surfaced by the platform catalog (derived
from OCI image labels) so the installer can route a plugin to the
correct section of ``spot.yaml``.
"""

from __future__ import annotations

from enum import Enum


class PluginKind(str, Enum):
    """Discriminator for pluggable SPOT components."""

    ANALYZER = "analyzer"
    CONTEXT_PROVIDER = "context_provider"
    MAIL_RETRIEVER = "mail_retriever"

    def __str__(self) -> str:  # pragma: no cover - trivial
        return self.value
