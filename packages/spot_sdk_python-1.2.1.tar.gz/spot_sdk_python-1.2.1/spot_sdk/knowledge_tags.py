"""Well-known shared-vocabulary tag constants for the Knowledge Store.

Tags are plain strings on ``KnowledgeDocument.tags``; these constants
encode the recommended common vocabulary so providers and analyzers
agree on the same labels. External developers may introduce private
tags (e.g. ``"acme:jira_issue"``) without changing the SDK.
"""

from __future__ import annotations


class KnowledgeTag:
    """Common tag constants. Use these for interoperability across plugins."""

    # ----- "Kind" tags: what is this document? -----
    EMPLOYEE = "employee"
    WIKI_PAGE = "wiki_page"
    POLICY = "policy"
    ORG_CHART = "org_chart"
    INCIDENT_REPORT = "incident_report"
    TICKET = "ticket"
    THREAT_REPORT = "threat_report"
    SENDER_HISTORY = "sender_history"

    # ----- "Subset" tags: who/what is this about? -----
    EXECUTIVE = "executive"
    FINANCE = "finance"
    ENGINEERING = "engineering"
    HR = "hr"
    PUBLIC = "public"
    INTERNAL = "internal"
