"""Standard error response models for SPOT API."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class ErrorResponse(BaseModel):
    """Standard error response for all SPOT API endpoints.

    Provides a consistent error format across the platform:
    - ``error``: machine-readable error code (e.g. "not_found", "validation_error")
    - ``message``: human-readable explanation
    - ``details``: optional structured context (validation errors, field info, etc.)
    """

    error: str = Field(..., description="Machine-readable error code")
    message: str = Field(..., description="Human-readable error message")
    details: dict[str, Any] = Field(
        default_factory=dict,
        description="Optional structured details about the error",
    )
