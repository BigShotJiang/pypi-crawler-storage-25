"""Test data factories for SPOT SDK.

Simple functions to create test data as plain dictionaries.
These work with spot_sdk models when validated via Pydantic.
"""

from datetime import datetime, timezone
from typing import Any


def create_test_email(
    subject: str = "Team Meeting Tomorrow",
    sender: str = "alice@company.com",
    recipients: list[str] | None = None,
    body_text: str = "Hi team, don't forget about our meeting tomorrow.",
) -> dict[str, Any]:
    """Create a legitimate test email.

    Args:
        subject: Email subject
        sender: Sender email address
        recipients: List of recipient addresses
        body_text: Email body text

    Returns:
        Email data dictionary
    """
    if recipients is None:
        recipients = ["team@company.com"]

    return {
        "id": "test-email-123",
        "headers": {
            "message_id": "<test@test.com>",
            "subject": subject,
            "sender": sender,
            "recipients": recipients,
            "date": datetime.now(timezone.utc).isoformat(),
        },
        "body_text": body_text,
        "body_html": None,
        "attachments": [],
        "received_at": datetime.now(timezone.utc).isoformat(),
    }


def create_phishing_email() -> dict[str, Any]:
    """Create a phishing test email with common phishing indicators.

    Returns:
        Email data dictionary with phishing characteristics
    """
    return {
        "id": "phishing-email-456",
        "headers": {
            "message_id": "<phish@evil.com>",
            "subject": "URGENT: Verify Your Account Now!",
            "sender": "security@paypal-verify.com",
            "recipients": ["victim@company.com"],
            "date": datetime.now(timezone.utc).isoformat(),
        },
        "body_text": (
            "Your account has been suspended due to suspicious activity. "
            "Click here immediately to verify: http://bit.ly/fake-link"
        ),
        "body_html": None,
        "attachments": [],
        "received_at": datetime.now(timezone.utc).isoformat(),
    }


def create_test_indicator(
    indicator_type: str = "URGENT_LANGUAGE",
    description: str = "Urgent language detected",
    severity: str = "medium",
    confidence: float = 0.8,
) -> dict[str, Any]:
    """Create a test analysis indicator.

    Args:
        indicator_type: Type of indicator
        description: Human-readable description
        severity: Severity level (low, medium, high)
        confidence: Confidence score (0.0-1.0)

    Returns:
        Indicator data dictionary
    """
    return {
        "type": indicator_type,
        "description": description,
        "severity": severity,
        "confidence": confidence,
        "source_analyzer": "test-analyzer",
    }


def create_test_analysis_result(
    is_phishing: bool = False,
    confidence: float = 0.9,
    threat_level: str = "SAFE",
    indicators: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Create a test analysis result.

    Args:
        is_phishing: Whether email is classified as phishing
        confidence: Confidence score (0.0-1.0)
        threat_level: Threat level (SAFE, LOW, MEDIUM, HIGH, CRITICAL)
        indicators: List of indicators (created if None)

    Returns:
        Analysis result data dictionary
    """
    if indicators is None:
        indicators = []
        if is_phishing:
            indicators.append(create_test_indicator())

    return {
        "is_phishing": is_phishing,
        "confidence": confidence,
        "threat_level": threat_level,
        "indicators": indicators,
        "metadata": {
            "analyzer_id": "test-analyzer",
            "analyzer_version": "1.0.0",
            "analysis_timestamp": datetime.now(timezone.utc).isoformat(),
            "processing_time_ms": 100,
        },
        "explanation": "Test analysis result",
        "raw_output": {},
    }


def create_analysis_request(
    email: dict[str, Any] | None = None,
    workflow_id: str = "default-workflow",
) -> dict[str, Any]:
    """Create an analysis request.

    Args:
        email: Email data dictionary (created if None)
        workflow_id: Workflow ID to use

    Returns:
        Analysis request dictionary
    """
    return {
        "email": email or create_test_email(),
        "workflow_id": workflow_id,
    }


def create_test_user(
    username: str = "testuser",
    email: str = "testuser@test.com",
    is_active: bool = True,
    is_superuser: bool = False,
) -> dict[str, Any]:
    """Create test user data.

    Args:
        username: Username
        email: Email address
        is_active: Whether user is active
        is_superuser: Whether user is superuser

    Returns:
        User data dictionary
    """
    return {
        "username": username,
        "email": email,
        "is_active": is_active,
        "is_superuser": is_superuser,
    }
