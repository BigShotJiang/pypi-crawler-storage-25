# SPOT SDK Testing Utilities

Shared test utilities for all SPOT projects (platform and analyzers).

## Installation

The testing module is included with spot-sdk:

```python
from spot_sdk.testing import (
    create_test_email,
    create_phishing_email,
    create_test_analysis_result,
    create_test_indicator,
)
```

## Usage

### Creating Test Emails

```python
# Create a legitimate email
email = create_test_email(
    subject="Meeting Tomorrow",
    sender="alice@company.com",
    recipients=["team@company.com"],
    body_text="Don't forget our meeting."
)

# Create a phishing email with common indicators
phishing_email = create_phishing_email()
```

### Creating Test Analysis Results

```python
# Create a safe analysis result
result = create_test_analysis_result(
    is_phishing=False,
    confidence=0.9,
    threat_level="SAFE"
)

# Create a phishing detection result
phishing_result = create_test_analysis_result(
    is_phishing=True,
    confidence=0.95,
    threat_level="HIGH",
    indicators=[
        create_test_indicator(
            indicator_type="URGENT_LANGUAGE",
            description="Urgent language detected",
            severity="high",
            confidence=0.9
        )
    ]
)
```

## In pytest

Use these factories in your conftest.py:

```python
import pytest
from spot_sdk.testing import create_test_email, create_phishing_email

@pytest.fixture
def sample_email():
    return create_test_email()

@pytest.fixture
def phishing_email():
    return create_phishing_email()
```

## Design Philosophy

- **Simple**: Plain dictionaries, not complex mocks
- **Practical**: Real test data that works with actual SDK models
- **Flexible**: Easy to customize for specific test cases
- **No magic**: No auto-mocking or complex test frameworks
