"""In-memory fake of :class:`spot_sdk.knowledge.KnowledgeClient` for tests.

No HTTP, no embedding, no vector math — just a dict keyed by ``id``
that supports the same upsert/fetch/delete methods. ``fetch()`` does
naive substring matching over content + tag-expression filtering, which
is enough for plugin unit tests to assert that an analyzer reads
documents out of the store.

Usage::

    from spot_sdk.testing.fake_knowledge_client import FakeKnowledgeClient

    kb = FakeKnowledgeClient()
    await kb.upsert(KnowledgeDocument(id="...", content="...", tags=[...]))
    docs = await kb.fetch(text="alice", tags="employee")
"""

from __future__ import annotations

import re
from typing import Any

from ..knowledge import KnowledgeDocument


class FakeKnowledgeClient:
    """In-memory fake compatible with :class:`KnowledgeClient`."""

    def __init__(self, retrieval_limits: dict[str, Any] | None = None) -> None:
        self._docs: dict[str, KnowledgeDocument] = {}
        self._limits = dict(retrieval_limits or {})

    # --- write side ---------------------------------------------------- #

    async def upsert(self, doc: KnowledgeDocument) -> None:
        self._docs[doc.id] = doc

    async def bulk_upsert(self, docs: list[KnowledgeDocument]) -> None:
        for d in docs:
            self._docs[d.id] = d

    async def delete(self, doc_id: str) -> None:
        self._docs.pop(doc_id, None)

    # --- read side ----------------------------------------------------- #

    async def fetch(
        self,
        tags: str | None = None,
        text: str | None = None,
        top_k: int = 5,
        min_score: float = 0.0,
        strategy: str = "similarity",
    ) -> list[KnowledgeDocument]:
        if text is None or not text.strip():
            raise ValueError("fetch() requires a non-empty 'text' argument")

        # Apply caps
        max_top_k = self._limits.get("max_top_k")
        if max_top_k is not None and top_k > max_top_k:
            top_k = max_top_k
        floor = self._limits.get("min_score_floor")
        if floor is not None and min_score < floor:
            min_score = floor

        # Tag filter
        candidates = list(self._docs.values())
        if tags:
            candidates = [d for d in candidates if _match_tag_expr(d.tags, tags)]

        # Scored by naive substring overlap (good enough for tests)
        terms = [t for t in re.split(r"\s+", text.lower()) if t]
        scored: list[tuple[float, KnowledgeDocument]] = []
        for d in candidates:
            content_lower = d.content.lower()
            hits = sum(1 for t in terms if t in content_lower)
            score = hits / max(len(terms), 1)
            if score >= min_score:
                scored.append((score, d.model_copy(update={"score": score})))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [d for _, d in scored[:top_k]]

    # --- test helpers -------------------------------------------------- #

    def all(self) -> list[KnowledgeDocument]:
        """Return all stored documents (test helper)."""
        return list(self._docs.values())

    def clear(self) -> None:
        """Remove all stored documents (test helper)."""
        self._docs.clear()


# Same tiny tag-expression evaluator used by the real store.
# Grammar: term (op term)*  where op is '+' (AND) or '|' (OR).
# AND binds tighter than OR; no parentheses.
def _match_tag_expr(doc_tags: list[str], expr: str) -> bool:
    tag_set = set(doc_tags)
    or_groups = expr.split("|")
    for group in or_groups:
        and_terms = [t.strip() for t in group.split("+") if t.strip()]
        if and_terms and all(t in tag_set for t in and_terms):
            return True
    return False
