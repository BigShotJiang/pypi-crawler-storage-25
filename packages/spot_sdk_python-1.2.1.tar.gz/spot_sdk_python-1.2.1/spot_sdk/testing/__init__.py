"""SPOT SDK Testing Utilities.

Shared test fixtures, factories, and utilities for all SPOT projects.
"""

from .factories import (
    create_analysis_request,
    create_phishing_email,
    create_test_analysis_result,
    create_test_email,
    create_test_indicator,
    create_test_user,
)

__all__ = [
    "create_test_email",
    "create_phishing_email",
    "create_test_analysis_result",
    "create_test_indicator",
    "create_analysis_request",
    "create_test_user",
]
