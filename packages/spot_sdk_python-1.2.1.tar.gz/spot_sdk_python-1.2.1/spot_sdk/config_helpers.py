"""Shared configuration helpers for SPOT analyzers."""

from typing import Any, TypeVar

from pydantic_settings import BaseSettings

T = TypeVar("T", bound=BaseSettings)


def merge_settings(settings_class: type[T], base: T, overrides: dict[str, Any]) -> T:
    """Merge base settings with central overrides.

    Override keys are matched case-insensitively against the Pydantic
    field names. This lets the dashboard / spot.yaml use the
    operator-friendly uppercase convention (``MODEL_PATH``,
    ``LISTEN_PORT``, ...) while the Settings class keeps the Python
    lowercase convention (``model_path``, ``listen_port``).

    Args:
        settings_class: The Pydantic Settings class (used for field discovery).
        base: Base Settings instance from local env/defaults.
        overrides: Override values from central config (any case).

    Returns:
        New Settings instance with overrides applied. Keys that do not
        match any field on ``settings_class`` are silently dropped.
    """
    field_by_lower = {name.lower(): name for name in settings_class.model_fields}
    filtered: dict[str, Any] = {}
    for key, value in overrides.items():
        canonical = field_by_lower.get(key.lower())
        if canonical is not None:
            filtered[canonical] = value
    return base.model_copy(update=filtered)
