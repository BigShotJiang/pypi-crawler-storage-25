"""Standardized threat level computation for SPOT analyzers."""

from .analyzer import ThreatLevel


def confidence_to_threat_level(
    confidence: float,
    *,
    high: float = 0.8,
    medium: float = 0.5,
    low: float = 0.2,
) -> ThreatLevel:
    """Map a confidence score to a ThreatLevel.

    Uses consistent default thresholds across all analyzers.
    Individual analyzers can override thresholds via keyword arguments.

    Args:
        confidence: Confidence score in [0.0, 1.0].
        high: Threshold for HIGH (default 0.8).
        medium: Threshold for MEDIUM (default 0.5).
        low: Threshold for LOW (default 0.2).

    Returns:
        The corresponding ThreatLevel.
    """
    if confidence >= high:
        return ThreatLevel.HIGH
    if confidence >= medium:
        return ThreatLevel.MEDIUM
    if confidence >= low:
        return ThreatLevel.LOW
    return ThreatLevel.SAFE
