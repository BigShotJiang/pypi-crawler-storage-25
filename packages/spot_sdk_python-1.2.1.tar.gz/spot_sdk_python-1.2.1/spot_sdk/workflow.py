"""Workflow configuration models for SPOT platform."""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, Field


class FailureStrategy(str, Enum):
    """Strategy for handling analyzer failures."""

    RETRY = "retry"
    SKIP = "skip"
    FAIL = "fail"
    FALLBACK = "fallback"


class RetryConfig(BaseModel):
    """Retry configuration for analyzer execution."""

    max_attempts: int = Field(
        default=3, ge=1, le=10, description="Maximum number of retry attempts"
    )
    backoff_ms: int = Field(
        default=1000,
        ge=100,
        le=60000,
        description="Initial backoff time in milliseconds",
    )
    max_backoff_ms: int = Field(
        default=10000,
        ge=1000,
        le=300000,
        description="Maximum backoff time in milliseconds",
    )
    exponential_backoff: bool = Field(
        default=True, description="Use exponential backoff"
    )


class AnalyzerConfig(BaseModel):
    """Configuration for a single analyzer in a workflow stage."""

    id: str = Field(..., description="Analyzer ID")
    weight: float = Field(
        default=1.0, ge=0.0, le=10.0, description="Weight for result aggregation"
    )
    timeout_ms: int = Field(
        default=30000, ge=1000, le=300000, description="Timeout in milliseconds"
    )
    required: bool = Field(
        default=False, description="Whether this analyzer is required"
    )
    failure_strategy: FailureStrategy = Field(
        default=FailureStrategy.RETRY, description="Failure handling strategy"
    )
    retry_config: RetryConfig = Field(
        default_factory=RetryConfig, description="Retry configuration"
    )
    condition: str | None = Field(None, description="Conditional execution expression")


class RetrievalLimits(BaseModel):
    """Operator policy for Knowledge Store retrieval inside a stage.

    Caps only — these shrink what an analyzer asks for, never expand it.
    The orchestrator passes this on the per-analysis request payload;
    ``KnowledgeClient.for_analysis(email)`` enforces them transparently.
    """

    max_top_k: int | None = Field(
        default=None,
        ge=1,
        le=1000,
        description="Cap on top_k requested by any analyzer in this stage",
    )
    min_score_floor: float | None = Field(
        default=None,
        ge=0.0,
        le=1.0,
        description="Raise the min_score floor even if analyzer asked for less",
    )


class WorkflowStage(BaseModel):
    """A stage in a workflow with multiple analyzers."""

    name: str = Field(..., description="Stage name")
    type: str = Field(
        default="sequential",
        description="Stage type (parallel, sequential, conditional)",
    )
    analyzers: list[AnalyzerConfig] = Field(
        default_factory=list, description="List of analyzers in this stage"
    )
    retrieval_limits: RetrievalLimits | None = Field(
        default=None,
        description="Operator-policy caps on knowledge-store retrieval for this stage",
    )
    depends_on: list[str] = Field(
        default_factory=list, description="Names of stages this depends on"
    )
    continue_on_failure: bool = Field(
        default=True, description="Continue if some analyzers fail"
    )
    min_successful_analyzers: int = Field(
        default=1, ge=0, description="Minimum successful analyzers required"
    )
    aggregation_method: str = Field(
        default="weighted_average", description="Method for aggregating results"
    )
    condition: str | None = Field(None, description="Conditional execution expression")


class Workflow(BaseModel):
    """Complete workflow configuration for email analysis."""

    id: str = Field(..., description="Workflow ID")
    name: str = Field(..., description="Workflow name")
    version: int = Field(default=1, ge=1, description="Workflow version")
    description: str = Field(default="", description="Workflow description")
    stages: list[WorkflowStage] = Field(
        default_factory=list, description="List of workflow stages"
    )
    final_stage_name: str = Field(
        default="",
        description="Name of the final decision stage. Empty means aggregate all results.",
    )
    timeout_ms: int = Field(
        default=300000,
        ge=1000,
        le=600000,
        description="Total workflow timeout in milliseconds",
    )
    max_parallel_analyzers: int = Field(
        default=10, ge=1, le=100, description="Maximum parallel analyzer executions"
    )
    created_by: str = Field(default="system", description="Creator of the workflow")
