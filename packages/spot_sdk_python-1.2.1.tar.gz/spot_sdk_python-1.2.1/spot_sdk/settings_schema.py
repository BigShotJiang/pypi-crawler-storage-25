"""Analyzer settings schema endpoint registration.

Provides a helper to register a /settings/schema endpoint on any analyzer's
FastAPI app. The endpoint returns the JSON Schema of the analyzer's Pydantic
Settings model, which the platform uses to render typed configuration forms.

Usage in an analyzer's main.py:

    from spot_sdk.settings_schema import register_settings_schema
    from .config import Settings

    app = FastAPI(...)
    register_settings_schema(app, Settings)
"""

from typing import Any

from fastapi import FastAPI
from pydantic_settings import BaseSettings


def register_settings_schema(app: FastAPI, settings_class: type[BaseSettings]) -> None:
    """Register /settings/schema and /settings/values endpoints on a FastAPI app.

    Args:
        app: FastAPI application instance.
        settings_class: The Pydantic BaseSettings class used by the analyzer.
    """

    @app.get("/settings/schema")
    async def get_settings_schema() -> dict[str, Any]:
        """Return JSON Schema for this analyzer's settings.

        The schema includes field types, defaults, constraints (min/max),
        and descriptions. The platform uses this to render typed forms
        in the web dashboard.
        """
        return settings_class.model_json_schema()

    @app.get("/settings/values")
    async def get_settings_values() -> dict[str, Any]:
        """Return current effective settings values.

        Useful for debugging to see what values the analyzer is running with.
        Sensitive fields (containing 'key', 'secret', 'password', 'token')
        are redacted.
        """
        instance = settings_class()
        values = instance.model_dump()

        for key in list(values.keys()):
            if any(s in key.lower() for s in ("key", "secret", "password", "token")):
                if values[key]:
                    values[key] = "[REDACTED]"

        return values
