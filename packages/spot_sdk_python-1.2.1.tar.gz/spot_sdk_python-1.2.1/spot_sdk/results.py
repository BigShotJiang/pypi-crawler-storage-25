"""Analysis result models."""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field, field_validator

from .analyzer import ThreatLevel


class IndicatorType(str, Enum):
    """Types of phishing indicators."""

    SUSPICIOUS_SENDER = "suspicious_sender"
    URGENT_LANGUAGE = "urgent_language"
    SUSPICIOUS_LINKS = "suspicious_links"
    MALICIOUS_ATTACHMENT = "malicious_attachment"
    SOCIAL_ENGINEERING = "social_engineering"
    DOMAIN_SPOOFING = "domain_spoofing"
    CREDENTIAL_HARVESTING = "credential_harvesting"
    WIRE_TRANSFER_SCAM = "wire_transfer_scam"
    CEO_FRAUD = "ceo_fraud"
    INVOICE_SCAM = "invoice_scam"
    IMPERSONATION = "impersonation"
    SPELLING_GRAMMAR_ERRORS = "spelling_grammar_errors"
    GENERIC_GREETING = "generic_greeting"
    MISMATCHED_URL = "mismatched_url"
    SUSPICIOUS_TIMING = "suspicious_timing"
    MISP_IOC_MATCH = "misp_ioc_match"
    DOMAIN_REPUTATION = "domain_reputation"
    CONTEXT_MISMATCH = "context_mismatch"
    SPF_FAILURE = "spf_failure"
    UNUSUAL_HEADERS = "unusual_headers"
    ENCODING_ANOMALY = "encoding_anomaly"
    THREATENING_TONE = "threatening_tone"

    def __str__(self) -> str:
        return self.value


class AnalysisIndicator(BaseModel):
    """Individual phishing indicator found in email."""

    type: IndicatorType
    confidence: float = Field(..., ge=0.0, le=1.0)
    description: str
    evidence: str | None = None  # Text excerpt or specific evidence
    severity: str = Field(..., pattern="^(undetermined|low|medium|high|critical)$")

    # Optional: location in email where indicator was found
    location: str | None = None  # "subject", "body", "attachment", "headers"


class AnalysisMetadata(BaseModel):
    """Analysis execution metadata."""

    analyzer_id: str
    analyzer_version: str
    analysis_duration_ms: int
    model_version: str | None = None
    language_detected: str | None = None
    processing_timestamp: datetime = Field(default_factory=datetime.utcnow)

    # Resource usage (optional)
    memory_usage_mb: int | None = None
    cpu_usage_ms: int | None = None


class AnalysisResult(BaseModel):
    """
    Standardized analysis result from any analyzer.

    This is the common format returned by all analyzers,
    enabling consistent processing by the orchestrator.
    """

    # Core classification
    is_phishing: bool
    threat_level: ThreatLevel
    confidence: float = Field(..., ge=0.0, le=1.0)

    # Detailed findings
    indicators: list[AnalysisIndicator] = Field(default_factory=list)
    explanation: str = ""  # Human-readable explanation

    # Metadata
    metadata: AnalysisMetadata

    # Optional: raw analyzer output for debugging
    raw_output: dict[str, Any] | None = None

    # Additional context
    recommendations: list[str] = Field(default_factory=list)
    false_positive_likelihood: float | None = Field(None, ge=0.0, le=1.0)

    @field_validator("threat_level")
    @classmethod
    def validate_threat_consistency(cls, v: str, info: Any) -> str:
        """Ensure threat level is consistent with is_phishing."""
        is_phishing = info.data.get("is_phishing")
        if is_phishing and v == ThreatLevel.SAFE:
            raise ValueError("Cannot have 'safe' threat level when is_phishing=True")
        if not is_phishing and v in (ThreatLevel.HIGH, ThreatLevel.CRITICAL):
            raise ValueError("High/critical threat levels require is_phishing=True")
        return v

    @property
    def risk_score(self) -> int:
        """Calculate numerical risk score (0-100)."""
        base_score = int(self.confidence * 100)

        # Adjust based on threat level
        multipliers = {
            ThreatLevel.SAFE: 0.0,
            ThreatLevel.LOW: 0.3,
            ThreatLevel.MEDIUM: 0.6,
            ThreatLevel.HIGH: 0.8,
            ThreatLevel.CRITICAL: 1.0,
        }

        return int(base_score * multipliers.get(self.threat_level, 0.5))

    @property
    def high_confidence_indicators(self) -> list[AnalysisIndicator]:
        """Get indicators with confidence > 0.7."""
        return [ind for ind in self.indicators if ind.confidence > 0.7]
