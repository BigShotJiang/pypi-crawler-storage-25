"""Parse canonical regulatory citation strings into :class:`Citation`.

The grammar is small enough that a regex per instrument is clearer than
a full parser combinator. The dispatch is keyword-driven on the leading
token; each branch produces a structured :class:`Citation` or raises
:class:`CitationParseError` with a message that names the offending
input.
"""

from __future__ import annotations

import re

from watchfire.model import Citation

__all__ = ["CitationParseError", "parse_citation"]


class CitationParseError(ValueError):
    """Raised when a citation string cannot be parsed.

    The exception message always contains the offending input, quoted,
    and a short reason. ``watchfire check`` surfaces these directly so
    fixing a bad citation is a question of reading the message.
    """


# A token like "(1)", "(a)", "(ii)", "(75)". Captures the inner value.
_PAREN_TOKEN = re.compile(r"\(([^()\s]+)\)")

# A bare integer (used for paragraph parsing in SS/PS where the number
# is sometimes given without parentheses).
_INT_RE = re.compile(r"\d+")

# Section path like "3.2" or "3.2.1". Anchored.
_SECTION_RE = re.compile(r"^\d+(?:\.\d+)*$")

# PS / SS document codes: "PS9/24", "SS1/23".
_PS_ID_RE = re.compile(r"^(PS|SS)\s*(\d+\s*/\s*\d+)$", re.IGNORECASE)

# PS / SS document code anchored at the start of a citation, capturing any
# trailing text (a paragraph tail like ", paragraph 4.1" or an article
# tail like " Art. 111(1)(a)").
_PRA_PUB_HEAD = re.compile(
    r"^(PS|SS)\s*(\d+)\s*/\s*(\d+)(.*)$",
    re.IGNORECASE | re.DOTALL,
)


def parse_citation(s: str) -> Citation:
    """Parse a canonical citation string.

    Accepts the forms documented in the project README. Whitespace is
    normalised; the keyword for ``article`` accepts ``Art``, ``Art.``,
    ``Article`` (any case). Returns a :class:`Citation`; raises
    :class:`CitationParseError` on any malformed input.
    """

    if not isinstance(s, str):
        raise CitationParseError(f"citation must be a string, got {type(s).__name__}")

    text = s.strip()
    if not text:
        raise CitationParseError("citation string is empty")

    # Look at the leading word(s) to choose a parser.
    upper = text.upper()

    if upper.startswith("CRR"):
        return _parse_article_based(text, instrument="CRR", prefix_len=3)

    if upper.startswith("DELEGATED REGULATION") or upper.startswith("DELEGATED REG"):
        return _parse_delegated(text)

    if upper.startswith("PRA RULEBOOK"):
        return _parse_pra_rulebook(text)

    # PS9/24 or SS1/23 (with optional ", paragraph X" or " Art. N(P)(p)" tail).
    m = _PRA_PUB_HEAD.match(text)
    if m:
        kind = m.group(1).upper()
        instrument_id = f"{kind}{m.group(2)}/{m.group(3)}"
        rest = m.group(4)
        return _parse_pra_publication(text, kind, instrument_id, rest)

    raise CitationParseError(
        f"unrecognised instrument in citation {s!r}; "
        "expected one of CRR, PRA Rulebook, PS<n>/<yy>, SS<n>/<yy>, "
        "Delegated Regulation"
    )


# ---------------------------------------------------------------------------
# Article-structured instruments: CRR and Delegated Regulations.
# ---------------------------------------------------------------------------

_ARTICLE_KEYWORD = re.compile(r"art(?:icle)?\.?", re.IGNORECASE)


def _parse_article_based(
    text: str,
    *,
    instrument: str,
    prefix_len: int,
    instrument_id: str | None = None,
) -> Citation:
    body = text[prefix_len:].lstrip(" \t,;:")
    return _parse_article_body(text, body, instrument, instrument_id)


def _parse_article_body(
    raw: str,
    body: str,
    instrument: str,
    instrument_id: str | None,
) -> Citation:
    m = _ARTICLE_KEYWORD.match(body)
    if not m:
        raise CitationParseError(f"expected 'Art.' or 'Article' after '{instrument}' in {raw!r}")
    rest = body[m.end() :].lstrip()
    num_match = re.match(r"(\d+[a-z]*)", rest, re.IGNORECASE)
    if not num_match:
        raise CitationParseError(f"expected article number after 'Art.' in {raw!r}")
    # The digit prefix carries the article number; reject zero in either
    # plain ("0") or suffixed ("0a") form. Trailing letters denote
    # inserted articles (e.g. CRR Art. 92a) — canonicalised to lowercase
    # so '92A' and '92a' compare equal and match the index.
    article = num_match.group(1).lower()
    digit_match = re.match(r"\d+", article)
    assert digit_match is not None  # guaranteed by the outer regex
    if int(digit_match.group(0)) == 0:
        raise CitationParseError(f"article number must be positive in {raw!r}")

    tail = rest[num_match.end() :].strip()
    paragraph, point, subpoint = _parse_paren_tail(tail, raw)

    return Citation(
        instrument=instrument,  # ty: ignore[invalid-argument-type]
        instrument_id=instrument_id,
        article=article,
        paragraph=paragraph,
        point=point,
        subpoint=subpoint,
        raw=raw,
    )


_PARAGRAPH_TOKEN_RE = re.compile(r"\d+[a-z]*", re.IGNORECASE)


def _parse_paren_tail(tail: str, raw: str) -> tuple[str | None, str | None, str | None]:
    """Parse the ``(1)(a)(ii)`` portion that follows an article number.

    Returns a (paragraph, point, subpoint) triple. Missing positions are
    ``None``. Any non-empty, non-parenthesised residue is an error: it
    means the citation has unexpected trailing text.
    """

    if not tail:
        return None, None, None

    tokens: list[str] = []
    pos = 0
    while pos < len(tail):
        # Skip whitespace between tokens.
        while pos < len(tail) and tail[pos].isspace():
            pos += 1
        if pos >= len(tail):
            break
        m = _PAREN_TOKEN.match(tail, pos)
        if not m:
            raise CitationParseError(
                f"unexpected text after article number in {raw!r} "
                f"(at offset {pos} of tail {tail!r})"
            )
        tokens.append(m.group(1))
        pos = m.end()

    if len(tokens) > 3:
        raise CitationParseError(
            f"too many parenthesised parts in {raw!r}; "
            f"expected at most (paragraph)(point)(subpoint)"
        )

    paragraph: str | None = None
    point: str | None = None
    subpoint: str | None = None

    if tokens:
        first = tokens[0]
        if not _PARAGRAPH_TOKEN_RE.fullmatch(first):
            raise CitationParseError(f"paragraph must be an integer in {raw!r}, got '({first})'")
        paragraph = first
    if len(tokens) >= 2:
        point = tokens[1]
    if len(tokens) == 3:
        subpoint = tokens[2]

    return paragraph, point, subpoint


# ---------------------------------------------------------------------------
# Delegated Regulation: "Delegated Regulation 2018/171 Art. 3"
# ---------------------------------------------------------------------------

_DELEGATED_HEAD = re.compile(
    r"^delegated\s+reg(?:ulation)?\s+([0-9]+/[0-9]+)\s*",
    re.IGNORECASE,
)


def _parse_delegated(text: str) -> Citation:
    m = _DELEGATED_HEAD.match(text)
    if not m:
        raise CitationParseError(f"expected 'Delegated Regulation <year>/<num>' in {text!r}")
    instrument_id = m.group(1)
    body = text[m.end() :].lstrip(" \t,;:")
    if not body:
        return Citation(instrument="DELEGATED_REG", instrument_id=instrument_id, raw=text)
    return _parse_article_body(text, body, "DELEGATED_REG", instrument_id)


# ---------------------------------------------------------------------------
# PRA Rulebook: "PRA Rulebook, Credit Risk, 3.2"
# ---------------------------------------------------------------------------


def _parse_pra_rulebook(text: str) -> Citation:
    # Strip leading "PRA Rulebook" (case-insensitive, optional comma).
    body = re.sub(r"^pra\s+rulebook\s*,?\s*", "", text, flags=re.IGNORECASE)
    if not body.strip():
        raise CitationParseError(
            f"PRA Rulebook citation must name a part in {text!r}, "
            "e.g. 'PRA Rulebook, Credit Risk, 3.2'"
        )

    # Split on the final section path: trailing token that looks like
    # "N", "N.N", "N.N.N" etc.
    parts = [p.strip() for p in body.split(",") if p.strip()]
    section: tuple[str, ...] | None = None
    if parts and _SECTION_RE.match(parts[-1]):
        section = tuple(parts[-1].split("."))
        parts = parts[:-1]

    if not parts:
        raise CitationParseError(
            f"PRA Rulebook citation must name a part in {text!r}, "
            "e.g. 'PRA Rulebook, Credit Risk, 3.2'"
        )

    instrument_id = ", ".join(parts)
    return Citation(
        instrument="PRA_RULEBOOK",
        instrument_id=instrument_id,
        section=section,
        raw=text,
    )


# ---------------------------------------------------------------------------
# PRA Publications: PS9/24 and SS1/23, optionally with a paragraph tail.
# ---------------------------------------------------------------------------

_PARAGRAPH_TAIL = re.compile(
    r"^(?:paragraph|para|paragraphs|¶)\s+(\d+[A-Za-z]*(?:\.\d+[A-Za-z]*)*)\s*$",
    re.IGNORECASE,
)


def _parse_pra_publication(text: str, kind: str, instrument_id: str, rest: str) -> Citation:
    stripped = rest.strip()
    if not stripped:
        return Citation(instrument=kind, instrument_id=instrument_id, raw=text)  # ty: ignore[invalid-argument-type]

    # Article-shape tail: "Art. 111(1)(a)" — rulebook instruments attached
    # to a PS (e.g. PS 1/26) carry CRR-style articles, not dotted
    # paragraphs. Delegate to the shared article-body parser.
    if _ARTICLE_KEYWORD.match(stripped):
        return _parse_article_body(text, stripped, kind, instrument_id)

    # Dotted-paragraph tail: ", paragraph 4.1".
    leading = rest.lstrip()
    if leading.startswith(","):
        tail = leading[1:].strip()
        if not tail:
            raise CitationParseError(f"trailing comma with no paragraph reference in {text!r}")
        m = _PARAGRAPH_TAIL.match(tail)
        if not m:
            raise CitationParseError(
                f"unrecognised tail '{tail}' in {text!r}; expected 'paragraph N' or 'paragraph N.N'"
            )
        section = tuple(m.group(1).split("."))
        return Citation(
            instrument=kind,  # ty: ignore[invalid-argument-type]
            instrument_id=instrument_id,
            section=section,
            raw=text,
        )

    raise CitationParseError(
        f"unrecognised tail '{stripped}' in {text!r}; expected 'Art. N(...)' or ', paragraph N.N'"
    )
