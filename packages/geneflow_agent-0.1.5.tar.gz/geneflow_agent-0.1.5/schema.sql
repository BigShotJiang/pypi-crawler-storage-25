-- GeneFlow Agent — PostgreSQL schema
--
-- Requires the pgvector extension. Embedding dimension defaults to 3
-- (matching HashEmbeddingProvider.dim=3). If you switch to OpenAI
-- embeddings (e.g. text-embedding-3-small @ 1536 dims), you must
-- recreate the embedding columns with vector(1536) and re-embed.

CREATE EXTENSION IF NOT EXISTS vector;

-- ============================================================
-- Association memory: episodes + entities + many-to-many link
-- ============================================================

CREATE TABLE IF NOT EXISTS episodes (
    id          BIGSERIAL PRIMARY KEY,
    content     TEXT NOT NULL,
    embedding   vector(3),
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_episodes_created_at
    ON episodes (created_at DESC);

-- Approximate nearest-neighbour search index (L2 distance).
-- For small dim (3) ivfflat is overkill but harmless; for higher
-- dims tune `lists` to ~ sqrt(rows).
CREATE INDEX IF NOT EXISTS idx_episodes_embedding
    ON episodes USING ivfflat (embedding vector_l2_ops)
    WITH (lists = 100);

CREATE TABLE IF NOT EXISTS entities (
    id    BIGSERIAL PRIMARY KEY,
    name  TEXT NOT NULL UNIQUE
);

CREATE INDEX IF NOT EXISTS idx_entities_name_lower
    ON entities (LOWER(name));

CREATE TABLE IF NOT EXISTS episode_entities (
    episode_id BIGINT NOT NULL REFERENCES episodes(id) ON DELETE CASCADE,
    entity_id  BIGINT NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
    PRIMARY KEY (episode_id, entity_id)
);

CREATE INDEX IF NOT EXISTS idx_episode_entities_entity
    ON episode_entities (entity_id);

-- ============================================================
-- Strategy genes: keyword + embedding indexed
-- ============================================================

CREATE TABLE IF NOT EXISTS genes (
    id              BIGSERIAL PRIMARY KEY,
    keywords        TEXT[] NOT NULL DEFAULT '{}',
    summary         TEXT NOT NULL DEFAULT '',
    strategy        TEXT NOT NULL DEFAULT '',
    avoid_signals   TEXT NOT NULL DEFAULT '',
    content_hash    TEXT,
    embedding       vector(3),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- GIN index for the keyword overlap operator (&&)
CREATE INDEX IF NOT EXISTS idx_genes_keywords
    ON genes USING GIN (keywords);

CREATE INDEX IF NOT EXISTS idx_genes_embedding
    ON genes USING ivfflat (embedding vector_l2_ops)
    WITH (lists = 100);

CREATE UNIQUE INDEX IF NOT EXISTS uq_genes_content_hash
    ON genes (content_hash);

-- ============================================================
-- Evolution event log (consumed by Agent.log_event)
-- Columns are intentionally optional — DatabaseManager.insert_row
-- introspects schema and only inserts known columns.
-- ============================================================

CREATE TABLE IF NOT EXISTS evolution_events (
    id              BIGSERIAL PRIMARY KEY,
    trace_id        TEXT,
    agent_name      TEXT,
    query           TEXT,
    execution_path  TEXT,
    result          TEXT,
    is_success      BOOLEAN,
    feedback        TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_evolution_events_created
    ON evolution_events (created_at DESC);

-- ============================================================
-- Lightweight "migration": add missing columns on existing DBs
-- ============================================================

ALTER TABLE genes ADD COLUMN IF NOT EXISTS content_hash TEXT;
CREATE UNIQUE INDEX IF NOT EXISTS uq_genes_content_hash ON genes (content_hash);

ALTER TABLE evolution_events ADD COLUMN IF NOT EXISTS trace_id TEXT;
ALTER TABLE evolution_events ADD COLUMN IF NOT EXISTS agent_name TEXT;
