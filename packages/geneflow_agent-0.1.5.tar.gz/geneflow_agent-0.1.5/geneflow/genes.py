import json
import logging
import re
from hashlib import sha256
from typing import Any, Dict, List, Optional, Sequence, Tuple

from .db import DatabaseManager
from .embedding import EmbeddingProvider

logger = logging.getLogger(__name__)


class GeneManager:
    def __init__(self, db: DatabaseManager, llm_client, *, model: Optional[str] = None, embedding_provider: Optional[EmbeddingProvider] = None):
        self.db = db
        self.llm = llm_client
        self.model = model or "gpt-3.5-turbo"
        self.embedding_provider = embedding_provider

    def match_genes(self, query, embedding=None, limit=2):
        """匹配最相关的策略基因"""
        cols = self.db.get_table_columns("genes")
        results: List[Tuple[str, str, str]] = []
        seen = set()

        if "keywords" in cols:
            tokens = list(
                {
                    t
                    for t in re.findall(r"[A-Za-z0-9_]+|[\u4e00-\u9fff]{2,}", query)
                    if len(t) >= 2
                }
            )
            if tokens:
                try:
                    rows = self.db.execute_query(
                        "SELECT strategy, avoid_signals, summary FROM genes WHERE keywords && %s::text[] LIMIT %s;",
                        (tokens, limit),
                        fetch=True,
                    )
                    for row in rows:
                        if row not in seen:
                            seen.add(row)
                            results.append(row)
                except Exception as exc:
                    logger.warning("Keyword gene match failed: %s", exc)

        if "embedding" in cols:
            try:
                emb = embedding if embedding is not None else self._fallback_embedding()
                rows = self.db.execute_query(
                    "SELECT strategy, avoid_signals, summary FROM genes ORDER BY embedding <-> %s LIMIT %s;",
                    (emb, limit),
                    fetch=True,
                )
                for row in rows:
                    if row not in seen:
                        seen.add(row)
                        results.append(row)
            except Exception as exc:
                logger.warning("Embedding gene match failed: %s", exc)

        return results[:limit]

    def evolve_gene(self, event_data):
        """根据执行事件进化基因 (GEP 协议)"""
        gene_json: Dict[str, Any] = {}
        try:
            prompt = f"""分析以下执行事件并蒸馏成一个 '策略基因 (Gene)'。
请以 JSON 格式输出：{{"keywords": [], "strategy": "", "avoid": "", "summary": ""}}
事件详情: {json.dumps(event_data, ensure_ascii=False)}
"""
            response = self.llm.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                response_format={"type": "json_object"},
            )
            content = response.choices[0].message.content
            gene_json = json.loads(content) if content else {}
        except Exception as exc:
            logger.warning("LLM gene evolution failed (%s), using fallback.", exc)
            query = str(event_data.get("query") or "")
            feedback = str(event_data.get("feedback") or "")
            tokens = list(
                {
                    t
                    for t in re.findall(r"[A-Za-z0-9_]+|[\u4e00-\u9fff]{2,}", query)
                    if len(t) >= 2
                }
            )
            gene_json = {
                "keywords": tokens[:12],
                "summary": "fallback gene",
                "strategy": feedback or "FORCE_FINAL: ok",
                "avoid": "",
            }

        embedding = self._fallback_embedding()
        if self.embedding_provider is not None:
            try:
                embedding = self.embedding_provider.embed(json.dumps(gene_json, ensure_ascii=False))
            except Exception as exc:
                logger.warning("Failed to compute gene embedding, using fallback: %s", exc)

        keywords = gene_json.get("keywords") or []
        if not isinstance(keywords, list):
            keywords = []
        keywords = [str(k) for k in keywords if str(k)]
        if len(keywords) > 32:
            keywords = keywords[:32]

        summary = str(gene_json.get("summary") or "")
        strategy = str(gene_json.get("strategy") or "")
        avoid = str(gene_json.get("avoid") or "")

        content_hash = sha256(
            json.dumps(
                {
                    "keywords": sorted(set(keywords)),
                    "summary": summary,
                    "strategy": strategy,
                    "avoid": avoid,
                },
                ensure_ascii=False,
                sort_keys=True,
            ).encode("utf-8")
        ).hexdigest()

        try:
            cols = self.db.get_table_columns("genes")
            if "content_hash" in cols:
                try:
                    self.db.insert_row(
                        "genes",
                        {
                            "keywords": keywords,
                            "summary": summary,
                            "strategy": strategy,
                            "avoid_signals": avoid,
                            "embedding": embedding,
                            "content_hash": content_hash,
                        },
                    )
                except Exception as exc:
                    msg = str(exc).lower()
                    if "duplicate" in msg or "unique" in msg:
                        logger.info("Gene already exists (content_hash duplicate), skipping insert.")
                    else:
                        raise
            else:
                existing = self.db.execute_query(
                    "SELECT id FROM genes WHERE summary=%s AND strategy=%s AND avoid_signals=%s LIMIT 1;",
                    (summary, strategy, avoid),
                    fetch=True,
                )
                if existing:
                    logger.info("Gene already exists (same content), skipping insert.")
                else:
                    self.db.execute_query(
                        "INSERT INTO genes (keywords, summary, strategy, avoid_signals, embedding) VALUES (%s, %s, %s, %s, %s);",
                        (
                            keywords,
                            summary,
                            strategy,
                            avoid,
                            embedding,
                        ),
                    )
        except Exception as exc:
            logger.error("Failed to persist evolved gene: %s", exc)
            raise

        return gene_json

    @staticmethod
    def _fallback_embedding() -> List[float]:
        """Return a zero vector as safe fallback."""
        return [0.0, 0.0, 0.0]
