import json
import logging
import threading
from dataclasses import dataclass
from typing import Any, Dict, Optional, Protocol, Sequence, Tuple

logger = logging.getLogger(__name__)


class Evaluator(Protocol):
    def evaluate(
        self,
        *,
        task: str,
        expected_output: Optional[str],
        result: str,
        transcript: Optional[Sequence[Dict[str, Any]]] = None,
    ) -> Tuple[bool, str]: ...


@dataclass
class AlwaysPassEvaluator:
    def evaluate(self, *, task: str, expected_output: Optional[str], result: str, transcript=None) -> Tuple[bool, str]:
        return True, ""


@dataclass
class ContainsAllEvaluator:
    required_substrings: Sequence[str]

    def evaluate(self, *, task: str, expected_output: Optional[str], result: str, transcript=None) -> Tuple[bool, str]:
        missing = [s for s in self.required_substrings if s.lower() not in (result or "").lower()]
        if missing:
            safe_required = "; ".join(self.required_substrings)
            return False, f"Missing required substrings: {missing}. FORCE_FINAL: {safe_required}"
        return True, ""


@dataclass
class FirstFailThenPassEvaluator:
    feedback_on_fail: str

    def __post_init__(self):
        self._local = threading.local()

    def evaluate(self, *, task: str, expected_output: Optional[str], result: str, transcript=None) -> Tuple[bool, str]:
        if not getattr(self._local, "has_failed", False):
            self._local.has_failed = True
            return False, self.feedback_on_fail
        return True, ""


@dataclass
class LlmJsonEvaluator:
    llm_client: Any
    model: str = "gpt-3.5-turbo"

    def evaluate(self, *, task: str, expected_output: Optional[str], result: str, transcript=None) -> Tuple[bool, str]:
        payload = {
            "task": task,
            "expected_output": expected_output or "",
            "result": result,
            "output_format": {"is_success": "boolean", "feedback": "string"},
        }
        res = self.llm_client.chat.completions.create(
            model=self.model,
            messages=[{"role": "user", "content": json.dumps(payload, ensure_ascii=False)}],
            response_format={"type": "json_object"},
        )
        data = json.loads(res.choices[0].message.content)
        return bool(data.get("is_success")), str(data.get("feedback") or "")
