import logging
from typing import List, Optional, Sequence, Tuple

from .db import DatabaseManager

logger = logging.getLogger(__name__)


class AssociationMemory:
    def __init__(self, db: DatabaseManager):
        self.db = db

    def add_episode(self, content, entities, embedding=None):
        """存储情景并链接实体"""
        emb = embedding if embedding is not None else self._fallback_embedding()
        try:
            ep_id = self.db.execute_scalar(
                "INSERT INTO episodes (content, embedding) VALUES (%s, %s) RETURNING id;",
                (content, emb),
            )
        except Exception as exc:
            logger.error("Failed to insert episode: %s", exc)
            raise

        for ent_name in entities:
            try:
                ent_id = self.db.execute_scalar(
                    "INSERT INTO entities (name) VALUES (%s) ON CONFLICT (name) DO UPDATE SET name=EXCLUDED.name RETURNING id;",
                    (ent_name,),
                )
                self.db.execute_query(
                    "INSERT INTO episode_entities (episode_id, entity_id) VALUES (%s, %s) ON CONFLICT DO NOTHING;",
                    (ep_id, ent_id),
                )
            except Exception as exc:
                logger.warning("Failed to link entity %r: %s", ent_name, exc)

        return ep_id

    def associate(self, query, embedding=None, limit=2, entity_limit=6):
        """联想检索：根据实体和向量寻找相关上下文"""
        episode_rows: List[Tuple[int, str]] = []
        seen_episode_ids = set()

        emb = embedding if embedding is not None else self._fallback_embedding()

        try:
            rows = self.db.execute_query(
                "SELECT id, content FROM episodes ORDER BY embedding <-> %s LIMIT %s;",
                (emb, limit),
                fetch=True,
            )
            for ep_id, content in rows:
                if ep_id not in seen_episode_ids:
                    seen_episode_ids.add(ep_id)
                    episode_rows.append((ep_id, content))
        except Exception as exc:
            logger.warning("Episode vector search failed: %s", exc)

        try:
            entity_matches = self.db.execute_query(
                "SELECT id, name FROM entities WHERE POSITION(LOWER(name) IN LOWER(%s)) > 0 LIMIT %s;",
                (query, entity_limit),
                fetch=True,
            )
            for entity_id, _ in entity_matches:
                try:
                    ep_rows = self.db.execute_query(
                        """
                        SELECT e.id, e.content
                        FROM episodes e
                        JOIN episode_entities ee ON e.id = ee.episode_id
                        WHERE ee.entity_id = %s
                        ORDER BY e.created_at DESC
                        LIMIT %s
                        """,
                        (entity_id, limit),
                        fetch=True,
                    )
                    for ep_id, content in ep_rows:
                        if ep_id not in seen_episode_ids:
                            seen_episode_ids.add(ep_id)
                            episode_rows.append((ep_id, content))
                except Exception as exc:
                    logger.warning("Entity-linked episode query failed: %s", exc)
        except Exception as exc:
            logger.warning("Entity match failed: %s", exc)

        related_context: List[str] = []
        for ep_id, content in episode_rows[: max(limit, 1) * 2]:
            related_context.append(f"Episode: {content}")
            try:
                linked = self.db.execute_query(
                    """
                    SELECT e.content
                    FROM episodes e
                    JOIN episode_entities ee ON e.id = ee.episode_id
                    WHERE ee.entity_id IN (
                        SELECT entity_id FROM episode_entities WHERE episode_id = %s
                    )
                    AND e.id != %s
                    ORDER BY e.created_at DESC
                    LIMIT 1;
                    """,
                    (ep_id, ep_id),
                    fetch=True,
                )
                if linked:
                    related_context.append(f"Associated Context: {linked[0][0]}")
            except Exception as exc:
                logger.debug("Linked context query failed for episode %s: %s", ep_id, exc)

        return "\n".join(related_context)

    @staticmethod
    def _fallback_embedding() -> List[float]:
        """Return a zero vector as safe fallback."""
        return [0.0, 0.0, 0.0]
