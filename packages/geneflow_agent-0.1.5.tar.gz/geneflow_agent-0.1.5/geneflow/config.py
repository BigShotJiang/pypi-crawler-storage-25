import os
from dataclasses import dataclass
from typing import Any, Dict, Optional


@dataclass(frozen=True)
class GeneflowConfig:
    db_params: Dict[str, Any]
    model: str
    openai_api_key: str
    openai_base_url: Optional[str] = None

    @staticmethod
    def from_env(
        *,
        dbname_default: str = "vector_db",
        user_default: str = "root",
        password_default: str = "root",
        host_default: str = "localhost",
        port_default: int = 5432,
        model_default: str = "gpt-4o-mini",
    ) -> "GeneflowConfig":
        api_key = os.getenv("OPENAI_API_KEY") or ""
        if not api_key:
            raise ValueError("missing OPENAI_API_KEY")

        db_params: Dict[str, Any] = {
            "dbname": os.getenv("PGDATABASE", dbname_default),
            "user": os.getenv("PGUSER", user_default),
            "password": os.getenv("PGPASSWORD", password_default),
            "host": os.getenv("PGHOST", host_default),
            "port": int(os.getenv("PGPORT", str(port_default))),
        }

        return GeneflowConfig(
            db_params=db_params,
            model=os.getenv("GENEFLOW_MODEL", model_default),
            openai_api_key=api_key,
            openai_base_url=os.getenv("OPENAI_BASE_URL") or None,
        )

