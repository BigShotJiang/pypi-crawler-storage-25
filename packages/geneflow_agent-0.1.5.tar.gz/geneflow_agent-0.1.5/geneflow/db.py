import logging
import threading
from typing import Any, Dict, List, Optional, Set, Tuple

import psycopg2
from psycopg2 import sql as pgsql
from psycopg2.pool import ThreadedConnectionPool

logger = logging.getLogger(__name__)

_DEFAULT_MIN_CONN = 1
_DEFAULT_MAX_CONN = 10

# Global registry: one connection pool per (normalized) db_params.
# Prevents every Agent from spinning up its own pool when they all
# point at the same database.
_REGISTRY_LOCK = threading.Lock()
_REGISTRY: Dict[frozenset, "DatabaseManager"] = {}


def _freeze_params(params: Dict[str, Any]) -> frozenset:
    """Make db_params hashable for registry key."""
    return frozenset((k, v) for k, v in params.items() if not k.startswith("_"))


class DatabaseManager:
    """
    Thin wrapper over psycopg2 ThreadedConnectionPool.

    Use DatabaseManager.get_shared(db_params) to reuse a process-wide
    pool per connection target — this is what Agent does under the hood.
    Direct construction (DatabaseManager(db_params)) still works and
    creates an isolated pool (useful for tests).
    """

    def __init__(
        self,
        db_params: Dict[str, Any],
        *,
        minconn: int = _DEFAULT_MIN_CONN,
        maxconn: int = _DEFAULT_MAX_CONN,
    ):
        self.params = dict(db_params)
        self._columns_cache: Dict[Tuple[str, str], Set[str]] = {}
        self._lock = threading.Lock()
        self._pool: Optional[ThreadedConnectionPool] = None
        self._closed = False
        try:
            self._pool = ThreadedConnectionPool(minconn, maxconn, **db_params)
            logger.info(
                "DB pool created host=%s db=%s min=%s max=%s",
                db_params.get("host"), db_params.get("dbname"), minconn, maxconn,
            )
        except Exception as exc:
            logger.error("Failed to create connection pool: %s", exc)
            raise

    # ---------- registry ----------

    @classmethod
    def get_shared(
        cls,
        db_params: Dict[str, Any],
        *,
        minconn: int = _DEFAULT_MIN_CONN,
        maxconn: int = _DEFAULT_MAX_CONN,
    ) -> "DatabaseManager":
        key = _freeze_params(db_params)
        with _REGISTRY_LOCK:
            existing = _REGISTRY.get(key)
            if existing is not None and not existing._closed:
                return existing
            mgr = cls(db_params, minconn=minconn, maxconn=maxconn)
            _REGISTRY[key] = mgr
            return mgr

    @classmethod
    def close_all(cls) -> None:
        with _REGISTRY_LOCK:
            for mgr in list(_REGISTRY.values()):
                try:
                    mgr.close()
                except Exception as exc:
                    logger.warning("close_all: failed to close a pool: %s", exc)
            _REGISTRY.clear()

    def close(self) -> None:
        with self._lock:
            if self._pool is not None and not self._closed:
                try:
                    self._pool.closeall()
                finally:
                    self._closed = True
                    self._pool = None

    # ---------- connection borrow/return ----------

    def _get_conn(self):
        if self._pool is None or self._closed:
            raise RuntimeError("Database pool is not initialized or has been closed")
        return self._pool.getconn()

    def _put_conn(self, conn):
        if self._pool is not None and not self._closed and conn is not None:
            try:
                self._pool.putconn(conn)
            except Exception as exc:
                logger.warning("putconn failed: %s", exc)

    # ---------- query helpers ----------

    def execute_query(self, query, params=None, fetch: bool = False):
        conn = self._get_conn()
        try:
            with conn.cursor() as cur:
                cur.execute(query, params)
                if fetch:
                    result = cur.fetchall()
                    conn.commit()
                    return result
                conn.commit()
        except Exception as exc:
            try:
                conn.rollback()
            except Exception:
                pass
            logger.error("execute_query failed: %s | query=%s", exc, query)
            raise
        finally:
            self._put_conn(conn)

    def execute_scalar(self, query, params=None):
        conn = self._get_conn()
        try:
            with conn.cursor() as cur:
                cur.execute(query, params)
                row = cur.fetchone()
                conn.commit()
                return row[0] if row else None
        except Exception as exc:
            try:
                conn.rollback()
            except Exception:
                pass
            logger.error("execute_scalar failed: %s | query=%s", exc, query)
            raise
        finally:
            self._put_conn(conn)

    # ---------- schema introspection ----------

    def get_table_columns(self, table_name: str, schema: str = "public") -> Set[str]:
        cache_key = (schema, table_name)
        cached = self._columns_cache.get(cache_key)
        if cached is not None:
            return cached

        conn = self._get_conn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT column_name
                    FROM information_schema.columns
                    WHERE table_schema = %s AND table_name = %s
                    """,
                    (schema, table_name),
                )
                cols = {row[0] for row in cur.fetchall()}
                self._columns_cache[cache_key] = cols
                return cols
        except Exception as exc:
            logger.error("get_table_columns failed: %s", exc)
            raise
        finally:
            self._put_conn(conn)

    # ---------- safe insert ----------

    def insert_row(self, table_name: str, data: Dict[str, Any], schema: str = "public") -> None:
        if not table_name or not table_name.isidentifier():
            raise ValueError(f"Invalid table name: {table_name!r}")
        if not schema or not schema.isidentifier():
            raise ValueError(f"Invalid schema name: {schema!r}")

        cols = self.get_table_columns(table_name, schema=schema)
        keys = [k for k in data.keys() if k in cols]
        if not keys:
            raise ValueError(f"No valid columns found for insert into {schema}.{table_name}")

        values: List[Any] = [data[k] for k in keys]

        # Use psycopg2.sql composition for safe identifier quoting
        stmt = pgsql.SQL("INSERT INTO {schema}.{table} ({fields}) VALUES ({values})").format(
            schema=pgsql.Identifier(schema),
            table=pgsql.Identifier(table_name),
            fields=pgsql.SQL(", ").join(pgsql.Identifier(k) for k in keys),
            values=pgsql.SQL(", ").join(pgsql.Placeholder() for _ in keys),
        )
        self.execute_query(stmt, tuple(values), fetch=False)
