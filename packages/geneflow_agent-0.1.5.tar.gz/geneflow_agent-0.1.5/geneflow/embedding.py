import hashlib
from dataclasses import dataclass
from typing import Any, List, Protocol, Sequence


class EmbeddingProvider(Protocol):
    def embed(self, text: str) -> List[float]: ...


@dataclass
class HashEmbeddingProvider:
    dim: int = 3

    def embed(self, text: str) -> List[float]:
        if self.dim <= 0:
            raise ValueError("dim must be positive")
        h = hashlib.sha256(text.encode("utf-8")).digest()
        vals: List[float] = []
        for i in range(self.dim):
            b = h[i % len(h)]
            vals.append((b / 255.0) * 2.0 - 1.0)
        return vals


@dataclass
class OpenAIEmbeddingProvider:
    client: Any
    model: str = "text-embedding-3-small"

    def embed(self, text: str) -> List[float]:
        res = self.client.embeddings.create(model=self.model, input=text)
        return list(res.data[0].embedding)

