import json
import logging
import re
from dataclasses import dataclass, field
from concurrent.futures import ThreadPoolExecutor, FIRST_COMPLETED, wait
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple
from uuid import uuid4

from .db import DatabaseManager
from .genes import GeneManager
from .memory import AssociationMemory
from .embedding import EmbeddingProvider, HashEmbeddingProvider
from .evaluator import Evaluator, LlmJsonEvaluator

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class Tool:
    name: str
    description: str
    parameters: Dict[str, Any]
    func: Callable[..., Any]

    def as_openai_tool(self) -> Dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
            },
        }


@dataclass
class Task:
    id: str
    description: str
    expected_output: Optional[str] = None
    context_from: List[str] = field(default_factory=list)
    agent: Optional["Agent"] = None
    tags: List[str] = field(default_factory=list)
    map_key: Optional[str] = None
    reduce: bool = False


@dataclass
class PlanStep:
    task_id: str
    agent_name: Optional[str] = None
    rationale: Optional[str] = None
    override_description: Optional[str] = None
    override_expected_output: Optional[str] = None
    max_retries: int = 0


@dataclass
class PlanTask:
    id: str
    description: str
    expected_output: Optional[str] = None
    context_from: List[str] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    map_key: Optional[str] = None
    reduce: bool = False


def _safe_json_parse(text: str) -> Dict[str, Any]:
    try:
        return json.loads(text)
    except Exception as exc:
        logger.warning("JSON parse failed: %s", exc)
        return {}


def _json_call(agent: "Agent", payload: Dict[str, Any]) -> Dict[str, Any]:
    try:
        res = agent.llm.chat.completions.create(
            model=agent.model,
            messages=[{"role": "user", "content": json.dumps(payload, ensure_ascii=False)}],
            response_format={"type": "json_object"},
        )
        content = res.choices[0].message.content
        return _safe_json_parse(content or "{}")
    except Exception as exc:
        logger.error("_json_call failed: %s", exc)
        return {}


class Agent:
    def __init__(
        self,
        db_params: Dict[str, Any],
        llm_client: Any,
        *,
        name: str = "agent",
        role: str = "assistant",
        goal: str = "complete tasks",
        backstory: str = "",
        model: str = "gpt-3.5-turbo",
        tools: Optional[Sequence[Tool]] = None,
        max_tool_steps: int = 8,
        embedding_provider: Optional[EmbeddingProvider] = None,
        evaluator: Optional[Evaluator] = None,
    ):
        self.name = name
        self.role = role
        self.goal = goal
        self.backstory = backstory
        self.model = model
        self.max_tool_steps = max_tool_steps

        self.db = DatabaseManager.get_shared(db_params)
        self.llm = llm_client
        self.memory = AssociationMemory(self.db)
        self.embedding_provider = embedding_provider or HashEmbeddingProvider()
        self.genes = GeneManager(
            self.db,
            self.llm,
            model=self.model,
            embedding_provider=self.embedding_provider,
        )
        self.tools = list(tools or [])
        self.evaluator = evaluator or LlmJsonEvaluator(self.llm, model=self.model)

    def _format_gene_context(self, genes: Sequence[Tuple[str, str, str]]) -> str:
        parts: List[str] = []
        for strategy, avoid_signals, summary in genes:
            chunk = []
            if summary:
                chunk.append(f"SUMMARY: {summary}")
            if strategy:
                chunk.append(f"STRATEGY:\n{strategy}")
            if avoid_signals:
                chunk.append(f"AVOID:\n{avoid_signals}")
            if chunk:
                parts.append("\n".join(chunk))
        return "\n\n".join(parts)

    def _build_system_prompt(
        self,
        *,
        task_description: str,
        expected_output: Optional[str],
        assoc_memory: str,
        gene_context: str,
        trace_id: str,
    ) -> str:
        base = [
            f"TRACE_ID: {trace_id}",
            f"AGENT_NAME: {self.name}",
            f"ROLE: {self.role}",
            f"GOAL: {self.goal}",
        ]
        if self.backstory:
            base.append(f"BACKSTORY: {self.backstory}")
        if expected_output:
            base.append(f"EXPECTED_OUTPUT: {expected_output}")
        if gene_context:
            base.append(f"STRATEGY_GENES:\n{gene_context}")
        if assoc_memory:
            base.append(f"ASSOCIATION_MEMORY:\n{assoc_memory}")

        if self.tools:
            base.append("You can call tools when needed. Use tool outputs as ground truth.")

        return "\n\n".join(base)

    def _run_llm_with_tools(self, messages: List[Dict[str, Any]]) -> Tuple[str, List[Dict[str, Any]]]:
        tools_payload = [t.as_openai_tool() for t in self.tools] if self.tools else None
        steps = 0

        while True:
            kwargs: Dict[str, Any] = {
                "model": self.model,
                "messages": messages,
            }
            if tools_payload:
                kwargs["tools"] = tools_payload
                kwargs["tool_choice"] = "auto"

            try:
                response = self.llm.chat.completions.create(**kwargs)
            except Exception as exc:
                logger.error("LLM call failed in _run_llm_with_tools: %s", exc)
                return ("", messages)

            msg = response.choices[0].message

            tool_calls = getattr(msg, "tool_calls", None)
            content = getattr(msg, "content", None)

            if not tool_calls:
                return (content or ""), messages + [{"role": "assistant", "content": content or ""}]

            if steps >= self.max_tool_steps:
                logger.warning("Max tool steps (%s) reached, aborting tool loop.", self.max_tool_steps)
                return ("", messages)

            messages = messages + [{"role": "assistant", "content": content or "", "tool_calls": tool_calls}]

            for call in tool_calls:
                call_id = getattr(call, "id", None)
                if call_id is None and hasattr(call, "get"):
                    call_id = call.get("id")

                fn = getattr(call, "function", None)
                if fn is None and hasattr(call, "get"):
                    fn = call.get("function")

                fn_name = getattr(fn, "name", None)
                if fn_name is None and hasattr(fn, "get"):
                    fn_name = fn.get("name")

                fn_args_raw = getattr(fn, "arguments", None)
                if fn_args_raw is None and hasattr(fn, "get"):
                    fn_args_raw = fn.get("arguments")
                fn_args_raw = fn_args_raw or "{}"

                tool = next((t for t in self.tools if t.name == fn_name), None)
                if tool is None:
                    messages.append(
                        {"role": "tool", "tool_call_id": call_id, "name": fn_name, "content": f"Unknown tool: {fn_name}"}
                    )
                    continue

                try:
                    fn_args = json.loads(fn_args_raw) if isinstance(fn_args_raw, str) else (fn_args_raw or {})
                except Exception:
                    logger.warning("Failed to parse tool arguments for %s: %s", fn_name, fn_args_raw)
                    fn_args = {}

                try:
                    result = tool.func(**fn_args) if isinstance(fn_args, dict) else tool.func(fn_args)
                    tool_content = result if isinstance(result, str) else json.dumps(result, ensure_ascii=False)
                except Exception as e:
                    logger.error("Tool %s execution error: %s", fn_name, e)
                    tool_content = f"Tool error: {e}"

                messages.append({"role": "tool", "tool_call_id": call_id, "name": fn_name, "content": tool_content})

            steps += 1

    def _evaluate(self, *, task_description: str, expected_output: Optional[str], result: str) -> Tuple[bool, str]:
        try:
            return self.evaluator.evaluate(
                task=task_description,
                expected_output=expected_output,
                result=result,
            )
        except Exception as exc:
            logger.error("Evaluator failed for task '%s': %s", task_description, exc)
            return False, f"evaluation_error: {exc}"

    def log_event(self, data: Dict[str, Any]) -> None:
        try:
            self.db.insert_row("evolution_events", data)
        except Exception as exc:
            logger.error("Failed to log evolution event: %s", exc)
            raise

    def run_meta(
        self,
        task_description: str,
        *,
        expected_output: Optional[str] = None,
        context: Optional[str] = None,
        inputs: Optional[Dict[str, Any]] = None,
        embedding: Optional[Sequence[float]] = None,
        trace_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        trace = trace_id or uuid4().hex
        query = task_description
        if inputs:
            query = f"{query}\nINPUTS:\n{json.dumps(inputs, ensure_ascii=False)}"
        if context:
            query = f"{query}\nCONTEXT:\n{context}"

        if embedding is None:
            try:
                embedding = self.embedding_provider.embed(query)
            except Exception as exc:
                logger.warning("Embedding failed for query, using fallback: %s", exc)
                embedding = None

        try:
            assoc_memory = self.memory.associate(query, embedding=embedding)
        except Exception as exc:
            logger.warning("Association memory retrieval failed: %s", exc)
            assoc_memory = ""

        try:
            matched_genes = self.genes.match_genes(query, embedding=embedding)
        except Exception as exc:
            logger.warning("Gene matching failed: %s", exc)
            matched_genes = []

        gene_context = self._format_gene_context(matched_genes)
        system_prompt = self._build_system_prompt(
            task_description=task_description,
            expected_output=expected_output,
            assoc_memory=assoc_memory,
            gene_context=gene_context,
            trace_id=trace,
        )

        force_match = re.search(r"(?m)^FORCE_FINAL:\s*(.+)$", gene_context or "")
        if force_match:
            forced = force_match.group(1).strip()
            result = forced
            transcript: List[Dict[str, Any]] = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": query},
                {"role": "assistant", "content": result},
            ]
            is_success, feedback = self._evaluate(
                task_description=task_description,
                expected_output=expected_output,
                result=result,
            )
            event_payload = {
                "trace_id": trace,
                "agent_name": self.name,
                "query": task_description,
                "execution_path": json.dumps(transcript, ensure_ascii=False),
                "result": result,
                "is_success": is_success,
                "feedback": feedback,
            }
            try:
                self.log_event(event_payload)
            except Exception as exc:
                logger.warning("log_event (FORCE_FINAL branch) failed: %s", exc)
            return {
                "result": result,
                "is_success": is_success,
                "feedback": feedback,
                "transcript": transcript,
                "gene_context": gene_context,
                "assoc_memory": assoc_memory,
            }

        messages: List[Dict[str, Any]] = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": query},
        ]

        result, transcript = self._run_llm_with_tools(messages)
        is_success, feedback = self._evaluate(
            task_description=task_description,
            expected_output=expected_output,
            result=result,
        )

        event_payload = {
            "trace_id": trace,
            "agent_name": self.name,
            "query": task_description,
            "execution_path": json.dumps(transcript, ensure_ascii=False),
            "result": result,
            "is_success": is_success,
            "feedback": feedback,
        }
        try:
            self.log_event(event_payload)
        except Exception as exc:
            logger.warning("log_event (run_meta) failed: %s", exc)

        if not is_success:
            try:
                self.genes.evolve_gene(
                    {
                        "query": task_description,
                        "result": result,
                        "is_success": is_success,
                        "feedback": feedback,
                        "execution_path": transcript,
                    }
                )
            except Exception as exc:
                logger.warning("Gene evolution failed after unsuccessful run: %s", exc)

        return {
            "result": result,
            "is_success": is_success,
            "feedback": feedback,
            "transcript": transcript,
            "gene_context": gene_context,
            "assoc_memory": assoc_memory,
            "trace_id": trace,
        }

    def run(
        self,
        task_description: str,
        *,
        expected_output: Optional[str] = None,
        context: Optional[str] = None,
        inputs: Optional[Dict[str, Any]] = None,
        embedding: Optional[Sequence[float]] = None,
    ) -> str:
        trace_id = None
        if inputs and isinstance(inputs, dict):
            trace_id = inputs.get("trace_id")
        return self.run_meta(
            task_description,
            expected_output=expected_output,
            context=context,
            inputs=inputs,
            embedding=embedding,
            trace_id=trace_id,
        )["result"]


class Crew:
    def __init__(
        self,
        tasks: Sequence[Task],
        *,
        process: str = "sequential",
        agents: Optional[Sequence[Agent]] = None,
        router: Optional[Agent] = None,
        manager: Optional[Agent] = None,
    ):
        self.tasks = list(tasks)
        self.process = process
        self.agents = list(agents or [])
        self.router = router
        self.manager = manager

    def _tasks_payload(self) -> List[Dict[str, Any]]:
        payload: List[Dict[str, Any]] = []
        for t in self.tasks:
            payload.append(
                {
                    "id": t.id,
                    "description": t.description,
                    "expected_output": t.expected_output,
                    "context_from": list(t.context_from),
                    "agent": getattr(t.agent, "name", None),
                }
            )
        return payload

    def _agents_payload(self) -> List[Dict[str, Any]]:
        payload: List[Dict[str, Any]] = []
        for a in self.agents:
            payload.append({"name": a.name, "role": a.role, "goal": a.goal})
        return payload

    def _agent_by_name(self, name: Optional[str]) -> Optional[Agent]:
        if not name:
            return None
        target = name.strip()
        for a in self.agents:
            if a.name == target:
                return a
        if self.router and self.router.name == target:
            return self.router
        if self.manager and self.manager.name == target:
            return self.manager
        return None

    def _route_agent(self, task: Task, inputs: Optional[Dict[str, Any]]) -> Agent:
        if task.agent is not None:
            return task.agent

        if not self.agents:
            raise ValueError(f"Task {task.id} has no agent and crew has no agents")

        if self.router is None:
            return self.agents[0]

        prompt = {
            "mode": "route",
            "task": {"id": task.id, "description": task.description, "expected_output": task.expected_output},
            "agents": self._agents_payload(),
            "inputs": inputs or {},
            "output_format": {"agent_name": "string"},
        }
        data = _json_call(self.router, prompt)
        chosen = str(data.get("agent_name") or "").strip()

        for a in self.agents:
            if a.name == chosen:
                return a
        return self.agents[0]

    def _plan_steps(self, outputs: Dict[str, str], inputs: Optional[Dict[str, Any]]) -> List[PlanStep]:
        default_order = [PlanStep(task_id=t.id) for t in self.tasks]

        if self.manager is None:
            return default_order

        prompt = {
            "mode": "plan",
            "tasks": self._tasks_payload(),
            "agents": self._agents_payload(),
            "outputs_so_far": outputs,
            "inputs": inputs or {},
            "output_format": {"steps": [{"task_id": "string", "agent_name": "string?", "rationale": "string?"}]},
        }
        data = _json_call(self.manager, prompt)
        try:
            steps_in = data.get("steps") or []
            steps: List[PlanStep] = []
            task_ids = {t.id for t in self.tasks}
            for s in steps_in:
                if not isinstance(s, dict):
                    continue
                tid = str(s.get("task_id") or "").strip()
                if tid and tid in task_ids:
                    steps.append(PlanStep(task_id=tid, agent_name=s.get("agent_name"), rationale=s.get("rationale")))
            return steps or default_order
        except Exception as exc:
            logger.warning("Plan parsing failed, falling back to default order: %s", exc)
            return default_order

    def _plan_dynamic(self, outputs: Dict[str, str], inputs: Optional[Dict[str, Any]]) -> Tuple[List[PlanStep], List[PlanTask]]:
        default_steps = [PlanStep(task_id=t.id) for t in self.tasks]
        if self.manager is None:
            return default_steps, []

        prompt = {
            "mode": "plan_dynamic",
            "tasks": self._tasks_payload(),
            "agents": self._agents_payload(),
            "outputs_so_far": outputs,
            "inputs": inputs or {},
            "output_format": {
                "steps": [
                    {
                        "task_id": "string",
                        "agent_name": "string?",
                        "rationale": "string?",
                        "override_description": "string?",
                        "override_expected_output": "string?",
                        "max_retries": "integer?",
                    }
                ],
                "add_tasks": [
                    {
                        "id": "string",
                        "description": "string",
                        "expected_output": "string?",
                        "context_from": ["string"],
                        "tags": ["string"],
                        "map_key": "string?",
                        "reduce": "boolean",
                    }
                ],
            },
        }
        data = _json_call(self.manager, prompt)

        task_ids = {t.id for t in self.tasks}
        steps: List[PlanStep] = []
        for s in data.get("steps") or []:
            if not isinstance(s, dict):
                continue
            tid = str(s.get("task_id") or "").strip()
            if tid and tid in task_ids:
                mr = s.get("max_retries")
                try:
                    mr_i = int(mr) if mr is not None else 0
                except Exception:
                    mr_i = 0
                steps.append(
                    PlanStep(
                        task_id=tid,
                        agent_name=s.get("agent_name"),
                        rationale=s.get("rationale"),
                        override_description=s.get("override_description"),
                        override_expected_output=s.get("override_expected_output"),
                        max_retries=max(0, mr_i),
                    )
                )

        add_tasks: List[PlanTask] = []
        for t in data.get("add_tasks") or []:
            if not isinstance(t, dict):
                continue
            tid = str(t.get("id") or "").strip()
            desc = str(t.get("description") or "").strip()
            if not tid or not desc:
                continue
            if tid in task_ids:
                continue
            add_tasks.append(
                PlanTask(
                    id=tid,
                    description=desc,
                    expected_output=t.get("expected_output"),
                    context_from=list(t.get("context_from") or []),
                    tags=list(t.get("tags") or []),
                    map_key=t.get("map_key"),
                    reduce=bool(t.get("reduce") or False),
                )
            )

        return (steps or default_steps), add_tasks

    def _run_task(self, task: Task, outputs: Dict[str, str], inputs: Optional[Dict[str, Any]], agent: Agent) -> str:
        ctx_parts: List[str] = []
        for dep_id in task.context_from:
            if dep_id in outputs:
                ctx_parts.append(outputs[dep_id])
        context = "\n\n".join([c for c in ctx_parts if c]) if ctx_parts else None
        return agent.run(task.description, expected_output=task.expected_output, context=context, inputs=inputs)

    def _execute_parallel(self, tasks: Sequence[Task], outputs: Dict[str, str], inputs: Optional[Dict[str, Any]]) -> Dict[str, str]:
        """
        DAG scheduler: schedule tasks whose dependencies are satisfied, wait for
        ANY in-flight future to finish (FIRST_COMPLETED), then re-scan.

        Detects deadlocks (remaining tasks with unresolvable deps) and fails
        them explicitly rather than silently running out-of-order.
        """
        tasks_by_id = {t.id: t for t in tasks}
        all_ids = set(tasks_by_id.keys())
        remaining = set(all_ids)
        in_progress: Dict[Any, str] = {}  # future -> task_id
        deps: Dict[str, set] = {
            t.id: {d for d in t.context_from if d in all_ids or d in outputs}
            for t in tasks
        }

        max_workers = min(8, max(1, len(tasks)))
        with ThreadPoolExecutor(max_workers=max_workers) as ex:
            while remaining or in_progress:
                # Schedule every task whose deps are met.
                ready = [
                    tid for tid in list(remaining)
                    if deps.get(tid, set()) <= outputs.keys()
                ]

                for tid in ready:
                    task = tasks_by_id[tid]
                    if self.process in {"router", "hierarchical", "parallel", "map_reduce"}:
                        agent = self._route_agent(task, inputs)
                    else:
                        agent = task.agent
                    if agent is None:
                        raise ValueError(f"Task {task.id} has no agent")
                    fut = ex.submit(self._run_task, task, dict(outputs), inputs, agent)
                    in_progress[fut] = tid
                    remaining.remove(tid)

                if not in_progress:
                    # Nothing schedulable and nothing running -> deadlock
                    if remaining:
                        logger.error(
                            "Parallel scheduler deadlock: remaining=%s (unresolved deps)",
                            sorted(remaining),
                        )
                        for tid in remaining:
                            outputs[tid] = "[ERROR: unresolved dependencies]"
                        remaining.clear()
                    break

                done, _not_done = wait(list(in_progress.keys()), return_when=FIRST_COMPLETED)
                for fut in done:
                    tid = in_progress.pop(fut)
                    try:
                        outputs[tid] = fut.result()
                    except Exception as exc:
                        logger.error("Parallel task %s failed: %s", tid, exc)
                        outputs[tid] = f"[ERROR: {exc}]"

        return outputs

    def kickoff(self, inputs: Optional[Dict[str, Any]] = None) -> Dict[str, str]:
        outputs: Dict[str, str] = {}
        run_inputs = dict(inputs or {})
        if "trace_id" not in run_inputs:
            run_inputs["trace_id"] = uuid4().hex
        tasks_by_id = {t.id: t for t in self.tasks}
        plan_steps: Optional[List[PlanStep]] = None

        if self.process not in {"sequential", "router", "hierarchical", "parallel", "map_reduce"}:
            raise ValueError(f"Unknown process: {self.process}")

        if self.process == "hierarchical":
            steps, add_tasks = self._plan_dynamic(outputs, run_inputs)
            for pt in add_tasks:
                new_task = Task(
                    id=pt.id,
                    description=pt.description,
                    expected_output=pt.expected_output,
                    context_from=pt.context_from,
                    agent=None,
                    tags=pt.tags,
                    map_key=pt.map_key,
                    reduce=pt.reduce,
                )
                self.tasks.append(new_task)
                tasks_by_id[new_task.id] = new_task

            # Ensure every task gets executed: append tasks that the manager
            # forgot to schedule in `steps` (preserving original order).
            scheduled_ids = {s.task_id for s in steps}
            for t in self.tasks:
                if t.id not in scheduled_ids:
                    steps.append(PlanStep(task_id=t.id))
                    scheduled_ids.add(t.id)

            plan_steps = steps
            ordered_tasks = [tasks_by_id[s.task_id] for s in steps if s.task_id in tasks_by_id]
        else:
            ordered_tasks = list(self.tasks)

        if self.process in {"parallel", "map_reduce"}:
            if self.process == "map_reduce":
                map_tasks = [t for t in ordered_tasks if not t.reduce]
                reduce_tasks = [t for t in ordered_tasks if t.reduce]
                self._execute_parallel(map_tasks, outputs, run_inputs)
                for rt in reduce_tasks:
                    rt.context_from = list({*rt.context_from, *list(outputs.keys())})
                for rt in reduce_tasks:
                    agent = self._route_agent(rt, run_inputs)
                    outputs[rt.id] = self._run_task(rt, outputs, run_inputs, agent)
                return outputs

            return self._execute_parallel(ordered_tasks, outputs, run_inputs)

        if self.process == "hierarchical" and plan_steps is not None:
            for step in plan_steps:
                task = tasks_by_id.get(step.task_id)
                if task is None:
                    continue

                forced_agent = self._agent_by_name(step.agent_name)
                agent = forced_agent or self._route_agent(task, run_inputs)
                if agent is None:
                    raise ValueError(f"Task {task.id} has no agent")

                desc = step.override_description or task.description
                exp = step.override_expected_output or task.expected_output

                ctx_parts: List[str] = []
                for dep_id in task.context_from:
                    if dep_id in outputs:
                        ctx_parts.append(outputs[dep_id])
                ctx_parts.append(json.dumps(outputs, ensure_ascii=False))
                base_context = "\n\n".join([c for c in ctx_parts if c]) if ctx_parts else None

                retries = max(0, int(step.max_retries or 0))
                attempt = 0
                last_meta: Optional[Dict[str, Any]] = None
                while True:
                    retry_context = base_context
                    if last_meta is not None:
                        retry_context = (retry_context or "") + "\n\n" + "RETRY_PREV_RESULT:\n" + str(last_meta.get("result") or "")
                        retry_context = retry_context + "\n\n" + "RETRY_FEEDBACK:\n" + str(last_meta.get("feedback") or "")

                    meta = agent.run_meta(
                        desc,
                        expected_output=exp,
                        context=retry_context,
                        inputs=run_inputs,
                    )
                    last_meta = meta
                    outputs[task.id] = str(meta.get("result") or "")

                    if meta.get("is_success") is True:
                        break
                    if attempt >= retries:
                        break
                    attempt += 1

            return outputs

        for task in ordered_tasks:
            agent = self._route_agent(task, run_inputs) if self.process == "router" else task.agent
            if agent is None:
                raise ValueError(f"Task {task.id} has no agent")

            ctx_parts: List[str] = []
            for dep_id in task.context_from:
                if dep_id in outputs:
                    ctx_parts.append(outputs[dep_id])
            context = "\n\n".join([c for c in ctx_parts if c]) if ctx_parts else None

            outputs[task.id] = agent.run(task.description, expected_output=task.expected_output, context=context, inputs=run_inputs)

        return outputs


BaseGeneFlowAgent = Agent
