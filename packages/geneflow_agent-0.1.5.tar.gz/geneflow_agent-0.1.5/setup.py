from pathlib import Path

from setuptools import find_packages, setup

ROOT = Path(__file__).parent
README = (ROOT / "README.md").read_text(encoding="utf-8")

setup(
    name="geneflow-agent",
    version="0.1.5",
    description="Agent/Crew framework with association memory, strategy genes, and test-time evolution.",
    long_description=README,
    long_description_content_type="text/markdown",
    author="0xroot",
    license="MIT",
    packages=find_packages(include=["geneflow", "geneflow.*"]),
    include_package_data=True,
    python_requires=">=3.9",
    install_requires=[
        "openai>=1.0.0",
        "psycopg2-binary>=2.9.0",
    ],
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    keywords="agent crew llm openai postgresql pgvector evolution memory",
)
