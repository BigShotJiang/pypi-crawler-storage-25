"""HTTP observability routes on FastMCP ASGI apps."""

from __future__ import annotations

import pytest
from starlette.testclient import TestClient


def test_health_sse_app(api_env):
    from speak_global_mcp.server import mcp

    client = TestClient(mcp.sse_app())
    r = client.get("/health")
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "ok"
    assert body["service"] == "speak-global-mcp"
    assert "version" in body


def test_ready_shallow_ok_streamable_http(api_env):
    from speak_global_mcp.server import mcp

    with TestClient(mcp.streamable_http_app()) as client:
        r = client.get("/ready")
    assert r.status_code == 200
    assert r.json()["ready"] is True
    assert r.json().get("deep_probe") is False


def test_ready_missing_api_key(monkeypatch: pytest.MonkeyPatch):
    from speak_global_mcp.config import reset_settings_cache
    from speak_global_mcp.server import mcp

    monkeypatch.setenv("SPEAKGLOBAL_ENVIRONMENT", "development")
    monkeypatch.setenv("SPEAKGLOBAL_API_BASE", "http://test.local")
    monkeypatch.delenv("SPEAKGLOBAL_API_KEY", raising=False)
    reset_settings_cache()
    client = TestClient(mcp.sse_app())
    r = client.get("/ready")
    assert r.status_code == 503
    assert r.json()["ready"] is False
