"""Multi-step flows (same order a real client would call the Developer API)."""

from __future__ import annotations

import json

import httpx
import pytest

from speak_global_mcp import tools as mcp_tools
from tests.fixtures import v1_samples as S


@pytest.mark.asyncio
async def test_stt_upload_transcribe_poll_recording_flow(mock_http):
    """Presign → register → transcribe → poll job → fetch recording with transcript."""
    sequence: list[tuple[str, str, dict | list]] = [
        ("GET", "/v1/recordings/presign", S.sample_presign()),
        ("POST", "/v1/recordings/upload/with-url", S.sample_register_upload()),
        ("POST", "/v1/processing/transcribe", S.sample_job_started()),
        ("GET", f"/v1/jobs/{S.JOB_UUID}", S.sample_job_row_completed()),
        ("GET", f"/v1/recordings/{S.SESSION_STT}", S.sample_recording_detail()),
    ]
    idx = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal idx
        assert idx < len(sequence)
        exp_m, exp_path, body = sequence[idx]
        assert request.method == exp_m, (idx, request.method, exp_m)
        assert request.url.path == exp_path, (idx, request.url.path, exp_path)
        idx += 1
        return httpx.Response(200, json=body)

    mock_http(handler)

    pres = json.loads(await mcp_tools.presign_audio_upload("new_clip.m4a", "audio/mp4"))
    public = pres["data"]["publicUrl"]

    reg = json.loads(
        await mcp_tools.register_recording_from_url(
            public,
            original_filename="new_clip.m4a",
        )
    )
    assert reg["session_id"] == S.SESSION_STT

    job = json.loads(await mcp_tools.start_transcription(S.SESSION_STT))
    assert job["job_id"] == S.JOB_UUID

    st = json.loads(await mcp_tools.get_job_status(S.JOB_UUID))
    assert st["status"] == "completed"

    rec = json.loads(await mcp_tools.get_recording(S.SESSION_STT))
    assert rec["data"]["transcript"]["transcript"][0]["transcript"] == "Hello from Lagos."

    assert idx == len(sequence)


@pytest.mark.asyncio
async def test_tts_account_pick_voice_generate_flow(mock_http):
    """Me → list profiles → TTS using default session from first row."""
    idx = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal idx
        if idx == 0:
            assert request.method == "GET" and request.url.path == "/v1/me"
            idx += 1
            return httpx.Response(200, json=S.sample_me())
        if idx == 1:
            assert request.method == "GET" and request.url.path == "/v1/voice-profiles"
            idx += 1
            return httpx.Response(200, json=S.sample_voice_profiles_list())
        if idx == 2:
            assert request.method == "POST" and request.url.path == "/v1/tts/generate"
            body = json.loads(request.content.decode())
            assert body["text"] == "Hook for TikTok."
            assert body["voice_profile_session_id"] == S.SESSION_VOICE
            idx += 1
            return httpx.Response(200, json=S.sample_tts_generate())
        return httpx.Response(500, json={"detail": "unexpected"})

    mock_http(handler)

    me = json.loads(await mcp_tools.account_summary())
    assert me["data"]["default_voice_session_id"] == S.SESSION_VOICE

    profiles = json.loads(await mcp_tools.list_voice_profiles())
    sid = profiles["data"][0]["session_id"]

    tts = json.loads(
        await mcp_tools.generate_tts("Hook for TikTok.", voice_profile_session_id=sid)
    )
    assert "generated_audio_url" in tts

    assert idx == 3


@pytest.mark.asyncio
async def test_enhance_after_transcribe_flow(mock_http):
    """Recording ready → queue enhance → poll job list."""
    sequence = [
        ("GET", f"/v1/recordings/{S.SESSION_STT}", S.sample_recording_detail()),
        (
            "POST",
            "/v1/processing/enhance",
            S.sample_job_started() | {"message": "Enhance started"},
        ),
        ("GET", f"/v1/jobs/session/{S.SESSION_STT}", S.sample_jobs_list()),
    ]
    i = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal i
        m, p, payload = sequence[i]
        assert request.method == m and request.url.path == p
        i += 1
        return httpx.Response(200, json=payload)

    mock_http(handler)

    json.loads(await mcp_tools.get_recording(S.SESSION_STT))
    json.loads(
        await mcp_tools.start_enhance(
            S.SESSION_STT,
            skip=False,
            enhancement="original",
            should_save_enhancement=True,
        )
    )
    jobs = json.loads(await mcp_tools.list_jobs_for_session(S.SESSION_STT))
    assert jobs[0]["job_type"] == "transcribe"
    assert i == 3
