"""Error formatting and edge cases mirroring FastAPI / httpx behavior."""

from __future__ import annotations

import httpx
import pytest

from speak_global_mcp.http_client import format_api_error, send


def test_format_api_error_string_detail():
    msg = format_api_error(401, '{"detail": "Invalid API key"}')
    assert "401" in msg
    assert "Invalid API key" in msg


def test_format_api_error_validation_list():
    body = (
        '{"detail":[{"loc":["body","session_id"],"msg":"field required",'
        '"type":"value_error.missing"}]}'
    )
    msg = format_api_error(422, body)
    assert "422" in msg
    assert "detail" in msg or "session_id" in msg or "field required" in msg


def test_format_api_error_non_json_body():
    msg = format_api_error(502, "bad gateway upstream")
    assert "502" in msg
    assert "bad gateway" in msg


def test_format_api_error_long_non_json_truncated():
    long_text = "x" * 800
    msg = format_api_error(500, long_text)
    assert "500" in msg
    assert len(msg) < len(long_text)


@pytest.mark.asyncio
async def test_send_empty_body_returns_none(api_env, mock_http):
    from speak_global_mcp import http_client

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, content=b"")

    mock_http(handler)
    async with http_client.httpx.AsyncClient(
        timeout=httpx.Timeout(300.0, connect=30.0)
    ) as client:
        assert await send(client, "GET", "/v1/me") is None


@pytest.mark.asyncio
async def test_402_payment_required_body(api_env, mock_http):
    from speak_global_mcp import http_client

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            402,
            json={"detail": "Insufficient credits for this operation."},
        )

    mock_http(handler)
    async with http_client.httpx.AsyncClient(
        timeout=httpx.Timeout(300.0, connect=30.0)
    ) as client:
        with pytest.raises(RuntimeError, match="402"):
            await send(client, "POST", "/v1/tts/generate")


@pytest.mark.asyncio
async def test_429_rate_limit(api_env, mock_http):
    from speak_global_mcp import http_client

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(429, json={"detail": "Rate limit exceeded"})

    mock_http(handler)
    async with http_client.httpx.AsyncClient(
        timeout=httpx.Timeout(300.0, connect=30.0)
    ) as client:
        with pytest.raises(RuntimeError, match="429"):
            await send(client, "GET", "/v1/me")
