"""Each MCP tool hits the expected path, method, and JSON body (mocked HTTP)."""

from __future__ import annotations

import json
import uuid
from typing import Any

import httpx
import pytest

from speak_global_mcp import tools as mcp_tools


def _echo_handler(captured: list[httpx.Request]):
    def handler(request: httpx.Request):
        captured.append(request)
        body: Any = None
        if request.content:
            try:
                body = json.loads(request.content.decode())
            except json.JSONDecodeError:
                body = request.content.decode()
        return httpx.Response(
            200,
            json={
                "method": request.method,
                "path": request.url.path,
                "query": dict(request.url.params),
                "body": body,
            },
        )

    return handler


@pytest.mark.asyncio
async def test_account_summary(mock_http):
    cap: list[httpx.Request] = []
    mock_http(_echo_handler(cap))
    out = await mcp_tools.account_summary()
    assert json.loads(out)["path"] == "/v1/me"
    assert json.loads(out)["method"] == "GET"
    assert len(cap) == 1


@pytest.mark.asyncio
async def test_list_voice_profiles(mock_http):
    mock_http(_echo_handler([]))
    out = json.loads(await mcp_tools.list_voice_profiles())
    assert out["path"] == "/v1/voice-profiles"


@pytest.mark.asyncio
async def test_get_voice_profile(mock_http):
    mock_http(_echo_handler([]))
    out = json.loads(await mcp_tools.get_voice_profile("sess-abc"))
    assert out["path"] == "/v1/voice-profiles/sess-abc"


@pytest.mark.asyncio
async def test_list_recordings(mock_http):
    mock_http(_echo_handler([]))
    out = json.loads(await mcp_tools.list_recordings(page=2, has_transcript=True))
    assert out["path"] == "/v1/recordings"
    assert out["query"]["page"] == "2"
    assert out["query"]["has_transcript"] == "true"


@pytest.mark.asyncio
async def test_get_recording(mock_http):
    mock_http(_echo_handler([]))
    out = json.loads(await mcp_tools.get_recording("sid-1"))
    assert out["path"] == "/v1/recordings/sid-1"


@pytest.mark.asyncio
async def test_generate_tts(mock_http):
    mock_http(_echo_handler([]))
    out = json.loads(
        await mcp_tools.generate_tts(
            "hello",
            voice_profile_session_id="vp1",
            speed=0.9,
            minimize_accent=True,
        )
    )
    assert out["path"] == "/v1/tts/generate"
    assert out["body"] == {
        "text": "hello",
        "speed": 0.9,
        "minimize_accent": True,
        "voice_profile_session_id": "vp1",
    }


@pytest.mark.asyncio
async def test_generate_tts_omits_optional_voice_profile(mock_http):
    mock_http(_echo_handler([]))
    out = json.loads(await mcp_tools.generate_tts("hi"))
    assert out["body"]["text"] == "hi"
    assert "voice_profile_session_id" not in out["body"]


@pytest.mark.asyncio
async def test_presign_audio_upload(mock_http):
    mock_http(_echo_handler([]))
    out = json.loads(await mcp_tools.presign_audio_upload("a.m4a", "audio/mp4"))
    assert out["path"] == "/v1/recordings/presign"
    assert out["query"]["file_name"] == "a.m4a"
    assert out["query"]["content_type"] == "audio/mp4"


@pytest.mark.asyncio
async def test_register_recording_from_url(mock_http):
    mock_http(_echo_handler([]))
    out = json.loads(
        await mcp_tools.register_recording_from_url(
            "https://cdn.example/f.mp3",
            original_filename="f.mp3",
            source_type="upload",
        )
    )
    assert out["path"] == "/v1/recordings/upload/with-url"
    assert out["body"] == {
        "file_url": "https://cdn.example/f.mp3",
        "source_type": "upload",
        "original_filename": "f.mp3",
    }


@pytest.mark.asyncio
async def test_start_transcription(mock_http):
    mock_http(_echo_handler([]))
    out = json.loads(
        await mcp_tools.start_transcription(
            "s1",
            speaker_detection=False,
            notify_user=True,
        )
    )
    assert out["path"] == "/v1/processing/transcribe"
    assert out["body"] == {
        "session_id": "s1",
        "notify_user": True,
        "speaker_detection": False,
    }


@pytest.mark.asyncio
async def test_start_enhance(mock_http):
    mock_http(_echo_handler([]))
    out = json.loads(
        await mcp_tools.start_enhance(
            session_id="s1",
            skip=True,
            enhancement="original",
            should_save_enhancement=True,
            fcm_token="tok",
        )
    )
    assert out["path"] == "/v1/processing/enhance"
    assert out["body"] == {
        "session_id": "s1",
        "skip": True,
        "enhancement": "original",
        "should_save_enhancement": True,
        "fcm_token": "tok",
    }


@pytest.mark.asyncio
async def test_start_enhance_no_fcm_token(mock_http):
    mock_http(_echo_handler([]))
    out = json.loads(
        await mcp_tools.start_enhance(
            session_id="s1",
            skip=False,
            enhancement="neutral",
            should_save_enhancement=False,
        )
    )
    assert "fcm_token" not in out["body"]


@pytest.mark.asyncio
async def test_edit_transcript(mock_http):
    mock_http(_echo_handler([]))
    transcript = {
        "session_id": "s1",
        "processing_time": 1.0,
        "transcript": [
            {
                "audio_url": "u",
                "audio_path": "p",
                "transcript": "hello",
                "duration": 1.0,
                "start_time": "0.0s",
                "end_time": "1.0s",
            }
        ],
    }
    out = json.loads(
        await mcp_tools.edit_transcript(
            session_id="s1",
            transcript=transcript,
            should_enhance=False,
            enhancement="neutral",
            should_save_enhancement=True,
            transcript_target="enhanced",
        )
    )
    assert out["path"] == "/v1/processing/edit-transcript"
    assert out["body"]["session_id"] == "s1"
    assert out["body"]["transcript"] == transcript
    assert out["body"]["should_enhance"] is False
    assert out["body"]["enhancement"] == "neutral"
    assert out["body"]["should_save_enhancement"] is True
    assert out["body"]["transcript_target"] == "enhanced"


@pytest.mark.asyncio
async def test_start_re_enhance(mock_http):
    mock_http(_echo_handler([]))
    out = json.loads(await mcp_tools.start_re_enhance("s9", minimize_accent=True))
    assert out["path"] == "/v1/processing/re-enhance"
    assert out["body"] == {"session_id": "s9", "minimize_accent": True}


@pytest.mark.asyncio
async def test_get_job_status(mock_http):
    jid = str(uuid.uuid4())
    mock_http(_echo_handler([]))
    out = json.loads(await mcp_tools.get_job_status(jid))
    assert out["path"] == f"/v1/jobs/{jid}"


@pytest.mark.asyncio
async def test_get_job_status_invalid_uuid():
    with pytest.raises(ValueError, match="UUID"):
        await mcp_tools.get_job_status("not-a-uuid")


@pytest.mark.asyncio
async def test_list_jobs_for_session(mock_http):
    mock_http(_echo_handler([]))
    out = json.loads(await mcp_tools.list_jobs_for_session("sess-z"))
    assert out["path"] == "/v1/jobs/session/sess-z"


@pytest.mark.asyncio
async def test_json_missing_key_errors(monkeypatch):
    monkeypatch.setenv("SPEAKGLOBAL_ENVIRONMENT", "development")
    monkeypatch.delenv("SPEAKGLOBAL_API_KEY", raising=False)
    monkeypatch.setenv("SPEAKGLOBAL_API_BASE", "http://x")
    with pytest.raises(ValueError, match="SPEAKGLOBAL_API_KEY"):
        await mcp_tools.account_summary()
