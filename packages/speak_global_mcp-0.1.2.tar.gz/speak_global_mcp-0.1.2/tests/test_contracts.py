"""
Contract tests: mock server returns JSON shaped like production `/v1` responses;
MCP tools must return pretty-printed JSON that still validates key fields.
"""

from __future__ import annotations

import json

import httpx
import pytest

from speak_global_mcp import tools as mcp_tools
from tests.fixtures import v1_samples as S


def _route_handler(routes: dict[tuple[str, str], dict | list]):
    """(method, path) -> JSON body."""

    def handler(request: httpx.Request) -> httpx.Response:
        key = (request.method, request.url.path)
        if key not in routes:
            return httpx.Response(
                404,
                json={"detail": f"test router: unregistered {key}"},
            )
        payload = routes[key]
        return httpx.Response(200, json=payload)

    return handler


@pytest.mark.asyncio
async def test_account_summary_matches_v1_me_shape(mock_http):
    routes = {("GET", "/v1/me"): S.sample_me()}
    mock_http(_route_handler(routes))
    data = json.loads(await mcp_tools.account_summary())
    assert data["message"] == "Account"
    assert data["data"]["user_id"] == "firebase_uid_demo"
    assert data["data"]["default_voice_session_id"] == S.SESSION_VOICE
    assert data["data"]["stats"]["recordings_count"] == 4
    assert data["data"]["api"]["version"] == "v1"


@pytest.mark.asyncio
async def test_list_voice_profiles_shape(mock_http):
    routes = {("GET", "/v1/voice-profiles"): S.sample_voice_profiles_list()}
    mock_http(_route_handler(routes))
    data = json.loads(await mcp_tools.list_voice_profiles())
    assert data["default_session_id"] == S.SESSION_VOICE
    assert len(data["data"]) == 1
    row = data["data"][0]
    assert row["session_id"] == S.SESSION_VOICE
    assert row["is_default"] is True
    assert row["tts_projects"] >= 0


@pytest.mark.asyncio
async def test_get_voice_profile_shape(mock_http):
    routes = {
        ("GET", f"/v1/voice-profiles/{S.SESSION_VOICE}"): S.sample_voice_profile_one(),
    }
    mock_http(_route_handler(routes))
    data = json.loads(await mcp_tools.get_voice_profile(S.SESSION_VOICE))
    assert data["data"]["voice_profile_status"] == "active"


@pytest.mark.asyncio
async def test_list_recordings_shape(mock_http):
    routes = {("GET", "/v1/recordings"): S.sample_recordings_page()}
    mock_http(_route_handler(routes))
    data = json.loads(await mcp_tools.list_recordings(page=1, has_transcript=False))
    assert data["pagination"]["total_count"] == 1
    assert data["data"][0]["session_id"] == S.SESSION_STT


@pytest.mark.asyncio
async def test_get_recording_shape(mock_http):
    routes = {
        ("GET", f"/v1/recordings/{S.SESSION_STT}"): S.sample_recording_detail(),
    }
    mock_http(_route_handler(routes))
    data = json.loads(await mcp_tools.get_recording(S.SESSION_STT))
    inner = data["data"]
    assert inner["transcript_status"] == "completed"
    assert inner["transcript"]["transcript"][0]["transcript"] == "Hello from Lagos."
    assert inner["jobs"][0]["job_type"] == "transcribe"
    assert inner["jobs"][0]["status"] == "completed"


@pytest.mark.asyncio
async def test_generate_tts_shape(mock_http):
    routes = {("POST", "/v1/tts/generate"): S.sample_tts_generate()}
    mock_http(_route_handler(routes))
    data = json.loads(
        await mcp_tools.generate_tts(
            "Script line one. Script line two.",
            voice_profile_session_id=S.SESSION_VOICE,
        )
    )
    assert data["generated_audio_url"].endswith(".mp3")
    assert data["generated_text"] == "Script line one. Script line two."
    assert data["reference_audio_duration"] == 12.4


@pytest.mark.asyncio
async def test_presign_shape(mock_http):
    routes = {("GET", "/v1/recordings/presign"): S.sample_presign()}
    mock_http(_route_handler(routes))
    data = json.loads(await mcp_tools.presign_audio_upload("clip.m4a", "audio/mp4"))
    assert "uploadUrl" in data["data"]
    assert "publicUrl" in data["data"]


@pytest.mark.asyncio
async def test_register_upload_shape(mock_http):
    routes = {
        ("POST", "/v1/recordings/upload/with-url"): S.sample_register_upload(),
    }
    mock_http(_route_handler(routes))
    data = json.loads(
        await mcp_tools.register_recording_from_url(
            "https://cdn.example.com/uploads/u/new_clip.m4a",
            original_filename="clip.m4a",
        )
    )
    assert data["session_id"] == S.SESSION_STT


@pytest.mark.asyncio
async def test_transcribe_job_started_shape(mock_http):
    routes = {("POST", "/v1/processing/transcribe"): S.sample_job_started()}
    mock_http(_route_handler(routes))
    data = json.loads(await mcp_tools.start_transcription(S.SESSION_STT))
    assert data["job_id"] == S.JOB_UUID
    assert data["session_id"] == S.SESSION_STT


@pytest.mark.asyncio
async def test_enhance_job_started_shape(mock_http):
    routes = {
        ("POST", "/v1/processing/enhance"): S.sample_job_started()
        | {"message": "Enhancement queued"},
    }
    mock_http(_route_handler(routes))
    data = json.loads(
        await mcp_tools.start_enhance(
            session_id=S.SESSION_STT,
            skip=False,
            enhancement="original",
            should_save_enhancement=True,
        )
    )
    assert data["job_id"] == S.JOB_UUID


@pytest.mark.asyncio
async def test_edit_transcript_db_response_shape(mock_http):
    routes = {
        ("POST", "/v1/processing/edit-transcript"): S.sample_edit_transcript_db_only(),
    }
    mock_http(_route_handler(routes))
    tr = S.sample_recording_detail()["data"]["transcript"]
    data = json.loads(
        await mcp_tools.edit_transcript(
            S.SESSION_STT,
            transcript=tr,
            should_enhance=False,
        )
    )
    assert data["session_id"] == S.SESSION_STT
    assert data["data"]["updated"] is True


@pytest.mark.asyncio
async def test_re_enhance_shape(mock_http):
    routes = {("POST", "/v1/processing/re-enhance"): S.sample_re_enhance()}
    mock_http(_route_handler(routes))
    data = json.loads(await mcp_tools.start_re_enhance(S.SESSION_STT))
    assert data["data"]["enhanced_media_url"].endswith(".mp3")


@pytest.mark.asyncio
async def test_get_job_shape(mock_http):
    routes = {("GET", f"/v1/jobs/{S.JOB_UUID}"): S.sample_job_row_completed()}
    mock_http(_route_handler(routes))
    data = json.loads(await mcp_tools.get_job_status(S.JOB_UUID))
    assert data["status"] == "completed"
    assert data["job_type"] == "transcribe"
    assert data["result_data"]["transcript_uri"].startswith("s3://")


@pytest.mark.asyncio
async def test_list_jobs_shape(mock_http):
    routes = {
        ("GET", f"/v1/jobs/session/{S.SESSION_STT}"): S.sample_jobs_list(),
    }
    mock_http(_route_handler(routes))
    data = json.loads(await mcp_tools.list_jobs_for_session(S.SESSION_STT))
    assert isinstance(data, list)
    assert data[0]["session_id"] == S.SESSION_STT
