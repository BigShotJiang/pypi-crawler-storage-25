"""Path encoding for session_id (must match quoted URL segments)."""

from __future__ import annotations

import httpx
import pytest

from speak_global_mcp import tools as mcp_tools


@pytest.mark.asyncio
async def test_get_recording_encodes_slashes_and_reserved_chars(mock_http):
    captured: list[bytes] = []

    def handler(request: httpx.Request) -> httpx.Response:
        # httpx exposes decoded `.path`; wire path is in `raw_path`.
        captured.append(request.url.raw_path)
        return httpx.Response(200, json={"message": "ok", "data": {}})

    mock_http(handler)
    await mcp_tools.get_recording("part1/part2|x")
    assert captured == [b"/v1/recordings/part1%2Fpart2%7Cx"]


@pytest.mark.asyncio
async def test_voice_profile_and_jobs_session_same_encoding(mock_http):
    raw_paths: list[bytes] = []

    def handler(request: httpx.Request) -> httpx.Response:
        raw_paths.append(request.url.raw_path)
        p = request.url.path
        return httpx.Response(200, json=[] if "/jobs/session/" in p else {})

    mock_http(handler)
    await mcp_tools.get_voice_profile("s/id")
    await mcp_tools.list_jobs_for_session("s/id")
    assert raw_paths[0] == b"/v1/voice-profiles/s%2Fid"
    assert raw_paths[1] == b"/v1/jobs/session/s%2Fid"
