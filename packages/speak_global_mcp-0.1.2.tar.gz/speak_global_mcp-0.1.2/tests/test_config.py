"""Settings validation (production safeguards)."""

from __future__ import annotations

import pytest

from speak_global_mcp.config import Settings, get_settings, reset_settings_cache


def test_development_allows_http(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setenv("SPEAKGLOBAL_ENVIRONMENT", "development")
    monkeypatch.setenv("SPEAKGLOBAL_API_BASE", "http://localhost:8000")
    monkeypatch.setenv("SPEAKGLOBAL_API_KEY", "sg_live_x")
    reset_settings_cache()
    s = get_settings()
    assert s.api_base == "http://localhost:8000"


def test_production_requires_https(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setenv("SPEAKGLOBAL_ENVIRONMENT", "production")
    monkeypatch.setenv("SPEAKGLOBAL_API_BASE", "http://api.example.com")
    monkeypatch.setenv("SPEAKGLOBAL_API_KEY", "sg_live_x")
    reset_settings_cache()
    with pytest.raises(ValueError, match="https"):
        get_settings()


def test_production_requires_api_key(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setenv("SPEAKGLOBAL_ENVIRONMENT", "production")
    monkeypatch.setenv("SPEAKGLOBAL_API_BASE", "https://api.example.com")
    monkeypatch.delenv("SPEAKGLOBAL_API_KEY", raising=False)
    reset_settings_cache()
    with pytest.raises(ValueError, match="SPEAKGLOBAL_API_KEY"):
        get_settings()


def test_api_base_strips_trailing_slash(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setenv("SPEAKGLOBAL_ENVIRONMENT", "development")
    monkeypatch.setenv("SPEAKGLOBAL_API_BASE", "http://x.com/")
    monkeypatch.setenv("SPEAKGLOBAL_API_KEY", "k")
    reset_settings_cache()
    assert get_settings().api_base == "http://x.com"


def test_settings_reads_mcp_transport(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setenv("SPEAKGLOBAL_ENVIRONMENT", "development")
    monkeypatch.setenv("SPEAKGLOBAL_API_BASE", "http://x")
    monkeypatch.setenv("SPEAKGLOBAL_API_KEY", "k")
    monkeypatch.setenv("SPEAKGLOBAL_MCP_TRANSPORT", "sse")
    reset_settings_cache()
    assert get_settings().mcp_transport == "sse"


def test_direct_settings_instantiation_without_lru_cache():
    s = Settings(
        environment="production",
        api_base="https://a.com",
        api_key="secret",
    )
    assert s.api_base == "https://a.com"
