"""Low-level HTTP helper behavior."""

from __future__ import annotations

import httpx
import pytest

from speak_global_mcp.http_client import require_api_key, send


@pytest.mark.asyncio
async def test_send_success(api_env, mock_http):
    from speak_global_mcp import http_client

    def handler(request: httpx.Request):
        assert request.method == "GET"
        assert str(request.url).startswith("http://test-api.local/v1/me")
        assert request.headers.get("authorization") == "Bearer sg_live_testkey"
        return httpx.Response(200, json={"message": "ok"})

    mock_http(handler)
    async with http_client.httpx.AsyncClient(
        timeout=httpx.Timeout(300.0, connect=30.0)
    ) as client:
        data = await send(client, "GET", "/v1/me")
    assert data == {"message": "ok"}


@pytest.mark.asyncio
async def test_send_4xx_raises(api_env, mock_http):
    from speak_global_mcp import http_client

    def handler(request: httpx.Request):
        return httpx.Response(401, json={"detail": "nope"})

    mock_http(handler)
    async with http_client.httpx.AsyncClient(
        timeout=httpx.Timeout(300.0, connect=30.0)
    ) as client:
        with pytest.raises(RuntimeError, match="HTTP 401"):
            await send(client, "GET", "/v1/me")


def test_require_key_missing(monkeypatch):
    monkeypatch.delenv("SPEAKGLOBAL_API_KEY", raising=False)
    with pytest.raises(ValueError, match="SPEAKGLOBAL_API_KEY"):
        require_api_key()
