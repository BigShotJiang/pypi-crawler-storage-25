"""MCP tool handlers (Developer API /v1)."""

from __future__ import annotations

from typing import Any
from uuid import UUID

from speak_global_mcp import http_client as api
from speak_global_mcp.mcp_instance import mcp
from speak_global_mcp.serialization import pretty_json


@mcp.tool()
async def account_summary() -> str:
    """Account, credits, default_voice_session_id. Scope: me:read."""
    data = await api.request_json("GET", "/v1/me")
    return pretty_json(data)


@mcp.tool()
async def list_voice_profiles() -> str:
    """List voice profiles (session_id for TTS). Profiles are created in the web app, not via MCP.
    Scope: voice_profiles:list."""
    data = await api.request_json("GET", "/v1/voice-profiles")
    return pretty_json(data)


@mcp.tool()
async def get_voice_profile(session_id: str) -> str:
    """One voice profile. Scope: voice_profiles:read."""
    sid = api.encode_path_segment(session_id)
    data = await api.request_json("GET", f"/v1/voice-profiles/{sid}")
    return pretty_json(data)


@mcp.tool()
async def list_recordings(page: int = 1, has_transcript: bool = False) -> str:
    """Library recordings (paged). Scope: recordings:list."""
    data = await api.request_json(
        "GET",
        "/v1/recordings",
        params={"page": page, "has_transcript": has_transcript},
    )
    return pretty_json(data)


@mcp.tool()
async def get_recording(session_id: str) -> str:
    """Recording detail, transcript, jobs. Scope: recordings:read."""
    sid = api.encode_path_segment(session_id)
    data = await api.request_json("GET", f"/v1/recordings/{sid}")
    return pretty_json(data)


@mcp.tool()
async def generate_tts(
    text: str,
    voice_profile_session_id: str | None = None,
    speed: float = 0.95,
    minimize_accent: bool = False,
) -> str:
    """TTS with voice clone. Pass voice_profile_session_id from list_voice_profiles (active profile)
    or omit if the account has default_voice_session_id set. Scope: tts:generate."""
    payload: dict[str, Any] = {
        "text": text,
        "speed": speed,
        "minimize_accent": minimize_accent,
    }
    if voice_profile_session_id:
        payload["voice_profile_session_id"] = voice_profile_session_id
    data = await api.request_json("POST", "/v1/tts/generate", json_body=payload)
    return pretty_json(data)


@mcp.tool()
async def presign_audio_upload(file_name: str, content_type: str) -> str:
    """Presigned PUT URL + public URL. Scope: recordings:upload."""
    data = await api.request_json(
        "GET",
        "/v1/recordings/presign",
        params={"file_name": file_name, "content_type": content_type},
    )
    return pretty_json(data)


@mcp.tool()
async def register_recording_from_url(
    file_url: str,
    original_filename: str = "audio.mp3",
    source_type: str = "upload",
) -> str:
    """Register upload by URL. Scope: recordings:upload."""
    payload = {
        "file_url": file_url,
        "source_type": source_type,
        "original_filename": original_filename,
    }
    data = await api.request_json(
        "POST", "/v1/recordings/upload/with-url", json_body=payload
    )
    return pretty_json(data)


@mcp.tool()
async def start_transcription(
    session_id: str,
    speaker_detection: bool = True,
    notify_user: bool = False,
) -> str:
    """Queue STT. Scope: processing:transcribe."""
    payload = {
        "session_id": session_id,
        "notify_user": notify_user,
        "speaker_detection": speaker_detection,
    }
    data = await api.request_json(
        "POST", "/v1/processing/transcribe", json_body=payload
    )
    return pretty_json(data)


@mcp.tool()
async def start_enhance(
    session_id: str,
    skip: bool,
    enhancement: str,
    should_save_enhancement: bool,
    fcm_token: str | None = None,
) -> str:
    """Queue enhancement. Scope: processing:enhance."""
    payload: dict[str, Any] = {
        "session_id": session_id,
        "skip": skip,
        "enhancement": enhancement,
        "should_save_enhancement": should_save_enhancement,
    }
    if fcm_token is not None:
        payload["fcm_token"] = fcm_token
    data = await api.request_json("POST", "/v1/processing/enhance", json_body=payload)
    return pretty_json(data)


@mcp.tool()
async def edit_transcript(
    session_id: str,
    transcript: dict[str, Any],
    should_enhance: bool = True,
    enhancement: str = "original",
    should_save_enhancement: bool = False,
    transcript_target: str = "original",
) -> str:
    """Update transcript; optional re-enhance. Scope: processing:edit_transcript."""
    payload: dict[str, Any] = {
        "session_id": session_id,
        "transcript": transcript,
        "should_enhance": should_enhance,
        "enhancement": enhancement,
        "should_save_enhancement": should_save_enhancement,
        "transcript_target": transcript_target,
    }
    data = await api.request_json(
        "POST", "/v1/processing/edit-transcript", json_body=payload
    )
    return pretty_json(data)


@mcp.tool()
async def start_re_enhance(session_id: str, minimize_accent: bool = False) -> str:
    """Re-run enhancement. Scope: processing:re_enhance."""
    payload = {"session_id": session_id, "minimize_accent": minimize_accent}
    data = await api.request_json("POST", "/v1/processing/re-enhance", json_body=payload)
    return pretty_json(data)


@mcp.tool()
async def get_job_status(job_id: str) -> str:
    """Job by UUID. Scope: jobs:read."""
    try:
        UUID(job_id)
    except ValueError as e:
        raise ValueError("job_id must be a UUID") from e
    data = await api.request_json("GET", f"/v1/jobs/{job_id}")
    return pretty_json(data)


@mcp.tool()
async def list_jobs_for_session(session_id: str) -> str:
    """Jobs for session_id. Scope: jobs:read."""
    sid = api.encode_path_segment(session_id)
    data = await api.request_json("GET", f"/v1/jobs/session/{sid}")
    return pretty_json(data)
