"""Process entry: logging and MCP transport."""

from __future__ import annotations

import logging

from speak_global_mcp.config import get_settings
from speak_global_mcp.mcp_instance import mcp

logger = logging.getLogger("speak_global_mcp")


def configure_logging() -> None:
    settings = get_settings()
    level = getattr(logging, settings.log_level, logging.INFO)
    root = logging.getLogger()
    if not root.handlers:
        logging.basicConfig(
            level=level,
            format="%(asctime)s %(levelname)s %(name)s %(message)s",
        )
    else:
        root.setLevel(level)
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)


def main() -> None:
    configure_logging()
    settings = get_settings()
    logger.info(
        "start transport=%s environment=%s api_base=%s",
        settings.mcp_transport,
        settings.environment,
        settings.api_base,
    )
    transport = settings.mcp_transport
    if transport not in ("stdio", "sse", "streamable-http"):
        transport = "stdio"
    mcp.run(transport=transport)  # type: ignore[arg-type]
