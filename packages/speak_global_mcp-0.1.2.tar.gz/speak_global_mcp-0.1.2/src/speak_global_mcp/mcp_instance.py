"""Single FastMCP application instance."""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP

_INSTRUCTIONS = (
    "SpeakGlobal: TTS (voice clone), STT, recordings via Developer API /v1. "
    "TTS needs an existing voice profile: use list_voice_profiles (session_id per row, "
    "voice_profile_status should be active) or account_summary.default_voice_session_id when set. "
    "This MCP cannot create voice profiles or open a browser; users create/clone voices in the "
    "SpeakGlobal web app (e.g. https://speakglobal.ai/dashboard/tts/create-profile; list at "
    "/dashboard/voice-profiles). Then generate_tts with that session_id. "
    "STT: presign_audio_upload, PUT file, register_recording_from_url, start_transcription, "
    "then get_job_status or get_recording. "
    "Processing: start_enhance, edit_transcript, start_re_enhance."
)

mcp = FastMCP("SpeakGlobal", instructions=_INSTRUCTIONS)
