"""
CLI entrypoint. Imports register tools and observability routes on the shared ``mcp`` instance.
"""

from __future__ import annotations

import speak_global_mcp.observability  # noqa: F401
import speak_global_mcp.tools  # noqa: F401

from speak_global_mcp.mcp_instance import mcp
from speak_global_mcp.runtime import main

__all__ = ["mcp", "main"]

if __name__ == "__main__":
    main()
