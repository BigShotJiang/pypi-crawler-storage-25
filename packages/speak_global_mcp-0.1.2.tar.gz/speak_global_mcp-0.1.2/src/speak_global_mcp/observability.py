"""HTTP routes for health checks (SSE / streamable-http only)."""

from __future__ import annotations

import httpx
from starlette.requests import Request
from starlette.responses import JSONResponse

from speak_global_mcp import __version__
from speak_global_mcp import http_client as api
from speak_global_mcp.config import get_settings
from speak_global_mcp.mcp_instance import mcp


@mcp.custom_route("/health", methods=["GET"])
async def health(_request: Request) -> JSONResponse:
    return JSONResponse(
        {
            "status": "ok",
            "service": "speak-global-mcp",
            "version": __version__,
        }
    )


@mcp.custom_route("/ready", methods=["GET"])
async def ready(_request: Request) -> JSONResponse:
    try:
        settings = get_settings()
    except Exception as exc:  # noqa: BLE001
        return JSONResponse({"ready": False, "reason": str(exc)}, status_code=503)

    if not settings.api_key.strip():
        return JSONResponse(
            {"ready": False, "reason": "missing api key"},
            status_code=503,
        )

    if not settings.ready_deep_probe:
        return JSONResponse(
            {
                "ready": True,
                "deep_probe": False,
                "environment": settings.environment,
            }
        )

    try:
        async with httpx.AsyncClient(**api.build_httpx_client_kwargs()) as client:
            response = await client.get(
                f"{settings.api_base}/v1/me",
                headers=api.auth_headers(),
            )
    except Exception as exc:  # noqa: BLE001
        return JSONResponse(
            {"ready": False, "reason": f"upstream: {exc}"},
            status_code=503,
        )

    if response.status_code >= 400:
        return JSONResponse(
            {
                "ready": False,
                "reason": api.format_api_error(response.status_code, response.text),
            },
            status_code=503,
        )
    return JSONResponse({"ready": True, "deep_probe": True})
