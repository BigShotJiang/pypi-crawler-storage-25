"""SpeakGlobal MCP server — Developer API tools."""

__version__ = "0.1.0"
