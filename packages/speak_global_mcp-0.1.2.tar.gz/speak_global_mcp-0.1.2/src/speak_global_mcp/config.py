"""Production-oriented settings (env-driven)."""

from __future__ import annotations

from functools import lru_cache
from typing import Literal

from pydantic import Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="SPEAKGLOBAL_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    environment: Literal["development", "production"] = "development"
    api_base: str = Field(default="http://127.0.0.1:8000")
    api_key: str = Field(default="")

    http_timeout_total: float = Field(default=300.0, ge=5.0, le=3600.0)
    http_timeout_connect: float = Field(default=30.0, ge=1.0, le=120.0)
    http_verify_ssl: bool = True
    http_trust_env: bool = Field(default=False)
    http_max_connections: int = Field(default=100, ge=1, le=500)
    http_max_keepalive_connections: int = Field(default=20, ge=0, le=200)

    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = "INFO"

    mcp_transport: Literal["stdio", "sse", "streamable-http"] = "stdio"

    ready_deep_probe: bool = Field(default=False)

    @field_validator("api_base")
    @classmethod
    def strip_api_base(cls, v: str) -> str:
        return (v or "").strip().rstrip("/")

    @model_validator(mode="after")
    def production_rules(self):
        if self.environment != "production":
            return self
        base = self.api_base.lower()
        if not base.startswith("https://"):
            raise ValueError(
                "SPEAKGLOBAL_API_BASE must use https:// when SPEAKGLOBAL_ENVIRONMENT=production"
            )
        if not self.api_key.strip():
            raise ValueError(
                "SPEAKGLOBAL_API_KEY is required when SPEAKGLOBAL_ENVIRONMENT=production"
            )
        return self


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()


def reset_settings_cache() -> None:
    """Clear settings singleton (tests / reload)."""
    get_settings.cache_clear()
