"""HTTP client for SpeakGlobal Developer API (/v1)."""

from __future__ import annotations

import json
import logging
from typing import Any
from urllib.parse import quote

import httpx

from speak_global_mcp.config import get_settings

logger = logging.getLogger("speak_global_mcp.http")

__all__ = [
    "auth_headers",
    "build_httpx_client_kwargs",
    "encode_path_segment",
    "format_api_error",
    "require_api_key",
    "request_json",
    "send",
]


def encode_path_segment(segment: str) -> str:
    return quote(segment, safe="")


def format_api_error(status: int, body: str) -> str:
    try:
        data = json.loads(body)
        detail = data.get("detail", data)
        return f"HTTP {status}: {detail}"
    except json.JSONDecodeError:
        return f"HTTP {status}: {body[:500]}"


def require_api_key() -> None:
    if not get_settings().api_key.strip():
        raise ValueError(
            "Missing SPEAKGLOBAL_API_KEY. Set your Developer API key (sg_live_…)."
        )


def auth_headers() -> dict[str, str]:
    key = get_settings().api_key.strip()
    return {
        "Authorization": f"Bearer {key}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }


def build_httpx_client_kwargs() -> dict[str, Any]:
    s = get_settings()
    return {
        "timeout": httpx.Timeout(s.http_timeout_total, connect=s.http_timeout_connect),
        "limits": httpx.Limits(
            max_connections=s.http_max_connections,
            max_keepalive_connections=s.http_max_keepalive_connections,
        ),
        "verify": s.http_verify_ssl,
        "trust_env": s.http_trust_env,
    }


async def send(
    client: httpx.AsyncClient,
    method: str,
    path: str,
    *,
    params: dict[str, Any] | None = None,
    json_body: dict[str, Any] | None = None,
) -> Any:
    base = get_settings().api_base
    url = f"{base}{path}"
    logger.debug("request %s %s", method, path)
    response = await client.request(
        method,
        url,
        params=params,
        json=json_body,
        headers=auth_headers(),
    )
    if response.status_code >= 400:
        logger.warning(
            "error %s %s -> %s",
            method,
            path,
            response.status_code,
        )
        raise RuntimeError(format_api_error(response.status_code, response.text))
    if not response.content:
        return None
    return response.json()


async def request_json(
    method: str,
    path: str,
    *,
    params: dict[str, Any] | None = None,
    json_body: dict[str, Any] | None = None,
) -> Any:
    require_api_key()
    async with httpx.AsyncClient(**build_httpx_client_kwargs()) as client:
        return await send(client, method, path, params=params, json_body=json_body)
