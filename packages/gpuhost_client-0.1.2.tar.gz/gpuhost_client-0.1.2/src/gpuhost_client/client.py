"""Synchronous client for the ComputeGateway GPU Model Host."""

from __future__ import annotations

import base64
import json
import os
from collections.abc import Iterable, Iterator, Sequence
from pathlib import Path
from typing import Any, Optional, Union

import httpx

from .errors import GPUHostError, GPUHostHTTPError, GPUHostQuotaError, GPUHostTimeoutError
from .recommended import (
    DEFAULT_MAX_PARALLEL,
    OPTIMAL_BATCH_SIZE,
    SERVER_BATCH_CAP,
)

ImageInput = Union[bytes, str, Path]
"""An image, supplied as raw bytes, a filesystem path, or a base64 string."""

JsonDict = dict[str, Any]


def _resolve_optimal(endpoint: str, model_id: Optional[str]) -> int:
    """Return the optimal batch size for ``endpoint`` (and optional model)."""
    if model_id and model_id in OPTIMAL_BATCH_SIZE:
        return OPTIMAL_BATCH_SIZE[model_id]
    return OPTIMAL_BATCH_SIZE.get(endpoint, 32)


def _clamp_to_cap(endpoint: str, batch_size: int) -> int:
    cap = SERVER_BATCH_CAP.get(endpoint)
    if cap is None:
        return max(1, batch_size)
    return max(1, min(batch_size, cap))


def _chunked(seq: Sequence[Any], size: int) -> Iterator[Sequence[Any]]:
    for i in range(0, len(seq), size):
        yield seq[i : i + size]


def _read_image(image: ImageInput) -> tuple[str, str]:
    """Return ``(b64_str, mime_type)`` for a single image input."""
    if isinstance(image, (bytes, bytearray)):
        data = bytes(image)
        mime = _sniff_mime(data)
        return base64.b64encode(data).decode("ascii"), mime
    if isinstance(image, Path) or (isinstance(image, str) and os.path.exists(image)):
        data = Path(image).read_bytes()
        mime = _sniff_mime(data)
        return base64.b64encode(data).decode("ascii"), mime
    # Treat as already-encoded base64 string.
    if isinstance(image, str):
        return image, "image/png"
    raise TypeError(f"unsupported image type: {type(image)!r}")


def _sniff_mime(data: bytes) -> str:
    if data.startswith(b"\x89PNG"):
        return "image/png"
    if data.startswith(b"\xff\xd8"):
        return "image/jpeg"
    if data.startswith(b"GIF8"):
        return "image/gif"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "image/webp"
    return "application/octet-stream"


class GPUHostClient:
    """Synchronous client for the GPU Model Host gateway.

    Args:
        host: Base URL, e.g.
            ``https://``.
            Trailing ``/`` is allowed and stripped.
        api_key: API key sent as ``Authorization: Bearer <key>``.
        timeout: Per-request timeout in seconds. Defaults to 60.
        max_retries: Best-effort retry count for ``Timeout`` /
            ``ProviderUnavailable`` / ``ModelLoadRejected`` responses.
            Defaults to 0 (no retry — caller should orchestrate).
        user_agent: Optional User-Agent override.

    The client owns an internal :class:`httpx.Client`. Use it as a context
    manager or call :meth:`close` to release the connection pool.
    """

    DEFAULT_TIMEOUT_S: float = 60.0

    def __init__(
        self,
        host: str,
        api_key: str,
        *,
        timeout: float = DEFAULT_TIMEOUT_S,
        max_retries: int = 0,
        user_agent: Optional[str] = None,
        verify: Union[bool, str] = True,
    ) -> None:
        if not host:
            raise ValueError("host is required")
        if not api_key:
            raise ValueError("api_key is required")
        self._host = host.rstrip("/")
        self._api_key = api_key
        self._max_retries = max_retries
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Accept": "application/json",
            "User-Agent": user_agent or f"gpuhost-client/0.1.0 (httpx/{httpx.__version__})",
        }
        self._http = httpx.Client(
            base_url=self._host,
            headers=headers,
            timeout=timeout,
            verify=verify,
        )

    # ------------------------------------------------------------------ lifecycle

    def __enter__(self) -> "GPUHostClient":
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    def close(self) -> None:
        self._http.close()

    # ------------------------------------------------------------------ low-level

    def _post(self, path: str, body: JsonDict, *, timeout: Optional[float] = None) -> JsonDict:
        return self._request("POST", path, json_body=body, timeout=timeout)

    def _get(self, path: str, *, timeout: Optional[float] = None) -> JsonDict:
        return self._request("GET", path, timeout=timeout)

    def _request(
        self,
        method: str,
        path: str,
        *,
        json_body: Optional[JsonDict] = None,
        timeout: Optional[float] = None,
    ) -> JsonDict:
        last_exc: Optional[Exception] = None
        for attempt in range(self._max_retries + 1):
            try:
                response = self._http.request(
                    method,
                    path,
                    json=json_body,
                    timeout=timeout if timeout is not None else httpx.USE_CLIENT_DEFAULT,
                )
            except httpx.TimeoutException as exc:
                last_exc = GPUHostTimeoutError(str(exc))
                if attempt >= self._max_retries:
                    raise last_exc from exc
                continue
            except httpx.HTTPError as exc:  # network-level
                raise GPUHostError(f"HTTP transport error: {exc}") from exc

            if response.status_code < 400:
                if response.headers.get("content-type", "").startswith("application/json"):
                    return response.json()
                return {"_raw": response.content}

            err = self._raise_for_status(response)
            if err.retryable and attempt < self._max_retries:
                last_exc = err
                continue
            raise err
        if last_exc is not None:
            raise last_exc
        raise GPUHostError("unreachable")

    @staticmethod
    def _raise_for_status(response: httpx.Response) -> GPUHostHTTPError:
        body: Any = None
        code = "Unknown"
        message = response.text[:500]
        retryable: Optional[bool] = None
        retry_after_ms: Optional[int] = None
        request_id: Optional[str] = None
        try:
            body = response.json()
            err = (body or {}).get("error") or {}
            if isinstance(err, dict):
                code = str(err.get("code") or code)
                message = str(err.get("message") or message)
                retryable = err.get("retryable")
                retry_after_ms = err.get("retry_after_ms")
            request_id = (body or {}).get("request_id")
        except (json.JSONDecodeError, ValueError):
            pass
        cls = GPUHostQuotaError if response.status_code == 429 else GPUHostHTTPError
        return cls(
            status_code=response.status_code,
            code=code,
            message=message,
            retryable=retryable,
            retry_after_ms=retry_after_ms,
            request_id=request_id,
            body=body,
        )

    # ------------------------------------------------------------------ ops

    def health(self) -> JsonDict:
        """``GET /health`` — liveness probe."""
        return self._get("/health")

    def ready(self) -> JsonDict:
        """``GET /ready`` — readiness probe."""
        return self._get("/ready")

    def models(self) -> JsonDict:
        """``GET /models`` — registry snapshot (models + LLM providers + state)."""
        return self._get("/models")

    def admin_limits(self) -> JsonDict:
        """``GET /v1/admin/limits`` — current server-side caps and quotas."""
        return self._get("/v1/admin/limits")

    # ------------------------------------------------------------------ embed

    def embed(
        self,
        texts: Union[str, Sequence[str]],
        *,
        model_id: str = "embed-baseline",
        batch_size: Optional[int] = None,
    ) -> Union[list[float], list[list[float]]]:
        """Generate embeddings.

        - ``texts`` is a string → returns a single vector ``list[float]``.
        - ``texts`` is a list → returns ``list[list[float]]`` aligned to input
          order. The list is automatically chunked at the optimal batch size
          for the chosen model and reassembled before return.
        """
        scalar = isinstance(texts, str)
        items: list[str] = [texts] if scalar else list(texts)
        if not items:
            return []
        bs = _clamp_to_cap("embed", batch_size or _resolve_optimal("embed", model_id))
        out: list[list[float]] = []
        for chunk in _chunked(items, bs):
            envelope = self._post(
                "/v1/embed",
                {"model_id": model_id, "texts": list(chunk)},
            )
            result = envelope.get("result") or {}
            vectors = result.get("vectors") or envelope.get("vectors") or []
            out.extend(vectors)
        return out[0] if scalar else out

    # ------------------------------------------------------------------ entities

    def entities(
        self,
        text: Union[str, Sequence[str]],
        *,
        model_id: str = "entity-gliner",
        labels: Optional[Sequence[str]] = None,
        threshold: Optional[float] = None,
        batch_size: Optional[int] = None,
        max_parallel: Optional[int] = None,
    ) -> Union[list[JsonDict], list[list[JsonDict]]]:
        """Extract entity spans.

        Single ``str`` → ``list[entity-dict]``.
        List of strings → ``list[list[entity-dict]]`` aligned to input order.
        """
        scalar = isinstance(text, str)
        items: list[str] = [text] if scalar else list(text)
        if not items:
            return []

        if scalar:
            body: JsonDict = {"model_id": model_id, "text": items[0]}
            if labels is not None:
                body["labels"] = list(labels)
            if threshold is not None:
                body["threshold"] = threshold
            envelope = self._post("/v1/entities", body)
            result = envelope.get("result") or {}
            return result.get("entities") or []

        bs = _clamp_to_cap("entities", batch_size or _resolve_optimal("entities", model_id))
        mp = max_parallel or DEFAULT_MAX_PARALLEL["entities"]
        out: list[list[JsonDict]] = []
        for chunk in _chunked(items, bs):
            body = {
                "model_id": model_id,
                "texts": list(chunk),
                "max_parallel": mp,
            }
            if labels is not None:
                body["labels"] = list(labels)
            if threshold is not None:
                body["threshold"] = threshold
            envelope = self._post("/v1/entities/batch", body)
            out.extend(self._unpack_batch_envelope(envelope, lambda r: r.get("entities") or []))
        return out

    # ------------------------------------------------------------------ translate

    def translate(
        self,
        text: Union[str, Sequence[str]],
        *,
        src: str,
        tgt: str = "en",
        batch_size: Optional[int] = None,
        max_parallel: Optional[int] = None,
    ) -> Union[str, list[str]]:
        """Translate ``text`` (single or list) into ``tgt`` (default ``en``)."""
        scalar = isinstance(text, str)
        items: list[str] = [text] if scalar else list(text)
        if not items:
            return "" if scalar else []

        if scalar:
            envelope = self._post(
                "/v1/translate",
                {"text": items[0], "src": src, "tgt": tgt},
            )
            result = envelope.get("result") or {}
            return str(result.get("translated_text") or "")

        bs = _clamp_to_cap("translate", batch_size or _resolve_optimal("translate", None))
        mp = max_parallel or DEFAULT_MAX_PARALLEL["translate"]
        out: list[str] = []
        for chunk in _chunked(items, bs):
            envelope = self._post(
                "/v1/translate/batch",
                {"texts": list(chunk), "src": src, "tgt": tgt, "max_parallel": mp},
            )
            out.extend(
                self._unpack_batch_envelope(
                    envelope, lambda r: str(r.get("translated_text") or "")
                )
            )
        return out

    # ------------------------------------------------------------------ rerank

    def rerank(
        self,
        query: str,
        documents: Sequence[str],
        *,
        top_k: Optional[int] = None,
        model_id: Optional[str] = None,
        return_documents: bool = False,
    ) -> list[JsonDict]:
        """Score ``documents`` against ``query`` with the cross-encoder.

        Always uses the single-call route. ``len(documents)`` should not
        exceed ``rerank_max_documents`` (server-side cap). The optimal
        ``len(documents)`` for steady-state throughput is **32** — beyond
        that p95 grows super-linearly.
        """
        body: JsonDict = {"query": query, "documents": list(documents)}
        if top_k is not None:
            body["top_k"] = top_k
        if model_id is not None:
            body["model_id"] = model_id
        if return_documents:
            body["return_documents"] = True
        envelope = self._post("/v1/rerank", body)
        result = envelope.get("result") or envelope
        return result.get("results") or []

    # ------------------------------------------------------------------ ocr

    def ocr(
        self,
        images: Union[ImageInput, Sequence[ImageInput]],
        *,
        min_confidence: Optional[float] = None,
        model_id: Optional[str] = None,
        batch_size: Optional[int] = None,
        max_parallel: Optional[int] = None,
    ) -> Union[JsonDict, list[JsonDict]]:
        """Run OCR on one image or a list of images.

        ``images`` accepts raw ``bytes``, a filesystem path (``str``/``Path``),
        or a base64-encoded ``str``. Single input → single result dict; list
        input → list of result dicts aligned to input order.
        """
        scalar = not isinstance(images, (list, tuple))
        items_in: list[ImageInput] = [images] if scalar else list(images)  # type: ignore[list-item]
        if not items_in:
            return [] if not scalar else {}

        if scalar:
            b64, mime = _read_image(items_in[0])
            body: JsonDict = {"image_b64": b64, "mime_type": mime}
            if min_confidence is not None:
                body["min_confidence"] = min_confidence
            if model_id is not None:
                body["model_id"] = model_id
            envelope = self._post("/v1/ocr", body)
            return envelope.get("result") or {}

        bs = _clamp_to_cap("ocr", batch_size or _resolve_optimal("ocr", model_id))
        mp = max_parallel or DEFAULT_MAX_PARALLEL["ocr"]
        out: list[JsonDict] = []
        for chunk in _chunked(items_in, bs):
            payload_images: list[JsonDict] = []
            for img in chunk:
                b64, mime = _read_image(img)
                entry: JsonDict = {"image_b64": b64, "mime_type": mime}
                if min_confidence is not None:
                    entry["min_confidence"] = min_confidence
                payload_images.append(entry)
            body = {"images": payload_images, "max_parallel": mp}
            if model_id is not None:
                body["model_id"] = model_id
            envelope = self._post("/v1/ocr/batch", body)
            out.extend(self._unpack_batch_envelope(envelope, lambda r: r))
        return out

    # ------------------------------------------------------------------ llm

    def llm(
        self,
        messages: Sequence[JsonDict],
        *,
        provider: Optional[str] = None,
        model: Optional[str] = None,
        task_type: Optional[str] = None,
        sensitivity: Optional[str] = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        reasoning_effort: Optional[str] = None,
        routing_strategy: Optional[str] = None,
        **extra: Any,
    ) -> JsonDict:
        """Provider-normalised single LLM completion.

        Returns the ``result`` dict from the response envelope (containing
        ``text``, ``tokens_in``, ``tokens_out``, ``finish_reason``, etc.).
        """
        body: JsonDict = {"messages": list(messages)}
        for k, v in (
            ("provider", provider),
            ("model", model),
            ("task_type", task_type),
            ("sensitivity", sensitivity),
            ("max_tokens", max_tokens),
            ("temperature", temperature),
            ("reasoning_effort", reasoning_effort),
            ("routing_strategy", routing_strategy),
        ):
            if v is not None:
                body[k] = v
        body.update(extra)
        envelope = self._post("/v1/llm", body)
        return envelope.get("result") or envelope

    def llm_stream(
        self,
        messages: Sequence[JsonDict],
        *,
        provider: Optional[str] = None,
        model: Optional[str] = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        **extra: Any,
    ) -> Iterator[JsonDict]:
        """Streaming LLM completion. Yields normalised ``CompletionChunk`` dicts.

        SSE ``data: [DONE]`` ends the iterator.
        """
        body: JsonDict = {"messages": list(messages)}
        for k, v in (
            ("provider", provider),
            ("model", model),
            ("max_tokens", max_tokens),
            ("temperature", temperature),
        ):
            if v is not None:
                body[k] = v
        body.update(extra)
        with self._http.stream(
            "POST",
            "/v1/llm/stream",
            json=body,
            headers={"Accept": "text/event-stream"},
        ) as response:
            if response.status_code >= 400:
                response.read()
                raise self._raise_for_status(response)
            for raw in response.iter_lines():
                if not raw:
                    continue
                if raw.startswith("data:"):
                    payload = raw[5:].strip()
                    if payload == "[DONE]":
                        return
                    try:
                        yield json.loads(payload)
                    except json.JSONDecodeError:
                        continue

    def llm_batch(
        self,
        requests: Sequence[JsonDict],
        *,
        max_parallel: Optional[int] = None,
        batch_size: Optional[int] = None,
    ) -> list[JsonDict]:
        """Submit a list of full ``LLMSingleRequest`` dicts to ``/v1/llm/batch``.

        Returns one dict per input request (success or error), aligned to
        input order. Inspect ``status`` on each item.
        """
        if not requests:
            return []
        bs = _clamp_to_cap("llm", batch_size or _resolve_optimal("llm", None))
        mp = max_parallel or DEFAULT_MAX_PARALLEL["llm"]
        out: list[JsonDict] = []
        for chunk in _chunked(list(requests), bs):
            envelope = self._post(
                "/v1/llm/batch",
                {"requests": list(chunk), "max_parallel": mp},
            )
            out.extend(self._unpack_batch_envelope(envelope, lambda r: r, include_errors=True))
        return out

    # ------------------------------------------------------------------ retrieval

    def search(
        self,
        query: Union[str, Sequence[str]],
        *,
        provider: str = "google",
        mode: str = "search",
        top_n: int = 5,
        scrape: bool = True,
        max_parallel: Optional[int] = None,
        batch_size: Optional[int] = None,
    ) -> Union[JsonDict, list[JsonDict]]:
        """Search via SerpApi (``provider`` ∈ ``google``/``bing``;
        ``mode`` ∈ ``search``/``news``/``news_light``)."""
        path = f"/v1/serpapi/{provider}/{mode}"
        scalar = isinstance(query, str)
        if scalar:
            envelope = self._post(
                path, {"query": query, "top_n": top_n, "scrape": scrape}
            )
            return envelope.get("result") or envelope

        items = list(query)
        if not items:
            return []
        bs = _clamp_to_cap("search", batch_size or _resolve_optimal("search", None))
        mp = max_parallel or DEFAULT_MAX_PARALLEL["search"]
        out: list[JsonDict] = []
        for chunk in _chunked(items, bs):
            queries = [{"query": q, "top_n": top_n, "scrape": scrape} for q in chunk]
            envelope = self._post(
                f"{path}/batch", {"queries": queries, "max_parallel": mp}
            )
            out.extend(self._unpack_batch_envelope(envelope, lambda r: r))
        return out

    def fetch(
        self,
        url: Union[str, Sequence[str]],
        *,
        timeout_s: Optional[float] = None,
        max_parallel: Optional[int] = None,
        batch_size: Optional[int] = None,
    ) -> Union[JsonDict, list[JsonDict]]:
        """Fetch one or many URLs via ``/v1/fetch``."""
        scalar = isinstance(url, str)
        if scalar:
            body: JsonDict = {"url": url}
            if timeout_s is not None:
                body["timeout_s"] = timeout_s
            envelope = self._post("/v1/fetch", body)
            return envelope.get("result") or envelope

        items = list(url)
        if not items:
            return []
        bs = _clamp_to_cap("fetch", batch_size or _resolve_optimal("fetch", None))
        mp = max_parallel or DEFAULT_MAX_PARALLEL["fetch"]
        out: list[JsonDict] = []
        for chunk in _chunked(items, bs):
            payload = []
            for u in chunk:
                entry: JsonDict = {"url": u}
                if timeout_s is not None:
                    entry["timeout_s"] = timeout_s
                payload.append(entry)
            envelope = self._post(
                "/v1/fetch/batch",
                {"urls": payload, "max_parallel": mp},
            )
            out.extend(self._unpack_batch_envelope(envelope, lambda r: r))
        return out

    # ------------------------------------------------------------------ jobs

    def job_create(self, endpoint: str, payload: JsonDict) -> str:
        """``POST /v1/jobs`` — returns ``job_id``."""
        envelope = self._post("/v1/jobs", {"endpoint": endpoint, "input": payload})
        job_id = envelope.get("job_id") or (envelope.get("result") or {}).get("job_id")
        if not job_id:
            raise GPUHostError(f"job_create returned no job_id: {envelope!r}")
        return str(job_id)

    def job_get(self, job_id: str) -> JsonDict:
        """``GET /v1/jobs/{id}``."""
        return self._get(f"/v1/jobs/{job_id}")

    # ------------------------------------------------------------------ helpers

    @staticmethod
    def _unpack_batch_envelope(
        envelope: JsonDict,
        result_extractor: Any,
        *,
        include_errors: bool = False,
    ) -> list[Any]:
        """Flatten a T-018 batch envelope into a per-input-order list.

        ``result_extractor`` is a callable applied to each item's ``result``
        dict. When ``include_errors`` is True, error items are returned as
        ``{"_error": {...}}`` dicts so the caller can inspect failures.
        Otherwise, the first error raises :class:`GPUHostHTTPError`.
        """
        result = envelope.get("result") or {}
        items: Iterable[JsonDict] = result.get("items") or []
        items = sorted(items, key=lambda it: it.get("index", 0))
        out: list[Any] = []
        for it in items:
            if it.get("status") == "success":
                out.append(result_extractor(it.get("result") or {}))
            else:
                err = it.get("error") or {}
                if include_errors:
                    out.append({"_error": err, "index": it.get("index")})
                else:
                    raise GPUHostHTTPError(
                        status_code=400,
                        code=str(err.get("code") or "BatchItemError"),
                        message=str(err.get("message") or "batch item failed"),
                        retryable=err.get("retryable"),
                        retry_after_ms=err.get("retry_after_ms"),
                        request_id=envelope.get("request_id"),
                        body=envelope,
                    )
        return out
