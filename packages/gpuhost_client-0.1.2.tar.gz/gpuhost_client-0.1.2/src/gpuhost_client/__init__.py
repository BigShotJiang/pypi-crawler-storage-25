"""Python client for the ComputeGateway GPU Model Host.

Quickstart:

    from gpuhost_client import GPUHostClient

    client = GPUHostClient(
        host="https://",
        api_key="...",
    )

    # Single call (latency-optimised path)
    vec = client.embed("hello world")

    # Batch call (auto-chunked at the per-endpoint optimal batch size)
    vecs = client.embed(["a", "b", "c", ...])

    # Translate, rerank, entities, OCR, LLM, search, fetch all follow the
    # same scalar-vs-list pattern. See README for the full surface.
"""

from __future__ import annotations

from .client import GPUHostClient
from .errors import (
    GPUHostError,
    GPUHostHTTPError,
    GPUHostQuotaError,
    GPUHostTimeoutError,
)
from .recommended import OPTIMAL_BATCH_SIZE, SERVER_BATCH_CAP

__all__ = [
    "GPUHostClient",
    "GPUHostError",
    "GPUHostHTTPError",
    "GPUHostQuotaError",
    "GPUHostTimeoutError",
    "OPTIMAL_BATCH_SIZE",
    "SERVER_BATCH_CAP",
    "__version__",
]

__version__ = "0.1.2"
