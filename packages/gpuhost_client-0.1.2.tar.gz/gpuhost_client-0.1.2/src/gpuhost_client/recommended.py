"""Recommended (sweet-spot) and server-cap batch sizes per endpoint.

Sourced from the production T4 sweep at rev ``ca-nas-prd-wus3--0000078``
(``docs/benchmarks/2026-05-10-rev78-extended.json``). Values represent the
**balanced** point — lowest p95 within ~90 % of peak items/s — and are safe
defaults for interactive callers.

Steady-state bulk callers can override per-call by passing ``batch_size=...``
to any client method.
"""

from __future__ import annotations

# Per-endpoint optimal batch size. Keys are stable identifiers; aliases
# (e.g. ``embed-mpnet`` for ``embed-mpnet-legacy``) resolve via the lookup
# helper in :mod:`gpuhost_client.client`.
OPTIMAL_BATCH_SIZE: dict[str, int] = {
    # Embeddings
    "embed-baseline": 128,        # Qwen3-Embedding-0.6B — flat past bs=256
    "embed-mpnet": 512,           # all-mpnet-base-v2 — flat past bs=512
    "embed-mpnet-legacy": 512,
    # Entities
    "entity-gliner": 128,         # at server cap; throughput peak
    # Rerank — cross-encoder, linear cost; do NOT exceed cap
    "rerank": 32,
    "rerank-bge-m3": 32,
    # Translate — best ROI of any endpoint (39× over bs=1)
    "translate": 256,
    # OCR — barely benefits from batching; small bs keeps p95 sane
    "ocr": 8,
    "ocr-paddle": 8,
    "ocr-easy-legacy": 8,
    # LLM — pass-through to upstream provider; keep small to bound $$
    "llm": 32,
    # Search/fetch — I/O-bound; concurrency matters more than batch size
    "search": 16,
    "fetch": 8,
}

# Server-side caps (T-037/T-038, default settings). Requests above these
# values are rejected with HTTP 400. Used by the client only as a safety
# clamp when a caller passes ``batch_size`` explicitly.
SERVER_BATCH_CAP: dict[str, int] = {
    "embed": 8192,
    "entities": 128,
    "rerank": 32,
    "translate": 512,
    "ocr": 16,
    "llm": 128,
    "search": 128,
    "fetch": 32,
}

# Default per-route ``max_parallel`` for batch alias routes. GPU-bound
# routes saturate at single-flight; I/O-bound routes benefit from
# raising this up to ``batch_max_parallel_cap`` (32).
DEFAULT_MAX_PARALLEL: dict[str, int] = {
    "embed": 1,
    "entities": 1,
    "rerank": 1,
    "translate": 1,
    "ocr": 1,
    "llm": 4,
    "search": 8,
    "fetch": 8,
}
