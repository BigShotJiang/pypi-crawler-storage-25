"""Exception hierarchy for the GPU Model Host client."""

from __future__ import annotations

from typing import Any, Optional


class GPUHostError(Exception):
    """Base class for all client-side errors."""


class GPUHostHTTPError(GPUHostError):
    """Raised when the server returns a non-2xx response.

    Attributes:
        status_code: HTTP status code from the gateway.
        code: ``error.code`` from the response envelope (e.g. ``BadRequest``).
        message: ``error.message`` from the response envelope.
        retryable: ``error.retryable`` from the response envelope, if present.
        retry_after_ms: ``error.retry_after_ms`` from the response envelope.
        request_id: ``request_id`` from the response envelope, if present.
        body: Raw decoded JSON body (best-effort).
    """

    def __init__(
        self,
        status_code: int,
        code: str = "Unknown",
        message: str = "",
        *,
        retryable: Optional[bool] = None,
        retry_after_ms: Optional[int] = None,
        request_id: Optional[str] = None,
        body: Optional[Any] = None,
    ) -> None:
        super().__init__(f"[{status_code} {code}] {message}")
        self.status_code = status_code
        self.code = code
        self.message = message
        self.retryable = retryable
        self.retry_after_ms = retry_after_ms
        self.request_id = request_id
        self.body = body


class GPUHostQuotaError(GPUHostHTTPError):
    """Raised on HTTP 429 / QuotaExceeded."""


class GPUHostTimeoutError(GPUHostError):
    """Raised when an HTTP request times out at the transport layer."""
