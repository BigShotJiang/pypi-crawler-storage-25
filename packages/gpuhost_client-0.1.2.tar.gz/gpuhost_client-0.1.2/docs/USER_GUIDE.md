# gpuhost-client — User Guide

A complete walkthrough of the Python client for the **ComputeGateway GPU
Model Host**: installation, authentication, every endpoint, batching
strategy, error handling, and operational patterns.

The README has the elevator pitch; this guide is the reference.

---

## Table of contents

1. [Install](#1-install)
2. [Connect & authenticate](#2-connect--authenticate)
3. [Single-call vs batch — one method, two shapes](#3-single-call-vs-batch--one-method-two-shapes)
4. [Endpoints](#4-endpoints)
   1. [Embeddings — `embed()`](#41-embeddings--embed)
   2. [Entities — `entities()`](#42-entities--entities)
   3. [Translate — `translate()`](#43-translate--translate)
   4. [Rerank — `rerank()`](#44-rerank--rerank)
   5. [OCR — `ocr()`](#45-ocr--ocr)
   6. [LLM — `llm()`, `llm_stream()`, `llm_batch()`](#46-llm--llm-llm_stream-llm_batch)
   7. [Search — `search()`](#47-search--search)
   8. [Fetch — `fetch()`](#48-fetch--fetch)
   9. [Jobs — `job_create()`, `job_get()`](#49-jobs--job_create-job_get)
   10. [Operations — `health()`, `ready()`, `models()`, `admin_limits()`](#410-operations--health-ready-models-admin_limits)
5. [Recommended batch sizes (sweet spots)](#5-recommended-batch-sizes-sweet-spots)
6. [Error handling](#6-error-handling)
7. [Timeouts & retries](#7-timeouts--retries)
8. [Connection pooling & concurrency](#8-connection-pooling--concurrency)
9. [Patterns & recipes](#9-patterns--recipes)
10. [Versioning & compatibility](#10-versioning--compatibility)
11. [FAQ / troubleshooting](#11-faq--troubleshooting)

---

## 1. Install

```bash
pip install gpuhost-client
```

Requires Python **3.9+**. The only runtime dependency is `httpx>=0.27`.

Optional extras:

```bash
pip install "gpuhost-client[dev]"     # pytest, ruff, mypy, pytest-httpx
```

---

## 2. Connect & authenticate

The client takes a base URL and an API key. Both are required.

```python
from gpuhost_client import GPUHostClient

client = GPUHostClient(
    host="https://ca-nas-prd-wus3.example.westus3.azurecontainerapps.io",
    api_key="<your-key>",
)
```

Best practice: **never hard-code the key**. Read from env / Key Vault.

```python
import os
client = GPUHostClient(
    host=os.environ["GPUHOST_URL"],
    api_key=os.environ["GPUHOST_API_KEY"],
)
```

The client owns an internal `httpx.Client` (connection-pooled). Use it as
a context manager so the pool is released:

```python
with GPUHostClient(host=..., api_key=...) as client:
    print(client.health())
```

Or call `client.close()` explicitly.

### Constructor options

| Param         | Default     | Notes |
|---------------|------------|-------|
| `host`        | (required) | Base URL; trailing `/` stripped. |
| `api_key`     | (required) | Sent as `Authorization: Bearer <key>`. |
| `timeout`     | `60.0`     | Per-request timeout in seconds (transport-level). |
| `max_retries` | `0`        | Best-effort retry on `Timeout` / `ProviderUnavailable` / `ModelLoadRejected`. Defaults to no retry — your job to orchestrate. |
| `user_agent`  | `gpuhost-client/<ver>` | Override the User-Agent header. |
| `verify`      | `True`     | TLS verification. Pass a path to a custom CA bundle if needed. |

---

## 3. Single-call vs batch — one method, two shapes

**Every inference method accepts either a scalar or a sequence.**

| Method            | Scalar input → returns       | List input → returns                    |
|-------------------|------------------------------|----------------------------------------|
| `embed(texts)`    | `list[float]` (one vector)   | `list[list[float]]` aligned to input    |
| `entities(text)`  | `list[entity-dict]`          | `list[list[entity-dict]]`               |
| `translate(text)` | `str`                        | `list[str]`                             |
| `ocr(images)`     | `dict` (one OCR result)      | `list[dict]`                            |
| `search(query)`   | `dict`                       | `list[dict]`                            |
| `fetch(url)`      | `dict`                       | `list[dict]`                            |
| `rerank(...)`     | (always single-call)         | n/a — caller controls `documents`       |
| `llm(messages)`   | (always single-call)         | use `llm_batch(...)` for fan-out        |

When you pass a **list**, the client:

1. **Auto-chunks** into requests of `OPTIMAL_BATCH_SIZE[endpoint]` items
   (you can override per call via `batch_size=...`).
2. Calls the dedicated `/v1/<endpoint>/batch` alias — guaranteed batch
   envelope, per-item indexing.
3. **Reassembles** results in input order before returning.
4. Raises `GPUHostHTTPError` on the first failed item, **unless** you opt
   in to error inclusion (only `llm_batch()` does this by default).

When you pass a **scalar**, the client calls the single-call route and
returns the unwrapped result — no batch envelope, no list wrapping.

---

## 4. Endpoints

### 4.1 Embeddings — `embed()`

Generate vector embeddings.

```python
# Single text → single vector
vec = client.embed("hello world")
# → [0.013, -0.421, ...]

# Batch — auto-chunked at bs=128 (default for embed-baseline)
vectors = client.embed(["a", "b", "c", ...])

# Use the legacy mpnet model
vectors = client.embed(texts, model_id="embed-mpnet-legacy")

# Override the chunk size for steady-state bulk pipelines
vectors = client.embed(big_corpus, batch_size=256)
```

| Parameter   | Default          | Description |
|-------------|------------------|-------------|
| `texts`     | required         | `str` or `Sequence[str]`. |
| `model_id`  | `embed-baseline` | One of `embed-baseline` (Qwen3, 1024d), `embed-mpnet-legacy` (768d), or any slot configured by ops via `GPUHOST_EMBED_MODELS_JSON`. |
| `batch_size`| optimal per model | Override per-request chunk size. Clamped to `embed_max_batch=8192`. |

### 4.2 Entities — `entities()`

Extract typed entity spans from text.

```python
# Single text → list of entity dicts
ents = client.entities("Acme Corp acquired Globex on 2025-01-15.")
# → [{"text": "Acme Corp", "type": "organization", "start": 0, "end": 9, "confidence": 0.91}, ...]

# Zero-shot labels (only for entity-gliner)
ents = client.entities(
    "Take 10 mg ibuprofen.",
    labels=["drug", "dose"],
    threshold=0.4,
)

# Batch — list of texts
all_ents = client.entities(["text 1", "text 2", "text 3"])
# → [[ents-for-1], [ents-for-2], [ents-for-3]]
```

| Parameter      | Default          | Description |
|----------------|------------------|-------------|
| `text`         | required         | `str` or `Sequence[str]`. |
| `model_id`     | `entity-gliner`  | `entity-gliner` (zero-shot, GPU) or `entity-baseline` (regex/spaCy, CPU). |
| `labels`       | None             | Zero-shot label list (1..32 entries, only valid for `entity-gliner`). |
| `threshold`    | None             | Minimum confidence (0.0–1.0). Ignored by fixed-label adapters. |
| `batch_size`   | 128              | Per-request chunk; cap = 128 (server). |
| `max_parallel` | 1                | Server-side fan-out. GPU saturates at 1; leave as default. |

### 4.3 Translate — `translate()`

Translate to English. Source is one of `zh`, `ar`, `hi`, `ru`.

```python
# Single
en = client.translate("صباح الخير", src="ar")
# → "Good morning"

# Batch — same source language for all items
ens = client.translate(many_arabic_sentences, src="ar")
# → list[str] aligned to input

# Override for steady-state (peak throughput at bs=512)
ens = client.translate(corpus, src="zh", batch_size=512, max_parallel=4)
```

| Parameter      | Default | Description |
|----------------|---------|-------------|
| `text`         | required | `str` or `Sequence[str]`. |
| `src`          | required | `zh` / `ar` / `hi` / `ru`. |
| `tgt`          | `"en"`  | Currently only English is supported. |
| `batch_size`   | 256     | Per-request chunk; server cap = 512. |
| `max_parallel` | 1       | GPU-bound — leave at 1 unless throughput beats latency. |

**Why translate is the highest-ROI endpoint:** ~30–39× speed-up over
`bs=1` for only ~6–8× p95 cost. Always batch translate if you have ≥ 32
sentences ready.

### 4.4 Rerank — `rerank()`

Cross-encoder reranking — score `documents` against `query`.

```python
ranked = client.rerank(
    query="What is RAG?",
    documents=[doc1, doc2, ..., doc32],
    top_k=5,
    return_documents=True,
)
# → [{"index": 11, "score": 0.94, "document": "..."}, ...] (sorted desc)
```

| Parameter          | Default          | Description |
|--------------------|------------------|-------------|
| `query`            | required         | The question/query string. |
| `documents`        | required         | List of candidate strings. **Hard cap = 32** server-side (T-038). |
| `top_k`            | None (= all)     | Truncate output to top-K. |
| `model_id`         | `rerank-bge-m3`  | Reranker model slot. |
| `return_documents` | `False`          | Include the document text in each result item. |

**Critical:** rerank is a cross-encoder — cost is **linear** in
`len(documents)` with no plateau. Going above 32 makes p95 grow into
seconds. If you have more candidates, do multiple rerank calls and merge,
or pre-filter with embeddings first.

`results[].index` is the **input-order** position of the document, not
the rank. Sort order is descending by `score`.

### 4.5 OCR — `ocr()`

Extract text from images.

```python
# Single image — pass a path
result = client.ocr("./scan.png")
# → {"text": "...", "boxes": [...], "confidence": 0.87}

# Or raw bytes
with open("scan.png", "rb") as f:
    result = client.ocr(f.read())

# Or pre-encoded base64
result = client.ocr(b64_string)

# Batch — list of any of the above
results = client.ocr(["a.png", img_bytes, b64_str])
```

| Parameter         | Default       | Description |
|-------------------|---------------|-------------|
| `images`          | required      | One of `bytes`, path (`str`/`Path`), or base64 `str`. List of any combination for batch. |
| `min_confidence`  | None          | Drop spans below this confidence. |
| `model_id`        | server default | `ocr-paddle` (PP-OCRv5) or `ocr-easy-legacy` (EasyOCR). |
| `batch_size`      | 8             | Per-request chunk; server cap = 16. |
| `max_parallel`    | 1             | GPU-bound. |

**Note:** OCR barely benefits from batching (1.1–1.4× over `bs=1`).
Per-image GPU work dominates per-request overhead. Use `bs=1` whenever
single-image latency matters; only batch when wall-clock matters more
than tail latency.

MIME type is sniffed from magic bytes (PNG/JPEG/GIF/WebP).

### 4.6 LLM — `llm()`, `llm_stream()`, `llm_batch()`

Provider-normalised completions across Azure OpenAI / OpenAI / Anthropic.

```python
# Single completion
out = client.llm(
    [{"role": "user", "content": "Summarise this in one sentence: ..."}],
    provider="auto",       # let the server choose by policy
    task_type="summarization",
    sensitivity="internal",
    max_tokens=200,
    temperature=0.2,
)
# → {"text": "...", "tokens_in": 412, "tokens_out": 38, "finish_reason": "stop", "provider": "azure_openai", "model": "gpt-4o-mini"}

# Streaming
for chunk in client.llm_stream(
    [{"role": "user", "content": "Tell me a joke"}],
    provider="openai",
    model="gpt-4o-mini",
):
    print(chunk.get("text", ""), end="", flush=True)

# Batch — fan out N independent completions
results = client.llm_batch([
    {"messages": [{"role": "user", "content": "translate: hi"}], "model": "gpt-4o-mini"},
    {"messages": [{"role": "user", "content": "translate: hello"}], "model": "gpt-4o-mini"},
])
# → list of {"text", "tokens_in", ...} OR {"_error": {...}, "index": N}
```

| Parameter            | Default | Description |
|----------------------|---------|-------------|
| `messages`           | required | OpenAI-style chat history. |
| `provider`           | None / `auto` | `auto` enables policy routing + failover; or pin to `azure_openai` / `openai` / `anthropic`. |
| `model`              | None    | Pin a specific model id. |
| `task_type`          | None    | `classification` / `extraction` / `summarization` / `reasoning` / `coding` / `general`. |
| `sensitivity`        | None    | `public` / `internal` / `pii` / `secret` — may restrict provider choice. |
| `max_tokens`         | None    | Hard cap on output tokens. |
| `temperature`        | None    | Sampling temperature. |
| `reasoning_effort`   | None    | `minimal` / `low` / `medium` / `high` — forwarded only to providers that support it. |
| `routing_strategy`   | None    | `auto` / `task_route` / `cost_cascade` / `ordered_failover` / `map_reduce` / `parallel_ensemble`. |
| `**extra`            | —       | Any extra fields forwarded to the request body. |

**Cost warning:** the gateway accepts up to `llm_batch_max_items=128` per
batch — but each item is a paid upstream call. One bad batch can cost
real money. Use per-tenant quotas before scaling callers.

`llm_batch()` returns errors as `{"_error": {...}, "index": N}` instead
of raising, so you can salvage successful items in a partially-failed
batch.

### 4.7 Search — `search()`

SerpApi-backed web search.

```python
# Single query, Google web
results = client.search("ComputeGateway gpu host", top_n=5)
# → {"query": "...", "results": [{"rank": 1, "url": "...", "title": "...", "snippet": "...", "scrape": {...}}, ...]}

# News mode
news = client.search("Azure AI", provider="google", mode="news", top_n=10)

# Batch — list of queries
all_results = client.search(
    ["query 1", "query 2", "query 3"],
    provider="bing",
    mode="search",
    top_n=5,
    max_parallel=8,
)
```

| Parameter      | Default    | Description |
|----------------|------------|-------------|
| `query`        | required   | `str` or `Sequence[str]`. |
| `provider`     | `"google"` | `google` or `bing`. |
| `mode`         | `"search"` | `search`, `news`, or `news_light` (Google only). |
| `top_n`        | `5`        | Capped at 10 server-side. |
| `scrape`       | `True`     | Whether to attach scraped markdown per result (Playwright). |
| `batch_size`   | 16         | Per-request chunk; server cap = 128. |
| `max_parallel` | 8          | I/O-bound — raise this (up to 32) to actually help. |

**Cost warning:** SerpApi is billed per query. A batch of 128 queries
can drain the monthly quota in minutes. Apply per-tenant rate limits.

### 4.8 Fetch — `fetch()`

Render a URL via headless browser, return markdown.

```python
# Single URL
page = client.fetch("https://example.com")
# → {"url": "...", "success": true, "content": "...", "title": "...", "text_length": 1234}

# Batch — list of URLs
pages = client.fetch(
    ["https://a.com", "https://b.com", "https://c.com"],
    timeout_s=30,
    max_parallel=8,
)
```

| Parameter      | Default    | Description |
|----------------|------------|-------------|
| `url`          | required   | `str` or `Sequence[str]`. Must be `http://` or `https://`. |
| `timeout_s`    | None (= 20) | Per-URL timeout. |
| `batch_size`   | 8          | Per-request chunk; server cap = 32. |
| `max_parallel` | 8          | I/O-bound — raise this for parallel fetching. |

Per-URL failures yield `success=false` with an `error_code` —
`Timeout` / `HTTP_4XX` / `HTTP_5XX` / `BLOCKED` / `PARSE_ERROR` /
`EMPTY_CONTENT` / `ScraperUnavailable` / `UNKNOWN`. **HTTP status is
always 200** when the gateway itself worked — inspect `success` per item.

For richer fetch (raw HTML, metadata, links, CSS extraction, screenshot)
the gateway exposes `/v1/fetch/html`, `/v1/fetch/metadata`, etc. These
are **not** wrapped in the v0.1 client — call them via `client._post(...)`
or open an issue.

### 4.9 Jobs — `job_create()`, `job_get()`

Long-running async jobs (large OCR, big LLM workflows).

```python
job_id = client.job_create("ocr", {"image_b64": "...", "mime_type": "image/pdf"})
# → "job_abc123"

import time
while True:
    status = client.job_get(job_id)
    if status["status"] in ("done", "failed"):
        break
    time.sleep(2)

print(status["result"])
```

### 4.10 Operations — `health()`, `ready()`, `models()`, `admin_limits()`

```python
client.health()        # GET /health  → liveness
client.ready()         # GET /ready   → readiness (model warmup state)
client.models()        # GET /models  → registry snapshot + LLM providers
client.admin_limits()  # GET /v1/admin/limits → current caps & quotas
```

Use `admin_limits()` to discover the current server-side caps without
guessing — useful when configuring callers across environments.

---

## 5. Recommended batch sizes (sweet spots)

Defaults are sourced from the production T4 sweep at rev
`ca-nas-prd-wus3--0000078`. Each value is the **balanced point** —
lowest p95 within ~90 % of peak items/s — safe for interactive callers.

| Endpoint / model           | Default `batch_size` | Speed-up over `bs=1` | Latency cost |
|---------------------------|---------------------:|---------------------:|--------------:|
| `embed-baseline` (Qwen3)  | **128**              | 23.9 ×              | 5.2 ×         |
| `embed-mpnet-legacy`      | **512**              | 22.3 ×              | 19 ×          |
| `entity-gliner`           | **128**              | 8.6 ×               | 14.7 ×        |
| `rerank` (bge-v2-m3)      | **32** (cap)         | 5.6 ×               | 5.6 ×         |
| `translate` (any pair)    | **256**              | ≈34 ×               | 6.4–8.2 ×     |
| `ocr-paddle`              | **8**                | 1.4 ×               | 5.6 ×         |
| `ocr-easy-legacy`         | **8**                | 1.1 ×               | 7.0 ×         |

The constants are exposed for inspection and overrides:

```python
from gpuhost_client import OPTIMAL_BATCH_SIZE, SERVER_BATCH_CAP

print(OPTIMAL_BATCH_SIZE["embed-baseline"])   # 128
print(SERVER_BATCH_CAP["rerank"])             # 32
```

`SERVER_BATCH_CAP` reflects the gateway's hard-rejection thresholds
(T-037/T-038). Anything above the cap is rejected with HTTP 400 — the
client clamps user-supplied `batch_size` to the cap as a safety net, but
the gateway is the source of truth.

### Overriding defaults

```python
# Steady-state bulk job — push to peak throughput
vecs = client.embed(big_corpus, batch_size=256)

# Latency-sensitive interactive call — force bs=1
vec  = client.embed(["one item"], batch_size=1)  # equivalent to scalar form
```

### Rules of thumb

1. **Batch when you have ≥ 32 items in hand** — overhead dominates
   below that for most endpoints.
2. **Translate is the single best ROI** — 30–39 × items/s for only
   6–8 × p95.
3. **Rerank cost is linear, no plateau** — never exceed `bs=32`.
4. **OCR barely benefits from batching** (1.1–1.4 ×) — use `bs=1` if
   single-image latency matters.
5. **`max_parallel` ≠ batch_size.** GPU-bound routes (`embed`,
   `entities`, `rerank`, `translate`, `ocr`) saturate at single-flight;
   leave `max_parallel=1`. I/O-bound routes (`search`, `fetch`) benefit
   from raising it to 8–32.

---

## 6. Error handling

All errors derive from `GPUHostError`:

```python
from gpuhost_client import (
    GPUHostError,
    GPUHostHTTPError,
    GPUHostQuotaError,
    GPUHostTimeoutError,
)
```

| Class                  | Raised on |
|------------------------|-----------|
| `GPUHostHTTPError`     | Any non-2xx response. |
| `GPUHostQuotaError`    | HTTP 429 specifically (subclass of `HTTPError`). |
| `GPUHostTimeoutError`  | Transport-level timeout (no response received). |
| `GPUHostError`         | Catch-all base class. |

### Inspecting an HTTP error

```python
try:
    out = client.embed(texts)
except GPUHostQuotaError as e:
    sleep(e.retry_after_ms / 1000 if e.retry_after_ms else 60)
except GPUHostHTTPError as e:
    print(e.status_code)     # 400
    print(e.code)            # "BadRequest"
    print(e.message)         # "texts must be non-empty"
    print(e.retryable)       # False
    print(e.request_id)      # "req-abc123" — quote in support tickets
    print(e.body)            # raw decoded JSON envelope
```

### Common error codes

| Code                | HTTP | Meaning |
|---------------------|------|---------|
| `BadRequest`        | 400  | Schema violation, oversized input, exceeded `*_batch_max_items`. |
| `Unauthorized`      | 401  | Missing/invalid API key. |
| `Forbidden`         | 403  | Key valid but lacks the required scope (e.g. `translate`). |
| `ModelNotFound`     | 404  | Unknown `model_id`. |
| `QuotaExceeded`     | 429  | Caller exceeded quota. Wait `retry_after_ms`. |
| `ModelLoadRejected` | 503  | VRAM budget prevented model load. Retryable. |
| `ProviderUnavailable`| 503 | Upstream LLM provider failed / circuit open. |
| `Timeout`           | 503  | Operation exceeded server timeout. |

### Batch errors

In a list/batch call, the client raises `GPUHostHTTPError` on the **first
failed item** by default. Use `llm_batch()` or call the batch route
directly if you need partial-success semantics.

---

## 7. Timeouts & retries

The client passes the `timeout` constructor arg straight to `httpx`.
Defaults to **60 s** per request.

```python
# Long-running OCR / LLM
client = GPUHostClient(host=..., api_key=..., timeout=300)

# Per-call override
result = client._request("POST", "/v1/embed", json_body={...}, timeout=10)
```

### Built-in retry

`max_retries` enables best-effort retries on `Timeout`,
`ProviderUnavailable`, and `ModelLoadRejected` responses (errors with
`retryable=True`):

```python
client = GPUHostClient(host=..., api_key=..., max_retries=2)
```

Retry is **simple immediate** — no backoff. For production, wrap your
call sites in a proper retry library (`tenacity`, `backoff`) for
exponential-jitter control.

```python
from tenacity import retry, stop_after_attempt, wait_exponential_jitter
from gpuhost_client import GPUHostQuotaError, GPUHostHTTPError

@retry(
    stop=stop_after_attempt(5),
    wait=wait_exponential_jitter(initial=1, max=30),
    retry=lambda exc: isinstance(exc, GPUHostQuotaError) or
                      (isinstance(exc, GPUHostHTTPError) and exc.retryable),
)
def embed_with_retry(texts):
    return client.embed(texts)
```

---

## 8. Connection pooling & concurrency

The client owns one `httpx.Client` instance with connection pooling.
**Do not create a client per request** — that defeats keep-alive and
adds TLS handshake cost.

### Recommended patterns

**One process, many sequential calls:** create one client at startup,
reuse it.

```python
client = GPUHostClient(host=..., api_key=...)  # module-level
def handler(req):
    return client.embed(req.text)
```

**Multi-threaded workers:** `httpx.Client` is thread-safe for concurrent
requests. One client per process is fine.

**Async (asyncio):** v0.1 is sync only. Run blocking calls in a thread
pool (`asyncio.to_thread`) for now. An async sibling is on the roadmap.

```python
import asyncio
async def embed_async(texts):
    return await asyncio.to_thread(client.embed, texts)
```

---

## 9. Patterns & recipes

### Embed a large corpus efficiently

```python
# Auto-chunked — client handles the split
all_vecs = client.embed(corpus_of_50k_strings)

# Or push to peak throughput for a bulk pipeline
all_vecs = client.embed(corpus, model_id="embed-mpnet-legacy", batch_size=512)
```

### Two-stage retrieval (embed → rerank)

```python
# 1. Embed query + corpus, find top 100 by cosine similarity (your code)
q_vec = client.embed(query)
candidates = top_100_by_cosine(q_vec, corpus)

# 2. Rerank top 100 in chunks of 32 (the rerank cap)
ranked: list[dict] = []
for chunk_start in range(0, len(candidates), 32):
    chunk = candidates[chunk_start:chunk_start + 32]
    chunk_results = client.rerank(query=query, documents=chunk, return_documents=True)
    # remap chunk-local index back to corpus index
    for r in chunk_results:
        r["corpus_index"] = chunk_start + r["index"]
    ranked.extend(chunk_results)

# 3. Final sort by score
ranked.sort(key=lambda r: r["score"], reverse=True)
top_5 = ranked[:5]
```

### LLM with cost cascade + Azure-only PII routing

```python
out = client.llm(
    messages=[{"role": "user", "content": user_question}],
    routing_strategy="cost_cascade",
    sensitivity="pii",        # forces Azure-only (per gateway policy)
    max_tokens=500,
    max_cost_usd=0.05,        # gateway rejects if estimated cost exceeds
)
```

### Search → fetch pipeline

```python
hits = client.search("retrieval augmented generation 2026", top_n=10, scrape=False)
urls = [h["url"] for h in hits["results"]]
pages = client.fetch(urls, max_parallel=8)
docs = [p["content"] for p in pages if p["success"]]
```

### Inspecting current server caps

```python
limits = client.admin_limits()
print(limits["rerank_batch_max_items"])     # → 32
print(limits["translate_batch_max_items"])  # → 512
```

---

## 10. Versioning & compatibility

`gpuhost-client` follows **SemVer**:

- **Major** bumps — backwards-incompatible API changes (renamed methods,
  changed return shapes).
- **Minor** bumps — new methods, new parameters, new endpoints.
- **Patch** bumps — bug fixes, doc updates, dependency relaxations.

| Client version | GPU Model Host minimum rev | API surface |
|----------------|----------------------------|-------------|
| `0.1.x`        | rev ≥ 76                   | `/v1/...` (T-037 caps + T-038 rerank cap) |

Pin to a minor range in your project:

```toml
# pyproject.toml
dependencies = [
    "gpuhost-client>=0.1,<0.2",
]
```

---

## 11. FAQ / troubleshooting

**Q: I get `GPUHostHTTPError(400, BadRequest, "X exceeds Y")`.**
A: You exceeded a server-side cap. Check `client.admin_limits()` for the
current caps. Most likely you passed `len(documents) > 32` to `rerank()`
or `len(texts) > 512` to `translate()` (single batch).

**Q: I get `403 Forbidden` even though my key works elsewhere.**
A: Your API key lacks the **scope** for this endpoint. Each endpoint
requires a specific scope (`embed`, `entities`, `translate`, `rerank`,
`ocr`, `llm`, `serpapi`, `fetch`). Ask ops to widen your key's scope
list.

**Q: My streaming LLM call hangs.**
A: Check that the upstream provider supports streaming (most do).
Increase `timeout=` on the client. The server emits SSE keep-alive pings
that the client iterates through transparently.

**Q: How do I send custom headers (e.g. `x-request-id`)?**
A: v0.1 doesn't expose per-call headers. The server auto-generates a
`request_id` and returns it in the response envelope (and on every
`GPUHostHTTPError`). For correlation, set a per-process header on the
underlying `httpx.Client`:

```python
client = GPUHostClient(host=..., api_key=...)
client._http.headers["x-request-id"] = my_correlation_id
```

(`_http` is intentionally not part of the public API — this is a stopgap
until v0.2.)

**Q: Connection pool exhausted under high concurrency.**
A: Increase the pool limits via the underlying `httpx.Client`:

```python
import httpx
client = GPUHostClient(host=..., api_key=...)
client._http._transport = httpx.HTTPTransport(
    limits=httpx.Limits(max_connections=100, max_keepalive_connections=20),
)
```

**Q: Where do I report bugs?**
A: https://github.com/computegateway/gpuhost-client/issues — include the
`request_id` from the failing response and the client version
(`gpuhost_client.__version__`).

---

## License

MIT. See [LICENSE](../LICENSE).
