"""autoplay-sdk — real-time event streaming client for Autoplay connectors.

Receives structured UI actions and LLM session summaries from the Autoplay
event connector via SSE (Server-Sent Events) or webhook POSTs, then routes
them into your RAG pipeline, vector store, or agent context.

Components
----------
Clients (choose one):
    ConnectorClient       — sync SSE client; separate reader + worker threads;
                            safe for blocking callbacks.
    AsyncConnectorClient  — async SSE client; per-session semaphore isolation;
                            use ``async def`` callbacks for any I/O.
    WebhookReceiver       — push mode; HMAC-SHA256 verification + typed dispatch.

Typed models:
    ActionsPayload        — batch of UI actions from a session.
    SummaryPayload        — LLM-generated session summary.

Pipeline components (mix and match):
    EventBuffer           — in-memory pull buffer; thread-safe; dev/testing.
    RedisEventBuffer      — Redis-backed sliding-window buffer; async; production.
    SessionSummarizer     — sync rolling LLM summarizer; compact context window.
    AsyncSessionSummarizer— async version; per-session workers; ordering guarantee.
    ContextStore          — sync store; call ``enrich(session_id, query)`` at query time.
    AsyncContextStore     — async write side; sync ``enrich()`` safe from any coroutine.
    RagPipeline           — sync embed + upsert wired to client callbacks.
    AsyncRagPipeline      — async embed + upsert; awaits your embedding and vector store.
    AsyncAgentContextWriter — push raw actions; overwrite with LLM summary.

Chatbot destination building blocks:
    ConversationWriter    — typed Protocol for all writer destinations.
    BaseChatbotWriter     — base class: pre-link buffer, post-link debounce,
                            note formatting.  Subclass and implement
                            ``_post_note`` / ``_redact_part`` to build a custom
                            chatbot backend in minutes.

Observability:
    SdkMetricsHook        — implement to receive Prometheus/Datadog/OTEL counters.

See the project README on PyPI or GitHub for the full architecture diagram,
quickstart examples, sync-vs-async decision guide, and performance/locking
reference: https://github.com/Autoplay-AI/real-time-poc/tree/main/later-rho-event-connector/src/customer_sdk#readme
"""

from autoplay_sdk.async_client import AsyncConnectorClient
from autoplay_sdk.buffer import BufferBackend, EventBuffer, RedisEventBuffer
from autoplay_sdk.chatbot import BaseChatbotWriter, ConversationWriter
from autoplay_sdk.client import ConnectorClient
from autoplay_sdk.context_store import AsyncContextStore, ContextStore
from autoplay_sdk.exceptions import (
    SdkBufferFullError,
    SdkConfigError,
    SdkError,
    SdkUpstreamError,
)
from autoplay_sdk.metrics import SdkMetricsHook
from autoplay_sdk.models import ActionsPayload, AnyPayload, SlimAction, SummaryPayload
from autoplay_sdk.rag import AsyncRagPipeline, RagPipeline
from autoplay_sdk.summarizer import (
    DEFAULT_PROMPT,
    AsyncSessionSummarizer,
    SessionSummarizer,
)
from autoplay_sdk.agent_context import AsyncAgentContextWriter
from autoplay_sdk.webhook_receiver import WebhookReceiver

__all__ = [
    # Clients
    "ConnectorClient",
    "AsyncConnectorClient",
    # Typed models
    "ActionsPayload",
    "SummaryPayload",
    "SlimAction",
    "AnyPayload",
    # Buffer
    "EventBuffer",
    "RedisEventBuffer",
    "BufferBackend",
    # Context store (query-time RAG enrichment)
    "ContextStore",
    "AsyncContextStore",
    # RAG pipeline (upsert flow)
    "RagPipeline",
    "AsyncRagPipeline",
    # Summarizer
    "SessionSummarizer",
    "AsyncSessionSummarizer",
    "DEFAULT_PROMPT",
    # Agent context writer (push model — real-time events → agent destination)
    "AsyncAgentContextWriter",
    # Chatbot destination building blocks
    "ConversationWriter",
    "BaseChatbotWriter",
    # Push webhook receiver
    "WebhookReceiver",
    # Observability
    "SdkMetricsHook",
    # Exceptions
    "SdkError",
    "SdkConfigError",
    "SdkUpstreamError",
    "SdkBufferFullError",
    # Version
    "__version__",
]
__version__ = "0.5.0"
