from django.test import TestCase, override_settings


class TestSettings(TestCase):
    def test_drf_setting_import(self):
        """测试DRF配置导入"""
        from fly_djangox.settings import drf_setting

        # 验证配置模块可以导入
        self.assertIsNotNone(drf_setting)

    def test_cross_domain_setting_import(self):
        """测试跨域配置导入"""
        from fly_djangox.settings import cross_domain_setting

        # 验证配置模块可以导入
        self.assertIsNotNone(cross_domain_setting)

    def test_logging_setting_import(self):
        """测试日志配置导入"""
        from fly_djangox.settings import logging_setting

        # 验证配置模块可以导入
        self.assertIsNotNone(logging_setting)

    def test_api_time_out_setting_import(self):
        """测试API超时配置导入"""
        from fly_djangox.settings import api_time_out_setting

        # 验证配置模块可以导入
        self.assertIsNotNone(api_time_out_setting)
