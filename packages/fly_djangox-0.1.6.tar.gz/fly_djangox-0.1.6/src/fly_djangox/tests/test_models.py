from django.test import TestCase
from django.db import models
from fly_djangox.models.soft_delete import BasicModel, TsSoftDeleteModel


class TestBasicModel(TestCase):
    def test_basic_model_fields(self):
        """测试基础模型字段"""

        # BasicModel是抽象模型，需要创建具体模型来测试
        class TestModel(BasicModel):
            name = models.CharField(max_length=100)

            class Meta:
                app_label = "fly_djangox"

        # 验证字段存在
        self.assertTrue(hasattr(TestModel, "create_ts"))
        self.assertTrue(hasattr(TestModel, "update_ts"))
        self.assertTrue(TestModel._meta.abstract)


class TestTsSoftDeleteModel(TestCase):
    def test_soft_delete_model_fields(self):
        """测试软删除模型字段"""

        class TestSoftModel(TsSoftDeleteModel):
            name = models.CharField(max_length=100)

            class Meta:
                app_label = "fly_djangox"

        # 验证字段存在
        self.assertTrue(hasattr(TestSoftModel, "create_ts"))
        self.assertTrue(hasattr(TestSoftModel, "update_ts"))
        self.assertTrue(hasattr(TestSoftModel, "delete_ts"))
        self.assertTrue(TestSoftModel._meta.abstract)

    def test_soft_delete_manager_exists(self):
        """测试软删除管理器存在"""

        class TestSoftModel(TsSoftDeleteModel):
            name = models.CharField(max_length=100)

            class Meta:
                app_label = "fly_djangox"

        # 验证管理器存在
        self.assertTrue(hasattr(TestSoftModel, "objects"))
        self.assertTrue(hasattr(TestSoftModel, "all_objects"))
