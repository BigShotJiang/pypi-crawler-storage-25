from django.test import TestCase
from fly_djangox.drf.response import JSONResponse


class TestJSONResponse(TestCase):
    def test_success_response(self):
        """测试成功响应"""
        response = JSONResponse(data={"id": 1, "name": "test"})
        self.assertEqual(response.data["code"], 0)
        self.assertEqual(response.data["msg"], "success")
        self.assertEqual(response.data["data"]["id"], 1)
        self.assertIn("ts", response.data)

    def test_error_response(self):
        """测试错误响应"""
        response = JSONResponse(code=40000, msg="参数错误")
        self.assertEqual(response.data["code"], 40000)
        self.assertEqual(response.data["msg"], "参数错误")
        self.assertEqual(response.data["data"], {})

    def test_list_response(self):
        """测试列表响应"""
        response = JSONResponse(data=[1, 2, 3])
        self.assertEqual(response.data["code"], 0)
        self.assertEqual(response.data["data"], [1, 2, 3])
