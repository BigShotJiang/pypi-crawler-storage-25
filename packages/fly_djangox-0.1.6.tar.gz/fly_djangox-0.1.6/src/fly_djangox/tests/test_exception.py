from django.test import TestCase, RequestFactory
from rest_framework.exceptions import APIException as DRFAPIException
from fly_djangox.drf.exception import APIException, exception_handler


class TestAPIException(TestCase):
    def test_custom_api_exception(self):
        """测试自定义API异常"""
        exc = APIException(msg="业务错误", code=40001)
        self.assertEqual(exc.detail["code"], 40001)
        self.assertEqual(exc.detail["msg"], "业务错误")

    def test_exception_handler_with_custom_exception(self):
        """测试异常处理器处理自定义异常"""
        factory = RequestFactory()
        request = factory.get("/")

        exc = APIException(msg="测试错误", code=40000)
        response = exception_handler(exc, {"request": request})

        self.assertIsNotNone(response)
        self.assertEqual(response.data["code"], 40000)
        self.assertEqual(response.data["msg"], "测试错误")

    def test_exception_handler_with_drf_exception(self):
        """测试异常处理器处理DRF异常"""
        from rest_framework.exceptions import NotFound

        factory = RequestFactory()
        request = factory.get("/")

        exc = NotFound()
        response = exception_handler(exc, {"request": request})

        self.assertIsNotNone(response)
        self.assertEqual(response.data["code"], 404)
