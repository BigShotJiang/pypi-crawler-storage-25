from django.conf import settings

# 确保INSTALLED_APPS和MIDDLEWARE是列表而不是元组
if isinstance(settings.INSTALLED_APPS, tuple):
    settings.INSTALLED_APPS = list(settings.INSTALLED_APPS)
if isinstance(settings.MIDDLEWARE, tuple):
    settings.MIDDLEWARE = list(settings.MIDDLEWARE)

# 添加corsheaders（防重复）
if "corsheaders" not in settings.INSTALLED_APPS:
    settings.INSTALLED_APPS.append("corsheaders")

# 添加CorsMiddleware（防重复）
cors_middleware = "corsheaders.middleware.CorsMiddleware"
if cors_middleware not in settings.MIDDLEWARE:
    try:
        idx = settings.MIDDLEWARE.index("django.middleware.security.SecurityMiddleware")
        settings.MIDDLEWARE.insert(idx + 1, cors_middleware)
    except ValueError:
        settings.MIDDLEWARE.insert(0, cors_middleware)

# 必须关闭全开放
settings.CORS_ALLOW_ALL_ORIGINS = False

# 指定白名单（前端域名）
settings.CORS_ALLOWED_ORIGINS = []

# 如果有子域名很多，可以用：
# settings.CORS_ALLOWED_ORIGIN_REGEXES = [
#     r"^https://.*\.your-frontend\.com$",
# ]

#  允许携带 Cookie（如果你用 session 登录）, jwt直接false
settings.CORS_ALLOW_CREDENTIALS = False

# 方法（标准即可）
settings.CORS_ALLOW_METHODS = [
    "GET",
    "POST",
    "PUT",
    "PATCH",
    "DELETE",
    "OPTIONS",
]

# 精简 Header
settings.CORS_ALLOW_HEADERS = [
    "authorization",
    "content-type",
    "x-csrftoken",
]

# 可选：暴露响应头（如果前端需要读）
settings.CORS_EXPOSE_HEADERS = [
    "Content-Type",
    "Authorization",
]

# 预检缓存（减少 OPTIONS 请求）
settings.CORS_PREFLIGHT_MAX_AGE = 86400  # 24小时
