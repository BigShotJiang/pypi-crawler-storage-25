from django.conf import settings

# 确保MIDDLEWARE是列表而不是元组
if isinstance(settings.MIDDLEWARE, tuple):
    settings.MIDDLEWARE = list(settings.MIDDLEWARE)

# 添加RequestTimingMiddleware（防重复）
api_middleware = (
    "fly_djangox.middlewares.timing_api_middlewares.RequestTimingMiddleware"
)
if api_middleware not in settings.MIDDLEWARE:
    try:
        idx = settings.MIDDLEWARE.index("django.middleware.common.CommonMiddleware")
        settings.MIDDLEWARE.insert(idx + 1, api_middleware)
    except ValueError:
        settings.MIDDLEWARE.insert(0, api_middleware)

# 添加SQLTimingMiddleware（防重复）
sql_middleware = "fly_djangox.middlewares.timing_sql_middlewares.SQLTimingMiddleware"
if sql_middleware not in settings.MIDDLEWARE:
    try:
        idx = settings.MIDDLEWARE.index("django.middleware.common.CommonMiddleware")
        settings.MIDDLEWARE.insert(idx + 1, sql_middleware)
    except ValueError:
        settings.MIDDLEWARE.insert(0, sql_middleware)
