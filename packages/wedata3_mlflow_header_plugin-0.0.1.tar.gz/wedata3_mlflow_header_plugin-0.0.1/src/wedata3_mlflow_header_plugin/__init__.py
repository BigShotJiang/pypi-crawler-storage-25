"""
WeData 3.0 MLflow Header Plugin

A plugin that adds custom headers to MLflow requests.
"""

__version__ = "0.0.1"

from wedata3_mlflow_header_plugin.plugin import WedataRequestHeaderProvider

__all__ = ["WedataRequestHeaderProvider"]
