"""Loop execution and HTTP dispatch methods for the API runtime app."""

from __future__ import annotations

from collections.abc import Iterator
from dataclasses import replace
import json
from queue import Empty, Queue
import shutil
from threading import Lock, Thread
from typing import Any, Mapping
from urllib.parse import unquote
from uuid import uuid4

from packages.context import (
    next_session_context_epoch,
)
from packages.context.epoch_store import FileEpochStore
from packages.contracts import EventEnvelope
from packages.kernel import KernelSourceRequest, ReconciliationPipeline, StateReconciler
from packages.models.reasoning_parser import split_reasoning_and_content
from packages.operator.runtime import RecallEvidenceOperatorDetail
from packages.runtime_layout import elephant_file_path
from packages.state import render_default_elephant_identity, write_elephant_identity_file

from .api_runtime_support import (
    APILoopRecord,
    APILoopResult,
    APIResponse,
    _jsonable,
    _now,
    _optional_str,
    _read_json_bytes,
    _split_path,
)
from .api_runtime_http_dispatch_helpers import (
    _cron_job_system_kind,
    _elephant_id_from_name,
    _cron_payload,
    _cron_skill_ids,
    _cron_job_record,
    _read_wsgi_body,
)
from .api_runtime_personal_model_methods import (
    _dispatch_personal_model,
    _persist_proactive_ask_config,
)
from .api_runtime_context_compression import (
    compact_context_after_usage as _compact_context_after_usage,
)
from .api_runtime_herd_local_agents import (
    baby_identity_text as _baby_identity_text,
    default_baby_display_name as _default_baby_display_name,
    herd_metadata_from_payload as _herd_metadata_from_payload,
    list_persisted_local_agents as _list_persisted_local_agents,
    local_agent_payload as _local_agent_payload,
    metadata_bool_payload as _metadata_bool_payload,
    metadata_str_payload as _metadata_str_payload,
    scan_and_persist_local_agents as _scan_and_persist_local_agents,
)

_STREAM_KEEPALIVE_SECONDS = 15.0

def run_loop(
    self,
    episode_id: str,
    *,
    prompt: str,
    state_query: str | None = None,
    tool_name: str | None = None,
    tool_arguments: Mapping[str, Any] | None = None,
    delivery_payload: Mapping[str, Any] | None = None,
) -> APILoopResult:
    episode = self.repository.load_episode_state(episode_id)
    if episode is None:
        raise KeyError(episode_id)
    if episode.status == "closed":
        raise ValueError(f"cannot send to a closed episode: {episode_id}")
    personal_model = self.repository.load_personal_model_runtime_state(episode.personal_model_id)
    if personal_model is None:
        raise KeyError(episode.personal_model_id)
    stored_episode = self.repository.load_episode(episode_id)
    route_state = self.repository.load_state(stored_episode.state_id) if stored_episode is not None else None
    event = EventEnvelope(
        event_id=f"api:{episode_id}:loop:{uuid4().hex}",
        event_type="loop.received",
        episode_id=episode_id,
        source="api",
        payload={
            "message": prompt,
            "content": prompt,
            "summary": prompt,
            "state_query": state_query or "",
            "tool_name": tool_name or "",
        },
    )
    outcome = self.kernel.run(
        KernelSourceRequest(
            route_id=episode_id,
            prompt=prompt,
            surface="api",
            source_event_type="loop.received",
            source_payload=dict(event.payload),
            source_event_id=event.event_id,
            route_profile_id=episode.personal_model_id,
            route_status=episode.status,
            route_interruption_state=episode.interruption_state,
            route_started_at=episode.started_at,
            personal_model_id=route_state.personal_model_id if route_state is not None else episode.personal_model_id,
            state_id=route_state.state_id if route_state is not None else None,
            episode_id=episode.episode_id,
            episode_policy="api_session",
            state_query=state_query,
            tool_name=tool_name,
            tool_arguments=dict(tool_arguments or {}),
            delivery_payload=dict(delivery_payload or {}),
        )
    )
    observation = ReconciliationPipeline().observe_turn(
        inbound_event=event,
        execution=outcome.execution,
        decision_summary=outcome.state.summary or outcome.execution.summary,
        source="api",
        profile_id=episode.personal_model_id,
        elephant_id=episode.elephant_id,
        turn_messages=outcome.turn_messages,
    )
    StateReconciler().reconcile_turn(
        repository=self.repository,
        recall_runtime=self.recall_runtime,
        observation=observation,
    )
    _epoch_store = FileEpochStore(self.repository.database_path.parent)
    existing_epoch = _epoch_store.load(episode.episode_id)
    updated_epoch = next_session_context_epoch(
        existing_epoch,
        session=episode,
        event=outcome.event,
        execution=outcome.execution,
        context=outcome.context,
        turn_messages=outcome.turn_messages,
        thread_focus=outcome.state.summary,
    )
    if updated_epoch != existing_epoch:
        _epoch_store.save(updated_epoch)
    outcome = _compact_context_after_usage(self, episode.episode_id, outcome)
    record = APILoopRecord(
        request={
            "prompt": prompt,
            "state_query": state_query,
            "tool_name": tool_name,
            "tool_arguments": dict(tool_arguments or {}),
            "delivery_payload": dict(delivery_payload or {}),
        },
        outcome=outcome,
        recorded_at=_now(),
    )
    self._loops.setdefault(episode_id, []).append(record)
    inspection = self.inspect_episode(episode_id)
    return APILoopResult(
        episode=inspection.episode,
        outcome=outcome,
        latest_loop=record,
        inspection=inspection,
    )


def stream_loop_events(
    self,
    episode_id: str,
    *,
    prompt: str,
    state_query: str | None = None,
    tool_name: str | None = None,
    tool_arguments: Mapping[str, Any] | None = None,
    delivery_payload: Mapping[str, Any] | None = None,
) -> Iterator[dict[str, Any]]:
    """Run a loop while yielding live UI-safe events.

    The CLI chat can render model deltas, kernel stages, and tool lifecycle
    events because it runs in-process. This generator exposes the same observer
    surfaces to HTTP callers without changing the synchronous loop contract.
    """
    event_queue: Queue[dict[str, Any] | object] = Queue(maxsize=2048)
    sentinel = object()
    sequence_lock = Lock()
    stream_sequence = 0

    def envelope(event: Mapping[str, Any]) -> dict[str, Any]:
        nonlocal stream_sequence
        with sequence_lock:
            stream_sequence += 1
            sequence = stream_sequence
        return _jsonable(
            {
                "episode_id": episode_id,
                "stream_sequence": sequence,
                "stream_emitted_at": _now(),
                **dict(event),
            }
        )

    def enqueue(event: Mapping[str, Any]) -> None:
        event_queue.put(envelope(event))

    def stream_observer(delta: str, **metadata: Any) -> None:
        stream_session_id = str(metadata.get("session_id") or "")
        if stream_session_id and stream_session_id != episode_id:
            return
        combined = split_reasoning_and_content(str(delta), streaming=True)
        if combined.reasoning:
            enqueue({"type": "assistant.reasoning.delta", "delta": combined.reasoning})
        if combined.content:
            enqueue({"type": "assistant.delta", "delta": combined.content})

    def tool_observer(event: Any) -> None:
        invocation = getattr(event, "invocation", None)
        if invocation is not None and getattr(invocation, "session_id", episode_id) != episode_id:
            return
        enqueue(_tool_lifecycle_stream_event(event))

    def telemetry_observer(event: Mapping[str, Any]) -> None:
        event_type = str(event.get("event_type") or event.get("type") or "")
        if event_type != "kernel.stage":
            return
        if str(event.get("episode_id") or "") not in {"", episode_id}:
            return
        payload = event.get("payload") if isinstance(event.get("payload"), Mapping) else {}
        enqueue(
            {
                "type": "kernel.stage",
                "event_type": "kernel.stage",
                "id": str(event.get("event_id") or payload.get("event_id") or uuid4().hex),
                "stage": str(payload.get("stage") or ""),
                "detail": str(payload.get("detail") or ""),
                "result": str(payload.get("result") or ""),
                "status": "running",
            }
        )

    def worker() -> None:
        stream_lock = getattr(self, "_loop_stream_lock", None)
        set_stream_observer = getattr(self.model_provider, "set_stream_observer", None)
        previous_stream_observer = getattr(self.model_provider, "_stream_observer", None)
        unsubscribe_tool = self.tool_runtime.subscribe(tool_observer)
        unsubscribe_telemetry = self.telemetry.subscribe(telemetry_observer)
        acquired_stream_lock = False
        try:
            enqueue({"type": "loop.started", "message": "Opening a live chat loop"})
            if stream_lock is not None:
                stream_lock.acquire()
                acquired_stream_lock = True
            if callable(set_stream_observer):
                set_stream_observer(stream_observer)
            result = self.run_loop(
                episode_id,
                prompt=prompt,
                state_query=state_query,
                tool_name=tool_name,
                tool_arguments=tool_arguments,
                delivery_payload=delivery_payload,
            )
            enqueue(_loop_result_stream_completed_event(result))
        except Exception as error:
            enqueue({"type": "loop.failed", "error": str(error)})
        finally:
            if callable(set_stream_observer):
                set_stream_observer(previous_stream_observer)
            unsubscribe_tool()
            unsubscribe_telemetry()
            if acquired_stream_lock and stream_lock is not None:
                stream_lock.release()
            event_queue.put(sentinel)

    Thread(target=worker, daemon=True).start()

    while True:
        try:
            event = event_queue.get(timeout=_STREAM_KEEPALIVE_SECONDS)
        except Empty:
            yield envelope({"type": "stream.heartbeat"})
            continue
        if event is sentinel:
            break
        yield event  # type: ignore[misc]

def dispatch(self, method: str, path: str, body: bytes | None = None) -> APIResponse:
    if method.upper() == "GET" and path == "/healthz":
        return APIResponse(200, {"status": "ok", "service": "elephant-api"})

    try:
        parts = _split_path(path)
        if not parts:
            return APIResponse(404, {"error": "not_found"})
        if parts[0] == "providers":
            return self._dispatch_providers(method, parts[1:], body)
        if parts[0] == "internal":
            return self._dispatch_internal(method, parts[1:], body)
        if parts[0] == "operator":
            return self._dispatch_operator(method, parts[1:], body)
        if parts[0] == "herd":
            return _dispatch_elephants(self, method, parts[1:], body)
        if parts[0] == "episodes":
            return self._dispatch_episodes(method, parts[1:], body)
        if parts[0] == "states":
            return self._dispatch_states(method, parts[1:], body)
        return APIResponse(404, {"error": "not_found"})
    except KeyError as error:
        return APIResponse(404, {"error": "not_found", "missing": str(error)})
    except (ValueError, TypeError) as error:
        return APIResponse(400, {"error": "bad_request", "detail": str(error)})
    except LookupError as error:
        return APIResponse(422, {"error": "configuration_required", "detail": str(error)})
    except Exception as error:
        return APIResponse(500, {"error": "internal_error", "detail": str(error)})
def _unique_elephant_id(self, base_elephant_id: str) -> str:
    root = _elephant_id_from_name(base_elephant_id)
    elephant_id = root
    suffix = 2
    while _elephant_state_for_id(self, elephant_id) is not None:
        elephant_id = f"{root}-{suffix}"
        suffix += 1
    return elephant_id
def _elephant_state_for_id(self, elephant_id: str):
    target = elephant_id.strip()
    if not target:
        return None
    direct = self.repository.load_state(f"state:{target}")
    if direct is not None:
        return direct
    return next((state for state in self.repository.list_states() if state.elephant_id == target), None)
def _default_elephant_identity_text(*, elephant_id: str, display_name: str) -> str:
    """Seed identity text when none is supplied via the API.

    Mirrors the CLI's first-person self-introduction template so a
    companion created through the API reads the same way a CLI-created
    companion does. Internal metadata lives in an HTML comment so it stays
    out of the prompt.
    """
    charter = render_default_elephant_identity(display_name=display_name)
    return "\n".join(
        (
            f"<!-- Internal metadata (not shown to the model). id: {elephant_id}. "
            f"Edit the paragraphs below to reshape how {display_name} introduces themselves. -->",
            "",
            charter,
        )
    )
def _elephant_identity_text_from_payload(payload: Mapping[str, Any], *, elephant_id: str, display_name: str) -> str:
    return (
        _optional_str(payload.get("elephant_identity_text") or payload.get("eggIdentityText") or payload.get("text") or payload.get("content"))
        or _default_elephant_identity_text(elephant_id=elephant_id, display_name=display_name)
    )

def _write_elephant_identity_file(self, *, elephant_id: str, text: str) -> str:
    path = write_elephant_identity_file(
        elephant_file_path(elephant_id, install_root=self.config.install_root),
        text,
    )
    return str(path)
def _dispatch_elephants(self, method: str, parts: tuple[str, ...], body: bytes | None) -> APIResponse:
    normalized_method = method.upper()
    if normalized_method == "POST" and parts == ("discovery", "scan"):
        records = _scan_and_persist_local_agents(self)
        return APIResponse(
            200,
            _jsonable(
                {
                    "status": "ok",
                    "discovery": [_local_agent_payload(record) for record in records],
                    "local_agent_runtimes": [_local_agent_payload(record) for record in records],
                }
            ),
        )
    if normalized_method == "GET" and parts == ("discovery",):
        records = _list_persisted_local_agents(self)
        return APIResponse(
            200,
            _jsonable(
                {
                    "status": "ok",
                    "discovery": [_local_agent_payload(record) for record in records],
                    "local_agent_runtimes": [_local_agent_payload(record) for record in records],
                }
            ),
        )
    if normalized_method == "POST" and parts == ("babies",):
        payload = _read_json_bytes(body)
        runtime_id = str(payload.get("runtime_id") or payload.get("runtimeId") or "").strip()
        if not runtime_id:
            raise ValueError("runtime_id is required")
        load_runtime = getattr(self.repository, "load_local_agent_runtime", None)
        record = load_runtime(runtime_id) if callable(load_runtime) else None
        if record is None:
            raise KeyError(runtime_id)
        if not record.can_execute:
            raise ValueError(f"runtime is not executable yet: {runtime_id}")
        role_title = _metadata_str_payload(payload, "role_title", "roleTitle") or record.role_title
        role_prompt = _metadata_str_payload(payload, "role_prompt", "rolePrompt") or record.role_prompt
        display_name = str(payload.get("display_name") or payload.get("name") or "").strip()
        if not display_name:
            display_name = _default_baby_display_name(record, role_title)
        raw_elephant_id = str(payload.get("elephant_id") or payload.get("elephantId") or "").strip()
        if raw_elephant_id and _elephant_state_for_id(self, raw_elephant_id) is not None:
            raise ValueError(f"elephant already exists: {raw_elephant_id}")
        elephant_id = raw_elephant_id or _unique_elephant_id(self, display_name)
        mother = _elephant_state_for_id(self, "mother-elephant")
        personal_model_id = str(
            payload.get("personal_model_id")
            or payload.get("profile_id")
            or (mother.personal_model_id if mother is not None else self.repository.ensure_default_personal_model().personal_model_id)
        ).strip()
        enabled = _metadata_bool_payload(payload, "enabled", "isEnabled") or "false"
        metadata = _herd_metadata_from_payload(
            {
                **dict(payload),
                "herd_kind": "baby",
                "parent_elephant_id": str(payload.get("parent_elephant_id") or payload.get("parentElephantId") or "mother-elephant"),
                "runtime_id": record.runtime_id,
                "provider_id": record.provider_id,
                "role_title": role_title,
                "role_prompt": role_prompt,
                "enabled": enabled,
                "max_concurrency": str(payload.get("max_concurrency") or payload.get("maxConcurrency") or "1"),
            },
            current={"profile_id": personal_model_id},
        )
        identity_text = (
            _optional_str(payload.get("elephant_identity_text") or payload.get("text") or payload.get("content"))
            or _baby_identity_text(
                display_name=display_name,
                role_title=role_title,
                role_prompt=role_prompt,
                provider_name=record.display_name,
            )
        )
        state = self.repository.create_state(
            personal_model_id=personal_model_id,
            state_id=f"state:{elephant_id}",
            state_anchor=f"elephant:{elephant_id}",
            elephant_id=elephant_id,
            elephant_name=display_name,
            identity_mode="baby",
            initiative="delegated",
            working_style="local_agent",
            surface_bindings=("api", "dashboard", "local-agent"),
            elephant_identity_text=identity_text,
            summary=f"{display_name} is available as a baby elephant for {role_title}.",
            metadata=metadata,
        )
        elephant_identity_path = _write_elephant_identity_file(self, elephant_id=elephant_id, text=identity_text)
        return APIResponse(201, _jsonable({"elephant": state, "eggIdentityPath": elephant_identity_path}))
    if normalized_method == "POST" and not parts:
        payload = _read_json_bytes(body)
        display_name = str(payload.get("elephant_name") or payload.get("display_name") or payload.get("name") or "").strip()
        if not display_name:
            raise ValueError("display_name is required")
        raw_elephant_id = str(payload.get("elephant_id") or payload.get("eggId") or "").strip()
        if raw_elephant_id and _elephant_state_for_id(self, raw_elephant_id) is not None:
            raise ValueError(f"elephant already exists: {raw_elephant_id}")
        elephant_id = raw_elephant_id or _unique_elephant_id(self, display_name)
        personal_model_id = str(
            payload.get("personal_model_id")
            or payload.get("profile_id")
            or self.repository.ensure_default_personal_model().personal_model_id
        ).strip()
        identity_text = _elephant_identity_text_from_payload(payload, elephant_id=elephant_id, display_name=display_name)
        identity_mode = _optional_str(payload.get("mode") or payload.get("identity_mode")) or "companion"
        initiative = _optional_str(payload.get("initiative")) or "gentle"
        working_style = _optional_str(payload.get("personality_preset") or payload.get("working_style")) or "companion"
        state = self.repository.create_state(
            personal_model_id=personal_model_id,
            state_id=f"state:{elephant_id}",
            state_anchor=f"elephant:{elephant_id}",
            elephant_id=elephant_id,
            elephant_name=display_name,
            identity_mode=identity_mode,
            initiative=initiative,
            working_style=working_style,
            surface_bindings=("api", "dashboard"),
            elephant_identity_text=identity_text,
            summary=f"{display_name} is ready to continue this elephant line.",
            metadata=_herd_metadata_from_payload(payload, current={"profile_id": personal_model_id}),
        )
        elephant_identity_path = _write_elephant_identity_file(self, elephant_id=elephant_id, text=identity_text)
        return APIResponse(201, _jsonable({"elephant": state, "eggIdentityPath": elephant_identity_path}))
    if len(parts) != 1:
        return APIResponse(404, {"error": "not_found"})
    elephant_id = unquote(parts[0]).strip()
    state = _elephant_state_for_id(self, elephant_id)
    if state is None:
        raise KeyError(elephant_id)
    if normalized_method in {"PATCH", "POST"}:
        payload = _read_json_bytes(body)
        display_name = _optional_str(payload.get("elephant_name") or payload.get("display_name") or payload.get("name"))
        mode = _optional_str(payload.get("mode"))
        identity_text = _optional_str(payload.get("elephant_identity_text") or payload.get("eggIdentityText") or payload.get("text") or payload.get("content"))
        personality_preset = _optional_str(payload.get("personality_preset") or payload.get("working_style"))
        initiative = _optional_str(payload.get("initiative"))
        identity_mode = _optional_str(payload.get("mode") or payload.get("identity_mode"))
        updated = replace(
            state,
            elephant_name=display_name or state.elephant_name,
            identity_mode=identity_mode if identity_mode is not None else state.identity_mode or "companion",
            initiative=initiative if initiative is not None else state.initiative,
            working_style=personality_preset if personality_preset is not None else state.working_style,
            elephant_identity_text=identity_text if identity_text is not None else state.elephant_identity_text,
            summary=f"{display_name or state.elephant_name} is ready to continue this elephant line.",
            metadata=_herd_metadata_from_payload(payload, current={**dict(state.metadata), "profile_id": state.personal_model_id}),
        )
        self.repository.upsert_state(updated)
        elephant_identity_path = ""
        if identity_text is not None:
            elephant_identity_path = _write_elephant_identity_file(self, elephant_id=updated.elephant_id, text=identity_text)
        return APIResponse(200, _jsonable({"elephant": updated, "eggIdentityPath": elephant_identity_path}))
    if normalized_method == "DELETE":
        episode_ids = tuple(episode.episode_id for episode in self.repository.list_episodes(state_id=state.state_id))
        deleted_sessions = self.repository.delete_episodes(episode_ids, delete_orphaned_profiles=False)
        self.repository.delete_state(state.state_id)
        shutil.rmtree(elephant_file_path(state.elephant_id, install_root=self.config.install_root), ignore_errors=True)
        return APIResponse(200, _jsonable({"elephant_id": state.elephant_id, "deleted": True, "deleted_sessions": deleted_sessions}))
    return APIResponse(404, {"error": "not_found"})

def _tool_lifecycle_stream_event(event: Any) -> dict[str, Any]:
    invocation = getattr(event, "invocation", None)
    approval = getattr(event, "approval", None)
    execution = getattr(event, "execution", None)
    phase = str(getattr(event, "phase", "") or "")
    name = str(getattr(invocation, "tool_id", "") or "tool")
    arguments = getattr(invocation, "arguments", {}) if invocation is not None else {}
    result = str(getattr(execution, "summary", "") or "")
    return {
        "type": "tool.lifecycle",
        "event_type": "tool_execute",
        "id": str(getattr(event, "event_id", "") or uuid4().hex),
        "invocation_id": str(getattr(invocation, "invocation_id", "") or ""),
        "name": name,
        "tool_name": name,
        "status": _tool_lifecycle_status(phase, execution=execution, approval=approval),
        "phase": phase,
        "detail": str(getattr(event, "detail", "") or ""),
        "arguments": arguments,
        "tool_arguments": arguments,
        "result": result,
        "tool_result": result,
        "approval": _jsonable(approval) if approval is not None else None,
        "execution": _jsonable(execution) if execution is not None else None,
    }

def _tool_lifecycle_status(event_phase: str, *, execution: Any, approval: Any) -> str:
    if event_phase == "execution.completed":
        outcome = str(getattr(execution, "outcome", "") or "").lower()
        return "completed" if outcome in {"", "ok", "success"} else outcome
    if event_phase == "execution.failed":
        return "failed"
    if event_phase == "execution.started":
        return "running"
    if event_phase.startswith("approval."):
        decision = str(getattr(approval, "decision", "") or "").lower()
        if decision in {"denied", "deferred"}:
            return decision
        return "approved"
    if event_phase in {"requested", "classified"}:
        return "preparing"
    return event_phase or "running"

def _loop_result_payload(result: APILoopResult) -> dict[str, Any]:
    payload = dict(result.to_record())
    payload["reply_text"] = _loop_reply_text(result)
    return payload

def _loop_result_stream_completed_event(result: APILoopResult) -> dict[str, Any]:
    reply_text = _loop_reply_text(result)
    return {
        "type": "loop.completed",
        "reply_text": reply_text,
        "reply": {
            "episode_id": str(getattr(getattr(result, "episode", None), "episode_id", "") or ""),
            "text": reply_text,
            "tool_events": _loop_result_stream_tool_events(result),
        },
    }

def _loop_result_stream_tool_events(result: APILoopResult) -> list[dict[str, str]]:
    outcome = getattr(result, "outcome", None)
    steps = tuple(getattr(outcome, "steps", ()) or ())
    events: list[dict[str, str]] = []
    for step in steps:
        action = str(getattr(step, "action", "") or "")
        if action != "call_tool":
            continue
        metadata = getattr(step, "metadata", {}) or {}
        if not isinstance(metadata, Mapping):
            metadata = {}
        tool_name = str(metadata.get("tool_name") or "").strip()
        if not tool_name:
            continue
        status = str(getattr(step, "status", "") or "").strip() or "completed"
        events.append(
            {
                "name": tool_name,
                "tool_name": tool_name,
                "status": status,
                "arguments": _stream_preview(metadata.get("tool_arguments")),
                "result": _stream_preview(metadata.get("tool_result") or getattr(step, "summary", "") or ""),
            }
        )
    return events[-12:]

def _stream_preview(value: Any, *, limit: int = 700) -> str:
    if value is None:
        return ""
    text = str(value).strip()
    if len(text) <= limit:
        return text
    return f"{text[:limit].rstrip()}..."

def _loop_reply_text(result: APILoopResult) -> str:
    outcome = getattr(result, "outcome", None)
    execution = getattr(outcome, "execution", None)
    text = str(getattr(execution, "summary", "") or "").strip()
    if text:
        return text
    for message in reversed(tuple(getattr(outcome, "turn_messages", ()) or ())):
        role = str(getattr(message, "role", "") or "").strip().lower()
        content = str(getattr(message, "content", "") or "").strip()
        if role == "assistant" and content:
            return content
    return ""
def _dispatch_episodes(self, method: str, parts: tuple[str, ...], body: bytes | None) -> APIResponse:
    if method.upper() == "POST" and len(parts) == 0:
        payload = _read_json_bytes(body)
        result = self.create_episode(
            personal_model_id=str(payload.get("personal_model_id") or payload["profile_id"]),
            display_name=str(payload["display_name"]),
            mode=str(payload.get("mode") or "companion"),
            elephant_id=payload.get("elephant_id"),
            elephant_path=payload.get("elephant_path"),
            preferences=tuple(payload.get("preferences", ())),
            enabled_capabilities=tuple(payload.get("enabled_capabilities", ())),
            provider_profile=payload.get("provider_profile"),
            episode_id=payload.get("episode_id"),
        )
        return APIResponse(201, _jsonable(result.to_record()))
    if len(parts) < 1:
        return APIResponse(404, {"error": "not_found"})
    episode_id = parts[0]
    if method.upper() == "GET" and len(parts) == 1:
        return APIResponse(200, _jsonable(self.inspect_episode(episode_id).to_record()))
    if method.upper() == "POST" and len(parts) == 2 and parts[1] == "interrupt":
        payload = _read_json_bytes(body)
        result = self.interrupt_episode(episode_id, interruption_state=str(payload["interruption_state"]))
        return APIResponse(200, _jsonable(_loop_result_payload(result)))
    if method.upper() == "POST" and len(parts) == 2 and parts[1] == "next":
        payload = _read_json_bytes(body)
        result = self.open_next_episode(episode_id, child_episode_id=payload.get("child_episode_id"))
        return APIResponse(200, _jsonable(result.to_record()))
    if method.upper() == "POST" and len(parts) == 2 and parts[1] == "loops":
        payload = _read_json_bytes(body)
        result = self.run_loop(
            episode_id,
            prompt=str(payload["prompt"]),
            state_query=payload.get("state_query"),
            tool_name=payload.get("tool_name"),
            tool_arguments=payload.get("tool_arguments"),
            delivery_payload=payload.get("delivery_payload"),
        )
        return APIResponse(200, _jsonable(result.to_record()))
    if method.upper() == "GET" and len(parts) == 2 and parts[1] == "profile":
        inspection = self.inspect_episode(episode_id)
        return APIResponse(200, _jsonable({"personal_model": inspection.personal_model}))
    if len(parts) == 2 and parts[1] in {"identity", "user", "relationship", "continuity"}:
        episode = self.repository.load_episode(episode_id)
        if episode is None:
            raise KeyError(episode_id)
        return self._dispatch_states(method, (episode.state_id, parts[1]), body)
    if len(parts) == 2 and parts[1] == "recall":
        if method.upper() == "GET":
            return APIResponse(200, _jsonable({"episode_id": episode_id, "recall": self.inspect_recall_evidence_surface(episode_id)}))
    if len(parts) == 3 and parts[1] == "recall" and parts[2] == "evidence":
        if method.upper() == "GET":
            return APIResponse(200, _jsonable({"episode_id": episode_id, "evidence": self.list_recall_evidence(episode_id)}))
    if len(parts) == 3 and parts[1] == "recall" and parts[2] == "search":
        payload = _read_json_bytes(body)
        query = _optional_str(payload.get("query"))
        if query is None:
            raise ValueError("recall search query is required")
        limit = int(payload.get("limit", 5))
        return APIResponse(
            200,
            _jsonable({
                "episode_id": episode_id,
                "recall": self.search_recall_evidence_surface(episode_id, query=query, limit=limit),
            }),
        )
    if len(parts) == 3 and parts[1] == "recall":
        evidence_ref = parts[2]
        if method.upper() == "GET":
            detail = self.inspect_recall_evidence(episode_id, evidence_ref)
            return APIResponse(
                200,
                _jsonable(
                    {
                        "episode_id": episode_id,
                        "evidence": RecallEvidenceOperatorDetail(
                            evidence=detail["evidence"],
                            state=detail["state"],
                            lineage=detail["lineage"],
                        ),
                    }
                ),
            )
    return APIResponse(404, {"error": "not_found"})
def _dispatch_states(self, method: str, parts: tuple[str, ...], body: bytes | None) -> APIResponse:
    if len(parts) != 2:
        return APIResponse(404, {"error": "not_found"})
    state_id, surface = parts
    if surface == "identity":
        if method.upper() == "GET":
            return APIResponse(200, _jsonable({"state_id": state_id, "identity": self.inspect_identity(state_id=state_id)}))
        if method.upper() in {"PATCH", "POST"}:
            payload = _read_json_bytes(body)
            result = self.update_identity_state(
                state_id=state_id,
                display_name=_optional_str(payload.get("display_name") or payload.get("name")),
                personality_preset=_optional_str(payload.get("personality_preset") or payload.get("working_style")),
                initiative=_optional_str(payload.get("initiative")),
                elephant_identity_text=_optional_str(payload.get("elephant_identity_text") or payload.get("eggIdentityText") or payload.get("text") or payload.get("content")),
                clear_elephant_identity=bool(payload.get("clear_elephant_identity", False)),
            )
            return APIResponse(200, _jsonable({"state_id": state_id, "identity": result}))
    if surface == "user":
        if method.upper() == "GET":
            return APIResponse(200, _jsonable({"state_id": state_id, "user": self.inspect_user(state_id=state_id)}))
        if method.upper() in {"PATCH", "POST"}:
            payload = _read_json_bytes(body)
            result = self.update_user_state(
                state_id=state_id,
                text=_optional_str(payload.get("text") or payload.get("content")),
                fields=payload.get("fields") if isinstance(payload.get("fields"), dict) else None,
                grounding_answers=payload.get("grounding_answers") if isinstance(payload.get("grounding_answers"), list) else None,
                append=bool(payload.get("append", False)),
                clear=bool(payload.get("clear", False)),
                split_personal_model_facts=bool(payload.get("split_personal_model_facts", False)),
            )
            return APIResponse(200, _jsonable({"state_id": state_id, "user": result}))
    if surface == "relationship":
        if method.upper() == "GET":
            return APIResponse(200, _jsonable({"state_id": state_id, "relationship": self.inspect_relationship(state_id=state_id)}))
        if method.upper() in {"PATCH", "POST"}:
            payload = _read_json_bytes(body)
            result = self.update_relationship_state(
                state_id=state_id,
                text=_optional_str(payload.get("text") or payload.get("content")),
                append=bool(payload.get("append", False)),
                clear=bool(payload.get("clear", False)),
            )
            return APIResponse(200, _jsonable({"state_id": state_id, "relationship": result}))
    if surface == "continuity" and method.upper() == "GET":
        return APIResponse(200, _jsonable(self.inspect_continuity(state_id).to_record()))
    return APIResponse(404, {"error": "not_found"})
def _dispatch_providers(self, method: str, parts: tuple[str, ...], body: bytes | None) -> APIResponse:
    if method.upper() == "GET" and len(parts) == 0:
        return APIResponse(200, _jsonable(self.list_providers()))
    if method.upper() == "GET" and len(parts) == 1 and parts[0] == "doctor":
        return APIResponse(200, _jsonable(self.doctor_provider()))
    if method.upper() == "GET" and len(parts) == 2 and parts[0] == "setup":
        return APIResponse(200, _jsonable(self.setup_provider(parts[1])))
    if method.upper() == "POST" and len(parts) == 1 and parts[0] == "models":
        payload = _read_json_bytes(body)
        return APIResponse(200, _jsonable(self.discover_provider_models(payload)))
    if method.upper() == "POST" and len(parts) == 1 and parts[0] == "default":
        payload = _read_json_bytes(body)
        provider_profile = payload.get("provider_profile")
        if not isinstance(provider_profile, dict):
            raise ValueError("provider_profile must be an object describing the default provider configuration")
        result = self.set_default_provider(provider_profile)
        return APIResponse(200, _jsonable(result))
    if method.upper() == "POST" and len(parts) == 1 and parts[0] == "test":
        payload = _read_json_bytes(body)
        result = self.test_provider(prompt=str(payload.get("prompt", "Summarize the current provider configuration.")))
        return APIResponse(200, _jsonable(result))
    if method.upper() == "GET" and len(parts) == 1 and parts[0] == "embeddings":
        return APIResponse(200, _jsonable({"embedding_provider": self.embedding_provider_summary()}))
    if method.upper() == "POST" and len(parts) == 1 and parts[0] == "embeddings":
        payload = _read_json_bytes(body)
        return APIResponse(200, _jsonable(self.set_embedding_provider(payload)))
    if method.upper() == "GET" and len(parts) == 1 and parts[0] == "keys":
        return APIResponse(200, _jsonable(self.list_provider_keys()))
    if method.upper() == "POST" and len(parts) == 1 and parts[0] == "keys":
        payload = _read_json_bytes(body)
        return APIResponse(201, _jsonable(self.create_provider_key(payload)))
    if method.upper() == "PATCH" and len(parts) == 2 and parts[0] == "keys":
        payload = _read_json_bytes(body)
        return APIResponse(200, _jsonable(self.upsert_provider_key(parts[1], payload)))
    if method.upper() == "DELETE" and len(parts) == 2 and parts[0] == "keys":
        return APIResponse(200, _jsonable(self.delete_provider_key(parts[1])))
    return APIResponse(404, {"error": "not_found"})

def _dispatch_internal(self, method: str, parts: tuple[str, ...], body: bytes | None) -> APIResponse:
    if method.upper() == "GET" and len(parts) == 2 and parts[0] == "dashboard":
        return APIResponse(200, {"dashboard": _jsonable(self.inspect_internal_dashboard(parts[1]))})
    if method.upper() == "POST" and len(parts) == 2 and parts[0] == "diary" and parts[1] == "write":
        payload = _read_json_bytes(body)
        target_date = str(payload.get("date") or "").strip()
        if not target_date:
            return APIResponse(400, {"error": "date is required (YYYY-MM-DD)"})
        result = self.trigger_diary_write(target_date=target_date)
        return APIResponse(200, _jsonable(result))
    if method.upper() == "DELETE" and len(parts) == 2 and parts[0] == "diary":
        try:
            result = self.delete_diary_entry(entry_date=unquote(parts[1]))
        except ValueError as error:
            return APIResponse(400, {"error": str(error)})
        return APIResponse(200, _jsonable(result))
    if method.upper() == "POST" and len(parts) == 2 and parts[0] == "reflect" and parts[1] == "run":
        payload = _read_json_bytes(body)
        trigger = str(payload.get("trigger") or "manual").strip()
        features = str(payload.get("features") or "").strip() or None
        result = self.trigger_reflect_job(trigger=trigger, features=features)
        return APIResponse(200, _jsonable(result))
    return APIResponse(404, {"error": "not_found"})

def _dispatch_operator(self, method: str, parts: tuple[str, ...], body: bytes | None) -> APIResponse:
    if parts and parts[0] == "cron":
        if method.upper() == "GET" and len(parts) == 1:
            from .api_runtime_console import _cron_jobs

            return APIResponse(200, {"cron": {"jobs": _cron_jobs(self)}})
        if method.upper() == "POST" and len(parts) == 1:
            payload = _read_json_bytes(body)
            job_payload = _cron_payload(payload)
            job = self.cron_runtime.create_job(
                name=str(payload.get("name") or "Elephant Agent job"),
                schedule_text=str(payload["schedule"]),
                payload=job_payload,
                profile_id=_optional_str(payload.get("profile_id")),
                elephant_id=_optional_str(payload.get("elephant_id")),
                timezone_name=_optional_str(payload.get("timezone_name")),
            )
            return APIResponse(201, {"cron": {"job": _cron_job_record(job)}})
        if len(parts) == 2:
            job_id = parts[1]
            if method.upper() == "GET":
                if job_id in {"system:proactive-ask", "system:dream"}:
                    from .api_runtime_console import _dream_system_job, _proactive_ask_system_job

                    job = _dream_system_job(self) if job_id == "system:dream" else _proactive_ask_system_job(self)
                    if job is None:
                        raise ValueError(f"system cron job unavailable: {job_id}")
                    return APIResponse(200, {"cron": {"job": job}})
                return APIResponse(200, {"cron": {"job": _cron_job_record(self.cron_runtime.inspect_job(job_id))}})
            if method.upper() == "PATCH":
                payload = _read_json_bytes(body)
                action = str(payload.get("action") or "").strip().lower()
                if action == "pause":
                    if job_id == "system:dream":
                        return APIResponse(403, {"error": "system_cron_job_cannot_be_paused"})
                    if job_id == "system:proactive-ask":
                        _persist_proactive_ask_config(self.repository.database_path.parent, {"enabled": False})
                        from .api_runtime_console import _proactive_ask_system_job

                        job = _proactive_ask_system_job(self)
                    else:
                        job = self.cron_runtime.pause_job(job_id)
                elif action == "resume":
                    if job_id == "system:dream":
                        return APIResponse(403, {"error": "system_cron_job_cannot_be_resumed"})
                    if job_id == "system:proactive-ask":
                        _persist_proactive_ask_config(self.repository.database_path.parent, {"enabled": True})
                        from .api_runtime_console import _proactive_ask_system_job

                        job = _proactive_ask_system_job(self)
                    else:
                        job = self.cron_runtime.resume_job(job_id)
                else:
                    raise ValueError("cron PATCH requires action=pause or action=resume")
                if job is None:
                    raise ValueError(f"system cron job unavailable: {job_id}")
                return APIResponse(200, {"cron": {"job": job if isinstance(job, Mapping) else _cron_job_record(job)}})
            if method.upper() == "DELETE":
                if job_id in {"system:proactive-ask", "system:dream"}:
                    return APIResponse(403, {"error": "system_cron_jobs_cannot_be_deleted"})
                job = self.cron_runtime.inspect_job(job_id)
                if _cron_job_system_kind(job) is not None:
                    return APIResponse(403, {"error": "system_cron_jobs_cannot_be_deleted"})
                job = self.cron_runtime.remove_job(job_id)
                return APIResponse(200, {"cron": {"job": _cron_job_record(job), "status": "removed"}})
        if len(parts) == 3 and parts[2] == "run" and method.upper() == "POST":
            # Manual-trigger ("Verify") endpoint. Runs the job once right now, goes
            # through the exact same execute → delivery pipeline the scheduler uses,
            # and returns the result synchronously so the dashboard can show it.
            if parts[1] == "system:proactive-ask":
                return APIResponse(200, _jsonable(self.run_proactive_ask_now()))
            if parts[1] == "system:dream":
                return APIResponse(200, _jsonable(self.run_dream_now()))
            return APIResponse(200, _jsonable(self.run_cron_job_now(parts[1])))
    if method.upper() == "PATCH" and len(parts) == 1 and parts[0] == "settings":
        payload = _read_json_bytes(body)
        return APIResponse(200, _jsonable(self.patch_operator_settings(payload)))
    if method.upper() == "PATCH" and len(parts) == 1 and parts[0] == "config":
        payload = _read_json_bytes(body)
        return APIResponse(200, _jsonable(self.patch_operator_global_config(payload)))
    if method.upper() == "POST" and len(parts) == 2 and parts[0] == "mcp" and parts[1] == "discover":
        payload = _read_json_bytes(body)
        return APIResponse(200, _jsonable(self.discover_operator_mcp_server(payload)))
    if len(parts) >= 2 and parts[0] == "mcp" and parts[1] == "servers":
        payload = _read_json_bytes(body)
        if method.upper() in {"POST", "PATCH"} and len(parts) == 2:
            status_code = 200 if method.upper() == "PATCH" else 201
            return APIResponse(status_code, _jsonable(self.sync_operator_mcp_server(payload)))
        if method.upper() == "DELETE" and len(parts) == 2:
            return APIResponse(200, _jsonable(self.delete_operator_mcp_server(payload)))
    if len(parts) >= 2 and parts[0] == "mcp" and parts[1] == "tools":
        payload = _read_json_bytes(body)
        if method.upper() == "POST" and len(parts) == 2:
            return APIResponse(201, _jsonable(self.create_operator_mcp_tool(payload)))
        if method.upper() == "PATCH" and len(parts) == 2:
            return APIResponse(200, _jsonable(self.update_operator_mcp_tool(payload)))
        if method.upper() == "DELETE" and len(parts) == 2:
            return APIResponse(200, _jsonable(self.delete_operator_mcp_tool(payload)))
        if method.upper() == "PATCH" and len(parts) == 3 and parts[2] == "enabled":
            return APIResponse(200, _jsonable(self.set_operator_mcp_tool_enabled(payload)))
    if method.upper() == "POST" and len(parts) == 1 and parts[0] == "gateway":
        payload = _read_json_bytes(body)
        return APIResponse(200, _jsonable(self.gateway_action(payload)))
    if parts and parts[0] == "personal-model":
        return _dispatch_personal_model(self, method, parts[1:], body)
    if method.upper() == "PATCH" and len(parts) == 2 and parts[0] in {"skills", "tools"}:
        payload = _read_json_bytes(body)
        result = self.set_console_item_enabled(
            kind="skill" if parts[0] == "skills" else "tool",
            item_id=parts[1],
            enabled=bool(payload.get("enabled")),
        )
        return APIResponse(200, _jsonable(result))
    return APIResponse(404, {"error": "not_found"})
