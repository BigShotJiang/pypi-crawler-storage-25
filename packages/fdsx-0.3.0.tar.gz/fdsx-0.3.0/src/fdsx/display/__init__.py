"""Terminal display utilities."""
