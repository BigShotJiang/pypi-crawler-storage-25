"""CLI module for fdsx."""
