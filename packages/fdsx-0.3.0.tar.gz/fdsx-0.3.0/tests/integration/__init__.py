"""Integration tests for fdsx."""
