"""Unit tests for fdsx."""
