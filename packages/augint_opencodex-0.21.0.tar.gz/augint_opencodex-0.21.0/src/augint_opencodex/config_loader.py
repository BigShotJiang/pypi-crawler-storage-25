from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import yaml
from dotenv import load_dotenv
from pydantic import BaseModel, ConfigDict, ValidationError

from augint_opencodex.constants import (
    AUGINT_ENV_FILE,
    GLOBAL_CONFIG_FILE,
    MANIFEST_SEARCH_ORDER,
)
from augint_opencodex.manifest import (
    CodexConfig,
    ContentPolicy,
    Manifest,
    ManifestError,
    OpenCodeConfig,
    PiConfig,
    load_manifest_raw,
)


class GlobalConfig(BaseModel):
    """User-level defaults from ~/.augint/.ai-opencodex.yaml.

    Only opencodex-private settings belong here.  Shared .env vars
    (models, AWS, ports) are handled by the .env overlay.
    """

    model_config = ConfigDict(extra="forbid")

    content_policy: ContentPolicy | None = None
    opencode: OpenCodeConfig | None = None
    codex: CodexConfig | None = None
    pi: PiConfig | None = None


def load_env_overlay(project_root: Path) -> None:
    """Load .env files into ``os.environ``.

    Locality principle -- closer files win:
      1. ``~/.augint/.env``  (global, loaded first, lowest .env priority)
      2. ``project_root/.env``  (project, loaded second, wins over global)

    Both layers use ``override=True`` so .env values beat ambient
    ``os.environ`` entries.
    """
    if AUGINT_ENV_FILE.exists():
        load_dotenv(AUGINT_ENV_FILE, override=True)
    project_env = project_root.resolve() / ".env"
    if project_env.exists():
        load_dotenv(project_env, override=True)


def collect_env_overrides() -> dict[str, Any]:
    """Map shared .env vars to a partial manifest-shaped config dict."""
    overrides: dict[str, Any] = {}

    if val := os.environ.get("PRIMARY_CODING_MODEL"):
        _set_nested(overrides, "opencode.default_model", val)
        if "codex" not in overrides:
            _set_nested(overrides, "codex.model", val)
        _set_nested(overrides, "pi.default_model", val)
    if val := os.environ.get("SECONDARY_CODING_MODEL"):
        _set_nested(overrides, "opencode.small_model", val)
    if val := os.environ.get("OLLAMA_PORT"):
        _set_nested(
            overrides,
            "opencode.local_provider.base_url",
            f"http://host.docker.internal:{val}/v1",
        )
    return overrides


def load_effective_config(
    project_root: Path,
    manifest_path: Path | None = None,
    *,
    global_config_path: Path | None = None,
    cli_overrides: dict[str, Any] | None = None,
) -> Manifest:
    """Resolve the full config stack and return a validated manifest.

    Priority (highest wins):
      1. CLI flags
      2. Resolved env vars  (./.env > ~/.augint/.env > os.environ)
      3. Project manifest    (.ai-opencodex.json or .yaml/.yml)
      4. Global config       (~/.augint/.ai-opencodex.yaml)
      5. Hardcoded defaults  (Pydantic model defaults / profile definitions)
    """
    resolved_root = project_root.resolve()

    load_env_overlay(resolved_root)

    global_path = global_config_path or GLOBAL_CONFIG_FILE
    global_cfg = _load_global_config(global_path)

    resolved_manifest_path = _resolve_manifest_path(resolved_root, manifest_path)
    if resolved_manifest_path.exists():
        project_dict = load_manifest_raw(resolved_manifest_path)
    else:
        project_dict = {"version": 1}

    merged = _deep_merge(global_cfg, project_dict)

    env_overrides = collect_env_overrides()
    merged = _deep_merge(merged, env_overrides)

    if cli_overrides:
        merged = _deep_merge(merged, cli_overrides)

    try:
        return Manifest.model_validate(merged)
    except ValidationError as exc:
        raise ManifestError(f"Config validation failed after merging layers: {exc}") from exc


def resolve_manifest_path(project_root: Path, manifest_path: Path | None = None) -> Path:
    """Public wrapper for manifest path resolution."""
    return _resolve_manifest_path(project_root.resolve(), manifest_path)


def _resolve_manifest_path(project_root: Path, manifest_path: Path | None) -> Path:
    if manifest_path is not None:
        return manifest_path.resolve()
    for candidate in MANIFEST_SEARCH_ORDER:
        full = project_root / candidate
        if full.exists():
            return full.resolve()
    return (project_root / MANIFEST_SEARCH_ORDER[0]).resolve()


def _load_global_config(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return {}
    try:
        data = yaml.safe_load(text)
    except yaml.YAMLError:
        return {}
    if not isinstance(data, dict):
        return {}
    GlobalConfig.model_validate(data)
    return data


def _set_nested(target: dict[str, Any], dotted_path: str, value: Any) -> None:
    keys = dotted_path.split(".")
    current = target
    for key in keys[:-1]:
        current = current.setdefault(key, {})
    current[keys[-1]] = value


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    merged = dict(base)
    for key, value in override.items():
        if key in merged and isinstance(merged[key], dict) and isinstance(value, dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged
