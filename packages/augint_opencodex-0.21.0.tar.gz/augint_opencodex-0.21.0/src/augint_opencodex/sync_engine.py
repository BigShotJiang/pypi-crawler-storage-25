from __future__ import annotations

import json
import tomllib
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any, Literal

from augint_opencodex.config_loader import load_effective_config, resolve_manifest_path
from augint_opencodex.connectivity import discover_bedrock_models, discover_models
from augint_opencodex.ignore import ExcludeUpdate, ensure_git_exclude
from augint_opencodex.manifest import ModelEntry, PiModelEntry
from augint_opencodex.profiles import ResolvedPolicy, resolve_policy
from augint_opencodex.renderer import RenderedFile, managed_file_paths, render_project

ApplyMode = Literal["write", "dry-run", "check"]
ProjectAction = Literal["init", "update"]


@dataclass(frozen=True)
class ProjectReport:
    """The result of creating or updating managed project files."""

    action: ProjectAction
    mode: ApplyMode
    policy: ResolvedPolicy
    changed_files: tuple[Path, ...]
    stale_files: tuple[Path, ...]
    written_files: tuple[Path, ...]
    removed_files: tuple[Path, ...]
    unchanged_files: tuple[Path, ...]
    skipped_files: tuple[Path, ...]
    exclude_update: ExcludeUpdate

    @property
    def needs_changes(self) -> bool:
        if self.action == "init":
            return bool(self.changed_files) or self.exclude_update.needs_update
        return bool(self.changed_files or self.stale_files) or self.exclude_update.needs_update


SyncReport = ProjectReport


def init_project(
    project_root: Path,
    manifest_path: Path | None = None,
    *,
    mode: Literal["write", "dry-run"] = "write",
    global_config_path: Path | None = None,
    cli_overrides: dict[str, Any] | None = None,
) -> ProjectReport:
    """Create any missing managed files without overwriting existing ones."""

    return _reconcile_project(
        project_root,
        manifest_path,
        action="init",
        mode=mode,
        global_config_path=global_config_path,
        cli_overrides=cli_overrides,
    )


def update_project(
    project_root: Path,
    manifest_path: Path | None = None,
    *,
    mode: ApplyMode = "write",
    global_config_path: Path | None = None,
    cli_overrides: dict[str, Any] | None = None,
) -> ProjectReport:
    """Merge rendered project files into the repository."""

    return _reconcile_project(
        project_root,
        manifest_path,
        action="update",
        mode=mode,
        global_config_path=global_config_path,
        cli_overrides=cli_overrides,
    )


def _reconcile_project(
    project_root: Path,
    manifest_path: Path | None,
    *,
    action: ProjectAction,
    mode: ApplyMode,
    global_config_path: Path | None = None,
    cli_overrides: dict[str, Any] | None = None,
) -> ProjectReport:
    resolved_root = project_root.resolve()
    manifest = load_effective_config(
        resolved_root,
        manifest_path=manifest_path,
        global_config_path=global_config_path,
        cli_overrides=cli_overrides,
    )
    resolved_manifest_path = resolve_manifest_path(resolved_root, manifest_path)
    policy = resolve_policy(manifest, resolved_root, resolved_manifest_path)
    policy = _inject_discovered_models(policy)
    rendered_files = render_project(policy)

    changed_files: list[Path] = []
    stale_files: list[Path] = []
    written_files: list[Path] = []
    removed_files: list[Path] = []
    unchanged_files: list[Path] = []
    skipped_files: list[Path] = []

    for rendered_file in rendered_files:
        target_path = resolved_root / rendered_file.path
        current_content = target_path.read_text(encoding="utf-8") if target_path.exists() else None

        if action == "init" and current_content is not None:
            skipped_files.append(rendered_file.path)
            continue

        desired_content = _desired_content(rendered_file, current_content, action)
        if current_content == desired_content:
            unchanged_files.append(rendered_file.path)
            continue

        changed_files.append(rendered_file.path)
        if mode == "write":
            target_path.parent.mkdir(parents=True, exist_ok=True)
            target_path.write_text(desired_content, encoding="utf-8")
            written_files.append(rendered_file.path)

    if action == "update":
        expected_paths = {rendered_file.path for rendered_file in rendered_files}
        for managed_path in managed_file_paths():
            if managed_path in expected_paths:
                continue

            target_path = resolved_root / managed_path
            if not target_path.exists():
                continue

            stale_files.append(managed_path)
            if mode == "write":
                target_path.unlink()
                _prune_empty_parent_dirs(target_path.parent, stop_at=resolved_root)
                removed_files.append(managed_path)

    exclude_update = ensure_git_exclude(resolved_root, write=mode == "write")
    return ProjectReport(
        action=action,
        mode=mode,
        policy=policy,
        changed_files=tuple(changed_files),
        stale_files=tuple(stale_files),
        written_files=tuple(written_files),
        removed_files=tuple(removed_files),
        unchanged_files=tuple(unchanged_files),
        skipped_files=tuple(skipped_files),
        exclude_update=exclude_update,
    )


def _desired_content(
    rendered_file: RenderedFile,
    current_content: str | None,
    action: ProjectAction,
) -> str:
    if current_content is None or action == "init":
        return rendered_file.content
    return _merge_content(rendered_file, current_content)


def _merge_content(rendered_file: RenderedFile, current_content: str) -> str:
    if rendered_file.merge_strategy == "json":
        return _merge_json(current_content, rendered_file.content)
    if rendered_file.merge_strategy == "toml":
        return _merge_toml(current_content, rendered_file.content)
    return rendered_file.content


def _merge_json(current_content: str, rendered_content: str) -> str:
    try:
        current_payload = json.loads(current_content)
        rendered_payload = json.loads(rendered_content)
    except json.JSONDecodeError:
        return rendered_content
    merged_payload = _deep_merge(current_payload, rendered_payload)
    return json.dumps(merged_payload, indent=2) + "\n"


def _merge_toml(current_content: str, rendered_content: str) -> str:
    try:
        current_payload = tomllib.loads(current_content)
        rendered_payload = tomllib.loads(rendered_content)
    except tomllib.TOMLDecodeError:
        return rendered_content

    merged_payload = _deep_merge(current_payload, rendered_payload)
    header = _leading_comment_block(rendered_content)
    body = _dump_toml(merged_payload).rstrip("\n")
    if header:
        return f"{header}\n{body}\n"
    return body + "\n"


def _deep_merge(existing: Any, incoming: Any) -> Any:
    if isinstance(existing, dict) and isinstance(incoming, dict):
        merged = dict(existing)
        for key, value in incoming.items():
            if key in merged:
                merged[key] = _deep_merge(merged[key], value)
            else:
                merged[key] = value
        return merged
    return incoming


def _leading_comment_block(content: str) -> str:
    lines = content.splitlines()
    header_lines: list[str] = []
    saw_comment = False
    for line in lines:
        if line.startswith("#"):
            header_lines.append(line)
            saw_comment = True
            continue
        if saw_comment and line == "":
            header_lines.append(line)
            continue
        break
    return "\n".join(header_lines).rstrip("\n")


def _dump_toml(payload: dict[str, Any]) -> str:
    lines = _dump_toml_table(payload)
    return "\n".join(lines).rstrip("\n") + "\n"


def _dump_toml_table(payload: dict[str, Any], prefix: str | None = None) -> list[str]:
    lines: list[str] = []
    if prefix is not None:
        lines.append(f"[{prefix}]")

    scalar_items = [(key, value) for key, value in payload.items() if not isinstance(value, dict)]
    table_items = [(key, value) for key, value in payload.items() if isinstance(value, dict)]

    for key, value in scalar_items:
        lines.append(f"{key} = {_format_toml_value(value)}")

    for index, (key, value) in enumerate(table_items):
        if lines:
            lines.append("")
        child_prefix = f"{prefix}.{key}" if prefix else key
        lines.extend(_dump_toml_table(value, child_prefix))
        if index < len(table_items) - 1:
            lines.append("")

    return lines


def _format_toml_value(value: Any) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, str):
        return json.dumps(value)
    if isinstance(value, int) and not isinstance(value, bool):
        return str(value)
    if isinstance(value, float):
        return repr(value)
    if isinstance(value, list):
        return "[" + ", ".join(_format_toml_value(item) for item in value) + "]"
    raise TypeError(f"Unsupported TOML value: {type(value)!r}")


def _inject_discovered_models(policy: ResolvedPolicy) -> ResolvedPolicy:
    """Auto-populate opencode and pi models from Ollama/Bedrock when none are configured."""
    local_provider = policy.opencode_local_provider
    ollama_discovery = None

    if local_provider is not None:
        provider_name = local_provider.name.lower()

        if not policy.opencode_models:
            ollama_discovery = discover_models(local_provider.base_url)
            if ollama_discovery.model_ids:
                updates: dict[str, Any] = {
                    "opencode_models": tuple(ModelEntry(id=m) for m in ollama_discovery.model_ids),
                }
                if not policy.opencode_default_model:
                    updates["opencode_default_model"] = (
                        f"{provider_name}/{ollama_discovery.model_ids[0]}"
                    )
                policy = replace(policy, **updates)

        if policy.opencode_default_model and "/" not in policy.opencode_default_model:
            policy = replace(
                policy,
                opencode_default_model=f"{provider_name}/{policy.opencode_default_model}",
            )
        if policy.opencode_small_model and "/" not in policy.opencode_small_model:
            policy = replace(
                policy,
                opencode_small_model=f"{provider_name}/{policy.opencode_small_model}",
            )

        if policy.pi_enabled and not policy.pi_models:
            if ollama_discovery is None:
                ollama_discovery = discover_models(local_provider.base_url)
            if ollama_discovery.model_ids:
                pi_updates: dict[str, Any] = {
                    "pi_models": tuple(
                        PiModelEntry(id=m, provider=provider_name)
                        for m in ollama_discovery.model_ids
                    ),
                }
                if not policy.pi_default_model:
                    pi_updates["pi_default_model"] = ollama_discovery.model_ids[0]
                policy = replace(policy, **pi_updates)

    if policy.opencode_bedrock_enabled and not policy.opencode_bedrock_models:
        bedrock_discovery = discover_bedrock_models()
        if bedrock_discovery.model_ids:
            policy = replace(
                policy,
                opencode_bedrock_models=bedrock_discovery.model_ids,
            )

    return policy


def _prune_empty_parent_dirs(path: Path, *, stop_at: Path) -> None:
    current = path
    resolved_stop = stop_at.resolve()
    while current != resolved_stop and current.exists():
        try:
            current.rmdir()
        except OSError:
            break
        current = current.parent
