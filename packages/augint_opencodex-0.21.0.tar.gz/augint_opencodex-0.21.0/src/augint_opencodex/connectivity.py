from __future__ import annotations

import json
import subprocess
import urllib.error
import urllib.request
from dataclasses import dataclass, field

DEFAULT_OLLAMA_API_URL = "http://localhost:11434"
DEFAULT_OPENAI_COMPAT_URL = "http://localhost:11434/v1"


def _resolve_for_host(url: str) -> str:
    """Resolve the best reachable host for discovery requests.

    The generated config uses host.docker.internal so agents running in Docker
    can reach Ollama on the host.  In WSL2 this address also works natively,
    so we try it first and only fall back to localhost when it is unreachable.
    """
    if "host.docker.internal" not in url:
        return url
    try:
        probe = _ollama_root(url)
        req = urllib.request.Request(probe, method="HEAD")
        urllib.request.urlopen(req, timeout=1.5)  # nosec B310  # nosemgrep: python.lang.security.audit.dynamic-urllib-use-detected.dynamic-urllib-use-detected
        return url
    except (urllib.error.URLError, OSError):
        return url.replace("host.docker.internal", "localhost")


@dataclass(frozen=True)
class ConnectivityResult:
    """Result of a local LLM reachability check."""

    reachable: bool
    checked_url: str
    error: str | None = None


@dataclass(frozen=True)
class ModelDiscoveryResult:
    """Result of querying the OpenAI-compatible /v1/models endpoint."""

    model_ids: tuple[str, ...] = field(default_factory=tuple)
    error: str | None = None


def discover_models(base_url: str, timeout: float = 3.0) -> ModelDiscoveryResult:
    """Return model IDs from the OpenAI-compatible /v1/models endpoint."""
    models_url = _resolve_for_host(base_url.rstrip("/")) + "/models"
    if not models_url.startswith(("http://", "https://")):
        return ModelDiscoveryResult(error="unsupported scheme")
    try:
        req = urllib.request.Request(models_url, method="GET")
        with urllib.request.urlopen(req, timeout=timeout) as resp:  # nosec B310  # nosemgrep: python.lang.security.audit.dynamic-urllib-use-detected.dynamic-urllib-use-detected
            data = json.loads(resp.read())
        ids = tuple(str(m["id"]) for m in data.get("data", []))
        return ModelDiscoveryResult(model_ids=ids)
    except (urllib.error.URLError, OSError, KeyError, json.JSONDecodeError) as exc:
        return ModelDiscoveryResult(error=str(exc))


def check_local_provider(base_url: str, timeout: float = 3.0) -> ConnectivityResult:
    """Check whether the local LLM endpoint is reachable.

    Derives the root URL by stripping a trailing ``/v1`` path segment so the
    check targets the Ollama health endpoint rather than the API base.
    """
    root_url = _resolve_for_host(_ollama_root(base_url))
    if not root_url.startswith(("http://", "https://")):
        return ConnectivityResult(
            reachable=False,
            checked_url=root_url,
            error="unsupported scheme: only http:// and https:// are accepted",
        )
    try:
        req = urllib.request.Request(root_url, method="GET")
        with urllib.request.urlopen(req, timeout=timeout):  # nosec B310  # nosemgrep: python.lang.security.audit.dynamic-urllib-use-detected.dynamic-urllib-use-detected
            pass
        return ConnectivityResult(reachable=True, checked_url=root_url)
    except urllib.error.URLError as exc:
        return ConnectivityResult(reachable=False, checked_url=root_url, error=str(exc.reason))
    except OSError as exc:
        return ConnectivityResult(reachable=False, checked_url=root_url, error=str(exc))


@dataclass(frozen=True)
class BedrockDiscoveryResult:
    """Result of querying AWS Bedrock for available inference profiles."""

    model_ids: tuple[str, ...] = field(default_factory=tuple)
    error: str | None = None


def discover_bedrock_models(timeout: float = 15.0) -> BedrockDiscoveryResult:
    """Return model IDs from AWS Bedrock system-defined inference profiles."""
    cmd = [
        "aws",
        "bedrock",
        "list-inference-profiles",
        "--type-equals",
        "SYSTEM_DEFINED",
        "--output",
        "json",
    ]
    try:
        result = subprocess.run(  # nosec B603 B607
            cmd, capture_output=True, text=True, timeout=timeout
        )
        if result.returncode != 0:
            return BedrockDiscoveryResult(
                error=result.stderr.strip() or f"exit code {result.returncode}"
            )
        data = json.loads(result.stdout)
        ids = tuple(
            p["inferenceProfileId"]
            for p in data.get("inferenceProfileSummaries", [])
            if p.get("status") == "ACTIVE"
        )
        return BedrockDiscoveryResult(model_ids=ids)
    except FileNotFoundError:
        return BedrockDiscoveryResult(error="aws CLI not found")
    except subprocess.TimeoutExpired:
        return BedrockDiscoveryResult(error="timed out")
    except (json.JSONDecodeError, KeyError) as exc:
        return BedrockDiscoveryResult(error=str(exc))


def _ollama_root(base_url: str) -> str:
    url = base_url.rstrip("/")
    if url.endswith("/v1"):
        url = url[:-3]
    return url
