from __future__ import annotations

import json
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from augint_opencodex.constants import INSTRUCTION_FILE, MANAGED_FILE_PATHS
from augint_opencodex.profiles import ResolvedPolicy
from augint_opencodex.template_loader import load_template, render_template

OPENCODE_SCHEMA_URL = "https://opencode.ai/config.json"

# Watcher patterns are static — same noise to skip in every repo.
DEFAULT_WATCHER_IGNORE: tuple[str, ...] = (
    "**/.git/**",
    "**/node_modules/**",
    "**/.venv/**",
    "**/__pycache__/**",
    "**/dist/**",
    "**/build/**",
    "**/.next/**",
    "**/target/**",
    "**/.terraform/**",
    "**/.mypy_cache/**",
    "**/.ruff_cache/**",
    "**/.pytest_cache/**",
)

BASH_PATTERNS: dict[str, str] = {
    "rm -rf /*": "deny",
    "rm -rf /": "deny",
    "rm -rf ~": "deny",
    "rm -rf ~/*": "deny",
    "sudo *": "deny",
    "git push --force*": "deny",
    "git push -f*": "deny",
    ":(){ :|:& };:": "deny",
    "git push *": "ask",
    "gh pr merge *": "ask",
    "gh release create *": "ask",
    "*": "allow",
}

REVIEW_AGENT_PROMPT = (
    "You are a code reviewer. Lead with risks and concerns first, "
    "then improvements. Be blunt, not diplomatic. No emojis. "
    "Cite file paths with line numbers when flagging issues."
)

COMMIT_COMMAND_TEMPLATE = (
    "Review the staged changes and propose a concise Conventional Commit "
    "message. Do not run git commit yourself.\n\n"
    "Staged diff:\n"
    "!`git diff --cached`\n\n"
    "Recent commits for style reference:\n"
    "!`git log -5 --oneline`"
)

MergeStrategy = Literal["replace", "json", "toml"]


@dataclass(frozen=True)
class RenderedFile:
    """A generated file, its content, and its update strategy."""

    path: Path
    content: str
    merge_strategy: MergeStrategy = "replace"


def render_project(policy: ResolvedPolicy) -> tuple[RenderedFile, ...]:
    """Render all managed project files for the active policy."""

    files = [
        RenderedFile(
            Path(".codex/config.toml"),
            _render_codex_config(policy),
            merge_strategy="toml",
        ),
        RenderedFile(INSTRUCTION_FILE, _render_ai_opencodex_markdown(policy)),
        RenderedFile(Path(".agents/skills/README.md"), _render_skills_readme()),
    ]

    if policy.opencode_enabled:
        files.append(
            RenderedFile(
                Path("opencode.json"),
                _render_opencode_json(policy),
                merge_strategy="json",
            )
        )

    if policy.pi_enabled:
        files.append(
            RenderedFile(
                Path(".pi/settings.json"),
                _render_pi_settings(policy),
                merge_strategy="json",
            )
        )
        files.append(
            RenderedFile(
                Path(".pi/skills/augint-workflow/SKILL.md"),
                _render_pi_workflow_skill(),
            )
        )
        files.append(
            RenderedFile(
                Path(".pi/skills/patch-pi-studio/SKILL.md"),
                _render_patch_pi_studio_skill(),
            )
        )

    if policy.org_python_library:
        files.append(
            RenderedFile(
                Path(".agents/skills/org-python-tooling/SKILL.md"),
                _render_org_python_tooling_skill(),
            )
        )

    return tuple(files)


def managed_file_paths() -> tuple[Path, ...]:
    """Return all paths managed by this tool."""

    return MANAGED_FILE_PATHS


def _render_codex_config(policy: ResolvedPolicy) -> str:
    provider_comment = ""
    if policy.codex_provider == "aws":
        provider_comment = (
            '# provider = "aws" — runtime launcher (augint-shell) selects Bedrock auth.\n'
        )
    model_line = f'model = "{policy.codex_model}"\n' if policy.codex_model else ""
    return render_template(
        "codex-config.toml.tpl",
        provider_comment=provider_comment,
        codex_web_search=policy.codex_web_search,
        codex_approval_policy=policy.codex_approval_policy,
        codex_sandbox_mode=policy.codex_sandbox_mode,
        model_line=model_line,
    )


def _render_ai_opencodex_markdown(policy: ResolvedPolicy) -> str:
    return render_template(
        "ai-opencodex.md.tpl",
        working_contract=_bullets(policy.instruction_bullets),
        content_policy=_render_content_policy(policy),
        blocked_paths=_render_blocked_paths(policy),
        shell_guardrails=_render_shell_guardrails(policy),
        org_python_tooling_section=_render_org_python_tooling_section(policy),
        opencode_disabled_section=_render_opencode_disabled_section(policy),
        pi_section=_render_pi_section(policy),
    )


def _render_opencode_json(policy: ResolvedPolicy) -> str:
    config: dict[str, object] = {"$schema": OPENCODE_SCHEMA_URL}
    config["instructions"] = _opencode_instructions(policy)
    config["permission"] = _opencode_permission(policy)

    providers = _opencode_providers(policy)
    if providers:
        config["provider"] = providers
        config["enabled_providers"] = list(providers.keys())

    if policy.opencode_default_model:
        config["model"] = policy.opencode_default_model
    if policy.opencode_small_model:
        config["small_model"] = policy.opencode_small_model

    config["agent"] = _opencode_default_agents()
    config["command"] = _opencode_default_commands()
    config["watcher"] = {"ignore": list(DEFAULT_WATCHER_IGNORE)}
    config["compaction"] = {"auto": True, "prune": True, "reserved": 16000}
    config["share"] = "disabled"
    config["autoupdate"] = "notify"
    config["snapshot"] = True

    _apply_extras(config, policy.opencode_extras)

    return json.dumps(config, indent=2) + "\n"


def _opencode_instructions(policy: ResolvedPolicy) -> list[str]:
    instructions = [
        ".agents/.ai-opencodex.md",
        "Treat .agents/.ai-opencodex.md and .codex/config.toml as the canonical local project policy.",
        "This repository intentionally avoids a root AGENTS.md so Codex and OpenCode follow the same generated instructions artifact.",
        "Use .agents/skills/ when shared reusable skills are available.",
    ]
    if policy.blocked_paths:
        instructions.append(
            "Avoid blocked paths called out in .agents/.ai-opencodex.md unless the user explicitly changes policy."
        )
    return instructions


def _opencode_permission(_policy: ResolvedPolicy) -> dict[str, object]:
    return {
        "read": "allow",
        "edit": "allow",
        "glob": "allow",
        "grep": "allow",
        "list": "allow",
        "bash": dict(BASH_PATTERNS),
        "skill": "allow",
        "webfetch": "allow",
        "websearch": "allow",
        "external_directory": "allow",
        "doom_loop": "ask",
    }


def _opencode_providers(policy: ResolvedPolicy) -> dict[str, object]:
    providers: dict[str, object] = {}
    if policy.opencode_local_provider is not None:
        local_provider = policy.opencode_local_provider
        provider_key = local_provider.name.lower()
        provider_entry: dict[str, object] = {"options": {"baseURL": local_provider.base_url}}
        if policy.opencode_models:
            provider_entry["models"] = {
                entry.id: ({"name": entry.name} if entry.name else {})
                for entry in policy.opencode_models
            }
        providers[provider_key] = provider_entry
    if policy.opencode_bedrock_enabled:
        bedrock_entry: dict[str, object] = {}
        if policy.opencode_bedrock_models:
            bedrock_entry["models"] = {model_id: {} for model_id in policy.opencode_bedrock_models}
        providers["amazon-bedrock"] = bedrock_entry
    if policy.opencode_openai_enabled:
        providers["openai"] = {}
    return providers


def _opencode_default_agents() -> dict[str, object]:
    return {
        "review": {
            "description": "Read-only code reviewer. Risks first, then improvements.",
            "mode": "subagent",
            "temperature": 0.1,
            "permission": {"edit": "deny", "bash": "deny", "write": "deny"},
            "prompt": REVIEW_AGENT_PROMPT,
        }
    }


def _opencode_default_commands() -> dict[str, object]:
    return {
        "commit": {
            "description": "Draft a Conventional Commit message from the staged diff",
            "agent": "build",
            "template": COMMIT_COMMAND_TEMPLATE,
        }
    }


def _apply_extras(config: dict[str, object], extras: tuple[str, ...]) -> None:
    plugins: list[str] = []
    for extra in extras:
        handler = _EXTRAS_HANDLERS.get(extra)
        if handler is None:
            # Pydantic Literal validation should have rejected this already.
            raise ValueError(f"Unknown opencode extra: {extra!r}")
        handler(config, plugins)
    if plugins:
        existing = config.get("plugin")
        if isinstance(existing, list):
            existing.extend(plugins)
        else:
            config["plugin"] = plugins


def _extra_serve(config: dict[str, object], _plugins: list[str]) -> None:
    config["server"] = {"port": 4096, "hostname": "127.0.0.1"}


def _extra_lsp_pyright(config: dict[str, object], _plugins: list[str]) -> None:
    lsp = config.setdefault("lsp", {})
    if isinstance(lsp, dict):
        lsp["pyright"] = {
            "disabled": False,
            "initialization": {"python": {"analysis": {"autoImportCompletions": False}}},
        }


def _extra_formatter_off(config: dict[str, object], _plugins: list[str]) -> None:
    config["formatter"] = False


ExtraHandler = Callable[[dict[str, object], list[str]], None]


def _extra_plugin(package: str) -> ExtraHandler:
    def handler(_config: dict[str, object], plugins: list[str]) -> None:
        if package not in plugins:
            plugins.append(package)

    return handler


_EXTRAS_HANDLERS: dict[str, ExtraHandler] = {
    "serve": _extra_serve,
    "lsp_pyright": _extra_lsp_pyright,
    "formatter_off": _extra_formatter_off,
    "plugin_snip": _extra_plugin("opencode-snip"),
    "plugin_dcp": _extra_plugin("opencode-dynamic-context-pruning"),
    "plugin_oh_my": _extra_plugin("oh-my-opencode"),
    "plugin_pty": _extra_plugin("opencode-pty"),
    "plugin_vibeguard": _extra_plugin("opencode-vibeguard"),
    "plugin_plannotator": _extra_plugin("@plannotator/opencode@latest"),
}


def _render_pi_settings(policy: ResolvedPolicy) -> str:
    settings: dict[str, object] = {}

    if policy.pi_default_model:
        settings["defaultModel"] = policy.pi_default_model
        model_provider = next(
            (m.provider for m in policy.pi_models if m.id == policy.pi_default_model),
            None,
        )
        if model_provider:
            settings["defaultProvider"] = model_provider
        elif policy.pi_bedrock_enabled:
            settings["defaultProvider"] = "amazon-bedrock"
    elif policy.pi_bedrock_enabled and policy.pi_bedrock_default_model:
        settings["defaultProvider"] = "amazon-bedrock"
        settings["defaultModel"] = policy.pi_bedrock_default_model
    elif policy.pi_models:
        settings["defaultProvider"] = policy.pi_models[0].provider

    settings["defaultThinkingLevel"] = "medium" if policy.pi_thinking else "off"
    settings["shellPath"] = "/bin/bash"

    settings["compaction"] = {
        "enabled": True,
        "reserveTokens": 16384,
        "keepRecentTokens": 20000,
    }
    settings["enableInstallTelemetry"] = False

    if policy.pi_packages:
        settings["packages"] = list(policy.pi_packages)

    return json.dumps(settings, indent=2) + "\n"


def _render_pi_workflow_skill() -> str:
    return load_template("skills/pi-workflow/SKILL.md")


def _render_patch_pi_studio_skill() -> str:
    return load_template("skills/patch-pi-studio/SKILL.md")


def _render_skills_readme() -> str:
    return load_template("skills/README.md")


def _render_org_python_tooling_skill() -> str:
    return load_template("skills/org-python-tooling/SKILL.md")


def _bullets(lines: tuple[str, ...] | list[str]) -> str:
    return "\n".join(f"- {line}" for line in lines)


def _render_content_policy(policy: ResolvedPolicy) -> str:
    items = [
        (
            "Do not use emojis in documentation or generated text unless explicitly requested."
            if policy.no_emojis
            else "Emoji use is allowed."
        ),
        (
            "Do not mention AI in commit messages, code comments, or generated code unless explicitly requested."
            if policy.no_ai_mentions
            else "AI mentions are allowed when they improve clarity."
        ),
    ]
    return _bullets(items)


def _render_blocked_paths(policy: ResolvedPolicy) -> str:
    return _bullets([f"`{blocked_path}`" for blocked_path in policy.blocked_paths])


def _render_shell_guardrails(policy: ResolvedPolicy) -> str:
    items: list[str] = []
    items.extend(f"Ask before running `{pattern}`" for pattern in policy.ask_patterns)
    items.extend(f"Deny `{pattern}`" for pattern in policy.deny_patterns)
    if not items:
        items.append("No additional shell guardrails were configured.")
    return _bullets(items)


def _render_org_python_tooling_section(policy: ResolvedPolicy) -> str:
    if not policy.org_python_library:
        return ""
    return (
        "\n\n## Organizational Python Tooling Standard\n"
        "- Use a `uv`-first workflow for dependency management, locking, and builds.\n"
        "- Keep Python packages in `src/` and expose CLIs through `[project.scripts]`.\n"
        "- Preserve `ruff`, `mypy`, `pytest`, coverage, and `pre-commit` as standard tooling.\n"
        "- Keep Conventional Commit discipline and semantic-release-compatible versioning in place.\n"
        "- Maintain code-quality, security, compliance, and build-validation jobs in CI.\n"
        "- Keep a stable task surface such as `install`, `test`, `format`, `typecheck`, `security`, and `build`.\n"
    )


def _render_opencode_disabled_section(policy: ResolvedPolicy) -> str:
    if policy.opencode_enabled:
        return ""
    return (
        "\n\n## OpenCode\n"
        "- OpenCode output is disabled by `opencode.enabled = false` in the manifest.\n"
    )


def _render_pi_section(policy: ResolvedPolicy) -> str:
    if not policy.pi_enabled:
        return ""
    lines = [
        "\n\n## Pi Coding Agent",
        "- Pi project settings are managed at `.pi/settings.json` (generated).",
        "- Pi skills are distributed to `.pi/skills/` (generated).",
        "- Ollama provider registration lives in `~/.pi/agent/models.json` (global, managed by augint-shell).",
        "- Pi reads `AGENTS.md` natively and falls back to `CLAUDE.md`.",
        "- Precedence: `.pi/SYSTEM.md` (replaces system prompt) > `.pi/APPEND_SYSTEM.md` (appends) > `AGENTS.md` > `CLAUDE.md`.",
    ]
    if policy.pi_packages:
        lines.append(f"- Managed packages: {', '.join(f'`{pkg}`' for pkg in policy.pi_packages)}.")
    return "\n".join(lines) + "\n"
