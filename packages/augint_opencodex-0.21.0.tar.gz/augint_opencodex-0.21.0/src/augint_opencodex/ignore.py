from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

GENERATED_IGNORE_PATTERNS = (
    "/.ai-codex.md",
    "/.codex/",
    "/opencode.json",
    "/.opencode/",
    "/.pi/",
    "/.agents/",
)
BLOCK_START = "# BEGIN ai-opencodex generated"
BLOCK_END = "# END ai-opencodex generated"
LEGACY_BLOCK_START = "# BEGIN ai-codex generated"
LEGACY_BLOCK_END = "# END ai-codex generated"


@dataclass(frozen=True)
class ExcludeUpdate:
    """The state of `.git/info/exclude` for generated files."""

    path: Path | None
    available: bool
    needs_update: bool
    updated: bool


def ensure_git_exclude(project_root: Path, *, write: bool) -> ExcludeUpdate:
    """Add or refresh the generated ignore block in `.git/info/exclude`."""

    exclude_path = project_root / ".git" / "info" / "exclude"
    if not exclude_path.parent.exists():
        return ExcludeUpdate(
            path=exclude_path,
            available=False,
            needs_update=False,
            updated=False,
        )

    existing = exclude_path.read_text(encoding="utf-8") if exclude_path.exists() else ""
    desired = _merge_block(existing)
    needs_update = desired != existing

    if write and needs_update:
        exclude_path.parent.mkdir(parents=True, exist_ok=True)
        exclude_path.write_text(desired, encoding="utf-8")

    return ExcludeUpdate(
        path=exclude_path,
        available=True,
        needs_update=needs_update,
        updated=write and needs_update,
    )


def _merge_block(existing: str) -> str:
    generated_block = "\n".join(
        (
            BLOCK_START,
            *GENERATED_IGNORE_PATTERNS,
            BLOCK_END,
        )
    )

    legacy_markers = (
        (BLOCK_START, BLOCK_END),
        (LEGACY_BLOCK_START, LEGACY_BLOCK_END),
    )
    for start_marker, end_marker in legacy_markers:
        if start_marker not in existing or end_marker not in existing:
            continue
        start = existing.index(start_marker)
        end = existing.index(end_marker, start) + len(end_marker)
        updated = existing[:start].rstrip("\n")
        suffix = existing[end:].lstrip("\n")
        pieces = [part for part in (updated, generated_block, suffix) if part]
        return "\n\n".join(pieces) + "\n"

    stripped_existing = existing.strip("\n")
    pieces = [part for part in (stripped_existing, generated_block) if part]
    return "\n\n".join(pieces) + "\n"
