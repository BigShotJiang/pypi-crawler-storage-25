# AI OpenCodex Project Instructions

This file is generated from `.ai-opencodex.yaml` by `ai-opencodex update`.
This repository uses `.agents/.ai-opencodex.md` as its generated repo-local instructions file.
Avoid a root `AGENTS.md` here because Codex gives `AGENTS.md` precedence over fallback filenames in the same directory.
Edit the manifest and re-run the tool instead of editing this file directly.

## Working Contract
$working_contract

## Content Policy
$content_policy

## Blocked Paths
$blocked_paths
- These are instruction-level safeguards here; use stronger runtime controls when a path must be truly inaccessible.

## Shell Guardrails
$shell_guardrails$org_python_tooling_section$opencode_disabled_section$pi_section
