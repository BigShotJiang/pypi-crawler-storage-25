---
name: patch-pi-studio
description: Patch pi-studio to bind to all network interfaces so Studio is accessible from outside the container.
metadata:
  short-description: Make pi-studio accessible from container host
---

# Patch pi-studio for Container Access

Run this after pi-studio is installed to make Studio accessible from outside the container (e.g., from a Windows host browser).

## Steps

1. Locate the pi-studio entry point:

```bash
PI_STUDIO_INDEX="$(node -e "console.log(require.resolve('pi-studio/index.ts'))")"
```

If not installed, install first:

```bash
pi install npm:pi-studio
```

2. Apply the patches below to `$PI_STUDIO_INDEX`.

### Patch A — bind to all interfaces

Find:
```typescript
server.listen(0, "127.0.0.1");
```
Replace with:
```typescript
server.listen(0, "0.0.0.0");
```

### Patch B — add configurable host for URLs

Find the `buildStudioUrl` function. Immediately before it, add:

```typescript
function getStudioHost(): string {
   return process.env.PI_STUDIO_HOST ?? "127.0.0.1";
}
```

Inside `buildStudioUrl`, find:
```typescript
return `http://127.0.0.1:${port}/?${params.toString()}`;
```
Replace with:
```typescript
const host = getStudioHost();
return `http://${host}:${port}/?${params.toString()}`;
```

3. Verify patches applied:

```bash
grep -n '0\.0\.0\.0\|getStudioHost\|PI_STUDIO_HOST' "$PI_STUDIO_INDEX"
```

Expected: `getStudioHost` definition, `PI_STUDIO_HOST` reference, and `server.listen(0, "0.0.0.0")`.

## Environment Variables

Set `PI_STUDIO_HOST` to the address shown in Studio URLs. Default is `127.0.0.1`. For container use, set to `0.0.0.0` or the container IP visible to the host.
