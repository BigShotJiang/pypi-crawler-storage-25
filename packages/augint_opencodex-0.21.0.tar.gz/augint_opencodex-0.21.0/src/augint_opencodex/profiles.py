from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path

from augint_opencodex.manifest import (
    LocalProvider,
    Manifest,
    ModelEntry,
    PiModelEntry,
)


def _detect_org_python_library(project_root: Path) -> bool:
    return (project_root / "uv.lock").exists() or (project_root / "pyproject.toml").exists()


DEFAULT_BLOCKED_PATHS = (
    "**/secrets/**",
    "**/*.pem",
    "**/terraform.tfstate*",
)

DEFAULT_ASK_PATTERNS = (
    "aws *",
    "terraform *",
    "kubectl *",
    "git push *",
)

DEFAULT_DENY_PATTERNS: tuple[str, ...] = ()

DEFAULT_APPROVAL_POLICY = "on-request"
DEFAULT_SANDBOX_MODE = "workspace-write"
DEFAULT_WEB_SEARCH = "live"

DEFAULT_PI_PACKAGES = (
    "npm:@aliou/pi-guardrails",
    "npm:pi-extmgr",
    "npm:pi-ask-user",
    "npm:pi-web-access",
    "npm:pi-powerline-footer",
    "npm:pi-studio",
)

BASELINE_INSTRUCTION_BULLETS = (
    "Use `.ai-opencodex.yaml` as the tracked source of truth for local agent configuration.",
    "Use `.agents/.ai-opencodex.md` as the generated repo instruction file.",
    "Avoid a root `AGENTS.md` in the repository root because it shadows fallback instruction filenames for Codex discovery.",
    "Treat `.codex/config.toml`, `opencode.json`, `.pi/`, and `.agents/skills/` as generated local artifacts.",
    "Re-run `ai-opencodex update` after manifest changes instead of editing generated files by hand.",
    "Pi, Codex, and OpenCode all read AGENTS.md natively; `.agents/.ai-opencodex.md` is the unified instruction source.",
    "Prefer practical, minimal changes that preserve the existing repository's patterns.",
    "Treat shell guardrails as real approval prompts for risky operational commands.",
)


@dataclass(frozen=True)
class ResolvedPolicy:
    """Effective policy after layering baseline and manifest settings."""

    project_root: Path
    manifest_path: Path
    blocked_paths: tuple[str, ...]
    ask_patterns: tuple[str, ...]
    deny_patterns: tuple[str, ...]
    no_emojis: bool
    no_ai_mentions: bool
    org_python_library: bool
    opencode_enabled: bool
    opencode_default_model: str | None
    opencode_small_model: str | None
    opencode_local_provider: LocalProvider | None
    opencode_models: tuple[ModelEntry, ...]
    opencode_bedrock_enabled: bool
    opencode_bedrock_models: tuple[str, ...]
    opencode_openai_enabled: bool
    opencode_extras: tuple[str, ...]
    codex_provider: str
    codex_model: str | None
    codex_approval_policy: str
    codex_sandbox_mode: str
    codex_web_search: str
    pi_enabled: bool
    pi_default_model: str | None
    pi_models: tuple[PiModelEntry, ...]
    pi_thinking: bool
    pi_packages: tuple[str, ...]
    pi_bedrock_enabled: bool
    pi_bedrock_default_model: str
    instruction_bullets: tuple[str, ...]


def resolve_policy(
    manifest: Manifest,
    project_root: Path,
    manifest_path: Path,
) -> ResolvedPolicy:
    """Merge baseline defaults and manifest settings into a frozen policy."""

    codex = manifest.codex
    opencode = manifest.opencode
    pi = manifest.pi
    return ResolvedPolicy(
        project_root=project_root.resolve(),
        manifest_path=manifest_path.resolve(),
        blocked_paths=_dedupe(DEFAULT_BLOCKED_PATHS + tuple(manifest.blocked_paths)),
        ask_patterns=_dedupe(DEFAULT_ASK_PATTERNS + tuple(manifest.shell_guardrails.ask)),
        deny_patterns=_dedupe(DEFAULT_DENY_PATTERNS + tuple(manifest.shell_guardrails.deny)),
        no_emojis=manifest.content_policy.no_emojis,
        no_ai_mentions=manifest.content_policy.no_ai_mentions,
        org_python_library=_detect_org_python_library(project_root.resolve()),
        opencode_enabled=opencode.enabled,
        opencode_default_model=opencode.default_model,
        opencode_small_model=opencode.small_model,
        opencode_local_provider=opencode.local_provider,
        opencode_models=tuple(opencode.models),
        opencode_bedrock_enabled=opencode.bedrock.enabled,
        opencode_bedrock_models=tuple(opencode.bedrock.models),
        opencode_openai_enabled=opencode.openai.enabled,
        opencode_extras=_dedupe(opencode.extras),
        codex_provider=codex.provider,
        codex_model=codex.model,
        codex_approval_policy=codex.approval_policy or DEFAULT_APPROVAL_POLICY,
        codex_sandbox_mode=codex.sandbox_mode or DEFAULT_SANDBOX_MODE,
        codex_web_search=codex.web_search or DEFAULT_WEB_SEARCH,
        pi_enabled=pi.enabled,
        pi_default_model=pi.default_model,
        pi_models=tuple(pi.models),
        pi_thinking=pi.thinking,
        pi_packages=_dedupe(DEFAULT_PI_PACKAGES + tuple(pi.packages)),
        pi_bedrock_enabled=pi.bedrock.enabled,
        pi_bedrock_default_model=pi.bedrock.default_model,
        instruction_bullets=BASELINE_INSTRUCTION_BULLETS,
    )


def _dedupe(values: Sequence[str]) -> tuple[str, ...]:
    seen: set[str] = set()
    ordered: list[str] = []
    for value in values:
        if value not in seen:
            ordered.append(value)
            seen.add(value)
    return tuple(ordered)
