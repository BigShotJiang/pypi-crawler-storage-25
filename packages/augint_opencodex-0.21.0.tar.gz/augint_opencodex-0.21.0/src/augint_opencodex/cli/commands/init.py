from __future__ import annotations

from pathlib import Path
from typing import Literal

import click

from augint_opencodex.constants import (
    DEFAULT_MANIFEST_FILE,
    GLOBAL_CONFIG_EXAMPLE,
    MANIFEST_SEARCH_ORDER,
)
from augint_opencodex.sync_engine import ProjectReport, init_project
from augint_opencodex.template_loader import load_template

from ._shared import GLOBAL_CONFIG_OPTION, display_path, warn_if_local_llm_unreachable


@click.command(name="init")
@click.option(
    "--project-root",
    type=click.Path(file_okay=False, path_type=Path),
    default=Path("."),
    show_default=True,
    help="Repository root to initialize.",
)
@click.option(
    "--manifest",
    type=click.Path(dir_okay=False, path_type=Path),
    help="Explicit manifest path. Defaults to PROJECT_ROOT/.ai-opencodex.yaml.",
)
@click.option("--dry-run", is_flag=True, help="Preview missing files without writing them.")
@GLOBAL_CONFIG_OPTION
def init_command(
    project_root: Path,
    manifest: Path | None,
    dry_run: bool,
    global_config: Path | None,
) -> None:
    """Create a manifest and any missing managed files."""

    mode: Literal["write", "dry-run"] = "dry-run" if dry_run else "write"
    manifest_path = _ensure_manifest(project_root, manifest, mode=mode)

    report = init_project(
        project_root,
        manifest_path=manifest_path,
        mode=mode,
        global_config_path=global_config,
    )
    _print_report(report)
    warn_if_local_llm_unreachable(report)
    _write_example(mode)


def _find_existing_manifest(project_root: Path) -> Path | None:
    resolved = project_root.resolve()
    for candidate in MANIFEST_SEARCH_ORDER:
        full = resolved / candidate
        if full.exists():
            return full
    return None


def _ensure_manifest(
    project_root: Path,
    manifest: Path | None,
    *,
    mode: Literal["write", "dry-run"],
) -> Path:
    if manifest is not None:
        manifest_path = manifest.resolve()
        if manifest_path.exists():
            click.echo(f"warning: manifest already exists, skipping create: {manifest_path}")
            return manifest_path
    else:
        existing = _find_existing_manifest(project_root)
        if existing is not None:
            click.echo(f"warning: manifest already exists, skipping create: {existing}")
            return existing
        manifest_path = (project_root / DEFAULT_MANIFEST_FILE).resolve()

    manifest_text = load_template("manifest-example.yaml")

    if mode == "dry-run":
        click.echo(f"would create manifest: {manifest_path}")
        manifest_path.parent.mkdir(parents=True, exist_ok=True)
        manifest_path.write_text(manifest_text, encoding="utf-8")

        def _cleanup_manifest() -> None:
            if manifest_path.exists():
                manifest_path.unlink()

        click.get_current_context().call_on_close(_cleanup_manifest)
        return manifest_path

    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(manifest_text, encoding="utf-8")
    click.echo(f"created manifest: {manifest_path}")
    return manifest_path


def _write_example(mode: Literal["write", "dry-run"]) -> None:
    example_text = load_template("global-config-example.yaml")
    if GLOBAL_CONFIG_EXAMPLE.exists():
        if GLOBAL_CONFIG_EXAMPLE.read_text(encoding="utf-8") == example_text:
            return
    if mode == "dry-run":
        click.echo(f"would create example: {GLOBAL_CONFIG_EXAMPLE}")
        return
    GLOBAL_CONFIG_EXAMPLE.parent.mkdir(parents=True, exist_ok=True)
    GLOBAL_CONFIG_EXAMPLE.write_text(example_text, encoding="utf-8")
    click.echo(f"created example: {GLOBAL_CONFIG_EXAMPLE}")


def _print_report(report: ProjectReport) -> None:
    root = report.policy.project_root
    click.echo(f"Project root: {root}")
    click.echo(f"Manifest: {report.policy.manifest_path}")

    for path in report.changed_files:
        verb = "would create" if report.mode == "dry-run" else "created"
        click.echo(f"{verb}: {display_path(path)}")

    for path in report.skipped_files:
        click.echo(f"warning: exists, skipped: {display_path(path)}")

    if not report.changed_files:
        click.echo("No missing managed files needed creation.")

    exclude_update = report.exclude_update
    if not exclude_update.available:
        click.echo("git exclude: skipped (no .git/info directory found)")
    elif exclude_update.updated:
        click.echo(f"git exclude: updated {display_path(exclude_update.path, root)}")
    elif exclude_update.needs_update:
        click.echo(f"git exclude: would update {display_path(exclude_update.path, root)}")
    else:
        click.echo("git exclude: already current")
