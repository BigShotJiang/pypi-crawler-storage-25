from __future__ import annotations

from pathlib import Path

DEFAULT_MANIFEST_FILE = Path(".ai-opencodex.yaml")
LEGACY_MANIFEST_FILE = Path(".ai-codex.json")
INSTRUCTION_FILE = Path(".agents/.ai-opencodex.md")
LEGACY_INSTRUCTION_FILE = Path(".ai-codex.md")
SCHEMA_URL = "https://svange.github.io/augint-opencodex/ai-opencodex.schema.json"

MANIFEST_SEARCH_ORDER = (
    Path(".ai-opencodex.json"),
    Path(".ai-opencodex.yaml"),
    Path(".ai-opencodex.yml"),
)

AUGINT_DIR = Path("~/.augint").expanduser()
GLOBAL_CONFIG_FILE = AUGINT_DIR / ".ai-opencodex.yaml"
GLOBAL_CONFIG_EXAMPLE = AUGINT_DIR / ".ai-opencodex.example.yaml"
AUGINT_ENV_FILE = AUGINT_DIR / ".env"

MANAGED_FILE_PATHS = (
    Path(".codex/config.toml"),
    INSTRUCTION_FILE,
    Path("opencode.json"),
    Path(".pi/settings.json"),
    Path(".pi/skills/augint-workflow/SKILL.md"),
    Path(".pi/skills/patch-pi-studio/SKILL.md"),
    Path(".agents/skills/README.md"),
    Path(".agents/skills/org-python-tooling/SKILL.md"),
    LEGACY_INSTRUCTION_FILE,
)
