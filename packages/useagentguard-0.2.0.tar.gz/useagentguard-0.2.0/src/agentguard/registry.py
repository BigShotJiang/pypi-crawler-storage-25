"""
agentguard.registry — Agent Identity Registry.

Agents are registered with metadata (owner, capabilities, creator) and
stored locally at ``~/.agentguard/registry.json``.  The registry also
provides a convenience method for retrieving an agent's full audit log.
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from agentguard import audit as _audit


_AGENTGUARD_HOME = Path(os.environ.get("AGENTGUARD_HOME", Path.home() / ".agentguard"))
_REGISTRY_FILE = _AGENTGUARD_HOME / "registry.json"


class AgentProfile:
    """Metadata record for a registered agent."""

    def __init__(
        self,
        agent_id: str,
        owner: str,
        capabilities: List[str],
        created_by: str,
        registered_at: str,
        tags: Optional[Dict[str, str]] = None,
        disabled: bool = False,
    ) -> None:
        self.agent_id = agent_id
        self.owner = owner
        self.capabilities = capabilities
        self.created_by = created_by
        self.registered_at = registered_at
        self.tags = tags or {}
        self.disabled = disabled

    def to_dict(self) -> Dict[str, Any]:
        return {
            "agent_id": self.agent_id,
            "owner": self.owner,
            "capabilities": self.capabilities,
            "created_by": self.created_by,
            "registered_at": self.registered_at,
            "tags": self.tags,
            "disabled": self.disabled,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "AgentProfile":
        return cls(
            agent_id=d["agent_id"],
            owner=d["owner"],
            capabilities=d.get("capabilities", []),
            created_by=d["created_by"],
            registered_at=d["registered_at"],
            tags=d.get("tags", {}),
            disabled=d.get("disabled", False),
        )

    def __repr__(self) -> str:
        return (
            f"AgentProfile(agent_id={self.agent_id!r}, owner={self.owner!r}, "
            f"capabilities={self.capabilities!r})"
        )


class Registry:
    """Local agent identity registry.

    All agent profiles are persisted in a single JSON file at
    ``~/.agentguard/registry.json``.

    Example::

        from agentguard.registry import Registry

        registry = Registry()
        registry.register(
            agent_id="support-bot",
            owner="team-cs",
            capabilities=["chat", "search"],
            created_by="kevin@company.com",
        )
        profile = registry.get("support-bot")
        print(profile.capabilities)
    """

    def __init__(self) -> None:
        _AGENTGUARD_HOME.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # Core CRUD
    # ------------------------------------------------------------------

    def register(
        self,
        agent_id: str,
        owner: str,
        capabilities: Optional[List[str]] = None,
        created_by: str = "",
        tags: Optional[Dict[str, str]] = None,
        overwrite: bool = False,
    ) -> AgentProfile:
        """Register a new agent (or update if *overwrite* is ``True``).

        Args:
            agent_id: Unique agent identifier.
            owner: Team or person owning this agent.
            capabilities: List of capability labels (e.g. ``["chat", "search"]``).
            created_by: Email or name of the person registering the agent.
            tags: Arbitrary key-value metadata.
            overwrite: If ``True``, overwrite an existing registration.

        Returns:
            The newly created :class:`AgentProfile`.

        Raises:
            ValueError: If the agent is already registered and *overwrite* is ``False``.
        """
        data = self._load()
        if agent_id in data and not overwrite:
            raise ValueError(
                f"Agent '{agent_id}' is already registered. "
                "Pass overwrite=True to update."
            )

        profile = AgentProfile(
            agent_id=agent_id,
            owner=owner,
            capabilities=capabilities or [],
            created_by=created_by,
            registered_at=datetime.now(timezone.utc).isoformat(),
            tags=tags or {},
        )
        data[agent_id] = profile.to_dict()
        self._save(data)

        _audit.log_event(
            agent_id=agent_id,
            action="agent_registered",
            details={
                "owner": owner,
                "capabilities": capabilities or [],
                "created_by": created_by,
            },
            outcome="allowed",
        )
        return profile

    def get(self, agent_id: str) -> AgentProfile:
        """Return the profile for *agent_id*.

        Args:
            agent_id: Agent to look up.

        Returns:
            :class:`AgentProfile` for the agent.

        Raises:
            KeyError: If the agent is not registered.
        """
        data = self._load()
        if agent_id not in data:
            raise KeyError(f"Agent '{agent_id}' is not registered.")
        return AgentProfile.from_dict(data[agent_id])

    def list(self) -> List[AgentProfile]:
        """Return all registered agent profiles.

        Returns:
            List of :class:`AgentProfile` objects.
        """
        return [AgentProfile.from_dict(v) for v in self._load().values()]

    def deregister(self, agent_id: str) -> None:
        """Remove an agent from the registry.

        Args:
            agent_id: Agent to remove.

        Raises:
            KeyError: If the agent is not registered.
        """
        data = self._load()
        if agent_id not in data:
            raise KeyError(f"Agent '{agent_id}' is not registered.")
        del data[agent_id]
        self._save(data)

        _audit.log_event(
            agent_id=agent_id,
            action="agent_deregistered",
            details={},
            outcome="allowed",
        )

    def disable(self, agent_id: str) -> None:
        """Mark an agent as disabled (soft delete).

        Args:
            agent_id: Agent to disable.

        Raises:
            KeyError: If the agent is not registered.
        """
        data = self._load()
        if agent_id not in data:
            raise KeyError(f"Agent '{agent_id}' is not registered.")
        data[agent_id]["disabled"] = True
        self._save(data)

        _audit.log_event(
            agent_id=agent_id,
            action="agent_disabled",
            details={},
            outcome="allowed",
        )

    # ------------------------------------------------------------------
    # Convenience
    # ------------------------------------------------------------------

    def audit_log(
        self,
        agent_id: str,
        since: Optional[str] = None,
        action: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Return all audit events for *agent_id*.

        Args:
            agent_id: Agent whose audit log to retrieve.
            since: ISO-8601 date filter (see :func:`agentguard.audit.query`).
            action: Filter to a specific action label.

        Returns:
            List of event dicts in chronological order.
        """
        return _audit.query(agent_id=agent_id, since=since, action=action)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _load(self) -> Dict[str, Any]:
        if not _REGISTRY_FILE.exists():
            return {}
        try:
            return json.loads(_REGISTRY_FILE.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return {}

    def _save(self, data: Dict[str, Any]) -> None:
        _AGENTGUARD_HOME.mkdir(parents=True, exist_ok=True)
        _REGISTRY_FILE.write_text(
            json.dumps(data, indent=2), encoding="utf-8"
        )
