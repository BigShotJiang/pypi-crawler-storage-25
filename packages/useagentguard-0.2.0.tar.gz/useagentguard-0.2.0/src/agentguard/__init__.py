"""
agentguard — The Security & Cost Control Layer for AI Agents.

Guard tier:    budget enforcement, cost tracking.
Shield tier:   per-agent credential isolation, OAuth scope enforcement,
               agent identity registry, permission drift detection, audit trail.
Sentinel tier: MCP policy enforcement, tool-call interception, compliance reports.
"""

from agentguard.audit import log_event, query as audit_query
from agentguard.compliance import ComplianceReport
from agentguard.drift import DriftDetector
from agentguard.guard import BudgetExceeded, GuardedClient, guard
from agentguard.mcp_interceptor import MCPInterceptor
from agentguard.policies import EvaluationResult, Policy, PolicyEngine, RateLimit
from agentguard.policy_loader import load_yaml as load_policy_yaml
from agentguard.registry import AgentProfile, Registry
from agentguard.scopes import ScopeManager, ScopeViolation
from agentguard.vault import AgentVault, CredentialRecord

__version__ = "0.2.0"
__all__ = [
    # Guard tier
    "guard",
    "GuardedClient",
    "BudgetExceeded",
    # Shield tier — vault
    "AgentVault",
    "CredentialRecord",
    # Shield tier — registry
    "Registry",
    "AgentProfile",
    # Shield tier — scopes
    "ScopeManager",
    "ScopeViolation",
    # Shield tier — drift
    "DriftDetector",
    # Sentinel tier — policies
    "Policy",
    "PolicyEngine",
    "RateLimit",
    "EvaluationResult",
    # Sentinel tier — interceptor
    "MCPInterceptor",
    # Sentinel tier — policy loader
    "load_policy_yaml",
    # Sentinel tier — compliance
    "ComplianceReport",
    # Audit
    "log_event",
    "audit_query",
]
