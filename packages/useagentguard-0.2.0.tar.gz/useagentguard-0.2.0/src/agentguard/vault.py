"""
agentguard.vault — Per-agent credential isolation vault.

Each agent gets an encrypted credential store at
``~/.agentguard/vaults/{agent_id}/credentials.enc``.

Encryption uses Fernet (AES-128-CBC + HMAC-SHA256).  The vault key is
derived from a master key stored at ``~/.agentguard/master.key`` (auto-
generated on first use and restricted to mode 0600).
"""

from __future__ import annotations

import json
import os
import stat
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

from cryptography.fernet import Fernet

from agentguard import audit as _audit


_AGENTGUARD_HOME = Path(os.environ.get("AGENTGUARD_HOME", Path.home() / ".agentguard"))
_MASTER_KEY_FILE = _AGENTGUARD_HOME / "master.key"
_VAULTS_DIR = _AGENTGUARD_HOME / "vaults"


# ---------------------------------------------------------------------------
# Master key management
# ---------------------------------------------------------------------------

def _load_or_create_master_key() -> bytes:
    """Return the master Fernet key, creating it on first use."""
    _AGENTGUARD_HOME.mkdir(parents=True, exist_ok=True)

    if _MASTER_KEY_FILE.exists():
        return _MASTER_KEY_FILE.read_bytes().strip()

    key = Fernet.generate_key()
    _MASTER_KEY_FILE.write_bytes(key)
    # Restrict to owner read/write only
    _MASTER_KEY_FILE.chmod(stat.S_IRUSR | stat.S_IWUSR)
    return key


def _get_fernet() -> Fernet:
    return Fernet(_load_or_create_master_key())


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

class CredentialRecord:
    """In-memory representation of a stored credential."""

    def __init__(
        self,
        service: str,
        key: str,
        scopes: List[str],
        created_at: str,
        rotated_at: Optional[str] = None,
    ) -> None:
        self.service = service
        self._key = key          # kept private; never serialised to __repr__
        self.scopes = scopes
        self.created_at = created_at
        self.rotated_at = rotated_at

    # Prevent accidental key exposure in logs/tracebacks
    def __repr__(self) -> str:
        return (
            f"CredentialRecord(service={self.service!r}, "
            f"scopes={self.scopes!r}, created_at={self.created_at!r})"
        )

    def get_key(self) -> str:
        """Return the raw credential key.  Handle with care."""
        return self._key

    def to_dict(self) -> Dict:
        """Serialize to a plain dict (key included — encrypt before persisting)."""
        return {
            "service": self.service,
            "key": self._key,
            "scopes": self.scopes,
            "created_at": self.created_at,
            "rotated_at": self.rotated_at,
        }

    @classmethod
    def from_dict(cls, d: Dict) -> "CredentialRecord":
        return cls(
            service=d["service"],
            key=d["key"],
            scopes=d.get("scopes", []),
            created_at=d["created_at"],
            rotated_at=d.get("rotated_at"),
        )


class AgentVault:
    """Encrypted, isolated credential store for a single agent.

    Args:
        agent_id: Unique identifier for the agent (e.g. ``"support-bot"``).

    Example::

        vault = AgentVault("support-bot")
        vault.store("openai", "sk-...", scopes=["chat.completions"])
        cred = vault.get("openai")
        print(cred.scopes)   # ["chat.completions"]
    """

    def __init__(self, agent_id: str) -> None:
        if not agent_id or not isinstance(agent_id, str):
            raise ValueError("agent_id must be a non-empty string")
        self.agent_id = agent_id
        self._vault_dir: Path = _VAULTS_DIR / agent_id
        self._vault_file: Path = self._vault_dir / "credentials.enc"
        self._vault_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # Core CRUD
    # ------------------------------------------------------------------

    def store(
        self,
        service: str,
        key: str,
        scopes: Optional[List[str]] = None,
    ) -> None:
        """Store (or overwrite) a credential for *service*.

        Args:
            service: Service name, e.g. ``"openai"`` or ``"github"``.
            key: The credential value (API key, token, etc.).
            scopes: List of permitted OAuth scopes for this credential.
        """
        if not service:
            raise ValueError("service must be a non-empty string")
        if not key:
            raise ValueError("key must be a non-empty string")

        data = self._load()
        now = datetime.now(timezone.utc).isoformat()
        data[service] = {
            "service": service,
            "key": key,
            "scopes": scopes or [],
            "created_at": now,
            "rotated_at": None,
        }
        self._save(data)

        _audit.log_event(
            agent_id=self.agent_id,
            action="credential_stored",
            details={"service": service, "scopes": scopes or []},
            outcome="allowed",
        )

    def get(self, service: str) -> CredentialRecord:
        """Retrieve the credential record for *service*.

        Args:
            service: Service name to look up.

        Returns:
            :class:`CredentialRecord` for the service.

        Raises:
            KeyError: If no credential is stored for *service*.
        """
        data = self._load()
        if service not in data:
            _audit.log_event(
                agent_id=self.agent_id,
                action="credential_access",
                details={"service": service},
                outcome="denied",
            )
            raise KeyError(f"No credential stored for service '{service}' in vault '{self.agent_id}'")

        _audit.log_event(
            agent_id=self.agent_id,
            action="credential_access",
            details={"service": service},
            outcome="allowed",
        )
        return CredentialRecord.from_dict(data[service])

    def rotate(self, service: str, new_key: str) -> None:
        """Rotate the credential for *service* to *new_key*.

        The old key is overwritten and an audit event is logged.

        Args:
            service: Service whose credential to rotate.
            new_key: The replacement credential value.

        Raises:
            KeyError: If no credential exists for *service*.
        """
        data = self._load()
        if service not in data:
            raise KeyError(f"No credential to rotate for service '{service}' in vault '{self.agent_id}'")

        data[service]["key"] = new_key
        data[service]["rotated_at"] = datetime.now(timezone.utc).isoformat()
        self._save(data)

        _audit.log_event(
            agent_id=self.agent_id,
            action="credential_rotated",
            details={"service": service},
            outcome="allowed",
        )

    def delete(self, service: str) -> None:
        """Remove the stored credential for *service*.

        Args:
            service: Service to remove.

        Raises:
            KeyError: If no credential exists for *service*.
        """
        data = self._load()
        if service not in data:
            raise KeyError(f"No credential found for service '{service}' in vault '{self.agent_id}'")
        del data[service]
        self._save(data)

        _audit.log_event(
            agent_id=self.agent_id,
            action="credential_deleted",
            details={"service": service},
            outcome="allowed",
        )

    def list_services(self) -> List[str]:
        """Return the names of all services stored in this vault.

        Returns:
            List of service name strings.
        """
        return list(self._load().keys())

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _load(self) -> Dict:
        """Decrypt and return the vault contents as a plain dict."""
        if not self._vault_file.exists():
            return {}
        fernet = _get_fernet()
        encrypted = self._vault_file.read_bytes()
        try:
            plaintext = fernet.decrypt(encrypted)
        except Exception as exc:
            raise RuntimeError(
                f"Failed to decrypt vault for agent '{self.agent_id}'. "
                "The master key may have changed."
            ) from exc
        return json.loads(plaintext.decode("utf-8"))

    def _save(self, data: Dict) -> None:
        """Encrypt and persist the vault contents."""
        fernet = _get_fernet()
        plaintext = json.dumps(data).encode("utf-8")
        encrypted = fernet.encrypt(plaintext)
        self._vault_file.write_bytes(encrypted)
        # Restrict file to owner only
        self._vault_file.chmod(stat.S_IRUSR | stat.S_IWUSR)
