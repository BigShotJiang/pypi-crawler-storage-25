"""
agentguard.drift — Permission drift detection.

Snapshots the current permission/scope state for an agent and compares it
against a stored baseline.  Drift events are logged to the audit trail.

Snapshots are stored at ``~/.agentguard/snapshots/{agent_id}.json``.
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from agentguard import audit as _audit


_AGENTGUARD_HOME = Path(os.environ.get("AGENTGUARD_HOME", Path.home() / ".agentguard"))
_SNAPSHOTS_DIR = _AGENTGUARD_HOME / "snapshots"

# Drift change types
ADDED = "added"
REMOVED = "removed"
CHANGED = "changed"


class DriftChange:
    """Describes a single detected change between baseline and current state."""

    def __init__(
        self,
        change_type: str,
        category: str,
        field: str,
        old_value: Any = None,
        new_value: Any = None,
    ) -> None:
        self.change_type = change_type   # added | removed | changed
        self.category = category         # e.g. "scope", "capability", "credential"
        self.field = field               # e.g. "openai.fine-tuning"
        self.old_value = old_value
        self.new_value = new_value

    def to_dict(self) -> Dict[str, Any]:
        return {
            "change_type": self.change_type,
            "category": self.category,
            "field": self.field,
            "old_value": self.old_value,
            "new_value": self.new_value,
        }

    def __repr__(self) -> str:
        return (
            f"DriftChange(type={self.change_type!r}, category={self.category!r}, "
            f"field={self.field!r})"
        )


class DriftDetector:
    """Detects permission and capability drift for agents.

    Example::

        from agentguard.drift import DriftDetector

        drift = DriftDetector()
        drift.snapshot("support-bot")        # save baseline
        # ... time passes, scopes change ...
        changes = drift.check("support-bot") # compare to baseline
        for c in changes:
            print(c)
    """

    def __init__(self) -> None:
        _SNAPSHOTS_DIR.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def snapshot(self, agent_id: str) -> Dict[str, Any]:
        """Capture and save the current permission state for *agent_id*.

        Reads from the live scope policy and vault service list.

        Args:
            agent_id: Agent to snapshot.

        Returns:
            The snapshot dict that was persisted.
        """
        from agentguard.scopes import ScopeManager
        from agentguard.vault import AgentVault
        from agentguard.registry import Registry

        scopes_mgr = ScopeManager()
        vault = AgentVault(agent_id)

        # Grab registry capabilities (best-effort)
        capabilities: List[str] = []
        try:
            registry = Registry()
            profile = registry.get(agent_id)
            capabilities = profile.capabilities
        except KeyError:
            pass

        snapshot: Dict[str, Any] = {
            "agent_id": agent_id,
            "captured_at": datetime.now(timezone.utc).isoformat(),
            "scopes": scopes_mgr.get(agent_id),
            "vault_services": vault.list_services(),
            "capabilities": capabilities,
        }

        snapshot_file = _SNAPSHOTS_DIR / f"{agent_id}.json"
        snapshot_file.write_text(json.dumps(snapshot, indent=2), encoding="utf-8")

        _audit.log_event(
            agent_id=agent_id,
            action="drift_snapshot",
            details={"vault_services": snapshot["vault_services"], "capabilities": capabilities},
            outcome="allowed",
        )
        return snapshot

    def get_snapshot(self, agent_id: str) -> Optional[Dict[str, Any]]:
        """Return the stored baseline snapshot for *agent_id*, or ``None``.

        Args:
            agent_id: Agent to look up.

        Returns:
            Snapshot dict or ``None`` if no snapshot exists.
        """
        snapshot_file = _SNAPSHOTS_DIR / f"{agent_id}.json"
        if not snapshot_file.exists():
            return None
        try:
            return json.loads(snapshot_file.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return None

    def check(self, agent_id: str) -> List[DriftChange]:
        """Compare current state to the stored baseline for *agent_id*.

        Args:
            agent_id: Agent to check.

        Returns:
            List of :class:`DriftChange` objects (empty if no drift detected).
            Returns an empty list if no baseline snapshot exists.
        """
        baseline = self.get_snapshot(agent_id)
        if not baseline:
            return []

        # Capture the *current* state without persisting it as the new baseline
        from agentguard.scopes import ScopeManager
        from agentguard.vault import AgentVault
        from agentguard.registry import Registry

        scopes_mgr = ScopeManager()
        vault = AgentVault(agent_id)

        capabilities: List[str] = []
        try:
            registry = Registry()
            profile = registry.get(agent_id)
            capabilities = profile.capabilities
        except KeyError:
            pass

        current: Dict[str, Any] = {
            "scopes": scopes_mgr.get(agent_id),
            "vault_services": vault.list_services(),
            "capabilities": capabilities,
        }

        changes: List[DriftChange] = []

        # --- scope drift ---
        baseline_scopes: Dict[str, List[str]] = baseline.get("scopes", {})
        current_scopes: Dict[str, List[str]] = current["scopes"]
        changes.extend(_diff_scopes(baseline_scopes, current_scopes))

        # --- vault service drift ---
        baseline_services = set(baseline.get("vault_services", []))
        current_services = set(current["vault_services"])
        for svc in current_services - baseline_services:
            changes.append(DriftChange(ADDED, "credential", svc, None, svc))
        for svc in baseline_services - current_services:
            changes.append(DriftChange(REMOVED, "credential", svc, svc, None))

        # --- capability drift ---
        baseline_caps = set(baseline.get("capabilities", []))
        current_caps = set(capabilities)
        for cap in current_caps - baseline_caps:
            changes.append(DriftChange(ADDED, "capability", cap, None, cap))
        for cap in baseline_caps - current_caps:
            changes.append(DriftChange(REMOVED, "capability", cap, cap, None))

        if changes:
            _audit.log_event(
                agent_id=agent_id,
                action="drift_detected",
                details={"changes": [c.to_dict() for c in changes]},
                outcome="allowed",
            )
        else:
            _audit.log_event(
                agent_id=agent_id,
                action="drift_check_clean",
                details={},
                outcome="allowed",
            )

        return changes

    def clear_snapshot(self, agent_id: str) -> None:
        """Delete the stored snapshot for *agent_id*.

        Args:
            agent_id: Agent whose snapshot to remove.
        """
        snapshot_file = _SNAPSHOTS_DIR / f"{agent_id}.json"
        if snapshot_file.exists():
            snapshot_file.unlink()


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _diff_scopes(
    baseline: Dict[str, List[str]],
    current: Dict[str, List[str]],
) -> List[DriftChange]:
    """Return scope-level drift changes between *baseline* and *current*."""
    changes: List[DriftChange] = []

    all_services = set(baseline.keys()) | set(current.keys())
    for svc in all_services:
        base_set = set(baseline.get(svc, []))
        curr_set = set(current.get(svc, []))

        for scope in curr_set - base_set:
            changes.append(
                DriftChange(ADDED, "scope", f"{svc}.{scope}", None, scope)
            )
        for scope in base_set - curr_set:
            changes.append(
                DriftChange(REMOVED, "scope", f"{svc}.{scope}", scope, None)
            )

    return changes
