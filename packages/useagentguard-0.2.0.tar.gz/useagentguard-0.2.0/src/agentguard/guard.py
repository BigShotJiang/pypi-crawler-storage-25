"""
agentguard.guard — The main guard() wrapper.

Wraps any OpenAI-compatible client with Guard (budget control),
Shield (per-agent vault, scope enforcement, identity), and
Sentinel (MCP policy enforcement) features.
"""

from __future__ import annotations

import re
import time
from typing import Any, Dict, List, Optional

from agentguard import audit as _audit
from agentguard.scopes import ScopeManager, ScopeViolation
from agentguard.vault import AgentVault


# ---------------------------------------------------------------------------
# Budget helpers
# ---------------------------------------------------------------------------

_BUDGET_RE = re.compile(r"^\$?(\d+(?:\.\d+)?)/(\w+)$")


def _parse_budget(budget_str: str) -> tuple[float, str]:
    """Parse a budget string like ``"$0.50/run"`` → ``(0.50, "run")``."""
    m = _BUDGET_RE.match(budget_str.strip())
    if not m:
        raise ValueError(
            f"Invalid budget format: {budget_str!r}. "
            "Expected format: '$<amount>/<period>', e.g. '$0.50/run'."
        )
    return float(m.group(1)), m.group(2)


# ---------------------------------------------------------------------------
# Guarded client proxy
# ---------------------------------------------------------------------------

class _GuardedCompletions:
    """Proxy for the ``client.chat.completions`` sub-object."""

    def __init__(self, parent: "GuardedClient") -> None:
        self._parent = parent

    def create(self, *args: Any, **kwargs: Any) -> Any:
        """Intercept a chat completion call to enforce budget + scopes."""
        parent = self._parent

        # --- Shield: scope check ---
        if parent._agent_id and parent._scopes_policy:
            scopes_mgr = ScopeManager()
            for service, scopes in parent._scopes_policy.items():
                for scope in scopes:
                    scopes_mgr.check(parent._agent_id, service, scope)

        # --- Guard: budget check ---
        if parent._budget_usd is not None:
            if parent._spent >= parent._budget_usd:
                _audit.log_event(
                    agent_id=parent._agent_id or "unknown",
                    action="budget_exceeded",
                    details={
                        "budget_usd": parent._budget_usd,
                        "spent_usd": parent._spent,
                    },
                    outcome="denied",
                )
                if parent._on_limit == "graceful_stop":
                    return _BudgetExceededResponse(
                        budget=parent._budget_usd,
                        spent=parent._spent,
                    )
                raise BudgetExceeded(
                    budget=parent._budget_usd,
                    spent=parent._spent,
                )

        # --- Apply fallback model if set ---
        if parent._fallback and "model" not in kwargs:
            kwargs["model"] = parent._fallback
        elif parent._fallback and parent._spent >= (parent._budget_usd or float("inf")) * 0.8:
            # Switch to cheaper fallback when 80 % of budget is used
            kwargs["model"] = parent._fallback

        # --- Delegate to the real client ---
        real_completions = getattr(parent._client.chat, "completions", None)
        if real_completions is None:
            raise AttributeError("Wrapped client does not have a 'chat.completions' attribute")

        response = real_completions.create(*args, **kwargs)

        # --- Track cost (approximate, based on usage if available) ---
        if hasattr(response, "usage") and response.usage:
            cost = _estimate_cost(response.usage, kwargs.get("model", ""))
            parent._spent += cost
            _audit.log_event(
                agent_id=parent._agent_id or "unknown",
                action="completion_created",
                details={
                    "model": kwargs.get("model", ""),
                    "tokens_used": getattr(response.usage, "total_tokens", 0),
                    "estimated_cost_usd": cost,
                    "spent_total_usd": parent._spent,
                },
                outcome="allowed",
            )

        return response


class _GuardedChat:
    """Proxy for ``client.chat``."""

    def __init__(self, parent: "GuardedClient") -> None:
        self.completions = _GuardedCompletions(parent)


class GuardedClient:
    """A wrapped AI client that enforces budget, Shield, and Sentinel policies.

    Do not instantiate directly; use :func:`guard` instead.
    """

    def __init__(
        self,
        client: Any,
        *,
        budget: Optional[str] = None,
        auth: Optional[str] = None,
        agent_id: Optional[str] = None,
        scopes: Optional[Dict[str, List[str]]] = None,
        fallback: Optional[str] = None,
        on_limit: str = "raise",
        mcp_policy: Optional[str] = None,
        on_violation: str = "block",
    ) -> None:
        self._client = client
        self._agent_id = agent_id
        self._auth = auth
        self._scopes_policy = scopes
        self._fallback = fallback
        self._on_limit = on_limit
        self._spent: float = 0.0

        # Parse budget
        self._budget_usd: Optional[float] = None
        self._budget_period: Optional[str] = None
        if budget:
            self._budget_usd, self._budget_period = _parse_budget(budget)

        # Shield: register scope policy
        if agent_id and scopes:
            mgr = ScopeManager()
            mgr.set(agent_id, scopes)

        # Shield: attach vault if auth="isolated"
        self._vault: Optional[AgentVault] = None
        if auth == "isolated" and agent_id:
            self._vault = AgentVault(agent_id)

        # Sentinel: attach MCP interceptor if mcp_policy is provided
        self._mcp_interceptor = None
        if mcp_policy:
            from agentguard.policies import PolicyEngine
            from agentguard.mcp_interceptor import MCPInterceptor
            engine = PolicyEngine.from_yaml(mcp_policy)
            self._mcp_interceptor = MCPInterceptor(
                policies=engine,
                on_violation=on_violation,
            )

        # Expose guarded chat interface
        self.chat = _GuardedChat(self)

    @property
    def spent(self) -> float:
        """Cumulative USD spent through this guarded client."""
        return self._spent

    @property
    def vault(self) -> Optional[AgentVault]:
        """The isolated credential vault, if auth='isolated'."""
        return self._vault

    @property
    def mcp_interceptor(self):
        """The MCP interceptor, if mcp_policy was provided."""
        return self._mcp_interceptor

    def __getattr__(self, name: str) -> Any:
        """Pass through any attribute not handled here to the wrapped client."""
        return getattr(self._client, name)


# ---------------------------------------------------------------------------
# Public factory function
# ---------------------------------------------------------------------------

def guard(
    client: Any,
    *,
    budget: Optional[str] = None,
    auth: Optional[str] = None,
    agent_id: Optional[str] = None,
    scopes: Optional[Dict[str, List[str]]] = None,
    fallback: Optional[str] = None,
    on_limit: str = "raise",
    mcp_policy: Optional[str] = None,
    on_violation: str = "block",
) -> GuardedClient:
    """Wrap an AI client with Guard, Shield, and Sentinel features.

    Args:
        client: The AI client to wrap (e.g. ``openai.OpenAI()``).
        budget: Budget string, e.g. ``"$0.50/run"`` or ``"$5.00/day"``.
        auth: Set to ``"isolated"`` to attach a per-agent credential vault.
        agent_id: Agent identifier (required for Shield/Sentinel features).
        scopes: Dict of ``{service: [allowed_scopes]}`` for scope enforcement.
        fallback: Fallback model name to use when budget is near limit.
        on_limit: ``"raise"`` (default) or ``"graceful_stop"`` when budget exceeded.
        mcp_policy: Path to a YAML policy file for MCP tool-call enforcement
            (Sentinel tier).
        on_violation: How to handle policy violations — ``"block"`` (default),
            ``"warn"``, or ``"log"``.

    Returns:
        A :class:`GuardedClient` wrapping *client*.

    Example::

        import openai
        from agentguard import guard

        client = guard(
            openai.OpenAI(),
            budget="$0.50/run",
            auth="isolated",
            agent_id="support-bot",
            scopes={"openai": ["chat.completions"]},
            mcp_policy="policies.yaml",
            on_violation="block",
            fallback="gpt-4o-mini",
            on_limit="graceful_stop",
        )
    """
    return GuardedClient(
        client,
        budget=budget,
        auth=auth,
        agent_id=agent_id,
        scopes=scopes,
        fallback=fallback,
        on_limit=on_limit,
        mcp_policy=mcp_policy,
        on_violation=on_violation,
    )


# ---------------------------------------------------------------------------
# Exceptions & sentinel responses
# ---------------------------------------------------------------------------

class BudgetExceeded(Exception):
    """Raised when an agent exceeds its budget and on_limit='raise'."""

    def __init__(self, budget: float, spent: float) -> None:
        self.budget = budget
        self.spent = spent
        super().__init__(
            f"Budget exceeded: spent ${spent:.4f} of ${budget:.2f} limit."
        )


class _BudgetExceededResponse:
    """Graceful stop sentinel returned when on_limit='graceful_stop'."""

    def __init__(self, budget: float, spent: float) -> None:
        self.budget_exceeded = True
        self.budget = budget
        self.spent = spent
        self.choices = []
        self.usage = None

    def __bool__(self) -> bool:
        return False


# ---------------------------------------------------------------------------
# Cost estimation (approximate, model-agnostic)
# ---------------------------------------------------------------------------

# Rough USD per 1k tokens for common models.  Add more as needed.
_COST_TABLE: Dict[str, Dict[str, float]] = {
    "gpt-4o": {"input": 0.005, "output": 0.015},
    "gpt-4o-mini": {"input": 0.00015, "output": 0.0006},
    "gpt-4-turbo": {"input": 0.01, "output": 0.03},
    "gpt-3.5-turbo": {"input": 0.0005, "output": 0.0015},
}

_DEFAULT_COST = {"input": 0.001, "output": 0.002}


def _estimate_cost(usage: Any, model: str) -> float:
    """Estimate USD cost from a usage object."""
    rates = _COST_TABLE.get(model, _DEFAULT_COST)
    prompt_tokens = getattr(usage, "prompt_tokens", 0) or 0
    completion_tokens = getattr(usage, "completion_tokens", 0) or 0
    return (
        prompt_tokens / 1000 * rates["input"]
        + completion_tokens / 1000 * rates["output"]
    )
