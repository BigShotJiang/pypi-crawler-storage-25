"""
agentguard.scopes — OAuth scope enforcement for agents.

Scope policies are stored per-agent in ``~/.agentguard/scopes.json``.
At runtime, every credential access is checked against the policy;
a :class:`ScopeViolation` is raised if the agent requests a scope it
is not permitted to use.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Dict, List, Optional

from agentguard import audit as _audit


_AGENTGUARD_HOME = Path(os.environ.get("AGENTGUARD_HOME", Path.home() / ".agentguard"))
_SCOPES_FILE = _AGENTGUARD_HOME / "scopes.json"


class ScopeViolation(Exception):
    """Raised when an agent attempts to use a scope it is not permitted."""

    def __init__(
        self,
        agent_id: str,
        service: str,
        requested_scope: str,
        allowed_scopes: List[str],
    ) -> None:
        self.agent_id = agent_id
        self.service = service
        self.requested_scope = requested_scope
        self.allowed_scopes = allowed_scopes
        super().__init__(
            f"Scope violation: agent '{agent_id}' requested scope "
            f"'{requested_scope}' on service '{service}', "
            f"but only {allowed_scopes!r} are permitted."
        )


class ScopeManager:
    """Manages per-agent OAuth scope policies.

    Policies are stored in ``~/.agentguard/scopes.json`` as::

        {
            "support-bot": {
                "openai": ["chat.completions"],
                "github": ["repos.read"]
            }
        }

    Example::

        from agentguard.scopes import ScopeManager

        scopes = ScopeManager()
        scopes.set("support-bot", {"openai": ["chat.completions"]})
        scopes.check("support-bot", "openai", "chat.completions")  # OK
        scopes.check("support-bot", "openai", "fine-tuning")       # raises ScopeViolation
    """

    def __init__(self) -> None:
        _AGENTGUARD_HOME.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # Policy management
    # ------------------------------------------------------------------

    def set(
        self,
        agent_id: str,
        policy: Dict[str, List[str]],
    ) -> None:
        """Set (replace) the full scope policy for *agent_id*.

        Args:
            agent_id: Target agent.
            policy: Dict mapping service names to allowed scope lists.
                    E.g. ``{"openai": ["chat.completions"], "github": ["repos.read"]}``.
        """
        data = self._load()
        data[agent_id] = policy
        self._save(data)

        _audit.log_event(
            agent_id=agent_id,
            action="scopes_updated",
            details={"policy": policy},
            outcome="allowed",
        )

    def get(self, agent_id: str) -> Dict[str, List[str]]:
        """Return the current scope policy for *agent_id*.

        Args:
            agent_id: Agent to look up.

        Returns:
            Dict of ``{service: [scopes]}``.  Empty dict if no policy set.
        """
        return self._load().get(agent_id, {})

    def add_scope(self, agent_id: str, service: str, scope: str) -> None:
        """Add a single scope to a service for *agent_id*.

        Args:
            agent_id: Target agent.
            service: Service to update.
            scope: Scope string to add.
        """
        data = self._load()
        agent_policy = data.setdefault(agent_id, {})
        service_scopes = agent_policy.setdefault(service, [])
        if scope not in service_scopes:
            service_scopes.append(scope)
        data[agent_id] = agent_policy
        self._save(data)

        _audit.log_event(
            agent_id=agent_id,
            action="scope_added",
            details={"service": service, "scope": scope},
            outcome="allowed",
        )

    def remove_scope(self, agent_id: str, service: str, scope: str) -> None:
        """Remove a single scope from a service for *agent_id*.

        Args:
            agent_id: Target agent.
            service: Service to update.
            scope: Scope string to remove.

        Raises:
            KeyError: If *scope* is not in the current policy.
        """
        data = self._load()
        try:
            data[agent_id][service].remove(scope)
        except (KeyError, ValueError) as exc:
            raise KeyError(
                f"Scope '{scope}' not found for agent '{agent_id}' / service '{service}'"
            ) from exc
        self._save(data)

        _audit.log_event(
            agent_id=agent_id,
            action="scope_removed",
            details={"service": service, "scope": scope},
            outcome="allowed",
        )

    def clear(self, agent_id: str) -> None:
        """Remove all scope policies for *agent_id*.

        Args:
            agent_id: Agent whose policies to clear.
        """
        data = self._load()
        data.pop(agent_id, None)
        self._save(data)

    # ------------------------------------------------------------------
    # Runtime enforcement
    # ------------------------------------------------------------------

    def check(
        self,
        agent_id: str,
        service: str,
        requested_scope: str,
    ) -> None:
        """Assert that *agent_id* is allowed to use *requested_scope* on *service*.

        Logs the check outcome to the audit trail regardless of result.

        Args:
            agent_id: Agent making the request.
            service: Service the agent is trying to use.
            requested_scope: The scope being requested.

        Raises:
            ScopeViolation: If the scope is not permitted.
        """
        policy = self._load()
        allowed_scopes: List[str] = policy.get(agent_id, {}).get(service, [])

        if requested_scope in allowed_scopes:
            _audit.log_event(
                agent_id=agent_id,
                action="scope_check",
                details={"service": service, "scope": requested_scope},
                outcome="allowed",
            )
            return

        _audit.log_event(
            agent_id=agent_id,
            action="scope_check",
            details={
                "service": service,
                "scope": requested_scope,
                "allowed": allowed_scopes,
            },
            outcome="denied",
        )
        raise ScopeViolation(
            agent_id=agent_id,
            service=service,
            requested_scope=requested_scope,
            allowed_scopes=allowed_scopes,
        )

    def is_allowed(
        self,
        agent_id: str,
        service: str,
        requested_scope: str,
    ) -> bool:
        """Return ``True`` if *agent_id* is permitted *requested_scope* on *service*.

        Unlike :meth:`check`, this method does *not* raise on denial and does
        *not* write to the audit trail.  Use :meth:`check` for enforced paths.

        Args:
            agent_id: Agent to check.
            service: Service name.
            requested_scope: Scope string.

        Returns:
            ``True`` if allowed, ``False`` otherwise.
        """
        policy = self._load()
        allowed: List[str] = policy.get(agent_id, {}).get(service, [])
        return requested_scope in allowed

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _load(self) -> Dict[str, Dict[str, List[str]]]:
        if not _SCOPES_FILE.exists():
            return {}
        try:
            return json.loads(_SCOPES_FILE.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return {}

    def _save(self, data: Dict) -> None:
        _AGENTGUARD_HOME.mkdir(parents=True, exist_ok=True)
        _SCOPES_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")
