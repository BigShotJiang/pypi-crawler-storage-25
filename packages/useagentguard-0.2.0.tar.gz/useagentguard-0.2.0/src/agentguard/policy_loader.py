"""
agentguard.policy_loader — Load :class:`PolicyEngine` from YAML files.

Supports a declarative YAML schema for defining policies without writing
Python code.  Use :func:`load_yaml` or :meth:`PolicyEngine.from_yaml`.

YAML schema example::

    policies:
      - name: no-pii-queries
        description: "Agents cannot query PII tables"
        agents: ["*"]
        tools: ["database_query"]
        deny_params:
          query:
            contains_any: ["users", "credentials", "payments"]

      - name: read-only-fs
        description: "Support bot is read-only"
        agents: ["support-bot"]
        tools: ["file_write", "file_delete"]
        action: deny

      - name: rate-limit
        description: "100 calls/min per agent"
        agents: ["*"]
        tools: ["*"]
        rate_limit:
          max_calls: 100
          window_seconds: 60
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

try:
    import yaml  # type: ignore
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        "pyyaml is required to load policy files. "
        "Install it with: pip install pyyaml"
    ) from exc

from agentguard.policies import Policy, PolicyEngine, RateLimit


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def load_yaml(path: str) -> PolicyEngine:
    """Parse a YAML policy file and return a configured :class:`PolicyEngine`.

    Args:
        path: Filesystem path to the YAML policy file.

    Returns:
        A :class:`PolicyEngine` pre-loaded with all policies from the file.

    Raises:
        FileNotFoundError: If *path* does not exist.
        ValueError: If the YAML schema is invalid.
    """
    fpath = Path(path)
    if not fpath.exists():
        raise FileNotFoundError(f"Policy file not found: {path}")

    raw = yaml.safe_load(fpath.read_text(encoding="utf-8")) or {}
    return _build_engine(raw, source=str(fpath))


def load_yaml_string(content: str) -> PolicyEngine:
    """Parse YAML policy content from a string.

    Useful for testing or loading policies from a remote config source.

    Args:
        content: YAML string.

    Returns:
        A configured :class:`PolicyEngine`.
    """
    raw = yaml.safe_load(content) or {}
    return _build_engine(raw, source="<string>")


# ---------------------------------------------------------------------------
# Internal builder
# ---------------------------------------------------------------------------

def _build_engine(raw: Dict[str, Any], source: str = "") -> PolicyEngine:
    """Build a :class:`PolicyEngine` from a parsed YAML dict."""
    engine = PolicyEngine()
    policy_list = raw.get("policies", [])
    if not isinstance(policy_list, list):
        raise ValueError(f"'policies' must be a list in {source}")

    for idx, entry in enumerate(policy_list):
        if not isinstance(entry, dict):
            raise ValueError(f"Policy entry {idx} is not a dict in {source}")
        policy = _parse_policy(entry, source=source)
        engine.add_policy(policy)

    return engine


def _parse_policy(entry: Dict[str, Any], source: str = "") -> Policy:
    """Convert a single YAML policy entry to a :class:`Policy` object."""
    name = entry.get("name")
    if not name:
        raise ValueError(f"Policy entry missing 'name' in {source}: {entry!r}")

    description = entry.get("description", "")
    agent_ids: List[str] = entry.get("agents", ["*"])
    tools: List[str] = entry.get("tools", ["*"])
    action: str = entry.get("action", "allow")

    # --- rate_limit ---
    rate_limit: Optional[RateLimit] = None
    if "rate_limit" in entry:
        rl_data = entry["rate_limit"]
        try:
            rate_limit = RateLimit(
                max_calls=int(rl_data["max_calls"]),
                window_seconds=int(rl_data["window_seconds"]),
            )
        except (KeyError, TypeError, ValueError) as exc:
            raise ValueError(
                f"Invalid rate_limit in policy '{name}': {exc}"
            ) from exc

    # --- deny_params → deny_if predicate ---
    deny_if: Optional[Callable[[Dict[str, Any]], bool]] = None
    if "deny_params" in entry:
        deny_if = _build_deny_if(entry["deny_params"], policy_name=name)

    # --- allow_if (not supported in YAML yet; reserved) ---
    allow_if = None

    return Policy(
        name=name,
        description=description,
        agent_ids=agent_ids,
        tools=tools,
        action=action,
        deny_if=deny_if,
        allow_if=allow_if,
        rate_limit=rate_limit,
    )


# ---------------------------------------------------------------------------
# Parameter constraint builder
# ---------------------------------------------------------------------------

def _build_deny_if(
    deny_params: Dict[str, Any],
    policy_name: str = "",
) -> Callable[[Dict[str, Any]], bool]:
    """Build a ``deny_if`` callable from a ``deny_params`` YAML block.

    Supported constraints per parameter key:

    * ``contains_any: [str, ...]`` — deny if the value contains any substring
    * ``contains_all: [str, ...]`` — deny if the value contains all substrings
    * ``matches: <regex>`` — deny if the value matches the regex
    * ``equals: <value>`` — deny if the value equals this
    * ``not_equals: <value>`` — deny if the value does not equal this

    Args:
        deny_params: Dict mapping parameter names to constraint dicts.
        policy_name: Name of the parent policy (for error messages).

    Returns:
        A callable ``(params: dict) -> bool``.
    """
    # Pre-compile constraints
    compiled: List[Callable[[Dict[str, Any]], bool]] = []

    for param_key, constraint in deny_params.items():
        if not isinstance(constraint, dict):
            raise ValueError(
                f"Policy '{policy_name}': deny_params['{param_key}'] must be a dict"
            )

        # contains_any
        if "contains_any" in constraint:
            terms = [str(t).lower() for t in constraint["contains_any"]]
            def _contains_any(params: Dict[str, Any], k: str = param_key, ts: List[str] = terms) -> bool:
                val = str(params.get(k, "")).lower()
                return any(t in val for t in ts)
            compiled.append(_contains_any)

        # contains_all
        if "contains_all" in constraint:
            terms = [str(t).lower() for t in constraint["contains_all"]]
            def _contains_all(params: Dict[str, Any], k: str = param_key, ts: List[str] = terms) -> bool:
                val = str(params.get(k, "")).lower()
                return all(t in val for t in ts)
            compiled.append(_contains_all)

        # matches
        if "matches" in constraint:
            pattern = re.compile(constraint["matches"])
            def _matches(params: Dict[str, Any], k: str = param_key, p: re.Pattern = pattern) -> bool:  # type: ignore[type-arg]
                return bool(p.search(str(params.get(k, ""))))
            compiled.append(_matches)

        # equals
        if "equals" in constraint:
            expected = constraint["equals"]
            def _equals(params: Dict[str, Any], k: str = param_key, e: Any = expected) -> bool:
                return params.get(k) == e
            compiled.append(_equals)

        # not_equals
        if "not_equals" in constraint:
            expected = constraint["not_equals"]
            def _not_equals(params: Dict[str, Any], k: str = param_key, e: Any = expected) -> bool:
                return params.get(k) != e
            compiled.append(_not_equals)

    def deny_if(params: Dict[str, Any]) -> bool:
        return any(check(params) for check in compiled)

    return deny_if
