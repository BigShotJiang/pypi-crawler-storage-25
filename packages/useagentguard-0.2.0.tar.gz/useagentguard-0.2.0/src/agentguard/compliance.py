"""
agentguard.compliance — Audit-ready compliance report generator.

Generates three types of reports from the AgentGuard audit trail:

1. **Agent Activity Summary** — per-agent breakdown of calls, denials, and cost.
2. **Policy Violation Report** — all denied actions with full context.
3. **Compliance Posture** — mapping of active policies to regulatory frameworks.

Output formats: Python dicts (JSON-serialisable) and Markdown.

Example::

    from agentguard.compliance import ComplianceReport
    from agentguard.registry import Registry

    registry = Registry()
    report = ComplianceReport(registry=registry)

    summary   = report.agent_summary("support-bot", since="2026-03-01")
    violations = report.violations(since="2026-03-01")
    posture    = report.compliance_posture()
    report.export_markdown("compliance-report.md")
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from agentguard import audit as _audit
from agentguard.policies import PolicyEngine


# ---------------------------------------------------------------------------
# Framework control mapping
# ---------------------------------------------------------------------------

#: Maps framework name → control ID → description of how policies address it.
_FRAMEWORK_CONTROLS: Dict[str, Dict[str, str]] = {
    "EU AI Act": {
        "Art.9 — Risk management": (
            "Policies enforce pre-execution checks on AI tool calls, "
            "implementing risk management controls."
        ),
        "Art.12 — Record-keeping": (
            "All tool calls and decisions are written to the immutable audit trail."
        ),
        "Art.14 — Human oversight": (
            "Violation alerts and compliance reports support human oversight "
            "of automated agent decisions."
        ),
        "Art.15 — Accuracy & Robustness": (
            "Parameter constraints and rate limits prevent misuse and "
            "maintain system robustness."
        ),
    },
    "NIST AI RMF": {
        "GOVERN 1.1 — Policies": (
            "Declarative policies define acceptable agent behaviour."
        ),
        "MAP 1.5 — Risk identification": (
            "deny_if predicates and allow lists map to identified risk categories."
        ),
        "MEASURE 2.5 — Monitoring": (
            "Real-time interception and audit logging provide continuous monitoring."
        ),
        "MANAGE 2.2 — Incident response": (
            "Alert hooks and violation reports enable rapid incident response."
        ),
    },
    "ISO 42001": {
        "6.1 — Risk & opportunity": (
            "Policies encode organisational risk appetite for AI tool usage."
        ),
        "8.4 — AI system operation": (
            "MCPInterceptor enforces policies at AI operation time."
        ),
        "9.1 — Performance evaluation": (
            "Compliance reports provide evidence for management review."
        ),
        "10.2 — Nonconformity & corrective action": (
            "Violation reports identify nonconformities for corrective action."
        ),
    },
}


# ---------------------------------------------------------------------------
# ComplianceReport
# ---------------------------------------------------------------------------

class ComplianceReport:
    """Generate compliance reports from the AgentGuard audit trail.

    Args:
        registry: Optional :class:`~agentguard.registry.Registry` instance.
            When provided, agent metadata (owner, capabilities) is included
            in reports.
        policy_engine: Optional :class:`~agentguard.policies.PolicyEngine`.
            Required for :meth:`compliance_posture`.
    """

    def __init__(
        self,
        registry: Optional[Any] = None,
        policy_engine: Optional[PolicyEngine] = None,
        # Legacy kwarg aliases accepted for backwards compatibility
        audit_store: Optional[Any] = None,
    ) -> None:
        self._registry = registry
        self._engine = policy_engine

    # ------------------------------------------------------------------
    # 1. Agent Activity Summary
    # ------------------------------------------------------------------

    def agent_summary(
        self,
        agent_id: str,
        since: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Return a per-agent activity summary.

        Args:
            agent_id: Agent to summarise.
            since: ISO-8601 date string (e.g. ``"2026-03-01"``).

        Returns:
            Dict with keys:

            * ``agent_id``
            * ``total_calls`` — all audit events
            * ``mcp_calls`` — tool-call events specifically
            * ``denied_calls`` — calls that were blocked
            * ``allowed_calls`` — calls that were permitted
            * ``estimated_cost_usd`` — sum of tracked cost events
            * ``top_tools`` — list of ``{tool, count}`` dicts sorted by count
            * ``since`` — the filter applied (or ``"all-time"``)
        """
        events = _audit.query(agent_id=agent_id, since=since)

        mcp_events = [e for e in events if e.get("action") == "mcp_tool_call"]
        denied = [e for e in mcp_events if e.get("outcome") == "denied"]
        allowed = [e for e in mcp_events if e.get("outcome") == "allowed"]

        # Cost tracking (from Guard tier events)
        cost_events = [e for e in events if e.get("action") == "completion_created"]
        total_cost = sum(
            e.get("details", {}).get("estimated_cost_usd", 0.0)
            for e in cost_events
        )

        # Top tools
        tool_counts: Dict[str, int] = {}
        for e in mcp_events:
            tool = e.get("details", {}).get("tool", "unknown")
            tool_counts[tool] = tool_counts.get(tool, 0) + 1
        top_tools = sorted(
            [{"tool": t, "count": c} for t, c in tool_counts.items()],
            key=lambda x: x["count"],
            reverse=True,
        )

        return {
            "agent_id": agent_id,
            "total_calls": len(events),
            "mcp_calls": len(mcp_events),
            "denied_calls": len(denied),
            "allowed_calls": len(allowed),
            "estimated_cost_usd": round(total_cost, 6),
            "top_tools": top_tools,
            "since": since or "all-time",
        }

    def all_agents_summary(
        self,
        since: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Return activity summaries for all registered agents.

        Args:
            since: ISO-8601 date filter.

        Returns:
            List of summary dicts (one per registered agent).
        """
        if self._registry is None:
            return []
        return [
            self.agent_summary(p.agent_id, since=since)
            for p in self._registry.list()
        ]

    # ------------------------------------------------------------------
    # 2. Policy Violation Report
    # ------------------------------------------------------------------

    def violations(
        self,
        since: Optional[str] = None,
        agent_id: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Return all denied MCP tool calls.

        Args:
            since: ISO-8601 date filter.
            agent_id: Filter to a specific agent; if ``None``, query all
                registered agents (requires a registry) or the global log.

        Returns:
            List of violation dicts with keys:

            * ``timestamp``
            * ``agent_id``
            * ``tool``
            * ``policy``
            * ``reason``
            * ``audit_id``
            * ``context_keys``
        """
        raw_events: List[Dict[str, Any]] = []

        if agent_id:
            raw_events = _audit.query(
                agent_id=agent_id,
                since=since,
                action="mcp_tool_call",
                outcome="denied",
            )
        elif self._registry:
            for profile in self._registry.list():
                raw_events.extend(
                    _audit.query(
                        agent_id=profile.agent_id,
                        since=since,
                        action="mcp_tool_call",
                        outcome="denied",
                    )
                )
        else:
            return []

        violations = []
        for e in raw_events:
            details = e.get("details", {})
            violations.append({
                "timestamp": e.get("timestamp"),
                "agent_id": e.get("agent_id"),
                "tool": details.get("tool"),
                "policy": details.get("policy"),
                "reason": details.get("reason"),
                "audit_id": details.get("audit_id"),
                "context_keys": details.get("context_keys", []),
            })

        return sorted(violations, key=lambda v: v.get("timestamp") or "")

    # ------------------------------------------------------------------
    # 3. Compliance Posture
    # ------------------------------------------------------------------

    def compliance_posture(
        self,
        frameworks: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Map active policies to regulatory framework controls.

        Args:
            frameworks: List of framework names to include.  Defaults to
                all known frameworks: ``["EU AI Act", "NIST AI RMF", "ISO 42001"]``.

        Returns:
            Dict with keys:

            * ``generated_at``
            * ``active_policy_count``
            * ``policies`` — list of active policy names
            * ``frameworks`` — dict mapping framework name → list of control dicts
              with ``control``, ``description``, ``satisfied_by`` (policy names).
        """
        target_frameworks = frameworks or list(_FRAMEWORK_CONTROLS.keys())

        active_policies: List[str] = []
        if self._engine:
            active_policies = [p.name for p in self._engine.policies]

        framework_map: Dict[str, List[Dict[str, Any]]] = {}
        for fw_name in target_frameworks:
            controls = _FRAMEWORK_CONTROLS.get(fw_name, {})
            fw_controls = []
            for control_id, description in controls.items():
                fw_controls.append({
                    "control": control_id,
                    "description": description,
                    "satisfied_by": active_policies,
                    "status": "covered" if active_policies else "no-policies",
                })
            framework_map[fw_name] = fw_controls

        return {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "active_policy_count": len(active_policies),
            "policies": active_policies,
            "frameworks": framework_map,
        }

    # ------------------------------------------------------------------
    # Export
    # ------------------------------------------------------------------

    def export_json(self, path: str, since: Optional[str] = None) -> None:
        """Export a full compliance report as JSON.

        Args:
            path: Output file path.
            since: ISO-8601 date filter passed to all sub-reports.
        """
        report = self._build_full_report(since=since)
        Path(path).write_text(
            json.dumps(report, indent=2), encoding="utf-8"
        )

    def export_markdown(self, path: str, since: Optional[str] = None) -> None:
        """Export a full compliance report as Markdown.

        Args:
            path: Output file path (e.g. ``"compliance-report.md"``).
            since: ISO-8601 date filter passed to all sub-reports.
        """
        md = self._render_markdown(since=since)
        Path(path).write_text(md, encoding="utf-8")

    def to_markdown(self, since: Optional[str] = None) -> str:
        """Return the full compliance report as a Markdown string.

        Args:
            since: ISO-8601 date filter.

        Returns:
            Markdown-formatted report.
        """
        return self._render_markdown(since=since)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _build_full_report(self, since: Optional[str] = None) -> Dict[str, Any]:
        return {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "since": since or "all-time",
            "agent_summaries": self.all_agents_summary(since=since),
            "violations": self.violations(since=since),
            "compliance_posture": self.compliance_posture(),
        }

    def _render_markdown(self, since: Optional[str] = None) -> str:
        report = self._build_full_report(since=since)
        lines: List[str] = []

        lines.append("# AgentGuard Compliance Report")
        lines.append(f"\n**Generated:** {report['generated_at']}")
        lines.append(f"**Period:** {report['since']}")
        lines.append("")

        # Agent summaries
        lines.append("## Agent Activity Summary")
        summaries = report.get("agent_summaries", [])
        if summaries:
            lines.append("")
            lines.append("| Agent | MCP Calls | Allowed | Denied | Est. Cost (USD) |")
            lines.append("|-------|-----------|---------|--------|-----------------|")
            for s in summaries:
                lines.append(
                    f"| {s['agent_id']} | {s['mcp_calls']} | "
                    f"{s['allowed_calls']} | {s['denied_calls']} | "
                    f"${s['estimated_cost_usd']:.4f} |"
                )
        else:
            lines.append("\n_No agent data available._")
        lines.append("")

        # Violations
        lines.append("## Policy Violations")
        vios = report.get("violations", [])
        if vios:
            lines.append("")
            lines.append("| Timestamp | Agent | Tool | Policy | Reason |")
            lines.append("|-----------|-------|------|--------|--------|")
            for v in vios:
                reason = (v.get("reason") or "")[:80].replace("|", "\\|")
                lines.append(
                    f"| {v.get('timestamp','')[:19]} | {v.get('agent_id','')} | "
                    f"{v.get('tool','')} | {v.get('policy','')} | {reason} |"
                )
        else:
            lines.append("\n_No violations recorded._")
        lines.append("")

        # Compliance posture
        posture = report.get("compliance_posture", {})
        lines.append("## Compliance Posture")
        lines.append(f"\n**Active policies:** {posture.get('active_policy_count', 0)}")
        policy_list = posture.get("policies", [])
        if policy_list:
            lines.append("\n**Policies loaded:**")
            for p in policy_list:
                lines.append(f"- `{p}`")
        lines.append("")

        for fw_name, controls in posture.get("frameworks", {}).items():
            lines.append(f"### {fw_name}")
            lines.append("")
            for ctrl in controls:
                status_icon = "✅" if ctrl["status"] == "covered" else "⚠️"
                lines.append(f"- {status_icon} **{ctrl['control']}**")
                lines.append(f"  {ctrl['description']}")
            lines.append("")

        return "\n".join(lines)
