"""
agentguard.mcp_interceptor — MCP tool-call interceptor.

Intercepts MCP (Model Context Protocol) tool calls *before* execution,
evaluates them against a :class:`~agentguard.policies.PolicyEngine`, and
returns a structured result indicating whether the call is allowed or denied.

All evaluations are written to the audit trail via :mod:`agentguard.audit`.

Example::

    from agentguard.policies import Policy, PolicyEngine
    from agentguard.mcp_interceptor import MCPInterceptor

    engine = PolicyEngine()
    engine.add_policy(Policy(
        name="no-pii-queries",
        agent_ids=["*"],
        tools=["database_query"],
        deny_if=lambda p: "users" in p.get("query", "").lower(),
    ))

    interceptor = MCPInterceptor(policies=engine)
    result = interceptor.evaluate(
        agent_id="support-bot",
        tool="database_query",
        params={"query": "SELECT * FROM users"},
        context={"user": "kevin@company.com"},
    )
    # result.allowed  → False
    # result.reason   → "Policy 'no-pii-queries' denied this action: ..."
    # result.audit_id → "evt_abc123..."
"""

from __future__ import annotations

import secrets
from typing import Any, Callable, Dict, List, Optional

from agentguard import audit as _audit
from agentguard.policies import EvaluationResult, PolicyEngine


# ---------------------------------------------------------------------------
# MCPInterceptor
# ---------------------------------------------------------------------------

class MCPInterceptor:
    """Evaluates MCP tool calls against a policy engine and audit-logs results.

    Args:
        policies: The :class:`~agentguard.policies.PolicyEngine` to evaluate
            calls against.
        on_violation: What to do when a call is denied.

            * ``"block"``  — return a denied :class:`~agentguard.policies.EvaluationResult`
              (default).
            * ``"warn"``  — return allowed but attach a warning to the result.
            * ``"log"``   — log and allow (audit only, no blocking).
        alert_hooks: Optional list of callables invoked whenever a call is
            denied.  Each hook receives the full
            :class:`~agentguard.policies.EvaluationResult` plus call metadata.

    Example::

        interceptor = MCPInterceptor(
            policies=engine,
            on_violation="block",
        )
    """

    def __init__(
        self,
        policies: PolicyEngine,
        on_violation: str = "block",
        alert_hooks: Optional[List[Callable[[Dict[str, Any]], None]]] = None,
    ) -> None:
        if on_violation not in ("block", "warn", "log"):
            raise ValueError(
                f"on_violation must be 'block', 'warn', or 'log'; got {on_violation!r}"
            )
        self._policies = policies
        self._on_violation = on_violation
        self._alert_hooks: List[Callable[[Dict[str, Any]], None]] = alert_hooks or []

    def evaluate(
        self,
        agent_id: str,
        tool: str,
        params: Optional[Dict[str, Any]] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> EvaluationResult:
        """Evaluate whether *agent_id* may call *tool* with *params*.

        The call is checked against all registered policies.  The result is
        written to the audit trail regardless of outcome.

        Args:
            agent_id: The agent attempting the tool call.
            tool: Name of the MCP tool being called.
            params: Tool parameters dict (defaults to ``{}``).
            context: Caller context dict (user identity, session, time, etc.).

        Returns:
            An :class:`~agentguard.policies.EvaluationResult` with:

            * ``allowed`` — ``True`` / ``False``
            * ``reason``  — human-readable explanation
            * ``audit_id`` — ``"evt_<hex>"`` unique event identifier
        """
        params = params or {}
        ctx = context or {}

        # Evaluate against policy engine
        result = self._policies.evaluate(
            agent_id=agent_id,
            tool=tool,
            params=params,
            context=ctx,
        )

        # Generate a unique audit ID for this event
        audit_id = f"evt_{secrets.token_hex(8)}"
        result.audit_id = audit_id

        # Track whether the policy originally denied the call (before on_violation override)
        policy_denied = not result.allowed

        # Determine effective outcome based on on_violation mode
        if policy_denied and self._on_violation == "warn":
            result.allowed = True
            result.reason = f"[WARN] {result.reason}"
        elif policy_denied and self._on_violation == "log":
            result.allowed = True
            result.reason = f"[LOG-ONLY] {result.reason}"

        # Write to audit trail — outcome reflects the effective decision
        outcome = "allowed" if result.allowed else "denied"
        _audit.log_event(
            agent_id=agent_id,
            action="mcp_tool_call",
            details={
                "tool": tool,
                "params": _safe_params(params),
                "context_keys": list(ctx.keys()),
                "policy": result.policy_name,
                "reason": result.reason,
                "audit_id": audit_id,
                "on_violation": self._on_violation,
            },
            outcome=outcome,
        )

        # Fire alert hooks once whenever the policy originally denied the call
        if policy_denied:
            self._fire_alerts(
                agent_id=agent_id,
                tool=tool,
                params=params,
                context=ctx,
                result=result,
            )

        return result

    def add_alert_hook(self, hook: Callable[[Dict[str, Any]], None]) -> None:
        """Register an alert hook called on every denied evaluation.

        Args:
            hook: Callable that receives a dict with keys:
                ``agent_id``, ``tool``, ``params``, ``context``, ``result``.
        """
        self._alert_hooks.append(hook)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _fire_alerts(
        self,
        agent_id: str,
        tool: str,
        params: Dict[str, Any],
        context: Dict[str, Any],
        result: EvaluationResult,
    ) -> None:
        payload = {
            "agent_id": agent_id,
            "tool": tool,
            "params": _safe_params(params),
            "context": context,
            "result": result,
        }
        for hook in self._alert_hooks:
            try:
                hook(payload)
            except Exception:
                pass  # Alert hooks must never crash the interceptor


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_SENSITIVE_PARAM_KEYS = frozenset({
    "password", "secret", "token", "key", "api_key", "credential",
})


def _safe_params(params: Dict[str, Any]) -> Dict[str, Any]:
    """Return a copy of *params* with sensitive values redacted."""
    return {
        k: ("***REDACTED***" if k.lower() in _SENSITIVE_PARAM_KEYS else v)
        for k, v in params.items()
    }
