"""
agentguard.policies — Policy Engine for MCP tool-call enforcement.

Policies declare which tools each agent can use, parameter constraints,
rate limits, and context-based rules.  The :class:`PolicyEngine` evaluates
a tool call against all applicable policies and returns an
:class:`EvaluationResult`.
"""

from __future__ import annotations

import re
import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple


# ---------------------------------------------------------------------------
# Rate limit configuration
# ---------------------------------------------------------------------------

@dataclass
class RateLimit:
    """Rolling-window rate limit for tool calls.

    Attributes:
        max_calls: Maximum number of calls allowed within *window_seconds*.
        window_seconds: Length of the rolling window in seconds.
    """

    max_calls: int
    window_seconds: int


# ---------------------------------------------------------------------------
# Policy definition
# ---------------------------------------------------------------------------

class Policy:
    """A single enforcement policy.

    A policy matches agent+tool combinations and either allows or denies
    the call, optionally based on a parameter predicate or rate limit.

    Args:
        name: Unique policy name.
        description: Human-readable description.
        agent_ids: List of agent IDs this policy applies to.  ``["*"]``
            means all agents.
        tools: List of tool names this policy applies to.  ``["*"]``
            means all tools.
        action: Default action when no *deny_if* predicate is supplied.
            ``"deny"`` blocks all matched calls; ``"allow"`` is a no-op
            (explicit allow, useful for allow-listing).
        deny_if: Optional callable ``(params) -> bool``.  When it returns
            ``True`` the call is denied.
        allow_if: Optional callable ``(params, context) -> bool``.  When it
            returns ``False`` the call is denied.
        rate_limit: Optional :class:`RateLimit` configuration.

    Example::

        Policy(
            name="no-pii-queries",
            description="Block queries touching PII tables",
            agent_ids=["*"],
            tools=["database_query"],
            deny_if=lambda params: "users" in params.get("query", "").lower(),
        )
    """

    def __init__(
        self,
        name: str,
        description: str = "",
        agent_ids: Optional[List[str]] = None,
        tools: Optional[List[str]] = None,
        action: str = "allow",
        deny_if: Optional[Callable[[Dict[str, Any]], bool]] = None,
        allow_if: Optional[Callable[[Dict[str, Any], Dict[str, Any]], bool]] = None,
        rate_limit: Optional[RateLimit] = None,
    ) -> None:
        self.name = name
        self.description = description
        self.agent_ids: List[str] = agent_ids or ["*"]
        self.tools: List[str] = tools or ["*"]
        self.action = action
        self.deny_if = deny_if
        self.allow_if = allow_if
        self.rate_limit = rate_limit

    def matches_agent(self, agent_id: str) -> bool:
        """Return ``True`` if this policy applies to *agent_id*."""
        return "*" in self.agent_ids or agent_id in self.agent_ids

    def matches_tool(self, tool: str) -> bool:
        """Return ``True`` if this policy applies to *tool*."""
        return "*" in self.tools or tool in self.tools

    def __repr__(self) -> str:
        return (
            f"Policy(name={self.name!r}, agents={self.agent_ids!r}, "
            f"tools={self.tools!r}, action={self.action!r})"
        )


# ---------------------------------------------------------------------------
# Evaluation result
# ---------------------------------------------------------------------------

@dataclass
class EvaluationResult:
    """Result of evaluating a tool call against all policies.

    Attributes:
        allowed: Whether the call is permitted.
        reason: Human-readable explanation (especially on denial).
        policy_name: Name of the policy that made the final decision.
        audit_id: Unique identifier for this evaluation event (``"evt_<hex>"``).
    """

    allowed: bool
    reason: str
    policy_name: Optional[str] = None
    audit_id: str = ""


# ---------------------------------------------------------------------------
# Policy engine
# ---------------------------------------------------------------------------

class PolicyEngine:
    """Evaluates MCP tool calls against a set of :class:`Policy` objects.

    Policies are evaluated in insertion order.  The first policy that
    **denies** a call wins; if no policy denies, the call is allowed.

    Example::

        engine = PolicyEngine()
        engine.add_policy(Policy(
            name="read-only-fs",
            agent_ids=["support-bot"],
            tools=["file_write", "file_delete"],
            action="deny",
        ))

        result = engine.evaluate(
            agent_id="support-bot",
            tool="file_write",
            params={},
            context={},
        )
        assert not result.allowed
    """

    def __init__(self) -> None:
        self._policies: List[Policy] = []
        # rate-limit state: {(policy_name, agent_id, tool): deque[timestamps]}
        self._rate_windows: Dict[Tuple[str, str, str], deque] = defaultdict(deque)

    def add_policy(self, policy: Policy) -> None:
        """Append *policy* to the engine.

        Args:
            policy: The :class:`Policy` to add.
        """
        self._policies.append(policy)

    def remove_policy(self, name: str) -> None:
        """Remove the first policy with the given *name*.

        Args:
            name: Policy name to remove.

        Raises:
            KeyError: If no policy with that name exists.
        """
        for i, p in enumerate(self._policies):
            if p.name == name:
                del self._policies[i]
                return
        raise KeyError(f"No policy named {name!r}")

    @property
    def policies(self) -> List[Policy]:
        """Return a snapshot of the current policy list."""
        return list(self._policies)

    def evaluate(
        self,
        agent_id: str,
        tool: str,
        params: Dict[str, Any],
        context: Optional[Dict[str, Any]] = None,
    ) -> EvaluationResult:
        """Evaluate whether *agent_id* may call *tool* with *params*.

        Args:
            agent_id: The agent attempting the tool call.
            tool: Name of the MCP tool being called.
            params: Tool call parameters.
            context: Caller context (e.g. user identity, time, IP).

        Returns:
            An :class:`EvaluationResult` with ``allowed``, ``reason``,
            and ``audit_id``.
        """
        ctx = context or {}

        for policy in self._policies:
            if not policy.matches_agent(agent_id):
                continue
            if not policy.matches_tool(tool):
                continue

            # --- rate limit check ---
            if policy.rate_limit:
                rl = policy.rate_limit
                key = (policy.name, agent_id, tool)
                window = self._rate_windows[key]
                now = time.monotonic()
                # Evict timestamps outside the window
                while window and now - window[0] > rl.window_seconds:
                    window.popleft()
                if len(window) >= rl.max_calls:
                    return EvaluationResult(
                        allowed=False,
                        reason=(
                            f"Policy '{policy.name}' rate limit exceeded: "
                            f"max {rl.max_calls} calls per {rl.window_seconds}s"
                        ),
                        policy_name=policy.name,
                    )
                # Record this call timestamp
                window.append(now)

            # --- deny_if predicate ---
            if policy.deny_if is not None:
                try:
                    if policy.deny_if(params):
                        return EvaluationResult(
                            allowed=False,
                            reason=f"Policy '{policy.name}' denied this action: {policy.description}",
                            policy_name=policy.name,
                        )
                except Exception as exc:
                    return EvaluationResult(
                        allowed=False,
                        reason=f"Policy '{policy.name}' predicate error: {exc}",
                        policy_name=policy.name,
                    )

            # --- allow_if predicate (explicit conditional allow) ---
            if policy.allow_if is not None:
                try:
                    if not policy.allow_if(params, ctx):
                        return EvaluationResult(
                            allowed=False,
                            reason=f"Policy '{policy.name}' allow condition not met: {policy.description}",
                            policy_name=policy.name,
                        )
                except Exception as exc:
                    return EvaluationResult(
                        allowed=False,
                        reason=f"Policy '{policy.name}' allow_if error: {exc}",
                        policy_name=policy.name,
                    )

            # --- blanket deny action ---
            if policy.action == "deny":
                return EvaluationResult(
                    allowed=False,
                    reason=f"Policy '{policy.name}' denied this action: {policy.description}",
                    policy_name=policy.name,
                )

        # No policy denied — allow
        return EvaluationResult(
            allowed=True,
            reason="No policy denied this action",
        )

    # ------------------------------------------------------------------
    # Class method factory — delegates to policy_loader to avoid circular
    # imports at the module level.
    # ------------------------------------------------------------------

    @classmethod
    def from_yaml(cls, path: str) -> "PolicyEngine":
        """Load a :class:`PolicyEngine` from a YAML policy file.

        Args:
            path: Path to the YAML policy file.

        Returns:
            A configured :class:`PolicyEngine`.

        Example::

            engine = PolicyEngine.from_yaml("policies.yaml")
        """
        from agentguard.policy_loader import load_yaml  # late import

        return load_yaml(path)
