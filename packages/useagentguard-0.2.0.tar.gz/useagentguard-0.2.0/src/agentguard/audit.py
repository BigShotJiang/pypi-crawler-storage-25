"""
agentguard.audit — Audit trail for all agent actions.

Every credential access, scope check, budget event, and drift detection
is appended as a JSON line to ~/.agentguard/audit/{agent_id}/{date}.jsonl.
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional


_AGENTGUARD_HOME = Path(os.environ.get("AGENTGUARD_HOME", Path.home() / ".agentguard"))
_AUDIT_DIR = _AGENTGUARD_HOME / "audit"


def _audit_dir_for(agent_id: str) -> Path:
    """Return (and create if needed) the audit directory for an agent."""
    d = _AUDIT_DIR / agent_id
    d.mkdir(parents=True, exist_ok=True)
    return d


def log_event(
    agent_id: str,
    action: str,
    details: Dict[str, Any],
    outcome: str = "allowed",
) -> None:
    """Append a single audit event for *agent_id*.

    Args:
        agent_id: The agent this event belongs to.
        action: Short action label, e.g. ``"credential_access"``.
        details: Free-form dict with context (service name, scope, etc.).
                 Keys named ``key``, ``secret``, or ``token`` are redacted.
        outcome: ``"allowed"`` or ``"denied"``.
    """
    # Redact sensitive fields before writing
    safe_details = _redact(details)

    event: Dict[str, Any] = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "agent_id": agent_id,
        "action": action,
        "details": safe_details,
        "outcome": outcome,
    }

    date_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    log_file = _audit_dir_for(agent_id) / f"{date_str}.jsonl"

    with log_file.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(event) + "\n")


def query(
    agent_id: str,
    since: Optional[str] = None,
    action: Optional[str] = None,
    outcome: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """Return audit events for *agent_id*, optionally filtered.

    Args:
        agent_id: Agent whose audit log to query.
        since: ISO-8601 date string (e.g. ``"2026-03-01"``).  Only events
               on or after this date are returned.
        action: Filter to events with this action label.
        outcome: Filter to events with this outcome (``"allowed"``/``"denied"``).

    Returns:
        List of event dicts in chronological order.
    """
    audit_dir = _AUDIT_DIR / agent_id
    if not audit_dir.exists():
        return []

    since_dt: Optional[datetime] = None
    if since:
        # Accept "YYYY-MM-DD" or full ISO-8601
        try:
            since_dt = datetime.fromisoformat(since).replace(tzinfo=timezone.utc)
        except ValueError:
            since_dt = datetime.strptime(since, "%Y-%m-%d").replace(tzinfo=timezone.utc)

    events: List[Dict[str, Any]] = []
    for log_file in sorted(audit_dir.glob("*.jsonl")):
        with log_file.open("r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    event = json.loads(line)
                except json.JSONDecodeError:
                    continue

                # Date filter
                if since_dt:
                    event_dt = datetime.fromisoformat(event["timestamp"])
                    if event_dt < since_dt:
                        continue

                # Action filter
                if action and event.get("action") != action:
                    continue

                # Outcome filter
                if outcome and event.get("outcome") != outcome:
                    continue

                events.append(event)

    return events


def clear(agent_id: str) -> None:
    """Delete all audit logs for *agent_id* (useful in tests).

    Args:
        agent_id: Agent whose audit logs to remove.
    """
    import shutil

    audit_dir = _AUDIT_DIR / agent_id
    if audit_dir.exists():
        shutil.rmtree(audit_dir)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

_REDACT_KEYS = frozenset({"key", "secret", "token", "password", "api_key", "new_key"})


def _redact(d: Dict[str, Any]) -> Dict[str, Any]:
    """Return a shallow copy of *d* with sensitive values masked."""
    return {
        k: ("***REDACTED***" if k in _REDACT_KEYS else v)
        for k, v in d.items()
    }
