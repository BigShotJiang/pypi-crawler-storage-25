"""Tests for agentguard.vault — per-agent credential isolation."""

import pytest
from agentguard.vault import AgentVault


def test_store_and_get():
    vault = AgentVault("bot-alpha")
    vault.store("openai", "sk-test-abc123", scopes=["chat.completions"])
    cred = vault.get("openai")
    assert cred.service == "openai"
    assert cred.get_key() == "sk-test-abc123"
    assert cred.scopes == ["chat.completions"]


def test_get_missing_service_raises():
    vault = AgentVault("bot-alpha")
    with pytest.raises(KeyError, match="openai"):
        vault.get("openai")


def test_rotate_updates_key():
    vault = AgentVault("bot-alpha")
    vault.store("openai", "sk-old-key", scopes=["chat.completions"])
    vault.rotate("openai", "sk-new-key")
    cred = vault.get("openai")
    assert cred.get_key() == "sk-new-key"
    assert cred.rotated_at is not None


def test_rotate_missing_service_raises():
    vault = AgentVault("bot-alpha")
    with pytest.raises(KeyError, match="openai"):
        vault.rotate("openai", "sk-new")


def test_delete_credential():
    vault = AgentVault("bot-alpha")
    vault.store("github", "ghp-token", scopes=["repos.read"])
    vault.delete("github")
    with pytest.raises(KeyError):
        vault.get("github")


def test_list_services():
    vault = AgentVault("bot-alpha")
    vault.store("openai", "sk-abc", scopes=[])
    vault.store("github", "ghp-xyz", scopes=[])
    services = vault.list_services()
    assert set(services) == {"openai", "github"}


def test_key_not_in_repr():
    vault = AgentVault("bot-alpha")
    vault.store("openai", "sk-super-secret-key", scopes=[])
    cred = vault.get("openai")
    assert "sk-super-secret-key" not in repr(cred)


def test_empty_agent_id_raises():
    with pytest.raises(ValueError, match="agent_id"):
        AgentVault("")


def test_vault_is_isolated_per_agent():
    vault_a = AgentVault("agent-a")
    vault_b = AgentVault("agent-b")
    vault_a.store("openai", "sk-agent-a", scopes=[])
    with pytest.raises(KeyError):
        vault_b.get("openai")


def test_multiple_stores_overwrite():
    vault = AgentVault("bot-alpha")
    vault.store("openai", "sk-v1")
    vault.store("openai", "sk-v2")
    cred = vault.get("openai")
    assert cred.get_key() == "sk-v2"
