"""Tests for agentguard.drift — permission drift detection."""

import pytest
from agentguard.drift import DriftDetector, ADDED, REMOVED
from agentguard.vault import AgentVault
from agentguard.scopes import ScopeManager
from agentguard.registry import Registry


def _setup_agent(agent_id: str):
    reg = Registry()
    reg.register(agent_id, "team-x", capabilities=["chat"], created_by="test")
    scopes = ScopeManager()
    scopes.set(agent_id, {"openai": ["chat.completions"]})
    vault = AgentVault(agent_id)
    vault.store("openai", "sk-test-key")


def test_snapshot_and_no_drift():
    agent_id = "drift-bot"
    _setup_agent(agent_id)
    drift = DriftDetector()
    drift.snapshot(agent_id)
    changes = drift.check(agent_id)
    assert changes == []


def test_scope_added_detected():
    agent_id = "drift-bot"
    _setup_agent(agent_id)
    drift = DriftDetector()
    drift.snapshot(agent_id)

    # Add a new scope after snapshot
    scopes = ScopeManager()
    scopes.add_scope(agent_id, "openai", "fine-tuning")

    changes = drift.check(agent_id)
    change_types = [c.change_type for c in changes]
    assert ADDED in change_types
    fields = [c.field for c in changes]
    assert any("fine-tuning" in f for f in fields)


def test_scope_removed_detected():
    agent_id = "drift-bot"
    _setup_agent(agent_id)
    drift = DriftDetector()
    drift.snapshot(agent_id)

    # Remove scope after snapshot
    scopes = ScopeManager()
    scopes.remove_scope(agent_id, "openai", "chat.completions")

    changes = drift.check(agent_id)
    change_types = [c.change_type for c in changes]
    assert REMOVED in change_types


def test_credential_added_detected():
    agent_id = "drift-bot"
    _setup_agent(agent_id)
    drift = DriftDetector()
    drift.snapshot(agent_id)

    # Add new credential after snapshot
    vault = AgentVault(agent_id)
    vault.store("github", "ghp-new-token")

    changes = drift.check(agent_id)
    credential_changes = [c for c in changes if c.category == "credential"]
    assert len(credential_changes) >= 1
    assert any(c.change_type == ADDED for c in credential_changes)


def test_capability_added_detected():
    agent_id = "drift-bot"
    _setup_agent(agent_id)
    drift = DriftDetector()
    drift.snapshot(agent_id)

    # Update capabilities after snapshot
    reg = Registry()
    reg.register(agent_id, "team-x", capabilities=["chat", "write"], overwrite=True, created_by="test")

    changes = drift.check(agent_id)
    cap_changes = [c for c in changes if c.category == "capability"]
    assert any(c.change_type == ADDED for c in cap_changes)


def test_no_snapshot_returns_empty():
    drift = DriftDetector()
    changes = drift.check("no-snapshot-agent")
    assert changes == []


def test_get_snapshot_returns_none_when_missing():
    drift = DriftDetector()
    assert drift.get_snapshot("ghost-agent") is None


def test_clear_snapshot():
    agent_id = "drift-bot"
    _setup_agent(agent_id)
    drift = DriftDetector()
    drift.snapshot(agent_id)
    assert drift.get_snapshot(agent_id) is not None
    drift.clear_snapshot(agent_id)
    assert drift.get_snapshot(agent_id) is None
