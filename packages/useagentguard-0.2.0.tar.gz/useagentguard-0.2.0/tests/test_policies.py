"""Tests for agentguard.policies — Policy Engine."""

import time

import pytest

from agentguard.policies import EvaluationResult, Policy, PolicyEngine, RateLimit


# ---------------------------------------------------------------------------
# Basic allow / deny
# ---------------------------------------------------------------------------

def test_allow_by_default():
    engine = PolicyEngine()
    result = engine.evaluate("any-agent", "any-tool", {}, {})
    assert result.allowed is True
    assert "No policy denied" in result.reason


def test_blanket_deny_by_action():
    engine = PolicyEngine()
    engine.add_policy(Policy(
        name="block-delete",
        agent_ids=["*"],
        tools=["file_delete"],
        action="deny",
    ))
    result = engine.evaluate("support-bot", "file_delete", {})
    assert result.allowed is False
    assert result.policy_name == "block-delete"


def test_allow_when_tool_not_matched():
    engine = PolicyEngine()
    engine.add_policy(Policy(
        name="block-delete",
        agent_ids=["*"],
        tools=["file_delete"],
        action="deny",
    ))
    result = engine.evaluate("support-bot", "file_read", {})
    assert result.allowed is True


def test_agent_specific_policy():
    engine = PolicyEngine()
    engine.add_policy(Policy(
        name="read-only",
        agent_ids=["support-bot"],
        tools=["file_write"],
        action="deny",
    ))
    # support-bot is blocked
    assert not engine.evaluate("support-bot", "file_write", {}).allowed
    # other agents are not
    assert engine.evaluate("analytics-bot", "file_write", {}).allowed


def test_wildcard_agent():
    engine = PolicyEngine()
    engine.add_policy(Policy(
        name="no-write",
        agent_ids=["*"],
        tools=["file_write"],
        action="deny",
    ))
    assert not engine.evaluate("any-bot", "file_write", {}).allowed
    assert not engine.evaluate("other-bot", "file_write", {}).allowed


def test_wildcard_tool():
    engine = PolicyEngine()
    engine.add_policy(Policy(
        name="lockdown",
        agent_ids=["locked-agent"],
        tools=["*"],
        action="deny",
    ))
    assert not engine.evaluate("locked-agent", "anything", {}).allowed
    assert engine.evaluate("other-agent", "anything", {}).allowed


# ---------------------------------------------------------------------------
# deny_if predicate
# ---------------------------------------------------------------------------

def test_deny_if_lambda():
    engine = PolicyEngine()
    engine.add_policy(Policy(
        name="no-pii",
        agent_ids=["*"],
        tools=["database_query"],
        deny_if=lambda p: "users" in p.get("query", "").lower(),
    ))
    denied = engine.evaluate("bot", "database_query", {"query": "SELECT * FROM users"})
    assert denied.allowed is False
    assert "no-pii" in denied.reason

    allowed = engine.evaluate("bot", "database_query", {"query": "SELECT * FROM products"})
    assert allowed.allowed is True


def test_deny_if_false_does_not_block():
    engine = PolicyEngine()
    engine.add_policy(Policy(
        name="safe",
        agent_ids=["*"],
        tools=["*"],
        deny_if=lambda p: False,
    ))
    assert engine.evaluate("bot", "tool", {}).allowed is True


def test_deny_if_exception_causes_deny():
    engine = PolicyEngine()
    engine.add_policy(Policy(
        name="broken",
        agent_ids=["*"],
        tools=["*"],
        deny_if=lambda p: 1 / 0,  # ZeroDivisionError
    ))
    result = engine.evaluate("bot", "tool", {})
    assert result.allowed is False
    assert "predicate error" in result.reason


# ---------------------------------------------------------------------------
# allow_if predicate
# ---------------------------------------------------------------------------

def test_allow_if_passes():
    engine = PolicyEngine()
    engine.add_policy(Policy(
        name="require-user",
        agent_ids=["*"],
        tools=["*"],
        allow_if=lambda params, ctx: bool(ctx.get("user")),
    ))
    assert engine.evaluate("bot", "tool", {}, {"user": "alice"}).allowed is True


def test_allow_if_fails():
    engine = PolicyEngine()
    engine.add_policy(Policy(
        name="require-user",
        agent_ids=["*"],
        tools=["*"],
        allow_if=lambda params, ctx: bool(ctx.get("user")),
    ))
    result = engine.evaluate("bot", "tool", {}, {})
    assert result.allowed is False
    assert "require-user" in result.reason


# ---------------------------------------------------------------------------
# Rate limits
# ---------------------------------------------------------------------------

def test_rate_limit_allows_within_window():
    engine = PolicyEngine()
    engine.add_policy(Policy(
        name="rl",
        agent_ids=["*"],
        tools=["*"],
        rate_limit=RateLimit(max_calls=3, window_seconds=10),
    ))
    for _ in range(3):
        assert engine.evaluate("bot", "tool", {}).allowed is True


def test_rate_limit_blocks_when_exceeded():
    engine = PolicyEngine()
    engine.add_policy(Policy(
        name="rl",
        agent_ids=["*"],
        tools=["*"],
        rate_limit=RateLimit(max_calls=2, window_seconds=10),
    ))
    engine.evaluate("bot", "tool", {})
    engine.evaluate("bot", "tool", {})
    result = engine.evaluate("bot", "tool", {})
    assert result.allowed is False
    assert "rate limit" in result.reason.lower()


def test_rate_limit_resets_after_window():
    engine = PolicyEngine()
    engine.add_policy(Policy(
        name="rl",
        agent_ids=["*"],
        tools=["*"],
        rate_limit=RateLimit(max_calls=1, window_seconds=1),
    ))
    assert engine.evaluate("bot", "tool", {}).allowed is True
    # exhaust
    result = engine.evaluate("bot", "tool", {})
    assert result.allowed is False
    # wait for window to expire
    time.sleep(1.1)
    assert engine.evaluate("bot", "tool", {}).allowed is True


# ---------------------------------------------------------------------------
# Policy management
# ---------------------------------------------------------------------------

def test_add_and_remove_policy():
    engine = PolicyEngine()
    engine.add_policy(Policy(name="p1", tools=["file_delete"], action="deny"))
    assert not engine.evaluate("bot", "file_delete", {}).allowed
    engine.remove_policy("p1")
    assert engine.evaluate("bot", "file_delete", {}).allowed


def test_remove_nonexistent_raises():
    engine = PolicyEngine()
    with pytest.raises(KeyError):
        engine.remove_policy("does-not-exist")


def test_policies_property():
    engine = PolicyEngine()
    p = Policy(name="x")
    engine.add_policy(p)
    assert engine.policies[0].name == "x"


# ---------------------------------------------------------------------------
# EvaluationResult
# ---------------------------------------------------------------------------

def test_evaluation_result_fields():
    result = EvaluationResult(allowed=True, reason="ok", policy_name=None, audit_id="evt_abc")
    assert result.allowed is True
    assert result.reason == "ok"
    assert result.audit_id == "evt_abc"


# ---------------------------------------------------------------------------
# Policy repr
# ---------------------------------------------------------------------------

def test_policy_repr():
    p = Policy(name="test-policy", agent_ids=["bot"], tools=["tool1"], action="deny")
    r = repr(p)
    assert "test-policy" in r
    assert "deny" in r
