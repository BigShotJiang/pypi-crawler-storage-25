"""Tests for agentguard.mcp_interceptor — MCP tool-call interceptor."""

import pytest

from agentguard import audit
from agentguard.mcp_interceptor import MCPInterceptor
from agentguard.policies import Policy, PolicyEngine


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_engine_with_deny(tool: str = "file_delete") -> PolicyEngine:
    engine = PolicyEngine()
    engine.add_policy(Policy(
        name="no-delete",
        agent_ids=["*"],
        tools=[tool],
        action="deny",
    ))
    return engine


# ---------------------------------------------------------------------------
# Basic allow / deny
# ---------------------------------------------------------------------------

def test_allow_passes_through():
    engine = PolicyEngine()  # no policies = allow everything
    interceptor = MCPInterceptor(policies=engine)
    result = interceptor.evaluate("bot", "safe_tool", {"x": 1})
    assert result.allowed is True
    assert result.audit_id.startswith("evt_")


def test_deny_blocks_call():
    interceptor = MCPInterceptor(policies=make_engine_with_deny())
    result = interceptor.evaluate("bot", "file_delete", {})
    assert result.allowed is False
    assert "no-delete" in result.reason
    assert result.audit_id.startswith("evt_")


def test_deny_with_pii_predicate():
    engine = PolicyEngine()
    engine.add_policy(Policy(
        name="no-pii",
        agent_ids=["*"],
        tools=["db_query"],
        deny_if=lambda p: "users" in p.get("query", "").lower(),
    ))
    interceptor = MCPInterceptor(policies=engine)

    bad = interceptor.evaluate("bot", "db_query", {"query": "SELECT * FROM users"})
    assert bad.allowed is False

    good = interceptor.evaluate("bot", "db_query", {"query": "SELECT * FROM products"})
    assert good.allowed is True


# ---------------------------------------------------------------------------
# on_violation modes
# ---------------------------------------------------------------------------

def test_on_violation_block_default():
    interceptor = MCPInterceptor(policies=make_engine_with_deny(), on_violation="block")
    result = interceptor.evaluate("bot", "file_delete", {})
    assert result.allowed is False


def test_on_violation_warn_allows_but_warns():
    interceptor = MCPInterceptor(policies=make_engine_with_deny(), on_violation="warn")
    result = interceptor.evaluate("bot", "file_delete", {})
    assert result.allowed is True
    assert "[WARN]" in result.reason


def test_on_violation_log_allows_silently():
    interceptor = MCPInterceptor(policies=make_engine_with_deny(), on_violation="log")
    result = interceptor.evaluate("bot", "file_delete", {})
    assert result.allowed is True
    assert "[LOG-ONLY]" in result.reason


def test_invalid_on_violation_raises():
    with pytest.raises(ValueError):
        MCPInterceptor(policies=PolicyEngine(), on_violation="invalid")


# ---------------------------------------------------------------------------
# Audit trail
# ---------------------------------------------------------------------------

def test_denied_call_written_to_audit():
    agent_id = "audit-test-bot-deny"
    audit.clear(agent_id)

    interceptor = MCPInterceptor(policies=make_engine_with_deny())
    interceptor.evaluate(agent_id, "file_delete", {})

    events = audit.query(agent_id, action="mcp_tool_call", outcome="denied")
    assert len(events) == 1
    assert events[0]["details"]["tool"] == "file_delete"


def test_allowed_call_written_to_audit():
    agent_id = "audit-test-bot-allow"
    audit.clear(agent_id)

    interceptor = MCPInterceptor(policies=PolicyEngine())
    interceptor.evaluate(agent_id, "safe_tool", {"data": "value"})

    events = audit.query(agent_id, action="mcp_tool_call", outcome="allowed")
    assert len(events) == 1
    assert events[0]["details"]["tool"] == "safe_tool"


def test_audit_id_in_audit_event():
    agent_id = "audit-id-bot"
    audit.clear(agent_id)

    interceptor = MCPInterceptor(policies=PolicyEngine())
    result = interceptor.evaluate(agent_id, "tool_x", {})

    events = audit.query(agent_id, action="mcp_tool_call")
    assert events[-1]["details"]["audit_id"] == result.audit_id


# ---------------------------------------------------------------------------
# Alert hooks
# ---------------------------------------------------------------------------

def test_alert_hook_called_on_deny():
    alerts = []

    def hook(payload):
        alerts.append(payload)

    interceptor = MCPInterceptor(
        policies=make_engine_with_deny(),
        alert_hooks=[hook],
    )
    interceptor.evaluate("bot", "file_delete", {})
    assert len(alerts) == 1
    assert alerts[0]["tool"] == "file_delete"
    assert alerts[0]["agent_id"] == "bot"


def test_alert_hook_not_called_on_allow():
    alerts = []
    interceptor = MCPInterceptor(
        policies=PolicyEngine(),
        alert_hooks=[lambda p: alerts.append(p)],
    )
    interceptor.evaluate("bot", "safe_tool", {})
    assert len(alerts) == 0


def test_add_alert_hook():
    alerts = []
    interceptor = MCPInterceptor(policies=make_engine_with_deny())
    interceptor.add_alert_hook(lambda p: alerts.append(p))
    interceptor.evaluate("bot", "file_delete", {})
    assert len(alerts) >= 1


def test_alert_hook_exception_does_not_crash_interceptor():
    def bad_hook(payload):
        raise RuntimeError("oops")

    interceptor = MCPInterceptor(
        policies=make_engine_with_deny(),
        alert_hooks=[bad_hook],
    )
    # Should not raise
    result = interceptor.evaluate("bot", "file_delete", {})
    assert result.allowed is False


# ---------------------------------------------------------------------------
# Sensitive param redaction
# ---------------------------------------------------------------------------

def test_sensitive_params_are_redacted_in_audit():
    agent_id = "redact-test-bot"
    audit.clear(agent_id)

    interceptor = MCPInterceptor(policies=PolicyEngine())
    interceptor.evaluate(agent_id, "auth_tool", {"token": "super-secret", "user": "alice"})

    events = audit.query(agent_id, action="mcp_tool_call")
    params = events[-1]["details"]["params"]
    assert params["token"] == "***REDACTED***"
    assert params["user"] == "alice"


# ---------------------------------------------------------------------------
# Context pass-through
# ---------------------------------------------------------------------------

def test_context_keys_logged():
    agent_id = "ctx-bot"
    audit.clear(agent_id)

    interceptor = MCPInterceptor(policies=PolicyEngine())
    interceptor.evaluate(agent_id, "tool", {}, context={"user": "alice", "ip": "1.2.3.4"})

    events = audit.query(agent_id, action="mcp_tool_call")
    ctx_keys = events[-1]["details"]["context_keys"]
    assert "user" in ctx_keys
    assert "ip" in ctx_keys
