"""Tests for agentguard.audit — audit trail."""

import pytest
from agentguard import audit


def test_log_and_query():
    audit.log_event("bot-a", "test_action", {"info": "hello"}, outcome="allowed")
    events = audit.query("bot-a")
    assert len(events) >= 1
    assert events[-1]["action"] == "test_action"
    assert events[-1]["outcome"] == "allowed"
    assert events[-1]["agent_id"] == "bot-a"


def test_query_since_filter():
    audit.log_event("bot-b", "old_event", {}, outcome="allowed")
    events = audit.query("bot-b", since="2099-01-01")
    assert events == []


def test_query_action_filter():
    audit.log_event("bot-c", "login", {}, outcome="allowed")
    audit.log_event("bot-c", "logout", {}, outcome="allowed")
    events = audit.query("bot-c", action="login")
    assert all(e["action"] == "login" for e in events)


def test_query_outcome_filter():
    audit.log_event("bot-d", "scope_check", {}, outcome="allowed")
    audit.log_event("bot-d", "scope_check", {}, outcome="denied")
    denied = audit.query("bot-d", outcome="denied")
    assert all(e["outcome"] == "denied" for e in denied)
    allowed = audit.query("bot-d", outcome="allowed")
    assert all(e["outcome"] == "allowed" for e in allowed)


def test_sensitive_keys_are_redacted():
    audit.log_event("bot-e", "test", {"key": "secret-value", "info": "safe"}, outcome="allowed")
    events = audit.query("bot-e")
    last = events[-1]
    assert last["details"]["key"] == "***REDACTED***"
    assert last["details"]["info"] == "safe"


def test_query_no_events_returns_empty():
    events = audit.query("no-such-agent")
    assert events == []


def test_clear_removes_logs():
    audit.log_event("bot-f", "action", {}, outcome="allowed")
    assert len(audit.query("bot-f")) >= 1
    audit.clear("bot-f")
    assert audit.query("bot-f") == []


def test_event_has_timestamp():
    audit.log_event("bot-g", "ping", {}, outcome="allowed")
    events = audit.query("bot-g")
    assert "timestamp" in events[-1]
    assert "T" in events[-1]["timestamp"]  # ISO-8601 format
