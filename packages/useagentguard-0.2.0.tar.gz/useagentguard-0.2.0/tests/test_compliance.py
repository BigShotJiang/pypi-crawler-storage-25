"""Tests for agentguard.compliance — Compliance Report Generator."""

import json
import os
import tempfile

import pytest

from agentguard import audit
from agentguard.compliance import ComplianceReport
from agentguard.mcp_interceptor import MCPInterceptor
from agentguard.policies import Policy, PolicyEngine
from agentguard.registry import Registry


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_registry_with_agents(*agent_ids: str) -> Registry:
    """Create a fresh (in-memory) registry with given agents."""
    import os
    with tempfile.TemporaryDirectory() as tmp:
        os.environ["AGENTGUARD_HOME"] = tmp
        r = Registry()
        for aid in agent_ids:
            try:
                r.register(aid, owner="test-team", created_by="forge")
            except ValueError:
                pass  # already registered
        return r


def seed_mcp_events(agent_id: str, allowed: int = 0, denied: int = 0) -> None:
    """Seed MCP audit events for an agent."""
    audit.clear(agent_id)
    for _ in range(allowed):
        audit.log_event(agent_id, "mcp_tool_call", {"tool": "safe_tool"}, outcome="allowed")
    for _ in range(denied):
        audit.log_event(
            agent_id, "mcp_tool_call",
            {"tool": "file_delete", "policy": "no-delete", "reason": "blocked", "audit_id": "evt_x", "context_keys": []},
            outcome="denied",
        )


# ---------------------------------------------------------------------------
# Agent Activity Summary
# ---------------------------------------------------------------------------

class TestAgentSummary:

    def test_empty_returns_zeros(self):
        audit.clear("no-events-bot")
        report = ComplianceReport()
        summary = report.agent_summary("no-events-bot")
        assert summary["agent_id"] == "no-events-bot"
        assert summary["mcp_calls"] == 0
        assert summary["denied_calls"] == 0
        assert summary["allowed_calls"] == 0

    def test_counts_mcp_events(self):
        agent = "summary-bot"
        seed_mcp_events(agent, allowed=5, denied=2)
        report = ComplianceReport()
        s = report.agent_summary(agent)
        assert s["mcp_calls"] == 7
        assert s["allowed_calls"] == 5
        assert s["denied_calls"] == 2

    def test_since_filter(self):
        agent = "since-bot"
        audit.clear(agent)
        audit.log_event(agent, "mcp_tool_call", {"tool": "t"}, outcome="allowed")
        report = ComplianceReport()
        # Far future should exclude all events
        s = report.agent_summary(agent, since="2099-01-01")
        assert s["mcp_calls"] == 0

    def test_top_tools(self):
        agent = "top-tools-bot"
        audit.clear(agent)
        for _ in range(3):
            audit.log_event(agent, "mcp_tool_call", {"tool": "tool_a"}, outcome="allowed")
        for _ in range(1):
            audit.log_event(agent, "mcp_tool_call", {"tool": "tool_b"}, outcome="allowed")
        report = ComplianceReport()
        s = report.agent_summary(agent)
        assert s["top_tools"][0]["tool"] == "tool_a"
        assert s["top_tools"][0]["count"] == 3

    def test_since_field_in_summary(self):
        report = ComplianceReport()
        s = report.agent_summary("bot", since="2026-01-01")
        assert s["since"] == "2026-01-01"

    def test_all_agents_summary_requires_registry(self):
        report = ComplianceReport()  # no registry
        result = report.all_agents_summary()
        assert result == []


# ---------------------------------------------------------------------------
# Policy Violation Report
# ---------------------------------------------------------------------------

class TestViolations:

    def test_no_violations_returns_empty(self):
        agent = "clean-bot"
        audit.clear(agent)
        report = ComplianceReport()
        assert report.violations(agent_id=agent) == []

    def test_violations_with_agent_id(self):
        agent = "vio-bot"
        seed_mcp_events(agent, denied=3)
        report = ComplianceReport()
        vios = report.violations(agent_id=agent)
        assert len(vios) == 3
        for v in vios:
            assert v["agent_id"] == agent
            assert v["tool"] == "file_delete"

    def test_violations_sorted_by_timestamp(self):
        agent = "sorted-vio-bot"
        seed_mcp_events(agent, denied=2)
        report = ComplianceReport()
        vios = report.violations(agent_id=agent)
        timestamps = [v["timestamp"] for v in vios]
        assert timestamps == sorted(timestamps)

    def test_violations_without_registry_or_agent_id(self):
        report = ComplianceReport()  # no registry, no agent_id
        result = report.violations()
        assert result == []

    def test_violations_with_registry(self):
        import os
        with tempfile.TemporaryDirectory() as tmp:
            os.environ["AGENTGUARD_HOME"] = tmp
            agent = "reg-vio-bot"
            audit.clear(agent)
            seed_mcp_events(agent, denied=2)
            # Build a report with a real registry
            r = Registry()
            r.register(agent, owner="team", created_by="forge")
            report = ComplianceReport(registry=r)
            vios = report.violations()
            # Filter to our test agent
            our_vios = [v for v in vios if v["agent_id"] == agent]
            assert len(our_vios) == 2
        os.environ.pop("AGENTGUARD_HOME", None)


# ---------------------------------------------------------------------------
# Compliance Posture
# ---------------------------------------------------------------------------

class TestCompliancePosture:

    def test_posture_without_engine(self):
        report = ComplianceReport()
        posture = report.compliance_posture()
        assert "generated_at" in posture
        assert posture["active_policy_count"] == 0
        assert "EU AI Act" in posture["frameworks"]
        assert "NIST AI RMF" in posture["frameworks"]
        assert "ISO 42001" in posture["frameworks"]

    def test_posture_with_engine(self):
        engine = PolicyEngine()
        engine.add_policy(Policy(name="p1", action="deny"))
        engine.add_policy(Policy(name="p2", action="allow"))
        report = ComplianceReport(policy_engine=engine)
        posture = report.compliance_posture()
        assert posture["active_policy_count"] == 2
        assert "p1" in posture["policies"]
        assert "p2" in posture["policies"]

    def test_posture_covered_status(self):
        engine = PolicyEngine()
        engine.add_policy(Policy(name="guard"))
        report = ComplianceReport(policy_engine=engine)
        posture = report.compliance_posture()
        for fw_controls in posture["frameworks"].values():
            for ctrl in fw_controls:
                assert ctrl["status"] == "covered"

    def test_posture_no_policies_status(self):
        report = ComplianceReport()
        posture = report.compliance_posture()
        for fw_controls in posture["frameworks"].values():
            for ctrl in fw_controls:
                assert ctrl["status"] == "no-policies"

    def test_posture_framework_filter(self):
        report = ComplianceReport()
        posture = report.compliance_posture(frameworks=["NIST AI RMF"])
        assert "NIST AI RMF" in posture["frameworks"]
        assert "EU AI Act" not in posture["frameworks"]

    def test_posture_controls_have_required_fields(self):
        report = ComplianceReport()
        posture = report.compliance_posture()
        for fw_controls in posture["frameworks"].values():
            for ctrl in fw_controls:
                assert "control" in ctrl
                assert "description" in ctrl
                assert "satisfied_by" in ctrl
                assert "status" in ctrl


# ---------------------------------------------------------------------------
# Export
# ---------------------------------------------------------------------------

class TestExport:

    def test_export_json(self):
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            path = f.name
        try:
            report = ComplianceReport()
            report.export_json(path)
            data = json.loads(open(path).read())
            assert "generated_at" in data
            assert "violations" in data
            assert "compliance_posture" in data
        finally:
            os.unlink(path)

    def test_export_markdown(self):
        with tempfile.NamedTemporaryFile(suffix=".md", delete=False) as f:
            path = f.name
        try:
            report = ComplianceReport()
            report.export_markdown(path)
            content = open(path).read()
            assert "# AgentGuard Compliance Report" in content
            assert "## Agent Activity Summary" in content
            assert "## Policy Violations" in content
            assert "## Compliance Posture" in content
        finally:
            os.unlink(path)

    def test_to_markdown_returns_string(self):
        report = ComplianceReport()
        md = report.to_markdown()
        assert isinstance(md, str)
        assert "AgentGuard" in md

    def test_markdown_contains_eu_ai_act(self):
        report = ComplianceReport()
        md = report.to_markdown()
        assert "EU AI Act" in md

    def test_markdown_with_violations(self):
        agent = "md-vio-bot"
        seed_mcp_events(agent, denied=1)
        import tempfile, os
        with tempfile.TemporaryDirectory() as tmp:
            os.environ["AGENTGUARD_HOME"] = tmp
            r = Registry()
            r.register(agent, owner="team", created_by="forge")
            # re-seed since AGENTGUARD_HOME changed
            seed_mcp_events(agent, denied=1)
            report = ComplianceReport(registry=r)
            md = report.to_markdown()
            assert "file_delete" in md or "no-delete" in md or "_No violations" in md
        os.environ.pop("AGENTGUARD_HOME", None)


# ---------------------------------------------------------------------------
# Integration: interceptor → audit → report
# ---------------------------------------------------------------------------

class TestIntegration:

    def test_interceptor_feeds_compliance_report(self):
        agent = "integration-bot"
        audit.clear(agent)

        engine = PolicyEngine()
        engine.add_policy(Policy(
            name="no-drop",
            agent_ids=["*"],
            tools=["dangerous_tool"],
            action="deny",
        ))
        interceptor = MCPInterceptor(policies=engine)
        interceptor.evaluate(agent, "safe_tool", {})
        interceptor.evaluate(agent, "dangerous_tool", {})
        interceptor.evaluate(agent, "safe_tool", {})

        report = ComplianceReport()
        summary = report.agent_summary(agent)
        assert summary["mcp_calls"] == 3
        assert summary["denied_calls"] == 1
        assert summary["allowed_calls"] == 2

        vios = report.violations(agent_id=agent)
        assert len(vios) == 1
        assert vios[0]["tool"] == "dangerous_tool"
