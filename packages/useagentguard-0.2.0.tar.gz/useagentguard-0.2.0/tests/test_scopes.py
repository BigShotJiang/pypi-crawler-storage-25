"""Tests for agentguard.scopes — OAuth scope enforcement."""

import pytest
from agentguard.scopes import ScopeManager, ScopeViolation


def test_set_and_get_policy():
    scopes = ScopeManager()
    scopes.set("support-bot", {"openai": ["chat.completions"], "github": ["repos.read"]})
    policy = scopes.get("support-bot")
    assert "openai" in policy
    assert "chat.completions" in policy["openai"]


def test_check_allowed_scope():
    scopes = ScopeManager()
    scopes.set("support-bot", {"openai": ["chat.completions"]})
    # Should not raise
    scopes.check("support-bot", "openai", "chat.completions")


def test_check_denied_scope_raises():
    scopes = ScopeManager()
    scopes.set("support-bot", {"openai": ["chat.completions"]})
    with pytest.raises(ScopeViolation) as exc_info:
        scopes.check("support-bot", "openai", "fine-tuning")
    err = exc_info.value
    assert err.agent_id == "support-bot"
    assert err.service == "openai"
    assert err.requested_scope == "fine-tuning"


def test_check_no_policy_raises():
    scopes = ScopeManager()
    with pytest.raises(ScopeViolation):
        scopes.check("unknown-bot", "openai", "chat.completions")


def test_is_allowed_returns_bool():
    scopes = ScopeManager()
    scopes.set("bot", {"svc": ["read"]})
    assert scopes.is_allowed("bot", "svc", "read") is True
    assert scopes.is_allowed("bot", "svc", "write") is False


def test_add_scope():
    scopes = ScopeManager()
    scopes.set("bot", {"openai": ["chat.completions"]})
    scopes.add_scope("bot", "openai", "embeddings")
    policy = scopes.get("bot")
    assert "embeddings" in policy["openai"]


def test_remove_scope():
    scopes = ScopeManager()
    scopes.set("bot", {"openai": ["chat.completions", "embeddings"]})
    scopes.remove_scope("bot", "openai", "embeddings")
    policy = scopes.get("bot")
    assert "embeddings" not in policy["openai"]
    assert "chat.completions" in policy["openai"]


def test_remove_missing_scope_raises():
    scopes = ScopeManager()
    scopes.set("bot", {"openai": ["chat.completions"]})
    with pytest.raises(KeyError):
        scopes.remove_scope("bot", "openai", "nonexistent")


def test_clear_policy():
    scopes = ScopeManager()
    scopes.set("bot", {"openai": ["chat.completions"]})
    scopes.clear("bot")
    assert scopes.get("bot") == {}


def test_scope_violation_audit_logged():
    import agentguard.audit as audit
    scopes = ScopeManager()
    scopes.set("bot", {"openai": ["chat.completions"]})
    with pytest.raises(ScopeViolation):
        scopes.check("bot", "openai", "admin")
    logs = audit.query("bot", action="scope_check", outcome="denied")
    assert len(logs) >= 1
