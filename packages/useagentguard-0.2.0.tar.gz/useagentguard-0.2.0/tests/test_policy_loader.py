"""Tests for agentguard.policy_loader — YAML policy file loading."""

import os
import tempfile

import pytest

from agentguard.policies import PolicyEngine
from agentguard.policy_loader import load_yaml, load_yaml_string


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_BASIC_YAML = """
policies:
  - name: no-pii-queries
    description: "Agents cannot query PII tables"
    agents: ["*"]
    tools: ["database_query"]
    deny_params:
      query:
        contains_any: ["users", "credentials", "payments"]

  - name: read-only-fs
    description: "Support bot is read-only"
    agents: ["support-bot"]
    tools: ["file_write", "file_delete"]
    action: deny

  - name: rate-limit
    description: "100 calls/min per agent"
    agents: ["*"]
    tools: ["*"]
    rate_limit:
      max_calls: 100
      window_seconds: 60
"""


def yaml_file(content: str):
    """Write YAML to a temp file and return its path."""
    f = tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False)
    f.write(content)
    f.flush()
    return f.name


# ---------------------------------------------------------------------------
# load_yaml_string
# ---------------------------------------------------------------------------

def test_load_yaml_string_returns_engine():
    engine = load_yaml_string(_BASIC_YAML)
    assert isinstance(engine, PolicyEngine)
    assert len(engine.policies) == 3


def test_policy_names_loaded():
    engine = load_yaml_string(_BASIC_YAML)
    names = [p.name for p in engine.policies]
    assert "no-pii-queries" in names
    assert "read-only-fs" in names
    assert "rate-limit" in names


def test_deny_params_contains_any():
    engine = load_yaml_string(_BASIC_YAML)
    # Denied: query contains "users"
    result = engine.evaluate("bot", "database_query", {"query": "SELECT * FROM users"})
    assert result.allowed is False

    # Denied: query contains "credentials"
    result = engine.evaluate("bot", "database_query", {"query": "SELECT * FROM credentials"})
    assert result.allowed is False

    # Allowed: query is safe
    result = engine.evaluate("bot", "database_query", {"query": "SELECT * FROM products"})
    assert result.allowed is True


def test_blanket_deny_from_yaml():
    engine = load_yaml_string(_BASIC_YAML)
    # support-bot cannot file_write
    result = engine.evaluate("support-bot", "file_write", {})
    assert result.allowed is False

    # other bots can file_write (no matching deny policy)
    result = engine.evaluate("analytics-bot", "file_write", {})
    assert result.allowed is True


def test_rate_limit_from_yaml():
    yaml = """
policies:
  - name: tight-limit
    agents: ["*"]
    tools: ["*"]
    rate_limit:
      max_calls: 2
      window_seconds: 30
"""
    engine = load_yaml_string(yaml)
    assert engine.evaluate("bot", "tool", {}).allowed is True
    assert engine.evaluate("bot", "tool", {}).allowed is True
    result = engine.evaluate("bot", "tool", {})
    assert result.allowed is False
    assert "rate limit" in result.reason.lower()


# ---------------------------------------------------------------------------
# contains_all constraint
# ---------------------------------------------------------------------------

def test_deny_params_contains_all():
    yaml = """
policies:
  - name: both-words
    agents: ["*"]
    tools: ["search"]
    deny_params:
      query:
        contains_all: ["drop", "table"]
"""
    engine = load_yaml_string(yaml)
    assert not engine.evaluate("bot", "search", {"query": "drop table users"}).allowed
    assert engine.evaluate("bot", "search", {"query": "drop everything"}).allowed
    assert engine.evaluate("bot", "search", {"query": "show table"}).allowed


# ---------------------------------------------------------------------------
# matches (regex) constraint
# ---------------------------------------------------------------------------

def test_deny_params_matches_regex():
    yaml = r"""
policies:
  - name: no-ssn
    agents: ["*"]
    tools: ["*"]
    deny_params:
      text:
        matches: '\d{3}-\d{2}-\d{4}'
"""
    engine = load_yaml_string(yaml)
    assert not engine.evaluate("bot", "anything", {"text": "SSN: 123-45-6789"}).allowed
    assert engine.evaluate("bot", "anything", {"text": "Hello world"}).allowed


# ---------------------------------------------------------------------------
# equals / not_equals constraints
# ---------------------------------------------------------------------------

def test_deny_params_equals():
    yaml = """
policies:
  - name: no-admin-role
    agents: ["*"]
    tools: ["set_role"]
    deny_params:
      role:
        equals: "admin"
"""
    engine = load_yaml_string(yaml)
    assert not engine.evaluate("bot", "set_role", {"role": "admin"}).allowed
    assert engine.evaluate("bot", "set_role", {"role": "viewer"}).allowed


def test_deny_params_not_equals():
    yaml = """
policies:
  - name: must-be-read
    agents: ["*"]
    tools: ["file_op"]
    deny_params:
      mode:
        not_equals: "read"
"""
    engine = load_yaml_string(yaml)
    assert not engine.evaluate("bot", "file_op", {"mode": "write"}).allowed
    assert engine.evaluate("bot", "file_op", {"mode": "read"}).allowed


# ---------------------------------------------------------------------------
# load_yaml from file
# ---------------------------------------------------------------------------

def test_load_yaml_from_file():
    path = yaml_file(_BASIC_YAML)
    try:
        engine = load_yaml(path)
        assert len(engine.policies) == 3
    finally:
        os.unlink(path)


def test_load_yaml_file_not_found():
    with pytest.raises(FileNotFoundError):
        load_yaml("/tmp/does-not-exist-agentguard.yaml")


# ---------------------------------------------------------------------------
# PolicyEngine.from_yaml shortcut
# ---------------------------------------------------------------------------

def test_from_yaml_class_method():
    path = yaml_file(_BASIC_YAML)
    try:
        engine = PolicyEngine.from_yaml(path)
        assert len(engine.policies) == 3
    finally:
        os.unlink(path)


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------

def test_missing_policy_name_raises():
    yaml = """
policies:
  - description: "No name"
    agents: ["*"]
    tools: ["*"]
    action: deny
"""
    with pytest.raises(ValueError, match="missing 'name'"):
        load_yaml_string(yaml)


def test_invalid_rate_limit_raises():
    yaml = """
policies:
  - name: bad-rl
    agents: ["*"]
    tools: ["*"]
    rate_limit:
      max_calls: "not-a-number"
      window_seconds: 60
"""
    with pytest.raises(ValueError):
        load_yaml_string(yaml)


def test_empty_yaml_returns_empty_engine():
    engine = load_yaml_string("")
    assert engine.policies == []


def test_yaml_with_no_policies_key():
    engine = load_yaml_string("other_key: value")
    assert engine.policies == []
