"""Tests for agentguard.registry — agent identity registry."""

import pytest
from agentguard.registry import Registry


def test_register_and_get():
    reg = Registry()
    reg.register(
        agent_id="support-bot",
        owner="team-cs",
        capabilities=["chat", "search"],
        created_by="kevin@company.com",
    )
    profile = reg.get("support-bot")
    assert profile.agent_id == "support-bot"
    assert profile.owner == "team-cs"
    assert "chat" in profile.capabilities
    assert profile.created_by == "kevin@company.com"


def test_get_unknown_agent_raises():
    reg = Registry()
    with pytest.raises(KeyError, match="not-registered"):
        reg.get("not-registered")


def test_list_agents():
    reg = Registry()
    reg.register("bot-a", "team-a", created_by="a@x.com")
    reg.register("bot-b", "team-b", created_by="b@x.com")
    profiles = reg.list()
    ids = {p.agent_id for p in profiles}
    assert ids == {"bot-a", "bot-b"}


def test_duplicate_register_raises():
    reg = Registry()
    reg.register("bot-a", "team-a", created_by="a@x.com")
    with pytest.raises(ValueError, match="already registered"):
        reg.register("bot-a", "team-b", created_by="b@x.com")


def test_overwrite_flag():
    reg = Registry()
    reg.register("bot-a", "team-a", created_by="a@x.com")
    reg.register("bot-a", "team-z", created_by="z@x.com", overwrite=True)
    profile = reg.get("bot-a")
    assert profile.owner == "team-z"


def test_deregister():
    reg = Registry()
    reg.register("bot-a", "team-a", created_by="a@x.com")
    reg.deregister("bot-a")
    with pytest.raises(KeyError):
        reg.get("bot-a")


def test_deregister_unknown_raises():
    reg = Registry()
    with pytest.raises(KeyError):
        reg.deregister("ghost")


def test_disable():
    reg = Registry()
    reg.register("bot-a", "team-a", created_by="a@x.com")
    reg.disable("bot-a")
    profile = reg.get("bot-a")
    assert profile.disabled is True


def test_audit_log_contains_registration():
    reg = Registry()
    reg.register("bot-a", "team-a", created_by="a@x.com")
    logs = reg.audit_log("bot-a")
    actions = [e["action"] for e in logs]
    assert "agent_registered" in actions
