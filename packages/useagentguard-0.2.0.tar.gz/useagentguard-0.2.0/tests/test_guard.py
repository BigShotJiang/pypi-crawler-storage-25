"""Tests for agentguard.guard — the main guard() wrapper."""

from unittest.mock import MagicMock, patch
import pytest

from agentguard.guard import guard, BudgetExceeded, GuardedClient
from agentguard.scopes import ScopeViolation


# ---------------------------------------------------------------------------
# Helpers to build a mock OpenAI-like client
# ---------------------------------------------------------------------------

def _make_mock_usage(prompt_tokens=100, completion_tokens=50):
    usage = MagicMock()
    usage.prompt_tokens = prompt_tokens
    usage.completion_tokens = completion_tokens
    usage.total_tokens = prompt_tokens + completion_tokens
    return usage


def _make_mock_client(model="gpt-4o-mini", tokens=(100, 50)):
    mock_response = MagicMock()
    mock_response.usage = _make_mock_usage(*tokens)
    mock_response.choices = [MagicMock()]

    completions = MagicMock()
    completions.create.return_value = mock_response

    chat = MagicMock()
    chat.completions = completions

    client = MagicMock()
    client.chat = chat
    return client, mock_response


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_guard_returns_guarded_client():
    client, _ = _make_mock_client()
    gc = guard(client)
    assert isinstance(gc, GuardedClient)


def test_guard_passthrough_to_chat_completions():
    client, mock_response = _make_mock_client()
    gc = guard(client)
    result = gc.chat.completions.create(model="gpt-4o-mini", messages=[])
    assert result is mock_response


def test_budget_exceeded_raises_by_default():
    client, _ = _make_mock_client(tokens=(10000, 5000))  # expensive call
    gc = guard(client, budget="$0.001/run", agent_id="test-bot")
    # First call should succeed (starts at $0)
    gc.chat.completions.create(model="gpt-4o-mini", messages=[])
    # Second call should exceed budget
    with pytest.raises(BudgetExceeded):
        gc.chat.completions.create(model="gpt-4o-mini", messages=[])


def test_budget_graceful_stop():
    client, _ = _make_mock_client(tokens=(10000, 5000))
    gc = guard(client, budget="$0.001/run", on_limit="graceful_stop", agent_id="test-bot")
    gc.chat.completions.create(model="gpt-4o-mini", messages=[])
    result = gc.chat.completions.create(model="gpt-4o-mini", messages=[])
    assert result.budget_exceeded is True
    assert bool(result) is False


def test_scope_enforcement_blocks_bad_scope():
    client, _ = _make_mock_client()
    gc = guard(
        client,
        agent_id="test-bot",
        scopes={"openai": ["chat.completions"]},
    )
    # Manually override the scope policy to trigger a violation
    from agentguard.scopes import ScopeManager
    sm = ScopeManager()
    # The guard already set allowed scopes; now try checking an extra scope
    with pytest.raises(ScopeViolation):
        sm.check("test-bot", "openai", "fine-tuning")


def test_shield_vault_attached_when_isolated():
    client, _ = _make_mock_client()
    gc = guard(client, auth="isolated", agent_id="test-bot")
    assert gc.vault is not None
    assert gc.vault.agent_id == "test-bot"


def test_no_vault_without_isolated():
    client, _ = _make_mock_client()
    gc = guard(client, agent_id="test-bot")
    assert gc.vault is None


def test_spent_tracks_cost():
    client, _ = _make_mock_client(tokens=(1000, 500))
    gc = guard(client, agent_id="test-bot")
    assert gc.spent == 0.0
    gc.chat.completions.create(model="gpt-4o-mini", messages=[])
    assert gc.spent > 0.0


def test_invalid_budget_raises():
    client, _ = _make_mock_client()
    with pytest.raises(ValueError, match="Invalid budget"):
        guard(client, budget="bad-format")


def test_guard_passthrough_attribute():
    client, _ = _make_mock_client()
    client.some_attr = "hello"
    gc = guard(client)
    assert gc.some_attr == "hello"


def test_full_shield_integration():
    """End-to-end: vault + scopes + guard()."""
    client, mock_response = _make_mock_client()
    gc = guard(
        client,
        budget="$1.00/run",
        auth="isolated",
        agent_id="integration-bot",
        scopes={"openai": ["chat.completions"]},
        fallback="gpt-4o-mini",
        on_limit="graceful_stop",
    )
    # Store a credential in the vault
    gc.vault.store("openai", "sk-test-integration-key", scopes=["chat.completions"])
    cred = gc.vault.get("openai")
    assert cred.scopes == ["chat.completions"]

    # Make a call
    result = gc.chat.completions.create(model="gpt-4o-mini", messages=[{"role": "user", "content": "hi"}])
    assert result is mock_response
