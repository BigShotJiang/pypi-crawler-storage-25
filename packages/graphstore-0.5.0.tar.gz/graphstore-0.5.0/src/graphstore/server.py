"""FastAPI server for the graphstore playground."""

from __future__ import annotations

import os
import time as _time
from collections import defaultdict
from pathlib import Path
from typing import Any

try:
    from fastapi import FastAPI, Request
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import JSONResponse, Response
    from fastapi.staticfiles import StaticFiles
    from pydantic import BaseModel
except ImportError as e:
    raise ImportError(
        "graphstore.server requires the `playground` extra. "
        "Install with: pip install 'graphstore[playground]'"
    ) from e

from graphstore import GraphStore
from graphstore.core.errors import GraphStoreError
from graphstore.core.types import encode_json

app = FastAPI(title="graphstore playground")

_CORS_ORIGINS = os.environ.get("GRAPHSTORE_CORS_ORIGINS", "*").split(",")

app.add_middleware(
    CORSMiddleware,
    allow_origins=_CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Auth + Rate Limiting Middleware ---

_AUTH_TOKEN = os.environ.get("GRAPHSTORE_AUTH_TOKEN")
_RATE_LIMIT_RPM = int(os.environ.get("GRAPHSTORE_RATE_LIMIT_RPM", "120"))

_rate_buckets: dict[str, list[float]] = defaultdict(list)
_rate_cleanup_counter = 0


def _check_rate_limit(client_ip: str) -> bool:
    """Returns True if request is allowed."""
    global _rate_cleanup_counter
    now = _time.time()
    window = float(_RATE_LIMIT_WINDOW)
    bucket = _rate_buckets[client_ip]
    _rate_buckets[client_ip] = [t for t in bucket if now - t < window]
    if len(_rate_buckets[client_ip]) >= _RATE_LIMIT_RPM:
        return False
    _rate_buckets[client_ip].append(now)

    _rate_cleanup_counter += 1
    if _rate_cleanup_counter % 100 == 0:
        stale = [ip for ip, ts in _rate_buckets.items() if not ts or now - max(ts) > float(_RATE_LIMIT_WINDOW)]
        for ip in stale:
            del _rate_buckets[ip]

    return True


@app.middleware("http")
async def auth_and_rate_limit(request: Request, call_next):
    if not request.url.path.startswith("/api/"):
        return await call_next(request)

    if _AUTH_TOKEN is not None:
        auth_header = request.headers.get("Authorization", "")
        if not auth_header.startswith("Bearer ") or auth_header[7:] != _AUTH_TOKEN:
            return JSONResponse(status_code=401, content={"error": "Unauthorized"})

    client_ip = request.client.host if request.client else "unknown"
    if not _check_rate_limit(client_ip):
        return JSONResponse(
            status_code=429,
            content={"error": "Rate limit exceeded"},
            headers={"Retry-After": str(_RATE_LIMIT_WINDOW)},
        )

    return await call_next(request)


# ---------------------------------------------------------------------------
# Module-level store (created lazily)
# ---------------------------------------------------------------------------

_store: GraphStore | None = None


def _get_store() -> GraphStore:
    global _store
    if _store is None:
        db_path = os.environ.get("GRAPHSTORE_DB_PATH")
        config_path = os.environ.get("GRAPHSTORE_CONFIG")
        ingest_root = os.environ.get("GRAPHSTORE_INGEST_ROOT", os.getcwd())
        kwargs: dict = {}
        if db_path:
            kwargs["path"] = db_path
        if config_path:
            kwargs["config_path"] = config_path
        if ingest_root:
            kwargs["ingest_root"] = ingest_root
        _store = GraphStore(**kwargs)
    return _store


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _result_payload(result) -> dict[str, Any]:
    return {
        "kind": result.kind,
        "data": result.data,
        "count": result.count,
        "elapsed_us": result.elapsed_us,
    }


def _json_bytes_response(payload: Any) -> Response:
    return Response(content=encode_json(payload), media_type="application/json")


# ---------------------------------------------------------------------------
# Request / response models
# ---------------------------------------------------------------------------


class ExecuteRequest(BaseModel):
    query: str


class BatchRequest(BaseModel):
    queries: list[str]


class ConfigRequest(BaseModel):
    ceiling_mb: int | None = None
    cost_threshold: int | None = None
    eviction_target_ratio: float | None = None


# ---------------------------------------------------------------------------
# Input validation
# ---------------------------------------------------------------------------

_MAX_QUERY_LENGTH = int(os.environ.get("GRAPHSTORE_MAX_QUERY_LENGTH", "10000"))
_MAX_BATCH_SIZE = int(os.environ.get("GRAPHSTORE_MAX_BATCH_SIZE", "1000"))
_RATE_LIMIT_WINDOW = int(os.environ.get("GRAPHSTORE_RATE_LIMIT_WINDOW", "60"))


def _validate_query(query: str) -> str | None:
    """Validate query input. Returns error message or None if valid."""
    if not query or not query.strip():
        return "Empty query"
    if len(query) > _MAX_QUERY_LENGTH:
        return f"Query exceeds maximum length ({_MAX_QUERY_LENGTH} chars)"
    if "\x00" in query:
        return "Query contains null bytes"
    return None


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@app.post("/api/execute")
def execute(req: ExecuteRequest):
    err = _validate_query(req.query)
    if err:
        return _json_bytes_response({"kind": "error", "data": err, "count": 0, "elapsed_us": 0})
    store = _get_store()
    try:
        result = store.execute(req.query)
    except Exception as exc:
        # Catch all exceptions (including ValueError, KeyError, etc.) and
        # return them as soft 200 errors. Pre-fix only GraphStoreError was
        # caught, so a programmer bug anywhere in the executor surfaced as
        # an HTTP 500 with a stack trace leaked to the client, and in
        # batch mode caused the whole batch to abort (bug #80). Logging
        # here gives us the observability we used to get from the 500.
        import logging
        logging.getLogger(__name__).warning(
            "execute: %s: %s", type(exc).__name__, exc,
        )
        return _json_bytes_response({
            "kind": "error",
            "data": f"{type(exc).__name__}: {exc}",
            "count": 0,
            "elapsed_us": 0,
        })
    return _json_bytes_response(_result_payload(result))


@app.post("/api/execute-batch")
def execute_batch(req: BatchRequest):
    if len(req.queries) > _MAX_BATCH_SIZE:
        return _json_bytes_response([{"kind": "error", "data": f"Batch exceeds {_MAX_BATCH_SIZE} queries", "count": 0, "elapsed_us": 0}])
    store = _get_store()
    results = []
    import logging as _logging
    for q in req.queries:
        err = _validate_query(q)
        if err:
            results.append({"kind": "error", "data": err, "count": 0, "elapsed_us": 0})
            continue
        try:
            r = store.execute(q)
            results.append(_result_payload(r))
        except Exception as exc:
            # Same widening as /api/execute — a single unexpected error
            # shouldn't abort the remaining queries in the batch.
            _logging.getLogger(__name__).warning(
                "execute-batch: %s: %s", type(exc).__name__, exc,
            )
            results.append({
                "kind": "error",
                "data": f"{type(exc).__name__}: {exc}",
                "count": 0,
                "elapsed_us": 0,
            })
    return _json_bytes_response(results)


@app.get("/api/graph")
def get_graph():
    store = _get_store()
    nodes = store.get_all_nodes()
    edges = store.get_all_edges()
    return _json_bytes_response({"nodes": nodes, "edges": edges})


@app.post("/api/reset")
def reset():
    """Reset the in-memory graph. For persistent DBs, wipes memory and WAL
    but preserves the script metadata so Run All can repopulate cleanly."""
    store = _get_store()
    store.reset_store(preserve_config=True)
    return {"ok": True}


@app.get("/api/script")
def get_script():
    store = _get_store()
    script = store.get_script()
    return {"script": script}


@app.put("/api/script")
def put_script(req: ExecuteRequest):
    store = _get_store()
    store.set_script(req.query)
    return {"ok": True}


@app.post("/api/config")
def config(req: ConfigRequest):
    store = _get_store()
    changes = {}
    if req.ceiling_mb is not None:
        changes["ceiling_mb"] = req.ceiling_mb
    if req.cost_threshold is not None:
        changes["cost_threshold"] = req.cost_threshold
    if req.eviction_target_ratio is not None:
        changes["eviction_target_ratio"] = req.eviction_target_ratio
    
    if changes:
        store.update_runtime_config(changes)
        
    return {"ok": True}


@app.get("/api/logs")
def get_logs(
    limit: int = 50,
    tag: str | None = None,
    source: str | None = None,
    trace_id: str | None = None,
    since: str | None = None,
):
    """Query the enriched query log."""
    store = _get_store()
    conn = store._conn
    if conn is None:
        return []

    sql = "SELECT id, timestamp, query, elapsed_us, result_count, error, tag, trace_id, source, phase FROM query_log"
    params: list = []
    conditions = []

    if tag:
        conditions.append("tag = ?")
        params.append(tag)
    if source:
        conditions.append("source LIKE ?")
        params.append(f"%{source}%")
    if trace_id:
        conditions.append("trace_id = ?")
        params.append(trace_id)
    if since:
        import datetime
        dt = datetime.datetime.fromisoformat(since)
        conditions.append("timestamp >= ?")
        params.append(dt.timestamp())

    if conditions:
        sql += " WHERE " + " AND ".join(conditions)

    sql += " ORDER BY timestamp DESC LIMIT ?"
    params.append(limit)

    rows = conn.execute(sql, params).fetchall()
    return [
        {
            "id": r[0], "timestamp": r[1], "query": r[2],
            "elapsed_us": r[3], "result_count": r[4], "error": r[5],
            "tag": r[6], "trace_id": r[7], "source": r[8], "phase": r[9],
        }
        for r in rows
    ]


# ---------------------------------------------------------------------------
# Static files helper
# ---------------------------------------------------------------------------


def mount_static(application: FastAPI, path: str | Path) -> None:
    """Mount a StaticFiles directory on / if it exists."""
    p = Path(path)
    if p.is_dir():
        application.mount(
            "/",
            StaticFiles(directory=str(p), html=True),
            name="playground",
        )
