from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required, user_passes_test
from .forms import RegistrationForm, LoginForm, ApplicationForm
from .models import Application


def index(request):
    return render(request, "main/index.html")


def register_view(request):
    if request.method == "POST":
        form = RegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("login")
    else:
        form = RegistrationForm()
    return render(request, "main/register.html", {"form": form})


def login_view(request):
    if request.method == "POST":
        form = LoginForm(request.POST)
        if form.is_valid():
            user = authenticate(request, username=form.cleaned_data["username"], password=form.cleaned_data["password"])
            if user:
                login(request, user)
                return redirect("applications")
            else:
                form.add_error(None, "Неверный логин или пароль")
    else:
        form = LoginForm()
    return render(request, "main/login.html", {"form": form})


def logout_view(request):
    logout(request)
    return redirect("index")


@login_required
def applications_view(request):
    apps = request.user.applications.all()
    return render(request, "main/applications.html", {"applications": apps})


@login_required
def create_application(request):
    if request.method == "POST":
        form = ApplicationForm(request.POST)
        if form.is_valid():
            app = form.save(commit=False)
            app.user = request.user
            app.save()
            return redirect("applications")
    else:
        form = ApplicationForm()
    return render(request, "main/create_application.html", {"form": form})


def is_admin(user):
    return user.is_superuser or (user.username == "Admin")


@user_passes_test(is_admin)
def admin_panel(request):
    apps = Application.objects.all().order_by("-created_at")
    if request.method == "POST":
        app_id = request.POST.get("app_id")
        status = request.POST.get("status")
        app = get_object_or_404(Application, id=app_id)
        app.status = status
        app.save()
    return render(request, "main/admin_panel.html", {"applications": apps})


def admin_login(request):
    error = None
    if request.method == "POST":
        login_input = request.POST.get("username")
        password_input = request.POST.get("password")
        if login_input == "Admin" and password_input == "KorokNET":
            from django.contrib.auth.models import User

            user, created = User.objects.get_or_create(username="Admin", defaults={"is_staff": True, "is_superuser": True})
            if created:
                user.set_password("KorokNET")
                user.save()
            user = authenticate(request, username="Admin", password="KorokNET")
            if user:
                login(request, user)
                return redirect("admin_panel")
        error = "Неверный логин или пароль администратора"
    return render(request, "main/admin_login.html", {"error": error})


def admin_logout(request):
    logout(request)
    return redirect("index")
