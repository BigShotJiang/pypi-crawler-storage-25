from django.contrib import admin
from .models import Profile, Application


@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ("user", "full_name", "phone")


@admin.register(Application)
class ApplicationAdmin(admin.ModelAdmin):
    list_display = ("user", "course_name", "start_date", "payment_method", "status", "created_at")
    list_filter = ("status", "payment_method")
