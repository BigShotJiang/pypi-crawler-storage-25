from django.urls import path
from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("register/", views.register_view, name="register"),
    path("login/", views.login_view, name="login"),
    path("logout/", views.logout_view, name="logout"),
    path("applications/", views.applications_view, name="applications"),
    path("application/new/", views.create_application, name="create_application"),
    path("admin-login/", views.admin_login, name="admin_login"),
    path("admin-panel/", views.admin_panel, name="admin_panel"),
    path("admin-logout/", views.admin_logout, name="admin_logout"),
]
