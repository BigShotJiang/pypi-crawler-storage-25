from django.db import models
from django.contrib.auth.models import User


class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    full_name = models.CharField(max_length=200)
    phone = models.CharField(max_length=20)

    def __str__(self):
        return f"{self.user.username} - {self.full_name}"


class Application(models.Model):
    PAYMENT_CHOICES = [
        ("cash", "Наличными"),
        ("phone", "Перевод по номеру телефона"),
    ]

    STATUS_NEW = "NEW"
    STATUS_IN_PROGRESS = "IN_PROGRESS"
    STATUS_COMPLETED = "COMPLETED"

    STATUS_CHOICES = [
        (STATUS_NEW, "Новая"),
        (STATUS_IN_PROGRESS, "Идет обучение"),
        (STATUS_COMPLETED, "Обучение завершено"),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="applications")
    course_name = models.CharField(max_length=200)
    start_date = models.DateField()
    payment_method = models.CharField(max_length=20, choices=PAYMENT_CHOICES)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_NEW)
    review = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.course_name} ({self.user.username}) - {self.status}"
