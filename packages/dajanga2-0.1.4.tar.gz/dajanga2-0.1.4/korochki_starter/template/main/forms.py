from django import forms
from django.contrib.auth.models import User
from .models import Application
import re


class RegistrationForm(forms.Form):
    username = forms.CharField(label="Логин", max_length=150)
    password1 = forms.CharField(label="Пароль", widget=forms.PasswordInput)
    password2 = forms.CharField(label="Повтор пароля", widget=forms.PasswordInput)
    full_name = forms.CharField(label="ФИО", max_length=200)
    phone = forms.CharField(label="Телефон", max_length=20)
    email = forms.EmailField(label="Email")

    def clean_username(self):
        username = self.cleaned_data["username"]
        if not re.match(r"^[A-Za-z0-9]{6,}$", username):
            raise forms.ValidationError("Логин должен содержать латиницу и цифры, не менее 6 символов")
        if User.objects.filter(username=username).exists():
            raise forms.ValidationError("Пользователь с таким логином уже существует")
        return username

    def clean_password1(self):
        p = self.cleaned_data["password1"]
        if len(p) < 8:
            raise forms.ValidationError("Пароль минимум 8 символов")
        return p

    def clean(self):
        cleaned = super().clean()
        p1 = cleaned.get("password1")
        p2 = cleaned.get("password2")
        if p1 and p2 and p1 != p2:
            raise forms.ValidationError("Пароли не совпадают")
        full = cleaned.get("full_name")
        if full and not re.match(r"^[А-Яа-яЁё\s]+$", full):
            self.add_error("full_name", "ФИО должно содержать только кириллицу и пробелы")
        phone = cleaned.get("phone")
        if phone and not re.match(r"^8\(\d{3}\)\d{3}-\d{2}-\d{2}$", phone):
            self.add_error("phone", "Телефон в формате 8(XXX)XXX-XX-XX")

    def save(self):
        data = self.cleaned_data
        user = User.objects.create_user(username=data["username"], email=data["email"])
        user.set_password(data["password1"])
        user.save()
        # create profile
        from .models import Profile

        Profile.objects.create(user=user, full_name=data["full_name"], phone=data["phone"])
        return user


class LoginForm(forms.Form):
    username = forms.CharField(label="Логин")
    password = forms.CharField(label="Пароль", widget=forms.PasswordInput)


class ApplicationForm(forms.ModelForm):
    class Meta:
        model = Application
        fields = ["course_name", "start_date", "payment_method"]
        widgets = {
            "start_date": forms.DateInput(attrs={"type": "date"}),
        }
