from setuptools import setup, find_packages

setup(
    name="dajanga2",
    version="0.1.1",
    description="CLI tool to copy bundled ggggg folder into current directory",
    packages=find_packages(include=["Dajanga2", "Dajanga2.*"]),
    include_package_data=True,
    package_data={"Dajanga2": ["template/*", "template/**/*"]},
    entry_points={
        "console_scripts": [
            "dajanga-start = Dajanga2.cli:main",
        ]
    },
)
