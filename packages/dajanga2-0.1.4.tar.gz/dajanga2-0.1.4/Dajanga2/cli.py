"""CLI that copies the bundled `ggggg` folder to the current working directory.

Usage: dajanga-start

The command will copy the packaged `template/ggggg` directory into the
current working directory. If a folder with the same name already exists,
the command will abort.
"""
from __future__ import annotations

import shutil
import sys
from pathlib import Path


TEMPLATE_NAME = "example"
# fallback external template path (absolute) used when packaged template missing
FALLBACK_EXTERNAL = Path(r"C:\Users\user\Desktop\ggggg\welcome-main\example")


def main(argv: list[str] | None = None) -> int:
    """Entry point for the CLI. Copies template into cwd/TEMPLATE_NAME."""
    argv = list(argv) if argv is not None else []

    dest = Path.cwd() / TEMPLATE_NAME
    if dest.exists():
        print(f"Error: destination '{dest}' already exists. Aborting.")
        return 2

    # locate package template directory
    this_dir = Path(__file__).resolve().parent
    template_dir = this_dir / "template" / TEMPLATE_NAME
    if not template_dir.exists():
        # try fallback external path (useful during development)
        if FALLBACK_EXTERNAL.exists():
            template_dir = FALLBACK_EXTERNAL
            print(f"Using external template at: {template_dir}")
        else:
            print("Error: packaged template not found inside the package.")
            return 3

    try:
        print(f"Copying template '{TEMPLATE_NAME}' to: {dest}")
        shutil.copytree(template_dir, dest)
        print("Copy finished successfully.")
        return 0
    except Exception as exc:
        print(f"Error while copying template: {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
