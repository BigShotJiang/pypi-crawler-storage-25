import os
import shutil
import sys
from pathlib import Path

# By default use the `example` directory that contains this package.
# This avoids hardcoding user-specific paths and ensures the package copies
# the example folder located next to the `dajanga2` package.
DEFAULT_EXAMPLE = Path(__file__).resolve().parent.parent


def copy_merge(src: Path, dst: Path, overwrite: bool = True):
    src = Path(src)
    dst = Path(dst)
    if not src.exists():
        raise FileNotFoundError(f"Source not found: {src}")
    # Exclude common build/venv/package metadata directories and files
    exclude_dir_names = {"venv", "ENV", "env", "build", "dist", ".git", ".eggs"}
    exclude_dir_suffixes = (".dist-info", ".egg-info", ".egg-link")
    exclude_file_suffixes = (".whl", ".tar.gz", ".zip", ".pyc", ".pyo")

    for root, dirs, files in os.walk(src):
        # filter out directories we don't want to traverse or copy
        dirs[:] = [d for d in dirs if not (
            d in exclude_dir_names or
            d.endswith(exclude_dir_suffixes) or
            d.startswith('.')
        )]

        rel = Path(root).relative_to(src)
        target_dir = dst.joinpath(rel)
        target_dir.mkdir(parents=True, exist_ok=True)

        for f in files:
            # skip unwanted files
            if f.startswith('.') or f.endswith(exclude_file_suffixes):
                continue
            sfile = Path(root) / f
            tfile = target_dir / f
            if tfile.exists() and overwrite:
                if tfile.is_dir():
                    shutil.rmtree(tfile)
                else:
                    tfile.unlink()
            shutil.copy2(sfile, tfile)


def main(argv=None):
    argv = argv or sys.argv[1:]
    # Allow override via envvar or CLI arg
    src = os.environ.get("DAJANGA_EXAMPLE_PATH", DEFAULT_EXAMPLE)
    if len(argv) >= 1:
        src = argv[0]

    src_path = Path(src).resolve()
    dst_path = Path(os.getcwd()).resolve()

    # Create a subdirectory in the destination with the same name as the
    # source folder (e.g. 'example') and copy the entire source folder into it.
    dst_root = dst_path.joinpath(src_path.name)
    print(f"Source: {src_path}")
    print(f"Destination (root): {dst_root}")

    try:
        dst_root.mkdir(parents=True, exist_ok=True)
        copy_merge(src_path, dst_root, overwrite=True)
    except Exception as e:
        print(f"Error copying example site: {e}", file=sys.stderr)
        return 2

    print(f"Example folder '{src_path.name}' copied successfully to {dst_root}.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
