"""dajanga2 package - lightweight CLI to scaffold a site from an example folder."""

__version__ = "0.1.2"
