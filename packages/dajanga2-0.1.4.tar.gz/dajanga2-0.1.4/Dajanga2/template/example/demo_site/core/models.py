from django.db import models
from django.contrib.auth.models import AbstractUser


class User(AbstractUser):
    tel = models.CharField(max_length=12)
    fio = models.CharField(max_length=255)


class PaymentType(models.Model):
    caption = models.CharField(max_length=32, unique=True)


class BidStatus(models.Model):
    caption = models.CharField(max_length=255, unique=True)


class Bid(models.Model):
    user = models.ForeignKey(User, null=True, on_delete=models.SET_NULL)
    course_name = models.CharField(max_length=255)
    start_date = models.DateField()
    payment_type = models.ForeignKey(PaymentType, null=True, on_delete=models.SET_NULL)
    status = models.ForeignKey(BidStatus, null=True, on_delete=models.SET_NULL)
