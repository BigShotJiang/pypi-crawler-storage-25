from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('bids/', views.bids_view, name='bids'),
]
