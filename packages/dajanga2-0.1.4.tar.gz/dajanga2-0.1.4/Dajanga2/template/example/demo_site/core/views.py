from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages

from .models import User, Bid, PaymentType, BidStatus


def index(request):
    return HttpResponse(render(request, "index.html"))


def registration(request):
    if request.method == "POST":
        form_data = request.POST

        login = form_data.get("login")
        if login is None:
            messages.error(request, "Не указан логин")
            return redirect("registration")

        password = form_data.get("password")
        if password is None:
            messages.error(request, "Не указан пароль")
            return redirect("registration")

        fullname = form_data.get("fullname")
        if fullname is None:
            messages.error(request, "Не указано ФИО")
            return redirect("registration")

        email = form_data.get("email")
        if email is None:
            messages.error(request, "Не указан email")
            return redirect("registration")

        phone = form_data.get("phone")
        if phone is None:
            messages.error(request, "Не указан телефон")
            return redirect("registration")

        new_user = User(username=login, email=email, fio=fullname, tel=phone)
        new_user.set_password(password)
        new_user.save()

        return redirect("index")

    return HttpResponse(render(request, "registration.html"))


def login_view(request):
    if request.method == "POST":
        form_data = request.POST

        user_login = form_data.get("login")
        if user_login is None:
            messages.error(request, "Не указан логин")
            return redirect("login")

        password = form_data.get("password")
        if password is None:
            messages.error(request, "Не указан пароль")
            return redirect("login")

        user = authenticate(username=user_login, password=password)
        if user is None:
            messages.error(request, "Пользователь не найден")
            return redirect("login")

        login(request, user)
        return redirect("bids")

    return HttpResponse(render(request, "login.html"))


def logout_view(request):
    logout(request)
    return redirect("index")


@login_required
def bids(request):
    bids = []

    current_user = User.objects.filter(id=request.user.pk).first()
    if current_user is not None:
        bids = (
            Bid.objects.select_related("user", "payment_type")
            .filter(user=current_user)
            .all()
        )

    return HttpResponse(render(request, "bids.html", {"bids": bids}))


@login_required
def make_bid(request):
    if request.method == "POST":
        form = request.POST

        name = form.get("name")
        if name is None:
            messages.error(request, "Не указано название курса")
            return redirect("make_bid")

        start_date = form.get("start_date")
        if start_date is None:
            messages.error(request, "Не указана дата начала обучения")
            return redirect("make_bid")

        payment_type_id = form.get("payment_type")
        if payment_type_id is None:
            messages.error(request, "Не найден способ оплаты")
            return redirect("make_bid")

        payment_type = PaymentType.objects.filter(id=payment_type_id).first()
        if payment_type is None:
            messages.error(request, "Не найден способ оплаты")
            return redirect("make_bid")

        user = User.objects.filter(id=request.user.pk).first()
        if user is None:
            messages.error(request, "Ошибка создания заявки. Не найден пользователь")
            return redirect("make_bid")

        # Убедимся, что статус "Создана" существует — создаём при необходимости
        status_created, _ = BidStatus.objects.get_or_create(caption="Создана")

        bid = Bid(
            user=user,
            course_name=name,
            start_date=start_date,
            payment_type=payment_type,
            status=status_created,
        )
        bid.save()

        messages.success(request, "Заявка успешно создана")
        return redirect("make_bid")

    payment_types = PaymentType.objects.all().values()
    return HttpResponse(
        render(request, "make_bid.html", {"payment_types": payment_types})
    )
