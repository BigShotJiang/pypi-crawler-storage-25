from django.contrib import admin

from .models import User, Bid, PaymentType, BidStatus

# Register your models here.
admin.site.register(User)
admin.site.register(Bid)
admin.site.register(PaymentType)
admin.site.register(BidStatus)
