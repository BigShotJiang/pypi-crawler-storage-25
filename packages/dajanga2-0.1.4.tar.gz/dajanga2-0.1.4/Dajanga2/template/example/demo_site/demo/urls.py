"""
URL configuration for demo project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.contrib import admin
from django.urls import path
import core.views as core

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", core.index, name="index"),
    path("login/", core.login_view, name="login"),
    path("logout/", core.logout_view, name="logout"),
    path("registration/", core.registration, name="registration"),
    path("bids/", core.bids, name="bids"),
    path("make_bid/", core.make_bid, name="make_bid"),
]
