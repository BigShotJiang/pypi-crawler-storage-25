"""Dajanga2 package - simple copier of bundled `ggggg` template."""
__version__ = "0.1.4"
