korochki-starter
=================

Утилита CLI для разворачивания шаблона Django-проекта из пакета.

Сборка и установка локально:

```powershell
python -m build
pip install dist\korochki_starter-0.1.0-py3-none-any.whl
```

После установки доступна команда:

```powershell
korochki-start myproject
```

Это создаст папку `myproject/` с шаблоном и выполнит замену всех вхождений `korochki` на `myproject`.
