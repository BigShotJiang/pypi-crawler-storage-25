"""Control management operations for Agent Control SDK."""

from typing import Any, Literal, cast

from agent_control_models import (
    ControlDefinition,
    TemplateControlInput,
    TemplateDefinition,
    TemplateValue,
    UnrenderedTemplateControl,
)

from .client import AgentControlClient


async def list_controls(
    client: AgentControlClient,
    cursor: int | None = None,
    limit: int = 20,
    name: str | None = None,
    enabled: bool | None = None,
    template_backed: bool | None = None,
    step_type: str | None = None,
    stage: Literal["pre", "post"] | None = None,
    execution: Literal["server", "sdk"] | None = None,
    tag: str | None = None,
) -> dict[str, Any]:
    """
    List all controls with optional filtering and pagination.

    Controls are returned ordered by ID descending (newest first).

    Args:
        client: AgentControlClient instance
        cursor: Control ID to start after (for pagination)
        limit: Maximum number of controls to return (default 20, max 100)
        name: Optional filter by name (partial, case-insensitive match)
        enabled: Optional filter by enabled status
        template_backed: Optional filter by whether the control is template-backed
        step_type: Optional filter by step type (built-ins: 'tool', 'llm')
        stage: Optional filter by stage ('pre' or 'post')
        execution: Optional filter by execution ('server' or 'sdk')
        tag: Optional filter by tag

    Returns:
        Dictionary containing:
            - controls: List of control summaries with id, name, description,
                       enabled, execution, step_types, stages, tags
            - pagination: Object with limit, total, next_cursor, has_more

    Raises:
        httpx.HTTPError: If request fails

    Example:
        async with AgentControlClient() as client:
            # List all controls
            result = await list_controls(client)
            print(f"Total: {result['pagination']['total']}")

            # Filter by type
            llm_controls = await list_controls(client, step_type="llm")

            # Paginate
            page1 = await list_controls(client, limit=10)
            if page1['pagination']['has_more']:
                page2 = await list_controls(
                    client,
                    cursor=int(page1['pagination']['next_cursor']),
                    limit=10
                )
    """
    params: dict[str, Any] = {"limit": limit}
    if cursor is not None:
        params["cursor"] = cursor
    if name is not None:
        params["name"] = name
    if enabled is not None:
        params["enabled"] = enabled
    if template_backed is not None:
        params["template_backed"] = template_backed
    if step_type is not None:
        params["step_type"] = step_type
    if stage is not None:
        params["stage"] = stage
    if execution is not None:
        params["execution"] = execution
    if tag is not None:
        params["tag"] = tag

    response = await client.http_client.get("/api/v1/controls", params=params)
    response.raise_for_status()
    return cast(dict[str, Any], response.json())


async def get_control(
    client: AgentControlClient,
    control_id: int,
) -> dict[str, Any]:
    """
    Get a control by ID.

    Args:
        client: AgentControlClient instance
        control_id: ID of the control

    Returns:
        Dictionary containing:
            - id: Control ID
            - name: Control name
            - data: Control definition or unrendered template control data

    Raises:
        httpx.HTTPError: If request fails
        HTTPException 404: Control not found

    Example:
        async with AgentControlClient() as client:
            control = await get_control(client, control_id=5)
            print(f"Control: {control['name']}")
            print(f"Enabled: {control['data']['enabled']}")
    """
    response = await client.http_client.get(f"/api/v1/controls/{control_id}")
    response.raise_for_status()
    return cast(dict[str, Any], response.json())


async def list_control_versions(
    client: AgentControlClient,
    control_id: int,
    cursor: int | None = None,
    limit: int = 20,
) -> dict[str, Any]:
    """
    List version-history summaries for a control.

    Args:
        client: AgentControlClient instance
        control_id: ID of the control
        cursor: Version number to start after (newest-first pagination)
        limit: Maximum number of versions to return

    Returns:
        Dictionary containing:
            - versions: List of version summaries
            - pagination: Object with limit, total, next_cursor, has_more
    """
    params: dict[str, Any] = {"limit": limit}
    if cursor is not None:
        params["cursor"] = cursor

    response = await client.http_client.get(
        f"/api/v1/controls/{control_id}/versions",
        params=params,
    )
    response.raise_for_status()
    return cast(dict[str, Any], response.json())


async def get_control_version(
    client: AgentControlClient,
    control_id: int,
    version_num: int,
) -> dict[str, Any]:
    """
    Get a specific version snapshot for a control.

    Args:
        client: AgentControlClient instance
        control_id: ID of the control
        version_num: Control version number to fetch

    Returns:
        Dictionary containing version metadata and the raw snapshot payload.
    """
    response = await client.http_client.get(
        f"/api/v1/controls/{control_id}/versions/{version_num}"
    )
    response.raise_for_status()
    return cast(dict[str, Any], response.json())


async def create_control(
    client: AgentControlClient,
    name: str,
    data: dict[str, Any] | ControlDefinition | TemplateControlInput,
) -> dict[str, Any]:
    """
    Create a new control with a unique name and configuration.

    Control names are canonicalized by the API (leading/trailing whitespace
    is trimmed); callers may pass trimmed names for consistency.

    Args:
        client: AgentControlClient instance
        name: Unique name for the control
        data: Raw control definition or template-backed control input

    Returns:
        Dictionary containing:
            - control_id: ID of the created control
            - configured: Always True because create requires data

    Raises:
        httpx.HTTPError: If request fails
        HTTPException 409: Control with this name already exists
        HTTPException 422: If data doesn't match schema
        HTTPException 500: Database error during creation

    Example:
        async with AgentControlClient() as client:
            result = await create_control(
                client,
                name="ssn-blocker",
                data={
                    "execution": "server",
                    "scope": {"step_types": ["llm"], "stages": ["post"]},
                    "condition": {
                        "selector": {"path": "output"},
                        "evaluator": {
                            "name": "regex",
                            "config": {"pattern": r"\\d{3}-\\d{2}-\\d{4}"}
                        }
                    },
                    "action": {"decision": "deny"}
                }
            )
            print(f"Created and configured control: {result['control_id']}")
    """
    payload: dict[str, Any] = {"name": name}
    if isinstance(data, (ControlDefinition, TemplateControlInput)):
        payload["data"] = data.model_dump(mode="json", exclude_none=True)
    else:
        payload["data"] = cast(dict[str, Any], data)

    response = await client.http_client.put(
        "/api/v1/controls",
        json=payload,
    )
    response.raise_for_status()
    result = cast(dict[str, Any], response.json())

    result["configured"] = True
    return result


async def set_control_data(
    client: AgentControlClient,
    control_id: int,
    data: dict[str, Any] | ControlDefinition | TemplateControlInput
) -> dict[str, Any]:
    """
    Set the configuration data for a control.

    This defines what the control actually does (condition tree, action, scope).

    Args:
        client: AgentControlClient instance
        control_id: ID of the control
        data: Raw control definition or template-backed control input

    Returns:
        Dictionary containing success flag

    Raises:
        httpx.HTTPError: If request fails
        HTTPException 422: If data doesn't match schema
    """
    if isinstance(data, (ControlDefinition, TemplateControlInput)):
        # Convert model to dict, excluding None to keep payload clean
        payload: dict[str, Any] = data.model_dump(mode="json", exclude_none=True)
    else:
        # We assume it's a dict if it's not a model
        payload = cast(dict[str, Any], data)

    response = await client.http_client.put(
        f"/api/v1/controls/{control_id}/data",
        json={"data": payload}
    )
    response.raise_for_status()
    return cast(dict[str, Any], response.json())


async def validate_control_data(
    client: AgentControlClient,
    data: dict[str, Any] | ControlDefinition | TemplateControlInput,
) -> dict[str, Any]:
    """Validate raw or template-backed control data without saving it."""
    if isinstance(data, (ControlDefinition, TemplateControlInput)):
        payload: dict[str, Any] = data.model_dump(mode="json", exclude_none=True)
    else:
        payload = cast(dict[str, Any], data)

    response = await client.http_client.post(
        "/api/v1/controls/validate",
        json={"data": payload},
    )
    response.raise_for_status()
    return cast(dict[str, Any], response.json())


async def render_control_template(
    client: AgentControlClient,
    template: dict[str, Any] | TemplateDefinition,
    template_values: dict[str, TemplateValue],
) -> dict[str, Any]:
    """Render a control template preview without persisting it."""
    if isinstance(template, TemplateDefinition):
        serialized_template = template.model_dump(mode="json", exclude_none=True)
    else:
        serialized_template = cast(dict[str, Any], template)

    response = await client.http_client.post(
        "/api/v1/control-templates/render",
        json={
            "template": serialized_template,
            "template_values": template_values,
        },
    )
    response.raise_for_status()
    return cast(dict[str, Any], response.json())


def to_template_control_input(
    data: dict[str, Any] | ControlDefinition | UnrenderedTemplateControl,
) -> TemplateControlInput:
    """Convert stored control data into template authoring input.

    This is the supported reshape path for template-backed controls returned by
    ``GET /controls/{id}`` or ``GET /controls/{id}/data`` before submitting them
    back to ``set_control_data``.  Accepts both rendered (``ControlDefinition``)
    and unrendered (``UnrenderedTemplateControl``) shapes.
    """
    if isinstance(data, UnrenderedTemplateControl):
        return TemplateControlInput(
            template=data.template,
            template_values=dict(data.template_values),
        )
    if isinstance(data, ControlDefinition):
        return data.to_template_control_input()

    # Raw dict — detect unrendered vs rendered by checking for condition key.
    if (
        isinstance(data, dict)
        and data.get("template") is not None
        and data.get("condition") is None
    ):
        unrendered = UnrenderedTemplateControl.model_validate(data)
        return TemplateControlInput(
            template=unrendered.template,
            template_values=dict(unrendered.template_values),
        )

    control_def = ControlDefinition.model_validate(data)
    return control_def.to_template_control_input()


async def add_rule_to_control(
    client: AgentControlClient,
    control_id: int,
    rule_id: int
) -> dict[str, Any]:
    """
    Associate a rule with a control.

    This operation is idempotent - adding the same rule multiple times has no effect.
    Agents with policies containing this control will immediately see the added rule.

    Args:
        client: AgentControlClient instance
        control_id: ID of the control
        rule_id: ID of the rule to add

    Returns:
        Dictionary containing:
            - success: True if operation succeeded

    Raises:
        httpx.HTTPError: If request fails
        HTTPException 404: Control or rule not found
        HTTPException 500: Database error

    Example:
        async with AgentControlClient() as client:
            result = await add_rule_to_control(client, control_id=5, rule_id=10)
            print(f"Success: {result['success']}")
    """
    response = await client.http_client.post(
        f"/api/v1/controls/{control_id}/rules/{rule_id}"
    )
    response.raise_for_status()
    return cast(dict[str, Any], response.json())


async def remove_rule_from_control(
    client: AgentControlClient,
    control_id: int,
    rule_id: int
) -> dict[str, Any]:
    """
    Remove a rule from a control.

    This operation is idempotent - removing a non-associated rule has no effect.
    Agents with policies containing this control will immediately lose the removed rule.

    Args:
        client: AgentControlClient instance
        control_id: ID of the control
        rule_id: ID of the rule to remove

    Returns:
        Dictionary containing:
            - success: True if operation succeeded

    Raises:
        httpx.HTTPError: If request fails
        HTTPException 404: Control or rule not found
        HTTPException 500: Database error

    Example:
        async with AgentControlClient() as client:
            result = await remove_rule_from_control(client, control_id=5, rule_id=10)
            print(f"Success: {result['success']}")
    """
    response = await client.http_client.delete(
        f"/api/v1/controls/{control_id}/rules/{rule_id}"
    )
    response.raise_for_status()
    return cast(dict[str, Any], response.json())


async def list_control_rules(
    client: AgentControlClient,
    control_id: int
) -> dict[str, Any]:
    """
    List all rules associated with a control.

    Args:
        client: AgentControlClient instance
        control_id: ID of the control

    Returns:
        Dictionary containing:
            - rule_ids: List of rule IDs associated with the control

    Raises:
        httpx.HTTPError: If request fails
        HTTPException 404: Control not found

    Example:
        async with AgentControlClient() as client:
            result = await list_control_rules(client, control_id=5)
            rule_ids = result["rule_ids"]
            print(f"Control has {len(rule_ids)} rules: {rule_ids}")
    """
    response = await client.http_client.get(
        f"/api/v1/controls/{control_id}/rules"
    )
    response.raise_for_status()
    return cast(dict[str, Any], response.json())


async def delete_control(
    client: AgentControlClient,
    control_id: int,
    force: bool = False,
) -> dict[str, Any]:
    """
    Delete a control by ID.

    By default, deletion fails if the control is associated with any policy.
    Use force=True to automatically dissociate and delete.

    Args:
        client: AgentControlClient instance
        control_id: ID of the control to delete
        force: If True, remove associations before deleting

    Returns:
        Dictionary containing:
            - success: True if control was deleted
            - dissociated_from: List of policy IDs the control was removed from

    Raises:
        httpx.HTTPError: If request fails
        HTTPException 404: Control not found
        HTTPException 409: Control is in use (and force=False)

    Example:
        async with AgentControlClient() as client:
            # Try to delete (fails if in use)
            try:
                result = await delete_control(client, control_id=5)
            except httpx.HTTPStatusError as e:
                if e.response.status_code == 409:
                    # Force delete
                    result = await delete_control(client, control_id=5, force=True)
                    print(f"Removed from {len(result['dissociated_from'])} policies")
    """
    params = {"force": force}
    response = await client.http_client.delete(
        f"/api/v1/controls/{control_id}",
        params=params,
    )
    response.raise_for_status()
    return cast(dict[str, Any], response.json())


async def update_control(
    client: AgentControlClient,
    control_id: int,
    name: str | None = None,
    enabled: bool | None = None,
) -> dict[str, Any]:
    """
    Update control metadata (name and/or enabled status).

    This endpoint allows partial updates - only provide the fields you want to change.

    Control names are canonicalized by the API (leading/trailing whitespace
    is trimmed); callers may pass trimmed names for consistency.

    Args:
        client: AgentControlClient instance
        control_id: ID of the control to update
        name: New name for the control (optional)
        enabled: Enable or disable the control (optional, requires control to have data)

    Returns:
        Dictionary containing:
            - success: True if update succeeded
            - name: Current control name (may have changed)
            - enabled: Current enabled status (if control has data)

    Raises:
        httpx.HTTPError: If request fails
        HTTPException 404: Control not found
        HTTPException 409: New name conflicts with existing control
        HTTPException 422: Cannot update enabled (control has no data configured)

    Example:
        async with AgentControlClient() as client:
            # Rename a control
            result = await update_control(client, control_id=5, name="new-name")

            # Disable a control
            result = await update_control(client, control_id=5, enabled=False)

            # Both at once
            result = await update_control(
                client,
                control_id=5,
                name="pii-protection-v2",
                enabled=True
            )
    """
    payload: dict[str, Any] = {}
    if name is not None:
        payload["name"] = name
    if enabled is not None:
        payload["enabled"] = enabled

    response = await client.http_client.patch(
        f"/api/v1/controls/{control_id}",
        json=payload,
    )
    response.raise_for_status()
    return cast(dict[str, Any], response.json())
