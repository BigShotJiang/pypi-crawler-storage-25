"""
Models for timeseries forecasting.
"""

from pytorch_forecasting.models.base import (
    AutoRegressiveBaseModel,
    AutoRegressiveBaseModelWithCovariates,
    BaseModel,
    BaseModelWithCovariates,
)
from pytorch_forecasting.models.baseline import Baseline
from pytorch_forecasting.models.deepar import DeepAR
from pytorch_forecasting.models.mlp import DecoderMLP
from pytorch_forecasting.models.nbeats import NBeats, NBeatsKAN
from pytorch_forecasting.models.nhits import NHiTS
from pytorch_forecasting.models.nn import GRU, LSTM, MultiEmbedding, get_rnn
from pytorch_forecasting.models.rnn import RecurrentNetwork
from pytorch_forecasting.models.temporal_fusion_transformer import (
    TemporalFusionTransformer,
)
from pytorch_forecasting.models.tide import TiDEModel
from pytorch_forecasting.models.timexer import TimeXer
from pytorch_forecasting.models.xlstm import xLSTMTime

__all__ = [
    "NBeats",
    "NBeatsKAN",
    "NHiTS",
    "TemporalFusionTransformer",
    "RecurrentNetwork",
    "DeepAR",
    "BaseModel",
    "Baseline",
    "BaseModelWithCovariates",
    "AutoRegressiveBaseModel",
    "AutoRegressiveBaseModelWithCovariates",
    "get_rnn",
    "LSTM",
    "GRU",
    "MultiEmbedding",
    "DecoderMLP",
    "TiDEModel",
    "TimeXer",
    "xLSTMTime",
]
