import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  HiMiniBookOpen,
  HiMiniTag,
  HiMiniComputerDesktop,
  HiMiniChartBar,
} from "react-icons/hi2";

import {
  Badge,
  EmptyState,
  SectionLabel,
  GuardHero,
} from "./approval-center-primitives";
import { harnessDisplayName, formatRelativeTime } from "./approval-center-utils";
import type { GuardReceipt } from "./guard-types";
import { StoryTab, CategoryTab, AppTab, ExploreTab, detectCategory } from "./evidence";

function useMountedTabs(activeTab: TabKey): Set<TabKey> {
  const [mounted, setMounted] = useState<Set<TabKey>>(new Set([activeTab]));
  useEffect(() => {
    setMounted((prev) => {
      if (prev.has(activeTab)) return prev;
      const next = new Set(prev);
      next.add(activeTab);
      return next;
    });
  }, [activeTab]);
  return mounted;
}

type TabKey = "story" | "category" | "app" | "explore";
type TimeFilter = "all" | "today" | "yesterday" | "week" | "last7d" | "last30d";
type DecisionFilter = "all" | "allow" | "block";

type ReceiptsState =
  | { kind: "loading" }
  | { kind: "error"; message: string }
  | { kind: "ready"; items: GuardReceipt[] };

const TIME_FILTER_VALUES: TimeFilter[] = ["all", "today", "yesterday", "week", "last7d", "last30d"];
const DECISION_FILTER_VALUES: DecisionFilter[] = ["all", "allow", "block"];

const TAB_CONFIG: { key: TabKey; label: string; icon: React.ElementType }[] = [
  { key: "story", label: "Story", icon: HiMiniBookOpen },
  { key: "category", label: "Category", icon: HiMiniTag },
  { key: "app", label: "App", icon: HiMiniComputerDesktop },
  { key: "explore", label: "Explore", icon: HiMiniChartBar },
];

const CATEGORY_CONFIG: { key: string; label: string; value: string }[] = [
  { key: "all", label: "All", value: "" },
  { key: "secret", label: "Secrets", value: "secret" },
  { key: "network", label: "Network", value: "network" },
  { key: "destructive", label: "Destructive", value: "destructive" },
  { key: "hidden", label: "Hidden", value: "hidden" },
  { key: "other", label: "Other", value: "other" },
];

export function ReceiptsWorkspace(props: { receipts: ReceiptsState }) {
  if (props.receipts.kind === "loading") {
    return (
      <div className="space-y-4">
        <div className="guard-skeleton h-8 w-64" />
        <div className="guard-skeleton h-32 w-full" />
      </div>
    );
  }
  if (props.receipts.kind === "error") {
    return (
      <div className="rounded-xl border border-brand-attention/10 bg-brand-attention/[0.03] p-4">
        <p className="text-sm text-brand-dark">{props.receipts.message}</p>
      </div>
    );
  }
  return <ReadyReceiptsWorkspace receiptItems={props.receipts.items} />;
}

function readUrlParams(): {
  search: string;
  time: TimeFilter;
  decision: DecisionFilter;
  harness: string;
  tab: TabKey;
  day: string;
} {
  const params = new URLSearchParams(window.location.search);
  const time = params.get("time") as TimeFilter;
  const decision = params.get("decision") as DecisionFilter;
  const tab = params.get("tab") as TabKey;
  return {
    search: params.get("search") ?? "",
    time: TIME_FILTER_VALUES.includes(time) ? time : "all",
    decision: DECISION_FILTER_VALUES.includes(decision) ? decision : "all",
    harness: params.get("harness") ?? "all",
    tab: TAB_CONFIG.some((t) => t.key === tab) ? tab : "story",
    day: params.get("day") ?? "",
  };
}

function writeUrlParams(params: {
  search: string;
  time: TimeFilter;
  decision: DecisionFilter;
  harness: string;
  tab: TabKey;
  day: string;
}) {
  const url = new URL(window.location.href);
  url.search = "";
  if (params.search) url.searchParams.set("search", params.search);
  if (params.time !== "all") url.searchParams.set("time", params.time);
  if (params.decision !== "all") url.searchParams.set("decision", params.decision);
  if (params.harness !== "all") url.searchParams.set("harness", params.harness);
  if (params.tab !== "story") url.searchParams.set("tab", params.tab);
  if (params.day) url.searchParams.set("day", params.day);
  window.history.replaceState({}, "", url.toString());
}

function timeFilterLabel(filter: TimeFilter): string {
  switch (filter) {
    case "today": return "Today";
    case "yesterday": return "Yesterday";
    case "week": return "Since Sunday";
    case "last7d": return "Last 7 days";
    case "last30d": return "Last 30 days";
    default: return "All time";
  }
}

function decisionFilterLabel(filter: DecisionFilter): string {
  switch (filter) {
    case "allow": return "Allowed";
    case "block": return "Stopped";
    default: return "All decisions";
  }
}

function useDebounce<T>(value: T, delay: number): T {
  const [debouncedValue, setDebouncedValue] = useState(value);
  useEffect(() => {
    const timer = setTimeout(() => setDebouncedValue(value), delay);
    return () => clearTimeout(timer);
  }, [value, delay]);
  return debouncedValue;
}

function ReadyReceiptsWorkspace(props: { receiptItems: GuardReceipt[] }) {
  const initial = useMemo(() => readUrlParams(), []);
  const [search, setSearch] = useState(initial.search);
  const [categoryFilter, setCategoryFilter] = useState<string>("");
  const [timeFilter, setTimeFilter] = useState<TimeFilter>(initial.time);
  const [decisionFilter, setDecisionFilter] = useState<DecisionFilter>(initial.decision);
  const [activeTab, setActiveTab] = useState<TabKey>(initial.tab);
  const [dayFilter, setDayFilter] = useState<string>(initial.day);
  const [harnessFilter, setHarnessFilter] = useState<string>(initial.harness);
  const [isFiltering, setIsFiltering] = useState(false);

  const debouncedSearch = useDebounce(search, 300);

  const harnesses = useMemo(
    () => Array.from(new Set(props.receiptItems.map((r) => r.harness))).sort(),
    [props.receiptItems]
  );

  // URL sync with debounce to avoid races
  const urlSyncTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    if (urlSyncTimerRef.current) {
      clearTimeout(urlSyncTimerRef.current);
    }
    urlSyncTimerRef.current = setTimeout(() => {
      writeUrlParams({
        search: debouncedSearch,
        time: timeFilter,
        decision: decisionFilter,
        harness: harnessFilter,
        tab: activeTab,
        day: dayFilter,
      });
    }, 100);
    return () => {
      if (urlSyncTimerRef.current) {
        clearTimeout(urlSyncTimerRef.current);
      }
    };
  }, [debouncedSearch, timeFilter, decisionFilter, harnessFilter, activeTab, dayFilter]);

  useEffect(() => {
    if (harnessFilter !== "all" && !harnesses.includes(harnessFilter)) {
      setHarnessFilter("all");
    }
  }, [harnesses, harnessFilter]);

  const filtered = useMemo(() => {
    setIsFiltering(true);
    let items = props.receiptItems;
    if (decisionFilter !== "all") {
      items = items.filter((r) => r.policy_decision === decisionFilter);
    }
    if (harnessFilter !== "all") {
      items = items.filter((r) => r.harness === harnessFilter);
    }
    if (timeFilter !== "all") {
      const now = new Date();
      const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const startOfYesterday = new Date(startOfToday);
      startOfYesterday.setDate(startOfYesterday.getDate() - 1);
      const startOfWeek = new Date(startOfToday);
      startOfWeek.setDate(startOfWeek.getDate() - startOfWeek.getDay());
      const startOfLast7d = new Date(startOfToday);
      startOfLast7d.setDate(startOfLast7d.getDate() - 7);
      const startOfLast30d = new Date(startOfToday);
      startOfLast30d.setDate(startOfLast30d.getDate() - 30);
      items = items.filter((r) => {
        const d = new Date(r.timestamp);
        if (timeFilter === "today") return d >= startOfToday;
        if (timeFilter === "yesterday") return d >= startOfYesterday && d < startOfToday;
        if (timeFilter === "week") return d >= startOfWeek;
        if (timeFilter === "last7d") return d >= startOfLast7d;
        if (timeFilter === "last30d") return d >= startOfLast30d;
        return true;
      });
    }
    if (dayFilter) {
      const dayStart = new Date(dayFilter);
      const dayEnd = new Date(dayStart);
      dayEnd.setDate(dayEnd.getDate() + 1);
      items = items.filter((r) => {
        const d = new Date(r.timestamp);
        return d >= dayStart && d < dayEnd;
      });
    }
    if (categoryFilter) {
      items = items.filter((r) => detectCategory(r) === categoryFilter);
    }
    if (debouncedSearch.trim()) {
      const q = debouncedSearch.toLowerCase();
      items = items.filter((r) =>
        (r.artifact_name ?? r.artifact_id).toLowerCase().includes(q) ||
        r.harness.toLowerCase().includes(q)
      );
    }
    const result = items.sort((a, b) => +new Date(b.timestamp) - +new Date(a.timestamp));
    // Clear filtering flag after computation
    setTimeout(() => setIsFiltering(false), 0);
    return result;
  }, [props.receiptItems, decisionFilter, harnessFilter, timeFilter, debouncedSearch, dayFilter, categoryFilter]);

  const handleFilterDay = useCallback((day: string) => {
    setDayFilter(day);
    setTimeFilter("all");
  }, []);

  const handleTabChange = useCallback((tab: TabKey) => {
    setActiveTab(tab);
    // Reset scroll on tab change
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  const totalCount = props.receiptItems.length;

  // Category counts
  const categoryCounts = useMemo(() => {
    const counts = new Map<string, number>();
    for (const r of props.receiptItems) {
      const cat = detectCategory(r);
      counts.set(cat, (counts.get(cat) ?? 0) + 1);
    }
    return counts;
  }, [props.receiptItems]);

  // Tab counts
  const tabCounts = useMemo(() => {
    const counts: Record<TabKey, number> = { story: 0, category: 0, app: 0, explore: 0 };
    // Story and explore show all filtered
    counts.story = filtered.length;
    counts.explore = filtered.length;
    // Category shows unique categories
    const cats = new Set(filtered.map((r) => detectCategory(r)));
    counts.category = cats.size;
    // App shows unique apps
    const apps = new Set(filtered.map((r) => r.harness));
    counts.app = apps.size;
    return counts;
  }, [filtered]);

  if (totalCount === 0) {
    return (
      <EmptyState
        title="No history yet"
        body="Saved choices appear here after HOL Guard reviews or blocks an action."
        tone="teach"
      />
    );
  }

  const hasActiveFilters = debouncedSearch || categoryFilter || harnessFilter !== "all" || timeFilter !== "all" || decisionFilter !== "all" || dayFilter;

  return (
    <div className="space-y-6">
      <GuardHero
        status="clear"
        headline="History"
        subheadline="What Guard decided."
        cta={<Badge tone="info">{totalCount} saved</Badge>}
      />

      {/* Search and filters */}
      <div className="space-y-3">
        <div className="flex flex-wrap items-center gap-2">
          <label className="relative block flex-1 min-w-[200px]">
            <span className="sr-only">Search history</span>
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search command, file, app..."
              className="min-h-10 w-full rounded-lg border border-slate-200 bg-white px-3 text-sm text-brand-dark placeholder:text-slate-400 focus:border-brand-blue focus:outline-none focus:ring-2 focus:ring-brand-blue/20"
            />
          </label>
          <select
            value={timeFilter}
            onChange={(e) => setTimeFilter(e.target.value as TimeFilter)}
            className="min-h-10 rounded-lg border border-slate-200 bg-white px-3 text-sm font-medium text-brand-dark focus:border-brand-blue focus:outline-none focus:ring-2 focus:ring-brand-blue/20"
          >
            {TIME_FILTER_VALUES.map((t) => (
              <option key={t} value={t}>{timeFilterLabel(t)}</option>
            ))}
          </select>
          <select
            value={decisionFilter}
            onChange={(e) => setDecisionFilter(e.target.value as DecisionFilter)}
            className="min-h-10 rounded-lg border border-slate-200 bg-white px-3 text-sm font-medium text-brand-dark focus:border-brand-blue focus:outline-none focus:ring-2 focus:ring-brand-blue/20"
          >
            {DECISION_FILTER_VALUES.map((d) => (
              <option key={d} value={d}>{decisionFilterLabel(d)}</option>
            ))}
          </select>
        </div>

        {/* Category filter bar */}
        <div className="flex flex-wrap items-center gap-1.5">
          {CATEGORY_CONFIG.map((c) => {
            const count = c.value ? categoryCounts.get(c.value) ?? 0 : totalCount;
            const isActive = categoryFilter === c.value;
            if (c.value && count === 0) return null;
            return (
              <button
                key={c.key}
                aria-pressed={isActive}
                className={`rounded-full px-3 py-1.5 text-xs font-medium transition-all ${
                  isActive
                    ? "bg-brand-blue text-white shadow-sm"
                    : "border border-slate-200 bg-white text-brand-dark hover:bg-slate-50"
                }`}
                onClick={() => setCategoryFilter(isActive ? "" : c.value)}
              >
                {c.label} {count > 0 && <span className="opacity-70">({count})</span>}
              </button>
            );
          })}
          <span className="mx-1 h-4 w-px bg-slate-200" />
          <select
            value={harnessFilter}
            onChange={(e) => setHarnessFilter(e.target.value)}
            className="h-8 rounded-md border-0 bg-transparent px-2 py-1 text-xs font-medium text-brand-dark hover:bg-slate-100 focus:bg-slate-100 focus:outline-none"
          >
            <option value="all">All apps</option>
            {harnesses.map((h) => (
              <option key={h} value={h}>{harnessDisplayName(h)}</option>
            ))}
          </select>
          {hasActiveFilters && (
            <button
              onClick={() => { setSearch(""); setCategoryFilter(""); setHarnessFilter("all"); setTimeFilter("all"); setDecisionFilter("all"); setDayFilter(""); }}
              className="ml-auto text-xs font-medium text-brand-blue hover:text-brand-dark transition-colors"
            >
              Clear filters
            </button>
          )}
        </div>

        {/* Results count */}
        {isFiltering ? (
          <div className="guard-skeleton h-4 w-48" />
        ) : (
          <p className="text-xs text-slate-500">
            Showing {filtered.length} of {totalCount} decisions
            {filtered.length !== totalCount && hasActiveFilters ? " (filtered)" : ""}
          </p>
        )}
      </div>

      {/* Tabs */}
      <div className="flex gap-1 rounded-xl border border-slate-200/70 bg-white/80 p-1 shadow-sm" role="tablist" aria-label="History views">
        {TAB_CONFIG.map((t) => {
          const Icon = t.icon;
          const isActive = activeTab === t.key;
          const count = tabCounts[t.key];
          return (
            <button
              key={t.key}
              role="tab"
              aria-selected={isActive}
              aria-controls={`tabpanel-${t.key}`}
              id={`tab-${t.key}`}
              onClick={() => handleTabChange(t.key)}
              className={`flex flex-1 items-center justify-center gap-2 rounded-lg px-4 py-2.5 text-sm font-medium transition-all ${
                isActive
                  ? "bg-brand-blue text-white shadow-sm"
                  : "text-brand-dark hover:bg-slate-50"
              }`}
            >
              <Icon className="h-4 w-4" aria-hidden="true" />
              <span className="hidden sm:inline">{t.label}</span>
              <span className="text-[10px] opacity-70">({count})</span>
            </button>
          );
        })}
      </div>

      {/* Tab content */}
      <TabPanels
        activeTab={activeTab}
        filtered={filtered}
        receiptItems={props.receiptItems}
        dayFilter={dayFilter}
        handleFilterDay={handleFilterDay}
        harnessFilter={harnessFilter}
        setHarnessFilter={setHarnessFilter}
        setSearch={setSearch}
        search={search}
        timeFilter={timeFilter}
        decisionFilter={decisionFilter}
      />
    </div>
  );
}

function TabPanels(props: {
  activeTab: TabKey;
  filtered: GuardReceipt[];
  receiptItems: GuardReceipt[];
  dayFilter: string;
  handleFilterDay: (day: string) => void;
  harnessFilter: string;
  setHarnessFilter: (h: string) => void;
  setSearch: (s: string) => void;
  search: string;
  timeFilter: TimeFilter;
  decisionFilter: DecisionFilter;
}) {
  const mounted = useMountedTabs(props.activeTab);
  return (
    <div className="min-h-[300px]">
      {mounted.has("story") && (
        <div id="tabpanel-story" role="tabpanel" aria-labelledby="tab-story" hidden={props.activeTab !== "story"}>
          <StoryTab receipts={props.filtered} selectedDay={props.dayFilter} onSelectDay={props.handleFilterDay} />
        </div>
      )}
      {mounted.has("category") && (
        <div id="tabpanel-category" role="tabpanel" aria-labelledby="tab-category" hidden={props.activeTab !== "category"}>
          <CategoryTab receipts={props.filtered} />
        </div>
      )}
      {mounted.has("app") && (
        <div id="tabpanel-app" role="tabpanel" aria-labelledby="tab-app" hidden={props.activeTab !== "app"}>
          <AppTab receipts={props.filtered} />
        </div>
      )}
      {mounted.has("explore") && (
        <div id="tabpanel-explore" role="tabpanel" aria-labelledby="tab-explore" hidden={props.activeTab !== "explore"}>
          <ExploreTab
            receipts={props.receiptItems}
            filteredReceipts={props.filtered}
            filters={{ search: props.search, time: props.timeFilter, decision: props.decisionFilter, harness: props.harnessFilter }}
            onFilterDay={props.handleFilterDay}
            onFilterHarness={(harness) => props.setHarnessFilter(harness)}
            onFilterAction={(name) => props.setSearch(name)}
          />
        </div>
      )}
    </div>
  );
}

export function filterReceiptItems(
  items: GuardReceipt[],
  searchTerm: string,
  harnessFilter: string,
  decisionFilter: string,
  dateRange: string
): GuardReceipt[] {
  const normalizedSearchTerm = searchTerm.trim().toLowerCase();
  const now = Date.now();
  const todayStart = new Date();
  todayStart.setHours(0, 0, 0, 0);
  const todayStartMs = todayStart.getTime();
  const last7Start = now - 7 * 24 * 60 * 60 * 1000;
  return items.filter((receipt) => {
    const matchesHarness = harnessFilter === "all" || receipt.harness === harnessFilter;
    const matchesDecision = decisionFilter === "all" || receipt.policy_decision === decisionFilter;
    if (!matchesHarness || !matchesDecision) {
      return false;
    }
    if (dateRange === "today" || dateRange === "last7") {
      const ts = new Date(receipt.timestamp).getTime();
      if (dateRange === "today" && ts < todayStartMs) {
        return false;
      } else if (dateRange === "last7" && ts < last7Start) {
        return false;
      }
    }
    if (normalizedSearchTerm.length === 0) {
      return true;
    }
    const name = (receipt.artifact_name ?? receipt.artifact_id).toLowerCase();
    return name.includes(normalizedSearchTerm);
  });
}
