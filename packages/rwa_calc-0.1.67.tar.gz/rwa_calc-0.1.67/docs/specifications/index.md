# RWA Calculator Specifications

This section contains the formal specifications for the RWA Calculator. These specifications serve as:

1. **Living documentation** - Human-readable descriptions of business rules and regulatory treatments
2. **Acceptance criteria** - Clear definition of expected behaviour for each scenario
3. **Traceability** - Each scenario maps to acceptance tests via scenario IDs

## Specification Index

### CRR Framework (Current - Until December 2026)

| Specification | Description | Regulatory Reference |
|--------------|-------------|---------------------|
| [SA Risk Weights](crr/sa-risk-weights.md) | Standardised Approach risk weights by exposure class and CQS | CRR Art. 112-134 |
| [Supporting Factors](crr/supporting-factors.md) | SME (0.7619) and infrastructure (0.75) factors | CRR Art. 501, 501a |
| [F-IRB Calculation](crr/firb-calculation.md) | Foundation IRB with supervisory LGD | CRR Art. 153-154, 161-163 |
| [A-IRB Calculation](crr/airb-calculation.md) | Advanced IRB with internal estimates | CRR Art. 153-154 |
| [Credit Conversion Factors](crr/credit-conversion-factors.md) | CCF for off-balance sheet items | CRR Art. 111, 166 |
| [Credit Risk Mitigation](crr/credit-risk-mitigation.md) | Collateral haircuts, guarantees, and overcollateralisation | CRR Art. 192-241 |
| [Slotting Approach](crr/slotting-approach.md) | Specialised lending categories | CRR Art. 147(8), 153(5) |
| [Provisions](crr/provisions.md) | Provision treatment and EL comparison | CRR Art. 159; PRA Rulebook Art. 158 |
| [Equity Approach](crr/equity-approach.md) | SA equity (Art. 133), IRB Simple (Art. 155), CIU treatment | CRR Art. 132-133, 155 |

### Basel 3.1 Framework (From January 2027)

| Specification | Description | Regulatory Reference | Test Group |
|--------------|-------------|---------------------|------------|
| [SA Risk Weights](basel31/sa-risk-weights.md) | ECRA/SCRA, corporate sub-categories, RE loan-splitting, SA specialised lending | Art. 112–134 | B31-A |
| [Foundation IRB](basel31/firb-calculation.md) | Reduced senior LGD (40%), higher PD floor (0.05%), covered bond LGD, 1.06 removal | Art. 153–163 | B31-B |
| [Advanced IRB](basel31/airb-calculation.md) | LGD floors, post-model adjustments, CCF floor, double default removal | Art. 153–154, 161, 164, 166D | B31-C |
| [Credit Risk Mitigation](basel31/credit-risk-mitigation.md) | Revised 5-band haircuts, equity haircuts, IRB parameter substitution | Art. 191A–241 | B31-D, B31-D7 |
| [Slotting Approach](basel31/slotting-approach.md) | Revised weights, maturity split removal, no pre-op PF distinction | Art. 147(8), 153(5) | B31-E |
| [Output Floor](basel31/output-floor.md) | PRA 4-year transitional floor, OF-ADJ capital adjustment | Art. 92(2A)–(2D) | B31-F |
| [Provisions](basel31/provisions.md) | EL with revised LGD, Art. 158(6A) monotonicity, shortfall/excess | Art. 158–159 | B31-G |
| [Defaulted Exposures](basel31/defaulted-exposures.md) | Provision-coverage split (100%/150%), RESI RE exception, IRB defaulted | Art. 127, 153(1), 154(1) | B31-K |
| [Equity Approach](basel31/equity-approach.md) | New SA equity regime (250%/400%), IRB removal, transitional, CIU | Art. 133, 147A, Rules 4.1–4.8 | B31-L |
| [Model Permissions](basel31/model-permissions.md) | Art. 147A approach restrictions: FSE, large corporate, institution, equity | Art. 147A; PS1/26 Glossary (LFSE, CRR Art. 142(1)(4)) | B31-M |

See also the [CRR vs Basel 3.1](../framework-comparison/index.md) section for comparison documentation.

### Common (Framework-Agnostic)

| Specification | Description |
|--------------|-------------|
| [Hierarchy & Classification](common/hierarchy-classification.md) | Counterparty hierarchy resolution and exposure classification |
| [Stress Testing](common/stress-testing.md) | Pipeline integrity tests at 10K–100K scale across all framework/permission combinations |

### Project

| Specification | Description |
|--------------|-------------|
| [Overview](overview.md) | Executive summary, scope, users, technology stack |
| [Architecture](architecture.md) | Pipeline stages, design decisions, data model |
| [Configuration](configuration.md) | Framework toggle, IRB permissions, PD/LGD floors |
| [Output & Reporting](output-reporting.md) | Aggregation, output floor, COREP, export |
| [Interfaces](interfaces.md) | Python API, Marimo UI, CLI |
| [Observability](observability.md) | Logging contract, correlation IDs, format, enforcement |
| [NFRs](nfr.md) | Performance, correctness, reliability targets |
| [Milestones](milestones.md) | Release plan, risks |
| [Regulatory Compliance](regulatory-compliance.md) | CRR + Basel 3.1 compliance matrix, acceptance tests |
| [Glossary](glossary.md) | Regulatory terms |

## Scenario Coverage by Test Group

### Group A: Standardised Approach
Covers risk weight determination for all SA exposure classes:

- Sovereigns (CQS 1-6 and unrated)
- Institutions (CQS-based per Art. 120)
- Corporates (rated and unrated)
- Retail (fixed 75%)
- Residential mortgages (LTV-based split at 80%)
- Commercial real estate (LTV-based with income cover test)

### Group B: Foundation IRB
Covers F-IRB calculation components:

- PD floor (0.03%)
- Supervisory LGD (45% senior, 75% subordinated)
- Corporate correlation formula with PD-dependent decay
- SME firm-size correlation adjustment
- Maturity adjustment
- Expected loss calculation
- 1.06 scaling factor

### Group C: Advanced IRB
Covers A-IRB with internal estimates:

- Internal LGD application
- Internal CCF application
- FI scalar (1.25x) for large financial institutions

### Group D: Credit Risk Mitigation
Covers CRM techniques:

- Basic CRM (D1–D6): Financial collateral haircuts (Art. 224), FX mismatch (8%), overcollateralisation (Art. 230), guarantee substitution (Art. 213-217), multi-level collateral, maturity mismatch (Art. 238)
- Advanced CRM (D7–D14, D9b): non-beneficial guarantees, sovereign guarantees, CDS restructuring exclusion/inclusion, gold/equity collateral, overcollateralisation floor, full CRM chain, mixed collateral types
- Provision-CRM interaction (G4–G6): SA provision deduction (Art. 110), multiple provisions, provision + collateral combined waterfall

### Group E: Slotting
Covers specialised lending:

- Slotting categories (Strong to Default)
- HVCRE elevated risk weights
- Project/Object/Commodities/IPRE finance types

### Group F: Supporting Factors
Covers CRR-specific factors:

- SME supporting factor (tiered: 0.7619 / 0.85)
- Infrastructure supporting factor (0.75)

### Group G: Provisions
Covers provision treatment:

- SA provision deduction from exposure
- IRB expected loss comparison

### Group H: Complex/Combined
Covers multi-approach and combined scenarios:

- Mixed SA/IRB portfolios
- Multi-level hierarchy with CRM
- Combined supporting factors with output floor

### Group I: Defaulted Exposures
Covers defaulted exposure treatment:

- F-IRB defaulted (K=0, CRR Art. 153(1)(ii))
- A-IRB defaulted (K=max(0, LGD−BEEL), CRR Art. 154(1)(i))
- Defaulted with CRM adjustments

### Group J: Equity
Covers equity exposure treatment:

- SA equity flat 100% (CRR Art. 133(2)) — listed, unlisted, PE/VC
- IRB Simple risk weights (CRR Art. 155(2)) — exchange-traded 290%, PE diversified 190%, other 370%
- CIU treatment — mandate-based, look-through, fallback (CRR Art. 132)
- RWA arithmetic validation

### Basel 3.1 Groups
Basel 3.1 scenarios mirror the CRR structure with additional framework-specific tests:

- B31-A through B31-H: Same structure as CRR groups with Basel 3.1 rule changes
- B31-D7: Parameter substitution (IRB guarantor PD substitution, new in Basel 3.1)
- B31-F: Output floor phase-in (60%–72.5%, 2027–2030)
- B31-K: Defaulted exposures (provision-coverage split, RESI RE exception, IRB K=0)
- B31-L: Equity approach (SA 250%/400%, IRB removal, transitional phase-in, CIU treatment)
- B31-M: Model permissions (Art. 147A restrictions — FSE, large corporate, institution, equity routing)

### Stress Testing Groups
Pipeline integrity tests at scale (framework-agnostic):

- STRESS-1 to STRESS-14: Row count preservation, column completeness, numerical stability, risk weight bounds, approach routing, exposure class coverage, output floor at scale, error accumulation, summary consistency, EAD consistency, determinism, framework comparison, large-scale 100K, reference uniqueness

See the [Stress Testing Specification](common/stress-testing.md) for full scenario definitions.

### Comparison Groups
Dual-framework comparison scenarios:

- M3.1: Side-by-side CRR vs Basel 3.1 RWA comparison
- M3.2: Capital impact analysis with delta decomposition by driver
- M3.3: Transitional floor schedule modelling (2027–2030)

## Scenario ID Convention

Each scenario is tagged with an identifier for traceability:

| Prefix | Scenarios | Description |
|--------|-----------|-------------|
| `CRR-A` | A1–A9, A11 | CRR Standardised Approach |
| `CRR-B` | B1–B7 | CRR Foundation IRB |
| `CRR-C` | C1–C3 | CRR Advanced IRB |
| `CRR-D` | D1–D14, D.CCF1–CCF4 | CRR Credit Risk Mitigation and CCFs |
| `CRR-E` | E1–E8 | CRR Slotting Approach |
| `CRR-F` | F1–F7 | CRR Supporting Factors |
| `CRR-G` | G1–G3, G4–G6 | CRR Provisions (G4–G6 in CRM spec) |
| `CRR-H` | H1, H3 | CRR Complex/Combined |
| `CRR-I` | I1–I3 | CRR Defaulted Exposures |
| `CRR-J` | J1–J20 | CRR Equity |
| `B31-A` | A1–A11 | Basel 3.1 Standardised Approach |
| `B31-B` | B1–B7 | Basel 3.1 Foundation IRB |
| `B31-C` | C1–C3 | Basel 3.1 Advanced IRB |
| `B31-D` | D1–D6, D7–D7e, D.CCF1–CCF8 | Basel 3.1 Credit Risk Mitigation and CCFs |
| `B31-E` | E1–E4 | Basel 3.1 Slotting Approach |
| `B31-F` | F1–F3 | Basel 3.1 Output Floor |
| `B31-G` | G1–G3 | Basel 3.1 Provisions |
| `B31-H` | H1, H3 | Basel 3.1 Complex/Combined |
| `B31-K` | K1–K12 | Basel 3.1 Defaulted Exposures |
| `B31-L` | L1–L23 | Basel 3.1 Equity Approach |
| `B31-M` | M1–M12 | Basel 3.1 Model Permissions |
| `M3.1` | — | Dual-framework comparison |
| `M3.2` | — | Capital impact analysis |
| `M3.3` | — | Transitional floor modelling |
| `STRESS` | 1–14 | Pipeline stress tests (10K–100K scale) |
| `HIER` | 1–6 | Hierarchy resolution scenarios |
| `CLASS` | 1–8 | Classification scenarios |
| `CONFIG` | 1–6 | Configuration scenarios |

## For Developers

These specifications are verified through acceptance tests in `tests/acceptance/`. See the [Testing Guide](../development/testing.md) for details on running tests.
