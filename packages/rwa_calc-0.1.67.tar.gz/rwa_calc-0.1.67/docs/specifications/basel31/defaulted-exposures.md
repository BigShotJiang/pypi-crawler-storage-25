# Defaulted Exposures Specification

Basel 3.1 treatment of defaulted exposures under the Standardised Approach and IRB,
including the provision-coverage risk weight split and RESI RE exception.

**Regulatory Reference:** PRA PS1/26 Art. 127, Art. 153(1)(ii), Art. 154(1)(i), CRE20.88
**Test Group:** B31-K

---

## Requirements Status

| ID | Requirement | Priority | Status |
|----|-------------|----------|--------|
| FR-10.1 | SA defaulted: provision-coverage 100%/150% RW split | P0 | Done |
| FR-10.2 | SA defaulted: provision threshold at 20% of outstanding amount | P0 | Done |
| FR-10.3 | SA defaulted: unsecured portion determined by the CRM method (Art. 127(2)) | P0 | Done |
| FR-10.4 | SA defaulted: RESI RE non-income-dependent flat 100% exception | P0 | Done |
| FR-10.5 | IRB F-IRB defaulted: K = 0 (Art. 153(1)(ii)) | P0 | Done |
| FR-10.6 | IRB A-IRB defaulted: K = max(0, LGD − BEEL) (Art. 154(1)(i)) | P0 | Done |
| FR-10.7 | IRB defaulted: no 1.06 scaling factor under Basel 3.1 | P0 | Done |

---

## Overview

Basel 3.1 introduces a more granular SA treatment of defaulted exposures compared to CRR.
Under CRR, defaulted exposures generally received a flat 100% or 150% risk weight with limited
distinction. Basel 3.1 introduces a **provision-coverage mechanism** that rewards firms for
adequate provisioning.

!!! info "Default Trigger — Art. 178"
    This specification covers the **consequence** of default (risk weight treatment). The
    **definition** of default — the Art. 178 two-limb trigger (unlikeliness-to-pay and
    90 DPD), UTP indicators, materiality thresholds, suspension rules, and cure/probation
    requirements — is documented in the shared
    [Default Definition (Art. 178) specification](../common/default-definition.md).
    The calculator consumes default status via the upstream `is_defaulted` flag and
    routes accordingly.

### Key Changes from CRR

| Feature | CRR | Basel 3.1 | Reference |
|---------|-----|-----------|-----------|
| SA risk weight mechanism | Flat 100%/150% | Provision-coverage split | Art. 127 |
| Provision threshold denominator | Pre-provision unsecured exposure value | **Outstanding amount** of the item or facility (gross) | Art. 127(1) |
| RESI RE non-income exception | None | Flat 100% regardless of provisions | Art. 127(3) (was cited as 127(1A) in earlier drafts; PDF numbers as para 3) |
| IRB F-IRB defaulted | K = 0; RW includes 1.06 | K = 0; no 1.06 (Art. 153(3) left blank) | Art. 153(1)(ii) |
| IRB A-IRB defaulted | K = max(0, LGD − BEEL); 1.06 in RW | K = max(0, LGD − BEEL); no 1.06 | Art. 154(1)(i) |

---

## SA Defaulted Exposures (Art. 127)

### Provision-Coverage Mechanism

For SA defaulted exposures, the risk weight for the **unsecured portion** depends on the
level of specific provisions relative to the outstanding amount of the item or facility:

```
provision_ratio = specific_provisions / outstanding_amount
```

| Provision Ratio | Risk Weight | Reference |
|----------------|-------------|-----------|
| ≥ 20% | 100% | Art. 127(1)(b) |
| < 20% | 150% | Art. 127(1)(a) |

Where:

- `specific_provisions` = specific credit risk adjustments per Art. 110 and Commission
  Delegated Regulation (EU) No 183/2014
- `outstanding_amount` = the outstanding amount of the item or facility (gross, before
  CRM adjustments)

!!! warning "Denominator Differs from CRR"
    **CRR Art. 127(1)** uses: "the unsecured part of the exposure value if those specific
    credit risk adjustments and deductions were not applied" — the **pre-provision
    unsecured** exposure value.

    **PRA PS1/26 Art. 127(1)** uses: "the outstanding amount of the item or facility" —
    the **gross outstanding** amount (the full facility, not limited to the unsecured
    portion, and not net of provisions).

    The PRA denominator is typically larger, making it easier to reach the 20% threshold
    for a given level of provisioning.

### Secured Portion Treatment

PS1/26 Art. 127(2) defers to the CRM method the institution applies
(Art. 191A(2)) to determine the unsecured portion:

- **Financial Collateral Comprehensive Method (FCCM — default for SA)**:
  eligible financial collateral has already reduced `ead_final` in the
  CRM stage. The value entering the defaulted override IS the unsecured
  value, and Art. 127(1) applies to it flat.
- **Financial Collateral Simple Method (FCSM)**: handled downstream by
  `apply_fcsm_rw_substitution`, which blends the defaulted RW with the
  collateral RW per the substitution rule.
- **Real estate**: eligible RE collateral routes through class
  reclassification (mortgage treatment) upstream; it does not reappear
  as a secured portion inside the defaulted override.

The defaulted override therefore does NOT re-apply a secondary
secured/unsecured split on non-financial collateral columns — that would
double-count the CRM reduction and, for low-RW classes like retail (75%),
drag the defaulted RW below the 100% floor required by Art. 127(1)(b).

```
RWA_defaulted = ead_final × provision_based_rw
```

### RESI RE Non-Income-Dependent Exception

**Art. 127(3) / CRE20.88**

Defaulted exposures secured by **residential real estate** that are **not dependent on cash flows
generated by the property** (i.e., standard owner-occupied mortgages) receive a flat **100% risk weight**
regardless of the provision ratio.

This exception recognises that residential mortgages with recourse to the borrower's income
have a different risk profile from income-dependent real estate exposures.

```
if exposure.is_residential_re and not exposure.is_income_dependent:
    rw = 100%  # Flat, regardless of provision ratio
```

!!! info "Scope of Exception"
    The exception applies only to residential RE exposures that meet the Art. 124A qualifying
    criteria and are not income-dependent. Income-producing residential RE, buy-to-let, and
    commercial RE defaulted exposures all follow the standard provision-coverage mechanism.

---

## IRB Defaulted Exposures

### F-IRB Defaulted (Art. 153(1)(ii))

For F-IRB defaulted exposures, the capital requirement formula component K is set to zero:

```
K = 0
```

The risk weight for F-IRB defaulted is therefore driven entirely by the expected loss (EL)
component:

```
RW = max(0, 12.5 x (LGD - BEEL))
```

Where:

- `LGD` = supervisory LGD (40% senior non-FSE, 45% FSE, 75% subordinated)
- `BEEL` = best estimate of expected loss — the firm's estimate of loss given default has occurred

!!! note "1.06 Scaling Factor Removed"
    Under CRR, the IRB capital formula included a 1.06 scaling factor (Art. 153(3)). Basel 3.1
    removes this — Art. 153(3) is "[Provision left blank]" in PRA PS1/26. This applies to all
    IRB exposures, not just defaulted.

### A-IRB Defaulted (Art. 154(1)(i))

For A-IRB defaulted exposures, K uses the firm's own LGD estimate:

```
K = max(0, LGD - BEEL)
```

Where:

- `LGD` = the firm's internal LGD estimate for the defaulted exposure, subject to LGD floors
- `BEEL` = best estimate of expected loss

The risk weight is:

```
RW = max(0, 12.5 x K)
```

### Expected Loss for Defaulted

Art. 158(5) sets a **different** EL rule for the two IRB approaches:

| Approach | Defaulted EL amount | Rationale |
|---|---|---|
| **F-IRB defaulted** | `EL = PD x LGD x EAD = 1 x LGD x EAD` | Standard Art. 158(5) first formula with PD = 1 |
| **A-IRB defaulted** | `EL = BEEL x EAD` | Art. 158(5) closing proviso — firm's own best estimate substitutes for the PD x LGD product |

!!! quote "PRA PS1/26 Art. 158(5) verbatim (ps126app1.pdf p. 107)"
    "An institution using the Foundation IRB Approach or Advanced IRB Approach shall,
    subject to the specific treatment laid down in paragraphs 6 and 6A, calculate the
    expected loss (EL) and expected loss amounts for exposures to corporates and
    institutions and for retail exposures in accordance with the following formulae:

    Expected loss (EL) = PD · LGD

    Expected loss amount = EL · exposure value

    **except for defaulted exposures (PD = 1) where the institution uses the Advanced
    IRB Approach, EL shall be BEEL.**"

The substitution applies **only** to the A-IRB EL amount (the figure that feeds Pool C
of the Art. 159 provisions comparison). The **RW formulas** in Art. 153(1)(b) and
Art. 154(1)(i) reference BEEL for both F-IRB and A-IRB defaulted exposures — that is a
capital-calculation mechanic distinct from the Art. 158(5) EL-amount definition.

### BEEL — Best Estimate of Expected Loss (Art. 158(5), Art. 181(1)(h)(ii))

**Definition.** BEEL is the institution's own estimate of the economic loss expected
on a defaulted exposure over the period from the default event to the final
liquidation or recovery, expressed as a fraction of exposure at default. It is the
A-IRB counterpart to the supervisory LGD applied to non-defaulted exposures.

**PRA Rulebook source.** BEEL is a defined term in the Credit Risk: Internal Ratings
Based Approach (CRR) Part of the PRA Rulebook (Rule 1.3): *"BEEL means an institution's
best estimate of expected loss for a defaulted exposure as referred to in point
(h)(ii) of Article 181(1)"*. Art. 181(1)(h)(ii) sets the **estimation standards**
an institution must satisfy before it may recognise its own BEEL estimate:

- **Downturn conditions.** BEEL must be estimated on the basis of economic conditions
  observed during periods of stress relevant to the exposure, consistent with the
  downturn-LGD requirements of Art. 181(1)(b).
- **Evidence of unexpected additional loss during recovery.** Where the institution
  has evidence of unexpected loss during the recovery period, the BEEL estimate must
  be greater than or equal to the expected economic loss given default (i.e. BEEL ≥
  LGD-in-default after recoveries).
- **No cherry-picking.** Observed recovery realisations must be used symmetrically —
  favourable and unfavourable outcomes must both inform the estimate.
- **Governance and independence.** Estimates must be subject to the same validation,
  human oversight, and back-testing processes applied to other A-IRB parameters
  (Art. 185 validation rules apply by reference).

**Scope — A-IRB only.** BEEL is an A-IRB-specific input for the EL-amount calculation
in Art. 158(5); under F-IRB the EL amount uses the standard Art. 158(5) formula
`PD x LGD x EAD` with PD = 1, so F-IRB firms do not need to estimate BEEL separately
for Pool C. The supervisory LGD parameter (40% senior non-FSE, 45% FSE, etc.) already
provides the conservative loss expectation under F-IRB.

**Sovereign/central-bank carve-out.** Under PS1/26 Art. 147A(1)(a), sovereign,
central-bank, RGLA, PSE, MDB and international-organisation exposures are **excluded**
from A-IRB; BEEL therefore cannot arise for these classes — any exposure to a
defaulted quasi-sovereign counterparty must be treated under SA (Art. 127).

**Required input.** The engine consumes BEEL as a row-level input named `beel` of type
Float64. The column is defined in `src/rwa_calc/data/schemas.py` on `loans`,
`contingents`, and `facility_details`, defaults to `0.0`, and is read by
`engine/irb/adjustments.py` solely when `is_defaulted = True` and the exposure is
routed through the A-IRB approach (see
[Default Definition spec — BEEL Companion Input](../common/default-definition.md#beel-companion-input-a-irb-only)).

**Relationship to `LGD-in-default`.** The A-IRB capital formula `K = max(0, LGD − BEEL)`
uses the institution's **LGD-in-default estimate** (the firm's current best view of
post-default economic loss, used in the RW structure) minus BEEL (the firm's best
estimate of EL amount already accrued). Where BEEL ≥ LGD-in-default, `K = 0` and the
RW collapses to `max(0, 12.5 × 0) = 0`; Pool C of the Art. 159 comparison still
carries the full BEEL × EAD amount as the defaulted EL contribution.

!!! info "CRR → PS1/26 terminology change"
    Pre-revocation CRR used the symbol **`ELBE`** (Expected Loss Best Estimate) in
    Art. 158(5) and Art. 181(1)(h). PS1/26 renames this to **`BEEL`** (Best Estimate of
    Expected Loss) with no substantive change in the estimation standards —
    Art. 181(1)(h)(ii) wording tracks the CRR version. The engine's `beel` column and
    internal variable names use the PS1/26 term. Legacy CRR documentation and model
    validation reports that reference `ELBE` denote the same parameter.

!!! warning "Interaction with Art. 158(6A) post-model EL uplift"
    PS1/26 introduces a new paragraph 6A requiring institutions to **increase** the
    total EL amounts (paragraphs 5 and 6) to reflect any post-model adjustments
    recognised under Art. 146(3)(c). For A-IRB defaulted exposures this means the
    `BEEL × EAD` contribution is uplifted by any PMA component before entering Pool C
    of the Art. 159 comparison. See
    [Provisions spec — Art. 158(6A) EL Monotonicity](provisions.md#art-1586a-el-monotonicity).
    No equivalent paragraph existed under pre-revocation CRR.

---

## Key Scenarios

| Scenario ID | Description | Expected Outcome |
|-------------|-------------|------------------|
| B31-K1 | SA defaulted, provisions ≥ 20% of outstanding amount | 100% RW |
| B31-K2 | SA defaulted, provisions < 20% of outstanding amount | 150% RW |
| B31-K3 | SA defaulted, zero provisions | 150% RW on full ead_final |
| B31-K4 | SA defaulted, RESI RE non-income-dependent | 100% RW (flat, Art. 127(3)) |
| B31-K5 | SA defaulted, RESI RE non-income with collateral columns populated | 100% RW (flat, Art. 127(3) overrides) |
| B31-K6 | SA defaulted, RESI RE income-dependent (IPRRE) | Provision-coverage test on full ead_final |
| B31-K7 | SA defaulted corporate, non-fin collateral columns populated | Full provision-based RW (columns ignored by defaulted override) |
| B31-K8 | SA defaulted, B31 vs CRR denominator difference | 100% under B31, 150% under CRR |
| B31-K9 | F-IRB defaulted corporate | K=0, RW=0, EL = LGD × EAD |
| B31-K10 | A-IRB retail defaulted | K = max(0, LGD − BEEL) |
| B31-K11 | A-IRB corporate defaulted (no 1.06 scaling under B31) | RWA matches CRR (no 1.06 in Art. 153(1)(ii)) |
| B31-K12 | A-IRB corporate defaulted, BEEL > LGD | K=0 (floored) |

## Acceptance Tests

| Group | Scenarios | Tests | Pass Rate |
|-------|-----------|-------|-----------|
| B31-K: Defaulted Exposures | K1–K12 | 31 | 100% (31/31) |
