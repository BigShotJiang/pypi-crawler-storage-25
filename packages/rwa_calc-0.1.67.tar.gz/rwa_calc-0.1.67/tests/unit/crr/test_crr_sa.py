"""Unit tests for the CRR Standardised Approach (SA) calculator.

Tests cover:
- SA risk weight lookups by exposure class and CQS
- UK institution deviation (30% for CQS2)
- Retail 75% risk weight
- Residential mortgage LTV treatment
- Commercial real estate LTV treatment
- SME supporting factor (tiered)
- Infrastructure supporting factor
- RWA calculation

References:
- CRR Art. 112-134: SA risk weights
- CRR Art. 501: SME supporting factor
- CRR Art. 501a: Infrastructure supporting factor
"""

from __future__ import annotations

from datetime import date
from decimal import Decimal

import polars as pl
import pytest
from tests.fixtures.single_exposure import calculate_single_sa_exposure

from rwa_calc.contracts.bundles import CRMAdjustedBundle
from rwa_calc.contracts.config import CalculationConfig
from rwa_calc.engine.sa import SACalculator, create_sa_calculator
from rwa_calc.engine.sa.supporting_factors import (
    SupportingFactorCalculator,
    create_supporting_factor_calculator,
)

# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def sa_calculator() -> SACalculator:
    """Return an SA Calculator instance."""
    return SACalculator()


@pytest.fixture
def crr_config() -> CalculationConfig:
    """Return a CRR configuration."""
    return CalculationConfig.crr(reporting_date=date(2024, 12, 31))


@pytest.fixture
def basel31_config() -> CalculationConfig:
    """Return a Basel 3.1 configuration."""
    return CalculationConfig.basel_3_1(reporting_date=date(2027, 6, 30))


@pytest.fixture
def supporting_factor_calculator() -> SupportingFactorCalculator:
    """Return a SupportingFactorCalculator instance."""
    return SupportingFactorCalculator()


# =============================================================================
# CQS-Based Risk Weight Tests
# =============================================================================


class TestSovereignRiskWeights:
    """Tests for sovereign exposure risk weights."""

    def test_cqs1_zero_risk_weight(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """CQS 1 sovereign (e.g., UK Govt) should get 0% RW."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="CENTRAL_GOVT_CENTRAL_BANK",
            cqs=1,
            config=crr_config,
        )

        assert result["risk_weight"] == pytest.approx(0.0)
        assert result["rwa"] == pytest.approx(0.0)

    def test_cqs2_twenty_percent(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """CQS 2 sovereign should get 20% RW."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="CENTRAL_GOVT_CENTRAL_BANK",
            cqs=2,
            config=crr_config,
        )

        assert result["risk_weight"] == pytest.approx(0.20)
        assert result["rwa"] == pytest.approx(200000)

    def test_unrated_hundred_percent(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """Unrated sovereign should get 100% RW."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="CENTRAL_GOVT_CENTRAL_BANK",
            cqs=None,
            config=crr_config,
        )

        assert result["risk_weight"] == pytest.approx(1.0)
        assert result["rwa"] == pytest.approx(1000000)


class TestArticle114_3DomesticCurrency:
    """Tests for CRR Art. 114(3) — UK domestic currency 0% RW override.

    Art. 114(3) provides that exposures to UK central government and
    central bank denominated in GBP receive 0% RW regardless of CQS.
    """

    def test_uk_sovereign_gbp_cqs2_gets_zero_rw(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """UK sovereign + GBP + CQS 2 → 0% RW (domestic currency override)."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="CENTRAL_GOVT_CENTRAL_BANK",
            cqs=2,
            currency="GBP",
            country_code="GB",
            config=crr_config,
        )

        assert result["risk_weight"] == pytest.approx(0.0)
        assert result["rwa"] == pytest.approx(0.0)

    def test_uk_sovereign_gbp_unrated_gets_zero_rw(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """UK sovereign + GBP + unrated → 0% RW (domestic currency override)."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="CENTRAL_GOVT_CENTRAL_BANK",
            cqs=None,
            currency="GBP",
            country_code="GB",
            config=crr_config,
        )

        assert result["risk_weight"] == pytest.approx(0.0)
        assert result["rwa"] == pytest.approx(0.0)

    def test_uk_sovereign_usd_uses_cqs_based_rw(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """UK sovereign + USD + CQS 2 → 20% RW (foreign currency, no override)."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="CENTRAL_GOVT_CENTRAL_BANK",
            cqs=2,
            currency="USD",
            country_code="GB",
            config=crr_config,
        )

        assert result["risk_weight"] == pytest.approx(0.20)
        assert result["rwa"] == pytest.approx(200000)

    def test_non_uk_sovereign_gbp_uses_cqs_based_rw(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """Non-UK sovereign (US) + GBP + CQS 2 → 20% RW (not UK, no override)."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="CENTRAL_GOVT_CENTRAL_BANK",
            cqs=2,
            currency="GBP",
            country_code="US",
            config=crr_config,
        )

        assert result["risk_weight"] == pytest.approx(0.20)
        assert result["rwa"] == pytest.approx(200000)

    def test_corporate_gb_gbp_no_override(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """Corporate + GB + GBP → CQS-based RW (Art. 114(3) only applies to CGCB)."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="CORPORATE",
            cqs=2,
            currency="GBP",
            country_code="GB",
            config=crr_config,
        )

        assert result["risk_weight"] == pytest.approx(0.50)
        assert result["rwa"] == pytest.approx(500000)

    def test_missing_currency_falls_through_to_cqs(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """Missing currency → falls through to CQS-based RW."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="CENTRAL_GOVT_CENTRAL_BANK",
            cqs=2,
            country_code="GB",
            config=crr_config,
        )

        assert result["risk_weight"] == pytest.approx(0.20)

    def test_uk_sovereign_gbp_cqs1_still_zero(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """UK sovereign + GBP + CQS 1 → 0% RW (both paths agree)."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="CENTRAL_GOVT_CENTRAL_BANK",
            cqs=1,
            currency="GBP",
            country_code="GB",
            config=crr_config,
        )

        assert result["risk_weight"] == pytest.approx(0.0)
        assert result["rwa"] == pytest.approx(0.0)

    def test_uk_sovereign_gbp_basel31_gets_zero_rw(
        self,
        sa_calculator: SACalculator,
        basel31_config: CalculationConfig,
    ) -> None:
        """Art. 114(3) also applies under Basel 3.1 — UK sovereign + GBP → 0%."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="CENTRAL_GOVT_CENTRAL_BANK",
            cqs=3,
            currency="GBP",
            country_code="GB",
            config=basel31_config,
        )

        assert result["risk_weight"] == pytest.approx(0.0)
        assert result["rwa"] == pytest.approx(0.0)


class TestInstitutionRiskWeights:
    """Tests for institution exposure risk weights."""

    def test_cqs1_twenty_percent(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """CQS 1 institution should get 20% RW."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="INSTITUTION",
            cqs=1,
            config=crr_config,
        )

        assert result["risk_weight"] == pytest.approx(0.20)
        assert result["rwa"] == pytest.approx(200000)

    def test_cqs2_fifty_percent(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """CQS 2 institution under CRR gets 50% RW (Art. 120 Table 3)."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="INSTITUTION",
            cqs=2,
            config=crr_config,
        )

        assert result["risk_weight"] == pytest.approx(0.50)
        assert result["rwa"] == pytest.approx(500000)

    def test_unrated_hundred_percent(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """Unrated institution under CRR gets 100% RW (Art. 120(2) Table 3)."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="INSTITUTION",
            cqs=None,
            config=crr_config,
        )

        assert result["risk_weight"] == pytest.approx(1.00)
        assert result["rwa"] == pytest.approx(1_000_000)


class TestCorporateRiskWeights:
    """Tests for corporate exposure risk weights."""

    def test_cqs1_twenty_percent(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """CQS 1 corporate should get 20% RW."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="CORPORATE",
            cqs=1,
            config=crr_config,
        )

        assert result["risk_weight"] == pytest.approx(0.20)
        assert result["rwa"] == pytest.approx(200000)

    def test_cqs2_fifty_percent(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """CQS 2 corporate should get 50% RW."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="CORPORATE",
            cqs=2,
            config=crr_config,
        )

        assert result["risk_weight"] == pytest.approx(0.50)
        assert result["rwa"] == pytest.approx(500000)

    def test_unrated_hundred_percent(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """Unrated corporate should get 100% RW."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="CORPORATE",
            cqs=None,
            config=crr_config,
        )

        assert result["risk_weight"] == pytest.approx(1.0)
        assert result["rwa"] == pytest.approx(1000000)


# =============================================================================
# Retail Risk Weight Tests
# =============================================================================


class TestRetailRiskWeights:
    """Tests for retail exposure risk weights."""

    def test_retail_seventy_five_percent(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """Retail exposures should get 75% RW."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("100000"),
            exposure_class="RETAIL",
            config=crr_config,
        )

        assert result["risk_weight"] == pytest.approx(0.75)
        assert result["rwa"] == pytest.approx(75000)

    def test_retail_ignores_cqs(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """Retail RW should not depend on CQS."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("100000"),
            exposure_class="RETAIL",
            cqs=1,  # Should be ignored
            config=crr_config,
        )

        assert result["risk_weight"] == pytest.approx(0.75)

    def test_non_regulatory_retail_gets_100pct(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """Non-qualifying retail (fails Art. 123 criteria) should get 100% RW.

        Why: Capital understatement — retail exposures above EUR 1m lending group
        threshold should not benefit from 75% preferential treatment.
        """
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1500000"),
            exposure_class="RETAIL",
            qualifies_as_retail=False,
            config=crr_config,
        )

        assert result["risk_weight"] == pytest.approx(1.0)
        assert result["rwa"] == pytest.approx(1500000)


# =============================================================================
# Real Estate Tests
# =============================================================================


class TestResidentialMortgageRiskWeights:
    """Tests for residential mortgage LTV treatment."""

    def test_low_ltv_thirty_five_percent(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """LTV <= 80% should get 35% RW."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("500000"),
            exposure_class="RESIDENTIAL_MORTGAGE",
            ltv=Decimal("0.60"),
            config=crr_config,
        )

        assert result["risk_weight"] == pytest.approx(0.35)
        assert result["rwa"] == pytest.approx(175000)

    def test_at_threshold_thirty_five_percent(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """LTV exactly at 80% should get 35% RW."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("500000"),
            exposure_class="RESIDENTIAL_MORTGAGE",
            ltv=Decimal("0.80"),
            config=crr_config,
        )

        assert result["risk_weight"] == pytest.approx(0.35)

    def test_high_ltv_split_treatment(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """LTV > 80% should get split treatment."""
        # At 100% LTV: 80% at 35%, 20% at 75%
        # Weighted: (0.80 × 0.35) + (0.20 × 0.75) = 0.28 + 0.15 = 0.43
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("500000"),
            exposure_class="RESIDENTIAL_MORTGAGE",
            ltv=Decimal("1.00"),
            config=crr_config,
        )

        expected_rw = 0.80 * 0.35 + 0.20 * 0.75
        assert float(result["risk_weight"]) == pytest.approx(expected_rw, rel=0.01)


class TestCommercialRERiskWeights:
    """Tests for commercial real estate LTV treatment."""

    def test_low_ltv_with_income_cover_fifty_percent(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """CRE LTV <= 50% with income cover should get 50% RW."""
        exposures = pl.DataFrame(
            {
                "exposure_reference": ["CRE001"],
                "ead_final": [600000.0],
                "exposure_class": ["COMMERCIAL_RE"],
                "cqs": [None],
                "ltv": [0.40],
                "is_sme": [False],
                "is_infrastructure": [False],
                "has_income_cover": [True],
            }
        ).lazy()

        bundle = CRMAdjustedBundle(
            exposures=exposures,
            sa_exposures=exposures,
            irb_exposures=pl.LazyFrame(),
        )

        result = sa_calculator.calculate(bundle, crr_config)
        df = result.frame.collect()

        assert df["risk_weight"][0] == pytest.approx(0.50)

    def test_low_ltv_without_income_cover_hundred_percent(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """CRE LTV <= 50% without income cover should get 100% RW."""
        exposures = pl.DataFrame(
            {
                "exposure_reference": ["CRE001"],
                "ead_final": [600000.0],
                "exposure_class": ["COMMERCIAL_RE"],
                "cqs": [None],
                "ltv": [0.40],
                "is_sme": [False],
                "is_infrastructure": [False],
                "has_income_cover": [False],
            }
        ).lazy()

        bundle = CRMAdjustedBundle(
            exposures=exposures,
            sa_exposures=exposures,
            irb_exposures=pl.LazyFrame(),
        )

        result = sa_calculator.calculate(bundle, crr_config)
        df = result.frame.collect()

        assert df["risk_weight"][0] == pytest.approx(1.00)


# =============================================================================
# CCP Risk Weight Tests (CRR Art. 306, CRE54.14-15)
# =============================================================================


class TestCCPRiskWeights:
    """Qualifying CCP exposures get prescribed risk weights, not CQS-based."""

    def test_ccp_proprietary_trade_gets_2pct_rw(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """Proprietary CCP trade exposure should get 2% RW (CRE54.14)."""
        exposures = pl.DataFrame(
            {
                "exposure_reference": ["CCP_PROP"],
                "ead_final": [10_000_000.0],
                "exposure_class": ["INSTITUTION"],
                "cqs": [1],
                "is_sme": [False],
                "is_infrastructure": [False],
                "cp_entity_type": ["ccp"],
                "cp_is_ccp_client_cleared": [False],
            }
        ).lazy()

        bundle = CRMAdjustedBundle(
            exposures=exposures,
            sa_exposures=exposures,
            irb_exposures=pl.LazyFrame(),
        )

        result = sa_calculator.calculate(bundle, crr_config)
        df = result.frame.collect()

        assert df["risk_weight"][0] == pytest.approx(0.02)

    def test_ccp_client_cleared_trade_gets_4pct_rw(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """Client-cleared CCP trade exposure should get 4% RW (CRE54.15)."""
        exposures = pl.DataFrame(
            {
                "exposure_reference": ["CCP_CLIENT"],
                "ead_final": [10_000_000.0],
                "exposure_class": ["INSTITUTION"],
                "cqs": [1],
                "is_sme": [False],
                "is_infrastructure": [False],
                "cp_entity_type": ["ccp"],
                "cp_is_ccp_client_cleared": [True],
            }
        ).lazy()

        bundle = CRMAdjustedBundle(
            exposures=exposures,
            sa_exposures=exposures,
            irb_exposures=pl.LazyFrame(),
        )

        result = sa_calculator.calculate(bundle, crr_config)
        df = result.frame.collect()

        assert df["risk_weight"][0] == pytest.approx(0.04)

    def test_ccp_null_client_cleared_defaults_to_proprietary(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """CCP with null is_ccp_client_cleared should default to 2% (proprietary)."""
        exposures = pl.DataFrame(
            {
                "exposure_reference": ["CCP_NULL"],
                "ead_final": [10_000_000.0],
                "exposure_class": ["INSTITUTION"],
                "cqs": [1],
                "is_sme": [False],
                "is_infrastructure": [False],
                "cp_entity_type": ["ccp"],
                "cp_is_ccp_client_cleared": [None],
            }
        ).lazy()

        bundle = CRMAdjustedBundle(
            exposures=exposures,
            sa_exposures=exposures,
            irb_exposures=pl.LazyFrame(),
        )

        result = sa_calculator.calculate(bundle, crr_config)
        df = result.frame.collect()

        assert df["risk_weight"][0] == pytest.approx(0.02)

    def test_ccp_rwa_calculation(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """CCP RWA should be EAD × 4% for client-cleared trade."""
        exposures = pl.DataFrame(
            {
                "exposure_reference": ["CCP_RWA"],
                "ead_final": [10_000_000.0],
                "exposure_class": ["INSTITUTION"],
                "cqs": [1],
                "is_sme": [False],
                "is_infrastructure": [False],
                "cp_entity_type": ["ccp"],
                "cp_is_ccp_client_cleared": [True],
            }
        ).lazy()

        bundle = CRMAdjustedBundle(
            exposures=exposures,
            sa_exposures=exposures,
            irb_exposures=pl.LazyFrame(),
        )

        result = sa_calculator.calculate(bundle, crr_config)
        df = result.frame.collect()

        # RWA = 10,000,000 × 4% = 400,000
        assert df["rwa_pre_factor"][0] == pytest.approx(400_000.0)

    def test_ccp_overrides_cqs_institution_rw(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """CCP should get 2% RW even though CQS 1 institution would normally get 20%."""
        exposures = pl.DataFrame(
            {
                "exposure_reference": ["CCP_OVERRIDE"],
                "ead_final": [5_000_000.0],
                "exposure_class": ["INSTITUTION"],
                "cqs": [1],
                "is_sme": [False],
                "is_infrastructure": [False],
                "cp_entity_type": ["ccp"],
                "cp_is_ccp_client_cleared": [False],
            }
        ).lazy()

        bundle = CRMAdjustedBundle(
            exposures=exposures,
            sa_exposures=exposures,
            irb_exposures=pl.LazyFrame(),
        )

        result = sa_calculator.calculate(bundle, crr_config)
        df = result.frame.collect()

        # Should be 2% (CCP), NOT 20% (institution CQS 1)
        assert df["risk_weight"][0] == pytest.approx(0.02)
        assert df["risk_weight"][0] != pytest.approx(0.20)


class TestCCPRiskWeightsBasel31:
    """CCP risk weights under Basel 3.1 (same treatment as CRR for QCCPs)."""

    def test_b31_ccp_proprietary_trade_gets_2pct_rw(
        self,
        sa_calculator: SACalculator,
        basel31_config: CalculationConfig,
    ) -> None:
        """Proprietary CCP trade should get 2% RW under Basel 3.1."""
        exposures = pl.DataFrame(
            {
                "exposure_reference": ["CCP_B31_PROP"],
                "ead_final": [10_000_000.0],
                "exposure_class": ["INSTITUTION"],
                "cqs": [1],
                "is_sme": [False],
                "is_infrastructure": [False],
                "cp_entity_type": ["ccp"],
                "cp_is_ccp_client_cleared": [False],
            }
        ).lazy()

        bundle = CRMAdjustedBundle(
            exposures=exposures,
            sa_exposures=exposures,
            irb_exposures=pl.LazyFrame(),
        )

        result = sa_calculator.calculate(bundle, basel31_config)
        df = result.frame.collect()

        assert df["risk_weight"][0] == pytest.approx(0.02)

    def test_b31_ccp_client_cleared_trade_gets_4pct_rw(
        self,
        sa_calculator: SACalculator,
        basel31_config: CalculationConfig,
    ) -> None:
        """Client-cleared CCP trade should get 4% RW under Basel 3.1."""
        exposures = pl.DataFrame(
            {
                "exposure_reference": ["CCP_B31_CLIENT"],
                "ead_final": [10_000_000.0],
                "exposure_class": ["INSTITUTION"],
                "cqs": [1],
                "is_sme": [False],
                "is_infrastructure": [False],
                "cp_entity_type": ["ccp"],
                "cp_is_ccp_client_cleared": [True],
            }
        ).lazy()

        bundle = CRMAdjustedBundle(
            exposures=exposures,
            sa_exposures=exposures,
            irb_exposures=pl.LazyFrame(),
        )

        result = sa_calculator.calculate(bundle, basel31_config)
        df = result.frame.collect()

        assert df["risk_weight"][0] == pytest.approx(0.04)


# =============================================================================
# Supporting Factor Tests
# =============================================================================


class TestSMESupportingFactor:
    """Tests for SME supporting factor."""

    def test_tier1_only_small_exposure(
        self,
        supporting_factor_calculator: SupportingFactorCalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """Exposure <= £2.2m should get full Tier 1 factor (0.7619)."""
        factor = supporting_factor_calculator.calculate_sme_factor(
            total_exposure=Decimal("1000000"),
            config=crr_config,
        )

        assert factor == pytest.approx(Decimal("0.7619"))

    def test_tier2_dominant_large_exposure(
        self,
        supporting_factor_calculator: SupportingFactorCalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """Large exposure should approach Tier 2 factor (0.85)."""
        # £10m exposure: £2.2m at 0.7619, £7.8m at 0.85
        # Effective: (2.2m × 0.7619 + 7.8m × 0.85) / 10m = 0.8306
        factor = supporting_factor_calculator.calculate_sme_factor(
            total_exposure=Decimal("10000000"),
            config=crr_config,
        )

        # Should be between 0.7619 and 0.85
        assert Decimal("0.7619") < factor < Decimal("0.85")

    def test_sme_factor_applies_to_rwa(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """SME factor should reduce RWA."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="CORPORATE",
            cqs=None,  # 100% RW
            is_sme=True,
            config=crr_config,
        )

        # Without factor: RWA = 1m × 100% = 1m
        # With factor: RWA = 1m × 100% × 0.7619 = £761,900
        assert result["supporting_factor"] == pytest.approx(0.7619)
        assert result["rwa"] == pytest.approx(761900)
        assert result["supporting_factor_applied"] is True

    def test_sme_factor_disabled_in_basel31(
        self,
        sa_calculator: SACalculator,
        basel31_config: CalculationConfig,
    ) -> None:
        """SME factor should be 1.0 under Basel 3.1."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="CORPORATE",
            cqs=None,
            is_sme=True,
            config=basel31_config,
        )

        assert result["supporting_factor"] == pytest.approx(1.0)
        assert result["supporting_factor_applied"] is False


class TestInfrastructureSupportingFactor:
    """Tests for infrastructure supporting factor."""

    def test_infrastructure_factor_seventy_five_percent(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """Infrastructure factor should be 0.75."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("10000000"),
            exposure_class="CORPORATE",
            cqs=None,
            is_infrastructure=True,
            config=crr_config,
        )

        assert result["supporting_factor"] == pytest.approx(0.75)
        # RWA = 10m × 100% × 0.75 = £7.5m
        assert result["rwa"] == pytest.approx(7500000)

    def test_infrastructure_factor_disabled_in_basel31(
        self,
        sa_calculator: SACalculator,
        basel31_config: CalculationConfig,
    ) -> None:
        """Infrastructure factor should be 1.0 under Basel 3.1."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("10000000"),
            exposure_class="CORPORATE",
            cqs=None,
            is_infrastructure=True,
            config=basel31_config,
        )

        assert result["supporting_factor"] == pytest.approx(1.0)


class TestSupportingFactorPriority:
    """Tests for supporting factor selection when both apply."""

    def test_lower_factor_wins(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """When both SME and infra apply, lower factor should win."""
        # SME factor for small exposure: 0.7619
        # Infrastructure factor: 0.75
        # Should use 0.75 (infrastructure is lower for large exposures)

        # Large exposure where SME factor > infra factor
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("100000000"),  # £100m - SME factor close to 0.85
            exposure_class="CORPORATE",
            cqs=None,
            is_sme=True,
            is_infrastructure=True,
            config=crr_config,
        )

        # At £100m, SME factor is close to 0.85, infra is 0.75
        # Should use 0.75
        assert result["supporting_factor"] == pytest.approx(0.75)


class TestSMESupportingFactorCounterpartyAggregation:
    """Tests for SME factor counterparty-level aggregation (CRR2 Art. 501).

    The EUR 2.5m threshold for the tiered SME factor is applied at the
    counterparty level, not per-exposure. All exposures to the same
    counterparty are aggregated before determining the blended factor.
    """

    def test_multiple_exposures_same_counterparty_aggregated(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """Multiple exposures to same counterparty should use aggregated EAD for factor."""
        # Two exposures of £1.5m each to same counterparty = £3m total
        # Threshold is ~£2.183m (EUR 2.5m * 0.8732)
        # Factor should be blended, not pure Tier 1 (0.7619)
        exposures = pl.DataFrame(
            {
                "exposure_reference": ["EXP001", "EXP002"],
                "counterparty_reference": ["CP001", "CP001"],  # Same counterparty
                "ead_final": [1500000.0, 1500000.0],  # £1.5m each
                "exposure_class": ["CORPORATE", "CORPORATE"],
                "cqs": [None, None],
                "is_sme": [True, True],
                "is_infrastructure": [False, False],
            }
        ).lazy()

        bundle = CRMAdjustedBundle(
            exposures=exposures,
            sa_exposures=exposures,
            irb_exposures=pl.LazyFrame(),
        )

        result = sa_calculator.calculate(bundle, crr_config)
        df = result.frame.collect()

        # Both exposures should have the same blended factor
        # Total = £3m, threshold = £2,183,000
        # tier1 = £2,183,000 * 0.7619 = £1,663,277.70
        # tier2 = £817,000 * 0.85 = £694,450.00
        # weighted_factor = (1,663,277.70 + 694,450) / 3,000,000 = ~0.7859
        exp1_factor = df.filter(pl.col("exposure_reference") == "EXP001")["supporting_factor"][0]
        exp2_factor = df.filter(pl.col("exposure_reference") == "EXP002")["supporting_factor"][0]

        # Both should have same factor (blended based on total counterparty exposure)
        assert exp1_factor == pytest.approx(exp2_factor, rel=0.001)

        # Factor should be between 0.7619 and 0.85 (blended)
        assert 0.7619 < exp1_factor < 0.85

    def test_different_counterparties_use_individual_totals(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """Exposures to different counterparties should use their own totals."""
        # CP001: £1m (small, gets pure 0.7619)
        # CP002: £5m (larger, gets blended factor closer to 0.85)
        exposures = pl.DataFrame(
            {
                "exposure_reference": ["EXP001", "EXP002"],
                "counterparty_reference": ["CP001", "CP002"],  # Different counterparties
                "ead_final": [1000000.0, 5000000.0],
                "exposure_class": ["CORPORATE", "CORPORATE"],
                "cqs": [None, None],
                "is_sme": [True, True],
                "is_infrastructure": [False, False],
            }
        ).lazy()

        bundle = CRMAdjustedBundle(
            exposures=exposures,
            sa_exposures=exposures,
            irb_exposures=pl.LazyFrame(),
        )

        result = sa_calculator.calculate(bundle, crr_config)
        df = result.frame.collect()

        exp1_factor = df.filter(pl.col("exposure_reference") == "EXP001")["supporting_factor"][0]
        exp2_factor = df.filter(pl.col("exposure_reference") == "EXP002")["supporting_factor"][0]

        # CP001 (£1m) should get pure Tier 1 factor
        assert exp1_factor == pytest.approx(0.7619, rel=0.001)

        # CP002 (£5m) should get blended factor (closer to 0.85)
        assert 0.7619 < exp2_factor < 0.85

    def test_null_counterparty_falls_back_to_individual_ead(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """Exposures with null counterparty should use individual EAD."""
        exposures = pl.DataFrame(
            {
                "exposure_reference": ["EXP001", "EXP002"],
                "counterparty_reference": [None, None],  # No counterparty reference
                "ead_final": [1000000.0, 5000000.0],
                "exposure_class": ["CORPORATE", "CORPORATE"],
                "cqs": [None, None],
                "is_sme": [True, True],
                "is_infrastructure": [False, False],
            }
        ).lazy()

        bundle = CRMAdjustedBundle(
            exposures=exposures,
            sa_exposures=exposures,
            irb_exposures=pl.LazyFrame(),
        )

        result = sa_calculator.calculate(bundle, crr_config)
        df = result.frame.collect()

        exp1_factor = df.filter(pl.col("exposure_reference") == "EXP001")["supporting_factor"][0]
        exp2_factor = df.filter(pl.col("exposure_reference") == "EXP002")["supporting_factor"][0]

        # Both should use individual EAD for factor calculation
        # EXP001 (£1m) - small, gets pure Tier 1
        assert exp1_factor == pytest.approx(0.7619, rel=0.001)

        # EXP002 (£5m) - gets blended factor
        assert 0.7619 < exp2_factor < 0.85


# =============================================================================
# Bundle Processing Tests
# =============================================================================


class TestSACalculatorBundleProcessing:
    """Tests for processing CRMAdjustedBundle."""

    def test_calculate_returns_lazyframe_result(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """calculate() should return LazyFrameResult."""
        exposures = pl.DataFrame(
            {
                "exposure_reference": ["EXP001"],
                "ead_final": [1000000.0],
                "exposure_class": ["CORPORATE"],
                "cqs": [None],
                "is_sme": [False],
                "is_infrastructure": [False],
            }
        ).lazy()

        bundle = CRMAdjustedBundle(
            exposures=exposures,
            sa_exposures=exposures,
            irb_exposures=pl.LazyFrame(),
        )

        result = sa_calculator.calculate(bundle, crr_config)

        assert hasattr(result, "frame")
        assert hasattr(result, "errors")

    def test_get_sa_result_bundle_returns_bundle(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """get_sa_result_bundle() should return SAResultBundle."""
        exposures = pl.DataFrame(
            {
                "exposure_reference": ["EXP001"],
                "ead_final": [1000000.0],
                "exposure_class": ["CORPORATE"],
                "cqs": [None],
                "is_sme": [False],
                "is_infrastructure": [False],
            }
        ).lazy()

        bundle = CRMAdjustedBundle(
            exposures=exposures,
            sa_exposures=exposures,
            irb_exposures=pl.LazyFrame(),
        )

        result = sa_calculator.get_sa_result_bundle(bundle, crr_config)

        assert hasattr(result, "results")
        assert hasattr(result, "calculation_audit")
        assert hasattr(result, "errors")

    def test_multiple_exposures_processed(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """Multiple exposures should all be processed."""
        exposures = pl.DataFrame(
            {
                "exposure_reference": ["EXP001", "EXP002", "EXP003"],
                "ead_final": [1000000.0, 500000.0, 100000.0],
                "exposure_class": ["CENTRAL_GOVT_CENTRAL_BANK", "INSTITUTION", "RETAIL"],
                "cqs": [1, 2, None],
                "is_sme": [False, False, False],
                "is_infrastructure": [False, False, False],
            }
        ).lazy()

        bundle = CRMAdjustedBundle(
            exposures=exposures,
            sa_exposures=exposures,
            irb_exposures=pl.LazyFrame(),
        )

        result = sa_calculator.calculate(bundle, crr_config)
        df = result.frame.collect()

        assert len(df) == 3
        # Sovereign CQS1: 0%
        assert df.filter(pl.col("exposure_reference") == "EXP001")["risk_weight"][
            0
        ] == pytest.approx(0.0)
        # Institution CQS2: 50% (CRR Art. 120 Table 3)
        assert df.filter(pl.col("exposure_reference") == "EXP002")["risk_weight"][
            0
        ] == pytest.approx(0.50)
        # Retail: 75%
        assert df.filter(pl.col("exposure_reference") == "EXP003")["risk_weight"][
            0
        ] == pytest.approx(0.75)


# =============================================================================
# Factory Function Tests
# =============================================================================


class TestSAFactoryFunctions:
    """Tests for SA factory functions."""

    def test_create_sa_calculator(self) -> None:
        """Factory should create SACalculator."""
        calculator = create_sa_calculator()
        assert isinstance(calculator, SACalculator)

    def test_create_supporting_factor_calculator(self) -> None:
        """Factory should create SupportingFactorCalculator."""
        calculator = create_supporting_factor_calculator()
        assert isinstance(calculator, SupportingFactorCalculator)


# =============================================================================
# Audit Trail Tests
# =============================================================================


class TestSAAuditTrail:
    """Tests for SA calculation audit trail."""

    def test_audit_contains_calculation_details(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """Audit should contain calculation breakdown."""
        exposures = pl.DataFrame(
            {
                "exposure_reference": ["EXP001"],
                "counterparty_reference": ["CP001"],
                "ead_final": [1000000.0],
                "exposure_class": ["CORPORATE"],
                "cqs": [2],
                "is_sme": [True],
                "is_infrastructure": [False],
            }
        ).lazy()

        bundle = CRMAdjustedBundle(
            exposures=exposures,
            sa_exposures=exposures,
            irb_exposures=pl.LazyFrame(),
        )

        result = sa_calculator.get_sa_result_bundle(bundle, crr_config)
        audit = result.calculation_audit

        if audit is not None:
            audit_df = audit.collect()
            assert "sa_calculation" in audit_df.columns
            calc_str = audit_df["sa_calculation"][0]
            assert "EAD=" in calc_str
            assert "RW=" in calc_str
            assert "SF=" in calc_str
            assert "RWA=" in calc_str


# =============================================================================
# Defaulted Exposure Risk Weight Tests (CRR Art. 127 / CRE20.88-90)
# =============================================================================


class TestDefaultedExposureRiskWeights:
    """Tests for defaulted exposure risk weight treatment.

    CRR Art. 127: Defaulted exposures receive 100% RW if specific provisions
    >= 20% of unsecured EAD, otherwise 150% RW.

    Basel 3.1 CRE20.88-90: 100% RW if provisions >= 50%, otherwise 150%.
    """

    def test_crr_defaulted_high_provision_100pct_rw(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """CRR Art. 127: provision >= 20% of unsecured EAD -> 100% RW."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="CORPORATE",
            cqs=None,
            is_defaulted=True,
            # provision_allocated=250k, provision_deducted=0
            # ratio = 250k / (1m + 0) = 25% >= 20%
            provision_allocated=Decimal("250000"),
            provision_deducted=Decimal("0"),
            config=crr_config,
        )

        assert result["risk_weight"] == pytest.approx(1.0)

    def test_crr_defaulted_low_provision_150pct_rw(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """CRR Art. 127: provision < 20% of unsecured EAD -> 150% RW."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="CORPORATE",
            cqs=None,
            is_defaulted=True,
            # provision_allocated=50k, provision_deducted=0
            # ratio = 50k / (1m + 0) = 5% < 20%
            provision_allocated=Decimal("50000"),
            provision_deducted=Decimal("0"),
            config=crr_config,
        )

        assert result["risk_weight"] == pytest.approx(1.50)

    def test_crr_defaulted_zero_provision_150pct_rw(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """CRR Art. 127: no provisions at all -> 150% RW."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="CORPORATE",
            cqs=None,
            is_defaulted=True,
            config=crr_config,
        )

        assert result["risk_weight"] == pytest.approx(1.50)

    def test_crr_defaulted_mortgage_gets_defaulted_rw(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """Defaulted mortgage should get defaulted treatment, not LTV-based RW."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("500000"),
            exposure_class="RETAIL_MORTGAGE",
            cqs=None,
            is_defaulted=True,
            config=crr_config,
        )

        # Should be 150% (no provisions), NOT the 35% LTV-based weight
        assert result["risk_weight"] == pytest.approx(1.50)

    def test_crr_non_defaulted_corporate_unchanged(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """Non-defaulted corporate should still get normal CQS-based RW."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="CORPORATE",
            cqs=2,
            config=crr_config,
        )

        # CQS 2 corporate = 50%
        assert result["risk_weight"] == pytest.approx(0.50)

    def test_b31_defaulted_high_provision_100pct_rw(
        self,
        sa_calculator: SACalculator,
        basel31_config: CalculationConfig,
    ) -> None:
        """Art. 127: provision >= 20% of EAD -> 100% RW."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="CORPORATE",
            cqs=None,
            is_defaulted=True,
            # provision_allocated=600k, provision_deducted=0
            # ratio = 600k / 1m = 60% >= 20%
            provision_allocated=Decimal("600000"),
            provision_deducted=Decimal("0"),
            config=basel31_config,
        )

        assert result["risk_weight"] == pytest.approx(1.0)

    def test_b31_defaulted_low_provision_150pct_rw(
        self,
        sa_calculator: SACalculator,
        basel31_config: CalculationConfig,
    ) -> None:
        """Art. 127: provision < 20% of EAD -> 150% RW."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="CORPORATE",
            cqs=None,
            is_defaulted=True,
            # provision_allocated=100k, provision_deducted=0
            # ratio = 100k / (1m + 0) = 10% < 50%
            provision_allocated=Decimal("100000"),
            provision_deducted=Decimal("0"),
            config=basel31_config,
        )

        assert result["risk_weight"] == pytest.approx(1.50)

    def test_crr_defaulted_retail_non_mortgage_low_provision_150pct_rw(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """CRR defaulted regulatory retail (non-mortgage), provisions < 20% → 150%.

        Regression guard for the user-reported bug where defaulted retail
        exposures returned the 75% base RW instead of Art. 127(1)(a) 150%.
        """
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("100000"),
            exposure_class="RETAIL_OTHER",
            cqs=None,
            is_defaulted=True,
            provision_allocated=Decimal("0"),
            provision_deducted=Decimal("0"),
            config=crr_config,
        )

        assert result["risk_weight"] == pytest.approx(1.50)

    def test_crr_defaulted_retail_non_mortgage_high_provision_100pct_rw(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """CRR defaulted regulatory retail (non-mortgage), provisions >= 20% → 100%."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("100000"),
            exposure_class="RETAIL_OTHER",
            cqs=None,
            is_defaulted=True,
            # 25k >= 20% × 100k = 20k → 100%
            provision_allocated=Decimal("25000"),
            provision_deducted=Decimal("0"),
            config=crr_config,
        )

        assert result["risk_weight"] == pytest.approx(1.00)

    def test_b31_defaulted_retail_non_mortgage_low_provision_150pct_rw(
        self,
        sa_calculator: SACalculator,
        basel31_config: CalculationConfig,
    ) -> None:
        """Basel 3.1 defaulted retail (non-mortgage), provisions < 20% → 150%."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("100000"),
            exposure_class="RETAIL_OTHER",
            cqs=None,
            is_defaulted=True,
            provision_allocated=Decimal("0"),
            provision_deducted=Decimal("0"),
            config=basel31_config,
        )

        assert result["risk_weight"] == pytest.approx(1.50)

    def test_b31_defaulted_retail_non_mortgage_high_provision_100pct_rw(
        self,
        sa_calculator: SACalculator,
        basel31_config: CalculationConfig,
    ) -> None:
        """Basel 3.1 defaulted retail (non-mortgage), provisions >= 20% → 100%."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("100000"),
            exposure_class="RETAIL_OTHER",
            cqs=None,
            is_defaulted=True,
            provision_allocated=Decimal("20000"),
            provision_deducted=Decimal("0"),
            config=basel31_config,
        )

        assert result["risk_weight"] == pytest.approx(1.00)


class TestDefaultedSMEExclusion:
    """Tests for SME supporting factor exclusion of defaulted exposures.

    CRR Art. 501: SME supporting factor applies only to non-defaulted exposures.
    """

    def test_sme_factor_excluded_for_defaulted(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """Defaulted SME should NOT receive supporting factor."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="CORPORATE",
            cqs=None,
            is_sme=True,
            is_defaulted=True,
            provision_allocated=Decimal("250000"),
            provision_deducted=Decimal("0"),
            config=crr_config,
        )

        assert result["supporting_factor"] == pytest.approx(1.0)
        assert result["supporting_factor_applied"] is False

    def test_sme_factor_applies_to_performing_sme(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """Non-defaulted SME should still receive supporting factor."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="CORPORATE",
            cqs=None,
            is_sme=True,
            is_defaulted=False,
            config=crr_config,
        )

        assert result["supporting_factor"] < Decimal("1.0")
        assert result["supporting_factor_applied"] is True


# =============================================================================
# Art. 114(4) — EU Domestic Currency 0% RW
# =============================================================================


class TestArticle114_4EUDomesticCurrency:
    """Tests for CRR Art. 114(4) — EU domestic currency 0% RW override.

    Art. 114(4) provides that exposures to EU central government and
    central bank denominated in the member state's domestic currency
    receive 0% RW regardless of CQS.
    """

    def test_eu_eurozone_sovereign_eur_cqs2_gets_zero_rw(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """German sovereign + EUR + CQS 2 → 0% RW (EU domestic currency override)."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="CENTRAL_GOVT_CENTRAL_BANK",
            cqs=2,
            currency="EUR",
            country_code="DE",
            config=crr_config,
        )

        assert result["risk_weight"] == pytest.approx(0.0)
        assert result["rwa"] == pytest.approx(0.0)

    def test_eu_eurozone_sovereign_eur_unrated_gets_zero_rw(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """French sovereign + EUR + unrated → 0% RW (EU domestic currency override)."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="CENTRAL_GOVT_CENTRAL_BANK",
            cqs=None,
            currency="EUR",
            country_code="FR",
            config=crr_config,
        )

        assert result["risk_weight"] == pytest.approx(0.0)
        assert result["rwa"] == pytest.approx(0.0)

    def test_eu_non_euro_sovereign_domestic_currency_gets_zero_rw(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """Polish sovereign + PLN + CQS 3 → 0% RW (non-euro EU domestic currency)."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="CENTRAL_GOVT_CENTRAL_BANK",
            cqs=3,
            currency="PLN",
            country_code="PL",
            config=crr_config,
        )

        assert result["risk_weight"] == pytest.approx(0.0)
        assert result["rwa"] == pytest.approx(0.0)

    def test_eu_non_euro_sovereign_eur_uses_cqs_based_rw(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """Polish sovereign + EUR → CQS-based RW (EUR is not Poland's domestic currency)."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="CENTRAL_GOVT_CENTRAL_BANK",
            cqs=3,
            currency="EUR",
            country_code="PL",
            config=crr_config,
        )

        assert result["risk_weight"] == pytest.approx(0.50)

    def test_eu_sovereign_usd_uses_cqs_based_rw(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """German sovereign + USD + CQS 2 → 20% RW (foreign currency, no override)."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="CENTRAL_GOVT_CENTRAL_BANK",
            cqs=2,
            currency="USD",
            country_code="DE",
            config=crr_config,
        )

        assert result["risk_weight"] == pytest.approx(0.20)
        assert result["rwa"] == pytest.approx(200000)

    def test_non_eu_sovereign_eur_uses_cqs_based_rw(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """Non-EU sovereign (US) + EUR → CQS-based RW (not EU, no override)."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="CENTRAL_GOVT_CENTRAL_BANK",
            cqs=2,
            currency="EUR",
            country_code="US",
            config=crr_config,
        )

        assert result["risk_weight"] == pytest.approx(0.20)

    def test_eu_sovereign_eur_basel31_gets_zero_rw(
        self,
        sa_calculator: SACalculator,
        basel31_config: CalculationConfig,
    ) -> None:
        """Art. 114(4) also applies under Basel 3.1 — EU sovereign + EUR → 0%."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="CENTRAL_GOVT_CENTRAL_BANK",
            cqs=3,
            currency="EUR",
            country_code="DE",
            config=basel31_config,
        )

        assert result["risk_weight"] == pytest.approx(0.0)
        assert result["rwa"] == pytest.approx(0.0)

    def test_eu_corporate_eur_no_override(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """Corporate + DE + EUR → CQS-based RW (Art. 114(4) only applies to CGCB)."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="CORPORATE",
            cqs=2,
            currency="EUR",
            country_code="DE",
            config=crr_config,
        )

        assert result["risk_weight"] == pytest.approx(0.50)

    def test_eu_sovereign_cqs6_domestic_gets_zero_rw(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """Even CQS 6 (150%) gets overridden to 0% for EU domestic sovereign."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="CENTRAL_GOVT_CENTRAL_BANK",
            cqs=6,
            currency="EUR",
            country_code="IT",
            config=crr_config,
        )

        assert result["risk_weight"] == pytest.approx(0.0)
        assert result["rwa"] == pytest.approx(0.0)

    def test_sweden_sek_gets_zero_rw(
        self,
        sa_calculator: SACalculator,
        crr_config: CalculationConfig,
    ) -> None:
        """Swedish sovereign + SEK → 0% RW (non-euro EU domestic currency)."""
        result = calculate_single_sa_exposure(
            sa_calculator,
            ead=Decimal("1000000"),
            exposure_class="CENTRAL_GOVT_CENTRAL_BANK",
            cqs=2,
            currency="SEK",
            country_code="SE",
            config=crr_config,
        )

        assert result["risk_weight"] == pytest.approx(0.0)
        assert result["rwa"] == pytest.approx(0.0)
