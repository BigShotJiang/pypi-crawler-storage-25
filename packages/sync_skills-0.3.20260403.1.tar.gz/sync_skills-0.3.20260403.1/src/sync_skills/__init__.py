"""sync-skills: AI coding agent skills 同步工具"""

__version__ = "0.3.20260403.1"
