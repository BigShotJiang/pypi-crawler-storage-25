﻿"""
xml_parser.py — parses Squish native XML and JUnit XML result files.
No third-party dependencies — uses xml.etree.ElementTree from stdlib.
"""
from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from typing import Literal


StatusType = Literal["passed", "failed", "blocked", "untested"]


@dataclass
class ParsedTest:
    full_name: str
    title: str
    normalized_title: str
    suite_name: str
    status: StatusType
    error_message: str | None = field(default=None)


def normalize_title(title: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9\s]", " ", title, flags=re.I)).strip().lower()


# ---------------------------------------------------------------------------
# JUnit XML
# ---------------------------------------------------------------------------

def parse_junit_xml(content: str) -> list[ParsedTest]:
    """
    Supports both <testsuites><testsuite>... and bare <testsuite>... roots.
    Handles <failure>, <error>, and <skipped> child elements.
    """
    tests: list[ParsedTest] = []
    root = ET.fromstring(content)

    # collect all <testsuite> elements wherever they are
    suites = root.findall(".//testsuite") if root.tag != "testsuite" else [root]
    if root.tag == "testsuite":
        suites = [root]
    else:
        suites = root.findall(".//testsuite")

    for suite in suites:
        suite_name = suite.get("name") or "Default"
        for case in suite.findall("testcase"):
            title = case.get("name") or ""
            if not title:
                continue
            full_name = f"{suite_name}.{title}"
            status: StatusType = "passed"
            error_message: str | None = None

            failure = case.find("failure") or case.find("error")
            skipped = case.find("skipped")

            if failure is not None:
                status = "failed"
                error_message = (
                    failure.get("message")
                    or (failure.text or "").strip()
                )[:2000] or None
            elif skipped is not None:
                status = "blocked"

            tests.append(
                ParsedTest(
                    full_name=full_name,
                    title=title,
                    normalized_title=normalize_title(title),
                    suite_name=suite_name,
                    status=status,
                    error_message=error_message,
                )
            )
    return tests


# ---------------------------------------------------------------------------
# Squish native XML
# ---------------------------------------------------------------------------

def parse_squish_native_xml(content: str) -> list[ParsedTest]:
    """
    Squish native XML structure:
      <SquishReport>
        <test name="tst_foo">
          <prolog title="tst_foo"/>
          <function name="main">
            <message type="FAIL" text="..."/>
            <verification type="passes|fails"/>
          </function>
        </test>
      </SquishReport>

    Each <test> becomes a suite; each <function> becomes a test case.
    """
    tests: list[ParsedTest] = []
    root = ET.fromstring(content)

    for test_elem in root.findall(".//test"):
        suite_name = test_elem.get("name") or "Default"
        functions = test_elem.findall("function")

        if not functions:
            # treat the whole <test> as one case
            fail_msg = _squish_fail_message(test_elem)
            tests.append(
                ParsedTest(
                    full_name=suite_name,
                    title=suite_name,
                    normalized_title=normalize_title(suite_name),
                    suite_name=suite_name,
                    status="failed" if fail_msg is not None else "passed",
                    error_message=fail_msg,
                )
            )
            continue

        for fn in functions:
            title = fn.get("name") or suite_name
            full_name = f"{suite_name}.{title}"
            fail_msg = _squish_fail_message(fn)
            skip = any(
                m.get("type", "").upper() == "SKIP"
                for m in fn.findall("message")
            )
            status: StatusType = "passed"
            if fail_msg is not None:
                status = "failed"
            elif skip:
                status = "blocked"

            tests.append(
                ParsedTest(
                    full_name=full_name,
                    title=title,
                    normalized_title=normalize_title(title),
                    suite_name=suite_name,
                    status=status,
                    error_message=fail_msg,
                )
            )

    return tests


def _squish_fail_message(elem: ET.Element) -> str | None:
    for msg in elem.findall(".//message"):
        if (msg.get("type") or "").upper() == "FAIL":
            text = msg.get("text") or (msg.text or "").strip()
            return text[:2000] if text else None
    return None


# ---------------------------------------------------------------------------
# Auto-detect and parse
# ---------------------------------------------------------------------------

def parse_results_file(file_path: str) -> list[ParsedTest]:
    with open(file_path, encoding="utf-8") as f:
        content = f.read()

    # Detect by root element
    stripped = content.lstrip()
    if re.search(r"<SquishReport", stripped, re.I):
        return parse_squish_native_xml(content)
    if re.search(r"<testsuites|<testsuite", stripped, re.I):
        return parse_junit_xml(content)

    raise ValueError(
        f"[squish-qatouch] Unrecognised result format "
        f"(expected Squish XML or JUnit XML): {file_path}"
    )