﻿"""squish_qatouch — QA Touch reporter for Squish (Froglogic / Qt)."""
from .reporter import SquishQATouchReporter
from .xml_parser import ParsedTest, parse_results_file

__all__ = ["SquishQATouchReporter", "ParsedTest", "parse_results_file"]
__version__ = "1.0.0"