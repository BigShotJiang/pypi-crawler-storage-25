﻿"""
reporter.py — main SquishQATouchReporter class.
"""
from __future__ import annotations

import json
import urllib.parse
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from .qatouch_client import QATouchClient
from .xml_parser import ParsedTest, normalize_title, parse_results_file


# ---------------------------------------------------------------------------
# Helper extractors (tolerant of varying QA Touch API response shapes)
# ---------------------------------------------------------------------------

def _extract(item: dict, *keys: str) -> str | None:
    for k in keys:
        v = item.get(k)
        if v:
            return str(v)
    return None

def _case_key(item: dict) -> str | None:
    return _extract(item, "case_key", "caseKey", "key", "api_key", "apiKey", "id")

def _run_key(item: dict) -> str | None:
    return _extract(item, "testrun_id", "key", "testRunKey", "testrunkey", "test_run")

def _milestone_key(item: dict) -> str | None:
    return _extract(item, "milestone_key", "key", "milestoneKey", "id")

def _module_key(item: dict) -> str | None:
    return _extract(item, "section_key", "module_key", "key", "sectionKey", "api_key", "apiKey", "id")

def _module_name(item: dict) -> str | None:
    return _extract(item, "section_name", "module_name", "name", "title", "sectionName")

def _status_to_id(status: str) -> int:
    return {"passed": 1, "failed": 5, "blocked": 3}.get(status, 2)

def _build_steps_template(title: str) -> str:
    steps = {
        "0": {
            "steps": f"Launch the Squish AUT and navigate to the feature for: {title}.",
            "expected_result": "The AUT starts and reaches the expected initial state.",
        },
        "1": {
            "steps": f"Execute the Squish test case: {title}.",
            "expected_result": "All script actions and verification points run without errors.",
        },
        "2": {
            "steps": f"Verify all verification points for: {title}.",
            "expected_result": "All verification points pass and no failures are recorded.",
        },
    }
    return urllib.parse.quote(json.dumps(steps))


# ---------------------------------------------------------------------------
# Reporter
# ---------------------------------------------------------------------------

class SquishQATouchReporter:
    """
    Parses a Squish result file (native XML or JUnit XML) and uploads
    results to QA Touch, auto-creating modules, test cases, milestones,
    and test runs as needed.

    Usage::

        from squish_qatouch import SquishQATouchReporter

        reporter = SquishQATouchReporter(
            domain="mycompany",
            api_token="YOUR_TOKEN",
            project_key="PROJ",
            assign_to="user-key",
            results_file="./results/squish.xml",
            milestone_name="Sprint 12",
        )
        reporter.run()
    """

    def __init__(
        self,
        *,
        domain: str,
        api_token: str,
        project_key: str,
        assign_to: str,
        results_file: str,
        testsuite_id: str | None = None,
        milestone_name: str = "Squish Automation",
        milestone_key: str | None = None,
        create_cases: bool = True,
        tag: str = "squish",
    ) -> None:
        self.domain = domain
        self.api_token = api_token
        self.project_key = project_key
        self.assign_to = assign_to
        self.results_file = results_file
        self.testsuite_id = testsuite_id
        self.milestone_name = milestone_name
        self.milestone_key = milestone_key
        self.create_cases = create_cases
        self.tag = tag
        self._client = QATouchClient(domain, api_token, project_key)

    # ------------------------------------------------------------------
    # Public entry point
    # ------------------------------------------------------------------

    def run(self) -> None:
        tests = parse_results_file(self.results_file)
        if not tests:
            print("[squish-qatouch] No test cases found in results file.")
            return

        # Group by suite name
        suite_map: dict[str, list[ParsedTest]] = {}
        for t in tests:
            suite_map.setdefault(t.suite_name, []).append(t)

        # Resolve QA Touch modules
        module_key_by_suite = self._resolve_modules(list(suite_map.keys()))

        # Build case map  (normalised title -> case key)
        case_map: dict[str, str] = {}
        for mk in set(module_key_by_suite.values()):
            self._refresh_case_map(mk, case_map)

        # Auto-create missing test cases
        if self.create_cases:
            for suite_name, suite_tests in suite_map.items():
                mk = module_key_by_suite.get(suite_name)
                if not mk:
                    continue
                for test in suite_tests:
                    if test.normalized_title in case_map:
                        continue
                    self._client.create_test_case(
                        mk,
                        test.title,
                        f"Automated Squish scenario: {test.title}",
                        test.full_name,
                        "The Squish AUT is running and accessible.",
                        _build_steps_template(test.title),
                    )
                    self._refresh_case_map(mk, case_map)

        # Resolve / create milestone
        mk_milestone = self._resolve_milestone()
        if not mk_milestone:
            raise RuntimeError("[squish-qatouch] Unable to resolve milestone key.")

        # Bucket results
        bulk: list[dict] = []
        detailed: list[tuple[str, ParsedTest]] = []
        case_keys: list[str] = []

        for test in tests:
            ck = case_map.get(test.normalized_title)
            if not ck:
                print(f"[squish-qatouch] Skipping unmapped test: {test.title}")
                continue
            case_keys.append(ck)
            if test.status == "failed" and test.error_message:
                detailed.append((ck, test))
            else:
                bulk.append({"case": ck, "status": _status_to_id(test.status)})

        if not case_keys:
            print("[squish-qatouch] No mapped test cases to upload.")
            return

        # Create test run
        run_title = f"Squish Run {datetime.now(timezone.utc).isoformat()}"
        run_payload = self._client.create_test_run(
            mk_milestone,
            run_title,
            self.assign_to,
            list(dict.fromkeys(case_keys)),   # deduplicate, preserve order
            self.tag,
        )
        test_run_key = _run_key(run_payload)
        if not test_run_key:
            raise RuntimeError("[squish-qatouch] Test run creation returned no key.")

        # Upload detailed (failed + message) results
        for ck, test in detailed:
            try:
                self._client.add_result_with_comment(
                    test_run_key, ck, _status_to_id(test.status), test.error_message
                )
            except Exception as exc:
                print(f"[squish-qatouch] Detailed upload failed for '{test.title}': {exc}")
                bulk.append({"case": ck, "status": _status_to_id(test.status)})

        # Bulk upload remaining
        if bulk:
            try:
                resp = self._client.update_results(test_run_key, bulk)
                if isinstance(resp, dict) and resp.get("error"):
                    raise RuntimeError(resp["error"])
            except Exception:
                for item in bulk:
                    try:
                        self._client.add_result_with_comment(
                            test_run_key, item["case"], item["status"]
                        )
                    except Exception as exc:
                        print(f"[squish-qatouch] Individual upload failed for {item['case']}: {exc}")

        print(f"[squish-qatouch] Uploaded {len(case_keys)} result(s) to run {test_run_key}.")

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _refresh_case_map(self, module_key: str, case_map: dict[str, str]) -> None:
        for item in self._client.get_test_cases(module_key):
            title = (item.get("title") or item.get("case_title") or "").strip()
            k = _case_key(item)
            if title and k:
                case_map[normalize_title(title)] = k

    def _resolve_milestone(self) -> str | None:
        if self.milestone_key:
            return self.milestone_key
        name = self.milestone_name
        milestones = self._client.get_milestones()
        found = next(
            (
                m for m in milestones
                if (m.get("milestone_name") or m.get("name") or m.get("title") or m.get("milestone") or "") == name
            ),
            None,
        )
        if found:
            return _milestone_key(found)
        self._client.create_milestone(name)
        milestones = self._client.get_milestones()
        created = next(
            (
                m for m in milestones
                if (m.get("milestone_name") or m.get("name") or m.get("title") or m.get("milestone") or "") == name
            ),
            None,
        )
        return _milestone_key(created) if created else None

    def _resolve_modules(self, suite_names: list[str]) -> dict[str, str]:
        module_map: dict[str, str] = {}

        if self.testsuite_id:
            for name in suite_names:
                module_map[name] = self.testsuite_id
            return module_map

        existing = self._client.get_modules()
        by_name: dict[str, str] = {}
        for m in existing:
            n = _module_name(m)
            k = _module_key(m)
            if n and k:
                by_name[n.lower().strip()] = k

        for suite_name in suite_names:
            norm = suite_name.lower().strip()
            if norm in by_name:
                module_map[suite_name] = by_name[norm]
                continue
            # Create the module
            ck: str | None = None
            try:
                created = self._client.create_module(suite_name)
                ck = _module_key(created)
            except Exception as exc:
                print(f"[squish-qatouch] createModule error for '{suite_name}': {exc}")
            if not ck:
                # Re-fetch and retry lookup
                existing = self._client.get_modules()
                for m in existing:
                    n = _module_name(m)
                    k = _module_key(m)
                    if n and k:
                        by_name[n.lower().strip()] = k
                ck = by_name.get(norm)
            if ck:
                module_map[suite_name] = ck
                by_name[norm] = ck
            else:
                print(f"[squish-qatouch] Failed to resolve module: {suite_name}")

        return module_map