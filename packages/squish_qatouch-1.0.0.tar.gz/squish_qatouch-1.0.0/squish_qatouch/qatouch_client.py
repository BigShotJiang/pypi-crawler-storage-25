﻿"""
qatouch_client.py — thin wrapper around the QA Touch REST API v1.
Uses only the Python standard library (urllib, json, ssl).
"""
from __future__ import annotations

import json
import os
import ssl
import urllib.parse
import urllib.request
from typing import Any


class QATouchClient:
    BASE = "https://api.qatouch.com/api/v1"

    def __init__(self, domain: str, api_token: str, project_key: str) -> None:
        self.domain = domain
        self.api_token = api_token
        self.project_key = project_key
        self._ctx = ssl.create_default_context()

    # ------------------------------------------------------------------
    # Low-level helpers
    # ------------------------------------------------------------------

    def _headers(self) -> dict[str, str]:
        return {
            "api-token": self.api_token,
            "domain": self.domain,
            "Content-Type": "application/json",
        }

    def _request(self, method: str, path: str) -> Any:
        url = f"{self.BASE}{path}"
        req = urllib.request.Request(url, method=method, headers=self._headers())
        try:
            with urllib.request.urlopen(req, context=self._ctx) as resp:
                body = resp.read().decode()
                return json.loads(body) if body.strip() else {}
        except urllib.error.HTTPError as exc:
            body = exc.read().decode()
            try:
                payload = json.loads(body)
                msg = payload.get("error_msg") or payload.get("error") or str(exc)
            except Exception:
                msg = body or str(exc)
            raise RuntimeError(f"QA Touch API {exc.code} for {path}: {msg}") from exc

    def _post_multipart(self, path: str, file_path: str) -> Any:
        import mimetypes
        boundary = f"----QATouchBoundary{os.getpid()}"
        filename = os.path.basename(file_path)
        with open(file_path, "rb") as f:
            file_data = f.read()

        preamble = (
            f"--{boundary}\r\n"
            f'Content-Disposition: form-data; name="file[]"; filename="{filename}"\r\n'
            f"Content-Type: {mimetypes.guess_type(filename)[0] or 'application/octet-stream'}\r\n\r\n"
        ).encode()
        epilogue = f"\r\n--{boundary}--\r\n".encode()
        body = preamble + file_data + epilogue

        headers = {
            "api-token": self.api_token,
            "domain": self.domain,
            "Content-Type": f"multipart/form-data; boundary={boundary}",
            "Content-Length": str(len(body)),
        }
        url = f"{self.BASE}{path}"
        req = urllib.request.Request(url, data=body, method="POST", headers=headers)
        with urllib.request.urlopen(req, context=self._ctx) as resp:
            raw = resp.read().decode()
            return json.loads(raw) if raw.strip() else {}

    @staticmethod
    def _normalize_list(response: Any) -> list:
        if isinstance(response, list):
            return response
        if isinstance(response, dict):
            if isinstance(response.get("data"), list):
                return response["data"]
            if isinstance(response.get("items"), list):
                return response["items"]
        return []

    # ------------------------------------------------------------------
    # Test cases
    # ------------------------------------------------------------------

    def get_test_cases(self, module_key: str | None = None) -> list:
        all_cases: list = []
        page = 1
        while True:
            if module_key:
                query = f"moduleKey={module_key}&page={page}"
            else:
                query = f"mode=automation&page={page}"
            resp = self._request("GET", f"/getAllTestCases/{self.project_key}?{query}")
            batch = self._normalize_list(resp)
            if not batch:
                break
            all_cases.extend(batch)
            total = int((resp.get("meta") or {}).get("total") or 0)
            per_page = int((resp.get("meta") or {}).get("per_page") or 50)
            if total and len(all_cases) >= total:
                break
            if len(batch) < per_page:
                break
            page += 1
            if page > 200:
                break
        return all_cases

    def create_test_case(
        self,
        module_key: str,
        title: str,
        description: str,
        reference: str,
        precondition: str,
        steps_template: str,
    ) -> None:
        params = (
            f"projectKey={self.project_key}"
            f"&sectionKey={urllib.parse.quote(module_key)}"
            f"&caseTitle={urllib.parse.quote(title)}"
            f"&description={urllib.parse.quote(description)}"
            f"&reference={urllib.parse.quote(reference)}"
            f"&precondition={urllib.parse.quote(precondition)}"
            f"&steps_template={steps_template}"
            f"&mode=automation"
        )
        self._request("POST", f"/testCase/steps?{params}")

    # ------------------------------------------------------------------
    # Modules
    # ------------------------------------------------------------------

    def get_modules(self) -> list:
        all_mods: list = []
        page = 1
        while True:
            resp = self._request("GET", f"/getAllModules/{self.project_key}?page={page}")
            batch = self._normalize_list(resp)
            if not batch:
                break
            all_mods.extend(batch)
            total = int((resp.get("meta") or {}).get("total") or 0)
            per_page = int((resp.get("meta") or {}).get("per_page") or 20)
            if total and len(all_mods) >= total:
                break
            if len(batch) < per_page:
                break
            page += 1
            if page > 50:
                break
        return all_mods

    def create_module(self, module_name: str, parent_key: str | None = None) -> Any:
        params = (
            f"projectKey={self.project_key}"
            f"&moduleName={urllib.parse.quote(module_name)}"
        )
        if parent_key:
            params += f"&parentKey={urllib.parse.quote(parent_key)}"
        resp = self._request("POST", f"/module?{params}")
        if isinstance(resp.get("data"), dict):
            return resp["data"]
        batch = self._normalize_list(resp)
        return batch[0] if batch else resp

    # ------------------------------------------------------------------
    # Milestones
    # ------------------------------------------------------------------

    def get_milestones(self) -> list:
        resp = self._request("GET", f"/getAllMilestones/{self.project_key}")
        return self._normalize_list(resp)

    def create_milestone(self, name: str) -> None:
        self._request(
            "POST",
            f"/milestone?projectKey={self.project_key}&milestone={urllib.parse.quote(name)}",
        )

    # ------------------------------------------------------------------
    # Test runs
    # ------------------------------------------------------------------

    def create_test_run(
        self,
        milestone_key: str,
        title: str,
        assign_to: str,
        case_keys: list[str],
        tags: str | None = None,
    ) -> Any:
        params = [
            f"projectKey={self.project_key}",
            f"milestoneKey={urllib.parse.quote(milestone_key)}",
            f"testRun={urllib.parse.quote(title)}",
            f"assignTo={urllib.parse.quote(assign_to)}",
        ]
        if tags:
            params.append(f"tags={urllib.parse.quote(tags)}")
        for k in case_keys:
            params.append(f"caseId[]={urllib.parse.quote(k)}")
        resp = self._request("POST", f"/testRun/specific?{'&'.join(params)}")
        batch = self._normalize_list(resp)
        if batch:
            return batch[0]
        return (resp.get("data") or [{}])[0] if isinstance(resp.get("data"), list) else resp.get("data") or {}

    # ------------------------------------------------------------------
    # Results
    # ------------------------------------------------------------------

    def update_results(
        self, test_run_key: str, results: list[dict]
    ) -> Any:
        cases_obj = {str(i): r for i, r in enumerate(results)}
        params = (
            f"project={self.project_key}"
            f"&test_run={test_run_key}"
            f"&cases={urllib.parse.quote(json.dumps(cases_obj))}"
        )
        return self._request("POST", f"/runresult/updatestatus/multiple?{params}")

    def add_result_with_comment(
        self,
        test_run_key: str,
        case_key: str,
        status_id: int,
        comments: str | None = None,
        screenshot_path: str | None = None,
    ) -> Any:
        status_name = _status_id_to_name(status_id)
        endpoint = (
            f"/testRunResults/add/results"
            f"?status={urllib.parse.quote(status_name)}"
            f"&project={urllib.parse.quote(self.project_key)}"
            f"&test_run={urllib.parse.quote(test_run_key)}"
            f"&run_result[]={urllib.parse.quote('CASE' + case_key)}"
        )
        if comments:
            endpoint += f"&comments={urllib.parse.quote(comments)}"

        if screenshot_path and os.path.isfile(screenshot_path):
            size = os.path.getsize(screenshot_path)
            if size <= 2 * 1024 * 1024:
                return self._post_multipart(endpoint, screenshot_path)

        return self._request("POST", endpoint)


def _status_id_to_name(status_id: int) -> str:
    return {
        1: "passed",
        3: "blocked",
        4: "retest",
        5: "failed",
        6: "not-applicable",
        7: "in-progress",
    }.get(status_id, "untested")