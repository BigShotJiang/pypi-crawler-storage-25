﻿"""
CLI entry point.

Usage:
    python -m squish_qatouch --results results.xml \
        --domain mycompany --token TOKEN --project PROJ --assign user-key

Or via the installed script:
    squish-qatouch --results results.xml ...
"""
from __future__ import annotations

import argparse
import sys

from .reporter import SquishQATouchReporter


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="squish-qatouch",
        description="Upload Squish test results to QA Touch.",
    )
    parser.add_argument("--results",        required=True,  help="Path to Squish XML or JUnit XML results file")
    parser.add_argument("--domain",         required=True,  help="QA Touch domain (e.g. mycompany)")
    parser.add_argument("--token",          required=True,  help="QA Touch API token")
    parser.add_argument("--project",        required=True,  help="QA Touch project key")
    parser.add_argument("--assign",         required=True,  help="User key to assign the test run to")
    parser.add_argument("--testsuite",      default=None,   help="Pin all cases to this module key (skips auto-create)")
    parser.add_argument("--milestone-name", default="Squish Automation", help="Milestone name (default: Squish Automation)")
    parser.add_argument("--milestone-key",  default=None,   help="Existing milestone key — skips creation")
    parser.add_argument("--no-create-cases", action="store_true", help="Disable auto-creation of test cases")
    parser.add_argument("--tag",            default="squish", help="Tag applied to the test run (default: squish)")

    args = parser.parse_args()

    reporter = SquishQATouchReporter(
        domain=args.domain,
        api_token=args.token,
        project_key=args.project,
        assign_to=args.assign,
        results_file=args.results,
        testsuite_id=args.testsuite,
        milestone_name=args.milestone_name,
        milestone_key=args.milestone_key,
        create_cases=not args.no_create_cases,
        tag=args.tag,
    )

    try:
        reporter.run()
    except Exception as exc:
        print(f"[squish-qatouch] Fatal error: {exc}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()