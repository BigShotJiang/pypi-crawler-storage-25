﻿# squish-qatouch

> QA Touch reporter for **Squish** (Froglogic / Qt Group) — pure Python, zero dependencies.
> Reads your Squish result file and automatically creates modules, test cases, milestones,
> and test runs in QA Touch.

## Supported result formats

| Format | How to generate |
|--------|----------------|
| **Squish native XML** | `squishrunner --reportgen xml,results.xml` |
| **JUnit XML** | `squish2junit results/ junit.xml` |

Auto-detected at runtime — just point `--results` at the file.

## Works with all Squish script languages

Python, JavaScript, Perl, Ruby, Tcl — the script language does not matter.
`squishrunner` always produces the same XML format.

## Installation

```bash
pip install squish-qatouch
```

Requires **Python >= 3.10**. No third-party dependencies.

## Usage — CLI

```bash
# after squishrunner writes results.xml
squish-qatouch \
  --results   ./results/squish.xml \
  --domain    mycompany \
  --token     $QATOUCH_TOKEN \
  --project   PROJ \
  --assign    user-key \
  --milestone-name "Sprint 12"
```

Or via `python -m`:

```bash
python -m squish_qatouch --results results.xml --domain mycompany \
  --token $QATOUCH_TOKEN --project PROJ --assign user-key
```

## Usage — Python API

```python
from squish_qatouch import SquishQATouchReporter

reporter = SquishQATouchReporter(
    domain="mycompany",
    api_token="YOUR_TOKEN",
    project_key="PROJ",
    assign_to="user-key",
    results_file="./results/squish.xml",
    milestone_name="Sprint 12",   # created automatically if missing
    tag="squish",
)
reporter.run()
```

## All options

| Option | CLI flag | Default | Description |
|--------|----------|---------|-------------|
| `domain` | `--domain` | — | QA Touch domain |
| `api_token` | `--token` | — | QA Touch API token |
| `project_key` | `--project` | — | QA Touch project key |
| `assign_to` | `--assign` | — | User key to assign the run to |
| `results_file` | `--results` | — | Path to Squish XML or JUnit XML |
| `testsuite_id` | `--testsuite` | — | Pin all cases to one module key |
| `milestone_name` | `--milestone-name` | `"Squish Automation"` | Milestone name |
| `milestone_key` | `--milestone-key` | — | Use existing milestone key directly |
| `create_cases` | `--no-create-cases` | `True` | Auto-create missing test cases |
| `tag` | `--tag` | `"squish"` | Tag on the test run |

## CI example (GitHub Actions)

```yaml
- name: Run Squish tests
  run: |
    squishrunner --testsuite suite_MyApp --reportgen xml,results/squish.xml

- name: Set up Python
  uses: actions/setup-python@v5
  with:
    python-version: "3.12"

- name: Upload to QA Touch
  run: |
    pip install squish-qatouch
    squish-qatouch --results results/squish.xml \
      --domain mycompany --token ${{ secrets.QATOUCH_TOKEN }} \
      --project PROJ --assign user-key
```

## License

ISC