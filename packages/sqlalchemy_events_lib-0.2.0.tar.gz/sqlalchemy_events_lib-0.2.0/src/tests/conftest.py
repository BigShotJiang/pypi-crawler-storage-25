import asyncio
import os

import pytest_asyncio
from dotenv import load_dotenv

from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker
from sqlalchemy import text
from sqlalchemy_events import SQLAlchemyEvents

from tests.test_models import Base

load_dotenv()
DATABASE_URL = os.environ.get('DATABASE_URL')


@pytest_asyncio.fixture
async def engine():
    engine = create_async_engine(DATABASE_URL, pool_pre_ping=True)
    yield engine
    await engine.dispose()

IS_DB = False


@pytest_asyncio.fixture(autouse=True)
async def prepared_db(engine):
    global IS_DB
    if not IS_DB:
        async with engine.begin() as conn:
            await conn.execute(text('DROP SCHEMA IF EXISTS public CASCADE'))
            await conn.execute(text('CREATE SCHEMA public'))
            await conn.run_sync(Base.metadata.create_all)

        SQLAlchemyEvents(
            base=Base,
            engine=engine,
            autodiscover_paths=['tests']
        )
        await asyncio.sleep(0.1)
        IS_DB = True


@pytest_asyncio.fixture
async def session(engine):
    async_session = async_sessionmaker(engine, expire_on_commit=False)

    async with async_session() as session:
        yield session
        await session.rollback()