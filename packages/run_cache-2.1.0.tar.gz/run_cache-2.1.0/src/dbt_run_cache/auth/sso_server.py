from __future__ import annotations

import sys
import typing as t
from http.server import BaseHTTPRequestHandler, HTTPServer
from queue import Queue
from types import TracebackType
from urllib.parse import parse_qs, urlparse

if t.TYPE_CHECKING:
    if sys.version_info >= (3, 11):
        from typing import Self
    else:
        from typing_extensions import Self

LOGO = "https://auth.runcache.com/assets/logo.svg"
LOCAL_OAUTH_PORT = 29525
""" The string "sql" in base 32"""


class SsoHttpServer(HTTPServer):
    allow_reuse_address = True

    def __init__(self) -> None:
        self.queue: Queue[str] = Queue()
        super().__init__(("", LOCAL_OAUTH_PORT), SsoHttpRequestHandler)
        self.timeout = 300

    def stop(self) -> None:
        """Best-effort stop: close the listening socket to unblock handle_request."""
        try:
            self.server_close()
        except Exception:
            pass

    def __enter__(self) -> Self:
        return self

    def __exit__(
        self,
        exc_type: t.Optional[type[BaseException]],
        exc_val: t.Optional[BaseException],
        exc_tb: t.Optional[TracebackType],
    ) -> None:
        self.stop()


class SsoHttpRequestHandler(BaseHTTPRequestHandler):
    server: SsoHttpServer

    @staticmethod
    def _html(title: str, message: str) -> str:
        return str(f"""<!doctype html>
<html>
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="icon" href="https://auth.runcache.com/assets/favicon.png" sizes="any" type="image/svg+xml" />
    <title>Run Cache - Login</title>
  </head>
  <body style="text-align: center; font-family: Inter, sans-serif;">
    <img alt="Logo" src="{LOGO}"/>
    <h1>{title}</h1>
    <p>{message}</p>
    <p><em>You can close this window</em></p>
  </body>
</html>
""")

    @staticmethod
    def success_html() -> str:
        return SsoHttpRequestHandler._html("Success", "You have logged in!")

    @staticmethod
    def error_html(message: str) -> str:
        return SsoHttpRequestHandler._html("Error", message)

    def log_message(self, format: str, *args: t.Any) -> None:
        pass

    def do_GET(self) -> None:
        self.server.queue.put(self.path)

        parsed = urlparse(self.path)
        query = parse_qs(parsed.query)

        if "error" in query:
            self.send_response(500)
            self.send_header("Content-type", "text/html")
            self.send_header("Connection", "close")
            self.end_headers()
            message = query["error"][0]
            if query.get("error_description"):
                message = message + ": " + query["error_description"][0]
            self.wfile.write(self.error_html(message).encode("utf-8"))
            self.close_connection = True
            return

        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(self.success_html().encode("utf-8"))
        self.close_connection = True
