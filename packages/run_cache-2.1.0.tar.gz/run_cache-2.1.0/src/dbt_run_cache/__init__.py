from dbt_run_cache import plugin

try:
    from dbt_run_cache._version import __version__ as __version__
except ImportError:
    __version__: str = "0.0.0"


plugins = [plugin.RunCachePlugin]
