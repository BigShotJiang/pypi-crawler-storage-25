from __future__ import annotations

import abc


class BaseRunCacheError(Exception, abc.ABC):
    """Base class for all errors."""


class AdapterExtensionError(BaseRunCacheError):
    """Errors related to adapter extensions."""


class OAuthClientError(BaseRunCacheError):
    """Errors related to OAuth client management operations."""


class AuthenticationError(BaseRunCacheError):
    """Raised when authentication operations fail."""


class CertificateError(BaseRunCacheError):
    """Raised when there is an issue with SSL/TLS certificates."""


class UnsupportedClientVersionError(BaseRunCacheError):
    """Raised when the current client version is not supported."""
