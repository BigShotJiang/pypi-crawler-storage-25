# `nidaqlib.sinks`

::: nidaqlib.sinks
