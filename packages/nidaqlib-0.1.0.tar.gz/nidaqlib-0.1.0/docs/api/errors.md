# `nidaqlib.errors`

::: nidaqlib.errors
