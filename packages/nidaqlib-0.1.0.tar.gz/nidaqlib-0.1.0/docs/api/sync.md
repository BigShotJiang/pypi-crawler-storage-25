# `nidaqlib.sync`

::: nidaqlib.sync
