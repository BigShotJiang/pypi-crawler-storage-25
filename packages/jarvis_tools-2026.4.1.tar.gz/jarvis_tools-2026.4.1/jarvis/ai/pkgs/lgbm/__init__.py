"""LighGBM applications."""
