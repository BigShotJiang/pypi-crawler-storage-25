"""Modules for thermodynamic analysis."""
