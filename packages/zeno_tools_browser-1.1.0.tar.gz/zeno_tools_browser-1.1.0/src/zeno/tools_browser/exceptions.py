"""zeno-tools-browser exceptions.

These are surfaced directly to the LLM via the ``@tool`` envelope, so
messages should be concise and actionable.
"""

from __future__ import annotations


class BrowserError(Exception):
    """Base class for all zeno-tools-browser errors."""


class BrowserLimitError(BrowserError):
    """Raised when a pool-level session cap is exceeded.

    Example::

        raise BrowserLimitError("max_sessions_per_user (10) reached for user 'alice'")
    """


class BrowserSessionClosedError(BrowserError):
    """Raised when a caller tries to use a pool after ``stop()``.

    Also raised if a session has been closed by the idle reaper between
    the agent's ``acquire()`` and subsequent use.
    """


class BrowserEvaluateJsDisabledError(BrowserError):
    """Raised when ``evaluate_js`` is called on a pool with
    ``allow_evaluate_js=False`` (the default).

    The message points at the pool flag so the app author can opt in
    explicitly if they need agent-supplied JS execution.
    """


class BrowserUrlDeniedError(BrowserError):
    """Raised when a navigation target is rejected.

    Rejections come from two sources:

    * the built-in scheme filter (``browse`` only allows ``http`` and
      ``https``);
    * an app-supplied ``url_filter`` callable on the pool that returned
      ``False`` for the requested URL.
    """
