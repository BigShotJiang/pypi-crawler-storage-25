"""``BrowserSessionPool`` — per-``(user_id, thread_key)`` Playwright
lifecycle.

One ``BrowserSession`` per key holds a ``Browser`` → ``BrowserContext``
→ ``Page`` chain plus an ``asyncio.Lock`` that serializes concurrent
tool calls against the page. The pool owns one ``async_playwright()``
root and one launched ``Browser``; every session gets its own
``BrowserContext`` so cookies and auth are isolated per key.

Lifecycle mirrors ``zeno.scheduler.Scheduler``:

* ``start()`` lazily imports ``playwright.async_api``, launches the
  browser, spawns the idle-reap task.
* ``stop()`` closes every session, closes the browser, exits
  ``async_playwright()``, cancels the reap task.

Everything is structurally typed against Playwright so the pool is
testable without real Chromium — tests inject a fake manager via
``_manager_factory``.
"""

from __future__ import annotations

import asyncio
import contextlib
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Protocol

from zeno.tools_browser.exceptions import (
    BrowserLimitError,
    BrowserSessionClosedError,
)

if TYPE_CHECKING:
    from playwright.async_api import Browser, BrowserContext


# ---------------------------------------------------------------------------
# Manager abstraction (test seam)
# ---------------------------------------------------------------------------


class _PlaywrightManagerProtocol(Protocol):
    """Narrow protocol the pool uses to interact with Playwright.

    The real implementation below wraps ``async_playwright()`` and a
    launched ``Browser``. Tests inject a fake that tracks calls.
    """

    async def start(self) -> None: ...
    async def stop(self) -> None: ...
    async def new_context(self, *, viewport: tuple[int, int]) -> Any: ...


class _PlaywrightManager:
    """Real ``async_playwright()`` + ``Browser`` owner."""

    def __init__(self, *, headless: bool) -> None:
        self._headless = headless
        self._playwright: Any = None
        self._browser: Browser | None = None

    async def start(self) -> None:
        # Lazy import so the module-level import cost is paid only when
        # the app actually wires ``ZenoApp(browser=...)``.
        from playwright.async_api import async_playwright

        self._playwright = await async_playwright().start()
        self._browser = await self._playwright.chromium.launch(headless=self._headless)

    async def stop(self) -> None:
        if self._browser is not None:
            with contextlib.suppress(Exception):
                await self._browser.close()
            self._browser = None
        if self._playwright is not None:
            with contextlib.suppress(Exception):
                await self._playwright.stop()
            self._playwright = None

    async def new_context(self, *, viewport: tuple[int, int]) -> BrowserContext:
        if self._browser is None:
            raise RuntimeError("_PlaywrightManager.new_context called before start()")
        return await self._browser.new_context(
            viewport={"width": viewport[0], "height": viewport[1]},
        )


# ---------------------------------------------------------------------------
# Session
# ---------------------------------------------------------------------------


@dataclass
class BrowserSession:
    """One browser session bound to a ``(user_id, thread_key)`` key.

    ``lock`` serializes concurrent tool calls against ``page`` —
    Playwright's ``Page`` is not safe to drive from multiple
    coroutines at once.

    ``pool`` back-reference exists so tool wrappers can read the pool's
    ``allow_evaluate_js`` flag, ``url_filter``, and ``call_timeout_s``
    without plumbing them through every tool signature.
    """

    user_id: str
    thread_key: str | None
    page: Any  # Playwright Page (Any to stay test-injectable)
    context: Any  # Playwright BrowserContext
    pool: BrowserSessionPool
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    last_used_at: float = 0.0

    async def close(self) -> None:
        """Close the page + context. Safe to call twice."""
        with contextlib.suppress(Exception):
            await self.page.close()
        with contextlib.suppress(Exception):
            await self.context.close()


# ---------------------------------------------------------------------------
# Pool
# ---------------------------------------------------------------------------


_SessionKey = tuple[str, str | None]


class BrowserSessionPool:
    """Per-``(user_id, thread_key)`` browser session pool.

    Parameters
    ----------
    headless:
        ``True`` (default) runs Chromium without a visible window.
        Headful mode is useful for app-author debugging.
    idle_timeout_s:
        Sessions untouched for this many seconds are closed by the
        reap loop.
    max_sessions_global:
        Hard cap on live sessions across all users. Raises
        ``BrowserLimitError`` when exceeded.
    max_sessions_per_user:
        Per-user cap. Raises ``BrowserLimitError`` when exceeded.
    viewport:
        ``(width, height)`` applied to every new ``BrowserContext``.
    call_timeout_s:
        Default timeout (seconds) for Playwright calls in the tool
        wrappers. Individual tools may override.
    allow_evaluate_js:
        When ``False`` (default), the ``evaluate_js`` tool raises
        ``BrowserEvaluateJsDisabledError``. Apps that actually need
        agent-supplied JS execution opt in explicitly.
    url_filter:
        Optional callable ``(url) -> bool``. When provided and it
        returns ``False``, ``browse`` raises
        ``BrowserUrlDeniedError`` before any navigation occurs.
        ``None`` (default) means unrestricted.
    reap_interval_s:
        How often the idle reaper wakes to scan for cold sessions.
    now_fn:
        Clock injection for testing. Defaults to ``time.monotonic``.
    _manager_factory:
        Test seam. Produces the object the pool uses to interact with
        Playwright. Default is the real ``_PlaywrightManager``.
    """

    def __init__(
        self,
        *,
        headless: bool = True,
        idle_timeout_s: int = 600,
        max_sessions_global: int = 50,
        max_sessions_per_user: int = 10,
        viewport: tuple[int, int] = (1280, 720),
        call_timeout_s: float = 30.0,
        allow_evaluate_js: bool = False,
        url_filter: Callable[[str], bool] | None = None,
        reap_interval_s: float = 60.0,
        now_fn: Callable[[], float] | None = None,
        _manager_factory: Callable[[bool], _PlaywrightManagerProtocol] | None = None,
    ) -> None:
        self._headless = headless
        self._idle_timeout_s = idle_timeout_s
        self._max_sessions_global = max_sessions_global
        self._max_sessions_per_user = max_sessions_per_user
        self._viewport = viewport
        self.call_timeout_s = call_timeout_s
        self.allow_evaluate_js = allow_evaluate_js
        self.url_filter = url_filter
        self._reap_interval_s = reap_interval_s
        self._now_fn: Callable[[], float] = now_fn or time.monotonic
        self._manager_factory: Callable[[bool], _PlaywrightManagerProtocol] = _manager_factory or (
            lambda headless: _PlaywrightManager(headless=headless)
        )

        self._sessions: dict[_SessionKey, BrowserSession] = {}
        self._manager: _PlaywrightManagerProtocol | None = None
        self._reaper_task: asyncio.Task[None] | None = None
        self._started = False
        self._stopping = False
        self._acquire_lock = asyncio.Lock()  # serializes session creation

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        """Start the pool (idempotent).

        Launches Playwright and spawns the idle-reap task. Calling
        ``start()`` twice is a no-op.
        """
        if self._started:
            return
        self._stopping = False
        self._manager = self._manager_factory(self._headless)
        await self._manager.start()
        self._reaper_task = asyncio.create_task(self._reap_loop(), name="browser-reap")
        self._started = True

    async def stop(self) -> None:
        """Stop the pool. Idempotent — safe to call without ``start()``."""
        self._stopping = True
        # Cancel and await the reap task.
        if self._reaper_task is not None and not self._reaper_task.done():
            self._reaper_task.cancel()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await self._reaper_task
        self._reaper_task = None

        # Close every session.
        sessions = list(self._sessions.values())
        self._sessions.clear()
        for session in sessions:
            await session.close()

        # Shut down Playwright.
        if self._manager is not None:
            with contextlib.suppress(Exception):
                await self._manager.stop()
        self._manager = None
        self._started = False

    # ------------------------------------------------------------------
    # Acquire
    # ------------------------------------------------------------------

    async def acquire(self, user_id: str, thread_key: str | None) -> BrowserSession:
        """Return the session for ``(user_id, thread_key)``, opening one
        if it doesn't exist yet.

        Raises
        ------
        BrowserSessionClosedError
            If the pool has been stopped.
        BrowserLimitError
            If creating a new session would exceed the per-user or
            global cap.
        """
        if self._stopping or not self._started or self._manager is None:
            raise BrowserSessionClosedError(
                "BrowserSessionPool is not running; call start() before acquire()"
            )

        key: _SessionKey = (user_id, thread_key)

        async with self._acquire_lock:
            existing = self._sessions.get(key)
            if existing is not None:
                existing.last_used_at = self._now_fn()
                return existing

            # Enforce caps before opening a new session.
            if len(self._sessions) >= self._max_sessions_global:
                raise BrowserLimitError(
                    f"max_sessions_global ({self._max_sessions_global}) reached"
                )
            per_user = sum(1 for (uid, _) in self._sessions if uid == user_id)
            if per_user >= self._max_sessions_per_user:
                raise BrowserLimitError(
                    f"max_sessions_per_user ({self._max_sessions_per_user}) "
                    f"reached for user {user_id!r}"
                )

            context = await self._manager.new_context(viewport=self._viewport)
            page = await context.new_page()

            session = BrowserSession(
                user_id=user_id,
                thread_key=thread_key,
                page=page,
                context=context,
                pool=self,
                last_used_at=self._now_fn(),
            )
            self._sessions[key] = session
            return session

    # ------------------------------------------------------------------
    # Reap
    # ------------------------------------------------------------------

    async def _reap_loop(self) -> None:
        """Background task: close sessions idle beyond ``idle_timeout_s``."""
        while not self._stopping:
            try:
                await asyncio.sleep(self._reap_interval_s)
            except asyncio.CancelledError:
                raise
            if self._stopping:
                break
            await self._reap_once()

    async def _reap_once(self) -> None:
        """Scan sessions and close any past the idle window.

        Holds ``_acquire_lock`` while mutating ``_sessions`` so an idle
        session can't be popped + closed while ``acquire()`` is about
        to hand it to a caller.
        """
        async with self._acquire_lock:
            now = self._now_fn()
            to_close: list[_SessionKey] = [
                key
                for key, session in self._sessions.items()
                if now - session.last_used_at > self._idle_timeout_s
            ]
            popped: list[BrowserSession] = []
            for key in to_close:
                session = self._sessions.pop(key, None)
                if session is not None:
                    popped.append(session)
        for session in popped:
            await session.close()
