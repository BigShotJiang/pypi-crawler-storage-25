"""Test double: ``FakeBrowserSessionPool``.

Drop-in replacement for ``BrowserSessionPool`` used by the tool
wrappers' unit tests and by apps that want to run their agent against
a scripted ``page`` without launching Chromium. Mirrors
``zeno.scheduler.testing.InMemoryScheduleStore`` in spirit — same
public API, in-memory state.

Typical use::

    from zeno.tools_browser.testing import FakeBrowserSessionPool

    pool = FakeBrowserSessionPool()
    await pool.start()
    session = await pool.acquire("alice", "t1")
    session.page.text = "hello"  # fake page has a writable .text
"""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from zeno.tools_browser.exceptions import (
    BrowserLimitError,
    BrowserSessionClosedError,
)
from zeno.tools_browser.pool import BrowserSession, _SessionKey


@dataclass
class _FakePageRecord:
    """Record of a single call made against the fake page."""

    method: str
    args: tuple[Any, ...]
    kwargs: dict[str, Any]


class _FakeKeyboard:
    """Stand-in for ``playwright.async_api.Keyboard``.

    Shares the owning ``FakePage``'s ``calls`` list so tests can assert
    on both page-level and keyboard-level calls in a single ordering.
    """

    def __init__(self, page: FakePage) -> None:
        self._page = page

    async def press(self, key: str, **kwargs: Any) -> None:
        self._page._record("keyboard.press", key, **kwargs)


class FakePage:
    """Scriptable stand-in for ``playwright.async_api.Page``.

    Supports the methods the tool wrappers call (``goto``, ``click``,
    ``fill``, ``text_content``, ``screenshot``, ``wait_for_selector``,
    ``keyboard.press``, ``eval_on_selector_all``, ``evaluate``,
    ``content``, ``url``). Every call is recorded in ``calls`` so
    tests can assert on behavior.

    Fields marked as return-value knobs (``text``, ``url_value``,
    ``screenshot_bytes``, ``eval_result``, ``evaluate_result``,
    ``links``) let tests script what each method returns.
    """

    def __init__(self) -> None:
        self.calls: list[_FakePageRecord] = []
        self.closed: bool = False
        self.keyboard = _FakeKeyboard(self)

        # Scripted return values.
        self.text: str = ""
        self.html: str = "<html><body></body></html>"
        self.url_value: str = "about:blank"
        self.screenshot_bytes: bytes = b""
        self.eval_result: Any = None
        self.evaluate_result: Any = None
        self.links: list[dict[str, str]] = []
        self.wait_raises: BaseException | None = None
        self.click_raises: BaseException | None = None

    # URL reflects the most recent successful goto.
    @property
    def url(self) -> str:
        return self.url_value

    def _record(self, method: str, *args: Any, **kwargs: Any) -> None:
        self.calls.append(_FakePageRecord(method=method, args=args, kwargs=kwargs))

    async def goto(self, url: str, **kwargs: Any) -> None:
        self._record("goto", url, **kwargs)
        self.url_value = url

    async def click(self, selector: str, **kwargs: Any) -> None:
        self._record("click", selector, **kwargs)
        if self.click_raises is not None:
            raise self.click_raises

    async def fill(self, selector: str, value: str, **kwargs: Any) -> None:
        self._record("fill", selector, value, **kwargs)

    async def type(self, selector: str, text: str, **kwargs: Any) -> None:  # noqa: A003
        self._record("type", selector, text, **kwargs)

    async def text_content(self, selector: str, **kwargs: Any) -> str:
        self._record("text_content", selector, **kwargs)
        return self.text

    async def content(self) -> str:
        self._record("content")
        return self.html

    async def screenshot(self, **kwargs: Any) -> bytes:
        self._record("screenshot", **kwargs)
        return self.screenshot_bytes

    async def wait_for_selector(self, selector: str, **kwargs: Any) -> None:
        self._record("wait_for_selector", selector, **kwargs)
        if self.wait_raises is not None:
            raise self.wait_raises

    async def press(self, selector: str, key: str, **kwargs: Any) -> None:
        self._record("press", selector, key, **kwargs)

    async def eval_on_selector_all(self, selector: str, expression: str, **kwargs: Any) -> Any:
        self._record("eval_on_selector_all", selector, expression, **kwargs)
        return self.links if self.eval_result is None else self.eval_result

    async def evaluate(self, expression: str, **kwargs: Any) -> Any:
        self._record("evaluate", expression, **kwargs)
        return self.evaluate_result

    async def close(self) -> None:
        self.closed = True


@dataclass
class _FakeContext:
    pages: list[FakePage] = field(default_factory=list)
    closed: bool = False

    async def close(self) -> None:
        self.closed = True
        for page in self.pages:
            await page.close()


class FakeBrowserSessionPool:
    """In-memory test double with the same public API as
    ``BrowserSessionPool``.

    Behavioral contract matches the real pool:

    * ``start()`` / ``stop()`` are idempotent.
    * ``acquire(user_id, thread_key)`` returns the same session for
      the same key across calls; different keys get different
      sessions.
    * ``max_sessions_per_user`` / ``max_sessions_global`` are
      enforced.
    * ``acquire()`` after ``stop()`` raises
      ``BrowserSessionClosedError``.

    The pool never touches Playwright. ``session.page`` is a
    ``FakePage``.
    """

    def __init__(
        self,
        *,
        max_sessions_global: int = 50,
        max_sessions_per_user: int = 10,
        call_timeout_s: float = 30.0,
        allow_evaluate_js: bool = False,
        url_filter: Callable[[str], bool] | None = None,
    ) -> None:
        self._max_sessions_global = max_sessions_global
        self._max_sessions_per_user = max_sessions_per_user
        self.call_timeout_s = call_timeout_s
        self.allow_evaluate_js = allow_evaluate_js
        self.url_filter = url_filter

        self._sessions: dict[_SessionKey, BrowserSession] = {}
        self._started = False
        self._stopping = False

    async def start(self) -> None:
        if self._started:
            return
        self._started = True
        self._stopping = False

    async def stop(self) -> None:
        self._stopping = True
        sessions = list(self._sessions.values())
        self._sessions.clear()
        for session in sessions:
            await session.close()
        self._started = False

    async def acquire(self, user_id: str, thread_key: str | None) -> BrowserSession:
        if self._stopping or not self._started:
            raise BrowserSessionClosedError(
                "FakeBrowserSessionPool is not running; call start() before acquire()"
            )

        key: _SessionKey = (user_id, thread_key)
        existing = self._sessions.get(key)
        if existing is not None:
            return existing

        if len(self._sessions) >= self._max_sessions_global:
            raise BrowserLimitError(f"max_sessions_global ({self._max_sessions_global}) reached")
        per_user = sum(1 for (uid, _) in self._sessions if uid == user_id)
        if per_user >= self._max_sessions_per_user:
            raise BrowserLimitError(
                f"max_sessions_per_user ({self._max_sessions_per_user}) "
                f"reached for user {user_id!r}"
            )

        context = _FakeContext()
        page = FakePage()
        context.pages.append(page)

        session = BrowserSession(
            user_id=user_id,
            thread_key=thread_key,
            page=page,
            context=context,
            pool=self,  # type: ignore[arg-type]
            lock=asyncio.Lock(),
        )
        self._sessions[key] = session
        return session
