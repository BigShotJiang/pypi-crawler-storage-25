"""zeno-tools-browser public API."""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version

from zeno.tools_browser.exceptions import (
    BrowserError,
    BrowserEvaluateJsDisabledError,
    BrowserLimitError,
    BrowserSessionClosedError,
    BrowserUrlDeniedError,
)
from zeno.tools_browser.pool import BrowserSession, BrowserSessionPool
from zeno.tools_browser.tools import (
    browse,
    click,
    evaluate_js,
    extract_links,
    fill_form,
    press_key,
    read_text,
    screenshot,
    type_text,
    wait_for_selector,
)

# FakeBrowserSessionPool is intentionally NOT exported from the top-level
# package — users import it from `zeno.tools_browser.testing`.

try:
    __version__ = version("zeno-tools-browser")
except PackageNotFoundError:
    __version__ = "0.0.0+unknown"

__all__ = [
    "__version__",
    # Exceptions
    "BrowserError",
    "BrowserLimitError",
    "BrowserSessionClosedError",
    "BrowserEvaluateJsDisabledError",
    "BrowserUrlDeniedError",
    # Core
    "BrowserSession",
    "BrowserSessionPool",
    # Tools
    "browse",
    "click",
    "type_text",
    "fill_form",
    "read_text",
    "screenshot",
    "extract_links",
    "wait_for_selector",
    "press_key",
    "evaluate_js",
]
