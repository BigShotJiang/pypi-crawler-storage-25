"""Fake Playwright primitives for pool unit tests.

These live under ``tests/`` on purpose — they are implementation
scaffolding for the real ``BrowserSessionPool`` unit tests, not a
public API. The user-facing test double is ``FakeBrowserSessionPool``
(shipped in ``zeno.tools_browser.testing``).

The fakes are duck-typed against the handful of Playwright methods
the pool actually calls (``new_context``, ``context.new_page``,
``page.close``, ``context.close``, ``browser.close``).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class FakePage:
    """Stand-in for ``playwright.async_api.Page``.

    Tool-level tests replace this with a richer fake that records
    method calls; pool-level tests just need an object with a stable
    identity and a ``close()``.
    """

    closed: bool = False
    identity: int = 0  # test-assigned; two FakePages are different when their identity differs

    async def close(self) -> None:
        self.closed = True

    async def goto(self, url: str, **kwargs: Any) -> Any:  # noqa: ARG002
        return None


@dataclass
class FakeContext:
    pages: list[FakePage] = field(default_factory=list)
    closed: bool = False

    async def new_page(self) -> FakePage:
        page = FakePage(identity=len(self.pages))
        self.pages.append(page)
        return page

    async def close(self) -> None:
        self.closed = True
        for p in self.pages:
            await p.close()


@dataclass
class FakeBrowser:
    """Stand-in for ``playwright.async_api.Browser``."""

    contexts: list[FakeContext] = field(default_factory=list)
    closed: bool = False

    async def new_context(self, **_: Any) -> FakeContext:
        ctx = FakeContext()
        self.contexts.append(ctx)
        return ctx

    async def close(self) -> None:
        self.closed = True


@dataclass
class FakePlaywrightManager:
    """Stand-in for the pool's internal Playwright manager.

    The real ``_PlaywrightManager`` owns the ``async_playwright()``
    context manager and a launched ``Browser``. The fake owns a
    ``FakeBrowser`` and tracks start/stop so tests can assert on
    lifecycle.
    """

    started: bool = False
    stopped: bool = False
    browser: FakeBrowser = field(default_factory=FakeBrowser)

    async def start(self) -> None:
        self.started = True

    async def stop(self) -> None:
        self.stopped = True
        await self.browser.close()

    async def new_context(self, *, viewport: tuple[int, int]) -> FakeContext:  # noqa: ARG002
        if not self.started:
            raise RuntimeError("FakePlaywrightManager.new_context called before start()")
        return await self.browser.new_context()
