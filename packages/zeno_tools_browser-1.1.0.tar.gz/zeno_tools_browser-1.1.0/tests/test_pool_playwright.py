"""Real-Playwright lifecycle smoke test.

Gated behind ``@pytest.mark.playwright`` so the main ``test`` CI job
stays fast. The dedicated ``test-playwright`` job installs Chromium
via ``playwright install --with-deps chromium`` before running this.
"""

from __future__ import annotations

import pytest
from zeno.tools_browser.pool import BrowserSessionPool


@pytest.mark.playwright
async def test_real_playwright_lifecycle() -> None:
    """start → acquire → navigate → stop, no zombie processes."""
    pool = BrowserSessionPool(headless=True)
    await pool.start()
    try:
        session = await pool.acquire("alice", "t1")
        await session.page.goto("about:blank")
        assert session.page.url == "about:blank"
    finally:
        await pool.stop()
