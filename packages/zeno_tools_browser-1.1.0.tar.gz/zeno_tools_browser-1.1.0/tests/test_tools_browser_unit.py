"""Unit tests for zeno-tools-browser @tool wrappers (U3).

All tests use ``FakeBrowserSessionPool`` wired into
``ctx.state["browser"]`` — no Chromium required. A real-Playwright
integration test lives in ``test_tools_playwright.py`` under
``@pytest.mark.playwright``.
"""

from __future__ import annotations

import asyncio
import base64
import json
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest
from zeno.context import Ctx
from zeno.tool import get_spec
from zeno.tools_browser.exceptions import (
    BrowserError,
    BrowserEvaluateJsDisabledError,
    BrowserUrlDeniedError,
)
from zeno.tools_browser.testing import FakeBrowserSessionPool
from zeno.tools_browser.tools import (
    browse,
    click,
    evaluate_js,
    extract_links,
    fill_form,
    press_key,
    read_text,
    screenshot,
    type_text,
    wait_for_selector,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_ctx(
    pool: FakeBrowserSessionPool | None,
    *,
    user_id: str = "alice",
    thread_key: str | None = "main",
) -> Ctx:
    transport = httpx.MockTransport(lambda _req: httpx.Response(200))
    http = httpx.AsyncClient(transport=transport)
    state: dict[str, Any] = {}
    if pool is not None:
        state["browser"] = pool
    return Ctx(
        user_id=user_id,
        session_id=None,
        channel="test",
        memory=MagicMock(),
        reply=AsyncMock(),
        stream=AsyncMock(),
        finalize=AsyncMock(),
        http=http,
        logger=MagicMock(),
        tracer=MagicMock(),
        state=state,
        thread_key=thread_key,
    )


async def _started_pool(**kwargs: Any) -> FakeBrowserSessionPool:
    pool = FakeBrowserSessionPool(**kwargs)
    await pool.start()
    return pool


# ---------------------------------------------------------------------------
# browse
# ---------------------------------------------------------------------------


async def test_browse_returns_final_url() -> None:
    pool = await _started_pool()
    try:
        ctx = _make_ctx(pool)
        result = await browse(ctx, "https://example.org")
        assert result == "https://example.org"
        session = await pool.acquire("alice", "main")
        goto_calls = [c for c in session.page.calls if c.method == "goto"]
        assert len(goto_calls) == 1
        assert goto_calls[0].args == ("https://example.org",)
    finally:
        await pool.stop()


async def test_browse_rejects_javascript_scheme() -> None:
    pool = await _started_pool()
    try:
        ctx = _make_ctx(pool)
        with pytest.raises(BrowserUrlDeniedError):
            await browse(ctx, "javascript:alert(1)")
        # No session created -> no goto call.
        session = await pool.acquire("alice", "main")
        assert [c.method for c in session.page.calls] == []
    finally:
        await pool.stop()


async def test_browse_rejects_file_and_data_schemes() -> None:
    pool = await _started_pool()
    try:
        ctx = _make_ctx(pool)
        with pytest.raises(BrowserUrlDeniedError):
            await browse(ctx, "file:///etc/passwd")
        with pytest.raises(BrowserUrlDeniedError):
            await browse(ctx, "data:text/html,<h1>hi</h1>")
    finally:
        await pool.stop()


async def test_browse_url_filter_rejection_before_goto() -> None:
    pool = await _started_pool(url_filter=lambda u: "allowed" in u)
    try:
        ctx = _make_ctx(pool)
        with pytest.raises(BrowserUrlDeniedError):
            await browse(ctx, "https://denied.example")
        session = await pool.acquire("alice", "main")
        assert [c.method for c in session.page.calls] == []
    finally:
        await pool.stop()


async def test_browse_url_filter_allows_matching_url() -> None:
    pool = await _started_pool(url_filter=lambda u: "allowed" in u)
    try:
        ctx = _make_ctx(pool)
        result = await browse(ctx, "https://allowed.example")
        assert result == "https://allowed.example"
    finally:
        await pool.stop()


# ---------------------------------------------------------------------------
# click / type_text / fill_form / press_key
# ---------------------------------------------------------------------------


async def test_click_returns_clicked_and_records_call() -> None:
    pool = await _started_pool()
    try:
        ctx = _make_ctx(pool)
        result = await click(ctx, "#submit")
        assert result == "clicked"
        session = await pool.acquire("alice", "main")
        calls = [c for c in session.page.calls if c.method == "click"]
        assert len(calls) == 1
        assert calls[0].args == ("#submit",)
    finally:
        await pool.stop()


async def test_click_surfaces_timeout_error() -> None:
    pool = await _started_pool()
    try:
        ctx = _make_ctx(pool)
        session = await pool.acquire("alice", "main")

        class _PwTimeout(Exception):
            pass

        session.page.click_raises = _PwTimeout("selector not found")
        # Raises through — envelope layer adds is_error=True on SDK path.
        with pytest.raises(_PwTimeout):
            await click(ctx, "#nope")
    finally:
        await pool.stop()


async def test_click_error_surfaces_as_is_error_envelope() -> None:
    """Verifies the @tool envelope sets is_error=True when the handler raises."""
    pool = await _started_pool()
    try:
        ctx = _make_ctx(pool)
        session = await pool.acquire("alice", "main")

        class _PwTimeout(Exception):
            pass

        session.page.click_raises = _PwTimeout("boom")

        # Run the handler inside the envelope Ctx binding.
        from zeno.context import bind_ctx
        from zeno.providers.claude_sdk._mcp import to_sdk_tool

        spec = get_spec(click)
        sdk = to_sdk_tool(spec)
        with bind_ctx(ctx):
            result = await sdk.handler({"selector": "#nope"})
        assert result.get("is_error") is True
        assert "boom" in result["content"][0]["text"]
    finally:
        await pool.stop()


async def test_type_text_returns_typed() -> None:
    pool = await _started_pool()
    try:
        ctx = _make_ctx(pool)
        result = await type_text(ctx, "#email", "a@b.c")
        assert result == "typed"
        session = await pool.acquire("alice", "main")
        type_calls = [c for c in session.page.calls if c.method == "type"]
        assert type_calls[0].args == ("#email", "a@b.c")
    finally:
        await pool.stop()


async def test_fill_form_fills_each_field_and_returns_json() -> None:
    pool = await _started_pool()
    try:
        ctx = _make_ctx(pool)
        result = await fill_form(ctx, {"#email": "a@b.c", "#pw": "hunter2"})
        parsed = json.loads(result)
        assert parsed == ["#email", "#pw"]
        session = await pool.acquire("alice", "main")
        fill_calls = [c for c in session.page.calls if c.method == "fill"]
        assert len(fill_calls) == 2
        assert fill_calls[0].args == ("#email", "a@b.c")
        assert fill_calls[1].args == ("#pw", "hunter2")
    finally:
        await pool.stop()


async def test_press_key_returns_pressed() -> None:
    pool = await _started_pool()
    try:
        ctx = _make_ctx(pool)
        result = await press_key(ctx, "Enter")
        assert result == "pressed"
        session = await pool.acquire("alice", "main")
        press_calls = [c for c in session.page.calls if c.method == "keyboard.press"]
        assert press_calls[0].args == ("Enter",)
    finally:
        await pool.stop()


# ---------------------------------------------------------------------------
# read_text
# ---------------------------------------------------------------------------


async def test_read_text_with_selector_returns_text_content() -> None:
    pool = await _started_pool()
    try:
        ctx = _make_ctx(pool)
        session = await pool.acquire("alice", "main")
        session.page.text = "Welcome"
        result = await read_text(ctx, "#header")
        assert result == "Welcome"
    finally:
        await pool.stop()


async def test_read_text_without_selector_returns_stripped_content() -> None:
    pool = await _started_pool()
    try:
        ctx = _make_ctx(pool)
        session = await pool.acquire("alice", "main")
        session.page.html = (
            "<html><head><script>var x=1;</script></head>"
            "<body><h1>Hello</h1><p>World</p></body></html>"
        )
        result = await read_text(ctx)
        # Scripts dropped, tags stripped, whitespace collapsed.
        assert "Hello" in result
        assert "World" in result
        assert "<h1>" not in result
        assert "var x=1" not in result
    finally:
        await pool.stop()


# ---------------------------------------------------------------------------
# screenshot
# ---------------------------------------------------------------------------


async def test_screenshot_returns_data_url() -> None:
    pool = await _started_pool()
    try:
        ctx = _make_ctx(pool)
        session = await pool.acquire("alice", "main")
        session.page.screenshot_bytes = b"\x89PNGfake"
        result = await screenshot(ctx, full_page=True)
        assert result.startswith("data:image/png;base64,")
        payload = result.removeprefix("data:image/png;base64,")
        assert base64.b64decode(payload) == b"\x89PNGfake"
        # full_page=True propagated.
        calls = [c for c in session.page.calls if c.method == "screenshot"]
        assert calls[0].kwargs.get("full_page") is True
    finally:
        await pool.stop()


async def test_screenshot_over_1mb_raises() -> None:
    pool = await _started_pool()
    try:
        ctx = _make_ctx(pool)
        session = await pool.acquire("alice", "main")
        session.page.screenshot_bytes = b"x" * (1_000_001)
        with pytest.raises(BrowserError) as ei:
            await screenshot(ctx)
        assert "1" in str(ei.value)  # message should name the cap/size
    finally:
        await pool.stop()


# ---------------------------------------------------------------------------
# extract_links
# ---------------------------------------------------------------------------


async def test_extract_links_returns_json_array() -> None:
    pool = await _started_pool()
    try:
        ctx = _make_ctx(pool)
        session = await pool.acquire("alice", "main")
        session.page.links = [
            {"text": "home", "href": "https://example.org/"},
            {"text": "docs", "href": "http://docs.example.org/"},
        ]
        result = await extract_links(ctx)
        parsed = json.loads(result)
        assert parsed == [
            {"text": "home", "href": "https://example.org/"},
            {"text": "docs", "href": "http://docs.example.org/"},
        ]
    finally:
        await pool.stop()


async def test_extract_links_default_filters_non_http_schemes() -> None:
    pool = await _started_pool()
    try:
        ctx = _make_ctx(pool)
        session = await pool.acquire("alice", "main")
        session.page.links = [
            {"text": "home", "href": "https://example.org/"},
            {"text": "js", "href": "javascript:alert(1)"},
            {"text": "data", "href": "data:text/plain,hi"},
            {"text": "file", "href": "file:///etc/passwd"},
            {"text": "email", "href": "mailto:a@b.c"},
        ]
        result = await extract_links(ctx)
        parsed = json.loads(result)
        assert parsed == [{"text": "home", "href": "https://example.org/"}]
    finally:
        await pool.stop()


async def test_extract_links_with_mailto_opt_in() -> None:
    pool = await _started_pool()
    try:
        ctx = _make_ctx(pool)
        session = await pool.acquire("alice", "main")
        session.page.links = [
            {"text": "home", "href": "https://example.org/"},
            {"text": "email", "href": "mailto:a@b.c"},
        ]
        result = await extract_links(ctx, schemes=["http", "https", "mailto"])
        parsed = json.loads(result)
        assert {"text": "email", "href": "mailto:a@b.c"} in parsed
    finally:
        await pool.stop()


# ---------------------------------------------------------------------------
# wait_for_selector
# ---------------------------------------------------------------------------


async def test_wait_for_selector_happy_returns_visible() -> None:
    pool = await _started_pool()
    try:
        ctx = _make_ctx(pool)
        result = await wait_for_selector(ctx, "#el", timeout_ms=5000)
        assert result == "visible"
        session = await pool.acquire("alice", "main")
        calls = [c for c in session.page.calls if c.method == "wait_for_selector"]
        assert calls[0].args == ("#el",)
        assert calls[0].kwargs.get("timeout") == 5000
    finally:
        await pool.stop()


async def test_wait_for_selector_timeout_raises() -> None:
    pool = await _started_pool()
    try:
        ctx = _make_ctx(pool)
        session = await pool.acquire("alice", "main")

        class _PwTimeout(Exception):
            pass

        session.page.wait_raises = _PwTimeout("no element")
        with pytest.raises(_PwTimeout):
            await wait_for_selector(ctx, "x", timeout_ms=1)
    finally:
        await pool.stop()


# ---------------------------------------------------------------------------
# evaluate_js (gated)
# ---------------------------------------------------------------------------


async def test_evaluate_js_disabled_raises_without_calling_page() -> None:
    pool = await _started_pool(allow_evaluate_js=False)
    try:
        ctx = _make_ctx(pool)
        with pytest.raises(BrowserEvaluateJsDisabledError):
            await evaluate_js(ctx, "1+1")
        session = await pool.acquire("alice", "main")
        assert [c for c in session.page.calls if c.method == "evaluate"] == []
    finally:
        await pool.stop()


async def test_evaluate_js_enabled_returns_stringified_result() -> None:
    pool = await _started_pool(allow_evaluate_js=True)
    try:
        ctx = _make_ctx(pool)
        session = await pool.acquire("alice", "main")
        session.page.evaluate_result = 2
        result = await evaluate_js(ctx, "1+1")
        assert result == "2"
        calls = [c for c in session.page.calls if c.method == "evaluate"]
        assert calls[0].args == ("1+1",)
    finally:
        await pool.stop()


async def test_evaluate_js_enabled_returns_json_for_dict_result() -> None:
    pool = await _started_pool(allow_evaluate_js=True)
    try:
        ctx = _make_ctx(pool)
        session = await pool.acquire("alice", "main")
        session.page.evaluate_result = {"a": 1, "b": [1, 2]}
        result = await evaluate_js(ctx, "({a:1,b:[1,2]})")
        assert json.loads(result) == {"a": 1, "b": [1, 2]}
    finally:
        await pool.stop()


# ---------------------------------------------------------------------------
# Missing pool
# ---------------------------------------------------------------------------


async def test_missing_pool_raises_clear_error() -> None:
    ctx = _make_ctx(None)
    with pytest.raises(BrowserError) as ei:
        await browse(ctx, "https://example.org")
    assert "ZenoApp(browser" in str(ei.value)


# ---------------------------------------------------------------------------
# Session lock serialization
# ---------------------------------------------------------------------------


async def test_concurrent_tool_calls_serialize_via_session_lock() -> None:
    """Two tool calls against the same session must run under its lock —
    the second cannot start until the first releases.
    """
    from zeno.tools_browser.testing import _FakePageRecord

    pool = await _started_pool()
    try:
        ctx = _make_ctx(pool)
        session = await pool.acquire("alice", "main")

        release = asyncio.Event()
        slow_entered = asyncio.Event()

        async def slow_click(selector: str, **kwargs: Any) -> None:
            session.page.calls.append(
                _FakePageRecord(method="click", args=(selector,), kwargs=kwargs)
            )
            if selector == "#slow":
                slow_entered.set()
                await release.wait()

        session.page.click = slow_click

        async def _click(sel: str) -> Any:
            return await click(ctx, sel)

        t1 = asyncio.create_task(_click("#slow"))
        await slow_entered.wait()  # t1 holds session.lock and is blocked on release
        t2 = asyncio.create_task(_click("#fast"))
        # Yield enough event-loop ticks for t2 to schedule and reach
        # `async with session.lock:`. asyncio.sleep(0) is deterministic
        # (yields to ready tasks) — wall-clock sleeps were flaky on Windows.
        for _ in range(20):
            await asyncio.sleep(0)
            if t2.done():
                break
        assert not t2.done(), "t2 must still be waiting on the held lock"
        release.set()
        await asyncio.gather(t1, t2)

        # Recorded order: #slow then #fast.
        click_methods = [c for c in session.page.calls if c.method == "click"]
        assert [c.args[0] for c in click_methods] == ["#slow", "#fast"]
    finally:
        await pool.stop()
