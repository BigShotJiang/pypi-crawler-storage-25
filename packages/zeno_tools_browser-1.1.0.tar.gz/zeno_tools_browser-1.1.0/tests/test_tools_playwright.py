"""Real-Playwright tool integration test.

Gated behind ``@pytest.mark.playwright`` so the main ``test`` CI job
stays fast. The dedicated ``test-playwright`` job installs Chromium
via ``playwright install --with-deps chromium`` before running this.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest
from zeno.context import Ctx
from zeno.tools_browser.pool import BrowserSessionPool
from zeno.tools_browser.tools import browse, read_text


@pytest.mark.playwright
async def test_browse_and_read_text_roundtrip() -> None:
    """Real Chromium: browse + read_text against a data URL returns the expected body."""
    pool = BrowserSessionPool(headless=True)
    await pool.start()
    try:
        transport = httpx.MockTransport(lambda _req: httpx.Response(200))
        http = httpx.AsyncClient(transport=transport)
        ctx = Ctx(
            user_id="alice",
            session_id=None,
            channel="test",
            memory=MagicMock(),
            reply=AsyncMock(),
            stream=AsyncMock(),
            finalize=AsyncMock(),
            http=http,
            logger=MagicMock(),
            tracer=MagicMock(),
            state={"browser": pool},
            thread_key="main",
        )
        # data: URLs are denied by browse's built-in scheme check, so
        # use a plain http(s) URL that Playwright can render instantly.
        # about:blank is fine — we just need a loaded page to exercise
        # read_text without relying on network.
        await browse(ctx, "https://example.org")
        body = await read_text(ctx)
        assert "Example Domain" in body or "Example" in body
    finally:
        await pool.stop()
