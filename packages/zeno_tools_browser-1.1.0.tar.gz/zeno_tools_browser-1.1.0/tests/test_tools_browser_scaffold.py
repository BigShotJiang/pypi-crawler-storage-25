"""Smoke tests for the zeno-tools-browser scaffold (U1)."""

from __future__ import annotations

import sys


def test_package_imports_cleanly() -> None:
    """Public package is importable and reports a non-empty version."""
    import zeno.tools_browser as pkg

    assert isinstance(pkg.__version__, str)
    assert pkg.__version__


def test_no_playwright_import_at_module_load() -> None:
    """Importing zeno.tools_browser must not pull in playwright.

    The full Playwright import only happens when an agent or app calls
    ``BrowserSessionPool.start()`` — enforced so apps that have the
    extra installed but never wire ``ZenoApp(browser=...)`` don't pay
    the import cost.
    """
    # Clear any previously-cached import to keep this test order-independent.
    for mod in list(sys.modules):
        if mod.startswith("playwright"):
            del sys.modules[mod]

    import zeno.tools_browser  # noqa: F401

    playwright_mods = [m for m in sys.modules if m.startswith("playwright")]
    assert not playwright_mods, (
        f"Importing zeno.tools_browser leaked Playwright modules: {playwright_mods}"
    )
