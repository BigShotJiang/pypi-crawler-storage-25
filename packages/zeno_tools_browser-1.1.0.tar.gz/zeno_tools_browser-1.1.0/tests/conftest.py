"""Pytest fixtures for zeno-tools-browser tests."""

from __future__ import annotations

import sys
from pathlib import Path

# Make the tests/ directory importable so test helper modules (e.g. _fakes)
# can be imported directly by test files.
_tests_dir = str(Path(__file__).parent)
if _tests_dir not in sys.path:
    sys.path.insert(0, _tests_dir)
