# zeno-tools-browser

Pooled-Playwright browser tools. Nine always-on wrappers (`browse`, `click`, `type_text`, `fill_form`, `read_text`, `screenshot`, `extract_links`, `wait_for_selector`, `press_key`) plus a gated `evaluate_js`.

## Pool model

`BrowserSessionPool` manages one Playwright `Page` per `(user_id, thread_key)`. Sessions:

- Are wired into `ctx.state["browser"]` by `ZenoApp(browser=...)`.
- Hold a per-session `asyncio.Lock` so concurrent tool calls against the same page serialize.
- Outlive a single turn — the pool is what survives, not the session.

Tools must acquire the session lock around every Playwright call. Don't reach past it.

## Injection mitigations

Treat agent-driven browser tools as a confused-deputy risk. The mitigations baked into this package:

- **`evaluate_js` is opt-in.** `BrowserSessionPool(allow_evaluate_js=True)` is required to use it. Default-off.
- **URL scheme allowlist.** `extract_links` filters to `http`/`https` by default. `javascript:`, `data:`, `file:`, `mailto:` are dropped unless the app opts in.
- **Screenshot byte cap.** 1 MB. Larger payloads bloat model context and usually mean someone screenshotted a full long page.
- **Domain errors stop at the boundary.** Translate Playwright exceptions into `BrowserError` / `BrowserUrlDeniedError` / `BrowserEvaluateJsDisabledError` before they reach the agent. Don't leak Playwright types up.

When adding a new tool: think through what an adversarial page can make the agent do with it. If the answer involves exfiltration or arbitrary navigation, gate it behind a pool flag.

## Dependencies

- `playwright>=1.40,<2` — pre-1.0 cap per root `AGENTS.md` § Dependency policy.
- `zeno-core` (lockstep version).

Browser binaries are not a runtime dep — users install them with `playwright install chromium` after `pip install zeno-tools-browser`. Document this in the README.

## Testing

`tests/test_pool.py` covers concurrency. Use the `FakeBrowser` fixtures in `src/zeno/tools_browser/testing.py` for tool-level tests — driving real Chromium in unit tests is too slow and flaky. End-to-end browser coverage lives in `apps/zeno-example-browser/`.
