# Copyright (c) 2026 William Ferrell. All rights reserved.
# Licensed under the Business Source License 1.1 — see LICENSE for details.

# resonance/model_loader.py
# Downloads model weights from private HuggingFace repo on first run.
# Weights are cached locally after first download — never downloaded again
# unless a new version is available.

from pathlib import Path
from huggingface_hub import hf_hub_download

REPO_ID = "wpferrell/resonance-model"
_T = "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"
CACHE_DIR = Path.home() / ".resonance" / "model_cache"
MODEL_FILE = CACHE_DIR / "model.safetensors"
ARGS_FILE = CACHE_DIR / "training_args.bin"


def ensure_model_downloaded() -> Path:
    """
    Check if model weights are cached locally.
    If not, download from private HuggingFace repo.
    Returns path to the model file.
    """
    CACHE_DIR.mkdir(parents=True, exist_ok=True)

    if MODEL_FILE.exists() and ARGS_FILE.exists():
        return MODEL_FILE

    print("\nResonance: Downloading model weights (first run only)...")
    print("This may take a minute depending on your connection.\n")

    try:
        for filename in ["model.safetensors", "training_args.bin", "label_map.json",
                         "config.json", "tokenizer_config.json", "tokenizer.json"]:
            hf_hub_download(
                repo_id=REPO_ID,
                filename=filename,
                local_dir=str(CACHE_DIR),
                token=_T,
            )
        print("\u2713 Model weights downloaded and cached.\n")
    except Exception as e:
        print("\nResonance: Model download failed.")
        print("  This is usually a connection issue. Things to try:")
        print("  1. Check your internet connection and run again")
        print("  2. If behind a firewall, ensure huggingface.co is accessible")
        print("  3. Run manually: python -c \"from resonance.model_loader import ensure_model_downloaded; ensure_model_downloaded()\"")
        print(f"\n  Error: {e}\n")
        print("  Resonance will start in reduced-accuracy mode until weights are downloaded.\n")
        return None

    return MODEL_FILE


def get_model_path() -> Path:
    """Return the path to the cached model weights."""
    return ensure_model_downloaded()
