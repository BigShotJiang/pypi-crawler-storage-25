"""
Cap Table tools — funds, rounds, stakeholders, securities, transactions.

Read + Create only (no update/delete via MCP — admin manages lifecycle via UI).
"""

from typing import Literal

from ..server import mcp
from ..client import v7


# ==========================================
# Funds
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def list_funds() -> str:
    """List all investment funds."""
    result = await v7.get("/api/assetmanager/captable/funds")
    items = result.get("data", [])

    if not items:
        return "No funds found."

    lines = [f"Funds ({len(items)}):"]
    for f in items:
        lines.append(f"  - {f['name']} (id={f['id']}, status={f.get('status', '—')}, currency={f.get('currency', '—')})")

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def get_fund(fund_id: int) -> str:
    """Get details of a specific fund by ID."""
    result = await v7.get(f"/api/assetmanager/captable/funds/{fund_id}")
    f = result.get("data")

    if not f:
        return f"Fund {fund_id} not found."

    return (
        f"Fund: {f['name']} (id={f['id']})\n"
        f"  Status: {f.get('status', '—')}\n"
        f"  Currency: {f.get('currency', '—')}\n"
        f"  Vintage: {f.get('vintage', '—')}\n"
        f"  Description: {f.get('description', '—')}"
    )


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def create_fund(
    name: str,
    currency: str = "USD",
    status: Literal["Active", "Fundraising", "Closed", "Liquidating"] = "Active",
    vintage: int | None = None,
    description: str | None = None,
) -> str:
    """Create a new investment fund."""
    payload: dict = {"name": name, "currency": currency, "status": status}
    if vintage is not None:
        payload["vintage"] = vintage
    if description:
        payload["description"] = description

    result = await v7.post("/api/assetmanager/captable/funds", payload)
    f = result["data"]
    return f"Fund created: {f['name']} (id={f['id']}, currency={f['currency']}, status={f['status']})."


# ==========================================
# Rounds
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def list_rounds() -> str:
    """List all funding rounds across all funds."""
    result = await v7.get("/api/assetmanager/captable/rounds")
    items = result.get("data", [])

    if not items:
        return "No rounds found."

    lines = [f"Rounds ({len(items)}):"]
    for r in items:
        lines.append(f"  - {r['roundName']} (id={r['id']}, type={r.get('roundType', '—')}, fund_id={r['fundId']}, date={r.get('roundDate', '—')})")

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def create_round(
    fund_id: int,
    round_name: str,
    round_type: Literal["Seed", "Series A", "Series B", "Series C", "Bridge", "Debt", "Convertible", "Other"],
    round_date: str,
) -> str:
    """Create a new funding round. Date format: YYYY-MM-DD."""
    result = await v7.post("/api/assetmanager/captable/rounds", {
        "fundId": fund_id,
        "roundName": round_name,
        "roundType": round_type,
        "roundDate": round_date,
    })
    r = result["data"]
    return f"Round created: {r['roundName']} (id={r['id']}, type={r['roundType']})."


# ==========================================
# Stakeholders
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def list_stakeholders() -> str:
    """List all stakeholders."""
    result = await v7.get("/api/assetmanager/captable/stakeholders")
    items = result.get("data", [])

    if not items:
        return "No stakeholders found."

    lines = [f"Stakeholders ({len(items)}):"]
    for s in items:
        lines.append(f"  - {s['stakeholderName']} (id={s['id']}, type={s.get('type', '—')})")

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def create_stakeholder(
    stakeholder_name: str,
    type: Literal["Investor", "Founder", "Employee", "Advisor", "Board Member"] = "Investor",
) -> str:
    """Add a stakeholder."""
    result = await v7.post("/api/assetmanager/captable/stakeholders", {
        "stakeholderName": stakeholder_name,
        "type": type,
    })
    s = result["data"]
    return f"Stakeholder created: {s['stakeholderName']} (id={s['id']}, type={s['type']})."


# ==========================================
# Securities
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def list_securities() -> str:
    """List all securities across all rounds."""
    result = await v7.get("/api/assetmanager/captable/securities")
    items = result.get("data", [])

    if not items:
        return "No securities found."

    lines = [f"Securities ({len(items)}):"]
    for s in items:
        price = f", price={s['issuePrice']}" if s.get("issuePrice") else ""
        lines.append(f"  - {s['securityName']} (id={s['id']}, code={s['code']}, type={s['securityType']}, round_id={s['roundId']}{price})")

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def create_security(
    round_id: int,
    security_name: str,
    code: str,
    security_type: Literal["Common Stock", "Preferred Stock", "Convertible Note", "SAFE", "Warrant", "Option", "Bond"],
    currency: str = "USD",
    issue_price: float | None = None,
) -> str:
    """Create a new security class under a funding round."""
    payload: dict = {
        "roundId": round_id,
        "securityName": security_name,
        "code": code,
        "securityType": security_type,
        "currency": currency,
    }
    if issue_price is not None:
        payload["issuePrice"] = issue_price

    result = await v7.post("/api/assetmanager/captable/securities", payload)
    s = result["data"]
    return f"Security created: {s['securityName']} (id={s['id']}, type={s['securityType']}, code={s['code']})."


# ==========================================
# Transactions
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def list_transactions() -> str:
    """List all security transactions."""
    result = await v7.get("/api/assetmanager/captable/transactions")
    items = result.get("data", [])

    if not items:
        return "No transactions found."

    lines = [f"Transactions ({len(items)}):"]
    for t in items:
        ref = t.get("transactionReference", "—")
        ttype = t.get("transactionType", "—")
        date = t.get("transactionDate", "—")
        lines.append(f"  - {ref} | {ttype} | {date} | debit={t.get('amountDebit', 0)} credit={t.get('amountCredit', 0)}")

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def create_transaction(
    stakeholder_id: int,
    security_id: int,
    fund_id: int,
    round_id: int,
    transaction_type: Literal["Issuance", "Transfer", "Redemption", "Conversion", "Exercise", "Cancellation"],
    transaction_date: str,
    transaction_reference: str,
    amount_debit: float = 0,
    amount_credit: float = 0,
    units_debit: float = 0,
    units_credit: float = 0,
    notes: str | None = None,
) -> str:
    """Create a security transaction. Date format: YYYY-MM-DD. transaction_reference must be unique."""
    payload: dict = {
        "stakeholderId": stakeholder_id,
        "securityId": security_id,
        "fundId": fund_id,
        "roundId": round_id,
        "transactionType": transaction_type,
        "transactionDate": transaction_date,
        "transactionReference": transaction_reference,
        "amountDebit": amount_debit,
        "amountCredit": amount_credit,
        "unitsDebit": units_debit,
        "unitsCredit": units_credit,
    }
    if notes:
        payload["notes"] = notes

    result = await v7.post("/api/assetmanager/captable/transactions", payload)
    t = result["data"]
    return f"Transaction created (id={t['id']}, type={t['transactionType']}, ref={t['transactionReference']})."


# ==========================================
# Cap Table (computed view)
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def get_cap_table() -> str:
    """Get the computed cap table — ownership breakdown by stakeholder."""
    result = await v7.get("/api/assetmanager/captable/cap-table")
    rows = result.get("data", [])

    if not rows:
        return "No cap table entries. Create stakeholders and transactions first."

    lines = [f"Cap Table ({len(rows)} entries):"]
    for row in rows:
        lines.append(
            f"  - stakeholder_id={row.get('stakeholderId')} | "
            f"security_id={row.get('securityId')} | "
            f"units={row.get('totalEquityUnits', 0)} | "
            f"ownership={row.get('ownershipPercentage', 0)}%"
        )

    return "\n".join(lines)


# ==========================================
# Commitments (read-only)
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def list_commitments() -> str:
    """List all commitment invitations."""
    result = await v7.get("/api/assetmanager/captable/commitments")
    items = result.get("data", [])

    if not items:
        return "No commitments found."

    lines = [f"Commitments ({len(items)}):"]
    for c in items:
        lines.append(
            f"  - id={c['id']} | stakeholder_id={c['stakeholderId']} | "
            f"status={c['status']} | pro_rata={c.get('proRataAmount', '—')} | "
            f"committed={c.get('committedAmount', '—')}"
        )

    return "\n".join(lines)
