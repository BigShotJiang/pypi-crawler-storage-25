"""
Portfolio tools — deal pipeline (CRUD), investments, cash flows, performance (CRU).

Deal pipeline is the only model with DELETE support.
Fee costs are managed separately in fees.py.
"""

from ..server import mcp
from ..client import v7


# ==========================================
# Deal Pipeline
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def list_deal_pipeline() -> str:
    """List all deals in the pipeline."""
    result = await v7.get("/api/assetmanager/portfolio/deal-pipeline")
    items = result.get("data", [])

    if not items:
        return "No deals found in the pipeline."

    lines = [f"Deal Pipeline ({len(items)}):"]
    for d in items:
        lines.append(
            f"  - {d['dealName']} (id={d['id']}, status={d.get('status', '—')}, "
            f"priority={d.get('priority', '—')}, round={d.get('round', '—')}, "
            f"sector={d.get('sector', '—')})"
        )

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def get_deal_pipeline(deal_id: int) -> str:
    """Get details of a specific deal pipeline entry by ID."""
    result = await v7.get(f"/api/assetmanager/portfolio/deal-pipeline/{deal_id}")
    d = result.get("data")

    if not d:
        return f"Deal {deal_id} not found."

    return (
        f"Deal: {d['dealName']} (id={d['id']})\n"
        f"  Company ID: {d.get('companyId', '—')}\n"
        f"  Priority: {d.get('priority', '—')}\n"
        f"  Status: {d.get('status', '—')}\n"
        f"  Round: {d.get('round', '—')}\n"
        f"  Sector: {d.get('sector', '—')}\n"
        f"  Pre-Money Valuation: {d.get('preMoneyValuation', '—')}\n"
        f"  Post-Money Valuation: {d.get('postMoneyValuation', '—')}"
    )


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def create_deal_pipeline(
    deal_name: str,
    company_id: int | None = None,
    priority: str | None = None,
    status: str | None = None,
    round: str | None = None,
    sector: str | None = None,
    pre_money_valuation: float | None = None,
    post_money_valuation: float | None = None,
) -> str:
    """Create a new deal in the pipeline."""
    payload: dict = {"dealName": deal_name}
    if company_id is not None:
        payload["companyId"] = company_id
    if priority is not None:
        payload["priority"] = priority
    if status is not None:
        payload["status"] = status
    if round is not None:
        payload["round"] = round
    if sector is not None:
        payload["sector"] = sector
    if pre_money_valuation is not None:
        payload["preMoneyValuation"] = pre_money_valuation
    if post_money_valuation is not None:
        payload["postMoneyValuation"] = post_money_valuation

    result = await v7.post("/api/assetmanager/portfolio/deal-pipeline", payload)
    d = result["data"]
    return f"Deal created: {d['dealName']} (id={d['id']}, status={d.get('status', '—')})."


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def update_deal_pipeline(
    deal_id: int,
    deal_name: str | None = None,
    company_id: int | None = None,
    priority: str | None = None,
    status: str | None = None,
    round: str | None = None,
    sector: str | None = None,
    pre_money_valuation: float | None = None,
    post_money_valuation: float | None = None,
) -> str:
    """Update an existing deal pipeline entry by ID."""
    payload: dict = {}
    if deal_name is not None:
        payload["dealName"] = deal_name
    if company_id is not None:
        payload["companyId"] = company_id
    if priority is not None:
        payload["priority"] = priority
    if status is not None:
        payload["status"] = status
    if round is not None:
        payload["round"] = round
    if sector is not None:
        payload["sector"] = sector
    if pre_money_valuation is not None:
        payload["preMoneyValuation"] = pre_money_valuation
    if post_money_valuation is not None:
        payload["postMoneyValuation"] = post_money_valuation

    result = await v7.put(f"/api/assetmanager/portfolio/deal-pipeline/{deal_id}", payload)
    d = result["data"]
    return f"Deal updated: {d['dealName']} (id={d['id']}, status={d.get('status', '—')})."


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": True})
async def delete_deal_pipeline(deal_id: int) -> str:
    """Delete a deal pipeline entry by ID. This action is irreversible."""
    await v7.delete(f"/api/assetmanager/portfolio/deal-pipeline/{deal_id}")
    return f"Deal {deal_id} deleted."


# ==========================================
# Investments
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def list_investments() -> str:
    """List all investments."""
    result = await v7.get("/api/assetmanager/portfolio/investments")
    items = result.get("data", [])

    if not items:
        return "No investments found."

    lines = [f"Investments ({len(items)}):"]
    for i in items:
        lines.append(
            f"  - id={i['id']} | company_id={i.get('companyId', '—')} | "
            f"fund_id={i.get('fundId', '—')} | type={i.get('investmentType', '—')} | "
            f"amount={i.get('investmentAmount', '—')} | status={i.get('portfolioStatus', '—')}"
        )

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def get_investment(investment_id: int) -> str:
    """Get details of a specific investment by ID."""
    result = await v7.get(f"/api/assetmanager/portfolio/investments/{investment_id}")
    i = result.get("data")

    if not i:
        return f"Investment {investment_id} not found."

    return (
        f"Investment (id={i['id']})\n"
        f"  Company ID: {i.get('companyId', '—')}\n"
        f"  Fund ID: {i.get('fundId', '—')}\n"
        f"  Round ID: {i.get('roundId', '—')}\n"
        f"  Portfolio Status: {i.get('portfolioStatus', '—')}\n"
        f"  Investment Type: {i.get('investmentType', '—')}\n"
        f"  Sector: {i.get('sector', '—')}\n"
        f"  Investment Amount: {i.get('investmentAmount', '—')}"
    )


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def create_investment(
    company_id: int,
    fund_id: int,
    round_id: int | None = None,
    portfolio_status: str | None = None,
    investment_type: str | None = None,
    sector: str | None = None,
    investment_amount: float | None = None,
) -> str:
    """Create a new investment."""
    payload: dict = {"companyId": company_id, "fundId": fund_id}
    if round_id is not None:
        payload["roundId"] = round_id
    if portfolio_status is not None:
        payload["portfolioStatus"] = portfolio_status
    if investment_type is not None:
        payload["investmentType"] = investment_type
    if sector is not None:
        payload["sector"] = sector
    if investment_amount is not None:
        payload["investmentAmount"] = investment_amount

    result = await v7.post("/api/assetmanager/portfolio/investments", payload)
    i = result["data"]
    return f"Investment created (id={i['id']}, company_id={i.get('companyId')}, fund_id={i.get('fundId')})."


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def update_investment(
    investment_id: int,
    company_id: int | None = None,
    fund_id: int | None = None,
    round_id: int | None = None,
    portfolio_status: str | None = None,
    investment_type: str | None = None,
    sector: str | None = None,
    investment_amount: float | None = None,
) -> str:
    """Update an existing investment by ID."""
    payload: dict = {}
    if company_id is not None:
        payload["companyId"] = company_id
    if fund_id is not None:
        payload["fundId"] = fund_id
    if round_id is not None:
        payload["roundId"] = round_id
    if portfolio_status is not None:
        payload["portfolioStatus"] = portfolio_status
    if investment_type is not None:
        payload["investmentType"] = investment_type
    if sector is not None:
        payload["sector"] = sector
    if investment_amount is not None:
        payload["investmentAmount"] = investment_amount

    result = await v7.put(f"/api/assetmanager/portfolio/investments/{investment_id}", payload)
    i = result["data"]
    return f"Investment updated (id={i['id']}, company_id={i.get('companyId')}, fund_id={i.get('fundId')})."


# ==========================================
# Cash Flows
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def list_cash_flows() -> str:
    """List all cash flows."""
    result = await v7.get("/api/assetmanager/portfolio/cash-flows")
    items = result.get("data", [])

    if not items:
        return "No cash flows found."

    lines = [f"Cash Flows ({len(items)}):"]
    for c in items:
        lines.append(
            f"  - id={c['id']} | company_id={c.get('companyId', '—')} | "
            f"fund_id={c.get('fundId', '—')} | type={c.get('cashFlowType', '—')} | "
            f"date={c.get('date', '—')} | debit={c.get('amountDebit', 0)} | credit={c.get('amountCredit', 0)}"
        )

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def get_cash_flow(cash_flow_id: int) -> str:
    """Get details of a specific cash flow by ID."""
    result = await v7.get(f"/api/assetmanager/portfolio/cash-flows/{cash_flow_id}")
    c = result.get("data")

    if not c:
        return f"Cash flow {cash_flow_id} not found."

    return (
        f"Cash Flow (id={c['id']})\n"
        f"  Company ID: {c.get('companyId', '—')}\n"
        f"  Fund ID: {c.get('fundId', '—')}\n"
        f"  Round ID: {c.get('roundId', '—')}\n"
        f"  Date: {c.get('date', '—')}\n"
        f"  Amount Debit: {c.get('amountDebit', '—')}\n"
        f"  Amount Credit: {c.get('amountCredit', '—')}\n"
        f"  Cash Flow Type: {c.get('cashFlowType', '—')}"
    )


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def create_cash_flow(
    company_id: int,
    fund_id: int,
    cash_flow_type: str,
    date: str,
    round_id: int | None = None,
    amount_debit: float = 0,
    amount_credit: float = 0,
) -> str:
    """Create a new cash flow entry. Date format: YYYY-MM-DD."""
    payload: dict = {
        "companyId": company_id,
        "fundId": fund_id,
        "cashFlowType": cash_flow_type,
        "date": date,
        "amountDebit": amount_debit,
        "amountCredit": amount_credit,
    }
    if round_id is not None:
        payload["roundId"] = round_id

    result = await v7.post("/api/assetmanager/portfolio/cash-flows", payload)
    c = result["data"]
    return f"Cash flow created (id={c['id']}, type={c.get('cashFlowType')}, date={c.get('date')})."


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def update_cash_flow(
    cash_flow_id: int,
    company_id: int | None = None,
    fund_id: int | None = None,
    round_id: int | None = None,
    cash_flow_type: str | None = None,
    date: str | None = None,
    amount_debit: float | None = None,
    amount_credit: float | None = None,
) -> str:
    """Update an existing cash flow entry by ID. Date format: YYYY-MM-DD."""
    payload: dict = {}
    if company_id is not None:
        payload["companyId"] = company_id
    if fund_id is not None:
        payload["fundId"] = fund_id
    if round_id is not None:
        payload["roundId"] = round_id
    if cash_flow_type is not None:
        payload["cashFlowType"] = cash_flow_type
    if date is not None:
        payload["date"] = date
    if amount_debit is not None:
        payload["amountDebit"] = amount_debit
    if amount_credit is not None:
        payload["amountCredit"] = amount_credit

    result = await v7.put(f"/api/assetmanager/portfolio/cash-flows/{cash_flow_id}", payload)
    c = result["data"]
    return f"Cash flow updated (id={c['id']}, type={c.get('cashFlowType')}, date={c.get('date')})."


# ==========================================
# Performance
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def list_performance() -> str:
    """List all performance records."""
    result = await v7.get("/api/assetmanager/portfolio/performance")
    items = result.get("data", [])

    if not items:
        return "No performance records found."

    lines = [f"Performance ({len(items)}):"]
    for p in items:
        lines.append(
            f"  - id={p['id']} | fund_id={p.get('fundId', '—')} | "
            f"date={p.get('reportDate', '—')} | NAV={p.get('nav', '—')} | "
            f"IRR={p.get('irr', '—')} | TVPI={p.get('tvpi', '—')} | "
            f"DPI={p.get('dpi', '—')} | RVPI={p.get('rvpi', '—')}"
        )

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def get_performance(performance_id: int) -> str:
    """Get details of a specific performance record by ID."""
    result = await v7.get(f"/api/assetmanager/portfolio/performance/{performance_id}")
    p = result.get("data")

    if not p:
        return f"Performance record {performance_id} not found."

    return (
        f"Performance (id={p['id']})\n"
        f"  Fund ID: {p.get('fundId', '—')}\n"
        f"  Report Date: {p.get('reportDate', '—')}\n"
        f"  NAV: {p.get('nav', '—')}\n"
        f"  IRR: {p.get('irr', '—')}\n"
        f"  TVPI: {p.get('tvpi', '—')}\n"
        f"  DPI: {p.get('dpi', '—')}\n"
        f"  RVPI: {p.get('rvpi', '—')}"
    )


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def create_performance(
    fund_id: int,
    report_date: str,
    nav: float | None = None,
    irr: float | None = None,
    tvpi: float | None = None,
    dpi: float | None = None,
    rvpi: float | None = None,
) -> str:
    """Create a new performance record. Date format: YYYY-MM-DD."""
    payload: dict = {"fundId": fund_id, "reportDate": report_date}
    if nav is not None:
        payload["nav"] = nav
    if irr is not None:
        payload["irr"] = irr
    if tvpi is not None:
        payload["tvpi"] = tvpi
    if dpi is not None:
        payload["dpi"] = dpi
    if rvpi is not None:
        payload["rvpi"] = rvpi

    result = await v7.post("/api/assetmanager/portfolio/performance", payload)
    p = result["data"]
    return f"Performance created (id={p['id']}, fund_id={p.get('fundId')}, date={p.get('reportDate')})."


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def update_performance(
    performance_id: int,
    fund_id: int | None = None,
    report_date: str | None = None,
    nav: float | None = None,
    irr: float | None = None,
    tvpi: float | None = None,
    dpi: float | None = None,
    rvpi: float | None = None,
) -> str:
    """Update an existing performance record by ID. Date format: YYYY-MM-DD."""
    payload: dict = {}
    if fund_id is not None:
        payload["fundId"] = fund_id
    if report_date is not None:
        payload["reportDate"] = report_date
    if nav is not None:
        payload["nav"] = nav
    if irr is not None:
        payload["irr"] = irr
    if tvpi is not None:
        payload["tvpi"] = tvpi
    if dpi is not None:
        payload["dpi"] = dpi
    if rvpi is not None:
        payload["rvpi"] = rvpi

    result = await v7.put(f"/api/assetmanager/portfolio/performance/{performance_id}", payload)
    p = result["data"]
    return f"Performance updated (id={p['id']}, fund_id={p.get('fundId')}, date={p.get('reportDate')})."
