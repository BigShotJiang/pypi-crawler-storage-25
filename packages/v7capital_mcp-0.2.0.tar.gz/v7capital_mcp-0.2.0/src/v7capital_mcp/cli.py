"""
V7 Capital CLI — Interactive terminal authentication

Commands:
  v7-cli login        — Login via browser (OAuth device flow)
  v7-cli login --basic — Login with email/password in terminal (fallback)
  v7-cli logout       — Delete stored credentials
  v7-cli status       — Show current auth status
"""

import getpass
import time
import webbrowser

import click
import httpx

from .config import API_BASE_URL, REQUEST_TIMEOUT
from .credentials import load_credentials, save_credentials, delete_credentials


@click.group()
def main():
    """V7 Capital CLI — Authenticate and manage your MCP connection."""
    pass


@main.command()
@click.option("--basic", is_flag=True, help="Use email/password login instead of browser (for headless environments)")
def login(basic: bool):
    """Login to V7 Capital. Opens browser by default (OAuth device flow).
    Use --basic for email/password in terminal."""
    if basic:
        _login_basic()
    else:
        _login_device()


def _login_device():
    """Device flow: open browser, user approves, CLI polls for token."""
    try:
        with httpx.Client(timeout=REQUEST_TIMEOUT) as client:
            # Step 1: Request device code
            r = client.post(f"{API_BASE_URL}/api/auth/device-code")
            r.raise_for_status()
            device = r.json()

            device_code = device["device_code"]
            user_code = device["user_code"]
            verification_url = device["verification_url"]
            interval = device.get("interval", 2)
            expires_in = device.get("expires_in", 300)

            # Step 2: Open browser
            click.echo(f"\nOpening browser to authorize...")
            click.echo(f"If browser doesn't open, go to: {verification_url}")
            click.echo(f"Code: {user_code}\n")
            webbrowser.open(verification_url)

            # Step 3: Poll for token
            click.echo("Waiting for authorization", nl=False)
            start = time.time()
            while time.time() - start < expires_in:
                time.sleep(interval)
                click.echo(".", nl=False)

                r = client.post(
                    f"{API_BASE_URL}/api/auth/device-token",
                    json={"device_code": device_code},
                )
                data = r.json()

                if data.get("success"):
                    click.echo("")  # newline after dots

                    # Check if needs basic login fallback
                    if data.get("needs_basic_login"):
                        click.echo(f"\nDevice approved for {data.get('user_email')}.")
                        click.echo("Please complete login with your password:\n")
                        _login_basic_with_email(data["user_email"])
                        return

                    save_credentials({
                        "access_token": data["access_token"],
                        "refresh_token": data["refresh_token"],
                        "user_email": data.get("user_email", ""),
                    })

                    click.echo(f"\n✓ Logged in as {data.get('user_email', 'unknown')}")
                    click.echo("✓ Credentials saved to ~/.v7capital/credentials.json")
                    click.echo(f"\nAPI: {API_BASE_URL}")
                    return

                error = data.get("error", "")
                if error == "authorization_pending":
                    continue
                elif error == "expired_token":
                    click.echo("\nError: Code expired. Please try again.", err=True)
                    raise SystemExit(1)
                elif error == "access_denied":
                    click.echo("\nError: Authorization denied.", err=True)
                    raise SystemExit(1)
                else:
                    click.echo(f"\nError: {error}", err=True)
                    raise SystemExit(1)

            click.echo("\nError: Timed out waiting for authorization.", err=True)
            raise SystemExit(1)

    except httpx.ConnectError:
        click.echo(f"Error: Cannot connect to {API_BASE_URL}. Is the server running?", err=True)
        raise SystemExit(1)


def _login_basic():
    """Basic flow: email/password in terminal (fallback for headless environments)."""
    email = click.prompt("Email")
    _login_basic_with_email(email)


def _login_basic_with_email(email: str):
    """Basic login with known email — prompts for password."""
    password = getpass.getpass("Password: ")

    click.echo("Logging in...")

    try:
        with httpx.Client(timeout=REQUEST_TIMEOUT) as client:
            r = client.post(
                f"{API_BASE_URL}/api/auth/login",
                json={"email": email, "password": password},
            )

            if r.status_code == 401:
                click.echo("Error: Invalid email or password.", err=True)
                raise SystemExit(1)

            r.raise_for_status()
            data = r.json()

            if not data.get("success"):
                click.echo(f"Error: {data.get('error', 'Login failed')}", err=True)
                raise SystemExit(1)

            save_credentials({
                "access_token": data["access_token"],
                "refresh_token": data["refresh_token"],
                "user_email": data.get("user_email", email),
            })

            click.echo(f"\n✓ Logged in as {data.get('user_email', email)}")
            click.echo("✓ Credentials saved to ~/.v7capital/credentials.json")
            click.echo(f"\nAPI: {API_BASE_URL}")

    except httpx.HTTPStatusError as e:
        click.echo(f"Error: API returned {e.response.status_code}", err=True)
        raise SystemExit(1)
    except httpx.ConnectError:
        click.echo(f"Error: Cannot connect to {API_BASE_URL}. Is the server running?", err=True)
        raise SystemExit(1)


@main.command()
def logout():
    """Delete stored credentials."""
    delete_credentials()
    click.echo("✓ Logged out. Credentials deleted.")


@main.command()
def status():
    """Show current authentication status."""
    creds = load_credentials()
    if not creds:
        click.echo("Not authenticated. Run 'v7-cli login' first.")
        return

    click.echo(f"Email: {creds.get('user_email', 'unknown')}")
    click.echo(f"API: {API_BASE_URL}")
    click.echo(f"Token: {'present' if creds.get('access_token') else 'missing'}")
    click.echo(f"Refresh token: {'present' if creds.get('refresh_token') else 'missing'}")
