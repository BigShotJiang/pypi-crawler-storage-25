import os

VERBOSE = True if os.getenv("VERBOSE", "False").lower() == "true" else False

# Log *******************************************************************************
LOG_ENABLE = True if os.getenv("LOG_ENABLE", "False").lower() == "true" else False
RABBITMQ_USER = os.getenv("RABBITMQ_USER")
RABBITMQ_PASSWORD = os.getenv("RABBITMQ_PASSWORD")
RABBITMQ_HOST = os.getenv("RABBITMQ_HOST")
RABBITMQ_VHOST = os.getenv("RABBITMQ_VHOST")
LOG_EXCHANGE = os.getenv("LOG_EXCHANGE")
LOG_REQUESTS_QUEUE = os.getenv("LOG_REQUESTS_QUEUE")
SERVICE_NAME = os.getenv("SERVICE_NAME")
IP_HEADER_NAME = os.getenv("IP_HEADER_NAME")
DB_HEALTH_CHECK_INTERVAL = int(os.getenv("DB_HEALTH_CHECK_INTERVAL", 15))

# IP Session ************************************************************************
IP_SESSION_AUTH_ENABLE = True if os.getenv("IP_SESSION_AUTH_ENABLE", "False").lower() == "true" else False
APIKEY_HEADER_NAME = os.getenv("APIKEY_HEADER_NAME")
WHITE_LIST_IP = os.getenv("WHITE_LIST_IP") #192.168.0.0/16, 10.0.0.0/24, 11.22.33.44
IP_SESSION_CACHE_DATABASE_NUMBER = os.getenv("IP_SESSION_CACHE_DATABASE_NUMBER")


# REDIS *****************************************************************************
REDIS_URL = os.getenv("REDIS_URL")
REDIS_PASSWORD = os.getenv("REDIS_PASSWORD")
REDIS_USER = os.getenv("REDIS_USER")
REDIS_CONNECTION_STRING = os.getenv("REDIS_CONNECTION_STRING")
CACHE_DATABASE_NUMBER = os.getenv("CACHE_DATABASE_NUMBER")
REDIS_CONNECTION_STRING = os.getenv(
    "REDIS_CONNECTION_STRING", f"redis://{REDIS_USER}:{REDIS_PASSWORD}@{REDIS_URL}"
)
CACHE_EXPIRE_TIME_HOURS = int(os.getenv("CACHE_EXPIRE_TIME_HOURS", 24))
REDIS_SENTINELS = os.getenv("REDIS_SENTINELS")
REDIS_MASTER_NAME = os.getenv("REDIS_MASTER_NAME")
REDIS_CLUSTER_NODES = os.getenv("REDIS_CLUSTER_NODES")
REDIS_MODE = os.getenv("REDIS_MODE") # sentinel / cluster / standalone