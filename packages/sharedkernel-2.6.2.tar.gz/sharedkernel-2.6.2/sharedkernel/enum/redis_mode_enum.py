
from enum import Enum

class RedisMode(str, Enum):
    SENTINEL = "sentinel"
    CLUSTER = "cluster"
    STANDALONE = "standalone"
    