from typing import Generic, List, Optional, Tuple, Type, TypeVar

import redis
from pydantic import BaseModel
from redis import Redis
from redis.sentinel import Sentinel
from redis.cluster import RedisCluster, ClusterNode
from sharedkernel.exception.exception import BusinessException

from sharedkernel import config
from sharedkernel.enum import ErrorCode, RedisMode

T = TypeVar("T", bound=BaseModel)


from typing import List, Tuple

def parse_nodes(value: str) -> List[Tuple[str, int]]:
    if not value:
        return []

    sentinels = []
    for item in value.split(","):
        item = item.strip()

        if ":" in item:
            host, port = item.rsplit(":", 1)
            port = int(port)
        else:
            host = item
            port = 6379

        sentinels.append((host, port))

    return sentinels



def get_redis_client(cache_database_number=config.CACHE_DATABASE_NUMBER) -> Redis:
    redis_mode = config.REDIS_MODE
    if redis_mode == RedisMode.SENTINEL:
        sentinels = parse_nodes(config.REDIS_SENTINELS)

        sentinel = Sentinel(sentinels)
        return sentinel.master_for(
            service_name=config.REDIS_MASTER_NAME,
            db=cache_database_number,
            username=config.REDIS_USER,
            password=config.REDIS_PASSWORD,
            # decode_responses=True,
        )

    elif redis_mode == RedisMode.CLUSTER:
        nodes = parse_nodes(config.REDIS_CLUSTER_NODES)

        startup_nodes = [ClusterNode(host=h, port=p) for h, p in nodes]

        return RedisCluster(
            startup_nodes=startup_nodes,
            username=config.REDIS_USER,
            password=config.REDIS_PASSWORD,
        )
    
    else:
        return redis.Redis.from_url(
            url=f"{config.REDIS_CONNECTION_STRING}/{cache_database_number}"
        )



class DistributedCache(Generic[T]):
    def __init__(
        self,
        namespace: str,
        model: Type[T],
        expire_time_hour: int = config.CACHE_EXPIRE_TIME_HOURS,
    ):
        """
        :param namespace:        Prefix for the key
        :param model:            The Pydantic model class to store/retrieve
        :param expire_time_hour: Time-to-live for each item in hours
        """

        self.client = get_redis_client()
        if not self.client.ping():
            raise BusinessException(ErrorCode.Internal_Server)

        self.namespace = namespace
        self.model = model
        self.expire_time = self.expire_time_to_seconds(expire_time_hour)

    def expire_time_to_seconds(self, hours: int) -> int:
        return hours * 60 * 60

    def _pref(self, key: str) -> str:
        return f"{self.namespace}:{key}"

    def _serialize(self, value: T) -> str:
        return value.model_dump_json()

    def _deserialize(self, raw: bytes) -> T:
        return self.model.model_validate_json(raw.decode())

    def set(self, key: str, value: T) -> None:
        if value is None:
            return
        skey = self._pref(key)
        payload = self._serialize(value)
        self.client.set(skey, payload, ex=self.expire_time)

    def get(self, key: str) -> Optional[T]:
        skey = self._pref(key)
        raw = self.client.get(skey)
        if raw is None:
            return None
        return self._deserialize(raw)

    def get_all_ids(self) -> list[str]:
        return [
            raw.decode().split(":")[1]
            for raw in self.client.scan_iter(f"{self.namespace}:*")
        ]

    def exists(self, key: str) -> bool:
        skey = self._pref(key)
        return self.client.exists(skey)

    def delete(self, key):
        self.client.delete(key)
        
    def delete_group(self, key_prefix: str):
        pattern = f"{self.namespace}:{key_prefix}*"
        for k in self.client.scan_iter(pattern):
            self.client.delete(k)

    def clear(self):
        for k in self.client.scan_iter(f"{self.namespace}:*"):
            self.client.delete(k)
