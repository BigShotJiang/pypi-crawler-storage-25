import time
import threading
from typing import Callable, Optional
from pymongo.errors import PyMongoError

from sharedkernel import config

class MongoHealthChecker:
    def __init__(
        self,
        client,
        interval: int = config.DB_HEALTH_CHECK_INTERVAL,
        on_connect: Optional[Callable[[], None]] = None,
        on_disconnect: Optional[Callable[[Exception], None]] = None,
    ):

        self.client = client
        self.interval = interval
        self.on_connect = on_connect
        self.on_disconnect = on_disconnect

        self._is_connected = None
        self._thread = None
        self._stop_event = threading.Event()

    def _default_on_connect(self):
        print(f"Mongo connected")

    def _default_on_disconnect(self, error):
        print(f"Mongo DISCONNECTED: {error}")

    def _run(self):
        db = self.client.admin

        while not self._stop_event.is_set():
            try:
                db.command("ping")

                if self._is_connected is not True:
                    (self.on_connect or self._default_on_connect)()
                    self._is_connected = True

            except PyMongoError as e:
                if self._is_connected is not False:
                    (self.on_disconnect or self._default_on_disconnect)()
                    self._is_connected = False

            time.sleep(self.interval)

    def start(self):
        if self._thread and self._thread.is_alive():
            return

        self._stop_event.clear()

        self._thread = threading.Thread(
            target=self._run,
            daemon=True
        )
        self._thread.start()

    def stop(self):
        if not self._thread:
            return

        self._stop_event.set()
        self._thread.join()