import json
import ipaddress
from typing import List
from fastapi import Request
from sharedkernel.exception.exception import UnAuthorizedException, BusinessException
from sharedkernel.database.distributed_cache import get_redis_client
from sharedkernel.logger.log_decorator import unified_logger
from sharedkernel.enum import ErrorCode
from sharedkernel import config


class IPSessionAuth:

    def __init__(self):
        self.redis = get_redis_client(cache_database_number=config.IP_SESSION_CACHE_DATABASE_NUMBER)
        self.whitelist_networks = self._load_whitelist(config.WHITE_LIST_IP)


    def _load_whitelist(self, raw_value):
        if not raw_value:
            return []

        entries = [e.strip() for e in raw_value.split(",") if e.strip()]

        networks = []

        for entry in entries:
            try:
                if "/" in entry:
                    networks.append(ipaddress.ip_network(entry, strict=False))

                else:
                    ip = ipaddress.ip_address(entry)
                    networks.append(ipaddress.ip_network(f"{ip}/32"))

            except ValueError:
                raise BusinessException(ErrorCode.Unsupported_IP)

        return networks


    def _is_ip_allowed(self, ip_str: str) -> bool:
        try:
            ip = ipaddress.ip_address(ip_str)
        except ValueError:
            raise BusinessException(ErrorCode.Unsupported_IP)

        return any(ip in net for net in self.whitelist_networks)


    def _get_lifetime(self) -> int:
        try:
            raw = self.redis.get("settings_v1")
            data = json.loads(raw.decode())

            lifetime = data.get("AccessTokenLifetimeInMinutes")

            return int(lifetime)

        except (ValueError, TypeError, json.JSONDecodeError):
            raise BusinessException(ErrorCode.Internal_Server)

    
    @unified_logger()
    def ip_session_auth(self, request: Request):

        if not config.IP_SESSION_AUTH_ENABLE:
            if config.VERBOSE:
                print("IP_SESSION_AUTH | OK | IP Session Auth is disabled")
            return

        if config.VERBOSE:
            print("IP_SESSION_AUTH | INFO | Request Headers: ", request.headers)

        api_key = request.headers.get(config.APIKEY_HEADER_NAME)

        if api_key:
            if config.VERBOSE:
                print("IP_SESSION_AUTH | OK | API Key is provided")
            return

        state = getattr(request.state, "decoded_token", None)
        if config.VERBOSE:
            print("IP_SESSION_AUTH | INFO | State: ", state)

        if not state:
            if config.VERBOSE:
                print("IP_SESSION_AUTH | ERROR | No state found")
            raise UnAuthorizedException()

        nameid = state.get("nameid")
        sessionid = state.get("sessionId")
        if config.VERBOSE:
            print("IP_SESSION_AUTH | INFO | Nameid: ", nameid)
            print("IP_SESSION_AUTH | INFO | Sessionid: ", sessionid)

        if not nameid or not sessionid:
            if config.VERBOSE:
                print("IP_SESSION_AUTH | ERROR | No nameid or sessionid found")
            raise UnAuthorizedException()

        request_ip = request.headers.get(config.IP_HEADER_NAME)

        if not request_ip:
            if config.VERBOSE:
                print("IP_SESSION_AUTH | ERROR | No request ip found")
            raise UnAuthorizedException()

        request_ip = request_ip.strip()
        if config.VERBOSE:
            print("IP_SESSION_AUTH | INFO | Request ip: ", request_ip)

        if self._is_ip_allowed(request_ip):
            if config.VERBOSE:
                print("IP_SESSION_AUTH | OK | IP is in whitelist")
            return

        redis_key = f"userId:{nameid}:session:{sessionid}"
        user_data = self.redis.get(redis_key)
        if config.VERBOSE:
            print("IP_SESSION_AUTH | INFO | User data: ", user_data)

        if not user_data:
            if config.VERBOSE:
                print("IP_SESSION_AUTH | ERROR | No user data found")
            raise UnAuthorizedException()

        try:
            payload = json.loads(user_data.decode())
        except (ValueError, UnicodeDecodeError, TypeError):
            if config.VERBOSE:
                print("IP_SESSION_AUTH | ERROR | Error decoding user data")
            raise UnAuthorizedException()

        stored_ip = payload.get("Ip")
        if config.VERBOSE:
            print("IP_SESSION_AUTH | INFO | Stored ip: ", stored_ip)
            
        if not stored_ip:
            if config.VERBOSE:
                print("IP_SESSION_AUTH | ERROR | No stored ip found")
            raise UnAuthorizedException()

        if stored_ip.strip() != request_ip:
            if config.VERBOSE:
                print("IP_SESSION_AUTH | ERROR | Stored ip does not match request ip")
            raise UnAuthorizedException()

        lifetime_minutes = self._get_lifetime()
        self.redis.expire(redis_key, lifetime_minutes * 60)
        if config.VERBOSE:
            print("IP_SESSION_AUTH | OK | IP session auth successful")