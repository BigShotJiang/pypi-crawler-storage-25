from enum import IntEnum

class LogEventTypeEnum(IntEnum):
    START = 1
    END = 2

class LogLevelEnum(IntEnum):
    INFORMATION = 1
    WARNING = 2
    CRITICAL = 3
    SECURITY = 4
    ERROR = 5