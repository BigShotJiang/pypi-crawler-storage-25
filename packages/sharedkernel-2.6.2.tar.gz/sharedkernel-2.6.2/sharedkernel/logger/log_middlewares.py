import uuid
from typing import Callable
from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware


from sharedkernel.logger.log_info import log_info
from sharedkernel.logger.log_dto import LogDTO
from sharedkernel import config

class LogMiddleware(BaseHTTPMiddleware):

    async def dispatch(self, request: Request, call_next: Callable) -> Response:

        if not config.LOG_ENABLE:
            return await call_next(request)

        correlation_id = request.headers.get("x-request-id") or uuid.uuid4().hex
        ip_address = request.headers.get(config.IP_HEADER_NAME)
        log_obj = LogDTO(
            CorrelationId=correlation_id,
            RequestPath=request.url.path,
            HttpMethod=request.method,
            UserAgent=request.headers.get("user-agent"),
            IpAddress=ip_address,
        )

        log_info.set(log_obj)

        response = await call_next(request)
        
        return response


    