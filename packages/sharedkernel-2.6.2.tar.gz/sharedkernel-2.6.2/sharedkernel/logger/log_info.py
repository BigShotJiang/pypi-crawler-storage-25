from contextvars import ContextVar

from sharedkernel.logger.log_dto import LogDTO

log_info: ContextVar[LogDTO] = ContextVar("log_info")