import inspect
from functools import wraps
from typing import Callable, Type
from asyncio import iscoroutinefunction

from sharedkernel.logger.logger_service import LoggerService
from sharedkernel import config


logger = LoggerService()

def decorate_class_methods(cls: Type) -> Type:
    for name, attr in cls.__dict__.items():
        if name.startswith("_"):
            continue

        if isinstance(attr, staticmethod):
            original = attr.__func__
            wrapped = unified_logger(class_name=cls.__name__)(original)
            setattr(cls, name, staticmethod(wrapped))

        elif isinstance(attr, classmethod):
            original = attr.__func__
            wrapped = unified_logger(class_name=cls.__name__)(original)
            setattr(cls, name, classmethod(wrapped))

        elif callable(attr):
            wrapped = unified_logger(class_name=cls.__name__)(attr)
            setattr(cls, name, wrapped)

    return cls



def unified_logger(endpoint_name: str = None, class_name: str = None) -> Callable:
    def decorator(target: Callable | Type):

        if not config.LOG_ENABLE:
            return target

        if inspect.isclass(target):
            return decorate_class_methods(target)

        method_name = f"{class_name}.{target.__name__}" if class_name else target.__name__

        if iscoroutinefunction(target):

            @wraps(target)
            async def async_wrapper(*args, **kwargs):
                return await logger.execute_async(target, args, kwargs, method_name, endpoint_name)

            return async_wrapper

        else:

            @wraps(target)
            def sync_wrapper(*args, **kwargs):
                return logger.execute_sync(target, args, kwargs, method_name, endpoint_name)

            return sync_wrapper

    return decorator
