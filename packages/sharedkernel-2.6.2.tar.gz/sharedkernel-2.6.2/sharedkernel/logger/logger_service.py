from fastapi import HTTPException, WebSocket
from kombu import Connection, Producer, Exchange
from pymongo import monitoring
from pydantic import BaseModel
from typing import Optional
import datetime
import uuid
import os

from sharedkernel.logger.log_info import log_info
from sharedkernel.enum import ErrorCode
from sharedkernel.objects.user_info import current_user_info
from sharedkernel.exception.exception import BusinessException
from sharedkernel.logger.log_dto import LogDTO
from sharedkernel.logger.log_enums import LogEventTypeEnum, LogLevelEnum
from sharedkernel.database.mongo_health_checker import MongoHealthChecker
from sharedkernel import config


rabbitmq_url = (
    f"amqp://{config.RABBITMQ_USER}:{config.RABBITMQ_PASSWORD}"
    f"@{config.RABBITMQ_HOST}/{config.RABBITMQ_VHOST}"
)


class LoggerService:
    def __init__(self):
        self._connection: Optional[Connection] = None
        self._producer: Optional[Producer] = None
        self._exchange = Exchange(config.LOG_EXCHANGE, type="topic")
        self.checker: Optional[MongoHealthChecker] = None


    def _ensure_connection(self):
        if not self._connection or not self._connection.connected:
            self._connection = Connection(rabbitmq_url)
            self._connection.connect()
            self._producer = Producer(self._connection)


    def publish(self, log: BaseModel):
        self._ensure_connection()

        self._producer.publish(
            body=log.model_dump_json(),
            exchange=self._exchange,
            routing_key=config.LOG_REQUESTS_QUEUE,
            headers={
                "cap-msg-id": str(uuid.uuid4()),
                "cap-msg-name": config.LOG_REQUESTS_QUEUE,
            },
            content_type="application/json",
            retry=True,
            retry_policy={
                "max_retries": 3,
                "interval_step": 2,
            }
        )
    

    def build(
        self,
        method_name: Optional[str] = None,
        event_type: Optional[LogEventTypeEnum] = None,
        endpoint_name: Optional[str] = None,
        is_success: Optional[bool] = True,
        failure_reason: Optional[str] = None,
    ) -> LogDTO:

        log = log_info.get()
        user = current_user_info.get(None)
        if user:
            log.UserId = user.nameid
        log.ServiceName = config.SERVICE_NAME
        log.MethodName = method_name
        log.Description = endpoint_name
        log.IsSuccess = is_success
        log.Level = LogLevelEnum.INFORMATION if is_success else LogLevelEnum.ERROR
        log.EventType = event_type
        log.FailureReason = failure_reason
        log.CreatedOn = datetime.datetime.now(datetime.timezone.utc)

        return log


    def map_exception(self, exc: Exception):
        if isinstance(exc, BusinessException):
            return str(exc.detail)
        if isinstance(exc, HTTPException):
            return str(exc.detail)
        return ErrorCode.Internal_Server


    def emit(self, log: LogDTO):
        # if config.VERBOSE:
        #     print("LOGGER | INFO | Emitting log:\n", log)
        self.publish(log)


    async def execute_async(self, target, args, kwargs, method_name, endpoint_name):
        self.emit(self.build(method_name, LogEventTypeEnum.START, endpoint_name))

        try:
            result = await target(*args, **kwargs)

        except Exception as exc:
            self.emit(
                self.build(
                    method_name,
                    LogEventTypeEnum.END,
                    endpoint_name,
                    is_success=False,
                    failure_reason=self.map_exception(exc),
                )
            )
            raise

        else:
            self.emit(self.build(method_name, LogEventTypeEnum.END, endpoint_name))
            return result


    def execute_sync(self, target, args, kwargs, method_name, endpoint_name):
        self.emit(self.build(method_name, LogEventTypeEnum.START, endpoint_name))

        try:
            result = target(*args, **kwargs)

        except Exception as exc:
            self.emit(
                self.build(
                    method_name,
                    LogEventTypeEnum.END,
                    endpoint_name,
                    is_success=False,
                    failure_reason=self.map_exception(exc),
                )
            )
            raise

        else:
            self.emit(self.build(method_name, LogEventTypeEnum.END, endpoint_name))
            return result

    @staticmethod
    def websocket_handler(websocket: WebSocket):
        if not config.LOG_ENABLE:
            return
        correlation_id = websocket.headers.get("x-request-id") or uuid.uuid4().hex
        ip_address = websocket.headers.get(config.IP_HEADER_NAME)

        log_obj = LogDTO(
            CorrelationId=correlation_id,
            RequestPath=websocket.url.path,
            HttpMethod="ws",
            UserAgent=websocket.headers.get("user-agent"),
            IpAddress=ip_address,
        )

        log_info.set(log_obj)


    def set_log_to_context(self, correlation_id: str = None):

        if not config.LOG_ENABLE:
            return

        log_obj = LogDTO(CorrelationId=correlation_id)
        log_info.set(log_obj)


    def _on_mongo_connect(self):
        self.set_log_to_context(correlation_id=uuid.uuid4().hex)

        log = self.build(
            method_name="mongo_health_check",
            event_type=LogEventTypeEnum.START,
            endpoint_name="اتصال به دیتابیس",
            is_success=True,
        )
        self.emit(log)


    def _on_mongo_disconnect(self):
        log = self.build(
            method_name="mongo_health_check",
            event_type=LogEventTypeEnum.END,
            endpoint_name="قطع اتصال به دیتابیس",
            is_success=False,
        )
        self.emit(log)


    def start_db_logger(self, db_client):
        if not config.LOG_ENABLE:
            return

        self.checker = MongoHealthChecker(
            db_client,
            on_connect=self._on_mongo_connect,
            on_disconnect=self._on_mongo_disconnect,
        )

        self.checker.start()


    def stop_db_logger(self):
        if not config.LOG_ENABLE:
            return

        if self.checker:
            self.checker.stop()
            self.checker = None