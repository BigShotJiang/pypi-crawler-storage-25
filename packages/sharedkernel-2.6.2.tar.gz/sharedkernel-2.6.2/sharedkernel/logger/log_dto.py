from typing import Optional
from pydantic import BaseModel
import datetime
import uuid

from sharedkernel.logger.log_enums import LogEventTypeEnum, LogLevelEnum


class LogDTO(BaseModel):
    EventType : Optional[LogEventTypeEnum] = None
    Description: Optional[str] = None
    MethodName: Optional[str] = None
    IsSuccess : Optional[bool] = None
    UserId : Optional[str] = None
    UserName : Optional[str] = None
    FailureReason : Optional[str] = None
    UserAgent : Optional[str] = "Internal"
    IpAddress : Optional[str] = '127.0.0.1'
    RequestPath : Optional[str] = "Internal"
    ServiceName : Optional[str] = None
    HttpMethod : Optional[str] = "Internal"
    CorrelationId : Optional[str] = None
    Level : Optional[LogLevelEnum] = None
    CreatedOn : datetime.datetime = None