"""Generic OpenAI-compatible provider adapter.

This module provides one reusable path for endpoints that speak the common
OpenAI-compatible request shape. The adapter stays provider-neutral at the
kernel boundary while still exposing the transport, credential, and endpoint
metadata needed by product surfaces and integration tests.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field
from typing import Any, Callable, Mapping

from packages.contracts.runtime import ExecutionToolCall

from ..provider_runtime import ProviderRuntimeResolution, ProviderRuntimeResolver
from ..runtime import CredentialSource, ModelAdapterDescriptor, ModelEmbeddingResult, ModelRequest, ModelTextResult, ModelUsage
from .identity_contract import build_provider_identity_contract
from .http import JSONHTTPTransport, UrllibJSONHTTPTransport

_TOOL_NAME_PATTERN = re.compile(r"^[A-Za-z0-9_-]+$")
_SCHEMA_TYPE_PREFERENCE = ("string", "object", "array", "integer", "number", "boolean")


@dataclass(frozen=True, slots=True)
class OpenAICompatibleProviderConfig:
    provider_id: str = "openai-compatible"
    base_url: str = ""
    model_id: str = ""
    extra_headers: Mapping[str, str] = field(default_factory=dict)
    auth_header_name: str = "Authorization"
    auth_scheme: str = "Bearer"

    def __post_init__(self) -> None:
        if not self.base_url:
            raise ValueError("base_url is required for an OpenAI-compatible provider")
        if not self.model_id:
            raise ValueError("model_id is required for an OpenAI-compatible provider")


@dataclass(frozen=True, slots=True)
class OpenAICompatibleRequestPlan:
    request_id: str
    provider_id: str
    model_id: str
    base_url: str
    endpoint_path: str
    url: str
    request_family: str
    transport_id: str
    headers: Mapping[str, str] = field(default_factory=dict)
    payload: Mapping[str, Any] = field(default_factory=dict)
    tool_name_map: Mapping[str, str] = field(default_factory=dict)
    credential_keys: tuple[str, ...] = ()
    metadata: Mapping[str, str] = field(default_factory=dict)


class OpenAICompatibleProviderAdapter:
    """Plan and execute requests for OpenAI-compatible and OpenAI transports."""

    def __init__(
        self,
        *,
        config: OpenAICompatibleProviderConfig,
        runtime_resolver: ProviderRuntimeResolver | None = None,
        credential_source: CredentialSource | None = None,
        http_transport: JSONHTTPTransport | None = None,
        adapter_id: str = "adapter.models.openai-compatible",
        stream_observer: Callable[[str], None] | None = None,
    ) -> None:
        self.config = config
        self.runtime_resolver = runtime_resolver or ProviderRuntimeResolver.default()
        self.credential_source = credential_source
        self.http_transport = http_transport or UrllibJSONHTTPTransport()
        self.stream_observer = stream_observer
        self.descriptor = ModelAdapterDescriptor(
            adapter_id=adapter_id,
            provider_id=config.provider_id,
            model_id=config.model_id,
            kind="chat",
            supported_tasks=("generate", "summarize", "embed"),
            metadata={
                "provider_id": config.provider_id,
                "transport_id": "openai_chat_compatible",
                "base_url": config.base_url,
            },
        )

    def plan_request(
        self,
        request: ModelRequest,
        credentials: Mapping[str, str] | None = None,
    ) -> OpenAICompatibleRequestPlan:
        provider_id = self._resolve_provider_id(request)
        resolution = self.runtime_resolver.resolve(
            provider_id,
            model_id=request.model_id or self.config.model_id,
            base_url=self.config.base_url,
        )
        resolved_credentials = self._resolve_credentials(provider_id, credentials)
        if request.task == "embed" and not resolution.supports_embeddings:
            raise ValueError(f"transport {resolution.transport_id} does not support embeddings")
        endpoint_path = self._endpoint_path_for_task(request.task, resolution.endpoint_path)
        url = self._compose_url(self.config.base_url, endpoint_path)
        headers = self._build_headers(resolution, resolved_credentials)
        payload, tool_name_map = self._build_payload(request, request.task, resolution)
        return OpenAICompatibleRequestPlan(
            request_id=request.request_id,
            provider_id=provider_id,
            model_id=resolution.model_id,
            base_url=self.config.base_url,
            endpoint_path=endpoint_path,
            url=url,
            request_family=resolution.request_family if request.task != "embed" else "embeddings",
            transport_id=resolution.transport_id,
            headers=headers,
            payload=payload,
            tool_name_map=tool_name_map,
            credential_keys=tuple(sorted(resolved_credentials)),
            metadata={
                "supports_streaming": str(resolution.supports_streaming).lower(),
                "supports_embeddings": str(resolution.supports_embeddings).lower(),
                "supports_tools": str(resolution.supports_tools).lower(),
                "supports_reasoning": str(resolution.supports_reasoning).lower(),
            },
        )

    def generate(
        self,
        request: ModelRequest,
        credentials: Mapping[str, str],
    ) -> ModelTextResult:
        plan = self.plan_request(request, credentials)
        if bool(plan.payload.get("stream")):
            return self._generate_streaming(request, plan)
        response = self.http_transport.post_json(url=plan.url, headers=plan.headers, payload=plan.payload)
        return self._text_result_from_payload(
            request=request,
            plan=plan,
            payload=response.payload,
            status_code=response.status_code,
        )

    def _generate_streaming(
        self,
        request: ModelRequest,
        plan: OpenAICompatibleRequestPlan,
    ) -> ModelTextResult:
        transport = getattr(self.http_transport, "post_json_stream", None)
        if transport is None:
            fallback_response = self.http_transport.post_json(url=plan.url, headers=plan.headers, payload=plan.payload)
            return self._text_result_from_payload(
                request=request,
                plan=plan,
                payload=fallback_response.payload,
                status_code=fallback_response.status_code,
                stream_used=False,
            )
        text_parts: list[str] = []
        collected_output: list[Mapping[str, Any]] = []
        usage = ModelUsage()
        result_id = f"{request.request_id}:generate"
        result_model = plan.model_id
        final_payload: Mapping[str, Any] | None = None
        for chunk in transport(url=plan.url, headers=plan.headers, payload=plan.payload):
            payload = chunk.payload
            event_name = chunk.event
            if plan.request_family == "responses":
                response_payload = self._responses_stream_response_payload(
                    payload,
                    collected_output=collected_output,
                    text_parts=text_parts,
                )
                if response_payload:
                    final_payload = response_payload
                result_id = str(response_payload.get("id", payload.get("id", result_id)))
                result_model = str(response_payload.get("model", payload.get("model", result_model)))
                if "output_item.done" in str(event_name or payload.get("type") or ""):
                    item = payload.get("item")
                    if isinstance(item, Mapping):
                        collected_output.append({str(key): value for key, value in item.items()})
                delta = self._extract_stream_text_delta(
                    payload,
                    request_family=plan.request_family,
                    event=event_name,
                )
                chunk_usage = self._usage_from_payload(response_payload)
            else:
                result_id = str(payload.get("id", result_id))
                result_model = str(payload.get("model", result_model))
                delta = self._extract_stream_text_delta(payload, request_family=plan.request_family)
                chunk_usage = self._usage_from_payload(payload)
            if delta:
                text_parts.append(delta)
                if self.stream_observer is not None:
                    self.stream_observer(delta)
            if any((chunk_usage.prompt_tokens, chunk_usage.completion_tokens, chunk_usage.total_tokens)):
                usage = chunk_usage
        if plan.request_family == "responses":
            payload = (
                final_payload
                if final_payload is not None
                else self._responses_stream_response_payload(
                    {},
                    collected_output=collected_output,
                    text_parts=text_parts,
                )
            )
            tool_calls = self._extract_tool_calls(
                payload,
                request_family=plan.request_family,
                tool_name_map=plan.tool_name_map,
            )
            try:
                content = self._extract_text_content(
                    payload,
                    request_family=plan.request_family,
                    allow_empty=bool(tool_calls),
                )
            except RuntimeError:
                content = ""
            if not content and not tool_calls:
                raise RuntimeError("responses transport returned no streamed assistant text")
            return ModelTextResult(
                result_id=result_id,
                request_id=request.request_id,
                adapter_id=self.descriptor.adapter_id,
                provider_id=plan.provider_id,
                model_id=result_model,
                task="generate",
                content=content,
                usage=usage,
                metadata={
                    "endpoint_path": plan.endpoint_path,
                    "url": plan.url,
                    "credential_keys": ",".join(plan.credential_keys) or "no-credentials",
                    "transport_id": plan.transport_id,
                    "request_family": plan.request_family,
                    "status_code": "200",
                    "stream": "true",
                },
                tool_calls=tool_calls,
            )
        content = "".join(text_parts)
        if not content:
            raise RuntimeError("chat-completions transport returned no streamed assistant text")
        return ModelTextResult(
            result_id=result_id,
            request_id=request.request_id,
            adapter_id=self.descriptor.adapter_id,
            provider_id=plan.provider_id,
            model_id=result_model,
            task="generate",
            content=content,
            usage=usage,
            metadata={
                "endpoint_path": plan.endpoint_path,
                "url": plan.url,
                "credential_keys": ",".join(plan.credential_keys) or "no-credentials",
                "transport_id": plan.transport_id,
                "request_family": plan.request_family,
                "status_code": "200",
                "stream": "true",
            },
        )

    def _text_result_from_payload(
        self,
        *,
        request: ModelRequest,
        plan: OpenAICompatibleRequestPlan,
        payload: Mapping[str, Any],
        status_code: int | str,
        stream_used: bool = False,
    ) -> ModelTextResult:
        tool_calls = self._extract_tool_calls(
            payload,
            request_family=plan.request_family,
            tool_name_map=plan.tool_name_map,
        )
        content = self._extract_text_content(
            payload,
            request_family=plan.request_family,
            allow_empty=bool(tool_calls),
        )
        usage = self._usage_from_payload(payload)
        return ModelTextResult(
            result_id=str(payload.get("id", f"{request.request_id}:generate")),
            request_id=request.request_id,
            adapter_id=self.descriptor.adapter_id,
            provider_id=plan.provider_id,
            model_id=str(payload.get("model", plan.model_id)),
            task="generate",
            content=content,
            usage=usage,
            metadata={
                "endpoint_path": plan.endpoint_path,
                "url": plan.url,
                "credential_keys": ",".join(plan.credential_keys) or "no-credentials",
                "transport_id": plan.transport_id,
                "request_family": plan.request_family,
                "status_code": str(status_code),
                "stream": "true" if stream_used else "false",
            },
            tool_calls=tool_calls,
        )

    def summarize(
        self,
        request: ModelRequest,
        credentials: Mapping[str, str],
    ) -> ModelTextResult:
        result = self.generate(
            ModelRequest(
                request_id=request.request_id,
                profile_id=request.profile_id,
                session_id=request.session_id,
                provider_id=request.provider_id,
                model_id=request.model_id,
                prompt=request.prompt,
                context=dict(request.context),
                task="summarize",
                reasoning_effort=request.reasoning_effort,
                metadata=dict(request.metadata),
            ),
            credentials,
        )
        return ModelTextResult(
            result_id=result.result_id,
            request_id=result.request_id,
            adapter_id=result.adapter_id,
            provider_id=result.provider_id,
            model_id=result.model_id,
            task="summarize",
            content=result.content,
            usage=result.usage,
            failure_kind=result.failure_kind,
            metadata=dict(result.metadata),
        )

    def embed(
        self,
        request: ModelRequest,
        credentials: Mapping[str, str],
    ) -> ModelEmbeddingResult:
        plan = self.plan_request(request, credentials)
        response = self.http_transport.post_json(url=plan.url, headers=plan.headers, payload=plan.payload)
        embeddings = self._extract_embeddings(response.payload)
        return ModelEmbeddingResult(
            result_id=str(response.payload.get("id", f"{request.request_id}:embed")),
            request_id=request.request_id,
            adapter_id=self.descriptor.adapter_id,
            provider_id=plan.provider_id,
            model_id=str(response.payload.get("model", plan.model_id)),
            task="embed",
            embeddings=embeddings,
            metadata={
                "endpoint_path": plan.endpoint_path,
                "url": plan.url,
                "credential_keys": ",".join(plan.credential_keys) or "no-credentials",
                "transport_id": plan.transport_id,
                "request_family": plan.request_family,
                "status_code": str(response.status_code),
            },
        )

    def _resolve_provider_id(self, request: ModelRequest) -> str:
        provider_id = request.provider_id or self.config.provider_id
        if provider_id != self.config.provider_id:
            raise ValueError(
                f"request provider_id {provider_id!r} does not match adapter provider_id "
                f"{self.config.provider_id!r}"
            )
        return provider_id

    def _resolve_credentials(
        self,
        provider_id: str,
        explicit_credentials: Mapping[str, str] | None,
    ) -> Mapping[str, str]:
        if explicit_credentials is not None:
            return dict(explicit_credentials)
        if self.credential_source is None:
            return {}
        return dict(self.credential_source.resolve(provider_id))

    def _build_headers(
        self,
        resolution: ProviderRuntimeResolution,
        credentials: Mapping[str, str],
    ) -> dict[str, str]:
        headers = dict(self.config.extra_headers)
        headers["Content-Type"] = "application/json"
        api_key = credentials.get("api_key")
        if api_key:
            headers[resolution.auth_header_name] = f"{self.config.auth_scheme} {api_key}"
        return headers

    def _build_payload(
        self,
        request: ModelRequest,
        task: str,
        resolution: ProviderRuntimeResolution,
    ) -> tuple[dict[str, Any], dict[str, str]]:
        if task == "embed":
            input_text = request.context.get("input") or request.context.get("text") or request.prompt
            return (
                {
                    "model": resolution.model_id,
                    "input": input_text,
                    "encoding_format": "float",
                },
                {},
            )
        if resolution.request_family == "responses":
            should_stream = bool(resolution.supports_streaming)
            payload: dict[str, Any] = {
                "model": resolution.model_id,
                "input": self._responses_input_payload(request.prompt),
                "store": False,
                "stream": should_stream,
            }
            tool_name_map: dict[str, str] = {}
            payload["instructions"] = build_provider_identity_contract(request)
            if request.reasoning_effort and resolution.supports_reasoning:
                payload["reasoning"] = {"effort": request.reasoning_effort}
            if request.tools and resolution.supports_tools:
                payload["tools"], tool_name_map = self._normalized_tool_definitions(
                    request.tools,
                    request_family="responses",
                    strict_schema=self._requires_strict_tool_schema(resolution),
                )
                if payload["tools"]:
                    payload["tool_choice"] = "auto"
                    payload["parallel_tool_calls"] = True
            return payload, tool_name_map
        messages: list[dict[str, str]] = []
        messages.append({"role": "system", "content": build_provider_identity_contract(request)})
        messages.append({"role": "user", "content": request.prompt})
        should_stream = bool(self.stream_observer and resolution.supports_streaming and not request.tools)
        payload = {
            "model": resolution.model_id,
            "messages": messages,
            "stream": should_stream,
        }
        tool_name_map: dict[str, str] = {}
        if (
            request.reasoning_effort
            and resolution.supports_reasoning
            and resolution.provider_id == "copilot"
        ):
            payload["reasoning_effort"] = request.reasoning_effort
        if request.tools and resolution.supports_tools:
            payload["tools"], tool_name_map = self._normalized_tool_definitions(
                request.tools,
                request_family="chat_completions",
                strict_schema=self._requires_strict_tool_schema(resolution),
            )
            if payload["tools"]:
                payload["tool_choice"] = "auto"
                payload["parallel_tool_calls"] = True
        if payload["stream"]:
            payload["stream_options"] = {"include_usage": True}
        return payload, tool_name_map

    def _responses_input_payload(self, prompt: str) -> list[dict[str, object]]:
        return [
            {
                "role": "user",
                "content": [
                    {
                        "type": "input_text",
                        "text": prompt,
                    }
                ],
            }
        ]

    def _responses_tool_definition(self, payload: Mapping[str, object]) -> dict[str, object]:
        if not isinstance(payload, Mapping):
            return {}
        function_payload = payload.get("function")
        if isinstance(function_payload, Mapping):
            normalized: dict[str, object] = {
                "type": str(payload.get("type") or "function"),
                "name": str(function_payload.get("name") or ""),
                "description": str(function_payload.get("description") or ""),
                "parameters": dict(function_payload.get("parameters") or {}),
                "strict": bool(function_payload.get("strict", payload.get("strict", False))),
            }
            return normalized
        return {str(key): value for key, value in payload.items()}

    def _chat_tool_definition(self, payload: Mapping[str, object]) -> dict[str, object]:
        if not isinstance(payload, Mapping):
            return {}
        function_payload = payload.get("function")
        if isinstance(function_payload, Mapping):
            return {
                **{str(key): value for key, value in payload.items()},
                "type": str(payload.get("type") or "function"),
                "function": {str(key): value for key, value in function_payload.items()},
            }
        name = str(payload.get("name") or "").strip()
        if not name:
            return {}
        normalized: dict[str, object] = {
            "type": str(payload.get("type") or "function"),
            "function": {
                "name": name,
                "description": str(payload.get("description") or ""),
                "parameters": dict(payload.get("parameters") or {}),
            },
        }
        strict = payload.get("strict")
        if strict is not None:
            normalized["function"]["strict"] = strict
        return normalized

    def _normalized_tool_definitions(
        self,
        tools: tuple[Mapping[str, object], ...],
        *,
        request_family: str,
        strict_schema: bool,
    ) -> tuple[list[dict[str, object]], dict[str, str]]:
        normalized_tools: list[dict[str, object]] = []
        tool_name_map: dict[str, str] = {}
        used_aliases: set[str] = set()
        for item in tools:
            normalized = (
                self._responses_tool_definition(item)
                if request_family == "responses"
                else self._chat_tool_definition(item)
            )
            if not normalized:
                continue
            normalized = self._sanitize_tool_definition(normalized, request_family=request_family, strict_schema=strict_schema)
            if not normalized:
                continue
            if request_family == "responses":
                raw_name = str(normalized.get("name") or "").strip()
                if not raw_name:
                    continue
                alias = self._provider_tool_name(raw_name, used_aliases)
                normalized["name"] = alias
            else:
                function_payload = normalized.get("function")
                if not isinstance(function_payload, Mapping):
                    continue
                raw_name = str(function_payload.get("name") or "").strip()
                if not raw_name:
                    continue
                alias = self._provider_tool_name(raw_name, used_aliases)
                normalized["function"] = {
                    **{str(key): value for key, value in function_payload.items()},
                    "name": alias,
                }
            normalized_tools.append(normalized)
            used_aliases.add(alias)
            tool_name_map[alias] = raw_name
        return normalized_tools, tool_name_map

    def _requires_strict_tool_schema(self, resolution: ProviderRuntimeResolution) -> bool:
        return resolution.request_family == "responses" or resolution.provider_id in {"copilot", "openai", "openai-codex"}

    def _sanitize_tool_definition(
        self,
        payload: Mapping[str, object],
        *,
        request_family: str,
        strict_schema: bool,
    ) -> dict[str, object]:
        normalized = {str(key): value for key, value in payload.items()}
        if request_family == "responses":
            parameters = normalized.get("parameters")
            normalized["parameters"] = self._sanitize_json_schema(parameters, strict=strict_schema)
            return normalized
        function_payload = normalized.get("function")
        if not isinstance(function_payload, Mapping):
            return normalized
        function_mapping = {str(key): value for key, value in function_payload.items()}
        function_mapping["parameters"] = self._sanitize_json_schema(
            function_mapping.get("parameters"),
            strict=strict_schema,
        )
        normalized["function"] = function_mapping
        return normalized

    def _sanitize_json_schema(self, payload: object, *, strict: bool) -> dict[str, object]:
        if not isinstance(payload, Mapping):
            return {"type": "object", "properties": {}}
        schema = {str(key): value for key, value in payload.items()}
        resolved_type = self._schema_type(schema.get("type"), strict=strict)
        normalized: dict[str, object] = {}
        if resolved_type:
            normalized["type"] = resolved_type
        description = schema.get("description")
        if isinstance(description, str) and description.strip():
            normalized["description"] = description.strip()
        enum = schema.get("enum")
        if isinstance(enum, (list, tuple)):
            normalized_enum = [str(item) if resolved_type == "string" else item for item in enum]
            if normalized_enum:
                normalized["enum"] = normalized_enum
        if resolved_type == "object" or ("properties" in schema and resolved_type != "array"):
            properties = schema.get("properties")
            if isinstance(properties, Mapping):
                normalized_properties: dict[str, object] = {}
                for key, value in properties.items():
                    if not isinstance(value, Mapping):
                        continue
                    normalized_properties[str(key)] = self._sanitize_json_schema(value, strict=strict)
                normalized["properties"] = normalized_properties
                required = schema.get("required")
                if isinstance(required, (list, tuple)) and normalized_properties:
                    normalized["required"] = [
                        str(item)
                        for item in required
                        if str(item).strip() and str(item) in normalized_properties
                    ]
        if resolved_type == "array":
            items = schema.get("items")
            if isinstance(items, Mapping):
                normalized["items"] = self._sanitize_json_schema(items, strict=strict)
        if resolved_type in {"integer", "number"}:
            minimum = schema.get("minimum")
            maximum = schema.get("maximum")
            if isinstance(minimum, (int, float)):
                normalized["minimum"] = minimum
            if isinstance(maximum, (int, float)):
                normalized["maximum"] = maximum
        if "type" not in normalized:
            normalized["type"] = "object"
            normalized.setdefault("properties", {})
        if normalized.get("type") == "object":
            normalized.setdefault("properties", {})
        return normalized

    def _schema_type(self, raw_type: object, *, strict: bool) -> str | None:
        if isinstance(raw_type, str):
            return raw_type
        if isinstance(raw_type, (list, tuple)):
            candidates = [str(item).strip() for item in raw_type if str(item).strip()]
            if not candidates:
                return None
            if strict:
                for preferred in _SCHEMA_TYPE_PREFERENCE:
                    if preferred in candidates:
                        return preferred
            return candidates[0]
        return None

    def _provider_tool_name(self, tool_name: str, used_aliases: set[str]) -> str:
        candidate = tool_name.strip()
        if _TOOL_NAME_PATTERN.match(candidate) and candidate not in used_aliases:
            return candidate
        sanitized = re.sub(r"[^A-Za-z0-9_-]", "_", candidate)
        sanitized = re.sub(r"_+", "_", sanitized).strip("_") or "tool"
        if sanitized not in used_aliases and _TOOL_NAME_PATTERN.match(sanitized):
            return sanitized
        digest = hashlib.sha1(candidate.encode("utf-8", errors="replace")).hexdigest()[:8]
        candidate = f"{sanitized}_{digest}"
        index = 1
        while candidate in used_aliases:
            index += 1
            candidate = f"{sanitized}_{digest}_{index}"
        return candidate

    def _endpoint_path_for_task(self, task: str, default_endpoint_path: str) -> str:
        if task == "embed":
            return "/v1/embeddings"
        return default_endpoint_path

    def _compose_url(self, base_url: str, endpoint_path: str) -> str:
        trimmed_base = base_url.rstrip("/")
        trimmed_path = endpoint_path.lstrip("/")
        if trimmed_path.startswith("v1/") and trimmed_base.endswith("/v1"):
            trimmed_path = trimmed_path[3:]
        return f"{trimmed_base}/{trimmed_path}"

    def _extract_text_content(
        self,
        payload: Mapping[str, Any],
        *,
        request_family: str,
        allow_empty: bool = False,
    ) -> str:
        if request_family == "responses":
            direct_text = payload.get("output_text")
            if isinstance(direct_text, str) and direct_text.strip():
                return direct_text
            output = payload.get("output", ())
            texts: list[str] = []
            if isinstance(output, list):
                for item in output:
                    if not isinstance(item, dict):
                        continue
                    content = item.get("content", ())
                    if isinstance(content, list):
                        for block in content:
                            if not isinstance(block, dict):
                                continue
                            if block.get("type") in {"output_text", "text"}:
                                text = block.get("text")
                                if isinstance(text, str):
                                    texts.append(text)
                    elif isinstance(item.get("text"), str):
                        texts.append(str(item["text"]))
            if texts:
                return "".join(texts)
            if allow_empty:
                return ""
            raise RuntimeError("responses transport returned no assistant text")
        choices = payload.get("choices", ())
        if isinstance(choices, list):
            for choice in choices:
                if not isinstance(choice, dict):
                    continue
                message = choice.get("message", {})
                if not isinstance(message, dict):
                    continue
                content = message.get("content")
                if isinstance(content, str):
                    return content
                if isinstance(content, list):
                    texts = [
                        str(block.get("text", ""))
                        for block in content
                        if isinstance(block, dict) and block.get("text")
                    ]
                    if texts:
                        return "".join(texts)
        if allow_empty:
            return ""
        raise RuntimeError("chat-completions transport returned no assistant text")

    def _extract_tool_calls(
        self,
        payload: Mapping[str, Any],
        *,
        request_family: str,
        tool_name_map: Mapping[str, str] | None = None,
    ) -> tuple[ExecutionToolCall, ...]:
        if request_family != "chat_completions":
            if request_family != "responses":
                return ()
            output = payload.get("output", ())
            if not isinstance(output, list):
                return ()
            calls: list[ExecutionToolCall] = []
            for item in output:
                if not isinstance(item, Mapping):
                    continue
                call = self._tool_call_from_payload(item, tool_name_map=tool_name_map)
                if call is not None:
                    calls.append(call)
                    continue
                content = item.get("content")
                if isinstance(content, list):
                    for block in content:
                        call = self._tool_call_from_payload(block, tool_name_map=tool_name_map)
                        if call is not None:
                            calls.append(call)
            return tuple(calls)
        choices = payload.get("choices", ())
        if not isinstance(choices, list):
            return ()
        calls: list[ExecutionToolCall] = []
        for choice in choices:
            if not isinstance(choice, Mapping):
                continue
            message = choice.get("message")
            if not isinstance(message, Mapping):
                continue
            tool_calls = message.get("tool_calls")
            if isinstance(tool_calls, list):
                for item in tool_calls:
                    call = self._tool_call_from_payload(item, tool_name_map=tool_name_map)
                    if call is not None:
                        calls.append(call)
            function_call = message.get("function_call")
            if isinstance(function_call, Mapping):
                call = self._tool_call_from_payload({"function": function_call}, tool_name_map=tool_name_map)
                if call is not None:
                    calls.append(call)
        return tuple(calls)

    def _tool_call_from_payload(
        self,
        payload: object,
        *,
        tool_name_map: Mapping[str, str] | None = None,
    ) -> ExecutionToolCall | None:
        if not isinstance(payload, Mapping):
            return None
        function = payload.get("function")
        if isinstance(function, Mapping):
            name = str(function.get("name") or "").strip()
            arguments = self._tool_arguments_from_payload(function.get("arguments"))
        else:
            payload_type = str(payload.get("type") or "").strip()
            if payload_type and payload_type not in {"function_call", "tool_call", "function"} and "tool" not in payload_type:
                return None
            name = str(payload.get("name") or payload.get("tool_name") or "").strip()
            arguments = self._tool_arguments_from_payload(payload.get("arguments") or payload.get("input"))
        if tool_name_map is not None:
            name = str(tool_name_map.get(name, name)).strip()
        if not name:
            return None
        return ExecutionToolCall(tool_name=name, arguments=arguments)

    def _tool_arguments_from_payload(self, payload: object) -> dict[str, object]:
        if isinstance(payload, Mapping):
            return {str(key): value for key, value in payload.items()}
        if isinstance(payload, str):
            text = payload.strip()
            if not text:
                return {}
            try:
                decoded = json.loads(text)
            except json.JSONDecodeError:
                return {}
            if isinstance(decoded, Mapping):
                return {str(key): value for key, value in decoded.items()}
        return {}

    def _extract_stream_text_delta(
        self,
        payload: Mapping[str, Any],
        *,
        request_family: str,
        event: str | None = None,
    ) -> str:
        if request_family == "responses":
            event_name = str(event or payload.get("type") or "").strip()
            if "output_text.delta" in event_name:
                delta = payload.get("delta")
                return str(delta) if isinstance(delta, str) else ""
            if "output_text.done" in event_name:
                text = payload.get("text")
                return str(text) if isinstance(text, str) else ""
            return ""
        if request_family != "chat_completions":
            return ""
        choices = payload.get("choices", ())
        if not isinstance(choices, list):
            return ""
        fragments: list[str] = []
        for choice in choices:
            if not isinstance(choice, dict):
                continue
            delta = choice.get("delta")
            if not isinstance(delta, dict):
                continue
            content = delta.get("content")
            if isinstance(content, str):
                fragments.append(content)
                continue
            if isinstance(content, list):
                fragments.extend(
                    str(block.get("text", ""))
                    for block in content
                    if isinstance(block, dict) and block.get("text")
                )
        return "".join(fragments)

    def _responses_stream_response_payload(
        self,
        payload: Mapping[str, Any],
        *,
        collected_output: list[Mapping[str, Any]],
        text_parts: list[str],
    ) -> Mapping[str, Any]:
        response_payload = payload.get("response")
        if isinstance(response_payload, Mapping):
            synthesized: dict[str, Any] = {str(key): value for key, value in response_payload.items()}
        else:
            synthesized = {}
        response_id = payload.get("id")
        if isinstance(response_id, str):
            synthesized["id"] = response_id
        response_model = payload.get("model")
        if isinstance(response_model, str):
            synthesized["model"] = response_model
        existing_output = synthesized.get("output")
        if collected_output and not (isinstance(existing_output, list) and existing_output):
            synthesized["output"] = list(collected_output)
        existing_output_text = synthesized.get("output_text")
        if text_parts and not (isinstance(existing_output_text, str) and existing_output_text.strip()):
            synthesized["output_text"] = "".join(text_parts)
        usage_payload = payload.get("usage")
        if isinstance(usage_payload, Mapping):
            synthesized["usage"] = dict(usage_payload)
        return synthesized

    def _extract_embeddings(self, payload: Mapping[str, Any]) -> tuple[tuple[float, ...], ...]:
        data = payload.get("data", ())
        if not isinstance(data, list):
            raise RuntimeError("embedding response did not include a data list")
        embeddings: list[tuple[float, ...]] = []
        for item in data:
            if not isinstance(item, dict):
                continue
            vector = item.get("embedding", ())
            if isinstance(vector, list):
                embeddings.append(tuple(float(value) for value in vector))
        if not embeddings:
            raise RuntimeError("embedding response did not include vectors")
        return tuple(embeddings)

    def _usage_from_payload(self, payload: Mapping[str, Any]) -> ModelUsage:
        usage_payload = payload.get("usage", {})
        if not isinstance(usage_payload, dict):
            return ModelUsage()
        prompt_tokens = int(usage_payload.get("prompt_tokens", usage_payload.get("input_tokens", 0)))
        completion_tokens = int(usage_payload.get("completion_tokens", usage_payload.get("output_tokens", 0)))
        total_tokens = int(usage_payload.get("total_tokens", prompt_tokens + completion_tokens))
        return ModelUsage(
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=total_tokens,
        )
