"""
Chat — a simple multi-turn conversation object.
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import TYPE_CHECKING, Generator

if TYPE_CHECKING:
    from .core import GeminiClient, ChatSession as _ChatSession
    from .response import Response


class Chat:
    """
    A multi-turn conversation with Gemini.

    Created via ``Gemini.chat()``. All methods are synchronous by default.

    Examples
    --------
    >>> g = Gemini()
    >>> chat = g.chat(model="flash")
    >>> chat.say("My name is Alex.")
    'Nice to meet you, Alex!'
    >>> chat.say("What is my name?")
    'Your name is Alex.'
    >>> print(chat.history)
    [('user', 'My name is Alex.'), ('model', 'Nice to meet you, Alex!'), ...]
    """

    def __init__(
        self,
        session: "_ChatSession",
        client: "GeminiClient",
        _loop: asyncio.AbstractEventLoop,
    ):
        self._session = session
        self._client = client
        self._loop = _loop
        self._history: list[tuple[str, str]] = []

    # ------------------------------------------------------------------
    # Sync interface
    # ------------------------------------------------------------------

    def say(
        self,
        prompt: str,
        files: list[str | Path] | None = None,
        temporary: bool = False,
    ) -> str:
        """
        Send a message and get a text reply.

        Parameters
        ----------
        prompt : str
            Your message.
        files : list[str | Path], optional
            Files to attach (images, PDFs, etc.).
        temporary : bool
            If True, this message won't be saved to Gemini history.

        Returns
        -------
        str
            Gemini's reply text.

        Examples
        --------
        >>> chat.say("What is 2 + 2?")
        '4'
        """
        response = self._run(
            self._session.send_message(
                prompt,
                files=[Path(f) for f in files] if files else None,
                temporary=temporary,
            )
        )
        user_text = prompt
        model_text = response.text
        self._history.append(("user", user_text))
        self._history.append(("model", model_text))
        return model_text

    def say_stream(
        self,
        prompt: str,
        files: list[str | Path] | None = None,
        temporary: bool = False,
    ) -> Generator[str, None, None]:
        """
        Send a message and stream the reply in chunks.

        Yields
        ------
        str
            Text chunks as they arrive.

        Examples
        --------
        >>> for chunk in chat.say_stream("Tell me about black holes"):
        ...     print(chunk, end="", flush=True)
        """
        full_text = []

        async def _collect():
            async for output in self._session.send_message_stream(
                prompt,
                files=[Path(f) for f in files] if files else None,
                temporary=temporary,
            ):
                if output.text_delta:
                    full_text.append(output.text_delta)
                    yield output.text_delta

        # We need to bridge async generator → sync generator
        queue: asyncio.Queue = asyncio.Queue()
        _DONE = object()

        async def _producer():
            try:
                async for chunk in self._session.send_message_stream(
                    prompt,
                    files=[Path(f) for f in files] if files else None,
                    temporary=temporary,
                ):
                    if chunk.text_delta:
                        await queue.put(chunk.text_delta)
            finally:
                await queue.put(_DONE)

        future = asyncio.run_coroutine_threadsafe(_producer(), self._loop)

        while True:
            # Block the calling thread until a chunk is ready
            chunk = asyncio.run_coroutine_threadsafe(
                queue.get(), self._loop
            ).result()
            if chunk is _DONE:
                break
            full_text.append(chunk)
            yield chunk

        self._history.append(("user", prompt))
        self._history.append(("model", "".join(full_text)))

    def reply(self, prompt: str, **kwargs) -> str:
        """Alias for :meth:`say`."""
        return self.say(prompt, **kwargs)

    # ------------------------------------------------------------------
    # Async interface
    # ------------------------------------------------------------------

    async def async_say(
        self,
        prompt: str,
        files: list[str | Path] | None = None,
        temporary: bool = False,
    ) -> str:
        """Async version of :meth:`say`."""
        output = await self._session.send_message(
            prompt,
            files=[Path(f) for f in files] if files else None,
            temporary=temporary,
        )
        self._history.append(("user", prompt))
        self._history.append(("model", output.text))
        return output.text

    async def async_say_stream(
        self,
        prompt: str,
        files: list[str | Path] | None = None,
        temporary: bool = False,
    ):
        """Async streaming version of :meth:`say`."""
        full_text = []
        async for output in self._session.send_message_stream(
            prompt,
            files=[Path(f) for f in files] if files else None,
            temporary=temporary,
        ):
            if output.text_delta:
                full_text.append(output.text_delta)
                yield output.text_delta

        self._history.append(("user", prompt))
        self._history.append(("model", "".join(full_text)))

    # ------------------------------------------------------------------
    # History & metadata
    # ------------------------------------------------------------------

    @property
    def history(self) -> list[tuple[str, str]]:
        """
        List of (role, text) tuples for the current session.

        Returns
        -------
        list[tuple[str, str]]
            Each element is ``('user', '...')`` or ``('model', '...')``.
        """
        return list(self._history)

    @property
    def chat_id(self) -> str:
        """The Gemini chat ID (``c_...``). Useful for resuming later."""
        return self._session.cid or ""

    @property
    def metadata(self) -> list:
        """Raw session metadata for advanced use / session resumption."""
        return self._session.metadata

    def save(self, path: str = "chat.txt", encoding: str = "utf-8") -> str:
        """
        Save the conversation history to a text file.

        Parameters
        ----------
        path : str
            File path to save to.
        encoding : str
            File encoding.

        Returns
        -------
        str
            Absolute path of the saved file.

        Examples
        --------
        >>> chat.save("my_conversation.txt")
        '/home/user/my_conversation.txt'
        """
        lines = []
        for role, text in self._history:
            label = "YOU" if role == "user" else "GEMINI"
            lines.append(f"[{label}] {text}\n")

        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text("\n".join(lines), encoding=encoding)
        return str(p.resolve())

    def clear(self) -> None:
        """Clear local history (does not affect Gemini server history)."""
        self._history.clear()

    def __repr__(self) -> str:
        return (
            f"Chat(chat_id={self.chat_id!r}, "
            f"turns={len(self._history) // 2})"
        )

    def _run(self, coro):
        """Run a coroutine synchronously using the shared event loop."""
        return asyncio.run_coroutine_threadsafe(coro, self._loop).result()
