"""
Exceptions for gemi — re-exported with cleaner names.
"""

from .core.exceptions import (
    AuthError,
    APIError,
    ImageGenerationError,
    GeminiError,
    TimeoutError,
    UsageLimitExceeded,
    ModelInvalid,
    TemporarilyBlocked,
)

__all__ = [
    "AuthError",
    "APIError",
    "ImageGenerationError",
    "GeminiError",
    "TimeoutError",
    "UsageLimitExceeded",
    "ModelInvalid",
    "TemporarilyBlocked",
]
