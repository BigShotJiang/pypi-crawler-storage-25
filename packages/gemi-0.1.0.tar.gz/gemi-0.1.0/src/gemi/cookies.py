"""
Cookie loading helpers for gemi.

Priority order:
  1. Explicit psid= / psidts= arguments
  2. Environment variables: GEMINI_PSID, GEMINI_PSIDTS
  3. .env file (via python-dotenv if installed)
  4. JSON cookie file (browser export or simple dict)
  5. Local browser cookies (requires browser-cookie3)
"""

from __future__ import annotations

import json
import os
from pathlib import Path


def load_cookies(
    psid: str | None = None,
    psidts: str | None = None,
    cookies_json: str | Path | None = None,
    dotenv_path: str | Path | None = ".env",
) -> tuple[str, str]:
    """
    Resolve Gemini cookies from multiple sources.

    Returns
    -------
    tuple[str, str]
        (psid, psidts) — psidts may be empty string if unavailable.

    Raises
    ------
    AuthError
        If PSID cannot be found from any source.
    """
    # 1. Explicit arguments
    if psid:
        return psid, psidts or ""

    # 2. Environment variables (already loaded or from os.environ)
    psid = os.getenv("GEMINI_PSID") or os.getenv("GEMINI_SECURE_1PSID")
    psidts = os.getenv("GEMINI_PSIDTS") or os.getenv("GEMINI_SECURE_1PSIDTS")
    if psid:
        return psid, psidts or ""

    # 3. .env file via python-dotenv
    if dotenv_path:
        _try_load_dotenv(dotenv_path)
        psid = os.getenv("GEMINI_PSID") or os.getenv("GEMINI_SECURE_1PSID")
        psidts = os.getenv("GEMINI_PSIDTS") or os.getenv("GEMINI_SECURE_1PSIDTS")
        if psid:
            return psid, psidts or ""

    # 4. JSON cookie file
    if cookies_json:
        return _load_from_json(cookies_json)

    # 5. Browser cookies (if browser-cookie3 is installed)
    result = _try_browser_cookies()
    if result:
        return result

    from .exceptions import AuthError
    raise AuthError(
        "Could not find Gemini cookies.\n\n"
        "Option A — Environment variables:\n"
        "  export GEMINI_PSID='your__Secure-1PSID value'\n"
        "  export GEMINI_PSIDTS='your__Secure-1PSIDTS value'\n\n"
        "Option B — .env file in your project directory:\n"
        "  GEMINI_PSID=your_value\n"
        "  GEMINI_PSIDTS=your_value\n\n"
        "Option C — JSON file:\n"
        "  g = Gemini(cookies_json='cookies.json')\n\n"
        "Option D — Direct:\n"
        "  g = Gemini(psid='...', psidts='...')\n\n"
        "Option E — Auto (install browser-cookie3 and be logged in):\n"
        "  pip install 'gemi[browser]'\n\n"
        "How to get your cookies:\n"
        "  1. Go to https://gemini.google.com and log in\n"
        "  2. Press F12 → Network tab → refresh page\n"
        "  3. Click any request and copy __Secure-1PSID and __Secure-1PSIDTS cookie values"
    )


def _try_load_dotenv(path: str | Path) -> None:
    """Try to load a .env file, silently ignore if dotenv not installed."""
    try:
        from dotenv import load_dotenv
        load_dotenv(path, override=False)
    except ImportError:
        pass
    except Exception:
        pass


def _load_from_json(path: str | Path) -> tuple[str, str]:
    """Load cookies from a JSON file (supports multiple export formats)."""
    from .exceptions import AuthError

    data = json.loads(Path(path).read_text(encoding="utf-8"))
    cookies: dict[str, str] = {}

    # Format 1: flat dict {"__Secure-1PSID": "value", ...}
    if isinstance(data, dict) and all(isinstance(v, str) for v in data.values()):
        cookies = data

    # Format 2: {"cookies": {"__Secure-1PSID": "value", ...}}
    elif isinstance(data, dict) and isinstance(data.get("cookies"), dict):
        inner = data["cookies"]
        if all(isinstance(v, str) for v in inner.values()):
            cookies = inner
        elif isinstance(data["cookies"], list):
            for item in data["cookies"]:
                if isinstance(item, dict):
                    name = item.get("name") or item.get("Name")
                    value = item.get("value") or item.get("Value")
                    if name and value:
                        cookies[name] = value

    # Format 3: array of {name, value} objects (browser export)
    elif isinstance(data, list):
        for item in data:
            if isinstance(item, dict):
                name = item.get("name") or item.get("Name")
                value = item.get("value") or item.get("Value")
                if name and value:
                    cookies[name] = value

    psid = cookies.get("__Secure-1PSID")
    psidts = cookies.get("__Secure-1PSIDTS", "")

    if not psid:
        raise AuthError(
            f"Could not find __Secure-1PSID in cookie file: {path}"
        )

    return psid, psidts


def _try_browser_cookies() -> tuple[str, str] | None:
    """Try to get cookies from local browser via browser-cookie3."""
    try:
        import browser_cookie3
        jar = browser_cookie3.load(domain_name=".google.com")
        cookies = {c.name: c.value for c in jar}
        psid = cookies.get("__Secure-1PSID")
        psidts = cookies.get("__Secure-1PSIDTS", "")
        if psid:
            return psid, psidts
    except ImportError:
        pass
    except Exception:
        pass
    return None
