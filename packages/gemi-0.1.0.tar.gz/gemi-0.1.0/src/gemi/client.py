"""
Gemini — the main entry point for gemi.

A sync-first, batteries-included client that wraps core.

Examples
--------
Basic usage::

    from gemi import Gemini

    g = Gemini()               # auto-loads cookies from env / .env / browser
    print(g.ask("Hello!"))     # plain string

    for chunk in g.stream("Tell me a story"):
        print(chunk, end="", flush=True)

    chat = g.chat(model="flash")
    chat.say("My name is Alex.")
    print(chat.say("What is my name?"))

Advanced / async::

    async def main():
        g = Gemini(psid="...", psidts="...")
        async with g:
            text = await g.async_ask("Hello!")
            print(text)
"""

from __future__ import annotations

import asyncio
import threading
from pathlib import Path
from typing import Generator, Iterator

from .cookies import load_cookies
from .response import Response
from .chat import Chat

# ---------------------------------------------------------------------------
# Model name aliases — users pass simple strings like "pro", "flash", etc.
# ---------------------------------------------------------------------------

_MODEL_ALIASES: dict[str, str] = {
    # Short aliases
    "pro":              "gemini-3-pro",
    "flash":            "gemini-3-flash",
    "thinking":         "gemini-3-flash-thinking",
    "pro-plus":         "gemini-3-pro-plus",
    "flash-plus":       "gemini-3-flash-plus",
    "thinking-plus":    "gemini-3-flash-thinking-plus",
    "pro-advanced":     "gemini-3-pro-advanced",
    "flash-advanced":   "gemini-3-flash-advanced",
    "thinking-advanced":"gemini-3-flash-thinking-advanced",
    # Full names pass through unchanged
    "gemini-3-pro":                   "gemini-3-pro",
    "gemini-3-flash":                 "gemini-3-flash",
    "gemini-3-flash-thinking":        "gemini-3-flash-thinking",
    "gemini-3-pro-plus":              "gemini-3-pro-plus",
    "gemini-3-flash-plus":            "gemini-3-flash-plus",
    "gemini-3-flash-thinking-plus":   "gemini-3-flash-thinking-plus",
    "gemini-3-pro-advanced":          "gemini-3-pro-advanced",
    "gemini-3-flash-advanced":        "gemini-3-flash-advanced",
    "gemini-3-flash-thinking-advanced":"gemini-3-flash-thinking-advanced",
}


def _resolve_model(name: str | None) -> str:
    """Resolve a user-friendly model name to a canonical gemi.core model name."""
    if not name:
        return "unspecified"
    lower = name.lower().strip()
    return _MODEL_ALIASES.get(lower, name)


# ---------------------------------------------------------------------------
# Background event loop (powers the sync interface)
# ---------------------------------------------------------------------------

class _LoopThread(threading.Thread):
    """A daemon thread that hosts an asyncio event loop."""

    def __init__(self):
        super().__init__(daemon=True, name="gemi-loop")
        self.loop: asyncio.AbstractEventLoop | None = None
        self._ready = threading.Event()

    def run(self):
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        self._ready.set()
        self.loop.run_forever()

    def start_and_wait(self) -> asyncio.AbstractEventLoop:
        self.start()
        self._ready.wait()
        return self.loop  # type: ignore[return-value]


# ---------------------------------------------------------------------------
# Main Gemini class
# ---------------------------------------------------------------------------

class Gemini:
    """
    The main interface for Google Gemini via gemi.

    Handles authentication, conversation, image generation, gems, chat
    management, and deep research — all with a simple synchronous API.

    Parameters
    ----------
    psid : str, optional
        Your ``__Secure-1PSID`` cookie value. If omitted, auto-discovered
        from environment variables, a ``.env`` file, or your browser.
    psidts : str, optional
        Your ``__Secure-1PSIDTS`` cookie value (not required for all accounts).
    cookies_json : str | Path, optional
        Path to a JSON cookie file (browser export format or simple dict).
    proxy : str, optional
        Proxy URL (e.g. ``"http://127.0.0.1:8080"``). Also reads from
        ``HTTPS_PROXY`` environment variable.
    dotenv_path : str | Path, optional
        Path to ``.env`` file. Defaults to ``".env"`` in the current directory.
    timeout : float, optional
        HTTP request timeout in seconds. Defaults to 300.
    auto_refresh : bool, optional
        Whether to auto-refresh cookies in the background. Defaults to False
        for short scripts, True for long-running services.

    Examples
    --------
    Minimal::

        from gemi import Gemini
        g = Gemini()
        print(g.ask("What is 2+2?"))

    With cookies::

        g = Gemini(psid="abc...", psidts="xyz...")

    With context manager (auto-closes cleanly)::

        with Gemini() as g:
            print(g.ask("Hello!"))

    Async usage::

        async def main():
            g = Gemini()
            async with g:
                print(await g.async_ask("Hello!"))
    """

    def __init__(
        self,
        psid: str | None = None,
        psidts: str | None = None,
        cookies_json: str | Path | None = None,
        proxy: str | None = None,
        dotenv_path: str | Path | None = ".env",
        timeout: float = 300,
        auto_refresh: bool = False,
    ):
        self._psid, self._psidts = load_cookies(
            psid=psid,
            psidts=psidts,
            cookies_json=cookies_json,
            dotenv_path=dotenv_path,
        )
        self._proxy = proxy
        self._timeout = timeout
        self._auto_refresh = auto_refresh

        # Spin up a background event loop for sync usage
        self._loop_thread = _LoopThread()
        self._loop = self._loop_thread.start_and_wait()

        # The underlying gemi.core client (initialized lazily)
        self._client = None

    # ------------------------------------------------------------------
    # Initialization / lifecycle
    # ------------------------------------------------------------------

    def _get_client(self):
        """Return the initialized GeminiClient, initializing it if needed."""
        if self._client is None:
            self._run(self._async_init())
        return self._client

    async def _async_init(self):
        """Initialize the gemi.core GeminiClient."""
        from .core import GeminiClient

        self._client = GeminiClient(
            secure_1psid=self._psid,
            secure_1psidts=self._psidts,
            proxy=self._proxy,
        )
        await self._client.init(
            timeout=self._timeout,
            auto_refresh=self._auto_refresh,
            verbose=False,
        )

    def close(self) -> None:
        """Close the client and release resources."""
        if self._client is not None:
            self._run(self._client.close())
            self._client = None
        self._loop.call_soon_threadsafe(self._loop.stop)

    async def async_close(self) -> None:
        """Async version of :meth:`close`."""
        if self._client is not None:
            await self._client.close()
            self._client = None

    # Context manager support
    def __enter__(self) -> "Gemini":
        self._get_client()
        return self

    def __exit__(self, *args) -> None:
        self.close()

    async def __aenter__(self) -> "Gemini":
        await self._async_init()
        return self

    async def __aexit__(self, *args) -> None:
        await self.async_close()

    # ------------------------------------------------------------------
    # Core: ask (single turn)
    # ------------------------------------------------------------------

    def ask(
        self,
        prompt: str,
        *,
        model: str | None = None,
        files: list[str | Path] | None = None,
        temporary: bool = False,
        gem: str | None = None,
    ) -> Response:
        """
        Ask Gemini a single question. Returns a :class:`Response` object.

        Use ``response.text`` or ``str(response)`` to get plain text.

        Parameters
        ----------
        prompt : str
            Your question or instruction.
        model : str, optional
            Model to use: ``"pro"``, ``"flash"``, ``"thinking"``,
            ``"pro-advanced"``, etc. Defaults to Gemini's auto selection.
        files : list[str | Path], optional
            Files to attach: images, PDFs, text files.
        temporary : bool, optional
            If True, this conversation won't be saved to Gemini history.
        gem : str, optional
            Gem ID or name to use as system prompt.

        Returns
        -------
        Response
            A :class:`Response` object. Access ``.text`` for the reply.

        Examples
        --------
        >>> g.ask("What is the capital of France?").text
        'Paris'

        >>> print(g.ask("Summarize this", files=["doc.pdf"]))

        >>> g.ask("What model are you?", model="flash").text

        >>> g.ask("Be a chef. Suggest a meal.", gem="my-chef-gem").text
        """
        client = self._get_client()
        model_name = _resolve_model(model)

        file_paths = [Path(f) for f in files] if files else None

        output = self._run(
            client.generate_content(
                prompt=prompt,
                files=file_paths,
                model=model_name,
                gem=gem,
                temporary=temporary,
            )
        )
        return Response(output, _loop=self._loop)

    def stream(
        self,
        prompt: str,
        *,
        model: str | None = None,
        files: list[str | Path] | None = None,
        temporary: bool = False,
        gem: str | None = None,
    ) -> Generator[str, None, None]:
        """
        Ask Gemini a question and stream the reply as text chunks.

        Yields
        ------
        str
            Incremental text chunks as they arrive from Gemini.

        Examples
        --------
        >>> for chunk in g.stream("Write a poem about the moon"):
        ...     print(chunk, end="", flush=True)
        >>> print()  # newline at end
        """
        client = self._get_client()
        model_name = _resolve_model(model)
        file_paths = [Path(f) for f in files] if files else None

        queue: asyncio.Queue = asyncio.Queue()
        _DONE = object()

        async def _producer():
            try:
                async for output in client.generate_content_stream(
                    prompt=prompt,
                    files=file_paths,
                    model=model_name,
                    temporary=temporary,
                    gem=gem,
                ):
                    if output.text_delta:
                        await queue.put(output.text_delta)
            finally:
                await queue.put(_DONE)

        asyncio.run_coroutine_threadsafe(_producer(), self._loop)

        while True:
            chunk = asyncio.run_coroutine_threadsafe(
                queue.get(), self._loop
            ).result()
            if chunk is _DONE:
                break
            yield chunk

    # ------------------------------------------------------------------
    # Core: multi-turn chat
    # ------------------------------------------------------------------

    def chat(
        self,
        model: str | None = None,
        gem: str | None = None,
    ) -> Chat:
        """
        Start a multi-turn conversation.

        Parameters
        ----------
        model : str, optional
            Model alias: ``"pro"``, ``"flash"``, ``"thinking"``, etc.
        gem : str, optional
            Gem ID or name to use as system prompt for this chat.

        Returns
        -------
        Chat
            A :class:`Chat` object. Use ``.say()`` to send messages.

        Examples
        --------
        >>> chat = g.chat(model="flash")
        >>> chat.say("My name is Alex.")
        >>> print(chat.say("What's my name?"))
        """
        client = self._get_client()
        model_name = _resolve_model(model)
        session = client.start_chat(model=model_name, gem=gem)
        return Chat(session=session, client=client, _loop=self._loop)

    def resume_chat(
        self,
        chat_id: str,
        model: str | None = None,
    ) -> Chat:
        """
        Resume a previous conversation by its chat ID.

        Parameters
        ----------
        chat_id : str
            A Gemini chat ID (e.g. ``"c_abc123"``).
        model : str, optional
            Model to continue using (should match the original).

        Returns
        -------
        Chat
            A :class:`Chat` object you can continue with ``.say()``.

        Examples
        --------
        >>> chat = g.resume_chat("c_abc123")
        >>> chat.say("Continue from where we left off.")
        """
        client = self._get_client()
        model_name = _resolve_model(model)
        session = client.start_chat(cid=chat_id, model=model_name)
        return Chat(session=session, client=client, _loop=self._loop)

    # ------------------------------------------------------------------
    # Chat management
    # ------------------------------------------------------------------

    def list_chats(self) -> list[dict]:
        """
        List your recent Gemini conversations.

        Returns
        -------
        list[dict]
            Each item has ``id``, ``title``, ``timestamp``, ``pinned`` keys.

        Examples
        --------
        >>> for c in g.list_chats():
        ...     print(c["id"], c["title"])
        """
        client = self._get_client()
        raw = client.list_chats() or []
        return [
            {
                "id": c.cid,
                "title": c.title,
                "timestamp": c.timestamp,
                "pinned": c.is_pinned,
            }
            for c in raw
        ]

    def read_chat(self, chat_id: str, limit: int = 20) -> list[dict]:
        """
        Read the message history of a specific chat.

        Parameters
        ----------
        chat_id : str
            The Gemini chat ID (e.g. ``"c_abc123"``).
        limit : int, optional
            Maximum number of turns to retrieve. Defaults to 20.

        Returns
        -------
        list[dict]
            Each item has ``role`` (``"user"`` or ``"model"``) and ``text``.

        Examples
        --------
        >>> turns = g.read_chat("c_abc123")
        >>> for t in turns:
        ...     print(f"[{t['role']}] {t['text'][:80]}")
        """
        client = self._get_client()
        history = self._run(client.read_chat(chat_id, limit=limit))
        if not history or not history.turns:
            return []
        return [{"role": t.role, "text": t.text} for t in history.turns]

    def delete_chat(self, chat_id: str) -> bool:
        """
        Delete a conversation from Gemini history.

        Parameters
        ----------
        chat_id : str
            The Gemini chat ID to delete (e.g. ``"c_abc123"``).

        Returns
        -------
        bool
            True if deletion was attempted successfully.

        Examples
        --------
        >>> g.delete_chat("c_abc123")
        True
        """
        client = self._get_client()
        self._run(client.delete_chat(chat_id))
        return True

    def delete_chats(self, chat_ids: list[str]) -> dict[str, bool]:
        """
        Delete multiple conversations at once.

        Parameters
        ----------
        chat_ids : list[str]
            List of chat IDs to delete.

        Returns
        -------
        dict[str, bool]
            Mapping of chat_id → success.

        Examples
        --------
        >>> results = g.delete_chats(["c_abc", "c_def"])
        >>> print(results)
        {'c_abc': True, 'c_def': True}
        """
        results = {}
        for cid in chat_ids:
            try:
                self.delete_chat(cid)
                results[cid] = True
            except Exception:
                results[cid] = False
        return results

    # ------------------------------------------------------------------
    # Models
    # ------------------------------------------------------------------

    def list_models(self) -> list[dict]:
        """
        List all available Gemini models for your account.

        Returns
        -------
        list[dict]
            Each item has ``name``, ``display_name``, ``description``,
            ``available`` keys.

        Examples
        --------
        >>> for m in g.list_models():
        ...     status = "✓" if m["available"] else "✗"
        ...     print(f"[{status}] {m['name']}: {m['display_name']}")
        """
        client = self._get_client()
        raw = client.list_models() or []
        return [
            {
                "name": m.model_name,
                "display_name": m.display_name,
                "description": m.description,
                "available": m.is_available,
            }
            for m in raw
        ]

    @property
    def models(self) -> list[str]:
        """
        Quick list of available model names.

        Examples
        --------
        >>> g.models
        ['gemini-3-flash', 'gemini-3-pro', ...]
        """
        return [m["name"] for m in self.list_models() if m["available"]]

    # ------------------------------------------------------------------
    # Gems
    # ------------------------------------------------------------------

    def get_gems(self, include_hidden: bool = False) -> list[dict]:
        """
        Fetch all gems (system prompts) for your account.

        Parameters
        ----------
        include_hidden : bool
            Include hidden system gems. Defaults to False.

        Returns
        -------
        list[dict]
            Each item has ``id``, ``name``, ``description``,
            ``prompt``, ``predefined`` keys.

        Examples
        --------
        >>> gems = g.get_gems()
        >>> for gem in gems:
        ...     print(gem["id"], "→", gem["name"])
        """
        client = self._get_client()
        jar = self._run(client.fetch_gems(include_hidden=include_hidden))
        return [
            {
                "id": gem.id,
                "name": gem.name,
                "description": gem.description or "",
                "prompt": gem.prompt or "",
                "predefined": gem.predefined,
            }
            for gem in jar
        ]

    def get_gem(self, name: str = None, gem_id: str = None) -> dict | None:
        """
        Find a specific gem by name or ID.

        Parameters
        ----------
        name : str, optional
            Gem name to search for.
        gem_id : str, optional
            Gem ID to look up.

        Returns
        -------
        dict | None
            Gem data dict or None if not found.

        Examples
        --------
        >>> gem = g.get_gem(name="Coding partner")
        >>> print(gem["id"])
        """
        client = self._get_client()
        jar = self._run(client.fetch_gems())
        gem = jar.get(id=gem_id, name=name)
        if gem is None:
            return None
        return {
            "id": gem.id,
            "name": gem.name,
            "description": gem.description or "",
            "prompt": gem.prompt or "",
            "predefined": gem.predefined,
        }

    def create_gem(
        self,
        name: str,
        prompt: str,
        description: str = "",
    ) -> dict:
        """
        Create a new custom gem (system prompt preset).

        Parameters
        ----------
        name : str
            Name for the new gem.
        prompt : str
            The system prompt / instructions for this gem.
        description : str, optional
            A short description of what this gem does.

        Returns
        -------
        dict
            The newly created gem's data.

        Examples
        --------
        >>> gem = g.create_gem(
        ...     name="Python Tutor",
        ...     prompt="You are an expert Python programming teacher.",
        ...     description="For learning Python",
        ... )
        >>> print(gem["id"])
        """
        client = self._get_client()
        gem = self._run(client.create_gem(
            name=name,
            prompt=prompt,
            description=description,
        ))
        return {"id": gem.id, "name": gem.name, "description": gem.description or "",
                "prompt": gem.prompt or "", "predefined": gem.predefined}

    def update_gem(
        self,
        gem_id: str,
        name: str,
        prompt: str,
        description: str = "",
    ) -> dict:
        """
        Update an existing custom gem.

        Parameters
        ----------
        gem_id : str
            The gem's ID to update.
        name : str
            New name.
        prompt : str
            New system prompt.
        description : str, optional
            New description.

        Returns
        -------
        dict
            Updated gem data.

        Examples
        --------
        >>> g.update_gem(
        ...     gem_id="abc123",
        ...     name="Advanced Python Tutor",
        ...     prompt="You are a senior Python engineer.",
        ... )
        """
        client = self._get_client()
        gem = self._run(client.update_gem(
            gem=gem_id,
            name=name,
            prompt=prompt,
            description=description,
        ))
        return {"id": gem.id, "name": gem.name, "description": gem.description or "",
                "prompt": gem.prompt or "", "predefined": gem.predefined}

    def delete_gem(self, gem_id: str) -> bool:
        """
        Delete a custom gem.

        Parameters
        ----------
        gem_id : str
            The gem ID to delete.

        Returns
        -------
        bool
            True if deleted successfully.

        Examples
        --------
        >>> g.delete_gem("abc123")
        True
        """
        client = self._get_client()
        self._run(client.delete_gem(gem=gem_id))
        return True

    # ------------------------------------------------------------------
    # Image generation shortcut
    # ------------------------------------------------------------------

    def generate_image(
        self,
        prompt: str,
        save_to: str | None = None,
        model: str | None = None,
    ) -> Response:
        """
        Generate images with Gemini's image generation model.

        Parameters
        ----------
        prompt : str
            What to generate, e.g. ``"a cat sitting on the moon"``.
        save_to : str, optional
            Directory to automatically save images to after generation.
        model : str, optional
            Model to use. Defaults to auto-selection.

        Returns
        -------
        Response
            Response with ``.images`` populated.

        Examples
        --------
        >>> r = g.generate_image("a cyberpunk cityscape at night")
        >>> r.save_images("./output/")

        >>> # One-liner: generate and save
        >>> g.generate_image("a cat", save_to="./cats/")
        """
        response = self.ask(f"Generate an image of: {prompt}", model=model)
        if save_to:
            response.save_images(save_to)
        return response

    # ------------------------------------------------------------------
    # Deep research
    # ------------------------------------------------------------------

    def research(
        self,
        prompt: str,
        timeout: float = 600.0,
        poll_interval: float = 10.0,
        on_status=None,
    ) -> str:
        """
        Run a full deep research cycle and return the final report text.

        Gemini browses the web, analyzes sources, and writes a comprehensive
        report. This may take several minutes.

        Parameters
        ----------
        prompt : str
            Research question or topic.
        timeout : float
            Max seconds to wait for completion. Defaults to 600 (10 minutes).
        poll_interval : float
            How often to check status, in seconds. Defaults to 10.
        on_status : callable, optional
            Called with each status update: ``on_status(status_dict)``.

        Returns
        -------
        str
            The full research report text.

        Examples
        --------
        >>> report = g.research("AI chip market trends 2025")
        >>> print(report)

        >>> # With progress callback
        >>> def show_progress(s):
        ...     print(f"[{s['state']}] {s.get('message', '')}")
        >>> report = g.research("climate change solutions", on_status=show_progress)
        """
        client = self._get_client()

        def _status_adapter(status_obj):
            if on_status:
                on_status({
                    "state": getattr(status_obj, "state", ""),
                    "done": getattr(status_obj, "done", False),
                    "message": str(status_obj),
                })

        result = self._run(
            client.deep_research(
                prompt=prompt,
                poll_interval=poll_interval,
                timeout=timeout,
                on_status=_status_adapter if on_status else None,
            )
        )

        if result.final_output:
            return result.final_output.text or ""
        if result.start_output:
            return result.start_output.text or ""
        return ""

    # ------------------------------------------------------------------
    # Async versions (for async code / notebooks)
    # ------------------------------------------------------------------

    async def async_ask(
        self,
        prompt: str,
        *,
        model: str | None = None,
        files: list[str | Path] | None = None,
        temporary: bool = False,
        gem: str | None = None,
    ) -> Response:
        """Async version of :meth:`ask`."""
        if self._client is None:
            await self._async_init()
        model_name = _resolve_model(model)
        file_paths = [Path(f) for f in files] if files else None
        output = await self._client.generate_content(
            prompt=prompt,
            files=file_paths,
            model=model_name,
            gem=gem,
            temporary=temporary,
        )
        return Response(output, _loop=self._loop)

    async def async_stream(
        self,
        prompt: str,
        *,
        model: str | None = None,
        files: list[str | Path] | None = None,
        temporary: bool = False,
        gem: str | None = None,
    ):
        """Async streaming version of :meth:`stream`. Yields str chunks."""
        if self._client is None:
            await self._async_init()
        model_name = _resolve_model(model)
        file_paths = [Path(f) for f in files] if files else None
        async for output in self._client.generate_content_stream(
            prompt=prompt,
            files=file_paths,
            model=model_name,
            temporary=temporary,
            gem=gem,
        ):
            if output.text_delta:
                yield output.text_delta

    def chat_from_async(
        self,
        model: str | None = None,
        gem: str | None = None,
    ) -> Chat:
        """Create a Chat session from within async code (same as :meth:`chat`)."""
        return self.chat(model=model, gem=gem)

    # ------------------------------------------------------------------
    # Account diagnostics
    # ------------------------------------------------------------------

    def inspect(self) -> dict:
        """
        Run account diagnostics to check feature availability.

        Returns
        -------
        dict
            Snapshot of account status and feature availability.

        Examples
        --------
        >>> info = g.inspect()
        >>> print("Deep research:", info["deep_research_available"])
        """
        client = self._get_client()
        snapshot = self._run(client.inspect_account_status())
        summary = snapshot.get("summary", {})
        return {
            "deep_research_available": summary.get("deep_research_feature_present", False),
            "rejected_probes": summary.get("rejected_probes", []),
            "account_status": str(getattr(client, "account_status", "unknown")),
            "raw": snapshot,
        }

    # ------------------------------------------------------------------
    # String representation
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        status = "initialized" if self._client else "lazy (not yet connected)"
        return f"Gemini(status={status!r})"

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _run(self, coro):
        """Run a coroutine synchronously via the background event loop."""
        return asyncio.run_coroutine_threadsafe(coro, self._loop).result()
