"""
gemi: The simplest Python library for Google Gemini web app.

Quick start:
    from gemi import Gemini

    g = Gemini()  # reads GEMINI_PSID / GEMINI_PSIDTS from env or .env
    print(g.ask("What is the capital of France?"))
"""

from .client import Gemini
from .chat import Chat
from .response import Response
from .exceptions import (
    AuthError,
    APIError,
    GeminiError,
    TimeoutError,
    UsageLimitExceeded,
    ModelInvalid,
    TemporarilyBlocked,
)

__all__ = [
    "Gemini",
    "Chat",
    "Response",
    "AuthError",
    "APIError",
    "GeminiError",
    "TimeoutError",
    "UsageLimitExceeded",
    "ModelInvalid",
    "TemporarilyBlocked",
]

__version__ = "0.1.0"
