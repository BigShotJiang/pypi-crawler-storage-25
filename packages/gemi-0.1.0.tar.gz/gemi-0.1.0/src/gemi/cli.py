#!/usr/bin/env python3
"""
gemi CLI — interact with Google Gemini from the terminal.

Examples:
  gemi ask "What is the capital of France?"
  gemi stream "Write a long story about dragons"
  gemi chat
  gemi chat c_abc123           # resume an existing chat
  gemi chats                   # list recent conversations
  gemi read c_abc123           # read a chat history
  gemi delete c_abc123         # delete a chat
  gemi models                  # list available models
  gemi gems                    # list available gems
  gemi gem-create --name "Chef" --prompt "You are a master chef."
  gemi gem-delete GEM_ID
  gemi research "AI chip competition 2025"
  gemi inspect                 # check account feature availability
"""

from __future__ import annotations

import argparse
import os
import sys


def _build_gemini(args) -> object:
    """Construct a Gemini instance from CLI arguments."""
    from gemi import Gemini

    return Gemini(
        psid=getattr(args, "psid", None) or os.getenv("GEMINI_PSID"),
        psidts=getattr(args, "psidts", None) or os.getenv("GEMINI_PSIDTS"),
        cookies_json=getattr(args, "cookies", None),
        proxy=getattr(args, "proxy", None) or os.getenv("HTTPS_PROXY"),
        timeout=getattr(args, "timeout", 300),
    )


# ---------------------------------------------------------------------------
# Command implementations
# ---------------------------------------------------------------------------


def cmd_ask(args):
    g = _build_gemini(args)
    files = getattr(args, "files", None)
    r = g.ask(args.prompt, model=args.model, files=files)
    print(r.text)
    if r.images:
        print(f"\n[{len(r.images)} image(s) in response]")
        for i, img in enumerate(r.images):
            print(f"  [{i}] {img.url}")
        print("  → Use Python API to save: r.save_images('./output/')")


def cmd_stream(args):
    g = _build_gemini(args)
    for chunk in g.stream(args.prompt, model=args.model):
        print(chunk, end="", flush=True)
    print()


def cmd_chat(args):
    """Interactive multi-turn chat REPL."""
    g = _build_gemini(args)
    chat_id = getattr(args, "chat_id", None)

    if chat_id:
        chat = g.resume_chat(chat_id, model=args.model)
        print(f"Resumed chat {chat_id}. Type 'exit' or Ctrl+C to quit.\n")
    else:
        chat = g.chat(model=args.model)
        print("New chat started. Type 'exit' or Ctrl+C to quit.\n")

    while True:
        try:
            user_input = input("You: ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\nGoodbye!")
            break

        if not user_input:
            continue
        if user_input.lower() in {"exit", "quit", "q"}:
            break

        print("Gemini: ", end="", flush=True)
        try:
            for chunk in chat.say_stream(user_input):
                print(chunk, end="", flush=True)
            print()
        except Exception as e:
            print(f"\n[Error: {e}]")

        if chat.chat_id:
            print(f"  [Chat ID: {chat.chat_id}]\n")


def cmd_chats(args):
    """List recent chats in a formatted table."""
    g = _build_gemini(args)
    chats = g.list_chats()
    if not chats:
        print("No recent chats found.")
        return

    from datetime import datetime
    id_w = max(len("ID"), max(len(c["id"]) for c in chats))
    title_w = 45

    print(f"\n{'ID':<{id_w}}   {'Title':<{title_w}}  Updated")
    print("-" * (id_w + title_w + 20))
    for c in chats:
        ts = (
            datetime.fromtimestamp(c["timestamp"]).strftime("%Y-%m-%d %H:%M")
            if c["timestamp"]
            else "-"
        )
        pin = "📌 " if c["pinned"] else "   "
        title = (c["title"] or "(untitled)")[:title_w]
        print(f"{c['id']:<{id_w}}   {pin}{title:<{title_w}}  {ts}")
    print()


def cmd_read(args):
    """Print a chat's message history."""
    g = _build_gemini(args)
    turns = g.read_chat(args.chat_id, limit=args.limit)
    if not turns:
        print(f"No messages found for chat {args.chat_id}.")
        return

    for i, t in enumerate(turns, 1):
        label = "  YOU" if t["role"] == "user" else "GEMINI"
        print(f"\n[{i}] {label}:")
        print(t["text"])
        print("─" * 60)


def cmd_delete(args):
    """Delete one or more chats."""
    g = _build_gemini(args)
    for cid in args.chat_ids:
        try:
            g.delete_chat(cid)
            print(f"✓ Deleted: {cid}")
        except Exception as e:
            print(f"✗ Error deleting {cid}: {e}", file=sys.stderr)


def cmd_models(args):
    """List all available Gemini models."""
    g = _build_gemini(args)
    models = g.list_models()
    if not models:
        print("No models found.")
        return

    print(f"\n{'Name':<38}  {'Display Name':<28}  Status")
    print("-" * 80)
    for m in models:
        status = "✓ available" if m["available"] else "✗ locked"
        print(f"{m['name']:<38}  {m['display_name']:<28}  {status}")
    print()


def cmd_gems(args):
    """List all available gems."""
    g = _build_gemini(args)
    include_hidden = getattr(args, "hidden", False)

    try:
        gems = g.get_gems(include_hidden=include_hidden)
    except Exception as e:
        print(f"Error fetching gems: {e}", file=sys.stderr)
        return

    if not gems:
        print("No gems found.")
        return

    n_system = sum(1 for g_ in gems if g_["predefined"])
    n_custom = len(gems) - n_system
    print(f"\nFound {len(gems)} gems ({n_system} system, {n_custom} custom)\n")
    print(f"{'ID':<30}  {'Name':<30}  Type")
    print("-" * 75)
    for gem in gems:
        kind = "system" if gem["predefined"] else "custom"
        print(f"{gem['id']:<30}  {gem['name']:<30}  {kind}")
    print()


def cmd_gem_create(args):
    """Create a new custom gem."""
    g = _build_gemini(args)
    gem = g.create_gem(
        name=args.name,
        prompt=args.prompt,
        description=getattr(args, "description", "") or "",
    )
    print(f"✓ Created gem: {gem['name']}")
    print(f"  ID:   {gem['id']}")
    print(f"  Use:  g.ask('...', gem='{gem['id']}')")


def cmd_gem_update(args):
    """Update an existing custom gem."""
    g = _build_gemini(args)
    gem = g.update_gem(
        gem_id=args.gem_id,
        name=args.name,
        prompt=args.prompt,
        description=getattr(args, "description", "") or "",
    )
    print(f"✓ Updated gem: {gem['name']} (ID: {gem['id']})")


def cmd_gem_delete(args):
    """Delete a custom gem by ID."""
    g = _build_gemini(args)
    try:
        g.delete_gem(args.gem_id)
        print(f"✓ Deleted gem: {args.gem_id}")
    except Exception as e:
        print(f"✗ Error: {e}", file=sys.stderr)


def cmd_research(args):
    """Submit and wait for a deep research task."""
    g = _build_gemini(args)
    timeout = getattr(args, "timeout", 600)
    output_file = getattr(args, "output", None)

    print(f"\n🔬 Deep Research: {args.prompt!r}")
    print("   Gemini will browse the web and compile a report.")
    print("   This typically takes 3–10 minutes.\n")

    _last_state = {"v": ""}

    def _on_status(s):
        state = s.get("state", "")
        if state != _last_state["v"]:
            _last_state["v"] = state
            print(f"  → {state}", flush=True)

    try:
        report = g.research(
            prompt=args.prompt,
            timeout=timeout,
            on_status=_on_status,
        )
    except Exception as e:
        print(f"\n✗ Research failed: {e}", file=sys.stderr)
        return 1

    if not report:
        print("\n✗ No report was returned. Try again or check your account eligibility.")
        return 1

    print(f"\n{'='*60}")
    if output_file:
        from pathlib import Path
        Path(output_file).write_text(report, encoding="utf-8")
        print(f"✓ Report saved to: {output_file}")
    else:
        print(report)
    return 0


def cmd_inspect(args):
    """Check account diagnostics and feature availability."""
    g = _build_gemini(args)
    try:
        info = g.inspect()
    except Exception as e:
        print(f"✗ Diagnostics failed: {e}", file=sys.stderr)
        return 1

    print("\n=== Account Diagnostics ===\n")
    print(f"  Account status:       {info['account_status']}")
    print(f"  Deep Research:        {'✓ available' if info['deep_research_available'] else '✗ not available'}")
    if info["rejected_probes"]:
        print(f"  Rejected probes:      {', '.join(info['rejected_probes'])}")
        print("  Tip: try refreshing cookies or using a different proxy/region.")
    else:
        print("  All capability probes passed.")
    print()
    return 0


# ---------------------------------------------------------------------------
# Argument parser
# ---------------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="gemi",
        description="🤖 gemi — a simple CLI for Google Gemini",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Auth: set GEMINI_PSID and GEMINI_PSIDTS env variables,\n"
            "or use a .env file, or --cookies cookies.json\n"
        ),
    )

    # Global options
    parser.add_argument("--psid", default=None, metavar="VALUE",
                        help="__Secure-1PSID cookie (or set GEMINI_PSID env var)")
    parser.add_argument("--psidts", default=None, metavar="VALUE",
                        help="__Secure-1PSIDTS cookie (or set GEMINI_PSIDTS env var)")
    parser.add_argument("--cookies", "-c", default=None, metavar="FILE",
                        help="Path to JSON cookie file")
    parser.add_argument("--proxy", default=None, metavar="URL",
                        help="Proxy URL (or set HTTPS_PROXY env var)")
    parser.add_argument("--model", "-m", default=None, metavar="NAME",
                        help="Model: pro, flash, thinking, pro-advanced, etc.")
    parser.add_argument("--timeout", type=float, default=300, metavar="SEC",
                        help="HTTP timeout in seconds (default: 300)")

    sub = parser.add_subparsers(dest="command", metavar="COMMAND")

    # ask
    p = sub.add_parser("ask", help="Ask a single question (non-streaming)")
    p.add_argument("prompt", help="Your question or prompt")
    p.add_argument("--files", "-f", nargs="+", default=None, metavar="FILE",
                   help="Files to attach (images, PDFs, etc.)")

    # stream
    p = sub.add_parser("stream", help="Ask with streaming output")
    p.add_argument("prompt", help="Your question or prompt")

    # chat (interactive REPL)
    p = sub.add_parser("chat", help="Interactive multi-turn chat")
    p.add_argument("chat_id", nargs="?", default=None,
                   help="Optional chat ID to resume (e.g. c_abc123)")

    # chats (list)
    sub.add_parser("chats", help="List recent conversations")

    # read
    p = sub.add_parser("read", help="Read a chat's message history")
    p.add_argument("chat_id", help="Chat ID (e.g. c_abc123)")
    p.add_argument("--limit", type=int, default=20, help="Max turns to show (default: 20)")

    # delete
    p = sub.add_parser("delete", help="Delete one or more chats")
    p.add_argument("chat_ids", nargs="+", metavar="CHAT_ID",
                   help="One or more chat IDs to delete")

    # models
    sub.add_parser("models", help="List available models for your account")

    # gems
    p = sub.add_parser("gems", help="List available gems (system prompts)")
    p.add_argument("--hidden", action="store_true",
                   help="Include hidden system gems")

    # gem-create
    p = sub.add_parser("gem-create", help="Create a custom gem")
    p.add_argument("--name", required=True, help="Gem name")
    p.add_argument("--prompt", required=True, help="System prompt / instructions")
    p.add_argument("--description", default="", help="Short description")

    # gem-update
    p = sub.add_parser("gem-update", help="Update an existing custom gem")
    p.add_argument("gem_id", help="Gem ID to update")
    p.add_argument("--name", required=True, help="New gem name")
    p.add_argument("--prompt", required=True, help="New system prompt")
    p.add_argument("--description", default="", help="New description")

    # gem-delete
    p = sub.add_parser("gem-delete", help="Delete a custom gem")
    p.add_argument("gem_id", help="Gem ID to delete")

    # research
    p = sub.add_parser("research", help="Run a deep research task")
    p.add_argument("prompt", help="Research topic or question")
    p.add_argument("--output", "-o", default=None, metavar="FILE",
                   help="Save report to this file instead of printing")
    p.add_argument("--timeout", type=float, default=600, metavar="SEC",
                   help="Max wait time in seconds (default: 600)")

    # inspect
    sub.add_parser("inspect", help="Check account feature availability")

    return parser


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 0

    dispatch = {
        "ask":        cmd_ask,
        "stream":     cmd_stream,
        "chat":       cmd_chat,
        "chats":      cmd_chats,
        "read":       cmd_read,
        "delete":     cmd_delete,
        "models":     cmd_models,
        "gems":       cmd_gems,
        "gem-create": cmd_gem_create,
        "gem-update": cmd_gem_update,
        "gem-delete": cmd_gem_delete,
        "research":   cmd_research,
        "inspect":    cmd_inspect,
    }

    fn = dispatch.get(args.command)
    if fn is None:
        print(f"Unknown command: {args.command}", file=sys.stderr)
        return 1

    try:
        result = fn(args)
        return 0 if result is None else int(result)
    except KeyboardInterrupt:
        print("\nInterrupted.")
        return 0
    except Exception as e:
        print(f"\nError: {e}", file=sys.stderr)
        if os.getenv("GEMINI_DEBUG"):
            import traceback
            traceback.print_exc()
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
