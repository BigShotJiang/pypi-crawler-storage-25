"""
Response — a simple, user-friendly wrapper around gemi.core ModelOutput.
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .core.types import ModelOutput


class Response:
    """
    A simplified wrapper around a Gemini model output.

    Attributes
    ----------
    text : str
        The main text response from Gemini.
    thoughts : str | None
        The model's internal reasoning (only for thinking models).
    images : list
        List of image objects in the response.

    Examples
    --------
    >>> r = g.ask("Tell me a joke")
    >>> print(r.text)
    >>> print(r)  # same as r.text

    >>> r = g.ask("Generate an image of a cat")
    >>> r.save_images("./images/")
    """

    def __init__(self, output: "ModelOutput", _loop: asyncio.AbstractEventLoop | None = None):
        self._output = output
        self._loop = _loop  # background loop from Gemini client, if available

    def __str__(self) -> str:
        return self.text

    def __repr__(self) -> str:
        preview = self.text[:80].replace("\n", " ")
        return f"Response(text={preview!r}...)"

    # ------------------------------------------------------------------
    # Core properties
    # ------------------------------------------------------------------

    @property
    def text(self) -> str:
        """The main text of the response."""
        return self._output.text or ""

    @property
    def thoughts(self) -> str | None:
        """Internal reasoning if using a thinking model. None otherwise."""
        t = self._output.thoughts
        return t if t else None

    @property
    def images(self) -> list:
        """List of Image objects (WebImage or GeneratedImage)."""
        return self._output.images or []

    @property
    def web_images(self) -> list:
        """Only web images (fetched from the internet) in the response."""
        try:
            from .core.types.image import WebImage
            return [img for img in self.images if isinstance(img, WebImage)]
        except ImportError:
            return self.images

    @property
    def generated_images(self) -> list:
        """Only AI-generated images in the response."""
        try:
            from .core.types.image import GeneratedImage
            return [img for img in self.images if isinstance(img, GeneratedImage)]
        except ImportError:
            return []

    @property
    def videos(self) -> list:
        """List of video objects, if any."""
        return self._output.videos or []

    @property
    def media(self) -> list:
        """List of media objects (audio, music), if any."""
        return self._output.media or []

    @property
    def candidates(self) -> list:
        """All response candidates (Gemini sometimes returns multiple alternatives)."""
        return self._output.candidates or []

    @property
    def metadata(self) -> list:
        """Raw chat metadata [cid, rid, rcid] — for session management."""
        return self._output.metadata

    @property
    def chat_id(self) -> str:
        """The Gemini chat ID (c_...) from this response, if available."""
        meta = self._output.metadata
        return meta[0] if meta else ""

    # ------------------------------------------------------------------
    # Image saving
    # ------------------------------------------------------------------

    def save_images(
        self,
        path: str = "images",
        prefix: str = "gemini",
        verbose: bool = True,
    ) -> list[str]:
        """
        Save all images in the response to disk (synchronous).

        Each image gets a unique filename based on prefix + index.

        Parameters
        ----------
        path : str
            Directory to save images into. Created automatically if needed.
        prefix : str
            Filename prefix (e.g. ``"gemini"`` → ``"gemini_0.png"``).
        verbose : bool
            Print save paths to console.

        Returns
        -------
        list[str]
            Absolute paths of all saved image files.

        Examples
        --------
        >>> r = g.ask("Generate an image of a sunny beach")
        >>> paths = r.save_images("./beach_pics/")
        >>> print(paths)
        ['/absolute/path/beach_pics/gemini_0.png']
        """
        if not self.images:
            if verbose:
                print("No images in this response.")
            return []

        async def _save_all():
            saved = []
            for i, img in enumerate(self.images):
                fname = f"{prefix}_{i}"
                # Pass client=None so Image creates its own session
                # (avoids cross-loop issues — Image.save handles this gracefully)
                dest = await img.save(
                    path=path,
                    filename=fname,
                    verbose=verbose,
                    client=None,
                )
                if dest:
                    saved.append(dest)
            return saved

        # Run using the shared background loop if available, else create one
        if self._loop is not None and self._loop.is_running():
            future = asyncio.run_coroutine_threadsafe(_save_all(), self._loop)
            return future.result(timeout=120)
        else:
            return asyncio.run(_save_all())

    # ------------------------------------------------------------------
    # Candidate selection
    # ------------------------------------------------------------------

    def choose_candidate(self, index: int) -> "Response":
        """
        Switch to a different response candidate.

        Gemini sometimes produces multiple answer candidates. This lets you
        pick which one becomes ``response.text``.

        Parameters
        ----------
        index : int
            Zero-based index of the candidate to select.

        Returns
        -------
        Response
            This same Response object (mutated in-place), for chaining.

        Examples
        --------
        >>> r = g.ask("Give me a book recommendation")
        >>> if len(r.candidates) > 1:
        ...     r.choose_candidate(1)
        ...     print(r.text)
        """
        if index >= len(self.candidates):
            raise ValueError(
                f"Only {len(self.candidates)} candidate(s) available, "
                f"but index {index} was requested."
            )
        self._output.chosen = index
        return self

    # ------------------------------------------------------------------
    # Convenience
    # ------------------------------------------------------------------

    def print(self) -> None:
        """Print the response text (and thoughts if present) to stdout."""
        if self.thoughts:
            print(f"[Thinking]\n{self.thoughts}\n")
        print(self.text)
