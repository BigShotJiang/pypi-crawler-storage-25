"""Configuration management for omnibackup."""

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import yaml


@dataclass
class Settings:
    """Omnibackup settings."""
    
    # Storage
    storage_path: Path = Path("/tmp/omnibackup")
    metadata_backend: str = "sqlite"
    
    # Celery
    celery_broker_url: str = "redis://localhost:6379/0"
    celery_result_backend: str = "redis://localhost:6379/0"
    celery_timezone: str = "UTC"
    
    # Logging
    log_level: str = "INFO"
    log_format: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    
    # Cloud Storage (S3)
    s3_bucket: Optional[str] = None
    s3_region: str = "us-east-1"
    s3_access_key: Optional[str] = None
    s3_secret_key: Optional[str] = None
    
    # Cloud Storage (GCS)
    gcs_bucket: Optional[str] = None
    gcs_project: Optional[str] = None
    gcs_credentials_path: Optional[str] = None
    
    @classmethod
    def from_env(cls) -> "Settings":
        """Load settings from environment variables."""
        return cls(
            storage_path=Path(os.getenv("OMNIBACKUP_STORAGE_PATH", "/tmp/omnibackup")),
            metadata_backend=os.getenv("OMNIBACKUP_METADATA_BACKEND", "sqlite"),
            celery_broker_url=os.getenv("CELERY_BROKER_URL", "redis://localhost:6379/0"),
            celery_result_backend=os.getenv("CELERY_RESULT_BACKEND", "redis://localhost:6379/0"),
            celery_timezone=os.getenv("CELERY_TIMEZONE", "UTC"),
            log_level=os.getenv("OMNIBACKUP_LOG_LEVEL", "INFO"),
            s3_bucket=os.getenv("OMNIBACKUP_S3_BUCKET"),
            s3_region=os.getenv("OMNIBACKUP_S3_REGION", "us-east-1"),
            s3_access_key=os.getenv("OMNIBACKUP_S3_ACCESS_KEY"),
            s3_secret_key=os.getenv("OMNIBACKUP_S3_SECRET_KEY"),
            gcs_bucket=os.getenv("OMNIBACKUP_GCS_BUCKET"),
            gcs_project=os.getenv("OMNIBACKUP_GCS_PROJECT"),
            gcs_credentials_path=os.getenv("OMNIBACKUP_GCS_CREDENTIALS"),
        )
    
    @classmethod
    def from_yaml(cls, path: Path) -> "Settings":
        """Load settings from YAML file."""
        with open(path) as f:
            data = yaml.safe_load(f)
        
        settings = cls()
        
        storage = data.get("storage", {})
        if "path" in storage:
            settings.storage_path = Path(storage["path"])
        if "metadata_backend" in storage:
            settings.metadata_backend = storage["metadata_backend"]
        
        celery = data.get("celery", {})
        settings.celery_broker_url = celery.get("broker_url", settings.celery_broker_url)
        settings.celery_result_backend = celery.get("result_backend", settings.celery_result_backend)
        settings.celery_timezone = celery.get("timezone", settings.celery_timezone)
        
        logging = data.get("logging", {})
        settings.log_level = logging.get("level", settings.log_level)
        
        s3 = data.get("s3", {})
        settings.s3_bucket = s3.get("bucket")
        settings.s3_region = s3.get("region", settings.s3_region)
        settings.s3_access_key = s3.get("access_key")
        settings.s3_secret_key = s3.get("secret_key")
        
        gcs = data.get("gcs", {})
        settings.gcs_bucket = gcs.get("bucket")
        settings.gcs_project = gcs.get("project")
        settings.gcs_credentials_path = gcs.get("credentials_path")
        
        return settings
    
    def to_yaml(self, path: Path) -> None:
        """Save settings to YAML file."""
        data = {
            "storage": {
                "path": str(self.storage_path),
                "metadata_backend": self.metadata_backend,
            },
            "celery": {
                "broker_url": self.celery_broker_url,
                "result_backend": self.celery_result_backend,
                "timezone": self.celery_timezone,
            },
            "logging": {
                "level": self.log_level,
            },
            "s3": {
                "bucket": self.s3_bucket,
                "region": self.s3_region,
                "access_key": self.s3_access_key,
                "secret_key": self.s3_secret_key,
            },
            "gcs": {
                "bucket": self.gcs_bucket,
                "project": self.gcs_project,
                "credentials_path": self.gcs_credentials_path,
            },
        }
        
        with open(path, "w") as f:
            yaml.dump(data, f, default_flow_style=False)


# Global settings instance
_settings: Optional[Settings] = None


def get_settings() -> Settings:
    """Get settings (from env or config file)."""
    global _settings
    
    if _settings is not None:
        return _settings
    
    # Try to load from config file
    config_paths = [
        Path("omnibackup.yaml"),
        Path("omnibackup.yml"),
        Path.home() / ".omnibackup.yaml",
        Path.home() / ".omnibackup.yml",
        Path("/etc/omnibackup/omnibackup.yaml"),
    ]
    
    for path in config_paths:
        if path.exists():
            _settings = Settings.from_yaml(path)
            return _settings
    
    # Fallback to environment variables
    _settings = Settings.from_env()
    return _settings


def set_settings(settings: Settings) -> None:
    """Set global settings."""
    global _settings
    _settings = settings
