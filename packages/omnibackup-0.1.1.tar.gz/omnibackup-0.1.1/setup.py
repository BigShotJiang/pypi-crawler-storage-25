from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="omnibackup",
    version="0.1.0",
    author="Omnibackup Team",
    author_email="team@omnibackup.dev",
    description="Universal Database Backup and Restore System",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/omnibackup",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: System Administrators",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Database",
        "Topic :: System :: Archiving :: Backup",
        "Topic :: Utilities",
    ],
    python_requires=">=3.8",
    install_requires=requirements,
    entry_points={
        "console_scripts": [
            "omnibackup=omnibackup.cli.main:main",
        ],
    },
    extras_require={
        "postgres": ["psycopg2-binary>=2.9.0"],
        "mysql": ["mysql-connector-python>=8.1.0"],
        "mongodb": ["pymongo>=4.5.0"],
        "s3": ["boto3>=1.28.0"],
        "gcs": ["google-cloud-storage>=2.10.0"],
        "dev": [
            "pytest>=7.4.0",
            "pytest-asyncio>=0.21.0",
            "black>=23.7.0",
            "isort>=5.12.0",
            "flake8>=6.1.0",
            "mypy>=1.5.0",
        ],
    },
)
