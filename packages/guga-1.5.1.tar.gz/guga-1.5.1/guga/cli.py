#!/usr/bin/env python3
"""
guga - Send notifications to your Android via the GuGa server.
Version: 1.5.1

Usage:
  guga [options] "message"           Send a notification
  guga [options] command args        Run a command and notify when finished
  guga --ask-user "Question"         Ask a question to your phone and wait for reply
  guga --run --interactive python    Run interactively (forwards prompts to phone)
  guga -i --expect "regex" cmd      Use custom regex for interactive prompt detection

Options:
  -m, --message                      Force message mode
  -r, --run                          Force run mode
  -i, --interactive                  Remote interactive mode (PTY wrapping)
  --expect REGEX                     Custom prompt regex for --interactive
  --ask-user PROMPT                  Synchronous request-reply loop
  --delay DURATION                   Timeout for replies (e.g. 5m, 1200s, never)
  --send-to DEVICE_ID                Target a specific device or custom tag
  --status                           Show server status and connections
  --qr                               Show pairing QR code
  --start-server                     Start the GuGa ASGI server
"""

import argparse
from typing import List, Optional, Any
import sys
import json
import os
import shlex
import shutil
import re
import subprocess
import time
import urllib.request
import urllib.error
import configparser
import uuid
try:
    import argcomplete
except ImportError:
    argcomplete = None
from guga import __version__
from guga.db_utils import Database

db = Database()

# ── Colour helpers ────────────────────────────────────────────────────────────
RESET  = "\033[0m"; BOLD = "\033[1m"; DIM = "\033[2m"
GREEN  = "\033[32m"; YELLOW = "\033[33m"; RED = "\033[31m"; CYAN = "\033[36m"

CONFIG_DIR = os.environ.get("GUGA_CONFIG_DIR", os.path.expanduser("~/.guga"))
LOGS_DIR = os.path.join(CONFIG_DIR, "logs")
os.makedirs(LOGS_DIR, exist_ok=True)
CAPABILITIES_FILE = os.path.join(CONFIG_DIR, "capabilities.json")

def load_capabilities():
    return db.get_capabilities()

def parse_duration(duration: str) -> Optional[int]:
    """Parses duration strings like 1200s, 10m, 1h, or 'never' into seconds."""
    if not duration: return None
    duration = duration.lower().strip()
    if duration == "never": return None
    
    match = re.match(r"^(\d+)([smh]?)$", duration)
    if not match:
        raise ValueError(f"Invalid duration format: {duration} (use e.g. 120s, 5m, 1h, or never)")
    
    val, unit = match.groups()
    val = int(val)
    if unit == 'm': val *= 60
    elif unit == 'h': val *= 3600
    return val

def check_capabilities(args):
    """Checks if the system has the required capabilities for the given arguments."""
    state = load_capabilities()
    caps = state.get("capabilities", {})
    
    # Example checks:
    if args.status and not caps.get("background_service"):
        # If they ask for status but no background service, it's fine, but we can warn
        pass
        
    if not state.get("installed_stages"):
        # If no stages are installed, they probably haven't run --install-service
        if not (args.install_service or args.uninstall):
            print(f"⚠️  {BOLD}{YELLOW}Warning:{RESET} GuGa hasn't been fully initialized.")
            print(f"   Run {BOLD}guga --install-service{RESET} to set up the system.\n")


# ── Helpers ───────────────────────────────────────────────────────────────────

def format_duration(seconds):
    seconds = int(seconds)
    if seconds < 60:
        return f"{seconds}s"
    elif seconds < 3600:
        m, s = divmod(seconds, 60)
        return f"{m}m {s}s"
    else:
        h, rem = divmod(seconds, 3600)
        m, _ = divmod(rem, 60)
        return f"{h}h {m}m"


def is_runnable(token):
    return shutil.which(token) is not None or os.path.isfile(token)


def last_meaningful_line(text):
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    return lines[-1] if lines else None


CHOICES = []
_choice_idx = 0

def guga_input(prompt):
    global _choice_idx
    if _choice_idx < len(CHOICES):
        val = CHOICES[_choice_idx]
        _choice_idx += 1
        # If it's empty, print it as [ENTER] for clarity
        display_val = val if val else "[ENTER]"
        print(f"{prompt}{BOLD}{display_val}{RESET} {DIM}(auto){RESET}")
        return val
    return input(prompt)


# ── Core actions ──────────────────────────────────────────────────────────────

def broadcast_message(message: str, port: int, silent: bool, title: Optional[str] = None, msg_id: Optional[str] = None):
    """
    Sends a notification message to the GuGa server (broadcast).

    Args:
        message (str): The text message to send.
        port (int): The port where the GuGa server is listening.
        silent (bool): If True, suppresses success/error messages in the console.
        title (str, optional): An optional title/label for the notification.
        msg_id (str, optional): A unique ID for this message.
    """
    url = f"http://localhost:{port}/send"

    payload = {"message": message}
    if title:
        payload["title"] = title
    if msg_id:
        payload["unique_message_id"] = msg_id

    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=5) as response:
            if not silent:
                print(f"✅ Sent ({response.status}): {message}")
    except urllib.error.URLError as e:
        reason = getattr(e, "reason", str(e))
        if not silent:
            print(f"❌ Could not reach GuGa server on port {port}: {reason}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        if not silent:
            print(f"❌ Unexpected error: {e}", file=sys.stderr)
        sys.exit(1)


def send_message_to(target_id: str, message: str, port: int, silent: bool, title: Optional[str] = None, msg_id: Optional[str] = None):
    """
    Sends a notification message to a specific device via the GuGa server.

    Args:
        target_id (str): The device_id or session_id of the recipient.
        message (str): The text message to send.
        port (int): The port where the GuGa server is listening.
        silent (bool): If True, suppresses success/error messages in the console.
        title (str, optional): An optional title/label for the notification.
        msg_id (str, optional): A unique ID for this message.
    """
    url = f"http://localhost:{port}/send/{target_id}"

    payload = {"message": message}
    if title:
        payload["title"] = title
    if msg_id:
        payload["unique_message_id"] = msg_id

    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=5) as response:
            if not silent:
                print(f"✅ Sent to {target_id} ({response.status}): {message}")
    except urllib.error.URLError as e:
        reason = getattr(e, "reason", str(e))
        if not silent:
            print(f"❌ Could not reach GuGa server on port {port}: {reason}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        if not silent:
            print(f"❌ Unexpected error: {e}", file=sys.stderr)
        sys.exit(1)

def guga_ask_user(prompt: str, port: int, device_id: str, title: Optional[str] = None, timeout: Optional[int] = None, quiet: bool = False, default: Optional[str] = None) -> str:
    """
    Sends a synchronous request-reply prompt to a specific device.
    Blocks the local CLI until the user replies from the Android app
    or the request times out.
    
    Args:
        prompt (str): The question to show the user.
        port (int): GuGa server port.
        device_id (str): Target device identifier.
        title (str, optional): Label for the notification.
        timeout (int, optional): Seconds to wait before expiring.
        quiet (bool): If True, suppresses printing the reply to stdout.
        default (str, optional): Default value to return if the request times out.
        
    Returns:
        str: The user's reply or the default value.
    """
    url = f"http://localhost:{port}/api/ask"
    payload = {"message": prompt, "device_id": device_id, "timeout": timeout}
    if title:
        payload["title"] = title
    
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    
    try:
        # urlopen timeout should be slightly more than the server wait time
        req_timeout = (timeout + 5) if timeout is not None else None
        with urllib.request.urlopen(req, timeout=req_timeout) as response:
            res_data = json.load(response)
            if "reply" in res_data:
                reply = res_data["reply"]
                if not quiet:
                    print(reply)
                return reply
            elif "error" in res_data:
                print(f"❌ Error: {res_data['error']}", file=sys.stderr)
                sys.exit(1)
    except (urllib.error.HTTPError) as e:
        if e.code == 408:
            if default is not None:
                if not quiet:
                    print(default)
                return default
            print("❌ Expired: Timed out waiting for user reply.", file=sys.stderr)
            sys.exit(1)
        try:
            error_data = json.loads(e.read().decode())
            print(f"❌ Error: {error_data.get('error', e.reason)}", file=sys.stderr)
        except Exception:
            print(f"❌ Server error: {e.reason}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        # Check if it's a timeout error (socket.timeout or similar)
        if "timeout" in str(e).lower() or "timed out" in str(e).lower():
            print("❌ Expired: Timed out waiting for user reply.", file=sys.stderr)
        else:
            print(f"❌ Request failed: {e}", file=sys.stderr)
        sys.exit(1)


def run_interactive_command(cmd_args: List[str], port: int, silent: bool, title: str, target_id: Optional[str] = None, expect_regex: Optional[str] = None, look_for: Optional[str] = None):
    """
    Spawns a command in a pseudo-terminal (PTY) using pexpect.
    Monitors stdout for common terminal prompts.
    When a prompt is detected, it is forwarded to the user's phone.
    """
    try:
        import pexpect
    except ImportError:
        print(f"\n  {RED}✗  ERROR:{RESET} 'pexpect' package is required for interactive mode.")
        print(f"  {DIM}Install it with: {RESET}{BOLD}pip install pexpect{RESET}\n")
        sys.exit(1)

    cmd_label = " ".join(cmd_args)
    start = time.time()
    
    unique_msg_id = uuid.uuid4().hex[:8]
    log_path = os.path.join(LOGS_DIR, f"{unique_msg_id}.log")
    look_for_re = re.compile(look_for) if look_for else None

    if not silent:
        print(f"▶ guga interactive: {cmd_label}\n")
        print(f"  {DIM}Log file: {log_path}{RESET}\n")

    # Default regex matches any line that ends with :, ?, or >, plus optional spaces.
    prompt_regex = expect_regex if expect_regex else r'[:?>]\s*$'
    captured_lines = []

    try:
        full_cmd = shlex.join(cmd_args)
        child = pexpect.spawn(full_cmd, encoding='utf-8', timeout=None)
        
        with open(log_path, "w") as log_f:
            while child.isalive():
                try:
                    index = child.expect([prompt_regex, pexpect.EOF], timeout=1)
                    
                    output = child.before
                    if output:
                        print(output, end="", flush=True)
                        log_f.write(output)
                        log_f.flush()
                        captured_lines.append(output)
                        
                        if look_for_re:
                            for line in output.splitlines():
                                if look_for_re.search(line):
                                    msg = line.strip()
                                    random_id = uuid.uuid4().hex[:8]
                                    if target_id:
                                        send_message_to(target_id, msg, port, silent, title, msg_id=random_id)
                                    else:
                                        broadcast_message(msg, port, silent, title, msg_id=random_id)

                    if index == 0: # Prompt detected!
                        prompt = child.after
                        print(prompt, end="", flush=True)
                        log_f.write(prompt)
                        log_f.flush()
                        captured_lines.append(prompt)

                        if not silent:
                            print(f"\n{YELLOW}🔔 [REMOTE ASK]{RESET} Forwarding prompt to {target_id or 'devices'}...")
                        
                        context = (output.splitlines()[-1] if "\n" in output else output) + prompt
                        reply = guga_ask_user(context.strip(), port, target_id, title="Interactive Prompt", quiet=True)
                        child.sendline(reply)
                    
                    elif index == 1: # EOF
                        break

                except pexpect.TIMEOUT:
                    output = child.before
                    # Note: pexpect.before keeps growing until a match. 
                    # To avoid re-printing, we only print if it changed.
                    # However, child.before is the WHOLE buffer since start/last match.
                    # A better way is to use expect with a small timeout and check what's new.
                    # For simplicity, we'll use child.read_nonblocking if we wanted true streaming,
                    # but pexpect's expect(timeout) is okay if we manage the printed state.
                    # The existing code had a bug where it re-printed. Let's fix that.
                    continue
                except pexpect.EOF:
                    break

        child.wait()
        exit_code = child.exitstatus if child.exitstatus is not None else 0

    except Exception as e:
        print(f"❌ Error during interactive execution: {e}", file=sys.stderr)
        sys.exit(1)

    elapsed = format_duration(time.time() - start)
    last_line = last_meaningful_line("".join(captured_lines))

    status, verb = ("✅", "done") if exit_code == 0 else ("❌", f"failed (exit {exit_code})")
    parts = [f"{status} {cmd_label} {verb} — {elapsed}"]
    if last_line:
        parts.append(last_line)

    msg = "\n".join(parts)
    if target_id:
        send_message_to(target_id, msg, port, silent, title, msg_id=unique_msg_id)
    else:
        broadcast_message(msg, port, silent, title, msg_id=unique_msg_id)
    
    if not silent:
        print(f"\n{parts[0]}")
    
    sys.exit(exit_code)


def run_command(cmd_args: List[str], port: int, silent: bool, title: str, target_id: Optional[str] = None, interactive: bool = False, expect_regex: Optional[str] = None, look_for: Optional[str] = None):
    """
    Executes a shell command, streams its output to the console, and sends a 
    notification via GuGa when the command completes or is interrupted.
    """
    cmd_label = " ".join(cmd_args)
    start = time.time()
    
    unique_msg_id = uuid.uuid4().hex[:8]
    log_path = os.path.join(LOGS_DIR, f"{unique_msg_id}.log")
    look_for_re = re.compile(look_for) if look_for else None

    if not silent:
        print(f"▶ guga watching: {cmd_label}\n")
        print(f"  {DIM}Log file: {log_path}{RESET}\n")

    captured_lines = []
    if interactive:
        return run_interactive_command(cmd_args, port, silent, title, target_id, expect_regex=expect_regex, look_for=look_for)

    try:
        process = subprocess.Popen(
            cmd_args,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
        )
        
        with open(log_path, "w") as log_f:
            for line in process.stdout:
                print(line, end="")
                log_f.write(line)
                log_f.flush()
                captured_lines.append(line)
                
                if look_for_re and look_for_re.search(line):
                    msg = line.strip()
                    random_id = uuid.uuid4().hex[:8]
                    if target_id:
                        send_message_to(target_id, msg, port, silent, title, msg_id=random_id)
                    else:
                        broadcast_message(msg, port, silent, title, msg_id=random_id)

        process.wait()
        exit_code = process.returncode

    except FileNotFoundError:
        print(f"❌ Command not found: {cmd_args[0]}", file=sys.stderr)
        sys.exit(1)
    except KeyboardInterrupt:
        elapsed = format_duration(time.time() - start)
        msg = f"⚠️ {cmd_label} interrupted after {elapsed}"
        if target_id:
            send_message_to(target_id, msg, port, silent, title, msg_id=unique_msg_id)
        else:
            broadcast_message(msg, port, silent, title, msg_id=unique_msg_id)
        sys.exit(130)

    elapsed = format_duration(time.time() - start)
    last_line = last_meaningful_line("".join(captured_lines))

    status, verb = ("✅", "done") if exit_code == 0 else ("❌", f"failed (exit {exit_code})")
    parts = [f"{status} {cmd_label} {verb} — {elapsed}"]
    if last_line:
        parts.append(last_line)

    msg = "\n".join(parts)
    if target_id:
        send_message_to(target_id, msg, port, silent, title, msg_id=unique_msg_id)
    else:
        broadcast_message(msg, port, silent, title, msg_id=unique_msg_id)
    sys.exit(exit_code)


def guga_approve(port: int, watch: bool = False, approve_all: bool = False):
    """Interactive loop to approve pending pairings."""
    base_url = f"http://localhost:{port}/api"
    
    def get_pending() -> List[dict]:
        try:
            req = urllib.request.Request(f"{base_url}/pending")
            with urllib.request.urlopen(req, timeout=2) as r:
                return json.load(r).get("pending", [])
        except Exception as e:
            print(f"  {RED}✗{RESET} Error reaching server: {e}")
            return []

    if approve_all:
        pending = get_pending()
        if not pending:
            print(f"  {DIM}No pending requests to approve.{RESET}")
            return
        for p in pending:
            payload = json.dumps({"device_id": p['device_id'], "action": "approve"}).encode()
            req = urllib.request.Request(f"{base_url}/approve", data=payload, headers={"Content-Type": "application/json"}, method="POST")
            urllib.request.urlopen(req)
        print(f"  {GREEN}✓ Approved {len(pending)} devices.{RESET}")
        return

    def format_time(ts: float) -> str:
        diff = int(time.time() - ts)
        if diff < 10: return "just now"
        if diff < 60: return f"{diff}s ago"
        return f"{diff // 60} min ago"

    def print_list(pending: List[dict]) -> None:
        print(f"\n  {DIM}{'─' * 42}{RESET}")
        print(f"   {BOLD}Pending pairing requests{RESET}")
        print(f"  {DIM}{'─' * 42}{RESET}")
        for i, p in enumerate(pending):
            name = p['device_name'][:14].ljust(14)
            did  = p['device_id'][:8]
            pin  = " ".join(p['pin'])
            ago  = format_time(p['requested_at'])
            print(f"  {i+1})  {BOLD}{name}{RESET}  {DIM}{did}{RESET}   {CYAN}{pin}{RESET}   {ago}")
        print(f"  {DIM}{'─' * 42}{RESET}")

    if watch:
        print(f"\n  Watching for pairing requests... {DIM}(Ctrl+C to stop){RESET}")
        seen_ids = set()
        try:
            while True:
                pending = get_pending()
                new_entries = [p for p in pending if p['device_id'] not in seen_ids]
                if new_entries:
                    for p in new_entries:
                        print(f"\n  {BOLD}{YELLOW}New request:{RESET}")
                        print(f"  1)  {BOLD}{p['device_name'][:14].ljust(14)}{RESET}  {DIM}{p['device_id'][:8]}{RESET}   {CYAN}{' '.join(p['pin'])}{RESET}   just now")
                        print(f"  {DIM}{'─' * 42}{RESET}")
                        
                        choice = guga_input(f"  {BOLD}[A] approve   [R] reject   [S] skip{RESET}\n\n  Your choice: ").strip().lower()
                        if choice == 'a':
                            action_url = f"{base_url}/approve"
                            payload = json.dumps({"device_id": p['device_id'], "action": "approve"}).encode()
                            req = urllib.request.Request(action_url, data=payload, headers={"Content-Type": "application/json"}, method="POST")
                            urllib.request.urlopen(req)
                            print(f"  {GREEN}✓ Approved{RESET}")
                        elif choice == 'r':
                            action_url = f"{base_url}/approve"
                            payload = json.dumps({"device_id": p['device_id'], "action": "reject"}).encode()
                            req = urllib.request.Request(action_url, data=payload, headers={"Content-Type": "application/json"}, method="POST")
                            urllib.request.urlopen(req)
                            print(f"  {RED}✗ Rejected{RESET}")
                        
                        seen_ids.add(p['device_id'])
                time.sleep(2)
        except KeyboardInterrupt:
            print("\n  Stopped watching.")
            return

    pending = get_pending()
    if not pending:
        print(f"\n  {DIM}No pending pairing requests.{RESET}\n")
        return

    print_list(pending)
    print(f"  {BOLD}[A] approve all   [R] reject all   [1,2,...] choose{RESET}")
    choice = guga_input(f"\n  Your choice: ").strip().lower()

    if choice == 'a':
        for p in pending:
            payload = json.dumps({"device_id": p['device_id'], "action": "approve"}).encode()
            req = urllib.request.Request(f"{base_url}/approve", data=payload, headers={"Content-Type": "application/json"}, method="POST")
            urllib.request.urlopen(req)
        print(f"  {GREEN}✓ All approved{RESET}")
    elif choice == 'r':
        for p in pending:
            payload = json.dumps({"device_id": p['device_id'], "action": "reject"}).encode()
            req = urllib.request.Request(f"{base_url}/approve", data=payload, headers={"Content-Type": "application/json"}, method="POST")
            urllib.request.urlopen(req)
        print(f"  {RED}✗ All rejected{RESET}")
    else:
        try:
            indices = [int(x.strip()) - 1 for x in choice.replace(',', ' ').split() if x.strip().isdigit()]
            for i, p in enumerate(pending):
                action = "approve" if i in indices else "reject"
                payload = json.dumps({"device_id": p['device_id'], "action": action}).encode()
                req = urllib.request.Request(f"{base_url}/approve", data=payload, headers={"Content-Type": "application/json"}, method="POST")
                urllib.request.urlopen(req)
                status = f"{GREEN}Approved{RESET}" if action == "approve" else f"{RED}Rejected{RESET}"
                print(f"  {status}: {p['device_name']}")
        except Exception:
            print(f"  {RED}Invalid input.{RESET}")


def guga_rename_device(port: int):
    """Interactive loop to rename/tag connected devices."""
    base_url = f"http://localhost:{port}/api"
    
    def get_devices() -> List[dict]:
        try:
            req = urllib.request.Request(f"{base_url}/devices")
            with urllib.request.urlopen(req, timeout=2) as r:
                return json.load(r).get("devices", [])
        except Exception as e:
            print(f"  {RED}✗{RESET} Error reaching server: {e}")
            return []

    def print_list(devices: List[dict]) -> None:
        print(f"\n  {DIM}{'─' * 52}{RESET}")
        print(f"   {BOLD}Connected devices{RESET}")
        print(f"  {DIM}{'─' * 52}{RESET}")
        for i, d in enumerate(devices):
            name = d['device_name'][:14].ljust(14)
            did  = d['device_id'][:8]
            tag  = d.get('tag') or "-"
            tag_display = f"{CYAN}{tag.ljust(12)}{RESET}"
            print(f"  {i+1})  {BOLD}{name}{RESET}  {DIM}{did}{RESET}   Tag: {tag_display}")
        print(f"  {DIM}{'─' * 52}{RESET}")

    devices = get_devices()
    if not devices:
        print(f"\n  {DIM}No connected devices found.{RESET}\n")
        return

    print_list(devices)
    choice = guga_input(f"  {BOLD}Choose a device (1-{len(devices)}): {RESET}").strip()
    
    try:
        idx = int(choice) - 1
        if 0 <= idx < len(devices):
            device = devices[idx]
            print(f"\n  Renaming {BOLD}{device['device_name']}{RESET} ({DIM}{device['device_id'][:8]}{RESET})")
            new_tag = guga_input(f"  Enter new tag (empty to clear): ").strip()
            
            payload = json.dumps({"device_id": device['device_id'], "tag": new_tag}).encode()
            req = urllib.request.Request(f"{base_url}/rename", data=payload, headers={"Content-Type": "application/json"}, method="POST")
            
            try:
                with urllib.request.urlopen(req) as r:
                    print(f"\n  {GREEN}✓ Device tagged: {BOLD}{new_tag or 'None'}{RESET}")
            except urllib.error.HTTPError as e:
                try:
                    err_data = json.load(e)
                    print(f"\n  {RED}✗ Error: {err_data.get('error', 'Unknown error')}{RESET}")
                except Exception:
                    print(f"\n  {RED}✗ Error: {e.reason}{RESET}")
        else:
            print(f"  {RED}Invalid choice.{RESET}")
    except ValueError:
        print(f"  {RED}Invalid input.{RESET}")

def guga_list_blocked():
    """List all devices currently on the blocklist."""
    blocked = db.get_blocked_devices()
    if not blocked:
        print(f"\n  {DIM}No devices are currently blocked.{RESET}\n")
        return

    print(f"\n  {DIM}{'─' * 52}{RESET}")
    print(f"   {BOLD}Blocked Devices{RESET}")
    print(f"  {DIM}{'─' * 52}{RESET}")
    now = time.time()
    for i, (did, unblock_at) in enumerate(blocked.items()):
        remaining = int(unblock_at - now)
        if remaining <= 0:
            status = f"{GREEN}Expired{RESET}"
        else:
            status = f"{RED}Blocked for {format_duration(remaining)}{RESET}"
        print(f"  {i+1})  {BOLD}{did[:16].ljust(16)}{RESET}  {status}")
    print(f"  {DIM}{'─' * 52}{RESET}\n")

def guga_unblock_device(target_id=None):
    """Remove a device from the blocklist."""
    blocked = db.get_blocked_devices()
    
    # If target_id is the boolean True (from const=True when flag is passed without arg)
    if target_id is True:
        target_id = None

    if not blocked:
        print(f"\n  {DIM}No devices are currently blocked.{RESET}\n")
        return

    if target_id:
        if target_id in blocked:
            db.unblock_device(target_id)
            print(f"\n  {GREEN}✓ Device unblocked: {BOLD}{target_id}{RESET}")
        else:
            # Try partial match
            matches = [did for did in blocked if did.startswith(target_id)]
            if len(matches) == 1:
                db.unblock_device(matches[0])
                print(f"\n  {GREEN}✓ Device unblocked: {BOLD}{matches[0]}{RESET}")
            else:
                print(f"\n  {RED}✗ Device '{target_id}' not found in blocklist.{RESET}")
        return

    # Interactive mode
    guga_list_blocked()
    choice = guga_input(f"  {BOLD}Choose a device to unblock (1-{len(blocked)}): {RESET}").strip()
    try:
        idx = int(choice) - 1
        dids = list(blocked.keys())
        if 0 <= idx < len(dids):
            did = dids[idx]
            db.unblock_device(did)
            print(f"\n  {GREEN}✓ Device unblocked: {BOLD}{did}{RESET}")
        else:
            print(f"  {RED}Invalid choice.{RESET}")
    except ValueError:
        print(f"  {RED}Invalid input.{RESET}")

def guga_revoke_device(target_id=None):
    """Revoke access for a trusted device."""
    trusted = db.get_trusted_devices()
    
    if target_id is True:
        target_id = None

    if not trusted:
        print(f"\n  {DIM}No trusted devices found.{RESET}\n")
        return

    if target_id:
        # Check if target_id matches a device_id, name, or tag
        actual_id = None
        if target_id in trusted:
            actual_id = target_id
        else:
            for did, info in trusted.items():
                if info.get("name") == target_id or info.get("tag") == target_id:
                    actual_id = did
                    break
        
        if actual_id:
            db.delete_trusted_device(actual_id)
            print(f"\n  {GREEN}✓ Access revoked for: {BOLD}{target_id}{RESET}")
        else:
            print(f"\n  {RED}✗ Device '{target_id}' not found.{RESET}")
        return

    # Interactive mode
    print(f"\n  {DIM}{'─' * 52}{RESET}")
    print(f"   {BOLD}Trusted Devices (Revocation Mode){RESET}")
    print(f"  {DIM}{'─' * 52}{RESET}")
    dids = list(trusted.keys())
    for i, did in enumerate(dids):
        info = trusted[did]
        name = info.get("name", "Unknown")[:14].ljust(14)
        tag = info.get("tag") or "-"
        print(f"  {i+1})  {BOLD}{name}{RESET}  {DIM}{did[:8]}{RESET}   Tag: {CYAN}{tag}{RESET}")
    print(f"  {DIM}{'─' * 52}{RESET}")
    
    choice = guga_input(f"  {BOLD}Choose a device to revoke (1-{len(trusted)}): {RESET}").strip()
    try:
        idx = int(choice) - 1
        if 0 <= idx < len(dids):
            did = dids[idx]
            confirm = guga_input(f"  {RED}Are you sure you want to revoke {BOLD}{trusted[did].get('name')}{RESET}? [y/N]: ").strip().lower()
            if confirm == 'y':
                db.delete_trusted_device(did)
                print(f"\n  {GREEN}✓ Access revoked.{RESET}")
            else:
                print("\n  Cancelled.")
        else:
            print(f"  {RED}Invalid choice.{RESET}")
    except ValueError:
        print(f"  {RED}Invalid input.{RESET}")

def run_stop_server(stop_all: bool = False):
    """Interactive manager or non-interactive terminator for background GuGa servers."""
    registry_path = os.path.join(CONFIG_DIR, "active_servers.json")
    if not os.path.exists(registry_path):
        print(f"\n  {DIM}No background servers registered.{RESET}\n")
        return

    try:
        with open(registry_path, "r") as f:
            registry = json.load(f)
    except Exception:
        print(f"  {RED}Error reading server registry.{RESET}")
        return

    # Filter out dead processes
    active = []
    for s in registry:
        pid = s.get("pid")
        if pid:
            try:
                os.kill(pid, 0)
                active.append(s)
            except OSError:
                pass
    
    if not active:
        print(f"\n  {DIM}No active background servers found.{RESET}\n")
        if os.path.exists(registry_path):
            os.remove(registry_path)
        return

    if stop_all:
        print(f"  {CYAN}⚙{RESET} Stopping all {len(active)} background servers...")
        for s in active:
            pid = s.get("pid")
            port = s.get("port")
            try:
                os.kill(pid, 15)
                print(f"  {GREEN}✓ Stopped server on port {port}{RESET}")
            except: pass
        if os.path.exists(registry_path):
            os.remove(registry_path)
        return

    # Print list in --approve style
    print(f"\n  {DIM}{'─' * 60}{RESET}")
    print(f"   {BOLD}Active Background GuGa Servers{RESET}")
    print(f"  {DIM}{'─' * 60}{RESET}")
    for i, s in enumerate(active):
        port = str(s.get("port")).ljust(6)
        mode = s.get("mode", "lan").upper().ljust(8)
        pid = str(s.get("pid")).ljust(6)
        start_time = s.get("start_time", "Unknown")
        print(f"  {i+1})  Port: {BOLD}{port}{RESET} Mode: {CYAN}{mode}{RESET} PID: {DIM}{pid}{RESET} Started: {start_time}")
    print(f"  {DIM}{'─' * 60}{RESET}")

    print(f"  {BOLD}[A] stop all   [1,2,...] choose   [Q] quit{RESET}")
    choice = guga_input(f"\n  Your choice: ").strip().lower()

    if choice == 'q' or not choice:
        return

    to_stop = []
    if choice == 'a':
        to_stop = active
    else:
        try:
            indices = [int(x.strip()) - 1 for x in choice.replace(',', ' ').split() if x.strip().isdigit()]
            to_stop = [active[i] for i in indices if 0 <= i < len(active)]
        except Exception:
            print(f"  {RED}Invalid input.{RESET}")
            return

    for s in to_stop:
        pid = s.get("pid")
        port = s.get("port")
        try:
            print(f"  Stopping server on port {port} (PID {pid})...")
            os.kill(pid, 15) # SIGTERM
            active = [x for x in active if x["pid"] != pid]
            print(f"  {GREEN}✓ Stopped{RESET}")
        except Exception as e:
            print(f"  {RED}✗ Failed to stop PID {pid}: {e}{RESET}")

    # Update registry file
    if active:
        with open(registry_path, "w") as f:
            json.dump(active, f)
    else:
        if os.path.exists(registry_path):
            os.remove(registry_path)

def spawn_background_server(port: int, mode: str):
    """Spawns the GuGa server as a detached background process."""
    log_dir = os.path.join(CONFIG_DIR, "logs")
    os.makedirs(log_dir, exist_ok=True)
    log_file = os.path.join(log_dir, f"server_{port}.log")
    
    # Use the same executable and module
    cmd = [sys.executable, "-m", "guga.cli", "--start-server", "--server", str(port), "--mode", mode]
    
    # Ensure the environment includes the correct PYTHONPATH
    env = os.environ.copy()
    # The 'guga' package is inside the 'server' directory
    # If cli.py is in server/guga/cli.py, then server/ is the package root
    cli_dir = os.path.dirname(os.path.abspath(__file__)) # .../server/guga
    server_root = os.path.dirname(cli_dir) # .../server
    
    if server_root not in env.get("PYTHONPATH", ""):
        env["PYTHONPATH"] = server_root + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")

    print(f"  {CYAN}⚙{RESET} Spawning background server on port {port} ({mode})...")
    
    with open(log_file, "w") as f:
        # Use OS variable from .env to determine process creation flags
        kwargs = {}
        if os.getenv("OS") == "Windows":
            # CREATE_NEW_PROCESS_GROUP (0x00000200)
            kwargs["creationflags"] = 0x00000200
        else:
            kwargs["start_new_session"] = True
            
        try:
            p = subprocess.Popen(cmd, stdout=f, stderr=f, env=env, **kwargs)
        except Exception as e:
            print(f"  {RED}✗ Failed to spawn background process: {e}{RESET}")
            return
    
    # Register it
    registry_path = os.path.join(CONFIG_DIR, "active_servers.json")
    registry = []
    if os.path.exists(registry_path):
        try:
            with open(registry_path, "r") as f:
                registry = json.load(f)
        except: pass
    
    registry.append({
        "pid": p.pid,
        "port": port,
        "mode": mode,
        "start_time": time.strftime("%Y-%m-%d %H:%M:%S")
    })
    
    with open(registry_path, "w") as f:
        json.dump(registry, f)

    # Tail the log until URL is found
    print(f"  {DIM}Waiting for server to initialize...{RESET}")
    found_url = False
    start_wait = time.time()
    while time.time() - start_wait < 30: # 30s timeout
        if os.path.exists(log_file):
            with open(log_file, "r") as f:
                lines = f.readlines()
                for line in reversed(lines):
                    if "[GUGA_URL]" in line:
                        url = line.split("[GUGA_URL]")[1].strip().split("\033")[0].strip()
                        print(f"\n  {GREEN}✓ Server is up!{RESET}")
                        print(f"  {DIM}address →{RESET}  {BOLD}{url}{RESET}")
                        found_url = True
                        break
                    if "TUNNEL URL:" in line or "manual address" in line or "address   http" in line:
                        print(f"\n  {GREEN}✓ Server is up!{RESET}")
                        print(f"  {line.strip()}")
                        found_url = True
                        break
        if found_url: break
        time.sleep(1)
    
    if not found_url:
        print(f"  {YELLOW}⚠{RESET} Server started but URL discovery timed out.")
        print(f"    Check logs: {log_file}")
    
    print(f"  {DIM}Background server running (PID: {p.pid}). Use 'guga --stop-server' to stop it.{RESET}")


# ── Configuration ─────────────────────────────────────────────────────────────

def load_config():
    """Loads default values from ~/.config/guga/config"""
    config = configparser.ConfigParser()
    config_path = os.path.expanduser("~/.config/guga/config")
    
    defaults = {
        "title": None,
        "port": 6769,
        "silent": False
    }
    
    if os.path.exists(config_path):
        try:
            config.read(config_path)
            if "default" in config:
                section = config["default"]
                if "title" in section:
                    defaults["title"] = section["title"]
                if "port" in section:
                    defaults["port"] = int(section["port"])
                if "silent" in section:
                    defaults["silent"] = section.getboolean("silent")
        except Exception:
            pass # Ignore invalid config files
            
    return defaults


# ── Entry point ───────────────────────────────────────────────────────────────

def parse_args():
    defaults = load_config()

    parser = argparse.ArgumentParser(
        prog="guga",
        description="Send notifications to Android, or watch a command and notify on completion.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
mode flags (override auto-detection):
  -m / --message    Force message mode — treat all args as a plain string.
  -r / --run        Force run mode    — treat all args as a command to execute.

auto-detection rules:
  1. stdin piped, no args  →  message mode
  2. single non-executable string  →  message mode
  3. everything else  →  run mode

examples:
  echo "Deploy done" | guga                         # auto: message via stdin
  guga "Build finished"                             # auto: plain message
  guga python train.py --epochs 100                # auto: run mode
  guga calc maintenance.cobol                      # auto: run mode

  guga -m "build done"                             # explicit: message
  guga -m "python train.py"                        # sends the literal string, does not run
  guga -r "sleep 5"                                # explicit: run (splits into tokens)
  guga -r ./deploy.sh --from "Prod Server"         # explicit: run + title alias

  guga -r python train.py --silent -f "GPU"        # run silently, short title alias

configuration:
  ~/.config/guga/config                            # set default title, port, silent

shell completion:
  guga <tab>                                       # autocompletes all flags
  (requires: `activate-global-python-argcomplete --user` or similar initialization)

setup & pairing:
  guga --qr                                        # show pairing QR code
  guga --approve                                   # list and approve pairing requests
  guga --install-service                           # initialise background service
  guga --install-service --reconfigure             # re-run configuration questions
  guga --status                                    # show service status and connections
  guga --url                                       # show raw pairing URL
  guga --version                                   # show current version
  guga --uninstall                                 # remove all GuGa system components

for more details:
  man guga
  tldr guga
        """,
    )

    parser.add_argument(
        "args",
        nargs="*",
        help="Message string, or command + arguments.",
    )

    # Proxy mode flags
    proxy_mode = parser.add_mutually_exclusive_group()
    proxy_mode.add_argument(
        "--qr",
        action="store_true",
        help="Show the pairing QR code and exit.",
    )
    proxy_mode.add_argument(
        "--approve",
        action="store_true",
        help="List and approve pending pairing requests.",
    )
    proxy_mode.add_argument(
        "--rename-device",
        action="store_true",
        help="List connected devices and assign custom tags/names.",
    )
    proxy_mode.add_argument(
        "--install-service",
        action="store_true",
        help="Initializes the Linux background systemd service and components.",
    )
    proxy_mode.add_argument(
        "--blocked",
        action="store_true",
        help="List all devices currently on the blocklist.",
    )
    proxy_mode.add_argument(
        "--unblock",
        nargs="?",
        const=True,
        metavar="DEVICE_ID",
        help="Remove a device from the blocklist (interactive if ID omitted).",
    )
    proxy_mode.add_argument(
        "--revoke",
        nargs="?",
        const=True,
        metavar="DEVICE_ID",
        help="Revoke access for a trusted/paired device (interactive if ID omitted).",
    )
    proxy_mode.add_argument(
        "--uninstall",
        action="store_true",
        help="Safely remove all GuGa system components (service, man pages, config).",
    )
    proxy_mode.add_argument(
        "--install-skills",
        action="store_true",
        help="Installs the GuGa skill to the .agents/skills directory.",
    )
    proxy_mode.add_argument(
        "--status",
        action="store_true",
        help="Show the current service status and connected devices.",
    )
    proxy_mode.add_argument(
        "--url",
        action="store_true",
        help="Output the raw pairing URL (scriptable).",
    )
    proxy_mode.add_argument(
        "--reload-server",
        action="store_true",
        help="Reload (restart) the background GuGa service.",
    )
    proxy_mode.add_argument(
        "--stop-server",
        action="store_true",
        help="Stop one or more background GuGa servers.",
    )
    parser.add_argument(
        "--watch",
        action="store_true",
        help="Stay open and watch for pairing requests (used with --approve).",
    )
    parser.add_argument(
        "--reconfigure",
        action="store_true",
        help="Force re-run of configuration questions during --install-service.",
    )
    proxy_mode.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
        help="Show the current version and exit.",
    )
    proxy_mode.add_argument(
        "--start-server",
        action="store_true",
        help="Start the GuGa server in the foreground.",
    )
    parser.add_argument(
        "-b", "--background",
        action="store_true",
        help="Run the server in the background (detached).",
    )
    parser.add_argument(
        "--choices",
        help="Pre-fill interactive prompts with comma-separated values (e.g. '1,2,,4' where ,, is default).",
    )
    parser.add_argument(
        "--mode",
        choices=["lan", "public"],
        help="Server mode: 'lan' for local network, 'public' for internet (Cloudflare Tunnel).",
    )
    proxy_mode.add_argument(
        "--mcp",
        action="store_true",
        help="Start the GuGa MCP server in stdio mode for local AI tools.",
    )
    proxy_mode.add_argument(
        "--mcp-token",
        action="store_true",
        help="Generate a JWT token for remote MCP access via Cloudflare tunnel.",
    )
    proxy_mode.add_argument(
        "--install-mcp",
        action="store_true",
        help="Install the GuGa stdio MCP server entry into Antigravity's mcp_config.json.",
    )
    proxy_mode.add_argument(
        "--uninstall-mcp",
        action="store_true",
        help="Remove the 'guga' entry from Antigravity's mcp_config.json.",
    )
    parser.add_argument(
        "--mcp-python",
        metavar="PATH",
        default=None,
        help="Python interpreter to use for the MCP server entry (auto-detected if omitted).",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what --install-mcp / --uninstall-mcp would do without writing files.",
    )

    # Explicit mode flags — mutually exclusive
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument(
        "-m", "--message",
        action="store_true",
        help="Force message mode. Joins all positional args as a single string.",
    )
    mode.add_argument(
        "-r", "--run",
        action="store_true",
        help="Force run mode. Executes positional args as a command.",
    )
    mode.add_argument(
        "-i", "--interactive",
        action="store_true",
        help="Enable remote interaction for --run mode (forwards prompts to phone).",
    )
    parser.add_argument(
        "--expect",
        metavar="REGEX",
        help="Custom regex for prompt detection in interactive mode.",
    )
    parser.add_argument(
        "--look-for",
        metavar="REGEX",
        help="Regex pattern to watch for in run mode output; matches are sent as notifications.",
    )

    parser.add_argument(
        "--server",
        type=int,
        default=defaults["port"],
        metavar="PORT",
        help=f"GuGa server port (default: {defaults['port']}).",
    )
    parser.add_argument(
        "--silent",
        action="store_true",
        default=defaults["silent"],
        help="Suppress guga's own output.",
    )
    parser.add_argument(
        "-A", "--all",
        action="store_true",
        help="Apply action to ALL (e.g. approve all clients or stop all servers) without asking.",
    )
    parser.add_argument(
        "-t", "-f", "--from", "--title",
        dest="title",
        default=defaults["title"],
        metavar="LABEL",
        help='Label shown in the notification, e.g. "GPU Server".',
    )
    parser.add_argument(
        "--send-to",
        dest="send_to",
        metavar="DEVICE_ID",
        help="Send the notification to a specific device ID or session ID.",
    )
    parser.add_argument(
        "--ask-user",
        metavar="PROMPT",
        help="Ask user for input and wait for reply.",
    )
    parser.add_argument(
        "--default",
        metavar="VALUE",
        help="Default value to use if --ask-user times out.",
    )
    parser.add_argument(
        "--delay",
        metavar="DURATION",
        default="never",
        help="How long to wait for --ask-user reply (e.g. 120s, 5m, never). Default: never.",
    )

    if argcomplete:
        argcomplete.autocomplete(parser)

    args, unknown = parser.parse_known_args()
    if unknown:
        args.args.extend(unknown)
    return args


def show_help(error: Optional[str] = None) -> None:
    """
    Displays a descriptive help message for the guga CLI.
    
    Args:
        error (str, optional): An optional error message to display before the help text.
    """
    if error:
        print(f"❌ {error}\n", file=sys.stderr)

    print("GuGa Nexus - Notification & Command Watcher\n", file=sys.stderr)
    print("Usage:", file=sys.stderr)
    print('  guga [options] "message"      Send a simple notification', file=sys.stderr)
    print('  guga [options] command args   Run a command and notify when done', file=sys.stderr)
    print('  echo "msg" | guga             Pipe message into guga', file=sys.stderr)
    
    print("\nCommon Options:", file=sys.stderr)
    print('  -m, --message                 Force message mode', file=sys.stderr)
    print('  -r, --run                     Force run mode', file=sys.stderr)
    print('  -i, --interactive             Remote interaction (PTY) for --run mode', file=sys.stderr)
    print('  --expect REGEX                Custom regex for prompt detection', file=sys.stderr)
    print('  --look-for REGEX              Watch for regex in output and notify', file=sys.stderr)
    print('  -t, --title LABEL             Set notification title (e.g. "GPU Server")', file=sys.stderr)
    print('  --send-to DEVICE_ID           Send to a specific device', file=sys.stderr)
    print('  --ask-user PROMPT             Ask user for input and wait for reply', file=sys.stderr)
    print('  --default VALUE               Default value if --ask-user times out', file=sys.stderr)
    print('  --timeout SECONDS             Wait time for --ask-user (default: 60)', file=sys.stderr)
    print('  --silent                      Suppress internal output', file=sys.stderr)

    print("\nAdvanced Mode:", file=sys.stderr)
    print('  guga -r -i python train.py    Automatically forwards stdin prompts to phone', file=sys.stderr)
    
    print("\nSetup & Background:", file=sys.stderr)
    print('  --install-service             Set up GuGa system components', file=sys.stderr)
    print('  --qr                          Show pairing QR code', file=sys.stderr)
    print('  --start-server                Start server in foreground', file=sys.stderr)
    print('  --reload-server               Restart background service', file=sys.stderr)
    
    if os.getenv("OS") == "Windows" or sys.platform == "win32":
        print("\nFor more detail, check 'guga --help'.", file=sys.stderr)
    else:
        print("\nFor more detail, check 'man guga'.", file=sys.stderr)


def main():
    args = parse_args()
    
    # ── Proxy modes ───────────────────────────────────────────────────────────
    if args.install_service or args.qr or args.approve or args.rename_device or args.uninstall or args.status or args.url or args.start_server or args.reload_server or args.install_skills or args.mcp or args.mcp_token or args.stop_server or args.blocked or args.unblock or args.revoke or args.install_mcp or args.uninstall_mcp:
        from guga.installer import run_system_installer, run_system_uninstaller, run_status, run_url, run_reload
        import guga.installer
        
        if args.choices:
            global CHOICES
            CHOICES = [c.strip() for c in args.choices.split(",")]
            guga.installer.PREFILLED_CHOICES = CHOICES
        if args.uninstall:
            run_system_uninstaller()
            return
        if args.status:
            run_status()
            return
        if args.stop_server:
            run_stop_server(stop_all=args.all)
            return
        if args.url:
            run_url()
            return
        if args.reload_server:
            run_reload()
            return
        if args.approve:
            guga_approve(args.server, watch=args.watch, approve_all=args.all)
            return
        if args.rename_device:
            guga_rename_device(args.server)
            return
        if args.blocked:
            guga_list_blocked()
            return
        if args.unblock:
            guga_unblock_device(args.unblock)
            return
        if args.revoke:
            guga_revoke_device(args.revoke)
            return
        if args.start_server:
            if args.background:
                spawn_background_server(args.server, args.mode or "lan")
                return
            try:
                from guga.daemon import run_server
                run_server(mode=args.mode, port=args.server)
            except ImportError:
                # Fallback if run_server isn't defined yet
                import guga.daemon
            return
            
        if args.mcp:
            from guga.mcp_server import GugaMcpServer
            import asyncio
            mcp_server = GugaMcpServer(f"http://localhost:{args.server}")
            print(f"🚀 {BOLD}GuGa MCP Server{RESET} {DIM}started (stdio mode){RESET}", file=sys.stderr)
            try:
                asyncio.run(mcp_server.run_stdio())
            except KeyboardInterrupt:
                pass
            return

        if args.install_mcp:
            from guga.install_mcp import install_mcp as _install_mcp
            _install_mcp(
                config_path=os.path.join(os.path.expanduser("~"), ".gemini", "antigravity", "mcp_config.json"),
                python_exe=args.mcp_python,
                dry_run=args.dry_run,
            )
            return

        if args.uninstall_mcp:
            from guga.install_mcp import uninstall_mcp as _uninstall_mcp
            _uninstall_mcp(
                config_path=os.path.join(os.path.expanduser("~"), ".gemini", "antigravity", "mcp_config.json"),
                dry_run=args.dry_run,
            )
            return
            
        if args.mcp_token:
            url = f"http://localhost:{args.server}/mcp/token"
            try:
                with urllib.request.urlopen(url, timeout=5) as response:
                    data = json.load(response)
                    token = data.get("token")
                    print(f"\n  {BOLD}MCP Access Token:{RESET}")
                    print(f"  {CYAN}{token}{RESET}\n")
                    print(f"  {DIM}Use this in your remote tool's Authorization header as:{RESET}")
                    print(f"  {BOLD}Bearer {token[:10]}...{RESET}\n")
            except urllib.error.URLError as e:
                print(f"❌ Could not reach GuGa server on port {args.server}. Is it running?", file=sys.stderr)
                sys.exit(1)
            except Exception as e:
                print(f"❌ Error: {e}", file=sys.stderr)
                sys.exit(1)
            return

        run_system_installer(qr_only=args.qr, setup_only=args.install_service, install_skills_flag=args.install_skills)
        return

    if args.ask_user:
        target_id = args.send_to if args.send_to else "all"
        try:
            timeout_sec = parse_duration(args.delay) if args.delay else 60
            guga_ask_user(args.ask_user, args.server, target_id, title=args.title, timeout=timeout_sec, default=args.default)
        except ValueError as e:
            print(f"❌ Error: {e}", file=sys.stderr)
            sys.exit(1)
        return

    # Check capabilities for general usage
    check_capabilities(args)

    positional = args.args

    # ── Explicit message mode ─────────────────────────────────────────────────
    if args.message:
        if not positional:
            # Fall back to stdin if no positional args given with --message
            if not sys.stdin.isatty():
                message = sys.stdin.read().strip()
            else:
                print("❌ --message requires a string argument.", file=sys.stderr)
                sys.exit(1)
        else:
            message = " ".join(positional)   # join so --message hello world works too
        
        if args.send_to:
            send_message_to(args.send_to, message, args.server, args.silent, args.title)
        else:
            broadcast_message(message, args.server, args.silent, args.title)
        return

    # ── Explicit run mode ─────────────────────────────────────────────────────
    if args.run:
        if not positional:
            print("❌ --run requires a command to execute.", file=sys.stderr)
            sys.exit(1)
            
        if args.interactive and not args.send_to:
            print("❌ Error: --send-to DEVICE_ID is mandatory when using --interactive.", file=sys.stderr)
            sys.exit(1)

        # If the user passed a single quoted string like "sleep 1" or "python train.py --lr 0.01",
        # split it into proper tokens so subprocess can execute it correctly.
        if len(positional) == 1:
            positional = shlex.split(positional[0])
        run_command(positional, args.server, args.silent, args.title, target_id=args.send_to, interactive=args.interactive, expect_regex=args.expect, look_for=args.look_for)
        return

    # ── Auto-detection ────────────────────────────────────────────────────────

    # 1. Stdin pipe with no positional args
    if not sys.stdin.isatty() and not positional:
        message = sys.stdin.read().strip()
        if not message:
            print("❌ Received empty stdin.", file=sys.stderr)
            sys.exit(1)
        
        if args.send_to:
            send_message_to(args.send_to, message, args.server, args.silent, args.title)
        else:
            broadcast_message(message, args.server, args.silent, args.title)
        return

    # 2. Nothing at all
    if not positional:
        show_help("No message or command provided.")
        sys.exit(1)

    # 3. Single non-executable string → message
    if len(positional) == 1 and not is_runnable(positional[0]):
        if args.send_to:
            send_message_to(args.send_to, positional[0], args.server, args.silent, args.title)
        else:
            broadcast_message(positional[0], args.server, args.silent, args.title)
        return

    # 4. Otherwise → run mode
    run_command(positional, args.server, args.silent, args.title, target_id=args.send_to, interactive=args.interactive, expect_regex=args.expect, look_for=args.look_for)


if __name__ == "__main__":
    main()
