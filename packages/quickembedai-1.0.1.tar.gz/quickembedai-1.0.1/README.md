# QuickEmbed AI Python SDK 🐍

Official Python client for **QuickEmbed AI** ([quickembedai.com](https://quickembedai.com)) - The ultimate RAG Infrastructure for developers.

## 💡 Why use QuickEmbed AI?
Struggling with vector databases or complex chunking? QuickEmbed AI provides a unified API to handle massive data ingestion (PDFs, URLs, CSVs) and high-performance AI retrieval at scale.

**Perfect for:**
- Multi-tenant SaaS products
- Automated document analysis (The Nexus Pipeline)
- Real-time AI chatbots with zero infra management

With Python 3.8+ support and full type hints, it's never been easier to integrate enterprise-grade AI features into your analytics or backend systems.

## 🔗 Official Portal
Visit [quickembedai.com](https://quickembedai.com) to get your API key, manage your tenants, and monitor your AI consumption. Full docs available at [quickembedai.com/help-center](https://quickembedai.com/help-center).

## Installation
```bash
pip install quickembedai
```

## Quick Start
```python
from quickembedai import QuickEmbedAIClient

# Initialize the client (defaults to quickembedai.com API)
client = QuickEmbedAIClient(api_key="your_secret_api_key")

# Perform RAG search
response = client.query("What is our refund policy?", tenant_id="acme-corp")
print(f"Answer: {response['answer']}")
```

## Features
- **Scalable RAG**: Ingest documents of any size into vector-isolated tenants.
- **Advanced Control**: Fine-tune temperature, model selection, and prompt context.
- **Custom Error Handling**: `QuickEmbedAIError` with granular API status codes.
- **Type Hinting**: Clean, robust client for modern Python services.

## API Documentation

### `QuickEmbedAIClient(api_key, base_url=None, timeout=30)`
- `api_key`: Your personal API secret.
- `base_url`: Defaults to `https://quickembedai.com/api/v1`.

### `client.query(message, tenant_id, model=None, temperature=0.7, **kwargs)`
Performs a RAG search and AI generation.

### `client.ingest_url(url, tenant_id)`
Scrapes and indexes a public URL.

### `client.ingest_file(file_path, tenant_id)`
Uploads a local file for vectorization.

### `client.get_insights(tenant_id, **filters)`
Retrieves AI analysis and Nexus metadata.

## License
MIT © QuickEmbed AI Team
