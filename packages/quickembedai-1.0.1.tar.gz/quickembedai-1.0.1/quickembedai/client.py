import os
import requests
from typing import Optional, Dict, Any, List, Union

class QuickEmbedAIError(Exception):
    """Base exception for QuickEmbed AI SDK"""
    def __init__(self, message, status_code=None, response_body=None):
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body

class QuickEmbedAIClient:
    """
    QuickEmbed AI Python SDK for RAG-powered AI Integration.
    """
    def __init__(
        self, 
        api_key: str, 
        base_url: Optional[str] = None,
        timeout: int = 30
    ):
        """
        Initialize the SDK client.
        
        :param api_key: Your secret API key.
        :param base_url: API Base URL (defaults to production).
        :param timeout: Request timeout in seconds.
        """
        if not api_key:
            raise ValueError("QuickEmbed AI API Key is required.")

        self.api_key = api_key
        self.base_url = base_url or os.getenv("QUICKEMBED_API_URL", "https://quickembedai.com/api/v1")
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "User-Agent": "quickembedai-python-sdk/1.0.0"
        })

    def query(
        self, 
        message: str, 
        tenant_id: str, 
        model: Optional[str] = None,
        temperature: float = 0.7,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Query the knowledge base using RAG.
        
        :param message: The user query.
        :param tenant_id: The unique tenant/organization slug.
        :param model: Optional model override (e.g. 'llama-3.1-70b-versatile').
        :param temperature: LLM temperature (0.0 to 1.0).
        """
        payload = {
            "message": message, 
            "tenant_id": tenant_id,
            "temperature": temperature
        }
        if model:
            payload["model"] = model
        
        # Merge extra kwargs into payload
        payload.update(kwargs)

        response = self.session.post(
            f"{self.base_url}/chat",
            json=payload,
            timeout=self.timeout
        )
        return self._handle_response(response)

    def ingest_url(self, url: str, tenant_id: str) -> Dict[str, Any]:
        """
        Ingest and vectorize a URL into the knowledge base.
        """
        response = self.session.post(
            f"{self.base_url}/ingest/url",
            params={"url": url, "tenant_id": tenant_id},
            timeout=self.timeout
        )
        return self._handle_response(response)

    def ingest_file(self, file_path: str, tenant_id: str) -> Dict[str, Any]:
        """
        Upload and vectorize a local file (PDF, CSV, etc.).
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")

        with open(file_path, 'rb') as f:
            files = {'file': f}
            # Use current session headers but let requests handle multipart
            headers = self.session.headers.copy()
            del headers["Content-Type"]
            
            response = self.session.post(
                f"{self.base_url}/ingest",
                headers=headers,
                params={"tenant_id": tenant_id},
                files=files,
                timeout=self.timeout
            )
        return self._handle_response(response)

    def push_data(
        self, 
        content: Union[str, Dict, List], 
        source_name: str = "API Push", 
        metadata: Optional[Dict] = None, 
        tenant_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Directly push raw text or JSON data into the knowledge base.
        
        :param content: String content or JSON-serializable object.
        :param source_name: Descriptive name for the source.
        :param metadata: Optional dictionary of tags for filtering.
        :param tenant_id: The unique tenant/organization slug.
        """
        import json
        if not isinstance(content, str):
            content = json.dumps(content, indent=2)
            
        payload = {
            "content": content,
            "source_name": source_name,
            "metadata": metadata
        }
        
        params = {}
        if tenant_id:
            params["tenant_id"] = tenant_id
            
        response = self.session.post(
            f"{self.base_url}/push",
            json=payload,
            params=params,
            timeout=self.timeout
        )
        return self._handle_response(response)

    def get_insights(self, tenant_id: str, **filters) -> List[Dict[str, Any]]:
        """
        Retrieve AI insights with optional filtering.
        """
        params = {"tenant_id": tenant_id}
        params.update(filters)
        
        response = self.session.get(
            f"{self.base_url}/insights/filter",
            params=params,
            timeout=self.timeout
        )
        return self._handle_response(response)

    def _handle_response(self, response: requests.Response) -> Any:
        try:
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError:
            try:
                error_detail = response.json().get("detail", "API Request Failed")
            except Exception:
                error_detail = response.text
            
            raise QuickEmbedAIError(
                f"QuickEmbed AI Error {response.status_code}: {error_detail}",
                status_code=response.status_code,
                response_body=response.text
            )
        except Exception as e:
            raise QuickEmbedAIError(f"Unexpected Error: {str(e)}")
