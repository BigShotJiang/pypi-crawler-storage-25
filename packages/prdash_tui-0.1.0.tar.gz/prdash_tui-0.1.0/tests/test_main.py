"""Tests for __main__.py entry point."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from prdash.__main__ import main
from prdash.exceptions import AuthError
from prdash.updater import get_version


class TestMain:
    def test_auth_failure_exits(self) -> None:
        with patch(
            "prdash.__main__.get_github_token",
            side_effect=AuthError("no token"),
        ):
            with pytest.raises(SystemExit) as exc_info:
                main()
            assert exc_info.value.code == 1

    def test_wizard_launched_when_no_config(self, tmp_path) -> None:
        mock_wizard = MagicMock()
        mock_wizard.wizard_state.completed = False

        with (
            patch("prdash.__main__.get_github_token", return_value="ghp_test"),
            patch("prdash.__main__.CONFIG_FILE", tmp_path / "nonexistent.toml"),
            patch("prdash.__main__.SetupWizardApp", return_value=mock_wizard),
        ):
            with pytest.raises(SystemExit) as exc_info:
                main()
            assert exc_info.value.code == 0
            mock_wizard.run.assert_called_once()

    def test_wizard_skipped_when_config_exists(self, tmp_path) -> None:
        config_file = tmp_path / "config.toml"
        config_file.write_text(
            'username = "user"\nrepos = ["org/repo"]\n'
        )

        mock_app = MagicMock()

        with (
            patch("prdash.__main__.get_github_token", return_value="ghp_test"),
            patch("prdash.__main__.CONFIG_FILE", config_file),
            patch("prdash.__main__.load_config") as mock_load,
            patch("prdash.__main__.create_http_client"),
            patch("prdash.__main__.GitHubClient"),
            patch("prdash.__main__.ReviewDashboardApp", return_value=mock_app),
        ):
            mock_load.return_value = MagicMock()
            main()
            mock_app.run.assert_called_once()

    def test_wizard_completed_proceeds_to_dashboard(self, tmp_path) -> None:
        config_file = tmp_path / "config.toml"
        # Simulate wizard creating the file
        config_file.write_text(
            'username = "user"\nrepos = ["org/repo"]\n'
        )

        mock_wizard = MagicMock()
        mock_wizard.wizard_state.completed = True

        mock_app = MagicMock()

        with (
            patch("prdash.__main__.get_github_token", return_value="ghp_test"),
            patch("prdash.__main__.CONFIG_FILE", config_file),
            patch("prdash.__main__.load_config") as mock_load,
            patch("prdash.__main__.create_http_client"),
            patch("prdash.__main__.GitHubClient"),
            patch("prdash.__main__.ReviewDashboardApp", return_value=mock_app),
        ):
            mock_load.return_value = MagicMock()
            main()
            mock_app.run.assert_called_once()


class TestVersionFlag:
    def test_version_prints_and_exits(
        self, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
    ) -> None:
        monkeypatch.setattr("sys.argv", ["prdash", "--version"])
        with pytest.raises(SystemExit) as exc_info:
            main()
        assert exc_info.value.code == 0
        captured = capsys.readouterr()
        assert get_version() in captured.out

    def test_version_short_alias(
        self, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
    ) -> None:
        monkeypatch.setattr("sys.argv", ["prdash", "-V"])
        with pytest.raises(SystemExit) as exc_info:
            main()
        assert exc_info.value.code == 0
        captured = capsys.readouterr()
        assert get_version() in captured.out

    def test_version_requires_no_auth(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setattr("sys.argv", ["prdash", "--version"])
        with (
            patch(
                "prdash.__main__.get_github_token",
                side_effect=AssertionError("auth should not be called"),
            ),
            pytest.raises(SystemExit) as exc_info,
        ):
            main()
        assert exc_info.value.code == 0


class TestUpdateFlag:
    def test_update_delegates_to_run_upgrade(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr("sys.argv", ["prdash", "--update"])
        with patch("prdash.__main__.run_upgrade") as mock_upgrade:
            main()
        mock_upgrade.assert_called_once()

    def test_update_requires_no_auth(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setattr("sys.argv", ["prdash", "--update"])
        with (
            patch(
                "prdash.__main__.get_github_token",
                side_effect=AssertionError("auth should not be called"),
            ),
            patch("prdash.__main__.run_upgrade"),
        ):
            main()
