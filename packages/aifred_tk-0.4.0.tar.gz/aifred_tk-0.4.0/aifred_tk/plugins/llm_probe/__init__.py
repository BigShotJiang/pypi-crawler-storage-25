"""LLM probe plugin package."""
