"""LLM probe plugin providing the ``probe_llm`` tool.

The tool accepts a system prompt, a user prompt, and optional model parameters,
forwards them directly to the configured LLM, and returns the raw text response.
Intended for prompt engineering and parameter tuning workflows where the caller
wants to assess model behaviour before embedding prompts in higher-level tools.
"""

from __future__ import annotations

from typing import Any, cast

from dynaconf import Dynaconf
from loguru import logger
from pydantic import Field, TypeAdapter
from pydantic_ai import Agent
from pydantic_ai.settings import ModelSettings

from aifred_tk.core.interfaces import Plugin, Tool, ToolArgs
from aifred_tk.core.llm import LlmConfig, PluginLlmSetting, build_pydantic_ai_model, resolve_llm
from aifred_tk.core.models import ConfigurationError

_TOOL_ID = "probe_llm"


class LlmProbeArgs(ToolArgs):
    """Arguments accepted by :class:`LlmProbeTool`.

    :param system_prompt: System prompt to send to the LLM.
    :param user_prompt: User prompt to send to the LLM.
    :param temperature: Sampling temperature in the range [0.0, 2.0].
        Uses the provider default when omitted.
    :param max_tokens: Maximum number of tokens in the response.
        Uses the provider default when omitted.
    """

    system_prompt: str = Field(description="System prompt to send to the LLM.")
    user_prompt: str = Field(description="User prompt to send to the LLM.")
    temperature: float | None = Field(
        None,
        ge=0.0,
        le=2.0,
        description="Sampling temperature (0.0–2.0). Uses provider default when omitted.",
    )
    max_tokens: int | None = Field(
        None,
        ge=1,
        description="Maximum tokens in the response. Uses provider default when omitted.",
    )


class LlmProbeTool(Tool):
    """Forwards prompts directly to the configured LLM and returns the raw response.

    A new :class:`~pydantic_ai.Agent` is constructed on every :meth:`execute` call
    because the system prompt is supplied by the caller at runtime.
    """

    def __init__(self, llm_config: LlmConfig) -> None:
        """Initialise with a resolved LLM config.

        :param llm_config: Resolved LLM configuration used to build the pydantic-ai model.
        :type llm_config: LlmConfig
        """
        self._llm_config = llm_config

    @property
    def tool_id(self) -> str:
        """Return the unique tool identifier.

        :return: ``"probe_llm"``
        :rtype: str
        """
        return _TOOL_ID

    @property
    def name(self) -> str:
        """Return the human-readable tool name.

        :return: Display name string.
        :rtype: str
        """
        return "LLM Probe"

    @property
    def description(self) -> str:
        """Return the tool description shown in CLI help and MCP metadata.

        :return: Description string.
        :rtype: str
        """
        return (
            "Sends a system prompt and a user prompt directly to the configured LLM and "
            "returns the raw text response. Optionally accepts temperature and max_tokens "
            "to control generation. Useful for testing prompts and evaluating model "
            "behaviour with specific parameters."
        )

    @property
    def args_schema(self) -> type[LlmProbeArgs]:
        """Return the Pydantic model class for argument validation.

        :return: :class:`LlmProbeArgs` class.
        :rtype: type[LlmProbeArgs]
        """
        return LlmProbeArgs

    def execute(self, args: ToolArgs) -> dict[str, Any]:
        """Forward the prompts to the LLM and return the raw response.

        Constructs a fresh pydantic-ai :class:`~pydantic_ai.Agent` with the provided
        system prompt on each call. Model settings are applied only when at least one
        optional parameter is supplied.

        :param args: Validated :class:`LlmProbeArgs` instance.
        :type args: ToolArgs
        :return: On success: ``{"response": <str>}``.
            On error: ``{"status": "error", "message": <str>}``.
        :rtype: dict[str, Any]
        """
        probe_args = cast(LlmProbeArgs, args)

        model = build_pydantic_ai_model(self._llm_config)
        agent: Agent[None, str] = Agent(model, system_prompt=probe_args.system_prompt)

        raw: dict[str, Any] = {
            k: v
            for k, v in {
                "temperature": probe_args.temperature,
                "max_tokens": probe_args.max_tokens,
            }.items()
            if v is not None
        }
        model_settings: ModelSettings | None = cast(ModelSettings, raw) if raw else None

        logger.debug("Invoking LLM probe agent")
        try:
            run_result = agent.run_sync(probe_args.user_prompt, model_settings=model_settings)
        except Exception as exc:
            logger.error("Agent error during LLM probe: {}", exc)
            return {"status": "error", "message": f"Agent error: {exc}"}

        response: str = run_result.output
        logger.info("LLM probe complete")
        return {"response": response}


class LlmProbePlugin(Plugin):
    """Plugin that provides the :class:`LlmProbeTool`."""

    def __init__(self, llm_config: LlmConfig) -> None:
        """Initialise with a resolved LLM config.

        :param llm_config: Resolved LLM configuration forwarded to the tool.
        :type llm_config: LlmConfig
        """
        self._llm_config = llm_config

    @property
    def plugin_id(self) -> str:
        """Return the unique plugin identifier.

        :return: ``"llm_probe"``
        :rtype: str
        """
        return "llm_probe"

    @property
    def name(self) -> str:
        """Return the human-readable plugin name.

        :return: Display name string.
        :rtype: str
        """
        return "LLM Probe"

    def get_tools(self) -> list[Tool]:
        """Return all tools provided by this plugin.

        :return: List containing :class:`LlmProbeTool`.
        :rtype: list[Tool]
        """
        return [LlmProbeTool(self._llm_config)]


def create_plugin(settings: Dynaconf) -> LlmProbePlugin:
    """Entry point factory for the llm_probe plugin.

    Reads the ``llms`` registry and the ``tools.probe_llm.llm`` setting from
    *settings*, resolves the LLM configuration, and constructs the plugin.

    :param settings: Active Dynaconf settings instance.
    :type settings: Dynaconf
    :return: Initialised :class:`LlmProbePlugin` instance.
    :rtype: LlmProbePlugin
    :raises ConfigurationError: When the LLM setting is missing or references an unknown name.
    """
    llms_data: dict[str, Any] = dict(settings.get("LLMS", {}) or {})
    llms_registry: dict[str, LlmConfig] = (
        TypeAdapter(dict[str, LlmConfig]).validate_python(llms_data) if llms_data else {}
    )

    llm_raw = settings.get(f"TOOLS__{_TOOL_ID.upper()}__LLM")
    if not llm_raw:
        raise ConfigurationError(
            f"Missing tools.{_TOOL_ID}.llm configuration; "
            "define an LLM reference or inline definition."
        )

    llm_setting: PluginLlmSetting = TypeAdapter(PluginLlmSetting).validate_python(dict(llm_raw))
    llm_config = resolve_llm(llm_setting, llms_registry)

    logger.debug(
        "llm_probe plugin using {} model {!r}",
        llm_config.provider,
        llm_config.model,
    )
    return LlmProbePlugin(llm_config)
