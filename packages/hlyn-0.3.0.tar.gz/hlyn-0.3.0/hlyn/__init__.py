"""
Hlyn Defender SDK — prompt injection detection.

Usage:
    from hlyn import defender
    d = defender(api_key="sk_xxx", base_url="https://...")
    result = d.classify("some user prompt")
"""

from ._client import Defender

# Lowercase alias — the public-facing name customers use
defender = Defender
from ._exceptions import (
    AuthenticationError,
    BadRequestError,
    HlynError,
    NetworkError,
    RateLimitError,
    RequestTimeoutError,
    ServerError,
)
from ._version import __version__
from .types import ClassifyResult

__all__ = [
    # Client
    "defender",
    "Defender",
    # Types
    "ClassifyResult",
    # Exceptions
    "HlynError",
    "AuthenticationError",
    "RateLimitError",
    "BadRequestError",
    "ServerError",
    "NetworkError",
    "RequestTimeoutError",
    # Version
    "__version__",
]
