"""
Public response types returned by the SDK.
Dataclasses — lightweight, typed, IDE-friendly.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class ClassifyResult:
    """Result from a prompt injection classification."""

    score: float
    """Injection probability — 0.0 (safe) to 1.0 (injection)."""

    label: str
    """Classification label: "SAFE" or "INJECTION"."""

    @property
    def is_safe(self) -> bool:
        """True if the text is not prompt injection."""
        return self.label == "SAFE"

    @property
    def is_injection(self) -> bool:
        """True if the text is prompt injection."""
        return self.label == "INJECTION"
