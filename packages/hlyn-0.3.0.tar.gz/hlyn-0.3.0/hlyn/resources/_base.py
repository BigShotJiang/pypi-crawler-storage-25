"""
Base resource — shared logic inherited by all resource classes.
New resources subclass this and get HTTP transport for free.
"""

from .._transport import HTTPTransport


class BaseResource:
    """Every resource gets the shared transport. No other magic."""

    def __init__(self, transport: HTTPTransport):
        self._transport = transport
