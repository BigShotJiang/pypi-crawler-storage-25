"""
Classify resource — prompt injection detection.

To add a new resource later, copy this file and follow the same pattern:
1. Subclass BaseResource
2. Make it callable via __call__ for the primary operation
3. Add methods for secondary operations (batch, etc.)
"""

from __future__ import annotations

from ._base import BaseResource
from ..types import ClassifyResult


class ClassifyResource(BaseResource):
    """Detect prompt injection in text.

    Callable directly for single classification:
        result = client.classify("some text")

    Or use named methods:
        result = client.classify.detect("some text")
        results = client.classify.batch(["text1", "text2"])
    """

    def __call__(self, text: str) -> ClassifyResult:
        """Shortcut — equivalent to .detect(text)."""
        return self.detect(text)

    def detect(self, text: str) -> ClassifyResult:
        """Classify a single text for prompt injection.

        Args:
            text: The user prompt or message to check.

        Returns:
            ClassifyResult with score, label, threshold, is_safe, is_injection.
        """
        data = self._transport.request("POST", "/v1/classify", json={"text": text})
        return ClassifyResult(
            score=data["score"],
            label=data["label"],
        )

    def batch(self, texts: list[str]) -> list[ClassifyResult]:
        """Classify multiple texts. Calls detect() for each.

        Args:
            texts: List of prompts to check.

        Returns:
            List of ClassifyResult in the same order as input.
        """
        # Sequential for now — server batch endpoint can be added later
        # without changing the SDK interface
        return [self.detect(text) for text in texts]
