"""
HTTP transport layer — handles retries, backoff, timeouts, and error mapping.
All HTTP logic is centralized here so resources never touch requests directly.
"""

import time
from typing import Any

import requests
import requests.adapters

from ._exceptions import (
    AuthenticationError,
    BadRequestError,
    HlynError,
    NetworkError,
    RateLimitError,
    RequestTimeoutError,
    ServerError,
)
from ._version import __version__

# Status codes that trigger automatic retry
_RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}

# Default retry config
_DEFAULT_MAX_RETRIES = 2
_DEFAULT_BACKOFF_BASE = 0.5  # seconds — doubles each retry: 0.5, 1.0, 2.0
_DEFAULT_CONNECT_TIMEOUT = 5.0  # seconds
_DEFAULT_READ_TIMEOUT = 30.0  # seconds


class HTTPTransport:
    """Manages a requests.Session with retry logic, auth, and error handling."""

    def __init__(
        self,
        base_url: str,
        api_key: str,
        max_retries: int = _DEFAULT_MAX_RETRIES,
        timeout: tuple[float, float] = (_DEFAULT_CONNECT_TIMEOUT, _DEFAULT_READ_TIMEOUT),
    ):
        self.base_url = base_url.rstrip("/")
        self.max_retries = max_retries
        self.timeout = timeout

        self._session = requests.Session()
        self._session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": f"hlyn-python/{__version__}",
        })

    def request(self, method: str, path: str, json: dict | None = None) -> dict:
        """Make an HTTP request with automatic retry on transient errors."""
        url = f"{self.base_url}{path}"
        last_exception = None

        for attempt in range(1 + self.max_retries):
            try:
                resp = self._session.request(
                    method=method,
                    url=url,
                    json=json,
                    timeout=self.timeout,
                )

                # Success — return parsed JSON (guard against empty body)
                if resp.ok:
                    if not resp.content:
                        return {}
                    return resp.json()

                # Map HTTP errors to SDK exceptions
                error = self._map_error(resp)

                # Retry on transient errors only
                if resp.status_code in _RETRYABLE_STATUS_CODES and attempt < self.max_retries:
                    wait = self._backoff_wait(attempt, error)
                    time.sleep(wait)
                    last_exception = error
                    continue

                raise error

            except requests.exceptions.Timeout as e:
                last_exception = RequestTimeoutError(f"Request timed out after {self.timeout}s")
                if attempt < self.max_retries:
                    time.sleep(self._backoff_wait(attempt))
                    continue
                raise last_exception from e

            except requests.exceptions.ConnectionError as e:
                last_exception = NetworkError(f"Connection failed: {e}")
                if attempt < self.max_retries:
                    time.sleep(self._backoff_wait(attempt))
                    continue
                raise last_exception from e

        # Should not reach here, but fail-safe
        raise last_exception or HlynError("Request failed after all retries")

    def _backoff_wait(self, attempt: int, error: HlynError | None = None) -> float:
        """Exponential backoff. Respects Retry-After header for rate limits."""
        if isinstance(error, RateLimitError) and error.retry_after:
            return error.retry_after
        return _DEFAULT_BACKOFF_BASE * (2 ** attempt)

    def _map_error(self, resp: requests.Response) -> HlynError:
        """Convert an HTTP error response to the appropriate SDK exception."""
        request_id = resp.headers.get("x-request-id")
        try:
            body = resp.json()
            message = body.get("detail", body.get("error", resp.text))
        except Exception:
            message = resp.text or f"HTTP {resp.status_code}"

        kwargs: dict[str, Any] = {"status_code": resp.status_code, "request_id": request_id}

        if resp.status_code == 401:
            return AuthenticationError(message, **kwargs)
        if resp.status_code == 429:
            retry_after = resp.headers.get("Retry-After")
            return RateLimitError(
                message,
                retry_after=float(retry_after) if retry_after else None,
                **kwargs,
            )
        if resp.status_code == 400:
            return BadRequestError(message, **kwargs)
        if resp.status_code >= 500:
            return ServerError(message, **kwargs)

        return HlynError(message, **kwargs)

    def close(self):
        """Close the underlying HTTP session."""
        self._session.close()
