"""
Exception hierarchy for the Hlyn SDK.
Follows industry standard (Stripe, OpenAI, Anthropic) pattern:
catch HlynError for all SDK errors, or catch specific subclasses.
"""


class HlynError(Exception):
    """Base exception for all Hlyn SDK errors."""

    def __init__(self, message: str, status_code: int | None = None, request_id: str | None = None):
        self.message = message
        self.status_code = status_code
        self.request_id = request_id
        super().__init__(self.message)

    def __str__(self):
        parts = [self.message]
        if self.status_code is not None:
            parts.append(f"(HTTP {self.status_code})")
        if self.request_id:
            parts.append(f"[request_id={self.request_id}]")
        return " ".join(parts)


class AuthenticationError(HlynError):
    """API key is missing, invalid, or revoked. HTTP 401."""
    pass


class RateLimitError(HlynError):
    """Too many requests. Retry after backoff. HTTP 429."""

    def __init__(self, message: str, retry_after: float | None = None, **kwargs):
        super().__init__(message, **kwargs)
        # Seconds to wait before retrying (from Retry-After header if present)
        self.retry_after = retry_after


class BadRequestError(HlynError):
    """Malformed request — missing fields, text too long, etc. HTTP 400."""
    pass


class ServerError(HlynError):
    """Something went wrong on the server side. HTTP 5xx."""
    pass


class NetworkError(HlynError):
    """Network-level failure — DNS, TCP, TLS. Not an HTTP error."""
    pass


class RequestTimeoutError(HlynError):
    """Request exceeded the configured timeout."""
    pass
