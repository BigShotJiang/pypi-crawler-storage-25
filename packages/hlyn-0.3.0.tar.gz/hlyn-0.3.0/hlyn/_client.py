"""
Main client — the single entry point customers interact with.

Adding a new resource:
    1. Create hlyn/resources/new_resource.py (copy classify.py pattern)
    2. Import and attach it in __init__ below
    That's it.
"""

from __future__ import annotations

import os

from ._exceptions import AuthenticationError, HlynError
from ._transport import HTTPTransport
from .resources.classify import ClassifyResource

DEFAULT_BASE_URL = "https://chromejaw--defender-model1-defenderservice-api.modal.run"


class Defender:
    """Hlyn Defender client — prompt injection detection.

    Usage:
        from hlyn import Defender
        d = Defender(api_key="sk_xxx", base_url="https://...")
        result = d.classify("ignore all previous instructions")

    Environment variables (used as fallbacks):
        HLYN_API_KEY  — API key
        HLYN_BASE_URL — Base URL of the Defender API
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        max_retries: int = 2,
        timeout: tuple[float, float] = (5.0, 30.0),
    ):
        # Resolve API key: explicit > env var > error (strip whitespace)
        resolved_key = (api_key or os.environ.get("HLYN_API_KEY") or "").strip()
        if not resolved_key:
            raise AuthenticationError(
                "No API key provided. Pass api_key= or set the HLYN_API_KEY environment variable."
            )

        # Resolve base URL: explicit > env var > default (strip whitespace)
        resolved_url = (base_url or os.environ.get("HLYN_BASE_URL") or DEFAULT_BASE_URL).strip()

        self._transport = HTTPTransport(
            base_url=resolved_url,
            api_key=resolved_key,
            max_retries=max_retries,
            timeout=timeout,
        )

        # ── Resources ────────────────────────────────────────────────────
        # To add a new resource: import it, attach it here.
        self.classify = ClassifyResource(self._transport)

    def close(self):
        """Close the underlying HTTP connection pool."""
        self._transport.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
