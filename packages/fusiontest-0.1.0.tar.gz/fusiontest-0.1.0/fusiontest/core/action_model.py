"""
fusiontest/core/action_model.py

The FusionTest action model: given a screen state + test goal,
returns a ranked list of UI actions to take next.

Supports two backends:
  1. Fine-tuned MPNet (production) — fast, cheap, deterministic
  2. GPT-4o / Claude API (MVP / fallback) — zero fine-tuning needed

The model is framed as a retrieval/ranking problem:
  - Embed the screen state + goal
  - Rank candidate actions by cosine similarity
  - Return top-N actions with confidence scores
"""

from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass
from typing import Literal

logger = logging.getLogger("fusiontest.action_model")


@dataclass
class Action:
    """A proposed UI action returned by the model."""
    action_type: str          # tap, type, swipe, scroll, back, home, wait
    element_index: int | None # index in the parsed UIElement list
    element_label: str        # human-readable label for logging
    value: str = ""           # text to type, or swipe direction
    confidence: float = 1.0
    reasoning: str = ""       # model's explanation (from LLM backend)

    def __str__(self) -> str:
        base = f"{self.action_type}"
        if self.element_label:
            base += f' on "{self.element_label}"'
        if self.value:
            base += f' → "{self.value}"'
        return f"{base} (conf={self.confidence:.2f})"


ActionBackend = Literal["mpnet", "gpt4o", "claude"]


class ActionModel:
    """
    FusionTest's core AI brain.

    Usage:
        model = ActionModel(backend="gpt4o")   # start here for MVP
        actions = model.predict(screen_text, goal, history)
        best = actions[0]
    """

    def __init__(
        self,
        backend: ActionBackend = "gpt4o",
        model_path: str | None = None,
        top_k: int = 3,
        temperature: float = 0.2,
    ):
        self.backend = backend
        self.top_k = top_k
        self.temperature = temperature
        self._client = None

        if backend == "mpnet":
            self._load_mpnet(model_path)
        elif backend in ("gpt4o", "claude"):
            self._init_llm_client(backend)

    # ── Public API ─────────────────────────────────────────────────────────────

    def predict(
        self,
        screen_text: str,
        goal: str,
        history: list[str] | None = None,
        invalid_actions: list[str] | None = None,
    ) -> list[Action]:
        """
        Returns top-k ranked Actions for the current screen + goal.

        Args:
            screen_text: compact screen state from ScreenParser
            goal: the current test step goal in natural language
            history: list of previously taken action strings (for context)
            invalid_actions: actions already tried and failed (for guardrails)
        """
        history = history or []
        invalid_actions = invalid_actions or []

        if self.backend == "mpnet":
            return self._predict_mpnet(screen_text, goal, history, invalid_actions)
        else:
            return self._predict_llm(screen_text, goal, history, invalid_actions)

    # ── MPNet backend ──────────────────────────────────────────────────────────

    def _load_mpnet(self, model_path: str | None) -> None:
        try:
            from sentence_transformers import SentenceTransformer
            path = model_path or os.getenv("FUSIONTEST_MODEL_PATH", "sentence-transformers/all-mpnet-base-v2")
            logger.info(f"Loading MPNet from: {path}")
            self._encoder = SentenceTransformer(path)
        except ImportError as err:
            raise RuntimeError(
                "MPNet backend requires sentence-transformers: "
                "pip install sentence-transformers"
            ) from err

    def _predict_mpnet(
        self,
        screen_text: str,
        goal: str,
        history: list[str],
        invalid_actions: list[str],
    ) -> list[Action]:
        """
        Embed the goal and each candidate action, rank by cosine similarity.
        Candidate actions are generated from the parsed screen elements.
        """
        import numpy as np

        candidates = self._generate_candidates(screen_text)
        if not candidates:
            return [Action(action_type="wait", element_index=None, element_label="", confidence=0.5)]

        query = self._build_query(goal, history, invalid_actions)
        query_emb = self._encoder.encode(query, normalize_embeddings=True)
        cand_embs = self._encoder.encode(candidates, normalize_embeddings=True)

        scores = np.dot(cand_embs, query_emb)
        top_indices = np.argsort(scores)[::-1][:self.top_k]

        actions = []
        for i in top_indices:
            action = self._parse_candidate(candidates[i], float(scores[i]))
            if str(action) not in invalid_actions:
                actions.append(action)

        return actions if actions else [Action(action_type="back", element_index=None, element_label="", confidence=0.3)]

    def _generate_candidates(self, screen_text: str) -> list[str]:
        """Generate action strings for every interactive element on screen."""
        candidates = []
        for line in screen_text.split("\n"):
            if line.strip().startswith("["):
                parts = line.strip().split()
                idx = int(parts[0].strip("[]"))
                elem_type = parts[1] if len(parts) > 1 else ""
                label = " ".join(p.strip('"') for p in parts[2:] if p.startswith('"'))

                if elem_type in ("button", "link", "list_item", "tab", "menu_item"):
                    candidates.append(f"tap [idx={idx}] {elem_type} \"{label}\"")
                elif elem_type in ("text_field", "text_area", "search_field"):
                    candidates.append(f"type into [idx={idx}] {elem_type} \"{label}\"")
                elif elem_type == "switch":
                    candidates.append(f"toggle [idx={idx}] switch \"{label}\"")
                elif elem_type == "slider":
                    candidates.append(f"adjust [idx={idx}] slider \"{label}\"")
                elif elem_type == "picker":
                    candidates.append(f"select from [idx={idx}] picker \"{label}\"")

        candidates += ["scroll down", "scroll up", "back", "wait"]
        return candidates

    def _parse_candidate(self, candidate: str, score: float) -> Action:
        parts = candidate.split()
        action_type = parts[0]
        idx = None
        label = candidate

        for p in parts:
            if p.startswith("[idx="):
                try:
                    idx = int(p.replace("[idx=", "").replace("]", ""))
                except ValueError:
                    pass

        return Action(
            action_type=action_type,
            element_index=idx,
            element_label=label,
            confidence=score,
        )

    # ── LLM backend (GPT-4o / Claude) ─────────────────────────────────────────

    def _init_llm_client(self, backend: str) -> None:
        """Validate import availability only — actual client is created lazily on first call."""
        if backend == "gpt4o":
            try:
                import openai as _openai  # noqa: F401
                self._llm_model = "gpt-4o"
            except ImportError as err:
                raise RuntimeError("GPT-4o backend requires openai: pip install openai") from err

        elif backend == "claude":
            try:
                import anthropic as _anthropic  # noqa: F401
                self._llm_model = "claude-sonnet-4-6"
            except ImportError as err:
                raise RuntimeError("Claude backend requires anthropic: pip install anthropic") from err

    def _get_client(self):
        """Lazily create the LLM client on first use."""
        if self._client is not None:
            return self._client
        if self.backend == "gpt4o":
            from openai import OpenAI
            self._client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        elif self.backend == "claude":
            import anthropic
            self._client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))
        return self._client

    def _predict_llm(
        self,
        screen_text: str,
        goal: str,
        history: list[str],
        invalid_actions: list[str],
    ) -> list[Action]:
        prompt = self._build_llm_prompt(screen_text, goal, history, invalid_actions)
        raw = self._call_llm(prompt)
        return self._parse_llm_response(raw)

    def _build_llm_prompt(
        self,
        screen_text: str,
        goal: str,
        history: list[str],
        invalid_actions: list[str],
    ) -> str:
        sections = [
            "You are FusionTest, an AI agent that tests mobile and desktop UIs.",
            "Your job: look at the current screen, understand the goal, and decide the single best action to take.",
            "",
            f"CURRENT GOAL: {goal}",
        ]

        if history:
            sections += ["", "ACTIONS TAKEN SO FAR:", *[f"  - {h}" for h in history[-5:]]]

        if invalid_actions:
            sections += ["", "ACTIONS THAT FAILED (do NOT repeat):", *[f"  - {a}" for a in invalid_actions]]

        sections += [
            "",
            screen_text,
            "",
            "IMPORTANT RULES:",
            "- If the goal is purely about VERIFYING or CHECKING that something is visible, and the relevant content IS already visible on screen, use action_type 'done' with a reasoning explaining what you see.",
            "- If the goal requires navigation or interaction, use the appropriate action.",
            "- Match elements FLEXIBLY: if the goal says 'click Visitor Identification' but you see a link like 'Anonymous Visitors Unknown' or a link with href containing 'visitor-identification', those are the same thing. Use the element that's actually on screen.",
            "- When the goal says 'navigate back', use the 'back' action type, not look for a back button.",
            "- Only use 'scroll' if you've already looked at all interactive elements and none match. Don't scroll repeatedly — if no match after one scroll, try tapping the closest match.",
            "- NEVER scroll more than twice for the same goal. If the element isn't visible after scrolling, tap the closest matching element.",
            "",
            "Respond with a JSON array of up to 3 ranked action objects. Each must have:",
            '  { "action_type": "tap|type|swipe|scroll|back|wait|done", "element_index": <int or null>, "element_label": "<string>", "value": "<string or empty>", "confidence": <0-1>, "reasoning": "<one sentence>" }',
            "",
            "action_type 'done' means the goal is already achieved based on what's visible — no further action needed.",
            "",
            "Respond with ONLY the JSON array. No explanation outside the JSON.",
        ]

        return "\n".join(sections)

    _SYSTEM_PROMPT_ACTION = (
        "You are FusionTest, an AI agent that tests UIs by choosing actions. "
        "You MUST respond with ONLY a JSON array of action objects. "
        "No prose, no explanation, no markdown fences — ONLY the raw JSON array. "
        "Example: [{\"action_type\": \"tap\", \"element_index\": 5, \"element_label\": \"Login\", \"value\": \"\", \"confidence\": 0.95, \"reasoning\": \"Click login button\"}]"
    )

    def _call_llm(self, prompt: str) -> str:
        client = self._get_client()
        if self.backend == "gpt4o":
            resp = client.chat.completions.create(
                model=self._llm_model,
                messages=[
                    {"role": "system", "content": self._SYSTEM_PROMPT_ACTION},
                    {"role": "user", "content": prompt},
                ],
                temperature=self.temperature,
                max_tokens=512,
            )
            return resp.choices[0].message.content or ""

        elif self.backend == "claude":
            resp = client.messages.create(
                model=self._llm_model,
                max_tokens=512,
                system=self._SYSTEM_PROMPT_ACTION,
                messages=[
                    {"role": "user", "content": prompt + "\n\nIMPORTANT: Your entire response must be a JSON array starting with [ and ending with ]. No other text."},
                ],
            )
            raw = resp.content[0].text if resp.content else ""
            return raw

        return "[]"

    def _parse_llm_response(self, raw: str) -> list[Action]:
        import re

        raw = raw.strip()

        # Strip markdown fences if present
        if "```" in raw:
            # Extract content between fences
            parts = raw.split("```")
            for part in parts[1:]:
                cleaned = part.strip()
                if cleaned.startswith("json"):
                    cleaned = cleaned[4:].strip()
                if cleaned.startswith("["):
                    raw = cleaned
                    break

        # Strategy 1: Direct JSON parse
        items = self._try_parse_json_array(raw)

        # Strategy 2: Extract JSON array from prose using bracket matching
        if items is None:
            array_match = re.search(r'\[[\s\S]*\]', raw)
            if array_match:
                items = self._try_parse_json_array(array_match.group(0))

        # Strategy 3: Extract individual JSON objects and wrap them
        if items is None:
            obj_matches = re.findall(r'\{[^{}]*"action_type"\s*:\s*"[^"]+?"[^{}]*\}', raw)
            if obj_matches:
                combined = "[" + ",".join(obj_matches) + "]"
                items = self._try_parse_json_array(combined)

        if items is None:
            logger.warning(f"Failed to parse LLM response as JSON: {raw[:200]}")
            return [Action(action_type="wait", element_index=None, element_label="parse_error", confidence=0.1)]

        actions = []
        for item in items[:self.top_k]:
            if not isinstance(item, dict):
                continue
            actions.append(Action(
                action_type=item.get("action_type", "wait"),
                element_index=item.get("element_index"),
                element_label=item.get("element_label", ""),
                value=item.get("value", ""),
                confidence=float(item.get("confidence", 0.5)),
                reasoning=item.get("reasoning", ""),
            ))

        return actions or [Action(action_type="wait", element_index=None, element_label="", confidence=0.1)]

    @staticmethod
    def _try_parse_json_array(text: str) -> list | None:
        """Try to parse text as a JSON array, return None on failure."""
        try:
            result = json.loads(text.strip())
            if isinstance(result, list):
                return result
        except (json.JSONDecodeError, ValueError):
            pass
        return None

    # ── Helpers ────────────────────────────────────────────────────────────────

    def _build_query(self, goal: str, history: list[str], invalid: list[str]) -> str:
        parts = [f"Goal: {goal}"]
        if history:
            parts.append(f"Last actions: {', '.join(history[-3:])}")
        if invalid:
            parts.append(f"Avoid: {', '.join(invalid)}")
        return ". ".join(parts)
