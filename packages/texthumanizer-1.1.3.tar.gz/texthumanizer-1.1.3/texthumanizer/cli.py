#!/usr/bin/env python3
"""
texthumanizer CLI
-----------------
Usage:
    python -m texthumanizer.cli              # interactive mode
    python -m texthumanizer.cli --help
"""

import argparse
import sys
import os


def interactive_mode():
    from texthumanizer import TextHumanizer

    print("=" * 50)
    print("     texthumanizer  — AI Text Humanizer Tool")
    print("=" * 50)
    print("\n[1] Paste/type text")
    print("[2] Process a .docx file")
    choice = input("\nSelect option (1/2): ").strip()

    print("\nDiversity level  (0 = minimal changes | 1 = maximum rewriting)")
    div_input = input("Diversity [default 0.7]: ").strip()
    diversity = float(div_input) if div_input else 0.7

    th = TextHumanizer(diversity=diversity)

    if choice == "1":
        print("\nPaste your text (press Enter twice when done):")
        lines = []
        while True:
            line = input()
            if line == "" and lines and lines[-1] == "":
                break
            lines.append(line)
        text = "\n".join(lines).strip()
        if not text:
            print("No text provided. Exiting.")
            sys.exit(1)
        result = th.humanize_text(text)
        print("\n" + "─" * 50)
        print("HUMANIZED OUTPUT:")
        print("─" * 50)
        print(result)

    elif choice == "2":
        path = input("\nEnter .docx file path: ").strip().strip('"').strip("'")
        print("\nOutput format:")
        print("  [A] Save as humanized .docx")
        print("  [B] Print as plain text")
        fmt = input("Choose (A/B): ").strip().upper()

        if fmt == "A":
            out_path = input("Output path [leave blank for auto]: ").strip() or None
            result = th.humanize_doc(path, output="doc", output_path=out_path)
            print(f"\nSaved: {result}")
        else:
            result = th.humanize_doc(path, output="text")
            print("\n" + "─" * 50)
            print("HUMANIZED OUTPUT:")
            print("─" * 50)
            print(result)
    else:
        print("Invalid option.")
        sys.exit(1)


def cli_mode():
    parser = argparse.ArgumentParser(
        prog="python -m texthumanizer.cli",
        description="Offline AI-text humanizer & plagiarism reducer",
    )
    sub = parser.add_subparsers(dest="command")

    #text subcommand
    tp = sub.add_parser("text", help="Humanize a text string or stdin")
    tp.add_argument("input", nargs="?", help="Text to humanize (or pipe via stdin)")
    tp.add_argument("-d", "--diversity", type=float, default=0.7,
                    help="Rewriting diversity 0-1 (default 0.7)")

    #doc subcommand
    dp = sub.add_parser("doc", help="Humanize a .docx file")
    dp.add_argument("file", help="Path to .docx file")
    dp.add_argument("-o", "--output", choices=["doc", "text"], default="doc",
                    help="Output format: 'doc' saves file, 'text' prints result")
    dp.add_argument("-p", "--out-path", default=None,
                    help="Custom output .docx path (only for --output doc)")
    dp.add_argument("-d", "--diversity", type=float, default=0.7,
                    help="Rewriting diversity 0-1 (default 0.7)")

    args = parser.parse_args()

    if args.command is None:
        interactive_mode()
        return

    from texthumanizer import TextHumanizer
    th = TextHumanizer(diversity=args.diversity)

    if args.command == "text":
        if args.input:
            text = args.input
        else:
            text = sys.stdin.read()
        if not text.strip():
            print("No input provided.", file=sys.stderr)
            sys.exit(1)
        print(th.humanize_text(text))

    elif args.command == "doc":
        result = th.humanize_doc(args.file, output=args.output, output_path=args.out_path)
        if args.output == "text":
            print(result)


if __name__ == "__main__":
    cli_mode()
