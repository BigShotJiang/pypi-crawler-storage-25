"""
texthumanizer
=============
Offline AI-text humanizer & plagiarism reducer for students and researchers.

Quick Start
-----------
>>> from texthumanizer import TextHumanizer
>>> th = TextHumanizer()

#1. Humanize pasted text
>>> output = th.humanize_text("Artificial intelligence has rapidly transformed...")
>>> print(output)

#2a. Humanize a .docx → save new humanized .docx
>>> path = th.humanize_doc("my_essay.docx", output="doc")

#2b. Humanize a .docx → get plain text back
>>> text = th.humanize_doc("my_essay.docx", output="text")
"""

from .humanizer import TextHumanizer

__version__ = "1.0.0"
__author__  = "Rejaul Karim"
__all__     = ["TextHumanizer"]
