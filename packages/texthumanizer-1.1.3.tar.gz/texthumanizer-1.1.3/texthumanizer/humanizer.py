"""
texthumanizer/humanizer.py
Core humanization engine with semantic & research context preservation.
"""

import re
import time
from typing import Optional

try:
    from tqdm import tqdm
    TQDM_AVAILABLE = True
except ImportError:
    TQDM_AVAILABLE = False

# Patterns to PRESERVE during paraphrasing
_PRESERVE_PATTERNS = [
    (r'\[\d+(?:,\s*\d+)*\]',          "CITATION"),    # [1], [1,2]
    (r'\(\w+ et al\.,?\s*\d{4}\)',     "ETCIT"),       # (Smith et al., 2020)
    (r'\b(?:doi|DOI):\S+',             "DOI"),         # DOI:10.xxx
    (r'https?://\S+',                  "URL"),         # URLs
    (r'\b\d{4}\b',                     "YEAR"),        # Years: 2023
    (r'\b\d+\.?\d*\s*%',               "PCT"),         # 95%, 3.5%
    (r'\b\d+\.?\d*\s*(?:kg|mg|ml|km|nm|μm|Hz|kHz|MHz|GHz|kJ|MJ|kcal)\b',
                                       "UNIT"),        # units
    (r'\b[A-Z]{2,6}\b',               "ABBR"),        # DNA, COVID, LSTM
    (r'(?:Fig|Table|Eq|Eqn|Sec|Ref)\.\s*\d+',
                                       "FIGREF"),      # Fig. 3, Table 1
    (r'et al\.',                       "ETAL"),
    (r'e\.g\.',                        "EG"),
    (r'i\.e\.',                        "IE"),
    (r'viz\.',                         "VIZ"),
]


def _mask_terms(text: str) -> tuple[str, dict]:
    """Replace preserve-worthy terms with unique tokens. Returns masked text + mapping."""
    mapping = {}
    counter = [0]

    def _replace(pattern, label, t):
        def replacer(m):
            token = f"__{label}{counter[0]:04d}__"
            mapping[token] = m.group(0)
            counter[0] += 1
            return token
        return re.sub(pattern, replacer, t)

    for pattern, label in _PRESERVE_PATTERNS:
        text = _replace(pattern, label, text)
    return text, mapping


def _restore_terms(text: str, mapping: dict) -> str:
    """Restore masked terms from mapping."""
    for token, original in mapping.items():
        text = text.replace(token, original)
    return text


def _split_sentences(text: str) -> list[str]:
    """
    Sentence-aware splitter that handles:
    - Abbreviations (e.g., i.e., et al.)
    - Decimal numbers
    - Quoted sentences
    Returns a list of stripped sentences.
    """
    #Protect known abbreviation dots
    text = re.sub(r'\b(e\.g|i\.e|et al|viz|Dr|Mr|Mrs|Ms|Prof|Sr|Jr|vs|Fig|Eq|Sec)\.',
                  r'\1<DOT>', text)
    #Protect decimal numbers
    text = re.sub(r'(\d)\.(\d)', r'\1<DOT>\2', text)
    #Split on sentence-ending punctuation
    sentences = re.split(r'(?<=[.!?])\s+(?=[A-Z"\'(])', text)
    # Restore protected dots
    sentences = [s.replace('<DOT>', '.').strip() for s in sentences if s.strip()]
    return sentences


def _chunk_text(text: str, chunk_size: int = 3) -> list[list[str]]:
    """Group sentences into chunks for batch-style processing."""
    sentences = _split_sentences(text)
    chunks = []
    for i in range(0, len(sentences), chunk_size):
        chunks.append(sentences[i:i + chunk_size])
    return chunks


class TextHumanizer:
    """
    Lightweight, offline AI-text humanizer and plagiarism reducer.

    Preserves:
      - Research terminology, citations, abbreviations
      - Semantic meaning of each sentence
      - Paragraph structure in documents

    Parameters
    ----------
    model_name : str
        HuggingFace model for paraphrasing.
        Default: 'humarin/chatgpt_paraphraser_on_T5_base'
    device : int
        -1 for CPU, 0+ for GPU index.
    diversity : float
        0.0-1.0.  Higher = more rewriting, lower = safer preservation.
    verbose : bool
        Show progress information.
    """

    DEFAULT_MODEL = "humarin/chatgpt_paraphraser_on_T5_base"

    def __init__(
        self,
        model_name: Optional[str] = None,
        device: int = -1,
        diversity: float = 0.7,
        verbose: bool = True,
    ):
        self.model_name = model_name or self.DEFAULT_MODEL
        self.device = device
        self.diversity = max(0.0, min(1.0, diversity))
        self.verbose = verbose
        self._pipe = None  # lazy load

    # ── Lazy model loader 
    def _load_model(self):
        if self._pipe is not None:
            return
        try:
            from transformers import pipeline as hf_pipeline
        except ImportError:
            raise ImportError(
                "transformers is required. Install via:\n"
                "  pip install texthumanizer[ml]"
            )
        if self.verbose:
            print(f"Loading model: {self.model_name}  (first run may download ~250 MB)")
            
        # Updated loading pipeline (Fixed KeyError issue)
        self._pipe = hf_pipeline(
            model=self.model_name,
            device=self.device,
        )
        if self.verbose:
            print("Model ready.\n")

    #Internal sentence-level paraphrasing
    def _paraphrase_sentence(self, sentence: str) -> str:
        """Paraphrase a single sentence with semantic preservation and text cleaning."""
        if len(sentence.split()) < 4:          #too short to paraphrase meaningfully
            return sentence

        prompt = f"paraphrase: {sentence} </s>"

        # Diversity → temperature & sampling strategy
        temperature = 0.6 + self.diversity * 0.6   # 0.6 – 1.2
        top_k = int(30 + self.diversity * 70)       # 30 – 100
        top_p = 0.85 + self.diversity * 0.10        # 0.85 – 0.95

        try:
            # Updated generation logic to avoid HuggingFace warnings
            result = self._pipe(
                prompt,
                max_new_tokens=min(256, max(20, len(sentence.split()) * 3)),
                do_sample=True,
                temperature=temperature,
                top_k=top_k,
                top_p=top_p,
                num_return_sequences=1,
            )
            out = result[0]["generated_text"].strip()
            
            # --- CLEANUP LOGIC ---
            # 1. Remove "paraphrase:" (case-insensitive, handles extra spaces)
            out = re.sub(r'(?i)paraphrase\s*:', '', out)
            
            # 2. Remove special model tags like </s> or <pad>
            out = out.replace('</s>', '').replace('<pad>', '').replace('<s>', '')
            
            # 3. Fix multiple spaces into a single space and strip edges
            out = re.sub(r'\s+', ' ', out).strip()
            
            # 4. Capitalize the first letter safely (keeps the rest intact)
            if out:
                out = out[0].upper() + out[1:]

            # Fallback: if output is too short or identical, return original
            if len(out) < 5 or out.lower() == sentence.lower():
                return sentence
            return out
            
        except Exception:
            return sentence   #graceful fallback

    #Core processing: text block
    def _process_block(self, text: str) -> str:
        """Humanize a block of text (preserving technical terms)."""
        masked_text, mapping = _mask_terms(text)
        chunks = _chunk_text(masked_text, chunk_size=3)

        output_sentences = []
        iterator = tqdm(chunks, desc="  Humanizing", unit="chunk") \
            if TQDM_AVAILABLE and self.verbose else chunks

        for chunk in iterator:
            for sentence in chunk:
                humanized = self._paraphrase_sentence(sentence)
                output_sentences.append(humanized)

        result = " ".join(output_sentences)
        result = _restore_terms(result, mapping)
        return result

    #Public API

    def humanize_text(self, text: str) -> str:
        """
        Humanize pasted AI-generated text.

        Parameters
        ----------
        text : str
            Raw text (copy-pasted from AI tool, essay, etc.)

        Returns
        -------
        str
            Humanized, plagiarism-reduced text with semantic meaning preserved.
        """
        self._load_model()
        if self.verbose:
            print("Processing text input...")
            t0 = time.time()

        result = self._process_block(text.strip())

        if self.verbose:
            print(f"Done in {time.time()-t0:.1f}s\n")
        return result

    def humanize_doc(
        self,
        file_path: str,
        output: str = "doc",
        output_path: Optional[str] = None,
    ) -> str:
        """
        Humanize a .docx file.

        Parameters
        ----------
        file_path : str
            Path to the input .docx file.
        output : str
            'doc'  → saves a new humanized .docx and returns the output path.
            'text' → returns the humanized content as a plain string.
        output_path : str, optional
            Custom path for the output .docx.
        """
        from .processors.doc_processor import DocProcessor
        self._load_model()
        processor = DocProcessor(self)
        return processor.process(file_path, output=output, output_path=output_path)