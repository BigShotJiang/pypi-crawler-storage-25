"""
texthumanizer/processors/doc_processor.py
Handles reading, humanizing, and exporting .docx files
while preserving images, tables, drawings, and all non-text elements
via an in-place run-level text replacement strategy.
"""

import copy
import os
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..humanizer import TextHumanizer


class DocProcessor:
    """
    Processes .docx files paragraph-by-paragraph to preserve
    document structure (headings, body text, spacing) as well as
    all non-text elements such as images, drawings, tables, and
    complex run-level formatting.

    Strategy: "In-place Replacement"
    ---------------------------------
    Instead of building a new Document() from scratch (which discards
    everything except text), we:
      1. Open the original file as a template via shutil.copy + Document().
      2. Collect the full paragraph text and locate humanizable paragraphs.
      3. Humanize only body paragraphs (headings are left untouched).
      4. Write the humanized text back into the existing paragraph runs,
         preserving every run's character formatting (bold, italic, font,
         colour, size, etc.).
      5. Save the modified document to the output path.

    Run-text distribution
    ----------------------
    A paragraph's visible text is spread across one or more <w:r> runs.
    Each run may carry its own rPr (character formatting).  We preserve
    that structure: the first run receives the full humanized text; all
    subsequent runs in the same paragraph are cleared.  This keeps
    formatting of the first run intact and avoids orphaned styled runs
    that could corrupt the paragraph's appearance.
    """

    def __init__(self, humanizer: "TextHumanizer"):
        self.humanizer = humanizer
        
    # Public entry point
    def process(self, file_path: str, output: str = "doc", output_path=None) -> str:
        """Main entry point called by TextHumanizer.humanize_doc()."""
        file_path = os.path.expanduser(file_path)
        if not os.path.isfile(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")
        if not file_path.lower().endswith(".docx"):
            raise ValueError("Only .docx files are supported.")

        Document = self._load_docx()

        if self.humanizer.verbose:
            print(f"📂 Reading: {file_path}")

        #Determine output path early so we can copy there  
        out = self._resolve_output_path(file_path, output_path)

        #Work on a copy so the original is never mutated 
        import shutil
        shutil.copy2(file_path, out)

        doc = Document(out)
        paragraphs = doc.paragraphs

        # Identify body paragraphs that need humanizing 
        body_texts: list[str] = []
        body_indices: list[int] = []

        for i, para in enumerate(paragraphs):
            text = para.text.strip()
            style = para.style.name if para.style else "Normal"
            if text and not self._is_heading(style):
                body_texts.append(text)
                body_indices.append(i)

        #Humanize all body paragraphs in one pass 
        humanized_bodies = self._batch_humanize(body_texts)

        #Write humanized text back into the existing paragraphs
        for para_idx, humanized_text in zip(body_indices, humanized_bodies):
            self._replace_paragraph_text(paragraphs[para_idx], humanized_text)

        #Output 
        if output == "text":
            lines = []
            for para in doc.paragraphs:
                t = para.text.strip()
                if t:
                    lines.append(t)
            return "\n\n".join(lines)

        doc.save(out)
        if self.humanizer.verbose:
            print(f"\nSaved → {out}")
        return out

    # In-place run-level text replacement

    def _replace_paragraph_text(self, para, new_text: str) -> None:
        """
        Replace a paragraph's visible text with *new_text* while keeping:
          • The paragraph object itself (preserves images, drawings, bookmarks,
            hyperlinks, and field codes that live as sibling XML elements).
          • Each run's character properties (rPr: bold, italic, font, colour…).

        Algorithm
        ---------
        1. Collect all runs that currently carry text (skip runs that only
           hold inline images/drawings — those have no <w:t> child).
        2. Place the entire new_text into the first text-bearing run.
        3. Clear the text of every subsequent text-bearing run (set to "").

        Runs that hold only drawings or other non-text XML children are
        untouched, so embedded images remain in position.
        """
        # Gather runs that actually hold <w:t> text
        text_runs = [run for run in para.runs if self._run_has_text(run)]

        if not text_runs:
            # Paragraph has no text runs (e.g. image-only paragraph) — skip
            return

        # Put the full humanized text into the first run, clear the rest.
        # python-docx exposes run text via run.text; assigning to it rewrites
        # the underlying <w:t> element while leaving <w:rPr> intact.
        text_runs[0].text = new_text
        for run in text_runs[1:]:
            run.text = ""

    def _run_has_text(self, run) -> bool:
        """Return True if the run element contains a <w:t> child node."""
        # python-docx Run._element is the lxml element
        nsmap = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
        return run._element.find(f"{{{nsmap}}}t") is not None

    # Helpers
    def _load_docx(self):
        try:
            from docx import Document
            return Document
        except ImportError:
            raise ImportError(
                "python-docx is required. Install via:\n"
                "  pip install texthumanizer[docx]   or   pip install python-docx"
            )

    def _batch_humanize(self, texts: list) -> list:
        """Humanize a list of paragraph strings."""
        results = []
        total = len(texts)
        for idx, text in enumerate(texts, 1):
            if self.humanizer.verbose:
                print(f"  Paragraph {idx}/{total}...", end="\r")
            results.append(self.humanizer._process_block(text))
        if self.humanizer.verbose:
            print()
        return results

    def _is_heading(self, style_name: str) -> bool:
        """Detect heading styles (preserved as-is)."""
        s = style_name.lower()
        return s.startswith("heading") or s in {"title", "subtitle"}

    def _resolve_output_path(self, file_path: str, output_path) -> str:
        """Return the absolute path where the output .docx will be written."""
        if output_path:
            return os.path.expanduser(output_path)
        dirname = os.path.dirname(file_path) or "."
        basename = "humanized_" + os.path.basename(file_path)
        return os.path.join(dirname, basename)