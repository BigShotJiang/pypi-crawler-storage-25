"""AgentLoop checkpoint persistence backend.

This module provides persistence infrastructure for AgentLoop checkpoints
with thread/loop isolation and dual backend support (SQLite/PostgreSQL).

RFC-215: AgentLoop Persistence Backend Architecture
"""

from soothe.core.loop.state.persistence.manager import (
    AgentLoopCheckpointPersistenceManager,
)

__all__ = ["AgentLoopCheckpointPersistenceManager"]
