"""Thread executor for concurrent execution with isolation."""

from __future__ import annotations

import asyncio
import logging
from collections.abc import AsyncGenerator
from typing import TYPE_CHECKING, Any

from soothe.logging import ThreadLogger

if TYPE_CHECKING:
    from soothe.core.runner import SootheRunner

logger = logging.getLogger(__name__)


class ThreadExecutor:
    """Manages concurrent thread execution with isolation."""

    def __init__(
        self,
        runner: SootheRunner,
        max_concurrent_threads: int = 100,
    ) -> None:
        """Initialize thread executor.

        Args:
            runner: SootheRunner instance
            max_concurrent_threads: Maximum concurrent threads
        """
        self._runner = runner
        self._max_concurrent = max_concurrent_threads
        self._active_tasks: dict[str, asyncio.Task] = {}

    async def execute_thread(
        self,
        thread_id: str,
        user_input: str,
        **kwargs: Any,
    ) -> AsyncGenerator[Any]:
        """Execute query in isolated thread context.

        Rate limiting is now handled at LLM level via LLMRateLimitMiddleware,
        not at thread level. Threads start immediately and share LLM API permits.

        Args:
            thread_id: Thread ID to execute in
            user_input: User input text
            **kwargs: Additional arguments for runner.astream

        Yields:
            Stream chunks from runner
        """
        # Thread id is passed to astream(); do not mutate runner._current_thread_id (IG-110).

        # Create isolated logger
        ThreadLogger(thread_id=thread_id)

        logger.info("Executing query in thread %s", thread_id)

        # Execute immediately without thread-level rate limiting
        # LLM-level rate limiting handled by LLMRateLimitMiddleware
        try:
            async for chunk in self._runner.astream(
                user_input,
                thread_id=thread_id,
                **kwargs,
            ):
                # Log to thread-specific logger
                # ThreadLogger will handle the actual logging
                yield chunk
        except Exception:
            logger.exception("Error in thread %s", thread_id)
            raise
