"""Tool, goal, and subagent resolution for create_soothe_agent.

Extracted from ``resolver.py`` to isolate tool/subagent wiring from
protocol and infrastructure resolution.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any

from soothe.config import BrowserSubagentConfig, SootheConfig
from soothe.core.workspace.tool_path_resolution import (
    filesystem_virtual_mode_from_soothe_config,
    max_file_size_mb_for_filesystem_backend,
)
from soothe.utils import expand_path

if TYPE_CHECKING:
    from collections.abc import Callable

    from deepagents.middleware.subagents import CompiledSubAgent, SubAgent
    from langchain_core.language_models import BaseChatModel
    from langchain_core.tools import BaseTool

    from soothe.core.goal_engine import GoalEngine

logger = logging.getLogger(__name__)


def _get_subagent_factories() -> dict[str, Callable[..., SubAgent | CompiledSubAgent]]:
    """Lazily load subagent factories on first access.

    This avoids importing heavy subagent modules (browser)
    at module load time, which was causing 24+ second startup delays.
    """
    from soothe.subagents.browser import create_browser_subagent
    from soothe.subagents.claude import create_claude_subagent
    from soothe.subagents.explore import create_explore_subagent
    from soothe.subagents.plan import create_plan_subagent
    from soothe.subagents.research import create_research_subagent

    return {
        "browser": create_browser_subagent,
        "claude": create_claude_subagent,
        "explore": create_explore_subagent,
        "plan": create_plan_subagent,
        "research": create_research_subagent,
    }


# Lazy accessor for SUBAGENT_FACTORIES
class _SubagentFactoriesAccessor:
    """Lazy accessor for subagent factories."""

    _factories: dict[str, Callable[..., SubAgent | CompiledSubAgent]] | None = None

    def __getitem__(self, key: str) -> Callable[..., SubAgent | CompiledSubAgent]:
        if self._factories is None:
            self._factories = _get_subagent_factories()
        return self._factories[key]

    def get(self, key: str, default: Any = None) -> Any:
        if self._factories is None:
            self._factories = _get_subagent_factories()
        return self._factories.get(key, default)

    def keys(self) -> Any:  # type: ignore[override]
        if self._factories is None:
            self._factories = _get_subagent_factories()
        return self._factories.keys()

    def items(self) -> Any:  # type: ignore[override]
        if self._factories is None:
            self._factories = _get_subagent_factories()
        return self._factories.items()

    def __len__(self) -> int:
        if self._factories is None:
            self._factories = _get_subagent_factories()
        return len(self._factories)


SUBAGENT_FACTORIES = _SubagentFactoriesAccessor()


def _call_subagent_factory(factory: Any, kwargs: dict[str, Any]) -> Any:
    """Invoke a subagent factory and return its spec (dict or agent object).

    Plugin factories from ``@subagent`` are async; built-in factories are sync.
    When no event loop is running, coroutine results are driven with
    :func:`asyncio.run` (AgentBuilder runs in a synchronous context).
    When a loop is already running (e.g. async tests or nested async), the
    coroutine is completed on a worker thread with its own loop so we never
    call :func:`asyncio.run` from inside a running loop.
    """
    import asyncio
    import inspect
    from concurrent.futures import ThreadPoolExecutor

    result = factory(**kwargs)
    if not inspect.iscoroutine(result):
        return result
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(result)

    def _run_coro_on_fresh_loop(coro: Any) -> Any:
        return asyncio.run(coro)

    with ThreadPoolExecutor(max_workers=1) as pool:
        return pool.submit(_run_coro_on_fresh_loop, result).result()


# ---------------------------------------------------------------------------
# Tool resolution
# ---------------------------------------------------------------------------


def resolve_tools(
    tools_config: Any,
    *,
    lazy: bool = False,
    config: SootheConfig | None = None,
) -> list[BaseTool]:
    """Resolve tool groups from ToolsConfig to instantiated langchain BaseTool lists.

    Args:
        tools_config: ToolsConfig instance with enabled tool groups.
        lazy: If True, load tool groups in parallel using a thread pool
            for faster startup.  Historically this created lazy proxies,
            but those are incompatible with langgraph ToolNode's eager
            metadata probing.
        config: Optional Soothe config for tool configuration.

    Returns:
        Flat list of fully-initialised `BaseTool` instances.
    """
    import time

    # Get list of enabled tool group names
    # Note: "research" is a subagent, not a tool group - handled in resolve_subagents()
    enabled_tools = [
        name
        for name in [
            "execution",
            "file_ops",
            "datetime",
            "data",
            "wizsearch",
            "http_requests",
            "image",
            "audio",
            "video",
        ]
        if getattr(tools_config, name, None) and getattr(tools_config, name).enabled
    ]

    # Filter out execution tools when sandbox is disabled (IG-sandbox)
    if config and hasattr(config, "security") and config.security:
        if not config.security.sandbox:
            enabled_tools = [name for name in enabled_tools if name != "execution"]
            logger.debug("Sandbox disabled: execution tools filtered out")

    total_start = time.perf_counter()

    parallel = lazy and len(enabled_tools) > 1
    tools = (
        _resolve_tools_parallel(enabled_tools, config)
        if parallel
        else _resolve_tools_sequential(enabled_tools, config)
    )

    total_elapsed_ms = (time.perf_counter() - total_start) * 1000
    logger.info(
        "Resolved %d tool groups (%d tools) in %.1fms (parallel=%s)",
        len(enabled_tools),
        len(tools),
        total_elapsed_ms,
        parallel,
    )

    return tools


def _resolve_tools_sequential(
    tool_names: list[str],
    config: SootheConfig | None = None,
) -> list[BaseTool]:
    """Load tool groups one-by-one, skipping failures."""
    tools: list[BaseTool] = []
    for name in tool_names:
        try:
            resolved = _resolve_single_tool_group(name, config)
            tools.extend(resolved)
        except Exception:
            logger.warning("Failed to load tool group '%s'", name, exc_info=True)
    return tools


def _resolve_tools_parallel(
    tool_names: list[str],
    config: SootheConfig | None = None,
) -> list[BaseTool]:
    """Load tool groups concurrently via ThreadPoolExecutor.

    Overlaps I/O-bound module imports and network initialisation across
    tool groups while preserving the original ordering in the result.
    Failed groups are logged and skipped.
    """
    from concurrent.futures import ThreadPoolExecutor

    max_workers = min(len(tool_names), 4)
    results: dict[str, list[BaseTool]] = {}

    with ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="tool-load") as pool:
        futures = {
            name: pool.submit(_resolve_single_tool_group, name, config) for name in tool_names
        }
        for name in tool_names:
            try:
                results[name] = futures[name].result()
            except Exception:
                logger.warning("Failed to load tool group '%s'", name, exc_info=True)

    tools: list[BaseTool] = []
    for name in tool_names:
        tools.extend(results.get(name, []))
    return tools


def _resolve_single_tool_group(name: str, config: SootheConfig | None = None) -> list[BaseTool]:
    """Resolve a single tool group name to a list of BaseTool instances with caching and profiling.

    This method checks the cache first, and if not found, delegates to the uncached version.
    """
    import time

    from soothe.core.scheduling.tool_cache import cache_tools, get_cached_tools
    from soothe.core.workspace.framework_filesystem import FrameworkFilesystem

    # Include workspace in cache key to prevent cross-workspace tool reuse
    current_ws = FrameworkFilesystem.get_current_workspace()
    ws_key = str(current_ws) if current_ws else None

    cached = get_cached_tools(name, workspace=ws_key)
    if cached is not None:
        logger.debug("Tool group '%s' loaded from cache (%d tools)", name, len(cached))
        return cached

    start = time.perf_counter()
    tools = _resolve_single_tool_group_uncached(name, config)
    elapsed_ms = (time.perf_counter() - start) * 1000

    if tools:
        cache_tools(name, tools, workspace=ws_key)

    logger.debug("Tool group '%s' loaded in %.1fms (%d tools)", name, elapsed_ms, len(tools))
    return tools


def _resolve_single_tool_group_uncached(
    name: str, config: SootheConfig | None = None
) -> list[BaseTool]:
    """Resolve a single tool group name to a list of BaseTool instances.

    Args:
        name: Tool group name.
        config: Optional Soothe config for tool configuration.
    """
    # Try plugin registry first
    try:
        from soothe.plugin.global_registry import get_plugin_registry, is_plugins_loaded

        if is_plugins_loaded():
            registry = get_plugin_registry()
            plugin_tools = registry.get_tools_for_group(name)
            if plugin_tools:
                logger.debug(
                    "Resolved tool group '%s' from plugins (%d tools)", name, len(plugin_tools)
                )
                return plugin_tools
    except RuntimeError:
        logger.debug(
            "Plugin registry not loaded, falling back to hardcoded dispatch for '%s'", name
        )

    # Toolkit dispatch using new toolkit classes
    if name == "datetime":
        from soothe.toolkits.datetime import DatetimeToolkit

        toolkit = DatetimeToolkit()
        return toolkit.get_tools()

    if name == "image":
        from soothe.toolkits.image import ImageToolkit

        toolkit = ImageToolkit(config=config)
        return toolkit.get_tools()

    if name == "audio":
        from soothe.toolkits.audio import AudioToolkit

        toolkit = AudioToolkit(config=config)
        return toolkit.get_tools()

    if name == "video":
        from soothe.toolkits.video import VideoToolkit

        toolkit = VideoToolkit(config=config)
        return toolkit.get_tools()

    if name == "wizsearch":
        from soothe.toolkits.wizsearch import WizsearchToolkit

        web_search_config: dict = {}
        if config and hasattr(config, "tools") and hasattr(config.tools, "wizsearch"):
            ws = config.tools.wizsearch
            web_search_config = {
                "default_engines": ws.default_engines,
                "max_results_per_engine": ws.max_results_per_engine,
                "timeout": ws.timeout,
            }
        if config and hasattr(config, "debug"):
            web_search_config["debug"] = config.debug
        toolkit = WizsearchToolkit(config=web_search_config)
        return toolkit.get_tools()

    if name == "execution":
        from soothe.toolkits.execution import ExecutionToolkit

        resolved_cwd = (
            str(expand_path(config.workspace_dir))
            if config and config.workspace_dir
            else str(Path.cwd())
        )
        toolkit = ExecutionToolkit(
            workspace_root=resolved_cwd,
            security_config=(getattr(config, "security", None) if config else None),
        )
        return toolkit.get_tools()

    if name == "http_requests":
        from soothe.toolkits.http_requests import HttpRequestsToolkit

        toolkit = HttpRequestsToolkit(config=config)
        return toolkit.get_tools()

    # Support individual tool names (map to consolidated group)
    if name in ("run_command", "run_background", "kill_process", "run_python"):
        # Filter out if sandbox is disabled (IG-sandbox)
        if config and hasattr(config, "security") and config.security:
            if not config.security.sandbox:
                logger.debug("Sandbox disabled: '%s' tool filtered out", name)
                return []
        from soothe.toolkits.execution import ExecutionToolkit

        resolved_cwd = (
            str(expand_path(config.workspace_dir))
            if config and config.workspace_dir
            else str(Path.cwd())
        )
        toolkit = ExecutionToolkit(
            workspace_root=resolved_cwd,
            security_config=(getattr(config, "security", None) if config else None),
        )
        all_tools = toolkit.get_tools()
        tool_map = {tool.name: tool for tool in all_tools}
        if name in tool_map:
            return [tool_map[name]]
        logger.warning("Tool '%s' not found in ExecutionToolkit", name)
        return []

    if name == "file_ops":
        from deepagents.backends.filesystem import FilesystemBackend  # noqa: I001

        from soothe.middleware.filesystem import SootheFilesystemMiddleware  # noqa: I001

        resolved_cwd = (
            str(expand_path(config.workspace_dir))
            if config and config.workspace_dir
            else str(Path.cwd())
        )

        virtual_mode = filesystem_virtual_mode_from_soothe_config(config) if config else False
        max_file_size_mb = max_file_size_mb_for_filesystem_backend(config) if config else 10

        # Create filesystem backend
        backend = FilesystemBackend(
            root_dir=resolved_cwd or None,
            virtual_mode=virtual_mode,
            max_file_size_mb=max_file_size_mb,
        )

        # Create middleware with surgical file ops
        middleware = SootheFilesystemMiddleware(
            backend=backend,
            backup_enabled=True,
            workspace_root=resolved_cwd or None,
            tool_token_limit_before_evict=20000,
        )

        # Extract surgical tools only (not ls, read_file, etc. from FilesystemMiddleware)
        surgical_tool_names = [
            "delete_file",
            "file_info",
            "edit_file_lines",
            "insert_lines",
            "delete_lines",
            "apply_diff",
        ]
        tools = [t for t in middleware.tools if t.name in surgical_tool_names]
        return tools

    # Support individual tool names (map to consolidated group)
    if name in (
        "read_file",
        "write_file",
        "delete_file",
        "search_files",
        "list_files",
        "file_info",
        "edit_file_lines",
        "insert_lines",
        "delete_lines",
        "apply_diff",
    ):
        from deepagents.backends.filesystem import FilesystemBackend  # noqa: I001

        from soothe.middleware.filesystem import SootheFilesystemMiddleware  # noqa: I001

        resolved_cwd = (
            str(expand_path(config.workspace_dir))
            if config and config.workspace_dir
            else str(Path.cwd())
        )

        virtual_mode = filesystem_virtual_mode_from_soothe_config(config) if config else False
        max_file_size_mb = max_file_size_mb_for_filesystem_backend(config) if config else 10

        # Create filesystem backend
        backend = FilesystemBackend(
            root_dir=resolved_cwd or None,
            virtual_mode=virtual_mode,
            max_file_size_mb=max_file_size_mb,
        )

        # Create middleware with surgical file ops
        middleware = SootheFilesystemMiddleware(
            backend=backend,
            backup_enabled=True,
            workspace_root=resolved_cwd or None,
            tool_token_limit_before_evict=20000,
        )

        # Extract surgical tools only
        surgical_tool_names = [
            "delete_file",
            "file_info",
            "edit_file_lines",
            "insert_lines",
            "delete_lines",
            "apply_diff",
        ]
        all_tools = [t for t in middleware.tools if t.name in surgical_tool_names]
        tool_map = {tool.name: tool for tool in all_tools}

        # For read_file/write_file/edit_file/search_files/list_files, these come from deepagents
        # so we need to get them from the middleware's full tools list
        if name in ("read_file", "write_file", "edit_file", "search_files", "list_files"):
            full_tool_map = {tool.name: tool for tool in middleware.tools}
            if name in full_tool_map:
                return [full_tool_map[name]]
            logger.warning("Tool '%s' not found in SootheFilesystemMiddleware", name)
            return []

        if name in tool_map:
            return [tool_map[name]]
        logger.warning("Tool '%s' not found in surgical tools", name)
        return []

    if name == "data":
        from soothe.toolkits.data import DataToolkit

        toolkit = DataToolkit(config=config)
        return toolkit.get_tools()

    # Support individual data tool names (map to consolidated group)
    if name in (
        "inspect_data",
        "summarize_data",
        "check_data_quality",
        "extract_text",
        "get_data_info",
        "ask_about_file",
    ):
        from soothe.toolkits.data import DataToolkit

        toolkit = DataToolkit(config=config)
        all_tools = toolkit.get_tools()
        tool_map = {tool.name: tool for tool in all_tools}
        if name in tool_map:
            return [tool_map[name]]
        logger.warning("Tool '%s' not found in DataToolkit", name)
        return []

    # --- Goal management tools (RFC-0016 single-purpose) ---
    if name == "goals":
        return []  # Goals are handled separately via resolve_goal_tools

    # Support individual goal tool names (map to consolidated group)
    if name in ("create_goal", "list_goals", "complete_goal", "fail_goal"):
        # These require goal_engine, return empty for now
        # They will be handled via resolve_goal_tools
        return []

    logger.warning("Unknown tool group '%s', skipping.", name)
    return []


# ---------------------------------------------------------------------------
# Goal engine resolution
# ---------------------------------------------------------------------------


def resolve_goal_engine(config: SootheConfig) -> GoalEngine:
    """Create a GoalEngine instance from config.

    Args:
        config: Soothe configuration.

    Returns:
        A configured GoalEngine with backoff reasoner support.
    """
    from soothe.core.goal_engine import GoalEngine

    # RFC-200: Pass config for GoalBackoffReasoner initialization
    return GoalEngine(
        max_retries=config.autonomous.max_retries,
        config=config,  # Enable LLM-driven backoff reasoning
    )


# ---------------------------------------------------------------------------
# Subagent resolution
# ---------------------------------------------------------------------------


def resolve_subagents(
    config: SootheConfig,
    default_model: BaseChatModel | None = None,
    *,
    lazy: bool = False,
) -> list[SubAgent | CompiledSubAgent]:
    """Build subagent specs from config.

    Args:
        config: Soothe configuration.
        default_model: Pre-configured model instance to use as default.
        lazy: If True, create subagent specs in parallel using a thread
            pool for faster startup.

    Returns:
        List of subagent specs for deepagents.
    """
    import time

    total_start = time.perf_counter()

    # Collect (name, factory, kwargs) tuples for enabled subagents
    pending: list[tuple[str, Callable, dict]] = []
    cwd_subagents = {"claude"}
    resolved_cwd = (
        str(expand_path(config.workspace_dir)) if config.workspace_dir else str(Path.cwd())
    )

    for name, sub_cfg in config.subagents.items():
        if not sub_cfg.enabled:
            continue

        factory = None
        resolved_via_plugin = False
        try:
            from soothe.plugin.global_registry import get_plugin_registry, is_plugins_loaded

            if is_plugins_loaded():
                registry = get_plugin_registry()
                reg_factory = registry.get_subagent_factory(name)
                if reg_factory is not None:
                    factory = reg_factory
                    resolved_via_plugin = True
                    logger.debug("Resolved subagent '%s' from plugin registry", name)
        except RuntimeError:
            logger.debug("Plugin registry not loaded, using fallback for '%s'", name)

        if factory is None:
            factory = SUBAGENT_FACTORIES.get(name)

        if factory is None:
            logger.warning("Unknown subagent '%s', skipping.", name)
            continue

        if name == "claude":
            model_override = None
        elif name == "explore":
            model_override = sub_cfg.model or config.create_chat_model("fast")
        elif name == "plan":
            # Built-in: always the router ``think`` role (ignore ``subagents.plan.model``).
            model_override = config.create_chat_model("think")
        else:
            model_override = sub_cfg.model or default_model or config.resolve_model("default")

        if resolved_via_plugin:
            from soothe.plugin.context import create_plugin_context

            plugin_instance = factory.__self__
            pname = plugin_instance.manifest.name
            plugin_ctx = create_plugin_context(
                plugin_name=pname,
                config=dict(sub_cfg.config),
                soothe_config=config,
            )
            call_kwargs = dict(sub_cfg.config)
            call_kwargs["model"] = model_override
            call_kwargs["config"] = config
            call_kwargs["context"] = plugin_ctx
            pending.append((name, factory, call_kwargs))
            continue

        extra_kwargs: dict = dict(sub_cfg.config)
        if name in cwd_subagents and "cwd" not in extra_kwargs:
            extra_kwargs["cwd"] = resolved_cwd
        if name == "browser":
            extra_kwargs["config"] = BrowserSubagentConfig(**sub_cfg.config)
        if name == "research":
            extra_kwargs["config"] = config
            if "context" not in extra_kwargs:
                extra_kwargs["context"] = {"work_dir": resolved_cwd}
        elif name == "explore":
            # Explore YAML options live in ``config.subagents["explore"].config`` only.
            # Do not spread them as kwargs — ``create_explore_subagent`` accepts ``model``,
            # ``SootheConfig``, and ``context`` only.
            extra_kwargs.clear()
            extra_kwargs["config"] = config
            extra_kwargs["context"] = {"work_dir": resolved_cwd}
        elif name == "plan":
            extra_kwargs.clear()
            extra_kwargs["config"] = config
            extra_kwargs["context"] = {"work_dir": resolved_cwd}

        pending.append((name, factory, {"model": model_override, **extra_kwargs}))

    parallel = lazy and len(pending) > 1
    subagents = (
        _resolve_subagents_parallel(pending) if parallel else _resolve_subagents_sequential(pending)
    )

    total_elapsed_ms = (time.perf_counter() - total_start) * 1000
    logger.info(
        "Resolved %d subagents in %.1fms (parallel=%s)",
        len(subagents),
        total_elapsed_ms,
        parallel,
    )

    return subagents


def _resolve_subagents_sequential(
    pending: list[tuple[str, Callable, dict]],
) -> list[SubAgent | CompiledSubAgent]:
    """Build subagent specs one-by-one, skipping failures."""
    import time

    subagents: list[SubAgent | CompiledSubAgent] = []
    for name, factory, kwargs in pending:
        start = time.perf_counter()
        try:
            spec = _call_subagent_factory(factory, kwargs)
            elapsed_ms = (time.perf_counter() - start) * 1000
            logger.info("Loaded subagent '%s' in %.1fms", name, elapsed_ms)
            subagents.append(spec)
        except Exception:
            logger.exception("Failed to load subagent '%s'", name)
    return subagents


def _resolve_subagents_parallel(
    pending: list[tuple[str, Callable, dict]],
) -> list[SubAgent | CompiledSubAgent]:
    """Build subagent specs concurrently, preserving order."""
    import time
    from concurrent.futures import ThreadPoolExecutor

    max_workers = min(len(pending), 4)

    def _build(entry: tuple[str, Callable, dict]) -> SubAgent | CompiledSubAgent:
        name, factory, kwargs = entry
        start = time.perf_counter()
        spec = _call_subagent_factory(factory, kwargs)
        elapsed_ms = (time.perf_counter() - start) * 1000
        logger.info("Loaded subagent '%s' in %.1fms", name, elapsed_ms)
        return spec

    subagents: list[SubAgent | CompiledSubAgent] = []
    with ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="subagent-load") as pool:
        futures = [(entry[0], pool.submit(_build, entry)) for entry in pending]
        for name, future in futures:
            try:
                subagents.append(future.result())
            except Exception:
                logger.exception("Failed to load subagent '%s'", name)
    return subagents
