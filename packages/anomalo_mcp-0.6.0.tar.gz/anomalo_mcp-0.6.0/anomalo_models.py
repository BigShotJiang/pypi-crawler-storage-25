from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List


####
# Structured models
####


@dataclass
class ConfiguredCheck:
    check_id: int
    check_type: str
    check_static_id: str | int
    description: str | None
    created_at: str | None
    created_by: str | None
    last_edited_at: str | None
    last_edited_by: str | None
    current_triage_status: str | None

    def __init__(self, check: Dict[str, Any]):
        """Initialize the configured check with metadata from the get_checks_for_table api response."""
        self.check_id = check["check_id"]
        self.check_type = check.get("check_type") or "unknown"
        self.check_static_id = check.get("check_static_id") or check.get("check_id")
        self.description = ((check.get("config") or {}).get("_metadata") or {}).get(
            "check_message", ""
        )
        self.created_at = check.get("created")
        self.created_by = (check.get("created_by") or {}).get("name") or "unknown"
        self.last_edited_at = check.get("last_edited_at")
        self.last_edited_by = (check.get("last_edited_by") or {}).get(
            "name"
        ) or "unknown"
        self.current_triage_status = check.get("triage_status")


@dataclass
class CheckResult:
    check_id: int | str
    check_run_id: int | str
    execution_status: str | None
    completed_at: str | None
    labels: List[str]
    check_still_running: bool
    check_errored: bool
    check_passed: bool
    check_failed: bool
    result_message: str | None
    exception_msg: str | None
    check_history_message: str | None
    statistic_name: str | None
    statistic_value: Any | None
    statistic_context: str | None
    url_for_csv_of_sample_of_bad_rows: str | None
    sql_for_bad_rows: str | None
    url_for_csv_of_sample_of_good_rows: str | None
    sql_for_good_rows: str | None

    def __init__(self, check_result: Dict[str, Any]):
        """Initialize the check result with metadata from the check result."""
        self.check_id = check_result.get("check_id")
        self.check_run_id = check_result.get("check_run_id")
        self.execution_status = check_result.get("status")
        self.completed_at = check_result.get("completed_at")
        self.labels = [l.name for l in (check_result.get("labels") or []) if l]

        self.check_still_running = check_result.get("results_pending", False)
        result = check_result.get("results") or {}
        if self.check_still_running:
            self.check_errored = False
            self.check_passed = False
            self.check_failed = False
        else:
            self.check_errored = result.get("errored", False)
            # Both check_passed and check_failed default to False if 'success' is not present
            self.check_passed = result.get("success", False)
            self.check_failed = not result.get("success", True)

        self.result_message = result.get("evaluated_message")
        self.exception_msg = result.get("exception_msg")
        self.check_history_message = result.get("history_message")

        self.statistic_name = result.get("statistic_name")
        self.statistic_value = result.get("statistic")
        self.statistic_context = result.get("statistic_context")

        self.url_for_csv_of_sample_of_bad_rows = result.get("sample_rows_bad_csv_url")
        self.sql_for_bad_rows = result.get("sample_rows_bad_sql")
        self.url_for_csv_of_sample_of_good_rows = result.get("sample_rows_good_csv_url")
        self.sql_for_good_rows = result.get("sample_rows_good_sql")


@dataclass
class CheckRunResult:
    check_results: List[CheckResult]
    is_complete: bool

    def __init__(self, results: list[CheckResult]):
        self.check_results = results
        self.is_complete = not any(r.check_still_running for r in results)


@dataclass
class TableConfig:
    id: int
    full_name: str
    name: str
    description: str | None
    monitored: bool
    url: str
    warehouse_id: int
    warehouse_name: str
    warehouse_type: str
    data_quality_status: Dict[str, int | bool] | None = None
    latest_data_quality_check_run_job_id: str | None = None

    data_quality_check_results: list[Dict[str, Any]] | None = None

    def __init__(
        self,
        id: int,
        full_name: str,
        name: str,
        description: str,
        monitored: bool,
        url: str,
        warehouse_id: int,
        warehouse_name: str,
        warehouse_type: str,
        check_runs: List[Dict[str, Any]],
    ):
        """Initialize the table config with metadata from the table config."""
        self.id = id
        self.full_name = full_name
        self.name = name
        self.description = description
        self.monitored = monitored
        self.url = url
        self.warehouse_id = warehouse_id
        self.warehouse_name = warehouse_name
        self.warehouse_type = warehouse_type

        if check_runs:
            if last_completed_run := next(
                iter([c for c in check_runs if c.get("status") == "complete"]), None
            ):
                self.latest_data_quality_check_run_job_id = last_completed_run.get(
                    "latest_run_checks_job_id"
                )


@dataclass
class DataProfile:
    table_id: int
    table_name: str
    description: str | None

    column_value_image_url: str | None
    column_value_samples: List[Dict[str, Any]] | None

    data_profile_image_url: str | None
    data_profile_details: List[Dict[str, Any]] | None

    def __init__(
        self,
        profile: Dict[str, Any],
    ):
        self.table_id = profile.get("id")
        self.table_name = profile.get("full_name")
        self.description = profile.get("description")
        self.column_value_image_url = profile.get("columns", {}).get("img_url")
        self.column_value_samples = profile.get("columns", {}).get("data", [])
        self.data_profile_image_url = profile.get("profile", {}).get("img_url")
        self.data_profile_details = profile.get("profile", {}).get("details", [])


####
# Unstructured models
####


class SourceType(Enum):
    S3 = "s3"
    TABLE = "table"


@dataclass
class Collection:
    id: int | str
    name: str
    description: str | None
    organization_id: int | str
    source_type: str | None
    bucket_name: str | None
    path_prefix: str | None
    mime_types: List[str]
    ai_model: str | None

    def __init__(self, collection: "Dict[str, Any] | Collection"):
        """Initialize the collection with metadata and from the collection config."""
        if isinstance(collection, Collection):
            self.id = collection.id
            self.name = collection.name
            self.description = collection.description
            self.organization_id = collection.organization_id
            self.source_type = collection.source_type
            self.bucket_name = collection.bucket_name
            self.path_prefix = collection.path_prefix
            self.mime_types = collection.mime_types
            self.ai_model = collection.ai_model
        else:
            self.id = collection["id"]
            self.name = collection["name"]
            self.description = collection.get("description")
            self.organization_id = collection["organization_id"]
            self.source_type = (collection.get("source") or {}).get("type")
            self.bucket_name = (collection.get("source") or {}).get("bucket_name")
            self.path_prefix = (collection.get("source") or {}).get("path_prefix")
            self.mime_types = (collection.get("source") or {}).get("mime_types", [])
            self.ai_model = collection.get("ai_model")


@dataclass
class CollectionBreakdown(Collection):
    last_check_run_id: int | str | None
    last_check_run_completed_at: str | None
    document_count: int
    summary: str
    score: float | None
    issues: Dict[str, int]
    metadata: Dict[str, Dict[str, int]]

    def __init__(
        self, collection: Dict[str, Any] | Collection, check_run: Dict[str, int]
    ):
        """Initialize the collection breakdown with metadata and from the collection config and check_run summary."""
        super().__init__(collection)

        self.last_check_run_id = check_run.get("id")
        self.last_check_run_completed_at = check_run.get("completed_at")
        self.document_count = check_run.get("num_documents", 0)
        self.summary = check_run.get("summary", "")
        self.score = check_run.get("score")

        self.issues = {}
        self.metadata = {
            "tone": {},
            "sentiment": {},
            "language": {},
            "theme": {},
            "writing_level": {},
            "score": {},
        }

    @property
    def readme(self) -> str:
        """Generate a README for the collection based on its metadata."""
        readme = f"<h2>Summary</h2>\n<p>{self.summary}</p>\n\n"

        if self.issues:
            readme += f"""
<h2>Issues</h2>

<table>
  <tr><th>Issue</th><th></th></tr>
"""
            for issue, count in sorted(self.issues.items()):
                pct = (
                    f"{count / self.document_count:.0%}"
                    if self.document_count > 0
                    else "-"
                )
                readme += f"<tr><td>{issue}</td><td>{pct}</td></tr>\n"

            readme += "</table>\n\n"

        if self.metadata:
            for category, entries in sorted(self.metadata.items()):
                if entries:
                    readme += f"<h2>{category.capitalize()}</h2>\n\n<table>\n  <tr><th>{category.capitalize()}</th><th>Document count</th></tr>"

                    for item, count in sorted(
                        entries.items(), key=lambda x: x[1], reverse=True
                    ):
                        readme += f"<tr><td>{item}</td><td>{count}</td></tr>\n"
                    readme += "</table>\n\n"

        return readme

    def process_document(self, doc: Dict[str, Any], issues: List[Dict[str, Any]]):
        """Update the collection breakdown based on findings from an analyzed document in the collection"""
        for k in self.metadata:
            v = doc.get(k)
            if v:
                if v not in self.metadata[k]:
                    self.metadata[k][v] = 0
                self.metadata[k][v] += 1

        for issue in issues:
            issue_type = issue.get("label")
            if issue_type:
                if issue_type not in self.issues:
                    self.issues[issue_type] = 0
                self.issues[issue_type] += 1
