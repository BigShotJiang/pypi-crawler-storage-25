# Anomalo MCP Server

Data quality tools for Claude Desktop, Cursor, Gemini CLI, and other MCP clients — powered by your Anomalo deployment.

## Install and run

Requires [`uv`](https://docs.astral.sh/uv/) (or `pipx`).

```sh
export ANOMALO_INSTANCE_HOST=YOUR-INSTANCE.anomalo.com
export ANOMALO_API_SECRET_TOKEN=your-api-key
uvx anomalo-mcp
```

Get an API key at `https://YOUR-INSTANCE.anomalo.com` → Settings → API Keys.

## Wire it into an MCP client

### Claude Desktop

Add to `~/Library/Application Support/Claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "anomalo": {
      "command": "uvx",
      "args": ["anomalo-mcp"],
      "env": {
        "ANOMALO_INSTANCE_HOST": "YOUR-INSTANCE.anomalo.com",
        "ANOMALO_API_SECRET_TOKEN": "your-api-key"
      }
    }
  }
}
```

Restart Claude Desktop, then try: *"Use Anomalo to list the organizations."*

### Gemini CLI

Install the [`anomalo-gemini-extension`](https://github.com/datagravity-ai/anomalo-gemini-extension) — it wraps this MCP server for the Gemini CLI.

## Environment variables

| Variable | Required | Description |
|---|---|---|
| `ANOMALO_INSTANCE_HOST` | yes | Anomalo instance hostname (e.g. `app.anomalo.com`) |
| `ANOMALO_API_SECRET_TOKEN` | yes | API token for the Anomalo instance |
| `SENTRY_DSN` | no | Enables Sentry error reporting with PII scrubbing. Requires the `[sentry]` extra: `uvx --with sentry-sdk anomalo-mcp` |
| `AIDA_FETCH_FILES` | no | `true` to download AIDA CSV results inline — off by default |

## Developing from source

```sh
cd anomalo_labs/anomalo-mcp
uv sync
uv run pytest tests
```

To run the local checkout against your Anomalo instance:

```sh
uv run anomalo-mcp
```

Running from source also loads `dev_plugins/` (internal-only tools not shipped on PyPI).
