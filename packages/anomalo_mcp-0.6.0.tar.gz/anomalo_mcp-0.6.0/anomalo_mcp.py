import datetime
import importlib
import logging
import os
import pathlib
import sys

import fastmcp
from anomalo_api import (
    AnomaloClient,
)
from anomalo_models import (
    Collection,
    CollectionBreakdown,
    ConfiguredCheck,
    TableConfig,
)

import anomalo


logger = logging.getLogger(__name__)


####
# Version — reported to Sentry (as `release`) and the Anomalo API (User-Agent)
####

try:
    from importlib.metadata import PackageNotFoundError
    from importlib.metadata import version as _pkg_version

    MCP_SERVER_VERSION = _pkg_version("anomalo-mcp")
except (PackageNotFoundError, ImportError):  # pragma: no cover
    MCP_SERVER_VERSION = "dev"


####
# Sentry — error monitoring with strict PII controls
#
# Enabled when SENTRY_DSN is set. All PII is stripped before events
# leave the process. See the scrub_event hook below.
####

SENSITIVE_KEYS = {
    "api_key",
    "authorization",
    "password",
    "token",
    "x-anomalo-key",
    "x-anomalo-token",
}


def _scrub_event(event, hint):
    """Strip PII and secrets from every Sentry event before transmission."""
    event.pop("request", None)
    event.pop("user", None)

    def scrub_dict(d):
        if not isinstance(d, dict):
            return d
        return {
            k: "[REDACTED]" if k.lower() in SENSITIVE_KEYS else scrub_dict(v)
            for k, v in d.items()
        }

    if "extra" in event:
        event["extra"] = scrub_dict(event["extra"])
    if "contexts" in event:
        event["contexts"] = scrub_dict(event["contexts"])
    # Scrub breadcrumbs — LoggingIntegration captures INFO logs which may
    # contain SQL snippets from AIDA tool call approvals
    if "breadcrumbs" in event:
        for crumb in event.get("breadcrumbs", {}).get("values", []):
            if "data" in crumb:
                crumb["data"] = scrub_dict(crumb["data"])

    return event


def _init_sentry() -> None:
    """Initialize Sentry if SENTRY_DSN is set. Never crash the server on failure."""
    dsn = os.environ.get("SENTRY_DSN")
    if not dsn:
        return

    try:
        import sentry_sdk
        from sentry_sdk.integrations.logging import LoggingIntegration
    except ImportError:
        logger.warning("SENTRY_DSN is set but sentry-sdk is not installed")
        return

    env = os.environ.get("ANOMALO_ENV", "development")
    try:
        sentry_sdk.init(
            dsn=dsn,
            integrations=[
                LoggingIntegration(
                    level=logging.INFO,
                    event_level=logging.ERROR,
                ),
            ],
            environment=env,
            release=f"anomalo-mcp@{MCP_SERVER_VERSION}",
            traces_sample_rate=float(
                os.environ.get("SENTRY_TRACES_SAMPLE_RATE", "0.1")
            ),
            send_default_pii=False,
            before_send=_scrub_event,
        )
    except Exception:  # noqa: BLE001
        # A bad DSN, incompatible SDK, or network hiccup during init must
        # never prevent the MCP server from starting.
        logger.exception("Failed to initialize Sentry — continuing without it")
        return

    logger.info(
        f"Sentry initialized (env={env}, release=anomalo-mcp@{MCP_SERVER_VERSION})"
    )
    if os.environ.get("SENTRY_VERIFY") == "1":
        # Emit a test event so the operator can confirm Sentry is receiving.
        logger.error(
            "SENTRY_VERIFY=1 — this is a synthetic event to confirm Sentry delivery"
        )


_init_sentry()


DQ_CHECK_RUN_RATE_LIMITER = {}
DQ_CHECK_RUN_RATE_LIMIT = datetime.timedelta(minutes=15)

logger.info(f"Anomalo MCP Server version {MCP_SERVER_VERSION} starting")

EXPERIMENTAL_UNSTRUCTURED_TOOLS = (
    os.environ.get("ANOMALO_EXPERIMENTAL_UNSTRUCTURED_TOOLS", "N").lower() in "1trueyes"
)

client = AnomaloClient(
    headers={
        "User-Agent": f"anomalo/{anomalo.version} (app=anomalo-mcp/{MCP_SERVER_VERSION}, python={sys.version}, fastmcp={fastmcp.__version__})",
    },
)

mcp = fastmcp.FastMCP(name="Anomalo MCP Server")

###
# Organizations
###


@mcp.tool
def get_organizations() -> list[dict[str, str | bool | int]]:
    """Retrieves a list of accessible organizations from the Anomalo deployment, including which organization is currently active for the given API key.
    Schema is `{id: int, name: str, is_active: bool}`.
    Each organization is a tenant within the Anomalo deployment.
    API calls are scoped to the active organization, which is sticky across calls and may be changed with the `set_active_organization` tool.
    """
    active_org = client.get_active_organization_id()
    return [
        {"id": org["id"], "name": org["name"], "is_active": org["id"] == active_org}
        for org in client.get_all_organizations()
    ]


@mcp.tool
def set_active_organization(id: int) -> int:
    """Sets the active organization for API access to the Anomalo deployment. Each organization is a tenant within the Anomalo deployment. API calls are scoped to the active organization, which is sticky across calls. Use the `get_organizations` tool to retrieve a list of accessible organizations."""
    client.set_active_organization_id(id)
    return id


###
# Labels
###


@mcp.tool
def get_labels() -> list[dict[str, str | int]]:
    """Retrieves a list of labels from the active organization in the Anomalo deployment.
    Labels are used to organize tables and checks within the Anomalo deployment.
    Each label has an id which can be used when searching for tables and checks,
    a name, a slug which is a URL-friendly and unique version of the name, and
    a scope which indicates whether the label is for tables or checks or both.
    """
    return [
        {
            "id": label["id"],
            "name": label["name"],
            "scope": label["scope"],
            "slug": label["slug"],
        }
        for label in client.list_labels_for_organization()
    ]


###
# Configured tables
###


@mcp.tool(output_schema=None)
def get_configured_tables(
    label: str | None = None, table_name: str | None = None, table_id: int | None = None
) -> list[TableConfig]:
    """Retrieves a list of configured tables in the active organization.
    Optionally provide a `label` name that filters the returned list of tables to only those with the given label.

    This returns table metadata (name, description, warehouse, monitoring status).
    To see data quality check results, pass/fail status, or detailed analysis,
    use the `ask_aida` tool instead — AIDA provides AI-powered analysis of check
    results and can run SQL queries to investigate issues.
    """
    if table_name:
        if table := client.get_table_information(table_name=table_name):
            return client.get_enriched_configured_tables(table_id=table["id"])
        raise ValueError(f"Table '{table_name}' not found in organization.")

    if table_id:
        return client.get_enriched_configured_tables(table_id=table_id)

    if label:
        label_id = (
            next(
                iter(
                    [
                        l.get("id")
                        for l in client.list_labels_for_organization()
                        if l.get("name", "").lower() == label.lower()
                        or l.get("slug", "").lower() == label.lower()
                    ]
                ),
                None,
            )
            if label
            else None
        )
        if label_id:
            return client.get_enriched_configured_tables(label_id=label_id)
        raise ValueError(f"Label '{label}' not found in organization.")

    raise ValueError("Must provide one of 'label', 'table_name', or 'table_id'.")


###
# Check metadata & execution
###


@mcp.tool(output_schema=None)
def get_checks_for_table(table_id: int) -> list[ConfiguredCheck]:
    """Retrieves a list of data quality checks that are configured for the specified `table_id`.
    Each check includes its check_id, name, description, whether it is active, and its severity level.

    This returns check configuration metadata only — not results.
    To see whether checks are passing or failing, what the issues are, and get
    AI-powered analysis, use the `ask_aida` tool instead.

    Note: use `check_id` when tracking the status of a specific check across tool calls.
    `check_static_id` is a durable identifier set by end users to support cases where they delete and recreate a check and want a stable identifier to reference that check from outside systems.
    """
    return client.get_configured_checks(table_id)


@mcp.tool
def run_data_quality_checks_on_table(
    table_id: int, check_id: int | str | None = None
) -> str:
    """Triggers a data quality check run on the specified `table_id`.
    If `check_id` is provided, only that specific check will be run; otherwise, all configured checks for the table will be run.
    `check_id` may be either a numeric check id or a durable `check_static_id` string.

    This will enqueue a job in Anomalo to run all configured data quality checks for the table.
    The response is the `check_run_id` for tracking purposes.

    To see the results after the run completes, use `ask_aida` — for example:
    "What were the results of the latest check run on this table?"

    Note: This function only triggers the check run; it does not wait for the checks to complete.
    Note: This tool will not start a new check run if there is an existing check run pending.
    """
    if not check_id:
        if last_run_time := DQ_CHECK_RUN_RATE_LIMITER.get(table_id):
            now = datetime.datetime.now()
            if now - last_run_time < DQ_CHECK_RUN_RATE_LIMIT:
                retry_time = last_run_time + DQ_CHECK_RUN_RATE_LIMIT
                raise ValueError(
                    f"Data quality check run for table_id {table_id} was triggered recently at {last_run_time.isoformat()}. Please wait until {retry_time.isoformat()} before triggering another run."
                )

    args = {
        "table_id": table_id,
        "respect_data_freshness_gate": False,
        "force": False,
    }
    if check_id:
        args["check_ids"] = [check_id]

    check_run = client.run_checks(**args)

    if not check_id:
        DQ_CHECK_RUN_RATE_LIMITER[table_id] = datetime.datetime.now()

    return str(check_run["run_checks_job_id"])


###
# Plugins — load optional tool extensions.
#
# plugins/ ships in the wheel and carries customer-facing tools (aida.py).
# dev_plugins/ is only present in source checkouts and carries Anomalo-internal
# tools that bypass AIDA (e.g. direct check result / data profile access). It is
# excluded from the PyPI wheel so external users only see plugins/.
###

_HERE = pathlib.Path(__file__).parent
for _plugins_dir in (_HERE / "plugins", _HERE / "dev_plugins"):
    if not _plugins_dir.is_dir():
        continue
    for _plugin_file in sorted(_plugins_dir.glob("*.py")):
        if _plugin_file.name.startswith("_"):
            continue
        try:
            _mod = importlib.import_module(f"{_plugins_dir.name}.{_plugin_file.stem}")
            if hasattr(_mod, "register"):
                _mod.register(mcp, client)
        except Exception:  # noqa: BLE001
            logger.exception("Failed to load plugin %s", _plugin_file.stem)


###
# Unstructured
###

if EXPERIMENTAL_UNSTRUCTURED_TOOLS:

    @mcp.tool(output_schema=None)
    def get_unstructured_collections() -> list[Collection]:
        """Retrieves a list of unstructured document collections that are being monitored by Anomalo.
        Unstructured collections are sets of unstructured documents that Anomalo has analyzed and enriched with metadata, classification, and quality issues.
        Each collection has an id, name, description, and source type. Source type tells us where the files live - in a cloud object storage bucket or in a column in a data warehouse table.
        The response schema is a list of `Collection` objects, which include the following fields:
        - `id`: The unique identifier for the collection.
        - `name`: The name of the collection.
        - `description`: A description of the collection.
        - `organization_id`: The ID of the Anomalo organization that contains the collection.
        - `source_type`: The type of source for the collection (e.g., "s3", "data_warehouse").
        - `bucket_name`: The name of the bucket where the collection's documents are stored, if applicable.
        - `path_prefix`: The prefix path within the bucket where the collection's documents are stored, if applicable.
        - `mime_types`: A list of MIME types that the collection is configured to process.
        - `ai_model`: The AI model used for analyzing the documents in the collection.
        """
        return client.get_collections()

    @mcp.tool(output_schema=None)
    def get_unstructured_collection_results(
        organization_id: str, collection_id: str
    ) -> CollectionBreakdown | None:
        """Retrieves the detailed metadata of a document collection based on the last analysis run.
        An Unstructured collection is a set of unstructured documents that Anomalo has analyzed and enriched with metadata, classification, and quality issues.
        Each collection has a name, a description, and generated metadata based on Anomalo's analysis of the content.
        The response schema is a `CollectionBreakdown` object, which includes the following fields:
        - `id`: The unique identifier for the collection.
        - `name`: The name of the collection.
        - `description`: A description of the collection.
        - `organization_id`: The ID of the Anomalo organization that contains the collection.
        - `source_type`: The type of source for the collection (e.g., "s3", "data_warehouse").
        - `bucket_name`: The name of the bucket where the collection's documents are stored, if applicable.
        - `path_prefix`: The prefix path within the bucket where the collection's documents are stored, if applicable.
        - `mime_types`: A list of MIME types that the collection is configured to process.
        - `ai_model`: The AI model used for analyzing the documents in the collection.
        - `last_check_run_id`: The ID of the last check run (aka content analysis run) for the collection.
        - `last_check_run_completed_at`: The timestamp when the last check run (aka content analysis run) was completed.
        - `document_count`: The number of documents in the collection.
        - `summary`: A generated summary of the documents in the collection.
        - `score`: A score representing the quality of the documents in the collection, from 0 to 10.
        - `issues`: A dictionary of issues found in the documents, with issue names as keys and counts as values.
        - `metadata`: A dictionary of metadata categories (tone, sentiment, language, theme, writing_level, score) with their respective entries and counts.
        """
        collection = client.get_collection(organization_id, collection_id)
        if not collection:
            raise ValueError(
                f"Collection with ID {collection_id} not found in organization {organization_id}."
            )
        return client.get_collection_breakdown(collection)


###
# Common prompts
###


@mcp.prompt
def find_tables_with_label(label: str, as_json: bool) -> str:
    """Generates a user message asking for a list of tables with a specific label.
    The label can be a name or slug.
    Returns a list of table names with metadata.
    If `as_json` is True, the response will be formatted as a JSON string; otherwise, it will be plain text."""

    prompt = f"Find all tables with the label '{label}' in the Anomalo deployment using the `get_configured_tables` tool. "

    if as_json:
        prompt += """
Return the response as a JSON-encoded dictionary with the following schema:

```{id: {id: int, name: str, full_name: str, description: str, monitored: bool, url: str, warehouse_id: int, warehouse_name: str, warehouse_type: str}, ...}```.
"""
    else:
        prompt += """
Format your response as text using this format:

```{table_1.warehouse_name}.{table_1.full_name}\n{table_1.url}\n{table_1.description}\n\n{table_2.warehouse_name}.{table_2.full_name}\n{table_2.url}\n{table_2.description}

...
```"""

    return prompt


def main():
    """Entry point for console_scripts (uvx/pip install)."""
    mcp.run()


if __name__ == "__main__":  # pragma: no cover
    main()
