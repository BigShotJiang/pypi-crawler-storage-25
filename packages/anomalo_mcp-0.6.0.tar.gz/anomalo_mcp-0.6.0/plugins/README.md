# AIDA MCP Plugin

The AIDA MCP plugin exposes Anomalo's AI Data Analyst (AIDA) as a callable tool within MCP clients like Claude Desktop, Cursor, and Gemini CLI. It allows users to ask natural language questions about monitored tables, drives SQL query approval through MCP elicitation, and optionally returns query results as downloadable CSV files.

The plugin ships with `anomalo-mcp` — if your Anomalo deployment has AIDA enabled, the AIDA tools (`ask_aida`, `list_aida_conversations`, etc.) are registered automatically.

---

## Setup

### Prerequisites

- An MCP-capable client (Claude Desktop, Cursor, Gemini CLI, etc.)
- `uv` (or `pipx`)
- Access to an Anomalo instance with AIDA enabled and a valid API token

### Claude Desktop Configuration

Add the following to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "anomalo": {
      "command": "uvx",
      "args": ["anomalo-mcp"],
      "env": {
        "ANOMALO_INSTANCE_HOST": "YOUR-INSTANCE.anomalo.com",
        "ANOMALO_API_SECRET_TOKEN": "your-api-key-here"
      }
    }
  }
}
```

---

## Configuration

All configuration is via environment variables. Set these in the Claude Desktop config `env` block or your shell.

| Variable | Default | Description |
|---|---|---|
| `ANOMALO_INSTANCE_HOST` | *(required)* | Anomalo instance hostname (e.g. `staging-5fa9.anomalo.com`) |
| `ANOMALO_API_SECRET_TOKEN` | *(required)* | API token for the Anomalo instance |
| `AIDA_FETCH_FILES` | `false` | Whether to automatically download CSV query results to the local machine |

### `AIDA_FETCH_FILES`

Controls whether AIDA query results (CSV files) are fetched from S3 and returned inline to Claude.

| Value | Behavior |
|---|---|
| `false` (default) | Guardrail on — file metadata only returned, no row-level data downloaded |
| `true` | Guardrail off — CSV content fetched, saved to `/tmp/aida_<uuid>.csv`, and returned inline |

**When `false`:** Claude receives file name and size only. Row-level data never leaves the Anomalo/S3 environment.

**When `true`:** CSV content is fetched to the local machine and passed through the Claude API context window. Use with caution on instances with sensitive or customer data — see [Security Considerations](#security-considerations) below.

---

## Available Tools

### `ask_aida`

Ask AIDA a natural language question about a specific table.

| Parameter | Type | Default | Description |
|---|---|---|---|
| `table_id` | int | *(required)* | Anomalo table ID to query |
| `question` | str | *(required)* | Natural language question |
| `auto_approve` | bool | `False` | Approve every SQL query AIDA wants to run, with no prompts |
| `fetch_files` | bool | `AIDA_FETCH_FILES` | Override the env var default for this call |
| `conversation_id` | int | `None` | Continue an existing AIDA conversation by id. Omit to start fresh. |
| `include_messages` | bool | `False` | Include the full AIDA conversation transcript in the response. Off by default to keep output focused. |

**Approval flow:**

When `auto_approve=False` (default), the server drives approval via **MCP elicitation** — Claude Desktop / Cursor / etc. renders a native confirmation dialog for each SQL query. Three outcomes:

- **Approve** / **Approve all** — server sends `approved` / `approved_all` to the Anomalo API and continues polling.
- **Decline** — server sends `denied`, lets AIDA react (usually it explains it couldn't proceed).
- **Cancel** — `ask_aida` returns immediately with `status="cancelled"`.

If the MCP client does **not** support elicitation, the server falls back to returning `status="awaiting_approval"` with `pending_tool_calls`. The LLM can then call `approve_aida_query` to approve via a separate tool call (older flow — kept for compatibility).

**Response includes:**
- `status` — `complete`, `awaiting_approval`, `cancelled`, or `timeout`
- `answer` — AIDA's analysis in markdown
- `files` — file metadata (or full content if `fetch_files=True`)
- `approved_queries` — SQL queries that ran (auto-approve or elicitation paths)
- `pending_tool_calls` — only present on the `awaiting_approval` fallback
- `messages` — full conversation history

### `approve_aida_query`

Manually approve or deny a pending AIDA SQL query. Only needed as a fallback for clients that don't support MCP elicitation.

| Parameter | Type | Default | Description |
|---|---|---|---|
| `tool_call_id` | int | *(required)* | ID from `pending_tool_calls` in `ask_aida` response |
| `action` | str | `approved` | One of: `approved`, `denied`, `approved_all` |
| `conversation_id` | int | `None` | If provided, polls for AIDA's continued response after approval |

### `list_aida_conversations`

List recent AIDA conversations, optionally filtered to a specific table.

| Parameter | Type | Default | Description |
|---|---|---|---|
| `table_id` | int | `None` | Filter to conversations for a specific table |
| `hidden` | bool | `False` | Include hidden conversations |
| `limit` | int | `20` | Max number of conversations to return |

---

## Logging

The plugin logs to `/tmp/aida_mcp.log`. To tail in real time:

```bash
tail -f /tmp/aida_mcp.log
```

Log output includes poll attempts, tool call approvals, file fetch status, and any errors.

---

## Security Considerations

### API Token Attribution

All Anomalo API calls are made using the configured API token, not individual user credentials. Audit logs in Anomalo will show the API token identity, not the name of the person running the query.

### Row-Level Data

When `AIDA_FETCH_FILES=true`, query results flow through:
1. Anomalo → S3 presigned URL
2. Local Python process (`_fetch_files`)
3. MCP response payload → Claude Desktop
4. Anthropic API (Claude's context window)
5. Local disk (`/tmp/aida_<uuid>.csv`)

Keep `AIDA_FETCH_FILES=false` (the default) on any instance containing sensitive, PII, or customer data until a formal data handling review has been completed.

### Presigned URL Expiry

S3 presigned URLs expire after 15 minutes. The local `/tmp/` copy (when `fetch_files=True`) persists until the OS clears it.

---

## Polling Configuration

| Constant | Default | Description |
|---|---|---|
| `POLL_INTERVAL_SECONDS` | `3` | Seconds between poll attempts |
| `POLL_MAX_ATTEMPTS` | `100` | Max polls before timeout (~5 minutes) |

---

## Known Limitations

- **API token attribution** — queries appear in audit logs as the service token, not a named user
- **Client timeout** — very long-running queries (>4 min) may time out at the MCP client layer (Claude Desktop, Cursor, etc.) before the MCP returns. For decomposable analyses, use `ask_aida_chunked`.
