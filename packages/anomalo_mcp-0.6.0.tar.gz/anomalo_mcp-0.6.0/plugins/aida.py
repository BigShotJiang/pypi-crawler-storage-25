import asyncio
import logging
import logging.handlers
import os
import time
from enum import StrEnum
from typing import Any, Dict, List

import requests as _requests
from fastmcp import Context
from fastmcp.server.elicitation import AcceptedElicitation, DeclinedElicitation


FETCH_FILES_DEFAULT: bool = os.getenv("AIDA_FETCH_FILES", "false").lower() == "true"

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
try:
    _fh = logging.handlers.RotatingFileHandler(
        "/tmp/aida_mcp.log", maxBytes=5 * 1024 * 1024, backupCount=2
    )
    _fh.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    logger.addHandler(_fh)
except OSError:
    pass  # /tmp not writable — file logging unavailable, console logging still active

# Default polling configuration for AIDA async responses
POLL_INTERVAL_SECONDS = 3
POLL_MAX_ATTEMPTS = 100  # 5 minutes at 3s intervals


####
# Models
####


class Conversation:
    id: int
    title: str | None
    agent_type: str
    created: str | None
    metadata: Dict[str, Any]
    latest_turn_task_id: str | None

    def __init__(self, data: Dict[str, Any]):
        self.id = data["id"]
        self.title = data.get("title")
        self.agent_type = data.get("agent_type", "ask_a_table")
        self.created = data.get("created")
        self.metadata = data.get("metadata", {})
        self.latest_turn_task_id = data.get("latest_turn_task_id")


class Message:
    id: int
    role: str
    content: str | None
    model: str | None
    created: str | None
    task_id: str | None
    tool_calls: List[Dict[str, Any]]
    files: List[Dict[str, Any]]

    def __init__(self, data: Dict[str, Any]):
        self.id = data["id"]
        self.role = data.get("role", "")
        self.content = data.get("content")
        self.model = data.get("model")
        self.created = data.get("created")
        self.task_id = data.get("task_id")
        self.tool_calls = data.get("tool_calls", data.get("tool_call_models", []))
        self.files = data.get("files", [])

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "role": self.role,
            "content": self.content,
            "model": self.model,
            "created": self.created,
            "tool_calls": self.tool_calls,
            "files": self.files,
        }


####
# Client methods
#
# Note on input validation: table_id, question, tool_call_id, and action are
# validated server-side by the Anomalo API (Django serializers, model lookups,
# and permission checks). The plugin does not duplicate this validation — invalid
# inputs will surface as API errors returned to the caller.
####


def _create_conversation(client, table_id: int) -> Conversation:
    logger.info(f"Creating AIDA conversation for table_id={table_id}")
    resp = client._api_call(
        "aida/conversations/",
        method="POST",
        agent_type="ask_a_table",
        metadata={"table_id": table_id},
    )
    conv = Conversation(resp)
    logger.info(f"Created conversation_id={conv.id}")
    return conv


def _send_message(client, conversation_id: int, content: str) -> Dict[str, Any]:
    logger.info(
        f"Sending message to conversation_id={conversation_id} ({len(content)} chars)"
    )
    return client._api_call(
        f"aida/conversations/{conversation_id}/messages/",
        method="POST",
        content=content,
    )


def _get_messages(client, conversation_id: int) -> List[Message]:
    resp = client._api_call(
        f"aida/conversations/{conversation_id}/messages/",
    )
    results = resp.get("results", []) if isinstance(resp, dict) else resp
    return [Message(m) for m in results]


def _list_conversations(
    client,
    table_id: int | None = None,
    hidden: bool = False,
    limit: int = 20,
) -> List[Conversation]:
    params: Dict[str, Any] = {"hidden": str(hidden).lower(), "limit": limit}
    if table_id:
        params["table_id"] = table_id
    resp = client._api_call("aida/conversations/", **params)
    results = resp.get("results", []) if isinstance(resp, dict) else resp
    return [Conversation(c) for c in results]


def _approve_tool_call(
    client, tool_call_id: int, approval_state: str
) -> Dict[str, Any]:
    logger.info(f"Tool call {tool_call_id}: {approval_state}")
    return client._api_call(
        f"aida/tool_calls/{tool_call_id}/",
        method="PATCH",
        approval_state=approval_state,
    )


def _get_pending_tool_calls(
    assistant_messages: List[Message],
) -> List[Dict[str, Any]]:
    """Extract pending tool calls from assistant messages."""
    return [
        tc
        for m in assistant_messages
        for tc in m.tool_calls
        if tc.get("approval_state") == "pending"
    ]


# Preamble prefixes AIDA commonly uses before running tools. Match is
# case-insensitive via .lower() in _looks_like_preamble. We accept a few
# adverb leads ("Now ", "First ", "Next ") since AIDA threads those onto
# continuation preambles.
_PREAMBLE_LEAD_WORDS = (
    "now ",
    "now, ",
    "first ",
    "first, ",
    "next ",
    "next, ",
    "then ",
    "then, ",
    "",
)
_PREAMBLE_CORES = (
    "i'll ",
    "i will ",
    "let me ",
    "let's ",
    "i'm going to ",
    "i am going to ",
)


def _looks_like_preamble(text: str) -> bool:
    """True if `text` reads like a stalling/transitional sentence before the real answer.

    Matches things like "I'll check...", "Let me ...", "Now let me check one
    successful check for context:". We cast a wide net via adverb-lead
    prefixes plus a trailing-colon heuristic for short strings.
    """
    lowered = text.lower()
    for lead in _PREAMBLE_LEAD_WORDS:
        for core in _PREAMBLE_CORES:
            if lowered.startswith(lead + core):
                return True
    # Short sentence ending with ":" is almost always a lead-in to more content
    # that got cut off (e.g. "Now let me check one successful check for context:")
    if len(text) < 120 and text.rstrip().endswith(":"):
        return True
    return False


def _detect_truncated_answer(
    answer: str | None,
    assistant_messages: List[Message],
) -> str | None:
    """Detect when AIDA's answer looks truncated — it ran tools but only
    returned a preamble without the actual analysis. Returns a warning or None.
    """
    has_finished_tools = any(
        tc.get("execution_state") == "finished"
        for m in assistant_messages
        for tc in m.tool_calls
    )
    if not has_finished_tools:
        return None

    # Null answer after running tools = backend definitely truncated
    if not answer:
        logger.warning("AIDA answer is null despite tools running to completion")
        return (
            "Warning: AIDA's response is empty despite running tools successfully. "
            "The backend likely hit a processing time limit. Start a fresh "
            "conversation (do not reuse this conversation_id — it will keep "
            "returning the same partial result) and try a simpler question."
        )

    answer_stripped = answer.strip()
    if len(answer_stripped) < 300 and _looks_like_preamble(answer_stripped):
        logger.warning(
            f"AIDA answer appears truncated — tools ran but answer is a "
            f"short preamble ({len(answer_stripped)} chars)"
        )
        return (
            "Warning: AIDA's response appears truncated — it ran tools but "
            "returned only a brief preamble without the full analysis. The "
            "backend likely hit a processing time limit. Start a fresh "
            "conversation (do not reuse this conversation_id — it will keep "
            "returning the same partial result) and try a simpler question."
        )

    return None


def _has_running_tool_calls(assistant_messages: List[Message]) -> bool:
    """Check if any tool calls are still executing."""
    return any(
        tc.get("execution_state") == "running"
        for m in assistant_messages
        for tc in m.tool_calls
    )


####
# Elicitation — spec-compliant approval flow (MCP 2025-06-18)
####


class SqlDecision(StrEnum):
    """User's decision when AIDA requests approval to run a SQL query."""

    approve = "approve"
    approve_all = "approve_all"
    deny = "deny"


class ElicitationUnsupported(Exception):
    """Raised internally to signal the client does not support elicitation."""


async def _handle_pending_via_elicitation(
    ctx: Context,
    client,
    pending_tool_calls: List[Dict[str, Any]],
    approved_queries: List[Dict[str, Any]],
    attempt: int,
) -> tuple[str, bool]:
    """Drive user approval for each pending tool call via MCP elicitation.

    Returns (last_action, cancelled) where:
    - last_action is "approve", "approve_all", or "deny"
    - cancelled is True if the user cancelled the dialog (polling should stop)
    """
    last_action = "deny"
    for tc in pending_tool_calls:
        tc_id = tc.get("id")
        sql = tc.get("arguments", {}).get("sql", "N/A")
        logger.info(
            f"Poll {attempt + 1}: eliciting approval for tool_call_id={tc_id} "
            f"({tc.get('tool_name')})"
        )
        decision = await _elicit_sql_approval(ctx, tc)
        if decision is None:
            logger.info(f"Poll {attempt + 1}: user cancelled elicitation")
            return last_action, True

        approval_state = {
            SqlDecision.approve: "approved",
            SqlDecision.approve_all: "approved_all",
            SqlDecision.deny: "denied",
        }[decision]
        _approve_tool_call(client, tc_id, approval_state)
        last_action = decision.value
        if decision in (SqlDecision.approve, SqlDecision.approve_all):
            approved_queries.append(
                {
                    "tool_call_id": tc_id,
                    "tool_name": tc.get("tool_name"),
                    "sql": sql,
                }
            )
        if decision == SqlDecision.approve_all:
            # Remaining pending calls in this batch are covered server-side by
            # approved_all; don't keep prompting the user for them.
            break
    return last_action, False


async def _elicit_sql_approval(
    ctx: Context, tool_call: Dict[str, Any]
) -> SqlDecision | None:
    """Ask the user to approve or deny a SQL query via MCP elicitation.

    Returns the decision, or None if the user cancelled the dialog.
    Raises ElicitationUnsupported if the client cannot handle elicit requests.
    """
    sql = tool_call.get("arguments", {}).get("sql", "(no SQL provided)")
    tool_name = tool_call.get("tool_name", "unknown")
    prompt = f"AIDA wants to run {tool_name}.\n\nSQL:\n{sql}\n\nApprove this query?"
    try:
        result = await ctx.elicit(prompt, response_type=SqlDecision)
    except Exception as exc:  # noqa: BLE001
        logger.warning(f"ctx.elicit failed — treating client as unsupported: {exc}")
        raise ElicitationUnsupported() from exc

    if isinstance(result, AcceptedElicitation):
        return result.data
    if isinstance(result, DeclinedElicitation):
        return SqlDecision.deny
    return None  # CancelledElicitation


####
# File fetching
####


def _fetch_files(files: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Fetch CSV files from presigned S3 URLs and save locally.

    For each file with a download_url:
    - Fetches the content inline so Claude can read and interpret it
    - Saves to /tmp/aida_<uuid>.<ext> for persistent local access
    - Adds 'content' and 'local_path' keys to the file dict

    Non-CSV files are left as-is with the URL intact.
    """
    enriched = []
    for f in files:
        url = f.get("download_url")
        content_type = f.get("content_type", "")
        uuid = f.get("uuid", "unknown")

        if url and "text/csv" in content_type:
            try:
                logger.info(
                    f"Fetching file {f.get('filename')} ({f.get('size_in_bytes')} bytes)"
                )
                resp = _requests.get(url, timeout=30)
                resp.raise_for_status()
                csv_content = resp.text

                ext = f.get("filename", "results.csv").rsplit(".", 1)[-1]
                local_path = f"/tmp/aida_{uuid}.{ext}"
                with open(local_path, "w") as fh:
                    fh.write(csv_content)
                logger.info(f"Saved to {local_path}")

                enriched_file = {**f}
                enriched_file["content"] = csv_content
                enriched_file["local_path"] = local_path
                enriched_file.pop("download_url", None)
                enriched.append(enriched_file)

            except Exception:  # pragma: no cover  # noqa: BLE001
                # Log at ERROR so Sentry captures the stack trace.
                logger.exception(f"Failed to fetch file {uuid}")
                enriched.append(f)
        else:
            enriched.append(f)

    return enriched


def _apply_file_guardrail(
    raw_files: List[Dict[str, Any]],
    fetch_files: bool,
) -> List[Dict[str, Any]]:
    """Apply the fetch_files guardrail to a list of raw file dicts.

    When fetch_files=True, downloads CSV content via _fetch_files.
    When fetch_files=False, returns metadata only (name, size, type) with
    download_url stripped to prevent presigned URL leakage.
    """
    if not raw_files:
        return []

    if fetch_files:
        result = _fetch_files(raw_files)
        if result:
            logger.info(f"  {len(result)} file(s) fetched and ready")
        return result

    result = [
        {
            "filename": f.get("filename"),
            "content_type": f.get("content_type"),
            "size_in_bytes": f.get("size_in_bytes"),
            "note": "File not downloaded. Set fetch_files=True to download row-level data.",
        }
        for f in raw_files
    ]
    if result:
        logger.info(f"  {len(result)} file(s) available (metadata only)")
    return result


####
# Result building
####


def _build_complete_result(
    conversation_id: int,
    question: str,
    answer: str | None,
    messages: List[Message],
    assistant_messages: List[Message],
    approved_queries: List[Dict[str, Any]],
    fetch_files: bool = False,
    include_messages: bool = False,
) -> Dict[str, Any]:
    """Build the final 'complete' response dict.

    When `include_messages=False` (default), the verbose `messages` field
    is omitted from the response. The full conversation history is still
    retrievable via `list_aida_conversations` + direct API. Omitting it
    keeps the tool output focused on the answer so the LLM doesn't narrate
    around intermediate tool-call messages.
    """
    raw_files = [f for m in assistant_messages for f in m.files]
    all_files = _apply_file_guardrail(raw_files, fetch_files)
    truncation_warning = _detect_truncated_answer(answer, assistant_messages)

    # When the answer is truncated (e.g. a Celery soft-time-limit kill mid-turn
    # leaves only a preamble), surface "truncated" rather than "complete" so
    # callers can branch on status instead of parsing the warning string.
    status = "truncated" if truncation_warning else "complete"

    result: Dict[str, Any] = {
        "conversation_id": conversation_id,
        "question": question,
        "status": status,
        "answer": answer,
    }
    if include_messages:
        result["messages"] = [m.to_dict() for m in messages]
    if truncation_warning:
        result["warning"] = truncation_warning
    if all_files:
        result["files"] = all_files
    if approved_queries:
        result["approved_queries"] = approved_queries
    return result


####
# Polling
####


def _awaiting_approval_result(
    conversation_id: int,
    question: str,
    latest_assistant_content: str | None,
    pending_tool_calls: List[Dict[str, Any]],
    messages: List[Message],
    include_messages: bool = False,
) -> Dict[str, Any]:
    """Build the 'awaiting_approval' fallback result for clients without elicitation."""
    result: Dict[str, Any] = {
        "conversation_id": conversation_id,
        "question": question,
        "status": "awaiting_approval",
        "answer": latest_assistant_content,
        "pending_tool_calls": pending_tool_calls,
    }
    if include_messages:
        result["messages"] = [m.to_dict() for m in messages]
    return result


def _auto_approve_tool_calls(
    client,
    pending_tool_calls: List[Dict[str, Any]],
    approved_queries: List[Dict[str, Any]],
    attempt: int,
) -> None:
    """Approve all pending tool calls and record them for the caller."""
    for tc in pending_tool_calls:
        tc_id = tc.get("id")
        sql = tc.get("arguments", {}).get("sql", "N/A")
        # Log metadata at INFO (visible to Sentry breadcrumbs) and the
        # full SQL at DEBUG so it stays in the local log file only.
        logger.info(
            f"Poll {attempt + 1}: auto-approving tool_call_id={tc_id} "
            f"({tc.get('tool_name')}) sql_len={len(sql)}"
        )
        logger.debug(f"  sql={sql[:200]}")
        _approve_tool_call(client, tc_id, "approved")
        approved_queries.append(
            {
                "tool_call_id": tc_id,
                "tool_name": tc.get("tool_name"),
                "sql": sql,
            }
        )


async def _ask(
    client,
    table_id: int,
    question: str,
    auto_approve: bool = False,
    fetch_files: bool = FETCH_FILES_DEFAULT,
    poll_interval: float = POLL_INTERVAL_SECONDS,
    max_attempts: int = POLL_MAX_ATTEMPTS,
    ctx: Context | None = None,
    conversation_id: int | None = None,
    include_messages: bool = False,
) -> Dict[str, Any]:
    """Create a conversation (or continue an existing one), send a question, and poll until AIDA responds.

    If `conversation_id` is provided, the question is posted to that existing
    conversation — AIDA sees the full prior context. If omitted, a fresh
    conversation is created.

    When `include_messages=False` (default), the verbose conversation
    transcript is omitted from the returned response — only the final
    answer (and pending/approved tool calls) is surfaced. Set True if the
    caller wants the full transcript.

    Approval flow priority:
    1. `auto_approve=True` — approve everything silently, keep polling.
    2. `ctx` is provided and client supports MCP elicitation — prompt the
       user for each pending SQL query via `ctx.elicit()` and act on the
       response (approve / approve_all / deny / cancel).
    3. Fallback — return `status="awaiting_approval"` with pending_tool_calls
       so the LLM / caller can drive approval via `approve_aida_query`.
    """
    if conversation_id is None:
        conversation = _create_conversation(client, table_id)
        active_conversation_id = conversation.id
    else:
        logger.info(f"Continuing existing conversation_id={conversation_id}")
        active_conversation_id = conversation_id

    # Track the message count at the start of this turn so we only consider
    # messages from this turn when detecting completion. Otherwise a threaded
    # call would see prior assistant messages and declare "complete" instantly.
    # We also track the prior assistant-message count specifically, because
    # completion must require a *new* assistant turn to have started — without
    # that, a previously-truncated conversation would return its stale assistant
    # message as "complete" for every follow-up question.
    prior_messages = (
        _get_messages(client, active_conversation_id) if conversation_id else []
    )
    prior_message_count = len(prior_messages)
    prior_assistant_count = sum(1 for m in prior_messages if m.role == "assistant")

    _send_message(client, active_conversation_id, question)
    approved_queries: List[Dict[str, Any]] = []
    last_message_count = prior_message_count
    stable_polls = 0
    approve_all_remaining = False

    for attempt in range(max_attempts):
        await asyncio.sleep(poll_interval)
        messages = _get_messages(client, active_conversation_id)

        assistant_messages = [m for m in messages if m.role == "assistant"]
        if not assistant_messages:
            logger.debug(
                f"Poll {attempt + 1}/{max_attempts}: no assistant response yet"
            )
            continue

        latest_assistant = assistant_messages[-1]
        pending_tool_calls = _get_pending_tool_calls(assistant_messages)

        current_message_count = len(messages)
        if current_message_count != last_message_count:
            stable_polls = 0
            last_message_count = current_message_count
        else:
            stable_polls += 1

        if pending_tool_calls:
            if auto_approve or approve_all_remaining:
                _auto_approve_tool_calls(
                    client, pending_tool_calls, approved_queries, attempt
                )
                continue

            if ctx is not None:
                try:
                    handled, cancelled = await _handle_pending_via_elicitation(
                        ctx, client, pending_tool_calls, approved_queries, attempt
                    )
                except ElicitationUnsupported:
                    logger.info("Falling back to awaiting_approval flow")
                    return _awaiting_approval_result(
                        active_conversation_id,
                        question,
                        latest_assistant.content,
                        pending_tool_calls,
                        messages,
                        include_messages=include_messages,
                    )

                if cancelled:
                    cancelled_result: Dict[str, Any] = {
                        "conversation_id": active_conversation_id,
                        "question": question,
                        "status": "cancelled",
                        "answer": latest_assistant.content,
                    }
                    if include_messages:
                        cancelled_result["messages"] = [m.to_dict() for m in messages]
                    return cancelled_result
                if handled == "approve_all":
                    approve_all_remaining = True
                continue

            tool_names = [tc.get("tool_name") for tc in pending_tool_calls]
            logger.info(
                f"Poll {attempt + 1}: AIDA paused for approval — "
                f"conversation_id={active_conversation_id} pending_tools={tool_names}"
            )
            return _awaiting_approval_result(
                active_conversation_id,
                question,
                latest_assistant.content,
                pending_tool_calls,
                messages,
                include_messages=include_messages,
            )

        if not latest_assistant.task_id:
            if _has_running_tool_calls(assistant_messages):
                logger.debug(
                    f"Poll {attempt + 1}: tool call still executing — waiting for results"
                )
                stable_polls = 0
                continue

            # Celery's soft_time_limit on complete_agent_turn clears task_id
            # via a finally block even when the turn was killed mid-execution.
            # Without this guard, polling would read the stale prior-turn
            # assistant message and declare completion before AIDA has even
            # started responding to the current question.
            if len(assistant_messages) <= prior_assistant_count:
                logger.debug(
                    f"Poll {attempt + 1}: no new assistant message yet "
                    f"(have {len(assistant_messages)}, need > {prior_assistant_count}) "
                    f"— still waiting for AIDA to start responding"
                )
                stable_polls = 0
                continue

            # AIDA writes intermediate messages with null/empty content between
            # tool calls and the final synthesis. Don't declare complete
            # until we have actual content — the synthesis is coming next.
            if not latest_assistant.content:
                logger.debug(
                    f"Poll {attempt + 1}: latest message has null content — "
                    f"waiting for AIDA to write synthesis"
                )
                stable_polls = 0
                continue

            if stable_polls < 2:
                logger.debug(
                    f"Poll {attempt + 1}: assistant has no task_id, "
                    f"stable_polls={stable_polls}/2 — confirming completion"
                )
                continue

            answer_len = len(latest_assistant.content or "")
            # Log length at INFO (safe to send to Sentry as breadcrumb) and
            # the preview at DEBUG to keep warehouse content out of breadcrumbs.
            logger.info(
                f"Poll {attempt + 1}: AIDA complete — "
                f"conversation_id={active_conversation_id} answer_len={answer_len}"
            )
            logger.debug(f"  answer_preview={(latest_assistant.content or '')[:100]!r}")
            return _build_complete_result(
                active_conversation_id,
                question,
                latest_assistant.content,
                messages,
                assistant_messages,
                approved_queries,
                fetch_files=fetch_files,
                include_messages=include_messages,
            )

        logger.debug(
            f"Poll {attempt + 1}/{max_attempts}: AIDA still working "
            f"(task_id={latest_assistant.task_id})"
        )

    logger.warning(
        f"AIDA timed out after {max_attempts} polls — conversation_id={active_conversation_id}"
    )
    timeout_result: Dict[str, Any] = {
        "conversation_id": active_conversation_id,
        "question": question,
        "status": "timeout",
        "answer": None,
    }
    if include_messages:
        timeout_result["messages"] = [
            m.to_dict() for m in _get_messages(client, active_conversation_id)
        ]
    return timeout_result


def _poll_for_response(
    client,
    conversation_id: int,
    fetch_files: bool = FETCH_FILES_DEFAULT,
    include_messages: bool = False,
) -> dict | None:
    """Poll for AIDA's continued response after a tool call approval.

    Applies the same fetch_files guardrail as _ask — presigned URLs are
    stripped when fetch_files=False to prevent accidental data leakage.
    When `include_messages=False` (default), the verbose transcript is
    omitted to keep the LLM-facing response focused on the answer.
    """
    logger.info(f"Polling for continued response — conversation_id={conversation_id}")
    last_message_count = 0
    stable_polls = 0

    for attempt in range(POLL_MAX_ATTEMPTS):
        time.sleep(POLL_INTERVAL_SECONDS)
        messages = _get_messages(client, conversation_id)
        assistant_messages = [m for m in messages if m.role == "assistant"]

        if not assistant_messages:
            continue

        current_message_count = len(messages)
        if current_message_count != last_message_count:
            stable_polls = 0
            last_message_count = current_message_count
        else:
            stable_polls += 1

        latest = assistant_messages[-1]
        pending = _get_pending_tool_calls(assistant_messages)

        if pending:
            logger.info(f"Poll {attempt + 1}: AIDA paused again for approval")
            pending_result: Dict[str, Any] = {
                "conversation_id": conversation_id,
                "status": "awaiting_approval",
                "answer": latest.content,
                "pending_tool_calls": pending,
            }
            if include_messages:
                pending_result["messages"] = [m.to_dict() for m in messages]
            return pending_result

        if not latest.task_id:
            if _has_running_tool_calls(assistant_messages):
                logger.debug(f"Poll {attempt + 1}: tool call still executing — waiting")
                stable_polls = 0
                continue

            if not latest.content:
                logger.debug(
                    f"Poll {attempt + 1}: latest message has null content — "
                    f"waiting for synthesis"
                )
                stable_polls = 0
                continue

            if stable_polls < 2:
                logger.debug(
                    f"Poll {attempt + 1}: confirming completion "
                    f"(stable_polls={stable_polls}/2)"
                )
                continue

            logger.info(f"Poll {attempt + 1}: AIDA complete after approval")
            raw_files = [f for m in assistant_messages for f in m.files]
            all_files = _apply_file_guardrail(raw_files, fetch_files)
            truncation_warning = _detect_truncated_answer(
                latest.content, assistant_messages
            )
            status = "truncated" if truncation_warning else "complete"

            result: Dict[str, Any] = {
                "conversation_id": conversation_id,
                "status": status,
                "answer": latest.content,
            }
            if include_messages:
                result["messages"] = [m.to_dict() for m in messages]
            if truncation_warning:
                result["warning"] = truncation_warning
            if all_files:
                result["files"] = all_files
            return result

        logger.debug(f"Poll {attempt + 1}: still working after approval")

    logger.warning(
        f"Polling timed out after approval — conversation_id={conversation_id}"
    )
    return None


####
# Chunked questions — parallel AIDA conversations for decomposable queries
####


MAX_CHUNKS = 20
MAX_CONCURRENT_CHUNKS = 5


def _validate_chunks(chunks: List[Dict[str, Any]]) -> List[Dict[str, str]]:
    """Return a normalized list of {label, question} dicts, or raise ValueError.

    Rejects empty/oversized batches and any chunk missing a `label` or `question`
    so the LLM gets an immediate, actionable error rather than a partial run.
    """
    if not chunks:
        raise ValueError("`chunks` must not be empty.")
    if len(chunks) > MAX_CHUNKS:
        raise ValueError(
            f"`chunks` has {len(chunks)} entries — capped at {MAX_CHUNKS} to "
            f"avoid saturating the AIDA backend."
        )
    normalized: List[Dict[str, str]] = []
    for i, chunk in enumerate(chunks):
        if not isinstance(chunk, dict):
            raise ValueError(f"chunks[{i}] must be a dict with `label` and `question`.")
        label = chunk.get("label")
        question = chunk.get("question")
        if not label or not isinstance(label, str):
            raise ValueError(f"chunks[{i}] missing required `label` (string).")
        if not question or not isinstance(question, str):
            raise ValueError(f"chunks[{i}] missing required `question` (string).")
        normalized.append({"label": label, "question": question})
    return normalized


async def _ask_one_chunk(
    client,
    semaphore: asyncio.Semaphore,
    table_id: int,
    chunk: Dict[str, str],
    fetch_files: bool,
) -> Dict[str, Any]:
    """Fire a single AIDA conversation for one chunk, with concurrency capped
    via the shared semaphore. Always returns a dict — individual chunk failures
    are captured as `status="error"` so the caller can report partial results.
    """
    async with semaphore:
        try:
            result = await _ask(
                client,
                table_id=table_id,
                question=chunk["question"],
                auto_approve=True,
                fetch_files=fetch_files,
                ctx=None,
                conversation_id=None,
                include_messages=False,
            )
        except Exception as exc:  # noqa: BLE001
            logger.exception(f"Chunked ask failed for label={chunk['label']!r}")
            return {
                "label": chunk["label"],
                "question": chunk["question"],
                "status": "error",
                "answer": None,
                "conversation_id": None,
                "warning": f"Chunk raised an exception: {exc}",
            }

    return {
        "label": chunk["label"],
        "question": chunk["question"],
        "status": result.get("status"),
        "answer": result.get("answer"),
        "conversation_id": result.get("conversation_id"),
        **({"warning": result["warning"]} if result.get("warning") else {}),
        **({"files": result["files"]} if result.get("files") else {}),
        **(
            {"approved_queries": result["approved_queries"]}
            if result.get("approved_queries")
            else {}
        ),
    }


async def _ask_chunked(
    client,
    table_id: int,
    chunks: List[Dict[str, Any]],
    fetch_files: bool,
    max_concurrent: int,
) -> Dict[str, Any]:
    """Fan out N AIDA conversations in parallel (capped by `max_concurrent`) and
    return a merged result. Partial success is a first-class outcome.
    """
    normalized = _validate_chunks(chunks)
    concurrent = max(1, min(max_concurrent, MAX_CONCURRENT_CHUNKS))
    semaphore = asyncio.Semaphore(concurrent)

    logger.info(
        f"ask_aida_chunked: table_id={table_id} chunks={len(normalized)} "
        f"concurrent={concurrent}"
    )
    chunk_results = await asyncio.gather(
        *(
            _ask_one_chunk(client, semaphore, table_id, chunk, fetch_files)
            for chunk in normalized
        )
    )

    successful = sum(1 for c in chunk_results if c.get("status") == "complete")
    overall_status = "complete" if successful == len(chunk_results) else "partial"

    logger.info(
        f"ask_aida_chunked complete: {successful}/{len(chunk_results)} chunks "
        f"succeeded, overall_status={overall_status}"
    )

    return {
        "status": overall_status,
        "total_chunks": len(chunk_results),
        "successful_chunks": successful,
        "chunks": chunk_results,
    }


####
# Plugin registration
####


def register(mcp, client):
    """Register AIDA tools with the MCP server.

    IMPORTANT: These tools are for INTERNAL TESTING ONLY. Do not connect this
    plugin to customer Anomalo instances without explicit approval. The tools
    can execute SQL queries against the connected data warehouse, fetch query
    results to the local machine, and create conversations visible in the
    customer's AIDA history. Use only against staging or internal instances
    until the AIDA MCP integration is formally approved for customer use.
    """
    logger.info("Registering AIDA plugin tools")

    @mcp.tool
    async def ask_aida(
        ctx: Context,
        table_id: int,
        question: str,
        auto_approve: bool = False,
        fetch_files: bool = FETCH_FILES_DEFAULT,
        conversation_id: int | None = None,
        include_messages: bool = False,
    ) -> dict:
        """Ask AIDA (Anomalo's AI Data Analyst) a natural language question about a specific table.

        IMPORTANT: Before calling this tool, confirm with the user:
        1. Which Anomalo instance and table you are querying
        2. Whether AIDA should auto-approve SQL queries (auto_approve=True) or
           prompt for approval (auto_approve=False, the default)
        3. Whether they want to download row-level data (fetch_files=True) or just
           get AIDA's text analysis (fetch_files=False, the default)

        Conversation threading:
        - Omit `conversation_id` (the default) to start a fresh AIDA conversation.
        - Pass the `conversation_id` from a prior `ask_aida` response to continue
          that conversation — AIDA will see the full prior context. Use this for
          follow-up questions about the same topic (e.g. "why is that check
          failing?", "show me the last 7 days").
        - Start a NEW conversation (omit conversation_id) when the topic shifts
          meaningfully, or when switching to a different table. Threading a
          brand-new topic onto an old conversation wastes AIDA's context window.
        - Use `list_aida_conversations` to look up recent conversations for a
          table if the user references prior work.

        Approval flow:
        - auto_approve=False (default): when AIDA wants to run a SQL query, the
          server asks the MCP client for approval via elicitation (a native
          confirmation dialog in Claude Desktop / Cursor / etc).
        - On clients that don't support elicitation, the tool falls back to
          returning `status="awaiting_approval"` with `pending_tool_calls`,
          which can be approved via `approve_aida_query`.

        Set auto_approve=True only if the user explicitly says to run queries
        without review. This will execute SQL against the connected data warehouse
        without confirmation.

        By default, fetch_files=False: only AIDA's text analysis is returned — no
        row-level data is downloaded. If the user explicitly requests to see data
        rows or download results, set fetch_files=True.

        By default, include_messages=False: the response omits the verbose AIDA
        conversation transcript. This keeps your output focused on the final
        answer — you do not need to narrate AIDA's internal reasoning steps.
        Set include_messages=True only if the user asks to see the detailed
        reasoning or tool-call sequence.

        The response includes:
        - `conversation_id`: ID for follow-up interactions (reuse for threading)
        - `status`: "complete", "awaiting_approval", "cancelled", or "timeout"
        - `answer`: AIDA's final analysis in markdown format
        - `files`: When fetch_files=True, list of downloaded files with inline content.
                   When fetch_files=False (default), file metadata only (name, size) without content.
        - `approved_queries`: SQL queries that ran (populated for auto_approve and elicitation paths)
        - `pending_tool_calls`: SQL queries awaiting approval (elicitation-unsupported fallback only)
        - `warning`: Present only when AIDA's output looks truncated (preamble without full analysis)
        - `messages`: Full conversation history (only when include_messages=True)

        Note: AIDA runs asynchronously. This tool may take up to 2 minutes to
        return as it waits for queries to execute.
        """
        return await _ask(
            client,
            table_id=table_id,
            question=question,
            auto_approve=auto_approve,
            fetch_files=fetch_files,
            ctx=ctx,
            conversation_id=conversation_id,
            include_messages=include_messages,
        )

    @mcp.tool
    async def ask_aida_chunked(
        table_id: int,
        chunks: list[dict],
        fetch_files: bool = FETCH_FILES_DEFAULT,
        max_concurrent: int = MAX_CONCURRENT_CHUNKS,
    ) -> dict:
        """Ask AIDA the SAME broad question split across multiple parallel
        conversations, one per dimension slice. Use this when a single
        `ask_aida` call would hit the AIDA processing time limit because the
        scope is too large to analyze in 5 minutes.

        WHEN TO USE:
        - Broad time windows: "failures over the last month" → one chunk per
          week (4 chunks, each covers 7 days).
        - Enumerable dimensions: "failures by check type" → one chunk per
          check category.
        - Per-table analyses over a group of tables (call per table_id
          separately — this tool is for one table at a time).
        - ONLY AFTER plain `ask_aida` returns `status="truncated"` or
          `status="timeout"`, indicating the backend hit a time limit.

        WHEN NOT TO USE:
        - Cross-cutting questions where chunks need to see each other's
          results (e.g. "which week had the biggest change?" — one week can't
          answer that alone). Use plain `ask_aida` with a narrower question.
        - Questions that comfortably fit in one 5-minute AIDA turn — the
          parallel conversations are more expensive and visible as N entries
          in the user's conversation list.

        REQUIRED INPUT SHAPE:
            chunks = [
                {"label": "Week 1 (Apr 1-7)", "question": "List all check failures on table X between 2026-04-01 and 2026-04-07, grouped by check type."},
                {"label": "Week 2 (Apr 8-14)", "question": "List all check failures on table X between 2026-04-08 and 2026-04-14, grouped by check type."},
                ...
            ]

        - Each chunk runs as an independent AIDA conversation — no shared
          context. Phrase each `question` to stand alone with the full
          dimension filter embedded.
        - `label` is echoed back in the response so you can attribute each
          chunk's answer to its slice.
        - Max {MAX_CHUNKS} chunks per call; max {MAX_CONCURRENT_CHUNKS}
          running in parallel to avoid saturating the AIDA backend.

        AUTO-APPROVAL:
        - All chunks run with auto_approve=True. Interactive approval across
          parallel conversations is not supported — running SQL without
          review is an inherent part of this tool.
        - ONLY use this tool if the user has explicitly agreed to auto-run
          SQL queries for this analysis.

        RETURN SHAPE:
            {
                "status": "complete" | "partial",
                "total_chunks": N,
                "successful_chunks": M,
                "chunks": [
                    {
                        "label": ...,
                        "question": ...,
                        "status": "complete" | "truncated" | "timeout" | "error",
                        "answer": ...,
                        "conversation_id": ...,
                        "warning": ...,  # present only when status != "complete"
                    },
                    ...
                ],
            }

        - `status="partial"` means at least one chunk did not fully succeed.
          The surviving chunks still contain useful data — synthesize the
          partial results in your response to the user, and explicitly call
          out which slices failed.
        - Individual chunks that return status="truncated"/"timeout" had the
          same backend time-limit problem — you may want to retry only those
          slices with even narrower scope rather than re-running the whole
          batch.
        """
        return await _ask_chunked(
            client,
            table_id=table_id,
            chunks=chunks,
            fetch_files=fetch_files,
            max_concurrent=max_concurrent,
        )

    @mcp.tool
    def approve_aida_query(
        tool_call_id: int,
        action: str = "approved",
        conversation_id: int | None = None,
        fetch_files: bool = FETCH_FILES_DEFAULT,
        include_messages: bool = False,
    ) -> dict:
        """Approve or deny a pending AIDA tool call (typically a SQL query that AIDA wants to run).

        Only needed when ask_aida was called with auto_approve=False (the default).

        When AIDA pauses to request permission before running a SQL query, use this tool to approve or deny it.
        The `tool_call_id` comes from the `pending_tool_calls` in the `ask_aida` response.

        `action` must be one of:
        - "approved": Approve this specific tool call
        - "denied": Deny this specific tool call
        - "approved_all": Approve this and all future tool calls in the conversation

        If `conversation_id` is provided and the tool call is approved, this will also poll for AIDA's
        continued response after the approved query runs. The same fetch_files and include_messages
        guardrails apply.
        """
        valid_actions = {"approved", "denied", "approved_all"}
        if action not in valid_actions:
            raise ValueError(f"action must be one of {valid_actions}, got '{action}'")

        result = _approve_tool_call(client, tool_call_id, action)

        if action in ("approved", "approved_all") and conversation_id:
            poll_result = _poll_for_response(
                client,
                conversation_id,
                fetch_files=fetch_files,
                include_messages=include_messages,
            )
            if poll_result:
                return poll_result
            return {
                "status": "timeout",
                "answer": None,
                "conversation_id": conversation_id,
                "approval_result": result,
            }

        return result

    @mcp.tool
    def list_aida_conversations(
        table_id: int | None = None,
        hidden: bool = False,
        limit: int = 20,
    ) -> list[dict]:
        """List recent AIDA conversations, optionally filtered to a specific table.

        Useful for checking what questions have already been asked about a table,
        or retrieving a previous conversation's ID for follow-up.

        Returns a list of conversation summaries including id, title, agent_type, created timestamp, and metadata.
        """
        conversations = _list_conversations(
            client, table_id=table_id, hidden=hidden, limit=limit
        )
        return [
            {
                "id": c.id,
                "title": c.title,
                "agent_type": c.agent_type,
                "created": c.created,
                "metadata": c.metadata,
            }
            for c in conversations
        ]
