import datetime
from typing import Any, Dict, List

from anomalo_models import (
    CheckResult,
    CheckRunResult,
    Collection,
    CollectionBreakdown,
    ConfiguredCheck,
    SourceType,
    TableConfig,
)

import anomalo


class AnomaloClient(anomalo.Client):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def get_configured_checks(self, table_id: int) -> List[ConfiguredCheck]:
        """Get a list of configured checks for a table from Anomalo"""
        checks = self.get_checks_for_table(table_id).get("checks", [])
        return [ConfiguredCheck(check) for check in checks if check]

    def get_enriched_configured_tables(
        self, label_id: int = None, table_id: int = None
    ) -> List[TableConfig]:
        """Get a list of configured tables from Anomalo"""
        warehouses = {
            wh.get("id"): {
                "id": wh.get("id"),
                "name": wh.get("name"),
                "warehouse_type": wh.get("warehouse_type"),
            }
            for wh in self.list_warehouses().get("warehouses", [])
        }

        if label_id:
            # filter_tables_by_label uses the `tables` api endpoint
            tables = [
                TableConfig(
                    id=table.get("id"),
                    full_name=table.get("full_name", ""),
                    name=table.get("name", ""),
                    description=table.get("description", ""),
                    monitored=table.get(
                        "monitored", False
                    ),  # should always be true, right?
                    url=f"{self.proto}://{self.host}/dashboard/tables/{table.get('id')}/overview",
                    warehouse_id=(table.get("warehouse") or {}).get("id", 0),
                    warehouse_name=warehouses.get(
                        (table.get("warehouse") or {}).get("id"), {}
                    ).get("name", ""),
                    warehouse_type=warehouses.get(
                        (table.get("warehouse") or {}).get("id"), {}
                    ).get("warehouse_type", ""),
                    check_runs=[],
                )
                for table in self.filter_tables_by_label(label_id)
                if table.get("monitored")
            ]
        elif table_id:
            table = self.get_table_information(table_id=table_id)
            tables = (
                [
                    TableConfig(
                        id=table.get("id"),
                        full_name=table.get("full_name", ""),
                        name=table.get("full_name", "").split(".")[-1],
                        description=table.get("description", ""),
                        monitored=table.get(
                            "monitored", True
                        ),  # should always be true, right?
                        url=f"{self.proto}://{self.host}/dashboard/tables/{table.get('id')}/overview",
                        warehouse_id=(table.get("warehouse") or {}).get("id", 0),
                        warehouse_name=(table.get("warehouse") or {}).get("name", ""),
                        warehouse_type=warehouses.get(
                            (table.get("warehouse") or {}).get("id"), {}
                        ).get("warehouse_type", ""),
                        check_runs=(table.get("recent_status") or {}).get(
                            "recent_intervals"
                        ),
                    )
                ]
                if table
                else []
            )
        else:
            # configured_tables uses the `configured_tables` endpoint
            tables = [
                TableConfig(
                    id=(table.get("table") or {}).get("id"),
                    full_name=(table.get("table") or {}).get("full_name", ""),
                    name=(table.get("table") or {}).get("name", ""),
                    description=(table.get("table") or {}).get("description", ""),
                    monitored=table.get(
                        "watched", True
                    ),  # should always be true, right?
                    url=f"{self.proto}://{self.host}/dashboard/tables/{(table.get('table') or {}).get('id')}/overview",
                    warehouse_id=(table.get("table") or {}).get("warehouse_id", 0),
                    warehouse_name=warehouses.get(
                        (table.get("table") or {}).get("warehouse_id"), {}
                    ).get("name", ""),
                    warehouse_type=warehouses.get(
                        (table.get("table") or {}).get("warehouse_id"), {}
                    ).get("warehouse_type", ""),
                    check_runs=(table.get("recent_status") or {}).get(
                        "recent_intervals"
                    ),
                )
                for table in self.configured_tables(details=False, limit=100)
            ]

        return tables

    def load_data_quality_check_results(self, table: TableConfig) -> bool:
        """Load the last completed run of data quality check results into the TableConfig instance."""
        if not table.latest_data_quality_check_run_job_id:
            start = datetime.datetime.today() - datetime.timedelta(days=7)
            if intervals := self.get_check_intervals(
                table_id=table.id, start=start.strftime("%Y-%m-%d")
            ):
                if intervals := sorted(
                    [i for i in intervals if i.get("status") == "complete"],
                    key=lambda x: x.get("end_time"),
                    reverse=True,
                ):
                    table.latest_data_quality_check_run_job_id = intervals[0].get(
                        "latest_run_checks_job_id"
                    )

        if not table.latest_data_quality_check_run_job_id:
            return False

        results = self.get_run_result(job_id=table.latest_data_quality_check_run_job_id)
        table.data_quality_check_results = [
            CheckResult(r) for r in results.get("check_runs", [])
        ]

        if table.data_quality_check_results:
            passed = sum(1 for r in table.data_quality_check_results if r.check_passed)
            failed = sum(1 for r in table.data_quality_check_results if r.check_failed)
            errored = sum(
                1 for r in table.data_quality_check_results if r.check_errored
            )

            table.data_quality_status = {
                "total_checks": len(table.data_quality_check_results),
                "num_checks_passed": passed,
                "num_checks_failed": failed,
                "num_checks_errored": errored,
                "all_checks_passed": failed == 0 and errored == 0,
            }
        return True

    def get_job_result(self, job_id: str) -> CheckRunResult:
        """
        Get the Check Run Results for a job_id.
        Returns a CheckRunResult object containing a list of CheckResult objects and a flag indicating whether the job is complete or still pending.
        """
        return CheckRunResult(
            [
                CheckResult(r)
                for r in self.get_run_result(job_id=job_id).get("check_runs", [])
                if r
            ]
        )

    def get_collections(
        self, source_type: SourceType | None = None
    ) -> List[Collection]:
        """Get a list of collections from Anomalo"""
        # collect up a list of collections from all organizations in the deployment, optionally filtered by collection source type
        collections = []
        for org in self._api_call("organizations"):
            org_id = org["id"]
            colls = self._api_call(f"orgs/{org_id}/document_collections")
            if source_type == SourceType.S3:
                colls = [o for o in colls if (o.get("source") or {}).get("bucket_name")]
            elif source_type == SourceType.TABLE:
                colls = [o for o in colls if (o.get("source") or {}).get("table_name")]
            # Add organization ID to each collection
            collections.extend(
                list(map(lambda c: {**c, "organization_id": org_id}, colls))
            )

        return [Collection(c) for c in collections]

    def get_collection(
        self, org_id: str | int, collection_id: str | int
    ) -> Collection | None:
        """Get a specific collection from Anomalo"""

        coll = self._api_call(f"orgs/{org_id}/document_collections/{collection_id}")
        return Collection({**coll, "organization_id": org_id}) if coll else None

    def get_org_issues(self, org_id: str | int) -> List[Dict[str, Any]]:
        """Get issues for a specific organization"""
        return self._api_call(f"orgs/{org_id}/issues")

    def get_doc_issues(
        self, org_id: str | int, doc_id: str | int
    ) -> List[Dict[str, Any]]:
        """Get issues for a specific document"""
        return self._api_call(f"orgs/{org_id}/document_issues?document_id={doc_id}")

    def get_collection_issues(self, collection: Collection) -> List[Dict[str, Any]]:
        """Get issues for a specific collection"""
        return self._api_call(
            f"orgs/{collection.organization_id}/document_collections/{collection.id}/issues"
        )

    def get_collection_metadata(self, collection: Collection) -> List[Dict[str, Any]]:
        """Get metadata for a specific collection"""
        return self._api_call(
            f"orgs/{collection.organization_id}/document_collections/{collection.id}/metadata"
        )

    def get_last_collection_check_run(
        self, collection: Collection
    ) -> Dict[str, Any] | None:
        """Get the last check run for a specific collection"""
        runs = self._api_call(
            f"orgs/{collection.organization_id}/document_collection_checkruns?limit=5&document_collection_id={collection.id}"
        )
        runs = [
            r for r in runs if r.get("status") == "success" and r.get("completed_at")
        ]
        return (
            sorted(runs, key=lambda x: x.get("completed_at"), reverse=True)[0]
            if runs
            else None
        )

    def get_collection_breakdown(
        self, collection: Collection
    ) -> CollectionBreakdown | None:
        """Get the breakdown of file metadata for the collection"""
        last_check_run = self.get_last_collection_check_run(collection)
        if not last_check_run:
            return None

        breakdown = CollectionBreakdown(collection, last_check_run)

        docs = self._api_call(
            f"orgs/{collection.organization_id}/documents?document_collection_checkrun_id={last_check_run.get('id')}"
        )
        for doc in docs or []:
            issues = self.get_doc_issues(collection.organization_id, doc["id"])
            breakdown.process_document(doc, issues)

        return breakdown
