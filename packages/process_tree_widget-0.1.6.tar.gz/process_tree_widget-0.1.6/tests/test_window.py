import ibis
import pytest
from process_tree_widget import ProcessTreeWidget
from process_tree_widget.tree import Process, ProcessTree


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def mde_tree():
    table = ibis.read_parquet("public/demo.parquet")
    w = ProcessTreeWidget(events=table, source="mde")
    return w._tree


@pytest.fixture(scope="module")
def vol_tree():
    table = ibis.read_parquet("public/pstree.parquet")
    w = ProcessTreeWidget(events=table, source="volatility")
    return w._tree


@pytest.fixture(scope="module")
def mde_widget():
    table = ibis.read_parquet("public/demo.parquet")
    return ProcessTreeWidget(events=table, source="mde")


@pytest.fixture(scope="module")
def vol_widget():
    table = ibis.read_parquet("public/pstree.parquet")
    return ProcessTreeWidget(events=table, source="volatility")


def _any_real_node(tree: ProcessTree) -> str:
    """Return identifier of the first non-synthetic, non-root node."""
    for node in tree.tree.all_nodes_itr():
        if node.data is not None and not node.data.synthetic:
            return node.identifier
    raise RuntimeError("No real node found in fixture tree")


def _any_real_pid(tree: ProcessTree) -> int:
    for node in tree.tree.all_nodes_itr():
        if node.data is not None and not node.data.synthetic:
            return node.data.target_process_id
    raise RuntimeError("No real node found in fixture tree")


# ---------------------------------------------------------------------------
# ProcessTree.window()
# ---------------------------------------------------------------------------

class TestWindow:
    def test_returns_process_tree(self, mde_tree):
        nid = _any_real_node(mde_tree)
        result = mde_tree.window(nid)
        assert isinstance(result, ProcessTree)

    def test_focal_node_always_present(self, mde_tree):
        nid = _any_real_node(mde_tree)
        result = mde_tree.window(nid, ancestors=2, focal_descendants=3)
        assert result.tree.contains(nid)

    def test_unknown_identifier_returns_empty(self, mde_tree):
        result = mde_tree.window("nonexistent|1970-01-01 00:00:00")
        assert len(list(result.tree.all_nodes())) == 1  # only <root>

    def test_zero_ancestors(self, mde_tree):
        nid = _any_real_node(mde_tree)
        result_zero = mde_tree.window(nid, ancestors=0)
        result_two  = mde_tree.window(nid, ancestors=2)
        focal_zero = result_zero.tree.get_node(nid)
        focal_two  = result_two.tree.get_node(nid)
        assert focal_zero is not None
        # ancestors=0 should give a shallower (or equal) tree than ancestors=2
        assert result_zero.tree.depth(focal_zero) <= result_two.tree.depth(focal_two)

    def test_zero_descendants(self, mde_tree):
        nid = _any_real_node(mde_tree)
        result = mde_tree.window(nid, ancestors=2, focal_descendants=0)
        assert result.tree.contains(nid)
        assert result.tree.children(nid) == []

    def test_unlimited_descendants_keeps_full_subtree(self, mde_tree):
        nid = _any_real_node(mde_tree)
        unbounded = mde_tree.window(nid, ancestors=0, focal_descendants=None)
        bounded_deep = mde_tree.window(nid, ancestors=0, focal_descendants=999)
        # Both should have the same node count
        assert len(list(unbounded.tree.all_nodes())) == len(list(bounded_deep.tree.all_nodes()))

    def test_descendant_depth_exact(self, mde_tree):
        nid = _any_real_node(mde_tree)
        max_desc = 2
        result = mde_tree.window(nid, ancestors=0, focal_descendants=max_desc, sibling_descendants=None)
        focal_depth = result.tree.depth(result.tree.get_node(nid))
        for node in result.tree.all_nodes_itr():
            if node.data is not None:
                node_depth = result.tree.depth(node)
                assert node_depth - focal_depth <= max_desc

    def test_ancestors_capped_by_tree_depth(self, mde_tree):
        nid = _any_real_node(mde_tree)
        # Requesting 999 ancestors should not raise, just return what's available
        result = mde_tree.window(nid, ancestors=999)
        assert result.tree.contains(nid)

    def test_does_not_mutate_original(self, mde_tree):
        original_count = len(list(mde_tree.tree.all_nodes()))
        nid = _any_real_node(mde_tree)
        mde_tree.window(nid, ancestors=1, focal_descendants=2)
        assert len(list(mde_tree.tree.all_nodes())) == original_count

    def test_result_builds_valid_dependentree(self, mde_tree):
        nid = _any_real_node(mde_tree)
        result = mde_tree.window(nid, ancestors=2, focal_descendants=3)
        fmt = result.create_dependentree_format()
        assert isinstance(fmt, list)
        assert all("_name" in e and "_deps" in e for e in fmt)

    def test_vol_window_works(self, vol_tree):
        nid = _any_real_node(vol_tree)
        result = vol_tree.window(nid, ancestors=1, focal_descendants=2)
        assert result.tree.contains(nid)

    def test_sibling_descendants_limits_sibling_depth(self, mde_tree):
        # Find a node with at least one ancestor that has other children (siblings)
        for node in mde_tree.tree.all_nodes_itr():
            if node.data is None or node.data.synthetic:
                continue
            parent = mde_tree.tree.parent(node.identifier)
            if parent is None or parent.identifier == "<root>":
                continue
            siblings = [c for c in mde_tree.tree.children(parent.identifier) if c.identifier != node.identifier]
            if siblings:
                nid = node.identifier
                break
        else:
            pytest.skip("No node with siblings found in fixture")

        # With sibling_descendants=0: no sibling children should appear
        result_0 = mde_tree.window(nid, ancestors=1, focal_descendants=None, sibling_descendants=0)
        # With sibling_descendants=2: more nodes allowed
        result_2 = mde_tree.window(nid, ancestors=1, focal_descendants=None, sibling_descendants=2)
        assert len(list(result_0.tree.all_nodes())) <= len(list(result_2.tree.all_nodes()))

    def test_no_extra_synthetic_above_anchor(self, mde_tree):
        # After windowing, no synthetic nodes should appear above the focal node
        nid = _any_real_node(mde_tree)
        result = mde_tree.window(nid, ancestors=1, focal_descendants=None)
        focal = result.tree.get_node(nid)
        assert focal is not None
        focal_depth = result.tree.depth(focal)
        synthetic_above = [
            n for n in result.tree.all_nodes_itr()
            if n.data is not None and n.data.synthetic and result.tree.depth(n) < focal_depth
        ]
        # Any synthetic nodes above focal should only be real OS ancestors (smss, ntoskrnl etc),
        # not leaked grandparents from outside the window
        for syn in synthetic_above:
            parent = result.tree.parent(syn.identifier)
            assert parent is not None, f"Synthetic node {syn.identifier} has no parent — leaked grandparent"


# ---------------------------------------------------------------------------
# ProcessTree.window_by_pid()
# ---------------------------------------------------------------------------

class TestWindowByPid:
    def test_known_pid_returns_nonempty(self, mde_tree):
        pid = _any_real_pid(mde_tree)
        result = mde_tree.window_by_pid(pid)
        non_root = [n for n in result.tree.all_nodes() if n.data is not None]
        assert len(non_root) > 0

    def test_unknown_pid_returns_empty(self, mde_tree):
        result = mde_tree.window_by_pid(-99999)
        non_root = [n for n in result.tree.all_nodes() if n.data is not None]
        assert len(non_root) == 0

    def test_recycled_pid_picks_latest_creation_time(self):
        t1 = "2024-01-01 00:00:00"
        t2 = "2024-06-01 00:00:00"
        processes = [
            {"TargetProcessId": 100, "TargetProcessFilename": "early.exe", "TargetProcessCreationTime": t1},
            {"TargetProcessId": 100, "TargetProcessFilename": "late.exe",  "TargetProcessCreationTime": t2},
        ]
        tree = ProcessTree(processes)
        result = tree.window_by_pid(100, ancestors=0, focal_descendants=0)
        real_nodes = [n for n in result.tree.all_nodes() if n.data is not None]
        assert len(real_nodes) == 1
        assert real_nodes[0].data.target_process_filename == "late.exe"

    def test_focal_node_is_in_result(self, mde_tree):
        pid = _any_real_pid(mde_tree)
        candidates = [
            n for n in mde_tree.tree.all_nodes_itr()
            if n.data and n.data.target_process_id == pid
        ]
        focal = max(candidates, key=lambda n: n.data.target_process_creation_time)
        result = mde_tree.window_by_pid(pid)
        assert result.tree.contains(focal.identifier)


# ---------------------------------------------------------------------------
# ProcessTree.prune_subtrees()
# ---------------------------------------------------------------------------

class TestPruneSubtrees:
    def test_excluded_name_not_in_result(self, mde_tree):
        all_names = {
            n.data.target_process_filename.lower()
            for n in mde_tree.tree.all_nodes_itr()
            if n.data
        }
        if not all_names:
            pytest.skip("No real nodes in fixture")
        target = next(iter(all_names))
        result = mde_tree.prune_subtrees([target])
        result_names = {
            n.data.target_process_filename.lower()
            for n in result.tree.all_nodes_itr()
            if n.data
        }
        assert target not in result_names

    def test_case_insensitive(self, mde_tree):
        all_names = {
            n.data.target_process_filename
            for n in mde_tree.tree.all_nodes_itr()
            if n.data
        }
        if not all_names:
            pytest.skip("No real nodes in fixture")
        target = next(iter(all_names))
        result_lower = mde_tree.prune_subtrees([target.lower()])
        result_upper = mde_tree.prune_subtrees([target.upper()])
        assert len(list(result_lower.tree.all_nodes())) == len(list(result_upper.tree.all_nodes()))

    def test_descendants_of_excluded_also_removed(self):
        # A simple two-level tree: parent (svchost) -> child (malware)
        t_parent = "2024-01-01 00:00:00"
        t_child  = "2024-01-01 00:00:01"
        processes = [
            {"TargetProcessId": 200, "TargetProcessFilename": "svchost.exe",
             "TargetProcessCreationTime": t_parent},
            {"TargetProcessId": 300, "TargetProcessFilename": "malware.exe",
             "TargetProcessCreationTime": t_child,
             "ActingProcessId": 200, "ActingProcessFilename": "svchost.exe",
             "ActingProcessCreationTime": t_parent},
        ]
        tree = ProcessTree(processes)
        result = tree.prune_subtrees(["svchost.exe"])
        names = {n.data.target_process_filename for n in result.tree.all_nodes_itr() if n.data}
        assert "svchost.exe" not in names
        assert "malware.exe" not in names

    def test_no_match_returns_equivalent_tree(self, mde_tree):
        original_count = len(list(mde_tree.tree.all_nodes()))
        result = mde_tree.prune_subtrees(["__no_such_process__.exe"])
        assert len(list(result.tree.all_nodes())) == original_count

    def test_does_not_mutate_original(self, mde_tree):
        original_count = len(list(mde_tree.tree.all_nodes()))
        all_names = [
            n.data.target_process_filename
            for n in mde_tree.tree.all_nodes_itr()
            if n.data
        ]
        if all_names:
            mde_tree.prune_subtrees([all_names[0]])
        assert len(list(mde_tree.tree.all_nodes())) == original_count

    def test_result_is_connected(self, mde_tree):
        result = mde_tree.prune_subtrees(["svchost.exe"])
        for node in result.tree.all_nodes_itr():
            if node.identifier == "<root>":
                continue
            parent = result.tree.parent(node.identifier)
            assert parent is not None, f"Node {node.identifier} has no parent — tree is disconnected"


# ---------------------------------------------------------------------------
# ProcessTree.prune_root_children()
# ---------------------------------------------------------------------------

class TestPruneRootChildren:
    def test_no_keep_removes_all_root_children(self, mde_tree):
        result = mde_tree.prune_root_children(keep=None)
        root_children = result.tree.children("<root>")
        assert root_children == []

    def test_keep_list_retains_specified(self, mde_tree):
        root_children = mde_tree.tree.children("<root>")
        if not root_children:
            pytest.skip("No root children in fixture")
        first = root_children[0]
        if first.data is None:
            pytest.skip("Root child has no data")
        keep_name = first.data.target_process_filename
        result = mde_tree.prune_root_children(keep=[keep_name])
        result_root_names = {
            c.data.target_process_filename
            for c in result.tree.children("<root>")
            if c.data
        }
        assert keep_name.lower() in {n.lower() for n in result_root_names}

    def test_keep_list_removes_others(self, mde_tree):
        root_children = mde_tree.tree.children("<root>")
        if len(root_children) < 2:
            pytest.skip("Need at least 2 root children for this test")
        keep_node = root_children[0]
        if keep_node.data is None:
            pytest.skip("Root child has no data")
        keep_name = keep_node.data.target_process_filename
        result = mde_tree.prune_root_children(keep=[keep_name])
        # Only the kept name (and its descendants) should be under root
        for child in result.tree.children("<root>"):
            if child.data:
                assert child.data.target_process_filename.lower() == keep_name.lower()

    def test_removes_entire_subtrees(self, mde_tree):
        original_count = len(list(mde_tree.tree.all_nodes()))
        result = mde_tree.prune_root_children(keep=None)
        # Only <root> should remain
        assert len(list(result.tree.all_nodes())) == 1

    def test_does_not_mutate_original(self, mde_tree):
        original_count = len(list(mde_tree.tree.all_nodes()))
        mde_tree.prune_root_children(keep=None)
        assert len(list(mde_tree.tree.all_nodes())) == original_count

    def test_result_is_connected(self, mde_tree):
        root_children = mde_tree.tree.children("<root>")
        if not root_children or root_children[0].data is None:
            pytest.skip("No suitable root children in fixture")
        keep_name = root_children[0].data.target_process_filename
        result = mde_tree.prune_root_children(keep=[keep_name])
        for node in result.tree.all_nodes_itr():
            if node.identifier == "<root>":
                continue
            parent = result.tree.parent(node.identifier)
            assert parent is not None


# ---------------------------------------------------------------------------
# ProcessTree.to_dataframe()
# ---------------------------------------------------------------------------

class TestToDataframe:
    def test_has_asim_columns(self, mde_tree):
        df = mde_tree.to_dataframe()
        expected = {
            "TargetProcessId", "TargetProcessFilename", "TargetProcessCreationTime",
            "ActingProcessId", "ActingProcessFilename", "ActingProcessCreationTime",
        }
        assert expected.issubset(set(df.columns))

    def test_row_count_matches_non_root_nodes(self, mde_tree):
        df = mde_tree.to_dataframe()
        non_root = sum(1 for n in mde_tree.tree.all_nodes_itr() if n.data is not None)
        assert len(df) == non_root

    def test_empty_tree_correct_schema(self):
        df = ProcessTree().to_dataframe()
        assert len(df) == 0
        assert "TargetProcessId" in df.columns

    def test_window_then_dataframe_has_fewer_rows(self, mde_tree):
        nid = _any_real_node(mde_tree)
        full_df = mde_tree.to_dataframe()
        windowed_df = mde_tree.window(nid, ancestors=1, focal_descendants=2).to_dataframe()
        assert len(windowed_df) <= len(full_df)


# ---------------------------------------------------------------------------
# Widget integration
# ---------------------------------------------------------------------------

class TestWidgetIntegration:
    def test_widget_stores_tree_attribute(self, mde_widget):
        assert hasattr(mde_widget, "_tree")
        assert isinstance(mde_widget._tree, ProcessTree)

    def test_widget_stores_active_tree_attribute(self, mde_widget):
        assert hasattr(mde_widget, "_active_tree")

    def test_widget_accepts_process_tree_directly(self, mde_tree):
        w = ProcessTreeWidget(mde_tree)
        assert len(w.events) > 0

    def test_get_window_no_selection_raises(self, mde_widget):
        w = ProcessTreeWidget(mde_widget._tree)  # fresh widget, no selection
        with pytest.raises(ValueError, match="No node selected"):
            w.get_window()

    def test_prune_subtrees_reduces_events(self, mde_tree):
        w = ProcessTreeWidget(mde_tree)
        original_count = len(w.events)
        all_names = [e.get("ProcessName", "") for e in w.events if e.get("ProcessName") != "root"]
        if not all_names:
            pytest.skip("No named nodes")
        w.prune_subtrees([all_names[0]])
        assert len(w.events) <= original_count

    def test_prune_root_children_reduces_events(self, mde_tree):
        w = ProcessTreeWidget(mde_tree)
        original_count = len(w.events)
        w.prune_root_children(keep=None)
        assert len(w.events) <= original_count

    def test_reset_restores_full_tree(self, mde_tree):
        w = ProcessTreeWidget(mde_tree)
        original_count = len(w.events)
        w.prune_root_children(keep=None)
        w.reset()
        assert len(w.events) == original_count

    def test_window_by_pid_on_widget(self, mde_tree):
        w = ProcessTreeWidget(mde_tree)
        pid = _any_real_pid(mde_tree)
        full_count = len(w.events)
        w.window_by_pid(pid, ancestors=1, focal_descendants=2)
        assert len(w.events) <= full_count

    def test_chained_prune_then_window(self, mde_tree):
        w = ProcessTreeWidget(mde_tree)
        pid = _any_real_pid(mde_tree)
        w.prune_root_children(keep=None)
        w.reset()
        w.window_by_pid(pid, ancestors=1)
        assert len(w.events) > 0

    def test_vol_widget_stores_tree(self, vol_widget):
        assert isinstance(vol_widget._tree, ProcessTree)
