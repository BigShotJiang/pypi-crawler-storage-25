import marimo

__generated_with = "0.23.3"
app = marimo.App(width="full", sql_output="polars")


@app.cell
def _():
    return


@app.cell(hide_code=True)
def _():
    import polars as pl
    import narwhals as nw
    from datetime import datetime
    import sys

    sys.path.insert(0, "src")
    for mod in list(sys.modules.keys()):
        if "process_tree_widget" in mod:
            del sys.modules[mod]
    from process_tree_widget.utils import prepare_mde_data, _coalesce_acting_parent, _resolve_epoch_times
    from process_tree_widget.tree import ProcessTree

    return


if __name__ == "__main__":
    app.run()
