project = "Nexus-Nancy"
author = "Nexus-Nancy Maintainers"
release = "1.0.1"

extensions = []

templates_path = ["_templates"]
exclude_patterns = ["_build", "Thumbs.db", ".DS_Store"]

html_theme = "sphinx_rtd_theme"
html_static_path = ["_static"]
