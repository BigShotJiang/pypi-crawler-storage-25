"""
LangChain tools for NEAR Protocol.
Generated for: Build LangChain Tool: NEAR Price & Market Data
"""
import requests
import json
import base64
from typing import Optional, Type, Any, List, Dict, Union, Tuple, Set, Callable
from pydantic import BaseModel, Field

try:
    from langchain.tools import BaseTool
except ImportError:
    from langchain_core.tools import BaseTool  # langchain v0.2+

NEAR_RPC_MAINNET = "https://rpc.mainnet.near.org"
NEAR_RPC_TESTNET = "https://rpc.testnet.near.org"


def _near_rpc(method: str, params: Any, network: str = "mainnet") -> dict:
    """Execute NEAR JSON-RPC call."""
    url = NEAR_RPC_MAINNET if network == "mainnet" else NEAR_RPC_TESTNET
    resp = requests.post(url, json={"jsonrpc":"2.0","id":"1","method":method,"params":params}, timeout=10)
    resp.raise_for_status()
    data = resp.json()
    if "error" in data:
        raise RuntimeError(f"NEAR RPC error: {data['error']}")
    return data.get("result", {})


class NEARAccountInput(BaseModel):
    account_id: str = Field(description="NEAR account ID (e.g. example.near)")
    network: str = Field(default="mainnet", description="mainnet or testnet")


class NEARAccountTool(BaseTool):
    """Query NEAR account balance and storage info."""
    name: str = "near_account_info"
    description: str = "Get NEAR account balance and info. Input: account_id, network (optional)"
    args_schema: Type[BaseModel] = NEARAccountInput

    def _run(self, account_id: str, network: str = "mainnet") -> str:
        result = _near_rpc("query", {
            "request_type": "view_account", "finality": "final", "account_id": account_id
        }, network)
        near = int(result.get("amount", 0)) / 10**24
        return json.dumps({"account_id": account_id, "balance_near": f"{near:.4f}",
            "storage_bytes": result.get("storage_usage", 0)})

    async def _arun(self, account_id: str, network: str = "mainnet") -> str:
        return self._run(account_id, network)


class NEARViewFunctionInput(BaseModel):
    contract_id: str = Field(description="NEAR contract ID")
    method_name: str = Field(description="View method name")
    args: dict = Field(default={}, description="Method arguments")
    network: str = Field(default="mainnet", description="mainnet or testnet")


class NEARViewFunctionTool(BaseTool):
    """Call a view function on a NEAR smart contract."""
    name: str = "near_view_function"
    description: str = "Call a NEAR contract view function. Input: contract_id, method_name, args"
    args_schema: Type[BaseModel] = NEARViewFunctionInput

    def _run(self, contract_id: str, method_name: str, args: dict = {}, network: str = "mainnet") -> str:
        args_b64 = base64.b64encode(json.dumps(args).encode()).decode()
        result = _near_rpc("query", {
            "request_type": "call_function", "finality": "final",
            "account_id": contract_id, "method_name": method_name, "args_base64": args_b64
        }, network)
        decoded = json.loads(bytes(result["result"]).decode())
        return json.dumps(decoded, indent=2)

    async def _arun(self, contract_id: str, method_name: str, args: dict = {}, network: str = "mainnet") -> str:
        return self._run(contract_id, method_name, args, network)


class NEARPriceInput(BaseModel):
    tokens: Optional[List[str]] = Field(default=["near"], description="List of token IDs (e.g. ['near', 'wrap.near'])")
    include_history: bool = Field(default=False, description="Include 7-day price history")
    vs_currency: str = Field(default="usd", description="Quote currency (usd, eur, btc)")

class NEARPriceTool(BaseTool):
    name: str = "near_price_market_data"
    description: str = (
        "Get real-time NEAR and ecosystem token prices, market cap, 24h volume, "
        "price change percentages, and optional 7-day historical data from CoinGecko."
    )
    args_schema: Type[BaseModel] = NEARPriceInput

    def _fetch_coingecko(self, tokens: List[str], vs_currency: str, include_history: bool) -> Dict[str, Any]:
        id_map = {"near": "near", "wrap.near": "near", "aurora": "aurora-near", "ref": "ref-finance"}
        cg_ids = list({id_map.get(t, t) for t in tokens})
        ids_str = ",".join(cg_ids)
        base = "https://api.coingecko.com/api/v3"
        r = requests.get(
            f"{base}/coins/markets",
            params={"vs_currency": vs_currency, "ids": ids_str,
                    "price_change_percentage": "1h,24h,7d", "sparkline": "false"},
            timeout=10
        )
        r.raise_for_status()
        markets = r.json()
        result = {}
        for coin in markets:
            entry = {
                "price": coin.get("current_price"),
                "market_cap": coin.get("market_cap"),
                "volume_24h": coin.get("total_volume"),
                "change_1h_pct": coin.get("price_change_percentage_1h_in_currency"),
                "change_24h_pct": coin.get("price_change_percentage_24h_in_currency"),
                "change_7d_pct": coin.get("price_change_percentage_7d_in_currency"),
                "ath": coin.get("ath"),
                "atl": coin.get("atl"),
                "circulating_supply": coin.get("circulating_supply"),
                "last_updated": coin.get("last_updated"),
            }
            if include_history:
                hist = requests.get(
                    f"{base}/coins/{coin['id']}/market_chart",
                    params={"vs_currency": vs_currency, "days": 7, "interval": "daily"},
                    timeout=10
                )
                if hist.ok:
                    prices = hist.json().get("prices", [])
                    entry["history_7d"] = [{"timestamp": p[0], "price": p[1]} for p in prices]
            result[coin.get("symbol", coin["id"]).upper()] = entry
        return result

    def _run(self, tokens: Optional[List[str]] = None, include_history: bool = False, vs_currency: str = "usd") -> str:
        tokens = tokens or ["near"]
        try:
            data = self._fetch_coingecko(tokens, vs_currency, include_history)
            return json.dumps({"status": "ok", "currency": vs_currency, "data": data}, indent=2)
        except Exception as e:
            return json.dumps({"status": "error", "message": str(e)})

    async def _arun(self, tokens: Optional[List[str]] = None, include_history: bool = False, vs_currency: str = "usd") -> str:
        return self._run(tokens=tokens, include_history=include_history, vs_currency=vs_currency)


class NEARPriceAlertInput(BaseModel):
    token: str = Field(default="near", description="Token symbol or CoinGecko ID to monitor")
    above: Optional[float] = Field(default=None, description="Alert if price rises above this value (USD)")
    below: Optional[float] = Field(default=None, description="Alert if price falls below this value (USD)")
    change_pct_threshold: Optional[float] = Field(default=None, description="Alert if 24h change % exceeds this magnitude")

class NEARPriceAlertTool(BaseTool):
    name: str = "near_price_alert_check"
    description: str = (
        "Check if NEAR or ecosystem token prices have crossed alert thresholds. "
        "Returns triggered alerts for above/below price levels or % change magnitude."
    )
    args_schema: Type[BaseModel] = NEARPriceAlertInput

    def _run(self, token: str = "near", above: Optional[float] = None,
             below: Optional[float] = None, change_pct_threshold: Optional[float] = None) -> str:
        id_map = {"near": "near", "wrap.near": "near", "aurora": "aurora-near", "ref": "ref-finance"}
        cg_id = id_map.get(token.lower(), token.lower())
        try:
            r = requests.get(
                "https://api.coingecko.com/api/v3/coins/markets",
                params={"vs_currency": "usd", "ids": cg_id,
                        "price_change_percentage": "24h", "sparkline": "false"},
                timeout=10
            )
            r.raise_for_status()
            data = r.json()
            if not data:
                return json.dumps({"status": "error", "message": f"Token '{token}' not found"})
            coin = data[0]
            price = coin.get("current_price", 0)
            change_24h = coin.get("price_change_percentage_24h_in_currency", 0) or 0
            alerts = []
            if above is not None and price > above:
                alerts.append({"type": "above", "threshold": above, "current_price": price, "triggered": True})
            if below is not None and price < below:
                alerts.append({"type": "below", "threshold": below, "current_price": price, "triggered": True})
            if change_pct_threshold is not None and abs(change_24h) >= change_pct_threshold:
                alerts.append({"type": "change_pct", "threshold": change_pct_threshold,
                                "current_change_24h_pct": change_24h, "triggered": True})
            return json.dumps({
                "status": "ok", "token": coin.get("symbol", token).upper(),
                "current_price_usd": price, "change_24h_pct": change_24h,
                "alerts_triggered": len(alerts) > 0, "alerts": alerts,
                "last_updated": coin.get("last_updated")
            }, indent=2)
        except Exception as e:
            return json.dumps({"status": "error", "message": str(e)})

    async def _arun(self, token: str = "near", above: Optional[float] = None,
                    below: Optional[float] = None, change_pct_threshold: Optional[float] = None) -> str:
        return self._run(token=token, above=above, below=below, change_pct_threshold=change_pct_threshold)