import cv2
import numpy as np

def rect(img, pt1, pt2, color=(255, 255, 0), thickness=2, corner_length=30):
    """
    Draws a cyberpunk-style frame with reinforced corners instead of a standard cv2.rectangle.
    
    Args:
        img (np.ndarray): The image to draw on.
        pt1 (tuple): Top-left corner (x1, y1).
        pt2 (tuple): Bottom-right corner (x2, y2).
        color (tuple): BGR color of the rectangle. Default is Cyan (255, 255, 0).
        thickness (int): Thickness of the corner lines.
        corner_length (int): Length of the reinforced corner segments.
        
    Returns:
        np.ndarray: The image with the futuristic rectangle drawn.
    """
    x1, y1 = pt1
    x2, y2 = pt2

    # 1. Main thin wireframe (Subtle boundary)
    cv2.rectangle(img, (x1, y1), (x2, y2), color, 1, cv2.LINE_AA)

    # 2. Draw Reinforced Corners (Thicker and prominent)
    # Top-Left
    cv2.line(img, (x1, y1), (x1 + corner_length, y1), color, thickness + 1)
    cv2.line(img, (x1, y1), (x1, y1 + corner_length), color, thickness + 1)

    # Top-Right
    cv2.line(img, (x2, y1), (x2 - corner_length, y1), color, thickness + 1)
    cv2.line(img, (x2, y1), (x2, y1 + corner_length), color, thickness + 1)

    # Bottom-Left
    cv2.line(img, (x1, y2), (x1 + corner_length, y2), color, thickness + 1)
    cv2.line(img, (x1, y2), (x1, y2 - corner_length), color, thickness + 1)

    # Bottom-Right
    cv2.line(img, (x2, y2), (x2 - corner_length, y2), color, thickness + 1)
    cv2.line(img, (x2, y2), (x2, y2 - corner_length), color, thickness + 1)

    # 3. Optional: Neon Inner Fill (Semi-transparent)
    overlay = img.copy()
    cv2.rectangle(overlay, (x1, y1), (x2, y2), color, -1)
    # Applying transparency: 10% overlay + 90% original image
    cv2.addWeighted(overlay, 0.1, img, 0.9, 0, img)

    return img


def circle(img, center, radius, color=(255, 255, 0), thickness=2):
    """
    Draws a futuristic, radar-style circle with dashed segments and neon fill.
    
    Args:
        img (np.ndarray): The image to draw on.
        center (tuple): Center coordinates (x, y).
        radius (int): Radius of the circle.
        color (tuple): BGR color of the circle. Default is Cyan (255, 255, 0).
        thickness (int): Thickness of the segments.
        
    Returns:
        np.ndarray: The image with the futuristic circle drawn.
    """
    # 1. Neon Inner Fill (Hologram Effect)
    overlay = img.copy()
    cv2.circle(overlay, center, radius, color, -1)
    cv2.addWeighted(overlay, 0.1, img, 0.9, 0, img)

    # 2. Main Thin Outer Ring
    cv2.circle(img, center, radius, color, 1, cv2.LINE_AA)

    # 3. Dashed Radar Segments
    for i in range(0, 360, 90):
        start_angle = i
        end_angle = i + 25  
        cv2.ellipse(img, center, (radius, radius), 0, start_angle, end_angle, color, thickness + 1, cv2.LINE_AA)

    # 4. Center Crosshair
    l = 10 
    cv2.line(img, (center[0] - l, center[1]), (center[0] + l, center[1]), color, 1, cv2.LINE_AA)
    cv2.line(img, (center[0], center[1] - l), (center[0], center[1] + l), color, 1, cv2.LINE_AA)

    return img



def translate(image, x, y):
    """Shifts the image by x and y pixels."""
    M = np.float32([[1, 0, x], [0, 1, y]])
    shifted = cv2.warpAffine(image, M, (image.shape[1], image.shape[0]))
    return shifted

def rotate(image, angle, center=None, scale=1.0):
    """Rotates the image by a given angle around a center point."""
    (h, w) = image.shape[:2]
    if center is None:
        center = (w // 2, h // 2)
    M = cv2.getRotationMatrix2D(center, angle, scale)
    rotated = cv2.warpAffine(image, M, (w, h))
    return rotated

def resize(image, width=None, height=None, inter=cv2.INTER_AREA):
    """Resizes the image while maintaining aspect ratio."""
    (h, w) = image.shape[:2]
    if width is None and height is None:
        return image
    if width is None:
        r = height / float(h)
        dim = (int(w * r), height)
    else:
        r = width / float(w)
        dim = (width, int(h * r))
    return cv2.resize(image, dim, interpolation=inter)