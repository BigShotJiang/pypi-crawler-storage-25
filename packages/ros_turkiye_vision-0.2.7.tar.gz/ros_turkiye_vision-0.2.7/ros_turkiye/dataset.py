import os
import json
import cv2
import numpy as np
from pathlib import Path
from tqdm import tqdm
import matplotlib.pyplot as plt
from collections import Counter

# Sabit Renk Paleti
def get_colors(num_classes=50):
    cmap = plt.get_cmap('tab20')
    return [tuple((np.array(cmap(i % 20)[:3]) * 255).astype(int).tolist()) for i in range(num_classes)]

COLORS = get_colors()

def convert(img_dir, json_dir, out_dir="dataset_output", mode='detect', width=None):
    """
    Labelme verilerini YOLO formatına dönüştürür.
    Görselleri ve .txt etiketlerini AYNI klasöre kaydeder.
    """
    label_map = {}
    label_counts = Counter()
    
    # Tüm çıktıların toplanacağı tek klasör
    out_path = Path(out_dir)
    out_path.mkdir(parents=True, exist_ok=True)
    
    img_exts = ('.jpg', '.jpeg', '.png', '.bmp', '.webp')
    images = [f for f in os.listdir(img_dir) if f.lower().endswith(img_exts)]
    
    print(f"🚀 {len(images)} dosya işleniyor...")

    for filename in tqdm(images, desc="Dönüştürülüyor"):
        base_name = Path(filename).stem
        json_path = Path(json_dir) / f"{base_name}.json"
        img_src = Path(img_dir) / filename
        
        if not json_path.exists():
            continue
            
        img = cv2.imread(str(img_src))
        if img is None:
            continue
        
        h_orig, w_orig = img.shape[:2]
        
        # Yeniden Boyutlandırma
        if width:
            r = width / w_orig
            h_new = int(h_orig * r)
            img = cv2.resize(img, (width, h_new))
            w_curr, h_curr = width, h_new
        else:
            r, w_curr, h_curr = 1.0, w_orig, h_orig
        
        with open(json_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        yolo_lines = []
        for shape in data.get('shapes', []):
            label = shape.get('label')
            
            # Sınıf haritasını oluştur (ID sırası için)
            if label not in label_map:
                label_map[label] = len(label_map)
            
            class_id = label_map[label]
            label_counts[label] += 1
            
            pts = np.array(shape.get('points')) * r
            
            if mode == 'segment':
                norm_pts = [f"{pt[i] / (w_curr if i==0 else h_curr):.6f}" for pt in pts for i in range(2)]
                yolo_lines.append(f"{class_id} " + " ".join(norm_pts))
            else:
                x_min, y_min = np.min(pts, axis=0)
                x_max, y_max = np.max(pts, axis=0)
                bw, bh = (x_max - x_min), (y_max - y_min)
                xc, yc = x_min + bw/2, y_min + bh/2
                yolo_lines.append(f"{class_id} {xc/w_curr:.6f} {yc/h_curr:.6f} {bw/w_curr:.6f} {bh/h_curr:.6f}")

        if yolo_lines:
            # Görseli ve etiketi AYNI klasöre kaydet
            cv2.imwrite(str(out_path / filename), img)
            with open(out_path / f"{base_name}.txt", 'w', encoding='utf-8') as f:
                f.write("\n".join(yolo_lines))

    # classes.txt: ID sırasına göre sınıfları yazdır
    # label_map zaten eklenme sırasına göre (0, 1, 2...) tutuyor
    sorted_classes = [l for l, i in sorted(label_map.items(), key=lambda x: x[1])]
    with open(out_path / "classes.txt", "w", encoding='utf-8') as f:
        f.write("\n".join(sorted_classes))
    
    # 2. GRAFİĞİ ÇİZDİR (Eksik olan buydu)
    _plot_distribution(label_counts, out_dir)
    print(f"\n✅ İşlem Tamamlandı!")
    print(f"📂 Tüm dosyalar şurada toplandı: {out_path.absolute()}")
    print(f"📄 Sınıf listesi (classes.txt) oluşturuldu.")
    print(f"📊 Dağılım raporu şuraya kaydedildi: {out_dir}/reports/sinif_dagilimi.png")



def _plot_distribution(label_counts, out_dir):
    report_path = Path(out_dir) / "reports"
    report_path.mkdir(parents=True, exist_ok=True)
    if not label_counts: return
    
    # Veriyi sayıya göre sırala
    sorted_counts = sorted(label_counts.items(), key=lambda x: x[1], reverse=True)
    labels, counts = zip(*sorted_counts)
    
    # 1. Grafik boyutunu büyüttük (daha geniş)
    plt.figure(figsize=(15, 8)) 
    
    # 2. Renk paletini daha canlı yaptık
    colors = plt.cm.viridis(np.linspace(0, 1, len(labels)))
    bars = plt.bar(labels, counts, color=colors, edgecolor='black', alpha=0.7)
    
    # 3. Her barın üzerine tam sayısını yazdıralım
    for bar in bars:
        yval = bar.get_height()
        plt.text(bar.get_x() + bar.get_width()/2, yval + 0.5, int(yval), 
                 ha='center', va='bottom', fontsize=10, fontweight='bold')

    # 4. Eksen ve Başlık ayarları
    plt.title("Veriseti Sınıf Dağılımı", fontsize=16, fontweight='bold', pad=20)
    plt.xlabel("Sınıf İsimleri", fontsize=12)
    plt.ylabel("Nesne Sayısı", fontsize=12)
    
    # 5. ETİKETLERİ DÜZELTEN KISIM: 45 derece açı ve hizalama
    plt.xticks(rotation=45, ha='right', fontsize=9)
    
    # 6. Arka plana hafif ızgara ekleyelim (okunabilirliği artırır)
    plt.grid(axis='y', linestyle='--', alpha=0.6)
    
    plt.tight_layout() # Tasarımı ekrana sığdır
    plt.savefig(report_path / "sinif_dagilimi.png", dpi=300) # Yüksek kalite kayıt
    plt.close()

    
def visualize(dataset_dir, mode='detect'):
    """Dönüştürülmüş YOLO verisetini havalı etiketlerle ekranda gösterir."""
    dataset_path = Path(dataset_dir)
    names = []
    if (dataset_path / "classes.txt").exists():
        with open(dataset_path / "classes.txt", "r", encoding='utf-8') as f:
            names = [l.strip() for l in f.readlines()]

    # Sadece .txt karşılığı olan resimleri listele
    files = [dataset_path / f for f in os.listdir(dataset_dir) 
            if f.lower().endswith(('.jpg', '.png', '.jpeg')) 
            and (dataset_path / Path(f).with_suffix('.txt').name).exists()]    
    if not files:
        print("❌ Görselleştirilecek uygun dosya bulunamadı!")
        return

    idx = 0
    cv2.namedWindow("ROS Turkiye Visualizer", cv2.WINDOW_NORMAL)

    while True:
        img_path = files[idx]
        img = cv2.imread(str(img_path))
        h, w = img.shape[:2]
        txt_path = img_path.with_suffix('.txt')
        
        if txt_path.exists():
            with open(txt_path, 'r') as f:
                for line in f:
                    p = list(map(float, line.strip().split()))
                    if not p: continue
                    cls_id = int(p[0])
                    color = COLORS[cls_id % 20]
                    label_name = names[cls_id].upper() if cls_id < len(names) else f"ID:{cls_id}"
                    
                    # Koordinat Hesaplama
                    if mode == 'detect':
                        x1, y1 = int((p[1]-p[3]/2)*w), int((p[2]-p[4]/2)*h)
                        x2, y2 = int((p[1]+p[3]/2)*w), int((p[2]+p[4]/2)*h)
                        cv2.rectangle(img, (x1, y1), (x2, y2), color, 2)
                        text_anchor = (x1, y1)
                    else: # segment
                        pts = np.array([[p[i]*w, p[i+1]*h] for i in range(1, len(p), 2)], np.int32)
                        cv2.polylines(img, [pts], True, color, 2)
                        text_anchor = (pts[0][0], pts[0][1])

                    # --- HAVALI ETİKET ÇİZİMİ ---
                    font = cv2.FONT_HERSHEY_SIMPLEX
                    font_scale = 0.6
                    thickness = 1
                    padding = 8
                    
                    # Metin boyutunu hesapla
                    (t_w, t_h), baseline = cv2.getTextSize(label_name, font, font_scale, thickness)
                    
                    # Arka plan kutusu koordinatları (Metni kutunun üzerine bindiriyoruz)
                    bg_x1 = text_anchor[0]
                    bg_y1 = text_anchor[1] - t_h - padding
                    bg_x2 = text_anchor[0] + t_w + padding
                    bg_y2 = text_anchor[1]

                    # Kutunun resim dışına taşmasını engelle (Basit kontrol)
                    if bg_y1 < 0: 
                        bg_y1 = text_anchor[1]
                        bg_y2 = text_anchor[1] + t_h + padding

                    # Sınıf renginde dolu kutu çiz
                    cv2.rectangle(img, (bg_x1, bg_y1), (bg_x2, bg_y2), color, -1)
                    
                    # Metni kontrast için Beyaz veya Siyah yaz (Burada Beyaz tercih edildi)
                    cv2.putText(img, label_name, (bg_x1 + padding//2, bg_y2 - padding//2), 
                                font, font_scale, (255, 255, 255), thickness, cv2.LINE_AA)

        cv2.setWindowTitle("ROS Turkiye Visualizer", f"[{idx+1}/{len(files)}] {img_path.name} - 'Q' Cikis")
        cv2.imshow("ROS Turkiye Visualizer", img)
        
        key = cv2.waitKeyEx(0)
        if key == 27 or key == ord('q'): break
        elif key in [2555904, 65363, ord('d')]: idx = (idx + 1) % len(files)
        elif key in [2424832, 65361, ord('a')]: idx = (idx - 1) % len(files)
        
    cv2.destroyAllWindows()