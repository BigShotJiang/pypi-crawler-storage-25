from __future__ import annotations

import asyncio
import base64
import copy
import importlib
import json
import ssl
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from queue import Empty as QueueEmpty, Queue
from typing import Any, Callable, Dict, List, Optional, Protocol, Union
from urllib.parse import urlencode, urlparse
from urllib.request import Request, urlopen

from .correlation import TrackingPayload


EndpointKind = str
EndpointMode = str


@dataclass
class HttpEndpointOptions:
    url: str
    method: str = "GET"
    consume_poll: Optional[Callable[[], Optional[TrackingPayload]]] = None
    body_type: str = "Json"
    response_source: str = "None"
    tracking_payload_source: str = "Request"
    consume_array_path: Optional[str] = None
    consume_json_array_response: Optional[bool] = None
    request_timeout_seconds: Optional[float] = None
    auth: Optional["HttpAuthOptions"] = None
    token_request_headers: Dict[str, str] = field(default_factory=dict)


@dataclass
class HttpOAuth2ClientCredentialsOptions:
    token_endpoint: Optional[str] = None
    client_id: Optional[str] = None
    client_secret: Optional[str] = None
    scopes: Optional[List[str]] = None
    additional_form_fields: Dict[str, str] = field(default_factory=dict)

    def validate(self) -> None:
        if not str(self.token_endpoint or "").strip():
            raise ValueError("TokenEndpoint must be provided for OAuth2 client credentials flow.")
        if not str(self.client_id or "").strip():
            raise ValueError("ClientId must be provided for OAuth2 client credentials flow.")
        if not str(self.client_secret or "").strip():
            raise ValueError("ClientSecret must be provided for OAuth2 client credentials flow.")

    Validate = validate


@dataclass
class HttpAuthOptions:
    mode: str = "None"
    type: Optional[str] = None
    username: Optional[str] = None
    password: Optional[str] = None
    bearer_token: Optional[str] = None
    token_url: Optional[str] = None
    client_id: Optional[str] = None
    client_secret: Optional[str] = None
    scope: Optional[str] = None
    scopes: Optional[List[str]] = None
    audience: Optional[str] = None
    additional_form_fields: Dict[str, str] = field(default_factory=dict)
    oauth2_client_credentials: Optional[HttpOAuth2ClientCredentialsOptions] = None
    token_header_name: str = "Authorization"

    def validate(self) -> None:
        mode = _resolve_http_auth_mode(self)
        if mode == "none":
            return
        if mode == "basic":
            if not str(self.username or "").strip():
                raise ValueError("Username must be provided for basic auth.")
            if self.password is None:
                raise ValueError("Password must be provided for basic auth.")
            return
        if mode == "bearer":
            if not str(self.bearer_token or "").strip():
                raise ValueError("BearerToken must be provided for bearer auth.")
            return
        if mode == "oauth2clientcredentials":
            oauth_options = self.oauth2_client_credentials if isinstance(self.oauth2_client_credentials, HttpOAuth2ClientCredentialsOptions) else None
            if not str(_first_non_empty_string(self.token_url, oauth_options.token_endpoint if oauth_options else None) or "").strip():
                raise ValueError("TokenEndpoint must be provided for OAuth2 client credentials flow.")
            if not str(_first_non_empty_string(self.client_id, oauth_options.client_id if oauth_options else None) or "").strip():
                raise ValueError("ClientId must be provided for OAuth2 client credentials flow.")
            if not str(_first_non_empty_string(self.client_secret, oauth_options.client_secret if oauth_options else None) or "").strip():
                raise ValueError("ClientSecret must be provided for OAuth2 client credentials flow.")
            return
        raise ValueError(f"Unsupported HTTP auth type: {self.mode or self.type}")

    Validate = validate


@dataclass
class KafkaSaslOptions:
    mechanism: str = "Plain"
    username: Optional[str] = None
    password: Optional[str] = None
    oauth_bearer_token_endpoint_url: Optional[str] = None
    additional_settings: Dict[str, str] = field(default_factory=dict)

    def validate(self) -> None:
        mechanism = str(self.mechanism or "Plain").strip().lower()
        if mechanism == "oauthbearer":
            if not str(self.oauth_bearer_token_endpoint_url or "").strip():
                raise ValueError("OAuthBearerTokenEndpointUrl must be provided when SASL mechanism is OAuthBearer.")
            return
        if not str(self.username or "").strip():
            raise ValueError("Username must be provided for SASL authentication.")
        if self.password is None:
            raise ValueError("Password must be provided for SASL authentication.")

    Validate = validate


@dataclass
class KafkaEndpointOptions:
    bootstrap_servers: Optional[str] = None
    topic: Optional[str] = None
    consumer_group_id: Optional[str] = None
    security_protocol: str = "Plaintext"
    sasl: Optional[Union[Dict[str, Any], KafkaSaslOptions]] = None
    confluent_settings: Dict[str, str] = field(default_factory=dict)
    start_from_earliest: Optional[bool] = None
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class RabbitMqEndpointOptions:
    host_name: Optional[str] = None
    port: int = 5672
    virtual_host: str = "/"
    user_name: Optional[str] = None
    password: Optional[str] = None
    exchange: str = ""
    queue_name: Optional[str] = None
    routing_key: Optional[str] = None
    durable: bool = True
    auto_ack: bool = False
    use_ssl: bool = False
    client_properties: Dict[str, str] = field(default_factory=dict)
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class NatsEndpointOptions:
    server_url: Optional[str] = None
    subject: Optional[str] = None
    queue_group: Optional[str] = None
    user_name: Optional[str] = None
    password: Optional[str] = None
    token: Optional[str] = None
    connection_name: Optional[str] = None
    max_reconnect_attempts: int = 60
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class RedisStreamsEndpointOptions:
    connection_string: Optional[str] = None
    stream_key: Optional[str] = None
    consumer_group: Optional[str] = None
    consumer_name: Optional[str] = None
    start_from_earliest: Optional[bool] = None
    read_count: int = 50
    max_length: Optional[int] = None
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class AzureEventHubsEndpointOptions:
    connection_string: Optional[str] = None
    event_hub_name: Optional[str] = None
    consumer_group: Optional[str] = None
    partition_id: Optional[str] = None
    partition_key: Optional[str] = None
    partition_count: Optional[int] = None
    start_from_earliest: Optional[bool] = None
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class PushDiffusionEndpointOptions:
    server_url: Optional[str] = None
    topic_path: Optional[str] = None
    principal: Optional[str] = None
    password: Optional[str] = None
    connection_properties: Dict[str, str] = field(default_factory=dict)
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class DelegateEndpointOptions:
    produce: Optional[Callable[[TrackingPayload], Any]] = None
    consume: Optional[Callable[[], Any]] = None
    produce_async: Optional[Callable[["ProducedMessageRequest"], Any]] = None
    consume_async: Optional[Callable[[Callable[["ConsumedMessage"], Any]], Any]] = None


@dataclass(frozen=True)
class ProducedMessageRequest:
    endpoint: "EndpointDefinition"
    payload: TrackingPayload
    tracking_id: str


@dataclass
class ProducedMessageResult:
    is_success: bool = True
    timestamp_utc: Any = None
    error_message: Optional[str] = None
    response_payload: Optional[TrackingPayload] = None


@dataclass(frozen=True)
class ConsumedMessage:
    payload: TrackingPayload
    timestamp_utc: Any = None


@dataclass
class EndpointDefinition:
    kind: EndpointKind
    mode: EndpointMode
    name: str
    tracking_field: str
    gather_by_field: Optional[str] = None
    auto_generate_tracking_id_when_missing: bool = True
    poll_interval_ms: Optional[int] = 250
    message_headers: Dict[str, str] = field(default_factory=dict)
    message_payload: Any = None
    message_payload_type: Optional[str] = None
    json_serializer_settings: Dict[str, Any] = field(default_factory=dict)
    json_convert_settings: Dict[str, Any] = field(default_factory=dict)
    content_type: str = "application/json"
    http: Optional[HttpEndpointOptions] = None
    kafka: Optional[Union[Dict[str, Any], KafkaEndpointOptions]] = None
    rabbit_mq: Optional[Union[Dict[str, Any], RabbitMqEndpointOptions]] = None
    nats: Optional[Union[Dict[str, Any], NatsEndpointOptions]] = None
    redis_streams: Optional[Union[Dict[str, Any], RedisStreamsEndpointOptions]] = None
    azure_event_hubs: Optional[Union[Dict[str, Any], AzureEventHubsEndpointOptions]] = None
    push_diffusion: Optional[Union[Dict[str, Any], PushDiffusionEndpointOptions]] = None
    delegate: Optional[DelegateEndpointOptions] = None
    connection_metadata: Dict[str, str] = field(default_factory=dict)


@dataclass
class TrafficEndpointDefinition(EndpointDefinition):
    kind: str = field(init=False, default="")
    mode: str = "Produce"
    name: str = ""
    tracking_field: Any = ""
    gather_by_field: Optional[Any] = None

    def __post_init__(self) -> None:
        if type(self) is TrafficEndpointDefinition:
            raise TypeError("TrafficEndpointDefinition is abstract and cannot be instantiated directly.")
        self.tracking_field = _normalize_tracking_field_input(self.tracking_field)
        if self.gather_by_field is not None:
            self.gather_by_field = _normalize_tracking_field_input(self.gather_by_field)

    def validate(self) -> None:
        _validate_endpoint_definition(self)

    Validate = validate


@dataclass
class HttpEndpointDefinition(TrafficEndpointDefinition):
    url: str = ""
    method: str = "GET"
    consume_poll: Optional[Callable[[], Optional[TrackingPayload]]] = None
    body_type: str = "Json"
    response_source: str = "None"
    tracking_payload_source: str = "Request"
    consume_array_path: Optional[str] = None
    consume_json_array_response: bool = False
    request_timeout: Optional[float] = None
    request_timeout_seconds: Optional[float] = None
    auth: Optional[HttpAuthOptions] = None
    token_request_headers: Dict[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        super().__post_init__()
        self.kind = "Http"
        timeout_seconds = self.request_timeout_seconds if self.request_timeout_seconds is not None else self.request_timeout
        self.http = HttpEndpointOptions(
            url=self.url,
            method=self.method,
            consume_poll=self.consume_poll,
            body_type=self.body_type,
            response_source=self.response_source,
            tracking_payload_source=self.tracking_payload_source,
            consume_array_path=self.consume_array_path,
            consume_json_array_response=self.consume_json_array_response,
            request_timeout_seconds=timeout_seconds,
            auth=self.auth,
            token_request_headers=dict(self.token_request_headers),
        )


@dataclass
class KafkaEndpointDefinition(TrafficEndpointDefinition):
    bootstrap_servers: str = ""
    topic: str = ""
    consumer_group_id: Optional[str] = None
    security_protocol: str = "Plaintext"
    sasl: Optional[Union[Dict[str, Any], KafkaSaslOptions]] = None
    confluent_settings: Dict[str, str] = field(default_factory=dict)
    start_from_earliest: bool = True

    def __post_init__(self) -> None:
        super().__post_init__()
        self.kind = "Kafka"
        self.kafka = KafkaEndpointOptions(
            bootstrap_servers=self.bootstrap_servers,
            topic=self.topic,
            consumer_group_id=self.consumer_group_id,
            security_protocol=self.security_protocol,
            sasl=self.sasl,
            confluent_settings=dict(self.confluent_settings),
            start_from_earliest=self.start_from_earliest,
        )


@dataclass
class RabbitMqEndpointDefinition(TrafficEndpointDefinition):
    host_name: str = ""
    port: int = 5672
    virtual_host: str = "/"
    user_name: str = ""
    password: Optional[str] = None
    exchange: str = ""
    queue_name: str = ""
    routing_key: str = ""
    durable: bool = True
    auto_ack: bool = False
    use_ssl: bool = False
    client_properties: Dict[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        super().__post_init__()
        self.kind = "RabbitMq"
        self.rabbit_mq = RabbitMqEndpointOptions(
            host_name=self.host_name,
            port=self.port,
            virtual_host=self.virtual_host,
            user_name=self.user_name,
            password=self.password,
            exchange=self.exchange,
            queue_name=self.queue_name,
            routing_key=self.routing_key,
            durable=self.durable,
            auto_ack=self.auto_ack,
            use_ssl=self.use_ssl,
            client_properties=dict(self.client_properties),
        )


@dataclass
class NatsEndpointDefinition(TrafficEndpointDefinition):
    server_url: str = ""
    subject: str = ""
    queue_group: Optional[str] = None
    user_name: Optional[str] = None
    password: Optional[str] = None
    token: Optional[str] = None
    connection_name: Optional[str] = None
    max_reconnect_attempts: int = 60

    def __post_init__(self) -> None:
        super().__post_init__()
        self.kind = "Nats"
        self.nats = NatsEndpointOptions(
            server_url=self.server_url,
            subject=self.subject,
            queue_group=self.queue_group,
            user_name=self.user_name,
            password=self.password,
            token=self.token,
            connection_name=self.connection_name,
            max_reconnect_attempts=self.max_reconnect_attempts,
        )


@dataclass
class RedisStreamsEndpointDefinition(TrafficEndpointDefinition):
    connection_string: str = ""
    stream_key: str = ""
    consumer_group: Optional[str] = None
    consumer_name: Optional[str] = None
    start_from_earliest: bool = True
    read_count: int = 50
    max_length: Optional[int] = None

    def __post_init__(self) -> None:
        super().__post_init__()
        self.kind = "RedisStreams"
        self.redis_streams = RedisStreamsEndpointOptions(
            connection_string=self.connection_string,
            stream_key=self.stream_key,
            consumer_group=self.consumer_group,
            consumer_name=self.consumer_name,
            start_from_earliest=self.start_from_earliest,
            read_count=self.read_count,
            max_length=self.max_length,
        )


@dataclass
class AzureEventHubsEndpointDefinition(TrafficEndpointDefinition):
    connection_string: str = ""
    event_hub_name: str = ""
    consumer_group: str = "$Default"
    partition_id: Optional[str] = None
    partition_key: Optional[str] = None
    partition_count: Optional[int] = None
    start_from_earliest: bool = False

    def __post_init__(self) -> None:
        super().__post_init__()
        self.kind = "AzureEventHubs"
        self.azure_event_hubs = AzureEventHubsEndpointOptions(
            connection_string=self.connection_string,
            event_hub_name=self.event_hub_name,
            consumer_group=self.consumer_group,
            partition_id=self.partition_id,
            partition_key=self.partition_key,
            partition_count=self.partition_count,
            start_from_earliest=self.start_from_earliest,
        )


@dataclass
class DelegateStreamEndpointDefinition(TrafficEndpointDefinition):
    produce: Optional[Callable[[TrackingPayload], Any]] = None
    consume: Optional[Callable[[], Any]] = None
    produce_async: Optional[Callable[[ProducedMessageRequest], Any]] = None
    consume_async: Optional[Callable[[Callable[[ConsumedMessage], Any]], Any]] = None

    def __post_init__(self) -> None:
        super().__post_init__()
        self.kind = "DelegateStream"
        self.delegate = DelegateEndpointOptions(
            produce=self.produce,
            consume=self.consume,
            produce_async=self.produce_async,
            consume_async=self.consume_async,
        )


@dataclass
class PushDiffusionEndpointDefinition(TrafficEndpointDefinition):
    server_url: str = ""
    topic_path: str = ""
    principal: Optional[str] = None
    password: Optional[str] = None
    connection_properties: Dict[str, str] = field(default_factory=dict)
    publish_async: Optional[Callable[[ProducedMessageRequest], Any]] = None
    subscribe_async: Optional[Callable[[Callable[[ConsumedMessage], Any]], Any]] = None

    def __post_init__(self) -> None:
        super().__post_init__()
        self.kind = "PushDiffusion"
        self.push_diffusion = PushDiffusionEndpointOptions(
            server_url=self.server_url,
            topic_path=self.topic_path,
            principal=self.principal,
            password=self.password,
            connection_properties=dict(self.connection_properties),
        )
        self.delegate = DelegateEndpointOptions(
            produce_async=self.publish_async,
            consume_async=self.subscribe_async,
        )


class EndpointAdapter(Protocol):
    def produce(self, payload: Optional[TrackingPayload] = None) -> Optional[TrackingPayload]:
        ...

    def consume(self) -> Optional[TrackingPayload]:
        ...


class _InMemoryProtocolBus:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._kafka_topics: Dict[str, list[dict[str, Any]]] = {}
        self._kafka_offsets: Dict[str, int] = {}
        self._rabbit_queues: Dict[str, list[dict[str, Any]]] = {}
        self._nats_subjects: Dict[str, list[dict[str, Any]]] = {}
        self._nats_offsets: Dict[str, int] = {}
        self._redis_streams: Dict[str, list[dict[str, Any]]] = {}
        self._redis_group_offsets: Dict[str, int] = {}
        self._redis_counters: Dict[str, int] = {}
        self._event_hubs: Dict[str, list[dict[str, Any]]] = {}
        self._event_hub_offsets: Dict[str, int] = {}
        self._push_topics: Dict[str, list[dict[str, Any]]] = {}
        self._push_offsets: Dict[str, int] = {}

    def reset(self) -> None:
        with self._lock:
            self._kafka_topics.clear()
            self._kafka_offsets.clear()
            self._rabbit_queues.clear()
            self._nats_subjects.clear()
            self._nats_offsets.clear()
            self._redis_streams.clear()
            self._redis_group_offsets.clear()
            self._redis_counters.clear()
            self._event_hubs.clear()
            self._event_hub_offsets.clear()
            self._push_topics.clear()
            self._push_offsets.clear()

    def produce_kafka(self, endpoint: EndpointDefinition, payload: TrackingPayload) -> TrackingPayload:
        options = _as_options_dict(endpoint.kafka)
        topic = _option_string(options, "Topic", "topic") or endpoint.name
        with self._lock:
            rows = self._kafka_topics.setdefault(topic, [])
            rows.append({"payload": _clone_payload(payload), "timestamp_ms": _now_ms()})
        return _clone_payload(payload)

    def consume_kafka(self, endpoint: EndpointDefinition) -> Optional[TrackingPayload]:
        options = _as_options_dict(endpoint.kafka)
        topic = _option_string(options, "Topic", "topic") or endpoint.name
        group_id = _option_string(options, "ConsumerGroupId", "consumerGroupId") or f"{endpoint.name}-group"
        start_from_earliest = _option_bool(options, True, "StartFromEarliest", "startFromEarliest")
        cursor_key = f"{topic}|{group_id}"
        with self._lock:
            rows = self._kafka_topics.get(topic, [])
            offset = self._kafka_offsets.get(cursor_key)
            if offset is None:
                offset = 0 if start_from_earliest else len(rows)
            if offset >= len(rows):
                self._kafka_offsets[cursor_key] = offset
                return None
            self._kafka_offsets[cursor_key] = offset + 1
            return _clone_payload(rows[offset]["payload"])

    def produce_rabbit(self, endpoint: EndpointDefinition, payload: TrackingPayload) -> TrackingPayload:
        options = _as_options_dict(endpoint.rabbit_mq)
        queue_name = (
            _option_string(options, "QueueName", "queueName")
            or _option_string(options, "RoutingKey", "routingKey")
            or endpoint.name
        )
        with self._lock:
            queue = self._rabbit_queues.setdefault(queue_name, [])
            queue.append({"payload": _clone_payload(payload), "timestamp_ms": _now_ms()})
        return _clone_payload(payload)

    def consume_rabbit(self, endpoint: EndpointDefinition) -> Optional[TrackingPayload]:
        options = _as_options_dict(endpoint.rabbit_mq)
        queue_name = (
            _option_string(options, "QueueName", "queueName")
            or _option_string(options, "RoutingKey", "routingKey")
            or endpoint.name
        )
        with self._lock:
            queue = self._rabbit_queues.get(queue_name, [])
            if not queue:
                return None
            next_row = queue.pop(0)
            self._rabbit_queues[queue_name] = queue
            return _clone_payload(next_row["payload"])

    def produce_nats(self, endpoint: EndpointDefinition, payload: TrackingPayload) -> TrackingPayload:
        options = _as_options_dict(endpoint.nats)
        subject = _option_string(options, "Subject", "subject") or endpoint.name
        with self._lock:
            rows = self._nats_subjects.setdefault(subject, [])
            rows.append({"payload": _clone_payload(payload), "timestamp_ms": _now_ms()})
        return _clone_payload(payload)

    def consume_nats(self, endpoint: EndpointDefinition) -> Optional[TrackingPayload]:
        options = _as_options_dict(endpoint.nats)
        subject = _option_string(options, "Subject", "subject") or endpoint.name
        queue_group = _option_string(options, "QueueGroup", "queueGroup")
        start_from_earliest = _option_bool(options, True, "StartFromEarliest", "startFromEarliest")
        cursor_key = f"queue:{subject}:{queue_group}" if queue_group else f"sub:{subject}:{endpoint.name}"
        with self._lock:
            rows = self._nats_subjects.get(subject, [])
            offset = self._nats_offsets.get(cursor_key)
            if offset is None:
                offset = 0 if start_from_earliest else len(rows)
            if offset >= len(rows):
                self._nats_offsets[cursor_key] = offset
                return None
            self._nats_offsets[cursor_key] = offset + 1
            return _clone_payload(rows[offset]["payload"])

    def produce_redis(self, endpoint: EndpointDefinition, payload: TrackingPayload) -> TrackingPayload:
        options = _as_options_dict(endpoint.redis_streams)
        stream_key = _option_string(options, "StreamKey", "streamKey") or endpoint.name
        with self._lock:
            rows = self._redis_streams.setdefault(stream_key, [])
            counter = self._redis_counters.get(stream_key, 0) + 1
            self._redis_counters[stream_key] = counter
            stream_id = f"{_now_ms()}-{counter}"
            rows.append({"id": stream_id, "payload": _clone_payload(payload), "timestamp_ms": _now_ms()})
            max_length = int(_option_number(options, "MaxLength", "maxLength"))
            if max_length > 0 and len(rows) > max_length:
                del rows[0 : len(rows) - max_length]

        with_id = _clone_payload(payload)
        headers = with_id.get("headers", {})
        if not isinstance(headers, dict):
            headers = {}
        headers["x-stream-id"] = stream_id
        with_id["headers"] = headers
        return with_id

    def consume_redis(self, endpoint: EndpointDefinition) -> Optional[TrackingPayload]:
        options = _as_options_dict(endpoint.redis_streams)
        stream_key = _option_string(options, "StreamKey", "streamKey") or endpoint.name
        consumer_group = _option_string(options, "ConsumerGroup", "consumerGroup") or f"{endpoint.name}-group"
        start_from_earliest = _option_bool(options, True, "StartFromEarliest", "startFromEarliest")
        cursor_key = f"{stream_key}|{consumer_group}"
        with self._lock:
            rows = self._redis_streams.get(stream_key, [])
            offset = self._redis_group_offsets.get(cursor_key)
            if offset is None:
                offset = 0 if start_from_earliest else len(rows)
            if offset >= len(rows):
                self._redis_group_offsets[cursor_key] = offset
                return None
            self._redis_group_offsets[cursor_key] = offset + 1
            row = rows[offset]

        payload = _clone_payload(row["payload"])
        headers = payload.get("headers", {})
        if not isinstance(headers, dict):
            headers = {}
        headers["x-stream-id"] = str(row.get("id", ""))
        payload["headers"] = headers
        return payload

    def produce_event_hub(self, endpoint: EndpointDefinition, payload: TrackingPayload) -> TrackingPayload:
        options = _as_options_dict(endpoint.azure_event_hubs)
        hub_name = _option_string(options, "EventHubName", "eventHubName") or endpoint.name
        partition_id = _resolve_event_hub_produce_partition_id(options) or ""
        with self._lock:
            rows = self._event_hubs.setdefault(hub_name, [])
            rows.append(
                {
                    "partition_id": partition_id,
                    "payload": _clone_payload(payload),
                    "timestamp_ms": _now_ms(),
                }
            )
        return _clone_payload(payload)

    def consume_event_hub(self, endpoint: EndpointDefinition) -> Optional[TrackingPayload]:
        options = _as_options_dict(endpoint.azure_event_hubs)
        hub_name = _option_string(options, "EventHubName", "eventHubName") or endpoint.name
        consumer_group = _option_string(options, "ConsumerGroup", "consumerGroup") or "$Default"
        partition_filter = _option_string(options, "PartitionId", "partitionId") or "*"
        start_from_earliest = _option_bool(options, False, "StartFromEarliest", "startFromEarliest")
        cursor_key = f"{hub_name}|{consumer_group}|{partition_filter}"
        with self._lock:
            rows = self._event_hubs.get(hub_name, [])
            offset = self._event_hub_offsets.get(cursor_key)
            if offset is None:
                offset = 0 if start_from_earliest else len(rows)

            for idx in range(offset, len(rows)):
                row = rows[idx]
                if partition_filter != "*" and str(row.get("partition_id", "")) != partition_filter:
                    continue
                self._event_hub_offsets[cursor_key] = idx + 1
                return _clone_payload(row["payload"])

            self._event_hub_offsets[cursor_key] = len(rows)
            return None

    def produce_push(self, endpoint: EndpointDefinition, payload: TrackingPayload) -> TrackingPayload:
        options = _as_options_dict(endpoint.push_diffusion)
        topic = (
            _option_string(options, "TopicPath", "topicPath")
            or _option_string(options, "Channel", "channel")
            or endpoint.name
        )
        with self._lock:
            rows = self._push_topics.setdefault(topic, [])
            rows.append({"payload": _clone_payload(payload), "timestamp_ms": _now_ms()})
        return _clone_payload(payload)

    def consume_push(self, endpoint: EndpointDefinition) -> Optional[TrackingPayload]:
        options = _as_options_dict(endpoint.push_diffusion)
        topic = (
            _option_string(options, "TopicPath", "topicPath")
            or _option_string(options, "Channel", "channel")
            or endpoint.name
        )
        subscriber_id = _option_string(options, "SubscriberId", "subscriberId") or endpoint.name
        start_from_earliest = _option_bool(options, True, "StartFromEarliest", "startFromEarliest")
        cursor_key = f"{topic}|{subscriber_id}"
        with self._lock:
            rows = self._push_topics.get(topic, [])
            offset = self._push_offsets.get(cursor_key)
            if offset is None:
                offset = 0 if start_from_earliest else len(rows)
            if offset >= len(rows):
                self._push_offsets[cursor_key] = offset
                return None
            self._push_offsets[cursor_key] = offset + 1
            return _clone_payload(rows[offset]["payload"])


_PROTOCOL_BUS = _InMemoryProtocolBus()


class CallbackAdapter:
    def __init__(self, endpoint: EndpointDefinition) -> None:
        self._endpoint = endpoint
        self._auto_tracking_index = 0

    def initialize(self) -> None:
        return

    def produce(self, payload: Optional[TrackingPayload] = None) -> Optional[TrackingPayload]:
        if self._endpoint.mode != "Produce":
            return None

        resolved = self._prepare_produced_payload(payload)
        delegate = self._endpoint.delegate
        if delegate and callable(delegate.produce):
            return delegate.produce(resolved)
        return resolved

    def consume(self) -> Optional[TrackingPayload]:
        if self._endpoint.mode != "Consume":
            return None

        delegate = self._endpoint.delegate
        if delegate and callable(delegate.consume):
            return delegate.consume()
        return self._default_payload()

    def _default_payload(self) -> TrackingPayload:
        return {
            "headers": dict(self._endpoint.message_headers),
            "body": self._endpoint.message_payload,
            "contentType": self._endpoint.content_type,
        }

    def _prepare_produced_payload(self, payload: Optional[TrackingPayload] = None) -> TrackingPayload:
        resolved = _normalize_tracking_payload(payload or self._default_payload())
        if _resolve_payload_tracking_id(self._endpoint, resolved) or not self._endpoint.auto_generate_tracking_id_when_missing:
            return resolved
        self._auto_tracking_index += 1
        return _inject_generated_tracking_id(
            resolved,
            self._endpoint.tracking_field,
            f"{self._endpoint.name}-auto-{self._auto_tracking_index}",
        )


def _invoke_delegate_callback(callback: Callable[..., Any], *args: Any) -> Any:
    result = callback(*args)
    if asyncio.iscoroutine(result):
        return asyncio.run(result)
    return result


def _resolve_payload_tracking_id(endpoint: EndpointDefinition, payload: TrackingPayload) -> Optional[str]:
    from .correlation import TrackingFieldSelector

    selector = TrackingFieldSelector.parse(_normalize_tracking_field_input(endpoint.tracking_field))
    return selector.extract(payload)


def _http_response_body_required(endpoint: EndpointDefinition) -> bool:
    http_options = endpoint.http
    if http_options is None:
        return False

    response_source = str(http_options.response_source or "None").strip().lower()
    if response_source == "responsebody":
        return True

    tracking_payload_source = str(http_options.tracking_payload_source or "Request").strip().lower()
    if tracking_payload_source != "response":
        return False

    selector = _normalize_tracking_field_input(endpoint.tracking_field).strip().lower()
    return not selector.startswith("header:")


def _inject_generated_tracking_id(payload: TrackingPayload, selector: Any, tracking_id: str) -> TrackingPayload:
    normalized = _normalize_tracking_payload(payload)
    selector_text = _normalize_tracking_field_input(selector)
    if selector_text.lower().startswith("header:"):
        header_name = selector_text[len("header:") :].strip()
        headers = dict(normalized.get("headers") or {})
        if header_name:
            headers[header_name] = tracking_id
        normalized["headers"] = headers
        return normalized

    if selector_text.lower().startswith("json:"):
        path = selector_text[len("json:") :].strip()
        if path.startswith("$."):
            path = path[2:]
        normalized["body"] = _set_json_path_value(normalized.get("body"), path, tracking_id)
    return normalized


def _set_json_path_value(body: Any, path: str, value: str) -> Dict[str, Any]:
    target = copy.deepcopy(body) if isinstance(body, dict) else {}
    segments = [segment for segment in str(path or "").split(".") if segment]
    if not segments:
        return target

    current = target
    for segment in segments[:-1]:
        next_value = current.get(segment)
        if not isinstance(next_value, dict):
            next_value = {}
            current[segment] = next_value
        current = next_value
    current[segments[-1]] = value
    return target


def _normalize_delegate_timestamp(value: Any) -> Any:
    if value is None:
        return datetime.now(timezone.utc).isoformat()
    if isinstance(value, datetime):
        return value.astimezone(timezone.utc).isoformat()
    return value


def _normalize_delegate_produce_result(
    endpoint: EndpointDefinition,
    request_payload: TrackingPayload,
    callback_result: Any,
) -> TrackingPayload:
    request_tracking_id = _resolve_payload_tracking_id(endpoint, request_payload)
    if isinstance(callback_result, ProducedMessageResult):
        success = bool(callback_result.is_success)
        timestamp_utc = _normalize_delegate_timestamp(callback_result.timestamp_utc)
        error_message = callback_result.error_message
        response_payload = callback_result.response_payload
    elif isinstance(callback_result, dict) and any(
        key in callback_result
        for key in (
            "IsSuccess",
            "isSuccess",
            "TimestampUtc",
            "timestampUtc",
            "ErrorMessage",
            "errorMessage",
            "ResponsePayload",
            "responsePayload",
        )
    ):
        success = bool(callback_result.get("IsSuccess", callback_result.get("isSuccess", True)))
        timestamp_utc = _normalize_delegate_timestamp(
            callback_result.get("TimestampUtc", callback_result.get("timestampUtc"))
        )
        error_message = callback_result.get("ErrorMessage", callback_result.get("errorMessage"))
        response_payload = callback_result.get("ResponsePayload", callback_result.get("responsePayload"))
    else:
        payload = _normalize_tracking_payload(callback_result if callback_result is not None else request_payload)
        payload["producedUtc"] = payload.get("producedUtc") or datetime.now(timezone.utc).isoformat()
        if request_tracking_id and not _resolve_payload_tracking_id(endpoint, payload):
            payload = _inject_generated_tracking_id(payload, endpoint.tracking_field, request_tracking_id)
        return payload

    payload = _normalize_tracking_payload(response_payload if response_payload is not None else request_payload)
    payload["producedUtc"] = payload.get("producedUtc") or timestamp_utc
    if success and request_tracking_id and not _resolve_payload_tracking_id(endpoint, payload):
        payload = _inject_generated_tracking_id(payload, endpoint.tracking_field, request_tracking_id)
    payload["__delegateSuccess"] = success
    if not success:
        payload["__delegateErrorMessage"] = (
            str(error_message or "").strip()
            or "Delegate stream producer reported an unknown failure."
        )
    return payload


def _normalize_delegate_consumed_message(message: Any) -> Optional[TrackingPayload]:
    if message is None:
        return None
    if isinstance(message, ConsumedMessage):
        payload = _normalize_tracking_payload(message.payload)
        payload["producedUtc"] = payload.get("producedUtc") or _normalize_delegate_timestamp(message.timestamp_utc)
        return payload
    if isinstance(message, dict) and (
        "Payload" in message
        or "payload" in message
        or "TimestampUtc" in message
        or "timestampUtc" in message
    ):
        payload = _normalize_tracking_payload(message.get("Payload", message.get("payload")))
        payload["producedUtc"] = payload.get("producedUtc") or _normalize_delegate_timestamp(
            message.get("TimestampUtc", message.get("timestampUtc"))
        )
        return payload
    return _normalize_tracking_payload(message)


class HttpEndpointAdapter(CallbackAdapter):
    def __init__(self, endpoint: EndpointDefinition) -> None:
        super().__init__(endpoint)
        self._consume_queue: list[TrackingPayload] = []
        self._oauth_token: Optional[Dict[str, Any]] = None

    def produce(self, payload: Optional[TrackingPayload] = None) -> Optional[TrackingPayload]:
        if self._endpoint.mode != "Produce":
            return None

        resolved = self._prepare_produced_payload(payload)
        http_options = self._endpoint.http
        if http_options is None or not http_options.url:
            return super().produce(resolved)

        headers = dict(resolved.get("headers", {}))
        headers.setdefault("Content-Type", self._endpoint.content_type)
        self._apply_auth_headers(headers, http_options)
        body = resolved.get("body")
        body_bytes = _build_http_request_body(
            body=body,
            body_type=http_options.body_type,
            content_type=headers.get("Content-Type", self._endpoint.content_type),
        )
        request = Request(http_options.url, data=body_bytes, method=http_options.method or "POST")
        for key, value in headers.items():
            request.add_header(str(key), str(value))

        with urlopen(request, timeout=_resolve_request_timeout_seconds(http_options)) as response:  # noqa: S310
            status = int(getattr(response, "status", 200))
            if status >= 400:
                raise RuntimeError(f"HTTP adapter request failed with status {status}.")
            response_headers = _headers_to_dict(response.headers)
            response_bytes = response.read() if _http_response_body_required(self._endpoint) else b""
            response_text = response_bytes.decode("utf-8", errors="replace") if response_bytes else ""
        result_payload = _build_http_produce_result(
            request_payload=resolved,
            response_status=status,
            response_headers=response_headers,
            response_text=response_text,
            response_source=http_options.response_source,
        )
        tracking_payload_source = str(http_options.tracking_payload_source or "Request").strip().lower()
        if tracking_payload_source == "response":
            response_payload = {
                "headers": dict(response_headers),
                "body": _parse_maybe_json(response_text),
                "contentType": response_headers.get("content-type") or headers.get("Content-Type", self._endpoint.content_type),
                "producedUtc": resolved.get("producedUtc"),
            }
            if _resolve_payload_tracking_id(self._endpoint, result_payload) is None:
                result_payload = response_payload
        return result_payload

    def consume(self) -> Optional[TrackingPayload]:
        if self._endpoint.mode != "Consume":
            return None

        if self._consume_queue:
            return self._consume_queue.pop(0)

        http_options = self._endpoint.http
        if http_options and callable(http_options.consume_poll):
            return http_options.consume_poll()
        if not http_options or not http_options.url:
            return super().consume()

        method = http_options.method or "GET"
        headers: Dict[str, str] = {}
        self._apply_auth_headers(headers, http_options)
        request = Request(http_options.url, method=method)
        for key, value in headers.items():
            request.add_header(str(key), str(value))

        with urlopen(request, timeout=_resolve_request_timeout_seconds(http_options)) as response:  # noqa: S310
            status = int(getattr(response, "status", 200))
            if status >= 400:
                _sleep_for_poll_interval(self._endpoint)
                return None
            payload_text = response.read().decode("utf-8", errors="replace")

        parsed = _parse_maybe_json(payload_text)
        consume_array_path = (
            http_options.consume_array_path
            if _is_non_empty_string(http_options.consume_array_path)
            else ("$" if bool(http_options.consume_json_array_response) else None)
        )
        rows = _normalize_consumed_payload_rows(parsed, consume_array_path)
        if not rows:
            _sleep_for_poll_interval(self._endpoint)
            return None
        self._consume_queue.extend(rows[1:])
        _sleep_for_poll_interval(self._endpoint)
        return rows[0]

    def _apply_auth_headers(self, headers: Dict[str, str], http_options: HttpEndpointOptions) -> None:
        auth = http_options.auth
        if auth is None:
            return

        mode = _resolve_http_auth_mode(auth)
        header_name = str(auth.token_header_name or "Authorization").strip() or "Authorization"
        if mode == "basic":
            username = _require_non_empty_string(auth.username, "Http Basic auth requires username.")
            password = _require_non_empty_string(auth.password, "Http Basic auth requires password.")
            token = base64.b64encode(f"{username}:{password}".encode("utf-8")).decode("ascii")
            headers[header_name] = f"Basic {token}"
        elif mode == "bearer":
            headers[header_name] = f"Bearer {_require_non_empty_string(auth.bearer_token, 'Http Bearer auth requires bearer_token.')}"
        elif mode == "oauth2clientcredentials":
            headers[header_name] = f"Bearer {self._resolve_oauth_token(http_options)}"

    def _resolve_oauth_token(self, http_options: HttpEndpointOptions) -> str:
        auth = http_options.auth
        if auth is None:
            return ""
        oauth_options = auth.oauth2_client_credentials

        now_ms = _now_ms()
        if self._oauth_token and int(self._oauth_token.get("expires_at_ms", 0)) > (now_ms + 5000):
            return str(self._oauth_token.get("access_token", ""))

        token_url = _require_non_empty_string(
            _first_non_empty_string(
                auth.token_url,
                oauth_options.token_endpoint if oauth_options else None,
            ),
            "Http OAuth2 client credentials requires token_url.",
        )
        client_id = _require_non_empty_string(
            _first_non_empty_string(
                auth.client_id,
                oauth_options.client_id if oauth_options else None,
            ),
            "Http OAuth2 client credentials requires client_id.",
        )
        client_secret = _require_non_empty_string(
            _first_non_empty_string(
                auth.client_secret,
                oauth_options.client_secret if oauth_options else None,
            ),
            "Http OAuth2 client credentials requires client_secret.",
        )
        form_data = {
            "grant_type": "client_credentials",
            "client_id": client_id,
            "client_secret": client_secret,
        }
        resolved_scopes = []
        if isinstance(auth.scopes, list):
            resolved_scopes = [str(x).strip() for x in auth.scopes if str(x).strip()]
        if not resolved_scopes and oauth_options and isinstance(oauth_options.scopes, list):
            resolved_scopes = [str(x).strip() for x in oauth_options.scopes if str(x).strip()]

        scope_text = str(auth.scope or "").strip()
        if not scope_text and resolved_scopes:
            scope_text = " ".join(resolved_scopes)
        if scope_text:
            form_data["scope"] = scope_text
        if _is_non_empty_string(auth.audience):
            form_data["audience"] = str(auth.audience).strip()
        if oauth_options:
            for key, value in (oauth_options.additional_form_fields or {}).items():
                if _is_non_empty_string(key):
                    form_data[str(key).strip()] = "" if value is None else str(value)
        for key, value in (auth.additional_form_fields or {}).items():
            if _is_non_empty_string(key):
                form_data[str(key).strip()] = "" if value is None else str(value)

        request = Request(
            token_url,
            data=urlencode(form_data).encode("utf-8"),
            method="POST",
        )
        request.add_header("Content-Type", "application/x-www-form-urlencoded")
        for key, value in (http_options.token_request_headers or {}).items():
            if _is_non_empty_string(key):
                request.add_header(str(key), str(value))

        with urlopen(request, timeout=_resolve_request_timeout_seconds(http_options)) as response:  # noqa: S310
            if int(getattr(response, "status", 200)) >= 400:
                raise RuntimeError("OAuth2 token request failed.")
            token_payload = _parse_maybe_json(response.read().decode("utf-8", errors="replace"))

        if not isinstance(token_payload, dict):
            raise RuntimeError("OAuth2 token response must be a JSON object.")
        access_token = _require_non_empty_string(
            token_payload.get("access_token"),
            "OAuth2 token response did not include access_token.",
        )
        expires_in_seconds = max(int(_option_number(token_payload, "expires_in", "expiresIn", "ExpiresIn") or 1), 1)
        self._oauth_token = {
            "access_token": access_token,
            "expires_at_ms": now_ms + (expires_in_seconds * 1000),
        }
        return access_token


class KafkaEndpointAdapter(CallbackAdapter):
    def __init__(self, endpoint: EndpointDefinition) -> None:
        super().__init__(endpoint)
        self._options = _as_options_dict(endpoint.kafka)
        self._producer = self._create_producer() if endpoint.mode == "Produce" and not endpoint.delegate else None
        self._consumer = self._create_consumer() if endpoint.mode == "Consume" and not endpoint.delegate else None

    def produce(self, payload: Optional[TrackingPayload] = None) -> Optional[TrackingPayload]:
        if self._endpoint.mode != "Produce":
            return None
        resolved = self._prepare_produced_payload(payload)
        delegate = self._endpoint.delegate
        if delegate and callable(delegate.produce):
            return delegate.produce(resolved)
        if self._producer is None:
            raise RuntimeError("Kafka endpoint is not configured in Produce mode.")
        topic = _option_string(self._options, "Topic", "topic") or self._endpoint.name
        headers, content_type = _payload_headers_with_content_type(resolved, self._endpoint.content_type)
        body = _payload_body_to_bytes(resolved.get("body"), content_type)
        record_headers = [(str(key), value.encode("utf-8")) for key, value in headers.items()]
        future = self._producer.send(topic, value=body, headers=record_headers)
        try:
            metadata = future.get(timeout=10)
        except Exception as error:  # noqa: BLE001
            raise RuntimeError(f"Kafka produce failed: {error}") from error
        if metadata is None:
            raise RuntimeError("Kafka message was not persisted.")
        return _clone_payload_with_headers(resolved, headers)

    def consume(self) -> Optional[TrackingPayload]:
        if self._endpoint.mode != "Consume":
            return None
        delegate = self._endpoint.delegate
        if delegate and callable(delegate.consume):
            return delegate.consume()
        if self._consumer is None:
            raise RuntimeError("Kafka endpoint is not configured in Consume mode.")
        try:
            records = self._consumer.poll(timeout_ms=max(int(_option_number(self._options, "PollTimeoutMs", "pollTimeoutMs") or 100), 1), max_records=1)
        except Exception as error:  # noqa: BLE001
            return None if error.__class__.__name__.lower().endswith("consumeerror") else (_raise_runtime("Kafka consume failed", error))
        for topic_partition in records:
            batch = records.get(topic_partition) or []
            if not batch:
                continue
            record = batch[0]
            headers = {
                str(key): value.decode("utf-8", errors="replace") if isinstance(value, (bytes, bytearray)) else str(value or "")
                for key, value in (getattr(record, "headers", None) or [])
            }
            content_type = headers.get("content-type") or self._endpoint.content_type
            return {
                "headers": headers,
                "body": _payload_body_from_bytes(getattr(record, "value", b""), content_type),
                "contentType": content_type,
            }
        return None

    def _create_producer(self) -> Any:
        config = _build_kafka_client_config(self._options)
        kafka_module = _require_module("kafka", "kafka-python")
        producer_class = getattr(kafka_module, "KafkaProducer", None)
        if producer_class is None:
            raise RuntimeError("Kafka transport requires kafka.KafkaProducer.")
        return producer_class(**config)

    def _create_consumer(self) -> Any:
        config = _build_kafka_client_config(self._options)
        config["group_id"] = _option_string(self._options, "ConsumerGroupId", "consumerGroupId")
        config["auto_offset_reset"] = (
            "earliest" if _option_bool(self._options, True, "StartFromEarliest", "startFromEarliest") else "latest"
        )
        kafka_module = _require_module("kafka", "kafka-python")
        consumer_class = getattr(kafka_module, "KafkaConsumer", None)
        if consumer_class is None:
            raise RuntimeError("Kafka transport requires kafka.KafkaConsumer.")
        topic = _option_string(self._options, "Topic", "topic") or self._endpoint.name
        return consumer_class(topic, **config)


class RabbitMqEndpointAdapter(CallbackAdapter):
    def __init__(self, endpoint: EndpointDefinition) -> None:
        super().__init__(endpoint)
        self._options = _as_options_dict(endpoint.rabbit_mq)
        self._connection: Any = None
        self._channel: Any = None
        if not endpoint.delegate:
            self._connection, self._channel = self._create_connection_and_channel()
            queue_name = _option_string(self._options, "QueueName", "queueName")
            if queue_name:
                self._channel.queue_declare(
                    queue=queue_name,
                    durable=_option_bool(self._options, True, "Durable", "durable"),
                    exclusive=False,
                    auto_delete=False,
                )

    def produce(self, payload: Optional[TrackingPayload] = None) -> Optional[TrackingPayload]:
        if self._endpoint.mode != "Produce":
            return None
        resolved = self._prepare_produced_payload(payload)
        delegate = self._endpoint.delegate
        if delegate and callable(delegate.produce):
            return delegate.produce(resolved)
        if self._channel is None:
            raise RuntimeError("RabbitMQ endpoint is not configured in Produce mode.")
        headers, content_type = _payload_headers_with_content_type(resolved, self._endpoint.content_type)
        routing_key = (
            _option_string(self._options, "RoutingKey", "routingKey")
            or _option_string(self._options, "QueueName", "queueName")
            or self._endpoint.name
        )
        exchange = _option_string(self._options, "Exchange", "exchange")
        body = _payload_body_to_bytes(resolved.get("body"), content_type)
        properties = _create_rabbitmq_basic_properties(
            headers,
            content_type,
            2 if _option_bool(self._options, True, "Durable", "durable") else 1,
        )
        self._channel.basic_publish(
            exchange=exchange,
            routing_key=routing_key,
            body=body,
            properties=properties,
        )
        return _clone_payload_with_headers(resolved, headers)

    def consume(self) -> Optional[TrackingPayload]:
        if self._endpoint.mode != "Consume":
            return None
        delegate = self._endpoint.delegate
        if delegate and callable(delegate.consume):
            return delegate.consume()
        if self._channel is None:
            raise RuntimeError("RabbitMQ endpoint is not configured in Consume mode.")
        queue_name = _option_string(self._options, "QueueName", "queueName")
        method, properties, body = self._channel.basic_get(
            queue=queue_name,
            auto_ack=_option_bool(self._options, False, "AutoAck", "autoAck"),
        )
        if method is None:
            return None
        if not _option_bool(self._options, False, "AutoAck", "autoAck"):
            self._channel.basic_ack(delivery_tag=method.delivery_tag)
        headers = {}
        raw_headers = getattr(properties, "headers", None)
        if isinstance(raw_headers, dict):
            headers = {
                str(key): value.decode("utf-8", errors="replace") if isinstance(value, (bytes, bytearray)) else str(value or "")
                for key, value in raw_headers.items()
            }
        content_type = str(getattr(properties, "content_type", "") or headers.get("content-type") or self._endpoint.content_type)
        return {
            "headers": headers,
            "body": _payload_body_from_bytes(body, content_type),
            "contentType": content_type,
        }

    def _create_connection_and_channel(self) -> tuple[Any, Any]:
        config = _build_rabbitmq_config(self._options)
        pika_module = _require_module("pika", "pika")
        parameters_class = getattr(pika_module, "ConnectionParameters", None)
        credentials_class = getattr(pika_module, "PlainCredentials", None)
        connection_class = getattr(pika_module, "BlockingConnection", None)
        if parameters_class is None or credentials_class is None or connection_class is None:
            raise RuntimeError("RabbitMQ transport requires pika.ConnectionParameters, pika.PlainCredentials, and pika.BlockingConnection.")
        credentials = credentials_class(config["user_name"], config["password"])
        parameters = parameters_class(
            host=config["host_name"],
            port=config["port"],
            virtual_host=config["virtual_host"],
            credentials=credentials,
            client_properties=config["client_properties"],
            ssl_options=_build_rabbitmq_ssl_options(pika_module) if config["use_ssl"] else None,
        )
        connection = connection_class(parameters)
        return connection, connection.channel()


class NatsEndpointAdapter(CallbackAdapter):
    def __init__(self, endpoint: EndpointDefinition) -> None:
        super().__init__(endpoint)
        self._options = _as_options_dict(endpoint.nats)
        self._connection = self._create_connection() if not endpoint.delegate else None

    def produce(self, payload: Optional[TrackingPayload] = None) -> Optional[TrackingPayload]:
        if self._endpoint.mode != "Produce":
            return None
        resolved = self._prepare_produced_payload(payload)
        delegate = self._endpoint.delegate
        if delegate and callable(delegate.produce):
            return delegate.produce(resolved)
        if self._connection is None:
            raise RuntimeError("NATS endpoint is not configured in Produce mode.")
        headers, content_type = _payload_headers_with_content_type(resolved, self._endpoint.content_type)
        subject = _option_string(self._options, "Subject", "subject") or self._endpoint.name
        self._connection.publish(subject, _payload_body_to_bytes(resolved.get("body"), content_type), headers)
        return _clone_payload_with_headers(resolved, headers)

    def initialize(self) -> None:
        if self._endpoint.mode != "Consume" or self._connection is None or self._endpoint.delegate:
            return
        subject = _option_string(self._options, "Subject", "subject") or self._endpoint.name
        queue_group = _option_string(self._options, "QueueGroup", "queueGroup")
        self._connection.ensure_subscription(subject, queue_group)

    def consume(self) -> Optional[TrackingPayload]:
        if self._endpoint.mode != "Consume":
            return None
        delegate = self._endpoint.delegate
        if delegate and callable(delegate.consume):
            return delegate.consume()
        if self._connection is None:
            raise RuntimeError("NATS endpoint is not configured in Consume mode.")
        subject = _option_string(self._options, "Subject", "subject") or self._endpoint.name
        queue_group = _option_string(self._options, "QueueGroup", "queueGroup")
        message = self._connection.consume_one(subject, queue_group, 0.1)
        if message is None:
            return None
        headers = _to_string_dict(message.get("headers"))
        content_type = headers.get("content-type") or self._endpoint.content_type
        return {
            "headers": headers,
            "body": _payload_body_from_bytes(message.get("body", b""), content_type),
            "contentType": content_type,
        }

    def _create_connection(self) -> Any:
        config = _build_nats_config(self._options)
        return _NatsSyncConnection(config)


class RedisStreamsEndpointAdapter(CallbackAdapter):
    def __init__(self, endpoint: EndpointDefinition) -> None:
        super().__init__(endpoint)
        self._options = _as_options_dict(endpoint.redis_streams)
        self._client = self._create_client() if not endpoint.delegate else None
        self._group_ready = False

    def produce(self, payload: Optional[TrackingPayload] = None) -> Optional[TrackingPayload]:
        if self._endpoint.mode != "Produce":
            return None
        resolved = self._prepare_produced_payload(payload)
        delegate = self._endpoint.delegate
        if delegate and callable(delegate.produce):
            return delegate.produce(resolved)
        if self._client is None:
            raise RuntimeError("Redis Streams endpoint is not configured in Produce mode.")
        stream_key = _option_string(self._options, "StreamKey", "streamKey") or self._endpoint.name
        headers, content_type = _payload_headers_with_content_type(resolved, self._endpoint.content_type)
        fields: Dict[str, Any] = {"body": _payload_body_to_bytes(resolved.get("body"), content_type)}
        if content_type:
            fields["content-type"] = content_type
        for key, value in headers.items():
            fields[f"header:{key}"] = value
        kwargs: Dict[str, Any] = {}
        max_length = int(_option_number(self._options, "MaxLength", "maxLength") or 0)
        if max_length > 0:
            kwargs["maxlen"] = max_length
            kwargs["approximate"] = True
        stream_id = self._client.xadd(stream_key, fields, **kwargs)
        produced = _clone_payload_with_headers(resolved, headers)
        produced_headers = dict(produced.get("headers", {}))
        produced_headers["x-stream-id"] = stream_id.decode("utf-8", errors="replace") if isinstance(stream_id, bytes) else str(stream_id)
        produced["headers"] = produced_headers
        return produced

    def consume(self) -> Optional[TrackingPayload]:
        if self._endpoint.mode != "Consume":
            return None
        delegate = self._endpoint.delegate
        if delegate and callable(delegate.consume):
            return delegate.consume()
        if self._client is None:
            raise RuntimeError("Redis Streams endpoint is not configured in Consume mode.")
        self._ensure_group()
        stream_key = _option_string(self._options, "StreamKey", "streamKey") or self._endpoint.name
        group = _option_string(self._options, "ConsumerGroup", "consumerGroup")
        consumer = _option_string(self._options, "ConsumerName", "consumerName") or f"{self._endpoint.name}-consumer"
        count = max(int(_option_number(self._options, "ReadCount", "readCount") or 50), 1)
        block_ms = max(
            int(
                _option_number(self._options, "PollIntervalMs", "pollIntervalMs")
                or self._endpoint.poll_interval_ms
                or 250
            ),
            1,
        )
        try:
            rows = self._client.xreadgroup(group, consumer, {stream_key: ">"}, count=count, block=block_ms)
        except Exception as error:  # noqa: BLE001
            if "NOGROUP" in str(error).upper():
                self._group_ready = False
                self._ensure_group()
                rows = self._client.xreadgroup(group, consumer, {stream_key: ">"}, count=count, block=block_ms)
            else:
                raise
        if not rows:
            return None
        _, entries = rows[0]
        if not entries:
            return None
        entry_id, values = entries[0]
        self._client.xack(stream_key, group, entry_id)
        payload = _redis_stream_entry_to_payload(values, self._endpoint.content_type)
        payload_headers = dict(payload.get("headers", {}))
        payload_headers["x-stream-id"] = entry_id.decode("utf-8", errors="replace") if isinstance(entry_id, bytes) else str(entry_id)
        payload["headers"] = payload_headers
        return payload

    def _create_client(self) -> Any:
        connection_string = _option_string(self._options, "ConnectionString", "connectionString")
        redis_module = _require_module("redis", "redis")
        client_class = getattr(getattr(redis_module, "Redis", None), "from_url", None)
        if not callable(client_class):
            raise RuntimeError("Redis Streams transport requires redis.Redis.from_url.")
        return client_class(connection_string, decode_responses=False)

    def _ensure_group(self) -> None:
        if self._group_ready:
            return
        stream_key = _option_string(self._options, "StreamKey", "streamKey") or self._endpoint.name
        group = _option_string(self._options, "ConsumerGroup", "consumerGroup")
        start = "0-0" if _option_bool(self._options, True, "StartFromEarliest", "startFromEarliest") else "$"
        try:
            self._client.xgroup_create(stream_key, group, id=start, mkstream=True)
        except Exception as error:  # noqa: BLE001
            if "BUSYGROUP" not in str(error).upper():
                raise
        self._group_ready = True


class AzureEventHubsEndpointAdapter(CallbackAdapter):
    def __init__(self, endpoint: EndpointDefinition) -> None:
        super().__init__(endpoint)
        self._options = _as_options_dict(endpoint.azure_event_hubs)
        self._producer = self._create_producer_client() if endpoint.mode == "Produce" and not endpoint.delegate else None
        self._partition_offsets: Dict[str, str] = {}

    def produce(self, payload: Optional[TrackingPayload] = None) -> Optional[TrackingPayload]:
        if self._endpoint.mode != "Produce":
            return None
        resolved = self._prepare_produced_payload(payload)
        delegate = self._endpoint.delegate
        if delegate and callable(delegate.produce):
            return delegate.produce(resolved)
        if self._producer is None:
            raise RuntimeError("Azure Event Hubs endpoint is not configured in Produce mode.")
        azure_module = _require_module("azure.eventhub", "azure-eventhub")
        event_data_class = getattr(azure_module, "EventData", None)
        if event_data_class is None:
            raise RuntimeError("Azure Event Hubs transport requires azure.eventhub.EventData.")
        headers, content_type = _payload_headers_with_content_type(resolved, self._endpoint.content_type)
        event_data = event_data_class(_payload_body_to_bytes(resolved.get("body"), content_type))
        if content_type:
            setattr(event_data, "content_type", content_type)
        properties = getattr(event_data, "properties", None)
        if isinstance(properties, dict):
            properties.update(headers)
        else:
            setattr(event_data, "properties", dict(headers))
        batch = self._producer.create_batch(partition_id=_resolve_event_hub_produce_partition_id(self._options) or None)
        if not batch.add(event_data):
            raise RuntimeError("Azure Event Hubs payload is too large for a single batch.")
        self._producer.send_batch(batch)
        return _clone_payload_with_headers(resolved, headers)

    def consume(self) -> Optional[TrackingPayload]:
        if self._endpoint.mode != "Consume":
            return None
        delegate = self._endpoint.delegate
        if delegate and callable(delegate.consume):
            return delegate.consume()
        consumer = self._create_consumer_client()
        try:
            event = _receive_event_hubs_event(
                consumer,
                partition_id=_option_string(self._options, "PartitionId", "partitionId"),
                consumer_group=_option_string(self._options, "ConsumerGroup", "consumerGroup") or "$Default",
                start_from_earliest=_option_bool(self._options, False, "StartFromEarliest", "startFromEarliest"),
                last_offsets=self._partition_offsets,
            )
            if event is None:
                return None
            partition_id = str(event.get("partition_id") or "")
            offset = event.get("offset")
            if partition_id and offset is not None:
                self._partition_offsets[partition_id] = str(offset)
            content_type = str(event.get("content_type") or self._endpoint.content_type)
            return {
                "headers": _to_string_dict(event.get("headers")),
                "body": _payload_body_from_bytes(event.get("body", b""), content_type),
                "contentType": content_type,
            }
        finally:
            _close_if_exists(consumer)

    def _create_producer_client(self) -> Any:
        config = _build_event_hubs_config(self._options)
        azure_module = _require_module("azure.eventhub", "azure-eventhub")
        producer_class = getattr(azure_module, "EventHubProducerClient", None)
        if producer_class is None or not hasattr(producer_class, "from_connection_string"):
            raise RuntimeError("Azure Event Hubs transport requires azure.eventhub.EventHubProducerClient.")
        return producer_class.from_connection_string(
            conn_str=config["connection_string"],
            eventhub_name=config["event_hub_name"],
        )

    def _create_consumer_client(self) -> Any:
        config = _build_event_hubs_config(self._options)
        azure_module = _require_module("azure.eventhub", "azure-eventhub")
        consumer_class = getattr(azure_module, "EventHubConsumerClient", None)
        if consumer_class is None or not hasattr(consumer_class, "from_connection_string"):
            raise RuntimeError("Azure Event Hubs transport requires azure.eventhub.EventHubConsumerClient.")
        return consumer_class.from_connection_string(
            conn_str=config["connection_string"],
            consumer_group=config["consumer_group"],
            eventhub_name=config["event_hub_name"],
        )


class PushDiffusionEndpointAdapter(CallbackAdapter):
    def __init__(self, endpoint: EndpointDefinition) -> None:
        super().__init__(endpoint)
        self._consume_queue: Queue[TrackingPayload] = Queue()
        self._consume_started = False
        self._consume_lock = threading.Lock()

    def produce(self, payload: Optional[TrackingPayload] = None) -> Optional[TrackingPayload]:
        if self._endpoint.mode != "Produce":
            return None
        resolved = self._prepare_produced_payload(payload)
        delegate = self._endpoint.delegate
        if delegate and callable(delegate.produce_async):
            tracking_id = _resolve_payload_tracking_id(self._endpoint, resolved) or ""
            request = ProducedMessageRequest(
                endpoint=self._endpoint,
                payload=_clone_payload(resolved),
                tracking_id=tracking_id,
            )
            result = _invoke_delegate_callback(delegate.produce_async, request)
            return _normalize_delegate_produce_result(self._endpoint, resolved, result)
        if delegate and callable(delegate.produce):
            result = _invoke_delegate_callback(delegate.produce, _clone_payload(resolved))
            return _normalize_delegate_produce_result(self._endpoint, resolved, result)
        raise RuntimeError("Push Diffusion endpoint is not configured in Produce mode.")

    def consume(self) -> Optional[TrackingPayload]:
        if self._endpoint.mode != "Consume":
            return None
        delegate = self._endpoint.delegate
        if delegate and callable(delegate.consume_async):
            self._ensure_consume_stream_started()
            try:
                return self._consume_queue.get_nowait()
            except QueueEmpty:
                return None
        if delegate and callable(delegate.consume):
            return _normalize_delegate_consumed_message(_invoke_delegate_callback(delegate.consume))
        raise RuntimeError("Push Diffusion endpoint is not configured in Consume mode.")

    def _ensure_consume_stream_started(self) -> None:
        with self._consume_lock:
            if self._consume_started:
                return
            self._consume_started = True

        delegate = self._endpoint.delegate
        if delegate is None or not callable(delegate.consume_async):
            return

        def on_message(message: Any) -> None:
            normalized = _normalize_delegate_consumed_message(message)
            if normalized is not None:
                self._consume_queue.put(normalized)

        def run_consume_stream() -> None:
            try:
                _invoke_delegate_callback(delegate.consume_async, on_message)
            except Exception:  # noqa: BLE001
                return

        threading.Thread(
            target=run_consume_stream,
            name=f"loadstrike-push-diffusion-consume-{self._endpoint.name}",
            daemon=True,
        ).start()


class DelegateStreamEndpointAdapter(CallbackAdapter):
    def __init__(self, endpoint: EndpointDefinition) -> None:
        super().__init__(endpoint)
        self._consume_queue: Queue[TrackingPayload] = Queue()
        self._consume_started = False
        self._consume_lock = threading.Lock()

    def produce(self, payload: Optional[TrackingPayload] = None) -> Optional[TrackingPayload]:
        if self._endpoint.mode != "Produce":
            return None

        resolved = self._prepare_produced_payload(payload)
        delegate = self._endpoint.delegate
        if delegate and callable(delegate.produce_async):
            tracking_id = _resolve_payload_tracking_id(self._endpoint, resolved) or ""
            request = ProducedMessageRequest(
                endpoint=self._endpoint,
                payload=_clone_payload(resolved),
                tracking_id=tracking_id,
            )
            result = _invoke_delegate_callback(delegate.produce_async, request)
            return _normalize_delegate_produce_result(self._endpoint, resolved, result)
        if delegate and callable(delegate.produce):
            result = _invoke_delegate_callback(delegate.produce, _clone_payload(resolved))
            return _normalize_delegate_produce_result(self._endpoint, resolved, result)
        return resolved

    def consume(self) -> Optional[TrackingPayload]:
        if self._endpoint.mode != "Consume":
            return None

        delegate = self._endpoint.delegate
        if delegate and callable(delegate.consume_async):
            self._ensure_consume_stream_started()
            try:
                return self._consume_queue.get_nowait()
            except QueueEmpty:
                return None
        if delegate and callable(delegate.consume):
            return _normalize_delegate_consumed_message(_invoke_delegate_callback(delegate.consume))
        return _normalize_tracking_payload(self._default_payload())

    def _ensure_consume_stream_started(self) -> None:
        with self._consume_lock:
            if self._consume_started:
                return
            self._consume_started = True

        delegate = self._endpoint.delegate
        if delegate is None or not callable(delegate.consume_async):
            return

        def on_message(message: Any) -> None:
            normalized = _normalize_delegate_consumed_message(message)
            if normalized is not None:
                self._consume_queue.put(normalized)

        def run_consume_stream() -> None:
            try:
                _invoke_delegate_callback(delegate.consume_async, on_message)
            except Exception:  # noqa: BLE001
                return

        threading.Thread(
            target=run_consume_stream,
            name=f"loadstrike-delegate-consume-{self._endpoint.name}",
            daemon=True,
        ).start()


class EndpointAdapterFactory:
    @staticmethod
    def create(endpoint: EndpointDefinition) -> EndpointAdapter:
        _validate_endpoint_definition(endpoint)
        kind = endpoint.kind
        if kind == "Http":
            return HttpEndpointAdapter(endpoint)
        if kind == "Kafka":
            return KafkaEndpointAdapter(endpoint)
        if kind == "RabbitMq":
            return RabbitMqEndpointAdapter(endpoint)
        if kind == "Nats":
            return NatsEndpointAdapter(endpoint)
        if kind == "RedisStreams":
            return RedisStreamsEndpointAdapter(endpoint)
        if kind == "AzureEventHubs":
            return AzureEventHubsEndpointAdapter(endpoint)
        if kind == "PushDiffusion":
            return PushDiffusionEndpointAdapter(endpoint)
        if kind == "DelegateStream":
            return DelegateStreamEndpointAdapter(endpoint)
        raise ValueError(f"Unsupported endpoint kind: {kind}")


def _validate_endpoint_definition(endpoint: EndpointDefinition) -> None:
    if endpoint is None:
        raise ValueError("Endpoint definition must be provided.")

    kind = _require_non_empty_string(getattr(endpoint, "kind", ""), "Endpoint kind must be provided.")
    mode = _require_non_empty_string(getattr(endpoint, "mode", ""), "Endpoint mode must be provided.")
    _require_non_empty_string(getattr(endpoint, "name", ""), "Endpoint name must be provided.")
    tracking_field = _require_non_empty_string(
        _normalize_tracking_field_input(getattr(endpoint, "tracking_field", "")),
        "Endpoint tracking_field must be provided.",
    )
    from .correlation import TrackingFieldSelector

    TrackingFieldSelector.parse(tracking_field)
    gather_by_field = getattr(endpoint, "gather_by_field", None)
    if gather_by_field is not None and not str(gather_by_field).strip():
        raise ValueError("GatherByField path must be provided when GatherByField is configured.")
    if gather_by_field is not None:
        TrackingFieldSelector.parse(_normalize_tracking_field_input(gather_by_field))
    poll_interval_ms = getattr(endpoint, "poll_interval_ms", None)
    if poll_interval_ms is not None and int(poll_interval_ms) <= 0:
        raise ValueError("PollInterval must be greater than zero.")
    if mode not in {"Produce", "Consume"}:
        raise ValueError(f"Unsupported endpoint mode: {mode}")

    delegate = endpoint.delegate
    has_mode_delegate = bool(
        (
            mode == "Produce"
            and delegate
            and (callable(delegate.produce) or callable(delegate.produce_async))
        )
        or (
            mode == "Consume"
            and delegate
            and (callable(delegate.consume) or callable(delegate.consume_async))
        )
    )

    if kind == "DelegateStream":
        if mode == "Produce" and not has_mode_delegate:
            raise ValueError("ProduceAsync delegate must be provided when endpoint mode is Produce.")
        if mode == "Consume" and not has_mode_delegate:
            raise ValueError("ConsumeAsync delegate must be provided when endpoint mode is Consume.")
        return

    if kind == "Http":
        _validate_http_endpoint(endpoint, mode, has_mode_delegate)
        return

    if kind == "Kafka":
        _validate_kafka_endpoint(_as_options_dict(endpoint.kafka), mode, has_mode_delegate)
        return
    if kind == "RabbitMq":
        _validate_rabbitmq_endpoint(_as_options_dict(endpoint.rabbit_mq), mode, has_mode_delegate)
        return
    if kind == "Nats":
        _validate_nats_endpoint(_as_options_dict(endpoint.nats), mode, has_mode_delegate)
        return
    if kind == "RedisStreams":
        _validate_redis_streams_endpoint(_as_options_dict(endpoint.redis_streams), mode, has_mode_delegate)
        return
    if kind == "AzureEventHubs":
        _validate_event_hubs_endpoint(_as_options_dict(endpoint.azure_event_hubs), mode, has_mode_delegate)
        return
    if kind == "PushDiffusion":
        _validate_push_diffusion_endpoint(_as_options_dict(endpoint.push_diffusion), mode, has_mode_delegate)
        return
    raise ValueError(f"Unsupported endpoint kind: {kind}")


def _validate_kafka_endpoint(options: Dict[str, Any], mode: str, has_mode_delegate: bool) -> None:
    if not has_mode_delegate and not options:
        raise ValueError(f"Kafka endpoint in {mode} mode requires protocol options or delegate callback.")
    if has_mode_delegate and not options:
        return
    _require_non_empty_string(
        _option_string(options, "BootstrapServers", "bootstrapServers"),
        "BootstrapServers must be provided for Kafka endpoint.",
    )
    _require_non_empty_string(_option_string(options, "Topic", "topic"), "Topic must be provided for Kafka endpoint.")
    if mode == "Consume":
        _require_non_empty_string(
            _option_string(options, "ConsumerGroupId", "consumerGroupId"),
            "ConsumerGroupId must be provided when Kafka endpoint mode is Consume.",
        )
    protocol = str(_option_string(options, "SecurityProtocol", "securityProtocol") or "Plaintext").strip().lower()
    if protocol in {"saslplaintext", "sasl_ssl", "saslssl", "sasl_plaintext"}:
        sasl = _nested_options(options, "Sasl", "sasl")
        if not sasl:
            raise ValueError("Sasl options must be provided for SASL Kafka security protocol.")
        mechanism = str(_option_string(sasl, "Mechanism", "mechanism") or "Plain").strip().lower()
        if mechanism == "oauthbearer":
            _require_non_empty_string(
                _option_string(
                    sasl,
                    "OAuthBearerTokenEndpointUrl",
                    "oauthBearerTokenEndpointUrl",
                    "TokenEndpoint",
                    "tokenEndpoint",
                ),
                "OAuthBearerTokenEndpointUrl must be provided when SASL mechanism is OAuthBearer.",
            )
            return
        _require_non_empty_string(
            _option_string(sasl, "Username", "username"),
            "Username must be provided for SASL authentication.",
        )
        if sasl.get("Password") is None and sasl.get("password") is None:
            raise ValueError("Password must be provided for SASL authentication.")


def _validate_rabbitmq_endpoint(options: Dict[str, Any], mode: str, has_mode_delegate: bool) -> None:
    if not has_mode_delegate and not options:
        raise ValueError(f"RabbitMq endpoint in {mode} mode requires protocol options or delegate callback.")
    if has_mode_delegate and not options:
        return
    _require_non_empty_string(_option_string(options, "HostName", "hostName"), "HostName must be provided for RabbitMQ endpoint.")
    if int(_option_number(options, "Port", "port") or 0) <= 0:
        raise ValueError("Port must be greater than zero.")
    _require_non_empty_string(_option_string(options, "UserName", "userName"), "UserName must be provided for RabbitMQ endpoint.")
    if options.get("Password") is None and options.get("password") is None:
        raise ValueError("Password must be provided for RabbitMQ endpoint.")
    if mode == "Produce":
        if not (
            _option_string(options, "RoutingKey", "routingKey")
            or _option_string(options, "QueueName", "queueName")
        ):
            raise ValueError("Either RoutingKey or QueueName must be provided for RabbitMQ producer endpoint.")
    if mode == "Consume":
        _require_non_empty_string(_option_string(options, "QueueName", "queueName"), "QueueName must be provided for RabbitMQ consumer endpoint.")


def _validate_nats_endpoint(options: Dict[str, Any], mode: str, has_mode_delegate: bool) -> None:
    if not has_mode_delegate and not options:
        raise ValueError(f"Nats endpoint in {mode} mode requires protocol options or delegate callback.")
    if has_mode_delegate and not options:
        return
    _require_non_empty_string(_option_string(options, "ServerUrl", "serverUrl"), "ServerUrl must be provided for NATS endpoint.")
    _require_non_empty_string(_option_string(options, "Subject", "subject"), "Subject must be provided for NATS endpoint.")
    username = _option_string(options, "UserName", "userName")
    if username and not _option_string(options, "Password", "password"):
        raise ValueError("Password must be provided when UserName is configured for NATS endpoint.")
    max_reconnect_attempts = int(_option_number(options, "MaxReconnectAttempts", "maxReconnectAttempts") or 0)
    if max_reconnect_attempts < 0:
        raise ValueError("MaxReconnectAttempts must be zero or greater.")


def _validate_redis_streams_endpoint(options: Dict[str, Any], mode: str, has_mode_delegate: bool) -> None:
    if not has_mode_delegate and not options:
        raise ValueError(f"RedisStreams endpoint in {mode} mode requires protocol options or delegate callback.")
    if has_mode_delegate and not options:
        return
    _require_non_empty_string(
        _option_string(options, "ConnectionString", "connectionString"),
        "ConnectionString must be provided for Redis Streams endpoint.",
    )
    _require_non_empty_string(_option_string(options, "StreamKey", "streamKey"), "StreamKey must be provided for Redis Streams endpoint.")
    if mode == "Consume":
        _require_non_empty_string(
            _option_string(options, "ConsumerGroup", "consumerGroup"),
            "ConsumerGroup must be provided when Redis Streams endpoint mode is Consume.",
        )
        _require_non_empty_string(
            _option_string(options, "ConsumerName", "consumerName"),
            "ConsumerName must be provided when Redis Streams endpoint mode is Consume.",
        )
    if int(_option_number(options, "ReadCount", "readCount") or 50) <= 0:
        raise ValueError("ReadCount must be greater than zero.")
    max_length = _option_number(options, "MaxLength", "maxLength")
    if max_length and int(max_length) <= 0:
        raise ValueError("MaxLength must be greater than zero when configured.")


def _validate_event_hubs_endpoint(options: Dict[str, Any], mode: str, has_mode_delegate: bool) -> None:
    if not has_mode_delegate and not options:
        raise ValueError(f"AzureEventHubs endpoint in {mode} mode requires protocol options or delegate callback.")
    if has_mode_delegate and not options:
        return
    _require_non_empty_string(
        _option_string(options, "ConnectionString", "connectionString"),
        "ConnectionString must be provided for Azure Event Hubs endpoint.",
    )
    _require_non_empty_string(
        _option_string(options, "EventHubName", "eventHubName"),
        "EventHubName must be provided for Azure Event Hubs endpoint.",
    )
    partition_count = _option_number(options, "PartitionCount", "partitionCount")
    if partition_count and int(partition_count) < 0:
        raise ValueError("PartitionCount must be zero or greater when configured.")


def _validate_push_diffusion_endpoint(options: Dict[str, Any], mode: str, has_mode_delegate: bool) -> None:
    if not has_mode_delegate:
        raise ValueError(f"PushDiffusion endpoint in {mode} mode requires protocol options or delegate callback.")
    _require_non_empty_string(
        _option_string(options, "ServerUrl", "serverUrl"),
        "ServerUrl must be provided for Push Diffusion endpoint.",
    )
    _require_non_empty_string(
        _option_string(options, "TopicPath", "topicPath"),
        "TopicPath must be provided for Push Diffusion endpoint.",
    )


def _validate_http_endpoint(endpoint: EndpointDefinition, mode: str, has_mode_delegate: bool) -> None:
    options = endpoint.http
    if options is None and not has_mode_delegate:
        raise ValueError(f"Http endpoint in {mode} mode requires http options or delegate callback.")

    if options is not None:
        if _is_non_empty_string(options.url):
            parsed_url = urlparse(options.url)
            if not parsed_url.scheme or not parsed_url.netloc:
                raise ValueError("Url must be an absolute URI for HTTP endpoint.")
        body_type = str(options.body_type or "Json").strip().lower()
        if body_type not in {"json", "text", "plaintext", "xml", "formurlencoded", "binary"}:
            raise ValueError(f"Unsupported Http body_type: {options.body_type}")
        response_source = str(options.response_source or "None").strip().lower()
        if response_source not in {"none", "responsebody", "responseheaders", "responsestatuscode"}:
            raise ValueError(f"Unsupported Http response_source: {options.response_source}")
        tracking_payload_source = str(options.tracking_payload_source or "Request").strip().lower()
        if tracking_payload_source not in {"request", "response"}:
            raise ValueError(f"Unsupported Http tracking_payload_source: {options.tracking_payload_source}")
        if options.request_timeout_seconds is not None and float(options.request_timeout_seconds) <= 0:
            raise ValueError("Http request_timeout_seconds must be greater than zero when specified.")
        _validate_http_auth_options(options)

    if mode == "Produce" and not has_mode_delegate:
        if options is None or not _is_non_empty_string(options.url):
            raise ValueError("Http endpoint in Produce mode requires http.url.")
    elif mode == "Consume" and not has_mode_delegate:
        has_poll = bool(options and callable(options.consume_poll))
        has_url = bool(options and _is_non_empty_string(options.url))
        if not has_poll and not has_url:
            raise ValueError("Http endpoint in Consume mode requires http.consume_poll or http.url.")


def _validate_http_auth_options(options: HttpEndpointOptions) -> None:
    auth = options.auth
    if auth is None:
        return
    if isinstance(auth, HttpAuthOptions):
        auth.validate()
        return

    mode = _resolve_http_auth_mode(auth)
    oauth_options = auth.oauth2_client_credentials
    if mode not in {"none", "basic", "bearer", "oauth2clientcredentials"}:
        raise ValueError(f"Unsupported Http auth mode: {auth.mode or auth.type}")
    if mode == "basic":
        _require_non_empty_string(auth.username, "Http Basic auth requires username.")
        _require_non_empty_string(auth.password, "Http Basic auth requires password.")
    elif mode == "bearer":
        _require_non_empty_string(auth.bearer_token, "Http Bearer auth requires bearer_token.")
    elif mode == "oauth2clientcredentials":
        _require_non_empty_string(
            _first_non_empty_string(auth.token_url, oauth_options.token_endpoint if oauth_options else None),
            "Http OAuth2 client credentials auth requires token_url.",
        )
        _require_non_empty_string(
            _first_non_empty_string(auth.client_id, oauth_options.client_id if oauth_options else None),
            "Http OAuth2 client credentials auth requires client_id.",
        )
        _require_non_empty_string(
            _first_non_empty_string(auth.client_secret, oauth_options.client_secret if oauth_options else None),
            "Http OAuth2 client credentials auth requires client_secret.",
        )


def _build_http_request_body(*, body: Any, body_type: str, content_type: str) -> Optional[bytes]:
    if body is None:
        return None

    normalized = str(body_type or "Json").strip().lower()
    if normalized in {"text", "plaintext", "xml"}:
        return str(body).encode("utf-8")
    if normalized == "binary":
        if isinstance(body, bytes):
            return body
        if isinstance(body, bytearray):
            return bytes(body)
        return str(body).encode("utf-8")
    if normalized == "formurlencoded":
        if isinstance(body, dict):
            return urlencode({str(k): "" if v is None else str(v) for k, v in body.items()}).encode("utf-8")
        return str(body).encode("utf-8")

    if isinstance(body, str) and "json" not in str(content_type or "").lower():
        return body.encode("utf-8")
    return json.dumps(body).encode("utf-8")


def _build_http_produce_result(
    *,
    request_payload: TrackingPayload,
    response_status: int,
    response_headers: Dict[str, str],
    response_text: str,
    response_source: str,
) -> TrackingPayload:
    normalized_source = str(response_source or "None").strip().lower()
    headers = _to_string_dict(request_payload.get("headers")) | response_headers
    if normalized_source == "none":
        return request_payload
    if normalized_source == "responseheaders":
        return {"headers": headers, "body": request_payload.get("body"), "producedUtc": request_payload.get("producedUtc")}
    if normalized_source == "responsestatuscode":
        return {
            "headers": _to_string_dict(request_payload.get("headers")),
            "body": {"statusCode": response_status},
            "producedUtc": request_payload.get("producedUtc"),
        }
    return {
        "headers": headers,
        "body": _parse_maybe_json(response_text),
        "producedUtc": request_payload.get("producedUtc"),
    }


def _normalize_consumed_payload_rows(value: Any, array_path: Optional[str]) -> list[TrackingPayload]:
    selected = _extract_json_path(value, array_path)
    if isinstance(selected, list):
        return [_normalize_tracking_payload(item) for item in selected]
    if selected is None:
        return []
    return [_normalize_tracking_payload(selected)]


def _normalize_tracking_payload(value: Any) -> TrackingPayload:
    if isinstance(value, dict) and ("headers" in value or "body" in value):
        normalized = TrackingPayload({
            "headers": _to_string_dict(value.get("headers")),
            "body": copy.deepcopy(value.get("body")),
            "producedUtc": value.get("producedUtc"),
            "contentType": _first_non_empty_string(value.get("contentType"), value.get("ContentType")),
        })
        for key in ("messagePayloadType", "jsonSettings", "jsonConvertSettings", "getBodyAsUtf8"):
            if key in value:
                normalized[key] = copy.deepcopy(value.get(key))
        return normalized
    return TrackingPayload({"headers": {}, "body": copy.deepcopy(value), "producedUtc": None, "contentType": None})


def _sleep_for_poll_interval(endpoint: EndpointDefinition) -> None:
    poll_interval_ms = max(int(getattr(endpoint, "poll_interval_ms", 250) or 250), 1)
    time.sleep(poll_interval_ms / 1000.0)


def _payload_headers_with_content_type(payload: TrackingPayload, default_content_type: str) -> tuple[Dict[str, str], str]:
    headers = _to_string_dict(payload.get("headers"))
    content_type = _first_non_empty_string(
        payload.get("contentType"),
        payload.get("ContentType"),
        headers.get("content-type"),
        default_content_type,
    ) or "application/json"
    headers.setdefault("content-type", content_type)
    return headers, content_type


def _payload_body_to_bytes(body: Any, content_type: str) -> bytes:
    if body is None:
        return b""
    if isinstance(body, bytes):
        return body
    if isinstance(body, bytearray):
        return bytes(body)
    if isinstance(body, memoryview):
        return body.tobytes()
    normalized_content_type = str(content_type or "").lower()
    if isinstance(body, str):
        return body.encode("utf-8")
    if "json" in normalized_content_type:
        return json.dumps(body).encode("utf-8")
    if isinstance(body, dict):
        return json.dumps(body).encode("utf-8")
    return str(body).encode("utf-8")


def _payload_body_from_bytes(body: Any, content_type: str) -> Any:
    if body is None:
        return None
    if isinstance(body, memoryview):
        body = body.tobytes()
    if isinstance(body, bytearray):
        body = bytes(body)
    if not isinstance(body, bytes):
        return body
    if not body:
        return None
    normalized_content_type = str(content_type or "").lower()
    if "json" in normalized_content_type:
        try:
            return json.loads(body.decode("utf-8"))
        except Exception:  # noqa: BLE001
            return body.decode("utf-8", errors="replace")
    if normalized_content_type.startswith("text/") or "utf-8" in normalized_content_type:
        return body.decode("utf-8", errors="replace")
    try:
        text = body.decode("utf-8")
    except UnicodeDecodeError:
        return body
    parsed = _parse_maybe_json(text)
    return parsed if parsed is not None else text


def _clone_payload_with_headers(payload: TrackingPayload, headers: Dict[str, str]) -> TrackingPayload:
    cloned = _clone_payload(payload)
    cloned["headers"] = dict(headers)
    if headers.get("content-type"):
        cloned["contentType"] = headers["content-type"]
    return cloned


def _nested_options(options: Dict[str, Any], *keys: str) -> Dict[str, Any]:
    for key in keys:
        value = options.get(key)
        if isinstance(value, dict):
            return dict(value)
        if hasattr(value, "__dict__"):
            return _as_options_dict(value)
    return {}


def _require_module(module_name: str, package_hint: str) -> Any:
    try:
        return importlib.import_module(module_name)
    except ImportError as error:
        raise RuntimeError(
            f"{module_name} is required for this LoadStrike transport. Install the '{package_hint}' package."
        ) from error


def _build_kafka_client_config(options: Dict[str, Any]) -> Dict[str, Any]:
    config: Dict[str, Any] = {
        "bootstrap_servers": _split_servers(_option_string(options, "BootstrapServers", "bootstrapServers")),
        "value_serializer": None,
        "value_deserializer": None,
        "key_serializer": None,
        "key_deserializer": None,
    }
    protocol = str(_option_string(options, "SecurityProtocol", "securityProtocol") or "Plaintext").strip().upper()
    normalized_protocol = protocol.replace("_", "")
    mapping = {
        "PLAINTEXT": "PLAINTEXT",
        "SSL": "SSL",
        "SASLPLAINTEXT": "SASL_PLAINTEXT",
        "SASLSSL": "SASL_SSL",
    }
    config["security_protocol"] = mapping.get(normalized_protocol, "PLAINTEXT")
    sasl = _nested_options(options, "Sasl", "sasl")
    mechanism = str(_option_string(sasl, "Mechanism", "mechanism") or "PLAIN").strip().upper()
    if sasl:
        config["sasl_mechanism"] = mechanism
        if _option_string(sasl, "Username", "username"):
            config["sasl_plain_username"] = _option_string(sasl, "Username", "username")
        if _option_string(sasl, "Password", "password"):
            config["sasl_plain_password"] = _option_string(sasl, "Password", "password")
        oauth_endpoint = _option_string(sasl, "OAuthBearerTokenEndpointUrl", "oauthBearerTokenEndpointUrl")
        if oauth_endpoint:
            config["sasl_oauth_token_provider"] = _StaticOAuthTokenProvider(oauth_endpoint)
    confluent_settings = _nested_options(options, "ConfluentSettings", "confluentSettings")
    config.update({str(key): value for key, value in confluent_settings.items() if value is not None})
    return config


def _build_rabbitmq_config(options: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "host_name": _option_string(options, "HostName", "hostName"),
        "port": max(int(_option_number(options, "Port", "port") or 5672), 1),
        "virtual_host": _option_string(options, "VirtualHost", "virtualHost") or "/",
        "user_name": _option_string(options, "UserName", "userName"),
        "password": str(options.get("Password") if options.get("Password") is not None else options.get("password") or ""),
        "use_ssl": _option_bool(options, False, "UseSsl", "useSsl"),
        "client_properties": _to_string_dict(_nested_options(options, "ClientProperties", "clientProperties")),
    }


def _build_nats_config(options: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "server_url": _option_string(options, "ServerUrl", "serverUrl"),
        "user_name": _option_string(options, "UserName", "userName"),
        "password": _option_string(options, "Password", "password"),
        "token": _option_string(options, "Token", "token"),
        "connection_name": _option_string(options, "ConnectionName", "connectionName"),
        "max_reconnect_attempts": int(_option_number(options, "MaxReconnectAttempts", "maxReconnectAttempts") or 60),
    }


def _build_event_hubs_config(options: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "connection_string": _option_string(options, "ConnectionString", "connectionString"),
        "event_hub_name": _option_string(options, "EventHubName", "eventHubName"),
        "consumer_group": _option_string(options, "ConsumerGroup", "consumerGroup") or "$Default",
    }


def _build_rabbitmq_ssl_options(pika_module: Any) -> Any:
    ssl_context = ssl.create_default_context()
    ssl_options_class = getattr(pika_module, "SSLOptions", None)
    return ssl_options_class(ssl_context) if callable(ssl_options_class) else None


def _create_rabbitmq_basic_properties(headers: Dict[str, str], content_type: str, delivery_mode: int) -> Any:
    try:
        pika_module = _require_module("pika", "pika")
        properties_class = getattr(pika_module, "BasicProperties", None)
        if callable(properties_class):
            return properties_class(
                headers=headers,
                content_type=content_type,
                delivery_mode=delivery_mode,
            )
    except RuntimeError:
        pass

    return type(
        "_RabbitProperties",
        (),
        {
            "headers": headers,
            "content_type": content_type,
            "delivery_mode": delivery_mode,
        },
    )()


def _redis_stream_entry_to_payload(values: Any, default_content_type: str) -> TrackingPayload:
    decoded: Dict[str, Any] = {}
    if isinstance(values, dict):
        for key, value in values.items():
            normalized_key = key.decode("utf-8", errors="replace") if isinstance(key, (bytes, bytearray)) else str(key)
            decoded[normalized_key] = value
    headers: Dict[str, str] = {}
    body_bytes = b""
    content_type = _first_non_empty_string(decoded.get("content-type"), default_content_type) or default_content_type
    for key, value in decoded.items():
        if key.lower() == "body":
            body_bytes = value if isinstance(value, bytes) else str(value).encode("utf-8")
        elif key.lower() == "content-type":
            content_type = str(value.decode("utf-8", errors="replace") if isinstance(value, (bytes, bytearray)) else value)
        elif key.lower().startswith("header:"):
            header_key = key.split(":", 1)[1]
            header_value = value.decode("utf-8", errors="replace") if isinstance(value, (bytes, bytearray)) else str(value)
            headers[header_key] = header_value
    return {
        "headers": headers,
        "body": _payload_body_from_bytes(body_bytes, content_type),
        "contentType": content_type,
    }


def _receive_event_hubs_event(
    consumer: Any,
    *,
    partition_id: str,
    consumer_group: str,
    start_from_earliest: bool,
    last_offsets: Dict[str, str],
) -> Optional[Dict[str, Any]]:
    batch_holder: List[tuple[Any, List[Any]]] = []
    azure_module = _require_module("azure.eventhub", "azure-eventhub")
    event_position_class = getattr(azure_module, "EventPosition", None)
    starting_position: Any = "-1" if start_from_earliest else "@latest"
    if partition_id and partition_id in last_offsets and callable(getattr(event_position_class, "from_offset", None)):
        starting_position = event_position_class.from_offset(last_offsets[partition_id], inclusive=False)

    def on_event_batch(partition_context: Any, events: List[Any]) -> None:
        if events:
            batch_holder.append((partition_context, list(events)))
        _close_if_exists(consumer)

    receive_kwargs: Dict[str, Any] = {
        "on_event_batch": on_event_batch,
        "max_batch_size": 1,
        "max_wait_time": 0.1,
        "starting_position": starting_position,
    }
    if partition_id:
        receive_kwargs["partition_id"] = partition_id
    consumer.receive_batch(**receive_kwargs)
    if not batch_holder:
        return None
    partition_context, events = batch_holder[0]
    if not events:
        return None
    event = events[0]
    body_bytes = b""
    body_reader = getattr(event, "body", None)
    if callable(body_reader):
        body_bytes = b"".join(bytes(part) for part in body_reader())
    elif isinstance(body_reader, (bytes, bytearray, memoryview)):
        body_bytes = bytes(body_reader)
    headers = {}
    properties = getattr(event, "properties", None)
    if isinstance(properties, dict):
        headers = _to_string_dict(properties)
    return {
        "partition_id": str(getattr(partition_context, "partition_id", "") or partition_id),
        "offset": getattr(event, "offset", None),
        "headers": headers,
        "content_type": getattr(event, "content_type", None),
        "body": body_bytes,
    }


def _close_if_exists(value: Any) -> None:
    close = getattr(value, "close", None)
    if callable(close):
        close()


def _split_servers(value: str) -> Union[List[str], str]:
    rows = [part.strip() for part in str(value or "").split(",") if part.strip()]
    if len(rows) == 1:
        return rows[0]
    return rows


class _StaticOAuthTokenProvider:
    def __init__(self, token_endpoint: str) -> None:
        self._token_endpoint = token_endpoint

    def token(self) -> str:
        return self._token_endpoint


class _NatsSyncConnection:
    def __init__(self, config: Dict[str, Any]) -> None:
        self._config = dict(config)
        self._loop = asyncio.new_event_loop()
        self._client = self._loop.run_until_complete(self._connect())
        self._subscriptions: Dict[str, Any] = {}

    async def _connect(self) -> Any:
        nats_module = _require_module("nats", "nats-py")
        connect = getattr(nats_module, "connect", None)
        if not callable(connect):
            raise RuntimeError("NATS transport requires nats.connect.")
        kwargs: Dict[str, Any] = {
            "servers": [self._config["server_url"]],
            "max_reconnect_attempts": self._config["max_reconnect_attempts"],
        }
        if self._config["user_name"]:
            kwargs["user"] = self._config["user_name"]
            kwargs["password"] = self._config["password"]
        if self._config["token"]:
            kwargs["token"] = self._config["token"]
        if self._config["connection_name"]:
            kwargs["name"] = self._config["connection_name"]
        return await connect(**kwargs)

    def publish(self, subject: str, body: bytes, headers: Dict[str, str]) -> None:
        self._loop.run_until_complete(self._client.publish(subject, body, headers=headers or None))
        self._loop.run_until_complete(self._client.flush())

    def ensure_subscription(self, subject: str, queue_group: Optional[str]) -> Any:
        key = f"{subject}|{queue_group or ''}"
        subscription = self._subscriptions.get(key)
        if subscription is not None:
            return subscription
        subscription = self._loop.run_until_complete(
            self._client.subscribe(subject, queue=queue_group or None)
        )
        try:
            self._loop.run_until_complete(self._client.flush())
        except Exception as error:  # noqa: BLE001
            if key in self._subscriptions:
                self._subscriptions.pop(key, None)
            raise RuntimeError("Failed to initialize NATS subscription.") from error
        self._subscriptions[key] = subscription
        return subscription

    def consume_one(self, subject: str, queue_group: str, timeout_seconds: float) -> Optional[Dict[str, Any]]:
        subscription = self.ensure_subscription(subject, queue_group)
        try:
            message = self._loop.run_until_complete(subscription.next_msg(timeout=timeout_seconds))
        except Exception:  # noqa: BLE001
            return None
        headers = {}
        raw_headers = getattr(message, "header", None)
        if raw_headers is not None:
            try:
                headers = {str(key): str(raw_headers[key]) for key in raw_headers.keys()}
            except Exception:  # noqa: BLE001
                headers = {}
        return {
            "headers": headers,
            "body": bytes(getattr(message, "data", b"") or b""),
        }

    def close(self) -> None:
        try:
            self._loop.run_until_complete(self._client.drain())
        except Exception:  # noqa: BLE001
            try:
                self._loop.run_until_complete(self._client.close())
            except Exception:  # noqa: BLE001
                pass
        try:
            self._loop.close()
        except Exception:  # noqa: BLE001
            pass

    def __del__(self) -> None:
        self.close()


def _extract_json_path(value: Any, array_path: Optional[str]) -> Any:
    if not _is_non_empty_string(array_path):
        return value
    path = str(array_path).strip()
    if path.startswith("$."):
        path = path[2:]
    elif path == "$":
        path = ""
    if not path:
        return value

    current = value
    tokens = path.replace("[", ".").replace("]", "").split(".")
    tokens = [token for token in tokens if token]
    for token in tokens:
        if current is None:
            return None
        if isinstance(current, list):
            try:
                index = int(token)
            except ValueError:
                return None
            if index < 0 or index >= len(current):
                return None
            current = current[index]
            continue
        if not isinstance(current, dict) or token not in current:
            return None
        current = current[token]
    return current


def _parse_maybe_json(value: str) -> Any:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return value


def _headers_to_dict(headers: Any) -> Dict[str, str]:
    if headers is None:
        return {}
    items = getattr(headers, "items", None)
    if callable(items):
        try:
            return {str(k): str(v) for k, v in items()}
        except Exception:  # noqa: BLE001
            return {}
    return {}


def _as_options_dict(value: Any) -> Dict[str, Any]:
    if value is None:
        return {}
    if isinstance(value, dict):
        return dict(value)
    if hasattr(value, "__dict__"):
        mapped = dict(getattr(value, "__dict__", {}))
        extra = mapped.get("extra")
        if isinstance(extra, dict):
            merged = dict(extra)
            for key, row in mapped.items():
                if key == "extra":
                    continue
                if row is None:
                    continue
                merged[key] = row
                if "_" in key:
                    parts = [part for part in key.split("_") if part]
                    if parts:
                        pascal = "".join(part[:1].upper() + part[1:] for part in parts)
                        camel = parts[0] + "".join(part[:1].upper() + part[1:] for part in parts[1:])
                        merged[pascal] = row
                        merged[camel] = row
                elif key:
                    merged[key[:1].upper() + key[1:]] = row
            return merged
        return {str(k): v for k, v in mapped.items() if not k.startswith("_") and v is not None}
    return {}


def _to_string_dict(value: Any) -> Dict[str, str]:
    if not isinstance(value, dict):
        return {}
    return {str(k): "" if v is None else str(v) for k, v in value.items()}


def _resolve_http_auth_mode(auth: HttpAuthOptions) -> str:
    return str(auth.mode or auth.type or "None").strip().lower()


def _resolve_request_timeout_seconds(options: Optional[HttpEndpointOptions]) -> float:
    if options is None:
        return 30.0
    value = options.request_timeout_seconds
    if isinstance(value, bool):
        return 30.0
    if isinstance(value, (int, float)) and float(value) > 0:
        return float(value)
    if isinstance(value, str) and value.strip():
        try:
            parsed = float(value.strip())
            if parsed > 0:
                return parsed
        except ValueError:
            return 30.0
    return 30.0


def _first_non_empty_string(*values: Any) -> Optional[str]:
    for value in values:
        if isinstance(value, str) and value.strip():
            return value.strip()
    return None


def _is_non_empty_string(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


def _normalize_tracking_field_input(value: Any) -> str:
    if value is None:
        return ""
    path = getattr(value, "path", None)
    kind = getattr(value, "kind", None)
    if path is not None and kind is not None:
        return f"{str(kind).strip().lower()}:{str(path).strip()}".strip(":")
    location = getattr(value, "location", None)
    if path is not None and location is not None:
        return f"{str(location).strip().lower()}:{str(path).strip()}".strip(":")
    return str(value).strip()


def _require_non_empty_string(value: Any, message: str) -> str:
    if _is_non_empty_string(value):
        return str(value).strip()
    raise ValueError(message)


def _now_ms() -> int:
    return int(time.time() * 1000)


def _clone_payload(payload: TrackingPayload) -> TrackingPayload:
    headers = payload.get("headers", {})
    cloned = {
        "headers": dict(headers if isinstance(headers, dict) else {}),
        "body": copy.deepcopy(payload.get("body")),
        "producedUtc": payload.get("producedUtc"),
        "contentType": payload.get("contentType"),
    }
    for key in ("messagePayloadType", "jsonSettings", "jsonConvertSettings", "getBodyAsUtf8"):
        if key in payload:
            cloned[key] = copy.deepcopy(payload.get(key))
    return cloned


def _option_string(options: Dict[str, Any], *keys: str) -> str:
    for key in keys:
        value = options.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""


def _option_number(options: Dict[str, Any], *keys: str) -> float:
    for key in keys:
        value = options.get(key)
        if isinstance(value, bool):
            continue
        if isinstance(value, (int, float)):
            return float(value)
        if isinstance(value, str) and value.strip():
            try:
                return float(value.strip())
            except ValueError:
                continue
    return 0.0


def _option_bool(options: Dict[str, Any], fallback: bool, *keys: str) -> bool:
    for key in keys:
        value = options.get(key)
        if isinstance(value, bool):
            return value
        if isinstance(value, (int, float)):
            return float(value) != 0.0
        if isinstance(value, str) and value.strip():
            normalized = value.strip().lower()
            if normalized in {"true", "1", "yes"}:
                return True
            if normalized in {"false", "0", "no"}:
                return False
    return fallback


def _partition_from_key(value: str, partition_count: int) -> str:
    if not value:
        return "0"
    count = max(int(partition_count), 1)
    hashed = 0
    for character in value:
        hashed = ((hashed << 5) - hashed) + ord(character)
        hashed &= 0xFFFFFFFF
    return str(abs(hashed) % count)


def _resolve_event_hub_produce_partition_id(options: Dict[str, Any]) -> Optional[str]:
    partition_id = _option_string(options, "PartitionId", "partitionId")
    if partition_id:
        return partition_id
    partition_key = _option_string(options, "PartitionKey", "partitionKey")
    if not partition_key:
        return None
    partition_count = int(_option_number(options, "PartitionCount", "partitionCount") or 4)
    return _partition_from_key(partition_key, partition_count)


def _raise_runtime(prefix: str, error: Exception) -> None:
    raise RuntimeError(f"{prefix}: {error}") from error
