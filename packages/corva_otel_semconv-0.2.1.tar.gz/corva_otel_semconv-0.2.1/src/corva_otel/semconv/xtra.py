X_PROCESS_RUN_ID = 'x.process.run.id'
"""
Unique ID of a process run, changes only upon restart of the process
"""

X_THREAD_RUN_ID = 'x.thread.run.id'
"""
Unique ID of a thread run, changes only upon restart of the thread
"""

X_FAAS_REMAINING_TIME_MILLISECONDS = 'x.faas.remaining_time_milliseconds'
"""
The number of milliseconds left before the FAAS execution times out
"""
