"""Policy-as-Code support for cokodo-agent.

This module provides:
1. Access to the bundled Rego policy packs (under
   ``cokodo_agent/bundled/agent/policies/<kind>/``).
2. Project data collection that produces JSON input documents matching the
   schema declared by each policy pack (see the METADATA blocks of the
   respective ``.rego`` files).
3. A thin wrapper around ``conftest test`` so users can validate their
   project locally with one command.

Design notes
------------
- We do **not** embed a Rego evaluator. Conftest / OPA is the source of
  truth and any CI can run the same policies independently.
- Only the data-collection contract is owned by cokodo-agent; the policies
  themselves are versioned files under ``bundled/agent/policies/`` and may
  be vendored into a project later.
"""

from __future__ import annotations

import json
import re
import shutil
import subprocess
import tomllib
from dataclasses import dataclass
from pathlib import Path
from typing import Any

# Bundled policies live alongside ``bundled/agent/templates/``.
_BUNDLED_POLICY_ROOT = (
    Path(__file__).resolve().parent / "bundled" / "agent" / "policies"
)

# Heading detector for release notes (level-2 markdown headings).
_H2_RE = re.compile(r"^##\s+(.+?)\s*$", re.MULTILINE)
# Strip leading numbering like "1. ", "1.2 ", "Step 1: " from a heading
# so callers can compare against canonical labels (e.g. "Compatibility").
_HEADING_PREFIX_RE = re.compile(
    r"^(?:\d+(?:\.\d+)*\.?\s+|step\s+\d+\s*[:\-]\s*)",
    re.IGNORECASE,
)

# Recognised policy kinds (kept explicit so typos surface as CLI errors).
KNOWN_POLICY_KINDS = ("release",)


# ---------------------------------------------------------------------------
# Bundled policy access
# ---------------------------------------------------------------------------


def list_bundled_policies() -> list[str]:
    """Return policy pack names available in the bundle."""
    if not _BUNDLED_POLICY_ROOT.is_dir():
        return []
    return sorted(
        p.name for p in _BUNDLED_POLICY_ROOT.iterdir()
        if p.is_dir() and any(p.glob("*.rego"))
    )


def bundled_policy_dir(name: str) -> Path:
    """Return the directory containing the Rego files for a policy pack.

    Raises FileNotFoundError if the pack is not bundled.
    """
    candidate = _BUNDLED_POLICY_ROOT / name
    if not candidate.is_dir() or not any(candidate.glob("*.rego")):
        available = list_bundled_policies()
        raise FileNotFoundError(
            f"policy pack '{name}' not found; available: {available}"
        )
    return candidate


# ---------------------------------------------------------------------------
# Bundled hook templates
# ---------------------------------------------------------------------------

_BUNDLED_HOOK_ROOT = (
    Path(__file__).resolve().parent / "bundled" / "agent" / "templates" / "hooks"
)


def bundled_hook_path(name: str = "pre-commit.policy") -> Path:
    """Return the absolute path of a bundled git hook template.

    Raises FileNotFoundError when the requested template is not shipped.
    """
    candidate = _BUNDLED_HOOK_ROOT / name
    if not candidate.is_file():
        available = (
            sorted(p.name for p in _BUNDLED_HOOK_ROOT.iterdir() if p.is_file())
            if _BUNDLED_HOOK_ROOT.is_dir()
            else []
        )
        raise FileNotFoundError(
            f"bundled hook '{name}' not found; available: {available}"
        )
    return candidate


# ---------------------------------------------------------------------------
# conftest install command matrix (used by `co policy doctor`)
# ---------------------------------------------------------------------------

# Ordered by preference per platform; first detected manager wins for --install.
_INSTALL_COMMANDS: dict[str, list[tuple[str, list[str]]]] = {
    "Windows": [
        (
            "winget",
            [
                "winget",
                "install",
                "--id",
                "OpenPolicyAgent.Conftest",
                "-e",
                "--source",
                "winget",
            ],
        ),
        ("scoop", ["scoop", "install", "conftest"]),
        ("choco", ["choco", "install", "conftest", "-y"]),
    ],
    "Darwin": [
        ("brew", ["brew", "install", "conftest"]),
    ],
    "Linux": [
        ("brew", ["brew", "install", "conftest"]),
        ("apt-get", ["sudo", "apt-get", "install", "-y", "conftest"]),
        ("dnf", ["sudo", "dnf", "install", "-y", "conftest"]),
        ("pacman", ["sudo", "pacman", "-S", "--noconfirm", "conftest"]),
    ],
}


def detect_install_commands(
    system: str | None = None,
) -> list[tuple[str, list[str]]]:
    """Return ``[(manager, argv), ...]`` for managers actually present on PATH.

    Empty list when no recognised manager is installed for ``system``.
    """
    import platform as _platform

    sys_name = system or _platform.system()
    candidates = _INSTALL_COMMANDS.get(sys_name, [])
    return [(mgr, argv) for mgr, argv in candidates if shutil.which(mgr) is not None]


def list_install_commands(
    system: str | None = None,
) -> list[tuple[str, list[str]]]:
    """Return all candidate install commands for ``system`` (regardless of presence)."""
    import platform as _platform

    sys_name = system or _platform.system()
    return list(_INSTALL_COMMANDS.get(sys_name, []))


# ---------------------------------------------------------------------------
# Data collection
# ---------------------------------------------------------------------------


@dataclass
class ReleaseNoteSummary:
    exists: bool
    size: int
    sections: list[str]

    def to_dict(self) -> dict[str, Any]:
        return {"exists": self.exists, "size": self.size, "sections": self.sections}


def _summarise_release_note(path: Path) -> ReleaseNoteSummary:
    if not path.is_file():
        return ReleaseNoteSummary(exists=False, size=0, sections=[])
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return ReleaseNoteSummary(exists=True, size=path.stat().st_size, sections=[])
    sections = [
        _HEADING_PREFIX_RE.sub("", m.group(1).strip()).strip()
        for m in _H2_RE.finditer(text)
    ]
    return ReleaseNoteSummary(exists=True, size=len(text), sections=sections)


def _collect_version_state(project_root: Path) -> tuple[dict[str, dict[str, Any]], dict[str, ReleaseNoteSummary]]:
    """Return (version_state_per_track, release_note_summaries)."""
    state_path = project_root / ".agent" / "project" / "version-state.toml"
    if not state_path.is_file():
        return {}, {}
    try:
        with state_path.open("rb") as fh:
            data = tomllib.load(fh)
    except (OSError, tomllib.TOMLDecodeError):
        return {}, {}

    tracks_raw = data.get("tracks") or {}
    tracks: dict[str, dict[str, Any]] = {}
    notes: dict[str, ReleaseNoteSummary] = {}
    for name, track in tracks_raw.items():
        if not isinstance(track, dict):
            continue
        entry = {
            "enabled": bool(track.get("enabled", False)),
            "current_release": str(track.get("current_release", "")),
            "working_version": str(track.get("working_version", "")),
            "status": str(track.get("status", "")),
            "tag": str(track.get("tag", "")),
            "rollback_tag": str(track.get("rollback_tag", "")),
            "release_note": str(track.get("release_note", "")),
        }
        tracks[name] = entry

        rn = entry["release_note"]
        if rn and rn not in notes:
            notes[rn] = _summarise_release_note(project_root / rn)
    return tracks, notes


def _count_recently_completed(project_root: Path) -> int:
    """Count list items in the 'Recently Completed' section of status.md."""
    status_path = project_root / ".agent" / "project" / "status.md"
    if not status_path.is_file():
        return 0
    try:
        text = status_path.read_text(encoding="utf-8")
    except OSError:
        return 0
    # Find heading then count markdown bullet lines until next heading.
    lines = text.splitlines()
    inside = False
    count = 0
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("#"):
            if inside:
                break
            heading = stripped.lstrip("#").strip().lower()
            if "recently completed" in heading:
                inside = True
            continue
        if inside and (stripped.startswith("- ") or stripped.startswith("* ")):
            count += 1
    return count


def _has_active_change(project_root: Path) -> bool:
    active = project_root / ".agent" / "project" / "changes" / ".active"
    return active.is_file() and active.read_text(encoding="utf-8").strip() != ""


def collect_release_data(project_root: Path) -> dict[str, Any]:
    """Build the JSON input document consumed by the ``release`` policy pack."""
    project_root = project_root.resolve()
    tracks, notes = _collect_version_state(project_root)
    return {
        "version_state": tracks,
        "release_notes": {path: summary.to_dict() for path, summary in notes.items()},
        "status": {
            "recently_completed_count": _count_recently_completed(project_root),
            "has_active_change": _has_active_change(project_root),
        },
    }


def collect_data(kind: str, project_root: Path) -> dict[str, Any]:
    """Dispatch to the data collector for ``kind``."""
    if kind == "release":
        return collect_release_data(project_root)
    raise ValueError(
        f"unknown policy kind '{kind}'; known: {list(KNOWN_POLICY_KINDS)}"
    )


# ---------------------------------------------------------------------------
# Conftest invocation
# ---------------------------------------------------------------------------


@dataclass
class ConftestResult:
    returncode: int
    stdout: str
    stderr: str


CONFTEST_MISSING_EXIT = 2

CONFTEST_INSTALL_HINT = (
    "conftest is not on PATH. Install it from https://www.conftest.dev/install/ "
    "(e.g. `scoop install conftest` on Windows, `brew install conftest` on macOS, "
    "or download a release binary). The bundled policy files are located via "
    "`co policy show <name>`."
)


def conftest_available() -> bool:
    return shutil.which("conftest") is not None


def run_conftest(
    policy_dir: Path,
    data: dict[str, Any],
    namespace: str = "release",
) -> ConftestResult:
    """Pipe ``data`` as JSON to ``conftest test`` against ``policy_dir``.

    Caller must check ``conftest_available()`` first; this function will
    raise ``FileNotFoundError`` if conftest is missing.
    """
    if not conftest_available():
        raise FileNotFoundError(CONFTEST_INSTALL_HINT)

    payload = json.dumps(data).encode("utf-8")
    cmd = [
        "conftest",
        "test",
        "--policy",
        str(policy_dir),
        "--namespace",
        namespace,
        "--parser",
        "json",
        "-",
    ]
    completed = subprocess.run(  # noqa: S603 - explicit argv, no shell
        cmd,
        input=payload,
        capture_output=True,
        check=False,
    )
    return ConftestResult(
        returncode=completed.returncode,
        stdout=completed.stdout.decode("utf-8", errors="replace"),
        stderr=completed.stderr.decode("utf-8", errors="replace"),
    )
