"""Helpers for structured version-governance state transitions."""

from __future__ import annotations

import copy
import re
import tomllib
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Any


START_NEXT_VERSION_STATUSES = ("planning", "developing", "frozen")
PREPARE_RELEASE_SOURCE_STATUSES = ("planning", "developing", "frozen")
CUT_RELEASE_SOURCE_STATUSES = ("frozen",)


@dataclass
class StartNextVersionPlan:
    track: str
    previous_working_version: str
    current_release: str
    next_working_version: str
    next_status: str
    release_note_relative: Path
    next_tag: str
    release_note_exists: bool
    next_state: dict[str, Any]
    release_note_content: str


@dataclass
class PrepareReleasePlan:
    track: str
    current_release: str
    working_version: str
    previous_status: str
    next_status: str
    release_note_relative: Path
    release_note_exists: bool
    release_tag: str
    next_state: dict[str, Any]


@dataclass
class CutReleasePlan:
    track: str
    current_release: str
    working_version: str
    previous_status: str
    next_status: str
    release_note_relative: Path
    release_note_exists: bool
    canonical_source: str
    release_tag: str
    previous_rollback_tag: str
    next_rollback_tag: str
    next_state: dict[str, Any]


def _parse_version_key(version: str) -> tuple[Any, ...]:
    parts = re.split(r"[.\-+_]", version.strip())
    normalized: list[Any] = []
    for part in parts:
        if not part:
            continue
        normalized.append(int(part) if part.isdigit() else part.lower())
    return tuple(normalized)


def load_version_state(path: Path) -> dict[str, Any]:
    with path.open("rb") as f:
        data = tomllib.load(f)
    return data if isinstance(data, dict) else {}


def toml_escape(value: str) -> str:
    escaped = value.replace("\\", "\\\\").replace('"', '\\"')
    return f'"{escaped}"'


def render_list(items: list[Any], indent: str = "") -> list[str]:
    if not items:
        return [f"{indent}[]"]
    lines = [f"{indent}["]
    for item in items:
        if isinstance(item, str):
            lines.append(f"{indent}  {toml_escape(item)},")
        else:
            lines.append(f"{indent}  {item!r},")
    lines.append(f"{indent}]")
    return lines


def render_value(value: Any, indent: str = "") -> list[str]:
    if isinstance(value, bool):
        return [f"{indent}{str(value).lower()}"]
    if isinstance(value, str):
        return [f"{indent}{toml_escape(value)}"]
    if isinstance(value, list):
        return render_list(value, indent=indent)
    if isinstance(value, int):
        return [f"{indent}{value}"]
    raise TypeError(f"Unsupported TOML value type: {type(value)!r}")


def write_version_state(path: Path, state: dict[str, Any]) -> None:
    tracks = state.get("tracks", {})
    preferred_track_order = ["primary", "client", "backend", "protocol"]
    preferred_root_order = ["schema_version", "updated_at", "owner"]
    preferred_key_order = [
        "enabled",
        "display_name",
        "canonical_source",
        "derived_sync",
        "current_release",
        "working_version",
        "status",
        "release_note",
        "tag",
        "rollback_tag",
        "rollback_note",
        "protocol",
        "compatibility",
        "scope_refs",
        "build_script",
        "artifact_kinds",
        "deploy_script",
        "deploy_targets",
    ]

    lines = [
        "# Machine-readable version governance state.",
        "# Human-readable policy lives in `project/versioning.md`.",
        "",
    ]

    root_keys = [key for key in preferred_root_order if key in state]
    root_keys += sorted(key for key in state.keys() if key not in root_keys and key != "tracks")
    for root_key in root_keys:
        rendered = render_value(state[root_key])[0]
        lines.append(f"{root_key} = {rendered}")

    if tracks:
        lines.append("")

    ordered_tracks = [name for name in preferred_track_order if name in tracks]
    ordered_tracks += sorted(name for name in tracks.keys() if name not in ordered_tracks)
    for index, track_name in enumerate(ordered_tracks):
        lines.append(f"[tracks.{track_name}]")
        track_state = tracks[track_name]
        ordered_keys = [key for key in preferred_key_order if key in track_state]
        ordered_keys += sorted(key for key in track_state.keys() if key not in ordered_keys)
        for key in ordered_keys:
            rendered = render_value(track_state[key])
            lines.append(f"{key} = {rendered[0]}")
            if len(rendered) > 1:
                lines.extend(rendered[1:])
        if index != len(ordered_tracks) - 1:
            lines.append("")

    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _derive_release_note_path(track_state: dict[str, Any], track: str, version: str) -> Path:
    current_path_raw = track_state.get("release_note")
    if isinstance(current_path_raw, str) and current_path_raw.strip():
        current_path = Path(current_path_raw.strip())
        filename = current_path.name
        replacement_candidates = [
            str(track_state.get("working_version", "")).strip(),
            str(track_state.get("current_release", "")).strip(),
        ]
        for candidate in replacement_candidates:
            if candidate and candidate in filename:
                return current_path.with_name(filename.replace(candidate, version))
        return current_path.parent / f"{track}-release-note-{version}{current_path.suffix or '.md'}"
    return Path("docs/operations") / f"{track}-release-note-{version}.md"


def _derive_next_tag(existing_tag: str, track: str, version: str, *, multi_track: bool) -> str:
    existing_tag = existing_tag.strip()
    patterns = [
        re.compile(r"^(.*?/v)[^/]+$"),
        re.compile(r"^(.*?/)[^/]+$"),
        re.compile(r"^(v)[^/]+$"),
    ]
    for pattern in patterns:
        match = pattern.match(existing_tag)
        if match:
            return f"{match.group(1)}{version}"
    if multi_track:
        return f"{track}/v{version}"
    return f"v{version}"


def _render_release_note(
    *,
    track: str,
    version: str,
    current_release: str,
    canonical_source: str,
    release_tag: str,
    rollback_tag: str,
    compatibility: list[str],
    scope_refs: list[str],
) -> str:
    compatibility_lines = "\n".join(f"- `{item}`" for item in compatibility) if compatibility else "- `TBD`"
    scope_ref_lines = "\n".join(f"- `{item}`" for item in scope_refs) if scope_refs else "- `TBD`"
    rollback_display = rollback_tag or "TBD"
    return f"""# Release Note

> Track: `{track}`
> Version: `{version}`
> Previous stable: `{current_release}`
> Canonical version source: `{canonical_source}`
> Release tag: `{release_tag}`
> Rollback tag: `{rollback_display}`

---

## 1. Release Summary

- Track: `{track}`
- Target version: `{version}`
- Previous stable: `{current_release}`
- Release owner: `TBD`
- Release date: `TBD`

## 2. Scope Included

- `TBD`
- `TBD`

## 3. Scope Excluded / Deferred

- `TBD`

## 4. Compatibility Notes

{compatibility_lines}

## 5. Validation Checklist

- `TBD`
- `TBD`

## 6. Known Risks

- `TBD`

## 7. Rollback

- Rollback tag: `{rollback_display}`
- Rollback guidance: `TBD`

## 8. Traceability

- Canonical source: `{canonical_source}`
- Release tag: `{release_tag}`
- Scope refs:
{scope_ref_lines}
"""


def plan_start_next_version(
    state: dict[str, Any],
    *,
    track: str,
    version: str,
    status: str,
) -> StartNextVersionPlan:
    tracks = state.get("tracks")
    if not isinstance(tracks, dict) or track not in tracks:
        raise KeyError(f"Track {track!r} not found in version-state")
    if status not in START_NEXT_VERSION_STATUSES:
        raise ValueError(f"Unsupported status {status!r}")

    track_state_obj = tracks[track]
    if not isinstance(track_state_obj, dict):
        raise TypeError(f"Track {track!r} state is not a TOML table")

    track_state = copy.deepcopy(track_state_obj)
    current_release = str(track_state.get("current_release", "")).strip()
    previous_working_version = str(track_state.get("working_version", "")).strip()
    previous_status = str(track_state.get("status", "")).strip()
    canonical_source = str(track_state.get("canonical_source", "")).strip()
    if not current_release:
        raise ValueError(f"Track {track!r} is missing current_release")
    if not previous_working_version:
        raise ValueError(f"Track {track!r} is missing working_version")
    if not canonical_source:
        raise ValueError(f"Track {track!r} is missing canonical_source")

    multi_track = len(
        [
            name
            for name, state_obj in tracks.items()
            if isinstance(state_obj, dict) and state_obj.get("enabled", True) is not False
        ]
    ) > 1
    next_release_note_relative = _derive_release_note_path(track_state, track, version)
    existing_tag = str(track_state.get("tag", "")).strip()
    next_tag = _derive_next_tag(existing_tag, track, version, multi_track=multi_track)

    track_state["working_version"] = version
    track_state["status"] = status
    track_state["release_note"] = next_release_note_relative.as_posix()
    track_state["tag"] = next_tag
    if previous_status in {"released", "hotfix"} and existing_tag:
        track_state["rollback_tag"] = existing_tag

    next_state = copy.deepcopy(state)
    next_state["tracks"][track] = track_state
    if "updated_at" in next_state:
        next_state["updated_at"] = date.today().isoformat()

    compatibility = track_state.get("compatibility", [])
    scope_refs = track_state.get("scope_refs", [])
    compatibility_items = compatibility if isinstance(compatibility, list) else []
    scope_ref_items = scope_refs if isinstance(scope_refs, list) else []
    release_note_content = _render_release_note(
        track=track,
        version=version,
        current_release=current_release,
        canonical_source=canonical_source,
        release_tag=next_tag,
        rollback_tag=str(track_state.get("rollback_tag", "")).strip(),
        compatibility=[str(item) for item in compatibility_items],
        scope_refs=[str(item) for item in scope_ref_items],
    )

    return StartNextVersionPlan(
        track=track,
        previous_working_version=previous_working_version,
        current_release=current_release,
        next_working_version=version,
        next_status=status,
        release_note_relative=next_release_note_relative,
        next_tag=next_tag,
        release_note_exists=False,
        next_state=next_state,
        release_note_content=release_note_content,
    )


def plan_open_next_version_from_release(
    state: dict[str, Any],
    *,
    track: str,
    version: str,
) -> StartNextVersionPlan:
    tracks = state.get("tracks")
    if not isinstance(tracks, dict) or track not in tracks:
        raise KeyError(f"Track {track!r} not found in version-state")

    track_state_obj = tracks[track]
    if not isinstance(track_state_obj, dict):
        raise TypeError(f"Track {track!r} state is not a TOML table")

    previous_status = str(track_state_obj.get("status", "")).strip()
    current_release = str(track_state_obj.get("current_release", "")).strip()
    if previous_status != "released":
        raise ValueError(
            f"Track {track!r} must already be 'released' before opening the next version "
            f"(got {previous_status!r})"
        )
    if not current_release:
        raise ValueError(f"Track {track!r} is missing current_release")
    if _parse_version_key(version) <= _parse_version_key(current_release):
        raise ValueError(
            f"Next version {version!r} must be newer than current_release {current_release!r}"
        )

    return plan_start_next_version(state, track=track, version=version, status="developing")


def plan_prepare_release(
    state: dict[str, Any],
    *,
    track: str,
) -> PrepareReleasePlan:
    tracks = state.get("tracks")
    if not isinstance(tracks, dict) or track not in tracks:
        raise KeyError(f"Track {track!r} not found in version-state")

    track_state_obj = tracks[track]
    if not isinstance(track_state_obj, dict):
        raise TypeError(f"Track {track!r} state is not a TOML table")

    track_state = copy.deepcopy(track_state_obj)
    current_release = str(track_state.get("current_release", "")).strip()
    working_version = str(track_state.get("working_version", "")).strip()
    previous_status = str(track_state.get("status", "")).strip()
    release_note_raw = str(track_state.get("release_note", "")).strip()
    release_tag = str(track_state.get("tag", "")).strip()

    if not current_release:
        raise ValueError(f"Track {track!r} is missing current_release")
    if not working_version:
        raise ValueError(f"Track {track!r} is missing working_version")
    if previous_status not in PREPARE_RELEASE_SOURCE_STATUSES:
        raise ValueError(
            f"Track {track!r} status must be one of {', '.join(PREPARE_RELEASE_SOURCE_STATUSES)} "
            f"before prepare-release (got {previous_status!r})"
        )
    if not release_note_raw:
        raise ValueError(f"Track {track!r} is missing release_note")
    if not release_tag:
        raise ValueError(f"Track {track!r} is missing tag")

    next_state = copy.deepcopy(state)
    next_state["tracks"][track]["status"] = "frozen"
    if "updated_at" in next_state:
        next_state["updated_at"] = date.today().isoformat()

    release_note_relative = Path(release_note_raw)
    return PrepareReleasePlan(
        track=track,
        current_release=current_release,
        working_version=working_version,
        previous_status=previous_status,
        next_status="frozen",
        release_note_relative=release_note_relative,
        release_note_exists=False,
        release_tag=release_tag,
        next_state=next_state,
    )


def plan_cut_release(
    state: dict[str, Any],
    *,
    track: str,
) -> CutReleasePlan:
    tracks = state.get("tracks")
    if not isinstance(tracks, dict) or track not in tracks:
        raise KeyError(f"Track {track!r} not found in version-state")

    track_state_obj = tracks[track]
    if not isinstance(track_state_obj, dict):
        raise TypeError(f"Track {track!r} state is not a TOML table")

    track_state = copy.deepcopy(track_state_obj)
    current_release = str(track_state.get("current_release", "")).strip()
    working_version = str(track_state.get("working_version", "")).strip()
    previous_status = str(track_state.get("status", "")).strip()
    release_note_raw = str(track_state.get("release_note", "")).strip()
    canonical_source = str(track_state.get("canonical_source", "")).strip()
    release_tag = str(track_state.get("tag", "")).strip()
    previous_rollback_tag = str(track_state.get("rollback_tag", "")).strip()

    if not current_release:
        raise ValueError(f"Track {track!r} is missing current_release")
    if not working_version:
        raise ValueError(f"Track {track!r} is missing working_version")
    if previous_status not in CUT_RELEASE_SOURCE_STATUSES:
        raise ValueError(
            f"Track {track!r} status must be one of {', '.join(CUT_RELEASE_SOURCE_STATUSES)} "
            f"before cut-release (got {previous_status!r})"
        )
    if not release_note_raw:
        raise ValueError(f"Track {track!r} is missing release_note")
    if not canonical_source:
        raise ValueError(f"Track {track!r} is missing canonical_source")
    if not release_tag:
        raise ValueError(f"Track {track!r} is missing tag")

    multi_track = len(
        [
            name
            for name, state_obj in tracks.items()
            if isinstance(state_obj, dict) and state_obj.get("enabled", True) is not False
        ]
    ) > 1
    next_rollback_tag = _derive_next_tag(release_tag, track, current_release, multi_track=multi_track)

    next_state = copy.deepcopy(state)
    next_track_state = next_state["tracks"][track]
    next_track_state["current_release"] = working_version
    next_track_state["status"] = "released"
    next_track_state["rollback_tag"] = next_rollback_tag
    if "updated_at" in next_state:
        next_state["updated_at"] = date.today().isoformat()

    release_note_relative = Path(release_note_raw)
    return CutReleasePlan(
        track=track,
        current_release=current_release,
        working_version=working_version,
        previous_status=previous_status,
        next_status="released",
        release_note_relative=release_note_relative,
        release_note_exists=False,
        canonical_source=canonical_source,
        release_tag=release_tag,
        previous_rollback_tag=previous_rollback_tag,
        next_rollback_tag=next_rollback_tag,
        next_state=next_state,
    )
