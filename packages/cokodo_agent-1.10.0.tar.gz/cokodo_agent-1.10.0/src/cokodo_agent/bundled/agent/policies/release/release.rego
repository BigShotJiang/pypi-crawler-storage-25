# METADATA
# title: Release governance — version-state consistency
# description: |
#   Enforces invariants on project/version-state.toml as collected by
#   `co policy data release`. Input shape:
#     {
#       "version_state": {
#         "<track>": {
#           "enabled": bool,
#           "current_release": "x.y.z",
#           "working_version": "x.y.z",
#           "status": "developing|frozen|released|hotfix|stable|deprecated|planning",
#           "tag": "<track>/vX.Y.Z[-suffix]",
#           "rollback_tag": "<track>/vX.Y.Z",
#           "release_note": "<path>"
#         }
#       },
#       "release_notes": { "<path>": { "exists": bool, ... } },
#       "status": { ... }
#     }
package release

valid_statuses := {
    "planning", "developing", "frozen", "released",
    "hotfix", "stable", "deprecated",
}

semver_re := `^\d+\.\d+\.\d+(?:[-+][\w.\-]+)?$`

# tag accepts both styles: "vX.Y.Z" (single-track repo) or "<track>/vX.Y.Z"
# (multi-track repo). Multi-track is enforced when more than one enabled
# track exists (see deny rule below).
tag_re_simple := `^v\d+\.\d+\.\d+(?:[-+][\w.\-]+)?$`
tag_re_prefixed(track) := sprintf(`^%s/v\d+\.\d+\.\d+(?:[-+][\w.\-]+)?$`, [track])

# ---------- denies ---------------------------------------------------------

deny[msg] {
    track := input.version_state[name]
    track.enabled == true
    not regex.match(semver_re, track.current_release)
    msg := sprintf("track '%s': current_release '%s' is not semver", [name, track.current_release])
}

deny[msg] {
    track := input.version_state[name]
    track.enabled == true
    not valid_statuses[track.status]
    msg := sprintf("track '%s': status '%s' not in %v", [name, track.status, valid_statuses])
}

deny[msg] {
    track := input.version_state[name]
    track.enabled == true
    track.tag != ""
    not regex.match(tag_re_simple, track.tag)
    not regex.match(tag_re_prefixed(name), track.tag)
    msg := sprintf("track '%s': tag '%s' must match 'vX.Y.Z' or '<track>/vX.Y.Z'", [name, track.tag])
}

# When multiple tracks are enabled, the prefixed form is mandatory to keep
# tags isolated per track.
deny[msg] {
    enabled_count := count([n | input.version_state[n].enabled == true])
    enabled_count > 1
    track := input.version_state[name]
    track.enabled == true
    track.tag != ""
    not regex.match(tag_re_prefixed(name), track.tag)
    msg := sprintf("track '%s': multi-track repo requires prefixed tag '<track>/vX.Y.Z' (got '%s')", [name, track.tag])
}

deny[msg] {
    track := input.version_state[name]
    track.enabled == true
    track.status == "released"
    track.rollback_tag == ""
    msg := sprintf("track '%s': rollback_tag is required when status=released", [name])
}

deny[msg] {
    track := input.version_state[name]
    track.enabled == true
    track.release_note != ""
    note := input.release_notes[track.release_note]
    note.exists == false
    msg := sprintf("track '%s': release_note '%s' does not exist on disk", [name, track.release_note])
}
