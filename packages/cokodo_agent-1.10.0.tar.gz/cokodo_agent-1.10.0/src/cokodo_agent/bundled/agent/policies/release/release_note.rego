# METADATA
# title: Release Note section requirements
# description: |
#   Each existing release note referenced from version-state must contain
#   the canonical sections so rollback / compatibility intent is documented.
package release

required_keywords := {"compatibility", "rollback", "validation"}

# A required keyword is "present" when at least one section heading contains
# it case-insensitively (so "Compatibility Notes", "5. Rollback", and
# "Validation Checklist" all count).
present_keywords(sections) := {kw |
    kw := required_keywords[_]
    section := sections[_]
    contains(lower(section), kw)
}

deny[msg] {
    track := input.version_state[name]
    track.enabled == true
    track.release_note != ""
    note := input.release_notes[track.release_note]
    note.exists == true
    missing := required_keywords - present_keywords(note.sections)
    count(missing) > 0
    msg := sprintf(
        "track '%s': release note '%s' is missing required topics: %v",
        [name, track.release_note, missing],
    )
}

# Recently Completed cap (governance hygiene)
deny[msg] {
    n := input.status.recently_completed_count
    n > 5
    msg := sprintf("status.md 'Recently Completed' has %d entries; cap is 5 (use journal.d/)", [n])
}
