# Project Commands

> agent_protocol 常用命令

---

## Protocol Check

```bash
# 协议合规检查
python .agent/scripts/lint-protocol.py

# Token 统计
python .agent/scripts/token-counter.py
```

---

## Sync Protocol

```bash
# 同步协议到其他项目（手动）
# 复制 core/, adapters/, meta/, scripts/ 到目标项目

# 使用 history-sync 工具
python .me/scripts/sync-history.py
python .me/scripts/sync-history.py --apply
```

---

## Plan Governance

Use Cursor Plan Mode as a draft or review surface only. In this protocol:

- `.agent/project/plan/` is the canonical, shareable, MCP-discoverable plan directory.
- `.cursor/plans/` is an IDE-local draft or review copy, not the project source of truth.
- `project/changes/<name>/tasks.md` stays the execution checklist when SDD is active.

When a plan should persist across sessions or IDEs:

1. Mirror or summarize the approved plan into `.agent/project/plan/<kebab-name>.md`.
2. Update `.agent/project/plan/plan-index.md`.
3. Keep day-to-day implementation progress in `project/changes/<name>/tasks.md` when an active change exists.

---

*This file is project-specific. Update when commands change.*
