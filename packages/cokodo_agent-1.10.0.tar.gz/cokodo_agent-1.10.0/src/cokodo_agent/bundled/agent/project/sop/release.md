# SOP: Release cokodo-agent

> Authoritative release SOP. Follow every step in order.
> AI agents MUST read this file before executing any release task.
>
> **Trigger**: When user says "release", "publish", "bump version", "tag", or "push to PyPI".

---

## Pre-Release Checklist

Before starting, confirm ALL of the following:

- [ ] All intended changes are committed to `main`
- [ ] `co lint` passes (0 errors)
- [ ] `pyproject.toml` version is still at the OLD version (will be bumped in Step 1)

---

## When .agent or cokodo content changed (内容更新后、版本提交前)

If you modified **root `.agent/`** (protocol, workflows, templates, adapters) or **cokodo-agent** code/docs, complete this checklist **before** Step 1 (bump version). Ensures docs, manifest, bundled copy, and status are in sync.

| # | Item | Action |
|---|------|--------|
| 1 | Root `.agent/` changed | Sync to `cokodo-agent/src/cokodo_agent/bundled/agent/` (core/, adapters/, meta/, workflows/, templates/, start-here, manifest — exclude project/ if repo-specific). |
| 2 | Protocol / structure / workflow changed | Update `manifest.json`: `version` and/or `minor_changes` as needed. Run **`co update-checksums`** and commit the checksum file. |
| 3 | New or changed workflow, task type, or MCP resource | Update `start-here.md` (On-Demand / mappings), `manifest.json` (workflows.mappings, task_profiles), README / usage-guide (EN & CN), and adapter rules (e.g. Key Rules in agent-protocol.mdc) so they reference the new workflow or resource. |
| 4 | CLI or MCP behavior changed | Update **README** (cokodo-agent), **usage-guide** (EN/CN), and **docs/protocol-version-config.md** if version or config semantics changed. |
| 5 | Before version commit | **`status.md`** updated (Current Phase, Recently Completed, Quick Reference version/date). **`co lint`** passes. |

See also: `docs/protocol-version-config.md` (version sources), `meta/agent-protocol-rules.md` (manifest version), `meta/self-check-prompt.md` (protocol self-check before release).

---

## Step 1 — Bump Version (Single Source of Truth)

Edit exactly **two** files. No other files should contain the version number.

```bash
# File 1: cokodo-agent/pyproject.toml
version = "X.Y.Z"

# File 2: cokodo-agent/src/cokodo_agent/__init__.py  (fallback only)
__version__ = "X.Y.Z"
```

---

## Step 2 — Update status.md and journal

**Archive journal fragments first (release boundary):**
```bash
co journal-flush --for-release vX.Y.Z
```
This archives all current `Recently Completed` items to `session-journal.md` under `## vX.Y.Z Released (YYYY-MM-DD)` and leaves only the release entry in `status.md`. If there are no pending fragments, skip this sub-step.

**Then update `.agent/project/status.md` manually:**
- `Current Phase`: reflect new release
- `Active Goals`: mark release goal as Done
- `Recently Completed`: ensure only the release entry remains (1 item)
- `Quick Reference -> CLI`: update version and PyPI line
- `Last updated` date

---

## Step 3 — Commit Everything

```bash
git add cokodo-agent/pyproject.toml
git add cokodo-agent/src/cokodo_agent/__init__.py
git add .agent/project/status.md
# add any other changed files
git commit -m "feat(cokodo-agent): vX.Y.Z - <brief description>"
```

---

## Step 4 — Push main Branch

```bash
git push origin main
```

Verify push succeeded before proceeding to the tag step.

---

## Step 5 — Create and Push Tag

> **CRITICAL RULES:**
>
> 1. Tag format MUST be `vX.Y.Z` (e.g., `v1.8.3`). NEVER use `cokodo-agent/vX.Y.Z`.
>    The workflow trigger is `tags: 'v*'`. A prefix breaks CI silently.
>
> 2. The tag MUST point to HEAD **after** Step 4 is complete.
>    Always use explicit SHA, never rely on symbolic `HEAD`.
>
> 3. NEVER delete and re-push the same tag name.
>    GitHub Actions will NOT re-trigger on a re-pushed tag.
>    If a tag needs fixing: bump to next patch version instead.
>
> 4. Push tag in a SEPARATE `git push` call from the branch push.

```bash
# PowerShell (Windows)
$SHA = git rev-parse HEAD
Write-Output "Tagging commit: $SHA"
git tag -a "vX.Y.Z" "$SHA" -m "cokodo-agent vX.Y.Z"
git push origin "vX.Y.Z"
```

---

## Step 6 — Verify CI Triggered

Check GitHub Actions within 2 minutes:
```
https://github.com/dinwind/agent_protocol/actions
```

A run named "Release to PyPI" should appear with event `push` and branch `vX.Y.Z`.

**If CI does not appear within 2 minutes — DO NOT delete and re-push the tag.**
Instead:
1. Go to https://github.com/dinwind/agent_protocol/actions/workflows/release.yml
2. Click "Run workflow" -> select branch `main` -> click "Run workflow"

Note: GitHub tag push CI can have up to ~10 min delay. Wait before concluding it failed.

---

## Step 7 — Monitor CI Jobs

| Job | Expected outcome |
|-----|-----------------|
| Build distribution | Builds wheel + sdist |
| Publish to PyPI | Uploads via OIDC Trusted Publishing |
| Create GitHub Release | Creates release with auto-generated notes |
| Publish to MCP Registry | Updates registry.modelcontextprotocol.io (non-blocking) |

---

## Step 8 — Post-Release Verification

```bash
pip index versions cokodo-agent
pip install cokodo-agent==X.Y.Z
co version
```

If the local release commit and tag push are complete, open the next development iteration explicitly:

```bash
co open-next-version --track primary --version X.Y.(Z+1) --apply
```

This step updates only version-governance state (`project/version-state.toml`, the next release-note draft, and `project/status.md`). It does **not** upgrade the installed package/runtime.

---

## Known Pitfalls

| # | Pitfall | Rule |
|---|---------|------|
| 1 | Wrong tag format (`cokodo-agent/v*`) | Always `v*` only |
| 2 | Delete and re-push same tag | Never — bump patch instead |
| 3 | Tag points to wrong commit | Use explicit SHA after `git push origin main` |
| 4 | `workflow_dispatch` API returns 500 | Use GitHub web UI "Run workflow" button |
| 5 | Combined branch + tag push | Always separate `git push` calls |

See ISSUE-001, ISSUE-002 in `project/known-issues.md`.

---

## Quick Reference

```bash
VERSION="X.Y.Z"
# 1. Edit pyproject.toml + __init__.py + status.md
# 2. Commit
git add cokodo-agent/pyproject.toml cokodo-agent/src/cokodo_agent/__init__.py
git commit -m "feat(cokodo-agent): v${VERSION} - <description>"
# 3. Push branch FIRST
git push origin main
# 4. Tag with explicit SHA, v* format, SEPARATE push
$SHA = git rev-parse HEAD
git tag -a "v${VERSION}" "$SHA" -m "cokodo-agent v${VERSION}"
git push origin "v${VERSION}"
# 5. Monitor: https://github.com/dinwind/agent_protocol/actions
# 6. Open next iteration after release commit + tag push are done
co open-next-version --track primary --version X.Y.(Z+1) --apply
```

---

*Last updated: 2026-03-18 | See also: commands.md, known-issues.md*
