"""Local cross-project event discovery for Phase 1 linkage."""

from __future__ import annotations

import re
from pathlib import Path
from typing import NamedTuple

from cokodo_agent.relations import (
    _resolve_partner_path,
    _resolve_source_path,
    detect_source_type,
    load_collaborations,
    load_references,
)


class EventRecord(NamedTuple):
    """Structured row parsed from project/events/events-index.md."""

    event: str
    file: str
    kind: str
    targets: list[str]
    status: str
    updated: str
    summary: str


class RelatedEvent(NamedTuple):
    """Event discovered from a related local project."""

    source_project: str
    relation_name: str
    via: str  # "reference" | "collaboration"
    event: EventRecord


_EVENTS_INDEX = """# Events index

> **Role**: `.agent/project/events/` holds **cross-project change notices** that other local projects may need to react to.
> **Entry point for AI/MCP**: Update this file whenever you add a new event markdown so agents can discover local linkage work.
> **Scope**: Use this directory for API/schema changes, breaking behavior, shared dependency changes, process changes, or any update that may affect another local project.

## How to use

1. **Write** a new event as `events/<topic>.md` or `events/<yyyy-mm-dd>-<topic>.md`.
2. **Register** the event in the table below (path relative to `project/events/`).
3. **Targets** should name affected local projects or relations. Supported forms:
   - project directory names, e.g. `frontend`, `wsync`
   - `project:<name>`, e.g. `project:frontend`
   - `relation:<name>`, e.g. `relation:shared-api`
   - `all-local` for broad local-machine impact
4. **Status** should be one of `open`, `acknowledged`, `resolved`, or `superseded`.
5. **Read** this index when checking cross-project impact or preparing a linked change.

## Index

| Event | File | Kind | Targets | Status | Updated | Summary |
|-------|------|------|---------|--------|---------|---------|
| *(add rows as you create events)* | | | | | | |

---

*Generated/maintained by cokodo-agent — run `co scaffold` to create missing dirs.*
"""


def events_root(agent_dir: Path) -> Path:
    """Return the project/events directory."""
    return agent_dir / "project" / "events"


def events_index_path(agent_dir: Path) -> Path:
    """Return the events index path."""
    return events_root(agent_dir) / "events-index.md"


def ensure_events_dir(agent_dir: Path) -> list[str]:
    """Create project/events/events-index.md if missing."""
    created: list[str] = []
    root = agent_dir.parent
    ev_dir = events_root(agent_dir)
    ev_dir.mkdir(parents=True, exist_ok=True)
    index = events_index_path(agent_dir)
    if not index.exists():
        index.write_text(_EVENTS_INDEX, encoding="utf-8")
        created.append(str(index.relative_to(root)).replace("\\", "/"))
    return created


def load_event_records(agent_dir: Path) -> list[EventRecord]:
    """Load events from project/events/events-index.md."""
    index = events_index_path(agent_dir)
    if not index.exists():
        return []
    try:
        return parse_events_index(index.read_text(encoding="utf-8"))
    except OSError:
        return []


def parse_events_index(text: str) -> list[EventRecord]:
    """Parse the markdown event index table into records."""
    lines = text.splitlines()
    header_idx = -1
    for idx, line in enumerate(lines):
        if line.strip().lower().startswith("| event | file |"):
            header_idx = idx
            break
    if header_idx == -1 or header_idx + 1 >= len(lines):
        return []

    header = [cell.strip().lower() for cell in _split_table_row(lines[header_idx])]
    records: list[EventRecord] = []

    for line in lines[header_idx + 2:]:
        stripped = line.strip()
        if not stripped.startswith("|"):
            if records:
                break
            continue
        cells = _split_table_row(stripped)
        if len(cells) != len(header):
            continue
        row = dict(zip(header, cells, strict=False))
        event_name = row.get("event", "").strip()
        file_name = row.get("file", "").strip()
        if not event_name or not file_name or event_name.startswith("*("):
            continue
        records.append(
            EventRecord(
                event=event_name,
                file=file_name,
                kind=row.get("kind", "").strip(),
                targets=_parse_targets(row.get("targets", "")),
                status=row.get("status", "").strip() or "open",
                updated=row.get("updated", "").strip(),
                summary=row.get("summary", "").strip(),
            )
        )
    return records


def get_event_by_name(agent_dir: Path, name_or_file: str) -> EventRecord | None:
    """Find an event by title, file path, or file stem."""
    query = name_or_file.strip().lower()
    for event in load_event_records(agent_dir):
        if event.event.lower() == query:
            return event
        if event.file.lower() == query:
            return event
        if Path(event.file).stem.lower() == query:
            return event
    return None


def read_event_file(agent_dir: Path, name_or_file: str) -> tuple[EventRecord, str] | None:
    """Read a single event markdown file by event name or file path."""
    event = get_event_by_name(agent_dir, name_or_file)
    if event is None:
        return None
    safe = Path(event.file)
    if safe.is_absolute() or ".." in safe.parts:
        return None
    target = events_root(agent_dir) / safe
    if not target.exists() or not target.is_file():
        return None
    try:
        return event, target.read_text(encoding="utf-8")
    except OSError:
        return None


def collect_related_events(
    agent_dir: Path,
    *,
    status: str | None = None,
) -> list[RelatedEvent]:
    """Collect events from related local projects that target the current project."""
    current_aliases = _project_aliases(agent_dir)
    related: list[RelatedEvent] = []
    for via, relation_name, related_agent_dir, source_project in _iter_related_projects(agent_dir):
        for event in load_event_records(related_agent_dir):
            if status and event.status.lower() != status.lower():
                continue
            if _event_targets_current(event.targets, current_aliases, relation_name):
                related.append(
                    RelatedEvent(
                        source_project=source_project,
                        relation_name=relation_name,
                        via=via,
                        event=event,
                    )
                )
    return sorted(
        related,
        key=lambda item: (
            item.event.status.lower() not in {"open", "acknowledged"},
            item.source_project.lower(),
            item.event.updated,
            item.event.event.lower(),
        ),
    )


def resolve_impacted_projects(
    source_agent_dir: Path,
    event_name: str,
) -> list[tuple[str, str, str]]:
    """Resolve impacted local projects for an event.

    Returns tuples of (project_name, via, relation_name).
    """
    event = get_event_by_name(source_agent_dir, event_name)
    if event is None:
        return []

    related = _iter_related_projects(source_agent_dir)
    if not related:
        return []

    targets = {token.lower() for token in event.targets}
    if targets & {"all-local", "all", "*"}:
        return sorted(
            {(project, via, relation) for via, relation, _agent, project in related},
            key=lambda item: (item[0].lower(), item[2].lower()),
        )

    impacted: set[tuple[str, str, str]] = set()
    for via, relation_name, related_agent_dir, source_project in related:
        aliases = _project_aliases(related_agent_dir)
        relation_token = f"relation:{relation_name.lower()}"
        if relation_token in targets or relation_name.lower() in targets:
            impacted.add((source_project, via, relation_name))
            continue
        for alias in aliases:
            if alias in targets or f"project:{alias}" in targets:
                impacted.add((source_project, via, relation_name))
                break
    return sorted(impacted, key=lambda item: (item[0].lower(), item[2].lower()))


def build_local_linkage_hint(agent_dir: Path) -> str:
    """Return a short hint block about related local events."""
    related = [
        item for item in collect_related_events(agent_dir)
        if item.event.status.lower() not in {"resolved", "superseded"}
    ]
    if not related:
        return ""

    project_count = len({item.source_project for item in related})
    lines = [
        "## Local linkage events",
        f"- {len(related)} active related event(s) detected across {project_count} local project(s).",
        "- Use `get_related_events()` to inspect the linked changes before editing code.",
    ]
    for item in related[:5]:
        status = item.event.status.lower()
        target_suffix = ""
        if item.event.targets:
            target_suffix = f" -> targets: {', '.join(item.event.targets)}"
        lines.append(
            f"- {item.source_project}/{item.event.file} ({item.relation_name}, {status})"
            f": {item.event.event}"
            f" — {item.event.summary or '(no summary)'}{target_suffix}"
        )
    if len(related) > 5:
        lines.append("- ...")
    return "\n".join(lines)


def _split_table_row(line: str) -> list[str]:
    return [cell.strip() for cell in line.strip().strip("|").split("|")]


def _parse_targets(raw: str) -> list[str]:
    if not raw.strip():
        return []
    return [
        token.strip()
        for token in re.split(r"[,;]", raw)
        if token.strip()
    ]


def _project_aliases(agent_dir: Path) -> set[str]:
    aliases = {agent_dir.parent.name.lower()}
    aliases.add(agent_dir.parent.name.lower().replace("-", "_"))
    aliases.add(agent_dir.parent.name.lower().replace("_", "-"))
    return {alias for alias in aliases if alias}


def _event_targets_current(
    targets: list[str],
    current_aliases: set[str],
    relation_name: str,
) -> bool:
    if not targets:
        return False

    normalized = {token.strip().lower() for token in targets if token.strip()}
    if normalized & {"all-local", "all", "*"}:
        return True
    relation_tokens = {relation_name.lower(), f"relation:{relation_name.lower()}"}
    if normalized & relation_tokens:
        return True
    for alias in current_aliases:
        if alias in normalized or f"project:{alias}" in normalized:
            return True
    return False


def _iter_related_projects(
    agent_dir: Path,
) -> list[tuple[str, str, Path, str]]:
    project_root = agent_dir.parent
    related: dict[str, tuple[str, str, Path, str]] = {}

    for ref in load_references(agent_dir):
        resolved = _resolve_source_path(ref.source, project_root)
        if detect_source_type(resolved) != "project":
            continue
        related[str(resolved.resolve())] = (
            "reference",
            ref.name,
            resolved,
            resolved.parent.name,
        )

    for collab in load_collaborations(agent_dir):
        resolved = _resolve_partner_path(collab.partner, project_root)
        if detect_source_type(resolved) != "project":
            continue
        related[str(resolved.resolve())] = (
            "collaboration",
            collab.name,
            resolved,
            resolved.parent.name,
        )

    return list(related.values())
