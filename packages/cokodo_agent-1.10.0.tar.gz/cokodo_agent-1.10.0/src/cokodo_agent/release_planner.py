"""Release planner: derive next version + draft release note from git history.

Reads Conventional Commits from ``git log <last_tag>..HEAD`` and produces a
``ReleasePlan`` containing the bump kind (``major``/``minor``/``patch``/
``none``), the next version string, the parsed commits and a
``needs_review`` flag with human-readable reasons.

This module is intentionally subprocess-based (no ``gitpython`` dep) so the
behaviour is easy to mock in tests.
"""

from __future__ import annotations

import re
import subprocess
import tomllib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

BumpKind = Literal["major", "minor", "patch", "none"]

# Conventional Commit subject:  type(scope)!: subject
_SUBJECT_RE = re.compile(
    r"^(?P<type>[a-zA-Z]+)"
    r"(?:\((?P<scope>[^)]+)\))?"
    r"(?P<bang>!)?"
    r":\s+(?P<subject>.+?)\s*$"
)
# BREAKING CHANGE / BREAKING-CHANGE token in body
_BREAKING_RE = re.compile(
    r"^BREAKING[ -]CHANGE:\s*(?P<msg>.+?)$",
    re.IGNORECASE | re.MULTILINE,
)

# Recognised commit types (others trigger needs_review).
_KNOWN_TYPES = frozenset(
    {
        "feat", "fix", "perf", "refactor", "revert",
        "docs", "test", "chore", "ci", "style", "build",
    }
)
# Types that count as patch-level changes when there is no feat/breaking.
_PATCH_TYPES = frozenset({"fix", "perf", "refactor", "revert"})

# Paths whose modification raises a ⚠ rollback warning.
_MIGRATION_PATH_RE = re.compile(
    r"(?:^|/)(?:migrations?|schema|alembic|prisma|knex)/",
    re.IGNORECASE,
)

# SemVer (X.Y.Z) — pre-release / build metadata are out of scope here.
_SEMVER_RE = re.compile(r"^(\d+)\.(\d+)\.(\d+)$")


@dataclass
class ParsedCommit:
    sha: str
    type: str
    scope: str | None
    breaking: bool
    subject: str
    body: str
    raw_subject: str

    @property
    def short_sha(self) -> str:
        return self.sha[:7] if self.sha else ""


@dataclass
class ReleasePlan:
    track: str
    current_version: str
    next_version: str
    bump: BumpKind
    commits: list[ParsedCommit] = field(default_factory=list)
    breaking_changes: list[str] = field(default_factory=list)
    needs_review: bool = False
    review_reasons: list[str] = field(default_factory=list)
    previous_tag: str = ""
    has_migration_changes: bool = False

    def to_dict(self) -> dict:
        return {
            "track": self.track,
            "current_version": self.current_version,
            "next_version": self.next_version,
            "bump": self.bump,
            "previous_tag": self.previous_tag,
            "needs_review": self.needs_review,
            "review_reasons": list(self.review_reasons),
            "breaking_changes": list(self.breaking_changes),
            "has_migration_changes": self.has_migration_changes,
            "commits": [
                {
                    "sha": c.sha,
                    "type": c.type,
                    "scope": c.scope,
                    "breaking": c.breaking,
                    "subject": c.subject,
                }
                for c in self.commits
            ],
        }


# ---------------------------------------------------------------------------
# Pure parsing
# ---------------------------------------------------------------------------


def parse_commit(raw_subject: str, body: str = "", sha: str = "") -> ParsedCommit:
    """Parse one Conventional Commit subject + optional body."""
    raw_subject = raw_subject.rstrip("\n")
    m = _SUBJECT_RE.match(raw_subject)
    if not m:
        return ParsedCommit(
            sha=sha,
            type="other",
            scope=None,
            breaking=False,
            subject=raw_subject,
            body=body,
            raw_subject=raw_subject,
        )
    ctype = m.group("type").lower()
    bang = bool(m.group("bang"))
    body_breaking = bool(_BREAKING_RE.search(body or ""))
    return ParsedCommit(
        sha=sha,
        type=ctype,
        scope=m.group("scope"),
        breaking=bang or body_breaking,
        subject=m.group("subject").strip(),
        body=body or "",
        raw_subject=raw_subject,
    )


def classify_bump(commits: list[ParsedCommit]) -> tuple[BumpKind, list[str]]:
    """Return (bump, review_reasons)."""
    reasons: list[str] = []
    if not commits:
        return "none", reasons

    has_breaking = any(c.breaking for c in commits)
    has_feat = any(c.type == "feat" for c in commits)
    has_patch = any(c.type in _PATCH_TYPES for c in commits)
    unknown_types = sorted({c.type for c in commits if c.type not in _KNOWN_TYPES})

    if unknown_types:
        reasons.append(f"unknown commit type(s): {', '.join(unknown_types)}")

    if has_breaking:
        return "major", reasons
    if has_feat:
        return "minor", reasons
    if has_patch:
        return "patch", reasons
    if unknown_types:
        # Conservative: bump patch but flag for review.
        return "patch", reasons
    return "none", reasons


def bump_version(current: str, kind: BumpKind) -> str:
    """Bump a SemVer X.Y.Z by ``kind``. ``none`` returns input unchanged."""
    if kind == "none":
        return current
    m = _SEMVER_RE.match(current.strip())
    if not m:
        raise ValueError(
            f"current version '{current}' is not a SemVer X.Y.Z; "
            f"automated bump requires plain SemVer."
        )
    major, minor, patch = (int(x) for x in m.groups())
    if kind == "major":
        return f"{major + 1}.0.0"
    if kind == "minor":
        return f"{major}.{minor + 1}.0"
    return f"{major}.{minor}.{patch + 1}"


# ---------------------------------------------------------------------------
# Git interaction
# ---------------------------------------------------------------------------


def _run_git(args: list[str], cwd: Path) -> str:
    """Run a git command and return stdout (text). Raises CalledProcessError."""
    completed = subprocess.run(  # noqa: S603 - argv only
        ["git", *args],
        cwd=str(cwd),
        capture_output=True,
        check=True,
        text=True,
    )
    return completed.stdout


def _try_git(args: list[str], cwd: Path) -> str | None:
    try:
        return _run_git(args, cwd)
    except (subprocess.CalledProcessError, FileNotFoundError):
        return None


def find_last_tag(repo_root: Path, *, track: str, configured_tag: str) -> str:
    """Locate the previous release tag.

    Resolution order:
      1. ``configured_tag`` from version-state.toml (current ``tag`` field
         points at the *last frozen* release tag in our convention).
      2. ``git describe --tags --abbrev=0 --match "<track>/v*"``.
      3. ``git describe --tags --abbrev=0 --match "v*"``.
      4. Empty string → caller falls back to entire history.
    """
    if configured_tag:
        # Verify the tag actually exists; if not, fall through.
        if _try_git(["rev-parse", "--verify", f"refs/tags/{configured_tag}"], repo_root) is not None:
            return configured_tag
    for pattern in (f"{track}/v*", "v*"):
        out = _try_git(
            ["describe", "--tags", "--abbrev=0", "--match", pattern],
            repo_root,
        )
        if out:
            return out.strip()
    return ""


def collect_commits(repo_root: Path, since_tag: str) -> list[ParsedCommit]:
    """Return commits between ``since_tag`` (exclusive) and HEAD."""
    rev_range = f"{since_tag}..HEAD" if since_tag else "HEAD"
    # Use a delimiter unlikely to appear in commit messages.
    sep = "<<<COKODO_COMMIT>>>"
    fmt = f"%H%n%s%n%b%n{sep}"
    raw = _try_git(["log", rev_range, f"--pretty=format:{fmt}"], repo_root)
    if not raw:
        return []
    commits: list[ParsedCommit] = []
    for chunk in raw.split(sep):
        chunk = chunk.strip("\n")
        if not chunk:
            continue
        lines = chunk.split("\n")
        if not lines:
            continue
        sha = lines[0].strip()
        subject = lines[1] if len(lines) > 1 else ""
        body = "\n".join(lines[2:]) if len(lines) > 2 else ""
        commits.append(parse_commit(subject, body=body, sha=sha))
    return commits


def detect_migration_changes(repo_root: Path, since_tag: str) -> bool:
    rev_range = f"{since_tag}..HEAD" if since_tag else "HEAD"
    out = _try_git(["diff", "--name-only", rev_range], repo_root)
    if not out:
        return False
    for path in out.splitlines():
        if _MIGRATION_PATH_RE.search(path):
            return True
    return False


# ---------------------------------------------------------------------------
# Plan
# ---------------------------------------------------------------------------


def _load_track_state(agent_dir: Path, track: str) -> dict:
    state_path = agent_dir / "project" / "version-state.toml"
    if not state_path.is_file():
        raise FileNotFoundError(f"version-state.toml not found at {state_path}")
    with state_path.open("rb") as fh:
        data = tomllib.load(fh)
    tracks = data.get("tracks") or {}
    if track not in tracks:
        raise KeyError(f"track '{track}' not declared in version-state.toml")
    return tracks[track] or {}


def plan_release(repo_root: Path, agent_dir: Path, track: str) -> ReleasePlan:
    track_state = _load_track_state(agent_dir, track)
    current_version = str(track_state.get("working_version") or track_state.get("current_release") or "0.0.0")
    configured_tag = str(track_state.get("tag") or "")

    last_tag = find_last_tag(repo_root, track=track, configured_tag=configured_tag)
    commits = collect_commits(repo_root, since_tag=last_tag)
    bump, reasons = classify_bump(commits)
    next_version = bump_version(current_version, bump)

    breaking_msgs: list[str] = []
    for c in commits:
        if c.breaking:
            for m in _BREAKING_RE.finditer(c.body or ""):
                breaking_msgs.append(m.group("msg").strip())
            if not _BREAKING_RE.search(c.body or "") and "!" in c.raw_subject.split(":", 1)[0]:
                breaking_msgs.append(c.subject)

    has_migration = detect_migration_changes(repo_root, since_tag=last_tag)
    needs_review = bool(breaking_msgs) or bool(reasons) or has_migration
    if breaking_msgs:
        reasons.append(f"detected {len(breaking_msgs)} BREAKING CHANGE marker(s)")
    if has_migration:
        reasons.append("detected schema/migration path changes")

    return ReleasePlan(
        track=track,
        current_version=current_version,
        next_version=next_version,
        bump=bump,
        commits=commits,
        breaking_changes=breaking_msgs,
        needs_review=needs_review,
        review_reasons=reasons,
        previous_tag=last_tag,
        has_migration_changes=has_migration,
    )


# ---------------------------------------------------------------------------
# Render release note
# ---------------------------------------------------------------------------


def _bullets(commits: list[ParsedCommit], types: set[str]) -> str:
    lines = []
    for c in commits:
        if c.type not in types:
            continue
        scope = f"{c.scope}: " if c.scope else ""
        lines.append(f"- {scope}{c.subject} ({c.short_sha})")
    return "\n".join(lines) if lines else "- _none_"


def render_note(plan: ReleasePlan, *, validation_steps: str | None = None) -> str:
    """Render a structured release-note draft from a plan.

    The headings deliberately include the keywords ``Compatibility`` /
    ``Rollback`` / ``Validation`` so the bundled OPA release pack accepts it.
    """
    if plan.bump == "none":
        return f"# {plan.next_version}\n\n_No release-worthy changes since {plan.previous_tag or 'first commit'}._\n"

    feats = [c for c in plan.commits if c.type == "feat"]
    highlights_lines = [f"- {c.subject}" for c in feats[:3]]
    highlights = "\n".join(highlights_lines) if highlights_lines else "_TBD by reviewer._"

    if plan.breaking_changes:
        compat_lines = [f"- {msg}" for msg in plan.breaking_changes]
        compatibility = "\n".join(compat_lines)
    else:
        compatibility = "No breaking changes."

    rollback_extra = ""
    if plan.has_migration_changes:
        rollback_extra = " ⚠ Schema/migration path changes detected; review database rollback steps."
    prev_tag = plan.previous_tag or "(initial release)"
    rollback = f"Revert to tag `{prev_tag}`.{rollback_extra}"

    if validation_steps is None:
        validation_steps = "- `pytest`\n- `co policy check release`"

    feat_block = _bullets(plan.commits, {"feat"})
    fix_block = _bullets(plan.commits, {"fix"})
    other_block = _bullets(
        plan.commits,
        {"perf", "refactor", "revert", "docs", "chore", "ci", "style", "build", "test", "other"},
    )

    review_banner = ""
    if plan.needs_review:
        reasons = "; ".join(plan.review_reasons) or "needs human review"
        review_banner = f"> ⚠ **Reviewer attention required:** {reasons}\n\n"

    return (
        f"# {plan.next_version}\n\n"
        f"{review_banner}"
        f"## 1. Highlights\n{highlights}\n\n"
        f"## 2. Compatibility Notes\n{compatibility}\n\n"
        f"## 3. Rollback\n{rollback}\n\n"
        f"## 4. Validation\n{validation_steps}\n\n"
        f"## 5. Changes\n"
        f"### Features\n{feat_block}\n\n"
        f"### Fixes\n{fix_block}\n\n"
        f"### Other\n{other_block}\n"
    )
