# celedog (Python)

OpenAI-compatible Python client for [Celedog.io](https://celedog.io) — one API, 400+ AI models, pay as you go.

```sh
pip install celedog
```

## Quick start

```python
import celedog

# Reads CELEDOG_API_KEY from the env; or pass it directly:
#   celedog.Client(api_key="sk-celedog-...")
client = celedog.Client()

resp = client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": "Hello, Celedog!"}],
)
print(resp.choices[0].message.content)
```

### Async + streaming

```python
import asyncio
import celedog

async def main():
    client = celedog.AsyncClient()
    stream = await client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": "Stream me a sentence."}],
        stream=True,
    )
    async for chunk in stream:
        print(chunk.choices[0].delta.content or "", end="", flush=True)

asyncio.run(main())
```

`celedog.Client` is a thin subclass of `openai.OpenAI` — every feature OpenAI ships (multimodal input, structured outputs, tool calling, vision, batch) works unchanged. Just point the SDK at Celedog with your `sk-celedog-...` key.

## Configuration

| Source | Variable | Default |
|---|---|---|
| Constructor | `api_key=` | — |
| Env | `CELEDOG_API_KEY` | — |
| Env (fallback) | `OPENAI_API_KEY` | — |
| Constructor | `base_url=` | `https://celedog.io/v1` |
| Env | `CELEDOG_BASE_URL` | `https://celedog.io/v1` |

## Other languages

| Language | Install |
|---|---|
| Python | this package |
| Node.js / TypeScript | `npm install celedog` |
| Go | `go get github.com/AIRES-Technology/celedog-go` |
| Java | Maven coordinate `io.celedog:celedog:0.1.0` (GitHub Packages — see [celedog-java](https://github.com/AIRES-Technology/celedog-java)) |

## License

MIT — free to use and integrate. The Celedog gateway server itself is AGPL-3.0 (see [celedog.io](https://celedog.io)); SDK code is permissive so you can ship it inside your closed-source app.
