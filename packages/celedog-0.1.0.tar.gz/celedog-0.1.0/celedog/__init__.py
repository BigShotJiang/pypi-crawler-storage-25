"""Celedog AI gateway client (OpenAI-compatible)."""

from __future__ import annotations

import os
from typing import Any

from openai import AsyncOpenAI as _AsyncOpenAI
from openai import OpenAI as _OpenAI

# Re-export the common exception types so users can `except celedog.APIError`
from openai import (  # noqa: F401
    APIConnectionError,
    APIError,
    APIStatusError,
    APITimeoutError,
    AuthenticationError,
    BadRequestError,
    ConflictError,
    InternalServerError,
    NotFoundError,
    PermissionDeniedError,
    RateLimitError,
    UnprocessableEntityError,
)

__version__ = "0.1.0"

DEFAULT_BASE_URL = "https://celedog.io/v1"


def _resolve_api_key(api_key: str | None) -> str | None:
    return (
        api_key
        or os.environ.get("CELEDOG_API_KEY")
        or os.environ.get("OPENAI_API_KEY")
    )


def _resolve_base_url(base_url: str | None) -> str:
    return base_url or os.environ.get("CELEDOG_BASE_URL") or DEFAULT_BASE_URL


class Client(_OpenAI):
    """Synchronous Celedog client.

    Defaults `base_url` to https://celedog.io/v1 and reads the API key from
    the `CELEDOG_API_KEY` env var (falling back to `OPENAI_API_KEY`) if not
    passed explicitly. Every other argument is forwarded to `openai.OpenAI`.

    Example
    -------
    >>> import celedog
    >>> client = celedog.Client(api_key="sk-celedog-...")
    >>> resp = client.chat.completions.create(
    ...     model="gpt-4o",
    ...     messages=[{"role": "user", "content": "Hello!"}],
    ... )
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            api_key=_resolve_api_key(api_key),
            base_url=_resolve_base_url(base_url),
            **kwargs,
        )


class AsyncClient(_AsyncOpenAI):
    """Async Celedog client. Same conventions as `Client`."""

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            api_key=_resolve_api_key(api_key),
            base_url=_resolve_base_url(base_url),
            **kwargs,
        )


__all__ = [
    "Client",
    "AsyncClient",
    "DEFAULT_BASE_URL",
    "APIError",
    "APIStatusError",
    "APIConnectionError",
    "APITimeoutError",
    "AuthenticationError",
    "BadRequestError",
    "ConflictError",
    "InternalServerError",
    "NotFoundError",
    "PermissionDeniedError",
    "RateLimitError",
    "UnprocessableEntityError",
    "__version__",
]
