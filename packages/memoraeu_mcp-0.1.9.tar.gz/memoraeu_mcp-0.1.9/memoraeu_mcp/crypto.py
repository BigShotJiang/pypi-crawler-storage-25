"""
MemoraEU — Chiffrement zero-knowledge côté client
AES-256-GCM + PBKDF2-HMAC-SHA256

Le serveur ne voit jamais le texte clair ni la clé.
L'embedding est calculé AVANT chiffrement pour préserver la recherche sémantique.
"""
import os
import base64
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes


# M6 — 210 000 itérations (recommandation OWASP 2024 pour PBKDF2-SHA256)
PBKDF2_ITERATIONS = 210_000

# M1 — Préfixe magique pour détecter les valeurs chiffrées sans ambiguïté
ENC_PREFIX = "ENCv1:"


def derive_key(password: str, salt: str) -> bytes:
    """
    Dérive une clé AES-256 depuis un mot de passe et un salt.
    Appelé une seule fois au démarrage du MCP server.
    """
    salt_bytes = salt.encode() if isinstance(salt, str) else salt
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt_bytes,
        iterations=PBKDF2_ITERATIONS,
    )
    return kdf.derive(password.encode())


def encrypt(plaintext: str, key: bytes) -> str:
    """
    Chiffre un texte avec AES-256-GCM.
    Retourne : ENCv1:<base64(nonce[12] + ciphertext + tag[16])>
    """
    nonce = os.urandom(12)
    ciphertext = AESGCM(key).encrypt(nonce, plaintext.encode("utf-8"), None)
    return ENC_PREFIX + base64.b64encode(nonce + ciphertext).decode("ascii")


def decrypt(ciphertext_b64: str, key: bytes) -> str:
    """
    Déchiffre un texte chiffré par encrypt().
    Accepte les anciens formats (sans préfixe) pour rétrocompatibilité.
    Lève une exception si la clé est mauvaise ou les données corrompues.
    """
    # Retirer le préfixe si présent
    raw = ciphertext_b64[len(ENC_PREFIX):] if ciphertext_b64.startswith(ENC_PREFIX) else ciphertext_b64
    data = base64.b64decode(raw)
    nonce = data[:12]
    ciphertext = data[12:]
    plaintext = AESGCM(key).decrypt(nonce, ciphertext, None)
    return plaintext.decode("utf-8")


def is_encrypted(value: str) -> bool:
    """
    M1 — Détecte si une valeur est chiffrée via le préfixe ENCv1:
    Rétrocompatible : accepte aussi les anciens blobs base64 bruts (≥ 28 octets).
    """
    if value.startswith(ENC_PREFIX):
        return True
    # Rétrocompatibilité anciens blobs sans préfixe
    try:
        data = base64.b64decode(value)
        return len(data) >= 28  # nonce(12) + tag(16) minimum
    except Exception:
        return False
