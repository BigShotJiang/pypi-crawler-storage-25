"""Tests for DSPy Raindrop integration."""

import asyncio
import logging
import sys
import warnings
from unittest.mock import MagicMock, patch

import pytest

from raindrop_dspy import RaindropDSPy, create_raindrop_dspy
from raindrop_dspy.wrapper import (
    _extract_finish_reason,
    _extract_input,
    _extract_output,
    _extract_usage,
    _extract_usage_from_history,
    _wrap_module,
)


def _make_result(answer="Paris"):
    result = MagicMock()
    result.answer = answer
    result.toDict = MagicMock(return_value={"answer": answer})
    result.usage = None
    return result


class TestExtractInput:
    def test_string_values(self):
        assert _extract_input({"question": "What is 2+2?"}) == "What is 2+2?"

    def test_empty(self):
        assert _extract_input({}) is None

    def test_none(self):
        assert _extract_input(None) is None

    def test_multiple_fields(self):
        result = _extract_input({"context": "France info", "question": "Capital?"})
        assert "France info" in result
        assert "Capital?" in result


class TestExtractOutput:
    def test_toDict(self):
        result = _make_result("Paris")
        assert _extract_output(result) == "Paris"

    def test_none(self):
        assert _extract_output(None) is None

    def test_answer_attr(self):
        result = MagicMock(spec=[])
        result.answer = "Paris"
        assert _extract_output(result) == "Paris"


class TestWrapModule:
    def test_forward_tracked(self):
        module = MagicMock()
        fake_result = _make_result("Paris")
        module.forward = MagicMock(return_value=fake_result)
        module._raindrop_wrapped = False

        with patch("raindrop_dspy.wrapper.raindrop") as mock_rd:
            wrapped = _wrap_module(module, user_id="test-user")
            result = wrapped.forward(question="What is the capital of France?")

            assert result is fake_result
            mock_rd.track_ai.assert_called_once()
            kwargs = mock_rd.track_ai.call_args.kwargs
            assert kwargs["user_id"] == "test-user"
            assert "capital of France" in kwargs["input"]
            assert kwargs["output"] == "Paris"

    def test_error_tracked_with_properties(self):
        module = MagicMock()
        module.forward = MagicMock(side_effect=RuntimeError("LM Error"))
        module._raindrop_wrapped = False

        with patch("raindrop_dspy.wrapper.raindrop") as mock_rd:
            wrapped = _wrap_module(module, user_id="u")
            with pytest.raises(RuntimeError, match="LM Error"):
                wrapped.forward(question="Hi")
            mock_rd.track_ai.assert_called_once()
            props = mock_rd.track_ai.call_args.kwargs["properties"]
            assert props["error.type"] == "RuntimeError"
            assert props["error.message"] == "LM Error"

    def test_convo_id(self):
        module = MagicMock()
        module.forward = MagicMock(return_value=_make_result())
        module._raindrop_wrapped = False

        with patch("raindrop_dspy.wrapper.raindrop") as mock_rd:
            wrapped = _wrap_module(module, user_id="u", convo_id="c1")
            wrapped.forward(question="Hi")
            assert mock_rd.track_ai.call_args.kwargs["convo_id"] == "c1"

    def test_telemetry_error_does_not_mask_result(self):
        module = MagicMock()
        module.forward = MagicMock(return_value=_make_result("OK"))
        module._raindrop_wrapped = False

        with patch("raindrop_dspy.wrapper.raindrop") as mock_rd:
            mock_rd.track_ai.side_effect = RuntimeError("broke")
            wrapped = _wrap_module(module, user_id="u")
            result = wrapped.forward(question="Hi")
            assert result.answer == "OK"

    def test_multiple_calls(self):
        module = MagicMock()
        module.forward = MagicMock(return_value=_make_result())
        module._raindrop_wrapped = False

        with patch("raindrop_dspy.wrapper.raindrop") as mock_rd:
            wrapped = _wrap_module(module, user_id="u")
            for _ in range(10):
                wrapped.forward(question="Hi")
            assert mock_rd.track_ai.call_count == 10

    def test_user_id_defaults_to_unknown(self):
        module = MagicMock()
        module.forward = MagicMock(return_value=_make_result())
        module._raindrop_wrapped = False

        with patch("raindrop_dspy.wrapper.raindrop") as mock_rd:
            wrapped = _wrap_module(module)
            wrapped.forward(question="Hi")
            assert mock_rd.track_ai.call_args.kwargs["user_id"] == "unknown"


class TestDoubleWrapGuard:
    def test_double_wrap_is_noop(self):
        module = MagicMock()
        module.forward = MagicMock(return_value=_make_result())
        module._raindrop_wrapped = False

        with patch("raindrop_dspy.wrapper.raindrop"):
            first = _wrap_module(module, user_id="u")
            original_forward = first.forward
            second = _wrap_module(first, user_id="u")
            assert second.forward is original_forward

    def test_already_wrapped_attr_set(self):
        module = MagicMock()
        module.forward = MagicMock(return_value=_make_result())
        module._raindrop_wrapped = False

        with patch("raindrop_dspy.wrapper.raindrop"):
            wrapped = _wrap_module(module, user_id="u")
            assert getattr(wrapped, "_raindrop_wrapped", False) is True


class TestAsyncForward:
    def test_async_forward_tracked(self):
        module = MagicMock()
        fake_result = _make_result("Paris")

        async def async_forward(**kwargs):
            return fake_result

        module.forward = async_forward
        module._raindrop_wrapped = False

        with patch("raindrop_dspy.wrapper.raindrop") as mock_rd:
            wrapped = _wrap_module(module, user_id="async-user")
            result = asyncio.run(
                wrapped.forward(question="Capital of France?")
            )
            assert result is fake_result
            mock_rd.track_ai.assert_called_once()
            kwargs = mock_rd.track_ai.call_args.kwargs
            assert kwargs["user_id"] == "async-user"

    def test_async_error_tracked(self):
        module = MagicMock()

        async def async_forward(**kwargs):
            raise ValueError("async fail")

        module.forward = async_forward
        module._raindrop_wrapped = False

        with patch("raindrop_dspy.wrapper.raindrop") as mock_rd:
            wrapped = _wrap_module(module, user_id="u")
            with pytest.raises(ValueError, match="async fail"):
                asyncio.run(
                    wrapped.forward(question="Hi")
                )
            mock_rd.track_ai.assert_called_once()
            props = mock_rd.track_ai.call_args.kwargs["properties"]
            assert props["error.type"] == "ValueError"
            assert props["error.message"] == "async fail"


class TestRaindropDSPyClass:
    def test_class_init_and_wrap(self):
        module = MagicMock()
        module.forward = MagicMock(return_value=_make_result())
        module._raindrop_wrapped = False

        with patch("raindrop_dspy.wrapper.raindrop") as mock_rd:
            rd = RaindropDSPy(api_key="rk_test", user_id="u1")
            wrapped = rd.wrap(module)
            wrapped.forward(question="Hi")
            mock_rd.init.assert_called_once_with(
                api_key="rk_test",
                tracing_enabled=True,
                bypass_otel_for_tools=True,
            )
            mock_rd.track_ai.assert_called_once()

    def test_flush_delegates(self):
        with patch("raindrop_dspy.wrapper.raindrop") as mock_rd:
            rd = RaindropDSPy(api_key="rk_test")
            rd.flush()
            mock_rd.flush.assert_called_once()

    def test_shutdown_delegates(self):
        with patch("raindrop_dspy.wrapper.raindrop") as mock_rd:
            rd = RaindropDSPy(api_key="rk_test")
            rd.shutdown()
            mock_rd.shutdown.assert_called_once()

    def test_identify_delegates(self):
        with patch("raindrop_dspy.wrapper.raindrop") as mock_rd:
            rd = RaindropDSPy(api_key="rk_test")
            rd.identify("user-1", {"name": "Alice"})
            mock_rd.identify.assert_called_once_with(user_id="user-1", traits={"name": "Alice"})

    def test_identify_without_traits(self):
        with patch("raindrop_dspy.wrapper.raindrop") as mock_rd:
            rd = RaindropDSPy(api_key="rk_test")
            rd.identify("user-1")
            mock_rd.identify.assert_called_once_with(user_id="user-1", traits={})

    def test_identify_with_standard_trait_types(self):
        with patch("raindrop_dspy.wrapper.raindrop") as mock_rd:
            rd = RaindropDSPy(api_key="rk_test")
            rd.identify("user-1", {"name": "Alice", "age": 30, "active": True, "score": 9.5})
            mock_rd.identify.assert_called_once_with(
                user_id="user-1",
                traits={"name": "Alice", "age": 30, "active": True, "score": 9.5},
            )

    def test_track_signal_delegates(self):
        with patch("raindrop_dspy.wrapper.raindrop") as mock_rd:
            rd = RaindropDSPy(api_key="rk_test")
            rd.track_signal("evt-123", "thumbs_up", sentiment="POSITIVE")
            mock_rd.track_signal.assert_called_once_with(
                event_id="evt-123",
                name="thumbs_up",
                signal_type="default",
                timestamp=None,
                properties=None,
                attachment_id=None,
                comment=None,
                after=None,
                sentiment="POSITIVE",
            )

    def test_track_signal_with_all_params(self):
        with patch("raindrop_dspy.wrapper.raindrop") as mock_rd:
            rd = RaindropDSPy(api_key="rk_test")
            rd.track_signal(
                "evt-123",
                "user_feedback",
                "feedback",
                comment="Great response!",
                properties={"score": 5},
            )
            mock_rd.track_signal.assert_called_once_with(
                event_id="evt-123",
                name="user_feedback",
                signal_type="feedback",
                timestamp=None,
                properties={"score": 5},
                attachment_id=None,
                comment="Great response!",
                after=None,
                sentiment=None,
            )

    def test_empty_api_key_warns(self):
        with patch("raindrop_dspy.wrapper.raindrop"):
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                RaindropDSPy(api_key="")
                assert len(w) == 1
                assert "api_key not provided" in str(w[0].message)

    def test_none_api_key_warns(self):
        with patch("raindrop_dspy.wrapper.raindrop"):
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                RaindropDSPy()
                assert len(w) == 1
                assert "[raindrop-dspy]" in str(w[0].message)


class TestFactory:
    def test_returns_raindrop_dspy_instance(self):
        with patch("raindrop_dspy.wrapper.raindrop") as mock_rd:
            result = create_raindrop_dspy(api_key="rk_test")
            assert isinstance(result, RaindropDSPy)
            mock_rd.init.assert_called_once_with(
                api_key="rk_test",
                tracing_enabled=True,
                bypass_otel_for_tools=True,
            )

    def test_factory_wrap_instruments_module(self):
        module = MagicMock()
        module.forward = MagicMock(return_value=_make_result())
        module._raindrop_wrapped = False

        with patch("raindrop_dspy.wrapper.raindrop") as mock_rd:
            rd = create_raindrop_dspy(api_key="rk_test", user_id="u1")
            wrapped = rd.wrap(module)
            wrapped.forward(question="Hi")
            mock_rd.track_ai.assert_called_once()


class TestLegacyDictAccess:
    def test_getitem_wrap(self):
        with patch("raindrop_dspy.wrapper.raindrop"):
            rd = RaindropDSPy(api_key="rk_test")
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                assert rd["wrap"] == rd.wrap
                assert len(w) == 1
                assert issubclass(w[0].category, DeprecationWarning)
                assert "deprecated" in str(w[0].message)

    def test_getitem_flush(self):
        with patch("raindrop_dspy.wrapper.raindrop"):
            rd = RaindropDSPy(api_key="rk_test")
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                assert rd["flush"] == rd.flush
                assert len(w) == 1
                assert issubclass(w[0].category, DeprecationWarning)

    def test_getitem_shutdown(self):
        with patch("raindrop_dspy.wrapper.raindrop"):
            rd = RaindropDSPy(api_key="rk_test")
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                assert rd["shutdown"] == rd.shutdown
                assert len(w) == 1
                assert issubclass(w[0].category, DeprecationWarning)

    def test_getitem_invalid_key(self):
        with patch("raindrop_dspy.wrapper.raindrop"):
            rd = RaindropDSPy(api_key="rk_test")
            with pytest.raises(KeyError):
                rd["nonexistent"]


class TestVersion:
    def test_version_exported(self):
        from raindrop_dspy import __version__

        assert isinstance(__version__, str)
        assert __version__ == "0.0.3"


class TestDebugFlag:
    """Tests for the debug=True constructor flag."""

    def test_debug_false_by_default(self):
        with patch("raindrop_dspy.wrapper.raindrop"):
            rd = RaindropDSPy(api_key="rk_test")
            assert rd._debug is False

    def test_debug_true_sets_logger_level(self):
        with patch("raindrop_dspy.wrapper.raindrop"):
            with patch("raindrop_dspy.wrapper.logger") as mock_logger:
                RaindropDSPy(api_key="rk_test", debug=True)
                mock_logger.setLevel.assert_called_once_with(logging.DEBUG)

    def test_debug_false_does_not_set_logger_level(self):
        with patch("raindrop_dspy.wrapper.raindrop"):
            with patch("raindrop_dspy.wrapper.logger") as mock_logger:
                RaindropDSPy(api_key="rk_test", debug=False)
                mock_logger.setLevel.assert_not_called()

    def test_debug_stored_on_instance(self):
        with patch("raindrop_dspy.wrapper.raindrop"):
            rd = RaindropDSPy(api_key="rk_test", debug=True)
            assert rd._debug is True

    def test_factory_passes_debug(self):
        with patch("raindrop_dspy.wrapper.raindrop"):
            with patch("raindrop_dspy.wrapper.logger") as mock_logger:
                rd = create_raindrop_dspy(api_key="rk_test", debug=True)
                assert rd._debug is True
                mock_logger.setLevel.assert_called_once_with(logging.DEBUG)


class TestTracingFlags:
    """Tests for tracing_enabled and bypass_otel_for_tools in raindrop.init()."""

    def test_init_passes_tracing_flags(self):
        with patch("raindrop_dspy.wrapper.raindrop") as mock_rd:
            RaindropDSPy(api_key="rk_test")
            mock_rd.init.assert_called_once_with(
                api_key="rk_test",
                tracing_enabled=True,
                bypass_otel_for_tools=True,
            )

    def test_init_passes_custom_tracing_flags(self):
        with patch("raindrop_dspy.wrapper.raindrop") as mock_rd:
            RaindropDSPy(api_key="rk_test", tracing_enabled=False, bypass_otel_for_tools=False)
            mock_rd.init.assert_called_once_with(
                api_key="rk_test",
                tracing_enabled=False,
                bypass_otel_for_tools=False,
            )

    def test_factory_passes_tracing_flags(self):
        with patch("raindrop_dspy.wrapper.raindrop") as mock_rd:
            create_raindrop_dspy(api_key="rk_test")
            mock_rd.init.assert_called_once_with(
                api_key="rk_test",
                tracing_enabled=True,
                bypass_otel_for_tools=True,
            )

    def test_factory_passes_custom_tracing_flags(self):
        with patch("raindrop_dspy.wrapper.raindrop") as mock_rd:
            create_raindrop_dspy(api_key="rk_test", tracing_enabled=False, bypass_otel_for_tools=False)
            mock_rd.init.assert_called_once_with(
                api_key="rk_test",
                tracing_enabled=False,
                bypass_otel_for_tools=False,
            )

    def test_tracing_flags_with_debug(self):
        with patch("raindrop_dspy.wrapper.raindrop") as mock_rd:
            RaindropDSPy(api_key="rk_test", debug=True)
            mock_rd.init.assert_called_once_with(
                api_key="rk_test",
                tracing_enabled=True,
                bypass_otel_for_tools=True,
            )

    def test_empty_api_key_passes_empty_string(self):
        with patch("raindrop_dspy.wrapper.raindrop") as mock_rd:
            with warnings.catch_warnings(record=True):
                warnings.simplefilter("always")
                RaindropDSPy()
            mock_rd.init.assert_called_once_with(
                api_key="",
                tracing_enabled=True,
                bypass_otel_for_tools=True,
            )


class TestExtractFinishReason:
    """Tests for _extract_finish_reason() helper."""

    def _make_mock_dspy(self, *, finish_reason=None, history=None, lm=None, settings=None):
        """Build a mock dspy module with configurable LM history."""
        mock_dspy = MagicMock()
        if settings is not None:
            mock_dspy.settings = settings
            return mock_dspy
        if lm is not None:
            mock_dspy.settings.lm = lm
            return mock_dspy
        if history is not None:
            mock_dspy.settings.lm.history = history
            return mock_dspy
        if finish_reason is not None:
            mock_choice = MagicMock()
            mock_choice.finish_reason = finish_reason
            mock_response = MagicMock()
            mock_response.choices = [mock_choice]
            mock_dspy.settings.lm.history = [{"response": mock_response}]
            return mock_dspy
        return mock_dspy

    def test_extracts_stop_reason(self):
        mock_dspy = self._make_mock_dspy(finish_reason="stop")
        with patch.dict(sys.modules, {"dspy": mock_dspy}):
            result = _extract_finish_reason()
            assert result == "stop"

    def test_extracts_length_reason(self):
        mock_dspy = self._make_mock_dspy(finish_reason="length")
        with patch.dict(sys.modules, {"dspy": mock_dspy}):
            result = _extract_finish_reason()
            assert result == "length"

    def test_returns_none_when_no_settings(self):
        mock_dspy = MagicMock()
        mock_dspy.settings = None
        with patch.dict(sys.modules, {"dspy": mock_dspy}):
            result = _extract_finish_reason()
            assert result is None

    def test_returns_none_when_no_lm(self):
        mock_dspy = MagicMock()
        mock_dspy.settings.lm = None
        with patch.dict(sys.modules, {"dspy": mock_dspy}):
            result = _extract_finish_reason()
            assert result is None

    def test_returns_none_when_no_history(self):
        mock_dspy = MagicMock()
        mock_dspy.settings.lm.history = None
        with patch.dict(sys.modules, {"dspy": mock_dspy}):
            result = _extract_finish_reason()
            assert result is None

    def test_returns_none_when_history_empty(self):
        mock_dspy = self._make_mock_dspy(history=[])
        with patch.dict(sys.modules, {"dspy": mock_dspy}):
            result = _extract_finish_reason()
            assert result is None

    def test_returns_none_when_response_is_none(self):
        mock_dspy = self._make_mock_dspy(history=[{"response": None}])
        with patch.dict(sys.modules, {"dspy": mock_dspy}):
            result = _extract_finish_reason()
            assert result is None

    def test_returns_none_when_no_choices(self):
        mock_response = MagicMock()
        mock_response.choices = []
        mock_dspy = self._make_mock_dspy(history=[{"response": mock_response}])
        with patch.dict(sys.modules, {"dspy": mock_dspy}):
            result = _extract_finish_reason()
            assert result is None

    def test_returns_none_when_finish_reason_attr_missing(self):
        mock_choice = MagicMock(spec=[])
        mock_response = MagicMock()
        mock_response.choices = [mock_choice]
        mock_dspy = self._make_mock_dspy(history=[{"response": mock_response}])
        with patch.dict(sys.modules, {"dspy": mock_dspy}):
            result = _extract_finish_reason()
            assert result is None

    def test_handles_exception_gracefully(self):
        mock_dspy = MagicMock()
        mock_dspy.settings.lm.history.__getitem__ = MagicMock(
            side_effect=Exception("unexpected")
        )
        with patch.dict(sys.modules, {"dspy": mock_dspy}):
            result = _extract_finish_reason()
            assert result is None


class TestFinishReasonInTracking:
    """Tests that finish_reason is included in track_ai properties."""

    def _setup_lm_history(self, mock_dspy, finish_reason):
        mock_choice = MagicMock()
        mock_choice.finish_reason = finish_reason
        mock_response = MagicMock()
        mock_response.choices = [mock_choice]
        mock_dspy.settings.lm.history = [{"response": mock_response}]
        mock_dspy.settings.lm.model = "openai/gpt-4o-mini"

    def test_sync_forward_includes_finish_reason(self):
        module = MagicMock()
        fake_result = _make_result("Paris")
        module.forward = MagicMock(return_value=fake_result)
        module._raindrop_wrapped = False
        mock_dspy = MagicMock()
        self._setup_lm_history(mock_dspy, "stop")

        with patch("raindrop_dspy.wrapper.raindrop") as mock_rd, \
             patch.dict(sys.modules, {"dspy": mock_dspy}):
            wrapped = _wrap_module(module, user_id="u")
            wrapped.forward(question="Hi")
            props = mock_rd.track_ai.call_args.kwargs["properties"]
            assert props["dspy.finish_reason"] == "stop"

    def test_async_forward_includes_finish_reason(self):
        module = MagicMock()
        fake_result = _make_result("Paris")

        async def async_forward(**kwargs):
            return fake_result

        module.forward = async_forward
        module._raindrop_wrapped = False
        mock_dspy = MagicMock()
        self._setup_lm_history(mock_dspy, "stop")

        with patch("raindrop_dspy.wrapper.raindrop") as mock_rd, \
             patch.dict(sys.modules, {"dspy": mock_dspy}):
            wrapped = _wrap_module(module, user_id="u")
            asyncio.run(wrapped.forward(question="Hi"))
            props = mock_rd.track_ai.call_args.kwargs["properties"]
            assert props["dspy.finish_reason"] == "stop"

    def test_finish_reason_none_not_in_properties(self):
        module = MagicMock()
        fake_result = _make_result("Paris")
        module.forward = MagicMock(return_value=fake_result)
        module._raindrop_wrapped = False
        mock_dspy = MagicMock()
        mock_dspy.settings.lm = None

        with patch("raindrop_dspy.wrapper.raindrop") as mock_rd, \
             patch.dict(sys.modules, {"dspy": mock_dspy}):
            wrapped = _wrap_module(module, user_id="u")
            wrapped.forward(question="Hi")
            props = mock_rd.track_ai.call_args.kwargs["properties"]
            assert props is None or "dspy.finish_reason" not in (props or {})


class TestEdgeCases:
    """Edge case tests for robustness."""

    def test_debug_with_empty_api_key(self):
        with patch("raindrop_dspy.wrapper.raindrop"):
            with patch("raindrop_dspy.wrapper.logger") as mock_logger:
                with warnings.catch_warnings(record=True) as w:
                    warnings.simplefilter("always")
                    rd = RaindropDSPy(api_key="", debug=True)
                    assert len(w) == 1
                    assert "api_key not provided" in str(w[0].message)
                mock_logger.setLevel.assert_called_once_with(logging.DEBUG)
                assert rd._debug is True

    def test_all_constructor_params(self):
        with patch("raindrop_dspy.wrapper.raindrop") as mock_rd:
            rd = RaindropDSPy(
                api_key="rk_test",
                user_id="u1",
                convo_id="c1",
                tracing_enabled=False,
                bypass_otel_for_tools=False,
                debug=True,
            )
            assert rd._user_id == "u1"
            assert rd._convo_id == "c1"
            assert rd._debug is True
            mock_rd.init.assert_called_once_with(
                api_key="rk_test",
                tracing_enabled=False,
                bypass_otel_for_tools=False,
            )


class TestExtractUsage:
    """Tests for _extract_usage() helper."""

    def test_get_lm_usage_single_model(self):
        result = MagicMock(spec=[])
        result.get_lm_usage = MagicMock(return_value={
            "openai/gpt-4o": {"prompt_tokens": 100, "completion_tokens": 50},
        })
        props = _extract_usage(result)
        assert props == {
            "ai.usage.prompt_tokens": 100,
            "ai.usage.completion_tokens": 50,
        }

    def test_get_lm_usage_multiple_models(self):
        result = MagicMock(spec=[])
        result.get_lm_usage = MagicMock(return_value={
            "openai/gpt-4o": {"prompt_tokens": 100, "completion_tokens": 50},
            "openai/gpt-4o-mini": {"prompt_tokens": 30, "completion_tokens": 10},
        })
        props = _extract_usage(result)
        assert props == {
            "ai.usage.prompt_tokens": 130,
            "ai.usage.completion_tokens": 60,
        }

    def test_get_lm_usage_returns_non_dict(self):
        result = MagicMock(spec=[])
        result.get_lm_usage = MagicMock(return_value="not a dict")
        result.usage = None
        mock_dspy = MagicMock()
        mock_dspy.settings.lm = None
        with patch.dict(sys.modules, {"dspy": mock_dspy}):
            assert _extract_usage(result) is None

    def test_get_lm_usage_empty_dict(self):
        result = MagicMock(spec=[])
        result.get_lm_usage = MagicMock(return_value={})
        mock_dspy = MagicMock()
        mock_dspy.settings.lm = None
        with patch.dict(sys.modules, {"dspy": mock_dspy}):
            assert _extract_usage(result) is None

    def test_get_lm_usage_zero_tokens(self):
        result = MagicMock(spec=[])
        result.get_lm_usage = MagicMock(return_value={
            "openai/gpt-4o": {"prompt_tokens": 0, "completion_tokens": 0},
        })
        mock_dspy = MagicMock()
        mock_dspy.settings.lm = None
        with patch.dict(sys.modules, {"dspy": mock_dspy}):
            assert _extract_usage(result) is None

    def test_usage_dict_fallback(self):
        result = MagicMock(spec=[])
        result.usage = {"prompt_tokens": 20, "completion_tokens": 10}
        assert _extract_usage(result) == {
            "ai.usage.prompt_tokens": 20,
            "ai.usage.completion_tokens": 10,
        }

    def test_usage_object_fallback(self):
        result = MagicMock(spec=[])
        usage_obj = MagicMock()
        usage_obj.prompt_tokens = 15
        usage_obj.completion_tokens = 7
        result.usage = usage_obj
        assert _extract_usage(result) == {
            "ai.usage.prompt_tokens": 15,
            "ai.usage.completion_tokens": 7,
        }

    def test_usage_none(self):
        result = MagicMock(spec=[])
        result.usage = None
        mock_dspy = MagicMock()
        mock_dspy.settings.lm = None
        with patch.dict(sys.modules, {"dspy": mock_dspy}):
            assert _extract_usage(result) is None

    def test_result_none(self):
        mock_dspy = MagicMock()
        mock_dspy.settings.lm = None
        with patch.dict(sys.modules, {"dspy": mock_dspy}):
            assert _extract_usage(None) is None

    def test_exception_returns_none(self):
        result = MagicMock(spec=[])
        result.get_lm_usage = MagicMock(side_effect=RuntimeError("boom"))
        result.usage = None
        assert _extract_usage(result) is None

    def test_falls_back_to_history(self):
        """When get_lm_usage returns None and no usage attr, reads LM history."""
        result = MagicMock(spec=[])
        result.get_lm_usage = MagicMock(return_value=None)
        result.usage = None

        mock_usage = MagicMock()
        mock_usage.prompt_tokens = 100
        mock_usage.completion_tokens = 25
        mock_response = MagicMock()
        mock_response.usage = mock_usage
        mock_dspy = MagicMock()
        mock_dspy.settings.lm.history = [{"response": mock_response}]

        with patch.dict(sys.modules, {"dspy": mock_dspy}):
            props = _extract_usage(result)
        assert props == {
            "ai.usage.prompt_tokens": 100,
            "ai.usage.completion_tokens": 25,
        }


class TestExtractUsageFromHistory:
    """Tests for _extract_usage_from_history() LM history fallback."""

    def test_extracts_from_response_usage(self):
        mock_usage = MagicMock()
        mock_usage.prompt_tokens = 50
        mock_usage.completion_tokens = 10
        mock_response = MagicMock()
        mock_response.usage = mock_usage
        mock_dspy = MagicMock()
        mock_dspy.settings.lm.history = [{"response": mock_response}]

        with patch.dict(sys.modules, {"dspy": mock_dspy}):
            props = _extract_usage_from_history()
        assert props == {
            "ai.usage.prompt_tokens": 50,
            "ai.usage.completion_tokens": 10,
        }

    def test_returns_none_when_no_history(self):
        mock_dspy = MagicMock()
        mock_dspy.settings.lm.history = None
        with patch.dict(sys.modules, {"dspy": mock_dspy}):
            assert _extract_usage_from_history() is None

    def test_returns_none_when_no_usage(self):
        mock_response = MagicMock()
        mock_response.usage = None
        mock_dspy = MagicMock()
        mock_dspy.settings.lm.history = [{"response": mock_response}]
        with patch.dict(sys.modules, {"dspy": mock_dspy}):
            assert _extract_usage_from_history() is None

    def test_handles_exception(self):
        mock_dspy = MagicMock()
        mock_dspy.settings.lm.history.__getitem__ = MagicMock(
            side_effect=Exception("unexpected")
        )
        with patch.dict(sys.modules, {"dspy": mock_dspy}):
            assert _extract_usage_from_history() is None
