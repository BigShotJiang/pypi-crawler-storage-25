"""End-to-end tests for DSPy Raindrop integration.

These tests make REAL API calls to OpenAI and verify events land in the
Raindrop dashboard via the TRPC API.  They are skipped in CI where keys
are not available.

Required environment variables:
  OPENAI_API_KEY               — OpenAI API key
  RAINDROP_WRITE_KEY           — (or RAINDROP_API_KEY) Raindrop write key
  RAINDROP_DASHBOARD_TOKEN     — Bearer token for backend.raindrop.ai TRPC API

Run locally:
  cd packages/dspy-python
  source .venv/bin/activate
  export OPENAI_API_KEY=sk-...
  export RAINDROP_WRITE_KEY=your-write-key
  export RAINDROP_DASHBOARD_TOKEN=eyJ...
  python -m pytest tests/test_e2e.py -v -s
"""

from __future__ import annotations

import json
import os
import time
import urllib.parse
import uuid

import pytest
import requests

WRITE_KEY = os.getenv("RAINDROP_WRITE_KEY") or os.getenv("RAINDROP_API_KEY")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
DASHBOARD_TOKEN = os.getenv("RAINDROP_DASHBOARD_TOKEN")
BACKEND_URL = os.getenv("RAINDROP_BACKEND_URL", "https://backend.raindrop.ai")

skip_unless_e2e = pytest.mark.skipif(
    not all([WRITE_KEY, OPENAI_API_KEY, DASHBOARD_TOKEN]),
    reason="RAINDROP_WRITE_KEY, OPENAI_API_KEY, and RAINDROP_DASHBOARD_TOKEN required",
)

RUN_ID = uuid.uuid4().hex[:10]
MODEL = "openai/gpt-4o-mini"


def _make_user(suffix: str) -> str:
    return f"e2e_dspy_{RUN_ID}_{suffix}"


def _make_convo(suffix: str) -> str:
    return f"e2e_convo_{RUN_ID}_{suffix}"


def _query_dashboard(limit: int = 50) -> list[dict]:
    """Fetch recent events from the dashboard TRPC API."""
    input_obj = {"json": {"limit": limit, "orderBy": {"field": "timestamp", "direction": "desc"}}}
    encoded = urllib.parse.quote(json.dumps(input_obj))
    resp = requests.get(
        f"{BACKEND_URL}/api/trpc/events.list?input={encoded}",
        headers={"Authorization": f"Bearer {DASHBOARD_TOKEN}"},
        timeout=20,
    )
    resp.raise_for_status()
    data = resp.json()
    return data.get("result", {}).get("data", [])


def poll_events(
    user_id: str,
    min_count: int = 1,
    timeout: int = 60,
    interval: int = 4,
) -> list[dict]:
    """Poll the dashboard TRPC API until *min_count* events for *user_id* appear."""
    deadline = time.time() + timeout
    matched: list[dict] = []
    while time.time() < deadline:
        all_events = _query_dashboard()
        matched = [e for e in all_events if e.get("userId") == user_id]
        if len(matched) >= min_count:
            return matched
        time.sleep(interval)
    raise TimeoutError(
        f"Expected >= {min_count} events for userId={user_id}, "
        f"got {len(matched)} after {timeout}s"
    )


def _setup_dspy():
    """Configure DSPy with OpenAI LM and caching disabled.

    Caching must be off so each call hits the API and populates
    ``lm.history`` — otherwise token usage and finish_reason read
    stale data from a previous (uncached) call.
    """
    import dspy

    lm = dspy.LM(MODEL, cache=False)
    dspy.configure(lm=lm)


@skip_unless_e2e
class TestEventShape:
    """Verify exact event structure: aiData nesting, userId, model, properties."""

    def test_single_predict_full_shape(self):
        import dspy

        from raindrop_dspy import RaindropDSPy

        user_id = _make_user("shape")
        convo_id = _make_convo("shape")

        _setup_dspy()

        raindrop = RaindropDSPy(
            api_key=WRITE_KEY,
            user_id=user_id,
            convo_id=convo_id,
        )

        predict = dspy.Predict("question -> answer")
        wrapped = raindrop.wrap(predict)

        result = wrapped(question="What is 2 + 2?")
        assert result.answer is not None

        raindrop.flush()
        time.sleep(3)
        raindrop.shutdown()

        rows = poll_events(user_id)
        assert len(rows) >= 1, f"Expected >= 1 event, got {len(rows)}"
        ev = rows[0]

        assert ev["userId"] == user_id

        ai = ev.get("aiData") or {}
        assert ai.get("input"), f"aiData.input should be populated, got: {ai}"
        assert "2 + 2" in (ai.get("input") or ""), f"input should contain the question, got: {ai.get('input')}"
        assert ai.get("output"), f"aiData.output should be populated, got: {ai}"
        assert ai.get("convoId") == convo_id, f"aiData.convoId should match, got: {ai.get('convoId')}"

        model = ai.get("model") or ""
        assert "gpt-4o-mini" in model, f"aiData.model should contain gpt-4o-mini, got: {model}"

        assert "isPending" not in ev or not ev["isPending"], "Event should be finalized"


@skip_unless_e2e
class TestTokenUsage:
    """Token counts should be present and > 0 (extracted from LM history)."""

    def test_tokens_present_and_positive(self):
        import dspy

        from raindrop_dspy import RaindropDSPy

        user_id = _make_user("tokens")
        _setup_dspy()

        raindrop = RaindropDSPy(api_key=WRITE_KEY, user_id=user_id)
        predict = dspy.Predict("question -> answer")
        wrapped = raindrop.wrap(predict)

        wrapped(question="What is 1 + 1?")

        raindrop.flush()
        time.sleep(3)
        raindrop.shutdown()

        rows = poll_events(user_id)
        ev = rows[0]
        props = ev.get("properties") or {}

        prompt_tokens = props.get("ai.usage.prompt_tokens")
        completion_tokens = props.get("ai.usage.completion_tokens")

        assert prompt_tokens is not None, f"Expected ai.usage.prompt_tokens in properties, got: {props}"
        assert int(prompt_tokens) > 0, f"prompt_tokens should be > 0, got {prompt_tokens}"
        assert completion_tokens is not None, f"Expected ai.usage.completion_tokens in properties, got: {props}"
        assert int(completion_tokens) > 0, f"completion_tokens should be > 0, got {completion_tokens}"


@skip_unless_e2e
class TestFinishReason:
    """finish_reason should be 'stop' for a normal completion."""

    def test_finish_reason_is_stop(self):
        import dspy

        from raindrop_dspy import RaindropDSPy

        user_id = _make_user("finish")
        _setup_dspy()

        raindrop = RaindropDSPy(api_key=WRITE_KEY, user_id=user_id)
        predict = dspy.Predict("question -> answer")
        wrapped = raindrop.wrap(predict)

        wrapped(question="Say hello")

        raindrop.flush()
        time.sleep(3)
        raindrop.shutdown()

        rows = poll_events(user_id)
        ev = rows[0]
        props = ev.get("properties") or {}

        finish_reason = props.get("dspy.finish_reason")
        assert finish_reason == "stop", (
            f"Expected dspy.finish_reason='stop', got: {finish_reason!r} (all props: {props})"
        )


@skip_unless_e2e
class TestMultipleCallsDistinct:
    """Multiple calls produce distinct events with distinct inputs."""

    def test_three_calls_no_cross_contamination(self):
        import dspy

        from raindrop_dspy import RaindropDSPy

        user_id = _make_user("multi")
        convo_id = _make_convo("multi")
        _setup_dspy()

        raindrop = RaindropDSPy(api_key=WRITE_KEY, user_id=user_id, convo_id=convo_id)
        predict = dspy.Predict("question -> answer")
        wrapped = raindrop.wrap(predict)

        wrapped(question="What is the capital of France?")
        wrapped(question="What is the capital of Germany?")
        wrapped(question="What is the capital of Italy?")

        raindrop.flush()
        time.sleep(3)
        raindrop.shutdown()

        rows = poll_events(user_id, min_count=3, timeout=90)
        assert len(rows) >= 3, f"Expected >= 3 events, got {len(rows)}"

        inputs = set()
        for r in rows:
            inp = (r.get("aiData") or {}).get("input", "")
            if inp:
                inputs.add(inp)
        assert len(inputs) >= 3, (
            f"Expected >= 3 distinct inputs (no cross-contamination), got {len(inputs)}: {inputs}"
        )

        for r in rows:
            ai = r.get("aiData") or {}
            assert ai.get("convoId") == convo_id, f"All events should share convoId={convo_id}"


@skip_unless_e2e
class TestConvoIdGrouping:
    """Events with the same convo_id are grouped; different convo_ids are separate."""

    def test_convo_id_separation(self):
        import dspy

        from raindrop_dspy import RaindropDSPy

        user_id = _make_user("convo")
        convo_a = _make_convo("a")
        convo_b = _make_convo("b")
        _setup_dspy()

        rd_a = RaindropDSPy(api_key=WRITE_KEY, user_id=user_id, convo_id=convo_a)
        predict_a = dspy.Predict("question -> answer")
        wrapped_a = rd_a.wrap(predict_a)
        wrapped_a(question="Hello from convo A")
        rd_a.flush()

        rd_b = RaindropDSPy(api_key=WRITE_KEY, user_id=user_id, convo_id=convo_b)
        predict_b = dspy.Predict("question -> answer")
        wrapped_b = rd_b.wrap(predict_b)
        wrapped_b(question="Hello from convo B")
        rd_b.flush()

        time.sleep(3)
        rd_a.shutdown()
        rd_b.shutdown()

        rows = poll_events(user_id, min_count=2, timeout=90)

        convo_ids = [(r.get("aiData") or {}).get("convoId") for r in rows]
        assert convo_a in convo_ids, f"Expected convo_a={convo_a} in events, got {convo_ids}"
        assert convo_b in convo_ids, f"Expected convo_b={convo_b} in events, got {convo_ids}"


@skip_unless_e2e
class TestFactoryFunction:
    """create_raindrop_dspy factory produces working events."""

    def test_factory_event_shape(self):
        import dspy

        from raindrop_dspy import create_raindrop_dspy

        user_id = _make_user("factory")
        convo_id = _make_convo("factory")
        _setup_dspy()

        raindrop = create_raindrop_dspy(
            api_key=WRITE_KEY,
            user_id=user_id,
            convo_id=convo_id,
        )

        predict = dspy.Predict("question -> answer")
        wrapped = raindrop.wrap(predict)

        result = wrapped(question="What color is the sky?")
        assert result.answer is not None

        raindrop.flush()
        time.sleep(3)
        raindrop.shutdown()

        rows = poll_events(user_id)
        ev = rows[0]

        assert ev["userId"] == user_id
        ai = ev.get("aiData") or {}
        assert ai.get("input"), "Should have input"
        assert ai.get("output"), "Should have output"
        assert ai.get("convoId") == convo_id


@skip_unless_e2e
class TestDoubleWrapIdempotent:
    """Wrapping a module twice should not duplicate events."""

    def test_double_wrap_single_event(self):
        import dspy

        from raindrop_dspy import RaindropDSPy

        user_id = _make_user("dblwrap")
        _setup_dspy()

        raindrop = RaindropDSPy(api_key=WRITE_KEY, user_id=user_id)
        predict = dspy.Predict("question -> answer")

        wrapped = raindrop.wrap(predict)
        double_wrapped = raindrop.wrap(wrapped)
        assert wrapped is double_wrapped, "Second wrap should return same module"

        double_wrapped(question="Hello double wrap")

        raindrop.flush()
        time.sleep(3)
        raindrop.shutdown()

        rows = poll_events(user_id)
        assert len(rows) == 1, (
            f"Expected exactly 1 event (double wrap should not duplicate), got {len(rows)}"
        )
        ai = rows[0].get("aiData") or {}
        assert ai.get("input"), "Should have input"
        assert ai.get("output"), "Should have output"


@skip_unless_e2e
class TestErrorResilience:
    """A bad Raindrop key should not crash the DSPy call."""

    def test_bad_key_does_not_crash(self):
        import dspy

        from raindrop_dspy import RaindropDSPy

        _setup_dspy()

        raindrop = RaindropDSPy(api_key="invalid-key-for-test", user_id="test")
        predict = dspy.Predict("question -> answer")
        wrapped = raindrop.wrap(predict)

        result = wrapped(question="Say hello")
        assert result.answer is not None, "DSPy call should succeed despite bad Raindrop key"

        raindrop.shutdown()


@skip_unless_e2e
class TestModelNameCaptured:
    """Model name in aiData should contain gpt-4o-mini."""

    def test_model_field(self):
        import dspy

        from raindrop_dspy import RaindropDSPy

        user_id = _make_user("model")
        _setup_dspy()

        raindrop = RaindropDSPy(api_key=WRITE_KEY, user_id=user_id)
        predict = dspy.Predict("question -> answer")
        wrapped = raindrop.wrap(predict)

        wrapped(question="What is 3 + 3?")

        raindrop.flush()
        time.sleep(3)
        raindrop.shutdown()

        rows = poll_events(user_id)
        ai = rows[0].get("aiData") or {}
        model = ai.get("model") or ""
        assert "gpt-4o-mini" in model, f"Expected model to contain gpt-4o-mini, got: {model}"


@skip_unless_e2e
class TestEventNotPending:
    """Events should be finalized (isPending=false) after flush+shutdown."""

    def test_event_finalized(self):
        import dspy

        from raindrop_dspy import RaindropDSPy

        user_id = _make_user("pending")
        _setup_dspy()

        raindrop = RaindropDSPy(api_key=WRITE_KEY, user_id=user_id)
        predict = dspy.Predict("question -> answer")
        wrapped = raindrop.wrap(predict)

        wrapped(question="Is this finalized?")

        raindrop.flush()
        time.sleep(3)
        raindrop.shutdown()

        rows = poll_events(user_id)
        ev = rows[0]
        assert ev["userId"] == user_id
        assert "isPending" not in ev or not ev["isPending"], (
            f"Event should be finalized, but isPending={ev.get('isPending')}"
        )
