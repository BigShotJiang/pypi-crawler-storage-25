"""
DSPy module wrapper for Raindrop observability.

Wraps DSPy modules (Predict, ChainOfThought, etc.) to capture
input, output, model name, and token usage.

Usage:
    from raindrop_dspy import RaindropDSPy
    import dspy

    raindrop = RaindropDSPy(api_key="rk_...", debug=True)
    lm = dspy.LM("openai/gpt-4o-mini")
    dspy.configure(lm=lm)

    predict = dspy.Predict("question -> answer")
    wrapped = raindrop.wrap(predict)

    result = wrapped(question="What is the capital of France?")
    raindrop.flush()
"""

from __future__ import annotations

import asyncio
import json
import logging
import uuid
import warnings
from typing import TYPE_CHECKING, Any, Callable, Dict, Literal, Optional, Union

import raindrop.analytics as raindrop

if TYPE_CHECKING:
    import dspy

logger = logging.getLogger("raindrop_dspy")

_WRAPPED_ATTR = "_raindrop_wrapped"


class RaindropDSPy:
    """Raindrop observability wrapper for DSPy modules.

    Instruments DSPy Predict and ChainOfThought modules to capture
    input fields, output fields, model name, and token usage.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        user_id: Optional[str] = None,
        convo_id: Optional[str] = None,
        tracing_enabled: bool = True,
        bypass_otel_for_tools: bool = True,
        debug: bool = False,
    ) -> None:
        if not api_key:
            warnings.warn(
                "[raindrop-dspy] api_key not provided; telemetry shipping is disabled",
                stacklevel=2,
            )
        if debug:
            logger.setLevel(logging.DEBUG)
        raindrop.init(
            api_key=api_key or "",
            tracing_enabled=tracing_enabled,
            bypass_otel_for_tools=bypass_otel_for_tools,
        )
        self._user_id = user_id
        self._convo_id = convo_id
        self._debug = debug

    def wrap(self, module: dspy.Module) -> dspy.Module:
        """Wrap a DSPy module to capture forward/call invocations.

        Supports both sync and async ``forward`` methods. Modules already
        wrapped by this instance are returned unchanged (double-wrap guard).
        """
        try:
            return _wrap_module(module, user_id=self._user_id, convo_id=self._convo_id)
        except Exception:
            logger.debug("Failed to wrap module", exc_info=True)
            return module

    def flush(self) -> None:
        """Flush any buffered events to Raindrop."""
        try:
            raindrop.flush()
        except Exception:
            logger.debug("Failed to flush events", exc_info=True)

    def shutdown(self) -> None:
        """Flush remaining events and shut down the Raindrop client."""
        try:
            raindrop.shutdown()
        except Exception:
            logger.debug("Failed to shutdown", exc_info=True)

    def identify(
        self,
        user_id: str,
        traits: Optional[Dict[str, Union[str, int, bool, float]]] = None,
    ) -> None:
        """Identify a user with optional traits.

        Args:
            user_id: The user identifier.
            traits: Optional dictionary of user traits.
        """
        try:
            raindrop.identify(user_id=user_id, traits=traits or {})
        except Exception:
            logger.debug("Failed to identify user", exc_info=True)

    def track_signal(
        self,
        event_id: str,
        name: str,
        signal_type: Literal["default", "feedback", "edit"] = "default",
        *,
        timestamp: Optional[str] = None,
        properties: Optional[Dict[str, object]] = None,
        attachment_id: Optional[str] = None,
        comment: Optional[str] = None,
        after: Optional[str] = None,
        sentiment: Optional[Literal["POSITIVE", "NEGATIVE"]] = None,
    ) -> None:
        """Track a signal event.

        Args:
            event_id: The event ID to associate the signal with.
            name: Signal name.
            signal_type: One of "default", "feedback", or "edit".
            timestamp: Optional ISO-8601 timestamp string.
            properties: Optional extra properties dict.
            attachment_id: Optional attachment identifier.
            comment: Optional comment text.
            after: Optional "after" value for edit signals.
            sentiment: Optional sentiment ("POSITIVE" or "NEGATIVE").
        """
        try:
            raindrop.track_signal(
                event_id=event_id,
                name=name,
                signal_type=signal_type,
                timestamp=timestamp,
                properties=properties,
                attachment_id=attachment_id,
                comment=comment,
                after=after,
                sentiment=sentiment,
            )
        except Exception:
            logger.debug("Failed to track signal", exc_info=True)

    def __getitem__(self, key: str) -> Any:
        """Support dict-style access for backwards compatibility.

        .. deprecated::
            Use attribute access instead.
        """
        _COMPAT_KEYS = {"wrap", "flush", "shutdown"}
        if key in _COMPAT_KEYS:
            warnings.warn(
                f'raindrop["{key}"] is deprecated \u2014 use raindrop.{key} instead',
                DeprecationWarning,
                stacklevel=2,
            )
            return getattr(self, key)
        raise KeyError(key)


def create_raindrop_dspy(
    api_key: Optional[str] = None,
    user_id: Optional[str] = None,
    convo_id: Optional[str] = None,
    tracing_enabled: bool = True,
    bypass_otel_for_tools: bool = True,
    debug: bool = False,
) -> RaindropDSPy:
    """Create a Raindrop-instrumented DSPy wrapper.

    Factory function that returns a :class:`RaindropDSPy` instance.
    Kept for backwards compatibility.

    Args:
        api_key: Raindrop API key.
        user_id: Associate all events with this user.
        convo_id: Conversation ID to group related events.
        tracing_enabled: Enable OTEL tracing.
        bypass_otel_for_tools: Bypass OTEL for tool calls.
        debug: Enable debug logging.

    Returns:
        A :class:`RaindropDSPy` instance.
    """
    try:
        return RaindropDSPy(
            api_key=api_key,
            user_id=user_id,
            convo_id=convo_id,
            tracing_enabled=tracing_enabled,
            bypass_otel_for_tools=bypass_otel_for_tools,
            debug=debug,
        )
    except Exception:
        logger.debug("Failed to create RaindropDSPy", exc_info=True)
        return RaindropDSPy(
            api_key="",
            user_id=user_id,
            convo_id=convo_id,
            tracing_enabled=tracing_enabled,
            bypass_otel_for_tools=bypass_otel_for_tools,
            debug=debug,
        )


def _wrap_module(
    module: dspy.Module,
    user_id: Optional[str] = None,
    convo_id: Optional[str] = None,
) -> dspy.Module:
    """Patch a DSPy module's ``forward`` method with instrumentation.

    If the module has already been wrapped (detected via the
    ``_raindrop_wrapped`` attribute), it is returned unchanged.
    Both sync and async ``forward`` methods are supported.
    """
    if getattr(module, _WRAPPED_ATTR, False):
        logger.debug("Module already wrapped, skipping")
        return module

    try:
        original_forward: Optional[Callable[..., Any]] = getattr(module, "forward", None)
        if original_forward is None or not callable(original_forward):
            return module

        if asyncio.iscoroutinefunction(original_forward):
            async def wrapped_forward(*args: Any, **kwargs: Any) -> Any:
                """Async instrumented forward method."""
                return await _async_instrument_forward(
                    original_forward, args, kwargs, user_id, convo_id,
                )

            module.forward = wrapped_forward  # type: ignore[assignment]
        else:
            def wrapped_forward_sync(*args: Any, **kwargs: Any) -> Any:
                """Sync instrumented forward method."""
                return _instrument_forward(
                    original_forward, args, kwargs, user_id, convo_id,
                )

            module.forward = wrapped_forward_sync  # type: ignore[assignment]

        setattr(module, _WRAPPED_ATTR, True)
    except Exception:
        logger.debug("Failed to wrap module", exc_info=True)

    return module


def _instrument_forward(
    original_fn: Callable[..., Any],
    args: tuple[Any, ...],
    kwargs: Dict[str, Any],
    user_id: Optional[str],
    convo_id: Optional[str],
) -> Any:
    """Run the original sync ``forward`` and emit a Raindrop event.

    On success the event includes input, output, model, and token usage.
    On failure the event captures the error type and message in properties
    before re-raising the exception.
    """
    try:
        input_text = _extract_input(kwargs)
        model_name = _get_model_name()
        event_id = str(uuid.uuid4())
    except Exception:
        logger.debug("Failed to extract pre-call metadata", exc_info=True)
        return original_fn(*args, **kwargs)

    try:
        result = original_fn(*args, **kwargs)
    except Exception as exc:
        _track_error(exc, event_id, input_text, model_name, user_id, convo_id)
        raise

    try:
        output_text = _extract_output(result)
        properties = _extract_usage(result)
        finish_reason = _extract_finish_reason()
        if finish_reason is not None:
            properties = properties or {}
            properties["dspy.finish_reason"] = finish_reason

        raindrop.track_ai(
            user_id=user_id or "unknown",
            event="ai_generation",
            event_id=event_id,
            input=input_text,
            output=output_text,
            model=model_name,
            properties=properties,
            convo_id=convo_id,
        )
    except Exception:
        logger.debug("Failed to track successful forward call", exc_info=True)

    return result


async def _async_instrument_forward(
    original_fn: Callable[..., Any],
    args: tuple[Any, ...],
    kwargs: Dict[str, Any],
    user_id: Optional[str],
    convo_id: Optional[str],
) -> Any:
    """Run the original async ``forward`` and emit a Raindrop event.

    Async counterpart of :func:`_instrument_forward`. Captures the same
    telemetry (input, output, model, tokens, errors).
    """
    try:
        input_text = _extract_input(kwargs)
        model_name = _get_model_name()
        event_id = str(uuid.uuid4())
    except Exception:
        logger.debug("Failed to extract pre-call metadata (async)", exc_info=True)
        return await original_fn(*args, **kwargs)

    try:
        result = await original_fn(*args, **kwargs)
    except Exception as exc:
        _track_error(exc, event_id, input_text, model_name, user_id, convo_id)
        raise

    try:
        output_text = _extract_output(result)
        properties = _extract_usage(result)
        finish_reason = _extract_finish_reason()
        if finish_reason is not None:
            properties = properties or {}
            properties["dspy.finish_reason"] = finish_reason

        raindrop.track_ai(
            user_id=user_id or "unknown",
            event="ai_generation",
            event_id=event_id,
            input=input_text,
            output=output_text,
            model=model_name,
            properties=properties,
            convo_id=convo_id,
        )
    except Exception:
        logger.debug("Failed to track successful async forward call", exc_info=True)

    return result


def _track_error(
    exc: BaseException,
    event_id: str,
    input_text: Optional[str],
    model_name: Optional[str],
    user_id: Optional[str],
    convo_id: Optional[str],
) -> None:
    """Emit a Raindrop event for a failed forward call.

    Captures the exception type and message as event properties so
    errors are visible in the Raindrop dashboard.
    """
    try:
        properties: Dict[str, Any] = {
            "error.type": type(exc).__name__,
            "error.message": str(exc),
        }
        raindrop.track_ai(
            user_id=user_id or "unknown",
            event="ai_generation",
            event_id=event_id,
            input=input_text,
            model=model_name,
            properties=properties,
            convo_id=convo_id,
        )
    except Exception:
        logger.debug("Failed to track error event", exc_info=True)


def _extract_input(kwargs: Optional[Dict[str, Any]]) -> Optional[str]:
    """Extract a readable input string from DSPy module keyword arguments.

    Concatenates all string values; non-string values are JSON-serialized.
    Returns ``None`` when *kwargs* is empty or ``None``.
    """
    if not kwargs:
        return None
    try:
        parts: list[str] = []
        for value in kwargs.values():
            if isinstance(value, str):
                parts.append(value)
            else:
                try:
                    parts.append(json.dumps(value, default=str))
                except Exception:
                    logger.debug("Failed to serialize input value", exc_info=True)
                    parts.append(str(value))
        return "\n".join(parts) if parts else None
    except Exception:
        logger.debug("Failed to extract input", exc_info=True)
        return None


def _extract_output(result: Any) -> Optional[str]:
    """Extract output text from a DSPy ``Prediction`` result.

    Tries ``toDict()`` first, then well-known attribute names, and falls
    back to ``str(result)``.
    """
    if result is None:
        return None
    try:
        if hasattr(result, "toDict"):
            d: Dict[str, Any] = result.toDict()
            values = [str(v) for v in d.values() if v is not None]
            return "\n".join(values) if values else None

        for attr in ("answer", "output", "response", "text", "completion"):
            val = getattr(result, attr, None)
            if val is not None:
                return str(val)

        return str(result)
    except Exception:
        logger.debug("Failed to extract output", exc_info=True)
        return None


def _get_model_name() -> Optional[str]:
    """Return the model name from the active DSPy LM configuration.

    Accesses ``dspy.settings.lm.model`` when available.
    """
    try:
        import dspy

        settings = getattr(dspy, "settings", None)
        if settings:
            lm = getattr(settings, "lm", None)
            if lm:
                model = getattr(lm, "model", None)
                if model:
                    return str(model)
    except Exception:
        logger.debug("Failed to get DSPy model name", exc_info=True)
    return None


def _get_last_lm_response() -> Any:
    """Return the response object from the most recent DSPy LM history entry.

    Navigates ``dspy.settings.lm.history[-1]["response"]``.  Returns
    ``None`` when DSPy is not configured, the LM has no history, or the
    last entry has no response.

    Caveat: When DSPy's caching is active and the call is a cache hit, no
    new entry is appended to LM history, so this may return a stale value
    from a previous uncached call.
    """
    try:
        import dspy

        settings = getattr(dspy, "settings", None)
        if not settings:
            return None
        lm = getattr(settings, "lm", None)
        if not lm:
            return None
        history = getattr(lm, "history", None)
        if not history:
            return None
        last_entry = history[-1]
        return last_entry.get("response") if isinstance(last_entry, dict) else None
    except Exception:
        logger.debug("Failed to read LM history", exc_info=True)
        return None


def _extract_finish_reason() -> Optional[str]:
    """Extract finish_reason from the most recent DSPy LM completion.

    Reads ``response.choices[0].finish_reason`` from the last LM history
    entry.  Returns ``None`` when unavailable.
    """
    try:
        response = _get_last_lm_response()
        if response is None:
            return None
        choices = getattr(response, "choices", None)
        if choices and len(choices) > 0:
            reason = getattr(choices[0], "finish_reason", None)
            if reason is not None:
                return str(reason)
    except Exception:
        logger.debug("Failed to extract finish_reason", exc_info=True)
    return None


def _extract_usage(result: Any) -> Optional[Dict[str, Any]]:
    """Extract token usage from a DSPy ``Prediction`` result.

    Tries these sources in order (each wrapped independently so a failure
    in one does not short-circuit the rest):
    1. ``result.get_lm_usage()`` — returns ``{lm: {prompt_tokens, completion_tokens}}``
    2. ``result.usage`` attribute (dict or object)
    3. ``dspy.settings.lm.history[-1]["response"].usage`` — LM history fallback
       (DSPy 3.x doesn't expose usage on Prediction, but the underlying
       LiteLLM response in the LM history always has it)
    """
    try:
        get_usage = getattr(result, "get_lm_usage", None)
        if callable(get_usage):
            usage_dict = get_usage()
            if isinstance(usage_dict, dict) and usage_dict:
                props: Dict[str, Any] = {}
                total_prompt = 0
                total_completion = 0
                for lm_usage in usage_dict.values():
                    if isinstance(lm_usage, dict):
                        total_prompt += lm_usage.get("prompt_tokens", 0) or 0
                        total_completion += lm_usage.get("completion_tokens", 0) or 0
                if total_prompt > 0:
                    props["ai.usage.prompt_tokens"] = total_prompt
                if total_completion > 0:
                    props["ai.usage.completion_tokens"] = total_completion
                if props:
                    return props
    except Exception:
        logger.debug("Failed to extract usage via get_lm_usage()", exc_info=True)

    try:
        usage = getattr(result, "usage", None)
        if usage is not None:
            props = {}
            if isinstance(usage, dict):
                pt = usage.get("prompt_tokens")
                ct = usage.get("completion_tokens")
            else:
                pt = getattr(usage, "prompt_tokens", None)
                ct = getattr(usage, "completion_tokens", None)
            if pt is not None:
                props["ai.usage.prompt_tokens"] = pt
            if ct is not None:
                props["ai.usage.completion_tokens"] = ct
            if props:
                return props
    except Exception:
        logger.debug("Failed to extract usage from result.usage", exc_info=True)

    return _extract_usage_from_history()


def _extract_usage_from_history() -> Optional[Dict[str, Any]]:
    """Extract token usage from the most recent DSPy LM history entry.

    Reads ``response.usage`` from :func:`_get_last_lm_response`.
    """
    try:
        response = _get_last_lm_response()
        if response is None:
            return None
        usage = getattr(response, "usage", None)
        if usage is None:
            return None
        pt = getattr(usage, "prompt_tokens", None)
        ct = getattr(usage, "completion_tokens", None)
        props: Dict[str, Any] = {}
        if pt is not None:
            props["ai.usage.prompt_tokens"] = pt
        if ct is not None:
            props["ai.usage.completion_tokens"] = ct
        return props if props else None
    except Exception:
        logger.debug("Failed to extract usage from LM history", exc_info=True)
        return None
