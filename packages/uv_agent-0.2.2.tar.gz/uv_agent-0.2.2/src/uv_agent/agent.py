from __future__ import annotations

import asyncio
import copy
import hashlib
import json
import re
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from html import escape as xml_escape
from pathlib import Path
from time import monotonic
from typing import Any, Callable

from uv_agent.attachments import AttachmentStore, image_message_item
from uv_agent.config import AppConfig
from uv_agent.context import ContextStats, estimate_tokens, usage_token_count
from uv_agent.environment import detect_user_language, host_environment, host_environment_line
from uv_agent.ids import new_id
from uv_agent.mcp_config import discover_mcp_servers, render_mcp_summary
from uv_agent.model_client import ModelClient, ModelResponse
from uv_agent.paths import project_state_dir, uv_agent_home
from uv_agent.project_rules import (
    ProjectRuleContext,
    discover_workspace_rule_index,
    load_directory_rules,
    load_project_rules,
)
from uv_agent.runner import PythonRunRequest, PythonRunner, RerunRequest
from uv_agent.session.store import ThreadSnapshot, ThreadStore, digest_items
from uv_agent.skills import discover_skills, render_skill_summary


DEFAULT_THREAD_TITLES = {"New thread", "new thread", "新会话"}
COMPACTION_USER_MESSAGE_MAX_TOKENS = 20_000
COMPACTION_SUMMARIZATION_PROMPT = (
    "You are performing a CONTEXT CHECKPOINT COMPACTION. Create a handoff summary for "
    "another LLM that will resume the task.\n\n"
    "Include:\n"
    "- Current progress and key decisions made\n"
    "- Important context, constraints, or user preferences\n"
    "- What remains to be done (clear next steps)\n"
    "- Any critical data, examples, or references needed to continue\n\n"
    "Be concise, structured, and focused on helping the next LLM seamlessly continue the work."
)
TITLE_GENERATION_PROMPT = (
    "Create a concise title for this uv-agent thread from the user's first message. "
    "Return only the title, without quotes or punctuation. Prefer the user's language. "
    "Keep it under 8 words or 24 CJK characters."
)
COMPACTED_CONTEXT_CONTINUATION = (
    "The messages above may include several earlier user messages preserved for continuity. "
    "Continue from this compacted context."
)


class TurnInterrupted(Exception):
    """Raised internally when the active turn is interrupted by the user."""


PYTHON_TOOL = {
    "type": "function",
    "name": "run_python",
    "description": (
        "Run a Python script through the uv-agent Python runner. Use this as the only "
        "way to inspect files, call subprocesses, access the network, or perform external actions. "
        "Declare third-party dependencies inside the script with PEP 723 inline metadata, "
        "or rerun a previously saved script by script_id/run_id."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "code": {
                "type": "string",
                "description": "Complete Python script source. Include PEP 723 inline metadata when dependencies are needed. Omit only when rerunning by script_id/run_id.",
            },
            "script_id": {
                "type": "string",
                "description": "Previously saved script id to rerun instead of creating new code.",
            },
            "run_id": {
                "type": "string",
                "description": "Previous run id to replay or rerun.",
            },
            "rerun_mode": {
                "type": "string",
                "enum": ["rerun", "replay"],
                "description": "rerun uses fresh args; replay inherits the previous run context when run_id is given.",
                "default": "rerun",
            },
            "uv_args": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Exceptional extra arguments for uv run, such as --refresh-package.",
                "default": [],
            },
            "script_args": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Arguments passed to the Python script.",
                "default": [],
            },
            "timeout_s": {
                "type": "number",
                "description": "Execution timeout in seconds.",
                "default": 7200,
            },
        },
        "required": [],
        "additionalProperties": False,
    },
    "strict": False,
}


SYSTEM_INSTRUCTIONS_TEMPLATE = """<uv_agent_system_prompt>
<identity>
You are uv-agent, an experimental coding agent.
</identity>

<environment>
<workspace>{workspace}</workspace>
<user_state>{user_state}</user_state>
<project_state>{project_state}</project_state>
<host>{host_environment}</host>
<user_language>{user_language}</user_language>
<persistence>Persisted scripts, runs, and threads live under the project state directory.</persistence>
</environment>

{model_levels}

<tool_boundary>
<rule>You have exactly one external action tool: run_python.</rule>
<rule>Use Python for file inspection, edits, subprocesses, network access, and verification.</rule>
<rule>Do not assume shell, filesystem, browser, or network tools exist outside Python.</rule>
<rule>When dependencies or a Python version constraint are needed, put PEP 723 inline metadata at the top of the script, for example:
# /// script
# requires-python = ">=3.12"
# dependencies = [
#   "requests",
# ]
# ///
</rule>
<rule>If no inline metadata is needed, write plain Python source without a metadata block and treat it like normal project code, not a temporary-script wrapper. uv_agent_runtime is injected automatically even if metadata is omitted.</rule>
<rule>Use uv_args only for exceptional uv behavior such as refresh, reinstall, or debug flags.</rule>
<rule>Do not rely on the system to truncate oversized output for you; when output may be large, limit and summarize it in your Python code before printing.</rule>
<rule>Prefer small inspect-then-change steps, then run focused verification when behavior changes.</rule>
<rule>Never print secrets; summarize sensitive config after redaction.</rule>
</tool_boundary>

<runtime_helpers>
<imports>
from uv_agent_runtime import (
    apply_patch,
    enter_dir,
    look_at,
    ask,
    saved_scripts,
    thread_digest,
    list_thread_digests,
    list_declared_servers,
    connect_declared,
    connect_named,
)
</imports>
<helper name="apply_patch">
Applies focused file edits using uv-agent_runtime's custom patch envelope. The body looks like a unified diff, but it must be wrapped with *** Begin Patch and *** End Patch. Each file operation starts with one of:
- *** Add File: path
- *** Update File: path
- *** Delete File: path

For update hunks, use @@ as the hunk marker, prefix unchanged context lines with a space, removed lines with -, and added lines with +. Keep patches small and use paths relative to the current workspace unless an absolute path is necessary.
Example:
apply_patch('''*** Begin Patch
*** Update File: path.txt
@@
 old context
-old value
+new value
*** End Patch
''')
</helper>
<helper name="enter_dir">
Changes the script working directory like os.chdir(path), persists that directory for later runs in this thread, and may automatically load AGENTS directory rules for that location.
Example:
enter_dir("src")
</helper>
<helper name="look_at">
Attaches an image to future model context.
Example:
look_at("screenshots/error.png", note="inspect failing UI")
</helper>
<helper name="rerun">
Rerun saved scripts by passing script_id or run_id to run_python; omit code when rerunning.
</helper>
<helper name="ask">
Invokes a nested uv-agent subagent for isolated, tedious, or parallelizable work. The result has .text, .stdout, .stderr, .thread_id, and .raise_for_error().
Pass level only when intentionally choosing one of the configured model levels listed in <model_levels>; otherwise omit it.
Example:
result = ask("Inspect parser tests", check=True, timeout_s=300)
print(result.text[:1000])
</helper>
<helper name="saved_scripts">
saved_scripts(limit=32) returns recent managed scripts with script_id, summary, run_count, last_used_at, and paths.
Example:
for script in saved_scripts(limit=5):
    print(script["script_id"], script["summary"])
</helper>
<helper name="threads">
thread_digest(thread_id) and list_thread_digests(limit=10) return compact cross-thread summaries.
Example:
threads = list_thread_digests(limit=5)
if threads:
    print(threads[0]["thread_id"], threads[0]["last_text"])
</helper>
<helper name="mcp">
MCP helpers connect to declared stdio MCP servers; call MCP through Python, not as model tools. Use list_declared_servers() to discover names, connect_named(name) for project/user declarations, or connect_declared(name, config_path=".agents/mcp.json") for one config file.
Example:
print(list_declared_servers())
with connect_named("files") as client:
    client.initialize()
    print(client.list_tools())
    result = client.call_tool("read_file", {{"path": "README.md"}})
    print(result.value)

Raw MCP requests are also available with client.request(method, params) and notifications with client.notify(method, params).
</helper>
<helper>Use Python standard library modules such as pathlib, os, json, and subprocess for ordinary files, JSON, traversal, and commands.</helper>
<helper>Do not guess helper signatures; inspect uv_agent_runtime implementation when an exact signature matters.</helper>
</runtime_helpers>

<mentions>
<rule>User text may include @file, @thread:id, @mcp:name, or @skill:name references. Mentions are plain-text hints only; they do not attach, load, connect, or call anything automatically.</rule>
<rule>When a mentioned file matters, inspect it with Python standard library APIs. When a mentioned thread matters, use thread_digest or list_thread_digests.</rule>
<rule>When a mentioned skill matters, read its SKILL.md from the available skills context. When a mentioned MCP server matters, use uv_agent_runtime MCP helpers from Python.</rule>
</mentions>

<dynamic_workspace_context>
<rule>Directory rules from AGENTS files are loaded automatically for the active working directory. A bounded workspace_rule_index may list rule file locations without loading their full contents.</rule>
<rule>Skills and MCP declarations are appended only when first seen, changed, removed, or after compaction, and only as context immediately before the current user message.</rule>
<rule>A removal notice means older appended capability context must not be used unless it appears again.</rule>
<rule>Interrupted turns may appear in context as summaries of partial work; do not assume unfinished tool calls completed.</rule>
</dynamic_workspace_context>
</uv_agent_system_prompt>
"""


@dataclass
class TurnInputState:
    input_items: list[dict[str, Any]]
    previous_response_id: str | None = None
    use_previous_response_id: bool = False
    pending_items: list[dict[str, Any]] = field(default_factory=list)

    def request_input_items(self) -> list[dict[str, Any]]:
        if self.use_previous_response_id and self.previous_response_id:
            return copy.deepcopy(self.pending_items)
        return copy.deepcopy(self.input_items)


@dataclass
class RuleRuntimeState:
    active_cwd: Path
    loaded_rule_paths: set[Path] = field(default_factory=set)
    index_emitted: bool = False
    cwd_notice_cwd: Path | None = None


class AgentEngine:
    def __init__(
        self,
        *,
        config: AppConfig,
        model_client: ModelClient,
        runner: PythonRunner,
        thread_store: ThreadStore,
        project_root: Path,
        config_loader: Callable[[], AppConfig] | None = None,
    ) -> None:
        self.config = config
        self.model_client = model_client
        self.runner = runner
        self.thread_store = thread_store
        self.project_root = project_root
        self.attachments = AttachmentStore(thread_store.data_dir)
        self._last_config_refresh_at = 0.0
        self._config_loader = config_loader
        self._host_environment = host_environment()
        self._rule_states: dict[str, RuleRuntimeState] = {}

    def refresh_config(self, *, force: bool = False) -> None:
        """Reload user/project config for long-running sessions."""
        if self._config_loader is None:
            return
        now = monotonic()
        if not force and now - self._last_config_refresh_at < 1.0:
            return
        self.config = self._config_loader()
        if hasattr(self.model_client, "reload_config"):
            self.model_client.reload_config(self.config)  # type: ignore[attr-defined]
        self.runner.config = self.config.runner
        self._last_config_refresh_at = now

    async def run_turn(
        self,
        *,
        user_text: str,
        thread_id: str | None = None,
        level: str | None = None,
        image_paths: list[str | Path] | None = None,
        cancel_event: asyncio.Event | None = None,
    ) -> AsyncIterator[dict[str, Any]]:
        self.refresh_config(force=True)
        thread_id = thread_id or self.thread_store.create_thread("New thread")
        system_instructions = self._system_instructions_for_turn(thread_id)
        turn_id = new_id("turn")
        should_generate_title = self._should_generate_title(thread_id)
        turn_input = self._prepare_turn_input(thread_id, level=level)
        input_items = turn_input.input_items
        request_input_items = turn_input.request_input_items()
        pre_user_items = self._pre_user_context_items(thread_id)
        self.thread_store.append(thread_id, "turn.started", turn_id=turn_id)
        user_item = message_item("user", user_text)
        self.thread_store.append(thread_id, "item.user", turn_id=turn_id, item=user_item)
        title_task = self._start_title_generation_task(
            thread_id,
            user_text,
            should_generate=should_generate_title,
            level=level,
        )
        input_items.extend(pre_user_items)
        request_input_items.extend(pre_user_items)
        turn_input.pending_items.extend(pre_user_items)
        input_items.append(user_item)
        request_input_items.append(user_item)
        turn_input.pending_items.append(user_item)
        for image_path in image_paths or []:
            attachment = self.attachments.register_image(
                image_path,
                cwd=self.project_root,
                thread_id=thread_id,
                note="pasted from clipboard",
            )
            payload = attachment.to_event_payload()
            self.thread_store.append(
                thread_id,
                "item.image_attachment",
                turn_id=turn_id,
                attachment=payload,
            )
            image_item = image_message_item(payload)
            input_items.append(image_item)
            request_input_items.append(image_item)
            turn_input.pending_items.append(image_item)
            yield {
                "type": "image.attachment",
                "thread_id": thread_id,
                "turn_id": turn_id,
                "attachment": payload,
            }

        final_text = ""
        assistant_parts: list[str] = []
        reasoning_parts: list[str] = []
        try:
            for round_index in range(self.config.runtime.max_agent_rounds):
                self._raise_if_cancelled(cancel_event)
                response: ModelResponse | None = None
                async for stream_event in self._stream_response_until_cancelled(
                    input_items=copy.deepcopy(request_input_items),
                    level=level,
                    instructions=system_instructions,
                    cancel_event=cancel_event,
                    previous_response_id=turn_input.previous_response_id,
                ):
                    self._raise_if_cancelled(cancel_event)
                    if stream_event.type == "text_delta" and stream_event.text:
                        assistant_parts.append(stream_event.text)
                        yield {
                            "type": "assistant.delta",
                            "thread_id": thread_id,
                            "turn_id": turn_id,
                            "text": stream_event.text,
                        }
                    elif stream_event.type == "reasoning_delta" and stream_event.text:
                        reasoning_parts.append(stream_event.text)
                        yield {
                            "type": "assistant.reasoning_delta",
                            "thread_id": thread_id,
                            "turn_id": turn_id,
                            "text": stream_event.text,
                        }
                    elif stream_event.type == "tool_call_delta" and stream_event.tool_call:
                        yield {
                            "type": "tool.delta",
                            "thread_id": thread_id,
                            "turn_id": turn_id,
                            "tool_call": stream_event.tool_call,
                        }
                    elif stream_event.type == "completed":
                        response = stream_event.response
                self._raise_if_cancelled(cancel_event)
                if response is None:
                    raise RuntimeError("Model stream ended without completion")
                reasoning_text = response.reasoning_text or "".join(reasoning_parts).strip()
                self.thread_store.append(
                    thread_id,
                    "item.model_response",
                    turn_id=turn_id,
                    model_api=self._model_api_for_level(level),
                    response_id=response.id,
                    output=response.output,
                    usage=response.usage,
                    reasoning_text=reasoning_text,
                )
                yield {
                    "type": "model.response",
                    "thread_id": thread_id,
                    "turn_id": turn_id,
                    "response": response,
                }
                input_items.extend(response.output)
                turn_input.previous_response_id = response.id
                turn_input.use_previous_response_id = bool(
                    response.id and self._level_uses_responses_api(level)
                )
                turn_input.pending_items.clear()
                request_input_items = turn_input.request_input_items()
                assistant_parts.clear()
                reasoning_parts.clear()

                tool_calls = [item for item in response.output if item.get("type") == "function_call"]
                if not tool_calls:
                    final_text = response.output_text
                    break

                for call_index, call in enumerate(tool_calls):
                    self._raise_if_cancelled(cancel_event)
                    self.thread_store.append(
                        thread_id,
                        "item.tool_call",
                        turn_id=turn_id,
                        item=call,
                    )
                    yield {
                        "type": "tool.started",
                        "thread_id": thread_id,
                        "turn_id": turn_id,
                        "call": call,
                        "tool_call_index": call_index,
                    }
                    tool_output, attachments, display_output = await self._handle_tool_call(
                        call,
                        thread_id,
                        turn_id,
                        cancel_event=cancel_event,
                    )
                    self.thread_store.append(
                        thread_id,
                        "item.tool_output",
                        turn_id=turn_id,
                        item=tool_output,
                    )
                    input_items.append(tool_output)
                    request_input_items.append(tool_output)
                    turn_input.pending_items.append(tool_output)
                    for attachment in attachments:
                        image_item = image_message_item(attachment)
                        input_items.append(image_item)
                        turn_input.pending_items.append(image_item)
                        request_input_items.append(image_item)
                    yield {
                        "type": "tool.output",
                        "thread_id": thread_id,
                        "turn_id": turn_id,
                        "call": call,
                        "tool_call_index": call_index,
                        "output": display_output,
                    }
            else:
                raise RuntimeError("Agent exceeded max_agent_rounds")
        except (asyncio.CancelledError, TurnInterrupted):
            partial_text = "".join(assistant_parts).strip()
            if partial_text:
                self.thread_store.append(
                    thread_id,
                    "item.assistant_partial",
                    turn_id=turn_id,
                    text=partial_text,
                )
            reasoning_text = "".join(reasoning_parts).strip()
            if reasoning_text:
                self.thread_store.append(
                    thread_id,
                    "item.reasoning_partial",
                    turn_id=turn_id,
                    text=reasoning_text,
                )
            self.thread_store.append(
                thread_id,
                "turn.interrupted",
                turn_id=turn_id,
                reason="user_interrupt",
            )
            yield {
                "type": "turn.interrupted",
                "thread_id": thread_id,
                "turn_id": turn_id,
                "reason": "user_interrupt",
            }
            if title_task is not None:
                title_task.cancel()
            return

        self.thread_store.append(
            thread_id,
            "turn.completed",
            turn_id=turn_id,
            final_text=final_text,
        )
        compacted = await self._maybe_compact(
            thread_id,
            turn_id,
            input_items,
            level=level,
            instructions=system_instructions,
        )
        if compacted:
            yield {
                "type": "compaction.completed",
                "thread_id": thread_id,
                "turn_id": turn_id,
            }
        generated_title = await self._finish_title_generation(title_task)
        if generated_title:
            yield {
                "type": "thread.title",
                "thread_id": thread_id,
                "turn_id": turn_id,
                "title": generated_title,
            }
        yield {
            "type": "turn.completed",
            "thread_id": thread_id,
            "turn_id": turn_id,
            "final_text": final_text,
        }

    def _should_generate_title(self, thread_id: str) -> bool:
        if not self.config.runtime.title_generation.enabled:
            return False
        metadata = self.thread_store.snapshot(thread_id).metadata
        if int(metadata.get("user_message_count") or 0) > 0:
            return False
        return self._thread_title_is_pending(metadata)

    def _thread_title_is_pending(self, metadata: dict[str, Any]) -> bool:
        if metadata.get("title_updated_at"):
            return False
        return is_default_thread_title(str(metadata.get("title") or ""))

    def _start_title_generation_task(
        self,
        thread_id: str,
        user_text: str,
        *,
        should_generate: bool,
        level: str | None,
    ) -> asyncio.Task[str | None] | None:
        if not should_generate:
            return None
        return asyncio.create_task(self._maybe_generate_title(thread_id, user_text, level=level))

    async def _finish_title_generation(
        self,
        title_task: asyncio.Task[str | None] | None,
    ) -> str | None:
        if title_task is None:
            return None
        try:
            return await title_task
        except asyncio.CancelledError:
            return None

    async def _maybe_generate_title(
        self,
        thread_id: str,
        user_text: str,
        *,
        level: str | None,
    ) -> str | None:
        try:
            title = await self._generate_thread_title(user_text, level=level)
        except Exception:
            return None
        if not title or not self._thread_title_is_pending(self.thread_store.snapshot(thread_id).metadata):
            return None
        self.thread_store.update_title(thread_id, title, source="generated")
        return title

    async def _generate_thread_title(self, user_text: str, *, level: str | None) -> str | None:
        title_level = self.config.runtime.title_generation.model_level or level
        response = await self.model_client.create_response(
            input_items=[
                message_item(
                    "user",
                    TITLE_GENERATION_PROMPT
                    + "\n\nUser message:\n"
                    + user_text.strip(),
                )
            ],
            level=title_level,
            tools=[],
            instructions="Generate a short thread title. Return only the title.",
        )
        return clean_thread_title(response.output_text)

    async def _maybe_compact(
        self,
        thread_id: str,
        turn_id: str,
        input_items: list[dict[str, Any]],
        *,
        level: str | None,
        instructions: str,
    ) -> bool:
        if not self.config.runtime.compression.enabled:
            return False
        compact_level = self.config.runtime.compression.model_level or level
        model = self.config.model_for_level(compact_level)
        approx_tokens = estimate_tokens(input_items)
        if approx_tokens < self.config.runtime.compression.min_tokens:
            return False
        trigger_tokens = int(
            model.context_window_tokens
            * self.config.runtime.compression.trigger_ratio
        )
        if approx_tokens < trigger_tokens:
            return False
        compact_input = copy.deepcopy(input_items)
        compact_input.append(self._compaction_trigger_item())
        response = await self.model_client.create_response(
            input_items=compact_input,
            level=compact_level,
            tools=[PYTHON_TOOL],
            instructions=instructions,
        )
        replacement_input = self._compaction_replacement_input(input_items, response)
        context_state = self._latest_context_state(thread_id)
        self.thread_store.append(
            thread_id,
            "item.compaction",
            turn_id=turn_id,
            text=response.output_text,
            output=response.output,
            replacement_input=replacement_input,
            context_state=context_state,
            usage=response.usage,
        )
        self._reset_rule_epoch(thread_id)
        return True

    def _compaction_trigger_item(self) -> dict[str, Any]:
        return message_item(
            "user",
            "<context_compaction_request>\n"
            + COMPACTION_SUMMARIZATION_PROMPT
            + "\n\n"
            + "Return only the continuation summary. Preserve user intent, decisions, "
            + "file changes, tool results, and unresolved tasks. Do not restate AGENTS "
            + "directory rules; they are reloaded automatically when needed.\n"
            + "</context_compaction_request>",
        )

    def _compaction_replacement_input(
        self,
        input_items: list[dict[str, Any]],
        response: ModelResponse,
    ) -> list[dict[str, Any]]:
        replacement = self._retained_user_messages_after_compaction(input_items)
        summary = response.output_text.strip() or "(no summary available)"
        replacement.append(
            message_item(
                "user",
                "<conversation_summary>\n"
                + summary
                + "\n</conversation_summary>\n"
                + COMPACTED_CONTEXT_CONTINUATION,
            )
        )
        return replacement

    def _retained_user_messages_after_compaction(self, input_items: list[dict[str, Any]]) -> list[dict[str, Any]]:
        selected: list[dict[str, Any]] = []
        remaining = COMPACTION_USER_MESSAGE_MAX_TOKENS
        for item in reversed(input_items):
            if not self._retain_item_after_compaction(item):
                continue
            tokens = estimate_tokens([item])
            if tokens <= remaining:
                selected.append(copy.deepcopy(item))
                remaining -= tokens
                if remaining <= 0:
                    break
                continue
            text = message_item_text(item)
            if remaining > 0 and text:
                selected.append(message_item("user", truncate_text_to_estimated_tokens(text, remaining)))
            break
        selected.reverse()
        return selected

    @staticmethod
    def _retain_item_after_compaction(item: dict[str, Any]) -> bool:
        if item.get("type") != "message" or item.get("role") not in {"user"}:
            return False
        text = message_item_text(item)
        return not (
            "<workspace_rules" in text
            or "<workspace_rule_index>" in text
            or "<directory_rules_loaded>" in text
            or "<active_cwd_notice>" in text
            or "<conversation_summary>" in text
            or "<available_skills>" in text
            or "<available_mcp_servers>" in text
            or "<context_update" in text
        )

    async def _handle_tool_call(
        self,
        call: dict[str, Any],
        thread_id: str,
        turn_id: str,
        *,
        cancel_event: asyncio.Event | None = None,
    ) -> tuple[dict[str, Any], list[dict[str, Any]], dict[str, Any]]:
        if call.get("name") != "run_python":
            output = {"error": f"Unsupported tool: {call.get('name')}"}
            tool_output = function_output(call, output)
            return tool_output, [], tool_output
        try:
            args = json.loads(call.get("arguments") or "{}")
        except json.JSONDecodeError as exc:
            output = {"error": f"Invalid tool arguments JSON: {exc}"}
            tool_output = function_output(call, output)
            return tool_output, [], tool_output

        if args.get("script_id") or args.get("run_id"):
            result = await self.runner.rerun(
                RerunRequest(
                    script_id=args.get("script_id"),
                    run_id=args.get("run_id"),
                    mode="replay" if args.get("rerun_mode") == "replay" else "rerun",
                    uv_args=list(args.get("uv_args") or []),
                    script_args=list(args.get("script_args") or []),
                    timeout_s=float(args.get("timeout_s") or self.config.runner.default_timeout_s),
                    cwd=self._active_cwd(thread_id),
                    thread_id=thread_id,
                    turn_id=turn_id,
                    cancel_event=cancel_event,
                )
            )
        else:
            code = args.get("code")
            if not isinstance(code, str) or not code.strip():
                output = {"error": "run_python requires code, script_id, or run_id"}
                tool_output = function_output(call, output)
                return tool_output, [], tool_output
            result = await self.runner.run(
                PythonRunRequest(
                    code=code,
                    uv_args=list(args.get("uv_args") or []),
                    script_args=list(args.get("script_args") or []),
                    timeout_s=float(args.get("timeout_s") or self.config.runner.default_timeout_s),
                    cwd=self._active_cwd(thread_id),
                    thread_id=thread_id,
                    turn_id=turn_id,
                    cancel_event=cancel_event,
                )
            )
        if result.interrupted:
            raise TurnInterrupted()
        rule_events, visible_events = self._process_runner_events(
            result.events,
            thread_id=thread_id,
            turn_id=turn_id,
        )
        payload = {
            "script_id": result.script_id,
            "run_id": result.run_id,
            "returncode": result.returncode,
            "timed_out": result.timed_out,
            "interrupted": result.interrupted,
            "truncated": result.truncated,
            "stdout": result.stdout,
            "stderr": result.stderr,
            "events": visible_events,
            "run_log_path": str(result.run_log_path),
        }
        if rule_events:
            payload["rules_loaded"] = rule_events
        attachments = self._register_look_at_events(
            visible_events,
            thread_id=thread_id,
            turn_id=turn_id,
            cwd=self._active_cwd(thread_id),
        )
        if attachments:
            payload["attachments"] = attachments
        self.thread_store.append(
            thread_id,
            "item.runner_result",
            turn_id=turn_id,
            call_id=call.get("call_id"),
            result=payload,
        )
        return function_output(call, model_tool_payload(payload)), attachments, function_output(call, payload)

    @staticmethod
    def _raise_if_cancelled(cancel_event: asyncio.Event | None) -> None:
        if cancel_event is not None and cancel_event.is_set():
            raise TurnInterrupted()

    async def _stream_response_until_cancelled(
        self,
        *,
        input_items: list[dict[str, Any]],
        level: str | None,
        instructions: str,
        cancel_event: asyncio.Event | None,
        previous_response_id: str | None = None,
    ) -> AsyncIterator[Any]:
        stream = self.model_client.stream_response(
            input_items=input_items,
            level=level,
            tools=[PYTHON_TOOL],
            instructions=instructions,
            previous_response_id=previous_response_id,
        )
        iterator = stream.__aiter__()
        cancel_task: asyncio.Task[bool] | None = None
        if cancel_event is not None:
            cancel_task = asyncio.create_task(cancel_event.wait())
        try:
            while True:
                next_task = asyncio.create_task(iterator.__anext__())
                tasks: set[asyncio.Task[Any]] = {next_task}
                if cancel_task is not None:
                    tasks.add(cancel_task)
                done, pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
                if cancel_task is not None and cancel_task in done:
                    next_task.cancel()
                    await asyncio.gather(next_task, return_exceptions=True)
                    raise TurnInterrupted()
                if next_task in done:
                    if cancel_event is not None and cancel_event.is_set():
                        raise TurnInterrupted()
                    yield next_task.result()
                for task in pending:
                    if task is not cancel_task:
                        task.cancel()
        except StopAsyncIteration:
            return
        finally:
            if cancel_task is not None:
                cancel_task.cancel()
                await asyncio.gather(cancel_task, return_exceptions=True)
            aclose = getattr(iterator, "aclose", None)
            if callable(aclose):
                await aclose()

    def _register_look_at_events(
        self,
        events: list[dict[str, Any]],
        *,
        thread_id: str,
        turn_id: str,
        cwd: Path,
    ) -> list[dict[str, Any]]:
        attachments: list[dict[str, Any]] = []
        for event in events:
            if event.get("kind") != "look_at":
                continue
            path = event.get("path")
            if not isinstance(path, str) or not path:
                continue
            attachment = self.attachments.register_image(
                path,
                cwd=cwd,
                thread_id=thread_id,
                note=str(event.get("note") or ""),
            )
            payload = attachment.to_event_payload()
            self.thread_store.append(
                thread_id,
                "item.image_attachment",
                turn_id=turn_id,
                attachment=payload,
            )
            attachments.append(payload)
        return attachments

    def _process_runner_events(
        self,
        events: list[dict[str, Any]],
        *,
        thread_id: str,
        turn_id: str,
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        visible_events: list[dict[str, Any]] = []
        rules_loaded: list[dict[str, Any]] = []
        for event in events:
            if event.get("kind") == "enter_dir":
                entered = self._handle_enter_dir_event(event, thread_id=thread_id, turn_id=turn_id)
                if entered is not None:
                    visible_events.append({"kind": "cwd", "cwd": self._relative_to_project(entered)})
                    rules_loaded.extend(
                        self._load_unseen_rules_for_dir(thread_id, entered, source="tool_result")
                    )
                continue
            visible_events.append(event)
        return rules_loaded, visible_events

    def _handle_enter_dir_event(
        self,
        event: dict[str, Any],
        *,
        thread_id: str,
        turn_id: str,
    ) -> Path | None:
        raw_cwd = event.get("cwd")
        if not isinstance(raw_cwd, str) or not raw_cwd:
            return None
        try:
            cwd = Path(raw_cwd).resolve()
        except OSError:
            return None
        if not self._is_within_project(cwd):
            return None
        state = self._rule_state(thread_id)
        state.active_cwd = cwd
        self.thread_store.append(
            thread_id,
            "thread.cwd_updated",
            turn_id=turn_id,
            cwd=str(cwd),
        )
        return cwd

    def _prepare_turn_input(self, thread_id: str, *, level: str | None) -> TurnInputState:
        snapshot = self.thread_store.snapshot(thread_id)
        input_items = self._reconstruct_input(thread_id, snapshot=snapshot)
        if not self._level_uses_responses_api(level):
            return TurnInputState(input_items=input_items)

        resume = self._latest_responses_resume(thread_id, snapshot=snapshot)
        if resume is None:
            return TurnInputState(input_items=input_items)

        _, previous_response_id, pending_items = resume
        return TurnInputState(
            input_items=input_items,
            previous_response_id=previous_response_id,
            use_previous_response_id=True,
            pending_items=pending_items,
        )

    def _system_instructions_for_turn(self, thread_id: str) -> str:
        snapshot = self.thread_store.snapshot(thread_id)
        existing = self._thread_system_instructions(thread_id, snapshot=snapshot)
        if existing is not None and not self._needs_system_instruction_refresh(thread_id, snapshot=snapshot):
            return existing
        instructions = self.system_instructions()
        self.thread_store.append(
            thread_id,
            "item.system_instructions",
            text=instructions,
            fingerprint=context_fingerprint(instructions),
            after_compaction=self._has_compaction(thread_id, snapshot=snapshot),
        )
        return instructions

    def _ensure_system_instructions(self, thread_id: str) -> str:
        return self._system_instructions_for_turn(thread_id)

    def _thread_system_instructions(self, thread_id: str, *, snapshot: ThreadSnapshot | None = None) -> str | None:
        events = (snapshot or self.thread_store.snapshot(thread_id)).events_after_compaction
        for event in reversed(events):
            if event.get("type") != "item.system_instructions":
                continue
            text = event.get("text")
            if isinstance(text, str) and text:
                return text
        return None

    def _needs_system_instruction_refresh(self, thread_id: str, *, snapshot: ThreadSnapshot | None = None) -> bool:
        snap = snapshot or self.thread_store.snapshot(thread_id)
        events = snap.events_after_compaction
        compaction = snap.latest_compaction
        if compaction is None:
            return False
        return not any(event.get("type") == "item.system_instructions" for event in events)

    def _level_uses_responses_api(self, level: str | None) -> bool:
        return self._model_api_for_level(level) == "responses"

    def _model_api_for_level(self, level: str | None) -> str | None:
        try:
            return self.config.model_for_level(level).api
        except Exception:
            return None

    def _latest_responses_resume(
        self,
        thread_id: str,
        *,
        snapshot: ThreadSnapshot | None = None,
    ) -> tuple[int, str, list[dict[str, Any]]] | None:
        events = (snapshot or self.thread_store.snapshot(thread_id)).events_after_compaction
        for index in range(len(events) - 1, -1, -1):
            event = events[index]
            if event.get("type") != "item.model_response":
                continue
            if event.get("model_api") not in {"responses", None}:
                continue
            response_id = str(event.get("response_id") or "")
            if not response_id:
                continue
            if event.get("model_api") is None and not response_id.startswith("resp"):
                continue
            pending_items = self._input_items_after_event(events[index + 1 :])
            return index, response_id, pending_items
        return None

    def _input_items_after_event(self, events: list[dict[str, Any]]) -> list[dict[str, Any]]:
        input_items: list[dict[str, Any]] = []
        pending_pre_user: list[dict[str, Any]] = []
        for event in events:
            pre_user_item = self._pre_user_event_item(event)
            if pre_user_item is not None:
                pending_pre_user.append(pre_user_item)
            elif event.get("type") == "item.user":
                input_items.extend(pending_pre_user)
                pending_pre_user.clear()
                input_items.append(copy.deepcopy(event["item"]))
            elif event.get("type") == "item.tool_output":
                input_items.append(copy.deepcopy(event["item"]))
            elif event.get("type") == "item.image_attachment":
                input_items.append(image_message_item(event["attachment"]))
            elif event.get("type") == "turn.interrupted":
                interrupted = self._interrupted_turn_context(events, str(event.get("turn_id") or ""))
                if interrupted:
                    input_items.append(message_item("user", interrupted))
        return input_items

    def _reconstruct_input(
        self,
        thread_id: str,
        *,
        snapshot: ThreadSnapshot | None = None,
    ) -> list[dict[str, Any]]:
        input_items: list[dict[str, Any]] = []
        pending_pre_user: list[dict[str, Any]] = []
        snap = snapshot or self.thread_store.snapshot(thread_id)
        events = snap.events_after_compaction
        compaction = snap.latest_compaction
        if compaction is not None:
            replacement_input = compaction.get("replacement_input")
            if isinstance(replacement_input, list):
                input_items.extend(copy.deepcopy(replacement_input))
            else:
                summary = str(compaction.get("text") or "").strip()
                if summary:
                    input_items.append(
                        message_item(
                            "user",
                            "<conversation_summary>\n"
                            + summary
                            + "\n</conversation_summary>\n"
                            + COMPACTED_CONTEXT_CONTINUATION,
                        )
                    )
        for event in events:
            pre_user_item = self._pre_user_event_item(event)
            if pre_user_item is not None:
                pending_pre_user.append(pre_user_item)
            elif event.get("type") == "item.user":
                input_items.extend(pending_pre_user)
                pending_pre_user.clear()
                input_items.append(event["item"])
            elif event.get("type") == "item.model_response":
                input_items.extend(event.get("output") or [])
            elif event.get("type") == "item.tool_output":
                input_items.append(event["item"])
            elif event.get("type") == "item.image_attachment":
                input_items.append(image_message_item(event["attachment"]))
            elif event.get("type") == "turn.interrupted":
                interrupted = self._interrupted_turn_context(events, str(event.get("turn_id") or ""))
                if interrupted:
                    input_items.append(message_item("user", interrupted))
        return input_items

    def _pre_user_event_item(self, event: dict[str, Any]) -> dict[str, Any] | None:
        event_type = event.get("type")
        if event_type == "item.context_update":
            text = str(event.get("text") or "")
        elif event_type == "item.rule_index":
            text = str(event.get("text") or "")
        elif event_type == "item.rules_loaded" and event.get("source") == "pre_user":
            text = str(event.get("text") or "")
        elif event_type == "item.cwd_notice":
            text = str(event.get("text") or "")
        else:
            return None
        if not text:
            return None
        return message_item("user", text)

    def _interrupted_turn_context(self, events: list[dict[str, Any]], turn_id: str) -> str:
        turn_events = [
            event
            for event in events
            if event.get("turn_id") == turn_id
            and event.get("type") not in {"item.tool_call", "item.tool_output"}
        ]
        items = digest_items(turn_events, include_tools=False)
        if not items:
            return ""
        lines = [
            "<interrupted_turn>",
            "The previous turn was interrupted by the user. Use this as context only; do not assume unfinished tool calls completed.",
        ]
        for item in items:
            role = item.get("role")
            text = str(item.get("text") or "").strip()
            if text:
                lines.append(f"{role}: {text}")
        lines.append("</interrupted_turn>")
        return "\n".join(lines)

    def _workspace_context_items(self, thread_id: str | None = None) -> list[dict[str, Any]]:
        update = self._turn_context_update(thread_id)
        if update is None:
            return []
        if thread_id:
            self.thread_store.append(
                thread_id,
                "item.context_update",
                context_fingerprint=update["fingerprint"],
                context_state=update["state"],
                context_kind="workspace",
                removed=update["removed"],
                text=update["text"],
            )
        return [message_item("user", update["text"])]

    def _pre_user_context_items(self, thread_id: str) -> list[dict[str, Any]]:
        items: list[dict[str, Any]] = []
        for text in self._rule_context_texts(thread_id):
            items.append(message_item("user", text))
        items.extend(self._workspace_context_items(thread_id))
        return items

    def _rule_context_texts(self, thread_id: str) -> list[str]:
        state = self._rule_state(thread_id)
        texts: list[str] = []
        if not state.index_emitted:
            index_root = state.active_cwd
            index = discover_workspace_rule_index(index_root)
            rendered = index.render(label="working directory")
            if rendered:
                texts.append(rendered)
            state.index_emitted = True
            self.thread_store.append(
                thread_id,
                "item.rule_index",
                text=rendered,
                root=str(index_root.resolve()),
                max_depth=index.max_depth,
                max_entries=index.max_entries,
                truncated=index.truncated_entries or index.depth_limited,
                paths=[str(path) for path in index.paths],
            )
        cwd_notice = self._active_cwd_notice(thread_id)
        if cwd_notice:
            texts.append(cwd_notice)
        rules = self._load_unseen_rules_for_dir(thread_id, state.active_cwd, source="pre_user")
        for event in rules:
            text = str(event.get("text") or "")
            if text:
                texts.append(text)
        return texts

    def _active_cwd_notice(self, thread_id: str) -> str:
        state = self._rule_state(thread_id)
        active_cwd = state.active_cwd.resolve()
        initial_cwd = self.project_root.resolve()
        if active_cwd == initial_cwd:
            state.cwd_notice_cwd = None
            return ""
        if state.cwd_notice_cwd == active_cwd:
            return ""
        text = (
            "<active_cwd_notice>\n"
            f"The active working directory for run_python is now {xml_text(self._relative_to_project(active_cwd))}. "
            f"The thread opened at {xml_text(self._relative_to_project(initial_cwd))}. "
            "Relative paths and automatic directory rules follow the active working directory.\n"
            "</active_cwd_notice>"
        )
        state.cwd_notice_cwd = active_cwd
        self.thread_store.append(
            thread_id,
            "item.cwd_notice",
            cwd=str(active_cwd),
            initial_cwd=str(initial_cwd),
            text=text,
        )
        return text

    def _load_unseen_rules_for_dir(
        self,
        thread_id: str,
        directory: Path,
        *,
        source: str,
    ) -> list[dict[str, Any]]:
        state = self._rule_state(thread_id)
        context = load_directory_rules(directory, root=self.project_root)
        new_rules = [rule for rule in context.rules if rule.path not in state.loaded_rule_paths]
        if not new_rules:
            return []
        for rule in new_rules:
            state.loaded_rule_paths.add(rule.path)
        filtered = ProjectRuleContext(
            rules=new_rules,
            truncated=context.truncated,
            omitted_files=context.omitted_files,
        )
        text = filtered.render(root=self.project_root, heading="directory_rules_loaded")
        event = {
            "kind": "rules_loaded",
            "cwd": self._relative_to_project(directory),
            "paths": [self._relative_to_project(rule.path) for rule in new_rules],
            "text": text,
        }
        self.thread_store.append(
            thread_id,
            "item.rules_loaded",
            cwd=str(directory.resolve()),
            paths=[str(rule.path) for rule in new_rules],
            text=text,
            source=source,
        )
        return [event]

    def _rule_state(self, thread_id: str) -> RuleRuntimeState:
        state = self._rule_states.get(thread_id)
        if state is not None:
            return state
        active_cwd = self._latest_active_cwd(thread_id)
        state = RuleRuntimeState(
            active_cwd=active_cwd,
            loaded_rule_paths=self._loaded_rule_paths_in_epoch(thread_id),
            index_emitted=self._rule_index_already_emitted(thread_id, active_cwd),
            cwd_notice_cwd=self._latest_cwd_notice_in_epoch(thread_id),
        )
        self._rule_states[thread_id] = state
        return state

    def _latest_active_cwd(self, thread_id: str) -> Path:
        raw_cwd = self.thread_store.snapshot(thread_id).metadata.get("latest_cwd")
        if isinstance(raw_cwd, str) and raw_cwd:
            try:
                cwd = Path(raw_cwd).resolve()
            except OSError:
                return self.project_root.resolve()
            if self._is_within_project(cwd):
                return cwd
        return self.project_root.resolve()

    def _active_cwd(self, thread_id: str) -> Path:
        return self._rule_state(thread_id).active_cwd

    def _reset_rule_epoch(self, thread_id: str) -> None:
        state = self._rule_state(thread_id)
        state.loaded_rule_paths.clear()
        state.index_emitted = False
        state.cwd_notice_cwd = None

    def _loaded_rule_paths_in_epoch(self, thread_id: str) -> set[Path]:
        events = self.thread_store.snapshot(thread_id).events_after_compaction
        loaded: set[Path] = set()
        for event in events:
            if event.get("type") != "item.rules_loaded":
                continue
            paths = event.get("paths")
            if not isinstance(paths, list):
                continue
            for raw_path in paths:
                if not isinstance(raw_path, str) or not raw_path:
                    continue
                try:
                    loaded.add(Path(raw_path).resolve())
                except OSError:
                    continue
        return loaded

    def _rule_index_already_emitted(self, thread_id: str, active_cwd: Path) -> bool:
        del active_cwd
        events = self.thread_store.snapshot(thread_id).events_after_compaction
        for event in events:
            if event.get("type") == "item.rule_index":
                return True
        return False

    def _latest_cwd_notice_in_epoch(self, thread_id: str) -> Path | None:
        events = self.thread_store.snapshot(thread_id).events_after_compaction
        for event in reversed(events):
            if event.get("type") != "item.cwd_notice":
                continue
            raw_cwd = event.get("cwd")
            if not isinstance(raw_cwd, str) or not raw_cwd:
                continue
            try:
                cwd = Path(raw_cwd).resolve()
            except OSError:
                continue
            if self._is_within_project(cwd):
                return cwd
        return None

    def _has_compaction(self, thread_id: str, *, snapshot: ThreadSnapshot | None = None) -> bool:
        return (snapshot or self.thread_store.snapshot(thread_id)).latest_compaction is not None

    def _is_within_project(self, path: Path) -> bool:
        try:
            path.resolve().relative_to(self.project_root.resolve())
        except ValueError:
            return False
        return True

    def _relative_to_project(self, path: Path) -> str:
        resolved = path.resolve()
        try:
            relative = resolved.relative_to(self.project_root.resolve())
        except ValueError:
            return str(resolved)
        return "." if not relative.parts else relative.as_posix()

    def _turn_context_update(self, thread_id: str | None) -> dict[str, Any] | None:
        parts = self._turn_context_parts()
        rendered = "\n\n".join(parts.values())
        fingerprint = context_fingerprint(rendered)
        state = {key: context_fingerprint(value) for key, value in parts.items()}
        previous = self._latest_context_state(thread_id) if thread_id else None
        previous_fingerprint = previous.get("fingerprint") if previous else None
        if previous_fingerprint == fingerprint:
            return None
        previous_parts = previous.get("parts", {}) if previous else {}
        removed = [key for key in previous_parts if key not in state]
        changed = [key for key in state if previous_parts.get(key) != state[key]]
        if not rendered:
            if previous_fingerprint is None:
                return None
            return {
                "fingerprint": fingerprint,
                "state": {"fingerprint": fingerprint, "parts": state},
                "removed": removed or sorted(previous_parts),
                "text": (
                    "<workspace_context_update>\n"
                    "Previously available skills or MCP declarations are no longer present. "
                    "Do not rely on older appended capability context unless it appears again.\n"
                    "</workspace_context_update>"
                ),
            }
        if removed:
            removed_text = (
                "\n\n<workspace_context_removed>\n"
                f"Removed context kinds: {', '.join(removed)}. "
                "Do not rely on older appended content for these kinds unless it appears again.\n"
                "</workspace_context_removed>"
            )
        else:
            removed_text = ""
        prefix = (
            "<workspace_context_update>\n"
            "The following workspace capabilities are current. This update replaces any older appended "
            "skills or MCP declarations in this thread.\n"
            f"fingerprint: {fingerprint}\n"
            + (f"removed: {', '.join(removed)}\n" if removed else "")
            + (f"changed: {', '.join(changed)}\n" if changed else "")
            + "</workspace_context_update>"
        )
        return {
            "fingerprint": fingerprint,
            "state": {"fingerprint": fingerprint, "parts": state},
            "removed": removed,
            "text": prefix + removed_text + "\n\n" + rendered,
        }

    def _latest_context_state(self, thread_id: str | None) -> dict[str, Any] | None:
        if not thread_id:
            return None
        snap = self.thread_store.snapshot(thread_id)
        events = snap.events_after_compaction
        for event in reversed(events):
            if event.get("type") == "item.context_update":
                state = event.get("context_state")
                if isinstance(state, dict):
                    return state
                return {"fingerprint": str(event.get("context_fingerprint") or ""), "parts": {}}
        return None

    def _turn_context_text(self) -> str:
        return "\n\n".join(self._turn_context_parts().values())

    def _turn_context_parts(self) -> dict[str, str]:
        sections: dict[str, str] = {}
        skills = render_skill_summary(discover_skills(self.project_root))
        if skills != "None discovered.":
            sections["skills"] = (
                "<available_skills>\n"
                "Read the listed SKILL.md with Python only when relevant.\n"
                f"{skills}\n"
                "</available_skills>"
            )

        mcp_servers = render_mcp_summary(discover_mcp_servers(self.project_root))
        if mcp_servers != "None declared.":
            sections["mcp"] = (
                "<available_mcp_servers>\n"
                "Use uv_agent_runtime MCP helpers from Python to inspect or call these servers.\n"
                f"{mcp_servers}\n"
                "</available_mcp_servers>"
            )
        return sections

    def project_rule_context(self) -> ProjectRuleContext:
        """Load AGENTS.md context for status/debug display."""
        return load_project_rules(self.project_root)

    def context_percent(self, thread_id: str | None, level: str | None = None) -> int:
        """Return a context-window usage percentage for a thread."""
        return self.context_stats(thread_id, level).percent

    def context_stats(self, thread_id: str | None, level: str | None = None) -> ContextStats:
        """Return detailed context-window statistics for a thread."""
        model = self.config.model_for_level(level)
        trigger_tokens = int(
            model.context_window_tokens * self.config.runtime.compression.trigger_ratio
        )
        if not thread_id:
            return ContextStats(
                used_tokens=0,
                context_window_tokens=model.context_window_tokens,
                percent=0,
                threshold_tokens=trigger_tokens,
                headroom_tokens=model.context_window_tokens,
                source="empty",
            )
        try:
            snapshot = self.thread_store.snapshot(thread_id)
        except FileNotFoundError:
            return ContextStats(
                used_tokens=0,
                context_window_tokens=model.context_window_tokens,
                percent=0,
                threshold_tokens=trigger_tokens,
                headroom_tokens=model.context_window_tokens,
                source="empty",
            )
        used = self._latest_usage_tokens(thread_id, snapshot=snapshot)
        source = "provider"
        if used is None:
            update = self._turn_context_update(thread_id)
            context_items = [message_item("user", update["text"])] if update else []
            used = estimate_tokens(self._reconstruct_input(thread_id, snapshot=snapshot) + context_items)
            source = "estimate"
        percent = min(100, max(0, round(used * 100 / model.context_window_tokens)))
        return ContextStats(
            used_tokens=used,
            context_window_tokens=model.context_window_tokens,
            percent=percent,
            threshold_tokens=trigger_tokens,
            headroom_tokens=max(0, model.context_window_tokens - used),
            source=source,
        )

    def _latest_usage_tokens(self, thread_id: str, *, snapshot: ThreadSnapshot | None = None) -> int | None:
        """Return the latest provider-reported token usage when available."""
        snap = snapshot or self.thread_store.snapshot(thread_id)
        metadata_usage = snap.metadata.get("latest_usage_tokens")
        if isinstance(metadata_usage, int):
            return metadata_usage
        events = snap.events_after_compaction
        compaction = snap.latest_compaction
        for event in reversed(events):
            if event.get("type") != "item.model_response":
                continue
            used = usage_token_count(event.get("usage") or {})
            if used is not None:
                return used
        if compaction is not None:
            used = usage_token_count(compaction.get("usage") or {})
            if used is not None:
                return used
        return None

    def system_instructions(self) -> str:
        """Build concise environment-aware system instructions."""
        return SYSTEM_INSTRUCTIONS_TEMPLATE.format(
            workspace=xml_text(self.project_root),
            user_state=xml_text(uv_agent_home()),
            project_state=xml_text(project_state_dir(self.project_root)),
            host_environment=xml_text(host_environment_line(self._host_environment)),
            user_language=xml_text(detect_user_language(self.config.ui.language).name),
            model_levels=self._model_levels_context(),
        )

    def _model_levels_context(self) -> str:
        lines = [
            "<model_levels>",
            f"<default>{xml_text(self.config.runtime.default_level)}</default>",
            "<available>",
        ]
        for name in self.config.levels:
            lines.append(f"<level>{xml_text(name)}</level>")
        lines.extend(
            [
                "</available>",
                "<rule>level and model_level values are configuration-defined; use only an available name, or omit them to use the default.</rule>",
                "</model_levels>",
            ]
        )
        return "\n".join(lines)

def message_item(role: str, text: str) -> dict[str, Any]:
    return {
        "type": "message",
        "role": role,
        "content": [{"type": "input_text", "text": text}],
    }


def message_item_text(item: dict[str, Any]) -> str:
    parts: list[str] = []
    for content in item.get("content") or []:
        if content.get("type") in {"input_text", "output_text", "text"}:
            parts.append(str(content.get("text") or ""))
    return "\n".join(parts)


def truncate_text_to_estimated_tokens(text: str, max_tokens: int) -> str:
    if max_tokens <= 0:
        return ""
    max_chars = max_tokens * 4
    if len(text) <= max_chars:
        return text
    suffix = "\n[truncated during context compaction]"
    keep = max(0, max_chars - len(suffix))
    return text[:keep].rstrip() + suffix


def assistant_output_item(text: str) -> dict[str, Any]:
    """Return a Responses-style assistant message item."""
    return {
        "type": "message",
        "role": "assistant",
        "content": [{"type": "output_text", "text": text}],
    }


def is_default_thread_title(title: str) -> bool:
    return title.strip() in DEFAULT_THREAD_TITLES


def clean_thread_title(text: str) -> str | None:
    title = text.strip().splitlines()[0].strip()
    title = title.strip(" \t\r\n\"'`“”‘’")
    title = re.sub(r"^[#*\-\d\.\)\s]+", "", title).strip()
    title = re.sub(r"\s+", " ", title)
    if not title:
        return None
    if len(title) > 80:
        title = title[:77].rstrip() + "..."
    return title


def function_output(call: dict[str, Any], output: dict[str, Any]) -> dict[str, Any]:
    return {
        "type": "function_call_output",
        "call_id": call.get("call_id"),
        "output": json.dumps(output, ensure_ascii=False),
    }


def model_tool_payload(payload: dict[str, Any]) -> dict[str, Any]:
    """Return the run payload that is safe and useful to feed back to the model."""
    visible_events = model_visible_events(payload.get("events"))
    visible = {
        "script_id": payload.get("script_id"),
        "run_id": payload.get("run_id"),
        "returncode": payload.get("returncode"),
        "timed_out": payload.get("timed_out"),
        "interrupted": payload.get("interrupted"),
        "truncated": payload.get("truncated"),
        "stdout": strip_structured_event_lines(str(payload.get("stdout") or "")),
        "stderr": payload.get("stderr") or "",
    }
    if visible_events:
        visible["events"] = visible_events
    if payload.get("rules_loaded"):
        visible["rules_loaded"] = payload["rules_loaded"]
    if payload.get("attachments"):
        visible["attachments"] = payload["attachments"]
    return visible


def model_visible_events(value: object) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    visible: list[dict[str, Any]] = []
    for event in value:
        if not isinstance(event, dict):
            continue
        kind = str(event.get("kind") or "")
        if kind in {"progress", "cwd"}:
            continue
        if kind == "result":
            visible.append(copy.deepcopy(event))
        elif kind == "look_at":
            visible.append({"kind": "look_at", "path": event.get("path"), "note": event.get("note")})
        elif kind == "subagent.completed":
            visible.append(
                {
                    "kind": "subagent.completed",
                    "thread_id": event.get("thread_id"),
                    "summary": event.get("summary"),
                }
            )
        elif kind.startswith("subagent."):
            continue
        else:
            visible.append({"kind": kind})
    return visible


def strip_structured_event_lines(text: str) -> str:
    lines: list[str] = []
    for line in text.splitlines(keepends=True):
        if _is_structured_event_line(line):
            continue
        lines.append(line)
    return "".join(lines)


def _is_structured_event_line(line: str) -> bool:
    stripped = line.strip()
    if not stripped.startswith("{"):
        return False
    try:
        value = json.loads(stripped)
    except json.JSONDecodeError:
        return False
    return isinstance(value, dict) and "kind" in value


def context_fingerprint(text: str) -> str:
    """Stable fingerprint for dynamic per-turn context."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


def xml_text(value: object) -> str:
    return xml_escape(str(value), quote=False)
