"""Issue-backed state tracker for orchestrator persistence."""

from __future__ import annotations

import contextlib
import logging
from typing import TYPE_CHECKING

from caretaker.causal import make_causal_marker
from caretaker.github_client.api import RateLimitError
from caretaker.graph.models import NodeType, RelType
from caretaker.graph.writer import get_writer
from caretaker.tools.github import GitHubIssueTools

from .models import OrchestratorState, RunSummary

if TYPE_CHECKING:
    from caretaker.evolution.reflection import ReflectionResult
    from caretaker.github_client.api import GitHubClient

logger = logging.getLogger(__name__)

TRACKING_ISSUE_TITLE = "[Maintainer] Orchestrator State"
TRACKING_LABEL = "maintainer:internal"
STATE_MARKER_OPEN = "<!-- maintainer-state:"
STATE_MARKER_CLOSE = ":maintainer-state -->"

# Per-comment marker used by upsert_issue_comment so that the orchestrator
# state and the rolling run-history comments are edited in place instead of
# accumulating one new comment per run. portfolio#121 reached 110 bot
# comments before this was added.
STATE_COMMENT_MARKER = "<!-- caretaker:orchestrator-state -->"
RUN_HISTORY_COMMENT_MARKER = "<!-- caretaker:run-history -->"

# How many recent runs to keep visible in the rolling history comment.
_RUN_HISTORY_KEEP = 10

# Fragment that GitHub includes in the 403 response body when an issue has
# accumulated more than 2500 comments and commenting is disabled.
_COMMENT_LIMIT_FRAGMENT = "2500 comments"


def _is_comment_limit_error(exc: Exception) -> bool:
    """Return True when *exc* is the GitHub 403 'too many comments' error."""
    from caretaker.github_client.api import GitHubAPIError

    return (
        isinstance(exc, GitHubAPIError)
        and exc.status_code == 403
        and _COMMENT_LIMIT_FRAGMENT in exc.message
    )


class StateTracker:
    """Persists orchestrator state as a hidden JSON block in a tracking issue."""

    def __init__(self, github: GitHubClient, owner: str, repo: str) -> None:
        self._github = github
        self._owner = owner
        self._repo = repo
        self._issues = GitHubIssueTools(github, owner, repo)
        self._tracking_issue_number: int | None = None
        self._state: OrchestratorState = OrchestratorState()

    @property
    def state(self) -> OrchestratorState:
        return self._state

    async def load(self) -> OrchestratorState:
        """Load state from the tracking issue."""
        issue_number = await self._find_tracking_issue()
        if issue_number is None:
            logger.info("No tracking issue found — starting fresh")
            self._state = OrchestratorState()
            return self._state

        self._tracking_issue_number = issue_number
        comments = await self._github.get_pr_comments(self._owner, self._repo, issue_number)

        # Find the latest state comment (search from newest)
        for comment in reversed(comments):
            state_json = self._extract_state(comment.body)
            if state_json is not None:
                try:
                    self._state = OrchestratorState.model_validate_json(state_json)
                    logger.info("Loaded state from comment %d", comment.id)
                    return self._state
                except Exception:
                    logger.warning("Failed to parse state from comment %d", comment.id)

        logger.info("No valid state found in tracking issue — starting fresh")
        self._state = OrchestratorState()
        return self._state

    async def save(self, summary: RunSummary | None = None) -> None:
        """Save current state to the tracking issue.

        State is persisted as a single comment carrying ``STATE_COMMENT_MARKER``
        — the comment is edited in place on every save, not appended. Earlier
        versions appended a new comment per run, which produced unbounded
        comment growth on the tracking issue (portfolio#121 reached 110 bot
        comments).
        """
        if summary:
            self._state.last_run = summary
            self._state.run_history.append(summary)
            # Keep last 20 runs
            if len(self._state.run_history) > 20:
                self._state.run_history = self._state.run_history[-20:]

        try:
            if self._tracking_issue_number is None:
                await self._create_tracking_issue()
        except RateLimitError as exc:
            logger.warning(
                "State save skipped: GitHub rate-limit while creating tracking issue (%s). "
                "In-memory state is intact; next successful run will persist.",
                exc,
            )
            return

        assert self._tracking_issue_number is not None

        state_json = self._state.model_dump_json(indent=2)
        body = self._build_state_comment(state_json, summary)
        try:
            await self._github.upsert_issue_comment(
                self._owner,
                self._repo,
                self._tracking_issue_number,
                STATE_COMMENT_MARKER,
                body,
            )
        except RateLimitError as exc:
            logger.warning(
                "State save skipped: GitHub rate-limit while upserting state comment (%s). "
                "In-memory state is intact; next successful run will persist.",
                exc,
            )
            return
        except Exception as exc:
            if _is_comment_limit_error(exc):
                await self._rotate_tracking_issue()
                await self._github.upsert_issue_comment(
                    self._owner,
                    self._repo,
                    self._tracking_issue_number,
                    STATE_COMMENT_MARKER,
                    body,
                )
            else:
                raise
        logger.info("State saved to tracking issue #%d", self._tracking_issue_number)
        if summary is not None:
            self._emit_run_graph(summary)

    def _emit_run_graph(self, summary: RunSummary) -> None:
        """Publish the just-saved run to the event-driven graph writer.

        Called at the end of :meth:`save` so a dropped graph write cannot
        prevent state from being persisted to the tracking issue — GitHub
        is the source of truth, Neo4j is a projection.
        """
        run_id = f"run:{summary.run_at.isoformat()}"
        writer = get_writer()
        writer.record_node(
            NodeType.RUN,
            run_id,
            {
                "name": f"run-{summary.run_at.strftime('%Y%m%dT%H%M%S')}",
                "run_at": summary.run_at.isoformat(),
                "mode": summary.mode,
                "prs_monitored": summary.prs_monitored,
                "prs_merged": summary.prs_merged,
                "issues_triaged": summary.issues_triaged,
                "goal_health": summary.goal_health if summary.goal_health is not None else 0.0,
                "escalation_rate": summary.escalation_rate,
                "repo": f"{self._owner}/{self._repo}",
                "valid_from": summary.run_at.isoformat(),
            },
        )
        if summary.goal_health is not None:
            # Ensure the synthetic aggregate goal node exists before
            # the edge merge — the GraphBuilder full-sync also merges
            # it but live writes can land before the first sync.
            writer.record_node(
                NodeType.GOAL,
                "goal:overall",
                {"name": "overall", "aggregate": True},
            )
            # AFFECTED is the M2 edge — semantically "this run moved the
            # goal score by this much." `valid_from` is the run's wall
            # clock; `valid_to` stays unset because the score only
            # ceases to reflect a given run's contribution when a newer
            # run supersedes it, and that's an analysis-layer concern.
            writer.record_edge(
                NodeType.RUN,
                run_id,
                NodeType.GOAL,
                "goal:overall",
                RelType.AFFECTED,
                {
                    "score": summary.goal_health,
                    "escalation_rate": summary.escalation_rate,
                    "valid_from": summary.run_at.isoformat(),
                },
            )

    async def post_run_summary(self, summary: RunSummary) -> None:
        """Post a human-readable run summary to the tracking issue.

        Maintains a single rolling "Maintainer Run History" comment with the
        last :data:`_RUN_HISTORY_KEEP` runs rendered, edited in place. This
        replaces the previous append-per-run pattern that drove unbounded
        comment growth.
        """
        try:
            if self._tracking_issue_number is None:
                await self._create_tracking_issue()
        except RateLimitError as exc:
            logger.warning(
                "Run summary post skipped: GitHub rate-limit while creating tracking issue (%s)",
                exc,
            )
            return
        assert self._tracking_issue_number is not None

        recent = list(self._state.run_history[-_RUN_HISTORY_KEEP:])
        # Make sure the latest run is represented even if save() didn't run
        # for some reason (defensive — save() should always be called first).
        if not recent or recent[-1] is not summary:
            recent.append(summary)
            recent = recent[-_RUN_HISTORY_KEEP:]

        body = self._build_history_comment(recent)
        try:
            await self._github.upsert_issue_comment(
                self._owner,
                self._repo,
                self._tracking_issue_number,
                RUN_HISTORY_COMMENT_MARKER,
                body,
            )
        except RateLimitError as exc:
            logger.warning(
                "Run summary post skipped: GitHub rate-limit while upserting history comment (%s)",
                exc,
            )
            return
        except Exception as exc:
            if _is_comment_limit_error(exc):
                await self._rotate_tracking_issue()
                await self._github.upsert_issue_comment(
                    self._owner,
                    self._repo,
                    self._tracking_issue_number,
                    RUN_HISTORY_COMMENT_MARKER,
                    body,
                )
            else:
                raise

    async def post_reflection(self, result: ReflectionResult) -> None:
        """Post a reflection analysis comment to the tracking issue."""
        from caretaker.evolution.reflection import format_reflection_comment

        if self._tracking_issue_number is None:
            await self._create_tracking_issue()
        assert self._tracking_issue_number is not None

        body = format_reflection_comment(result)
        try:
            await self._issues.comment(self._tracking_issue_number, body)
        except Exception as exc:
            if _is_comment_limit_error(exc):
                await self._rotate_tracking_issue()
                await self._issues.comment(self._tracking_issue_number, body)
            else:
                raise
        logger.info(
            "Reflection posted to tracking issue #%d (triggered_by=%s)",
            self._tracking_issue_number,
            result.triggered_by,
        )

    async def _find_tracking_issue(self) -> int | None:
        issues = await self._issues.list(labels=TRACKING_LABEL)
        for issue in issues:
            if issue.title == TRACKING_ISSUE_TITLE:
                return issue.number
        return None

    async def _create_tracking_issue(self) -> None:
        issue = await self._issues.create(
            title=TRACKING_ISSUE_TITLE,
            body=(
                "This issue is used by the caretaker orchestrator "
                "to track state and post run summaries.\n\n"
                "**Do not close or modify this issue.**\n\n"
                "Label: `maintainer:internal`"
            ),
            labels=[TRACKING_LABEL],
        )
        self._tracking_issue_number = issue.number
        logger.info("Created tracking issue #%d", issue.number)

    async def _rotate_tracking_issue(self) -> None:
        """Close the full tracking issue and create a fresh replacement.

        Called automatically when GitHub returns a 403 because the current
        tracking issue has accumulated more than 2500 comments.  The old
        issue is closed with an explanatory note; a new one is opened and
        :attr:`_tracking_issue_number` is updated so the next save lands on
        the new issue.
        """
        old_number = self._tracking_issue_number
        if old_number is not None:
            with contextlib.suppress(Exception):
                await self._github.update_issue(
                    self._owner,
                    self._repo,
                    old_number,
                    state="closed",
                    body=(
                        "This tracking issue has reached GitHub's 2500-comment "
                        "limit.  A replacement tracking issue has been created "
                        "automatically — please use that one going forward."
                    ),
                )
            logger.warning(
                "Tracking issue #%d is full (≥2500 comments) — "
                "closed and creating a new tracking issue",
                old_number,
            )
        self._tracking_issue_number = None
        await self._create_tracking_issue()

    @staticmethod
    def _extract_state(body: str) -> str | None:
        start = body.find(STATE_MARKER_OPEN)
        if start == -1:
            return None
        start += len(STATE_MARKER_OPEN)
        end = body.find(STATE_MARKER_CLOSE, start)
        if end == -1:
            return None
        return body[start:end].strip()

    @staticmethod
    def _build_state_comment(state_json: str, summary: RunSummary | None = None) -> str:
        lines = [
            STATE_COMMENT_MARKER,
            make_causal_marker("state-tracker:orchestrator-state"),
            "",
            "## Orchestrator State Update\n",
        ]
        if summary:
            lines.append(f"Run completed at {summary.run_at.isoformat()} (mode: {summary.mode})")
            lines.append(f"- PRs monitored: {summary.prs_monitored}")
            lines.append(f"- PRs merged: {summary.prs_merged}")
            lines.append(f"- Issues triaged: {summary.issues_triaged}")
            if summary.errors:
                lines.append(f"- Errors: {len(summary.errors)}")
            if summary.goal_health is not None:
                lines.append(f"- Goal health: {summary.goal_health:.2%}")
                if summary.goal_escalation_count:
                    lines.append(f"- Goal escalations: {summary.goal_escalation_count}")
            lines.append("")
        lines.append(f"{STATE_MARKER_OPEN}\n{state_json}\n{STATE_MARKER_CLOSE}")
        return "\n".join(lines)

    @classmethod
    def _build_history_comment(cls, runs: list[RunSummary]) -> str:
        """Render a rolling history of recent runs as one upsertable body."""
        lines = [
            RUN_HISTORY_COMMENT_MARKER,
            make_causal_marker("state-tracker:run-history"),
            "",
            f"## Maintainer Run History (last {len(runs)} runs)",
            "",
            "_This comment is edited in place on every run — it does not grow._",
            "",
        ]
        for run in reversed(runs):  # newest first
            lines.append(cls._format_summary(run))
            lines.append("---")
            lines.append("")
        return "\n".join(lines).rstrip() + "\n"

    @staticmethod
    def _format_summary(summary: RunSummary) -> str:
        lines = [
            f"## Maintainer Run — {summary.run_at.strftime('%B %d, %Y')}",
            "",
            "### PR Agent",
            f"- {summary.prs_monitored} PRs monitored",
            f"- {summary.prs_merged} merged",
            f"- {summary.prs_escalated} escalated",
            f"- {summary.prs_fix_requested} fix requests posted",
            "",
            "### Issue Agent",
            f"- {summary.issues_triaged} issues triaged",
            f"- {summary.issues_assigned} assigned to Copilot",
            f"- {summary.issues_closed} closed",
            f"- {summary.issues_escalated} escalated",
            "",
            "### Reconciliation",
            f"- {summary.orphaned_prs} orphaned PRs detected",
            f"- {summary.stale_assignments_escalated} stale assignments escalated",
            f"- Escalation rate: {summary.escalation_rate:.2%}",
            f"- Copilot success rate: {summary.copilot_success_rate:.2%}",
            f"- Avg time-to-merge: {summary.avg_time_to_merge_hours:.2f}h",
            "",
        ]
        if summary.upgrade_available:
            lines.extend(
                [
                    "### Upgrade Agent",
                    f"- Upgrade available: {summary.upgrade_version}",
                    "",
                ]
            )
        if any(
            (
                summary.charlie_managed_issues,
                summary.charlie_managed_prs,
                summary.charlie_issues_closed,
                summary.charlie_prs_closed,
            )
        ):
            lines.extend(
                [
                    "### Charlie Agent",
                    f"- {summary.charlie_managed_issues} managed issues reviewed",
                    f"- {summary.charlie_managed_prs} managed PRs reviewed",
                    f"- {summary.charlie_issues_closed} issues closed",
                    f"- {summary.charlie_prs_closed} PRs closed",
                    f"- {summary.charlie_duplicates_closed} duplicate items cleaned up",
                    "",
                ]
            )
        if summary.errors:
            lines.extend(
                [
                    "### Errors",
                    *[f"- {e}" for e in summary.errors],
                    "",
                ]
            )
        if summary.goal_health is not None:
            lines.extend(
                [
                    "### Goal Health",
                    f"- Overall health: {summary.goal_health:.2%}",
                    f"- Goal escalations: {summary.goal_escalation_count}",
                    "",
                ]
            )
        return "\n".join(lines)
