"""Opt-in fleet-registry heartbeat emitter, store, and HTTP surface."""

from caretaker.fleet.abstraction import abstract_sop
from caretaker.fleet.api import admin_router, public_router
from caretaker.fleet.emitter import (
    FleetHeartbeat,
    build_heartbeat,
    emit_heartbeat,
    sign_payload,
)
from caretaker.fleet.graph import promote_global_skills, sync_repos_to_graph
from caretaker.fleet.store import (
    FleetClient,
    FleetRegistryStore,
    get_store,
    reset_store_for_tests,
)

__all__ = [
    "FleetClient",
    "FleetHeartbeat",
    "FleetRegistryStore",
    "abstract_sop",
    "admin_router",
    "build_heartbeat",
    "emit_heartbeat",
    "get_store",
    "promote_global_skills",
    "public_router",
    "reset_store_for_tests",
    "sign_payload",
    "sync_repos_to_graph",
]
