"""Tests for the policy engine."""

from gate_policy.models import Condition, Effect, Policy, Rule
from gate_policy.engine import PolicyEngine


def _make_policy() -> Policy:
    return Policy(
        name="test-policy",
        rules=(
            Rule(
                name="deny-high-impact-without-approval",
                effect=Effect.DENY,
                execution_classes=frozenset({"high_impact"}),
                conditions=(
                    Condition(field="human_approved", operator="neq", value=True),
                ),
                priority=10,
            ),
            Rule(
                name="allow-read-only",
                effect=Effect.ALLOW,
                execution_classes=frozenset({"read_only"}),
                conditions=(),
                priority=5,
            ),
        ),
        default_effect=Effect.ALLOW,
    )


def test_deny_high_impact_without_approval():
    engine = PolicyEngine(_make_policy())
    context = {"human_approved": False, "mode": 0.2}
    result = engine.evaluate("deploy", "high_impact", context)
    assert result == Effect.DENY


def test_allow_high_impact_with_approval():
    engine = PolicyEngine(_make_policy())
    context = {"human_approved": True, "mode": 0.2}
    result = engine.evaluate("deploy", "high_impact", context)
    assert result == Effect.ALLOW


def test_allow_read_only():
    engine = PolicyEngine(_make_policy())
    context = {"human_approved": False, "mode": 0.8}
    result = engine.evaluate("read_file", "read_only", context)
    assert result == Effect.ALLOW


def test_default_effect_when_no_match():
    engine = PolicyEngine(_make_policy())
    context = {"human_approved": False}
    result = engine.evaluate("some_tool", "advisory", context)
    assert result == Effect.ALLOW


def test_filter_tools():
    engine = PolicyEngine(_make_policy())
    tools = [
        {"name": "read_file", "execution_class": "read_only"},
        {"name": "deploy", "execution_class": "high_impact"},
        {"name": "analyze", "execution_class": "advisory"},
    ]
    context = {"human_approved": False}
    result = engine.filter_tools(tools, context)
    assert len(result["allowed"]) == 2
    assert len(result["denied"]) == 1
    assert result["denied"][0]["name"] == "deploy"
