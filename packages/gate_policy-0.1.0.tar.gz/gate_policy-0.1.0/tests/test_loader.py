"""Tests for policy loading from YAML files."""

from pathlib import Path

from gate_policy.loader import load_policy_file
from gate_policy.engine import PolicyEngine
from gate_policy.models import Effect

EXAMPLES = Path(__file__).parent.parent / "examples"


def test_load_enterprise_standard():
    policy = load_policy_file(EXAMPLES / "enterprise_standard.yaml")
    assert policy.name == "enterprise-standard"
    assert len(policy.rules) == 4
    assert policy.default_effect == Effect.ALLOW


def test_load_startup_permissive():
    policy = load_policy_file(EXAMPLES / "startup_permissive.yaml")
    assert policy.name == "startup-permissive"
    assert len(policy.rules) == 4
    assert policy.default_effect == Effect.ALLOW


def test_enterprise_denies_unapproved_high_impact():
    policy = load_policy_file(EXAMPLES / "enterprise_standard.yaml")
    engine = PolicyEngine(policy)
    result = engine.evaluate("deploy", "high_impact", {"human_approved": False, "mode_zone": "normal"})
    assert result == Effect.DENY


def test_enterprise_allows_approved_high_impact():
    policy = load_policy_file(EXAMPLES / "enterprise_standard.yaml")
    engine = PolicyEngine(policy)
    result = engine.evaluate("deploy", "high_impact", {"human_approved": True, "mode_zone": "normal"})
    assert result == Effect.ALLOW


def test_startup_blocks_friday_deploy():
    policy = load_policy_file(EXAMPLES / "startup_permissive.yaml")
    engine = PolicyEngine(policy)
    result = engine.evaluate("deploy_production", "high_impact", {
        "weekday_name": "friday",
        "hour": 17,
        "human_approved": True,
        "mode_zone": "normal",
        "is_weekend": False,
    })
    assert result == Effect.DENY


def test_startup_allows_monday_deploy():
    policy = load_policy_file(EXAMPLES / "startup_permissive.yaml")
    engine = PolicyEngine(policy)
    result = engine.evaluate("deploy_production", "high_impact", {
        "weekday_name": "monday",
        "hour": 10,
        "human_approved": True,
        "mode_zone": "normal",
        "is_weekend": False,
    })
    assert result == Effect.ALLOW
