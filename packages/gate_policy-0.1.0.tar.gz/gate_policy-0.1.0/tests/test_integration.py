"""Tests for gate-core integration via PolicyGate."""

from datetime import datetime

from gatekeeper.core import Gate, Tool

from gate_policy.integration import PolicyGate, _inject_time_context
from gate_policy.models import Condition, Effect, Policy, Rule


def _sample_tools() -> list[Tool]:
    return [
        Tool(name="read_file", execution_class="read_only"),
        Tool(name="write_file", execution_class="state_mutation"),
        Tool(name="deploy", execution_class="high_impact"),
        Tool(name="send_email", execution_class="external_action"),
        Tool(name="analyze", execution_class="advisory"),
    ]


def _approval_policy() -> Policy:
    return Policy(
        name="require-approval",
        rules=(
            Rule(
                name="deny-high-impact-unapproved",
                effect=Effect.DENY,
                execution_classes=frozenset({"high_impact"}),
                conditions=(Condition(field="human_approved", operator="neq", value=True),),
                priority=10,
            ),
        ),
        default_effect=Effect.ALLOW,
    )


def test_policy_gate_normal_mode_with_approval():
    gate = Gate()
    gate.add_tools(_sample_tools())
    pg = PolicyGate(gate, _approval_policy())
    result = pg.filter(0.1, {"human_approved": True})
    assert "deploy" in result.visible_names
    assert len(result.suppressed) == 0
    assert len(result.policy_denied) == 0


def test_policy_gate_normal_mode_without_approval():
    gate = Gate()
    gate.add_tools(_sample_tools())
    pg = PolicyGate(gate, _approval_policy())
    result = pg.filter(0.1, {"human_approved": False})
    assert "deploy" not in result.visible_names
    assert "deploy" in result.policy_denied_names
    assert "read_file" in result.visible_names


def test_policy_gate_crisis_mode():
    """In crisis mode, gate-core suppresses most tools. Policy shouldn't re-add them."""
    gate = Gate()
    gate.add_tools(_sample_tools())
    pg = PolicyGate(gate, _approval_policy())
    result = pg.filter(0.9, {"human_approved": True})
    # gate-core suppresses external_action, state_mutation, high_impact at crisis
    assert "deploy" in result.suppressed_names
    assert "write_file" in result.suppressed_names
    assert "send_email" in result.suppressed_names
    # read_only and advisory pass both layers
    assert "read_file" in result.visible_names
    assert "analyze" in result.visible_names


def test_policy_gate_both_layers_block():
    """A tool suppressed by mode AND denied by policy appears in suppressed (mode wins first)."""
    gate = Gate()
    gate.add_tools(_sample_tools())
    pg = PolicyGate(gate, _approval_policy())
    result = pg.filter(0.9, {"human_approved": False})
    # deploy is suppressed by mode before policy even sees it
    assert "deploy" in result.suppressed_names
    assert "deploy" not in result.policy_denied_names


def test_time_context_injection():
    ctx = {"_now": datetime(2026, 4, 10, 14, 30)}  # Friday 2:30pm
    _inject_time_context(ctx)
    assert ctx["hour"] == 14
    assert ctx["minute"] == 30
    assert ctx["weekday"] == 4  # Friday
    assert ctx["is_weekend"] is False
    assert ctx["is_business_hours"] is True


def test_time_context_weekend():
    ctx = {"_now": datetime(2026, 4, 12, 10, 0)}  # Saturday
    _inject_time_context(ctx)
    assert ctx["is_weekend"] is True
    assert ctx["is_business_hours"] is False


def test_time_based_policy():
    """Policy that denies state_mutation outside business hours."""
    policy = Policy(
        name="business-hours-only",
        rules=(
            Rule(
                name="no-mutations-after-hours",
                effect=Effect.DENY,
                execution_classes=frozenset({"state_mutation"}),
                conditions=(Condition(field="is_business_hours", operator="eq", value=False),),
                priority=10,
            ),
        ),
        default_effect=Effect.ALLOW,
    )
    gate = Gate()
    gate.add_tools(_sample_tools())
    pg = PolicyGate(gate, policy)

    # During business hours (Friday) — write_file allowed
    result = pg.filter(0.1, {"_now": datetime(2026, 4, 10, 14, 0)})
    assert "write_file" in result.visible_names

    # After hours (Friday night) — write_file denied by policy
    result = pg.filter(0.1, {"_now": datetime(2026, 4, 10, 22, 0)})
    assert "write_file" in result.policy_denied_names


def test_role_based_policy():
    """Policy with role-based conditions."""
    policy = Policy(
        name="role-based",
        rules=(
            Rule(
                name="admin-only-deploy",
                effect=Effect.DENY,
                tool_names=frozenset({"deploy"}),
                conditions=(Condition(field="role", operator="not_in", value=["admin", "sre"]),),
                priority=10,
            ),
        ),
        default_effect=Effect.ALLOW,
    )
    gate = Gate()
    gate.add_tools(_sample_tools())
    pg = PolicyGate(gate, policy)

    result = pg.filter(0.1, {"role": "developer"})
    assert "deploy" in result.policy_denied_names

    result = pg.filter(0.1, {"role": "admin"})
    assert "deploy" in result.visible_names
