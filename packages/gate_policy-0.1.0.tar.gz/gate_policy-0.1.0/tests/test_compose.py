"""Tests for policy composition."""

import pytest

from gate_policy.compose import merge_policies
from gate_policy.engine import PolicyEngine
from gate_policy.models import Condition, Effect, Policy, Rule


def _policy_a() -> Policy:
    return Policy(
        name="policy-a",
        description="Denies high_impact without approval",
        rules=(
            Rule(
                name="a-deny-high-impact",
                effect=Effect.DENY,
                execution_classes=frozenset({"high_impact"}),
                conditions=(Condition(field="human_approved", operator="neq", value=True),),
                priority=10,
            ),
        ),
        default_effect=Effect.ALLOW,
    )


def _policy_b() -> Policy:
    return Policy(
        name="policy-b",
        description="Denies external_action at night",
        rules=(
            Rule(
                name="b-deny-external-night",
                effect=Effect.DENY,
                execution_classes=frozenset({"external_action"}),
                conditions=(Condition(field="hour", operator="gte", value=22),),
                priority=5,
            ),
        ),
        default_effect=Effect.ALLOW,
    )


def test_merge_combines_rules():
    merged = merge_policies([_policy_a(), _policy_b()])
    assert len(merged.rules) == 2
    assert "policy-a" in merged.name
    assert "policy-b" in merged.name


def test_merge_strict_default_deny():
    deny_policy = Policy(name="deny-all", rules=(), default_effect=Effect.DENY)
    merged = merge_policies([_policy_a(), deny_policy], strategy="strict")
    assert merged.default_effect == Effect.DENY


def test_merge_permissive_default_allow():
    deny_policy = Policy(name="deny-all", rules=(), default_effect=Effect.DENY)
    merged = merge_policies([_policy_a(), deny_policy], strategy="permissive")
    assert merged.default_effect == Effect.ALLOW


def test_merge_permissive_all_deny():
    d1 = Policy(name="d1", rules=(), default_effect=Effect.DENY)
    d2 = Policy(name="d2", rules=(), default_effect=Effect.DENY)
    merged = merge_policies([d1, d2], strategy="permissive")
    assert merged.default_effect == Effect.DENY


def test_merged_policy_evaluates_correctly():
    merged = merge_policies([_policy_a(), _policy_b()])
    engine = PolicyEngine(merged)

    # high_impact denied without approval
    assert engine.evaluate("deploy", "high_impact", {"human_approved": False, "hour": 10}) == Effect.DENY
    # high_impact allowed with approval
    assert engine.evaluate("deploy", "high_impact", {"human_approved": True, "hour": 10}) == Effect.ALLOW
    # external_action denied at night
    assert engine.evaluate("send_email", "external_action", {"human_approved": True, "hour": 23}) == Effect.DENY
    # external_action allowed during day
    assert engine.evaluate("send_email", "external_action", {"human_approved": True, "hour": 10}) == Effect.ALLOW


def test_merge_empty_list_raises():
    with pytest.raises(ValueError):
        merge_policies([])


def test_merge_single_policy():
    p = _policy_a()
    merged = merge_policies([p])
    assert merged is p


def test_merge_bad_strategy_raises():
    with pytest.raises(ValueError):
        merge_policies([_policy_a()], strategy="invalid")
