"""Tests for the policy audit trail."""
from datetime import datetime, timedelta, timezone

import pytest

from gate_policy.audit import AuditEntry, AuditLog


def _entry(
    tool="deploy", cls="high_impact", effect="deny", rule="test-rule",
    policy="test-policy", mode=0.5, zone="elevated",
    ts=None, context=None,
):
    return AuditEntry(
        timestamp=ts or datetime.now(timezone.utc),
        tool_name=tool, execution_class=cls,
        effect=effect, matched_rule=rule,
        policy_name=policy, mode=mode, mode_zone=zone,
        context=context or {},
    )


def test_record_and_len():
    log = AuditLog()
    assert len(log) == 0
    log.record(_entry())
    assert len(log) == 1


def test_eviction_at_capacity():
    log = AuditLog(max_entries=5)
    for i in range(10):
        log.record(_entry(tool=f"tool_{i}"))
    assert len(log) == 5
    # Oldest should be evicted
    names = [e.tool_name for e in log.entries]
    assert "tool_0" not in names
    assert "tool_9" in names


def test_entries_newest_first():
    log = AuditLog()
    log.record(_entry(tool="first"))
    log.record(_entry(tool="second"))
    assert log.entries[0].tool_name == "second"
    assert log.entries[1].tool_name == "first"


def test_query_by_tool_name():
    log = AuditLog()
    log.record(_entry(tool="deploy"))
    log.record(_entry(tool="read_file"))
    log.record(_entry(tool="deploy"))

    results = log.query(tool_name="deploy")
    assert len(results) == 2
    assert all(r.tool_name == "deploy" for r in results)


def test_query_by_effect():
    log = AuditLog()
    log.record(_entry(effect="allow"))
    log.record(_entry(effect="deny"))
    log.record(_entry(effect="deny"))

    denied = log.query(effect="deny")
    assert len(denied) == 2

    allowed = log.query(effect="allow")
    assert len(allowed) == 1


def test_query_since():
    now = datetime.now(timezone.utc)
    old = now - timedelta(hours=2)
    recent = now - timedelta(minutes=5)

    log = AuditLog()
    log.record(_entry(tool="old", ts=old))
    log.record(_entry(tool="recent", ts=recent))

    cutoff = now - timedelta(hours=1)
    results = log.query(since=cutoff)
    assert len(results) == 1
    assert results[0].tool_name == "recent"


def test_query_limit():
    log = AuditLog()
    for i in range(20):
        log.record(_entry(tool=f"tool_{i}"))

    results = log.query(limit=5)
    assert len(results) == 5


def test_query_combined_filters():
    log = AuditLog()
    log.record(_entry(tool="deploy", effect="deny"))
    log.record(_entry(tool="deploy", effect="allow"))
    log.record(_entry(tool="read_file", effect="deny"))

    results = log.query(tool_name="deploy", effect="deny")
    assert len(results) == 1


def test_query_no_matches():
    log = AuditLog()
    log.record(_entry(tool="deploy"))
    results = log.query(tool_name="nonexistent")
    assert results == []


def test_deny_rate():
    log = AuditLog()
    for i in range(7):
        log.record(_entry(effect="allow"))
    for i in range(3):
        log.record(_entry(effect="deny"))

    rate = log.deny_rate(window_seconds=3600)
    assert abs(rate - 0.3) < 0.01


def test_deny_rate_empty():
    log = AuditLog()
    assert log.deny_rate() == 0.0


def test_deny_rate_all_denied():
    log = AuditLog()
    for i in range(5):
        log.record(_entry(effect="deny"))
    assert log.deny_rate() == 1.0


def test_deny_rate_window():
    now = datetime.now(timezone.utc)
    old = now - timedelta(hours=2)

    log = AuditLog()
    log.record(_entry(effect="deny", ts=old))  # outside window
    log.record(_entry(effect="allow", ts=now))  # inside window

    rate = log.deny_rate(window_seconds=3600)
    assert rate == 0.0  # only the allow is in-window


def test_export_csv():
    log = AuditLog()
    log.record(_entry(tool="deploy", effect="deny"))
    log.record(_entry(tool="read_file", effect="allow"))

    csv_data = log.export_csv()
    lines = csv_data.strip().split("\n")
    assert len(lines) == 3  # header + 2 rows
    assert "tool_name" in lines[0]
    assert "deploy" in lines[1]


def test_export_csv_empty():
    log = AuditLog()
    csv_data = log.export_csv()
    lines = csv_data.strip().split("\n")
    assert len(lines) == 1  # header only


def test_export_csv_to_file(tmp_path):
    log = AuditLog()
    log.record(_entry())
    path = str(tmp_path / "audit.csv")
    log.export_csv(path=path)
    with open(path) as f:
        content = f.read()
    assert "tool_name" in content


def test_matched_rule_none():
    """Default effect (no rule matched) should record matched_rule=None."""
    log = AuditLog()
    log.record(_entry(rule=None))
    csv_data = log.export_csv()
    assert len(log) == 1
    assert log.entries[0].matched_rule is None
