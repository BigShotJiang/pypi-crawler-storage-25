"""Failure injection tests for gate-policy — edge cases across all modules.

Tests for:
- Engine: unknown operators, empty rules, None values, priority ties
- Audit: concurrent recording, capacity edge cases
- Threshold sync: override merging, extraction edge cases
- Server hook: CombinedResult logic
"""
import threading
from datetime import datetime, timezone

import pytest

from gate_policy.models import Condition, Effect, Policy, Rule
from gate_policy.engine import PolicyEngine
from gate_policy.audit import AuditEntry, AuditLog
from gate_policy.threshold_sync import (
    ThresholdOverride, ThresholdSyncState,
    thresholds_from_policy_result,
)
from gate_policy.server_hook import CombinedResult, ServerEnforcementConfig


# --- Engine edge cases ---


def test_unknown_operator_rejected_at_construction():
    """Condition validates operators — unknown ones raise ValueError."""
    with pytest.raises(ValueError, match="Unknown operator"):
        Condition(field="role", operator="FAKE_OP", value="admin")


def test_empty_rules_uses_default():
    policy = Policy(name="test", rules=[], default_effect=Effect.DENY)
    engine = PolicyEngine(policy)
    assert engine.evaluate("deploy", "high_impact", {}) == Effect.DENY


def test_none_value_in_context():
    """Context field explicitly set to None should be matchable."""
    cond = Condition(field="override", operator="eq", value=None)
    engine = PolicyEngine(Policy(name="test", rules=[], default_effect=Effect.ALLOW))
    assert engine.evaluate_condition(cond, {"override": None}) is True


def test_priority_ordering():
    """Higher priority rules should win over lower."""
    low_rule = Rule(
        name="low", priority=1, conditions=[],
        effect=Effect.ALLOW, tool_names=[], execution_classes=[],
    )
    high_rule = Rule(
        name="high", priority=10, conditions=[],
        effect=Effect.DENY, tool_names=[], execution_classes=[],
    )
    policy = Policy(name="test", rules=[low_rule, high_rule], default_effect=Effect.ALLOW)
    engine = PolicyEngine(policy)
    # High priority deny should win
    assert engine.evaluate("any_tool", "any_class", {}) == Effect.DENY


def test_rule_with_no_conditions_always_matches():
    rule = Rule(
        name="catch-all", priority=1, conditions=[],
        effect=Effect.DENY, tool_names=[], execution_classes=[],
    )
    policy = Policy(name="test", rules=[rule], default_effect=Effect.ALLOW)
    engine = PolicyEngine(policy)
    assert engine.evaluate("anything", "anything", {}) == Effect.DENY


def test_filter_tools_empty_list():
    policy = Policy(name="test", rules=[], default_effect=Effect.ALLOW)
    engine = PolicyEngine(policy)
    result = engine.filter_tools([], {})
    assert result == {"allowed": [], "denied": []}


def test_condition_in_operator():
    cond = Condition(field="role", operator="in", value=["admin", "operator"])
    engine = PolicyEngine(Policy(name="test", rules=[], default_effect=Effect.ALLOW))
    assert engine.evaluate_condition(cond, {"role": "admin"}) is True
    assert engine.evaluate_condition(cond, {"role": "viewer"}) is False


def test_condition_not_in_operator():
    cond = Condition(field="role", operator="not_in", value=["banned", "suspended"])
    engine = PolicyEngine(Policy(name="test", rules=[], default_effect=Effect.ALLOW))
    assert engine.evaluate_condition(cond, {"role": "admin"}) is True
    assert engine.evaluate_condition(cond, {"role": "banned"}) is False


# --- Audit concurrent recording ---


def test_audit_concurrent_writes():
    log = AuditLog(max_entries=10_000)
    errors = []

    def writer(thread_id):
        try:
            for i in range(100):
                log.record(AuditEntry(
                    timestamp=datetime.now(timezone.utc),
                    tool_name=f"tool_{thread_id}_{i}",
                    execution_class="read_only",
                    effect="allow",
                    matched_rule=None,
                    policy_name="test",
                    mode=0.0,
                    mode_zone="normal",
                ))
        except Exception as e:
            errors.append(e)

    threads = [threading.Thread(target=writer, args=(i,)) for i in range(4)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert errors == []
    assert len(log) == 400


def test_audit_capacity_exactly_at_limit():
    log = AuditLog(max_entries=3)
    for i in range(3):
        log.record(AuditEntry(
            timestamp=datetime.now(timezone.utc),
            tool_name=f"tool_{i}", execution_class="read_only",
            effect="allow", matched_rule=None,
            policy_name="test", mode=0.0, mode_zone="normal",
        ))
    assert len(log) == 3
    log.record(AuditEntry(
        timestamp=datetime.now(timezone.utc),
        tool_name="overflow", execution_class="read_only",
        effect="deny", matched_rule=None,
        policy_name="test", mode=0.0, mode_zone="normal",
    ))
    assert len(log) == 3
    assert log.entries[0].tool_name == "overflow"


# --- ThresholdSync edge cases ---


def test_threshold_override_most_restrictive_wins():
    state = ThresholdSyncState()
    state.active_overrides = [
        ThresholdOverride("high_impact", 0.30, "rule-A", "policy-1"),
        ThresholdOverride("high_impact", 0.10, "rule-B", "policy-2"),  # stricter
        ThresholdOverride("high_impact", 0.25, "rule-C", "policy-3"),
    ]
    pending = state.pending_overrides()
    assert pending["high_impact"] == 0.10  # lowest = most restrictive


def test_threshold_extraction_empty():
    result = thresholds_from_policy_result({})
    assert result == []


def test_threshold_extraction_with_overrides():
    result = thresholds_from_policy_result({
        "threshold_overrides": [
            {"class": "high_impact", "threshold": 0.20, "reason": "incident"},
        ]
    })
    assert len(result) == 1
    assert result[0].execution_class == "high_impact"
    assert result[0].new_threshold == 0.20


def test_threshold_extraction_skips_invalid():
    result = thresholds_from_policy_result({
        "threshold_overrides": [
            {"class": "", "threshold": 0.20},     # empty class
            {"class": "high_impact"},               # missing threshold
            {"class": "valid", "threshold": 0.30},  # valid
        ]
    })
    assert len(result) == 1
    assert result[0].execution_class == "valid"


# --- CombinedResult ---


def test_combined_result_both_allow():
    r = CombinedResult(policy_allowed=True, gate_allowed=True)
    assert r.allowed is True
    assert "allowed" in r.reason


def test_combined_result_policy_deny():
    r = CombinedResult(
        policy_allowed=False, gate_allowed=True,
        policy_reason="after-hours rule", gate_reason="",
    )
    assert r.allowed is False
    assert "policy denied" in r.reason


def test_combined_result_gate_deny():
    r = CombinedResult(
        policy_allowed=True, gate_allowed=False,
        policy_reason="", gate_reason="mode suppressed",
    )
    assert r.allowed is False
    assert "gate denied" in r.reason


def test_combined_result_both_deny():
    r = CombinedResult(
        policy_allowed=False, gate_allowed=False,
        policy_reason="blocked by rule", gate_reason="suppressed",
    )
    assert r.allowed is False
    assert "policy denied" in r.reason
    assert "gate denied" in r.reason
