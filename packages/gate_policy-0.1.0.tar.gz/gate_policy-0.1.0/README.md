# gate-policy

[![status](https://img.shields.io/badge/status-v0.1.0-blue)]()
[![tests](https://img.shields.io/badge/tests-62_passing-brightgreen)]()
[![license](https://img.shields.io/badge/license-Apache_2.0-green)]()

> Declarative policy engine for Gatekeeper. YAML rules over execution
> classes, mode zones, and request context.

Gate-core decides *what is visible at what mode*. Policy decides *who, when, and
under what condition*. Rules are evaluated in priority order against a context
dict; the first match wins. Ships an audit log, composition operator for
merging policies, and a `PolicyGate` wrapper that layers on top of any `Gate`.

## Install

```bash
pip install gate-policy  # once published
# or from source:
pip install -e .[dev]
```

## Quick example

```python
from gate_policy import load_policy_file, PolicyGate
from gatekeeper import Gate, Tool

policy = load_policy_file("examples/enterprise_standard.yaml")
gate = Gate()
gate.add_tools([
    Tool(name="read_file", execution_class="read_only"),
    Tool(name="deploy",    execution_class="high_impact"),
])

pg = PolicyGate(gate, policy)
result = pg.filter(mode=0.1, context={"human_approved": False, "role": "dev"})
# deploy denied by 'require-human-approval-for-high-impact' rule
```

## Example policy

```yaml
name: enterprise-standard
default_effect: allow
rules:
  - name: crisis-lockdown
    effect: deny
    execution_classes: [external_action, state_mutation, high_impact]
    conditions:
      - field: mode_zone
        operator: eq
        value: crisis
    priority: 100

  - name: require-approval-for-high-impact
    effect: deny
    execution_classes: [high_impact]
    conditions:
      - field: human_approved
        operator: neq
        value: true
    priority: 90
```

Operators: `eq`, `neq`, `in`, `not_in`, `gt`, `gte`, `lt`, `lte`.

## Composition

```python
from gate_policy import merge_policies

combined = merge_policies([org_policy, team_policy, project_policy])
# rules sorted by priority, duplicates collapsed by name
```

## Audit log

```python
from gate_policy.audit import AuditLog

log = AuditLog(max_entries=10_000)
pg = PolicyGate(gate, policy, audit_log=log)
# every evaluation records tool, class, effect, matched rule, mode zone, context
```

## Server integration

`gate_policy.server_hook` returns a `CombinedResult` that folds policy decisions
into a `gate-server` filter response — so a running service can serve policy-aware
manifests over HTTP.

## Tests

```bash
pytest tests/
```

62 tests across engine, loader, composition, threshold sync, audit, server
integration, and failure injection.

## How it fits

Layer 2 (enterprise) in [Gatekeeper](https://github.com/adam-scott-thomas/gate-keeper).
Depends on `gate-keeper`. Feeds `gate-server`, `gate-sdk`, and `gate-dashboard`.

## License

Apache-2.0.
