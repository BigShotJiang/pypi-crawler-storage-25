"""Policy loading from YAML/dict.

Supports loading policies from Python dicts or YAML files.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from gate_policy.models import Condition, Effect, Policy, Rule


def _parse_condition(raw: dict[str, Any]) -> Condition:
    return Condition(
        field=raw["field"],
        operator=raw["operator"],
        value=raw["value"],
    )


def _parse_rule(raw: dict[str, Any]) -> Rule:
    conditions = tuple(_parse_condition(c) for c in raw.get("conditions", []))
    exec_classes = frozenset(raw.get("execution_classes", []))
    tool_names = frozenset(raw.get("tool_names", []))
    return Rule(
        name=raw["name"],
        effect=Effect(raw["effect"]),
        execution_classes=exec_classes,
        tool_names=tool_names,
        conditions=conditions,
        priority=raw.get("priority", 0),
    )


def load_policy(data: dict[str, Any]) -> Policy:
    """Load a Policy from a dict (parsed YAML/JSON)."""
    rules = tuple(_parse_rule(r) for r in data.get("rules", []))
    default = Effect(data.get("default_effect", "allow"))
    return Policy(
        name=data["name"],
        description=data.get("description", ""),
        rules=rules,
        default_effect=default,
    )


def load_policy_file(path: str | Path) -> Policy:
    """Load a Policy from a YAML file."""
    with open(path) as f:
        data = yaml.safe_load(f)
    return load_policy(data)
