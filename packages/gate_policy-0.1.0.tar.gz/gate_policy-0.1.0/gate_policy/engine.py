"""Policy evaluation engine.

Evaluates a Policy against a gate context to produce allow/deny decisions
per tool. Integrates with gate-core's filter pipeline.
"""

from __future__ import annotations

from typing import Any

from gate_policy.models import Condition, Effect, Policy, Rule


class PolicyEngine:
    """Evaluates policies against a runtime context."""

    def __init__(self, policy: Policy):
        self.policy = policy

    def evaluate_condition(self, condition: Condition, context: dict[str, Any]) -> bool:
        """Check if a single condition is satisfied by the context."""
        if condition.field not in context:
            return False
        val = context[condition.field]

        op = condition.operator
        expected = condition.value

        if op == "eq":
            return val == expected
        elif op == "neq":
            return val != expected
        elif op == "gt":
            return val > expected
        elif op == "gte":
            return val >= expected
        elif op == "lt":
            return val < expected
        elif op == "lte":
            return val <= expected
        elif op == "in":
            return val in expected
        elif op == "not_in":
            return val not in expected
        return False

    def rule_matches(self, rule: Rule, tool_name: str, execution_class: str, context: dict[str, Any]) -> bool:
        """Check if a rule applies to a given tool in the current context."""
        if rule.tool_names and tool_name not in rule.tool_names:
            return False
        if rule.execution_classes and execution_class not in rule.execution_classes:
            return False
        return all(self.evaluate_condition(c, context) for c in rule.conditions)

    def evaluate(self, tool_name: str, execution_class: str, context: dict[str, Any]) -> Effect:
        """Evaluate the policy for a specific tool and return allow/deny.

        Rules are checked in priority order (highest first). The first
        matching rule wins. If no rule matches, default_effect applies.
        """
        sorted_rules = sorted(self.policy.rules, key=lambda r: r.priority, reverse=True)
        for rule in sorted_rules:
            if self.rule_matches(rule, tool_name, execution_class, context):
                return rule.effect
        return self.policy.default_effect

    def filter_tools(self, tools: list[dict[str, Any]], context: dict[str, Any]) -> dict[str, list[dict[str, Any]]]:
        """Filter a tool manifest through the policy.

        Returns {"allowed": [...], "denied": [...]} with full tool dicts.
        This sits on top of gate-core's mode-based suppression — a tool
        can be visible per gate-core but denied by policy.
        """
        allowed = []
        denied = []
        for tool in tools:
            effect = self.evaluate(tool["name"], tool["execution_class"], context)
            if effect == Effect.ALLOW:
                allowed.append(tool)
            else:
                denied.append(tool)
        return {"allowed": allowed, "denied": denied}
