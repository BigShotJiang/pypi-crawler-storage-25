"""Policy data models.

A Policy contains Rules. Each Rule has Conditions that must be met
and an Effect (allow or deny) applied to a set of tools or execution classes.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class Effect(Enum):
    ALLOW = "allow"
    DENY = "deny"


@dataclass(frozen=True)
class Condition:
    """A single predicate evaluated against the gate context.

    field:    context key to check (e.g. "mode", "role", "hour", "human_approved")
    operator: comparison op ("eq", "neq", "gt", "gte", "lt", "lte", "in", "not_in")
    value:    expected value or list of values
    """
    field: str
    operator: str
    value: Any

    OPERATORS = {"eq", "neq", "gt", "gte", "lt", "lte", "in", "not_in"}

    def __post_init__(self):
        if self.operator not in self.OPERATORS:
            raise ValueError(f"Unknown operator '{self.operator}', must be one of {self.OPERATORS}")


@dataclass(frozen=True)
class Rule:
    """A single policy rule.

    name:              human-readable identifier
    effect:            allow or deny
    execution_classes: which classes this rule targets (empty = all)
    tool_names:        specific tool names this rule targets (empty = all)
    conditions:        all must be true for the rule to apply
    priority:          higher priority rules win on conflict (default 0)
    """
    name: str
    effect: Effect
    execution_classes: frozenset[str] = field(default_factory=frozenset)
    tool_names: frozenset[str] = field(default_factory=frozenset)
    conditions: tuple[Condition, ...] = ()
    priority: int = 0


@dataclass(frozen=True)
class Policy:
    """A complete policy document.

    name:          policy identifier
    description:   what this policy enforces
    rules:         ordered list of rules
    default_effect: what happens when no rule matches (default: allow)
    """
    name: str
    rules: tuple[Rule, ...]
    description: str = ""
    default_effect: Effect = Effect.ALLOW
