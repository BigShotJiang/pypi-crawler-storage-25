"""Server-backed policy enforcement — call gate-server to apply policies remotely.

When gate-policy runs as a sidecar or separate service, it needs to reach
gate-server to register policy-enforced tools and validate proposals.

This module provides the wiring between PolicyEngine decisions and
gate-server's HTTP API.

Flow:
    1. PolicyEngine evaluates a tool proposal against loaded rules
    2. If the policy says "allow", server_hook calls gate-server /tools/validate
       to get the gate-core opinion too (defense in depth)
    3. Combined result: both policy AND gate must agree

NOT WIRED YET — An Improver should:
  1. Add httpx to gate-policy dependencies
  2. Implement the HTTP calls
  3. Wire this into PolicyGate as an optional enforcement backend
  4. Add integration tests against a running gate-server

Seeded by Creator 2 (gate-server), Loop 5.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class ServerEnforcementConfig:
    """Configuration for server-backed enforcement."""
    gate_server_url: str = "http://localhost:8900/api/v1"
    timeout_seconds: float = 5.0
    fail_open: bool = False  # if server unreachable: True=allow, False=deny


@dataclass
class CombinedResult:
    """Result of policy + gate-server dual evaluation."""
    policy_allowed: bool = False
    gate_allowed: bool = False
    policy_reason: str = ""
    gate_reason: str = ""

    @property
    def allowed(self) -> bool:
        """Both must agree for the tool to be allowed."""
        return self.policy_allowed and self.gate_allowed

    @property
    def reason(self) -> str:
        if self.allowed:
            return "allowed by policy and gate"
        parts = []
        if not self.policy_allowed:
            parts.append(f"policy denied: {self.policy_reason}")
        if not self.gate_allowed:
            parts.append(f"gate denied: {self.gate_reason}")
        return "; ".join(parts)


def enforce_with_server(
    tool_name: str,
    mode: float,
    policy_result: dict[str, Any],
    config: ServerEnforcementConfig | None = None,
) -> CombinedResult:
    """Dual-check: policy engine result + gate-server validation.

    Args:
        tool_name: The tool being proposed.
        mode: Current threat mode signal (0.0-1.0).
        policy_result: Output from PolicyEngine.evaluate().
        config: Server connection config.

    Returns:
        CombinedResult with both verdicts.
    """
    config = config or ServerEnforcementConfig()

    result = CombinedResult(
        policy_allowed=policy_result.get("allowed", False),
        policy_reason=policy_result.get("reason", "no reason given"),
    )

    # TODO: Implement HTTP call to gate-server
    # response = httpx.post(
    #     f"{config.gate_server_url}/tools/validate",
    #     json={"tool_name": tool_name, "mode": mode},
    #     timeout=config.timeout_seconds,
    # )
    # gate_data = response.json()
    # result.gate_allowed = gate_data["accepted"]
    # result.gate_reason = gate_data["reason"]

    # Stub: gate side is unknown until wired
    result.gate_allowed = False
    result.gate_reason = "server hook not wired — stub returns deny"

    return result


def sync_tools_to_server(
    tools: list[dict[str, Any]],
    config: ServerEnforcementConfig | None = None,
) -> dict[str, Any]:
    """Push policy-managed tools to gate-server for registration.

    Called when policies are loaded/reloaded so gate-server knows
    about the full tool inventory.
    """
    config = config or ServerEnforcementConfig()

    # TODO: Implement HTTP call
    # payload = {"tools": tools}
    # response = httpx.post(
    #     f"{config.gate_server_url}/tools/register",
    #     json=payload,
    #     timeout=config.timeout_seconds,
    # )
    # return response.json()

    return {"stub": True, "message": "sync_tools_to_server not wired yet"}
