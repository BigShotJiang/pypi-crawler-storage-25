"""Policy decision audit trail.

Records every policy evaluation with timestamp, context, matching rule,
and outcome. Designed for compliance reporting and forensic review.

Consumer: gate-compliance (Layer 2) can ingest these records via
the compliance_bridge example.

Originally a stub by Creator 4. Implemented by Improver 1.
"""
from __future__ import annotations

import csv
import io
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any


@dataclass
class AuditEntry:
    """A single policy decision record."""
    timestamp: datetime
    tool_name: str
    execution_class: str
    effect: str  # "allow" or "deny"
    matched_rule: str | None  # rule name that fired, or None for default
    policy_name: str
    mode: float
    mode_zone: str
    context: dict[str, Any] = field(default_factory=dict)


class AuditLog:
    """In-memory audit log with ring buffer eviction.

    Usage:
        log = AuditLog(max_entries=10_000)
        log.record(AuditEntry(
            timestamp=datetime.now(timezone.utc),
            tool_name="deploy", execution_class="high_impact",
            effect="deny", matched_rule="after-hours",
            policy_name="enterprise", mode=0.5, mode_zone="elevated",
            context={"role": "developer", "hour": 22},
        ))

        denied = log.query(effect="deny")
        rate = log.deny_rate(window_seconds=3600)
    """

    def __init__(self, max_entries: int = 10_000) -> None:
        self._entries: deque[AuditEntry] = deque(maxlen=max_entries)

    def record(self, entry: AuditEntry) -> None:
        """Append an audit entry. Evicts oldest if over capacity."""
        self._entries.append(entry)

    @property
    def entries(self) -> list[AuditEntry]:
        """All entries, newest first."""
        return list(reversed(self._entries))

    def __len__(self) -> int:
        return len(self._entries)

    def query(
        self,
        tool_name: str | None = None,
        effect: str | None = None,
        since: datetime | None = None,
        limit: int = 100,
    ) -> list[AuditEntry]:
        """Query audit entries with optional filters."""
        results = []
        for entry in reversed(self._entries):  # newest first
            if tool_name and entry.tool_name != tool_name:
                continue
            if effect and entry.effect != effect:
                continue
            if since and entry.timestamp < since:
                continue
            results.append(entry)
            if len(results) >= limit:
                break
        return results

    def deny_rate(self, window_seconds: int = 3600) -> float:
        """Fraction of evaluations that resulted in deny within the window."""
        now = datetime.now(timezone.utc)
        total = 0
        denied = 0
        for entry in self._entries:
            age = (now - entry.timestamp).total_seconds()
            if age <= window_seconds:
                total += 1
                if entry.effect == "deny":
                    denied += 1
        if total == 0:
            return 0.0
        return denied / total

    def export_csv(self, path: str | None = None) -> str:
        """Export audit log to CSV.

        If path is provided, writes to file. Always returns CSV as string.
        """
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow([
            "timestamp", "tool_name", "execution_class", "effect",
            "matched_rule", "policy_name", "mode", "mode_zone",
        ])
        for entry in self._entries:
            writer.writerow([
                entry.timestamp.isoformat(), entry.tool_name,
                entry.execution_class, entry.effect,
                entry.matched_rule or "", entry.policy_name,
                entry.mode, entry.mode_zone,
            ])

        csv_data = output.getvalue()
        if path:
            with open(path, "w", newline="") as f:
                f.write(csv_data)
        return csv_data
