"""Policy composition — merge multiple policies into one.

Supports two merge strategies:
- strict: all policies must allow (any deny wins)
- permissive: any policy can allow (any allow wins)
"""

from __future__ import annotations

from gate_policy.models import Effect, Policy, Rule


def merge_policies(
    policies: list[Policy],
    name: str | None = None,
    strategy: str = "strict",
) -> Policy:
    """Merge multiple policies into a single policy.

    Args:
        policies: list of Policy objects to merge
        name: name for the merged policy (default: joined names)
        strategy: "strict" (default) or "permissive"
            - strict: rules from all policies are combined, highest priority wins.
                      Default effect is DENY if any policy defaults to DENY.
            - permissive: same rule combination, but default effect is ALLOW
                          unless ALL policies default to DENY.

    Returns:
        A new Policy with all rules combined and priorities preserved.
    """
    if strategy not in ("strict", "permissive"):
        raise ValueError(f"Unknown strategy '{strategy}', must be 'strict' or 'permissive'")

    if not policies:
        raise ValueError("Cannot merge empty policy list")

    if len(policies) == 1:
        return policies[0]

    merged_name = name or " + ".join(p.name for p in policies)

    all_rules: list[Rule] = []
    for policy in policies:
        all_rules.extend(policy.rules)

    if strategy == "strict":
        default = (
            Effect.DENY
            if any(p.default_effect == Effect.DENY for p in policies)
            else Effect.ALLOW
        )
    elif strategy == "permissive":
        default = (
            Effect.DENY
            if all(p.default_effect == Effect.DENY for p in policies)
            else Effect.ALLOW
        )
    else:
        raise ValueError(f"Unknown strategy '{strategy}', must be 'strict' or 'permissive'")

    descriptions = [p.description for p in policies if p.description]
    merged_desc = " | ".join(descriptions) if descriptions else ""

    return Policy(
        name=merged_name,
        description=merged_desc,
        rules=tuple(all_rules),
        default_effect=default,
    )
