"""Policy-driven threshold synchronization with gate-server.

When the PolicyEngine evaluates rules, it may decide that certain
execution classes need tighter or looser thresholds based on context.
This module pushes those decisions to gate-server's PUT /v1/thresholds
endpoint so the server-side enforcement matches the policy intent.

Use cases:
  - Policy rule says "during_incident: suppress high_impact at 0.20"
    → push {high_impact: 0.20} to gate-server
  - Policy relaxation: "approved_deployer: allow high_impact at 0.50"
    → push {high_impact: 0.50} to gate-server
  - Time-based policies: "after_hours: tighten state_mutation to 0.40"
    → push {state_mutation: 0.40} to gate-server

This complements server_hook.py (which validates individual tool proposals)
with bulk threshold control. Together they form the sidecar wiring:

  server_hook.py  → per-tool validation (fine-grained)
  threshold_sync.py → class-wide thresholds (coarse-grained)

NOT WIRED YET — An Improver should:
  1. Add httpx to gate-policy dependencies
  2. Implement the HTTP calls to PUT /v1/thresholds
  3. Hook into PolicyEngine.evaluate() result pipeline
  4. Add rollback logic (restore previous thresholds on policy unload)
  5. Add integration tests against a running gate-server

Seeded by Creator 3 (gate-server-go), Loop 5.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


# Gate spec default thresholds (from gate-core Section 4)
DEFAULT_THRESHOLDS: dict[str, float | None] = {
    "read_only": None,       # never suppressed
    "advisory": None,        # never suppressed
    "external_action": 0.65,
    "state_mutation": 0.65,
    "high_impact": 0.35,
}


@dataclass
class ThresholdOverride:
    """A policy-driven threshold change."""
    execution_class: str
    new_threshold: float
    reason: str          # why the policy wants this change
    policy_rule: str     # which rule triggered it
    ttl_seconds: int = 0  # 0 = permanent until next sync; >0 = auto-revert


@dataclass
class ThresholdSyncState:
    """Tracks what thresholds we've pushed vs. what the server has."""
    server_url: str = "http://localhost:8090"
    active_overrides: list[ThresholdOverride] = field(default_factory=list)
    last_sync_timestamp: str = ""
    last_sync_success: bool = False

    def pending_overrides(self) -> dict[str, float]:
        """Collapse active overrides into a single threshold dict.

        If multiple rules override the same class, the most restrictive
        (lowest threshold) wins — defense in depth.
        """
        merged: dict[str, float] = {}
        for ov in self.active_overrides:
            cls = ov.execution_class
            if cls not in merged or ov.new_threshold < merged[cls]:
                merged[cls] = ov.new_threshold
        return merged


def thresholds_from_policy_result(
    policy_result: dict[str, Any],
) -> list[ThresholdOverride]:
    """Extract threshold overrides from a PolicyEngine evaluation result.

    Looks for a "threshold_overrides" key in the policy result dict.
    Expected format:
      {
        "threshold_overrides": [
          {"class": "high_impact", "threshold": 0.20, "reason": "incident active"},
          {"class": "state_mutation", "threshold": 0.40, "reason": "after hours"}
        ]
      }

    Returns empty list if no overrides found.
    """
    raw = policy_result.get("threshold_overrides", [])
    overrides = []
    for item in raw:
        cls = item.get("class", "")
        threshold = item.get("threshold")
        if cls and threshold is not None:
            overrides.append(ThresholdOverride(
                execution_class=cls,
                new_threshold=float(threshold),
                reason=item.get("reason", "policy override"),
                policy_rule=item.get("rule", "unknown"),
                ttl_seconds=item.get("ttl", 0),
            ))
    return overrides


def push_thresholds(
    overrides: dict[str, float],
    server_url: str = "http://localhost:8090",
    timeout: float = 5.0,
) -> dict[str, Any]:
    """Push threshold overrides to gate-server.

    Calls PUT /v1/thresholds with the override dict.
    Both gate-server (Python, port 8900) and gate-server-go (port 8090)
    support this endpoint.

    Args:
        overrides: {execution_class: threshold} dict.
        server_url: Base URL of the gate-server.
        timeout: Request timeout in seconds.

    Returns:
        Server response dict, or stub marker.
    """
    # TODO: Implement HTTP call
    # response = httpx.put(
    #     f"{server_url}/v1/thresholds",
    #     json=overrides,
    #     timeout=timeout,
    # )
    # return response.json()

    return {"stub": True, "would_push": overrides, "to": server_url}


def restore_defaults(
    server_url: str = "http://localhost:8090",
    timeout: float = 5.0,
) -> dict[str, Any]:
    """Reset gate-server thresholds to spec defaults.

    Called when policies are unloaded or the sidecar shuts down cleanly.
    """
    defaults_to_push = {
        k: v for k, v in DEFAULT_THRESHOLDS.items() if v is not None
    }
    return push_thresholds(defaults_to_push, server_url, timeout)


def sync_from_policy(
    policy_result: dict[str, Any],
    state: ThresholdSyncState | None = None,
) -> ThresholdSyncState:
    """Full sync cycle: extract overrides from policy, push to server.

    This is the main entry point. Call it after PolicyEngine.evaluate()
    returns a result that might contain threshold overrides.
    """
    state = state or ThresholdSyncState()

    new_overrides = thresholds_from_policy_result(policy_result)
    if not new_overrides:
        return state

    state.active_overrides.extend(new_overrides)
    pending = state.pending_overrides()

    result = push_thresholds(pending, state.server_url)
    state.last_sync_success = not result.get("stub", False)

    return state
