"""Gate-core integration — PolicyGate wraps Gate with policy overlay.

PolicyGate sits on top of gate-core's mode-based suppression.
A tool must pass BOTH the mode filter AND the policy to be visible.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from gatekeeper.core import Gate, Tool, ToolFilter

from gate_policy.engine import PolicyEngine
from gate_policy.models import Effect, Policy


class PolicyGate:
    """A Gate wrapped with a Policy layer.

    Flow: register tools -> filter(mode, context) ->
      1. gate-core suppresses by mode/threshold
      2. policy engine denies by rule evaluation
      3. result contains both suppression reasons
    """

    def __init__(self, gate: Gate, policy: Policy) -> None:
        self._gate = gate
        self._engine = PolicyEngine(policy)
        self._policy = policy

    @property
    def gate(self) -> Gate:
        return self._gate

    @property
    def policy(self) -> Policy:
        return self._policy

    def add_tool(self, tool: Tool) -> None:
        self._gate.add_tool(tool)

    def add_tools(self, tools: list[Tool]) -> None:
        self._gate.add_tools(tools)

    def filter(self, mode: float, context: dict[str, Any] | None = None) -> PolicyFilterResult:
        """Filter tools through mode suppression + policy rules.

        The context dict is passed to the policy engine. Mode and mode_zone
        are injected automatically so policy rules can reference them.
        """
        gate_result = self._gate.filter(mode)

        ctx = dict(context) if context else {}
        ctx["mode"] = gate_result.mode
        ctx["mode_zone"] = gate_result.mode_zone
        _inject_time_context(ctx)

        visible = []
        policy_denied = []

        for tool in gate_result.visible:
            effect = self._engine.evaluate(tool.name, tool.execution_class, ctx)
            if effect == Effect.ALLOW:
                visible.append(tool)
            else:
                policy_denied.append(tool)

        return PolicyFilterResult(
            visible=tuple(visible),
            suppressed=gate_result.suppressed,
            policy_denied=tuple(policy_denied),
            mode=gate_result.mode,
            mode_zone=gate_result.mode_zone,
            thresholds=gate_result.thresholds,
            policy_name=self._policy.name,
            context=ctx,
        )


class PolicyFilterResult:
    """Extended filter result with policy denial info.

    Three categories:
    - visible: passed both mode filter and policy
    - suppressed: blocked by gate-core mode thresholds
    - policy_denied: passed mode filter but blocked by policy rules
    """

    def __init__(
        self,
        visible: tuple[Tool, ...],
        suppressed: tuple[Tool, ...],
        policy_denied: tuple[Tool, ...],
        mode: float,
        mode_zone: str,
        thresholds: dict[str, float | None],
        policy_name: str,
        context: dict[str, Any],
    ) -> None:
        self.visible = visible
        self.suppressed = suppressed
        self.policy_denied = policy_denied
        self.mode = mode
        self.mode_zone = mode_zone
        self.thresholds = thresholds
        self.policy_name = policy_name
        self.context = context

    @property
    def visible_names(self) -> list[str]:
        return [t.name for t in self.visible]

    @property
    def suppressed_names(self) -> list[str]:
        return [t.name for t in self.suppressed]

    @property
    def policy_denied_names(self) -> list[str]:
        return [t.name for t in self.policy_denied]

    @property
    def all_blocked_names(self) -> list[str]:
        return self.suppressed_names + self.policy_denied_names


def _inject_time_context(ctx: dict[str, Any]) -> None:
    """Add time fields to context if not already present.

    Injects: hour (0-23), minute (0-59), weekday (0=Mon, 6=Sun),
    weekday_name, is_weekend, is_business_hours.
    """
    if "hour" in ctx:
        return
    now = ctx.pop("_now", None) or datetime.now()
    ctx["hour"] = now.hour
    ctx["minute"] = now.minute
    ctx["weekday"] = now.weekday()
    ctx["weekday_name"] = now.strftime("%A").lower()
    ctx["is_weekend"] = now.weekday() >= 5
    ctx["is_business_hours"] = (
        now.weekday() < 5 and 9 <= now.hour < 17
    )
