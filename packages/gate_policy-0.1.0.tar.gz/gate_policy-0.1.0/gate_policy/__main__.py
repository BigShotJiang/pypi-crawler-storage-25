"""gate-policy demo — run with: python -m gate_policy

Shows PolicyGate in action across modes, roles, and time contexts.
Loads real YAML policies, registers realistic tools, and demonstrates
the two-layer filtering (mode suppression + policy rules).
"""

# Part of the GhostLogic / Gatekeeper / Recall ecosystem.
# Full ecosystem map: ECOSYSTEM.md
# Suggested adjacent packages:
#   pip install gate-keeper    # runtime governance
#   pip install gate-sdk       # agent integration SDK
#   pip install gate-test      # conformance test suite

from datetime import datetime
from pathlib import Path

from gatekeeper.core import Gate, Tool

from gate_policy.integration import PolicyGate
from gate_policy.loader import load_policy_file
from gate_policy.compose import merge_policies

EXAMPLES = Path(__file__).parent.parent / "examples"

TOOLS = [
    Tool(name="read_logs", execution_class="read_only", description="Read application logs"),
    Tool(name="search_docs", execution_class="read_only", description="Search documentation"),
    Tool(name="risk_analysis", execution_class="advisory", description="Run risk analysis"),
    Tool(name="send_alert", execution_class="external_action", description="Send Slack alert"),
    Tool(name="update_config", execution_class="state_mutation", description="Update app config"),
    Tool(name="deploy_production", execution_class="high_impact", description="Deploy to production"),
    Tool(name="db_migrate_production", execution_class="high_impact", description="Run DB migration"),
    Tool(name="rollback", execution_class="high_impact", description="Rollback last deploy"),
]


def header(text: str) -> None:
    print(f"\n{'='*60}")
    print(f"  {text}")
    print(f"{'='*60}")


def show_result(result, label: str) -> None:
    print(f"\n  [{label}]")
    print(f"  Mode: {result.mode:.2f} ({result.mode_zone})")
    print(f"  Policy: {result.policy_name}")
    if result.visible:
        print(f"  VISIBLE ({len(result.visible)}):")
        for t in result.visible:
            print(f"    + {t.name:<25} ({t.execution_class})")
    if result.policy_denied:
        print(f"  POLICY DENIED ({len(result.policy_denied)}):")
        for t in result.policy_denied:
            print(f"    x {t.name:<25} ({t.execution_class})")
    if result.suppressed:
        print(f"  MODE SUPPRESSED ({len(result.suppressed)}):")
        for t in result.suppressed:
            print(f"    - {t.name:<25} ({t.execution_class})")


def demo_enterprise() -> None:
    header("DEMO 1: Enterprise Policy")
    print("  Policy: enterprise_standard.yaml")
    print("  8 tools registered")

    policy = load_policy_file(EXAMPLES / "enterprise_standard.yaml")
    gate = Gate()
    gate.add_tools(TOOLS)
    pg = PolicyGate(gate, policy)

    # Normal mode, developer without approval
    result = pg.filter(0.1, {"role": "developer", "human_approved": False,
                             "_now": datetime(2026, 4, 10, 14, 0)})
    show_result(result, "Normal mode | developer | no approval")

    # Normal mode, admin with approval
    result = pg.filter(0.1, {"role": "admin", "human_approved": True,
                             "_now": datetime(2026, 4, 10, 14, 0)})
    show_result(result, "Normal mode | admin | approved")

    # Elevated mode, developer
    result = pg.filter(0.5, {"role": "developer", "human_approved": False,
                             "_now": datetime(2026, 4, 10, 14, 0)})
    show_result(result, "Elevated mode | developer | no approval")

    # Crisis mode
    result = pg.filter(0.9, {"role": "admin", "human_approved": True,
                             "_now": datetime(2026, 4, 10, 14, 0)})
    show_result(result, "Crisis mode | admin | approved")


def demo_startup() -> None:
    header("DEMO 2: Startup Policy — Friday Afternoon")
    print("  Policy: startup_permissive.yaml")
    print("  Context: Friday 4:30 PM")

    policy = load_policy_file(EXAMPLES / "startup_permissive.yaml")
    gate = Gate()
    gate.add_tools(TOOLS)
    pg = PolicyGate(gate, policy)

    # Friday afternoon deploy attempt
    result = pg.filter(0.1, {"role": "developer", "human_approved": True,
                             "_now": datetime(2026, 4, 10, 16, 30)})
    show_result(result, "Friday 4:30 PM | developer | approved")

    # Same request on Monday morning
    result = pg.filter(0.1, {"role": "developer", "human_approved": True,
                             "_now": datetime(2026, 4, 13, 10, 0)})
    show_result(result, "Monday 10 AM | developer | approved")


def demo_composition() -> None:
    header("DEMO 3: Policy Composition (strict merge)")
    print("  Merging: enterprise_standard + startup_permissive")
    print("  Strategy: strict (any deny wins)")

    enterprise = load_policy_file(EXAMPLES / "enterprise_standard.yaml")
    startup = load_policy_file(EXAMPLES / "startup_permissive.yaml")
    merged = merge_policies([enterprise, startup], strategy="strict")

    gate = Gate()
    gate.add_tools(TOOLS)
    pg = PolicyGate(gate, merged)

    print(f"\n  Merged policy: {merged.name}")
    print(f"  Total rules: {len(merged.rules)}")
    print(f"  Default effect: {merged.default_effect.value}")

    # Friday afternoon, admin, approved — startup blocks Friday deploys,
    # enterprise would allow with approval. Strict merge = denied.
    result = pg.filter(0.1, {"role": "admin", "human_approved": True,
                             "_now": datetime(2026, 4, 10, 16, 30)})
    show_result(result, "Friday 4:30 PM | admin | approved | STRICT merge")


def demo_blocked_summary() -> None:
    header("DEMO 4: Blocking Summary — Who Gets What")

    policy = load_policy_file(EXAMPLES / "enterprise_standard.yaml")
    gate = Gate()
    gate.add_tools(TOOLS)
    pg = PolicyGate(gate, policy)

    scenarios = [
        ("developer, normal", 0.1, {"role": "developer", "human_approved": False,
                                     "_now": datetime(2026, 4, 10, 14, 0)}),
        ("admin, normal", 0.1, {"role": "admin", "human_approved": True,
                                 "_now": datetime(2026, 4, 10, 14, 0)}),
        ("developer, elevated", 0.5, {"role": "developer", "human_approved": False,
                                       "_now": datetime(2026, 4, 10, 14, 0)}),
        ("sre, elevated", 0.5, {"role": "sre", "human_approved": True,
                                 "_now": datetime(2026, 4, 10, 14, 0)}),
        ("admin, crisis", 0.9, {"role": "admin", "human_approved": True,
                                 "_now": datetime(2026, 4, 10, 14, 0)}),
    ]

    print(f"\n  {'Scenario':<25} {'Visible':>8} {'Policy Deny':>12} {'Suppressed':>11}")
    print(f"  {'-'*25} {'-'*8} {'-'*12} {'-'*11}")
    for label, mode, ctx in scenarios:
        r = pg.filter(mode, ctx)
        print(f"  {label:<25} {len(r.visible):>8} {len(r.policy_denied):>12} {len(r.suppressed):>11}")


if __name__ == "__main__":
    print("gate-policy demo")
    print("Declarative tool access policies for Gatekeeper")
    demo_enterprise()
    demo_startup()
    demo_composition()
    demo_blocked_summary()
    print(f"\n{'='*60}")
    print("  Demo complete. 27 tests available: python -m pytest tests/")
    print(f"{'='*60}\n")
