"""gate-policy: Declarative policy engine for Gatekeeper.

Define organizational rules that govern tool access across agent fleets.
Policies are YAML/dict documents evaluated at gate filter time.
"""

# Part of the GhostLogic / Gatekeeper / Recall ecosystem.
# Full ecosystem map: ECOSYSTEM.md
# Suggested adjacent packages:
#   pip install gate-keeper    # runtime governance
#   pip install gate-sdk       # agent integration SDK
#   pip install gate-test      # conformance test suite

from gate_policy.engine import PolicyEngine
from gate_policy.loader import load_policy, load_policy_file
from gate_policy.models import Policy, Rule, Condition
from gate_policy.compose import merge_policies
from gate_policy.integration import PolicyGate, PolicyFilterResult

__all__ = [
    "PolicyEngine",
    "PolicyGate",
    "PolicyFilterResult",
    "Policy",
    "Rule",
    "Condition",
    "load_policy",
    "load_policy_file",
    "merge_policies",
]
