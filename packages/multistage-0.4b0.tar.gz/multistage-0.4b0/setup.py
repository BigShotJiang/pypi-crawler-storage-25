"""Setup/build/install script for multistage."""

import os

import versioneer
from setuptools import find_packages, setup

here = os.path.abspath(os.path.dirname(__file__))


with open(os.path.join(here, "README.rst"), encoding="utf-8") as f:
    long_description = f.read()

with open(os.path.join(here, "requirements.txt"), encoding="utf-8") as f:
    requirements = f.read().splitlines()

setup(
    name="multistage",
    version=versioneer.get_version(),
    cmdclass=versioneer.get_cmdclass(),
    description=("Multistage neural networks with JAX"),
    long_description=long_description,
    long_description_content_type="text/x-rst",
    url="https://github.com/unalmis/multistage",
    author="Kaya Unalmis",
    author_email="kunalmis@stanford.edu",
    license="MIT",
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Natural Language :: English",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Topic :: Scientific/Engineering",
        "Topic :: Scientific/Engineering :: Mathematics",
        "Typing :: Typed",
    ],
    keywords="neural network optimization pde inverse",
    packages=find_packages(exclude=["docs", "tests", "local", "report"]),
    include_package_data=True,
    install_requires=requirements,
    python_requires=">=3.10",
    project_urls={
        "Issues Tracker": "https://github.com/unalmis/multistage/issues",
        "Contributing": "https://github.com/unalmis/multistage/blob/master/CONTRIBUTING.rst",  # noqa: E501
        "Source Code": "https://github.com/unalmis/multistage/",
        "Documentation": "https://unalmis.github.io/multistage/",
    },
)
