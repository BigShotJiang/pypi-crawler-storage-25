"""General multi-stage neural network classes."""

import os
import time
import warnings
from functools import partial

import equinox as eqx
import jax
import jax.numpy as jnp
import lineax as lx
import numpy as np
import optax
import optimistix
import orbax.checkpoint as ocp
from jax import config, jit, value_and_grad
from paramax import non_trainable, unwrap

from ._io_utils import _ParamContainer, checkpoint_manager, save
from ._utils import (
    adaptive_sample,
    is_not_trainable,
    partition,
    rescale,
    stats,
    stats_chebyshev,
)

config.update("jax_enable_x64", True)


def _coerce_params(params, params_are_trainable):
    """Return a consistently initialized parameter container."""
    if params is None:
        return _ParamContainer({})
    if not isinstance(params, _ParamContainer):
        params = _ParamContainer(params)
    if params_are_trainable:
        return params
    return _ParamContainer(
        {
            key: val if (val is None or is_not_trainable(val)) else non_trainable(val)
            for key, val in params.items()
        }
    )


def _trainable_params_or_none(params):
    """Extract trainable PDE parameters, returning None when there are none."""
    if params is None:
        return None
    params = eqx.filter(
        params, is_not_trainable, inverse=True, is_leaf=is_not_trainable
    )
    leaves = [
        leaf for leaf in jax.tree_util.tree_leaves(params) if eqx.is_inexact_array(leaf)
    ]
    return params if leaves else None


_DEFAULT_STAGE_CORRECTION_PARAM_MAP = {"log_lambda_2": "lambda_2"}
_TRANSFORMED_PARAM_PREFIXES = ("log_", "exp_")


def _stage_correction_entry(key, val, correction_param_map):
    spec = correction_param_map.get(key, key)
    if callable(spec):
        correction_key, correction_val = spec(key, val)
    elif isinstance(spec, tuple):
        correction_key, initializer = spec
        correction_val = initializer(val) if callable(initializer) else initializer
    else:
        correction_key = spec
        correction_val = jnp.zeros_like(val)
    return correction_key, correction_val


def _stage_correction_params_or_none(params, correction_param_map=None):
    """Initialize trainable PDE parameter corrections for the next stage.

    A later stage stores corrections, not another copy of the previous total
    estimate. Transformed parameters require an explicit map because their
    neutral correction value depends on how the PDE residual combines stages.
    """
    correction_param_map = {
        **_DEFAULT_STAGE_CORRECTION_PARAM_MAP,
        **({} if correction_param_map is None else correction_param_map),
    }

    params = _trainable_params_or_none(params)
    if params is None:
        return None

    corrections = {}
    for key, val in params.items():
        if val is None:
            continue
        if key not in correction_param_map and key.startswith(
            _TRANSFORMED_PARAM_PREFIXES
        ):
            raise ValueError(
                f"Parameter '{key}' looks transformed, but no stage correction "
                "initializer was provided for it. Pass correction_param_map to "
                "prescribe the neutral next-stage parameter."
            )
        correction_key, correction_val = _stage_correction_entry(
            key, val, correction_param_map
        )
        if correction_key in corrections:
            raise ValueError(
                "Multiple trainable parameters initialize the same correction "
                f"parameter '{correction_key}'. Check the stage correction map."
            )
        corrections[correction_key] = correction_val

    return _ParamContainer(corrections) if corrections else None


def _feature_scale_from_frequency(kappa, in_size, feature_map="separable"):
    """Convert target angular frequency to an input scale for ``eqx.nn.Linear``.

    Equinox initializes ``Linear(in_size, out_size)`` weights uniformly on
    ``[-1 / sqrt(in_size), 1 / sqrt(in_size)]``, so each first-layer weight has
    RMS magnitude ``1 / sqrt(3 * in_size)``. Separable features mask each row to
    one coordinate, so the masked component needs the full ``sqrt(3 * in_size)``
    compensation. Dense random features use all coordinates in each row; using
    ``sqrt(3)`` keeps an isotropic random wave-vector's RMS norm at ``kappa``
    instead of overscaling it by ``sqrt(in_size)``.
    """
    kappa = jnp.asarray(kappa)
    if feature_map == "separable":
        return kappa * jnp.sqrt(3.0 * in_size)
    if feature_map == "random":
        return kappa * jnp.sqrt(3.0)
    raise ValueError("feature_map must be 'separable' or 'random'.")


def _feature_mask(width_size, in_size, feature_map):
    """Return a first-layer mask for the requested Fourier feature geometry."""
    if feature_map == "random":
        return jnp.ones((width_size, in_size))
    if feature_map == "separable":
        axis = jnp.arange(width_size) % in_size
        return jax.nn.one_hot(axis, in_size)
    raise ValueError("feature_map must be 'separable' or 'random'.")


def _safe_loss_ref(loss_ref):
    """Return a positive finite scalar suitable for loss normalization."""
    loss_ref = jnp.asarray(loss_ref)
    return jnp.where(
        jnp.isfinite(loss_ref) & (loss_ref > 0),
        loss_ref,
        jnp.ones((), dtype=loss_ref.dtype),
    )


class Stage1(eqx.Module):
    """First stage PINN solver.

    Examples
    --------
      * See ``tests/test_burgers.py``.

    Parameters
    ----------
    lb : jax.Array
        Lower bounds of the domain [x1_min, ..., x_i_min, ..., x_n_min].
    ub : jax.Array
        Upper bounds of the domain [x1_max, ..., x_i_max, ..., x_n_max].
    in_size : int
        Number of dimensions of input.
        The input should to the network should be ``in_size`` arguments.
    out_size : int
        The output should have shape (out_size, )
    width_size : int
        Size of each hidden layer.
    depth : int
        The number of hidden layers, including the output layer.
    activation : callable
        The activation function after each hidden layer.
        Default is ``jnp.tanh``.
    params : dict[str, jax.Array]
        Dictionary of parameters to learn and initial guesses.
        E.g. for Burgers:
        {
            "lambda_1": jax.random.normal(l1_key, (1,)) * 0.1,
            "log_lambda_2": -6.0 + jax.random.normal(l2_key, (1,)) * 0.1,
        }
    params_are_trainable : bool
        Whether the ``params`` values should be frozen or an optimizable quantity.
        Default is False for frozen.
    key : float
        Key for reproducibility.
    kwargs : dict
        Keyword arguments to ``equinox.nn.MLP``.

    """

    _lb: jax.Array
    _ub: jax.Array
    _params: _ParamContainer
    _mlp: eqx.nn.MLP

    def __init__(
        self,
        lb,
        ub,
        in_size,
        out_size,
        width_size=20,
        depth=4,
        activation=jnp.tanh,
        params=None,
        params_are_trainable=False,
        key=None,
        **kwargs,
    ):
        if key is None:
            key = jax.random.PRNGKey(42)

        self._lb = non_trainable(lb)
        self._ub = non_trainable(ub)
        self._mlp = eqx.nn.MLP(
            in_size=in_size,
            out_size=out_size,
            width_size=width_size,
            depth=depth,
            activation=activation,
            key=key,
            **kwargs,
        )
        self._params = _coerce_params(params, params_are_trainable)

    @property
    def params(self):
        """Params for this stage."""
        return unwrap(self._params)

    @property
    def lb(self):
        """Lower bound of input coordinates."""
        return unwrap(self._lb)

    @property
    def ub(self):
        """Upper bound of input coordinates."""
        return unwrap(self._ub)

    @property
    def in_size(self):
        """Number of input dimensions."""
        return self._mlp.in_size

    @property
    def out_size(self):
        """Number of output dimensions."""
        return self._mlp.out_size

    @property
    def epsilon(self):
        """Estimated magnitude scale of output."""
        return 1.0

    @property
    def kappa(self):
        """Estimated dominant frequency of output."""
        return jnp.ones(self._mlp.in_size)

    def __call__(self, *args):
        """Compute the output of this network.

        Parameters
        ----------
        args : tuple[jnp.ndarray]
            Input coordinates, e.g. (x, t) for 2D problem.

        """
        x = rescale(jnp.stack(args), self.lb, self.ub)
        x = self._mlp(x)
        if self.out_size == 1:
            x = x.squeeze(0)
        return x

    def get_param(self, key, default=None):
        """Return ``self.params["key"]`` if it exists and is not None else default."""
        val = self.params.get(key, default)
        return default if val is None else val

    def print_params(self):
        """Print the params of this network."""
        print(f"    Stage 1 params: {self.params}")

    def print_frozen_params(self):
        """Print the frozen parameters of this network."""
        pass


class Stage2(eqx.Module):
    """Initializes the Stage 2 PINN model.

    Examples
    --------
      * See ``tests/test_burgers.py``.

    Parameters
    ----------
    s1 : Stage1
        The frozen model from stage 1.
    epsilon : float
        Approximate magnitude of output.
    kappa : jax.Array
        Approximate angular frequency of this stage's output in normalized
        coordinates. For ``feature_map="separable"``, each entry is the target
        frequency for one input direction. For ``feature_map="random"``, the
        vector gives anisotropic component scales; if all entries are equal,
        the random wave-vector RMS norm matches that common value.
        Shape ``(s1.in_size,)``.
    width_size : int
        Size of each hidden layer.
    depth : int
        The number of hidden layers, including the output layer.
    activation : callable
        The activation function for each hidden layer after the first.
        Default is ``jnp.tanh``.
    params : dict[str, jax.Array]
        Dictionary of parameter corrections to learn and initial guesses. The
        automatic multistage constructors initialize corrections so that the
        total PDE parameters are unchanged at stage creation. Manual transformed
        parameters are allowed, but must be initialized in their transformed
        coordinates.
        E.g. for Burgers:
        {
            "lambda_1": jax.random.normal(l1_key, (1,)) * 0.1,
            "log_lambda_2": jnp.log(0.5),
        }
    params_are_trainable : bool
        Whether the ``params`` values should be frozen or an optimizable quantity.
        Default is False for frozen.
    key : float
        Key for reproducibility.
    chebyshev : bool
        Whether the frequency ``kappa`` is associated with a Chebyshev feature
        mapping instead of Fourier. Default is False.
    feature_map : {"separable", "random"}
        First-layer Fourier feature geometry. ``"separable"`` assigns each
        sinusoidal feature to one input coordinate; ``"random"`` preserves the
        original dense random plane-wave mapping and interprets ``kappa`` as an
        isotropic wave-vector norm when all entries are equal.
    kwargs : dict
        Keyword arguments to ``equinox.nn.MLP``.

    """

    _s1: Stage1
    _epsilon: float
    _kappa: jax.Array
    _params: _ParamContainer
    _first: eqx.nn.Linear
    _mlp: eqx.nn.MLP
    _chebyshev: bool
    _feature_map: str
    _feature_mask: jax.Array

    def __init__(
        self,
        s1,
        epsilon,
        kappa,
        width_size=20,
        depth=4,
        activation=jnp.tanh,
        params=None,
        params_are_trainable=False,
        key=None,
        *,
        chebyshev=False,
        feature_map="separable",
        **kwargs,
    ):
        s1 = non_trainable(s1)
        self._s1 = s1
        self._epsilon = non_trainable(epsilon)
        self._kappa = non_trainable(jnp.asarray(kappa))
        self._chebyshev = chebyshev
        self._feature_map = feature_map
        self._feature_mask = non_trainable(
            _feature_mask(width_size, s1.in_size, feature_map)
        )
        if chebyshev:
            warnings.warn("Chebyshev setting is experimental.")

        if key is None:
            key = jax.random.PRNGKey(42)
        key1, key2 = jax.random.split(key, 2)

        self._first = eqx.nn.Linear(s1.in_size, width_size, key=key1)
        self._mlp = eqx.nn.MLP(
            in_size=width_size,
            out_size=s1.out_size,
            width_size=width_size,
            depth=depth - 1,
            activation=activation,
            key=key2,
            **kwargs,
        )
        self._params = _coerce_params(params, params_are_trainable)

    @property
    def s1(self):
        """Returns the previous stage network."""
        return unwrap(self._s1)

    @property
    def epsilon(self):
        """Estimated magnitude scale of output for this stage."""
        return unwrap(self._epsilon)

    @property
    def kappa(self):
        """Estimated dominant frequency of output for this stage."""
        return unwrap(self._kappa)

    @property
    def params(self):
        """Params for this stage."""
        return unwrap(self._params)

    @property
    def in_size(self):
        """Number of input dimensions."""
        return self.s1.in_size

    @property
    def out_size(self):
        """Number of output dimensions."""
        return self._mlp.out_size

    @property
    def lb(self):
        """Lower bound of input coordinates."""
        return self.s1.lb

    @property
    def ub(self):
        """Upper bound of input coordinates."""
        return self.s1.ub

    def __call__(self, *args):
        """Compute the output of this network.

        output = last stage + epsilon * this stage

        Parameters
        ----------
        args : tuple[jnp.ndarray]
            Input coordinates, e.g. (x, t) for 2D problem.

        """
        return self.s1(*args) + self.epsilon * self.compute_s2(*args)

    def compute_s2(self, *args):
        """Compute just this stage of the output."""
        x = rescale(jnp.stack(args), self.lb, self.ub)
        feature_scale = _feature_scale_from_frequency(
            self.kappa, self.in_size, self._feature_map
        )
        weight = self._first.weight * unwrap(self._feature_mask)
        bias = 0 if self._first.bias is None else self._first.bias

        if self._chebyshev:
            # Ensure x ∈ (-1, 1), i.e. where arccos is differentiable.
            eps = 1 - 1e2 * jnp.finfo(jnp.array(1.0).dtype).eps
            x = jnp.clip(x, -eps, eps)
            x = jnp.cos(weight @ (feature_scale * jnp.arccos(x)) + bias)
        else:
            x = jnp.sin(weight @ (feature_scale * x) + bias)
        x = self._mlp(x)

        if self.out_size == 1:
            x = x.squeeze(0)

        return x

    def get_param(self, key, default=None):
        """Return ``self.params["key"]`` if it exists and is not None else default."""
        val = self.params.get(key, default)
        return default if val is None else val

    def print_params(self):
        """Print the params of this network."""
        print(f"    Current params: {self.params}")

    def print_frozen_params(self):
        """Print the frozen parameters of this network."""
        print(
            f"    Current value for (epsilon, kappa) = ({self.epsilon}, {self.kappa})."
        )
        self.s1.print_params()


def _is_multiple_or_last(step, multiple, last):
    if multiple <= 0:
        return step == (last - 1)
    return ((step % multiple) == 0) or (step == (last - 1))


def _is_completed_multiple_or_last(step, multiple, last):
    if multiple <= 0:
        return step == (last - 1)
    return (((step + 1) % multiple) == 0) or (step == (last - 1))


def _fill_lask_k_buffer(last_k_loss, loss_history):
    n_restore = min(loss_history.size, last_k_loss.size)
    if n_restore > 0:
        steps = np.arange(loss_history.size - n_restore, loss_history.size)
        last_k_loss[steps % last_k_loss.size] = loss_history[-n_restore:]
    return last_k_loss


def _restore_train_checkpoint(
    manager,
    step,
    trainable,
    opt_state,
    return_loss_history,
    loss_ref,
):
    """Restore an optimizer checkpoint, allowing older files without loss_ref."""
    last_error = None
    history_sizes = [step + 1, step + 2] if return_loss_history else [None]
    for include_loss_ref in (True, False):
        for history_size in history_sizes:
            restored = {"trainable": trainable, "opt_state": opt_state}
            if include_loss_ref:
                restored["loss_ref"] = loss_ref
            if return_loss_history:
                restored["loss_history"] = jnp.zeros(history_size)
            try:
                restored = manager.restore(
                    step, args=ocp.args.StandardRestore(restored)
                )
            except ValueError as err:
                last_error = err
                continue
            return restored, include_loss_ref
    raise last_error


def _restore_trust_region_checkpoint(manager, step, trainable, loss_ref):
    """Restore a trust-region checkpoint, allowing older files without loss_ref."""
    last_error = None
    for include_loss_ref in (True, False):
        restored = {"trainable": trainable}
        if include_loss_ref:
            restored["loss_ref"] = loss_ref
        try:
            restored = manager.restore(step, args=ocp.args.StandardRestore(restored))
        except ValueError as err:
            last_error = err
            continue
        return restored, include_loss_ref
    raise last_error


def _train(  # noqa: C901
    net,
    loss_fun,
    x,
    training_samples,
    optimizer,
    steps,
    *,
    learning_rate,
    adaptive_sampler=None,
    adaptive_sample_freq=1000,
    # progress & reproducibility params
    return_loss_history=True,
    print_every=100,
    checkpoint_path=None,
    checkpoint_every=5000,
    callback=None,
    callback_every=1000,
    key=None,
    debug=False,
    normalize_loss=True,
):
    """Optimize using gradient-based optimization.

    Parameters
    ----------
    net : eqx.Module
        The model to train.
    loss_fun : callable
        Function computing scalar loss with signature ``loss(net,*args)``.
    x : tuple or list of jax.Array
        Input coordinates passed to the loss function.
    training_samples : jax.Array
        Target values for training.
    optimizer : optax.GradientTransformation
        Optax optimizer.
    steps : int
        Total number of training steps.
    learning_rate : float
        Learning rate passed to the optimizer.
    adaptive_sampler : callable, optional
        Function to generate new collocation points.
    adaptive_sample_freq : int, optional
        Frequency of resampling collocation points.
    return_loss_history : bool, optional
        If True, returns the loss history alongside the model.
    print_every : int, optional
        Logging frequency.
    checkpoint_path : str, optional
        Path for saving/restoring checkpoints.
    checkpoint_every : int, optional
        Frequency of checkpoints.
    callback : callable, optional
        Function called every ``callback_every`` steps
        with signature ``callback(net,step)``.
    callback_every : int, optional
        Frequency of callback execution.
    key : jax.random.PRNGKey, optional
        Random key for sampling.
    debug : bool, optional
        Whether to print additional details for testing and debugging.
    normalize_loss : bool, optional
        If True, divide this stage's objective by its initial value. This keeps
        later small-amplitude correction stages on a comparable optimizer scale.

    Returns
    -------
    net : eqx.Module
        The trained model.
    loss_history : list of float, optional
        List of loss values per step
        (returned only if ``return_loss_history`` is True).

    """
    is_lbfgs = optimizer == optax.lbfgs
    trainable, frozen, static = partition(net)
    optimizer = optimizer(learning_rate)
    opt_state = optimizer.init(trainable)

    loss_history = []
    print_window = max(print_every, 1)
    last_k_loss = np.zeros(print_window)
    loss_ref = jnp.asarray(1.0)
    loss_ref_restored = False

    manager = None
    start_step = 0
    if checkpoint_path and checkpoint_every > 0:
        manager = checkpoint_manager(checkpoint_path)

        if manager.latest_step() is not None:
            start_step = manager.latest_step()
            print(f"\n=== Resuming training from step {start_step} ===")
            restored, loss_ref_restored = _restore_train_checkpoint(
                manager,
                start_step,
                trainable,
                opt_state,
                return_loss_history,
                loss_ref,
            )

            trainable = restored["trainable"]
            opt_state = restored["opt_state"]
            loss_ref = restored.get("loss_ref", loss_ref)
            net = eqx.combine(trainable, frozen, static)

            if return_loss_history:
                loss_history = np.array(restored["loss_history"])
                last_k_loss = _fill_lask_k_buffer(last_k_loss, loss_history)
                loss_history = list(loss_history)

            start_step += 1

    if debug:
        print("\n-----   Static  -----")
        print(static)
        print("\n----- Trainable -----")
        print(trainable)
        print("\n-----   Frozen  -----")
        print(frozen)
        print("\n----- Recombine -----")
        print(eqx.combine(trainable, frozen, static))

    def raw_loss(trainable, frozen, static, *args):
        net = eqx.combine(trainable, frozen, static)
        return loss_fun(net, *args)

    def loss(trainable, frozen, static, loss_ref, *args):
        return raw_loss(trainable, frozen, static, *args) / loss_ref

    @partial(jit, static_argnames=["static"])
    def make_step(trainable, frozen, static, opt_state, loss_ref, *args):
        loss_value, grads = value_and_grad(loss)(
            trainable, frozen, static, loss_ref, *args
        )
        if is_lbfgs:

            def loss_lbfgs(trainable):
                return loss(trainable, frozen, static, loss_ref, *args)

            updates, opt_state = optimizer.update(
                grads,
                opt_state,
                trainable,
                value=loss_value,
                grad=grads,
                value_fn=loss_lbfgs,
            )
        else:
            updates, opt_state = optimizer.update(grads, opt_state, trainable)
        trainable = eqx.apply_updates(trainable, updates)
        return trainable, opt_state, loss_value

    print(f"--- Values at step {start_step} ---")
    net.print_params()
    if debug:
        net.print_frozen_params()

    print("--- Starting training ---")
    start_train_time = time.time()

    x_col = [None] * net.in_size
    if (
        (adaptive_sampler is not None)
        and (adaptive_sample_freq > 0)
        and (start_step < steps)
    ):
        print(f"Resampled at step {start_step}.")
        x_col, key = adaptive_sampler(eqx.combine(trainable, frozen, static), key=key)

    if not normalize_loss:
        loss_ref = jnp.asarray(1.0)
    elif loss_ref_restored:
        print(f"Restored loss normalization scale: {loss_ref:.6e}.")
    elif start_step < steps:
        loss_ref = _safe_loss_ref(
            raw_loss(trainable, frozen, static, *x, training_samples, *x_col)
        )
        print(f"Initial loss normalization scale: {loss_ref:.6e}.")

    for step in range(start_step, steps):
        if (
            (adaptive_sampler is not None)
            and (adaptive_sample_freq > 0)
            and (step > start_step)
            and (step % adaptive_sample_freq == 0)
        ):
            print(f"Resampled at step {step}.")
            x_col, key = adaptive_sampler(
                eqx.combine(trainable, frozen, static), key=key
            )

        trainable, opt_state, loss_value = make_step(
            trainable,
            frozen,
            static,
            opt_state,
            loss_ref,
            *x,
            training_samples,
            *x_col,
        )

        if return_loss_history:
            loss_history.append(loss_value)

        last_k_loss[step % print_window] = loss_value
        if _is_multiple_or_last(step, print_every, steps):
            last_k = loss_value if (step == 0) else last_k_loss.mean()
            loss_window_name = print_every if print_every > 0 else print_window
            print(
                f"Step {step}, Loss: {loss_value:.6e}, "
                f"Last {loss_window_name} mean loss: {last_k}.",
                flush=True,
            )
            net = eqx.combine(trainable, frozen, static)
            net.print_params()
            if debug:
                net.print_frozen_params()

        if (
            manager
            and (checkpoint_every > 0)
            and _is_completed_multiple_or_last(step, checkpoint_every, steps)
        ):
            man_args = {
                "trainable": trainable,
                "opt_state": opt_state,
                "loss_ref": loss_ref,
            }
            if len(loss_history):
                man_args["loss_history"] = jnp.asarray(loss_history)
            manager.save(step, args=ocp.args.StandardSave(man_args))

        if callback and _is_multiple_or_last(step, callback_every, steps):
            current_net = eqx.combine(trainable, frozen, static)
            callback(current_net, step)

    end_train_time = time.time()
    print("--- Finished training ---\n")
    print(f"Training time: {end_train_time - start_train_time:.2f}")

    if manager:
        manager.wait_until_finished()
        manager.close()

    net = eqx.combine(trainable, frozen, static)
    return (net, loss_history) if return_loss_history else net


def _trust_region_train(  # noqa: C901
    net,
    loss_fun_unreduced,
    x,
    training_samples,
    steps,
    *,
    rtol,
    atol,
    linear_solver,
    adaptive_sampler=None,
    adaptive_sample_freq=100,
    # progress & reproducibility params
    checkpoint_path=None,
    checkpoint_every=100,
    callback=None,
    callback_every=100,
    key=None,
    normalize_loss=True,
):
    """Optimize using a Levenberg-Marquardt nonlinear least squares solver.

    Parameters
    ----------
    net : eqx.Module
        The model to train.
    loss_fun_unreduced : callable
        Function returning a residual vector for least squares.
    x : tuple or list of jax.Array
        Input coordinates passed to the loss function.
    training_samples : jax.Array
        Target values.
    steps : int
        Maximum number of solver steps.
    rtol : float
        Relative tolerance for the solver.
    atol : float
        Absolute tolerance for the solver.
    linear_solver : lineax.AbstractLinearSolver
        The linear solver used to compute the Gauss-Newton step.
    adaptive_sampler : callable, optional
        Function to generate new collocation points.
    adaptive_sample_freq : int, optional
        Frequency of resampling collocation points.
    checkpoint_path : str, optional
        Path for saving/restoring checkpoints.
    checkpoint_every : int, optional
        Frequency of checkpoints.
    callback : callable, optional
        Function called every ``callback_every`` steps
        with signature ``callback(net,step)``.
    callback_every : int, optional
        Frequency of callback execution.
    key : jax.random.PRNGKey, optional
        Random key for sampling.
    normalize_loss : bool, optional
        If True, scale the residual vector by the square root of its initial
        least-squares objective for this stage.

    Returns
    -------
    net : eqx.Module
        The trained model.

    """
    trainable, frozen, static = partition(net)
    loss_ref = jnp.asarray(1.0)
    loss_ref_restored = False
    solver = optimistix.LevenbergMarquardt(
        rtol=rtol,
        atol=atol,
        verbose=False,
        linear_solver=linear_solver,
    )

    manager = None
    start_step = 0
    if checkpoint_path and checkpoint_every > 0:
        manager = checkpoint_manager(checkpoint_path)

        if manager.latest_step() is not None:
            start_step = manager.latest_step()
            print(f"\n=== Resuming training from step {start_step} ===")
            restored, loss_ref_restored = _restore_trust_region_checkpoint(
                manager, start_step, trainable, loss_ref
            )
            trainable = restored["trainable"]
            loss_ref = restored.get("loss_ref", loss_ref)
            net = eqx.combine(trainable, frozen, static)

    def raw_loss(trainable, args):
        frozen, static, *rest = args
        net = eqx.combine(trainable, frozen, static)
        return loss_fun_unreduced(net, *rest)

    def loss(trainable, args):
        loss_ref, frozen, static, *rest = args
        raw_residual = raw_loss(trainable, (frozen, static, *rest))
        return raw_residual / jnp.sqrt(loss_ref)

    print(f"--- Values at step {start_step} ---")
    net.print_params()

    print("--- Starting training ---")
    start_train_time = time.time()

    x_col = [None] * net.in_size
    if start_step >= steps:
        end_train_time = time.time()
        print("--- Finished training ---\n")
        print(f"Training time: {end_train_time - start_train_time:.2f}")
        if manager:
            manager.wait_until_finished()
            manager.close()
        return net

    step_frequencies = [steps]
    if adaptive_sampler is not None and adaptive_sample_freq > 0:
        step_frequencies.append(adaptive_sample_freq)
    if checkpoint_every > 0:
        step_frequencies.append(checkpoint_every)
    step_per_opt = min(step_frequencies)
    for step in range(start_step, steps, step_per_opt):
        steps_this_chunk = min(step_per_opt, steps - step)
        if (
            (adaptive_sampler is not None)
            and (adaptive_sample_freq > 0)
            and (
                step == start_step
                or step // adaptive_sample_freq
                > (step - step_per_opt) // adaptive_sample_freq
            )
        ):
            print(f"Resampled at step {step}.")
            x_col, key = adaptive_sampler(
                eqx.combine(trainable, frozen, static), key=key
            )

        if not normalize_loss:
            loss_ref = jnp.asarray(1.0)
        elif loss_ref_restored and (step == start_step):
            print(f"Restored loss normalization scale: {loss_ref:.6e}.")
        elif step == start_step:
            initial_residual = raw_loss(
                trainable, (frozen, static, *x, training_samples, *x_col)
            )
            loss_ref = _safe_loss_ref(jnp.sum(initial_residual**2))
            print(f"Initial loss normalization scale: {loss_ref:.6e}.")

        sol = optimistix.least_squares(
            loss,
            solver,
            trainable,
            args=(loss_ref, frozen, static, *x, training_samples, *x_col),
            max_steps=steps_this_chunk,
            throw=False,
        )
        trainable = sol.value
        print(optimistix.RESULTS[sol.result])
        # can't extract loss history programmatically from optimistix solver:
        #    https://github.com/patrick-kidger/optimistix/issues/52

        net = eqx.combine(trainable, frozen, static)
        net.print_params()

        current_step = step + steps_this_chunk
        if (
            manager
            and (checkpoint_every > 0)
            and (
                (current_step // checkpoint_every > step // checkpoint_every)
                or (current_step == steps)
            )
        ):
            manager.save(
                current_step,
                args=ocp.args.StandardSave(
                    {"trainable": trainable, "loss_ref": loss_ref}
                ),
            )

        if (
            callback
            and (callback_every > 0)
            and (
                (current_step // callback_every > step // callback_every)
                or (current_step == steps)
            )
        ):
            current_net = eqx.combine(trainable, frozen, static)
            callback(current_net, current_step)

    end_train_time = time.time()
    print("--- Finished training ---\n")
    print(f"Training time: {end_train_time - start_train_time:.2f}")

    if manager:
        manager.wait_until_finished()
        manager.close()

    net = eqx.combine(trainable, frozen, static)
    return net


def multistage_train(
    net,
    residual_fun_s1,
    residual_fun_s2,
    loss_fun_s1,
    loss_fun_s2,
    x,
    training_samples,
    optimizer,
    steps,
    *,
    learning_rate=None,
    adaptive_sample_freq=1000,
    n_stages=2,
    width_size=20,
    depth=4,
    activation=jnp.tanh,
    num_samples_for_epsilon=(1024,),
    order=(1,),
    beta_fun=None,
    heuristic=0.9,
    frequency_estimator="spectral",
    chebyshev=False,
    feature_map="separable",
    stage_correction_param_map=None,
    x_stage2=None,
    training_samples_stage2=None,
    # progress & reproducibility params
    return_loss_history=True,
    print_every=100,
    key=None,
    net_kwargs_for_save=None,
    name="",
    checkpoint_dir="checkpoints",
    checkpoint_every=5000,
    benchmark_state=None,
    normalize_loss=True,
    **adaptive_sample_kwargs,
):
    """Multi-stage training.

    Examples
    --------
      * See ``tests/test_burgers.py``.

    Parameters
    ----------
    net : eqx.Module
        The initial model architecture.
    residual_fun_s1 : callable
        Function to compute PDE residuals for the first stage.
    residual_fun_s2 : callable
        Function to compute PDE residuals for subsequent stages.
    loss_fun_s1 : callable
        Scalar output loss function for the first stage.
    loss_fun_s2 : callable
        Scalar output loss function for subsequent stages.
    x : tuple or list of jax.Array
        Input coordinates for the first stage.
    training_samples : jax.Array
        Target values for the first stage.
    optimizer : optax.GradientTransformation
        Optimizer for training loops.
    steps : int
        Number of training steps per stage.
    learning_rate : float, optional
        Learning rate passed to the optimizer.
    adaptive_sample_freq : int, optional
        Frequency of adaptive sampling during training.
    n_stages : int, optional
        Total number of training stages. Default is 2.
    width_size : int, optional
        Width of the sub-networks added in later stages.
    depth : int, optional
        Depth of the sub-networks added in later stages.
    activation : callable, optional
        Activation function for new stages. Default is ``jnp.tanh``.
    num_samples_for_epsilon : tuple, optional
        Number of samples used to estimate error statistics between stages.
    order : tuple, optional
        Derivative orders used for error estimation. A 1D tuple is interpreted
        as separate operator terms in each input direction; pass nested
        multi-indices for mixed derivative terms.
    beta_fun : callable, optional
        Function defining scalar or per-operator-term coefficients for the
        error estimate.
    heuristic : float, optional
        Heuristic multiplier for error estimation. Default is 0.9.
        Used only when ``frequency_estimator="zero_crossing"``.
    frequency_estimator : {"spectral", "zero_crossing"}
        Fourier residual frequency estimator used between stages.
    chebyshev : bool
        Whether to use Chebyshev feature mapping instead of Fourier.
        If given, ``heuristic`` is ignored.
    feature_map : {"separable", "random"}
        First-layer feature geometry for new stages. ``"separable"`` is the
        default; ``"random"`` preserves the previous dense plane-wave mapping.
    stage_correction_param_map : dict, optional
        Mapping from current-stage parameter names to next-stage correction
        names or initializers. Custom entries extend the built-in defaults,
        including ``{"log_lambda_2": "lambda_2"}`` for Burgers-style signed
        physical diffusion corrections.
    x_stage2 : tuple of jax.Array, optional
        Input coordinates for stage 2 and beyond. Default is ``x``.
    training_samples_stage2 : jax.Array, optional
        Training data for stage 2 and beyond. Default is ``training_samples``.
    return_loss_history : bool, optional
        If True, returns loss histories for all stages.
    print_every : int, optional
        Logging frequency.
    key : jax.random.PRNGKey, optional
        Random key for initialization and sampling.
    net_kwargs_for_save : dict, optional
        Additional metadata to save with the model.
    name : str, optional
        Base name for saving models and checkpoints.
    checkpoint_dir : str, optional
        Directory to store stage-specific checkpoints.
    checkpoint_every : int, optional
        Frequency of checkpointing within stages.
    benchmark_state : callable, optional
        Callback for external benchmarking or logging. Signature:
        ``benchmark_state(net,stage,name,step=step)``.
    normalize_loss : bool, optional
        Whether to normalize each stage's objective by its initial value.

    Returns
    -------
    net : eqx.Module
        The final trained multi-stage model.
    loss_histories : list of list of float, optional
        A list containing the loss history for each stage
        (if `return_loss_history`` is True).

    """
    if key is None:
        key = jax.random.PRNGKey(42)
    if net_kwargs_for_save is None:
        net_kwargs_for_save = {}
    if x_stage2 is None:
        x_stage2 = x
    if training_samples_stage2 is None:
        training_samples_stage2 = training_samples

    adaptive_sample_kwargs_base = dict(adaptive_sample_kwargs)

    residual_fun = residual_fun_s1
    loss_fun = loss_fun_s1
    loss_histories = []

    for stage in range(n_stages):
        current_callback = None
        if benchmark_state is not None:

            def current_callback(n, s):  # noqa: F811
                benchmark_state(n, stage, name, step=s)

        if adaptive_sample_freq > 0:
            stage_adaptive_sample_kwargs = dict(adaptive_sample_kwargs_base)
            stage_adaptive_sample_kwargs.setdefault("n_candidates", len(x[0]) * 10)
            stage_adaptive_sample_kwargs.setdefault("n_selected", len(x[0]) // 2)
            adaptive_sampler = partial(
                adaptive_sample,
                residual_fun=residual_fun,
                in_size=net.in_size,
                **stage_adaptive_sample_kwargs,
            )
        else:
            adaptive_sampler = None

        key, train_key = jax.random.split(key)
        net = _train(
            net=net,
            loss_fun=loss_fun,
            x=x,
            training_samples=training_samples,
            optimizer=optimizer,
            steps=steps,
            learning_rate=learning_rate,
            adaptive_sampler=adaptive_sampler,
            adaptive_sample_freq=adaptive_sample_freq,
            return_loss_history=return_loss_history,
            print_every=print_every,
            checkpoint_path=os.path.join(checkpoint_dir, f"{name}_stage_{stage}"),
            checkpoint_every=checkpoint_every,
            callback=current_callback,
            key=train_key,
            normalize_loss=normalize_loss,
        )
        if return_loss_history:
            net, loss_history = net
            loss_histories.append(loss_history)

        save(f"models/{name}_net_stage_{stage}.eqx", net, **net_kwargs_for_save)

        if benchmark_state is not None:
            benchmark_state(net, stage, name)

        if stage == (n_stages - 1):
            continue

        non_static, static = eqx.partition(net, eqx.is_inexact_array)
        eps_residual, eps_prediction, kappa = (stats_chebyshev if chebyshev else stats)(
            non_static,
            static,
            residual_fun,
            num_samples_for_epsilon,
            order,
            beta_fun,
            **(
                {}
                if chebyshev
                else {
                    "heuristic": heuristic,
                    "frequency_estimator": frequency_estimator,
                }
            ),
        )
        print(f"Stage {stage} statistics:")
        print(f"RMS residual estimate used for stage {stage +1} is {eps_residual}.")
        print(f"RMS prediction residual used for stage {stage +1} is {eps_prediction}.")
        print(f"Estimate frequency kappa used for stage {stage +1} is {kappa}.")

        params = _stage_correction_params_or_none(
            getattr(net, "_params", None), stage_correction_param_map
        )

        key, subkey = jax.random.split(key)
        net_kwargs_for_save = dict(
            epsilon=eps_prediction,
            kappa=kappa,
            width_size=width_size,
            depth=depth,
            params_are_trainable=params is not None,
            chebyshev=chebyshev,
            feature_map=feature_map,
        )
        net = Stage2(
            net, params=params, key=subkey, activation=activation, **net_kwargs_for_save
        )

        residual_fun = residual_fun_s2
        loss_fun = loss_fun_s2
        # Next stages will use same as stage 2 data currently.
        training_samples = training_samples_stage2
        x = x_stage2

    return (net, loss_histories) if return_loss_history else net


def multistage_trust_region_train(
    net,
    residual_fun_s1,
    residual_fun_s2,
    loss_fun_s1,
    loss_fun_s2,
    loss_fun_s1_unreduced,
    loss_fun_s2_unreduced,
    x,
    training_samples,
    steps,
    lbfgs_steps=1000,
    *,
    rtol=1e-7,
    atol=1e-8,
    rtol_decay_factor=0.7,
    atol_decay_factor=0.1,
    linear_solver=(lx.QR(), lx.Normal(lx.CG(rtol=1e-7, atol=1e-7))),
    learning_rate=None,
    adaptive_sample_freq=100,
    n_stages=2,
    width_size=20,
    depth=4,
    activation=jnp.tanh,
    num_samples_for_epsilon=(1024,),
    order=(1,),
    beta_fun=None,
    heuristic=0.9,
    frequency_estimator="spectral",
    chebyshev=False,
    feature_map="separable",
    stage_correction_param_map=None,
    x_stage2=None,
    training_samples_stage2=None,
    # Progress & reproducibility params
    print_every=100,
    key=None,
    net_kwargs_for_save=None,
    name="",
    checkpoint_dir="checkpoints",
    checkpoint_every=100,
    benchmark_state=None,
    normalize_loss=True,
    **adaptive_sample_kwargs,
):
    """Multi-stage training using trust region based optimization.

    Examples
    --------
      * See ``tests/test_burgers.py``.

    Parameters
    ----------
    net : eqx.Module
        The initial model architecture.
    residual_fun_s1 : callable
        Function to compute PDE residuals for the first stage.
    residual_fun_s2 : callable
        Function to compute PDE residuals for subsequent stages.
    loss_fun_s1 : callable
        Scalar output loss function for the first stage.
    loss_fun_s2 : callable
        Scalar output loss function for subsequent stages.
    loss_fun_s1_unreduced : callable
        Unreduced loss function for the first stage.
    loss_fun_s2_unreduced : callable
        Unreduced loss function for subsequent stages.
    x : tuple or list of jax.Array
        Input coordinates passed to the residual function for the first stage.
    training_samples : jax.Array
        Target values for the first stage.
    steps : int
        Maximum number of solver steps per stage.
    lbfgs_steps : int
        Number of steps to use LBFGS prior to trust region approach.
        Default is 1000.
    rtol : float
        Relative tolerance for the Levenberg-Marquardt solver for the first stage.
    atol : float
        Absolute tolerance for the Levenberg-Marquardt solver for the first stage.
    rtol_decay_factor : float
        Decay factor for ``rtol`` in subsequent stages.
        Default of ``0.7`` means the next stage will have ``new_rtol=rtol*0.7``.
    atol_decay_factor : float
        Decay factor for ``atol`` in subsequent stages.
        Default of ``0.1`` means the next stage will have ``new_atol=atol*0.1``.
    linear_solver : tuple[lineax.AbstractLinearSolver]
        The linear solver used to compute the Gauss-Newton step.
        Default is QR for first stage and conjugate gradient on the normal
        equations for following stages.
    learning_rate : float, optional
        Learning rate passed to the LBFGS warmup optimizer. The
        Levenberg-Marquardt phase is controlled by ``rtol``, ``atol``, and
        ``linear_solver``.
    adaptive_sample_freq : int, optional
        Frequency of adaptive sampling during training with trust region method.
        Default is 100. LBFGS warmup steps will adaptive sample with
        10 times less frequency.
    n_stages : int, optional
        Total number of training stages. Default is 2.
    width_size : int, optional
        Width of the sub-networks added in later stages.
    depth : int, optional
        Depth of the sub-networks added in later stages.
    activation : callable, optional
        Activation function for new stages. Default is ``jnp.tanh``.
    num_samples_for_epsilon : tuple, optional
        Number of samples used to estimate error statistics between stages.
    order : tuple, optional
        Derivative orders used for error estimation. A 1D tuple is interpreted
        as separate operator terms in each input direction; pass nested
        multi-indices for mixed derivative terms.
    beta_fun : callable, optional
        Function defining scalar or per-operator-term coefficients for the
        error estimate.
    heuristic : float, optional
        Heuristic multiplier for error estimation. Default is 0.9.
        Used only when ``frequency_estimator="zero_crossing"``.
    frequency_estimator : {"spectral", "zero_crossing"}
        Fourier residual frequency estimator used between stages.
    chebyshev : bool
        Whether to use Chebyshev feature mapping instead of Fourier.
        If given, ``heuristic`` is ignored.
    feature_map : {"separable", "random"}
        First-layer feature geometry for new stages. ``"separable"`` is the
        default; ``"random"`` preserves the previous dense plane-wave mapping.
    stage_correction_param_map : dict, optional
        Mapping from current-stage parameter names to next-stage correction
        names or initializers. Custom entries extend the built-in defaults,
        including ``{"log_lambda_2": "lambda_2"}`` for Burgers-style signed
        physical diffusion corrections.
    x_stage2 : tuple of jax.Array, optional
        Input coordinates for stage 2 and beyond. Default is ``x``.
    training_samples_stage2 : jax.Array, optional
        Training data for stage 2 and beyond. Default is ``training_samples``.
    print_every : int, optional
        Logging frequency.
    key : jax.random.PRNGKey, optional
        Random key for initialization and sampling.
    net_kwargs_for_save : dict, optional
        Additional metadata to save with the model.
    name : str, optional
        Base name for saving models and checkpoints.
    checkpoint_dir : str, optional
        Directory to store stage-specific checkpoints.
    checkpoint_every : int, optional
        Frequency of checkpointing within stages. Default is 100.
        LBFGS warmup steps will checkpoint with 10 times less frequency.
    benchmark_state : callable, optional
        Callback for external benchmarking or logging. Signature:
        ``benchmark_state(net,stage,name,step=step)``.
    normalize_loss : bool, optional
        Whether to normalize each stage's objective by its initial value.

    Returns
    -------
    net : eqx.Module
        The final trained multi-stage model.

    """
    if key is None:
        key = jax.random.PRNGKey(42)
    if net_kwargs_for_save is None:
        net_kwargs_for_save = {}
    if x_stage2 is None:
        x_stage2 = x
    if training_samples_stage2 is None:
        training_samples_stage2 = training_samples

    adaptive_sample_kwargs_base = dict(adaptive_sample_kwargs)

    residual_fun = residual_fun_s1
    loss_fun = loss_fun_s1
    loss_fun_unreduced = loss_fun_s1_unreduced
    linear_solver, linear_solver_next = linear_solver

    for stage in range(n_stages):
        current_callback = None
        if benchmark_state is not None:

            def current_callback(n, s):  # noqa: F811
                benchmark_state(n, stage, name, step=s)

        if adaptive_sample_freq > 0:
            stage_adaptive_sample_kwargs = dict(adaptive_sample_kwargs_base)
            stage_adaptive_sample_kwargs.setdefault("n_candidates", len(x[0]) * 10)
            stage_adaptive_sample_kwargs.setdefault("n_selected", len(x[0]) // 2)
            adaptive_sampler = partial(
                adaptive_sample,
                residual_fun=residual_fun,
                in_size=net.in_size,
                **stage_adaptive_sample_kwargs,
            )
        else:
            adaptive_sampler = None

        key, train_key = jax.random.split(key)
        net, _ = _train(
            net=net,
            loss_fun=loss_fun,
            x=x,
            training_samples=training_samples,
            optimizer=optax.lbfgs,
            steps=lbfgs_steps,
            learning_rate=learning_rate,
            adaptive_sampler=adaptive_sampler,
            adaptive_sample_freq=adaptive_sample_freq * 10,
            return_loss_history=True,
            print_every=print_every,
            checkpoint_path=os.path.join(
                checkpoint_dir, f"{name}_lbfgs_warmup_stage_{stage}"
            ),
            checkpoint_every=checkpoint_every * 10,
            callback=current_callback,
            key=train_key,
            normalize_loss=normalize_loss,
        )

        key, train_key = jax.random.split(key)
        net = _trust_region_train(
            net=net,
            loss_fun_unreduced=loss_fun_unreduced,
            x=x,
            training_samples=training_samples,
            steps=steps,
            rtol=rtol,
            atol=atol,
            linear_solver=linear_solver,
            adaptive_sampler=adaptive_sampler,
            adaptive_sample_freq=adaptive_sample_freq,
            checkpoint_path=os.path.join(checkpoint_dir, f"{name}_stage_{stage}"),
            checkpoint_every=checkpoint_every,
            callback=current_callback,
            key=train_key,
            normalize_loss=normalize_loss,
        )

        linear_solver = linear_solver_next
        loss_fun_unreduced = loss_fun_s2_unreduced
        rtol *= rtol_decay_factor
        atol *= atol_decay_factor

        save(f"models/{name}_net_stage_{stage}.eqx", net, **net_kwargs_for_save)

        if benchmark_state is not None:
            benchmark_state(net, stage, name)

        if stage == (n_stages - 1):
            continue

        non_static, static = eqx.partition(net, eqx.is_inexact_array)
        eps_residual, eps_prediction, kappa = (stats_chebyshev if chebyshev else stats)(
            non_static,
            static,
            residual_fun,
            num_samples_for_epsilon,
            order,
            beta_fun,
            **(
                {}
                if chebyshev
                else {
                    "heuristic": heuristic,
                    "frequency_estimator": frequency_estimator,
                }
            ),
        )
        print(f"Stage {stage} statistics:")
        print(f"RMS residual estimate used for stage {stage +1} is {eps_residual}.")
        print(f"RMS prediction residual used for stage {stage +1} is {eps_prediction}.")
        print(f"Estimate frequency kappa used for stage {stage +1} is {kappa}.")

        params = _stage_correction_params_or_none(
            getattr(net, "_params", None), stage_correction_param_map
        )

        key, subkey = jax.random.split(key)
        net_kwargs_for_save = dict(
            epsilon=eps_prediction,
            kappa=kappa,
            width_size=width_size,
            depth=depth,
            params_are_trainable=params is not None,
            chebyshev=chebyshev,
            feature_map=feature_map,
        )
        net = Stage2(
            net, params=params, key=subkey, activation=activation, **net_kwargs_for_save
        )

        residual_fun = residual_fun_s2
        loss_fun = loss_fun_s2
        # Next stages will use same as stage 2 data currently.
        training_samples = training_samples_stage2
        x = x_stage2

    return net
