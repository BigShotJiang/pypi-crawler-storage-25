Team
====

This is an introduction of beets' core-team members, collaborators and frequent
contributors. Refer to this list to find out who to ask about your collaboration
idea, discuss a usage-question, request a review of your open PR. Beets is a
huge project and not everyone involved, knows everything. We hope this helps to
point you in the right direction in the first place and should give you an idea
of what you can expect from these *knowledge owners*.

@arsaboo
--------

- The master of the Spotify plugin
- Testing out new contributions
- beets as a music discovery tool

@bal-e
------

- Documentation
- The Fish plugin
- Type annotations

@govynnus
---------

- The AURA plugin
- The AURA specification
- The web plugin
- The plugin ecosystem
- The library database API and its documentation

@jackwilsdon
------------

- Broad knowledge around beets' configuration and plugins
- Assists in discussion forums frequently
- Knows internals of beets and puts new contributors into the right direction

@joj0
-----

- The Discogs plugin
- Good documentation throughout the project
- The smartplaylist plugin
- The lastgenre plugin
- Support for M3U and other playlist formats
- beets as a DJ companion tool (BPM, audio features, key)

@RollingStar
------------

- Data visualization
- ListenBrainz / Last.fm
- Smart playlists
- Library reports
- MusicBrainz fields and searching
- Project organization and roadmap

@sampsyo
--------

- The founder
- Knows almost everything ;-)

@serene-arc
-----------

- Good documentation throughout the project
- Experienced Python developer
- Experienced in test-driven-development
- Code quality
- Typing

@snejus
-------

- Grug-minded approach: simple, obvious solutions over clever complexity
- MusicBrainz/autotagger internals and source-plugin behavior
- Query/path handling and SQL-backed lookup behavior
- Typing and tooling modernization (mypy, Ruff, annotations)
- Test architecture, CI reliability, and coverage improvements
- Release and packaging workflows (Poetry/pyproject, dependencies, changelog)
- Cross-plugin refactors (especially metadata and lyrics-related internals)

@wisp3rwind
-----------

- Mr. Tidy - Keeping the code in shape
- Focus on improving core things rather than implementing new features

@ybnd
-----

- The replaygain plugin
- Improving the general parallelism of plugins
- Experienced with web scrapers
- Experienced with Flask and JavaScript integration
- The web plugin
