"""Project-scoped command routing and execution."""

from .runner import run_project_command
from .subcommands import AGENTS, CLI_NAME, NAMES, WORKTREE, create_app
from .worktree import (
    WorktreeCreateResult,
    WorktreeInfo,
    create_worktree,
    find_git_root,
    list_worktrees,
    prune_worktrees,
    remove_worktree,
)

__all__ = [
    "AGENTS",
    "CLI_NAME",
    "NAMES",
    "WORKTREE",
    "WorktreeCreateResult",
    "WorktreeInfo",
    "create_app",
    "create_worktree",
    "find_git_root",
    "list_worktrees",
    "prune_worktrees",
    "remove_worktree",
    "run_project_command",
]
