from ._reduce import reduce
from .abc import is_reducable

__all__ = ("is_reducable", "reduce")
__author__ = "Vizonex"
__version__ = "0.2.2"
