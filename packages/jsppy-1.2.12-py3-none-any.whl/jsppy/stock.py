
import cmesdata as csd
from typing import List
import pandas as pd

def login(token_str):
    return csd.login(token_str)


def login_out():
    return csd.login_out()



def get_history_data(code, start_date, end_date, period, index=False):
    return csd.get_history_data(code, start_date, end_date, period, index)


def get_index_data(code, start_date, end_date, period):
    return csd.get_index_data(code, start_date, end_date, period)


def get_real_hq(all_stock):
    return csd.get_real_hq(all_stock)


def get_real_kzz(all_stock):
    return csd.get_real_kzz(all_stock)


def get_tick(code, date):
    return csd.get_tick(code, date)

# --------------------------

def subscribe_future_code(code_list):
    return csd.subscribe_future_code(code_list)


def get_real_tick(code_list: List[str], num: int = 1) -> pd.DataFrame:
    return csd.get_real_tick(code_list, num)


def get_real_min(code_list: List[str], num: int = 1) -> pd.DataFrame:
    return csd.get_real_min(code_list, num)


def get_real_day(code_list: List[str]) -> pd.DataFrame:
    return csd.get_real_day(code_list)


def register_push_callback(callback):
    return csd.register_push_callback(callback)





###########













