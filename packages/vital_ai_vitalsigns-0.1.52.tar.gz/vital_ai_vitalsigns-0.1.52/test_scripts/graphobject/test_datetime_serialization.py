#!/usr/bin/env python3
"""
Tests for datetime/timestamp serialization fidelity — verifies that
prop.get_value() (used in Phase 13 optimization) produces correct output
for Long (timestamp) and Boolean property types across serialization formats.

Covers: Phase 13 (prop.get_value() in to_json/to_dict)
"""

import json
import sys
from pathlib import Path

project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(project_root))

from vital_ai_vitalsigns.vitalsigns import VitalSigns
from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node


def _make_node_with_all_types():
    """Helper: create a VITAL_Node with string, boolean, long, and URI properties."""
    vs = VitalSigns()
    node = VITAL_Node()
    node.URI = "http://example.com/dt-test"
    node.name = "DateTime Test"
    node.active = True
    node.timestamp = 1710000000000
    node.ontologyIRI = "http://vital.ai/ontology/vital-core"
    return node


# -- to_json / from_json fidelity --

def test_json_timestamp_fidelity():
    """Timestamp (Long) value should be preserved exactly through JSON round-trip."""
    node = _make_node_with_all_types()

    json_str = node.to_json(pretty_print=False)
    data = json.loads(json_str)

    ts_uri = "http://vital.ai/ontology/vital-core#hasTimestamp"
    assert ts_uri in data
    assert data[ts_uri] == 1710000000000

    restored = VITAL_Node.from_json(json_str)
    assert restored.timestamp == 1710000000000


def test_json_boolean_fidelity():
    """Boolean value should be preserved exactly through JSON round-trip."""
    node = _make_node_with_all_types()

    json_str = node.to_json(pretty_print=False)
    data = json.loads(json_str)

    active_uri = "http://vital.ai/ontology/vital-core#isActive"
    assert active_uri in data
    assert data[active_uri] is True

    restored = VITAL_Node.from_json(json_str)
    assert restored.active == True


def test_json_string_fidelity():
    """String value should be preserved exactly through JSON round-trip."""
    node = _make_node_with_all_types()

    json_str = node.to_json(pretty_print=False)
    data = json.loads(json_str)

    name_uri = "http://vital.ai/ontology/vital-core#hasName"
    assert name_uri in data
    assert data[name_uri] == "DateTime Test"

    restored = VITAL_Node.from_json(json_str)
    assert restored.name == "DateTime Test"


def test_json_uri_property_fidelity():
    """URI property value should be preserved exactly through JSON round-trip."""
    node = _make_node_with_all_types()

    json_str = node.to_json(pretty_print=False)
    data = json.loads(json_str)

    iri_uri = "http://vital.ai/ontology/vital-core#hasOntologyIRI"
    assert iri_uri in data
    assert data[iri_uri] == "http://vital.ai/ontology/vital-core"

    restored = VITAL_Node.from_json(json_str)
    assert str(restored.ontologyIRI) == "http://vital.ai/ontology/vital-core"


# -- to_dict / from_dict fidelity --

def test_dict_all_types_fidelity():
    """All property types should be preserved through dict round-trip."""
    node = _make_node_with_all_types()

    dict_data = node.to_dict()

    ts_uri = "http://vital.ai/ontology/vital-core#hasTimestamp"
    active_uri = "http://vital.ai/ontology/vital-core#isActive"
    name_uri = "http://vital.ai/ontology/vital-core#hasName"

    assert dict_data[ts_uri] == 1710000000000
    assert dict_data[active_uri] is True
    assert dict_data[name_uri] == "DateTime Test"

    restored = VITAL_Node.from_dict(dict_data)
    assert restored.timestamp == 1710000000000
    assert restored.active == True
    assert restored.name == "DateTime Test"


# -- to_rdf / from_rdf fidelity --

def test_rdf_timestamp_fidelity():
    """Timestamp value should be preserved through RDF round-trip."""
    node = _make_node_with_all_types()

    rdf_str = node.to_rdf(format='nt')
    restored = VITAL_Node.from_rdf(rdf_str)

    assert restored.timestamp == 1710000000000


def test_rdf_boolean_fidelity():
    """Boolean value should be preserved through RDF round-trip."""
    node = _make_node_with_all_types()

    rdf_str = node.to_rdf(format='nt')
    restored = VITAL_Node.from_rdf(rdf_str)

    assert restored.active == True


def test_rdf_string_fidelity():
    """String value should be preserved through RDF round-trip."""
    node = _make_node_with_all_types()

    rdf_str = node.to_rdf(format='nt')
    restored = VITAL_Node.from_rdf(rdf_str)

    assert restored.name == "DateTime Test"


# -- Triples fidelity --

def test_triples_all_types_fidelity():
    """All property types should be preserved through triples round-trip."""
    node = _make_node_with_all_types()

    triple_list = []
    node.add_to_list(triple_list)

    def gen():
        for t in triple_list:
            yield t

    restored = VITAL_Node.from_triples(gen())
    assert restored.timestamp == 1710000000000
    assert restored.active == True
    assert restored.name == "DateTime Test"
