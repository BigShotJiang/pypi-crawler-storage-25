#!/usr/bin/env python3
"""
Tests for property None handling — verifies the optimized __setattr__ pop path
works correctly when setting properties to None.

Covers: Phase 1 (__setattr__ O(1) dict lookup + pop path)
"""

import sys
from pathlib import Path

project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(project_root))

from vital_ai_vitalsigns.vitalsigns import VitalSigns
from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node


def test_set_property_to_none_by_short_name():
    """Setting a property to None via short name should remove it from _properties."""
    vs = VitalSigns()
    node = VITAL_Node()
    node.URI = "http://example.com/none-test-1"
    node.name = "Before"

    assert node.name == "Before"

    node.name = None
    assert node.name is None

    # Verify the property URI is actually removed from _properties
    name_uri = "http://vital.ai/ontology/vital-core#hasName"
    assert name_uri not in node._properties


def test_set_property_to_none_by_full_uri():
    """Setting a property to None via full URI should remove it from _properties."""
    vs = VitalSigns()
    node = VITAL_Node()
    node.URI = "http://example.com/none-test-2"

    name_uri = "http://vital.ai/ontology/vital-core#hasName"
    setattr(node, name_uri, "Hello")
    assert node.name == "Hello"

    setattr(node, name_uri, None)
    assert node.name is None
    assert name_uri not in node._properties


def test_set_uri_to_none():
    """Setting URI to None should remove URIProp from _properties."""
    vs = VitalSigns()
    node = VITAL_Node()
    node.URI = "http://example.com/none-test-3"
    assert node.URI is not None

    node.URI = None
    assert node.URI is None

    uri_prop = "http://vital.ai/ontology/vital-core#URIProp"
    assert uri_prop not in node._properties


def test_set_boolean_property_to_none():
    """Setting a boolean property to None should remove it."""
    vs = VitalSigns()
    node = VITAL_Node()
    node.URI = "http://example.com/none-test-4"
    node.active = True
    assert node.active == True

    node.active = None
    assert node.active is None

    active_uri = "http://vital.ai/ontology/vital-core#isActive"
    assert active_uri not in node._properties


def test_set_long_property_to_none():
    """Setting a long/integer property to None should remove it."""
    vs = VitalSigns()
    node = VITAL_Node()
    node.URI = "http://example.com/none-test-5"
    node.timestamp = 1234567890
    assert node.timestamp is not None

    node.timestamp = None
    assert node.timestamp is None

    ts_uri = "http://vital.ai/ontology/vital-core#hasTimestamp"
    assert ts_uri not in node._properties


def test_set_none_on_unset_property():
    """Setting None on a property that was never set should be a no-op."""
    vs = VitalSigns()
    node = VITAL_Node()
    node.URI = "http://example.com/none-test-6"

    # name was never set
    node.name = None
    assert node.name is None

    name_uri = "http://vital.ai/ontology/vital-core#hasName"
    assert name_uri not in node._properties


def test_modified_flag_on_none_set():
    """Setting a property to None should still set the _modified flag."""
    vs = VitalSigns()
    node = VITAL_Node()
    node.URI = "http://example.com/none-test-7"
    node.name = "Test"
    node.mark_serialized()
    assert node._modified is False

    node.name = None
    assert node._modified is True
