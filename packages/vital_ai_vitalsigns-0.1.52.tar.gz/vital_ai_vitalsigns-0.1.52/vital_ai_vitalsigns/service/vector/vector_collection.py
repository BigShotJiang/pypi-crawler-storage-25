

class VitalVectorCollection:
    pass
