from pydantic import BaseModel, Field
from typing import Annotated, Generic
from nexo.types.string import OptStrT
from nexo.types.uuid import OptUUID


class UserUUID(BaseModel):
    user_uuid: Annotated[OptUUID, Field(None, description="User's UUID")] = None


class Original(BaseModel, Generic[OptStrT]):
    original: Annotated[OptStrT, Field(..., description="Original Transcript")]
