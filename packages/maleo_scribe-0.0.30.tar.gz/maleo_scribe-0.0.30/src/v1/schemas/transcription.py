from pydantic import Field
from typing import Annotated, Self
from uuid import UUID
from nexo.schemas.mixins.identity import (
    UUID as UUIDMixin,
    DataIdentifier,
    IntUserId,
)
from nexo.schemas.mixins.timestamp import Duration
from nexo.types.integer import OptInt
from .soap import SOAP, SOAPMixin
from ..mixins.transcription import UserUUID, Original
from ...common.dtos import (
    AudioMetadata,
    AudioMetadataMixin,
    TranscriptionMetadata,
    TranscriptionMetadataMixin,
    ProcessTranscriptMetadata,
    ProcessTranscriptMetadataMixin,
)
from ...common.mixins import Notes


class TranscribeParameter(UserUUID, IntUserId[OptInt]):
    transcription_id: Annotated[UUID, Field(..., description="Transcription's ID")]
    audio: Annotated[bytes, Field(..., description="Audio")]
    content_type: Annotated[str, Field(..., description="Content type")]
    filename: Annotated[str, Field(..., description="File name")]


class TranscribeResponseData(
    Notes[str],
    SOAPMixin[SOAP[str, str, str, str]],
    Original[str],
):
    pass


class InsertTranscriptionParameters(
    TranscribeResponseData,
    ProcessTranscriptMetadataMixin[TranscribeResponseData],
    TranscriptionMetadataMixin,
    AudioMetadataMixin,
    Duration[float],
    UserUUID,
    IntUserId[OptInt],
    UUIDMixin[UUID],
):
    @classmethod
    def from_data(
        cls,
        parameters: TranscribeParameter,
        duration: float,
        audio_metadata: AudioMetadata,
        transcription_metadata: TranscriptionMetadata,
        process_transcript_metadata: ProcessTranscriptMetadata[TranscribeResponseData],
        data: TranscribeResponseData,
    ) -> Self:
        return cls(
            uuid=parameters.transcription_id,
            user_id=parameters.user_id,
            user_uuid=parameters.user_uuid,
            duration=duration,
            audio_metadata=audio_metadata,
            transcription_metadata=transcription_metadata,
            process_transcript_metadata=process_transcript_metadata,
            original=data.original,
            soap=data.soap,
            notes=data.notes,
        )


class InsertTranscriptionSchema(
    TranscribeResponseData,
    ProcessTranscriptMetadataMixin[TranscribeResponseData],
    TranscriptionMetadataMixin,
    AudioMetadataMixin,
    Duration[float],
    UserUUID,
    IntUserId[OptInt],
    DataIdentifier,
):
    pass


class TranscriptionSchema(
    TranscribeResponseData,
    DataIdentifier,
):
    pass
