from pydantic import BaseModel, Field
from typing import Annotated, Generic, TypeVar
from nexo.types.string import OptStr, OptStrT
from ...common.mixins import (
    Overall,
    OptOtherInformation,
    ChiefComplaint,
    OptAdditionalComplaint,
    OptPainScale,
    OptOnset,
    OptChronology,
    OptLocation,
    OptFactor,
    OptPastIllnessHistory,
    OptFamilyIllnessHistory,
    OptHabitActivityOccupation,
    OptConsumedMedication,
    OptSystole,
    OptDiastole,
    OptTemperature,
    OptRespirationRate,
    OptHeartRate,
    OptOxygenSaturation,
    OptWaistCircumference,
    OptWeight,
    OptHeight,
    OptBodyMassIndex,
    OptOrganExaminationDetail,
)


# ----- Subjective ----- #
class Subjective(
    OptOtherInformation,
    OptConsumedMedication,
    OptHabitActivityOccupation,
    OptFamilyIllnessHistory,
    OptPastIllnessHistory,
    OptFactor,
    OptLocation,
    OptChronology,
    OptOnset,
    OptPainScale,
    OptAdditionalComplaint,
    ChiefComplaint[OptStrT],
    Generic[OptStrT],
):
    pass


# ----- Vital Sign ----- #
class VitalSign(
    OptOrganExaminationDetail,
    OptBodyMassIndex,
    OptWeight,
    OptHeight,
    OptWaistCircumference,
    OptOxygenSaturation,
    OptHeartRate,
    OptRespirationRate,
    OptTemperature,
    OptDiastole,
    OptSystole,
):
    pass


class VitalSignMixin(BaseModel):
    vital_sign: Annotated[VitalSign, Field(..., description="Vital Sign")]


# ----- Objective ----- #
class Objective(
    OptOtherInformation,
    VitalSignMixin,
    Overall[OptStrT],
    Generic[OptStrT],
):
    pass


# ----- Assessment ----- #
class Assessment(Overall[OptStrT], Generic[OptStrT]):
    pass


# ----- Plan ----- #
class Plan(Overall[OptStrT], Generic[OptStrT]):
    pass


# ----- SOAP ----- #
SubjectiveChiefComplaintT = TypeVar("SubjectiveChiefComplaintT", bound=OptStr)
ObjectiveOverallT = TypeVar("ObjectiveOverallT", bound=OptStr)
AssessmentOverallT = TypeVar("AssessmentOverallT", bound=OptStr)
PlanOverallT = TypeVar("PlanOverallT", bound=OptStr)


class SOAP(
    BaseModel,
    Generic[
        SubjectiveChiefComplaintT,
        ObjectiveOverallT,
        AssessmentOverallT,
        PlanOverallT,
    ],
):
    subjective: Annotated[
        Subjective[SubjectiveChiefComplaintT], Field(..., description="Subjective")
    ]
    objective: Annotated[
        Objective[ObjectiveOverallT], Field(..., description="Objective")
    ]
    assessment: Annotated[
        Assessment[AssessmentOverallT], Field(..., description="Assessment")
    ]
    plan: Annotated[Plan[PlanOverallT], Field(..., description="Plan")]


OptSOAP = SOAP | None
OptSOAPT = TypeVar("OptSOAPT", bound=OptSOAP)


class SOAPMixin(BaseModel, Generic[OptSOAPT]):
    soap: Annotated[OptSOAPT, Field(..., description="SOAP")]
