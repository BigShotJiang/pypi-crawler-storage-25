from pydantic import BaseModel, Field
from typing import Annotated, Self
from uuid import UUID
from nexo.schemas.mixins.identity import (
    UUID as UUIDMixin,
    DataIdentifier,
    UUIDOrganizationId,
    UUIDPrincipalId,
    UUIDUserId,
)
from nexo.schemas.mixins.timestamp import Duration
from nexo.schemas.security.authentication import AnyAuthenticatedAuthentication
from nexo.schemas.security.enums import Domain, DomainMixin
from nexo.types.uuid import OptUUID
from .soap import SOAP, SOAPMixin
from ..mixins.transcription import Transcript
from ...common.dtos import (
    AudioMetadata,
    AudioMetadataMixin,
    TranscriptionMetadata,
    TranscriptionMetadataMixin,
    ProcessTranscriptMetadata,
    ProcessTranscriptMetadataMixin,
)
from ...common.mixins import Notes


class TranscribeParameter(BaseModel):
    transcription_id: Annotated[UUID, Field(..., description="Transcription's ID")]
    audio: Annotated[bytes, Field(..., description="Audio")]
    content_type: Annotated[str, Field(..., description="Content type")]
    filename: Annotated[str, Field(..., description="File name")]


class TranscribeResponseData(
    Notes[str],
    SOAPMixin[SOAP[str, str, str, str]],
    Transcript[str],
):
    pass


class InsertTranscriptionParameters(
    TranscribeResponseData,
    ProcessTranscriptMetadataMixin[TranscribeResponseData],
    TranscriptionMetadataMixin,
    AudioMetadataMixin,
    Duration[float],
    UUIDOrganizationId[OptUUID],
    UUIDUserId[UUID],
    DomainMixin[Domain],
    UUIDPrincipalId[UUID],
    UUIDMixin[UUID],
):
    @classmethod
    def from_data(
        cls,
        uuid: UUID,
        authentication: AnyAuthenticatedAuthentication,
        duration: float,
        audio_metadata: AudioMetadata,
        transcription_metadata: TranscriptionMetadata,
        process_transcript_metadata: ProcessTranscriptMetadata[TranscribeResponseData],
        data: TranscribeResponseData,
    ) -> Self:
        return cls(
            uuid=uuid,
            principal_id=authentication.credentials.principal.uuid,
            domain=authentication.credentials.domain,
            user_id=authentication.credentials.user.uuid,
            organization_id=(
                authentication.credentials.organization.uuid
                if authentication.credentials.organization is not None
                else None
            ),
            duration=duration,
            audio_metadata=audio_metadata,
            transcription_metadata=transcription_metadata,
            process_transcript_metadata=process_transcript_metadata,
            transcript=data.transcript,
            soap=data.soap,
            notes=data.notes,
        )


class InsertTranscriptionSchema(
    TranscribeResponseData,
    ProcessTranscriptMetadataMixin[TranscribeResponseData],
    TranscriptionMetadataMixin,
    AudioMetadataMixin,
    Duration[float],
    UUIDOrganizationId[OptUUID],
    UUIDUserId[UUID],
    DomainMixin[Domain],
    UUIDPrincipalId[UUID],
    DataIdentifier,
):
    pass


class TranscriptionSchema(
    TranscribeResponseData,
    DataIdentifier,
):
    pass
