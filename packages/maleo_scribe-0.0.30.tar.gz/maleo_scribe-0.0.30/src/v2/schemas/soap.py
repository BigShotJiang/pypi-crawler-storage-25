from pydantic import BaseModel, Field
from typing import Annotated, Generic, TypeVar
from nexo.types.string import OptStr, OptStrT
from ...common.mixins import (
    Overall,
    OptOtherInformation,
    ChiefComplaint,
    OptAdditionalComplaint,
    OptPainScale,
    OptOnset,
    OptChronology,
    OptLocation,
    OptAggravatingFactor,
    OptRelievingFactor,
    OptPersonalMedicalHistory,
    OptFamilyMedicalHistory,
    OptHabitActivityOccupation,
    OptConsumedMedication,
    OptSystolicBloodPressure,
    OptDiastolicBloodPressure,
    OptTemperature,
    OptRespirationRate,
    OptHeartRate,
    OptOxygenSaturation,
    OptAbdominalCircumference,
    OptWaistCircumference,
    OptWeight,
    OptHeight,
    OptBodyMassIndex,
    OptOrganExaminationDetail,
)


# ----- Subjective ----- #
class Subjective(
    OptOtherInformation,
    OptConsumedMedication,
    OptHabitActivityOccupation,
    OptFamilyMedicalHistory,
    OptPersonalMedicalHistory,
    OptRelievingFactor,
    OptAggravatingFactor,
    OptLocation,
    OptChronology,
    OptOnset,
    OptPainScale,
    OptAdditionalComplaint,
    ChiefComplaint[OptStrT],
    Generic[OptStrT],
):
    pass


# ----- Vital Sign ----- #
class VitalSign(
    OptOrganExaminationDetail,
    OptBodyMassIndex,
    OptWeight,
    OptHeight,
    OptWaistCircumference,
    OptAbdominalCircumference,
    OptOxygenSaturation,
    OptHeartRate,
    OptRespirationRate,
    OptTemperature,
    OptDiastolicBloodPressure,
    OptSystolicBloodPressure,
):
    pass


class VitalSignMixin(BaseModel):
    vital_sign: Annotated[VitalSign, Field(..., description="Vital Sign")]


# ----- Objective ----- #
class Objective(
    OptOtherInformation,
    VitalSignMixin,
    Overall[OptStrT],
    Generic[OptStrT],
):
    pass


# ----- Assessment ----- #
class Assessment(BaseModel, Generic[OptStrT]):
    assessment: Annotated[OptStrT, Field(..., description="Patient's assessment")]


# ----- Plan ----- #
class Plan(BaseModel, Generic[OptStrT]):
    plan: Annotated[OptStrT, Field(..., description="Patient's plan")]


# ----- SOAP ----- #
SubjectiveChiefComplaintT = TypeVar("SubjectiveChiefComplaintT", bound=OptStr)
ObjectiveOverallT = TypeVar("ObjectiveOverallT", bound=OptStr)
AssessmentT = TypeVar("AssessmentT", bound=OptStr)
PlanT = TypeVar("PlanT", bound=OptStr)


class SOAP(
    BaseModel,
    Generic[
        SubjectiveChiefComplaintT,
        ObjectiveOverallT,
        AssessmentT,
        PlanT,
    ],
):
    subjective: Annotated[
        Subjective[SubjectiveChiefComplaintT], Field(..., description="Subjective")
    ]
    objective: Annotated[
        Objective[ObjectiveOverallT], Field(..., description="Objective")
    ]
    assessment: Annotated[AssessmentT, Field(..., description="Patient's assessment")]
    plan: Annotated[PlanT, Field(..., description="Patient's plan")]


OptSOAP = SOAP | None
OptSOAPT = TypeVar("OptSOAPT", bound=OptSOAP)


class SOAPMixin(BaseModel, Generic[OptSOAPT]):
    soap: Annotated[OptSOAPT, Field(..., description="SOAP")]
