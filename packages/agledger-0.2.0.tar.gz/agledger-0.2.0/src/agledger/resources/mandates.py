"""Mandates resource — CRUD, lifecycle transitions, delegation, rework loops."""

from __future__ import annotations

from typing import Any, AsyncIterator, Iterator

from agledger._http import AsyncHttpClient, HttpClient
from agledger.types import Mandate, MandateStatusSummary, OutcomeResult, Page


class MandatesResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def create(
        self,
        *,
        enterprise_id: str,
        contract_type: str,
        contract_version: str,
        platform: str,
        criteria: dict[str, Any],
        platform_ref: str | None = None,
        project_ref: str | None = None,
        tolerance: dict[str, Any] | None = None,
        deadline: str | None = None,
        agent_id: str | None = None,
        commission_pct: float | None = None,
        max_submissions: int | None = None,
        operating_mode: str | None = None,
        verification_mode: str | None = None,
        risk_classification: str | None = None,
        eu_ai_act_domain: str | None = None,
        human_oversight: dict[str, Any] | None = None,
    ) -> Mandate:
        """Create a new mandate via enterprise auth."""
        body: dict[str, Any] = {
            "enterpriseId": enterprise_id,
            "contractType": contract_type,
            "contractVersion": contract_version,
            "platform": platform,
            "criteria": criteria,
        }
        if platform_ref is not None: body["platformRef"] = platform_ref
        if project_ref is not None: body["projectRef"] = project_ref
        if tolerance is not None: body["tolerance"] = tolerance
        if deadline is not None: body["deadline"] = deadline
        if agent_id is not None: body["agentId"] = agent_id
        if commission_pct is not None: body["commissionPct"] = commission_pct
        if max_submissions is not None: body["maxSubmissions"] = max_submissions
        if operating_mode is not None: body["operatingMode"] = operating_mode
        if verification_mode is not None: body["verificationMode"] = verification_mode
        if risk_classification is not None: body["riskClassification"] = risk_classification
        if eu_ai_act_domain is not None: body["euAiActDomain"] = eu_ai_act_domain
        if human_oversight is not None: body["humanOversight"] = human_oversight
        return Mandate.model_validate(self._http.post("/v1/mandates", json=body))

    def create_agent(
        self,
        *,
        principal_agent_id: str,
        contract_type: str,
        contract_version: str,
        criteria: dict[str, Any],
        performer_agent_id: str | None = None,
        platform: str | None = None,
        project_ref: str | None = None,
        tolerance: dict[str, Any] | None = None,
        parent_mandate_id: str | None = None,
        commission_pct: float | None = None,
        max_submissions: int | None = None,
        deadline: str | None = None,
        verification_mode: str | None = None,
    ) -> Mandate:
        """Create a mandate via agent auth."""
        body: dict[str, Any] = {
            "principalAgentId": principal_agent_id,
            "contractType": contract_type,
            "contractVersion": contract_version,
            "criteria": criteria,
        }
        if performer_agent_id is not None: body["performerAgentId"] = performer_agent_id
        if platform is not None: body["platform"] = platform
        if project_ref is not None: body["projectRef"] = project_ref
        if tolerance is not None: body["tolerance"] = tolerance
        if parent_mandate_id is not None: body["parentMandateId"] = parent_mandate_id
        if commission_pct is not None: body["commissionPct"] = commission_pct
        if max_submissions is not None: body["maxSubmissions"] = max_submissions
        if deadline is not None: body["deadline"] = deadline
        if verification_mode is not None: body["verificationMode"] = verification_mode
        return Mandate.model_validate(self._http.post("/v1/mandates/agent", json=body))

    def get(self, mandate_id: str) -> Mandate:
        """Get a mandate by ID."""
        return Mandate.model_validate(self._http.get(f"/v1/mandates/{mandate_id}"))

    def list(
        self,
        *,
        enterprise_id: str,
        status: str | None = None,
        limit: int | None = None,
        cursor: str | None = None,
    ) -> Page[Mandate]:
        """List mandates with optional filters."""
        params: dict[str, Any] = {"enterpriseId": enterprise_id}
        if status is not None: params["status"] = status
        if limit is not None: params["limit"] = limit
        if cursor is not None: params["cursor"] = cursor
        raw = self._http.get_page("/v1/mandates", params=params)
        raw["data"] = [Mandate.model_validate(m) for m in raw.get("data", [])]
        return Page[Mandate].model_validate(raw)

    def list_all(self, *, enterprise_id: str, status: str | None = None) -> Iterator[Mandate]:
        """Auto-paginate through all mandates."""
        params: dict[str, Any] = {"enterpriseId": enterprise_id}
        if status is not None: params["status"] = status
        for item in self._http.paginate("/v1/mandates", params=params):
            yield Mandate.model_validate(item)

    def search(
        self,
        *,
        enterprise_id: str,
        status: str | None = None,
        contract_type: str | None = None,
        agent_id: str | None = None,
        from_date: str | None = None,
        to_date: str | None = None,
        sort: str | None = None,
        order: str | None = None,
        limit: int | None = None,
        cursor: str | None = None,
    ) -> Page[Mandate]:
        """Search mandates with advanced filters."""
        params: dict[str, Any] = {"enterpriseId": enterprise_id}
        if status is not None: params["status"] = status
        if contract_type is not None: params["contractType"] = contract_type
        if agent_id is not None: params["agentId"] = agent_id
        if from_date is not None: params["from"] = from_date
        if to_date is not None: params["to"] = to_date
        if sort is not None: params["sort"] = sort
        if order is not None: params["order"] = order
        if limit is not None: params["limit"] = limit
        if cursor is not None: params["cursor"] = cursor
        raw = self._http.get_page("/v1/mandates/search", params=params)
        raw["data"] = [Mandate.model_validate(m) for m in raw.get("data", [])]
        return Page[Mandate].model_validate(raw)

    def update(self, mandate_id: str, **params: Any) -> Mandate:
        """Update a mandate's mutable fields."""
        return Mandate.model_validate(self._http.patch(f"/v1/mandates/{mandate_id}", json=params))

    def transition(self, mandate_id: str, action: str, reason: str | None = None) -> Mandate:
        """Transition a mandate to a new state."""
        body: dict[str, Any] = {"action": action}
        if reason:
            body["reason"] = reason
        return Mandate.model_validate(self._http.post(f"/v1/mandates/{mandate_id}/transition", json=body))

    def cancel(self, mandate_id: str, reason: str | None = None) -> Mandate:
        """Cancel a mandate."""
        return self.transition(mandate_id, "cancel", reason)

    def accept(self, mandate_id: str) -> Mandate:
        """Accept a proposed mandate (as performer)."""
        return Mandate.model_validate(self._http.post(f"/v1/mandates/{mandate_id}/accept", json={}))

    def reject(self, mandate_id: str, reason: str | None = None) -> Mandate:
        """Reject a proposed mandate (as performer)."""
        body = {"reason": reason} if reason else {}
        return Mandate.model_validate(self._http.post(f"/v1/mandates/{mandate_id}/reject", json=body))

    def request_revision(self, mandate_id: str, reason: str | None = None) -> Mandate:
        """Request revision after principal rejection (rework loop)."""
        body = {"reason": reason} if reason else {}
        return Mandate.model_validate(self._http.post(f"/v1/mandates/{mandate_id}/revision", json=body))

    def get_chain(self, mandate_id: str) -> list[Mandate]:
        """Get the full delegation chain for a mandate."""
        data = self._http.get(f"/v1/mandates/{mandate_id}/chain")
        return [Mandate.model_validate(m) for m in data]

    def get_audit(self, mandate_id: str) -> dict[str, Any]:
        """Get audit trail for a mandate."""
        return self._http.get(f"/v1/mandates/{mandate_id}/audit")

    def get_graph(self, mandate_id: str) -> dict[str, Any]:
        """Get the delegation graph for a mandate."""
        return self._http.get(f"/v1/mandates/{mandate_id}/graph")

    def respond(self, mandate_id: str, *, action: str, reason: str | None = None) -> Mandate:
        """Respond to a PROPOSED mandate (accept, reject, or counter)."""
        body: dict[str, Any] = {"action": action}
        if reason is not None:
            body["reason"] = reason
        return Mandate.model_validate(self._http.post(f"/v1/mandates/{mandate_id}/respond", json=body))

    def accept_counter(self, mandate_id: str) -> Mandate:
        """Accept a counter-proposal on a mandate."""
        return Mandate.model_validate(self._http.post(f"/v1/mandates/{mandate_id}/accept-counter", json={}))

    def get_sub_mandates(self, mandate_id: str) -> Page[Mandate]:
        """Get direct sub-mandates of a mandate."""
        raw = self._http.get_page(f"/v1/mandates/{mandate_id}/sub-mandates")
        raw["data"] = [Mandate.model_validate(m) for m in raw.get("data", [])]
        return Page[Mandate].model_validate(raw)

    def delegate(self, mandate_id: str, **kwargs: Any) -> Mandate:
        """Delegate a mandate by creating a child mandate via agent auth."""
        kwargs["parent_mandate_id"] = mandate_id
        return self.create_agent(**kwargs)

    def bulk_create(self, mandates: list[dict[str, Any]]) -> dict[str, Any]:
        """Create multiple mandates in a single request."""
        return self._http.post("/v1/mandates/bulk", json={"mandates": mandates})

    def list_as_principal(self, **kwargs: Any) -> Page[Mandate]:
        """List mandates where the authenticated agent is principal."""
        raw = self._http.get_page("/v1/mandates/agent/principal", params=kwargs or None)
        raw["data"] = [Mandate.model_validate(m) for m in raw.get("data", [])]
        return Page[Mandate].model_validate(raw)

    def list_proposals(self, **kwargs: Any) -> Page[Mandate]:
        """List mandates proposed to the authenticated agent."""
        raw = self._http.get_page("/v1/mandates/agent/proposals", params=kwargs or None)
        raw["data"] = [Mandate.model_validate(m) for m in raw.get("data", [])]
        return Page[Mandate].model_validate(raw)

    def report_outcome(
        self,
        mandate_id: str,
        *,
        receipt_id: str,
        outcome: str,
        checks: dict[str, Any] | None = None,
    ) -> OutcomeResult:
        """Report the principal verdict (PASS or FAIL) on a receipt."""
        body: dict[str, Any] = {"receiptId": receipt_id, "outcome": outcome}
        if checks is not None:
            body["checks"] = checks
        return OutcomeResult.model_validate(self._http.post(f"/v1/mandates/{mandate_id}/outcome", json=body))

    def get_summary(self, enterprise_id: str | None = None) -> MandateStatusSummary:
        """Get mandate counts grouped by status."""
        params: dict[str, Any] = {}
        if enterprise_id is not None:
            params["enterpriseId"] = enterprise_id
        return MandateStatusSummary.model_validate(self._http.get("/v1/mandates/summary", params=params))

    def create_and_activate(self, **params: Any) -> Mandate:
        """Create, register, and activate a mandate. 3 API calls — if a step fails, the mandate exists in the intermediate state."""
        mandate = self.create(**params)
        self.transition(mandate.id, "register")
        return self.transition(mandate.id, "activate")


class AsyncMandatesResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def create(self, **params: Any) -> Mandate:
        body = _to_camel(params)
        return Mandate.model_validate(await self._http.post("/v1/mandates", json=body))

    async def create_agent(self, **params: Any) -> Mandate:
        body = _to_camel(params)
        return Mandate.model_validate(await self._http.post("/v1/mandates/agent", json=body))

    async def get(self, mandate_id: str) -> Mandate:
        return Mandate.model_validate(await self._http.get(f"/v1/mandates/{mandate_id}"))

    async def list(self, *, enterprise_id: str, status: str | None = None, limit: int | None = None, cursor: str | None = None) -> Page[Mandate]:
        params: dict[str, Any] = {"enterpriseId": enterprise_id}
        if status is not None: params["status"] = status
        if limit is not None: params["limit"] = limit
        if cursor is not None: params["cursor"] = cursor
        raw = await self._http.get_page("/v1/mandates", params=params)
        raw["data"] = [Mandate.model_validate(m) for m in raw.get("data", [])]
        return Page[Mandate].model_validate(raw)

    async def list_all(self, *, enterprise_id: str, status: str | None = None) -> AsyncIterator[Mandate]:
        params: dict[str, Any] = {"enterpriseId": enterprise_id}
        if status is not None: params["status"] = status
        async for item in self._http.paginate("/v1/mandates", params=params):
            yield Mandate.model_validate(item)

    async def transition(self, mandate_id: str, action: str, reason: str | None = None) -> Mandate:
        body: dict[str, Any] = {"action": action}
        if reason: body["reason"] = reason
        return Mandate.model_validate(await self._http.post(f"/v1/mandates/{mandate_id}/transition", json=body))

    async def cancel(self, mandate_id: str, reason: str | None = None) -> Mandate:
        return await self.transition(mandate_id, "cancel", reason)

    async def accept(self, mandate_id: str) -> Mandate:
        return Mandate.model_validate(await self._http.post(f"/v1/mandates/{mandate_id}/accept", json={}))

    async def reject(self, mandate_id: str, reason: str | None = None) -> Mandate:
        body = {"reason": reason} if reason else {}
        return Mandate.model_validate(await self._http.post(f"/v1/mandates/{mandate_id}/reject", json=body))

    async def request_revision(self, mandate_id: str, reason: str | None = None) -> Mandate:
        body = {"reason": reason} if reason else {}
        return Mandate.model_validate(await self._http.post(f"/v1/mandates/{mandate_id}/revision", json=body))

    async def get_chain(self, mandate_id: str) -> list[Mandate]:
        data = await self._http.get(f"/v1/mandates/{mandate_id}/chain")
        return [Mandate.model_validate(m) for m in data]

    async def get_audit(self, mandate_id: str) -> dict[str, Any]:
        return await self._http.get(f"/v1/mandates/{mandate_id}/audit")

    async def get_graph(self, mandate_id: str) -> dict[str, Any]:
        """Get the delegation graph for a mandate."""
        return await self._http.get(f"/v1/mandates/{mandate_id}/graph")

    async def respond(self, mandate_id: str, *, action: str, reason: str | None = None) -> Mandate:
        body: dict[str, Any] = {"action": action}
        if reason is not None:
            body["reason"] = reason
        return Mandate.model_validate(await self._http.post(f"/v1/mandates/{mandate_id}/respond", json=body))

    async def accept_counter(self, mandate_id: str) -> Mandate:
        return Mandate.model_validate(await self._http.post(f"/v1/mandates/{mandate_id}/accept-counter", json={}))

    async def get_sub_mandates(self, mandate_id: str) -> Page[Mandate]:
        raw = await self._http.get_page(f"/v1/mandates/{mandate_id}/sub-mandates")
        raw["data"] = [Mandate.model_validate(m) for m in raw.get("data", [])]
        return Page[Mandate].model_validate(raw)

    async def delegate(self, mandate_id: str, **kwargs: Any) -> Mandate:
        kwargs["parent_mandate_id"] = mandate_id
        return await self.create_agent(**kwargs)

    async def bulk_create(self, mandates: list[dict[str, Any]]) -> dict[str, Any]:
        return await self._http.post("/v1/mandates/bulk", json={"mandates": mandates})

    async def list_as_principal(self, **kwargs: Any) -> Page[Mandate]:
        raw = await self._http.get_page("/v1/mandates/agent/principal", params=kwargs or None)
        raw["data"] = [Mandate.model_validate(m) for m in raw.get("data", [])]
        return Page[Mandate].model_validate(raw)

    async def list_proposals(self, **kwargs: Any) -> Page[Mandate]:
        raw = await self._http.get_page("/v1/mandates/agent/proposals", params=kwargs or None)
        raw["data"] = [Mandate.model_validate(m) for m in raw.get("data", [])]
        return Page[Mandate].model_validate(raw)

    async def report_outcome(
        self,
        mandate_id: str,
        *,
        receipt_id: str,
        outcome: str,
        checks: dict[str, Any] | None = None,
    ) -> OutcomeResult:
        """Report the principal verdict (PASS or FAIL) on a receipt."""
        body: dict[str, Any] = {"receiptId": receipt_id, "outcome": outcome}
        if checks is not None:
            body["checks"] = checks
        return OutcomeResult.model_validate(await self._http.post(f"/v1/mandates/{mandate_id}/outcome", json=body))

    async def get_summary(self, enterprise_id: str | None = None) -> MandateStatusSummary:
        """Get mandate counts grouped by status."""
        params: dict[str, Any] = {}
        if enterprise_id is not None:
            params["enterpriseId"] = enterprise_id
        return MandateStatusSummary.model_validate(await self._http.get("/v1/mandates/summary", params=params))

    async def create_and_activate(self, **params: Any) -> Mandate:
        mandate = await self.create(**params)
        await self.transition(mandate.id, "register")
        return await self.transition(mandate.id, "activate")


def _to_camel(d: dict[str, Any]) -> dict[str, Any]:
    """Convert snake_case keys to camelCase for API."""
    result: dict[str, Any] = {}
    for k, v in d.items():
        if v is None:
            continue
        parts = k.split("_")
        key = parts[0] + "".join(p.capitalize() for p in parts[1:])
        result[key] = v
    return result
