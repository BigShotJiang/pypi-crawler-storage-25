"""Dashboard resource."""

from __future__ import annotations

from typing import Any

from agledger._http import AsyncHttpClient, HttpClient
from agledger.types import DashboardStats, DashboardSummary


class DashboardResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def get_summary(self) -> DashboardSummary:
        """Get a high-level dashboard summary."""
        return DashboardSummary.model_validate(self._http.get("/v1/dashboard/summary"))

    def get_metrics(self, **params: Any) -> dict[str, Any]:
        """Get dashboard metrics over a time range."""
        return self._http.get("/v1/dashboard/metrics", params=params)

    def get_stats(self) -> DashboardStats:
        """Get dashboard statistics."""
        return DashboardStats.model_validate(self._http.get("/v1/dashboard/stats"))

    def get_alerts(self, **params: Any) -> dict[str, Any]:
        """List dashboard alerts."""
        return self._http.get_page("/v1/dashboard/alerts", params=params)

    def get_disputes(self, **params: Any) -> dict[str, Any]:
        """List dashboard disputes."""
        return self._http.get_page("/v1/dashboard/disputes", params=params)

    def get_audit_trail(self, **params: Any) -> dict[str, Any]:
        """List dashboard audit trail entries."""
        return self._http.get_page("/v1/dashboard/audit-trail", params=params)

    def list_agents(self, **params: Any) -> dict[str, Any]:
        """List dashboard agents."""
        return self._http.get_page("/v1/dashboard/agents", params=params)


class AsyncDashboardResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def get_summary(self) -> DashboardSummary:
        """Get a high-level dashboard summary."""
        return DashboardSummary.model_validate(await self._http.get("/v1/dashboard/summary"))

    async def get_metrics(self, **params: Any) -> dict[str, Any]:
        """Get dashboard metrics over a time range."""
        return await self._http.get("/v1/dashboard/metrics", params=params)

    async def get_stats(self) -> DashboardStats:
        """Get dashboard statistics."""
        return DashboardStats.model_validate(await self._http.get("/v1/dashboard/stats"))

    async def get_alerts(self, **params: Any) -> dict[str, Any]:
        """List dashboard alerts."""
        return await self._http.get_page("/v1/dashboard/alerts", params=params)

    async def get_disputes(self, **params: Any) -> dict[str, Any]:
        """List dashboard disputes."""
        return await self._http.get_page("/v1/dashboard/disputes", params=params)

    async def get_audit_trail(self, **params: Any) -> dict[str, Any]:
        """List dashboard audit trail entries."""
        return await self._http.get_page("/v1/dashboard/audit-trail", params=params)

    async def list_agents(self, **params: Any) -> dict[str, Any]:
        """List dashboard agents."""
        return await self._http.get_page("/v1/dashboard/agents", params=params)
