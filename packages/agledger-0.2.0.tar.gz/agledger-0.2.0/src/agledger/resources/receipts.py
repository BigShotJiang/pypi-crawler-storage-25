"""Receipts resource."""

from __future__ import annotations

from typing import Any, AsyncIterator, Iterator

from agledger._http import AsyncHttpClient, HttpClient
from agledger.types import Page, Receipt


class ReceiptsResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def submit(
        self,
        mandate_id: str,
        *,
        agent_id: str,
        evidence: dict[str, Any],
        notes: str | None = None,
        idempotency_key: str | None = None,
    ) -> Receipt:
        """Submit a receipt (evidence of completion) for a mandate."""
        body: dict[str, Any] = {"agentId": agent_id, "evidence": evidence}
        if notes is not None: body["notes"] = notes
        if idempotency_key is not None: body["idempotencyKey"] = idempotency_key
        return Receipt.model_validate(self._http.post(f"/v1/mandates/{mandate_id}/receipts", json=body))

    def get(self, mandate_id: str, receipt_id: str) -> Receipt:
        return Receipt.model_validate(self._http.get(f"/v1/mandates/{mandate_id}/receipts/{receipt_id}"))

    def list(self, mandate_id: str, *, limit: int | None = None, cursor: str | None = None) -> Page[Receipt]:
        params: dict[str, Any] = {}
        if limit is not None: params["limit"] = limit
        if cursor is not None: params["cursor"] = cursor
        raw = self._http.get_page(f"/v1/mandates/{mandate_id}/receipts", params=params)
        raw["data"] = [Receipt.model_validate(r) for r in raw.get("data", [])]
        return Page[Receipt].model_validate(raw)

    def list_all(self, mandate_id: str) -> Iterator[Receipt]:
        for item in self._http.paginate(f"/v1/mandates/{mandate_id}/receipts"):
            yield Receipt.model_validate(item)


class AsyncReceiptsResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def submit(self, mandate_id: str, *, agent_id: str, evidence: dict[str, Any], notes: str | None = None, idempotency_key: str | None = None) -> Receipt:
        body: dict[str, Any] = {"agentId": agent_id, "evidence": evidence}
        if notes is not None: body["notes"] = notes
        if idempotency_key is not None: body["idempotencyKey"] = idempotency_key
        return Receipt.model_validate(await self._http.post(f"/v1/mandates/{mandate_id}/receipts", json=body))

    async def get(self, mandate_id: str, receipt_id: str) -> Receipt:
        return Receipt.model_validate(await self._http.get(f"/v1/mandates/{mandate_id}/receipts/{receipt_id}"))

    async def list(self, mandate_id: str, *, limit: int | None = None, cursor: str | None = None) -> Page[Receipt]:
        params: dict[str, Any] = {}
        if limit is not None: params["limit"] = limit
        if cursor is not None: params["cursor"] = cursor
        raw = await self._http.get_page(f"/v1/mandates/{mandate_id}/receipts", params=params)
        raw["data"] = [Receipt.model_validate(r) for r in raw.get("data", [])]
        return Page[Receipt].model_validate(raw)

    async def list_all(self, mandate_id: str) -> AsyncIterator[Receipt]:
        async for item in self._http.paginate(f"/v1/mandates/{mandate_id}/receipts"):
            yield Receipt.model_validate(item)
