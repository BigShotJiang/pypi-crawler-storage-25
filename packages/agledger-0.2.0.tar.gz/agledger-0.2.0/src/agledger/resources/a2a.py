"""A2A (Agent-to-Agent) protocol resource."""

from __future__ import annotations

from typing import Any

from agledger._http import AsyncHttpClient, HttpClient
from agledger.types import AgentCard


class A2AResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def get_agent_card(self) -> AgentCard:
        return AgentCard.model_validate(self._http.get("/.well-known/agent.json"))

    def send_rpc(self, **params: Any) -> dict[str, Any]:
        return self._http.post("/a2a", json=params)


class AsyncA2AResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def get_agent_card(self) -> AgentCard:
        return AgentCard.model_validate(await self._http.get("/.well-known/agent.json"))

    async def send_rpc(self, **params: Any) -> dict[str, Any]:
        return await self._http.post("/a2a", json=params)
