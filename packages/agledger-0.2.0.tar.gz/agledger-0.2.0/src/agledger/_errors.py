"""
AGLedger SDK — Error classes.
Follows Anthropic/OpenAI naming conventions. Never shadows Python builtins.
"""

from __future__ import annotations

from typing import Any


class AgledgerError(Exception):
    """Base error for all SDK errors."""

    pass


class APIError(AgledgerError):
    """API returned an error response.

    Key properties for agent consumers:

    - ``status`` — HTTP status code
    - ``code`` — stable machine-readable error code
    - ``suggestion`` — agent-friendly recovery hint
    - ``retryable`` — whether this error can be retried
    - ``doc_url`` — link to error documentation
    """

    status: int
    code: str
    request_id: str | None
    details: Any | None
    retryable: bool
    doc_url: str
    suggestion: str | None

    __slots__ = ("status", "code", "request_id", "details", "retryable", "doc_url", "suggestion")

    _DEFAULT_SUGGESTIONS: dict[int, str] = {
        401: "Check your API key. Set AGLEDGER_API_KEY or pass api_key to the client constructor.",
        403: "Check API key scopes. See error.missing_scopes for required scopes, or use a broader scope profile.",
        404: "The resource was not found. Verify the ID is correct, or list resources to find valid IDs.",
        409: "A conflicting operation is in progress. Wait and retry, or check the current resource state.",
        422: "The resource is in the wrong state for this operation. Check the current status before retrying.",
        429: "Rate limit exceeded. The SDK retries automatically — if you see this, increase max_retries or add backoff.",
    }

    def __init__(
        self,
        status: int,
        *,
        message: str = "",
        code: str = "unknown",
        request_id: str | None = None,
        details: Any | None = None,
        retryable: bool | None = None,
        suggestion: str | None = None,
    ) -> None:
        self.status = status
        self.code = code
        self.request_id = request_id
        self.details = details
        self.retryable = retryable if retryable is not None else (status == 429 or status >= 500)
        self.doc_url = f"https://docs.agledger.ai/errors/{self.code}"
        self.suggestion = suggestion or self._DEFAULT_SUGGESTIONS.get(status)
        super().__init__(message or f"API error {status}")

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(status={self.status}, code={self.code!r}, message={str(self)!r})"

    def is_retryable(self) -> bool:
        """Whether this error can be retried (429, 5xx, network errors)."""
        return self.retryable

    def is_input_error(self) -> bool:
        """Whether this is a 400 validation error — fix the request and retry."""
        return self.status == 400

    def is_state_error(self) -> bool:
        """Whether this is a 422 state error — resource is in the wrong state."""
        return self.status == 422

    def is_auth_error(self) -> bool:
        """Whether this is an auth error (401/403)."""
        return self.status in (401, 403)


class AuthenticationError(APIError):
    """401 — invalid or missing API key."""

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(401, **kwargs)


class PermissionDeniedError(APIError):
    """403 — insufficient scopes or permissions."""

    missing_scopes: list[str]
    key_scopes: list[str] | None

    def __init__(
        self,
        *,
        missing_scopes: list[str] | None = None,
        key_scopes: list[str] | None = None,
        **kwargs: Any,
    ) -> None:
        self.missing_scopes = missing_scopes or []
        self.key_scopes = key_scopes
        super().__init__(403, **kwargs)


class NotFoundError(APIError):
    """404 — resource not found."""

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(404, **kwargs)


class BadRequestError(APIError):
    """400 — request validation failed."""

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(400, **kwargs)


class ConflictError(APIError):
    """409 — conflict (e.g., idempotency key reuse, state conflict)."""

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(409, **kwargs)


class UnprocessableError(APIError):
    """422 — resource in wrong state for the requested operation."""

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(422, **kwargs)


class RateLimitError(APIError):
    """429 — rate limit exceeded."""

    retry_after: float | None

    def __init__(self, *, retry_after: float | None = None, **kwargs: Any) -> None:
        self.retry_after = retry_after
        super().__init__(429, **kwargs)


class APIConnectionError(AgledgerError):
    """Network connectivity error."""

    pass


class APITimeoutError(APIConnectionError):
    """Request timed out."""

    pass


class SignatureVerificationError(Exception):
    """Raised when webhook signature verification fails."""

    def __init__(self, message: str, payload: bytes | None = None) -> None:
        super().__init__(message)
        self.payload = payload
