"""
AGLedger SDK — Client with 23 resource sub-clients.
Supports context manager protocol for proper connection cleanup.
"""

from __future__ import annotations

from types import TracebackType

import httpx

from agledger._http import (
    AsyncHttpClient,
    HttpClient,
    DEFAULT_BASE_URL,
    DEFAULT_MAX_RETRIES,
    DEFAULT_TIMEOUT,
    _resolve_api_key,
)
from agledger.resources.a2a import A2AResource, AsyncA2AResource
from agledger.resources.agents import AgentsResource, AsyncAgentsResource
from agledger.resources.admin import AdminResource, AsyncAdminResource
from agledger.resources.capabilities import AsyncCapabilitiesResource, CapabilitiesResource
from agledger.resources.compliance import AsyncComplianceResource, ComplianceResource
from agledger.resources.dashboard import AsyncDashboardResource, DashboardResource
from agledger.resources.disputes import AsyncDisputesResource, DisputesResource
from agledger.resources.enterprises import AsyncEnterprisesResource, EnterprisesResource
from agledger.resources.events import AsyncEventsResource, EventsResource
from agledger.resources.health import AsyncHealthResource, HealthResource
from agledger.resources.mandates import AsyncMandatesResource, MandatesResource
from agledger.resources.notarize import AsyncNotarizeResource, NotarizeResource
from agledger.resources.projects import AsyncProjectsResource, ProjectsResource
from agledger.resources.proxy import AsyncProxyResource, ProxyResource
from agledger.resources.references import AsyncReferencesResource, ReferencesResource
from agledger.resources.receipts import AsyncReceiptsResource, ReceiptsResource
from agledger.resources.registration import AsyncRegistrationResource, RegistrationResource
from agledger.resources.reputation import AsyncReputationResource, ReputationResource
from agledger.resources.schemas import AsyncSchemasResource, SchemasResource
from agledger.resources.verification import AsyncVerificationResource, VerificationResource
from agledger.resources.webhooks import AsyncWebhooksResource, WebhooksResource
from agledger.resources.federation import AsyncFederationResource, FederationResource
from agledger.resources.federation_admin import AsyncFederationAdminResource, FederationAdminResource


class AgledgerClient:
    """
    Synchronous AGLedger API client with 23 resource sub-clients.

    Supports context manager for automatic connection cleanup::

        with AgledgerClient(api_key="ach_ent_...") as client:
            mandate = client.mandates.create(
                enterprise_id="ent_123",
                contract_type="ACH-PROC-v1",
                contract_version="1",
                platform="internal",
                criteria={"item": "widgets"},
            )

    Or pass ``AGLEDGER_API_KEY`` env var::

        client = AgledgerClient()  # reads from env
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str = DEFAULT_BASE_URL,
        max_retries: int = DEFAULT_MAX_RETRIES,
        timeout: float = DEFAULT_TIMEOUT,
        idempotency_key_prefix: str = "",
        http_client: httpx.Client | None = None,
    ) -> None:
        resolved_key = _resolve_api_key(api_key)
        self._http = HttpClient(
            api_key=resolved_key,
            base_url=base_url,
            max_retries=max_retries,
            timeout=timeout,
            idempotency_key_prefix=idempotency_key_prefix,
            http_client=http_client,
        )
        self.mandates = MandatesResource(self._http)
        self.receipts = ReceiptsResource(self._http)
        self.verification = VerificationResource(self._http)
        self.disputes = DisputesResource(self._http)
        self.webhooks = WebhooksResource(self._http)
        self.reputation = ReputationResource(self._http)
        self.events = EventsResource(self._http)
        self.schemas = SchemasResource(self._http)
        self.dashboard = DashboardResource(self._http)
        self.compliance = ComplianceResource(self._http)
        self.registration = RegistrationResource(self._http)
        self.health = HealthResource(self._http)
        self.admin = AdminResource(self._http)
        self.a2a = A2AResource(self._http)
        self.agents = AgentsResource(self._http)
        self.capabilities = CapabilitiesResource(self._http)
        self.notarize = NotarizeResource(self._http)
        self.enterprises = EnterprisesResource(self._http)
        self.proxy = ProxyResource(self._http)
        self.projects = ProjectsResource(self._http)
        self.references = ReferencesResource(self._http)
        self.federation = FederationResource(self._http)
        self.federation_admin = FederationAdminResource(self._http)

    @property
    def last_request_id(self) -> str | None:
        """Request ID from the most recent API response (``X-Request-Id`` header)."""
        return self._http.last_request_id

    def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        self._http.close()

    def __enter__(self) -> AgledgerClient:
        return self

    def __exit__(self, exc_type: type[BaseException] | None, exc_val: BaseException | None, exc_tb: TracebackType | None) -> None:
        self.close()


class AsyncAgledgerClient:
    """
    Async AGLedger API client with 23 resource sub-clients.

    Supports async context manager::

        async with AsyncAgledgerClient(api_key="ach_ent_...") as client:
            mandate = await client.mandates.get("mnd-123")
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str = DEFAULT_BASE_URL,
        max_retries: int = DEFAULT_MAX_RETRIES,
        timeout: float = DEFAULT_TIMEOUT,
        idempotency_key_prefix: str = "",
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        resolved_key = _resolve_api_key(api_key)
        self._http = AsyncHttpClient(
            api_key=resolved_key,
            base_url=base_url,
            max_retries=max_retries,
            timeout=timeout,
            idempotency_key_prefix=idempotency_key_prefix,
            http_client=http_client,
        )
        self.mandates = AsyncMandatesResource(self._http)
        self.receipts = AsyncReceiptsResource(self._http)
        self.verification = AsyncVerificationResource(self._http)
        self.disputes = AsyncDisputesResource(self._http)
        self.webhooks = AsyncWebhooksResource(self._http)
        self.reputation = AsyncReputationResource(self._http)
        self.events = AsyncEventsResource(self._http)
        self.schemas = AsyncSchemasResource(self._http)
        self.dashboard = AsyncDashboardResource(self._http)
        self.compliance = AsyncComplianceResource(self._http)
        self.registration = AsyncRegistrationResource(self._http)
        self.health = AsyncHealthResource(self._http)
        self.admin = AsyncAdminResource(self._http)
        self.a2a = AsyncA2AResource(self._http)
        self.agents = AsyncAgentsResource(self._http)
        self.capabilities = AsyncCapabilitiesResource(self._http)
        self.notarize = AsyncNotarizeResource(self._http)
        self.enterprises = AsyncEnterprisesResource(self._http)
        self.proxy = AsyncProxyResource(self._http)
        self.projects = AsyncProjectsResource(self._http)
        self.references = AsyncReferencesResource(self._http)
        self.federation = AsyncFederationResource(self._http)
        self.federation_admin = AsyncFederationAdminResource(self._http)

    @property
    def last_request_id(self) -> str | None:
        """Request ID from the most recent API response (``X-Request-Id`` header)."""
        return self._http.last_request_id

    async def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        await self._http.close()

    async def __aenter__(self) -> AsyncAgledgerClient:
        return self

    async def __aexit__(self, exc_type: type[BaseException] | None, exc_val: BaseException | None, exc_tb: TracebackType | None) -> None:
        await self.close()
