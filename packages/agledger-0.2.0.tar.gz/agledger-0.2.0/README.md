# AGLedger Python SDK

Accountability and audit infrastructure for agentic systems.

```python
from agledger import AgledgerClient

client = AgledgerClient(api_key="ach_ent_...")
mandate = client.mandates.create(
    enterpriseId="ent_123",
    contractType="ACH-PROC-v1",
    contractVersion="1",
    platform="internal",
    criteria={"item": "widgets", "maxQuantity": 100},
)
```

See [agledger.ai](https://agledger.ai) for documentation.
