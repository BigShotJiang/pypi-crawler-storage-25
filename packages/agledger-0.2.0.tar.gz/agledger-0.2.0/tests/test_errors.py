"""Tests for error hierarchy and classification."""

import httpx
import pytest
import respx

from agledger import AgledgerClient
from agledger._errors import (
    APIError,
    AuthenticationError,
    BadRequestError,
    NotFoundError,
    PermissionDeniedError,
    RateLimitError,
    UnprocessableError,
)


@respx.mock
def test_401_raises_authentication_error():
    respx.get("https://api.agledger.ai/v1/mandates/x").mock(
        return_value=httpx.Response(401, json={"message": "Invalid key", "code": "invalid_key"})
    )
    client = AgledgerClient(api_key="bad-key", max_retries=0)
    with pytest.raises(AuthenticationError) as exc_info:
        client.mandates.get("x")
    assert exc_info.value.status == 401
    assert exc_info.value.is_auth_error()
    assert not exc_info.value.is_retryable()


@respx.mock
def test_403_raises_permission_denied_with_scopes():
    respx.get("https://api.agledger.ai/v1/mandates/x").mock(
        return_value=httpx.Response(403, json={
            "message": "Missing scope",
            "code": "insufficient_scopes",
            "details": {"missingScopes": ["mandate:read"], "keyScopes": ["health:read"]},
        })
    )
    client = AgledgerClient(api_key="test", max_retries=0)
    with pytest.raises(PermissionDeniedError) as exc_info:
        client.mandates.get("x")
    assert exc_info.value.missing_scopes == ["mandate:read"]
    assert exc_info.value.key_scopes == ["health:read"]


@respx.mock
def test_404_raises_not_found():
    respx.get("https://api.agledger.ai/v1/mandates/x").mock(
        return_value=httpx.Response(404, json={"message": "Not found", "code": "not_found"})
    )
    client = AgledgerClient(api_key="test", max_retries=0)
    with pytest.raises(NotFoundError):
        client.mandates.get("x")


@respx.mock
def test_400_raises_bad_request():
    respx.post("https://api.agledger.ai/v1/mandates").mock(
        return_value=httpx.Response(400, json={"message": "Missing field", "code": "validation_error"})
    )
    client = AgledgerClient(api_key="test", max_retries=0)
    with pytest.raises(BadRequestError) as exc_info:
        client.mandates.create(enterprise_id="e", contract_type="t", contract_version="1", platform="p", criteria={})
    assert exc_info.value.is_input_error()


@respx.mock
def test_422_raises_unprocessable():
    respx.post("https://api.agledger.ai/v1/mandates/x/transition").mock(
        return_value=httpx.Response(422, json={"message": "Wrong state", "code": "invalid_transition"})
    )
    client = AgledgerClient(api_key="test", max_retries=0)
    with pytest.raises(UnprocessableError) as exc_info:
        client.mandates.transition("x", "activate")
    assert exc_info.value.is_state_error()


@respx.mock
def test_429_raises_rate_limit_with_retry_after():
    respx.get("https://api.agledger.ai/v1/mandates/x").mock(
        return_value=httpx.Response(
            429,
            json={"message": "Rate limited"},
            headers={"retry-after": "2.5"},
        )
    )
    client = AgledgerClient(api_key="test", max_retries=0)
    with pytest.raises(RateLimitError) as exc_info:
        client.mandates.get("x")
    assert exc_info.value.retry_after == 2.5
    assert exc_info.value.is_retryable()


def test_doc_url():
    err = APIError(422, code="MANDATE_NOT_ACTIVE", message="Wrong state")
    assert err.doc_url == "https://docs.agledger.ai/errors/MANDATE_NOT_ACTIVE"


def test_error_repr():
    err = APIError(422, code="MANDATE_NOT_ACTIVE", message="Wrong state")
    assert "MANDATE_NOT_ACTIVE" in repr(err)
    assert "422" in repr(err)


@respx.mock
def test_non_json_error_response():
    respx.get("https://api.agledger.ai/v1/mandates/x").mock(
        return_value=httpx.Response(500, text="Internal Server Error")
    )
    client = AgledgerClient(api_key="test", max_retries=0)
    with pytest.raises(APIError) as exc_info:
        client.mandates.get("x")
    assert exc_info.value.status == 500
