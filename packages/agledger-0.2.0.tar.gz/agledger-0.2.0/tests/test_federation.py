"""Federation resource tests."""

import httpx
import pytest
import respx

from agledger import AgledgerClient


BASE = "https://api.agledger.ai"


# ---------------------------------------------------------------------------
# FederationResource (Gateway Operations)
# ---------------------------------------------------------------------------


class TestFederationResource:
    def _client(self, mock_client: httpx.Client) -> AgledgerClient:
        return AgledgerClient(api_key="gw_bearer_token", http_client=mock_client)

    @respx.mock
    def test_register_sends_no_auth_header(self):
        route = respx.post(f"{BASE}/federation/v1/register").mock(
            return_value=httpx.Response(201, json={
                "gatewayId": "gw-001",
                "hubSigningPublicKey": "hub-pk",
                "hubEncryptionPublicKey": "hub-enc",
                "bearerToken": "bt-fresh",
                "bearerTokenExpiresAt": "2026-04-01T00:00:00Z",
                "registeredAt": "2026-03-31T00:00:00Z",
            })
        )

        with AgledgerClient(api_key="unused") as client:
            result = client.federation.register(
                registration_token="tok-abc",
                organization_id="org-1",
                signing_public_key="ed25519-pk",
                encryption_public_key="x25519-pk",
                endpoint_url="https://gw.example.com",
                revocation_secret="supersecretrevoke16",
                timestamp="2026-03-31T00:00:00Z",
                nonce="nonce-1234567890123456",
                signature="sig-abc",
            )

        assert result["gatewayId"] == "gw-001"
        assert result["bearerToken"] == "bt-fresh"
        # No Authorization header
        assert "Authorization" not in route.calls[0].request.headers

    @respx.mock
    def test_heartbeat_sends_bearer_token(self):
        route = respx.post(f"{BASE}/federation/v1/heartbeat").mock(
            return_value=httpx.Response(200, json={
                "ack": True, "serverTime": "2026-03-31T00:05:00Z",
                "bearerToken": "bt-new", "bearerTokenExpiresAt": "2026-04-01T00:00:00Z",
                "revocations": [],
            })
        )

        with AgledgerClient(api_key="gw_bearer") as client:
            client.federation.heartbeat(
                gateway_id="gw-001",
                agent_count=5,
                mandate_count=10,
                timestamp="2026-03-31T00:05:00Z",
            )

        assert route.calls[0].request.headers["Authorization"] == "Bearer gw_bearer"

    @respx.mock
    def test_register_agent(self):
        respx.post(f"{BASE}/federation/v1/agents").mock(
            return_value=httpx.Response(201, json={"registered": True})
        )

        with AgledgerClient(api_key="gw_token") as client:
            result = client.federation.register_agent(
                agent_id="agent-001",
                contract_types=["ACH-PROC-v1"],
            )

        assert result["registered"] is True

    @respx.mock
    def test_list_agents_with_filter(self):
        respx.get(f"{BASE}/federation/v1/agents").mock(
            return_value=httpx.Response(200, json={
                "data": [{"agentId": "a1", "gatewayId": "gw-1", "contractTypes": [], "displayName": None, "registeredAt": "2026-03-31T00:00:00Z"}],
                "nextCursor": "cursor-abc",
                "hasMore": True,
            })
        )

        with AgledgerClient(api_key="gw_token") as client:
            result = client.federation.list_agents(contract_type="ACH-PROC-v1", limit=10)

        assert len(result["data"]) == 1

    @respx.mock
    def test_revoke_sends_no_auth_header(self):
        route = respx.post(f"{BASE}/federation/v1/gateways/gw-001/revoke").mock(
            return_value=httpx.Response(200, json={"revoked": True, "revokedAt": "2026-03-31T00:00:00Z"})
        )

        with AgledgerClient(api_key="unused") as client:
            result = client.federation.revoke("gw-001", revocation_secret="secret16chars!!!", reason="key_compromise")

        assert result["revoked"] is True
        assert "Authorization" not in route.calls[0].request.headers

    @respx.mock
    def test_catch_up(self):
        respx.get(f"{BASE}/federation/v1/catch-up").mock(
            return_value=httpx.Response(200, json={"data": [], "hasMore": False})
        )

        with AgledgerClient(api_key="gw_token") as client:
            result = client.federation.catch_up(since_position=42, limit=50)

        assert result["hasMore"] is False


# ---------------------------------------------------------------------------
# FederationAdminResource (Platform Operations)
# ---------------------------------------------------------------------------


class TestFederationAdminResource:
    @respx.mock
    def test_create_registration_token(self):
        respx.post(f"{BASE}/federation/v1/admin/registration-tokens").mock(
            return_value=httpx.Response(201, json={"token": "tok-abc", "expiresAt": "2026-04-01T00:00:00Z"})
        )

        with AgledgerClient(api_key="admin_key") as client:
            result = client.federation_admin.create_registration_token(label="Test GW", expires_in_hours=24)

        assert result["token"] == "tok-abc"

    @respx.mock
    def test_list_gateways(self):
        respx.get(f"{BASE}/federation/v1/admin/gateways").mock(
            return_value=httpx.Response(200, json={"data": [], "total": 0})
        )

        with AgledgerClient(api_key="admin_key") as client:
            result = client.federation_admin.list_gateways(status="active")

        assert result["total"] == 0

    @respx.mock
    def test_revoke_gateway(self):
        respx.post(f"{BASE}/federation/v1/admin/gateways/gw-001/revoke").mock(
            return_value=httpx.Response(200, json={"revoked": True, "nextSteps": []})
        )

        with AgledgerClient(api_key="admin_key") as client:
            result = client.federation_admin.revoke_gateway("gw-001", reason="Compromised")

        assert result["revoked"] is True

    @respx.mock
    def test_query_mandates(self):
        respx.get(f"{BASE}/federation/v1/admin/mandates").mock(
            return_value=httpx.Response(200, json={"data": [], "total": 0})
        )

        with AgledgerClient(api_key="admin_key") as client:
            result = client.federation_admin.query_mandates(hub_state="ACTIVE")

        assert result["total"] == 0

    @respx.mock
    def test_get_health(self):
        respx.get(f"{BASE}/federation/v1/admin/health").mock(
            return_value=httpx.Response(200, json={
                "gateways": {"active": 2, "suspended": 0, "revoked": 1},
                "mandates": {"ACTIVE": 5},
                "auditChainLength": 100,
                "lastAuditEntry": "2026-03-31T00:00:00Z",
            })
        )

        with AgledgerClient(api_key="admin_key") as client:
            result = client.federation_admin.get_health()

        assert result["gateways"]["active"] == 2

    @respx.mock
    def test_reset_sequence(self):
        respx.post(f"{BASE}/federation/v1/admin/gateways/gw-001/reset-seq").mock(
            return_value=httpx.Response(200, json={"reset": True, "nextSteps": []})
        )

        with AgledgerClient(api_key="admin_key") as client:
            result = client.federation_admin.reset_sequence("gw-001", new_seq=100)

        assert result["reset"] is True

    @respx.mock
    def test_list_dlq(self):
        respx.get(f"{BASE}/federation/v1/admin/outbound-dlq").mock(
            return_value=httpx.Response(200, json={"data": [], "hasMore": False})
        )

        with AgledgerClient(api_key="admin_key") as client:
            result = client.federation_admin.list_dlq(limit=25)

        assert result["hasMore"] is False

    @respx.mock
    def test_retry_dlq(self):
        respx.post(f"{BASE}/federation/v1/admin/outbound-dlq/dlq-001/retry").mock(
            return_value=httpx.Response(200, json={"retried": True, "nextSteps": []})
        )

        with AgledgerClient(api_key="admin_key") as client:
            result = client.federation_admin.retry_dlq("dlq-001")

        assert result["retried"] is True

    @respx.mock
    def test_delete_dlq(self):
        respx.delete(f"{BASE}/federation/v1/admin/outbound-dlq/dlq-001").mock(
            return_value=httpx.Response(200, json={"deleted": True})
        )

        with AgledgerClient(api_key="admin_key") as client:
            result = client.federation_admin.delete_dlq("dlq-001")

        assert result["deleted"] is True
