import requests
import json
import time
import re
from datetime import datetime, timezone
from typing import Optional, Dict, List
import pytz  # Import pytz to handle timezone conversions
import sys
import os
import argparse

from psycopg2.extras import execute_values

base_dir = os.path.dirname(os.path.abspath(__file__))
common_dir = os.path.join(base_dir, "common")
if not os.path.isdir(common_dir):
    # go up one level to find "common" (for installed package structure)
    base_dir = os.path.dirname(base_dir)
    common_dir = os.path.join(base_dir, "common")

if os.path.isdir(common_dir) and base_dir not in sys.path:
    sys.path.insert(0, base_dir)

from common.utils import Utils
import logging

# Configure logging to print messages on stdout
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s', stream=sys.stdout)

# GitHub and CI/CD API details - Configuration will be loaded from database
repos = None
repo_owner = None
personal_access_token = None
headers = None
valid_workflow_names = None


class GitHubActionsExtractor:
    """Extracts build events from GitHub Actions."""

    def __init__(self):
        self.stats = {
            'build_events_inserted': 0,
            'build_events_duplicates': 0,
            'deployment_events_inserted': 0,
            'deployment_events_duplicates': 0,
        }

    def get_config_from_database(self, cursor):
        """Fetch GitHub Actions configuration from data_source_config table."""
        cursor.execute("""
            SELECT config_item, config_value
            FROM data_source_config
            WHERE data_source = 'integration_and_build'
            AND config_item IN ('Organization', 'Repos', 'Personal Access Token', 'Workflows', 'Build Stage Pattern', 'Include Repos')
        """)

        config = {}
        for row in cursor.fetchall():
            config_item, config_value = row
            if config_item == 'Include Repos':
                config['include_repos'] = Utils.to_bool(config_value, default=True)
            else:
                config[config_item] = config_value

        return config

    def _fetch_all_repos(self, owner: str, api_token: str) -> List[str]:
        """Fetch all repositories for a GitHub organization."""
        _logger = logging.getLogger(__name__)
        all_repos = []
        page = 1
        max_retries = 3
        retry_delay = 5
        request_headers = {
            'Authorization': f'Bearer {api_token}',
            'Accept': 'application/vnd.github.v3+json'
        }
        while True:
            url = f'https://api.github.com/orgs/{owner}/repos'
            params = {'per_page': 100, 'page': page}
            attempt = 0
            while attempt < max_retries:
                try:
                    response = requests.get(url, headers=request_headers, params=params, timeout=30)
                except requests.RequestException as e:
                    _logger.warning(f'Network error fetching repos page {page} for org {owner}: {e}')
                    attempt += 1
                    if attempt < max_retries:
                        time.sleep(retry_delay * (2 ** attempt))
                    continue
                if response.status_code == 200:
                    data = response.json()
                    if not isinstance(data, list) or not data:
                        return all_repos
                    all_repos.extend([r.get('name') for r in data if r.get('name')])
                    if len(data) < 100:
                        return all_repos
                    page += 1
                    break
                elif response.status_code == 404:
                    return all_repos
                elif response.status_code in (401, 403):
                    Utils.fatal(
                        Utils.format_http_error(
                            'GET', response.url, response.status_code,
                            getattr(response, 'reason', '') or '',
                            response.text, response.headers.get('Content-Type'),
                        ),
                        context='_fetch_all_repos',
                        logger=_logger,
                    )
                elif response.status_code == 429:
                    wait = int(response.headers.get('Retry-After', 60))
                    _logger.warning(f'Rate limit exceeded fetching repos for org {owner}. Waiting {wait}s...')
                    time.sleep(wait)
                    continue
                elif 500 <= response.status_code < 600:
                    _logger.warning(
                        Utils.format_http_error(
                            'GET', response.url, response.status_code,
                            getattr(response, 'reason', '') or '',
                            response.text, response.headers.get('Content-Type'),
                        )
                    )
                    attempt += 1
                    if attempt < max_retries:
                        time.sleep(retry_delay * (2 ** attempt))
                    continue
                else:
                    _logger.warning(
                        Utils.format_http_error(
                            'GET', response.url, response.status_code,
                            getattr(response, 'reason', '') or '',
                            response.text, response.headers.get('Content-Type'),
                        )
                    )
                    return all_repos
            else:
                # All retries exhausted for this page
                _logger.warning(f'All retries exhausted fetching repos page {page} for org {owner}')
                return all_repos
        return all_repos

    def get_last_modified_date(self, cursor) -> Optional[datetime]:
        """Get the last modified date from the database."""
        query = "SELECT MAX(timestamp_utc) FROM build_event"
        cursor.execute(query)
        result = cursor.fetchone()
        if result[0]:
            # Convert to naive datetime if timezone-aware
            dt = result[0]
            if dt.tzinfo is not None:
                dt = dt.replace(tzinfo=None)
            return dt
        else:
            return datetime(2000, 1, 1)

    def run_extraction(self, cursor, config: Dict, start_date: Optional[str], last_modified: Optional[datetime], export_path: str = None, product_name: Optional[str] = None):
        """
        Run extraction: fetch and save data.

        Args:
            cursor: Database cursor (None for CSV mode)
            config: Configuration dictionary
            start_date: Start date from command line (optional)
            last_modified: Last modified datetime from database or checkpoint
            export_path: Export path for CSV mode
        """
        # Track maximum timestamp for checkpoint saving
        max_timestamp = None

        # Set up global variables from configuration (needed by fetch_builds)
        global repo_owner, repos, personal_access_token, headers, valid_workflow_names
        repo_owner = config.get('Organization')

        # Parse selected repositories
        repos_config = config.get('Repos', '')
        if repos_config:
            try:
                selected_repos = json.loads(repos_config)
            except (json.JSONDecodeError, TypeError):
                selected_repos = repos_config.split(',')
        else:
            selected_repos = []
        selected_repos = [r.strip() for r in selected_repos if str(r).strip()]

        personal_access_token = config.get('Personal Access Token')
        include_repos = config.get('include_repos', True)

        # Parse workflows
        workflows_config = config.get('Workflows', '')
        if workflows_config:
            try:
                valid_workflow_names = json.loads(workflows_config)
            except (json.JSONDecodeError, TypeError):
                valid_workflow_names = workflows_config.split(',')
        else:
            valid_workflow_names = []

        # Validate required credentials
        if not repo_owner or not personal_access_token:
            Utils.fatal(
                "Missing required configuration: Organization / Personal Access Token",
                context="run_extraction",
            )

        # Resolve repo list based on include/exclude mode
        if include_repos:
            if not selected_repos:
                Utils.fatal(
                    "Include Repos is enabled but no repositories are configured.",
                    context="run_extraction",
                )
            repos = selected_repos
        else:
            selected_repo_set = set(selected_repos)
            repos = [r for r in self._fetch_all_repos(repo_owner, personal_access_token) if r not in selected_repo_set]
            if not repos:
                Utils.fatal("No repositories resolved for extraction", context="run_extraction")

        logging.info(f"Repositories to process: {repos}")

        # Set up headers
        headers = {
            'Authorization': f'Bearer {personal_access_token}',
            'Accept': 'application/vnd.github.v3+json'
        }

        # Determine start date
        if start_date:
            try:
                extraction_start_date = datetime.strptime(start_date, '%Y-%m-%d')
                # Convert to naive UTC datetime
                if extraction_start_date.tzinfo is not None:
                    extraction_start_date = extraction_start_date.astimezone(pytz.utc).replace(tzinfo=None)
                else:
                    # Ensure naive datetime
                    extraction_start_date = extraction_start_date.replace(tzinfo=None)
            except ValueError:
                Utils.fatal(
                    "Invalid date format. Please use YYYY-MM-DD format.",
                    context="run_extraction",
                )
        else:
            if last_modified:
                # Convert to naive datetime if timezone-aware
                if last_modified.tzinfo is not None:
                    last_modified = last_modified.replace(tzinfo=None)
                extraction_start_date = last_modified
            else:
                extraction_start_date = datetime(2000, 1, 1)

        # Load stage→environment mapping for deployment events (DB mode only)
        deploy_event_mapping = get_deploy_event_mapping(cursor) if cursor else None

        # Set up save function
        if cursor:
            # Database mode

            def save_output_fn(build_data_list):
                if not build_data_list:
                    return 0, 0, 0

                try:
                    data_count, inserted_count, duplicate_count = insert_build_data_batch(
                        cursor, build_data_list
                    )
                    self.stats['build_events_inserted'] += inserted_count
                    self.stats['build_events_duplicates'] += duplicate_count

                    if deploy_event_mapping:
                        deployment_events = derive_deployment_events_from_build_data(
                            build_data_list, deploy_event_mapping
                        )
                        if deployment_events:
                            deploy_inserted, deploy_duplicates = save_deployment_events(
                                deployment_events, cursor
                            )
                            self.stats['deployment_events_inserted'] += deploy_inserted
                            self.stats['deployment_events_duplicates'] += deploy_duplicates

                    cursor.connection.commit()
                except Exception:
                    cursor.connection.rollback()
                    raise

                return data_count, inserted_count, duplicate_count
        else:
            # CSV mode - create CSV file lazily
            build_csv_file = None

            def save_output_fn(build_data_list):
                nonlocal build_csv_file, max_timestamp

                if not build_data_list:
                    return 0, 0, 0

                # Convert tuples to dictionaries for CSV
                # Tuple format: (source_branch, repo, event, timestamp_utc, actor, workflow_name, build_number, build_id, comment)
                build_events = []
                for build_tuple in build_data_list:
                    timestamp_utc = build_tuple[3]
                    # Convert to naive UTC datetime if needed
                    if timestamp_utc:
                        if isinstance(timestamp_utc, datetime):
                            if timestamp_utc.tzinfo is not None:
                                timestamp_utc = timestamp_utc.astimezone(pytz.utc).replace(tzinfo=None)
                        else:
                            timestamp_utc = datetime.fromisoformat(str(timestamp_utc).replace('Z', '+00:00'))
                            if timestamp_utc.tzinfo is not None:
                                timestamp_utc = timestamp_utc.astimezone(pytz.utc).replace(tzinfo=None)

                    build_event_dict = {
                        'timestamp_utc': timestamp_utc,
                        'event': build_tuple[2],
                        'repo': build_tuple[1] if build_tuple[1] else '',
                        'source_branch': build_tuple[0],
                        'workflow_name': build_tuple[5],
                        'build_number': build_tuple[6],
                        'comment': build_tuple[8],
                        'actor': build_tuple[4],
                        'build_id': build_tuple[7]
                    }
                    build_events.append(build_event_dict)

                # Create CSV file lazily when first events arrive
                if build_events and not build_csv_file:
                    build_csv_file = Utils.create_csv_file("github_actions_build_events", export_path, logging)

                # Save build events
                build_max_ts = None
                if build_events:
                    result = Utils.save_events_to_csv(build_events, build_csv_file, logging, checkpoint_prefix="github_actions", export_path=export_path)
                    if len(result) > 3 and result[3]:
                        build_max_ts = result[3]

                # Track maximum timestamp for checkpoint
                if build_max_ts and (not max_timestamp or build_max_ts > max_timestamp):
                    max_timestamp = build_max_ts

                return len(build_events), 0, 0

        # Read build stage pattern from database (if in database mode)
        build_event_regex = None
        if cursor:
            try:
                cursor.execute("""
                    SELECT config_value
                    FROM data_source_config
                    WHERE data_source = 'integration_and_build'
                    AND config_item = 'Build Stage Pattern'
                """)
                result = cursor.fetchone()
                if result and result[0]:
                    build_event_pattern = result[0].strip() or None
                    if build_event_pattern:
                        try:
                            # Handle escaped backslashes from database
                            build_event_pattern = build_event_pattern.replace("\\\\", "\\")
                            build_event_regex = re.compile(build_event_pattern, re.IGNORECASE)
                            logging.info(f"Loaded build event regex pattern: {build_event_pattern}")
                        except re.error as e:
                            logging.warning(f"Invalid build event regex pattern: {build_event_pattern}, error: {e}")
                            build_event_regex = None
            except Exception as e:
                logging.warning(f"Failed to read build stage pattern from data_source_config: {e}")
                build_event_regex = None

        # Read release branch patterns from product table (if in database mode)
        release_branch_pattern_regex = None
        release_branch_source = None
        if cursor and product_name:
            try:
                cursor.execute("SELECT regex_configuration FROM product WHERE product_name = %s", (product_name,))
                result = cursor.fetchone()
                regex_config = result[0] if result else None
                if regex_config:
                    pattern_str = regex_config.get('release_branch_pattern', None)
                    if pattern_str:
                        try:
                            release_branch_pattern_regex = re.compile(pattern_str)
                            logging.info(f"Loaded release_branch_pattern: {pattern_str}")
                        except re.error as e:
                            logging.warning(f"Invalid release_branch_pattern: {pattern_str}, error: {e}")
                    release_branch_source = regex_config.get('release_branch_source', None)
                    if release_branch_source:
                        logging.info(f"Loaded release_branch_source: {release_branch_source}")
            except Exception as e:
                logging.warning(f"Failed to read release branch patterns from product table: {e}")

        # Log the fetch information
        logging.info(f"Workflow names: {valid_workflow_names}")
        logging.info(f"Starting extraction from {extraction_start_date}")

        # Fetch builds for each repository
        for repo in repos:
            repo = repo.strip()  # Remove any whitespace
            logging.info(f"Fetching data from https://api.github.com/repos/{repo_owner}/{repo}")

            try:
                # Fetch builds and get actual counts
                build_data_list = fetch_builds(repo, extraction_start_date, build_event_regex, release_branch_pattern_regex, release_branch_source)

                if build_data_list:
                    # Save events
                    save_output_fn(build_data_list)

            except Exception as e:
                logging.error(f"Error processing repository {repo}: {str(e)}")
                continue

        # Print summary
        if cursor:
            logging.info(
                f"Build events: inserted {self.stats['build_events_inserted']}, "
                f"skipped {self.stats['build_events_duplicates']} duplicates"
            )
            logging.info(
                f"Deployment events: inserted {self.stats['deployment_events_inserted']}, "
                f"skipped {self.stats['deployment_events_duplicates']} duplicates"
            )
        else:
            logging.info(f"Extraction completed")


# Function to safely extract data and handle missing or invalid fields
def safe_get(data, keys, default_value='NULL'):
    try:
        for key in keys:
            data = data[key]
        return data
    except (KeyError, TypeError):
        return default_value


def _insert_rows_chunked(cursor, insert_sql, rows, chunk_size=1000):
    """
    Bulk insert with execute_values in bounded chunks.
    Uses page_size=len(chunk) per chunk so cursor.rowcount is accurate, and avoids a
    single oversized INSERT when fetch_builds returns many rows for one repo.
    """
    if not rows:
        return 0

    inserted = 0
    for offset in range(0, len(rows), chunk_size):
        chunk = rows[offset:offset + chunk_size]
        execute_values(cursor, insert_sql, chunk, template=None, page_size=len(chunk))
        rowcount = cursor.rowcount
        if rowcount is not None and rowcount >= 0:
            inserted += rowcount
    return inserted

# Function to insert build data into the build_event table using batch insertion
def insert_build_data_batch(cursor, build_data_list):
    """Insert build data into the database using batch insertion."""
    if not build_data_list:
        return 0, 0, 0

    columns = [
        'source_branch', 'repo', 'event', 'timestamp_utc', 'actor', 'workflow_name', 'build_number', 'build_id', 'comment'
    ]
    insert_sql = f"INSERT INTO build_event ({', '.join(columns)}) VALUES %s ON CONFLICT DO NOTHING"

    inserted_count = _insert_rows_chunked(cursor, insert_sql, build_data_list)

    duplicate_count = len(build_data_list) - inserted_count

    return len(build_data_list), inserted_count, duplicate_count


def get_deploy_event_mapping(cursor):
    """Load stage→environment mapping from environment_mapping (same as load script)."""
    try:
        cursor.execute("""
            SELECT stage_name, environment
            FROM environment_mapping
            WHERE stage_name IS NOT NULL AND job_name IS NULL
        """)
        result = cursor.fetchall()
        if not result:
            return None
        deploy_event_mapping = {}
        for stage_name, environment in result:
            if stage_name and environment:
                deploy_event_mapping[stage_name.lower()] = environment
        return deploy_event_mapping or None
    except Exception as e:
        logging.warning(f"Failed to read stage to env map from environment_mapping: {e}")
        return None


def _parse_job_comment(comment):
    """Parse job comment JSON from fetch_builds(); returns None on empty/invalid input."""
    if not comment:
        return None
    try:
        data = json.loads(comment)
        return data if isinstance(data, dict) else None
    except (json.JSONDecodeError, AttributeError, TypeError):
        return None


def _commit_sha_from_build_row(build_id, comment_data=None, comment=None):
    """
    Resolve the Git commit SHA for deployment_event.build_id.

    build_id in the build tuple may be a release/version string when release branches
    are configured; the actual SHA is stored as git_sha in the job comment JSON.
    """
    if comment_data is None:
        comment_data = _parse_job_comment(comment)
    if comment_data:
        git_sha = comment_data.get('git_sha') or ''
        if git_sha:
            return git_sha
    return build_id or ''


def _job_succeeded(comment_data):
    """True when GitHub job comment indicates success (status or conclusion)."""
    if not comment_data:
        return False
    stage_status = (comment_data.get('status') or '').upper()
    if stage_status in ('SUCCESS', 'SUCCESSFUL', 'PASSED'):
        return True
    conclusion = (comment_data.get('conclusion') or '').upper()
    return conclusion in ('SUCCESS', 'SUCCESSFUL', 'PASSED')


def derive_deployment_events_from_build_data(build_data_list, deploy_event_mapping):
    """
    Derive Deployed events from build rows using stage→environment mapping.
    Mirrors load_build_and_deployment_event._parse_build_format deployment logic.
    """
    if not deploy_event_mapping or not build_data_list:
        return []

    deployment_events = []
    for row in build_data_list:
        source_branch, repo, event_name, timestamp_utc, _actor, _workflow_name, build_number, build_id, comment = row
        stage_name = event_name
        if not stage_name or stage_name in ('Build Created', 'Build Failed'):
            continue

        comment_data = _parse_job_comment(comment)
        if not _job_succeeded(comment_data):
            continue

        environment = deploy_event_mapping.get(stage_name.lower())
        if environment:
            deployment_events.append({
                'created_at': timestamp_utc,
                'event_type': 'Deployed',
                'target_iid': str(build_number) if build_number is not None else '',
                'repo_name': repo or '',
                'branch_name': source_branch or '',
                'commit_sha': _commit_sha_from_build_row(build_id, comment_data=comment_data),
                'comment': comment or '',
                'environment': environment,
            })

    return deployment_events


def save_deployment_events(events, cursor):
    """Save deployment events to deployment_event table."""
    if not events:
        return 0, 0

    values = []
    for event in events:
        values.append((
            event.get('created_at'),
            event.get('event_type'),
            event.get('target_iid', ''),
            event.get('repo_name', ''),
            event.get('branch_name', ''),
            event.get('commit_sha', ''),
            event.get('comment', ''),
            event.get('environment', ''),
            None,
            '',
        ))

    insert_query = """
    INSERT INTO deployment_event (
        timestamp_utc, event, build_name, repo, source_branch, build_id,
        comment, environment, is_major_release, release_version
    ) VALUES %s
    ON CONFLICT ON CONSTRAINT deployment_event_hash_unique DO NOTHING
    """
    inserted_count = _insert_rows_chunked(cursor, insert_query, values)

    duplicate_count = len(events) - inserted_count
    return inserted_count, duplicate_count


# Function to fetch jobs for a specific workflow run
def fetch_jobs_for_run(repo, run_id) -> List[Dict]:
    """Fetch all jobs for a specific workflow run."""
    jobs_url = f"https://api.github.com/repos/{repo_owner}/{repo}/actions/runs/{run_id}/jobs?per_page=100"
    all_jobs = []

    while jobs_url:
        max_retries = 3
        retry_delay = 1

        for attempt in range(max_retries):
            try:
                logging.info(f"Fetching jobs from: {jobs_url}")
                response = requests.get(jobs_url, headers=headers, timeout=30)

                if response.status_code == 200:
                    data = response.json()
                    jobs = data.get('jobs', [])
                    all_jobs.extend(jobs)

                    # Check for pagination
                    if 'next' in response.links:
                        jobs_url = response.links['next']['url']
                    else:
                        jobs_url = None
                    break

                elif response.status_code == 429:
                    # Rate limit exceeded
                    if 'Retry-After' in response.headers:
                        wait_time = int(response.headers['Retry-After'])
                        logging.warning(f"Rate limit exceeded. Waiting {wait_time} seconds...")
                        time.sleep(wait_time)
                        continue
                    else:
                        logging.warning("Rate limit exceeded for GitHub Actions jobs API")
                        jobs_url = None
                        break
                else:
                    if response.status_code in (401, 403, 404):
                        Utils.fatal(
                            Utils.format_http_error(
                                "GET",
                                response.url,
                                response.status_code,
                                getattr(response, "reason", "") or "",
                                response.text,
                                response.headers.get("Content-Type"),
                            ),
                            context="fetch_jobs_for_run",
                            logger=logging.getLogger(__name__),
                        )
                    logging.warning(
                        Utils.format_http_error(
                            "GET",
                            response.url,
                            response.status_code,
                            getattr(response, "reason", "") or "",
                            response.text,
                            response.headers.get("Content-Type"),
                        )
                    )
                    if attempt < max_retries - 1:
                        time.sleep(retry_delay * (2 ** attempt))
                        continue
                    else:
                        Utils.fatal(
                            Utils.format_http_error(
                                "GET",
                                response.url,
                                response.status_code,
                                getattr(response, "reason", "") or "",
                                response.text,
                                response.headers.get("Content-Type"),
                            ),
                            context="fetch_jobs_for_run",
                            logger=logging.getLogger(__name__),
                        )

            except requests.RequestException as e:
                logging.warning(f"Request failed for jobs (attempt {attempt + 1}): {e}")
                if attempt < max_retries - 1:
                    time.sleep(retry_delay * (2 ** attempt))
                    continue
                else:
                    Utils.fatal(
                        f"GitHub Actions jobs API request failed after retries for run {run_id}: {e}",
                        context="fetch_jobs_for_run",
                        logger=logging.getLogger(__name__),
                    )
        else:
            # All retries exhausted without break
            Utils.fatal(
                f"GitHub Actions jobs API retries exhausted for run {run_id}",
                context="fetch_jobs_for_run",
                logger=logging.getLogger(__name__),
            )

    return all_jobs


# Function to fetch build from CI/CD system with If-Modified-Since header
def fetch_builds(repo, last_modified_date, build_event_regex=None, release_branch_pattern_regex=None, release_branch_source=None):
    # Format the last modified date to the proper HTTP date format
    if_modified_since = last_modified_date.strftime("%a, %d %b %Y %H:%M:%S GMT")
    headers['If-Modified-Since'] = if_modified_since

    builds_url = f"https://api.github.com/repos/{repo_owner}/{repo}/actions/runs?per_page=100"
    build_data_list = []

    while builds_url:
        # Retry logic for failed requests
        max_retries = 3
        retry_delay = 1  # seconds

        for attempt in range(max_retries):
            try:
                logging.info(f"Fetching workflow runs from: {builds_url}")
                response = requests.get(builds_url, headers=headers, timeout=30)

                if response.status_code == 200:
                    builds = response.json()
                    break
                elif response.status_code == 304:
                    # Not modified since last check
                    logging.info(f"No new builds since {last_modified_date}.")
                    return build_data_list
                elif response.status_code == 429:
                    # Rate limit exceeded
                    if 'Retry-After' in response.headers:
                        wait_time = int(response.headers['Retry-After'])
                        logging.warning(f"Rate limit exceeded. Waiting {wait_time} seconds...")
                        time.sleep(wait_time)
                        continue
                    else:
                        logging.warning("Rate limit exceeded for GitHub Actions")
                        return build_data_list
                else:
                    if response.status_code in (401, 403, 404):
                        Utils.fatal(
                            Utils.format_http_error(
                                "GET",
                                response.url,
                                response.status_code,
                                getattr(response, "reason", "") or "",
                                response.text,
                                response.headers.get("Content-Type"),
                            ),
                            context="fetch_builds",
                            logger=logging.getLogger(__name__),
                        )
                    logging.warning(
                        Utils.format_http_error(
                            "GET",
                            response.url,
                            response.status_code,
                            getattr(response, "reason", "") or "",
                            response.text,
                            response.headers.get("Content-Type"),
                        )
                    )
                    if attempt < max_retries - 1:
                        time.sleep(retry_delay * (2 ** attempt))  # Exponential backoff
                        continue
                    else:
                        Utils.fatal(
                            Utils.format_http_error(
                                "GET",
                                response.url,
                                response.status_code,
                                getattr(response, "reason", "") or "",
                                response.text,
                                response.headers.get("Content-Type"),
                            ),
                            context="fetch_builds",
                            logger=logging.getLogger(__name__),
                        )

            except requests.RequestException as e:
                logging.warning(f"Request failed for GitHub Actions runs (attempt {attempt + 1}): {e}")
                if attempt < max_retries - 1:
                    time.sleep(retry_delay * (2 ** attempt))  # Exponential backoff
                    continue
                else:
                    Utils.fatal(
                        f"GitHub Actions runs API request failed after retries: {e}",
                        context="fetch_builds",
                        logger=logging.getLogger(__name__),
                    )
            except Exception as ex:
                logging.error(f"Error fetching GitHub Actions runs: {ex}")
                Utils.fatal(
                    f"GitHub Actions runs API unexpected error: {ex}",
                    context="fetch_builds",
                    logger=logging.getLogger(__name__),
                )
        else:
            Utils.fatal(
                "GitHub Actions runs API retries exhausted",
                context="fetch_builds",
                logger=logging.getLogger(__name__),
            )

        # Process the workflow runs from the response
        for build in builds['workflow_runs']:
            workflow_name = safe_get(build, ['name'], 'NULL')
            # Skip builds that don't match the valid workflow names
            if valid_workflow_names and workflow_name not in valid_workflow_names:
                continue

            # Check run's updated_at BEFORE fetching jobs (expensive API call)
            run_updated_at = build.get('updated_at')
            if run_updated_at:
                try:
                    run_dt = datetime.fromisoformat(str(run_updated_at).replace('Z', '+00:00'))
                    if run_dt.tzinfo is not None:
                        run_dt = run_dt.astimezone(timezone.utc).replace(tzinfo=None)
                    # Skip runs not updated since last extraction
                    if run_dt <= last_modified_date:
                        continue
                except (ValueError, TypeError):
                    pass

            # Get run-level data
            run_id = safe_get(build, ['id'], None)
            branch = safe_get(build, ['head_branch'], None)
            release_str = None
            if release_branch_pattern_regex and branch:
                match = release_branch_pattern_regex.search(branch)
                if match:
                    release_str = match.group(1) if match.lastindex and match.lastindex >= 1 else match.group(0)
            if release_str is None and release_branch_source and branch == release_branch_source:
                release_str = "0.0"
            build_number = safe_get(build, ['run_number'], None)
            commit_sha = safe_get(build, ['head_sha'], None)  # Full SHA for join key
            short_sha = commit_sha[:7] if len(commit_sha) >= 7 else safe_get(commit_sha)
            actor = safe_get(build, ['actor', 'login'], None)

            # Skip if no run_id
            if not run_id:
                continue

            # Fetch jobs for this workflow run
            jobs = fetch_jobs_for_run(repo, run_id)

            # Track deduplication: (repo, workflow_name, build_number) combinations that have already matched
            build_created_repo_workflow_build_numbers = set()

            for job in jobs:
                # Get job name - this goes in 'event' column
                job_name = job.get('name')
                if not job_name:
                    continue

                # Get timestamp: MUST have completed_at (only include completed jobs)
                completed_at = job.get('completed_at')
                if not completed_at:
                    continue  # Skip jobs that haven't completed

                # Convert completed_at to naive UTC datetime
                try:
                    timestamp_utc = datetime.fromisoformat(str(completed_at).replace('Z', '+00:00'))
                    if timestamp_utc.tzinfo is not None:
                        timestamp_utc = timestamp_utc.astimezone(timezone.utc).replace(tzinfo=None)
                except (ValueError, TypeError):
                    continue

                # Skip jobs older than the last known modification date
                if timestamp_utc <= last_modified_date:
                    continue

                # Get job conclusion (success, failure, cancelled, etc.)
                conclusion = job.get('conclusion', '').lower()

                # Build comment as JSON with useful metadata
                comment_data = {
                    'job_id': job.get('id'),
                    'run_id': run_id,
                    'conclusion': job.get('conclusion'),
                    'status': job.get('status'),
                    'started_at': job.get('started_at'),
                    'git_sha': commit_sha
                }
                comment = json.dumps(comment_data)

                # Determine event name based on build stage pattern matching
                event_name = job_name  # Default to job name
                
                # Check if job name matches build event pattern
                if build_event_regex and job_name:
                    if build_event_regex.search(job_name):
                        # Create unique key for this (repo, workflow_name, build_number) combination
                        repo_workflow_build_key = (repo or '', workflow_name, build_number)
                        
                        # Only create "Build Created" or "Build Failed" event if we haven't already created one for this (repo, workflow_name, build_number)
                        if repo_workflow_build_key not in build_created_repo_workflow_build_numbers:
                            if conclusion == 'success':
                                event_name = 'Build Created'
                                build_created_repo_workflow_build_numbers.add(repo_workflow_build_key)
                            elif conclusion == 'failure':
                                event_name = 'Build Failed'
                                build_created_repo_workflow_build_numbers.add(repo_workflow_build_key)
                            # For other conclusions (cancelled, skipped, etc.), keep job_name as event
                            # Note: We don't add to the set for cancelled/skipped, so a later matching job with success/failure can still create an event

                if not release_str:
                    build_id = commit_sha
                else:
                    date_str = timestamp_utc.date().isoformat()
                    build_id = f"{release_str}.{build_number}-{date_str}-{short_sha}"

                build_data = (
                    branch,
                    repo,
                    event_name,  # Event name (may be "Build Created", "Build Failed", or job_name)
                    timestamp_utc,
                    actor,
                    workflow_name,
                    build_number,
                    build_id,
                    comment
                )
                build_data_list.append(build_data)

        # Check for pagination
        if 'next' in response.links:
            builds_url = response.links['next']['url']
        else:
            builds_url = None  # No more pages to fetch

    return build_data_list


# Main Execution: Fetching data for each repo and writing to the database
def main():
    parser = argparse.ArgumentParser(description="Add new events in the build_event table.")

    parser.add_argument('-p', '--product', type=str, help='Product name (if provided, saves to database; otherwise saves to CSV)')
    parser.add_argument('-s', '--start-date', type=str, help='Start date in YYYY-MM-DD format')
    args = parser.parse_args()

    extractor = GitHubActionsExtractor()

    if args.product is None:
        # CSV Mode: Load configuration from config.json
        config = json.load(open(os.path.join(common_dir, "config.json")))
        
        # Get configuration from config dictionary
        repos_str = config.get("GITHUB_REPOS", '')
        repos_list = [repo.strip() for repo in repos_str.split(",") if repo.strip()] if repos_str else []

        workflows_str = config.get("GITHUB_WORKFLOWS", '')
        workflows_list = [wf.strip() for wf in workflows_str.split(",") if wf.strip()] if workflows_str else []

        config = {
            'Organization': config.get('GITHUB_ORGANIZATION'),
            'Repos': json.dumps(repos_list) if repos_list else '',
            'Personal Access Token': config.get('GITHUB_API_TOKEN'),
            'Workflows': json.dumps(workflows_list) if workflows_list else '',
            'include_repos': Utils.to_bool(config.get('GITHUB_ACTIONS_INCLUDE_REPOS'), default=True),
        }

        # Use checkpoint file for last modified date
        last_modified = Utils.load_checkpoint("github_actions")

        extractor.run_extraction(None, config, args.start_date, last_modified)

    else:
        # Database Mode: Connect to the database
        from database import DatabaseConnection
        db = DatabaseConnection()
        with db.product_scope(args.product) as conn:
            with conn.cursor() as cursor:
                config = extractor.get_config_from_database(cursor)
                last_modified = extractor.get_last_modified_date(cursor)
                extractor.run_extraction(cursor, config, args.start_date, last_modified, product_name=args.product)

    return 0


# Run the main function
if __name__ == '__main__':
    exit_code = main()
    sys.exit(exit_code)
