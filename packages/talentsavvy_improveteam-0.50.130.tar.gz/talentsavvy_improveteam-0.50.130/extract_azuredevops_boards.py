#!/usr/bin/env python3
"""
Azure DevOps Boards Data Extraction Script

This script extracts work item events from Azure DevOps Boards and supports two modes of operation:

Usage:
    python extract_azuredevops_boards.py [-p <product_name>] [-s <start_date>]

Arguments:
    -p, --product: Product name (if provided, saves to database; otherwise saves to CSV)
    -s, --start-date: Start date for extraction in YYYY-MM-DD format (optional)

Modes (automatically determined):
    Database mode (when -p is provided):
        - Imports from the database module
        - Connects to the database
        - Reads the config from the data_source_config table
        - Gets the last extraction timestamp from the work_item_event table
        - Saves the extracted data to the database table

    CSV mode (when -p is NOT provided):
        - Reads the config from config.json:
          * AZDO_ORGANIZATION: Azure DevOps organization
          * AZDO_API_TOKEN: Azure DevOps API token
          * AZDO_PROJECT: Azure DevOps project name
          * AZDO_WORK_ITEM_ATTRIBUTES: optional JSON array of {id, name} work item fields to include in extended_attributes
        - Gets the last extraction timestamp from the checkpoint (JSON) file
        - Saves the extracted data to one CSV file, updating the checkpoint (JSON) file

Events extracted:
    - Work Item Created
    - Work Item Updated
    - Work Item State Changed
    - Work Item Sprint Changed
"""

import requests
import base64
import json
from datetime import datetime, timezone
import sys
import os
import argparse
import time
from typing import Dict, List, Optional, Any, Tuple

base_dir = os.path.dirname(os.path.abspath(__file__))
common_dir = os.path.join(base_dir, "common")
if not os.path.isdir(common_dir):
    # go up one level to find "common" (for installed package structure)
    base_dir = os.path.dirname(base_dir)
    common_dir = os.path.join(base_dir, "common")

if os.path.isdir(common_dir) and base_dir not in sys.path:
    sys.path.insert(0, base_dir)

import logging
from common.contributor import ContributorCache
from common.utils import Utils

# Configure logging to print messages on stdout
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s', stream=sys.stdout)
logger = logging.getLogger('extract_azuredevops_boards')
ContributorCache.LOGGER = logger

class AzureDevOpsBoardsExtractor:
    """Extracts work item events from Azure DevOps Boards with page-by-page processing."""

    def __init__(self):
        # Newly discovered assignee_name -> (email, contributor_id, assignee_name) entries.
        # Persisted to the contributor table at end of run in DB mode.
        self.new_assignees: Dict[str, Tuple[str, str, str]] = {}

        # Statistics
        self.stats = {
            'work_items_created': 0,
            'work_items_updated': 0,
            'total_inserted': 0,
            'total_duplicates': 0,
            'total_sprints': 0,
            'sprints_inserted': 0,
            'sprints_updated': 0
        }

    def get_config_from_database(self, cursor):
        """Get Azure DevOps configuration from data_source_config table."""
        query = """
        SELECT config_item, config_value
        FROM data_source_config
        WHERE data_source = 'work_item_management'
        AND config_item IN ('Organization', 'Projects', 'Personal Access Token', 'Work Item Attributes')
        """
        cursor.execute(query)
        results = cursor.fetchall()

        config = {}
        for row in results:
            config_item, config_value = row
            if config_item == 'Projects':
                try:
                    projects = json.loads(config_value)
                    config['projects'] = projects if projects else []
                    config['project'] = projects[0] if projects else None
                except (json.JSONDecodeError, IndexError):
                    config['projects'] = []
                    config['project'] = None
            elif config_item == 'Work Item Attributes':
                try:
                    work_item_attributes = json.loads(config_value) if config_value else []
                    config['work_item_attributes'] = work_item_attributes
                except (json.JSONDecodeError, TypeError):
                    config['work_item_attributes'] = []
            else:
                config[config_item.lower().replace(' ', '_')] = config_value

        # Ensure work_item_attributes is always present (default [] when row is missing)
        config.setdefault('work_item_attributes', [])
        return config

    def get_last_modified_date(self, cursor):
        """Get the last modified date from the database."""
        query = """
        SELECT MAX(timestamp_utc) FROM work_item_event;
        """
        cursor.execute(query)
        result = cursor.fetchone()
        if result[0]:
            # Convert to naive datetime if timezone-aware
            dt = result[0]
            if dt.tzinfo is not None:
                dt = dt.replace(tzinfo=None)
            return dt
        else:
            return datetime(2000, 1, 1)

    def save_events_to_database(self, events, cursor):
        """Save events to database."""
        if not events:
            return 0, 0

        from psycopg2.extras import execute_values

        # Define the columns for the insert (event required for Work Item Sprint Changed / journey)
        columns = [
            'work_item_id', 'project', 'type', 'parent_work_item_id',
            'state', 'title', 'timestamp_utc', 'event', 'extended_attributes', 'description_revisions'
        ]

        # Get count before insertion
        cursor.execute("SELECT COUNT(*) FROM work_item_event")
        count_before = cursor.fetchone()[0]

        # Build insert tuples from dicts with explicit column mapping (mirrors extract_jira.py)
        insert_data = []
        for event in events:
            insert_data.append((
                event.get("work_item_id"),
                event.get("project"),
                event.get("type"),
                event.get("parent_work_item_id"),
                event.get("state"),
                event.get("title"),
                event.get("timestamp_utc"),
                event.get("event"),
                event.get("extended_attributes"),
                event.get("description_revisions", 0)
            ))

        execute_values(
            cursor,
            f"INSERT INTO work_item_event ({', '.join(columns)}) VALUES %s ON CONFLICT DO NOTHING",
            insert_data,
            template=None,
            page_size=1000
        )

        # Repair any existing rows whose event is still null (inserted by an older version of the script)
        # Uses a separate UPDATE so we don't need to know the exact unique-constraint column list.
        repair_data = [
            (row[7], row[0], row[6])   # (event, work_item_id, timestamp_utc)
            for row in insert_data
            if row[7] is not None
        ]
        if repair_data:
            execute_values(
                cursor,
                """
                UPDATE work_item_event AS wie
                SET    event = data.event
                FROM   (VALUES %s) AS data(event, work_item_id, timestamp_utc)
                WHERE  wie.work_item_id  = data.work_item_id::text
                  AND  wie.timestamp_utc = data.timestamp_utc::timestamp
                  AND  wie.event IS NULL
                """,
                repair_data,
                template=None,
                page_size=1000
            )

        # Get count after insertion to determine actual inserted records
        cursor.execute("SELECT COUNT(*) FROM work_item_event")
        count_after = cursor.fetchone()[0]

        # Calculate actual inserted and skipped records
        inserted_count = count_after - count_before
        duplicate_count = len(insert_data) - inserted_count

        return inserted_count, duplicate_count

    def save_sprints_to_database(self, sprints: List[Dict], cursor) -> tuple:
        """Save sprints to database with UPSERT logic (mirrors Jira). product_id set by trigger."""
        if not sprints:
            return 0, 0

        inserted_count = 0
        updated_count = 0

        for sprint in sprints:
            cursor.execute(
                "SELECT id FROM sprint WHERE sprint_id = %s",
                (sprint.get("sprint_id"),)
            )
            exists = cursor.fetchone()

            if exists:
                cursor.execute(
                    """
                    UPDATE sprint
                    SET sprint_name = %s, project = %s, board_name = %s,
                        created_date_utc = %s, start_date_utc = %s, end_date_utc = %s,
                        completion_date_utc = %s, status = %s
                    WHERE sprint_id = %s
                    """,
                    (
                        sprint.get("sprint_name"),
                        sprint.get("project"),
                        sprint.get("board_name"),
                        sprint.get("created_date_utc"),
                        sprint.get("start_date_utc"),
                        sprint.get("end_date_utc"),
                        sprint.get("completion_date_utc"),
                        sprint.get("status"),
                        sprint.get("sprint_id")
                    )
                )
                updated_count += 1
            else:
                cursor.execute(
                    """
                    INSERT INTO sprint (
                        sprint_id, sprint_name, project, board_name,
                        created_date_utc, start_date_utc, end_date_utc, completion_date_utc, status
                    ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                    """,
                    (
                        sprint.get("sprint_id"),
                        sprint.get("sprint_name"),
                        sprint.get("project"),
                        sprint.get("board_name"),
                        sprint.get("created_date_utc"),
                        sprint.get("start_date_utc"),
                        sprint.get("end_date_utc"),
                        sprint.get("completion_date_utc"),
                        sprint.get("status")
                    )
                )
                inserted_count += 1

        return inserted_count, updated_count

    def run_extraction(self, cursor, config: Dict, start_date, last_modified, export_path: str = None):
        """
        Run extraction: fetch and save data page-by-page.

        Args:
            cursor: Database cursor (None for CSV mode)
            config: Configuration dictionary with organization, project, personal_access_token
            start_date: Start date string from command line (optional)
            last_modified: Last modified datetime from database or checkpoint
            export_path: Export path for CSV mode
        """
        # Track maximum timestamp for checkpoint saving
        max_timestamp = None
        extract_title = False
        had_error = False

        # Validate required configuration
        if not config.get('organization'):
            Utils.fatal(
                "Missing required configuration: Organization",
                context="run_extraction",
                logger=logger,
            )
        if not config.get('personal_access_token'):
            Utils.fatal(
                "Missing required configuration: Personal Access Token",
                context="run_extraction",
                logger=logger,
            )

        # Title extraction is optional: only extract if "Title" is listed in Work Item Attributes
        work_item_attributes = config.get('work_item_attributes', [])
        if work_item_attributes:
            extract_title = any(
                item.get('name', '').lower() == 'title'
                for item in work_item_attributes
            )

        # Set up Azure DevOps API configuration
        organization = config['organization']
        personal_access_token = config['personal_access_token']
        pat_token = base64.b64encode(f":{personal_access_token}".encode()).decode()

        # Set headers for API call
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Basic {pat_token}'
        }

        # Build optional work item attributes from config (list of (display_name, reference_name))
        work_item_attributes = config.get('work_item_attributes', [])
        optional_attribute_ids = []
        if work_item_attributes and all(
            isinstance(item, dict) and item.get('id') is not None and item.get('name') is not None
            for item in work_item_attributes
        ):
            optional_attribute_ids = [(item['name'], item['id']) for item in work_item_attributes]
            logger.info(f"Using {len(optional_attribute_ids)} work item attributes from config")
        elif work_item_attributes:
            logger.warning("Work item attributes must be array of {id, name} pairs; ignoring invalid config")

        # Determine the start date and whether to fetch full history.
        # When -s is supplied the WIQL query finds work items changed on/after that date,
        # but full_history=True causes every revision of those items to be included —
        # right back to the creation event — mirroring extract_jira.py behaviour.
        if start_date:
            try:
                last_modified_date = datetime.strptime(start_date, '%Y-%m-%d')
            except ValueError:
                Utils.fatal(
                    "Invalid date format. Please use YYYY-MM-DD format.",
                    context="run_extraction",
                    logger=logger,
                )
            full_history = True
        else:
            last_modified_date = last_modified
            full_history = False

        # Set up function wrappers (shared across all projects)
        if cursor:
            # Database mode
            def save_output_fn(events):
                result = self.save_events_to_database(events, cursor)
                cursor.connection.commit()
                logger.debug(f"Committed work items to database ({result[0]} inserted, {result[1]} duplicates)")
                return result
        else:
            # CSV mode - create CSV file at the start
            csv_file = Utils.create_csv_file("azuredevops_boards_events", export_path, logger)
            def save_output_fn(events):
                # events are already dicts (from prepare_revision_data)
                result = Utils.save_events_to_csv(events, csv_file, logger, checkpoint_prefix="azuredevops_boards", export_path=export_path)
                nonlocal max_timestamp
                if result[3] and (not max_timestamp or result[3] > max_timestamp):
                    max_timestamp = result[3]
                return result[1:3]  # Return only inserted and duplicates

        # Build projects list - database mode uses full list; CSV mode uses single project
        if cursor:
            projects = config.get('projects') or ([config['project']] if config.get('project') else [])
        else:
            projects = [config.get('project')] if config.get('project') else []

        if not projects:
            Utils.fatal(
                "Missing required configuration: Projects",
                context="run_extraction",
                logger=logger,
            )

        # Log the fetch information
        logger.info(f"Starting extraction from {last_modified_date}")
        logger.info(f"Fetching data from https://dev.azure.com/{organization}")
        logger.info(f"Projects: {', '.join(projects)}")

        # Initialize cumulative counters
        total_inserted = 0
        total_duplicates = 0

        # Process each project (mirrors extract_jira.py project loop)
        for project in projects:
            if not project or not project.strip():
                continue
            project = project.strip()
            logger.info(f"Processing project: {project}")

            # Fetch iterations (sprints) and build path map for extended_attributes and event detection
            iteration_path_map = {}
            try:
                iterations_root = fetch_iterations(organization, project, headers)
                if iterations_root:
                    flat_iterations = flatten_iterations_tree(iterations_root)
                    iteration_path_map = build_iteration_path_map(flat_iterations)
                    sprint_rows = process_iterations(flat_iterations, project)
                    self.stats['total_sprints'] += len(sprint_rows)
                    if cursor and sprint_rows:
                        inserted, updated = self.save_sprints_to_database(sprint_rows, cursor)
                        cursor.connection.commit()
                        self.stats['sprints_inserted'] += inserted
                        self.stats['sprints_updated'] += updated
                        logger.info(f"Project {project}: saved sprints: {inserted} inserted, {updated} updated")
                else:
                    logger.warning(f"Project {project}: could not fetch iterations; sprint table and sprint extended_attributes may be incomplete")
            except Exception as e:
                logger.error(f"Error fetching iterations for project {project}: {str(e)}")

            # Process work items in 14-day chunks: one WIQL query, one batch insert, one commit per chunk
            end_date = datetime.now(timezone.utc)
            project_inserted = 0
            project_duplicates = 0
            chunk_num = 0

            try:
                for chunk_start, chunk_end, work_items in iter_wiql_chunks(
                    last_modified_date, end_date, organization, project, headers
                ):
                    chunk_num += 1
                    if not work_items:
                        continue

                    logger.info(
                        f"Project {project}: chunk {chunk_num} ({chunk_start.date()}–{chunk_end.date()}): "
                        f"{len(work_items)} work items"
                    )
                    chunk_events = []
                    for i, item in enumerate(work_items):
                        try:
                            revision_data_list = fetch_work_item_revisions(
                                item['id'], last_modified_date, organization, project, headers,
                                optional_attribute_ids=optional_attribute_ids,
                                iteration_path_map=iteration_path_map,
                                extract_title=extract_title,
                                full_history=full_history,
                                accumulator=self.new_assignees
                            )
                            if revision_data_list:
                                chunk_events.extend(revision_data_list)
                        except Exception as e:
                            logger.error(f"Error fetching work item revisions for {item['id']}: {str(e)}")
                            had_error = True
                            if cursor:
                                try:
                                    cursor.connection.rollback()
                                except Exception:
                                    pass
                            continue

                    if chunk_events:
                        inserted, duplicates = save_output_fn(chunk_events)
                        project_inserted += inserted
                        project_duplicates += duplicates
                        logger.info(
                            f"Project {project}: chunk {chunk_num} saved: {inserted} inserted, {duplicates} duplicates"
                        )

            except Exception as e:
                logger.error(f"Error running WIQL/processing for project {project}: {str(e)}")
                had_error = True
                if cursor:
                    try:
                        cursor.connection.rollback()
                    except Exception:
                        pass
                continue

            if chunk_num == 0:
                logger.warning(f"Project {project}: no work item chunks returned. This could be due to:")
                logger.warning("1. No work items modified since the last extraction date")
                logger.warning("2. Azure DevOps services being temporarily unavailable")
                logger.warning("3. Authentication or permission issues")
                logger.warning("If you suspect a service outage, check: https://status.dev.azure.com/")

            logger.info(f"Project {project} completed: {project_inserted} inserted, {project_duplicates} duplicates.")
            total_inserted += project_inserted
            total_duplicates += project_duplicates

        # Persist newly discovered assignee→email mappings to contributor table
        if cursor and self.new_assignees:
            ContributorCache.save(cursor, 'Azure DevOps', self.new_assignees)

        # Print summary statistics
        logger.info(f"Inserted {total_inserted} records, skipped {total_duplicates} duplicate records.")
        self.stats['total_inserted'] = total_inserted
        self.stats['total_duplicates'] = total_duplicates
        return 1 if had_error else 0

# Function to safely extract data and handle missing or invalid fields
def safe_get(data, keys, default_value='NULL'):
    try:
        for key in keys:
            data = data[key]
        if isinstance(data, str):
            return "'{}'".format(data.replace("'", "''"))  # Escape single quotes for SQL
        if isinstance(data, (int, float)):
            return data
        return "'{}'".format(data)
    except (KeyError, TypeError):
        return default_value


def _normalize_attr_key(name):
    """Convert display name to a safe extended_attributes key (lowercase, spaces to underscores)."""
    if not name or not isinstance(name, str):
        return None
    return name.lower().replace(' ', '_').replace('-', '_')


def _extract_field_value(value):
    """Extract a scalar from Azure field value (e.g. identity -> displayName)."""
    if value is None:
        return None
    if isinstance(value, dict):
        return value.get('displayName') or value.get('name') or value.get('value')
    return value


# Function to build extended_attributes JSON (same structure as Jira: sprint, sprint_id, all_sprints, assignee, priority)
def build_extended_attributes(revision, fields, iteration_path_map=None, optional_attribute_ids=None, all_sprints_list=None, accumulator=None):
    """
    Build extended_attributes JSON to match Jira structure.
    Sets sprint (current), sprint_id (current, as string), all_sprints (full history when all_sprints_list provided).
    optional_attribute_ids: optional list of (display_name, reference_name) for extra fields    all_sprints_list: optional list of sprint names from work item revision history (order of first appearance).
    """
    if iteration_path_map is None:
        iteration_path_map = {}

    extended_attrs = {}

    # Sprint fields  current sprint + all_sprints
    iteration_path_value = fields.get('System.IterationPath')
    if iteration_path_value is not None:
        extended_attrs['iteration_path'] = iteration_path_value

    sprint_id_str, sprint_name = _resolve_iteration_path_to_sprint(iteration_path_value or '', iteration_path_map)
    extended_attrs['sprint_id'] = sprint_id_str
    extended_attrs['sprint'] = sprint_name
    if all_sprints_list is not None:
        extended_attrs['all_sprints'] = list(all_sprints_list)
    elif sprint_name:
        extended_attrs['all_sprints'] = [sprint_name]
    else:
        extended_attrs['all_sprints'] = []

    priority_value = fields.get('Microsoft.VSTS.Common.Priority')
    extended_attrs['priority'] = priority_value if priority_value is not None else ''

    assigned_to = fields.get('System.AssignedTo')
    if isinstance(assigned_to, dict):
        assignee_value = assigned_to.get('displayName')
        contributor_id = assigned_to.get('id')
        contributor_email = assigned_to.get('uniqueName')
    else:
        assignee_value = assigned_to
        contributor_id = None
        contributor_email = None
    if assignee_value is not None:
        extended_attrs['assignee'] = assignee_value
    if contributor_id is not None:
        extended_attrs['contributor_id'] = contributor_id
    if contributor_email:
        extended_attrs['contributor_email_address'] = contributor_email
    if accumulator is not None and assignee_value and contributor_email:
        cache_key = str(contributor_id) if contributor_id else str(assignee_value)
        accumulator[cache_key] = (str(contributor_email), str(contributor_id or ''), str(assignee_value))
    area_path_value = fields.get('System.AreaPath')
    if area_path_value is not None:
        extended_attrs['area_path'] = area_path_value

    story_points_value = fields.get('Microsoft.VSTS.Scheduling.StoryPoints')
    if story_points_value is not None:
        extended_attrs['story_points'] = story_points_value

    if optional_attribute_ids:
        for display_name, ref_id in optional_attribute_ids:
            raw = fields.get(ref_id)
            if raw is not None:
                val = _extract_field_value(raw)
                if val is not None:
                    key = _normalize_attr_key(display_name) or ref_id.replace('.', '_').lower()
                    extended_attrs[key] = val

    return json.dumps(extended_attrs) if extended_attrs else None

# Function to check if Title/Description/Acceptance Criteria changed
def has_content_changed(current_revision, previous_revision):
    """
    Check if Title, Description, or Acceptance Criteria changed between revisions.
    Returns 1 if any of these fields changed, 0 otherwise.
    """
    if not previous_revision:
        return 0  # First revision, no change to count

    current_fields = current_revision.get('fields', {})
    previous_fields = previous_revision.get('fields', {})

    # Fields to track for changes (Title/Description/Acceptance Criteria)
    fields_to_track = [
        'System.Title',
        'System.Description',
        'Microsoft.VSTS.Common.AcceptanceCriteria'
    ]

    for field in fields_to_track:
        current_value = current_fields.get(field, '')
        previous_value = previous_fields.get(field, '')

        # Normalize None to empty string for comparison
        current_value = current_value if current_value is not None else ''
        previous_value = previous_value if previous_value is not None else ''

        if current_value != previous_value:
            return 1  # Change detected in Title/Description/Acceptance Criteria

    return 0  # No changes detected in tracked fields

def get_revision_event_type(revision, previous_revision) -> str:
    """
    Determine event type for this revision. Priority: Created > State Changed > Sprint Changed > Updated.
    """
    if previous_revision is None:
        return "Work Item Created"

    curr_fields = revision.get('fields', {})
    prev_fields = previous_revision.get('fields', {})

    if curr_fields.get('System.State') != prev_fields.get('System.State'):
        return "Work Item State Changed"
    if curr_fields.get('System.IterationPath') != prev_fields.get('System.IterationPath'):
        return "Work Item Sprint Changed"
    return "Work Item Updated"


# Function to prepare revision data for batch insertion
def prepare_revision_data(revision, work_item_id, description_revisions, event: str, iteration_path_map=None, optional_attribute_ids=None, extract_title=False, all_sprints_list=None, accumulator=None):
    fields = revision.get('fields', {})

    # Title is extracted only if "Title" is in the optional attributes list
    extract_title = bool(
        optional_attribute_ids
        and any(name.lower() == 'title' for name, _ in optional_attribute_ids)
    )

    # Convert and rename state_change_date to timestamp_utc
    state_change_date = safe_get(fields, ['System.ChangedDate'])
    timestamp_utc = Utils.convert_to_utc(state_change_date.strip("'")) if state_change_date != 'NULL' else None

    # Build extended_attributes JSON (all_sprints_list = work item sprint history)
    extended_attributes = build_extended_attributes(
        revision, fields,
        iteration_path_map=iteration_path_map,
        optional_attribute_ids=optional_attribute_ids,
        all_sprints_list=all_sprints_list,
        accumulator=accumulator
    )

    # Extract field values safely
    def safe_extract(field_path, default=None):
        try:
            current_data = fields
            for key in field_path:
                if isinstance(current_data, dict):
                    current_data = current_data[key]
                else:
                    return default
            return current_data if current_data is not None else default
        except (KeyError, TypeError):
            return default

    return {
        'work_item_id': work_item_id,
        'project': safe_extract(['System.TeamProject']),
        'type': safe_extract(['System.WorkItemType']),
        'parent_work_item_id': safe_extract(['System.Parent']),
        'state': safe_extract(['System.State']),
        'title': safe_extract(['System.Title']) if extract_title else None,
        'timestamp_utc': timestamp_utc,
        'event': event,
        'extended_attributes': extended_attributes,
        'description_revisions': description_revisions,
    }

# Function to check if the response is in JSON format
def is_json(response_text):
    try:
        json.loads(response_text)
        return True
    except ValueError:
        return False

# Azure DevOps WIQL returns at most 20,000 work items per query (VS402337).
WIQL_RESULT_SIZE_LIMIT = 20000
# Chunk size in days to keep each query under the limit when scanning large date ranges.
WIQL_CHUNK_DAYS = 14


def run_wiql_query(last_modified_date, organization, project, headers, end_date=None):
    """
    Run a single WIQL query for work items modified in [last_modified_date, end_date).
    If end_date is None, no upper bound is applied (query uses only >= last_modified_date).
    """
    start_str = last_modified_date.strftime('%Y-%m-%d')
    query_url = f"https://dev.azure.com/{organization}/{project}/_apis/wit/wiql?api-version=6.0"
    if end_date is not None:
        end_str = end_date.strftime('%Y-%m-%d')
        where_clause = f"[System.TeamProject] = '{project}' AND [System.ChangedDate] >= '{start_str}' AND [System.ChangedDate] < '{end_str}'"
    else:
        where_clause = f"[System.TeamProject] = '{project}' AND [System.ChangedDate] >= '{start_str}'"
    wiql_query = {
        "query": f"SELECT [System.Id], [System.ChangedDate] FROM WorkItems WHERE {where_clause} ORDER BY [System.ChangedDate] DESC"
    }

    max_retries = 3
    retry_delay = 1

    for attempt in range(max_retries):
        try:
            response = requests.post(query_url, headers=headers, json=wiql_query, timeout=60)

            if response.status_code == 200 and is_json(response.text):
                return response.json().get('workItems', [])
            elif response.status_code == 400 and is_json(response.text):
                body = response.json()
                msg = (body.get('message') or '')
                if '20000' in msg or 'WorkItemTrackingQueryResultSizeLimitExceededException' in (body.get('typeKey') or ''):
                    # Signal that this date range is too large; caller should use a smaller chunk.
                    raise WorkItemQueryResultSizeLimitExceeded(msg)
                logger.error(
                    Utils.format_http_error(
                        "POST",
                        query_url,
                        response.status_code,
                        getattr(response, "reason", "") or "",
                        response.text,
                        response.headers.get("Content-Type"),
                    )
                )
                if attempt < max_retries - 1:
                    time.sleep(retry_delay * (2 ** attempt))
                    continue
                return []
            elif response.status_code == 403:
                if 'X-RateLimit-Reset' in response.headers:
                    reset_time = int(response.headers['X-RateLimit-Reset'])
                    wait_time = max(0, reset_time - int(time.time()) + 10)
                    logger.warning(f"Rate limit exceeded. Waiting {wait_time} seconds...")
                    time.sleep(wait_time)
                    continue
                # A 403 without X-RateLimit-Reset is a permission denied error, not a rate limit.
                Utils.fatal(
                    Utils.format_http_error(
                        "POST",
                        query_url,
                        response.status_code,
                        getattr(response, "reason", "") or "",
                        response.text,
                        response.headers.get("Content-Type"),
                    ),
                    context="run_wiql_query",
                    logger=logger,
                )
            else:
                if response.status_code in (401, 404):
                    Utils.fatal(
                        Utils.format_http_error(
                            "POST",
                            query_url,
                            response.status_code,
                            getattr(response, "reason", "") or "",
                            response.text,
                            response.headers.get("Content-Type"),
                        ),
                        context="run_wiql_query",
                        logger=logger,
                    )
                logger.error(
                    Utils.format_http_error(
                        "POST",
                        query_url,
                        response.status_code,
                        getattr(response, "reason", "") or "",
                        response.text,
                        response.headers.get("Content-Type"),
                    )
                )
                if attempt < max_retries - 1:
                    time.sleep(retry_delay * (2 ** attempt))
                    continue
                return []

        except requests.exceptions.RequestException as e:
            logging.error(f"Request failed for WIQL query (attempt {attempt + 1}): {e}")
            if attempt < max_retries - 1:
                time.sleep(retry_delay * (2 ** attempt))
                continue
            return []

    return []


class WorkItemQueryResultSizeLimitExceeded(Exception):
    """Raised when a WIQL query returns more than the allowed 20,000 work items."""


def iter_wiql_chunks(last_modified_date, end_date, organization, project, headers):
    """
    Yield work items in 14-day date-range chunks to stay under the 20,000 work item limit per query.
    Yields (chunk_start, chunk_end, work_items) for each chunk. If a chunk hits the limit,
    it is split into two sub-chunks (half the days); each sub-chunk gets one query and one yield.
    Caller does one execute_values + one commit per yielded chunk (including sub-chunks).
    """
    from datetime import timedelta

    if end_date.tzinfo is not None:
        end_date = end_date.replace(tzinfo=None)
    start_date = last_modified_date
    if start_date.tzinfo is not None:
        start_date = start_date.replace(tzinfo=None)

    chunk_days = WIQL_CHUNK_DAYS
    # Stack of (start, end) ranges to query; we process and split as needed (no recursion).
    pending = []
    current = start_date
    while current < end_date:
        chunk_end = min(current + timedelta(days=chunk_days), end_date)
        pending.append((current, chunk_end))
        current = chunk_end

    while pending:
        start, end = pending.pop()
        try:
            work_items = run_wiql_query(start, organization, project, headers, end_date=end)
            yield (start, end, work_items or [])
        except WorkItemQueryResultSizeLimitExceeded:
            delta = (end - start).days
            if delta <= 1:
                logger.error(f"Cannot split 1-day chunk further; skipping range {start.date()}–{end.date()}")
            else:
                half = (delta // 2) or 1
                mid = start + timedelta(days=half)
                logger.warning(f"Chunk {start.date()}–{end.date()} exceeded 20k items; splitting into sub-chunks.")
                pending.append((mid, end))
                pending.append((start, mid))


def fetch_iterations(organization: str, project: str, headers: Dict) -> Optional[Dict]:
    """Fetch iteration tree from Azure DevOps Classification Nodes API."""
    url = f"https://dev.azure.com/{organization}/{project}/_apis/wit/classificationnodes/iterations?api-version=6.0&$depth=10"
    for attempt in range(3):
        try:
            response = requests.get(url, headers=headers, timeout=30)
            if response.status_code == 200 and is_json(response.text):
                return response.json()
            if response.status_code == 403 and 'X-RateLimit-Reset' in response.headers:
                reset_time = int(response.headers['X-RateLimit-Reset'])
                wait_time = max(0, reset_time - int(time.time()) + 10)
                logger.warning(f"Rate limit exceeded. Waiting {wait_time} seconds...")
                time.sleep(wait_time)
                continue
            if response.status_code == 403:
                # A 403 without X-RateLimit-Reset is a permission denied error, not a rate limit.
                Utils.fatal(
                    Utils.format_http_error(
                        "GET",
                        url,
                        response.status_code,
                        getattr(response, "reason", "") or "",
                        response.text,
                        response.headers.get("Content-Type"),
                    ),
                    context="fetch_iterations",
                    logger=logger,
                )
            if response.status_code in (401, 404):
                Utils.fatal(
                    Utils.format_http_error(
                        "GET",
                        url,
                        response.status_code,
                        getattr(response, "reason", "") or "",
                        response.text,
                        response.headers.get("Content-Type"),
                    ),
                    context="fetch_iterations",
                    logger=logger,
                )
            logger.warning(f"Fetch iterations: {response.status_code}")
        except requests.exceptions.RequestException as e:
            logger.warning(f"Request failed for iterations (attempt {attempt + 1}): {e}")
        if attempt < 2:
            time.sleep(1 * (2 ** attempt))
    return None


def flatten_iterations_tree(node: Dict, path_prefix: str = "") -> List[Dict]:
    """Recursively flatten iteration tree into list of nodes. path_prefix is the path of the parent."""
    result = []
    name = node.get('name') or ''
    path = node.get('path') or ''
    # API path may use backslashes; normalize for lookup (e.g. "\\Project\\Iteration1")
    if path:
        normalized_path = path.strip('\\').replace('\\', '\\')
    else:
        normalized_path = (path_prefix + '\\' + name).strip('\\') if path_prefix else name

    node_id = node.get('id')
    attrs = node.get('attributes') or {}
    start_date = attrs.get('startDate')
    finish_date = attrs.get('finishDate')
    start_date_utc = Utils.convert_to_utc(start_date) if start_date else None
    end_date_utc = Utils.convert_to_utc(finish_date) if finish_date else None

    if node_id is not None and name:
        result.append({
            'id': node_id,
            'name': name,
            'path': path or normalized_path,
            'start_date_utc': start_date_utc,
            'end_date_utc': end_date_utc,
        })

    for child in node.get('children') or []:
        result.extend(flatten_iterations_tree(child, path or normalized_path))

    return result


def process_iterations(flat_iterations: List[Dict], project: str) -> List[Dict]:
    """Map flattened iteration nodes to sprint table rows (same shape as Jira process_sprints)."""
    sprint_data = []
    board_name = project  # Azure DevOps has no boards like Jira; use project name
    for it in flat_iterations:
        node_id = it.get('id')
        name = it.get('name')
        if node_id is None or not name:
            continue
        start_date_utc = it.get('start_date_utc')
        end_date_utc = it.get('end_date_utc')
        status = ''
        if start_date_utc and end_date_utc:
            now = datetime.now(timezone.utc).replace(tzinfo=None)
            if now < start_date_utc:
                status = 'future'
            elif now > end_date_utc:
                status = 'closed'
            else:
                status = 'active'
        sprint_data.append({
            'sprint_id': node_id,
            'sprint_name': name,
            'project': project,
            'board_name': board_name,
            'created_date_utc': None,
            'start_date_utc': start_date_utc,
            'end_date_utc': end_date_utc,
            'completion_date_utc': end_date_utc,
            'status': status
        })
    return sprint_data


def _normalize_iteration_path(path_str: str) -> str:
    """Normalize iteration path for consistent lookup (strip, normalize slashes)."""
    if not path_str:
        return ''
    return (path_str or '').strip().strip('\\').strip('/').replace('/', '\\')


def _resolve_iteration_path_to_sprint(iteration_path_value: str, iteration_path_map: Dict[str, Dict[str, Any]]) -> tuple:
    """
    Resolve System.IterationPath to (sprint_id, sprint_name). Returns (str, str); empty strings if not found.
    Tries path lookup first, then fallback: match by sprint name (leaf or full) so current sprint_id is always set when possible.
    """
    if not iteration_path_value or not iteration_path_map:
        return '', ''
    raw = (iteration_path_value or '').strip()
    normalized_path = _normalize_iteration_path(iteration_path_value)
    path_fwd = (normalized_path or '').replace('\\', '/')
    path_stripped = raw.strip('\\').strip('/').replace('/', '\\')
    # Try all path key variants (including with leading backslash; work item API may return different format)
    path_variants = [
        normalized_path,
        iteration_path_value,
        raw,
        path_fwd,
        path_stripped,
        (raw.strip('\\').strip('/')),
        ('\\' + normalized_path) if normalized_path else '',
        (normalized_path.replace('\\', '/')) if normalized_path else '',
    ]
    sprint_info = None
    for key in path_variants:
        if key and key in iteration_path_map:
            sprint_info = iteration_path_map[key]
            break
    if sprint_info:
        return str(sprint_info['id']), (sprint_info.get('name') or '')
    # Fallback: resolve by sprint name (current sprint) so sprint_id is never null when we know the sprint
    # Work item may store only leaf name (e.g. "2025-02") or path format may not match; match by name
    leaf = raw.split('\\')[-1].strip() if '\\' in raw else raw
    if not leaf and '/' in raw:
        leaf = raw.split('/')[-1].strip()
    for entry in iteration_path_map.values():
        if not isinstance(entry, dict) or entry.get('id') is None:
            continue
        name = (entry.get('name') or '').strip()
        if name and (name == raw or name == leaf or name == iteration_path_value):
            return str(entry['id']), name
    return '', (raw or iteration_path_value)


def build_iteration_path_map(flat_iterations: List[Dict]) -> Dict[str, Dict[str, Any]]:
    """
    Build map from iteration path string (as stored in System.IterationPath) to {id, name, ...}.
    Azure DevOps System.IterationPath is typically "ProjectName\\Release 1\\Sprint 3".
    Multiple key variants are stored so lookup works regardless of slash or leading/trailing format.
    """
    path_map = {}
    for it in flat_iterations:
        raw_path = (it.get('path') or '').strip()
        path = _normalize_iteration_path(raw_path) or _normalize_iteration_path(raw_path.strip('\\'))
        name = (it.get('name') or '').strip()
        node_id = it.get('id')
        if node_id is None:
            continue
        entry = {'id': node_id, 'name': name, 'path': path or raw_path}
        if path:
            path_map[path] = entry
        if raw_path:
            path_map[_normalize_iteration_path(raw_path)] = entry
        # Key without leading/trailing backslash (matches System.IterationPath on work items)
        path_no_leading = _normalize_iteration_path(raw_path.lstrip('\\'))
        if path_no_leading:
            path_map[path_no_leading] = entry
        path_no_trailing = _normalize_iteration_path(raw_path.rstrip('\\'))
        if path_no_trailing:
            path_map[path_no_trailing] = entry
        # Also key by path with forward slashes (API may return either)
        path_fwd = (path or '').replace('\\', '/')
        if path_fwd:
            path_map[path_fwd] = entry
        if name and name not in path_map:
            path_map[name] = entry
    return path_map


# Fetch Work Item Revisions from Azure DevOps API for modified work items
def fetch_work_item_revisions(work_item_id, last_modified_date, organization, project, headers, optional_attribute_ids=None, iteration_path_map=None, extract_title=False, full_history=False, accumulator=None):
    revisions_url = f"https://dev.azure.com/{organization}/{project}/_apis/wit/workitems/{work_item_id}/revisions?api-version=6.0&$expand=relations"

    # Retry logic for failed requests
    max_retries = 3
    retry_delay = 1  # seconds

    for attempt in range(max_retries):
        try:
            response = requests.get(revisions_url, headers=headers, timeout=30)

            # Check if the response is valid JSON
            if response.status_code == 200 and is_json(response.text):
                revisions_data = response.json()
                break
            elif response.status_code == 403:
                # A 403 with X-RateLimit-Reset is a rate limit response.
                # A 403 without it is a permission denied error.
                if 'X-RateLimit-Reset' in response.headers:
                    reset_time = int(response.headers['X-RateLimit-Reset'])
                    wait_time = max(0, reset_time - int(time.time()) + 10)
                    logging.warning(f"Rate limit exceeded. Waiting {wait_time} seconds...")
                    time.sleep(wait_time)
                    continue
                else:
                    Utils.fatal(
                        Utils.format_http_error(
                            "GET",
                            revisions_url,
                            response.status_code,
                            getattr(response, "reason", "") or "",
                            response.text,
                            response.headers.get("Content-Type"),
                        ),
                        context="fetch_work_item_revisions",
                        logger=logger,
                    )
            else:
                if response.status_code in (401, 404):
                    Utils.fatal(
                        Utils.format_http_error(
                            "GET",
                            revisions_url,
                            response.status_code,
                            getattr(response, "reason", "") or "",
                            response.text,
                            response.headers.get("Content-Type"),
                        ),
                        context="fetch_work_item_revisions",
                        logger=logger,
                    )
                logger.error(
                    Utils.format_http_error(
                        "GET",
                        revisions_url,
                        response.status_code,
                        getattr(response, "reason", "") or "",
                        response.text,
                        response.headers.get("Content-Type"),
                    )
                )
                if attempt < max_retries - 1:
                    time.sleep(retry_delay * (2 ** attempt))  # Exponential backoff
                    continue
                else:
                    return []

        except requests.exceptions.RequestException as e:
            logging.error(f"Request failed for work item revisions {work_item_id} (attempt {attempt + 1}): {e}")
            if attempt < max_retries - 1:
                time.sleep(retry_delay * (2 ** attempt))  # Exponential backoff
                continue
            else:
                return []
    else:
        return []

    # Process the revisions and collect data for batch insertion
    revision_data_list = []
    if 'value' in revisions_data:
        revisions = revisions_data['value']
        path_map = iteration_path_map or {}

        # Build all_sprints for this work item: unique sprint names in order of first appearance 
        all_sprint_names_ordered = []
        for rev in revisions:
            it_path = rev.get('fields', {}).get('System.IterationPath')
            if not it_path:
                continue
            _, name = _resolve_iteration_path_to_sprint(it_path, path_map)
            if name and name not in all_sprint_names_ordered:
                all_sprint_names_ordered.append(name)

        for i, revision in enumerate(revisions):
            changed_date = revision['fields'].get('System.ChangedDate')
            if changed_date:
                changed_date_dt = Utils.convert_to_utc(changed_date)  # Convert to naive UTC datetime

                # In full_history mode include every revision; otherwise only those after the watermark
                if full_history or changed_date_dt > last_modified_date:
                    # Get previous revision for comparison (if exists)
                    previous_revision = revisions[i - 1] if i > 0 else None

                    event = get_revision_event_type(revision, previous_revision)
                    description_revisions = has_content_changed(revision, previous_revision)

                    # Prepare data for batch insertion (event, iteration_path_map, all_sprints)
                    revision_data = prepare_revision_data(
                        revision, work_item_id, description_revisions, event,
                        iteration_path_map=path_map,
                        optional_attribute_ids=optional_attribute_ids,
                        extract_title=extract_title,
                        all_sprints_list=all_sprint_names_ordered,
                        accumulator=accumulator
                    )
                    revision_data_list.append(revision_data)

    return revision_data_list

# Main Execution: Fetch work items modified since the last known date
def main():
    parser = argparse.ArgumentParser(description="Extract Azure DevOps Boards work item events to database or CSV.")

    # Add command-line arguments
    parser.add_argument('-p', '--product', type=str, help='Product name (if provided, saves to database; otherwise saves to CSV)')
    parser.add_argument('-s', '--start-date', type=str, help='Start date in YYYY-MM-DD format')

    # Parse the arguments
    args = parser.parse_args()

    extractor = AzureDevOpsBoardsExtractor()

    if args.product is None:
        # CSV Mode: Load configuration from config.json
        raw_config = json.load(open(os.path.join(common_dir, "config.json")))
        
        # Get configuration from config dictionary
        config = {
            'organization': raw_config.get('AZDO_ORGANIZATION'),
            'personal_access_token': raw_config.get('AZDO_API_TOKEN'),
            'project': raw_config.get('AZDO_PROJECT')
        }

        # Parse optional work item attributes (AZDO_WORK_ITEM_ATTRIBUTES: array of {id, name})
        raw_work_item_attributes = raw_config.get('AZDO_WORK_ITEM_ATTRIBUTES', [])
        if raw_work_item_attributes:
            try:
                if isinstance(raw_work_item_attributes, str):
                    work_item_attributes = json.loads(raw_work_item_attributes)
                else:
                    work_item_attributes = raw_work_item_attributes
                if isinstance(work_item_attributes, list) and all(
                    isinstance(item, dict) and item.get('id') is not None and item.get('name') is not None
                    for item in work_item_attributes
                ):
                    config['work_item_attributes'] = work_item_attributes
                else:
                    logger.warning("AZDO_WORK_ITEM_ATTRIBUTES must be JSON array of {id, name} pairs")
                    config['work_item_attributes'] = []
            except (json.JSONDecodeError, TypeError) as e:
                logger.warning(f"Failed to parse AZDO_WORK_ITEM_ATTRIBUTES: {e}")
                config['work_item_attributes'] = []
        else:
            config['work_item_attributes'] = []

        # Parse optional work item attributes (AZDO_WORK_ITEM_ATTRIBUTES: array of {id, name})
        raw_work_item_attributes = raw_config.get('AZDO_WORK_ITEM_ATTRIBUTES', [])
        if raw_work_item_attributes:
            try:
                if isinstance(raw_work_item_attributes, str):
                    work_item_attributes = json.loads(raw_work_item_attributes)
                else:
                    work_item_attributes = raw_work_item_attributes
                if isinstance(work_item_attributes, list) and all(
                    isinstance(item, dict) and item.get('id') is not None and item.get('name') is not None
                    for item in work_item_attributes
                ):
                    config['work_item_attributes'] = work_item_attributes
                else:
                    logger.warning("AZDO_WORK_ITEM_ATTRIBUTES must be JSON array of {id, name} pairs")
                    config['work_item_attributes'] = []
            except (json.JSONDecodeError, TypeError) as e:
                logger.warning(f"Failed to parse AZDO_WORK_ITEM_ATTRIBUTES: {e}")
                config['work_item_attributes'] = []
        else:
            config['work_item_attributes'] = []

        # Use checkpoint file for last modified date
        checkpoint_file = "azuredevops_boards"
        last_modified = Utils.load_checkpoint(checkpoint_file)

        return extractor.run_extraction(None, config, args.start_date, last_modified)

    else:
        # Database Mode: Connect to the database
        from database import DatabaseConnection
        db = DatabaseConnection()

        with db.product_scope(args.product) as conn:
            with conn.cursor() as cursor:
                config = extractor.get_config_from_database(cursor)
                last_modified = extractor.get_last_modified_date(cursor)
                return extractor.run_extraction(cursor, config, args.start_date, last_modified)

if __name__ == '__main__':
    exit_code = main()
    sys.exit(exit_code)
