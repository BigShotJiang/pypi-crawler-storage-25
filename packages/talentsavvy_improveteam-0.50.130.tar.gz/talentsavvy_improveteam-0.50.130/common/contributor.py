import json
import logging
from typing import Dict, List, Optional, Tuple


class ContributorCache:
    """
    Shared contributor cache within the current process/extraction run.

    _email_by_id   — contributor_id → email, keyed by the tool-specific user ID
                     (e.g. ADO GUID, GitLab numeric id, Bitbucket account_id).
                     Populated at startup via load() and extended at runtime.
                     ID-keyed lookups are preferred because IDs are globally unique
                     within a tool, whereas display names are not.

    _email_by_name — author_name → email, keyed by display name.  Only populated
                     for names that map unambiguously to a single email in the DB.
                     Used as a fallback when no contributor_id is available.

    load()         — populate both maps from the contributor table for a given tool.

    save()         — persist newly discovered (name, email, id) triples into the
                     contributor table.
    """

    LOGGER: Optional[logging.Logger] = None

    # contributor_id → email, populated at startup via load()
    _email_by_id: Dict[str, str] = {}
    # author_name → email (unambiguous names only), populated at startup via load()
    _email_by_name: Dict[str, str] = {}

    @classmethod
    def load(cls, cursor, tool_name: str) -> None:
        """
        Populate _email_by_id and _email_by_name from the contributor table for
        the given tool.

        _email_by_id  — maps every non-empty tool->>'id' to contributor.email.
                        No ambiguity guard: IDs are unique per tool so each maps
                        to exactly one email.

        _email_by_name — maps tool->>'name' to contributor.email only for names
                         that resolve to a single distinct email.  Names shared by
                         two or more contributors (same display name, different
                         people) are intentionally omitted so that
                         _get_contributor_email() falls through to the tool API,
                         which can uniquely resolve the correct address.
        """
        query = """
            SELECT tool->>'name' AS contributor_name,
                   tool->>'id'   AS contributor_id,
                   c.email
            FROM contributor c,
                 jsonb_array_elements(c.tools) AS tool
            WHERE lower(tool->>'tool') = lower(%s)
              AND c.email IS NOT NULL
              AND TRIM(c.email) != ''
              AND (tool->>'name') IS NOT NULL
              AND TRIM(tool->>'name') != ''
        """
        cursor.execute(query, (tool_name,))

        cls._email_by_id = {}
        grouped: Dict[str, set] = {}  # name → set of emails (for ambiguity detection)
        for name, contrib_id, email in cursor.fetchall():
            # ID-based map: no ambiguity guard needed — IDs are unique per tool
            if contrib_id and contrib_id.strip():
                cls._email_by_id[contrib_id.strip()] = email
            # Name-based grouping for ambiguity detection
            grouped.setdefault(name, set()).add(email)

        cls._email_by_name = {
            name: next(iter(emails))
            for name, emails in grouped.items()
            if len(emails) == 1
        }
        ambiguous = sum(1 for emails in grouped.values() if len(emails) > 1)
        if cls.LOGGER:
            cls.LOGGER.info(
                f"Loaded {len(cls._email_by_id)} id\u2192email and "
                f"{len(cls._email_by_name)} name\u2192email mappings "
                f"for tool '{tool_name}'"
                + (f" ({ambiguous} ambiguous name(s) skipped; will resolve via API)" if ambiguous else "")
            )

    @classmethod
    def reset(cls) -> None:
        """Clear both lookup caches. Call at the start of each extraction run."""
        cls._email_by_id = {}
        cls._email_by_name = {}

    @classmethod
    def get_email(cls, contrib_id: Optional[str], name: Optional[str]) -> Optional[str]:
        """
        Return a cached email or None if not yet looked up.

        If contrib_id is provided, looks up _email_by_id only.
        If contrib_id is falsy, looks up _email_by_name only.
        Returns '' when a previous lookup yielded no email (known miss).
        Returns None when this combination has never been attempted.
        """
        if contrib_id and contrib_id in cls._email_by_id:
            return cls._email_by_id[contrib_id]
        if not contrib_id and name and name in cls._email_by_name:
            return cls._email_by_name[name]
        return None

    @classmethod
    def cache_email_by_id(cls, contrib_id: str, email: str) -> None:
        """Store an email (may be '') against a contributor ID."""
        cls._email_by_id[contrib_id] = email

    @classmethod
    def cache_email_by_name(cls, name: str, email: str) -> None:
        """Store an email (may be '') against a display name."""
        cls._email_by_name[name] = email

    @classmethod
    def save(cls, cursor, tool_name: str, new_entries: Dict[str, Tuple[str, str, str]], commit: bool = True) -> None:
        """
        Persist newly discovered contributor mappings into the contributor table.

        new_entries is keyed by contributor_id (when non-empty) or display_name,
        with each value being a (email, contributor_id, display_name) triple.

        Groups all new (name, id) pairs by normalised email so that each INSERT
        row carries every distinct tool entry for that email.  Only one row per
        email is emitted, preventing duplicate-key conflicts within a single
        execute_values() batch.

        Upsert behaviour:
          INSERT  – new contributor row with all tool entries for that email.
          CONFLICT (email already exists for this tenant):
            * Iterates EXCLUDED.tools and appends only entries whose
              (tool, id, name) triple is not already in contributor.tools.
            * Preserve 'ignored' status; otherwise set 'active'.
        """
        if not new_entries:
            return

        from psycopg2.extras import execute_values

        # Group (name, contributor_id) pairs by normalised email
        email_to_entries: Dict[str, List[Tuple[str, str]]] = {}
        for _key, (email, contrib_id, display_name) in new_entries.items():
            email_norm = (email or '').strip().lower()
            name_stripped = (display_name or '').strip()
            if not email_norm or not name_stripped:
                continue
            email_to_entries.setdefault(email_norm, []).append(
                (name_stripped, (contrib_id or '').strip())
            )

        if not email_to_entries:
            return

        upsert_sql = """
            INSERT INTO contributor (email, tools, status)
            VALUES %s
            ON CONFLICT (tenant_id, lower(trim(email)))
            WHERE NULLIF(trim(email), '') IS NOT NULL
            DO UPDATE SET
                tools  = contributor.tools || COALESCE(
                             (
                                 SELECT jsonb_agg(new_tool.entry)
                                 FROM jsonb_array_elements(EXCLUDED.tools) AS new_tool(entry)
                                 WHERE NOT EXISTS (
                                     SELECT 1
                                     FROM jsonb_array_elements(contributor.tools) AS existing_tool(entry)
                                     WHERE existing_tool.entry->>'tool' = new_tool.entry->>'tool'
                                       AND existing_tool.entry->>'id'   = new_tool.entry->>'id'
                                       AND existing_tool.entry->>'name' = new_tool.entry->>'name'
                                 )
                             ),
                             '[]'::jsonb
                         ),
                status = CASE
                             WHEN contributor.status = 'ignored' THEN 'ignored'
                             ELSE 'active'
                         END
        """

        # Emit at most one row per normalised email so a single INSERT ... ON CONFLICT
        # statement never targets the same (tenant_id, lower(trim(email))) key twice.
        # Each row carries every distinct tool entry for that email, and the UPDATE
        # appends only the entries not already present in contributor.tools.
        values = []
        total_entries = 0
        for email_norm, entries in email_to_entries.items():
            distinct_entries = list(dict.fromkeys(entries))
            if not distinct_entries:
                continue

            total_entries += len(distinct_entries)
            values.append(
                (
                    email_norm,
                    json.dumps(
                        [
                            {'tool': tool_name, 'name': name, 'id': contrib_id}
                            for name, contrib_id in distinct_entries
                        ]
                    ),
                    'active',
                )
            )

        execute_values(cursor, upsert_sql, values, template="(%s, %s::jsonb, %s)", page_size=500)
        if commit:
            cursor.connection.commit()

        if cls.LOGGER:
            cls.LOGGER.info(
                f"Upserted {total_entries} contributor tool entries for tool '{tool_name}'"
            )
