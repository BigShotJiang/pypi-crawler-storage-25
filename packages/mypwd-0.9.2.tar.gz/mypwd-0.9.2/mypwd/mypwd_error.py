class MyPwdError(Exception):
    pass
