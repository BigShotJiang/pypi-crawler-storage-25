#include <stdio.h>
#include <unistd.h>
#include <assert.h>
#include <time.h>
#include <getopt.h>
#include <math.h>
#include <errno.h>
#include <string.h>

#include <json-model.h>

#define str_eq(s1, s2) (strcmp(s1, s2) == 0)

typedef enum {
    expect_nothing,
    expect_anything,
    expect_fail,
    expect_pass
} process_mode_t;

// NOTE CLOCK_REALTIME resolution seems low at 0.250 µs
static clockid_t current_clock = CLOCK_MONOTONIC;

// return realtime(?) µs
static INLINE double now(void)
{
    struct timespec ts;
    if (unlikely(clock_gettime(current_clock, &ts)))
    {
        fprintf(stderr, "cannot get time (%d): %s\n", errno, strerror(errno));
        exit(2);
    }
    return 1000000.0 * ts.tv_sec + 0.001 * ts.tv_nsec;
}

// return clock resolution in µs (may be probably optimistic)
static double getres(void)
{
    struct timespec ts;
    if (unlikely(clock_getres(current_clock, &ts)))
    {
        fprintf(stderr, "cannot get clock resolution (%d): %s\n", errno, strerror(errno));
        exit(2);
    }
    return 1000000.0 * ts.tv_sec + 0.001 * ts.tv_nsec;
}

// small computation to avoid compiler optimizations that could remove empty loops
#define NEXT_STUFF(v, pi) v = frexp(3.141592653589793 * v + 2.718281828459045, pi)

// overhead estimation µs on a nearly empty loop
static double overhead_estimation(int loop, double *value)
{
    double empty = 0.0, v = *value;
    int exponent;

    for (int i = loop; i; i--)
    {
        double start = now();
        NEXT_STUFF(v, &exponent);
        empty += now() - start;
    }

    *value = v;
    return empty / loop;
}

// check value and report if there was some error wrt expectations
static bool
process_value(
    const char *name, const json_t * value,
    const char *fname, size_t index, process_mode_t mode,
    bool report, bool show_time, int loop, double empty)
{
    // get checker function
    const jm_check_fun_t checker = CHECK_fun(name);
    if (checker == NULL)
    {
        fprintf(stderr, "check function not found for %s\n", name);
        return true;
    }

    // check value against model, fast (no path nor reasons)
    bool valid = true;
    int exponent;
    double v = frexp(loop / 13.0, &exponent);

    // performance loop in µs
    if (show_time)
    {
        // validation estimation
        double sum = 0.0, sum2 = 0.0;

        for (int i = loop; i; i--)
        {
            double start = now();
            NEXT_STUFF(v, &exponent);
            valid = checker(value, NULL, NULL);
            double delay = now() - start - empty;

            sum += delay;
            sum2 += delay * delay;
        }

        double avg = sum / loop;
        double stdev = sqrt(sum2 / loop - avg * avg);

        fprintf(stderr, "%s%s%s[%zu] nop %s %.03f ± %.03f µs/check (%.03f)\n",
                fname, strlen(name)? ".": "", name, index, valid ? "PASS": "FAIL",
                avg, stdev, empty);
    }

    // get result
    valid = checker(value, NULL, NULL);
    bool unexpected = (mode == expect_fail && valid) || (mode == expect_pass && !valid);

    if (mode == expect_nothing)  // just show, no index
        fprintf(stdout, "%s: %s", fname, valid ? "PASS" : "FAIL");
    else if (mode == expect_anything)  // just show, including index
        fprintf(stdout, "%s[%zu]: %s", fname, index, valid ? "PASS" : "FAIL");
    else if (unexpected)
        fprintf(stdout, "%s[%zu]: ERROR unexpected %s", fname, index, valid ? "PASS" : "FAIL");
    else  // as expected
        fprintf(stdout, "%s[%zu]: %s", fname, index, valid ? "PASS" : "FAIL");

    // maybe second pass with report collection
    if ((show_time || !valid) && report)
    {
        jm_path_t path;
        jm_report_t report;

        bool valid2 = true;

        // loop just for measuring performance, including cleanup
        if (show_time)
        {
            double sum = 0.0, sum2 = 0.0;

            for (int i = loop; i; i--)
            {
                double start = now();

                NEXT_STUFF(v, &exponent);
                path = (jm_path_t) { "", 0, NULL, NULL };
                report = (jm_report_t) { NULL };
                valid2 = checker(value, &path, &report);
                jm_report_free_entries(&report);

                double delay = now() - start - empty;
                sum += delay;
                sum2 += delay * delay;
            }

            double avg = sum / loop;
            double stdev = sqrt(sum2 / loop - avg * avg);

            fprintf(stderr, "%s%s%s[%zu] rep %s %.03f ± %.03f µs/check (%.03f)\n",
                    fname, strlen(name)? ".": "", name, index, valid ? "PASS": "FAIL",
                    avg, stdev, empty);
        }

        // get the result for display
        path = (jm_path_t) { "", 0, NULL, NULL };
        report = (jm_report_t) { NULL };
        valid2 = checker(value, &path, &report);

        assert(valid == valid2);

        if (report.entry)
        {
            bool first = true;
            fprintf(stdout, " (");

            for (jm_report_entry_t *entry = report.entry; entry != NULL; entry = entry->prev)
            {
                if (first)
                    first = false;
                else
                    fprintf(stdout, "; ");
                fprintf(stdout, "%s: %s", entry->path, entry->message);
            }

            fprintf(stdout, ")");
        }

        jm_report_free_entries(&report);
    }

    fprintf(stdout, "\n");

    return !unexpected;
}

int main(int argc, char* argv[])
{
    // get options
    int opt;
    char *name = "";
    bool report = false;
    bool test = false;
    bool jsonl = false;
    bool list = false;
    bool version = false;
    bool show_time = false;
    int loop = 1;

    const struct option options[] = {
        { "help", no_argument, NULL, 'h' },
        { "version", no_argument, NULL, 'v' },
        { "list", no_argument, NULL, 'l' },
        { "name", required_argument, NULL, 'n' },
        { "report", no_argument, NULL, 'r' },
        { "test", no_argument, NULL, 't' },
        { "time", required_argument, NULL, 'T' },
        { "jsonl", no_argument, NULL, 'L' },
        { "fast", no_argument, NULL, 1000 },
        { "slow", no_argument, NULL, 1001 },
        { "no-report", no_argument, NULL, 1002 },
        { "resolution", no_argument, NULL, 1003 },
        { "clock", required_argument, NULL, 'C' },
        { NULL, 0, NULL, 0 }
    };

    while ((opt = getopt_long(argc, argv, "hvln:rtT:C:", options, NULL)) != -1)
    {
        switch (opt) {
            case 'h':  // FIXME expand help!
                fprintf(stdout,
                        "Usage: %s [-hvl] [-r] [-n name] [-t] [-T repeat] [files...]\n"
                        "Check JSON values validity against a JSON model\n"
                        "Generated by jmc (JSON Model Compiler) version %s\n"
                        "see https://github.com/clairey-zx81/json-model\n",
                        argv[0], jm_version_string);
                return 0;
            case 'l':
                list = true;
                break;
            case 'v':
                version = true;
                break;
            case 'n':
                name = optarg;
                break;
            case 'r':
                report = true;
                break;
            case 't':
                test = true;
                break;
            case 'T':
                loop = atoi(optarg);
                show_time = loop > 0;
                loop = loop ? loop : 1;
                break;
            case 'L':
                jsonl = true;
                break;
            case 1000:
                jm_is_valid_regex = jm_is_valid_regex_fast;
                jm_is_valid_date = jm_is_valid_date_fast;
                break;
            case 1001:
                jm_is_valid_regex = jm_is_valid_regex_slow;
                jm_is_valid_date = jm_is_valid_date_slow;
                break;
            case 1002:
                report = false;
                break;
            case 1003:
                fprintf(stderr, "clock resolution: %.03f µs\n", getres());
                break;
            case 'C':
                if (str_eq(optarg, "monotonic") || str_eq(optarg, "m"))
                    current_clock = CLOCK_MONOTONIC;
                else if (str_eq(optarg, "realtime") || str_eq(optarg, "r"))
                    current_clock = CLOCK_REALTIME;
#ifdef CLOCK_PROCESS_CPUTIME_ID
                else if (str_eq(optarg, "process") || str_eq(optarg, "p"))
                    current_clock = CLOCK_PROCESS_CPUTIME_ID;
#endif
#ifdef CLOCK_THREAD_CPUTIME_ID
                else if (str_eq(optarg, "thread") || str_eq(optarg, "t"))
                    current_clock = CLOCK_THREAD_CPUTIME_ID;
#endif
                else {
                    fprintf(stderr, "unexpected clock %s for [mrpt]\n", optarg);
                    return 1;
                }
                break;
            case '?':
            default:
                fprintf(stdout, "unexpected option encountered\n");
                return 1;
        }
    }

    // option consistency
    if (jsonl && test)
    {
        fprintf(stderr, "Value input format cannot be both jsonl and test\n");
        return 1;
    }

    // initialization
    const char *error;
    if ((error = CHECK_init()) != NULL)
    {
        fprintf(stderr, "JSON Model initialization error: %s\n", error);
        return 2;
    }

    // delayed after the initialization
    if (version)
    {
        fprintf(stdout, "C from JSON Model compiler version %s\n", jm_version_string);
        return 0;
    }
    if (list)
    {
        fprintf(stdout, "JSON Model names (empty for default):");
        for (int i = 0; i < CHECK_map_size; i++)
            fprintf(stdout, "%s ", CHECK_map_tab[i].name);
        fprintf(stdout, "\n");
        return 0;
    }

    // minimal non-zero measure overhead estimation
    double empty = 0.0;
    if (show_time && loop > 1)
    {
        int exponent;
        double v = frexp(loop / 13.0, &exponent);
        int count = 1000;
        while (count)
        {
            double e = overhead_estimation(loop, &v);
            if (e) {
                count--;
                if (empty == 0.0 || e < empty)
                    empty = e;
            }
        }
    }

    int errors = 0;

    for (int i = optind; i < argc; i++)
    {
        json_error_t error;
        json_t *value;

        if (jsonl)
        {
            FILE *input = fopen(argv[i], "r");
            int count = 1;

            if (input == NULL)
            {
                fprintf(stderr, "%s: ERROR while opening file\n", argv[i]);
                errors++;
                continue;
            }

            while ((value = json_loadf(input,
                                       JSON_DISABLE_EOF_CHECK|JSON_DECODE_ANY|JSON_ALLOW_NUL,
                                       &error)))
            {
                if (!process_value(name, value, argv[i], count, expect_anything,
                                   report, show_time, loop, empty))
                    errors++;
                count++;
                json_decref(value);
            }

            if (value == NULL)  // if not EOF, it is probably an error
            {
                unsigned char c;
                if (fread(&c, 1, 1, input) != 0)
                {
                    fprintf(stdout, "%s: ERROR (%s at %d:%d)\n",
                            argv[i], error.text, error.line, error.column);
                    errors++;
                    continue;
                }
            }
        }
        else
        {
            // read and parse JSON file
            json_t *value = json_load_file(argv[i], JSON_DECODE_ANY|JSON_ALLOW_NUL, &error);
            if (value == NULL)
            {
                fprintf(stdout, "%s: ERROR (%s at %d:%d)\n",
                        argv[i], error.text, error.line, error.column);
                errors++;
                continue;
            }

            if (test)
            {
                if (!json_is_array(value))
                {
                    fprintf(stdout, "%s: ERROR not a JSON array in test mode\n", argv[i]);
                    errors++;
                    continue;
                }

                size_t _, index = 0;
                json_t *val;
                json_array_foreach(value, _, val)
                {
                    if (json_is_string(val))
                        // skip string comments
                        continue;

                    // else must be an array (size is 0 for non-arrays)
                    size_t size = json_array_size(val);
                    if (!(size == 2 || size == 3))
                    {
                        fprintf(stdout,
                                "%s[%zu]: ERROR not a 2 or 3-tuple\n",
                                argv[i], index);
                        errors++;
                        continue;
                    }

                    const json_t
                        *first = json_array_get(val, 0),
                        *second = json_array_get(val, 1);

                    if (!json_is_boolean(first) || (size == 3 && !json_is_string(second)))
                    {
                        fprintf(stdout,
                                "%s[%zu]: ERROR first element not boolean or second not string\n",
                                argv[i], index);
                        errors++;
                        continue;
                    }

                    const char *tname = size == 3 ? json_string_value(second) : name;
                    const json_t *value = size == 3 ? json_array_get(val, 2) : second;
                    process_mode_t mode = json_is_true(first) ? expect_pass : expect_fail;

                    if (!process_value(tname, value, argv[i], index, mode,
                                       report, show_time, loop, empty))
                        errors++;

                    index++;
                }
            }
            else
                if (!process_value(name, value, argv[i], 0, expect_nothing,
                                   report, show_time, loop, empty))
                    errors++;

            // free json value
            json_decref(value);
        }
    }

    CHECK_free();

    return errors? 4: 0;
}
