from abc import ABC, abstractmethod
from typing import List

from .model import KnowledgeExtraction
from ..vector.db import VectorSearchResponse


class KnowledgeExtractor(ABC):

    @abstractmethod
    def extract(
        self, vector_search_response: VectorSearchResponse
    ) -> List[KnowledgeExtraction]:
        pass

    def extract_text(self, text: str) -> KnowledgeExtraction:
        knowledge_extractions = self.extract(
            VectorSearchResponse(answers=[text], source="")
        )
        if knowledge_extractions:
            return knowledge_extractions[0]
        return KnowledgeExtraction(chunk=text, entities=[], relations=[], source="")
