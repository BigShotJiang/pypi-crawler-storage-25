"""Views for the generic widget system.

Provides lazy-loading of widget content via HTMX, drag-and-drop
reordering with layout persistence through ScopedSettings, and a
lock/unlock toggle for the widget area.

Layout data uses Gridstack.js coordinates: ``x`` (column, 0-based),
``y`` (row, 0-based), ``w`` (width in columns).
"""

import json

from django.contrib.auth.mixins import LoginRequiredMixin
from django.http import (
    Http404,
    HttpResponse,
    HttpResponseBadRequest,
)
from django.shortcuts import render
from django.views import View

from conjunto.api.interfaces import IWidget, IWidgetArea
from conjunto.settings.scoped.models import Scope, ScopedSetting


def _find_area(area_name: str) -> type[IWidgetArea] | None:
    """Look up an IWidgetArea implementation by its ``name`` attribute."""
    for area_cls in IWidgetArea.enabled_plugins():
        if area_cls.name == area_name:
            return area_cls
    return None


def _find_widget(area_cls: type[IWidgetArea], widget_name: str) -> type[IWidget] | None:
    """Look up an IWidget implementation by name within the given area."""
    for widget_cls in IWidget.enabled_plugins():
        if widget_cls.area is area_cls and widget_cls.name == widget_name:
            return widget_cls
    return None


def _make_widget_dict(w, x=None, y=None, width=None):
    """Build a widget dict with Gridstack-compatible layout data.

    Args:
        w: The IWidget class.
        x: Column position (0-based). None lets Gridstack auto-place.
        y: Row position (0-based). None lets Gridstack auto-place.
        width: Width in columns. Falls back to ``w.col_span``.
    """
    return {
        "name": w.name,
        "title": w.title,
        "icon": w.icon,
        "template": w.template,
        "x": x,
        "y": y,
        "w": width if width is not None else w.col_span,
        "min_w": w.min_col_span,
        "max_w": w.max_col_span,
        "resizable": w.resizable,
        "removable": w.removable,
    }


class WidgetAreaMixin:
    """View mixin that populates context with widget layout data.

    Requires the ``widget_area_class`` attribute to be set to an
    :class:`IWidgetArea` subclass. Adds the following context keys:

    - ``widget_area`` — the area class
    - ``widgets`` — flat list of widget dicts with Gridstack layout info
    - ``widgets_locked`` — boolean, whether the area is locked
    """

    widget_area_class: type[IWidgetArea] = None

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)

        area = self.widget_area_class
        if area is None:
            return ctx

        request = self.request

        # Collect all widgets the user is allowed to see.
        permitted_widgets = area.get_widgets(request)
        widget_by_name = {w.name: w for w in permitted_widgets}

        # Load persisted layout from ScopedSettings (fallback: empty list).
        saved_layout = request.scoped_settings.get(
            area.name, "widget_layout", default=[]
        )

        # Merge: honour saved positions/widths, drop removed, append new.
        widgets: list[dict] = []
        seen: set[str] = set()

        for entry in saved_layout:
            name = entry.get("name")
            visible = entry.get("visible", True)
            if name in widget_by_name and visible:
                w = widget_by_name[name]
                widgets.append(
                    _make_widget_dict(
                        w,
                        x=entry.get("x"),
                        y=entry.get("y"),
                        width=entry.get("w", entry.get("col_span", w.col_span)),
                    )
                )
                seen.add(name)

        # Append new (unseen) widgets — Gridstack will auto-place them.
        unseen = [w for w in permitted_widgets if w.name not in seen]
        for widget in unseen:
            widgets.append(_make_widget_dict(widget))

        # Lock state.
        locked = request.scoped_settings.get(area.name, "locked", default=True)

        ctx.update(
            {
                "widget_area": area,
                "widgets": widgets,
                "widgets_locked": locked,
            }
        )
        return ctx


class WidgetContentView(LoginRequiredMixin, View):
    """Lazy-load a single widget's content via HTMX.

    URL: ``widgets/<area_name>/<widget_name>/``
    """

    def get(self, request, area_name: str, widget_name: str):
        area_cls = _find_area(area_name)
        if area_cls is None:
            raise Http404(f"Widget area '{area_name}' not found.")

        widget_cls = _find_widget(area_cls, widget_name)
        if widget_cls is None:
            raise Http404(f"Widget '{widget_name}' not found in area '{area_name}'.")

        if not widget_cls.has_permission(request):
            raise Http404  # hide existence from unauthorized users

        if not widget_cls.template:
            return HttpResponse()

        context = widget_cls.get_context_data(request)
        context["request"] = request
        return render(request, widget_cls.template, context)


class WidgetReorderView(LoginRequiredMixin, View):
    """Persist a new widget layout for the current user.

    URL: ``widgets/<area_name>/reorder/``
    Expects a POST with a JSON body: a list of
    ``{"name": str, "x": int, "y": int, "w": int, "visible": bool}`` entries.
    """

    def post(self, request, area_name: str):
        area_cls = _find_area(area_name)
        if area_cls is None:
            raise Http404(f"Widget area '{area_name}' not found.")

        try:
            layout = json.loads(request.body)
        except (json.JSONDecodeError, ValueError):
            return HttpResponseBadRequest("Invalid JSON.")

        if not isinstance(layout, list):
            return HttpResponseBadRequest("Expected a JSON array.")

        # Validate: all referenced widget names must exist in the area.
        valid_names = {w.name for w in IWidget.enabled_plugins() if w.area is area_cls}
        for entry in layout:
            if not isinstance(entry, dict) or entry.get("name") not in valid_names:
                return HttpResponseBadRequest(
                    f"Unknown widget: {entry.get('name', '<missing>')}"
                )

        ScopedSetting.objects.update_or_create(
            namespace=area_name,
            key="widget_layout",
            scope=Scope.USER,
            user=request.user,
            defaults={"value": layout},
        )

        return HttpResponse(status=204)


class WidgetToggleLockView(LoginRequiredMixin, View):
    """Toggle the lock state for a widget area.

    URL: ``widgets/<area_name>/toggle-lock/``
    """

    def post(self, request, area_name: str):
        area_cls = _find_area(area_name)
        if area_cls is None:
            raise Http404(f"Widget area '{area_name}' not found.")

        current = request.scoped_settings.get(area_name, "locked", default=True)
        new_value = not current

        ScopedSetting.objects.update_or_create(
            namespace=area_name,
            key="locked",
            scope=Scope.USER,
            user=request.user,
            defaults={"value": new_value},
        )

        # Invalidate the cached value so subsequent reads in the same
        # request reflect the change.
        request.scoped_settings.invalidate(area_name, "locked")

        response = HttpResponse(status=204)
        response["HX-Trigger"] = json.dumps({f"{area_name}:lock-changed": True})
        return response
