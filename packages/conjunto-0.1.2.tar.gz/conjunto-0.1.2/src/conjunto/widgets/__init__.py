from conjunto.api.interfaces import IWidget, IWidgetArea

__all__ = ["IWidget", "IWidgetArea"]
