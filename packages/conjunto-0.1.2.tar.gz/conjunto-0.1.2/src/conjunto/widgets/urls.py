from django.urls import path

from . import views

app_name = "widgets"

urlpatterns = [
    path(
        "<str:area_name>/reorder/",
        views.WidgetReorderView.as_view(),
        name="reorder",
    ),
    path(
        "<str:area_name>/toggle-lock/",
        views.WidgetToggleLockView.as_view(),
        name="toggle-lock",
    ),
    path(
        "<str:area_name>/<str:widget_name>/",
        views.WidgetContentView.as_view(),
        name="content",
    ),
]
