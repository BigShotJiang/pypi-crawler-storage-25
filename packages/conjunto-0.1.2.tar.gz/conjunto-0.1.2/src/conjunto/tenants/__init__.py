"""Conjunto tenants app.

Provides a swappable Tenant model following Django's ``AUTH_USER_MODEL``
pattern. Consumer projects may either:

* use the default concrete model ``conjunto_tenants.Tenant`` (no
  configuration required), or
* subclass :class:`~conjunto.tenants.models.AbstractTenant` and point
  ``CONJUNTO_TENANT_MODEL = "myapp.MyTenant"`` at their own model.

To keep ``CONJUNTO_TENANT_MODEL`` truly optional we install the default
value on the settings object at package import time — which happens
before Django loads ``conjunto.tenants.models`` and therefore before
``ForeignKey(settings.CONJUNTO_TENANT_MODEL, ...)`` / migration
``swappable_dependency`` calls are evaluated.
"""

from django.conf import settings

# Install a sane default for CONJUNTO_TENANT_MODEL if the consumer
# project did not configure one explicitly. Must happen at module
# import time (before models.py is loaded by Django's app registry).
if not hasattr(settings, "CONJUNTO_TENANT_MODEL"):
    settings.CONJUNTO_TENANT_MODEL = "conjunto_tenants.Tenant"

default_app_config = "conjunto.tenants.apps.TenantsConfig"
