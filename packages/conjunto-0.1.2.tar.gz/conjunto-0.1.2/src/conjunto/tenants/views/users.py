"""User management views for tenant-scoped administration.

Provides CRUD views for managing users within the current tenant:

- :class:`TenantUserListView` — paginated list of users who hold at
  least one :class:`~conjunto.tenants.models.TenantMembership` for the
  current tenant, plus superusers.
- :class:`TenantUserCreateView` — modal form to create a new user and
  assign them to the tenant with optional initial roles.
- :class:`TenantUserUpdateView` — modal form to edit a user's basic
  details (name, email, active status).
- :class:`TenantUserRemoveView` — modal confirmation to remove all
  memberships for a user in the current tenant. Does **not** delete
  the user account.
"""

from __future__ import annotations

from typing import Any

from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.mixins import LoginRequiredMixin
from django.core.exceptions import PermissionDenied
from django.db.models import Q
from django.utils.translation import gettext_lazy as _
from django.views.generic import FormView, ListView, UpdateView

from conjunto.htmx.views import ModalFormViewMixin
from conjunto.tenants.context import override_tenant
from conjunto.tenants.forms import TenantUserCreateForm, TenantUserEditForm
from conjunto.tenants.mixins import TenantRequiredMixin
from conjunto.tenants.models import TenantMembership

User = get_user_model()


def _roles_for_user(user, tenant) -> list[str]:
    """Return role names the user holds within the tenant."""
    return list(
        user.tenant_memberships.filter(tenant=tenant)
        .order_by("role")
        .values_list("role", flat=True)
    )


class _NamespaceMixin:
    """Pre-build fully-qualified URL names for the template."""

    _template_url_names: tuple[str, ...] = ()

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        match = self.request.resolver_match
        ns = match.namespace
        prefix = f"{ns}:" if ns else ""
        ctx["urls"] = {
            name.replace("-", "_"): f"{prefix}{name}"
            for name in self._template_url_names
        }
        return ctx


class TenantUserListView(
    _NamespaceMixin, LoginRequiredMixin, TenantRequiredMixin, ListView
):
    """List users who are members of the current tenant."""

    template_name = "conjunto/tenants/user_list.html"
    context_object_name = "users"
    paginate_by = 50
    base_template = "conjunto/app_base.html"
    _template_url_names = ("user-add", "user-edit", "user-remove")

    def get_queryset(self):
        tenant = self.request.tenant
        return (
            User.objects.filter(
                Q(is_superuser=True) | Q(tenant_memberships__tenant=tenant)
            )
            .distinct()
            .order_by("username")
        )

    def get_context_data(self, **kwargs: Any) -> dict[str, Any]:
        ctx = super().get_context_data(**kwargs)
        tenant = self.request.tenant
        for u in ctx["users"]:
            u.current_roles = _roles_for_user(u, tenant)
        ctx["title"] = _("Users")
        ctx["tenant"] = tenant
        ctx["base_template"] = self.base_template
        return ctx


class TenantUserCreateView(
    LoginRequiredMixin, TenantRequiredMixin, ModalFormViewMixin, FormView
):
    """Modal form to create a new user within the tenant."""

    template_name = "conjunto/tenants/user_form.html"
    form_class = TenantUserCreateForm
    success_url = ""
    success_event = "tenant_users:changed"
    enforce_htmx = False

    def get_modal_title(self) -> str:
        return _("Create user")

    def get_form_kwargs(self) -> dict[str, Any]:
        kwargs = super().get_form_kwargs()
        kwargs["tenant"] = self.request.tenant
        return kwargs

    def form_valid(self, form):
        with override_tenant(self.request.tenant):
            form.save()
        return super().form_valid(form)


class TenantUserUpdateView(
    LoginRequiredMixin, TenantRequiredMixin, ModalFormViewMixin, UpdateView
):
    """Modal form to edit a user's basic details.

    Uses ``ModalFormViewMixin + UpdateView`` directly instead of
    ``ModalUpdateView`` to avoid the ``AutoPermissionsViewMixin``
    that would require ``change_user`` Django permission. Access
    control is handled by the consuming app's admin permission mixin.
    """

    model = User
    form_class = TenantUserEditForm
    success_url = ""
    success_event = "tenant_users:changed"
    template_name = "conjunto/tenants/user_edit.html"
    enforce_htmx = False

    def get_queryset(self):
        tenant = self.request.tenant
        return User.objects.filter(
            Q(is_superuser=True) | Q(tenant_memberships__tenant=tenant)
        ).distinct()

    def get_modal_title(self) -> str:
        return _("Edit user '{user}'").format(user=self.object)


class _EmptyForm(forms.Form):
    """Placeholder form so modal_form.html renders a <form> tag."""

    pass


class TenantUserRemoveView(
    LoginRequiredMixin, TenantRequiredMixin, ModalFormViewMixin, FormView
):
    """Confirm removal of a user from the current tenant.

    Deletes all :class:`TenantMembership` rows for the target user in
    the current tenant. Does **not** delete the user account itself.

    Validates that at least one admin remains after removal.
    """

    template_name = "conjunto/tenants/user_remove.html"
    form_class = _EmptyForm
    success_url = ""
    success_event = "tenant_users:changed"
    enforce_htmx = False

    def get_modal_title(self) -> str:
        return _("Remove user")

    def _target_user(self):
        if not hasattr(self, "_cached_user"):
            self._cached_user = User.objects.get(pk=self.kwargs["pk"])
        return self._cached_user

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["target_user"] = self._target_user()
        ctx["button_content"] = _("Remove")
        ctx["submit_button_css_class"] = "danger"
        return ctx

    def form_valid(self, form):
        user = self._target_user()
        tenant = self.request.tenant

        # Prevent removal of the last admin.
        user_is_admin = TenantMembership.objects.filter(
            user=user, tenant=tenant, role="tenant_admin"
        ).exists()
        if user_is_admin:
            other_admins = (
                TenantMembership.objects.filter(tenant=tenant, role="tenant_admin")
                .exclude(user=user)
                .exists()
            )
            if not other_admins:
                raise PermissionDenied(
                    _("Cannot remove the last admin from the tenant.")
                )

        # Delete all memberships for this user in the tenant.
        for membership in TenantMembership.objects.filter(user=user, tenant=tenant):
            membership.delete()

        return super().form_valid(form)
