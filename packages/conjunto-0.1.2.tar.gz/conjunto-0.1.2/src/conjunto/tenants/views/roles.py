"""Role management views for tenant-scoped permission administration.

Provides CRUD views for :class:`~conjunto.tenants.models.TenantRole`:

- :class:`TenantRoleListView` — paginated list of all roles for the
  current tenant (system + custom).
- :class:`TenantRoleCreateView` — modal form to create a custom role.
- :class:`TenantRoleUpdateView` — modal form to edit a role's label,
  description, and permissions.
- :class:`TenantRoleDeleteView` — modal confirmation to delete a
  custom role (system roles are protected).

All views are gated to tenant admins via a permission mixin that
consumers must provide (or override ``dispatch`` on their subclasses).
"""

from __future__ import annotations

from typing import Any

from django.contrib.auth.mixins import LoginRequiredMixin
from django.core.exceptions import PermissionDenied
from django.db.models import QuerySet
from django.utils.translation import gettext_lazy as _
from django.views.generic import ListView

from django.views.generic import CreateView, UpdateView

from conjunto.htmx.views import HtmxDeleteView, ModalFormViewMixin
from conjunto.tenants.forms import TenantRoleForm
from conjunto.tenants.mixins import TenantRequiredMixin
from conjunto.tenants.models import TenantRole


class _NamespaceMixin:
    """Pre-build fully-qualified URL names for the template.

    Templates receive ``urls`` — a dict of short name → full URL name
    that can be passed directly to ``{% url %}``, e.g.::

        {% url urls.role_add %}
        {% url urls.role_edit pk=role.pk %}
    """

    #: Short URL names the template needs (without namespace prefix).
    _template_url_names: tuple[str, ...] = ()

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        match = self.request.resolver_match
        ns = match.namespace
        prefix = f"{ns}:" if ns else ""
        ctx["urls"] = {
            name.replace("-", "_"): f"{prefix}{name}"
            for name in self._template_url_names
        }
        return ctx


class TenantRoleListView(
    _NamespaceMixin, LoginRequiredMixin, TenantRequiredMixin, ListView
):
    """List all roles (system + custom) for the current tenant."""

    model = TenantRole
    template_name = "conjunto/tenants/role_list.html"
    context_object_name = "roles"
    paginate_by = 50
    base_template = "conjunto/app_base.html"
    _template_url_names = ("role-add", "role-edit", "role-delete")

    def get_queryset(self) -> QuerySet[TenantRole]:
        return TenantRole.objects.filter(tenant=self.request.tenant).order_by("name")

    def get_context_data(self, **kwargs: Any) -> dict[str, Any]:
        ctx = super().get_context_data(**kwargs)
        ctx["title"] = _("Roles")
        ctx["base_template"] = self.base_template
        return ctx


class TenantRoleCreateView(
    LoginRequiredMixin, TenantRequiredMixin, ModalFormViewMixin, CreateView
):
    """Modal form to create a custom role.

    Uses ``ModalFormViewMixin + CreateView`` directly instead of
    ``ModalCreateView`` to avoid ``AutoPermissionsViewMixin``. Access
    control is handled by the consuming app's admin permission mixin.
    """

    model = TenantRole
    form_class = TenantRoleForm
    success_url = ""
    success_event = "tenant_roles:changed"
    modal_title = _("Create role")
    enforce_htmx = False

    def get_form_kwargs(self) -> dict[str, Any]:
        kwargs = super().get_form_kwargs()
        kwargs["tenant"] = self.request.tenant
        return kwargs


class TenantRoleUpdateView(
    LoginRequiredMixin, TenantRequiredMixin, ModalFormViewMixin, UpdateView
):
    """Modal form to edit an existing role.

    Uses ``ModalFormViewMixin + UpdateView`` directly instead of
    ``ModalUpdateView`` to avoid ``AutoPermissionsViewMixin``.
    """

    model = TenantRole
    form_class = TenantRoleForm
    success_url = ""
    success_event = "tenant_roles:changed"
    enforce_htmx = False

    def get_queryset(self) -> QuerySet[TenantRole]:
        return TenantRole.objects.filter(tenant=self.request.tenant)

    def get_form_kwargs(self) -> dict[str, Any]:
        kwargs = super().get_form_kwargs()
        kwargs["tenant"] = self.request.tenant
        return kwargs

    def get_modal_title(self) -> str:
        return _("Edit role '{name}'").format(name=self.object.label)


class TenantRoleDeleteView(LoginRequiredMixin, TenantRequiredMixin, HtmxDeleteView):
    """Modal confirmation to delete a custom role.

    System roles (``is_system=True``) cannot be deleted — the view
    raises ``PermissionDenied`` if the target role is a system role.

    ``HtmxDeleteView`` does not use ``AutoPermissionsViewMixin``, so
    no model-level permissions are enforced beyond what the consuming
    app's admin mixin provides.
    """

    model = TenantRole
    success_url = ""
    success_event = "tenant_roles:changed"
    template_name = "conjunto/tenants/role_confirm_delete.html"
    enforce_htmx = False

    def get_queryset(self) -> QuerySet[TenantRole]:
        return TenantRole.objects.filter(tenant=self.request.tenant)

    def dispatch(self, request, *args, **kwargs):
        obj = self.get_object()
        if obj.is_system:
            raise PermissionDenied(_("System roles cannot be deleted."))
        return super().dispatch(request, *args, **kwargs)
