"""User-role assignment views for tenant-scoped permission management.

Provides views for assigning and revoking roles on a per-user basis:

- :class:`UserRoleListView` — paginated list of users with their
  current tenant-scoped roles displayed as badges.
- :class:`ManageUserRolesView` — modal checkbox form for
  assigning/revoking roles on a single user.
"""

from __future__ import annotations

from typing import Any

from django.contrib.auth import get_user_model
from django.contrib.auth.mixins import LoginRequiredMixin
from django.db.models import Q
from django.utils.translation import gettext_lazy as _
from django.views.generic import FormView, ListView

from conjunto.htmx.views import ModalFormViewMixin
from conjunto.tenants.context import override_tenant
from conjunto.tenants.forms import UserRolesForm
from conjunto.tenants.mixins import TenantRequiredMixin

User = get_user_model()


def _roles_for_user(user, tenant) -> list[str]:
    """Return role names the user holds within the tenant."""
    return list(
        user.tenant_memberships.filter(tenant=tenant)
        .order_by("role")
        .values_list("role", flat=True)
    )


class _NamespaceMixin:
    """Pre-build fully-qualified URL names for the template."""

    _template_url_names: tuple[str, ...] = ()

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        match = self.request.resolver_match
        ns = match.namespace
        prefix = f"{ns}:" if ns else ""
        ctx["urls"] = {
            name.replace("-", "_"): f"{prefix}{name}"
            for name in self._template_url_names
        }
        return ctx


class UserRoleListView(
    _NamespaceMixin, LoginRequiredMixin, TenantRequiredMixin, ListView
):
    """List users with their tenant-scoped roles."""

    template_name = "conjunto/tenants/user_role_list.html"
    context_object_name = "users"
    paginate_by = 50
    base_template = "conjunto/app_base.html"
    _template_url_names = ("user-role-manage",)

    def get_queryset(self):
        tenant = self.request.tenant
        return (
            User.objects.filter(
                Q(is_superuser=True) | Q(tenant_memberships__tenant=tenant)
            )
            .distinct()
            .order_by("username")
        )

    def get_context_data(self, **kwargs: Any) -> dict[str, Any]:
        ctx = super().get_context_data(**kwargs)
        tenant = self.request.tenant
        for u in ctx["users"]:
            u.current_roles = _roles_for_user(u, tenant)
        ctx["title"] = _("User roles")
        ctx["tenant"] = tenant
        ctx["base_template"] = self.base_template
        return ctx


class ManageUserRolesView(
    LoginRequiredMixin, TenantRequiredMixin, ModalFormViewMixin, FormView
):
    """Modal form to assign/revoke roles for a single user.

    On save returns a 204 with ``HX-Trigger: user_roles:changed``.
    The list view listens for that event and refetches itself.
    """

    template_name = "conjunto/tenants/manage_roles.html"
    form_class = UserRolesForm
    success_url = ""
    success_event = "user_roles:changed"
    enforce_htmx = False

    def get_modal_title(self) -> str:
        return _("Manage roles for {user}").format(user=self._target_user())

    def _target_user(self):
        if not hasattr(self, "_cached_user"):
            self._cached_user = User.objects.get(pk=self.kwargs["pk"])
        return self._cached_user

    def get_form_kwargs(self) -> dict[str, Any]:
        kwargs = super().get_form_kwargs()
        kwargs["target_user"] = self._target_user()
        kwargs["tenant"] = self.request.tenant
        return kwargs

    def form_valid(self, form):
        with override_tenant(self.request.tenant):
            form.save()
        return super().form_valid(form)

    def get_context_data(self, **kwargs: Any) -> dict[str, Any]:
        ctx = super().get_context_data(**kwargs)
        ctx["target_user"] = self._target_user()
        return ctx
