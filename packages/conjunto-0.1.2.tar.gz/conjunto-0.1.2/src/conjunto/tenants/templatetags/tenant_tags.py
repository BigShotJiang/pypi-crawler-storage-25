"""Template tags for rendering tenant state in the layout.

The most common use is the statusbar badge in ``conjunto/base.html`` —
a tiny chip that shows the currently bound tenant and, if the user is
allowed to switch, links to the tenant picker.
"""

from django import template

from conjunto.tenants.utils import get_allowed_tenants

register = template.Library()


@register.inclusion_tag("conjunto/tenants/_badge.html", takes_context=True)
def tenant_badge(context):
    """Render the statusbar tenant badge.

    Context consumed:
    - ``request.tenant`` — currently bound tenant (may be ``None``).
    - ``request.user`` — used to decide whether the badge is a link to
      the picker. A user is considered allowed to switch if
      :func:`~conjunto.tenants.utils.get_allowed_tenants` returns more
      than one tenant for them (one-or-zero means there's nothing to
      switch to, so the badge stays plain).
    """
    request = context.get("request")
    if request is None:
        return {
            "tenant": None,
            "can_switch": False,
            "tenants": [],
            "current_tenant_id": None,
        }

    tenant = getattr(request, "tenant", None)
    allowed = get_allowed_tenants(request)
    num_tenants = allowed.count()
    # Show the picker when there are multiple tenants to choose from,
    # OR when the user has no tenant bound yet but at least one exists.
    can_switch = num_tenants > 1 or (tenant is None and num_tenants >= 1)
    current_tenant_id = getattr(request, "session", {}).get("cj_tenant_id")
    if current_tenant_id is None and tenant is not None:
        current_tenant_id = tenant.pk
    return {
        "tenant": tenant,
        "can_switch": can_switch,
        "tenants": allowed if can_switch else [],
        "current_tenant_id": current_tenant_id,
    }
