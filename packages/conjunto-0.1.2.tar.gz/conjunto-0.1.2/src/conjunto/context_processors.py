from django.conf import settings as django_settings
from importlib import metadata
from conjunto.models import Vendor


__all__ = ["globals", "settings"]


# Inline-style fragments for every supported toast position. ``{m}`` is
# substituted with the configured ``CONJUNTO_TOAST_MARGIN`` value.
_TOAST_POSITION_STYLES = {
    "top-left": "top: {m}; left: {m};",
    "top-center": "top: {m}; left: 50%; transform: translateX(-50%);",
    "top-right": "top: {m}; right: {m};",
    "bottom-left": "bottom: {m}; left: {m};",
    "bottom-center": "bottom: {m}; left: 50%; transform: translateX(-50%);",
    "bottom-right": "bottom: {m}; right: {m};",
}


def _toast_config():
    position = getattr(django_settings, "CONJUNTO_TOAST_POSITION", "top-right")
    margin = getattr(django_settings, "CONJUNTO_TOAST_MARGIN", "1rem")
    template = (
        _TOAST_POSITION_STYLES.get(position) or _TOAST_POSITION_STYLES["top-right"]
    )
    return {
        "position": position,
        "margin": margin,
        "style": template.format(m=margin),
    }


# try to get version using the importlib.metadata module
# you have to set PROJECT_NAME in settings.py for that.
# But this is obligatory anyway, and helps to avoid searching for version strings
# elsewhere.
__version__ = metadata.version(django_settings.PROJECT_NAME)


def globals(request):  # noqa
    # Build cj_layout from Django settings defaults, then overlay the
    # effective scoped-setting values (VENDOR → USER chain). Views can
    # further override by setting ctx["cj_layout"] = {...}.
    default_style = getattr(django_settings, "CONJUNTO_LAYOUT", "fluid")
    default_topbar = getattr(django_settings, "CONJUNTO_TOPBAR_FIXED", True)
    default_sidebar = getattr(django_settings, "CONJUNTO_SIDEBAR_WIDTH", "15rem")

    scoped = getattr(request, "scoped_settings", None)
    if scoped is not None:
        layout = {
            "style": scoped.get("conjunto", "layout_style", default=default_style),
            "topbar_fixed": scoped.get(
                "conjunto", "topbar_fixed", default=default_topbar
            ),
            "sidebar_width": scoped.get(
                "conjunto", "sidebar_width", default=default_sidebar
            ),
            "color_scheme": scoped.get("conjunto", "color_scheme", default="light"),
        }
    else:
        layout = {
            "style": default_style,
            "topbar_fixed": default_topbar,
            "sidebar_width": default_sidebar,
            "color_scheme": "light",
        }

    return {
        "globals": {
            "project_title": django_settings.PROJECT_TITLE,
            "version": __version__,
            "layout": layout["style"],  # kept for backwards-compat
        },
        "cj_layout": layout,
        "cj_toasts": _toast_config(),
        "menus": getattr(request, "menus", None),
        "vendor": Vendor.get_instance(),
    }


def settings(request):
    return {
        "scoped_settings": getattr(request, "scoped_settings", None),
        "PRODUCTION": getattr(django_settings, "PRODUCTION", False),
        "tabler": getattr(django_settings, "TABLER", {}),
    }
