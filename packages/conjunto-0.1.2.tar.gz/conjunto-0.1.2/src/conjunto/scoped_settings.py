"""Framework-level scoped setting registrations."""

from django.conf import settings as django_settings

from conjunto.settings.scoped.models import Scope
from conjunto.settings.scoped.registry import SettingRegistry

SettingRegistry.register(
    "conjunto",
    "layout_style",
    type="str",
    default=getattr(django_settings, "CONJUNTO_LAYOUT", "fluid"),
    help_text="Page layout: 'fluid' (container-fluid) or 'boxed' (container-xl).",
    icon="layout",
    writable_scopes=[Scope.VENDOR, Scope.TENANT, Scope.USER],
    lockable_scopes=[Scope.VENDOR, Scope.TENANT],
)

SettingRegistry.register(
    "conjunto",
    "topbar_fixed",
    type="bool",
    default=getattr(django_settings, "CONJUNTO_TOPBAR_FIXED", True),
    help_text="Whether the topbar uses position:fixed (True) or position:sticky (False).",
    icon="layout-navbar",
    writable_scopes=[Scope.VENDOR, Scope.TENANT, Scope.USER],
    lockable_scopes=[Scope.VENDOR, Scope.TENANT],
)

SettingRegistry.register(
    "conjunto",
    "sidebar_width",
    type="str",
    default=getattr(django_settings, "CONJUNTO_SIDEBAR_WIDTH", "15rem"),
    help_text="CSS length of the left sidebar (e.g. '15rem', '240px').",
    icon="layout-sidebar",
    writable_scopes=[Scope.VENDOR, Scope.TENANT, Scope.USER],
    lockable_scopes=[Scope.VENDOR, Scope.TENANT],
)

SettingRegistry.register(
    "conjunto",
    "maintenance_mode",
    type="bool",
    default=False,
    help_text="When True, non-staff users are redirected to /maintenance/.",
    icon="tool",
    writable_scopes=[Scope.VENDOR],
    lockable_scopes=[Scope.VENDOR],
)

SettingRegistry.register(
    "conjunto",
    "session_lifetime_default",
    type="int",
    default=getattr(django_settings, "CONJUNTO_SESSION_LIFETIME_DEFAULT", 0),
    help_text=(
        "Session lifetime in seconds when the user does NOT check "
        "'Remember me' on the login page. 0 means the session expires "
        "when the browser closes (Django default). Positive values set "
        "an absolute expiry via request.session.set_expiry()."
    ),
    icon="clock",
    writable_scopes=[Scope.VENDOR, Scope.TENANT],
    lockable_scopes=[Scope.VENDOR, Scope.TENANT],
)

SettingRegistry.register(
    "conjunto",
    "session_lifetime_remembered",
    type="int",
    default=getattr(
        django_settings, "CONJUNTO_SESSION_LIFETIME_REMEMBERED", 60 * 60 * 24 * 30
    ),
    help_text=(
        "Session lifetime in seconds when the user checks 'Remember me' "
        "on the login page. Default is 30 days (2592000 seconds)."
    ),
    icon="clock-check",
    writable_scopes=[Scope.VENDOR, Scope.TENANT],
    lockable_scopes=[Scope.VENDOR, Scope.TENANT],
)

SettingRegistry.register(
    "conjunto",
    "color_scheme",
    type="str",
    default="light",
    help_text="Color scheme: 'light' or 'dark'. Persisted per user to avoid flash of wrong theme on page load.",
    icon="palette",
    writable_scopes=[Scope.VENDOR, Scope.TENANT, Scope.DEVICE, Scope.USER],
    lockable_scopes=[Scope.VENDOR, Scope.TENANT],
)
