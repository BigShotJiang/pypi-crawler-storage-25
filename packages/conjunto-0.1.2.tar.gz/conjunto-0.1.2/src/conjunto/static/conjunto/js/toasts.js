/*
 * conjunto/toasts.js — HTMX-native Bootstrap/Tabler toast renderer.
 *
 * Sources of toasts (all routed through `renderToast`):
 *
 *   1. Initial page load: reads the JSON payload from
 *      <script id="cj-initial-toasts" type="application/json">, which
 *      is emitted by `conjunto/includes/toasts.html` whenever there
 *      are pending messages in a full-page response.
 *
 *   2. HTMX responses: `ConjuntoMessagesMiddleware` drains the Django
 *      messages framework and attaches an `HX-Trigger` header with a
 *      `conjunto:toasts` event. django-htmx dispatches that as a DOM
 *      CustomEvent on `body`; we listen for it and render each toast
 *      from `event.detail.toasts`.
 *
 *   3. Views that want to fire a single toast without going through
 *      the messages framework can call `conjunto.http.add_toast()`,
 *      which emits a `showToast` event with `{message, level,
 *      dismissible?, delay?}`. `conjunto.settings.views` already
 *      uses this pattern.
 */
(function () {
  "use strict";

  // Tabler ships soft-color utilities as `bg-{level}-lt`. Do NOT use
  // Bootstrap 5.3's `text-bg-*-lt` shorthand — Tabler doesn't define
  // those and the toasts end up with a transparent background.
  const LEVEL_CLASS = {
    debug: "bg-secondary-lt",
    info: "bg-info-lt",
    success: "bg-success-lt",
    warning: "bg-warning-lt",
    error: "bg-danger-lt",
  };

  function getContainer() {
    return document.getElementById("cj-toasts");
  }

  function getBootstrap() {
    // Tabler bundles bootstrap under `window.bootstrap`.
    return window.bootstrap || (window.tabler && window.tabler.bootstrap);
  }

  function renderToast(toast) {
    const container = getContainer();
    const bs = getBootstrap();
    if (!container || !bs || !bs.Toast) return;

    const level = (toast.level || toast.type || "info").toLowerCase();
    const levelClass = LEVEL_CLASS[level] || LEVEL_CLASS.info;
    const dismissible = Boolean(toast.dismissible);

    const el = document.createElement("div");
    el.className = `toast fade border-0 mb-1 ${levelClass}`;
    el.setAttribute("role", "alert");
    el.setAttribute("aria-live", "assertive");
    el.setAttribute("aria-atomic", "true");

    if (dismissible) {
      el.setAttribute("data-bs-autohide", "false");
    } else {
      const delay =
        toast.delay != null
          ? parseInt(toast.delay, 10)
          : parseInt(container.dataset.cjToastDelay || "6000", 10);
      el.setAttribute("data-bs-delay", String(delay));
    }

    const flex = document.createElement("div");
    flex.className = "d-flex";

    const body = document.createElement("div");
    body.className = "toast-body flex-grow-1";
    body.textContent = toast.message || "";
    flex.appendChild(body);

    if (dismissible) {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "btn-close ms-2 me-2 m-auto";
      btn.setAttribute("data-bs-dismiss", "toast");
      btn.setAttribute("aria-label", "Close");
      flex.appendChild(btn);
    }

    el.appendChild(flex);
    container.appendChild(el);

    const instance = new bs.Toast(el);
    el.addEventListener("hidden.bs.toast", () => el.remove());
    instance.show();
  }

  function renderToasts(toasts) {
    if (!Array.isArray(toasts)) return;
    toasts.forEach(renderToast);
  }

  function readInitial() {
    const node = document.getElementById("cj-initial-toasts");
    if (!node) return;
    try {
      renderToasts(JSON.parse(node.textContent));
    } catch (err) {
      // Malformed JSON — drop silently, nothing we can do.
      console.error("conjunto toasts: invalid initial JSON", err);
    }
  }

  // Initial payload (full-page load).
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", readInitial);
  } else {
    readInitial();
  }

  // Batch delivery from ConjuntoMessagesMiddleware via HX-Trigger.
  document.body.addEventListener("conjunto:toasts", (event) => {
    const detail = event.detail || {};
    renderToasts(detail.toasts || []);
  });

  // Single-shot delivery from `conjunto.http.add_toast` (or any
  // caller that dispatches a `showToast` event). HTMX dispatches
  // HX-Trigger events on `document.body` and they bubble to `window`,
  // so we listen on `document.body` only to avoid double-rendering.
  document.body.addEventListener("showToast", (event) => {
    const detail = event.detail || {};
    if (!detail.message) return;
    renderToast(detail);
  });
})();
