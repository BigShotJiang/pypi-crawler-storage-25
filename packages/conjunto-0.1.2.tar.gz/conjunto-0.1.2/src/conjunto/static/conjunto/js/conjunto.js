(() => {
  // ── Sidebar toggle ──────────────────────────────────────────
  window.cjToggleSidebar = function() {
    const w = window.innerWidth || document.documentElement.clientWidth;
    if (w >= 992) {
      const collapsed = document.body.classList.toggle('cj-sidebar-collapsed');
      try { localStorage.setItem('cj-sidebar-collapsed', collapsed ? '1' : '0'); } catch(e) {}
    } else {
      document.body.classList.toggle('cj-sidebar-open');
    }
  };

  // Close mobile sidebar on backdrop click
  document.addEventListener('click', function(e) {
    if (document.body.classList.contains('cj-sidebar-open') &&
        !e.target.closest('#cj-sidebar') &&
        !e.target.closest('#cj-sidebar-toggle')) {
      document.body.classList.remove('cj-sidebar-open');
    }
  });

  // ── Sidebar resize (desktop only) ──────────────────────────
  (function() {
    const handle = document.getElementById('cj-sidebar-resize');
    if (!handle) return;
    const MIN_W = 160, MAX_W = 480;
    let startX, startW;

    function saveSidebarWidth(width) {
      const url = document.body.dataset.sidebarWidthUrl;
      const csrfEl = document.querySelector('[name=csrfmiddlewaretoken]');
      if (url && csrfEl) {
        fetch(url, {
          method: 'POST',
          headers: {'Content-Type': 'application/json', 'X-CSRFToken': csrfEl.value},
          body: JSON.stringify({width: width})
        });
      }
    }

    handle.addEventListener('pointerdown', function(e) {
      if ((window.innerWidth || document.documentElement.clientWidth) < 992) return;
      e.preventDefault();
      startX = e.clientX;
      startW = document.getElementById('cj-sidebar').getBoundingClientRect().width;
      document.body.classList.add('cj-sidebar-resizing');
      handle.setPointerCapture(e.pointerId);
    });
    handle.addEventListener('pointermove', function(e) {
      if (!document.body.classList.contains('cj-sidebar-resizing')) return;
      const w = Math.min(MAX_W, Math.max(MIN_W, startW + e.clientX - startX));
      document.body.style.setProperty('--cj-sidebar-width', w + 'px');
    });
    handle.addEventListener('pointerup', function(e) {
      if (!document.body.classList.contains('cj-sidebar-resizing')) return;
      document.body.classList.remove('cj-sidebar-resizing');
      handle.releasePointerCapture(e.pointerId);
      const w = Math.round(document.getElementById('cj-sidebar').getBoundingClientRect().width);
      try { localStorage.setItem('cj-sidebar-width', w); } catch(e) {}
      saveSidebarWidth(w + 'px');
    });
    handle.addEventListener('dblclick', function() {
      const def = document.body.dataset.defaultSidebarWidth || '15rem';
      document.body.style.setProperty('--cj-sidebar-width', def);
      try { localStorage.removeItem('cj-sidebar-width'); } catch(e) {}
      saveSidebarWidth(def);
    });
  })();

  // ── Sortable ────────────────────────────────────────────────
  const sortables = document.querySelectorAll('.sortable');
  sortables.forEach((sortable) => {
    new Sortable(sortable, {
      animation: 150,
      ghostClass: 'bg-info',
      handle: '.handle'
    })
  })

  // -------------- Modals --------------
  // Based on Benoit Blanchon's django-htmx modal pattern:
  // https://blog.benoitblanchon.fr/django-htmx-modal-form/
  //
  // Contract:
  //   • A trigger fetches a modal view with `hx-target="#dialog"` and
  //     `hx-swap="innerHTML"`. The view returns the inner dialog
  //     HTML (typically `conjunto/modal_form.html`).
  //   • `htmx:afterSwap` on `#dialog` → show the Bootstrap modal.
  //   • A 204 No Content response targeting `#dialog` → close the
  //     modal. This is the `ModalFormViewMixin` success flow: on
  //     save, the view returns 204 with `HX-Trigger: <event>` and
  //     no body, the listener cancels the swap so the form element
  //     stays put through the close animation, and Bootstrap hides
  //     the modal.
  //   • On `hidden.bs.modal`, wipe `#dialog` so the next open starts
  //     from a clean slate.
  const modalEl = document.getElementById('modal')
  if (modalEl) {
    const bsModal = (window.bootstrap || window.tabler).Modal.getOrCreateInstance(modalEl)

    document.addEventListener('htmx:beforeSwap', (e) => {
      // 204 No Content from any element inside the modal → close it.
      // The check uses .closest('#modal') (not target.id === 'dialog')
      // because the form's submit request has hx-target="this", which
      // makes target be the <form id="modal-form">, NOT #dialog. We
      // want both flows to work:
      //   • open flow: GET → swap into #dialog → afterSwap → show
      //   • submit flow: POST → 204 → beforeSwap → hide
      // Status code is checked instead of `xhr.response`/`xhr.responseText`
      // because `xhr.response` can be falsy depending on responseType
      // even for valid bodies, which would wrongly cancel the swap.
      const target = e.detail.target
      if (target && target.closest && target.closest('#modal') && e.detail.xhr.status === 204) {
        bsModal.hide()
        e.detail.shouldSwap = false
      }
    })

    document.addEventListener('htmx:afterSwap', (e) => {
      // Open flow: a non-empty response was swapped into #dialog →
      // show the modal. Restricted to target.id === 'dialog' so that
      // form submits whose response gets swapped into the form
      // itself (hx-target="this") do not re-trigger show().
      if (e.detail.target.id === 'dialog') {
        bsModal.show()
      }
    })

    // Focus the first visible input/textarea/submit after the modal
    // is shown, so keyboard users land somewhere useful.
    modalEl.addEventListener('shown.bs.modal', () => {
      const selectors = [
        'textarea:not([type="hidden"])',
        'input:not([type="hidden"])',
        'button[type="submit"]',
      ]
      for (const sel of selectors) {
        for (const el of modalEl.querySelectorAll(sel)) {
          if (!el.hidden && !el.disabled) {
            el.focus()
            return
          }
        }
      }
    })

    // Clean up the dialog on close so stale form state does not
    // leak into the next open.
    modalEl.addEventListener('hidden.bs.modal', () => {
      const dialog = document.getElementById('dialog')
      if (dialog) dialog.innerHTML = ''
    })
  }

  // // Litepicker
  // const litepickers = document.querySelectorAll('.textinput');
  // console.log("registering ",litepickers)
  // litepickers.forEach((litepicker) => {
  //   new Litepicker({
  //     element: litepicker
  //   });
  // })

  window.toggleTheme = function () {
    const currentTheme = document.documentElement.getAttribute('data-bs-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-bs-theme', newTheme);
    if (newTheme === 'dark') {
      document.documentElement.classList.add('theme-dark');
    } else {
      document.documentElement.classList.remove('theme-dark');
    }
    localStorage.setItem('tabler-theme', newTheme);

    // Persist color scheme server-side so the next full page load
    // renders the correct data-bs-theme attribute without a flash.
    var urlEl = document.querySelector('[data-color-scheme-url]');
    if (urlEl) {
      var url = urlEl.getAttribute('data-color-scheme-url');
      var csrfToken = '';
      var csrfEl = document.querySelector('[name=csrfmiddlewaretoken]');
      if (csrfEl) csrfToken = csrfEl.value;
      fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRFToken': csrfToken,
        },
        body: JSON.stringify({color_scheme: newTheme}),
      }).catch(function () { /* best-effort, localStorage is the fallback */ });
    }
  };
})();
