from django.urls import path

from .views import (
    MaintenanceView,
    ModelAutocompleteView,
    SaveColorSchemeView,
    SaveSidebarWidthView,
)

app_name = "conjunto"

urlpatterns = [
    path("maintenance/", MaintenanceView.as_view(), name="maintenance"),
    path("autocomplete/", ModelAutocompleteView.as_view(), name="autocomplete"),
    path("sidebar-width/", SaveSidebarWidthView.as_view(), name="sidebar-width"),
    path("color-scheme/", SaveColorSchemeView.as_view(), name="color-scheme"),
]
