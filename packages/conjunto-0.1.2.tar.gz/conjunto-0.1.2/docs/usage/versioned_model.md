# HistoryVersionedModel

Conjunto provides a `HistoryVersionedModel` abstract model that tracks changes in a separate
snapshot table. On every save, the previous field values are stored as a JSON snapshot in
`VersionSnapshot` before the record is updated. The primary key stays stable, making it safe
to reference via `ForeignKey` from other models.

## Model

Inherit from `HistoryVersionedModel` to add versioning to your model:

```python
from conjunto.models import HistoryVersionedModel
from django.db import models

class Document(HistoryVersionedModel):
    title = models.CharField(max_length=255)
    content = models.TextField()
```

## Fields

`HistoryVersionedModel` adds these fields to your model:

| Field         | Type            | Description                         |
|---------------|-----------------|-------------------------------------|
| `version`     | PositiveInteger | Version number (1, 2, 3, ...)       |
| `created_at`  | DateTime        | Set on first save, never changes    |
| `modified_at` | DateTime        | Updated automatically on every save |

The snapshot history is stored in the separate `VersionSnapshot` table, not on the main model.

## Behavior

- **First save**: Creates the record with `version=1`, no snapshot is written yet.
- **Subsequent saves**: Snapshots the current DB state into `VersionSnapshot`, then increments
  `version` and updates the main record in-place. The PK never changes.

```python
doc = Document(title="Hello", content="First draft")
doc.save()
# doc.version == 1, no history yet

doc.content = "Revised draft"
doc.save()
# doc.version == 2, doc.pk unchanged
# VersionSnapshot stores the v1 state

doc.content = "Final version"
doc.save()
# doc.version == 3
# VersionSnapshot stores v1 and v2 states
```

## Accessing history

Use `get_history()` on any instance to retrieve previous snapshots, ordered by version:

```python
for snapshot in doc.get_history():
    print(f"v{snapshot.version} saved at {snapshot.saved_at}")
    print(snapshot.snapshot["content"])
```

Each `VersionSnapshot` entry has:

| Field            | Description                                   |
|------------------|-----------------------------------------------|
| `version`        | Version number this snapshot was taken from   |
| `snapshot`       | JSON dict of all field values at that version |
| `saved_at`       | When the snapshot was written                 |
| `content_object` | Generic relation back to the main object      |

## Example: Content Management

```python
class Article(HistoryVersionedModel):
    title = models.CharField(max_length=255)
    body = models.TextField()
    author = models.ForeignKey(User, on_delete=models.CASCADE)

# Create initial article
article = Article(title="My Article", body="First draft", author=user)
article.save()

# Update - history of v1 is preserved in VersionSnapshot
article.body = "Revised draft"
article.save()

# Inspect history
for snapshot in article.get_history():
    print(f"v{snapshot.version}: {snapshot.snapshot['body']}")

# Stable PK means ForeignKeys always point to the current version
comment = Comment(article=article, text="Great post!")
comment.save()
# comment.article still resolves correctly after further saves
```
