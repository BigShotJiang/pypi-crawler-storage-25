# Tables with CRUD row actions

Conjunto ships a small reusable layer on top of
[`django-tables2`](https://django-tables2.readthedocs.io/) that gives
you a consistent, recognizable set of CRUD action buttons on every
list table in your project, plus pluggable extra actions and automatic
HTMX refresh on success events.

The module lives in `conjunto.tables` and has three building blocks:

| Symbol | Role |
|---|---|
| `RowAction` | Dataclass describing one row-level action button |
| `ActionsColumn` | `django_tables2.Column` that renders a row's buttons |
| `CrudTableMixin` | Table mixin wiring the column, actions, and listen events |
| `IRowAction` | GDAPS interface for plugging extra actions into a table |

The default visual style is a right-aligned Tabler `btn-list` of
`btn btn-sm btn-icon` buttons — the same look the rest of conjunto
uses. Clicks default to HTMX; the delete action opens a modal
confirm dialog by default.

## The basic pattern

```python
# projects/tables.py
import django_tables2 as tables
from conjunto.tables import CrudTableMixin
from .models import Project


class ProjectTable(CrudTableMixin, tables.Table):
    crud_url_namespace = "projects:project"

    class Meta:
        model = Project
        fields = ("name", "owner", "created_at")
```

That is the whole setup. The table:

- gets an `actions` column appended at the end of its sequence,
- renders an edit button (`<ns>_update`) and a delete button
  (`<ns>_delete`),
- wires itself up as `#cj-table-projects-project` with the listen
  events `projects:project:created`, `projects:project:changed`,
  and `projects:project:deleted`.

Your URLConf needs two routes matching the namespace:

```python
urlpatterns = [
    path("projects/<int:pk>/edit/", ProjectUpdateView.as_view(),
         name="project_update"),
    path("projects/<int:pk>/delete/", ProjectDeleteView.as_view(),
         name="project_delete"),
]
```

> The URL-name convention `<namespace>_update` / `<namespace>_delete`
> (with a `pk` kwarg) is a hard contract. If your routes don't
> follow it, either add them or build a custom action yourself
> (see "Custom actions" below).

## The `RowAction` dataclass

Every button is a `RowAction`:

```python
from conjunto.tables import RowAction

RowAction(
    name="publish",
    label=_("Publish"),
    icon="send",
    url=lambda record: reverse("projects:project_publish", kwargs={"pk": record.pk}),
    method="post",
    htmx=True,
    target="#cj-dialog",
    swap="innerHTML",
    confirm=_("Really publish this project?"),
    confirm_style="inline",           # or "modal"
    variant="btn-ghost-secondary",    # Tabler btn variant
    permission="projects.publish_project",  # str or (record, request) -> bool
    visible=lambda rec, req: not rec.is_archived,
    weight=50,
)
```

Key points:

- **`url`** is either a string or a callable `(record) -> str`. Use a
  lambda with `reverse(...)` for anything that depends on the record.
- **`htmx=True`** (default) produces `hx-<method>` / `hx-target` /
  `hx-swap` attributes. `htmx=False` renders a plain `<a href>` — use
  this for plain navigation or static links.
- **`permission`** is either a Django permission string
  (`"app.codename"`) or a callable `(record, request) -> bool`. Both
  `permission` and `visible` must pass for the button to render.
- **`weight`** controls ordering inside one row (lowest first).
  Standard edit = 10, delete = 20.

## Confirm flows

The delete action defaults to **modal confirm**: the button issues
`hx-get` against the delete view, loads the result into
`#cj-dialog`, and the actual delete happens when the user submits
the confirmation form inside the modal. This is the standard flow
and works with `conjunto.htmx.views.ModalDeleteView`.

To use a browser-native confirm prompt instead:

```python
class ProjectTable(CrudTableMixin, tables.Table):
    crud_url_namespace = "projects:project"
    delete_confirm_style = "inline"
```

With `confirm_style="inline"` the button uses `hx-confirm` and
`hx-post`s straight to the delete URL.

The modal target defaults to `#cj-dialog`. Override it per table:

```python
class ProjectTable(CrudTableMixin, tables.Table):
    crud_url_namespace = "projects:project"
    dialog_target = "#my-dialog"
```

Or per action via `RowAction.target`.

## Custom actions

Override `get_standard_actions` to replace the built-in edit/delete
list entirely, or `get_row_actions` to inject per-row logic without
touching the standard actions:

```python
from conjunto.tables import CrudTableMixin, RowAction, standard_edit_action

class ProjectTable(CrudTableMixin, tables.Table):
    crud_url_namespace = "projects:project"

    def get_row_actions(self, record, request):
        actions = super().get_row_actions(record, request)
        if record.is_draft:
            actions.append(RowAction(
                name="publish",
                label=_("Publish"),
                icon="send",
                url=lambda r: reverse("projects:project_publish", kwargs={"pk": r.pk}),
                method="post",
                weight=15,
            ))
        return sorted(actions, key=lambda a: a.weight)
```

Opt out of one of the standard actions by restricting
`crud_actions`:

```python
class ProjectTable(CrudTableMixin, tables.Table):
    crud_url_namespace = "projects:project"
    crud_actions = ("edit",)   # no delete button
```

Or disable standard actions entirely (`crud_actions = ()`) and build
everything yourself in `get_standard_actions`.

## Plugin actions via `IRowAction`

For actions that come from a different app (classic GDAPS
extensibility), use the `IRowAction` interface. One interface
implementation represents one action:

```python
# other_app/row_actions.py
from conjunto.tables import IRowAction, RowAction

class ArchiveProjectAction(IRowAction):
    menu = "projects.row_actions"
    weight = 30

    def to_row_action(self, request, record):
        if record.is_archived:
            return None   # skip
        return RowAction(
            name="archive",
            label="Archive",
            icon="archive",
            url=reverse("other_app:archive_project", kwargs={"pk": record.pk}),
            method="post",
        )
```

Opt the table in:

```python
class ProjectTable(CrudTableMixin, tables.Table):
    crud_url_namespace = "projects:project"
    extra_actions_menu = "projects.row_actions"
```

All `IRowAction` plugins whose `menu` attribute matches
`extra_actions_menu` are collected, their `to_row_action` is called
with `(request, record)`, and any non-`None` results are merged into
the table's row actions (subject to the same permission/visible
filter and weight sorting).

## Auto-refresh on success events

`CrudTableMixin` exposes two template helpers that make the whole
table refresh automatically when an HTMX form view fires a success
event:

- `table.wrapper_id` — a stable DOM id such as `cj-table-projects-project`.
- `table.hx_trigger` — a comma-joined `"<event> from:body"` list with
  the default CRUD events (`<ns>:created`, `<ns>:changed`,
  `<ns>:deleted`).

Wrap the rendered table in one element that self-refetches:

```django
{% load render_table from django_tables2 %}

<div id="{{ table.wrapper_id }}"
     hx-get="{{ request.path }}"
     hx-trigger="{{ table.hx_trigger }}"
     hx-swap="outerHTML"
     hx-select="#{{ table.wrapper_id }}">
  {% render_table table %}
</div>
```

Your modal forms (built on `HtmxFormViewMixin` /
`SuccessEventMixin`) already return an empty 204 with
`HX-Trigger: <ns>:created` (or `:changed` / `:deleted`) on success —
the table wrapper picks it up and re-renders itself. No custom JS.

Override `listen_events` on the table to listen for a different set
of events, or override `get_listen_events()` for dynamic logic.

## Templates and styling

The column renders
`conjunto/tables/_row_actions.html`, a small template that emits a
Tabler `btn-list` with one `<button>` (or `<a>`) per action. If you
need a radically different look, override that template in your
project's template path — the context is
`{"buttons": [{"attrs": {...}, "icon": str, "name": str}, ...]}`.

For everyday tweaks, prefer the `variant` attribute on `RowAction`
(Tabler button classes, e.g. `btn-ghost-secondary`, `btn-ghost-danger`,
`btn-ghost-primary`) — it composes with the standard
`btn btn-sm btn-icon` base so the row keeps a consistent rhythm.
