# Menu System

Conjunto provides a powerful, plugin-friendly menu system through the `IMenuItem` interface. Menu items are automatically discovered via GDAPS and support unlimited hierarchical nesting.

## Quick Start

### Basic Menu Item

```python
from conjunto.menu import IMenuItem
from django.urls import reverse_lazy
from django.utils.translation import gettext_lazy as _

class UsersMenuItem(IMenuItem):
    menu = "main"           # Which menu to appear in
    title = _("Users")      # Display title
    slug = "users"          # Unique identifier
    url = reverse_lazy("users:list")
    icon = "users"          # Bootstrap icon name
    weight = 10             # Sort order (higher = lower in menu)
```

### Nested Menu Items

Create hierarchical menus using the `parent` attribute:

```python
class SettingsMenuItem(IMenuItem):
    menu = "main"
    title = _("Settings")
    slug = "settings"
    icon = "settings"
    weight = 100

class AccountSettingsItem(IMenuItem):
    menu = "main"
    title = _("Account")
    slug = "account"
    parent = "settings"  # ✅ Reference parent by slug (recommended)
    url = reverse_lazy("settings:account")

class SecuritySettingsItem(IMenuItem):
    menu = "main"
    title = _("Security")
    slug = "security"
    parent = "settings"  # Same parent - becomes sibling to AccountSettingsItem
    url = reverse_lazy("settings:security")
    weight = 10
```

**Deep Nesting** (unlimited levels):

```python
class PrivacySettingsItem(IMenuItem):
    menu = "main"
    title = _("Privacy")
    slug = "privacy"
    parent = "account"  # Child of AccountSettingsItem
    url = reverse_lazy("settings:privacy")
```

## Parent Reference Methods

### Slug-Based (Recommended)

**Use for:** Cross-plugin references, loose coupling

```python
class MyMenuItem(IMenuItem):
    parent = "settings"  # Reference by slug string
```

**Advantages:**
- ✅ No import dependencies between plugins
- ✅ Works across different codebases
- ✅ Plugin-friendly architecture

**Validation:** If parent slug doesn't exist, you'll see a warning:
```
UserWarning: MenuItem 'MyMenuItem' (slug='my-item') references parent 'settings'
which was not found. This menu item will appear at top level.
```

### Class-Based

**Use for:** Same-module items, type safety

```python
from my_app.menus import SettingsMenuItem

class MyMenuItem(IMenuItem):
    parent = SettingsMenuItem  # Reference by class
```

**Advantages:**
- ✅ IDE autocomplete and refactoring support
- ✅ Type checking

**Disadvantages:**
- ❌ Requires import access
- ❌ Tight coupling

## Template Usage

### Displaying Menus

In your template (menu items automatically available via context processor):

```django
<ul class="nav">
{% for item in menus.main %}
  <li class="nav-item">
    <a href="{{ item.url }}" class="nav-link{% if item.selected %} active{% endif %}">
      <i class="ti ti-{{ item.icon }}"></i>
      {{ item.title }}
    </a>

    {# Render nested items #}
    {% if item.has_children %}
      <ul class="submenu">
        {% for child in item.children %}
          <li><a href="{{ child.url }}">{{ child.title }}</a></li>
        {% endfor %}
      </ul>
    {% endif %}
  </li>
{% endfor %}
</ul>
```

### Multi-Level Navigation

```django
{% for item in menus.main %}
  {% if not item.has_parent %}  {# Only show top-level items #}
    <li>
      <a href="{{ item.url }}">{{ item.title }}</a>
      {% if item.has_children %}
        <ul>
          {% for child in item.children %}
            <li>
              <a href="{{ child.url }}">{{ child.title }}</a>
              {# Recursively render deeper levels if needed #}
              {% if child.has_children %}
                <ul>
                  {% for grandchild in child.children %}
                    <li><a href="{{ grandchild.url }}">{{ grandchild.title }}</a></li>
                  {% endfor %}
                </ul>
              {% endif %}
            </li>
          {% endfor %}
        </ul>
      {% endif %}
    </li>
  {% endif %}
{% endfor %}
```

## Advanced Features

### Permission-Based Visibility

```python
class AdminMenuItem(IMenuItem):
    menu = "main"
    title = _("Admin")
    slug = "admin"
    permissions_required = ["auth.view_user", "auth.change_user"]
    url = reverse_lazy("admin:index")
```

### Custom Visibility Logic

Override `_is_visible()` for complex visibility rules:

```python
class StaffOnlyMenuItem(IMenuItem):
    menu = "main"
    title = _("Staff Area")
    slug = "staff"
    url = reverse_lazy("staff:index")

    def _is_visible(self):
        # Always call parent first to check permissions
        if not super()._is_visible():
            return False
        # Custom logic
        return self._request.user.is_staff
```

### Dynamic Titles and Icons

Override `get_title()` and `get_icon()` methods:

```python
class UserProfileItem(IMenuItem):
    menu = "user"
    title = _("Profile")  # Fallback title
    slug = "profile"
    icon = "user"  # Fallback icon
    url = reverse_lazy("profile:view")

    def get_title(self):
        return f"{self._request.user.username}'s Profile"

    def get_icon(self):
        return "user-check" if self._request.user.is_verified else "user"
```

### Badges

```python
class NotificationsItem(IMenuItem):
    menu = "main"
    title = _("Notifications")
    slug = "notifications"
    badge = "5"  # Static badge
    badge_class = "bg-red text-red-fg badge-notification"
```

**Note:** Badges are currently static. For dynamic badges, consider using custom template logic or overriding methods in future versions.

### Separators

```python
class LogoutMenuItem(IMenuItem):
    menu = "user"
    title = _("Profile")
    slug = "profile"
    separator_after = True  # Show separator after this item
    weight = 999
```

## Menu Attributes Reference

| Attribute | Type | Default | Description |
|-----------|------|---------|-------------|
| `menu` | `str` | `"main"` | Menu name (e.g., "main", "user", "page_actions") |
| `title` | `str` | Required | Display title (use `get_title()` for dynamic) |
| `slug` | `str` | Auto-generated | Unique identifier (used for parent references) |
| `parent` | `str\|type\|None` | `None` | Parent menu item (slug string or class) |
| `url` | `str` | `""` | Target URL (only in IMenuItem) |
| `icon` | `str` | `""` | Bootstrap icon name (use `get_icon()` for dynamic) |
| `weight` | `int` | `0` | Sort order (higher = lower position) |
| `permissions_required` | `list[str]\|None` | `None` | Required Django permissions (all must match) |
| `badge` | `str` | `""` | Badge text/count (static) |
| `badge_class` | `str` | `""` | Badge CSS classes |
| `separator` | `bool` | `False` | Show separator after item |
| `collapsed` | `bool` | `True` | Initially collapsed (for expandable menus) |
| `disabled` | `bool` | `False` | Disabled state (use `get_disabled()` for dynamic) |
| `exact_url` | `bool` | `False` | Exact URL match for "active" state |

## Overridable Methods

| Method | Return Type | Purpose |
|--------|-------------|---------|
| `get_title()` | `str` | Returns dynamic title |
| `get_icon()` | `str` | Returns dynamic icon name |
| `get_disabled()` | `bool` | Returns dynamic disabled state |
| `get_slug()` | `str` | Returns item slug |
| `_is_visible()` | `bool` | Custom visibility logic (call `super()` first) |
| `selected()` | `bool` | Check if item matches current URL |

## Helper Methods

```python
# Check if item has child items
if item.has_children():
    for child in item.children():
        print(child.title)

# Check if item has a parent
if item.has_parent():
    parent = item.get_parent()
    print(f"Parent: {parent.title}")

# Check if item is currently selected
if item.selected():
    # Highlight this menu item
    pass
```

## Architecture Notes

### How It Works

1. **Discovery**: GDAPS automatically discovers all `IMenuItem` implementations
2. **Tree Building**: During menu initialization:
   - All items are instantiated and indexed by slug
   - Parent-child relationships are resolved
   - Children are sorted by weight
   - Only top-level items appear in menu lists
3. **Performance**: Tree structure built once per request (cached)

### Best Practices

✅ **DO:**
- Use slug-based parent references for cross-plugin menus
- Keep slugs unique and descriptive
- Use `weight` for consistent ordering
- Validate permissions at both menu and view level

❌ **DON'T:**
- Don't use duplicate slugs (causes parent resolution issues)
- Don't rely solely on menu visibility for access control
- Don't create circular parent references
- Don't use class-based parents across plugin boundaries

## Examples

### Complete Plugin Menu

```python
# my_plugin/menus.py
from conjunto.menu import IMenuItem
from django.urls import reverse_lazy
from django.utils.translation import gettext_lazy as _

class PluginMainMenu(IMenuItem):
    menu = "main"
    title = _("My Plugin")
    slug = "my-plugin"
    icon = "puzzle"
    weight = 50

class PluginDashboard(IMenuItem):
    menu = "main"
    title = _("Dashboard")
    slug = "plugin-dashboard"
    parent = "my-plugin"
    url = reverse_lazy("my_plugin:dashboard")
    weight = 0

class PluginSettings(IMenuItem):
    menu = "main"
    title = _("Settings")
    slug = "plugin-settings"
    parent = "my-plugin"
    url = reverse_lazy("my_plugin:settings")
    permission_required = ["my_plugin.change_settings"]
    weight = 100
```

### Action Menu

```python
class PageActionMenu(IMenuItem):
    menu = "page_actions"
    title = _("Export")
    slug = "export"
    icon = "download"
    url = reverse_lazy("export")

    def _is_visible(self):
        if not super()._is_visible():
            return False
        # Only show if user has export permission and item exists
        return (self._request.user.has_perm("app.export") and
                hasattr(self._request, 'resolver_match') and
                "id" in self._request.resolver_match.kwargs)
```

## Migration Guide

If you're upgrading from an older version, here are the key changes:

### Breaking Changes

1. **`permission_required` → `permissions_required`** (plural, always a list)
   ```python
   # Old
   permission_required = "auth.add_user"
   # New
   permissions_required = ["auth.add_user"]
   ```

2. **`check()` → `_is_visible()`** override
   ```python
   # Old
   @staticmethod
   def check(request):
       return request.user.is_staff

   # New
   def _is_visible(self):
       if not super()._is_visible():
           return False
       return self._request.user.is_staff
   ```

3. **Dynamic `title`/`icon` → `get_title()`/`get_icon()` methods**
   ```python
   # Old
   title = lambda request: request.user.username
   icon = lambda request: "user-check"

   # New
   title = "User"  # Static fallback
   def get_title(self):
       return self._request.user.username

   icon = "user"  # Static fallback
   def get_icon(self):
       return "user-check"
   ```

4. **`view_name` attribute removed** - Use `_is_visible()` instead:
   ```python
   # Old
   view_name = "users:detail"

   # New
   def _is_visible(self):
       if not super()._is_visible():
           return False
       return (hasattr(self._request, 'resolver_match') and
               self._request.resolver_match.view_name == "users:detail")
   ```

5. **Menu items require `request` parameter** when instantiated directly:
   ```python
   # Old
   item = MyMenuItem()

   # New
   item = MyMenuItem(request=request)
   ```

6. **`slug` access via `get_slug()` method**:
   ```python
   # Old
   slug_value = item.slug

   # New
   slug_value = item.get_slug()
   ```
