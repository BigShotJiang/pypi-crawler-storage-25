# Template Block Reference

This page lists **every `{% block %}`** exposed by Conjunto's shipped
templates, so you know exactly which hooks you can override when
extending them. Blocks are grouped by template, starting with the two
base templates (`base.html` and `app_base.html`) and followed by the
various form / modal templates.

For a high-level walk-through of the layout (topbar, sidebar, canvas,
statusbar, offcanvas) see [Layout & Templates](layout.md).

---

## `conjunto/base.html` (slim, generic)

Since 0.1.2 `conjunto/base.html` is a slim document shell without
topbar, sidebar, canvas or statusbar. Use it for public / marketing /
chrome-less pages. For the full application layout extend
[`conjunto/app_base.html`](#conjuntoapp_basehtml) instead.

```django
{% extends "conjunto/base.html" %}
```

### Block tree

```
title           ← <title> tag
meta            ← extra <head> meta tags
extra_css       ← extra <link rel="stylesheet">
body_attrs     ← extra attributes injected on <body>
body            ← everything inside <body> (except modals, toasts, scripts)
modal           ← modal dialog container (default: #modal with #dialog)
toasts          ← toast container (default: includes toasts.html)
scripts         ← extra <script> tags at end of <body>
```

---

## `conjunto/app_base.html`

The full application layout (topbar + sidebar + canvas + statusbar +
offcanvas). **Extend this template** for regular in-app pages:

```django
{% extends "conjunto/app_base.html" %}
```

### Block tree

Indentation shows nesting; children are only rendered when their parent
block is rendered.

```
title                         ← <title> tag
meta                          ← extra <head> meta tags
extra_css                     ← extra <link rel="stylesheet">

top_bar                       ← entire <header id="cj-topbar">
├── sidebar_toggle            ← hamburger button that toggles the sidebar
├── top_bar_brand             ← logo + project name (left)
├── top_bar_center            ← horizontal nav, renders menus.main
├── top_bar_actions           ← page-specific icon buttons (e.g. offcanvas triggers)
└── top_bar_right             ← theme toggle + user dropdown (menus.user)

sidebar                       ← left sidebar (default: includes sidebar.html, renders menus.sidebar)

canvas                        ← entire scrollable content area (.cj-page-content)
├── page_header               ← header strip above the content
│   ├── page_pretitle_wrapper ← wrapper around pretitle (override to hide the <div>)
│   │   └── page_pretitle     ← small muted line above the title
│   ├── page_title            ← <h2 class="page-title">
│   └── page_actions          ← button list on the right of the header
├── messages                  ← reserved for Django messages (rendered as toasts by default)
└── content                   ← your page body

footer                        ← entire <footer id="cj-statusbar">
└── statusbar                 ← inner statusbar content (default: includes footer.html, renders menus.footer)

offcanvas_left                ← static content for #cj-offcanvas-left
offcanvas_right               ← static content for #cj-offcanvas-right

modal                         ← reserved slot for modal dialogs
toasts                        ← toast container (default: includes toasts.html)
scripts                       ← extra <script> tags at end of <body>
```

### Block reference table

| Block                   | Default content                                             | Typical override                            |
|-------------------------|-------------------------------------------------------------|---------------------------------------------|
| `title`                 | `site.name` or `"Conjunto"`                                 | Page-specific `<title>`                     |
| `meta`                  | *(empty)*                                                   | Extra `<meta>` tags                         |
| `extra_css`             | *(empty)*                                                   | Additional stylesheets                      |
| `top_bar`               | Full topbar (`fixed-top` / `sticky-top`)                    | Replace the whole topbar                    |
| `sidebar_toggle`        | Hamburger button (`#cj-sidebar-toggle`) that toggles sidebar | Hide or replace the sidebar toggle button   |
| `top_bar_brand`         | Logo + project title, linked to `/`                         | Custom brand or hide logo                   |
| `top_bar_center`        | Horizontal nav built from `menus.main`                      | Custom center content                       |
| `top_bar_actions`       | *(empty)*                                                   | Page-level icon buttons, offcanvas triggers |
| `top_bar_right`         | Theme toggle + user menu (`menus.user`) + login/logout      | Custom right cluster                        |
| `sidebar`               | `includes/sidebar.html` (renders `menus.sidebar`, 2 levels) | Custom sidebar                              |
| `canvas`                | `page_header` + `messages` + page body                      | Fully custom scroll area                    |
| `page_header`           | `.page-header` with title row + actions                     | Hide or replace the header                  |
| `page_pretitle_wrapper` | `<div class="page-pretitle">` around `page_pretitle`        | Override to hide the wrapper entirely       |
| `page_pretitle`         | *(empty)*                                                   | Small label above the title                 |
| `page_title`            | *(empty)*                                                   | Page title (`<h2>`)                         |
| `page_actions`          | *(empty)*                                                   | Buttons on the right of the header          |
| `messages`              | *(empty — toasts render them)*                              | Only override if you want inline alerts     |
| `content`               | *(empty)*                                                   | **Your main page content**                  |
| `footer`                | `<footer id="cj-statusbar">` wrapper                        | Replace the whole statusbar wrapper         |
| `statusbar`             | `includes/footer.html` (copyright + `menus.footer`)         | Custom statusbar content                    |
| `offcanvas_left`        | *(empty)*                                                   | Static left offcanvas content               |
| `offcanvas_right`       | *(empty)*                                                   | Static right offcanvas content              |
| `modal`                 | *(empty)*                                                   | Modal dialog placeholder                    |
| `toasts`                | `includes/toasts.html`                                      | Usually leave as-is                         |
| `scripts`               | *(empty)*                                                   | Extra JS at end of `<body>`                 |

!!! tip "Child-friendly overrides"
    Most pages only need to override `title`, `page_pretitle`,
    `page_title`, `page_actions` and `content`. Everything else is
    opt-in.

---

## `conjunto/layouts/empty.html`

A minimal layout without topbar or sidebar — useful for login,
registration, password reset and error pages. It **extends
`app_base.html`** and blanks out the topbar / sidebar blocks, so all
`base.html` blocks are still available; the ones listed below are the
ones it *re-defines*.

```django
{% extends "conjunto/layouts/empty.html" %}
```

| Block       | Behaviour                                                                 |
|-------------|---------------------------------------------------------------------------|
| `extra_css` | Inherits and appends layout tweaks (centered `.cj-empty-wrapper`).        |
| `top_bar`   | **Emptied** — no topbar rendered.                                         |
| `sidebar`   | **Emptied** — no sidebar rendered.                                        |
| `canvas`    | Replaced with a centered flex wrapper containing `messages` + `content`.  |
| `messages`  | Inline Bootstrap alerts (full-page layout has no toast container here).   |
| `content`   | Your main content, vertically centered on screen.                         |

All other `app_base.html` blocks (`title`, `meta`, `extra_css`, `footer`,
`statusbar`, `scripts`, …) still work as usual.

---

## `conjunto/modal_form.html`

The base template for HTMX modal dialogs (used by `HtmxFormViewMixin`
and `ModalFormView`). It is **not** a full-page template — it renders
only the `.modal-content` element that gets swapped into the shared
`#dialog` target. See [`HtmxFormViewMixin`](../../CLAUDE.md) for the
wiring.

```django
{% extends "conjunto/modal_form.html" %}
```

### Block tree

```
modal-header
└── header
    ├── title              ← defaults to {{ modal_title }}
    └── action-buttons     ← extra buttons in the header (next to the close ×)

modal-body
└── body
    └── content            ← free-text content, rendered before the crispy form
    (crispy form is rendered automatically if `form` is in the context)

modal-footer
└── footer
    └── submit-button      ← the primary submit button (htmx POST)
```

### Block reference table

| Block            | Default content                                          | When to override                                |
|------------------|----------------------------------------------------------|-------------------------------------------------|
| `modal-header`   | `<div class="modal-header">` wrapper                     | Replace the whole header row                    |
| `header`         | Title + action buttons + close `×`                       | Replace inner header content                    |
| `title`          | `{{ modal_title }}`                                      | Custom title markup                             |
| `action-buttons` | *(empty)*                                                | Extra icon buttons in the header                |
| `modal-body`     | `<div class="modal-body">` wrapper                       | Replace body wrapper                            |
| `body`           | `content` block + auto-rendered `{% crispy form %}`      | Full custom body (skip crispy auto-render)      |
| `content`        | *(empty)*                                                | Static text / markup shown above the form       |
| `modal-footer`   | `<div class="modal-footer">` wrapper                     | Replace the whole footer / hide it entirely     |
| `footer`         | Cancel button + `submit-button`                          | Replace footer buttons                          |
| `submit-button`  | Primary `hx-post` submit button                          | Custom submit button (label, css class, …)      |

---

## `conjunto/modal_confirm_delete.html`

Tiny specialisation of `modal_form.html` used for standard delete
confirmation dialogs.

```django
{% extends "conjunto/modal_confirm_delete.html" %}
```

| Block     | Default                                            | When to override              |
|-----------|----------------------------------------------------|-------------------------------|
| `content` | `"Do you really want to delete '{{ object }}'"`    | Custom confirmation wording   |

All other blocks from `modal_form.html` remain available.

---

## `conjunto/lightbox.html`

A full-screen image lightbox built on top of `modal_form.html`.

```django
{% extends "conjunto/lightbox.html" %}
```

| Block          | Default                                          | When to override              |
|----------------|--------------------------------------------------|-------------------------------|
| `body`         | `<img class="card-img" src="{{ image_url }}">`   | Custom lightbox media         |
| `modal-footer` | **Emptied** — no footer rendered                 | Re-enable / replace footer    |

---

## `conjunto/generic_form.html`

Bare-bones full-page form template (extends the project's own
`base.html`, so it will also inherit from `conjunto/app_base.html` in a
normal Conjunto project, assuming the project's `base.html` extends
`conjunto/app_base.html`). Useful as a quick template for simple `FormView`
subclasses.

| Block     | Default                                     | When to override           |
|-----------|---------------------------------------------|----------------------------|
| `content` | Crispy-rendered form + submit button        | Custom form layout         |

---

## `conjunto/login.html`

The default login page (extends `conjunto/app_base.html`).

| Block                  | Default                                             | When to override               |
|------------------------|-----------------------------------------------------|--------------------------------|
| `content`              | Full Tabler login card (username, password, links)  | Replace the whole card         |
| `extra-form-content`   | *(empty)*                                           | Social login buttons, OAuth, … |

---

## `registration/login.html`

The login page rendered by Django's `auth` views / any `LoginView`
subclass. Extends `conjunto/app_base.html` and blanks out `top_bar`,
`sidebar` and `header` so the login card is centered on a chrome-free
page. Projects typically extend this template (or override individual
blocks) instead of shipping their own full login markup.

```django
{% extends "registration/login.html" %}
```

### Block tree

```
content
├── login_brand                 ← logo + project name, centered above the card
├── login_welcome               ← (empty) optional welcome line above the card
├── login_title                 ← h2 inside the card, defaults to "Login to your account"
├── login_form_top              ← (empty) slot inside <form>, above the fields
├── login_alternative_methods   ← renders all enabled ILoginMethod implementations
├── login_extensions            ← (empty) slot below the card (e.g. ILoginViewExtension hooks)
└── login_footer                ← (empty) slot at the very bottom (e.g. copyright line)
```

### Block reference table

| Block                        | Default                                                                                           | Typical override                                                   |
|------------------------------|---------------------------------------------------------------------------------------------------|--------------------------------------------------------------------|
| `login_brand`                | Centered `brand.svg` + `site.name` / `globals.project_title` fallback                             | Custom brand / hide logo                                           |
| `login_welcome`              | *(empty)*                                                                                         | Welcome headline (e.g. `{{ welcome_message }}` from the view)      |
| `login_title`                | `"Login to your account"`                                                                         | Custom card heading                                                |
| `login_form_top`             | *(empty)*                                                                                         | Extra fields / notices rendered inside `<form>` above the username |
| `login_alternative_methods`  | "Or sign in with" divider + buttons for every enabled `ILoginMethod`; empty when none registered  | Replace the provider button list / hide it                         |
| `login_extensions`           | *(empty)*                                                                                         | Plugin hooks (e.g. `ILoginViewExtension`), social login, OAuth     |
| `login_footer`               | *(empty)*                                                                                         | Copyright / legal line below the card                              |

!!! note "Form fields inside the login card"
    The shipped card also exposes a `remember_me` checkbox (HTML
    name `remember_me`). The default `LoginView` wires this to the
    `conjunto.session_lifetime_default` and
    `conjunto.session_lifetime_remembered` scoped settings; see
    [Settings](settings.md) for the concrete keys.

All `conjunto/app_base.html` blocks (`title`, `extra_css`, `scripts`, …)
remain available as usual.

---

## `conjunto/card_page.html`

A thin shell that extends `conjunto/app_base.html` without adding any
blocks of its own. It exists as a conventional starting point — all
overridable blocks come from `app_base.html`.

---

## Include templates (not extended, but overridable via blocks)

A few `includes/` templates expose blocks so that higher-level
templates can re-render parts of the page header when they are
included from elsewhere:

### `conjunto/includes/page_header.html`

| Block                 | Default                  | When to override             |
|-----------------------|--------------------------|------------------------------|
| `page_pretitle`       | `{{ page_pretitle }}`    | Custom pretitle markup       |
| `page_title`          | `{{ page_title }}`       | Custom title markup          |
| `page_title_actions`  | *(empty)*                | Buttons on the right         |

These are provided for cases where you render a page header outside
the normal `base.html` `page_header` block.

---

## Quick cheat-sheet

| You want to…                            | Override this block                          | In template                         |
|-----------------------------------------|----------------------------------------------|-------------------------------------|
| Set the page title                      | `page_title` (+ optional `page_pretitle`)    | `conjunto/app_base.html`            |
| Add buttons next to the page title      | `page_actions`                               | `conjunto/app_base.html`            |
| Add an icon button to the topbar        | `top_bar_actions`                            | `conjunto/app_base.html`            |
| Add a static right offcanvas panel      | `offcanvas_right`                            | `conjunto/app_base.html`            |
| Inject extra CSS on a single page       | `extra_css`                                  | `conjunto/app_base.html`            |
| Inject extra JS on a single page        | `scripts`                                    | `conjunto/app_base.html`            |
| Render a page with no chrome            | *(extend `layouts/empty.html`)*              | `conjunto/layouts/empty.html`       |
| Change a modal's title                  | `title`                                      | `conjunto/modal_form.html`          |
| Change a modal's submit button          | `submit-button`                              | `conjunto/modal_form.html`          |
| Hide a modal's footer                   | `modal-footer` (empty)                       | `conjunto/modal_form.html`          |
| Customise delete confirmation wording   | `content`                                    | `conjunto/modal_confirm_delete.html`|
