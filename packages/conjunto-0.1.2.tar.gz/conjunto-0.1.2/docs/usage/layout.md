# Layout & Template System

Conjunto ships with a mobile-first, Tabler.io–based layout that defines a fixed
topbar, a fixed left sidebar, a scrollable content canvas and a fixed status
bar at the bottom. The layout is mobile-first, fully responsive, and every
region can be customised through Django template blocks.

## Two-Tier Base Templates

Since 0.1.2, conjunto ships **two** base templates:

| Template                  | Use case                                                                  |
|---------------------------|---------------------------------------------------------------------------|
| `conjunto/base.html`      | Slim, generic document shell. No topbar, no sidebar, no canvas, no statusbar. Use this for public / marketing / chrome-less pages. Blocks: `title`, `meta`, `extra_css`, `body_attrs`, `body`, `modal`, `toasts`, `scripts`. |
| `conjunto/app_base.html`  | Full application layout (topbar + sidebar + canvas + statusbar + offcanvas). Extends `conjunto/base.html` and preserves all historical block names. **Extend this for regular in-app pages.**                            |

If you're upgrading from a version prior to 0.1.2, replace
`{% extends "conjunto/base.html" %}` with
`{% extends "conjunto/app_base.html" %}` in every template that relies on
the topbar / sidebar / `content` / `page_title` / ... blocks. All block
names are unchanged.

## Visual Structure

```
┌─────────────────────────────────────────────────────┐  ← #cj-topbar (fixed/sticky)
│ ☰  [Brand]   [menus.main]            [avatar ▼]     │
├──────────┬──────────────────────────────────────────┤
│          │                                          │
│ sidebar  │   .cj-page-content  (this is the         │
│ (fixed,  │                       only scroll area)  │
│ pushes   │   ┌──────────────────────────────────┐   │
│ content) │   │ {% block canvas %}               │   │
│          │   │   page_header                    │   │
│          │   │   messages                       │   │
│          │   │   content                        │   │
│          │   └──────────────────────────────────┘   │
├──────────┴──────────────────────────────────────────┤  ← #cj-statusbar (fixed bottom)
│ © 2026 Project              [menus.footer]          │
└─────────────────────────────────────────────────────┘
```

In addition, two Bootstrap offcanvas panels are available out of the box:

* `#cj-offcanvas-left` (slides in from the left)
* `#cj-offcanvas-right` (slides in from the right)

## Regions

| Region        | Behaviour                                                                                                                               | Block(s)                                                      |
|---------------|-----------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------|
| **Topbar**    | 100% width, always visible (mobile too). `fixed-top` or `sticky-top`, configurable.                                                     | `top_bar`, `top_bar_brand`, `top_bar_center`, `top_bar_actions`, `top_bar_right` |
| **Sidebar**   | Always `position: fixed`, between topbar and statusbar. Pushes content on desktop, overlays on mobile. **Never scrolls with the page.** | `sidebar`                                                     |
| **Canvas**    | The only scrollable area; sits to the right of the sidebar.                                                                             | `canvas`, `page_header`, `page_pretitle`, `page_title`, `page_actions`, `messages`, `content` |
| **Statusbar** | Always `position: fixed; bottom: 0`. Visible on every screen size.                                                                      | `footer` (the wrapper), `statusbar` (the inner content)       |
| **Offcanvas** | Hidden by default, opens via `data-bs-toggle="offcanvas"`.                                                                              | `offcanvas_left`, `offcanvas_right`                            |

## Template Block Reference

When you `{% extends "conjunto/app_base.html" %}` you can override any of these
blocks:

```
title                  ← <title> tag
meta                   ← extra <head> meta tags
extra_css              ← extra <link rel="stylesheet">

top_bar                ← entire topbar
  top_bar_brand        ← logo + project name
  top_bar_center       ← horizontal nav (menus.main)
  top_bar_actions      ← page-level buttons (e.g. offcanvas triggers)
  top_bar_right        ← theme toggle, user dropdown (menus.user)

sidebar                ← left sidebar (default: includes sidebar.html)

canvas                 ← entire scrollable content area
  page_header          ← header strip with title (left) + actions (right)
    page_pretitle
    page_title
    page_subtitle
    page_actions
  messages             ← Django flash messages
  content              ← your main content

offcanvas_left         ← static content for the left offcanvas
offcanvas_right        ← static content for the right offcanvas

footer                 ← entire statusbar wrapper
  statusbar            ← inner statusbar content (default shows copyright + menus.footer)

modal                  ← reserved slot for modal dialogs
toasts                 ← reserved slot for toast container
scripts                ← extra JS at end of body
```

## Menus

The default base template wires four menus from the `IMenuItem` system:

| Menu name        | Used in                           |
|------------------|-----------------------------------|
| `menus.main`     | Topbar horizontal navigation      |
| `menus.user`     | User avatar dropdown (top right)  |
| `menus.sidebar`  | Left sidebar (2 levels supported) |
| `menus.footer`   | Statusbar links (bottom right)    |

See [Menu System](menus.md) for how to declare items via `IMenuItem`.

### Sidebar specifics

The sidebar renders **two levels** of `IMenuItem`. Top-level items can declare
an `inline_action` — an icon button that appears on the right side of the row
and becomes fully visible on hover:

```python
from conjunto.menu import IMenuItem

class ProjectsMenuItem(IMenuItem):
    menu = "sidebar"
    title = _("Projects")
    slug = "projects"
    icon = "folder"
    url = reverse_lazy("projects:list")
    # Inline action button rendered to the right of the title
    inline_action = InlineAction(
        url=reverse_lazy("projects:create"),
        icon="plus",
        title=_("New project"),
    )
```

## Layout Configuration

The layout exposes three configuration values that follow a clear priority
chain — **anything later overrides anything earlier**:

```
Django settings.py  →  request.scoped_settings (DB)  →  view context (cj_layout)
```

You can configure defaults globally in `settings.py`, override them
per-user / per-tenant / per-device / per-group via the scoped settings
subsystem, or override them per view by setting `cj_layout` in the
template context.

### Available values

| Key             | Default   | Type   | Effect                                             |
|-----------------|-----------|--------|----------------------------------------------------|
| `style`         | `"fluid"` | str    | `"fluid"` = full width, `"boxed"` = `container-xl` |
| `topbar_fixed`  | `True`    | bool   | `True` = `fixed-top`, `False` = `sticky-top`       |
| `sidebar_width` | `"15rem"` | str    | Any CSS length value (`px`, `rem`, `vw`, …)        |
| `color_scheme`  | `"light"` | str    | `"light"` or `"dark"` — sets `data-bs-theme` on `<html>` server-side |

### 1. Defaults from `settings.py`

```python
# settings.py
CONJUNTO_LAYOUT = "fluid"          # "fluid" | "boxed"
CONJUNTO_TOPBAR_FIXED = True
CONJUNTO_SIDEBAR_WIDTH = "15rem"
```

### 2. Per-scope via `ScopedSetting`

Four scoped settings are pre-registered by conjunto:
`conjunto.layout_style`, `conjunto.topbar_fixed`,
`conjunto.sidebar_width`, and `conjunto.color_scheme`. Writing rows for
any of these keys at any scope (USER / DEVICE / GROUP / TENANT / VENDOR)
overrides the Django settings default for requests matching that scope:

```python
from conjunto.settings.scoped.models import Scope, ScopedSetting

# Force the boxed layout for a specific tenant:
ScopedSetting.objects.create(
    namespace="conjunto",
    key="layout_style",
    scope=Scope.TENANT,
    tenant=my_tenant,
    value="boxed",
)

# Let an individual user choose a wider sidebar:
ScopedSetting.objects.create(
    namespace="conjunto",
    key="sidebar_width",
    scope=Scope.USER,
    user=request.user,
    value="20rem",
)
```

The context processor reads these via
`request.scoped_settings.get("conjunto", "layout_style", default=...)`
on every request.

### 3. Per-view override

In any view you can drop a `cj_layout` dict into the template context and it
will win over both of the above:

```python
class WideEditorView(TemplateView):
    template_name = "myapp/editor.html"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["cj_layout"] = {
            "style": "fluid",
            "topbar_fixed": False,   # let the topbar scroll out of view
            "sidebar_width": "12rem",
        }
        return ctx
```

The CSS variable `--cj-sidebar-width` is set inline on `<body>`, so changing
`sidebar_width` does **not** require recompiling any CSS.

## Sidebar Toggle

A single hamburger button (`#cj-sidebar-toggle`) is rendered in the topbar on
every screen size. Its behaviour adapts to viewport width:

* **Desktop (≥ 992 px)** — toggles `body.cj-sidebar-collapsed`. The sidebar
  slides off-screen and the content reclaims the freed space. The collapsed
  state is persisted in `localStorage` (`cj-sidebar-collapsed`).
* **Mobile (< 992 px)** — toggles `body.cj-sidebar-open`. The sidebar slides
  in as an overlay (with backdrop) and does **not** push the content. Clicking
  the backdrop closes it.

If you need to trigger the sidebar from somewhere else, just call
`cjToggleSidebar()` from JavaScript.

## Dark Mode (Color Scheme)

The theme toggle button in the topbar switches between light and dark mode.
The color scheme is persisted server-side as the `conjunto.color_scheme`
scoped setting, so the correct `data-bs-theme` attribute is rendered on the
`<html>` tag during the initial page load. This eliminates the flash of
wrong theme that occurs when the theme is only stored in `localStorage`.

When the user clicks the toggle:

1. JavaScript immediately applies the new theme via `data-bs-theme` (instant UI feedback).
2. `localStorage` is updated as a fallback.
3. A `POST` request is sent to `/color-scheme/` which persists the preference as a USER-scoped setting (or DEVICE-scoped for anonymous users).

On the next full page load the server renders the `<html>` tag with the
correct `data-bs-theme` attribute, so the browser never shows the wrong
theme.

A VENDOR or TENANT administrator can lock the color scheme to enforce a
specific theme across the organization.

## Offcanvas Panels

Two empty offcanvas panels are always present in the DOM:

```html
<div class="offcanvas offcanvas-start" id="cj-offcanvas-left">…</div>
<div class="offcanvas offcanvas-end"   id="cj-offcanvas-right">…</div>
```

You have two ways to use them:

### Static content

Override the block in any child template:

```django
{% block offcanvas_right %}
  <h6>Filter</h6>
  <form method="get">…</form>
{% endblock %}
```

### Dynamic content (HTMX)

Add a trigger button to the topbar via the `top_bar_actions` block. The
button can both load fresh content into the panel and open it in one click:

```django
{% block top_bar_actions %}
  <button class="btn btn-ghost-secondary btn-icon"
          data-bs-toggle="offcanvas"
          data-bs-target="#cj-offcanvas-right"
          hx-get="{% url 'projects:filter_panel' %}"
          hx-target="#cj-offcanvas-right .offcanvas-body"
          title="{% trans 'Filter' %}">
    <i class="ti ti-filter"></i>
  </button>
{% endblock %}
```

The `top_bar_actions` block is the recommended place for any page-specific
icon buttons that should live in the topbar.

## CSS Variables & Custom Theming

The layout exposes a small set of CSS variables you can override in your own
stylesheet (or inline on `<body>`):

```css
:root {
    --cj-navbar-height:    3.5rem;
    --cj-statusbar-height: 2.5rem;
    --cj-sidebar-width:    15rem;
    --cj-sidebar-bg:       var(--tblr-bg-surface, #fff);
    --cj-sidebar-border:   var(--tblr-border-color, rgba(0,0,0,.08));
}
```

The most common overrides (`--cj-sidebar-width`) are already set for you
inline from `cj_layout`, so you usually don't need to touch them unless you
want to change navbar/statusbar heights.

### Body classes

| Class                    | Meaning                                              |
|--------------------------|------------------------------------------------------|
| `cj-sidebar-collapsed`   | Desktop: sidebar pushed off, content full width      |
| `cj-sidebar-open`        | Mobile: sidebar overlay visible, backdrop active     |

You can target these in your own CSS to react to sidebar state.

## Minimal Example

```django
{% extends "conjunto/app_base.html" %}
{% load i18n %}

{% block title %}{% trans "Dashboard" %}{% endblock %}

{% block page_pretitle %}{% trans "Overview" %}{% endblock %}
{% block page_title %}{% trans "Dashboard" %}{% endblock %}

{% block page_actions %}
  <a href="{% url 'projects:create' %}" class="btn btn-primary">
    <i class="ti ti-plus me-1"></i>{% trans "New project" %}
  </a>
{% endblock %}

{% block top_bar_actions %}
  <button class="btn btn-ghost-secondary btn-icon"
          data-bs-toggle="offcanvas" data-bs-target="#cj-offcanvas-right">
    <i class="ti ti-filter"></i>
  </button>
{% endblock %}

{% block offcanvas_right %}
  <h6>{% trans "Filter" %}</h6>
  {# … filter form … #}
{% endblock %}

{% block content %}
  <div class="row row-cards">
    {# … cards … #}
  </div>
{% endblock %}
```
