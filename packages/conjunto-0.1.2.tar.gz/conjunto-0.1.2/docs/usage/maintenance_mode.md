# Maintenance mode

Conjunto ships a maintenance-mode flow wired into `ConjuntoMiddleware`
and gated on the **`conjunto.maintenance_mode`** VENDOR-scoped
setting. The key is pre-registered for you — consumers just need to
write a row.

## Enabling it

**Via the Django admin:**

1. Open `Scoped settings` → `Add scoped setting`.
2. Set `namespace = "conjunto"`, `key = "maintenance_mode"`,
   `scope = Vendor`, `value = true`, leave all FKs blank.
3. Save.

**Programmatically:**

```python
from conjunto.settings.scoped.models import Scope, ScopedSetting

ScopedSetting.objects.update_or_create(
    namespace="conjunto",
    key="maintenance_mode",
    scope=Scope.VENDOR,
    defaults={"value": True},
)
```

When the flag is truthy:

- Non-staff users are redirected to `/maintenance/` (the built-in
  `MaintenanceView`, which renders `maintenance.html`). Provide your
  own `maintenance.html` in your project's templates.
- Staff users (`user.is_staff == True`) bypass the redirect so they
  can reach the admin to toggle the flag back off.
- The login page and the maintenance page itself are always reachable.
- `MEDIA_URL`-prefixed paths are passed through (unless `MEDIA_URL` is
  `"/"` or empty, in which case the exception is skipped to avoid
  matching every request).

## Locking the flag (admin-only override)

Because `conjunto.maintenance_mode` is registered with
`lockable_scopes=[Scope.VENDOR]`, you can set `locked=True` on the
VENDOR row. This has no practical effect for `maintenance_mode` since
it's already a VENDOR-only key — but the mechanism is there if your
own app adds additional keys that should be "pinnable" from above.

## Checking it from a view or template

**View:**

```python
def my_view(request):
    if request.scoped_settings.get("conjunto", "maintenance_mode"):
        ...
```

**Template:**

```django
{% if request.scoped_settings.conjunto.maintenance_mode %}
  <div class="banner banner-warning">Site is in maintenance mode.</div>
{% endif %}
```

The strict `.get()` call works out of the box because
`conjunto.scoped_settings` pre-registers the key.

## Migrating from the old `AbstractSettings.maintenance_mode` field

Old code:

```python
class MyAppSettings(AbstractSettings):
    maintenance_mode = models.BooleanField(default=False)

# ...
if request.app_settings.maintenance_mode:
    ...
```

New code: drop the model field and the subclass — the key is already
registered by conjunto. One-time data migration to move the existing
boolean into a `ScopedSetting` row at VENDOR scope:

```python
# one-off migration script
from conjunto.settings.scoped.models import Scope, ScopedSetting
from my_app.models import MyAppSettings  # old model

for old in MyAppSettings.objects.filter(maintenance_mode=True):
    ScopedSetting.objects.update_or_create(
        namespace="conjunto",
        key="maintenance_mode",
        scope=Scope.VENDOR,
        site=old.site,
        defaults={"value": True},
    )
```
