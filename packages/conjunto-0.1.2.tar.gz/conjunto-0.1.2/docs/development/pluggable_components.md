# Pluggable Tetra Components

Conjunto allows you to use [Tetra](https://www.tetraframework.com/) components as dynamically discovered [GDAPS](https://github.com/scaphilo/gdaps) plugins. This enables the creation of "shell" components that can render a list of children components defined as implementations of a specific GDAPS Interface.

## Core Interfaces

### `IComponent`

`IComponent` is the base GDAPS interface for all components that can be used as plugins. It provides an `is_component` property that returns `True` if the implementation is a Tetra component (i.e., it has a `_template` attribute).

```python
from conjunto.api.interfaces import IComponent
from gdaps.api import Interface

class IMyComponent(IComponent, Interface):
    pass
```

### `IElement`

`IElement` (which inherits from `IComponent`) is a more specialized interface for elements that have a name, title, icon, weight, and belong to a group. This is commonly used for things like settings sections, menu items, or dashboard widgets.

Attributes of `IElement`:
- `name`: Unique identifier (slug).
- `title`: Translatable display name.
- `icon`: Bootstrap icon name.
- `weight`: Sorting weight.
- `group`: An `IElementGroup` implementation.

## Usage Example

To create a pluggable component system:

### 1. Define the Interface

Define a GDAPS interface that inherits from `IComponent` (or `IElement`).

```python
# interfaces.py
from conjunto.api.interfaces import IComponent
from gdaps.api import Interface

class IDashboardWidget(IComponent, Interface):
    """Plugins implementing this interface will be shown on the dashboard."""
    pass
```

### 2. Implement the Component

Create one or more Tetra components that implement your interface.

```python
# components.py
from tetra import BasicComponent
from .interfaces import IDashboardWidget

class WelcomeWidget(BasicComponent, IDashboardWidget):
    name = "welcome_widget"
    template_name = "my_app/welcome_widget.html"
```

### 3. Render the Plugins

In your "shell" component or template, you can now discover and render these components.

```django
{# dashboard.html #}
{% for widget in IDashboardWidget.plugins %}
    {% if widget.is_component %}
        {% component =widget key=widget.name /%}
    {% endif %}
{% endfor %}
```

## Advanced: Shell Components with Subsections

You can create complex structures where a shell component renders "Sections", and each section dynamically renders "Subsections" implemented as components.

See the [Settings implementation](../usage/settings.md#dynamic-settings-sections) for a real-world example.
