from django.db import models

from conjunto.models import HistoryVersionedModel, SingletonModel
from conjunto.tenants.models import OptionalTenantModelMixin, TenantModelMixin


class SingletonTestModel(SingletonModel):
    app_label = "test_app"


class Person(models.Model):
    name = models.CharField(max_length=40)


class HistoryVersionedTestModel(HistoryVersionedModel):
    app_label = "test_app"
    title = models.CharField(max_length=255)
    content = models.TextField(blank=True)


class TenantDoc(TenantModelMixin):
    title = models.CharField(max_length=100)

    class Meta(TenantModelMixin.Meta):
        app_label = "test_app"


class OptionalTenantDoc(OptionalTenantModelMixin):
    title = models.CharField(max_length=100)

    class Meta(OptionalTenantModelMixin.Meta):
        app_label = "test_app"
