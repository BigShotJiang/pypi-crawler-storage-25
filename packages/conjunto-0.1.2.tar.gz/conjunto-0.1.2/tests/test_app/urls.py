"""Test project root URL conf.

Includes ``conjunto.settings.urls`` and the core ``conjunto.urls``
(for the ``maintenance`` URL name required by
``ConjuntoMiddleware._maintenance_redirect``). In real projects you
would let ``PluginManager.urlpatterns()`` auto-mount GDAPS plugin URLs,
but in the test harness we wire them directly to keep the test setup
self-contained.
"""

from django.http import HttpResponse
from django.urls import include, path

urlpatterns = [
    path("settings/", include("conjunto.settings.urls")),
    path("tenants/", include("conjunto.tenants.urls")),
    path("accounts/logout/", lambda r: HttpResponse(""), name="logout"),
    path("", include("conjunto.urls")),
]
