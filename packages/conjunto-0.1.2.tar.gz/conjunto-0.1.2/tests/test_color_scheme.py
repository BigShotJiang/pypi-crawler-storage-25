"""Tests for the server-side color scheme persistence feature.

The ``conjunto.color_scheme`` scoped setting eliminates the flash of
wrong theme on full-page loads by letting the server render the correct
``data-bs-theme`` attribute on the ``<html>`` tag.

Covers:
- ``SaveColorSchemeView`` accepts valid color schemes and rejects invalid ones.
- Authenticated users get a USER-scoped setting.
- Anonymous users get a DEVICE-scoped setting.
- The ``cj_layout`` context processor exposes the resolved color scheme.
"""

import json

import pytest
from django.contrib.auth import get_user_model
from django.contrib.auth.models import AnonymousUser
from django.test import RequestFactory

from conjunto.context_processors import globals as globals_cp
from conjunto.middleware import ConjuntoMiddleware
from conjunto.settings.scoped.models import Scope, ScopedSetting


pytestmark = pytest.mark.django_db

User = get_user_model()


def _noop(request):
    from django.http import HttpResponse

    return HttpResponse("ok")


@pytest.fixture
def rf():
    return RequestFactory()


def _make_request(rf, user=None, path="/color-scheme/", body=None):
    """Build a POST request and run it through ConjuntoMiddleware to
    populate ``request.device`` and ``request.scoped_settings``."""
    request = rf.post(
        path,
        data=json.dumps(body or {}),
        content_type="application/json",
    )
    request.user = user or AnonymousUser()
    # Run through middleware to populate device + scoped_settings
    ConjuntoMiddleware(_noop)(request)
    return request


# ── SaveColorSchemeView ──────────────────────────────────────────────


class TestSaveColorSchemeView:
    def test_valid_dark(self, rf, db):
        user = User.objects.create_user(username="alice", password="x")
        request = _make_request(rf, user=user, body={"color_scheme": "dark"})

        from conjunto.views import SaveColorSchemeView

        view = SaveColorSchemeView()
        response = view.post(request)
        assert response.status_code == 200
        data = json.loads(response.content)
        assert data["ok"] is True

        setting = ScopedSetting.objects.get(
            namespace="conjunto", key="color_scheme", scope=Scope.USER, user=user
        )
        assert setting.value == "dark"

    def test_valid_light(self, rf, db):
        user = User.objects.create_user(username="bob", password="x")
        request = _make_request(rf, user=user, body={"color_scheme": "light"})

        from conjunto.views import SaveColorSchemeView

        view = SaveColorSchemeView()
        response = view.post(request)
        assert response.status_code == 200

        setting = ScopedSetting.objects.get(
            namespace="conjunto", key="color_scheme", scope=Scope.USER, user=user
        )
        assert setting.value == "light"

    def test_invalid_scheme_rejected(self, rf, db):
        user = User.objects.create_user(username="eve", password="x")
        request = _make_request(rf, user=user, body={"color_scheme": "blue"})

        from conjunto.views import SaveColorSchemeView

        view = SaveColorSchemeView()
        response = view.post(request)
        assert response.status_code == 400

    def test_invalid_json_rejected(self, rf, db):
        request = rf.post(
            "/color-scheme/",
            data="not json",
            content_type="application/json",
        )
        request.user = AnonymousUser()
        ConjuntoMiddleware(_noop)(request)

        from conjunto.views import SaveColorSchemeView

        view = SaveColorSchemeView()
        response = view.post(request)
        assert response.status_code == 400

    def test_anonymous_saves_device_scoped(self, rf, db):
        request = _make_request(rf, body={"color_scheme": "dark"})

        from conjunto.views import SaveColorSchemeView

        view = SaveColorSchemeView()
        response = view.post(request)
        assert response.status_code == 200

        assert ScopedSetting.objects.filter(
            namespace="conjunto",
            key="color_scheme",
            scope=Scope.DEVICE,
        ).exists()

    def test_update_overwrites_previous(self, rf, db):
        user = User.objects.create_user(username="carol", password="x")

        # First: set to dark
        request = _make_request(rf, user=user, body={"color_scheme": "dark"})
        from conjunto.views import SaveColorSchemeView

        SaveColorSchemeView().post(request)

        # Second: set to light
        request = _make_request(rf, user=user, body={"color_scheme": "light"})
        SaveColorSchemeView().post(request)

        settings = ScopedSetting.objects.filter(
            namespace="conjunto", key="color_scheme", scope=Scope.USER, user=user
        )
        assert settings.count() == 1
        assert settings.first().value == "light"


# ── Context processor ────────────────────────────────────────────────


class TestColorSchemeContextProcessor:
    def test_default_is_light(self, rf, db):
        request = rf.get("/")
        request.user = AnonymousUser()
        ConjuntoMiddleware(_noop)(request)

        ctx = globals_cp(request)
        assert ctx["cj_layout"]["color_scheme"] == "light"

    def test_resolves_user_setting(self, rf, db):
        user = User.objects.create_user(username="dan", password="x")
        ScopedSetting.objects.create(
            namespace="conjunto",
            key="color_scheme",
            scope=Scope.USER,
            user=user,
            value="dark",
        )

        request = rf.get("/")
        request.user = user
        ConjuntoMiddleware(_noop)(request)

        ctx = globals_cp(request)
        assert ctx["cj_layout"]["color_scheme"] == "dark"
