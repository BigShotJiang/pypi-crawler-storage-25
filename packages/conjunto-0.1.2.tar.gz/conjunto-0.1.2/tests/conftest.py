import django
import pytest
from pathlib import Path


def pytest_configure(config):
    from django.conf import settings

    if settings.configured:
        return

    BASE_DIR = Path(__file__).resolve().parent

    settings.configure(
        SECRET_KEY="test",
        BASE_DIR=BASE_DIR,
        DATABASES={
            "default": {"ENGINE": "django.db.backends.sqlite3", "NAME": ":memory:"}
        },
        INSTALLED_APPS=[
            "django.contrib.admin",
            "django.contrib.auth",
            "django.contrib.contenttypes",
            "django.contrib.messages",
            "django.contrib.sessions",
            "django.contrib.sites",
            "gdaps",
            "conjunto",
            "conjunto.tenants",
            "conjunto.settings",
            "crispy_forms",
            "crispy_bootstrap5",
            "django_htmx",
            "statici18n",
            "tests.test_app",
        ],
        MIDDLEWARE=[
            "django.contrib.sessions.middleware.SessionMiddleware",
            "django.contrib.auth.middleware.AuthenticationMiddleware",
            "django.contrib.messages.middleware.MessageMiddleware",
            "django_htmx.middleware.HtmxMiddleware",
            "conjunto.middleware.ConjuntoMessagesMiddleware",
        ],
        ROOT_URLCONF="tests.test_app.urls",
        LOGIN_URL="/accounts/login/",
        CONJUNTO_TENANT_MODEL="conjunto_tenants.Tenant",
        CRISPY_TEMPLATE_PACK="bootstrap5",
        CRISPY_ALLOWED_TEMPLATE_PACKS="bootstrap5",
        PLUGIN1={"OVERRIDE": 20},
        PROJECT_NAME="conjunto",
        PROJECT_TITLE="Foo Bar",
        TEMPLATES=[
            {
                "BACKEND": "django.template.backends.django.DjangoTemplates",
                "DIRS": [BASE_DIR / "templates"],
                "APP_DIRS": True,
                "OPTIONS": {
                    "context_processors": [
                        "django.template.context_processors.request",
                        "django.contrib.auth.context_processors.auth",
                        "django.contrib.messages.context_processors.messages",
                        "conjunto.context_processors.globals",
                    ],
                },
            },
        ],
    )

    django.setup()


@pytest.fixture
def terms_conditions_page(db):
    """Make sure that one TermsAndConditionsPage exists."""
    from conjunto.cms.models import TermsConditionsPage

    return TermsConditionsPage.objects.create(
        title="Terms and Conditions",
        body="Terms and conditions content",
        version=1,
    )
