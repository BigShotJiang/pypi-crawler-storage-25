# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.2] - unreleased
### Added
- New slim, generic `conjunto/base.html` — document shell only (`<!doctype>`, `<html>`, `<head>`, `<body>` with CSRF + `body`, `modal`, `toasts`, `scripts` blocks). Use it as starting point for public / marketing / chrome-less pages. Exposed blocks: `title`, `meta`, `extra_css`, `body_attrs`, `body`, `modal`, `toasts`, `scripts`.
- New `conjunto/app_base.html` carrying the full application layout (topbar + sidebar + scrollable canvas + statusbar + two offcanvas panels). Extends `conjunto/base.html`. All historical block names (`top_bar`, `top_bar_brand`, `top_bar_center`, `top_bar_actions`, `top_bar_right`, `sidebar_toggle`, `sidebar`, `canvas`, `page_header`, `page_pretitle`, `page_pretitle_wrapper`, `page_title`, `page_subtitle`, `page_actions`, `messages`, `content`, `footer`, `statusbar`, `offcanvas_left`, `offcanvas_right`) are preserved here unchanged.

### Changed
- **BREAKING**: `conjunto/base.html` is now a slim, generic template without topbar, sidebar, canvas or statusbar. Projects that previously extended `conjunto/base.html` to get the app layout (topbar, sidebar, `content`, `page_title`, …) must migrate to `conjunto/app_base.html`.

  Migration:

  ```diff
  - {% extends "conjunto/base.html" %}
  + {% extends "conjunto/app_base.html" %}
  ```

  All block names are unchanged, so a one-line change per template is usually sufficient. Shipped conjunto templates that depend on the app layout (`conjunto/layouts/empty.html`, `conjunto/card_page.html`, `conjunto/login.html`, `registration/login.html`, `conjunto/settings/page.html`, tenants admin views) have already been migrated internally.

### Added (previously logged for 0.1.2)
- `CONJUNTO_TENANT_MODEL` is now **optional**. When unset, conjunto installs the default `"conjunto_tenants.Tenant"` at package import time (before Django loads the tenants models), mirroring Django's `AUTH_USER_MODEL` semantics while removing boilerplate for consumer projects that don't swap the tenant model.
- Server-side dark mode persistence via `conjunto.color_scheme` scoped setting (USER/DEVICE scope), eliminating flash of wrong theme on full page loads
- New granular template block `sidebar_toggle` in `conjunto/base.html` wrapping the `#cj-sidebar-toggle` hamburger button, so child templates can hide or replace it without overriding the whole topbar
- New override hooks in `registration/login.html`: `login_brand`, `login_welcome`, `login_title`, `login_form_top`, `login_extensions` and `login_footer`, so project templates can extend the shipped login page instead of duplicating its markup
- New `ILoginMethod` GDAPS interface for contributing alternative sign-in entry points (social, SSO, WebAuthn, …) to the login page, rendered into the new `login_alternative_methods` block via the `{% login_methods %}` template tag
- `remember_me` checkbox in the shipped login card; consuming `LoginView`s wire it to `request.session.set_expiry(...)`
- New scoped settings `conjunto.session_lifetime_default` and `conjunto.session_lifetime_remembered` (VENDOR/TENANT scope) driving the post-login session lifetime. Defaults: `0` (browser session) and `2592000` (30 days), overridable via `CONJUNTO_SESSION_LIFETIME_DEFAULT` / `CONJUNTO_SESSION_LIFETIME_REMEMBERED`. Projects with a custom `LoginView` must wire `remember_me` to these two keys until conjunto ships its own base `LoginView`.

### Changed (previously logged for 0.1.2)
- Rename scope classes to use `I` prefix: `IVendorScope`, `ITenantScope`, `IGroupScope`, `IDeviceScope`, `IUserScope`
- Simplify tenant handling, rename admin role to `tenant_admin`
- Replace tenant picker with inline dropdown for tenant switching
- Bump gdaps dependency to >=0.13.0
- `registration/login.html` now blanks out the entire `top_bar` block and renders brand/logo centered above the login card, reusing the same `site.name|default:globals.project_title` + `brand.svg` pattern as `top_bar_brand`

### Fixed
- Fix `test_all_five_scopes_are_registered` for abstract `IScope` interface
- `registration/login.html`: guard the "I forgot password" link with `{% url 'password_reset' as … %}` + `{% if %}` so the template no longer breaks downstream projects that don't register a `password_reset` URL name

## [0.1.1] - 2026-04-13
### Changed
- Bump gdaps dependency to >=0.13.0
- Simplify tenant handling and rename admin role to `tenant_admin`
- Replace tenant picker with inline dropdown
- Update README to replace Tetra with HTMX in framework description

## [0.1.0] - 2026-04-13

**Major release: Complete removal of Tetra, migration to HTMX.**

### Added
- Complete HTMX-based layout system with fixed topbar, resizable sidebar, two offcanvas panels, and statusbar
- Scoped settings system (`USER > DEVICE > GROUP > TENANT > VENDOR` priority chain) replacing `AbstractSettings`
- Toast notification system based on Django's `messages` framework + HTMX
- `HtmxFormViewMixin` for in-place partial swaps (not just modals)
- `CrudTableMixin` and `RowAction` system for tables with pluggable row actions via `IRowAction` GDAPS interface
- Tenant system: `TenantModelMixin`, `OptionalTenantModelMixin`, tenant picker, `TenantRequiredMixin`
- Per-tenant role system with tenant-aware auth backend
- Settings page UI with `ISettingsGroup` / `ISettingsSection` / `ISettingsForm` plugin architecture
- Configurable toast container positioning
- `page_subtitle` block in base template
- Resizable sidebar with persistent width (localStorage)
- GitLab CI pipeline for automated testing and PyPI publishing

### Changed
- **BREAKING**: Removed Tetra dependency entirely — all UI is now HTMX-based
- **BREAKING**: Replaced `AbstractSettings` with scoped settings (`request.scoped_settings.get()`)
- **BREAKING**: Removed toasts component, migrated to Django `messages` framework + HTMX
- Complete redesign of layout system (topbar, sidebar, offcanvas, page/canvas, footer)
- Updated Django dependency to >=6.0.3
- Rewrote modal logic and form handling for HTMX
- Migrated all JS libraries to current versions
- Removed `suitable_django_autocomplete` integration

### Fixed
- Modal form override now replaces form instead of appending
- Type hint formatting in settings `section` attribute

## [0.0.26] - 2026-03-15
### Added
- `LogActionResult` enum and integrated `result` field into log actions and `ModelLogEntry`
- `show_actions` management command
- `register_log_actions` hook for audit logging
- Annotations for improved code clarity

### Changed
- Bumped Django and `gdaps` dependencies
- Updated to Tetra 0.4 API
- Use Tetra slots instead of blocks in components
- Refactored `Card` component to use `_pre_load`
- Improved tests for models and logging

### Fixed
- SPDX license attribute in `pyproject.toml`
- Buffer length access in `ProtectedFileSystemStorage`
- `Toasts` component to use external JS
- `Updatable` component now saves trigger event

## [0.0.25] - 2025-12-19
### Added
- Test configuration and pytest setup in conftest.py
- Django test app configuration for testing purposes
- Template directory configuration in test settings
- Support for GDAPS and Conjunto apps in test environment

### Changed
- Updated project configuration structure for better testing support
- Improved test database configuration to use in-memory SQLite

### Fixed
- Django setup and configuration for test suite
- Plugin configuration handling in tests

## [0.0.24] - 2025-08-08
### Added
- Audit log functionality
- `Updatable` component saves trigger event
- `show_actions` management command
- `register_log_actions` hook

### Changed
- Updated to Tetra 0.4 API
- Use Tetra slots instead of blocks in components

### Fixed
- Component template compilation issues
- Toast component JavaScript loading

## [0.0.23] - 2025-07-27
- ...

## [0.0.22] - 2024-04-19
- documentation++
- get rid of separate `tabler` app

## [0.0.21] - 2024-03-21
- use gettext_lazy for model translations
- rename conjunto migration 0003 to proper name

## [0.0.20] - 2024-03-21
### Fixed
- add missing data files

## [0.0.19] - 2024-03-21
- switch build tool from flit to setuptools
- gitignore mo files
- add menu check for anonymous

## [0.0.18] - 2024-03-13
### Added
- Token helper views
- variable icon font sizes in button components

## [0.0.17] - 2024-03-08
- update HtmxLinkElement

## [0.0.16] - 2024-03-05
- add HTMX lightbox
- disable modal form button when posting
- enable htmx spinner
- rebase HtmxSetModelAttributeView on SuccessEventMixin

## [0.0.15] - 2023-02-29
- add datagrid-item component
- improve "static" page views

## [0.0.14] - 2023-02-28
- fix issues with tabler https://github.com/tabler/tabler/issues/1836
- breaking: rename required_permissions attribute to permission_required in IMenuItems
- improve link functionality

## [0.0.13] - 2023-02-27
### Added
- let listitem component accept subtitle slot additionally to attribute
- allow autocomplete and custom form attrs in ModalFormViews
- provide function to generate secure passwords
- add helper functions for menus: is_staff, is_authenticated
### Changed
- breaking change of HTMX mixin names to better explain their purpose
- rename "Site Editor" permissions group to "Content Editor"

## [0.0.12] - 2023-02-23
### Added
- protected media files download support

## [0.0.11] - 2023-02-21
- improve updatable component

## [0.0.10] - 2023-02-19
### Added
- another fixes for HTMX form handling and redirects

## [0.0.9] - 2023-02-19
### Added
- allow auto img tags in datagrids
- fixes for HTMX form handling and redirects

## [0.0.8]
- fix error with LicensePage

## [0.0.7]
- fix PRODUCTION env variable for red background bar

## [0.0.6]
- mark testing sites with read header bar
- rename GDAPS based "component" to "element" to avoid name clashes with django-web-components
- massively improve element rendering
- begin adding some tabler components: list, (action)buttons, etc.
- migrate some more helper classes from medux-common

## [0.0.5] 2023-12-23
- update translations
- move CMS functionality in own subapp `conjunto.cms`

## [0.0.4] 2023-12-23
### Fixed
- maintenance mode

### Changed
- rename maintenance_text to maintenance_content

## [0.0.3]
### Added
- documentation at readthedocs
- many small bugfixes

## [0.0.2]
### Added
- move many common used classes + helpers from medux-common to Conjunto
- Makefile for common tasks

## [0.0.1]
- initial version

