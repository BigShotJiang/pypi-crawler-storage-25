# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Conjunto is a Django application framework for building component-based, plugin-extendable applications. It combines:
- **Tetra** - Component-based UI framework
- **GDAPS** - Plugin architecture via interfaces and hooks
- **Tabler.io** - UI components (modals, toasts, cards, accordions)
- **django-tables2 / crispy-forms** - Tables and forms

## Development Commands

```bash
# Install dependencies (uses uv)
uv sync

# Run all tests
uv run pytest

# Run specific test file
uv run pytest tests/test_log_action.py

# Run specific test
uv run pytest tests/test_log_action.py::TestAuditLog::test_log_action_basic

# Build package
uv build

# Format code
uv run black .
```

## Architecture

### GDAPS Plugin System

The codebase uses GDAPS (Generic Django App Plugin System) for extensibility:

- **Interfaces** are defined in `src/conjunto/api/interfaces/` - e.g., `IComponent`, `IElement`, `IMenuItem`, and in plugin packages (e.g. `ISettingsGroup/Section/Form` in `src/conjunto/settings/interfaces.py`)
- **Hooks** use `gdaps.hooks` - e.g., `register_log_actions` hook in `gdaps_hooks.py`
- Plugins implementing interfaces are auto-discovered by GDAPS

When combining Tetra components with GDAPS interfaces, use `CombinedComponentMeta` metaclass.

### Key Directories

| Path | Purpose |
|------|---------|
| `src/conjunto/components/` | Tetra UI components (Modal, Toast, Card, Accordion, etc.) |
| `src/conjunto/audit_log/` | Model audit logging with `ModelLogEntry`, `LogActionRegistry`, `log_action()` |
| `src/conjunto/menu/` | Permission-aware menu system via `IMenuItem` interface |
| `src/conjunto/tenants/` | Swappable `AbstractTenant` + concrete `Tenant` (via `CONJUNTO_TENANT_MODEL`) |
| `src/conjunto/settings/` | GitHub-style settings page (UI plugins) + `ScopedSetting` data layer (five scopes, per-request proxy) |
| `src/conjunto/settings/scoped/` | Scoped settings core: models, IScope, registry, resolver, proxy |
| `src/conjunto/api/interfaces/` | GDPS interface definitions |
| `src/conjunto/cms/` | CMS models (StaticPage, VersionedPage) |
| `src/conjunto/tables.py` | `RowAction` + `CrudTableMixin` + `IRowAction` (row-action table layer) |
| `src/conjunto/templates/conjunto/` | `base.html` + sidebar/footer/offcanvas includes (the layout system) |
| `src/conjunto/static/conjunto/css/conjunto.css` | Layout CSS (fixed topbar/sidebar/statusbar) |
| `tests/` | Test suite with test app in `tests/test_app/` |

### Audit Logging

The audit log system requires actions to be registered via the `register_log_actions` hook before use:
```python
from conjunto.audit_log import LogActionRegistry, log_action

# Actions must be registered first
LogActionRegistry.register("user.login", "User logged in")

# Then log actions
log_action("user.login", request, user=user)
```

### Menu System

Menu items are GDAPS plugins implementing `IMenuItem`. Key concepts:

**Hierarchical Structure:**
- Use `parent` attribute to create nested menus (supports unlimited depth)
- `parent` can be a slug string (e.g., `parent = "settings"`) or preferably a class reference (e.g., `parent = SettingsMenuItem`)
- Items without `parent` are top-level

**Instantiation:**
- Menu items are instantiated per-request with `IMenuItem(request=request)`
- Access request context via `self._request` or `self.request` property

**Visibility:**
- Control via `permissions_required` list (e.g., `permissions_required = ["auth.add_user"]`)
- Override `_is_visible()` method for custom logic
- Visibility checked via `item.visible` property

**Dynamic Attributes:**
- Override `get_title()`, `get_icon()`, `get_disabled()` for dynamic values
- Use `get_slug()` method (not property) for slug access
- Static attributes: `title`, `icon`, `slug`, `disabled`

**Example:**
```python
class UsersMenuItem(IMenuItem):
    menu = "main"
    title = "Users"
    slug = "users"
    icon = "users"
    permissions_required = ["auth.view_user"]

class UserListItem(IMenuItem):
    menu = "main"
    title = "User List"
    parent = "users"  # or parent = UsersMenuItem
    url = "/users/"
```

### Settings System (Scoped Settings)

The `conjunto.settings` package hosts **two layers**:

1. **`ScopedSetting` data layer** (`conjunto.settings.scoped.*`) — a
   scope-based overlay store where every setting is resolved through
   the priority chain `USER > DEVICE > GROUP > TENANT > VENDOR`. Each
   row has an optional `locked` flag that acts as a "floor" no higher
   scope can dig under; multiple locks are resolved by lowest
   priority (a VENDOR lock is ultimate authority).

2. **Settings page UI** (`conjunto.settings.menus`, `views`,
   `templates`) — the GitHub-style `/settings/` page driven by the
   `ISettingsGroup` / `ISettingsSection` / `ISettingsForm` GDAPS
   plugins. Operators edit scope-specific rows through the Django
   admin for now; the per-scope-tabbed UI is a follow-up.

The old `AbstractSettings` model, `request.app_settings`, and
`SETTINGS_MODEL` are gone. Consumers of conjunto ≥ this version use
`request.scoped_settings.get("namespace", "key")` via the proxy.

> **Import note.** Inside files in `conjunto/settings/` that need Django's
> own settings object, use `from django.conf import settings as django_settings`
> to avoid shadowing. `conjunto.settings` (the package) and
> `django.conf.settings` (a module attribute) don't collide at import
> level, but they do collide if bound to the same local name in one file.

#### Scoped settings data layer

- **Key model**: `conjunto.settings.scoped.models.ScopedSetting`.
  Fields: `namespace`, `key`, `scope`, four per-scope FKs
  (`user/group/device/tenant`), orthogonal `site` filter, `value`
  JSONField, `locked` bool, audit timestamps. CheckConstraint enforces
  exactly one FK non-null per scope; partial UniqueConstraints per
  scope use `Coalesce(site_id, 0)` to collapse NULL-site duplicates.
- **Device model**: `conjunto.settings.scoped.models.Device`. Anchor
  for DEVICE-scoped rows. Identified by a 10-year `cj_device_id`
  cookie set by `ConjuntoMiddleware`. Bound to a user on first auth'd
  visit; never rebound across users.
- **Five IScope plugins**: `IVendorScope`, `ITenantScope`, `IGroupScope`,
  `IDeviceScope`, `IUserScope` in
  `conjunto.settings.scoped.scopes`. Each implements `resolve(request)
  → list[int|None]`, `filter_kwargs(ref)`, `can_edit`, `can_lock`,
  `ref_display`. `ITenantScope.resolve` tries `request.tenant` →
  `request.user.tenant_id` → `request.session['cj_tenant_id']`.
- **Registry** (`conjunto.settings.scoped.registry.SettingRegistry`):
  every `(namespace, key)` must be registered at startup via a
  top-level `scoped_settings.py` module in the consumer app
  (auto-discovered from `SettingsConfig.ready()`). Registry freezes
  on first read; tests use
  `conjunto.settings.scoped.testing.unfreeze_registry()`.
- **Resolver** (`conjunto.settings.scoped.resolver.get_effective`):
  one DB query per `(namespace, key)`, bucketed by scope, walked
  lowest-to-highest; a locked row short-circuits immediately. GROUP
  tie-break: highest-pk group wins unlocked, lowest-pk locked wins.
- **Proxy** (`conjunto.settings.scoped.proxy.ScopedSettingsProxy`):
  attached by middleware as `request.scoped_settings`. Has strict
  `get(ns, key)` and lenient `get(ns, key, default=...)`. Template
  access `{{ request.scoped_settings.myapp.foo }}` returns `""` for
  missing specs. Per-request cache proven via `assertNumQueries(1)`.
- **Pre-registered conjunto keys** (in
  `conjunto/scoped_settings.py`): `conjunto.layout_style`,
  `conjunto.topbar_fixed`, `conjunto.sidebar_width`,
  `conjunto.color_scheme`, `conjunto.maintenance_mode`. The first
  four drive `cj_layout` (override chain: Django settings → scoped →
  view context); `color_scheme` is set on `<html data-bs-theme>`
  server-side to prevent dark-mode flash; `maintenance_mode` drives
  maintenance-mode redirects in the middleware.
- **Tenant**: `conjunto.tenants.models.AbstractTenant` + concrete
  `Tenant` (swappable via `CONJUNTO_TENANT_MODEL`). Auto-creates a
  `tenant:<slug>:admin` auth.Group on first save. See
  `docs/usage/tenants.md` for the full reference.

### Tenant scoping for domain models

`conjunto.tenants.models` provides two mixins for marking a model as
tenant-scoped. Both auto-wire a `TenantManager` / `OptionalTenantManager`
(`conjunto.tenants.managers`) that filters every queryset by the tenant
bound on the `conjunto.tenants.context` ContextVar. The ContextVar is
populated by `ConjuntoMiddleware` from `request.tenant` during HTTP
requests; outside the request/response cycle use `override_tenant(t)`
as a context manager.

| Mixin                       | `tenant` FK | `objects` (bound) | `objects` (unbound)           | `create()` auto-injects |
|-----------------------------|-------------|-------------------|-------------------------------|-------------------------|
| `TenantModelMixin`          | NOT NULL    | `tenant=current`  | **raises `TenantScopeMissing`** | **yes**                 |
| `OptionalTenantModelMixin`  | nullable    | `tenant=current OR tenant IS NULL` | `tenant IS NULL` only (no raise) | no (pass `tenant=` explicitly) |

**Key properties**:

- Both mixins expose two managers: `objects` (scoped) and
  `all_objects` (plain `Manager`, unscoped). `Meta.base_manager_name
  = "all_objects"` so Django internals (FK validation, cascade
  deletes, admin autocomplete, reverse-relation access) always use
  the unscoped manager — they are **never** tenant-filtered.
- `TenantModelMixin.objects` fails loud: accessing it with no tenant
  bound raises `TenantScopeMissing` so Celery tasks, management
  commands and shell sessions can't silently return empty results.
  Escape via `with override_tenant(t):` or `Model.all_objects`.
- `OptionalTenantModelMixin.objects` degrades gracefully when no
  tenant is bound — it returns `tenant IS NULL` rows (globals) only.
  This matches the "optional tenant" semantics: a tenant-less caller
  is a legitimate state, not a bug. Bound tenant → globals **plus**
  that tenant's rows.
- `TenantManager.create()` / `bulk_create()` inject the bound tenant
  automatically; passing `tenant=` (or `tenant_id=`) explicitly
  always wins. `OptionalTenantManager` does **not** auto-inject —
  omitting `tenant` is the idiomatic way to create a global row.
- GROUP/site/… have nothing to do with this layer. Scoped settings
  (`conjunto.settings.scoped`) are an orthogonal concern.

**Idioms**:

```python
from conjunto.tenants.context import override_tenant

# Inside a view: middleware already bound request.tenant → just use it.
docs = TenantDoc.objects.filter(archived=False)

# Creating a tenant-scoped row: tenant comes from the context.
TenantDoc.objects.create(title="Invoice #42")

# Management command / Celery task: bind explicitly.
with override_tenant(acme):
    TenantDoc.objects.bulk_create([TenantDoc(title=t) for t in titles])

# Creating a global row on an OptionalTenant model.
VatRate.all_objects.create(country="DE", rate=19, tenant=None)

# Cross-tenant report / backup.
for doc in TenantDoc.all_objects.all():
    ...
```

If you hit `TenantScopeMissing`, the call site is running outside a
request with no `override_tenant(...)` block. Either wrap the caller
or use `all_objects` deliberately — **do not** silently catch the
exception.

**Tenant picker + `TenantRequiredMixin`**: Users who legitimately have
`user.tenant=None` (most commonly superadmins) pick a working tenant
per session via `conjunto.tenants.views.TenantPickView`, auto-mounted
at `/tenants/pick/` (URL name `tenants:pick`). The view lists active
tenants the user is allowed on — superusers see **every** active
tenant; everyone else is filtered to their `TenantMembership`
entries — and on POST stores the choice in
`request.session["cj_tenant_id"]`. `ConjuntoMiddleware` already reads
that session key as its last fallback when binding the tenant
ContextVar, so subsequent requests just work.

Tenant-scoped class-based views should inherit from
`conjunto.tenants.mixins.TenantRequiredMixin`: if `request.tenant` is
`None` at dispatch time, the user is redirected to `tenants:pick`
with a `?next=` pointing back at the original URL. **Do not** try to
model "no tenant" as a synthetic admin Tenant row — the idiomatic
path is `user.tenant=None` + session-picker + `all_objects` for
genuinely cross-tenant views (backups, reports, system overview).

The statusbar in `conjunto/base.html` shows the current tenant via
`{% tenant_badge %}` (from `conjunto.tenants.templatetags.tenant_tags`),
which renders as a link to the picker when the user has access to
more than one tenant and as plain text otherwise. The badge and the
picker view share
`conjunto.tenants.utils.get_allowed_tenants(request)` — a
request-cached queryset of all tenants the user is allowed to
select — so there is at most one extra DB hit per page render.

#### Settings page UI (unchanged from before)

The settings page uses a flat three-interface design mirroring
`IMenuItem`'s `menu` attribute, instead of a nested section/subsection
hierarchy:

| Interface          | Role                                                           |
|--------------------|----------------------------------------------------------------|
| `ISettingsGroup`   | Top-level category on the left rail ("User", "Tenant", …)      |
| `ISettingsSection` | Second-level entry under a group; selectable (`?section=<n>`)  |
| `ISettingsForm`    | One form subsection rendered in the right pane                 |

Each `ISettingsForm` declares `section = SomeSection` (class reference
or slug string — same dual lookup as `IMenuItem.parent`). Discovery is a
single `ISettingsForm.enabled_plugins()` call filtered by active
section; no per-section sub-interface is needed.

**Built-ins (in `src/conjunto/settings/menus.py`):**
- `UserGroup` — "User" category
- `UserProfileSection` — "Profile" section under User (slug `profile`)
- `UserNameFormPlugin` — ModelForm for `first_name` / `last_name`

Plugin implementations live in `menus.py` (same convention as the menu
system); `SettingsConfig.ready()` imports the module so the GDAPS
metaclass registers the plugins.

**URL wiring:** `src/conjunto/settings/urls.py` declares
`app_name = "settings"` and is auto-mounted at `/settings/` by
`PluginManager.urlpatterns()` in the consuming project's root URL conf.
The package never touches `src/conjunto/urls.py`.

**Adding a new section + form:**
```python
from conjunto.settings.interfaces import (
    ISettingsGroup, ISettingsSection, ISettingsForm,
)
from conjunto.settings.menus import UserGroup
from django import forms

class UserNotificationsSection(ISettingsSection):
    name = "notifications"
    group = UserGroup
    title = _("Notifications")
    icon = "bell"
    weight = 10
    permission_required = None  # optional Django perm

class _EmailPrefsForm(forms.ModelForm):
    class Meta:
        model = UserPreferences
        fields = ["email_digest", "email_mentions"]

class EmailPrefsPlugin(ISettingsForm):
    section = UserNotificationsSection  # or "notifications"
    name = "email_prefs"
    title = _("Email")
    form_class = _EmailPrefsForm

    def get_instance(self, request):
        return UserPreferences.objects.get_or_create(user=request.user)[0]
```

**HTMX flow:** section clicks swap only `#cj-settings-pane`; form saves
return 204 with `HX-Trigger: settings:changed` + a `showToast`
trigger and `HX-Reswap: none` (see the "HtmxFormViewMixin for in-place
partial swaps" section below for the underlying pattern). The pane
listens for `settings:changed from:body` and refetches itself to
pick up canonical state. Invalid forms render the `settings-form` partial
with bound errors via a Django 6 template partial (`conjunto/settings/page.html#settings-form`).

**Tabler layout conventions (do not improvise with plain Bootstrap):**
The template follows Tabler's canonical settings page
(<https://preview.tabler.io/settings.html>) exactly. The outer wrapper
is `.card > .row.g-0`; the rail is `.col-md-3.border-end > .card-body`
with `<h4 class="subheader">` per group (add `.mt-4` on 2nd+) and
`.list-group.list-group-transparent` for section links (items use
`.list-group-item-action.d-flex.align-items-center`, active gets
`.active`); the pane is `.col-md-9.d-flex.flex-column > .card-body`
with `<h2 class="mb-4">` for the active section title and
`<h3 class="card-title">` (`.mt-4` on 2nd+) for each subsection, plus
an optional `<p class="card-subtitle">`. **No `<hr>` between
subsections** — Tabler uses `mt-4` spacing instead. **Do not** use
`list-group-flush`, custom `bg-light` group headers, or other plain
Bootstrap idioms here. The tabler skill's "Settings layout" section has
the full class reference.

**Pointing a menu item at a section:**
```python
from django.urls import reverse_lazy
from django.utils.text import format_lazy

class ProfileMenuItem(IMenuItem):
    menu = "user"
    title = _("Profile")
    url = format_lazy("{}?section=profile", reverse_lazy("settings:index"))
```

### Layout & Template System

Conjunto provides a Tabler.io-based, mobile-first layout in `conjunto/base.html`.
**Full reference:** [`docs/usage/layout.md`](docs/usage/layout.md).

**Structure (fixed regions, only `.cj-page-content` scrolls):**

```
┌──────────────────────────────────────────────┐  #cj-topbar (fixed/sticky)
│ ☰  Brand  [menus.main]        [user ▼]      │
├─────────┬────────────────────────────────────┤
│ sidebar │   .cj-page-content (scrollable)    │
│ (fixed) │   ── canvas block ──               │
├─────────┴────────────────────────────────────┤  #cj-statusbar (fixed bottom)
│ © …                              [footer]    │
└──────────────────────────────────────────────┘
```

**Always extend `conjunto/base.html`** — never write your own `<html>` / `<body>`:

```django
{% extends "conjunto/base.html" %}
```

**Block hierarchy** (override what you need):

```
title, meta, extra_css
top_bar → top_bar_brand, top_bar_center, top_bar_actions, top_bar_right
sidebar
canvas → page_header (page_pretitle, page_title, page_actions), messages, content
offcanvas_left, offcanvas_right
footer → statusbar
modal, toasts, scripts
```

**Menus consumed by base.html:**

| Menu name        | Position                          |
|------------------|-----------------------------------|
| `menus.main`     | Topbar horizontal nav             |
| `menus.user`     | User avatar dropdown (top right)  |
| `menus.sidebar`  | Left sidebar (2 levels supported) |
| `menus.footer`   | Statusbar links (bottom right)    |

The sidebar supports an `inline_action` on top-level items (icon button on the
right, fades in on hover).

**Layout configuration follows a priority chain** — later overrides earlier:

```
settings.py defaults  →  request.scoped_settings (DB)  →  view context cj_layout
```

Three values are configurable:

| Key             | Default   | Purpose                                       |
|-----------------|-----------|-----------------------------------------------|
| `style`         | `"fluid"` | `"fluid"` (container-fluid) or `"boxed"` (container-xl) |
| `topbar_fixed`  | `True`    | `True` = `fixed-top`, `False` = `sticky-top`  |
| `sidebar_width` | `"15rem"` | CSS length, set inline on `<body>` (no recompile) |

Defaults: `CONJUNTO_LAYOUT`, `CONJUNTO_TOPBAR_FIXED`, `CONJUNTO_SIDEBAR_WIDTH`
in `settings.py`. DB override: write `ScopedSetting` rows for
`conjunto.layout_style`, `conjunto.topbar_fixed`,
`conjunto.sidebar_width` at any scope (VENDOR for global, TENANT for
per-tenant, USER for per-user, …). Per-view override:

```python
def get_context_data(self, **kwargs):
    ctx = super().get_context_data(**kwargs)
    ctx["cj_layout"] = {"style": "boxed", "topbar_fixed": False}
    return ctx
```

**Sidebar toggle:** single hamburger button (`#cj-sidebar-toggle`) in the
topbar, works on every screen size. Desktop ≥ 992 px → toggles
`body.cj-sidebar-collapsed` (push, persisted in `localStorage`). Mobile <
992 px → toggles `body.cj-sidebar-open` (overlay with backdrop). JS API:
`cjToggleSidebar()`.

**Offcanvas panels** (`#cj-offcanvas-left`, `#cj-offcanvas-right`) are always
in the DOM. Use them either by overriding the `offcanvas_left` /
`offcanvas_right` block (static) or by injecting an HTMX trigger button into
the `top_bar_actions` block:

```django
{% block top_bar_actions %}
  <button class="btn btn-ghost-secondary btn-icon"
          data-bs-toggle="offcanvas"
          data-bs-target="#cj-offcanvas-right"
          hx-get="{% url 'projects:filter_panel' %}"
          hx-target="#cj-offcanvas-right .offcanvas-body">
    <i class="ti ti-filter"></i>
  </button>
{% endblock %}
```

`top_bar_actions` is the recommended slot for any page-specific topbar
buttons (offcanvas triggers, page-level shortcuts, etc.).

### Toasts

Conjunto ships a Bootstrap/Tabler toast system driven by Django's
`messages` framework + HTMX. No component include is needed — the
toast container lives in `base.html`'s `{% block toasts %}` and is
rendered on every page.

- Normal views: `messages.success(request, "Saved.")` — shows a toast
  on full-page loads *and* HTMX swaps automatically. Works for
  `info`, `success`, `warning`, `error`, `debug` levels (Tabler soft
  color variants).
- `extra_tags="dismissible"` — the toast stays until the user closes
  it via the `×` button; otherwise it auto-hides after 6 s.
- HTMX view returning an `HttpResponse` directly:
  `conjunto.http.add_toast(response, "Done", level="success")`.
- Custom client-side: dispatch a `showToast` `CustomEvent` on
  `window` with `{message, level, dismissible?, delay?}`.

Wiring: `conjunto.middleware.ConjuntoMessagesMiddleware` must be in
`MIDDLEWARE` **after** `django.contrib.messages.middleware.MessageMiddleware`
and after `django_htmx.middleware.HtmxMiddleware`. On HTMX responses
it drains pending messages into an `HX-Trigger` header
(`conjunto:toasts` event). On full-page responses the
`conjunto/includes/toasts.html` template dumps them into a
`<script id="cj-initial-toasts" type="application/json">` block, and
`conjunto/js/toasts.js` renders both sources.

Full reference: [`docs/components/toasts.md`](docs/components/toasts.md).

### HtmxFormViewMixin for in-place partial swaps (not only modals)

`HtmxFormViewMixin` (`src/conjunto/htmx/views.py`) is most commonly used
with modal forms, but it also supports **in-place, partial-based pages**
where a form lives on the page itself and persists across saves. Pattern:

- Set `success_url = ""` and `success_event = "some:event"` on the view.
  The mixin converts the FormView default redirect into an empty 204
  response and `SuccessEventMixin.dispatch` adds
  `HX-Trigger: some:event` on the way out.
- In `form_valid`, call `super().form_valid(form)` as usual, then set
  `response["HX-Reswap"] = "none"`. This stops HTMX from applying the
  form's own `hx-target`/`hx-swap` to the empty body — otherwise the
  client-side `<form>` element would be removed. You can also call
  `trigger_client_event(response, "showToast", params={...})` to fire
  extra events (e.g. a toast).
- On the client, the `<form>` keeps its normal `hx-target`/`hx-swap` so
  that **validation errors** still swap in the re-rendered partial. A
  second element elsewhere on the page listens for the success event via
  `hx-trigger="some:event from:body"` + `hx-get="..."` to re-fetch its
  own partial and pick up canonical DB state.
- `form_invalid` is unaffected — point `template_name` at a
  `django-template-partials` partial (e.g.
  `"conjunto/settings/page.html#settings-form"`) so only the single form
  is rendered back with its errors.

`src/conjunto/settings/views.py` uses this pattern end-to-end; see
`SettingsFormView` for a concrete reference.

### Tables with CRUD row actions

`conjunto.tables` provides a thin layer on `django-tables2` for
reusable list tables with consistent, system-wide row actions.
**Full reference:** [`docs/usage/tables.md`](docs/usage/tables.md).

Three building blocks:

- **`RowAction`** — dataclass: `name`, `label`, `icon`, `url`
  (str or `(record) -> str`), `method`, `htmx`, `target`, `swap`,
  `confirm`, `confirm_style` (`"modal"`|`"inline"`), `variant`,
  `permission` (Django perm string or callable), `visible`,
  `weight`. `is_allowed(record, request)` runs both the permission
  check and the `visible` callable; `render_attrs(record)` builds
  the HTML attribute dict.
- **`CrudTableMixin`** — `tables.Table` mixin. Required:
  `crud_url_namespace` (e.g. `"projects:project"`, routes must be
  named `<ns>_update` / `<ns>_delete` with a `pk` kwarg — this is a
  hard contract). Optional knobs: `crud_actions` (default
  `("edit", "delete")`, set `()` to opt out), `extra_actions_menu`
  (GDAPS slot for `IRowAction` plugins), `edit_permission` /
  `delete_permission`, `delete_confirm_style` (`"modal"` default),
  `dialog_target` (`#cj-dialog` default), `listen_events`. Appends an
  `actions` column to `Meta.sequence`, sorts actions by weight,
  filters by permission/visible, renders through
  `conjunto/tables/_row_actions.html`.
- **`IRowAction`** — GDAPS interface for pluggable extra actions.
  One implementation = one action. Declares `menu = "<slot>"` and
  returns a `RowAction` (or `None` to skip) from
  `to_row_action(request, record)`. Tables opt in via
  `extra_actions_menu = "<slot>"`.

**Modal-confirm delete (default).** `delete_confirm_style="modal"`
(the default) makes the delete button `hx-get` the delete view into
the dialog; the user submits the confirmation form there. Pair with
`conjunto.htmx.views.ModalDeleteView`. Switch to
`"inline"` to use browser-native `hx-confirm` + direct `hx-post`.

**Auto-refresh via listen events.** The mixin exposes
`table.wrapper_id` (stable DOM id, e.g. `cj-table-projects-project`)
and `table.hx_trigger` (`"<ns>:created from:body, <ns>:changed
from:body, <ns>:deleted from:body"`). Wrap the table in one element
with `id="{{ table.wrapper_id }}"`, `hx-get="{{ request.path }}"`,
`hx-trigger="{{ table.hx_trigger }}"`, `hx-swap="outerHTML"`,
`hx-select="#{{ table.wrapper_id }}"`. Modal form views built on
`HtmxFormViewMixin` fire `HX-Trigger: <ns>:created|changed|deleted`
on success — the wrapper self-refetches, no JS required.

Minimal example:

```python
from conjunto.tables import CrudTableMixin
import django_tables2 as tables

class ProjectTable(CrudTableMixin, tables.Table):
    crud_url_namespace = "projects:project"

    class Meta:
        model = Project
        fields = ("name", "owner")
```

Override `get_row_actions(record, request)` for per-row logic
(e.g. append context-dependent actions) or `get_standard_actions`
to replace edit/delete entirely. Prefer `RowAction.variant` for
per-button styling (Tabler `btn-ghost-*` classes).

## Code Style

- Python 3.12+ required
- Black formatter (version >= 25.12.0)
- Type hints are being progressively added