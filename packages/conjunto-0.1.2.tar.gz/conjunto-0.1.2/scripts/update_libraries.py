#!/usr/bin/env python
"""Download JS/CSS libraries and save them into the conjunto static folder.

Usage:
    uv run scripts/update_libraries.py [library ...]
    uv run scripts/update_libraries.py --all
    uv run scripts/update_libraries.py --list

Each library entry is a list of 3-tuples:
  - local file path relative to the static/conjunto/ directory
  - URL to download
  - write mode: "w" for text, "wb" for binary (fonts)
"""

import argparse
import os
import sys
from pathlib import Path

import requests

STATIC_ROOT = Path(__file__).parent.parent / "src" / "conjunto" / "static" / "conjunto"

UNPKG = "https://unpkg.com"

TI_VERSION = "3.41.0"
TI_PATH = f"https://unpkg.com/@tabler/icons-webfont@{TI_VERSION}/dist"

TABLER_VERSION = "1.4.0"
TABLER_PATH = f"https://cdn.jsdelivr.net/npm/@tabler/core@{TABLER_VERSION}/dist"

LIBRARIES: dict[str, list[tuple[str, str, str]]] = {
    "alpine": [
        ("js/alpine.js", f"{UNPKG}/alpinejs/dist/cdn.js", "w"),
        ("js/alpine.min.js", f"{UNPKG}/alpinejs/dist/cdn.min.js", "w"),
    ],
    "chartjs": [
        ("js/chart.min.js", f"{UNPKG}/chart.js@4.4.9/dist/chart.umd.js", "w"),
    ],
    "dropzone": [
        ("js/dropzone.min.js", f"{UNPKG}/dropzone@5/dist/min/dropzone.min.js", "w"),
        ("js/dropzone.js", f"{UNPKG}/dropzone@5/dist/dropzone.js", "w"),
        ("css/dropzone.min.css", f"{UNPKG}/dropzone@5/dist/min/dropzone.min.css", "w"),
        ("css/dropzone.css", f"{UNPKG}/dropzone@5/dist/dropzone.css", "w"),
    ],
    "fslightbox": [
        ("js/fslightbox.js", f"{UNPKG}/fslightbox", "w"),
    ],
    "htmx": [
        ("js/htmx/htmx.js", f"{UNPKG}/htmx.org@latest/dist/htmx.js", "w"),
        ("js/htmx/htmx.min.js", f"{UNPKG}/htmx.org@latest/dist/htmx.min.js", "w"),
        ("js/htmx/ext/ws.js", f"https://cdn.jsdelivr.net/npm/htmx-ext-ws@2.0.4", "w"),
        ("js/htmx/ext/debug.js", f"{UNPKG}/htmx.org@latest/dist/ext/debug.js", "w"),
    ],
    "litepicker": [
        ("js/litepicker.js", f"{UNPKG}/litepicker/dist/litepicker.js", "w"),
    ],
    "sortable": [
        (
            "js/Sortable.min.js",
            "https://cdn.jsdelivr.net/npm/sortablejs@latest/Sortable.min.js",
            "w",
        ),
        (
            "js/Sortable.js",
            "https://cdn.jsdelivr.net/npm/sortablejs@latest/Sortable.js",
            "w",
        ),
    ],
    "tabler": [
        ("css/tabler.css", f"{TABLER_PATH}/css/tabler.css", "w"),
        ("css/tabler.min.css", f"{TABLER_PATH}/css/tabler.min.css", "w"),
        ("js/tabler.js", f"{TABLER_PATH}/js/tabler.js", "w"),
        ("js/tabler.min.js", f"{TABLER_PATH}/js/tabler.min.js", "w"),
        ("js/tabler-theme.js", f"{TABLER_PATH}/js/tabler-theme.js", "w"),
        ("js/tabler-theme.min.js", f"{TABLER_PATH}/js/tabler-theme.min.js", "w"),
        ("css/fonts/tabler-icons.woff", f"{TI_PATH}/fonts/tabler-icons.woff", "wb"),
        ("css/fonts/tabler-icons.woff2", f"{TI_PATH}/fonts/tabler-icons.woff2", "wb"),
        ("css/tabler-icons.css", f"{TI_PATH}/tabler-icons.css", "w"),
        ("css/tabler-icons.min.css", f"{TI_PATH}/tabler-icons.min.css", "w"),
    ],
}


def download_library(name: str) -> bool:
    files = LIBRARIES[name]
    ok = True
    for file_name, url, mode in files:
        target = STATIC_ROOT / file_name
        os.makedirs(target.parent, exist_ok=True)
        print(f"  {file_name}  <-  {url}")
        response = requests.get(url)
        if response.status_code != 200:
            print(
                f"  ERROR {response.status_code}: could not fetch {url}",
                file=sys.stderr,
            )
            ok = False
            continue
        with open(target, mode) as f:
            if mode == "w":
                f.write(response.text)
            else:
                f.write(response.content)
    return ok


def main() -> None:
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument(
        "library",
        nargs="*",
        choices=[*LIBRARIES, []],
        metavar="library",
        help=f"Libraries to download: {list(LIBRARIES)}",
    )
    group.add_argument("--all", action="store_true", help="Download all libraries")
    group.add_argument("--list", action="store_true", help="List available libraries")
    args = parser.parse_args()

    if args.list:
        print("Available libraries:")
        for name in LIBRARIES:
            print(f"  {name}")
        return

    targets = list(LIBRARIES) if args.all else args.library
    if not targets:
        parser.print_help()
        sys.exit(1)

    failed = []
    for name in targets:
        if name not in LIBRARIES:
            print(
                f"Unknown library: {name}. Available: {list(LIBRARIES)}",
                file=sys.stderr,
            )
            failed.append(name)
            continue
        print(f"[{name}]")
        if not download_library(name):
            failed.append(name)

    if failed:
        print(f"\nFailed: {failed}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
