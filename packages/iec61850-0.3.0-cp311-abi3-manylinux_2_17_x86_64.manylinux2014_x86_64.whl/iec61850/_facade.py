"""Public class surface for iec61850.

v0.2.0 wires the full typed scalar read/write surface (bool / int32 / uint32 /
int64 / float / float64 / string / timestamp / quality + corresponding writes)
to the native extension. The remaining methods (TLS connect, directory queries,
reporting, control, dataset) raise ``NotImplementedError`` until their slices
land.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from datetime import datetime, timedelta, timezone
from typing import Any

from . import _native
from ._dataclasses import (
    ClientReport,
    ControlParams,
    DataSetMember,
    Iec61850ClientConfig,
    Quality,
    QualityDetail,
    ReportOptFlds,
    TlsConfig,
    TriggerOptions,
    TypeSpec,
)
from ._enums import AcsiClass, FC, Validity

_NIE = "Not yet implemented — pending future vertical slice."


# Bit layout per IEC 61850-7-3 §6.2.3 / -8-1 BIT_STRING(13) Quality wire format.
# bits 0-1 = validity; bits 2-9 = detail flags; bit 10 source substituted;
# bit 11 test; bit 12 operator blocked.
_VALIDITY_BY_BITS: tuple[Validity, ...] = (
    Validity.GOOD,
    Validity.RESERVED,
    Validity.INVALID,
    Validity.QUESTIONABLE,
)


def _decode_quality_bits(bits: int) -> Quality:
    """Decode a 16-bit Quality packed value into the dataclass."""
    return Quality(
        validity=_VALIDITY_BY_BITS[bits & 0b11],
        detail=QualityDetail(
            overflow=bool(bits & 0x0004),
            out_of_range=bool(bits & 0x0008),
            bad_reference=bool(bits & 0x0010),
            oscillatory=bool(bits & 0x0020),
            failure=bool(bits & 0x0040),
            old_data=bool(bits & 0x0080),
            inconsistent=bool(bits & 0x0100),
            inaccurate=bool(bits & 0x0200),
        ),
        source_substituted=bool(bits & 0x0400),
        test=bool(bits & 0x0800),
        operator_blocked=bool(bits & 0x1000),
    )


def _decode_utc_time(buf: bytes) -> datetime:
    """Decode IEC 61850-8-1 Annex E UTC time (8-byte wire format) → datetime.

    Bytes 0..4 carry seconds since 1970-01-01 UTC (big-endian u32);
    bytes 4..7 carry a 24-bit big-endian fraction of a second (frac / 2^24);
    byte 7 is the TimeQuality flag byte (ignored here — pending its own slice).
    """
    if len(buf) != 8:
        raise ValueError(f"UTC time wire buffer must be 8 bytes, got {len(buf)}")
    secs = int.from_bytes(buf[0:4], "big")
    frac_raw = (buf[4] << 16) | (buf[5] << 8) | buf[6]
    micros = (frac_raw * 1_000_000) // (1 << 24)
    return datetime.fromtimestamp(secs, tz=timezone.utc) + timedelta(microseconds=micros)


class MmsValue:
    """Wrapper for composite MMS values (STRUCTURE / ARRAY / BIT_STRING / OCTET_STRING).

    Scalar values are NOT wrapped — typed read methods return native Python
    types directly, and generic ``IedConnection.read()`` returns a native value
    or this wrapper depending on the underlying MMS kind.
    """

    __slots__ = ()

    @property
    def kind(self) -> str:
        raise NotImplementedError(_NIE)

    def as_dict(self) -> dict[str, Any]:
        """STRUCTURE → dict."""
        raise NotImplementedError(_NIE)

    def as_list(self) -> list[Any]:
        """ARRAY → list."""
        raise NotImplementedError(_NIE)

    def as_bytes(self) -> bytes:
        """OCTET_STRING / BIT_STRING → bytes."""
        raise NotImplementedError(_NIE)

    @staticmethod
    def structure(members: dict[str, Any]) -> "MmsValue":
        raise NotImplementedError(_NIE)

    @staticmethod
    def array(elements: list[Any]) -> "MmsValue":
        raise NotImplementedError(_NIE)

    @staticmethod
    def octet_string(data: bytes) -> "MmsValue":
        raise NotImplementedError(_NIE)


class RcbHandle:
    """Opaque RCB-state mirror.

    Mutate via property setters, then push to the server with
    ``IedConnection.set_rcb_values(ref, handle, mask)``. ``conf_rev`` is
    server-controlled and read-only.
    """

    __slots__ = ()

    @property
    def rpt_ena(self) -> bool: raise NotImplementedError(_NIE)
    @rpt_ena.setter
    def rpt_ena(self, value: bool) -> None: raise NotImplementedError(_NIE)

    @property
    def rpt_id(self) -> str: raise NotImplementedError(_NIE)
    @rpt_id.setter
    def rpt_id(self, value: str) -> None: raise NotImplementedError(_NIE)

    @property
    def dataset(self) -> str: raise NotImplementedError(_NIE)
    @dataset.setter
    def dataset(self, value: str) -> None: raise NotImplementedError(_NIE)

    @property
    def conf_rev(self) -> int: raise NotImplementedError(_NIE)

    @property
    def buf_time(self) -> int: raise NotImplementedError(_NIE)
    @buf_time.setter
    def buf_time(self, value: int) -> None: raise NotImplementedError(_NIE)

    @property
    def trigger_options(self) -> TriggerOptions: raise NotImplementedError(_NIE)
    @trigger_options.setter
    def trigger_options(self, value: TriggerOptions) -> None: raise NotImplementedError(_NIE)

    @property
    def opt_flds(self) -> ReportOptFlds: raise NotImplementedError(_NIE)
    @opt_flds.setter
    def opt_flds(self, value: ReportOptFlds) -> None: raise NotImplementedError(_NIE)


class RcbWriteMask:
    """Selects which ``RcbHandle`` fields are pushed in ``set_rcb_values``."""

    __slots__ = ()

    @staticmethod
    def all() -> "RcbWriteMask":
        raise NotImplementedError(_NIE)

    @staticmethod
    def fields(*names: str) -> "RcbWriteMask":
        """Build a mask from field names (e.g. ``"rpt_ena"``, ``"trigger_options"``)."""
        raise NotImplementedError(_NIE)


class ReportDispatcher:
    """Background task polling the report queue at a fixed interval."""

    __slots__ = ()

    def stop(self) -> None:
        raise NotImplementedError(_NIE)

    async def aclose(self) -> None:
        raise NotImplementedError(_NIE)


class ControlObjectClient:
    """``select`` / ``operate`` / ``cancel`` for a single control object."""

    __slots__ = ()

    async def select(self) -> None:
        raise NotImplementedError(_NIE)

    async def operate(self, params: ControlParams) -> None:
        raise NotImplementedError(_NIE)

    async def cancel(self) -> None:
        raise NotImplementedError(_NIE)


class IedConnection:
    """IEC 61850 client connection. Async-only.

    **v0.3.0 wired surface**:

    - ``connect`` / ``disconnect`` / ``is_connected``
    - Typed scalar read/write: ``read_bool`` / ``read_int32`` / ``read_uint32`` /
      ``read_int64`` / ``read_float`` / ``read_float64`` / ``read_string`` /
      ``read_timestamp`` / ``read_quality`` + corresponding writes for bool /
      int32 / uint32 / float / octet_string / visible_string
    - Directory queries: ``get_server_directory`` /
      ``get_logical_device_directory`` / ``get_logical_node_directory`` /
      ``get_data_directory``

    Methods still pending their own slice (``connect_tls``, generic ``read`` /
    ``write``, ``get_variable_specification``, ``get_device_model``, reporting,
    control, dataset) raise ``NotImplementedError``.
    """

    __slots__ = ("_native_conn",)

    def __init__(self) -> None:
        raise TypeError(
            "Use `await IedConnection.connect(addr)` to construct an IedConnection."
        )

    # ─── lifecycle ────────────────────────────────────────────────────────
    @classmethod
    async def connect(cls, addr: str, *, timeout_ms: int = 5000) -> "IedConnection":
        native = await _native.IedConnection.connect(addr, timeout_ms=timeout_ms)
        self = cls.__new__(cls)
        self._native_conn = native
        return self

    @classmethod
    async def connect_tls(
        cls,
        addr: str,
        tls: TlsConfig,
        server_name: str,
        *,
        timeout_ms: int = 5000,
    ) -> "IedConnection":
        raise NotImplementedError(_NIE)

    async def disconnect(self) -> None:
        await self._native_conn.disconnect()

    @property
    def is_connected(self) -> bool:
        return self._native_conn.is_connected

    # ─── typed read ───────────────────────────────────────────────────────
    async def read_bool(self, ref: str, fc: FC) -> bool:
        return await self._native_conn.read_bool(ref, fc)

    async def read_int32(self, ref: str, fc: FC) -> int:
        return await self._native_conn.read_int32(ref, fc)

    async def read_uint32(self, ref: str, fc: FC) -> int:
        return await self._native_conn.read_uint32(ref, fc)

    async def read_int64(self, ref: str, fc: FC) -> int:
        return await self._native_conn.read_int64(ref, fc)

    async def read_float(self, ref: str, fc: FC) -> float:
        return await self._native_conn.read_float(ref, fc)

    async def read_float64(self, ref: str, fc: FC) -> float:
        return await self._native_conn.read_float64(ref, fc)

    async def read_string(self, ref: str, fc: FC) -> str:
        return await self._native_conn.read_string(ref, fc)

    async def read_timestamp(self, ref: str, fc: FC) -> datetime:
        raw: bytes = await self._native_conn.read_timestamp(ref, fc)
        return _decode_utc_time(raw)

    async def read_quality(self, ref: str, fc: FC) -> Quality:
        bits: int = await self._native_conn.read_quality_bits(ref, fc)
        return _decode_quality_bits(bits)

    # ─── typed write ──────────────────────────────────────────────────────
    async def write_bool(self, ref: str, fc: FC, value: bool) -> None:
        await self._native_conn.write_bool(ref, fc, value)

    async def write_int32(self, ref: str, fc: FC, value: int) -> None:
        await self._native_conn.write_int32(ref, fc, value)

    async def write_uint32(self, ref: str, fc: FC, value: int) -> None:
        await self._native_conn.write_uint32(ref, fc, value)

    async def write_float(self, ref: str, fc: FC, value: float) -> None:
        await self._native_conn.write_float(ref, fc, value)

    async def write_octet_string(self, ref: str, fc: FC, value: bytes) -> None:
        await self._native_conn.write_octet_string(ref, fc, value)

    async def write_visible_string(self, ref: str, fc: FC, value: str) -> None:
        await self._native_conn.write_visible_string(ref, fc, value)

    # ─── generic (composite types + alternate access) ─────────────────────
    async def read(
        self,
        ref: str,
        fc: FC,
        *,
        array_index: int | None = None,
        component: str | None = None,
    ) -> Any:
        """Return a native scalar (int / float / str / bool / datetime) OR an
        ``MmsValue`` for composite kinds. Use the typed read methods on hot paths.
        """
        raise NotImplementedError(_NIE)

    async def write(self, ref: str, fc: FC, value: Any) -> None:
        raise NotImplementedError(_NIE)

    # ─── directory / model ────────────────────────────────────────────────
    async def get_server_directory(self, include_lds: bool = True) -> list[str]:
        """Return all logical device names exposed by the server.

        ``include_lds`` is accepted for forward compatibility but currently
        ignored — file directory listing is pending its own slice.
        """
        return await self._native_conn.get_server_directory()

    async def get_logical_device_directory(self, ld: str) -> list[str]:
        return await self._native_conn.get_logical_device_directory(ld)

    async def get_logical_node_directory(self, ln_ref: str, cls: AcsiClass) -> list[str]:
        return await self._native_conn.get_logical_node_directory(ln_ref, cls)

    async def get_data_directory(self, data_ref: str) -> list[str]:
        """Return sub-element names one level under a data object.

        ``data_ref`` is ``"<LD>/<LN>.<DO>[.<sub>]*"``. Names returned do not
        carry FC suffixes; sub-elements present under multiple FCs are
        deduplicated.
        """
        return await self._native_conn.get_data_directory(data_ref)

    async def get_variable_specification(self, ref: str, fc: FC) -> TypeSpec:
        raise NotImplementedError(_NIE)

    async def get_device_model(self, refresh: bool = False) -> dict[str, Any]:
        raise NotImplementedError(_NIE)

    # ─── reporting ────────────────────────────────────────────────────────
    def install_report_handler(
        self,
        rcb_ref: str,
        callback: Callable[[ClientReport], Awaitable[None]],
    ) -> None:
        """Register an ``async def`` callback. It receives an owned
        ``ClientReport`` snapshot — safe to mutate locally without affecting
        further dispatches.
        """
        raise NotImplementedError(_NIE)

    def uninstall_report_handler(self, rcb_ref: str) -> None:
        raise NotImplementedError(_NIE)

    async def get_rcb_values(self, rcb_ref: str) -> RcbHandle:
        raise NotImplementedError(_NIE)

    async def set_rcb_values(
        self, rcb_ref: str, rcb: RcbHandle, mask: RcbWriteMask
    ) -> None:
        raise NotImplementedError(_NIE)

    async def refresh_rcb_values(self, rcb_ref: str, rcb: RcbHandle) -> None:
        raise NotImplementedError(_NIE)

    async def poll_reports(self, timeout_ms: int) -> None:
        """Caller-driven dispatch: pull one batch of pending reports and run
        any matching handlers."""
        raise NotImplementedError(_NIE)

    def spawn_report_dispatcher(self, interval_ms: int) -> ReportDispatcher:
        """Background dispatch: run ``poll_reports`` on an interval until
        ``ReportDispatcher.stop()`` / ``aclose()``."""
        raise NotImplementedError(_NIE)

    # ─── control ──────────────────────────────────────────────────────────
    async def create_control_object(self, co_ref: str) -> ControlObjectClient:
        raise NotImplementedError(_NIE)

    # ─── dataset ──────────────────────────────────────────────────────────
    async def create_data_set(self, ref: str, members: list[DataSetMember]) -> bool:
        raise NotImplementedError(_NIE)

    async def delete_data_set(self, ref: str) -> bool:
        raise NotImplementedError(_NIE)

    async def get_data_set_values(self, ref: str) -> list[Any]:
        raise NotImplementedError(_NIE)

    async def set_data_set_values(self, ref: str, values: list[Any]) -> None:
        raise NotImplementedError(_NIE)


class Iec61850Client:
    """csp_lib-friendly outer wrapper.

    Mirrors ``csp_lib.core.lifecycle.AsyncLifecycleMixin`` semantics — use as::

        async with Iec61850Client(cfg) as cli:
            await cli.connection.read_int32(ref, FC.MX)

    Manages the underlying ``IedConnection`` and, if
    ``config.report_dispatcher_interval_ms`` is set, a background
    ``ReportDispatcher``.
    """

    __slots__ = ("_config", "_connection")

    def __init__(self, config: Iec61850ClientConfig) -> None:
        self._config: Iec61850ClientConfig = config
        self._connection: IedConnection | None = None

    @property
    def config(self) -> Iec61850ClientConfig:
        return self._config

    @property
    def connection(self) -> IedConnection:
        if self._connection is None:
            raise RuntimeError("Iec61850Client is not entered — use `async with`.")
        return self._connection

    async def __aenter__(self) -> "Iec61850Client":
        raise NotImplementedError(_NIE)

    async def __aexit__(self, exc_type: object, exc: object, tb: object) -> None:
        raise NotImplementedError(_NIE)
