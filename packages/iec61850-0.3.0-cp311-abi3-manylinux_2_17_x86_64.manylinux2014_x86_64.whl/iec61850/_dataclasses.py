"""Frozen value-type dataclasses for the iec61850 public API.

These are pure-Python because they are immutable values — PyO3 classes are
reserved for opaque handles that hold Rust state (``IedConnection``,
``RcbHandle``, ``ControlObjectClient``, ``MmsValue``).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Mapping, Sequence

from ._enums import FC, Validity


@dataclass(frozen=True, slots=True)
class TriggerOptions:
    """RCB trigger conditions (TrgOps, IEC 61850-7-2 §17.2.3.2.4)."""

    data_change: bool = False
    quality_change: bool = False
    data_update: bool = False
    integrity: bool = False
    general_interrogation: bool = False


@dataclass(frozen=True, slots=True)
class ReportOptFlds:
    """RCB optional fields (OptFlds, IEC 61850-7-2 §17.2.3.2.5)."""

    sequence_number: bool = False
    report_timestamp: bool = False
    reason_for_inclusion: bool = False
    dataset_name: bool = False
    data_reference: bool = False
    buffer_overflow: bool = False
    entry_id: bool = False
    conf_rev: bool = False


@dataclass(frozen=True, slots=True)
class QualityDetail:
    """Detail bits of an IEC 61850 quality attribute (IEC 61850-7-3 §6.2.3)."""

    overflow: bool = False
    out_of_range: bool = False
    bad_reference: bool = False
    oscillatory: bool = False
    failure: bool = False
    old_data: bool = False
    inconsistent: bool = False
    inaccurate: bool = False


@dataclass(frozen=True, slots=True)
class Quality:
    """IEC 61850 quality attribute."""

    validity: Validity = Validity.GOOD
    detail: QualityDetail = field(default_factory=QualityDetail)
    source_substituted: bool = False
    test: bool = False
    operator_blocked: bool = False


@dataclass(frozen=True, slots=True)
class InclusionReason:
    """Reason a member was included in a report (IEC 61850-7-2 §17.2.3.2.6)."""

    data_change: bool = False
    quality_change: bool = False
    data_update: bool = False
    integrity: bool = False
    general_interrogation: bool = False
    application_trigger: bool = False


@dataclass(frozen=True, slots=True)
class ReportEntry:
    """One member's snapshot inside a ``ClientReport``."""

    ref: str
    value: Any  # native scalar OR MmsValue for composites
    quality: Quality | None = None
    timestamp: datetime | None = None
    reason: InclusionReason | None = None


@dataclass(frozen=True, slots=True)
class ClientReport:
    """A report delivered to a callback registered via ``install_report_handler``."""

    rpt_id: str
    dataset: str
    sequence_number: int
    timestamp: datetime | None
    conf_rev: int | None
    entries: Sequence[ReportEntry]


@dataclass(frozen=True, slots=True)
class ControlParams:
    """Parameters for ``ControlObjectClient.operate()``."""

    ctl_val: Any
    operate_time: datetime | None = None
    test: bool = False
    check_synchrocheck: bool = False
    check_interlock: bool = False
    origin_orcat: int = 0
    origin_orident: bytes = b""


@dataclass(frozen=True, slots=True)
class DataSetMember:
    """Member spec for ``create_data_set()``."""

    object_ref: str
    fc: FC
    array_index: int | None = None
    component: str | None = None


@dataclass(frozen=True, slots=True)
class TlsConfig:
    """TLS configuration for ``IedConnection.connect_tls()``.

    PEM-encoded bytes are accepted directly so callers can load from any source
    (file, KMS, secrets manager) without this package taking a filesystem dep.
    """

    ca_pem: bytes
    client_cert_pem: bytes | None = None
    client_key_pem: bytes | None = None
    verify_hostname: bool = True


@dataclass(frozen=True, slots=True)
class Iec61850ClientConfig:
    """High-level config consumed by the ``Iec61850Client`` wrapper."""

    address: str
    port: int = 102
    timeout_ms: int = 5000
    tls: TlsConfig | None = None
    report_dispatcher_interval_ms: int | None = 100


# TypeSpec is a recursive MMS type descriptor surfaced as a nested dict.
# Concrete schema lands with the directory vertical slice.
TypeSpec = Mapping[str, Any]
