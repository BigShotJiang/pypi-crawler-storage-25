"""iec61850 — Python client for IEC 61850 (MMS over TCP).

Async-first. Public surface re-exported from this module. See ``IedConnection``
for the primary client entry point.
"""

from __future__ import annotations

from ._dataclasses import (
    ClientReport,
    ControlParams,
    DataSetMember,
    Iec61850ClientConfig,
    InclusionReason,
    Quality,
    QualityDetail,
    ReportEntry,
    ReportOptFlds,
    TlsConfig,
    TriggerOptions,
    TypeSpec,
)
from ._enums import AcsiClass, FC, Validity
from ._facade import (
    ControlObjectClient,
    Iec61850Client,
    IedConnection,
    MmsValue,
    RcbHandle,
    RcbWriteMask,
    ReportDispatcher,
)
from ._native import (
    IedConnectionError,
    IedControlError,
    IedDataAccessError,
    IedError,
    IedServiceError,
    IedTimeoutError,
    __version__,
)

__all__ = [
    "AcsiClass",
    "ClientReport",
    "ControlObjectClient",
    "ControlParams",
    "DataSetMember",
    "FC",
    "Iec61850Client",
    "Iec61850ClientConfig",
    "IedConnection",
    "IedConnectionError",
    "IedControlError",
    "IedDataAccessError",
    "IedError",
    "IedServiceError",
    "IedTimeoutError",
    "InclusionReason",
    "MmsValue",
    "Quality",
    "QualityDetail",
    "RcbHandle",
    "RcbWriteMask",
    "ReportDispatcher",
    "ReportEntry",
    "ReportOptFlds",
    "TlsConfig",
    "TriggerOptions",
    "TypeSpec",
    "Validity",
    "__version__",
]
