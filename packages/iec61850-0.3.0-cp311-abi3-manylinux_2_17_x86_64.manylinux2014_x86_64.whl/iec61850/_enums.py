"""Enums for IEC 61850 functional constraints, ACSI classes, and quality."""

from __future__ import annotations

from enum import StrEnum


class FC(StrEnum):
    """Functional Constraint (IEC 61850-7-2 §6)."""

    ST = "ST"  # status information
    MX = "MX"  # measurands (analogue)
    SP = "SP"  # setpoint
    SV = "SV"  # substituted value
    CF = "CF"  # configuration
    DC = "DC"  # description
    SG = "SG"  # setting group
    SE = "SE"  # setting group editable
    SR = "SR"  # service response tracking
    OR = "OR"  # operate received
    BL = "BL"  # blocking
    EX = "EX"  # extended definition
    CO = "CO"  # control
    US = "US"  # unicast SCSM
    MS = "MS"  # multicast SCSM
    RP = "RP"  # unbuffered reporting
    BR = "BR"  # buffered reporting
    LG = "LG"  # logging


class AcsiClass(StrEnum):
    """ACSI class used by ``get_logical_node_directory``."""

    DATA_OBJECT = "DO"
    DATASET = "DS"
    REPORT = "RP"
    BUFFERED_REPORT = "BR"
    LOG = "LG"
    GOOSE = "GO"
    SETTING_GROUP = "SG"
    CONTROL = "CO"


class Validity(StrEnum):
    """Validity field of an IEC 61850 quality attribute (IEC 61850-7-3 §6.2.3.1)."""

    GOOD = "good"
    INVALID = "invalid"
    RESERVED = "reserved"
    QUESTIONABLE = "questionable"
