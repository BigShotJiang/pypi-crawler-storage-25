"""
Shim: allows `import sentinel` in addition to `from sentinel_ai import ...`
The implementation lives in sentinel_ai.sentinel.
"""
from sentinel_ai.sentinel import *  # noqa: F401, F403
from sentinel_ai.sentinel import (
    init, disable, workflow, trace_step, set_active_run,
    get_state, propose_state, propose_state_with_retry,
    register_contract, handoff, validate_payload,
    patch_openai, patch_anthropic, auto_instrument, LangChainCallback,
    ConflictError, ContractViolationError,
    WorkflowRun, WorkflowStep,
    Sentinel,
)
