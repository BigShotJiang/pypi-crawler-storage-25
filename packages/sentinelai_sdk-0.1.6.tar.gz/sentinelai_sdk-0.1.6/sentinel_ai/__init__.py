"""sentinel_ai — drop-in observability for multi-agent AI workflows."""

from sentinel_ai.sentinel import (
    init,
    disable,
    flush,
    workflow,
    trace_step,
    set_active_run,
    get_state,
    propose_state,
    propose_state_with_retry,
    register_contract,
    handoff,
    validate_payload,
    patch_openai,
    patch_openai_async,
    patch_anthropic,
    auto_instrument,
    LangChainCallback,
    ConflictError,
    ContractViolationError,
    WorkflowRun,
    WorkflowStep,
    Sentinel,
)

__version__ = "0.1.6"

__all__ = [
    "init", "disable", "flush", "workflow", "trace_step", "set_active_run",
    "get_state", "propose_state", "propose_state_with_retry",
    "register_contract", "handoff", "validate_payload",
    "patch_openai", "patch_openai_async", "patch_anthropic", "auto_instrument", "LangChainCallback",
    "ConflictError", "ContractViolationError",
    "WorkflowRun", "WorkflowStep",
    "Sentinel",
]
