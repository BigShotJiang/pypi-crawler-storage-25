#!/usr/bin/env python3
"""
sentinel instrument <file>

Reads a Python pipeline file, asks what you want to add,
and writes the instrumented version back.
"""

import ast
import sys
import os
import textwrap


# ── AST helpers ───────────────────────────────────────────────────────────────

def _find_functions(source: str):
    """Return list of (name, args, lineno) for every top-level function."""
    tree = ast.parse(source)
    fns = []
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef):
            args = [a.arg for a in node.args.args if a.arg != 'self']
            fns.append({"name": node.name, "args": args, "lineno": node.lineno})
    return fns


# ── Prompt helpers ────────────────────────────────────────────────────────────

def _ask(prompt, default="y"):
    """Yes/no prompt. Returns True for yes."""
    hint = "Y/n" if default == "y" else "y/N"
    ans = input(f"{prompt} ({hint}): ").strip().lower()
    if ans == "":
        return default == "y"
    return ans in ("y", "yes")


def _ask_fields(from_fn, to_fn):
    """
    Ask user what fields from_fn must return for to_fn.
    Returns list of (field_name, type_str) or None if skipped.
    """
    print(f"\n  What fields must '{from_fn}' return for '{to_fn}' to work?")
    print("  Format: name:type  (types: string, number, integer, boolean)")
    print("  Example: destination:string, budget:number, days:integer")
    print("  Press Enter to skip.")
    raw = input("  Fields: ").strip()
    if not raw:
        return None
    fields = []
    for part in raw.split(","):
        part = part.strip()
        if ":" in part:
            name, typ = part.split(":", 1)
            fields.append((name.strip(), typ.strip()))
        elif part:
            fields.append((part, "string"))
    return fields if fields else None


# ── Code generation ───────────────────────────────────────────────────────────

def _required_list(fields):
    return ", ".join(f'"{f}"' for f, _ in fields)


def _type_to_schema(typ: str) -> str:
    mapping = {
        "string": '"string"', "str": '"string"',
        "number": '"number"', "float": '"number"',
        "integer": '"integer"', "int": '"integer"',
        "boolean": '"boolean"', "bool": '"boolean"',
    }
    return mapping.get(typ.lower(), '"string"')


def _generate_instrumented(source, file_path, fns, add_tracing, contracts, add_state, api_key):
    """
    Build the instrumented source. Strategy:
    1. Build the setup block (imports + init + register_contract calls)
    2. Find the last import line in the original source and insert setup after it
    3. Walk remaining lines to insert record_step after agent calls
    4. Insert set_active_run at the top of the pipeline entry function
    """
    lines = source.splitlines()

    # ── 1. Build setup block ──────────────────────────────────────────────────
    setup = []
    if contracts:
        setup.append("import sentinel")
        setup.append("from sentinel import Sentinel")
        setup.append(f'sentinel.init(api_key="{api_key}")')
        setup.append("")
        setup.append(f'client = Sentinel(api_key="{api_key}")')
        setup.append("")
        for (from_fn, to_fn, fields) in contracts:
            props = "\n".join(
                f'    "{f}": {{"type": {_type_to_schema(t)}, "required": True}},'
                for f, t in fields
            )
            setup.append("client.register_contract(")
            setup.append('    workflow_name="my_pipeline",')
            setup.append(f'    from_step="{from_fn}",')
            setup.append(f'    to_step="{to_fn}",')
            setup.append("    schema={")
            setup.append('        "type": "object",')
            setup.append(f'        "required": [{_required_list(fields)}],')
            setup.append('        "properties": {')
            for f, t in fields:
                setup.append(f'            "{f}": {{"type": {_type_to_schema(t)}, "required": True}},')
            setup.append("        }")
            setup.append("    },")
            setup.append('    on_fail="block"')
            setup.append(")")
            setup.append("")
    elif add_tracing:
        setup.append("import sentinel")
        setup.append(f'sentinel.init(api_key="{api_key}")')
        setup.append("")

    # ── 2. Find last import line (1-indexed from AST) ─────────────────────────
    tree = ast.parse(source)
    last_import_lineno = 0
    for node in ast.walk(tree):
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            last_import_lineno = max(last_import_lineno, node.lineno)

    # ── 3. Insert setup after last import (or at top if none) ────────────────
    output = []
    if last_import_lineno == 0:
        output.extend(setup)
    for i, line in enumerate(lines):
        output.append(line)
        if i + 1 == last_import_lineno:  # i is 0-indexed, lineno is 1-indexed
            output.append("")
            output.extend(setup)

    # ── 4. Insert run_id (and set_active_run for tracing) at top of entry fn ──
    if (add_tracing or contracts) and fns:
        entry_candidates = [f for f in fns if any(k in f["name"] for k in ("pipeline", "run", "main"))]
        entry_fn = entry_candidates[0] if entry_candidates else fns[-1]

        result_lines = []
        inserted = False
        for line in output:
            result_lines.append(line)
            if not inserted and line.strip().startswith("def ") and f"{entry_fn['name']}(" in line:
                indent = "    "
                result_lines.append(f"{indent}import uuid")
                result_lines.append(f'{indent}run_id = f"run_{{uuid.uuid4().hex[:10]}}"')
                if add_tracing:
                    result_lines.append(f'{indent}sentinel.set_active_run(run_id, "my_pipeline")')
                inserted = True
        output = result_lines

    # ── 5. Insert record_step after each agent call ───────────────────────────
    if contracts:
        contract_from = {from_fn for (from_fn, _, _) in contracts}
        result_lines = []
        for line in output:
            result_lines.append(line)
            stripped = line.strip()
            for (from_fn, to_fn, fields) in contracts:
                if f"{from_fn}(" in stripped and "=" in stripped and not stripped.startswith("#"):
                    var = stripped.split("=")[0].strip()
                    indent = " " * (len(line) - len(line.lstrip()))
                    result_lines.append(f'{indent}check = client.record_step(run_id=run_id, step_name="{from_fn}", output={var})')
                    result_lines.append(f'{indent}if check["boundary_check"]["result"] == "failed":')
                    result_lines.append(f'{indent}    print("Blocked:", check["boundary_check"]["reason"]); return')
        output = result_lines

    # ── 6. Insert shared state writes after agent calls ───────────────────────
    if add_state and fns:
        agent_names = {f["name"] for f in fns}
        result_lines = []
        for line in output:
            result_lines.append(line)
            stripped = line.strip()
            for fn in fns:
                if (f"{fn['name']}(" in stripped and "=" in stripped
                        and not stripped.startswith("#") and "record_step" not in stripped):
                    var = stripped.split("=")[0].strip()
                    indent = " " * (len(line) - len(line.lstrip()))
                    state_lambda = 'lambda cur: {**(cur or {}), "' + var + '": ' + var + '}'
                    result_lines.append(
                        f'{indent}sentinel.propose_state_with_retry(run_id, "pipeline_state", {state_lambda})'
                    )
        output = result_lines

    return "\n".join(output)


# ── Main CLI ──────────────────────────────────────────────────────────────────

def instrument(file_path: str):
    if not os.path.exists(file_path):
        print(f"Error: file not found: {file_path}")
        sys.exit(1)

    with open(file_path) as f:
        source = f.read()

    try:
        fns = _find_functions(source)
    except SyntaxError as e:
        print(f"Error parsing {file_path}: {e}")
        sys.exit(1)

    if not fns:
        print(f"No functions found in {file_path}.")
        sys.exit(0)

    print(f"\nAnalyzing {file_path}...\n")
    print(f"Found {len(fns)} function(s):")
    for fn in fns:
        args_str = ", ".join(fn["args"]) if fn["args"] else "no args"
        print(f"  - {fn['name']}({args_str})  [line {fn['lineno']}]")

    print()
    api_key = input("Your Sentinel API key (sk_live_...): ").strip()
    if not api_key:
        api_key = "sk_live_..."

    # ── Tracing ───────────────────────────────────────────────────────────────
    add_tracing = _ask("\nAdd tracing? (records every step — latency, inputs, outputs → Traces tab)")

    # ── Contracts ─────────────────────────────────────────────────────────────
    contracts = []
    add_contracts = _ask("Add contracts? (block bad data between agents → Incidents tab)")
    if add_contracts and len(fns) >= 2:
        print(f"\n  Found {len(fns)} functions. Define which ones hand off to each other.")
        for i in range(len(fns) - 1):
            from_fn = fns[i]["name"]
            to_fn   = fns[i + 1]["name"]
            if _ask(f"  Enforce what '{from_fn}' returns before '{to_fn}' runs?"):
                fields = _ask_fields(from_fn, to_fn)
                if fields:
                    contracts.append((from_fn, to_fn, fields))
                    print(f"  ✓ Contract: {from_fn} → {to_fn}  ({len(fields)} field(s))")

    # ── Shared state ──────────────────────────────────────────────────────────
    add_state = _ask("Add shared state? (only needed if agents run concurrently)")

    # ── Write output ──────────────────────────────────────────────────────────
    if not add_tracing and not contracts and not add_state:
        print("\nNothing to add. Exiting.")
        sys.exit(0)

    instrumented = _generate_instrumented(
        source, file_path, fns, add_tracing, contracts, add_state, api_key
    )

    # Write to a new file so original is never overwritten without review
    out_path = file_path.replace(".py", "_sentinel.py")
    with open(out_path, "w") as f:
        f.write(instrumented)

    print(f"\n✓ Written to: {out_path}")
    print(f"  Review the changes, then rename to {file_path} when ready.")
    print(f"  View traces at: https://www.agentsentinelai.com/dashboard")


def main():
    if len(sys.argv) < 3 or sys.argv[1] != "instrument":
        print("Usage: sentinel instrument <path/to/file.py>")
        print("       sentinel instrument pipeline.py")
        print("       sentinel instrument agents/research_agent.py")
        sys.exit(1)
    instrument(sys.argv[2])


if __name__ == "__main__":
    main()
