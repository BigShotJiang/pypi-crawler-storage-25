# pymaxgram

Async Python framework for building bots on **MAX Messenger** platform.

Built with `asyncio`, `aiohttp`, and `pydantic`. Inspired by aiogram architecture.

## Installation

```bash
pip install pymaxgram
```

## Quick Start

```python
import asyncio
from maxgram import Bot, Dispatcher, Router

bot = Bot(token="YOUR_BOT_TOKEN")
dp = Dispatcher()
router = Router()


@router.message()
async def echo(message, bot):
    await message.answer(text=message.body.text)


dp.include_router(router)
asyncio.run(dp.start_polling(bot))
```

---

## Examples

### Command Handling

```python
from maxgram import Bot, Dispatcher, Router
from maxgram.filters import Command, CommandStart, CommandObject

router = Router()


@router.message(CommandStart())
async def start_handler(message, bot):
    name = message.sender.first_name
    await message.answer(text=f"Welcome, {name}!")


@router.message(Command("help"))
async def help_handler(message, bot):
    await message.answer(text="Available commands:\n/start - Start bot\n/help - Show help")


@router.message(Command("echo"))
async def echo_command(message, command: CommandObject, bot):
    if command.args:
        await message.answer(text=command.args)
    else:
        await message.answer(text="Usage: /echo <text>")
```

### Inline Keyboard & Callbacks

```python
from maxgram import F, Router
from maxgram.types import InlineKeyboard, Button, Attachment
from maxgram.enums import ButtonType

router = Router()


@router.message(Command("menu"))
async def show_menu(message, bot):
    keyboard = InlineKeyboard(buttons=[
        [
            Button(type=ButtonType.CALLBACK, text="Like", payload="vote:like"),
            Button(type=ButtonType.CALLBACK, text="Dislike", payload="vote:dislike"),
        ],
        [
            Button(type=ButtonType.LINK, text="Website", url="https://max.ru"),
        ],
    ])
    await message.answer(
        text="Rate our bot:",
        attachments=[
            Attachment(type="inline_keyboard", payload=keyboard.model_dump(mode="json"))
        ],
    )


@router.message_callback(F.payload == "vote:like")
async def on_like(callback, bot):
    await callback.answer(notification="Thanks for your like!")


@router.message_callback(F.payload == "vote:dislike")
async def on_dislike(callback, bot):
    await callback.answer(notification="We'll try to improve!")
```

### CallbackData Factory

```python
from maxgram import F, Router
from maxgram.filters import CallbackData

router = Router()


class ProductCallback(CallbackData, prefix="product"):
    id: int
    action: str


@router.message(Command("products"))
async def show_products(message, bot):
    keyboard = InlineKeyboard(buttons=[
        [
            Button(
                type=ButtonType.CALLBACK,
                text="Buy iPhone",
                payload=ProductCallback(id=1, action="buy").pack(),
            ),
        ],
        [
            Button(
                type=ButtonType.CALLBACK,
                text="Buy MacBook",
                payload=ProductCallback(id=2, action="buy").pack(),
            ),
        ],
    ])
    await message.answer(
        text="Our products:",
        attachments=[
            Attachment(type="inline_keyboard", payload=keyboard.model_dump(mode="json"))
        ],
    )


@router.message_callback(ProductCallback.filter())
async def on_product_action(callback, callback_data: ProductCallback, bot):
    await callback.answer(
        notification=f"Product #{callback_data.id}, action: {callback_data.action}"
    )
```

### Finite State Machine (FSM)

```python
from maxgram import Bot, Dispatcher, Router
from maxgram.filters import Command, StateFilter
from maxgram.fsm.state import State, StatesGroup
from maxgram.fsm.context import FSMContext

router = Router()


class RegistrationStates(StatesGroup):
    waiting_name = State()
    waiting_age = State()
    waiting_confirm = State()


@router.message(Command("register"))
async def start_registration(message, state: FSMContext, bot):
    await state.set_state(RegistrationStates.waiting_name)
    await message.answer(text="What is your name?")


@router.message(StateFilter(RegistrationStates.waiting_name))
async def process_name(message, state: FSMContext, bot):
    await state.update_data(name=message.body.text)
    await state.set_state(RegistrationStates.waiting_age)
    await message.answer(text="How old are you?")


@router.message(StateFilter(RegistrationStates.waiting_age))
async def process_age(message, state: FSMContext, bot):
    try:
        age = int(message.body.text)
    except ValueError:
        await message.answer(text="Please enter a valid number.")
        return

    await state.update_data(age=age)
    data = await state.get_data()
    await state.clear()
    await message.answer(text=f"Registration complete!\nName: {data['name']}\nAge: {age}")
```

### MagicFilter

```python
from maxgram import F, Router

router = Router()

# Filter messages by text content
@router.message(F.body.text == "hello")
async def exact_match(message, bot):
    await message.answer(text="Hello!")


# Filter by sender
@router.message(F.sender.is_bot == False)
async def humans_only(message, bot):
    pass


# Filter callbacks by payload prefix
@router.message_callback(F.payload.startswith("action:"))
async def action_handler(callback, bot):
    action = callback.payload.split(":")[1]
    await callback.answer(notification=f"Action: {action}")
```

### Middleware

```python
import time
import logging
from typing import Any
from collections.abc import Awaitable, Callable

from maxgram import BaseMiddleware
from maxgram.types import MaxObject

logger = logging.getLogger(__name__)


class LoggingMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[MaxObject, dict[str, Any]], Awaitable[Any]],
        event: MaxObject,
        data: dict[str, Any],
    ) -> Any:
        start = time.monotonic()
        result = await handler(event, data)
        duration = time.monotonic() - start
        logger.info("Handler completed in %.3fs", duration)
        return result


class AuthMiddleware(BaseMiddleware):
    def __init__(self, allowed_user_ids: set[int]):
        self.allowed_user_ids = allowed_user_ids

    async def __call__(self, handler, event, data):
        user = data.get("event_from_user")
        if user and user.user_id not in self.allowed_user_ids:
            return  # Ignore unauthorized users
        return await handler(event, data)


# Register middleware on router
router.message.outer_middleware(LoggingMiddleware())
router.message.outer_middleware(AuthMiddleware(allowed_user_ids={123456, 789012}))
```

### Chat Actions (Typing Indicator)

```python
import asyncio
from maxgram import Router
from maxgram.utils.chat_action import ChatActionSender
from maxgram.filters import Command

router = Router()


@router.message(Command("slow"))
async def slow_handler(message, bot):
    async with ChatActionSender.typing(
        chat_id=message.recipient.chat_id,
        bot=bot,
    ):
        await asyncio.sleep(3)  # Simulate long operation
        await message.answer(text="Done! Typing indicator was shown while processing.")
```

### Text Formatting

```python
from maxgram import Router, html, md
from maxgram.utils.formatting import (
    Text, Bold, Italic, Code, Pre,
    as_list, as_marked_list, as_numbered_list, as_section,
)
from maxgram.filters import Command

router = Router()


@router.message(Command("format"))
async def formatting_example(message, bot):
    content = as_list(
        Bold("User Info"),
        as_marked_list(
            f"Name: {message.sender.first_name}",
            f"ID: {message.sender.user_id}",
        ),
        "",
        as_section(
            Bold("Features"),
            as_numbered_list(
                "Async architecture",
                "FSM support",
                "Middleware system",
                "Inline keyboards",
            ),
        ),
    )
    await message.answer(**content.as_kwargs())


@router.message(Command("code"))
async def code_example(message, bot):
    content = as_list(
        Bold("Code Example:"),
        Pre("print('Hello, MAX!')", language="python"),
        "",
        Text("Use ", Code("/help"), " for more info."),
    )
    await message.answer(**content.as_kwargs())
```

### Multiple Routers

```python
from maxgram import Bot, Dispatcher, Router

# Admin router
admin_router = Router(name="admin")


@admin_router.message(Command("ban"))
async def ban_user(message, bot):
    await message.answer(text="User banned.")


# User router
user_router = Router(name="user")


@user_router.message(Command("profile"))
async def show_profile(message, bot):
    await message.answer(text=f"Your ID: {message.sender.user_id}")


# Main setup
dp = Dispatcher()
dp.include_routers(admin_router, user_router)
```

### Startup & Shutdown Events

```python
import logging
from maxgram import Bot, Dispatcher, Router

router = Router()
logger = logging.getLogger(__name__)


@router.startup()
async def on_startup(bot: Bot, dispatcher: Dispatcher):
    me = await bot.get_me()
    logger.info("Bot started: %s", me.name)


@router.shutdown()
async def on_shutdown(bot: Bot, dispatcher: Dispatcher):
    logger.info("Bot shutting down...")
```

### Error Handling

```python
from maxgram import Router
from maxgram.filters import ExceptionTypeFilter

router = Router()


@router.error(ExceptionTypeFilter(ValueError))
async def handle_value_error(error, bot):
    print(f"ValueError caught: {error}")


@router.error()
async def handle_all_errors(error, bot):
    print(f"Unhandled error: {error}")
```

### Default Bot Properties

```python
from maxgram import Bot
from maxgram.client.default import DefaultBotProperties
from maxgram.enums import ParseMode

bot = Bot(
    token="YOUR_BOT_TOKEN",
    default=DefaultBotProperties(
        parse_mode=ParseMode.HTML,
        disable_link_preview=True,
        notify=False,
    ),
)
```

### Webhook (aiohttp)

```python
from aiohttp import web
from maxgram import Bot, Dispatcher
from maxgram.webhook.aiohttp_server import SimpleRequestHandler, setup_application

bot = Bot(token="YOUR_BOT_TOKEN")
dp = Dispatcher()

# ... register handlers ...

app = web.Application()
handler = SimpleRequestHandler(dp, bot, secret_token="your_secret")
handler.register(app, "/webhook")
setup_application(app, dp)
web.run_app(app, host="0.0.0.0", port=8080)
```

### Full Bot Example

```python
import asyncio
import logging

from maxgram import Bot, Dispatcher, F, Router
from maxgram.client.default import DefaultBotProperties
from maxgram.enums import ButtonType, ParseMode
from maxgram.filters import Command, CommandStart, StateFilter, CallbackData
from maxgram.fsm.state import State, StatesGroup
from maxgram.fsm.context import FSMContext
from maxgram.types import Attachment, Button, InlineKeyboard
from maxgram.utils.formatting import Bold, Text, as_list, as_marked_list

logging.basicConfig(level=logging.INFO)

bot = Bot(
    token="YOUR_BOT_TOKEN",
    default=DefaultBotProperties(parse_mode=ParseMode.HTML),
)
dp = Dispatcher()
router = Router()


# --- FSM States ---
class OrderStates(StatesGroup):
    choosing_item = State()
    confirming = State()


# --- Callback Data ---
class ItemCallback(CallbackData, prefix="item"):
    name: str


class ConfirmCallback(CallbackData, prefix="confirm"):
    value: bool


# --- Handlers ---
@router.message(CommandStart())
async def cmd_start(message, bot):
    await message.answer(text="Welcome! Use /order to make an order.")


@router.message(Command("order"))
async def cmd_order(message, state: FSMContext, bot):
    keyboard = InlineKeyboard(buttons=[
        [
            Button(
                type=ButtonType.CALLBACK,
                text="Pizza",
                payload=ItemCallback(name="pizza").pack(),
            ),
            Button(
                type=ButtonType.CALLBACK,
                text="Burger",
                payload=ItemCallback(name="burger").pack(),
            ),
        ],
    ])
    await state.set_state(OrderStates.choosing_item)
    await message.answer(
        text="Choose your item:",
        attachments=[
            Attachment(type="inline_keyboard", payload=keyboard.model_dump(mode="json"))
        ],
    )


@router.message_callback(ItemCallback.filter(), StateFilter(OrderStates.choosing_item))
async def on_item_chosen(callback, callback_data: ItemCallback, state: FSMContext, bot):
    await state.update_data(item=callback_data.name)
    await state.set_state(OrderStates.confirming)

    keyboard = InlineKeyboard(buttons=[
        [
            Button(
                type=ButtonType.CALLBACK,
                text="Confirm",
                payload=ConfirmCallback(value=True).pack(),
            ),
            Button(
                type=ButtonType.CALLBACK,
                text="Cancel",
                payload=ConfirmCallback(value=False).pack(),
            ),
        ],
    ])
    await callback.answer(
        text=f"You chose: {callback_data.name}. Confirm?",
        attachments=[
            Attachment(type="inline_keyboard", payload=keyboard.model_dump(mode="json"))
        ],
    )


@router.message_callback(ConfirmCallback.filter(), StateFilter(OrderStates.confirming))
async def on_confirm(callback, callback_data: ConfirmCallback, state: FSMContext, bot):
    if callback_data.value:
        data = await state.get_data()
        content = as_list(
            Bold("Order confirmed!"),
            as_marked_list(f"Item: {data['item']}"),
        )
        await callback.answer(**content.as_kwargs())
    else:
        await callback.answer(text="Order cancelled.")
    await state.clear()


@router.message()
async def echo(message, bot):
    await message.answer(text=message.body.text)


# --- Run ---
dp.include_router(router)
asyncio.run(dp.start_polling(bot))
```

## Links

- MAX Bot API: https://dev.max.ru
- PyPI: https://pypi.org/project/pymaxgram/
