class ListenerTimeout(Exception):
    pass
