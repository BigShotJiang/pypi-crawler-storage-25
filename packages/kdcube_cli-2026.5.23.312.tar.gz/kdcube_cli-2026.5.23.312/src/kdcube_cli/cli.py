# SPDX-License-Identifier: MIT
from __future__ import annotations

import argparse
import io
import json
import os
import posixpath
import shlex
import shutil
import subprocess
import sys
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit

import yaml
from rich.console import Console
from rich.control import Control
from rich.live import Live
from rich.panel import Panel
from rich.prompt import Confirm, Prompt
from rich.table import Table
from rich.text import Text

from kdcube_cli.banner import print_cli_banner
from kdcube_cli import installer as installer_mod
from kdcube_cli.export_live_bundles import export_live_bundle_descriptors
from kdcube_cli.tty_keys import (
    KEY_DOWN,
    KEY_ENTER,
    KEY_EOF,
    KEY_ESCAPE,
    KEY_INTERRUPT,
    KEY_UP,
    read_tty_key,
)


DEFAULT_REPO = "https://github.com/kdcube/kdcube-ai-app.git"
DEFAULT_DIR = Path.home() / ".kdcube" / "kdcube-ai-app"
DEFAULT_WORKDIR = Path.home() / ".kdcube" / "kdcube-runtime"
DEFAULT_DEFAULTS_FILE = Path.home() / ".kdcube" / "cli-defaults.json"
CLI_LOCK_FILE = Path.home() / ".kdcube" / "cli-lock.json"
DEFAULT_REPO_DIRNAME = "repo"
DOCKER_STATUS_TIMEOUT_SECONDS = 20
DOCKER_CLEAN_TIMEOUT_SECONDS = 120
STANDARD_INIT_SECRET_PROMPTS: tuple[tuple[str, str], ...] = (
    ("services.openai.api_key", "OpenAI API key"),
    ("services.anthropic.api_key", "Anthropic API key"),
    ("services.git.http_token", "Git HTTPS token"),
)
SECRET_KEY_ALIASES: dict[str, str] = {
    "OPENAI_API_KEY": "services.openai.api_key",
    "ANTHROPIC_API_KEY": "services.anthropic.api_key",
    "GIT_HTTP_TOKEN": "services.git.http_token",
    "BRAVE_API_KEY": "services.brave.api_key",
    "GOOGLE_API_KEY": "services.google.api_key",
    "GEMINI_API_KEY": "services.google.api_key",
    "OPENROUTER_API_KEY": "services.openrouter.api_key",
    "HUGGINGFACE_API_KEY": "services.huggingface.api_key",
    "STRIPE_SECRET_KEY": "services.stripe.secret_key",
    "STRIPE_WEBHOOK_SECRET": "services.stripe.webhook_secret",
}
KDCUBE_REPOS = {
    "kdcube-chat-ingress",
    "kdcube-chat-proc",
    "kdcube-metrics",
    "kdcube-postgres-setup",
    "kdcube-secrets",
    "kdcube-web-ui",
    "kdcube-web-proxy",
    "proxylogin",
    "py-code-exec",
}


class _AmbiguousWorkdirError(Exception):
    def __init__(self, base_workdir: Path, candidates: list[Path]) -> None:
        self.base_workdir = base_workdir
        self.candidates = candidates
        super().__init__(str(base_workdir))


class _NullWriter(io.StringIO):
    def write(self, value: str) -> int:
        return len(value)

    def flush(self) -> None:
        return None

    def isatty(self) -> bool:
        return False


def _cli_quiet_requested(argv: list[str], *, stdout_is_tty: bool | None = None) -> bool:
    if _cli_explicit_quiet_requested(argv):
        return True
    args = list(argv or [])
    if any(arg == "--json" or arg.startswith("--json=") for arg in args):
        return True
    is_tty = sys.stdout.isatty() if stdout_is_tty is None else bool(stdout_is_tty)
    return not is_tty


def _cli_explicit_quiet_requested(argv: list[str]) -> bool:
    raw_env = os.environ.get("KDCUBE_CLI_QUIET", "").strip().lower()
    if raw_env not in {"", "0", "false", "no"}:
        return True
    args = list(argv or [])
    if any(arg in {"-q", "--quiet"} for arg in args):
        return True
    return False


def _print_json(payload: object) -> None:
    sys.stdout.write(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True))
    sys.stdout.write("\n")
    sys.stdout.flush()


def run(cmd: list[str], cwd: Path | None = None, *, timeout: float | None = None) -> None:
    subprocess.run(cmd, cwd=cwd, check=True, timeout=timeout)


def _docker_output(
    cmd: list[str],
    env: dict[str, str] | None = None,
    *,
    cwd: Path | None = None,
    timeout: float | None = None,
) -> str:
    try:
        return subprocess.run(
            cmd,
            check=True,
            capture_output=True,
            text=True,
            env=env,
            cwd=str(cwd) if cwd else None,
            timeout=timeout,
        ).stdout
    except subprocess.TimeoutExpired as exc:
        timeout_label = f"{timeout:g}" if timeout is not None else "unknown"
        raise SystemExit(
            f"Docker command timed out after {timeout_label}s: {shlex.join(cmd)}\n"
            "Docker Desktop or the Docker daemon is not responding. This is often caused by "
            "severe disk pressure, a stuck Docker VM, or a daemon lock. Free disk space and/or "
            "restart Docker Desktop, then retry."
        ) from exc
    except subprocess.CalledProcessError as exc:
        stderr = (exc.stderr or "").strip()
        stdout = (exc.stdout or "").strip()
        details = "\n".join([line for line in [stdout, stderr] if line])
        raise SystemExit(f"Docker command failed: {' '.join(cmd)}\n{details}") from exc


def _ensure_docker_responsive() -> None:
    _docker_output(
        ["docker", "info", "--format", "{{.ServerVersion}}"],
        timeout=DOCKER_STATUS_TIMEOUT_SECONDS,
    )


def _docker_output_soft(cmd: list[str], *, timeout: float | None = None) -> str | None:
    try:
        return subprocess.run(cmd, check=True, capture_output=True, text=True, timeout=timeout).stdout
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
        return None


def _docker_run(cmd: list[str], *, timeout: float | None = None) -> None:
    try:
        subprocess.run(cmd, check=True, timeout=timeout)
    except subprocess.TimeoutExpired as exc:
        timeout_label = f"{timeout:g}" if timeout is not None else "unknown"
        raise SystemExit(
            f"Docker command timed out after {timeout_label}s: {shlex.join(cmd)}\n"
            "Docker Desktop or the Docker daemon is not responding. Free disk space and/or "
            "restart Docker Desktop, then retry."
        ) from exc
    except subprocess.CalledProcessError as exc:
        raise SystemExit(f"Docker command failed: {' '.join(cmd)} (exit {exc.returncode})") from exc


def _compose_env_from_cmd(cmd: list[str]) -> dict[str, str] | None:
    if "--env-file" not in cmd:
        return None
    idx = cmd.index("--env-file")
    if idx + 1 >= len(cmd):
        return None
    env = os.environ.copy()
    env["COMPOSE_ENV_FILES"] = cmd[idx + 1]
    return env


def _run_compose(console: Console, cmd: list[str], *, cwd: Path) -> None:
    console.print(f"[dim]$ {' '.join(cmd)}[/dim]")
    proc = subprocess.run(cmd, cwd=cwd, env=_compose_env_from_cmd(cmd))
    if proc.returncode != 0:
        raise SystemExit(f"Command failed with exit code {proc.returncode}.")


def _tail_process_text(text: str, *, max_lines: int = 40, max_chars: int = 6000) -> str:
    lines = [line.rstrip() for line in str(text or "").splitlines() if line.rstrip()]
    if max_lines > 0 and len(lines) > max_lines:
        lines = ["... output truncated ...", *lines[-max_lines:]]
    value = "\n".join(lines).strip()
    if max_chars > 0 and len(value) > max_chars:
        return "... output truncated ...\n" + value[-max_chars:]
    return value


def _run_compose_capture(
    console: Console,
    cmd: list[str],
    *,
    cwd: Path,
    label: str,
    verbose: bool = False,
) -> str:
    if verbose:
        console.print(f"[dim]$ {shlex.join(cmd)}[/dim]")
    proc = subprocess.run(
        cmd,
        cwd=cwd,
        env=_compose_env_from_cmd(cmd),
        capture_output=True,
        text=True,
    )
    stdout = (proc.stdout or "").strip()
    stderr = (proc.stderr or "").strip()
    if verbose:
        if stdout:
            console.print(stdout)
        if stderr:
            console.print(stderr)
    if proc.returncode != 0:
        details = _tail_process_text("\n".join([part for part in [stdout, stderr] if part]))
        message = f"{label} failed with exit code {proc.returncode}."
        if details:
            message += f"\n{details}"
        if not verbose:
            message += "\nRerun with --verbose to see the raw docker compose command and full proc output."
        raise SystemExit(message)
    return stdout


def _run_compose_optional(console: Console, cmd: list[str], *, cwd: Path, label: str) -> bool:
    console.print(f"[dim]$ {' '.join(cmd)}[/dim]")
    proc = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, env=_compose_env_from_cmd(cmd))
    if proc.stdout:
        console.print(proc.stdout.strip())
    if proc.stderr:
        console.print(proc.stderr.strip())
    if proc.returncode != 0:
        console.print(f"[yellow]{label} (exit {proc.returncode}).[/yellow]")
        return False
    return True


def _compose_logs_dir_from_env(env_file: Path, fallback_workdir: Path) -> Path:
    try:
        env_main = installer_mod.load_env_file(env_file)
        value = str(env_main.entries.get("KDCUBE_LOGS_DIR", (None, None))[1] or "").strip()
        if value:
            return Path(value).expanduser().resolve()
    except Exception:
        pass
    return fallback_workdir / "logs"


def stop_compose_stack(
    console: Console,
    *,
    repo_root: Path,
    workdir: Path,
    remove_volumes: bool = False,
) -> None:
    ctx = _build_paths_for_repo(repo_root, workdir)
    env_file = ctx.config_dir / ".env"
    if not env_file.exists():
        raise SystemExit(
            f"Compose env file not found: {env_file}. "
            "Pass --workdir for the runtime you want to stop or re-run the installer first."
        )

    _ensure_docker_responsive()
    _check_before_stop(workdir, env_file, ctx.docker_dir)

    cmd = [
        "docker",
        "compose",
        "--env-file",
        str(env_file),
        "down",
        "--remove-orphans",
    ]
    if remove_volumes:
        cmd.append("-v")

    _run_compose(console, cmd, cwd=ctx.docker_dir)
    _clear_cli_lock()
    console.print("[green]Docker compose stopped.[/green]")
    console.print(f"[dim]Workdir:[/dim] {workdir}")
    if not remove_volumes:
        console.print("[dim]Host data under the workdir was preserved.[/dim]")


def start_compose_stack(
    console: Console,
    *,
    repo_root: Path,
    workdir: Path,
    build: bool = False,
) -> None:
    ctx = _build_paths_for_repo(repo_root, workdir)
    env_file = ctx.config_dir / ".env"
    if not env_file.exists():
        raise SystemExit(
            f"Compose env file not found: {env_file}.\n"
            "Initialize the workdir first:\n"
            "  kdcube init"
        )
    _ensure_docker_responsive()
    env_main = installer_mod.load_env_file(env_file)
    installer_mod.ensure_compose_log_dirs(_compose_logs_dir_from_env(env_file, ctx.workdir))
    token_overrides = installer_mod.generate_runtime_tokens()
    runtime_env = installer_mod.write_env_overlay(env_file, token_overrides)
    _tenant, _project = _parse_workdir_namespace(workdir)
    build_flag = ["--build"] if build else []
    try:
        _write_cli_lock(
            tenant=_tenant, project=_project, workdir=workdir,
            docker_dir=ctx.docker_dir, env_file=env_file,
        )
        _run_compose(
            console,
            ["docker", "compose", "--env-file", str(runtime_env), "up", "-d", *build_flag],
            cwd=ctx.docker_dir,
        )
        console.print("[green]Docker compose started.[/green]")
        proxy_http_port = (
            env_main.entries.get("KDCUBE_PROXY_HTTP_PORT", (None, None))[1]
            or env_main.entries.get("KDCUBE_UI_PORT", (None, None))[1]
            or "80"
        )
        routes_prefix = installer_mod.resolve_frontend_routes_prefix(
            env_main.entries.get("PATH_TO_FRONTEND_CONFIG_JSON", (None, None))[1]
        )
        proxy_url = installer_mod.build_ui_url(proxy_http_port, routes_prefix)
        console.print("Open the UI:")
        console.print(f"  [link={proxy_url}]{proxy_url}[/link]")
    finally:
        if runtime_env.exists():
            runtime_env.unlink(missing_ok=True)


def build_compose_images(
    console: Console,
    *,
    repo_root: Path,
    workdir: Path,
) -> None:
    ctx = _build_paths_for_repo(repo_root, workdir)
    env_file = ctx.config_dir / ".env"
    if not env_file.exists():
        raise SystemExit(
            f"Compose env file not found: {env_file}.\n"
            "Initialize the workdir before building images:\n"
            "  kdcube init --build"
        )
    _ensure_docker_responsive()

    env_main = installer_mod.load_env_file(env_file)
    missing = installer_mod.missing_build_keys(env_main)
    if missing:
        details = "\n".join(f"  - {key}" for key in missing)
        raise SystemExit(
            "Cannot build images; missing required build settings in .env:\n"
            f"{details}\n"
            "Fix the staged runtime env or rerun init with a complete descriptor set."
        )

    ui_image_override = env_main.entries.get("KDCUBE_UI_IMAGE", (None, None))[1]
    build_services = [
        "chat-ingress",
        "chat-proc",
        "metrics",
        "web-proxy",
        "postgres-setup",
        "kdcube-secrets",
    ]
    if not (ui_image_override and not installer_mod.is_placeholder(ui_image_override)):
        build_services.append("web-ui")

    _run_compose(
        console,
        ["docker", "compose", "--env-file", str(env_file), "build", *build_services],
        cwd=ctx.docker_dir,
    )
    _run_compose(
        console,
        ["docker", "build", "--progress=plain", "-t", "py-code-exec:latest", "-f", "Dockerfile_Exec", "../../.."],
        cwd=ctx.docker_dir,
    )
    console.print("[green]Docker images built. The stack was not started.[/green]")


def clean_docker_images(console: Console) -> None:
    console.print("[bold]Cleaning Docker cache and unused KDCube images...[/bold]")
    try:
        _ensure_docker_responsive()
        # Remove dangling images + build cache
        _docker_run(["docker", "image", "prune", "-f"], timeout=DOCKER_CLEAN_TIMEOUT_SECONDS)
        _docker_run(["docker", "builder", "prune", "-f"], timeout=DOCKER_CLEAN_TIMEOUT_SECONDS)

        used_refs: set[str] = set()
        out = _docker_output_soft(
            ["docker", "ps", "-a", "--format", "{{.ImageID}}"],
            timeout=DOCKER_STATUS_TIMEOUT_SECONDS,
        )
        if out is None:
            out = _docker_output(
                ["docker", "ps", "-a", "--format", "{{.Image}}"],
                timeout=DOCKER_STATUS_TIMEOUT_SECONDS,
            )
        for line in out.splitlines():
            value = line.strip()
            if value:
                used_refs.add(value)

        images = _docker_output(
            ["docker", "image", "ls", "--no-trunc", "--format", "{{.ID}} {{.Repository}} {{.Tag}}"],
            timeout=DOCKER_STATUS_TIMEOUT_SECONDS,
        ).splitlines()

        to_remove: list[str] = []
        for line in images:
            parts = line.split(" ", 2)
            if len(parts) != 3:
                continue
            image_id, repo, tag = parts
            if tag == "<none>":
                continue
            if repo.startswith("kdcube/"):
                pass
            elif repo in KDCUBE_REPOS or repo.startswith("kdcube-"):
                pass
            else:
                continue
            if image_id in used_refs or f"{repo}:{tag}" in used_refs:
                continue
            to_remove.append(f"{repo}:{tag}")

        if to_remove:
            console.print("[dim]Removing old KDCube image tags:[/dim]")
            for ref in to_remove:
                console.print(f"  {ref}")
            try:
                subprocess.run(["docker", "rmi", *to_remove], check=False, timeout=DOCKER_CLEAN_TIMEOUT_SECONDS)
            except subprocess.TimeoutExpired as exc:
                raise SystemExit(
                    f"Docker command timed out after {DOCKER_CLEAN_TIMEOUT_SECONDS}s: "
                    f"docker rmi <{len(to_remove)} image tags>\n"
                    "Docker Desktop or the Docker daemon is not responding. Free disk space and/or "
                    "restart Docker Desktop, then retry."
                ) from exc
        else:
            console.print("[dim]No old KDCube image tags to remove.[/dim]")
    except FileNotFoundError:
        raise SystemExit("Docker not found. Please install Docker and retry.")
    except subprocess.CalledProcessError as exc:
        raise SystemExit(f"Docker cleanup failed with exit code {exc.returncode}.") from exc


def _build_paths_for_repo(repo_root: Path, workdir: Path) -> installer_mod.PathsContext:
    workdir = _resolve_cli_workdir(workdir)
    ai_app_root = repo_root / "app/ai-app"
    if not (ai_app_root / "deployment/docker/all_in_one_kdcube/docker-compose.yaml").exists():
        raise SystemExit(f"Could not find deployment/docker/all_in_one_kdcube under {ai_app_root}")
    lib_root = ai_app_root / "src/kdcube-ai-app"
    if not (lib_root / "kdcube_ai_app").exists():
        raise SystemExit(f"Could not locate kdcube_ai_app under {lib_root}")
    config_dir = workdir / "config"
    compose_mode = "all-in-one"
    env_main_path = config_dir / ".env"
    if env_main_path.exists():
        env_main = installer_mod.load_env_file(env_main_path)
        compose_mode_raw = env_main.entries.get("KDCUBE_COMPOSE_MODE", (None, None))[1]
        if _strip_env_value(compose_mode_raw) == "custom-ui-managed-infra":
            compose_mode = "custom-ui-managed-infra"
    if compose_mode == "custom-ui-managed-infra":
        docker_dir = ai_app_root / "deployment/docker/custom-ui-managed-infra"
    else:
        docker_dir = ai_app_root / "deployment/docker/all_in_one_kdcube"
    return installer_mod.PathsContext(
        lib_root=lib_root,
        ai_app_root=ai_app_root,
        docker_dir=docker_dir,
        sample_env_dir=docker_dir / "sample_env",
        workdir=workdir,
        config_dir=config_dir,
        data_dir=workdir / "data",
    )


def _runtime_env_exists(workdir: Path) -> bool:
    return (workdir / "config" / ".env").exists()


def _runtime_candidates(base_workdir: Path) -> list[Path]:
    if not base_workdir.exists() or not base_workdir.is_dir():
        return []
    candidates: list[Path] = []
    for child in base_workdir.iterdir():
        if child.is_dir() and _runtime_env_exists(child):
            candidates.append(child.resolve())
    return sorted(candidates)


def _descriptor_context_hint(
    *,
    descriptors_location: Path | None = None,
    assembly_path: Path | None = None,
) -> tuple[str | None, str | None]:
    source: Path | None = None
    if descriptors_location is not None:
        source = descriptors_location / "assembly.yaml"
    elif assembly_path is not None:
        source = assembly_path
    assembly = installer_mod.load_release_descriptor_soft(source)
    return installer_mod.descriptor_context_from_assembly(assembly)


def _resolve_cli_workdir(
    workdir: Path,
    *,
    descriptors_location: Path | None = None,
    assembly_path: Path | None = None,
    tenant: str | None = None,
    project: str | None = None,
) -> Path:
    workdir = workdir.expanduser().resolve()
    if _runtime_env_exists(workdir) or (workdir / "config").exists():
        return workdir

    # Explicit tenant/project take priority over descriptor hints
    if tenant or project:
        return installer_mod.workspace_runtime_dir(workdir, tenant, project).resolve()

    tenant_hint, project_hint = _descriptor_context_hint(
        descriptors_location=descriptors_location,
        assembly_path=assembly_path,
    )
    namespace = installer_mod.workspace_namespace(tenant_hint, project_hint)
    if workdir.name == namespace or "__" in workdir.name:
        return workdir

    if descriptors_location is not None or assembly_path is not None:
        return installer_mod.workspace_runtime_dir(workdir, tenant_hint, project_hint).resolve()

    candidates = _runtime_candidates(workdir)
    if len(candidates) == 1:
        return candidates[0]
    if len(candidates) > 1:
        raise _AmbiguousWorkdirError(workdir, candidates)
    return installer_mod.workspace_runtime_dir(workdir, tenant_hint, project_hint).resolve()


def _is_git_repo(path: Path) -> bool:
    return installer_mod.is_git_repo(path)


def _is_platform_source_tree(path: Path) -> bool:
    return (
        path.exists()
        and (path / "app" / "ai-app").is_dir()
        and (path / "app" / "ai-app" / "deployment").is_dir()
    )


def _default_repo_path_for_workdir(workdir: Path) -> Path:
    return workdir / DEFAULT_REPO_DIRNAME


def _read_install_meta_raw(workdir: Path) -> dict | None:
    meta_path = workdir / "config" / "install-meta.json"
    if not meta_path.exists():
        return None
    try:
        return json.loads(meta_path.read_text())
    except Exception:
        return None


def _resolve_namespaced_runtime_target(
    *,
    workdir_arg: str,
    workdir_base_arg: str,
    tenant_arg: str,
    project_arg: str,
    cli_defaults: dict,
    prefer_existing: bool = False,
) -> tuple[Path, str, str]:
    """Resolve the fully-qualified namespaced runtime path for ``init`` /
    ``refresh``.

    Returns ``(resolved_runtime_path, tenant, project)``. Raises
    ``SystemExit`` with a clear message on bad flag combinations.

    Resolution precedence (each flag has exactly one meaning):

    1. ``--workdir <full>``: use as the namespaced runtime path. The trailing
       segment must contain ``__``. If ``--tenant`` / ``--project`` are also
       given they must match the trailing segment.
    2. ``--workdir-base <B> --tenant T --project P``: compose under ``<B>``.
       Mutually exclusive with ``--workdir``.
    3. ``--tenant T --project P`` (no --workdir / --workdir-base): compose
       under ``$DEFAULT_WORKDIR`` (the platform-wide default base
       ``~/.kdcube/kdcube-runtime``).
    4. ``cli_defaults["default_workdir"]`` (must be a full namespaced path):
       use as the namespaced runtime path.

    No other resolution path is considered. ``cli_defaults["default_workdir"]``
    is **never** treated as a base; use the bare ``--tenant``/``--project``
    form for that.

    Naming convention when composing from ``--tenant`` / ``--project``:

    - The directory is named **literally** ``<tenant>__<project>`` (preserves
      hyphens, dots, mixed case — anything filesystem-safe). This matches the
      tenant/project the user typed.
    - If ``prefer_existing=True`` (used by ``refresh``) and the literal path
      is not an initialized runtime, the resolver also tries the
      ``safe_workspace_name``-normalized form (``demo-tenant`` →
      ``demo_tenant``) for backward compatibility with older workdirs created
      via that path. The literal form wins if both are initialized.
    """
    workdir_arg = (workdir_arg or "").strip()
    workdir_base_arg = (workdir_base_arg or "").strip()
    tenant_arg = (tenant_arg or "").strip()
    project_arg = (project_arg or "").strip()

    if workdir_arg and workdir_base_arg:
        raise SystemExit(
            "Choose either --workdir <full-path> OR --workdir-base <base> + "
            "--tenant + --project. They are mutually exclusive."
        )

    def _compose_namespaced(base: Path, t: str, p: str) -> Path:
        """Primary form: literal `<base>/<tenant>__<project>`."""
        return (base / f"{t}__{p}").resolve()

    def _compose_namespaced_safe(base: Path, t: str, p: str) -> Path:
        """Fallback form: safe-normalized via workspace_runtime_dir."""
        return installer_mod.workspace_runtime_dir(base, t, p).resolve()

    def _pick_target(base: Path, t: str, p: str) -> Path:
        """Return the namespaced runtime path. If ``prefer_existing`` is set
        and the literal form is not an initialized runtime, fall back to the
        safe-normalized form when *that* one is initialized.
        """
        literal = _compose_namespaced(base, t, p)
        if not prefer_existing:
            return literal
        if _read_install_meta_raw(literal) is not None:
            return literal
        safe = _compose_namespaced_safe(base, t, p)
        if safe != literal and _read_install_meta_raw(safe) is not None:
            return safe
        return literal

    # Shape 2: --workdir-base + tenant + project
    if workdir_base_arg:
        if not (tenant_arg and project_arg):
            raise SystemExit(
                "--workdir-base requires both --tenant and --project to compose "
                "the namespaced runtime path."
            )
        base = Path(os.path.expanduser(workdir_base_arg)).resolve()
        return _pick_target(base, tenant_arg, project_arg), tenant_arg, project_arg

    # Shape 1: --workdir <full>
    if workdir_arg:
        resolved = Path(os.path.expanduser(workdir_arg)).resolve()
        name = resolved.name
        if "__" not in name:
            raise SystemExit(
                f"--workdir must be a fully-qualified namespaced runtime "
                f"(its name must contain '__'): {resolved}\n"
                "Either pass `--workdir <base>/<tenant>__<project>` directly, "
                "use `--workdir-base <base> --tenant T --project P` to have the "
                "CLI compose the namespaced path, or pass `--tenant T --project P` "
                "alone to compose under the platform default base "
                f"({DEFAULT_WORKDIR})."
            )
        ns_t, ns_p = name.split("__", 1)
        if tenant_arg and tenant_arg != ns_t:
            raise SystemExit(
                f"--tenant '{tenant_arg}' disagrees with the trailing segment "
                f"of --workdir ('{ns_t}__{ns_p}'). Either remove --tenant or use "
                "--workdir-base + --tenant + --project."
            )
        if project_arg and project_arg != ns_p:
            raise SystemExit(
                f"--project '{project_arg}' disagrees with the trailing segment "
                f"of --workdir ('{ns_t}__{ns_p}'). Either remove --project or use "
                "--workdir-base + --tenant + --project."
            )
        return resolved, ns_t, ns_p

    # Shape 3: bare --tenant + --project, default base.
    if tenant_arg and project_arg:
        base = Path(DEFAULT_WORKDIR).expanduser().resolve()
        return _pick_target(base, tenant_arg, project_arg), tenant_arg, project_arg

    # Shape 4: cli_defaults["default_workdir"] (must be fully-qualified).
    default_workdir = str(cli_defaults.get("default_workdir", "") or "").strip()
    if default_workdir:
        resolved = Path(os.path.expanduser(default_workdir)).resolve()
        name = resolved.name
        if "__" not in name:
            raise SystemExit(
                f"cli_defaults.default_workdir is not a fully-qualified namespaced "
                f"runtime (its name must contain '__'): {resolved}\n"
                "Either reset it with `kdcube defaults --default-workdir <full-path>`, "
                "or invoke this command with --tenant T --project P to compose under "
                f"the platform default base ({DEFAULT_WORKDIR})."
            )
        ns_t, ns_p = name.split("__", 1)
        return resolved, ns_t, ns_p

    raise SystemExit(
        "No target workdir specified.\n"
        "Pass one of:\n"
        "  --tenant T --project P                            # primary form; "
        f"composes under {DEFAULT_WORKDIR}\n"
        "  --workdir-base <base> --tenant T --project P      # compose under <base>\n"
        "  --workdir <full-path>                             # explicit namespaced runtime\n"
        "or configure cli_defaults via:\n"
        "  kdcube defaults --default-workdir <full-path>"
    )


def _repo_path_from_install_meta(workdir: Path) -> Path | None:
    meta = _read_install_meta_raw(workdir)
    if not isinstance(meta, dict):
        return None
    raw = str(meta.get("repo_root") or "").strip()
    if not raw:
        return None
    path = Path(raw).expanduser().resolve()
    return path if (_is_git_repo(path) or _is_platform_source_tree(path)) else None


def _canonical_descriptor_dir_from_initialized_workdir(workdir: Path) -> Path | None:
    try:
        concrete_workdir = _resolve_cli_workdir(workdir)
    except _AmbiguousWorkdirError:
        return None
    config_dir = (concrete_workdir / "config").resolve()
    if not config_dir.exists():
        return None
    meta = _read_install_meta_raw(concrete_workdir)
    if not isinstance(meta, dict):
        return None
    missing = [
        name
        for name in installer_mod.CANONICAL_DESCRIPTOR_FILENAMES
        if not (config_dir / name).exists()
    ]
    if missing:
        return None
    return config_dir


def _resolve_cli_repo_path(
    repo_path: Path,
    *,
    workdir: Path,
    path_provided: bool,
    descriptors_location: Path | None = None,
    assembly_path: Path | None = None,
) -> Path:
    if path_provided:
        return repo_path.expanduser().resolve()

    concrete_workdir = _resolve_cli_workdir(
        workdir,
        descriptors_location=descriptors_location,
        assembly_path=assembly_path,
    )

    meta_repo = _repo_path_from_install_meta(concrete_workdir)
    if meta_repo is not None:
        return meta_repo

    if descriptors_location is not None or assembly_path is not None:
        return _default_repo_path_for_workdir(concrete_workdir).resolve()

    return repo_path.expanduser().resolve()


def _ensure_secrets_service_available(docker_dir: Path) -> None:
    compose_path = docker_dir / "docker-compose.yaml"
    if not compose_path.exists():
        raise SystemExit(f"Compose file not found: {compose_path}")
    try:
        content = compose_path.read_text()
    except Exception as exc:
        raise SystemExit(f"Failed to read compose file: {compose_path}") from exc
    if "kdcube-secrets:" not in content:
        raise SystemExit(
            "Compose file does not include kdcube-secrets. "
            "Update your repo (or pass --path to a newer checkout) and retry."
        )


def _compose_services(docker_dir: Path, env_file: Path) -> set[str]:
    try:
        env = os.environ.copy()
        env["COMPOSE_ENV_FILES"] = str(env_file)
        output = _docker_output(
            [
                "docker",
                "compose",
                "--env-file",
                str(env_file),
                "config",
                "--services",
            ],
            env=env,
            cwd=docker_dir,
            timeout=DOCKER_STATUS_TIMEOUT_SECONDS,
        )
        return {line.strip() for line in output.splitlines() if line.strip()}
    except SystemExit:
        return set()


def _compose_running_services(docker_dir: Path, env_file: Path, *, strict: bool = False) -> set[str]:
    try:
        env = os.environ.copy()
        env["COMPOSE_ENV_FILES"] = str(env_file)
        output = _docker_output(
            [
                "docker",
                "compose",
                "--env-file",
                str(env_file),
                "ps",
                "--services",
                "--filter",
                "status=running",
            ],
            env=env,
            cwd=docker_dir,
            timeout=DOCKER_STATUS_TIMEOUT_SECONDS,
        )
        return {line.strip() for line in output.splitlines() if line.strip()}
    except SystemExit:
        if strict:
            raise
        return set()


def _strip_env_value(raw: str | None) -> str:
    value = (raw or "").strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
        value = value[1:-1]
    return value.strip()


def _runtime_env_value(workdir: Path, name: str) -> str | None:
    env_path = workdir / "config" / ".env"
    if not env_path.exists():
        return None
    try:
        env_main = installer_mod.load_env_file(env_path)
    except Exception:
        return None
    raw = env_main.entries.get(name, (None, None))[1]
    value = _strip_env_value(raw)
    return value or None


def _runtime_config_dir(env_main: installer_mod.EnvFile) -> Path:
    return env_main.path.parent.resolve()


def _resolve_bundle_reload_source(env_main: installer_mod.EnvFile, env_proc: installer_mod.EnvFile) -> Path:
    del env_proc

    bundles_path = _runtime_config_dir(env_main) / "bundles.yaml"
    if bundles_path.exists():
        return bundles_path.resolve()

    raise SystemExit(
        f"No bundles.yaml found under the runtime config directory: {_runtime_config_dir(env_main)}"
    )


def _resolve_live_bundle_export_sources(
    env_main: installer_mod.EnvFile,
    env_proc: installer_mod.EnvFile,
) -> tuple[Path, Path | None] | None:
    del env_proc

    config_dir = _runtime_config_dir(env_main)
    bundles_path = (config_dir / "bundles.yaml").resolve()
    if not bundles_path.exists():
        return None

    bundles_secrets_path = (config_dir / "bundles.secrets.yaml").resolve()
    return bundles_path, bundles_secrets_path if bundles_secrets_path.exists() else None


def _collect_runtime_info(*, repo_root: Path, workdir: Path) -> dict[str, object]:
    ctx = _build_paths_for_repo(repo_root, workdir)
    env_main_path = ctx.config_dir / ".env"
    env_main = installer_mod.load_env_file(env_main_path) if env_main_path.exists() else None
    assembly_path = ctx.config_dir / "assembly.yaml"
    assembly = installer_mod.load_release_descriptor_soft(assembly_path)
    bundles_path = ctx.config_dir / "bundles.yaml"
    bundles_data = installer_mod.load_release_descriptor_soft(bundles_path)
    bundles = bundles_data.get("bundles") if isinstance(bundles_data, dict) and "bundles" in bundles_data else bundles_data
    bundle_items = []
    default_bundle_id = None
    if isinstance(bundles, dict):
        default_bundle_id = bundles.get("default_bundle_id")
        items = bundles.get("items")
        if isinstance(items, list):
            bundle_items = [item for item in items if isinstance(item, dict)]
        else:
            for key, value in bundles.items():
                if key in {"version", "default_bundle_id"}:
                    continue
                if isinstance(value, dict):
                    spec = dict(value)
                    spec.setdefault("id", str(key))
                    bundle_items.append(spec)
    install_meta = _read_install_meta_raw(ctx.workdir) or {}
    env_entries = env_main.entries if env_main is not None else {}

    def _env_value(name: str) -> str | None:
        raw = env_entries.get(name, (None, None))[1] if env_entries else None
        value = _strip_env_value(raw)
        return value or None

    return {
        "workdir": str(ctx.workdir),
        "config_dir": str(ctx.config_dir),
        "data_dir": str(ctx.data_dir),
        "logs_dir": _env_value("KDCUBE_LOGS_DIR") or str(ctx.workdir / "logs"),
        "docker_dir": str(ctx.docker_dir),
        "repo_root": str(repo_root),
        "install_meta": install_meta,
        "assembly_path": str(assembly_path) if assembly_path.exists() else None,
        "bundles_path": str(bundles_path) if bundles_path.exists() else None,
        "default_bundle_id": default_bundle_id,
        "bundle_count": len(bundle_items),
        "host_bundles_path": _env_value("HOST_BUNDLES_PATH"),
        "container_bundles_root": _env_value("BUNDLES_ROOT"),
        "host_managed_bundles_path": _env_value("HOST_MANAGED_BUNDLES_PATH"),
        "container_managed_bundles_root": _env_value("MANAGED_BUNDLES_ROOT"),
        "host_bundle_storage_path": _env_value("HOST_BUNDLE_STORAGE_PATH"),
        "container_bundle_storage_root": _env_value("BUNDLE_STORAGE_ROOT"),
        "host_exec_workspace_path": _env_value("HOST_EXEC_WORKSPACE_PATH"),
        "container_exec_workspace_root": _env_value("EXEC_WORKSPACE_ROOT"),
        "host_react_debug_path": _env_value("HOST_REACT_DEBUG_PATH"),
        "container_react_debug_root": _env_value("REACT_DEBUG_ROOT"),
        "compose_mode": _env_value("KDCUBE_COMPOSE_MODE"),
        "tenant": _get_nested(assembly, "context", "tenant"),
        "project": _get_nested(assembly, "context", "project"),
    }


def print_runtime_info(console: Console, *, repo_root: Path, workdir: Path) -> None:
    info = _collect_runtime_info(repo_root=repo_root, workdir=workdir)

    console.print("[bold]KDCube Runtime Info[/bold]")
    console.print(f"[dim]Workdir:[/dim] {info['workdir']}")
    console.print(f"[dim]Config dir:[/dim] {info['config_dir']}")
    console.print(f"[dim]Data dir:[/dim] {info['data_dir']}")
    console.print(f"[dim]Logs dir:[/dim] {info['logs_dir']}")
    console.print(f"[dim]Docker dir:[/dim] {info['docker_dir']}")
    console.print(f"[dim]Repo root:[/dim] {info['repo_root']}")

    install_meta = info["install_meta"] if isinstance(info["install_meta"], dict) else {}
    if install_meta:
        console.print(f"[dim]Install mode:[/dim] {install_meta.get('install_mode') or 'unknown'}")
        console.print(f"[dim]Platform ref:[/dim] {install_meta.get('platform_ref') or 'unknown'}")

    console.print(f"[dim]Tenant / project:[/dim] {info['tenant'] or 'unknown'} / {info['project'] or 'unknown'}")
    console.print(f"[dim]Compose mode:[/dim] {info['compose_mode'] or 'unknown'}")
    console.print(f"[dim]Assembly descriptor:[/dim] {info['assembly_path'] or 'missing'}")
    console.print(f"[dim]Bundles descriptor:[/dim] {info['bundles_path'] or 'missing'}")
    console.print(
        f"[dim]Bundle registry snapshot:[/dim] default={info['default_bundle_id'] or '<none>'}, "
        f"items={info['bundle_count']}"
    )

    console.print("\n[bold]Bundle Mounts[/bold]")
    console.print(f"[dim]Host config:[/dim] {info['config_dir']}")
    console.print("[dim]Container config root:[/dim] /config")
    console.print(f"[dim]Host non-managed bundles:[/dim] {info['host_bundles_path'] or 'unset'}")
    console.print(f"[dim]Container non-managed bundles root:[/dim] {info['container_bundles_root'] or 'unset'}")
    console.print(f"[dim]Host managed bundles:[/dim] {info['host_managed_bundles_path'] or 'unset'}")
    console.print(f"[dim]Container managed bundles root:[/dim] {info['container_managed_bundles_root'] or 'unset'}")
    console.print(f"[dim]Host bundle storage:[/dim] {info['host_bundle_storage_path'] or 'unset'}")
    console.print(f"[dim]Container bundle storage root:[/dim] {info['container_bundle_storage_root'] or 'unset'}")
    console.print(f"[dim]Host exec workspace:[/dim] {info['host_exec_workspace_path'] or 'unset'}")
    console.print(f"[dim]Container exec workspace root:[/dim] {info['container_exec_workspace_root'] or 'unset'}")
    console.print(f"[dim]Host React debug:[/dim] {info['host_react_debug_path'] or 'unset'}")
    console.print(f"[dim]Container React debug root:[/dim] {info['container_react_debug_root'] or 'unset'}")
    console.print(f"[dim]Host logs:[/dim] {info['logs_dir'] or 'unset'}")
    console.print("[dim]Container logs root:[/dim] /logs")

    host_bundles_path = str(info["host_bundles_path"] or "").strip()
    container_bundles_root = str(info["container_bundles_root"] or "").strip()
    if host_bundles_path and container_bundles_root:
        console.print("\n[bold]Non-git Bundle Path Rule[/bold]")
        console.print(
            "A non-managed local-path bundle host path must live under the host non-managed bundles root. "
            "In bundles.yaml, use the matching container path under the container non-managed bundles root."
        )
        console.print(f"[dim]Example mapping:[/dim] {host_bundles_path}/my.bundle -> {container_bundles_root}/my.bundle")

    host_managed_bundles_path = str(info["host_managed_bundles_path"] or "").strip()
    container_managed_bundles_root = str(info["container_managed_bundles_root"] or "").strip()
    if host_managed_bundles_path and container_managed_bundles_root:
        console.print("\n[bold]Managed Bundle Path Rule[/bold]")
        console.print(
            "Platform-managed bundles are materialized under the managed bundles root. "
            "This includes git-resolved bundles and built-in example bundles."
        )
        console.print(
            f"[dim]Example mapping:[/dim] {host_managed_bundles_path}/repo__bundle.demo__main "
            f"-> {container_managed_bundles_root}/repo__bundle.demo__main"
        )


def print_cli_defaults(console: Console, cli_defaults: dict) -> None:
    has_defaults = bool(cli_defaults)
    if not has_defaults:
        console.print("[dim]No defaults configured.[/dim]")
        console.print(
            "  Set defaults with: kdcube defaults --default-workdir <path> "
            "--default-tenant <t> --default-project <p>"
        )
    else:
        console.print(f"[dim]Default workdir:[/dim]  {cli_defaults.get('default_workdir') or '[not set]'}")
        console.print(f"[dim]Default tenant:[/dim]   {cli_defaults.get('default_tenant') or '[not set]'}")
        console.print(f"[dim]Default project:[/dim]  {cli_defaults.get('default_project') or '[not set]'}")


def _collect_running_deployment_info() -> dict[str, object]:
    lock = _read_cli_lock()
    if lock is None:
        return {"recorded": False, "running": False}
    running = _lock_running_services(lock)
    stale = not bool(running)
    return {
        "recorded": True,
        "running": bool(running),
        "stale": stale,
        "tenant": lock.get("tenant"),
        "project": lock.get("project"),
        "workdir": lock.get("workdir"),
        "services": sorted(running),
    }


def print_running_deployment_info(console: Console) -> None:
    lock = _read_cli_lock()
    if lock is None:
        console.print("[dim]No running deployment recorded.[/dim]")
        return
    running = _lock_running_services(lock)
    if running:
        console.print("[bold]Currently Running Deployment[/bold]")
        console.print(f"  [dim]Tenant / project:[/dim] {lock.get('tenant') or '?'} / {lock.get('project') or '?'}")
        console.print(f"  [dim]Workdir:[/dim]          {lock.get('workdir') or '?'}")
        console.print(f"  [dim]Services:[/dim]         {', '.join(sorted(running))}")
    else:
        console.print("[yellow]Stale lock found (recorded deployment is not running).[/yellow]")
        console.print(f"  Tenant / project: {lock.get('tenant') or '?'} / {lock.get('project') or '?'}")
        console.print(f"  Workdir: {lock.get('workdir') or '?'}")
        _clear_cli_lock()
        console.print("[dim]Stale lock cleared.[/dim]")


def print_global_info(console: Console, cli_defaults: dict) -> None:
    console.print("[bold]KDCube Global Info[/bold]")
    print_cli_defaults(console, cli_defaults)
    console.print()
    print_running_deployment_info(console)


def _load_bundle_ids_from_descriptor(path: Path) -> set[str]:
    if not path.exists():
        raise SystemExit(f"Bundle descriptor source not found: {path}")

    text = path.read_text()
    suffix = path.suffix.lower()
    if suffix in {".yaml", ".yml"}:
        data = yaml.safe_load(text) or {}
    else:
        data = json.loads(text)

    if not isinstance(data, dict):
        raise SystemExit(f"Unsupported bundle descriptor format in {path}")

    raw_bundles = data.get("bundles") if "bundles" in data else data
    if isinstance(raw_bundles, dict):
        items = raw_bundles.get("items")
        if isinstance(items, list):
            bundle_ids = {
                str(item.get("id"))
                for item in items
                if isinstance(item, dict) and item.get("id")
            }
            if bundle_ids:
                return bundle_ids
        return {str(key) for key in raw_bundles.keys() if key not in {"items", "version", "default_bundle_id"}}

    if isinstance(raw_bundles, list):
        bundle_ids = {
            str(item.get("id"))
            for item in raw_bundles
            if isinstance(item, dict) and item.get("id")
        }
        if bundle_ids:
            return bundle_ids

    raise SystemExit(f"Descriptor {path} does not contain supported bundle declarations")


def _bundle_runtime_roots(workdir: Path) -> tuple[Path | None, str]:
    config_dir = workdir / "config"
    assembly_path = config_dir / "assembly.yaml"
    assembly = installer_mod.load_release_descriptor_soft(assembly_path)

    host_root_raw = _get_nested(assembly, "paths", "host_bundles_path")
    if not isinstance(host_root_raw, str) or not host_root_raw.strip():
        host_root_raw = _runtime_env_value(workdir, "HOST_BUNDLES_PATH")
    host_root: Path | None = None
    if isinstance(host_root_raw, str) and host_root_raw.strip():
        host_root = Path(host_root_raw).expanduser().resolve()

    container_root_raw = _get_nested(
        assembly,
        "platform",
        "services",
        "proc",
        "bundles",
        "bundles_root",
    )
    if not isinstance(container_root_raw, str) or not container_root_raw.strip():
        container_root_raw = _runtime_env_value(workdir, "BUNDLES_ROOT")
    container_root = str(container_root_raw or "/bundles").strip() or "/bundles"
    if not container_root.startswith("/"):
        container_root = "/" + container_root
    return host_root, container_root.rstrip("/") or "/"


def _is_container_visible_path(raw_path: str, container_root: str) -> bool:
    normalized = posixpath.normpath(raw_path.strip().replace("\\", "/"))
    root = posixpath.normpath(container_root.rstrip("/") or "/")
    return normalized == root or normalized.startswith(root + "/")


def _resolve_bundle_local_path_for_runtime(raw_path: str, workdir: Path) -> tuple[str, str]:
    value = str(raw_path or "").strip()
    if not value:
        raise SystemExit("--local-path cannot be empty.")

    host_root, container_root = _bundle_runtime_roots(workdir)
    if _is_container_visible_path(value, container_root):
        return posixpath.normpath(value.replace("\\", "/")), "container"

    candidate = Path(value).expanduser().resolve()
    if not candidate.exists():
        raise SystemExit(f"Bundle local path does not exist on the host: {candidate}")
    if not candidate.is_dir():
        raise SystemExit(f"Bundle local path must be a directory: {candidate}")
    if host_root is None:
        raise SystemExit(
            "Cannot translate host bundle path because the initialized runtime does not define "
            "paths.host_bundles_path or HOST_BUNDLES_PATH."
        )
    try:
        rel = candidate.relative_to(host_root)
    except ValueError as exc:
        raise SystemExit(
            "Bundle local path is not visible inside chat-proc.\n"
            f"  host path: {candidate}\n"
            f"  allowed host bundle root: {host_root}\n"
            f"  runtime bundle root: {container_root}\n"
            "Move or symlink the bundle under the host bundle root, pass the already "
            f"container-visible path under {container_root}, or use --git-repo."
        ) from exc

    return posixpath.join(container_root, rel.as_posix()), "translated"


def _bundle_apply_command(bundle_id: str, workdir: Path) -> str:
    return f"kdcube bundle reload {shlex.quote(bundle_id)} --workdir {shlex.quote(str(workdir))}"


def _print_bundle_apply_hint(console: Console, bundle_id: str, workdir: Path) -> None:
    console.print("[dim]Apply with:[/dim]")
    console.print(f"  {_bundle_apply_command(bundle_id, workdir)}")


def _bundle_items_from_descriptor(data: object) -> tuple[list[dict[str, object]], str | None]:
    if not isinstance(data, dict):
        return [], None
    raw_bundles = data.get("bundles")
    if isinstance(raw_bundles, dict):
        default_id = raw_bundles.get("default_bundle_id")
        raw_items = raw_bundles.get("items")
        if isinstance(raw_items, list):
            return [item for item in raw_items if isinstance(item, dict)], str(default_id or "").strip() or None
        items = []
        for key, value in raw_bundles.items():
            if key in {"items", "version", "default_bundle_id"} or not isinstance(value, dict):
                continue
            entry = dict(value)
            entry.setdefault("id", key)
            items.append(entry)
        return items, str(default_id or "").strip() or None
    if isinstance(raw_bundles, list):
        return [item for item in raw_bundles if isinstance(item, dict)], None
    return [], None


def _bundle_items_by_id(data: object) -> dict[str, dict[str, object]]:
    items, _default_id = _bundle_items_from_descriptor(data)
    result: dict[str, dict[str, object]] = {}
    for item in items:
        bundle_id = str(item.get("id", "") or "").strip()
        if bundle_id:
            result[bundle_id] = item
    return result


def _bundle_descriptor_default_id(data: object) -> str | None:
    _items, default_id = _bundle_items_from_descriptor(data)
    return default_id


def _canonical_descriptor_json(value: object) -> str:
    return json.dumps(value, sort_keys=True, ensure_ascii=False, default=str, separators=(",", ":"))


def _changed_bundle_ids_between_descriptors(current: object, incoming: object) -> tuple[list[str], list[str]]:
    current_items = _bundle_items_by_id(current)
    incoming_items = _bundle_items_by_id(incoming)
    changed: set[str] = set()
    removed: set[str] = set()

    for bundle_id, incoming_item in incoming_items.items():
        current_item = current_items.get(bundle_id)
        if current_item is None or _canonical_descriptor_json(current_item) != _canonical_descriptor_json(incoming_item):
            changed.add(bundle_id)

    for bundle_id in current_items:
        if bundle_id not in incoming_items:
            removed.add(bundle_id)

    if _bundle_descriptor_default_id(current) != _bundle_descriptor_default_id(incoming):
        changed.update(incoming_items.keys())

    return sorted(changed), sorted(removed)


def _descriptor_objects_differ(current: object, incoming: object) -> bool:
    return _canonical_descriptor_json(current) != _canonical_descriptor_json(incoming)


def _normalize_bundle_descriptor_paths_for_runtime(data: object, workdir: Path) -> list[dict[str, str]]:
    translations: list[dict[str, str]] = []
    if not isinstance(data, dict):
        return translations
    items, _default_id = _bundle_items_from_descriptor(data)
    for item in items:
        if not isinstance(item, dict):
            continue
        if item.get("repo"):
            continue
        raw_path = str(item.get("path") or "").strip()
        if not raw_path:
            continue
        runtime_path, mode = _resolve_bundle_local_path_for_runtime(raw_path, workdir)
        if runtime_path != raw_path:
            item["path"] = runtime_path
            translations.append(
                {
                    "bundle_id": str(item.get("id") or ""),
                    "source_path": raw_path,
                    "runtime_path": runtime_path,
                    "mode": mode,
                }
            )
    return translations


def apply_bundle_config_descriptors(
    console: Console,
    *,
    workdir: Path,
    descriptors_location: Path,
    dry_run: bool = False,
    reload_changed: bool = False,
    repo_root: Path | None = None,
    verbose: bool = False,
    quiet: bool = False,
) -> dict[str, object]:
    """Stage bundle content descriptors into an initialized runtime.

    This intentionally operates only on bundles.yaml and bundles.secrets.yaml.
    Platform descriptors remain owned by init/refresh.
    """
    config_dir = _canonical_descriptor_dir_from_initialized_workdir(workdir)
    if config_dir is None:
        raise SystemExit(
            f"Workdir is not initialized: {workdir}\n"
            "`kdcube bundle config apply` only operates on an existing runtime created by `kdcube init`."
        )

    source_dir = Path(descriptors_location).expanduser().resolve()
    if not source_dir.exists() or not source_dir.is_dir():
        raise SystemExit(f"Descriptor directory not found: {source_dir}")

    source_bundles_path = source_dir / "bundles.yaml"
    source_bundles_secrets_path = source_dir / "bundles.secrets.yaml"
    target_bundles_path = config_dir / "bundles.yaml"
    target_bundles_secrets_path = config_dir / "bundles.secrets.yaml"

    if not source_bundles_path.exists():
        raise SystemExit(f"bundles.yaml not found under {source_dir}")

    incoming_bundles = installer_mod.load_release_descriptor(source_bundles_path)
    path_translations = _normalize_bundle_descriptor_paths_for_runtime(incoming_bundles, workdir)
    current_bundles = (
        installer_mod.load_release_descriptor(target_bundles_path)
        if target_bundles_path.exists()
        else {"bundles": {"version": "1", "items": []}}
    )
    changed_bundle_ids, removed_bundle_ids = _changed_bundle_ids_between_descriptors(
        current_bundles,
        incoming_bundles,
    )

    files: list[dict[str, object]] = []
    bundles_changed = _descriptor_objects_differ(current_bundles, incoming_bundles)
    files.append(
        {
            "name": "bundles.yaml",
            "source": str(source_bundles_path),
            "target": str(target_bundles_path),
            "changed": bundles_changed,
            "path_translations": path_translations,
        }
    )

    secrets_changed_bundle_ids: list[str] = []
    secrets_removed_bundle_ids: list[str] = []
    secrets_will_apply = source_bundles_secrets_path.exists()
    if secrets_will_apply:
        incoming_secrets = installer_mod.load_release_descriptor(source_bundles_secrets_path)
        current_secrets = (
            installer_mod.load_release_descriptor(target_bundles_secrets_path)
            if target_bundles_secrets_path.exists()
            else {"bundles": {"version": "1", "items": []}}
        )
        secrets_changed_bundle_ids, secrets_removed_bundle_ids = _changed_bundle_ids_between_descriptors(
            current_secrets,
            incoming_secrets,
        )
        secrets_changed = _descriptor_objects_differ(current_secrets, incoming_secrets)
        files.append(
            {
                "name": "bundles.secrets.yaml",
                "source": str(source_bundles_secrets_path),
                "target": str(target_bundles_secrets_path),
                "changed": secrets_changed,
            }
        )
    else:
        files.append(
            {
                "name": "bundles.secrets.yaml",
                "source": str(source_bundles_secrets_path),
                "target": str(target_bundles_secrets_path),
                "changed": False,
                "skipped": True,
                "reason": "source file is absent; runtime secrets descriptor is preserved",
            }
        )

    declared_bundle_ids = set(_bundle_items_by_id(incoming_bundles).keys())
    secret_only_changed_ids = sorted(set(secrets_changed_bundle_ids).difference(declared_bundle_ids))
    reload_bundle_ids = sorted(
        set(changed_bundle_ids).union(
            bundle_id for bundle_id in secrets_changed_bundle_ids if bundle_id in declared_bundle_ids
        )
    )
    removed_ids = sorted(set(removed_bundle_ids).union(secrets_removed_bundle_ids))

    if dry_run:
        if not quiet:
            console.print("[yellow]Dry run: bundle content descriptors were not modified.[/yellow]")
    else:
        installer_mod.save_release_descriptor(target_bundles_path, incoming_bundles)
        if secrets_will_apply:
            shutil.copyfile(source_bundles_secrets_path, target_bundles_secrets_path)
        if not quiet:
            console.print(f"[green]Applied bundle content descriptors:[/green] {source_dir}")

    if not quiet:
        for item in files:
            status = "skipped" if item.get("skipped") else ("changed" if item.get("changed") else "unchanged")
            console.print(f"[dim]{item['name']}:[/dim] {status}")
            if item.get("skipped") and item.get("reason"):
                console.print(f"[dim]  {item['reason']}[/dim]")
            translations = item.get("path_translations")
            if isinstance(translations, list):
                for translation in translations:
                    if not isinstance(translation, dict):
                        continue
                    console.print(
                        f"[dim]  path[/dim] {translation.get('bundle_id')}: "
                        f"{translation.get('source_path')} -> {translation.get('runtime_path')}"
                    )
        if reload_bundle_ids:
            verb = "would reload" if dry_run and reload_changed else "reload candidates"
            console.print(f"[dim]{verb}:[/dim] {', '.join(reload_bundle_ids)}")
        if removed_ids:
            console.print(
                "[yellow]Removed bundle ids are not reloaded because they are no longer declared:[/yellow] "
                + ", ".join(removed_ids)
            )
        if secret_only_changed_ids:
            console.print(
                "[yellow]Secret-only bundle ids are not reloaded because they are not declared in bundles.yaml:[/yellow] "
                + ", ".join(secret_only_changed_ids)
            )

    reload_results: list[dict[str, object]] = []
    if reload_changed and reload_bundle_ids and not dry_run:
        if repo_root is None:
            raise SystemExit("repo_root is required when reload_changed=True")
        for bundle_id in reload_bundle_ids:
            result = reload_bundle_from_descriptor(
                console,
                repo_root=repo_root,
                workdir=workdir,
                bundle_id=bundle_id,
                verbose=verbose,
                json_output=False,
                quiet=quiet,
            )
            reload_results.append({"bundle_id": bundle_id, "result": result})

    return {
        "status": "dry-run" if dry_run else "ok",
        "source_dir": str(source_dir),
        "target_dir": str(config_dir),
        "files": files,
        "changed_bundle_ids": reload_bundle_ids,
        "removed_bundle_ids": removed_ids,
        "secret_only_changed_bundle_ids": secret_only_changed_ids,
        "reloaded": reload_results,
    }


def _find_bundle_item(data: object, bundle_id: str) -> tuple[dict[str, object] | None, str | None]:
    items, default_id = _bundle_items_from_descriptor(data)
    for item in items:
        if str(item.get("id") or "").strip() == bundle_id:
            return item, default_id
    return None, default_id


def _host_path_for_runtime_bundle_path(runtime_path: str, workdir: Path) -> str | None:
    value = str(runtime_path or "").strip()
    if not value:
        return None
    host_root, container_root = _bundle_runtime_roots(workdir)
    if host_root is None or not _is_container_visible_path(value, container_root):
        return None
    normalized = posixpath.normpath(value.replace("\\", "/"))
    root = posixpath.normpath(container_root.rstrip("/") or "/")
    if normalized == root:
        return str(host_root)
    rel = normalized[len(root):].lstrip("/")
    if not rel:
        return str(host_root)
    return str(host_root.joinpath(*rel.split("/")))


def _source_summary(entry: dict[str, object] | None) -> dict[str, object]:
    if not entry:
        return {"mode": "missing"}
    if entry.get("repo"):
        return {
            "mode": "git",
            "repo": entry.get("repo"),
            "ref": entry.get("ref"),
            "subdir": entry.get("subdir"),
            "path": entry.get("path"),
        }
    return {
        "mode": "local-path",
        "path": entry.get("path"),
    }


def _runtime_proc_status(ctx: installer_mod.PathsContext, env_main_path: Path) -> dict[str, object]:
    running = _compose_running_services(ctx.docker_dir, env_main_path)
    return {
        "chat_proc_running": "chat-proc" in running,
        "running_services": sorted(running),
    }


def _live_bundle_status(ctx: installer_mod.PathsContext, env_main_path: Path, *, bundle_id: str) -> dict[str, object]:
    runtime = _runtime_proc_status(ctx, env_main_path)
    if not runtime.get("chat_proc_running"):
        return {
            "available": False,
            "chat_proc_running": False,
            "reason": "chat-proc is not running",
        }

    payload = json.dumps({"bundle_id": bundle_id})
    script = "\n".join(
        [
            "import json,sys,urllib.request,urllib.error",
            f"data={payload!r}.encode('utf-8')",
            "req=urllib.request.Request(",
            "    'http://127.0.0.1:8020/internal/bundles/status',",
            "    data=data,",
            "    headers={'content-type':'application/json'},",
            "    method='POST',",
            ")",
            "try:",
            "    resp=urllib.request.urlopen(req, timeout=15)",
            "    sys.stdout.write(resp.read().decode('utf-8'))",
            "except urllib.error.HTTPError as e:",
            "    sys.stdout.write(e.read().decode('utf-8'))",
            "    sys.exit(2)",
        ]
    )
    cmd = [
        "docker",
        "compose",
        "--env-file",
        str(env_main_path),
        "exec",
        "-T",
        "chat-proc",
        "python",
        "-c",
        script,
    ]
    try:
        raw = _docker_output(cmd, env=_compose_env_from_cmd(cmd), cwd=ctx.docker_dir)
    except SystemExit as exc:
        return {
            "available": False,
            "chat_proc_running": True,
            "reason": str(exc),
        }
    try:
        payload_obj = json.loads(raw)
    except Exception:
        return {
            "available": False,
            "chat_proc_running": True,
            "reason": "status endpoint returned non-JSON output",
            "raw": raw,
        }
    if isinstance(payload_obj, dict):
        payload_obj.setdefault("available", True)
        payload_obj.setdefault("chat_proc_running", True)
        return payload_obj
    return {
        "available": False,
        "chat_proc_running": True,
        "reason": "status endpoint returned an unexpected JSON shape",
        "raw": payload_obj,
    }


def _collect_bundle_status(
    *,
    repo_root: Path,
    workdir: Path,
    bundle_id: str,
    include_live: bool = True,
    include_live_manifest: bool = False,
) -> dict[str, object]:
    ctx = _build_paths_for_repo(repo_root, workdir)
    env_main_path = ctx.config_dir / ".env"
    bundles_path = ctx.config_dir / "bundles.yaml"
    if not bundles_path.exists():
        raise SystemExit(
            f"bundles.yaml not found at {bundles_path}.\n"
            "Initialize the workdir first."
        )

    bundles_data = installer_mod.load_release_descriptor(bundles_path)
    entry, _default_id = _find_bundle_item(bundles_data, bundle_id)
    source = _source_summary(entry)
    runtime_path = str((entry or {}).get("path") or "").strip()
    host_path = _host_path_for_runtime_bundle_path(runtime_path, workdir) if runtime_path else None
    host_path_exists = None
    if host_path:
        host_path_exists = Path(host_path).exists()

    secrets_entry = None
    bundles_secrets_path = ctx.config_dir / "bundles.secrets.yaml"
    if bundles_secrets_path.exists():
        try:
            secrets_data = installer_mod.load_release_descriptor(bundles_secrets_path)
            secrets_entry, _ = _find_bundle_item(secrets_data, bundle_id)
        except Exception:
            secrets_entry = None

    result: dict[str, object] = {
        "bundle_id": bundle_id,
        "workdir": str(workdir),
        "descriptor": str(bundles_path),
        "declared": entry is not None,
        "entry": entry or None,
        "source": source,
        "runtime_path": runtime_path or None,
        "host_path": host_path,
        "host_path_exists": host_path_exists,
        "secrets_declared": secrets_entry is not None,
    }

    if include_live:
        if not env_main_path.exists():
            result["runtime"] = {
                "chat_proc_running": False,
                "reason": f"runtime env file not found: {env_main_path}",
            }
        else:
            result["runtime"] = _runtime_proc_status(ctx, env_main_path)
            if include_live_manifest:
                result["live"] = _live_bundle_status(ctx, env_main_path, bundle_id=bundle_id)
    return result


def _format_bool(value: object) -> str:
    if value is True:
        return "yes"
    if value is False:
        return "no"
    return "unknown"


def print_bundle_status(console: Console, status: dict[str, object]) -> None:
    console.print("[bold]Bundle Status[/bold]")
    console.print(f"[dim]Bundle:[/dim] {status.get('bundle_id')}")
    console.print(f"[dim]Declared in staged descriptor:[/dim] {_format_bool(status.get('declared'))}")
    console.print(f"[dim]Descriptor:[/dim] {status.get('descriptor')}")

    source = status.get("source") if isinstance(status.get("source"), dict) else {}
    console.print(f"[dim]Source mode:[/dim] {source.get('mode') if isinstance(source, dict) else 'unknown'}")
    if status.get("runtime_path"):
        console.print(f"[dim]Runtime path:[/dim] {status.get('runtime_path')}")
    if status.get("host_path"):
        console.print(f"[dim]Host path:[/dim] {status.get('host_path')}")
        console.print(f"[dim]Host path exists:[/dim] {_format_bool(status.get('host_path_exists'))}")
    if isinstance(source, dict) and source.get("repo"):
        console.print(f"[dim]Git repo:[/dim] {source.get('repo')}")
        console.print(f"[dim]Git ref:[/dim] {source.get('ref') or 'unset'}")
        if source.get("subdir"):
            console.print(f"[dim]Git subdir:[/dim] {source.get('subdir')}")
    console.print(f"[dim]Secrets entry:[/dim] {_format_bool(status.get('secrets_declared'))}")

    runtime = status.get("runtime") if isinstance(status.get("runtime"), dict) else None
    if runtime is None:
        return
    console.print("\n[bold]Runtime[/bold]")
    console.print(f"[dim]chat-proc running:[/dim] {_format_bool(runtime.get('chat_proc_running'))}")
    if runtime.get("reason"):
        console.print(f"[yellow]Runtime check limited:[/yellow] {runtime.get('reason')}")

    live = status.get("live") if isinstance(status.get("live"), dict) else None
    if live is None:
        return
    console.print("\n[bold]Live Bundle Load[/bold]")
    if not live.get("available"):
        console.print(f"[yellow]Live status unavailable:[/yellow] {live.get('reason') or 'unknown'}")
        return
    console.print(f"[dim]Declared in live registry:[/dim] {_format_bool(live.get('declared'))}")
    console.print(f"[dim]Manifest load:[/dim] {'ok' if live.get('loaded') else 'failed'}")
    console.print(f"[dim]Path exists in proc:[/dim] {_format_bool(live.get('path_exists'))}")
    if live.get("authority"):
        console.print(f"[dim]Authority:[/dim] {live.get('authority')}")
    if live.get("last_error"):
        err = live.get("last_error")
        if isinstance(err, dict):
            console.print(f"[red]Last error:[/red] {err.get('type')}: {err.get('message')}")
            if err.get("where"):
                console.print(f"[dim]Where:[/dim] {err.get('where')}")
        else:
            console.print(f"[red]Last error:[/red] {err}")
    interface = live.get("interface")
    if isinstance(interface, dict):
        widgets = interface.get("widgets") if isinstance(interface.get("widgets"), list) else []
        apis = interface.get("apis") if isinstance(interface.get("apis"), list) else []
        mcps = interface.get("mcp_endpoints") if isinstance(interface.get("mcp_endpoints"), list) else []
        scheduled = interface.get("scheduled_jobs") if isinstance(interface.get("scheduled_jobs"), list) else []
        console.print(f"[dim]Widgets:[/dim] {', '.join(str(w.get('alias')) for w in widgets if isinstance(w, dict)) or '<none>'}")
        console.print(f"[dim]APIs:[/dim] {', '.join(str(a.get('alias')) for a in apis if isinstance(a, dict)) or '<none>'}")
        console.print(f"[dim]MCP endpoints:[/dim] {', '.join(str(m.get('alias')) for m in mcps if isinstance(m, dict)) or '<none>'}")
        console.print(f"[dim]Scheduled jobs:[/dim] {', '.join(str(j.get('alias')) for j in scheduled if isinstance(j, dict)) or '<none>'}")


def _bundle_reload_summary_lines(
    result: dict[str, object],
    *,
    descriptor_path: Path,
    bundle_id: str,
) -> list[str]:
    lines = [
        "Bundle reload accepted.",
        f"Bundle: {bundle_id}",
        f"Descriptor: {descriptor_path}",
    ]
    authority = str(result.get("authority") or "").strip()
    if authority:
        lines.append(f"Authority: {authority}")
    receivers = result.get("broadcast_receivers")
    if receivers is not None:
        lines.append(f"Broadcast receivers: {receivers}")
    eviction = result.get("eviction")
    if isinstance(eviction, dict) and eviction:
        parts = [f"{key}={value}" for key, value in sorted(eviction.items())]
        lines.append("Eviction: " + ", ".join(parts))
    elif eviction is not None:
        lines.append(f"Eviction: {eviction}")
    lines.append("The next request will re-import that bundle from the runtime workspace descriptor path.")
    return lines


def _print_bundle_reload_summary(
    console: Console,
    result: dict[str, object],
    *,
    descriptor_path: Path,
    bundle_id: str,
) -> None:
    lines = _bundle_reload_summary_lines(result, descriptor_path=descriptor_path, bundle_id=bundle_id)
    if not lines:
        return
    console.print(f"[green]{lines[0]}[/green]")
    for line in lines[1:]:
        console.print(f"[dim]{line}[/dim]")


def reload_bundle_from_descriptor(
    console: Console,
    *,
    repo_root: Path,
    workdir: Path,
    bundle_id: str,
    verbose: bool = False,
    json_output: bool = False,
    quiet: bool = False,
) -> dict[str, object]:
    ctx = _build_paths_for_repo(repo_root, workdir)
    env_main_path = ctx.config_dir / ".env"
    env_proc_path = ctx.config_dir / ".env.proc"
    if not env_main_path.exists() or not env_proc_path.exists():
        raise SystemExit(
            f"Runtime env files not found under {ctx.config_dir}. "
            "Run the installer first for this workdir."
        )

    env_main = installer_mod.load_env_file(env_main_path)
    env_proc = installer_mod.load_env_file(env_proc_path)
    descriptor_path = _resolve_bundle_reload_source(env_main, env_proc)
    bundle_ids = _load_bundle_ids_from_descriptor(descriptor_path)
    if bundle_id not in bundle_ids:
        known = ", ".join(sorted(bundle_ids)) or "<none>"
        raise SystemExit(
            f"Bundle '{bundle_id}' is not declared in {descriptor_path}. "
            f"Known bundles: {known}"
        )

    running = _compose_running_services(ctx.docker_dir, env_main_path)
    if "chat-proc" not in running:
        raise SystemExit(
            "chat-proc is not running for this workdir. "
            "Start the stack first, then rerun --bundle-reload."
        )

    payload = json.dumps({"bundle_id": bundle_id})
    script = (
        "import json,sys,urllib.request;"
        f"data={payload!r}.encode('utf-8');"
        "req=urllib.request.Request("
        "'http://127.0.0.1:8020/internal/bundles/reload-authority',"
        "data=data,"
        "headers={'content-type':'application/json'},"
        "method='POST');"
        "resp=urllib.request.urlopen(req);"
        "sys.stdout.write(resp.read().decode('utf-8'))"
    )
    cmd = [
        "docker",
        "compose",
        "--env-file",
        str(env_main_path),
        "exec",
        "-T",
        "chat-proc",
        "python",
        "-c",
        script,
    ]

    if not quiet and not json_output:
        console.print(
            f"[dim]Reloading bundle[/dim] {bundle_id}\n"
            f"[dim]Descriptor[/dim] {descriptor_path}"
        )
    raw = _run_compose_capture(
        console,
        cmd,
        cwd=ctx.docker_dir,
        label="Bundle reload",
        verbose=verbose,
    )
    try:
        result = json.loads(raw) if raw else {}
    except json.JSONDecodeError as exc:
        if verbose and raw:
            raise SystemExit("Bundle reload returned non-JSON output.") from exc
        detail = _tail_process_text(raw)
        message = "Bundle reload returned non-JSON output."
        if detail:
            message += f"\n{detail}"
        message += "\nRerun with --verbose to see the raw docker compose command and full proc output."
        raise SystemExit(message) from exc
    if not isinstance(result, dict):
        raise SystemExit("Bundle reload returned an unexpected response shape.")
    if result.get("status") != "ok":
        detail = json.dumps(result, ensure_ascii=False, indent=2)
        raise SystemExit(f"Bundle reload failed.\n{detail}")
    result.setdefault(
        "messages",
        _bundle_reload_summary_lines(result, descriptor_path=descriptor_path, bundle_id=bundle_id),
    )
    if json_output:
        _print_json(result)
    elif not quiet:
        _print_bundle_reload_summary(
            console,
            result,
            descriptor_path=descriptor_path,
            bundle_id=bundle_id,
        )
    return result


def _docker_running_names() -> list[str]:
    try:
        output = _docker_output(["docker", "ps", "--format", "{{.Names}}"])
    except SystemExit:
        return []
    names = [line.strip() for line in output.splitlines() if line.strip()]
    return names


def _parse_secret_pairs(items: list[str]) -> dict[str, str]:
    secrets: dict[str, str] = {}
    for item in items:
        if "=" not in item:
            raise SystemExit(f"Invalid secret '{item}'. Use KEY=VALUE.")
        key, value = item.split("=", 1)
        key = key.strip()
        if not key:
            raise SystemExit(f"Invalid secret '{item}'. Key is empty.")
        secrets[key] = value
    return secrets


def _canonical_secret_key(key: str) -> str:
    stripped = str(key or "").strip()
    return SECRET_KEY_ALIASES.get(stripped, stripped)


def _parse_init_secret_pairs(items: list[list[str]] | None) -> dict[str, str]:
    secrets: dict[str, str] = {}
    for item in items or []:
        if len(item) != 2:
            raise SystemExit("Invalid --set-secret usage. Use: --set-secret KEY VALUE.")
        raw_key, value = item
        key = _canonical_secret_key(raw_key)
        if not key or "." not in key:
            raise SystemExit(f"Invalid secret key '{raw_key}'. Use a dotted descriptor key.")
        secrets[key] = value
    return secrets


def _prompt_init_standard_secrets(console: Console, existing: dict[str, str]) -> dict[str, str]:
    secrets = dict(existing)
    for key, label in STANDARD_INIT_SECRET_PROMPTS:
        if key in secrets:
            continue
        value = Prompt.ask(f"{label} ({key}; leave blank to skip)", default="", password=True)
        if value:
            secrets[key] = value
    return secrets


def _select_option(console: Console, title: str, options: list[str], default_index: int = 0) -> str:
    def _debug_enabled() -> bool:
        raw = os.environ.get("KDCUBE_CLI_DEBUG_SELECTOR", "").strip().lower()
        return raw not in {"", "0", "false", "no"}

    def _debug(msg: str) -> None:
        if _debug_enabled():
            try:
                debug_path = Path(
                    os.environ.get("KDCUBE_CLI_DEBUG_SELECTOR_PATH", "/tmp/kdcube-cli-selector.log")
                )
                debug_path.parent.mkdir(parents=True, exist_ok=True)
                with debug_path.open("a", encoding="utf-8") as fh:
                    fh.write(f"[cli] {msg}\n")
            except Exception:
                pass

    def _plain_prompt_enabled() -> bool:
        raw = os.environ.get("KDCUBE_CLI_PLAIN_PROMPTS", "").strip().lower()
        return raw not in {"", "0", "false", "no"}

    def _use_alt_screen() -> bool:
        raw = os.environ.get("KDCUBE_CLI_ALT_SCREEN", "").strip().lower()
        if raw in {"1", "true", "yes", "on"}:
            return True
        if raw in {"0", "false", "no", "off"}:
            return False
        return any(os.environ.get(name) for name in ("SSH_CONNECTION", "SSH_CLIENT", "SSH_TTY"))

    def _use_manual_redraw() -> bool:
        raw = os.environ.get("KDCUBE_CLI_MANUAL_REDRAW", "").strip().lower()
        if raw in {"1", "true", "yes", "on"}:
            return True
        if raw in {"0", "false", "no", "off"}:
            return False
        term = os.environ.get("TERM", "").lower()
        return bool(os.environ.get("STY") or os.environ.get("TMUX") or term.startswith("screen"))

    def _prompt_numbered() -> str:
        console.print(f"[bold]{title}[/bold]")
        for i, option in enumerate(options, start=1):
            marker = " (default)" if i - 1 == default_index else ""
            console.print(f"  {i}. {option}{marker}")
        choice = Prompt.ask(
            "Select option number",
            choices=[str(i) for i in range(1, len(options) + 1)],
            default=str(default_index + 1),
        )
        return options[int(choice) - 1]

    if not sys.stdin.isatty() or not sys.stdout.isatty():
        _debug("path=numbered reason=non-tty")
        return _prompt_numbered()

    if _plain_prompt_enabled():
        _debug("path=numbered reason=forced-plain")
        return _prompt_numbered()

    if not console.is_terminal or console.is_jupyter or os.environ.get("TERM", "").lower() == "dumb":
        _debug("path=numbered reason=terminal-capability")
        return _prompt_numbered()

    idx = max(0, min(default_index, len(options) - 1))

    def _render() -> Panel:
        text = Text()
        text.append(title + "\n\n", style="bold")
        for i, option in enumerate(options):
            if i == idx:
                text.append("➤ ", style="bold cyan")
                text.append(option, style="bold cyan")
            else:
                text.append("  " + option)
            text.append("\n")
        text.append("\nUse ↑/↓ and Enter. Press q to exit.", style="dim")
        return Panel(text, title="Select")

    if _use_manual_redraw():
        _debug(
            "path=manual-redraw "
            f"TERM={os.environ.get('TERM','')} "
            f"SSH_TTY={bool(os.environ.get('SSH_TTY'))} "
            f"STY={bool(os.environ.get('STY'))} "
            f"TMUX={bool(os.environ.get('TMUX'))}"
        )
        def _capture() -> tuple[str, int]:
            with console.capture() as capture:
                console.print(_render())
            rendered = capture.get()
            lines = rendered.splitlines()
            return rendered, max(1, len(lines))

        def _rewrite(rendered: str, line_count: int) -> None:
            if line_count > 0:
                sys.stdout.write(f"\x1b[{line_count}F")
            sys.stdout.write(rendered)
            sys.stdout.flush()

        rendered, line_count = _capture()
        sys.stdout.write(rendered)
        sys.stdout.flush()

        while True:
            k = read_tty_key()
            _debug(f"key={k!r}")
            if k in (KEY_UP, "k"):
                idx = (idx - 1) % len(options)
            elif k in (KEY_DOWN, "j"):
                idx = (idx + 1) % len(options)
            elif k == KEY_EOF:
                raise KeyboardInterrupt
            elif k == KEY_ENTER:
                return options[idx]
            elif k in ("q", KEY_ESCAPE):
                raise KeyboardInterrupt
            elif k == KEY_INTERRUPT:
                raise KeyboardInterrupt
            rendered, _ = _capture()
            _rewrite(rendered, line_count)

    with Live(
        _render(),
        console=console,
        screen=_use_alt_screen(),
        transient=True,
        auto_refresh=False,
        redirect_stdout=False,
        redirect_stderr=False,
    ) as live:
        _debug(
            "path=live "
            f"screen={_use_alt_screen()} "
            f"TERM={os.environ.get('TERM','')} "
            f"SSH_TTY={bool(os.environ.get('SSH_TTY'))} "
            f"STY={bool(os.environ.get('STY'))} "
            f"TMUX={bool(os.environ.get('TMUX'))}"
        )
        while True:
            k = read_tty_key()
            _debug(f"key={k!r}")
            if k in (KEY_UP, "k"):
                idx = (idx - 1) % len(options)
            elif k in (KEY_DOWN, "j"):
                idx = (idx + 1) % len(options)
            elif k == KEY_EOF:
                raise KeyboardInterrupt
            elif k == KEY_ENTER:
                return options[idx]
            elif k in ("q", KEY_ESCAPE):
                raise KeyboardInterrupt
            elif k == KEY_INTERRUPT:
                raise KeyboardInterrupt
            live.update(_render(), refresh=True)

def _extract_platform_ref(text: str) -> str | None:
    in_platform = False
    for line in text.splitlines():
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        if not line.startswith(" "):
            in_platform = line.strip().startswith("platform:")
            continue
        if in_platform and "ref:" in line:
            _, value = line.split("ref:", 1)
            value = value.strip().strip('"').strip("'")
            return value or None
    return None


def _read_local_ref(repo_root: Path) -> str | None:
    path = repo_root / "release.yaml"
    if not path.exists():
        return None
    return _extract_platform_ref(path.read_text())


def _read_remote_ref(repo_root: Path) -> str | None:
    try:
        subprocess.run(["git", "fetch", "origin", "main"], cwd=repo_root, check=True, capture_output=True, text=True)
    except subprocess.CalledProcessError:
        return None
    try:
        proc = subprocess.run(
            ["git", "show", "origin/main:release.yaml"],
            cwd=repo_root,
            check=True,
            capture_output=True,
            text=True,
        )
    except subprocess.CalledProcessError:
        return None
    return _extract_platform_ref(proc.stdout)


def _get_nested(data: dict | None, *keys: str):
    cur = data
    for key in keys:
        if not isinstance(cur, dict):
            return None
        cur = cur.get(key)
    return cur


def _parse_yaml_scalar(raw: str) -> object:
    """Parse a CLI string value into a typed YAML scalar (bool, int, float, str, None)."""
    try:
        val = yaml.safe_load(raw)
        if isinstance(val, (bool, int, float, str)) or val is None:
            return val
    except Exception:
        pass
    return raw


def _nested_key_exists(dct: dict, keys: list) -> bool:
    cur: object = dct
    for key in keys:
        if not isinstance(cur, dict) or key not in cur:
            return False
        cur = cur[key]
    return True


def _has_value(value: object | None) -> bool:
    if value is None:
        return False
    text = str(value).strip()
    return bool(text) and not installer_mod.is_placeholder(text)


def _normalize_cors_origin(raw: str) -> str:
    value = str(raw or "").strip().rstrip("/")
    if not value:
        return ""
    if "://" not in value:
        value = f"https://{value}"
    parsed = urlsplit(value)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise SystemExit(f"Invalid CORS origin: {raw!r}. Use an origin like https://example.ngrok-free.dev")
    return urlunsplit((parsed.scheme, parsed.netloc, "", "", ""))


def _apply_cors_origins(assembly: dict, origins: list[str]) -> list[str]:
    if not origins:
        return []
    cors = assembly.get("cors")
    if not isinstance(cors, dict):
        cors = {}
        assembly["cors"] = cors
    allow_origins = cors.get("allow_origins")
    if not isinstance(allow_origins, list):
        allow_origins = []
        cors["allow_origins"] = allow_origins

    existing = {str(item).strip().rstrip("/") for item in allow_origins if str(item).strip()}
    added: list[str] = []
    for raw in origins:
        origin = _normalize_cors_origin(raw)
        if origin and origin not in existing:
            allow_origins.append(origin)
            existing.add(origin)
            added.append(origin)
    return added


def _iter_bundle_specs(payload: dict | None):
    if not isinstance(payload, dict):
        return
    raw_bundles = payload.get("bundles") if "bundles" in payload else payload
    if not isinstance(raw_bundles, dict):
        return

    items = raw_bundles.get("items")
    if isinstance(items, list):
        for item in items:
            if isinstance(item, dict):
                yield item
        return

    for key, value in raw_bundles.items():
        if key in {"version", "default_bundle_id"}:
            continue
        if isinstance(value, dict):
            spec = dict(value)
            spec.setdefault("id", str(key))
            yield spec


def _uses_local_path_bundles(payload: dict | None) -> bool:
    for spec in _iter_bundle_specs(payload):
        if _has_value(spec.get("path")):
            return True
    return False


def _local_path_bundles_need_host_root(payload: dict | None) -> bool:
    for spec in _iter_bundle_specs(payload):
        raw_path = spec.get("path")
        if not _has_value(raw_path):
            continue
        candidate = Path(str(raw_path).strip()).expanduser()
        normalized = str(candidate).replace("\\", "/")
        if normalized == "/bundles" or normalized.startswith("/bundles/"):
            return True
        if not candidate.is_absolute():
            return True
    return False


def _descriptor_fast_path_reasons(
    assembly: dict,
    *,
    have_secrets: bool,
    have_gateway: bool,
    bundles_descriptor: dict | None = None,
    latest: bool,
    upstream: bool = False,
    release: str | None = None,
) -> list[str]:
    reasons: list[str] = []
    if not have_secrets:
        reasons.append("missing secrets.yaml")
    if not have_gateway:
        reasons.append("missing gateway.yaml")

    provider = installer_mod.normalize_secrets_provider(
        _get_nested(assembly, "secrets", "provider"),
        default="secrets-service",
    )
    if provider != "secrets-file":
        reasons.append("assembly secrets.provider must be secrets-file")

    if not latest and not upstream and not _has_value(release) and not _has_value(_get_nested(assembly, "platform", "ref")):
        reasons.append("assembly platform.ref is required unless --latest, --upstream, or --release is used")

    for field in (("context", "tenant"), ("context", "project")):
        if not _has_value(_get_nested(assembly, *field)):
            reasons.append(f"assembly {'.'.join(field)} is required")

    auth_type = str(_get_nested(assembly, "auth", "type") or "").strip().lower()
    if auth_type not in {"simple", "cognito", "delegated"}:
        reasons.append("assembly auth.type must be simple, cognito, or delegated")
    if auth_type in {"cognito", "delegated"}:
        for field in (
            ("auth", "cognito", "region"),
            ("auth", "cognito", "user_pool_id"),
            ("auth", "cognito", "app_client_id"),
        ):
            if not _has_value(_get_nested(assembly, *field)):
                reasons.append(f"assembly {'.'.join(field)} is required")

    if installer_mod.parse_bool(_get_nested(assembly, "proxy", "ssl")) and not _has_value(assembly.get("domain")):
        reasons.append("assembly domain is required when proxy.ssl=true")

    for storage_kind in ("workspace", "claude_code_session"):
        storage_type = str(_get_nested(assembly, "storage", storage_kind, "type") or "").strip().lower()
        if storage_type == "git" and not _has_value(_get_nested(assembly, "storage", storage_kind, "repo")):
            reasons.append(f"assembly storage.{storage_kind}.repo is required when type=git")

    uses_local_path_bundles = _uses_local_path_bundles(bundles_descriptor)
    if not uses_local_path_bundles:
        uses_local_path_bundles = _uses_local_path_bundles(assembly)
    if (
        uses_local_path_bundles
        and _local_path_bundles_need_host_root(bundles_descriptor if _uses_local_path_bundles(bundles_descriptor) else assembly)
        and not _has_value(_get_nested(assembly, "paths", "host_bundles_path"))
    ):
        reasons.append("assembly paths.host_bundles_path is required for non-interactive local bundle installs")

    frontend = assembly.get("frontend")
    if isinstance(frontend, dict) and frontend:
        frontend_image = frontend.get("image")
        if not _has_value(frontend_image):
            build = frontend.get("build") if isinstance(frontend.get("build"), dict) else frontend
            for field in ("repo", "ref", "dockerfile", "src"):
                if not _has_value(build.get(field) if isinstance(build, dict) else None):
                    reasons.append(f"assembly frontend.build.{field} is required when frontend.image is not set")

    return reasons


def _stage_descriptor_set(
    *,
    repo_root: Path,
    workdir: Path,
    descriptors_location: Path,
) -> dict[str, object]:
    return installer_mod.stage_descriptor_directory(
        workdir / "config",
        source_dir=descriptors_location,
        ai_app_root=repo_root / "app/ai-app",
        require_complete=True,
    )


def _ensure_runtime_repo_build_support_files(console: Console, *, repo_root: Path, workdir: Path) -> None:
    env_file = workdir / "config" / ".env"
    if not env_file.exists():
        return
    try:
        env_main = installer_mod.load_env_file(env_file)
    except Exception:
        return

    ui_context_raw = str(env_main.entries.get("UI_BUILD_CONTEXT", (None, None))[1] or "").strip()
    nginx_rel_raw = str(env_main.entries.get("NGINX_UI_CONFIG_FILE_PATH", (None, None))[1] or "").strip()
    if not ui_context_raw or not nginx_rel_raw:
        return
    nginx_rel = Path(nginx_rel_raw)
    if nginx_rel.is_absolute():
        return

    ui_context = Path(ui_context_raw).expanduser()
    if not ui_context.is_absolute():
        ui_context = repo_root / "app" / "ai-app" / ui_context
    ui_context = ui_context.resolve()
    target = (ui_context / nginx_rel).resolve()
    try:
        target.relative_to(ui_context)
    except ValueError:
        return
    if target.exists():
        return

    compose_mode = str(env_main.entries.get("KDCUBE_COMPOSE_MODE", (None, None))[1] or "").strip()
    if compose_mode == "custom-ui-managed-infra":
        source_rel = "deployment/docker/custom-ui-managed-infra/nginx/conf/nginx_ui.conf"
    else:
        source_rel = "deployment/docker/all_in_one_kdcube/nginx/conf/nginx_ui.conf"
    source = (repo_root / "app" / "ai-app" / source_rel).resolve()
    if not source.exists():
        console.print(f"[yellow]UI nginx config source missing after source restage: {source}[/yellow]")
        return
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    console.print(f"[dim]Restored runtime UI nginx build config:[/dim] {target}")


def _copy_dirty_local_source(console: Console, *, source_repo: Path, workdir: Path) -> Path:
    if not _is_git_repo(source_repo):
        raise SystemExit(f"init --path requires a local git repo: {source_repo}")

    target = _default_repo_path_for_workdir(workdir)
    if source_repo.resolve() == target.resolve():
        console.print(f"[dim]Local platform source already staged:[/dim] {target}")
        return target

    console.print(f"[dim]Copying local platform source:[/dim] {source_repo} -> {target}")

    try:
        proc = subprocess.run(
            ["git", "ls-files", "--cached", "--others", "--exclude-standard"],
            cwd=source_repo,
            check=True,
            capture_output=True,
            text=True,
        )
    except subprocess.CalledProcessError as exc:
        details = (exc.stderr or exc.stdout or "").strip()
        raise SystemExit(f"Could not enumerate local source files in {source_repo}.{(' ' + details) if details else ''}") from exc

    files = [line.strip() for line in (proc.stdout or "").splitlines() if line.strip()]
    if not files:
        raise SystemExit(f"No source files found to copy from {source_repo}")

    preserve_root = workdir / f".{DEFAULT_REPO_DIRNAME}.preserve-{os.getpid()}"
    shutil.rmtree(preserve_root, ignore_errors=True)
    if target.exists():
        for rel in (".kdcube", "app/ai-app/.kdcube"):
            src_preserve = target / rel
            if src_preserve.exists():
                dst_preserve = preserve_root / rel
                dst_preserve.parent.mkdir(parents=True, exist_ok=True)
                shutil.copytree(src_preserve, dst_preserve, dirs_exist_ok=True)
        shutil.rmtree(target)
    target.mkdir(parents=True, exist_ok=True)

    copied = 0
    for rel in files:
        src = (source_repo / rel).resolve()
        try:
            src.relative_to(source_repo)
        except ValueError:
            continue
        if not src.exists() and not src.is_symlink():
            continue
        dst = target / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        if src.is_symlink():
            link_to = os.readlink(src)
            dst.symlink_to(link_to)
        elif src.is_file():
            shutil.copy2(src, dst)
        copied += 1

    if preserve_root.exists():
        for preserved in preserve_root.rglob("*"):
            rel = preserved.relative_to(preserve_root)
            dst = target / rel
            if preserved.is_dir():
                dst.mkdir(parents=True, exist_ok=True)
            elif preserved.is_file() and not dst.exists():
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(preserved, dst)
        shutil.rmtree(preserve_root, ignore_errors=True)

    _ensure_runtime_repo_build_support_files(console, repo_root=target, workdir=workdir)
    console.print(f"[dim]Copied local platform source files:[/dim] {copied}")
    return target


def ensure_repo(console: Console, repo: str, target: Path) -> None:
    if _is_git_repo(target):
        console.print(f"Repo already exists at {target}")
        return

    if _is_platform_source_tree(target):
        console.print(f"[dim]Using local platform source at:[/dim] {target}")
        return

    normalized_repo = installer_mod.normalize_git_repo_source(repo)
    target.parent.mkdir(parents=True, exist_ok=True)
    console.print(f"Cloning {normalized_repo} to {target}")
    run(["git", "clone", normalized_repo, str(target)])


def _checkout_repo_ref(console: Console, repo_root: Path, ref: str) -> None:
    ref = str(ref or "").strip()
    if not ref:
        raise SystemExit("Release ref is required for source checkout.")
    console.print(f"[dim]Checking out repo ref:[/dim] {ref}")
    try:
        subprocess.run(["git", "fetch", "--tags", "origin"], cwd=repo_root, check=True, capture_output=True, text=True)
    except subprocess.CalledProcessError:
        # Best effort only; later checkout may still work for local refs/commits.
        pass

    candidates = [ref, f"origin/{ref}", f"refs/tags/{ref}", f"tags/{ref}"]
    last_error: subprocess.CalledProcessError | None = None
    for candidate in candidates:
        try:
            subprocess.run(
                ["git", "checkout", "--detach", candidate],
                cwd=repo_root,
                check=True,
                capture_output=True,
                text=True,
            )
            return
        except subprocess.CalledProcessError as exc:
            last_error = exc
            continue
    details = ""
    if last_error is not None:
        details = (last_error.stderr or last_error.stdout or "").strip()
    raise SystemExit(f"Could not checkout release ref '{ref}' in {repo_root}.{(' ' + details) if details else ''}")


def _checkout_repo_upstream(console: Console, repo_root: Path) -> str:
    console.print("[dim]Checking out latest upstream repo state:[/dim] origin/main")
    try:
        subprocess.run(
            ["git", "fetch", "origin", "main"],
            cwd=repo_root,
            check=True,
            capture_output=True,
            text=True,
        )
        subprocess.run(
            ["git", "checkout", "--detach", "origin/main"],
            cwd=repo_root,
            check=True,
            capture_output=True,
            text=True,
        )
        proc = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=repo_root,
            check=True,
            capture_output=True,
            text=True,
        )
    except subprocess.CalledProcessError as exc:
        details = (exc.stderr or exc.stdout or "").strip()
        raise SystemExit(
            f"Could not checkout upstream repo state in {repo_root}.{(' ' + details) if details else ''}"
        ) from exc
    value = (proc.stdout or "").strip()
    if not value:
        raise SystemExit(f"Could not resolve HEAD after checking out origin/main in {repo_root}.")
    return value


def _read_install_meta(workdir: Path) -> dict | None:
    workdir = _resolve_cli_workdir(workdir)
    return _read_install_meta_raw(workdir)


def _git_status(repo_root: Path) -> tuple[str | None, str | None, str | None]:
    """Return (local_head, remote_head, status) where status is 'up-to-date'|'behind'|'diverged'|'ahead'|None."""
    try:
        subprocess.run(["git", "fetch", "origin", "main"], cwd=repo_root, check=True, capture_output=True, text=True)
        local_head = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=repo_root,
            check=True,
            capture_output=True,
            text=True,
        ).stdout.strip()
        remote_head = subprocess.run(
            ["git", "rev-parse", "origin/main"],
            cwd=repo_root,
            check=True,
            capture_output=True,
            text=True,
        ).stdout.strip()
        counts = subprocess.run(
            ["git", "rev-list", "--left-right", "--count", "HEAD...origin/main"],
            cwd=repo_root,
            check=True,
            capture_output=True,
            text=True,
        ).stdout.strip()
        ahead, behind = (int(x) for x in counts.split())
        if ahead == 0 and behind == 0:
            status = "up-to-date"
        elif behind > 0 and ahead == 0:
            status = f"behind ({behind} commits)"
        elif ahead > 0 and behind == 0:
            status = f"ahead ({ahead} commits)"
        else:
            status = f"diverged (ahead {ahead}, behind {behind})"
        return local_head, remote_head, status
    except Exception:
        return None, None, None


def run_installer(
    console: Console,
    repo_root: Path,
    workdir: Path,
    mode: str,
    release_ref: str | None,
    docker_namespace: str | None,
    dry_run: bool,
) -> None:
    installer_mod.run_setup(
        console,
        repo_root=repo_root,
        workdir=workdir,
        install_mode=mode,
        release_ref=release_ref,
        docker_namespace=docker_namespace,
        dry_run=dry_run,
    )


def _load_cli_defaults() -> dict:
    try:
        return json.loads(DEFAULT_DEFAULTS_FILE.read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


def _save_cli_defaults(data: dict) -> None:
    DEFAULT_DEFAULTS_FILE.parent.mkdir(parents=True, exist_ok=True)
    DEFAULT_DEFAULTS_FILE.write_text(json.dumps(data, indent=2))


def _parse_workdir_namespace(workdir: Path) -> tuple[str, str]:
    name = workdir.name
    if "__" in name:
        tenant, _, project = name.partition("__")
        return tenant, project
    return "", name


def _read_cli_lock() -> dict | None:
    try:
        return json.loads(CLI_LOCK_FILE.read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        return None


def _write_cli_lock(
    *,
    tenant: str,
    project: str,
    workdir: Path,
    docker_dir: Path,
    env_file: Path,
) -> None:
    CLI_LOCK_FILE.parent.mkdir(parents=True, exist_ok=True)
    CLI_LOCK_FILE.write_text(
        json.dumps(
            {
                "tenant": tenant,
                "project": project,
                "workdir": str(workdir),
                "docker_dir": str(docker_dir),
                "env_file": str(env_file),
            },
            indent=2,
        )
    )


def _clear_cli_lock() -> None:
    try:
        CLI_LOCK_FILE.unlink()
    except FileNotFoundError:
        pass


def _lock_running_services(lock: dict) -> set[str]:
    """Return the set of running Docker services for a lock entry, or empty set if stale/inaccessible."""
    docker_dir = Path(lock["docker_dir"]) if lock.get("docker_dir") else None
    env_file = Path(lock["env_file"]) if lock.get("env_file") else None
    if not (docker_dir and env_file and docker_dir.exists() and env_file.exists()):
        return set()
    try:
        return _compose_running_services(docker_dir, env_file)
    except Exception:
        return set()


def _check_before_start(
    console: Console,
    *,
    tenant: str,
    project: str,
) -> None:
    """Raise SystemExit if a different deployment is already running. Clear stale locks silently."""
    lock = _read_cli_lock()
    if lock is None:
        return
    lock_tenant = str(lock.get("tenant", "")).strip()
    lock_project = str(lock.get("project", "")).strip()
    if lock_tenant == tenant and lock_project == project:
        return
    running = _lock_running_services(lock)
    if running:
        raise SystemExit(
            f"Another local KDCube deployment is already running.\n"
            f"  Tenant  : {lock_tenant}\n"
            f"  Project : {lock_project}\n"
            f"  Workdir : {lock.get('workdir', '?')}\n"
            f"  Services: {', '.join(sorted(running))}\n\n"
            f"Stop it first, then retry:\n"
            f"  kdcube stop --workdir {lock.get('workdir', '<workdir>')}"
        )
    _clear_cli_lock()


def _check_before_stop(workdir: Path, env_file: Path, docker_dir: Path) -> None:
    """Raise SystemExit if the target deployment is not running or a different one is."""
    running = set()
    try:
        running = _compose_running_services(docker_dir, env_file, strict=True)
    except Exception:
        pass

    if not running:
        raise SystemExit(
            f"Deployment is not running.\n"
            f"  Workdir: {workdir}"
        )

    target_tenant, target_project = _parse_workdir_namespace(workdir)
    lock = _read_cli_lock()
    if lock is not None:
        lock_tenant = str(lock.get("tenant", "")).strip()
        lock_project = str(lock.get("project", "")).strip()
        if lock_tenant != target_tenant or lock_project != target_project:
            raise SystemExit(
                f"Cannot stop: a different deployment is currently running.\n"
                f"  Running  : {lock_tenant} / {lock_project}  ({lock.get('workdir', '?')})\n"
                f"  Requested: {target_tenant} / {target_project}  ({workdir})\n\n"
                f"Stop the running deployment first:\n"
                f"  kdcube stop --workdir {lock.get('workdir', '<workdir>')}"
            )


def _resolve_subcommand_workdir(
    workdir_arg: str | None,
    cli_defaults: dict,
    *,
    tenant_arg: str = "",
    project_arg: str = "",
) -> Path:
    """Resolve the namespaced runtime workdir for non-init subcommands.

    Precedence:
      1. ``--workdir <full-path>`` (explicit, takes precedence over everything).
      2. ``--tenant T --project P`` → compose under ``$DEFAULT_WORKDIR``
         (the platform-wide default base). Falls back to the
         ``safe_workspace_name`` form when the literal form is not initialized,
         for backward compatibility with older workdirs.
      3. ``cli_defaults["default_workdir"]`` (must be a full namespaced path).
      4. ``cli_defaults["default_tenant"]`` + ``["default_project"]`` →
         compose under ``$DEFAULT_WORKDIR``.
      5. Error.
    """
    if workdir_arg is not None and str(workdir_arg).strip():
        return Path(os.path.expanduser(workdir_arg)).resolve()

    tenant_arg = (tenant_arg or "").strip()
    project_arg = (project_arg or "").strip()

    def _compose_under_default(t: str, p: str) -> Path:
        base = Path(DEFAULT_WORKDIR).expanduser().resolve()
        literal = (base / f"{t}__{p}").resolve()
        if _read_install_meta_raw(literal) is not None:
            return literal
        safe = installer_mod.workspace_runtime_dir(base, t, p).resolve()
        if safe != literal and _read_install_meta_raw(safe) is not None:
            return safe
        return literal

    if tenant_arg and project_arg:
        return _compose_under_default(tenant_arg, project_arg)

    default_workdir = str(cli_defaults.get("default_workdir", "") or "").strip()
    if default_workdir:
        return Path(os.path.expanduser(default_workdir)).resolve()

    default_tenant = str(cli_defaults.get("default_tenant", "") or "").strip()
    default_project = str(cli_defaults.get("default_project", "") or "").strip()
    if default_tenant and default_project:
        return _compose_under_default(default_tenant, default_project)

    raise SystemExit(
        "No target workdir specified.\n"
        "Pass one of:\n"
        "  --tenant T --project P                            # primary form; "
        f"composes under {DEFAULT_WORKDIR}\n"
        "  --workdir <full-path>                             # explicit namespaced runtime\n"
        "or configure cli_defaults via:\n"
        "  kdcube defaults --default-tenant T --default-project P\n"
        "  kdcube defaults --default-workdir <full-path>"
    )


def _resolve_subcommand_repo(path_arg: str, *, workdir: Path, path_provided: bool = False) -> Path:
    if path_provided:
        return Path(os.path.expanduser(path_arg)).resolve()
    meta_repo = _repo_path_from_install_meta(_resolve_cli_workdir(workdir))
    if meta_repo is not None:
        return meta_repo
    return Path(os.path.expanduser(path_arg)).resolve()


def _descriptor_platform_repo(assembly: dict, fallback_repo: str) -> str:
    platform_repo = str(_get_nested(assembly, "platform", "repo") or fallback_repo).strip()
    return platform_repo or fallback_repo


def _ensure_descriptor_platform_repo(
    console: Console,
    *,
    repo_path: Path,
    path_provided: bool,
    assembly: dict,
    fallback_repo: str,
) -> None:
    if path_provided:
        if not _is_git_repo(repo_path):
            raise SystemExit(f"Provided --path is not a git repo: {repo_path}")
        return

    ensure_repo(console, _descriptor_platform_repo(assembly, fallback_repo), repo_path)







def _bootstrap_repo_for_defaults(
    console: Console,
    *,
    repo: str,
    repo_path: Path,
    path_provided: bool,
) -> tuple[Path, Path]:
    """Ensure the platform repo exists and return (repo_path, descriptors_location).

    Used when --descriptors-location is omitted but a source selector (--latest,
    --upstream, --release, --build) implies non-interactive mode.  The repo's
    deployment/ directory is used as the implicit descriptor source so that a
    plain ``kdcube --upstream`` works without pre-prepared descriptors.
    """
    if path_provided:
        if not _is_git_repo(repo_path):
            raise SystemExit(f"Provided --path is not a git repo: {repo_path}")
    else:
        ensure_repo(console, repo, repo_path)

    descriptors_location = repo_path / "app" / "ai-app" / "deployment"
    if not descriptors_location.is_dir() or not (descriptors_location / "assembly.yaml").exists():
        raise SystemExit(
            f"Could not find deployment descriptors under {descriptors_location}. "
            "Ensure the platform repo contains app/ai-app/deployment/assembly.yaml."
        )
    return repo_path, descriptors_location


def main() -> None:
    preparse_quiet = _cli_quiet_requested(sys.argv[1:])
    console = Console()
    if not preparse_quiet:
        print_cli_banner()
    parser = argparse.ArgumentParser(description="KDCube Apps bootstrap CLI")
    parser.add_argument(
        "-q",
        "--quiet",
        action="store_true",
        default=False,
        help="Suppress the banner and routine success chatter",
    )
    parser.add_argument("--repo", default=DEFAULT_REPO, help=argparse.SUPPRESS)
    parser.add_argument(
        "--path",
        default=str(DEFAULT_DIR),
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--workdir",
        default=str(DEFAULT_WORKDIR),
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--descriptors-location",
        default="",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--latest",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--upstream",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--release",
        default="",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--build",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "-i",
        "--interactive",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--reset-config",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--reset",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--clean",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--remove-volumes",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--secrets-set",
        action="append",
        default=[],
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--secrets-prompt",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--proxy-ssl",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--no-proxy-ssl",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--dry-run-print-env",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--tenant",
        default="",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--project",
        default="",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--out-dir",
        default="",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--aws-region",
        default="",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--aws-profile",
        default="",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--aws-sm-prefix",
        default="",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--default-tenant",
        default="",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--default-project",
        default="",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--default-workdir",
        default="",
        help=argparse.SUPPRESS,
    )
    subparsers = parser.add_subparsers(dest="command")

    def _add_quiet_arg(subparser: argparse.ArgumentParser) -> None:
        subparser.add_argument(
            "-q",
            "--quiet",
            action="store_true",
            default=argparse.SUPPRESS,
            help="Suppress the banner and routine success chatter",
        )

    _sp = subparsers.add_parser("stop", help="Stop the local Docker Compose stack")
    _add_quiet_arg(_sp)
    _sp.add_argument("--tenant", default="", help="Tenant of the runtime to stop. With --project, composes under the platform default base.")
    _sp.add_argument("--project", default="", help="Project of the runtime to stop. Pair with --tenant.")
    _sp.add_argument("--workdir", default=None, help="(Advanced) Fully-qualified namespaced runtime workdir to stop")
    _sp.add_argument("--path", default=str(DEFAULT_DIR), help="Platform repo path")
    _sp.add_argument("--remove-volumes", action="store_true", help="Also pass -v to docker compose down")

    _sp = subparsers.add_parser("reload", help="Reload a bundle from its descriptor")
    _add_quiet_arg(_sp)
    _sp.add_argument("bundle_id", help="Bundle ID to reload")
    _sp.add_argument("--tenant", default="", help="Tenant of the runtime. With --project, composes under the platform default base.")
    _sp.add_argument("--project", default="", help="Project of the runtime. Pair with --tenant.")
    _sp.add_argument("--workdir", default=None, help="(Advanced) Fully-qualified namespaced runtime workdir")
    _sp.add_argument("--path", default=str(DEFAULT_DIR), help="Platform repo path")
    _sp.add_argument("--json", action="store_true", dest="json_output", help="Print machine-readable JSON")
    _sp.add_argument(
        "--verbose",
        action="store_true",
        help="Show the raw docker compose command and proc response",
    )

    _sp = subparsers.add_parser("bundle", help="Create, update, delete, or inspect a staged bundle entry")
    _add_quiet_arg(_sp)
    _sp.add_argument("bundle_id", nargs="?", help="Bundle ID to patch, or 'status'")
    _sp.add_argument("status_bundle_id", nargs="?", help=argparse.SUPPRESS)
    _sp.add_argument("--tenant", default="", help="Tenant of the runtime. With --project, composes under the platform default base.")
    _sp.add_argument("--project", default="", help="Project of the runtime. Pair with --tenant.")
    _sp.add_argument("--workdir", default=None, help="(Advanced) Fully-qualified namespaced runtime workdir")
    _sp.add_argument("--path", default=str(DEFAULT_DIR), help="Platform repo path")
    _sp.add_argument("--json", action="store_true", dest="json_output", help="With `bundle status`, `bundle reload`, or `bundle config apply`, print JSON")
    _sp.add_argument(
        "--verbose",
        action="store_true",
        help="With `bundle reload` or `bundle config apply --reload`, show the raw docker compose command and proc response",
    )
    _sp.add_argument(
        "--live",
        action="store_true",
        dest="live_status",
        help="With `bundle status`, ask local chat-proc to validate the explicit bundle id",
    )
    # Source mode (mutually exclusive)
    _src_grp = _sp.add_mutually_exclusive_group()
    _src_grp.add_argument(
        "--local-path",
        metavar="PATH",
        default=None,
        dest="local_path",
        help="Set bundle source to a local/container-visible path (clears git fields)",
    )
    _src_grp.add_argument(
        "--git-repo",
        metavar="REPO",
        default=None,
        dest="git_repo",
        help="Set bundle source to a git repo URL (clears path field)",
    )
    _sp.add_argument(
        "--git-ref",
        metavar="REF",
        default=None,
        dest="git_ref",
        help="Git ref/tag (required with --git-repo)",
    )
    _sp.add_argument(
        "--git-subdir",
        metavar="SUBDIR",
        default=None,
        dest="git_subdir",
        help="Subdirectory within the git repo that contains the bundle",
    )
    # Identity fields
    _sp.add_argument("--name", default=None, help="Display name for the bundle")
    _sp.add_argument("--module", default=None, help="Python module name (default: entrypoint)")
    _sg = _sp.add_mutually_exclusive_group()
    _sg.add_argument(
        "--singleton",
        dest="singleton",
        action="store_const",
        const=True,
        default=None,
        help="Mark bundle as singleton",
    )
    _sg.add_argument(
        "--no-singleton",
        dest="singleton",
        action="store_const",
        const=False,
        help="Mark bundle as non-singleton",
    )
    # Config / secrets patch ops
    _sp.add_argument(
        "--set-config",
        nargs=2,
        metavar=("KEY", "VALUE"),
        action="append",
        default=[],
        dest="set_config",
        help="Set a config value by dotted key path",
    )
    _sp.add_argument(
        "--set-secret",
        nargs=2,
        metavar=("KEY", "VALUE"),
        action="append",
        default=[],
        dest="set_secret",
        help="Set a secret value by dotted key path",
    )
    _sp.add_argument(
        "--del-config",
        metavar="KEY",
        action="append",
        default=[],
        dest="del_config",
        help="Delete a config key by dotted path",
    )
    _sp.add_argument(
        "--del-secret",
        metavar="KEY",
        action="append",
        default=[],
        dest="del_secret",
        help="Delete a secret key by dotted path",
    )
    _sp.add_argument(
        "--delete",
        action="store_true",
        default=False,
        help="Remove this bundle entry from bundles.yaml (and its secrets entry if present)",
    )
    _sp.add_argument(
        "--descriptors-location",
        default="",
        help="With `bundle config apply`, source directory containing bundles.yaml and optional bundles.secrets.yaml",
    )
    _sp.add_argument(
        "--dry-run",
        action="store_true",
        help="With `bundle config apply`, show what would change without staging files",
    )
    _sp.add_argument(
        "--reload",
        action="store_true",
        dest="reload_changed",
        help="With `bundle config apply`, reload changed bundle ids after staging descriptors",
    )

    _sp = subparsers.add_parser("export", help="Export live bundle descriptors")
    _add_quiet_arg(_sp)
    _sp.add_argument("--workdir", default=None, help="Namespaced runtime workdir")
    _sp.add_argument("--path", default=str(DEFAULT_DIR), help="Platform repo path")
    _sp.add_argument("--tenant", default="", help="Tenant for AWS SM export")
    _sp.add_argument("--project", default="", help="Project for AWS SM export")
    _sp.add_argument("--out-dir", default="", help="Output directory for exported files")
    _sp.add_argument("--aws-region", default="", help="AWS region for AWS SM export")
    _sp.add_argument("--aws-profile", default="", help="AWS profile for AWS SM export")
    _sp.add_argument("--aws-sm-prefix", default="", help="AWS SM prefix override")

    _sp = subparsers.add_parser("info", help="Show CLI defaults and runtime info")
    _add_quiet_arg(_sp)
    _sp.add_argument("--workdir", default="", help="Initialized runtime workdir to inspect")
    _sp.add_argument("--path", default=str(DEFAULT_DIR), help="Platform repo path")
    _sp.add_argument("--tenant", default="", help="Tenant for workdir resolution or disambiguation")
    _sp.add_argument("--project", default="", help="Project for workdir resolution or disambiguation")
    _sp.add_argument("--show-defaults", action="store_true", help="Show stored CLI defaults")
    _sp.add_argument(
        "--show-current-running-runtime",
        action="store_true",
        help="Show the currently running deployment",
    )
    _sp.add_argument("--json", action="store_true", dest="json_output", help="Print machine-readable JSON")

    _sp = subparsers.add_parser("clean", help="Clean local Docker image/cache artifacts")
    _add_quiet_arg(_sp)

    _sp = subparsers.add_parser("defaults", help="Save persistent operator defaults")
    _add_quiet_arg(_sp)
    _sp.add_argument("--default-tenant", default="", help="Default tenant to persist")
    _sp.add_argument("--default-project", default="", help="Default project to persist")
    _sp.add_argument("--default-workdir", default="", help="Default workdir to persist")

    _sp = subparsers.add_parser("start", help="Start the Docker Compose stack for an initialized workdir")
    _add_quiet_arg(_sp)
    _sp.add_argument("--tenant", default="", help="Tenant of the runtime to start. With --project, composes under the platform default base.")
    _sp.add_argument("--project", default="", help="Project of the runtime to start. Pair with --tenant.")
    _sp.add_argument("--workdir", default=None, help="(Advanced) Fully-qualified namespaced runtime workdir to start")
    _sp.add_argument("--path", default=str(DEFAULT_DIR), help="Platform repo path")
    _sp.add_argument("--build", action="store_true", help="Build/rebuild images before starting")

    _sp = subparsers.add_parser(
        "init",
        help=(
            "First-time setup of a runtime workdir. Refuses if the target workdir is already initialized; "
            "use `kdcube refresh` for re-init."
        ),
    )
    _add_quiet_arg(_sp)
    _sp.add_argument(
        "--tenant",
        default="",
        help=(
            "Tenant name for the new runtime. With --project, composes the "
            "runtime path under the platform default base "
            "(~/.kdcube/kdcube-runtime/<tenant>__<project>). This is the "
            "recommended primary form."
        ),
    )
    _sp.add_argument(
        "--project",
        default="",
        help="Project name for the new runtime. Pair with --tenant.",
    )
    _sp.add_argument(
        "--workdir",
        default="",
        help=(
            "(Advanced) Fully-qualified namespaced runtime workdir to create "
            "(e.g. /opt/kdcube/<tenant>__<project>). Use when the runtime "
            "should live outside the default base."
        ),
    )
    _sp.add_argument(
        "--workdir-base",
        default="",
        help=(
            "(Advanced) Parent directory under which to create a new namespaced "
            "runtime. Requires --tenant and --project. Use only when the runtime "
            "should live outside the platform default base."
        ),
    )
    _sp.add_argument(
        "--path",
        default=str(DEFAULT_DIR),
        help="Local platform repo path. Without --upstream/--latest/--release, init copies this source into the runtime workdir.",
    )
    _sp.add_argument("--descriptors-location", default="", help="Directory containing the descriptor set")
    _sp.add_argument("--latest", action="store_true", help="Use the latest platform release")
    _sp.add_argument("--upstream", action="store_true", help="Use upstream repo state instead of assembly platform.ref")
    _sp.add_argument("--release", default="", help="Use a specific platform release ref")
    _sp.add_argument("--build", action="store_true", help="Build images after staging the runtime, without starting containers")
    _sp.add_argument(
        "--reset-config",
        action="store_true",
        help="Re-run config prompts and allow editing existing values",
    )
    _sp.add_argument(
        "--reset",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    _sp.add_argument(
        "--prompt-secrets",
        action="store_true",
        help="Prompt for standard secret values and stage them into config/secrets.yaml",
    )
    _sp.add_argument(
        "--set-secret",
        action="append",
        nargs=2,
        metavar=("KEY", "VALUE"),
        default=[],
        help="Stage one dotted secret key into config/secrets.yaml (repeatable)",
    )
    _sp.add_argument(
        "--cors-origin",
        action="append",
        metavar="ORIGIN",
        default=[],
        help="Append an allowed CORS origin to staged config/assembly.yaml (repeatable)",
    )
    _sp.add_argument(
        "-i",
        "--interactive",
        action="store_true",
        help="Prompt for required fields missing in the assembly instead of failing",
    )

    _sp = subparsers.add_parser(
        "refresh",
        help=(
            "Refresh an already-initialized runtime: rebuild images (with --build) "
            "and restart the stack. Never modifies staged descriptors."
        ),
    )
    _add_quiet_arg(_sp)
    _sp.add_argument(
        "--tenant",
        default="",
        help=(
            "Tenant name of the runtime to refresh. With --project, composes "
            "the runtime path under the platform default base "
            "(~/.kdcube/kdcube-runtime/<tenant>__<project>). This is the "
            "recommended primary form."
        ),
    )
    _sp.add_argument(
        "--project",
        default="",
        help="Project name of the runtime to refresh. Pair with --tenant.",
    )
    _sp.add_argument(
        "--workdir",
        default="",
        help=(
            "(Advanced) Fully-qualified namespaced runtime workdir to refresh. "
            "Use when the runtime lives outside the default base."
        ),
    )
    _sp.add_argument(
        "--workdir-base",
        default="",
        help=(
            "(Advanced) Parent directory under which the runtime lives. "
            "Requires --tenant and --project. Use only when the runtime is "
            "not under the platform default base."
        ),
    )
    _sp.add_argument(
        "--path",
        default=str(DEFAULT_DIR),
        help="Local platform repo path (used for rebuilding images). Defaults to install-meta.json's repo_root when omitted.",
    )
    _sp.add_argument("--latest", action="store_true", help="Refresh against the latest platform release advertised by the selected repo.")
    _sp.add_argument("--upstream", action="store_true", help="Refresh against origin/main of the selected platform repo.")
    _sp.add_argument("--release", default="", help="Refresh against a specific platform git ref/tag before rebuilding.")
    _sp.add_argument("--build", action="store_true", help="Rebuild platform Docker images before restarting.")
    _sp.add_argument(
        "--no-restart",
        action="store_true",
        help="Do not restart the stack after refresh (useful for build-only invocations).",
    )

    args = parser.parse_args()
    args.quiet = bool(_cli_explicit_quiet_requested(sys.argv[1:]) or getattr(args, "quiet", False))
    if args.quiet and not bool(getattr(args, "json_output", False)):
        console = Console(file=_NullWriter())

    def _arg_provided(name: str) -> bool:
        return any(arg == name or arg.startswith(f"{name}=") for arg in sys.argv[1:])

    if args.dry_run and (args.secrets_set or args.secrets_prompt):
        console.print("[yellow]Dry run ignores --secrets-set/--secrets-prompt (env generation only).[/yellow]")
        args.secrets_set = []
        args.secrets_prompt = False

    repo_path = Path(os.path.expanduser(args.path)).resolve()
    path_provided = _arg_provided("--path")
    workdir_arg = _arg_provided("--workdir")
    workdir = Path(os.path.expanduser(args.workdir or str(DEFAULT_WORKDIR))).expanduser().resolve()
    cli_defaults = _load_cli_defaults()
    if not workdir_arg and "default_workdir" in cli_defaults:
        workdir = Path(cli_defaults["default_workdir"]).resolve()
    implicit_descriptors_location: Path | None = None
    if (
        workdir_arg
        and not args.descriptors_location
        and not args.secrets_set
        and not args.secrets_prompt
    ):
        implicit_descriptors_location = _canonical_descriptor_dir_from_initialized_workdir(workdir)
    effective_descriptors_location = (
        Path(os.path.expanduser(args.descriptors_location)).expanduser().resolve()
        if args.descriptors_location
        else implicit_descriptors_location
    )
    try:
        if args.command == "defaults":
            updates: dict[str, str] = {}
            if args.default_tenant.strip():
                updates["default_tenant"] = args.default_tenant.strip()
            if args.default_project.strip():
                updates["default_project"] = args.default_project.strip()
            if args.default_workdir.strip():
                updates["default_workdir"] = str(
                    Path(os.path.expanduser(args.default_workdir)).resolve()
                )
            if not updates:
                raise SystemExit(
                    "Provide at least one of --default-tenant, --default-project, "
                    "or --default-workdir."
                )
            cli_defaults.update(updates)
            _save_cli_defaults(cli_defaults)
            console.print(f"[green]Defaults saved to {DEFAULT_DEFAULTS_FILE}:[/green]")
            for k, v in cli_defaults.items():
                console.print(f"  {k}: {v}")
            return
        if args.command == "clean":
            clean_docker_images(console)
            return
        if args.command == "info":
            _eff_tenant = str(args.tenant or cli_defaults.get("default_tenant", "") or "").strip() or None
            _eff_project = str(args.project or cli_defaults.get("default_project", "") or "").strip() or None
            if args.show_defaults:
                if args.json_output:
                    _print_json({"defaults": cli_defaults})
                    return
                console.print("[bold]KDCube CLI Defaults[/bold]")
                print_cli_defaults(console, cli_defaults)
                return
            if args.show_current_running_runtime:
                if args.json_output:
                    _print_json({"running_deployment": _collect_running_deployment_info()})
                    return
                print_running_deployment_info(console)
                return
            _workdir_str = str(args.workdir or "").strip()
            if _workdir_str:
                _workdir = Path(os.path.expanduser(args.workdir)).resolve()
                _resolved = _resolve_cli_workdir(_workdir, tenant=_eff_tenant, project=_eff_project)
                if not _runtime_env_exists(_resolved) and not (_resolved / "config").exists():
                    raise SystemExit(
                        f"Runtime workdir not found or not initialized: {_resolved}\n"
                        "Run `kdcube init` to initialize it first."
                    )
                _repo = _resolve_subcommand_repo(args.path, workdir=_resolved, path_provided=_arg_provided("--path"))
                if args.json_output:
                    _print_json(_collect_runtime_info(repo_root=_repo, workdir=_resolved))
                    return
                print_runtime_info(console, repo_root=_repo, workdir=_resolved)
            elif _arg_provided("--tenant") or _arg_provided("--project"):
                _def_base_raw = str(cli_defaults.get("default_workdir", "") or "").strip()
                _base = Path(_def_base_raw).expanduser().resolve() if _def_base_raw else DEFAULT_WORKDIR
                _workdir = installer_mod.workspace_runtime_dir(_base, _eff_tenant, _eff_project).resolve()
                if not _runtime_env_exists(_workdir) and not (_workdir / "config").exists():
                    raise SystemExit(
                        f"Runtime workdir not found or not initialized: {_workdir}\n"
                        "Run `kdcube init` to initialize it first."
                    )
                _repo = _resolve_subcommand_repo(args.path, workdir=_workdir, path_provided=_arg_provided("--path"))
                if args.json_output:
                    _print_json(_collect_runtime_info(repo_root=_repo, workdir=_workdir))
                    return
                print_runtime_info(console, repo_root=_repo, workdir=_workdir)
            else:
                if args.json_output:
                    payload: dict[str, object] = {
                        "defaults": cli_defaults,
                        "running_deployment": _collect_running_deployment_info(),
                    }
                    _def_base_raw = str(cli_defaults.get("default_workdir", "") or "").strip()
                    _def_tenant = str(cli_defaults.get("default_tenant", "") or "").strip() or None
                    _def_project = str(cli_defaults.get("default_project", "") or "").strip() or None
                    if _def_base_raw or _def_tenant or _def_project:
                        _def_base = Path(_def_base_raw).expanduser().resolve() if _def_base_raw else DEFAULT_WORKDIR
                        try:
                            _def_resolved = _resolve_cli_workdir(_def_base, tenant=_def_tenant, project=_def_project)
                        except SystemExit:
                            payload["default_runtime"] = None
                        else:
                            if _runtime_env_exists(_def_resolved) or (_def_resolved / "config").exists():
                                _def_repo = _resolve_subcommand_repo(args.path, workdir=_def_resolved, path_provided=_arg_provided("--path"))
                                payload["default_runtime"] = _collect_runtime_info(repo_root=_def_repo, workdir=_def_resolved)
                    _print_json(payload)
                    return
                print_global_info(console, cli_defaults)
                _def_base_raw = str(cli_defaults.get("default_workdir", "") or "").strip()
                _def_tenant = str(cli_defaults.get("default_tenant", "") or "").strip() or None
                _def_project = str(cli_defaults.get("default_project", "") or "").strip() or None
                if _def_base_raw or _def_tenant or _def_project:
                    _def_base = Path(_def_base_raw).expanduser().resolve() if _def_base_raw else DEFAULT_WORKDIR
                    try:
                        _def_resolved = _resolve_cli_workdir(_def_base, tenant=_def_tenant, project=_def_project)
                    except SystemExit:
                        pass
                    else:
                        if _runtime_env_exists(_def_resolved) or (_def_resolved / "config").exists():
                            _def_repo = _resolve_subcommand_repo(args.path, workdir=_def_resolved, path_provided=_arg_provided("--path"))
                            console.print()
                            print_runtime_info(console, repo_root=_def_repo, workdir=_def_resolved)
            return
        if args.command == "stop":
            # `kdcube stop` always targets a single deployment. When no flags
            # are given and there is no usable default, fall back to the
            # currently-recorded deployment in ~/.kdcube/cli-lock.json — it
            # is by definition the one that's running, so "stop with no args"
            # has the obvious meaning "stop what's running."
            _stop_tenant_arg = (getattr(args, "tenant", "") or "").strip()
            _stop_project_arg = (getattr(args, "project", "") or "").strip()
            _stop_workdir_arg = args.workdir
            _have_explicit_target = bool(
                (_stop_workdir_arg and str(_stop_workdir_arg).strip())
                or (_stop_tenant_arg and _stop_project_arg)
                or str(cli_defaults.get("default_workdir", "") or "").strip()
                or (
                    str(cli_defaults.get("default_tenant", "") or "").strip()
                    and str(cli_defaults.get("default_project", "") or "").strip()
                )
            )
            if not _have_explicit_target:
                _lock = _read_cli_lock()
                _lock_workdir = str((_lock or {}).get("workdir", "") or "").strip()
                if _lock_workdir:
                    console.print(
                        f"[dim]No --workdir/--tenant/--project passed; "
                        f"stopping currently-recorded deployment:[/dim] {_lock_workdir}"
                    )
                    _stop_workdir_arg = _lock_workdir
            _workdir = _resolve_subcommand_workdir(
                _stop_workdir_arg, cli_defaults,
                tenant_arg=_stop_tenant_arg,
                project_arg=_stop_project_arg,
            )
            _repo = _resolve_subcommand_repo(args.path, workdir=_workdir, path_provided=_arg_provided("--path"))
            stop_compose_stack(
                console,
                repo_root=_repo,
                workdir=_resolve_cli_workdir(_workdir),
                remove_volumes=args.remove_volumes,
            )
            return
        if args.command == "reload":
            _workdir = _resolve_subcommand_workdir(
                args.workdir, cli_defaults,
                tenant_arg=getattr(args, "tenant", "") or "",
                project_arg=getattr(args, "project", "") or "",
            )
            _repo = _resolve_subcommand_repo(args.path, workdir=_workdir, path_provided=_arg_provided("--path"))
            reload_bundle_from_descriptor(
                console,
                repo_root=_repo,
                workdir=_resolve_cli_workdir(_workdir),
                bundle_id=str(args.bundle_id).strip(),
                verbose=bool(args.verbose),
                json_output=bool(args.json_output),
                quiet=bool(args.quiet),
            )
            return
        if args.command == "bundle":
            _workdir = _resolve_subcommand_workdir(
                args.workdir, cli_defaults,
                tenant_arg=getattr(args, "tenant", "") or "",
                project_arg=getattr(args, "project", "") or "",
            )
            _resolved = _resolve_cli_workdir(_workdir)
            _bundle_arg = str(args.bundle_id or "").strip()
            _status_bundle_arg = str(args.status_bundle_id or "").strip()
            _has_bundle_patch_flags = any(
                [
                    args.local_path is not None,
                    args.git_repo is not None,
                    args.git_ref is not None,
                    args.git_subdir is not None,
                    args.name is not None,
                    args.module is not None,
                    args.singleton is not None,
                    bool(args.set_config or []),
                    bool(args.set_secret or []),
                    bool(args.del_config or []),
                    bool(args.del_secret or []),
                    bool(args.delete),
                ]
            )
            if _bundle_arg == "reload":
                if not _status_bundle_arg:
                    raise SystemExit("Usage: kdcube bundle reload <bundle_id> --workdir <workdir>")
                if _has_bundle_patch_flags:
                    raise SystemExit("`kdcube bundle reload` cannot be combined with bundle mutation flags.")
                if args.live_status:
                    raise SystemExit("--live is only supported with `kdcube bundle status <bundle_id>`.")
                if args.descriptors_location or args.dry_run or args.reload_changed:
                    raise SystemExit(
                        "--descriptors-location, --dry-run, and --reload are only supported with "
                        "`kdcube bundle config apply`."
                    )
                _repo = _resolve_subcommand_repo(args.path, workdir=_resolved, path_provided=_arg_provided("--path"))
                reload_bundle_from_descriptor(
                    console,
                    repo_root=_repo,
                    workdir=_resolved,
                    bundle_id=_status_bundle_arg,
                    verbose=bool(args.verbose),
                    json_output=bool(args.json_output),
                    quiet=bool(args.quiet),
                )
                return
            if _bundle_arg == "config":
                if _status_bundle_arg != "apply":
                    raise SystemExit(
                        "Usage: kdcube bundle config apply "
                        "--descriptors-location <dir> --workdir <workdir> [--dry-run] [--reload]"
                    )
                if _has_bundle_patch_flags:
                    raise SystemExit("`kdcube bundle config apply` cannot be combined with bundle mutation flags.")
                if args.live_status:
                    raise SystemExit("--live is only supported with `kdcube bundle status <bundle_id>`.")
                if not str(args.descriptors_location or "").strip():
                    raise SystemExit("--descriptors-location is required with `kdcube bundle config apply`.")
                _repo = None
                if args.reload_changed:
                    _repo = _resolve_subcommand_repo(args.path, workdir=_resolved, path_provided=_arg_provided("--path"))
                _result = apply_bundle_config_descriptors(
                    console,
                    workdir=_resolved,
                    descriptors_location=Path(str(args.descriptors_location)),
                    dry_run=bool(args.dry_run),
                    reload_changed=bool(args.reload_changed),
                    repo_root=_repo,
                    verbose=bool(args.verbose),
                    quiet=bool(args.quiet or args.json_output),
                )
                if args.json_output:
                    _print_json(_result)
                return
            if _bundle_arg == "status":
                if not _status_bundle_arg:
                    raise SystemExit("Usage: kdcube bundle status <bundle_id> --workdir <workdir>")
                if any(
                    [
                        args.local_path is not None,
                        args.git_repo is not None,
                        args.git_ref is not None,
                        args.git_subdir is not None,
                        args.name is not None,
                        args.module is not None,
                        args.singleton is not None,
                        bool(args.set_config or []),
                        bool(args.set_secret or []),
                        bool(args.del_config or []),
                        bool(args.del_secret or []),
                        bool(args.delete),
                        bool(args.descriptors_location),
                        bool(args.dry_run),
                        bool(args.reload_changed),
                    ]
                ):
                    raise SystemExit("`kdcube bundle status` cannot be combined with mutation flags.")
                _repo = _resolve_subcommand_repo(args.path, workdir=_resolved, path_provided=_arg_provided("--path"))
                _status = _collect_bundle_status(
                    repo_root=_repo,
                    workdir=_resolved,
                    bundle_id=_status_bundle_arg,
                    include_live=True,
                    include_live_manifest=bool(args.live_status),
                )
                if args.json_output:
                    _print_json(_status)
                else:
                    print_bundle_status(console, _status)
                return
            if _status_bundle_arg:
                raise SystemExit(
                    f"Unexpected extra argument {_status_bundle_arg!r}. "
                    "Use `kdcube bundle status <bundle_id>` for status checks."
                )
            if args.json_output:
                raise SystemExit("--json is only supported with `kdcube bundle status`, `kdcube bundle reload`, or `kdcube bundle config apply`.")
            if args.live_status:
                raise SystemExit("--live is only supported with `kdcube bundle status <bundle_id>`.")
            if args.descriptors_location or args.dry_run or args.reload_changed:
                raise SystemExit(
                    "--descriptors-location, --dry-run, and --reload are only supported with "
                    "`kdcube bundle config apply`."
                )
            if not _bundle_arg:
                raise SystemExit(
                    "Bundle ID is required. Use `kdcube bundle <bundle_id> --...` or "
                    "`kdcube bundle status <bundle_id>`."
                )
            _config_dir = _resolved / "config"
            _bundles_path = _config_dir / "bundles.yaml"
            _bundles_secrets_path = _config_dir / "bundles.secrets.yaml"

            if not _bundles_path.exists():
                raise SystemExit(
                    f"bundles.yaml not found at {_bundles_path}.\n"
                    "Initialize the workdir first."
                )

            _bundle_id = _bundle_arg
            _local_path: str | None = args.local_path
            _git_repo: str | None = args.git_repo
            _git_ref: str | None = args.git_ref
            _git_subdir: str | None = args.git_subdir
            _b_name: str | None = args.name
            _b_module: str | None = args.module
            _b_singleton: bool | None = args.singleton
            _set_config_ops: list[list[str]] = args.set_config or []
            _set_secret_ops: list[list[str]] = args.set_secret or []
            _del_config_ops: list[str] = args.del_config or []
            _del_secret_ops: list[str] = args.del_secret or []
            _delete: bool = args.delete

            _has_source_op = _local_path is not None or _git_repo is not None
            _has_identity_op = _b_name is not None or _b_module is not None or _b_singleton is not None
            _has_config_op = bool(_set_config_ops or _del_config_ops)
            _has_secret_op = bool(_set_secret_ops or _del_secret_ops)

            if _git_subdir is not None and _git_repo is None:
                raise SystemExit("--git-subdir can only be used together with --git-repo.")

            if _delete and any([_has_source_op, _has_identity_op, _has_config_op, _has_secret_op]):
                raise SystemExit("--delete cannot be combined with other flags.")

            if not any([_delete, _has_source_op, _has_identity_op, _has_config_op, _has_secret_op]):
                raise SystemExit(
                    "No operations specified. Use --local-path, --git-repo, --name, --module, "
                    "--singleton/--no-singleton, --set-config, --set-secret, --del-config, --del-secret, or --delete."
                )

            if _git_repo is not None and not _git_ref:
                raise SystemExit("--git-ref is required when --git-repo is specified.")

            if _delete:
                _bundles_data = installer_mod.load_release_descriptor(_bundles_path)
                _b_block = _bundles_data.get("bundles") if isinstance(_bundles_data, dict) else None
                _b_items = _b_block.get("items", []) if isinstance(_b_block, dict) else []
                _b_idx = next(
                    (i for i, it in enumerate(_b_items) if isinstance(it, dict) and str(it.get("id", "")) == _bundle_id),
                    None,
                )
                if _b_idx is None:
                    raise SystemExit(f"Bundle '{_bundle_id}' not found in {_bundles_path}")
                del _b_items[_b_idx]
                installer_mod.save_release_descriptor(_bundles_path, _bundles_data)
                console.print(f"[green]Removed from bundles.yaml:[/green] {_bundle_id!r}")
                _bs_idx = None
                _bs_items = []
                _bs_data = None
                if _bundles_secrets_path.exists():
                    _bs_data = installer_mod.load_release_descriptor(_bundles_secrets_path)
                    _bs_block = _bs_data.get("bundles") if isinstance(_bs_data, dict) else None
                    _bs_items = _bs_block.get("items", []) if isinstance(_bs_block, dict) else []
                    _bs_idx = next(
                        (i for i, it in enumerate(_bs_items) if isinstance(it, dict) and str(it.get("id", "")) == _bundle_id),
                        None,
                    )
                if _bs_idx is not None:
                    del _bs_items[_bs_idx]
                    if _bs_data is not None:
                        installer_mod.save_release_descriptor(_bundles_secrets_path, _bs_data)
                    console.print(f"[green]Removed from bundles.secrets.yaml:[/green] {_bundle_id!r}")
                _print_bundle_apply_hint(console, _bundle_id, _resolved)
                return

            # --- bundles.yaml operations (source mode + identity + config) ---
            if _has_source_op or _has_identity_op or _has_config_op:
                _bundles_data = installer_mod.load_release_descriptor(_bundles_path)
                _b_block = _bundles_data.get("bundles") if isinstance(_bundles_data, dict) else None
                _b_items = _b_block.get("items", []) if isinstance(_b_block, dict) else []
                _b_item = next(
                    (it for it in _b_items if isinstance(it, dict) and str(it.get("id", "")) == _bundle_id),
                    None,
                )
                if _b_item is None:
                    if not _has_source_op:
                        raise SystemExit(
                            f"Bundle '{_bundle_id}' not found in {_bundles_path}. "
                            "Provide --local-path or --git-repo to create a new entry."
                        )
                    _b_item = {"id": _bundle_id}
                    if isinstance(_b_block, dict):
                        _b_block.setdefault("items", []).append(_b_item)
                    console.print(f"[dim]creating new bundle entry[/dim] {_bundle_id!r}")

                if _local_path is not None:
                    _runtime_path, _path_mode = _resolve_bundle_local_path_for_runtime(_local_path, _resolved)
                    _b_item["path"] = _runtime_path
                    for _stale in ("repo", "ref", "subdir"):
                        _b_item.pop(_stale, None)
                    if _path_mode == "translated":
                        console.print(
                            f"[dim]set source[/dim] local-path = {_runtime_path!r} "
                            f"[dim](translated from host path {_local_path!r})[/dim]"
                        )
                    else:
                        console.print(
                            f"[dim]set source[/dim] local-path = {_runtime_path!r} "
                            "[dim](already runtime-visible)[/dim]"
                        )

                if _git_repo is not None:
                    _b_item["repo"] = _git_repo
                    _b_item["ref"] = _git_ref
                    if _git_subdir is not None:
                        _b_item["subdir"] = _git_subdir
                    else:
                        _b_item.pop("subdir", None)
                    _b_item.pop("path", None)
                    console.print(f"[dim]set source[/dim] git-repo = {_git_repo!r} ref = {_git_ref!r}")
                    if _git_subdir:
                        console.print(f"[dim]set source[/dim] git-subdir = {_git_subdir!r}")

                if _b_name is not None:
                    _b_item["name"] = _b_name
                    console.print(f"[dim]set name[/dim] {_b_name!r}")

                if _b_module is not None:
                    _b_item["module"] = _b_module
                    console.print(f"[dim]set module[/dim] {_b_module!r}")
                elif "module" not in _b_item:
                    _b_item["module"] = "entrypoint"

                if _b_singleton is not None:
                    _b_item["singleton"] = _b_singleton
                    console.print(f"[dim]set singleton[/dim] {_b_singleton!r}")
                elif "singleton" not in _b_item:
                    _b_item["singleton"] = False

                if _has_config_op:
                    _cfg = _b_item.setdefault("config", {})
                    if not isinstance(_cfg, dict):
                        _cfg = {}
                        _b_item["config"] = _cfg
                    for _key, _raw in _set_config_ops:
                        _val = _parse_yaml_scalar(_raw)
                        installer_mod._set_nested(_cfg, _key.split("."), _val)
                        console.print(f"[dim]set config[/dim] {_key} = {_val!r}")
                    for _key in _del_config_ops:
                        _parts = _key.split(".")
                        if not _nested_key_exists(_cfg, _parts):
                            raise SystemExit(f"Config key '{_key}' not found in bundle '{_bundle_id}'")
                        installer_mod._delete_nested(_cfg, _parts)
                        console.print(f"[dim]del config[/dim] {_key}")

                installer_mod.save_release_descriptor(_bundles_path, _bundles_data)
                console.print(f"[green]Updated:[/green] {_bundles_path}")

            if _set_secret_ops or _del_secret_ops:
                _bs_data = (
                    installer_mod.load_release_descriptor(_bundles_secrets_path)
                    if _bundles_secrets_path.exists()
                    else {"bundles": {"version": "1", "items": []}}
                )
                _bs_block = _bs_data.setdefault("bundles", {})
                if not isinstance(_bs_block, dict):
                    _bs_block = {}
                    _bs_data["bundles"] = _bs_block
                _bs_items = _bs_block.setdefault("items", [])
                if not isinstance(_bs_items, list):
                    _bs_items = []
                    _bs_block["items"] = _bs_items
                _bs_item = next(
                    (it for it in _bs_items if isinstance(it, dict) and str(it.get("id", "")) == _bundle_id),
                    None,
                )
                if _bs_item is None:
                    _bs_item = {"id": _bundle_id, "secrets": {}}
                    _bs_items.append(_bs_item)
                _sec = _bs_item.setdefault("secrets", {})
                if not isinstance(_sec, dict):
                    _sec = {}
                    _bs_item["secrets"] = _sec
                for _key, _raw in _set_secret_ops:
                    _val = _parse_yaml_scalar(_raw)
                    installer_mod._set_nested(_sec, _key.split("."), _val)
                    console.print(f"[dim]set secret[/dim] {_key}")
                for _key in _del_secret_ops:
                    _parts = _key.split(".")
                    if not _nested_key_exists(_sec, _parts):
                        raise SystemExit(f"Secret key '{_key}' not found in bundle '{_bundle_id}'")
                    installer_mod._delete_nested(_sec, _parts)
                    console.print(f"[dim]del secret[/dim] {_key}")
                installer_mod.save_release_descriptor(_bundles_secrets_path, _bs_data)
                console.print(f"[green]Updated:[/green] {_bundles_secrets_path}")

            _print_bundle_apply_hint(console, _bundle_id, _resolved)
            return
        if args.command == "export":
            _workdir = _resolve_subcommand_workdir(
                args.workdir, cli_defaults,
                tenant_arg=getattr(args, "tenant", "") or "",
                project_arg=getattr(args, "project", "") or "",
            )
            _repo = _resolve_subcommand_repo(args.path, workdir=_workdir, path_provided=_arg_provided("--path"))
            _resolved = _resolve_cli_workdir(_workdir)
            _out_dir = Path(os.path.expanduser(args.out_dir or os.getcwd())).resolve()
            _bundles_path: Path | None = None
            _bundles_secrets_path: Path | None = None
            try:
                _ctx = _build_paths_for_repo(_repo, _resolved)
                _env_main = _ctx.config_dir / ".env"
                _env_proc = _ctx.config_dir / ".env.proc"
                if _env_main.exists() and _env_proc.exists():
                    _sources = _resolve_live_bundle_export_sources(
                        installer_mod.load_env_file(_env_main),
                        installer_mod.load_env_file(_env_proc),
                    )
                    if _sources is not None:
                        _bundles_path, _bundles_secrets_path = _sources
            except SystemExit:
                raise
            except Exception:
                pass
            export_live_bundle_descriptors(
                console,
                tenant=str(args.tenant or cli_defaults.get("default_tenant", "") or "").strip(),
                project=str(args.project or cli_defaults.get("default_project", "") or "").strip(),
                out_dir=_out_dir,
                aws_region=str(args.aws_region or "").strip() or None,
                aws_profile=str(args.aws_profile or "").strip() or None,
                aws_sm_prefix=str(args.aws_sm_prefix or "").strip() or None,
                bundles_path=_bundles_path,
                bundles_secrets_path=_bundles_secrets_path,
            )
            return
        if args.command == "start":
            _workdir = _resolve_subcommand_workdir(
                args.workdir, cli_defaults,
                tenant_arg=getattr(args, "tenant", "") or "",
                project_arg=getattr(args, "project", "") or "",
            )
            _resolved = _resolve_cli_workdir(_workdir)
            _repo = _resolve_subcommand_repo(args.path, workdir=_resolved, path_provided=_arg_provided("--path"))
            _t, _p = _parse_workdir_namespace(_resolved)
            _check_before_start(console, tenant=_t, project=_p)
            start_compose_stack(console, repo_root=_repo, workdir=_resolved, build=args.build)
            return
        if args.command == "refresh":
            # `kdcube refresh` is the re-init / pick-up-platform-changes
            # command. It operates only on an already-initialized runtime
            # workdir and NEVER touches staged descriptors.
            #
            # Primary invocation (uses platform default base):
            #   kdcube refresh --tenant T --project P --build
            #
            # When no flags and no defaults are present, refresh falls back
            # to the currently-recorded deployment in ~/.kdcube/cli-lock.json
            # so `kdcube refresh --build` after editing platform code "just
            # works" against the running runtime.
            #
            # Behaviour:
            #   1. Resolve the target workdir (--tenant/--project compose
            #      under DEFAULT_WORKDIR; or --workdir / --workdir-base for
            #      explicit non-default forms; or cli-lock fallback).
            #   2. Refuse if the workdir is not initialized
            #      (no install-meta.json or missing canonical descriptors).
            #   3. Stop the stack if it is running.
            #   4. If --build, rebuild platform Docker images from the staged
            #      repo (or from --path).
            #   5. Unless --no-restart, start the stack again.
            _refresh_workdir_arg = args.workdir or ""
            _refresh_tenant_arg = (args.tenant or "").strip()
            _refresh_project_arg = (args.project or "").strip()
            _refresh_workdir_base_arg = (getattr(args, "workdir_base", "") or "").strip()
            _have_explicit_target = bool(
                str(_refresh_workdir_arg).strip()
                or _refresh_workdir_base_arg
                or (_refresh_tenant_arg and _refresh_project_arg)
                or str(cli_defaults.get("default_workdir", "") or "").strip()
                or (
                    str(cli_defaults.get("default_tenant", "") or "").strip()
                    and str(cli_defaults.get("default_project", "") or "").strip()
                )
            )
            if not _have_explicit_target:
                _lock = _read_cli_lock()
                _lock_workdir = str((_lock or {}).get("workdir", "") or "").strip()
                if _lock_workdir:
                    console.print(
                        f"[dim]No --workdir/--tenant/--project passed; "
                        f"refreshing currently-recorded deployment:[/dim] {_lock_workdir}"
                    )
                    _refresh_workdir_arg = _lock_workdir
            _resolved, _refresh_tenant, _refresh_project = (
                _resolve_namespaced_runtime_target(
                    workdir_arg=_refresh_workdir_arg,
                    workdir_base_arg=_refresh_workdir_base_arg,
                    tenant_arg=_refresh_tenant_arg,
                    project_arg=_refresh_project_arg,
                    cli_defaults=cli_defaults,
                    prefer_existing=True,
                )
            )
            _refresh_reuse_config = _canonical_descriptor_dir_from_initialized_workdir(_resolved)
            if _refresh_reuse_config is None:
                raise SystemExit(
                    f"Workdir is not initialized: {_resolved}\n"
                    "`kdcube refresh` only operates on a runtime that was previously created "
                    "by `kdcube init`. Either:\n"
                    "  - run `kdcube init --tenant T --project P` to set this workdir up, or\n"
                    "  - target a different existing initialized runtime."
                )
            _refresh_path_provided = _arg_provided("--path")
            _refresh_release = str(getattr(args, "release", "") or "").strip()
            _refresh_version_selector = bool(args.latest or args.upstream or _refresh_release)
            if sum([bool(args.latest), bool(args.upstream), bool(_refresh_release)]) > 1:
                raise SystemExit("Choose only one of --latest, --upstream, or --release.")

            _repo = _resolve_subcommand_repo(args.path, workdir=_resolved, path_provided=_refresh_path_provided)
            if _refresh_version_selector:
                if not _is_git_repo(_repo):
                    raise SystemExit(
                        f"Cannot use --latest/--upstream/--release with a non-git platform source tree: {_repo}"
                    )
                if args.upstream:
                    _checkout_repo_upstream(console, _repo)
                elif args.latest:
                    _latest_ref = _read_remote_ref(_repo) or _read_local_ref(_repo)
                    if not _latest_ref:
                        raise SystemExit(
                            "Could not resolve the latest platform release. "
                            "Check platform.repo or pass --release <ref>."
                        )
                    _checkout_repo_ref(console, _repo, _latest_ref)
                else:
                    _checkout_repo_ref(console, _repo, _refresh_release)
                if _repo.resolve() != _default_repo_path_for_workdir(_resolved).resolve():
                    _repo = _copy_dirty_local_source(
                        console,
                        source_repo=_repo,
                        workdir=_resolved,
                    )
            elif _refresh_path_provided:
                _repo = _copy_dirty_local_source(
                    console,
                    source_repo=_repo,
                    workdir=_resolved,
                )
            _t, _p = _parse_workdir_namespace(_resolved)
            # Stop if running (no-op if already stopped).
            try:
                stop_compose_stack(console, repo_root=_repo, workdir=_resolved)
            except SystemExit as _stop_exit:
                _stop_msg = str(_stop_exit)
                if "Deployment is not running" in _stop_msg:
                    _clear_cli_lock()
                    console.print(
                        f"[dim]Refresh: deployment was already stopped; continuing. Workdir: {_resolved}[/dim]"
                    )
                else:
                    # stop_compose_stack already prints; re-raise so the user sees it.
                    raise
            except Exception as _stop_exc:
                console.print(
                    f"[yellow]Refresh: stop_compose_stack reported {_stop_exc}; "
                    "continuing anyway.[/yellow]"
                )
            if args.build:
                build_compose_images(console, repo_root=_repo, workdir=_resolved)
            if not args.no_restart:
                _check_before_start(console, tenant=_t, project=_p)
                start_compose_stack(console, repo_root=_repo, workdir=_resolved, build=False)
            else:
                console.print(
                    "[dim]Refresh: --no-restart set; not starting the stack. "
                    f"Run `kdcube start --workdir {_resolved}` when ready.[/dim]"
                )
            return
        if args.command == "init":
            _init_path_provided = bool(_arg_provided("--path"))
            _init_repo = Path(os.path.expanduser(args.path)).resolve()
            _init_descriptors_location: Path | None = None
            _init_version_selector = bool(args.upstream or args.latest or str(args.release or "").strip())
            if sum([bool(args.latest), bool(args.upstream), bool(str(args.release or "").strip())]) > 1:
                raise SystemExit("Choose only one of --latest, --upstream, or --release.")
            _init_local_source_copy = _init_path_provided and not _init_version_selector

            # === Resolve target workdir under the strict contract. ===
            #
            # `kdcube init` is *first-time setup only*. It always lands on a
            # fully-qualified namespaced runtime path
            # `<base>/<tenant>__<project>`. See _resolve_namespaced_runtime_target
            # for the four supported input shapes. The most common shape is
            #
            #   kdcube init --tenant T --project P
            #
            # which composes the path under the platform default base
            # (~/.kdcube/kdcube-runtime). `--workdir <full>` and
            # `--workdir-base <base> --tenant T --project P` are advanced
            # forms for non-default placement.
            #
            # If the resolved target already has `install-meta.json` (i.e. a
            # previous successful init), `init` refuses with a clear error
            # pointing the user at `kdcube refresh`. This prevents the
            # silent-clobber bug where `init` would reseed descriptors on top
            # of a working runtime.
            _init_resolved, _init_preset_tenant, _init_preset_project = (
                _resolve_namespaced_runtime_target(
                    workdir_arg=args.workdir or "",
                    workdir_base_arg=getattr(args, "workdir_base", "") or "",
                    tenant_arg=args.tenant or "",
                    project_arg=args.project or "",
                    cli_defaults=cli_defaults,
                )
            )
            console.print(
                f"[dim]Target runtime workdir:[/dim] {_init_resolved}"
            )

            # Refusal guard: if the resolved workdir is already an initialized
            # runtime (has install-meta.json), `kdcube init` will NOT reseed
            # descriptors over it. This is the load-bearing fix for N9.
            _existing_meta = _read_install_meta_raw(_init_resolved) if _init_resolved.exists() else None
            if _existing_meta is not None:
                raise SystemExit(
                    f"An initialized runtime already exists at:\n"
                    f"  {_init_resolved}\n"
                    "`kdcube init` is for first-time setup only and refuses to overwrite "
                    "staged descriptors.\n\n"
                    "If you want to rebuild platform images / restart on this workdir, run:\n"
                    f"  kdcube refresh --workdir {_init_resolved}{' --build' if args.build else ''}\n\n"
                    "If you really want to recreate from scratch, remove the workdir first:\n"
                    f"  rm -rf {_init_resolved}\n"
                    "and then re-run kdcube init."
                )

            # Initial workdir is created from here on.
            _init_workdir = _init_resolved
            if str(args.descriptors_location or "").strip():
                _init_descriptors_location = Path(
                    os.path.expanduser(args.descriptors_location)
                ).resolve()
            else:
                # Fresh init without descriptors: bootstrap the platform repo
                # under <workdir>/repo and use its deployment/ directory as the
                # descriptor source.
                _init_resolved.mkdir(parents=True, exist_ok=True)
                _repo_target = _init_repo if _init_path_provided else _init_resolved / DEFAULT_REPO_DIRNAME
                _init_repo, _init_descriptors_location = _bootstrap_repo_for_defaults(
                    console,
                    repo=args.repo,
                    repo_path=_repo_target,
                    path_provided=_init_path_provided,
                )
                console.print(
                    f"[dim]No --descriptors-location provided. "
                    f"Using repo defaults from:[/dim] {_init_descriptors_location}"
                )
                if not _init_version_selector:
                    # No explicit version selector: default to latest release.
                    args.latest = True

            # For --interactive: prompt tenant/project BEFORE resolving/creating the workdir
            # so the directory is created with the correct namespace from the start.
            # Skipped when tenant/project were already collected in the no-descriptors path above.
            if args.interactive and _init_preset_tenant is None:
                _src_assembly = installer_mod.load_release_descriptor_soft(
                    _init_descriptors_location / "assembly.yaml"
                ) or {}
                _t_default, _p_default = installer_mod.descriptor_context_from_assembly(_src_assembly)
                _init_preset_tenant = installer_mod.ask(
                    console, "Tenant ID", default=_t_default or "default"
                )
                _init_preset_project = installer_mod.ask(
                    console, "Project name", default=_p_default or "default"
                )

            if _init_resolved is None:
                if _init_preset_tenant and _init_preset_project:
                    _init_resolved = installer_mod.workspace_runtime_dir(
                        _init_workdir, _init_preset_tenant, _init_preset_project
                    ).resolve()
                else:
                    _init_resolved = _resolve_cli_workdir(
                        _init_workdir, descriptors_location=_init_descriptors_location
                    )

            if str(args.descriptors_location or "").strip():
                _init_repo = _resolve_cli_repo_path(
                    _init_repo,
                    workdir=_init_resolved,
                    path_provided=_init_path_provided,
                    descriptors_location=_init_descriptors_location,
                )
            if _init_local_source_copy:
                _init_repo = _copy_dirty_local_source(
                    console,
                    source_repo=_init_repo,
                    workdir=_init_resolved,
                )
                _init_path_provided = True

            _descriptor_bootstrap = _stage_descriptor_set(
                repo_root=_init_repo,
                workdir=_init_resolved,
                descriptors_location=_init_descriptors_location,
            )
            _added_cors_origins = _apply_cors_origins(
                _descriptor_bootstrap["assembly"],
                list(args.cors_origin or []),
            )
            if _added_cors_origins:
                installer_mod.save_release_descriptor(
                    _descriptor_bootstrap["assembly_path"],
                    _descriptor_bootstrap["assembly"],
                )
                console.print(
                    "[dim]Added CORS origins to config/assembly.yaml:[/dim] "
                    + ", ".join(_added_cors_origins)
                )
            _init_runtime_secrets = _parse_init_secret_pairs(args.set_secret)
            if args.prompt_secrets and not args.interactive:
                _init_runtime_secrets = _prompt_init_standard_secrets(console, _init_runtime_secrets)
            if _init_runtime_secrets:
                installer_mod.apply_runtime_secrets_to_file_descriptors(
                    config_dir=_init_resolved / "config",
                    runtime_secrets=_init_runtime_secrets,
                )
                console.print("[dim]Staged init secrets into config/secrets.yaml.[/dim]")

            if _init_preset_tenant and _init_preset_project:
                os.environ["KDCUBE_PRESET_TENANT"] = _init_preset_tenant
                os.environ["KDCUBE_PRESET_PROJECT"] = _init_preset_project

            # From this point on, the canonical descriptor set for this init run is
            # the staged workdir/config copy. CLI overrides such as --set-secret are
            # applied there; pointing the installer back at the original descriptor
            # directory would restage the pristine files and erase those overrides.
            os.environ["KDCUBE_DESCRIPTORS_LOCATION"] = str((_init_resolved / "config").resolve())
            os.environ["KDCUBE_ASSEMBLY_DESCRIPTOR_PATH"] = str(_descriptor_bootstrap["assembly_path"])
            os.environ["KDCUBE_ASSEMBLY_USER_SUPPLIED"] = (
                "0"
                if _init_descriptors_location.resolve() == (_init_resolved / "config").resolve()
                else "1"
            )
            if _descriptor_bootstrap["secrets_path"]:
                os.environ["KDCUBE_SECRETS_DESCRIPTOR_PATH"] = str(_descriptor_bootstrap["secrets_path"])
            if _descriptor_bootstrap["gateway_path"]:
                os.environ["KDCUBE_GATEWAY_DESCRIPTOR_PATH"] = str(_descriptor_bootstrap["gateway_path"])
            if _descriptor_bootstrap["bundles_path"]:
                os.environ["KDCUBE_BUNDLES_DESCRIPTOR_PATH"] = str(_descriptor_bootstrap["bundles_path"])
            if _descriptor_bootstrap["bundles_secrets_path"]:
                os.environ["KDCUBE_BUNDLES_SECRETS_PATH"] = str(_descriptor_bootstrap["bundles_secrets_path"])
            _init_assembly = _descriptor_bootstrap["assembly"]
            os.environ["KDCUBE_ASSEMBLY_USE_BUNDLES"] = "1" if bool(_get_nested(_init_assembly, "bundles")) else "0"
            os.environ["KDCUBE_ASSEMBLY_USE_FRONTEND"] = "1" if bool(_get_nested(_init_assembly, "frontend")) else "0"
            os.environ["KDCUBE_ASSEMBLY_USE_PLATFORM"] = "0"
            os.environ["KDCUBE_USE_BUNDLES_DESCRIPTOR"] = "1" if _descriptor_bootstrap["bundles_path"] else "0"
            os.environ["KDCUBE_USE_BUNDLES_SECRETS"] = "1" if _descriptor_bootstrap["bundles_secrets_path"] else "0"

            if not _init_local_source_copy:
                _ensure_descriptor_platform_repo(
                    console,
                    repo_path=_init_repo,
                    path_provided=_init_path_provided,
                    assembly=_init_assembly,
                    fallback_repo=args.repo,
                )

            if _init_version_selector and not _is_git_repo(_init_repo):
                raise SystemExit(
                    f"Cannot use --upstream/--latest/--release with a local source tree at {_init_repo} (not a git repo root).\n"
                    f"Remove {_init_repo} and re-run, or use --path to point to a git repo."
                )

            _init_release_ref: str | None = None
            _init_mode = "release"
            if args.upstream:
                _init_release_ref = _checkout_repo_upstream(console, _init_repo)
                _init_mode = "upstream"
            elif args.latest:
                _init_release_ref = _read_remote_ref(_init_repo) or _read_local_ref(_init_repo)
                if not _init_release_ref:
                    raise SystemExit(
                        "Could not resolve the latest platform release. "
                        "Check platform.repo or pass a repo that contains release.yaml."
                    )
            elif str(args.release or "").strip():
                _init_release_ref = str(args.release).strip()
            else:
                _init_release_ref = (
                    str(_get_nested(_init_assembly, "platform", "ref") or "").strip() or None
                )
                if not _init_release_ref:
                    raise SystemExit(
                        "assembly platform.ref is required unless --latest, --upstream, or --release is used."
                    )

            if _init_local_source_copy:
                _init_mode = "skip"
            if args.build:
                if not args.upstream and not _init_local_source_copy:
                    _checkout_repo_ref(console, _init_repo, _init_release_ref)
                if _init_mode != "upstream":
                    _init_mode = "skip"
            elif not _init_path_provided and not args.upstream and not _init_local_source_copy:
                _checkout_repo_ref(console, _init_repo, _init_release_ref)

            if args.reset_config or args.reset:
                os.environ["KDCUBE_RESET_CONFIG"] = "1"
            if not args.interactive:
                os.environ["KDCUBE_CLI_NONINTERACTIVE"] = "1"
            os.environ["KDCUBE_INIT_PREPARE_ONLY"] = "1"
            run_installer(console, _init_repo, _init_resolved, _init_mode, _init_release_ref, None, True)
            if args.build:
                build_compose_images(console, repo_root=_init_repo, workdir=_init_resolved)
            return
        if args.clean:
            clean_docker_images(console)
            return
        selected_version_flags = int(bool(args.latest)) + int(bool(args.upstream)) + int(bool(str(args.release or "").strip()))
        if selected_version_flags > 1:
            raise SystemExit("Choose only one of --latest, --upstream, or --release.")
        if args.proxy_ssl and args.no_proxy_ssl:
            raise SystemExit("Choose only one of --proxy-ssl or --no-proxy-ssl.")
        if args.proxy_ssl:
            os.environ["KDCUBE_PROXY_SSL"] = "1"
        elif args.no_proxy_ssl:
            os.environ["KDCUBE_PROXY_SSL"] = "0"
        if args.dry_run_print_env:
            os.environ["KDCUBE_DRY_RUN_PRINT_ENV"] = "1"
        # No-descriptors fast path: when a source selector is given without
        # --descriptors-location (and no initialized workdir was found), bootstrap
        # the platform repo and use its deployment/ directory as the descriptor
        # source.  This lets operators run e.g. ``kdcube --upstream``
        # without pre-preparing a descriptor set.
        if (
            effective_descriptors_location is None
            and not args.secrets_set
            and not args.secrets_prompt
            and (args.latest or args.upstream or str(args.release or "").strip() or args.build)
        ):
            repo_path, effective_descriptors_location = _bootstrap_repo_for_defaults(
                console,
                repo=args.repo,
                repo_path=repo_path,
                path_provided=path_provided,
            )
            path_provided = True
            console.print(
                f"[dim]No --descriptors-location provided. "
                f"Using repo defaults from:[/dim] {effective_descriptors_location}"
            )

        if (
            not args.secrets_set
            and not args.secrets_prompt
            and effective_descriptors_location is None
            and not (args.dry_run and workdir_arg)
        ):
            workdir = Path(
                Prompt.ask("Compose workdir (config+data root)", default=str(workdir))
            ).expanduser().resolve()

        descriptor_bootstrap = None
        if effective_descriptors_location is not None and not args.secrets_set and not args.secrets_prompt:
            descriptors_location = effective_descriptors_location
            workdir = _resolve_cli_workdir(workdir, descriptors_location=descriptors_location)
            repo_path = _resolve_cli_repo_path(
                repo_path,
                workdir=workdir,
                path_provided=path_provided,
                descriptors_location=descriptors_location,
            )
            os.environ["KDCUBE_DESCRIPTORS_LOCATION"] = str(descriptors_location)
            descriptor_bootstrap = _stage_descriptor_set(
                repo_root=repo_path,
                workdir=workdir,
                descriptors_location=descriptors_location,
            )
            assembly_path = descriptor_bootstrap["assembly_path"]
            secrets_path = descriptor_bootstrap["secrets_path"]
            gateway_path = descriptor_bootstrap["gateway_path"]
            bundles_path = descriptor_bootstrap["bundles_path"]
            bundles_secrets_path = descriptor_bootstrap["bundles_secrets_path"]
            assembly = descriptor_bootstrap["assembly"]
            descriptor_is_runtime_config = descriptors_location.resolve() == (workdir / "config").resolve()

            os.environ["KDCUBE_ASSEMBLY_DESCRIPTOR_PATH"] = str(assembly_path)
            os.environ["KDCUBE_ASSEMBLY_USER_SUPPLIED"] = "0" if descriptor_is_runtime_config else "1"
            if secrets_path:
                os.environ["KDCUBE_SECRETS_DESCRIPTOR_PATH"] = str(secrets_path)
            if gateway_path:
                os.environ["KDCUBE_GATEWAY_DESCRIPTOR_PATH"] = str(gateway_path)
            if bundles_path:
                os.environ["KDCUBE_BUNDLES_DESCRIPTOR_PATH"] = str(bundles_path)
            if bundles_secrets_path:
                os.environ["KDCUBE_BUNDLES_SECRETS_PATH"] = str(bundles_secrets_path)

            os.environ["KDCUBE_ASSEMBLY_USE_BUNDLES"] = "1" if bool(_get_nested(assembly, "bundles")) else "0"
            os.environ["KDCUBE_ASSEMBLY_USE_FRONTEND"] = "1" if bool(_get_nested(assembly, "frontend")) else "0"
            os.environ["KDCUBE_ASSEMBLY_USE_PLATFORM"] = "0"
            os.environ["KDCUBE_USE_BUNDLES_DESCRIPTOR"] = "1" if bundles_path else "0"
            os.environ["KDCUBE_USE_BUNDLES_SECRETS"] = "1" if bundles_secrets_path else "0"

            reasons = _descriptor_fast_path_reasons(
                assembly,
                have_secrets=bool(descriptor_bootstrap["have_secrets"]),
                have_gateway=bool(descriptor_bootstrap["have_gateway"]),
                bundles_descriptor=descriptor_bootstrap.get("bundles_data"),
                latest=bool(args.latest),
                upstream=bool(args.upstream),
                release=str(args.release or "").strip() or None,
            )
            if reasons and not args.interactive:
                rendered = "\n".join(f"  - {reason}" for reason in reasons)
                raise SystemExit(
                    "Descriptor directory is not valid for non-interactive install.\n"
                    f"{rendered}\n\n"
                    "Use -i to configure missing fields interactively."
                )

            _ensure_descriptor_platform_repo(
                console,
                repo_path=repo_path,
                path_provided=path_provided,
                assembly=assembly,
                fallback_repo=args.repo,
            )

            release_ref = None
            install_mode = "release"
            if args.upstream:
                release_ref = _checkout_repo_upstream(console, repo_path)
                install_mode = "upstream"
            elif args.latest:
                release_ref = _read_remote_ref(repo_path)
                if not release_ref:
                    release_ref = _read_local_ref(repo_path)
                if not release_ref:
                    raise SystemExit(
                        "Could not resolve the latest platform release from the platform repo. "
                        "Check platform.repo or pass a repo that contains release.yaml."
                    )
            elif str(args.release or "").strip():
                release_ref = str(args.release).strip()
            else:
                release_ref = str(_get_nested(assembly, "platform", "ref") or "").strip() or None
                if not release_ref:
                    raise SystemExit("assembly platform.ref is required unless --latest, --upstream, or --release is used.")

            if args.build:
                if not args.upstream:
                    _checkout_repo_ref(console, repo_path, release_ref)
                if install_mode != "upstream":
                    install_mode = "skip"
                console.print("[green]Descriptor set is complete. Running non-interactive source build install.[/green]")
            elif not path_provided and not args.upstream:
                _checkout_repo_ref(console, repo_path, release_ref)
                console.print("[green]Descriptor set is complete. Running non-interactive release-image install.[/green]")
            else:
                console.print("[green]Descriptor set is complete. Running non-interactive release-image install.[/green]")
            if not args.interactive:
                os.environ["KDCUBE_CLI_NONINTERACTIVE"] = "1"
            if not args.dry_run:
                _t, _p = _parse_workdir_namespace(workdir)
                _check_before_start(console, tenant=_t, project=_p)
            run_installer(console, repo_path, workdir, install_mode, release_ref, None, args.dry_run)
            if not args.dry_run:
                try:
                    _lctx = _build_paths_for_repo(repo_path, workdir)
                    _write_cli_lock(
                        tenant=_t, project=_p, workdir=workdir,
                        docker_dir=_lctx.docker_dir, env_file=_lctx.config_dir / ".env",
                    )
                except Exception:
                    pass
            return

        assembly_descriptor_path: Path | None = None
        secrets_descriptor_path: Path | None = None
        bundles_descriptor_path: Path | None = None
        bundles_secrets_path: Path | None = None
        use_descriptor_bundles = False
        use_bundles_descriptor = False
        use_bundles_secrets = False
        use_descriptor_frontend = False
        bundles_default = False
        frontend_default = False
        if not args.secrets_set and not args.secrets_prompt and not descriptor_bootstrap:
            default_descriptors_dir = str((workdir / "config").resolve())
            raw_dir = Prompt.ask("Descriptors directory", default=default_descriptors_dir).strip()
            source_dir = Path(os.path.expanduser(raw_dir)).expanduser().resolve()
            workdir = _resolve_cli_workdir(workdir, descriptors_location=source_dir)
            repo_path = _resolve_cli_repo_path(
                repo_path,
                workdir=workdir,
                path_provided=path_provided,
                descriptors_location=source_dir,
            )
            staged = installer_mod.stage_descriptor_directory(
                workdir / "config",
                source_dir=source_dir,
                ai_app_root=repo_path / "app/ai-app",
                require_complete=False,
            )
            user_supplied = source_dir.resolve() != (workdir / "config").resolve()

            assembly_descriptor_path = staged["assembly_path"]
            secrets_descriptor_path = staged["secrets_path"]
            bundles_descriptor_path = staged["bundles_path"]
            bundles_secrets_path = staged["bundles_secrets_path"]
            gateway_descriptor_path = staged["gateway_path"]
            descriptor = staged["assembly"]

            os.environ["KDCUBE_ASSEMBLY_DESCRIPTOR_PATH"] = str(assembly_descriptor_path)
            os.environ["KDCUBE_ASSEMBLY_USER_SUPPLIED"] = "1" if user_supplied else "0"
            if secrets_descriptor_path:
                os.environ["KDCUBE_SECRETS_DESCRIPTOR_PATH"] = str(secrets_descriptor_path)
            if gateway_descriptor_path:
                os.environ["KDCUBE_GATEWAY_DESCRIPTOR_PATH"] = str(gateway_descriptor_path)
            if bundles_descriptor_path:
                os.environ["KDCUBE_BUNDLES_DESCRIPTOR_PATH"] = str(bundles_descriptor_path)
            if bundles_secrets_path:
                os.environ["KDCUBE_BUNDLES_SECRETS_PATH"] = str(bundles_secrets_path)

            bundles_default = isinstance(descriptor, dict) and bool(descriptor.get("bundles"))
            frontend_default = isinstance(descriptor, dict) and bool(descriptor.get("frontend"))
            use_bundles_descriptor = bool(bundles_descriptor_path)
            use_bundles_secrets = bool(bundles_secrets_path)

            if frontend_default:
                use_descriptor_frontend = Confirm.ask(
                    "Use assembly descriptor for frontend?",
                    default=True,
                )

            os.environ["KDCUBE_ASSEMBLY_USE_BUNDLES"] = "0"
            os.environ["KDCUBE_ASSEMBLY_USE_FRONTEND"] = "1" if use_descriptor_frontend else "0"
            os.environ["KDCUBE_ASSEMBLY_USE_PLATFORM"] = "0"
            if bundles_descriptor_path:
                os.environ["KDCUBE_USE_BUNDLES_DESCRIPTOR"] = "1" if use_bundles_descriptor else "0"
            if bundles_secrets_path:
                os.environ["KDCUBE_USE_BUNDLES_SECRETS"] = "1" if use_bundles_secrets else "0"
            if not assembly_descriptor_path:
                os.environ["KDCUBE_ASSEMBLY_USE_BUNDLES"] = "0"
                os.environ["KDCUBE_ASSEMBLY_USE_FRONTEND"] = "0"
                os.environ["KDCUBE_ASSEMBLY_USE_PLATFORM"] = "0"
        elif descriptor_bootstrap:
            assembly_descriptor_path = descriptor_bootstrap["assembly_path"]
            secrets_descriptor_path = descriptor_bootstrap["secrets_path"]
            bundles_descriptor_path = descriptor_bootstrap["bundles_path"]
            bundles_secrets_path = descriptor_bootstrap["bundles_secrets_path"]

        if args.secrets_set or args.secrets_prompt:
            secrets = _parse_secret_pairs(args.secrets_set)
            if args.secrets_prompt:
                openai = Prompt.ask("OpenAI API key (leave blank to skip)", default="", password=True)
                anthropic = Prompt.ask("Anthropic API key (leave blank to skip)", default="", password=True)
                git_http_token = Prompt.ask("Git HTTPS token (leave blank to skip)", default="", password=True)
                if openai:
                    secrets["OPENAI_API_KEY"] = openai
                if anthropic:
                    secrets["ANTHROPIC_API_KEY"] = anthropic
                if git_http_token:
                    secrets["GIT_HTTP_TOKEN"] = git_http_token
            if not secrets:
                console.print("[yellow]No secrets provided. Nothing to inject.[/yellow]")
                return
            ctx = _build_paths_for_repo(repo_path, workdir)
            _ensure_secrets_service_available(ctx.docker_dir)
            base_env = workdir / "config" / ".env"
            token_overrides = installer_mod.generate_runtime_tokens()
            runtime_env = installer_mod.write_env_overlay(base_env, token_overrides)
            try:
                console.print("[dim]Restarting secrets-enabled services with fresh tokens...[/dim]")
                # Ensure secrets sidecar is (re)created with the new tokens.
                _run_compose(
                    console,
                    [
                        "docker",
                        "compose",
                        "--env-file",
                        str(runtime_env),
                        "up",
                        "-d",
                        "--force-recreate",
                        "kdcube-secrets",
                    ],
                    cwd=ctx.docker_dir,
                )
                installer_mod.apply_runtime_secrets(console, ctx, secrets, runtime_env)

                # Restart ingress/proc so they pick up new read tokens.
                _run_compose(
                    console,
                    [
                        "docker",
                        "compose",
                        "--env-file",
                        str(runtime_env),
                        "up",
                        "-d",
                        "--force-recreate",
                        "chat-ingress",
                        "chat-proc",
                    ],
                    cwd=ctx.docker_dir,
                )

                # Restart proxy to refresh upstream resolution.
                available = _compose_services(ctx.docker_dir, runtime_env)
                if available:
                    console.print(f"[dim]Compose services:[/dim] {', '.join(sorted(available))}")
                running = _compose_running_services(ctx.docker_dir, runtime_env)
                if running:
                    console.print(f"[dim]Running services:[/dim] {', '.join(sorted(running))}")
                else:
                    names = _docker_running_names()
                    if names:
                        console.print(f"[dim]Running containers:[/dim] {', '.join(sorted(names))}")
                # Restart only known proxy service names from compose config.
                proxy_targets = [
                    name
                    for name in ("web-proxy", "kdcube-web-proxy")
                    if name in available
                ]
                if proxy_targets:
                    for proxy_name in proxy_targets:
                        _run_compose_optional(
                            console,
                            [
                                "docker",
                                "compose",
                                "--env-file",
                                str(runtime_env),
                                "up",
                                "-d",
                                "--force-recreate",
                                proxy_name,
                            ],
                            cwd=ctx.docker_dir,
                            label=f"{proxy_name} restart skipped or failed",
                        )
                else:
                    # Fallback to container-level restart if compose service name was not detected.
                    names = _docker_running_names()
                    if "kdcube-web-proxy" in names:
                        _run_compose_optional(
                            console,
                            ["docker", "restart", "kdcube-web-proxy"],
                            cwd=ctx.docker_dir,
                            label="kdcube-web-proxy restart skipped or failed",
                        )
                    else:
                        console.print("[yellow]No web proxy service found to restart.[/yellow]")
                # Show final service state for debugging.
                _run_compose_optional(
                    console,
                    [
                        "docker",
                        "compose",
                        "--env-file",
                        str(runtime_env),
                        "ps",
                    ],
                    cwd=ctx.docker_dir,
                    label="compose ps failed",
                )
            finally:
                runtime_env.unlink(missing_ok=True)
            return

        install_meta = _read_install_meta(workdir)
        if install_meta and install_meta.get("platform_ref"):
            console.print(f"[dim]Installed release (workdir):[/dim] {install_meta.get('platform_ref')}")
        elif (workdir / "config").exists():
            console.print("[dim]Installed release (workdir):[/dim] unknown (no metadata)")

        docker_namespace = None

        path_arg = _arg_provided("--path")
        if path_arg:
            # Explicit local repo path: use as-is for templates/builds, no source menu.
            if not _is_git_repo(repo_path):
                raise SystemExit(f"Provided --path is not a git repo: {repo_path}")
            local_ref = _read_local_ref(repo_path)
            if local_ref:
                console.print(f"[dim]Repo release.yaml:[/dim] {local_ref}")
            _, _, status = _git_status(repo_path)
            if status:
                console.print(f"[dim]Repo status:[/dim] {status}")
            mode = "skip"
            release_ref = None
        else:
            # Source selection menu (workspace, local, upstream, releases).
            workspace_repo = repo_path
            workspace_has_repo = _is_git_repo(workspace_repo)

            local_ref = None
            remote_ref = None
            if workspace_has_repo:
                local_ref = _read_local_ref(workspace_repo)
                remote_ref = _read_remote_ref(workspace_repo)
                if remote_ref:
                    console.print(f"[dim]Latest release (remote):[/dim] {remote_ref}")
                if local_ref:
                    console.print(f"[dim]Repo release.yaml:[/dim] {local_ref}")
                _, _, status = _git_status(workspace_repo)
                if status:
                    console.print(f"[dim]Repo status:[/dim] {status}")

            choices = ["upstream", "release-latest", "release-tag", "local"]
            if workspace_has_repo:
                choices.append("workspace")
            default_choice = "workspace" if workspace_has_repo else "upstream"
            default_index = choices.index(default_choice)
            console.print("[dim]Sources define templates + images. Only release-latest/release-tag pull images; all other choices build locally.[/dim]")
            choice = _select_option(
                console,
                "Install source",
                options=choices,
                default_index=default_index,
            )

            if choice == "local":
                default_local = str(repo_path) if _is_git_repo(repo_path) else ""
                while True:
                    local_path = Prompt.ask("Local repo path", default=default_local).strip()
                    if not local_path:
                        console.print("[yellow]Local repo path is required for 'local' source.[/yellow]")
                        continue
                    repo_path = Path(os.path.expanduser(local_path)).expanduser().resolve()
                    if not _is_git_repo(repo_path):
                        console.print(f"[yellow]Local repo path is not a git repo: {repo_path}[/yellow]")
                        continue
                    break
                mode = "skip"
                release_ref = None
            elif choice == "workspace":
                repo_path = workspace_repo
                if not workspace_has_repo:
                    console.print("[yellow]Workspace repo not found; falling back to upstream clone.[/yellow]")
                    mode = "upstream"
                else:
                    mode = "skip"
                release_ref = None
            elif choice == "upstream":
                repo_path = workspace_repo
                mode = "upstream"
                release_ref = None
            elif choice == "release-latest":
                repo_path = workspace_repo
                mode = "release"
                if not workspace_has_repo:
                    ensure_repo(console, args.repo, repo_path)
                release_ref = remote_ref or _read_remote_ref(repo_path) or Prompt.ask("Release version (platform.ref)")
            else:  # release-tag
                repo_path = workspace_repo
                mode = "release"
                if not workspace_has_repo:
                    ensure_repo(console, args.repo, repo_path)
                release_ref = Prompt.ask("Release version (platform.ref)")

            if mode in {"upstream", "skip"} and choice != "local":
                ensure_repo(console, args.repo, repo_path)
            if mode == "upstream":
                run(["git", "pull"], cwd=repo_path)

        if args.reset_config or args.reset:
            os.environ["KDCUBE_RESET_CONFIG"] = "1"
        if not args.dry_run:
            _resolved_wdir = _resolve_cli_workdir(workdir)
            _t, _p = _parse_workdir_namespace(_resolved_wdir)
            _check_before_start(console, tenant=_t, project=_p)
        run_installer(console, repo_path, workdir, mode, release_ref, docker_namespace, args.dry_run)
        if not args.dry_run:
            try:
                _resolved_wdir = _resolve_cli_workdir(workdir)
                _lctx = _build_paths_for_repo(repo_path, _resolved_wdir)
                _write_cli_lock(
                    tenant=_t, project=_p, workdir=_resolved_wdir,
                    docker_dir=_lctx.docker_dir, env_file=_lctx.config_dir / ".env",
                )
            except Exception:
                pass
    except _AmbiguousWorkdirError as exc:
        tbl = Table(show_header=True, header_style="bold", box=None, padding=(0, 2))
        tbl.add_column("Tenant")
        tbl.add_column("Project")
        for candidate in exc.candidates:
            parts = candidate.name.split("__", 1)
            tbl.add_row(parts[0], parts[1] if len(parts) > 1 else "")
        console.print(f"[red]Multiple runtime workdirs found under {exc.base_workdir}:[/red]")
        console.print(tbl)
        console.print("Disambiguate with [bold]--tenant[/bold] / [bold]--project[/bold].")
        raise SystemExit(1)
    except FileNotFoundError as exc:
        detail = str(exc).strip()
        if detail:
            raise SystemExit(f"Missing dependency or file: {detail}") from exc
        raise SystemExit("Missing dependency or file (FileNotFoundError).") from exc
    except KeyboardInterrupt:
        console.print("\n[yellow]Setup cancelled.[/yellow]")
        raise SystemExit(130)
    except subprocess.CalledProcessError as exc:
        raise SystemExit(f"Command failed with exit code {exc.returncode}.") from exc


if __name__ == "__main__":
    main()
