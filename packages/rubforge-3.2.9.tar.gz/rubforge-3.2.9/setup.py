from setuptools import setup, find_packages

setup(
    name='rubforge',
    version='3.2.9',
    packages=find_packages(),
    description='One of the Best Modules for Developing Rubika Bots',
    long_description=open('README.md', encoding='utf-8').read(),
    long_description_content_type='text/markdown',
    author='Akuma & Off Coder',
    author_email='testoftesttestfortest@gmail.com',
    license='MIT',
    install_requires=[
        "uuid", "httpx",
        "apscheduler", "aiosqlite",
        "aiohttp", "aiofiles", "requests"
    ],
)
