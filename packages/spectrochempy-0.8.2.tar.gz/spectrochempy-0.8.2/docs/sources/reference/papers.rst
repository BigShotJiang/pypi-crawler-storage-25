.. _papers:

****************************************
Papers citing `SpectroChemPy`
****************************************

2026
====

- Speciation of silanol groups on commercial precipitated silicas via IR spectroscopy,
  :cite:t:`debs:2026`, `DOI: 10.26434/chemrxiv.15002422/v1 <https://chemrxiv.org/doi/abs/10.26434/chemrxiv.15002422/v1>`__.

- Multivariate analysis coupled to infrared spectroscopy unravels the diversity of adsorption sites and strengths of a zeolite surface
  :cite:t:`aboulayt:2026`, `DOI: 10.1039/d6cy00101g <https://doi.org/10.1039/d6cy00101g>`__.

- On the Influence of Catalyst Mesopore Structure in the Catalytic Cracking of Polypropylene,
  :cite:t:`rejman:2026`, `DOI: 10.1002/ceur.202500317 <https://doi.org/10.1002/ceur.202500317>`__.

- Evaluation of Quantification Methods applied to Overlapping FTIR Features,
  :cite:t:`diehl:2026`, `DOI: 10.70163/2997-8947.1014 <https://doi.org/10.70163/2997-8947.1014>`__.

- Operando Infrared Imaging of Electrolyte Gradients with Lithium Metal Electrodes,
  :cite:t:`landetta:2026`, `URL: https://scholarsarchive.byu.edu/cgi/viewcontent.cgi?article=1012&context=raise <https://scholarsarchive.byu.edu/cgi/viewcontent.cgi?article=1012&context=raise>`__.

- Effect of reaction temperature on nascent carbonaceous particles from toluene shock-tube pyrolysis: Insights from FTIR and Raman spectroscopy
  :cite:t:`rezaeian:2026`, `DOI: 10.48550/arXiv.2604.26629 <https://doi.org/10.48550/arXiv.2604.26629>`__.

- Denoising framework for X-ray absorption spectroscopy data
  :cite:t:`aidukas:2026`, `DOI: 10.1107/S1600577526001712 <https://doi.org/10.1107/S1600577526001712>`__.

- The Effect of Inorganic Impurities in Post-Consumer Plastic Waste on the Cracking of Polyolefins with Zeolite-based Catalysts,
  :cite:t:`rejman:2026b`, `10.26434/chemrxiv-2025-0nfrn/v2 <https://chemrxiv.org/doi/abs/10.26434/chemrxiv-2025-0nfrn/v2>`__.

2025
====

- Structure and Sulfur: Tuning the Viscoelastic and Surface Properties of Natural Keratin Fibers
  :cite:t:`czibula:2025`, `DOI: 10.1021/acsmaterialsau.5c00130 <https://doi.org/10.1021/acsmaterialsau.5c00130>`__.

- Rapid, clean and quantitative analysis of Cu2+ in copper refining electrolyte via chemometrics-driven Vis–SWNIR absorption spectroscopy
  :cite:t:`yuan:2025`, `DOI: 10.1039/D5AY01465D <http://dx.doi.org/10.1039/D5AY01465D>`__.

- Cellulose–TBPH interactions from diffusion NMR, rheology and SAXS studies.
  :cite:t:`quillard:2025`, `DOI: 10.21203/rs.3.rs-6993367/v1 <https://doi.org/10.21203/rs.3.rs-6993367/v1>`__.

- Single--Cell Raman Imaging Reveals Fructose Impairs Brown Adipocyte Differentiation
  :cite:t:`gupta:2025`, `DOI: 10.1016/j.bios.2025.117994 <https://doi.org/10.1016/j.bios.2025.117994>`__.

- High-temperature CO2 capture by Li4SiO4: IR spectroscopic evidence for the double shell model
  :cite:t:`alassaad:2025`, `DOI: 10.1039/D5CP02957K <https://doi.org/10.1039/D5CP02957K>`__.

- La programmacion Como Herramienta Esencial Para El Ingeniero Quimico Del Siglo XXI
  :cite:t:`flores:2025`, `URL: http://rd.buap.mx/ojs-rdicuap/index.php/rdicuap/article/view/1598/1571 <http://rd.buap.mx/ojs-rdicuap/index.php/rdicuap/article/view/1598/1571>`__.

- Whole brain resting-state EEG dynamic: A mixture of linear aperiodic and nonlinear resonant stochastic processes,
  :cite:t:`wang:2025`, `DOI: 10.1101/2025.06.27.661950 <https://doi.org/10.1101/2025.06.27.661950>`__.

- AutoSDT: Scaling Data-Driven Discovery Tasks Toward Open Co-Scientists,
  :cite:t:`Li:2025`, `DOI: 10.48550/arXiv.2506.08140 <https://doi.org/10.48550/arXiv.2506.08140>`__.

- Unveiling Capacity Limitations of MnO2 in Rechargeable Zn Chemistry,
  :cite:t:`Liu:2025`, `DOI: 10.26434/chemrxiv-2025-f5j9d <https://doi.org/10.26434/chemrxiv-2025-f5j9d>`__.

- Characterising the Interfacial Bonding in Organic-Inorganic Hybrid Materials from Their Thermal Stability,
  :cite:t:`Schade:2025`, `DOI: 10.1016/j.ctta.2025.100221 <https://doi.org/10.1016/j.ctta.2025.100221>`__.

- External Acidity as Performance Descriptor in Polyolefin Cracking using Zeolite-Based Materials,
  :cite:t:`Rejman:2025a`, `DOI: 10.1038/s41467-025-57158-110.1038/s41467-025-57158-1 <https://doi.org/10.1038/s41467-025-57158-1>`__.

- Tracking solid electrolyte interphase dynamics using operando fibre-optic infrared spectroscopy and multivariate curve regression,
  :cite:t:`Leau:2025`, `DOI: 10.1038/s41467-024-55339-y <https://doi.org/10.1038/s41467-024-55339-y>`__.

- Discriminating Analysis of Metal Ions via Multivariate Curve Resolution–Alternating Least Squares Applied to Silver Nanoparticle Sensor,
  :cite:t:`Rossi:2025`, `DOI: 10.3390/nano15010057 <https://doi.org/10.3390/nano15010057>`__.

- Comprehensive assessment of the role of spectral data pre-processing in spectroscopy-based liquid biopsy,
  :cite:t:`Vrtelka:2025`, `DOI: 10.1016/j.saa.2025.126261 <https://doi.org/10.1016/j.saa.2025.126261>`__.

- Absorbance Discrimination of Ready-to-Drink Tea Samples By Derivative Spectroscopy and Multivariate Analysis,
  :cite:t:`hernandez:2025`, `URL: www.westmont.edu/sites/default/files/2025-02/Elmer-Rico%20Mojica_final_tea_1.pdf <https://www.westmont.edu/sites/default/files/2025-02/Elmer-Rico%20Mojica_final_tea_1.pdf>`__.

2024
====

- Assessment of Chemometric Analysis Utilizing Multivariate Curve Resolution Alternating Least Squares (MCRALS) for Examination of Thermal and Photodegradation of Fern Extracts,
  :cite:t:`Oviedo:2024`, `DOI: 10.1109/BIP63158.2024.10885392 <https://doi.org/10.1109/BIP63158.2024.10885392>`__.

- Metal-organic frameworks based on pyrazolates for the selective and efficient capture of formaldehyde,
  :cite:t:`Sadovnik:2024`, `DOI: 10.1038/s41467-024-53572-z <https://doi.org/10.1038/s41467-024-53572-z>`__.

- Investigating nalidixic acid adsorption onto ferrihydrite and maghemite surfaces: molecular-level insights via
  continuous-flow ATR-FTIR spectroscopy,
  :cite:t:`Schuh-Frantz:2024`, `DOI: 10.1039/D4NJ03440F <http://dx.doi.org/10.1039/D4NJ03440F>`__.

- Deriving kinetic insights from mechanochemically synthesized compounds using multivariate analysis (MCR-ALS) of powder
  X-ray diffraction data,
  :cite:t:`Macchietti:2024`, `DOI: 10.1039/D3MR00013C <http://dx.doi.org/10.1039/D3MR00013C>`__.

- An intuitive approach for spike removal in Raman spectra based on peaks’ prominence and width,
  :cite:t:`coca-lopez:2024`, `DOI: 10.1016/j.aca.2024.342312 <https://doi.org/10.1016/j.aca.2024.342312>`__.

- Adsοrptiοn de l'isοbutanοl dans les zeοlithes : appοrt des analyses multivariées,
  :cite:t:`aboulayt:2024`, `HAL: tel-04934402 <https://theses.hal.science/tel-04934402>`__.

2023
====

- Cyclohexane Oxidative Dehydrogenation on Graphene-Oxide-Supported Cobalt Ferrite
  Nanohybrids: Effect of Dynamic Nature of Active Sites on Reaction Selectivity,
  :cite:t:`kadam:2023`, `DOI: 10.1021/acscatal.3c02592 <https://doi.org/10.1021/acscatal.3c02592>`__.

- Study of the diffusion properties of zeolite mixtures by combined gravimetric
  analysis, IR spectroscopy and inversion methods (IRIS),
  :cite:t:`ait-blal:2023`, `DOI: 10.1039/D3CP01585H <http://dx.doi.org/10.1039/D3CP01585H>`__.

- Determining the Mechanism Behind Ultrasound Induced Cell Enlargement in Water-Blown Polyurethane Foam
  :cite:t:`blackwell:2023`, `DOI: 10.2139/ssrn.4479369 <https://dx.doi.org/10.2139/ssrn.4479369>`__.

- FTIR dataset from the article "Resistance to
  Degradation of Silk Fibroin Hydrogels Exposed to Neuroinflammatory Environments",
  :cite:t:`yonesi:2023`, `DOI: 10.5281/zenodo.7921117 <https://doi.org/10.5281/zenodo.7921117>`__.

- Understanding the patterns that neural networks learn from chemical spectra,
  :cite:t:`rieger:2023`, `DOI: 10.26434/chemrxiv-2023-8pfk5 <https://dx.doi.org/10.26434/chemrxiv-2023-8pfk5>`__.

- Electronic Communication in Bridged Ruthenium Acetylide Complexes,
  :cite:`naik:2023`, `DOI: 10.26190/unsworks/25240 <https://dx.doi.org/10.26190/unsworks/25240>`__.

2022
====

- Observation of surface species in plasma-catalytic dry reforming of methane in a novel atmospheric pressure dielectric
  barrier discharge in situ IR cell,
  :cite:t:`vanturnhout:2022`, `DOI: 10.1039/D2CY00311B <https://dx.doi.org/10.1039/D2CY00311B>`__.

- Développement d’outils de traitement de données de spectroscopie massives dans le contexte de la dépollution
  automobile,
  :cite:t:`helie:2022`, `HAL: tel-04077817 <https://theses.hal.science/tel-04077817>`__.

2021
====

- Catalysis by sulfides: Advanced IR/CO spectroscopy for the identification of the most active sites in
  hydrodesulfurization reactions,
  :cite:t:`oliviero:2021`, `DOI: 10.1016/j.jcat.2021.02.018 <https://dx.doi.org/10.1016/j.jcat.2021.02.018>`__.

- A highly selective FER-based catalyst to produce n-butenes from isobutanol,
  :cite:t:`vandaele:2021`, `DOI: 10.1016/j.apcatb.2020.119699 <https://dx.doi.org/10.1016/j.apcatb.2020.119699>`__.
