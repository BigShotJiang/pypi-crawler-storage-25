"""Veo CLI core modules."""
