"""AI session capture — sniff and log coding sessions from Claude Code, ChatGPT, Codex, Qwen.

Usage:
    openrunner session watch          # daemon mode, auto-logs new sessions
    openrunner session sync           # one-shot, sync recent unlogged sessions
    openrunner session hook install   # install Claude Code hook for auto-capture
    openrunner session list           # list captured sessions

Supports:
    - Claude Code (~/.claude/projects/*/*.jsonl)
    - ChatGPT API logs (if OPENAI_LOG_DIR set)
    - Codex CLI (~/.codex/sessions/)
    - Qwen Code (~/.qwen-code/sessions/)
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger("openrunner.session")

# ---------------------------------------------------------------------------
# Session source detectors
# ---------------------------------------------------------------------------

CLAUDE_CODE_DIR = Path.home() / ".claude" / "projects"
CODEX_DIR = Path.home() / ".codex" / "sessions"
QWEN_DIR = Path.home() / ".qwen-code" / "sessions"
CHATGPT_LOG_DIR = Path(os.environ.get("OPENAI_LOG_DIR", "~/.openai/logs")).expanduser()

# Track which sessions we've already synced
SYNC_STATE_FILE = Path.home() / ".openrunner" / "session_sync_state.json"


def _load_sync_state() -> dict:
    """Load set of already-synced session hashes."""
    if SYNC_STATE_FILE.exists():
        return json.loads(SYNC_STATE_FILE.read_text())
    return {"synced": {}}


def _save_sync_state(state: dict) -> None:
    SYNC_STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    SYNC_STATE_FILE.write_text(json.dumps(state, indent=2))


def _session_hash(path: Path) -> str:
    """Stable hash for a session file (path + size + mtime)."""
    stat = path.stat()
    key = f"{path}:{stat.st_size}:{int(stat.st_mtime)}"
    return hashlib.md5(key.encode()).hexdigest()[:12]


# ---------------------------------------------------------------------------
# Claude Code parser
# ---------------------------------------------------------------------------


def discover_claude_sessions(since_hours: float = 24) -> list[dict]:
    """Find recent Claude Code session files."""
    sessions = []
    if not CLAUDE_CODE_DIR.exists():
        return sessions

    cutoff = time.time() - (since_hours * 3600)
    for jsonl in CLAUDE_CODE_DIR.rglob("*.jsonl"):
        if jsonl.stat().st_mtime < cutoff:
            continue
        sessions.append({
            "source": "claude-code",
            "path": jsonl,
            "mtime": jsonl.stat().st_mtime,
            "size": jsonl.stat().st_size,
        })
    return sorted(sessions, key=lambda s: s["mtime"], reverse=True)


def parse_claude_session(path: Path) -> dict[str, Any]:
    """Parse a Claude Code .jsonl session into structured data."""
    messages = []
    tools_used = set()
    files_touched = set()
    total_tokens = 0

    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                continue

            # Claude Code format: {type, message: {role, content}, ...}
            msg = entry.get("message", entry)
            role = msg.get("role", entry.get("type", ""))
            content = msg.get("content", "")

            # Handle content as list (Claude API format)
            if isinstance(content, list):
                text_parts = []
                for block in content:
                    if isinstance(block, dict):
                        if block.get("type") == "text":
                            text_parts.append(block.get("text", ""))
                        elif block.get("type") == "tool_use":
                            tools_used.add(block.get("name", "unknown"))
                            # Track files from Read/Write/Edit
                            inp = block.get("input", {})
                            if "file_path" in inp:
                                files_touched.add(inp["file_path"])
                            elif "path" in inp:
                                files_touched.add(inp["path"])
                        elif block.get("type") == "tool_result":
                            pass
                content = "\n".join(text_parts)

            if role == "user" and content:
                messages.append({"role": "user", "content": content[:2000]})
            elif role == "assistant" and content:
                messages.append({"role": "assistant", "content": content[:2000]})

            # Token counting from usage field (may be at entry or message level)
            usage = entry.get("usage", msg.get("usage", {}))
            total_tokens += usage.get("input_tokens", 0) + usage.get("output_tokens", 0)

    # Extract project context from path
    # ~/.claude/projects/-home-user-myproject/session.jsonl
    project_hint = path.parent.name.replace("-", "/").lstrip("/")

    # Build summary
    user_messages = [m for m in messages if m["role"] == "user"]
    first_msg = user_messages[0]["content"][:200] if user_messages else "Empty session"

    return {
        "source": "claude-code",
        "session_file": str(path),
        "project_hint": project_hint,
        "started_at": datetime.fromtimestamp(path.stat().st_mtime - _estimate_duration(path), tz=timezone.utc).isoformat(),
        "ended_at": datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc).isoformat(),
        "message_count": len(messages),
        "user_message_count": len(user_messages),
        "tools_used": sorted(tools_used),
        "files_touched": sorted(files_touched)[:50],
        "total_tokens": total_tokens,
        "first_message": first_msg,
        "summary": _summarize_session(messages),
        "messages": messages[:100],  # cap at 100 for storage
    }


def _estimate_duration(path: Path) -> float:
    """Rough session duration estimate from file size."""
    # ~500 bytes per message exchange, ~30s per exchange
    size = path.stat().st_size
    exchanges = size / 500
    return min(exchanges * 30, 7200)  # cap at 2h


def _summarize_session(messages: list[dict]) -> str:
    """Generate a text summary from messages."""
    user_msgs = [m["content"] for m in messages if m["role"] == "user"]
    if not user_msgs:
        return "Empty session"

    # Use first and last user messages as summary
    parts = []
    if user_msgs:
        parts.append(f"Started: {user_msgs[0][:100]}")
    if len(user_msgs) > 1:
        parts.append(f"Last: {user_msgs[-1][:100]}")
    parts.append(f"({len(user_msgs)} user messages)")
    return " | ".join(parts)


# ---------------------------------------------------------------------------
# Codex / Qwen / ChatGPT parsers (simpler)
# ---------------------------------------------------------------------------


def discover_codex_sessions(since_hours: float = 24) -> list[dict]:
    """Find recent Codex sessions."""
    sessions = []
    if not CODEX_DIR.exists():
        return sessions
    cutoff = time.time() - (since_hours * 3600)
    for f in CODEX_DIR.glob("*.json"):
        if f.stat().st_mtime < cutoff:
            continue
        sessions.append({"source": "codex", "path": f, "mtime": f.stat().st_mtime, "size": f.stat().st_size})
    return sessions


def discover_qwen_sessions(since_hours: float = 24) -> list[dict]:
    """Find recent Qwen Code sessions."""
    sessions = []
    if not QWEN_DIR.exists():
        return sessions
    cutoff = time.time() - (since_hours * 3600)
    for f in QWEN_DIR.rglob("*.json"):
        if f.stat().st_mtime < cutoff:
            continue
        sessions.append({"source": "qwen", "path": f, "mtime": f.stat().st_mtime, "size": f.stat().st_size})
    return sessions


def discover_chatgpt_sessions(since_hours: float = 24) -> list[dict]:
    """Find ChatGPT API log files."""
    sessions = []
    if not CHATGPT_LOG_DIR.exists():
        return sessions
    cutoff = time.time() - (since_hours * 3600)
    for f in CHATGPT_LOG_DIR.rglob("*.jsonl"):
        if f.stat().st_mtime < cutoff:
            continue
        sessions.append({"source": "chatgpt", "path": f, "mtime": f.stat().st_mtime, "size": f.stat().st_size})
    return sessions


def parse_generic_session(path: Path, source: str) -> dict[str, Any]:
    """Parse a generic JSON/JSONL session file."""
    messages = []
    try:
        if path.suffix == ".jsonl":
            with open(path) as f:
                for line in f:
                    if line.strip():
                        try:
                            messages.append(json.loads(line))
                        except json.JSONDecodeError:
                            pass
        else:
            data = json.loads(path.read_text())
            if isinstance(data, list):
                messages = data
            elif isinstance(data, dict) and "messages" in data:
                messages = data["messages"]
    except Exception:
        pass

    return {
        "source": source,
        "session_file": str(path),
        "project_hint": "",
        "started_at": datetime.fromtimestamp(path.stat().st_mtime - 1800, tz=timezone.utc).isoformat(),
        "ended_at": datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc).isoformat(),
        "message_count": len(messages),
        "user_message_count": sum(1 for m in messages if isinstance(m, dict) and m.get("role") == "user"),
        "tools_used": [],
        "files_touched": [],
        "total_tokens": 0,
        "first_message": str(messages[0])[:200] if messages else "Empty",
        "summary": f"{source} session with {len(messages)} messages",
        "messages": messages[:100],
    }


# ---------------------------------------------------------------------------
# Sync to OpenRunner
# ---------------------------------------------------------------------------


def sync_session_to_openrunner(
    parsed: dict[str, Any],
    project: str | None = None,
    api_key: str | None = None,
    base_url: str | None = None,
) -> str | None:
    """Upload a parsed session to OpenRunner as a run with notes.

    Returns the run ID on success, None on failure.
    """
    from openrunner.api_client import APIClient

    # Load settings from ~/.openrunner/settings.json
    if not api_key or not base_url:
        settings_file = Path.home() / ".openrunner" / "settings.json"
        settings = {}
        if settings_file.exists():
            try:
                settings = json.loads(settings_file.read_text())
            except (json.JSONDecodeError, OSError):
                pass
        api_key = api_key or os.environ.get("OPENRUNNER_API_KEY") or settings.get("api_key")
        base_url = base_url or os.environ.get("OPENRUNNER_BASE_URL") or settings.get("base_url")

    if not api_key or not base_url:
        logger.warning("No API key or base URL configured. Run 'openrunner login' first.")
        return None

    # Determine project
    if not project:
        project = os.environ.get("OPENRUNNER_SESSION_PROJECT", "research-sessions")

    client = APIClient(base_url=base_url, api_key=api_key)

    # Create run
    source = parsed["source"]
    timestamp = parsed.get("ended_at", "")[:16].replace("T", " ")
    run_name = f"{source}/{timestamp}"

    run_data = {
        "project": project,
        "display_name": run_name,
        "config": {
            "source": source,
            "session_file": parsed.get("session_file", ""),
            "project_hint": parsed.get("project_hint", ""),
            "message_count": parsed.get("message_count", 0),
            "user_message_count": parsed.get("user_message_count", 0),
            "tools_used": parsed.get("tools_used", []),
            "total_tokens": parsed.get("total_tokens", 0),
        },
        "tags": [f"source:{source}", "ai-session"],
        "notes": _format_session_notes(parsed),
        "state": "finished",
    }

    result = client.create_run(run_data)
    if not result:
        logger.warning("Failed to create session run")
        client.close()
        return None

    run_id = result.get("id")

    # Log metrics
    metrics = []
    if parsed.get("total_tokens"):
        metrics.append({"key": "tokens", "value": parsed["total_tokens"], "step": 1})
    if parsed.get("message_count"):
        metrics.append({"key": "messages", "value": parsed["message_count"], "step": 1})
    if parsed.get("user_message_count"):
        metrics.append({"key": "user_messages", "value": parsed["user_message_count"], "step": 1})
    if parsed.get("files_touched"):
        metrics.append({"key": "files_touched", "value": len(parsed["files_touched"]), "step": 1})

    if metrics and run_id:
        client.post_metrics(run_id, metrics)

    # Log files touched as summary
    if parsed.get("files_touched") and run_id:
        client.update_run(run_id, {
            "summary": {
                "files_touched": len(parsed["files_touched"]),
                "tools_used": len(parsed.get("tools_used", [])),
                "tokens": parsed.get("total_tokens", 0),
            }
        })

    client.close()
    return run_id


def _format_session_notes(parsed: dict) -> str:
    """Format parsed session into readable notes."""
    lines = []
    lines.append(f"# {parsed['source'].title()} Session")
    lines.append(f"**Time:** {parsed.get('started_at', '?')[:16]} → {parsed.get('ended_at', '?')[:16]}")
    lines.append("")

    if parsed.get("first_message"):
        lines.append(f"## First Request")
        lines.append(parsed["first_message"])
        lines.append("")

    if parsed.get("tools_used"):
        lines.append(f"## Tools Used ({len(parsed['tools_used'])})")
        for t in parsed["tools_used"][:20]:
            lines.append(f"- {t}")
        lines.append("")

    if parsed.get("files_touched"):
        lines.append(f"## Files Touched ({len(parsed['files_touched'])})")
        for f in parsed["files_touched"][:30]:
            lines.append(f"- `{f}`")
        lines.append("")

    if parsed.get("summary"):
        lines.append(f"## Summary")
        lines.append(parsed["summary"])

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Discovery + sync orchestration
# ---------------------------------------------------------------------------


def discover_all_sessions(since_hours: float = 24) -> list[dict]:
    """Discover sessions from all sources."""
    all_sessions = []
    all_sessions.extend(discover_claude_sessions(since_hours))
    all_sessions.extend(discover_codex_sessions(since_hours))
    all_sessions.extend(discover_qwen_sessions(since_hours))
    all_sessions.extend(discover_chatgpt_sessions(since_hours))
    return sorted(all_sessions, key=lambda s: s["mtime"], reverse=True)


def sync_all(
    since_hours: float = 24,
    project: str | None = None,
    dry_run: bool = False,
) -> list[str]:
    """Discover and sync all new sessions. Returns list of synced run IDs."""
    state = _load_sync_state()
    sessions = discover_all_sessions(since_hours)
    synced_ids = []

    for session_info in sessions:
        h = _session_hash(session_info["path"])
        if h in state["synced"]:
            continue

        if dry_run:
            logger.info(f"[dry-run] Would sync: {session_info['source']} {session_info['path']}")
            continue

        # Parse
        if session_info["source"] == "claude-code":
            parsed = parse_claude_session(session_info["path"])
        else:
            parsed = parse_generic_session(session_info["path"], session_info["source"])

        # Sync
        run_id = sync_session_to_openrunner(parsed, project=project)
        if run_id:
            state["synced"][h] = {
                "run_id": run_id,
                "source": session_info["source"],
                "synced_at": datetime.now(timezone.utc).isoformat(),
            }
            synced_ids.append(run_id)
            logger.info(f"Synced {session_info['source']} session -> run {run_id}")

    _save_sync_state(state)
    return synced_ids


# ---------------------------------------------------------------------------
# Claude Code hook installer
# ---------------------------------------------------------------------------


HOOK_SCRIPT = '''#!/usr/bin/env python3
"""Auto-log Claude Code session to OpenRunner on exit."""
import sys
from pathlib import Path

def main():
    # Find the most recent session file that was just written
    from openrunner.session import discover_claude_sessions, parse_claude_session, sync_session_to_openrunner

    sessions = discover_claude_sessions(since_hours=0.1)  # last 6 minutes
    if not sessions:
        return

    latest = sessions[0]
    parsed = parse_claude_session(latest["path"])

    # Only sync if meaningful (>2 user messages)
    if parsed.get("user_message_count", 0) < 2:
        return

    run_id = sync_session_to_openrunner(parsed)
    if run_id:
        print(f"openrunner: Session logged as run {run_id}", file=sys.stderr)

if __name__ == "__main__":
    main()
'''


def install_claude_hook() -> str:
    """Install Claude Code hook for auto-session capture.

    Returns path to the installed hook config.
    """
    claude_dir = Path.home() / ".claude"
    claude_dir.mkdir(exist_ok=True)

    # Write hook script
    hook_script_path = claude_dir / "openrunner_session_hook.py"
    hook_script_path.write_text(HOOK_SCRIPT)
    hook_script_path.chmod(0o755)

    # Update or create hooks.json
    hooks_file = claude_dir / "hooks.json"
    if hooks_file.exists():
        hooks = json.loads(hooks_file.read_text())
    else:
        hooks = {"hooks": {}}

    # Add to Stop hooks
    stop_hooks = hooks.setdefault("hooks", {}).setdefault("Stop", [])
    hook_cmd = f"python3 {hook_script_path}"

    # Don't duplicate
    if not any(hook_cmd in str(h) for h in stop_hooks):
        stop_hooks.append({"command": hook_cmd})

    hooks_file.write_text(json.dumps(hooks, indent=2))
    return str(hooks_file)


# ---------------------------------------------------------------------------
# Watch mode (daemon)
# ---------------------------------------------------------------------------


def watch(interval: int = 60, project: str | None = None) -> None:
    """Watch for new sessions and sync them continuously."""
    logger.info(f"Watching for AI sessions (interval={interval}s)...")
    while True:
        try:
            synced = sync_all(since_hours=1, project=project)
            if synced:
                logger.info(f"Synced {len(synced)} new session(s)")
        except Exception as e:
            logger.warning(f"Watch cycle error: {e}")
        time.sleep(interval)
