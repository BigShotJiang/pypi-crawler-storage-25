# notes-tl

`notes-tl` is a Python package that ships experiment modules `EX1.py` to `EX10.py`.

## Install

```bash
pip install .
```

## Usage

```python
from notes_tl import EX1, program

EX1("dataset_path")
program(1)
```

## Available Helpers

- `EX1` to `EX10`: importable experiment functions.
- `program(n)`: copies `EX{n}.py` to the current working directory.
- `list_experiments()`: returns `['EX1', ..., 'EX10']`.

## Build

```bash
python -m build
```
