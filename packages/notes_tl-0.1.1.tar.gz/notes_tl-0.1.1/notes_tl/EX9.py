
# =========================================
# Step 1: Install Required Libraries
# =========================================

# !pip install tensorflow tensorflow_hub librosa -q


# =========================================
# Step 2: Import Libraries
# =========================================

import tensorflow as tf
import tensorflow_hub as hub
import numpy as np
import librosa
import pandas as pd
import urllib.request


# =========================================
# Step 3: Load Pretrained YAMNet Model
# =========================================

model = hub.load("https://tfhub.dev/google/yamnet/1")

print("Model Loaded Successfully")


# =========================================
# Step 4: Download Sample Audio
# =========================================

audio_url = "https://storage.googleapis.com/audioset/miaow_16k.wav"
audio_file = "miaow_16k.wav"

urllib.request.urlretrieve(audio_url, audio_file)

print("Audio downloaded:", audio_file)


# =========================================
# Step 5: Load Audio File
# =========================================

waveform, sr = librosa.load(audio_file, sr=16000)

print("Audio Loaded, Sample Rate:", sr)


# =========================================
# Step 6: Download Class Labels
# =========================================

class_map_path = "https://raw.githubusercontent.com/tensorflow/models/master/research/audioset/yamnet/yamnet_class_map.csv"

class_map = pd.read_csv(class_map_path)

class_names = class_map['display_name'].tolist()


# =========================================
# Step 7: Run Audio Classification
# =========================================

scores, embeddings, spectrogram = model(waveform)

scores = scores.numpy()

mean_scores = np.mean(scores, axis=0)

top_class = class_names[np.argmax(mean_scores)]


# =========================================
# Step 8: Print Results
# =========================================

print("\nAudio File Name:", audio_file)
print("Predicted Audio Event:", top_class)