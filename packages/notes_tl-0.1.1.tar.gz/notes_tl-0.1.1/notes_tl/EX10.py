

# ===============================
# Step 1: Import Libraries
# ===============================
import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt

# ===============================
# Step 2: Load CIFAR10 Dataset
# ===============================
(x_train, _), (x_test, _) = tf.keras.datasets.cifar10.load_data()

# Normalize images
x_train = x_train.astype('float32') / 255.0
x_test = x_test.astype('float32') / 255.0

# ===============================
# Step 3: Convert to Grayscale
# ===============================
x_train_gray = tf.image.rgb_to_grayscale(x_train)
x_test_gray = tf.image.rgb_to_grayscale(x_test)

# ===============================
# Step 4: Build CNN Colorization Model
# ===============================
model = tf.keras.Sequential([

    tf.keras.layers.Input(shape=(32,32,1)),

    tf.keras.layers.Conv2D(64,(3,3),activation='relu',padding='same'),
    tf.keras.layers.Conv2D(128,(3,3),activation='relu',padding='same'),

    tf.keras.layers.Conv2D(64,(3,3),activation='relu',padding='same'),

    tf.keras.layers.Conv2D(3,(3,3),activation='sigmoid',padding='same')
])

model.compile(
    optimizer='adam',
    loss='mse'
)

print("Model Created Successfully")

# ===============================
# Step 5: Train Model
# ===============================
model.fit(
    x_train_gray,
    x_train,
    epochs=2,
    batch_size=128
)

# ===============================
# Step 6: Predict Color Images
# ===============================
predicted = model.predict(x_test_gray[:5])

# ===============================
# Step 7: Display Results
# ===============================
for i in range(5):

    plt.figure(figsize=(8,3))

    plt.subplot(1,3,1)
    plt.title("Grayscale")
    plt.imshow(x_test_gray[i].numpy().reshape(32,32), cmap="gray")
    plt.axis("off")

    plt.subplot(1,3,2)
    plt.title("Original")
    plt.imshow(x_test[i])
    plt.axis("off")

    plt.subplot(1,3,3)
    plt.title("Colorized")
    plt.imshow(predicted[i])
    plt.axis("off")

    plt.show()