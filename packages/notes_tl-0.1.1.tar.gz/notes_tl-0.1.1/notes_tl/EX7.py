# -*- coding: utf-8 -*-
# =====================================
# Import Libraries
# =====================================

from transformers import AutoTokenizer, AutoModelForSeq2SeqLM


# =====================================
# Load T5 Model
# =====================================

model_name = "t5-small"

tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForSeq2SeqLM.from_pretrained(model_name)

print("Model Loaded Successfully")


# =====================================
# Input Document
# =====================================

text = """
Artificial Intelligence is a branch of computer science that focuses on creating intelligent machines.
These machines are capable of performing tasks such as learning, reasoning and decision making.
AI is widely used in healthcare, education, finance and transportation.
For example, AI helps doctors detect diseases and helps businesses analyze large datasets.
"""


# =====================================
# Prepare Input
# =====================================

input_text = "summarize: " + text

inputs = tokenizer(
    input_text,
    return_tensors="pt",
    max_length=512,
    truncation=True
)


# =====================================
# Generate Summary
# =====================================

summary_ids = model.generate(
    inputs["input_ids"],
    max_length=50,
    min_length=20,
    num_beams=4,
    length_penalty=2.0,
    early_stopping=True
)


# =====================================
# Decode Summary
# =====================================

summary = tokenizer.decode(summary_ids[0], skip_special_tokens=True)


# =====================================
# Print Output
# =====================================

print("\nOriginal Text:\n")
print(text)

print("\nGenerated Summary:\n")
print(summary)