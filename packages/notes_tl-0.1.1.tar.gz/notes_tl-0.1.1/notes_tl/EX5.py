

from tensorflow.keras.datasets import imdb
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.preprocessing.text import Tokenizer

# Load IMDB (top 10,000 words)
(X_train, y_train), (X_test, y_test) = imdb.load_data(num_words=1000)

word_index = imdb.get_word_index()
index_word = {v+3: k for k, v in word_index.items()}
index_word[0] = "<PAD>"
index_word[1] = "<START>"
index_word[2] = "<UNK>"

# Decode reviews back to text
def decode_review(sequence):
    return " ".join([index_word.get(i, "?") for i in sequence])

train_texts = [decode_review(x) for x in X_train]
test_texts = [decode_review(x) for x in X_test]

# -------------------------------------------------
# 1. Load IMDB dataset (binary sentiment)
# -------------------------------------------------
# num_words limits vocabulary size → simpler
(X_train_raw, y_train), (X_test_raw, y_test) = imdb.load_data(num_words=10000)

print("First 10 IMDB reviews (encoded):\n")

for i in range(10):
    print(f"Review {i+1} (Label: {y_train[i]}):")
    print(X_train_raw[i])
    print("-" * 60)

#Print the shape of IMDB Dataset
from tensorflow.keras.preprocessing.sequence import pad_sequences

X_train_pad = pad_sequences(X_train, maxlen=200)
X_test_pad = pad_sequences(X_test, maxlen=200)

print("X_train padded shape:", X_train_pad.shape)
print("X_test padded shape:", X_test_pad.shape)

# Get word index dictionary
word_index = imdb.get_word_index()

# Sort words by index (ascending)
top_10 = sorted(word_index.items(), key=lambda x: x[1])[:10]

print("Top 10 words with smallest indices:")
for word, index in top_10:
    print(f"{word}: {index}")

word_index = imdb.get_word_index()
index_to_word = {index + 3: word for word, index in word_index.items()}
index_to_word[0] = "<PAD>"
index_to_word[1] = "<START>"
index_to_word[2] = "<UNK>"

def decode_review(review):
    return " ".join(index_to_word.get(i, "<UNK>") for i in review)

print("\nFirst 10 IMDB reviews (decoded text):\n")

for i in range(10):
    print(f"Review {i+1} (Label: {'Positive' if y_train[i] == 1 else 'Negative'}):")
    print(decode_review(X_train_raw[i])[:500])  # limit length
    print("-" * 80)

#Pre Processing
import re

def preprocess(sentences):
    processed = []
    for s in sentences:
        s = s.lower()
        s = re.sub(r'[^a-z\s]', '', s)
        processed.append(s.split())
    return processed

train_tokens = preprocess(train_texts)
test_tokens = preprocess(test_texts)

# Print first 10 preprocessed training samples
for i, tokens in enumerate(train_tokens[:10], start=1):
    print(f"Sentence {i}: {tokens}")

#Vectorization Method 1: TF-IDF
from sklearn.feature_extraction.text import TfidfVectorizer

tfidf = TfidfVectorizer(max_features=5000)
X_train_tfidf = tfidf.fit_transform(train_texts)
X_test_tfidf = tfidf.transform(test_texts)

print("TF-IDF shape:", X_train_tfidf.shape)

pip install gensim

#Vectorization Method 2: Word2Vec

from gensim.models import Word2Vec
import numpy as np

w2v_model = Word2Vec(
    sentences=train_tokens,
    vector_size=100,
    window=5,
    min_count=2,
    workers=4
)

def sentence_vector_w2v(sentence, model):
    vectors = [model.wv[w] for w in sentence if w in model.wv]
    if len(vectors) == 0:
        return np.zeros(model.vector_size)
    return np.mean(vectors, axis=0)

X_train_w2v = np.array([sentence_vector_w2v(s, w2v_model) for s in train_tokens])
X_test_w2v = np.array([sentence_vector_w2v(s, w2v_model) for s in test_tokens])

print("Word2Vec shape:", X_train_w2v.shape)

!wget http://nlp.stanford.edu/data/glove.6B.zip
!unzip glove.6B.zip

#Vectorization Method 3: GloVeVectorization Method
glove = {}
with open("/content/glove.6B.100d.txt", "r", encoding="utf-8") as f:
    for line in f:
        values = line.split()
        glove[values[0]] = np.array(values[1:], dtype="float32")

def sentence_vector_glove(sentence, glove, dim=100):
    vectors = [glove[w] for w in sentence if w in glove]
    if len(vectors) == 0:
        return np.zeros(dim)
    return np.mean(vectors, axis=0)

X_train_glove = np.array([sentence_vector_glove(s, glove) for s in train_tokens])
X_test_glove = np.array([sentence_vector_glove(s, glove) for s in test_tokens])

print("GloVe shape:", X_train_glove.shape)

#Compare the Vectors (Same Review)
i = 0  # first review

print("TF-IDF vector size:", X_train_tfidf[i].shape)
print("Word2Vec vector size:", X_train_w2v[i].shape)
print("GloVe vector size:", X_train_glove[i].shape)

#Sentimental Analysis Same Classifier with Different Vectors

from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

# TF-IDF
clf_tfidf = LogisticRegression(max_iter=1000)
clf_tfidf.fit(X_train_tfidf, y_train)
print("TF-IDF Accuracy:", accuracy_score(y_test, clf_tfidf.predict(X_test_tfidf)))

# Word2Vec
clf_w2v = LogisticRegression(max_iter=1000)
clf_w2v.fit(X_train_w2v, y_train)
print("Word2Vec Accuracy:", accuracy_score(y_test, clf_w2v.predict(X_test_w2v)))

# GloVe
clf_glove = LogisticRegression(max_iter=1000)
clf_glove.fit(X_train_glove, y_train)
print("GloVe Accuracy:", accuracy_score(y_test, clf_glove.predict(X_test_glove)))

#Accuracy Comparision in Percentage

from sklearn.metrics import accuracy_score

# Predictions
y_pred_tfidf = clf_tfidf.predict(X_test_tfidf)
y_pred_w2v   = clf_w2v.predict(X_test_w2v)
y_pred_glove = clf_glove.predict(X_test_glove)

# Accuracy (percentage)
acc_tfidf = accuracy_score(y_test, y_pred_tfidf) * 100
acc_w2v   = accuracy_score(y_test, y_pred_w2v) * 100
acc_glove = accuracy_score(y_test, y_pred_glove) * 100

print("Model Accuracy Comparison (IMDB Dataset)")
print("----------------------------------------")
print(f"TF-IDF   Accuracy : {acc_tfidf:.2f}%")
print(f"Word2Vec Accuracy : {acc_w2v:.2f}%")
print(f"GloVe    Accuracy : {acc_glove:.2f}%")

#Table View for Accuracy Comparision
import pandas as pd

results = pd.DataFrame({
    "Model": ["TF-IDF", "Word2Vec", "GloVe"],
    "Accuracy (%)": [acc_tfidf, acc_w2v, acc_glove]
})

print(results)

#why is TF-IDF better?

#1. TF-IDF is task-aligned for sentiment classification.
#Word2Vec / GloVe are generic semantic embeddings.
#2. excellent, terrible, boring, amazing, waste - high weightage in TF-IDF

# 3. Word2VEc - Use averaged embeddings

# Glove - Embeddings weight trained on Wikipedia data not on IMDB dataset.