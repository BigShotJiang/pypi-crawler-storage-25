
# =========================================
# Step 1: Import Libraries
# =========================================

import tensorflow as tf
import matplotlib.pyplot as plt
import numpy as np

from tensorflow.keras.datasets import cifar10
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense


# =========================================
# Step 2: Load Dataset
# =========================================

(x_train, y_train), (x_test, y_test) = cifar10.load_data()

print("Training images:", x_train.shape)
print("Testing images:", x_test.shape)


# =========================================
# Step 3: Normalize Images
# =========================================

x_train = x_train / 255.0
x_test = x_test / 255.0


# =========================================
# Step 4: Class Names
# =========================================

class_names = [
'airplane','automobile','bird','cat','deer',
'dog','frog','horse','ship','truck'
]


# =========================================
# Step 5: Build CNN Model
# =========================================

model = Sequential()

model.add(Conv2D(32,(3,3),activation='relu',input_shape=(32,32,3)))
model.add(MaxPooling2D((2,2)))

model.add(Conv2D(64,(3,3),activation='relu'))
model.add(MaxPooling2D((2,2)))

model.add(Conv2D(64,(3,3),activation='relu'))

model.add(Flatten())

model.add(Dense(64,activation='relu'))
model.add(Dense(10,activation='softmax'))

model.summary()


# =========================================
# Step 6: Compile Model
# =========================================

model.compile(
optimizer='adam',
loss='sparse_categorical_crossentropy',
metrics=['accuracy']
)


# =========================================
# Step 7: Train Model
# =========================================

model.fit(
x_train,
y_train,
epochs=5,
validation_data=(x_test,y_test)
)


# =========================================
# Step 8: Predict an Image
# =========================================

index = 10

prediction = model.predict(x_test[index].reshape(1,32,32,3))

predicted_class = np.argmax(prediction)

print("Predicted Class:", class_names[predicted_class])
print("Actual Class:", class_names[y_test[index][0]])


# =========================================
# Step 9: Display Image with Name
# =========================================

plt.imshow(x_test[index])
plt.title("Predicted: " + class_names[predicted_class])
plt.axis("off")
plt.show()