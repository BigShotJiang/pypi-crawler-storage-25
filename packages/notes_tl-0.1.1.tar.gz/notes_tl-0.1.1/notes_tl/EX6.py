


# ============================================
# STEP 1 : Import Libraries
# ============================================

import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt

from tensorflow.keras.datasets import imdb
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding

from sklearn.decomposition import PCA


# ============================================
# STEP 2 : Load Dataset
# ============================================

max_features = 10000

(x_train, y_train), (x_test, y_test) = imdb.load_data(num_words=max_features)

print("Training samples:", len(x_train))


# ============================================
# STEP 3 : Padding
# ============================================

maxlen = 200

x_train = pad_sequences(x_train, maxlen=maxlen)


# ============================================
# STEP 4 : Build Embedding Model
# ============================================

embedding_dim = 20

model = Sequential()

model.add(
    Embedding(
        input_dim=max_features,
        output_dim=embedding_dim,
        input_length=maxlen
    )
)

model.build((None, maxlen))


# ============================================
# STEP 5 : Get Embedding Matrix
# ============================================

embedding_matrix = model.layers[0].get_weights()[0]

print("Embedding matrix shape:", embedding_matrix.shape)


# ============================================
# STEP 6 : Word Index
# ============================================

word_index = imdb.get_word_index()
reverse_word_index = {v: k for k, v in word_index.items()}


# ============================================
# STEP 7 : Select Few Words
# ============================================

words = ["good","bad","movie","film","love","story","great","worst"]

vectors = []
labels = []

for w in words:

    idx = word_index.get(w)

    if idx and idx < max_features:

        vectors.append(embedding_matrix[idx])
        labels.append(w)


vectors = np.array(vectors)


# ============================================
# STEP 8 : Reduce Dimensions (PCA)
# ============================================

pca = PCA(n_components=2)

reduced = pca.fit_transform(vectors)


# ============================================
# STEP 9 : Plot Colored Word Embeddings
# ============================================

plt.figure(figsize=(8,6))

for i, word in enumerate(labels):

    x = reduced[i][0]
    y = reduced[i][1]

    plt.scatter(x, y)
    plt.text(x+0.01, y+0.01, word)

plt.title("Word Embedding Visualization")
plt.xlabel("Dimension 1")
plt.ylabel("Dimension 2")

plt.show()