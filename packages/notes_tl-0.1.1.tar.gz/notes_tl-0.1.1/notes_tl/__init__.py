from __future__ import annotations

import os
import shutil

from .EX1 import EX1
from .EX2 import EX2
from .EX3 import EX3
from .EX4 import EX4
from .EX5 import EX5
from .EX6 import EX6
from .EX7 import EX7
from .EX8 import EX8
from .EX9 import EX9
from .EX10 import EX10


def list_experiments():
    return [f"EX{i}" for i in range(1, 11)]


def program(n):
    try:
        n = int(n)
    except (TypeError, ValueError):
        print("Invalid input: n must be an integer from 1 to 10")
        return

    if n < 1 or n > 10:
        print("Invalid input: n must be an integer from 1 to 10")
        return

    src = os.path.join(os.path.dirname(__file__), f"EX{n}.py")
    dst = os.path.join(os.getcwd(), f"EX{n}.py")

    if not os.path.exists(src):
        print(f"EX{n}.py not found in package")
        return

    shutil.copy(src, dst)
    print(f"EX{n}.py downloaded to current directory")


__all__ = [
    "EX1",
    "EX2",
    "EX3",
    "EX4",
    "EX5",
    "EX6",
    "EX7",
    "EX8",
    "EX9",
    "EX10",
    "list_experiments",
    "program",
]
