#!/usr/bin/env python3
"""Shared timing anomaly formatting helpers."""

from collections.abc import Iterable
from pathlib import Path

from rich.console import Console

from screenshooter.modules.settings.logging_utils import create_verify_timings_log_file
from screenshooter.modules.settings.settings_helper import get_screenshots_dir

from .models import DatabaseTimingAnomaly

console = Console()


def _format_seconds_or_na(value: int | None) -> str:
    """Format integer seconds or return NA."""
    if value is None:
        return "NA"
    return str(value)


def _build_timing_anomalies_report_lines(
    normalized_rows: list[DatabaseTimingAnomaly],
) -> list[str]:
    """Build plain-text timing anomaly report lines for console output."""
    lines = ["", "Duration Anomalies"]
    if not normalized_rows:
        lines.append("No duration anomalies found.")
        return lines

    client_width = max(len("Client"), *(len(row.client_name) for row in normalized_rows))
    project_width = max(len("Project"), *(len(row.project_name) for row in normalized_rows))
    session_width = max(len("Session"), *(len(row.session_name) for row in normalized_rows))
    duration_width = len("duration_seconds")
    computed_width = len("computed_seconds")

    header = (
        f"{'Client':<{client_width}}  "
        f"{'Project':<{project_width}}  "
        f"{'Session':<{session_width}}  "
        f"{'duration_seconds':>{duration_width}}  "
        f"{'computed_seconds':>{computed_width}}  "
        "Reason"
    )
    lines.append(header)
    lines.append("-" * len(header))
    for row in normalized_rows:
        lines.append(
            f"{row.client_name:<{client_width}}  "
            f"{row.project_name:<{project_width}}  "
            f"{row.session_name:<{session_width}}  "
            f"{_format_seconds_or_na(row.duration_seconds):>{duration_width}}  "
            f"{_format_seconds_or_na(row.computed_seconds):>{computed_width}}  "
            f"{row.reason}"
        )

    lines.append(f"Found {len(normalized_rows)} anomalous sessions.")
    return lines


def _build_timing_anomalies_log_lines(normalized_rows: list[DatabaseTimingAnomaly]) -> list[str]:
    """Build plain-text timing anomaly report lines for saved log output."""
    screenshots_dir = Path(get_screenshots_dir()).resolve()
    lines = _build_timing_anomalies_report_lines(normalized_rows)
    if not normalized_rows:
        return lines

    lines.append("")
    lines.append("Filesystem Paths")
    lines.append(
        "These paths point to the project and session directories on disk. "
        "The session path contains files such as session.log and session.json."
    )

    for index, row in enumerate(normalized_rows, start=1):
        project_path = (
            screenshots_dir / row.client_directory_name / row.project_directory_name
        ).resolve()
        session_path = (project_path / "sessions" / row.session_name).resolve()
        lines.append("")
        lines.append(
            f"Anomaly {index}: {row.client_name} / {row.project_name} / {row.session_name}"
        )
        lines.append(f"Project path: {project_path}")
        lines.append(f"Session path: {session_path}")
    return lines


def _write_timing_anomalies_report(report_lines: list[str]) -> Path:
    """Write a timing anomaly report to a dated log file."""
    log_file = create_verify_timings_log_file()
    log_file.write_text("\n".join(report_lines) + "\n", encoding="utf-8")
    return log_file


def print_timing_anomalies(rows: Iterable[DatabaseTimingAnomaly]) -> Path:
    """Print anomalous session durations and save the same report to a dated log file."""
    normalized_rows = list(rows)
    console_lines = _build_timing_anomalies_report_lines(normalized_rows)
    log_lines = _build_timing_anomalies_log_lines(normalized_rows)

    console.print()
    console.print("[bold]Duration Anomalies[/bold]")
    if not normalized_rows:
        console.print("No duration anomalies found.")
    else:
        for line in console_lines[2:]:
            console.print(line)

    log_file = _write_timing_anomalies_report(log_lines)
    console.print(f"[dim]Verification log:[/dim] {log_file}")
    return log_file
