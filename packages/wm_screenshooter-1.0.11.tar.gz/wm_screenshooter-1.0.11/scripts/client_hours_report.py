#!/usr/bin/env python3
"""Generate a per-client hours report from the ScreenShooter database.

This script is intended for local analysis and billing support. It reads the
SQLite database used by ScreenShooter and prints total tracked time per client.
"""

from __future__ import annotations

import argparse
import sqlite3
from dataclasses import dataclass
from pathlib import Path

from screenshooter.modules.database import (
    DatabaseManager,
    DatabaseOperations,
    get_default_database_path,
)
from screenshooter.modules.database.models import DatabaseTimingAnomaly
from screenshooter.modules.database.timing_verification import print_timing_anomalies


@dataclass(frozen=True)
class ClientHoursRow:
    """A single client-hours row for reporting."""

    client_name: str
    project_count: int
    session_count: int
    total_seconds: int

    @property
    def total_hours(self) -> float:
        """Return total seconds converted to hours."""
        return self.total_seconds / 3600.0

    def revenue(self, hourly_rate: float) -> float:
        """Return billed revenue for this client at the given hourly rate."""
        return self.total_hours * hourly_rate


def _build_query(include_archived: bool) -> str:
    """Build SQL query for per-client time aggregation.

    Args:
        include_archived: Whether to include archived clients/projects/sessions.

    Returns:
        SQL statement string.
    """
    archived_filter = ""
    if not include_archived:
        archived_filter = (
            "WHERE c.archived_at IS NULL AND p.archived_at IS NULL AND s.archived_at IS NULL"
        )

    return f"""
        SELECT
            c.name AS client_name,
            COUNT(DISTINCT p.id) AS project_count,
            COUNT(DISTINCT s.id) AS session_count,
            COALESCE(
                SUM(
                    CASE
                        WHEN s.duration_seconds IS NOT NULL AND s.duration_seconds > 0 THEN
                            s.duration_seconds
                        WHEN s.duration_seconds IS NOT NULL THEN 0
                        WHEN s.start_time IS NOT NULL AND s.end_time IS NOT NULL THEN
                            MAX(
                                0,
                                CAST(
                                    (julianday(s.end_time) - julianday(s.start_time)) * 86400
                                    AS INTEGER
                                )
                            )
                        ELSE 0
                    END
                ),
                0
            ) AS total_seconds
        FROM clients c
        LEFT JOIN projects p ON p.client_id = c.id
        LEFT JOIN sessions s ON s.project_id = p.id
        {archived_filter}
        GROUP BY c.id, c.name
        ORDER BY total_seconds DESC, c.name ASC
    """


def fetch_client_hours(db_path: Path, include_archived: bool) -> list[ClientHoursRow]:
    """Fetch per-client hours from the SQLite database.

    Args:
        db_path: Path to the ScreenShooter SQLite database.
        include_archived: Whether archived entities are included.

    Returns:
        List of aggregated rows ordered by total seconds descending.
    """
    query = _build_query(include_archived=include_archived)
    with sqlite3.connect(db_path) as connection:
        connection.row_factory = sqlite3.Row
        cursor = connection.execute(query)
        rows = cursor.fetchall()

    return [
        ClientHoursRow(
            client_name=str(row["client_name"]),
            project_count=int(row["project_count"]),
            session_count=int(row["session_count"]),
            total_seconds=max(0, int(row["total_seconds"])),
        )
        for row in rows
    ]


def fetch_duration_anomalies(db_path: Path, include_archived: bool) -> list[DatabaseTimingAnomaly]:
    """Fetch sessions with suspicious duration values.

    Args:
        db_path: Path to the ScreenShooter SQLite database.
        include_archived: Whether archived entities are included.

    Returns:
        List of anomalous sessions.
    """
    default_db_path = get_default_database_path().expanduser().resolve()
    db_manager = None
    if db_path != default_db_path:
        db_manager = DatabaseManager(str(db_path))
    try:
        db_ops = DatabaseOperations(db_manager=db_manager)
        anomalies = db_ops.list_timing_anomalies(include_archived=include_archived)
    finally:
        if db_manager is not None:
            db_manager.close()
    return anomalies


def _format_duration(total_seconds: int) -> str:
    """Format seconds as `Hh Mm` for quick reading."""
    hours = total_seconds // 3600
    minutes = (total_seconds % 3600) // 60
    return f"{hours}h {minutes:02d}m"


def _normalize_excluded_clients(raw_values: list[str]) -> set[str]:
    """Normalize excluded-client values to lowercase names.

    Accepts repeated args and comma-separated lists.
    """
    excluded_clients: set[str] = set()
    for raw in raw_values:
        parts = [part.strip().lower() for part in raw.split(",")]
        excluded_clients.update(part for part in parts if part)
    return excluded_clients


def _filter_excluded_clients(
    rows: list[ClientHoursRow], excluded_clients: set[str]
) -> list[ClientHoursRow]:
    """Exclude clients by case-insensitive exact name match."""
    if not excluded_clients:
        return rows
    return [row for row in rows if row.client_name.strip().lower() not in excluded_clients]


def _filter_excluded_anomalies(
    rows: list[DatabaseTimingAnomaly], excluded_clients: set[str]
) -> list[DatabaseTimingAnomaly]:
    """Exclude anomalies by case-insensitive exact client name."""
    if not excluded_clients:
        return rows
    return [row for row in rows if row.client_name.strip().lower() not in excluded_clients]


def print_report(
    rows: list[ClientHoursRow], hourly_rate: float | None, currency_symbol: str
) -> None:
    """Print the client-hours report to stdout.

    Args:
        rows: Aggregated per-client rows.
        hourly_rate: Per-hour billing rate, or None to omit pricing output.
        currency_symbol: Currency prefix to use when printing monetary amounts.
    """
    if not rows:
        print("No client/session data found.")
        return

    name_width = max(len("Client"), *(len(row.client_name) for row in rows))
    projects_width = len("Projects")
    sessions_width = len("Sessions")
    tracked_width = len("Tracked")
    hours_width = len("Hours")
    show_revenue = hourly_rate is not None
    revenue_width = len("Revenue")

    header = (
        f"{'Client':<{name_width}}  "
        f"{'Projects':>{projects_width}}  "
        f"{'Sessions':>{sessions_width}}  "
        f"{'Tracked':>{tracked_width}}  "
        f"{'Hours':>{hours_width}}"
    )
    if show_revenue:
        header += f"  {'Revenue':>{revenue_width}}"
    print(header)
    print("-" * len(header))

    total_seconds_all_clients = 0
    total_revenue = 0.0
    for row in rows:
        total_seconds_all_clients += row.total_seconds
        line = (
            f"{row.client_name:<{name_width}}  "
            f"{row.project_count:>{projects_width}}  "
            f"{row.session_count:>{sessions_width}}  "
            f"{_format_duration(row.total_seconds):>{tracked_width}}  "
            f"{row.total_hours:>{hours_width}.2f}"
        )
        if show_revenue and hourly_rate is not None:
            client_revenue = row.revenue(hourly_rate)
            total_revenue += client_revenue
            line += (
                f"  {currency_symbol}{client_revenue:>{revenue_width - len(currency_symbol)}.2f}"
            )
        print(line)

    print("-" * len(header))
    total_line = (
        f"{'TOTAL':<{name_width}}  "
        f"{'':>{projects_width}}  "
        f"{'':>{sessions_width}}  "
        f"{_format_duration(total_seconds_all_clients):>{tracked_width}}  "
        f"{(total_seconds_all_clients / 3600.0):>{hours_width}.2f}"
    )
    if show_revenue:
        total_line += (
            f"  {currency_symbol}{total_revenue:>{revenue_width - len(currency_symbol)}.2f}"
        )
    print(total_line)


def parse_args() -> argparse.Namespace:
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(
        description="Print total tracked hours per client from ScreenShooter database."
    )
    parser.add_argument(
        "--db-path",
        type=Path,
        default=get_default_database_path(),
        help="Path to screenshooter.db (defaults to ~/.config/screenshooter/screenshooter.db)",
    )
    archive_group = parser.add_mutually_exclusive_group()
    archive_group.add_argument(
        "--include-archived",
        action="store_true",
        dest="include_archived",
        help="Include archived clients/projects/sessions in totals (default).",
    )
    archive_group.add_argument(
        "--active-only",
        action="store_false",
        dest="include_archived",
        help="Exclude archived clients/projects/sessions from totals.",
    )
    parser.set_defaults(include_archived=True)
    parser.add_argument(
        "--exclude-client",
        action="append",
        default=[],
        help=(
            "Exclude client by exact name (case-insensitive). Can be repeated or comma-separated."
        ),
    )
    parser.add_argument(
        "--hourly-rate",
        type=float,
        default=None,
        help="Hourly billing rate to calculate revenue.",
    )
    parser.add_argument(
        "--currency-symbol",
        type=str,
        default="$",
        help="Currency symbol for revenue output (default: $).",
    )
    parser.add_argument(
        "--show-anomalies",
        action="store_true",
        help="Print sessions with suspicious duration values.",
    )
    return parser.parse_args()


def main() -> int:
    """Run CLI script and print per-client hour totals."""
    args = parse_args()
    db_path: Path = args.db_path.expanduser().resolve()

    if not db_path.exists():
        print(f"Database not found: {db_path}")
        return 1

    hourly_rate: float | None = args.hourly_rate
    if hourly_rate is not None and hourly_rate < 0:
        print("Hourly rate must be >= 0.")
        return 1

    rows = fetch_client_hours(db_path=db_path, include_archived=args.include_archived)
    excluded_clients = _normalize_excluded_clients(args.exclude_client)
    filtered_rows = _filter_excluded_clients(rows, excluded_clients)
    print_report(
        filtered_rows,
        hourly_rate=hourly_rate,
        currency_symbol=args.currency_symbol,
    )

    if args.show_anomalies:
        anomalies = fetch_duration_anomalies(
            db_path=db_path, include_archived=args.include_archived
        )
        filtered_anomalies = _filter_excluded_anomalies(anomalies, excluded_clients)
        print_timing_anomalies(filtered_anomalies)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
