from __future__ import annotations

from pathlib import Path

import pytest

from comate_agent_sdk.system_tools.task.models import TaskStatus
from comate_agent_sdk.system_tools.task.store import TaskStore, TaskStoreConflictError


def _store(tmp_path: Path) -> TaskStore:
    return TaskStore(store_dir=tmp_path, list_id="demo")


def test_create_and_list_tasks(tmp_path: Path) -> None:
    store = _store(tmp_path)
    first = store.create_task(subject="Design interface")
    second = store.create_task(subject="Implement backend")
    store.update_task(second.id, extend_blocked_by=[first.id])

    tasks = store.list_tasks()
    assert [task.id for task in tasks] == ["1", "2"]
    updated_second = store.get_task(second.id)
    assert updated_second.blocked_by == ["1"]
    assert store.get_open_blocked_by("2") == ["1"]


def test_update_task_and_filter_open_blockers(tmp_path: Path) -> None:
    store = _store(tmp_path)
    first = store.create_task(subject="A")
    second = store.create_task(subject="B")
    store.update_task(second.id, extend_blocked_by=[first.id])

    store.update_task(first.id, status=TaskStatus.COMPLETED)

    assert store.get_open_blocked_by(second.id) == []
    updated = store.update_task(second.id, status=TaskStatus.IN_PROGRESS, owner="worker")
    assert updated.status == TaskStatus.IN_PROGRESS
    assert updated.owner == "worker"


def test_cycle_detection_rejects_updates(tmp_path: Path) -> None:
    store = _store(tmp_path)
    first = store.create_task(subject="A")
    second = store.create_task(subject="B")
    store.update_task(second.id, extend_blocked_by=[first.id])

    with pytest.raises(TaskStoreConflictError):
        store.update_task(first.id, extend_blocked_by=[second.id])


def test_delete_rejects_when_task_is_still_depended_on(tmp_path: Path) -> None:
    store = _store(tmp_path)
    first = store.create_task(subject="A")
    second = store.create_task(subject="B")
    store.update_task(first.id, extend_blocks=[second.id])

    with pytest.raises(TaskStoreConflictError):
        store.delete_task(first.id)


def test_extend_blocked_by_atomic(tmp_path: Path) -> None:
    store = _store(tmp_path)
    a = store.create_task(subject="A")
    b = store.create_task(subject="B")
    c = store.create_task(subject="C")
    store.update_task(c.id, extend_blocked_by=[a.id])

    updated = store.update_task(c.id, extend_blocked_by=[b.id])
    assert updated.blocked_by == [a.id, b.id]


def test_blocks_persisted_in_json(tmp_path: Path) -> None:
    """blocks field is written to disk and survives reload."""
    store = _store(tmp_path)
    a = store.create_task(subject="A")
    b = store.create_task(subject="B")
    store.update_task(a.id, extend_blocks=[b.id])

    # Reload from disk
    store2 = _store(tmp_path)
    a_reloaded = store2.get_task(a.id)
    assert a_reloaded is not None
    assert b.id in a_reloaded.blocks
    b_reloaded = store2.get_task(b.id)
    assert b_reloaded is not None
    assert a.id in b_reloaded.blocked_by


def test_extend_blocks_cycle_via_blocked_by(tmp_path: Path) -> None:
    store = _store(tmp_path)
    a = store.create_task(subject="A")
    b = store.create_task(subject="B")
    store.update_task(b.id, extend_blocked_by=[a.id])

    with pytest.raises(TaskStoreConflictError):
        store.update_task(b.id, extend_blocks=[a.id])


def test_create_task_has_empty_dependencies(tmp_path: Path) -> None:
    store = _store(tmp_path)
    task = store.create_task(subject="New task")
    assert task.blocked_by == []
    assert task.blocks == []


def test_v1_data_migration_fills_empty_blocks(tmp_path: Path) -> None:
    """Reading v1 JSON (no blocks field) should auto-fill blocks=[]."""
    store = _store(tmp_path)
    task = store.create_task(subject="Legacy task")
    import json
    raw = json.loads(store.path.read_text())
    del raw["tasks"]["1"]["blocks"]
    raw["schema_version"] = "1"
    store.path.write_text(json.dumps(raw))
    loaded = store.get_task("1")
    assert loaded is not None
    assert loaded.blocks == []


def test_extend_blocked_by_syncs_blocks(tmp_path: Path) -> None:
    """When C adds A to its blocked_by, A.blocks should include C."""
    store = _store(tmp_path)
    a = store.create_task(subject="A")
    store.create_task(subject="C")
    store.update_task("2", extend_blocked_by=[a.id])
    a_updated = store.get_task(a.id)
    assert a_updated is not None
    assert "2" in a_updated.blocks


def test_extend_blocks_syncs_blocked_by(tmp_path: Path) -> None:
    """When A adds B to its blocks, B.blocked_by should include A."""
    store = _store(tmp_path)
    a = store.create_task(subject="A")
    b = store.create_task(subject="B")
    store.update_task(a.id, extend_blocks=[b.id])
    b_updated = store.get_task(b.id)
    assert b_updated is not None
    assert a.id in b_updated.blocked_by
    a_updated = store.get_task(a.id)
    assert a_updated is not None
    assert b.id in a_updated.blocks


def test_extend_blocks_cycle_detection(tmp_path: Path) -> None:
    """A blocked_by B; trying to make B.blocks include A should fail (cycle)."""
    store = _store(tmp_path)
    a = store.create_task(subject="A")
    b = store.create_task(subject="B")
    store.update_task(b.id, extend_blocked_by=[a.id])
    with pytest.raises(TaskStoreConflictError):
        store.update_task(b.id, extend_blocks=[a.id])


def test_delete_cleans_up_blocked_by_references(tmp_path: Path) -> None:
    """After deleting a leaf task, its ID is removed from upstream tasks' blocks."""
    store = _store(tmp_path)
    a = store.create_task(subject="A")
    b = store.create_task(subject="B")
    store.update_task(b.id, extend_blocked_by=[a.id])
    # A.blocks=[B], B.blocked_by=[A]. B has no blocks, so B is deletable.
    store.delete_task(b.id)
    a_after = store.get_task(a.id)
    assert a_after is not None
    assert b.id not in a_after.blocks
