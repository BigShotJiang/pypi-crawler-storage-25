import unittest

from comate_agent_sdk.context.truncation import TruncationRecord
from comate_agent_sdk.system_tools.output_formatter import OutputFormatter, _default_truncation
from comate_agent_sdk.system_tools.tool_result import err, ok


class TestOutputFormatter(unittest.TestCase):
    def test_format_read_with_truncation_footer_and_hints(self) -> None:
        payload = ok(
            data={
                "content": "     1\tline1\n     2\tline2",
                "total_lines": 1200,
                "lines_returned": 2,
                "has_more": True,
                "next_offset_line": 2,
                "truncated": True,
                "artifact": {"relpath": ".agent_workspace/.artifacts/read/abc.txt"},
            },
            meta={
                "file_path": "src/main.py",
                "offset_line": 0,
                "limit_lines": 2,
            },
        )

        formatted = OutputFormatter.format(
            tool_name="Read",
            tool_call_id="tc_read_1",
            result_dict=payload,
        )

        self.assertIn("# Read: src/main.py", formatted.text)
        self.assertIn("Lines 1-2 of 1200", formatted.text)
        self.assertIn("Recommended next step:", formatted.text)
        self.assertEqual(formatted.meta.status, "ok")
        self.assertIsNotNone(formatted.meta.truncation)
        self.assertIsInstance(formatted.meta.truncation, TruncationRecord)
        self.assertTrue(formatted.meta.truncation.formatter_truncated)
        self.assertEqual(formatted.meta.truncation.formatter_reason, "line_limit")
        self.assertIsNotNone(formatted.meta.retrieval_hints)
        self.assertGreaterEqual(len(formatted.meta.retrieval_hints), 2)

    def test_format_write_includes_file_ops(self) -> None:
        payload = ok(
            data={
                "bytes_written": 12,
                "file_bytes": 40,
                "created": False,
                "sha256": "after_hash",
                "relpath": "src/config.json",
            },
            meta={
                "file_path": "src/config.json",
                "operation": "overwrite",
                "sha256_before": "before_hash",
                "sha256_after": "after_hash",
            },
        )

        formatted = OutputFormatter.format(
            tool_name="Write",
            tool_call_id="tc_write_1",
            result_dict=payload,
        )

        self.assertIn("# Write: src/config.json", formatted.text)
        self.assertIn("Operation: overwrite", formatted.text)
        self.assertEqual(formatted.meta.status, "ok")
        self.assertIsNotNone(formatted.meta.file_ops)
        self.assertEqual(formatted.meta.file_ops["operation"], "overwrite")
        self.assertEqual(formatted.meta.file_ops["sha256_after"], "after_hash")

    def test_format_write_prefers_resolved_file_path(self) -> None:
        payload = ok(
            data={
                "bytes_written": 7,
                "file_bytes": 7,
                "created": True,
                "sha256": "after_hash",
                "relpath": "optimize-thinking-blocks-compaction.md",
            },
            meta={
                "file_path": "~/.agent/plans/optimize-thinking-blocks-compaction.md",
                "resolved_file_path": "/tmp/home/.agent/plans/optimize-thinking-blocks-compaction.md",
                "operation": "create",
                "sha256_after": "after_hash",
            },
        )

        formatted = OutputFormatter.format(
            tool_name="Write",
            tool_call_id="tc_write_2",
            result_dict=payload,
        )

        self.assertIn(
            "# Write: /tmp/home/.agent/plans/optimize-thinking-blocks-compaction.md",
            formatted.text,
        )
        self.assertEqual(
            formatted.meta.file_ops["file_path"],
            "/tmp/home/.agent/plans/optimize-thinking-blocks-compaction.md",
        )

    def test_format_error_includes_retry_footer(self) -> None:
        payload = err(
            "INVALID_ARGUMENT",
            "invalid path",
            field_errors=[{"field": "path", "message": "must be absolute"}],
        )
        formatted = OutputFormatter.format(
            tool_name="Grep",
            tool_call_id="tc_grep_1",
            result_dict=payload,
        )

        self.assertIn("# Grep Error", formatted.text)
        self.assertIn("Code: INVALID_ARGUMENT", formatted.text)
        self.assertIn("Recommended next step:", formatted.text)
        self.assertEqual(formatted.meta.status, "error")
        self.assertEqual(formatted.meta.error_code, "INVALID_ARGUMENT")
        self.assertEqual(formatted.meta.error_field, "path")

    def test_format_ask_user_question(self) -> None:
        payload = ok(
            data={
                "status": "waiting_for_input",
                "questions": [
                    {
                        "question": "Which option?",
                        "header": "Choice",
                        "options": [
                            {"label": "A", "description": "Option A"},
                            {"label": "B", "description": "Option B"},
                        ],
                        "multiSelect": False,
                    }
                ],
            },
            message="Prepared 1 question(s) for user",
        )
        formatted = OutputFormatter.format(
            tool_name="AskUserQuestion",
            tool_call_id="tc_question_1",
            result_dict=payload,
        )

        self.assertIn("# AskUserQuestion", formatted.text)
        self.assertIn("Question count: 1", formatted.text)
        self.assertEqual(formatted.meta.status, "ok")

    def test_default_truncation_returns_truncation_record(self) -> None:
        record = _default_truncation(
            {
                "truncated": True,
                "raw_output_truncated": True,
                "total_matches": 123,
            }
        )
        self.assertIsNotNone(record)
        assert record is not None
        self.assertIsInstance(record, TruncationRecord)
        self.assertTrue(record.formatter_truncated)
        self.assertIn("output_capture_limit", record.formatter_reason)
        self.assertEqual(record.formatter_total_estimate, 123)

    def test_format_read_no_truncation_returns_none(self) -> None:
        payload = ok(
            data={
                "content": "     1\tline1\n     2\tline2",
                "total_lines": 2,
                "lines_returned": 2,
                "has_more": False,
                "truncated": False,
            },
            meta={
                "file_path": "src/main.py",
                "offset_line": 0,
                "limit_lines": 2,
            },
        )
        formatted = OutputFormatter.format(
            tool_name="Read",
            tool_call_id="tc_read_no_truncation",
            result_dict=payload,
        )
        self.assertIsNone(formatted.meta.truncation)

    def test_format_task_result_with_open_tasks(self) -> None:
        payload = ok(
            data={
                "list_id": "shared",
                "total": 4,
                "by_status": {
                    "pending": 2,
                    "in_progress": 1,
                "completed": 1,
                },
                "tasks": [
                    {
                        "id": "1",
                        "subject": "Fix authentication bug",
                        "status": "pending",
                        "owner": "andy",
                        "description": "Investigate the auth middleware token parsing path.",
                        "open_blocked_by": [],
                    },
                    {
                        "id": "2",
                        "subject": "Add unit tests",
                        "status": "in_progress",
                        "owner": "worker-b",
                        "description": "Cover the edge cases around expired tokens.",
                        "open_blocked_by": [],
                    },
                    {
                        "id": "3",
                        "subject": "Update docs",
                        "status": "pending",
                        "owner": "",
                        "open_blocked_by": ["1"],
                    },
                    {
                        "id": "4",
                        "subject": "Refactor code",
                        "status": "completed",
                        "owner": "worker-c",
                        "open_blocked_by": [],
                    },
                ],
            },
        )

        formatted = OutputFormatter.format(
            tool_name="TaskList",
            tool_call_id="tc_task_1",
            result_dict=payload,
        )

        self.assertIn("# TaskList", formatted.text)
        self.assertIn("Task Namespace: shared", formatted.text)
        self.assertIn("Total tasks: 4", formatted.text)
        self.assertIn("Open Tasks:", formatted.text)
        self.assertIn("- [pending] #1 Fix authentication bug owner=andy", formatted.text)
        self.assertIn("  Description: Investigate the auth middleware token parsing path.", formatted.text)
        self.assertIn("- [in_progress] #2 Add unit tests owner=worker-b", formatted.text)
        self.assertIn("  Description: Cover the edge cases around expired tokens.", formatted.text)
        self.assertIn("blocked_by=#1", formatted.text)
        self.assertEqual(formatted.meta.status, "ok")

    def test_format_task_result_with_selected_task(self) -> None:
        payload = ok(
            data={
                "list_id": "default",
                "task": {
                    "id": "2",
                    "subject": "Finalize release checklist",
                    "status": "completed",
                    "owner": "andy",
                    "description": "Double-check release blockers.",
                    "blocked_by": ["1"],
                    "open_blocked_by": [],
                    "blocks": ["5"],
                    "metadata": {"priority": "high"},
                },
                "blocked_by_detail": [
                    {
                        "id": "1",
                        "subject": "Ship release notes",
                        "status": "completed",
                        "owner": "writer",
                        "open_blocked_by": [],
                    }
                ],
                "blocks_detail": [
                    {
                        "id": "5",
                        "subject": "Publish release",
                        "status": "pending",
                        "owner": "ops",
                        "open_blocked_by": ["2"],
                    }
                ],
                "summary": "tasks=2 pending=0 in_progress=0 completed=2",
            },
        )

        formatted = OutputFormatter.format(
            tool_name="TaskGet",
            tool_call_id="tc_task_2",
            result_dict=payload,
        )

        self.assertIn("# TaskGet", formatted.text)
        self.assertIn("Selected Task:", formatted.text)
        self.assertIn("Task ID: #2", formatted.text)
        self.assertIn("Status: [completed] Finalize release checklist", formatted.text)
        self.assertIn("Owner: andy", formatted.text)
        self.assertIn("Description: Double-check release blockers.", formatted.text)
        self.assertIn("Blocked By: #1", formatted.text)
        self.assertIn("Blocks: #5", formatted.text)
        self.assertIn('Metadata: {"priority": "high"}', formatted.text)
        self.assertIn("Blocked By Detail:", formatted.text)
        self.assertIn("- [completed] #1 Ship release notes owner=writer", formatted.text)
        self.assertIn("Blocks Detail:", formatted.text)
        self.assertIn("- [pending] #5 Publish release owner=ops blocked_by=#2", formatted.text)
        self.assertNotIn("Total tasks: 0", formatted.text)

    def test_format_task_create_result_highlights_task_id_for_follow_up(self) -> None:
        payload = ok(
            data={
                "list_id": "session-123",
                "task": {
                    "id": "1",
                    "subject": "Search TODO comments",
                    "status": "pending",
                    "owner": "andy",
                    "open_blocked_by": [],
                },
                "tasks": [
                    {
                        "id": "1",
                        "subject": "Search TODO comments",
                        "status": "pending",
                        "owner": "andy",
                        "open_blocked_by": [],
                    }
                ],
                "total": 1,
                "by_status": {
                    "pending": 1,
                    "in_progress": 0,
                    "completed": 0,
                },
                "summary": "tasks=1 pending=1 in_progress=0 completed=0",
            },
        )

        formatted = OutputFormatter.format(
            tool_name="TaskCreate",
            tool_call_id="tc_task_create",
            result_dict=payload,
        )

        self.assertIn("Task ID: #1", formatted.text)
        self.assertIn("Owner: andy", formatted.text)
        self.assertIn(
            "Display IDs may appear as `#1`, but use `task_id=\"1\"` for TaskGet/TaskUpdate.",
            formatted.text,
        )
        self.assertIn("Task Namespace: session-123", formatted.text)


if __name__ == "__main__":
    unittest.main(verbosity=2)
