import asyncio
import json
import tempfile
from pathlib import Path

from comate_agent_sdk.system_tools.policy_engine import (
    BASH_COMMAND_POLICY,
    READ_REGISTRY_POLICY,
)


def test_bash_policy_denies_banned_command() -> None:
    violation = BASH_COMMAND_POLICY.validate(
        args=["cat", "a.txt"],
        cwd=Path.cwd(),
        allowed_roots=[Path.cwd()],
    )
    assert violation is not None
    assert violation.code == "POLICY_DENIED"


def test_bash_policy_requires_rg_max_count() -> None:
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        violation = BASH_COMMAND_POLICY.validate(
            args=["rg", "--line-number", "--no-heading", "--color=never", "foo", str(root)],
            cwd=root,
            allowed_roots=[root],
        )
        assert violation is not None
        assert violation.code == "POLICY_DENIED"


def test_bash_policy_accepts_valid_rg_scope() -> None:
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        violation = BASH_COMMAND_POLICY.validate(
            args=[
                "rg",
                "--line-number",
                "--no-heading",
                "--color=never",
                "--max-count",
                "10",
                "foo",
                str(root),
            ],
            cwd=root,
            allowed_roots=[root],
        )
        assert violation is None


def test_read_registry_policy_persists_to_session_root() -> None:
    READ_REGISTRY_POLICY.clear_memory()

    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        session_root = root / "sessions" / "s1"
        target = root / "a.txt"
        target.write_text("x\n", encoding="utf-8")

        async def _run() -> bool:
            await READ_REGISTRY_POLICY.mark_read(
                session_root=session_root,
                session_id="s1",
                path=target,
            )
            return await READ_REGISTRY_POLICY.has_read(
                session_root=session_root,
                session_id="s1",
                path=target,
            )

        assert asyncio.run(_run())
        idx = session_root / "read_index.json"
        assert idx.exists()
        payload = json.loads(idx.read_text(encoding="utf-8"))
        assert payload.get("schema_version") == 2
        assert str(target.resolve()) in payload.get("files", [])


def test_read_registry_cleanup_stale_loops_removes_old_loops():
    """cleanup_stale_loops 应保留当前 loop + 最近 10 个，删除更旧的。"""
    from comate_agent_sdk.system_tools.policy_engine import ReadRegistryPolicy

    policy = ReadRegistryPolicy()
    # 注入 15 个假 loop id（小整数，不会与真实 loop 的内存地址冲突）
    for i in range(1, 16):
        policy._locks_by_loop[i]  # trigger defaultdict to create empty dict

    async def _run():
        policy.cleanup_stale_loops()

    asyncio.run(_run())

    # 当前真实 loop id 不在 1-15 中，所以 1-15 全部参与淘汰
    # 保留最近 10 个（6-15），删除最旧的 5 个（1-5）
    assert len(policy._locks_by_loop) == 10
    for i in range(6, 16):
        assert i in policy._locks_by_loop, f"loop id {i} should be retained"
    for i in range(1, 6):
        assert i not in policy._locks_by_loop, f"loop id {i} should be removed"


def test_read_registry_cleanup_stale_loops_no_op_under_limit():
    """少于等于 10 个旧 loop 时不应删除任何条目。"""
    from comate_agent_sdk.system_tools.policy_engine import ReadRegistryPolicy

    policy = ReadRegistryPolicy()
    for i in range(1, 6):
        policy._locks_by_loop[i]  # trigger defaultdict to create empty dict

    async def _run():
        policy.cleanup_stale_loops()

    asyncio.run(_run())

    assert len(policy._locks_by_loop) == 5
    for i in range(1, 6):
        assert i in policy._locks_by_loop
