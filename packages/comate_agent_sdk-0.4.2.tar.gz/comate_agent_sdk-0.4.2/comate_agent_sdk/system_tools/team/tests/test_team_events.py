"""Tests for team events persistence."""

from __future__ import annotations

import json
import pytest
from pathlib import Path
from comate_agent_sdk.system_tools.team.config import TeamConfig


@pytest.fixture
def team_cfg(tmp_path: Path) -> TeamConfig:
    return TeamConfig(team_name="test-team", base_dir=tmp_path)


class TestTeamConfigLeaderSession:
    def test_set_leader_session_persists(self, team_cfg: TeamConfig) -> None:
        team_cfg.set_leader_session(
            session_id="uuid-123",
            session_root="/home/user/.agent/sessions/-proj/uuid-123",
        )
        raw = json.loads(team_cfg.path.read_text())
        assert raw["leader_session_id"] == "uuid-123"
        assert raw["leader_session_root"] == "/home/user/.agent/sessions/-proj/uuid-123"

    def test_set_leader_session_idempotent(self, team_cfg: TeamConfig) -> None:
        team_cfg.set_leader_session(session_id="a", session_root="/a")
        team_cfg.set_leader_session(session_id="b", session_root="/b")
        raw = json.loads(team_cfg.path.read_text())
        assert raw["leader_session_id"] == "b"

    def test_get_leader_session_returns_defaults(self, team_cfg: TeamConfig) -> None:
        sid, sroot = team_cfg.get_leader_session()
        assert sid == ""
        assert sroot == ""

    def test_get_leader_session_after_set(self, team_cfg: TeamConfig) -> None:
        team_cfg.set_leader_session(session_id="uuid-123", session_root="/path/to/root")
        sid, sroot = team_cfg.get_leader_session()
        assert sid == "uuid-123"
        assert sroot == "/path/to/root"


import asyncio
from unittest.mock import patch

from comate_agent_sdk.system_tools.team.tools import TeamCreate
from comate_agent_sdk.tools.system_context import bind_system_tool_context


def _parse(raw: str) -> dict:
    return json.loads(raw)


class TestTeamCreateLeaderSession:
    def test_team_create_writes_leader_session(self, tmp_path: Path) -> None:
        session_root = tmp_path / "sessions" / "leader-uuid-456"
        session_root.mkdir(parents=True)

        async def _run() -> dict:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": str(tmp_path / "teams")}):
                with bind_system_tool_context(
                    project_root=tmp_path,
                    session_id="leader-uuid-456",
                    session_root=session_root,
                    team_namespace_switcher=lambda _: None,
                ):
                    return _parse(await TeamCreate.execute(
                        team_name="my-team",
                        description="test",
                    ))

        result = asyncio.run(_run())
        assert result["ok"]

        team_cfg = TeamConfig(team_name="my-team", base_dir=tmp_path / "teams")
        sid, sroot = team_cfg.get_leader_session()
        assert sid == "leader-uuid-456"
        assert sroot == str(session_root)


from comate_agent_sdk.system_tools.team.inbox import append_team_event


class TestAppendTeamEvent:
    def test_append_creates_file_and_writes_record(self, tmp_path: Path) -> None:
        session_root = tmp_path / "session-root"
        session_root.mkdir()

        append_team_event(
            leader_session_id="uuid-789",
            leader_session_root=str(session_root),
            from_agent="alice",
            to_agent="bob",
            message_type="message",
            content="hello bob",
            timestamp="2026-03-25T10:30:00",
        )

        events_file = session_root / "team_events.jsonl"
        assert events_file.exists()
        lines = events_file.read_text().strip().split("\n")
        assert len(lines) == 1
        record = json.loads(lines[0])
        assert record["schema_version"] == "1.0"
        assert record["session_id"] == "uuid-789"
        assert record["from_agent"] == "alice"
        assert record["to_agent"] == "bob"
        assert record["message_type"] == "message"
        assert record["content"] == "hello bob"
        assert record["timestamp"] == "2026-03-25T10:30:00"
        assert "message_id" in record  # UUID, 不为空

    def test_append_multiple_records(self, tmp_path: Path) -> None:
        session_root = tmp_path / "session-root"
        session_root.mkdir()

        for i in range(3):
            append_team_event(
                leader_session_id="uuid-789",
                leader_session_root=str(session_root),
                from_agent="alice",
                to_agent="bob",
                message_type="message",
                content=f"msg-{i}",
                timestamp=f"2026-03-25T10:0{i}:00",
            )

        lines = (session_root / "team_events.jsonl").read_text().strip().split("\n")
        assert len(lines) == 3
        assert json.loads(lines[2])["content"] == "msg-2"

    def test_append_broadcast_to_agent_star(self, tmp_path: Path) -> None:
        session_root = tmp_path / "session-root"
        session_root.mkdir()

        append_team_event(
            leader_session_id="uuid-789",
            leader_session_root=str(session_root),
            from_agent="alice",
            to_agent="*",
            message_type="broadcast",
            content="hello everyone",
            timestamp="2026-03-25T10:30:00",
        )

        record = json.loads(
            (session_root / "team_events.jsonl").read_text().strip()
        )
        assert record["to_agent"] == "*"

    def test_append_best_effort_no_exception_on_bad_path(self) -> None:
        """写入失败时不抛异常（best-effort）。"""
        append_team_event(
            leader_session_id="uuid-789",
            leader_session_root="/nonexistent/path/that/does/not/exist",
            from_agent="alice",
            to_agent="bob",
            message_type="message",
            content="hello",
            timestamp="2026-03-25T10:30:00",
        )
        # 没有异常即 PASS

    def test_append_skips_when_session_root_empty(self, tmp_path: Path) -> None:
        """leader_session_root 为空时静默跳过。"""
        append_team_event(
            leader_session_id="",
            leader_session_root="",
            from_agent="alice",
            to_agent="bob",
            message_type="message",
            content="hello",
            timestamp="2026-03-25T10:30:00",
        )
        # 没有异常，也没有文件创建


from comate_agent_sdk.system_tools.team.tools import SendMessage, SendMessageInput


class TestSendMessageTeamEvents:
    def _setup_team(self, tmp_path: Path) -> tuple[Path, Path]:
        """创建 team config 和 session root，返回 (teams_dir, session_root)。"""
        teams_dir = tmp_path / "teams"
        session_root = tmp_path / "sessions" / "leader-uuid"
        session_root.mkdir(parents=True)

        team_cfg = TeamConfig(team_name="test-team", base_dir=teams_dir)
        team_cfg.set_leader_session(
            session_id="leader-uuid",
            session_root=str(session_root),
        )
        team_cfg.register_member(name="alice", agent_type="leader")
        team_cfg.register_member(name="bob", agent_type="teammate")
        return teams_dir, session_root

    def test_direct_message_writes_team_event(self, tmp_path: Path) -> None:
        teams_dir, session_root = self._setup_team(tmp_path)

        async def _run() -> dict:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": str(teams_dir)}):
                with bind_system_tool_context(
                    project_root=tmp_path,
                    session_id="leader-uuid",
                    session_root=session_root,
                    team_name="test-team",
                    agent_name="alice",
                ):
                    return _parse(await SendMessage.execute(
                        params=SendMessageInput(
                            to="bob", content="hello bob", type="message",
                        )
                    ))

        result = asyncio.run(_run())
        assert result["ok"]

        events_file = session_root / "team_events.jsonl"
        assert events_file.exists()
        record = json.loads(events_file.read_text().strip())
        assert record["from_agent"] == "alice"
        assert record["to_agent"] == "bob"
        assert record["content"] == "hello bob"
        assert record["message_type"] == "message"

    def test_broadcast_writes_single_team_event_with_star(self, tmp_path: Path) -> None:
        teams_dir, session_root = self._setup_team(tmp_path)

        async def _run() -> dict:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": str(teams_dir)}):
                with bind_system_tool_context(
                    project_root=tmp_path,
                    session_id="leader-uuid",
                    session_root=session_root,
                    team_name="test-team",
                    agent_name="alice",
                ):
                    return _parse(await SendMessage.execute(
                        params=SendMessageInput(
                            content="hello all", type="broadcast",
                        )
                    ))

        result = asyncio.run(_run())
        assert result["ok"]

        events_file = session_root / "team_events.jsonl"
        lines = events_file.read_text().strip().split("\n")
        # broadcast 只写一条记录
        assert len(lines) == 1
        record = json.loads(lines[0])
        assert record["from_agent"] == "alice"
        assert record["to_agent"] == "*"
        assert record["message_type"] == "broadcast"
        assert record["content"] == "hello all"

    def test_no_team_event_when_leader_session_not_set(self, tmp_path: Path) -> None:
        """TeamConfig 没有 leader_session 时，不写 team_events.jsonl。"""
        teams_dir = tmp_path / "teams"
        session_root = tmp_path / "sessions" / "some-id"
        session_root.mkdir(parents=True)
        # 创建 team 但不设置 leader_session
        team_cfg = TeamConfig(team_name="test-team", base_dir=teams_dir)
        team_cfg.register_member(name="alice", agent_type="leader")
        team_cfg.register_member(name="bob", agent_type="teammate")

        async def _run() -> dict:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": str(teams_dir)}):
                with bind_system_tool_context(
                    project_root=tmp_path,
                    session_id="some-id",
                    session_root=session_root,
                    team_name="test-team",
                    agent_name="alice",
                ):
                    return _parse(await SendMessage.execute(
                        params=SendMessageInput(
                            to="bob", content="hello bob", type="message",
                        )
                    ))

        result = asyncio.run(_run())
        assert result["ok"]
        # inbox 消息已写入，但 team_events.jsonl 不应存在
        assert not (session_root / "team_events.jsonl").exists()
