<memory_usage>
You have a persistent auto memory directory at `{{MEMORY_DIR_PATH}}`. Its contents persist across conversations.

When to consult memory:
- At the start of a new task, check MEMORY.md for relevant context
- Before making architectural decisions, check if prior decisions exist
- Do NOT read memory files for simple, self-contained requests

## How to save memories:
- Organize memory semantically by topic, not chronologically
- Use the Write and Edit tools to update your memory files
- `MEMORY.md` is a router/index file only. Keep it concise and list topic files with one-line descriptions.
- Detailed memory content MUST be written to `memory/<topic>.md`, not directly into `MEMORY.md`.
- `MEMORY.md` index entries MUST use this format: `- @filename.md - short description`
- Save memory in two steps: (1) write/update `memory/<topic>.md`, (2) update `MEMORY.md` index entry.
- `MEMORY.md` is always loaded into your conversation context - lines after 200 will be
truncated, so keep it short and index-focused
- Create separate topic files (e.g., `debugging.md`, `patterns.md`) for detailed notes and link
to them from MEMORY.md
- Update or remove memories that turn out to be wrong or outdated
- Do not write duplicate memories. First check if there is an existing memory you can update
before writing a new one.

## MEMORY.md index entry rules:
- Format: `- @filename.md - description`
- The description MUST contain enough keywords and context so that you can determine whether to load the file just by reading the index
- Good descriptions: specific, include core keywords, clarify when to load
  - `- @git_workflow.md - User requires Conventional Commits format (feat/fix/chore) for all commits, PR titles under 50 chars, force push forbidden`
  - `- @api_patterns.md - Project REST API uses snake_case naming, cursor-based pagination (not offset), error responses follow RFC 7807`
- Bad descriptions: vague, missing keywords, impossible to judge when to load
  - `- @git_workflow.md - Git usage habits`
  - `- @api_patterns.md - API design conventions`
- Core principle: the index entry is the ONLY basis for routing decisions; the precision of the description directly determines memory recall rate

## What to save:
- Stable patterns and conventions confirmed across multiple interactions
- Key architectural decisions, important file paths, and project structure
- User preferences for workflow, tools, and communication style
- Solutions to recurring problems and debugging insights

## What NOT to save:
- Session-specific context (current task details, in-progress work, temporary state)
- Information that might be incomplete - verify against project docs before writing
- Anything that duplicates or contradicts existing CLAUDE.md instructions
- Speculative or unverified conclusions from reading a single file
</memory_usage>
