from __future__ import annotations

import asyncio
import os
import time
import warnings
from contextlib import AsyncExitStack
from types import SimpleNamespace
from types import MethodType

import pytest

from comate_agent_sdk.mcp import create_sdk_mcp_server, mcp_tool
from comate_agent_sdk.mcp.manager import McpManager, _CachedConnection
from comate_agent_sdk.mcp import manager as manager_module


def _build_calc_server():
    @mcp_tool(name="add", description="Add two numbers")
    async def add(a: float, b: float) -> str:
        return f"Sum: {a + b}"

    return create_sdk_mcp_server(name="calculator", tools=[add])


def test_mcp_manager_aclose_idempotent() -> None:
    async def _run() -> None:
        manager = McpManager({"calc": _build_calc_server()})

        await manager.start()
        assert any(t.name == "mcp__calc__add" for t in manager.tools)

        await manager.aclose()
        await manager.aclose()

        assert manager.tools == []
        assert manager.tool_infos == []

    asyncio.run(_run())


def test_mcp_manager_concurrent_start() -> None:
    async def _run() -> None:
        manager = McpManager({"calc": _build_calc_server()})

        await asyncio.gather(manager.start(), manager.start(), manager.start())
        assert any(t.name == "mcp__calc__add" for t in manager.tools)

        await manager.aclose()

    asyncio.run(_run())



def test_mcp_manager_parallel_start_loads_all_servers() -> None:
    async def _run() -> None:
        manager = McpManager(
            {
                "slow": {"type": "http", "url": "http://slow.test"},
                "fast": {"type": "http", "url": "http://fast.test"},
            }
        )  # type: ignore[arg-type]

        delays = {"slow": 0.12, "fast": 0.03}

        async def _fake_open(self: McpManager, alias: str, _cfg: dict[str, str]):
            await asyncio.sleep(delays[alias])
            self._conn_cache[alias] = _CachedConnection(
                alias=alias, config_hash="fake",
                session=alias,  # type: ignore[arg-type]
                exit_stack=AsyncExitStack(),
            )
            return alias

        async def _fake_list_all_tools(self: McpManager, session: str):
            return [
                SimpleNamespace(
                    name=f"{session}_tool",
                    description=f"{session} description",
                    inputSchema={"type": "object", "properties": {}},
                )
            ]

        manager._open_connection = MethodType(_fake_open, manager)  # type: ignore[method-assign]
        manager._list_all_tools = MethodType(_fake_list_all_tools, manager)  # type: ignore[method-assign]

        started = time.monotonic()
        await manager.start()
        elapsed = time.monotonic() - started

        assert elapsed < 0.18
        # Workers process results as they complete (progressive), so order
        # follows completion order: fast finishes before slow.
        assert {info.server_alias for info in manager.tool_infos} == {"slow", "fast"}
        assert {tool.name for tool in manager.tools} == {
            "mcp__slow__slow_tool",
            "mcp__fast__fast_tool",
        }

        await manager.aclose()

    asyncio.run(_run())


def test_mcp_manager_start_timeout_cleanup(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(manager_module, "_START_TIMEOUT_S", 0.05)
    monkeypatch.setattr(manager_module, "_START_SAFETY_BUFFER_S", 0.05)
    monkeypatch.setattr(manager_module, "_SHUTDOWN_TIMEOUT_S", 0.05)

    async def _never_init(self: McpManager) -> None:
        await asyncio.Event().wait()

    async def _run() -> None:
        manager = McpManager({"calc": _build_calc_server()})
        manager._run_lifecycle = MethodType(_never_init, manager)  # type: ignore[method-assign]

        with pytest.raises(asyncio.TimeoutError):
            await manager.start()

        assert manager._lifecycle_task is None
        assert manager.tools == []
        assert manager.tool_infos == []

    asyncio.run(_run())


def test_mcp_manager_start_propagates_init_error(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(manager_module, "_START_TIMEOUT_S", 0.1)
    monkeypatch.setattr(manager_module, "_SHUTDOWN_TIMEOUT_S", 0.1)

    async def _raise_during_init(self: McpManager) -> None:
        init_done = self._init_done
        err = RuntimeError("init boom")
        if init_done is not None and not init_done.done():
            init_done.set_exception(err)
        raise err

    async def _run() -> None:
        manager = McpManager({"calc": _build_calc_server()})
        manager._run_lifecycle = MethodType(_raise_during_init, manager)  # type: ignore[method-assign]

        with pytest.raises(RuntimeError, match="init boom"):
            await manager.start()

        assert manager._lifecycle_task is None
        assert manager.tools == []
        assert manager.tool_infos == []

    asyncio.run(_run())


def test_mcp_manager_partial_server_failures_do_not_block_healthy_server() -> None:
    async def _run() -> None:
        servers = {
            "bad-http": {"type": "http", "url": ""},
            "calc": _build_calc_server(),
        }
        manager = McpManager(servers)  # type: ignore[arg-type]

        await manager.start()
        tool_names = [t.name for t in manager.tools]
        assert "mcp__calc__add" in tool_names

        # 验证失败 server 被记录
        failed_aliases = [alias for alias, _ in manager.failed_servers]
        assert "bad-http" in failed_aliases

        await manager.aclose()

    asyncio.run(_run())


def test_mcp_manager_aclose_returns_when_cancelled_task_still_hangs(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(manager_module, "_SHUTDOWN_TIMEOUT_S", 0.05)
    monkeypatch.setattr(manager_module, "_SHUTDOWN_CANCEL_TIMEOUT_S", 0.05)

    async def _run() -> None:
        manager = McpManager({})
        stop_event = asyncio.Event()

        async def _stubborn_lifecycle() -> None:
            while True:
                if stop_event.is_set():
                    return
                try:
                    await stop_event.wait()
                    return
                except asyncio.CancelledError:
                    # Simulate底层 TaskGroup 取消后仍无法快速退出。
                    continue

        stubborn_task = asyncio.create_task(
            _stubborn_lifecycle(),
            name="test-mcp-stubborn-lifecycle",
        )
        manager._lifecycle_task = stubborn_task
        manager._shutdown_event = asyncio.Event()

        started = time.monotonic()
        await manager.aclose()
        elapsed = time.monotonic() - started

        assert elapsed < 0.3
        assert manager._lifecycle_task is None
        assert manager.tools == []
        assert manager.tool_infos == []

        stop_event.set()
        await asyncio.wait_for(stubborn_task, timeout=0.2)

    asyncio.run(_run())


def test_mcp_manager_stdio_connect_suppresses_child_stderr(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured: dict[str, object] = {}

    from contextlib import asynccontextmanager as _acm

    @_acm
    async def _fake_stdio_client(_params, errlog):  # type: ignore[no-untyped-def]
        captured["errlog"] = errlog
        yield object(), object()

    class _FakeSession:
        def __init__(self, *_args, **_kwargs) -> None:
            self.initialized = False

        async def __aenter__(self) -> "_FakeSession":
            return self

        async def __aexit__(self, exc_type, exc, tb) -> None:
            del exc_type, exc, tb

        async def initialize(self) -> None:
            self.initialized = True

    async def _run() -> None:
        manager = McpManager({"ctx7": {"type": "stdio", "command": "dummy"}})  # type: ignore[arg-type]
        monkeypatch.setattr(manager_module, "stdio_client", _fake_stdio_client)
        monkeypatch.setattr(manager_module, "ClientSession", _FakeSession)

        session = await manager._open_connection(
            "ctx7",
            {"type": "stdio", "command": "dummy"},  # type: ignore[arg-type]
        )
        assert isinstance(session, _FakeSession)
        assert session.initialized is True

        await manager._close_connection("ctx7")

    asyncio.run(_run())

    errlog = captured.get("errlog")
    assert errlog is not None
    assert getattr(errlog, "name", None) == os.devnull


def test_mcp_manager_http_connect_with_headers_does_not_require_shared_exit_stack(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured: dict[str, object] = {}

    class _FakeAsyncClient:
        def __init__(self, *, headers=None, timeout=None) -> None:
            captured["headers"] = headers
            captured["timeout"] = timeout

        async def __aenter__(self) -> "_FakeAsyncClient":
            captured["entered"] = True
            return self

        async def __aexit__(self, exc_type, exc, tb) -> None:
            del exc_type, exc, tb
            captured["exited"] = True

    from contextlib import asynccontextmanager as _acm

    @_acm
    async def _fake_streamable_http_client(url: str, http_client=None):  # type: ignore[no-untyped-def]
        captured["url"] = url
        captured["http_client"] = http_client
        yield object(), object(), lambda: "session-id"

    class _FakeSession:
        def __init__(self, *_args, **_kwargs) -> None:
            self.initialized = False

        async def __aenter__(self) -> "_FakeSession":
            return self

        async def __aexit__(self, exc_type, exc, tb) -> None:
            del exc_type, exc, tb

        async def initialize(self) -> None:
            self.initialized = True

    async def _run() -> None:
        manager = McpManager(
            {
                "ctx7": {
                    "type": "http",
                    "url": "https://example.test/mcp",
                    "headers": {"Authorization": "Bearer token"},
                }
            }
        )  # type: ignore[arg-type]
        monkeypatch.setattr(manager_module.httpx, "AsyncClient", _FakeAsyncClient)
        monkeypatch.setattr(
            manager_module,
            "streamable_http_client",
            _fake_streamable_http_client,
        )
        monkeypatch.setattr(manager_module, "ClientSession", _FakeSession)

        session = await manager._open_connection(
            "ctx7",
            {
                "type": "http",
                "url": "https://example.test/mcp",
                "headers": {"Authorization": "Bearer token"},
            },  # type: ignore[arg-type]
        )
        assert session.initialized is True

        await manager._close_connection("ctx7")

        assert captured["url"] == "https://example.test/mcp"
        assert captured["headers"] == {"Authorization": "Bearer token"}
        assert captured["entered"] is True
        assert captured["exited"] is True

    asyncio.run(_run())


def test_mcp_manager_list_tools_timeout(monkeypatch: pytest.MonkeyPatch) -> None:
    """_list_all_tools hang should result in failed_servers, not infinite block."""
    monkeypatch.setattr(manager_module, "_START_TIMEOUT_S", 0.5)

    async def _run() -> None:
        manager = McpManager(
            {"hang": {"type": "http", "url": "http://hang.test"}},
            connect_timeout_s=0.1,
        )  # type: ignore[arg-type]

        async def _fake_open(self, alias, cfg):
            self._conn_cache[alias] = _CachedConnection(
                alias=alias, config_hash="fake",
                session=object(),  # type: ignore[arg-type]
                exit_stack=AsyncExitStack(),
            )
            return object()

        async def _hanging_list_all_tools(self, session):
            await asyncio.Event().wait()  # hang forever
            return []  # unreachable

        manager._open_connection = MethodType(_fake_open, manager)  # type: ignore[method-assign]
        manager._list_all_tools = MethodType(_hanging_list_all_tools, manager)  # type: ignore[method-assign]

        await manager.start()

        assert manager.tools == []
        assert len(manager.failed_servers) == 1
        alias, reason = manager.failed_servers[0]
        assert alias == "hang"
        assert "list_tools timed out" in reason

        await manager.aclose()

    asyncio.run(_run())


def test_friendly_error_message_unwraps_exception_group() -> None:
    """ExceptionGroup should be unwrapped to show the root cause, not the raw repr."""
    manager = McpManager({})
    cfg: dict[str, str] = {"type": "http", "url": "http://example.test"}

    # Single sub-exception
    inner = ConnectionRefusedError("Connection refused")
    eg = ExceptionGroup("unhandled errors in a TaskGroup", [inner])
    result = manager._friendly_error_message("ctx7", cfg, eg)  # type: ignore[arg-type]
    assert "cannot connect to server" in result
    assert "ExceptionGroup" not in result

    # Nested ExceptionGroup
    inner_timeout = TimeoutError("timed out")
    nested_eg = ExceptionGroup("inner", [inner_timeout])
    outer_eg = ExceptionGroup("outer", [nested_eg])
    result2 = manager._friendly_error_message("ctx7", cfg, outer_eg)  # type: ignore[arg-type]
    assert "timed out" in result2
    assert "ExceptionGroup" not in result2


def test_friendly_error_message_session_terminated_shows_url() -> None:
    """McpError 'Session terminated' (HTTP 404) should hint at wrong URL path."""
    manager = McpManager({})
    cfg: dict[str, str] = {"type": "http", "url": "https://mcp.example.com/"}

    # Simulate what upstream MCP SDK raises on HTTP 404 during initialize
    from mcp.shared.exceptions import McpError
    from mcp.types import ErrorData

    exc = McpError(ErrorData(code=32600, message="Session terminated"))
    result = manager._friendly_error_message("ctx7", cfg, exc)  # type: ignore[arg-type]
    assert "404" in result
    assert "URL" in result or "url" in result.lower()
    assert "https://mcp.example.com/" in result
    assert "McpError" not in result


def test_friendly_error_message_session_terminated_unwraps_from_exception_group() -> None:
    """Session terminated wrapped in ExceptionGroup should also produce friendly hint."""
    manager = McpManager({})
    cfg: dict[str, str] = {"type": "http", "url": "https://mcp.example.com/wrong"}

    from mcp.shared.exceptions import McpError
    from mcp.types import ErrorData

    inner = McpError(ErrorData(code=32600, message="Session terminated"))
    eg = ExceptionGroup("unhandled errors in a TaskGroup", [inner])
    result = manager._friendly_error_message("ctx7", cfg, eg)  # type: ignore[arg-type]
    assert "404" in result
    assert "https://mcp.example.com/wrong" in result


def test_mcp_manager_partial_timeout_returns_successful_tools(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """One server hangs past deadline; healthy server's tools must still be available."""
    monkeypatch.setattr(manager_module, "_START_TIMEOUT_S", 0.3)

    async def _run() -> None:
        manager = McpManager(
            {
                "good": {"type": "http", "url": "http://good.test"},
                "slow": {"type": "http", "url": "http://slow.test"},
            },
            connect_timeout_s=5.0,
        )  # type: ignore[arg-type]

        async def _fake_open(self, alias, cfg):
            if alias == "slow":
                await asyncio.sleep(10)  # hang way past deadline
            self._conn_cache[alias] = _CachedConnection(
                alias=alias, config_hash="fake",
                session=alias,  # type: ignore[arg-type]
                exit_stack=AsyncExitStack(),
            )
            return alias

        async def _fake_list_all_tools(self, session):
            return [
                SimpleNamespace(
                    name=f"{session}_tool",
                    description=f"{session} desc",
                    inputSchema={"type": "object", "properties": {}},
                )
            ]

        manager._open_connection = MethodType(_fake_open, manager)  # type: ignore[method-assign]
        manager._list_all_tools = MethodType(_fake_list_all_tools, manager)  # type: ignore[method-assign]

        await manager.start()

        # Good server's tools should be available immediately
        tool_names = [t.name for t in manager.tools]
        assert "mcp__good__good_tool" in tool_names

        # Slow server is still connecting in background (not failed yet)
        # It will fail when cancelled during aclose()
        await manager.aclose()

    asyncio.run(_run())


def test_mcp_manager_all_servers_timeout_returns_empty_tools(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """All servers hang past deadline; start() must return normally with empty tools."""
    monkeypatch.setattr(manager_module, "_START_TIMEOUT_S", 0.2)

    async def _run() -> None:
        manager = McpManager(
            {
                "a": {"type": "http", "url": "http://a.test"},
                "b": {"type": "http", "url": "http://b.test"},
            },
            connect_timeout_s=5.0,
        )  # type: ignore[arg-type]

        async def _hang_open(self, alias, cfg):
            await asyncio.sleep(10)
            self._conn_cache[alias] = _CachedConnection(
                alias=alias, config_hash="fake",
                session=alias,  # type: ignore[arg-type]
                exit_stack=AsyncExitStack(),
            )
            return alias

        async def _fake_list(self, session):
            return []

        manager._open_connection = MethodType(_hang_open, manager)  # type: ignore[method-assign]
        manager._list_all_tools = MethodType(_fake_list, manager)  # type: ignore[method-assign]

        await manager.start()

        # After start(), no tools available yet (all servers still connecting)
        assert manager.tools == []
        # Workers are still running in background, not yet failed
        # They will be cancelled during aclose()

        await manager.aclose()

    asyncio.run(_run())


def test_mcp_manager_aclose_no_coroutine_warnings(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """aclose() must not produce 'coroutine ignored GeneratorExit' warnings."""
    monkeypatch.setattr(manager_module, "_START_TIMEOUT_S", 0.5)
    monkeypatch.setattr(manager_module, "_SHUTDOWN_TIMEOUT_S", 0.5)
    monkeypatch.setattr(manager_module, "_SHUTDOWN_CANCEL_TIMEOUT_S", 0.3)

    async def _run() -> None:
        manager = McpManager({"calc": _build_calc_server()})
        await manager.start()
        assert len(manager.tools) > 0

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            await manager.aclose()

        coroutine_warnings = [
            w for w in caught
            if "coroutine" in str(w.message).lower()
            or "GeneratorExit" in str(w.message)
        ]
        assert coroutine_warnings == [], (
            f"Unexpected coroutine warnings: {[str(w.message) for w in coroutine_warnings]}"
        )

    asyncio.run(_run())


def test_open_close_connection_lifecycle(monkeypatch: pytest.MonkeyPatch) -> None:
    """_open_connection creates session; _close_connection cleans up."""
    connect_count = 0
    close_count = 0

    from contextlib import asynccontextmanager as _acm

    @_acm
    async def _fake_stdio_client(_params, errlog):
        nonlocal connect_count
        connect_count += 1
        yield object(), object()

    class _FakeSession:
        def __init__(self, *_args, **_kwargs):
            self.initialized = False

        async def __aenter__(self):
            return self

        async def __aexit__(self, *_):
            nonlocal close_count
            close_count += 1

        async def initialize(self):
            self.initialized = True

    async def _run() -> None:
        nonlocal connect_count, close_count
        manager = McpManager({"cmd": {"type": "stdio", "command": "dummy"}})  # type: ignore[arg-type]
        monkeypatch.setattr(manager_module, "stdio_client", _fake_stdio_client)
        monkeypatch.setattr(manager_module, "ClientSession", _FakeSession)

        session = await manager._open_connection("cmd", {"type": "stdio", "command": "dummy"})  # type: ignore[arg-type]
        assert session.initialized is True
        assert "cmd" in manager._conn_cache
        assert connect_count == 1

        await manager._close_connection("cmd")
        assert "cmd" not in manager._conn_cache
        assert close_count == 1

        # idempotent close
        await manager._close_connection("cmd")
        assert close_count == 1

    asyncio.run(_run())


def test_manager_lifecycle_uses_conn_cache() -> None:
    """After start(), sessions are stored in _conn_cache, not _sessions."""
    async def _run() -> None:
        manager = McpManager({"calc": _build_calc_server()})
        await manager.start()

        assert "calc" in manager._conn_cache
        assert manager._conn_cache["calc"].session is not None
        assert any(t.name == "mcp__calc__add" for t in manager.tools)

        result = await manager.call_tool("mcp__calc__add", {"a": 1, "b": 2})
        assert "3" in str(result)

        await manager.aclose()
        assert len(manager._conn_cache) == 0

    asyncio.run(_run())


def test_connection_cache_hit_skips_reconnect() -> None:
    """Second start() with same config reuses cached connection."""
    connect_count = 0

    async def _run() -> None:
        nonlocal connect_count
        manager = McpManager({"calc": _build_calc_server()})

        original_open = McpManager._open_connection

        async def _counting_open(self, alias, cfg):
            nonlocal connect_count
            connect_count += 1
            return await original_open(self, alias, cfg)

        manager._open_connection = MethodType(_counting_open, manager)

        await manager.start()
        assert connect_count == 1
        assert len(manager.tools) > 0

        # Second start — same config, should reuse
        await manager.start()
        assert connect_count == 1  # no new connection

        await manager.aclose()

    asyncio.run(_run())


def test_connection_cache_miss_on_config_change() -> None:
    """Changing server config invalidates cache, triggers reconnect."""
    async def _run() -> None:
        server1 = _build_calc_server()
        manager = McpManager({"calc": server1})

        await manager.start()
        assert "calc" in manager._conn_cache
        old_hash = manager._conn_cache["calc"].config_hash

        # Change config — different sdk instance → different id() → different hash
        server2 = _build_calc_server()
        manager._servers["calc"] = server2
        new_hash = McpManager._compute_config_hash(server2)
        assert old_hash != new_hash

        await manager.start()
        assert manager._conn_cache["calc"].config_hash == new_hash

        await manager.aclose()

    asyncio.run(_run())


def test_concurrency_limit_local_servers(monkeypatch: pytest.MonkeyPatch) -> None:
    """Local servers (stdio/sdk) respect concurrency limit."""
    monkeypatch.setattr(manager_module, "_LOCAL_CONCURRENCY", 2)
    monkeypatch.setattr(manager_module, "_START_TIMEOUT_S", 2.0)

    max_concurrent = 0
    current_concurrent = 0
    lock = asyncio.Lock()

    async def _run() -> None:
        nonlocal max_concurrent, current_concurrent

        original_open = McpManager._open_connection

        async def _tracking_open(self, alias, cfg):
            nonlocal max_concurrent, current_concurrent
            async with lock:
                current_concurrent += 1
                max_concurrent = max(max_concurrent, current_concurrent)
            await asyncio.sleep(0.05)
            try:
                return await original_open(self, alias, cfg)
            finally:
                async with lock:
                    current_concurrent -= 1

        servers = {f"s{i}": _build_calc_server() for i in range(5)}
        manager = McpManager(servers)
        manager._open_connection = MethodType(_tracking_open, manager)  # type: ignore[method-assign]

        await manager.start()
        assert max_concurrent <= 2
        await manager.aclose()

    asyncio.run(_run())


def test_retry_transient_failure_succeeds(monkeypatch: pytest.MonkeyPatch) -> None:
    """Transient connection failure retries and eventually succeeds."""
    monkeypatch.setattr(manager_module, "_RETRY_MAX", 3)
    monkeypatch.setattr(manager_module, "_RETRY_INITIAL_DELAY_S", 0.01)
    monkeypatch.setattr(manager_module, "_START_TIMEOUT_S", 5.0)

    attempt = 0

    async def _run() -> None:
        nonlocal attempt
        manager = McpManager({"calc": _build_calc_server()})

        original_open = McpManager._open_connection

        async def _flaky_open(self, alias, cfg):
            nonlocal attempt
            attempt += 1
            if attempt <= 2:
                raise ConnectionRefusedError("Connection refused")
            return await original_open(self, alias, cfg)

        manager._open_connection = MethodType(_flaky_open, manager)

        await manager.start()
        assert attempt == 3
        assert any(t.name == "mcp__calc__add" for t in manager.tools)
        assert len(manager.failed_servers) == 0

        await manager.aclose()

    asyncio.run(_run())


def test_no_retry_on_permanent_failure(monkeypatch: pytest.MonkeyPatch) -> None:
    """Permanent errors (ValueError, FileNotFoundError) are not retried."""
    monkeypatch.setattr(manager_module, "_RETRY_MAX", 3)
    monkeypatch.setattr(manager_module, "_RETRY_INITIAL_DELAY_S", 0.01)

    attempt = 0

    async def _run() -> None:
        nonlocal attempt
        manager = McpManager({"bad": {"type": "stdio", "command": ""}})

        original_open = McpManager._open_connection

        async def _perm_fail_open(self, alias, cfg):
            nonlocal attempt
            attempt += 1
            return await original_open(self, alias, cfg)

        manager._open_connection = MethodType(_perm_fail_open, manager)

        await manager.start()
        assert attempt == 1  # no retry — ValueError is not retryable
        assert len(manager.failed_servers) == 1

        await manager.aclose()

    asyncio.run(_run())


def test_tools_cache_ttl_expiry_triggers_refresh(monkeypatch: pytest.MonkeyPatch) -> None:
    """After TTL expires, tools are re-fetched using cached connection."""
    monkeypatch.setattr(manager_module, "_TOOLS_CACHE_TTL_S", 0.1)
    list_tools_count = 0

    async def _run() -> None:
        nonlocal list_tools_count
        manager = McpManager({"calc": _build_calc_server()})

        original_list = McpManager._list_all_tools

        async def _counting_list(self, session):
            nonlocal list_tools_count
            list_tools_count += 1
            return await original_list(self, session)

        manager._list_all_tools = MethodType(_counting_list, manager)

        await manager.start()
        assert list_tools_count == 1

        # Within TTL — no refresh
        refreshed = await manager.refresh_tools_if_stale()
        assert refreshed is False
        assert list_tools_count == 1

        # Wait for TTL to expire
        await asyncio.sleep(0.15)

        # After TTL — refresh
        refreshed = await manager.refresh_tools_if_stale()
        assert refreshed is True
        assert list_tools_count == 2

        await manager.aclose()

    asyncio.run(_run())


def test_call_tool_auto_reconnects_on_session_expired() -> None:
    """call_tool detects session expiry and reconnects once."""
    async def _run() -> None:
        manager = McpManager({"calc": _build_calc_server()})
        await manager.start()

        # Make the first call_tool fail with ConnectionResetError
        cached = manager._conn_cache["calc"]
        original_call = cached.session.call_tool
        call_count = 0

        async def _failing_then_ok(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise ConnectionResetError("Connection reset")
            return await original_call(*args, **kwargs)

        cached.session.call_tool = _failing_then_ok

        result = await manager.call_tool("mcp__calc__add", {"a": 1, "b": 2})
        assert "3" in str(result)

        await manager.aclose()

    asyncio.run(_run())


def test_retry_server_recovers_failed_server(monkeypatch: pytest.MonkeyPatch) -> None:
    """retry_server reconnects a previously failed server."""
    monkeypatch.setattr(manager_module, "_RETRY_MAX", 0)
    monkeypatch.setattr(manager_module, "_RETRY_INITIAL_DELAY_S", 0.01)

    attempt = 0

    async def _run() -> None:
        nonlocal attempt
        manager = McpManager(
            {"flaky": {"type": "http", "url": "http://flaky.test"}},
            connect_timeout_s=0.5,
        )  # type: ignore[arg-type]

        async def _fail_then_succeed_open(self, alias, cfg):
            nonlocal attempt
            attempt += 1
            if attempt == 1:
                raise ConnectionRefusedError("refused")
            # Fake a successful connection
            self._conn_cache[alias] = _CachedConnection(
                alias=alias, config_hash="fake",
                session=alias,  # type: ignore[arg-type]
                exit_stack=AsyncExitStack(),
            )
            return alias

        async def _fake_list(self, session):
            return [SimpleNamespace(
                name="tool1", description="desc",
                inputSchema={"type": "object", "properties": {}},
            )]

        manager._open_connection = MethodType(_fail_then_succeed_open, manager)
        manager._list_all_tools = MethodType(_fake_list, manager)

        await manager.start()
        assert len(manager.failed_servers) == 1

        ok = await manager.retry_server("flaky")
        assert ok is True
        assert len(manager.failed_servers) == 0
        assert any(t.name == "mcp__flaky__tool1" for t in manager.tools)

        await manager.aclose()

    asyncio.run(_run())


def test_start_progressive_on_tools_ready() -> None:
    """on_tools_ready is called as each server becomes ready."""
    callbacks_received: list[list[str]] = []

    async def _run() -> None:
        manager = McpManager({
            "a": _build_calc_server(),
            "b": _build_calc_server(),
        })

        def _on_ready(tools: list) -> None:
            callbacks_received.append([t.name for t in tools])

        await manager.start(on_tools_ready=_on_ready)
        assert len(callbacks_received) >= 1
        all_tool_names = [name for batch in callbacks_received for name in batch]
        assert "mcp__a__add" in all_tool_names
        assert "mcp__b__add" in all_tool_names

        await manager.aclose()

    asyncio.run(_run())


def test_start_and_wait_blocks_until_all_done(monkeypatch: pytest.MonkeyPatch) -> None:
    """start_and_wait returns only after all servers are done."""
    monkeypatch.setattr(manager_module, "_START_TIMEOUT_S", 0.1)

    async def _run() -> None:
        manager = McpManager(
            {
                "fast": {"type": "http", "url": "http://fast.test"},
                "slow": {"type": "http", "url": "http://slow.test"},
            },
            connect_timeout_s=5.0,
        )  # type: ignore[arg-type]

        async def _delayed_open(self, alias, cfg):
            if alias == "slow":
                await asyncio.sleep(0.3)  # longer than _START_TIMEOUT_S
            self._conn_cache[alias] = _CachedConnection(
                alias=alias, config_hash="fake",
                session=alias,  # type: ignore[arg-type]
                exit_stack=AsyncExitStack(),
            )
            return alias

        async def _fake_list(self, session):
            return [SimpleNamespace(
                name="tool", description="desc",
                inputSchema={"type": "object", "properties": {}},
            )]

        manager._open_connection = MethodType(_delayed_open, manager)  # type: ignore[method-assign]
        manager._list_all_tools = MethodType(_fake_list, manager)  # type: ignore[method-assign]

        await manager.start_and_wait()

        # Both servers should be loaded (including slow one that exceeded window)
        tool_names = [t.name for t in manager.tools]
        assert "mcp__slow__tool" in tool_names
        assert "mcp__fast__tool" in tool_names

        await manager.aclose()

    asyncio.run(_run())


def test_tools_hash_stable_when_tools_unchanged() -> None:
    """Same tools produce same hash."""
    async def _run() -> None:
        manager = McpManager({"calc": _build_calc_server()})
        await manager.start()

        hash1 = manager.tools_hash
        assert len(hash1) == 16
        assert hash1 == manager.tools_hash  # idempotent

        await manager.aclose()

    asyncio.run(_run())


def test_tools_hash_changes_when_tools_change() -> None:
    """Adding a server changes the tools_hash."""
    async def _run() -> None:
        @mcp_tool(name="subtract", description="Subtract two numbers")
        async def sub(a: float, b: float) -> str:
            return f"Diff: {a - b}"

        manager1 = McpManager({"calc": _build_calc_server()})
        await manager1.start()
        hash1 = manager1.tools_hash

        manager2 = McpManager({
            "calc": _build_calc_server(),
            "math": create_sdk_mcp_server(name="math", tools=[sub]),
        })
        await manager2.start()
        hash2 = manager2.tools_hash

        assert hash1 != hash2

        await manager1.aclose()
        await manager2.aclose()

    asyncio.run(_run())


def test_sdk_server_config_hash_uses_id() -> None:
    """sdk type uses id(instance) for config_hash; different instances = cache miss."""
    server1 = _build_calc_server()
    server2 = _build_calc_server()
    hash1 = McpManager._compute_config_hash(server1)
    hash2 = McpManager._compute_config_hash(server2)
    assert hash1 != hash2  # different instances → different id → different hash
    assert hash1 == McpManager._compute_config_hash(server1)  # same instance → same hash


def test_call_tool_for_not_yet_ready_server() -> None:
    """Calling a tool for a server not yet connected returns error."""
    async def _run() -> None:
        manager = McpManager({"slow": {"type": "http", "url": "http://slow.test"}})  # type: ignore[arg-type]
        # Don't start — no connections
        result = await manager.call_tool("mcp__slow__some_tool", {})
        assert "Unknown MCP tool" in result

        await manager.aclose()

    asyncio.run(_run())


def test_concurrency_limit_remote_servers(monkeypatch: pytest.MonkeyPatch) -> None:
    """Remote servers (http/sse) respect their own concurrency limit."""
    monkeypatch.setattr(manager_module, "_REMOTE_CONCURRENCY", 2)
    monkeypatch.setattr(manager_module, "_START_TIMEOUT_S", 2.0)
    monkeypatch.setattr(manager_module, "_RETRY_MAX", 0)

    max_concurrent = 0
    current_concurrent = 0

    async def _run() -> None:
        nonlocal max_concurrent, current_concurrent
        lock = asyncio.Lock()
        original_open = McpManager._open_connection

        async def _tracking_open(self, alias, cfg):
            nonlocal max_concurrent, current_concurrent
            async with lock:
                current_concurrent += 1
                max_concurrent = max(max_concurrent, current_concurrent)
            await asyncio.sleep(0.05)
            try:
                return await original_open(self, alias, cfg)
            finally:
                async with lock:
                    current_concurrent -= 1

        servers = {
            f"r{i}": {"type": "http", "url": f"http://r{i}.test"} for i in range(5)
        }
        manager = McpManager(servers)  # type: ignore[arg-type]
        manager._open_connection = MethodType(_tracking_open, manager)  # type: ignore[method-assign]

        await manager.start()
        assert max_concurrent <= 2
        await manager.aclose()

    asyncio.run(_run())
