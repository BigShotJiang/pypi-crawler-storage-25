"""Settings 配置文件加载

从 ~/.agent/settings.json（user 级）、
{project_root}/.agent/settings.json（project 级）、
{project_root}/.agent/settings.local.json（local 级）
加载 LLM 配置，支持分层覆盖。

优先级（从高到低）：
    代码参数 llm_levels=
    > project/.agent/settings.local.json
    > project/.agent/settings.json
    > ~/.agent/settings.json
    > 环境变量
    > 默认值
"""

from __future__ import annotations

import json
import logging
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal, Mapping, cast

from comate_agent_sdk.utils.paths import (
    PathInput,
    PathInputError,
    is_path_input,
    normalize_path_input,
)

logger = logging.getLogger("comate_agent_sdk.agent.settings")

SettingSource = Literal["user", "project", "local"]
DEFAULT_SETTING_SOURCES: tuple[SettingSource, ...] = ("user", "project", "local")

# 用户级配置路径
USER_SETTINGS_PATH: Path = Path.home() / ".agent" / "settings.json"
USER_AGENTS_MD_PATH: Path = Path.home() / ".agent" / "AGENTS.md"
LOCAL_SETTINGS_FILENAME = "settings.local.json"
ModelPreferenceLevel = Literal["LOW", "MID", "HIGH"]

_MODEL_LEVEL_TO_STORAGE: dict[ModelPreferenceLevel, str] = {
    "LOW": "low",
    "MID": "mid",
    "HIGH": "high",
}
_STORAGE_TO_MODEL_LEVEL: dict[str, ModelPreferenceLevel] = {
    "low": "LOW",
    "mid": "MID",
    "high": "HIGH",
}


@dataclass
class SettingsConfig:
    """从 settings.json 加载的配置

    Attributes:
        llm_levels: LLM 三档配置，格式为 {"LOW": "provider:model", ...}
        llm_levels_base_url: 各档 base_url 覆盖，值为 None 表示不覆盖
        llm_levels_api_key: 各档 api_key 覆盖，值为 None 表示不覆盖（优先级低于 env var）
    """

    llm_levels: dict[str, str] | None = None
    llm_levels_base_url: dict[str, str | None] | None = None
    llm_levels_api_key: dict[str, str | None] | None = None
    permissions_allow: list[str] | None = None
    permissions_deny: list[str] | None = None


def _normalize_settings_path(path: PathInput) -> Path:
    return normalize_path_input(path, field_name="path")


def _normalize_project_root(project_root: PathInput | None) -> Path:
    return normalize_path_input(
        project_root if project_root is not None else Path.cwd(),
        field_name="project_root",
    )


def _expand_project_root(project_root: PathInput | None) -> Path:
    value = project_root if project_root is not None else Path.cwd()
    if not is_path_input(value):
        raise PathInputError(
            f"invalid project_root type: expected str | os.PathLike, got {type(value).__name__}"
        )
    try:
        return Path(value).expanduser()
    except Exception as exc:
        raise PathInputError(f"invalid project_root: {value!r}") from exc


def read_settings_json_object(path: PathInput) -> dict[str, Any]:
    """读取 settings JSON 对象；失败时返回空 dict。"""
    resolved = _normalize_settings_path(path)
    if not resolved.exists():
        return {}
    if not resolved.is_file():
        logger.warning(f"settings 路径不是文件，返回空对象: {resolved}")
        return {}

    try:
        data = json.loads(resolved.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as e:
        logger.warning(f"读取/解析 settings 失败，返回空对象: {resolved}: {e}")
        return {}

    if not isinstance(data, dict):
        logger.warning(f"settings 根节点不是对象，返回空对象: {resolved}")
        return {}

    return dict(data)


def write_settings_json_atomic(*, path: PathInput, data: Mapping[str, Any]) -> None:
    """原子写入 settings JSON。"""
    target = _normalize_settings_path(path)
    target.parent.mkdir(parents=True, exist_ok=True)

    payload = json.dumps(dict(data), ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    fd, tmp_name = tempfile.mkstemp(prefix=".tmp_", dir=str(target.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(payload)
        os.replace(tmp_name, target)
    finally:
        tmp_path = Path(tmp_name)
        if tmp_path.exists():
            tmp_path.unlink(missing_ok=True)


def _normalize_model_preference(raw: object) -> ModelPreferenceLevel | None:
    if not isinstance(raw, str):
        return None
    normalized = raw.strip().lower()
    if not normalized:
        return None
    return _STORAGE_TO_MODEL_LEVEL.get(normalized)


def load_user_model_preference(*, path: PathInput | None = None) -> ModelPreferenceLevel | None:
    """读取 user settings 中的 model 偏好（low/mid/high）。"""
    target = path or USER_SETTINGS_PATH
    data = read_settings_json_object(target)
    if not data:
        return None

    raw_model = data.get("model")
    model_level = _normalize_model_preference(raw_model)
    if model_level is None:
        if raw_model is not None:
            logger.warning(f"settings.model 非法，忽略该值: {raw_model!r}")
        return None

    logger.debug(f"加载 user model 偏好: {model_level}")
    return model_level


def persist_user_model_preference(
    level: ModelPreferenceLevel,
    *,
    path: PathInput | None = None,
) -> None:
    """持久化 user settings 的 model 偏好。"""
    normalized = str(level).strip().upper()
    if normalized not in _MODEL_LEVEL_TO_STORAGE:
        raise ValueError(f"非法 level：{level}")

    target = path or USER_SETTINGS_PATH
    data = read_settings_json_object(target)
    resolved_level = cast(ModelPreferenceLevel, normalized)
    data["model"] = _MODEL_LEVEL_TO_STORAGE[resolved_level]
    write_settings_json_atomic(path=target, data=data)
    logger.info(f"已持久化 user model 偏好: {normalized}")


def load_settings_file(path: PathInput) -> SettingsConfig | None:
    """从 settings.json 文件加载配置

    文件不存在或解析失败时返回 None，不抛异常。

    Args:
        path: settings.json 的绝对路径

    Returns:
        解析后的 SettingsConfig，或 None
    """
    resolved = _normalize_settings_path(path)
    if not resolved.exists():
        logger.debug(f"settings.json 不存在，跳过: {resolved}")
        return None

    if not resolved.is_file():
        logger.warning(f"settings.json 路径不是文件: {resolved}")
        return None

    try:
        raw = resolved.read_text(encoding="utf-8")
        data = json.loads(raw)
    except (json.JSONDecodeError, OSError) as e:
        logger.warning(f"读取/解析 settings.json 失败 {resolved}: {e}")
        return None

    if not isinstance(data, dict):
        logger.warning(f"settings.json 内容不是 JSON 对象: {resolved}")
        return None

    llm_levels: dict[str, str] | None = None
    llm_levels_base_url: dict[str, str | None] | None = None
    llm_levels_api_key: dict[str, str | None] | None = None
    permissions_allow: list[str] | None = None
    permissions_deny: list[str] | None = None

    # 解析 llm_levels
    raw_levels = data.get("llm_levels")
    if raw_levels is not None:
        if not isinstance(raw_levels, dict):
            logger.warning(f"settings.json llm_levels 不是对象，跳过: {resolved}")
        else:
            llm_levels = {}
            for k, v in raw_levels.items():
                if not isinstance(v, str):
                    logger.warning(f"settings.json llm_levels.{k} 不是字符串，跳过该项")
                    continue
                llm_levels[k] = v

    # 解析 llm_levels_base_url
    raw_base_urls = data.get("llm_levels_base_url")
    if raw_base_urls is not None:
        if not isinstance(raw_base_urls, dict):
            logger.warning(f"settings.json llm_levels_base_url 不是对象，跳过: {resolved}")
        else:
            llm_levels_base_url = {}
            for k, v in raw_base_urls.items():
                if v is not None and not isinstance(v, str):
                    logger.warning(f"settings.json llm_levels_base_url.{k} 不是字符串或 null，跳过该项")
                    continue
                llm_levels_base_url[k] = v

    # 解析 llm_levels_api_key
    raw_api_keys = data.get("llm_levels_api_key")
    if raw_api_keys is not None:
        if not isinstance(raw_api_keys, dict):
            logger.warning(f"settings.json llm_levels_api_key 不是对象，跳过: {resolved}")
        else:
            llm_levels_api_key = {}
            for k, v in raw_api_keys.items():
                if v is not None and not isinstance(v, str):
                    logger.warning(f"settings.json llm_levels_api_key.{k} 不是字符串或 null，跳过该项")
                    continue
                llm_levels_api_key[k] = v

    # 解析 permissions DSL
    raw_permissions = data.get("permissions")
    if raw_permissions is not None:
        if not isinstance(raw_permissions, dict):
            logger.warning(f"settings.json permissions 不是对象，跳过: {resolved}")
        else:
            raw_allow = raw_permissions.get("allow")
            raw_deny = raw_permissions.get("deny")

            if raw_allow is not None:
                if not isinstance(raw_allow, list):
                    logger.warning(f"settings.json permissions.allow 不是数组，跳过: {resolved}")
                else:
                    permissions_allow = [str(v) for v in raw_allow if isinstance(v, str) and str(v).strip()]

            if raw_deny is not None:
                if not isinstance(raw_deny, list):
                    logger.warning(f"settings.json permissions.deny 不是数组，跳过: {resolved}")
                else:
                    permissions_deny = [str(v) for v in raw_deny if isinstance(v, str) and str(v).strip()]

    if (
        llm_levels is None
        and llm_levels_base_url is None
        and llm_levels_api_key is None
        and permissions_allow is None
        and permissions_deny is None
    ):
        return None

    return SettingsConfig(
        llm_levels=llm_levels,
        llm_levels_base_url=llm_levels_base_url,
        llm_levels_api_key=llm_levels_api_key,
        permissions_allow=permissions_allow,
        permissions_deny=permissions_deny,
    )


def resolve_settings(
    sources: tuple[SettingSource, ...] | None,
    project_root: PathInput | None,
) -> SettingsConfig | None:
    """按优先级加载并合并 settings

    合并策略：project 完全覆盖 user（project 定义了 llm_levels 就忽略 user 的 llm_levels）。

    Args:
        sources: 要加载的配置源，None 或空 tuple 表示不加载任何配置
        project_root: 项目根目录，None 时使用 cwd

    Returns:
        合并后的 SettingsConfig，或 None（无有效配置）
    """
    if not sources:
        logger.debug("setting_sources 为空，不加载 settings")
        return None

    root = _normalize_project_root(project_root)

    user_settings: SettingsConfig | None = None
    project_settings: SettingsConfig | None = None
    local_settings: SettingsConfig | None = None

    if "user" in sources:
        user_settings = load_settings_file(USER_SETTINGS_PATH)
        if user_settings:
            logger.debug(f"加载 user settings: {USER_SETTINGS_PATH}")

    if "project" in sources:
        project_path = root / ".agent" / "settings.json"
        project_settings = load_settings_file(project_path)
        if project_settings:
            logger.debug(f"加载 project settings: {project_path}")

    if "local" in sources:
        local_path = root / ".agent" / LOCAL_SETTINGS_FILENAME
        local_settings = load_settings_file(local_path)
        if local_settings:
            logger.debug(f"加载 local settings: {local_path}")

    # 合并：local > project > user（字段级覆盖）
    result: SettingsConfig | None = None
    for cfg in (user_settings, project_settings, local_settings):
        if cfg is None:
            continue
        if result is None:
            result = cfg
            continue
        result = SettingsConfig(
            llm_levels=cfg.llm_levels if cfg.llm_levels is not None else result.llm_levels,
            llm_levels_base_url=cfg.llm_levels_base_url if cfg.llm_levels_base_url is not None else result.llm_levels_base_url,
            llm_levels_api_key=cfg.llm_levels_api_key if cfg.llm_levels_api_key is not None else result.llm_levels_api_key,
            permissions_allow=cfg.permissions_allow if cfg.permissions_allow is not None else result.permissions_allow,
            permissions_deny=cfg.permissions_deny if cfg.permissions_deny is not None else result.permissions_deny,
        )

    # 输出配置加载日志
    if result is not None:
        logger.info("✅ settings.json 已加载")
        if result.llm_levels:
            logger.info(f"  - llm_levels: {list(result.llm_levels.keys())}")
        if result.llm_levels_base_url:
            logger.info(f"  - llm_levels_base_url: 已配置 {len(result.llm_levels_base_url)} 个档位")
        if result.llm_levels_api_key:
            logger.info(f"  - llm_levels_api_key: 已配置 {len(result.llm_levels_api_key)} 个档位")
        else:
            logger.debug("  ℹ️  llm_levels_api_key 未配置，将使用环境变量")

    return result


def discover_agents_md(project_root: PathInput | None) -> list[Path]:
    """发现项目中的 AGENTS.md 文件

    搜索位置（按此顺序）：
    - {project_root}/AGENTS.md
    - {project_root}/.agent/AGENTS.md

    Args:
        project_root: 项目根目录，None 时使用 cwd

    Returns:
        存在的 AGENTS.md 文件路径列表（按上述顺序去重）
    """
    # 注意：不要在这里调用 resolve()，避免在 macOS 上把 /var/... 解析成 /private/var/...，
    # 导致调用方（尤其是测试）拿到的路径与输入不一致。
    root = _expand_project_root(project_root)
    candidates = [
        root / "AGENTS.md",
        root / ".agent" / "AGENTS.md",
    ]

    found: list[Path] = []
    for p in candidates:
        if p.is_file():
            found.append(p)
            logger.debug(f"发现 AGENTS.md: {p}")

    if not found:
        logger.debug(f"未在 {root} 中发现 AGENTS.md")

    return found


def discover_user_agents_md() -> list[Path]:
    """发现 user 级别的 AGENTS.md（~/.agent/AGENTS.md）

    Returns:
        包含 ~/.agent/AGENTS.md 的单元素列表（如果存在），否则空列表
    """
    if USER_AGENTS_MD_PATH.is_file():
        logger.debug(f"发现 user AGENTS.md: {USER_AGENTS_MD_PATH}")
        return [USER_AGENTS_MD_PATH]
    return []
