import unittest

from comate_agent_sdk.agent.interrupt import SessionRunController


class TestSessionRunControllerInterruptCallbacks(unittest.TestCase):
    def test_interrupt_invokes_registered_callbacks_with_reason_and_count(self) -> None:
        controller = SessionRunController()
        observed: list[tuple[str, int]] = []

        controller.register_interrupt_callback(
            lambda reason, count: observed.append((reason, count))
        )

        controller.interrupt("user")
        controller.interrupt("user_force")

        self.assertEqual(observed, [("user", 1), ("user_force", 2)])

    def test_unregister_interrupt_callback_stops_future_notifications(self) -> None:
        controller = SessionRunController()
        observed: list[tuple[str, int]] = []

        unregister = controller.register_interrupt_callback(
            lambda reason, count: observed.append((reason, count))
        )
        controller.interrupt("user")
        unregister()
        controller.interrupt("user_force")

        self.assertEqual(observed, [("user", 1)])


if __name__ == "__main__":
    unittest.main()
