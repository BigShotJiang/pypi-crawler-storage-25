"""
极简 @tool 装饰器（Facade 层）。

使用函数签名定义工具参数（通过类型注解），docstring 作为描述。
工具无需继承任何基类，直接使用 @tool 装饰函数定义即可。

Example:
    @tool("搜索文档")
    async def search(query: str, max_results: int = 10) -> str:
        '''搜索包含关键词的文档'''
        return f"搜索结果：{query}"

    # 执行工具
    result = await search.execute(query="Python", max_results=5)
"""

from comate_agent_sdk.tools.decorator import tool

__all__ = ["tool"]
