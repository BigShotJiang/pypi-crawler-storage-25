import tempfile
import unittest
from pathlib import Path
from types import MappingProxyType
from comate_agent_sdk.facade.config.options import AgentOptions
from comate_agent_sdk.facade._internals.adapters import _map_options
from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.llm.views import ChatInvokeCompletion
from comate_agent_sdk.tools.decorator import tool


class TestEnvFieldMapping(unittest.TestCase):
    def test_env_none_by_default(self) -> None:
        config = _map_options(AgentOptions())
        self.assertIsNone(config.env)

    def test_env_maps_to_frozen_mapping(self) -> None:
        config = _map_options(AgentOptions(env={"FOO": "bar", "BAZ": "1"}))
        self.assertIsNotNone(config.env)
        self.assertEqual(config.env["FOO"], "bar")
        self.assertEqual(config.env["BAZ"], "1")
        self.assertIsInstance(config.env, MappingProxyType)

    def test_env_empty_dict_maps_to_none(self) -> None:
        config = _map_options(AgentOptions(env={}))
        self.assertIsNone(config.env)


from comate_agent_sdk.tools.system_context import (
    SystemToolContext,
    bind_system_tool_context,
    get_system_tool_context,
)


class TestEnvSystemToolContext(unittest.TestCase):
    def test_config_env_field_exists(self) -> None:
        ctx = SystemToolContext(
            project_root=Path("/tmp"),
            config_env={"MY_VAR": "hello"},
        )
        self.assertEqual(ctx.config_env["MY_VAR"], "hello")

    def test_config_env_default_none(self) -> None:
        ctx = SystemToolContext(project_root=Path("/tmp"))
        self.assertIsNone(ctx.config_env)

    def test_bind_passes_config_env(self) -> None:
        with bind_system_tool_context(
            project_root="/tmp",
            config_env={"X": "1"},
        ):
            ctx = get_system_tool_context()
            self.assertIsNotNone(ctx.config_env)
            self.assertEqual(ctx.config_env["X"], "1")


class TestAddDirsFieldMapping(unittest.TestCase):
    def test_add_dirs_none_by_default(self) -> None:
        config = _map_options(AgentOptions())
        self.assertIsNone(config.add_dirs)

    def test_add_dirs_maps_to_resolved_paths(self) -> None:
        config = _map_options(AgentOptions(add_dirs=["/tmp", "/var"]))
        self.assertIsNotNone(config.add_dirs)
        self.assertIsInstance(config.add_dirs, tuple)
        self.assertEqual(len(config.add_dirs), 2)
        for p in config.add_dirs:
            self.assertTrue(p.is_absolute())
            self.assertIsInstance(p, Path)

    def test_add_dirs_empty_list_maps_to_none(self) -> None:
        config = _map_options(AgentOptions(add_dirs=[]))
        self.assertIsNone(config.add_dirs)


class _FakeLLM:
    def __init__(self) -> None:
        self.model = "fake:model"

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):
        return ChatInvokeCompletion(content="ok")


class TestDisallowedToolsMapping(unittest.TestCase):
    def test_disallowed_tools_none_by_default(self) -> None:
        config = _map_options(AgentOptions())
        self.assertIsNone(config.disallowed_tools)

    def test_disallowed_tools_maps_to_tuple(self) -> None:
        config = _map_options(AgentOptions(
            tools="comate",
            disallowed_tools=["Bash", "Write"],
        ))
        self.assertEqual(config.disallowed_tools, ("Bash", "Write"))

    def test_disallowed_tools_empty_list_maps_to_none(self) -> None:
        config = _map_options(AgentOptions(disallowed_tools=[]))
        self.assertIsNone(config.disallowed_tools)


class TestDisallowedToolsFiltering(unittest.TestCase):
    def test_disallowed_tools_excluded_from_definitions(self) -> None:
        @tool("A test tool", name="AllowedTool")
        async def allowed(x: str) -> str:
            return x

        @tool("A banned tool", name="BannedTool")
        async def banned(x: str) -> str:
            return x

        with tempfile.TemporaryDirectory() as tmp:
            template = Agent(
                llm=_FakeLLM(),
                config=AgentConfig(
                    tools=(allowed, banned),
                    disallowed_tools=("BannedTool",),
                    offload_enabled=False,
                    setting_sources=None,
                    cwd=Path(tmp),
                ),
            )
            runtime = template.create_runtime()

        tool_names = {d.name for d in runtime.tool_definitions}
        self.assertIn("AllowedTool", tool_names)
        self.assertNotIn("BannedTool", tool_names)


from pydantic import BaseModel as PydanticBaseModel


class SampleSchema(PydanticBaseModel):
    name: str
    age: int


class TestOutputFormatMapping(unittest.TestCase):
    def test_output_format_none_by_default(self) -> None:
        config = _map_options(AgentOptions())
        self.assertIsNone(config.output_format)

    def test_output_format_dict_passthrough(self) -> None:
        raw = {"type": "json_schema", "schema": {"type": "object", "properties": {"x": {"type": "string"}}}}
        config = _map_options(AgentOptions(output_format=raw))
        self.assertIsNotNone(config.output_format)
        self.assertEqual(config.output_format["type"], "json_schema")

    def test_output_format_pydantic_class(self) -> None:
        config = _map_options(AgentOptions(output_format=SampleSchema))
        self.assertIsNotNone(config.output_format)
        self.assertEqual(config.output_format["type"], "json_schema")
        schema = config.output_format["schema"]
        self.assertIn("name", schema["properties"])
        self.assertIn("age", schema["properties"])

    def test_output_format_pydantic_instance(self) -> None:
        instance = SampleSchema(name="test", age=1)
        config = _map_options(AgentOptions(output_format=instance))
        self.assertIsNotNone(config.output_format)
        self.assertEqual(config.output_format["type"], "json_schema")


class TestStructuredOutputParsing(unittest.TestCase):
    def test_completion_has_structured_output_field(self) -> None:
        c = ChatInvokeCompletion(content='{"x": 1}')
        self.assertIsNone(c.structured_output)
        self.assertIsNone(c.structured_output_error)

    def test_completion_structured_output_settable(self) -> None:
        c = ChatInvokeCompletion(content='{"x": 1}', structured_output={"x": 1})
        self.assertEqual(c.structured_output, {"x": 1})


class TestStructuredOutputRetry(unittest.TestCase):
    def test_valid_json_parsed_successfully(self) -> None:
        import json_repair
        result = json_repair.loads('{"name": "test", "age": 30}')
        self.assertEqual(result, {"name": "test", "age": 30})

    def test_json_repair_fixes_minor_errors(self) -> None:
        import json_repair
        result = json_repair.loads('{"name": "test", "age": 30,}')
        self.assertEqual(result["name"], "test")

    def test_structured_output_max_retries_default(self) -> None:
        config = _map_options(AgentOptions())
        self.assertEqual(config.structured_output_max_retries, 3)


from comate_agent_sdk.agent.events import TextEvent as InternalTextEvent


class TestTextEventStructuredOutput(unittest.TestCase):
    def test_text_event_has_structured_output(self) -> None:
        event = InternalTextEvent(content='{"x": 1}', structured_output={"x": 1})
        self.assertEqual(event.structured_output, {"x": 1})

    def test_text_event_structured_output_default_none(self) -> None:
        event = InternalTextEvent(content="hello")
        self.assertIsNone(event.structured_output)
