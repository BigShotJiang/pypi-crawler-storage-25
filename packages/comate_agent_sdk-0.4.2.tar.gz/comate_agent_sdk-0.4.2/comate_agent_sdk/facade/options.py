from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from comate_agent_sdk.mcp.types import McpServerConfig
from comate_agent_sdk.tools.decorator import Tool


@dataclass(slots=True)
class AgentOptions:
    system_prompt: str | None = None
    max_iterations: int = 200
    tools: list[Tool] | None = None
    mcp_servers: dict[str, McpServerConfig] | None = None
    session_id: str | None = None
    cwd: str | Path | None = None
