# upvertex-worker

Namespace reservation for UpVertex Inc. (www.upvertex.com)