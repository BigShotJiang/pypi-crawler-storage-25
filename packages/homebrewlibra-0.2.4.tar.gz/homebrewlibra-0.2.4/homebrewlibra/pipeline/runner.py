"""Config-driven pipeline runner.

Supports two execution models:

1. **Commands** — individual callable steps declared in ``[commands]``
   (legacy alias ``[step-execution]``). Each command maps a label to a
   config section and can be run standalone.

2. **Chains** — ordered pipelines declared in ``[chain-execution]``. Each
   chain is a comma-separated list of command labels executed in sequence.

Usage::

    from homebrewlibra.pipeline.runner import PipelineRunner
    runner = PipelineRunner("config.ini")

    # Run a single command
    runner.run_command("detect_spikes")

    # Run a chain
    runner.run_chain("default")
"""
from __future__ import annotations

import configparser
import fnmatch
import glob
import importlib
import inspect
import logging
import os
import re
from pathlib import Path
from typing import Any

from pandas import DataFrame

from homebrewlibra.helper_io.step_execution import step_execution
from homebrewlibra.pipeline.template_var import TemplateResolver

logger = logging.getLogger(__name__)

class ConfigDeadloopError(ValueError):
    """Raised when an include file is visited more than once (dead loop)."""


class ConfigConflictError(ValueError):
    """Raised when the same config key is assigned different values from multiple files."""

    def __init__(self, conflicts: list[tuple[str, str, str, str, str, str]]) -> None:
        lines = ["Config key conflicts detected across included files:"]
        for section, key, f1, v1, f2, v2 in conflicts:
            lines.append(
                f"  [{section}] {key}\n"
                f"    {f1}: {v1!r}\n"
                f"    {f2}: {v2!r}"
            )
        super().__init__("\n".join(lines))
        self.conflicts = conflicts


__all__ = [
    "PipelineRunner",
    "resolve_value",
    "load_function",
    "load_config",
    "ConfigDeadloopError",
    "ConfigConflictError",
]


# ---------------------------------------------------------------------------
# Config loading with include support
# ---------------------------------------------------------------------------

def load_config(
    config_path: str | Path,
    cfg: configparser.ConfigParser | None = None,
    _visited: set[str] | None = None,
    _conflicts: list[tuple[str, str, str, str, str, str]] | None = None,
    _file_of: dict[tuple[str, str], str] | None = None,
) -> configparser.ConfigParser:
    """Load an INI file with recursive ``[include]`` support.

    Syntax::

        [include]
        paths = common.ini, steps/*.ini, ../shared/globals.ini

    * Paths are relative to the **including file's directory**.
    * Glob patterns (``*``, ``?``) are expanded against the filesystem.
    * Dead loops (same file included twice) raise ``ConfigDeadloopError``
      **immediately**.
    * Key conflicts (same ``section.key`` with different values from multiple
      files) are collected and raised as ``ConfigConflictError`` at the end.
    * The ``[include]`` section is removed from the final config so it
      does not interfere with normal processing.
    """
    config_path = Path(config_path).expanduser().resolve()
    if not config_path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")

    cfg = cfg if cfg is not None else configparser.ConfigParser(interpolation=None)
    _visited = _visited if _visited is not None else set()
    _conflicts = _conflicts if _conflicts is not None else []
    _file_of = _file_of if _file_of is not None else {}

    abs_path = str(config_path)
    if abs_path in _visited:
        raise ConfigDeadloopError(
            f"Dead loop detected: file included twice → {config_path}"
        )
    _visited.add(abs_path)

    # Read this file into a temporary parser so we can inspect [include]
    # before merging (avoids overwriting existing sections prematurely).
    tmp = configparser.ConfigParser(interpolation=None)
    tmp.read(config_path, encoding="utf-8")

    # Resolve includes before merging this file
    if tmp.has_section("include"):
        raw = tmp.get("include", "paths", fallback="").strip()
        if raw:
            base_dir = config_path.parent
            for part in (p.strip() for p in raw.split(",") if p.strip()):
                pattern = str(base_dir / part)
                matches = sorted(glob.glob(pattern))
                if not matches:
                    logger.warning("Include pattern matched no files: %s", pattern)
                for m in matches:
                    load_config(
                        m,
                        cfg=cfg,
                        _visited=_visited,
                        _conflicts=_conflicts,
                        _file_of=_file_of,
                    )
        # Remove [include] so it does not leak into runtime
        tmp.remove_section("include")

    # Merge tmp into the master parser, tracking file provenance
    file_name = str(config_path)
    for section in tmp.sections():
        if not cfg.has_section(section):
            cfg.add_section(section)
        for key, val in tmp.items(section):
            sk = (section, key)
            if sk in _file_of:
                existing_file = _file_of[sk]
                existing_val = cfg.get(section, key)
                if existing_val != val:
                    logger.warning(
                        "Config conflict: [%s] %s = %r (from %s) "
                        "overrides %r (from %s)",
                        section, key, val, file_name, existing_val, existing_file,
                    )
                    _conflicts.append(
                        (section, key, existing_file, existing_val, file_name, val)
                    )
                else:
                    # Identical override — log which file is redundantly setting it
                    logger.info(
                        "Config override (same value): [%s] %s = %r "
                        "(already set by %s, now also in %s)",
                        section, key, val, existing_file, file_name,
                    )
            else:
                _file_of[sk] = file_name
            cfg.set(section, key, val)

    # After processing this file, pop it from _visited so that the same file
    # can legitimately appear via a *different* include path (rare but valid).
    # We keep the conflict tracking intact regardless.
    _visited.discard(abs_path)

    # Raise accumulated conflicts now so the caller gets a full report
    if _conflicts:
        raise ConfigConflictError(_conflicts)

    return cfg


# ---------------------------------------------------------------------------
# Value resolution
# ---------------------------------------------------------------------------

def resolve_value(raw: str, ctx: dict[str, Any]) -> Any:
    """Resolve a config value string into a runtime value.

    Rules:
    * ``VAR++``          → next period of ``ctx['VAR']`` (``YYYYMM`` or ``YYYYMMDD``)
    * ``'...'``          → string literal (quotes stripped)
    * ``@obj``           → ``ctx['obj']`` (whole object)
    * ``@obj.attr``      → ``ctx['obj'][ctx['attr']]``  (attr is a variable)
    * ``@obj.'attr'``    → ``ctx['obj']['attr']``       (attr is a literal)
    * anything else      → ``eval(raw, {"__builtins__": {}}, ctx)``;
      on failure fall back to the raw string
    """
    raw = raw.strip()

    # String literal: 'price'
    if raw.startswith("'") and raw.endswith("'") and len(raw) >= 2:
        return raw[1:-1]

    # Object reference: @obj        → ctx['obj'] (whole object)
    # Column access:    @obj.col    → ctx['obj'][ctx['col']]
    # Literal column:     @obj.'col'  → ctx['obj']['col']
    if raw.startswith("@"):
        body = raw[1:]
        dot = body.find(".")
        if dot == -1:
            # Whole object: @ddf
            obj_name = body
            if obj_name not in ctx:
                return f"<ctx.{obj_name}>"
            return ctx[obj_name]
        obj_name = body[:dot]
        accessor = body[dot + 1 :]
        if obj_name not in ctx:
            return f"<ctx.{obj_name}.{accessor}>"
        obj = ctx[obj_name]
        if accessor.startswith("'") and accessor.endswith("'"):
            col_name = accessor[1:-1]
            return obj[col_name]
        col_name = ctx.get(accessor, accessor)
        return obj[col_name]

    # Direct {_section.key} reference (underscore-prefixed sections)
    if raw.startswith("{") and raw.endswith("}") and "." in raw:
        key = raw[1:-1].strip()
        if key in ctx and not key.endswith((".next", ".first")):
            return ctx[key]

    # Try eval in restricted context; fall back to raw string
    try:
        return eval(raw, {"__builtins__": {}}, ctx)
    except Exception:
        return raw


# ---------------------------------------------------------------------------
# Function loading
# ---------------------------------------------------------------------------

def load_function(dotpath: str):
    """Load a callable from ``package.module:function_name``."""
    if ":" in dotpath:
        module_path, func_name = dotpath.split(":", 1)
    else:
        parts = dotpath.rsplit(".", 1)
        if len(parts) != 2:
            raise ValueError(f"Cannot parse function path: {dotpath!r}")
        module_path, func_name = parts

    mod = importlib.import_module(module_path)
    func = getattr(mod, func_name)
    if not callable(func):
        raise TypeError(f"{dotpath!r} is not callable")
    return func


# ---------------------------------------------------------------------------
# Template → regex (reverse resolution)
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Legacy helpers — kept for backward compatibility, use TemplateResolver instead
# ---------------------------------------------------------------------------


def _template_to_regex(template: str) -> str:
    """Deprecated — use TemplateResolver.build_regex() instead."""
    logger.warning("_template_to_regex is deprecated, use TemplateResolver")
    parts = re.split(r"(\{[^}]+\})", template)
    regex_parts: list[str] = []
    for part in parts:
        if part.startswith("{") and part.endswith("}"):
            var_name = part[1:-1]
            regex_parts.append(f"(?P<{var_name}>.+?)")
        else:
            regex_parts.append(re.escape(part))
    return "".join(regex_parts) + "$"


def extract_path_vars(file_path: str, template: str) -> dict[str, str] | None:
    """Deprecated — use TemplateResolver.extract() instead."""
    logger.warning("extract_path_vars is deprecated, use TemplateResolver")
    regex = _template_to_regex(template)
    m = re.match(regex, file_path)
    if not m:
        return None
    return m.groupdict()


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------

class PipelineRunner:
    """Execute a pipeline declared in an INI file."""

    def __init__(self, config_path: str | Path):
        self.cfg = load_config(config_path)
        self._functions: dict[str, Any] = {}
        self._commands: dict[str, str] = {}   # label → section_name
        self._chains: dict[str, list[str]] = {}  # chain_name → [label, ...]
        self._ctx: dict[str, Any] = {}
        self._parse()
        self.resolver = TemplateResolver(self.cfg, self._ctx)

    # -- internal helpers --------------------------------------------------

    def _parse(self) -> None:
        """Cache function mappings, commands, chains, and seed context."""
        for section_name in self.cfg.sections():
            if section_name.startswith("_") or section_name in (
                "variables", "columns", "markets"
            ):
                if section_name.startswith("_"):
                    for key, raw in self.cfg.items(section_name):
                        flat_key = f"{section_name}.{key}"
                        self._ctx[flat_key] = raw.strip()
                continue
            for key, raw in self.cfg.items(section_name):
                raw = raw.strip()
                if not raw:
                    continue
                self._ctx[key] = raw

        # Build structured section dicts for non-flat sections
        if self.cfg.has_section("markets"):
            self._ctx["markets"] = {
                key: resolve_value(raw.strip(), self._ctx)
                for key, raw in self.cfg.items("markets")
                if raw.strip()
            }

        if self.cfg.has_section("function_mapping"):
            for label, dotpath in self.cfg.items("function_mapping"):
                self._functions[label] = dotpath.strip()

        # Commands: [commands] takes priority, [step-execution] is legacy fallback
        command_section = None
        if self.cfg.has_section("commands"):
            command_section = "commands"
        elif self.cfg.has_section("step-execution"):
            command_section = "step-execution"

        if command_section:
            for label, section in self.cfg.items(command_section):
                self._commands[label.strip()] = section.strip()

        # Chains
        if self.cfg.has_section("chain-execution"):
            for chain_name, raw in self.cfg.items("chain-execution"):
                labels = [lbl.strip() for lbl in raw.split(",") if lbl.strip()]
                self._chains[chain_name.strip()] = labels

    def _resolve_func(self, func_label: str):
        """Return a callable given a config label like ``table_grouping_by.1``."""
        base_label = func_label.split(".", 1)[0]
        dotpath = self._functions.get(base_label)
        if dotpath is None:
            raise KeyError(
                f"No function_mapping entry for '{base_label}' "
                f"(from label '{func_label}')"
            )
        return load_function(dotpath)

    def _check_unresolved(self, path: str, label: str = "path") -> None:
        """Raise ``ValueError`` if ``path`` still contains ``{var}`` placeholders."""
        unresolved = re.findall(r"\{([^}]+)\}", path)
        if unresolved:
            raise ValueError(
                f"Unresolved template variables in {label}: {path}\n"
                f"Missing context variables: {', '.join(unresolved)}\n"
                f"Pass them with --set VAR=VALUE (e.g. --set {unresolved[0]}=VALUE)"
            )

    def _resolve_constants(self, template: str) -> str:
        """Resolve only literal-type variables, preserving extractable ones."""
        return self.resolver._resolve_constants(template)

    def _resolve_template(self, template: str) -> str:
        """Expand ``{var}`` placeholders using the template resolver."""
        return self.resolver.resolve(template)

    def _resolve_section_kwargs(self, section_name: str) -> dict[str, Any]:
        """Turn a config section into keyword arguments with value resolution."""
        if not self.cfg.has_section(section_name):
            raise KeyError(f"Config section '{section_name}' not found")

        kwargs: dict[str, Any] = {}
        for key, raw in self.cfg.items(section_name):
            key = key.strip()
            raw = raw.strip()
            if not raw:
                continue
            # Template strings stay unresolved until use.
            if key in ("file_name", "file_pattern", "file_list", "output_name", "output_pattern"):
                kwargs[key] = raw
            elif key == "source_ddf":
                # Meta-key for context injection — must stay a string label
                kwargs[key] = raw
            elif key in ("input_file", "output_file"):
                # Resolve template variables for direct file paths (atomic functions)
                kwargs[key] = self.resolver.resolve(raw)
            elif key in ("input_template", "zeros_file"):
                # Resolve constants (e.g. {sz}=01) but preserve extractable vars.
                kwargs[key] = self._resolve_constants(raw)
            elif key.endswith("_template"):
                kwargs[key] = raw
            else:
                resolved = resolve_value(raw, self._ctx)
                # Allow function_mapping labels for func/func_name keys
                if key in ("func", "func_name") and isinstance(resolved, str):
                    label = resolved.strip()
                    if label in self._functions:
                        resolved = load_function(self._functions[label])
                kwargs[key] = resolved
        return kwargs

    def _iter_files(self, kwargs: dict[str, Any]) -> tuple[list[str], str | None]:
        """Return (input_files, output_template) for a step.

        Input modes:
        * ``file_name``     → single file
        * ``file_pattern``  → glob pattern
        * ``file_list``     → comma-separated explicit paths

        Output modes:
        * ``output_name``   → single output path
        * ``output_pattern`` → template for per-file output paths
        * missing           → overwrite input (None)
        """
        # Resolve input files
        input_files: list[str] = []
        if "file_name" in kwargs:
            path = os.path.expanduser(self.resolver.resolve(kwargs.pop("file_name")))
            self._check_unresolved(path, "file_name")
            input_files = [path]
        elif "file_pattern" in kwargs:
            pattern = os.path.expanduser(self.resolver.resolve(kwargs.pop("file_pattern")))
            self._check_unresolved(pattern, "file_pattern")
            matches = sorted(glob.glob(pattern))
            if not matches:
                logger.warning("No files matched pattern: %s", pattern)
            else:
                logger.info("Pattern matched %s files: %s", len(matches), pattern)
            input_files = matches
        elif "file_list" in kwargs:
            raw = kwargs.pop("file_list")
            if isinstance(raw, str):
                raw = [p.strip() for p in raw.split(",")]
            input_files = []
            for p in raw:
                path = os.path.expanduser(self.resolver.resolve(p))
                self._check_unresolved(path, "file_list entry")
                input_files.append(path)
            logger.info("File list: %s entries", len(input_files))

        # Resolve output template (if any)
        output_template = None
        if "output_name" in kwargs:
            output_template = os.path.expanduser(self.resolver.resolve(kwargs.pop("output_name")))
            self._check_unresolved(output_template, "output_name")
        elif "output_pattern" in kwargs:
            output_template = os.path.expanduser(self.resolver.resolve(kwargs.pop("output_pattern")))
            self._check_unresolved(output_template, "output_pattern")

        return input_files, output_template

    def _resolve_output_path(
        self, input_path: str, input_template: str | None, output_template: str
    ) -> str:
        """Build an output path for a specific input file.

        If ``input_template`` is provided, variables are extracted from the
        input path using mask-based regex and temporarily injected into the
        resolver before resolving the output template.
        """
        if input_template is None:
            return self.resolver.resolve(output_template)

        # Resolve literal constants (e.g. {sz}, {base_path}) and expand ~
        input_template = os.path.expanduser(
            self.resolver._resolve_constants(input_template)
        )

        extracted = self.resolver.extract(input_path, input_template)
        if extracted is None:
            logger.warning(
                "Could not extract vars from %s using template %s — "
                "falling back to global context",
                input_path,
                input_template,
            )
            return self.resolver.resolve(output_template)

        return self.resolver.resolve_with(output_template, **extracted)

    # -- ddf / ddf2 injection ----------------------------------------------

    def _inject_ctx(
        self,
        func,
        kwargs: dict[str, Any],
        source_ddf: str | None = None,
    ) -> dict[str, Any]:
        """Inject ``ddf`` / ``ddf2`` from context when the callable accepts them.

        Inspects the function signature and, if parameters named ``ddf`` or
        ``ddf2`` exist, passes the corresponding context values when
        available.  Falls back to ``df`` / ``df2`` for functions that use
        the shorter naming convention.

        ``source_ddf`` allows remapping: if ``source_ddf='ddf2'``, the value
        stored under ``ctx['ddf2']`` is passed as the ``ddf`` argument.
        """
        sig = inspect.signature(func)
        params = sig.parameters
        out = dict(kwargs)

        for key in ("ddf", "ddf2"):
            if key in params and key in self._ctx:
                out[key] = self._ctx[key]

        # Fallback: ctx["ddf"] → param "df" when "ddf" is not accepted
        if "ddf" not in params and "df" in params and "ddf" in self._ctx:
            out["df"] = self._ctx["ddf"]
        if "ddf2" not in params and "df2" in params and "ddf2" in self._ctx:
            out["df2"] = self._ctx["ddf2"]

        if "ddf" in params and source_ddf and source_ddf in self._ctx:
            out["ddf"] = self._ctx[source_ddf]
        # Also apply source_ddf remapping for the "df" fallback
        if "ddf" not in params and "df" in params and source_ddf and source_ddf in self._ctx:
            out["df"] = self._ctx[source_ddf]

        if "ctx" in params:
            out["ctx"] = self._ctx
        return out

    def _is_loop_section(self, section_name: str) -> bool:
        """Return True if the config section declares a loop construct."""
        if not self.cfg.has_section(section_name):
            return False
        return self.cfg.get(section_name, "type", fallback="").strip().lower() == "loop"

    def _run_loop(self, section_name: str) -> DataFrame | None:
        """Execute a loop section.

        ``loop_values`` can be an explicit comma-separated list, or a glob
        pattern containing ``*`` / ``?`` which is resolved against the
        filesystem.  When a glob is used, ``loop_template`` (optional) defines
        how to extract ``loop_var`` from each matched path.

        Expected keys::

            loop_values  = val1, val2, val3
                         | {base_path}/{ticker}-trades-*.{file_format}
            loop_var     = period          # optional, defaults to ``period``
            loop_template = {base_path}/{ticker}-trades-{period}.{file_format}
            run          = cmd1, cmd2, ... # chain of command labels
        """
        if not self.cfg.has_section(section_name):
            raise KeyError(f"Loop section '{section_name}' not found")

        raw_values = self.cfg.get(section_name, "loop_values", fallback="").strip()
        loop_var = self.cfg.get(section_name, "loop_var", fallback="period").strip()
        raw_run = self.cfg.get(section_name, "run", fallback="").strip()
        loop_template = self.cfg.get(section_name, "loop_template", fallback="").strip()

        if not raw_values:
            raise ValueError(f"Loop section '{section_name}' missing 'loop_values'")
        if not raw_run:
            raise ValueError(f"Loop section '{section_name}' missing 'run'")

        # Detect glob pattern vs explicit list
        is_glob = any(c in raw_values for c in "*?[")
        if is_glob:
            pattern = os.path.expanduser(self.resolver.resolve(raw_values))
            matches = sorted(glob.glob(pattern))
            if not matches:
                logger.warning("Loop '%s' — no files matched: %s", section_name, pattern)
                return None
            logger.info(
                "Loop '%s' — resolved glob %s → %s files", section_name, pattern, len(matches)
            )
            # Extract loop_var from each matched path
            if loop_template:
                tmpl = os.path.expanduser(self.resolver._resolve_constants(loop_template))
                values: list[str] = []
                for p in matches:
                    extracted = self.resolver.extract(p, tmpl)
                    if extracted and loop_var in extracted:
                        values.append(extracted[loop_var])
                    else:
                        # Fallback: use the filename stem
                        values.append(Path(p).stem)
            else:
                # No template — use filename stems as values
                values = [Path(p).stem for p in matches]
        else:
            values = [v.strip() for v in raw_values.split(",") if v.strip()]

        labels = [lbl.strip() for lbl in raw_run.split(",") if lbl.strip()]

        logger.info(
            "=" * 60)
        logger.info(
            "Running loop: %s (%s iterations, %s steps)", section_name, len(values), len(labels))
        logger.info(
            "=" * 60)

        last_result = None
        for i, val in enumerate(values, 1):
            self._ctx[loop_var] = val
            self.resolver.set(**{loop_var: val})
            logger.info("[%s/%s] %s = %s", i, len(values), loop_var, val)
            for func_label in labels:
                last_result = self._run_single(func_label)

        return last_result

    # -- public API --------------------------------------------------------

    @property
    def commands(self) -> list[str]:
        """Return list of available command labels."""
        return list(self._commands.keys())

    @property
    def chains(self) -> list[str]:
        """Return list of available chain names."""
        return list(self._chains.keys())

    @property
    def steps(self) -> list[str]:
        """Legacy alias — returns available command labels."""
        return self.commands

    def reset_context(self, **initial) -> None:
        """Clear execution context and optionally seed it."""
        self._ctx.clear()
        self._ctx.update(initial)
        # Rebuild resolver with new context
        self.resolver = TemplateResolver(self.cfg, self._ctx)

    def _run_single(self, func_label: str) -> DataFrame | None:
        """Execute a single command or chain by its label.

        Returns the step's output DataFrame (or None).
        """
        section_name = self._commands.get(func_label)

        if section_name is not None:
            # Loop construct — section type = loop
            if self._is_loop_section(section_name):
                return self._run_loop(section_name)

            func = self._resolve_func(func_label)
            kwargs = self._resolve_section_kwargs(section_name)

            force_update = kwargs.pop(
                "force_update", self._ctx.get("force_update", False)
            )
            update = kwargs.pop("update", self._ctx.get("update", False))
            read_only = kwargs.pop("read_only", False)

            # Remember whether this step was declared as file-based before _iter_files pops the keys.
            has_file_input = any(
                k in kwargs for k in ("file_name", "file_pattern", "file_list")
            )

            input_files, output_template = self._iter_files(kwargs)

            if not input_files:
                if has_file_input:
                    logger.warning(
                        "Step '%s' — no input files matched; skipping ("
                        "file-based step cannot run without data)",
                        func_label,
                    )
                    return None
                # Direct call — no files involved; inject cached ddf/ddf2 when accepted
                source_ddf = kwargs.pop("source_ddf", None)
                call_kwargs = self._inject_ctx(func, kwargs, source_ddf=source_ddf)
                df_out = func(**call_kwargs)
                if df_out is not None:
                    self._ctx["result"] = df_out
                    if isinstance(df_out, dict):
                        for key in ("ddf", "ddf2"):
                            if key in df_out and df_out[key] is not None:
                                self._ctx[key] = df_out[key]
                                logger.info(
                                    "Step '%s' produced %s (%s rows)",
                                    func_label, key, len(df_out[key]),
                                )
                    else:
                        self._ctx["ddf"] = df_out
                        logger.info("Step '%s' produced ddf (%s rows)", func_label, len(df_out))
                else:
                    logger.warning("Step '%s' returned None", func_label)
                return df_out

            # Remember the input template for variable extraction when output is specified.
            # Explicit ``input_template`` takes priority, then raw file_pattern/file_name/file_list.
            input_template = None
            if self.cfg.has_section(section_name):
                if "input_template" in self.cfg.options(section_name):
                    input_template = self.cfg.get(section_name, "input_template")
                elif "file_pattern" in self.cfg.options(section_name):
                    input_template = self.cfg.get(section_name, "file_pattern")
                elif "file_name" in self.cfg.options(section_name):
                    input_template = self.cfg.get(section_name, "file_name")
                elif "file_list" in self.cfg.options(section_name):
                    # For file_list, use the first entry as a representative template
                    first = self.cfg.get(section_name, "file_list").split(",")[0].strip()
                    input_template = first

            if input_template is not None:
                input_template = os.path.expanduser(input_template)

            # Batch mode
            all_results: list[DataFrame] = []
            for i, input_path in enumerate(input_files, 1):
                logger.info("[%s/%s] %s", i, len(input_files), input_path)
                self._ctx["current_file"] = input_path

                if output_template is not None:
                    # Separate output path → function handles its own I/O
                    output_path = self._resolve_output_path(
                        input_path, input_template, output_template
                    )
                    logger.info("  → output: %s", output_path)
                    source_ddf = kwargs.pop("source_ddf", None)
                    call_kwargs = self._inject_ctx(func, kwargs, source_ddf=source_ddf)
                    df_out = func(
                        input_file=input_path,
                        output_file=output_path,
                        **call_kwargs,
                    )
                elif read_only:
                    # Load and pass data directly — do not save back
                    from homebrewlibra.helper_feather.feather_io_helper import (
                        load_feather_trades,
                    )

                    data = load_feather_trades(input_path)
                    source_ddf = kwargs.pop("source_ddf", None)
                    call_kwargs = self._inject_ctx(func, kwargs, source_ddf=source_ddf)
                    df_out = func(ddf=data, **call_kwargs)
                else:
                    # Overwrite input → step_execution handles caching
                    logger.warning(
                        "DEPRECATED: step_execution path for '%s'. "
                        "Migrate to chain-atomic sections in config/60-steps.ini "
                        "(see config/99-step-execution.ini for legacy reference).",
                        func_label,
                    )
                    df_out = step_execution(
                        file_name=input_path,
                        func_name=func,
                        force_update=force_update,
                        update=update,
                        **kwargs,
                    )

                if df_out is not None:
                    all_results.append(df_out)
                    if isinstance(df_out, dict):
                        for key in ("ddf", "ddf2"):
                            if key in df_out and df_out[key] is not None:
                                self._ctx[key] = df_out[key]
                    else:
                        self._ctx["ddf"] = df_out

            if all_results:
                self._ctx["result"] = all_results[-1]
                last = all_results[-1]
                size = len(last) if hasattr(last, "__len__") else "n/a"
                logger.info(
                    "Step '%s' completed — %s files processed, last result: %s rows",
                    func_label,
                    len(all_results),
                    size,
                )
                return all_results[-1]

            logger.warning("Step '%s' — no files produced output", func_label)
            return None

        # Not a command — try chains (allows nesting chains inside loops)
        if func_label in self._chains:
            return self.run_chain(func_label)

        raise KeyError(
            f"Command '{func_label}' not found in [commands] or [step-execution]"
        )

    def run_command(self, func_label: str) -> DataFrame | None:
        """Run a single command by label."""
        logger.info("=" * 60)
        logger.info("Running command: %s", func_label)
        logger.info("=" * 60)
        return self._run_single(func_label)

    def run_chain(self, chain_name: str) -> DataFrame | None:
        """Run a named chain of commands in order."""
        labels = self._chains.get(chain_name)
        if labels is None:
            raise KeyError(
                f"Chain '{chain_name}' not found in [chain-execution]"
            )

        logger.info("=" * 60)
        logger.info("Running chain: %s (%s steps)", chain_name, len(labels))
        logger.info("=" * 60)

        df_out = None
        for func_label in labels:
            df_out = self._run_single(func_label)
            import time
            time.sleep(0.5)
        return df_out

    def run(
        self,
        targets: list[str] | None = None,
        *,
        chain: str | None = None,
    ) -> DataFrame | None:
        """Run commands or a chain.

        * ``chain='name'`` → run the named chain.
        * ``targets=['a','b']`` → run individual commands.
        * ``targets=None, chain=None`` → run every command in declaration order.
        """
        if chain is not None:
            return self.run_chain(chain)

        labels = targets if targets else self.commands
        df_out = None
        for func_label in labels:
            df_out = self.run_command(func_label)

        return df_out
