"""YouTube Shorts CRDT document parser.

This module provides parsing for CRDT documents containing YouTube Short
post data with youtubeshort nodes.
"""

from __future__ import annotations

import re
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from marqetive.utils.crdt.exceptions import CRDTEmptyDocumentError, CRDTParseError
from marqetive.utils.crdt.models import (
    ParsedYouTubeShortDocument,
    YouTubeShortPostContent,
)
from marqetive.utils.crdt.platforms.base import BaseCRDTParser

if TYPE_CHECKING:
    from pycrdt import Doc, XmlElement


def _parse_tags(raw: str) -> list[str]:
    """Split a space/comma-separated tag string and strip leading '#'."""
    parts = re.split(r"[,\s]+", raw.strip())
    return [p.lstrip("#") for p in parts if p and p != "#"]


class YouTubeCRDTParser(BaseCRDTParser[ParsedYouTubeShortDocument]):
    """Parser for YouTube Short CRDT documents.

    Handles parsing of youtubeshort nodes. Supports single video posts
    with title, description, privacy, tags and other metadata.

    Validation rules:
        - Max 100 characters for title
        - Video URL is required (at least 1 media item)
    """

    @property
    def platform_name(self) -> str:
        return "youtube"

    @property
    def root_node_type(self) -> str:
        return "youtubeshort"

    def parse_document(
        self,
        doc: Doc[Any],
        fragment_name: str = "default",
        *,
        include_auto_number: bool = False,  # noqa: ARG002
    ) -> ParsedYouTubeShortDocument:
        """Parse a YouTube Short CRDT document.

        Args:
            doc: The pycrdt Doc object to parse
            fragment_name: Name of the XML fragment to parse

        Returns:
            ParsedYouTubeShortDocument with parsed post

        Raises:
            CRDTEmptyDocumentError: If no youtubeshort node found
            CRDTParseError: If parsing fails
        """
        fragment = self._get_fragment(doc, fragment_name)
        raw_attributes = self._get_node_attributes(fragment)

        post_nodes = self._find_nodes_by_type(fragment, self.root_node_type)

        if not post_nodes:
            raise CRDTEmptyDocumentError(
                "No YouTube Short found in document",
                fragment_name=fragment_name,
            )

        try:
            post = self._parse_post(post_nodes[0])
        except Exception as e:
            raise CRDTParseError(
                f"Failed to parse YouTube Short: {e}",
                platform=self.platform_name,
                node_type=self.root_node_type,
            ) from e

        return ParsedYouTubeShortDocument(
            post=post,
            raw_attributes=raw_attributes,
            parsed_at=datetime.now(UTC),
        )

    def _parse_post(self, node: XmlElement) -> YouTubeShortPostContent:
        """Parse a youtubeshort node."""
        attrs = self._get_node_attributes(node)

        post_id = attrs.get("id")
        if post_id is not None:
            post_id = str(post_id)

        title = str(attrs.get("title", ""))
        description = self._extract_text(node)
        media = self._parse_media_urls(node, "media")

        privacy_status = str(attrs.get("privacy_status", "public"))
        category_id = str(attrs.get("category_id", "22"))
        license_ = str(attrs.get("license", "youtube"))
        _raw_thumbnail = attrs.get("thumbnail_url")
        thumbnail_url = str(_raw_thumbnail) if _raw_thumbnail is not None else None

        raw_tags = attrs.get("tags", "")
        tags = _parse_tags(str(raw_tags)) if raw_tags else []

        def _bool_attr(key: str, default: bool = False) -> bool:
            val = attrs.get(key)
            if val is None:
                return default
            return str(val).lower() in ("true", "1", "yes")

        return YouTubeShortPostContent(
            id=post_id,
            title=title,
            description=description,
            media=media,
            privacy_status=privacy_status,
            category_id=category_id,
            made_for_kids=_bool_attr("made_for_kids", False),
            tags=tags,
            notify_subscribers=_bool_attr("notify_subscribers", True),
            license=license_,
            embeddable=_bool_attr("embeddable", True),
            thumbnail_url=thumbnail_url
        )
