"""TikTok-specific CRDT document parser.

This module provides parsing for CRDT documents containing TikTok
post data with tiktokpost nodes.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from marqetive.utils.crdt.exceptions import CRDTEmptyDocumentError, CRDTParseError
from marqetive.utils.crdt.models import (
    ParsedTikTokDocument,
    TikTokPostContent,
)
from marqetive.utils.crdt.platforms.base import BaseCRDTParser

if TYPE_CHECKING:
    from pycrdt import Doc, XmlElement


class TikTokCRDTParser(BaseCRDTParser[ParsedTikTokDocument]):
    """Parser for TikTok CRDT documents.

    Handles parsing of tiktokpost nodes. Supports single video posts
    with location and music metadata.

    Validation rules:
        - Max 2200 characters for title
        - Video is required (at least 1 media item)
    """

    @property
    def platform_name(self) -> str:
        """Return the platform name."""
        return "tiktok"

    @property
    def root_node_type(self) -> str:
        """Return the root node type for TikTok."""
        return "tiktokpost"

    def parse_document(
        self,
        doc: Doc[Any],
        fragment_name: str = "default",
        *,
        include_auto_number: bool = False,  # noqa: ARG002
    ) -> ParsedTikTokDocument:
        """Parse a TikTok CRDT document.

        Args:
            doc: The pycrdt Doc object to parse
            fragment_name: Name of the XML fragment to parse

        Returns:
            ParsedTikTokDocument with parsed post

        Raises:
            CRDTEmptyDocumentError: If no post found
            CRDTParseError: If parsing fails
        """
        fragment = self._get_fragment(doc, fragment_name)
        raw_attributes = self._get_node_attributes(fragment)

        # Find the tiktokpost node
        post_nodes = self._find_nodes_by_type(fragment, self.root_node_type)

        if not post_nodes:
            raise CRDTEmptyDocumentError(
                "No TikTok post found in document",
                fragment_name=fragment_name,
            )

        # Parse the post
        try:
            post = self._parse_post(post_nodes[0])
        except Exception as e:
            raise CRDTParseError(
                f"Failed to parse TikTok post: {e}",
                platform=self.platform_name,
                node_type=self.root_node_type,
            ) from e

        return ParsedTikTokDocument(
            post=post,
            raw_attributes=raw_attributes,
            parsed_at=datetime.now(UTC),
        )

    def _parse_post(self, node: XmlElement) -> TikTokPostContent:
        """Parse a tiktokpost node.

        Args:
            node: The tiktokpost XML node

        Returns:
            TikTokPostContent with parsed data
        """
        attrs = self._get_node_attributes(node)

        post_id = attrs.get("id")
        if post_id is not None:
            post_id = str(post_id)

        title = self._extract_text(node)
        media = self._parse_media_urls(node, "media")

        location = attrs.get("location")
        if location is not None:
            location = str(location)

        music = attrs.get("music")
        if music is not None:
            music = str(music)

        privacy_level = attrs.get("privacy_level")
        if privacy_level is not None:
            privacy_level = str(privacy_level)

        def _bool_attr(key: str) -> bool:
            val = attrs.get(key)
            return (
                str(val).lower() in ("true", "1", "yes") if val is not None else False
            )

        def _int_attr(key: str) -> int | None:
            val = attrs.get(key)
            if val is None:
                return None
            try:
                return int(val)
            except (ValueError, TypeError):
                return None

        return TikTokPostContent(
            id=post_id,
            title=title,
            media=media,
            location=location,
            music=music,
            privacy_level=privacy_level,
            disable_comment=_bool_attr("disable_comment"),
            disable_duet=_bool_attr("disable_duet"),
            disable_stitch=_bool_attr("disable_stitch"),
            video_cover_timestamp_ms=_int_attr("video_cover_timestamp_ms"),
            brand_content_toggle=_bool_attr("brand_content_toggle"),
            brand_organic_toggle=_bool_attr("brand_organic_toggle"),
            schedule_time=_int_attr("schedule_time"),
            is_aigc=_bool_attr("is_aigc"),
            auto_add_music=_bool_attr("auto_add_music"),
            photo_cover_index=_int_attr("photo_cover_index"),
        )
