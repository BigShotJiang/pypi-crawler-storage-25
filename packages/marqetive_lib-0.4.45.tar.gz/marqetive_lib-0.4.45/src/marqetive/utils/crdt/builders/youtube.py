"""YouTube Shorts CRDT document builder.

Builds pycrdt Doc objects from ParsedYouTubeShortDocument models.
"""

from __future__ import annotations

from typing import Any

from pycrdt import Doc, XmlElement

from marqetive.utils.crdt.builders.base import BaseCRDTBuilder
from marqetive.utils.crdt.models import ParsedYouTubeShortDocument


class YouTubeCRDTBuilder(BaseCRDTBuilder[ParsedYouTubeShortDocument]):
    """Builder for YouTube Short CRDT documents."""

    @property
    def platform_name(self) -> str:
        return "youtube"

    @property
    def root_node_type(self) -> str:
        return "youtubeshort"

    def build_document(
        self, parsed: ParsedYouTubeShortDocument, fragment_name: str = "default"
    ) -> Doc[Any]:
        """Build a YouTube Short CRDT Doc from a parsed document."""
        post = parsed.post
        attrs: dict[str, str] = {}
        if post.id is not None:
            attrs["id"] = post.id
        attrs["title"] = post.title
        if post.media:
            attrs["media"] = self._build_media_attribute(post.media)
        attrs["privacy_status"] = post.privacy_status
        attrs["category_id"] = post.category_id
        if post.made_for_kids:
            attrs["made_for_kids"] = "true"
        if post.tags:
            attrs["tags"] = " ".join(
                f"#{t}" if not t.startswith("#") else t for t in post.tags
            )
        if not post.notify_subscribers:
            attrs["notify_subscribers"] = "false"
        attrs["license"] = post.license
        if not post.embeddable:
            attrs["embeddable"] = "false"

        paragraphs = self._build_text_paragraphs(post.description)
        children = [XmlElement("youtubeshort", attributes=attrs, contents=paragraphs)]

        return self._create_doc_with_fragment(fragment_name, children)
