from marqetive.platforms.youtube.client import YouTubeShortsClient

__all__ = ["YouTubeShortsClient"]
