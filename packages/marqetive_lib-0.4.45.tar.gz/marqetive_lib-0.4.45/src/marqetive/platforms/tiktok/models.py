"""TikTok-specific models for post creation.

This module defines TikTok-specific data models for creating video posts,
including privacy settings and content toggles.
"""

from enum import StrEnum

from pydantic import BaseModel, Field


class PrivacyLevel(StrEnum):
    """Privacy level options for TikTok posts.

    Attributes:
        PUBLIC: Visible to everyone
        FRIENDS: Visible to mutual followers/friends only
        FOLLOWER_OF_CREATOR: Visible to followers only
        PRIVATE: Visible only to the author (for unaudited apps)
    """

    PUBLIC = "PUBLIC_TO_EVERYONE"
    FRIENDS = "MUTUAL_FOLLOW_FRIENDS"
    FOLLOWER_OF_CREATOR = "FOLLOWER_OF_CREATOR"
    PRIVATE = "SELF_ONLY"


class TikTokPostRequest(BaseModel):
    """TikTok-specific post creation request with full API options.

    This model provides a type-safe way to configure TikTok-specific post settings.
    It can be converted to the universal PostCreateRequest for use with TikTokClient.

    Supports both video posts (mp4/mov) and photo carousel posts (jpg/jpeg/webp/png).
    Videos must be between 3 seconds and 10 minutes, and under 4GB in size.
    Photo carousels support up to 35 images.

    Attributes:
        title: Video/photo title (max 2200 characters)
        video_url: URL to video file (for video posts)
        video_id: Pre-uploaded video ID
        privacy_level: Privacy setting (PUBLIC, FRIENDS, FOLLOWER_OF_CREATOR, PRIVATE)
        disable_comment: Disable comments on the post
        disable_duet: Disable duet feature (video only)
        disable_stitch: Disable stitch feature (video only)
        video_cover_timestamp_ms: Timestamp in ms for auto-generated video cover
        brand_content_toggle: Mark as branded/sponsored content
        brand_organic_toggle: Mark as organic branded content
        schedule_time: Unix timestamp to schedule post (10 mins to 10 days ahead)
        is_aigc: Disclose content as AI-generated
        auto_add_music: Automatically add background music
        photo_cover_index: Index of the cover photo for photo carousel posts (0-based)

    Example:
        >>> from marqetive.core.models import PostCreateRequest
        >>>
        >>> # Create TikTok-specific request
        >>> tiktok_request = TikTokPostRequest(
        ...     title="Check out this dance!",
        ...     video_url="https://example.com/dance.mp4",
        ...     privacy_level=PrivacyLevel.PUBLIC,
        ...     disable_duet=True,
        ...     is_aigc=False,
        ...     auto_add_music=True,
        ... )
        >>>
        >>> # Convert to universal PostCreateRequest for client
        >>> request = PostCreateRequest(
        ...     content=tiktok_request.title,
        ...     media_urls=[tiktok_request.video_url] if tiktok_request.video_url else [],
        ...     additional_data=tiktok_request.model_dump(exclude_none=True),
        ... )
        >>> async with TikTokClient(credentials) as client:
        ...     post = await client.create_post(request)
    """

    title: str | None = None
    video_url: str | None = None
    video_id: str | None = None
    privacy_level: PrivacyLevel = PrivacyLevel.PRIVATE
    disable_comment: bool = False
    disable_duet: bool = False
    disable_stitch: bool = False
    video_cover_timestamp_ms: int | None = None
    brand_content_toggle: bool = False
    brand_organic_toggle: bool = False
    schedule_time: int | None = Field(
        default=None, description="Unix timestamp (10 min to 10 days ahead)"
    )
    is_aigc: bool = False
    auto_add_music: bool = False
    photo_cover_index: int | None = None
