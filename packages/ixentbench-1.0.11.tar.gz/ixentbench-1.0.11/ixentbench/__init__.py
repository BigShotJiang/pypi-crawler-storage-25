# -*- coding: utf-8 -*-
__version__ = "1.0.11"
__author__  = "iXentLabs"
__email__   = "contact@ixentlabs.com"