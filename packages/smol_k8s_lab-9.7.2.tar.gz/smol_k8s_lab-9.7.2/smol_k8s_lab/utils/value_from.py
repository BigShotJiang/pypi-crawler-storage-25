import logging as log
from os import environ
from smol_k8s_lab.bitwarden.bw_cli import BwCLI

DEFAULT_S3_VALUES = {
        "endpoint": "",
        "bucket": "",
        "region": "",
        "s3_user": "",
        "s3_password": ""
        }

DEFAULT_DB_VALUES = {
        "schedule": "0 0 */12 * * *",
        "retention": "2d"
        }

DEFAULT_PVC_VALUES = {
        "schedule": "10 */12 * * *",
        "retention": {
            "keepDaily": 7,
            "keepWeekly": 2,
            "keepMonthly": 2
            }
        }


def extract_secret(value: dict = {}) -> str:
    """
    process a value that has a value_from dict and return the value

    supported value_from methods: env, bitwarden. coming soon: openbao
    """
    if isinstance(value, dict):
        value_dict = value.get('value_from', None)
        if not value_dict:
            log.warn(f"{value} has no value_from dict, so we're returning empty str")
            return ""
    else:
        log.warn(f"value, {value}, is not a dict, so we're returning it as it came in")
        return value

    # try to get variable from env var
    env_var = value_dict.get('env', None)
    if env_var:
        return environ.get(env_var, "")

    # try to get variable from bitwarden item and field
    bitwarden_item = value_dict.get('bitwarden_item', None)
    if bitwarden_item:
        bitwarden_field = value['value_from'].get('bitwarden_field', None)
        bw = BwCLI()
        return bw.get_item(bitwarden_item)[0][bitwarden_field]

    # try to get variable from openbao (or vault) item
    openbao_item = value_dict.get('openbao_item', None)
    if openbao_item:
        log.warn("openbao support not yet implemented")

    log.warn("No secret was found so returning empty string")
    return ""


def process_backup_vals(backup_dict: dict) -> dict:
    """
    return a backup value dict by processing s3, pvc, and db values and
    getting any secret data
    """
    # process s3 values
    s3_values = backup_dict.get('s3', DEFAULT_S3_VALUES)
    s3_values["access_key_id"] = extract_secret(s3_values.get('access_key_id', ''))
    s3_values["secret_access_key"] = extract_secret(s3_values.get('secret_access_key', ''))
    s3_values["endpoint"] = s3_values.get('endpoint', '')
    s3_values["bucket"] = s3_values.get('bucket', '')
    s3_values["region"] = s3_values.get('region', '')

    # process db values
    db_values = backup_dict.get('db', DEFAULT_DB_VALUES)
    db_values["schedule"] = db_values.get('schedule',
                                          DEFAULT_DB_VALUES['schedule'])
    db_values["retention"] = db_values.get('retention',
                                           DEFAULT_DB_VALUES['retention'])

    # process pvc values
    pvc_values = backup_dict.get('pvc', DEFAULT_PVC_VALUES)
    pvc_values["schedule"] = pvc_values.get('schedule',
                                            DEFAULT_PVC_VALUES['schedule'])
    pvc_values["retention"] = pvc_values.get('retention',
                                             DEFAULT_PVC_VALUES['retention'])

    return_dict =  {
            "s3": s3_values,
            "pvc": pvc_values,
            "db": db_values,
            "restic_repo_pass": extract_secret(
                backup_dict.get('restic_repo_password', ''))
            }

    return return_dict
