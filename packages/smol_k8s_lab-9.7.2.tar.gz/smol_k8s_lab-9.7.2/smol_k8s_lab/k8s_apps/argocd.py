"""
       Name: argocd
DESCRIPTION: configure argocd
     AUTHOR: @jessebot
    LICENSE: GNU AFFERO GENERAL PUBLIC LICENSE Version 3
"""
import bcrypt
import logging as log
from os import path
import yaml
from ..constants import XDG_CACHE_DIR
from ..k8s_tools.argocd_util import ArgoCD
from ..k8s_tools.helm import Helm
from ..k8s_tools.k8s_lib import K8s
from ..bitwarden.bw_cli import BwCLI
from ..utils.passwords import create_password
from ..utils.rich_cli.console_logging import header, sub_header


def configure_argocd(k8s_obj: K8s,
                     argocd_config_dict: dict = {},
                     secret_dict: dict = {},
                     bitwarden: BwCLI = None) -> ArgoCD:
    """
    Installs argocd with ingress enabled by default and puts admin pass in a
    password manager, currently only bitwarden is supported
    arg:
      k8s_obj:                K8s() object with the kubernetes context
      bitwarden:              BwCLI() object, defaults to None
      plugin_secret_creation: boolean for creating the plugin secret generator
      secret_dict:            set of secrets to create for secret plugin
    """
    header("Checking [green]Argo CD[/green] status, for managing your k8s apps",
           "🦑")

    namespace = argocd_config_dict['argo']['namespace']
    # this is needed for helm but also setting argo to use the current k8s context
    argocd_domain = argocd_config_dict['hostnames']['argocd']

    # immediately start building helm object to check if helm release exists
    release_dict = {"release_name": "argo-cd", "namespace": namespace}
    release = Helm.chart(**release_dict)

    if not release.check_existing():
        sub_header("Looks like Argo CD isn't installed, let's remedy that :)")
        # this is the base python dict for the values.yaml that is created below
        val = {"fullnameOverride": "argo-cd",
               "global": {"domain": argocd_domain},
               "dex": {"enabled": False},
               "configs": {
                   "secret": {"argocdServerAdminPassword": ""}
                   },
               "server": {
                   "ingress": {
                       "enabled": True,
                       "hostname": argocd_domain,
                       "annotations": {
                           "nginx.ingress.kubernetes.io/backend-protocol": "HTTPS",
                           "nginx.ingress.kubernetes.io/ssl-passthrough": "true",
                       },
                       "ingressClassName": "nginx",
                       "https": True,
                       "tls":  [{"secretName": "argocd-secret",
                                 "hosts": [argocd_domain]}]}}}

        # TODO: add this to dict if debug logging is enabled for smol-k8s-lab:
        # "global": {"logging": {"level": "debug"}}

        if secret_dict.get('global_cluster_issuer', None):
            val['server']['ingress']['annotations']['cert-manager.io/cluster-issuer'] = secret_dict['global_cluster_issuer']

        # if we're using bitwarden, generate a password & save it
        argo_password = create_password()
        if bitwarden:
            sub_header(":lock: Creating a new password in BitWarden.")
            # if we're using bitwarden...
            bitwarden.create_login(name="argo-cd-admin-credentials",
                                   item_url=argocd_domain,
                                   user="admin",
                                   password=argo_password)

        admin_pass = bcrypt.hashpw(argo_password.encode('utf-8'),
                                   bcrypt.gensalt()).decode()

        # this gets passed to the helm cli, but is bcrypted
        val['configs']['secret']['argocdServerAdminPassword'] = admin_pass

        # this creates a values.yaml from the val dict above
        values_file_name = path.join(XDG_CACHE_DIR, 'argocd_values.yaml')
        with open(values_file_name, 'w') as values_file:
            yaml.dump(val, values_file)

        release_dict['values_file'] = values_file_name
        release_dict['chart_name'] = 'argo-cd/argo-cd'

        release = Helm.chart(**release_dict)
        release.install(wait=True)
    else:
        sub_header("Looks like Argo CD is installed 🎉")

    if bitwarden:
        secrets_backend = "bitwarden"
    else:
        secrets_backend = ""

    # handle setting up the globals dict
    globals_dict = {}
    for key, value in secret_dict.items():
        if key.startswith("global_"):
            globals_dict[key.replace("global_", "")] = value

    argocd = ArgoCD(namespace,
                    argocd_domain,
                    k8s_obj,
                    globals_dict,
                    secrets_backend)

    # verify if we're doing a full init (meaning we use a smol-app)
    init_enabled = argocd_config_dict.get('init', {}).get("enabled", False)

    # if the app is already installed, make sure it has the right credentials
    if argocd.check_if_app_exists('argo-cd') and init_enabled:
        secret_dicts = refresh_bitwarden(argocd_domain, bitwarden)
        argocd_config_dict['externalSecrets'] = {'bitwarden': secret_dicts[0]}
        argocd_config_dict['oidc'] = secret_dicts[1]
        argocd.install_init_app("argo-cd", argocd_config_dict, 4)

    # install the appset secret plugin generator if we're using that
    special_argocd_dict = argocd_config_dict.get("argocd", {})
    enable_appset_secret_plugin = special_argocd_dict.get(
            "enable_appset_secret_plugin", False)
    if init_enabled and enable_appset_secret_plugin:
        configure_secret_plugin_generator(argocd,
                                          argocd_config_dict,
                                          secret_dict)
    return argocd


def refresh_bitwarden(argocd_domain: str,
                      bitwarden: BwCLI,
                      zitadel_domain: str = "") -> [dict, dict]:
    """
    refresh all our bitwarden credentials in memory
    """
    argo_oidc_item = bitwarden.get_item(
            f'argo-cd-oidc-credentials-{argocd_domain}', False)[0]
    argo_admin_item = bitwarden.get_item(
            f'argo-cd-admin-credentials-{argocd_domain}', False)[0]['id']

    bitwarden_dict = {"oidcCredentials": argo_oidc_item['id'],
                      "adminCredentials": argo_admin_item}

    # section for configuring zitadel
    # we shouldn't need to clientID after this is fixed:
    # https://github.com/argoproj/argo-cd/issues/14899
    oidc_dict = {"baseUrl": argo_oidc_item['fields'][0]['value'],
                 "clientID": argo_oidc_item['login']['username']}

    return bitwarden_dict, oidc_dict


def configure_secret_plugin_generator(argocd: ArgoCD,
                                      argocd_config: dict,
                                      secret_dict: dict) -> None:
    """
    configures the applicationset secret plugin generator

    (._. ) <-- who are they?
    """
    if not argocd.check_if_app_exists('appset-secrets-plugin'):
        # creates the secret vars secret with all the key/values for each appset
        argocd.k8s.create_secret('appset-secret-vars', 'argocd', secret_dict,
                                 'secret_vars.yaml')

        msg = "🔌 Installing the ApplicationSet Secret Plugin Generator for Argo CD..."
        sub_header(msg)

        # creates only the token for authentication
        token = create_password()
        argocd.k8s.create_secret('appset-secret-token', 'argocd', {'token': token})

        # this creates a values.yaml from this dict
        set_opts = {'secretVars.existingSecret': 'appset-secret-vars',
                    'token.existingSecret': 'appset-secret-token'}

        # install the helm chart :)
        release = Helm.chart(
                release_name='appset-secret-plugin',
                chart_name='codeberg.org/appset-secret-plugin',
                namespace='argocd',
                set_options=set_opts
                )
        release.install(wait=True)
    else:
        log.info("Reloading deployment for Argo CD Appset Secret Plugin")
        argocd.update_appset_secret(secret_dict, update_bitwarden=False)
