"""
       Name: configure_certmanager
DESCRIPTION: helm install, and optionally configure, certmanager
     AUTHOR: @jessebot
    LICENSE: GNU AFFERO GENERAL PUBLIC LICENSE Version 3
"""
from smol_k8s_lab.bitwarden.bw_cli import BwCLI
from smol_k8s_lab.k8s_tools.helm import Helm
from smol_k8s_lab.k8s_tools.argocd_util import ArgoCD
from smol_k8s_lab.k8s_tools.k8s_lib import K8s
from smol_k8s_lab.utils.rich_cli.console_logging import header
import logging as log


def configure_certmanager(k8s_obj: K8s,
                          certmanager_dict: dict,
                          argocd_enabled: bool = True) -> None:
    """
    Installs cert-manager helm chart and optionally creates letsencrypt acme
    ClusterIssuers for both staging and production if email_addr is passed in
    """
    # immediately exit if certmanager is not enabled
    if not certmanager_dict.get('enabled', False):
        log.debug("Certmanager not enabled.")
        return

    # manager SSL/TLS certificates via lets-encrypt
    header("Installing [green]cert-manager[/green] for TLS certificates...", '📜')
    # install chart and wait
    release = Helm.chart(release_name='cert-manager',
                         chart_name='jetstack/cert-manager',
                         namespace='cert-manager',
                         set_options={'installCRDs': 'true',
                                      'config.featureGates.ACMEHTTP01IngressPathTypeExact': 'false'
                                      })
    release.install(wait=True)

    if not argocd_enabled:
        create_cluster_issuers(certmanager_dict, k8s_obj)


def create_cluster_issuers(certmanager_dict: dict,
                           k8s_obj: K8s = None,
                           argocd: ArgoCD = None,
                           bw: BwCLI = None) -> None:
    """
    create ClusterIssuers for cert manager
    """
    init = certmanager_dict['init']
    # if init insn't enabled, exit immediately
    if not init.get('enabled', False):
        return

    header("Initializing [green]cert-manager[/green] issuers", '📜')
    init_values = init.get('values', {})
    solver = init_values.get('cluster_issuer_acme_challenge_solver',
                             "http01").lower()
    if solver == "dns01":
        log.error("We currently don't support a DNS provider for the ACME "
                  "issuer type in cert-manager. If you'd like to see a provider"
                  " supported, please submit a PR and we'll take a look!")
    else:
        challenge = {'ingress': {'class': 'nginx'}}

    log.info("Creating ClusterIssuers for staging and production.")

    # we create a ClusterIssuer for both staging and prod
    acme_staging = "https://acme-staging-v02.api.letsencrypt.org/directory"
    private_key_ref = "letsencrypt-staging"

    for issuer in ['letsencrypt-staging', 'letsencrypt-prod']:
        if issuer == "letsencrypt-prod":
            acme_staging = acme_staging.replace("staging-", "")
            private_key_ref = private_key_ref.replace("-staging", "-prod")

        issuers_dict = {
            'apiVersion': "cert-manager.io/v1",
            'kind': 'ClusterIssuer',
            'metadata': {'name': issuer},
            'spec': {
                'acme': {
                    'email':  init_values['email'],
                    'server': acme_staging,
                    'privateKeySecretRef': {'name': private_key_ref},
                    'solvers': [{solver: challenge}]
                    }
                }
            }

        # backup plan till above issue is resolved
        k8s_obj.apply_custom_resources([issuers_dict])
