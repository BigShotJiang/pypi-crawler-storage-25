"""
       Name: nginx_ingress_controller
DESCRIPTION: install the nginx ingress controller
     AUTHOR: @jessebot
    LICENSE: GNU AFFERO GENERAL PUBLIC LICENSE Version 3
"""
# internal libraries
from smol_k8s_lab.k8s_tools.helm import Helm
from smol_k8s_lab.k8s_tools.k8s_lib import K8s
from smol_k8s_lab.utils.rich_cli.console_logging import header


def configure_ingress_nginx(k8s_obj: K8s,
                            k8s_distro: str,
                            ingress_dict: dict) -> None:
    """
    install nginx ingress controller from manifests for kind and helm for k3s
    """
    # return immediately if
    if not ingress_dict.get('enabled', False):
        return

    header("Installing [green]ingress-nginx-controller[/green] to access "
           "web apps outside the cluster", "🌐")

    url = ('https://raw.githubusercontent.com/kubernetes/ingress-nginx/main/'
           'deploy/static/provider/kind/deploy.yaml')

    if k8s_distro == 'kind':
        # this is to wait for the deployment to come up
        k8s_obj.apply_manifests(
                manifest_file_name=url,
                namespace="ingress-nginx",
                deployment="ingress-nginx-controller",
                selector="app.kubernetes.io/component=controller"
                )
    else:
        values = {"controller.allowSnippetAnnotations": True}
        release = Helm.chart(release_name='ingress-nginx',
                             chart_name='ingress-nginx/ingress-nginx',
                             namespace='ingress-nginx',
                             set_options=values)
        release.install()
