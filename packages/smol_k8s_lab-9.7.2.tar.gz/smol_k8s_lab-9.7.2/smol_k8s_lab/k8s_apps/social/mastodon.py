# internal libraries
from smol_k8s_lab.bitwarden.bw_cli import BwCLI, create_custom_field
from smol_k8s_lab.k8s_apps.social.mastodon_secrets import generate_mastodon_secrets
from smol_k8s_lab.k8s_tools.argocd_util import ArgoCD
from smol_k8s_lab.k8s_tools.external_secrets import CreateCredentials
from smol_k8s_lab.k8s_tools.restores import Restore
from smol_k8s_lab.utils.passwords import create_password
from smol_k8s_lab.utils.rich_cli.console_logging import sub_header, header
from smol_k8s_lab.utils.run.subproc import subproc
from smol_k8s_lab.utils.value_from import extract_secret

# external libraries
import logging as log


async def configure_mastodon(argocd: ArgoCD,
                             cfg: dict,
                             pvc_storage_class: str,
                             libretranslate_api_key: str = "",
                             bitwarden: BwCLI = BwCLI("test", "test", "test")
                             ) -> bool:
    """
    creates a mastodon app and initializes it with secrets if you'd like :)

    required:
        argocd                 - ArgoCD() object for Argo CD operations
        cfg                    - dict, with at least argocd key and init key
        pvc_storage_class      - str, storage class of PVC
        libretranslate_api_key - str, api key to enable automatic translations

    optional:
        bitwarden - BwCLI() object with session token to create bitwarden items
    """
    # check immediately if the app is installed
    app_installed = argocd.check_if_app_exists('mastodon')

    # verify if initialization is enabled
    init = cfg.get('init', {'enabled': True, 'restore': {'enabled': False}})
    init_enabled = init.get('enabled', True)

    # check if we're restoring and get values for that
    restore_dict = init.get('restore', {"enabled": False})
    restore_enabled = restore_dict['enabled']

    # figure out what header to print
    if restore_enabled:
        header_start = "Restoring"
    else:
        if app_installed:
            header_start = "Syncing [green]Mastodon[/]"
        else:
            header_start = "Setting up [green]Mastodon[/]"

    header(f"{header_start}, so you can self host your social media",
           '🐘')

    # get any secrets for this app
    hostname = cfg['hostnames']['mastodon']
    libretranslate_hostname = cfg['hostnames']['libretranslate']

    # we need namespace immediately
    mastodon_namespace = cfg['argo']['namespace']

    if init_enabled:
        # declare custom values for mastodon
        init_values = init.get('values', None)

        # get the api key for LibreTranslate, so we can translate posts
        libre_api_key = extract_secret(
                init_values.get('libretranslate_api_key'))
        if not libre_api_key:
            libre_api_key = libretranslate_api_key

        if not app_installed:
            argocd.k8s.create_namespace(mastodon_namespace)

            if not restore_enabled:
                # main mastodon rake secrets
                rake_secrets = generate_mastodon_secrets()

                if bitwarden:
                    setup_bitwarden_items(cfg,
                                          hostname,
                                          rake_secrets,
                                          libretranslate_hostname,
                                          libre_api_key,
                                          argocd,
                                          bitwarden)

                # these are standard k8s secrets yaml
                elif not bitwarden:
                    # mastodon rake secrets
                    argocd.k8s.create_secret('mastodon-server-secrets',
                                             'mastodon',
                                             rake_secrets)

                argocd.install_init_app('mastodon', cfg, 4, True)
                # configure the admin user credentials
                admin_username = cfg['admin'].get('user', 'tootadmin')
                admin_email = cfg['admin'].get('email', '')
                password = create_user(admin_username,
                                       admin_email,
                                       cfg['argo']['namespace'])
                if bitwarden:
                    sub_header("Creating secrets in Bitwarden")
                    bitwarden.create_login(
                            name='mastodon-admin-credentials',
                            item_url=hostname,
                            user=admin_username,
                            password=password,
                            fields=[create_custom_field("email", admin_email)])

            # restore enabled
            else:
                if bitwarden:
                    bw_ids = refresh_bweso(
                            argocd,
                            hostname,
                            libretranslate_hostname,
                            libre_api_key,
                            bitwarden)
                    cfg['externalSecrets'] = {'bitwarden': bw_ids}

                Restore("mastodon",
                        argocd,
                        hostname,
                        mastodon_namespace,
                        cfg,
                        pvc_storage_class,
                        True,
                        bitwarden)
                return

    if not app_installed:
        if not init_enabled:
            argocd.install_app('mastodon', cfg['argo'])
    else:
        log.info("mastodon already installed 🎉")

        if bitwarden and init_enabled:
            bw_ids = refresh_bweso(argocd,
                                   hostname,
                                   libretranslate_hostname,
                                   libre_api_key,
                                   bitwarden)
            cfg['externalSecrets'] = {'bitwarden': bw_ids}


def create_user(user: str, email: str, pod_namespace: str) -> str:
    """
    given a username, email, and namespace of the mastodon pod, we'll create a
    new mastodon user via tootctl using a kubectl exec command and then we
    return their autogenerated password
    """
    sub_header(f"Creating a mastodon user for: {user}")
    # first, go get the exact name of the pod we need to exec a command on
    pod_cmd = (
            f"kubectl get pods -n {pod_namespace} "
            "-l app.kubernetes.io/instance=mastodon-web-app,"
            "app.kubernetes.io/component=web"
            " --no-headers "
            "-o custom-columns=NAME:.metadata.name"
            )
    pod = subproc([pod_cmd]).rstrip()
    log.info(f"Mastodon web app pod is: {pod}")

    # then run the user creation command
    cmd = (f'kubectl exec -n {pod_namespace} {pod} -- /bin/bash -c '
           f'"bin/tootctl accounts create {user} --email {email} --confirmed '
           '--role Owner"')

    # then process the output from the command and return it
    res = subproc([cmd],
                  shell=True,
                  universal_newlines=True).split()[3]
    print(f"password returned is: {res}")
    return res


def setup_bitwarden_items(cfg: dict,
                          hostname: str,
                          rake_secrets: dict,
                          libretranslate_hostname: str,
                          libre_api_key: str,
                          argocd: ArgoCD,
                          bitwarden: BwCLI) -> None:

    creds_creator = CreateCredentials("mastodon",
                                      cfg,
                                      None,
                                      bitwarden,
                                      argocd)
    return_dict = creds_creator.create_all_credentials()

    pgsql_s3_key = create_password()
    s3_db_id = bitwarden.create_login(
            name='mastodon-postgres-s3-credentials',
            item_url=hostname,
            user="mastodon-postgres",
            password=pgsql_s3_key)

    # elastic search password
    mastodon_elasticsearch_password = bitwarden.generate()
    elastic_id = bitwarden.create_login(
            name='mastodon-elasticsearch-credentials',
            item_url=hostname,
            user='mastodon',
            password=mastodon_elasticsearch_password)

    # mastodon secrets
    secret_key_base_obj = create_custom_field("SECRET_KEY_BASE",
                                              rake_secrets['SECRET_KEY_BASE'])
    otp_secret_obj = create_custom_field("OTP_SECRET",
                                         rake_secrets['OTP_SECRET'])
    vapid_pub_key_obj = create_custom_field("VAPID_PUBLIC_KEY",
                                            rake_secrets['VAPID_PUBLIC_KEY'])
    vapid_priv_key_obj = create_custom_field("VAPID_PRIVATE_KEY",
                                             rake_secrets['VAPID_PRIVATE_KEY'])
    active_record_encryption_deterministic_obj = create_custom_field(
            "ACTIVE_RECORD_ENCRYPTION_DETERMINISTIC_KEY",
            rake_secrets['ACTIVE_RECORD_ENCRYPTION_DETERMINISTIC_KEY'])
    active_record_encryption_derivation_obj = create_custom_field(
            "ACTIVE_RECORD_ENCRYPTION_KEY_DERIVATION_SALT",
            rake_secrets['ACTIVE_RECORD_ENCRYPTION_KEY_DERIVATION_SALT'])
    active_record_encryption_primary_obj = create_custom_field(
            "ACTIVE_RECORD_ENCRYPTION_PRIMARY_KEY",
            rake_secrets['ACTIVE_RECORD_ENCRYPTION_PRIMARY_KEY'])

    secrets_id = bitwarden.create_login(
            name='mastodon-server-secrets',
            item_url=hostname,
            user="mastodon",
            password="none",
            fields=[secret_key_base_obj,
                    otp_secret_obj,
                    vapid_priv_key_obj,
                    vapid_pub_key_obj,
                    active_record_encryption_primary_obj,
                    active_record_encryption_derivation_obj,
                    active_record_encryption_deterministic_obj])

    endpoint = create_custom_field('endpoint', libretranslate_hostname)
    libretranslate_api_key_id = bitwarden.create_login(
            name=f'mastodon-libretranslate-credentials-{hostname}',
            item_url=libretranslate_hostname,
            user="n/a",
            password=libre_api_key,
            fields=[endpoint])

    # reload the bitwarden ESO provider
    try:
        argocd.k8s.reload_deployment('bitwarden-eso-provider',
                                     'external-secrets')
    except Exception as e:
        log.error("Couldn't scale down the [magenta]bitwarden-eso-provider"
                  "[/] deployment in [green]external-secrets[/] namespace."
                  f"Recieved: {e}")

    return_dict['s3PostgresCredentials'] = s3_db_id
    return_dict['elasticsearchCredentials'] = elastic_id
    return_dict['libretranslateApiKey'] = libretranslate_api_key_id
    return_dict['mastodonSecrets'] = secrets_id

    return return_dict


def refresh_bweso(argocd: ArgoCD,
                  hostname: str,
                  libretranslate_hostname: str,
                  libre_api_key: str,
                  bitwarden: BwCLI) -> dict:
    """
    if mastodon already installed, but bitwarden and init are enabled, still
    populate the bitwarden IDs in memory
    """
    log.debug("Making sure mastodon Bitwarden item IDs are memory")

    bw_items = bitwarden.list_items(hostname)

    # admin_id = bw_items[f"mastodon-admin-credentials-{hostname}"]

    db_id = bw_items[f"mastodon-pgsql-credentials-{hostname}"]

    elastic_id = bw_items[f"mastodon-elasticsearch-credentials-{hostname}"]

    valkey_id = bw_items[f"mastodon-valkey-credentials-{hostname}"]

    smtp_id = bw_items[f"mastodon-smtp-credentials-{hostname}"]

    s3_admin_id = bw_items[f"mastodon-admin-s3-credentials-{hostname}"]

    s3_db_id = bw_items[f"mastodon-postgres-s3-credentials-{hostname}"]

    s3_id = bw_items[f"mastodon-user-s3-credentials-{hostname}"]

    s3_backups_id = bw_items[f"mastodon-backups-s3-credentials-{hostname}"]

    secrets_id = bw_items[f"mastodon-server-secrets-{hostname}"]

    # checking here since this isn't required and so it may not be available
    libretranslate_api_key_item = bitwarden.get_item(
            f"mastodon-libretranslate-credentials-{hostname}", False
            )[0]
    if libretranslate_api_key_item:
        libretranslate_api_key_id = libretranslate_api_key_item.get('id', "")
    else:
        endpoint = create_custom_field('endpoint', libretranslate_hostname)
        libretranslate_api_key_id = bitwarden.create_login(
                name=f'mastodon-libretranslate-credentials-{hostname}',
                item_url=libretranslate_hostname,
                user="n/a",
                password=libre_api_key,
                fields=[endpoint]
                )

    # {'mastodon_admin_credentials_bitwarden_id': admin_id,
    return {'smtpCredentials': smtp_id,
            'postgresCredentials': db_id,
            'valkeyCredentials': valkey_id,
            's3AdminCredentials': s3_admin_id,
            's3PostgresCredentials': s3_db_id,
            's3AppCredentials': s3_id,
            's3BackupCredentials': s3_backups_id,
            'elasticsearchCredentials': elastic_id,
            'libretranslateApiKey': libretranslate_api_key_id,
            'mastodonSecrets': secrets_id}
