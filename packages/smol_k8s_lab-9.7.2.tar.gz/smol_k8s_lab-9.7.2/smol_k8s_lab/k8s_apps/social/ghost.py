# internal libraries
from smol_k8s_lab.bitwarden.bw_cli import BwCLI
from smol_k8s_lab.k8s_apps.identity_provider.zitadel_api import Zitadel
from smol_k8s_lab.k8s_tools.argocd_util import ArgoCD
from smol_k8s_lab.k8s_tools.restores import Restore
from smol_k8s_lab.k8s_tools.external_secrets import CreateCredentials
from smol_k8s_lab.utils.rich_cli.console_logging import header

# external libraries
import asyncio
import logging as log


async def configure_ghost(
        argocd: ArgoCD,
        cfg: dict,
        pvc_storage_class: str,
        zitadel: Zitadel,
        bitwarden: BwCLI = BwCLI("test", "test", "test")) -> bool:
    """
    creates a ghost app and initializes it with secrets if you'd like :)

    required:
        argocd                 - ArgoCD() object for Argo CD operations
        cfg                    - dict, with at least argocd key and init key
        pvc_storage_class      - str, storage class of PVC

    optional:
        zitadel   - Zitadel() object to create zitadel oidc app and roles
        bitwarden - BwCLI() object with session token to create bitwarden items
    """
    # check immediately if the app is installed
    app_installed = argocd.check_if_app_exists('ghost')

    # verify if initialization is enabled
    init = cfg.get('init', {'enabled': True, 'restore': {'enabled': False}})
    init_enabled = init.get('enabled', True)

    # check if we're restoring and get values for that
    restore_dict = init.get('restore', {"enabled": False})
    restore_enabled = restore_dict['enabled']

    print_header(restore_enabled, app_installed)

    # get any secrets for this app
    hostname = cfg['hostnames']['ghost']

    # we need namespace immediately
    ghost_namespace = cfg['argo']['namespace']
    if bitwarden:
        cfg['externalSecrets'] = {'provider': 'bitwarden'}

    if init_enabled and not app_installed:
        argocd.k8s.create_namespace(ghost_namespace)
        if bitwarden and not restore_enabled:
            creds_creator = CreateCredentials("ghost",
                                              cfg,
                                              zitadel,
                                              bitwarden,
                                              argocd)
            externalSecrets = creds_creator.create_all_credentials()
            cfg['externalSecrets']['bitwarden'] = externalSecrets

    if not app_installed:
        if restore_enabled:
            # first we grab existing bitwarden items if they exist
            if bitwarden:
                externalSecrets = refresh_bweso(argocd, hostname, bitwarden)
                cfg['externalSecrets']['bitwarden'] = externalSecrets
            Restore("ghost",
                    argocd,
                    hostname,
                    ghost_namespace,
                    cfg,
                    pvc_storage_class,
                    False,
                    bitwarden)

        if not init_enabled:
            argocd.install_app('ghost', cfg['argo'])
        elif init_enabled and not restore_enabled:
            argocd.install_init_app('ghost', cfg, 4, True)
    else:
        log.info("ghost already installed 🎉")

        if bitwarden and init_enabled:
            externalSecrets = refresh_bweso(argocd, hostname, bitwarden)
            cfg['externalSecrets']['bitwarden'] = externalSecrets
            argocd.install_init_app('ghost', cfg, 4, True)


def refresh_bweso(argocd: ArgoCD, hostname: str, bitwarden: BwCLI) -> dict:
    """
    if ghost already installed, but bitwarden and init are enabled, still
    populate the bitwarden IDs in memory
    """
    log.debug("Making sure ghost Bitwarden item IDs are in memory")
    bw_items = bitwarden.list_items(hostname)

    oidc_id = bw_items[f"ghost-oidc-credentials-{hostname}"]

    admin_id = bw_items[f"ghost-admin-credentials-{hostname}"]

    db_id = bw_items[f"ghost-mysql-credentials-{hostname}"]

    smtp_id = bw_items[f"ghost-smtp-credentials-{hostname}"]

    s3_backups_id = bw_items[f"ghost-backups-s3-credentials-{hostname}"]

    return {
        'ghost_smtp_credentials_bitwarden_id': smtp_id,
        'ghost_oidc_credentials_bitwarden_id': oidc_id,
        'ghost_mysql_credentials_bitwarden_id': db_id,
        'ghost_admin_credentials_bitwarden_id': admin_id,
        'ghost_s3_backups_credentials_bitwarden_id': s3_backups_id}


def print_header(restore_enabled: bool, app_installed: bool) -> None:
    """
    figure out what header to print and print it
    """
    if restore_enabled:
        header_start = "Restoring [green]ghost[/]"
    else:
        if app_installed:
            header_start = "Syncing [green]ghost[/]"
        else:
            header_start = "Setting up [green]ghost[/]"

    header(f"{header_start}, so you can self host your own blogging platform",
           '👻')
