# internal libraries
from smol_k8s_lab.bitwarden.bw_cli import BwCLI, create_custom_field
from smol_k8s_lab.k8s_apps.identity_provider.zitadel_api import Zitadel
from smol_k8s_lab.k8s_tools.argocd_util import ArgoCD
from smol_k8s_lab.k8s_tools.external_secrets import CreateCredentials
from smol_k8s_lab.k8s_tools.restores import Restore
from smol_k8s_lab.utils.passwords import create_password
from smol_k8s_lab.utils.rich_cli.console_logging import sub_header, header
from smol_k8s_lab.utils.run.subproc import subproc

# external libraries
import asyncio
import logging as log


async def configure_gotosocial(
        argocd: ArgoCD,
        cfg: dict,
        pvc_storage_class: str,
        zitadel: Zitadel,
        bitwarden: BwCLI = BwCLI("test", "test", "test")) -> bool:
    """
    creates a gotosocial app and initializes it with secrets if you'd like :)

    required:
        argocd                 - ArgoCD() object for Argo CD operations
        cfg                    - dict, with at least argocd key and init key
        pvc_storage_class      - str, storage class of PVC

    optional:
        zitadel   - Zitadel() object to create zitadel oidc app and roles
        bitwarden - BwCLI() object with session token to create bitwarden items
    """
    # check immediately if the app is installed
    app_installed = argocd.check_if_app_exists('gotosocial')

    # verify if initialization is enabled
    init = cfg.get('init', {'enabled': True, 'restore': {'enabled': False}})
    init_enabled = init.get('enabled', True)

    # check if we're restoring and get values for that
    restore_dict = init.get('restore', {"enabled": False})
    restore_enabled = restore_dict['enabled']

    # figure out what header to print
    if restore_enabled:
        header_start = "Restoring"
    else:
        if app_installed:
            header_start = "Syncing [green]gotosocial[/]"
        else:
            header_start = "Setting up [green]gotosocial[/]"

    header(f"{header_start}, so you can self host your social media", '🦥')

    # get any secrets for this app
    hostname = cfg['hostnames']['gotosocial']

    # we need namespace immediately
    gotosocial_namespace = cfg['argo']['namespace']

    if init_enabled:
        # configure OIDC
        if zitadel:
            cfg['oidc'] = {"baseUrl": zitadel.hostname}

        if bitwarden:
            cfg['externalSecrets'] = {'provider': 'bitwarden'}

        if not app_installed:
            argocd.k8s.create_namespace(gotosocial_namespace)

            if not restore_enabled:
                if bitwarden:
                    creds_creator = CreateCredentials("gotosocial",
                                                      cfg,
                                                      zitadel,
                                                      bitwarden,
                                                      argocd)
                    bw_ids = creds_creator.create_all_credentials()
                    cfg['externalSecrets'] = {'bitwarden': bw_ids}

                # install gotosocial
                argocd.install_init_app('gotosocial', cfg, 4, True)

                # wait for all gotosocial apps to come up, give it extra time
                argocd.sync_app(app='gotosocial-web-app', sleep_time=4)
                argocd.wait_for_app('gotosocial-web-app')

                # create admin credentials
                password = create_user(cfg['admin']['user'],
                                       cfg['admin']['email'],
                                       cfg['argo']['namespace'])
                if bitwarden:
                    e_obj = create_custom_field("email", cfg['admin']['email'])
                    sub_header("Creating secrets in Bitwarden")
                    bitwarden.create_login(
                            name='gotosocial-admin-credentials',
                            item_url=hostname,
                            user=cfg['admin']['user'],
                            password=password,
                            fields=[e_obj])

            else:
                # first we grab existing bitwarden items if they exist
                if bitwarden:
                    bw_ids = refresh_bweso(argocd, hostname, bitwarden)
                    cfg['externalSecrets'] = {'bitwarden': bw_ids}

                Restore("gotosocial",
                        argocd,
                        hostname,
                        gotosocial_namespace,
                        cfg,
                        pvc_storage_class,
                        True,
                        bitwarden)
    else:
        argocd.install_app('gotosocial', cfg['argo'])

    if app_installed:
        # first we grab existing bitwarden items if they exist
        if bitwarden:
            external_secret_items = refresh_bweso(argocd, hostname, bitwarden)
            cfg['externalSecrets'] = {'bitwarden': external_secret_items}
            argocd.install_init_app('gotosocial', cfg, 4, True)


def create_user(user: str, email: str, pod_namespace: str) -> str:
    """
    given a username, email, and namespace of the gotosocial pod, we'll create
    a new gotosocial user using a kubectl exec command and then we return
    their autogenerated password
    """
    sub_header(f"Creating a GoToSocial user for: {user}")
    # first, go get the exact name of the pod we need to exec a command on
    pod_cmd = (
            f"kubectl get pods -n {pod_namespace} "
            "-l app.kubernetes.io/instance=gotosocial-web-app,"
            "app.kubernetes.io/component=web"
            " --no-headers "
            "-o custom-columns=NAME:.metadata.name"
            )
    pod = subproc([pod_cmd]).rstrip()
    log.info(f"gotosocial web app pod is: {pod}")

    # generate a random password
    password = create_password()

    # then run the user creation command
    cmd = (f'kubectl exec -n {pod_namespace} {pod} -- /bin/sh -c "./gotosocial'
           ' --config-path ../config/config.yaml admin account create '
           f'--username {user} --email {email} --password \'{password}\'"')

    # then process the output from the command
    subproc([cmd], shell=True, universal_newlines=True)

    # then run the user promotion (to admin) command
    cmd = (f'kubectl exec -n {pod_namespace} {pod} -- /bin/sh -c '
           '"./gotosocial --config-path ../config/config.yaml admin '
           f'account promote --username {user}"')

    # then process the output from the command
    subproc([cmd], shell=True, universal_newlines=True).split()[3]

    return password


def refresh_bweso(argocd: ArgoCD, hostname: str, bitwarden: BwCLI) -> dict:
    """
    if gotosocial already installed, but bitwarden and init are enabled, still
    populate the bitwarden IDs in the appset secret plugin secret
    """
    log.debug("Making sure gotosocial Bitwarden item IDs are in memory")
    bw_items = bitwarden.list_items(hostname)

    oidc_id = bw_items[f"gotosocial-oidc-credentials-{hostname}"]

    db_id = bw_items[f"gotosocial-pgsql-credentials-{hostname}"]

    smtp_id = bw_items[f"gotosocial-smtp-credentials-{hostname}"]

    s3_admin_id = bw_items[f"gotosocial-admin-s3-credentials-{hostname}"]

    s3_db_id = bw_items[f"gotosocial-postgres-s3-credentials-{hostname}"]

    s3_id = bw_items[f"gotosocial-user-s3-credentials-{hostname}"]

    s3_backups_id = bw_items[f"gotosocial-backups-s3-credentials-{hostname}"]

    # {'s3AdminCredentials': admin_id,
    return {'smtpCredentials': smtp_id,
            'oidcCredentials': oidc_id,
            'postgresqlCredentials': db_id,
            's3AdminCredentials': s3_admin_id,
            's3PostgresCredentials': s3_db_id,
            's3AppCredentials': s3_id,
            's3BackupCredentials': s3_backups_id}
