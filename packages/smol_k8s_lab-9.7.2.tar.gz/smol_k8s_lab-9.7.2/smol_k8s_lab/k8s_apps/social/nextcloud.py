# internal libraries
from smol_k8s_lab.bitwarden.bw_cli import BwCLI, create_custom_field
from smol_k8s_lab.k8s_apps.operators.minio import create_minio_alias
from smol_k8s_lab.k8s_apps.identity_provider.zitadel_api import Zitadel
from smol_k8s_lab.k8s_apps.social.nextcloud_occ_commands import Nextcloud
from smol_k8s_lab.k8s_tools.argocd_util import ArgoCD
from smol_k8s_lab.k8s_tools.restores import Restore
from smol_k8s_lab.utils.passwords import create_password
from smol_k8s_lab.utils.rich_cli.console_logging import sub_header, header
from smol_k8s_lab.utils.run.subproc import subproc
from smol_k8s_lab.utils.value_from import extract_secret, process_backup_vals

# external libraries
import asyncio
import logging as log
from rich.prompt import Prompt


async def configure_nextcloud(
        argocd: ArgoCD,
        cfg: dict,
        pvc_storage_class: str,
        zitadel: Zitadel,
        bitwarden: BwCLI = BwCLI("test","test","test")
        ) -> None:
    """
    creates a nextcloud app and initializes it with secrets if you'd like :)

    required:
        argocd            - ArgoCD() object for Argo CD operations
        cfg               - dict, with at least argocd key and init key
        pvc_storage_class - str, storage class of PVC

    optional:
        zitadel     - Zitadel() object with session token to create zitadel oidc app and roles
        bitwarden   - BwCLI() object with session token to create bitwarden items
    """
    # check immediately if this app is installed
    app_installed = argocd.check_if_app_exists('nextcloud')

    hostname = cfg['hostnames']['nextcloud']
    collabora_hostname = cfg['hostnames'].get('collabora', 'example.com')

    # verify if initialization is enabled
    init = cfg.get('init', {'enabled': True, 'restore': {'enabled': False}})
    init_enabled = init.get('enabled', True)

    # check if we're restoring and get values for that
    restore_dict = init.get('restore', {"enabled": False})
    restore_enabled = restore_dict['enabled']

    # figure out what header to print
    if restore_enabled:
        header_start = "Restoring"
    else:
        if app_installed:
            header_start = "Syncing"
        else:
            header_start = "Setting up"

    header(f"{header_start} [green]Nextcloud[/], to self host your files",
           '🩵')

    if init_enabled:
        # backups are their own config.yaml section
        backup_vals = process_backup_vals(cfg.get('backups', {}))

        # grab all possile init values
        init_values = init.get('values', None)

        # collabora config values
        collabora_user = init_values.get('collabora_user', None)
        collabora_pass = extract_secret(init_values.get('collabora_password',
                                                        create_password))

    # if the user has chosen to use smol-k8s-lab initialization
    if not app_installed and init_enabled:
        nextcloud_namespace = cfg['argo']['namespace']
        argocd.k8s.create_namespace(nextcloud_namespace)

        if init_values:
            admin_user = init_values.get('admin_user', 'admin')

            # stmp config values
            mail_host = init_values.get('smtp_host', None)
            mail_user = init_values.get('smtp_user', None)
            mail_pass = extract_secret(init_values.get('smtp_password', ""))

        else:
            log.warn("Strange, there's no nextcloud init values...")

        s3_endpoint = cfg['s3'].get('endpoint', "")
        if s3_endpoint and not restore_enabled:
            s3_access_key = create_password()
            # create a local alias to check and make sure nextcloud is functional
            create_minio_alias(minio_alias="nextcloud",
                               minio_hostname=s3_endpoint,
                               access_key="nextcloud",
                               secret_key=s3_access_key)

        # configure SMTP
        if not mail_host:
            mail_host = Prompt.ask(
                    "[green]Please enter the SMTP host for nextcoud"
                    )

        if not mail_user:
            m = f"[green]Please enter an SMTP user for Nextcloud on server, {mail_host}"
            mail_user = Prompt.ask(m)

        if not mail_pass:
            m = f"[green]Please enter the SMTP password of {mail_user} on {mail_host}"
            mail_pass = Prompt.ask(m, password=True)

        # configure OIDC
        if zitadel:
            zitadel_hostname = "https://" + zitadel.hostname
        else:
            zitadel_hostname = ""

        cfg['zitadel_hostname'] = zitadel_hostname

        if zitadel and not restore_enabled:
            log.debug("Creating a Nextcloud OIDC application in Zitadel...")
            redirect_uris = f"https://{hostname}/apps/oidc_login/oidc"
            logout_uris = [f"https://{hostname}"]
            oidc_creds = zitadel.create_application(
                    "nextcloud",
                    redirect_uris,
                    logout_uris
                    )
            zitadel.create_role("nextcloud_users",
                                "Nextcloud Users",
                                "nextcloud_users")
            zitadel.create_role("nextcloud_admins",
                                "Nextcloud Admins",
                                "nextcloud_admins")
            zitadel.update_user_grant(['nextcloud_admins'])

        # if bitwarden is enabled, we create login items for each set of credentials
        if bitwarden and not restore_enabled:
            external_secrets = setup_bitwarden_items(argocd,
                                  hostname,
                                  collabora_hostname,
                                  s3_endpoint,
                                  s3_access_key,
                                  backup_vals['s3']['access_key_id'],
                                  backup_vals['s3']['secret_access_key'],
                                  backup_vals['restic_repo_pass'],
                                  admin_user,
                                  collabora_user,
                                  collabora_pass,
                                  mail_host,
                                  mail_user,
                                  mail_pass,
                                  oidc_creds,
                                  zitadel_hostname,
                                  bitwarden)
            cfg['externalSecrets'] = external_secrets

        # these are standard k8s secrets
        elif not bitwarden and not restore_enabled:
            # nextcloud admin credentials and smtp credentials
            token = create_password()
            admin_password = create_password()
            argocd.k8s.create_secret('nextcloud-admin-credentials', 'nextcloud',
                                     {"username": admin_user,
                                      "password": admin_password,
                                      "serverInfoToken": token,
                                      "smtpHost": mail_host,
                                      "smtpUsername": mail_user,
                                      "smtpPassword": mail_pass})

            # postgres db credentials creation
            argocd.k8s.create_secret(
                    'nextcloud-pgsql-credentials',
                    'nextcloud',
                    {"username": 'nextcloud',
                     "password": 'we-use-tls-instead-of-password'}
                    )

            # redis credentials creation
            nextcloud_redis_password = create_password()
            argocd.k8s.create_secret('nextcloud-redis-credentials', 'nextcloud',
                                     {"password": nextcloud_redis_password})

            # s3 credentials creation
            argocd.k8s.create_secret('nextcloud-s3-credentials', 'nextcloud',
                                     {"accessKeyId": "nextcloud",
                                      "secretAccessKey": s3_access_key,
                                      "S3_ENDPOINT": s3_endpoint})

    if not app_installed:
        if restore_enabled:
            # if the user is restoring, the process is a little different
            if init_enabled:
                if bitwarden:
                    external_secrets = refresh_bweso(
                            argocd,
                            hostname,
                            collabora_hostname,
                            collabora_user,
                            collabora_pass,
                            bitwarden)
                    cfg['externalSecrets'] = external_secrets

            Restore("nextcloud",
                    argocd,
                    hostname,
                    nextcloud_namespace,
                    cfg,
                    pvc_storage_class,
                    True,
                    bitwarden)

            # verify nextcloud rolled out completely, just in case
            rollout = (f"kubectl rollout status -n {nextcloud_namespace} "
                       "deployment/nextcloud-web-app --watch --timeout 10m")
            while True:
                rolled_out = subproc([rollout], error_ok=True)
                if "NotFound" not in rolled_out:
                    break

            # try to update the maintenance mode of nextcloud to off
            nextcloud_obj = Nextcloud(argocd.k8s, nextcloud_namespace)
            nextcloud_obj.set_maintenance_mode("off")
        else:
            if init_enabled:
                argocd.install_init_app('nextcloud', cfg, 4, True)
            else:
                argocd.install_app('nextcloud', cfg['argocd'])
    else:
        log.info("nextcloud already installed 🎉")
        if init_enabled:
            if bitwarden:
                external_secrets = refresh_bweso(
                        argocd,
                        hostname,
                        collabora_hostname,
                        collabora_user,
                        collabora_pass,
                        bitwarden)
                cfg['externalSecrets'] = external_secrets
            argocd.install_init_app('nextcloud', cfg, 4, True)

def setup_bitwarden_items(argocd: ArgoCD,
                          hostname: str,
                          collabora_hostname: str,
                          s3_endpoint: str,
                          s3_access_key: str,
                          backups_s3_user: str,
                          backups_s3_password: str,
                          restic_repo_pass: str,
                          admin_user: str,
                          collabora_user: str,
                          collabora_pass: str,
                          mail_host: str,
                          mail_user: str,
                          mail_pass: str,
                          oidc_creds: dict,
                          zitadel_hostname: str,
                          bitwarden: BwCLI) -> dict:
    """
    setup all the bitwarden items for nextcloud external secrets to be populated
    """
    sub_header("Creating Nextcloud items in Bitwarden")

    # s3 credentials creation
    bucket_obj = create_custom_field('bucket', "nextcloud-data")
    endpoint_obj = create_custom_field('endpoint', s3_endpoint)
    s3_id = bitwarden.create_login(
            name='nextcloud-user-s3-credentials',
            item_url=hostname,
            user="nextcloud",
            password=s3_access_key,
            fields=[bucket_obj, endpoint_obj]
            )

    pgsql_s3_key = create_password()
    s3_db_id = bitwarden.create_login(
            name='nextcloud-postgres-s3-credentials',
            item_url=hostname,
            user="nextcloud-postgres",
            password=pgsql_s3_key
            )

    admin_s3_key = create_password()
    s3_admin_id = bitwarden.create_login(
            name='nextcloud-admin-s3-credentials',
            item_url=hostname,
            user="nextcloud-root",
            password=admin_s3_key
            )

    # credentials for remote backups of the s3 PVC
    restic_repo_pass_obj = create_custom_field("resticRepoPassword", restic_repo_pass)
    s3_backups_id = bitwarden.create_login(
            name='nextcloud-backups-s3-credentials',
            item_url=hostname,
            user=backups_s3_user,
            password=backups_s3_password,
            fields=[restic_repo_pass_obj]
            )

    # oidc credentials if they were given, else they're probably already there
    if oidc_creds:
        log.debug("Creating OIDC credentials for Nextcloud in Bitwarden...")
        issuer_obj = create_custom_field("issuer", zitadel_hostname)
        oidc_id = bitwarden.create_login(
                name='nextcloud-oidc-credentials',
                item_url=hostname,
                user=oidc_creds['client_id'],
                password=oidc_creds['client_secret'],
                fields=[issuer_obj]
                )
    else:
        oidc_id = bitwarden.get_item(
                f"nextcloud-oidc-credentials-{hostname}"
                )[0]['id']

    # admin credentials + metrics server info token
    token = bitwarden.generate()
    admin_password = bitwarden.generate()
    serverinfo_token_obj = create_custom_field("serverInfoToken", token)
    admin_id = bitwarden.create_login(
            name='nextcloud-admin-credentials',
            item_url=hostname,
            user=admin_user,
            password=admin_password,
            fields=[serverinfo_token_obj]
            )

    # collabora admin credentials for initial owner user
    collabora_admin_id = bitwarden.create_login(
            name=f'collabora-admin-credentials-{collabora_hostname}',
            item_url=collabora_hostname,
            user=collabora_user,
            password=collabora_pass
            )

    # smtp credentials
    smtpHost = create_custom_field("hostname", mail_host)
    smtp_id = bitwarden.create_login(
            name='nextcloud-smtp-credentials',
            item_url=hostname,
            user=mail_user,
            password=mail_pass,
            fields=[smtpHost]
            )

    # postgres db credentials creation
    db_id = bitwarden.create_login(
            name='nextcloud-pgsql-credentials',
            item_url=hostname,
            user='nextcloud',
            password='we-dont-use-the-password-anymore-we-use-tls'
            )

    # redis credentials creation
    nextcloud_redis_password = bitwarden.generate()
    redis_id = bitwarden.create_login(
            name='nextcloud-redis-credentials',
            item_url=hostname,
            user='nextcloud',
            password=nextcloud_redis_password
            )

    return_dict = {
            'adminCredentials': admin_id,
            'oidcCredentials': oidc_id,
            'smtpCredentials': smtp_id,
            'postgresCredentials': db_id,
            'valkeyCredentials': redis_id,
            's3AdminCredentials': s3_admin_id,
            's3PostgresCredentials': s3_db_id,
            's3AppCredentials': s3_id,
            's3BackupCredentials': s3_backups_id,
            'collaboraCredentials': collabora_admin_id}

    return {"bitwarden": return_dict}


def refresh_bweso(argocd: ArgoCD,
                  hostname: str,
                  collabora_hostname: str,
                  collabora_user: str,
                  collabora_pass: str,
                  bitwarden: BwCLI) -> dict:
    """
    if bitwarden and init are enabled, but app is already installed, make sure
    nextcloud bitwarden item IDs are in memory
    """
    log.debug("Making sure nextcloud Bitwarden item IDs are in memory")
    bw_items = bitwarden.list_items(hostname)

    oidc_id = bw_items[f"nextcloud-oidc-credentials-{hostname}"]

    admin_id = bw_items[f"nextcloud-admin-credentials-{hostname}"]

    collabora_admin_id = bw_items.get(
            f"collabora-admin-credentials-{collabora_hostname}", "")

    if not collabora_admin_id:
        # collabora admin credentials for initial owner user
        collabora_admin_id = bitwarden.create_login(
                name=f'collabora-admin-credentials-{collabora_hostname}',
                item_url=collabora_hostname,
                user=collabora_user,
                password=collabora_pass
                )

    smtp_id = bw_items[f"nextcloud-smtp-credentials-{hostname}"]

    db_id = bw_items[f"nextcloud-pgsql-credentials-{hostname}"]

    redis_id = bw_items[f"nextcloud-redis-credentials-{hostname}"]

    s3_admin_id = bw_items[f"nextcloud-admin-s3-credentials-{hostname}"]

    s3_db_id = bw_items[f"nextcloud-postgres-s3-credentials-{hostname}"]

    s3_id = bw_items[f"nextcloud-user-s3-credentials-{hostname}"]

    s3_backups_id = bw_items[f"nextcloud-backups-s3-credentials-{hostname}"]

    return_dict = {
            'adminCredentials': admin_id,
            'oidcCredentials': oidc_id,
            'smtpCredentials': smtp_id,
            'postgresCredentials': db_id,
            'valkeyCredentials': redis_id,
            's3AdminCredentials': s3_admin_id,
            's3PostgresCredentials': s3_db_id,
            's3AppCredentials': s3_id,
            's3BackupCredentials': s3_backups_id,
            'collaboraCredentials': collabora_admin_id}

    return {"bitwarden": return_dict}
