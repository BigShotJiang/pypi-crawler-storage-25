# function for creating the initial home assistant user

# internal libraries
from smol_k8s_lab.bitwarden.bw_cli import BwCLI
from smol_k8s_lab.k8s_tools.argocd_util import ArgoCD
from smol_k8s_lab.k8s_tools.external_secrets import CreateCredentials
from smol_k8s_lab.k8s_tools.restores import Restore
from smol_k8s_lab.utils.rich_cli.console_logging import header

# external libraries
import asyncio
import logging as log


async def configure_home_assistant(
        argocd: ArgoCD,
        cfg: dict,
        pvc_storage_class: str,
        api_tls_verify: bool = False,
        bitwarden: BwCLI = BwCLI("test", "test", "test")
        ) -> None:
    """
    creates a home-assistant app and initializes it with secrets :)

    required:
        argocd  - ArgoCD() object for argo operations
        cfg     - dictionary with at least argocd key and init key

    optional:
        bitwarden - BwCLI() object with session token to create bitwarden items
    """
    # check immediately if this app is installed
    app_installed = argocd.check_if_app_exists('home-assistant')

    # get the hostname we're using, if any
    hostname = cfg.get('hostnames', {}).get('home_assistant',
                                            'iot.example.com')

    # verify if initialization is enabled
    init_enabled = cfg['init']['enabled']

    # process restore dict
    restore_dict = cfg['init'].get('restore', {"enabled": False})
    restore_enabled = restore_dict['enabled']
    if restore_enabled:
        header_start = "Restoring"
    else:
        if app_installed:
            header_start = "Syncing [green]home-assistant[/]"
        else:
            header_start = "Setting up [green]home-assistant[/]"

    header(f"{header_start}, to self host your home automation", '🏡')

    # we need namespace no matter the install type
    home_assistant_namespace = cfg['argo']['namespace']

    if bitwarden:
        cfg['externalSecrets'] = {'provider': 'bitwarden'}

    # if the user has chosen to use smol-k8s-lab initialization
    if not app_installed and init_enabled:
        # immediately create namespace
        argocd.k8s.create_namespace(home_assistant_namespace)

        # if bitwarden is enabled, we create login items for each credential
        if bitwarden and not restore_enabled:
            externalSecrets = CreateCredentials(
                    "home-assistant",
                    cfg,
                    None,
                    bitwarden,
                    argocd).create_all_credentials()
            cfg['externalSecrets']['bitwarden'] = externalSecrets

    if init_enabled and restore_enabled:
        if bitwarden:
            externalSecrets = refresh_bitwarden(argocd, hostname, bitwarden)
            cfg['externalSecrets']['bitwarden'] = externalSecrets

        Restore("home-assistant",
                argocd,
                hostname,
                home_assistant_namespace,
                cfg,
                pvc_storage_class,
                False,
                bitwarden)

    if not app_installed:
        if init_enabled:
            argocd.install_init_app('home-assistant', cfg, 4, True)
        else:
            # then install the app as normal
            argocd.install_app('home-assistant', cfg['argo'])
    else:
        if init_enabled:
            externalSecrets = refresh_bitwarden(argocd, hostname, bitwarden)
            cfg['externalSecrets']['bitwarden'] = externalSecrets
            argocd.install_init_app('home-assistant', cfg, 4, True)
        log.info("home-assistant already installed 🎉")


def refresh_bitwarden(argocd: ArgoCD, hostname: str, bitwarden: BwCLI) -> dict:
    """
    refresh bitwardens item in memory
    """
    log.debug("Making sure home-assistant Bitwarden item IDs are in memory")

    bw_items = bitwarden.list_items(hostname)

    admin_id = bw_items[f"home-assistant-admin-credentials-{hostname}"]
    s3_backup_id = bw_items[
            f"home-assistant-backups-s3-credentials-{hostname}"]

    return {'adminCredentials': admin_id, 's3BackupsCredentials': s3_backup_id}
