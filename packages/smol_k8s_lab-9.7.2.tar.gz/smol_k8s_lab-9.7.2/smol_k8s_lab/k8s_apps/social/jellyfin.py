# internal libraries
from smol_k8s_lab.bitwarden.bw_cli import BwCLI, create_custom_field
from smol_k8s_lab.k8s_tools.argocd_util import ArgoCD
from smol_k8s_lab.k8s_tools.restores import Restore
from smol_k8s_lab.utils.rich_cli.console_logging import sub_header, header
from smol_k8s_lab.utils.value_from import process_backup_vals

# external libraries
import asyncio
import logging as log


async def configure_jellyfin(
        argocd: ArgoCD,
        cfg: dict,
        pvc_storage_class: str,
        bitwarden: BwCLI = BwCLI("test","test","test")
        ) -> None:
    """
    creates a jellyfin app and initializes it with secrets if you'd like :)

    required:
        argocd            - ArgoCD() object for Argo CD operations
        cfg               - dict, with at least argocd key and init key
        pvc_storage_class - str, storage class of PVC

    optional:
        bitwarden   - BwCLI() object with session token to create bitwarden items
    """
    # check immediately if this app is installed
    app_installed = argocd.check_if_app_exists('jellyfin')

    hostname = cfg['hostnames']['jellyfin']

    # verify if initialization is enabled
    init = cfg.get('init', {'enabled': True, 'restore': {'enabled': False}})
    init_enabled = init.get('enabled', True)

    # check if we're restoring and get values for that
    restore_dict = init.get('restore', {"enabled": False})
    restore_enabled = restore_dict['enabled']

    # figure out what header to print
    if restore_enabled:
        header_start = "Restoring"
    else:
        if app_installed:
            header_start = "Syncing"
        else:
            header_start = "Setting up"

    header(f"{header_start} [green]Jellyfin[/], your home media server", '🪼')

    if init_enabled:
        # backups are their own config.yaml section
        backup_vals = process_backup_vals(cfg.get('backups', {}))
        if bitwarden:
            cfg['externalSecrets'] = {"provider": "bitwarden"}

    # if the user has chosen to use smol-k8s-lab initialization
    if not app_installed:
        if init_enabled:
            jellyfin_namespace = cfg['argo']['namespace']
            argocd.k8s.create_namespace(jellyfin_namespace)

            # if bitwarden is enabled, we create login items for each set of credentials
            if bitwarden and not restore_enabled:
                cfg['externalSecrets']['bitwarden'] = setup_bitwarden_items(
                        argocd,
                        hostname,
                        backup_vals['s3']['access_key_id'],
                        backup_vals['s3']['secret_access_key'],
                        backup_vals['restic_repo_pass'],
                        bitwarden)

        # if the user is restoring, the process is a little different
        if init_enabled and restore_enabled:
            if bitwarden:
                cfg['externalSecrets']['bitwarden'] = refresh_bweso(argocd,
                                                                    hostname,
                                                                    bitwarden)
            Restore("jellyfin",
                    argocd,
                    hostname,
                    jellyfin_namespace,
                    cfg,
                    pvc_storage_class,
                    ['media', 'config'],
                    False,
                    bitwarden)
        else:
            if init_enabled:
                argocd.install_init_app('jellyfin', cfg, 4)
            else:
                argocd.install_app('jellyfin', cfg['argo'])
    else:
        log.info("jellyfin already installed 🎉")
        if init_enabled:
            if bitwarden:
                cfg['externalSecrets']['bitwarden'] = refresh_bweso(argocd,
                                                                    hostname,
                                                                    bitwarden)
            argocd.install_init_app('jellyfin', cfg, 4)


def setup_bitwarden_items(argocd: ArgoCD,
                          hostname: str,
                          backups_s3_user: str,
                          backups_s3_password: str,
                          restic_repo_pass: str,
                          bitwarden: BwCLI) -> dict:
    """
    setup all the bitwarden items for jellyfin external secrets to be populated
    """
    sub_header("Creating jellyfin items in Bitwarden")

    # credentials for remote backups of the s3 PVC
    restic_repo_pass_obj = create_custom_field("resticRepoPassword", restic_repo_pass)
    s3_backups_id = bitwarden.create_login(
            name='jellyfin-backups-s3-credentials',
            item_url=hostname,
            user=backups_s3_user,
            password=backups_s3_password,
            fields=[restic_repo_pass_obj]
            )

    return {'s3BackupCredentials': s3_backups_id}


def refresh_bweso(argocd: ArgoCD, hostname: str, bitwarden: BwCLI) -> dict:
    """
    if bitwarden and init are enabled, but app is already installed, make sure
    current bitwarden item id is in memory
    """
    log.debug("Making sure jellyfin Bitwarden item IDs are in appset "
              "secret plugin secret")

    s3_backups_id = bitwarden.get_item(
            f"jellyfin-backups-s3-credentials-{hostname}", False
            )[0]['id']

    return {'s3BackupCredentials': s3_backups_id}
