# internal libraries
from smol_k8s_lab.bitwarden.bw_cli import BwCLI, create_custom_field
# from smol_k8s_lab.k8s_apps.operators.minio import create_minio_alias
from smol_k8s_lab.k8s_apps.identity_provider.zitadel_api import Zitadel
from smol_k8s_lab.k8s_tools.argocd_util import ArgoCD
from smol_k8s_lab.k8s_tools.restores import Restore
from smol_k8s_lab.k8s_tools.external_secrets import CreateCredentials
from smol_k8s_lab.utils.passwords import create_password
from smol_k8s_lab.utils.rich_cli.console_logging import sub_header, header
from smol_k8s_lab.utils.run.subproc import subproc

# external libraries
import asyncio
import logging as log


async def configure_writefreely(
        argocd: ArgoCD,
        cfg: dict,
        pvc_storage_class: str,
        zitadel: Zitadel,
        bitwarden: BwCLI = BwCLI("test", "test", "test")
        ) -> bool:
    """
    creates a writefreely app and initializes it with secrets if you'd like :)

    required:
        argocd                 - ArgoCD() object for Argo CD operations
        cfg                    - dict, with at least argocd key and init key
        pvc_storage_class      - str, storage class of PVC

    optional:
        zitadel   - Zitadel() to create zitadel oidc app and roles
        bitwarden - BwCLI() object with session token to create bitwarden items
    """
    # check immediately if the app is installed
    app_installed = argocd.check_if_app_exists('writefreely')

    # verify if initialization is enabled
    init = cfg.get('init', {'enabled': True, 'restore': {'enabled': False}})
    init_enabled = init.get('enabled', True)

    # check if we're restoring and get values for that
    restore_dict = init.get('restore', {"enabled": False})
    restore_enabled = restore_dict['enabled']

    # figure out what header to print
    if restore_enabled:
        header_start = "Restoring"
    else:
        if app_installed:
            header_start = "Syncing"
        else:
            header_start = "Setting up"

    header_full = (f"{header_start} [green]writefreely[/], so you can self "
                   "host your own blogging platform")
    header(header_full, '👻')

    # get any secrets for this app
    hostname = cfg['hostnames']['writefreely']

    # we need namespace immediately
    writefreely_namespace = cfg['argo']['namespace']

    if init_enabled:
        # configure OIDC
        if zitadel:
            zitadel_hostname = zitadel.hostname
        else:
            zitadel_hostname = ""
        cfg['odic'] = {"baseUrl": zitadel_hostname}

        # configure bitwarden
        if bitwarden:
            cfg['externalSecrets'] = {"provider": "bitwarden"}

    if init_enabled and not app_installed:
        argocd.k8s.create_namespace(writefreely_namespace)

        if bitwarden and not restore_enabled:
            creds_creator = CreateCredentials("writefreely",
                                              cfg,
                                              zitadel,
                                              bitwarden,
                                              argocd)
            bw_ids = creds_creator.create_all_credentials()
            cfg['externalSecrets']['bitwarden'] = bw_ids

    if not app_installed:
        if restore_enabled:
            # first we grab existing bitwarden items if they exist
            if bitwarden:
                refresh_bweso(argocd, hostname, bitwarden)
            Restore("writefreely",
                    argocd,
                    hostname,
                    writefreely_namespace,
                    cfg,
                    pvc_storage_class,
                    ['mysql'],
                    True,
                    bitwarden)

        if not init_enabled:
            argocd.install_app('writefreely', cfg['argo'])
        elif init_enabled and not restore_enabled:
            argocd.install_app('writefreely', cfg['argo'], True)
            # wait for all the writefreely apps to come up, give it extra time
            argocd.sync_app(app='writefreely-web-app', sleep_time=4)
            argocd.wait_for_app('writefreely-web-app')

            # create admin credentials
            password = create_user(cfg['admin']['user'],
                                   cfg['admin']['email'],
                                   cfg['argo']['namespace'])
            if bitwarden:
                sub_header("Creating secrets in Bitwarden")
                bitwarden.create_login(
                        name='writefreely-admin-credentials',
                        item_url=hostname,
                        user=cfg['admin']['user'],
                        password=password,
                        fields=[create_custom_field("email",
                                                    cfg['admin']['email'])])
    else:
        log.info("writefreely already installed 🎉")

        if bitwarden and init_enabled:
            refresh_bweso(argocd, hostname, bitwarden)


def create_user(user: str, email: str, pod_namespace: str) -> str:
    """
    given a username, email, and namespace of the writefreely pod, we'll create
    a new writefreely user using a kubectl exec command and then we return
    their autogenerated password
    """
    sub_header(f"Creating a writefreely user for: {user}")
    # first, go get the exact name of the pod we need to exec a command on
    pod_cmd = (
            f"kubectl get pods -n {pod_namespace} "
            "-l app.kubernetes.io/instance=writefreely-web-app,"
            "app.kubernetes.io/component=web"
            " --no-headers "
            "-o custom-columns=NAME:.metadata.name")
    pod = subproc([pod_cmd]).rstrip()
    log.info(f"writefreely web app pod is: {pod}")

    # generate a random password
    password = create_password()

    # then run the user creation command
    cmd = (f'kubectl exec -n {pod_namespace} {pod} -- /bin/sh -c'
           '"./writefreely --config-path ../config/config.yaml '
           'admin account create '
           f'--username {user} --email {email} --password \'{password}\'"')

    # then process the output from the command
    subproc([cmd], shell=True, universal_newlines=True)

    # then run the user promotion (to admin) command
    cmd = (f'kubectl exec -n {pod_namespace} {pod} -- /bin/sh -c '
           '"./writefreely --config-path ../config/config.yaml admin '
           f'account promote --username {user}"')

    # then process the output from the command
    subproc([cmd], shell=True, universal_newlines=True).split()[3]

    return password


def refresh_bweso(argocd: ArgoCD,
                  hostname: str,
                  bitwarden: BwCLI) -> dict:
    """
    if writefreely already installed, but bitwarden and init are enabled, still
    populate the bitwarden IDs in the appset secret plugin secret
    """
    log.debug("Making sure writefreely Bitwarden item IDs are in appset "
              "secret plugin secret")

    oidc_id = bitwarden.get_item(
            f"writefreely-oidc-credentials-{hostname}"
            )[0]['id']

    admin_id = bitwarden.get_item(
            f"writefreely-admin-credentials-{hostname}", False
            )[0]['id']

    db_id = bitwarden.get_item(
            f"writefreely-mysql-credentials-{hostname}", False
            )[0]['id']

    smtp_id = bitwarden.get_item(
            f"writefreely-smtp-credentials-{hostname}", False
            )[0]['id']

    s3_admin_id = bitwarden.get_item(
            f"writefreely-admin-s3-credentials-{hostname}", False
            )[0]['id']

    s3_id = bitwarden.get_item(
            f"writefreely-user-s3-credentials-{hostname}", False
            )[0]['id']

    s3_backups_id = bitwarden.get_item(
            f"writefreely-backups-s3-credentials-{hostname}", False
            )[0]['id']

    return {'smtpCredentials': smtp_id,
            'oidcCredentials': oidc_id,
            'mysqlCredentials': db_id,
            'adminCredentials': admin_id,
            's3AdminCredentials': s3_admin_id,
            's3AppCredentials': s3_id,
            's3BackupsCredentials': s3_backups_id}
