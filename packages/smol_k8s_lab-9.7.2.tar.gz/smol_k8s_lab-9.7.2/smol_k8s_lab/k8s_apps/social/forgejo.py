# internal libraries
from smol_k8s_lab.bitwarden.bw_cli import BwCLI
from smol_k8s_lab.k8s_apps.identity_provider.zitadel_api import Zitadel
from smol_k8s_lab.k8s_tools.argocd_util import ArgoCD
from smol_k8s_lab.k8s_tools.restores import Restore
from smol_k8s_lab.k8s_tools.external_secrets import CreateCredentials
from smol_k8s_lab.utils.rich_cli.console_logging import header
from smol_k8s_lab.utils.value_from import process_backup_vals

# external libraries
import logging as log


class ConfigureForgejo():
    def __init__(self,
                 argocd: ArgoCD,
                 cfg: dict,
                 pvc_storage_class: str,
                 zitadel: Zitadel,
                 bitwarden: BwCLI = BwCLI("test", "test", "test")) -> bool:
        """
        creates a forgejo app and initializes it with secrets if you'd like :)

        required:
            argocd              - ArgoCD() object for Argo CD operations
            cfg                 - dict, with at least argocd key and init key
            pvc_storage_class   - str, storage class of PVC

        optional:
            zitadel   - Zitadel() object with session token to create zitadel
                        oidc app and roles
            bitwarden - BwCLI() object to create bitwarden items
        """
        self.cfg = cfg
        self.hostname = cfg['hostnames']['forgejo']
        self.namespace = cfg['argo']['namespace']
        self.argocd = argocd
        self.zitadel = zitadel
        self.bitwarden = bitwarden
        # check immediately if the app is installed
        self.app_installed = argocd.check_if_app_exists('forgejo')

        # verify if initialization is enabled
        init = cfg.get('init', {'enabled': True,
                                'restore': {'enabled': False}})
        self.init_enabled = init.get('enabled', True)

        # check if we're restoring and get values for that
        restore_dict = init.get('restore', {"enabled": False})
        restore_enabled = restore_dict['enabled']

        # figure out what header to print
        if restore_enabled:
            header_start = "Restoring"
        else:
            if self.app_installed:
                header_start = "Syncing [green]forgejo[/]"
            else:
                header_start = "Setting up [green]forgejo[/]"

        header(f"{header_start}, to self host your own git server", '🦊')

        if self.init_enabled:
            # declare custom values for forgejo
            self.init_values = init.get('values', None)

            # backups are their own config.yaml section
            self.backup_vals = process_backup_vals(cfg.get('backups', {}))

            # for future oidc stuff
            if zitadel:
                self.zitadel_hostname = "https://" + zitadel.hostname
            else:
                log.debug("forgejo is not using zitadel 🤔")
                self.zitadel_hostname = ""

            log.debug(f"zitadel_hostname is set to {self.zitadel_hostname}")

            self.cfg['oidc'] = {'baseUrl': self.zitadel_hostname}

        if self.app_installed or restore_enabled:
            # first we grab existing bitwarden items if they exist
            if bitwarden:
                external_secret_items = self.refresh_bweso()
                self.cfg['externalSecrets'] = {
                        'bitwarden': external_secret_items}

        if self.init_enabled and not self.app_installed:
            if not restore_enabled:
                self.install_forgejo()
            else:
                Restore("forgejo",
                        self.argocd,
                        self.hostname,
                        self.namespace,
                        self.cfg,
                        pvc_storage_class,
                        True,
                        bitwarden)

        if self.app_installed:
            if self.init_enabled:
                log.info("Syncing forgejo with latest values")
                argocd.install_init_app('forgejo', cfg, 4, True)
            else:
                log.info("forgejo already installed 🎉")

    def install_forgejo(self):
        """
        do everything needed for a forgejo install
        """
        self.argocd.k8s.create_namespace(self.namespace)

        if self.bitwarden:
            creds_creator = CreateCredentials("forgejo",
                                              self.cfg,
                                              self.zitadel,
                                              self.bitwarden,
                                              self.argocd)
            external_secret_items = creds_creator.create_all_credentials()
            self.cfg['externalSecrets'] = {'bitwarden': external_secret_items}

        if self.init_enabled:
            self.argocd.install_init_app('forgejo', self.cfg, 4, True)
            # wait for all the forgejo apps to come up, give it extra time
            self.argocd.sync_app(app='forgejo-web-app', sleep_time=4)
            self.argocd.wait_for_app('forgejo-web-app')
        else:
            self.argocd.install_app('forgejo', self.cfg['argo'])

    def refresh_bweso(self) -> dict:
        """
        if forgejo already installed, but bitwarden and init are enabled, still
        populate the bitwarden IDs in memory
        """
        log.debug("Making sure forgejo Bitwarden item IDs available in memory")

        bw_items = self.bitwarden.list_items(self.hostname)

        oidc_id = bw_items[f"forgejo-oidc-credentials-{self.hostname}"]

        admin_id = bw_items[f"forgejo-admin-credentials-{self.hostname}"]

        db_id = bw_items[f"forgejo-pgsql-credentials-{self.hostname}"]

        valkey_id = bw_items[f"forgejo-valkey-credentials-{self.hostname}"]

        smtp_id = bw_items[f"forgejo-smtp-credentials-{self.hostname}"]

        s3_admin_id = bw_items[f"forgejo-admin-s3-credentials-{self.hostname}"]

        s3_db_id = bw_items[f"forgejo-postgres-s3-credentials-{self.hostname}"]

        s3_id = bw_items[f"forgejo-user-s3-credentials-{self.hostname}"]

        s3_backups_id = bw_items[
                f"forgejo-backups-s3-credentials-{self.hostname}"]

        # update the forgejo external secret bitwrden ID values
        return {'smtpCredentials': smtp_id,
                'oidcCredentials': oidc_id,
                'postgresCredentials': db_id,
                'valkeyCredentials': valkey_id,
                'adminCredentials': admin_id,
                's3AdminCredentials': s3_admin_id,
                's3PostgresCredentials': s3_db_id,
                's3ForgejoCredentials': s3_id,
                's3BackupCredentials': s3_backups_id}
