# internal libraries
from smol_k8s_lab.bitwarden.bw_cli import BwCLI, create_custom_field
from smol_k8s_lab.k8s_apps.identity_provider.zitadel_api import Zitadel
from smol_k8s_lab.k8s_apps.networking.headscale_secrets import generate_headscale_secrets
from smol_k8s_lab.k8s_tools.argocd_util import ArgoCD
from smol_k8s_lab.k8s_tools.restores import Restore
from smol_k8s_lab.utils.rich_cli.console_logging import header, sub_header
from smol_k8s_lab.utils.run.subproc import subproc
from smol_k8s_lab.utils.value_from import process_backup_vals

# external libraries
import logging as log


class ConfigureHeadscale():
    def __init__(self,
                 argocd: ArgoCD,
                 cfg: dict,
                 pvc_storage_class: str,
                 zitadel: Zitadel,
                 bitwarden: BwCLI = BwCLI("test", "test", "test")) -> bool:
        """
        creates a headscale app and initializes it with secrets if you'd like!

        required:
            argocd               - ArgoCD() object for Argo CD operations
            cfg                  - dict, with at least argocd key and init key
            pvc_storage_class    - str, storage class of PVC

        optional:
            zitadel    - Zitadel() object with session token to create zitadel
                         oidc app and roles
            bitwarden  - BwCLI() with session token to create bitwarden items
        """
        self.cfg = cfg
        self.hostname = cfg['hostnames']['headscale']
        self.namespace = cfg['argo']['namespace']
        self.argocd = argocd
        self.zitadel = zitadel
        self.bitwarden = bitwarden
        # check immediately if the app is installed
        self.app_installed = argocd.check_if_app_exists('headscale')

        # verify if initialization is enabled
        init = cfg.get('init',
                       {'enabled': True, 'restore': {'enabled': False}})
        self.init_enabled = init.get('enabled', True)
        self.users = init.get("values", {}).get("users", {})

        # check if we're restoring and get values for that
        restore_dict = init.get('restore', {"enabled": False})
        restore_enabled = restore_dict['enabled']

        # figure out what header to print
        if restore_enabled:
            header_start = "Restoring"
        else:
            if self.app_installed:
                header_start = "Syncing"
            else:
                header_start = "Setting up"

        header(f"{header_start} [green]headscale[/], so you can self host your own git server",
               '🦊')

        if self.init_enabled:
            # declare custom values for headscale
            self.init_values = init.get('values', None)

            # backups are their own config.yaml section
            self.backup_vals = process_backup_vals(cfg.get('backups', {}))

            # for future oidc stuff
            if zitadel:
                self.zitadel_hostname = zitadel.hostname
            else:
                log.debug("headscale is not using zitadel 🤔")
                self.zitadel_hostname = ""

            log.debug(f"zitadel_hostname is set to {self.zitadel_hostname}")

            self.cfg['oidc'] = {'baseUrl': self.zitadel_hostname}

        if self.app_installed or restore_enabled:
            # first we grab existing bitwarden items if they exist
            if bitwarden:
                external_secret_items = self.refresh_bweso()
                self.cfg['externalSecrets'] = {
                        'bitwarden': external_secret_items}

        if self.init_enabled and not self.app_installed:
            if not restore_enabled:
                self.install_headscale()

        if restore_enabled and not self.app_installed:
            Restore("headscale",
                    self.argocd,
                    self.hostname,
                    self.namespace,
                    self.cfg,
                    pvc_storage_class,
                    True,
                    bitwarden)

        if self.app_installed:
            if self.init_enabled:
                log.info("Syncing headscale with latest values")
                argocd.install_init_app('headscale', cfg, 4, True)
            else:
                log.info("headscale already installed 🎉")

    def install_headscale(self):
        """
        do everything needed for a headscale install
        """
        self.argocd.k8s.create_namespace(self.namespace)

        # configure OIDC
        if self.zitadel:
            log.debug("Creating a headscale OIDC application in Zitadel...")
            redirect_uris = f"https://{self.hostname}/oidc/callback"
            logout_uris = [f"https://{self.hostname}"]
            oidc_creds = self.zitadel.create_application(
                    "headscale",
                    redirect_uris,
                    logout_uris
                    )
            self.zitadel.create_role("headscale_users",
                                     "headscale Users",
                                     "headscale_users")
            self.zitadel.create_role("headscale_admins",
                                     "headscale Admins",
                                     "headscale_admins")
            self.zitadel.update_user_grant(['headscale_admins'])

        if self.bitwarden:
            headscale_secrets = generate_headscale_secrets()
            external_secret_items = self.setup_bitwarden_items(
                    self.backup_vals['s3']['access_key_id'],
                    self.backup_vals['s3']['secret_access_key'],
                    self.backup_vals['restic_repo_pass'],
                    headscale_secrets,
                    oidc_creds)
            self.cfg['externalSecrets'] = {'bitwarden': external_secret_items}

        self.argocd.install_init_app('headscale', self.cfg, 4, True)
        # wait for all the headscale apps to come up, give it extra time
        self.argocd.sync_app(app='headscale-web-app', sleep_time=4)
        self.argocd.wait_for_app('headscale-web-app')

        # create any initial users so we can use the vpn immediately
        if self.users:
            for user in self.users:
                self.create_user(user['name'], user['email'], user['display_name'])

    def refresh_bweso(self) -> dict:
        """
        if headscale already installed, but bitwarden and init are enabled,
        still populate the bitwarden IDs in memory
        """
        log.debug("Making sure headscale Bitwarden item IDs available in mem")

        bw_items = self.bitwarden.list_items(self.hostname)

        oidc_id = bw_items[f"headscale-oidc-credentials-{self.hostname}"]

        s3_backups_id = bw_items[
                f"headscale-backups-s3-credentials-{self.hostname}"]

        # coturn_id = bw_items[f"headscale-coturn-credentials-{self.hostname}"]

        encryption_id = bw_items[f"headscale-encryption-keys-{self.hostname}"]

        # update the headscale external secret bitwrden ID values
        return {'oidcCredentials': oidc_id,
                'encryptionCredentials': encryption_id,
                's3BackupCredentials': s3_backups_id}

    def setup_bitwarden_items(self,
                              backups_s3_user: str,
                              backups_s3_password: str,
                              restic_repo_pass: str,
                              headscale_secrets: dict,
                              oidc_creds: dict) -> dict:
        """
        setup secrets in bitwarden for headscale.
        """
        # coturn credentials for headscale
        # coturn_password = create_password()
        # coturn_id = self.bitwarden.create_login(
        #         name='headscale-coturn-credentials',
        #         item_url=self.hostname,
        #         user="headscale",
        #         password=coturn_password,
        #         fields=[]
        #         )

        # credentials for remote backups of the s3 PVC
        restic_repo_pass_obj = create_custom_field("resticRepoPassword",
                                                   restic_repo_pass)
        s3_backups_id = self.bitwarden.create_login(
                name='headscale-backups-s3-credentials',
                item_url=self.hostname,
                user=backups_s3_user,
                password=backups_s3_password,
                fields=[restic_repo_pass_obj]
                )

        # headscale relay and data store encryption credentials
        wg_key_obj = create_custom_field("wireguard",
                                         headscale_secrets['wireguard_key'])
        noise_key_obj = create_custom_field("noise",
                                            headscale_secrets['noise_key'])
        derp_key_obj = create_custom_field("derp",
                                           headscale_secrets['derp_key'])
        encryption_id = self.bitwarden.create_login(
                name='headscale-encryption-keys',
                item_url=self.hostname,
                user="headscale",
                password="beepboop",
                fields=[wg_key_obj, noise_key_obj, derp_key_obj]
                )

        # oidc credentials if they were given, else probably already there
        if oidc_creds:
            log.debug("Creating OIDC credentials for headscale in bitwarden.")
            issuer_obj = create_custom_field("issuer", self.zitadel_hostname)
            zitadel_project_id = create_custom_field("projectId",
                                                     self.zitadel.project_id)
            oidc_id = self.bitwarden.create_login(
                    name='headscale-oidc-credentials',
                    item_url=self.hostname,
                    user=oidc_creds['client_id'],
                    password=oidc_creds['client_secret'],
                    fields=[issuer_obj, zitadel_project_id]
                    )
        else:
            oidc_id = self.bitwarden.get_item(
                    f"headscale-oidc-credentials-{self.hostname}"
                    )[0]['id']

        # reload the bitwarden ESO provider
        try:
            self.argocd.k8s.reload_deployment('bitwarden-eso-provider',
                                              'external-secrets')
        except Exception as e:
            log.error(
                    "Couldn't scale down the [magenta]bitwarden-eso-provider"
                    "[/] deployment in [green]external-secrets[/] namespace."
                    f"Recieved: {e}"
                    )

        # update the headscale external secret bitwrden ID values
        return {'oidcCredentials': oidc_id,
                'encryptionCredentials': encryption_id,
                's3BackupCredentials': s3_backups_id}

    def create_user(self, user: str, email: str, display_name) -> None:
        """
        given a username, email, display name and namespace of the headscale
        pod, we'll create a new headscale user using a kubectl exec command
        """
        sub_header(f"Creating a headscale user for: {user}")

        # first, go get the exact name of the pod we need to exec a command on
        pod_cmd = (f"kubectl get pods -n {self.namespace} "
                   "-l app.kubernetes.io/instance=headscale-web-app"
                   " --no-headers "
                   "-o custom-columns=NAME:.metadata.name")

        pod = subproc([pod_cmd]).rstrip()
        log.info(f"headscale web app pod is: {pod}")

        # then run the user creation command
        cmd = (f'kubectl exec -n {self.namespace} {pod} -- headscale users '
               f'create {user} --email {email} --display-name {display_name}"')

        # then process the output from the command and return it
        subproc([cmd], shell=True, universal_newlines=True).split()[3]
