#!/usr/bin/env python
"""
This is just for generating headscale secrets and testing on the cli
"""
from smol_k8s_lab.utils.run.subproc import subproc


def generate_headscale_secrets() -> None:
    """
    These are required for headscale and headplane:

    # these are all for headscale
    headscale generate private-key --output json
    # this one is for headplane
    headscale apikeys create --expiration 999d
    """
    final_dict = {"wireguard_key": "",
                  "noise_key": "",
                  "derp_key": ""}

    # we use docker to generate all of these
    base_cmd = "docker run ghcr.io/juanfont/headscale:latest"

    # this is for the SECRET_KEY_BASE and OTP_SECRET values
    private_key_cmd = base_cmd + " generate private-key"

    final_dict["wireguard_key"] = subproc([private_key_cmd]).split()[0]
    final_dict["noise_key"] = subproc([private_key_cmd]).split()[0]
    final_dict["derp_key"] = subproc([private_key_cmd]).split()[0]

    # api_key_cmd = base_cmd + " apikeys create --expiration 999d"
    # headplane_api_key = json.loads(subproc([private_key_cmd]).split()[1])
    return final_dict

if __name__ == '__main__':
    print(generate_headscale_secrets())
