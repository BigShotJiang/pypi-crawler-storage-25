"""
       Name: external_secrets
DESCRIPTION: configures external secrets, currently only with Bitwarden
             hopefully with more supported providers in the future
     AUTHOR: @jessebot
    LICENSE: GNU AFFERO GENERAL PUBLIC LICENSE Version 3
"""
from smol_k8s_lab.bitwarden.bw_cli import BwCLI
from smol_k8s_lab.k8s_tools.argocd_util import ArgoCD
from smol_k8s_lab.k8s_tools.k8s_lib import K8s
from smol_k8s_lab.utils.run.subproc import subproc


def configure_external_secrets(argocd: ArgoCD,
                               eso_dict: dict,
                               eso_provider: str = "",
                               distro: str = "",
                               bitwarden: BwCLI = None) -> None:
    """
    configure external secrets and provider.
    """
    argocd.k8s.create_namespace("external-secrets")

    if eso_provider == "bitwarden":
        setup_bweso_provider(argocd.k8s, distro, bitwarden)

    argocd.install_init_app('external-secrets-operator', eso_dict, 4, True)


def setup_bweso_provider(k8s_obj: K8s,
                         distro: str,
                         bitwarden: BwCLI = None) -> None:
    """
    Creates an initial secret for use with the bitwarden provider for ESO
    """
    # this is a standard k8s secrets yaml
    k8s_obj.create_secret('bweso-login',
                          'external-secrets',
                          {"BW_PASSWORD": bitwarden.password,
                           "BW_CLIENTSECRET": bitwarden.client_secret,
                           "BW_CLIENTID": bitwarden.client_id,
                           "BW_APPID": "external-secrets-operator-bitwarden-provider",
                           "BW_HOST": bitwarden.host})

    if distro == 'kind':
        image = "docker.io/jessebot/bweso:v1.10.0"
        cmds = [f"docker pull --platform=linux/amd64 {image}",
                f"kind load docker-image {image} --name smol-k8s-lab-kind"]
        subproc(cmds)
