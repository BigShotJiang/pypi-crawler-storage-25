# internal libraries
from smol_k8s_lab.bitwarden.bw_cli import BwCLI
from smol_k8s_lab.k8s_tools.argocd_util import ArgoCD
from smol_k8s_lab.utils.passwords import create_password
from smol_k8s_lab.utils.rich_cli.console_logging import header

# external libraries
import logging as log


def configure_valkey(argocd: ArgoCD,
                     cfg: dict,
                     bitwarden: BwCLI = None) -> bool:
    """
    creates a valkey app and initializes it with secrets if you'd like :)

    required:
        argocd                 - ArgoCD() object for Argo CD operations
        cfg                    - dict, with at least argocd key and init key

    optional:
        bitwarden   - BwCLI() object with session token to create bitwarden items

    coming soon:
        pvc_storage_class      - str, storage class of PVC
    """
    # check immediately if the app is installed
    app_installed = argocd.check_if_app_exists('valkey')

    # verify if initialization is enabled
    init = cfg.get('init', {'enabled': True, 'restore': {'enabled': False}})
    init_enabled = init.get('enabled', True)

    # check if we're restoring and get values for that
    restore_dict = init.get('restore', {"enabled": False})
    restore_enabled = restore_dict['enabled']

    # figure out what header to print
    if restore_enabled:
        header_start = "Restoring"
    else:
        if app_installed:
            header_start = "Syncing"
        else:
            header_start = "Setting up"

    header(f"{header_start} [green]valkey[/], so you can have a key/value store",
           '💿')

    # get any secrets for this app
    # secrets = cfg['argo']['secret_keys']

    # we need namespace immediately
    valkey_namespace = cfg['argo']['namespace']

    # if init_enabled:
    #    # backups are their own config.yaml section
    #     backup_vals = process_backup_vals(cfg.get('backups', {}), 'valkey', argocd)

    if init_enabled and not app_installed:
        argocd.k8s.create_namespace(valkey_namespace)

        if bitwarden and not restore_enabled:
            setup_bitwarden_items(argocd, bitwarden)

        # these are standard k8s secrets yaml
        elif not bitwarden and not restore_enabled:
            # valkey creds k8s secret
            valkey_password = create_password()
            argocd.k8s.create_secret('valkey-credentials', 'valkey',
                                     {"password": valkey_password})

    if not app_installed:
        # TODO: support restores
        # if restore_enabled:
        #     Restore()

        if not init_enabled:
            argocd.install_app('valkey', cfg['argo'])
    else:
        log.info("valkey already installed 🎉")

        if bitwarden and init_enabled:
            refresh_bweso(argocd, bitwarden)


def refresh_bweso(argocd: ArgoCD, bitwarden: BwCLI) -> None:
    """
    if valkey already installed, but bitwarden and init are enabled, still
    populate the bitwarden IDs in the appset secret plugin secret
    """
    log.debug("Making sure valkey Bitwarden item IDs are in appset "
              "secret plugin secret")


    secrets_id = bitwarden.get_item("valkey-credentials-smol-k8s-lab", False)[0]['id']

    # {'valkey_admin_credentials_bitwarden_id': admin_id,
    argocd.update_appset_secret({'valkey_secret_bitwarden_id': secrets_id})


def setup_bitwarden_items(argocd: ArgoCD,
                          bitwarden: BwCLI) -> None:
    # valkey credentials
    valkey_password = bitwarden.generate()
    valkey_id = bitwarden.create_login(
            name='valkey-credentials-smol-k8s-lab',
            item_url="valkey.io",
            user='valkey',
            password=valkey_password
            )

    # update the valkey values for the argocd appset
    argocd.update_appset_secret({'valkey_valkey_bitwarden_id': valkey_id})

    # reload the bitwarden ESO provider
    try:
        argocd.k8s.reload_deployment('bitwarden-eso-provider', 'external-secrets')
    except Exception as e:
        log.error(
                "Couldn't scale down the [magenta]bitwarden-eso-provider"
                "[/] deployment in [green]external-secrets[/] namespace."
                f"Recieved: {e}"
                )
