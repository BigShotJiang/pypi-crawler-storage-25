# external libraries
import logging as log

# internal libraries
from smol_k8s_lab.k8s_tools.argocd_util import ArgoCD
from smol_k8s_lab.bitwarden.bw_cli import BwCLI, create_custom_field
from smol_k8s_lab.k8s_apps.identity_provider.zitadel_api import Zitadel
from smol_k8s_lab.k8s_apps.operators.minio import create_minio_alias
from smol_k8s_lab.k8s_tools.restores import Restore
from smol_k8s_lab.utils.value_from import process_backup_vals
from smol_k8s_lab.utils.passwords import create_password
from smol_k8s_lab.utils.rich_cli.console_logging import sub_header, header

def configure_grafana_stack(argocd: ArgoCD,
                            cfg: dict,
                            pvc_storage_class: str = "",
                            zitadel: Zitadel = None,
                            bitwarden: BwCLI = None) -> bool:
    """
    creates a grafana stack app and initializes it with secrets if you'd like :)

    required:
        argocd            - ArgoCD() object for Argo CD operations
        cfg               - dict, with at least argocd key and init key

    optional:
        zitadel     - Zitadel() object with session token to create zitadel oidc app and roles
        bitwarden   - BwCLI() object with session token to create bitwarden items
    """
    # verify immediately if grafana monitoring stack is installed
    app_installed = argocd.check_if_app_exists('grafana-stack')

    # verify if initialization is enabled
    init = cfg.get('init', {'enabled': True, 'restore': {'enabled': False}})
    init_enabled = init.get('enabled', True)

    restore_dict = cfg['init'].get('restore', {"enabled": False})
    restore_enabled = restore_dict['enabled']
    if restore_enabled:
        prefix = "Restoring"
    else:
        if app_installed:
            prefix = "Syncing"
        else:
            prefix = "Setting up"

    header(f"{prefix} [green]Grafana Monitoring Stack[/], so you can monitor your infrastructure",
           '📈')

    hostname = cfg['hostnames']['grafana']

    # always declare grafana monitoring stack namespace immediately
    monitoring_namespace = cfg['argo']['namespace']

    if init_enabled:
        # configure backup s3 credentials
        backup_vals = process_backup_vals(cfg.get('backups', {}))
        if zitadel and not restore_enabled:
            zitadel_hostname = zitadel.hostname
        else:
            zitadel_hostname = ""
        cfg['oidc'] = {'baseUrl': zitadel_hostname}

    # initial secrets to deploy this app from scratch
    if init_enabled and not app_installed:
        argocd.k8s.create_namespace(monitoring_namespace)

        s3_values = cfg.get('s3', {'endpoint', ''})
        s3_endpoint = s3_values.get('endpoint', 's3.beepbeeplettuce.com')
        if s3_endpoint and not restore_enabled:
            s3_access_key = create_password()
            # create a local alias to check and make sure the grafana stack is functional
            create_minio_alias(minio_alias="monitoring",
                               minio_hostname=s3_endpoint,
                               access_key="monitoring",
                               secret_key=s3_access_key)

        # create Grafana OIDC Application
        if zitadel and not restore_enabled:
            log.debug("Creating an OIDC application in Zitadel...")
            logout_uris = [f"https://{hostname}"]
            redirect_uris = f"https://{hostname}/login/generic_oauth"
            oidc_creds = zitadel.create_application("grafana",
                                                    redirect_uris,
                                                    logout_uris)
            zitadel.create_role("grafana_users", "grafana Users", "grafana_users")
            zitadel.update_user_grant(['grafana_users'])

        # if the user has bitwarden enabled
        if bitwarden and not restore_enabled:
            external_secret_items = setup_bitwarden_items(
                    argocd,
                    hostname,
                    s3_endpoint,
                    s3_access_key,
                    backup_vals['s3']['access_key_id'],
                    backup_vals['s3']['secret_access_key'],
                    backup_vals['restic_repo_pass'],
                    zitadel_hostname,
                    oidc_creds,
                    bitwarden)
            cfg['externalSecrets'] = {'bitwarden': external_secret_items}

        # else create these as Kubernetes secrets
        elif not bitwarden and not restore_enabled:
            if zitadel:
                # oidc secret
                argocd.k8s.create_secret(
                        'grafana-oidc-credentials',
                        'grafana',
                        {'user': oidc_creds['client_id'],
                         'password': oidc_creds['client_secret']}
                        )

            # loki valkey creds k8s secret
            loki_valkey_password = create_password()
            argocd.k8s.create_secret('loki-valkey-credentials', 'forgejo',
                                     {"password": loki_valkey_password})

    if not app_installed:
        # if the user is restoring, the process is a little different
        if init_enabled:
            if restore_enabled:
                if bitwarden:
                    external_secret_items = refresh_bitwarden(argocd,
                                                              hostname,
                                                              bitwarden)
                    cfg['externalSecrets'] = {'bitwarden': external_secret_items}

                Restore("grafana-stack",
                        argocd,
                        hostname,
                        monitoring_namespace,
                        cfg,
                        pvc_storage_class,
                        True,
                        bitwarden)
            else:
              argocd.install_init_app('grafana-stack', cfg, 4)

        else:
            argocd.install_app('grafana-stack', cfg['argo'])
    else:
        if bitwarden and init_enabled:
            log.info("Grafana Monitoring Stack already installed 🎉")
            external_secret_items = refresh_bitwarden(argocd,
                                                      hostname,
                                                      bitwarden)
            cfg['externalSecrets'] = {'bitwarden': external_secret_items}
            argocd.install_init_app('grafana-stack', cfg, 4)


def setup_bitwarden_items(argocd: ArgoCD,
                          hostname: str,
                          s3_endpoint: str,
                          s3_access_key: str,
                          backups_s3_user: str,
                          backups_s3_password: str,
                          restic_repo_pass: str,
                          zitadel_hostname: str,
                          oidc_creds: str,
                          bitwarden: BwCLI) -> dict:
    """
    setup all the required secrets as items in bitwarden
    """
    sub_header("Creating grafana monitoring stack related secrets in Bitwarden")

    admin_password = create_password()
    admin_id = bitwarden.create_login(
            name='admin-credentials',
            item_url=hostname,
            user="admin",
            password=admin_password)

    # OIDC credentials
    log.info("Creating OIDC credentials for grafana in Bitwarden")
    if zitadel_hostname:
        if oidc_creds:
            # for the credentials to zitadel
            oidc_id = bitwarden.create_login(
                    name='grafana-oidc-credentials',
                    item_url=hostname,
                    user=oidc_creds['client_id'],
                    password=oidc_creds['client_secret']
                    )
        else:
            # we assume the credentials already exist if they fail to create
            oidc_id = bitwarden.get_item(
                    f"grafana-oidc-credentials-{hostname}"
                    )[0]['id']

    restic_repo_obj = create_custom_field('resticRepoPassword', restic_repo_pass)
    s3_backup_id = bitwarden.create_login(
            name='backups-s3-credentials',
            item_url=hostname,
            user=backups_s3_user,
            password=backups_s3_password,
            fields=[restic_repo_obj]
            )

    endpoint_obj = create_custom_field('endpoint', s3_endpoint)
    admin_s3_key = create_password()
    s3_admin_id = bitwarden.create_login(
            name='admin-s3-credentials',
            item_url=hostname,
            user="monitoring-root",
            password=admin_s3_key,
            fields=[endpoint_obj]
            )

    # loki valkey credentials
    loki_valkey_password = bitwarden.generate()
    loki_valkey_id = bitwarden.create_login(
            name='loki-valkey-credentials',
            item_url=hostname,
            user='valkey',
            password=loki_valkey_password
            )

    # S3 credentials for loki
    loki_bucket_obj = create_custom_field('bucket', "loki")
    loki_access_key = create_password()
    s3_loki_id = bitwarden.create_login(
            name='loki-s3-credentials',
            item_url=hostname,
            user="loki",
            password=loki_access_key,
            fields=[loki_bucket_obj, endpoint_obj]
            )

    # S3 credentials for mimir
    mimir_bucket_obj = create_custom_field('bucket', "mimir")
    mimir_access_key = create_password()
    s3_mimir_id = bitwarden.create_login(
            name='mimir-s3-credentials',
            item_url=hostname,
            user="mimir",
            password=mimir_access_key,
            fields=[mimir_bucket_obj, endpoint_obj]
            )

    # mimir valkey credentials
    mimir_valkey_password = bitwarden.generate()
    mimir_valkey_id = bitwarden.create_login(
            name='mimir-valkey-credentials',
            item_url=hostname,
            user='valkey',
            password=mimir_valkey_password
            )

    # tempo valkey credentials
    tempo_valkey_password = bitwarden.generate()
    tempo_valkey_id = bitwarden.create_login(
            name='tempo-valkey-credentials',
            item_url=hostname,
            user='valkey',
            password=tempo_valkey_password
            )

    # S3 credentials for tempo
    tempo_bucket_obj = create_custom_field('bucket', "tempo")
    s3_tempo_id = bitwarden.create_login(
            name='tempo-s3-credentials',
            item_url=hostname,
            user="tempo",
            password=s3_access_key,
            fields=[tempo_bucket_obj, endpoint_obj]
            )

    return_dict = {
            'mimir': {
              'valkeyCredentials': mimir_valkey_id,
              's3Credentials': s3_mimir_id
            },
            'tempo': {
              'valkeyCredentials': tempo_valkey_id,
              's3Credentials': s3_tempo_id
            },
            'loki': {
              'valkeyCredentials': loki_valkey_id,
              's3Credentials': s3_loki_id
            },
            'adminCredentials': admin_id,
            'oidcCredentials': oidc_id,
            's3BackupCredentials': s3_backup_id,
            's3AdminCredentials': s3_admin_id}

    # reload the bitwarden ESO provider
    try:
        argocd.k8s.reload_deployment('bitwarden-eso-provider',
                                     'external-secrets')
    except Exception as e:
        log.error(
                "Couldn't scale down the [magenta]bitwarden-eso-provider[/]"
                "deployment in [green]external-secrets[/] namespace. Recieved: "
                f"{e}"
                )

    return return_dict


def refresh_bitwarden(argocd: ArgoCD, hostname: str, bitwarden: BwCLI) -> dict:
    """
    makes sure we update bitwarden IDs in memory regardless
    """
    bw_items = bitwarden.list_items(hostname)

    loki_valkey_id = bw_items[f"loki-valkey-credentials-{hostname}"]

    mimir_valkey_id = bw_items[f"mimir-valkey-credentials-{hostname}"]

    tempo_valkey_id = bw_items[f"tempo-valkey-credentials-{hostname}"]

    oidc_id = bw_items[f"grafana-oidc-credentials-{hostname}"]

    s3_backup_id = bw_items[f"backups-s3-credentials-{hostname}"]

    s3_admin_id = bw_items[f"admin-s3-credentials-{hostname}"]

    s3_loki_id = bw_items[f"loki-s3-credentials-{hostname}"]

    s3_mimir_id = bw_items[f"mimir-s3-credentials-{hostname}"]

    s3_tempo_id = bw_items[f"tempo-s3-credentials-{hostname}"]

    return_dict = {
            'loki': {
                's3Credentials': s3_loki_id,
                'valkeyCredentials': loki_valkey_id
            },
            'mimir': {
                's3Credentials': s3_mimir_id,
                'valkeyCredentials': mimir_valkey_id
            },
            'tempo': {
                's3Credentials': s3_tempo_id,
                'valkeyCredentials': tempo_valkey_id
            },
            'oidcCredentials': oidc_id,
            's3BackupCredentials': s3_backup_id,
            's3AdminCredentials': s3_admin_id}

    return return_dict
