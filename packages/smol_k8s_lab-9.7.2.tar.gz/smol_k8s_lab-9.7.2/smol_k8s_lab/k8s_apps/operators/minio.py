from json import load, dump
import logging as log
from os.path import exists, join
from os import makedirs

from smol_k8s_lab.constants import HOME_DIR


def create_minio_alias(minio_alias: str,
                       minio_hostname: str,
                       access_key: str,
                       secret_key: str,
                       secure: bool = True) -> None:
    """
    add minio alias for credentials to your local /home/.mc/config.json file
    """
    protocol = "https"
    if not secure:
        protocol = "http"

    # we create a config file so users can easily use minio from the cli
    new_minio_alias = {"url": f"{protocol}://{minio_hostname}",
                       "accessKey": access_key,
                       "secretKey": secret_key,
                       "api": "S3v4",
                       "path": "auto"}

    # if the user hasn't chosen a config location, we use XDG spec, maybe
    # xdg_minio_config_file = xdg_config_home() + "/minio/config.json"
    minio_config_dir = join(HOME_DIR, ".mc/")
    minio_config_file = join(minio_config_dir, "config.json")

    # create the dir if it doesn't exist
    if not exists(minio_config_file):
        makedirs(minio_config_dir, exist_ok=True)
        minio_cfg_obj = {}
    else:
        # open the default minio cli config to take a peek
        with open(minio_config_file, 'r') as minio_config_contents:
            minio_cfg_obj = load(minio_config_contents)

    # reconfigure the file for our new alias
    if not minio_cfg_obj:
        # if there's not a config object, make one
        minio_cfg_obj = {"version": "10",
                         "aliases": {minio_alias: new_minio_alias}}
    else:
        aliases = minio_cfg_obj.get("aliases", None)
        # if there is an aliases section with minio_alias, update it
        if aliases:
            minio_cfg_obj['aliases'][minio_alias] = new_minio_alias
        # if there is not an aliases section with minio_alias, create one
        else:
            minio_cfg_obj['aliases'] = {minio_alias: new_minio_alias}

    # write out the config file when we're done
    with open(minio_config_file, 'w') as minio_config_contents:
        dump(minio_cfg_obj, minio_config_contents)
