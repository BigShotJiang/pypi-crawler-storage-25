# local libs
from smol_k8s_lab.utils.run.subproc import subproc
from smol_k8s_lab.k8s_tools.k8s_lib import K8s
from smol_k8s_lab.k8s_apps.social.nextcloud_occ_commands import Nextcloud
from smol_k8s_lab.utils.minio_lib import BetterMinio

# external libs
# import asyncio
import base64
from datetime import datetime
import logging as log
from time import sleep


def run_cli_backup(app: str = "", app_dict: dict = {}):
    """
    backup an init enabled app via the cli
    """
    log.info(f"Checking if {app} can be backed up...")

    if app_dict.get('init', {}).get('enabled', False):
        log.info(f"Looks like init is enabled for {app}")
        backups_config = app_dict.get('backups', {})

        if backups_config:
            log.info(f"looks like we can backup {app}")

            namespace = app_dict['argo']['namespace']
            if backups_config.get("db", {}):
                cnpg_backup = True

            if backups_config.get("pvc", {}):
                create_pvc_restic_backup(
                        app,
                        namespace,
                        backups_config['s3']['endpoint'],
                        backups_config['s3']['bucket'],
                        cnpg_backup,
                        app_dict['s3']['endpoint'])
        else:
            log.info(f"looks like we CANNOT backup {app} :(")
    else:
        log.info(f"looks like we CANNOT backup {app} :(")


def create_pvc_restic_backup(app: str,
                             namespace: str,
                             endpoint: str,
                             bucket: str,
                             cnpg_backup: bool = True,
                             cnpg_s3_endpoint: str = "",
                             quiet: bool = False) -> None:
    """
    a function to immediately run a restic backup job
    unless it's nextcloud, then we put it into maintenance_mode first...

    pass in quiet=True to disable loading spinners for logging
    """
    now = datetime.now().strftime('%Y-%m-%d-%H-%M')
    # make sure we don't have any _, as some kubectl commands don't like them
    app = app.replace("_", "-")
    backup_name = f"{app}-smol-k8s-lab-{now}"

    # k8s object creation
    k8s_obj = K8s()

    backup_yaml = {
            "apiVersion": "k8up.io/v1",
            "kind": "Backup",
            "metadata": {
              "name": backup_name,
              "namespace": namespace
              },
            "spec": {
              "failedJobsHistoryLimit": 4,
              "promURL": "push-gateway.monitoring.svc:9091",
              "successfulJobsHistoryLimit": 2,
              "backend": {
                "repoPasswordSecretRef": {
                  "key": "resticRepoPassword",
                  "name": "s3-backups-credentials"
                },
                "s3": {
                  "accessKeyIDSecretRef": {
                    "key": "ACCESS_KEY_ID",
                    "name": "s3-backups-credentials",
                    "optional": False
                    },
                  "bucket": bucket,
                  "endpoint": endpoint,
                  "secretAccessKeySecretRef": {
                    "key": "ACCESS_SECRET_KEY",
                    "name": "s3-backups-credentials",
                    "optional": False
                    }
                  }
                }
              }
            }

    # make sure we have a podConfig if we need it
    pod_configs = k8s_obj.get_podconfigs(namespace)
    log.info("here's the pod configs:")
    log.info(pod_configs)
    if pod_configs:
        if "file-backups-podconfig" in pod_configs:
            pod_config_name = "file-backups-podconfig"
        else:
            pod_config_name = "s3-backups-podconfig"
        backup_yaml['spec']["podConfigRef"] = {"name": pod_config_name}

    # nextcloud is needs to be put into maintenance mode before backups
    if app == "nextcloud":
        # nextcloud backups need to run as user 82 which is nginx
        backup_yaml['spec']['podSecurityContext'] = {"runAsUser": 82}
        nextcloud = Nextcloud(K8s(), namespace, quiet)
        nextcloud.set_maintenance_mode("on")

        # then wait for maintenance_mode to be fully on
        sleep(10)

    # do the database backup if this app has one
    if cnpg_backup:
        create_cnpg_cluster_backup(app,
                                   namespace,
                                   cnpg_s3_endpoint,
                                   quiet=quiet)

    # then we can do the actual backup
    k8s = K8s()
    k8s.apply_custom_resources([backup_yaml])

    # wait for backup to complete
    wait_cmd = (f"kubectl wait job -n {namespace} --for=condition=complete "
                f"backup-{backup_name}-0 --timeout=15m")
    print(wait_cmd)
    while True:
        log.debug(f"Waiting for backup job: backup-{backup_name}-0")
        res = subproc([wait_cmd], error_ok=True, spinner=quiet)
        log.debug(res)
        if "NotFound" in res:
            sleep(1)
        else:
            break

    if app == "nextcloud":
        # turn nextcloud maintenance_mode off after the backup
        nextcloud.set_maintenance_mode("off")

    return True


def create_cnpg_cluster_backup(app: str,
                               namespace: str,
                               s3_endpoint: str,
                               quiet: bool = False) -> None:
    """
    creates a backup for cnpg clusters and waits for it to complete

    pass in quiet=True to disable loading spinners for logging
    """
    now = datetime.now().strftime('%Y-%m-%d-%H-%M')
    backup_name = f"{app}-smol-k8s-lab-cnpg-backup-{now}"
    cluster_name = f"{app}-postgres"
    cnpg_backup = {"apiVersion": "postgresql.cnpg.io/v1",
                   "kind": "Backup",
                   "metadata": {
                      "name": backup_name,
                      "namespace": namespace
                      },
                   "spec": {
                      "method": "barmanObjectStore",
                      "cluster": {
                        "name": cluster_name
                        }
                      }
                   }

    # then we can do the actual backup
    k8s = K8s()
    k8s.apply_custom_resources([cnpg_backup])

    # wait for backup to complete
    wait_cmd = (f"kubectl get -n {namespace} --no-headers "
                "-o custom-columns=PHASE:.status.phase "
                f"backups.postgresql.cnpg.io/{backup_name}")
    while True:
        log.error(
                f"Waiting on backups.postgresql.cnpg.io/{backup_name} finish"
                )
        res = subproc([wait_cmd], error_ok=True, spinner=quiet)
        log.error(res)
        if "completed" in res:
            break
        sleep(1)

    # get credentials & setup s3 object to check if all wal archives are there
    credentials = k8s.get_secret("s3-postgres-credentials", namespace)
    accesskey = credentials['data']['ACCESS_KEY_ID']
    secretkey = credentials['data']['ACCESS_SECRET_KEY']
    access_key_id = base64.b64decode(accesskey).decode('utf-8')
    secret_access_key = base64.b64decode(secretkey).decode('utf-8')
    log.error("got credentials and about to check s3")
    s3 = BetterMinio("", s3_endpoint, access_key_id, secret_access_key)
    all_wals = f"{cluster_name}/wals"

    # after the backup is done, check which wal archive it says is the last one
    end_wal_cmd = (
            f"kubectl get -n {namespace} "
            f"backups.postgresql.cnpg.io/{backup_name}"
            " -o custom-columns=endwal:.status.endWal --no-headers"
            )
    end_wal = subproc([end_wal_cmd]).strip()
    end_wal_dir = f"'{all_wals}/{end_wal[:16]}/{end_wal}'"
    log.error(f"Wal folder expected for {cluster_name} backup: {end_wal_dir}")
    check_for_specific_wal(s3, cluster_name, all_wals, end_wal)


def check_for_specific_wal(s3: BetterMinio,
                           cluster_name: str,
                           all_wals_dir: str,
                           wall_to_chck: str):
    """
    count the number of wals in s3 for this cluster and log them each
    """

    while True:
        wal_files = s3.list_object(cluster_name, all_wals_dir, recursive=True)
        total_wals = 0
        for wal in wal_files:
            total_wals += 1
            log.error(f"{str(total_wals)}: Found wal called {wal.object_name}")

            # return if we found the correct wal
            if wall_to_chck in wal.object_name:
                log.error("wal to check present 🎉 sleeping just 5 more seconds because barman is weird")
                sleep(5)
                return True

        log.error(f"found {str(total_wals)} total wal files.")
        log.error(f"not the wal file we wanted: {wall_to_chck}. Sleeping 10s.")
        sleep(10)
