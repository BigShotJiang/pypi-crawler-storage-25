# it was only a matter of time before I had to query argocd directly
import logging as log
from .k8s_lib import K8s
from ..utils.run.subproc import subproc
from ..constants import XDG_CACHE_DIR
from json import loads
from os import path
from ruamel.yaml import YAML
from time import sleep


class ArgoCD():
    """
    class for common Argo CD functions
    """

    def __init__(self,
                 namespace: str,
                 argo_cd_domain: str,
                 k8s_obj: K8s|None = None,
                 globals_dict: dict = {},
                 secrets_backend: str = "") -> None:
        """
        secrets_backend: str, if set to "bitwarden", resets bitwarden eso
        provider when updating Argo CD Appset Secret Plugin
        """

        # setup Argo CD to talk directly to k8s
        log.debug(f"setting namespace to {namespace} and configuring argocd "
                  "to use k8s for auth")
        subproc([
            f'kubectl config set-context --current --namespace={namespace}',
            f'argocd login {argo_cd_domain} --core'
            ])
        self.namespace = namespace
        self.hostname = argo_cd_domain
        self.k8s = k8s_obj
        self.secrets_backend = secrets_backend
        self.globals_dict = globals_dict

    def check_if_app_exists(self, app: str, quiet: bool = False) -> bool:
        """
        check if argocd application has already been installed
        """
        res = subproc([f"argocd app get {app}"], error_ok=True, quiet=quiet)
        if app in res:
            return True
        else:
            return False

    def sync_app(self,
                 app: str,
                 spinner: bool = True,
                 replace: bool = False,
                 force: bool = False,
                 sleep_time: int = 1) -> str:
        """
        syncs an argocd app and returns the result
        """
        # build sync command
        cmd = "argocd app sync --retry-limit 3 --loglevel warn "
        if replace:
            cmd += "--replace "
        if force:
            cmd += "--force "
        cmd += app

        counter = 0
        while True:
            # run sync command
            if spinner:
                res = subproc([cmd], error_ok=True)
            else:
                res = subproc([cmd], spinner=False, error_ok=True)

            if "permission denied" not in res:
                return res
            else:
                if counter == 10:
                    log.error("Something has gone wrong with syncs! we tried 10 times!")
                    break
                else:
                    log.error(f"Sleeping {sleep_time} seconds before next attempt to sync...")
                    sleep(sleep_time)

            counter += 1

    def delete_app(self,
                   app: str,
                   spinner: bool = True,
                   force: bool = False) -> str:
        """
        delete an app and associated appsets, and returns the result for all
        """
        # build delete command
        cmd = "argocd app delete -y "
        if force:
            cmd += "--force "
        cmd += app

        # run sync command
        app_res = subproc([cmd], spinner=spinner, error_ok=True)
        if not app_res:
            app_res = ""

        # clean up old apps as well
        apps = ["web-app",
                "seaweedfs-app",
                "s3-provider-app",
                "s3-pvc-app",
                "pvc-app",
                "external-secrets-app"]
        init_apps = ["nextcloud",
                     "matrix",
                     "mastodon",
                     "zitadel",
                     "forgejo",
                     "gotosocial"]
        if app in init_apps:
            for argo_app in apps:
                res = subproc([f"argocd app delete -y {app}-{argo_app}"],
                              error_ok=True, spinner=spinner)
                if res:
                    app_res += res

            # sometimes seaweedfs gets stuck...
            res = subproc([f"argocd app terminate-op {app}-seaweedfs-app"],
                          error_ok=True, spinner=spinner)
            if res:
                app_res += res

        # delete any remaining pods, just in case
        res = self.k8s.delete_namespaced_pods(app)
        if res:
            app_res += res
        print(app_res)

        return app_res


    def install_app(self,
                    app: str,
                    argo_dict: dict,
                    wait: bool = False) -> bool|None:
        """
        create an Argo CD app directly from the command line using passed in
        app and argo_dict which should have str keys for repo, path, and namespace
        """
        if self.check_if_app_exists(app):
            log.debug(f"An Argo CD app called [green]{app}[/] already [green]exists[/] :)")
            return True
        else:
            log.info(f"Installing an Argo CD app called {app} :)")
            repo = argo_dict['repo']
            argo_path = argo_dict['path']
            revision = argo_dict['revision']
            app_namespace = argo_dict['namespace']
            app_cluster = argo_dict.get('cluster', 'https://kubernetes.default.svc')
            proj_namespaces = argo_dict['project']['destination']['namespaces']
            proj_namespaces.append(app_namespace)
            if 'argocd' not in proj_namespaces:
                proj_namespaces.append('argocd')

            # make sure the namespace already exists
            self.k8s.create_namespace(app_namespace)

            source_repos = [repo]
            extra_source_repos = argo_dict["project"].get('source_repos', [])
            if extra_source_repos:
                source_repos.extend(extra_source_repos)

            self.create_project(argo_dict['project'].get('name', app),
                                       app,
                                       set(proj_namespaces),
                                       app_cluster,
                                       set(source_repos))

            cmd = (f"argocd app create {app} --upsert "
                   f"--repo {repo} "
                   f"--path {argo_path} "
                   f"--revision {revision} "
                   "--sync-policy automated "
                   "--sync-option ApplyOutOfSyncOnly=true "
                   "--self-heal "
                   f"--dest-namespace {app_namespace} "
                   f"--dest-server {app_cluster}")

            if argo_dict['directory_recursion']:
                cmd += " --directory-recurse"

            response = subproc([cmd])
            log.debug(response)

            # wait for the app to be healthy if requested by the user
            if wait:
                self.wait_for_app(app)

    def install_init_app(self,
                         app: str,
                         app_dict: dict,
                         sync_wave: int = 1,
                         wait: bool = False) -> bool|None:
        """
        create an Argo CD app directly from the command line using passed in
        app and argo_dict which should have str keys for repo, path, & namespace
        """
        app_exists = self.check_if_app_exists(app)
        if app_exists:
            log.debug(f"An Argo CD app called [green]{app}[/] already "
                      "[green]exists[/]. Syncing...")
        else:
            log.info(f"Installing an Argo CD app called {app} :)")

        argo_dict = app_dict['argo']
        repo = argo_dict['repo']
        argo_path = argo_dict['path']
        revision = argo_dict['revision']
        app_namespace = argo_dict['namespace']
        app_cluster = argo_dict.get('cluster',
                                    'https://kubernetes.default.svc')
        proj_namespaces = argo_dict['project']['destination']['namespaces']
        proj_namespaces.append(app_namespace)
        if 'argocd' not in proj_namespaces:
            proj_namespaces.append('argocd')

        # make sure the namespace already exists
        self.k8s.create_namespace(app_namespace)

        source_repos = [repo]
        extra_source_repos = argo_dict["project"].get('source_repos', [])
        if extra_source_repos:
            source_repos.extend(extra_source_repos)

        app_project_name = argo_dict['project'].get('name', app)

        self.create_project(app_project_name,
                            app,
                            set(proj_namespaces),
                            app_cluster,
                            set(source_repos))

        backup_vals = app_dict.get('backups', {})

        # remove sensitive backup values from plain text app_dict
        if backup_vals:
            if backup_vals.get('s3', {}):
                if backup_vals['s3'].get('secret_access_key',''):
                    backup_vals['s3'].pop('secret_access_key')
                if backup_vals['s3'].get('access_key_id',''):
                    backup_vals['s3'].pop('access_key_id')

            if backup_vals.get('restic_repo_password', ''):
                backup_vals.pop('restic_repo_password')

        # this is for when there's a special app section, which is infrequent
        app_param = app.replace("-","_")

        argocd_app_yaml = {
                "apiVersion": "argoproj.io/v1alpha1",
                "kind": "Application",
                "metadata": {
                  "name": app,
                  "namespace": self.namespace
                },
                "spec": {
                  "project": app_project_name,

                  "destination": {
                    "server": app_cluster,
                    "namespace": app_namespace
                  },
                  "syncPolicy": {
                    "syncOptions": [
                      "CreateNamespace=true",
                      "ApplyOutOfSyncOnly=true"
                      ],
                    "automated": {
                      "prune": True,
                      "selfHeal": True
                      }
                  },
                  "source": {
                    "repoURL": repo,
                    "targetRevision": revision,
                    "path": argo_path,
                    "helm": {
                      "valuesObject": {
                          "syncWaves": sync_wave,
                          "global": {
                              "timeZone": self.globals_dict['time_zone'],
                              "storageClass": self.globals_dict['storage_class'],
                              "clusterIssuer": self.globals_dict['cluster_issuer'],
                              "phoneRegion": self.globals_dict.get('phoneRegion', '')
                          },
                          app_param: app_dict.get(app_param, {}),
                          "admin": app_dict.get("admin", {}),
                          "backups": backup_vals,
                          "affinity": app_dict.get('affinity', {}),
                          "tolerations": app_dict.get('tolerations', []),
                          "hostnames": app_dict.get('hostnames', {}),
                          "s3": app_dict.get('s3', {}),
                          "pvc": app_dict.get('pvc', {}),
                          "db": app_dict.get('db', {}),
                          "smtp": app_dict.get('smtp', {}),
                          "oidc": app_dict.get('oidc', {}),
                          "externalSecrets": app_dict.get('externalSecrets', {})
                      }
                    }
                  }
                }
        }

        # apply the the app yaml we just wrote to cache
        self.k8s.apply_custom_resources([argocd_app_yaml])

        # if the app already exists, sync it just to be sure
        if app_exists:
            self.sync_app(app)

        # wait for the app to be healthy if requested by the user
        if wait:
            self.wait_for_app(app)

    def wait_for_app(self, app: str, retry: bool = False) -> None:
        """
        checks the status of an Argo CD app and waits till it is ready
        """
        if retry:
            # set error to true by default
            error = True
            # while error still equals True, keep retrying the command
            while error:
                try:
                    subproc([f"argocd app wait {app} --health --loglevel warn"])
                except Exception as e:
                    log.debug(e)
                    error = True
                    log.debug(f"Retrying wait for for {app}")
                else:
                    error = False
        else:
            subproc([f"argocd app wait {app} --health --loglevel warn"])

    def create_project(self,
                       project_name: str,
                       app: str,
                       namespaces: set,
                       clusters: str|list,
                       source_repos: set) -> True:
        """
        create an argocd project
        """
        argocd_proj = {
            "apiVersion": "argoproj.io/v1alpha1",
            "kind": "AppProject",
            "metadata": {
                "name": project_name,
                "namespace": 'argocd',
            },
            "spec": {
                "clusterResourceWhitelist": [
                    {
                        "group": "*",
                        "kind": "*"
                    }
                ],
                "description": f"project for {app}",
                "destinations": [],
                "namespaceResourceWhitelist": [
                    {
                        "group": "*",
                        "kind": "*"
                    }
                ],
                "orphanedResources": {},
                "sourceRepos": list(source_repos)
            },
            "status": {}
        }

        # if the user has passed in a single cluster... todo: handle multiple clusters
        if isinstance(clusters, str):
            if clusters == "https://kubernetes.default.svc":
                name = "in-cluster"
                server = "https://kubernetes.default.svc"
            elif clusters == "in-cluster":
                server = "https://kubernetes.default.svc"
                name = "in-cluster"
            else:
                cluster_json = loads(subproc(f"argocd cluster get {clusters} -o json"))
                name = cluster_json["name"]
                server = cluster_json["server"]

            for namespace in namespaces:
                extra_dest = {"name": name, "namespace": namespace, "server": server}
                argocd_proj['spec']['destinations'].append(extra_dest)

        try:
            self.k8s.apply_custom_resources([argocd_proj])
        except Exception as e:
            log.warn(e)

    def update_appset_secret(self,
                             fields: dict,
                             argo_managed: bool = True,
                             update_bitwarden: bool = True) -> None:
        """
        pass in k8s context and dict of fields to add to the argocd appset secret
        and reload the deployment
        """
        self.k8s.update_secret_key('appset-secret-vars',
                                   self.namespace,
                                   fields,
                                   'secret_vars.yaml')

        if argo_managed:
            # reload the argocd appset secret plugin
            self.sync_app('appset-secrets-plugin', spinner=True, replace=True, force=True)
            self.wait_for_app('appset-secrets-plugin')
        else:
            sleep(9)
            # self.k8s.reload_deployment("appset-secrets-plugin", self.namespace)

        # if bweso enabled, reload the bitwarden ESO provider
        if update_bitwarden and self.secrets_backend == "bitwarden":
            self.sync_app('bitwarden-eso-provider', spinner=True, replace=True, force=True)
            self.wait_for_app('bitwarden-eso-provider')
