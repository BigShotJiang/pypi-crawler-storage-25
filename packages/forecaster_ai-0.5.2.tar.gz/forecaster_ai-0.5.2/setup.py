"""Setup script for the forecasting package."""

from setuptools import setup

# This file is kept for backward compatibility
# All configuration is in pyproject.toml
setup()

# Made with Bob
