"""Model monitoring for drift detection and performance tracking."""

from collections import deque
from datetime import datetime
from typing import Any, Deque, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from scipy import stats

from forecasting.core.exceptions import MLOpsError
from forecasting.evaluation.metrics import ForecastMetrics


class PerformanceMonitor:
    """Monitor model performance over time.

    Tracks prediction accuracy and detects performance degradation.

    Attributes:
        window_size: Size of rolling window for metrics
        alert_threshold: Threshold for performance alerts
        metrics_history: History of performance metrics
    """

    def __init__(
        self,
        window_size: int = 100,
        alert_threshold: float = 0.2,
        metrics: Optional[List[str]] = None,
    ):
        """Initialize performance monitor.

        Args:
            window_size: Size of rolling window
            alert_threshold: Relative threshold for alerts (e.g., 0.2 = 20% degradation)
            metrics: List of metrics to track
        """
        self.window_size = window_size
        self.alert_threshold = alert_threshold
        self.metrics = metrics or ["mae", "rmse", "mape"]

        self.metrics_history: Dict[str, Deque[float]] = {
            metric: deque(maxlen=window_size) for metric in self.metrics
        }
        self.baseline_metrics: Dict[str, float] = {}
        self.alerts: List[Dict[str, Any]] = []

    def set_baseline(self, metrics: Dict[str, float]) -> None:
        """Set baseline metrics for comparison.

        Args:
            metrics: Baseline metric values
        """
        self.baseline_metrics = {k: v for k, v in metrics.items() if k in self.metrics}

    def log_prediction(
        self,
        y_true: pd.Series,
        y_pred: pd.Series,
    ) -> Dict[str, float]:
        """Log a prediction and calculate metrics.

        Args:
            y_true: True values
            y_pred: Predicted values

        Returns:
            Dictionary of current metrics
        """
        # Calculate metrics
        current_metrics = ForecastMetrics.calculate_all(y_true, y_pred)

        # Update history
        for metric in self.metrics:
            if metric in current_metrics:
                self.metrics_history[metric].append(current_metrics[metric])

        # Check for alerts
        self._check_alerts(current_metrics)

        return current_metrics

    def _check_alerts(self, current_metrics: Dict[str, float]) -> None:
        """Check if current metrics trigger alerts.

        Args:
            current_metrics: Current metric values
        """
        if not self.baseline_metrics:
            return

        for metric, value in current_metrics.items():
            if metric not in self.baseline_metrics:
                continue

            baseline = self.baseline_metrics[metric]
            if baseline == 0:
                continue

            # Calculate relative change
            relative_change = abs(value - baseline) / baseline

            if relative_change > self.alert_threshold:
                alert = {
                    "timestamp": datetime.now().isoformat(),
                    "metric": metric,
                    "baseline": baseline,
                    "current": value,
                    "change": relative_change,
                    "severity": "high" if relative_change > 0.5 else "medium",
                }
                self.alerts.append(alert)

    def get_rolling_metrics(self) -> Dict[str, Dict[str, float]]:
        """Get rolling statistics for metrics.

        Returns:
            Dictionary with mean, std, min, max for each metric
        """
        rolling_stats = {}

        for metric, history in self.metrics_history.items():
            if len(history) > 0:
                rolling_stats[metric] = {
                    "mean": float(np.mean(history)),
                    "std": float(np.std(history)),
                    "min": float(np.min(history)),
                    "max": float(np.max(history)),
                    "current": float(history[-1]) if history else 0.0,
                }

        return rolling_stats

    def get_alerts(
        self,
        severity: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """Get performance alerts.

        Args:
            severity: Filter by severity ('high', 'medium', 'low')
            limit: Maximum number of alerts to return

        Returns:
            List of alerts
        """
        alerts = self.alerts

        if severity:
            alerts = [a for a in alerts if a["severity"] == severity]

        if limit:
            alerts = alerts[-limit:]

        return alerts

    def clear_alerts(self) -> None:
        """Clear all alerts."""
        self.alerts = []

    def get_summary(self) -> Dict[str, Any]:
        """Get monitoring summary.

        Returns:
            Dictionary with monitoring summary
        """
        return {
            "baseline_metrics": self.baseline_metrics,
            "rolling_metrics": self.get_rolling_metrics(),
            "total_predictions": sum(len(h) for h in self.metrics_history.values()),
            "active_alerts": len(self.alerts),
            "high_severity_alerts": len([a for a in self.alerts if a["severity"] == "high"]),
        }


class DriftMonitor:
    """Monitor data drift in features and predictions.

    Detects distribution shifts using statistical tests.

    Attributes:
        reference_data: Reference data distribution
        drift_threshold: P-value threshold for drift detection
        drift_history: History of drift detections
    """

    def __init__(
        self,
        drift_threshold: float = 0.05,
        window_size: int = 100,
    ):
        """Initialize drift monitor.

        Args:
            drift_threshold: P-value threshold for drift detection
            window_size: Size of window for drift detection
        """
        self.drift_threshold = drift_threshold
        self.window_size = window_size

        self.reference_data: Optional[pd.DataFrame] = None
        self.drift_history: List[Dict[str, Any]] = []
        self.feature_stats: Dict[str, Dict[str, float]] = {}

    def set_reference(self, data: pd.DataFrame) -> None:
        """Set reference data distribution.

        Args:
            data: Reference data
        """
        self.reference_data = data.copy()

        # Calculate reference statistics
        for column in data.columns:
            self.feature_stats[column] = {
                "mean": float(data[column].mean()),
                "std": float(data[column].std()),
                "min": float(data[column].min()),
                "max": float(data[column].max()),
            }

    def detect_drift(
        self,
        data: pd.DataFrame,
        method: str = "ks",
    ) -> Dict[str, Any]:
        """Detect drift in new data.

        Args:
            data: New data to check for drift
            method: Statistical test ('ks' for Kolmogorov-Smirnov, 'chi2' for Chi-square)

        Returns:
            Dictionary with drift detection results
        """
        if self.reference_data is None:
            raise MLOpsError("Reference data not set. Call set_reference() first.")

        drift_results = {
            "timestamp": datetime.now().isoformat(),
            "method": method,
            "features": {},
            "drift_detected": False,
        }

        for column in data.columns:
            if column not in self.reference_data.columns:
                continue

            ref_values = self.reference_data[column].dropna()
            new_values = data[column].dropna()

            if len(ref_values) == 0 or len(new_values) == 0:
                continue

            # Perform statistical test
            if method == "ks":
                statistic, pvalue = stats.ks_2samp(ref_values, new_values)
            elif method == "chi2":
                # Bin the data for chi-square test
                bins = np.histogram_bin_edges(np.concatenate([ref_values, new_values]), bins="auto")
                ref_hist, _ = np.histogram(ref_values, bins=bins)
                new_hist, _ = np.histogram(new_values, bins=bins)

                # Avoid division by zero
                ref_hist = ref_hist + 1
                new_hist = new_hist + 1

                statistic, pvalue = stats.chisquare(new_hist, ref_hist)
            else:
                raise MLOpsError(f"Unknown drift detection method: {method}")

            # Check for drift
            drift_detected = pvalue < self.drift_threshold

            drift_results["features"][column] = {
                "statistic": float(statistic),
                "pvalue": float(pvalue),
                "drift_detected": drift_detected,
                "mean_shift": float(new_values.mean() - ref_values.mean()),
                "std_shift": float(new_values.std() - ref_values.std()),
            }

            if drift_detected:
                drift_results["drift_detected"] = True

        # Store in history
        self.drift_history.append(drift_results)

        return drift_results

    def get_drift_summary(self) -> Dict[str, Any]:
        """Get drift monitoring summary.

        Returns:
            Dictionary with drift summary
        """
        if not self.drift_history:
            return {
                "total_checks": 0,
                "drift_detected_count": 0,
                "features_with_drift": [],
            }

        # Count drift occurrences per feature
        feature_drift_counts: Dict[str, int] = {}

        for result in self.drift_history:
            for feature, stats in result["features"].items():
                if stats["drift_detected"]:
                    feature_drift_counts[feature] = feature_drift_counts.get(feature, 0) + 1

        return {
            "total_checks": len(self.drift_history),
            "drift_detected_count": sum(1 for r in self.drift_history if r["drift_detected"]),
            "features_with_drift": [
                {"feature": k, "count": v}
                for k, v in sorted(feature_drift_counts.items(), key=lambda x: x[1], reverse=True)
            ],
            "last_check": self.drift_history[-1]["timestamp"],
        }

    def plot_drift_history(self) -> Any:
        """Plot drift detection history.

        Returns:
            Matplotlib figure
        """
        if not self.drift_history:
            raise MLOpsError("No drift history available")

        try:
            import matplotlib.pyplot as plt

            # Extract data
            timestamps = [r["timestamp"] for r in self.drift_history]
            drift_detected = [r["drift_detected"] for r in self.drift_history]

            fig, ax = plt.subplots(figsize=(12, 6))
            ax.plot(range(len(timestamps)), drift_detected, marker="o")
            ax.set_xlabel("Check Number")
            ax.set_ylabel("Drift Detected")
            ax.set_title("Data Drift Detection History")
            ax.set_yticks([0, 1])
            ax.set_yticklabels(["No Drift", "Drift Detected"])
            ax.grid(True)

            return fig

        except ImportError:
            raise MLOpsError("matplotlib required for plotting")


# Made with Bob
