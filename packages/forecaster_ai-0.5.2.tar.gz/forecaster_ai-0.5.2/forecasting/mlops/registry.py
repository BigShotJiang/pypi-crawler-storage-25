"""Model registry for version management."""

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd

from forecasting.core.base import BaseForecaster
from forecasting.core.exceptions import MLOpsError


class ModelRegistry:
    """Model registry for versioning and management.

    Manages model versions, metadata, and lifecycle stages.

    Attributes:
        registry_path: Path to registry storage
        models: Dictionary of registered models
    """

    def __init__(self, registry_path: str = "./model_registry"):
        """Initialize model registry.

        Args:
            registry_path: Path to store registry data
        """
        self.registry_path = Path(registry_path)
        self.registry_path.mkdir(parents=True, exist_ok=True)

        self.metadata_file = self.registry_path / "registry.json"
        self.models: Dict[str, List[Dict[str, Any]]] = {}

        self._load_registry()

    def _load_registry(self) -> None:
        """Load registry from disk."""
        if self.metadata_file.exists():
            try:
                with open(self.metadata_file, "r") as f:
                    self.models = json.load(f)
            except Exception as e:
                raise MLOpsError(f"Failed to load registry: {str(e)}")

    def _save_registry(self) -> None:
        """Save registry to disk."""
        try:
            with open(self.metadata_file, "w") as f:
                json.dump(self.models, f, indent=2, default=str)
        except Exception as e:
            raise MLOpsError(f"Failed to save registry: {str(e)}")

    def register_model(
        self,
        model: BaseForecaster,
        model_name: str,
        version: Optional[str] = None,
        stage: str = "development",
        metrics: Optional[Dict[str, float]] = None,
        tags: Optional[Dict[str, str]] = None,
        description: Optional[str] = None,
    ) -> str:
        """Register a new model version.

        Args:
            model: Forecaster instance
            model_name: Name of the model
            version: Version string (auto-generated if None)
            stage: Lifecycle stage ('development', 'staging', 'production')
            metrics: Model metrics
            tags: Model tags
            description: Model description

        Returns:
            Version string
        """
        try:
            # Generate version if not provided
            if version is None:
                if model_name in self.models:
                    version = f"v{len(self.models[model_name]) + 1}"
                else:
                    version = "v1"

            # Create model directory
            model_dir = self.registry_path / model_name / version
            model_dir.mkdir(parents=True, exist_ok=True)

            # Save model
            model_path = model_dir / "model.pkl"
            model.save_model(str(model_path))

            # Create metadata
            metadata = {
                "model_name": model_name,
                "version": version,
                "stage": stage,
                "registered_at": datetime.now().isoformat(),
                "model_path": str(model_path),
                "model_class": model.__class__.__name__,
                "metrics": metrics or {},
                "tags": tags or {},
                "description": description or "",
            }

            # Save metadata
            metadata_path = model_dir / "metadata.json"
            with open(metadata_path, "w") as f:
                json.dump(metadata, f, indent=2, default=str)

            # Update registry
            if model_name not in self.models:
                self.models[model_name] = []

            self.models[model_name].append(metadata)
            self._save_registry()

            return version

        except Exception as e:
            raise MLOpsError(f"Failed to register model: {str(e)}")

    def load_model(
        self,
        model_name: str,
        version: Optional[str] = None,
        stage: Optional[str] = None,
    ) -> BaseForecaster:
        """Load a model from registry.

        Args:
            model_name: Name of the model
            version: Specific version to load
            stage: Load latest model in this stage

        Returns:
            Loaded forecaster instance
        """
        try:
            if model_name not in self.models:
                raise MLOpsError(f"Model {model_name} not found in registry")

            # Find the right version
            if version:
                # Load specific version
                metadata = next(
                    (m for m in self.models[model_name] if m["version"] == version), None
                )
            elif stage:
                # Load latest version in stage
                stage_models = [m for m in self.models[model_name] if m["stage"] == stage]
                if not stage_models:
                    raise MLOpsError(f"No models found in stage {stage} for {model_name}")
                metadata = stage_models[-1]
            else:
                # Load latest version
                metadata = self.models[model_name][-1]

            if metadata is None:
                raise MLOpsError(f"Version {version} not found for {model_name}")

            # Load model
            model_path = metadata["model_path"]
            model_class_name = metadata["model_class"]

            # Import the model class dynamically
            from forecasting import models

            model_class = getattr(models, model_class_name)

            return model_class.load_model(model_path)

        except Exception as e:
            raise MLOpsError(f"Failed to load model: {str(e)}")

    def update_stage(
        self,
        model_name: str,
        version: str,
        new_stage: str,
    ) -> None:
        """Update model stage.

        Args:
            model_name: Name of the model
            version: Version to update
            new_stage: New stage ('development', 'staging', 'production')
        """
        try:
            if model_name not in self.models:
                raise MLOpsError(f"Model {model_name} not found")

            # Find and update version
            for metadata in self.models[model_name]:
                if metadata["version"] == version:
                    metadata["stage"] = new_stage
                    metadata["stage_updated_at"] = datetime.now().isoformat()

                    # Update metadata file
                    model_dir = Path(metadata["model_path"]).parent
                    metadata_path = model_dir / "metadata.json"
                    with open(metadata_path, "w") as f:
                        json.dump(metadata, f, indent=2, default=str)

                    break

            self._save_registry()

        except Exception as e:
            raise MLOpsError(f"Failed to update stage: {str(e)}")

    def list_models(self, model_name: Optional[str] = None) -> pd.DataFrame:
        """List registered models.

        Args:
            model_name: Filter by model name

        Returns:
            DataFrame with model information
        """
        if model_name:
            if model_name not in self.models:
                return pd.DataFrame()
            models_list = self.models[model_name]
        else:
            models_list = [model for versions in self.models.values() for model in versions]

        if not models_list:
            return pd.DataFrame()

        return pd.DataFrame(models_list)

    def get_production_model(self, model_name: str) -> Optional[BaseForecaster]:
        """Get the production model.

        Args:
            model_name: Name of the model

        Returns:
            Production model or None
        """
        try:
            return self.load_model(model_name, stage="production")
        except MLOpsError:
            return None

    def delete_version(self, model_name: str, version: str) -> None:
        """Delete a model version.

        Args:
            model_name: Name of the model
            version: Version to delete
        """
        try:
            if model_name not in self.models:
                raise MLOpsError(f"Model {model_name} not found")

            # Find version
            metadata = next((m for m in self.models[model_name] if m["version"] == version), None)

            if metadata is None:
                raise MLOpsError(f"Version {version} not found")

            # Delete files
            model_dir = Path(metadata["model_path"]).parent
            if model_dir.exists():
                import shutil

                shutil.rmtree(model_dir)

            # Remove from registry
            self.models[model_name] = [
                m for m in self.models[model_name] if m["version"] != version
            ]

            # Remove model name if no versions left
            if not self.models[model_name]:
                del self.models[model_name]

            self._save_registry()

        except Exception as e:
            raise MLOpsError(f"Failed to delete version: {str(e)}")

    def compare_versions(
        self,
        model_name: str,
        metric: str = "rmse",
    ) -> pd.DataFrame:
        """Compare model versions by metric.

        Args:
            model_name: Name of the model
            metric: Metric to compare

        Returns:
            DataFrame with comparison
        """
        if model_name not in self.models:
            return pd.DataFrame()

        df = self.list_models(model_name)

        # Extract metric from metrics dict
        if "metrics" in df.columns:
            df[metric] = df["metrics"].apply(
                lambda x: x.get(metric, float("nan")) if isinstance(x, dict) else float("nan")
            )
            df = df.sort_values(metric)

        return df[["version", "stage", metric, "registered_at"]]


# Made with Bob
