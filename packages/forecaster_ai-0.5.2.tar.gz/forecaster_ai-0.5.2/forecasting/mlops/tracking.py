"""Experiment tracking with MLflow."""

import json
from pathlib import Path
from typing import Any, Dict, Optional

import pandas as pd

from forecasting.core.base import BaseForecaster
from forecasting.core.exceptions import MLOpsError


class ExperimentTracker:
    """MLflow experiment tracker for forecasting models.

    Tracks experiments, parameters, metrics, and artifacts using MLflow.

    Attributes:
        experiment_name: Name of the MLflow experiment
        tracking_uri: MLflow tracking server URI
        run_name: Name of the current run
    """

    def __init__(
        self,
        experiment_name: str = "forecasting",
        tracking_uri: Optional[str] = None,
        run_name: Optional[str] = None,
    ):
        """Initialize experiment tracker.

        Args:
            experiment_name: Name of the experiment
            tracking_uri: MLflow tracking server URI
            run_name: Name for the run
        """
        self.experiment_name = experiment_name
        self.tracking_uri = tracking_uri
        self.run_name = run_name
        self._mlflow = None
        self._active_run = None

        self._initialize_mlflow()

    def _initialize_mlflow(self) -> None:
        """Initialize MLflow."""
        try:
            import mlflow

            self._mlflow = mlflow

            if self.tracking_uri:
                mlflow.set_tracking_uri(self.tracking_uri)

            # Set or create experiment
            try:
                experiment = mlflow.get_experiment_by_name(self.experiment_name)
                if experiment is None:
                    mlflow.create_experiment(self.experiment_name)
            except Exception:
                mlflow.create_experiment(self.experiment_name)

            mlflow.set_experiment(self.experiment_name)

        except ImportError:
            raise MLOpsError(
                "mlflow package required for experiment tracking. "
                "Install with: pip install mlflow"
            )

    def start_run(self, run_name: Optional[str] = None) -> "ExperimentTracker":
        """Start a new MLflow run.

        Args:
            run_name: Name for the run

        Returns:
            Self for method chaining
        """
        if self._mlflow is None:
            raise MLOpsError("MLflow not initialized")

        run_name = run_name or self.run_name
        self._active_run = self._mlflow.start_run(run_name=run_name)

        return self

    def end_run(self) -> None:
        """End the current MLflow run."""
        if self._mlflow is None:
            raise MLOpsError("MLflow not initialized")

        if self._active_run:
            self._mlflow.end_run()
            self._active_run = None

    def log_params(self, params: Dict[str, Any]) -> "ExperimentTracker":
        """Log parameters to MLflow.

        Args:
            params: Dictionary of parameters

        Returns:
            Self for method chaining
        """
        if self._mlflow is None:
            raise MLOpsError("MLflow not initialized")

        for key, value in params.items():
            # Convert complex types to strings
            if isinstance(value, (dict, list)):
                value = json.dumps(value)
            self._mlflow.log_param(key, value)

        return self

    def log_metrics(
        self,
        metrics: Dict[str, float],
        step: Optional[int] = None,
    ) -> "ExperimentTracker":
        """Log metrics to MLflow.

        Args:
            metrics: Dictionary of metrics
            step: Optional step number

        Returns:
            Self for method chaining
        """
        if self._mlflow is None:
            raise MLOpsError("MLflow not initialized")

        for key, value in metrics.items():
            self._mlflow.log_metric(key, value, step=step)

        return self

    def log_model(
        self,
        model: BaseForecaster,
        artifact_path: str = "model",
    ) -> "ExperimentTracker":
        """Log model to MLflow.

        Args:
            model: Forecaster instance
            artifact_path: Path within the run's artifact directory

        Returns:
            Self for method chaining
        """
        if self._mlflow is None:
            raise MLOpsError("MLflow not initialized")

        try:
            # Save model temporarily
            import tempfile

            with tempfile.NamedTemporaryFile(suffix=".pkl", delete=False) as f:
                model.save_model(f.name)
                self._mlflow.log_artifact(f.name, artifact_path)

            # Clean up
            Path(f.name).unlink()

        except Exception as e:
            raise MLOpsError(f"Failed to log model: {str(e)}")

        return self

    def log_artifact(
        self,
        local_path: str,
        artifact_path: Optional[str] = None,
    ) -> "ExperimentTracker":
        """Log artifact to MLflow.

        Args:
            local_path: Local path to artifact
            artifact_path: Path within the run's artifact directory

        Returns:
            Self for method chaining
        """
        if self._mlflow is None:
            raise MLOpsError("MLflow not initialized")

        self._mlflow.log_artifact(local_path, artifact_path)

        return self

    def log_figure(
        self,
        figure: Any,
        artifact_file: str,
    ) -> "ExperimentTracker":
        """Log matplotlib figure to MLflow.

        Args:
            figure: Matplotlib figure
            artifact_file: Filename for the artifact

        Returns:
            Self for method chaining
        """
        if self._mlflow is None:
            raise MLOpsError("MLflow not initialized")

        self._mlflow.log_figure(figure, artifact_file)

        return self

    def log_dataframe(
        self,
        df: pd.DataFrame,
        artifact_file: str,
    ) -> "ExperimentTracker":
        """Log DataFrame to MLflow.

        Args:
            df: DataFrame to log
            artifact_file: Filename for the artifact

        Returns:
            Self for method chaining
        """
        if self._mlflow is None:
            raise MLOpsError("MLflow not initialized")

        import tempfile

        with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False) as f:
            df.to_csv(f.name, index=False)
            self._mlflow.log_artifact(f.name)

        Path(f.name).unlink()

        return self

    def log_dict(
        self,
        dictionary: Dict[str, Any],
        artifact_file: str,
    ) -> "ExperimentTracker":
        """Log dictionary as JSON to MLflow.

        Args:
            dictionary: Dictionary to log
            artifact_file: Filename for the artifact

        Returns:
            Self for method chaining
        """
        if self._mlflow is None:
            raise MLOpsError("MLflow not initialized")

        self._mlflow.log_dict(dictionary, artifact_file)

        return self

    def set_tags(self, tags: Dict[str, str]) -> "ExperimentTracker":
        """Set tags for the run.

        Args:
            tags: Dictionary of tags

        Returns:
            Self for method chaining
        """
        if self._mlflow is None:
            raise MLOpsError("MLflow not initialized")

        for key, value in tags.items():
            self._mlflow.set_tag(key, value)

        return self

    def __enter__(self) -> "ExperimentTracker":
        """Context manager entry."""
        self.start_run()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit."""
        self.end_run()


class ModelTracker:
    """Track model training and evaluation.

    Convenience wrapper around ExperimentTracker for common
    model tracking workflows.
    """

    def __init__(
        self,
        experiment_name: str = "forecasting",
        tracking_uri: Optional[str] = None,
    ):
        """Initialize model tracker.

        Args:
            experiment_name: Name of the experiment
            tracking_uri: MLflow tracking server URI
        """
        self.tracker = ExperimentTracker(
            experiment_name=experiment_name,
            tracking_uri=tracking_uri,
        )

    def track_training(
        self,
        model: BaseForecaster,
        model_name: str,
        params: Dict[str, Any],
        metrics: Dict[str, float],
        artifacts: Optional[Dict[str, Any]] = None,
        tags: Optional[Dict[str, str]] = None,
    ) -> str:
        """Track a complete training run.

        Args:
            model: Trained forecaster
            model_name: Name of the model
            params: Model parameters
            metrics: Evaluation metrics
            artifacts: Optional artifacts to log
            tags: Optional tags

        Returns:
            Run ID
        """
        with self.tracker as tracker:
            # Set tags
            run_tags = {"model_type": model_name}
            if tags:
                run_tags.update(tags)
            tracker.set_tags(run_tags)

            # Log parameters
            tracker.log_params(params)

            # Log metrics
            tracker.log_metrics(metrics)

            # Log model
            tracker.log_model(model)

            # Log artifacts
            if artifacts:
                for name, artifact in artifacts.items():
                    if isinstance(artifact, pd.DataFrame):
                        tracker.log_dataframe(artifact, f"{name}.csv")
                    elif isinstance(artifact, dict):
                        tracker.log_dict(artifact, f"{name}.json")
                    else:
                        # Assume it's a figure
                        tracker.log_figure(artifact, f"{name}.png")

            run_id = tracker._active_run.info.run_id if tracker._active_run else None

        return run_id

    def compare_models(
        self,
        results: Dict[str, Dict[str, float]],
        metric: str = "rmse",
    ) -> pd.DataFrame:
        """Compare multiple model runs.

        Args:
            results: Dictionary mapping model names to metrics
            metric: Primary metric for comparison

        Returns:
            DataFrame with comparison
        """
        df = pd.DataFrame(results).T

        if metric in df.columns:
            df = df.sort_values(metric)

        return df


# Made with Bob
