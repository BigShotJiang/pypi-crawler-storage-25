"""Pattern detection for time series data."""

from typing import Any, Dict, Optional, Tuple

import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.tsa.seasonal import seasonal_decompose
from statsmodels.tsa.stattools import acf, adfuller


def detect_pattern(
    data: pd.Series,
    seasonal_period: Optional[int] = None
) -> Dict[str, Any]:
    """Detect patterns in time series data.
    
    Detects:
    - Trend (increasing, decreasing, or none)
    - Seasonality (present or not, and period)
    - Intermittency (sparse or regular)
    - Stationarity
    
    Args:
        data: Time series data
        seasonal_period: Known seasonal period (auto-detected if None)
        
    Returns:
        Dictionary with pattern information
        
    Examples:
        >>> pattern = detect_pattern(sales_data)
        >>> print(pattern['has_trend'])
        True
        >>> print(pattern['has_seasonality'])
        True
        >>> print(pattern['seasonal_period'])
        7
    """
    result = {
        'has_trend': False,
        'trend_direction': 'none',
        'has_seasonality': False,
        'seasonal_period': None,
        'is_intermittent': False,
        'is_stationary': False,
        'zero_ratio': 0.0,
        'cv': 0.0
    }
    
    # Check for missing values
    if data.isnull().any():
        data = data.dropna()
    
    if len(data) < 10:
        return result
    
    # 1. Detect trend
    result['has_trend'], result['trend_direction'] = _detect_trend(data)
    
    # 2. Detect seasonality
    if seasonal_period is None:
        seasonal_period = _detect_seasonal_period(data)
    
    if seasonal_period is not None and seasonal_period > 1:
        result['has_seasonality'] = True
        result['seasonal_period'] = seasonal_period
    
    # 3. Detect intermittency
    result['is_intermittent'], result['zero_ratio'] = _detect_intermittency(data)
    
    # 4. Check stationarity
    result['is_stationary'] = _check_stationarity(data)
    
    # 5. Calculate coefficient of variation
    if data.mean() != 0:
        result['cv'] = data.std() / abs(data.mean())
    
    return result


def _detect_trend(data: pd.Series) -> Tuple[bool, str]:
    """Detect trend in time series.
    
    Args:
        data: Time series data
        
    Returns:
        Tuple of (has_trend, direction)
    """
    # Use linear regression to detect trend
    x = np.arange(len(data))
    y = data.values
    
    # Calculate slope
    slope, intercept, r_value, p_value, std_err = stats.linregress(x, y)
    
    # Significant trend if p-value < 0.05 and R² > 0.1
    has_trend = (p_value < 0.05) and (r_value ** 2 > 0.1)
    
    if has_trend:
        direction = 'increasing' if slope > 0 else 'decreasing'
    else:
        direction = 'none'
    
    return has_trend, direction


def _detect_seasonal_period(data: pd.Series, max_lag: Optional[int] = None) -> Optional[int]:
    """Detect seasonal period using autocorrelation.
    
    Args:
        data: Time series data
        max_lag: Maximum lag to check
        
    Returns:
        Detected period or None
    """
    if len(data) < 20:
        return None
    
    if max_lag is None:
        max_lag = min(len(data) // 2, 365)
    
    try:
        # Calculate autocorrelation
        autocorr = acf(data.values, nlags=max_lag, fft=True)
        
        # Find peaks in autocorrelation
        peaks = []
        for i in range(2, len(autocorr) - 1):
            if autocorr[i] > autocorr[i-1] and autocorr[i] > autocorr[i+1]:
                if autocorr[i] > 0.3:  # Threshold for significant peak
                    peaks.append((i, autocorr[i]))
        
        if peaks:
            # Return the lag with highest autocorrelation
            period = max(peaks, key=lambda x: x[1])[0]
            return int(period)
        
        return None
        
    except Exception:
        return None


def _detect_intermittency(data: pd.Series) -> Tuple[bool, float]:
    """Detect if series is intermittent (sparse).
    
    Args:
        data: Time series data
        
    Returns:
        Tuple of (is_intermittent, zero_ratio)
    """
    # Count zeros or very small values
    threshold = data.std() * 0.1 if data.std() > 0 else 0.01
    zero_count = (data.abs() < threshold).sum()
    zero_ratio = zero_count / len(data)
    
    # Consider intermittent if more than 25% are zeros/near-zeros
    is_intermittent = zero_ratio > 0.25
    
    return is_intermittent, float(zero_ratio)


def _check_stationarity(data: pd.Series, significance: float = 0.05) -> bool:
    """Check if series is stationary using Augmented Dickey-Fuller test.
    
    Args:
        data: Time series data
        significance: Significance level
        
    Returns:
        True if stationary, False otherwise
    """
    try:
        # Perform ADF test
        result = adfuller(data.dropna().values, autolag='AIC')
        p_value = result[1]
        
        # Stationary if p-value < significance level
        return p_value < significance
        
    except Exception:
        return False


def detect_seasonality(
    data: pd.Series,
    period: Optional[int] = None,
    model: str = 'additive'
) -> Dict[str, Any]:
    """Detect and decompose seasonality.
    
    Args:
        data: Time series data
        period: Seasonal period (auto-detected if None)
        model: 'additive' or 'multiplicative'
        
    Returns:
        Dictionary with seasonality information
    """
    result = {
        'has_seasonality': False,
        'seasonal_period': None,
        'seasonal_strength': 0.0,
        'trend_strength': 0.0
    }
    
    if len(data) < 20:
        return result
    
    # Detect period if not provided
    if period is None:
        period = _detect_seasonal_period(data)
    
    if period is None or period < 2:
        return result
    
    try:
        # Perform seasonal decomposition
        decomposition = seasonal_decompose(
            data,
            model=model,
            period=period,
            extrapolate_trend='freq'
        )
        
        # Calculate seasonal strength
        seasonal_var = np.var(decomposition.seasonal.dropna())
        residual_var = np.var(decomposition.resid.dropna())
        
        if seasonal_var + residual_var > 0:
            seasonal_strength = seasonal_var / (seasonal_var + residual_var)
        else:
            seasonal_strength = 0.0
        
        # Calculate trend strength
        trend_var = np.var(decomposition.trend.dropna())
        if trend_var + residual_var > 0:
            trend_strength = trend_var / (trend_var + residual_var)
        else:
            trend_strength = 0.0
        
        result['has_seasonality'] = seasonal_strength > 0.3
        result['seasonal_period'] = period
        result['seasonal_strength'] = float(seasonal_strength)
        result['trend_strength'] = float(trend_strength)
        
    except Exception:
        pass
    
    return result


# Made with Bob