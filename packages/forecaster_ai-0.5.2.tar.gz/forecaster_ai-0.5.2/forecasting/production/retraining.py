"""Automatic model retraining based on performance degradation."""

from typing import Any, Dict, List, Optional
from datetime import datetime, timedelta

import numpy as np
import pandas as pd

from forecasting.core.base import BaseForecaster
from forecasting.core.exceptions import ModelError
from forecasting.evaluation.metrics import calculate_metrics


class AutoRetrainer:
    """Automatic model retraining based on performance monitoring.
    
    Monitors model performance and triggers retraining when:
    - Performance degrades below threshold
    - Sufficient new data is available
    - Scheduled retraining interval is reached
    
    Examples
    --------
    >>> from forecasting.production import AutoRetrainer
    >>> 
    >>> # Create retrainer
    >>> retrainer = AutoRetrainer(
    ...     performance_threshold=0.15,  # 15% degradation triggers retrain
    ...     min_samples_for_retrain=100,
    ...     retrain_interval_days=30
    ... )
    >>> 
    >>> # Check if retraining is needed
    >>> if retrainer.should_retrain(current_mae, baseline_mae, new_data):
    ...     new_model = retrainer.retrain(model, new_data)
    """
    
    def __init__(
        self,
        performance_threshold: float = 0.15,
        min_samples_for_retrain: int = 100,
        retrain_interval_days: int = 30,
        metric: str = 'mae'
    ):
        """Initialize auto retrainer.
        
        Args:
            performance_threshold: Relative performance degradation threshold (0.15 = 15%)
            min_samples_for_retrain: Minimum new samples needed for retraining
            retrain_interval_days: Days between scheduled retraining
            metric: Metric to monitor ('mae', 'rmse', 'mape')
        """
        self.performance_threshold = performance_threshold
        self.min_samples_for_retrain = min_samples_for_retrain
        self.retrain_interval_days = retrain_interval_days
        self.metric = metric
        
        self.retrain_history: List[Dict[str, Any]] = []
        self.last_retrain_date: Optional[datetime] = None
    
    def should_retrain(
        self,
        current_performance: float,
        baseline_performance: float,
        new_data: pd.Series,
        last_retrain_date: Optional[datetime] = None
    ) -> Dict[str, Any]:
        """Determine if model should be retrained.
        
        Args:
            current_performance: Current model performance metric
            baseline_performance: Baseline (training) performance metric
            new_data: New data available for retraining
            last_retrain_date: Date of last retraining
            
        Returns:
            Dictionary with decision and reasons
            
        Examples
        --------
        >>> decision = retrainer.should_retrain(
        ...     current_mae=12.5,
        ...     baseline_mae=10.0,
        ...     new_data=recent_data
        ... )
        >>> if decision['should_retrain']:
        ...     print(f"Retrain because: {decision['reasons']}")
        """
        reasons = []
        should_retrain = False
        
        # Check 1: Performance degradation
        if baseline_performance > 0:
            degradation = (current_performance - baseline_performance) / baseline_performance
            if degradation > self.performance_threshold:
                reasons.append(
                    f"Performance degraded by {degradation*100:.1f}% "
                    f"(threshold: {self.performance_threshold*100:.1f}%)"
                )
                should_retrain = True
        
        # Check 2: Sufficient new data
        if len(new_data) < self.min_samples_for_retrain:
            if should_retrain:
                reasons.append(
                    f"But insufficient data: {len(new_data)} samples "
                    f"(need {self.min_samples_for_retrain})"
                )
                should_retrain = False
        else:
            reasons.append(f"Sufficient new data: {len(new_data)} samples")
        
        # Check 3: Scheduled retraining
        if last_retrain_date is not None:
            days_since_retrain = (datetime.now() - last_retrain_date).days
            if days_since_retrain >= self.retrain_interval_days:
                reasons.append(
                    f"Scheduled retrain: {days_since_retrain} days since last retrain "
                    f"(interval: {self.retrain_interval_days} days)"
                )
                should_retrain = True
        
        return {
            'should_retrain': should_retrain,
            'reasons': reasons,
            'current_performance': current_performance,
            'baseline_performance': baseline_performance,
            'degradation_pct': ((current_performance - baseline_performance) / baseline_performance * 100) 
                              if baseline_performance > 0 else 0,
            'new_samples': len(new_data)
        }
    
    def retrain(
        self,
        model: BaseForecaster,
        new_data: pd.Series,
        X_new: Optional[pd.DataFrame] = None,
        combine_with_old: bool = True,
        old_data: Optional[pd.Series] = None,
        X_old: Optional[pd.DataFrame] = None,
        **fit_kwargs: Any
    ) -> BaseForecaster:
        """Retrain model with new data.
        
        Args:
            model: Existing model to retrain
            new_data: New training data
            X_new: New exogenous variables
            combine_with_old: Whether to combine with old training data
            old_data: Old training data (if combining)
            X_old: Old exogenous variables (if combining)
            **fit_kwargs: Additional arguments for model fitting
            
        Returns:
            Retrained model
            
        Examples
        --------
        >>> new_model = retrainer.retrain(
        ...     model=current_model,
        ...     new_data=recent_data,
        ...     combine_with_old=True,
        ...     old_data=training_data
        ... )
        """
        try:
            # Combine data if requested
            if combine_with_old and old_data is not None:
                combined_data = pd.concat([old_data, new_data])
                if X_new is not None and X_old is not None:
                    combined_X = pd.concat([X_old, X_new])
                else:
                    combined_X = X_new
            else:
                combined_data = new_data
                combined_X = X_new
            
            # Create new model instance with same config
            new_model = model.__class__(model.config)
            
            # Retrain
            new_model.fit(combined_data, combined_X, **fit_kwargs)
            
            # Record retraining
            self.retrain_history.append({
                'timestamp': datetime.now(),
                'model_type': model.__class__.__name__,
                'training_samples': len(combined_data),
                'new_samples': len(new_data)
            })
            self.last_retrain_date = datetime.now()
            
            return new_model
            
        except Exception as e:
            raise ModelError(f"Failed to retrain model: {str(e)}")
    
    def get_retrain_history(self) -> pd.DataFrame:
        """Get history of retraining events.
        
        Returns:
            DataFrame with retraining history
        """
        if not self.retrain_history:
            return pd.DataFrame()
        
        return pd.DataFrame(self.retrain_history)
    
    def monitor_performance(
        self,
        model: BaseForecaster,
        test_data: pd.Series,
        X_test: Optional[pd.DataFrame] = None,
        baseline_performance: Optional[float] = None
    ) -> Dict[str, Any]:
        """Monitor current model performance.
        
        Args:
            model: Model to monitor
            test_data: Test data for evaluation
            X_test: Test exogenous variables
            baseline_performance: Baseline performance to compare against
            
        Returns:
            Dictionary with performance metrics and status
        """
        try:
            # Generate predictions
            forecast, _ = model.predict(horizon=len(test_data), X=X_test)
            
            # Calculate metrics
            metrics = calculate_metrics(test_data, forecast)
            current_performance = metrics[self.metric]
            
            # Check if retraining needed
            if baseline_performance is not None:
                decision = self.should_retrain(
                    current_performance,
                    baseline_performance,
                    test_data,
                    self.last_retrain_date
                )
            else:
                decision = {'should_retrain': False, 'reasons': ['No baseline available']}
            
            return {
                'current_performance': current_performance,
                'baseline_performance': baseline_performance,
                'all_metrics': metrics,
                'retrain_decision': decision,
                'timestamp': datetime.now()
            }
            
        except Exception as e:
            raise ModelError(f"Failed to monitor performance: {str(e)}")


# Made with Bob