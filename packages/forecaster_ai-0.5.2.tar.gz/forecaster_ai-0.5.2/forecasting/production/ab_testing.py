"""A/B testing framework for forecasting models."""

from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from scipy import stats

from forecasting.core.base import BaseForecaster
from forecasting.core.exceptions import ModelError
from forecasting.evaluation.metrics import calculate_metrics


class ABTestFramework:
    """A/B testing framework for comparing forecasting models.
    
    Provides statistical testing to determine if one model significantly
    outperforms another on production data.
    
    Features:
    - Statistical significance testing
    - Multiple comparison correction
    - Performance tracking over time
    - Champion/challenger model comparison
    
    Examples
    --------
    >>> from forecasting.production import ABTestFramework
    >>> 
    >>> # Create A/B test
    >>> ab_test = ABTestFramework()
    >>> 
    >>> # Compare two models
    >>> result = ab_test.run_ab_test(
    ...     model_a=current_model,
    ...     model_b=new_model,
    ...     test_data=test_data,
    ...     metric='mae'
    ... )
    >>> 
    >>> if result['is_significant']:
    ...     print(f"Model B is significantly better (p={result['p_value']:.4f})")
    """
    
    def __init__(
        self,
        significance_level: float = 0.05,
        min_sample_size: int = 30,
    ):
        """Initialize A/B testing framework.
        
        Args:
            significance_level: Significance level for hypothesis testing
            min_sample_size: Minimum sample size for valid test
        """
        self.significance_level = significance_level
        self.min_sample_size = min_sample_size
        self.test_history: List[Dict[str, Any]] = []
    
    def run_ab_test(
        self,
        model_a: BaseForecaster,
        model_b: BaseForecaster,
        test_data: pd.Series,
        X_test: Optional[pd.DataFrame] = None,
        metric: str = 'mae',
        test_name: Optional[str] = None
    ) -> Dict[str, Any]:
        """Run A/B test comparing two models.
        
        Args:
            model_a: First model (e.g., current production model)
            model_b: Second model (e.g., challenger model)
            test_data: Test data for evaluation
            X_test: Optional exogenous variables
            metric: Metric to compare ('mae', 'rmse', 'mape', etc.)
            test_name: Optional name for the test
            
        Returns:
            Dictionary with test results
            
        Examples
        --------
        >>> result = ab_test.run_ab_test(
        ...     model_a=current_model,
        ...     model_b=new_model,
        ...     test_data=test_data,
        ...     metric='mae'
        ... )
        >>> print(f"Winner: {result['winner']}")
        >>> print(f"P-value: {result['p_value']:.4f}")
        """
        if len(test_data) < self.min_sample_size:
            raise ValueError(
                f"Test data too small. Need at least {self.min_sample_size} samples, "
                f"got {len(test_data)}"
            )
        
        # Generate forecasts
        forecast_a, _ = model_a.predict(horizon=len(test_data), X=X_test)
        forecast_b, _ = model_b.predict(horizon=len(test_data), X=X_test)
        
        # Calculate errors
        errors_a = self._calculate_errors(test_data, forecast_a, metric)
        errors_b = self._calculate_errors(test_data, forecast_b, metric)
        
        # Perform statistical test
        statistic, p_value = self._perform_statistical_test(errors_a, errors_b)
        
        # Determine winner
        mean_a = np.mean(errors_a)
        mean_b = np.mean(errors_b)
        is_significant = p_value < self.significance_level
        
        # For error metrics, lower is better
        if mean_b < mean_a and is_significant:
            winner = 'model_b'
            improvement = ((mean_a - mean_b) / mean_a) * 100
        elif mean_a < mean_b and is_significant:
            winner = 'model_a'
            improvement = ((mean_b - mean_a) / mean_b) * 100
        else:
            winner = 'tie'
            improvement = 0.0
        
        result = {
            'test_name': test_name or f'test_{len(self.test_history) + 1}',
            'metric': metric,
            'model_a_score': mean_a,
            'model_b_score': mean_b,
            'statistic': statistic,
            'p_value': p_value,
            'is_significant': is_significant,
            'winner': winner,
            'improvement_pct': improvement,
            'sample_size': len(test_data)
        }
        
        # Store in history
        self.test_history.append(result)
        
        return result
    
    def _calculate_errors(
        self,
        actuals: pd.Series,
        forecast: pd.Series,
        metric: str
    ) -> np.ndarray:
        """Calculate errors for a given metric.
        
        Args:
            actuals: Actual values
            forecast: Forecasted values
            metric: Metric name
            
        Returns:
            Array of errors
        """
        if metric == 'mae':
            return np.abs(actuals.values - forecast.values)
        elif metric == 'mse':
            return (actuals.values - forecast.values) ** 2
        elif metric == 'rmse':
            return (actuals.values - forecast.values) ** 2
        elif metric == 'mape':
            return np.abs((actuals.values - forecast.values) / actuals.values) * 100
        else:
            raise ValueError(f"Unknown metric: {metric}")
    
    def _perform_statistical_test(
        self,
        errors_a: np.ndarray,
        errors_b: np.ndarray
    ) -> Tuple[float, float]:
        """Perform statistical test on errors.
        
        Args:
            errors_a: Errors from model A
            errors_b: Errors from model B
            
        Returns:
            Tuple of (statistic, p_value)
        """
        # Use paired t-test (since same test data)
        statistic, p_value = stats.ttest_rel(errors_a, errors_b)
        
        return float(statistic), float(p_value)
    
    def run_multiple_tests(
        self,
        models: Dict[str, BaseForecaster],
        test_data: pd.Series,
        X_test: Optional[pd.DataFrame] = None,
        metric: str = 'mae'
    ) -> pd.DataFrame:
        """Run pairwise A/B tests for multiple models.
        
        Args:
            models: Dictionary of models {name: model}
            test_data: Test data
            X_test: Optional exogenous variables
            metric: Metric to compare
            
        Returns:
            DataFrame with pairwise comparison results
        """
        model_names = list(models.keys())
        results = []
        
        for i, name_a in enumerate(model_names):
            for name_b in model_names[i+1:]:
                result = self.run_ab_test(
                    model_a=models[name_a],
                    model_b=models[name_b],
                    test_data=test_data,
                    X_test=X_test,
                    metric=metric,
                    test_name=f'{name_a}_vs_{name_b}'
                )
                results.append(result)
        
        return pd.DataFrame(results)
    
    def get_test_history(self) -> pd.DataFrame:
        """Get history of all A/B tests.
        
        Returns:
            DataFrame with test history
        """
        if not self.test_history:
            return pd.DataFrame()
        
        return pd.DataFrame(self.test_history)
    
    def champion_challenger_test(
        self,
        champion: BaseForecaster,
        challenger: BaseForecaster,
        test_data: pd.Series,
        X_test: Optional[pd.DataFrame] = None,
        metrics: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """Run champion vs challenger test across multiple metrics.
        
        Args:
            champion: Current production model
            challenger: New model to test
            test_data: Test data
            X_test: Optional exogenous variables
            metrics: List of metrics to compare
            
        Returns:
            Dictionary with comprehensive comparison results
        """
        if metrics is None:
            metrics = ['mae', 'rmse', 'mape']
        
        results = {}
        wins = {'champion': 0, 'challenger': 0, 'tie': 0}
        
        for metric in metrics:
            result = self.run_ab_test(
                model_a=champion,
                model_b=challenger,
                test_data=test_data,
                X_test=X_test,
                metric=metric,
                test_name=f'champion_vs_challenger_{metric}'
            )
            results[metric] = result
            
            if result['winner'] == 'model_a':
                wins['champion'] += 1
            elif result['winner'] == 'model_b':
                wins['challenger'] += 1
            else:
                wins['tie'] += 1
        
        # Determine overall winner
        if wins['challenger'] > wins['champion']:
            overall_winner = 'challenger'
            recommendation = 'PROMOTE challenger to production'
        elif wins['champion'] > wins['challenger']:
            overall_winner = 'champion'
            recommendation = 'KEEP champion in production'
        else:
            overall_winner = 'tie'
            recommendation = 'INCONCLUSIVE - need more data or different metrics'
        
        return {
            'metric_results': results,
            'wins': wins,
            'overall_winner': overall_winner,
            'recommendation': recommendation
        }


# Made with Bob