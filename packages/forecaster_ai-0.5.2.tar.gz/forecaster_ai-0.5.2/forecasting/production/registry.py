"""Model registry for version management and deployment."""

import json
import pickle
from typing import Any, Dict, List, Optional
from datetime import datetime
from pathlib import Path

import pandas as pd

from forecasting.core.base import BaseForecaster
from forecasting.core.exceptions import ModelError


class ModelRegistry:
    """Centralized model registry for version management.
    
    Manages model lifecycle:
    - Registration with metadata
    - Version tracking
    - Production promotion
    - Model retrieval
    - Rollback capabilities
    
    Examples
    --------
    >>> from forecasting.production import ModelRegistry
    >>> 
    >>> # Create registry
    >>> registry = ModelRegistry(storage_path='./models')
    >>> 
    >>> # Register a model
    >>> model_id = registry.register_model(
    ...     model=trained_model,
    ...     metadata={
    ...         'name': 'sales_forecaster_v1',
    ...         'description': 'ARIMA model for sales forecasting',
    ...         'metrics': {'mae': 10.5, 'rmse': 15.2}
    ...     }
    ... )
    >>> 
    >>> # Promote to production
    >>> registry.promote_model(model_id)
    >>> 
    >>> # Get production model
    >>> prod_model = registry.get_production_model()
    """
    
    def __init__(self, storage_path: str = './model_registry'):
        """Initialize model registry.
        
        Args:
            storage_path: Path to store models and metadata
        """
        self.storage_path = Path(storage_path)
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        self.models_path = self.storage_path / 'models'
        self.models_path.mkdir(exist_ok=True)
        
        self.metadata_path = self.storage_path / 'metadata.json'
        self.metadata = self._load_metadata()
    
    def _load_metadata(self) -> Dict[str, Any]:
        """Load registry metadata."""
        if self.metadata_path.exists():
            with open(self.metadata_path, 'r') as f:
                return json.load(f)
        return {
            'models': {},
            'production_model_id': None,
            'version_counter': 0
        }
    
    def _save_metadata(self) -> None:
        """Save registry metadata."""
        with open(self.metadata_path, 'w') as f:
            json.dump(self.metadata, f, indent=2, default=str)
    
    def register_model(
        self,
        model: BaseForecaster,
        metadata: Optional[Dict[str, Any]] = None
    ) -> str:
        """Register a new model.
        
        Args:
            model: Trained model to register
            metadata: Model metadata (name, description, metrics, etc.)
            
        Returns:
            Model ID
            
        Examples
        --------
        >>> model_id = registry.register_model(
        ...     model=trained_model,
        ...     metadata={
        ...         'name': 'arima_v1',
        ...         'description': 'Initial ARIMA model',
        ...         'metrics': {'mae': 10.5},
        ...         'training_data_size': 1000
        ...     }
        ... )
        """
        try:
            # Generate model ID
            self.metadata['version_counter'] += 1
            model_id = f"model_{self.metadata['version_counter']:04d}"
            
            # Save model
            model_file = self.models_path / f"{model_id}.pkl"
            with open(model_file, 'wb') as f:
                pickle.dump(model, f)
            
            # Store metadata
            model_metadata = {
                'model_id': model_id,
                'model_type': model.__class__.__name__,
                'registered_at': datetime.now().isoformat(),
                'status': 'registered',
                'model_file': str(model_file),
                'is_production': False
            }
            
            if metadata:
                model_metadata.update(metadata)
            
            self.metadata['models'][model_id] = model_metadata
            self._save_metadata()
            
            return model_id
            
        except Exception as e:
            raise ModelError(f"Failed to register model: {str(e)}")
    
    def get_model(self, model_id: str) -> BaseForecaster:
        """Retrieve a model by ID.
        
        Args:
            model_id: Model ID
            
        Returns:
            Loaded model
        """
        if model_id not in self.metadata['models']:
            raise ModelError(f"Model {model_id} not found in registry")
        
        try:
            model_file = self.metadata['models'][model_id]['model_file']
            with open(model_file, 'rb') as f:
                model = pickle.load(f)
            return model
            
        except Exception as e:
            raise ModelError(f"Failed to load model {model_id}: {str(e)}")
    
    def get_production_model(self) -> Optional[BaseForecaster]:
        """Get current production model.
        
        Returns:
            Production model or None if no model is in production
        """
        prod_model_id = self.metadata.get('production_model_id')
        if prod_model_id is None:
            return None
        
        return self.get_model(prod_model_id)
    
    def promote_model(self, model_id: str) -> None:
        """Promote a model to production.
        
        Args:
            model_id: Model ID to promote
            
        Examples
        --------
        >>> registry.promote_model('model_0005')
        """
        if model_id not in self.metadata['models']:
            raise ModelError(f"Model {model_id} not found in registry")
        
        # Demote current production model
        old_prod_id = self.metadata.get('production_model_id')
        if old_prod_id and old_prod_id in self.metadata['models']:
            self.metadata['models'][old_prod_id]['is_production'] = False
            self.metadata['models'][old_prod_id]['demoted_at'] = datetime.now().isoformat()
        
        # Promote new model
        self.metadata['models'][model_id]['is_production'] = True
        self.metadata['models'][model_id]['promoted_at'] = datetime.now().isoformat()
        self.metadata['models'][model_id]['status'] = 'production'
        self.metadata['production_model_id'] = model_id
        
        self._save_metadata()
    
    def rollback(self) -> Optional[str]:
        """Rollback to previous production model.
        
        Returns:
            Previous model ID or None
        """
        # Find previous production model
        production_models = [
            (mid, meta) for mid, meta in self.metadata['models'].items()
            if meta.get('demoted_at') is not None
        ]
        
        if not production_models:
            return None
        
        # Sort by demotion date and get most recent
        production_models.sort(key=lambda x: x[1]['demoted_at'], reverse=True)
        prev_model_id = production_models[0][0]
        
        # Promote previous model
        self.promote_model(prev_model_id)
        
        return prev_model_id
    
    def list_models(
        self,
        status: Optional[str] = None,
        model_type: Optional[str] = None
    ) -> pd.DataFrame:
        """List all registered models.
        
        Args:
            status: Filter by status ('registered', 'production', etc.)
            model_type: Filter by model type
            
        Returns:
            DataFrame with model information
        """
        models_list = []
        
        for model_id, metadata in self.metadata['models'].items():
            if status and metadata.get('status') != status:
                continue
            if model_type and metadata.get('model_type') != model_type:
                continue
            
            models_list.append(metadata)
        
        if not models_list:
            return pd.DataFrame()
        
        return pd.DataFrame(models_list)
    
    def delete_model(self, model_id: str, force: bool = False) -> None:
        """Delete a model from registry.
        
        Args:
            model_id: Model ID to delete
            force: Force deletion even if model is in production
        """
        if model_id not in self.metadata['models']:
            raise ModelError(f"Model {model_id} not found in registry")
        
        # Check if production model
        if self.metadata['models'][model_id].get('is_production') and not force:
            raise ModelError(
                f"Cannot delete production model {model_id}. "
                "Use force=True to override or demote first."
            )
        
        # Delete model file
        model_file = Path(self.metadata['models'][model_id]['model_file'])
        if model_file.exists():
            model_file.unlink()
        
        # Remove from metadata
        del self.metadata['models'][model_id]
        
        # Update production model ID if needed
        if self.metadata.get('production_model_id') == model_id:
            self.metadata['production_model_id'] = None
        
        self._save_metadata()
    
    def get_model_metadata(self, model_id: str) -> Dict[str, Any]:
        """Get metadata for a specific model.
        
        Args:
            model_id: Model ID
            
        Returns:
            Model metadata dictionary
        """
        if model_id not in self.metadata['models']:
            raise ModelError(f"Model {model_id} not found in registry")
        
        return self.metadata['models'][model_id].copy()
    
    def update_model_metadata(
        self,
        model_id: str,
        metadata_updates: Dict[str, Any]
    ) -> None:
        """Update metadata for a model.
        
        Args:
            model_id: Model ID
            metadata_updates: Dictionary of metadata updates
        """
        if model_id not in self.metadata['models']:
            raise ModelError(f"Model {model_id} not found in registry")
        
        self.metadata['models'][model_id].update(metadata_updates)
        self.metadata['models'][model_id]['updated_at'] = datetime.now().isoformat()
        self._save_metadata()


# Made with Bob