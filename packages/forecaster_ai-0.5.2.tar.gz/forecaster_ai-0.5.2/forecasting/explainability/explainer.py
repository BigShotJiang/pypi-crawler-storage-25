"""Model explainability using SHAP and feature importance."""

from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from forecasting.core.base import BaseForecaster
from forecasting.core.exceptions import ModelError


class ModelExplainer:
    """Model explainability using SHAP values and feature importance.
    
    Provides interpretability for forecasting models through:
    - SHAP (SHapley Additive exPlanations) values
    - Feature importance rankings
    - Contribution analysis
    - Visualization of explanations
    
    Examples
    --------
    >>> from forecasting.explainability import ModelExplainer
    >>> from forecasting.models import LSTMForecaster
    >>> 
    >>> # Train model
    >>> model = LSTMForecaster(config)
    >>> model.fit(train_data, X=features)
    >>> 
    >>> # Create explainer
    >>> explainer = ModelExplainer(model)
    >>> 
    >>> # Get SHAP values
    >>> shap_values = explainer.explain_forecast(test_features)
    >>> 
    >>> # Plot feature importance
    >>> explainer.plot_feature_importance()
    """
    
    def __init__(
        self,
        model: BaseForecaster,
        background_data: Optional[pd.DataFrame] = None,
    ):
        """Initialize model explainer.
        
        Args:
            model: Fitted forecasting model
            background_data: Background data for SHAP (optional)
        """
        self.model = model
        self.background_data = background_data
        self.shap_values_: Optional[np.ndarray] = None
        self.feature_importance_: Optional[pd.Series] = None
        
        # Check if SHAP is available
        try:
            import shap
            self.shap_available = True
        except ImportError:
            self.shap_available = False
    
    def explain_forecast(
        self,
        data: pd.DataFrame,
        method: str = 'shap'
    ) -> np.ndarray:
        """Generate explanations for forecasts.
        
        Args:
            data: Input features to explain
            method: Explanation method ('shap', 'permutation', 'lime')
            
        Returns:
            Array of explanation values
            
        Raises:
            ModelError: If explanation method is not available
        """
        if method == 'shap':
            return self._explain_with_shap(data)
        elif method == 'permutation':
            return self._explain_with_permutation(data)
        elif method == 'lime':
            return self._explain_with_lime(data)
        else:
            raise ValueError(f"Unknown explanation method: {method}")
    
    def _explain_with_shap(self, data: pd.DataFrame) -> np.ndarray:
        """Explain using SHAP values.
        
        Args:
            data: Input features
            
        Returns:
            SHAP values
        """
        if not self.shap_available:
            raise ModelError(
                "SHAP not available. Install with: pip install shap"
            )
        
        import shap
        
        try:
            # Create SHAP explainer
            if self.background_data is not None:
                explainer = shap.KernelExplainer(
                    self.model.predict,
                    self.background_data
                )
            else:
                # Use sample of data as background
                background = shap.sample(data, min(100, len(data)))
                explainer = shap.KernelExplainer(
                    self.model.predict,
                    background
                )
            
            # Calculate SHAP values
            shap_values = explainer.shap_values(data)
            self.shap_values_ = shap_values
            
            return shap_values
            
        except Exception as e:
            raise ModelError(f"Failed to calculate SHAP values: {str(e)}")
    
    def _explain_with_permutation(
        self,
        data: pd.DataFrame
    ) -> np.ndarray:
        """Explain using permutation importance.
        
        Args:
            data: Input features
            
        Returns:
            Permutation importance values
        """
        from sklearn.inspection import permutation_importance
        
        # Get baseline predictions
        baseline_pred = self.model.predict(horizon=1, X=data)[0]
        
        # Calculate permutation importance
        importance = []
        for col in data.columns:
            # Permute column
            data_permuted = data.copy()
            data_permuted[col] = np.random.permutation(data_permuted[col])
            
            # Get predictions with permuted feature
            permuted_pred = self.model.predict(horizon=1, X=data_permuted)[0]
            
            # Calculate importance as change in prediction
            importance.append(np.mean(np.abs(baseline_pred - permuted_pred)))
        
        return np.array(importance)
    
    def _explain_with_lime(self, data: pd.DataFrame) -> np.ndarray:
        """Explain using LIME.
        
        Args:
            data: Input features
            
        Returns:
            LIME explanation values
        """
        try:
            from lime import lime_tabular
            
            # Create LIME explainer
            explainer = lime_tabular.LimeTabularExplainer(
                data.values,
                feature_names=data.columns.tolist(),
                mode='regression'
            )
            
            # Explain first instance
            exp = explainer.explain_instance(
                data.iloc[0].values,
                lambda x: self.model.predict(
                    horizon=1,
                    X=pd.DataFrame([x], columns=data.columns)
                )[0].values
            )
            
            # Extract feature importance
            importance = dict(exp.as_list())
            return np.array([importance.get(col, 0) for col in data.columns])
            
        except ImportError:
            raise ModelError(
                "LIME not available. Install with: pip install lime"
            )
    
    def calculate_feature_importance(
        self,
        data: pd.DataFrame,
        method: str = 'shap'
    ) -> pd.Series:
        """Calculate feature importance.
        
        Args:
            data: Input features
            method: Method to use ('shap', 'permutation')
            
        Returns:
            Series with feature importance scores
        """
        if method == 'shap':
            if self.shap_values_ is None:
                self._explain_with_shap(data)
            
            # Calculate mean absolute SHAP values
            importance = np.abs(self.shap_values_).mean(axis=0)
        else:
            importance = self._explain_with_permutation(data)
        
        self.feature_importance_ = pd.Series(
            importance,
            index=data.columns
        ).sort_values(ascending=False)
        
        return self.feature_importance_
    
    def plot_feature_importance(
        self,
        top_n: int = 10,
        figsize: Tuple[int, int] = (10, 6),
        save_path: Optional[str] = None
    ) -> plt.Figure:
        """Plot feature importance.
        
        Args:
            top_n: Number of top features to show
            figsize: Figure size
            save_path: Path to save figure
            
        Returns:
            Matplotlib figure
        """
        if self.feature_importance_ is None:
            raise ModelError(
                "Feature importance not calculated. "
                "Call calculate_feature_importance() first."
            )
        
        fig, ax = plt.subplots(figsize=figsize)
        
        # Plot top N features
        top_features = self.feature_importance_.head(top_n)
        top_features.plot(kind='barh', ax=ax, color='steelblue')
        
        ax.set_xlabel('Importance', fontsize=12, fontweight='bold')
        ax.set_ylabel('Feature', fontsize=12, fontweight='bold')
        ax.set_title(
            f'Top {top_n} Feature Importance',
            fontsize=14,
            fontweight='bold'
        )
        ax.grid(True, alpha=0.3, axis='x')
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
            print(f"✓ Feature importance plot saved to {save_path}")
        
        return fig
    
    def plot_shap_summary(
        self,
        data: pd.DataFrame,
        figsize: Tuple[int, int] = (10, 8),
        save_path: Optional[str] = None
    ) -> None:
        """Plot SHAP summary.
        
        Args:
            data: Input features
            figsize: Figure size
            save_path: Path to save figure
        """
        if not self.shap_available:
            raise ModelError(
                "SHAP not available. Install with: pip install shap"
            )
        
        if self.shap_values_ is None:
            self._explain_with_shap(data)
        
        import shap
        
        plt.figure(figsize=figsize)
        shap.summary_plot(
            self.shap_values_,
            data,
            show=False
        )
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
            print(f"✓ SHAP summary plot saved to {save_path}")
        
        plt.show()


# Made with Bob