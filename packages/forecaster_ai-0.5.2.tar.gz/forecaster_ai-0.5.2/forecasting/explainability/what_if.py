"""What-if analysis for forecasting models."""

from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from forecasting.core.base import BaseForecaster
from forecasting.core.exceptions import ModelError


class WhatIfAnalyzer:
    """What-if scenario analysis for forecasting models.
    
    Allows testing different scenarios by modifying input features
    and observing the impact on forecasts.
    
    Features:
    - Single feature sensitivity analysis
    - Multi-feature scenario testing
    - Comparative scenario visualization
    - Impact quantification
    
    Examples
    --------
    >>> from forecasting.explainability import WhatIfAnalyzer
    >>> 
    >>> # Create analyzer
    >>> analyzer = WhatIfAnalyzer(model)
    >>> 
    >>> # Test scenario: increase price by 10%
    >>> scenario = {'price': base_data['price'] * 1.1}
    >>> forecast = analyzer.analyze_scenario(base_data, scenario)
    >>> 
    >>> # Sensitivity analysis
    >>> sensitivity = analyzer.sensitivity_analysis(
    ...     base_data,
    ...     feature='price',
    ...     range_pct=0.2
    ... )
    """
    
    def __init__(self, model: BaseForecaster):
        """Initialize what-if analyzer.
        
        Args:
            model: Fitted forecasting model
        """
        self.model = model
        if not model.is_fitted:
            raise ModelError("Model must be fitted before what-if analysis")
    
    def analyze_scenario(
        self,
        base_data: pd.DataFrame,
        changes: Dict[str, Any],
        horizon: Optional[int] = None
    ) -> pd.Series:
        """Analyze impact of changes to input features.
        
        Args:
            base_data: Base input features
            changes: Dictionary of feature changes {feature_name: new_value}
            horizon: Forecast horizon
            
        Returns:
            Forecast under the scenario
            
        Examples
        --------
        >>> # Test price increase
        >>> scenario_forecast = analyzer.analyze_scenario(
        ...     base_data,
        ...     {'price': base_data['price'] * 1.1}
        ... )
        """
        # Create modified data
        modified_data = base_data.copy()
        for feature, value in changes.items():
            if feature not in modified_data.columns:
                raise ValueError(f"Feature '{feature}' not in base_data")
            modified_data[feature] = value
        
        # Generate forecast with modified data
        forecast, _ = self.model.predict(horizon=horizon, X=modified_data)
        
        return forecast
    
    def compare_scenarios(
        self,
        base_data: pd.DataFrame,
        scenarios: Dict[str, Dict[str, Any]],
        horizon: Optional[int] = None
    ) -> pd.DataFrame:
        """Compare multiple scenarios.
        
        Args:
            base_data: Base input features
            scenarios: Dictionary of scenarios {name: {feature: value}}
            horizon: Forecast horizon
            
        Returns:
            DataFrame with forecasts for each scenario
            
        Examples
        --------
        >>> scenarios = {
        ...     'baseline': {},
        ...     'price_up_10': {'price': base_data['price'] * 1.1},
        ...     'price_down_10': {'price': base_data['price'] * 0.9}
        ... }
        >>> comparison = analyzer.compare_scenarios(base_data, scenarios)
        """
        results = {}
        
        # Baseline forecast
        baseline_forecast, _ = self.model.predict(horizon=horizon, X=base_data)
        results['baseline'] = baseline_forecast
        
        # Scenario forecasts
        for scenario_name, changes in scenarios.items():
            if scenario_name == 'baseline':
                continue
            forecast = self.analyze_scenario(base_data, changes, horizon)
            results[scenario_name] = forecast
        
        return pd.DataFrame(results)
    
    def sensitivity_analysis(
        self,
        base_data: pd.DataFrame,
        feature: str,
        range_pct: float = 0.2,
        n_points: int = 11,
        horizon: Optional[int] = None
    ) -> pd.DataFrame:
        """Perform sensitivity analysis for a single feature.
        
        Args:
            base_data: Base input features
            feature: Feature to analyze
            range_pct: Range as percentage of base value (e.g., 0.2 = ±20%)
            n_points: Number of points to test
            horizon: Forecast horizon
            
        Returns:
            DataFrame with feature values and corresponding forecasts
            
        Examples
        --------
        >>> # Test price sensitivity
        >>> sensitivity = analyzer.sensitivity_analysis(
        ...     base_data,
        ...     feature='price',
        ...     range_pct=0.2,
        ...     n_points=11
        ... )
        """
        if feature not in base_data.columns:
            raise ValueError(f"Feature '{feature}' not in base_data")
        
        base_value = base_data[feature].mean()
        
        # Create range of values
        min_value = base_value * (1 - range_pct)
        max_value = base_value * (1 + range_pct)
        test_values = np.linspace(min_value, max_value, n_points)
        
        results = []
        for value in test_values:
            # Create scenario
            changes = {feature: value}
            forecast = self.analyze_scenario(base_data, changes, horizon)
            
            results.append({
                f'{feature}_value': value,
                'forecast_mean': forecast.mean(),
                'forecast_sum': forecast.sum(),
                'forecast_std': forecast.std()
            })
        
        return pd.DataFrame(results)
    
    def plot_sensitivity(
        self,
        sensitivity_df: pd.DataFrame,
        feature: str,
        metric: str = 'forecast_mean',
        figsize: Tuple[int, int] = (10, 6),
        save_path: Optional[str] = None
    ) -> plt.Figure:
        """Plot sensitivity analysis results.
        
        Args:
            sensitivity_df: DataFrame from sensitivity_analysis()
            feature: Feature name
            metric: Metric to plot ('forecast_mean', 'forecast_sum', 'forecast_std')
            figsize: Figure size
            save_path: Path to save figure
            
        Returns:
            Matplotlib figure
        """
        fig, ax = plt.subplots(figsize=figsize)
        
        feature_col = f'{feature}_value'
        ax.plot(
            sensitivity_df[feature_col],
            sensitivity_df[metric],
            marker='o',
            linewidth=2,
            markersize=8,
            color='steelblue'
        )
        
        ax.set_xlabel(f'{feature} Value', fontsize=12, fontweight='bold')
        ax.set_ylabel(metric.replace('_', ' ').title(), fontsize=12, fontweight='bold')
        ax.set_title(
            f'Sensitivity Analysis: {feature}',
            fontsize=14,
            fontweight='bold'
        )
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
            print(f"✓ Sensitivity plot saved to {save_path}")
        
        return fig
    
    def plot_scenario_comparison(
        self,
        comparison_df: pd.DataFrame,
        figsize: Tuple[int, int] = (12, 6),
        save_path: Optional[str] = None
    ) -> plt.Figure:
        """Plot comparison of multiple scenarios.
        
        Args:
            comparison_df: DataFrame from compare_scenarios()
            figsize: Figure size
            save_path: Path to save figure
            
        Returns:
            Matplotlib figure
        """
        fig, ax = plt.subplots(figsize=figsize)
        
        for column in comparison_df.columns:
            ax.plot(
                comparison_df.index,
                comparison_df[column],
                label=column,
                linewidth=2,
                marker='o',
                markersize=4
            )
        
        ax.set_xlabel('Time Period', fontsize=12, fontweight='bold')
        ax.set_ylabel('Forecast', fontsize=12, fontweight='bold')
        ax.set_title(
            'Scenario Comparison',
            fontsize=14,
            fontweight='bold'
        )
        ax.legend(loc='best', fontsize=10)
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
            print(f"✓ Scenario comparison plot saved to {save_path}")
        
        return fig
    
    def calculate_impact(
        self,
        base_forecast: pd.Series,
        scenario_forecast: pd.Series
    ) -> Dict[str, float]:
        """Calculate impact metrics comparing two forecasts.
        
        Args:
            base_forecast: Baseline forecast
            scenario_forecast: Scenario forecast
            
        Returns:
            Dictionary with impact metrics
        """
        diff = scenario_forecast - base_forecast
        pct_change = (diff / base_forecast) * 100
        
        return {
            'mean_absolute_diff': np.abs(diff).mean(),
            'mean_diff': diff.mean(),
            'total_diff': diff.sum(),
            'mean_pct_change': pct_change.mean(),
            'max_pct_change': pct_change.max(),
            'min_pct_change': pct_change.min()
        }


# Made with Bob