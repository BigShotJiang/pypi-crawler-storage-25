"""Custom exceptions for the forecasting package."""


class ForecastingError(Exception):
    """Base exception for all forecasting-related errors."""

    pass


class DataValidationError(ForecastingError):
    """Raised when data validation fails."""

    pass


class ModelError(ForecastingError):
    """Raised when model training or prediction fails."""

    pass


class ConfigurationError(ForecastingError):
    """Raised when configuration is invalid."""

    pass


class APIError(ForecastingError):
    """Raised when API operations fail."""

    pass


class MLOpsError(ForecastingError):
    """Raised when MLOps operations fail."""

    pass


class PreprocessingError(ForecastingError):
    """Raised when preprocessing fails."""

    pass


class EvaluationError(ForecastingError):
    """Raised when evaluation fails."""

    pass


# Made with Bob
