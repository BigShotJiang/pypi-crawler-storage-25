"""Base classes for forecasting models."""

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional, Tuple

import numpy as np
import pandas as pd

from forecasting.core.config import ForecastConfig
from forecasting.core.exceptions import ModelError


class BaseForecaster(ABC):
    """Abstract base class for all forecasting models.

    All forecasting models should inherit from this class and implement
    the required abstract methods.

    Attributes:
        config: Configuration object for the forecaster
        model: The underlying model object
        is_fitted: Whether the model has been fitted
        feature_names: Names of features used in training
        preprocessor: Data preprocessor instance
    """

    def __init__(self, config: ForecastConfig):
        """Initialize the forecaster.

        Args:
            config: Configuration object
        """
        self.config = config
        self.model: Optional[Any] = None
        self.is_fitted: bool = False
        self.feature_names: Optional[list] = None
        self._training_data: Optional[pd.DataFrame] = None
        self._validation_metrics: Dict[str, float] = {}
        self._preprocessor: Optional[Any] = None
        self._original_data: Optional[pd.Series] = None
        self._last_forecast: Optional[pd.Series] = None
        self._last_conf_int: Optional[pd.DataFrame] = None

        # Initialize preprocessor if decomposition is enabled
        if self.config.preprocessing.enable_decomposition:
            self._init_preprocessor()

    def _init_preprocessor(self) -> None:
        """Initialize the data preprocessor."""
        from forecasting.data.preprocessors import TimeSeriesPreprocessor

        self._preprocessor = TimeSeriesPreprocessor(
            handle_missing=self.config.preprocessing.handle_missing,
            handle_outliers=self.config.preprocessing.handle_outliers,
            outlier_method=self.config.preprocessing.outlier_method,
            outlier_threshold=self.config.preprocessing.outlier_threshold,
            normalize=self.config.preprocessing.normalize,
            normalize_method=self.config.preprocessing.normalize_method,
            decompose=self.config.preprocessing.enable_decomposition,
            decomposition_method=self.config.preprocessing.decomposition_method,
            decomposition_model=self.config.preprocessing.decomposition_model,
            seasonal_period=self.config.preprocessing.seasonal_period,
        )

    @abstractmethod
    def fit(
        self, y: pd.Series, X: Optional[pd.DataFrame] = None, **kwargs: Any
    ) -> "BaseForecaster":
        """Fit the forecasting model.

        Args:
            y: Target time series
            X: Optional exogenous variables
            **kwargs: Additional arguments for model fitting

        Returns:
            Self for method chaining

        Raises:
            ModelError: If fitting fails
        """
        pass

    @abstractmethod
    def predict(
        self,
        horizon: Optional[int] = None,
        X: Optional[pd.DataFrame] = None,
        return_conf_int: bool = True,
        **kwargs: Any,
    ) -> Tuple[pd.Series, Optional[pd.DataFrame]]:
        """Generate forecasts.

        Args:
            horizon: Number of periods to forecast (uses config if None)
            X: Optional exogenous variables for forecast period
            return_conf_int: Whether to return confidence intervals
            **kwargs: Additional arguments for prediction

        Returns:
            Tuple of (predictions, confidence_intervals)
            confidence_intervals is None if return_conf_int is False

        Raises:
            ModelError: If prediction fails or model not fitted
        """
        pass

    def _store_forecast(
        self,
        forecast: pd.Series,
        conf_int: Optional[pd.DataFrame] = None
    ) -> None:
        """Store forecast for later use (e.g., plotting).

        Args:
            forecast: Forecast series
            conf_int: Optional confidence intervals
        """
        self._last_forecast = forecast
        self._last_conf_int = conf_int

    def fit_predict(
        self,
        y: pd.Series,
        X: Optional[pd.DataFrame] = None,
        horizon: Optional[int] = None,
        return_conf_int: bool = True,
        **kwargs: Any,
    ) -> Tuple[pd.Series, Optional[pd.DataFrame]]:
        """Fit the model and generate forecasts.

        Args:
            y: Target time series
            X: Optional exogenous variables
            horizon: Number of periods to forecast
            return_conf_int: Whether to return confidence intervals
            **kwargs: Additional arguments

        Returns:
            Tuple of (predictions, confidence_intervals)
        """
        self.fit(y, X, **kwargs)
        return self.predict(horizon, X, return_conf_int, **kwargs)

    def _preprocess_data(self, y: pd.Series) -> pd.Series:
        """Preprocess data before fitting.

        Args:
            y: Target time series

        Returns:
            Preprocessed time series
        """
        if self._preprocessor is not None:
            # Store original data for inverse transform
            self._original_data = y.copy()
            # Apply preprocessing (including decomposition)
            return self._preprocessor.fit_transform(y)
        return y

    def _postprocess_predictions(self, predictions: pd.Series) -> pd.Series:
        """Postprocess predictions to original scale.

        Args:
            predictions: Model predictions

        Returns:
            Predictions in original scale
        """
        if self._preprocessor is not None:
            # Inverse transform to get back to original scale
            return self._preprocessor.inverse_transform(predictions)
        return predictions

    def get_decomposition_components(self) -> Optional[Dict[str, pd.Series]]:
        """Get decomposition components if available.

        Returns:
            Dictionary with trend, seasonal, and residual components, or None
        """
        if self._preprocessor is not None and self._preprocessor.decomposer is not None:
            return self._preprocessor.decomposer.get_components()
        return None

    def _check_is_fitted(self) -> None:
        """Check if model is fitted.

        Raises:
            ModelError: If model is not fitted
        """
        if not self.is_fitted:
            raise ModelError(f"{self.__class__.__name__} must be fitted before making predictions")

    def _validate_input(self, y: pd.Series, X: Optional[pd.DataFrame] = None) -> None:
        """Validate input data.

        Args:
            y: Target time series
            X: Optional exogenous variables

        Raises:
            ModelError: If input is invalid
        """
        if not isinstance(y, pd.Series):
            raise ModelError("y must be a pandas Series")

        if y.empty:
            raise ModelError("y cannot be empty")

        if y.isnull().any():
            raise ModelError("y contains missing values")

        if X is not None:
            if not isinstance(X, pd.DataFrame):
                raise ModelError("X must be a pandas DataFrame")

            if len(X) != len(y):
                raise ModelError(f"X and y must have same length. Got X: {len(X)}, y: {len(y)}")

    def get_params(self) -> Dict[str, Any]:
        """Get model parameters.

        Returns:
            Dictionary of model parameters
        """
        return {
            "config": self.config,
            "is_fitted": self.is_fitted,
            "feature_names": self.feature_names,
        }

    def set_params(self, **params: Any) -> "BaseForecaster":
        """Set model parameters.

        Args:
            **params: Parameters to set

        Returns:
            Self for method chaining
        """
        for key, value in params.items():
            if hasattr(self, key):
                setattr(self, key, value)
        return self

    def get_validation_metrics(self) -> Dict[str, float]:
        """Get validation metrics from training.

        Returns:
            Dictionary of validation metrics
        """
        return self._validation_metrics.copy()

    def plot(
        self,
        actuals: Optional[pd.Series] = None,
        show_components: bool = False,
        historical: Optional[pd.Series] = None,
        title: Optional[str] = None,
        save_path: Optional[str] = None,
        **kwargs: Any,
    ) -> Any:
        """Plot forecast results with optional actuals comparison.

        Convenience method for visualizing model predictions. Automatically
        uses the last prediction made by the model.

        Args:
            actuals: Actual values to compare against forecast (optional)
            show_components: Whether to show decomposition components if available
            historical: Historical data to show before forecast period
            title: Plot title (auto-generated if None)
            save_path: Path to save the plot
            **kwargs: Additional arguments passed to ForecastVisualizer

        Returns:
            Matplotlib figure object

        Raises:
            ModelError: If model hasn't been fitted or no predictions available

        Examples:
            >>> model = ARIMAForecaster(config)
            >>> model.fit(train_data)
            >>> forecast, _ = model.predict(horizon=30)
            >>> # Simple plot
            >>> model.plot()
            >>> # With actuals comparison
            >>> model.plot(actuals=test_data)
            >>> # With historical context
            >>> model.plot(actuals=test_data, historical=train_data[-30:])
        """
        from forecasting.utils.visualization import ForecastVisualizer

        self._check_is_fitted()

        # Check if we have predictions stored
        if not hasattr(self, '_last_forecast') or self._last_forecast is None:
            raise ModelError(
                "No forecast available. Call predict() first before plotting.\n"
                "Example: forecast, _ = model.predict(horizon=30)"
            )

        forecast = self._last_forecast
        conf_int = getattr(self, '_last_conf_int', None)

        # Auto-generate title if not provided
        if title is None:
            model_name = self.__class__.__name__.replace('Forecaster', '')
            title = f'{model_name} Forecast'
            if actuals is not None:
                title += ' vs Actuals'

        # Create visualizer
        viz = ForecastVisualizer(**kwargs)

        # Plot forecast vs actuals
        fig = viz.plot_forecast_vs_actuals(
            actuals=actuals if actuals is not None else forecast,
            forecast=forecast,
            conf_int=conf_int,
            historical=historical,
            title=title,
            save_path=save_path,
            show_metrics=(actuals is not None),
        )

        # Show decomposition components if requested
        if show_components:
            components = self.get_decomposition_components()
            if components is not None:
                import matplotlib.pyplot as plt
                fig_comp, axes = plt.subplots(3, 1, figsize=(14, 10))
                
                axes[0].plot(components['trend'])
                axes[0].set_title('Trend Component')
                axes[0].grid(True, alpha=0.3)
                
                axes[1].plot(components['seasonal'])
                axes[1].set_title('Seasonal Component')
                axes[1].grid(True, alpha=0.3)
                
                axes[2].plot(components['residual'])
                axes[2].set_title('Residual Component')
                axes[2].grid(True, alpha=0.3)
                
                plt.tight_layout()
                if save_path:
                    comp_path = save_path.replace('.png', '_components.png')
                    plt.savefig(comp_path)
                    print(f"✓ Components plot saved to {comp_path}")

        return fig

    def save_model(self, path: str) -> None:
        """Save model to disk.

        Args:
            path: Path to save the model

        Raises:
            ModelError: If model cannot be saved
        """
        raise NotImplementedError(f"{self.__class__.__name__} does not implement save_model")

    @classmethod
    def load_model(cls, path: str) -> "BaseForecaster":
        """Load model from disk.

        Args:
            path: Path to load the model from

        Returns:
            Loaded model instance

        Raises:
            ModelError: If model cannot be loaded
        """
        raise NotImplementedError(f"{cls.__name__} does not implement load_model")

    def __repr__(self) -> str:
        """String representation of the forecaster."""
        return (
            f"{self.__class__.__name__}("
            f"model_type={self.config.model_type}, "
            f"is_fitted={self.is_fitted})"
        )


# Made with Bob
