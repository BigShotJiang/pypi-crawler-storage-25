"""Core modules for the forecasting package."""

from forecasting.core.base import BaseForecaster
from forecasting.core.config import ForecastConfig
from forecasting.core.exceptions import (
    ConfigurationError,
    DataValidationError,
    ForecastingError,
    ModelError,
)

__all__ = [
    "BaseForecaster",
    "ForecastConfig",
    "ForecastingError",
    "DataValidationError",
    "ModelError",
    "ConfigurationError",
]

# Made with Bob
