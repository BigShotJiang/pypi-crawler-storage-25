"""Configuration management for the forecasting package."""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

from forecasting.core.exceptions import ConfigurationError


@dataclass
class PreprocessingConfig:
    """Configuration for data preprocessing and decomposition.

    Attributes:
        enable_decomposition: Whether to decompose time series
        decomposition_method: Method for decomposition ('stl', 'classical', 'none')
        decomposition_model: Model type ('additive', 'multiplicative')
        seasonal_period: Seasonal period (auto-detected if None)
        handle_missing: Method for handling missing values
        handle_outliers: Whether to handle outliers
        outlier_method: Outlier detection method ('iqr', 'zscore', 'mad')
        outlier_threshold: Threshold for outlier detection
        normalize: Whether to normalize data
        normalize_method: Normalization method ('standardize', 'minmax')
    """

    enable_decomposition: bool = True
    decomposition_method: str = "stl"
    decomposition_model: str = "additive"
    seasonal_period: Optional[int] = None
    handle_missing: str = "interpolate"
    handle_outliers: bool = False
    outlier_method: str = "iqr"
    outlier_threshold: float = 3.0
    normalize: bool = False
    normalize_method: str = "standardize"

    def validate(self) -> None:
        """Validate preprocessing configuration.

        Raises:
            ConfigurationError: If configuration is invalid
        """
        valid_decomp_methods = ["stl", "classical", "none"]
        if self.decomposition_method not in valid_decomp_methods:
            raise ConfigurationError(
                f"Invalid decomposition_method: {self.decomposition_method}. "
                f"Must be one of {valid_decomp_methods}"
            )

        valid_decomp_models = ["additive", "multiplicative"]
        if self.decomposition_model not in valid_decomp_models:
            raise ConfigurationError(
                f"Invalid decomposition_model: {self.decomposition_model}. "
                f"Must be one of {valid_decomp_models}"
            )

        valid_missing_methods = ["interpolate", "forward", "backward"]
        if self.handle_missing not in valid_missing_methods:
            raise ConfigurationError(
                f"Invalid handle_missing: {self.handle_missing}. "
                f"Must be one of {valid_missing_methods}"
            )

        valid_outlier_methods = ["iqr", "zscore", "mad"]
        if self.outlier_method not in valid_outlier_methods:
            raise ConfigurationError(
                f"Invalid outlier_method: {self.outlier_method}. "
                f"Must be one of {valid_outlier_methods}"
            )

        valid_normalize_methods = ["standardize", "minmax"]
        if self.normalize_method not in valid_normalize_methods:
            raise ConfigurationError(
                f"Invalid normalize_method: {self.normalize_method}. "
                f"Must be one of {valid_normalize_methods}"
            )


@dataclass
class ForecastConfig:
    """Configuration for forecasting models and operations.

    Attributes:
        model_type: Type of model to use ('arima', 'prophet', 'lstm', 'ensemble')
        horizon: Number of periods to forecast
        frequency: Time series frequency (e.g., 'D', 'H', 'M')
        confidence_level: Confidence level for prediction intervals (0-1)
        random_seed: Random seed for reproducibility
        preprocessing: Preprocessing configuration
        model_params: Model-specific parameters
        evaluation_params: Evaluation parameters
        mlflow_tracking_uri: MLflow tracking server URI
        mlflow_experiment_name: MLflow experiment name
    """

    model_type: str = "arima"
    horizon: int = 10
    frequency: str = "D"
    confidence_level: float = 0.95
    random_seed: int = 42
    preprocessing: PreprocessingConfig = field(default_factory=PreprocessingConfig)
    model_params: Dict[str, Any] = field(default_factory=dict)
    evaluation_params: Dict[str, Any] = field(default_factory=dict)
    mlflow_tracking_uri: Optional[str] = None
    mlflow_experiment_name: str = "forecasting_experiments"

    def __post_init__(self) -> None:
        """Validate configuration after initialization."""
        self.validate()

    def validate(self) -> None:
        """Validate configuration parameters.

        Raises:
            ConfigurationError: If configuration is invalid
        """
        valid_models = ["arima", "prophet", "lstm", "ensemble"]
        if self.model_type not in valid_models:
            raise ConfigurationError(
                f"Invalid model_type: {self.model_type}. Must be one of {valid_models}"
            )

        if self.horizon <= 0:
            raise ConfigurationError(f"horizon must be positive, got {self.horizon}")

        if not 0 < self.confidence_level < 1:
            raise ConfigurationError(
                f"confidence_level must be between 0 and 1, got {self.confidence_level}"
            )

        valid_frequencies = ["D", "H", "M", "W", "Q", "Y", "T", "S"]
        if self.frequency not in valid_frequencies:
            raise ConfigurationError(
                f"Invalid frequency: {self.frequency}. Must be one of {valid_frequencies}"
            )

        # Validate preprocessing config
        self.preprocessing.validate()

    @classmethod
    def from_yaml(cls, path: Path) -> "ForecastConfig":
        """Load configuration from YAML file.

        Args:
            path: Path to YAML configuration file

        Returns:
            ForecastConfig instance

        Raises:
            ConfigurationError: If file cannot be loaded or parsed
        """
        try:
            with open(path, "r") as f:
                config_dict = yaml.safe_load(f)
            return cls(**config_dict)
        except FileNotFoundError:
            raise ConfigurationError(f"Configuration file not found: {path}")
        except yaml.YAMLError as e:
            raise ConfigurationError(f"Error parsing YAML file: {e}")
        except TypeError as e:
            raise ConfigurationError(f"Invalid configuration parameters: {e}")

    def to_yaml(self, path: Path) -> None:
        """Save configuration to YAML file.

        Args:
            path: Path to save YAML configuration file
        """
        config_dict = {
            "model_type": self.model_type,
            "horizon": self.horizon,
            "frequency": self.frequency,
            "confidence_level": self.confidence_level,
            "random_seed": self.random_seed,
            "model_params": self.model_params,
            "preprocessing": self.get_preprocessing_params(),
            "evaluation_params": self.evaluation_params,
            "mlflow_tracking_uri": self.mlflow_tracking_uri,
            "mlflow_experiment_name": self.mlflow_experiment_name,
        }

        with open(path, "w") as f:
            yaml.dump(config_dict, f, default_flow_style=False)

    def update(self, **kwargs: Any) -> None:
        """Update configuration parameters.

        Args:
            **kwargs: Parameters to update
        """
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)
            else:
                raise ConfigurationError(f"Unknown configuration parameter: {key}")
        self.validate()

    def get_model_params(self) -> Dict[str, Any]:
        """Get model-specific parameters.

        Returns:
            Dictionary of model parameters
        """
        return self.model_params.copy()

    def get_preprocessing_params(self) -> Dict[str, Any]:
        """Get preprocessing parameters.

        Returns:
            Dictionary of preprocessing parameters
        """
        return {
            "enable_decomposition": self.preprocessing.enable_decomposition,
            "decomposition_method": self.preprocessing.decomposition_method,
            "decomposition_model": self.preprocessing.decomposition_model,
            "seasonal_period": self.preprocessing.seasonal_period,
            "handle_missing": self.preprocessing.handle_missing,
            "handle_outliers": self.preprocessing.handle_outliers,
            "outlier_method": self.preprocessing.outlier_method,
            "outlier_threshold": self.preprocessing.outlier_threshold,
            "normalize": self.preprocessing.normalize,
            "normalize_method": self.preprocessing.normalize_method,
        }

    def get_evaluation_params(self) -> Dict[str, Any]:
        """Get evaluation parameters.

        Returns:
            Dictionary of evaluation parameters
        """
        return self.evaluation_params.copy()


# Made with Bob
