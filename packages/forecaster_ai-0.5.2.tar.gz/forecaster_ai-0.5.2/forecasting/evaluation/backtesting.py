"""
Backtesting framework for time series forecasting.

This module provides tools for evaluating forecast models using
walk-forward validation, expanding windows, and rolling windows.
"""

from typing import Any, Callable, Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd

from forecasting.core.base import BaseForecaster
from forecasting.evaluation.metrics import ForecastMetrics


class BacktestResults:
    """Container for backtesting results.
    
    Stores predictions, actuals, and metrics from backtesting runs.
    
    Attributes:
        predictions: List of forecast arrays
        actuals: List of actual value arrays
        metrics: List of metric dictionaries
        fold_info: Information about each fold
    """
    
    def __init__(self):
        """Initialize empty results container."""
        self.predictions: List[np.ndarray] = []
        self.actuals: List[np.ndarray] = []
        self.metrics: List[Dict[str, float]] = []
        self.fold_info: List[Dict[str, Any]] = []
    
    def add_fold(
        self,
        predictions: np.ndarray,
        actuals: np.ndarray,
        metrics: Dict[str, float],
        fold_info: Optional[Dict[str, Any]] = None
    ):
        """Add results from a single fold.
        
        Args:
            predictions: Forecast values
            actuals: Actual values
            metrics: Calculated metrics
            fold_info: Optional fold metadata
        """
        self.predictions.append(predictions)
        self.actuals.append(actuals)
        self.metrics.append(metrics)
        self.fold_info.append(fold_info or {})
    
    def aggregate_metrics(self) -> Dict[str, float]:
        """Aggregate metrics across all folds.
        
        Returns:
            Dictionary of mean metrics
        """
        if not self.metrics:
            return {}
        
        # Get all metric names
        metric_names = set()
        for m in self.metrics:
            metric_names.update(m.keys())
        
        # Calculate mean for each metric
        aggregated = {}
        for name in metric_names:
            values = [m.get(name, np.nan) for m in self.metrics]
            aggregated[f'mean_{name}'] = float(np.nanmean(values))
            aggregated[f'std_{name}'] = float(np.nanstd(values))
        
        return aggregated
    
    def summary(self) -> str:
        """Generate summary report.
        
        Returns:
            Formatted summary string
        """
        lines = [
            "Backtesting Results",
            "=" * 60,
            f"Number of folds: {len(self.predictions)}",
            "",
            "Aggregated Metrics:",
            "-" * 60
        ]
        
        agg_metrics = self.aggregate_metrics()
        for name, value in sorted(agg_metrics.items()):
            if 'std' in name:
                lines.append(f"  {name:30s}: {value:.4f}")
            elif any(x in name for x in ['mape', 'smape', 'coverage', 'directional']):
                lines.append(f"  {name:30s}: {value:.2f}%")
            else:
                lines.append(f"  {name:30s}: {value:.4f}")
        
        return "\n".join(lines)
    
    def to_dataframe(self) -> pd.DataFrame:
        """Convert results to DataFrame.
        
        Returns:
            DataFrame with one row per fold
        """
        data = []
        for i, (pred, actual, metrics, info) in enumerate(
            zip(self.predictions, self.actuals, self.metrics, self.fold_info)
        ):
            row = {'fold': i}
            row.update(metrics)
            row.update(info)
            data.append(row)
        
        return pd.DataFrame(data)


class TimeSeriesBacktester:
    """Backtesting framework for time series models.
    
    Supports multiple backtesting strategies:
    - Walk-forward validation
    - Expanding window
    - Rolling window
    
    Attributes:
        model_factory: Function that creates a new model instance
        initial_train_size: Initial training set size
        test_size: Test set size for each fold
        step_size: Step size between folds
        window_type: 'expanding' or 'rolling'
    """
    
    def __init__(
        self,
        model_factory: Callable[[], BaseForecaster],
        initial_train_size: int,
        test_size: int,
        step_size: int = 1,
        window_type: str = 'expanding'
    ):
        """Initialize backtester.
        
        Args:
            model_factory: Function that returns a new model instance
            initial_train_size: Initial training set size
            test_size: Test set size for each fold
            step_size: Step size between folds
            window_type: 'expanding' or 'rolling'
        """
        self.model_factory = model_factory
        self.initial_train_size = initial_train_size
        self.test_size = test_size
        self.step_size = step_size
        self.window_type = window_type
        
        if window_type not in ['expanding', 'rolling']:
            raise ValueError(f"window_type must be 'expanding' or 'rolling', got '{window_type}'")
    
    def run(
        self,
        data: Union[pd.Series, np.ndarray],
        X: Optional[pd.DataFrame] = None,
        seasonal_period: Optional[int] = None,
        verbose: bool = True
    ) -> BacktestResults:
        """Run backtesting.
        
        Args:
            data: Time series data
            X: Optional exogenous variables
            seasonal_period: Optional seasonal period for MASE
            verbose: Whether to print progress
            
        Returns:
            BacktestResults object with all fold results
        """
        if isinstance(data, np.ndarray):
            data = pd.Series(data)
        
        results = BacktestResults()
        n = len(data)
        
        # Calculate number of folds
        n_folds = (n - self.initial_train_size - self.test_size) // self.step_size + 1
        
        if verbose:
            print(f"Running backtesting with {n_folds} folds...")
            print(f"Window type: {self.window_type}")
            print(f"Initial train size: {self.initial_train_size}")
            print(f"Test size: {self.test_size}")
            print(f"Step size: {self.step_size}")
            print("-" * 60)
        
        for fold in range(n_folds):
            # Calculate indices
            test_start = self.initial_train_size + fold * self.step_size
            test_end = test_start + self.test_size
            
            if test_end > n:
                break
            
            # Get train/test split
            if self.window_type == 'expanding':
                train_start = 0
            else:  # rolling
                train_start = test_start - self.initial_train_size
            
            train_data = data.iloc[train_start:test_start]
            test_data = data.iloc[test_start:test_end]
            
            # Handle exogenous variables
            X_train = X.iloc[train_start:test_start] if X is not None else None
            X_test = X.iloc[test_start:test_end] if X is not None else None
            
            # Create and train model
            model = self.model_factory()
            
            try:
                model.fit(train_data, X_train)
                predictions, _ = model.predict(horizon=self.test_size, X=X_test, return_conf_int=False)
                
                # Calculate metrics
                calculator = ForecastMetrics(
                    test_data.values,
                    predictions.values if isinstance(predictions, pd.Series) else predictions,
                    train_data.values
                )
                metrics = calculator.calculate_all(seasonal_period)
                
                # Store results
                fold_info = {
                    'train_start': train_start,
                    'train_end': test_start,
                    'test_start': test_start,
                    'test_end': test_end,
                    'train_size': len(train_data),
                    'test_size': len(test_data)
                }
                
                results.add_fold(
                    predictions.values if isinstance(predictions, pd.Series) else predictions,
                    test_data.values,
                    metrics,
                    fold_info
                )
                
                if verbose:
                    print(f"Fold {fold + 1}/{n_folds}: MAE={metrics.get('mae', 0):.4f}, "
                          f"RMSE={metrics.get('rmse', 0):.4f}")
                
            except Exception as e:
                if verbose:
                    print(f"Fold {fold + 1}/{n_folds}: Failed - {str(e)}")
                continue
        
        if verbose:
            print("-" * 60)
            print(f"Completed {len(results.predictions)} folds successfully")
            print("\n" + results.summary())
        
        return results


def walk_forward_validation(
    model_factory: Callable[[], BaseForecaster],
    data: Union[pd.Series, np.ndarray],
    initial_train_size: int,
    test_size: int = 1,
    step_size: int = 1,
    X: Optional[pd.DataFrame] = None,
    seasonal_period: Optional[int] = None,
    verbose: bool = True
) -> BacktestResults:
    """Perform walk-forward validation.
    
    Walk-forward validation trains on expanding windows and tests
    on the next period(s).
    
    Args:
        model_factory: Function that returns a new model instance
        data: Time series data
        initial_train_size: Initial training set size
        test_size: Test set size for each fold
        step_size: Step size between folds
        X: Optional exogenous variables
        seasonal_period: Optional seasonal period for MASE
        verbose: Whether to print progress
        
    Returns:
        BacktestResults object
    """
    backtester = TimeSeriesBacktester(
        model_factory=model_factory,
        initial_train_size=initial_train_size,
        test_size=test_size,
        step_size=step_size,
        window_type='expanding'
    )
    
    return backtester.run(data, X, seasonal_period, verbose)


def rolling_window_validation(
    model_factory: Callable[[], BaseForecaster],
    data: Union[pd.Series, np.ndarray],
    train_size: int,
    test_size: int = 1,
    step_size: int = 1,
    X: Optional[pd.DataFrame] = None,
    seasonal_period: Optional[int] = None,
    verbose: bool = True
) -> BacktestResults:
    """Perform rolling window validation.
    
    Rolling window validation trains on fixed-size windows and tests
    on the next period(s).
    
    Args:
        model_factory: Function that returns a new model instance
        data: Time series data
        train_size: Training set size (fixed)
        test_size: Test set size for each fold
        step_size: Step size between folds
        X: Optional exogenous variables
        seasonal_period: Optional seasonal period for MASE
        verbose: Whether to print progress
        
    Returns:
        BacktestResults object
    """
    backtester = TimeSeriesBacktester(
        model_factory=model_factory,
        initial_train_size=train_size,
        test_size=test_size,
        step_size=step_size,
        window_type='rolling'
    )
    
    return backtester.run(data, X, seasonal_period, verbose)


# Made with Bob
