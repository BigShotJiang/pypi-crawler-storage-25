"""
Cross-validation for time series forecasting.

This module provides time series aware cross-validation methods that
respect temporal ordering and prevent data leakage.
"""

from typing import Any, Callable, Dict, Iterator, List, Optional, Tuple, Union

import numpy as np
import pandas as pd

from forecasting.core.base import BaseForecaster
from forecasting.evaluation.metrics import ForecastMetrics


class TimeSeriesSplit:
    """Time series cross-validator.
    
    Provides train/test indices for time series cross-validation.
    Ensures no data leakage by respecting temporal ordering.
    
    Attributes:
        n_splits: Number of splits
        test_size: Size of test set
        gap: Gap between train and test sets
    """
    
    def __init__(
        self,
        n_splits: int = 5,
        test_size: Optional[int] = None,
        gap: int = 0
    ):
        """Initialize time series splitter.
        
        Args:
            n_splits: Number of splits
            test_size: Size of test set (if None, calculated automatically)
            gap: Gap between train and test sets (prevents data leakage)
        """
        self.n_splits = n_splits
        self.test_size = test_size
        self.gap = gap
    
    def split(
        self,
        X: Union[pd.Series, pd.DataFrame, np.ndarray]
    ) -> Iterator[Tuple[np.ndarray, np.ndarray]]:
        """Generate train/test indices.
        
        Args:
            X: Data to split
            
        Yields:
            Tuple of (train_indices, test_indices)
        """
        n_samples = len(X)
        
        if self.test_size is None:
            test_size = n_samples // (self.n_splits + 1)
        else:
            test_size = self.test_size
        
        indices = np.arange(n_samples)
        
        for i in range(self.n_splits):
            # Calculate split point
            test_start = n_samples - (self.n_splits - i) * test_size
            test_end = test_start + test_size
            
            if test_start <= 0:
                continue
            
            # Train indices (everything before test, minus gap)
            train_end = test_start - self.gap
            if train_end <= 0:
                continue
            
            train_indices = indices[:train_end]
            test_indices = indices[test_start:test_end]
            
            yield train_indices, test_indices
    
    def get_n_splits(self) -> int:
        """Get number of splits.
        
        Returns:
            Number of splits
        """
        return self.n_splits


class BlockedTimeSeriesSplit:
    """Blocked time series cross-validator.
    
    Splits data into blocks and uses each block as test set once.
    Useful for seasonal data or when you want equal-sized test sets.
    
    Attributes:
        n_splits: Number of splits (blocks)
        min_train_size: Minimum training set size
    """
    
    def __init__(
        self,
        n_splits: int = 5,
        min_train_size: Optional[int] = None
    ):
        """Initialize blocked splitter.
        
        Args:
            n_splits: Number of splits (blocks)
            min_train_size: Minimum training set size
        """
        self.n_splits = n_splits
        self.min_train_size = min_train_size
    
    def split(
        self,
        X: Union[pd.Series, pd.DataFrame, np.ndarray]
    ) -> Iterator[Tuple[np.ndarray, np.ndarray]]:
        """Generate train/test indices.
        
        Args:
            X: Data to split
            
        Yields:
            Tuple of (train_indices, test_indices)
        """
        n_samples = len(X)
        block_size = n_samples // self.n_splits
        
        if block_size == 0:
            raise ValueError(f"Not enough samples ({n_samples}) for {self.n_splits} splits")
        
        indices = np.arange(n_samples)
        
        for i in range(self.n_splits):
            # Test block
            test_start = i * block_size
            test_end = (i + 1) * block_size if i < self.n_splits - 1 else n_samples
            test_indices = indices[test_start:test_end]
            
            # Train on all data before test block
            if self.min_train_size is not None and test_start < self.min_train_size:
                continue
            
            train_indices = indices[:test_start]
            
            if len(train_indices) == 0:
                continue
            
            yield train_indices, test_indices
    
    def get_n_splits(self) -> int:
        """Get number of splits.
        
        Returns:
            Number of splits
        """
        return self.n_splits


class CrossValidator:
    """Cross-validation framework for time series models.
    
    Performs cross-validation using a specified splitter and calculates
    metrics for each fold.
    
    Attributes:
        model_factory: Function that creates a new model instance
        splitter: Cross-validation splitter
        scoring: Metrics to calculate
    """
    
    def __init__(
        self,
        model_factory: Callable[[], BaseForecaster],
        splitter: Optional[Union[TimeSeriesSplit, BlockedTimeSeriesSplit]] = None,
        scoring: Optional[List[str]] = None
    ):
        """Initialize cross-validator.
        
        Args:
            model_factory: Function that returns a new model instance
            splitter: Cross-validation splitter (default: TimeSeriesSplit)
            scoring: List of metrics to calculate (default: ['mae', 'rmse', 'mape'])
        """
        self.model_factory = model_factory
        self.splitter = splitter or TimeSeriesSplit(n_splits=5)
        self.scoring = scoring or ['mae', 'rmse', 'mape']
    
    def cross_validate(
        self,
        data: Union[pd.Series, np.ndarray],
        X: Optional[pd.DataFrame] = None,
        seasonal_period: Optional[int] = None,
        verbose: bool = True
    ) -> Dict[str, Any]:
        """Perform cross-validation.
        
        Args:
            data: Time series data
            X: Optional exogenous variables
            seasonal_period: Optional seasonal period for MASE
            verbose: Whether to print progress
            
        Returns:
            Dictionary with cross-validation results
        """
        if isinstance(data, np.ndarray):
            data = pd.Series(data)
        
        results = {
            'fold_scores': [],
            'predictions': [],
            'actuals': [],
            'train_sizes': [],
            'test_sizes': []
        }
        
        n_splits = self.splitter.get_n_splits()
        
        if verbose:
            print(f"Running {n_splits}-fold cross-validation...")
            print("-" * 60)
        
        fold = 0
        for train_idx, test_idx in self.splitter.split(data):
            fold += 1
            
            # Get train/test data
            train_data = data.iloc[train_idx]
            test_data = data.iloc[test_idx]
            
            X_train = X.iloc[train_idx] if X is not None else None
            X_test = X.iloc[test_idx] if X is not None else None
            
            # Create and train model
            model = self.model_factory()
            
            try:
                model.fit(train_data, X_train)
                predictions, _ = model.predict(
                    horizon=len(test_data),
                    X=X_test,
                    return_conf_int=False
                )
                
                # Calculate metrics
                calculator = ForecastMetrics(
                    test_data.values,
                    predictions.values if isinstance(predictions, pd.Series) else predictions,
                    train_data.values
                )
                
                fold_metrics = {}
                for metric_name in self.scoring:
                    if metric_name == 'mae':
                        fold_metrics['mae'] = calculator.mae()
                    elif metric_name == 'rmse':
                        fold_metrics['rmse'] = calculator.rmse()
                    elif metric_name == 'mse':
                        fold_metrics['mse'] = calculator.mse()
                    elif metric_name == 'mape':
                        fold_metrics['mape'] = calculator.mape()
                    elif metric_name == 'smape':
                        fold_metrics['smape'] = calculator.smape()
                    elif metric_name == 'r2':
                        fold_metrics['r2'] = calculator.r2_score()
                    elif metric_name == 'mase' and seasonal_period is not None:
                        try:
                            fold_metrics['mase'] = calculator.mase(seasonal_period)
                        except ValueError:
                            pass
                
                results['fold_scores'].append(fold_metrics)
                results['predictions'].append(predictions.values if isinstance(predictions, pd.Series) else predictions)
                results['actuals'].append(test_data.values)
                results['train_sizes'].append(len(train_data))
                results['test_sizes'].append(len(test_data))
                
                if verbose:
                    metrics_str = ", ".join([f"{k}={v:.4f}" for k, v in fold_metrics.items()])
                    print(f"Fold {fold}: {metrics_str}")
                
            except Exception as e:
                if verbose:
                    print(f"Fold {fold}: Failed - {str(e)}")
                continue
        
        # Calculate aggregate metrics
        results['mean_scores'] = {}
        results['std_scores'] = {}
        
        for metric_name in self.scoring:
            values = [fold.get(metric_name, np.nan) for fold in results['fold_scores']]
            results['mean_scores'][metric_name] = float(np.nanmean(values))
            results['std_scores'][metric_name] = float(np.nanstd(values))
        
        if verbose:
            print("-" * 60)
            print("Cross-Validation Results:")
            for metric_name in self.scoring:
                mean = results['mean_scores'].get(metric_name, 0)
                std = results['std_scores'].get(metric_name, 0)
                print(f"  {metric_name.upper():10s}: {mean:.4f} (+/- {std:.4f})")
        
        return results


def cross_val_score(
    model_factory: Callable[[], BaseForecaster],
    data: Union[pd.Series, np.ndarray],
    cv: Optional[Union[TimeSeriesSplit, BlockedTimeSeriesSplit, int]] = None,
    scoring: str = 'mae',
    X: Optional[pd.DataFrame] = None,
    seasonal_period: Optional[int] = None,
    verbose: bool = False
) -> np.ndarray:
    """Calculate cross-validation scores.
    
    Simplified interface similar to sklearn's cross_val_score.
    
    Args:
        model_factory: Function that returns a new model instance
        data: Time series data
        cv: Cross-validation splitter or number of folds
        scoring: Metric to calculate
        X: Optional exogenous variables
        seasonal_period: Optional seasonal period for MASE
        verbose: Whether to print progress
        
    Returns:
        Array of scores for each fold
    """
    if isinstance(cv, int):
        cv = TimeSeriesSplit(n_splits=cv)
    elif cv is None:
        cv = TimeSeriesSplit(n_splits=5)
    
    validator = CrossValidator(
        model_factory=model_factory,
        splitter=cv,
        scoring=[scoring]
    )
    
    results = validator.cross_validate(data, X, seasonal_period, verbose)
    
    return np.array([fold.get(scoring, np.nan) for fold in results['fold_scores']])


# Made with Bob
