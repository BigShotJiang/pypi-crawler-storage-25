"""Evaluation module for forecasting models.

This module provides comprehensive tools for evaluating forecast accuracy:
- Metrics: MAE, RMSE, MAPE, SMAPE, MASE, R², directional accuracy
- Backtesting: Walk-forward validation, rolling windows
- Cross-validation: Time series aware CV methods
"""

from forecasting.evaluation.backtesting import (
    BacktestResults,
    TimeSeriesBacktester,
    rolling_window_validation,
    walk_forward_validation,
)
from forecasting.evaluation.cross_validation import (
    BlockedTimeSeriesSplit,
    CrossValidator,
    TimeSeriesSplit,
    cross_val_score,
)
from forecasting.evaluation.metrics import ForecastMetrics, compare_models

__all__ = [
    # Metrics
    "ForecastMetrics",
    "compare_models",
    # Backtesting
    "BacktestResults",
    "TimeSeriesBacktester",
    "walk_forward_validation",
    "rolling_window_validation",
    # Cross-validation
    "TimeSeriesSplit",
    "BlockedTimeSeriesSplit",
    "CrossValidator",
    "cross_val_score",
]

# Made with Bob
