"""
Evaluation metrics for time series forecasting.

This module provides comprehensive metrics for evaluating forecast accuracy,
including standard metrics (MAE, RMSE, MAPE) and time series specific metrics
(MASE, SMAPE, directional accuracy).
"""

from typing import Dict, List, Optional, Union

import numpy as np
import pandas as pd


class ForecastMetrics:
    """Calculate and manage forecasting evaluation metrics.
    
    Provides a comprehensive set of metrics for evaluating forecast accuracy,
    including error metrics, percentage metrics, and scaled metrics.
    
    Attributes:
        actual: Actual observed values
        predicted: Predicted forecast values
        train_data: Training data for MASE calculation
    """
    
    def __init__(
        self,
        actual: Union[np.ndarray, pd.Series, List],
        predicted: Union[np.ndarray, pd.Series, List],
        train_data: Optional[Union[np.ndarray, pd.Series, List]] = None
    ):
        """Initialize metrics calculator.
        
        Args:
            actual: Actual observed values
            predicted: Predicted forecast values
            train_data: Optional training data for MASE calculation
        """
        self.actual = np.asarray(actual).flatten()
        self.predicted = np.asarray(predicted).flatten()
        self.train_data = np.asarray(train_data).flatten() if train_data is not None else None
        
        if len(self.actual) != len(self.predicted):
            raise ValueError(
                f"Length mismatch: actual ({len(self.actual)}) "
                f"vs predicted ({len(self.predicted)})"
            )
    
    def mae(self) -> float:
        """Calculate Mean Absolute Error.
        
        MAE = mean(|actual - predicted|)
        
        Returns:
            Mean absolute error
        """
        return float(np.mean(np.abs(self.actual - self.predicted)))
    
    def rmse(self) -> float:
        """Calculate Root Mean Squared Error.
        
        RMSE = sqrt(mean((actual - predicted)^2))
        
        Returns:
            Root mean squared error
        """
        return float(np.sqrt(np.mean((self.actual - self.predicted) ** 2)))
    
    def mse(self) -> float:
        """Calculate Mean Squared Error.
        
        MSE = mean((actual - predicted)^2)
        
        Returns:
            Mean squared error
        """
        return float(np.mean((self.actual - self.predicted) ** 2))
    
    def mape(self) -> float:
        """Calculate Mean Absolute Percentage Error.
        
        MAPE = mean(|actual - predicted| / |actual|) * 100
        
        Note: Returns infinity if any actual values are zero.
        
        Returns:
            Mean absolute percentage error (%)
        """
        # Avoid division by zero
        mask = self.actual != 0
        if not np.any(mask):
            return float('inf')
        
        return float(np.mean(np.abs((self.actual[mask] - self.predicted[mask]) / self.actual[mask])) * 100)
    
    def smape(self) -> float:
        """Calculate Symmetric Mean Absolute Percentage Error.
        
        SMAPE = mean(2 * |actual - predicted| / (|actual| + |predicted|)) * 100
        
        More robust than MAPE when actual values are close to zero.
        
        Returns:
            Symmetric mean absolute percentage error (%)
        """
        denominator = np.abs(self.actual) + np.abs(self.predicted)
        # Avoid division by zero
        mask = denominator != 0
        if not np.any(mask):
            return 0.0
        
        return float(np.mean(2.0 * np.abs(self.actual[mask] - self.predicted[mask]) / denominator[mask]) * 100)
    
    def mase(self, seasonal_period: int = 1) -> float:
        """Calculate Mean Absolute Scaled Error.
        
        MASE = MAE / MAE_naive
        where MAE_naive is the MAE of a naive seasonal forecast on training data.
        
        MASE < 1: Better than naive forecast
        MASE = 1: Same as naive forecast
        MASE > 1: Worse than naive forecast
        
        Args:
            seasonal_period: Seasonal period for naive forecast (1 for non-seasonal)
            
        Returns:
            Mean absolute scaled error
            
        Raises:
            ValueError: If train_data was not provided
        """
        if self.train_data is None:
            raise ValueError("train_data required for MASE calculation")
        
        if len(self.train_data) <= seasonal_period:
            raise ValueError(
                f"train_data length ({len(self.train_data)}) must be > "
                f"seasonal_period ({seasonal_period})"
            )
        
        # Calculate MAE of forecast
        mae_forecast = self.mae()
        
        # Calculate MAE of naive seasonal forecast on training data
        naive_errors = np.abs(self.train_data[seasonal_period:] - self.train_data[:-seasonal_period])
        mae_naive = np.mean(naive_errors)
        
        if mae_naive == 0:
            return float('inf') if mae_forecast > 0 else 0.0
        
        return float(mae_forecast / mae_naive)
    
    def r2_score(self) -> float:
        """Calculate R-squared (coefficient of determination).
        
        R² = 1 - (SS_res / SS_tot)
        where SS_res = sum((actual - predicted)^2)
              SS_tot = sum((actual - mean(actual))^2)
        
        R² = 1: Perfect prediction
        R² = 0: Same as predicting mean
        R² < 0: Worse than predicting mean
        
        Returns:
            R-squared score
        """
        ss_res = np.sum((self.actual - self.predicted) ** 2)
        ss_tot = np.sum((self.actual - np.mean(self.actual)) ** 2)
        
        if ss_tot == 0:
            return 1.0 if ss_res == 0 else 0.0
        
        return float(1 - (ss_res / ss_tot))
    
    def directional_accuracy(self) -> float:
        """Calculate directional accuracy.
        
        Measures the percentage of times the forecast correctly predicts
        the direction of change (up or down).
        
        Returns:
            Directional accuracy (0-100%)
        """
        if len(self.actual) < 2:
            return 0.0
        
        # Calculate actual and predicted changes
        actual_changes = np.diff(self.actual)
        predicted_changes = np.diff(self.predicted)
        
        # Check if directions match (both positive or both negative)
        correct_direction = np.sign(actual_changes) == np.sign(predicted_changes)
        
        return float(np.mean(correct_direction) * 100)
    
    def coverage(
        self,
        lower_bound: Union[np.ndarray, pd.Series, List],
        upper_bound: Union[np.ndarray, pd.Series, List]
    ) -> float:
        """Calculate confidence interval coverage.
        
        Measures the percentage of actual values that fall within the
        predicted confidence intervals.
        
        Args:
            lower_bound: Lower confidence interval bounds
            upper_bound: Upper confidence interval bounds
            
        Returns:
            Coverage percentage (0-100%)
        """
        lower = np.asarray(lower_bound).flatten()
        upper = np.asarray(upper_bound).flatten()
        
        if len(lower) != len(self.actual) or len(upper) != len(self.actual):
            raise ValueError("Confidence interval bounds must match actual length")
        
        within_interval = (self.actual >= lower) & (self.actual <= upper)
        return float(np.mean(within_interval) * 100)
    
    def mean_interval_width(
        self,
        lower_bound: Union[np.ndarray, pd.Series, List],
        upper_bound: Union[np.ndarray, pd.Series, List]
    ) -> float:
        """Calculate mean confidence interval width.
        
        Args:
            lower_bound: Lower confidence interval bounds
            upper_bound: Upper confidence interval bounds
            
        Returns:
            Mean interval width
        """
        lower = np.asarray(lower_bound).flatten()
        upper = np.asarray(upper_bound).flatten()
        
        return float(np.mean(upper - lower))
    
    def calculate_all(
        self,
        seasonal_period: Optional[int] = None,
        lower_bound: Optional[Union[np.ndarray, pd.Series, List]] = None,
        upper_bound: Optional[Union[np.ndarray, pd.Series, List]] = None
    ) -> Dict[str, float]:
        """Calculate all available metrics.
        
        Args:
            seasonal_period: Optional seasonal period for MASE
            lower_bound: Optional lower confidence interval bounds
            upper_bound: Optional upper confidence interval bounds
            
        Returns:
            Dictionary of all calculated metrics
        """
        metrics = {
            'mae': self.mae(),
            'rmse': self.rmse(),
            'mse': self.mse(),
            'mape': self.mape(),
            'smape': self.smape(),
            'r2': self.r2_score(),
            'directional_accuracy': self.directional_accuracy(),
        }
        
        # Add MASE if training data available
        if self.train_data is not None and seasonal_period is not None:
            try:
                metrics['mase'] = self.mase(seasonal_period)
            except ValueError:
                pass
        
        # Add coverage metrics if confidence intervals provided
        if lower_bound is not None and upper_bound is not None:
            try:
                metrics['coverage'] = self.coverage(lower_bound, upper_bound)
                metrics['mean_interval_width'] = self.mean_interval_width(lower_bound, upper_bound)
            except ValueError:
                pass
        
        return metrics
    
    def summary(
        self,
        seasonal_period: Optional[int] = None,
        lower_bound: Optional[Union[np.ndarray, pd.Series, List]] = None,
        upper_bound: Optional[Union[np.ndarray, pd.Series, List]] = None
    ) -> str:
        """Generate a formatted summary of all metrics.
        
        Args:
            seasonal_period: Optional seasonal period for MASE
            lower_bound: Optional lower confidence interval bounds
            upper_bound: Optional upper confidence interval bounds
            
        Returns:
            Formatted string with all metrics
        """
        metrics = self.calculate_all(seasonal_period, lower_bound, upper_bound)
        
        lines = ["Forecast Evaluation Metrics", "=" * 40]
        
        for name, value in metrics.items():
            if np.isinf(value):
                lines.append(f"{name.upper():25s}: inf")
            elif name in ['mape', 'smape', 'directional_accuracy', 'coverage']:
                lines.append(f"{name.upper():25s}: {value:.2f}%")
            else:
                lines.append(f"{name.upper():25s}: {value:.4f}")
        
        return "\n".join(lines)


def compare_models(
    actual: Union[np.ndarray, pd.Series, List],
    predictions: Dict[str, Union[np.ndarray, pd.Series, List]],
    train_data: Optional[Union[np.ndarray, pd.Series, List]] = None,
    seasonal_period: Optional[int] = None
) -> pd.DataFrame:
    """Compare multiple models using various metrics.
    
    Args:
        actual: Actual observed values
        predictions: Dictionary mapping model names to predictions
        train_data: Optional training data for MASE
        seasonal_period: Optional seasonal period for MASE
        
    Returns:
        DataFrame with metrics for each model
    """
    results = []
    
    for model_name, pred in predictions.items():
        calculator = ForecastMetrics(actual, pred, train_data)
        metrics = calculator.calculate_all(seasonal_period)
        metrics['model'] = model_name
        results.append(metrics)
    
    df = pd.DataFrame(results)
    
    # Reorder columns to put model name first
    cols = ['model'] + [col for col in df.columns if col != 'model']
    df = df[cols]
    
    # Sort by MAE (lower is better)
    df = df.sort_values('mae')
    
    return df


# Made with Bob
