"""Enterprise Time Series Forecasting Package.

A comprehensive package for time series forecasting with ARIMA, Prophet, and LSTM models,
including MLOps capabilities, API endpoints, and production-ready features.
"""

__version__ = "0.5.0"
__author__ = "Surya Tripathi"
__email__ = "suryaec1099@gmail.com"

from forecasting.core.base import BaseForecaster
from forecasting.core.config import ForecastConfig
from forecasting.core.exceptions import (
    ForecastingError,
    DataValidationError,
    ModelError,
    ConfigurationError,
)

__all__ = [
    "BaseForecaster",
    "ForecastConfig",
    "ForecastingError",
    "DataValidationError",
    "ModelError",
    "ConfigurationError",
    "__version__",
]
