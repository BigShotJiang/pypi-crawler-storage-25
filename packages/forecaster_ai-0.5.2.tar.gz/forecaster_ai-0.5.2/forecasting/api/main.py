"""Main FastAPI application for forecasting service."""

from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from forecasting.api.routes import health, predictions, training
from forecasting.core.exceptions import ForecastingError


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan context manager for startup/shutdown events."""
    # Startup
    print("Starting forecasting API service...")
    yield
    # Shutdown
    print("Shutting down forecasting API service...")


# Create FastAPI application
app = FastAPI(
    title="Time Series Forecasting API",
    description="Enterprise-grade time series forecasting service with MLOps capabilities",
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Exception handlers
@app.exception_handler(ForecastingError)
async def forecasting_error_handler(request, exc: ForecastingError):
    """Handle forecasting-specific errors."""
    return JSONResponse(
        status_code=400, content={"error": exc.__class__.__name__, "detail": str(exc)}
    )


@app.exception_handler(Exception)
async def general_exception_handler(request, exc: Exception):
    """Handle general exceptions."""
    return JSONResponse(
        status_code=500,
        content={"error": "InternalServerError", "detail": "An unexpected error occurred"},
    )


# Include routers
app.include_router(health.router)
app.include_router(predictions.router)
app.include_router(training.router)


@app.get("/")
async def root():
    """Root endpoint with API information."""
    return {
        "name": "Time Series Forecasting API",
        "version": "1.0.0",
        "description": "Enterprise forecasting service with MLOps",
        "endpoints": {
            "health": "/health",
            "predictions": "/predictions",
            "training": "/training",
            "docs": "/docs",
            "redoc": "/redoc",
        },
    }


@app.get("/info")
async def api_info():
    """Get API information and capabilities."""
    return {
        "models_supported": ["ARIMA", "Auto-ARIMA", "Prophet", "LSTM", "Ensemble"],
        "features": [
            "Time series forecasting",
            "Model training and tuning",
            "Model versioning and registry",
            "Performance monitoring",
            "Drift detection",
            "Batch predictions",
            "Confidence intervals",
        ],
        "mlops": {
            "experiment_tracking": "MLflow",
            "model_registry": "Built-in",
            "monitoring": "Real-time",
            "drift_detection": "Statistical tests",
        },
    }


# Made with Bob
