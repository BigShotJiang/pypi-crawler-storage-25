"""Pydantic schemas for API request/response models."""

from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class HealthResponse(BaseModel):
    """Health check response."""

    status: str = Field(..., description="Service status")
    version: str = Field(..., description="API version")
    timestamp: datetime = Field(default_factory=datetime.now)


class PredictionRequest(BaseModel):
    """Request for making predictions."""

    model_name: str = Field(..., description="Name of the model to use")
    horizon: int = Field(..., ge=1, description="Forecast horizon")
    data: List[float] = Field(..., description="Historical time series data")
    exogenous: Optional[Dict[str, List[float]]] = Field(
        None, description="Optional exogenous variables"
    )
    return_confidence: bool = Field(True, description="Whether to return confidence intervals")

    class Config:
        json_schema_extra = {
            "example": {
                "model_name": "arima_model",
                "horizon": 7,
                "data": [100, 105, 110, 108, 112, 115, 118],
                "return_confidence": True,
            }
        }


class PredictionResponse(BaseModel):
    """Response with predictions."""

    predictions: List[float] = Field(..., description="Forecasted values")
    confidence_lower: Optional[List[float]] = Field(None, description="Lower confidence bounds")
    confidence_upper: Optional[List[float]] = Field(None, description="Upper confidence bounds")
    model_name: str = Field(..., description="Model used for prediction")
    timestamp: datetime = Field(default_factory=datetime.now)

    class Config:
        json_schema_extra = {
            "example": {
                "predictions": [120, 122, 125, 127, 130, 132, 135],
                "confidence_lower": [115, 117, 119, 121, 123, 125, 127],
                "confidence_upper": [125, 127, 131, 133, 137, 139, 143],
                "model_name": "arima_model",
                "timestamp": "2024-01-01T12:00:00",
            }
        }


class TrainingRequest(BaseModel):
    """Request for training a model."""

    model_type: str = Field(..., description="Type of model (arima, prophet, lstm)")
    model_name: str = Field(..., description="Name for the trained model")
    data: List[float] = Field(..., description="Training time series data")
    exogenous: Optional[Dict[str, List[float]]] = Field(
        None, description="Optional exogenous variables"
    )
    parameters: Optional[Dict[str, Any]] = Field(None, description="Model-specific parameters")
    auto_tune: bool = Field(False, description="Whether to auto-tune hyperparameters")

    class Config:
        json_schema_extra = {
            "example": {
                "model_type": "arima",
                "model_name": "sales_forecast",
                "data": [100, 105, 110, 108, 112, 115, 118, 120, 125],
                "parameters": {"order": [1, 1, 1]},
                "auto_tune": False,
            }
        }


class TrainingResponse(BaseModel):
    """Response after training."""

    model_name: str = Field(..., description="Name of trained model")
    model_type: str = Field(..., description="Type of model")
    version: str = Field(..., description="Model version")
    metrics: Dict[str, float] = Field(..., description="Training metrics")
    training_time: float = Field(..., description="Training time in seconds")
    timestamp: datetime = Field(default_factory=datetime.now)

    class Config:
        json_schema_extra = {
            "example": {
                "model_name": "sales_forecast",
                "model_type": "arima",
                "version": "v1",
                "metrics": {"mae": 5.2, "rmse": 7.1, "mape": 4.8},
                "training_time": 2.5,
                "timestamp": "2024-01-01T12:00:00",
            }
        }


class ModelInfo(BaseModel):
    """Information about a registered model."""

    model_name: str = Field(..., description="Model name")
    version: str = Field(..., description="Model version")
    model_type: str = Field(..., description="Model type")
    stage: str = Field(..., description="Lifecycle stage")
    metrics: Dict[str, float] = Field(..., description="Model metrics")
    registered_at: datetime = Field(..., description="Registration timestamp")


class ModelListResponse(BaseModel):
    """Response with list of models."""

    models: List[ModelInfo] = Field(..., description="List of registered models")
    total: int = Field(..., description="Total number of models")


class ErrorResponse(BaseModel):
    """Error response."""

    error: str = Field(..., description="Error message")
    detail: Optional[str] = Field(None, description="Detailed error information")
    timestamp: datetime = Field(default_factory=datetime.now)


class BatchPredictionRequest(BaseModel):
    """Request for batch predictions."""

    model_name: str = Field(..., description="Name of the model")
    data: List[List[float]] = Field(..., description="Multiple time series")
    horizon: int = Field(..., ge=1, description="Forecast horizon")
    return_confidence: bool = Field(True, description="Return confidence intervals")


class BatchPredictionResponse(BaseModel):
    """Response with batch predictions."""

    predictions: List[List[float]] = Field(..., description="Batch predictions")
    model_name: str = Field(..., description="Model used")
    count: int = Field(..., description="Number of predictions")
    timestamp: datetime = Field(default_factory=datetime.now)


class EvaluationRequest(BaseModel):
    """Request for model evaluation."""

    model_name: str = Field(..., description="Model to evaluate")
    test_data: List[float] = Field(..., description="Test time series")
    exogenous: Optional[Dict[str, List[float]]] = Field(None)


class EvaluationResponse(BaseModel):
    """Response with evaluation metrics."""

    model_name: str = Field(..., description="Evaluated model")
    metrics: Dict[str, float] = Field(..., description="Evaluation metrics")
    timestamp: datetime = Field(default_factory=datetime.now)


# Made with Bob
