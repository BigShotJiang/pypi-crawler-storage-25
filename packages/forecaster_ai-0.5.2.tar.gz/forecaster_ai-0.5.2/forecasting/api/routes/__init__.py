"""API routes for forecasting service."""

# Made with Bob
