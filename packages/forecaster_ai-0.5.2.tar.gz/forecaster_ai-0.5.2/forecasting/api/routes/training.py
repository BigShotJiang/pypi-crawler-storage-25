"""Training endpoints."""

import time
from datetime import datetime

import pandas as pd
from fastapi import APIRouter, HTTPException

from forecasting.api.schemas import (
    ErrorResponse,
    EvaluationRequest,
    EvaluationResponse,
    ModelInfo,
    ModelListResponse,
    TrainingRequest,
    TrainingResponse,
)
from forecasting.core.config import ForecastConfig
from forecasting.core.exceptions import ForecastingError
from forecasting.evaluation.metrics import ForecastMetrics
from forecasting.mlops.registry import ModelRegistry
from forecasting.models import (
    ARIMAForecaster,
    AutoARIMAForecaster,
    LSTMForecaster,
    ProphetForecaster,
)

router = APIRouter(prefix="/training", tags=["training"])

# Initialize model registry
registry = ModelRegistry()

# Model type mapping
MODEL_CLASSES = {
    "arima": ARIMAForecaster,
    "auto_arima": AutoARIMAForecaster,
    "prophet": ProphetForecaster,
    "lstm": LSTMForecaster,
}


@router.post("/", response_model=TrainingResponse, responses={400: {"model": ErrorResponse}})
async def train_model(request: TrainingRequest) -> TrainingResponse:
    """Train a new forecasting model.

    Args:
        request: Training request with model type and data

    Returns:
        Training response with metrics

    Raises:
        HTTPException: If training fails
    """
    try:
        start_time = time.time()

        # Validate model type
        if request.model_type not in MODEL_CLASSES:
            raise HTTPException(
                status_code=400,
                detail=f"Unknown model type: {request.model_type}. "
                f"Available: {list(MODEL_CLASSES.keys())}",
            )

        # Prepare data
        y = pd.Series(request.data)
        X = None
        if request.exogenous:
            X = pd.DataFrame(request.exogenous)

        # Create config
        config = ForecastConfig(
            model_type=request.model_type,
            horizon=10,  # Default horizon
        )

        # Initialize model
        model_class = MODEL_CLASSES[request.model_type]
        params = request.parameters or {}
        model = model_class(config, **params)

        # Train model
        model.fit(y, X)

        # Get validation metrics
        metrics = model.get_validation_metrics()

        # Register model
        version = registry.register_model(
            model=model,
            model_name=request.model_name,
            stage="development",
            metrics=metrics,
            description=f"Trained {request.model_type} model",
        )

        training_time = time.time() - start_time

        return TrainingResponse(
            model_name=request.model_name,
            model_type=request.model_type,
            version=version,
            metrics=metrics,
            training_time=training_time,
        )

    except ForecastingError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Training failed: {str(e)}")


@router.get("/models", response_model=ModelListResponse)
async def list_models(stage: str = None) -> ModelListResponse:
    """List all registered models.

    Args:
        stage: Optional filter by stage

    Returns:
        List of registered models
    """
    try:
        models_df = registry.list_models()

        if stage:
            models_df = models_df[models_df["stage"] == stage]

        models_list = []
        for _, row in models_df.iterrows():
            models_list.append(
                ModelInfo(
                    model_name=row["model_name"],
                    version=row["version"],
                    model_type=row["model_class"],
                    stage=row["stage"],
                    metrics=row.get("metrics", {}),
                    registered_at=datetime.fromisoformat(row["registered_at"]),
                )
            )

        return ModelListResponse(models=models_list, total=len(models_list))

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/evaluate", response_model=EvaluationResponse)
async def evaluate_model(request: EvaluationRequest) -> EvaluationResponse:
    """Evaluate a trained model.

    Args:
        request: Evaluation request

    Returns:
        Evaluation metrics
    """
    try:
        # Load model
        model = registry.load_model(request.model_name)

        if model is None:
            raise HTTPException(status_code=404, detail=f"Model {request.model_name} not found")

        # Prepare test data
        y_test = pd.Series(request.test_data)
        X_test = None
        if request.exogenous:
            X_test = pd.DataFrame(request.exogenous)

        # Generate predictions
        predictions, _ = model.predict(horizon=len(y_test), X=X_test, return_conf_int=False)

        # Calculate metrics
        metrics = ForecastMetrics.calculate_all(y_test, predictions)

        return EvaluationResponse(model_name=request.model_name, metrics=metrics)

    except ForecastingError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Evaluation failed: {str(e)}")


@router.put("/models/{model_name}/stage")
async def update_model_stage(model_name: str, version: str, new_stage: str) -> dict:
    """Update model lifecycle stage.

    Args:
        model_name: Name of the model
        version: Model version
        new_stage: New stage (development, staging, production)

    Returns:
        Success message
    """
    try:
        valid_stages = ["development", "staging", "production"]
        if new_stage not in valid_stages:
            raise HTTPException(
                status_code=400, detail=f"Invalid stage. Must be one of: {valid_stages}"
            )

        registry.update_stage(model_name, version, new_stage)

        return {
            "message": f"Model {model_name} version {version} moved to {new_stage}",
            "model_name": model_name,
            "version": version,
            "stage": new_stage,
        }

    except ForecastingError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# Made with Bob
