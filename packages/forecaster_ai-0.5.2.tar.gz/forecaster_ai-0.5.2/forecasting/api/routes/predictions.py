"""Prediction endpoints."""

import pandas as pd
from fastapi import APIRouter, HTTPException

from forecasting.api.schemas import (
    BatchPredictionRequest,
    BatchPredictionResponse,
    ErrorResponse,
    PredictionRequest,
    PredictionResponse,
)
from forecasting.core.exceptions import ForecastingError
from forecasting.mlops.registry import ModelRegistry

router = APIRouter(prefix="/predictions", tags=["predictions"])

# Initialize model registry
registry = ModelRegistry()


@router.post("/", response_model=PredictionResponse, responses={400: {"model": ErrorResponse}})
async def make_prediction(request: PredictionRequest) -> PredictionResponse:
    """Make a forecast prediction.

    Args:
        request: Prediction request with model name and data

    Returns:
        Prediction response with forecasts

    Raises:
        HTTPException: If prediction fails
    """
    try:
        # Load model from registry
        model = registry.load_model(request.model_name, stage="production")

        if model is None:
            raise HTTPException(
                status_code=404, detail=f"Model {request.model_name} not found in production"
            )

        # Prepare data
        y = pd.Series(request.data)
        X = None
        if request.exogenous:
            X = pd.DataFrame(request.exogenous)

        # Generate predictions
        predictions, conf_int = model.predict(
            horizon=request.horizon, X=X, return_conf_int=request.return_confidence
        )

        # Prepare response
        response = PredictionResponse(
            predictions=predictions.tolist(), model_name=request.model_name
        )

        if conf_int is not None:
            response.confidence_lower = conf_int["lower"].tolist()
            response.confidence_upper = conf_int["upper"].tolist()

        return response

    except ForecastingError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Prediction failed: {str(e)}")


@router.post("/batch", response_model=BatchPredictionResponse)
async def make_batch_predictions(request: BatchPredictionRequest) -> BatchPredictionResponse:
    """Make batch predictions for multiple time series.

    Args:
        request: Batch prediction request

    Returns:
        Batch prediction response

    Raises:
        HTTPException: If batch prediction fails
    """
    try:
        # Load model
        model = registry.load_model(request.model_name, stage="production")

        if model is None:
            raise HTTPException(status_code=404, detail=f"Model {request.model_name} not found")

        # Make predictions for each series
        all_predictions = []

        for series_data in request.data:
            y = pd.Series(series_data)
            predictions, _ = model.predict(horizon=request.horizon, return_conf_int=False)
            all_predictions.append(predictions.tolist())

        return BatchPredictionResponse(
            predictions=all_predictions, model_name=request.model_name, count=len(all_predictions)
        )

    except ForecastingError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Batch prediction failed: {str(e)}")


@router.get("/models", response_model=dict)
async def list_available_models():
    """List all available models for prediction.

    Returns:
        Dictionary with available models
    """
    try:
        models_df = registry.list_models()

        # Filter production models
        production_models = models_df[models_df["stage"] == "production"]

        return {
            "production_models": production_models.to_dict(orient="records"),
            "total": len(production_models),
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# Made with Bob
