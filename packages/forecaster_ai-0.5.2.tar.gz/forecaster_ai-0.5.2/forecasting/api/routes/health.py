"""Health check endpoints."""

from datetime import datetime

from fastapi import APIRouter

from forecasting.api.schemas import HealthResponse

router = APIRouter(prefix="/health", tags=["health"])


@router.get("/", response_model=HealthResponse)
async def health_check() -> HealthResponse:
    """Check service health.

    Returns:
        Health status response
    """
    return HealthResponse(status="healthy", version="1.0.0", timestamp=datetime.now())


@router.get("/ready", response_model=HealthResponse)
async def readiness_check() -> HealthResponse:
    """Check if service is ready to accept requests.

    Returns:
        Readiness status response
    """
    # Add checks for dependencies (database, model registry, etc.)
    return HealthResponse(status="ready", version="1.0.0", timestamp=datetime.now())


@router.get("/live", response_model=HealthResponse)
async def liveness_check() -> HealthResponse:
    """Check if service is alive.

    Returns:
        Liveness status response
    """
    return HealthResponse(status="alive", version="1.0.0", timestamp=datetime.now())


# Made with Bob
