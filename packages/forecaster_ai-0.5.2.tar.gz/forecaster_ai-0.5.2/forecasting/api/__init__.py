"""FastAPI application for forecasting service."""

from forecasting.api.main import app

__all__ = ["app"]

# Made with Bob
