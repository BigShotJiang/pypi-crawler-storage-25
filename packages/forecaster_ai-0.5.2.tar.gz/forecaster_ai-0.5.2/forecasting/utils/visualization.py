"""
Visualization utilities for forecasting.

Provides comprehensive visualization tools for comparing forecasts against actuals,
analyzing model performance, and creating publication-ready plots.
"""

from typing import Optional, List, Dict, Tuple, Union
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.figure import Figure
from matplotlib.axes import Axes
import seaborn as sns


class ForecastVisualizer:
    """
    Comprehensive visualization tool for forecasting analysis.

    Provides methods to:
    - Compare forecast vs actuals
    - Show confidence intervals
    - Display multiple products/categories
    - Analyze forecast errors
    - Create publication-ready plots

    Examples
    --------
    >>> from forecasting.utils.visualization import ForecastVisualizer
    >>>
    >>> # Create visualizer
    >>> viz = ForecastVisualizer(style='seaborn', figsize=(14, 8))
    >>>
    >>> # Simple forecast vs actuals
    >>> viz.plot_forecast_vs_actuals(
    ...     actuals=actual_demand,
    ...     forecast=forecast,
    ...     title='Product A Forecast'
    ... )
    >>>
    >>> # With confidence intervals
    >>> viz.plot_forecast_vs_actuals(
    ...     actuals=actual_demand,
    ...     forecast=forecast,
    ...     conf_int=confidence_intervals,
    ...     title='Product A Forecast with Uncertainty'
    ... )
    >>>
    >>> # Multiple products comparison
    >>> viz.plot_multiple_forecasts(
    ...     actuals_dict={'Product A': actuals_a, 'Product B': actuals_b},
    ...     forecast_dict={'Product A': forecast_a, 'Product B': forecast_b}
    ... )
    """

    def __init__(
        self,
        style: str = "seaborn-v0_8-darkgrid",
        figsize: Tuple[int, int] = (14, 8),
        dpi: int = 100,
        color_palette: str = "husl",
    ):
        """
        Initialize forecast visualizer.

        Parameters
        ----------
        style : str, default='seaborn-v0_8-darkgrid'
            Matplotlib style
        figsize : tuple, default=(14, 8)
            Default figure size
        dpi : int, default=100
            Figure DPI
        color_palette : str, default='husl'
            Seaborn color palette
        """
        self.style = style
        self.figsize = figsize
        self.dpi = dpi
        self.color_palette = color_palette

        # Set style
        try:
            plt.style.use(style)
        except:
            plt.style.use("default")

        # Set seaborn palette
        sns.set_palette(color_palette)

    def plot_forecast_vs_actuals(
        self,
        actuals: pd.Series,
        forecast: pd.Series,
        conf_int: Optional[pd.DataFrame] = None,
        historical: Optional[pd.Series] = None,
        title: str = "Forecast vs Actuals",
        xlabel: str = "Date",
        ylabel: str = "Demand",
        save_path: Optional[str] = None,
        show_metrics: bool = True,
        show_grid: bool = True,
        figsize: Optional[Tuple[int, int]] = None,
    ) -> Figure:
        """
        Plot forecast against actuals with optional confidence intervals.

        Parameters
        ----------
        actuals : pd.Series
            Actual values
        forecast : pd.Series
            Forecasted values
        conf_int : pd.DataFrame, optional
            Confidence intervals with 'lower' and 'upper' columns
        historical : pd.Series, optional
            Historical data to show before forecast period
        title : str, default='Forecast vs Actuals'
            Plot title
        xlabel : str, default='Date'
            X-axis label
        ylabel : str, default='Demand'
            Y-axis label
        save_path : str, optional
            Path to save figure
        show_metrics : bool, default=True
            Whether to show accuracy metrics
        show_grid : bool, default=True
            Whether to show grid
        figsize : tuple, optional
            Figure size (overrides default)

        Returns
        -------
        fig : Figure
            Matplotlib figure object
            
        Raises
        ------
        ValueError
            If inputs are invalid or indices don't align
        TypeError
            If inputs are not pandas Series/DataFrame
        """
        # Validate inputs
        try:
            if not isinstance(actuals, pd.Series):
                raise TypeError(f"actuals must be a pandas Series, got {type(actuals)}")
            if not isinstance(forecast, pd.Series):
                raise TypeError(f"forecast must be a pandas Series, got {type(forecast)}")
            
            if actuals.empty:
                raise ValueError("actuals cannot be empty")
            if forecast.empty:
                raise ValueError("forecast cannot be empty")
            
            # Convert indices to datetime if not already
            if not isinstance(actuals.index, pd.DatetimeIndex):
                try:
                    actuals = actuals.copy()
                    actuals.index = pd.to_datetime(actuals.index)
                except Exception as e:
                    raise ValueError(f"Could not convert actuals index to datetime: {e}")
            
            if not isinstance(forecast.index, pd.DatetimeIndex):
                try:
                    forecast = forecast.copy()
                    forecast.index = pd.to_datetime(forecast.index)
                except Exception as e:
                    raise ValueError(f"Could not convert forecast index to datetime: {e}")
            
            # Check for overlapping dates
            common_idx = actuals.index.intersection(forecast.index)
            if len(common_idx) == 0:
                raise ValueError(
                    f"No overlapping dates between actuals and forecast.\n"
                    f"Actuals range: {actuals.index.min()} to {actuals.index.max()}\n"
                    f"Forecast range: {forecast.index.min()} to {forecast.index.max()}\n"
                    f"Hint: Check that your forecast dates match your test data dates."
                )
            
            # Validate confidence intervals if provided
            if conf_int is not None:
                if not isinstance(conf_int, pd.DataFrame):
                    raise TypeError(f"conf_int must be a pandas DataFrame, got {type(conf_int)}")
                if 'lower' not in conf_int.columns or 'upper' not in conf_int.columns:
                    raise ValueError("conf_int must have 'lower' and 'upper' columns")
                if not isinstance(conf_int.index, pd.DatetimeIndex):
                    try:
                        conf_int = conf_int.copy()
                        conf_int.index = pd.to_datetime(conf_int.index)
                    except Exception as e:
                        raise ValueError(f"Could not convert conf_int index to datetime: {e}")
            
            # Validate historical if provided
            if historical is not None:
                if not isinstance(historical, pd.Series):
                    raise TypeError(f"historical must be a pandas Series, got {type(historical)}")
                if not isinstance(historical.index, pd.DatetimeIndex):
                    try:
                        historical = historical.copy()
                        historical.index = pd.to_datetime(historical.index)
                    except Exception as e:
                        raise ValueError(f"Could not convert historical index to datetime: {e}")
        
        except Exception as e:
            import logging
            logger = logging.getLogger(__name__)
            logger.error(f"Visualization input validation failed: {e}")
            raise
        
        figsize = figsize or self.figsize
        fig, ax = plt.subplots(figsize=figsize, dpi=self.dpi)

        # Plot historical data if provided
        if historical is not None:
            ax.plot(
                historical.index,
                historical.values,
                label="Historical",
                color="gray",
                linewidth=2,
                alpha=0.7,
            )

        # Plot actuals
        ax.plot(
            actuals.index,
            actuals.values,
            label="Actuals",
            color="blue",
            linewidth=2.5,
            marker="o",
            markersize=6,
        )

        # Plot forecast
        ax.plot(
            forecast.index,
            forecast.values,
            label="Forecast",
            color="red",
            linewidth=2.5,
            marker="s",
            markersize=6,
            linestyle="--",
        )

        # Plot confidence intervals
        if conf_int is not None:
            ax.fill_between(
                conf_int.index,
                conf_int["lower"].values,
                conf_int["upper"].values,
                alpha=0.3,
                color="red",
                label="Confidence Interval",
            )

        # Add vertical line at forecast start
        if historical is not None or len(actuals) > len(forecast):
            forecast_start = forecast.index[0]
            ax.axvline(
                x=forecast_start, color="green", linestyle=":", linewidth=2, label="Forecast Start"
            )

        # Calculate and display metrics
        if show_metrics:
            # Align actuals and forecast
            common_idx = actuals.index.intersection(forecast.index)
            if len(common_idx) > 0:
                actuals_aligned = actuals[common_idx]
                forecast_aligned = forecast[common_idx]

                # Calculate metrics
                mae = np.mean(np.abs(actuals_aligned - forecast_aligned))
                rmse = np.sqrt(np.mean((actuals_aligned - forecast_aligned) ** 2))
                mape = np.mean(np.abs((actuals_aligned - forecast_aligned) / actuals_aligned)) * 100

                # Add metrics text box
                metrics_text = f"MAE: {mae:.2f}\nRMSE: {rmse:.2f}\nMAPE: {mape:.1f}%"
                ax.text(
                    0.02,
                    0.98,
                    metrics_text,
                    transform=ax.transAxes,
                    verticalalignment="top",
                    bbox=dict(boxstyle="round", facecolor="wheat", alpha=0.8),
                    fontsize=10,
                    family="monospace",
                )

        # Formatting
        ax.set_xlabel(xlabel, fontsize=12, fontweight="bold")
        ax.set_ylabel(ylabel, fontsize=12, fontweight="bold")
        ax.set_title(title, fontsize=14, fontweight="bold", pad=20)
        ax.legend(loc="best", fontsize=10, framealpha=0.9)

        if show_grid:
            ax.grid(True, alpha=0.3, linestyle="--")

        # Format x-axis for dates
        if isinstance(actuals.index, pd.DatetimeIndex):
            ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m-%d"))
            plt.xticks(rotation=45, ha="right")

        plt.tight_layout()

        if save_path:
            plt.savefig(save_path, dpi=self.dpi, bbox_inches="tight")
            print(f"✓ Plot saved to {save_path}")

        return fig

    def plot_multiple_forecasts(
        self,
        actuals_dict: Dict[str, pd.Series],
        forecast_dict: Dict[str, pd.Series],
        conf_int_dict: Optional[Dict[str, pd.DataFrame]] = None,
        title: str = "Multiple Product Forecasts",
        save_path: Optional[str] = None,
        ncols: int = 2,
        figsize: Optional[Tuple[int, int]] = None,
    ) -> Figure:
        """
        Plot multiple products/categories in subplots.

        Parameters
        ----------
        actuals_dict : dict
            Dictionary mapping product names to actual series
        forecast_dict : dict
            Dictionary mapping product names to forecast series
        conf_int_dict : dict, optional
            Dictionary mapping product names to confidence intervals
        title : str, default='Multiple Product Forecasts'
            Overall title
        save_path : str, optional
            Path to save figure
        ncols : int, default=2
            Number of columns in subplot grid
        figsize : tuple, optional
            Figure size

        Returns
        -------
        fig : Figure
            Matplotlib figure object
        """
        n_products = len(actuals_dict)
        nrows = (n_products + ncols - 1) // ncols

        figsize = figsize or (7 * ncols, 5 * nrows)
        fig, axes = plt.subplots(nrows, ncols, figsize=figsize, dpi=self.dpi)

        if n_products == 1:
            axes = np.array([axes])
        axes = axes.flatten()

        for idx, (product_name, actuals) in enumerate(actuals_dict.items()):
            ax = axes[idx]
            forecast = forecast_dict[product_name]
            conf_int = conf_int_dict.get(product_name) if conf_int_dict else None

            # Plot actuals
            ax.plot(
                actuals.index,
                actuals.values,
                label="Actuals",
                color="blue",
                linewidth=2,
                marker="o",
                markersize=4,
            )

            # Plot forecast
            ax.plot(
                forecast.index,
                forecast.values,
                label="Forecast",
                color="red",
                linewidth=2,
                marker="s",
                markersize=4,
                linestyle="--",
            )

            # Plot confidence intervals
            if conf_int is not None:
                ax.fill_between(
                    conf_int.index,
                    conf_int["lower"].values,
                    conf_int["upper"].values,
                    alpha=0.3,
                    color="red",
                )

            # Calculate MAPE
            common_idx = actuals.index.intersection(forecast.index)
            if len(common_idx) > 0:
                actuals_aligned = actuals[common_idx]
                forecast_aligned = forecast[common_idx]
                mape = np.mean(np.abs((actuals_aligned - forecast_aligned) / actuals_aligned)) * 100

                ax.text(
                    0.02,
                    0.98,
                    f"MAPE: {mape:.1f}%",
                    transform=ax.transAxes,
                    verticalalignment="top",
                    bbox=dict(boxstyle="round", facecolor="wheat", alpha=0.8),
                    fontsize=9,
                )

            ax.set_title(product_name, fontsize=11, fontweight="bold")
            ax.legend(loc="best", fontsize=8)
            ax.grid(True, alpha=0.3)

            if isinstance(actuals.index, pd.DatetimeIndex):
                ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m-%d"))
                plt.setp(ax.xaxis.get_majorticklabels(), rotation=45, ha="right")

        # Hide unused subplots
        for idx in range(n_products, len(axes)):
            axes[idx].set_visible(False)

        fig.suptitle(title, fontsize=16, fontweight="bold", y=1.00)
        plt.tight_layout()

        if save_path:
            plt.savefig(save_path, dpi=self.dpi, bbox_inches="tight")
            print(f"✓ Plot saved to {save_path}")

        return fig

    def plot_forecast_error_analysis(
        self,
        actuals: pd.Series,
        forecast: pd.Series,
        title: str = "Forecast Error Analysis",
        save_path: Optional[str] = None,
        figsize: Optional[Tuple[int, int]] = None,
    ) -> Figure:
        """
        Create comprehensive error analysis plots.

        Shows:
        1. Forecast vs Actuals
        2. Error over time
        3. Error distribution
        4. Error autocorrelation

        Parameters
        ----------
        actuals : pd.Series
            Actual values
        forecast : pd.Series
            Forecasted values
        title : str, default='Forecast Error Analysis'
            Overall title
        save_path : str, optional
            Path to save figure
        figsize : tuple, optional
            Figure size

        Returns
        -------
        fig : Figure
            Matplotlib figure object
        """
        # Align data
        common_idx = actuals.index.intersection(forecast.index)
        actuals_aligned = actuals[common_idx]
        forecast_aligned = forecast[common_idx]
        errors = actuals_aligned - forecast_aligned

        figsize = figsize or (16, 10)
        fig = plt.figure(figsize=figsize, dpi=self.dpi)
        gs = fig.add_gridspec(3, 2, hspace=0.3, wspace=0.3)

        # 1. Forecast vs Actuals
        ax1 = fig.add_subplot(gs[0, :])
        ax1.plot(
            actuals_aligned.index,
            actuals_aligned.values,
            label="Actuals",
            color="blue",
            linewidth=2,
            marker="o",
            markersize=4,
        )
        ax1.plot(
            forecast_aligned.index,
            forecast_aligned.values,
            label="Forecast",
            color="red",
            linewidth=2,
            marker="s",
            markersize=4,
            linestyle="--",
        )
        ax1.set_title("Forecast vs Actuals", fontsize=12, fontweight="bold")
        ax1.set_ylabel("Value")
        ax1.legend()
        ax1.grid(True, alpha=0.3)

        # 2. Error over time
        ax2 = fig.add_subplot(gs[1, 0])
        ax2.plot(errors.index, errors.values, color="purple", linewidth=2, marker="o", markersize=4)
        ax2.axhline(y=0, color="black", linestyle="--", linewidth=1)
        ax2.fill_between(errors.index, 0, errors.values, alpha=0.3, color="purple")
        ax2.set_title("Forecast Error Over Time", fontsize=12, fontweight="bold")
        ax2.set_ylabel("Error (Actual - Forecast)")
        ax2.grid(True, alpha=0.3)

        # 3. Error distribution
        ax3 = fig.add_subplot(gs[1, 1])
        ax3.hist(errors.values, bins=20, color="orange", alpha=0.7, edgecolor="black")
        ax3.axvline(x=0, color="red", linestyle="--", linewidth=2, label="Zero Error")
        ax3.axvline(
            x=errors.mean(),
            color="green",
            linestyle="--",
            linewidth=2,
            label=f"Mean: {errors.mean():.2f}",
        )
        ax3.set_title("Error Distribution", fontsize=12, fontweight="bold")
        ax3.set_xlabel("Error")
        ax3.set_ylabel("Frequency")
        ax3.legend()
        ax3.grid(True, alpha=0.3, axis="y")

        # 4. Actual vs Forecast scatter
        ax4 = fig.add_subplot(gs[2, 0])
        ax4.scatter(actuals_aligned.values, forecast_aligned.values, alpha=0.6, s=50)

        # Perfect forecast line
        min_val = min(actuals_aligned.min(), forecast_aligned.min())
        max_val = max(actuals_aligned.max(), forecast_aligned.max())
        ax4.plot(
            [min_val, max_val], [min_val, max_val], "r--", linewidth=2, label="Perfect Forecast"
        )

        ax4.set_title("Actual vs Forecast Scatter", fontsize=12, fontweight="bold")
        ax4.set_xlabel("Actual")
        ax4.set_ylabel("Forecast")
        ax4.legend()
        ax4.grid(True, alpha=0.3)

        # 5. Metrics summary
        ax5 = fig.add_subplot(gs[2, 1])
        ax5.axis("off")

        # Calculate metrics
        mae = np.mean(np.abs(errors))
        rmse = np.sqrt(np.mean(errors**2))
        mape = np.mean(np.abs(errors / actuals_aligned)) * 100
        bias = errors.mean()

        metrics_text = f"""
        ACCURACY METRICS
        ═══════════════════════════
        MAE:   {mae:>10.2f}
        RMSE:  {rmse:>10.2f}
        MAPE:  {mape:>9.1f}%
        Bias:  {bias:>10.2f}
        
        ERROR STATISTICS
        ═══════════════════════════
        Mean:  {errors.mean():>10.2f}
        Std:   {errors.std():>10.2f}
        Min:   {errors.min():>10.2f}
        Max:   {errors.max():>10.2f}
        """

        ax5.text(
            0.1,
            0.5,
            metrics_text,
            transform=ax5.transAxes,
            verticalalignment="center",
            fontsize=11,
            family="monospace",
            bbox=dict(boxstyle="round", facecolor="lightblue", alpha=0.8),
        )

        fig.suptitle(title, fontsize=16, fontweight="bold")

        if save_path:
            plt.savefig(save_path, dpi=self.dpi, bbox_inches="tight")
            print(f"✓ Plot saved to {save_path}")

        return fig

    def plot_category_comparison(
        self,
        data_dict: Dict[str, Dict[str, pd.Series]],
        title: str = "Category Forecast Comparison",
        save_path: Optional[str] = None,
        figsize: Optional[Tuple[int, int]] = None,
    ) -> Figure:
        """
        Compare forecasts across multiple categories.

        Parameters
        ----------
        data_dict : dict
            Nested dictionary: {category: {'actuals': series, 'forecast': series}}
        title : str, default='Category Forecast Comparison'
            Plot title
        save_path : str, optional
            Path to save figure
        figsize : tuple, optional
            Figure size

        Returns
        -------
        fig : Figure
            Matplotlib figure object
        """
        figsize = figsize or (16, 10)
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=figsize, dpi=self.dpi)

        # Prepare data
        categories = list(data_dict.keys())
        colors = sns.color_palette(self.color_palette, len(categories))

        # Plot 1: All categories together
        for idx, (category, data) in enumerate(data_dict.items()):
            actuals = data["actuals"]
            forecast = data["forecast"]

            # Plot actuals
            ax1.plot(
                actuals.index,
                actuals.values,
                label=f"{category} (Actual)",
                color=colors[idx],
                linewidth=2,
                marker="o",
                markersize=4,
            )

            # Plot forecast
            ax1.plot(
                forecast.index,
                forecast.values,
                label=f"{category} (Forecast)",
                color=colors[idx],
                linewidth=2,
                marker="s",
                markersize=4,
                linestyle="--",
                alpha=0.7,
            )

        ax1.set_title("All Categories: Forecast vs Actuals", fontsize=12, fontweight="bold")
        ax1.set_ylabel("Demand")
        ax1.legend(loc="best", ncol=2, fontsize=8)
        ax1.grid(True, alpha=0.3)

        # Plot 2: MAPE comparison
        mapes = []
        for category, data in data_dict.items():
            actuals = data["actuals"]
            forecast = data["forecast"]
            common_idx = actuals.index.intersection(forecast.index)

            if len(common_idx) > 0:
                actuals_aligned = actuals[common_idx]
                forecast_aligned = forecast[common_idx]
                mape = np.mean(np.abs((actuals_aligned - forecast_aligned) / actuals_aligned)) * 100
                mapes.append(mape)
            else:
                mapes.append(np.nan)

        bars = ax2.bar(categories, mapes, color=colors, alpha=0.7, edgecolor="black")
        ax2.set_title("Forecast Accuracy by Category (MAPE)", fontsize=12, fontweight="bold")
        ax2.set_ylabel("MAPE (%)")
        ax2.set_xlabel("Category")
        ax2.grid(True, alpha=0.3, axis="y")

        # Add value labels on bars
        for bar, mape in zip(bars, mapes):
            if not np.isnan(mape):
                height = bar.get_height()
                ax2.text(
                    bar.get_x() + bar.get_width() / 2.0,
                    height,
                    f"{mape:.1f}%",
                    ha="center",
                    va="bottom",
                    fontsize=10,
                    fontweight="bold",
                )

        plt.xticks(rotation=45, ha="right")
        fig.suptitle(title, fontsize=16, fontweight="bold")
        plt.tight_layout()

        if save_path:
            plt.savefig(save_path, dpi=self.dpi, bbox_inches="tight")
            print(f"✓ Plot saved to {save_path}")

        return fig


# Convenience functions
def quick_plot(
    actuals: pd.Series,
    forecast: pd.Series,
    conf_int: Optional[pd.DataFrame] = None,
    title: str = "Forecast vs Actuals",
    save_path: Optional[str] = None,
) -> Figure:
    """
    Quick plot of forecast vs actuals.

    Convenience function for simple plotting.

    Parameters
    ----------
    actuals : pd.Series
        Actual values
    forecast : pd.Series
        Forecasted values
    conf_int : pd.DataFrame, optional
        Confidence intervals
    title : str, default='Forecast vs Actuals'
        Plot title
    save_path : str, optional
        Path to save figure

    Returns
    -------
    fig : Figure
        Matplotlib figure object
    """
    viz = ForecastVisualizer()
    return viz.plot_forecast_vs_actuals(
        actuals=actuals, forecast=forecast, conf_int=conf_int, title=title, save_path=save_path
    )


# Made with Bob
