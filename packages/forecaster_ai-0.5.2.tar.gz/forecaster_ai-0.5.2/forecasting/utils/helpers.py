"""Helper utilities for the forecasting package."""

import random
from typing import Optional, Tuple

import numpy as np
import pandas as pd
import torch


def set_random_seed(seed: int = 42) -> None:
    """Set random seed for reproducibility.

    Args:
        seed: Random seed value
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False


def ensure_datetime_index(
    data: pd.DataFrame,
    date_column: Optional[str] = None,
) -> pd.DataFrame:
    """Ensure DataFrame has a datetime index.

    Args:
        data: Input DataFrame
        date_column: Name of date column to use as index (if not already indexed)

    Returns:
        DataFrame with datetime index

    Raises:
        ValueError: If datetime index cannot be created
    """
    if isinstance(data.index, pd.DatetimeIndex):
        return data

    if date_column is not None and date_column in data.columns:
        data = data.copy()
        data[date_column] = pd.to_datetime(data[date_column])
        data = data.set_index(date_column)
        return data

    raise ValueError("Data must have a DatetimeIndex or specify date_column parameter")


def get_frequency(data: pd.Series) -> str:
    """Infer frequency of time series.

    Args:
        data: Time series with datetime index

    Returns:
        Frequency string (e.g., 'D', 'H', 'M')

    Raises:
        ValueError: If frequency cannot be inferred
    """
    if not isinstance(data.index, pd.DatetimeIndex):
        raise ValueError("Data must have a DatetimeIndex")

    freq = pd.infer_freq(data.index)
    if freq is None:
        # Try to infer from first few differences
        if len(data) > 1:
            diff = data.index[1] - data.index[0]
            if diff.days >= 365:
                return "Y"
            elif diff.days >= 28:
                return "M"
            elif diff.days >= 7:
                return "W"
            elif diff.days >= 1:
                return "D"
            elif diff.seconds >= 3600:
                return "H"
            elif diff.seconds >= 60:
                return "T"
            else:
                return "S"
        raise ValueError("Cannot infer frequency from data")

    return freq


def create_date_range(
    start: pd.Timestamp,
    periods: int,
    freq: str,
) -> pd.DatetimeIndex:
    """Create a date range for forecasting.

    Args:
        start: Start date
        periods: Number of periods
        freq: Frequency string

    Returns:
        DatetimeIndex for forecast period
    """
    return pd.date_range(start=start, periods=periods, freq=freq)


def split_train_test(
    data: pd.Series,
    test_size: Optional[int] = None,
    test_ratio: float = 0.2,
) -> Tuple[pd.Series, pd.Series]:
    """Split time series into train and test sets.

    Args:
        data: Time series data
        test_size: Number of observations for test set (overrides test_ratio)
        test_ratio: Ratio of data to use for testing (default 0.2)

    Returns:
        Tuple of (train, test) series

    Raises:
        ValueError: If split parameters are invalid
    """
    if test_size is not None:
        if test_size <= 0 or test_size >= len(data):
            raise ValueError(f"test_size must be between 0 and {len(data)}, got {test_size}")
        split_idx = len(data) - test_size
    else:
        if not 0 < test_ratio < 1:
            raise ValueError(f"test_ratio must be between 0 and 1, got {test_ratio}")
        split_idx = int(len(data) * (1 - test_ratio))

    train = data.iloc[:split_idx]
    test = data.iloc[split_idx:]

    return train, test


def validate_exogenous_features(
    X_train: pd.DataFrame,
    X_test: Optional[pd.DataFrame] = None,
) -> None:
    """Validate exogenous features.

    Args:
        X_train: Training exogenous features
        X_test: Test exogenous features

    Raises:
        ValueError: If features are invalid
    """
    if X_train.isnull().any().any():
        raise ValueError("Training features contain missing values")

    if X_test is not None:
        if X_test.isnull().any().any():
            raise ValueError("Test features contain missing values")

        if set(X_train.columns) != set(X_test.columns):
            raise ValueError("Train and test features must have the same columns")


def calculate_horizon_from_frequency(
    freq: str,
    days: int = 30,
) -> int:
    """Calculate forecast horizon based on frequency.

    Args:
        freq: Frequency string
        days: Number of days to forecast

    Returns:
        Number of periods for the horizon
    """
    freq_map = {
        "Y": days / 365,
        "Q": days / 90,
        "M": days / 30,
        "W": days / 7,
        "D": days,
        "H": days * 24,
        "T": days * 24 * 60,
        "S": days * 24 * 60 * 60,
    }

    return int(freq_map.get(freq, days))


def resample_time_series(
    data: pd.Series,
    target_freq: str,
    agg_func: str = "mean",
) -> pd.Series:
    """Resample time series to different frequency.

    Args:
        data: Time series data
        target_freq: Target frequency
        agg_func: Aggregation function (mean, sum, first, last)

    Returns:
        Resampled time series
    """
    if not isinstance(data.index, pd.DatetimeIndex):
        raise ValueError("Data must have a DatetimeIndex")

    resampler = data.resample(target_freq)

    if agg_func == "mean":
        return resampler.mean()
    elif agg_func == "sum":
        return resampler.sum()
    elif agg_func == "first":
        return resampler.first()
    elif agg_func == "last":
        return resampler.last()
    else:
        raise ValueError(f"Unknown aggregation function: {agg_func}")


# Made with Bob
