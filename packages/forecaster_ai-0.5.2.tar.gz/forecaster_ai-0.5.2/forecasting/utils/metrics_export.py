"""Metrics export utilities for monitoring and observability."""

import time
from typing import Dict, Optional

from prometheus_client import Counter, Gauge, Histogram, start_http_server


class MetricsExporter:
    """Export metrics for monitoring using Prometheus.

    Provides methods to track forecasting metrics, model performance,
    and system health for observability.

    Attributes:
        port: Port for Prometheus metrics server
        prediction_counter: Counter for predictions made
        prediction_latency: Histogram for prediction latency
        model_accuracy: Gauge for model accuracy
        data_drift_score: Gauge for data drift detection
    """

    def __init__(self, port: int = 8000, enable_server: bool = True):
        """Initialize metrics exporter.

        Args:
            port: Port to expose metrics on
            enable_server: Whether to start the HTTP server
        """
        self.port = port

        # Define metrics
        self.prediction_counter = Counter(
            "forecasting_predictions_total",
            "Total number of predictions made",
            ["model_type", "status"],
        )

        self.prediction_latency = Histogram(
            "forecasting_prediction_latency_seconds",
            "Prediction latency in seconds",
            ["model_type"],
        )

        self.model_accuracy = Gauge(
            "forecasting_model_accuracy",
            "Model accuracy metric",
            ["model_type", "metric_name"],
        )

        self.data_drift_score = Gauge(
            "forecasting_data_drift_score",
            "Data drift detection score",
            ["feature_name"],
        )

        self.training_duration = Histogram(
            "forecasting_training_duration_seconds",
            "Model training duration in seconds",
            ["model_type"],
        )

        self.active_models = Gauge(
            "forecasting_active_models",
            "Number of active models",
            ["model_type"],
        )

        if enable_server:
            self.start_server()

    def start_server(self) -> None:
        """Start Prometheus metrics HTTP server."""
        try:
            start_http_server(self.port)
        except OSError:
            # Server already running
            pass

    def record_prediction(
        self,
        model_type: str,
        status: str = "success",
        latency: Optional[float] = None,
    ) -> None:
        """Record a prediction event.

        Args:
            model_type: Type of model used
            status: Status of prediction (success/failure)
            latency: Prediction latency in seconds
        """
        self.prediction_counter.labels(
            model_type=model_type,
            status=status,
        ).inc()

        if latency is not None:
            self.prediction_latency.labels(
                model_type=model_type,
            ).observe(latency)

    def update_model_accuracy(
        self,
        model_type: str,
        metrics: Dict[str, float],
    ) -> None:
        """Update model accuracy metrics.

        Args:
            model_type: Type of model
            metrics: Dictionary of metric names and values
        """
        for metric_name, value in metrics.items():
            self.model_accuracy.labels(
                model_type=model_type,
                metric_name=metric_name,
            ).set(value)

    def update_data_drift(
        self,
        drift_scores: Dict[str, float],
    ) -> None:
        """Update data drift scores.

        Args:
            drift_scores: Dictionary of feature names and drift scores
        """
        for feature_name, score in drift_scores.items():
            self.data_drift_score.labels(
                feature_name=feature_name,
            ).set(score)

    def record_training(
        self,
        model_type: str,
        duration: float,
    ) -> None:
        """Record model training duration.

        Args:
            model_type: Type of model
            duration: Training duration in seconds
        """
        self.training_duration.labels(
            model_type=model_type,
        ).observe(duration)

    def set_active_models(
        self,
        model_type: str,
        count: int,
    ) -> None:
        """Set number of active models.

        Args:
            model_type: Type of model
            count: Number of active models
        """
        self.active_models.labels(
            model_type=model_type,
        ).set(count)

    def time_prediction(self, model_type: str):
        """Context manager to time predictions.

        Args:
            model_type: Type of model

        Usage:
            with exporter.time_prediction("arima"):
                # make prediction
                pass
        """
        return _PredictionTimer(self, model_type)


class _PredictionTimer:
    """Context manager for timing predictions."""

    def __init__(self, exporter: MetricsExporter, model_type: str):
        """Initialize timer.

        Args:
            exporter: MetricsExporter instance
            model_type: Type of model
        """
        self.exporter = exporter
        self.model_type = model_type
        self.start_time: Optional[float] = None

    def __enter__(self) -> "_PredictionTimer":
        """Start timing."""
        self.start_time = time.time()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Stop timing and record metrics."""
        if self.start_time is not None:
            latency = time.time() - self.start_time
            status = "success" if exc_type is None else "failure"
            self.exporter.record_prediction(
                self.model_type,
                status,
                latency,
            )


# Made with Bob
