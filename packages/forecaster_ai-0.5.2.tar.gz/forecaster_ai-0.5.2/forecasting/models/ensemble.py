"""Ensemble forecasting methods."""

import pickle
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from forecasting.core.base import BaseForecaster
from forecasting.core.config import ForecastConfig
from forecasting.core.exceptions import ModelError


class EnsembleForecaster(BaseForecaster):
    """Ensemble forecaster combining multiple models.
    
    Combines predictions from multiple forecasting models using
    various aggregation strategies (mean, median, weighted average).
    
    Attributes:
        models: List of forecaster instances
        weights: Optional weights for weighted averaging
        aggregation: Aggregation method ('mean', 'median', 'weighted')
    """
    
    def __init__(
        self,
        config: ForecastConfig,
        models: Optional[List[BaseForecaster]] = None,
        weights: Optional[List[float]] = None,
        aggregation: str = "mean",
    ):
        """Initialize ensemble forecaster.
        
        Args:
            config: Forecast configuration
            models: List of forecaster instances
            weights: Optional weights for weighted averaging
            aggregation: Aggregation method
        """
        super().__init__(config)
        self.models = models or []
        self.weights = weights
        self.aggregation = aggregation
        
        if weights is not None and len(weights) != len(self.models):
            raise ModelError(
                f"Number of weights ({len(weights)}) must match "
                f"number of models ({len(self.models)})"
            )
        
        if aggregation not in ["mean", "median", "weighted"]:
            raise ModelError(
                f"Invalid aggregation method: {aggregation}. "
                "Must be 'mean', 'median', or 'weighted'"
            )
        
        if aggregation == "weighted" and weights is None:
            raise ModelError("Weights required for weighted aggregation")
    
    def add_model(
        self,
        model: BaseForecaster,
        weight: Optional[float] = None,
    ) -> "EnsembleForecaster":
        """Add a model to the ensemble.
        
        Args:
            model: Forecaster instance to add
            weight: Optional weight for the model
            
        Returns:
            Self for method chaining
        """
        self.models.append(model)
        
        if weight is not None:
            if self.weights is None:
                self.weights = [1.0] * (len(self.models) - 1)
            self.weights.append(weight)
        
        return self
    
    def fit(
        self,
        y: pd.Series,
        X: Optional[pd.DataFrame] = None,
        **kwargs: Any
    ) -> "EnsembleForecaster":
        """Fit all models in the ensemble.
        
        Args:
            y: Target time series
            X: Optional exogenous variables
            **kwargs: Additional arguments for model fitting
            
        Returns:
            Self for method chaining
        """
        try:
            self._validate_input(y, X)
            
            if not self.models:
                raise ModelError("No models in ensemble")
            
            # Fit each model
            for i, model in enumerate(self.models):
                try:
                    model.fit(y, X, **kwargs)
                except Exception as e:
                    raise ModelError(
                        f"Failed to fit model {i} ({model.__class__.__name__}): {str(e)}"
                    )
            
            self.is_fitted = True
            
            # Aggregate validation metrics
            all_metrics = [m.get_validation_metrics() for m in self.models]
            if all_metrics and all_metrics[0]:
                self._validation_metrics = {
                    f"model_{i}_{k}": v
                    for i, metrics in enumerate(all_metrics)
                    for k, v in metrics.items()
                }
            
            return self
            
        except Exception as e:
            raise ModelError(f"Failed to fit ensemble: {str(e)}")
    
    def predict(
        self,
        horizon: Optional[int] = None,
        X: Optional[pd.DataFrame] = None,
        return_conf_int: bool = True,
        **kwargs: Any
    ) -> Tuple[pd.Series, Optional[pd.DataFrame]]:
        """Generate ensemble forecasts.
        
        Args:
            horizon: Number of periods to forecast
            X: Optional exogenous variables
            return_conf_int: Whether to return confidence intervals
            **kwargs: Additional prediction arguments
            
        Returns:
            Tuple of (predictions, confidence_intervals)
        """
        self._check_is_fitted()
        
        try:
            if not self.models:
                raise ModelError("No models in ensemble")
            
            # Get predictions from all models
            predictions_list = []
            conf_ints_list = []
            
            for model in self.models:
                pred, conf_int = model.predict(
                    horizon=horizon,
                    X=X,
                    return_conf_int=return_conf_int,
                    **kwargs
                )
                predictions_list.append(pred)
                if conf_int is not None:
                    conf_ints_list.append(conf_int)
            
            # Aggregate predictions
            predictions_array = np.array([p.values for p in predictions_list])
            
            if self.aggregation == "mean":
                ensemble_pred = np.mean(predictions_array, axis=0)
            elif self.aggregation == "median":
                ensemble_pred = np.median(predictions_array, axis=0)
            elif self.aggregation == "weighted":
                weights_array = np.array(self.weights).reshape(-1, 1)
                weights_array = weights_array / weights_array.sum()
                ensemble_pred = np.sum(predictions_array * weights_array, axis=0)
            
            # Create series with proper index
            ensemble_series = pd.Series(
                ensemble_pred,
                index=predictions_list[0].index,
                name="ensemble_forecast"
            )
            
            # Aggregate confidence intervals if available
            ensemble_conf_int = None
            if return_conf_int and conf_ints_list:
                lower_bounds = np.array([ci["lower"].values for ci in conf_ints_list])
                upper_bounds = np.array([ci["upper"].values for ci in conf_ints_list])
                
                if self.aggregation == "mean":
                    ensemble_lower = np.mean(lower_bounds, axis=0)
                    ensemble_upper = np.mean(upper_bounds, axis=0)
                elif self.aggregation == "median":
                    ensemble_lower = np.median(lower_bounds, axis=0)
                    ensemble_upper = np.median(upper_bounds, axis=0)
                elif self.aggregation == "weighted":
                    ensemble_lower = np.sum(lower_bounds * weights_array, axis=0)
                    ensemble_upper = np.sum(upper_bounds * weights_array, axis=0)
                
                ensemble_conf_int = pd.DataFrame({
                    "lower": ensemble_lower,
                    "upper": ensemble_upper
                }, index=predictions_list[0].index)
            
            return ensemble_series, ensemble_conf_int
            
        except Exception as e:
            raise ModelError(f"Failed to generate ensemble forecast: {str(e)}")
    
    def get_model_weights(self) -> Dict[str, float]:
        """Get weights for each model in the ensemble.
        
        Returns:
            Dictionary mapping model names to weights
        """
        if self.weights is None:
            # Equal weights
            weights = [1.0 / len(self.models)] * len(self.models)
        else:
            # Normalize weights
            total = sum(self.weights)
            weights = [w / total for w in self.weights]
        
        return {
            f"model_{i}_{model.__class__.__name__}": weight
            for i, (model, weight) in enumerate(zip(self.models, weights))
        }
    
    def save_model(self, path: str) -> None:
        """Save ensemble model to disk.
        
        Args:
            path: Path to save the model
        """
        if not self.is_fitted:
            raise ModelError("Cannot save unfitted model")
        
        try:
            model_data = {
                "models": self.models,
                "config": self.config,
                "weights": self.weights,
                "aggregation": self.aggregation,
                "validation_metrics": self._validation_metrics,
            }
            
            with open(path, "wb") as f:
                pickle.dump(model_data, f)
                
        except Exception as e:
            raise ModelError(f"Failed to save model: {str(e)}")
    
    @classmethod
    def load_model(cls, path: str) -> "EnsembleForecaster":
        """Load ensemble model from disk.
        
        Args:
            path: Path to load the model from
            
        Returns:
            Loaded EnsembleForecaster instance
        """
        try:
            with open(path, "rb") as f:
                model_data = pickle.load(f)
            
            forecaster = cls(
                config=model_data["config"],
                models=model_data["models"],
                weights=model_data["weights"],
                aggregation=model_data["aggregation"],
            )
            
            forecaster._validation_metrics = model_data["validation_metrics"]
            forecaster.is_fitted = True
            
            return forecaster
            
        except Exception as e:
            raise ModelError(f"Failed to load model: {str(e)}")


class StackingEnsemble(BaseForecaster):
    """Stacking ensemble with meta-learner.
    
    Uses predictions from base models as features for a meta-learner
    to generate final predictions.
    """
    
    def __init__(
        self,
        config: ForecastConfig,
        base_models: Optional[List[BaseForecaster]] = None,
        meta_model: Optional[BaseForecaster] = None,
    ):
        """Initialize stacking ensemble.
        
        Args:
            config: Forecast configuration
            base_models: List of base forecaster instances
            meta_model: Meta-learner forecaster instance
        """
        super().__init__(config)
        self.base_models = base_models or []
        self.meta_model = meta_model
        self._base_predictions: Optional[pd.DataFrame] = None
    
    def fit(
        self,
        y: pd.Series,
        X: Optional[pd.DataFrame] = None,
        **kwargs: Any
    ) -> "StackingEnsemble":
        """Fit stacking ensemble.
        
        Args:
            y: Target time series
            X: Optional exogenous variables
            **kwargs: Additional fitting arguments
            
        Returns:
            Self for method chaining
        """
        try:
            self._validate_input(y, X)
            
            if not self.base_models:
                raise ModelError("No base models provided")
            
            if self.meta_model is None:
                raise ModelError("No meta model provided")
            
            # Fit base models and collect predictions
            base_predictions = []
            
            for i, model in enumerate(self.base_models):
                # Fit base model
                model.fit(y, X, **kwargs)
                
                # Get in-sample predictions (simplified)
                # In production, use cross-validation
                pred, _ = model.predict(horizon=len(y), X=X, return_conf_int=False)
                base_predictions.append(pred.values)
            
            # Create meta-features
            self._base_predictions = pd.DataFrame(
                np.column_stack(base_predictions),
                index=y.index,
                columns=[f"base_{i}" for i in range(len(self.base_models))]
            )
            
            # Fit meta-model
            self.meta_model.fit(y, self._base_predictions, **kwargs)
            
            self.is_fitted = True
            
            return self
            
        except Exception as e:
            raise ModelError(f"Failed to fit stacking ensemble: {str(e)}")
    
    def predict(
        self,
        horizon: Optional[int] = None,
        X: Optional[pd.DataFrame] = None,
        return_conf_int: bool = True,
        **kwargs: Any
    ) -> Tuple[pd.Series, Optional[pd.DataFrame]]:
        """Generate stacking ensemble forecasts.
        
        Args:
            horizon: Number of periods to forecast
            X: Optional exogenous variables
            return_conf_int: Whether to return confidence intervals
            **kwargs: Additional prediction arguments
            
        Returns:
            Tuple of (predictions, confidence_intervals)
        """
        self._check_is_fitted()
        
        try:
            # Get predictions from base models
            base_predictions = []
            
            for model in self.base_models:
                pred, _ = model.predict(
                    horizon=horizon,
                    X=X,
                    return_conf_int=False,
                    **kwargs
                )
                base_predictions.append(pred.values)
            
            # Create meta-features
            meta_features = pd.DataFrame(
                np.column_stack(base_predictions),
                columns=[f"base_{i}" for i in range(len(self.base_models))]
            )
            
            # Get meta-model predictions
            final_pred, conf_int = self.meta_model.predict(
                horizon=horizon,
                X=meta_features,
                return_conf_int=return_conf_int,
                **kwargs
            )
            
            return final_pred, conf_int
            
        except Exception as e:
            raise ModelError(f"Failed to generate stacking forecast: {str(e)}")


# Made with Bob
