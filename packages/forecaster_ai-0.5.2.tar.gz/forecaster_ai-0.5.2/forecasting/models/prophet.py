"""Prophet-based forecasting models."""

import pickle
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from forecasting.core.base import BaseForecaster
from forecasting.core.config import ForecastConfig
from forecasting.core.exceptions import ModelError


class ProphetForecaster(BaseForecaster):
    """Facebook Prophet forecaster.
    
    Wrapper around Facebook Prophet for time series forecasting with
    automatic seasonality detection and holiday effects.
    
    Attributes:
        growth: Growth model ('linear' or 'logistic')
        changepoint_prior_scale: Flexibility of trend changes
        seasonality_prior_scale: Flexibility of seasonality
        holidays_prior_scale: Flexibility of holiday effects
        seasonality_mode: Seasonality mode ('additive' or 'multiplicative')
        yearly_seasonality: Whether to include yearly seasonality
        weekly_seasonality: Whether to include weekly seasonality
        daily_seasonality: Whether to include daily seasonality
    """
    
    def __init__(
        self,
        config: ForecastConfig,
        growth: str = "linear",
        changepoint_prior_scale: float = 0.05,
        seasonality_prior_scale: float = 10.0,
        holidays_prior_scale: float = 10.0,
        seasonality_mode: str = "additive",
        yearly_seasonality: str = "auto",
        weekly_seasonality: str = "auto",
        daily_seasonality: str = "auto",
        mcmc_samples: int = 0,
        interval_width: float = 0.80,
        uncertainty_samples: int = 1000,
    ):
        """Initialize Prophet forecaster.
        
        Args:
            config: Forecast configuration
            growth: Growth model ('linear' or 'logistic')
            changepoint_prior_scale: Flexibility of trend changes
            seasonality_prior_scale: Flexibility of seasonality
            holidays_prior_scale: Flexibility of holiday effects
            seasonality_mode: Seasonality mode ('additive' or 'multiplicative')
            yearly_seasonality: Yearly seasonality setting
            weekly_seasonality: Weekly seasonality setting
            daily_seasonality: Daily seasonality setting
            mcmc_samples: Number of MCMC samples (0 for MAP estimation)
            interval_width: Width of uncertainty intervals
            uncertainty_samples: Number of samples for uncertainty
        """
        super().__init__(config)
        self.growth = growth
        self.changepoint_prior_scale = changepoint_prior_scale
        self.seasonality_prior_scale = seasonality_prior_scale
        self.holidays_prior_scale = holidays_prior_scale
        self.seasonality_mode = seasonality_mode
        self.yearly_seasonality = yearly_seasonality
        self.weekly_seasonality = weekly_seasonality
        self.daily_seasonality = daily_seasonality
        self.mcmc_samples = mcmc_samples
        self.interval_width = interval_width
        self.uncertainty_samples = uncertainty_samples
        self._regressor_names: List[str] = []
    
    def fit(
        self,
        y: pd.Series,
        X: Optional[pd.DataFrame] = None,
        **kwargs: Any
    ) -> "ProphetForecaster":
        """Fit Prophet model.
        
        Args:
            y: Target time series
            X: Optional exogenous variables (regressors)
            **kwargs: Additional arguments for Prophet fitting
            
        Returns:
            Self for method chaining
        """
        try:
            from prophet import Prophet
            
            self._validate_input(y, X)
            
            # Prepare data in Prophet format
            df = pd.DataFrame({
                "ds": y.index,
                "y": y.values
            })
            
            # Initialize Prophet model
            self.model = Prophet(
                growth=self.growth,
                changepoint_prior_scale=self.changepoint_prior_scale,
                seasonality_prior_scale=self.seasonality_prior_scale,
                holidays_prior_scale=self.holidays_prior_scale,
                seasonality_mode=self.seasonality_mode,
                yearly_seasonality=self.yearly_seasonality,
                weekly_seasonality=self.weekly_seasonality,
                daily_seasonality=self.daily_seasonality,
                mcmc_samples=self.mcmc_samples,
                interval_width=self.interval_width,
                uncertainty_samples=self.uncertainty_samples,
            )
            
            # Add regressors if provided
            if X is not None:
                self._regressor_names = X.columns.tolist()
                for col in X.columns:
                    self.model.add_regressor(col)
                
                # Add regressors to dataframe
                for col in X.columns:
                    df[col] = X[col].values
            
            # Fit the model
            self.model.fit(df, **kwargs)
            self.is_fitted = True
            
            # Store validation metrics (in-sample)
            forecast = self.model.predict(df)
            residuals = y.values - forecast["yhat"].values
            
            self._validation_metrics = {
                "mae": float(np.mean(np.abs(residuals))),
                "rmse": float(np.sqrt(np.mean(residuals ** 2))),
                "mape": float(np.mean(np.abs(residuals / y.values)) * 100),
            }
            
            return self
            
        except ImportError:
            raise ModelError(
                "prophet package required for ProphetForecaster. "
                "Install with: pip install prophet"
            )
        except Exception as e:
            raise ModelError(f"Failed to fit Prophet model: {str(e)}")
    
    def predict(
        self,
        horizon: Optional[int] = None,
        X: Optional[pd.DataFrame] = None,
        return_conf_int: bool = True,
        **kwargs: Any
    ) -> Tuple[pd.Series, Optional[pd.DataFrame]]:
        """Generate Prophet forecasts.
        
        Args:
            horizon: Number of periods to forecast
            X: Optional exogenous variables for forecast period
            return_conf_int: Whether to return confidence intervals
            **kwargs: Additional prediction arguments
            
        Returns:
            Tuple of (predictions, confidence_intervals)
        """
        self._check_is_fitted()
        
        try:
            if horizon is None:
                horizon = self.config.horizon
            
            # Create future dataframe
            future = self.model.make_future_dataframe(
                periods=horizon,
                include_history=False
            )
            
            # Add regressors if provided
            if X is not None:
                if set(X.columns) != set(self._regressor_names):
                    raise ModelError(
                        f"Regressor columns must match training: {self._regressor_names}"
                    )
                for col in X.columns:
                    future[col] = X[col].values
            elif self._regressor_names:
                raise ModelError(
                    f"Model was trained with regressors: {self._regressor_names}. "
                    "Must provide X for prediction."
                )
            
            # Generate forecast
            forecast = self.model.predict(future)
            
            # Extract predictions
            predictions = pd.Series(
                forecast["yhat"].values,
                index=forecast["ds"].values,
                name="forecast"
            )
            
            # Extract confidence intervals if requested
            conf_int = None
            if return_conf_int:
                conf_int = pd.DataFrame({
                    "lower": forecast["yhat_lower"].values,
                    "upper": forecast["yhat_upper"].values
                }, index=forecast["ds"].values)
            
            return predictions, conf_int
            
        except Exception as e:
            raise ModelError(f"Failed to generate Prophet forecast: {str(e)}")
    
    def add_seasonality(
        self,
        name: str,
        period: float,
        fourier_order: int,
        prior_scale: Optional[float] = None,
        mode: Optional[str] = None,
    ) -> "ProphetForecaster":
        """Add custom seasonality to the model.
        
        Args:
            name: Name of the seasonality component
            period: Period of the seasonality in days
            fourier_order: Number of Fourier terms
            prior_scale: Prior scale for seasonality
            mode: Seasonality mode ('additive' or 'multiplicative')
            
        Returns:
            Self for method chaining
        """
        if self.is_fitted:
            raise ModelError("Cannot add seasonality after fitting")
        
        if self.model is None:
            from prophet import Prophet
            self.model = Prophet()
        
        self.model.add_seasonality(
            name=name,
            period=period,
            fourier_order=fourier_order,
            prior_scale=prior_scale,
            mode=mode,
        )
        
        return self
    
    def add_country_holidays(self, country_name: str) -> "ProphetForecaster":
        """Add country-specific holidays to the model.
        
        Args:
            country_name: Country name (e.g., 'US', 'UK', 'IN')
            
        Returns:
            Self for method chaining
        """
        if self.is_fitted:
            raise ModelError("Cannot add holidays after fitting")
        
        if self.model is None:
            from prophet import Prophet
            self.model = Prophet()
        
        self.model.add_country_holidays(country_name=country_name)
        
        return self
    
    def plot_components(self, forecast: Optional[pd.DataFrame] = None) -> Any:
        """Plot forecast components.
        
        Args:
            forecast: Forecast dataframe (if None, uses last prediction)
            
        Returns:
            Matplotlib figure
        """
        self._check_is_fitted()
        
        if forecast is None:
            # Generate forecast for plotting
            future = self.model.make_future_dataframe(periods=0)
            forecast = self.model.predict(future)
        
        return self.model.plot_components(forecast)
    
    def save_model(self, path: str) -> None:
        """Save Prophet model to disk.
        
        Args:
            path: Path to save the model
        """
        if not self.is_fitted:
            raise ModelError("Cannot save unfitted model")
        
        try:
            model_data = {
                "model": self.model,
                "config": self.config,
                "growth": self.growth,
                "changepoint_prior_scale": self.changepoint_prior_scale,
                "seasonality_prior_scale": self.seasonality_prior_scale,
                "holidays_prior_scale": self.holidays_prior_scale,
                "seasonality_mode": self.seasonality_mode,
                "regressor_names": self._regressor_names,
                "validation_metrics": self._validation_metrics,
            }
            
            with open(path, "wb") as f:
                pickle.dump(model_data, f)
                
        except Exception as e:
            raise ModelError(f"Failed to save model: {str(e)}")
    
    @classmethod
    def load_model(cls, path: str) -> "ProphetForecaster":
        """Load Prophet model from disk.
        
        Args:
            path: Path to load the model from
            
        Returns:
            Loaded ProphetForecaster instance
        """
        try:
            with open(path, "rb") as f:
                model_data = pickle.load(f)
            
            forecaster = cls(
                config=model_data["config"],
                growth=model_data["growth"],
                changepoint_prior_scale=model_data["changepoint_prior_scale"],
                seasonality_prior_scale=model_data["seasonality_prior_scale"],
                holidays_prior_scale=model_data["holidays_prior_scale"],
                seasonality_mode=model_data["seasonality_mode"],
            )
            
            forecaster.model = model_data["model"]
            forecaster._regressor_names = model_data["regressor_names"]
            forecaster._validation_metrics = model_data["validation_metrics"]
            forecaster.is_fitted = True
            
            return forecaster
            
        except Exception as e:
            raise ModelError(f"Failed to load model: {str(e)}")


class ProphetWithRegressors(ProphetForecaster):
    """Prophet forecaster with automatic regressor handling.
    
    Extends ProphetForecaster with better support for multiple regressors
    and automatic feature engineering.
    """
    
    def __init__(
        self,
        config: ForecastConfig,
        regressor_mode: str = "additive",
        standardize_regressors: bool = True,
        **kwargs: Any
    ):
        """Initialize Prophet with regressors.
        
        Args:
            config: Forecast configuration
            regressor_mode: Mode for regressors ('additive' or 'multiplicative')
            standardize_regressors: Whether to standardize regressors
            **kwargs: Additional Prophet parameters
        """
        super().__init__(config, **kwargs)
        self.regressor_mode = regressor_mode
        self.standardize_regressors = standardize_regressors
        self._regressor_scalers: Dict[str, Tuple[float, float]] = {}
    
    def fit(
        self,
        y: pd.Series,
        X: Optional[pd.DataFrame] = None,
        **kwargs: Any
    ) -> "ProphetWithRegressors":
        """Fit Prophet model with automatic regressor handling.
        
        Args:
            y: Target time series
            X: Optional exogenous variables
            **kwargs: Additional fitting arguments
            
        Returns:
            Self for method chaining
        """
        if X is not None and self.standardize_regressors:
            # Standardize regressors
            X_scaled = X.copy()
            for col in X.columns:
                mean = X[col].mean()
                std = X[col].std()
                self._regressor_scalers[col] = (mean, std)
                X_scaled[col] = (X[col] - mean) / (std + 1e-8)
            
            return super().fit(y, X_scaled, **kwargs)
        else:
            return super().fit(y, X, **kwargs)
    
    def predict(
        self,
        horizon: Optional[int] = None,
        X: Optional[pd.DataFrame] = None,
        return_conf_int: bool = True,
        **kwargs: Any
    ) -> Tuple[pd.Series, Optional[pd.DataFrame]]:
        """Generate forecasts with automatic regressor scaling.
        
        Args:
            horizon: Number of periods to forecast
            X: Optional exogenous variables
            return_conf_int: Whether to return confidence intervals
            **kwargs: Additional prediction arguments
            
        Returns:
            Tuple of (predictions, confidence_intervals)
        """
        if X is not None and self.standardize_regressors:
            # Scale regressors using training statistics
            X_scaled = X.copy()
            for col in X.columns:
                if col in self._regressor_scalers:
                    mean, std = self._regressor_scalers[col]
                    X_scaled[col] = (X[col] - mean) / (std + 1e-8)
            
            return super().predict(horizon, X_scaled, return_conf_int, **kwargs)
        else:
            return super().predict(horizon, X, return_conf_int, **kwargs)


def create_holiday_dataframe(
    country: str,
    years: List[int],
) -> pd.DataFrame:
    """Create holiday dataframe for Prophet.
    
    Args:
        country: Country code (e.g., 'US', 'UK', 'IN')
        years: List of years to include
        
    Returns:
        DataFrame with holiday dates
    """
    try:
        import holidays
        
        holiday_dates = []
        holiday_names = []
        
        for year in years:
            country_holidays = holidays.country_holidays(country, years=year)
            for date, name in country_holidays.items():
                holiday_dates.append(date)
                holiday_names.append(name)
        
        return pd.DataFrame({
            "ds": pd.to_datetime(holiday_dates),
            "holiday": holiday_names
        })
        
    except ImportError:
        raise ModelError(
            "holidays package required. Install with: pip install holidays"
        )


# Made with Bob
