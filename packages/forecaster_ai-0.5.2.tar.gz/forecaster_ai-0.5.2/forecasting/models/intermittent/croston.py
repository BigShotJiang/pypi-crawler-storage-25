"""
Croston's method for intermittent demand forecasting.

Reference:
    Croston, J. D. (1972). Forecasting and stock control for intermittent demands.
    Operational Research Quarterly, 23(3), 289-303.
"""

from typing import Optional, Tuple
import numpy as np
import pandas as pd

from forecasting.core.base import BaseForecaster
from forecasting.core.config import ForecastConfig
from forecasting.core.exceptions import ModelNotFittedError, ValidationError


class CrostonForecaster(BaseForecaster):
    """
    Croston's method for intermittent demand forecasting.
    
    This method separates the demand into two components:
    1. Demand size (z): The size of demand when it occurs
    2. Inter-arrival time (p): The time between demand occurrences
    
    The forecast is then calculated as: forecast = z / p
    
    Best suited for:
    - Spare parts demand
    - Slow-moving items
    - Items with many zero values
    
    Parameters
    ----------
    alpha : float, default=0.1
        Smoothing parameter for exponential smoothing (0 < alpha <= 1)
    min_demand_threshold : float, default=0.01
        Minimum value to consider as non-zero demand
    
    Attributes
    ----------
    demand_size_ : float
        Smoothed demand size estimate
    inter_arrival_ : float
        Smoothed inter-arrival time estimate
    is_fitted : bool
        Whether the model has been fitted
    
    Examples
    --------
    >>> import numpy as np
    >>> from forecasting.models.intermittent import CrostonForecaster
    >>> 
    >>> # Intermittent demand data
    >>> y = np.array([0, 0, 5, 0, 0, 0, 3, 0, 0, 0, 0, 7, 0, 0, 2])
    >>> 
    >>> # Fit model
    >>> model = CrostonForecaster(alpha=0.1)
    >>> model.fit(y)
    >>> 
    >>> # Forecast next 10 periods
    >>> forecast = model.predict(steps=10)
    >>> print(forecast)
    """
    
    def __init__(
        self,
        config: Optional[ForecastConfig] = None,
        alpha: float = 0.1,
        min_demand_threshold: float = 0.01
    ):
        """Initialize Croston forecaster."""
        super().__init__(config)
        
        if not 0 < alpha <= 1:
            raise ValidationError("alpha must be between 0 and 1")
        
        self.alpha = alpha
        self.min_demand_threshold = min_demand_threshold
        
        # Model parameters (fitted)
        self.demand_size_: Optional[float] = None
        self.inter_arrival_: Optional[float] = None
        self.last_demand_period_: Optional[int] = None
        
    def fit(
        self,
        y: np.ndarray,
        dates: Optional[np.ndarray] = None,
        exog: Optional[np.ndarray] = None
    ) -> 'CrostonForecaster':
        """
        Fit Croston's model to intermittent demand data.
        
        Parameters
        ----------
        y : np.ndarray
            Time series data with intermittent demand
        dates : np.ndarray, optional
            Not used, kept for API consistency
        exog : np.ndarray, optional
            Not used, Croston's method doesn't use exogenous variables
            
        Returns
        -------
        self : CrostonForecaster
            Fitted model
        """
        # Validate input
        y = self._validate_input(y)
        
        # Identify non-zero demand periods
        non_zero_mask = y > self.min_demand_threshold
        non_zero_indices = np.where(non_zero_mask)[0]
        
        if len(non_zero_indices) == 0:
            raise ValidationError("No non-zero demand found in the data")
        
        if len(non_zero_indices) < 2:
            # Not enough data points, use simple average
            self.demand_size_ = y[non_zero_indices[0]]
            self.inter_arrival_ = len(y)
            self.last_demand_period_ = non_zero_indices[0]
        else:
            # Initialize with first non-zero demand
            self.demand_size_ = y[non_zero_indices[0]]
            self.inter_arrival_ = float(non_zero_indices[0] + 1)
            
            # Update estimates using exponential smoothing
            for i in range(1, len(non_zero_indices)):
                current_idx = non_zero_indices[i]
                previous_idx = non_zero_indices[i - 1]
                
                # Update demand size
                current_demand = y[current_idx]
                self.demand_size_ = (
                    self.alpha * current_demand +
                    (1 - self.alpha) * self.demand_size_
                )
                
                # Update inter-arrival time
                interval = current_idx - previous_idx
                self.inter_arrival_ = (
                    self.alpha * interval +
                    (1 - self.alpha) * self.inter_arrival_
                )
            
            self.last_demand_period_ = non_zero_indices[-1]
        
        self.is_fitted = True
        self.logger.info(
            f"Croston model fitted: demand_size={self.demand_size_:.2f}, "
            f"inter_arrival={self.inter_arrival_:.2f}"
        )
        
        return self
    
    def predict(
        self,
        steps: int = 1,
        exog: Optional[np.ndarray] = None,
        return_conf_int: bool = False,
        alpha: float = 0.05
    ) -> np.ndarray:
        """
        Generate forecasts using Croston's method.
        
        Parameters
        ----------
        steps : int, default=1
            Number of periods to forecast
        exog : np.ndarray, optional
            Not used, kept for API consistency
        return_conf_int : bool, default=False
            Not supported for Croston's method
        alpha : float, default=0.05
            Not used, kept for API consistency
            
        Returns
        -------
        forecast : np.ndarray
            Point forecasts for the next 'steps' periods
        """
        if not self.is_fitted:
            raise ModelNotFittedError("Model must be fitted before prediction")
        
        if return_conf_int:
            self.logger.warning(
                "Confidence intervals not supported for Croston's method"
            )
        
        # Croston's forecast: demand_size / inter_arrival
        forecast_value = self.demand_size_ / self.inter_arrival_
        
        # Return constant forecast for all steps
        forecast = np.full(steps, forecast_value)
        
        return forecast
    
    def get_params(self) -> dict:
        """Get model parameters."""
        params = {
            'alpha': self.alpha,
            'min_demand_threshold': self.min_demand_threshold
        }
        
        if self.is_fitted:
            params.update({
                'demand_size': self.demand_size_,
                'inter_arrival': self.inter_arrival_,
                'forecast_value': self.demand_size_ / self.inter_arrival_
            })
        
        return params
    
    def _validate_input(self, y: np.ndarray) -> np.ndarray:
        """Validate input data."""
        if not isinstance(y, np.ndarray):
            y = np.array(y)
        
        if y.ndim != 1:
            raise ValidationError("Input must be 1-dimensional")
        
        if len(y) < 2:
            raise ValidationError("Input must have at least 2 observations")
        
        if np.any(y < 0):
            raise ValidationError("Demand cannot be negative")
        
        return y
    
    def calculate_intermittency_metrics(self, y: np.ndarray) -> dict:
        """
        Calculate intermittency metrics for the data.
        
        Parameters
        ----------
        y : np.ndarray
            Time series data
            
        Returns
        -------
        metrics : dict
            Dictionary containing:
            - zero_ratio: Proportion of zero values
            - demand_intervals: Average time between demands
            - cv_squared: Squared coefficient of variation
            - adi: Average demand interval
        """
        y = self._validate_input(y)
        
        # Zero ratio
        zero_ratio = np.sum(y <= self.min_demand_threshold) / len(y)
        
        # Non-zero demands
        non_zero_mask = y > self.min_demand_threshold
        non_zero_indices = np.where(non_zero_mask)[0]
        
        if len(non_zero_indices) < 2:
            return {
                'zero_ratio': zero_ratio,
                'demand_intervals': len(y),
                'cv_squared': 0.0,
                'adi': len(y),
                'is_intermittent': zero_ratio > 0.5
            }
        
        # Calculate intervals between demands
        intervals = np.diff(non_zero_indices)
        avg_interval = np.mean(intervals)
        
        # Coefficient of variation squared
        non_zero_demands = y[non_zero_mask]
        if len(non_zero_demands) > 1:
            cv_squared = (np.std(non_zero_demands) / np.mean(non_zero_demands)) ** 2
        else:
            cv_squared = 0.0
        
        # Average Demand Interval (ADI)
        adi = len(y) / len(non_zero_indices)
        
        # Classification: intermittent if ADI > 1.32 (Syntetos et al., 2005)
        is_intermittent = adi > 1.32
        
        return {
            'zero_ratio': zero_ratio,
            'demand_intervals': avg_interval,
            'cv_squared': cv_squared,
            'adi': adi,
            'is_intermittent': is_intermittent
        }

# Made with Bob
