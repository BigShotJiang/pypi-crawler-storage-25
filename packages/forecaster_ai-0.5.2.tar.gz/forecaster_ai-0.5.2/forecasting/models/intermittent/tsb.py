"""
TSB (Teunter-Syntetos-Babai) method for intermittent demand forecasting.

Reference:
    Teunter, R. H., Syntetos, A. A., & Babai, M. Z. (2011).
    Intermittent demand: Linking forecasting to inventory obsolescence.
    European Journal of Operational Research, 214(3), 606-615.
"""

from typing import Optional
import numpy as np

from forecasting.core.base import BaseForecaster
from forecasting.core.config import ForecastConfig
from forecasting.core.exceptions import ModelNotFittedError, ValidationError


class TSBForecaster(BaseForecaster):
    """
    TSB (Teunter-Syntetos-Babai) method for intermittent demand forecasting.
    
    An improved version of Croston's method that uses probability-weighted forecasts.
    Instead of forecasting demand size / inter-arrival time, TSB forecasts:
    - Probability of demand occurrence
    - Demand size when demand occurs
    
    The forecast is: probability * demand_size
    
    Best suited for:
    - Very intermittent demand (ADI > 1.32)
    - Items with high variability
    - Better than Croston for lumpy demand
    
    Parameters
    ----------
    alpha_demand : float, default=0.1
        Smoothing parameter for demand size (0 < alpha <= 1)
    alpha_probability : float, default=0.1
        Smoothing parameter for demand probability (0 < alpha <= 1)
    min_demand_threshold : float, default=0.01
        Minimum value to consider as non-zero demand
    
    Attributes
    ----------
    demand_size_ : float
        Smoothed demand size estimate
    demand_probability_ : float
        Smoothed probability of demand occurrence
    is_fitted : bool
        Whether the model has been fitted
    
    Examples
    --------
    >>> import numpy as np
    >>> from forecasting.models.intermittent import TSBForecaster
    >>> 
    >>> # Very intermittent demand data
    >>> y = np.array([0, 0, 0, 8, 0, 0, 0, 0, 0, 12, 0, 0, 0, 0, 0, 0, 5])
    >>> 
    >>> # Fit TSB model
    >>> model = TSBForecaster(alpha_demand=0.1, alpha_probability=0.1)
    >>> model.fit(y)
    >>> 
    >>> # Forecast next 10 periods
    >>> forecast = model.predict(steps=10)
    >>> print(forecast)
    """
    
    def __init__(
        self,
        config: Optional[ForecastConfig] = None,
        alpha_demand: float = 0.1,
        alpha_probability: float = 0.1,
        min_demand_threshold: float = 0.01
    ):
        """Initialize TSB forecaster."""
        super().__init__(config or ForecastConfig())
        
        if not 0 < alpha_demand <= 1:
            raise ValidationError("alpha_demand must be between 0 and 1")
        if not 0 < alpha_probability <= 1:
            raise ValidationError("alpha_probability must be between 0 and 1")
        
        self.alpha_demand = alpha_demand
        self.alpha_probability = alpha_probability
        self.min_demand_threshold = min_demand_threshold
        
        # Model parameters (fitted)
        self.demand_size_: Optional[float] = None
        self.demand_probability_: Optional[float] = None
        
    def fit(
        self,
        y: np.ndarray,
        dates: Optional[np.ndarray] = None,
        exog: Optional[np.ndarray] = None
    ) -> 'TSBForecaster':
        """
        Fit TSB model to intermittent demand data.
        
        Parameters
        ----------
        y : np.ndarray
            Time series data with intermittent demand
        dates : np.ndarray, optional
            Not used, kept for API consistency
        exog : np.ndarray, optional
            Not used, TSB doesn't use exogenous variables
            
        Returns
        -------
        self : TSBForecaster
            Fitted model
        """
        # Validate input
        y = self._validate_input(y)
        
        # Identify non-zero demand periods
        non_zero_mask = y > self.min_demand_threshold
        non_zero_indices = np.where(non_zero_mask)[0]
        
        if len(non_zero_indices) == 0:
            raise ValidationError("No non-zero demand found in the data")
        
        # Initialize demand size with first non-zero demand
        self.demand_size_ = float(y[non_zero_indices[0]])
        
        # Initialize probability (1 if demand, 0 if no demand)
        self.demand_probability_ = 1.0 if non_zero_indices[0] == 0 else 0.0
        
        # Update estimates using exponential smoothing
        for t in range(1, len(y)):
            # Binary indicator: 1 if demand occurs, 0 otherwise
            demand_indicator = 1.0 if y[t] > self.min_demand_threshold else 0.0
            
            # Update demand probability
            self.demand_probability_ = (
                self.alpha_probability * demand_indicator +
                (1 - self.alpha_probability) * self.demand_probability_
            )
            
            # Update demand size (only when demand occurs)
            if demand_indicator == 1.0:
                self.demand_size_ = (
                    self.alpha_demand * y[t] +
                    (1 - self.alpha_demand) * self.demand_size_
                )
        
        self.is_fitted = True
        self.logger.info(
            f"TSB model fitted: demand_size={self.demand_size_:.2f}, "
            f"probability={self.demand_probability_:.4f}"
        )
        
        return self
    
    def predict(
        self,
        steps: int = 1,
        exog: Optional[np.ndarray] = None,
        return_conf_int: bool = False,
        alpha: float = 0.05
    ) -> np.ndarray:
        """
        Generate forecasts using TSB method.
        
        Parameters
        ----------
        steps : int, default=1
            Number of periods to forecast
        exog : np.ndarray, optional
            Not used, kept for API consistency
        return_conf_int : bool, default=False
            Not supported for TSB method
        alpha : float, default=0.05
            Not used, kept for API consistency
            
        Returns
        -------
        forecast : np.ndarray
            Point forecasts for the next 'steps' periods
        """
        if not self.is_fitted:
            raise ModelNotFittedError("Model must be fitted before prediction")
        
        if return_conf_int:
            self.logger.warning(
                "Confidence intervals not supported for TSB method"
            )
        
        # TSB forecast: probability * demand_size
        forecast_value = self.demand_probability_ * self.demand_size_
        
        # Return constant forecast for all steps
        forecast = np.full(steps, forecast_value)
        
        return forecast
    
    def get_params(self) -> dict:
        """Get model parameters."""
        params = {
            'alpha_demand': self.alpha_demand,
            'alpha_probability': self.alpha_probability,
            'min_demand_threshold': self.min_demand_threshold
        }
        
        if self.is_fitted:
            params.update({
                'demand_size': self.demand_size_,
                'demand_probability': self.demand_probability_,
                'forecast_value': self.demand_probability_ * self.demand_size_
            })
        
        return params
    
    def _validate_input(self, y: np.ndarray) -> np.ndarray:
        """Validate input data."""
        if not isinstance(y, np.ndarray):
            y = np.array(y)
        
        if y.ndim != 1:
            raise ValidationError("Input must be 1-dimensional")
        
        if len(y) < 2:
            raise ValidationError("Input must have at least 2 observations")
        
        if np.any(y < 0):
            raise ValidationError("Demand cannot be negative")
        
        return y
    
    def compare_with_croston(self, y: np.ndarray) -> dict:
        """
        Compare TSB forecast with Croston's method.
        
        Parameters
        ----------
        y : np.ndarray
            Time series data
            
        Returns
        -------
        comparison : dict
            Dictionary containing forecasts from both methods
        """
        from forecasting.models.intermittent.croston import CrostonForecaster
        
        # Fit both models
        croston = CrostonForecaster(alpha=self.alpha_demand)
        croston.fit(y)
        
        # Get forecasts
        tsb_forecast = self.predict(steps=1)[0]
        croston_forecast = croston.predict(steps=1)[0]
        
        return {
            'tsb_forecast': tsb_forecast,
            'croston_forecast': croston_forecast,
            'difference': abs(tsb_forecast - croston_forecast),
            'tsb_probability': self.demand_probability_,
            'tsb_demand_size': self.demand_size_,
            'croston_demand_size': croston.demand_size_,
            'croston_inter_arrival': croston.inter_arrival_
        }

# Made with Bob
