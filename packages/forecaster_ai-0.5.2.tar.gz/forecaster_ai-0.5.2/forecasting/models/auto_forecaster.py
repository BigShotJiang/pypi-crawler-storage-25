"""Automatic model selection and comparison."""

import pickle
from typing import Any, Dict, List, Optional, Tuple, Callable
import logging

import numpy as np
import pandas as pd

from forecasting.core.base import BaseForecaster
from forecasting.core.config import ForecastConfig
from forecasting.core.exceptions import ModelError
from forecasting.pattern_detection import detect_pattern
from forecasting.evaluation import ForecastMetrics, cross_val_score, TimeSeriesSplit
from forecasting.data.feature_engineering import TimeSeriesFeatureEngineer

logger = logging.getLogger(__name__)


class AutoForecaster(BaseForecaster):
    """Automatic forecaster that tests multiple models and selects the best.
    
    This class automatically:
    1. Detects data patterns (trend, seasonality, intermittency)
    2. Tests multiple appropriate models
    3. Evaluates each model using cross-validation
    4. Selects the best performing model
    5. Prints comparison scores
    6. Trains the final model on all data
    
    Example:
        >>> from forecasting.models import AutoForecaster
        >>> from forecasting.core.config import ForecastConfig
        >>> 
        >>> config = ForecastConfig(horizon=30)
        >>> auto = AutoForecaster(config, verbose=True)
        >>> auto.fit(data, X=exog_features)  # Automatically tests all models
        >>> 
        >>> # Output:
        >>> # Testing 5 models...
        >>> # ARIMA: MAE=5.23, RMSE=7.45, MAPE=8.12%
        >>> # Prophet: MAE=4.89, RMSE=6.98, MAPE=7.45%
        >>> # LSTM: MAE=5.67, RMSE=8.12, MAPE=9.01%
        >>> # Ensemble: MAE=4.56, RMSE=6.45, MAPE=6.89%
        >>> # 
        >>> # ✓ Best model selected: Ensemble (MAE=4.56)
        >>> 
        >>> forecast, conf_int = auto.predict(horizon=30)
    
    Attributes:
        config: Forecast configuration
        verbose: Whether to print detailed output
        candidate_models: List of models to test
        model_scores: Scores for each tested model
        best_model: The selected best model
        best_model_name: Name of the best model
    """
    
    def __init__(
        self,
        config: ForecastConfig,
        candidate_models: Optional[List[str]] = None,
        scoring_metric: str = 'mae',
        cv_folds: int = 5,
        verbose: bool = True,
        auto_feature_engineering: bool = False,
        feature_engineer_config: Optional[Dict[str, Any]] = None
    ):
        """Initialize AutoForecaster.
        
        Args:
            config: Forecast configuration
            candidate_models: List of model names to test. If None, tests all appropriate models.
                Options: 'arima', 'prophet', 'lstm', 'croston', 'sba', 'ensemble'
            scoring_metric: Metric to use for model selection ('mae', 'rmse', 'mape', 'mase')
            cv_folds: Number of cross-validation folds
            verbose: Whether to print detailed output
            auto_feature_engineering: Whether to automatically create features
            feature_engineer_config: Configuration for TimeSeriesFeatureEngineer
        """
        super().__init__(config)
        self.candidate_models = candidate_models
        self.scoring_metric = scoring_metric
        self.cv_folds = cv_folds
        self.verbose = verbose
        self.auto_feature_engineering = auto_feature_engineering
        self.feature_engineer_config = feature_engineer_config or {}
        
        self.model_scores: Dict[str, Dict[str, float]] = {}
        self.best_model: Optional[BaseForecaster] = None
        self.best_model_name: Optional[str] = None
        self._patterns: Optional[Dict] = None
        self._feature_engineer: Optional[TimeSeriesFeatureEngineer] = None
        self._engineered_features: Optional[pd.DataFrame] = None
    
    def _get_candidate_models(
        self,
        patterns: Dict,
        has_exog: bool
    ) -> List[Tuple[str, Callable[[], BaseForecaster]]]:
        """Get list of candidate models based on data patterns.
        
        Args:
            patterns: Detected data patterns
            has_exog: Whether exogenous variables are provided
            
        Returns:
            List of (model_name, model_factory) tuples
        """
        from forecasting.models.arima import ARIMAForecaster
        from forecasting.models.prophet import ProphetForecaster
        from forecasting.models.lstm import LSTMForecaster
        from forecasting.models.intermittent.croston import CrostonForecaster
        from forecasting.models.intermittent.sba import SBAForecaster
        from forecasting.models.ensemble import EnsembleForecaster
        
        candidates = []
        
        # If user specified models, use those
        if self.candidate_models:
            model_map = {
                'arima': ('ARIMA', lambda: ARIMAForecaster(self.config)),
                'prophet': ('Prophet', lambda: ProphetForecaster(self.config)),
                'lstm': ('LSTM', lambda: LSTMForecaster(self.config)),
                'croston': ('Croston', lambda: CrostonForecaster(self.config)),
                'sba': ('SBA', lambda: SBAForecaster(self.config)),
            }
            
            for model_name in self.candidate_models:
                if model_name.lower() in model_map:
                    candidates.append(model_map[model_name.lower()])
        
        else:
            # Automatic model selection based on patterns
            intermittency = patterns.get('intermittency', {})
            zero_ratio = intermittency.get('zero_ratio', 0)
            
            # Check if intermittent
            if zero_ratio > 0.25:
                if self.verbose:
                    logger.info(f"Detected intermittent demand (zero_ratio={zero_ratio:.2f})")
                candidates.append(('Croston', lambda: CrostonForecaster(self.config)))
                candidates.append(('SBA', lambda: SBAForecaster(self.config)))
            
            # Standard forecasting models
            else:
                candidates.append(('ARIMA', lambda: ARIMAForecaster(self.config)))
                candidates.append(('Prophet', lambda: ProphetForecaster(self.config)))
                
                # LSTM if enough data
                if len(self._training_data) >= 100:
                    candidates.append(('LSTM', lambda: LSTMForecaster(self.config)))
                
                # Ensemble of top models
                if len(candidates) >= 2:
                    def create_ensemble():
                        arima = ARIMAForecaster(self.config)
                        prophet = ProphetForecaster(self.config)
                        return EnsembleForecaster(
                            self.config,
                            models=[arima, prophet],
                            aggregation='mean'
                        )
                    candidates.append(('Ensemble', create_ensemble))
        
        return candidates
    
    def _evaluate_model(
        self,
        model_name: str,
        model_factory: Callable[[], BaseForecaster],
        y: pd.Series,
        X: Optional[pd.DataFrame] = None
    ) -> Dict[str, float]:
        """Evaluate a single model using cross-validation.
        
        Args:
            model_name: Name of the model
            model_factory: Factory function to create model instances
            y: Target time series
            X: Optional exogenous variables
            
        Returns:
            Dictionary of evaluation metrics
        """
        try:
            if self.verbose:
                logger.info(f"Evaluating {model_name}...")
            
            # Cross-validation
            cv = TimeSeriesSplit(n_splits=self.cv_folds)
            
            # Calculate multiple metrics
            mae_scores = cross_val_score(
                model_factory=model_factory,
                data=y,
                X=X,
                cv=cv,
                scoring='mae',
                verbose=False
            )
            
            rmse_scores = cross_val_score(
                model_factory=model_factory,
                data=y,
                X=X,
                cv=cv,
                scoring='rmse',
                verbose=False
            )
            
            mape_scores = cross_val_score(
                model_factory=model_factory,
                data=y,
                X=X,
                cv=cv,
                scoring='mape',
                verbose=False
            )
            
            metrics = {
                'mae': mae_scores.mean(),
                'mae_std': mae_scores.std(),
                'rmse': rmse_scores.mean(),
                'rmse_std': rmse_scores.std(),
                'mape': mape_scores.mean(),
                'mape_std': mape_scores.std()
            }
            
            if self.verbose:
                logger.info(
                    f"  {model_name}: MAE={metrics['mae']:.4f} (±{metrics['mae_std']:.4f}), "
                    f"RMSE={metrics['rmse']:.4f} (±{metrics['rmse_std']:.4f}), "
                    f"MAPE={metrics['mape']:.2f}% (±{metrics['mape_std']:.2f}%)"
                )
            
            return metrics
            
        except Exception as e:
            logger.error(f"Failed to evaluate {model_name}: {str(e)}")
            return {
                'mae': np.inf,
                'mae_std': 0,
                'rmse': np.inf,
                'rmse_std': 0,
                'mape': np.inf,
                'mape_std': 0
            }
    
    def fit(
        self,
        y: pd.Series,
        X: Optional[pd.DataFrame] = None,
        **kwargs: Any
    ) -> "AutoForecaster":
        """Fit AutoForecaster by testing all models and selecting the best.
        
        This method:
        1. Detects data patterns
        2. Selects candidate models
        3. Evaluates each model using cross-validation
        4. Prints comparison scores
        5. Selects the best model
        6. Trains the best model on all data
        
        Args:
            y: Target time series
            X: Optional exogenous variables (e.g., holidays, promotions, weather)
            **kwargs: Additional arguments for model fitting
            
        Returns:
            Self for method chaining
        """
        try:
            self._validate_input(y, X)
            self._training_data = y
            
            if self.verbose:
                logger.info("="*60)
                logger.info("AutoForecaster: Automatic Model Selection")
                logger.info("="*60)
                logger.info(f"Data points: {len(y)}")
                if X is not None:
                    logger.info(f"Exogenous features: {X.shape[1]}")
                logger.info("")
            
            # Step 1: Detect patterns
            if self.verbose:
                logger.info("Step 1: Detecting data patterns...")
            
            self._patterns = detect_pattern(y)
            
            if self.verbose:
                logger.info(f"  Trend: {self._patterns.get('trend', {}).get('has_trend', False)}")
                logger.info(f"  Seasonality: {self._patterns.get('seasonality', {}).get('has_seasonality', False)}")
                logger.info(f"  Intermittency: {self._patterns.get('intermittency', {}).get('pattern', 'regular')}")
                logger.info("")
            
            # Step 2: Get candidate models
            if self.verbose:
                logger.info("Step 2: Selecting candidate models...")
            
            candidates = self._get_candidate_models(self._patterns, X is not None)
            
            if self.verbose:
                logger.info(f"  Testing {len(candidates)} models: {[name for name, _ in candidates]}")
                logger.info("")
            
            # Step 3: Evaluate all models
            if self.verbose:
                logger.info("Step 3: Evaluating models (this may take a few minutes)...")
                logger.info("")
            
            for model_name, model_factory in candidates:
                metrics = self._evaluate_model(model_name, model_factory, y, X)
                self.model_scores[model_name] = metrics
            
            # Step 4: Select best model
            if self.verbose:
                logger.info("")
                logger.info("="*60)
                logger.info("MODEL COMPARISON")
                logger.info("="*60)
            
            # Sort by scoring metric
            sorted_models = sorted(
                self.model_scores.items(),
                key=lambda x: x[1][self.scoring_metric]
            )
            
            if self.verbose:
                for model_name, metrics in sorted_models:
                    logger.info(
                        f"{model_name:15s}: MAE={metrics['mae']:7.4f}, "
                        f"RMSE={metrics['rmse']:7.4f}, "
                        f"MAPE={metrics['mape']:6.2f}%"
                    )
                logger.info("="*60)
            
            # Select best model
            self.best_model_name = sorted_models[0][0]
            best_metrics = sorted_models[0][1]
            
            if self.verbose:
                logger.info("")
                logger.info(f"✓ Best model selected: {self.best_model_name}")
                logger.info(f"  {self.scoring_metric.upper()}={best_metrics[self.scoring_metric]:.4f}")
                logger.info("")
            
            # Step 5: Train best model on all data
            if self.verbose:
                logger.info("Step 4: Training final model on all data...")
            
            # Find the model factory for the best model
            best_model_factory = None
            for model_name, model_factory in candidates:
                if model_name == self.best_model_name:
                    best_model_factory = model_factory
                    break
            
            if best_model_factory is None:
                raise ModelError(f"Could not find factory for best model: {self.best_model_name}")
            
            # Create and train final model
            self.best_model = best_model_factory()
            self.best_model.fit(y, X, **kwargs)
            
            self.is_fitted = True
            
            if self.verbose:
                logger.info("✓ Training complete!")
                logger.info("="*60)
                logger.info("")
            
            return self
            
        except Exception as e:
            raise ModelError(f"Failed to fit AutoForecaster: {str(e)}")
    
    def predict(
        self,
        horizon: Optional[int] = None,
        X: Optional[pd.DataFrame] = None,
        return_conf_int: bool = True,
        **kwargs: Any
    ) -> Tuple[pd.Series, Optional[pd.DataFrame]]:
        """Generate forecast using the best selected model.
        
        Args:
            horizon: Number of periods to forecast
            X: Optional exogenous variables for forecast period
            return_conf_int: Whether to return confidence intervals
            **kwargs: Additional prediction arguments
            
        Returns:
            Tuple of (predictions, confidence_intervals)
        """
        self._check_is_fitted()
        
        if self.best_model is None:
            raise ModelError("No model has been trained")
        
        return self.best_model.predict(
            horizon=horizon,
            X=X,
            return_conf_int=return_conf_int,
            **kwargs
        )
    
    def get_model_comparison(self) -> pd.DataFrame:
        """Get comparison of all tested models.
        
        Returns:
            DataFrame with model scores sorted by performance
        """
        if not self.model_scores:
            raise ModelError("No models have been evaluated yet")
        
        df = pd.DataFrame(self.model_scores).T
        df = df.sort_values(by=self.scoring_metric)
        df['selected'] = df.index == self.best_model_name
        
        return df
    
    def save_model(self, path: str) -> None:
        """Save AutoForecaster to disk.
        
        Args:
            path: Path to save the model
        """
        if not self.is_fitted:
            raise ModelError("Cannot save unfitted model")
        
        try:
            model_data = {
                "best_model": self.best_model,
                "best_model_name": self.best_model_name,
                "model_scores": self.model_scores,
                "patterns": self._patterns,
                "config": self.config,
                "scoring_metric": self.scoring_metric,
            }
            
            with open(path, "wb") as f:
                pickle.dump(model_data, f)
                
        except Exception as e:
            raise ModelError(f"Failed to save model: {str(e)}")
    
    @classmethod
    def load_model(cls, path: str) -> "AutoForecaster":
        """Load AutoForecaster from disk.
        
        Args:
            path: Path to load the model from
            
        Returns:
            Loaded AutoForecaster instance
        """
        try:
            with open(path, "rb") as f:
                model_data = pickle.load(f)
            
            # Create instance
            forecaster = cls(
                config=model_data["config"],
                scoring_metric=model_data["scoring_metric"],
            )
            
            # Restore state
            forecaster.best_model = model_data["best_model"]
            forecaster.best_model_name = model_data["best_model_name"]
            forecaster.model_scores = model_data["model_scores"]
            forecaster._patterns = model_data["patterns"]
            forecaster.is_fitted = True
            
            return forecaster
            
        except Exception as e:
            raise ModelError(f"Failed to load model: {str(e)}")


# Made with Bob