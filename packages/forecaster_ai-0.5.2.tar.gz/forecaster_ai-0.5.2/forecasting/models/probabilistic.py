"""Probabilistic forecasting models."""

from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from scipy import stats

from forecasting.core.base import BaseForecaster
from forecasting.core.config import ForecastConfig
from forecasting.core.exceptions import ModelError


class ProbabilisticForecaster(BaseForecaster):
    """Probabilistic forecasting with quantile predictions.
    
    Provides quantile forecasts and prediction intervals beyond simple
    confidence intervals. Useful for risk assessment and decision-making
    under uncertainty.
    
    Features:
    - Multiple quantile predictions
    - Prediction intervals at any confidence level
    - Monte Carlo simulation for uncertainty quantification
    - Compatible with any base forecaster
    
    Examples
    --------
    >>> from forecasting.models.probabilistic import ProbabilisticForecaster
    >>> from forecasting.models import ARIMAForecaster
    >>> 
    >>> # Create probabilistic forecaster
    >>> base_model = ARIMAForecaster(config)
    >>> prob_model = ProbabilisticForecaster(config, base_model=base_model)
    >>> 
    >>> # Fit and predict quantiles
    >>> prob_model.fit(train_data)
    >>> quantiles = prob_model.predict_quantiles(
    ...     horizon=30,
    ...     quantiles=[0.1, 0.5, 0.9]
    ... )
    """
    
    def __init__(
        self,
        config: ForecastConfig,
        base_model: Optional[BaseForecaster] = None,
        n_simulations: int = 1000,
    ):
        """Initialize probabilistic forecaster.
        
        Args:
            config: Forecast configuration
            base_model: Base forecaster to use (ARIMA if None)
            n_simulations: Number of Monte Carlo simulations
        """
        super().__init__(config)
        self.base_model = base_model
        self.n_simulations = n_simulations
        self._residuals: Optional[np.ndarray] = None
    
    def fit(
        self,
        y: pd.Series,
        X: Optional[pd.DataFrame] = None,
        **kwargs: Any
    ) -> "ProbabilisticForecaster":
        """Fit probabilistic forecaster.
        
        Args:
            y: Target time series
            X: Optional exogenous variables
            **kwargs: Additional arguments
            
        Returns:
            Self for method chaining
        """
        try:
            self._validate_input(y, X)
            
            # Initialize base model if not provided
            if self.base_model is None:
                from forecasting.models import ARIMAForecaster
                self.base_model = ARIMAForecaster(self.config)
            
            # Fit base model
            self.base_model.fit(y, X, **kwargs)
            
            # Calculate residuals for simulation
            fitted_values = self.base_model.predict(horizon=len(y))[0]
            self._residuals = (y - fitted_values).dropna().values
            
            self.is_fitted = True
            return self
            
        except Exception as e:
            raise ModelError(f"Failed to fit probabilistic forecaster: {str(e)}")
    
    def predict(
        self,
        horizon: Optional[int] = None,
        X: Optional[pd.DataFrame] = None,
        return_conf_int: bool = True,
        **kwargs: Any
    ) -> Tuple[pd.Series, Optional[pd.DataFrame]]:
        """Generate point forecast with confidence intervals.
        
        Args:
            horizon: Number of periods to forecast
            X: Optional exogenous variables
            return_conf_int: Whether to return confidence intervals
            **kwargs: Additional arguments
            
        Returns:
            Tuple of (predictions, confidence_intervals)
        """
        self._check_is_fitted()
        
        # Get base forecast
        forecast, conf_int = self.base_model.predict(
            horizon=horizon,
            X=X,
            return_conf_int=return_conf_int,
            **kwargs
        )
        
        # Store for plotting
        self._store_forecast(forecast, conf_int)
        
        return forecast, conf_int
    
    def predict_quantiles(
        self,
        horizon: Optional[int] = None,
        quantiles: Optional[List[float]] = None,
        X: Optional[pd.DataFrame] = None,
        **kwargs: Any
    ) -> pd.DataFrame:
        """Predict multiple quantiles.
        
        Args:
            horizon: Number of periods to forecast
            quantiles: List of quantiles to predict (e.g., [0.1, 0.5, 0.9])
            X: Optional exogenous variables
            **kwargs: Additional arguments
            
        Returns:
            DataFrame with quantile predictions
            
        Examples
        --------
        >>> quantiles = model.predict_quantiles(
        ...     horizon=30,
        ...     quantiles=[0.1, 0.25, 0.5, 0.75, 0.9]
        ... )
        >>> print(quantiles.columns)
        Index(['q_0.1', 'q_0.25', 'q_0.5', 'q_0.75', 'q_0.9'])
        """
        self._check_is_fitted()
        
        if quantiles is None:
            quantiles = [0.1, 0.25, 0.5, 0.75, 0.9]
        
        if horizon is None:
            horizon = self.config.horizon
        
        # Get point forecast
        forecast, _ = self.base_model.predict(horizon=horizon, X=X, **kwargs)
        
        # Run Monte Carlo simulations
        simulations = self._monte_carlo_simulate(forecast, horizon)
        
        # Calculate quantiles
        quantile_forecasts = pd.DataFrame(index=forecast.index)
        for q in quantiles:
            quantile_forecasts[f'q_{q}'] = np.quantile(simulations, q, axis=0)
        
        return quantile_forecasts
    
    def _monte_carlo_simulate(
        self,
        forecast: pd.Series,
        horizon: int
    ) -> np.ndarray:
        """Run Monte Carlo simulations.
        
        Args:
            forecast: Point forecast
            horizon: Forecast horizon
            
        Returns:
            Array of simulations (n_simulations x horizon)
        """
        if self._residuals is None or len(self._residuals) == 0:
            # Use normal distribution if no residuals
            std = forecast.std()
            simulations = np.random.normal(
                loc=forecast.values,
                scale=std,
                size=(self.n_simulations, horizon)
            )
        else:
            # Bootstrap residuals
            simulations = np.zeros((self.n_simulations, horizon))
            for i in range(self.n_simulations):
                # Sample residuals with replacement
                sampled_residuals = np.random.choice(
                    self._residuals,
                    size=horizon,
                    replace=True
                )
                simulations[i] = forecast.values + sampled_residuals
        
        return simulations
    
    def predict_intervals(
        self,
        horizon: Optional[int] = None,
        confidence_levels: Optional[List[float]] = None,
        X: Optional[pd.DataFrame] = None,
        **kwargs: Any
    ) -> Dict[float, pd.DataFrame]:
        """Predict intervals at multiple confidence levels.
        
        Args:
            horizon: Number of periods to forecast
            confidence_levels: List of confidence levels (e.g., [0.80, 0.95, 0.99])
            X: Optional exogenous variables
            **kwargs: Additional arguments
            
        Returns:
            Dictionary mapping confidence levels to DataFrames with 'lower' and 'upper'
            
        Examples
        --------
        >>> intervals = model.predict_intervals(
        ...     horizon=30,
        ...     confidence_levels=[0.80, 0.95, 0.99]
        ... )
        >>> print(intervals[0.95].columns)
        Index(['lower', 'upper'])
        """
        self._check_is_fitted()
        
        if confidence_levels is None:
            confidence_levels = [0.80, 0.95, 0.99]
        
        if horizon is None:
            horizon = self.config.horizon
        
        # Get point forecast
        forecast, _ = self.base_model.predict(horizon=horizon, X=X, **kwargs)
        
        # Run Monte Carlo simulations
        simulations = self._monte_carlo_simulate(forecast, horizon)
        
        # Calculate intervals
        intervals = {}
        for conf_level in confidence_levels:
            alpha = 1 - conf_level
            lower_q = alpha / 2
            upper_q = 1 - alpha / 2
            
            intervals[conf_level] = pd.DataFrame({
                'lower': np.quantile(simulations, lower_q, axis=0),
                'upper': np.quantile(simulations, upper_q, axis=0)
            }, index=forecast.index)
        
        return intervals


# Made with Bob