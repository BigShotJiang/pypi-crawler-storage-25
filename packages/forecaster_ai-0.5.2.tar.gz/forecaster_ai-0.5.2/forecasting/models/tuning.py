"""Hyperparameter tuning for forecasting models."""

from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from forecasting.core.base import BaseForecaster
from forecasting.core.config import ForecastConfig
from forecasting.core.exceptions import ModelError


class HyperparameterTuner:
    """Hyperparameter tuner using Optuna.
    
    Performs automated hyperparameter optimization for forecasting models
    using Bayesian optimization via Optuna.
    
    Attributes:
        model_class: Forecaster class to tune
        config: Base forecast configuration
        param_space: Parameter search space
        n_trials: Number of optimization trials
        metric: Optimization metric
    """
    
    def __init__(
        self,
        model_class: type,
        config: ForecastConfig,
        param_space: Dict[str, Any],
        n_trials: int = 50,
        metric: str = "rmse",
        direction: str = "minimize",
        timeout: Optional[int] = None,
        n_jobs: int = 1,
    ):
        """Initialize hyperparameter tuner.
        
        Args:
            model_class: Forecaster class to tune
            config: Base forecast configuration
            param_space: Parameter search space definition
            n_trials: Number of optimization trials
            metric: Metric to optimize ('rmse', 'mae', 'mape')
            direction: Optimization direction ('minimize' or 'maximize')
            timeout: Timeout in seconds
            n_jobs: Number of parallel jobs
        """
        self.model_class = model_class
        self.config = config
        self.param_space = param_space
        self.n_trials = n_trials
        self.metric = metric
        self.direction = direction
        self.timeout = timeout
        self.n_jobs = n_jobs
        
        self.best_params: Optional[Dict[str, Any]] = None
        self.best_score: Optional[float] = None
        self.study: Optional[Any] = None
    
    def tune(
        self,
        y: pd.Series,
        X: Optional[pd.DataFrame] = None,
        validation_split: float = 0.2,
        **kwargs: Any
    ) -> Dict[str, Any]:
        """Perform hyperparameter tuning.
        
        Args:
            y: Target time series
            X: Optional exogenous variables
            validation_split: Fraction of data for validation
            **kwargs: Additional arguments for model fitting
            
        Returns:
            Dictionary with best parameters and score
        """
        try:
            import optuna
            
            # Split data
            split_idx = int(len(y) * (1 - validation_split))
            y_train, y_val = y.iloc[:split_idx], y.iloc[split_idx:]
            
            if X is not None:
                X_train, X_val = X.iloc[:split_idx], X.iloc[split_idx:]
            else:
                X_train, X_val = None, None
            
            # Define objective function
            def objective(trial: Any) -> float:
                # Sample parameters
                params = {}
                for param_name, param_config in self.param_space.items():
                    if param_config["type"] == "int":
                        params[param_name] = trial.suggest_int(
                            param_name,
                            param_config["low"],
                            param_config["high"]
                        )
                    elif param_config["type"] == "float":
                        params[param_name] = trial.suggest_float(
                            param_name,
                            param_config["low"],
                            param_config["high"],
                            log=param_config.get("log", False)
                        )
                    elif param_config["type"] == "categorical":
                        params[param_name] = trial.suggest_categorical(
                            param_name,
                            param_config["choices"]
                        )
                
                # Create and fit model
                try:
                    model = self.model_class(self.config, **params)
                    model.fit(y_train, X_train, **kwargs)
                    
                    # Generate predictions
                    predictions, _ = model.predict(
                        horizon=len(y_val),
                        X=X_val,
                        return_conf_int=False
                    )
                    
                    # Calculate metric
                    if self.metric == "rmse":
                        score = np.sqrt(np.mean((y_val.values - predictions.values) ** 2))
                    elif self.metric == "mae":
                        score = np.mean(np.abs(y_val.values - predictions.values))
                    elif self.metric == "mape":
                        score = np.mean(
                            np.abs((y_val.values - predictions.values) / y_val.values)
                        ) * 100
                    else:
                        raise ValueError(f"Unknown metric: {self.metric}")
                    
                    return score
                    
                except Exception as e:
                    # Return worst possible score on error
                    return float("inf") if self.direction == "minimize" else float("-inf")
            
            # Create and run study
            self.study = optuna.create_study(direction=self.direction)
            self.study.optimize(
                objective,
                n_trials=self.n_trials,
                timeout=self.timeout,
                n_jobs=self.n_jobs,
                show_progress_bar=True,
            )
            
            # Store best results
            self.best_params = self.study.best_params
            self.best_score = self.study.best_value
            
            return {
                "best_params": self.best_params,
                "best_score": self.best_score,
                "n_trials": len(self.study.trials),
            }
            
        except ImportError:
            raise ModelError(
                "optuna package required for hyperparameter tuning. "
                "Install with: pip install optuna"
            )
        except Exception as e:
            raise ModelError(f"Failed to tune hyperparameters: {str(e)}")
    
    def get_best_model(self) -> BaseForecaster:
        """Get model with best parameters.
        
        Returns:
            Forecaster instance with best parameters
        """
        if self.best_params is None:
            raise ModelError("Must run tune() before getting best model")
        
        return self.model_class(self.config, **self.best_params)
    
    def plot_optimization_history(self) -> Any:
        """Plot optimization history.
        
        Returns:
            Plotly figure
        """
        if self.study is None:
            raise ModelError("Must run tune() before plotting")
        
        try:
            import optuna.visualization as vis
            return vis.plot_optimization_history(self.study)
        except ImportError:
            raise ModelError("plotly required for visualization")
    
    def plot_param_importances(self) -> Any:
        """Plot parameter importances.
        
        Returns:
            Plotly figure
        """
        if self.study is None:
            raise ModelError("Must run tune() before plotting")
        
        try:
            import optuna.visualization as vis
            return vis.plot_param_importances(self.study)
        except ImportError:
            raise ModelError("plotly required for visualization")


class AutoML:
    """Automated machine learning for time series forecasting.
    
    Automatically selects and tunes the best forecasting model
    from a set of candidates.
    """
    
    def __init__(
        self,
        config: ForecastConfig,
        model_classes: Optional[List[type]] = None,
        param_spaces: Optional[Dict[str, Dict[str, Any]]] = None,
        n_trials_per_model: int = 20,
        metric: str = "rmse",
        validation_split: float = 0.2,
    ):
        """Initialize AutoML.
        
        Args:
            config: Base forecast configuration
            model_classes: List of forecaster classes to try
            param_spaces: Parameter spaces for each model
            n_trials_per_model: Number of trials per model
            metric: Optimization metric
            validation_split: Validation split ratio
        """
        self.config = config
        self.model_classes = model_classes or []
        self.param_spaces = param_spaces or {}
        self.n_trials_per_model = n_trials_per_model
        self.metric = metric
        self.validation_split = validation_split
        
        self.best_model_class: Optional[type] = None
        self.best_params: Optional[Dict[str, Any]] = None
        self.best_score: Optional[float] = None
        self.results: List[Dict[str, Any]] = []
    
    def fit(
        self,
        y: pd.Series,
        X: Optional[pd.DataFrame] = None,
        **kwargs: Any
    ) -> "AutoML":
        """Fit AutoML to find best model.
        
        Args:
            y: Target time series
            X: Optional exogenous variables
            **kwargs: Additional fitting arguments
            
        Returns:
            Self for method chaining
        """
        try:
            if not self.model_classes:
                raise ModelError("No model classes provided")
            
            best_overall_score = float("inf")
            
            # Try each model class
            for model_class in self.model_classes:
                model_name = model_class.__name__
                
                # Get parameter space for this model
                param_space = self.param_spaces.get(model_name, {})
                
                if not param_space:
                    # Use default parameters
                    try:
                        model = model_class(self.config)
                        
                        # Split data
                        split_idx = int(len(y) * (1 - self.validation_split))
                        y_train, y_val = y.iloc[:split_idx], y.iloc[split_idx:]
                        
                        if X is not None:
                            X_train, X_val = X.iloc[:split_idx], X.iloc[split_idx:]
                        else:
                            X_train, X_val = None, None
                        
                        # Fit and evaluate
                        model.fit(y_train, X_train, **kwargs)
                        predictions, _ = model.predict(
                            horizon=len(y_val),
                            X=X_val,
                            return_conf_int=False
                        )
                        
                        # Calculate score
                        if self.metric == "rmse":
                            score = np.sqrt(
                                np.mean((y_val.values - predictions.values) ** 2)
                            )
                        elif self.metric == "mae":
                            score = np.mean(np.abs(y_val.values - predictions.values))
                        elif self.metric == "mape":
                            score = np.mean(
                                np.abs((y_val.values - predictions.values) / y_val.values)
                            ) * 100
                        
                        self.results.append({
                            "model": model_name,
                            "params": {},
                            "score": score,
                        })
                        
                        if score < best_overall_score:
                            best_overall_score = score
                            self.best_model_class = model_class
                            self.best_params = {}
                            self.best_score = score
                            
                    except Exception as e:
                        print(f"Failed to fit {model_name} with default params: {e}")
                        continue
                else:
                    # Tune hyperparameters
                    try:
                        tuner = HyperparameterTuner(
                            model_class=model_class,
                            config=self.config,
                            param_space=param_space,
                            n_trials=self.n_trials_per_model,
                            metric=self.metric,
                        )
                        
                        result = tuner.tune(
                            y=y,
                            X=X,
                            validation_split=self.validation_split,
                            **kwargs
                        )
                        
                        self.results.append({
                            "model": model_name,
                            "params": result["best_params"],
                            "score": result["best_score"],
                        })
                        
                        if result["best_score"] < best_overall_score:
                            best_overall_score = result["best_score"]
                            self.best_model_class = model_class
                            self.best_params = result["best_params"]
                            self.best_score = result["best_score"]
                            
                    except Exception as e:
                        print(f"Failed to tune {model_name}: {e}")
                        continue
            
            if self.best_model_class is None:
                raise ModelError("No models succeeded")
            
            return self
            
        except Exception as e:
            raise ModelError(f"AutoML failed: {str(e)}")
    
    def get_best_model(self) -> BaseForecaster:
        """Get the best model found by AutoML.
        
        Returns:
            Best forecaster instance
        """
        if self.best_model_class is None:
            raise ModelError("Must run fit() before getting best model")
        
        return self.best_model_class(self.config, **self.best_params)
    
    def get_leaderboard(self) -> pd.DataFrame:
        """Get leaderboard of all models tried.
        
        Returns:
            DataFrame with model results sorted by score
        """
        if not self.results:
            raise ModelError("Must run fit() before getting leaderboard")
        
        df = pd.DataFrame(self.results)
        return df.sort_values("score")


# Made with Bob
