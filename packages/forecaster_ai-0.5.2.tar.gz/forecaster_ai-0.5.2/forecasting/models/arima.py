"""ARIMA-based forecasting models."""

import pickle
from typing import Any, Dict, Optional, Tuple

import numpy as np
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.statespace.sarimax import SARIMAX
from statsmodels.tsa.stattools import adfuller

from forecasting.core.base import BaseForecaster
from forecasting.core.config import ForecastConfig
from forecasting.core.exceptions import ModelError
from forecasting.utils.helpers import create_date_range, get_frequency


class ARIMAForecaster(BaseForecaster):
    """ARIMA (AutoRegressive Integrated Moving Average) forecaster.
    
    Implements ARIMA model for univariate time series forecasting.
    Supports both manual parameter specification and automatic selection.
    
    Attributes:
        order: ARIMA order (p, d, q)
        seasonal_order: Seasonal ARIMA order (P, D, Q, s)
        trend: Trend component ('n', 'c', 't', 'ct')
    """
    
    def __init__(
        self,
        config: ForecastConfig,
        order: Tuple[int, int, int] = (1, 1, 1),
        seasonal_order: Tuple[int, int, int, int] = (0, 0, 0, 0),
        trend: str = "c",
    ):
        """Initialize ARIMA forecaster.
        
        Args:
            config: Forecast configuration
            order: ARIMA order (p, d, q)
            seasonal_order: Seasonal order (P, D, Q, s)
            trend: Trend component
        """
        super().__init__(config)
        self.order = order
        self.seasonal_order = seasonal_order
        self.trend = trend
        self._freq: Optional[str] = None
    
    def fit(
        self,
        y: pd.Series,
        X: Optional[pd.DataFrame] = None,
        **kwargs: Any
    ) -> "ARIMAForecaster":
        """Fit ARIMA model.
        
        Args:
            y: Target time series
            X: Optional exogenous variables (for ARIMAX)
            **kwargs: Additional arguments for ARIMA fitting
            
        Returns:
            Self for method chaining
        """
        try:
            self._validate_input(y, X)
            
            # Store frequency
            if isinstance(y.index, pd.DatetimeIndex):
                self._freq = get_frequency(y)
            
            # Fit ARIMA/SARIMAX model
            if X is not None:
                # ARIMAX with exogenous variables
                self.model = SARIMAX(
                    y,
                    exog=X,
                    order=self.order,
                    seasonal_order=self.seasonal_order,
                    trend=self.trend,
                    enforce_stationarity=False,
                    enforce_invertibility=False,
                )
            else:
                # Standard ARIMA
                self.model = ARIMA(
                    y,
                    order=self.order,
                    trend=self.trend,
                    enforce_stationarity=False,
                    enforce_invertibility=False,
                )
            
            # Fit the model
            self.model = self.model.fit(**kwargs)
            self.is_fitted = True
            
            # Store validation metrics
            self._validation_metrics = {
                "aic": float(self.model.aic),
                "bic": float(self.model.bic),
                "hqic": float(self.model.hqic),
            }
            
            return self
            
        except Exception as e:
            raise ModelError(f"Failed to fit ARIMA model: {str(e)}")
    
    def predict(
        self,
        horizon: Optional[int] = None,
        X: Optional[pd.DataFrame] = None,
        return_conf_int: bool = True,
        alpha: float = 0.05,
        **kwargs: Any
    ) -> Tuple[pd.Series, Optional[pd.DataFrame]]:
        """Generate ARIMA forecasts.
        
        Args:
            horizon: Number of periods to forecast
            X: Optional exogenous variables for forecast period
            return_conf_int: Whether to return confidence intervals
            alpha: Significance level for confidence intervals
            **kwargs: Additional prediction arguments
            
        Returns:
            Tuple of (predictions, confidence_intervals)
        """
        self._check_is_fitted()
        
        try:
            if horizon is None:
                horizon = self.config.horizon
            
            # Generate forecast
            if X is not None:
                forecast = self.model.forecast(steps=horizon, exog=X, **kwargs)
            else:
                forecast = self.model.forecast(steps=horizon, **kwargs)
            
            # Create forecast index
            if self._freq is not None:
                last_date = self.model.data.dates[-1]
                forecast_index = create_date_range(
                    start=last_date + pd.Timedelta(1, unit=self._freq),
                    periods=horizon,
                    freq=self._freq
                )
                forecast = pd.Series(forecast, index=forecast_index)
            
            # Get confidence intervals if requested
            conf_int = None
            if return_conf_int:
                forecast_result = self.model.get_forecast(
                    steps=horizon,
                    exog=X if X is not None else None
                )
                conf_int_array = forecast_result.conf_int(alpha=alpha)
                
                if self._freq is not None:
                    conf_int = pd.DataFrame(
                        conf_int_array,
                        index=forecast_index,
                        columns=["lower", "upper"]
                    )
                else:
                    conf_int = pd.DataFrame(
                        conf_int_array,
                        columns=["lower", "upper"]
                    )
            
            return forecast, conf_int
            
        except Exception as e:
            raise ModelError(f"Failed to generate ARIMA forecast: {str(e)}")
    
    def save_model(self, path: str) -> None:
        """Save ARIMA model to disk.
        
        Args:
            path: Path to save the model
        """
        if not self.is_fitted:
            raise ModelError("Cannot save unfitted model")
        
        try:
            model_data = {
                "model": self.model,
                "config": self.config,
                "order": self.order,
                "seasonal_order": self.seasonal_order,
                "trend": self.trend,
                "freq": self._freq,
                "validation_metrics": self._validation_metrics,
            }
            
            with open(path, "wb") as f:
                pickle.dump(model_data, f)
                
        except Exception as e:
            raise ModelError(f"Failed to save model: {str(e)}")
    
    @classmethod
    def load_model(cls, path: str) -> "ARIMAForecaster":
        """Load ARIMA model from disk.
        
        Args:
            path: Path to load the model from
            
        Returns:
            Loaded ARIMAForecaster instance
        """
        try:
            with open(path, "rb") as f:
                model_data = pickle.load(f)
            
            forecaster = cls(
                config=model_data["config"],
                order=model_data["order"],
                seasonal_order=model_data["seasonal_order"],
                trend=model_data["trend"],
            )
            
            forecaster.model = model_data["model"]
            forecaster._freq = model_data["freq"]
            forecaster._validation_metrics = model_data["validation_metrics"]
            forecaster.is_fitted = True
            
            return forecaster
            
        except Exception as e:
            raise ModelError(f"Failed to load model: {str(e)}")


class AutoARIMAForecaster(BaseForecaster):
    """Automatic ARIMA model selection using pmdarima.
    
    Automatically selects optimal ARIMA parameters using information criteria.
    Supports seasonal models and exogenous variables.
    """
    
    def __init__(
        self,
        config: ForecastConfig,
        seasonal: bool = True,
        m: int = 12,
        max_p: int = 5,
        max_q: int = 5,
        max_d: int = 2,
        max_P: int = 2,
        max_Q: int = 2,
        max_D: int = 1,
        information_criterion: str = "aic",
        stepwise: bool = True,
        suppress_warnings: bool = True,
    ):
        """Initialize Auto-ARIMA forecaster.
        
        Args:
            config: Forecast configuration
            seasonal: Whether to fit seasonal ARIMA
            m: Seasonal period
            max_p: Maximum AR order
            max_q: Maximum MA order
            max_d: Maximum differencing order
            max_P: Maximum seasonal AR order
            max_Q: Maximum seasonal MA order
            max_D: Maximum seasonal differencing order
            information_criterion: IC to use ('aic', 'bic', 'hqic')
            stepwise: Whether to use stepwise search
            suppress_warnings: Whether to suppress warnings
        """
        super().__init__(config)
        self.seasonal = seasonal
        self.m = m
        self.max_p = max_p
        self.max_q = max_q
        self.max_d = max_d
        self.max_P = max_P
        self.max_Q = max_Q
        self.max_D = max_D
        self.information_criterion = information_criterion
        self.stepwise = stepwise
        self.suppress_warnings = suppress_warnings
        self._freq: Optional[str] = None
        self._selected_order: Optional[Tuple] = None
    
    def fit(
        self,
        y: pd.Series,
        X: Optional[pd.DataFrame] = None,
        **kwargs: Any
    ) -> "AutoARIMAForecaster":
        """Fit Auto-ARIMA model with automatic parameter selection.
        
        Args:
            y: Target time series
            X: Optional exogenous variables
            **kwargs: Additional arguments for auto_arima
            
        Returns:
            Self for method chaining
        """
        try:
            from pmdarima import auto_arima
            
            self._validate_input(y, X)
            
            # Store frequency
            if isinstance(y.index, pd.DatetimeIndex):
                self._freq = get_frequency(y)
            
            # Fit auto ARIMA
            self.model = auto_arima(
                y,
                X=X,
                seasonal=self.seasonal,
                m=self.m,
                max_p=self.max_p,
                max_q=self.max_q,
                max_d=self.max_d,
                max_P=self.max_P,
                max_Q=self.max_Q,
                max_D=self.max_D,
                information_criterion=self.information_criterion,
                stepwise=self.stepwise,
                suppress_warnings=self.suppress_warnings,
                error_action="ignore",
                **kwargs
            )
            
            self.is_fitted = True
            self._selected_order = self.model.order
            
            # Store validation metrics
            self._validation_metrics = {
                "aic": float(self.model.aic()),
                "bic": float(self.model.bic()),
                "order": str(self.model.order),
                "seasonal_order": str(self.model.seasonal_order),
            }
            
            return self
            
        except ImportError:
            raise ModelError(
                "pmdarima package required for AutoARIMA. "
                "Install with: pip install pmdarima"
            )
        except Exception as e:
            raise ModelError(f"Failed to fit Auto-ARIMA model: {str(e)}")
    
    def predict(
        self,
        horizon: Optional[int] = None,
        X: Optional[pd.DataFrame] = None,
        return_conf_int: bool = True,
        alpha: float = 0.05,
        **kwargs: Any
    ) -> Tuple[pd.Series, Optional[pd.DataFrame]]:
        """Generate Auto-ARIMA forecasts.
        
        Args:
            horizon: Number of periods to forecast
            X: Optional exogenous variables for forecast period
            return_conf_int: Whether to return confidence intervals
            alpha: Significance level for confidence intervals
            **kwargs: Additional prediction arguments
            
        Returns:
            Tuple of (predictions, confidence_intervals)
        """
        self._check_is_fitted()
        
        try:
            if horizon is None:
                horizon = self.config.horizon
            
            # Generate forecast
            if return_conf_int:
                forecast, conf_int = self.model.predict(
                    n_periods=horizon,
                    X=X,
                    return_conf_int=True,
                    alpha=alpha,
                    **kwargs
                )
                
                # Create proper index
                if self._freq is not None:
                    last_date = self.model.arima_res_.data.dates[-1]
                    forecast_index = create_date_range(
                        start=last_date + pd.Timedelta(1, unit=self._freq),
                        periods=horizon,
                        freq=self._freq
                    )
                    forecast = pd.Series(forecast, index=forecast_index)
                    conf_int = pd.DataFrame(
                        conf_int,
                        index=forecast_index,
                        columns=["lower", "upper"]
                    )
                else:
                    forecast = pd.Series(forecast)
                    conf_int = pd.DataFrame(conf_int, columns=["lower", "upper"])
                
                return forecast, conf_int
            else:
                forecast = self.model.predict(
                    n_periods=horizon,
                    X=X,
                    return_conf_int=False,
                    **kwargs
                )
                
                if self._freq is not None:
                    last_date = self.model.arima_res_.data.dates[-1]
                    forecast_index = create_date_range(
                        start=last_date + pd.Timedelta(1, unit=self._freq),
                        periods=horizon,
                        freq=self._freq
                    )
                    forecast = pd.Series(forecast, index=forecast_index)
                else:
                    forecast = pd.Series(forecast)
                
                return forecast, None
                
        except Exception as e:
            raise ModelError(f"Failed to generate Auto-ARIMA forecast: {str(e)}")
    
    def save_model(self, path: str) -> None:
        """Save Auto-ARIMA model to disk.
        
        Args:
            path: Path to save the model
        """
        if not self.is_fitted:
            raise ModelError("Cannot save unfitted model")
        
        try:
            model_data = {
                "model": self.model,
                "config": self.config,
                "seasonal": self.seasonal,
                "m": self.m,
                "freq": self._freq,
                "selected_order": self._selected_order,
                "validation_metrics": self._validation_metrics,
            }
            
            with open(path, "wb") as f:
                pickle.dump(model_data, f)
                
        except Exception as e:
            raise ModelError(f"Failed to save model: {str(e)}")
    
    @classmethod
    def load_model(cls, path: str) -> "AutoARIMAForecaster":
        """Load Auto-ARIMA model from disk.
        
        Args:
            path: Path to load the model from
            
        Returns:
            Loaded AutoARIMAForecaster instance
        """
        try:
            with open(path, "rb") as f:
                model_data = pickle.load(f)
            
            forecaster = cls(
                config=model_data["config"],
                seasonal=model_data["seasonal"],
                m=model_data["m"],
            )
            
            forecaster.model = model_data["model"]
            forecaster._freq = model_data["freq"]
            forecaster._selected_order = model_data["selected_order"]
            forecaster._validation_metrics = model_data["validation_metrics"]
            forecaster.is_fitted = True
            
            return forecaster
            
        except Exception as e:
            raise ModelError(f"Failed to load model: {str(e)}")


def check_stationarity(data: pd.Series, alpha: float = 0.05) -> Dict[str, Any]:
    """Check if time series is stationary using ADF test.
    
    Args:
        data: Time series to test
        alpha: Significance level
        
    Returns:
        Dictionary with test results
    """
    result = adfuller(data.dropna(), autolag="AIC")
    
    return {
        "adf_statistic": float(result[0]),
        "pvalue": float(result[1]),
        "used_lag": int(result[2]),
        "n_obs": int(result[3]),
        "critical_values": {k: float(v) for k, v in result[4].items()},
        "is_stationary": result[1] < alpha,
    }


def suggest_differencing_order(data: pd.Series, max_d: int = 2) -> int:
    """Suggest differencing order to achieve stationarity.
    
    Args:
        data: Time series data
        max_d: Maximum differencing order to try
        
    Returns:
        Suggested differencing order
    """
    current_data = data.copy()
    
    for d in range(max_d + 1):
        result = check_stationarity(current_data)
        if result["is_stationary"]:
            return d
        current_data = current_data.diff().dropna()
    
    return max_d


# Made with Bob
