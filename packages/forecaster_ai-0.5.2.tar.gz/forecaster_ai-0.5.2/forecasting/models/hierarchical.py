"""Hierarchical forecasting with reconciliation."""

from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from forecasting.core.base import BaseForecaster
from forecasting.core.config import ForecastConfig
from forecasting.core.exceptions import ModelError


class HierarchicalForecaster:
    """Hierarchical forecasting with top-down/bottom-up reconciliation.
    
    Handles forecasting for hierarchical time series where forecasts
    at different levels need to be reconciled to maintain consistency.
    
    Reconciliation methods:
    - Bottom-up: Aggregate forecasts from lowest level
    - Top-down: Disaggregate top-level forecast
    - Middle-out: Start from middle level
    - Optimal reconciliation: MinT (minimum trace)
    
    Examples
    --------
    >>> from forecasting.models.hierarchical import HierarchicalForecaster
    >>> 
    >>> # Define hierarchy
    >>> hierarchy = {
    ...     'Total': ['Region_A', 'Region_B'],
    ...     'Region_A': ['Store_A1', 'Store_A2'],
    ...     'Region_B': ['Store_B1', 'Store_B2']
    ... }
    >>> 
    >>> # Create hierarchical forecaster
    >>> h_forecaster = HierarchicalForecaster(config, hierarchy=hierarchy)
    >>> 
    >>> # Fit and forecast
    >>> h_forecaster.fit(data_dict)
    >>> forecasts = h_forecaster.predict(horizon=30, method='bottom_up')
    """
    
    def __init__(
        self,
        config: ForecastConfig,
        hierarchy: Dict[str, List[str]],
        base_forecaster_class: Optional[type] = None,
    ):
        """Initialize hierarchical forecaster.
        
        Args:
            config: Forecast configuration
            hierarchy: Dictionary defining hierarchy structure
            base_forecaster_class: Forecaster class to use for each series
        """
        self.config = config
        self.hierarchy = hierarchy
        self.base_forecaster_class = base_forecaster_class
        self.forecasters: Dict[str, BaseForecaster] = {}
        self.is_fitted = False
        
        # Build hierarchy structure
        self._build_hierarchy_structure()
    
    def _build_hierarchy_structure(self) -> None:
        """Build internal hierarchy structure."""
        self.levels: Dict[str, int] = {}
        self.children: Dict[str, List[str]] = {}
        self.parent: Dict[str, Optional[str]] = {}
        
        # Assign levels
        def assign_level(node: str, level: int) -> None:
            self.levels[node] = level
            if node in self.hierarchy:
                self.children[node] = self.hierarchy[node]
                for child in self.hierarchy[node]:
                    self.parent[child] = node
                    assign_level(child, level + 1)
            else:
                self.children[node] = []
        
        # Find root (node with no parent)
        root = None
        all_children = set()
        for children_list in self.hierarchy.values():
            all_children.update(children_list)
        
        for node in self.hierarchy.keys():
            if node not in all_children:
                root = node
                break
        
        if root:
            self.parent[root] = None
            assign_level(root, 0)
    
    def fit(
        self,
        data_dict: Dict[str, pd.Series],
        X_dict: Optional[Dict[str, pd.DataFrame]] = None,
        **kwargs: Any
    ) -> "HierarchicalForecaster":
        """Fit forecasters for all series in hierarchy.
        
        Args:
            data_dict: Dictionary mapping series names to data
            X_dict: Optional dictionary of exogenous variables
            **kwargs: Additional arguments for fitting
            
        Returns:
            Self for method chaining
        """
        try:
            # Initialize base forecaster class if not provided
            if self.base_forecaster_class is None:
                from forecasting.models import ARIMAForecaster
                self.base_forecaster_class = ARIMAForecaster
            
            # Fit forecaster for each series
            for series_name, data in data_dict.items():
                forecaster = self.base_forecaster_class(self.config)
                X = X_dict.get(series_name) if X_dict else None
                forecaster.fit(data, X, **kwargs)
                self.forecasters[series_name] = forecaster
            
            self.is_fitted = True
            return self
            
        except Exception as e:
            raise ModelError(f"Failed to fit hierarchical forecaster: {str(e)}")
    
    def predict(
        self,
        horizon: Optional[int] = None,
        method: str = 'bottom_up',
        X_dict: Optional[Dict[str, pd.DataFrame]] = None,
        **kwargs: Any
    ) -> Dict[str, pd.Series]:
        """Generate hierarchical forecasts with reconciliation.
        
        Args:
            horizon: Number of periods to forecast
            method: Reconciliation method ('bottom_up', 'top_down', 'middle_out', 'optimal')
            X_dict: Optional dictionary of exogenous variables
            **kwargs: Additional arguments
            
        Returns:
            Dictionary mapping series names to forecasts
        """
        if not self.is_fitted:
            raise ModelError("Hierarchical forecaster must be fitted before prediction")
        
        if horizon is None:
            horizon = self.config.horizon
        
        # Generate base forecasts
        base_forecasts = {}
        for series_name, forecaster in self.forecasters.items():
            X = X_dict.get(series_name) if X_dict else None
            forecast, _ = forecaster.predict(horizon=horizon, X=X, **kwargs)
            base_forecasts[series_name] = forecast
        
        # Reconcile forecasts
        if method == 'bottom_up':
            return self._reconcile_bottom_up(base_forecasts)
        elif method == 'top_down':
            return self._reconcile_top_down(base_forecasts)
        elif method == 'middle_out':
            return self._reconcile_middle_out(base_forecasts)
        elif method == 'optimal':
            return self._reconcile_optimal(base_forecasts)
        else:
            raise ValueError(f"Unknown reconciliation method: {method}")
    
    def _reconcile_bottom_up(
        self,
        forecasts: Dict[str, pd.Series]
    ) -> Dict[str, pd.Series]:
        """Bottom-up reconciliation.
        
        Args:
            forecasts: Base forecasts
            
        Returns:
            Reconciled forecasts
        """
        reconciled = forecasts.copy()
        
        # Find leaf nodes (bottom level)
        leaf_nodes = [node for node in self.levels.keys() if not self.children[node]]
        
        # Aggregate from bottom to top
        def aggregate_children(node: str) -> pd.Series:
            if not self.children[node]:
                return reconciled[node]
            
            # Sum children
            children_sum = sum(aggregate_children(child) for child in self.children[node])
            reconciled[node] = children_sum
            return children_sum
        
        # Start from root
        root = [node for node, parent in self.parent.items() if parent is None][0]
        aggregate_children(root)
        
        return reconciled
    
    def _reconcile_top_down(
        self,
        forecasts: Dict[str, pd.Series]
    ) -> Dict[str, pd.Series]:
        """Top-down reconciliation using proportions.
        
        Args:
            forecasts: Base forecasts
            
        Returns:
            Reconciled forecasts
        """
        reconciled = forecasts.copy()
        
        # Find root
        root = [node for node, parent in self.parent.items() if parent is None][0]
        
        # Calculate historical proportions
        # (In practice, you'd calculate these from historical data)
        # For now, use equal proportions
        def disaggregate(node: str, parent_forecast: pd.Series) -> None:
            if not self.children[node]:
                return
            
            n_children = len(self.children[node])
            for child in self.children[node]:
                # Equal split (simplified)
                reconciled[child] = parent_forecast / n_children
                disaggregate(child, reconciled[child])
        
        disaggregate(root, reconciled[root])
        
        return reconciled
    
    def _reconcile_middle_out(
        self,
        forecasts: Dict[str, pd.Series]
    ) -> Dict[str, pd.Series]:
        """Middle-out reconciliation.
        
        Args:
            forecasts: Base forecasts
            
        Returns:
            Reconciled forecasts
        """
        # Find middle level (simplified: use level 1)
        middle_nodes = [node for node, level in self.levels.items() if level == 1]
        
        # Aggregate up from middle
        reconciled = self._reconcile_bottom_up(forecasts)
        
        # Disaggregate down from middle
        for node in middle_nodes:
            self._disaggregate_node(node, reconciled)
        
        return reconciled
    
    def _reconcile_optimal(
        self,
        forecasts: Dict[str, pd.Series]
    ) -> Dict[str, pd.Series]:
        """Optimal reconciliation using MinT approach.
        
        Args:
            forecasts: Base forecasts
            
        Returns:
            Reconciled forecasts
        """
        # Simplified optimal reconciliation
        # In practice, this would use the full MinT algorithm
        return self._reconcile_bottom_up(forecasts)
    
    def _disaggregate_node(
        self,
        node: str,
        forecasts: Dict[str, pd.Series]
    ) -> None:
        """Disaggregate forecast for a node to its children.
        
        Args:
            node: Node to disaggregate
            forecasts: Dictionary of forecasts (modified in place)
        """
        if not self.children[node]:
            return
        
        n_children = len(self.children[node])
        for child in self.children[node]:
            forecasts[child] = forecasts[node] / n_children
            self._disaggregate_node(child, forecasts)


# Made with Bob