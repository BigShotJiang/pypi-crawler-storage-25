"""
New Product Forecasting Models.

This module provides comprehensive approaches for forecasting new products
across the entire data availability spectrum - from zero to limited historical data.

Zero Historical Data (Cold Start)
----------------------------------
- ZeroShotForecaster: For completely new products with NO historical data
  Uses product attributes, market intelligence, and category benchmarks

Limited Historical Data (Few-Shot)
-----------------------------------
Traditional Methods:
- AnalogousProductForecaster: Use similar products as reference (5-20 obs)
- BassDiffusionForecaster: Model product adoption lifecycle (10-30 obs)
- HierarchicalForecaster: Leverage category-level patterns (10+ obs)

Modern Deep Learning Methods (State-of-the-Art):
- TransferLearningForecaster: Pre-train on existing products, fine-tune (2-10 obs)
- MetaLearningForecaster: Neural Processes for few-shot learning (1-5 obs)
- TemporalFusionForecaster: Transformer-based with interpretability (20+ obs)

Decision Guide
--------------
Data Available | Recommended Method
---------------|-------------------
0 observations | ZeroShotForecaster
1-5 obs        | MetaLearningForecaster
2-10 obs       | TransferLearningForecaster
5-20 obs       | AnalogousProductForecaster
10-30 obs      | BassDiffusionForecaster or HierarchicalForecaster
20+ obs        | TemporalFusionForecaster
"""

from forecasting.models.new_product.analogous import AnalogousProductForecaster
from forecasting.models.new_product.bass_diffusion import BassDiffusionForecaster
from forecasting.models.new_product.hierarchical import HierarchicalForecaster
from forecasting.models.new_product.transfer_learning import TransferLearningForecaster
from forecasting.models.new_product.meta_learning import MetaLearningForecaster
from forecasting.models.new_product.temporal_fusion import TemporalFusionForecaster
from forecasting.models.new_product.zero_shot import (
    ZeroShotForecaster,
    ProductAttributes,
    MarketIntelligence
)

__all__ = [
    # Zero-shot (0 observations)
    'ZeroShotForecaster',
    'ProductAttributes',
    'MarketIntelligence',
    # Traditional methods (5-30 observations)
    'AnalogousProductForecaster',
    'BassDiffusionForecaster',
    'HierarchicalForecaster',
    # Modern deep learning methods (1-20+ observations)
    'TransferLearningForecaster',
    'MetaLearningForecaster',
    'TemporalFusionForecaster',
]

# Made with Bob
