"""
Zero-Shot Forecasting for Completely New Products.

Handles products with absolutely no historical data by leveraging:
1. Product attributes and characteristics
2. Market intelligence and category trends
3. Similar product patterns
4. Expert knowledge and business rules
5. External data sources
"""

from typing import Optional, Tuple, List, Dict, Any
import numpy as np
import pandas as pd
from scipy.stats import norm
from dataclasses import dataclass

from forecasting.core.base import BaseForecaster
from forecasting.core.config import ForecastConfig


@dataclass
class ProductAttributes:
    """Product attributes for zero-shot forecasting."""
    category: str
    price: float
    brand: str
    quality_tier: str  # 'budget', 'mid', 'premium'
    innovation_level: str  # 'incremental', 'moderate', 'disruptive'
    target_market: str  # 'mass', 'niche', 'luxury'
    seasonality_type: Optional[str] = None  # 'none', 'weekly', 'monthly', 'yearly'
    launch_marketing_budget: Optional[float] = None
    competitor_count: Optional[int] = None
    market_maturity: Optional[str] = None  # 'emerging', 'growth', 'mature', 'declining'


@dataclass
class MarketIntelligence:
    """Market intelligence data."""
    category_growth_rate: float  # Annual growth rate
    category_avg_demand: float  # Average demand in category
    market_size: float  # Total market size
    seasonality_pattern: Optional[np.ndarray] = None
    trend_direction: str = 'stable'  # 'growing', 'stable', 'declining'


class ZeroShotForecaster(BaseForecaster):
    """
    Zero-Shot Forecaster for completely new products with no historical data.
    
    This approach combines multiple strategies:
    1. **Attribute-Based Estimation**: Use product characteristics to estimate demand
    2. **Category Benchmarking**: Leverage category-level statistics
    3. **Analogous Product Matching**: Find similar products as reference
    4. **Market Intelligence**: Incorporate market trends and growth
    5. **Expert Rules**: Apply business logic and domain knowledge
    6. **Ensemble Approach**: Combine multiple estimates with confidence weighting
    
    Best suited for:
    - Completely new products (0 historical observations)
    - Product launches with rich attribute data
    - Categories with established patterns
    - When market intelligence is available
    
    Parameters
    ----------
    use_category_benchmark : bool, default=True
        Use category-level benchmarks
    use_analogous_products : bool, default=True
        Find and use similar products
    use_market_intelligence : bool, default=True
        Incorporate market trends
    confidence_decay : float, default=0.95
        Confidence decay factor for future periods
    
    Attributes
    ----------
    category_stats_ : dict
        Category-level statistics
    analogous_products_ : list
        Similar products used for reference
    
    Examples
    --------
    >>> from forecasting.models.new_product import ZeroShotForecaster
    >>> from forecasting.models.new_product.zero_shot import (
    ...     ProductAttributes, MarketIntelligence
    ... )
    >>> 
    >>> # Define product attributes
    >>> product = ProductAttributes(
    ...     category='Smartphones',
    ...     price=799,
    ...     brand='NewBrand',
    ...     quality_tier='premium',
    ...     innovation_level='moderate',
    ...     target_market='mass',
    ...     seasonality_type='yearly',
    ...     launch_marketing_budget=1000000,
    ...     competitor_count=5,
    ...     market_maturity='growth'
    ... )
    >>> 
    >>> # Market intelligence
    >>> market = MarketIntelligence(
    ...     category_growth_rate=0.15,  # 15% annual growth
    ...     category_avg_demand=10000,
    ...     market_size=1000000,
    ...     trend_direction='growing'
    ... )
    >>> 
    >>> # Historical category data (optional)
    >>> category_history = {
    ...     'Product_A': np.array([100, 150, 200, 250]),
    ...     'Product_B': np.array([80, 120, 160, 200])
    ... }
    >>> 
    >>> # Initialize and fit
    >>> model = ZeroShotForecaster()
    >>> model.fit(
    ...     product_attributes=product,
    ...     market_intelligence=market,
    ...     category_history=category_history
    ... )
    >>> 
    >>> # Forecast with uncertainty
    >>> forecast, conf_int = model.predict(horizon=12, return_conf_int=True)
    >>> print(f"12-month forecast: {forecast}")
    """
    
    def __init__(
        self,
        config: Optional[ForecastConfig] = None,
        use_category_benchmark: bool = True,
        use_analogous_products: bool = True,
        use_market_intelligence: bool = True,
        confidence_decay: float = 0.95,
        min_confidence: float = 0.3
    ):
        """Initialize zero-shot forecaster."""
        super().__init__(config or ForecastConfig())
        
        self.use_category_benchmark = use_category_benchmark
        self.use_analogous_products = use_analogous_products
        self.use_market_intelligence = use_market_intelligence
        self.confidence_decay = confidence_decay
        self.min_confidence = min_confidence
        
        # Learned components
        self.product_attributes_: Optional[ProductAttributes] = None
        self.market_intelligence_: Optional[MarketIntelligence] = None
        self.category_stats_: Optional[Dict] = None
        self.analogous_products_: Optional[List[Dict]] = None
        self.base_estimate_: Optional[float] = None
        
    def fit(
        self,
        y: Optional[pd.Series] = None,
        X: Optional[pd.DataFrame] = None,
        product_attributes: Optional[ProductAttributes] = None,
        market_intelligence: Optional[MarketIntelligence] = None,
        category_history: Optional[Dict[str, np.ndarray]] = None,
        analogous_products: Optional[List[Dict]] = None,
        **kwargs
    ) -> 'ZeroShotForecaster':
        """
        Fit zero-shot forecaster using product attributes and market data.
        
        Parameters
        ----------
        y : pd.Series, optional
            Not used (for compatibility)
        X : pd.DataFrame, optional
            Not used (for compatibility)
        product_attributes : ProductAttributes
            Attributes of the new product
        market_intelligence : MarketIntelligence
            Market intelligence data
        category_history : dict, optional
            Historical data for products in same category
        analogous_products : list, optional
            List of similar products with their data
        **kwargs : dict
            Additional arguments
            
        Returns
        -------
        self : ZeroShotForecaster
            Fitted model
        """
        if product_attributes is None:
            raise ValueError("product_attributes is required for zero-shot forecasting")
        
        print("Fitting zero-shot forecaster for completely new product...")
        
        # Store inputs
        self.product_attributes_ = product_attributes
        self.market_intelligence_ = market_intelligence
        
        # Analyze category if history provided
        if category_history and self.use_category_benchmark:
            print("  ✓ Analyzing category benchmarks...")
            self.category_stats_ = self._analyze_category(category_history)
        
        # Find analogous products
        if analogous_products and self.use_analogous_products:
            print("  ✓ Identifying analogous products...")
            self.analogous_products_ = self._rank_analogous_products(
                analogous_products,
                product_attributes
            )
        
        # Compute base estimate
        print("  ✓ Computing base demand estimate...")
        self.base_estimate_ = self._compute_base_estimate()
        
        self.is_fitted = True
        print(f"  ✓ Base estimate: {self.base_estimate_:.2f} units")
        print("Zero-shot forecaster ready!")
        
        return self
    
    def _analyze_category(self, category_history: Dict[str, np.ndarray]) -> Dict:
        """Analyze category-level statistics."""
        all_demands = np.concatenate(list(category_history.values()))
        
        stats = {
            'mean': np.mean(all_demands),
            'median': np.median(all_demands),
            'std': np.std(all_demands),
            'min': np.min(all_demands),
            'max': np.max(all_demands),
            'q25': np.percentile(all_demands, 25),
            'q75': np.percentile(all_demands, 75),
            'n_products': len(category_history)
        }
        
        # Compute average growth rate
        growth_rates = []
        for demand in category_history.values():
            if len(demand) > 1:
                growth = (demand[-1] - demand[0]) / demand[0]
                growth_rates.append(growth)
        
        if growth_rates:
            stats['avg_growth_rate'] = np.mean(growth_rates)
        else:
            stats['avg_growth_rate'] = 0.0
        
        return stats
    
    def _rank_analogous_products(
        self,
        analogous_products: List[Dict],
        target_attributes: ProductAttributes
    ) -> List[Dict]:
        """
        Rank analogous products by similarity.
        
        Returns top 5 most similar products.
        """
        similarities = []
        
        for product in analogous_products:
            attrs = product.get('attributes', {})
            similarity = self._compute_similarity(attrs, target_attributes)
            
            similarities.append({
                'product': product,
                'similarity': similarity
            })
        
        # Sort by similarity
        similarities.sort(key=lambda x: x['similarity'], reverse=True)
        
        return similarities[:5]  # Top 5
    
    def _compute_similarity(
        self,
        attrs1: Dict,
        attrs2: ProductAttributes
    ) -> float:
        """
        Compute similarity between products.
        
        Uses weighted attribute matching.
        """
        similarity = 0.0
        weights = {
            'category': 0.3,
            'quality_tier': 0.2,
            'target_market': 0.2,
            'innovation_level': 0.15,
            'price': 0.15
        }
        
        # Category match
        if attrs1.get('category') == attrs2.category:
            similarity += weights['category']
        
        # Quality tier match
        if attrs1.get('quality_tier') == attrs2.quality_tier:
            similarity += weights['quality_tier']
        
        # Target market match
        if attrs1.get('target_market') == attrs2.target_market:
            similarity += weights['target_market']
        
        # Innovation level match
        if attrs1.get('innovation_level') == attrs2.innovation_level:
            similarity += weights['innovation_level']
        
        # Price similarity (normalized)
        if 'price' in attrs1 and attrs2.price:
            price_diff = abs(attrs1['price'] - attrs2.price)
            max_price = max(attrs1['price'], attrs2.price)
            price_sim = 1 - (price_diff / max_price)
            similarity += weights['price'] * price_sim
        
        return similarity
    
    def _compute_base_estimate(self) -> float:
        """
        Compute base demand estimate using multiple approaches.
        
        Combines:
        1. Category benchmark
        2. Analogous products
        3. Market intelligence
        4. Attribute-based rules
        """
        estimates = []
        weights = []
        
        # 1. Category benchmark
        if self.category_stats_ and self.use_category_benchmark:
            category_est = self._estimate_from_category()
            estimates.append(category_est)
            weights.append(0.3)
        
        # 2. Analogous products
        if self.analogous_products_ and self.use_analogous_products:
            analogous_est = self._estimate_from_analogous()
            estimates.append(analogous_est)
            weights.append(0.4)
        
        # 3. Market intelligence
        if self.market_intelligence_ and self.use_market_intelligence:
            market_est = self._estimate_from_market()
            estimates.append(market_est)
            weights.append(0.2)
        
        # 4. Attribute-based rules
        if self.product_attributes_:
            rule_est = self._estimate_from_attributes()
            estimates.append(rule_est)
            weights.append(0.1)
        
        # Weighted average
        if estimates:
            # Normalize weights
            weights = np.array(weights)
            weights = weights / weights.sum()
            
            base_estimate = np.average(estimates, weights=weights)
        else:
            # Fallback: use market intelligence or default
            if self.market_intelligence_:
                base_estimate = self.market_intelligence_.category_avg_demand * 0.1
            else:
                base_estimate = 100.0  # Default fallback
        
        return base_estimate
    
    def _estimate_from_category(self) -> float:
        """Estimate based on category statistics."""
        if not self.category_stats_:
            return 0.0
        
        # Use median as base, adjusted by quality tier
        base = self.category_stats_['median']
        
        # Adjust based on quality tier
        if self.product_attributes_:
            if self.product_attributes_.quality_tier == 'premium':
                base *= 0.7  # Premium products typically have lower volume
            elif self.product_attributes_.quality_tier == 'budget':
                base *= 1.3  # Budget products typically have higher volume
        
        return base
    
    def _estimate_from_analogous(self) -> float:
        """Estimate based on analogous products."""
        if not self.analogous_products_:
            return 0.0
        
        # Weighted average of analogous products
        estimates = []
        weights = []
        
        for item in self.analogous_products_:
            product = item['product']
            similarity = item['similarity']
            
            if 'demand' in product:
                demand = product['demand']
                if isinstance(demand, np.ndarray):
                    avg_demand = np.mean(demand)
                else:
                    avg_demand = demand
                
                estimates.append(avg_demand)
                weights.append(similarity)
        
        if estimates:
            weights = np.array(weights)
            weights = weights / weights.sum()
            return np.average(estimates, weights=weights)
        
        return 0.0
    
    def _estimate_from_market(self) -> float:
        """Estimate based on market intelligence."""
        if not self.market_intelligence_:
            return 0.0
        
        # Market share estimation
        market_size = self.market_intelligence_.market_size
        
        # Estimate market share based on attributes
        if self.product_attributes_:
            # Base market share
            if self.product_attributes_.target_market == 'mass':
                market_share = 0.05  # 5% for mass market
            elif self.product_attributes_.target_market == 'niche':
                market_share = 0.02  # 2% for niche
            else:  # luxury
                market_share = 0.01  # 1% for luxury
            
            # Adjust for innovation
            if self.product_attributes_.innovation_level == 'disruptive':
                market_share *= 1.5
            elif self.product_attributes_.innovation_level == 'incremental':
                market_share *= 0.8
            
            # Adjust for competition
            if self.product_attributes_.competitor_count:
                competition_factor = 1 / (1 + self.product_attributes_.competitor_count * 0.1)
                market_share *= competition_factor
            
            return market_size * market_share
        
        return self.market_intelligence_.category_avg_demand
    
    def _estimate_from_attributes(self) -> float:
        """Estimate based on product attributes using business rules."""
        if not self.product_attributes_:
            return 0.0
        
        # Base estimate from price tier
        price = self.product_attributes_.price
        
        if price < 100:
            base = 500  # High volume for low price
        elif price < 500:
            base = 200  # Medium volume
        else:
            base = 50  # Low volume for high price
        
        # Adjust for marketing budget
        if self.product_attributes_.launch_marketing_budget:
            budget = self.product_attributes_.launch_marketing_budget
            marketing_factor = 1 + (budget / 1000000) * 0.5  # 50% boost per $1M
            base *= marketing_factor
        
        return base
    
    def predict(
        self,
        horizon: Optional[int] = None,
        X: Optional[pd.DataFrame] = None,
        return_conf_int: bool = True,
        **kwargs
    ) -> Tuple[pd.Series, Optional[pd.DataFrame]]:
        """
        Generate zero-shot forecast.
        
        Parameters
        ----------
        horizon : int, optional
            Number of periods to forecast
        X : pd.DataFrame, optional
            Not used (for compatibility)
        return_conf_int : bool, default=True
            Whether to return confidence intervals
        **kwargs : dict
            Additional arguments
            
        Returns
        -------
        forecast : pd.Series
            Forecasted values
        conf_int : pd.DataFrame or None
            Confidence intervals if return_conf_int=True
        """
        if not self.is_fitted:
            raise ValueError("Model must be fitted before prediction")
        
        if horizon is None:
            horizon = 12
        
        # Generate forecast trajectory
        forecast_values = self._generate_trajectory(horizon)
        
        # Create series
        forecast = pd.Series(forecast_values, index=range(horizon))
        
        # Confidence intervals with increasing uncertainty
        conf_int = None
        if return_conf_int:
            conf_int = self._compute_confidence_intervals(forecast_values, horizon)
        
        return forecast, conf_int
    
    def _generate_trajectory(self, horizon: int) -> np.ndarray:
        """
        Generate demand trajectory over time.
        
        Incorporates:
        - Growth trend
        - Seasonality
        - Product lifecycle
        """
        if self.base_estimate_ is None:
            raise ValueError("Base estimate not computed")
        
        trajectory = np.zeros(horizon)
        
        # Base demand
        base = self.base_estimate_
        
        # Growth trend
        if self.market_intelligence_:
            monthly_growth = (1 + self.market_intelligence_.category_growth_rate) ** (1/12) - 1
        else:
            monthly_growth = 0.01  # Default 1% monthly growth
        
        # Product lifecycle curve (S-curve for adoption)
        for t in range(horizon):
            # S-curve adoption
            adoption_factor = 1 / (1 + np.exp(-0.3 * (t - horizon/3)))
            
            # Growth
            growth_factor = (1 + monthly_growth) ** t
            
            # Combine
            trajectory[t] = base * adoption_factor * growth_factor
        
        # Add seasonality if specified
        if self.product_attributes_ and self.product_attributes_.seasonality_type:
            seasonality = self._generate_seasonality(horizon)
            trajectory = trajectory * (1 + seasonality)
        
        return trajectory
    
    def _generate_seasonality(self, horizon: int) -> np.ndarray:
        """Generate seasonality pattern."""
        if not self.product_attributes_:
            return np.zeros(horizon)
        
        seasonality_type = self.product_attributes_.seasonality_type
        
        if seasonality_type == 'weekly':
            period = 7 / 30  # Weekly in months
        elif seasonality_type == 'monthly':
            period = 1
        elif seasonality_type == 'yearly':
            period = 12
        else:
            return np.zeros(horizon)
        
        # Sine wave seasonality
        t = np.arange(horizon)
        seasonality = 0.2 * np.sin(2 * np.pi * t / period)
        
        return seasonality
    
    def _compute_confidence_intervals(
        self,
        forecast: np.ndarray,
        horizon: int
    ) -> pd.DataFrame:
        """
        Compute confidence intervals with increasing uncertainty.
        
        Uncertainty increases over time due to:
        1. Lack of historical data
        2. Market uncertainty
        3. Forecast horizon
        """
        # Base uncertainty (high for zero-shot)
        base_uncertainty = 0.5  # 50% coefficient of variation
        
        # Increasing uncertainty over time
        uncertainty = np.array([
            base_uncertainty * (self.confidence_decay ** (-t))
            for t in range(horizon)
        ])
        
        # Ensure minimum confidence
        uncertainty = np.minimum(uncertainty, 1 - self.min_confidence)
        
        # Compute intervals (assuming log-normal distribution)
        std = forecast * uncertainty
        z_score = norm.ppf(0.975)  # 95% confidence
        
        lower = np.maximum(forecast - z_score * std, 0)
        upper = forecast + z_score * std
        
        return pd.DataFrame({
            'lower': lower,
            'upper': upper
        }, index=range(horizon))
    
    def get_params(self) -> dict:
        """Get model parameters."""
        params = {
            'use_category_benchmark': self.use_category_benchmark,
            'use_analogous_products': self.use_analogous_products,
            'use_market_intelligence': self.use_market_intelligence,
            'confidence_decay': self.confidence_decay,
            'min_confidence': self.min_confidence,
            'is_fitted': self.is_fitted
        }
        
        if self.base_estimate_ is not None:
            params['base_estimate'] = self.base_estimate_
        
        if self.category_stats_:
            params['category_stats'] = self.category_stats_
        
        if self.analogous_products_:
            params['n_analogous_products'] = len(self.analogous_products_)
        
        return params
    
    def get_estimate_breakdown(self) -> Dict[str, float]:
        """
        Get breakdown of how base estimate was computed.
        
        Returns
        -------
        breakdown : dict
            Contribution of each method to final estimate
        """
        breakdown = {}
        
        if self.category_stats_:
            breakdown['category_benchmark'] = self._estimate_from_category()
        
        if self.analogous_products_:
            breakdown['analogous_products'] = self._estimate_from_analogous()
        
        if self.market_intelligence_:
            breakdown['market_intelligence'] = self._estimate_from_market()
        
        if self.product_attributes_:
            breakdown['attribute_rules'] = self._estimate_from_attributes()
        
        if self.base_estimate_:
            breakdown['final_estimate'] = self.base_estimate_
        
        return breakdown

# Made with Bob
