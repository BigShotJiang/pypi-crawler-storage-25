"""
Analogous product forecasting for new products.

Uses historical data from similar existing products to forecast demand for new products.
"""

from typing import Dict, List, Optional, Tuple
import numpy as np
import pandas as pd
from scipy.spatial.distance import cosine, euclidean

from forecasting.core.base import BaseForecaster
from forecasting.core.config import ForecastConfig


class AnalogousProductForecaster(BaseForecaster):
    """
    Forecast new products using analogous (similar) existing products.
    
    This method finds similar products based on attributes and uses their
    historical demand patterns to forecast the new product.
    
    Best suited for:
    - Product launches
    - New market entries
    - Products with similar characteristics to existing ones
    
    Parameters
    ----------
    similarity_threshold : float, default=0.7
        Minimum similarity score (0-1) to consider a product analogous
    top_k : int, default=5
        Number of top similar products to use
    similarity_metric : str, default='cosine'
        Similarity metric ('cosine', 'euclidean', 'correlation')
    weighting_method : str, default='similarity'
        How to weight analogous products ('equal', 'similarity', 'inverse_rank')
    
    Attributes
    ----------
    analogous_products_ : List[str]
        IDs of selected analogous products
    similarities_ : np.ndarray
        Similarity scores for analogous products
    weights_ : np.ndarray
        Weights for combining forecasts
    forecast_pattern_ : np.ndarray
        Combined forecast pattern from analogous products
    
    Examples
    --------
    >>> import numpy as np
    >>> import pandas as pd
    >>> from forecasting.models.new_product import AnalogousProductForecaster
    >>> 
    >>> # New product attributes
    >>> new_product = {
    >>>     'category': 'electronics',
    >>>     'price': 299.99,
    >>>     'brand_strength': 0.8,
    >>>     'seasonality': 'high'
    >>> }
    >>> 
    >>> # Historical products database
    >>> products_db = pd.DataFrame({
    >>>     'product_id': ['P1', 'P2', 'P3'],
    >>>     'category': ['electronics', 'electronics', 'home'],
    >>>     'price': [249.99, 349.99, 199.99],
    >>>     'brand_strength': [0.7, 0.9, 0.6],
    >>>     'seasonality': ['high', 'medium', 'low']
    >>> })
    >>> 
    >>> # Historical demand data
    >>> demand_data = {
    >>>     'P1': np.array([10, 15, 20, 25, 30]),
    >>>     'P2': np.array([8, 12, 18, 22, 28]),
    >>>     'P3': np.array([5, 7, 9, 11, 13])
    >>> }
    >>> 
    >>> # Find analogous products and forecast
    >>> model = AnalogousProductForecaster(top_k=2)
    >>> analogous_ids = model.find_analogous_products(new_product, products_db)
    >>> model.fit(demand_data, analogous_ids)
    >>> forecast = model.predict(steps=10)
    """
    
    def __init__(
        self,
        config: Optional[ForecastConfig] = None,
        similarity_threshold: float = 0.7,
        top_k: int = 5,
        similarity_metric: str = 'cosine',
        weighting_method: str = 'similarity'
    ):
        """Initialize analogous product forecaster."""
        super().__init__(config or ForecastConfig())
        
        self.similarity_threshold = similarity_threshold
        self.top_k = top_k
        self.similarity_metric = similarity_metric
        self.weighting_method = weighting_method
        
        # Fitted attributes
        self.analogous_products_: Optional[List[str]] = None
        self.similarities_: Optional[np.ndarray] = None
        self.weights_: Optional[np.ndarray] = None
        self.forecast_pattern_: Optional[np.ndarray] = None
        
    def find_analogous_products(
        self,
        new_product_attributes: Dict,
        products_database: pd.DataFrame,
        attribute_weights: Optional[Dict[str, float]] = None
    ) -> List[str]:
        """
        Find analogous products based on attribute similarity.
        
        Parameters
        ----------
        new_product_attributes : Dict
            Attributes of the new product
        products_database : pd.DataFrame
            Database of existing products with attributes
        attribute_weights : Dict[str, float], optional
            Weights for different attributes in similarity calculation
            
        Returns
        -------
        analogous_products : List[str]
            List of analogous product IDs
        """
        similarities = []
        
        for idx, row in products_database.iterrows():
            similarity = self._calculate_similarity(
                new_product_attributes,
                row.to_dict(),
                attribute_weights
            )
            
            if similarity >= self.similarity_threshold:
                product_id = row.get('product_id', str(idx))
                similarities.append((product_id, similarity))
        
        # Sort by similarity (descending) and take top-k
        similarities.sort(key=lambda x: x[1], reverse=True)
        analogous_products = [p[0] for p in similarities[:self.top_k]]
        self.similarities_ = np.array([p[1] for p in similarities[:self.top_k]])
        
        self.logger.info(
            f"Found {len(analogous_products)} analogous products "
            f"(threshold={self.similarity_threshold})"
        )
        
        return analogous_products
    
    def _calculate_similarity(
        self,
        product1: Dict,
        product2: Dict,
        attribute_weights: Optional[Dict[str, float]] = None
    ) -> float:
        """
        Calculate similarity between two products.
        
        Parameters
        ----------
        product1 : Dict
            First product attributes
        product2 : Dict
            Second product attributes
        attribute_weights : Dict[str, float], optional
            Weights for attributes
            
        Returns
        -------
        similarity : float
            Similarity score between 0 and 1
        """
        # Get common attributes
        common_attrs = set(product1.keys()) & set(product2.keys())
        common_attrs.discard('product_id')  # Exclude ID
        
        if not common_attrs:
            return 0.0
        
        # Separate numerical and categorical attributes
        numerical_attrs = []
        categorical_attrs = []
        
        for attr in common_attrs:
            val1 = product1[attr]
            val2 = product2[attr]
            
            if isinstance(val1, (int, float)) and isinstance(val2, (int, float)):
                numerical_attrs.append(attr)
            else:
                categorical_attrs.append(attr)
        
        # Calculate numerical similarity
        numerical_sim = 0.0
        if numerical_attrs:
            vec1 = np.array([product1[attr] for attr in numerical_attrs])
            vec2 = np.array([product2[attr] for attr in numerical_attrs])
            
            # Normalize vectors
            vec1_norm = (vec1 - vec1.min()) / (vec1.max() - vec1.min() + 1e-10)
            vec2_norm = (vec2 - vec2.min()) / (vec2.max() - vec2.min() + 1e-10)
            
            if self.similarity_metric == 'cosine':
                numerical_sim = 1 - cosine(vec1_norm, vec2_norm)
            elif self.similarity_metric == 'euclidean':
                dist = euclidean(vec1_norm, vec2_norm)
                numerical_sim = 1 / (1 + dist)
            else:  # correlation
                numerical_sim = np.corrcoef(vec1_norm, vec2_norm)[0, 1]
        
        # Calculate categorical similarity (exact match)
        categorical_sim = 0.0
        if categorical_attrs:
            matches = sum(
                1 for attr in categorical_attrs
                if product1[attr] == product2[attr]
            )
            categorical_sim = matches / len(categorical_attrs)
        
        # Combine similarities
        if numerical_attrs and categorical_attrs:
            similarity = 0.6 * numerical_sim + 0.4 * categorical_sim
        elif numerical_attrs:
            similarity = numerical_sim
        else:
            similarity = categorical_sim
        
        # Apply attribute weights if provided
        if attribute_weights:
            weighted_sim = 0.0
            total_weight = 0.0
            for attr in common_attrs:
                weight = attribute_weights.get(attr, 1.0)
                attr_sim = 1.0 if product1[attr] == product2[attr] else 0.0
                weighted_sim += weight * attr_sim
                total_weight += weight
            similarity = weighted_sim / total_weight if total_weight > 0 else similarity
        
        return max(0.0, min(1.0, similarity))
    
    def fit(
        self,
        analogous_data: Dict[str, np.ndarray],
        analogous_products: Optional[List[str]] = None,
        adjustment_factor: float = 1.0
    ) -> 'AnalogousProductForecaster':
        """
        Fit forecaster using analogous product data.
        
        Parameters
        ----------
        analogous_data : Dict[str, np.ndarray]
            Dictionary mapping product IDs to their historical demand
        analogous_products : List[str], optional
            List of analogous product IDs to use. If None, uses all products in data
        adjustment_factor : float, default=1.0
            Factor to adjust forecast (e.g., for market size differences)
            
        Returns
        -------
        self : AnalogousProductForecaster
            Fitted forecaster
        """
        if analogous_products is None:
            analogous_products = list(analogous_data.keys())
        
        self.analogous_products_ = analogous_products
        
        # Calculate weights
        if self.similarities_ is not None and len(self.similarities_) == len(analogous_products):
            if self.weighting_method == 'similarity':
                self.weights_ = self.similarities_ / self.similarities_.sum()
            elif self.weighting_method == 'inverse_rank':
                ranks = np.arange(1, len(analogous_products) + 1)
                self.weights_ = (1 / ranks) / (1 / ranks).sum()
            else:  # equal
                self.weights_ = np.ones(len(analogous_products)) / len(analogous_products)
        else:
            # Equal weights if no similarities available
            self.weights_ = np.ones(len(analogous_products)) / len(analogous_products)
        
        # Combine analogous product patterns
        patterns = []
        for product_id in analogous_products:
            if product_id in analogous_data:
                patterns.append(analogous_data[product_id])
        
        if not patterns:
            raise ValueError("No valid analogous product data found")
        
        # Ensure all patterns have the same length (use minimum length)
        min_length = min(len(p) for p in patterns)
        patterns = [p[:min_length] for p in patterns]
        
        # Weighted average of patterns
        self.forecast_pattern_ = np.zeros(min_length)
        for pattern, weight in zip(patterns, self.weights_):
            self.forecast_pattern_ += weight * pattern
        
        # Apply adjustment factor
        self.forecast_pattern_ *= adjustment_factor
        
        self.is_fitted = True
        self.logger.info(
            f"Fitted analogous product forecaster with {len(analogous_products)} products"
        )
        
        return self
    
    def predict(
        self,
        steps: int = 1,
        growth_rate: Optional[float] = None,
        seasonality_adjustment: Optional[np.ndarray] = None
    ) -> np.ndarray:
        """
        Generate forecast for new product.
        
        Parameters
        ----------
        steps : int, default=1
            Number of periods to forecast
        growth_rate : float, optional
            Expected growth rate per period (e.g., 0.05 for 5% growth)
        seasonality_adjustment : np.ndarray, optional
            Seasonal adjustment factors (length should match steps)
            
        Returns
        -------
        forecast : np.ndarray
            Forecasted demand
        """
        if not self.is_fitted:
            raise ValueError("Model must be fitted before prediction")
        
        # Extend pattern if needed
        if steps <= len(self.forecast_pattern_):
            forecast = self.forecast_pattern_[:steps].copy()
        else:
            # Repeat pattern and extend
            n_repeats = (steps // len(self.forecast_pattern_)) + 1
            extended = np.tile(self.forecast_pattern_, n_repeats)
            forecast = extended[:steps]
        
        # Apply growth rate if specified
        if growth_rate is not None:
            growth_factors = np.array([(1 + growth_rate) ** t for t in range(steps)])
            forecast = forecast * growth_factors
        
        # Apply seasonality adjustment if specified
        if seasonality_adjustment is not None:
            if len(seasonality_adjustment) != steps:
                raise ValueError(
                    f"Seasonality adjustment length ({len(seasonality_adjustment)}) "
                    f"must match forecast steps ({steps})"
                )
            forecast = forecast * seasonality_adjustment
        
        return forecast
    
    def get_params(self) -> dict:
        """Get model parameters."""
        params = {
            'similarity_threshold': self.similarity_threshold,
            'top_k': self.top_k,
            'similarity_metric': self.similarity_metric,
            'weighting_method': self.weighting_method
        }
        
        if self.is_fitted:
            params.update({
                'analogous_products': self.analogous_products_,
                'similarities': self.similarities_.tolist() if self.similarities_ is not None else None,
                'weights': self.weights_.tolist() if self.weights_ is not None else None,
                'pattern_length': len(self.forecast_pattern_) if self.forecast_pattern_ is not None else 0
            })
        
        return params

# Made with Bob
