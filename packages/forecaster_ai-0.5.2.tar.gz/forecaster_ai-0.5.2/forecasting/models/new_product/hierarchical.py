"""
Hierarchical forecasting for new products.

Pools information across product hierarchy to improve forecasts for new products.
"""

from typing import Dict, List, Optional, Tuple
import numpy as np
import pandas as pd

from forecasting.core.base import BaseForecaster
from forecasting.core.config import ForecastConfig


class HierarchicalForecaster(BaseForecaster):
    """
    Hierarchical forecasting for new products using category-level information.
    
    This method leverages the product hierarchy (e.g., category, subcategory, brand)
    to pool information and generate forecasts for new products.
    
    Approaches:
    - Top-down: Forecast at aggregate level, then disaggregate
    - Bottom-up: Forecast at product level, then aggregate
    - Middle-out: Forecast at middle level, then reconcile
    
    Best suited for:
    - New products in existing categories
    - Products with hierarchical structure
    - Portfolio forecasting
    
    Parameters
    ----------
    hierarchy_levels : List[str]
        Names of hierarchy levels (e.g., ['category', 'subcategory', 'product'])
    reconciliation_method : str, default='proportional'
        Method to reconcile forecasts ('proportional', 'ols', 'wls')
    
    Attributes
    ----------
    hierarchy_ : Dict
        Fitted hierarchy structure
    proportions_ : Dict
        Historical proportions at each level
    
    Examples
    --------
    >>> import numpy as np
    >>> import pandas as pd
    >>> from forecasting.models.new_product import HierarchicalForecaster
    >>> 
    >>> # Historical data with hierarchy
    >>> data = pd.DataFrame({
    >>>     'product_id': ['P1', 'P2', 'P3', 'P4'],
    >>>     'category': ['Electronics', 'Electronics', 'Home', 'Home'],
    >>>     'subcategory': ['Phones', 'Tablets', 'Kitchen', 'Bedroom'],
    >>>     'demand': [100, 80, 60, 40]
    >>> })
    >>> 
    >>> # Fit hierarchical model
    >>> model = HierarchicalForecaster(
    >>>     hierarchy_levels=['category', 'subcategory', 'product_id']
    >>> )
    >>> model.fit(data, value_column='demand')
    >>> 
    >>> # Forecast for new product in existing category
    >>> new_product = {
    >>>     'category': 'Electronics',
    >>>     'subcategory': 'Phones'
    >>> }
    >>> forecast = model.predict_new_product(new_product, steps=10)
    """
    
    def __init__(
        self,
        config: Optional[ForecastConfig] = None,
        hierarchy_levels: Optional[List[str]] = None,
        reconciliation_method: str = 'proportional'
    ):
        """Initialize hierarchical forecaster."""
        super().__init__(config or ForecastConfig())
        
        self.hierarchy_levels = hierarchy_levels or ['category', 'product']
        self.reconciliation_method = reconciliation_method
        
        # Fitted attributes
        self.hierarchy_: Optional[Dict] = None
        self.proportions_: Optional[Dict] = None
        self.aggregated_data_: Optional[pd.DataFrame] = None
        
    def fit(
        self,
        data: pd.DataFrame,
        value_column: str = 'demand',
        time_column: Optional[str] = None
    ) -> 'HierarchicalForecaster':
        """
        Fit hierarchical model to historical data.
        
        Parameters
        ----------
        data : pd.DataFrame
            Historical data with hierarchy columns
        value_column : str, default='demand'
            Name of the value column
        time_column : str, optional
            Name of the time column (if time series data)
            
        Returns
        -------
        self : HierarchicalForecaster
            Fitted model
        """
        # Validate hierarchy levels exist in data
        missing_levels = set(self.hierarchy_levels) - set(data.columns)
        if missing_levels:
            raise ValueError(f"Missing hierarchy levels in data: {missing_levels}")
        
        # Build hierarchy structure
        self.hierarchy_ = self._build_hierarchy(data, value_column)
        
        # Calculate proportions at each level
        self.proportions_ = self._calculate_proportions(data, value_column)
        
        # Store aggregated data
        self.aggregated_data_ = self._aggregate_data(data, value_column, time_column)
        
        self.is_fitted = True
        return self
    
    def _build_hierarchy(
        self,
        data: pd.DataFrame,
        value_column: str
    ) -> Dict:
        """Build hierarchy structure from data."""
        hierarchy = {}
        
        for level in self.hierarchy_levels:
            if level not in data.columns:
                continue
            
            # Get unique values at this level
            unique_values = data[level].unique()
            hierarchy[level] = {
                'values': unique_values.tolist(),
                'count': len(unique_values)
            }
            
            # Calculate total at this level
            level_totals = data.groupby(level)[value_column].sum()
            hierarchy[level]['totals'] = level_totals.to_dict()
        
        return hierarchy
    
    def _calculate_proportions(
        self,
        data: pd.DataFrame,
        value_column: str
    ) -> Dict:
        """Calculate historical proportions at each hierarchy level."""
        proportions = {}
        
        # Calculate proportions for each level
        for i, level in enumerate(self.hierarchy_levels[:-1]):
            next_level = self.hierarchy_levels[i + 1]
            
            # Group by current and next level
            grouped = data.groupby([level, next_level])[value_column].sum()
            
            # Calculate proportions
            level_totals = data.groupby(level)[value_column].sum()
            
            props = {}
            for parent in level_totals.index:
                if parent in grouped.index:
                    children = grouped[parent]
                    parent_total = level_totals[parent]
                    
                    if parent_total > 0:
                        child_props = children / parent_total
                        props[parent] = child_props.to_dict()
                    else:
                        props[parent] = {child: 0.0 for child in children.index}
            
            proportions[f"{level}_to_{next_level}"] = props
        
        return proportions
    
    def _aggregate_data(
        self,
        data: pd.DataFrame,
        value_column: str,
        time_column: Optional[str]
    ) -> pd.DataFrame:
        """Aggregate data at each hierarchy level."""
        aggregated = {}
        
        # Aggregate at each level
        for level in self.hierarchy_levels:
            if time_column:
                # Time series aggregation
                agg_data = data.groupby([time_column, level])[value_column].sum().reset_index()
            else:
                # Simple aggregation
                agg_data = data.groupby(level)[value_column].sum().reset_index()
            
            aggregated[level] = agg_data
        
        return aggregated
    
    def predict_new_product(
        self,
        new_product_attributes: Dict,
        steps: int = 1,
        category_forecast: Optional[np.ndarray] = None
    ) -> np.ndarray:
        """
        Forecast for a new product using hierarchical information.
        
        Parameters
        ----------
        new_product_attributes : Dict
            Attributes of the new product (must include hierarchy levels)
        steps : int, default=1
            Number of periods to forecast
        category_forecast : np.ndarray, optional
            Forecast at category level. If None, uses historical average.
            
        Returns
        -------
        forecast : np.ndarray
            Forecasted demand for new product
        """
        if not self.is_fitted:
            raise ValueError("Model must be fitted before prediction")
        
        # Get category/parent level from new product attributes
        parent_level = self.hierarchy_levels[0]
        if parent_level not in new_product_attributes:
            raise ValueError(f"New product must have '{parent_level}' attribute")
        
        parent_value = new_product_attributes[parent_level]
        
        # Get category forecast
        if category_forecast is None:
            # Use historical average at parent level
            if parent_value in self.hierarchy_[parent_level]['totals']:
                parent_total = self.hierarchy_[parent_level]['totals'][parent_value]
                category_forecast = np.full(steps, parent_total / steps)
            else:
                # Unknown category, use overall average
                all_totals = list(self.hierarchy_[parent_level]['totals'].values())
                avg_total = np.mean(all_totals) if all_totals else 0
                category_forecast = np.full(steps, avg_total / steps)
        
        # Apply proportional disaggregation
        # Estimate proportion for new product based on similar products
        proportion = self._estimate_new_product_proportion(new_product_attributes)
        
        # Forecast = Category forecast * Proportion
        forecast = category_forecast * proportion
        
        return forecast
    
    def _estimate_new_product_proportion(
        self,
        new_product_attributes: Dict
    ) -> float:
        """
        Estimate the proportion for a new product.
        
        Uses average proportion of similar products in the same category.
        """
        parent_level = self.hierarchy_levels[0]
        parent_value = new_product_attributes[parent_level]
        
        # Get proportions for this parent
        prop_key = f"{parent_level}_to_{self.hierarchy_levels[1]}"
        
        if prop_key in self.proportions_ and parent_value in self.proportions_[prop_key]:
            # Average proportion of existing products in this category
            props = list(self.proportions_[prop_key][parent_value].values())
            if props:
                # Use average proportion
                avg_proportion = np.mean(props)
                return avg_proportion
        
        # Fallback: equal proportion among products
        if parent_value in self.hierarchy_[parent_level]:
            n_products = len(self.hierarchy_[self.hierarchy_levels[-1]]['values'])
            return 1.0 / max(n_products, 1)
        
        return 0.1  # Default fallback
    
    def reconcile_forecasts(
        self,
        forecasts: Dict[str, np.ndarray]
    ) -> Dict[str, np.ndarray]:
        """
        Reconcile forecasts across hierarchy levels.
        
        Parameters
        ----------
        forecasts : Dict[str, np.ndarray]
            Forecasts at different hierarchy levels
            
        Returns
        -------
        reconciled : Dict[str, np.ndarray]
            Reconciled forecasts
        """
        if self.reconciliation_method == 'proportional':
            return self._reconcile_proportional(forecasts)
        else:
            # Other methods (OLS, WLS) would be implemented here
            return forecasts
    
    def _reconcile_proportional(
        self,
        forecasts: Dict[str, np.ndarray]
    ) -> Dict[str, np.ndarray]:
        """Reconcile using proportional method."""
        reconciled = forecasts.copy()
        
        # Top-down reconciliation
        for i, level in enumerate(self.hierarchy_levels[:-1]):
            next_level = self.hierarchy_levels[i + 1]
            prop_key = f"{level}_to_{next_level}"
            
            if prop_key in self.proportions_:
                # Adjust lower level forecasts to match upper level
                for parent, child_props in self.proportions_[prop_key].items():
                    if parent in forecasts:
                        parent_forecast = forecasts[parent]
                        
                        for child, prop in child_props.items():
                            if child in reconciled:
                                reconciled[child] = parent_forecast * prop
        
        return reconciled
    
    def get_params(self) -> dict:
        """Get model parameters."""
        params = {
            'hierarchy_levels': self.hierarchy_levels,
            'reconciliation_method': self.reconciliation_method
        }
        
        if self.is_fitted and self.hierarchy_:
            params['hierarchy_structure'] = {
                level: info['count']
                for level, info in self.hierarchy_.items()
            }
        
        return params

# Made with Bob
