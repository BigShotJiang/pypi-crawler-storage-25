"""
Bass Diffusion Model for new product forecasting.

Models product adoption using innovation and imitation parameters.

Reference:
    Bass, F. M. (1969). A new product growth for model consumer durables.
    Management Science, 15(5), 215-227.
"""

from typing import Optional, Tuple
import numpy as np
from scipy.optimize import curve_fit

from forecasting.core.base import BaseForecaster
from forecasting.core.config import ForecastConfig


class BassDiffusionForecaster(BaseForecaster):
    """
    Bass Diffusion Model for forecasting new product adoption.
    
    The Bass model describes the adoption of new products through two mechanisms:
    - Innovation (p): Adoption by innovators (independent of others)
    - Imitation (q): Adoption by imitators (influenced by adopters)
    
    The model follows: f(t) = (p + q*F(t)) * (m - N(t))
    Where:
    - f(t) = adoptions at time t
    - F(t) = cumulative adoption rate
    - N(t) = cumulative adoptions
    - m = market potential
    
    Best suited for:
    - New product launches
    - Technology adoption forecasting
    - Market penetration analysis
    
    Parameters
    ----------
    p : float, optional
        Coefficient of innovation (0 < p < 1)
    q : float, optional
        Coefficient of imitation (0 < q < 1)
    m : float, optional
        Market potential (total addressable market)
    
    Attributes
    ----------
    p_ : float
        Fitted innovation coefficient
    q_ : float
        Fitted imitation coefficient
    m_ : float
        Fitted market potential
    
    Examples
    --------
    >>> import numpy as np
    >>> from forecasting.models.new_product import BassDiffusionForecaster
    >>> 
    >>> # Early adoption data
    >>> time = np.array([1, 2, 3, 4, 5])
    >>> adoptions = np.array([10, 25, 50, 80, 100])
    >>> 
    >>> # Fit Bass model
    >>> model = BassDiffusionForecaster()
    >>> model.fit(adoptions)
    >>> 
    >>> # Forecast future adoptions
    >>> forecast = model.predict(steps=10)
    >>> 
    >>> # Get model parameters
    >>> params = model.get_params()
    >>> print(f"Innovation (p): {params['p']:.4f}")
    >>> print(f"Imitation (q): {params['q']:.4f}")
    >>> print(f"Market potential (m): {params['m']:.0f}")
    """
    
    def __init__(
        self,
        config: Optional[ForecastConfig] = None,
        p: Optional[float] = None,
        q: Optional[float] = None,
        m: Optional[float] = None
    ):
        """Initialize Bass Diffusion forecaster."""
        super().__init__(config or ForecastConfig())
        
        self.p = p
        self.q = q
        self.m = m
        
        # Fitted parameters
        self.p_: Optional[float] = None
        self.q_: Optional[float] = None
        self.m_: Optional[float] = None
        self.cumulative_adoptions_: Optional[np.ndarray] = None
        
    def fit(
        self,
        y: np.ndarray,
        initial_guess: Optional[Tuple[float, float, float]] = None
    ) -> 'BassDiffusionForecaster':
        """
        Fit Bass Diffusion model to adoption data.
        
        Parameters
        ----------
        y : np.ndarray
            Historical adoption data (can be cumulative or per-period)
        initial_guess : Tuple[float, float, float], optional
            Initial guess for (p, q, m). If None, uses defaults.
            
        Returns
        -------
        self : BassDiffusionForecaster
            Fitted model
        """
        y = np.array(y)
        
        # Check if data is cumulative or per-period
        if np.all(np.diff(y) >= 0):
            # Data is cumulative
            cumulative = y
        else:
            # Data is per-period, convert to cumulative
            cumulative = np.cumsum(y)
        
        self.cumulative_adoptions_ = cumulative
        
        # Time points
        t = np.arange(1, len(cumulative) + 1)
        
        # If parameters are provided, use them
        if self.p is not None and self.q is not None and self.m is not None:
            self.p_ = self.p
            self.q_ = self.q
            self.m_ = self.m
        else:
            # Estimate parameters using curve fitting
            if initial_guess is None:
                # Default initial guess
                p_init = 0.03  # Typical innovation coefficient
                q_init = 0.38  # Typical imitation coefficient
                m_init = cumulative[-1] * 2  # Estimate market potential
                initial_guess = (p_init, q_init, m_init)
            
            try:
                # Fit Bass model
                params, _ = curve_fit(
                    self._bass_cumulative,
                    t,
                    cumulative,
                    p0=initial_guess,
                    bounds=([0, 0, cumulative[-1]], [1, 5, np.inf]),
                    maxfev=10000
                )
                self.p_, self.q_, self.m_ = params
            except Exception as e:
                # Fallback to initial guess if fitting fails
                print(f"Warning: Curve fitting failed ({e}). Using initial guess.")
                self.p_, self.q_, self.m_ = initial_guess
        
        self.is_fitted = True
        return self
    
    def _bass_cumulative(self, t: np.ndarray, p: float, q: float, m: float) -> np.ndarray:
        """
        Bass model for cumulative adoptions.
        
        F(t) = m * (1 - exp(-(p+q)*t)) / (1 + (q/p)*exp(-(p+q)*t))
        """
        numerator = 1 - np.exp(-(p + q) * t)
        denominator = 1 + (q / p) * np.exp(-(p + q) * t)
        return m * (numerator / denominator)
    
    def _bass_incremental(self, t: np.ndarray, p: float, q: float, m: float) -> np.ndarray:
        """
        Bass model for incremental adoptions.
        
        f(t) = m * (p + q)^2 / p * exp(-(p+q)*t) / (1 + (q/p)*exp(-(p+q)*t))^2
        """
        exp_term = np.exp(-(p + q) * t)
        numerator = m * ((p + q) ** 2) / p * exp_term
        denominator = (1 + (q / p) * exp_term) ** 2
        return numerator / denominator
    
    def predict(
        self,
        steps: int = 1,
        return_cumulative: bool = False
    ) -> np.ndarray:
        """
        Generate forecast using Bass Diffusion model.
        
        Parameters
        ----------
        steps : int, default=1
            Number of periods to forecast
        return_cumulative : bool, default=False
            If True, returns cumulative adoptions. Otherwise, returns per-period.
            
        Returns
        -------
        forecast : np.ndarray
            Forecasted adoptions
        """
        if not self.is_fitted:
            raise ValueError("Model must be fitted before prediction")
        
        # Current time period
        current_t = len(self.cumulative_adoptions_)
        
        # Future time periods
        future_t = np.arange(current_t + 1, current_t + steps + 1)
        
        # Forecast cumulative adoptions
        cumulative_forecast = self._bass_cumulative(future_t, self.p_, self.q_, self.m_)
        
        if return_cumulative:
            return cumulative_forecast
        else:
            # Convert to per-period adoptions
            # Add last observed value for differencing
            full_cumulative = np.concatenate([
                [self.cumulative_adoptions_[-1]],
                cumulative_forecast
            ])
            incremental_forecast = np.diff(full_cumulative)
            return incremental_forecast
    
    def predict_peak(self) -> Tuple[float, float]:
        """
        Predict when peak adoption will occur.
        
        Returns
        -------
        peak_time : float
            Time period when peak adoption occurs
        peak_value : float
            Peak adoption value
        """
        if not self.is_fitted:
            raise ValueError("Model must be fitted before prediction")
        
        # Peak occurs at t* = ln(q/p) / (p + q)
        peak_time = np.log(self.q_ / self.p_) / (self.p_ + self.q_)
        
        # Peak value
        peak_value = self._bass_incremental(
            np.array([peak_time]),
            self.p_,
            self.q_,
            self.m_
        )[0]
        
        return peak_time, peak_value
    
    def get_adoption_curve(self, periods: int = 100) -> Tuple[np.ndarray, np.ndarray]:
        """
        Get the full adoption curve.
        
        Parameters
        ----------
        periods : int, default=100
            Number of periods to generate
            
        Returns
        -------
        time : np.ndarray
            Time periods
        adoptions : np.ndarray
            Adoption values
        """
        if not self.is_fitted:
            raise ValueError("Model must be fitted before generating curve")
        
        time = np.arange(1, periods + 1)
        adoptions = self._bass_incremental(time, self.p_, self.q_, self.m_)
        
        return time, adoptions
    
    def get_params(self) -> dict:
        """Get model parameters."""
        params = {
            'p_initial': self.p,
            'q_initial': self.q,
            'm_initial': self.m
        }
        
        if self.is_fitted:
            params.update({
                'p': self.p_,
                'q': self.q_,
                'm': self.m_,
                'innovation_ratio': self.p_ / (self.p_ + self.q_),
                'imitation_ratio': self.q_ / (self.p_ + self.q_)
            })
            
            # Add peak information
            try:
                peak_time, peak_value = self.predict_peak()
                params.update({
                    'peak_time': peak_time,
                    'peak_value': peak_value
                })
            except:
                pass
        
        return params

# Made with Bob
