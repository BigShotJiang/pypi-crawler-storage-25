"""LSTM-based deep learning forecasting models."""

import pickle
from typing import Any, Dict, Optional, Tuple

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset

from forecasting.core.base import BaseForecaster
from forecasting.core.config import ForecastConfig
from forecasting.core.exceptions import ModelError
from forecasting.utils.helpers import create_date_range, get_frequency, set_random_seed


class LSTMNetwork(nn.Module):
    """LSTM neural network with attention mechanism.
    
    Implements a multi-layer LSTM with optional attention mechanism
    for time series forecasting.
    """
    
    def __init__(
        self,
        input_size: int,
        hidden_size: int,
        num_layers: int,
        output_size: int,
        dropout: float = 0.2,
        use_attention: bool = True,
    ):
        """Initialize LSTM network.
        
        Args:
            input_size: Number of input features
            hidden_size: Number of hidden units
            num_layers: Number of LSTM layers
            output_size: Number of output features
            dropout: Dropout rate
            use_attention: Whether to use attention mechanism
        """
        super(LSTMNetwork, self).__init__()
        
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.use_attention = use_attention
        
        # LSTM layers
        self.lstm = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            dropout=dropout if num_layers > 1 else 0,
            batch_first=True,
        )
        
        # Attention mechanism
        if use_attention:
            self.attention = nn.Linear(hidden_size, 1)
        
        # Output layer
        self.fc = nn.Linear(hidden_size, output_size)
        self.dropout = nn.Dropout(dropout)
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward pass.
        
        Args:
            x: Input tensor of shape (batch, seq_len, input_size)
            
        Returns:
            Output tensor of shape (batch, output_size)
        """
        # LSTM forward pass
        lstm_out, _ = self.lstm(x)  # (batch, seq_len, hidden_size)
        
        if self.use_attention:
            # Attention mechanism
            attention_weights = torch.softmax(
                self.attention(lstm_out).squeeze(-1), dim=1
            )  # (batch, seq_len)
            
            # Apply attention weights
            context = torch.sum(
                attention_weights.unsqueeze(-1) * lstm_out, dim=1
            )  # (batch, hidden_size)
        else:
            # Use last hidden state
            context = lstm_out[:, -1, :]  # (batch, hidden_size)
        
        # Apply dropout and output layer
        context = self.dropout(context)
        output = self.fc(context)  # (batch, output_size)
        
        return output


class LSTMForecaster(BaseForecaster):
    """LSTM-based forecaster with attention mechanism.
    
    Deep learning forecaster using LSTM networks for time series prediction.
    Supports multivariate inputs and attention mechanisms.
    
    Attributes:
        lookback: Number of past time steps to use
        hidden_size: Number of LSTM hidden units
        num_layers: Number of LSTM layers
        dropout: Dropout rate
        use_attention: Whether to use attention mechanism
        learning_rate: Learning rate for optimizer
        batch_size: Batch size for training
        epochs: Number of training epochs
    """
    
    def __init__(
        self,
        config: ForecastConfig,
        lookback: int = 30,
        hidden_size: int = 64,
        num_layers: int = 2,
        dropout: float = 0.2,
        use_attention: bool = True,
        learning_rate: float = 0.001,
        batch_size: int = 32,
        epochs: int = 100,
        early_stopping_patience: int = 10,
        device: Optional[str] = None,
    ):
        """Initialize LSTM forecaster.
        
        Args:
            config: Forecast configuration
            lookback: Number of past time steps to use
            hidden_size: Number of LSTM hidden units
            num_layers: Number of LSTM layers
            dropout: Dropout rate
            use_attention: Whether to use attention mechanism
            learning_rate: Learning rate
            batch_size: Batch size for training
            epochs: Number of training epochs
            early_stopping_patience: Patience for early stopping
            device: Device to use ('cuda', 'cpu', or None for auto)
        """
        super().__init__(config)
        self.lookback = lookback
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.dropout = dropout
        self.use_attention = use_attention
        self.learning_rate = learning_rate
        self.batch_size = batch_size
        self.epochs = epochs
        self.early_stopping_patience = early_stopping_patience
        
        # Set device
        if device is None:
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        else:
            self.device = torch.device(device)
        
        self._freq: Optional[str] = None
        self._scaler_mean: Optional[float] = None
        self._scaler_std: Optional[float] = None
        self._input_size: Optional[int] = None
        self._training_history: Dict[str, list] = {"train_loss": [], "val_loss": []}
        self._last_sequence: Optional[np.ndarray] = None
        self._training_data: Optional[np.ndarray] = None
    
    def _create_sequences(
        self,
        data: np.ndarray,
        lookback: int,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Create sequences for LSTM training.
        
        Args:
            data: Time series data
            lookback: Number of past time steps
            
        Returns:
            Tuple of (X, y) sequences
        """
        X, y = [], []
        for i in range(len(data) - lookback):
            X.append(data[i:i + lookback])
            y.append(data[i + lookback])
        return np.array(X), np.array(y)
    
    def fit(
        self,
        y: pd.Series,
        X: Optional[pd.DataFrame] = None,
        validation_split: float = 0.2,
        **kwargs: Any
    ) -> "LSTMForecaster":
        """Fit LSTM model.
        
        Args:
            y: Target time series
            X: Optional exogenous variables
            validation_split: Fraction of data for validation
            **kwargs: Additional training arguments
            
        Returns:
            Self for method chaining
        """
        try:
            self._validate_input(y, X)
            
            # Set random seed for reproducibility
            if self.config.random_seed is not None:
                set_random_seed(self.config.random_seed)
            
            # Store frequency
            if isinstance(y.index, pd.DatetimeIndex):
                self._freq = get_frequency(y)
            
            # Prepare data
            if X is not None:
                # Combine target and features
                data = np.column_stack([y.values.reshape(-1, 1), X.values])
                self._input_size = data.shape[1]
            else:
                data = y.values.reshape(-1, 1)
                self._input_size = 1
            
            # Normalize data
            self._scaler_mean = float(np.mean(data, axis=0)[0])
            self._scaler_std = float(np.std(data, axis=0)[0])
            data_normalized = (data - np.mean(data, axis=0)) / (np.std(data, axis=0) + 1e-8)
            
            # Store normalized training data for prediction
            self._training_data = data_normalized
            
            # Create sequences
            X_seq, y_seq = self._create_sequences(data_normalized, self.lookback)
            
            # Split into train and validation
            split_idx = int(len(X_seq) * (1 - validation_split))
            X_train, X_val = X_seq[:split_idx], X_seq[split_idx:]
            y_train, y_val = y_seq[:split_idx], y_seq[split_idx:]
            
            # Convert to tensors
            X_train_tensor = torch.FloatTensor(X_train).to(self.device)
            y_train_tensor = torch.FloatTensor(y_train[:, 0]).to(self.device)
            X_val_tensor = torch.FloatTensor(X_val).to(self.device)
            y_val_tensor = torch.FloatTensor(y_val[:, 0]).to(self.device)
            
            # Create data loaders
            train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
            train_loader = DataLoader(
                train_dataset,
                batch_size=self.batch_size,
                shuffle=True
            )
            
            # Initialize model
            self.model = LSTMNetwork(
                input_size=self._input_size,
                hidden_size=self.hidden_size,
                num_layers=self.num_layers,
                output_size=1,
                dropout=self.dropout,
                use_attention=self.use_attention,
            ).to(self.device)
            
            # Loss and optimizer
            criterion = nn.MSELoss()
            optimizer = torch.optim.Adam(
                self.model.parameters(),
                lr=self.learning_rate
            )
            
            # Training loop
            best_val_loss = float("inf")
            patience_counter = 0
            
            for epoch in range(self.epochs):
                # Training
                self.model.train()
                train_loss = 0.0
                for batch_X, batch_y in train_loader:
                    optimizer.zero_grad()
                    outputs = self.model(batch_X).squeeze()
                    loss = criterion(outputs, batch_y)
                    loss.backward()
                    optimizer.step()
                    train_loss += loss.item()
                
                train_loss /= len(train_loader)
                
                # Validation
                self.model.eval()
                with torch.no_grad():
                    val_outputs = self.model(X_val_tensor).squeeze()
                    val_loss = criterion(val_outputs, y_val_tensor).item()
                
                # Store history
                self._training_history["train_loss"].append(train_loss)
                self._training_history["val_loss"].append(val_loss)
                
                # Early stopping
                if val_loss < best_val_loss:
                    best_val_loss = val_loss
                    patience_counter = 0
                else:
                    patience_counter += 1
                    if patience_counter >= self.early_stopping_patience:
                        break
            
            self.is_fitted = True
            
            # Store validation metrics
            self._validation_metrics = {
                "final_train_loss": float(train_loss),
                "final_val_loss": float(val_loss),
                "best_val_loss": float(best_val_loss),
                "epochs_trained": len(self._training_history["train_loss"]),
            }
            
            return self
            
        except Exception as e:
            raise ModelError(f"Failed to fit LSTM model: {str(e)}")
    
    def predict(
        self,
        horizon: Optional[int] = None,
        X: Optional[pd.DataFrame] = None,
        return_conf_int: bool = True,
        **kwargs: Any
    ) -> Tuple[pd.Series, Optional[pd.DataFrame]]:
        """Generate LSTM forecasts.
        
        Args:
            horizon: Number of periods to forecast
            X: Optional exogenous variables for forecast period
            return_conf_int: Whether to return confidence intervals
            **kwargs: Additional prediction arguments
            
        Returns:
            Tuple of (predictions, confidence_intervals)
        """
        self._check_is_fitted()
        
        try:
            if horizon is None:
                horizon = self.config.horizon
            
            if self._training_data is None:
                raise ModelError("Training data not available for prediction")
            
            # Set model to evaluation mode
            self.model.eval()
            
            # Get last lookback sequence from training data
            current_sequence = self._training_data[-self.lookback:].copy()
            
            predictions = []
            
            # Recursive forecasting: predict one step at a time
            with torch.no_grad():
                for _ in range(horizon):
                    # Prepare input tensor
                    input_tensor = torch.FloatTensor(current_sequence).unsqueeze(0).to(self.device)
                    
                    # Generate prediction
                    pred = self.model(input_tensor).squeeze().cpu().numpy()
                    
                    # Store prediction
                    predictions.append(float(pred))
                    
                    # Update sequence for next prediction
                    if X is not None:
                        # If we have exogenous variables, we'd need them for future periods
                        # For now, we'll use zeros as placeholders
                        new_row = np.zeros(self._input_size)
                        new_row[0] = pred
                    else:
                        new_row = np.array([[pred]])
                    
                    # Shift sequence and add new prediction
                    current_sequence = np.vstack([current_sequence[1:], new_row])
            
            # Denormalize predictions
            predictions_array = np.array(predictions)
            predictions_denorm = predictions_array * self._scaler_std + self._scaler_mean
            
            # Create forecast index
            if self._freq is not None:
                # Create date range for forecast
                forecast_index = create_date_range(
                    start=pd.Timestamp.now(),  # This should be last training date + 1
                    periods=horizon,
                    freq=self._freq
                )
            else:
                forecast_index = pd.RangeIndex(start=0, stop=horizon)
            
            # Create forecast series
            forecast = pd.Series(
                predictions_denorm,
                index=forecast_index,
                name="forecast"
            )
            
            # Generate confidence intervals if requested
            conf_int = None
            if return_conf_int:
                # Simple confidence intervals based on training loss
                # In production, use Monte Carlo dropout or ensemble methods
                std_error = np.sqrt(self._validation_metrics.get("final_val_loss", 0.1))
                lower = predictions_denorm - 1.96 * std_error * self._scaler_std
                upper = predictions_denorm + 1.96 * std_error * self._scaler_std
                
                conf_int = pd.DataFrame({
                    "lower": lower,
                    "upper": upper
                }, index=forecast_index)
            
            return forecast, conf_int
            
        except Exception as e:
            raise ModelError(f"Failed to generate LSTM forecast: {str(e)}")
    
    def save_model(self, path: str) -> None:
        """Save LSTM model to disk.
        
        Args:
            path: Path to save the model
        """
        if not self.is_fitted:
            raise ModelError("Cannot save unfitted model")
        
        try:
            model_data = {
                "model_state_dict": self.model.state_dict(),
                "config": self.config,
                "lookback": self.lookback,
                "hidden_size": self.hidden_size,
                "num_layers": self.num_layers,
                "dropout": self.dropout,
                "use_attention": self.use_attention,
                "input_size": self._input_size,
                "scaler_mean": self._scaler_mean,
                "scaler_std": self._scaler_std,
                "freq": self._freq,
                "validation_metrics": self._validation_metrics,
                "training_history": self._training_history,
            }
            
            with open(path, "wb") as f:
                pickle.dump(model_data, f)
                
        except Exception as e:
            raise ModelError(f"Failed to save model: {str(e)}")
    
    @classmethod
    def load_model(cls, path: str) -> "LSTMForecaster":
        """Load LSTM model from disk.
        
        Args:
            path: Path to load the model from
            
        Returns:
            Loaded LSTMForecaster instance
        """
        try:
            with open(path, "rb") as f:
                model_data = pickle.load(f)
            
            forecaster = cls(
                config=model_data["config"],
                lookback=model_data["lookback"],
                hidden_size=model_data["hidden_size"],
                num_layers=model_data["num_layers"],
                dropout=model_data["dropout"],
                use_attention=model_data["use_attention"],
            )
            
            # Recreate model
            forecaster._input_size = model_data["input_size"]
            forecaster.model = LSTMNetwork(
                input_size=forecaster._input_size,
                hidden_size=forecaster.hidden_size,
                num_layers=forecaster.num_layers,
                output_size=1,
                dropout=forecaster.dropout,
                use_attention=forecaster.use_attention,
            ).to(forecaster.device)
            
            forecaster.model.load_state_dict(model_data["model_state_dict"])
            forecaster._scaler_mean = model_data["scaler_mean"]
            forecaster._scaler_std = model_data["scaler_std"]
            forecaster._freq = model_data["freq"]
            forecaster._validation_metrics = model_data["validation_metrics"]
            forecaster._training_history = model_data["training_history"]
            forecaster.is_fitted = True
            
            return forecaster
            
        except Exception as e:
            raise ModelError(f"Failed to load model: {str(e)}")
    
    def plot_training_history(self) -> Any:
        """Plot training history.
        
        Returns:
            Matplotlib figure
        """
        try:
            import matplotlib.pyplot as plt
            
            fig, ax = plt.subplots(figsize=(10, 6))
            ax.plot(self._training_history["train_loss"], label="Train Loss")
            ax.plot(self._training_history["val_loss"], label="Validation Loss")
            ax.set_xlabel("Epoch")
            ax.set_ylabel("Loss")
            ax.set_title("LSTM Training History")
            ax.legend()
            ax.grid(True)
            
            return fig
            
        except ImportError:
            raise ModelError(
                "matplotlib required for plotting. Install with: pip install matplotlib"
            )


# Made with Bob
