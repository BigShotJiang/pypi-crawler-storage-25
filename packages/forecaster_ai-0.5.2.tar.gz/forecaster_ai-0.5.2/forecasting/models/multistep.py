"""Multi-step forecasting strategies."""

from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd

from forecasting.core.base import BaseForecaster
from forecasting.core.config import ForecastConfig
from forecasting.core.exceptions import ModelError


class MultiStepForecaster(BaseForecaster):
    """Multi-step ahead forecasting with different strategies.
    
    Implements multiple strategies for multi-step forecasting:
    - Recursive: Use 1-step model recursively
    - Direct: Train separate model for each horizon
    - DirRec: Hybrid approach combining both
    - MIMO: Multiple input multiple output
    
    Examples
    --------
    >>> from forecasting.models.multistep import MultiStepForecaster
    >>> from forecasting.models import ARIMAForecaster
    >>> 
    >>> # Recursive strategy
    >>> model = MultiStepForecaster(
    ...     config,
    ...     base_forecaster_class=ARIMAForecaster,
    ...     strategy='recursive'
    ... )
    >>> model.fit(train_data)
    >>> forecast = model.predict(horizon=30)
    >>> 
    >>> # Direct strategy (separate model for each step)
    >>> model = MultiStepForecaster(
    ...     config,
    ...     strategy='direct'
    ... )
    >>> model.fit(train_data)
    >>> forecast = model.predict(horizon=30)
    """
    
    def __init__(
        self,
        config: ForecastConfig,
        base_forecaster_class: Optional[type] = None,
        strategy: str = 'recursive',
    ):
        """Initialize multi-step forecaster.
        
        Args:
            config: Forecast configuration
            base_forecaster_class: Base forecaster class to use
            strategy: Forecasting strategy ('recursive', 'direct', 'dirrec', 'mimo')
        """
        super().__init__(config)
        self.base_forecaster_class = base_forecaster_class
        self.strategy = strategy
        self.models: Dict[Union[int, str], BaseForecaster] = {}
        
        if strategy not in ['recursive', 'direct', 'dirrec', 'mimo']:
            raise ValueError(f"Unknown strategy: {strategy}")
    
    def fit(
        self,
        y: pd.Series,
        X: Optional[pd.DataFrame] = None,
        **kwargs: Any
    ) -> "MultiStepForecaster":
        """Fit multi-step forecaster.
        
        Args:
            y: Target time series
            X: Optional exogenous variables
            **kwargs: Additional arguments
            
        Returns:
            Self for method chaining
        """
        try:
            self._validate_input(y, X)
            
            # Initialize base forecaster class if not provided
            if self.base_forecaster_class is None:
                from forecasting.models import ARIMAForecaster
                self.base_forecaster_class = ARIMAForecaster
            
            if self.strategy == 'recursive':
                # Train single 1-step model
                model = self.base_forecaster_class(self.config)
                model.fit(y, X, **kwargs)
                self.models[1] = model
                
            elif self.strategy == 'direct':
                # Train separate model for each horizon
                horizon = self.config.horizon
                for h in range(1, horizon + 1):
                    # Create target shifted by h steps
                    y_shifted = y.shift(-h).dropna()
                    X_shifted = X.iloc[:len(y_shifted)] if X is not None else None
                    
                    model = self.base_forecaster_class(self.config)
                    model.fit(y_shifted, X_shifted, **kwargs)
                    self.models[h] = model
                    
            elif self.strategy == 'dirrec':
                # Hybrid: use direct for short horizons, recursive for long
                short_horizon = min(7, self.config.horizon)
                
                # Direct models for short horizon
                for h in range(1, short_horizon + 1):
                    y_shifted = y.shift(-h).dropna()
                    X_shifted = X.iloc[:len(y_shifted)] if X is not None else None
                    
                    model = self.base_forecaster_class(self.config)
                    model.fit(y_shifted, X_shifted, **kwargs)
                    self.models[h] = model
                
                # Recursive model for longer horizons
                model = self.base_forecaster_class(self.config)
                model.fit(y, X, **kwargs)
                self.models['recursive'] = model
                
            elif self.strategy == 'mimo':
                # Multiple input multiple output
                # Train single model that outputs all horizons
                model = self.base_forecaster_class(self.config)
                model.fit(y, X, **kwargs)
                self.models['mimo'] = model
            
            self.is_fitted = True
            return self
            
        except Exception as e:
            raise ModelError(f"Failed to fit multi-step forecaster: {str(e)}")
    
    def predict(
        self,
        horizon: Optional[int] = None,
        X: Optional[pd.DataFrame] = None,
        return_conf_int: bool = True,
        **kwargs: Any
    ) -> Tuple[pd.Series, Optional[pd.DataFrame]]:
        """Generate multi-step forecasts.
        
        Args:
            horizon: Number of periods to forecast
            X: Optional exogenous variables
            return_conf_int: Whether to return confidence intervals
            **kwargs: Additional arguments
            
        Returns:
            Tuple of (predictions, confidence_intervals)
        """
        self._check_is_fitted()
        
        if horizon is None:
            horizon = self.config.horizon
        
        if self.strategy == 'recursive':
            return self._predict_recursive(horizon, X, return_conf_int, **kwargs)
        elif self.strategy == 'direct':
            return self._predict_direct(horizon, X, return_conf_int, **kwargs)
        elif self.strategy == 'dirrec':
            return self._predict_dirrec(horizon, X, return_conf_int, **kwargs)
        elif self.strategy == 'mimo':
            return self._predict_mimo(horizon, X, return_conf_int, **kwargs)
        else:
            raise ValueError(f"Unknown strategy: {self.strategy}")
    
    def _predict_recursive(
        self,
        horizon: int,
        X: Optional[pd.DataFrame],
        return_conf_int: bool,
        **kwargs: Any
    ) -> Tuple[pd.Series, Optional[pd.DataFrame]]:
        """Recursive prediction strategy.
        
        Args:
            horizon: Forecast horizon
            X: Exogenous variables
            return_conf_int: Whether to return confidence intervals
            **kwargs: Additional arguments
            
        Returns:
            Tuple of (predictions, confidence_intervals)
        """
        model = self.models[1]
        forecast, conf_int = model.predict(
            horizon=horizon,
            X=X,
            return_conf_int=return_conf_int,
            **kwargs
        )
        
        # Store for plotting
        self._store_forecast(forecast, conf_int)
        
        return forecast, conf_int
    
    def _predict_direct(
        self,
        horizon: int,
        X: Optional[pd.DataFrame],
        return_conf_int: bool,
        **kwargs: Any
    ) -> Tuple[pd.Series, Optional[pd.DataFrame]]:
        """Direct prediction strategy.
        
        Args:
            horizon: Forecast horizon
            X: Exogenous variables
            return_conf_int: Whether to return confidence intervals
            **kwargs: Additional arguments
            
        Returns:
            Tuple of (predictions, confidence_intervals)
        """
        forecasts = []
        conf_ints = []
        
        for h in range(1, min(horizon + 1, len(self.models) + 1)):
            model = self.models[h]
            pred, ci = model.predict(
                horizon=1,
                X=X,
                return_conf_int=return_conf_int,
                **kwargs
            )
            forecasts.append(pred.iloc[0])
            if ci is not None:
                conf_ints.append(ci.iloc[0])
        
        # Combine forecasts
        forecast = pd.Series(forecasts, index=pd.RangeIndex(1, len(forecasts) + 1))
        
        if return_conf_int and conf_ints:
            conf_int = pd.DataFrame(conf_ints)
        else:
            conf_int = None
        
        # Store for plotting
        self._store_forecast(forecast, conf_int)
        
        return forecast, conf_int
    
    def _predict_dirrec(
        self,
        horizon: int,
        X: Optional[pd.DataFrame],
        return_conf_int: bool,
        **kwargs: Any
    ) -> Tuple[pd.Series, Optional[pd.DataFrame]]:
        """Hybrid direct-recursive prediction strategy.
        
        Args:
            horizon: Forecast horizon
            X: Exogenous variables
            return_conf_int: Whether to return confidence intervals
            **kwargs: Additional arguments
            
        Returns:
            Tuple of (predictions, confidence_intervals)
        """
        forecasts = []
        conf_ints = []
        
        # Use direct models for available horizons
        direct_horizon = len([k for k in self.models.keys() if isinstance(k, int)])
        
        for h in range(1, min(horizon + 1, direct_horizon + 1)):
            model = self.models[h]
            pred, ci = model.predict(
                horizon=1,
                X=X,
                return_conf_int=return_conf_int,
                **kwargs
            )
            forecasts.append(pred.iloc[0])
            if ci is not None:
                conf_ints.append(ci.iloc[0])
        
        # Use recursive for remaining horizons
        if horizon > direct_horizon:
            model = self.models['recursive']
            remaining_horizon = horizon - direct_horizon
            pred, ci = model.predict(
                horizon=remaining_horizon,
                X=X,
                return_conf_int=return_conf_int,
                **kwargs
            )
            forecasts.extend(pred.values)
            if ci is not None:
                conf_ints.extend(ci.values)
        
        # Combine forecasts
        forecast = pd.Series(forecasts, index=pd.RangeIndex(1, len(forecasts) + 1))
        
        if return_conf_int and conf_ints:
            conf_int = pd.DataFrame(conf_ints)
        else:
            conf_int = None
        
        # Store for plotting
        self._store_forecast(forecast, conf_int)
        
        return forecast, conf_int
    
    def _predict_mimo(
        self,
        horizon: int,
        X: Optional[pd.DataFrame],
        return_conf_int: bool,
        **kwargs: Any
    ) -> Tuple[pd.Series, Optional[pd.DataFrame]]:
        """MIMO prediction strategy.
        
        Args:
            horizon: Forecast horizon
            X: Exogenous variables
            return_conf_int: Whether to return confidence intervals
            **kwargs: Additional arguments
            
        Returns:
            Tuple of (predictions, confidence_intervals)
        """
        model = self.models['mimo']
        forecast, conf_int = model.predict(
            horizon=horizon,
            X=X,
            return_conf_int=return_conf_int,
            **kwargs
        )
        
        # Store for plotting
        self._store_forecast(forecast, conf_int)
        
        return forecast, conf_int


# Made with Bob