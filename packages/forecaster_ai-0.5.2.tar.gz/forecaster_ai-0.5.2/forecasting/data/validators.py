"""Data validation for time series forecasting."""

from typing import List, Optional, Tuple

import numpy as np
import pandas as pd
from pydantic import BaseModel, Field, field_validator

from forecasting.core.exceptions import DataValidationError


class TimeSeriesSchema(BaseModel):
    """Pydantic schema for time series data validation.
    
    Attributes:
        min_length: Minimum required length of time series
        max_missing_ratio: Maximum allowed ratio of missing values
        allow_negative: Whether negative values are allowed
        allow_zero: Whether zero values are allowed
        require_datetime_index: Whether datetime index is required
        min_value: Minimum allowed value
        max_value: Maximum allowed value
    """

    min_length: int = Field(default=10, ge=1)
    max_missing_ratio: float = Field(default=0.1, ge=0.0, le=1.0)
    allow_negative: bool = True
    allow_zero: bool = True
    require_datetime_index: bool = True
    min_value: Optional[float] = None
    max_value: Optional[float] = None

    @field_validator("max_missing_ratio")
    @classmethod
    def validate_ratio(cls, v: float) -> float:
        """Validate missing ratio is between 0 and 1."""
        if not 0 <= v <= 1:
            raise ValueError("max_missing_ratio must be between 0 and 1")
        return v


class TimeSeriesValidator:
    """Validator for time series data.
    
    Performs comprehensive validation including:
    - Length checks
    - Missing value detection
    - Outlier detection
    - Stationarity tests
    - Seasonality detection
    """

    def __init__(self, schema: Optional[TimeSeriesSchema] = None):
        """Initialize validator.
        
        Args:
            schema: Validation schema (uses default if None)
        """
        self.schema = schema or TimeSeriesSchema()

    def validate(
        self,
        data: pd.Series,
        raise_on_error: bool = True,
    ) -> Tuple[bool, List[str]]:
        """Validate time series data.
        
        Args:
            data: Time series to validate
            raise_on_error: Whether to raise exception on validation failure
            
        Returns:
            Tuple of (is_valid, error_messages)
            
        Raises:
            DataValidationError: If validation fails and raise_on_error is True
        """
        errors = []

        # Check length
        if len(data) < self.schema.min_length:
            errors.append(
                f"Time series too short: {len(data)} < {self.schema.min_length}"
            )

        # Check datetime index
        if self.schema.require_datetime_index:
            if not isinstance(data.index, pd.DatetimeIndex):
                errors.append("Time series must have DatetimeIndex")

        # Check missing values
        missing_ratio = data.isnull().sum() / len(data)
        if missing_ratio > self.schema.max_missing_ratio:
            errors.append(
                f"Too many missing values: {missing_ratio:.2%} > "
                f"{self.schema.max_missing_ratio:.2%}"
            )

        # Check for negative values
        if not self.schema.allow_negative and (data < 0).any():
            errors.append("Negative values not allowed")

        # Check for zero values
        if not self.schema.allow_zero and (data == 0).any():
            errors.append("Zero values not allowed")

        # Check value range
        if self.schema.min_value is not None:
            if (data < self.schema.min_value).any():
                errors.append(
                    f"Values below minimum: {self.schema.min_value}"
                )

        if self.schema.max_value is not None:
            if (data > self.schema.max_value).any():
                errors.append(
                    f"Values above maximum: {self.schema.max_value}"
                )

        is_valid = len(errors) == 0

        if not is_valid and raise_on_error:
            raise DataValidationError(
                f"Time series validation failed: {'; '.join(errors)}"
            )

        return is_valid, errors

    def detect_outliers(
        self,
        data: pd.Series,
        method: str = "iqr",
        threshold: float = 3.0,
    ) -> pd.Series:
        """Detect outliers in time series.
        
        Args:
            data: Time series data
            method: Detection method ('iqr', 'zscore', 'mad')
            threshold: Threshold for outlier detection
            
        Returns:
            Boolean series indicating outliers
            
        Raises:
            ValueError: If method is unknown
        """
        if method == "iqr":
            return self._detect_outliers_iqr(data, threshold)
        elif method == "zscore":
            return self._detect_outliers_zscore(data, threshold)
        elif method == "mad":
            return self._detect_outliers_mad(data, threshold)
        else:
            raise ValueError(f"Unknown outlier detection method: {method}")

    def _detect_outliers_iqr(
        self,
        data: pd.Series,
        threshold: float = 1.5,
    ) -> pd.Series:
        """Detect outliers using IQR method."""
        Q1 = data.quantile(0.25)
        Q3 = data.quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - threshold * IQR
        upper_bound = Q3 + threshold * IQR
        return (data < lower_bound) | (data > upper_bound)

    def _detect_outliers_zscore(
        self,
        data: pd.Series,
        threshold: float = 3.0,
    ) -> pd.Series:
        """Detect outliers using Z-score method."""
        z_scores = np.abs((data - data.mean()) / data.std())
        return z_scores > threshold

    def _detect_outliers_mad(
        self,
        data: pd.Series,
        threshold: float = 3.0,
    ) -> pd.Series:
        """Detect outliers using MAD (Median Absolute Deviation) method."""
        median = data.median()
        mad = np.median(np.abs(data - median))
        modified_z_scores = 0.6745 * (data - median) / mad
        return np.abs(modified_z_scores) > threshold

    def check_stationarity(
        self,
        data: pd.Series,
        significance_level: float = 0.05,
    ) -> Tuple[bool, float]:
        """Check if time series is stationary using ADF test.
        
        Args:
            data: Time series data
            significance_level: Significance level for test
            
        Returns:
            Tuple of (is_stationary, p_value)
        """
        from statsmodels.tsa.stattools import adfuller

        result = adfuller(data.dropna())
        p_value = result[1]
        is_stationary = p_value < significance_level

        return is_stationary, p_value

    def detect_seasonality(
        self,
        data: pd.Series,
        max_lag: Optional[int] = None,
    ) -> Tuple[bool, Optional[int]]:
        """Detect seasonality in time series.
        
        Args:
            data: Time series data
            max_lag: Maximum lag to check (default: len(data) // 2)
            
        Returns:
            Tuple of (has_seasonality, seasonal_period)
        """
        if max_lag is None:
            max_lag = min(len(data) // 2, 365)

        from statsmodels.tsa.stattools import acf

        acf_values = acf(data.dropna(), nlags=max_lag, fft=True)

        # Find peaks in ACF
        threshold = 1.96 / np.sqrt(len(data))  # 95% confidence
        significant_lags = np.where(np.abs(acf_values[1:]) > threshold)[0] + 1

        if len(significant_lags) > 0:
            # Return the first significant lag as seasonal period
            return True, int(significant_lags[0])

        return False, None

    def validate_exogenous(
        self,
        X: pd.DataFrame,
        y: pd.Series,
    ) -> Tuple[bool, List[str]]:
        """Validate exogenous variables.
        
        Args:
            X: Exogenous variables
            y: Target time series
            
        Returns:
            Tuple of (is_valid, error_messages)
        """
        errors = []

        # Check length match
        if len(X) != len(y):
            errors.append(
                f"Length mismatch: X has {len(X)} rows, y has {len(y)}"
            )

        # Check for missing values
        if X.isnull().any().any():
            missing_cols = X.columns[X.isnull().any()].tolist()
            errors.append(
                f"Missing values in columns: {missing_cols}"
            )

        # Check for constant columns
        constant_cols = [col for col in X.columns if X[col].nunique() == 1]
        if constant_cols:
            errors.append(
                f"Constant columns (no variance): {constant_cols}"
            )

        # Check for high correlation
        if len(X.columns) > 1:
            corr_matrix = X.corr().abs()
            high_corr = np.where(
                (corr_matrix > 0.95) & (corr_matrix < 1.0)
            )
            if len(high_corr[0]) > 0:
                errors.append(
                    "High correlation detected between features (>0.95)"
                )

        return len(errors) == 0, errors

# Made with Bob
