"""Sample datasets for testing and demonstrations.

This module provides realistic sample datasets that can be used to test
all forecasting models and features. Datasets include exogenous variables
and various patterns (trend, seasonality, intermittency).
"""

import numpy as np
import pandas as pd
from typing import Tuple, Dict
from datetime import datetime, timedelta


def load_retail_sales(
    n_periods: int = 365,
    include_exog: bool = True,
    seed: int = 42
) -> Tuple[pd.Series, pd.DataFrame]:
    """Load retail sales dataset with exogenous variables.
    
    Simulates daily retail sales with:
    - Weekly seasonality (higher on weekends)
    - Monthly seasonality (higher at month end)
    - Trend (growing over time)
    - Price sensitivity
    - Promotion effects
    - Holiday effects
    
    Args:
        n_periods: Number of days to generate
        include_exog: Whether to include exogenous variables
        seed: Random seed for reproducibility
        
    Returns:
        Tuple of (sales_series, exog_dataframe)
        
    Example:
        >>> from forecasting.data.sample_data import load_retail_sales
        >>> sales, exog = load_retail_sales(n_periods=365)
        >>> print(f"Sales shape: {sales.shape}")
        >>> print(f"Exogenous variables: {list(exog.columns)}")
    """
    np.random.seed(seed)
    
    # Create date range
    start_date = datetime(2023, 1, 1)
    dates = pd.date_range(start_date, periods=n_periods, freq='D')
    
    # Base demand
    base_demand = 1000
    
    # Trend component (growing 20% per year)
    trend = np.arange(n_periods) * (0.20 * base_demand / 365)
    
    # Weekly seasonality (higher on weekends)
    day_of_week = dates.dayofweek
    weekly_pattern = np.where(day_of_week >= 5, 1.3, 1.0)  # 30% higher on weekends
    
    # Monthly seasonality (higher at month end)
    day_of_month = dates.day
    monthly_pattern = np.where(day_of_month >= 25, 1.2, 1.0)  # 20% higher at month end
    
    # Generate exogenous variables
    if include_exog:
        # Price (varies between 90-110)
        price = 100 + np.random.randn(n_periods) * 5
        price = np.clip(price, 90, 110)
        
        # Promotions (20% of days)
        promotion = np.random.binomial(1, 0.2, n_periods)
        
        # Competitor price
        competitor_price = 105 + np.random.randn(n_periods) * 5
        competitor_price = np.clip(competitor_price, 95, 115)
        
        # Temperature (affects sales)
        day_of_year = dates.dayofyear
        temperature = 15 + 10 * np.sin(2 * np.pi * day_of_year / 365) + np.random.randn(n_periods) * 3
        
        # Marketing spend (varies by week)
        marketing_spend = 5000 + np.random.randn(n_periods) * 1000
        marketing_spend = np.clip(marketing_spend, 3000, 7000)
        
        # Calculate effects
        price_effect = 1 - (price - 100) * 0.01  # 1% decrease per dollar increase
        promotion_effect = 1 + promotion * 0.5  # 50% increase during promotions
        competitor_effect = 1 + (competitor_price - 105) * 0.005  # Benefit from competitor high prices
        temperature_effect = 1 + (temperature - 15) * 0.01  # 1% increase per degree
        marketing_effect = 1 + (marketing_spend - 5000) * 0.00005  # Small marketing effect
        
        # Combine all effects
        sales = (
            base_demand +
            trend +
            base_demand * (weekly_pattern - 1) +
            base_demand * (monthly_pattern - 1)
        ) * price_effect * promotion_effect * competitor_effect * temperature_effect * marketing_effect
        
        # Add noise
        noise = np.random.randn(n_periods) * 50
        sales = sales + noise
        
        # Ensure non-negative
        sales = np.maximum(sales, 0)
        
        # Create exogenous dataframe
        exog = pd.DataFrame({
            'price': price,
            'promotion': promotion,
            'competitor_price': competitor_price,
            'temperature': temperature,
            'marketing_spend': marketing_spend,
            'day_of_week': day_of_week,
            'day_of_month': day_of_month,
            'is_weekend': (day_of_week >= 5).astype(int),
            'is_month_end': (day_of_month >= 25).astype(int)
        }, index=dates)
        
    else:
        # Without exogenous variables, use simpler model
        sales = (
            base_demand +
            trend +
            base_demand * (weekly_pattern - 1) +
            base_demand * (monthly_pattern - 1) +
            np.random.randn(n_periods) * 50
        )
        sales = np.maximum(sales, 0)
        exog = None
    
    # Create series
    sales_series = pd.Series(sales, index=dates, name='sales')
    
    return sales_series, exog


def load_intermittent_demand(
    n_periods: int = 365,
    zero_ratio: float = 0.4,
    seed: int = 42
) -> pd.Series:
    """Load intermittent demand dataset (e.g., spare parts).
    
    Simulates intermittent demand with:
    - High proportion of zero values
    - Occasional large spikes
    - No clear seasonality
    
    Args:
        n_periods: Number of periods to generate
        zero_ratio: Proportion of zero values (0-1)
        seed: Random seed
        
    Returns:
        Series with intermittent demand
        
    Example:
        >>> from forecasting.data.sample_data import load_intermittent_demand
        >>> demand = load_intermittent_demand(n_periods=365, zero_ratio=0.4)
        >>> print(f"Zero ratio: {(demand == 0).mean():.2%}")
    """
    np.random.seed(seed)
    
    dates = pd.date_range('2023-01-01', periods=n_periods, freq='D')
    
    # Generate demand events (Bernoulli process)
    demand_occurs = np.random.binomial(1, 1 - zero_ratio, n_periods)
    
    # When demand occurs, generate quantity (Poisson-like)
    demand_quantity = np.random.gamma(2, 3, n_periods)  # Mean ~6, variance ~18
    
    # Combine
    demand = demand_occurs * demand_quantity
    
    return pd.Series(demand, index=dates, name='demand')


def load_hierarchical_sales(
    n_periods: int = 365,
    seed: int = 42
) -> Dict[str, pd.Series]:
    """Load hierarchical sales dataset.
    
    Simulates sales across a hierarchy:
    - Total company sales
    - 2 regions (North, South)
    - 4 stores (2 per region)
    
    Args:
        n_periods: Number of periods
        seed: Random seed
        
    Returns:
        Dictionary mapping level names to series
        
    Example:
        >>> from forecasting.data.sample_data import load_hierarchical_sales
        >>> data = load_hierarchical_sales(n_periods=365)
        >>> print(f"Levels: {list(data.keys())}")
        >>> # Verify hierarchy: total = north + south
        >>> assert np.allclose(data['total'], data['north'] + data['south'])
    """
    np.random.seed(seed)
    
    dates = pd.date_range('2023-01-01', periods=n_periods, freq='D')
    
    # Generate bottom level (stores)
    stores = {}
    
    # North region stores
    stores['store_n1'] = _generate_store_sales(n_periods, base=300, seed=seed)
    stores['store_n2'] = _generate_store_sales(n_periods, base=250, seed=seed+1)
    
    # South region stores
    stores['store_s1'] = _generate_store_sales(n_periods, base=280, seed=seed+2)
    stores['store_s2'] = _generate_store_sales(n_periods, base=220, seed=seed+3)
    
    # Aggregate to regions
    north = stores['store_n1'] + stores['store_n2']
    south = stores['store_s1'] + stores['store_s2']
    
    # Aggregate to total
    total = north + south
    
    # Create dictionary
    data = {
        'total': pd.Series(total, index=dates, name='total'),
        'north': pd.Series(north, index=dates, name='north'),
        'south': pd.Series(south, index=dates, name='south'),
        'store_n1': pd.Series(stores['store_n1'], index=dates, name='store_n1'),
        'store_n2': pd.Series(stores['store_n2'], index=dates, name='store_n2'),
        'store_s1': pd.Series(stores['store_s1'], index=dates, name='store_s1'),
        'store_s2': pd.Series(stores['store_s2'], index=dates, name='store_s2')
    }
    
    return data


def load_multivariate_data(
    n_periods: int = 365,
    n_series: int = 5,
    seed: int = 42
) -> pd.DataFrame:
    """Load multivariate time series dataset.
    
    Simulates multiple related time series with:
    - Cross-correlations
    - Common trends
    - Individual seasonality
    
    Args:
        n_periods: Number of periods
        n_series: Number of time series
        seed: Random seed
        
    Returns:
        DataFrame with multiple time series
        
    Example:
        >>> from forecasting.data.sample_data import load_multivariate_data
        >>> data = load_multivariate_data(n_periods=365, n_series=5)
        >>> print(f"Shape: {data.shape}")
        >>> print(f"Series: {list(data.columns)}")
    """
    np.random.seed(seed)
    
    dates = pd.date_range('2023-01-01', periods=n_periods, freq='D')
    
    # Common trend
    common_trend = np.arange(n_periods) * 0.5
    
    # Generate correlated series
    data = {}
    for i in range(n_series):
        # Individual trend
        individual_trend = np.arange(n_periods) * np.random.uniform(0.1, 0.5)
        
        # Seasonality
        seasonality = 20 * np.sin(2 * np.pi * np.arange(n_periods) / 7)
        
        # Combine
        series = 100 + common_trend + individual_trend + seasonality + np.random.randn(n_periods) * 10
        
        data[f'series_{i+1}'] = series
    
    return pd.DataFrame(data, index=dates)


def _generate_store_sales(n_periods: int, base: float, seed: int) -> np.ndarray:
    """Helper function to generate store-level sales."""
    np.random.seed(seed)
    
    # Trend
    trend = np.arange(n_periods) * (0.15 * base / 365)
    
    # Weekly seasonality
    weekly = 0.2 * base * np.sin(2 * np.pi * np.arange(n_periods) / 7)
    
    # Noise
    noise = np.random.randn(n_periods) * (0.1 * base)
    
    sales = base + trend + weekly + noise
    return np.maximum(sales, 0)


def get_sample_datasets() -> Dict[str, str]:
    """Get information about available sample datasets.
    
    Returns:
        Dictionary mapping dataset names to descriptions
        
    Example:
        >>> from forecasting.data.sample_data import get_sample_datasets
        >>> datasets = get_sample_datasets()
        >>> for name, desc in datasets.items():
        ...     print(f"{name}: {desc}")
    """
    return {
        'retail_sales': 'Daily retail sales with exogenous variables (price, promotions, etc.)',
        'intermittent_demand': 'Intermittent demand pattern (e.g., spare parts)',
        'hierarchical_sales': 'Hierarchical sales data (total -> regions -> stores)',
        'multivariate_data': 'Multiple correlated time series'
    }


# Convenience function to load all datasets
def load_all_samples(n_periods: int = 365) -> Dict[str, any]:
    """Load all sample datasets.
    
    Args:
        n_periods: Number of periods for each dataset
        
    Returns:
        Dictionary with all sample datasets
        
    Example:
        >>> from forecasting.data.sample_data import load_all_samples
        >>> samples = load_all_samples(n_periods=365)
        >>> print(f"Available datasets: {list(samples.keys())}")
    """
    sales, exog = load_retail_sales(n_periods=n_periods)
    
    return {
        'retail_sales': sales,
        'retail_exog': exog,
        'intermittent_demand': load_intermittent_demand(n_periods=n_periods),
        'hierarchical_sales': load_hierarchical_sales(n_periods=n_periods),
        'multivariate_data': load_multivariate_data(n_periods=n_periods)
    }


# Made with Bob