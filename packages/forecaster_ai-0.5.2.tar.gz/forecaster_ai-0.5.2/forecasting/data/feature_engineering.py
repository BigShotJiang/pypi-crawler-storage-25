"""Feature engineering for time series forecasting."""

from typing import Dict, List, Optional, Union

import numpy as np
import pandas as pd
from scipy import signal

from forecasting.core.exceptions import PreprocessingError
from forecasting.utils.helpers import ensure_datetime_index


class FeatureEngineer:
    """Feature engineering for time series forecasting.
    
    Creates various features from time series data including:
    - Temporal features (hour, day, month, etc.)
    - Lag features
    - Rolling statistics
    - Fourier features for seasonality
    - Interaction features
    - Calendar features (holidays, weekends)
    """
    
    def __init__(
        self,
        lag_features: Optional[List[int]] = None,
        rolling_windows: Optional[List[int]] = None,
        rolling_functions: Optional[List[str]] = None,
        temporal_features: bool = True,
        fourier_order: Optional[int] = None,
        interaction_features: bool = False,
        calendar_features: bool = True,
    ):
        """Initialize feature engineer.
        
        Args:
            lag_features: List of lag values to create (e.g., [1, 7, 30])
            rolling_windows: List of window sizes for rolling features
            rolling_functions: List of functions for rolling features
            temporal_features: Whether to create temporal features
            fourier_order: Order of Fourier features for seasonality
            interaction_features: Whether to create interaction features
            calendar_features: Whether to create calendar features
        """
        self.lag_features = lag_features or []
        self.rolling_windows = rolling_windows or []
        self.rolling_functions = rolling_functions or ["mean", "std"]
        self.temporal_features = temporal_features
        self.fourier_order = fourier_order
        self.interaction_features = interaction_features
        self.calendar_features = calendar_features
        
        self.feature_names: List[str] = []
    
    def create_features(
        self,
        data: pd.Series,
        exog: Optional[pd.DataFrame] = None,
    ) -> pd.DataFrame:
        """Create all features from time series.
        
        Args:
            data: Time series data
            exog: Optional exogenous variables
            
        Returns:
            DataFrame with all engineered features
            
        Raises:
            PreprocessingError: If feature creation fails
        """
        try:
            # Ensure datetime index
            if not isinstance(data.index, pd.DatetimeIndex):
                raise PreprocessingError("Data must have DatetimeIndex")
            
            features = pd.DataFrame(index=data.index)
            
            # 1. Lag features
            if self.lag_features:
                lag_df = self._create_lag_features(data)
                features = pd.concat([features, lag_df], axis=1)
            
            # 2. Rolling features
            if self.rolling_windows:
                rolling_df = self._create_rolling_features(data)
                features = pd.concat([features, rolling_df], axis=1)
            
            # 3. Temporal features
            if self.temporal_features:
                temporal_df = self._create_temporal_features(data.index)
                features = pd.concat([features, temporal_df], axis=1)
            
            # 4. Fourier features
            if self.fourier_order is not None:
                fourier_df = self._create_fourier_features(data.index)
                features = pd.concat([features, fourier_df], axis=1)
            
            # 5. Calendar features
            if self.calendar_features:
                calendar_df = self._create_calendar_features(data.index)
                features = pd.concat([features, calendar_df], axis=1)
            
            # 6. Add exogenous variables
            if exog is not None:
                features = pd.concat([features, exog], axis=1)
            
            # 7. Interaction features
            if self.interaction_features and len(features.columns) > 1:
                interaction_df = self._create_interaction_features(features)
                features = pd.concat([features, interaction_df], axis=1)
            
            # Store feature names
            self.feature_names = features.columns.tolist()
            
            return features
            
        except Exception as e:
            raise PreprocessingError(f"Failed to create features: {str(e)}")
    
    def _create_lag_features(self, data: pd.Series) -> pd.DataFrame:
        """Create lagged features.
        
        Args:
            data: Time series data
            
        Returns:
            DataFrame with lag features
        """
        features = pd.DataFrame(index=data.index)
        
        for lag in self.lag_features:
            features[f"lag_{lag}"] = data.shift(lag)
        
        return features
    
    def _create_rolling_features(self, data: pd.Series) -> pd.DataFrame:
        """Create rolling window features.
        
        Args:
            data: Time series data
            
        Returns:
            DataFrame with rolling features
        """
        features = pd.DataFrame(index=data.index)
        
        for window in self.rolling_windows:
            for func in self.rolling_functions:
                if func == "mean":
                    features[f"rolling_{window}_mean"] = data.rolling(window).mean()
                elif func == "std":
                    features[f"rolling_{window}_std"] = data.rolling(window).std()
                elif func == "min":
                    features[f"rolling_{window}_min"] = data.rolling(window).min()
                elif func == "max":
                    features[f"rolling_{window}_max"] = data.rolling(window).max()
                elif func == "median":
                    features[f"rolling_{window}_median"] = data.rolling(window).median()
                elif func == "skew":
                    features[f"rolling_{window}_skew"] = data.rolling(window).skew()
                elif func == "kurt":
                    features[f"rolling_{window}_kurt"] = data.rolling(window).kurt()
        
        return features
    
    def _create_temporal_features(self, index: pd.DatetimeIndex) -> pd.DataFrame:
        """Create temporal features from datetime index.
        
        Args:
            index: DatetimeIndex
            
        Returns:
            DataFrame with temporal features
        """
        features = pd.DataFrame(index=index)
        
        # Basic temporal features
        features["hour"] = index.hour
        features["day"] = index.day
        features["dayofweek"] = index.dayofweek
        features["dayofyear"] = index.dayofyear
        features["week"] = index.isocalendar().week
        features["month"] = index.month
        features["quarter"] = index.quarter
        features["year"] = index.year
        
        # Cyclical encoding for periodic features
        features["hour_sin"] = np.sin(2 * np.pi * index.hour / 24)
        features["hour_cos"] = np.cos(2 * np.pi * index.hour / 24)
        features["day_sin"] = np.sin(2 * np.pi * index.day / 31)
        features["day_cos"] = np.cos(2 * np.pi * index.day / 31)
        features["month_sin"] = np.sin(2 * np.pi * index.month / 12)
        features["month_cos"] = np.cos(2 * np.pi * index.month / 12)
        features["dayofweek_sin"] = np.sin(2 * np.pi * index.dayofweek / 7)
        features["dayofweek_cos"] = np.cos(2 * np.pi * index.dayofweek / 7)
        
        return features
    
    def _create_fourier_features(self, index: pd.DatetimeIndex) -> pd.DataFrame:
        """Create Fourier features for capturing seasonality.
        
        Args:
            index: DatetimeIndex
            
        Returns:
            DataFrame with Fourier features
        """
        features = pd.DataFrame(index=index)
        
        # Calculate time in days from start
        t = (index - index[0]).days
        
        for k in range(1, self.fourier_order + 1):
            features[f"fourier_sin_{k}"] = np.sin(2 * np.pi * k * t / 365.25)
            features[f"fourier_cos_{k}"] = np.cos(2 * np.pi * k * t / 365.25)
        
        return features
    
    def _create_calendar_features(self, index: pd.DatetimeIndex) -> pd.DataFrame:
        """Create calendar-based features.
        
        Args:
            index: DatetimeIndex
            
        Returns:
            DataFrame with calendar features
        """
        features = pd.DataFrame(index=index)
        
        # Weekend indicator
        features["is_weekend"] = (index.dayofweek >= 5).astype(int)
        
        # Month start/end indicators
        features["is_month_start"] = index.is_month_start.astype(int)
        features["is_month_end"] = index.is_month_end.astype(int)
        
        # Quarter start/end indicators
        features["is_quarter_start"] = index.is_quarter_start.astype(int)
        features["is_quarter_end"] = index.is_quarter_end.astype(int)
        
        # Year start/end indicators
        features["is_year_start"] = index.is_year_start.astype(int)
        features["is_year_end"] = index.is_year_end.astype(int)
        
        # Business day indicator
        features["is_business_day"] = index.dayofweek.isin([0, 1, 2, 3, 4]).astype(int)
        
        return features
    
    def _create_interaction_features(
        self,
        features: pd.DataFrame,
        max_interactions: int = 10,
    ) -> pd.DataFrame:
        """Create interaction features between existing features.
        
        Args:
            features: Existing features
            max_interactions: Maximum number of interaction features to create
            
        Returns:
            DataFrame with interaction features
        """
        interactions = pd.DataFrame(index=features.index)
        
        # Select numeric columns only
        numeric_cols = features.select_dtypes(include=[np.number]).columns.tolist()
        
        # Create interactions between first few features
        count = 0
        for i, col1 in enumerate(numeric_cols):
            for col2 in numeric_cols[i + 1:]:
                if count >= max_interactions:
                    break
                interactions[f"{col1}_x_{col2}"] = features[col1] * features[col2]
                count += 1
            if count >= max_interactions:
                break
        
        return interactions


class AdvancedFeatureEngineer:
    """Advanced feature engineering techniques.
    
    Includes more sophisticated feature creation methods:
    - Wavelet features
    - Spectral features
    - Autocorrelation features
    - Trend and seasonality decomposition features
    """
    
    @staticmethod
    def create_wavelet_features(
        data: pd.Series,
        wavelet: str = "db4",
        level: int = 3,
    ) -> pd.DataFrame:
        """Create wavelet decomposition features.
        
        Args:
            data: Time series data
            wavelet: Wavelet type
            level: Decomposition level
            
        Returns:
            DataFrame with wavelet features
        """
        try:
            import pywt
            
            features = pd.DataFrame(index=data.index)
            
            # Perform wavelet decomposition
            coeffs = pywt.wavedec(data.values, wavelet, level=level)
            
            # Add approximation coefficients
            approx = coeffs[0]
            # Upsample to match original length
            approx_upsampled = np.repeat(approx, len(data) // len(approx) + 1)[:len(data)]
            features["wavelet_approx"] = approx_upsampled
            
            # Add detail coefficients
            for i, detail in enumerate(coeffs[1:], 1):
                detail_upsampled = np.repeat(detail, len(data) // len(detail) + 1)[:len(data)]
                features[f"wavelet_detail_{i}"] = detail_upsampled
            
            return features
            
        except ImportError:
            raise PreprocessingError("pywt package required for wavelet features")
    
    @staticmethod
    def create_spectral_features(
        data: pd.Series,
        n_features: int = 5,
    ) -> pd.DataFrame:
        """Create spectral (frequency domain) features.
        
        Args:
            data: Time series data
            n_features: Number of top frequency components to extract
            
        Returns:
            DataFrame with spectral features
        """
        features = pd.DataFrame(index=data.index)
        
        # Compute FFT
        fft_values = np.fft.fft(data.values)
        fft_freq = np.fft.fftfreq(len(data))
        
        # Get power spectrum
        power = np.abs(fft_values) ** 2
        
        # Find top frequencies
        top_indices = np.argsort(power)[-n_features:]
        
        for i, idx in enumerate(top_indices):
            freq = fft_freq[idx]
            amplitude = np.abs(fft_values[idx])
            
            # Create sinusoidal features
            t = np.arange(len(data))
            features[f"spectral_sin_{i}"] = amplitude * np.sin(2 * np.pi * freq * t)
            features[f"spectral_cos_{i}"] = amplitude * np.cos(2 * np.pi * freq * t)
        
        return features
    
    @staticmethod
    def create_autocorrelation_features(
        data: pd.Series,
        lags: Optional[List[int]] = None,
    ) -> pd.DataFrame:
        """Create autocorrelation features.
        
        Args:
            data: Time series data
            lags: List of lags for autocorrelation
            
        Returns:
            DataFrame with autocorrelation features
        """
        if lags is None:
            lags = [1, 7, 14, 30]
        
        features = pd.DataFrame(index=data.index)
        
        for lag in lags:
            # Calculate rolling autocorrelation
            autocorr = data.rolling(window=lag + 1).apply(
                lambda x: x.autocorr(lag=lag) if len(x) > lag else np.nan,
                raw=False
            )
            features[f"autocorr_{lag}"] = autocorr
        
        return features
    
    @staticmethod
    def create_decomposition_features(
        data: pd.Series,
        period: Optional[int] = None,
        model: str = "additive",
    ) -> pd.DataFrame:
        """Create features from time series decomposition.
        
        Args:
            data: Time series data
            period: Seasonal period
            model: Decomposition model ('additive' or 'multiplicative')
            
        Returns:
            DataFrame with decomposition features
        """
        from statsmodels.tsa.seasonal import seasonal_decompose
        
        features = pd.DataFrame(index=data.index)
        
        # Perform decomposition
        decomposition = seasonal_decompose(
            data,
            model=model,
            period=period,
            extrapolate_trend="freq"
        )
        
        features["trend"] = decomposition.trend
        features["seasonal"] = decomposition.seasonal
        features["residual"] = decomposition.resid
        
        return features


def create_target_encoding(
    data: pd.Series,
    categorical_feature: pd.Series,
    smoothing: float = 1.0,
) -> pd.Series:
    """Create target encoding for categorical features.
    
    Args:
        data: Target time series
        categorical_feature: Categorical feature to encode
        smoothing: Smoothing parameter
        
    Returns:
        Encoded feature
    """
    # Calculate global mean
    global_mean = data.mean()
    
    # Calculate category means
    category_means = data.groupby(categorical_feature).agg(["mean", "count"])
    
    # Apply smoothing
    smoothed_means = (
        category_means["mean"] * category_means["count"] + global_mean * smoothing
    ) / (category_means["count"] + smoothing)
    
    # Map back to original index
    return categorical_feature.map(smoothed_means)


def create_expanding_features(
    data: pd.Series,
    functions: Optional[List[str]] = None,
) -> pd.DataFrame:
    """Create expanding window features.
    
    Args:
        data: Time series data
        functions: List of aggregation functions
        
    Returns:
        DataFrame with expanding features
    """
    if functions is None:
        functions = ["mean", "std", "min", "max"]
    
    features = pd.DataFrame(index=data.index)
    
    for func in functions:
        if func == "mean":
            features["expanding_mean"] = data.expanding().mean()
        elif func == "std":
            features["expanding_std"] = data.expanding().std()
        elif func == "min":
            features["expanding_min"] = data.expanding().min()
        elif func == "max":
            features["expanding_max"] = data.expanding().max()
        elif func == "median":
            features["expanding_median"] = data.expanding().median()
    
    return features


def create_ewm_features(
    data: pd.Series,
    spans: Optional[List[int]] = None,
) -> pd.DataFrame:
    """Create exponentially weighted moving average features.
    
    Args:
        data: Time series data
        spans: List of span values for EWM
        
    Returns:
        DataFrame with EWM features
    """
    if spans is None:
        spans = [7, 14, 30]
    
    features = pd.DataFrame(index=data.index)
    
    for span in spans:
        features[f"ewm_{span}_mean"] = data.ewm(span=span).mean()
        features[f"ewm_{span}_std"] = data.ewm(span=span).std()
    
    return features


class TimeSeriesFeatureEngineer:
    """Automated time series feature engineering with intelligent defaults.
    
    This class provides automated feature engineering specifically designed
    for time series forecasting, with automatic detection of seasonality
    and intelligent feature selection.
    
    Features created:
    - Lag features (configurable or auto-detected)
    - Rolling statistics (mean, std, min, max)
    - Date/time features (day of week, month, quarter, etc.)
    - Fourier features for seasonality (auto-detected period)
    - Expanding window features
    - Exponentially weighted features
    
    Examples
    --------
    >>> from forecasting.data.feature_engineering import TimeSeriesFeatureEngineer
    >>>
    >>> # Automatic feature engineering
    >>> engineer = TimeSeriesFeatureEngineer()
    >>> features = engineer.create_all_features(data, auto_detect=True)
    >>>
    >>> # Custom configuration
    >>> engineer = TimeSeriesFeatureEngineer(
    ...     lags=[1, 7, 14, 30],
    ...     rolling_windows=[7, 14, 30],
    ...     include_fourier=True
    ... )
    >>> features = engineer.create_all_features(data)
    """
    
    def __init__(
        self,
        lags: Optional[List[int]] = None,
        rolling_windows: Optional[List[int]] = None,
        include_date_features: bool = True,
        include_fourier: bool = True,
        fourier_order: int = 5,
        include_expanding: bool = False,
        include_ewm: bool = False,
        ewm_spans: Optional[List[int]] = None,
    ):
        """Initialize TimeSeriesFeatureEngineer.
        
        Args:
            lags: List of lag values (default: [1, 7, 14, 30])
            rolling_windows: List of window sizes (default: [7, 14, 30])
            include_date_features: Whether to include date/time features
            include_fourier: Whether to include Fourier features
            fourier_order: Order of Fourier features
            include_expanding: Whether to include expanding window features
            include_ewm: Whether to include exponentially weighted features
            ewm_spans: Spans for EWM features
        """
        self.lags = lags or [1, 7, 14, 30]
        self.rolling_windows = rolling_windows or [7, 14, 30]
        self.include_date_features = include_date_features
        self.include_fourier = include_fourier
        self.fourier_order = fourier_order
        self.include_expanding = include_expanding
        self.include_ewm = include_ewm
        self.ewm_spans = ewm_spans or [7, 14, 30]
        
        self.feature_names_: List[str] = []
        self.detected_period_: Optional[int] = None
    
    def create_lag_features(
        self,
        data: pd.Series,
        lags: Optional[List[int]] = None
    ) -> pd.DataFrame:
        """Create lag features.
        
        Args:
            data: Time series data
            lags: List of lag values (uses instance default if None)
            
        Returns:
            DataFrame with lag features
        """
        lags = lags or self.lags
        features = pd.DataFrame(index=data.index)
        
        for lag in lags:
            features[f'lag_{lag}'] = data.shift(lag)
        
        return features
    
    def create_rolling_features(
        self,
        data: pd.Series,
        windows: Optional[List[int]] = None
    ) -> pd.DataFrame:
        """Create rolling statistics features.
        
        Args:
            data: Time series data
            windows: List of window sizes (uses instance default if None)
            
        Returns:
            DataFrame with rolling features
        """
        windows = windows or self.rolling_windows
        features = pd.DataFrame(index=data.index)
        
        for window in windows:
            features[f'rolling_mean_{window}'] = data.rolling(window).mean()
            features[f'rolling_std_{window}'] = data.rolling(window).std()
            features[f'rolling_min_{window}'] = data.rolling(window).min()
            features[f'rolling_max_{window}'] = data.rolling(window).max()
        
        return features
    
    def create_date_features(self, data: pd.Series) -> pd.DataFrame:
        """Create date/time features.
        
        Args:
            data: Time series data with DatetimeIndex
            
        Returns:
            DataFrame with date features
        """
        if not isinstance(data.index, pd.DatetimeIndex):
            raise PreprocessingError("Data must have DatetimeIndex for date features")
        
        features = pd.DataFrame(index=data.index)
        
        # Basic date features
        features['day_of_week'] = data.index.dayofweek
        features['day_of_month'] = data.index.day
        features['month'] = data.index.month
        features['quarter'] = data.index.quarter
        features['year'] = data.index.year
        features['is_weekend'] = (data.index.dayofweek >= 5).astype(int)
        features['is_month_start'] = data.index.is_month_start.astype(int)
        features['is_month_end'] = data.index.is_month_end.astype(int)
        features['is_quarter_start'] = data.index.is_quarter_start.astype(int)
        features['is_quarter_end'] = data.index.is_quarter_end.astype(int)
        
        return features
    
    def create_fourier_features(
        self,
        data: pd.Series,
        period: Optional[int] = None,
        order: Optional[int] = None
    ) -> pd.DataFrame:
        """Create Fourier features for seasonality.
        
        Args:
            data: Time series data
            period: Seasonal period (auto-detected if None)
            order: Fourier order (uses instance default if None)
            
        Returns:
            DataFrame with Fourier features
        """
        order = order or self.fourier_order
        
        if period is None:
            period = self._detect_seasonality(data)
            if period is None:
                return pd.DataFrame(index=data.index)
        
        features = pd.DataFrame(index=data.index)
        t = np.arange(len(data))
        
        for i in range(1, order + 1):
            features[f'sin_{period}_{i}'] = np.sin(2 * np.pi * i * t / period)
            features[f'cos_{period}_{i}'] = np.cos(2 * np.pi * i * t / period)
        
        return features
    
    def _detect_seasonality(self, data: pd.Series) -> Optional[int]:
        """Detect seasonal period using autocorrelation.
        
        Args:
            data: Time series data
            
        Returns:
            Detected period or None
        """
        try:
            from statsmodels.tsa.stattools import acf
            
            # Calculate autocorrelation
            max_lag = min(len(data) // 2, 365)
            autocorr = acf(data.dropna(), nlags=max_lag, fft=True)
            
            # Find peaks in autocorrelation
            peaks = []
            for i in range(2, len(autocorr) - 1):
                if autocorr[i] > autocorr[i-1] and autocorr[i] > autocorr[i+1]:
                    if autocorr[i] > 0.3:  # Threshold for significant peak
                        peaks.append((i, autocorr[i]))
            
            if peaks:
                # Return the lag with highest autocorrelation
                period = max(peaks, key=lambda x: x[1])[0]
                self.detected_period_ = period
                return period
            
            return None
            
        except Exception:
            return None
    
    def create_all_features(
        self,
        data: pd.Series,
        auto_detect: bool = True
    ) -> pd.DataFrame:
        """Create all features automatically.
        
        Args:
            data: Time series data
            auto_detect: Whether to auto-detect seasonality for Fourier features
            
        Returns:
            DataFrame with all engineered features
            
        Examples
        --------
        >>> engineer = TimeSeriesFeatureEngineer()
        >>> features = engineer.create_all_features(data, auto_detect=True)
        >>> print(f"Created {features.shape[1]} features")
        """
        all_features = []
        
        # 1. Lag features
        lag_features = self.create_lag_features(data)
        all_features.append(lag_features)
        
        # 2. Rolling features
        rolling_features = self.create_rolling_features(data)
        all_features.append(rolling_features)
        
        # 3. Date features
        if self.include_date_features and isinstance(data.index, pd.DatetimeIndex):
            date_features = self.create_date_features(data)
            all_features.append(date_features)
        
        # 4. Fourier features (with auto-detection)
        if self.include_fourier:
            if auto_detect:
                fourier_features = self.create_fourier_features(data, period=None)
            else:
                # Use common periods
                fourier_features = pd.DataFrame(index=data.index)
                for period in [7, 30, 365]:
                    period_features = self.create_fourier_features(
                        data, period=period, order=3
                    )
                    fourier_features = pd.concat([fourier_features, period_features], axis=1)
            
            if not fourier_features.empty:
                all_features.append(fourier_features)
        
        # 5. Expanding features
        if self.include_expanding:
            expanding_features = create_expanding_features(data)
            all_features.append(expanding_features)
        
        # 6. EWM features
        if self.include_ewm:
            ewm_features = create_ewm_features(data, spans=self.ewm_spans)
            all_features.append(ewm_features)
        
        # Combine all features
        features = pd.concat(all_features, axis=1)
        
        # Store feature names
        self.feature_names_ = features.columns.tolist()
        
        return features
    
    def fit_transform(self, data: pd.Series) -> pd.DataFrame:
        """Fit and transform data (alias for create_all_features).
        
        Args:
            data: Time series data
            
        Returns:
            DataFrame with all features
        """
        return self.create_all_features(data, auto_detect=True)
    
    def get_feature_names(self) -> List[str]:
        """Get names of created features.
        
        Returns:
            List of feature names
        """
        return self.feature_names_


# Made with Bob
