"""Data quality checks and monitoring for time series."""

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from scipy import stats

from forecasting.core.exceptions import DataValidationError


@dataclass
class QualityReport:
    """Data quality report.
    
    Attributes:
        passed: Whether all checks passed
        warnings: List of warning messages
        errors: List of error messages
        metrics: Dictionary of quality metrics
    """
    
    passed: bool
    warnings: List[str]
    errors: List[str]
    metrics: Dict[str, float]
    
    def __str__(self) -> str:
        """String representation of quality report."""
        lines = [
            "=" * 60,
            "DATA QUALITY REPORT",
            "=" * 60,
            f"Status: {'PASSED' if self.passed else 'FAILED'}",
            "",
        ]
        
        if self.errors:
            lines.append("ERRORS:")
            for error in self.errors:
                lines.append(f"  ❌ {error}")
            lines.append("")
        
        if self.warnings:
            lines.append("WARNINGS:")
            for warning in self.warnings:
                lines.append(f"  ⚠️  {warning}")
            lines.append("")
        
        lines.append("METRICS:")
        for key, value in self.metrics.items():
            lines.append(f"  {key}: {value:.4f}")
        
        lines.append("=" * 60)
        return "\n".join(lines)


class DataQualityChecker:
    """Comprehensive data quality checker for time series.
    
    Performs various quality checks including:
    - Completeness checks
    - Consistency checks
    - Validity checks
    - Accuracy checks
    - Timeliness checks
    """
    
    def __init__(
        self,
        min_length: int = 10,
        max_missing_ratio: float = 0.1,
        max_duplicate_ratio: float = 0.05,
        max_outlier_ratio: float = 0.1,
        check_stationarity: bool = True,
        check_seasonality: bool = True,
    ):
        """Initialize data quality checker.
        
        Args:
            min_length: Minimum required length
            max_missing_ratio: Maximum allowed missing value ratio
            max_duplicate_ratio: Maximum allowed duplicate ratio
            max_outlier_ratio: Maximum allowed outlier ratio
            check_stationarity: Whether to check stationarity
            check_seasonality: Whether to check seasonality
        """
        self.min_length = min_length
        self.max_missing_ratio = max_missing_ratio
        self.max_duplicate_ratio = max_duplicate_ratio
        self.max_outlier_ratio = max_outlier_ratio
        self.check_stationarity = check_stationarity
        self.check_seasonality = check_seasonality
    
    def check_quality(self, data: pd.Series) -> QualityReport:
        """Perform comprehensive quality checks.
        
        Args:
            data: Time series to check
            
        Returns:
            QualityReport with results
        """
        warnings: List[str] = []
        errors: List[str] = []
        metrics: Dict[str, float] = {}
        
        # 1. Completeness checks
        completeness_warnings, completeness_errors, completeness_metrics = (
            self._check_completeness(data)
        )
        warnings.extend(completeness_warnings)
        errors.extend(completeness_errors)
        metrics.update(completeness_metrics)
        
        # 2. Consistency checks
        consistency_warnings, consistency_errors, consistency_metrics = (
            self._check_consistency(data)
        )
        warnings.extend(consistency_warnings)
        errors.extend(consistency_errors)
        metrics.update(consistency_metrics)
        
        # 3. Validity checks
        validity_warnings, validity_errors, validity_metrics = (
            self._check_validity(data)
        )
        warnings.extend(validity_warnings)
        errors.extend(validity_errors)
        metrics.update(validity_metrics)
        
        # 4. Statistical checks
        if self.check_stationarity or self.check_seasonality:
            stat_warnings, stat_errors, stat_metrics = (
                self._check_statistical_properties(data)
            )
            warnings.extend(stat_warnings)
            errors.extend(stat_errors)
            metrics.update(stat_metrics)
        
        passed = len(errors) == 0
        
        return QualityReport(
            passed=passed,
            warnings=warnings,
            errors=errors,
            metrics=metrics,
        )
    
    def _check_completeness(
        self,
        data: pd.Series,
    ) -> Tuple[List[str], List[str], Dict[str, float]]:
        """Check data completeness.
        
        Args:
            data: Time series to check
            
        Returns:
            Tuple of (warnings, errors, metrics)
        """
        warnings = []
        errors = []
        metrics = {}
        
        # Check length
        length = len(data)
        metrics["length"] = float(length)
        
        if length < self.min_length:
            errors.append(
                f"Data length ({length}) is below minimum ({self.min_length})"
            )
        
        # Check missing values
        missing_count = data.isnull().sum()
        missing_ratio = missing_count / length if length > 0 else 0
        metrics["missing_ratio"] = missing_ratio
        
        if missing_ratio > self.max_missing_ratio:
            errors.append(
                f"Missing value ratio ({missing_ratio:.2%}) exceeds "
                f"maximum ({self.max_missing_ratio:.2%})"
            )
        elif missing_ratio > 0:
            warnings.append(
                f"Data contains {missing_count} missing values "
                f"({missing_ratio:.2%})"
            )
        
        return warnings, errors, metrics
    
    def _check_consistency(
        self,
        data: pd.Series,
    ) -> Tuple[List[str], List[str], Dict[str, float]]:
        """Check data consistency.
        
        Args:
            data: Time series to check
            
        Returns:
            Tuple of (warnings, errors, metrics)
        """
        warnings = []
        errors = []
        metrics = {}
        
        # Check for duplicates
        if isinstance(data.index, pd.DatetimeIndex):
            duplicate_count = data.index.duplicated().sum()
            duplicate_ratio = duplicate_count / len(data) if len(data) > 0 else 0
            metrics["duplicate_ratio"] = duplicate_ratio
            
            if duplicate_ratio > self.max_duplicate_ratio:
                errors.append(
                    f"Duplicate timestamp ratio ({duplicate_ratio:.2%}) exceeds "
                    f"maximum ({self.max_duplicate_ratio:.2%})"
                )
            elif duplicate_count > 0:
                warnings.append(
                    f"Data contains {duplicate_count} duplicate timestamps"
                )
            
            # Check for gaps in time series
            if len(data) > 1:
                time_diffs = data.index.to_series().diff()
                mode_diff = time_diffs.mode()[0] if len(time_diffs.mode()) > 0 else None
                
                if mode_diff is not None:
                    gaps = time_diffs[time_diffs > mode_diff * 2]
                    gap_count = len(gaps)
                    metrics["gap_count"] = float(gap_count)
                    
                    if gap_count > 0:
                        warnings.append(
                            f"Data contains {gap_count} time gaps larger than expected"
                        )
        
        # Check for constant values
        unique_count = data.nunique()
        metrics["unique_ratio"] = unique_count / len(data) if len(data) > 0 else 0
        
        if unique_count == 1:
            warnings.append("Data contains only constant values")
        elif unique_count < len(data) * 0.1:
            warnings.append(
                f"Data has low variability (only {unique_count} unique values)"
            )
        
        return warnings, errors, metrics
    
    def _check_validity(
        self,
        data: pd.Series,
    ) -> Tuple[List[str], List[str], Dict[str, float]]:
        """Check data validity.
        
        Args:
            data: Time series to check
            
        Returns:
            Tuple of (warnings, errors, metrics)
        """
        warnings = []
        errors = []
        metrics = {}
        
        # Check for infinite values
        inf_count = np.isinf(data).sum()
        metrics["inf_count"] = float(inf_count)
        
        if inf_count > 0:
            errors.append(f"Data contains {inf_count} infinite values")
        
        # Check for outliers using IQR method
        clean_data = data.dropna()
        if len(clean_data) > 0:
            q1 = clean_data.quantile(0.25)
            q3 = clean_data.quantile(0.75)
            iqr = q3 - q1
            
            lower_bound = q1 - 1.5 * iqr
            upper_bound = q3 + 1.5 * iqr
            
            outliers = (clean_data < lower_bound) | (clean_data > upper_bound)
            outlier_count = outliers.sum()
            outlier_ratio = outlier_count / len(clean_data)
            
            metrics["outlier_ratio"] = outlier_ratio
            metrics["outlier_count"] = float(outlier_count)
            
            if outlier_ratio > self.max_outlier_ratio:
                warnings.append(
                    f"Outlier ratio ({outlier_ratio:.2%}) exceeds "
                    f"threshold ({self.max_outlier_ratio:.2%})"
                )
            
            # Basic statistics
            metrics["mean"] = float(clean_data.mean())
            metrics["std"] = float(clean_data.std())
            metrics["min"] = float(clean_data.min())
            metrics["max"] = float(clean_data.max())
            metrics["skewness"] = float(clean_data.skew())
            metrics["kurtosis"] = float(clean_data.kurtosis())
        
        return warnings, errors, metrics
    
    def _check_statistical_properties(
        self,
        data: pd.Series,
    ) -> Tuple[List[str], List[str], Dict[str, float]]:
        """Check statistical properties.
        
        Args:
            data: Time series to check
            
        Returns:
            Tuple of (warnings, errors, metrics)
        """
        warnings = []
        errors = []
        metrics = {}
        
        clean_data = data.dropna()
        
        if len(clean_data) < 10:
            warnings.append("Insufficient data for statistical tests")
            return warnings, errors, metrics
        
        # Stationarity test (ADF)
        if self.check_stationarity:
            try:
                from statsmodels.tsa.stattools import adfuller
                
                adf_result = adfuller(clean_data, autolag="AIC")
                adf_statistic = adf_result[0]
                adf_pvalue = adf_result[1]
                
                metrics["adf_statistic"] = float(adf_statistic)
                metrics["adf_pvalue"] = float(adf_pvalue)
                
                if adf_pvalue > 0.05:
                    warnings.append(
                        f"Data may be non-stationary (ADF p-value: {adf_pvalue:.4f})"
                    )
            except Exception as e:
                warnings.append(f"Could not perform stationarity test: {str(e)}")
        
        # Seasonality detection
        if self.check_seasonality and len(clean_data) >= 24:
            try:
                # Simple autocorrelation check
                from statsmodels.tsa.stattools import acf
                
                acf_values = acf(clean_data, nlags=min(40, len(clean_data) // 2))
                
                # Check for significant autocorrelation at common lags
                seasonal_lags = [7, 12, 24, 30]
                for lag in seasonal_lags:
                    if lag < len(acf_values):
                        if abs(acf_values[lag]) > 0.3:
                            warnings.append(
                                f"Potential seasonality detected at lag {lag}"
                            )
                            metrics[f"acf_lag_{lag}"] = float(acf_values[lag])
                            break
            except Exception as e:
                warnings.append(f"Could not check seasonality: {str(e)}")
        
        return warnings, errors, metrics


class DataDriftDetector:
    """Detect data drift in time series.
    
    Monitors changes in data distribution over time to detect drift.
    """
    
    def __init__(
        self,
        window_size: int = 100,
        drift_threshold: float = 0.05,
    ):
        """Initialize drift detector.
        
        Args:
            window_size: Size of sliding window for comparison
            drift_threshold: P-value threshold for drift detection
        """
        self.window_size = window_size
        self.drift_threshold = drift_threshold
        self.reference_data: Optional[pd.Series] = None
    
    def fit(self, data: pd.Series) -> "DataDriftDetector":
        """Fit detector on reference data.
        
        Args:
            data: Reference time series
            
        Returns:
            Self for method chaining
        """
        self.reference_data = data.copy()
        return self
    
    def detect_drift(self, data: pd.Series) -> Dict[str, any]:
        """Detect drift in new data.
        
        Args:
            data: New time series to check
            
        Returns:
            Dictionary with drift detection results
        """
        if self.reference_data is None:
            raise DataValidationError("Detector must be fitted before detecting drift")
        
        results = {
            "drift_detected": False,
            "tests": {},
        }
        
        # Kolmogorov-Smirnov test
        ks_statistic, ks_pvalue = stats.ks_2samp(
            self.reference_data.dropna(),
            data.dropna()
        )
        
        results["tests"]["ks_test"] = {
            "statistic": float(ks_statistic),
            "pvalue": float(ks_pvalue),
            "drift": ks_pvalue < self.drift_threshold,
        }
        
        # Mann-Whitney U test
        mw_statistic, mw_pvalue = stats.mannwhitneyu(
            self.reference_data.dropna(),
            data.dropna(),
            alternative="two-sided"
        )
        
        results["tests"]["mann_whitney"] = {
            "statistic": float(mw_statistic),
            "pvalue": float(mw_pvalue),
            "drift": mw_pvalue < self.drift_threshold,
        }
        
        # Check if any test detected drift
        results["drift_detected"] = any(
            test["drift"] for test in results["tests"].values()
        )
        
        # Statistical comparison
        results["statistics"] = {
            "reference_mean": float(self.reference_data.mean()),
            "current_mean": float(data.mean()),
            "reference_std": float(self.reference_data.std()),
            "current_std": float(data.std()),
            "mean_change": float(
                (data.mean() - self.reference_data.mean()) / self.reference_data.mean()
            ),
            "std_change": float(
                (data.std() - self.reference_data.std()) / self.reference_data.std()
            ),
        }
        
        return results


def check_data_freshness(
    data: pd.Series,
    max_age_hours: int = 24,
) -> Tuple[bool, str]:
    """Check if data is fresh (recent).
    
    Args:
        data: Time series with datetime index
        max_age_hours: Maximum allowed age in hours
        
    Returns:
        Tuple of (is_fresh, message)
    """
    if not isinstance(data.index, pd.DatetimeIndex):
        return False, "Data must have DatetimeIndex"
    
    latest_timestamp = data.index.max()
    current_time = pd.Timestamp.now(tz=latest_timestamp.tz)
    age = current_time - latest_timestamp
    age_hours = age.total_seconds() / 3600
    
    is_fresh = age_hours <= max_age_hours
    
    message = (
        f"Data is {age_hours:.1f} hours old "
        f"({'fresh' if is_fresh else 'stale'})"
    )
    
    return is_fresh, message


def validate_forecast_horizon(
    data: pd.Series,
    horizon: int,
    min_history_ratio: float = 2.0,
) -> Tuple[bool, str]:
    """Validate if there's enough history for forecast horizon.
    
    Args:
        data: Historical time series
        horizon: Forecast horizon
        min_history_ratio: Minimum ratio of history to horizon
        
    Returns:
        Tuple of (is_valid, message)
    """
    history_length = len(data)
    required_length = int(horizon * min_history_ratio)
    
    is_valid = history_length >= required_length
    
    message = (
        f"History length: {history_length}, "
        f"Required: {required_length} "
        f"(for horizon {horizon})"
    )
    
    return is_valid, message


# Made with Bob
