"""Special case handlers for forecasting scenarios."""

from typing import Optional, Tuple, Dict
import numpy as np
import pandas as pd
from enum import Enum

from forecasting.core.exceptions import DataValidationError


class DemandPattern(str, Enum):
    """Types of demand patterns."""
    
    REGULAR = "regular"  # Continuous demand
    INTERMITTENT = "intermittent"  # Sporadic demand with zeros
    LUMPY = "lumpy"  # Intermittent with high variance
    SMOOTH = "smooth"  # Low variance, predictable
    ERRATIC = "erratic"  # High variance, unpredictable
    NEW_PRODUCT = "new_product"  # Insufficient history


class DemandPatternDetector:
    """Detect demand patterns in time series data.
    
    Classifies time series into different demand patterns to determine
    appropriate forecasting strategies.
    
    Attributes:
        min_history_length: Minimum data points for regular forecasting
        zero_threshold: Threshold for considering value as zero
        cv_threshold: Coefficient of variation threshold for variance classification
        adi_threshold: Average demand interval threshold for intermittency
    """
    
    def __init__(
        self,
        min_history_length: int = 24,
        zero_threshold: float = 0.01,
        cv_threshold: float = 0.5,
        adi_threshold: float = 1.32,
    ):
        """Initialize detector.
        
        Args:
            min_history_length: Minimum points needed for regular forecasting
            zero_threshold: Values below this are considered zero
            cv_threshold: CV threshold (0.5 = moderate variance)
            adi_threshold: ADI threshold (1.32 = Croston's cutoff)
        """
        self.min_history_length = min_history_length
        self.zero_threshold = zero_threshold
        self.cv_threshold = cv_threshold
        self.adi_threshold = adi_threshold
    
    def detect_pattern(self, data: pd.Series) -> Tuple[DemandPattern, Dict[str, float]]:
        """Detect demand pattern in time series.
        
        Args:
            data: Time series data
            
        Returns:
            Tuple of (pattern, metrics_dict)
        """
        metrics = self._calculate_metrics(data)
        pattern = self._classify_pattern(metrics)
        
        return pattern, metrics
    
    def _calculate_metrics(self, data: pd.Series) -> Dict[str, float]:
        """Calculate demand pattern metrics.
        
        Args:
            data: Time series data
            
        Returns:
            Dictionary of metrics
        """
        # Basic statistics
        n = len(data)
        mean = data.mean()
        std = data.std()
        cv = std / mean if mean > 0 else np.inf  # Coefficient of variation
        
        # Zero demand analysis
        zero_count = (data <= self.zero_threshold).sum()
        zero_ratio = zero_count / n
        
        # Average Demand Interval (ADI) - average time between non-zero demands
        non_zero_indices = np.where(data > self.zero_threshold)[0]
        if len(non_zero_indices) > 1:
            intervals = np.diff(non_zero_indices)
            adi = intervals.mean() if len(intervals) > 0 else n
        else:
            adi = n
        
        # Demand variability (for non-zero demands only)
        non_zero_data = data[data > self.zero_threshold]
        if len(non_zero_data) > 1:
            cv_non_zero = non_zero_data.std() / non_zero_data.mean()
        else:
            cv_non_zero = 0
        
        return {
            'length': n,
            'mean': mean,
            'std': std,
            'cv': cv,
            'zero_count': zero_count,
            'zero_ratio': zero_ratio,
            'adi': adi,
            'cv_non_zero': cv_non_zero,
            'non_zero_count': len(non_zero_data),
        }
    
    def _classify_pattern(self, metrics: Dict[str, float]) -> DemandPattern:
        """Classify demand pattern based on metrics.
        
        Args:
            metrics: Calculated metrics
            
        Returns:
            Demand pattern classification
        """
        # Check for new product (insufficient history)
        if metrics['length'] < self.min_history_length:
            return DemandPattern.NEW_PRODUCT
        
        # Check for intermittent demand
        if metrics['adi'] > self.adi_threshold:
            # Lumpy: intermittent with high variance
            if metrics['cv_non_zero'] > self.cv_threshold:
                return DemandPattern.LUMPY
            else:
                return DemandPattern.INTERMITTENT
        
        # Regular demand patterns
        if metrics['cv'] < self.cv_threshold:
            return DemandPattern.SMOOTH
        elif metrics['cv'] > 1.0:
            return DemandPattern.ERRATIC
        else:
            return DemandPattern.REGULAR


class IntermittentDemandHandler:
    """Handler for intermittent and sparse demand forecasting.
    
    Implements specialized methods for intermittent demand:
    - Croston's method
    - SBA (Syntetos-Boylan Approximation)
    - TSB (Teunter-Syntetos-Babai)
    
    These methods separate demand occurrence from demand size.
    """
    
    def __init__(
        self,
        method: str = "croston",
        alpha: float = 0.1,
        zero_threshold: float = 0.01,
    ):
        """Initialize handler.
        
        Args:
            method: Method to use ('croston', 'sba', 'tsb')
            alpha: Smoothing parameter (0-1)
            zero_threshold: Values below this are considered zero
        """
        self.method = method
        self.alpha = alpha
        self.zero_threshold = zero_threshold
        self._demand_level: Optional[float] = None
        self._demand_interval: Optional[float] = None
    
    def fit(self, data: pd.Series) -> "IntermittentDemandHandler":
        """Fit intermittent demand model.
        
        Args:
            data: Time series with intermittent demand
            
        Returns:
            Self for method chaining
        """
        # Separate demand occurrences and sizes
        non_zero_mask = data > self.zero_threshold
        non_zero_demands = data[non_zero_mask]
        
        if len(non_zero_demands) == 0:
            raise DataValidationError("No non-zero demands found")
        
        # Initialize with first non-zero demand
        self._demand_level = non_zero_demands.iloc[0]
        self._demand_interval = 1.0
        
        # Apply exponential smoothing
        interval_count = 1
        for i in range(1, len(data)):
            if data.iloc[i] > self.zero_threshold:
                # Update demand level
                self._demand_level = (
                    self.alpha * data.iloc[i] + 
                    (1 - self.alpha) * self._demand_level
                )
                # Update interval
                self._demand_interval = (
                    self.alpha * interval_count + 
                    (1 - self.alpha) * self._demand_interval
                )
                interval_count = 1
            else:
                interval_count += 1
        
        return self
    
    def predict(self, horizon: int = 1) -> pd.Series:
        """Generate forecasts for intermittent demand.
        
        Args:
            horizon: Number of periods to forecast
            
        Returns:
            Forecast series
        """
        if self._demand_level is None or self._demand_interval is None:
            raise ValueError("Model must be fitted before prediction")
        
        if self.method == "croston":
            # Croston's method: forecast = demand_level / demand_interval
            forecast_value = self._demand_level / self._demand_interval
        elif self.method == "sba":
            # SBA: adjusts for bias in Croston's
            forecast_value = (
                self._demand_level * (1 - self.alpha / 2) / self._demand_interval
            )
        elif self.method == "tsb":
            # TSB: probability-based approach
            prob_demand = 1 / self._demand_interval
            forecast_value = prob_demand * self._demand_level
        else:
            raise ValueError(f"Unknown method: {self.method}")
        
        # Return constant forecast for all horizons
        return pd.Series([forecast_value] * horizon)


class NewProductHandler:
    """Handler for new products with limited or no historical data.
    
    Implements strategies for cold start scenarios:
    - Similar product bootstrapping
    - Market-based initialization
    - Hierarchical forecasting
    - Judgmental forecasting integration
    """
    
    def __init__(
        self,
        bootstrap_method: str = "similar_products",
        min_similarity_threshold: float = 0.7,
    ):
        """Initialize handler.
        
        Args:
            bootstrap_method: Method for initialization
            min_similarity_threshold: Minimum similarity score for bootstrapping
        """
        self.bootstrap_method = bootstrap_method
        self.min_similarity_threshold = min_similarity_threshold
        self._bootstrap_data: Optional[pd.Series] = None
    
    def bootstrap_from_similar(
        self,
        similar_products: Dict[str, pd.Series],
        similarity_scores: Dict[str, float],
    ) -> pd.Series:
        """Bootstrap forecast from similar products.
        
        Args:
            similar_products: Dictionary of product_id -> historical data
            similarity_scores: Dictionary of product_id -> similarity score (0-1)
            
        Returns:
            Bootstrapped time series
        """
        # Filter by similarity threshold
        valid_products = {
            pid: data for pid, data in similar_products.items()
            if similarity_scores.get(pid, 0) >= self.min_similarity_threshold
        }
        
        if not valid_products:
            raise DataValidationError(
                f"No similar products found with similarity >= {self.min_similarity_threshold}"
            )
        
        # Weighted average based on similarity scores
        weights = np.array([similarity_scores[pid] for pid in valid_products.keys()])
        weights = weights / weights.sum()
        
        # Align all series to same length
        min_length = min(len(data) for data in valid_products.values())
        aligned_data = np.array([
            data.iloc[-min_length:].values 
            for data in valid_products.values()
        ])
        
        # Weighted average
        bootstrap = np.average(aligned_data, axis=0, weights=weights)
        self._bootstrap_data = pd.Series(bootstrap)
        
        return self._bootstrap_data
    
    def bootstrap_from_market(
        self,
        market_data: pd.Series,
        market_share: float = 0.01,
    ) -> pd.Series:
        """Bootstrap from market-level data.
        
        Args:
            market_data: Total market demand
            market_share: Expected market share (0-1)
            
        Returns:
            Bootstrapped time series
        """
        self._bootstrap_data = market_data * market_share
        return self._bootstrap_data
    
    def get_bootstrap_data(self) -> Optional[pd.Series]:
        """Get bootstrapped data if available.
        
        Returns:
            Bootstrapped time series or None
        """
        return self._bootstrap_data


class AdaptiveDecomposer:
    """Adaptive decomposition that handles special cases.
    
    Automatically adjusts decomposition strategy based on demand pattern:
    - Regular: Standard STL/Classical decomposition
    - Intermittent: Skip decomposition, use specialized methods
    - New Product: Use bootstrapped data for decomposition
    - Lumpy/Erratic: Robust decomposition with outlier handling
    """
    
    def __init__(
        self,
        auto_detect: bool = True,
        fallback_to_simple: bool = True,
    ):
        """Initialize adaptive decomposer.
        
        Args:
            auto_detect: Automatically detect demand pattern
            fallback_to_simple: Fall back to simple methods if decomposition fails
        """
        self.auto_detect = auto_detect
        self.fallback_to_simple = fallback_to_simple
        self.detector = DemandPatternDetector()
        self.pattern: Optional[DemandPattern] = None
        self.metrics: Optional[Dict[str, float]] = None
    
    def should_decompose(self, data: pd.Series) -> bool:
        """Determine if decomposition should be applied.
        
        Args:
            data: Time series data
            
        Returns:
            True if decomposition is appropriate
        """
        if not self.auto_detect:
            return True
        
        self.pattern, self.metrics = self.detector.detect_pattern(data)
        
        # Don't decompose for these patterns
        if self.pattern in [
            DemandPattern.NEW_PRODUCT,
            DemandPattern.INTERMITTENT,
            DemandPattern.LUMPY,
        ]:
            return False
        
        return True
    
    def get_recommended_method(self) -> str:
        """Get recommended forecasting method based on pattern.
        
        Returns:
            Recommended method name
        """
        if self.pattern == DemandPattern.NEW_PRODUCT:
            return "bootstrap_similar_products"
        elif self.pattern in [DemandPattern.INTERMITTENT, DemandPattern.LUMPY]:
            return "croston_or_sba"
        elif self.pattern == DemandPattern.SMOOTH:
            return "simple_exponential_smoothing"
        elif self.pattern == DemandPattern.ERRATIC:
            return "ensemble_with_robust_methods"
        else:
            return "standard_decomposition"


# Made with Bob