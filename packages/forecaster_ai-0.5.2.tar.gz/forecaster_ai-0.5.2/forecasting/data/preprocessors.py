"""Data preprocessing and decomposition for time series forecasting."""

from enum import Enum
from typing import Dict, Optional, Tuple, Union

import numpy as np
import pandas as pd
from statsmodels.tsa.seasonal import STL, seasonal_decompose

from forecasting.core.exceptions import DataValidationError
from forecasting.data.special_cases import (
    AdaptiveDecomposer,
    DemandPattern,
    IntermittentDemandHandler,
)


class DecompositionMethod(str, Enum):
    """Supported decomposition methods."""
    
    STL = "stl"
    CLASSICAL = "classical"
    NONE = "none"


class DecompositionModel(str, Enum):
    """Decomposition model types."""
    
    ADDITIVE = "additive"
    MULTIPLICATIVE = "multiplicative"


class TimeSeriesDecomposer:
    """Decompose time series into trend, seasonal, and residual components.
    
    This class implements various decomposition methods to separate a time series
    into its constituent components, which can improve forecasting accuracy.
    
    Attributes:
        method: Decomposition method to use
        model: Additive or multiplicative model
        period: Seasonal period (auto-detected if None)
        trend_window: Window size for trend extraction (STL only)
        seasonal_window: Window size for seasonal extraction (STL only)
    """

    def __init__(
        self,
        method: Union[str, DecompositionMethod] = DecompositionMethod.STL,
        model: Union[str, DecompositionModel] = DecompositionModel.ADDITIVE,
        period: Optional[int] = None,
        trend_window: Optional[int] = None,
        seasonal_window: Optional[int] = None,
    ):
        """Initialize decomposer.
        
        Args:
            method: Decomposition method ('stl', 'classical', 'none')
            model: Model type ('additive', 'multiplicative')
            period: Seasonal period (auto-detected if None)
            trend_window: Trend smoothing window (STL only)
            seasonal_window: Seasonal smoothing window (STL only)
        """
        self.method = DecompositionMethod(method)
        self.model = DecompositionModel(model)
        self.period = period
        self.trend_window = trend_window
        self.seasonal_window = seasonal_window
        
        self._trend: Optional[pd.Series] = None
        self._seasonal: Optional[pd.Series] = None
        self._residual: Optional[pd.Series] = None
        self._is_fitted: bool = False

    def fit_transform(
        self,
        data: pd.Series,
    ) -> Tuple[pd.Series, pd.Series, pd.Series]:
        """Fit decomposer and transform data.
        
        Args:
            data: Time series to decompose
            
        Returns:
            Tuple of (trend, seasonal, residual) components
            
        Raises:
            DataValidationError: If data is invalid
        """
        self._validate_input(data)
        
        if self.method == DecompositionMethod.NONE:
            # No decomposition - return original data as trend
            self._trend = data.copy()
            self._seasonal = pd.Series(0, index=data.index)
            self._residual = pd.Series(0, index=data.index)
        elif self.method == DecompositionMethod.STL:
            self._decompose_stl(data)
        elif self.method == DecompositionMethod.CLASSICAL:
            self._decompose_classical(data)
        
        self._is_fitted = True
        return self._trend, self._seasonal, self._residual

    def _validate_input(self, data: pd.Series) -> None:
        """Validate input data.
        
        Args:
            data: Time series to validate
            
        Raises:
            DataValidationError: If data is invalid
        """
        if not isinstance(data, pd.Series):
            raise DataValidationError("Input must be a pandas Series")
        
        if data.empty:
            raise DataValidationError("Input series is empty")
        
        if data.isnull().any():
            raise DataValidationError("Input contains missing values")
        
        if self.method != DecompositionMethod.NONE:
            min_length = (self.period or 2) * 2
            if len(data) < min_length:
                raise DataValidationError(
                    f"Time series too short for decomposition. "
                    f"Need at least {min_length} observations"
                )

    def _decompose_stl(self, data: pd.Series) -> None:
        """Decompose using STL (Seasonal-Trend decomposition using LOESS).
        
        STL is robust to outliers and handles various seasonal patterns well.
        
        Args:
            data: Time series to decompose
        """
        # Auto-detect period if not provided
        period = self._get_period(data)
        
        # Set default windows if not provided
        seasonal = self.seasonal_window or 7
        trend = self.trend_window or self._calculate_trend_window(len(data), period)
        
        # Perform STL decomposition
        stl = STL(
            data,
            seasonal=seasonal,
            trend=trend,
            period=period,
            robust=True,
        )
        result = stl.fit()
        
        self._trend = result.trend
        self._seasonal = result.seasonal
        self._residual = result.resid

    def _decompose_classical(self, data: pd.Series) -> None:
        """Decompose using classical moving average method.
        
        Args:
            data: Time series to decompose
        """
        period = self._get_period(data)
        
        # Perform classical decomposition
        result = seasonal_decompose(
            data,
            model=self.model.value,
            period=period,
            extrapolate_trend='freq',
        )
        
        self._trend = result.trend
        self._seasonal = result.seasonal
        self._residual = result.resid

    def _get_period(self, data: pd.Series) -> int:
        """Get or auto-detect seasonal period.
        
        Args:
            data: Time series data
            
        Returns:
            Seasonal period
        """
        if self.period is not None:
            return self.period
        
        # Auto-detect period based on index frequency
        if isinstance(data.index, pd.DatetimeIndex):
            freq = pd.infer_freq(data.index)
            if freq:
                # Map common frequencies to periods
                freq_map = {
                    'D': 7,      # Daily -> weekly seasonality
                    'W': 52,     # Weekly -> yearly seasonality
                    'M': 12,     # Monthly -> yearly seasonality
                    'Q': 4,      # Quarterly -> yearly seasonality
                    'H': 24,     # Hourly -> daily seasonality
                }
                for key, value in freq_map.items():
                    if freq.startswith(key):
                        return value
        
        # Default period
        return 7

    def _calculate_trend_window(self, n: int, period: int) -> int:
        """Calculate appropriate trend window size.
        
        Args:
            n: Length of time series
            period: Seasonal period
            
        Returns:
            Trend window size (must be odd)
        """
        # Rule of thumb: trend window should be larger than seasonal period
        window = max(period * 2 + 1, int(0.1 * n))
        # Ensure odd number
        if window % 2 == 0:
            window += 1
        return window

    def get_components(self) -> Dict[str, pd.Series]:
        """Get decomposition components.
        
        Returns:
            Dictionary with trend, seasonal, and residual components
            
        Raises:
            ValueError: If decomposer not fitted
        """
        if not self._is_fitted:
            raise ValueError("Decomposer must be fitted before getting components")
        
        return {
            'trend': self._trend,
            'seasonal': self._seasonal,
            'residual': self._residual,
        }

    def reconstruct(self) -> pd.Series:
        """Reconstruct original series from components.
        
        Returns:
            Reconstructed time series
            
        Raises:
            ValueError: If decomposer not fitted
        """
        if not self._is_fitted:
            raise ValueError("Decomposer must be fitted before reconstruction")
        
        if self.model == DecompositionModel.ADDITIVE:
            return self._trend + self._seasonal + self._residual
        else:  # MULTIPLICATIVE
            return self._trend * self._seasonal * self._residual


class TimeSeriesPreprocessor:
    """Comprehensive preprocessing pipeline for time series.
    
    Handles missing values, outliers, normalization, and decomposition.
    
    Attributes:
        handle_missing: Method for handling missing values
        handle_outliers: Whether to handle outliers
        normalize: Whether to normalize data
        decompose: Whether to decompose data
        decomposer: TimeSeriesDecomposer instance
    """

    def __init__(
        self,
        handle_missing: str = "interpolate",
        handle_outliers: bool = False,
        outlier_method: str = "iqr",
        outlier_threshold: float = 3.0,
        normalize: bool = False,
        normalize_method: str = "standardize",
        decompose: bool = True,
        decomposition_method: str = "stl",
        decomposition_model: str = "additive",
        seasonal_period: Optional[int] = None,
    ):
        """Initialize preprocessor.
        
        Args:
            handle_missing: Method for missing values ('interpolate', 'forward', 'backward')
            handle_outliers: Whether to handle outliers
            outlier_method: Outlier detection method
            outlier_threshold: Threshold for outlier detection
            normalize: Whether to normalize data
            normalize_method: Normalization method ('standardize', 'minmax')
            decompose: Whether to decompose time series
            decomposition_method: Decomposition method
            decomposition_model: Decomposition model type
            seasonal_period: Seasonal period for decomposition
        """
        self.handle_missing = handle_missing
        self.handle_outliers = handle_outliers
        self.outlier_method = outlier_method
        self.outlier_threshold = outlier_threshold
        self.normalize = normalize
        self.normalize_method = normalize_method
        self.decompose = decompose
        
        # Initialize decomposer if needed
        self.decomposer = None
        if self.decompose:
            self.decomposer = TimeSeriesDecomposer(
                method=decomposition_method,
                model=decomposition_model,
                period=seasonal_period,
            )
        
        # Store normalization parameters
        self._mean: Optional[float] = None
        self._std: Optional[float] = None
        self._min: Optional[float] = None
        self._max: Optional[float] = None

    def fit_transform(self, data: pd.Series) -> pd.Series:
        """Fit preprocessor and transform data.
        
        Args:
            data: Time series to preprocess
            
        Returns:
            Preprocessed time series
        """
        # Handle missing values
        if data.isnull().any():
            data = self._handle_missing_values(data)
        
        # Handle outliers
        if self.handle_outliers:
            data = self._handle_outliers_data(data)
        
        # Normalize
        if self.normalize:
            data = self._normalize_data(data)
        
        # Decompose
        if self.decompose and self.decomposer:
            trend, seasonal, residual = self.decomposer.fit_transform(data)
            # Return detrended and deseasonalized data (residual)
            # Models will work on the residual component
            return residual
        
        return data

    def _handle_missing_values(self, data: pd.Series) -> pd.Series:
        """Handle missing values in time series.
        
        Args:
            data: Time series with missing values
            
        Returns:
            Time series with missing values handled
        """
        if self.handle_missing == "interpolate":
            return data.interpolate(method='time')
        elif self.handle_missing == "forward":
            return data.fillna(method='ffill')
        elif self.handle_missing == "backward":
            return data.fillna(method='bfill')
        else:
            return data

    def _handle_outliers_data(self, data: pd.Series) -> pd.Series:
        """Handle outliers in time series.
        
        Args:
            data: Time series data
            
        Returns:
            Time series with outliers handled
        """
        from forecasting.data.validators import TimeSeriesValidator
        
        validator = TimeSeriesValidator()
        outliers = validator.detect_outliers(
            data,
            method=self.outlier_method,
            threshold=self.outlier_threshold,
        )
        
        # Replace outliers with interpolated values
        data_clean = data.copy()
        data_clean[outliers] = np.nan
        data_clean = data_clean.interpolate(method='time')
        
        return data_clean

    def _normalize_data(self, data: pd.Series) -> pd.Series:
        """Normalize time series data.
        
        Args:
            data: Time series to normalize
            
        Returns:
            Normalized time series
        """
        if self.normalize_method == "standardize":
            self._mean = data.mean()
            self._std = data.std()
            return (data - self._mean) / self._std
        elif self.normalize_method == "minmax":
            self._min = data.min()
            self._max = data.max()
            return (data - self._min) / (self._max - self._min)
        else:
            return data

    def inverse_transform(self, data: pd.Series) -> pd.Series:
        """Inverse transform preprocessed data back to original scale.
        
        Args:
            data: Preprocessed time series
            
        Returns:
            Data in original scale
        """
        # Inverse normalize
        if self.normalize:
            if self.normalize_method == "standardize":
                data = data * self._std + self._mean
            elif self.normalize_method == "minmax":
                data = data * (self._max - self._min) + self._min
        
        # Reconstruct from decomposition
        if self.decompose and self.decomposer:
            components = self.decomposer.get_components()
            if self.decomposer.model == DecompositionModel.ADDITIVE:
                data = data + components['trend'] + components['seasonal']
            else:  # MULTIPLICATIVE
                data = data * components['trend'] * components['seasonal']
        
        return data


# Made with Bob
