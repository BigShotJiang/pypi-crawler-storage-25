"""Unit tests for feature engineering module."""

import pytest
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

from forecasting.data.feature_engineering import TimeSeriesFeatureEngineer


@pytest.fixture
def sample_time_series():
    """Create a sample time series for testing."""
    dates = pd.date_range('2023-01-01', periods=100, freq='D')
    # Create data with trend and seasonality
    trend = np.arange(100) * 0.5
    seasonality = 10 * np.sin(2 * np.pi * np.arange(100) / 7)
    noise = np.random.RandomState(42).randn(100) * 2
    values = 100 + trend + seasonality + noise
    return pd.Series(values, index=dates)


class TestTimeSeriesFeatureEngineer:
    """Test TimeSeriesFeatureEngineer class."""
    
    def test_initialization(self):
        """Test feature engineer initialization."""
        engineer = TimeSeriesFeatureEngineer(
            lags=[1, 7],
            rolling_windows=[7],
            include_date_features=True,
            include_fourier=True
        )
        
        assert engineer.lags == [1, 7]
        assert engineer.rolling_windows == [7]
        assert engineer.include_date_features is True
        assert engineer.include_fourier is True
    
    def test_create_lag_features(self, sample_time_series):
        """Test lag feature creation."""
        engineer = TimeSeriesFeatureEngineer(lags=[1, 7])
        features = engineer.create_lag_features(sample_time_series)
        
        assert 'lag_1' in features.columns
        assert 'lag_7' in features.columns
        assert len(features) == len(sample_time_series)
        
        # Check lag values are correct
        assert features['lag_1'].iloc[10] == sample_time_series.iloc[9]
        assert features['lag_7'].iloc[10] == sample_time_series.iloc[3]
    
    def test_create_rolling_features(self, sample_time_series):
        """Test rolling statistics feature creation."""
        engineer = TimeSeriesFeatureEngineer(rolling_windows=[7])
        features = engineer.create_rolling_features(sample_time_series)
        
        assert 'rolling_mean_7' in features.columns
        assert 'rolling_std_7' in features.columns
        assert 'rolling_min_7' in features.columns
        assert 'rolling_max_7' in features.columns
        
        # Check rolling mean is correct
        expected_mean = sample_time_series.rolling(window=7).mean()
        pd.testing.assert_series_equal(
            features['rolling_mean_7'],
            expected_mean,
            check_names=False
        )
    
    def test_create_date_features(self, sample_time_series):
        """Test date/time feature creation."""
        engineer = TimeSeriesFeatureEngineer(include_date_features=True)
        features = engineer.create_date_features(sample_time_series)
        
        assert 'day_of_week' in features.columns
        assert 'day_of_month' in features.columns
        assert 'month' in features.columns
        assert 'quarter' in features.columns
        assert 'day_of_year' in features.columns
        
        # Check values are in correct ranges
        assert features['day_of_week'].min() >= 0
        assert features['day_of_week'].max() <= 6
        assert features['month'].min() >= 1
        assert features['month'].max() <= 12
    
    def test_create_fourier_features(self, sample_time_series):
        """Test Fourier feature creation."""
        engineer = TimeSeriesFeatureEngineer(include_fourier=True)
        features = engineer.create_fourier_features(sample_time_series, period=7, order=2)
        
        assert 'fourier_sin_1' in features.columns
        assert 'fourier_cos_1' in features.columns
        assert 'fourier_sin_2' in features.columns
        assert 'fourier_cos_2' in features.columns
        
        # Check Fourier features are bounded
        assert features['fourier_sin_1'].min() >= -1
        assert features['fourier_sin_1'].max() <= 1
        assert features['fourier_cos_1'].min() >= -1
        assert features['fourier_cos_1'].max() <= 1
    
    def test_create_all_features(self, sample_time_series):
        """Test creating all features at once."""
        engineer = TimeSeriesFeatureEngineer(
            lags=[1, 7],
            rolling_windows=[7],
            include_date_features=True,
            include_fourier=True
        )
        
        features = engineer.create_all_features(sample_time_series, auto_detect=True)
        
        # Check all feature types are present
        assert 'lag_1' in features.columns
        assert 'rolling_mean_7' in features.columns
        assert 'day_of_week' in features.columns
        
        # Check auto-detection worked
        assert engineer.detected_period_ is not None
        
        # Check no NaN in final features (after dropna)
        assert not features.isnull().any().any()
    
    def test_auto_detect_seasonality(self, sample_time_series):
        """Test automatic seasonality detection."""
        engineer = TimeSeriesFeatureEngineer()
        features = engineer.create_all_features(sample_time_series, auto_detect=True)
        
        # Should detect weekly seasonality (period=7)
        assert engineer.detected_period_ == 7
    
    def test_empty_series(self):
        """Test handling of empty series."""
        engineer = TimeSeriesFeatureEngineer(lags=[1])
        empty_series = pd.Series([], dtype=float)
        
        features = engineer.create_lag_features(empty_series)
        assert len(features) == 0
    
    def test_short_series(self):
        """Test handling of very short series."""
        engineer = TimeSeriesFeatureEngineer(lags=[1, 7], rolling_windows=[7])
        short_series = pd.Series([1, 2, 3], index=pd.date_range('2023-01-01', periods=3))
        
        features = engineer.create_all_features(short_series)
        
        # Should still create features but with NaN values
        assert len(features) == len(short_series)
        assert 'lag_1' in features.columns


class TestFeatureEngineeringIntegration:
    """Integration tests for feature engineering."""
    
    def test_feature_engineering_pipeline(self, sample_time_series):
        """Test complete feature engineering pipeline."""
        # Create engineer
        engineer = TimeSeriesFeatureEngineer(
            lags=[1, 7, 14],
            rolling_windows=[7, 14],
            include_date_features=True,
            include_fourier=True
        )
        
        # Create features
        features = engineer.create_all_features(sample_time_series, auto_detect=True)
        
        # Verify feature count
        expected_features = (
            3 +  # lags
            8 +  # rolling (4 stats * 2 windows)
            5 +  # date features
            4    # Fourier (2 orders * 2 components)
        )
        assert features.shape[1] == expected_features
        
        # Verify no data leakage (features use only past data)
        for col in features.columns:
            if col.startswith('lag_'):
                lag = int(col.split('_')[1])
                # Check that lag feature at index i equals value at index i-lag
                for i in range(lag, len(features)):
                    if not pd.isna(features[col].iloc[i]):
                        assert features[col].iloc[i] == sample_time_series.iloc[i - lag]
    
    def test_feature_consistency(self, sample_time_series):
        """Test that features are consistent across multiple calls."""
        engineer = TimeSeriesFeatureEngineer(lags=[1, 7])
        
        features1 = engineer.create_all_features(sample_time_series)
        features2 = engineer.create_all_features(sample_time_series)
        
        pd.testing.assert_frame_equal(features1, features2)


if __name__ == '__main__':
    pytest.main([__file__, '-v'])

# Made with Bob