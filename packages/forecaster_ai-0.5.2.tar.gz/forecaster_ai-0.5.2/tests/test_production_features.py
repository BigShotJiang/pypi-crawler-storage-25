"""Unit tests for production features."""

import pytest
import numpy as np
import pandas as pd
import tempfile
import shutil
from pathlib import Path

from forecasting.core.config import ForecastConfig
from forecasting.models.arima import ARIMAForecaster
from forecasting.production.ab_testing import ABTestFramework
from forecasting.production.retraining import AutoRetrainer
from forecasting.production.registry import ModelRegistry


@pytest.fixture
def sample_data():
    """Create sample time series data."""
    dates = pd.date_range('2023-01-01', periods=100, freq='D')
    values = 100 + np.arange(100) * 0.5 + np.random.RandomState(42).randn(100) * 5
    return pd.Series(values, index=dates)


@pytest.fixture
def trained_model(sample_data):
    """Create a trained model."""
    config = ForecastConfig(horizon=10)
    model = ARIMAForecaster(config, order=(1, 1, 1))
    model.fit(sample_data[:80])
    return model


@pytest.fixture
def temp_registry_path():
    """Create temporary directory for model registry."""
    temp_dir = tempfile.mkdtemp()
    yield temp_dir
    shutil.rmtree(temp_dir)


class TestABTestFramework:
    """Test A/B testing framework."""
    
    def test_initialization(self):
        """Test AB test framework initialization."""
        framework = ABTestFramework(significance_level=0.05)
        assert framework.significance_level == 0.05
    
    def test_run_ab_test(self, sample_data):
        """Test running A/B test between two models."""
        config = ForecastConfig(horizon=10)
        
        # Create two models
        model_a = ARIMAForecaster(config, order=(1, 1, 1))
        model_b = ARIMAForecaster(config, order=(2, 1, 2))
        
        # Train on first 70 points
        train_data = sample_data[:70]
        test_data = sample_data[70:]
        
        model_a.fit(train_data)
        model_b.fit(train_data)
        
        # Run A/B test
        framework = ABTestFramework()
        result = framework.run_ab_test(
            model_a=model_a,
            model_b=model_b,
            test_data=test_data,
            metric='mae'
        )
        
        # Check result structure
        assert 'winner' in result
        assert 'p_value' in result
        assert 'is_significant' in result
        assert 'model_a_score' in result
        assert 'model_b_score' in result
        
        # Check winner is valid
        assert result['winner'] in ['model_a', 'model_b', 'tie']
        
        # Check p-value is valid
        assert 0 <= result['p_value'] <= 1
    
    def test_compare_models(self, sample_data):
        """Test comparing multiple models."""
        config = ForecastConfig(horizon=10)
        
        models = {
            'arima_111': ARIMAForecaster(config, order=(1, 1, 1)),
            'arima_212': ARIMAForecaster(config, order=(2, 1, 2))
        }
        
        train_data = sample_data[:70]
        test_data = sample_data[70:]
        
        # Train all models
        for model in models.values():
            model.fit(train_data)
        
        # Compare models
        framework = ABTestFramework()
        comparison = framework.compare_models(
            models=models,
            test_data=test_data,
            metric='mae'
        )
        
        # Check comparison structure
        assert 'best_model' in comparison
        assert 'scores' in comparison
        assert 'rankings' in comparison
        
        # Check all models are in scores
        for model_name in models.keys():
            assert model_name in comparison['scores']


class TestAutoRetrainer:
    """Test automatic retraining."""
    
    def test_initialization(self):
        """Test auto retrainer initialization."""
        retrainer = AutoRetrainer(
            performance_threshold=0.15,
            min_samples_for_retrain=50
        )
        
        assert retrainer.performance_threshold == 0.15
        assert retrainer.min_samples_for_retrain == 50
    
    def test_should_retrain_performance_degradation(self, sample_data):
        """Test retraining decision based on performance degradation."""
        retrainer = AutoRetrainer(performance_threshold=0.10)
        
        # Simulate performance degradation
        decision = retrainer.should_retrain(
            current_performance=15.0,
            baseline_performance=10.0,
            new_data=sample_data
        )
        
        assert decision['should_retrain'] is True
        assert 'performance_degradation' in decision['reasons']
    
    def test_should_retrain_sufficient_data(self, sample_data):
        """Test retraining decision based on data availability."""
        retrainer = AutoRetrainer(
            performance_threshold=0.10,
            min_samples_for_retrain=50
        )
        
        # Sufficient new data
        decision = retrainer.should_retrain(
            current_performance=10.5,
            baseline_performance=10.0,
            new_data=sample_data
        )
        
        assert decision['should_retrain'] is True
        assert 'sufficient_new_data' in decision['reasons']
    
    def test_should_not_retrain(self, sample_data):
        """Test when retraining is not needed."""
        retrainer = AutoRetrainer(
            performance_threshold=0.20,
            min_samples_for_retrain=200
        )
        
        # Good performance, insufficient data
        decision = retrainer.should_retrain(
            current_performance=10.5,
            baseline_performance=10.0,
            new_data=sample_data[:30]
        )
        
        assert decision['should_retrain'] is False
    
    def test_retrain_model(self, trained_model, sample_data):
        """Test model retraining."""
        retrainer = AutoRetrainer()
        
        # Retrain with new data
        retrained_model = retrainer.retrain_model(
            model=trained_model,
            new_data=sample_data
        )
        
        # Check model was retrained
        assert retrained_model is not None
        assert hasattr(retrained_model, 'model')


class TestModelRegistry:
    """Test model registry."""
    
    def test_initialization(self, temp_registry_path):
        """Test model registry initialization."""
        registry = ModelRegistry(storage_path=temp_registry_path)
        
        assert registry.storage_path == Path(temp_registry_path)
        assert registry.storage_path.exists()
    
    def test_register_model(self, trained_model, temp_registry_path):
        """Test registering a model."""
        registry = ModelRegistry(storage_path=temp_registry_path)
        
        model_id = registry.register_model(
            model=trained_model,
            metadata={
                'name': 'test_model',
                'description': 'Test ARIMA model',
                'metrics': {'mae': 5.2, 'rmse': 7.1}
            }
        )
        
        # Check model was registered
        assert model_id is not None
        assert len(model_id) > 0
        
        # Check model file exists
        model_files = list(registry.storage_path.glob(f"{model_id}*.pkl"))
        assert len(model_files) > 0
    
    def test_load_model(self, trained_model, temp_registry_path):
        """Test loading a registered model."""
        registry = ModelRegistry(storage_path=temp_registry_path)
        
        # Register model
        model_id = registry.register_model(
            model=trained_model,
            metadata={'name': 'test_model'}
        )
        
        # Load model
        loaded_model = registry.load_model(model_id)
        
        assert loaded_model is not None
        assert isinstance(loaded_model, ARIMAForecaster)
    
    def test_promote_model(self, trained_model, temp_registry_path):
        """Test promoting a model to production."""
        registry = ModelRegistry(storage_path=temp_registry_path)
        
        # Register and promote model
        model_id = registry.register_model(
            model=trained_model,
            metadata={'name': 'test_model'}
        )
        
        registry.promote_model(model_id)
        
        # Check production model
        prod_model = registry.get_production_model()
        assert prod_model is not None
    
    def test_list_models(self, trained_model, temp_registry_path):
        """Test listing registered models."""
        registry = ModelRegistry(storage_path=temp_registry_path)
        
        # Register multiple models
        model_id1 = registry.register_model(
            model=trained_model,
            metadata={'name': 'model_1'}
        )
        model_id2 = registry.register_model(
            model=trained_model,
            metadata={'name': 'model_2'}
        )
        
        # List models
        models = registry.list_models()
        
        assert len(models) >= 2
        assert any(m['model_id'] == model_id1 for m in models)
        assert any(m['model_id'] == model_id2 for m in models)
    
    def test_delete_model(self, trained_model, temp_registry_path):
        """Test deleting a model."""
        registry = ModelRegistry(storage_path=temp_registry_path)
        
        # Register model
        model_id = registry.register_model(
            model=trained_model,
            metadata={'name': 'test_model'}
        )
        
        # Delete model
        registry.delete_model(model_id)
        
        # Check model was deleted
        with pytest.raises(Exception):
            registry.load_model(model_id)
    
    def test_rollback(self, trained_model, temp_registry_path):
        """Test rolling back to previous model."""
        registry = ModelRegistry(storage_path=temp_registry_path)
        
        # Register two models
        model_id1 = registry.register_model(
            model=trained_model,
            metadata={'name': 'model_v1'}
        )
        registry.promote_model(model_id1)
        
        model_id2 = registry.register_model(
            model=trained_model,
            metadata={'name': 'model_v2'}
        )
        registry.promote_model(model_id2)
        
        # Rollback
        registry.rollback()
        
        # Check production model is v1
        prod_model_id = registry.production_model_id
        assert prod_model_id == model_id1


class TestProductionIntegration:
    """Integration tests for production features."""
    
    def test_complete_production_workflow(self, sample_data, temp_registry_path):
        """Test complete production workflow."""
        config = ForecastConfig(horizon=10)
        
        # 1. Train initial model
        model = ARIMAForecaster(config, order=(1, 1, 1))
        model.fit(sample_data[:70])
        
        # 2. Register model
        registry = ModelRegistry(storage_path=temp_registry_path)
        model_id = registry.register_model(
            model=model,
            metadata={
                'name': 'production_model_v1',
                'metrics': {'mae': 5.0}
            }
        )
        
        # 3. Promote to production
        registry.promote_model(model_id)
        
        # 4. Check if retraining needed
        retrainer = AutoRetrainer(performance_threshold=0.15)
        decision = retrainer.should_retrain(
            current_performance=6.0,
            baseline_performance=5.0,
            new_data=sample_data[70:]
        )
        
        # 5. If needed, retrain and register new version
        if decision['should_retrain']:
            new_model = retrainer.retrain_model(model, sample_data)
            new_model_id = registry.register_model(
                model=new_model,
                metadata={
                    'name': 'production_model_v2',
                    'metrics': {'mae': 5.5}
                }
            )
            
            # 6. A/B test before promoting
            framework = ABTestFramework()
            test_result = framework.run_ab_test(
                model_a=model,
                model_b=new_model,
                test_data=sample_data[80:],
                metric='mae'
            )
            
            # 7. Promote if new model is better
            if test_result['winner'] == 'model_b':
                registry.promote_model(new_model_id)
        
        # Verify production model exists
        prod_model = registry.get_production_model()
        assert prod_model is not None


if __name__ == '__main__':
    pytest.main([__file__, '-v'])

# Made with Bob