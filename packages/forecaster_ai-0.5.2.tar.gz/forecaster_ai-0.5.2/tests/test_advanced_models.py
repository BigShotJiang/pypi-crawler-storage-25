"""Unit tests for advanced forecasting models."""

import pytest
import numpy as np
import pandas as pd

from forecasting.core.config import ForecastConfig
from forecasting.models.arima import ARIMAForecaster
from forecasting.models.probabilistic import ProbabilisticForecaster
from forecasting.models.hierarchical import HierarchicalForecaster
from forecasting.models.multistep import MultiStepForecaster


@pytest.fixture
def sample_data():
    """Create sample time series data."""
    dates = pd.date_range('2023-01-01', periods=100, freq='D')
    values = 100 + np.arange(100) * 0.5 + np.random.RandomState(42).randn(100) * 5
    return pd.Series(values, index=dates)


@pytest.fixture
def hierarchical_data():
    """Create hierarchical time series data."""
    dates = pd.date_range('2023-01-01', periods=100, freq='D')
    
    # Create data for different levels
    data = {
        'total': pd.Series(
            100 + np.arange(100) * 0.5 + np.random.RandomState(42).randn(100) * 5,
            index=dates
        ),
        'region_a': pd.Series(
            60 + np.arange(100) * 0.3 + np.random.RandomState(43).randn(100) * 3,
            index=dates
        ),
        'region_b': pd.Series(
            40 + np.arange(100) * 0.2 + np.random.RandomState(44).randn(100) * 2,
            index=dates
        )
    }
    
    return data


class TestProbabilisticForecaster:
    """Test probabilistic forecasting."""
    
    def test_initialization(self, sample_data):
        """Test probabilistic forecaster initialization."""
        config = ForecastConfig(horizon=10)
        base_model = ARIMAForecaster(config, order=(1, 1, 1))
        base_model.fit(sample_data)
        
        prob_model = ProbabilisticForecaster(config, base_model=base_model)
        
        assert prob_model.base_model is not None
        assert prob_model.config.horizon == 10
    
    def test_fit(self, sample_data):
        """Test fitting probabilistic forecaster."""
        config = ForecastConfig(horizon=10)
        base_model = ARIMAForecaster(config, order=(1, 1, 1))
        
        prob_model = ProbabilisticForecaster(config, base_model=base_model)
        prob_model.fit(sample_data)
        
        assert prob_model.base_model.model is not None
    
    def test_predict_quantiles(self, sample_data):
        """Test quantile predictions."""
        config = ForecastConfig(horizon=10)
        base_model = ARIMAForecaster(config, order=(1, 1, 1))
        
        prob_model = ProbabilisticForecaster(config, base_model=base_model)
        prob_model.fit(sample_data)
        
        quantiles = prob_model.predict_quantiles(
            horizon=10,
            quantiles=[0.1, 0.5, 0.9]
        )
        
        # Check output structure
        assert isinstance(quantiles, pd.DataFrame)
        assert len(quantiles) == 10
        assert 'q_0.1' in quantiles.columns
        assert 'q_0.5' in quantiles.columns
        assert 'q_0.9' in quantiles.columns
        
        # Check quantile ordering
        assert (quantiles['q_0.1'] <= quantiles['q_0.5']).all()
        assert (quantiles['q_0.5'] <= quantiles['q_0.9']).all()
    
    def test_predict_intervals(self, sample_data):
        """Test prediction intervals."""
        config = ForecastConfig(horizon=10)
        base_model = ARIMAForecaster(config, order=(1, 1, 1))
        
        prob_model = ProbabilisticForecaster(config, base_model=base_model)
        prob_model.fit(sample_data)
        
        intervals = prob_model.predict_intervals(
            horizon=10,
            confidence_levels=[0.80, 0.95]
        )
        
        # Check output structure
        assert isinstance(intervals, dict)
        assert 0.80 in intervals
        assert 0.95 in intervals
        
        # Check interval structure
        for level, interval in intervals.items():
            assert 'lower' in interval
            assert 'upper' in interval
            assert len(interval['lower']) == 10
            assert len(interval['upper']) == 10
            
            # Check lower < upper
            assert (interval['lower'] <= interval['upper']).all()


class TestHierarchicalForecaster:
    """Test hierarchical forecasting."""
    
    def test_initialization(self, hierarchical_data):
        """Test hierarchical forecaster initialization."""
        config = ForecastConfig(horizon=10)
        
        forecaster = HierarchicalForecaster(
            config,
            hierarchy={'total': ['region_a', 'region_b']},
            method='bottom_up'
        )
        
        assert forecaster.hierarchy is not None
        assert forecaster.method == 'bottom_up'
    
    def test_fit(self, hierarchical_data):
        """Test fitting hierarchical forecaster."""
        config = ForecastConfig(horizon=10)
        
        forecaster = HierarchicalForecaster(
            config,
            hierarchy={'total': ['region_a', 'region_b']},
            method='bottom_up'
        )
        
        forecaster.fit(hierarchical_data)
        
        # Check models were created for each series
        assert len(forecaster.models) > 0
    
    def test_predict_bottom_up(self, hierarchical_data):
        """Test bottom-up forecasting."""
        config = ForecastConfig(horizon=10)
        
        forecaster = HierarchicalForecaster(
            config,
            hierarchy={'total': ['region_a', 'region_b']},
            method='bottom_up'
        )
        
        forecaster.fit(hierarchical_data)
        forecasts = forecaster.predict(horizon=10)
        
        # Check forecasts for all levels
        assert 'total' in forecasts
        assert 'region_a' in forecasts
        assert 'region_b' in forecasts
        
        # Check bottom-up constraint: total = sum of regions
        total_forecast = forecasts['total']
        sum_regions = forecasts['region_a'] + forecasts['region_b']
        
        np.testing.assert_array_almost_equal(
            total_forecast.values,
            sum_regions.values,
            decimal=2
        )
    
    def test_predict_top_down(self, hierarchical_data):
        """Test top-down forecasting."""
        config = ForecastConfig(horizon=10)
        
        forecaster = HierarchicalForecaster(
            config,
            hierarchy={'total': ['region_a', 'region_b']},
            method='top_down'
        )
        
        forecaster.fit(hierarchical_data)
        forecasts = forecaster.predict(horizon=10)
        
        # Check forecasts exist
        assert 'total' in forecasts
        assert 'region_a' in forecasts
        assert 'region_b' in forecasts


class TestMultiStepForecaster:
    """Test multi-step forecasting strategies."""
    
    def test_initialization(self):
        """Test multi-step forecaster initialization."""
        config = ForecastConfig(horizon=10)
        
        forecaster = MultiStepForecaster(
            config,
            strategy='recursive'
        )
        
        assert forecaster.strategy == 'recursive'
    
    def test_fit(self, sample_data):
        """Test fitting multi-step forecaster."""
        config = ForecastConfig(horizon=10)
        
        forecaster = MultiStepForecaster(
            config,
            strategy='recursive'
        )
        
        forecaster.fit(sample_data)
        
        assert forecaster.models is not None
    
    def test_predict_recursive(self, sample_data):
        """Test recursive multi-step prediction."""
        config = ForecastConfig(horizon=10)
        
        forecaster = MultiStepForecaster(
            config,
            strategy='recursive'
        )
        
        forecaster.fit(sample_data)
        forecast, _ = forecaster.predict(horizon=10)
        
        assert len(forecast) == 10
        assert isinstance(forecast, pd.Series)
    
    def test_predict_direct(self, sample_data):
        """Test direct multi-step prediction."""
        config = ForecastConfig(horizon=5)
        
        forecaster = MultiStepForecaster(
            config,
            strategy='direct'
        )
        
        forecaster.fit(sample_data)
        forecast, _ = forecaster.predict(horizon=5)
        
        assert len(forecast) == 5
        assert isinstance(forecast, pd.Series)
    
    def test_predict_dirrec(self, sample_data):
        """Test DirRec multi-step prediction."""
        config = ForecastConfig(horizon=10)
        
        forecaster = MultiStepForecaster(
            config,
            strategy='dirrec'
        )
        
        forecaster.fit(sample_data)
        forecast, _ = forecaster.predict(horizon=10)
        
        assert len(forecast) == 10
        assert isinstance(forecast, pd.Series)
    
    def test_predict_mimo(self, sample_data):
        """Test MIMO multi-step prediction."""
        config = ForecastConfig(horizon=10)
        
        forecaster = MultiStepForecaster(
            config,
            strategy='mimo'
        )
        
        forecaster.fit(sample_data)
        forecast, _ = forecaster.predict(horizon=10)
        
        assert len(forecast) == 10
        assert isinstance(forecast, pd.Series)


class TestAdvancedModelsIntegration:
    """Integration tests for advanced models."""
    
    def test_probabilistic_with_hierarchical(self, hierarchical_data):
        """Test combining probabilistic and hierarchical forecasting."""
        config = ForecastConfig(horizon=10)
        
        # Create hierarchical forecaster
        hier_forecaster = HierarchicalForecaster(
            config,
            hierarchy={'total': ['region_a', 'region_b']},
            method='bottom_up'
        )
        
        hier_forecaster.fit(hierarchical_data)
        forecasts = hier_forecaster.predict(horizon=10)
        
        # Wrap in probabilistic forecaster for uncertainty
        prob_forecaster = ProbabilisticForecaster(
            config,
            base_model=hier_forecaster
        )
        
        # Should be able to get quantiles
        assert prob_forecaster.base_model is not None
    
    def test_multistep_strategies_comparison(self, sample_data):
        """Test comparing different multi-step strategies."""
        config = ForecastConfig(horizon=10)
        strategies = ['recursive', 'direct', 'dirrec', 'mimo']
        
        forecasts = {}
        
        for strategy in strategies:
            forecaster = MultiStepForecaster(config, strategy=strategy)
            forecaster.fit(sample_data[:80])
            forecast, _ = forecaster.predict(horizon=10)
            forecasts[strategy] = forecast
        
        # All strategies should produce forecasts
        assert len(forecasts) == len(strategies)
        
        # All forecasts should have same length
        for forecast in forecasts.values():
            assert len(forecast) == 10


if __name__ == '__main__':
    pytest.main([__file__, '-v'])

# Made with Bob