# this string is used for the version string in the documentation, as well as the egg
__version__ = '3.12.1'
